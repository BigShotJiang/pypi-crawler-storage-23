"""Seahorse VectorStore implementation for LangChain."""

import json
import logging
from typing import Any, Dict, Iterable, List, Optional, Tuple

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_core.vectorstores import VectorStore

from .client import SeahorseClient
from .exceptions import SeahorseDimensionMismatchError, SeahorseSchemaError
from .filters import convert_filter_to_sql
from .models import (
    DenseSearchConfig,
    HybridSearchConfig,
    SearchMode,
    SparseSearchConfig,
)
from .utils import EMBEDDING_API_MAX_ROWS, batch_texts, generate_pk

logger = logging.getLogger(__name__)


class SeahorseVectorStore(VectorStore):
    """Seahorse API Gateway VectorStore implementation.

    이 클래스는 LangChain의 VectorStore 인터페이스를 구현하여
    Seahorse API Gateway를 벡터 저장소로 사용할 수 있게 합니다.

    Dense, Sparse, Hybrid 검색 모드를 지원합니다.

    Args:
        api_key: Seahorse API key
        base_url: Seahorse API base URL (테이블별 고유 URL)
        embedding: LangChain Embeddings instance (외부 임베딩 사용 시 필수, Dense만)
        use_builtin_embedding: Seahorse 내장 임베딩 사용 여부 (기본: True)
        dense_column: Dense 벡터 컬럼명 (기본: "dense_vector")
        sparse_column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
        **kwargs: 추가 인자

    Note:
        - use_builtin_embedding=True 일 때는 /v2/data/embedding을 사용합니다.
        - 외부 임베딩은 Dense 벡터에만 지원됩니다. Sparse는 항상 내장 임베딩 사용.
        - 외부 임베딩 사용 시에도 Sparse/Hybrid 검색 지원:
          - Dense 검색: 외부 임베딩으로 query vector 생성
          - Sparse 검색: query text 사용 (Seahorse 내장 임베딩)
          - Hybrid 검색: Dense는 외부 임베딩, Sparse는 내장 임베딩

    Attributes:
        _client: SeahorseClient instance
        _embedding: Embeddings instance (외부 임베딩 사용 시)
        _use_builtin_embedding: 내장 임베딩 사용 여부
        _dense_column: Dense 벡터 컬럼명
        _sparse_column: Sparse 벡터 컬럼명
        dimension: Dense 벡터 차원 (테이블 스키마에서 조회)

    Examples:
        >>> from seahorse_vector_store import SeahorseVectorStore, SearchMode
        >>>
        >>> # Seahorse 내장 임베딩 사용 (기본)
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://xxx.api.seahorse.dnotitia.ai"
        ... )
        >>>
        >>> # 텍스트 추가 (Dense + Sparse 자동 임베딩)
        >>> ids = vectorstore.add_texts(
        ...     texts=["Hello, world!", "LangChain is awesome!"],
        ...     metadatas=[{"source": "doc1.txt"}, {"source": "doc2.txt"}]
        ... )
        >>>
        >>> # Hybrid 검색 (기본)
        >>> docs = vectorstore.similarity_search("greeting", k=2)
        >>>
        >>> # Dense 검색
        >>> docs = vectorstore.similarity_search(
        ...     "greeting", k=2, retrieval_mode=SearchMode.DENSE
        ... )
        >>>
        >>> # Sparse 검색
        >>> docs = vectorstore.similarity_search(
        ...     "greeting", k=2, retrieval_mode=SearchMode.SPARSE
        ... )
        >>>
        >>> # 외부 임베딩 사용 (Dense만 지원)
        >>> from langchain_openai import OpenAIEmbeddings
        >>> vectorstore = SeahorseVectorStore(
        ...     api_key="your-api-key",
        ...     base_url="https://xxx.api.seahorse.dnotitia.ai",
        ...     embedding=OpenAIEmbeddings(),
        ...     use_builtin_embedding=False
        ... )
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        embedding: Optional[Embeddings] = None,
        use_builtin_embedding: bool = True,
        dense_column: str = "dense_vector",
        sparse_column: str = "sparse_vector",
        index_name: Optional[str] = None,  # deprecated, use dense_column
        **kwargs: Any,
    ) -> None:
        """Initialize SeahorseVectorStore.

        Args:
            api_key: Seahorse API key
            base_url: Seahorse API base URL (테이블별 고유 URL)
            embedding: LangChain Embeddings instance (optional, Dense만 지원)
            use_builtin_embedding: Seahorse 내장 임베딩 사용 여부
            dense_column: Dense 벡터 컬럼명 (기본: "dense_vector")
            sparse_column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
            index_name: Deprecated, use dense_column instead
            **kwargs: 추가 인자

        Raises:
            ValueError: use_builtin_embedding과 embedding 설정이 충돌할 경우
        """
        self._api_key = api_key
        self._base_url = base_url
        self._use_builtin_embedding = use_builtin_embedding

        # index_name 호환성 (deprecated)
        if index_name is not None:
            import warnings

            warnings.warn(
                "index_name is deprecated. Use dense_column instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            dense_column = index_name

        self._dense_column = dense_column
        self._sparse_column = sparse_column
        # 하위 호환성을 위해 _index_name 유지
        self._index_name = dense_column

        # SeahorseClient 초기화
        self._client = SeahorseClient(base_url=base_url, api_key=api_key)

        # 테이블 스키마 조회하여 dense_vector dimension 설정
        self.dimension = self._get_dense_vector_dimension()

        # Embedding 설정
        if use_builtin_embedding:
            if embedding is not None:
                raise ValueError(
                    "Cannot specify both use_builtin_embedding=True and embedding"
                )
            self._embedding = None
        else:
            if embedding is None:
                raise ValueError(
                    "Must provide embedding when use_builtin_embedding=False"
                )
            self._embedding = embedding

    @property
    def embeddings(self) -> Optional[Embeddings]:
        """Get the embeddings instance.

        Returns:
            Embeddings instance if external embedding is used, None otherwise
        """
        return self._embedding

    def _get_dense_vector_dimension(self) -> int:
        """테이블 스키마에서 dense_vector 컬럼의 차원 조회.

        GET /v2/data/schema API를 호출하여 dense_vector 컬럼의 dim 값을 반환합니다.

        Returns:
            Dense 벡터 차원

        Raises:
            SeahorseSchemaError: 스키마 조회 실패 또는 dense_vector 컬럼을 찾을 수 없는 경우
        """
        try:
            schema = self._client.get_table_schema()
        except Exception as e:
            raise SeahorseSchemaError(f"Failed to retrieve table schema: {e}") from e

        # columns에서 dense_vector 컬럼 찾기
        columns = schema.get("columns", [])
        for column in columns:
            if column.get("name") == self._dense_column:
                col_type = column.get("type")
                if (
                    isinstance(col_type, dict)
                    and col_type.get("name") == "DENSE_VECTOR"
                ):
                    dim = col_type.get("dim")
                    if dim is not None:
                        return int(dim)

        raise SeahorseSchemaError(
            f"Could not find dimension for dense_vector column '{self._dense_column}' "
            f"in table schema. Ensure the table has a DENSE_VECTOR column."
        )

    def add_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """텍스트를 벡터 저장소에 추가.

        Args:
            texts: 추가할 텍스트 목록
            metadatas: 각 텍스트의 메타데이터 (optional)
            **kwargs: 추가 인자

        Returns:
            생성된 document ID 목록

        Raises:
            ValueError: texts와 metadatas의 길이가 다를 경우
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> ids = vectorstore.add_texts(
            ...     texts=["text1", "text2"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}]
            ... )
        """
        texts_list = list(texts)

        if metadatas is None:
            metadatas = [{} for _ in texts_list]
        elif len(metadatas) != len(texts_list):
            raise ValueError("metadatas must have same length as texts")

        if self._use_builtin_embedding:
            # Seahorse 내장 임베딩 사용
            return self._add_texts_with_builtin_embedding(texts_list, metadatas)
        else:
            # 외부 임베딩 사용
            return self._add_texts_with_external_embedding(texts_list, metadatas)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        retrieval_mode: SearchMode = SearchMode.HYBRID,
        hybrid_config: Optional[HybridSearchConfig] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """자연어 쿼리로 유사 문서 검색.

        Dense, Sparse, Hybrid 검색 모드를 지원합니다.

        Args:
            query: 검색 쿼리 (자연어)
            k: 반환할 문서 수 (기본: 4)
            filter: 메타데이터 필터 (optional)
            retrieval_mode: 검색 모드 (기본: HYBRID)
            hybrid_config: 검색 설정 (optional)
            **kwargs: 추가 인자 (ef_search 등, 하위 호환성)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패
            ValueError: 외부 임베딩 사용 시 Sparse/Hybrid 모드 사용

        Examples:
            >>> # Hybrid 검색 (기본)
            >>> docs = vectorstore.similarity_search("machine learning", k=5)
            >>>
            >>> # Dense 검색
            >>> docs = vectorstore.similarity_search(
            ...     "machine learning", k=5,
            ...     retrieval_mode=SearchMode.DENSE
            ... )
            >>>
            >>> # Sparse 검색
            >>> docs = vectorstore.similarity_search(
            ...     "machine learning", k=5,
            ...     retrieval_mode=SearchMode.SPARSE
            ... )
            >>>
            >>> # 커스텀 Hybrid 검색
            >>> from seahorse_vector_store import HybridSearchConfig, FusionConfig
            >>> docs = vectorstore.similarity_search(
            ...     "machine learning", k=5,
            ...     hybrid_config=HybridSearchConfig(
            ...         fusion=FusionConfig(alpha=0.7)
            ...     )
            ... )
        """
        docs_and_scores = self.similarity_search_with_score(
            query,
            k=k,
            filter=filter,
            retrieval_mode=retrieval_mode,
            hybrid_config=hybrid_config,
            **kwargs,
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        retrieval_mode: SearchMode = SearchMode.HYBRID,
        hybrid_config: Optional[HybridSearchConfig] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """유사도 점수와 함께 문서 검색.

        Dense, Sparse, Hybrid 검색 모드를 지원합니다.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter: 메타데이터 필터
            retrieval_mode: 검색 모드 (기본: HYBRID)
            hybrid_config: 검색 설정 (optional)
            **kwargs: 추가 인자 (ef_search 등, 하위 호환성)

        Returns:
            (Document, score) 튜플 목록
            - DENSE: distance 값 (작을수록 더 유사)
            - SPARSE/HYBRID: score 값 (클수록 더 유사)

        Raises:
            SeahorseAPIError: API 호출 실패

        Note:
            외부 임베딩 사용 시:
            - Dense 검색: 외부 임베딩으로 query vector 생성
            - Sparse 검색: query text 사용 (Seahorse 내장 임베딩)
            - Hybrid 검색: Dense는 외부 임베딩, Sparse는 내장 임베딩

        Examples:
            >>> docs_and_scores = vectorstore.similarity_search_with_score(
            ...     "neural networks", k=5
            ... )
            >>> for doc, score in docs_and_scores:
            ...     print(f"Score: {score}, Content: {doc.page_content[:50]}")
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # HybridSearchConfig 구성
        if hybrid_config is None:
            hybrid_config = HybridSearchConfig()

        # kwargs에서 ef_search 추출하여 config에 적용 (하위 호환성)
        if "ef_search" in kwargs and hybrid_config.dense is not None:
            # 새 DenseSearchConfig 생성 (immutable 패턴)
            hybrid_config = HybridSearchConfig(
                dense=DenseSearchConfig(
                    column=hybrid_config.dense.column,
                    ef_search=kwargs["ef_search"],
                ),
                sparse=hybrid_config.sparse,
                fusion=hybrid_config.fusion,
            )

        # 컬럼명 설정
        if hybrid_config.dense is not None:
            hybrid_config = HybridSearchConfig(
                dense=DenseSearchConfig(
                    column=self._dense_column,
                    ef_search=hybrid_config.dense.ef_search,
                ),
                sparse=(
                    SparseSearchConfig(
                        column=self._sparse_column,
                        k=hybrid_config.sparse.k if hybrid_config.sparse else 1.2,
                        b=hybrid_config.sparse.b if hybrid_config.sparse else 0.75,
                    )
                    if hybrid_config.sparse
                    else SparseSearchConfig(column=self._sparse_column)
                ),
                fusion=hybrid_config.fusion,
            )

        # 외부 임베딩 사용 시 query vector 생성
        query_vector: Optional[List[float]] = None
        if not self._use_builtin_embedding and self._embedding is not None:
            # Dense 검색이 필요한 모드에서만 외부 임베딩으로 query vector 생성
            if retrieval_mode in (SearchMode.DENSE, SearchMode.HYBRID):
                query_vector = self._embedding.embed_query(query)
                # 차원 검증
                if len(query_vector) != self.dimension:
                    raise SeahorseDimensionMismatchError(
                        expected=self.dimension,
                        actual=len(query_vector),
                    )

        # 통합 검색 API 호출
        results = self._client.search(
            query_text=query,  # Sparse 검색에 사용 (내장 임베딩)
            query_vector=query_vector,  # Dense 검색에 사용 (외부 임베딩)
            top_k=k,
            search_mode=retrieval_mode,
            config=hybrid_config,
            filter_sql=filter_sql,
        )

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )

            # 검색 모드에 따라 score 필드 선택
            if retrieval_mode == SearchMode.DENSE:
                score = item.get("distance", 0.0)
            else:  # SPARSE, HYBRID
                score = item.get("score", 0.0)

            documents.append((doc, score))

        return documents

    def similarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """벡터로 직접 검색.

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자 (ef_search 등)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> vector = [0.1, 0.2, ..., 0.n]  # 1024차원
            >>> docs = vectorstore.similarity_search_by_vector(vector, k=5)
        """
        docs_and_scores = self.similarity_search_by_vector_with_score(
            embedding, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    def similarity_search_by_vector_with_score(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """벡터로 직접 검색 (점수 포함).

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정
        projection = "id, text, metadata, distance"

        # Vector search API 호출
        results_list = self._client.vector_search(
            index_name=self._index_name,
            query_vectors=[embedding],
            top_k=k,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 첫 번째 resultset 사용 (단일 벡터 검색)
        results = results_list[0] if results_list else []

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    def delete(
        self,
        ids: Optional[List[str]] = None,
        filter: Optional[Dict[str, Any]] = None,
        delete_all: bool = False,
        **kwargs: Any,
    ) -> Optional[bool]:
        """문서 삭제.

        Args:
            ids: 삭제할 document ID 목록
            filter: 메타데이터 필터 (ids와 함께 사용 불가)
            delete_all: 전체 삭제 여부 (기본값: False, 주의 필요!)
            **kwargs: 추가 인자

        Returns:
            성공 여부 (True: 삭제 성공, None: 조건 없음)

        Raises:
            SeahorseAPIError: API 호출 실패
            ValueError: 잘못된 파라미터 조합

        Examples:
            >>> # ID로 삭제
            >>> success = vectorstore.delete(ids=["doc1_id", "doc2_id"])
            >>>
            >>> # 필터로 삭제
            >>> success = vectorstore.delete(filter={"source": "test"})
            >>>
            >>> # 전체 삭제 (주의!)
            >>> success = vectorstore.delete(delete_all=True)

        Warning:
            delete_all=True 사용 시 테이블의 모든 데이터가 삭제됩니다.
            운영 환경에서는 매우 신중하게 사용해야 합니다.
        """
        # 파라미터 유효성 검증
        param_count = sum([ids is not None, filter is not None, delete_all])
        if param_count > 1:
            raise ValueError("ids, filter, delete_all 중 하나만 사용할 수 있습니다")

        if param_count == 0:
            # 아무 조건도 제공되지 않음
            raise ValueError(
                "삭제 조건을 지정해야 합니다. ids, filter, 또는 delete_all=True 중 하나를 제공하세요"
            )

        if ids:
            # SQL IN 절 생성
            ids_quoted = [f"'{id}'" for id in ids]
            delete_condition = f"id IN ({', '.join(ids_quoted)})"
        elif filter:
            # 메타데이터 필터를 SQL WHERE 절로 변환
            delete_condition = convert_filter_to_sql(filter)
        elif delete_all:
            # 전체 삭제 (delete_condition 없음)
            delete_condition = None
        else:
            # 이 경로는 도달하지 않아야 함 (위에서 검증됨)
            return None

        # Delete API 호출 (v2에서는 성공 시 빈 객체 반환)
        self._client.delete_data(delete_condition=delete_condition)

        # 예외 없이 완료되면 성공으로 간주
        return True

    def max_marginal_relevance_search(
        self,
        query: str,
        k: int = 4,
        fetch_k: int = 20,
        lambda_mult: float = 0.5,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """Maximal Marginal Relevance (MMR) 검색.

        ⚠️ 현재 Seahorse API는 MMR 검색을 지원하지 않습니다.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            fetch_k: 후보 문서 수
            lambda_mult: Diversity 파라미터 (0~1)
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            Document 목록

        Raises:
            NotImplementedError: MMR 검색은 현재 지원되지 않습니다
        """
        raise NotImplementedError(
            "Seahorse API does not support MMR (Maximal Marginal Relevance) search. "
            "Use similarity_search() or similarity_search_by_vector() instead."
        )

    # 비동기 메서드
    async def aadd_texts(
        self,
        texts: Iterable[str],
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> List[str]:
        """비동기로 텍스트를 벡터 저장소에 추가.

        Args:
            texts: 추가할 텍스트 목록
            metadatas: 각 텍스트의 메타데이터 (optional)
            **kwargs: 추가 인자

        Returns:
            생성된 document ID 목록

        Raises:
            ValueError: texts와 metadatas의 길이가 다를 경우
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> ids = await vectorstore.aadd_texts(
            ...     texts=["text1", "text2"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}]
            ... )
        """
        texts_list = list(texts)

        if metadatas is None:
            metadatas = [{} for _ in texts_list]
        elif len(metadatas) != len(texts_list):
            raise ValueError("metadatas must have same length as texts")

        if self._use_builtin_embedding:
            # Seahorse 내장 임베딩 사용
            return await self._aadd_texts_with_builtin_embedding(texts_list, metadatas)
        else:
            # 외부 임베딩 사용
            return await self._aadd_texts_with_external_embedding(texts_list, metadatas)

    async def asimilarity_search(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        retrieval_mode: SearchMode = SearchMode.HYBRID,
        hybrid_config: Optional[HybridSearchConfig] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """비동기로 자연어 쿼리로 유사 문서 검색.

        Dense, Sparse, Hybrid 검색 모드를 지원합니다.

        Args:
            query: 검색 쿼리 (자연어)
            k: 반환할 문서 수 (기본: 4)
            filter: 메타데이터 필터 (optional)
            retrieval_mode: 검색 모드 (기본: HYBRID)
            hybrid_config: 검색 설정 (optional)
            **kwargs: 추가 인자 (ef_search 등, 하위 호환성)

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> docs = await vectorstore.asimilarity_search("machine learning", k=5)
        """
        docs_and_scores = await self.asimilarity_search_with_score(
            query,
            k=k,
            filter=filter,
            retrieval_mode=retrieval_mode,
            hybrid_config=hybrid_config,
            **kwargs,
        )
        return [doc for doc, _ in docs_and_scores]

    async def asimilarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        retrieval_mode: SearchMode = SearchMode.HYBRID,
        hybrid_config: Optional[HybridSearchConfig] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """비동기로 유사도 점수와 함께 문서 검색.

        Dense, Sparse, Hybrid 검색 모드를 지원합니다.

        Args:
            query: 검색 쿼리
            k: 반환할 문서 수
            filter: 메타데이터 필터
            retrieval_mode: 검색 모드 (기본: HYBRID)
            hybrid_config: 검색 설정 (optional)
            **kwargs: 추가 인자 (ef_search 등, 하위 호환성)

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # HybridSearchConfig 구성
        if hybrid_config is None:
            hybrid_config = HybridSearchConfig()

        # kwargs에서 ef_search 추출하여 config에 적용 (하위 호환성)
        if "ef_search" in kwargs and hybrid_config.dense is not None:
            hybrid_config = HybridSearchConfig(
                dense=DenseSearchConfig(
                    column=hybrid_config.dense.column,
                    ef_search=kwargs["ef_search"],
                ),
                sparse=hybrid_config.sparse,
                fusion=hybrid_config.fusion,
            )

        # 컬럼명 설정
        if hybrid_config.dense is not None:
            hybrid_config = HybridSearchConfig(
                dense=DenseSearchConfig(
                    column=self._dense_column,
                    ef_search=hybrid_config.dense.ef_search,
                ),
                sparse=(
                    SparseSearchConfig(
                        column=self._sparse_column,
                        k=hybrid_config.sparse.k if hybrid_config.sparse else 1.2,
                        b=hybrid_config.sparse.b if hybrid_config.sparse else 0.75,
                    )
                    if hybrid_config.sparse
                    else SparseSearchConfig(column=self._sparse_column)
                ),
                fusion=hybrid_config.fusion,
            )

        # 외부 임베딩 사용 시 query vector 생성
        query_vector: Optional[List[float]] = None
        if not self._use_builtin_embedding and self._embedding is not None:
            # Dense 검색이 필요한 모드에서만 외부 임베딩으로 query vector 생성
            if retrieval_mode in (SearchMode.DENSE, SearchMode.HYBRID):
                query_vector = self._embedding.embed_query(query)
                # 차원 검증
                if len(query_vector) != self.dimension:
                    raise SeahorseDimensionMismatchError(
                        expected=self.dimension,
                        actual=len(query_vector),
                    )

        # 통합 검색 API 호출 (비동기)
        results = await self._client.asearch(
            query_text=query,  # Sparse 검색에 사용 (내장 임베딩)
            query_vector=query_vector,  # Dense 검색에 사용 (외부 임베딩)
            top_k=k,
            search_mode=retrieval_mode,
            config=hybrid_config,
            filter_sql=filter_sql,
        )

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )

            # 검색 모드에 따라 score 필드 선택
            if retrieval_mode == SearchMode.DENSE:
                score = item.get("distance", 0.0)
            else:  # SPARSE, HYBRID
                score = item.get("score", 0.0)

            documents.append((doc, score))

        return documents

    async def asimilarity_search_by_vector(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Document]:
        """비동기로 벡터로 직접 검색.

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            유사한 Document 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        docs_and_scores = await self.asimilarity_search_by_vector_with_score(
            embedding, k=k, filter=filter, **kwargs
        )
        return [doc for doc, _ in docs_and_scores]

    async def asimilarity_search_by_vector_with_score(
        self,
        embedding: List[float],
        k: int = 4,
        filter: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> List[Tuple[Document, float]]:
        """비동기로 벡터로 직접 검색 (점수 포함).

        Args:
            embedding: 검색할 벡터
            k: 반환할 문서 수
            filter: 메타데이터 필터
            **kwargs: 추가 인자

        Returns:
            (Document, score) 튜플 목록

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        # 필터를 SQL WHERE 절로 변환
        filter_sql = convert_filter_to_sql(filter) if filter else None

        # ef_search 파라미터 추출
        ef_search = kwargs.get("ef_search", min(k * 2, 500))

        # projection 설정
        projection = "id, text, metadata, distance"

        # Vector search API 호출
        results_list = await self._client.avector_search(
            index_name=self._index_name,
            query_vectors=[embedding],
            top_k=k,
            ef_search=ef_search,
            projection=projection,
            filter_sql=filter_sql,
        )

        # 첫 번째 resultset 사용
        results = results_list[0] if results_list else []

        # 결과를 Document로 변환
        documents = []
        for item in results:
            # metadata 파싱
            try:
                metadata = json.loads(item["metadata"])
            except (json.JSONDecodeError, KeyError):
                metadata = {}

            doc = Document(
                page_content=item["text"],
                metadata=metadata,
            )
            score = item["distance"]
            documents.append((doc, score))

        return documents

    async def adelete(
        self,
        ids: Optional[List[str]] = None,
        filter: Optional[Dict[str, Any]] = None,
        delete_all: bool = False,
        **kwargs: Any,
    ) -> Optional[bool]:
        """비동기로 문서 삭제.

        Args:
            ids: 삭제할 document ID 목록
            filter: 메타데이터 필터 (ids와 함께 사용 불가)
            delete_all: 전체 삭제 여부 (기본값: False, 주의 필요!)
            **kwargs: 추가 인자

        Returns:
            성공 여부 (True: 삭제 성공, None: 조건 없음)

        Raises:
            SeahorseAPIError: API 호출 실패
            ValueError: 잘못된 파라미터 조합

        Examples:
            >>> # ID로 삭제
            >>> success = await vectorstore.adelete(ids=["doc1_id", "doc2_id"])
            >>>
            >>> # 필터로 삭제
            >>> success = await vectorstore.adelete(filter={"source": "test"})
            >>>
            >>> # 전체 삭제 (주의!)
            >>> success = await vectorstore.adelete(delete_all=True)

        Warning:
            delete_all=True 사용 시 테이블의 모든 데이터가 삭제됩니다.
            운영 환경에서는 매우 신중하게 사용해야 합니다.
        """
        # 파라미터 유효성 검증
        param_count = sum([ids is not None, filter is not None, delete_all])
        if param_count > 1:
            raise ValueError("ids, filter, delete_all 중 하나만 사용할 수 있습니다")

        if param_count == 0:
            # 아무 조건도 제공되지 않음
            raise ValueError(
                "삭제 조건을 지정해야 합니다. ids, filter, 또는 delete_all=True 중 하나를 제공하세요"
            )

        if ids:
            # SQL IN 절 생성
            ids_quoted = [f"'{id}'" for id in ids]
            delete_condition = f"id IN ({', '.join(ids_quoted)})"
        elif filter:
            # 메타데이터 필터를 SQL WHERE 절로 변환
            delete_condition = convert_filter_to_sql(filter)
        elif delete_all:
            # 전체 삭제 (delete_condition 없음)
            delete_condition = None
        else:
            # 이 경로는 도달하지 않아야 함 (위에서 검증됨)
            return None

        # Delete API 호출 (v2에서는 성공 시 빈 객체 반환)
        await self._client.adelete_data(delete_condition=delete_condition)

        # 예외 없이 완료되면 성공으로 간주
        return True

    @classmethod
    def from_texts(
        cls,
        texts: List[str],
        embedding: Optional[Embeddings] = None,
        metadatas: Optional[List[Dict[str, Any]]] = None,
        **kwargs: Any,
    ) -> "SeahorseVectorStore":
        """텍스트 목록으로부터 VectorStore 생성.

        Args:
            texts: 텍스트 목록
            embedding: Embeddings instance (optional)
            metadatas: 메타데이터 목록 (optional)
            **kwargs: SeahorseVectorStore 초기화 인자 (api_key, base_url 등)

        Returns:
            SeahorseVectorStore instance

        Raises:
            ValueError: 필수 인자 누락 (api_key, base_url)

        Examples:
            >>> vectorstore = SeahorseVectorStore.from_texts(
            ...     texts=["Hello", "World"],
            ...     metadatas=[{"source": "doc1"}, {"source": "doc2"}],
            ...     api_key="your-api-key",
            ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai"
            ... )
        """
        # embedding 인자를 kwargs에 추가
        if embedding is not None:
            kwargs["embedding"] = embedding
            kwargs["use_builtin_embedding"] = False

        # VectorStore 생성
        vectorstore = cls(**kwargs)

        # 텍스트 추가
        vectorstore.add_texts(texts, metadatas=metadatas)

        return vectorstore

    def _add_texts_with_builtin_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """Seahorse 내장 임베딩으로 텍스트 추가.

        Dense와 Sparse 임베딩을 동시에 생성합니다.
        모든 배치 삽입 완료 후 Active Set Flush를 실행하여
        데이터를 즉시 검색 가능하게 합니다.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=EMBEDDING_API_MAX_ROWS
        ):
            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata in zip(text_batch, metadata_batch):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                    }
                )

            # API 호출 (Dense + Sparse 동시 임베딩)
            self._client.insert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column=self._dense_column,
                sparse_column=self._sparse_column,
            )

            doc_ids.extend(batch_ids)

        # Active Set Flush로 즉시 검색 가능하게 함
        self._flush_active_set()

        return doc_ids

    async def _aadd_texts_with_builtin_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """비동기로 Seahorse 내장 임베딩으로 텍스트 추가.

        Dense와 Sparse 임베딩을 동시에 생성합니다.
        모든 배치 삽입 완료 후 Active Set Flush를 실행하여
        데이터를 즉시 검색 가능하게 합니다.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록
        """
        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=EMBEDDING_API_MAX_ROWS
        ):
            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata in zip(text_batch, metadata_batch):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                    }
                )

            # API 호출 (비동기, Dense + Sparse 동시 임베딩)
            await self._client.ainsert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column=self._dense_column,
                sparse_column=self._sparse_column,
            )

            doc_ids.extend(batch_ids)

        # Active Set Flush로 즉시 검색 가능하게 함
        await self._aflush_active_set()

        return doc_ids

    def _add_texts_with_external_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """외부 임베딩으로 텍스트 추가.

        Dense 임베딩은 외부 임베딩으로 생성하고,
        Sparse 임베딩은 Seahorse 내장 임베딩으로 생성합니다.
        모든 배치 삽입 완료 후 Active Set Flush를 실행하여
        데이터를 즉시 검색 가능하게 합니다.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록

        Raises:
            SeahorseDimensionMismatchError: 외부 임베딩 차원이 테이블 스키마와 불일치하는 경우
        """
        if self._embedding is None:
            raise ValueError("Embedding instance is None")

        # Dense 임베딩 생성 (외부 임베딩)
        embeddings = self._embedding.embed_documents(texts)

        # 차원 검증
        if embeddings and len(embeddings[0]) != self.dimension:
            raise SeahorseDimensionMismatchError(
                expected=self.dimension,
                actual=len(embeddings[0]),
            )

        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=EMBEDDING_API_MAX_ROWS
        ):
            # 해당 배치의 임베딩 추출
            start_idx = texts.index(text_batch[0])
            end_idx = start_idx + len(text_batch)
            embedding_batch = embeddings[start_idx:end_idx]

            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata, embedding in zip(
                text_batch, metadata_batch, embedding_batch
            ):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                # Dense 벡터는 외부 임베딩 값을 직접 포함
                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                        self._dense_column: embedding,  # 외부 임베딩 값
                    }
                )

            # API 호출: Dense는 데이터에 포함, Sparse만 내장 임베딩 생성
            self._client.insert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column=self._dense_column,
                sparse_column=self._sparse_column,
                include_dense=False,  # Dense는 이미 데이터에 포함됨
            )

            doc_ids.extend(batch_ids)

        # Active Set Flush로 즉시 검색 가능하게 함
        self._flush_active_set()

        return doc_ids

    async def _aadd_texts_with_external_embedding(
        self,
        texts: List[str],
        metadatas: List[Dict[str, Any]],
    ) -> List[str]:
        """비동기로 외부 임베딩으로 텍스트 추가.

        Dense 임베딩은 외부 임베딩으로 생성하고,
        Sparse 임베딩은 Seahorse 내장 임베딩으로 생성합니다.
        모든 배치 삽입 완료 후 Active Set Flush를 실행하여
        데이터를 즉시 검색 가능하게 합니다.

        Args:
            texts: 텍스트 목록
            metadatas: 메타데이터 목록

        Returns:
            생성된 document ID 목록

        Raises:
            SeahorseDimensionMismatchError: 외부 임베딩 차원이 테이블 스키마와 불일치하는 경우
        """
        if self._embedding is None:
            raise ValueError("Embedding instance is None")

        # Dense 임베딩 생성 (동기 - 대부분의 LangChain Embeddings는 동기)
        # TODO: 추후 aembed_documents가 지원되는 경우 사용
        embeddings = self._embedding.embed_documents(texts)

        # 차원 검증
        if embeddings and len(embeddings[0]) != self.dimension:
            raise SeahorseDimensionMismatchError(
                expected=self.dimension,
                actual=len(embeddings[0]),
            )

        doc_ids = []

        # 배치 처리
        for text_batch, metadata_batch in batch_texts(
            texts, metadatas, batch_size=EMBEDDING_API_MAX_ROWS
        ):
            # 해당 배치의 임베딩 추출
            start_idx = texts.index(text_batch[0])
            end_idx = start_idx + len(text_batch)
            embedding_batch = embeddings[start_idx:end_idx]

            # Primary Key 생성 및 데이터 준비
            data = []
            batch_ids = []

            for text, metadata, embedding in zip(
                text_batch, metadata_batch, embedding_batch
            ):
                doc_id = generate_pk(text, chunk_id=0)
                batch_ids.append(doc_id)

                # Dense 벡터는 외부 임베딩 값을 직접 포함
                data.append(
                    {
                        "id": doc_id,
                        "text": text,
                        "metadata": json.dumps(metadata, ensure_ascii=False),
                        self._dense_column: embedding,  # 외부 임베딩 값
                    }
                )

            # API 호출: Dense는 데이터에 포함, Sparse만 내장 임베딩 생성 (비동기)
            await self._client.ainsert_with_embedding(
                data=data,
                embedding_source="text",
                dense_column=self._dense_column,
                sparse_column=self._sparse_column,
                include_dense=False,  # Dense는 이미 데이터에 포함됨
            )

            doc_ids.extend(batch_ids)

        # Active Set Flush로 즉시 검색 가능하게 함
        await self._aflush_active_set()

        return doc_ids

    def _flush_active_set(self) -> None:
        """Active Set Flush를 실행하여 삽입된 데이터를 즉시 검색 가능하게 함.

        reader-sync 모드로 호출하여 reader 노드들이
        flush된 데이터를 조회할 수 있도록 합니다.
        flush 실패 시에도 삽입 자체는 성공으로 처리하며,
        경고 로그만 남깁니다.
        """
        try:
            self._client._active_set_flush(sync_mode="reader-sync")
        except Exception as e:
            logger.warning(
                "Active Set Flush failed: %s. "
                "Inserted data may not be immediately searchable.",
                e,
            )

    async def _aflush_active_set(self) -> None:
        """비동기로 Active Set Flush를 실행하여 삽입된 데이터를 즉시 검색 가능하게 함.

        reader-sync 모드로 호출하여 reader 노드들이
        flush된 데이터를 조회할 수 있도록 합니다.
        flush 실패 시에도 삽입 자체는 성공으로 처리하며,
        경고 로그만 남깁니다.
        """
        try:
            await self._client._aactive_set_flush(sync_mode="reader-sync")
        except Exception as e:
            logger.warning(
                "Active Set Flush failed: %s. "
                "Inserted data may not be immediately searchable.",
                e,
            )
