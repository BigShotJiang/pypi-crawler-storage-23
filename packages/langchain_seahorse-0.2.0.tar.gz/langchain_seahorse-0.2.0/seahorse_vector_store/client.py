"""Low-level Seahorse API client."""

import logging
import time
import warnings
from typing import Any, Dict, List, Optional

import httpx

from .exceptions import (
    SeahorseAPIError,
    SeahorseAuthenticationError,
    SeahorseRateLimitError,
    SeahorseValidationError,
)
from .models import (
    DenseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
    SearchMode,
    SparseSearchConfig,
)
from .utils import EMBEDDING_API_MAX_ROWS, EMBEDDING_SOURCE_MAX_BYTES

logger = logging.getLogger(__name__)


class SeahorseClient:
    """Low-level Seahorse API client.

    CoralResponse 언래핑, 에러 처리, 재시도 로직 등을 담당합니다.

    Args:
        base_url: Seahorse API base URL (테이블별 고유 URL)
        api_key: Seahorse API key
        timeout: Request timeout (초 단위, 기본: 30.0)
        max_retries: 최대 재시도 횟수 (기본: 3)

    Attributes:
        _base_url: API base URL
        _api_key: API key
        _timeout: Request timeout
        _max_retries: Maximum retry attempts
        _session: httpx.Client instance
        _async_session: httpx.AsyncClient instance

    Examples:
        >>> client = SeahorseClient(
        ...     base_url="https://455fe13765664952bed80e7c22dd3436.api.seahorse.dnotitia.ai",
        ...     api_key="your-api-key"
        ... )
        >>> result = client.insert_with_embedding(
        ...     data=[{"id": "doc1", "text": "Hello"}],
        ...     embedding_source="text",
        ...     embedding_target="dense_vector"
        ... )
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = 30.0,
        max_retries: int = 3,
    ) -> None:
        """Initialize Seahorse API client.

        Args:
            base_url: API base URL
            api_key: API key
            timeout: Request timeout (초 단위)
            max_retries: 최대 재시도 횟수
        """
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout
        self._max_retries = max_retries

        # HTTP 클라이언트 설정
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        }

        self._session = httpx.Client(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )

        self._async_session = httpx.AsyncClient(
            headers=headers,
            timeout=timeout,
            follow_redirects=True,
        )

    def __del__(self) -> None:
        """Clean up resources."""
        if hasattr(self, "_session"):
            self._session.close()
        if hasattr(self, "_async_session"):
            # AsyncClient는 비동기로 닫아야 하지만 __del__에서는 불가능
            # 사용자가 명시적으로 close() 호출하도록 권장
            pass

    def close(self) -> None:
        """동기 세션 종료."""
        self._session.close()

    async def aclose(self) -> None:
        """비동기 세션 종료."""
        await self._async_session.aclose()

    def _validate_insert_with_embedding_request(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str,
    ) -> None:
        """Validate `/v2/data/embedding` request against API limits.

        Args:
            data: Rows to insert
            embedding_source: Field name used as embedding source

        Raises:
            SeahorseValidationError: If the request violates API limits
        """
        if len(data) > EMBEDDING_API_MAX_ROWS:
            raise SeahorseValidationError(
                f"/v2/data/embedding supports up to {EMBEDDING_API_MAX_ROWS} rows "
                f"per request (got {len(data)}). Please batch your inserts."
            )

        for row_idx, row in enumerate(data):
            if not isinstance(row, dict):
                raise SeahorseValidationError(
                    f"Each row in data must be a dict. "
                    f"Row {row_idx} is {type(row).__name__}."
                )

            value = row.get(embedding_source)
            if value is None:
                raise SeahorseValidationError(
                    f"Row {row_idx} is missing embedding_source field "
                    f"'{embedding_source}'."
                )
            if not isinstance(value, str):
                raise SeahorseValidationError(
                    f"Row {row_idx} field '{embedding_source}' must be a string "
                    f"(got {type(value).__name__})."
                )

            value_bytes = len(value.encode("utf-8"))
            if value_bytes > EMBEDDING_SOURCE_MAX_BYTES:
                raise SeahorseValidationError(
                    f"Row {row_idx} field '{embedding_source}' exceeds "
                    f"{EMBEDDING_SOURCE_MAX_BYTES} bytes "
                    f"({value_bytes} bytes). Please chunk or shorten the text."
                )

    async def ainsert_with_embedding(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str = "text",
        dense_column: str = "dense_vector",
        sparse_column: str = "sparse_vector",
        include_dense: bool = True,
    ) -> Dict[str, Any]:
        """데이터 삽입 (비동기, Seahorse 내장 임베딩 사용).

        Dense와 Sparse 임베딩을 생성하여 삽입합니다.
        외부 임베딩 사용 시: data에 dense_column 값을 포함하고 include_dense=False 설정
        Sparse 임베딩은 항상 Seahorse 내장 임베딩으로 생성됩니다.

        POST /v2/data/embedding

        Args:
            data: 삽입할 데이터 목록 (각 항목은 id, text, metadata 포함)
                  외부 임베딩 사용 시 dense_column 값도 포함
            embedding_source: 임베딩 소스 컬럼명 (기본: "text")
            dense_column: Dense 벡터 컬럼명 (기본: "dense_vector")
            sparse_column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
            include_dense: Dense 임베딩 생성 여부 (기본: True)
                           외부 임베딩 사용 시 False로 설정

        Returns:
            삽입 결과 (inserted_row_count, inserted_record_batches, elapsed_time)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        self._validate_insert_with_embedding_request(
            data=data, embedding_source=embedding_source
        )
        embedding_config = []

        if include_dense:
            embedding_config.append(
                {
                    "embedding_target": dense_column,
                    "embedding_type": "dense",
                }
            )

        # Sparse 임베딩은 항상 내장 임베딩으로 생성
        embedding_config.append(
            {
                "embedding_target": sparse_column,
                "embedding_type": "sparse",
            }
        )

        payload = {
            "data": data,
            "embedding_source": embedding_source,
            "embedding_config": embedding_config,
        }

        response = await self._arequest("POST", "/v2/data/embedding", json=payload)
        return self._unwrap_coral_response(response)

    def insert_with_embedding(
        self,
        data: List[Dict[str, Any]],
        embedding_source: str = "text",
        dense_column: str = "dense_vector",
        sparse_column: str = "sparse_vector",
        include_dense: bool = True,
    ) -> Dict[str, Any]:
        """데이터 삽입 (Seahorse 내장 임베딩 사용).

        Dense와 Sparse 임베딩을 생성하여 삽입합니다.
        외부 임베딩 사용 시: data에 dense_column 값을 포함하고 include_dense=False 설정
        Sparse 임베딩은 항상 Seahorse 내장 임베딩으로 생성됩니다.

        POST /v2/data/embedding

        Args:
            data: 삽입할 데이터 목록 (각 항목은 id, text, metadata 포함)
                  외부 임베딩 사용 시 dense_column 값도 포함
            embedding_source: 임베딩 소스 컬럼명 (기본: "text")
            dense_column: Dense 벡터 컬럼명 (기본: "dense_vector")
            sparse_column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
            include_dense: Dense 임베딩 생성 여부 (기본: True)
                           외부 임베딩 사용 시 False로 설정

        Returns:
            삽입 결과 (inserted_row_count, inserted_record_batches, elapsed_time)

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> # Dense + Sparse 동시 삽입 (내장 임베딩)
            >>> client.insert_with_embedding(
            ...     data=[{"id": "1", "text": "Hello", "metadata": "{}"}]
            ... )
            >>>
            >>> # 외부 임베딩 사용 (Dense는 데이터에 포함, Sparse는 내장 임베딩)
            >>> client.insert_with_embedding(
            ...     data=[{
            ...         "id": "1",
            ...         "text": "Hello",
            ...         "metadata": "{}",
            ...         "dense_vector": [0.1, 0.2, ...]  # 외부 임베딩 값
            ...     }],
            ...     include_dense=False  # dense는 이미 데이터에 포함됨
            ... )
        """
        self._validate_insert_with_embedding_request(
            data=data, embedding_source=embedding_source
        )
        embedding_config = []

        if include_dense:
            embedding_config.append(
                {
                    "embedding_target": dense_column,
                    "embedding_type": "dense",
                }
            )

        # Sparse 임베딩은 항상 내장 임베딩으로 생성
        embedding_config.append(
            {
                "embedding_target": sparse_column,
                "embedding_type": "sparse",
            }
        )

        payload = {
            "data": data,
            "embedding_source": embedding_source,
            "embedding_config": embedding_config,
        }

        response = self._request("POST", "/v2/data/embedding", json=payload)
        return self._unwrap_coral_response(response)

    async def asemantic_search(
        self,
        query: str,
        top_k: int,
        index_name: str,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """시맨틱 검색 (비동기, 자연어 쿼리).

        .. deprecated::
            Use `asearch()` with `SearchMode.DENSE` instead.

        POST /v2/data/search (dense + text 쿼리)

        Args:
            query: 검색 쿼리 (자연어)
            top_k: 반환할 결과 수
            index_name: 벡터 인덱스 컬럼명 (기본: "embedding")
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional, 기본: 모든 컬럼)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 text, metadata, distance 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        warnings.warn(
            "asemantic_search is deprecated. "
            "Use asearch() with SearchMode.DENSE instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # v2 통합 검색 API payload 구성
        dense_config: Dict[str, Any] = {
            "column": index_name,
            "text": [query],
        }

        if ef_search is not None:
            dense_config["parameters"] = {"ef_search": ef_search}

        payload: Dict[str, Any] = {
            "search_mode": "dense",
            "top_k": top_k,
            "dense": dense_config,
        }

        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = await self._arequest("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset의 data 반환
        return result["data"][0]

    def semantic_search(
        self,
        query: str,
        top_k: int,
        index_name: str,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """시맨틱 검색 (자연어 쿼리).

        .. deprecated::
            Use `search()` with `SearchMode.DENSE` instead.

        POST /v2/data/search (dense + text 쿼리)

        Args:
            query: 검색 쿼리 (자연어)
            top_k: 반환할 결과 수
            index_name: 벡터 인덱스 컬럼명 (기본: "embedding")
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional, 기본: 모든 컬럼)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 text, metadata, distance 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        warnings.warn(
            "semantic_search is deprecated. "
            "Use search() with SearchMode.DENSE instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # v2 통합 검색 API payload 구성
        dense_config: Dict[str, Any] = {
            "column": index_name,
            "text": [query],
        }

        if ef_search is not None:
            dense_config["parameters"] = {"ef_search": ef_search}

        payload: Dict[str, Any] = {
            "search_mode": "dense",
            "top_k": top_k,
            "dense": dense_config,
        }

        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = self._request("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset의 data 반환
        return result["data"][0]

    async def avector_search(
        self,
        index_name: str,
        query_vectors: List[List[float]],
        top_k: int,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """벡터 검색 (비동기, 벡터로 직접 검색).

        .. deprecated::
            Use `asearch()` with `query_vector` and `SearchMode.DENSE` instead.

        POST /v2/data/search (dense + vector 쿼리)

        Args:
            index_name: 벡터 인덱스 컬럼명
            query_vectors: 검색할 벡터 리스트 (여러 벡터 동시 검색 가능)
            top_k: 반환할 결과 수
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 벡터당 하나의 resultset)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        warnings.warn(
            "avector_search is deprecated. "
            "Use asearch() with query_vector and SearchMode.DENSE instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # v2 통합 검색 API payload 구성
        dense_config: Dict[str, Any] = {
            "column": index_name,
            "vector": query_vectors,
        }

        if ef_search is not None:
            dense_config["parameters"] = {"ef_search": ef_search}

        payload: Dict[str, Any] = {
            "search_mode": "dense",
            "top_k": top_k,
            "dense": dense_config,
        }

        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = await self._arequest("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        return result["data"]

    def vector_search(
        self,
        index_name: str,
        query_vectors: List[List[float]],
        top_k: int,
        ef_search: Optional[int] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[List[Dict[str, Any]]]:
        """벡터 검색 (벡터로 직접 검색).

        .. deprecated::
            Use `search()` with `query_vector` and `SearchMode.DENSE` instead.

        POST /v2/data/search (dense + vector 쿼리)

        Args:
            index_name: 벡터 인덱스 컬럼명
            query_vectors: 검색할 벡터 리스트 (여러 벡터 동시 검색 가능)
            top_k: 반환할 결과 수
            ef_search: HNSW ef_search 파라미터 (optional)
            projection: 반환할 컬럼 (optional)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 벡터당 하나의 resultset)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        warnings.warn(
            "vector_search is deprecated. "
            "Use search() with query_vector and SearchMode.DENSE instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        # v2 통합 검색 API payload 구성
        dense_config: Dict[str, Any] = {
            "column": index_name,
            "vector": query_vectors,
        }

        if ef_search is not None:
            dense_config["parameters"] = {"ef_search": ef_search}

        payload: Dict[str, Any] = {
            "search_mode": "dense",
            "top_k": top_k,
            "dense": dense_config,
        }

        if projection is not None:
            payload["projection"] = projection
        if filter_sql is not None:
            payload["filter"] = filter_sql

        response = self._request("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        return result["data"]

    async def adelete_data(
        self,
        delete_condition: Optional[str] = None,
    ) -> Dict[str, Any]:
        """데이터 삭제 (비동기).

        POST /v2/data/delete

        Args:
            delete_condition: SQL WHERE 절 (삭제 조건).
                None이면 전체 데이터 삭제 (주의!)

        Returns:
            빈 객체 {} (v2에서는 deleted_row_count 미반환)

        Raises:
            SeahorseAPIError: API 호출 실패

        Warning:
            delete_condition이 None이면 테이블의 전체 데이터가 삭제됩니다!
            운영 환경에서는 매우 신중하게 사용해야 합니다.

        Examples:
            >>> # 조건부 삭제
            >>> await client.adelete_data(delete_condition="id = '1000'")
            >>>
            >>> # 전체 삭제 (주의!)
            >>> await client.adelete_data(delete_condition=None)
        """
        payload: Dict[str, Any] = {}
        if delete_condition is not None:
            payload["delete_condition"] = delete_condition

        response = await self._arequest("POST", "/v2/data/delete", json=payload)
        return self._unwrap_coral_response(response)

    def delete_data(
        self,
        delete_condition: Optional[str] = None,
    ) -> Dict[str, Any]:
        """데이터 삭제.

        POST /v2/data/delete

        Args:
            delete_condition: SQL WHERE 절 (삭제 조건).
                None이면 전체 데이터 삭제 (주의!)

        Returns:
            빈 객체 {} (v2에서는 deleted_row_count 미반환)

        Raises:
            SeahorseAPIError: API 호출 실패

        Warning:
            delete_condition이 None이면 테이블의 전체 데이터가 삭제됩니다!
            운영 환경에서는 매우 신중하게 사용해야 합니다.

        Examples:
            >>> # 조건부 삭제
            >>> client.delete_data(delete_condition="id = '1000'")
            >>>
            >>> # 전체 삭제 (주의!)
            >>> client.delete_data(delete_condition=None)
        """
        payload: Dict[str, Any] = {}
        if delete_condition is not None:
            payload["delete_condition"] = delete_condition

        response = self._request("POST", "/v2/data/delete", json=payload)
        return self._unwrap_coral_response(response)

    def get_table_schema(self) -> Dict[str, Any]:
        """테이블 스키마 조회.

        GET /v2/data/schema

        Returns:
            테이블 스키마 정보 (table_name, columns, indexes, primary_key 등)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        response = self._request("GET", "/v2/data/schema")
        return self._unwrap_coral_response(response)

    async def aget_table_schema(self) -> Dict[str, Any]:
        """테이블 스키마 조회 (비동기).

        GET /v2/data/schema

        Returns:
            테이블 스키마 정보 (table_name, columns, indexes, primary_key 등)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        response = await self._arequest("GET", "/v2/data/schema")
        return self._unwrap_coral_response(response)

    def get_indexed_row_count(self) -> Dict[str, Any]:
        """인덱싱된 행 개수 조회.

        벡터 인덱스 별로 색인 완료된 개수와 총 행 수를 반환합니다.

        GET /v2/data/indexed-row-count

        Returns:
            인덱싱 정보 (total_row_count, indexed_counts[])
            - total_row_count: 테이블의 총 행 수
            - indexed_counts: 인덱스별 색인 정보 배열
              - index_name: 인덱스명
              - index_type: 인덱스 타입 (hnsw, inverted 등)
              - indexed_row_count: 색인 완료된 행 수

        Raises:
            SeahorseAPIError: API 호출 실패

        Examples:
            >>> result = client.get_indexed_row_count()
            >>> print(result["total_row_count"])
            1000
            >>> for idx in result["indexed_counts"]:
            ...     print(f"{idx['index_name']}: {idx['indexed_row_count']}")
        """
        response = self._request("GET", "/v2/data/indexed-row-count")
        return self._unwrap_coral_response(response)

    async def aget_indexed_row_count(self) -> Dict[str, Any]:
        """인덱싱된 행 개수 조회 (비동기).

        벡터 인덱스 별로 색인 완료된 개수와 총 행 수를 반환합니다.

        GET /v2/data/indexed-row-count

        Returns:
            인덱싱 정보 (total_row_count, indexed_counts[])

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        response = await self._arequest("GET", "/v2/data/indexed-row-count")
        return self._unwrap_coral_response(response)

    def search(
        self,
        query_text: Optional[str] = None,
        query_vector: Optional[List[float]] = None,
        top_k: int = 4,
        search_mode: SearchMode = SearchMode.HYBRID,
        config: Optional[HybridSearchConfig] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """통합 검색 API.

        모든 검색 모드(Dense/Sparse/Hybrid)를 지원하는 통합 검색 메서드입니다.
        text 쿼리 또는 vector 쿼리 중 하나를 사용할 수 있습니다.

        POST /v2/data/search

        Args:
            query_text: 검색 쿼리 (자연어) - 내장 임베딩 사용 시
            query_vector: 검색 쿼리 벡터 - 외부 임베딩 사용 시 (Dense 검색용)
            top_k: 반환할 결과 수 (기본: 4)
            search_mode: 검색 모드 (기본: HYBRID)
            config: 검색 설정 (optional, 기본값 사용 시 None)
            projection: 반환할 컬럼 (optional)
                        기본값: "id, text, metadata, score" (Sparse/Hybrid)
                                "id, text, metadata, distance" (Dense)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 id, text, metadata, distance/score 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
            ValueError: query_text와 query_vector 둘 다 없거나,
                       Sparse/Hybrid 검색 시 query_text 없는 경우

        Note:
            - query_vector 사용 시: Dense 검색은 vector로, Sparse 검색은 text로 수행
            - Hybrid 검색에서 query_vector 사용 시, Sparse 부분은 query_text 필요

        Examples:
            >>> # Text 쿼리 (내장 임베딩)
            >>> results = client.search(query_text="machine learning", top_k=5)
            >>>
            >>> # Vector 쿼리 (외부 임베딩) - Dense only
            >>> results = client.search(
            ...     query_vector=[0.1, 0.2, ...],
            ...     top_k=5,
            ...     search_mode=SearchMode.DENSE
            ... )
            >>>
            >>> # Hybrid with external embedding
            >>> results = client.search(
            ...     query_text="machine learning",
            ...     query_vector=[0.1, 0.2, ...],
            ...     top_k=5,
            ...     search_mode=SearchMode.HYBRID
            ... )
        """
        # 입력 검증
        if query_text is None and query_vector is None:
            raise ValueError("Either query_text or query_vector must be provided")

        # 기본 설정 적용
        if config is None:
            config = HybridSearchConfig()

        # API 페이로드 구성
        payload = self._build_search_payload(
            query_text=query_text,
            query_vector=query_vector,
            top_k=top_k,
            search_mode=search_mode,
            config=config,
            projection=projection,
            filter_sql=filter_sql,
        )

        response = self._request("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset 반환
        return result["data"][0] if result["data"] else []

    async def asearch(
        self,
        query_text: Optional[str] = None,
        query_vector: Optional[List[float]] = None,
        top_k: int = 4,
        search_mode: SearchMode = SearchMode.HYBRID,
        config: Optional[HybridSearchConfig] = None,
        projection: Optional[str] = None,
        filter_sql: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """통합 검색 API (비동기).

        모든 검색 모드(Dense/Sparse/Hybrid)를 지원하는 통합 검색 메서드입니다.

        POST /v2/data/search

        Args:
            query_text: 검색 쿼리 (자연어) - 내장 임베딩 사용 시
            query_vector: 검색 쿼리 벡터 - 외부 임베딩 사용 시 (Dense 검색용)
            top_k: 반환할 결과 수 (기본: 4)
            search_mode: 검색 모드 (기본: HYBRID)
            config: 검색 설정 (optional, 기본값 사용 시 None)
            projection: 반환할 컬럼 (optional)
                        기본값: "id, text, metadata, score" (Sparse/Hybrid)
                                "id, text, metadata, distance" (Dense)
            filter_sql: SQL WHERE 절 (optional)

        Returns:
            검색 결과 리스트 (각 항목은 id, text, metadata, distance/score 포함)

        Raises:
            SeahorseAPIError: API 호출 실패
            ValueError: 입력 검증 실패
        """
        # 입력 검증
        if query_text is None and query_vector is None:
            raise ValueError("Either query_text or query_vector must be provided")

        # 기본 설정 적용
        if config is None:
            config = HybridSearchConfig()

        # API 페이로드 구성
        payload = self._build_search_payload(
            query_text=query_text,
            query_vector=query_vector,
            top_k=top_k,
            search_mode=search_mode,
            config=config,
            projection=projection,
            filter_sql=filter_sql,
        )

        response = await self._arequest("POST", "/v2/data/search", json=payload)
        result = self._unwrap_coral_response(response)

        # 첫 번째 resultset 반환
        return result["data"][0] if result["data"] else []

    def _build_search_payload(
        self,
        query_text: Optional[str],
        query_vector: Optional[List[float]],
        top_k: int,
        search_mode: SearchMode,
        config: HybridSearchConfig,
        projection: Optional[str],
        filter_sql: Optional[str],
    ) -> Dict[str, Any]:
        """검색 API 페이로드 구성.

        Args:
            query_text: 텍스트 쿼리 (내장 임베딩 사용 시)
            query_vector: 벡터 쿼리 (외부 임베딩 사용 시, Dense만)
            top_k: 반환할 결과 수
            search_mode: 검색 모드
            config: 검색 설정
            projection: 반환할 컬럼
            filter_sql: SQL WHERE 절

        Returns:
            API 요청 페이로드

        Raises:
            ValueError: Sparse/Hybrid 검색 시 query_text 없는 경우
        """
        payload: Dict[str, Any] = {
            "search_mode": search_mode.value,
            "top_k": top_k,
        }

        # Dense 설정 (DENSE, HYBRID 모드에서 사용)
        if search_mode in (SearchMode.DENSE, SearchMode.HYBRID):
            dense_config = config.dense or DenseSearchConfig()
            dense_payload: Dict[str, Any] = {
                "column": dense_config.column,
            }

            # 외부 임베딩 사용 시 vector로, 아니면 text로 검색
            if query_vector is not None:
                dense_payload["vector"] = [query_vector]  # API는 2D 배열 형태로 받음
            elif query_text is not None:
                dense_payload["text"] = [query_text]
            else:
                raise ValueError("Dense search requires query_text or query_vector")

            if dense_config.ef_search is not None:
                dense_payload["parameters"] = {"ef_search": dense_config.ef_search}
            payload["dense"] = dense_payload

        # Sparse 설정 (SPARSE, HYBRID 모드에서 사용)
        # Sparse는 항상 text 쿼리 사용 (외부 임베딩 미지원)
        if search_mode in (SearchMode.SPARSE, SearchMode.HYBRID):
            sparse_config = config.sparse or SparseSearchConfig()

            # Sparse 검색은 반드시 text 쿼리 필요
            if query_text is None:
                raise ValueError(
                    f"Sparse search requires query_text. "
                    f"search_mode={search_mode.value} cannot be used with "
                    f"query_vector only."
                )

            sparse_payload: Dict[str, Any] = {
                "column": sparse_config.column,
                "text": [query_text],  # Sparse는 항상 text 사용
                "parameters": {
                    "k": sparse_config.k,
                    "b": sparse_config.b,
                },
            }
            payload["sparse"] = sparse_payload

        # Fusion 설정 (HYBRID 모드에서만 사용)
        if search_mode == SearchMode.HYBRID:
            fusion_config = config.fusion or FusionConfig()
            payload["fusion"] = {
                "type": fusion_config.type,
                "parameters": {
                    "k": fusion_config.k,
                    "alpha": fusion_config.alpha,
                },
            }

        # Projection 설정 (검색 모드에 따라 다른 score 필드)
        if projection is not None:
            payload["projection"] = projection
        else:
            # 기본 projection
            if search_mode == SearchMode.DENSE:
                payload["projection"] = "id, text, metadata, distance"
            else:  # SPARSE, HYBRID
                payload["projection"] = "id, text, metadata, score"

        # Filter 설정
        if filter_sql is not None:
            payload["filter"] = filter_sql

        return payload

    async def ainsert_jsonl(
        self,
        jsonl_data: str,
        reader_batch_size: int = 1024,
    ) -> Dict[str, Any]:
        """JSONL 형식으로 데이터 삽입 (비동기, 외부 임베딩 사용 시).

        POST /v2/data

        Args:
            jsonl_data: JSONL 형식 데이터 (각 줄은 JSON 객체)
            reader_batch_size: 배치 삽입 크기 (기본: 1024)

        Returns:
            삽입 결과

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        headers = {"Content-Type": "text/plain"}
        params = {"reader_batch_size": reader_batch_size}

        response = await self._arequest(
            "POST",
            "/v2/data",
            data=jsonl_data,
            headers=headers,
            params=params,
        )
        return self._unwrap_coral_response(response)

    def insert_jsonl(
        self,
        jsonl_data: str,
        reader_batch_size: int = 1024,
    ) -> Dict[str, Any]:
        """JSONL 형식으로 데이터 삽입 (외부 임베딩 사용 시).

        POST /v2/data

        Args:
            jsonl_data: JSONL 형식 데이터 (각 줄은 JSON 객체)
            reader_batch_size: 배치 삽입 크기 (기본: 1024)

        Returns:
            삽입 결과

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        headers = {"Content-Type": "text/plain"}
        params = {"reader_batch_size": reader_batch_size}

        response = self._request(
            "POST",
            "/v2/data",
            data=jsonl_data,
            headers=headers,
            params=params,
        )
        return self._unwrap_coral_response(response)

    def _active_set_flush(
        self,
        sync_mode: str = "reader-sync",
        segment_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Active Set Flush 실행 (비공개).

        삽입된 데이터를 즉시 검색 가능하게 만들기 위해
        Active Set을 플러시합니다.

        POST /v2/data/active-set-flush

        Args:
            sync_mode: 동기화 모드
                - "async": flush 요청을 대기열에 넣고 즉시 반환
                - "writer-sync": writer 노드가 AS를 S3에 업로드 확인
                - "reader-sync": reader 노드들이 flush된 데이터를 조회 가능
            segment_ids: flush할 세그먼트 ID 목록 (optional).
                생략하면 모든 세그먼트가 플러시됩니다.

        Returns:
            flush 결과 (flushed, failed, skipped 세그먼트 목록)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "sync_mode": sync_mode,
        }

        if segment_ids is not None:
            payload["segment_ids"] = segment_ids

        response = self._request("POST", "/v2/data/active-set-flush", json=payload)
        return self._unwrap_coral_response(response)

    async def _aactive_set_flush(
        self,
        sync_mode: str = "reader-sync",
        segment_ids: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Active Set Flush 실행 (비동기, 비공개).

        삽입된 데이터를 즉시 검색 가능하게 만들기 위해
        Active Set을 플러시합니다.

        POST /v2/data/active-set-flush

        Args:
            sync_mode: 동기화 모드
                - "async": flush 요청을 대기열에 넣고 즉시 반환
                - "writer-sync": writer 노드가 AS를 S3에 업로드 확인
                - "reader-sync": reader 노드들이 flush된 데이터를 조회 가능
            segment_ids: flush할 세그먼트 ID 목록 (optional).
                생략하면 모든 세그먼트가 플러시됩니다.

        Returns:
            flush 결과 (flushed, failed, skipped 세그먼트 목록)

        Raises:
            SeahorseAPIError: API 호출 실패
        """
        payload: Dict[str, Any] = {
            "sync_mode": sync_mode,
        }

        if segment_ids is not None:
            payload["segment_ids"] = segment_ids

        response = await self._arequest(
            "POST", "/v2/data/active-set-flush", json=payload
        )
        return self._unwrap_coral_response(response)

    async def _arequest(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """비동기 HTTP 요청 (재시도 로직 포함).

        Args:
            method: HTTP 메서드 (GET, POST 등)
            path: API 경로
            **kwargs: httpx.request에 전달할 추가 인자

        Returns:
            HTTP 응답

        Raises:
            SeahorseAPIError: API 호출 실패
            SeahorseAuthenticationError: 인증 실패
            SeahorseRateLimitError: Rate limit 초과
        """
        import asyncio

        url = f"{self._base_url}{path}"

        last_exception: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                response = await self._async_session.request(method, url, **kwargs)

                # 재시도 가능한 에러인지 확인
                if response.status_code in [408, 429, 500, 502, 503, 504]:
                    if attempt < self._max_retries - 1:
                        # 지수 백오프
                        delay = 2**attempt
                        await asyncio.sleep(delay)
                        continue

                # 인증 에러 처리
                if response.status_code in [401, 403]:
                    raise SeahorseAuthenticationError(
                        status_code=response.status_code,
                        error_message=f"Authentication failed: {response.text}",
                    )

                # Rate limit 에러 처리
                if response.status_code == 429:
                    raise SeahorseRateLimitError(
                        status_code=429,
                        error_message="Rate limit exceeded",
                    )

                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                if e.response.status_code not in [408, 429, 500, 502, 503, 504]:
                    # 재시도 불가능한 에러
                    raise SeahorseAPIError(
                        status_code=e.response.status_code,
                        error_message=str(e),
                    )
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e

        # 모든 재시도 실패
        if last_exception:
            raise SeahorseAPIError(
                status_code=500,
                error_message=f"Request failed after {self._max_retries} retries: {last_exception}",
            )

        # 이 코드는 실행되지 않아야 함
        raise SeahorseAPIError(
            status_code=500,
            error_message="Unexpected error in request handling",
        )

    def _request(
        self,
        method: str,
        path: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """HTTP 요청 (재시도 로직 포함).

        Args:
            method: HTTP 메서드 (GET, POST 등)
            path: API 경로
            **kwargs: httpx.request에 전달할 추가 인자

        Returns:
            HTTP 응답

        Raises:
            SeahorseAPIError: API 호출 실패
            SeahorseAuthenticationError: 인증 실패
            SeahorseRateLimitError: Rate limit 초과
        """
        url = f"{self._base_url}{path}"

        last_exception: Optional[Exception] = None
        for attempt in range(self._max_retries):
            try:
                response = self._session.request(method, url, **kwargs)

                # 재시도 가능한 에러인지 확인
                if response.status_code in [408, 429, 500, 502, 503, 504]:
                    if attempt < self._max_retries - 1:
                        # 지수 백오프
                        delay = 2**attempt
                        time.sleep(delay)
                        continue

                # 인증 에러 처리
                if response.status_code in [401, 403]:
                    raise SeahorseAuthenticationError(
                        status_code=response.status_code,
                        error_message=f"Authentication failed: {response.text}",
                    )

                # Rate limit 에러 처리
                if response.status_code == 429:
                    raise SeahorseRateLimitError(
                        status_code=429,
                        error_message="Rate limit exceeded",
                    )

                response.raise_for_status()
                return response

            except httpx.HTTPStatusError as e:
                if e.response.status_code not in [408, 429, 500, 502, 503, 504]:
                    # 재시도 불가능한 에러
                    raise SeahorseAPIError(
                        status_code=e.response.status_code,
                        error_message=str(e),
                    )
                last_exception = e
            except httpx.RequestError as e:
                last_exception = e

        # 모든 재시도 실패
        if last_exception:
            raise SeahorseAPIError(
                status_code=500,
                error_message=f"Request failed after {self._max_retries} retries: {last_exception}",
            )

        # 이 코드는 실행되지 않아야 함
        raise SeahorseAPIError(
            status_code=500,
            error_message="Unexpected error in request handling",
        )

    def _unwrap_coral_response(self, response: httpx.Response) -> Any:
        """CoralResponse 언래핑.

        Args:
            response: HTTP 응답

        Returns:
            CoralResponse의 data 필드

        Raises:
            SeahorseAPIError: API 에러 응답
        """
        data = response.json()

        if not data.get("success"):
            # 에러 응답
            exception = data.get("exception", {})
            error_code = exception.get("error_code")
            error_message = exception.get("error_message", "Unknown error")

            status_code = data.get("code", response.status_code)

            # 인증 에러
            if status_code in [401, 403]:
                raise SeahorseAuthenticationError(
                    status_code=status_code,
                    error_code=error_code,
                    error_message=error_message,
                )

            # Rate limit 에러
            if status_code == 429:
                raise SeahorseRateLimitError(
                    status_code=status_code,
                    error_code=error_code,
                    error_message=error_message,
                )

            # 일반 API 에러
            raise SeahorseAPIError(
                status_code=status_code,
                error_code=error_code,
                error_message=error_message,
            )

        return data.get("data")
