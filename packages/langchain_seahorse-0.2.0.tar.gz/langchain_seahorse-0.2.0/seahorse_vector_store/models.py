"""Seahorse VectorStore 모델 및 타입 정의.

이 모듈은 검색 모드, 검색 설정 등의 데이터 클래스를 정의합니다.
"""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class SearchMode(str, Enum):
    """검색 모드 enum.

    Attributes:
        DENSE: Dense 벡터 검색 (semantic search)
        SPARSE: Sparse 벡터 검색 (BM25 기반)
        HYBRID: Dense + Sparse 결합 검색 (RRF fusion)

    Examples:
        >>> from seahorse_vector_store import SearchMode
        >>> mode = SearchMode.HYBRID
        >>> print(mode.value)
        'hybrid'
    """

    DENSE = "dense"
    SPARSE = "sparse"
    HYBRID = "hybrid"


@dataclass
class DenseSearchConfig:
    """Dense 검색 설정.

    HNSW 기반 Dense 벡터 검색의 파라미터를 설정합니다.

    Attributes:
        column: Dense 벡터 컬럼명 (기본: "dense_vector")
        ef_search: HNSW ef_search 파라미터 (클수록 정확하지만 느림)

    Examples:
        >>> config = DenseSearchConfig(ef_search=200)
        >>> config = DenseSearchConfig(column="my_dense_vector", ef_search=100)
    """

    column: str = "dense_vector"
    ef_search: Optional[int] = None


@dataclass
class SparseSearchConfig:
    """Sparse 검색 설정 (BM25 파라미터).

    BM25 기반 Sparse 벡터 검색의 파라미터를 설정합니다.

    Attributes:
        column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
        k: BM25 k 파라미터 - 단어 빈도 가중치 (기본: 1.2)
           높은 값(>1.2): 단어 빈도의 영향 증가
           낮은 값(<1.2): 단어 빈도의 영향 감소
        b: BM25 b 파라미터 - 문서 길이 정규화 (0~1, 기본: 0.75)
           0: 문서 길이 정규화 없음
           1: 완전한 문서 길이 정규화

    Examples:
        >>> config = SparseSearchConfig(k=1.5, b=0.8)
        >>> config = SparseSearchConfig()  # 기본값 사용
    """

    column: str = "sparse_vector"
    k: float = 1.2
    b: float = 0.75


@dataclass
class FusionConfig:
    """Hybrid 검색 Fusion 설정 (RRF).

    Reciprocal Rank Fusion 알고리즘의 파라미터를 설정합니다.
    RRF Score = Σ(1 / (k + rank))

    Attributes:
        type: Fusion 알고리즘 타입 (현재 "rrf"만 지원)
        k: RRF k 파라미터 (기본: 60)
        alpha: Dense 가중치 (0.0~1.0, 기본: 0.5)
               Sparse 가중치는 자동으로 (1 - alpha)

    Examples:
        >>> # Dense 70%, Sparse 30%
        >>> config = FusionConfig(alpha=0.7)
        >>> # 기본값 (50:50)
        >>> config = FusionConfig()
    """

    type: str = "rrf"
    k: int = 60
    alpha: float = 0.5


@dataclass
class HybridSearchConfig:
    """Hybrid 검색 전체 설정.

    Dense, Sparse, Fusion 설정을 조합하여 Hybrid 검색을 구성합니다.
    각 설정은 Optional이며, 제공하지 않으면 기본값이 사용됩니다.

    Attributes:
        dense: Dense 검색 설정
        sparse: Sparse 검색 설정
        fusion: Fusion 설정 (RRF)

    Examples:
        >>> # 커스텀 Hybrid 검색 설정
        >>> config = HybridSearchConfig(
        ...     dense=DenseSearchConfig(ef_search=200),
        ...     sparse=SparseSearchConfig(k=1.5, b=0.8),
        ...     fusion=FusionConfig(alpha=0.7, k=60)
        ... )
        >>>
        >>> # 기본값 사용
        >>> config = HybridSearchConfig()
        >>>
        >>> # 일부만 커스텀
        >>> config = HybridSearchConfig(
        ...     fusion=FusionConfig(alpha=0.8)
        ... )
    """

    dense: Optional[DenseSearchConfig] = None
    sparse: Optional[SparseSearchConfig] = None
    fusion: Optional[FusionConfig] = None

    def __post_init__(self) -> None:
        """기본값 설정."""
        if self.dense is None:
            self.dense = DenseSearchConfig()
        if self.sparse is None:
            self.sparse = SparseSearchConfig()
        if self.fusion is None:
            self.fusion = FusionConfig()
