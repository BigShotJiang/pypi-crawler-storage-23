# 🔍 Sparse/Hybrid Search 기능 추가 작업 계획서

**작성일**: 2025-12-26  
**버전**: v1.2  
**상태**: 승인 대기

---

## 📋 개요

Seahorse VectorStore SDK에 Sparse Search와 Hybrid Search 기능을 추가합니다. API 명세(gw-api-specification-v2.md)를 기반으로 구현하며, Qdrant 스타일의 `SearchMode` enum을 통해 검색 모드를 선택할 수 있도록 합니다.

---

## 🎯 목표

1. **테이블 스키마 지원**: `dense_vector` + `sparse_vector` 듀얼 벡터 컬럼
2. **데이터 삽입**: Dense + Sparse 임베딩 자동 생성 (Seahorse 내장 임베딩)
3. **검색 모드**: Hybrid(기본) / Dense / Sparse 선택 가능
4. **Hybrid Search 파라미터**: RRF fusion 설정 (alpha, k) 지원

---

## ✅ 결정 사항

| 항목 | 결정 |
|------|------|
| Score 정규화 | 그대로 두고 문서화 (Dense: distance 작을수록 유사, Sparse/Hybrid: score 클수록 유사) |
| 외부 임베딩 | Dense는 외부/내장 모두 지원, Sparse는 내장만 지원 |
| 기본 검색 모드 | `HYBRID` |

---

## 📁 파일 변경 범위

| 파일 | 변경 내용 |
|------|----------|
| `seahorse_vector_store/__init__.py` | `SearchMode`, Config 클래스들, `SeahorseDimensionMismatchError` export 추가 |
| `seahorse_vector_store/models.py` | **신규** - `SearchMode` enum, Config dataclass들 |
| `seahorse_vector_store/client.py` | `search()` 메서드 추가 (text/vector 쿼리 지원), 기존 메서드 정리 |
| `seahorse_vector_store/vectorstores.py` | 검색 메서드에 `retrieval_mode` 파라미터 추가, 외부 임베딩 검색 지원 |
| `seahorse_vector_store/exceptions.py` | `SeahorseDimensionMismatchError` 클래스 추가 (또는 수정) |
| `tests/unit/test_search_modes.py` | **신규** - 검색 모드 관련 단위 테스트 |
| `tests/unit/test_external_embedding_search.py` | **신규** - 외부 임베딩 검색 단위 테스트 |
| `tests/integration/test_hybrid_search.py` | **신규** - Hybrid 검색 통합 테스트 |
| `tests/integration/test_external_embedding_search.py` | **신규** - 외부 임베딩 검색 통합 테스트 |
| `docs/TECHNICAL_SPEC.md` | Hybrid Search 관련 문서 업데이트 |

---

## 🔧 상세 작업 내용

### 1단계: 모델/타입 정의 (models.py 신규 생성)

API v2 명세와 일치하는 구조로 Config 클래스를 정의합니다.

```python
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional


class SearchMode(str, Enum):
    """검색 모드 enum.
    
    Attributes:
        DENSE: Dense 벡터 검색 (semantic search)
        SPARSE: Sparse 벡터 검색 (BM25 기반)
        HYBRID: Dense + Sparse 결합 검색 (RRF fusion)
    """
    DENSE = "dense"
    SPARSE = "sparse"
    HYBRID = "hybrid"


@dataclass
class DenseSearchConfig:
    """Dense 검색 설정.
    
    Attributes:
        column: Dense 벡터 컬럼명 (기본: "dense_vector")
        ef_search: HNSW ef_search 파라미터 (클수록 정확하지만 느림)
    
    Examples:
        >>> config = DenseSearchConfig(ef_search=200)
    """
    column: str = "dense_vector"
    ef_search: Optional[int] = None


@dataclass 
class SparseSearchConfig:
    """Sparse 검색 설정 (BM25 파라미터).
    
    Attributes:
        column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
        k: BM25 k 파라미터 - 단어 빈도 가중치 (기본: 1.2)
        b: BM25 b 파라미터 - 문서 길이 정규화 (0~1, 기본: 0.75)
    
    Examples:
        >>> config = SparseSearchConfig(k=1.5, b=0.8)
    """
    column: str = "sparse_vector"
    k: float = 1.2
    b: float = 0.75


@dataclass
class FusionConfig:
    """Hybrid 검색 Fusion 설정 (RRF).
    
    Attributes:
        type: Fusion 알고리즘 타입 (현재 "rrf"만 지원)
        k: RRF k 파라미터 (기본: 60)
        alpha: Dense 가중치 (0.0~1.0, 기본: 0.5). Sparse 가중치 = 1 - alpha
    
    Examples:
        >>> # Dense 70%, Sparse 30%
        >>> config = FusionConfig(alpha=0.7)
    """
    type: str = "rrf"
    k: int = 60
    alpha: float = 0.5


@dataclass
class HybridSearchConfig:
    """Hybrid 검색 전체 설정.
    
    Dense, Sparse, Fusion 설정을 조합하여 Hybrid 검색을 구성합니다.
    각 설정은 Optional이며, 제공하지 않으면 기본값이 사용됩니다.
    
    Attributes:
        dense: Dense 검색 설정
        sparse: Sparse 검색 설정
        fusion: Fusion 설정 (RRF)
    
    Examples:
        >>> # 커스텀 Hybrid 검색 설정
        >>> config = HybridSearchConfig(
        ...     dense=DenseSearchConfig(ef_search=200),
        ...     sparse=SparseSearchConfig(k=1.5, b=0.8),
        ...     fusion=FusionConfig(alpha=0.7, k=60)
        ... )
        >>>
        >>> # 기본값 사용
        >>> config = HybridSearchConfig()
    """
    dense: Optional[DenseSearchConfig] = None
    sparse: Optional[SparseSearchConfig] = None
    fusion: Optional[FusionConfig] = None
    
    def __post_init__(self) -> None:
        """기본값 설정."""
        if self.dense is None:
            self.dense = DenseSearchConfig()
        if self.sparse is None:
            self.sparse = SparseSearchConfig()
        if self.fusion is None:
            self.fusion = FusionConfig()
```

### 2단계: Client 수정 (client.py)

기존 `semantic_search`, `vector_search` 메서드를 유지하되, 새로운 `search()` 메서드를 추가합니다. 검색 파라미터는 Config 객체로 전달받습니다.

**핵심 변경**: 외부 임베딩 사용 시 `query_vector`를 받아 text 대신 vector로 API 호출

```python
from .models import (
    SearchMode,
    DenseSearchConfig,
    SparseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
)


def search(
    self,
    query_text: Optional[str] = None,
    query_vector: Optional[List[float]] = None,
    top_k: int = 4,
    search_mode: SearchMode = SearchMode.HYBRID,
    config: Optional[HybridSearchConfig] = None,
    projection: Optional[str] = None,
    filter_sql: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """통합 검색 API.
    
    모든 검색 모드(Dense/Sparse/Hybrid)를 지원하는 통합 검색 메서드입니다.
    text 쿼리 또는 vector 쿼리 중 하나를 사용할 수 있습니다.
    
    Args:
        query_text: 검색 쿼리 (자연어) - 내장 임베딩 사용 시
        query_vector: 검색 쿼리 벡터 - 외부 임베딩 사용 시 (Dense 검색용)
        top_k: 반환할 결과 수 (기본: 4)
        search_mode: 검색 모드 (기본: HYBRID)
        config: 검색 설정 (optional, 기본값 사용 시 None)
        projection: 반환할 컬럼 (optional)
        filter_sql: SQL WHERE 절 (optional)
    
    Returns:
        검색 결과 리스트 (각 항목은 text, metadata, distance/score 포함)
    
    Raises:
        SeahorseAPIError: API 호출 실패
        ValueError: query_text와 query_vector 둘 다 없거나 둘 다 있는 경우
    
    Note:
        - query_vector 사용 시: Dense 검색은 vector로, Sparse 검색은 text로 수행
        - Hybrid 검색에서 query_vector 사용 시, Sparse 부분은 원본 텍스트가 필요하므로
          VectorStore에서 원본 쿼리 텍스트도 함께 전달해야 함
    
    Examples:
        >>> # Text 쿼리 (내장 임베딩)
        >>> results = client.search(query_text="machine learning", top_k=5)
        >>>
        >>> # Vector 쿼리 (외부 임베딩)
        >>> results = client.search(
        ...     query_vector=[0.1, 0.2, ...],  # 테이블 스키마의 dimension과 동일
        ...     top_k=5,
        ...     search_mode=SearchMode.DENSE
        ... )
    """
    # 입력 검증
    if query_text is None and query_vector is None:
        raise ValueError("Either query_text or query_vector must be provided")
    
    # 기본 설정 적용
    if config is None:
        config = HybridSearchConfig()
    
    # API 페이로드 구성
    payload = self._build_search_payload(
        query_text=query_text,
        query_vector=query_vector,
        top_k=top_k,
        search_mode=search_mode,
        config=config,
        projection=projection,
        filter_sql=filter_sql,
    )
    
    response = self._request("POST", "/v2/data/search", json=payload)
    result = self._unwrap_coral_response(response)
    
    # 첫 번째 resultset 반환
    return result["data"][0] if result["data"] else []


def _build_search_payload(
    self,
    query_text: Optional[str],
    query_vector: Optional[List[float]],
    top_k: int,
    search_mode: SearchMode,
    config: HybridSearchConfig,
    projection: Optional[str],
    filter_sql: Optional[str],
) -> Dict[str, Any]:
    """검색 API 페이로드 구성.
    
    Args:
        query_text: 텍스트 쿼리 (내장 임베딩 사용 시)
        query_vector: 벡터 쿼리 (외부 임베딩 사용 시, Dense만)
        top_k: 반환할 결과 수
        search_mode: 검색 모드
        config: 검색 설정
        projection: 반환할 컬럼
        filter_sql: SQL WHERE 절
    
    Returns:
        API 요청 페이로드
    """
    payload: Dict[str, Any] = {
        "search_mode": search_mode.value,
        "top_k": top_k,
    }
    
    # Dense 설정 (DENSE, HYBRID 모드에서 사용)
    if search_mode in (SearchMode.DENSE, SearchMode.HYBRID):
        dense_config = config.dense or DenseSearchConfig()
        dense_payload: Dict[str, Any] = {
            "column": dense_config.column,
        }
        
        # 외부 임베딩 사용 시 vector로, 아니면 text로 검색
        if query_vector is not None:
            dense_payload["vector"] = [query_vector]  # API는 2D 배열 형태로 받음
        else:
            dense_payload["text"] = [query_text]
        
        if dense_config.ef_search is not None:
            dense_payload["parameters"] = {"ef_search": dense_config.ef_search}
        payload["dense"] = dense_payload
    
    # Sparse 설정 (SPARSE, HYBRID 모드에서 사용)
    # ⚠️ Sparse는 항상 text 쿼리 사용 (외부 임베딩 미지원)
    if search_mode in (SearchMode.SPARSE, SearchMode.HYBRID):
        sparse_config = config.sparse or SparseSearchConfig()
        
        # Sparse 검색은 반드시 text 쿼리 필요
        if query_text is None:
            raise ValueError(
                f"Sparse search requires query_text. "
                f"search_mode={search_mode.value} cannot be used with query_vector only."
            )
        
        sparse_payload: Dict[str, Any] = {
            "column": sparse_config.column,
            "text": [query_text],  # Sparse는 항상 text 사용
            "parameters": {
                "k": sparse_config.k,
                "b": sparse_config.b,
            }
        }
        payload["sparse"] = sparse_payload
    
    # Fusion 설정 (HYBRID 모드에서만 사용)
    if search_mode == SearchMode.HYBRID:
        fusion_config = config.fusion or FusionConfig()
        payload["fusion"] = {
            "type": fusion_config.type,
            "parameters": {
                "k": fusion_config.k,
                "alpha": fusion_config.alpha,
            }
        }
    
    # Projection 설정 (검색 모드에 따라 다른 score 필드)
    if projection is not None:
        payload["projection"] = projection
    else:
        # 기본 projection
        if search_mode == SearchMode.DENSE:
            payload["projection"] = "id, text, metadata, distance"
        else:  # SPARSE, HYBRID
            payload["projection"] = "id, text, metadata, score"
    
    # Filter 설정
    if filter_sql is not None:
        payload["filter"] = filter_sql
    
    return payload
```

**비동기 버전 (`asearch`)도 동일하게 구현**

### 3단계: VectorStore 수정 (vectorstores.py)

검색 메서드에 `retrieval_mode` 파라미터를 추가하고, **외부 임베딩 사용 시 쿼리 벡터화 및 차원 검증** 로직을 추가합니다.

```python
from .models import (
    SearchMode,
    DenseSearchConfig,
    SparseSearchConfig,
    FusionConfig,
    HybridSearchConfig,
)
from .exceptions import SeahorseDimensionMismatchError, SeahorseSchemaError

# 테이블 스키마의 Dense 벡터 차원은 초기화 시 GET /v2/data/schema로 조회
# self.dimension 속성에 저장됨


def similarity_search(
    self,
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    *,
    retrieval_mode: SearchMode = SearchMode.HYBRID,
    search_config: Optional[HybridSearchConfig] = None,
    **kwargs: Any,
) -> List[Document]:
    """자연어 쿼리로 유사 문서 검색.
    
    Args:
        query: 검색 쿼리 (자연어)
        k: 반환할 문서 수 (기본: 4)
        filter: 메타데이터 필터 (optional)
        retrieval_mode: 검색 모드 (기본: HYBRID)
        search_config: 검색 설정 (optional)
        **kwargs: 추가 인자
    
    Returns:
        유사한 Document 목록
    
    Raises:
        SeahorseAPIError: API 호출 실패
        SeahorseDimensionMismatchError: 외부 임베딩 벡터 차원이 테이블 스키마와 불일치하는 경우
    
    Examples:
        >>> # Hybrid 검색 (기본)
        >>> docs = vectorstore.similarity_search("machine learning", k=5)
        >>>
        >>> # Dense 검색으로 전환
        >>> docs = vectorstore.similarity_search(
        ...     "machine learning",
        ...     k=5,
        ...     retrieval_mode=SearchMode.DENSE
        ... )
        >>>
        >>> # Sparse 검색으로 전환
        >>> docs = vectorstore.similarity_search(
        ...     "machine learning",
        ...     k=5,
        ...     retrieval_mode=SearchMode.SPARSE
        ... )
        >>>
        >>> # 커스텀 Hybrid 검색
        >>> config = HybridSearchConfig(
        ...     dense=DenseSearchConfig(ef_search=200),
        ...     fusion=FusionConfig(alpha=0.7)
        ... )
        >>> docs = vectorstore.similarity_search(
        ...     "machine learning",
        ...     k=5,
        ...     search_config=config
        ... )
    """
    docs_and_scores = self.similarity_search_with_score(
        query,
        k=k,
        filter=filter,
        retrieval_mode=retrieval_mode,
        search_config=search_config,
        **kwargs,
    )
    return [doc for doc, _ in docs_and_scores]


def similarity_search_with_score(
    self,
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    *,
    retrieval_mode: SearchMode = SearchMode.HYBRID,
    search_config: Optional[HybridSearchConfig] = None,
    **kwargs: Any,
) -> List[Tuple[Document, float]]:
    """유사도 점수와 함께 문서 검색.
    
    Args:
        query: 검색 쿼리
        k: 반환할 문서 수
        filter: 메타데이터 필터
        retrieval_mode: 검색 모드 (기본: HYBRID)
        search_config: 검색 설정 (optional)
        **kwargs: 추가 인자
    
    Returns:
        (Document, score) 튜플 목록
        
        Note:
            - Dense 모드: score는 distance 값 (작을수록 유사)
            - Sparse/Hybrid 모드: score는 relevance 값 (클수록 유사)
    
    Raises:
        SeahorseAPIError: API 호출 실패
        SeahorseDimensionMismatchError: 외부 임베딩 벡터 차원이 테이블 스키마와 불일치하는 경우
    """
    # 필터를 SQL WHERE 절로 변환
    filter_sql = convert_filter_to_sql(filter) if filter else None
    
    # 외부 임베딩 사용 여부에 따라 쿼리 처리
    query_text: Optional[str] = query
    query_vector: Optional[List[float]] = None
    
    if not self._use_builtin_embedding:
        # 외부 임베딩 사용: 쿼리를 벡터로 변환
        query_vector = self._embed_query_with_validation(query)
        
        # Sparse/Hybrid 검색에는 text도 필요하므로 query_text 유지
        # Dense 검색에서만 query_text를 None으로 설정 가능
        if retrieval_mode == SearchMode.DENSE:
            query_text = None
    
    # Client search 호출
    results = self._client.search(
        query_text=query_text,
        query_vector=query_vector,
        top_k=k,
        search_mode=retrieval_mode,
        config=search_config,
        filter_sql=filter_sql,
    )
    
    # 결과를 Document로 변환
    documents = []
    for item in results:
        try:
            metadata = json.loads(item["metadata"])
        except (json.JSONDecodeError, KeyError):
            metadata = {}
        
        doc = Document(
            page_content=item["text"],
            metadata=metadata,
        )
        
        # 검색 모드에 따라 score 필드 다름
        if retrieval_mode == SearchMode.DENSE:
            score = item.get("distance", 0.0)
        else:
            score = item.get("score", 0.0)
        
        documents.append((doc, score))
    
    return documents


def _embed_query_with_validation(self, query: str) -> List[float]:
    """외부 임베딩으로 쿼리를 벡터화하고 차원을 검증.
    
    Args:
        query: 검색 쿼리 텍스트
    
    Returns:
        쿼리 임베딩 벡터 (테이블 스키마의 dimension과 동일한 차원)
    
    Raises:
        SeahorseDimensionMismatchError: 벡터 차원이 테이블 스키마와 불일치하는 경우
        ValueError: 임베딩 인스턴스가 없는 경우
    """
    if self._embedding is None:
        raise ValueError("Embedding instance is None")
    
    # 외부 임베딩으로 쿼리 벡터화
    query_vector = self._embedding.embed_query(query)
    
    # 차원 검증 (self.dimension은 초기화 시 스키마에서 조회됨)
    actual_dim = len(query_vector)
    if actual_dim != self.dimension:
        raise SeahorseDimensionMismatchError(
            expected=self.dimension,
            actual=actual_dim,
        )
    
    return query_vector
```

### 3-1단계: 예외 클래스 수정 (exceptions.py)

차원 불일치 예외 클래스가 없다면 추가합니다.

```python
class SeahorseDimensionMismatchError(SeahorseValidationError):
    """벡터 차원 불일치 에러.
    
    외부 임베딩 벡터의 차원이 테이블 스키마와 맞지 않을 때 발생합니다.
    
    Attributes:
        expected: 기대하는 벡터 차원 (스키마에서 조회)
        actual: 실제 벡터 차원
    """
    
    def __init__(self, expected: int, actual: int) -> None:
        self.expected = expected
        self.actual = actual
        super().__init__(
            f"Vector dimension mismatch: expected {expected}, got {actual}"
        )


class SeahorseSchemaError(SeahorseException):
    """스키마 조회 또는 파싱 실패 예외.
    
    테이블 스키마를 조회하거나 dense_vector 컬럼 정보를 찾을 수 없을 때 발생합니다.
    """
    
    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)
```

### 4단계: 데이터 삽입 수정

`insert_with_embedding` 메서드를 수정하여 Dense + Sparse 동시 임베딩을 지원합니다.

```python
# client.py

def insert_with_embedding(
    self,
    data: List[Dict[str, Any]],
    embedding_source: str = "text",
    dense_column: str = "dense_vector",
    sparse_column: str = "sparse_vector",
) -> Dict[str, Any]:
    """데이터 삽입 (Seahorse 내장 임베딩 사용).
    
    Dense와 Sparse 임베딩을 동시에 생성하여 삽입합니다.
    
    POST /v2/data/embedding
    
    Args:
        data: 삽입할 데이터 목록 (각 항목은 id, text, metadata 포함)
        embedding_source: 임베딩 소스 컬럼명 (기본: "text")
        dense_column: Dense 벡터 컬럼명 (기본: "dense_vector")
        sparse_column: Sparse 벡터 컬럼명 (기본: "sparse_vector")
    
    Returns:
        삽입 결과 (inserted_row_count, inserted_record_batches, elapsed_time)
    
    Raises:
        SeahorseAPIError: API 호출 실패
    """
    payload = {
        "data": data,
        "embedding_source": embedding_source,
        "embedding_config": [
            {
                "embedding_target": dense_column,
                "embedding_type": "dense",
            },
            {
                "embedding_target": sparse_column,
                "embedding_type": "sparse",
            },
        ],
    }
    
    response = self._request("POST", "/v2/data/embedding", json=payload)
    return self._unwrap_coral_response(response)
```

### 5단계: 기존 메서드 정리

기존 `semantic_search`, `vector_search` 메서드는 유지하되, 내부에서 `search()` 메서드를 호출하도록 리팩토링하거나 deprecated 마킹합니다.

```python
import warnings

def semantic_search(
    self,
    query: str,
    top_k: int,
    index_name: str,
    ef_search: Optional[int] = None,
    projection: Optional[str] = None,
    filter_sql: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """시맨틱 검색 (자연어 쿼리).
    
    .. deprecated::
        Use `search()` with `SearchMode.DENSE` instead.
    """
    warnings.warn(
        "semantic_search is deprecated. Use search() with SearchMode.DENSE instead.",
        DeprecationWarning,
        stacklevel=2,
    )
    
    config = HybridSearchConfig(
        dense=DenseSearchConfig(column=index_name, ef_search=ef_search)
    )
    
    return self.search(
        query=query,
        top_k=top_k,
        search_mode=SearchMode.DENSE,
        config=config,
        projection=projection,
        filter_sql=filter_sql,
    )
```

---

## 📊 API 응답 차이점

| 검색 모드 | Score 필드 | 값 해석 |
|----------|-----------|--------|
| Dense | `distance` | 작을수록 유사 |
| Sparse | `score` | 클수록 유사 |
| Hybrid | `score` | 클수록 유사 (RRF 결합) |

> ⚠️ **주의**: Dense 검색과 Sparse/Hybrid 검색의 score 방향이 다릅니다. 정규화하지 않고 그대로 반환하므로, 사용 시 검색 모드를 확인하세요.

---

## 🔄 사용 예시

### 기본 사용법

```python
from seahorse_vector_store import SeahorseVectorStore, SearchMode

# VectorStore 초기화
store = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table.api.seahorse.dnotitia.ai"
)

# 1. Hybrid 검색 (기본값)
docs = store.similarity_search("How much money did the robbers steal?", k=3)

# 2. Dense 검색으로 전환
dense_docs = store.similarity_search(
    "How much money did the robbers steal?",
    k=3,
    retrieval_mode=SearchMode.DENSE
)

# 3. Sparse 검색으로 전환
sparse_docs = store.similarity_search(
    "How much money did the robbers steal?",
    k=3,
    retrieval_mode=SearchMode.SPARSE
)
```

### 고급 사용법 (커스텀 설정)

```python
from seahorse_vector_store import (
    SeahorseVectorStore,
    SearchMode,
    HybridSearchConfig,
    DenseSearchConfig,
    SparseSearchConfig,
    FusionConfig,
)

store = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table.api.seahorse.dnotitia.ai"
)

# 커스텀 Hybrid 검색 설정
config = HybridSearchConfig(
    dense=DenseSearchConfig(
        column="dense_vector",
        ef_search=200,
    ),
    sparse=SparseSearchConfig(
        column="sparse_vector",
        k=1.5,
        b=0.8,
    ),
    fusion=FusionConfig(
        type="rrf",
        k=60,
        alpha=0.7,  # Dense 70%, Sparse 30%
    ),
)

docs = store.similarity_search(
    "machine learning algorithms",
    k=5,
    search_config=config,
)

# 점수와 함께 조회
docs_with_scores = store.similarity_search_with_score(
    "machine learning algorithms",
    k=5,
    retrieval_mode=SearchMode.HYBRID,
    search_config=config,
)

for doc, score in docs_with_scores:
    print(f"Score: {score:.4f}, Content: {doc.page_content[:50]}...")
```

### 외부 임베딩 사용 시

외부 임베딩을 사용하면 검색 시 자동으로 쿼리를 벡터화합니다.
- **Dense 검색**: 외부 임베딩으로 생성된 벡터로 검색
- **Sparse 검색**: 텍스트 쿼리로 검색 (Seahorse 내장 임베딩)
- **Hybrid 검색**: Dense는 벡터로, Sparse는 텍스트로 검색

```python
from langchain_openai import OpenAIEmbeddings
from seahorse_vector_store import SeahorseVectorStore, SearchMode
from seahorse_vector_store.exceptions import SeahorseDimensionMismatchError, SeahorseSchemaError

# 외부 임베딩 사용 (Dense만 외부, Sparse는 내장)
# ⚠️ 주의: 임베딩 모델의 출력 차원이 테이블의 dense_vector 차원과 일치해야 함
# 초기화 시 자동으로 GET /v2/data/schema를 호출하여 dimension 속성 설정
store = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table.api.seahorse.dnotitia.ai",
    embedding=OpenAIEmbeddings(model="text-embedding-3-large", dimensions=4096), # dimension은 테이블 벡터 차원과 동일한 값으로 설정해야 함
    use_builtin_embedding=False,
)
# store.dimension으로 테이블의 벡터 차원 확인 가능

# Hybrid 검색 - Dense는 외부 임베딩, Sparse는 내장
# 내부적으로:
#   - Dense: query를 외부 임베딩으로 벡터화 후 vector로 API 호출
#   - Sparse: query를 text로 API 호출 (내장 임베딩)
docs = store.similarity_search("query", k=5, retrieval_mode=SearchMode.HYBRID)

# Dense 검색만 - 외부 임베딩으로 벡터화
docs = store.similarity_search("query", k=5, retrieval_mode=SearchMode.DENSE)

# Sparse 검색만 - 내장 임베딩 (외부 임베딩과 무관)
docs = store.similarity_search("query", k=5, retrieval_mode=SearchMode.SPARSE)

# 벡터 차원 불일치 시 에러 처리
try:
    # 차원이 테이블 스키마와 다른 임베딩 모델 사용 시 에러 발생
    bad_store = SeahorseVectorStore(
        api_key="your-api-key",
        base_url="https://your-table.api.seahorse.dnotitia.ai",
        embedding=OpenAIEmbeddings(model="text-embedding-ada-002"),  # 1536 차원
        use_builtin_embedding=False,
    )
    # 테이블이 4096 차원인 경우, 검색 시 에러 발생
    bad_store.similarity_search("query", k=5)
except SeahorseDimensionMismatchError as e:
    print(f"Error: {e}")
    # Error: Vector dimension mismatch: expected 4096, got 1536
except SeahorseSchemaError as e:
    print(f"Schema Error: {e}")
    # 스키마 조회 실패 시
```

**외부 임베딩 동작 흐름**:

```
SeahorseVectorStore 초기화
    │
    └─ GET /v2/data/schema 호출
        └─ self.dimension = schema.columns[dense_vector].dim (예: 4096)

similarity_search(query="machine learning")
    │
    ├─ use_builtin_embedding=True (기본)
    │   └─ client.search(query_text="machine learning")
    │       └─ API: {"dense": {"text": ["machine learning"]}, ...}
    │
    └─ use_builtin_embedding=False (외부 임베딩)
        ├─ embedding.embed_query(query) → [0.1, 0.2, ..., 0.n]
        ├─ 차원 검증: len(vector) == self.dimension ? OK : Error
        │
        └─ client.search(query_text="machine learning", query_vector=[...])
            └─ API: {"dense": {"vector": [[...]]}, "sparse": {"text": ["machine learning"]}, ...}
```

---

## 📋 테스트 계획

### 단위 테스트 (`tests/unit/test_search_modes.py`)

| 테스트 케이스 | 설명 |
|-------------|------|
| `test_search_mode_enum_values` | SearchMode enum 값 검증 |
| `test_dense_search_config_defaults` | DenseSearchConfig 기본값 검증 |
| `test_sparse_search_config_defaults` | SparseSearchConfig 기본값 검증 |
| `test_fusion_config_defaults` | FusionConfig 기본값 검증 |
| `test_hybrid_search_config_defaults` | HybridSearchConfig 기본값 검증 |
| `test_build_search_payload_dense_text` | Dense 모드 text 쿼리 페이로드 생성 |
| `test_build_search_payload_dense_vector` | Dense 모드 vector 쿼리 페이로드 생성 |
| `test_build_search_payload_sparse` | Sparse 모드 페이로드 생성 검증 |
| `test_build_search_payload_hybrid_text` | Hybrid 모드 text 쿼리 페이로드 생성 |
| `test_build_search_payload_hybrid_vector` | Hybrid 모드 vector 쿼리 페이로드 생성 (Dense: vector, Sparse: text) |
| `test_search_sparse_requires_text` | Sparse 검색 시 text 필수 검증 |

### 단위 테스트 (`tests/unit/test_external_embedding_search.py`)

| 테스트 케이스 | 설명 |
|-------------|------|
| `test_embed_query_with_validation_success` | 정상 차원 (스키마와 일치) 벡터 검증 통과 |
| `test_embed_query_with_validation_dimension_error` | 잘못된 차원 벡터 시 에러 발생 |
| `test_dimension_from_schema` | 스키마에서 dimension 정상 조회 검증 |
| `test_schema_error_on_init` | 스키마 조회 실패 시 에러 발생 |
| `test_similarity_search_with_external_embedding` | 외부 임베딩 사용 시 vector 쿼리 호출 |
| `test_hybrid_search_with_external_embedding` | 외부 임베딩 + Hybrid 검색 (Dense: vector, Sparse: text) |
| `test_dense_search_with_external_embedding` | 외부 임베딩 + Dense 검색 (vector만 사용) |
| `test_sparse_search_with_external_embedding` | 외부 임베딩 + Sparse 검색 (text만 사용) |

### 통합 테스트 (`tests/integration/test_hybrid_search.py`)

| 테스트 케이스 | 설명 |
|-------------|------|
| `test_hybrid_search_default` | 기본 Hybrid 검색 |
| `test_dense_search_mode` | Dense 모드 검색 |
| `test_sparse_search_mode` | Sparse 모드 검색 |
| `test_hybrid_search_custom_config` | 커스텀 설정 Hybrid 검색 |
| `test_search_with_filter` | 필터와 함께 검색 |
| `test_score_field_by_mode` | 모드별 score 필드 검증 |

### 통합 테스트 (`tests/integration/test_external_embedding_search.py`)

| 테스트 케이스 | 설명 |
|-------------|------|
| `test_external_embedding_dense_search` | 외부 임베딩 Dense 검색 (실제 API 호출) |
| `test_external_embedding_hybrid_search` | 외부 임베딩 Hybrid 검색 (실제 API 호출) |
| `test_dimension_mismatch_error` | 차원 불일치 시 에러 발생 검증 |

---

## ⏰ 예상 작업 일정

| 단계 | 작업 내용 | 예상 시간 |
|-----|----------|----------|
| 1 | 모델/타입 정의 (models.py) | 0.5시간 |
| 2 | 예외 클래스 추가 (exceptions.py) | 0.25시간 |
| 3 | Client search() 메서드 구현 (text/vector 쿼리 지원) | 1.5시간 |
| 4 | 기존 메서드 deprecated 처리 | 0.5시간 |
| 5 | VectorStore 검색 메서드 수정 + 외부 임베딩 지원 | 1.5시간 |
| 6 | 데이터 삽입 로직 수정 | 0.5시간 |
| 7 | 단위 테스트 작성 (검색 모드 + 외부 임베딩) | 1.5시간 |
| 8 | 통합 테스트 작성 (Hybrid + 외부 임베딩) | 1.5시간 |
| 9 | 문서 업데이트 | 0.5시간 |
| **총계** | | **~8.25시간** |

---

## 🔄 호환성 고려사항

1. **하위 호환성 유지**: 
   - 기존 `similarity_search()` 호출은 그대로 작동 (Hybrid 기본값)
   - 기존 `semantic_search`, `vector_search` 메서드는 deprecated 마킹 후 유지

2. **외부 임베딩 사용자**: 
   - Dense는 외부/내장 모두 지원
   - Sparse는 Seahorse 내장만 지원 (자동 적용)
   - **검색 시 자동으로 쿼리 벡터화** (Dense 부분만)
   - **벡터 차원 검증**: 테이블 스키마에서 조회한 dimension과 불일치 시 `SeahorseDimensionMismatchError` 발생
   - 인스턴스 초기화 시 `GET /v2/data/schema` API를 호출하여 `dimension` 속성 설정

3. **API 버전**: v2 API (`/v2/data/search`) 사용

4. **검색 모드별 동작**:
   | 임베딩 설정 | Dense 검색 | Sparse 검색 | Hybrid 검색 |
   |-----------|-----------|------------|-------------|
   | 내장 (기본) | text 쿼리 | text 쿼리 | 둘 다 text |
   | 외부 | vector 쿼리 | text 쿼리 | Dense: vector, Sparse: text |

---

## 📝 변경 이력

| 버전 | 날짜 | 변경 내용 |
|-----|------|----------|
| v1.0 | 2025-12-26 | 초안 작성 |
| v1.1 | 2025-12-26 | 피드백 반영: Config 클래스 구조 변경, search() 메서드 방식 변경 |
| v1.2 | 2025-12-26 | 외부 임베딩 검색 지원 추가: query_vector 파라미터, 차원 검증 로직 |
| v1.3 | 2025-12-29 | 차원 검증 로직 변경: 하드코딩 대신 스키마 API에서 조회한 dimension 사용 |

