# API Reference - Seahorse VectorStore

## SeahorseVectorStore

### Constructor

```python
SeahorseVectorStore(
    api_key: str,
    base_url: str,
    embedding: Optional[Embeddings] = None,
    use_builtin_embedding: bool = True,
    dense_column: str = "dense_vector",
    sparse_column: str = "sparse_vector",
    index_name: Optional[str] = None,
    **kwargs: Any,
)
```

**Parameters:**
- `api_key` (str): Seahorse API key
- `base_url` (str): Seahorse API base URL (테이블별 고유 URL)
- `embedding` (Optional[Embeddings]): 외부 LangChain Embeddings instance (optional)
- `use_builtin_embedding` (bool): Seahorse 내장 임베딩 사용 여부 (기본: True)
- `dense_column` (str): Dense 벡터 컬럼명 (기본: "dense_vector")
- `sparse_column` (str): Sparse 벡터 컬럼명 (기본: "sparse_vector")
- `index_name` (Optional[str]): (Deprecated) `dense_column` 호환용 파라미터

**Examples:**
```python
# Built-in embedding
vectorstore = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table-uuid.api.seahorse.dnotitia.ai"
)

# External embedding
from langchain_openai import OpenAIEmbeddings
vectorstore = SeahorseVectorStore(
    api_key="your-api-key",
    base_url="https://your-table-uuid.api.seahorse.dnotitia.ai",
    embedding=OpenAIEmbeddings(),
    use_builtin_embedding=False
)
```

---

## Synchronous Methods

### add_texts()

텍스트를 벡터 저장소에 추가합니다.

```python
def add_texts(
    texts: Iterable[str],
    metadatas: Optional[List[Dict[str, Any]]] = None,
    **kwargs: Any,
) -> List[str]
```

**Parameters:**
- `texts`: 추가할 텍스트 목록
- `metadatas`: 각 텍스트의 메타데이터 (optional)
- `**kwargs`: 추가 인자

**Returns:** 생성된 document ID 목록

**Notes:**
- 삽입 요청은 내부적으로 **최대 50개 row** 단위로 자동 배치 처리됩니다.
- row당 `embedding_source` 텍스트(기본: `text`)가 **32KB(UTF-8 bytes)** 를 초과하면
  `SeahorseValidationError`가 발생할 수 있습니다. 긴 문서는 청크로 나눠서 추가하세요.

**Examples:**
```python
ids = vectorstore.add_texts(
    texts=["Hello", "World"],
    metadatas=[{"source": "doc1"}, {"source": "doc2"}]
)
```

---

### similarity_search()

자연어 쿼리로 유사 문서를 검색합니다.

```python
def similarity_search(
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    retrieval_mode: SearchMode = SearchMode.HYBRID,
    hybrid_config: Optional[HybridSearchConfig] = None,
    **kwargs: Any,
) -> List[Document]
```

**Parameters:**
- `query`: 검색 쿼리 (자연어)
- `k`: 반환할 문서 수 (기본: 4)
- `filter`: 메타데이터 필터 (optional)
- `retrieval_mode`: 검색 모드 (기본: HYBRID)
- `hybrid_config`: 하이브리드 검색 설정 (optional)
- `**kwargs`: 추가 인자 (ef_search 등)

**Returns:** Document 목록

**Examples:**
```python
from seahorse_vector_store import SearchMode

# Hybrid search (default)
docs = vectorstore.similarity_search("machine learning", k=5)

# Dense only search
docs = vectorstore.similarity_search(
    "machine learning", k=5, retrieval_mode=SearchMode.DENSE
)

# Sparse only search (BM25)
docs = vectorstore.similarity_search(
    "machine learning", k=5, retrieval_mode=SearchMode.SPARSE
)

# With filter
docs = vectorstore.similarity_search(
    "AI research",
    k=3,
    filter={"source": "arxiv.pdf"}
)
```

---

### similarity_search_with_score()

유사도 점수와 함께 문서를 검색합니다.

```python
def similarity_search_with_score(
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Tuple[Document, float]]
```

**Parameters:**
- `query`: 검색 쿼리
- `k`: 반환할 문서 수
- `filter`: 메타데이터 필터
- `**kwargs`: 추가 인자

**Returns:** (Document, score) 튜플 목록
- Dense 모드: distance (작을수록 유사)
- Sparse/Hybrid 모드: score (클수록 유사)

**Examples:**
```python
docs_and_scores = vectorstore.similarity_search_with_score(
    "neural networks",
    k=5,
    ef_search=100
)

for doc, score in docs_and_scores:
    print(f"Score: {score:.4f}, Content: {doc.page_content[:50]}")

# With search mode
docs_and_scores = vectorstore.similarity_search_with_score(
    "neural networks",
    k=5,
    retrieval_mode=SearchMode.SPARSE
)
```

---

### similarity_search_by_vector()

벡터로 직접 검색합니다.

```python
def similarity_search_by_vector(
    embedding: List[float],
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Document]
```

**Parameters:**
- `embedding`: 검색할 벡터 (테이블 스키마에 맞는 차원)
- `k`: 반환할 문서 수
- `filter`: 메타데이터 필터
- `**kwargs`: 추가 인자

**Returns:** Document 목록

---

### similarity_search_by_vector_with_score()

벡터로 검색하고 점수를 함께 반환합니다.

```python
def similarity_search_by_vector_with_score(
    embedding: List[float],
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Tuple[Document, float]]
```

---

### delete()

문서를 삭제합니다.

```python
def delete(
    ids: Optional[List[str]] = None,
    filter: Optional[Dict[str, Any]] = None,
    delete_all: bool = False,
    **kwargs: Any,
) -> Optional[bool]
```

**Parameters:**
- `ids`: 삭제할 document ID 목록
- `filter`: 메타데이터 필터 (ids와 함께 사용 불가)
- `delete_all`: 전체 삭제 여부 (기본값: False, 주의!)
- `**kwargs`: 추가 인자

**Returns:** 
- True: 삭제 성공
- None: 조건 없음

**Raises:**
- `ValueError`: 잘못된 파라미터 조합 (ids, filter, delete_all 중 2개 이상 제공)
- `SeahorseAPIError`: API 호출 실패

**Examples:**
```python
# ID로 삭제
success = vectorstore.delete(ids=["doc_id_1", "doc_id_2"])

# 필터로 삭제
success = vectorstore.delete(filter={"source": "test"})

# 전체 삭제 (주의!)
success = vectorstore.delete(delete_all=True)
```

**⚠️ Warning:**
`delete_all=True` 사용 시 테이블의 모든 데이터가 삭제됩니다. 운영 환경에서는 매우 신중하게 사용해야 합니다.

---

### from_texts()

텍스트 목록으로부터 VectorStore를 생성합니다 (클래스 메서드).

```python
@classmethod
def from_texts(
    texts: List[str],
    embedding: Optional[Embeddings] = None,
    metadatas: Optional[List[Dict[str, Any]]] = None,
    **kwargs: Any,
) -> "SeahorseVectorStore"
```

**Parameters:**
- `texts`: 텍스트 목록
- `embedding`: Embeddings instance (optional)
- `metadatas`: 메타데이터 목록 (optional)
- `**kwargs`: SeahorseVectorStore 초기화 인자

**Examples:**
```python
vectorstore = SeahorseVectorStore.from_texts(
    texts=["Hello", "World"],
    api_key="your-api-key",
    base_url="https://your-table-uuid.api.seahorse.dnotitia.ai"
)
```

---

## Async Methods

모든 주요 메서드는 비동기 버전을 제공합니다.

### aadd_texts()

비동기로 텍스트를 추가합니다.

```python
async def aadd_texts(
    texts: Iterable[str],
    metadatas: Optional[List[Dict[str, Any]]] = None,
    **kwargs: Any,
) -> List[str]
```

**Notes:**
- 삽입 요청은 내부적으로 **최대 50개 row** 단위로 자동 배치 처리됩니다.
- row당 `embedding_source` 텍스트(기본: `text`)가 **32KB(UTF-8 bytes)** 를 초과하면
  `SeahorseValidationError`가 발생할 수 있습니다. 긴 문서는 청크로 나눠서 추가하세요.

**Examples:**
```python
ids = await vectorstore.aadd_texts(
    texts=["Hello", "World"],
    metadatas=[{"source": "doc1"}, {"source": "doc2"}]
)
```

---

### asimilarity_search()

비동기로 유사 문서를 검색합니다.

```python
async def asimilarity_search(
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Document]
```

---

### asimilarity_search_with_score()

비동기로 점수와 함께 검색합니다.

```python
async def asimilarity_search_with_score(
    query: str,
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Tuple[Document, float]]
```

---

### asimilarity_search_by_vector()

비동기로 벡터로 검색합니다.

```python
async def asimilarity_search_by_vector(
    embedding: List[float],
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Document]
```

---

### asimilarity_search_by_vector_with_score()

비동기로 벡터로 검색하고 점수를 반환합니다.

```python
async def asimilarity_search_by_vector_with_score(
    embedding: List[float],
    k: int = 4,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Tuple[Document, float]]
```

---

### adelete()

비동기로 문서를 삭제합니다.

```python
async def adelete(
    ids: Optional[List[str]] = None,
    filter: Optional[Dict[str, Any]] = None,
    delete_all: bool = False,
    **kwargs: Any,
) -> Optional[bool]
```

**Parameters:**
- `ids`: 삭제할 document ID 목록
- `filter`: 메타데이터 필터 (ids와 함께 사용 불가)
- `delete_all`: 전체 삭제 여부 (기본값: False, 주의!)
- `**kwargs`: 추가 인자

**Returns:** 
- True: 삭제 성공
- None: 조건 없음

**Examples:**
```python
# ID로 삭제
success = await vectorstore.adelete(ids=["doc_id_1", "doc_id_2"])

# 필터로 삭제
success = await vectorstore.adelete(filter={"source": "test"})

# 전체 삭제 (주의!)
success = await vectorstore.adelete(delete_all=True)
```

**⚠️ Warning:**
`delete_all=True` 사용 시 테이블의 모든 데이터가 삭제됩니다.

---

## Search Modes

### SearchMode Enum

```python
from seahorse_vector_store import SearchMode

class SearchMode(Enum):
    DENSE = "dense"    # Pure dense vector search
    SPARSE = "sparse"  # BM25-based sparse search
    HYBRID = "hybrid"  # Dense + Sparse with RRF fusion (default)
```

### HybridSearchConfig

하이브리드 검색의 세부 설정을 제어합니다.

```python
from seahorse_vector_store import (
    HybridSearchConfig,
    DenseSearchConfig,
    SparseSearchConfig,
    FusionConfig,
)

# Custom hybrid config
config = HybridSearchConfig(
    dense=DenseSearchConfig(
        column="dense_vector",
        ef_search=100,
    ),
    sparse=SparseSearchConfig(
        column="sparse_vector",
        k=1.2,   # BM25 k parameter
        b=0.75,  # BM25 b parameter
    ),
    fusion=FusionConfig(
        type="rrf",
        k=60,      # RRF k parameter
        alpha=0.5, # Dense weight (0=sparse only, 1=dense only)
    ),
)

docs = vectorstore.similarity_search(
    "machine learning",
    k=5,
    hybrid_config=config,
)
```

### DenseSearchConfig

Dense 검색 설정.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `column` | str | "dense_vector" | Dense 벡터 컬럼명 |
| `ef_search` | Optional[int] | None | HNSW ef_search 값 |

### SparseSearchConfig

Sparse (BM25) 검색 설정.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `column` | str | "sparse_vector" | Sparse 벡터 컬럼명 |
| `k` | float | 1.2 | BM25 k 파라미터 |
| `b` | float | 0.75 | BM25 b 파라미터 |

### FusionConfig

RRF 융합 설정.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `type` | str | "rrf" | 융합 알고리즘 (현재 "rrf"만 지원) |
| `k` | int | 60 | RRF k 파라미터 |
| `alpha` | float | 0.5 | Dense 가중치 (0=Sparse only, 1=Dense only) |

---

## Not Supported Methods

### max_marginal_relevance_search()

⚠️ **Not Supported**

Seahorse API는 현재 MMR (Maximal Marginal Relevance) 검색을 지원하지 않습니다.

```python
def max_marginal_relevance_search(
    query: str,
    k: int = 4,
    fetch_k: int = 20,
    lambda_mult: float = 0.5,
    filter: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> List[Document]
```

**Raises:** `NotImplementedError`

**Alternative:** Use `similarity_search()` or `similarity_search_by_vector()` instead.

---

## Metadata Filtering

Seahorse의 metadata 컬럼은 String 타입이므로 LIKE 패턴을 사용합니다.

### Supported Filters

#### Equality Check
```python
# Simple equality
filter = {"source": "doc.pdf"}
# SQL: metadata LIKE '%"source": "doc.pdf"%'

# Multiple conditions (AND)
filter = {"source": "doc.pdf", "page": 1}
# SQL: metadata LIKE '%"source": "doc.pdf"%' AND metadata LIKE '%"page": 1%'
```

#### Explicit Operator
```python
# Explicit $eq operator
filter = {"source": {"$eq": "doc.pdf"}}
# Same as simple equality
```

### Supported Data Types

- String: `{"source": "doc.pdf"}`
- Integer: `{"page": 10}`
- Float: `{"score": 0.95}`
- Boolean: `{"is_active": true}`
- Null: `{"optional_field": null}`

### Not Supported

- Comparison operators: `$gt`, `$gte`, `$lt`, `$lte`
- List operators: `$in`, `$nin`
- Nested objects: `{"user.name": "John"}` (use flat JSON only)

---

## Advanced Configuration

### Custom ef_search

HNSW 검색 정확도를 조정할 수 있습니다:

```python
docs = vectorstore.similarity_search(
    "query",
    k=5,
    ef_search=100  # Higher = more accurate but slower
)
```

**Recommendations:**
- Default: `k * 2` (자동 설정)
- Maximum: 500
- For higher accuracy: 100-200
- For faster search: 50-100

---

## Error Handling

### Exception Hierarchy

```
SeahorseException (base)
├── SeahorseAPIError
│   ├── SeahorseAuthenticationError (401, 403)
│   └── SeahorseRateLimitError (429)
└── SeahorseValidationError
    └── SeahorseDimensionMismatchError (외부 임베딩 차원 불일치 시)
```

### Example

```python
from seahorse_vector_store import (
    SeahorseVectorStore,
    SeahorseAPIError,
    SeahorseAuthenticationError,
)

try:
    vectorstore = SeahorseVectorStore(
        api_key="invalid-key",
        base_url="https://example.api.seahorse.dnotitia.ai"
    )
    docs = vectorstore.similarity_search("test")
except SeahorseAuthenticationError as e:
    print(f"Authentication failed: {e.error_message}")
except SeahorseAPIError as e:
    print(f"API error: {e.status_code} - {e.error_message}")
```

---

## Performance Tips

### Batch Processing

```python
# Automatically batches in groups of 50
large_texts = ["text"] * 10000
ids = vectorstore.add_texts(large_texts)  # Processed in ~200 batches
```

### Async for Better Performance

```python
import asyncio

async def process_documents():
    # Multiple operations in parallel
    ids = await vectorstore.aadd_texts(texts)
    docs = await vectorstore.asimilarity_search("query")
    
asyncio.run(process_documents())
```

### Metadata Filtering Best Practices

```python
# ✅ Good: Simple flat metadata
metadata = {
    "source": "doc.pdf",
    "page": 1,
    "author": "John"
}

# ❌ Bad: Nested objects not supported
metadata = {
    "document": {
        "source": "doc.pdf",  # Won't filter correctly
        "page": 1
    }
}
```

---

## Type Hints

All public methods include complete type hints:

```python
from seahorse_vector_store import SeahorseVectorStore
from langchain_core.documents import Document
from typing import List, Dict, Any, Optional

vectorstore: SeahorseVectorStore = SeahorseVectorStore(...)
docs: List[Document] = vectorstore.similarity_search("query")
ids: List[str] = vectorstore.add_texts(["text1", "text2"])
```

---

## Constants

```python
from seahorse_vector_store.utils import (
    DEFAULT_BATCH_SIZE,  # 1024
    SMALL_BATCH_SIZE,    # 100
    MAX_JSON_SIZE,       # 20MB
    EMBEDDING_API_MAX_ROWS,        # 50
    EMBEDDING_SOURCE_MAX_BYTES,    # 32KB
)
```

---

**Last Updated:** 2026-02-11  
**Version:** 0.2.0

