# Seahorse API Gateway - TABLE API v2 명세서

**버전**: v2.0.0-rc5
**최종 업데이트**: 2025-12-22  
**변경 이력**: [CHANGELOG.md](./CHANGELOG.md)

> 📌 **버전 관리 정책**: 이 문서는 [Semantic Versioning](https://semver.org/)을 따르며, 모든 변경사항은 CHANGELOG에 기록됩니다.

## 📋 목차

1. 개요
2. v1 vs v2 주요 변경사항
3. 인증
4. 공통 응답 포맷
5. API 엔드포인트
6. 사용 시나리오 예시
7. 파라미터 가이드
8. 주의사항
9. 에러코드
10. 성능 최적화 팁
11. 용어사전
12. 문제 해결 가이드

---

## 개요

Seahorse API Gateway는 벡터 데이터베이스, AI 추론, 스토리지 서비스를 통합한 API 게이트웨이입니다. 이 문서는 **TABLE v2** 관련 API들을 다루며, 데이터 삽입, 조회, 수정, 삭제 및 벡터 검색 기능을 제공합니다.

### Base URL

https://console.seahorse.dnotitia.ai/main/tables 에서 생성한 테이블 상세 페이지에서 Host Name을 복사해서 사용할 수 있습니다.

```
https://bb1974015e734908ac3fe77a7dc57083.api.seahorse.dnotitia.ai
```

---

## v1 vs v2 주요 변경사항

### 1. 응답 구조 개선

| 항목 | v1 | v2 |
|------|----|----|
| Delete 응답 | `deleted_row_count` 반환 | 빈 객체 `{}` 반환 (성공 여부만 확인) |
| Update 응답 | `updated_row_count` 반환 | 빈 객체 `{}` 반환 (성공 여부만 확인) |
| Metrics 지원 | 미지원 | `include_metrics` 쿼리 파라미터로 상세 메트릭 조회 가능 |

### 2. 데이터 내보내기 개선

| 항목 | v1 | v2 |
|------|----|----|
| 엔드포인트 | `/v1/data/export-temp` | `/v2/data/export` |
| 내보내기 모드 | 단일 파일만 지원 | `single_file`, `multi_file` 모드 지원 |
| 다운로드 | 별도 스토리지에서 다운로드 | `/v2/data/export/download`로 직접 다운로드 가능 |
| 응답 구조 | `file_path` 단일 경로 | `files[]` 배열로 여러 파일 경로 반환 |

### 3. 임베딩 삽입 변경

| 항목 | v1 | v2 |
|------|----|----|
| `embedding_target` | 지원 (deprecated) | **미지원** (사용 시 에러 반환) |
| `embedding_config` | 선택 | **필수** |

### 4. 검색 API 개선

| 항목 | v1 | v2 |
|------|----|----|
| Metrics 지원 | 미지원 | `include_metrics` 쿼리 파라미터로 `elapsed_time`, `rss_peak_bytes` 조회 가능 |

---

## 인증

모든 API 요청에는 Bearer 토큰을 포함해야 합니다. API key는 https://console.seahorse.dnotitia.ai/main/management/api-keys 에서 생성 가능합니다. API key 생성 시 설정한 Permission에 따라 API 사용에 제한이 생길 수 있습니다.

```bash
-H "Authorization: Bearer <your-api-key>"
```

또한 api-key 헤더를 추가해서 사용 가능합니다.

```bash
-H "api-key: <your-api-key>"
```

### API Key Permission

API key는 다음과 같은 권한(Permission)을 가질 수 있습니다:

- **READ**: 데이터 조회 권한 (GET 요청, 검색 등)
- **WRITE**: 데이터 변경 권한 (POST/PUT/DELETE 요청, 삽입/수정/삭제 등)

각 API 엔드포인트는 필요한 권한이 다르며, 아래 API 엔드포인트 섹션에서 각 API별 필요 권한을 확인할 수 있습니다.

| 권한 조합 | 설명 |
|---------|------|
| READ | 조회 전용 API만 사용 가능 |
| WRITE | 변경 작업만 가능 (일반적으로 READ도 함께 부여됨) |
| READ, WRITE | 모든 API 사용 가능 (권장) |

### API 엔드포인트별 권한 요약

| API | 메소드 | 엔드포인트 | 필요 권한 |
|-----|--------|----------|----------|
| 데이터 삽입 | POST | `/v2/data` | WRITE |
| 임베딩과 함께 삽입 | POST | `/v2/data/embedding` | WRITE |
| 데이터 조회 | POST | `/v2/data/scan` | READ 또는 WRITE |
| 통합 검색 | POST | `/v2/data/search` | READ 또는 WRITE |
| 데이터 수정 | POST | `/v2/data/update` | WRITE |
| 데이터 삭제 | POST | `/v2/data/delete` | WRITE |
| 데이터 내보내기 | POST | `/v2/data/export` | READ 또는 WRITE |
| 데이터 내보내기 및 다운로드 | GET | `/v2/data/export/download` | READ 또는 WRITE |
| 인덱싱 행 개수 | GET | `/v2/data/indexed-row-count` | READ 또는 WRITE |
| 테이블 스키마 조회 | GET | `/v2/data/schema` | READ 또는 WRITE |

---

## 공통 응답 형식

모든 API는 다음과 같은 형식으로 응답합니다:

```json
{
  "success": true,
  "code": 200,
  "data": { /* 응답 데이터 */ },
  "exception": null
}
```

### 에러 응답 예시

```json
{
  "success": false,
  "code": 400,
  "data": null,
  "exception": {
    "error_code": 400001,
    "error_message": "Bad Request: Invalid input"
  }
}
```

### Metrics 응답 (v2 신규)

`include_metrics=true` 쿼리 파라미터 사용 시 응답에 메트릭 정보가 포함됩니다:

```json
{
  "success": true,
  "code": 200,
  "data": {
    /* 응답 데이터 */
    "metrics": {
      "elapsed_time": 0.5,
      "rss_peak_bytes": 52428800
    }
  },
  "exception": null
}
```

**Metrics 필드 설명:**
- `elapsed_time`: 요청 처리 시간 (초)
- `rss_peak_bytes`: 피크 메모리 사용량 (바이트)

---

## API 엔드포인트

### 1. 데이터 삽입 (v2)

**POST** `/v2/data`

**필요 권한**: `WRITE`

- **설명**: JSON Lines(JSONL) 형식으로 여러 행을 스트리밍처럼 삽입합니다.
- **Query**
    - `reader_batch_size` *(int, optional)*: 레코드 배치 크기. 기본 1024.
- **Request Body**
    - **Content-Type**: `text/plain` (**주의: JSON이 아니라 JSONL**)
    - 각 줄이 하나의 JSON 레코드입니다.
    - **벡터 길이**(아래 예시 기준으로 `embedding`)는 테이블 생성 시 지정된 **차원**과 같아야 합니다.
    - **PK(기본키) 생성 규칙 권장**:
        - 포맷: `{DocumentId}{RS(ASCII 30)}{ChunkId}`
        - Document Id: 중복 탐지를 위한 해시(권장 길이 ~128자)
        - 구분자: ASCII 30 (\u001E)
        - Chunk Id: 0부터 증가하는 4바이트 부호 없는 정수(최대 2^32-1)
        - **각 chunk의 pk는 반드시 유일**해야 합니다.

**예시(JSONL)**

```json
{"id":"1","metadata":"{\"file_name\": \"abc.pdf\"}","text":"hello","embedding":[1.0,2.0,...,3.0]}
{"id":"2","metadata":"{\"file_name\": \"def.pdf\"}","text":"world","embedding":[4.0,5.0,...,6.0]}
{"id":"3","metadata":"{\"file_name\": \"ghi.pdf\"}","text":"rust","embedding":[7.0,8.0,...,9.0]}
```

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v2/data?reader_batch_size=1024" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: text/plain" \
  --data-raw '{"id":"1","metadata":"{\"file_name\": \"abc.pdf\"}","text":"hello","embedding":[1.0,2.0,3.0]}
{"id":"2","metadata":"{\"file_name\": \"def.pdf\"}","text":"world","embedding":[4.0,5.0,6.0]}'
```

**성공 응답**: 삽입된 배치 수, 행 수, 경과 시간.

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "inserted_row_count": 4,
    "inserted_record_batches": 1,
    "elapsed_time": null
  },
  "exception": null
}
```

---

### 2. 임베딩과 함께 데이터 삽입 (v2)

**POST** `/v2/data/embedding`

**필요 권한**: `WRITE`

- **설명**: `text` 등 원문에서 임베딩을 **모델 추론 엔드포인트**로 생성한 뒤, 그 결과를 벡터 컬럼에 저장하고 함께 삽입합니다.

**⚠️ v2 변경사항:**
- `embedding_config`만 지원 (**필수**)
- deprecated된 `embedding_target` 방식은 **미지원** (사용 시 에러 반환)

**Request Body:**

```json
{
  "data": [
    {
      "id": 1,
      "metadata": "A",
      "text": "hello"
    },
    {
      "id": 2,
      "metadata": "B",
      "text": "world"
    }
  ],
  "embedding_source": "text",
  "embedding_config": [
    {
      "embedding_target": "dense_vector",
      "embedding_type": "dense"
    },
    {
      "embedding_target": "sparse_vector",
      "embedding_type": "sparse"
    }
  ]
}
```

**필드 설명:**

- `data`: 삽입할 데이터 배열 (예: `{id, text, metadata}`)
- `embedding_source`: 임베딩할 텍스트가 있는 컬럼명 (예: `text`)
- `embedding_config` **(필수)**: 여러 임베딩 타입 설정 (Dense, Sparse)
    - 항목: `{ embedding_target: "컬럼명", embedding_type: "dense" | "sparse" }`

**임베딩 타입:**

- **Dense**: 모든 차원에 값이 있는 고정 크기 벡터 (예: [0.1, 0.2, 0.3, ...])
- **Sparse**: 일부 차원만 값이 있는 벡터 (예: "1:0.5 5:0.3" - 1번째와 5번째 위치만 값 존재)

**성공 응답**: 삽입된 배치/행 수

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "inserted_row_count": 2,
    "inserted_record_batches": 1,
    "elapsed_time": 1.0
  },
  "exception": null
}
```

---

### 3. 데이터 조회 (Scan) (v2)

**POST** `/v2/data/scan`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: 전 노드를 스캔하며 조건에 맞는 데이터 반환. 일반 RDB의 `SELECT`와 유사.
- **Query**
    - `include_metrics` *(boolean)*: 메트릭 포함 여부. 기본 `false`.

**Request Body:**

```json
{
  "projection": "id, metadata, text",
  "filter": "id = '1'",
  "limit": 10
}
```

**필드 설명:**

- `projection`: 반환할 컬럼
    - 기본값: "*" - 모든 컬럼
    - 예: `id, metadata, text`
- `filter`: 필터 조건 (SQL WHERE 절, 예: `id = '1'`)
- `limit`: 반환할 최대 행 수

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v2/data/scan?include_metrics=true" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "projection": "id, text",
    "filter": "id = '\''1'\''",
    "limit": 10
  }'
```

**성공 응답**: 단일 resultset(JSON 배열 + Arrow 스타일 스키마 메타)

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "schema": {
      "fields": [
        {
          "name": "id",
          "data_type": "LargeUtf8",
          "nullable": false
        },
        {
          "name": "metadata",
          "data_type": "LargeUtf8",
          "nullable": true
        },
        {
          "name": "text",
          "data_type": "LargeUtf8",
          "nullable": true
        }
      ],
      "metadata": {}
    },
    "data": [
      {
        "id": "1",
        "metadata": "{\"file_name\": \"abc.pdf\"}",
        "text": "hello"
      }
    ],
    "metrics": {
      "elapsed_time": 0.5,
      "rss_peak_bytes": 52428800
    }
  },
  "exception": null
}
```

---

### 4. 통합 검색 API (v2)

**POST** `/v2/data/search`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: Dense, Sparse, Hybrid 검색(RRF)을 모두 지원하는 통합 검색 API입니다. 
질의 쿼리로는 텍스트 또는 벡터를 입력할 수 있습니다. 텍스트를 사용할 경우 자동으로 벡터로 변환하여 검색합니다. (데이터 임베딩을 위한 inference endpoint 사전 설정 필요)

- **Query**
    - `include_metrics` *(boolean)*: 메트릭 포함 여부. 기본 `false`.

**검색 모드:**

1. **dense**: Dense 벡터 검색만
2. **sparse**: Sparse 벡터 검색만
3. **hybrid**: Dense + Sparse 결합 검색

**필드 설명(공통 필드):**

- `search_mode`: 검색 모드 (`dense` | `sparse` | `hybrid`)
- `top_k`: 반환할 상위 결과 개수
- `projection`: 반환할 컬럼
- `filter`: 필터 조건 (WHERE 절)

#### 5.1 Dense 검색

**요청 본문 (텍스트 사용):**

```json
{
  "search_mode": "dense",
  "top_k": 10,
  "dense": {
    "column": "dense_vector",
    "text": ["Create a new trait within your crate."],
    "parameters": {
      "ef_search": 150
    }
  },
  "projection": "id, text, metadata, distance",
  "filter": "id = '100'"
}
```

**요청 본문 (벡터 사용):**

```json
{
  "search_mode": "dense",
  "top_k": 10,
  "dense": {
    "column": "dense_vector",
    "vector": [[0.1, 0.2, 0.3]],
    "parameters": {
      "ef_search": 150
    }
  },
  "projection": "id, text, metadata, distance",
  "filter": "id = '100'"
}
```

**필드 설명 (dense)**

- `column`: 검색 대상 벡터 컬럼명 (예: `dense_vector`)
- `text`: 검색에 사용할 텍스트 쿼리
- `vector`: 검색에 사용할 사전에 임베딩 된 벡터 쿼리
- `parameters`
    - `ef_search`: 검색 정확도 (클수록 정확하지만 느림)

#### 5.2 Sparse 텍스트 검색

**요청 본문 (텍스트 사용):**

```json
{
  "search_mode": "sparse",
  "top_k": 10,
  "sparse": {
    "column": "sparse_vector",
    "text": ["Create a new trait within your crate."],
    "parameters": {
      "k": 1.2,
      "b": 0.75
    }
  },
  "projection": "id, text, metadata, score",
  "filter": "id = '100'"
}
```

**요청 본문 (벡터 사용):**

```json
{
  "search_mode": "sparse",
  "top_k": 10,
  "sparse": {
    "column": "sparse_vector",
    "metadata": {
      "N": 50001,
      "avgdl": 200.51,
      "df": "1:10000 5:8000 12:15000 23:7000"
    },
    "parameters": {
      "b": 0.75,
      "k": 1.2
    },
    "vector": [
      "1:0.8 5:0.6 12:0.4 23:0.7"
    ]
  },
  "projection": "id, text, metadata, score",
  "filter": "id = '100'"
}
```

**필드 설명 (sparse)**

- `column`: 검색 대상 벡터 컬럼명 (예: `sparse_vector`)
- `text`: 검색에 사용할 텍스트 쿼리
- `vector`: 검색에 사용할 사전에 임베딩 된 벡터 쿼리
- `parameters`: BM25 알고리즘 파라미터
    - `k`: 단어 빈도 가중치 (기본: 1.2)
    - `b`: 문서 길이 정규화 (0~1, 기본: 0.75)
- `metadata`: Sparse 검색을 위한 메타데이터 (사전 임베딩 벡터 쿼리를 사용할 경우에만 유효하며, 텍스트 쿼리 사용시에는 무시됩니다)
    - `N`: 전체 문서 수
    - `avgdl`: 평균 문서 길이
    - `df`: 단어별 문서 빈도

#### 5.3 하이브리드 검색 (RRF)

Dense와 Sparse 검색 결과를 결합합니다. RRF(Reciprocal Rank Fusion) 알고리즘을 사용합니다.

**요청 본문 (텍스트 사용):**

```json
{
  "search_mode": "hybrid",
  "top_k": 10,
  "dense": {
    "column": "dense_vector",
    "text": ["Create a new trait within your crate."],
    "parameters": {
      "ef_search": 150
    }
  },
  "sparse": {
    "column": "sparse_vector",
    "text": ["Create a new trait within your crate."],
    "parameters": {
      "k": 1.2,
      "b": 0.75
    }
  },
  "fusion": {
    "type": "rrf",
    "parameters": {
      "k": 60,
      "alpha": 0.7
    }
  },
  "projection": "id, text, metadata, score",
  "filter": "id = '100'"
}
```

**요청 본문 (벡터 사용):**

```json
{
  "search_mode": "hybrid",
  "top_k": 10,
  "dense": {
    "column": "dense_vector",
    "vector": [[0.1, 0.2, 0.3]],
    "parameters": {
      "ef_search": 150
    }
  },
  "sparse": {
    "column": "sparse_vector",
    "vector": ["1:0.8 5:0.6 12:0.4 23:0.7"],
    "metadata": {
      "N": 50001,
      "avgdl": 200.51,
      "df": "1:10000 5:8000 12:15000 23:7000"
    },
    "parameters": {
      "k": 1.2,
      "b": 0.75
    }
  },
  "fusion": {
    "type": "rrf",
    "parameters": {
      "k": 60,
      "alpha": 0.7
    }
  },
  "projection": "id, text, metadata, score"
}
```

**필드 설명 (fusion - hybrid 사용 시)**

- `type`: hybrid 검색에 사용할 퓨전 알고리즘 입력 (현재는 `rrf` 만 지원)
- `parameters`: RRF 알고리즘 파라미터
    - `k`: RRF 조정 파라미터 (기본: 60)
    - `alpha`: dense search 가중치 매개변수(범위: 0.0 ~ 1.0). sparse search 가중치는 자동으로 (1 - alpha) 입니다. (기본: 0.5)

**참고: RRF란?**
Reciprocal Rank Fusion - 여러 검색 결과를 순위 기반으로 결합하는 알고리즘입니다.

```
RRF Score = Σ(1 / (k + rank))
```

- k: 조정 파라미터 (기본: 60)
- rank: 각 검색 결과에서의 순위

**성공 응답**: 다중 resultset (질의 개수만큼)

**응답 예시 (Dense):**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "num_resultsets": 2,
    "schema": {
      "fields": [
        {"name": "id", "data_type": "LargeUtf8", "nullable": false},
        {"name": "metadata", "data_type": "LargeUtf8", "nullable": false},
        {"name": "text", "data_type": "LargeUtf8", "nullable": false},
        {"name": "distance", "data_type": "Float32", "nullable": false}
      ],
      "metadata": {}
    },
    "data": [
      [
        {"id": "1", "metadata": "{\"file_name\": \"abc.pdf\"}", "text": "hello", "distance": 0.10213412},
        {"id": "2", "metadata": "{\"file_name\": \"def.pdf\"}", "text": "world", "distance": 0.20213412},
        {"id": "3", "metadata": "{\"file_name\": \"ghi.pdf\"}", "text": "rust", "distance": 0.30213412}
      ],
      [
        {"id": "4", "metadata": "{\"file_name\": \"jkl.pdf\"}", "text": "python", "distance": 0.15223412},
        {"id": "5", "metadata": "{\"file_name\": \"mno.pdf\"}", "text": "java", "distance": 0.25223412},
        {"id": "6", "metadata": "{\"file_name\": \"pqr.pdf\"}", "text": "go", "distance": 0.35223412}
      ]
    ],
    "metrics": null
  },
  "exception": null
}
```

**응답 예시 (Sparse / Hybrid):**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "num_resultsets": 2,
    "schema": {
      "fields": [
        {"name": "id", "data_type": "LargeUtf8", "nullable": false},
        {"name": "metadata", "data_type": "LargeUtf8", "nullable": false},
        {"name": "text", "data_type": "LargeUtf8", "nullable": false},
        {"name": "score", "data_type": "Float32", "nullable": false}
      ],
      "metadata": {}
    },
    "data": [
      [
        {"id": "1", "metadata": "{\"file_name\": \"abc.pdf\"}", "text": "hello", "score": 0.95213412},
        {"id": "2", "metadata": "{\"file_name\": \"def.pdf\"}", "text": "world", "score": 0.85213412}
      ]
    ],
    "metrics": {
      "elapsed_time": 0.5,
      "rss_peak_bytes": 52428800
    }
  },
  "exception": null
}
```

**참고: 거리(distance) vs 점수(score)**

- Dense 검색: `distance` 사용 - 작을수록 유사함
- Sparse 검색: `score` 사용 - 클수록 유사함
- Hybrid 검색: `score` 사용 - 클수록 유사함

---

### 5. 데이터 수정 (v2)

**POST** `/v2/data/update`

**필요 권한**: `WRITE`

- **설명**: 조건에 맞는 데이터를 갱신합니다.

**Request Body:**

```json
{
  "update_condition": "id = '1000'",
  "update_values": "text = 'changed_text'"
}
```

**필드 설명:**

- `update_condition`: 수정할 행의 조건 (SQL WHERE 절)
- `update_values`: 수정할 값 (SQL SET 절과 유사)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v2/data/update" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "update_condition": "id = '\''1000'\''",
    "update_values": "text = '\''changed_text'\''"
  }'
```

**성공 응답**: 빈 객체 (v1과 달리 `updated_row_count` 미반환)

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {},
  "exception": null
}
```

---

### 6. 데이터 삭제 (v2)

**POST** `/v2/data/delete`

**필요 권한**: `WRITE`

- **설명**: 조건에 맞는 데이터를 삭제합니다.

**Request Body:**

```json
{
  "delete_condition": "id = '1000'"
}
```

**필드 설명:**

- `delete_condition`: 삭제할 행의 조건 (SQL WHERE 절, 미제공 시 전체 삭제 가능하니 주의)

**요청 예시:**

```bash
curl -X POST "https://your-api-domain.com/v2/data/delete" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "delete_condition": "id = '\''1000'\''"
  }'
```

**성공 응답**: 빈 객체 (v1과 달리 `deleted_row_count` 미반환)

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {},
  "exception": null
}
```

---

### 7. 데이터 내보내기 (v2)

**POST** `/v2/data/export`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: 테이블 전체를 파일로 내보냅니다(주로 Parquet). 로컬/클라우드 스토리지 모두 지원.

**v2 신규 기능:**
- `single_file` / `multi_file` 모드 지원
- `target_file_size_bytes` / `max_row_groups_per_file` 옵션 추가
- 메트릭 정보 조회 가능

**Request Body (single_file 모드):**

```json
{
  "export_paths": {
    "paths": ["/export/dir"],
    "storage_config": {
      "storage_type": "S3",
      "bucket": "my_bucket",
      "credentials": {
        "access_key": "accesskey",
        "secret_key": "secretkey"
      },
      "options": {
        "endpoint": "http://127.0.0.1:8080",
        "allow_http": true,
        "virtual_hosted_style": false
      }
    }
  },
  "format": "Parquet",
  "mode": "single_file",
  "row_group_size": 40000000,
  "include_metrics": false
}
```

**Request Body (multi_file 모드):**

```json
{
  "export_paths": {
    "paths": ["/export/dir"],
    "storage_config": {
      "storage_type": "S3",
      "bucket": "my_bucket",
      "credentials": {
        "access_key": "accesskey",
        "secret_key": "secretkey"
      },
      "options": {
        "endpoint": "http://127.0.0.1:8080",
        "allow_http": true,
        "virtual_hosted_style": false
      }
    }
  },
  "format": "Parquet",
  "mode": "multi_file",
  "row_group_size": 40000000,
  "target_file_size_bytes": 134217728,
  "max_row_groups_per_file": 10,
  "include_metrics": true
}
```

**필드 설명:**

- `export_paths`: 내보내기 대상 설정
    - `paths`: 내보낼 디렉토리 경로 (배열, 하나만 지정)
    - `storage_config`: 스토리지 설정 (클라우드 스토리지 사용 시)
- `format`: 파일 형식 (현재 `Parquet`만 지원)
- `mode`: 내보내기 모드
    - `single_file`: 단일 파일로 내보내기
    - `multi_file`: 여러 파일로 분할하여 내보내기 (기본값)
- `row_group_size`: Row Group 크기 (바이트, 기본: 40MB)
- `target_file_size_bytes`: multi_file 모드에서 목표 파일 크기 (바이트)
- `max_row_groups_per_file`: multi_file 모드에서 파일당 최대 Row Group 수 (설정 시 `target_file_size_bytes`보다 우선)
- `include_metrics`: 메트릭 포함 여부 (기본: false)

**성공 응답**: 총 행 수, 로우 그룹 수, 파일 경로 등

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "export_result": {
      "output_prefix": "/export/dir",
      "files": ["part-00000.parquet", "part-00001.parquet"],
      "mode": "multi_file",
      "total_row_count": 1000,
      "total_uncompressed_byte_size": 100000,
      "num_row_groups": 10,
      "average_uncompressed_row_group_size": 10000
    },
    "metrics": {
      "elapsed_time": 2.5,
      "rss_peak_bytes": 104857600
    }
  },
  "exception": null
}
```

---

### 8. 데이터 내보내기 및 다운로드 (v2 신규)

**GET** `/v2/data/export/download`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: 테이블 전체를 내보내고 직접 다운로드합니다. 별도의 스토리지 설정 없이 바로 파일을 받을 수 있습니다.
- **Query**
    - `format` *(string)*: 파일 포맷. 현재는 Parquet만 지원. ex) Parquet
    - `row_group_size` *(int, optional)*: Row Group 크기 (바이트). 기본 40000000 (40MB).

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v2/data/export/download?format=Parquet" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -o exported_data.parquet
```

**성공 응답:**
- Content-Type: `application/octet-stream`
- Content-Disposition: `attachment; filename="{table_name}-{timestamp}.parquet"`
- 바이너리 Parquet 파일

---

### 9. 인덱싱된 행 개수 조회 (v2)

**GET** `/v2/data/indexed-row-count`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: 벡터 인덱스 별로 **색인 완료된 개수**와 총 행 수를 반환.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v2/data/indexed-row-count" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: `indexed_counts[]`(인덱스명/타입/색인된 행 수), `total_row_count`

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "total_row_count": 1000,
    "indexed_counts": [
      {
        "index_name": "dense_vector",
        "index_type": "hnsw",
        "indexed_row_count": 200
      },
      {
        "index_name": "sparse_vector",
        "index_type": "inverted",
        "indexed_row_count": 300
      }
    ]
  },
  "exception": null
}
```

---

### 10. 테이블 스키마 조회 (v2)

**GET** `/v2/data/schema`

**필요 권한**: `READ` 또는 `WRITE`

- **설명**: 테이블의 스키마 정보(컬럼 정의, 인덱스, Primary Key, 설정 등)를 조회합니다.

**요청 예시:**

```bash
curl -X GET "https://your-api-domain.com/v2/data/schema" \
  -H "Authorization: Bearer YOUR_TOKEN"
```

**성공 응답**: 테이블 스키마 정보

**응답 예시:**

```json
{
  "code": 200,
  "success": true,
  "data": {
    "table_name": "14d0508b-c824-4550-8687-f8bdecd9aad1",
    "columns": [
      {
        "name": "id",
        "type": "STRING",
        "nullable": false
      },
      {
        "name": "metadata",
        "type": "STRING",
        "nullable": false
      },
      {
        "name": "text",
        "type": "STRING",
        "nullable": false
      },
      {
        "name": "dense_vector",
        "type": {
          "name": "DENSE_VECTOR",
          "element": "FLOAT32",
          "dim": 4096
        },
        "nullable": false
      },
      {
        "name": "sparse_vector",
        "type": {
          "name": "SPARSE_VECTOR"
        },
        "nullable": false
      }
    ],
    "primary_key": ["id"],
    "segmentation": {
      "strategy": "hash",
      "columns": ["id"],
      "buckets": 1,
      "composition": "single"
    },
    "indexes": [
      {
        "type": "diskbased",
        "column": "dense_vector",
        "params": {
          "space": "ipspace",
          "ef_construction": 128,
          "M": 16
        }
      },
      {
        "type": "inverted",
        "column": "sparse_vector",
        "params": {
          "sparse_model": "bm25"
        }
      }
    ],
    "configurations": {
      "active_set_size_limit": 50000,
      "max_threads": 8
    },
    "schema": null
  },
  "exception": null
}
```

**응답 필드 설명:**

| 필드 | 타입 | 설명 |
|------|------|------|
| `table_name` | string | 테이블 이름 (UUID 형식) |
| `columns` | array | 컬럼 정의 목록 |
| `columns[].name` | string | 컬럼 이름 |
| `columns[].type` | string \| object | 컬럼 타입 (STRING, BOOL 또는 벡터 타입 객체) |
| `columns[].nullable` | boolean | NULL 허용 여부 |
| `primary_key` | array | Primary Key 컬럼 목록 |
| `segmentation` | object | 테이블 세그먼트 설정 |
| `indexes` | array | 인덱스 정의 목록 |
| `indexes[].type` | string | 인덱스 타입 (diskbased, inverted 등) |
| `indexes[].column` | string | 인덱스가 적용된 컬럼 |
| `indexes[].params` | object | 인덱스 파라미터 |
| `configurations` | object | 테이블 설정 |
| `schema` | object \| null | 스키마 정의 (nullable) |

---

## 사용 시나리오 예시: 문서 검색 시스템 구축

1. **문서 데이터 + 임베딩 삽입**

    ```bash
    POST /v2/data/embedding
    ```

    ```json
    {
      "data": [
        {
          "id": "doc1",
          "text": "인공지능은 컴퓨터가 인간처럼 생각하고 학습하는 기술입니다.",
          "metadata": "{\"title\": \"AI 개론\"}"
        }
      ],
      "embedding_source": "text",
      "embedding_config": [
        {
          "embedding_target": "dense_vector",
          "embedding_type": "dense"
        },
        {
          "embedding_target": "sparse_vector",
          "embedding_type": "sparse"
        }
      ]
    }
    ```

2. **인덱싱 상태 확인**

    ```bash
    GET /v2/data/indexed-row-count
    ```

3. **자연어로 하이브리드 검색**

    ```bash
    POST /v2/data/search?include_metrics=true
    ```

    ```json
    {
      "search_mode": "hybrid",
      "top_k": 10,
      "dense": {
        "column": "dense_vector",
        "text": ["머신러닝 알고리즘"]
      },
      "sparse": {
        "column": "sparse_vector",
        "text": ["머신러닝 알고리즘"],
        "parameters": {
          "k": 1.2,
          "b": 0.75
        }
      },
      "fusion": {
        "type": "rrf",
        "parameters": {
          "k": 60
        }
      },
      "projection": "id, text, score",
      "filter": "category = 'tech'"
    }
    ```

4. **데이터 내보내기 및 다운로드**

    ```bash
    GET /v2/data/export/download?format=Parquet
    ```

---

## 파라미터 가이드

### ef_search 설정 가이드

`ef_search`는 검색 정확도와 속도의 균형을 조절합니다.

| 값 | 정확도 | 속도 | 추천 용도 |
| --- | --- | --- | --- |
| top_k | 낮음 | 빠름 | 빠른 응답이 필요한 경우 |
| top_k * 2 | 중간 | 보통 | 일반적인 사용 |
| top_k * 5 | 높음 | 느림 | 정확도가 중요한 경우 |
| 1000+ | 매우 높음 | 매우 느림 | 최고 정확도가 필요한 경우 |

**예시:**

```json
{
  "top_k": 10,
  "ef_search": 50
}
```

### BM25 파라미터 (Sparse 검색)

**k 파라미터:**

- 범위: 1.2 ~ 2.0
- 낮은 값 (1.2): 단어 빈도의 영향 감소
- 높은 값 (2.0): 단어 빈도의 영향 증가
- 기본값: 1.2

**b 파라미터:**

- 범위: 0 ~ 1
- 0: 문서 길이 정규화 없음
- 1: 완전한 문서 길이 정규화
- 기본값: 0.75

**예시:**

```json
{
  "parameters": {
    "k": 1.2,
    "b": 0.75
  }
}
```

### reader_batch_size 설정 가이드

데이터 삽입 시 한 번에 처리할 행 수를 조절합니다.

| 데이터 크기 | 권장 reader_batch_size | 이유 |
| --- | --- | --- |
| 소량 (< 1000행) | 512 | 빠른 응답 |
| 중간 (1000~10000행) | 1024 (기본값) | 균형잡힌 성능 |
| 대량 (> 10000행) | 2048~4096 | 처리량 최적화 |

---

## 주의사항

### 1. Primary Key 중복

- 동일한 `id`(Primary Key)를 가진 데이터를 삽입하면 오류가 발생합니다.
- 청크(Chunk)별로 고유한 ID를 생성해야 합니다.

**올바른 예시:**

```
문서 "doc1"의 첫 번째 청크: "doc1_hash\u001E0"
문서 "doc1"의 두 번째 청크: "doc1_hash\u001E1"
문서 "doc2"의 첫 번째 청크: "doc2_hash\u001E0"
```

### 2. 임베딩 벡터 차원

- 삽입하는 벡터의 차원은 테이블 생성 시 지정한 차원과 일치해야 합니다.
- 예: 테이블이 1024차원이면 `[1.0, 2.0, ..., 1024번째 값]`

### 3. JSONL 형식 주의

- `/v2/data` 엔드포인트는 JSONL 형식을 사용합니다.
- 각 JSON 객체는 **한 줄에 하나씩** 작성되어야 합니다.

**잘못된 형식:**

```json
{
  "id": "1",
  "text": "hello"
}
```

**올바른 형식:**

```json
{"id": "1", "text": "hello"}
{"id": "2", "text": "world"}
```

### 4. 메타데이터 형식

- `metadata` 필드는 JSON 문자열로 저장됩니다.
- 이중 따옴표를 이스케이프해야 합니다.

**올바른 예시:**

```json
{
  "id": "1",
  "metadata": "{\"file_name\": \"abc.pdf\", \"page\": 1}"
}
```

### 5. 필터 조건 작성

- SQL WHERE 절 문법을 따릅니다.
- 문자열 비교 시 작은따옴표(`'`)를 사용합니다.

**올바른 예시:**

```json
{
  "filter": "id = '100' AND category = 'tech'"
}
```

### 6. Sparse 벡터 형식

- Sparse 벡터는 `"인덱스:값 인덱스:값"` 형식의 문자열입니다.
- 인덱스는 공백으로 구분합니다.

**올바른 예시:**

```json
{
  "sparse": {
    "vector": ["1:0.5 2:0.3 5:0.8"]
  }
}
```

### 7. v2 embedding_config 필수 (v2 전용)

- v2에서는 `embedding_config`가 **필수**입니다.
- v1에서 지원하던 `embedding_target`은 v2에서 **미지원**됩니다.

**잘못된 예시 (v2에서 에러 발생):**

```json
{
  "data": [...],
  "embedding_source": "text",
  "embedding_target": "feature"
}
```

**올바른 예시:**

```json
{
  "data": [...],
  "embedding_source": "text",
  "embedding_config": [
    {"embedding_target": "dense_vector", "embedding_type": "dense"}
  ]
}
```

---

## 에러 코드

| 코드 | 설명 | 해결 방법 |
| --- | --- | --- |
| 400 | Bad Request - 잘못된 요청 | 요청 본문의 형식과 필수 필드를 확인하세요 |
| 400001 | Bad Request - 특정 오류 | 에러 메시지의 세부 내용을 확인하세요 |
| 500 | Internal Server Error | 서버 로그를 확인하거나 관리자에게 문의하세요 |
| 500001 | Internal error | 서버 내부 오류입니다. 관리자에게 문의하세요 |

**에러 응답 예시:**

```json
{
  "code": 400,
  "success": false,
  "data": null,
  "exception": {
    "error_code": 400001,
    "error_message": "Bad Request: Invalid vector dimension. Expected 1024, got 512"
  }
}
```

---

## 성능 최적화 팁

### 1. 배치 삽입 활용

- 대량 데이터 삽입 시 `/v2/data`에 JSONL 형식으로 여러 행을 한 번에 삽입하세요.
- 여러 번 삽입하는 것보다 한 번에 배치로 삽입하는 것이 훨씬 빠릅니다.

### 2. 적절한 top_k 설정

- 필요한 만큼만 결과를 요청하세요.
- `top_k=100`보다 `top_k=10`이 훨씬 빠릅니다.

### 3. Projection 최소화

- 필요한 컬럼만 요청하세요.

```json
{
  "projection": "id, text"
}
```

### 4. 하이브리드 검색 활용

- Dense와 Sparse를 결합하면 정확도가 향상됩니다.
- RRF 파라미터 `k`를 조정하여 최적의 결과를 얻으세요.

### 5. 필터 활용

- 검색 전에 필터로 데이터를 줄이면 성능이 향상됩니다.

```json
{
  "filter": "category = 'tech' AND date > '2024-01-01'"
}
```

### 6. Metrics 활용 (v2 신규)

- `include_metrics=true`로 성능 분석 정보를 얻으세요.
- `elapsed_time`과 `rss_peak_bytes`로 병목 구간을 파악할 수 있습니다.

### 7. Export Download 활용 (v2 신규)

- 소규모 데이터는 `/v2/data/export/download`로 직접 다운로드하세요.
- 별도의 스토리지 설정 없이 간편하게 데이터를 받을 수 있습니다.

---

## 용어 사전

| 용어 | 설명 |
| --- | --- |
| **벡터(Vector)** | 데이터를 숫자 배열로 표현한 것 (예: [0.1, 0.2, 0.3]) |
| **임베딩(Embedding)** | 텍스트를 벡터로 변환하는 과정 |
| **Dense 벡터** | 모든 차원에 값이 있는 고정 크기 벡터 |
| **Sparse 벡터** | 일부 차원만 값이 있는 벡터 |
| **HNSW** | Hierarchical Navigable Small World - 빠른 벡터 검색 알고리즘 |
| **BM25** | Sparse 벡터 검색에 사용되는 랭킹 알고리즘 |
| **RRF** | Reciprocal Rank Fusion - 검색 결과 결합 알고리즘 |
| **Projection** | 조회할 컬럼 지정 (SQL의 SELECT 절) |
| **Filter** | 조건 필터링 (SQL의 WHERE 절) |
| **top_k** | 상위 k개 결과 반환 |
| **ef_search** | 검색 정확도 파라미터 (클수록 정확하지만 느림) |
| **Segment** | 데이터베이스가 데이터를 관리하는 단위 |
| **JSONL** | JSON Lines - 한 줄에 하나의 JSON 객체 |
| **Metrics** | 요청 처리 성능 정보 (처리 시간, 메모리 사용량 등) |

---

## 문제 해결 가이드

### Q1: "Invalid vector dimension" 오류가 발생해요

**A:** 테이블의 벡터 차원과 삽입하는 벡터의 차원이 일치하는지 확인하세요.

```bash
# v1 API로 테이블 스키마 확인 
GET /v1/data/schema
```

### Q2: 검색 결과가 너무 느려요

**A:** 다음 방법을 시도해보세요:

1. `ef_search` 값을 낮추기 (예: 1000 → 100)
2. `top_k` 값을 줄이기 (예: 100 → 10)
3. `filter`로 검색 범위 좁히기
4. 인덱싱이 완료되었는지 확인 (`GET /v2/data/indexed-row-count`)
5. `include_metrics=true`로 병목 구간 파악

### Q3: 데이터 삽입이 실패해요

**A:** 체크리스트:

- [ ] JSONL 형식이 올바른가요? (한 줄에 하나의 JSON)
- [ ] 벡터 차원이 일치하나요?
- [ ] Primary Key가 중복되지 않나요?
- [ ] 메타데이터가 JSON 문자열 형식인가요?

### Q4: Sparse 검색이 작동하지 않아요

**A:** 확인사항:

- [ ] `metadata` (N, avgdl, df)를 제공했나요? (벡터 쿼리 사용 시)
- [ ] `parameters` (k, b)를 설정했나요?
- [ ] Sparse 벡터 형식이 올바른가요? ("인덱스:값 인덱스:값")

### Q5: v2 embedding API에서 에러가 발생해요

**A:** v2에서는 `embedding_config`가 필수입니다:

- [ ] `embedding_config` 배열을 제공했나요?
- [ ] `embedding_target` 대신 `embedding_config`를 사용하고 있나요?

### Q6: 배치 삽입에서 일부 파일만 실패했어요

**A:** v2 응답의 `results[]` 배열을 확인하세요:

```json
{
  "results": [
    {"path": "/file1.parquet", "success": true, ...},
    {"path": "/file2.parquet", "success": false, "error": "에러 메시지"}
  ]
}
```

각 파일별 성공/실패 상태와 에러 메시지를 확인할 수 있습니다.

---

