# LangChain VectorStore SDK - 아키텍처 설계

> **Note**: 실제 코드는 `seahorse_vector_store/` 디렉토리를 참조하세요.
> 이 문서는 아키텍처 개요만 제공하며, 상세 구현은 소스 코드를 확인하시기 바랍니다.

---

## 1. 패키지 구조

```
seahorse_vector_store/
├── __init__.py           # Public exports
├── vectorstores.py       # SeahorseVectorStore 클래스
├── client.py             # SeahorseClient (Low-level API 클라이언트)
├── filters.py            # 필터 변환 로직
├── utils.py              # 유틸리티 함수
└── exceptions.py         # 커스텀 예외 클래스

tests/
├── unit/                 # 단위 테스트
├── integration/          # 통합 테스트
└── benchmarks/           # 성능 테스트

examples/                 # 예제 코드
docs/                     # 문서
```

---

## 2. 클래스 다이어그램

```
┌─────────────────────────────────────┐
│  langchain_core.vectorstores        │
│  VectorStore                        │
└───────────────┬─────────────────────┘
                │ inherits
                ▼
┌─────────────────────────────────────┐
│  SeahorseVectorStore                │
│  (vectorstores.py)                  │
├─────────────────────────────────────┤
│ - _client: SeahorseClient           │
│ - _embedding: Embeddings (optional) │
│ - _use_builtin_embedding: bool      │
│ - _index_name: str                  │
├─────────────────────────────────────┤
│ Public Methods (sync)               │
│ Public Methods (async)              │
│ Private Methods                     │
└───────────────┬─────────────────────┘
                │ uses
                ▼
┌─────────────────────────────────────┐
│  SeahorseClient                     │
│  (client.py)                        │
├─────────────────────────────────────┤
│ - _base_url: str                    │
│ - _api_key: str                     │
│ - _session: httpx.Client            │
│ - _async_client: httpx.AsyncClient  │
├─────────────────────────────────────┤
│ API Methods (v2)                    │
│ Internal Methods                    │
└─────────────────────────────────────┘
```

---

## 3. 주요 클래스

### 3.1 SeahorseVectorStore

**파일**: `seahorse_vector_store/vectorstores.py`

LangChain의 `VectorStore` 인터페이스를 구현한 메인 클래스입니다.

#### 생성자 파라미터

| 파라미터 | 타입 | 설명 |
|---------|------|------|
| `api_key` | `str` | Seahorse API 키 |
| `base_url` | `str` | 테이블 고유 API URL |
| `embedding` | `Embeddings` (optional) | 외부 임베딩 인스턴스 |
| `use_builtin_embedding` | `bool` | 내장 임베딩 사용 여부 (기본: True) |
| `dense_column` | `str` | Dense 벡터 컬럼명 (기본: "dense_vector") |
| `sparse_column` | `str` | Sparse 벡터 컬럼명 (기본: "sparse_vector") |

**속성:**
| 속성 | 타입 | 설명 |
|-----|------|------|
| `dimension` | `int` | 테이블의 dense_vector 차원 (초기화 시 스키마에서 조회) |
| `embeddings` | `Embeddings` (optional) | 외부 임베딩 인스턴스 |

#### Public Methods (동기)

| 메서드 | 설명 |
|-------|------|
| `add_texts()` | 텍스트를 벡터 저장소에 추가 |
| `add_documents()` | Document 객체를 벡터 저장소에 추가 |
| `similarity_search()` | 자연어 쿼리로 유사 문서 검색 |
| `similarity_search_with_score()` | 유사도 점수와 함께 검색 |
| `similarity_search_by_vector()` | 벡터로 직접 검색 |
| `similarity_search_by_vector_with_score()` | 벡터 검색 + 점수 |
| `delete()` | 문서 삭제 |
| `as_retriever()` | LangChain Retriever로 변환 |
| `from_texts()` | 클래스 메서드 - 텍스트로부터 VectorStore 생성 |
| `from_documents()` | 클래스 메서드 - Document로부터 VectorStore 생성 |

#### Public Methods (비동기)

| 메서드 | 설명 |
|-------|------|
| `aadd_texts()` | 비동기 텍스트 추가 |
| `aadd_documents()` | 비동기 Document 추가 |
| `asimilarity_search()` | 비동기 유사 문서 검색 |
| `asimilarity_search_with_score()` | 비동기 검색 + 점수 |
| `asimilarity_search_by_vector()` | 비동기 벡터 검색 |
| `asimilarity_search_by_vector_with_score()` | 비동기 벡터 검색 + 점수 |
| `adelete()` | 비동기 삭제 |

#### Private Methods

| 메서드 | 설명 |
|-------|------|
| `_add_texts_with_builtin_embedding()` | 내장 임베딩으로 텍스트 추가 |
| `_add_texts_with_external_embedding()` | 외부 임베딩으로 텍스트 추가 |
| `_search_to_documents()` | API 응답을 Document로 변환 |

---

### 3.2 SeahorseClient

**파일**: `seahorse_vector_store/client.py`

Low-level Seahorse API 클라이언트입니다. CoralResponse 언래핑, 에러 처리, 재시도 로직을 담당합니다.

#### 생성자 파라미터

| 파라미터 | 타입 | 설명 |
|---------|------|------|
| `base_url` | `str` | API Base URL |
| `api_key` | `str` | API 키 |
| `timeout` | `float` | 요청 타임아웃 (기본: 30.0초) |
| `max_retries` | `int` | 최대 재시도 횟수 (기본: 3) |

#### API Methods (v2)

| 메서드 | API 엔드포인트 | 설명 |
|-------|---------------|------|
| `insert_jsonl()` / `ainsert_jsonl()` | `POST /v2/data` | JSONL 형식 데이터 삽입 |
| `insert_with_embedding()` / `ainsert_with_embedding()` | `POST /v2/data/embedding` | 내장 임베딩으로 데이터 삽입 |
| `semantic_search()` / `asemantic_search()` | `POST /v2/data/search` | 텍스트 쿼리 검색 (dense + text) |
| `vector_search()` / `avector_search()` | `POST /v2/data/search` | 벡터 쿼리 검색 (dense + vector) |
| `delete_data()` / `adelete_data()` | `POST /v2/data/delete` | 데이터 삭제 |
| `get_table_schema()` | `GET /v2/data/schema` | 테이블 스키마 조회 |

#### Internal Methods

| 메서드 | 설명 |
|-------|------|
| `_request()` | 동기 HTTP 요청 (재시도 로직 포함) |
| `_arequest()` | 비동기 HTTP 요청 (재시도 로직 포함) |
| `_unwrap_coral_response()` | CoralResponse 언래핑 및 에러 처리 |

---

### 3.3 예외 클래스

**파일**: `seahorse_vector_store/exceptions.py`

| 클래스 | 설명 |
|-------|------|
| `SeahorseException` | Base exception |
| `SeahorseAPIError` | API 호출 실패 |
| `SeahorseAuthenticationError` | 인증 실패 (401, 403) |
| `SeahorseRateLimitError` | Rate limit 초과 (429) |
| `SeahorseValidationError` | 입력 검증 실패 |
| `SeahorseDimensionMismatchError` | 벡터 차원 불일치 (외부 임베딩 차원 ≠ 테이블 스키마) |
| `SeahorseSchemaError` | 스키마 조회 실패 또는 dense_vector 컬럼 정보 없음 |

---

### 3.4 필터 변환

**파일**: `seahorse_vector_store/filters.py`

| 함수 | 설명 |
|-----|------|
| `convert_filter_to_sql()` | LangChain 필터를 SQL WHERE 절로 변환 |

**제한사항**:
- metadata 컬럼은 String 타입 (JSONB 미지원)
- LIKE 패턴을 사용한 동등 비교만 지원
- 예: `{"source": "doc.pdf"}` → `metadata LIKE '%"source": "doc.pdf"%'`

---

### 3.5 유틸리티

**파일**: `seahorse_vector_store/utils.py`

| 함수/상수 | 설명 |
|---------|------|
| `generate_pk()` | Primary Key 생성 (SHA-512 해시 + chunk ID) |
| `batch_texts()` | 텍스트를 배치로 분할 |
| `estimate_json_size()` | JSON 크기 추정 |
| `DEFAULT_BATCH_SIZE` | 기본 배치 크기 (1024) |

---

## 4. API 버전

SDK v0.2.0부터 **Seahorse API v2**를 사용합니다.

| 기능 | 엔드포인트 |
|-----|----------|
| 데이터 삽입 (JSONL) | `POST /v2/data` |
| 데이터 삽입 (임베딩) | `POST /v2/data/embedding` |
| 통합 검색 | `POST /v2/data/search` |
| 데이터 삭제 | `POST /v2/data/delete` |
| 스키마 조회 | `GET /v2/data/schema` |

자세한 API 명세는 `docs/api/gw-api-specification-v2.md`를 참조하세요.

---

## 5. 임베딩 처리 전략

### 5.1 내장 임베딩 (기본)

- `use_builtin_embedding=True` (기본값)
- `/v2/data/embedding` 엔드포인트 사용
- Seahorse 서버에서 임베딩 생성
- 네트워크 왕복 최소화

### 5.2 외부 임베딩

- `use_builtin_embedding=False` + `embedding` 파라미터 제공
- LangChain Embeddings 인터페이스 사용 (OpenAI, Cohere, HuggingFace 등)
- `/v2/data` 엔드포인트로 JSONL 형식 삽입
- ⚠️ 벡터 차원이 테이블 스키마와 일치해야 함

---

## 6. 배치 처리

| 상수 | 값 | 설명 |
|-----|---|------|
| `DEFAULT_BATCH_SIZE` | 1024 | API 권장 배치 크기 |
| `MAX_JSON_SIZE` | 20MB | JSON 페이로드 최대 크기 |

대량 데이터 처리 시 자동으로 배치 분할됩니다.

---

## 7. 에러 처리 및 재시도

### 재시도 대상 상태 코드

| 코드 | 설명 |
|-----|------|
| 408 | Request Timeout |
| 429 | Rate Limit Exceeded |
| 500 | Internal Server Error |
| 502 | Bad Gateway |
| 503 | Service Unavailable |
| 504 | Gateway Timeout |

### 재시도 전략

- 최대 재시도: 3회
- 지수 백오프: 1초 → 2초 → 4초

---

## 8. 의존성

| 패키지 | 버전 | 용도 |
|-------|-----|------|
| `langchain-core` | ≥0.2.0 | VectorStore 인터페이스 |
| `httpx` | ≥0.27.0 | HTTP 클라이언트 (동기/비동기) |
| `pydantic` | ≥2.0.0 | 데이터 검증 |
| `python-dotenv` | ≥1.0.0 | 환경 변수 관리 |

---

## 9. 테스트 환경

### 환경 정보

| 환경 | Base URL |
|-----|---------|
| Production | `https://{table-uuid}.api.seahorse.dnotitia.ai` |
| Development | `http://{table-uuid}.api.seahorse.dnotitia.com` |

### 테이블 스키마

테스트용 테이블 스키마는 `docs/api/table-schema.json` 참조.

| 컬럼 | 타입 | 설명 |
|-----|-----|------|
| `id` | LargeUtf8 | Primary Key |
| `text` | LargeUtf8 | 문서 텍스트 |
| `metadata` | LargeUtf8 | JSON 문자열 |
| `dense_vector` | Vector<Float32, 4096> | 벡터 (4096차원) |

### HNSW 인덱스 설정

- M: 16
- ef_construction: 128
- space: ipspace (내적 유사도)
- active_set_size_limit: 50000

---

## 10. 개발 현황

### 구현 완료 ✅

- LangChain VectorStore 인터페이스 완전 구현
- 동기/비동기 메서드 전체 지원
- 내장 임베딩 및 외부 임베딩 지원
- 메타데이터 필터링 (LIKE 패턴)
- 배치 처리 최적화
- 에러 처리 및 재시도 로직

### 미지원 기능

| 기능 | 상태 | 비고 |
|-----|-----|------|
| MMR 검색 | ❌ | API 미지원 |
| Hybrid/Sparse 검색 | ⏳ | 향후 지원 예정 |
| SeahorseEmbeddings 클래스 | ❌ | Inference API가 base_url로 호출 불가 |

---

## 참고 문서

- **API Reference**: `docs/API_REFERENCE.md`
- **기술 명세**: `docs/TECHNICAL_SPEC.md`
- **API 스펙 (v2)**: `docs/api/gw-api-specification-v2.md`
- **테스트 요구사항**: `docs/TEST_REQUIREMENTS.md`
