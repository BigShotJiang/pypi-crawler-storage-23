# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.0] - 2025-12-26

### Added

#### Dual Vector Support (Dense + Sparse)
테이블 스키마에 `sparse_vector` 컬럼이 추가되어 Hybrid 검색을 지원합니다.

**테이블 스키마 변경:**
- `dense_vector`: VECTOR<Float32, 4096> - Dense 임베딩
- `sparse_vector`: SPARSE_VECTOR - Sparse 임베딩 (BM25)
- 데이터 삽입 시 두 벡터 모두 자동 생성 (`/v2/data/embedding`)

#### Hybrid/Sparse Search Support
Dense, Sparse, Hybrid 검색 모드를 지원합니다.

**새로운 기능:**
- `SearchMode` enum: `DENSE`, `SPARSE`, `HYBRID` (기본값)
- `HybridSearchConfig`: 하이브리드 검색 세부 설정
- `DenseSearchConfig`: Dense 검색 설정 (column, ef_search)
- `SparseSearchConfig`: Sparse 검색 설정 (column, k, b - BM25 파라미터)
- `FusionConfig`: RRF 융합 설정 (type, k, alpha)

**검색 메서드 변경:**
- `similarity_search()`: `retrieval_mode`, `hybrid_config` 파라미터 추가
- `similarity_search_with_score()`: `retrieval_mode`, `hybrid_config` 파라미터 추가
- 비동기 메서드도 동일하게 지원

**점수 반환값:**
- Dense 모드: `distance` (작을수록 유사)
- Sparse/Hybrid 모드: `score` (클수록 유사)

**기본 projection:**
- Dense: `id, text, metadata, distance`
- Sparse/Hybrid: `id, text, metadata, score`

#### External Embedding with Hybrid Search
외부 임베딩 사용 시에도 Sparse/Hybrid 검색을 지원합니다.

- Dense 검색: 외부 임베딩으로 query vector 생성
- Sparse 검색: query text 사용 (Seahorse 내장 임베딩)
- Hybrid 검색: Dense는 외부 임베딩, Sparse는 내장 임베딩
- 데이터 삽입: Dense는 외부 임베딩, Sparse는 내장 임베딩으로 자동 생성

#### Dimension Validation
외부 임베딩 차원 검증을 추가했습니다.

- 인스턴스 초기화 시 `GET /v2/data/schema` API를 호출하여 `dimension` 속성 자동 설정
- `SeahorseDimensionMismatchError`: 외부 임베딩 차원이 테이블 스키마와 불일치 시 발생
- `SeahorseSchemaError`: 스키마 조회 실패 또는 dense_vector 컬럼 정보를 찾을 수 없을 때 발생
- `add_texts()`, `similarity_search()` 모두에서 검증

### Changed

#### insert_with_embedding() 파라미터 변경
- `include_sparse` 제거 → Sparse 임베딩은 항상 내장 임베딩으로 생성
- `include_dense` 추가 (기본: True) → 외부 임베딩 사용 시 False로 설정

#### API Migration: v1 → v2
모든 Seahorse API 엔드포인트를 v1에서 v2로 마이그레이션했습니다.

**엔드포인트 변경:**
- `POST /v1/data` → `POST /v2/data`
  - Query parameter: `batch_insert_size` → `reader_batch_size`
- `POST /v1/data/embedding` → `POST /v2/data/embedding`
  - `embedding_target` (deprecated) → `embedding_config[]` (필수)
  - 새 파라미터: `embedding_type` ("dense" | "sparse")
- `POST /v1/data/semantic-search` → `POST /v2/data/search`
  - 통합 검색 API (dense + text 쿼리)
- `POST /v1/data/indexes/{index}/vector-search` → `POST /v2/data/search`
  - 통합 검색 API (dense + vector 쿼리)
- `POST /v1/data/delete` → `POST /v2/data/delete`
  - 응답 변경: `{"deleted_row_count": N}` → `{}`
- `GET /v1/data/schema` → `GET /v2/data/schema`
  - 응답 구조 확장 (columns, indexes, primary_key 등)

**메서드 시그니처 변경:**
- `insert_jsonl()`: `batch_insert_size` → `reader_batch_size`
- `insert_with_embedding()`: 새 파라미터 `embedding_type` 추가 (기본값: "dense")

**테이블 스키마 변경 (v2):**
- 벡터 컬럼명: `embedding` → `dense_vector`
- 기본 벡터 차원: 1024 → 4096
- `index_name` 기본값: `"embedding"` → `"dense_vector"`
- `embedding_target` 기본값: `"embedding"` → `"dense_vector"`

**동작 변경:**
- `delete()` / `adelete()`: 반환값 변경
  - 기존: `True` (삭제됨) / `False` (삭제 안됨)
  - 변경: `True` (성공) / `None` (ID 없음)
  - v2 API에서 `deleted_row_count` 미반환으로 인한 변경

### Notes
- ✅ Sparse/Hybrid 검색 지원 완료
- `include_metrics` 옵션 지원은 향후 별도 작업 예정

---

## [0.1.0] - 2025-11-27

Initial release of LangChain Seahorse VectorStore SDK.

### Features

#### Core Functionality
- **LangChain VectorStore integration**: Full compatibility with LangChain's VectorStore interface
- **Document management**: Add, search, and delete documents with vector embeddings
- **Semantic search**: Natural language query-based similarity search
- **Vector search**: Direct vector-based similarity search with score
- **Metadata filtering**: Filter search results using SQL WHERE clause syntax
- **Batch processing**: Automatic batching for large-scale document insertion (1024 docs/batch)

#### Embedding Support
- **Built-in embeddings**: Use Seahorse's native embedding API
- **External embeddings**: Compatible with any LangChain Embeddings (OpenAI, Cohere, HuggingFace, Ollama, etc.)

#### Async Support
- Full async/await support for all core operations
- Async methods: `aadd_texts`, `asimilarity_search`, `asimilarity_search_with_score`, `asimilarity_search_by_vector`, `asimilarity_search_by_vector_with_score`, `adelete`

#### Developer Experience
- **Type-safe**: 100% type hints coverage for better IDE support
- **Well-documented**: Google-style docstrings for all public APIs
- **Easy configuration**: Environment variable support via `.env` files (python-dotenv integration)
- **Error handling**: Automatic retry logic with exponential backoff (3 retries)
- **Examples included**: 5 ready-to-run example scripts

### Technical Specifications
- **Python support**: 3.8.1 - 3.12
- **Dependencies**: langchain-core, httpx, pydantic, python-dotenv
- **Code quality**: PEP 8 compliant, Black formatted, Ruff linted
- **Test coverage**: 76% (66 tests: 47 unit + 12 integration + 7 benchmark)
- **CI/CD**: Automated testing and PyPI deployment via GitHub Actions

### Known Limitations
- **MMR search not supported**: `max_marginal_relevance_search` raises `NotImplementedError` due to Seahorse API limitation
- **Metadata type**: Metadata stored as string (JSON serialized), only equality filtering supported
- **Hybrid search**: Not available in current Seahorse API version
