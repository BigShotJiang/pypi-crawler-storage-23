"""Pytest-specific check helpers."""
