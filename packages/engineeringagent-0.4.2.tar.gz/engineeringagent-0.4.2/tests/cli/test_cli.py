from __future__ import annotations

import json
import re
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest
import yaml
from typer.testing import CliRunner

from engineeringagent import cli as cli_module
from engineeringagent.config import (
    resolve_docs_root,
)
from engineeringagent.loop_runtime.run_context import LoopRun, RunConfig
from engineeringagent.schema_registry import list_schema_ids, schema_from_registry
from tests.cli.approach_fixture_data import (
    APPROACH_TOPIC_IDS,
)

_APPROACH_TOPIC_ID_PREFIX = re.compile(r"^\s*(?P<topic_id>[A-Za-z0-9-]+):")


def _frontmatter_from_markdown(payload: str) -> dict[str, object]:
    assert payload.startswith("---\n")
    parts = payload.split("---\n", 2)
    assert len(parts) == 3
    frontmatter = yaml.safe_load(parts[1])
    assert isinstance(frontmatter, dict)
    return frontmatter


def _parse_approach_topic_ids(payload: str) -> tuple[str, ...]:
    topic_ids: list[str] = []
    for line in payload.splitlines():
        match = _APPROACH_TOPIC_ID_PREFIX.match(line)
        if match is None:
            continue
        topic_ids.append(match.group("topic_id"))
    return tuple(topic_ids)


def _invoke_cli(args: list[str]) -> Any:
    runner = CliRunner(mix_stderr=False)
    return runner.invoke(cli_module.build_typer_app(), args)


def test_cli_surface_inventory_commands() -> None:
    result = _invoke_cli(["--help"])

    assert result.exit_code == 0
    for token in (
        "validate",
        "run",
        "approach",
        "schema",
        "checks",
        "progress",
        "init",
        "--project-root",
        "--version",
    ):
        assert token in result.stdout


def test_cli_surface_inventory_option_spellings() -> None:
    cases = [
        (["validate", "--help"], ["--schema-only"]),
        (
            ["schema", "--help"],
            ["--format", "--output"],
        ),
        (
            ["schema", "list", "--help"],
            [],
        ),
        (
            ["approach", "--help"],
            ["--output"],
        ),
        (
            ["run", "--help"],
            [
                "--all",
                "--dry-run",
                "--max-iterations",
                "--allow-dirty",
                "--verbose-output",
            ],
        ),
        (["checks", "run", "--help"], ["--checks", "--check-id", "--phase"]),
        (
            ["checks", "catalog", "--help"],
            ["--manifest-path", "--format", "--output"],
        ),
        (
            ["progress", "handoff-append", "--help"],
            ["--feature-id", "--attempt", "--timestamp"],
        ),
        (
            ["progress", "feature-prune", "--help"],
            ["--feature-id"],
        ),
        (
            ["init", "--help"],
            ["--force", "--scaffold-profile", "--docs-mode", "--scaffold-docs-dir"],
        ),
    ]

    for args, expected_options in cases:
        result = _invoke_cli(args)
        assert result.exit_code == 0
        assert "--help" in result.stdout
        for option in expected_options:
            assert option in result.stdout


def test_run_help_does_not_advertise_implement_command() -> None:
    removed_skip_flag = "--skip-" + "implement"
    result = _invoke_cli(["run", "--help"])
    stdout = result.stdout

    assert result.exit_code == 0
    assert "--implement-command" not in stdout
    assert removed_skip_flag not in stdout
    assert "skip implementation and run gates only" not in stdout
    assert "skip the implementation command" not in stdout


def test_run_rejects_removed_skip_flag() -> None:
    removed_skip_flag = "--skip-" + "implement"
    result = _invoke_cli(["run", "docs/spec/features/FEAT-900.yaml", removed_skip_flag])

    assert result.exit_code != 0
    combined_output = (result.stderr or "") + (result.stdout or "")
    assert removed_skip_flag in combined_output
    assert "No such option" in combined_output


def test_run_rejects_implement_command_option() -> None:
    result = _invoke_cli(["run", "--implement-command", "echo hi"])

    assert result.exit_code != 0
    assert "--implement-command" in (result.stderr or result.stdout)


def test_schema_requires_id_when_no_subcommand_is_provided() -> None:
    result = _invoke_cli(["schema"])

    assert result.exit_code == 1
    assert "provide a schema id or use `engineeringagent schema list`" in result.stdout


def test_run_all_requires_checks_yaml(tmp_path: Path) -> None:
    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "run",
            "--all",
            "--dry-run",
        ]
    )

    assert result.exit_code == 1
    assert "missing harness/checks.yaml" in result.stdout
    assert "engineeringagent init" in result.stdout


def test_run_all_requires_configured_checks_path(tmp_path: Path) -> None:
    (tmp_path / "engineeringagent.toml").write_text(
        "[harness.checks]\npath = \"config/checks.yaml\"\n",
        encoding="utf-8",
    )

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "run",
            "--all",
            "--dry-run",
        ]
    )

    assert result.exit_code == 1
    assert "missing config/checks.yaml" in result.stdout
    assert "required for --all" in result.stdout


def test_run_all_rejects_configured_checks_path_with_parent_traversal(
    tmp_path: Path,
) -> None:
    (tmp_path / "engineeringagent.toml").write_text(
        "[harness.checks]\npath = \"../checks.yaml\"\n",
        encoding="utf-8",
    )

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "run",
            "--all",
            "--dry-run",
        ]
    )

    assert result.exit_code == 1
    assert "run config error: invalid path in" in result.stdout
    assert "cannot contain '..'" in result.stdout


def test_run_all_rejects_invalid_checks_yaml(tmp_path: Path) -> None:
    checks_path = tmp_path / "harness" / "checks.yaml"
    checks_path.parent.mkdir(parents=True, exist_ok=True)
    checks_path.write_text("checks: {}\n", encoding="utf-8")

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "run",
            "--all",
            "--dry-run",
        ]
    )

    assert result.exit_code == 1
    assert "invalid harness/checks.yaml" in result.stdout
    assert "harness/checks.yaml:contract_version" in result.stdout


@pytest.mark.parametrize("reported_version", ["9.9.9", "3.2.1"])
def test_root_version_flag_uses_distribution_metadata_source(
    reported_version: str,
    monkeypatch: Any,
) -> None:
    requested_distribution_names: list[str] = []

    def _fake_version(distribution_name: str) -> str:
        requested_distribution_names.append(distribution_name)
        return reported_version

    monkeypatch.setattr(cli_module.importlib.metadata, "version", _fake_version)

    result = _invoke_cli(["--version"])

    assert result.exit_code == 0
    assert result.stdout == f"{reported_version}\n"
    assert result.stderr == ""
    assert requested_distribution_names == ["engineeringagent"]


def test_root_parser_still_requires_subcommand_without_version_flag() -> None:
    result = _invoke_cli([])

    assert result.exit_code == 2
    assert result.stdout == ""
    assert "Missing command" in result.stderr


def test_main_validate_command_reports_ok_via_real_cli(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    observed: dict[str, object] = {}

    def _fake_run_checks(
        project_root: str | Path,
        *,
        phase: str,
        checks: list[str] | None = None,
        schema_only: bool = False,
        **_: object,
    ) -> Any:
        observed["project_root"] = str(Path(project_root))
        observed["phase"] = phase
        observed["checks"] = checks
        observed["schema_only"] = schema_only
        return SimpleNamespace(ok=True, output="")

    monkeypatch.setattr(cli_module.checks_module, "run_checks", _fake_run_checks)

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "validate",
            "--schema-only",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "spec validation: ok\n"
    assert observed == {
        "project_root": str(tmp_path.resolve()),
        "phase": "manual",
        "checks": ["validate"],
        "schema_only": True,
    }


def test_main_run_command_executes_loop_context_via_real_cli(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    captured: dict[str, LoopRun] = {}

    def _fake_run_loop(loop_run: LoopRun) -> int:
        captured["loop_run"] = loop_run
        return 7

    monkeypatch.setattr(cli_module, "run_loop_controller", _fake_run_loop)

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "run",
            "docs/spec/features/FEAT-900.yaml",
            "--dry-run",
            "--max-iterations",
            "7",
            "--allow-dirty",
            "--verbose-output",
        ]
    )

    assert result.exit_code == 7
    loop_run = captured["loop_run"]
    assert loop_run.config == RunConfig(
        project_root=tmp_path.resolve(),
        feature_paths=("docs/spec/features/FEAT-900.yaml",),
        dry_run=True,
        run_all=False,
        max_iterations=7,
        allow_dirty=True,
        verbose_output=True,
    )


def test_main_schema_command_writes_registry_schema_via_real_cli(tmp_path: Path) -> None:
    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "schema",
            "feature.spec",
            "--format",
            "yaml",
            "--output",
            "tmp/schema.yaml",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "schema written: tmp/schema.yaml\n"
    schema_payload = yaml.safe_load(
        (tmp_path / "tmp" / "schema.yaml").read_text(encoding="utf-8")
    )
    assert schema_payload == schema_from_registry("feature.spec")


def test_main_schema_list_command_prints_registry_ids_via_real_cli() -> None:
    result = _invoke_cli(["schema", "list"])

    assert result.exit_code == 0
    assert result.stdout.splitlines() == list(list_schema_ids())


def test_main_checks_run_command_invokes_checks_via_real_cli(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    observed: dict[str, object] = {}

    def _fake_run_checks(
        project_root: str | Path,
        *,
        phase: str,
        checks: list[str] | None = None,
        check_id: str | None = None,
        feature_path: str | None = None,
        verbose_output: bool = False,
        base: str | None = None,
        head: str | None = None,
        dry_run: bool = False,
        **_: object,
    ) -> Any:
        observed["project_root"] = str(Path(project_root))
        observed["checks"] = checks
        observed["check_id"] = check_id
        observed["feature_path"] = feature_path
        observed["phase"] = phase
        observed["base"] = base
        observed["head"] = head
        observed["verbose_output"] = verbose_output
        observed["dry_run"] = dry_run
        return SimpleNamespace(
            ok=True,
            output="checks ok",
            dry_run=dry_run,
            failed_check_id=None,
            executions=[],
            decisions=[],
        )

    monkeypatch.setattr(cli_module.checks_module, "run_checks", _fake_run_checks)

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "checks",
            "run",
            "--checks",
            "commands",
            "--check-id",
            "smoke",
            "--phase",
            "feature_done",
            "--base",
            "main",
            "--head",
            "HEAD",
            "--verbose-output",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "checks ok\nchecks run: ok\n"
    assert observed["project_root"] == str(tmp_path.resolve())
    assert observed["checks"] == ["commands"]
    assert observed["check_id"] == "smoke"
    assert observed["feature_path"] is None
    assert observed["phase"] == "feature_done"
    assert observed["base"] == "main"
    assert observed["head"] == "HEAD"
    assert observed["verbose_output"] is True
    assert observed["dry_run"] is False


def test_main_approach_root_command_renders_overview_via_real_cli(tmp_path: Path) -> None:
    output_path = tmp_path / "artifacts" / "approach-overview.md"
    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "approach",
            "--output",
            "artifacts/approach-overview.md",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "approach overview written: artifacts/approach-overview.md\n"
    rendered = output_path.read_text(encoding="utf-8")
    frontmatter = _frontmatter_from_markdown(rendered)
    assert frontmatter.get("approach_id") == "overview"


def test_main_approach_topic_command_renders_topic_via_real_cli(tmp_path: Path) -> None:
    output_path = tmp_path / "artifacts" / "approach-topic.md"
    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "approach",
            "principles",
            "--output",
            "artifacts/approach-topic.md",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "approach topic written: artifacts/approach-topic.md\n"
    rendered = output_path.read_text(encoding="utf-8")
    frontmatter = _frontmatter_from_markdown(rendered)
    assert frontmatter.get("approach_id") == "principles"


def test_main_approach_list_command_renders_via_real_cli(tmp_path: Path) -> None:
    output_path = tmp_path / "artifacts" / "approach-list.md"
    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "approach",
            "list",
            "--output",
            "artifacts/approach-list.md",
        ]
    )

    assert result.exit_code == 0
    assert result.stdout == "approach list written: artifacts/approach-list.md\n"
    rendered = output_path.read_text(encoding="utf-8").splitlines()
    assert _parse_approach_topic_ids("\n".join(rendered)) == APPROACH_TOPIC_IDS


def test_main_approach_commands_render_expected_markdown() -> None:
    overview = _invoke_cli(["approach"])
    topic_list = _invoke_cli(["approach", "list"])
    topic_page = _invoke_cli(["approach", "specifications"])

    assert overview.exit_code == 0
    assert topic_list.exit_code == 0
    assert topic_page.exit_code == 0

    assert _parse_approach_topic_ids(topic_list.stdout) == APPROACH_TOPIC_IDS
    overview_frontmatter = _frontmatter_from_markdown(overview.stdout)
    topic_frontmatter = _frontmatter_from_markdown(topic_page.stdout)

    assert overview_frontmatter.get("approach_id") == "overview"
    assert topic_frontmatter.get("approach_id") == "specifications"


def test_main_unknown_approach_topic_is_helpful() -> None:
    result = _invoke_cli(["approach", "does-not-exist"])

    assert result.exit_code == 1
    assert "approach input error: unknown approach id or alias: does-not-exist" in result.stdout
    assert "engineeringagent approach list" in result.stdout


def test_fitness_command_is_rejected() -> None:
    result = _invoke_cli(["fitness", "run"])

    assert result.exit_code != 0
    assert "No such command 'fitness'" in (result.stderr or result.stdout)


def test_cmd_run_builds_looprun_context_for_loop_entrypoint(
    tmp_path: Path,
    monkeypatch: Any,
) -> None:
    captured: dict[str, LoopRun] = {}

    def _fake_run_loop(loop_run: LoopRun) -> int:
        captured["loop_run"] = loop_run
        return 7

    monkeypatch.setattr(cli_module, "run_loop_controller", _fake_run_loop)

    exit_code = cli_module.cmd_run(
        SimpleNamespace(
            project_root=str(tmp_path),
            feature_paths=["docs/spec/features/FEAT-078.yaml"],
            run_all=False,
            dry_run=True,
            max_iterations=7,
            allow_dirty=True,
            verbose_output=True,
        )
    )

    assert exit_code == 7
    loop_run = captured["loop_run"]
    assert isinstance(loop_run, LoopRun)
    assert loop_run.config == RunConfig(
        project_root=tmp_path,
        feature_paths=("docs/spec/features/FEAT-078.yaml",),
        dry_run=True,
        run_all=False,
        max_iterations=7,
        allow_dirty=True,
        verbose_output=True,
    )


def test_progress_handoff_append_reads_json_stdin_and_appends_markdown(
    tmp_path: Path,
) -> None:
    payload = {
        "summary": "Iteration completed.",
        "completed_work": ["Implemented CLI append command"],
        "verification": ["uv run pytest -q tests/cli/test_cli.py -k progress"],
        "remaining_work": ["Add docs updates"],
    }

    runner = CliRunner(mix_stderr=False)
    result = runner.invoke(
        cli_module.build_typer_app(),
        [
            "--project-root",
            str(tmp_path),
            "progress",
            "handoff-append",
            "--feature-id",
            "FEAT-130",
            "--attempt",
            "6",
            "--timestamp",
            "2026-02-25T07:00:00Z",
        ],
        input=json.dumps(payload),
    )

    assert result.exit_code == 0
    assert "fallback=false" in result.stdout
    handoff_path = (
        tmp_path / ".engineeringagent" / "progress" / "features" / "FEAT-130" / "handoff.md"
    )
    assert handoff_path.exists()


def test_progress_handoff_append_uses_fallback_for_invalid_json(
    tmp_path: Path,
) -> None:
    runner = CliRunner(mix_stderr=False)
    result = runner.invoke(
        cli_module.build_typer_app(),
        [
            "--project-root",
            str(tmp_path),
            "progress",
            "handoff-append",
            "--feature-id",
            "FEAT-130",
            "--attempt",
            "6",
        ],
        input="{bad-json",
    )

    assert result.exit_code == 0
    assert "fallback=true" in result.stdout
    assert (
        tmp_path / ".engineeringagent" / "progress" / "features" / "FEAT-130" / "handoff.md"
    ).exists()


def test_progress_feature_prune_removes_feature_progress_directory(
    tmp_path: Path,
) -> None:
    feature_dir = (
        tmp_path / ".engineeringagent" / "progress" / "features" / "FEAT-130"
    )
    feature_dir.mkdir(parents=True, exist_ok=True)
    (feature_dir / "run.txt").write_text("log\n", encoding="utf-8")

    runner = CliRunner(mix_stderr=False)
    result = runner.invoke(
        cli_module.build_typer_app(),
        [
            "--project-root",
            str(tmp_path),
            "progress",
            "feature-prune",
            "--feature-id",
            "FEAT-130",
        ],
    )

    assert result.exit_code == 0
    assert "removed path=.engineeringagent/progress/features/FEAT-130" in result.stdout
    assert not feature_dir.exists()


def test_main_init_command_uses_typer_handler(monkeypatch: Any, tmp_path: Path) -> None:
    observed: dict[str, object] = {}

    def _fake_run_init_command(request: Any, _deps: Any) -> int:
        observed["project_root"] = str(request.project_root)
        observed["force"] = request.force
        observed["scaffold_profile"] = request.scaffold_profile
        observed["docs_mode"] = request.docs_mode
        observed["scaffold_docs_dir"] = request.scaffold_docs_dir
        return 0

    monkeypatch.setattr(cli_module, "run_init_command", _fake_run_init_command)

    result = _invoke_cli(
        [
            "--project-root",
            str(tmp_path),
            "init",
            "--force",
            "--scaffold-profile",
            "python_uv",
            "--docs-mode",
            "separate",
            "--scaffold-docs-dir",
            "docs.custom",
        ]
    )

    assert result.exit_code == 0
    assert observed == {
        "project_root": str(tmp_path.resolve()),
        "force": True,
        "scaffold_profile": "python_uv",
        "docs_mode": "separate",
        "scaffold_docs_dir": "docs.custom",
    }


def test_validate_allows_custom_agents_content(tmp_path: Path, capsys: Any) -> None:
    (tmp_path / "AGENTS.md").write_text(
        "\n".join(
            [
                "# AGENTS.md",
                "",
                "Custom user-owned guidance.",
                "No bootstrap template lines required.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )

    code = cli_module.cmd_validate(
        SimpleNamespace(project_root=str(tmp_path), schema_only=False)
    )
    output = capsys.readouterr().out

    assert code == 0
    assert "AGENTS docs bootstrap contract" not in output


def test_cmd_validate_delegates_to_run_checks(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    recorded: dict[str, object] = {}

    def _fake_run_checks(
        project_root: str | Path,
        *,
        phase: str,
        checks: list[str] | None = None,
        schema_only: bool = False,
        **_: object,
    ) -> Any:
        recorded["project_root"] = str(project_root)
        recorded["phase"] = phase
        recorded["checks"] = checks
        recorded["schema_only"] = schema_only
        return SimpleNamespace(ok=True, output="")

    monkeypatch.setattr("engineeringagent.checks.run_checks", _fake_run_checks)

    code = cli_module.cmd_validate(
        SimpleNamespace(project_root=str(tmp_path), schema_only=True)
    )
    output = capsys.readouterr().out

    assert code == 0
    assert "spec validation: ok" in output
    assert recorded == {
        "project_root": str(tmp_path),
        "phase": "manual",
        "checks": ["validate"],
        "schema_only": True,
    }


def test_cmd_schema_list_prints_registry_ids(
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    monkeypatch.setattr(cli_module, "list_schema_ids", lambda: ("a.schema", "b.schema"))

    code = cli_module.cmd_schema_list(SimpleNamespace(project_root="."))
    output = capsys.readouterr().out

    assert code == 0
    assert output == "a.schema\nb.schema\n"


def test_cmd_schema_prints_registry_schema_as_json(
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    monkeypatch.setattr(
        cli_module,
        "schema_from_registry",
        lambda _schema_id: {"z": {"a": 1}, "a": 1},
    )

    code = cli_module.cmd_schema(
        SimpleNamespace(project_root=".", schema_id="feature.spec")
    )
    output = capsys.readouterr().out

    assert code == 0
    payload = json.loads(output)
    assert payload == {"a": 1, "z": {"a": 1}}


def test_cmd_schema_prints_registry_schema_as_yaml(
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    monkeypatch.setattr(
        cli_module,
        "schema_from_registry",
        lambda _schema_id: {"z": {"a": 1}, "a": 1},
    )

    code = cli_module.cmd_schema(
        SimpleNamespace(project_root=".", schema_id="feature.spec", output_format="yaml")
    )
    output = capsys.readouterr().out

    assert code == 0
    assert output == "a: 1\nz:\n  a: 1\n"


def test_cmd_schema_writes_to_output_path(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    monkeypatch.setattr(
        cli_module,
        "schema_from_registry",
        lambda _schema_id: {"z": {"a": 1}, "a": 1},
    )

    code = cli_module.cmd_schema(
        SimpleNamespace(
            project_root=str(tmp_path),
            schema_id="feature.spec",
            output_format="json",
            output="artifacts/schema.json",
        )
    )
    output = capsys.readouterr().out

    assert code == 0
    assert output == "schema written: artifacts/schema.json\n"
    payload = json.loads(
        (tmp_path / "artifacts" / "schema.json").read_text(encoding="utf-8")
    )
    assert payload == {"a": 1, "z": {"a": 1}}


def test_cmd_schema_rejects_unknown_schema_id(
    monkeypatch: pytest.MonkeyPatch,
    capsys: Any,
) -> None:
    def _raise_unknown(_schema_id: str) -> dict[str, object]:
        raise cli_module.UnknownSchemaIdError(
            "unknown schema id: missing; supported ids: feature.spec"
        )

    monkeypatch.setattr(cli_module, "schema_from_registry", _raise_unknown)

    code = cli_module.cmd_schema(SimpleNamespace(project_root=".", schema_id="missing"))
    output = capsys.readouterr().out

    assert code == 1
    assert (
        output
        == "schema input error: unknown schema id: missing; "
        "supported ids: feature.spec\n"
    )


def test_cmd_schema_rejects_empty_schema_id(capsys: Any) -> None:
    code = cli_module.cmd_schema(SimpleNamespace(project_root=".", schema_id=" "))
    output = capsys.readouterr().out

    assert code == 1
    assert (
        output
        == "schema input error: provide a schema id or use "
        "`engineeringagent schema list`\n"
    )


def test_cmd_schema_rejects_invalid_output_format(capsys: Any) -> None:
    code = cli_module.cmd_schema(
        SimpleNamespace(project_root=".", schema_id="feature.spec", output_format="toml")
    )
    output = capsys.readouterr().out

    assert code == 1
    assert output == "schema input error: --format must be one of: json, yaml\n"


def test_docs_root_resolver_defaults_to_docs(tmp_path: Path) -> None:
    assert resolve_docs_root(tmp_path) == tmp_path / "docs"


def test_docs_root_resolver_prefers_engineeringagent_toml(tmp_path: Path) -> None:
    (tmp_path / "engineeringagent.toml").write_text(
        'docs-root = "docs.engineeringagent"\n',
        encoding="utf-8",
    )
    (tmp_path / "pyproject.toml").write_text(
        '[tool.engineeringagent]\ndocs-root = "docs.from.pyproject"\n',
        encoding="utf-8",
    )

    assert resolve_docs_root(tmp_path) == tmp_path / "docs.engineeringagent"


def test_docs_root_resolver_reads_pyproject_tool_engineeringagent(
    tmp_path: Path,
) -> None:
    (tmp_path / "pyproject.toml").write_text(
        '[tool.engineeringagent]\ndocs-root = "docs.from.pyproject"\n',
        encoding="utf-8",
    )

    assert resolve_docs_root(tmp_path) == tmp_path / "docs.from.pyproject"
