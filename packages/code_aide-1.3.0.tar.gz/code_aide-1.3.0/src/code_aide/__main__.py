"""Entry point for python -m code_aide."""

from code_aide.entry import main

if __name__ == "__main__":
    main()
