"""Allow running as python -m riva."""

from riva.cli import cli

cli()
