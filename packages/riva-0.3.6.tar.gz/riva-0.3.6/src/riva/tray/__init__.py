"""System tray integration for Riva."""
