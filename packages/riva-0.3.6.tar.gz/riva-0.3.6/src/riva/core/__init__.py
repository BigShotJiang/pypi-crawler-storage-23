"""Core scanning and monitoring modules."""
