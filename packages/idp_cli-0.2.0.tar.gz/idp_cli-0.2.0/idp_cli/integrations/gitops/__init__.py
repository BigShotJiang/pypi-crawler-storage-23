"""GitOps integrations (ArgoCD, Flux)."""
