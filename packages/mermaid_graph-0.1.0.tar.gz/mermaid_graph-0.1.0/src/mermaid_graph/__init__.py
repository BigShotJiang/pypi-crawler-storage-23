"""
mermaid_graph
==========
Bidirectional conversion between Mermaid diagrams, JSON (node_link_data
extended format), and NetworkX graphs.

Quick start
-----------

.. code-block:: python

    import mermaid_graph as mnx

    # Mermaid → JSON dict
    data = mnx.mermaid_to_json(mermaid_text)

    # JSON dict → NetworkX
    G = mnx.to_networkx(data)

    # NetworkX → JSON dict
    data = mnx.from_networkx(G)

    # JSON dict → Mermaid
    text = mnx.json_to_mermaid(data)

    # Shorthand round-trips
    G = mnx.mermaid_to_networkx(mermaid_text)
    text = mnx.networkx_to_mermaid(G)
"""

from __future__ import annotations

import json
import os
from typing import Any

import networkx as nx

from .converter import from_networkx, to_networkx
from .exceptions import (
    MermaidError,
    MermaidParseError,
    MermaidSerializeError,
    MermaidValidationError,
)
from .parser import parse
from .schema import (
    ARROW_TYPES,
    DIRECTIONS,
    LINE_TYPES,
    SHAPES,
    MermaidGraph,
    MermaidLink,
    MermaidNode,
    Subgraph,
)
from .serializer import serialize

__version__ = "0.1.0"


# ════════════════════════════════════════════════════════════════════════
#  Core conversion functions
# ════════════════════════════════════════════════════════════════════════

def mermaid_to_json(text: str) -> dict[str, Any]:
    """Parse Mermaid flowchart text into an extended node_link_data dict."""
    return parse(text)


def json_to_mermaid(data: dict[str, Any]) -> str:
    """Serialize an extended node_link_data dict to Mermaid text."""
    return serialize(data)


def mermaid_to_networkx(text: str) -> nx.DiGraph | nx.Graph:
    """Parse Mermaid text directly into a NetworkX graph."""
    return to_networkx(parse(text))


def networkx_to_mermaid(G: nx.DiGraph | nx.Graph) -> str:
    """Serialize a NetworkX graph directly to Mermaid text."""
    return serialize(from_networkx(G))


# ════════════════════════════════════════════════════════════════════════
#  JSON I/O helpers
# ════════════════════════════════════════════════════════════════════════

def load_json(path: str | os.PathLike[str]) -> dict[str, Any]:
    """Load an extended node_link_data dict from a JSON file."""
    with open(path) as f:
        return json.load(f)


def save_json(
    data: dict[str, Any],
    path: str | os.PathLike[str],
    indent: int = 2,
) -> None:
    """Save an extended node_link_data dict to a JSON file."""
    with open(path, "w") as f:
        json.dump(data, f, indent=indent, ensure_ascii=False)


__all__ = [
    # Version
    "__version__",
    # Core conversions
    "mermaid_to_json",
    "json_to_mermaid",
    "to_networkx",
    "from_networkx",
    "mermaid_to_networkx",
    "networkx_to_mermaid",
    # JSON I/O
    "load_json",
    "save_json",
    # Schema classes
    "MermaidGraph",
    "MermaidNode",
    "MermaidLink",
    "Subgraph",
    # Constants
    "SHAPES",
    "LINE_TYPES",
    "ARROW_TYPES",
    "DIRECTIONS",
    # Exceptions
    "MermaidError",
    "MermaidParseError",
    "MermaidValidationError",
    "MermaidSerializeError",
]