"""
mermaid_graph.exceptions
========================
Custom exception hierarchy for the mermaid_graph library.
"""


class MermaidError(Exception):
    """Base exception for all mermaid_graph errors."""


class MermaidParseError(MermaidError):
    """Raised when Mermaid text cannot be parsed."""


class MermaidValidationError(MermaidError):
    """Raised when a schema value is invalid (e.g. unknown shape)."""


class MermaidSerializeError(MermaidError):
    """Raised when a data dict cannot be serialized to Mermaid text."""