"""Kingpin version number. You must bump this when creating a new release."""

__version__ = "8.0.0"
