import asyncio
import functools
from concurrent.futures import ThreadPoolExecutor

from botocore import exceptions as botocore_exceptions

EXECUTOR = ThreadPoolExecutor(10)


class ApiCallQueue:
    """
    Handles queueing up and sending AWS api calls serially,
    with exponential backoff when there is throttling.

    Invoke the `call` method to queue up a new API call.
    """

    def __init__(self):
        self.executor = EXECUTOR

        self._queue = asyncio.Queue()
        self._consumer_task = asyncio.ensure_future(self._process_queue())

        # Used for controlling how fast the work queue is processed,
        # with exponential delay on throttling errors.
        self.delay_min = 0.25
        self.delay_max = 30
        # We don't have a delay until we first get throttled.
        self.delay = 0

    async def call(self, api_function, *args, **kwargs):
        """Call a boto3 api function.

        Simply invoke this with an api method and its args and kwargs.

        The api function call is coordinated synchronously across all
        calls to this `api_call_queue`, and they will run in order.

        I.e., if you invoke this right after another coroutine invoked this,
        it will block until that other coroutine's call completed.

        If the call ends up being rate limited,
        it will backoff and try again continuously.

        By serializing the api calls to the specific method,
        this prevents a stampeding herd effect that you'd normally get
        with infinite retries.

        There is no limit or timeout on how many times it will retry,
        so in practice this may block an extremely long time if all responses
        are rate limit exceptions.

        Any other failures, like connection timeouts or read timeouts,
        will bubble up immediately and won't be retried here.
        """
        result_queue = asyncio.Queue(maxsize=1)
        await self._queue.put((result_queue, api_function, args, kwargs))
        result = await result_queue.get()
        if isinstance(result, Exception):
            raise result
        return result

    async def _process_queue(self):
        """Queue consumer.

        Reads the api functions to call from the internal queue
        along with their individual result queues.
        Calls the api function.
        That result queue is used to pass back the result
        or exception from the call.
        This sleeps between API calls based on `delay`.
        """
        while True:
            result_queue, api_function, args, kwargs = await self._queue.get()
            try:
                result = await self._call(api_function, *args, **kwargs)
            except Exception as e:
                result = e
            await result_queue.put(result)
            await asyncio.sleep(self.delay)

    async def _call(self, api_function, *args, **kwargs):
        """Calls the provided api_function in a background thread.

        If the api function returns a response cleanly, this will return it.
        If the api function raises an exception, this raises it up.

        For as long as the api function returns a boto3
        rate limiting exception, this will backoff and try again.
        """
        while True:
            try:
                result = await self._thread(api_function, *args, **kwargs)
                self._decrease_delay()
                return result
            except botocore_exceptions.ClientError as e:
                # Boto3 exception.
                if e.response["Error"]["Code"] == "Throttling":
                    self._increase_delay()
                    await asyncio.sleep(self.delay)
                else:
                    self._decrease_delay()
                    raise e

    def _decrease_delay(self):
        """Decrease `delay` by one step.

        If `delay` is already 0, do nothing.
        If `delay` is `delay_min`, go to 0.

        Otherwise, divide `delay` by 2.
        If that goes below `delay_min`, go to `delay_min`.
        """
        if self.delay == 0:
            return
        if self.delay == self.delay_min:
            self.delay = 0
            return
        self.delay /= 2
        self.delay = max(self.delay, self.delay_min)

    def _increase_delay(self):
        """Increase `delay` by one step.

        If `delay` is already 0, go to `delay_min`.

        Otherwise, multiply `delay` by 2.
        If that goes above `delay_max`, go to `delay_max`.
        """
        if self.delay == 0:
            self.delay = self.delay_min
            return
        self.delay *= 2
        self.delay = min(self.delay, self.delay_max)

    async def _thread(self, function, *args, **kwargs):
        """Execute `function` in a background thread."""
        loop = asyncio.get_event_loop()
        fn = functools.partial(function, *args, **kwargs)
        return await loop.run_in_executor(self.executor, fn)
