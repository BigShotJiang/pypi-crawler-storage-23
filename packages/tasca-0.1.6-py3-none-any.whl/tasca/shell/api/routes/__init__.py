"""
REST API routes.

This package contains the individual route modules for the API.
"""

# Route implementations will be here
