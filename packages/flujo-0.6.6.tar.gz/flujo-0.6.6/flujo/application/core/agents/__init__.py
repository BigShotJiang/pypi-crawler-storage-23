"""Core subpackage."""
