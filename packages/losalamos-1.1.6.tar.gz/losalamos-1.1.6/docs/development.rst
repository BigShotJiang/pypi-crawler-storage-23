.. _development:

.. development guide [CHANGE THIS]:

.. include:: ../CONTRIBUTING.md
   :parser: myst_parser.sphinx_

