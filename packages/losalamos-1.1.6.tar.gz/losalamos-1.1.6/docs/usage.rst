.. _usage:

.. include:: ./includes/warning_development.rst

Usage
#######################################################################

.. _quickview:

Overview
***********************************************************************

.. develop some entry notes [CHANGE THIS]:

For casual users, the installation instructions allow quick setup and testing of basic functionality.

.. seealso::

   For those who want to contribute, see :ref:`Development <development>`


.. _installation:

Installation
***********************************************************************

Install as a Python package
============================================

For Python regular users, install the latest package deploy
to a Python 3 environment via pip:

.. code-block:: console

    python -m pip install losalamos

Or any desired branch or version via github url:

.. code-block:: console

    python -m pip install git+https://github.com/iporepos/losalamos.git@main


.. _guides:

Guides
***********************************************************************

For those seeking practical guidance on using the tools available in the repo, relevant resources are provided.


Examples
============================================

Develop examples here

A basic script
--------------------------------------------

.. code-block:: python

    from losalamos import module


.. code-block:: python

    v = module.add(num1=3, num2=4)


.. code-block:: python

    print(v)
    # [out]: 7


.. [ADD MORE IF NEEDED]

Advanced script
--------------------------------------------

Develop examples here

.. [ADD MORE IF NEEDED]