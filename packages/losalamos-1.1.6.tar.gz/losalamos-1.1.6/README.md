![Style Status](https://github.com/iporepos/losalamos/actions/workflows/style.yaml/badge.svg)
![Docs Status](https://github.com/iporepos/losalamos/actions/workflows/docs.yaml/badge.svg)
![Tests Status](https://github.com/iporepos/losalamos/actions/workflows/tests.yaml/badge.svg)
![Top Language](https://img.shields.io/github/languages/top/iporepos/losalamos)
![Status](https://img.shields.io/badge/status-development-yellow.svg)
[![Code Style](https://img.shields.io/badge/style-black-000000.svg)](https://github.com/psf/black)
[![Documentation](https://img.shields.io/badge/docs-online-blue)](https://iporepos.github.io/losalamos/)
[![PyPI Latest Release](https://img.shields.io/pypi/v/losalamos.svg?label=PyPI)](https://pypi.org/project/losalamos/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/losalamos.svg?label=PyPI%20downloads)](
https://pypi.org/project/losalamos/)


<a logo>
<img src="https://raw.githubusercontent.com/iporepos/losalamos/master/docs/figs/logo.png" height="130" width="130">
</a>

---

# Los Alamos

A Python toolkit for productivity and research. 

> [!NOTE]
> Check out the [documentation website](https://iporepos.github.io/losalamos/)

---

# Install easily

```bash
python -m pip install losalamos
```

---

# Quick Gallery

