# SPDX-License-Identifier: GPL-3.0-or-later
#
# Copyright (C) 2025 The Project Authors
# See pyproject.toml for authors/maintainers.
# See LICENSE for license details.
"""
todo: docstring

"""
# IMPORTS
# ***********************************************************************

# Native imports
# =======================================================================
import subprocess

# SCRIPT
# ***********************************************************************
if __name__ == "__main__":

    subprocess.run(["black", "."])
