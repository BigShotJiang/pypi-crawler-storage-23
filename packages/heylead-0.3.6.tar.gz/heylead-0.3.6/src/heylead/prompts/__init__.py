# Prompt templates directory — loaded by ai/prompt_loader.py
