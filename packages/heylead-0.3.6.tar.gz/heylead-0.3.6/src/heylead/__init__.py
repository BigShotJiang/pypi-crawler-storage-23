"""HeyLead — MCP-native autonomous LinkedIn SDR."""

__version__ = "0.3.6"
