#!/bin/sh
echo "rm Demo01.xlsx 2>/dev/null"
rm Demo01.xlsx 2>/dev/null
echo "rm Demo02.xlsx 2>/dev/null"
rm Demo02.xlsx 2>/dev/null
echo "rm Demo03.xlsx 2>/dev/null"
rm Demo03.xlsx 2>/dev/null
echo "rm Demo04.xlsx 2>/dev/null"
rm Demo04.xlsx 2>/dev/null
echo "rm スプレッドシート.xlsx 2>/dev/null"
rm スプレッドシート.xlsx 2>/dev/null
echo "rm Demo05.xlsx 2>/dev/null"
rm Demo05.xlsx 2>/dev/null
echo "rm Demo06.xlsx 2>/dev/null"
rm Demo06.xlsx 2>/dev/null
echo "rm Demo07.xlsx 2>/dev/null"
rm Demo07.xlsx 2>/dev/null
echo "rm Demo08.xlsx 2>/dev/null"
rm Demo08.xlsx 2>/dev/null
echo "rm Demo09.xlsx 2>/dev/null"
rm Demo09.xlsx 2>/dev/null
echo "rm Demo10.xlsx 2>/dev/null"
rm Demo10.xlsx 2>/dev/null
