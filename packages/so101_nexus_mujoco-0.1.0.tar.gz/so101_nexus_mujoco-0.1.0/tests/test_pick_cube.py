import os

import gymnasium as gym
import numpy as np
import pytest

os.environ.setdefault("MUJOCO_GL", "egl")

import so101_nexus_mujoco  # noqa: F401
from so101_nexus_mujoco.pick_cube import (
    _CUBE_SPAWN_CENTER,
    _CUBE_SPAWN_HALF_SIZE,
    PickCubeEnv,
)


@pytest.fixture(scope="module")
def goal_env():
    env = gym.make("MuJoCoPickCubeGoal-v1")
    yield env
    env.close()


@pytest.fixture(scope="module")
def lift_env():
    env = gym.make("MuJoCoPickCubeLift-v1")
    yield env
    env.close()


class TestConstructionValidation:
    def test_invalid_cube_color(self):
        with pytest.raises(ValueError, match="cube_color"):
            PickCubeEnv(cube_color="neon")

    def test_invalid_cube_half_size(self):
        with pytest.raises(ValueError, match="cube_half_size"):
            PickCubeEnv(cube_half_size=0.001)


class TestEnvCreation:
    def test_goal_env_creates(self, goal_env):
        assert isinstance(goal_env, gym.Env)

    def test_lift_env_creates(self, lift_env):
        assert isinstance(lift_env, gym.Env)

    def test_goal_env_reset(self, goal_env):
        obs, info = goal_env.reset()
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)

    def test_lift_env_reset(self, lift_env):
        obs, info = lift_env.reset()
        assert isinstance(obs, np.ndarray)
        assert isinstance(info, dict)

    def test_goal_env_step(self, goal_env):
        goal_env.reset()
        action = goal_env.action_space.sample()
        obs, reward, terminated, truncated, info = goal_env.step(action)
        assert isinstance(obs, np.ndarray)
        assert reward is not None
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)

    def test_lift_env_step(self, lift_env):
        lift_env.reset()
        action = lift_env.action_space.sample()
        obs, reward, terminated, truncated, info = lift_env.step(action)
        assert isinstance(obs, np.ndarray)
        assert reward is not None
        assert isinstance(terminated, bool)
        assert isinstance(truncated, bool)
        assert isinstance(info, dict)

    def test_observation_space_goal(self, goal_env):
        obs, _ = goal_env.reset()
        assert goal_env.observation_space.contains(obs)

    def test_observation_space_lift(self, lift_env):
        obs, _ = lift_env.reset()
        assert lift_env.observation_space.contains(obs)

    def test_action_space_shape_goal(self, goal_env):
        assert goal_env.action_space.shape == (6,)

    def test_action_space_shape_lift(self, lift_env):
        assert lift_env.action_space.shape == (6,)


class TestEpisodeLogic:
    EXPECTED_INFO_KEYS = {
        "obj_to_goal_dist",
        "is_obj_placed",
        "is_grasped",
        "is_robot_static",
        "lift_height",
        "success",
        "tcp_to_obj_dist",
    }

    def test_info_keys_goal(self, goal_env):
        _, info = goal_env.reset()
        assert set(info.keys()) == self.EXPECTED_INFO_KEYS

    def test_info_keys_lift(self, lift_env):
        _, info = lift_env.reset()
        assert set(info.keys()) == self.EXPECTED_INFO_KEYS

    def test_cube_spawns_in_bounds(self, goal_env):
        for _ in range(5):
            goal_env.reset()
            cube_pose = goal_env.unwrapped._get_cube_pose()
            cx, cy = _CUBE_SPAWN_CENTER
            hs = _CUBE_SPAWN_HALF_SIZE
            assert cx - hs <= cube_pose[0] <= cx + hs
            assert cy - hs <= cube_pose[1] <= cy + hs

    def test_goal_spawns_in_bounds(self, goal_env):
        for _ in range(5):
            goal_env.reset()
            goal_pos = goal_env.unwrapped._get_goal_pos()
            cx, cy = _CUBE_SPAWN_CENTER
            hs = _CUBE_SPAWN_HALF_SIZE
            assert cx - hs <= goal_pos[0] <= cx + hs
            assert cy - hs <= goal_pos[1] <= cy + hs

    def test_reward_range_goal(self, goal_env):
        goal_env.reset()
        action = goal_env.action_space.sample()
        _, reward, _, _, _ = goal_env.step(action)
        assert 0.0 <= reward <= 1.0

    def test_reward_range_lift(self, lift_env):
        lift_env.reset()
        action = lift_env.action_space.sample()
        _, reward, _, _, _ = lift_env.step(action)
        assert 0.0 <= reward <= 1.0


class TestCameraModes:
    def test_state_only_returns_flat_array(self):
        env = PickCubeEnv(camera_mode="state_only")
        obs, _ = env.reset()
        assert isinstance(obs, np.ndarray)
        assert obs.shape == (24,)
        env.close()

    def test_wrist_mode_returns_dict(self):
        env = PickCubeEnv(camera_mode="wrist")
        obs, _ = env.reset()
        assert isinstance(obs, dict)
        assert "state" in obs
        assert "wrist_camera" in obs
        assert obs["state"].shape == (24,)
        assert obs["wrist_camera"].shape == (224, 224, 3)
        assert obs["wrist_camera"].dtype == np.uint8
        env.close()

    def test_wrist_mode_step_returns_dict(self):
        env = PickCubeEnv(camera_mode="wrist")
        env.reset()
        action = env.action_space.sample()
        obs, _, _, _, _ = env.step(action)
        assert isinstance(obs, dict)
        assert obs["wrist_camera"].shape == (224, 224, 3)
        assert obs["wrist_camera"].dtype == np.uint8
        env.close()


class TestRenderModes:
    def test_rgb_array(self):
        env = gym.make("MuJoCoPickCubeGoal-v1", render_mode="rgb_array")
        env.reset()
        frame = env.render()
        assert isinstance(frame, np.ndarray)
        assert frame.ndim == 3
        env.close()
