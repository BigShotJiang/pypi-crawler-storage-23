"""Agent-specific interaction loop for the command palette.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import json
import os
import re
from collections.abc import Callable
from contextlib import contextmanager
from typing import TYPE_CHECKING, Any, cast

import click

from glaip_sdk.branding import ERROR_STYLE, HINT_PREFIX_STYLE
from glaip_sdk.cli.commands.agents import get as agents_get_command
from glaip_sdk.cli.commands.agents import run as agents_run_command
from glaip_sdk.cli.constants import DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
from glaip_sdk.cli.core.context import bind_slash_session_context, get_client
from glaip_sdk.cli.hints import format_command_hint
from glaip_sdk.cli.io import fetch_raw_resource_details
from glaip_sdk.cli.masking import mask_payload
from glaip_sdk.cli.slash.prompt import _HAS_PROMPT_TOOLKIT, FormattedText
from glaip_sdk.cli.slash.tui.agent_prompt_editor_app import (
    TEXTUAL_SUPPORTED as _TEXTUAL_SUPPORTED,
)
from glaip_sdk.cli.slash.tui.agent_prompt_editor_app import (
    AgentPromptEditorInput,
    run_agent_prompt_editor_textual,
)
from glaip_sdk.cli.slash.tui.agent_workspace_foundation import format_utc_timestamp
from glaip_sdk.cli.slash.tui.agent_workspace_shell_app import (
    TEXTUAL_SUPPORTED as _WORKSPACE_TEXTUAL_SUPPORTED,
)
from glaip_sdk.cli.slash.tui.agent_workspace_shell_app import (
    AgentWorkspaceDetails,
    run_agent_workspace_shell,
)
from glaip_sdk.cli.transcript import store_transcript_for_session
from glaip_sdk.utils.rendering.renderer import make_silent_renderer

if TYPE_CHECKING:  # pragma: no cover - type checking only
    from glaip_sdk.cli.slash.session import SlashSession


class AgentRunSession:
    """Per-agent execution context for the command palette."""

    RETURN_TO_PALETTE_HELP = "Return to the command palette."
    _ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
    _STATUS_HEADER_LINE = "gl aip status"
    _STATUS_FETCHING_TOKEN = "fetching"
    _STATUS_BULLET_PREFIX = "• "
    _STATUS_ACCOUNT_PREFIX = "Account:"
    _STATUS_API_PREFIX = "API URL:"
    _STATUS_BASE_PREFIX = "Base URL:"
    _STATUS_ENDPOINT_PREFIX = "Endpoint:"
    _STATUS_SAVED_TRANSCRIPTS_PREFIX = "Saved transcripts:"
    _STATUS_TRANSCRIPTS_PREFIX = "Transcripts:"
    _STATUS_CACHE_DIR_PREFIX = "Cache dir:"
    _STATUS_RESOURCES_PREFIX = "Resources:"
    _PROMPT_COMMAND = "/prompt"
    _RUNS_COMMAND = "/runs"
    _SCHEDULES_COMMAND = "/schedules"
    _WORKSPACE_STATUS_LINE_LIMIT = 10
    _WORKSPACE_DETAILS_SENTINEL = "\u0000DETAILS\u0000"
    _WORKSPACE_TOOL_CALL_PREFIX = "tool_call:"
    _WORKSPACE_TOOL_RESULT_PREFIX = "tool_result:"
    _WORKSPACE_TOOL_PARAMS_PREFIX = "tool_params:"
    _WORKSPACE_HANDOFF_PREFIX = "handoff:"
    _WORKSPACE_FAILED_STATES = {"failed", "error", "aborted", "cancelled", "stopped"}
    _DETAILS_GROUPS = (
        (
            "Overview",
            (
                "id",
                "description",
                "type",
                "framework",
                "version",
                "language_model",
                "instruction",
                "created_at",
                "updated_at",
            ),
        ),
        ("Configuration", ("agent_config", "a2a_profile")),
        ("Tools", ("tools",)),  # tools will be merged with tool_configs during rendering
        ("MCPs", ("mcps",)),  # mcps will be merged with mcp_configs during rendering
        ("Sub-agents", ("agents",)),
        ("Metadata", ("metadata",)),
    )
    # Centralized exclusion list for attributes that should not appear in
    # `/details` by default. Unknown future keys still appear under "others"
    # unless explicitly listed here.
    _DETAILS_EXCLUDED_KEYS = {
        "api_key",
        "name",
        "account",
        "account_name",
        "account_id",
    }
    _DETAILS_CHILD_KEY_PRIORITY = (
        "description",
        "instruction",
        "config",
    )

    def __init__(self, session: SlashSession, agent: Any) -> None:
        """Initialize the agent run session.

        Args:
            session: The slash session context
            agent: The agent to interact with
        """
        self.session = session
        self.agent = agent
        self.console = session.console
        self._agent_id = str(getattr(agent, "id", ""))
        self._agent_name = getattr(agent, "name", "") or self._agent_id
        self._prompt_placeholder: str = "Message this agent. Type / for commands. Alt+Enter adds a new line."
        self._contextual_completion_help: dict[str, str] = {
            "details": "Show this agent's configuration (+ expands prompt).",
            "prompt": "Edit this agent's prompt (instruction).",
            "status": "Display connection status without leaving this context.",
            "help": "Display this context-aware menu.",
            "runs": "Browse remote run history for this agent.",
            "schedules": "Manage recurring schedules for this agent.",
            "export": "Export the latest transcript as JSONL.",
            "exit": self.RETURN_TO_PALETTE_HELP,
            "back": self.RETURN_TO_PALETTE_HELP,
            "q": self.RETURN_TO_PALETTE_HELP,
        }
        self._instruction_preview_limit = DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
        self._workspace_history: list[str] = []
        self._in_workspace_command = False

    def run(self) -> None:
        """Run the interactive agent session loop."""
        self.session.set_contextual_commands(self._contextual_completion_help, include_global=False)
        previous_agent = getattr(self.session, "_current_agent", None)
        self.session._current_agent = self.agent
        clear_ready = getattr(self.session, "clear_agent_transcript_ready", None)
        if callable(clear_ready):
            clear_ready(self._agent_id)
        try:
            self._display_agent_info()
            if self._use_workspace_shell():
                self._run_agent_workspace_loop()
            else:
                self._run_agent_loop()
        finally:
            self.session.set_contextual_commands(None)
            self.session._current_agent = previous_agent

    def _use_workspace_shell(self) -> bool:
        """Return True when the gated workspace shell should be used."""
        workspace_enabled = os.getenv("AIP_TUI_AGENT_WORKSPACE", "").strip().lower() in {"1", "true", "yes", "on"}
        selector_enabled = os.getenv("AIP_TUI_AGENTS_SELECTOR", "").strip().lower() in {"1", "true", "yes", "on"}
        tui_handoff_enabled = getattr(self.session, "tui_ctx", None) is not None
        enabled = workspace_enabled or selector_enabled or tui_handoff_enabled
        return bool(enabled and _WORKSPACE_TEXTUAL_SUPPORTED and self._is_tty_available())

    def _is_tty_available(self) -> bool:
        """Detect interactive terminal support for workspace shell usage."""
        ctx_obj = getattr(self.session.ctx, "obj", None)
        if isinstance(ctx_obj, dict) and "tty" in ctx_obj:
            try:
                return bool(ctx_obj.get("tty"))
            except Exception:
                pass
        return bool(getattr(self.console, "is_terminal", False))

    def _run_agent_workspace_loop(self) -> None:
        """Run interaction loop via Textual workspace shell."""
        while True:
            event = self._next_workspace_event()
            if event is None:
                return

            if not self._process_workspace_event(event):
                return

    def _next_workspace_event(self) -> Any | None:
        """Request next event from workspace shell."""
        event = run_agent_workspace_shell(
            details=self._workspace_details(),
            transcript_lines=self._workspace_history,
            composer_placeholder=self._prompt_placeholder or "Type / for commands, or enter a message.",
            status_summary_provider=self._collect_status_summary_lines,
            details_provider=self._collect_details_lines,
            transcript_sink=self._set_workspace_history,
            message_run_provider=self._run_workspace_message,
        )
        if self._prompt_placeholder:
            self._prompt_placeholder = ""
        if event is None or event.kind == "exit":
            return None
        return event

    def _set_workspace_history(self, lines: list[str]) -> None:
        """Persist workspace transcript updates emitted from inline status flow."""
        self._workspace_history = list(lines)

    def _append_workspace_status(self, body: str) -> None:
        """Append one normalized status row to workspace history."""
        text = str(body or "").strip()
        if text:
            self._workspace_history.append(f"Status: {text}")

    def _run_workspace_message(
        self,
        message: str,
        *,
        stream_status_callback: Callable[[str], None] | None = None,
        stream_reply_callback: Callable[[str], None] | None = None,
    ) -> str | tuple[str, list[str]] | None:
        """Execute agent run callback while workspace shell remains active."""
        if stream_status_callback is None and stream_reply_callback is None:
            return self._run_agent(self._agent_id, message)
        return self._run_agent(
            self._agent_id,
            message,
            stream_status_callback=stream_status_callback,
            stream_reply_callback=stream_reply_callback,
        )

    def _process_workspace_event(self, event: Any) -> bool:
        """Process a single workspace event and return continue-session signal."""
        value = (event.value or "").strip()
        if not value:
            return True

        if event.kind == "command":
            return self._process_workspace_command(value)

        if self._workspace_history and self._workspace_history[-1].strip():
            self._workspace_history.append("")
        self._workspace_history.append(f"You: {value}")
        reply = self._run_agent(self._agent_id, value)
        if isinstance(reply, tuple) and len(reply) == 2:
            reply_text, status_lines = reply
            for line in status_lines:
                self._workspace_history.append(f"  - {line}")
            self._workspace_history.append(f"Agent: {reply_text or 'Run finished.'}")
        elif isinstance(reply, str) and reply.strip():
            self._workspace_history.append(f"Agent: {reply}")
        else:
            self._workspace_history.append("Agent: Run finished.")
        return True

    def _process_workspace_command(self, value: str) -> bool:
        """Process a workspace slash command event."""
        if self._should_clear_terminal_before_workspace_route(value):
            self._clear_terminal_before_workspace_route()

        self._in_workspace_command = True
        try:
            return bool(self._handle_slash_command(value, self._agent_id))
        finally:
            self._in_workspace_command = False

    @staticmethod
    def _should_clear_terminal_before_workspace_route(value: str) -> bool:
        """Return True for routed workspace commands that launch separate TUI apps."""
        command = (str(value or "").strip().split(maxsplit=1)[0] or "").lower()
        return command in {"/agents", "/runs", "/schedules", "/prompt"}

    def _clear_terminal_before_workspace_route(self) -> None:
        """Clear terminal buffer to avoid stale non-TUI flashes between TUI app lifecycles."""
        try:
            if getattr(self.console, "is_terminal", False):
                self.console.clear()
        except Exception:
            pass

    def _workspace_details(self) -> AgentWorkspaceDetails:
        """Build details payload for workspace shell render."""
        tools = self._coerce_items(getattr(self.agent, "tools", None))
        mcps = self._coerce_items(getattr(self.agent, "mcps", None))
        sub_agents = self._coerce_items(getattr(self.agent, "agents", None))
        account_id = str(getattr(self.agent, "account_id", "") or "").strip()
        account_name = self._resolve_active_account_name()
        if not account_id:
            account_id = account_name
            account_display = account_id
        else:
            account_display = self._format_name_id(account_name, account_id) if account_name else account_id

        description = self._resolve_workspace_description()

        return AgentWorkspaceDetails(
            id=self._agent_id,
            name=self._agent_name,
            account_id=account_display,
            description=description,
            type=str(getattr(self.agent, "type", "") or ""),
            framework=str(getattr(self.agent, "framework", "") or ""),
            version=str(getattr(self.agent, "version", "") or ""),
            model_label=self._extract_model_label(getattr(self.agent, "agent_config", None)),
            tools_summary=str(len(tools)),
            mcps_summary=str(len(mcps)),
            sub_agents_summary=str(len(sub_agents)),
            tool_names=tuple(
                self._extract_item_name(item, fallback_prefix="tool", index=idx) for idx, item in enumerate(tools, 1)
            ),
            mcp_names=tuple(
                self._extract_item_name(item, fallback_prefix="mcp", index=idx) for idx, item in enumerate(mcps, 1)
            ),
            sub_agent_names=tuple(
                self._extract_item_name(item, fallback_prefix="sub-agent", index=idx)
                for idx, item in enumerate(sub_agents, 1)
            ),
            updated_at=str(getattr(self.agent, "updated_at", "") or ""),
        )

    def _resolve_workspace_description(self) -> str:
        """Resolve sidebar description from agent shell object, then details payload."""
        description = str(getattr(self.agent, "description", "") or "").strip()
        if description:
            return description
        try:
            payload = self._load_workspace_details_payload()
        except Exception:
            return ""
        if not isinstance(payload, dict):
            return ""
        return self._extract_payload_description(payload)

    @staticmethod
    def _coerce_items(values: Any) -> list[Any]:
        return values if isinstance(values, list) else []

    @staticmethod
    def _extract_item_name(item: Any, *, fallback_prefix: str, index: int) -> str:
        if isinstance(item, str):
            candidate = item
        elif isinstance(item, dict):
            candidate = item.get("name")
        else:
            candidate = getattr(item, "name", None)

        text = str(candidate or "").strip()
        if text:
            return text
        return f"{fallback_prefix}-{index}"

    def _resolve_active_account_name(self) -> str:
        getter = getattr(self.session, "_get_account_context", None)
        if not callable(getter):
            return ""
        try:
            account_context = getter()
        except Exception:
            return ""
        if not isinstance(account_context, tuple) or len(account_context) < 1:
            return ""
        active_name = account_context[0]
        return str(active_name or "").strip()

    @staticmethod
    def _extract_model_label(agent_config: Any) -> str:
        if isinstance(agent_config, dict):
            provider = str(agent_config.get("lm_provider") or "").strip()
            model = str(agent_config.get("lm_name") or "").strip()
        else:
            provider = str(getattr(agent_config, "lm_provider", "") or "").strip()
            model = str(getattr(agent_config, "lm_name", "") or "").strip()

        if not model:
            return ""
        if provider:
            return f"{provider}/{model}"
        return model

    @staticmethod
    def _compact_status_lines(rendered: str, *, max_lines: int = 6) -> list[str]:
        """Extract compact status lines suitable for workspace transcript history."""
        lines: list[str] = []
        for raw_line in rendered.splitlines():
            without_ansi = AgentRunSession._ANSI_RE.sub("", raw_line)
            line = " ".join(without_ansi.strip().split())
            if not line:
                continue
            if line.lower().startswith("next actions"):
                continue
            if line.startswith("/") or line.startswith("›"):
                continue
            if line.lower().startswith("hint:"):
                continue
            if not any(ch.isalnum() for ch in line):
                continue
            lines.append(line)
            if len(lines) >= max_lines:
                break
        return lines

    @staticmethod
    def _workspace_status_lines(compact_lines: list[str]) -> list[str]:
        """Normalize compact status lines for readable workspace transcript display."""
        normalized: list[str] = []
        home_dir = os.path.expanduser("~")
        endpoint_url = ""
        endpoint_note = ""

        for raw in compact_lines:
            line = AgentRunSession._normalize_workspace_status_line(raw)
            if line is None or AgentRunSession._should_skip_workspace_status_line(line):
                continue

            handled, endpoint_url, endpoint_note, parsed_lines = AgentRunSession._handle_workspace_status_body_line(
                line=line,
                home_dir=home_dir,
                endpoint_url=endpoint_url,
                endpoint_note=endpoint_note,
            )
            if handled:
                normalized.extend(parsed_lines)
                continue

            normalized.append(AgentRunSession._normalize_workspace_resources_line(line))

        AgentRunSession._insert_workspace_endpoint_line(
            normalized=normalized,
            endpoint_url=endpoint_url,
            endpoint_note=endpoint_note,
        )

        return AgentRunSession._dedupe_workspace_status_lines(normalized)

    @staticmethod
    def _handle_workspace_status_body_line(
        *,
        line: str,
        home_dir: str,
        endpoint_url: str,
        endpoint_note: str,
    ) -> tuple[bool, str, str, list[str]]:
        account_line, account_endpoint = AgentRunSession._parse_workspace_account_line(line)
        if account_line is not None:
            next_endpoint = endpoint_url
            next_note = endpoint_note
            if account_endpoint:
                next_endpoint = account_endpoint
                next_note = ""
            return True, next_endpoint, next_note, [account_line]

        api_endpoint = AgentRunSession._parse_workspace_api_line(line)
        if api_endpoint is not None:
            return True, api_endpoint, "", []

        base_endpoint, base_note, has_base_line = AgentRunSession._parse_workspace_base_line(line)
        if has_base_line:
            if endpoint_url and base_endpoint == endpoint_url:
                return True, endpoint_url, base_note, []
            if base_endpoint:
                endpoint_line = AgentRunSession._build_workspace_endpoint_line(base_endpoint, base_note)
                return True, endpoint_url, endpoint_note, [endpoint_line]
            return True, endpoint_url, endpoint_note, []

        transcript_lines = AgentRunSession._parse_workspace_saved_transcripts_line(line, home_dir)
        if transcript_lines is not None:
            return True, endpoint_url, endpoint_note, transcript_lines

        return False, endpoint_url, endpoint_note, []

    @staticmethod
    def _insert_workspace_endpoint_line(*, normalized: list[str], endpoint_url: str, endpoint_note: str) -> None:
        if not endpoint_url:
            return

        endpoint_line = AgentRunSession._build_workspace_endpoint_line(endpoint_url, endpoint_note)
        insert_at = 1 if normalized and normalized[0].startswith(AgentRunSession._STATUS_ACCOUNT_PREFIX) else 0
        normalized.insert(insert_at, endpoint_line)

    @staticmethod
    def _normalize_workspace_status_line(raw: str) -> str | None:
        line = raw.strip()
        if not line:
            return None
        if line.startswith(AgentRunSession._STATUS_BULLET_PREFIX):
            return line[len(AgentRunSession._STATUS_BULLET_PREFIX) :]
        return line

    @staticmethod
    def _should_skip_workspace_status_line(line: str) -> bool:
        lower = line.lower()
        return lower == AgentRunSession._STATUS_HEADER_LINE or AgentRunSession._STATUS_FETCHING_TOKEN in lower

    @staticmethod
    def _parse_workspace_account_line(line: str) -> tuple[str | None, str]:
        if not line.startswith(AgentRunSession._STATUS_ACCOUNT_PREFIX):
            return None, ""
        account_part, sep, api_part = line.partition(" · API URL: ")
        return account_part, api_part.strip() if sep and api_part else ""

    @staticmethod
    def _parse_workspace_api_line(line: str) -> str | None:
        if not line.startswith(AgentRunSession._STATUS_API_PREFIX):
            return None
        return line.replace(AgentRunSession._STATUS_API_PREFIX, "", 1).strip()

    @staticmethod
    def _parse_workspace_base_line(line: str) -> tuple[str, str, bool]:
        if not line.startswith(AgentRunSession._STATUS_BASE_PREFIX):
            return "", "", False

        base_body = line.replace(AgentRunSession._STATUS_BASE_PREFIX, "", 1).strip()
        if " (" in base_body and base_body.endswith(")"):
            base_url, _, suffix = base_body.partition(" (")
            return base_url.strip(), suffix[:-1].strip(), True
        return base_body.strip(), "", True

    @staticmethod
    def _parse_workspace_saved_transcripts_line(line: str, home_dir: str) -> list[str] | None:
        prefix = AgentRunSession._STATUS_SAVED_TRANSCRIPTS_PREFIX
        if not line.startswith(prefix):
            return None

        summary_part, sep, path_part = line.rpartition(" · ")
        summary = summary_part if sep else line
        normalized_summary = summary.replace(prefix, AgentRunSession._STATUS_TRANSCRIPTS_PREFIX, 1)

        if not sep:
            return [normalized_summary]

        cache_path = AgentRunSession._normalize_workspace_cache_path(path_part, home_dir)
        return [normalized_summary, f"{AgentRunSession._STATUS_CACHE_DIR_PREFIX} {cache_path}"]

    @staticmethod
    def _normalize_workspace_cache_path(path: str, home_dir: str) -> str:
        cache_path = path
        if cache_path.startswith(home_dir):
            return f"~{cache_path[len(home_dir) :]}"
        return cache_path

    @staticmethod
    def _normalize_workspace_resources_line(line: str) -> str:
        if line.startswith(AgentRunSession._STATUS_RESOURCES_PREFIX):
            return line.replace(",", " ·")
        return line

    @staticmethod
    def _build_workspace_endpoint_line(endpoint_url: str, endpoint_note: str) -> str:
        endpoint_line = f"{AgentRunSession._STATUS_ENDPOINT_PREFIX} {endpoint_url}"
        if endpoint_note:
            return f"{endpoint_line} ({endpoint_note})"
        return endpoint_line

    @staticmethod
    def _dedupe_workspace_status_lines(lines: list[str], *, limit: int = 8) -> list[str]:
        # Preserve order while removing duplicates and limiting line count.
        deduped: list[str] = []
        for line in lines:
            if line in deduped:
                continue
            deduped.append(line)
            if len(deduped) >= limit:
                break
        return deduped

    def _display_agent_info(self) -> None:
        """Display agent information and summary."""
        self.session._render_header(self.agent, focus_agent=True)

    def _run_agent_loop(self) -> None:
        """Run the main agent interaction loop."""
        while True:
            raw = self._get_user_input()
            if raw is None:
                return

            raw = raw.strip()
            if not raw:
                continue

            if raw.startswith("/"):
                if not self._handle_slash_command(raw, self._agent_id):
                    return
                continue

            self._run_agent(self._agent_id, raw)

    def _get_user_input(self) -> str | None:
        """Get user input with proper error handling."""
        try:

            def _prompt_message() -> Any:
                """Get formatted prompt message for agent session."""
                prompt_prefix = f"{self._agent_name} ({self._agent_id}) "

                # Use FormattedText if prompt_toolkit is available, otherwise use simple string
                if _HAS_PROMPT_TOOLKIT and FormattedText is not None:
                    segments = [
                        ("class:prompt", prompt_prefix),
                        ("class:prompt", "\n› "),
                    ]
                    return FormattedText(segments)

                return f"{prompt_prefix}\n› "

            raw = self.session._prompt(
                _prompt_message,
                placeholder=self._prompt_placeholder,
            )
            if self._prompt_placeholder:
                # Show the guidance once, then fall back to a clean prompt.
                self._prompt_placeholder = ""
            return raw
        except EOFError:
            self.console.print("\nExiting agent context.")
            return None
        except KeyboardInterrupt:
            self.console.print("")
            return ""

    def _handle_slash_command(self, raw: str, agent_id: str) -> bool:
        """Handle slash commands in agent context. Returns False if should exit."""
        # Handle simple commands first
        if raw == "/":
            return self._handle_help_command()

        verb, args = self.session._parse(raw)
        if verb in {"exit", "back", "q"}:
            return self._handle_exit_command()

        if verb == "details":
            return self._handle_details_command(agent_id)

        if verb == "prompt":
            return self._handle_prompt_command(agent_id)

        if verb == "runs":
            return self._handle_runs_command(args)

        if verb == "schedules":
            return self._handle_schedules_command(args)

        if verb == "status":
            return self._handle_status_command(args)

        if verb in {"help", "?"}:
            return self._handle_help_command()
        if verb == "accounts":
            return bool(self.session._cmd_accounts(args, True))
        if verb == "transcripts":
            return bool(self.session._cmd_transcripts(args, True))
        if verb == "agents":
            return bool(self.session._cmd_agents(args, True))
        if verb == "update":
            return bool(self.session._cmd_update(args, True))

        # Handle other commands through the main session
        return self._handle_other_command(raw)

    def _handle_help_command(self) -> bool:
        """Handle help command."""
        self.session._cmd_help([], True)
        return True

    def _handle_exit_command(self) -> bool:
        """Handle exit command."""
        self.console.print("[dim]Returning to the main prompt.[/dim]")
        return False

    def _handle_details_command(self, agent_id: str) -> bool:
        """Handle details command."""
        self._show_details(agent_id)
        return True

    def _handle_prompt_command(self, agent_id: str) -> bool:
        """Open the prompt editor for this agent."""
        previous_instruction = str(getattr(self.agent, "instruction", "") or "")
        try:
            updated = self._edit_agent_instruction(agent_id)
            self._finalize_prompt_command_update(updated, previous_instruction=previous_instruction)
        except click.ClickException as exc:
            self._handle_prompt_command_failure(exc, click_error=True)
        except Exception as exc:  # pragma: no cover - defensive
            self._handle_prompt_command_failure(exc, click_error=False)
        return self.session is not None

    def _finalize_prompt_command_update(self, updated: Any | None, *, previous_instruction: str) -> None:
        """Apply prompt editor result and refresh UI/workspace history."""
        if updated is None:
            self._record_workspace_prompt_outcome("cancelled")
            return

        self.agent = updated
        self.session._current_agent = updated
        current_instruction = str(getattr(updated, "instruction", "") or "")
        if self._in_workspace_command:
            outcome = "saved" if current_instruction != previous_instruction else "unchanged"
            self._record_workspace_prompt_outcome(outcome)
            return

        self._refresh_prompt_mode_header(updated)

    def _record_workspace_prompt_outcome(self, outcome: str) -> None:
        """Append prompt command outcome row in workspace mode."""
        self._record_workspace_page_outcome(self._PROMPT_COMMAND, outcome)

    def _record_workspace_page_outcome(self, command: str, outcome: str) -> None:
        """Append standardized page command outcome row in workspace mode."""
        if not self._in_workspace_command:
            return
        normalized_command = str(command or "").strip().split(maxsplit=1)[0].lower()
        if not normalized_command.startswith("/"):
            normalized_command = f"/{normalized_command}"
        self._append_workspace_status(f"{normalized_command} {outcome}")

    def _refresh_prompt_mode_header(self, updated: Any) -> None:
        """Refresh classic prompt header after prompt edits are saved."""
        # Workspace-mode flow restores its own TUI surface immediately.
        try:
            if getattr(self.session.console, "is_terminal", False):
                self.session.console.clear()
        except Exception:
            pass
        try:
            self.session._render_header(updated, focus_agent=True)
        except Exception:
            pass

    def _handle_prompt_command_failure(self, exc: Exception, *, click_error: bool) -> None:
        """Render prompt edit failures and record workspace status."""
        if click_error:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")
        else:
            self.console.print(f"[{ERROR_STYLE}]Failed to edit prompt: {exc}[/]")
        if self._in_workspace_command:
            self._append_workspace_status(f"{self._PROMPT_COMMAND} failed: {exc}")

    def _handle_runs_command(self, args: list[str]) -> bool:
        """Handle /runs command with explicit agent-context routing."""
        handled = bool(self.session._cmd_runs(args, True))
        if handled:
            self._record_workspace_page_outcome(self._RUNS_COMMAND, "closed")
        return handled

    def _handle_schedules_command(self, args: list[str]) -> bool:
        """Handle /schedules command with explicit agent-context routing."""
        handled = bool(self.session._cmd_schedules(args, True))
        if handled:
            self._record_workspace_page_outcome(self._SCHEDULES_COMMAND, "closed")
        return handled

    def _handle_status_command(self, args: list[str]) -> bool:
        """Handle /status command with explicit agent-context routing."""
        if not self._in_workspace_command:
            return bool(self.session._cmd_status(args, True))
        status_lines = self._collect_status_summary_lines(args)
        if status_lines:
            self._workspace_history.append("Cmd: /status")
            self._workspace_history.extend(f"status: {line}" for line in status_lines)
        return True

    def _collect_status_summary_lines(self, args: list[str] | None = None) -> list[str]:
        """Collect compact status lines without printing raw output to terminal."""
        status_args = args if args is not None else []
        with self.session.console.capture() as capture:
            self.session._cmd_status(status_args, True)
        compact_lines = self._compact_status_lines(capture.get())
        return self._workspace_status_lines(compact_lines)

    def _collect_details_lines(self) -> list[str]:
        """Collect workspace-ready details lines using raw payload data with grouped sections."""
        payload = self._load_workspace_details_payload()
        masked = mask_payload(payload)
        if not isinstance(masked, dict):
            masked = payload
        normalized = self._normalize_details_payload(masked)

        sentinel = self._WORKSPACE_DETAILS_SENTINEL
        agent_name = normalized.get("name") or self._agent_name or "Agent"
        account_display = normalized.get("account") or "-"
        lines = [f"{sentinel}{agent_name}", f"{sentinel}\u0000ACCOUNT\u0000{account_display}"]
        tool_configs = normalized.get("tool_configs") or {}
        mcp_configs = normalized.get("mcp_configs") or {}

        for group_name, group_keys in self._DETAILS_GROUPS:
            if not self._group_has_details_content(normalized, group_keys):
                continue
            lines.append(f"{sentinel}")
            lines.append(f"{sentinel}[{group_name}]")
            lines.extend(
                self._render_details_group_lines(
                    group_name=group_name,
                    group_keys=group_keys,
                    normalized=normalized,
                    tool_configs=tool_configs,
                    mcp_configs=mcp_configs,
                    sentinel=sentinel,
                )
            )

        return lines

    @classmethod
    def _group_has_details_content(cls, normalized: dict[str, Any], group_keys: tuple[str, ...]) -> bool:
        """Return True when at least one key in a details group should render."""
        for key in group_keys:
            if key in {"tools", "mcps"}:
                if key in normalized:
                    return True
                continue
            if key in normalized and key not in cls._DETAILS_EXCLUDED_KEYS:
                return True
        return False

    @staticmethod
    def _is_empty_details_value(value: Any) -> bool:
        """Return True for values that should be skipped in details output."""
        return value in (None, {}, [], "")

    def _render_details_group_lines(
        self,
        *,
        group_name: str,
        group_keys: tuple[str, ...],
        normalized: dict[str, Any],
        tool_configs: dict[str, Any],
        mcp_configs: dict[str, Any],
        sentinel: str,
    ) -> list[str]:
        """Render all detail lines for one details section."""
        lines: list[str] = []
        for key in group_keys:
            if group_name == "Overview" and key == "name":
                continue
            resolved = self._resolve_group_detail_value(key, normalized, tool_configs, mcp_configs)
            if resolved is None:
                continue
            value, skip_key = resolved
            detail_lines = self._render_details_key_lines(key, value, indent=0, skip_key=skip_key)
            lines.extend(f"{sentinel}{detail_line}" for detail_line in detail_lines)
        if not lines:
            lines.append(f"{sentinel}- none")
        return lines

    def _resolve_group_detail_value(
        self,
        key: str,
        normalized: dict[str, Any],
        tool_configs: dict[str, Any],
        mcp_configs: dict[str, Any],
    ) -> tuple[Any, bool] | None:
        """Resolve a grouped details key into render value and skip-key mode."""
        if key == "tools":
            if "tools" not in normalized:
                return None
            tools = normalized.get("tools") or []
            return self._merge_tools_with_configs(tools, tool_configs), True

        if key == "mcps":
            if "mcps" not in normalized:
                return None
            mcps = normalized.get("mcps") or []
            return self._merge_tools_with_configs(mcps, mcp_configs), True

        if key not in normalized or key in self._DETAILS_EXCLUDED_KEYS:
            return None

        value = normalized.get(key)
        if key == "description" and self._is_empty_details_value(value):
            return "-", False
        if self._is_empty_details_value(value):
            return None
        return value, False

    @classmethod
    def _normalize_details_payload(cls, payload: dict[str, Any]) -> dict[str, Any]:
        """Normalize payload into display-oriented structure for workspace details."""
        normalized = dict(payload)

        if "description" not in normalized:
            normalized["description"] = ""

        account_name = str(normalized.pop("account_name", "") or "").strip()
        account_id = str(normalized.pop("account_id", "") or "").strip()
        account_display = cls._format_name_id(account_name, account_id)
        if account_display:
            normalized["account"] = account_display

        language_model_name = str(normalized.get("language_model", "") or "").strip()
        language_model_id = str(normalized.pop("language_model_id", "") or "").strip()
        language_model_display = cls._format_name_id(language_model_name, language_model_id)
        if language_model_display:
            normalized["language_model"] = language_model_display

        return normalized

    def _render_details_key_lines(self, key: str, value: Any, *, indent: int, skip_key: bool = False) -> list[str]:
        """Render top-level details key into one or multiple display lines."""
        prefix = " " * indent
        if isinstance(value, list):
            lines = []
            if not skip_key:
                lines.append(f"{prefix}{key}:")
            lines.extend(self._render_details_list_items(value, indent=indent + (0 if skip_key else 2)))
            return lines
        if isinstance(value, dict):
            lines = []
            if not skip_key:
                lines.append(f"{prefix}{key}:")
            lines.extend(self._render_details_dict_items(value, indent=indent + (0 if skip_key else 2)))
            return lines
        value_text = self._summarize_details_value(key, value)
        return [f"{prefix}{key}: {value_text}"]

    def _render_details_list_items(self, values: list[Any], *, indent: int) -> list[str]:
        """Render list values as full bullet lines without list-size trimming."""
        prefix = " " * indent
        if not values:
            return [f"{prefix}- none"]

        lines: list[str] = []
        for item in values:
            lines.extend(self._render_details_list_item(item, prefix=prefix, indent=indent))
        return lines

    def _render_details_list_item(self, item: Any, *, prefix: str, indent: int) -> list[str]:
        """Render one list item as one or more display lines."""
        if isinstance(item, dict):
            return self._render_details_mapping_list_item(item, prefix=prefix, indent=indent)
        if isinstance(item, list):
            nested = self._render_details_list_items(item, indent=indent + 2)
            return [f"{prefix}-", *nested]

        label = self._extract_details_item_label(item)
        if label:
            return [f"{prefix}- {label}"]

        scalar = " ".join(str(item).split())
        return [f"{prefix}- {scalar or '-'}"]

    def _render_details_mapping_list_item(self, item: dict[str, Any], *, prefix: str, indent: int) -> list[str]:
        """Render one mapping entry in a details list."""
        name = str(item.get("name") or "").strip()
        ident = str(item.get("id") or "").strip()
        label = self._format_name_id(name, ident)
        if not label:
            return [f"{prefix}-", *self._render_details_dict_items(item, indent=indent + 2)]

        remaining = {k: v for k, v in item.items() if k not in {"name", "id"}}
        lines = [f"{prefix}- {label}"]
        if remaining:
            lines.extend(self._render_details_dict_items(remaining, indent=indent + 2))
        return lines

    def _extract_details_item_label(self, item: Any) -> str:
        """Extract `<name> (<id>)` label from object-like list items when available."""
        name_attr = str(getattr(item, "name", "") or "").strip()
        id_attr = str(getattr(item, "id", "") or "").strip()
        return self._format_name_id(name_attr, id_attr)

    def _render_details_dict_items(self, mapping: dict[str, Any], *, indent: int) -> list[str]:
        """Render dictionary values as hierarchical bullet groups."""
        prefix = " " * indent
        if not mapping:
            return [f"{prefix}- {{}}"]

        lines: list[str] = []
        for child_key in self._ordered_details_child_keys(mapping):
            child_value = mapping.get(child_key)
            if isinstance(child_value, list):
                lines.append(f"{prefix}- {child_key}:")
                lines.extend(self._render_details_list_items(child_value, indent=indent + 2))
                continue
            if isinstance(child_value, dict):
                lines.append(f"{prefix}- {child_key}:")
                lines.extend(self._render_details_dict_items(child_value, indent=indent + 2))
                continue
            lines.append(f"{prefix}- {child_key}: {self._summarize_details_value(child_key, child_value)}")
        return lines

    @classmethod
    def _ordered_details_child_keys(cls, mapping: dict[str, Any]) -> list[str]:
        """Return nested mapping keys with preferred semantic ordering."""
        ordered: list[str] = []
        seen: set[str] = set()
        for key in cls._DETAILS_CHILD_KEY_PRIORITY:
            if key in mapping:
                ordered.append(key)
                seen.add(key)
        for key in sorted(mapping.keys()):
            if key in seen:
                continue
            ordered.append(key)
        return ordered

    @staticmethod
    def _format_name_id(name: str, identifier: str) -> str:
        """Return normalized `<name> (<id>)` display when one or both are available."""
        normalized_name = " ".join(str(name or "").split()).strip()
        normalized_id = " ".join(str(identifier or "").split()).strip()
        if normalized_name and normalized_id:
            return f"{normalized_name} ({normalized_id})"
        return normalized_name or normalized_id

    @staticmethod
    def _merge_tools_with_configs(tools: list[Any], configs: dict[str, Any]) -> list[dict[str, Any]]:
        """Merge tool list with their configs by ID to eliminate redundancy.

        Each tool dict gets an additional "config" key with its corresponding
        configuration from the configs dict.
        """
        if not tools:
            return []

        merged = []
        for tool in tools:
            if isinstance(tool, dict):
                tool_id = str(tool.get("id") or "").strip()
                tool_copy = dict(tool)
                if tool_id and tool_id in configs:
                    tool_copy["config"] = configs[tool_id]
                merged.append(tool_copy)
            else:
                # Handle non-dict tool items gracefully
                merged.append({"value": tool})
        return merged

    def _load_workspace_details_payload(self) -> dict[str, Any]:
        """Return raw agent payload for `/details`, with safe fallback on failures."""
        active_account_name = self._resolve_active_account_name()
        try:
            client = get_client(self.session.ctx)
            payload = self._fetch_workspace_payload(client)
            if isinstance(payload, dict):
                self._enrich_workspace_payload(payload, client, active_account_name=active_account_name)
                return payload
        except Exception:
            pass
        return self._fallback_details_payload(active_account_name=active_account_name)

    def _fetch_workspace_payload(self, client: Any) -> dict[str, Any] | None:
        """Fetch agent details payload from primary resource, then API fallback."""
        raw = fetch_raw_resource_details(client, self.agent, "agents")
        if isinstance(raw, dict):
            return dict(raw)

        fetched = client.agents.get_agent_by_id(self._agent_id)
        if fetched is None:
            return None
        fallback_raw = fetch_raw_resource_details(client, fetched, "agents")
        if not isinstance(fallback_raw, dict):
            return None
        return dict(fallback_raw)

    def _enrich_workspace_payload(
        self,
        payload: dict[str, Any],
        client: Any,
        *,
        active_account_name: str,
    ) -> None:
        """Apply account/model/timestamp normalization to fetched details payload."""
        description = self._extract_payload_description(payload)
        if not description:
            description = str(getattr(self.agent, "description", "") or "").strip()
        if description:
            payload["description"] = description

        if active_account_name:
            payload["account_name"] = active_account_name

        language_model = self._resolve_language_model_display(client, payload)
        if language_model:
            payload["language_model"] = language_model

        self._normalize_workspace_timestamps(payload)

    @staticmethod
    def _extract_payload_description(payload: dict[str, Any]) -> str:
        """Extract description from common payload key variants."""
        for key in ("description", "agent_description", "desc"):
            value = str(payload.get(key) or "").strip()
            if value:
                return value
        return ""

    @staticmethod
    def _normalize_workspace_timestamps(payload: dict[str, Any]) -> None:
        """Best-effort UTC timestamp normalization for details payload."""
        for field in ("created_at", "updated_at"):
            value = payload.get(field)
            if value in (None, ""):
                continue
            try:
                payload[field] = format_utc_timestamp(value)
            except Exception:
                payload[field] = value

    def _resolve_language_model_display(self, client: Any, payload: dict[str, Any]) -> str:
        """Resolve human-friendly model display from payload and model catalog."""
        fallback = self._extract_model_label(payload.get("agent_config"))
        language_model_id = str(payload.get("language_model_id") or "").strip()
        if not language_model_id:
            return fallback

        catalog = self._list_language_model_catalog(client)
        if not isinstance(catalog, list):
            return fallback

        resolved = self._resolve_catalog_model_display(catalog, language_model_id)
        return resolved or fallback

    @staticmethod
    def _list_language_model_catalog(client: Any) -> list[Any] | None:
        """Return model catalog list when available, otherwise None."""
        try:
            list_models = getattr(client, "list_language_models", None)
            if not callable(list_models):
                return None
            catalog = list_models()
        except Exception:
            return None
        if not isinstance(catalog, list):
            return None
        return catalog

    @classmethod
    def _resolve_catalog_model_display(cls, catalog: list[Any], language_model_id: str) -> str:
        """Resolve provider/name display from catalog by model id."""
        for model in catalog:
            display = cls._resolve_single_catalog_model_display(model, language_model_id)
            if display is None:
                continue
            return display
        return ""

    @staticmethod
    def _resolve_single_catalog_model_display(model: Any, language_model_id: str) -> str | None:
        """Return display for one catalog model entry.

        Returns:
            - display string when `model` matches and has a renderable name
            - empty string when `model` matches but has no renderable name
            - None when `model` should be skipped
        """
        if not isinstance(model, dict):
            return None
        if str(model.get("id") or "").strip() != language_model_id:
            return None

        provider = str(model.get("provider") or "").strip()
        name = str(model.get("name") or "").strip()
        if provider and name:
            return f"{provider}/{name}"
        if name:
            return name
        return ""

    def _fallback_details_payload(self, *, active_account_name: str = "") -> dict[str, Any]:
        """Build a minimal payload when raw fetch is unavailable."""
        account_name = active_account_name or self._resolve_active_account_name()
        account_id = str(getattr(self.agent, "account_id", "") or "").strip() or account_name
        model_label = self._extract_model_label(getattr(self.agent, "agent_config", None))
        return {
            "id": self._agent_id,
            "name": self._agent_name,
            "account_name": account_name,
            "account_id": account_id,
            "type": str(getattr(self.agent, "type", "") or ""),
            "framework": str(getattr(self.agent, "framework", "") or ""),
            "version": str(getattr(self.agent, "version", "") or ""),
            "language_model": model_label,
            "description": str(getattr(self.agent, "description", "") or ""),
            "instruction": str(getattr(self.agent, "instruction", "") or ""),
            "agent_config": getattr(self.agent, "agent_config", None),
            "metadata": getattr(self.agent, "metadata", None),
            "tools": self._coerce_items(getattr(self.agent, "tools", None)),
            "mcps": self._coerce_items(getattr(self.agent, "mcps", None)),
            "created_at": str(getattr(self.agent, "created_at", "") or ""),
            "updated_at": str(getattr(self.agent, "updated_at", "") or ""),
        }

    def _summarize_details_value(self, key: str, value: Any) -> str:
        """Summarize details values into a single-line transcript-friendly string."""
        lowered = str(key or "").strip().lower()

        if value is None:
            return "null"

        if lowered == "instruction":
            return self._summarize_instruction_value(value)

        if isinstance(value, bool):
            return "true" if value else "false"
        if isinstance(value, (int, float)):
            return str(value)
        if isinstance(value, str):
            return self._summarize_string_value(value)
        if isinstance(value, list):
            return self._summarize_list_value(value)
        if isinstance(value, dict):
            return self._summarize_dict_value(value)

        return self._summarize_string_value(str(value))

    def _summarize_instruction_value(self, value: Any) -> str:
        """Summarize agent instruction with a link to /prompt."""
        raw = " ".join(str(value or "").split())
        if not raw:
            return "-"
        # Keep workspace transcript readable even when the global preview limit is larger.
        limit = min(240, max(0, int(self._instruction_preview_limit)))
        if limit <= 0 or len(raw) <= limit:
            return raw
        preview_text = raw[:limit].rstrip()
        return f"{preview_text} ... (trimmed; len={len(raw)}; open /prompt)"

    @staticmethod
    def _summarize_string_value(value: str) -> str:
        """Normalize and trim long strings."""
        normalized = " ".join(value.split())
        if not normalized:
            return "-"
        if len(normalized) <= 120:
            return normalized
        return f"{normalized[:120].rstrip()} ... (trimmed; len={len(normalized)})"

    @staticmethod
    def _summarize_list_value(value: list[Any]) -> str:
        """Summarize list items and length."""
        if not value:
            return "[] (len=0)"
        list_preview: list[str] = []
        for item in value[:3]:
            if isinstance(item, dict):
                label = str(item.get("name") or item.get("type") or item.get("id") or "item").strip()
            else:
                label = str(getattr(item, "name", None) or getattr(item, "id", None) or item).strip()
            list_preview.append(" ".join(label.split()) or "item")
        suffix = "" if len(value) <= 3 else f", +{len(value) - 3} more"
        return f"[{', '.join(list_preview)}{suffix}] (len={len(value)})"

    @staticmethod
    def _summarize_dict_value(value: dict[str, Any]) -> str:
        """Summarize dictionary keys and length."""
        keys = [str(k).strip() for k in value.keys()]
        if not keys:
            return "{} (keys=0)"
        preview_keys = keys[:6]
        suffix = "" if len(keys) <= 6 else f", +{len(keys) - 6} more"
        return f"{{{', '.join(preview_keys)}{suffix}}} (keys={len(keys)})"

    def _edit_agent_instruction(self, agent_id: str) -> Any | None:
        """Launch TUI editor and update the agent instruction if saved.

        Returns:
            Updated agent object when saved, otherwise None.
        """
        client = get_client(self.session.ctx)
        agent_obj = client.get_agent_by_id(agent_id)
        if agent_obj is None:
            raise click.ClickException(f"Agent '{agent_id}' not found")

        resolved_agent_id: str = str(getattr(agent_obj, "id", agent_id) or agent_id)
        current = getattr(agent_obj, "instruction", "") or ""

        def save_instruction(new_instruction: str) -> Any:
            return client.agents.update_agent(resolved_agent_id, instruction=new_instruction)

        if not _TEXTUAL_SUPPORTED or not getattr(self.console, "is_terminal", False):
            return self._edit_agent_instruction_with_editor(current, save_instruction)

        payload = AgentPromptEditorInput(
            agent_id=resolved_agent_id,
            agent_name=str(getattr(agent_obj, "name", "") or resolved_agent_id),
            instruction=current,
        )
        tui_ctx = getattr(self.session, "tui_ctx", None)
        updated = run_agent_prompt_editor_textual(payload, save_instruction, ctx=tui_ctx)
        if updated is None:
            return None
        self.console.print(f"[{HINT_PREFIX_STYLE}]Saved:[/] Updated agent prompt.")
        return updated

    def _edit_agent_instruction_with_editor(self, current: str, save_instruction: Any) -> Any | None:
        """Fallback editor loop for non-TTY environments.

        Args:
            current: Current instruction text.
            save_instruction: Callable that persists new instruction text.

        Returns:
            Updated agent object when saved, otherwise None.
        """
        updated_agent: Any | None = None
        while True:
            edited = click.edit(current)
            if edited is None:
                return updated_agent
            if isinstance(edited, bytes):
                edited_text = edited.decode("utf-8", errors="replace")
            else:
                edited_text = str(edited)
            if edited_text == current:
                self.console.print("[dim]No changes to save.[/dim]")
                return updated_agent
            if not click.confirm("Apply changes to this agent prompt?", default=False):
                self.console.print("[dim]Cancelled.[/dim]")
                return updated_agent
            updated_agent = save_instruction(edited_text)
            current = getattr(updated_agent, "instruction", edited_text) or edited_text
            self.console.print(f"[{HINT_PREFIX_STYLE}]Saved:[/] Updated agent prompt.")
            if not click.confirm("Keep editing?", default=False):
                return updated_agent

    def _handle_other_command(self, raw: str) -> bool:
        """Handle other commands through the main session."""
        self.session.handle_command(raw, invoked_from_agent=True)
        return not self.session._should_exit

    def _show_details(self, agent_id: str, *, enable_prompt: bool = True) -> None:
        """Render the agent's configuration export inside the command palette."""
        try:
            self.session.ctx.invoke(
                agents_get_command,
                agent_ref=agent_id,
                instruction_preview=self._instruction_preview_limit,
            )
            if enable_prompt:
                self._prompt_instruction_view_toggle(agent_id)
                self.console.print(
                    f"[{HINT_PREFIX_STYLE}]Tip:[/] Continue the conversation in this prompt, or use "
                    f"{format_command_hint('/help') or '/help'} for shortcuts."
                )
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")

    def _prompt_instruction_view_toggle(self, agent_id: str) -> None:
        """Offer a prompt to expand or collapse the instruction preview after details."""
        if not getattr(self.console, "is_terminal", False):
            return

        while True:
            mode = "expanded" if self._instruction_preview_limit == 0 else "trimmed"
            self.console.print(
                f"[dim]Instruction view is {mode}. Press t (or Ctrl+T) to toggle, Enter to continue.[/dim]"
            )
            try:
                ch = click.getchar()
            except (EOFError, KeyboardInterrupt):  # pragma: no cover - defensive guard
                return

            if not self._handle_instruction_toggle_input(agent_id, ch):
                break

        if self._instruction_preview_limit == 0:
            self._instruction_preview_limit = DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT
        self.console.print("")

    def _handle_instruction_toggle_input(self, agent_id: str, ch: str) -> bool:
        """Process a single toggle keypress; return False when the loop should exit."""
        if ch in {"\r", "\n"}:
            return False

        lowered = ch.lower()
        if lowered == "t" or ch == "\x14":  # support literal 't' or Ctrl+T
            self._instruction_preview_limit = (
                DEFAULT_AGENT_INSTRUCTION_PREVIEW_LIMIT if self._instruction_preview_limit == 0 else 0
            )
            self._show_details(agent_id, enable_prompt=False)
            return True

        # Ignore other keys and continue prompting.
        return True

    def _after_agent_run(self) -> None:
        """Handle transcript viewer behaviour after a successful run."""
        payload, manifest = self.session._get_last_transcript()
        if not self._transcript_matches(payload, manifest):
            return
        assert isinstance(manifest, dict)
        run_id = str(manifest.get("run_id") or "")
        mark_ready = getattr(self.session, "mark_agent_transcript_ready", None)
        if callable(mark_ready):
            mark_ready(self._agent_id, run_id)
        if self._open_transcript_viewer():
            return
        self.console.print("[dim]Transcript viewer is unavailable in this environment.[/dim]")

    def _transcript_matches(self, payload: Any, manifest: Any) -> bool:
        """Return True when the latest transcript belongs to this agent."""
        if not payload or not isinstance(manifest, dict):
            return False
        manifest_dict = cast(dict[str, Any], manifest)
        if not manifest_dict.get("run_id"):
            return False
        return manifest_dict.get("agent_id") == self._agent_id

    def _open_transcript_viewer(self) -> bool:
        """Launch the transcript viewer when terminal support is available."""
        if not getattr(self.console, "is_terminal", False):
            return False
        try:
            current_agent = getattr(self.session, "_current_agent", None)
            self.session.open_transcript_viewer(announce=True)
            if getattr(self.session.console, "is_terminal", False):
                try:
                    self.session.console.clear()
                except Exception:  # pragma: no cover - defensive cleanup
                    pass
                if current_agent is not None:  # pragma: no cover - UI refresh best effort
                    try:
                        self.session._render_header(current_agent, focus_agent=True)
                    except Exception:  # pragma: no cover - defensive cleanup
                        pass
            return True
        except Exception:  # pragma: no cover - defensive cleanup
            return False

    @contextmanager
    def _bind_session_context(self) -> Any:
        """Temporarily attach this slash session to the Click context."""
        with bind_slash_session_context(self.session.ctx, self.session):
            yield

    def _run_agent(
        self,
        agent_id: str,
        message: str,
        *,
        stream_status_callback: Callable[[str], None] | None = None,
        stream_reply_callback: Callable[[str], None] | None = None,
    ) -> str | tuple[str, list[str]] | None:
        """Execute the agents run command for the active agent."""
        if not message:
            return None

        try:
            self.session.notify_agent_run_started()
            if self._use_workspace_shell():
                if stream_status_callback is None and stream_reply_callback is None:
                    reply = self._run_agent_workspace_inline(agent_id, message)
                else:
                    reply = self._run_agent_workspace_inline(
                        agent_id,
                        message,
                        stream_status_callback=stream_status_callback,
                        stream_reply_callback=stream_reply_callback,
                    )
                self.session.last_run_input = message
                return reply

            with self._bind_session_context():
                self.session.ctx.invoke(
                    agents_run_command,
                    agent_ref=agent_id,
                    input_text=message,
                    verbose=False,
                )
            self.session.last_run_input = message
            self._after_agent_run()
            return None
        except click.ClickException as exc:
            self.console.print(f"[{ERROR_STYLE}]{exc}[/]")
            return None
        finally:
            try:
                self.session.notify_agent_run_finished()
            except Exception:
                pass

    def _run_agent_workspace_inline(
        self,
        agent_id: str,
        message: str,
        *,
        stream_status_callback: Callable[[str], None] | None = None,
        stream_reply_callback: Callable[[str], None] | None = None,
    ) -> tuple[str, list[str]]:
        """Run agent with a silent renderer so workspace stays in Textual surface."""
        with self._bind_session_context():
            client = get_client(self.session.ctx)
            renderer = make_silent_renderer()
            self._wire_workspace_stream_callbacks(
                renderer,
                user_message=message,
                stream_status_callback=stream_status_callback,
                stream_reply_callback=stream_reply_callback,
            )
            result = client.agents.run_agent(
                agent_id=agent_id,
                message=message,
                files=[],
                agent_name=self._agent_name,
                tty=False,
                renderer=renderer,
            )

            store_transcript_for_session(
                self.session.ctx,
                renderer,
                final_result=result,
                agent_id=agent_id or None,
                agent_name=self._agent_name,
                model=self._extract_model_label(getattr(self.agent, "agent_config", None)) or None,
                source="slash",
            )

        self._mark_workspace_transcript_ready()
        return self._format_workspace_agent_reply(result), self._collect_workspace_run_status_lines(
            user_message=message
        )

    def _wire_workspace_stream_callbacks(
        self,
        renderer: Any,
        *,
        user_message: str,
        stream_status_callback: Callable[[str], None] | None,
        stream_reply_callback: Callable[[str], None] | None,
    ) -> None:
        """Bridge renderer events into optional workspace status/reply stream callbacks."""
        if stream_status_callback is None and stream_reply_callback is None:
            return

        original_on_event = getattr(renderer, "on_event", None)
        if not callable(original_on_event):
            return

        stream_state = self._initial_workspace_stream_state(user_message=user_message)

        def _streaming_on_event(event: Any) -> None:
            original_on_event(event)
            self._emit_workspace_stream_event(
                event,
                stream_state=stream_state,
                stream_status_callback=stream_status_callback,
                stream_reply_callback=stream_reply_callback,
            )

        renderer.on_event = _streaming_on_event

    @staticmethod
    def _initial_workspace_stream_state(*, user_message: str) -> dict[str, Any]:
        """Initialize mutable per-run state for event-driven workspace streaming."""
        return {
            "rows": [],
            "pending_by_id": {},
            "pending_by_name": {},
            "normalized_user_message": " ".join(str(user_message or "").split()).strip().lower(),
            "active_subagent_label": "",
        }

    def _emit_workspace_stream_event(
        self,
        event: Any,
        *,
        stream_state: dict[str, Any],
        stream_status_callback: Callable[[str], None] | None,
        stream_reply_callback: Callable[[str], None] | None,
    ) -> None:
        """Forward incremental renderer events into workspace stream callbacks."""
        if stream_reply_callback is not None:
            self._emit_workspace_stream_reply_chunk(event, stream_reply_callback)

        if stream_status_callback is None:
            return
        if not isinstance(event, dict):
            return

        rows = cast(list[str], stream_state["rows"])
        pending_by_id = cast(dict[str, dict[str, Any]], stream_state["pending_by_id"])
        pending_by_name = cast(dict[str, list[dict[str, Any]]], stream_state["pending_by_name"])
        normalized_user_message = cast(str, stream_state["normalized_user_message"])
        active_subagent_label = cast(str, stream_state["active_subagent_label"])

        baseline = len(rows)
        updated_subagent = AgentRunSession._consume_workspace_event_for_taxonomy(
            event,
            rows=rows,
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
            normalized_user_message=normalized_user_message,
            active_subagent_label=active_subagent_label,
        )
        stream_state["active_subagent_label"] = updated_subagent

        for row in rows[baseline:]:
            AgentRunSession._emit_workspace_stream_status_line(row, stream_status_callback)

    @staticmethod
    def _emit_workspace_stream_status_line(
        line: Any,
        callback: Callable[[str], None],
    ) -> None:
        """Safely emit one status row to workspace stream callback."""
        text = str(line or "").strip()
        if not text:
            return
        try:
            callback(text)
        except Exception:
            return

    @staticmethod
    def _emit_workspace_stream_reply_chunk(
        event: Any,
        callback: Callable[[str], None],
    ) -> None:
        """Emit token/content chunks for live response rendering in workspace."""
        if not isinstance(event, dict):
            return

        metadata = event.get("metadata")
        metadata_dict = metadata if isinstance(metadata, dict) else {}
        event_type = AgentRunSession._canonical_workspace_event_type(event, metadata_dict)
        if event_type not in {"token", "content_chunk"}:
            return

        chunk = str(event.get("content") or "")
        if not chunk:
            return
        try:
            callback(chunk)
        except Exception:
            return

    def _mark_workspace_transcript_ready(self) -> None:
        """Mark latest transcript as ready for this agent without launching viewer."""
        payload, manifest = self.session._get_last_transcript()
        if not self._transcript_matches(payload, manifest):
            return
        assert isinstance(manifest, dict)
        run_id = str(manifest.get("run_id") or "")
        mark_ready = getattr(self.session, "mark_agent_transcript_ready", None)
        if callable(mark_ready):
            mark_ready(self._agent_id, run_id)

    @staticmethod
    def _format_workspace_agent_reply(result: Any) -> str:
        """Normalize run output into workspace transcript text without truncation."""
        if result is None:
            return "Run finished."

        if isinstance(result, str):
            text = result
        else:
            try:
                text = json.dumps(result, ensure_ascii=False)
            except Exception:
                text = str(result)

        normalized = str(text).replace("\r\n", "\n").replace("\r", "\n").strip()
        if not normalized:
            return "Run finished."
        return normalized

    def _collect_workspace_run_status_lines(self, *, user_message: str | None = None) -> list[str]:
        """Extract compact post-run status lines for workspace transcript."""
        payload, manifest = self.session._get_last_transcript()
        if payload is None or not isinstance(manifest, dict):
            return []

        lines = self._collect_workspace_taxonomy_lines(payload, user_message=user_message)
        self._append_workspace_run_duration_line(lines, getattr(payload, "meta", None))

        return self._limit_workspace_status_lines(lines)

    def _collect_workspace_taxonomy_lines(self, payload: Any, *, user_message: str | None = None) -> list[str]:
        """Prefer event-derived taxonomy rows, then fallback to step summaries."""
        raw_events = getattr(payload, "events", None)
        event_lines = self._workspace_event_taxonomy_lines(raw_events, user_message=user_message)
        if event_lines and self._has_informative_workspace_taxonomy_rows(event_lines):
            return list(event_lines)

        meta = getattr(payload, "meta", None)
        if not isinstance(meta, dict):
            return []

        raw_step_summaries = meta.get("transcript_steps")
        taxonomy_lines = self._workspace_step_taxonomy_lines(raw_step_summaries, user_message=user_message)
        if taxonomy_lines and self._has_informative_workspace_taxonomy_rows(taxonomy_lines):
            return list(taxonomy_lines)

        raw_steps = meta.get("transcript_step_lines")
        return self._workspace_step_summary_lines(raw_steps, user_message=user_message)

    @staticmethod
    def _append_workspace_run_duration_line(lines: list[str], meta: Any) -> None:
        """Append final transcript duration line when available."""
        if not isinstance(meta, dict):
            return
        duration = meta.get("final_duration_seconds")
        try:
            if isinstance(duration, (int, float)) and float(duration) > 0:
                lines.append(f"completed in {float(duration):.1f}s")
        except Exception:
            return

    @staticmethod
    def _workspace_step_taxonomy_lines(
        raw_step_summaries: Any,
        *,
        limit: int = 8,
        user_message: str | None = None,
    ) -> list[str]:
        """Normalize transcript step summaries into stable activity-log taxonomy rows."""
        if not isinstance(raw_step_summaries, list):
            return []

        rows: list[str] = []
        last_tool_call_name: str | None = None
        normalized_user_message = " ".join(str(user_message or "").split()).strip().lower()
        for item in raw_step_summaries:
            normalized = AgentRunSession._normalize_workspace_step_summary(item)
            if normalized is None:
                continue
            if normalized_user_message and AgentRunSession._is_user_echo_step(normalized, normalized_user_message):
                continue

            last_tool_call_name = AgentRunSession._maybe_add_missing_tool_call_row(
                rows,
                item,
                normalized,
                last_tool_call_name,
            )
            rows.append(normalized)

            if normalized.startswith(AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX):
                last_tool_call_name = AgentRunSession._append_tool_call_params_from_summary(
                    rows,
                    item,
                    normalized,
                    last_tool_call_name,
                )
        rows = AgentRunSession._drop_unpaired_workspace_tool_rows(rows)
        return rows[:limit]

    @staticmethod
    def _maybe_add_missing_tool_call_row(
        rows: list[str],
        item: Any,
        normalized: str,
        last_tool_call_name: str | None,
    ) -> str | None:
        """Insert synthetic tool_call rows when a tool_result arrives first."""
        if not normalized.startswith(AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX):
            return last_tool_call_name

        raw_kind = str(item.get("kind") or "").strip().lower() if isinstance(item, dict) else ""
        result_name = AgentRunSession._extract_tool_name_from_taxonomy_row(
            normalized,
            prefix=AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX,
        )
        if raw_kind != "tool" or not result_name or result_name == last_tool_call_name:
            return last_tool_call_name

        rows.append(f"{AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX} {result_name}")
        params_line = AgentRunSession._workspace_tool_params_line(item)
        if params_line is not None:
            rows.append(params_line)
        return result_name

    @staticmethod
    def _append_tool_call_params_from_summary(
        rows: list[str],
        item: Any,
        normalized: str,
        last_tool_call_name: str | None,
    ) -> str | None:
        """Track latest tool_call name and append params preview rows."""
        tool_name = AgentRunSession._extract_tool_name_from_taxonomy_row(
            normalized,
            prefix=AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX,
        )
        updated_name = tool_name or last_tool_call_name
        params_line = AgentRunSession._workspace_tool_params_line(item)
        if params_line is not None:
            rows.append(params_line)
        return updated_name

    @staticmethod
    def _workspace_event_taxonomy_lines(
        raw_events: Any,
        *,
        limit: int = 8,
        user_message: str | None = None,
    ) -> list[str]:
        """Build activity taxonomy rows directly from stored transcript events."""
        if not isinstance(raw_events, list):
            return []

        normalized_user_message = " ".join(str(user_message or "").split()).strip().lower()
        rows: list[str] = []
        pending_by_id: dict[str, dict[str, Any]] = {}
        pending_by_name: dict[str, list[dict[str, Any]]] = {}
        active_subagent_label = ""

        for raw_event in raw_events:
            active_subagent_label = AgentRunSession._consume_workspace_event_for_taxonomy(
                raw_event,
                rows=rows,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
                normalized_user_message=normalized_user_message,
                active_subagent_label=active_subagent_label,
            )

        rows = AgentRunSession._drop_unpaired_workspace_tool_rows(rows)
        return rows[:limit]

    @staticmethod
    def _consume_workspace_event_for_taxonomy(
        raw_event: Any,
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        normalized_user_message: str,
        active_subagent_label: str,
    ) -> str:
        """Consume one raw event into taxonomy state and return updated sub-agent label."""
        if not isinstance(raw_event, dict):
            return active_subagent_label

        metadata = raw_event.get("metadata")
        metadata_dict = metadata if isinstance(metadata, dict) else {}
        event_type = AgentRunSession._canonical_workspace_event_type(raw_event, metadata_dict)
        if AgentRunSession._should_skip_workspace_event_type(event_type):
            return active_subagent_label

        owner_fallback = active_subagent_label if bool(metadata_dict.get("is_sub_agent_event")) else ""
        owner_label = AgentRunSession._resolve_workspace_subagent_owner(
            str(metadata_dict.get("agent_name") or ""),
            owner_fallback,
        )

        if event_type == "tool_call":
            return AgentRunSession._process_workspace_tool_call_event(
                raw_event,
                metadata_dict,
                rows=rows,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
                normalized_user_message=normalized_user_message,
                owner_label=owner_label,
                active_subagent_label=active_subagent_label,
            )

        if event_type == "tool_result":
            return AgentRunSession._process_workspace_tool_result_event(
                raw_event,
                metadata_dict,
                rows=rows,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
                owner_label=owner_label,
                active_subagent_label=active_subagent_label,
            )

        return active_subagent_label

    @staticmethod
    def _should_skip_workspace_event_type(event_type: str) -> bool:
        """Return True for event categories intentionally omitted from status rows."""
        return event_type in {
            "status_update",
            "content_chunk",
            "final_response",
            "streaming_started",
            "stream_end",
        }

    @staticmethod
    def _store_workspace_pending_tool_entry(
        tool_name: str,
        entry: dict[str, Any],
        *,
        call_id: str,
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
    ) -> None:
        """Store one pending tool entry keyed by id and normalized name."""
        if call_id:
            pending_by_id[call_id] = entry
        key = AgentRunSession._normalize_workspace_tool_name(tool_name)
        pending_by_name.setdefault(key, []).append(entry)

    @staticmethod
    def _append_workspace_delegate_tool_call(
        call_payload: dict[str, Any],
        tool_name: str,
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
    ) -> str:
        """Record delegate tool-call lifecycle rows and pending state."""
        handoff_label = AgentRunSession._handoff_label_from_delegate_tool(
            tool_name,
            args=call_payload.get("args"),
        )
        handoff_row = f"{AgentRunSession._WORKSPACE_HANDOFF_PREFIX} {handoff_label}"
        if not rows or rows[-1] != handoff_row:
            rows.append(handoff_row)

        entry = {
            "name": handoff_label,
            "match_name": tool_name,
            "params": str(call_payload.get("params_preview") or ""),
            "args": call_payload.get("args"),
        }
        AgentRunSession._store_workspace_pending_tool_entry(
            tool_name,
            entry,
            call_id=str(call_payload.get("id") or "").strip(),
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
        )
        return AgentRunSession._handoff_target_from_delegate_tool(tool_name)

    @staticmethod
    def _append_workspace_standard_tool_call(
        call_payload: dict[str, Any],
        tool_name: str,
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        owner_label: str,
    ) -> None:
        """Record standard tool-call lifecycle rows and pending state."""
        display_name = AgentRunSession._prefix_workspace_tool_owner(tool_name, owner_label)
        params_preview = str(call_payload.get("params_preview") or "").strip()

        rows.append(f"{AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX} {display_name}")
        if params_preview and params_preview != "{}":
            rows.append(f"{AgentRunSession._WORKSPACE_TOOL_PARAMS_PREFIX} {params_preview}")

        entry = {
            "name": display_name,
            "match_name": tool_name,
            "params": params_preview,
        }
        AgentRunSession._store_workspace_pending_tool_entry(
            tool_name,
            entry,
            call_id=str(call_payload.get("id") or "").strip(),
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
        )

    @staticmethod
    def _process_workspace_tool_call_event(
        event: dict[str, Any],
        metadata: dict[str, Any],
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        normalized_user_message: str,
        owner_label: str,
        active_subagent_label: str,
    ) -> str:
        """Consume one tool_call event into immediate lifecycle rows and pending state."""
        call_payloads = AgentRunSession._extract_workspace_tool_call_payloads(event, metadata)
        if not call_payloads:
            return active_subagent_label

        updated_subagent_label = active_subagent_label
        for call_payload in call_payloads:
            tool_name = str(call_payload.get("name") or "").strip()
            if not tool_name:
                continue

            if normalized_user_message and AgentRunSession._is_user_echo_step(
                f"{AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX} {tool_name}",
                normalized_user_message,
            ):
                continue

            if AgentRunSession._is_delegate_tool_name(tool_name):
                updated_subagent_label = AgentRunSession._append_workspace_delegate_tool_call(
                    call_payload,
                    tool_name,
                    rows=rows,
                    pending_by_id=pending_by_id,
                    pending_by_name=pending_by_name,
                )
                continue

            AgentRunSession._append_workspace_standard_tool_call(
                call_payload,
                tool_name,
                rows=rows,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
                owner_label=owner_label,
            )

        return updated_subagent_label

    @staticmethod
    def _delegate_tool_result_args(
        result_payload: dict[str, Any],
        matched: dict[str, Any] | None,
    ) -> dict[str, Any] | None:
        """Return delegate args from result payload or matched pending entry."""
        delegate_args = result_payload.get("args")
        if isinstance(delegate_args, dict):
            return delegate_args
        fallback_args = (matched or {}).get("args")
        return fallback_args if isinstance(fallback_args, dict) else None

    @staticmethod
    def _process_workspace_delegate_tool_result(
        result_payload: dict[str, Any],
        tool_name: str,
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        active_subagent_label: str,
    ) -> str:
        """Consume one delegated tool_result event into handoff lifecycle rows."""
        matched = AgentRunSession._match_workspace_tool_result(
            result_payload,
            tool_name,
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
        )
        handoff_label = AgentRunSession._handoff_label_from_delegate_tool(
            tool_name,
            args=AgentRunSession._delegate_tool_result_args(result_payload, matched),
        )
        outcome = str(result_payload.get("outcome") or "finished").strip() or "finished"
        rows.append(f"{AgentRunSession._WORKSPACE_HANDOFF_PREFIX} {handoff_label} | {outcome}")
        delegate_target = AgentRunSession._handoff_target_from_delegate_tool(tool_name)
        return "" if active_subagent_label == delegate_target else active_subagent_label

    @staticmethod
    def _process_workspace_standard_tool_result(
        result_payload: dict[str, Any],
        tool_name: str,
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        owner_label: str,
        active_subagent_label: str,
    ) -> str:
        """Consume one standard tool_result event into paired lifecycle rows."""
        matched = AgentRunSession._match_workspace_tool_result(
            result_payload,
            tool_name,
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
        )
        resolved_name = str((matched or {}).get("name") or "").strip()
        if not resolved_name:
            resolved_name = AgentRunSession._prefix_workspace_tool_owner(tool_name, owner_label)

        outcome = str(result_payload.get("outcome") or "finished").strip() or "finished"
        rows.append(f"{AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX} {resolved_name} | {outcome}")
        return active_subagent_label

    @staticmethod
    def _process_workspace_tool_result_event(
        event: dict[str, Any],
        metadata: dict[str, Any],
        *,
        rows: list[str],
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
        owner_label: str,
        active_subagent_label: str,
    ) -> str:
        """Consume one tool_result event into paired lifecycle rows."""
        result_payload = AgentRunSession._extract_workspace_tool_result_payload(event, metadata)
        if not result_payload:
            return active_subagent_label

        tool_name = str(result_payload.get("name") or "").strip()
        if not tool_name:
            return active_subagent_label
        if AgentRunSession._is_delegate_tool_name(tool_name):
            return AgentRunSession._process_workspace_delegate_tool_result(
                result_payload,
                tool_name,
                rows=rows,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
                active_subagent_label=active_subagent_label,
            )
        return AgentRunSession._process_workspace_standard_tool_result(
            result_payload,
            tool_name,
            rows=rows,
            pending_by_id=pending_by_id,
            pending_by_name=pending_by_name,
            owner_label=owner_label,
            active_subagent_label=active_subagent_label,
        )

    @staticmethod
    def _match_workspace_tool_result(
        result_payload: dict[str, Any],
        tool_name: str,
        *,
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
    ) -> dict[str, Any] | None:
        """Find matching tool_call entry for a tool_result event."""
        call_id = str(result_payload.get("id") or "").strip()
        if call_id:
            matched = AgentRunSession._pop_workspace_pending_entry_by_id(
                call_id,
                tool_name,
                pending_by_id=pending_by_id,
                pending_by_name=pending_by_name,
            )
            if matched is not None:
                return matched
        return AgentRunSession._pop_workspace_pending_entry_by_name(tool_name, pending_by_name=pending_by_name)

    @staticmethod
    def _pop_workspace_pending_entry_by_id(
        call_id: str,
        tool_name: str,
        *,
        pending_by_id: dict[str, dict[str, Any]],
        pending_by_name: dict[str, list[dict[str, Any]]],
    ) -> dict[str, Any] | None:
        """Pop pending tool_call entry by explicit call id."""
        matched = pending_by_id.pop(call_id, None)
        if matched is None:
            return None
        key = AgentRunSession._normalize_workspace_tool_name(str(matched.get("match_name") or tool_name))
        queue = pending_by_name.get(key) or []
        if matched in queue:
            queue.remove(matched)
        if not queue:
            pending_by_name.pop(key, None)
        return matched

    @staticmethod
    def _pop_workspace_pending_entry_by_name(
        tool_name: str,
        *,
        pending_by_name: dict[str, list[dict[str, Any]]],
    ) -> dict[str, Any] | None:
        """Pop oldest pending tool_call entry by normalized tool name."""
        key = AgentRunSession._normalize_workspace_tool_name(tool_name)
        queue = pending_by_name.get(key) or []
        if not queue:
            return None
        matched = queue.pop(0)
        if not queue:
            pending_by_name.pop(key, None)
        return matched

    @staticmethod
    def _canonical_workspace_event_type(event: dict[str, Any], metadata: dict[str, Any]) -> str:
        """Resolve event type from event payload and metadata with normalized casing."""
        value = event.get("event_type")
        if not value:
            value = metadata.get("event_type") or metadata.get("kind")
        return str(value or "").strip().lower()

    @staticmethod
    def _extract_workspace_tool_name_from_content(content: Any) -> str:
        """Extract a best-effort tool name from human-oriented event content text."""
        text = " ".join(str(content or "").split()).strip()
        if not text:
            return ""

        if ":" in text:
            _, _, text = text.partition(":")
            text = text.strip()

        if not text:
            return ""
        if "," in text:
            text = text.split(",", 1)[0].strip()
        return text

    @staticmethod
    def _normalize_workspace_tool_name(name: str) -> str:
        """Normalize tool names for matching call/result lifecycle rows."""
        return " ".join(str(name or "").strip().lower().split())

    @staticmethod
    def _is_delegate_tool_name(name: str) -> bool:
        """Return True when tool name represents a sub-agent delegation call."""
        lowered = AgentRunSession._normalize_workspace_tool_name(name)
        return lowered.startswith("delegate_to_")

    @staticmethod
    def _handoff_target_from_delegate_tool(name: str) -> str:
        """Return compact sub-agent target label from delegate tool names."""
        lowered = AgentRunSession._normalize_workspace_tool_name(name)
        if lowered.startswith("delegate_to_"):
            label = lowered[len("delegate_to_") :].strip()
            return label or "sub-agent"
        return lowered or "sub-agent"

    @staticmethod
    def _workspace_delegate_context_label(args: Any) -> str | None:
        """Return a concise delegate context label derived from known args keys."""
        if not isinstance(args, dict):
            return None

        for key in ("query", "task", "prompt", "goal", "message", "request"):
            raw_value = args.get(key)
            if isinstance(raw_value, str):
                cleaned = " ".join(raw_value.split()).strip()
            elif isinstance(raw_value, (int, float, bool)):
                cleaned = str(raw_value)
            else:
                continue

            if cleaned:
                preview = AgentRunSession._truncate_workspace_step_text(cleaned, limit=56)
                return f"{key}: {preview}"

        return None

    @staticmethod
    def _handoff_label_from_delegate_tool(name: str, *, args: Any | None = None) -> str:
        """Map delegate tool names into compact sub-agent handoff labels."""
        target = AgentRunSession._handoff_target_from_delegate_tool(name)
        context = AgentRunSession._workspace_delegate_context_label(args)
        if context:
            return f"{target} ({context})"
        return target

    @staticmethod
    def _looks_like_workspace_uuid(value: str) -> bool:
        """Return True when value resembles a canonical UUID token."""
        cleaned = str(value or "").strip().lower()
        return bool(re.fullmatch(r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}", cleaned))

    @staticmethod
    def _resolve_workspace_subagent_owner(agent_name: str, fallback_owner: str) -> str:
        """Resolve sub-agent label from metadata agent name with fallback from handoff context."""
        cleaned = " ".join(str(agent_name or "").split()).strip()
        if cleaned and not AgentRunSession._looks_like_workspace_uuid(cleaned):
            return cleaned
        fallback = " ".join(str(fallback_owner or "").split()).strip()
        return fallback

    @staticmethod
    def _prefix_workspace_tool_owner(tool_name: str, owner_label: str) -> str:
        """Prefix tool name with bracketed owner label for sub-agent attribution."""
        name = " ".join(str(tool_name or "").split()).strip() or "tool"
        owner = " ".join(str(owner_label or "").split()).strip()
        if not owner:
            return name
        if name.startswith("["):
            return name
        return f"[{owner}] {name}"

    @staticmethod
    def _trim_workspace_args_preview_content(value: Any) -> Any:
        """Trim oversized args values while preserving object/array structure."""
        max_value_len = 220
        max_items = 24

        if isinstance(value, dict):
            return {key: AgentRunSession._trim_workspace_args_preview_content(item) for key, item in value.items()}
        if isinstance(value, list):
            trimmed = [AgentRunSession._trim_workspace_args_preview_content(item) for item in value[:max_items]]
            overflow = len(value) - max_items
            if overflow > 0:
                trimmed.append(f"... +{overflow} items")
            return trimmed
        if isinstance(value, tuple):
            trimmed = [AgentRunSession._trim_workspace_args_preview_content(item) for item in value[:max_items]]
            overflow = len(value) - max_items
            if overflow > 0:
                trimmed.append(f"... +{overflow} items")
            return tuple(trimmed)
        if isinstance(value, str):
            normalized = value.replace("\r\n", "\n").replace("\r", "\n")
            if len(normalized) <= max_value_len:
                return normalized
            return f"{normalized[: max_value_len - 3]}..."
        return value

    @staticmethod
    def _workspace_event_args_preview(args: Any) -> str | None:
        """Return redacted one-line args preview for event-derived tool rows."""
        if not isinstance(args, dict) or not args:
            return None
        try:
            masked = mask_payload(args)
            trimmed = AgentRunSession._trim_workspace_args_preview_content(masked)
            preview = json.dumps(trimmed, ensure_ascii=False, separators=(",", ":"))
        except Exception:
            return None

        single_line = " ".join(str(preview or "").split()).strip()
        if not single_line or single_line == "{}":
            return None
        return single_line

    @staticmethod
    def _workspace_event_duration_label(value: Any) -> str | None:
        """Convert tool execution seconds into compact duration text."""
        try:
            if not isinstance(value, (int, float)):
                return None
            seconds = float(value)
        except Exception:
            return None
        if seconds <= 0:
            return "<1ms"
        return AgentRunSession._workspace_duration_label(int(seconds * 1000))

    @staticmethod
    def _workspace_tool_output_summary(output: Any) -> str | None:
        """Return compact output summary suitable for inline status rows."""
        if output is None:
            return None

        if isinstance(output, str):
            return AgentRunSession._workspace_string_output_summary(output)

        if isinstance(output, dict):
            return AgentRunSession._workspace_mapping_output_summary(output)

        if isinstance(output, (list, tuple, set)):
            return f"{len(output)} items"

        return AgentRunSession._workspace_string_output_summary(str(output))

    @staticmethod
    def _workspace_output_looks_like_error(output: Any) -> bool:
        """Return True when tool output contains clear error/failure indicators."""
        if output is None:
            return False

        if isinstance(output, str):
            normalized = " ".join(output.replace("\r", "\n").split()).strip().lower()
            if not normalized:
                return False
            if normalized.startswith(("error", "exception", "traceback", "failed", "failure")):
                return True
            return any(
                marker in normalized
                for marker in (
                    "error executing tool",
                    "raised exception",
                    "unknown timezone",
                    "traceback (most recent call last)",
                )
            )

        if isinstance(output, dict):
            return AgentRunSession._workspace_mapping_looks_like_error(output)

        if isinstance(output, (list, tuple, set)):
            return any(AgentRunSession._workspace_output_looks_like_error(item) for item in output)

        return False

    @staticmethod
    def _workspace_mapping_looks_like_error(output: dict[str, Any]) -> bool:
        """Return True when mapping output carries top-level or nested failure signals."""
        for key in ("error", "errors", "exception", "traceback"):
            value = output.get(key)
            if value not in (None, "", [], {}):
                return True
        status = str(output.get("status") or "").strip().lower()
        if status in AgentRunSession._WORKSPACE_FAILED_STATES:
            return True
        for value in output.values():
            if AgentRunSession._workspace_output_looks_like_error(value):
                return True
        return False

    @staticmethod
    def _workspace_string_output_summary(output: str) -> str | None:
        """Summarize string-like tool outputs for compact status rows."""
        normalized = " ".join(str(output or "").replace("\r", "\n").split()).strip()
        if not normalized:
            return None
        if len(normalized) <= 64:
            return normalized
        estimated_tokens = AgentRunSession._workspace_estimated_token_count(normalized)
        return f"~{estimated_tokens} tokens"

    @staticmethod
    def _workspace_estimated_token_count(text: str) -> int:
        """Return a lightweight token estimate from normalized text length."""
        compact = " ".join(str(text or "").split()).strip()
        if not compact:
            return 0
        return max(1, int(round(len(compact) / 4)))

    @staticmethod
    def _workspace_mapping_output_summary(output: dict[str, Any]) -> str | None:
        """Summarize dict-like tool outputs for compact status rows."""
        organic = output.get("organic") if isinstance(output.get("organic"), list) else None
        if isinstance(organic, list):
            return f"{len(organic)} search results"

        for key in ("items", "results", "rows", "data"):
            items = output.get(key)
            if isinstance(items, list):
                return f"{len(items)} items"

        return f"{len(output)} fields"

    @staticmethod
    def _extract_workspace_tool_call_payloads(event: dict[str, Any], metadata: dict[str, Any]) -> list[dict[str, Any]]:
        """Extract one or more tool-call payloads from structured event metadata."""
        tool_info_raw = metadata.get("tool_info")
        tool_info = tool_info_raw if isinstance(tool_info_raw, dict) else {}
        payloads: list[dict[str, Any]] = []
        structured_calls = AgentRunSession._workspace_tool_calls(tool_info)

        if structured_calls:
            for index, call in enumerate(structured_calls):
                name = AgentRunSession._workspace_tool_name_from_call(
                    event,
                    tool_info,
                    call,
                    allow_content_fallback=False,
                )
                if not name:
                    continue
                args = AgentRunSession._workspace_tool_args_from_call(tool_info, call)
                call_id = AgentRunSession._workspace_tool_call_id_from_call(metadata, tool_info, call, index=index)
                payloads.append(
                    {
                        "id": call_id,
                        "name": name,
                        "args": args,
                        "params_preview": AgentRunSession._workspace_event_args_preview(args),
                    }
                )
            return payloads

        name = AgentRunSession._workspace_tool_name_from_call(event, tool_info, None)
        if not name:
            return []
        args = AgentRunSession._workspace_tool_args_from_call(tool_info, None)
        call_id = AgentRunSession._workspace_tool_call_id_from_call(metadata, tool_info, None)
        return [
            {
                "id": call_id,
                "name": name,
                "args": args,
                "params_preview": AgentRunSession._workspace_event_args_preview(args),
            }
        ]

    @staticmethod
    def _extract_workspace_tool_call_payload(event: dict[str, Any], metadata: dict[str, Any]) -> dict[str, Any] | None:
        """Extract first tool-call payload for compatibility with existing helper tests."""
        payloads = AgentRunSession._extract_workspace_tool_call_payloads(event, metadata)
        if not payloads:
            return None
        return payloads[0]

    @staticmethod
    def _workspace_tool_calls(tool_info: dict[str, Any]) -> list[dict[str, Any]]:
        """Return structured tool call entries in source order."""
        tool_calls_raw = tool_info.get("tool_calls")
        tool_calls = tool_calls_raw if isinstance(tool_calls_raw, list) else []
        calls: list[dict[str, Any]] = []
        for candidate in tool_calls:
            if isinstance(candidate, dict):
                calls.append(candidate)
        return calls

    @staticmethod
    def _workspace_first_tool_call(tool_info: dict[str, Any]) -> dict[str, Any] | None:
        """Return first structured tool_call entry from tool_info."""
        tool_calls = AgentRunSession._workspace_tool_calls(tool_info)
        if not tool_calls:
            return None
        return tool_calls[0]

    @staticmethod
    def _workspace_tool_name_from_call(
        event: dict[str, Any],
        tool_info: dict[str, Any],
        call: dict[str, Any] | None,
        *,
        allow_content_fallback: bool = True,
    ) -> str:
        """Resolve tool name from tool call payload, metadata, or content fallback."""
        name = str((call or {}).get("name") or "").strip()
        if name:
            return name
        name = str(tool_info.get("name") or "").strip()
        if name:
            return name
        if not allow_content_fallback:
            return ""
        return AgentRunSession._extract_workspace_tool_name_from_content(event.get("content"))

    @staticmethod
    def _workspace_tool_args_from_call(tool_info: dict[str, Any], call: dict[str, Any] | None) -> Any:
        """Resolve tool args payload from structured call or tool_info fallback."""
        args = (call or {}).get("args")
        if args is not None:
            return args
        return tool_info.get("args")

    @staticmethod
    def _workspace_tool_call_id_from_call(
        metadata: dict[str, Any],
        tool_info: dict[str, Any],
        call: dict[str, Any] | None,
        *,
        index: int = 0,
    ) -> str:
        """Resolve tool call identifier for call/result lifecycle pairing."""
        call_id = str((call or {}).get("id") or "").strip()
        if call_id:
            return call_id
        fallback = str(tool_info.get("id") or metadata.get("step_id") or "").strip()
        if not fallback:
            return ""
        if index <= 0:
            return fallback
        return f"{fallback}:{index}"

    @staticmethod
    def _extract_workspace_tool_result_payload(
        event: dict[str, Any], metadata: dict[str, Any]
    ) -> dict[str, Any] | None:
        """Extract tool-result metadata and normalize outcome text."""
        tool_info_raw = metadata.get("tool_info")
        tool_info = tool_info_raw if isinstance(tool_info_raw, dict) else {}
        name = str(tool_info.get("name") or "").strip()
        if not name:
            name = AgentRunSession._extract_workspace_tool_name_from_content(event.get("content"))

        args = tool_info.get("args")
        call_id = str(tool_info.get("id") or metadata.get("step_id") or "").strip()

        status = str(metadata.get("status") or event.get("status") or "").strip().lower()
        duration_label = AgentRunSession._workspace_event_duration_label(tool_info.get("execution_time"))
        output_value = tool_info.get("output")
        output_summary = AgentRunSession._workspace_tool_output_summary(output_value)
        output_failed = AgentRunSession._workspace_output_looks_like_error(output_value)

        if status in AgentRunSession._WORKSPACE_FAILED_STATES or output_failed:
            outcome = f"failed in {duration_label}" if duration_label else "failed"
        else:
            outcome = f"finished in {duration_label}" if duration_label else "finished"

        if output_summary:
            outcome = f"{outcome} | output {output_summary}"

        return {
            "id": call_id,
            "name": name,
            "args": args,
            "params_preview": AgentRunSession._workspace_event_args_preview(args),
            "outcome": outcome,
        }

    def _limit_workspace_status_lines(self, lines: list[str]) -> list[str]:
        """Clamp status lines while preserving a trailing completion summary when present."""
        limit = self._WORKSPACE_STATUS_LINE_LIMIT
        if len(lines) <= limit:
            return lines

        completion = ""
        if lines and str(lines[-1]).lower().startswith("completed in "):
            completion = lines[-1]
            body = lines[:-1]
            body = body[: max(0, limit - 1)]
            return body + [completion]

        return lines[:limit]

    @staticmethod
    def _drop_unpaired_workspace_tool_rows(rows: list[str]) -> list[str]:
        """Drop tool_call/tool_params rows that do not have a matching tool_result row."""
        result_counts = AgentRunSession._workspace_tool_result_counts(rows)
        pruned: list[str] = []
        skip_params = False
        for row in rows:
            skip_params, kept_row = AgentRunSession._filter_workspace_tool_row(
                row,
                result_counts=result_counts,
                skip_params=skip_params,
            )
            if kept_row is not None:
                pruned.append(kept_row)

        return pruned

    @staticmethod
    def _workspace_tool_result_counts(rows: list[str]) -> dict[str, int]:
        """Count tool_result rows by normalized tool name."""
        result_counts: dict[str, int] = {}
        for row in rows:
            lowered = str(row or "").strip().lower()
            if not lowered.startswith(AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX):
                continue
            tool_name = AgentRunSession._extract_tool_name_from_taxonomy_row(
                str(row),
                prefix=AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX,
            )
            key = AgentRunSession._normalize_workspace_tool_name(tool_name)
            result_counts[key] = result_counts.get(key, 0) + 1
        return result_counts

    @staticmethod
    def _filter_workspace_tool_row(
        row: str,
        *,
        result_counts: dict[str, int],
        skip_params: bool,
    ) -> tuple[bool, str | None]:
        """Filter one taxonomy row based on tool call/result pairing state."""
        lowered = str(row or "").strip().lower()
        if lowered.startswith(AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX):
            tool_name = AgentRunSession._extract_tool_name_from_taxonomy_row(
                str(row),
                prefix=AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX,
            )
            key = AgentRunSession._normalize_workspace_tool_name(tool_name)
            if result_counts.get(key, 0) <= 0:
                return True, None
            return False, row

        if lowered.startswith(AgentRunSession._WORKSPACE_TOOL_PARAMS_PREFIX):
            if skip_params:
                return True, None
            return False, row

        if lowered.startswith(AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX):
            tool_name = AgentRunSession._extract_tool_name_from_taxonomy_row(
                str(row),
                prefix=AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX,
            )
            key = AgentRunSession._normalize_workspace_tool_name(tool_name)
            if result_counts.get(key, 0) > 0:
                result_counts[key] -= 1
            return False, row

        return False, row

    @staticmethod
    def _extract_tool_name_from_taxonomy_row(row: str, *, prefix: str) -> str:
        """Extract the tool name portion from canonical taxonomy rows."""
        lowered = str(row or "")
        if not lowered.startswith(prefix):
            return ""
        detail = lowered[len(prefix) :].strip()
        if not detail:
            return ""
        if "|" in detail:
            detail = detail.split("|", 1)[0].strip()
        return detail

    @staticmethod
    def _workspace_tool_params_line(raw_step_summary: Any) -> str | None:
        """Return compact tool params row when summary metadata contains args preview."""
        if not isinstance(raw_step_summary, dict):
            return None
        preview = str(raw_step_summary.get("args_preview") or "").strip()
        if not preview or preview == "{}":
            return None
        single_line = " ".join(preview.splitlines()).strip()
        collapsed = single_line.replace(" ", "")
        if not single_line or collapsed == "{}":
            return None
        return f"{AgentRunSession._WORKSPACE_TOOL_PARAMS_PREFIX} {single_line}"

    @staticmethod
    def _has_informative_workspace_taxonomy_rows(rows: list[str]) -> bool:
        """Return True when taxonomy rows include actionable categories."""
        informative_prefixes = (
            AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX,
            AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX,
            AgentRunSession._WORKSPACE_HANDOFF_PREFIX,
            "reasoning:",
            "final:",
        )
        for row in rows:
            lowered = str(row or "").strip().lower()
            if lowered.startswith(informative_prefixes):
                return True
        return False

    @staticmethod
    def _normalize_workspace_step_summary(raw_step_summary: Any) -> str | None:
        """Map one renderer step summary into the workspace taxonomy shape."""
        if not isinstance(raw_step_summary, dict):
            return None

        kind = str(raw_step_summary.get("kind") or "").strip().lower()
        status = str(raw_step_summary.get("status") or "").strip().lower()
        duration_label = AgentRunSession._workspace_duration_label(raw_step_summary.get("duration_ms"))
        label = " ".join(
            str(raw_step_summary.get("display_name") or raw_step_summary.get("name") or "").split()
        ).strip()

        canonical_kind = AgentRunSession._canonical_workspace_step_kind(kind, label, status=status)
        if canonical_kind is None:
            return None

        label = AgentRunSession._resolve_workspace_step_label(canonical_kind, label, status=status)
        if not label:
            return None

        detail = AgentRunSession._truncate_workspace_step_text(label)
        if canonical_kind == "tool_result":
            outcome = AgentRunSession._workspace_tool_result_outcome(status, duration_label)
            return f"{canonical_kind}: {detail} | {outcome}"
        return f"{canonical_kind}: {detail}"

    @staticmethod
    def _resolve_workspace_step_label(canonical_kind: str, label: str, *, status: str) -> str:
        """Resolve fallback labels for normalized step taxonomy rows."""
        if label:
            return label
        if canonical_kind == "status" and status:
            return status
        if canonical_kind == "final":
            return "response ready"
        if canonical_kind == "tool_result":
            return "tool"
        return ""

    @staticmethod
    def _workspace_tool_result_outcome(status: str, duration_label: str | None) -> str:
        """Build canonical outcome text for normalized tool_result rows."""
        failed_states = {"failed", "error", "aborted", "cancelled"}
        failed = status in failed_states
        if failed:
            return f"failed in {duration_label}" if duration_label else "failed"
        return f"finished in {duration_label}" if duration_label else "finished"

    @staticmethod
    def _workspace_duration_label(value: Any) -> str | None:
        """Format duration milliseconds into compact human-readable status text."""
        try:
            if not isinstance(value, (int, float)):
                return None
            duration_ms = max(0, int(value))
        except Exception:
            return None

        if duration_ms <= 0:
            return "<1ms"
        if duration_ms < 1000:
            return f"{duration_ms}ms"

        total_seconds = duration_ms / 1000
        if total_seconds >= 60:
            minutes = int(total_seconds // 60)
            seconds = total_seconds % 60
            if seconds >= 1:
                return f"{minutes}m {seconds:.1f}s"
            return f"{minutes}m"
        return f"{total_seconds:.2f}s"

    @staticmethod
    def _canonical_workspace_step_kind(kind: str, label: str, *, status: str = "") -> str | None:
        """Resolve canonical step taxonomy kind from renderer metadata."""
        lowered_kind = str(kind or "").strip().lower()
        lowered_label = str(label or "").strip().lower()
        lowered_status = str(status or "").strip().lower()
        if lowered_kind == "tool":
            return AgentRunSession._canonical_tool_kind_from_status(lowered_status)

        direct_match = AgentRunSession._canonical_workspace_kind_from_kind(lowered_kind)
        if direct_match is not None:
            return direct_match

        inferred = AgentRunSession._canonical_workspace_kind_from_label(lowered_label)
        if inferred is not None:
            return inferred

        if lowered_kind:
            return "status"
        return None

    @staticmethod
    def _canonical_tool_kind_from_status(status: str) -> str:
        """Resolve tool row taxonomy from step status values."""
        finished_states = {
            "finished",
            "success",
            "succeeded",
            "completed",
            "failed",
            "error",
            "aborted",
            "cancelled",
            "stopped",
        }
        return "tool_result" if status in finished_states else "tool_call"

    @staticmethod
    def _canonical_workspace_kind_from_kind(lowered_kind: str) -> str | None:
        """Map renderer kind tokens directly to workspace taxonomy kinds."""
        if lowered_kind == "tool_call":
            return "tool_call"
        if lowered_kind in {"tool_result", "tool_output"}:
            return "tool_result"
        if lowered_kind in {"handoff", "delegate", "delegation", "sub_agent"} or "handoff" in lowered_kind:
            return "handoff"
        if lowered_kind in {"reasoning", "thinking", "thought", "analysis", "agent_thinking_step"}:
            return "reasoning"
        if lowered_kind in {"status", "status_update", "progress", "agent", "agent_step", "agent_default"}:
            return "status"
        if lowered_kind in {"final", "final_response", "response"}:
            return "final"
        return None

    @staticmethod
    def _canonical_workspace_kind_from_label(lowered_label: str) -> str | None:
        """Infer workspace taxonomy kind from display label text."""
        if "handoff" in lowered_label or "delegate" in lowered_label or "subagent" in lowered_label:
            return "handoff"
        if "tool" in lowered_label and ("result" in lowered_label or "output" in lowered_label):
            return "tool_result"
        if "tool" in lowered_label:
            return "tool_call"
        if "reason" in lowered_label or "think" in lowered_label:
            return "reasoning"
        return None

    @staticmethod
    def _workspace_step_summary_lines(
        raw_steps: Any,
        *,
        limit: int = 3,
        user_message: str | None = None,
    ) -> list[str]:
        """Normalize transcript step rows into concise, user-facing step summaries."""
        if not isinstance(raw_steps, list):
            return []

        rows: list[str] = []
        normalized_user_message = " ".join(str(user_message or "").split()).strip().lower()
        for item in raw_steps:
            normalized = AgentRunSession._normalize_workspace_step_line(item)
            if normalized is None:
                continue
            if normalized_user_message and AgentRunSession._is_user_echo_step(normalized, normalized_user_message):
                continue
            rows.append(normalized)
            if len(rows) >= limit:
                break
        return rows

    @staticmethod
    def _is_user_echo_step(step_line: str, user_message: str) -> bool:
        """Detect low-signal step rows that only repeat the user prompt text."""
        lowered = step_line.lower().strip()
        for prefix in (
            "step:",
            "action:",
            "reasoning:",
            "status:",
            "final:",
            AgentRunSession._WORKSPACE_TOOL_CALL_PREFIX,
            AgentRunSession._WORKSPACE_TOOL_RESULT_PREFIX,
            AgentRunSession._WORKSPACE_TOOL_PARAMS_PREFIX,
            AgentRunSession._WORKSPACE_HANDOFF_PREFIX,
        ):
            if lowered.startswith(prefix):
                detail = lowered[len(prefix) :].strip()
                return detail == user_message
        return False

    @staticmethod
    def _normalize_workspace_step_line(raw_step: Any) -> str | None:
        """Drop noisy step rows and keep concise action-oriented lines."""
        text = " ".join(str(raw_step).split()).strip()
        if not text:
            return None

        text = AgentRunSession._trim_workspace_step_prefix(text)
        text = AgentRunSession._trim_workspace_step_suffix(text)
        if not text:
            return None

        if AgentRunSession._is_workspace_step_noise(text):
            return None

        tool_row = AgentRunSession._normalize_workspace_tool_row(text)
        if tool_row is not None:
            return tool_row

        if AgentRunSession._is_low_signal_workspace_step_text(text):
            return None

        if AgentRunSession._has_workspace_step_prefix(text):
            return text[:140]

        compact = AgentRunSession._truncate_workspace_step_text(text)
        return f"step: {compact}"

    @staticmethod
    def _workspace_step_payload_prefixes() -> tuple[str, ...]:
        return ("request:", "payload:", "args:", "arguments:", "input:", "output:", "response:")

    @staticmethod
    def _truncate_workspace_step_text(text: str, *, limit: int = 132) -> str:
        if len(text) <= limit:
            return text
        return f"{text[: limit - 3]}..."

    @staticmethod
    def _is_workspace_step_noise(text: str) -> bool:
        lowered = text.lower()
        if text.startswith("🤖"):
            return True
        if re.search(r"\([0-9a-f]{8}-[0-9a-f-]{27,}\)", lowered):
            return True
        if lowered.startswith(("run ", "duration:")):
            return True
        return lowered.startswith(AgentRunSession._workspace_step_payload_prefixes())

    @staticmethod
    def _normalize_workspace_tool_row(text: str) -> str | None:
        if not text.startswith("🔧"):
            return None
        tool_detail = text[1:].strip()
        if not tool_detail:
            return None
        if tool_detail.lower().startswith(AgentRunSession._workspace_step_payload_prefixes()):
            return None
        return f"tool: {AgentRunSession._truncate_workspace_step_text(tool_detail)}"

    @staticmethod
    def _is_low_signal_workspace_step_text(text: str) -> bool:
        token_count = len(text.split())
        return token_count < 3 and not any(ch in text for ch in (":", "/", "-"))

    @staticmethod
    def _has_workspace_step_prefix(text: str) -> bool:
        return text.lower().startswith(("step:", "tool:", "call:", "action:"))

    @staticmethod
    def _trim_workspace_step_prefix(text: str) -> str:
        """Trim leading tree/indent glyphs from step rows without regex."""
        cleaned = str(text).lstrip()
        while cleaned and (cleaned[0] == "-" or 0x2500 <= ord(cleaned[0]) <= 0x257F):
            cleaned = cleaned[1:].lstrip()
        return cleaned

    @staticmethod
    def _trim_workspace_step_suffix(text: str) -> str:
        """Trim trailing checkmark glyphs and surrounding spaces from step rows."""
        cleaned = str(text).rstrip()
        while cleaned and cleaned[-1] in ("✓", "✔"):
            cleaned = cleaned[:-1].rstrip()
        return cleaned
