"""Shared helpers for loading Textual CSS assets."""

from __future__ import annotations

from collections.abc import Mapping
from functools import cache
from pathlib import Path


@cache
def load_tcss_file(relative_path: str) -> str:
    """Load a `.tcss` file from the TUI package directory."""
    css_path = Path(__file__).resolve().parent / relative_path
    return css_path.read_text(encoding="utf-8")


def load_tcss_template(relative_path: str, tokens: Mapping[str, str]) -> str:
    """Load `.tcss` and replace `{{token}}` placeholders with values."""
    css = load_tcss_file(relative_path)
    for key, value in tokens.items():
        css = css.replace(f"{{{{{key}}}}}", value)
    return css
