"""Textual UI for `/agents` selection.

This app is the A1 selector surface and is designed to be wired into the
runtime `/agents` flow in A2.
"""

from __future__ import annotations

import asyncio
import logging
import re
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.coordinate import Coordinate
from textual.reactive import reactive
from textual.widgets import DataTable, Footer, Input, Static

from glaip_sdk.cli.core.prompting import _fuzzy_score
from glaip_sdk.cli.slash.tui.background_tasks import cancel_worker_group
from glaip_sdk.cli.slash.tui.context import TUIContext
from glaip_sdk.cli.slash.tui.indicators import PulseIndicator
from glaip_sdk.cli.slash.tui.keybind_registry import KeybindRegistry
from glaip_sdk.cli.slash.tui.loading import hide_loading_indicator, show_loading_indicator
from glaip_sdk.cli.slash.tui.screenshot_capture import ScreenshotCaptureMixin
from glaip_sdk.cli.slash.tui.toast import ToastBus

logger = logging.getLogger(__name__)

AGENTS_TABLE_ID = "#agents-table"
FILTER_INPUT_ID = "#filter-input"
STATUS_ID = "#status"
AGENTS_LOADING_ID = "#agents-loading"
AGENTS_LOADING_PLACEHOLDER_ID = "#agents-loading-placeholder"

CSS_FILE_NAME = "agents.tcss"
KEYBIND_CATEGORY = "Agents"
APP_QUIT_ACTION = "app.quit"
DESCRIPTION_MAX_LEN = 72
DEFAULT_PAGE_SIZE = 25
MIN_DYNAMIC_PAGE_SIZE = 5
PAGE_CHROME_RESERVED_ROWS = 13
AGENTS_LOAD_WORKER_GROUP = "agents-load"
ID_SEARCH_BASE_SCORE = 900
NAME_MULTI_TERM_BONUS = 100
NAME_COMPACT_EXACT_BASE_SCORE = 600
LOADING_AGENTS_MESSAGE = "Loading agents..."
NAME_COMPACT_FUZZY_BASE_SCORE = 200
ID_VISIBLE_PREFIX_LEN = 4
ID_VISIBLE_SUFFIX_LEN = 4
SELECTION_HANDOFF_DELAY_SECONDS = 0.18


@dataclass
class AgentInfo:
    """Agent row info used by the selector table."""

    id: str
    name: str
    description: str
    mcp_count: int
    is_active: bool = False


@dataclass
class AgentPage:
    """Pagination payload for the selector app."""

    items: list[AgentInfo]
    total: int | None = None
    page: int = 1
    limit: int = 25
    has_next: bool | None = None
    has_prev: bool | None = None


AgentPageFetcher = Callable[[int, int], AgentPage | dict[str, Any] | Any]


class AgentsFilterInput(Input):
    """Filter input with selector-specific key routing."""

    def on_key(self, event: Any) -> None:  # pragma: no cover - exercised in integration tests
        app = self.app
        if app is None:
            return

        if event.key in {"[", "left_square_bracket"}:
            action = getattr(app, "action_page_left", None)
            if callable(action):
                action()
            event.prevent_default()
            event.stop()
            return

        if event.key in {"]", "right_square_bracket"}:
            action = getattr(app, "action_page_right", None)
            if callable(action):
                action()
            event.prevent_default()
            event.stop()
            return

        if event.key == "enter":
            action = getattr(app, "action_select_agent", None)
            if callable(action):
                action()
            event.prevent_default()
            event.stop()
            return

        base_on_key = getattr(Input, "on_key", None)
        if callable(base_on_key):
            base_on_key(self, event)


class AgentsDataTable(DataTable):
    """Agents table that forwards typed characters to the filter."""

    @staticmethod
    def _consume_event(event: Any) -> None:
        event.prevent_default()
        event.stop()

    @staticmethod
    def _dispatch_action(app: Any, action_name: str) -> bool:
        action = getattr(app, action_name, None)
        if not callable(action):
            return False
        action()
        return True

    def _handle_paging_key(self, event: Any, app: Any) -> bool:
        if event.key in {"[", "left_square_bracket"}:
            self._dispatch_action(app, "action_page_left")
            self._consume_event(event)
            return True

        if event.key in {"]", "right_square_bracket"}:
            self._dispatch_action(app, "action_page_right")
            self._consume_event(event)
            return True

        return False

    def _handle_filter_edit_key(self, event: Any, app: Any) -> bool:
        character = getattr(event, "character", None)
        if isinstance(character, str) and character and character.isprintable():
            append_char = getattr(app, "_append_filter_character", None)
            if callable(append_char):
                append_char(character, focus_filter=False)
                self._consume_event(event)
                return True

        if event.key == "backspace":
            pop_char = getattr(app, "_pop_filter_character", None)
            if callable(pop_char):
                pop_char(focus_filter=False)
                self._consume_event(event)
                return True

        return False

    def on_key(self, event: Any) -> None:  # pragma: no cover - exercised in integration tests
        app = self.app
        if app is None:
            return

        if self._handle_paging_key(event, app):
            return

        if self._handle_filter_edit_key(event, app):
            return


class AgentsApp(App[AgentInfo | None], ScreenshotCaptureMixin):
    """Main Textual app for `/agents` command."""

    CSS_PATH = CSS_FILE_NAME

    BINDINGS = [
        Binding("escape", APP_QUIT_ACTION, "Close", show=True, priority=True),
        Binding("ctrl+c", APP_QUIT_ACTION, "Quit", show=False),
        Binding("enter", "select_agent", "Select", show=True),
        Binding("up", "cursor_up", "Up", show=False, priority=True),
        Binding("down", "cursor_down", "Down", show=False, priority=True),
        Binding("left", "page_left", "Prev", show=True, priority=True),
        Binding("right", "page_right", "Next", show=True, priority=True),
        Binding("[", "page_left", "Prev", show=False, priority=True),
        Binding("]", "page_right", "Next", show=False, priority=True),
        Binding("/", "focus_filter", "Filter", show=False),
    ]

    agents: reactive[list[AgentInfo]] = reactive(list)
    filtered_agents: reactive[list[AgentInfo]] = reactive(list)
    selected_agent: reactive[AgentInfo | None] = reactive(None)

    def __init__(
        self,
        *,
        ctx: TUIContext | None = None,
        agents_data: list[dict[str, Any]] | None = None,
        fetch_page: AgentPageFetcher | None = None,
        page_size: int = DEFAULT_PAGE_SIZE,
        dynamic_page_size: bool | None = None,
    ) -> None:
        super().__init__()
        self._ctx = ctx
        self._raw_agents_data = agents_data or []
        self._fetch_page = fetch_page
        self._keybind_registry: KeybindRegistry | None = None
        self._toast_bus: ToastBus | None = None

        self._base_page_size = max(1, page_size)
        self._dynamic_page_size_enabled = (
            dynamic_page_size if dynamic_page_size is not None else self._base_page_size == DEFAULT_PAGE_SIZE
        )
        self._page_size = self._base_page_size
        self._mounted = False
        self._current_page = 1
        self._total_pages = 1
        self._total_items = 0
        self._has_next = False
        self._has_prev = False
        self._last_query = ""
        self._filter_source_cache: list[AgentInfo] | None = None
        self._initial_load_pending = True
        self._selection_handoff_pending = False
        self._page_load_in_flight = False
        self._page_load_request_id = 0

    def compose(self) -> ComposeResult:
        with Vertical(id="main-container"):
            yield Static("Select an agent to open its workspace", id="header")
            yield AgentsFilterInput(placeholder="Filter agents...", id="filter-input")
            yield Static(LOADING_AGENTS_MESSAGE, id=AGENTS_LOADING_PLACEHOLDER_ID.lstrip("#"))
            yield AgentsDataTable(id="agents-table", classes="-hidden")
            loading = PulseIndicator(id=AGENTS_LOADING_ID.lstrip("#"), variant="info", width=14)
            loading.display = True
            with Horizontal(id="status-row"):
                yield loading
                yield Static(LOADING_AGENTS_MESSAGE, id="status")
        yield Footer()

    def on_mount(self) -> None:
        self._mounted = True
        self._initialize_services()
        self._setup_table()
        self._sync_dynamic_page_size(reload=False)
        self.query_one(FILTER_INPUT_ID, Input).focus()
        self._set_initial_loading_state(True)
        if self._should_use_async_initial_load():
            self.call_after_refresh(self._load_agents_async)
        else:
            self.call_after_refresh(self._load_agents)
        self.call_after_refresh(self._sync_dynamic_page_size)

    def on_resize(self, event: Any) -> None:
        if not self._mounted:
            return
        self._sync_dynamic_page_size()

    def on_unmount(self) -> None:  # pragma: no cover - UI lifecycle hook
        """Cancel in-flight workers so late callbacks cannot mutate detached UI."""
        self._mounted = False
        self._page_load_in_flight = False
        self._page_load_request_id += 1
        cancel_worker_group(self, AGENTS_LOAD_WORKER_GROUP)
        parent_on_unmount = getattr(super(), "on_unmount", None)
        if callable(parent_on_unmount):
            parent_on_unmount()  # type: ignore[misc]

    def _next_page_load_request_id(self) -> int:
        """Return a monotonically increasing request id for async page loads."""
        self._page_load_request_id += 1
        return self._page_load_request_id

    def _dynamic_page_size(self) -> int:
        viewport_height = int(getattr(self.size, "height", 0) or 0)
        if viewport_height <= 0:
            return self._base_page_size  # pragma: no cover - unattached geometry fallback
        return max(MIN_DYNAMIC_PAGE_SIZE, viewport_height - PAGE_CHROME_RESERVED_ROWS)

    def _sync_dynamic_page_size(self, *, reload: bool = True) -> None:
        if not self._dynamic_page_size_enabled:
            return

        updated_limit = self._dynamic_page_size()
        if updated_limit == self._page_size:
            return

        previous_limit = self._page_size
        previous_page = self._current_page
        self._page_size = updated_limit

        if not reload:
            return

        first_item_index = max(0, (max(1, previous_page) - 1) * max(1, previous_limit))
        target_page = (first_item_index // self._page_size) + 1
        self._load_page(target_page)

    def _initialize_services(self) -> None:
        self._toast_bus = ToastBus()
        self._keybind_registry = KeybindRegistry()
        self._register_keybindings()

    def _register_keybindings(self) -> None:
        if self._keybind_registry is None:
            return
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="select_agent",
            key="enter",
            description="Select agent",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="focus_filter",
            key="/",
            description="Focus filter",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="page_left",
            key="left",
            description="Previous page",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="page_right",
            key="right",
            description="Next page",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="cursor_up",
            key="up",
            description="Previous row",
        )
        self._keybind_registry.register(
            category=KEYBIND_CATEGORY,
            action="cursor_down",
            key="down",
            description="Next row",
        )

    def _setup_table(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        table.add_columns("ID", "Name", "Description")
        table.cursor_type = "row"
        table.zebra_stripes = True

    def _load_agents(self) -> None:
        self._load_page(self._current_page)

    def _load_agents_async(self) -> None:
        """Run initial page load in worker to avoid blocking first paint."""
        request_id = self._next_page_load_request_id()
        self.run_worker(
            self._load_page_async(self._current_page, request_id=request_id),
            name="agents-load",
            group=AGENTS_LOAD_WORKER_GROUP,
            exclusive=True,
        )

    def _should_use_async_initial_load(self) -> bool:
        """Return True when initial selector load should use a worker."""
        return self._fetch_page is not None and not self._raw_agents_data

    def _resolve_page_data(self, page: int, limit: int) -> AgentPage:
        """Resolve one page payload from callback/local/default sources."""
        if self._fetch_page is not None:
            return self._coerce_page_result(self._fetch_page(page, limit), page, limit)
        if self._raw_agents_data:
            return self._build_local_page(page, limit)
        return self._fetch_agents_page(page, limit)

    async def _load_page_async(self, page: int, *, request_id: int | None = None) -> None:
        """Load one page asynchronously while keeping UI responsive."""
        if request_id is None:
            request_id = self._next_page_load_request_id()

        if request_id != self._page_load_request_id:
            return

        if self._page_load_in_flight:
            return

        show_loading_indicator(self, AGENTS_LOADING_ID, message=LOADING_AGENTS_MESSAGE)
        self._page_load_in_flight = True
        try:
            page_data = await asyncio.to_thread(self._resolve_page_data, page, self._page_size)

            if request_id != self._page_load_request_id or not self._mounted:
                return

            self._apply_page(page_data)
            self._apply_filter(self._last_query)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            if request_id != self._page_load_request_id or not self._mounted:
                return
            logger.error("Failed to load agents: %s", exc)
            self._show_error(f"Failed to load agents: {exc}")
        finally:
            self._page_load_in_flight = False
            hide_loading_indicator(self, AGENTS_LOADING_ID)
            self._set_initial_loading_state(False)
            if self._mounted:
                self._sync_dynamic_page_size()

    def _load_page(self, page: int) -> None:
        if self._page_load_in_flight:
            return

        show_loading_indicator(self, AGENTS_LOADING_ID, message=LOADING_AGENTS_MESSAGE)
        self._page_load_in_flight = True
        try:
            page_data = self._resolve_page_data(page, self._page_size)

            self._apply_page(page_data)
            self._apply_filter(self._last_query)

        except Exception as exc:
            logger.error("Failed to load agents: %s", exc)
            self._show_error(f"Failed to load agents: {exc}")
        finally:
            self._page_load_in_flight = False
            hide_loading_indicator(self, AGENTS_LOADING_ID)
            self._set_initial_loading_state(False)

    def _set_initial_loading_state(self, is_loading: bool) -> None:
        """Toggle initial loading placeholder so we avoid empty-table flashes."""
        try:
            placeholder = self.query_one(AGENTS_LOADING_PLACEHOLDER_ID, Static)
            table = self.query_one(AGENTS_TABLE_ID, DataTable)
        except Exception:
            return

        if not all(
            (
                callable(getattr(placeholder, "add_class", None)),
                callable(getattr(placeholder, "remove_class", None)),
                callable(getattr(table, "add_class", None)),
                callable(getattr(table, "remove_class", None)),
            )
        ):
            return

        if is_loading and self._initial_load_pending:
            placeholder.remove_class("-hidden")
            table.add_class("-hidden")
            return

        self._initial_load_pending = False
        placeholder.add_class("-hidden")
        table.remove_class("-hidden")

    def _apply_page(self, page_data: AgentPage) -> None:
        self._current_page = max(1, page_data.page)
        self._page_size = max(1, page_data.limit)
        self.agents = list(page_data.items)

        total = page_data.total if page_data.total is not None else len(page_data.items)
        self._total_items = max(0, total)
        self._total_pages = max(1, (self._total_items + self._page_size - 1) // self._page_size)

        self._has_prev = page_data.has_prev if page_data.has_prev is not None else self._current_page > 1
        self._has_next = (
            page_data.has_next if page_data.has_next is not None else self._current_page < self._total_pages
        )
        # Invalidate cached global filter source when page payload changes.
        self._filter_source_cache = None

    def _build_local_page(self, page: int, limit: int) -> AgentPage:
        agents = self._parse_agents(self._raw_agents_data)
        total = len(agents)
        start = max(0, (max(1, page) - 1) * limit)
        end = start + limit
        return AgentPage(
            items=agents[start:end],
            total=total,
            page=max(1, page),
            limit=limit,
            has_prev=page > 1,
            has_next=end < total,
        )

    def _coerce_mapping_page_result(self, payload: dict[str, Any], page: int, limit: int) -> AgentPage:
        """Coerce dict-like page payloads into a normalized `AgentPage`."""
        items = self._parse_agents(payload.get("data") or payload.get("items") or [])
        return AgentPage(
            items=items,
            total=payload.get("total"),
            page=int(payload.get("page") or page),
            limit=int(payload.get("limit") or limit),
            has_next=payload.get("has_next"),
            has_prev=payload.get("has_prev"),
        )

    def _coerce_object_page_result(self, payload: Any, page: int, limit: int) -> AgentPage:
        """Coerce object-style page payloads into a normalized `AgentPage`."""
        items = self._parse_agents(payload.items)
        return AgentPage(
            items=items,
            total=payload.total,
            page=(payload.page if hasattr(payload, "page") else page) or page,
            limit=(payload.limit if hasattr(payload, "limit") else limit) or limit,
            has_next=payload.has_next if hasattr(payload, "has_next") else None,
            has_prev=payload.has_prev if hasattr(payload, "has_prev") else None,
        )

    def _coerce_page_result(self, payload: Any, page: int, limit: int) -> AgentPage:
        if isinstance(payload, AgentPage):
            return payload

        if isinstance(payload, dict):
            return self._coerce_mapping_page_result(payload, page, limit)

        if hasattr(payload, "items") and hasattr(payload, "total"):
            return self._coerce_object_page_result(payload, page, limit)

        if isinstance(payload, list):
            return AgentPage(items=self._parse_agents(payload), total=len(payload), page=1, limit=max(1, len(payload)))

        return AgentPage(items=[], total=0, page=1, limit=limit)

    def _parse_agents(self, data: list[dict[str, Any]] | list[Any]) -> list[AgentInfo]:
        agents: list[AgentInfo] = []
        for item in data:
            payload = self._agent_to_dict(item)
            agents.append(
                AgentInfo(
                    id=str(payload.get("id", "")),
                    name=payload.get("name", "Unnamed"),
                    description=payload.get("description", "") or "",
                    mcp_count=len(payload.get("mcps", []) or []),
                    is_active=bool(payload.get("is_active", False)),
                )
            )
        return sorted(agents, key=lambda a: a.name.lower())

    def _agent_to_dict(self, item: Any) -> dict[str, Any]:
        if isinstance(item, dict):
            return item
        return {
            "id": getattr(item, "id", ""),
            "name": getattr(item, "name", "Unnamed"),
            "description": getattr(item, "description", ""),
            "mcps": getattr(item, "mcps", []) or [],
            "is_active": getattr(item, "is_active", False),
        }

    def _fetch_agents(self) -> list[AgentInfo]:
        return []

    def _fetch_agents_page(self, page: int, limit: int) -> AgentPage:
        all_agents = self._fetch_agents()
        total = len(all_agents)
        start = max(0, (max(1, page) - 1) * limit)
        end = start + limit
        return AgentPage(
            items=all_agents[start:end],
            total=total,
            page=max(1, page),
            limit=limit,
            has_prev=page > 1,
            has_next=end < total,
        )

    def _build_filter_source(self) -> list[AgentInfo]:
        """Build filter source across all available agents.

        Behavior:
        - For local demo payloads, use full in-memory list.
        - For paged callbacks, collect all pages once and cache while filtering.
        - For non-paged fallback path, use current loaded page.
        """
        if self._raw_agents_data:
            return self._parse_agents(self._raw_agents_data)

        if self._fetch_page is None:
            return list(self.agents)

        if self._filter_source_cache is not None:
            return self._filter_source_cache

        self._filter_source_cache = self._collect_filter_source_from_pages()
        return self._filter_source_cache

    def _collect_filter_source_from_pages(self) -> list[AgentInfo]:
        """Collect unique agents across paged fetch callback responses."""
        fetch_page = self._fetch_page
        if fetch_page is None:
            return list(self.agents)

        collected: list[AgentInfo] = []
        seen_ids: set[str] = set()
        page = 1

        while True:
            page_data = self._coerce_page_result(fetch_page(page, self._page_size), page, self._page_size)
            self._append_unique_agents(page_data.items, collected, seen_ids)

            if self._is_last_filter_page(page_data, collected):
                break

            page += 1

        return sorted(collected, key=lambda a: a.name.lower())

    @staticmethod
    def _append_unique_agents(
        page_items: list[AgentInfo],
        collected: list[AgentInfo],
        seen_ids: set[str],
    ) -> None:
        for agent in page_items:
            if agent.id in seen_ids:
                continue
            seen_ids.add(agent.id)
            collected.append(agent)

    @staticmethod
    def _is_last_filter_page(page_data: AgentPage, collected: list[AgentInfo]) -> bool:
        if page_data.has_next is not None:
            return not page_data.has_next

        total = page_data.total if page_data.total is not None else len(collected)
        return len(collected) >= total or not page_data.items

    @staticmethod
    def _format_description(description: str) -> str:
        if len(description) <= DESCRIPTION_MAX_LEN:
            return description
        return description[:DESCRIPTION_MAX_LEN] + "..."

    @staticmethod
    def _format_display_id(agent_id: str) -> str:
        value = str(agent_id or "")
        if len(value) <= (ID_VISIBLE_PREFIX_LEN + ID_VISIBLE_SUFFIX_LEN):
            return value
        return f"{value[:ID_VISIBLE_PREFIX_LEN]}****{value[-ID_VISIBLE_SUFFIX_LEN:]}"

    def _update_table(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        previous_row = table.cursor_row if table.cursor_row is not None else 0
        table.clear()

        if not self.filtered_agents:
            status = self.query_one(STATUS_ID, Static)
            if self.agents:
                status.update("No agents match the filter")
            else:
                status.update("No agents available")
            return

        for agent in self.filtered_agents:
            table.add_row(
                self._format_display_id(agent.id),
                agent.name,
                self._format_description(agent.description),
            )

        target_row = max(0, min(previous_row, len(self.filtered_agents) - 1))
        try:
            table.cursor_coordinate = Coordinate(target_row, 0)
        except Exception:
            pass

        status = self.query_one(STATUS_ID, Static)
        status.update(self._status_line())

    def _status_line(self) -> str:
        if self._last_query:
            return f"{len(self.filtered_agents)} match(es) | global filter"

        parts = [
            f"{len(self.filtered_agents)} shown",
            f"page {self._current_page}/{self._total_pages}",
            "↑↓ navigate",
        ]
        if self._has_prev or self._has_next:
            parts.append("←/→ or bracket keys page")
        return " | ".join(parts)

    def watch_filtered_agents(self, agents: list[AgentInfo]) -> None:
        self._update_table()

    @staticmethod
    def _compact_alnum(value: str) -> str:
        return re.sub(r"[^a-z0-9]+", "", value.lower())

    @staticmethod
    def _tokenize_name(name: str) -> list[str]:
        return [token for token in re.split(r"[^a-z0-9]+", name.lower()) if token]

    @staticmethod
    def _best_term_token_score(term: str, name_tokens: list[str]) -> int:
        return max((_fuzzy_score(term, token) for token in name_tokens), default=-1)

    def _score_compact_single_term(self, term: str, name: str, base_score: int) -> int:
        term_compact = self._compact_alnum(term)
        if not term_compact:
            return base_score

        name_compact = self._compact_alnum(name)
        if term_compact in name_compact:
            return max(base_score, NAME_COMPACT_EXACT_BASE_SCORE + len(term_compact))

        compact_fuzzy = _fuzzy_score(term_compact, name_compact)
        if compact_fuzzy >= 0:
            return max(base_score, NAME_COMPACT_FUZZY_BASE_SCORE + compact_fuzzy)

        return base_score

    def _score_name_query(self, terms: list[str], name: str) -> int:
        name_tokens = self._tokenize_name(name)
        if not name_tokens:
            return -1

        term_scores: list[int] = []
        for term in terms:
            best_score = self._best_term_token_score(term, name_tokens)
            if best_score < 0:
                return -1
            term_scores.append(best_score)

        score = sum(term_scores)
        if len(terms) > 1:
            score += NAME_MULTI_TERM_BONUS

        if len(terms) == 1:
            score = self._score_compact_single_term(terms[0], name, score)

        return score

    def _score_id_query(self, query: str, agent_id: str) -> int:
        query_compact = self._compact_alnum(query)
        if not query_compact:
            return -1

        id_compact = self._compact_alnum(agent_id)
        position = id_compact.find(query_compact)
        if position < 0:
            return -1

        return ID_SEARCH_BASE_SCORE + min(len(query_compact), 64) - min(position, 32)

    def _apply_filter(self, query: str) -> None:
        self._last_query = query.strip().lower()
        if not self._last_query:
            self.filtered_agents = list(self.agents)
            self._filter_source_cache = None
            return

        terms = [term for term in self._last_query.split() if term]
        if not terms:  # pragma: no cover - defensive empty-split guard
            self.filtered_agents = list(self.agents)
            return

        source = self._build_filter_source()
        scored_agents: list[tuple[int, int, int, str, str, AgentInfo]] = []

        for agent in source:
            name_score = self._score_name_query(terms, agent.name)
            id_score = self._score_id_query(self._last_query, agent.id)
            best_score = max(name_score, id_score)
            if best_score < 0:
                continue

            scored_agents.append((best_score, id_score, name_score, agent.name.lower(), agent.id.lower(), agent))

        scored_agents.sort(key=lambda row: (-row[0], -row[1], -row[2], row[3], row[4]))
        self.filtered_agents = [agent for _best, _id_score, _name_score, _name, _id, agent in scored_agents]

    def on_input_changed(self, event: Input.Changed) -> None:
        event_input = getattr(event, "input", None)
        if event_input is not None:
            input_id = getattr(event_input, "id", None)
            if input_id is not None and input_id != FILTER_INPUT_ID.lstrip("#"):
                return
        self._apply_filter(getattr(event, "value", ""))

    def _append_filter_character(self, character: str, *, focus_filter: bool = True) -> None:
        filter_input = self.query_one(FILTER_INPUT_ID, Input)
        if focus_filter:
            filter_input.focus()
        filter_input.value = f"{filter_input.value}{character}"
        filter_input.cursor_position = len(filter_input.value)
        self._apply_filter(filter_input.value)

    def _pop_filter_character(self, *, focus_filter: bool = True) -> None:
        filter_input = self.query_one(FILTER_INPUT_ID, Input)
        if focus_filter:
            filter_input.focus()
        if not filter_input.value:
            return
        filter_input.value = filter_input.value[:-1]
        filter_input.cursor_position = len(filter_input.value)
        self._apply_filter(filter_input.value)

    def on_key(self, event: Any) -> None:
        key = getattr(event, "key", "")
        if key not in {"left", "right", "[", "]", "left_square_bracket", "right_square_bracket"}:
            return

        filter_input = self.query_one(FILTER_INPUT_ID, Input)
        if filter_input.has_focus and key in {"left", "right"}:
            return

        if key in {"left", "[", "left_square_bracket"}:
            self.action_page_left()
        else:
            self.action_page_right()

        stop = getattr(event, "stop", None)
        if callable(stop):
            stop()

    def action_focus_filter(self) -> None:
        self.query_one(FILTER_INPUT_ID, Input).focus()

    def _move_cursor(self, delta: int) -> None:
        if not self.filtered_agents:
            return

        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        current = table.cursor_row if table.cursor_row is not None else 0
        target = max(0, min(len(self.filtered_agents) - 1, current + delta))

        try:
            table.cursor_coordinate = Coordinate(target, 0)
        except Exception:
            try:
                table.move_cursor(row=target, column=0)
            except Exception:
                pass

        table.focus()

    def action_cursor_up(self) -> None:
        self._move_cursor(-1)

    def action_cursor_down(self) -> None:
        self._move_cursor(1)

    def action_page_left(self) -> None:
        if self._last_query:
            return
        if self._has_prev:
            self._load_page(self._current_page - 1)

    def action_page_right(self) -> None:
        if self._last_query:
            return
        if self._has_next:
            self._load_page(self._current_page + 1)

    def action_select_agent(self) -> None:
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        if not self.filtered_agents:
            return

        row_index = table.cursor_row if table.cursor_row is not None else 0
        self._select_agent_at_row(row_index)

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:  # type: ignore[override]
        """Handle row activation (keyboard Enter)."""
        self._select_agent_at_row(event.cursor_row)

    def on_data_table_cell_selected(self, event: DataTable.CellSelected) -> None:  # type: ignore[override]
        """Handle mouse click selection."""
        self._select_agent_at_row(event.coordinate.row)

    def _select_agent_at_row(self, row_index: int) -> None:
        if not self.filtered_agents:
            return

        target_row = max(0, min(row_index, len(self.filtered_agents) - 1))
        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        try:
            table.cursor_coordinate = Coordinate(target_row, 0)
        except Exception:
            pass

        try:
            agent = self.filtered_agents[target_row]
        except IndexError:  # pragma: no cover
            self._show_error("Invalid selection")
            return

        self.selected_agent = agent
        self._on_agent_selected(agent)

    def _on_agent_selected(self, agent: AgentInfo) -> None:
        if self._selection_handoff_pending:
            return
        self._selection_handoff_pending = True

        if self._toast_bus:
            self._toast_bus.show(f"Opening {agent.name} workspace...", variant="info")

        status = self.query_one(STATUS_ID, Static)
        status.update(f"Opening {agent.name} workspace...")
        show_loading_indicator(self, AGENTS_LOADING_ID, message="Opening workspace...")

        filter_input = self.query_one(FILTER_INPUT_ID, Input)
        filter_input.disabled = True

        table = self.query_one(AGENTS_TABLE_ID, DataTable)
        table.disabled = True

        self.set_timer(SELECTION_HANDOFF_DELAY_SECONDS, lambda: self._complete_agent_selection(agent))

    def _complete_agent_selection(self, agent: AgentInfo) -> None:
        """Exit selector after showing handoff feedback briefly."""
        self.exit(agent)

    def _show_error(self, message: str) -> None:
        try:
            self.query_one(STATUS_ID, Static).update(f"Error: {message}")
        except Exception:  # pragma: no cover - defensive: widget may not exist in tests
            pass
        if self._toast_bus:
            self._toast_bus.show(message, variant="error")


def run_agents_app(
    *,
    ctx: TUIContext | None = None,
    agents_data: list[dict[str, Any]] | None = None,
    fetch_page: AgentPageFetcher | None = None,
    page_size: int = 25,
) -> AgentInfo | None:
    """Run agents selector app and return selected agent."""
    app = AgentsApp(ctx=ctx, agents_data=agents_data, fetch_page=fetch_page, page_size=page_size)  # pragma: no cover
    return app.run()  # pragma: no cover


if __name__ == "__main__":
    demo_agents = [
        {
            "id": "agent-001",
            "name": "Code Reviewer",
            "description": "Reviews code for best practices and potential issues",
            "mcps": ["mcp-github", "mcp-gitlab"],
            "is_active": False,
        },
        {
            "id": "agent-002",
            "name": "Documentation Writer",
            "description": "Creates and updates technical documentation",
            "mcps": ["mcp-notion", "mcp-confluence"],
            "is_active": True,
        },
        {
            "id": "agent-003",
            "name": "Bug Triage",
            "description": "Triage and prioritize bug reports",
            "mcps": ["mcp-jira", "mcp-slack"],
            "is_active": False,
        },
    ]

    selected = run_agents_app(agents_data=demo_agents, page_size=2)
    if selected:
        logger.info("Selected: %s (%s)", selected.name, selected.id)
    else:
        logger.info("No agent selected")
