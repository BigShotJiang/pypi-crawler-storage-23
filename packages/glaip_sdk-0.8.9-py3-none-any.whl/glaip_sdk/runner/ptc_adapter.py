"""PTC adapter for local runner integration.

This module provides validation and normalization of PTC configuration
for use in the local LangGraph runner. It ensures PTC is configured
correctly and rejects unsupported configuration sources.

Authors:
    Christian Trisno Sen Long Chen (christian.t.s.l.chen@gdplabs.id)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from glaip_sdk.exceptions import ValidationError

if TYPE_CHECKING:
    from glaip_sdk.ptc import PTC


def validate_ptc_for_local_run(
    agent_ptc: PTC | None,
    agent_config_ptc: Any | None,
    runtime_config_ptc: Any | None,
) -> PTC | None:
    """Validate PTC configuration for local runs.

    Args:
        agent_ptc: PTC object from Agent.ptc parameter.
        agent_config_ptc: PTC from agent_config (should be None for local).
        runtime_config_ptc: PTC from runtime_config (should be None for v1).

    Returns:
        Validated PTC object if enabled, None otherwise.

    Raises:
        ValidationError: If agent_config.ptc or runtime_config.ptc are provided,
            or if agent_ptc is not a PTC instance when provided.
    """
    if agent_config_ptc is not None:
        msg = (
            "PTC configuration via agent_config.ptc is not supported for local runs. "
            "Please configure PTC using the Agent.ptc parameter instead: "
            "Agent(name='...', ptc=PTC(enabled=True), ...)"
        )
        raise ValidationError(msg)

    if runtime_config_ptc is not None:
        msg = (
            "PTC configuration via runtime_config.ptc is not supported in v1. "
            "PTC configuration must be set at Agent initialization time using "
            "the Agent.ptc parameter and cannot be overridden at runtime. "
            "This preserves local/remote parity and prevents ambiguous precedence."
        )
        raise ValidationError(msg)

    if agent_ptc is None:
        return None

    from glaip_sdk.ptc import PTC  # noqa: PLC0415

    if not isinstance(agent_ptc, PTC):
        msg = (
            f"Agent.ptc must be a PTC instance, got {type(agent_ptc).__name__}. "
            "Example: Agent(name='...', ptc=PTC(enabled=True), ...)"
        )
        raise ValidationError(msg)

    if not agent_ptc.enabled:
        return None

    return agent_ptc


def normalize_ptc_for_aip_agents(
    ptc: PTC | None,
    custom_tools_config: Any | None = None,
) -> Any:
    """Normalize PTC config for aip-agents LangGraphReactAgent.

    Args:
        ptc: Validated PTC object or None.
        custom_tools_config: Optional PTCCustomToolConfig for custom tools.

    Returns:
        PTCSandboxConfig for aip-agents or None if PTC disabled.
    """
    if ptc is None or not ptc.enabled:
        return None

    from aip_agents.ptc import PromptConfig, PTCSandboxConfig  # noqa: PLC0415

    # Build PromptConfig if prompt dict is provided.
    prompt_config = None
    if ptc.prompt is not None:
        prompt_config = PromptConfig(**ptc.prompt)

    # Always pass core PTC fields from SDK config for deterministic parity.
    # Note: user-provided `ptc.custom_tools` is rejected at PTC validation time;
    # `custom_tools` here is internal builder output derived from Agent.tools.
    # Include `ptc_packages` only when explicitly configured on the PTC object.
    kwargs: dict[str, Any] = {
        "enabled": ptc.enabled,
        "sandbox_timeout": ptc.sandbox_timeout,
        "default_tool_timeout": ptc.default_tool_timeout,
        "prompt": prompt_config,
    }
    if ptc.sandbox_template is not None:
        kwargs["sandbox_template"] = ptc.sandbox_template
    if custom_tools_config is not None:
        kwargs["custom_tools"] = custom_tools_config

    # Pass ptc_packages only when explicitly set (including empty list).
    # When None, omit to preserve aip-agents smart package selection.
    if ptc.ptc_packages is not None:
        kwargs["ptc_packages"] = ptc.ptc_packages

    return PTCSandboxConfig(**kwargs)
