"""
Base class for integration tests.
"""

import argparse
import os
import sys
import time
from collections.abc import Callable
from typing import Any

# We need to add the project src to Python path before importing kanka
# This is required because this module is imported by test files
_current_dir = os.path.dirname(os.path.abspath(__file__))
_project_root = os.path.abspath(os.path.join(_current_dir, "../.."))
_src_dir = os.path.join(_project_root, "src")
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

from kanka import KankaClient  # noqa: E402 - Must be after path setup


class IntegrationTestBase:
    """Base class for integration tests with credential checking."""

    def __init__(self):
        self.client: KankaClient | None = None
        self.campaign_id: int | None = None
        self.token: str | None = None
        self._cleanup_tasks: list[tuple[str, Callable]] = []
        self._defer_cleanup = False
        self._pause_before_cleanup = False

    def setup(self):
        """Set up the test client with credentials from environment."""
        self.token = os.environ.get("KANKA_TOKEN")
        campaign_id_str = os.environ.get("KANKA_CAMPAIGN_ID")

        if not self.token:
            raise ValueError(
                "KANKA_TOKEN environment variable is required. "
                "Please set it to your Kanka API token."
            )

        if not campaign_id_str:
            raise ValueError(
                "KANKA_CAMPAIGN_ID environment variable is required. "
                "Please set it to your campaign ID."
            )

        try:
            self.campaign_id = int(campaign_id_str)
        except ValueError as e:
            raise ValueError(
                f"KANKA_CAMPAIGN_ID must be a valid integer, got: {campaign_id_str}"
            ) from e

        self.client = KankaClient(self.token, self.campaign_id)

        # Check environment variables for cleanup behavior
        self._defer_cleanup = (
            os.environ.get("KANKA_TEST_DEFER_CLEANUP", "").lower() == "true"
        )
        self._pause_before_cleanup = (
            os.environ.get("KANKA_TEST_PAUSE_CLEANUP", "").lower() == "true"
        )

    def register_cleanup(self, description: str, cleanup_func: Callable):
        """Register a cleanup task to be executed later."""
        self._cleanup_tasks.append((description, cleanup_func))

    def teardown(self):
        """Clean up resources."""
        if not self._defer_cleanup:
            self._execute_cleanup_tasks()

    def _execute_cleanup_tasks(self):
        """Execute all registered cleanup tasks."""
        if not self._cleanup_tasks:
            return

        print("\nExecuting cleanup tasks...")
        for description, cleanup_func in self._cleanup_tasks:
            try:
                cleanup_func()
                print(f"  ✓ {description}")
            except Exception as e:
                print(f"  ✗ {description} failed: {str(e)}")
        self._cleanup_tasks.clear()

    def run_test(self, test_name: str, test_func):
        """Run a single test with proper setup and teardown."""
        print(f"\nRunning {test_name}...")
        try:
            self.setup()
            test_func()
            print(f"✓ {test_name} passed")
            return True
        except Exception as e:
            print(f"✗ {test_name} failed: {str(e)}")
            import traceback

            traceback.print_exc()
            return False
        finally:
            self.teardown()

    def assert_equal(self, actual: Any, expected: Any, message: str = ""):
        """Assert that two values are equal."""
        if actual != expected:
            raise AssertionError(f"{message}\nExpected: {expected}\nActual: {actual}")

    def assert_true(self, condition: bool, message: str = ""):
        """Assert that a condition is true."""
        if not condition:
            raise AssertionError(f"Assertion failed: {message}")

    def assert_in(self, item: Any, container: Any, message: str = ""):
        """Assert that an item is in a container."""
        if item not in container:
            raise AssertionError(f"{message}\n{item} not found in {container}")

    def assert_not_none(self, value: Any, message: str = ""):
        """Assert that a value is not None."""
        if value is None:
            raise AssertionError(f"Value is None: {message}")

    def wait_for_api(self, seconds: float = 0.5):
        """Wait a bit to avoid rate limiting."""
        time.sleep(seconds)

    def run_all_tests(self) -> list[tuple[str, bool]]:
        """Run all tests. Subclasses must override this."""
        raise NotImplementedError

    @classmethod
    def run_standalone(cls, title: str = "INTEGRATION TEST"):
        """Run this test class standalone with --pause support.

        Call from ``if __name__ == "__main__"`` blocks::

            TestFooIntegration.run_standalone("FOO INTEGRATION TEST")
        """
        parser = argparse.ArgumentParser()
        parser.add_argument(
            "-p",
            "--pause",
            action="store_true",
            help="Defer cleanup and pause before cleanup for manual inspection",
        )
        args = parser.parse_args()

        if args.pause:
            os.environ["KANKA_TEST_DEFER_CLEANUP"] = "true"
            os.environ["KANKA_TEST_PAUSE_CLEANUP"] = "true"

        tester = cls()
        results = tester.run_all_tests()

        # Handle deferred cleanup
        if args.pause and tester._cleanup_tasks:
            print(f"\n{'=' * 50}")
            print("PAUSED BEFORE CLEANUP")
            print("=" * 50)
            print(f"About to clean up {len(tester._cleanup_tasks)} items:")
            for description, _ in tester._cleanup_tasks:
                print(f"  - {description}")
            print("\nYou can now inspect these entities in the Kanka web app.")
            input("Press Enter to continue with cleanup...")
            tester._execute_cleanup_tasks()

        print(f"\n{'=' * 50}")
        print(f"{title} RESULTS")
        print("=" * 50)

        passed = sum(1 for _, result in results if result)
        total = len(results)

        for test_name, result in results:
            status = "PASSED" if result else "FAILED"
            print(f"{test_name}: {status}")

        print(f"\nTotal: {passed}/{total} tests passed")

        if passed < total:
            sys.exit(1)
