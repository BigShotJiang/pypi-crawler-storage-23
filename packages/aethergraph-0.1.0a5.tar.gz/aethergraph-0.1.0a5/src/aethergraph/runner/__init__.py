# Aethergraph Runner -- direct aethergraph.core.runtime.graph_runner for clean imports

from aethergraph.core.runtime.graph_runner import run, run_async

__all__ = ["run", "run_async"]
