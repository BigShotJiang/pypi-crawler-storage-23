## Sincpro Payments SDK

SDK para integración con pasarelas de pago y servicios bancarios, construido sobre el **Sincpro Framework** con arquitectura hexagonal.

---

## Bounded Contexts

### `cybersource` — Pagos con tarjeta (Cybersource)

Proveedor: **Cybersource / Linkser**

| Use case | Command |
|----------|---------|
| Tokenizar tarjeta | `CommandCreatePaymentMethod` |
| Tokenizar tarjeta + cliente | `CommandCreateCustomerPaymentMethod` |
| Pago tarjeta nueva (enrollment) | `CommandPayNewCardEnrollment` |
| Pago tarjeta nueva (validación) | `CommandPayNewCardValidation` |
| Pago tarjeta guardada (enrollment) | `CommandPaySavedCardEnrollment` |
| Pago tarjeta guardada (validación) | `CommandPaySavedCardValidation` |
| Pago recurrente | `CommandRecurringPayment` |
| Cancelar / reembolso | `CommandCancelOrRefund` |
| Pre-pago: setup auth | `CommandSetupAuth` |
| Pre-pago: iniciar monitor | `CommandStartMonitorAuth` |
| Pre-pago: verificar 3DS | `CommandCheckRequireAuth` |
| Pre-pago: validar auth | `CommandValidateAuth` |

```python
from sincpro_payments_sdk.apps.cybersource import cybersource, tokenization

result = cybersource(
    tokenization.CommandCreatePaymentMethod(...),
    tokenization.ResponseCreatePaymentMethod,
)
```

---

### `qr` — Pagos QR

Tres proveedores bajo el mismo bounded context:

#### BNB
| Use case | Command |
|----------|---------|
| Autenticar | `CommandAuthenticateBNB` |
| Crear QR | `CommandCreateQR` |
| Verificar estado | `CommandCheckQRStatus` |
| Listar QRs | `CommandListQRs` |
| Cancelar QR | `CommandCancelQR` |

#### Banco Económico
| Use case | Command |
|----------|---------|
| Autenticar | `CommandAuthenticateEconomico` |
| Crear QR | `CommandCreateQR` |
| Verificar estado | `CommandCheckQRStatus` |
| QRs cobrados | `CommandGetPaidQRs` |
| Cancelar QR | `CommandCancelQR` |

#### Linkser
| Use case | Command |
|----------|---------|
| Crear QR | `CommandCreateQR` |
| Verificar estado | `CommandCheckQRStatus` |

```python
from sincpro_payments_sdk.apps.qr import qr, economico, bnb, linkser

auth = qr(
    economico.CommandAuthenticateEconomico(user_name="...", password="...", aes_key="..."),
    economico.ResponseAuthenticateEconomico,
)
qr_image = qr(economico.CommandCreateQR(...), economico.ResponseCreateQR)
```

---

### `bank_account` — Extractos bancarios (Banco Económico)

| Use case | Command |
|----------|---------|
| Autenticar | `CommandAuthenticateEconomico` |
| Consultar movimientos | `CommandGetMovements` |

```python
from sincpro_payments_sdk.apps.bank_account import bank_account, economico

auth = bank_account(
    economico.CommandAuthenticateEconomico(user_name="...", password="...", aes_key="..."),
    economico.ResponseAuthenticateEconomico,
)
movements = bank_account(
    economico.CommandGetMovements(account_code="...", start_date=..., end_date=...),
    economico.ResponseGetMovements,
)
```

---

## Documentación

Documentación detallada de DTOs, Features y Application Services disponible en [`generated_docs/site/index.html`](generated_docs/site/index.html).

Para regenerar:

```bash
make docs
```

---

## Desarrollo

```bash
make install          # instalar dependencias
make format           # formatear código (obligatorio antes de commit)
make test             # ejecutar tests
make test_one t=<archivo>  # test específico
```
