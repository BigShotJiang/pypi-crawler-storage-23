"""Banco Económico domain models."""

from .qr import PaymentQR, QRId, QRImageEconomico, QRStatusCode, QRStatusEconomico
