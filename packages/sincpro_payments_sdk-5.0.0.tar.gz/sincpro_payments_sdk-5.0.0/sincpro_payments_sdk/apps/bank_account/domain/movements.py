"""Domain models for bank account movements."""

from sincpro_framework import DataTransferObject


class AccountHeader(DataTransferObject):
    """Account header from queryMovements response."""

    account_code: str | None = None
    account_type_code: str | None = None
    product_name: str | None = None
    status: str | None = None
    currency: str | None = None
    balance: float | None = None
    balance_reserved: float | None = None
    balance_retained: float | None = None
    balance_available: float | None = None


class AccountDetail(DataTransferObject):
    """Single movement from queryMovements response."""

    transaction_id: int | None = None
    date: str | None = None
    time: str | None = None
    document_number: float | None = None
    transaction_type: str | None = None
    amount: float | None = None
    description: str | None = None
    client_note: str | None = None


class AccountWithheld(DataTransferObject):
    """Withheld entry from queryMovements response."""

    date: str | None = None
    description: str | None = None
    amount: float | None = None


class AccountMovementsResponse(DataTransferObject):
    """Response from /api/accounts/queryMovements endpoint."""

    response_code: int
    message: str
    account_header: AccountHeader = AccountHeader()
    account_detail_list: list[AccountDetail] = []
    account_withheld_list: list[AccountWithheld] = []
