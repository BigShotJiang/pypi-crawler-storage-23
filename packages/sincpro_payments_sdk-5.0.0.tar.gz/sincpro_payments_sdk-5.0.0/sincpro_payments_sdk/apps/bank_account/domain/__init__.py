"""Domain package for bank account bounded context."""

from .movements import AccountMovementsResponse
