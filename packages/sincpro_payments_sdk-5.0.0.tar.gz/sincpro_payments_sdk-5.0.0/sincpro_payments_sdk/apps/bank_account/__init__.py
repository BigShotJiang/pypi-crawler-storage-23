"""Bank account bounded context — Banco Económico account statements."""

from .infrastructure.framework import (
    ApplicationService,
    DataTransferObject,
    Feature,
    config_framework,
)

bank_account = config_framework("bank-account")

from .services import economico  # noqa: E402 — registers features
