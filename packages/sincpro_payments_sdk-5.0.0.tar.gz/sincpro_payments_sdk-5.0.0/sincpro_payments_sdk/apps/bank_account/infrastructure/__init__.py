"""Infrastructure package for bank account bounded context."""
