"""Dependency registration for bank account bounded context."""

from sincpro_framework import UseFramework

from sincpro_payments_sdk.apps.bank_account.adapters.economico_account_adapter import (
    EconomicoAccountAdapter,
)
from sincpro_payments_sdk.apps.common.adapters.economico_auth_adapter import (
    BancoEconomicoAuthAdapter,
    economico_credential_provider,
)
from sincpro_payments_sdk.apps.common.domain.economico_credentials import (
    BancoEconomicoCredentials,
)
from sincpro_payments_sdk.infrastructure.provider_credentials import CredentialProvider


def register_dependencies(framework: UseFramework) -> UseFramework:
    framework.add_dependency("economico_credential_provider", economico_credential_provider)
    framework.add_dependency("economico_auth_adapter", BancoEconomicoAuthAdapter())
    framework.add_dependency("economico_account_adapter", EconomicoAccountAdapter())
    return framework


class DependencyContextType:
    """Typing helper for bank account features."""

    economico_credential_provider: CredentialProvider[BancoEconomicoCredentials]
    economico_auth_adapter: BancoEconomicoAuthAdapter
    economico_account_adapter: EconomicoAccountAdapter
