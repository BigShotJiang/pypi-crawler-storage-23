"""Banco Económico account statements adapter."""

from datetime import date
from enum import StrEnum
from typing import NotRequired, TypedDict

from sincpro_payments_sdk.apps.bank_account.domain import AccountMovementsResponse
from sincpro_payments_sdk.apps.bank_account.domain.movements import (
    AccountDetail,
    AccountHeader,
    AccountWithheld,
)
from sincpro_payments_sdk.apps.common.adapters.economico_auth_adapter import (
    BancoEconomicoAuthAdapter,
    BearerTokenAuth,
    economico_credential_provider,
)
from sincpro_payments_sdk.infrastructure.client_api import ClientAPI


class QueryMovementsRequest(TypedDict):
    accountCode: str
    startDate: str
    endDate: str


class AccountHeaderResponse(TypedDict):
    accountCode: NotRequired[str]
    accountTypeCode: NotRequired[str]
    productName: NotRequired[str]
    status: NotRequired[str]
    currency: NotRequired[str]
    balance: NotRequired[float]
    balanceReserved: NotRequired[float]
    balanceRetained: NotRequired[float]
    balanceAvailable: NotRequired[float]


class AccountDetailResponse(TypedDict):
    transactionId: NotRequired[int]
    date: NotRequired[str]
    time: NotRequired[str]
    documentNumber: NotRequired[float]
    transactionType: NotRequired[str]
    amount: NotRequired[float]
    description: NotRequired[str]
    clienteNote: NotRequired[str]


class QueryMovementsApiResponse(TypedDict):
    responseCode: NotRequired[int]
    message: NotRequired[str]
    accountHeader: NotRequired[AccountHeaderResponse]
    accountDetailList: NotRequired[list[AccountDetailResponse]]
    accountWithheldList: NotRequired[list]


class AccountRoutes(StrEnum):
    QUERY_MOVEMENTS = "/ApiGateway/api/accounts/queryMovements"


class EconomicoAccountAdapter(ClientAPI):
    """Adapter for Banco Económico account statements API."""

    def __init__(self):
        super().__init__(auth=BearerTokenAuth(economico_credential_provider))
        self._auth_adapter = BancoEconomicoAuthAdapter()

    @property
    def base_url(self) -> str:
        credentials = economico_credential_provider.get_credentials()
        return credentials.endpoint

    def query_movements(
        self,
        account_code: str,
        start_date: date,
        end_date: date,
    ) -> AccountMovementsResponse:
        credentials = economico_credential_provider.get_credentials()
        encrypted_account = self._auth_adapter.encrypt(account_code, credentials.aes_key)

        payload: QueryMovementsRequest = {
            "accountCode": encrypted_account,
            "startDate": start_date.strftime("%Y-%m-%d"),
            "endDate": end_date.strftime("%Y-%m-%d"),
        }

        response = self.execute_request(
            resource=AccountRoutes.QUERY_MOVEMENTS,
            method="POST",
            data=payload,
        )

        raw: QueryMovementsApiResponse = response.json()
        header = raw.get("accountHeader") or {}

        return AccountMovementsResponse(
            response_code=raw.get("responseCode", -1),
            message=raw.get("message", ""),
            account_header=AccountHeader(
                account_code=header.get("accountCode"),
                account_type_code=header.get("accountTypeCode"),
                product_name=header.get("productName"),
                status=header.get("status"),
                currency=header.get("currency"),
                balance=header.get("balance"),
                balance_reserved=header.get("balanceReserved"),
                balance_retained=header.get("balanceRetained"),
                balance_available=header.get("balanceAvailable"),
            ),
            account_detail_list=[
                AccountDetail(
                    transaction_id=d.get("transactionId"),
                    date=d.get("date"),
                    time=d.get("time"),
                    document_number=d.get("documentNumber"),
                    transaction_type=d.get("transactionType"),
                    amount=d.get("amount"),
                    description=d.get("description"),
                    client_note=d.get("clienteNote"),
                )
                for d in (raw.get("accountDetailList") or [])
            ],
            account_withheld_list=[
                AccountWithheld(
                    date=w.get("date"),
                    description=w.get("description"),
                    amount=w.get("amount"),
                )
                for w in (raw.get("accountWithheldList") or [])
            ],
        )
