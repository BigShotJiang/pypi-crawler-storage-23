"""Adapters package for bank account bounded context."""
