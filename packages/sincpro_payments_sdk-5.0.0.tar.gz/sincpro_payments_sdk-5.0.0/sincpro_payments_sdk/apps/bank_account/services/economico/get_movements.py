"""Get account movements use case for Banco Económico."""

from datetime import date

from sincpro_payments_sdk import exceptions
from sincpro_payments_sdk.apps.bank_account import DataTransferObject, Feature, bank_account
from sincpro_payments_sdk.apps.bank_account.domain import AccountMovementsResponse


class CommandGetMovements(DataTransferObject):
    """Command to query account movements from Banco Económico."""

    account_code: str
    start_date: date
    end_date: date


class ResponseGetMovements(AccountMovementsResponse):
    """Response from querying account movements."""


@bank_account.feature(CommandGetMovements)
class GetMovements(Feature):
    """Query account movements from Banco Económico for a given period."""

    def execute(self, dto: CommandGetMovements) -> ResponseGetMovements:
        response = self.economico_account_adapter.query_movements(
            account_code=dto.account_code,
            start_date=dto.start_date,
            end_date=dto.end_date,
        )

        if response.response_code != 0:
            raise exceptions.SincproExternalServiceError(
                f"Banco Económico account query error (code {response.response_code}): {response.message}"
            )

        return ResponseGetMovements(
            response_code=response.response_code,
            message=response.message,
            account_header=response.account_header,
            account_detail_list=response.account_detail_list,
            account_withheld_list=response.account_withheld_list,
        )
