"""Authenticate with Banco Económico — bank account context."""

from sincpro_payments_sdk import exceptions
from sincpro_payments_sdk.apps.bank_account import DataTransferObject, Feature, bank_account
from sincpro_payments_sdk.apps.common.adapters.economico_auth_adapter import (
    economico_credential_provider,
)
from sincpro_payments_sdk.apps.common.domain.economico_credentials import (
    BancoEconomicoCredentials,
    BancoEconomicoEndPoints,
)


class CommandAuthenticateEconomico(DataTransferObject):
    """Authenticate Banco Económico for bank account context."""

    user_name: str
    password: str
    aes_key: str
    production_mode: bool = False


class ResponseAuthenticateEconomico(BancoEconomicoCredentials):
    """Banco Económico authenticated credentials."""


@bank_account.feature(CommandAuthenticateEconomico)
class AuthenticateEconomico(Feature):
    """Authenticate with Banco Económico and store Bearer token."""

    def execute(self, dto: CommandAuthenticateEconomico) -> ResponseAuthenticateEconomico:
        credentials = BancoEconomicoCredentials(
            user_name=dto.user_name,
            password=dto.password,
            aes_key=dto.aes_key,
            endpoint=(
                BancoEconomicoEndPoints.CERTIFICATION
                if not dto.production_mode
                else BancoEconomicoEndPoints.PRODUCTION
            ),
        )
        economico_credential_provider.set_loader_credentials(lambda: credentials)
        authenticated_credentials = self.economico_auth_adapter.authenticate(credentials)

        if not authenticated_credentials.bearer_token:
            raise exceptions.SincproValidationError(
                "Could not authenticate Banco Económico account"
            )

        self.economico_credential_provider.set_loader_credentials(
            lambda: authenticated_credentials
        )

        return ResponseAuthenticateEconomico.model_construct(
            **authenticated_credentials.model_dump()
        )
