"""Banco Económico credentials — shared kernel."""

from enum import StrEnum

from sincpro_framework import DataTransferObject


class BancoEconomicoEndPoints(StrEnum):
    CERTIFICATION = "https://apimktdesa.baneco.com.bo"
    PRODUCTION = "https://apimkt.baneco.com.bo"


class BancoEconomicoCredentials(DataTransferObject):
    user_name: str
    password: str
    aes_key: str
    endpoint: BancoEconomicoEndPoints
    bearer_token: str | None = None
