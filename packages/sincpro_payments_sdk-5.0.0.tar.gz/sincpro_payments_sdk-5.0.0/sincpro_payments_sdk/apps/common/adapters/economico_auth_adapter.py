"""Banco Económico authentication adapter — shared kernel."""

from enum import StrEnum
from typing import TypedDict

from requests.auth import AuthBase
from sincpro_framework import logger

from sincpro_payments_sdk.apps.common.domain.economico_credentials import (
    BancoEconomicoCredentials,
    BancoEconomicoEndPoints,
)
from sincpro_payments_sdk.infrastructure.client_api import ClientAPI
from sincpro_payments_sdk.infrastructure.provider_credentials import CredentialProvider


class BearerTokenAuth(AuthBase):
    """Bearer token authentication for Banco Económico API."""

    def __init__(self, credential_provider: CredentialProvider[BancoEconomicoCredentials]):
        self._credential_provider = credential_provider
        self.bearer_token: str | None = None

    def __call__(self, request):
        self.bearer_token = self._credential_provider.get_credentials().bearer_token
        request.headers.update(
            {
                "Authorization": f"Bearer {self.bearer_token}",
                "Content-Type": "application/json",
            }
        )
        logger.debug(f"Request headers: {request.headers}")
        return request


def _get_default_credentials() -> BancoEconomicoCredentials:
    return BancoEconomicoCredentials(
        user_name="26551010",
        password="1234",
        aes_key="40A318B299F245C2B697176723088629",
        endpoint=BancoEconomicoEndPoints.CERTIFICATION,
    )


economico_credential_provider = CredentialProvider[BancoEconomicoCredentials](
    _get_default_credentials
)


class AuthenticateRequest(TypedDict):
    userName: str
    password: str


class AuthRoutes(StrEnum):
    ENCRYPT = "/ApiGateway/api/authentication/encrypt"
    DECRYPT = "/ApiGateway/api/authentication/decrypt"
    AUTHENTICATE = "/ApiGateway/api/authentication/authenticate"


class BancoEconomicoAuthAdapter(ClientAPI):
    """Adapter for Banco Económico authentication and encryption operations."""

    def __init__(self):
        super().__init__(auth=None)

    @property
    def base_url(self) -> str:
        return economico_credential_provider.get_credentials().endpoint

    def encrypt(self, text: str, aes_key: str) -> str:
        response = self.execute_request(
            AuthRoutes.ENCRYPT, "GET", params={"text": text, "aesKey": aes_key}, timeout=30
        )
        return response.json()

    def decrypt(self, text: str, aes_key: str) -> str:
        response = self.execute_request(
            AuthRoutes.DECRYPT, "GET", params={"text": text, "aesKey": aes_key}, timeout=30
        )
        return response.json()

    def authenticate(
        self, credentials: BancoEconomicoCredentials
    ) -> BancoEconomicoCredentials:
        encrypted_password = self.encrypt(credentials.password, credentials.aes_key)

        response_data = self.execute_request(
            AuthRoutes.AUTHENTICATE,
            "POST",
            data=AuthenticateRequest(
                userName=credentials.user_name,
                password=encrypted_password,
            ),
            timeout=30,
        ).json()

        bearer_token = (
            response_data.get("token")
            or response_data.get("bearerToken")
            or response_data.get("access_token")
        )
        if not bearer_token:
            bearer_token = response_data.get("data", {}).get("token")

        return BancoEconomicoCredentials(
            user_name=credentials.user_name,
            password=credentials.password,
            aes_key=credentials.aes_key,
            endpoint=credentials.endpoint,
            bearer_token=bearer_token,
        )
