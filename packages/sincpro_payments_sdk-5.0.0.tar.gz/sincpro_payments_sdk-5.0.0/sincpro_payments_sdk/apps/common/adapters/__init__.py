"""Adapters — shared kernel."""
