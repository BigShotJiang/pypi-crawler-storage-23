"""slack-cli - Slack CLI for coding agents."""

import os
import subprocess
import sys


def main():
    """Entry point that delegates to the bash script."""
    script = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "bin", "slack-cli")

    # Fallback: check common install locations
    if not os.path.exists(script):
        for candidate in [
            os.path.join(sys.prefix, "bin", "slack-cli"),
            os.path.join(os.path.dirname(sys.executable), "slack-cli"),
        ]:
            if os.path.exists(candidate):
                script = candidate
                break

    if not os.path.exists(script):
        print("Error: slack-cli bash script not found.", file=sys.stderr)
        print("Ensure the package is installed correctly.", file=sys.stderr)
        sys.exit(1)

    result = subprocess.run([script] + sys.argv[1:])
    sys.exit(result.returncode)
