"""Aetherence Core Module"""
__version__ = "0.1.0"
