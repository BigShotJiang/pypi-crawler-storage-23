try:
    from .cli import main
except:
    from cli import main

main()
