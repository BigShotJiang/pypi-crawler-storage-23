https://github.com/marketplace/actions/code-sign-action
https://docs.sigstore.dev/about/api-stability/