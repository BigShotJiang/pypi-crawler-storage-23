"""Benchmark run scripts for mini-SWE-agent (e.g., SWE-bench)."""
