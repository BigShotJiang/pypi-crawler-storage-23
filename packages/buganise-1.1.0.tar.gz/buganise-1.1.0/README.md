# Buganise

This package installs [buganize](https://pypi.org/project/buganize/). See [rly0nheart/buganize](https://github.com/rly0nheart/buganize) for details.
