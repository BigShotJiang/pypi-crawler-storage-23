#!/usr/bin/env python3

import argparse
import json
import math
import platform
import sys
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import yaml

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tsadmetrics.evaluation.Runner import Runner
from tsadmetrics.metrics.Registry import Registry


SCHEMA_VERSION = 1
SPEED_SCHEMA_VERSION = 2


def resolve_path(path_str):
    path = Path(path_str)
    if path.is_absolute():
        return path
    return (REPO_ROOT / path).resolve()


def load_config(config_path):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def metric_id(name, params):
    return f"{name}::{json.dumps(params, sort_keys=True)}"


def encode_value(value):
    if value is None:
        return {"type": "none"}
    if isinstance(value, (bool, np.bool_)):
        return {"type": "bool", "value": bool(value)}
    if isinstance(value, (int, float, np.integer, np.floating)):
        v = float(value)
        if math.isnan(v):
            return {"type": "nan"}
        if math.isinf(v):
            return {"type": "inf", "sign": 1 if v > 0 else -1}
        return {"type": "number", "value": v}
    if isinstance(value, str):
        return {"type": "str", "value": value}
    return {"type": "repr", "value": repr(value)}


def compare_encoded(a, b, rtol, atol):
    if a.get("type") != b.get("type"):
        return False
    t = a.get("type")
    if t in {"none", "nan"}:
        return True
    if t == "inf":
        return a.get("sign") == b.get("sign")
    if t == "number":
        return bool(np.isclose(float(a["value"]), float(b["value"]), rtol=rtol, atol=atol))
    return a.get("value") == b.get("value")


def add_segments(y_true, starts_and_lengths):
    y = y_true.copy()
    n = len(y)
    for start, length in starts_and_lengths:
        s = max(0, min(n - 1, start))
        e = max(s, min(n, s + length))
        y[s:e] = 1
    return y


def build_continuous_scores(y_true, y_pred_binary, seed):
    rng = np.random.default_rng(seed)
    n = len(y_true)
    base = rng.normal(loc=0.12, scale=0.07, size=n)
    base += y_true * 0.62
    base += y_pred_binary * 0.18
    return np.clip(base, 0.0, 1.0)


def generate_random_case(size, seed, anomaly_fraction, fp_probability):
    rng = np.random.default_rng(seed)
    y_true = np.zeros(size, dtype=int)
    target = max(1, int(round(size * anomaly_fraction)))
    covered = 0
    attempts = 0
    while covered < target and attempts < size * 20:
        seg_len = int(rng.integers(4, max(6, size // 8)))
        seg_len = min(seg_len, size)
        start = int(rng.integers(0, max(1, size - seg_len + 1)))
        end = start + seg_len
        if np.any(y_true[start:end] == 1):
            attempts += 1
            continue
        y_true[start:end] = 1
        covered += seg_len
        attempts += 1

    y_pred_binary = np.zeros(size, dtype=int)
    idx = np.where(y_true == 1)[0]
    if len(idx) > 0:
        keep = rng.random(len(idx)) < 0.75
        y_pred_binary[idx[keep]] = 1
    fp_mask = rng.random(size) < fp_probability
    y_pred_binary[fp_mask] = 1

    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed=seed + 1000)
    return y_true, y_pred_binary, y_pred_cont


def generate_cases(cfg):
    suite = cfg["suite"]
    seed = int(suite.get("random_seed", 12345))
    random_sizes = [int(x) for x in suite.get("random_case_sizes", [96, 384])]
    random_seeds = [int(x) for x in suite.get("random_case_seeds", [11, 29])]
    anomaly_fraction = float(suite.get("random_anomaly_fraction", 0.12))
    fp_probability = float(suite.get("random_fp_probability", 0.02))

    cases = {}

    y_true = np.zeros(64, dtype=int)
    y_pred_binary = np.zeros(64, dtype=int)
    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed + 1)
    cases["all_zero_64"] = (y_true, y_pred_binary, y_pred_cont)

    y_true = add_segments(np.zeros(128, dtype=int), [(10, 12), (70, 18)])
    y_pred_binary = y_true.copy()
    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed + 2)
    cases["perfect_segments_128"] = (y_true, y_pred_binary, y_pred_cont)

    y_true = add_segments(np.zeros(128, dtype=int), [(20, 20), (85, 14)])
    y_pred_binary = np.zeros(128, dtype=int)
    y_pred_binary[28:33] = 1
    y_pred_binary[90:92] = 1
    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed + 3)
    cases["partial_detection_128"] = (y_true, y_pred_binary, y_pred_cont)

    y_true = add_segments(np.zeros(128, dtype=int), [(32, 10), (94, 8)])
    y_pred_binary = np.zeros(128, dtype=int)
    y_pred_binary[5:18] = 1
    y_pred_binary[37:41] = 1
    y_pred_binary[65:78] = 1
    y_pred_binary[100:104] = 1
    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed + 4)
    cases["fp_heavy_128"] = (y_true, y_pred_binary, y_pred_cont)

    y_true = add_segments(np.zeros(256, dtype=int), [(40, 80)])
    y_pred_binary = np.zeros(256, dtype=int)
    y_pred_binary[40:55] = 1
    y_pred_binary[170:180] = 1
    y_pred_cont = build_continuous_scores(y_true, y_pred_binary, seed + 5)
    cases["long_segment_256"] = (y_true, y_pred_binary, y_pred_cont)

    for size in random_sizes:
        for rs in random_seeds:
            name = f"random_{size}_seed_{rs}"
            cases[name] = generate_random_case(size, seed + rs + size, anomaly_fraction, fp_probability)

    serialized = {}
    for name, (yt, yb, yc) in cases.items():
        serialized[name] = {
            "y_true": yt.astype(int).tolist(),
            "y_pred_binary": yb.astype(int).tolist(),
            "y_pred_continuous": yc.astype(float).tolist(),
        }
    return serialized


def load_cases_arrays(cases_dict):
    out = {}
    for name, payload in cases_dict.items():
        out[name] = (
            np.asarray(payload["y_true"], dtype=int),
            np.asarray(payload["y_pred_binary"], dtype=int),
            np.asarray(payload["y_pred_continuous"], dtype=float),
        )
    return out


def load_metrics(metrics_config_path):
    metrics_info = Registry.load_metrics_info_from_file(str(metrics_config_path))
    metrics = []
    for name, params in metrics_info:
        params = params or {}
        metric = Registry.get_metric(name, **params)
        metrics.append(
            {
                "id": metric_id(name, params),
                "name": name,
                "params": params,
                "class_name": metric.__class__.__name__,
                "binary_prediction": bool(metric.binary_prediction),
            }
        )
    return metrics


def metric_matches(metric, metric_name):
    if metric.get("name") == metric_name:
        return True
    if metric.get("class_name") == metric_name:
        return True
    if metric.get("id") == metric_name:
        return True
    try:
        params = metric.get("params", {}) or {}
        class_name = Registry.get_metric(metric["name"], **params).__class__.__name__
        if class_name == metric_name:
            return True
    except Exception:
        return False
    return False


def filter_metrics(metrics, metric_name):
    if metric_name is None:
        return metrics
    selected = [m for m in metrics if metric_matches(m, metric_name)]
    if not selected:
        raise ValueError(f"Metric not found in baseline/config: {metric_name}")
    return selected


def evaluate_metric_on_case(metric_name, params, binary_prediction, case_arrays):
    y_true, y_pred_binary, y_pred_cont = case_arrays
    y_pred = y_pred_binary if binary_prediction else y_pred_cont
    metric = Registry.get_metric(metric_name, **params)
    try:
        value = metric.compute(y_true, y_pred)
        return {"status": "ok", "value": encode_value(value)}
    except Exception as exc:
        return {
            "status": "exception",
            "exception_type": exc.__class__.__name__,
            "message": str(exc),
        }


def evaluate_all_metrics(metrics, cases_arrays):
    results = {}
    for m in metrics:
        case_results = {}
        for case_name, arrays in cases_arrays.items():
            case_results[case_name] = evaluate_metric_on_case(
                m["name"], m["params"], m["binary_prediction"], arrays
            )
        results[m["id"]] = case_results
    return results


def run_contract_checks(metrics):
    checks = {}
    for m in metrics:
        metric = Registry.get_metric(m["name"], **m["params"])
        metric_checks = {}

        scenarios = {
            "shape_mismatch": (
                np.array([0, 1, 0, 1], dtype=int),
                np.array([0, 1, 0], dtype=int),
            ),
            "non_binary_y_true": (
                np.array([0, 2, 1, 0], dtype=int),
                np.array([0, 1, 0, 1], dtype=float if not m["binary_prediction"] else int),
            ),
            "multidim_inputs": (
                np.array([[0, 1], [0, 1]], dtype=int),
                np.array([[0, 1], [0, 1]], dtype=int),
            ),
            "non_binary_y_pred": (
                np.array([0, 1, 0, 1], dtype=int),
                np.array([0.2, 0.8, 0.1, 0.9], dtype=float),
            ),
        }

        for key, (yt, yp) in scenarios.items():
            try:
                value = metric.compute(yt, yp)
                metric_checks[key] = {"status": "ok", "value": encode_value(value)}
            except Exception as exc:
                metric_checks[key] = {
                    "status": "exception",
                    "exception_type": exc.__class__.__name__,
                    "message": str(exc),
                }

        checks[m["id"]] = metric_checks
    return checks


def serialize_runner_df(df):
    data = []
    for row in df.values.tolist():
        data.append([encode_value(x) for x in row])
    return {
        "status": "ok",
        "index": [str(x) for x in df.index.tolist()],
        "columns": [str(x) for x in df.columns.tolist()],
        "data": data,
    }


def run_runner_baseline(metrics, cases_arrays, runner_dataset_count):
    eligible = []
    for name, arrays in cases_arrays.items():
        y_true = arrays[0]
        if int(np.sum(y_true)) > 0:
            eligible.append((name, arrays))
    eligible = eligible[: max(1, int(runner_dataset_count))]

    dataset_evaluations = []
    for name, (y_true, y_pred_bin, y_pred_cont) in eligible:
        dataset_evaluations.append(
            (name, y_true.tolist(), (y_pred_bin.tolist(), y_pred_cont.tolist()))
        )

    metric_tuples = [(m["name"], m["params"]) for m in metrics]
    runner = Runner(dataset_evaluations, metric_tuples)
    try:
        df = runner.run(generate_report=False)
        return serialize_runner_df(df)
    except Exception as exc:
        return {
            "status": "exception",
            "exception_type": exc.__class__.__name__,
            "message": str(exc),
        }


def build_baseline(config):
    suite = config["suite"]
    metrics_config_path = resolve_path(suite["metrics_config_path"])

    metrics = load_metrics(metrics_config_path)
    cases = generate_cases(config)
    cases_arrays = load_cases_arrays(cases)

    metric_results = evaluate_all_metrics(metrics, cases_arrays)
    contract_results = run_contract_checks(metrics)
    runner_baseline = run_runner_baseline(
        metrics,
        cases_arrays,
        runner_dataset_count=int(suite.get("runner_dataset_count", 4)),
    )

    return {
        "schema_version": SCHEMA_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "numpy": np.__version__,
        },
        "config_snapshot": config,
        "metrics": metrics,
        "cases": cases,
        "metric_results": metric_results,
        "contract_results": contract_results,
        "runner_baseline": runner_baseline,
    }


def get_speed_config(config):
    speed_cfg = config.get("speed", {})
    return {
        "warmup_runs": max(0, int(speed_cfg.get("warmup_runs", 2))),
        "repeat_runs": max(1, int(speed_cfg.get("repeat_runs", 7))),
        "trial_runs": max(1, int(speed_cfg.get("trial_runs", 5))),
        "min_sample_time_ms": max(0.1, float(speed_cfg.get("min_sample_time_ms", 2.5))),
        "max_inner_loops": max(1, int(speed_cfg.get("max_inner_loops", 50000))),
        "confidence_z": max(0.0, float(speed_cfg.get("confidence_z", 2.0))),
        "min_speedup_ratio": float(speed_cfg.get("min_speedup_ratio", 1.03)),
        "require_faster": bool(speed_cfg.get("require_faster", True)),
    }


def summarize_numeric(values):
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return {
            "count": 0,
            "mean": 0.0,
            "median": 0.0,
            "std": 0.0,
            "se": 0.0,
            "min": 0.0,
            "max": 0.0,
        }

    std = float(np.std(arr, ddof=1)) if arr.size > 1 else 0.0
    se = float(std / math.sqrt(arr.size)) if arr.size > 0 else 0.0
    return {
        "count": int(arr.size),
        "mean": float(np.mean(arr)),
        "median": float(np.median(arr)),
        "std": std,
        "se": se,
        "min": float(np.min(arr)),
        "max": float(np.max(arr)),
    }


def run_metric_loops(metric, y_true, y_pred, loops):
    value = None
    for _ in range(loops):
        value = metric.compute(y_true, y_pred)
    return value


def calibrate_inner_loops(metric, y_true, y_pred, min_sample_time_ns, max_inner_loops):
    calibration_ns = []
    for _ in range(3):
        start = time.perf_counter_ns()
        metric.compute(y_true, y_pred)
        calibration_ns.append(max(1, time.perf_counter_ns() - start))

    single_call_ns = max(1, int(np.median(np.asarray(calibration_ns, dtype=float))))
    loops = int(math.ceil(float(min_sample_time_ns) / float(single_call_ns)))
    loops = max(1, min(int(max_inner_loops), loops))
    return loops


def benchmark_metric_on_case(
    metric_name,
    params,
    binary_prediction,
    case_arrays,
    warmup_runs,
    repeat_runs,
    trial_runs,
    min_sample_time_ms,
    max_inner_loops,
):
    y_true, y_pred_binary, y_pred_cont = case_arrays
    y_pred = y_pred_binary if binary_prediction else y_pred_cont
    metric = Registry.get_metric(metric_name, **params)
    try:
        min_sample_time_ns = int(max(1.0, float(min_sample_time_ms) * 1_000_000.0))
        inner_loops = calibrate_inner_loops(
            metric,
            y_true,
            y_pred,
            min_sample_time_ns=min_sample_time_ns,
            max_inner_loops=max_inner_loops,
        )

        for _ in range(warmup_runs):
            run_metric_loops(metric, y_true, y_pred, inner_loops)

        all_samples_ns = []
        trial_centers_ns = []
        value = None
        for _ in range(trial_runs):
            trial_samples_ns = []
            for _ in range(repeat_runs):
                start = time.perf_counter_ns()
                value = run_metric_loops(metric, y_true, y_pred, inner_loops)
                elapsed = time.perf_counter_ns() - start
                per_call_ns = float(elapsed) / float(inner_loops)
                trial_samples_ns.append(per_call_ns)
                all_samples_ns.append(per_call_ns)
            trial_centers_ns.append(float(np.median(np.asarray(trial_samples_ns, dtype=float))))

        sample_stats = summarize_numeric(all_samples_ns)
        trial_stats = summarize_numeric(trial_centers_ns)

        return {
            "status": "ok",
            "value": encode_value(value),
            "inner_loops": int(inner_loops),
            "sample_count": int(sample_stats["count"]),
            "samples_mean_ns": float(sample_stats["mean"]),
            "samples_median_ns": float(sample_stats["median"]),
            "samples_std_ns": float(sample_stats["std"]),
            "samples_min_ns": float(sample_stats["min"]),
            "samples_max_ns": float(sample_stats["max"]),
            "trial_centers_ns": [float(x) for x in trial_centers_ns],
            "trial_count": int(trial_stats["count"]),
            "trial_mean_ns": float(trial_stats["mean"]),
            "trial_median_ns": float(trial_stats["median"]),
            "trial_std_ns": float(trial_stats["std"]),
            "trial_se_ns": float(trial_stats["se"]),
        }
    except Exception as exc:
        return {
            "status": "exception",
            "exception_type": exc.__class__.__name__,
            "message": str(exc),
        }


def benchmark_metrics(metrics, cases_arrays, speed_cfg):
    warmup_runs = int(speed_cfg["warmup_runs"])
    repeat_runs = int(speed_cfg["repeat_runs"])
    trial_runs = int(speed_cfg["trial_runs"])
    min_sample_time_ms = float(speed_cfg["min_sample_time_ms"])
    max_inner_loops = int(speed_cfg["max_inner_loops"])
    results = {}
    for m in metrics:
        case_results = {}
        for case_name, arrays in cases_arrays.items():
            case_results[case_name] = benchmark_metric_on_case(
                m["name"],
                m["params"],
                m["binary_prediction"],
                arrays,
                warmup_runs=warmup_runs,
                repeat_runs=repeat_runs,
                trial_runs=trial_runs,
                min_sample_time_ms=min_sample_time_ms,
                max_inner_loops=max_inner_loops,
            )

        trial_totals_ns = [0.0] * trial_runs
        ok_case_count = 0
        for case in case_results.values():
            if case.get("status") == "ok":
                trial_centers_ns = case.get("trial_centers_ns", [])
                if len(trial_centers_ns) != trial_runs:
                    continue
                for idx in range(trial_runs):
                    trial_totals_ns[idx] += float(trial_centers_ns[idx])
                ok_case_count += 1

        total_stats = summarize_numeric(trial_totals_ns if ok_case_count > 0 else [])
        results[m["id"]] = {
            "case_results": case_results,
            "trial_totals_ns": [float(x) for x in trial_totals_ns],
            "total_mean_ns": float(total_stats["mean"]),
            "total_median_ns": float(total_stats["median"]),
            "total_std_ns": float(total_stats["std"]),
            "total_se_ns": float(total_stats["se"]),
            "ok_case_count": int(ok_case_count),
            "case_count": int(len(case_results)),
        }
    return results


def build_speed_baseline(config, metric_name=None):
    suite = config["suite"]
    metrics_config_path = resolve_path(suite["metrics_config_path"])

    metrics = load_metrics(metrics_config_path)
    metrics = filter_metrics(metrics, metric_name)

    cases = generate_cases(config)
    cases_arrays = load_cases_arrays(cases)
    speed_cfg = get_speed_config(config)
    timing_results = benchmark_metrics(metrics, cases_arrays, speed_cfg)

    return {
        "schema_version": SPEED_SCHEMA_VERSION,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "numpy": np.__version__,
        },
        "config_snapshot": config,
        "metric_filter": metric_name,
        "metrics": metrics,
        "cases": cases,
        "speed_config": speed_cfg,
        "timing_results": timing_results,
    }


def compare_outcomes(expected, actual, rtol, atol, strict_message):
    if expected.get("status") != actual.get("status"):
        return False, f"status mismatch: expected={expected.get('status')} actual={actual.get('status')}"

    if expected.get("status") == "ok":
        ok = compare_encoded(expected.get("value"), actual.get("value"), rtol, atol)
        if not ok:
            return (
                False,
                f"value mismatch: expected={expected.get('value')} actual={actual.get('value')}",
            )
        return True, ""

    if expected.get("exception_type") != actual.get("exception_type"):
        return (
            False,
            f"exception type mismatch: expected={expected.get('exception_type')} actual={actual.get('exception_type')}",
        )

    if strict_message and expected.get("message") != actual.get("message"):
        return False, "exception message mismatch"

    return True, ""


def compare_runner(expected, actual, rtol, atol, strict_message):
    if expected.get("status") != actual.get("status"):
        return [f"runner status mismatch: expected={expected.get('status')} actual={actual.get('status')}"]

    if expected.get("status") == "exception":
        ok, msg = compare_outcomes(expected, actual, rtol, atol, strict_message)
        return [] if ok else [f"runner exception mismatch: {msg}"]

    errors = []
    if expected.get("index") != actual.get("index"):
        errors.append("runner index mismatch")
    if expected.get("columns") != actual.get("columns"):
        errors.append("runner columns mismatch")

    exp_data = expected.get("data", [])
    act_data = actual.get("data", [])
    if len(exp_data) != len(act_data):
        errors.append("runner row count mismatch")
        return errors

    for i in range(len(exp_data)):
        if len(exp_data[i]) != len(act_data[i]):
            errors.append(f"runner column count mismatch at row {i}")
            continue
        for j in range(len(exp_data[i])):
            if not compare_encoded(exp_data[i][j], act_data[i][j], rtol, atol):
                errors.append(
                    f"runner value mismatch at row={i}, col={j}: expected={exp_data[i][j]} actual={act_data[i][j]}"
                )
    return errors


def verify_baseline(config, baseline, metric_name=None, include_runner=True):
    compare_cfg = config["comparison"]
    rtol = float(compare_cfg.get("rtol", 1e-9))
    atol = float(compare_cfg.get("atol", 1e-10))
    strict_message = bool(compare_cfg.get("strict_exception_message", False))

    metrics = filter_metrics(baseline["metrics"], metric_name)
    cases_arrays = load_cases_arrays(baseline["cases"])

    actual_metric_results = evaluate_all_metrics(metrics, cases_arrays)
    actual_contract_results = run_contract_checks(metrics)
    actual_runner = None
    if include_runner:
        all_metrics = baseline["metrics"]
        actual_runner = run_runner_baseline(
            all_metrics,
            cases_arrays,
            runner_dataset_count=int(config["suite"].get("runner_dataset_count", 4)),
        )

    mismatches = []

    for m in metrics:
        mid = m["id"]
        expected_cases = baseline["metric_results"][mid]
        actual_cases = actual_metric_results[mid]
        for case_name in expected_cases.keys():
            ok, msg = compare_outcomes(
                expected_cases[case_name],
                actual_cases[case_name],
                rtol,
                atol,
                strict_message,
            )
            if not ok:
                mismatches.append(f"[metric:{mid}] case:{case_name} -> {msg}")

    for m in metrics:
        mid = m["id"]
        expected_checks = baseline["contract_results"][mid]
        actual_checks = actual_contract_results[mid]
        for check_name in expected_checks.keys():
            ok, msg = compare_outcomes(
                expected_checks[check_name],
                actual_checks[check_name],
                rtol,
                atol,
                strict_message,
            )
            if not ok:
                mismatches.append(f"[contract:{mid}] check:{check_name} -> {msg}")

    if include_runner:
        runner_errors = compare_runner(
            baseline["runner_baseline"],
            actual_runner,
            rtol,
            atol,
            strict_message,
        )
        mismatches.extend([f"[runner] {e}" for e in runner_errors])

    return mismatches


def compare_speed_metric(
    expected_metric,
    actual_metric,
    min_speedup_ratio,
    require_faster,
    confidence_z,
):
    errors = []
    case_speedups = {}

    expected_cases = expected_metric["case_results"]
    actual_cases = actual_metric["case_results"]

    for case_name, expected_case in expected_cases.items():
        if case_name not in actual_cases:
            errors.append(f"missing case in actual results: {case_name}")
            continue
        actual_case = actual_cases[case_name]

        if expected_case.get("status") != actual_case.get("status"):
            errors.append(
                f"case {case_name} status mismatch: expected={expected_case.get('status')} actual={actual_case.get('status')}"
            )
            continue

        if expected_case.get("status") == "exception":
            if expected_case.get("exception_type") != actual_case.get("exception_type"):
                errors.append(
                    "case "
                    f"{case_name} exception type mismatch: expected={expected_case.get('exception_type')} "
                    f"actual={actual_case.get('exception_type')}"
                )
            continue

        expected_ns = float(expected_case.get("trial_mean_ns", expected_case.get("samples_mean_ns", 0.0)))
        actual_ns = float(actual_case.get("trial_mean_ns", actual_case.get("samples_mean_ns", 0.0)))
        if actual_ns <= 0:
            errors.append(f"case {case_name} invalid actual time={actual_ns}")
            continue

        case_speedups[case_name] = float(expected_ns / actual_ns)

    for case_name in actual_cases.keys():
        if case_name not in expected_cases:
            errors.append(f"unexpected case in actual results: {case_name}")

    expected_trials = expected_metric.get("trial_totals_ns", [])
    actual_trials = actual_metric.get("trial_totals_ns", [])
    if not expected_trials:
        expected_trials = [float(expected_metric.get("total_median_ns", 0.0))]
    if not actual_trials:
        actual_trials = [float(actual_metric.get("total_median_ns", 0.0))]

    expected_stats = summarize_numeric(expected_trials)
    actual_stats = summarize_numeric(actual_trials)
    expected_mean = float(expected_stats["mean"])
    actual_mean = float(actual_stats["mean"])

    if actual_mean <= 0:
        errors.append(f"invalid actual mean total time: {actual_mean}")
        raw_speedup_ratio = float("inf")
    else:
        raw_speedup_ratio = float(expected_mean / actual_mean)

    expected_low = max(1.0, expected_mean - float(confidence_z) * float(expected_stats["se"]))
    actual_high = max(1.0, actual_mean + float(confidence_z) * float(actual_stats["se"]))
    conservative_speedup_ratio = float(expected_low / actual_high)

    status = "faster"
    if conservative_speedup_ratio < min_speedup_ratio:
        status = "not_faster"
        if require_faster:
            errors.append(
                "speedup below target: "
                f"raw={raw_speedup_ratio:.4f}, conservative={conservative_speedup_ratio:.4f}, "
                f"required>={min_speedup_ratio:.4f}"
            )

    if errors:
        status = "error"

    return {
        "status": status,
        "expected_total_mean_ns": expected_mean,
        "expected_total_std_ns": float(expected_stats["std"]),
        "expected_total_se_ns": float(expected_stats["se"]),
        "actual_total_mean_ns": actual_mean,
        "actual_total_std_ns": float(actual_stats["std"]),
        "actual_total_se_ns": float(actual_stats["se"]),
        "raw_speedup_ratio": raw_speedup_ratio,
        "conservative_speedup_ratio": conservative_speedup_ratio,
        "confidence_z": float(confidence_z),
        "case_speedups": case_speedups,
        "errors": errors,
    }


def verify_speed_baseline(config, speed_baseline, metric_name=None, require_faster=None):
    speed_cfg = get_speed_config(config)
    min_speedup_ratio = float(speed_cfg["min_speedup_ratio"])
    confidence_z = float(speed_cfg["confidence_z"])
    if require_faster is None:
        require_faster = bool(speed_cfg["require_faster"])

    metrics = filter_metrics(speed_baseline["metrics"], metric_name)
    cases_arrays = load_cases_arrays(speed_baseline["cases"])
    actual_timings = benchmark_metrics(metrics, cases_arrays, speed_cfg)

    results = []
    failures = []

    for m in metrics:
        mid = m["id"]
        expected_metric = speed_baseline["timing_results"][mid]
        actual_metric = actual_timings[mid]

        comparison = compare_speed_metric(
            expected_metric,
            actual_metric,
            min_speedup_ratio=min_speedup_ratio,
            require_faster=require_faster,
            confidence_z=confidence_z,
        )

        result = {
            "metric_id": mid,
            "metric_name": m["name"],
            "params": m["params"],
            "comparison": comparison,
        }
        results.append(result)

        for err in comparison["errors"]:
            failures.append(f"[speed:{mid}] {err}")

    return results, failures, min_speedup_ratio, require_faster, confidence_z


def write_verify_report(report_path, mismatches, metric_name=None, include_runner=True):
    lines = []
    lines.append("# Metric Regression Guard Report")
    lines.append("")
    lines.append(f"- Generated at: {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"- Metric filter: {metric_name if metric_name else 'all'}")
    lines.append(f"- Runner check: {'enabled' if include_runner else 'disabled'}")
    lines.append(f"- Mismatch count: {len(mismatches)}")
    lines.append("")
    if not mismatches:
        lines.append("All checks passed.")
    else:
        lines.append("## Mismatches")
        lines.append("")
        for item in mismatches:
            lines.append(f"- {item}")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")


def write_speed_report(
    report_path,
    speed_results,
    failures,
    metric_name,
    min_speedup_ratio,
    require_faster,
    confidence_z,
):
    lines = []
    lines.append("# Metric Speed Guard Report")
    lines.append("")
    lines.append(f"- Generated at: {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"- Metric filter: {metric_name if metric_name else 'all'}")
    lines.append(f"- Minimum speedup ratio target: {min_speedup_ratio:.4f}")
    lines.append(f"- Require faster: {'yes' if require_faster else 'no'}")
    lines.append(f"- Confidence z: {confidence_z:.3f}")
    lines.append(f"- Failure count: {len(failures)}")
    lines.append("")
    lines.append(
        "| Metric | Baseline mean (ms) | Current mean (ms) | Raw speedup | Conservative speedup | Status |"
    )
    lines.append("| --- | ---: | ---: | ---: | ---: | --- |")

    for item in speed_results:
        comparison = item["comparison"]
        base_ms = comparison["expected_total_mean_ns"] / 1_000_000.0
        cur_ms = comparison["actual_total_mean_ns"] / 1_000_000.0
        raw_speedup = comparison["raw_speedup_ratio"]
        conservative_speedup = comparison["conservative_speedup_ratio"]
        lines.append(
            f"| {item['metric_id']} | {base_ms:.6f} | {cur_ms:.6f} | {raw_speedup:.4f}x | {conservative_speedup:.4f}x | {comparison['status']} |"
        )

    lines.append("")
    if failures:
        lines.append("## Failures")
        lines.append("")
        for failure in failures:
            lines.append(f"- {failure}")
    else:
        lines.append("All speed checks passed.")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")


def write_check_report(report_path, metric_name, behavior_mismatches, speed_results, speed_failures):
    lines = []
    lines.append("# Metric Optimization Check")
    lines.append("")
    lines.append(f"- Generated at: {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"- Metric: {metric_name}")
    lines.append(f"- Behavior mismatches: {len(behavior_mismatches)}")
    lines.append(f"- Speed failures: {len(speed_failures)}")
    lines.append("")

    behavior_ok = len(behavior_mismatches) == 0
    speed_ok = len(speed_failures) == 0
    if behavior_ok and speed_ok:
        lines.append("Verdict: SI, la metrica mantiene comportamiento y es mas rapida.")
    elif behavior_ok:
        lines.append("Verdict: La metrica mantiene comportamiento, pero no se confirma mejora de tiempo.")
    else:
        lines.append("Verdict: La metrica no mantiene el comportamiento baseline.")

    lines.append("")
    if speed_results:
        lines.append(
            "| Metric | Baseline mean (ms) | Current mean (ms) | Raw speedup | Conservative speedup | Status |"
        )
        lines.append("| --- | ---: | ---: | ---: | ---: | --- |")
        for item in speed_results:
            comparison = item["comparison"]
            base_ms = comparison["expected_total_mean_ns"] / 1_000_000.0
            cur_ms = comparison["actual_total_mean_ns"] / 1_000_000.0
            lines.append(
                f"| {item['metric_id']} | {base_ms:.6f} | {cur_ms:.6f} | {comparison['raw_speedup_ratio']:.4f}x | {comparison['conservative_speedup_ratio']:.4f}x | {comparison['status']} |"
            )
        lines.append("")

    if behavior_mismatches:
        lines.append("## Behavior mismatches")
        lines.append("")
        for mismatch in behavior_mismatches:
            lines.append(f"- {mismatch}")
        lines.append("")

    if speed_failures:
        lines.append("## Speed failures")
        lines.append("")
        for failure in speed_failures:
            lines.append(f"- {failure}")
        lines.append("")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(lines), encoding="utf-8")


def cmd_generate(config):
    baseline = build_baseline(config)
    baseline_path = resolve_path(config["paths"]["baseline_file"])
    baseline_path.parent.mkdir(parents=True, exist_ok=True)
    baseline_path.write_text(
        json.dumps(baseline, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"Baseline written to: {baseline_path}")


def cmd_verify(config, metric_name=None, include_runner=True):
    if metric_name is not None and include_runner:
        raise ValueError("--include-runner cannot be used together with --metric")

    baseline_path = resolve_path(config["paths"]["baseline_file"])
    if not baseline_path.exists():
        raise FileNotFoundError(f"Baseline file not found: {baseline_path}")
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))

    if int(baseline.get("schema_version", -1)) != SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported baseline schema version: {baseline.get('schema_version')}"
        )

    mismatches = verify_baseline(
        config,
        baseline,
        metric_name=metric_name,
        include_runner=include_runner,
    )
    report_path = resolve_path(config["paths"]["verify_report_file"])
    write_verify_report(
        report_path,
        mismatches,
        metric_name=metric_name,
        include_runner=include_runner,
    )
    print(f"Verification report: {report_path}")

    if mismatches:
        print(f"Verification failed with {len(mismatches)} mismatches.")
        raise SystemExit(1)
    print("Verification passed with no mismatches.")


def cmd_speed_generate(config, metric_name=None):
    speed_baseline = build_speed_baseline(config, metric_name=metric_name)
    speed_baseline_path = resolve_path(config["paths"]["speed_baseline_file"])
    speed_baseline_path.parent.mkdir(parents=True, exist_ok=True)
    speed_baseline_path.write_text(
        json.dumps(speed_baseline, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    print(f"Speed baseline written to: {speed_baseline_path}")


def cmd_speed_verify(config, metric_name=None, require_faster=None):
    speed_baseline_path = resolve_path(config["paths"]["speed_baseline_file"])
    if not speed_baseline_path.exists():
        raise FileNotFoundError(f"Speed baseline file not found: {speed_baseline_path}")
    speed_baseline = json.loads(speed_baseline_path.read_text(encoding="utf-8"))
    if int(speed_baseline.get("schema_version", -1)) != SPEED_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported speed baseline schema version: {speed_baseline.get('schema_version')}"
        )

    speed_results, failures, min_speedup_ratio, require_faster, confidence_z = verify_speed_baseline(
        config,
        speed_baseline,
        metric_name=metric_name,
        require_faster=require_faster,
    )

    report_path = resolve_path(config["paths"]["speed_report_file"])
    write_speed_report(
        report_path,
        speed_results=speed_results,
        failures=failures,
        metric_name=metric_name,
        min_speedup_ratio=min_speedup_ratio,
        require_faster=require_faster,
        confidence_z=confidence_z,
    )
    print(f"Speed verification report: {report_path}")

    if failures:
        print(f"Speed verification failed with {len(failures)} issues.")
        raise SystemExit(1)
    print("Speed verification passed.")


def cmd_check_metric(config, metric_name):
    baseline_path = resolve_path(config["paths"]["baseline_file"])
    if not baseline_path.exists():
        raise FileNotFoundError(f"Baseline file not found: {baseline_path}")
    baseline = json.loads(baseline_path.read_text(encoding="utf-8"))
    if int(baseline.get("schema_version", -1)) != SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported baseline schema version: {baseline.get('schema_version')}"
        )

    speed_baseline_path = resolve_path(config["paths"]["speed_baseline_file"])
    if not speed_baseline_path.exists():
        raise FileNotFoundError(f"Speed baseline file not found: {speed_baseline_path}")
    speed_baseline = json.loads(speed_baseline_path.read_text(encoding="utf-8"))
    if int(speed_baseline.get("schema_version", -1)) != SPEED_SCHEMA_VERSION:
        raise ValueError(
            f"Unsupported speed baseline schema version: {speed_baseline.get('schema_version')}"
        )

    behavior_mismatches = verify_baseline(
        config,
        baseline,
        metric_name=metric_name,
        include_runner=False,
    )
    speed_results, speed_failures, _, _, _ = verify_speed_baseline(
        config,
        speed_baseline,
        metric_name=metric_name,
        require_faster=True,
    )

    report_path = resolve_path(config["paths"]["check_report_file"])
    write_check_report(
        report_path,
        metric_name=metric_name,
        behavior_mismatches=behavior_mismatches,
        speed_results=speed_results,
        speed_failures=speed_failures,
    )
    print(f"Optimization check report: {report_path}")

    if not behavior_mismatches and not speed_failures:
        print("SI: la metrica mantiene comportamiento y es mas rapida.")
        return

    if behavior_mismatches:
        print(f"Behavior mismatches: {len(behavior_mismatches)}")
    if speed_failures:
        print(f"Speed issues: {len(speed_failures)}")
    raise SystemExit(1)


def main():
    parser = argparse.ArgumentParser(description="Metric regression guard for optimization safety.")
    parser.add_argument(
        "command",
        choices=["generate", "verify", "speed-generate", "speed-verify", "check-metric"],
        help="Guard command",
    )
    parser.add_argument(
        "--config",
        default="experiments/metric_regression_guard/guard_config.yaml",
        help="Path to guard config yaml",
    )
    parser.add_argument(
        "--metric",
        default=None,
        help="Optional metric class name filter (for example: SegmentwiseFScore)",
    )
    parser.add_argument(
        "--include-runner",
        action="store_true",
        help="Include runner integration check (only valid without --metric)",
    )
    parser.add_argument(
        "--allow-not-faster",
        action="store_true",
        help="For speed-verify only: do not fail when speedup target is not met.",
    )
    args = parser.parse_args()

    config_path = resolve_path(args.config)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    config = load_config(config_path)

    if args.command == "generate":
        cmd_generate(config)
    elif args.command == "verify":
        include_runner = bool(args.include_runner) if args.metric else True
        cmd_verify(config, metric_name=args.metric, include_runner=include_runner)
    elif args.command == "speed-generate":
        cmd_speed_generate(config, metric_name=args.metric)
    elif args.command == "speed-verify":
        require_faster = None if not args.allow_not_faster else False
        cmd_speed_verify(config, metric_name=args.metric, require_faster=require_faster)
    else:
        if args.metric is None:
            raise ValueError("check-metric requires --metric")
        cmd_check_metric(config, metric_name=args.metric)


if __name__ == "__main__":
    main()
