#!/usr/bin/env python3

import argparse
import math
import signal
import sys
import time
import warnings
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tsadmetrics.metrics.Registry import Registry


class TimeoutErrorCompute(RuntimeError):
    pass


@contextmanager
def time_limit(seconds):
    if seconds is None or seconds <= 0:
        yield
        return
    if not hasattr(signal, "SIGALRM"):
        yield
        return

    def _handler(_signum, _frame):
        raise TimeoutErrorCompute(f"Metric execution exceeded {seconds} seconds")

    old_handler = signal.signal(signal.SIGALRM, _handler)
    signal.setitimer(signal.ITIMER_REAL, seconds)
    try:
        yield
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, old_handler)


def resolve_input_path(config_dir: Path, target: str) -> Path:
    p = Path(target)
    if p.is_absolute():
        if p.exists():
            return p
        raise FileNotFoundError(f"Input path does not exist: {p}")

    candidate_config = (config_dir / p).resolve()
    if candidate_config.exists():
        return candidate_config

    candidate_repo = (REPO_ROOT / p).resolve()
    if candidate_repo.exists():
        return candidate_repo

    raise FileNotFoundError(
        "Input path not found. "
        f"Tried: {candidate_config} and {candidate_repo}"
    )


def resolve_output_root(target: str) -> Path:
    p = Path(target)
    if p.is_absolute():
        return p
    return (REPO_ROOT / p).resolve()


def load_yaml(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_sizes(size_cfg):
    if isinstance(size_cfg, list):
        sizes = [int(x) for x in size_cfg if int(x) > 1]
        return sorted(set(sizes))

    mode = size_cfg.get("mode", "geometric")
    if mode == "explicit":
        sizes = [int(x) for x in size_cfg.get("values", []) if int(x) > 1]
        return sorted(set(sizes))

    if mode != "geometric":
        raise ValueError(f"Unsupported sizes mode: {mode}")

    start = int(size_cfg["start"])
    max_size = int(size_cfg["max"])
    factor = float(size_cfg.get("factor", 2))
    if start < 2 or max_size < start or factor <= 1:
        raise ValueError("Invalid geometric size config")

    sizes = []
    current = start
    while current <= max_size:
        sizes.append(int(current))
        next_value = int(math.ceil(current * factor))
        if next_value <= current:
            next_value = current + 1
        current = next_value
    return sizes


def load_metrics(metrics_cfg, config_dir: Path):
    source = metrics_cfg.get("source", {})
    source_type = source.get("type", "file")

    if source_type == "file":
        metric_path = resolve_input_path(config_dir, source["path"])
        metrics_info = Registry.load_metrics_info_from_file(str(metric_path))
    elif source_type == "inline":
        raw_items = source.get("items", [])
        metrics_info = []
        for entry in raw_items:
            if isinstance(entry, str):
                metrics_info.append((entry, {}))
            elif isinstance(entry, dict):
                for name, params in entry.items():
                    metrics_info.append((name, params or {}))
            else:
                raise ValueError(f"Unsupported inline metric entry: {entry}")
    elif source_type == "all":
        metrics_info = [(name, {}) for name in Registry.available_metrics()]
    else:
        raise ValueError(f"Unsupported metrics source type: {source_type}")

    include = set(metrics_cfg.get("include", []) or [])
    exclude = set(metrics_cfg.get("exclude", []) or [])

    if include:
        metrics_info = [x for x in metrics_info if x[0] in include]
    if exclude:
        metrics_info = [x for x in metrics_info if x[0] not in exclude]

    loaded = []
    for metric_name, params in metrics_info:
        params = params or {}
        metric = Registry.get_metric(metric_name, **params)
        loaded.append(
            {
                "name": metric_name,
                "params": params,
                "input_type": "binary" if metric.binary_prediction else "continuous",
                "instance": metric,
            }
        )
    return loaded


def extract_segments(y_true):
    segments = []
    i = 0
    n = len(y_true)
    while i < n:
        if y_true[i] == 1:
            start = i
            while i < n and y_true[i] == 1:
                i += 1
            segments.append((start, i - 1))
        else:
            i += 1
    return segments


def generate_y_true(
    n,
    rng,
    anomaly_fraction,
    min_segment_len,
    max_segment_len,
):
    y_true = np.zeros(n, dtype=int)
    target = max(1, int(round(n * anomaly_fraction)))
    min_len = max(1, min(min_segment_len, n))
    max_len = max(min_len, min(max_segment_len, n))

    covered = 0
    attempts = 0
    max_attempts = n * 20
    while covered < target and attempts < max_attempts:
        seg_len = int(rng.integers(min_len, max_len + 1))
        start = int(rng.integers(0, n - seg_len + 1))
        end = start + seg_len
        if np.any(y_true[start:end] == 1):
            attempts += 1
            continue
        y_true[start:end] = 1
        covered += seg_len
        attempts += 1

    if np.sum(y_true) == 0:
        y_true[int(rng.integers(0, n))] = 1

    return y_true


def generate_binary_predictions(y_true, rng, detection_probability, fp_probability):
    n = len(y_true)
    y_pred = np.zeros(n, dtype=int)

    for start, end in extract_segments(y_true):
        if rng.random() > detection_probability:
            continue
        seg_len = end - start + 1
        coverage = float(rng.uniform(0.2, 1.0))
        det_len = max(1, int(round(seg_len * coverage)))
        det_start = int(rng.integers(start, end - det_len + 2))
        y_pred[det_start : det_start + det_len] = 1

    fp_mask = rng.random(n) < fp_probability
    y_pred[fp_mask] = 1
    return y_pred


def generate_continuous_scores(y_true, rng, noise_std, anomaly_boost):
    n = len(y_true)
    base = rng.normal(loc=0.15, scale=noise_std, size=n)
    base = np.clip(base, 0.0, 1.0)
    anomaly_idx = y_true == 1
    if np.any(anomaly_idx):
        boost = anomaly_boost + rng.normal(loc=0.0, scale=noise_std / 2.0, size=int(np.sum(anomaly_idx)))
        base[anomaly_idx] = np.clip(base[anomaly_idx] + boost, 0.0, 1.0)
    return base.astype(float)


def build_datasets(sizes, data_cfg, seed):
    datasets = {}
    for n in sizes:
        rng = np.random.default_rng(seed + n)
        y_true = generate_y_true(
            n=n,
            rng=rng,
            anomaly_fraction=float(data_cfg.get("anomaly_fraction", 0.1)),
            min_segment_len=int(data_cfg.get("min_segment_len", 8)),
            max_segment_len=int(data_cfg.get("max_segment_len", 64)),
        )
        y_pred_binary = generate_binary_predictions(
            y_true=y_true,
            rng=rng,
            detection_probability=float(data_cfg.get("detection_probability", 0.75)),
            fp_probability=float(data_cfg.get("fp_probability", 0.01)),
        )
        y_pred_continuous = generate_continuous_scores(
            y_true=y_true,
            rng=rng,
            noise_std=float(data_cfg.get("continuous_noise_std", 0.12)),
            anomaly_boost=float(data_cfg.get("anomaly_score_boost", 0.65)),
        )
        datasets[n] = (y_true, y_pred_binary, y_pred_continuous)
    return datasets


def run_compute(metric, y_true, y_pred, timeout_seconds):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            start = time.perf_counter()
            with time_limit(timeout_seconds):
                metric.compute(y_true, y_pred)
            elapsed = time.perf_counter() - start
        return elapsed, "ok", ""
    except TimeoutErrorCompute as exc:
        return float(timeout_seconds), "timeout", str(exc)
    except Exception as exc:
        return np.nan, "error", str(exc)


def complexity_from_exponent(exponent):
    if exponent is None:
        return "insufficient_data"
    if exponent < 0.3:
        return "O(1)"
    if exponent < 0.8:
        return "O(log n)"
    if exponent < 1.3:
        return "O(n)"
    if exponent < 1.8:
        return "O(n log n)"
    if exponent < 2.4:
        return "O(n^2)"
    if exponent < 3.2:
        return "O(n^3)"
    return f"O(n^{exponent:.2f})"


def estimate_exponent(df_metric):
    points = (
        df_metric[df_metric["status"] == "ok"]
        .groupby("size", as_index=False)["elapsed_sec"]
        .median()
        .sort_values("size")
    )
    points = points[(points["size"] > 0) & (points["elapsed_sec"] > 0)]
    if len(points) < 3:
        return None, None

    x = np.log(points["size"].to_numpy(dtype=float))
    y = np.log(points["elapsed_sec"].to_numpy(dtype=float))
    slope, intercept = np.polyfit(x, y, deg=1)
    y_hat = slope * x + intercept
    ss_res = float(np.sum((y - y_hat) ** 2))
    ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    r2 = 1.0 if ss_tot == 0 else 1.0 - (ss_res / ss_tot)
    return float(slope), float(r2)


def build_summary(raw_df):
    summary_rows = []
    for metric_name, df_metric in raw_df.groupby("metric_name"):
        exponent, r2 = estimate_exponent(df_metric)
        summary_rows.append(
            {
                "metric_name": metric_name,
                "input_type": df_metric["input_type"].iloc[0],
                "params": df_metric["params"].iloc[0],
                "ok_runs": int((df_metric["status"] == "ok").sum()),
                "timeouts": int((df_metric["status"] == "timeout").sum()),
                "errors": int((df_metric["status"] == "error").sum()),
                "early_stopped": bool((df_metric["status"] == "skipped_early_stop").any()),
                "last_size_ok": (
                    int(df_metric[df_metric["status"] == "ok"]["size"].max())
                    if (df_metric["status"] == "ok").any()
                    else np.nan
                ),
                "complexity_exponent": exponent,
                "r2": r2,
                "complexity_class": complexity_from_exponent(exponent),
            }
        )
    return pd.DataFrame(summary_rows).sort_values(["input_type", "metric_name"]).reset_index(drop=True)


def write_markdown_report(report_path: Path, summary_df: pd.DataFrame, raw_df: pd.DataFrame):
    lines = []
    lines.append("# Complexity Benchmark Report")
    lines.append("")
    lines.append(f"- Generated at: {datetime.now().isoformat(timespec='seconds')}")
    lines.append(f"- Metrics evaluated: {summary_df['metric_name'].nunique()}")
    lines.append(f"- Timed runs: {int((raw_df['status'] == 'ok').sum())}")
    lines.append(f"- Timeouts: {int((raw_df['status'] == 'timeout').sum())}")
    lines.append(f"- Errors: {int((raw_df['status'] == 'error').sum())}")
    lines.append("")
    lines.append("## Complexity Estimates")
    lines.append("")
    lines.append("| metric | input | class | exponent | r2 | early_stop |")
    lines.append("|---|---|---|---:|---:|---|")
    for _, row in summary_df.iterrows():
        exp_text = "" if pd.isna(row["complexity_exponent"]) else f"{row['complexity_exponent']:.3f}"
        r2_text = "" if pd.isna(row["r2"]) else f"{row['r2']:.3f}"
        lines.append(
            f"| {row['metric_name']} | {row['input_type']} | {row['complexity_class']} | "
            f"{exp_text} | {r2_text} | {row['early_stopped']} |"
        )
    report_path.write_text("\n".join(lines), encoding="utf-8")


def generate_plots(raw_df: pd.DataFrame, output_dir: Path, log_scale: bool):
    try:
        import matplotlib.pyplot as plt
    except Exception:
        return False

    grouped = raw_df[raw_df["status"] == "ok"].groupby(["metric_name", "input_type", "size"], as_index=False)["elapsed_sec"].median()

    for input_type, df_type in grouped.groupby("input_type"):
        fig, ax = plt.subplots(figsize=(13, 8))
        for metric_name, df_metric in df_type.groupby("metric_name"):
            df_metric = df_metric.sort_values("size")
            if len(df_metric) < 2:
                continue
            ax.plot(
                df_metric["size"].to_numpy(dtype=float),
                df_metric["elapsed_sec"].to_numpy(dtype=float),
                marker="o",
                linewidth=1.3,
                markersize=3.5,
                label=metric_name,
            )

        ax.set_title(f"Size vs Execution Time ({input_type} metrics)")
        ax.set_xlabel("Input size (n)")
        ax.set_ylabel("Median execution time (seconds)")
        ax.grid(True, which="both", alpha=0.25)
        if log_scale:
            ax.set_xscale("log", base=2)
            ax.set_yscale("log")
        ax.legend(fontsize=8, ncol=3)
        fig.tight_layout()
        fig.savefig(output_dir / f"plot_{input_type}_metrics.png", dpi=160)
        plt.close(fig)
    return True


def run_benchmark(config_path: Path, tag=None):
    config = load_yaml(config_path)
    config_dir = config_path.parent.resolve()

    exp_cfg = config.get("experiment", {})
    metrics_cfg = config.get("metrics", {})
    data_cfg = config.get("data", {})
    plots_cfg = config.get("plots", {})

    sizes = build_sizes(exp_cfg.get("sizes", []))
    if not sizes:
        raise ValueError("No input sizes configured")
    metrics = load_metrics(metrics_cfg, config_dir)
    if not metrics:
        raise ValueError("No metrics selected")

    output_root = resolve_output_root(exp_cfg.get("output_root", "experiments/complexity_benchmark/runs"))
    output_root.mkdir(parents=True, exist_ok=True)

    exp_name = str(exp_cfg.get("name", "complexity"))
    tag_text = tag or "run"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = output_root / f"{exp_name}_{tag_text}_{timestamp}"
    output_dir.mkdir(parents=True, exist_ok=False)

    datasets = build_datasets(
        sizes=sizes,
        data_cfg=data_cfg,
        seed=int(exp_cfg.get("random_seed", 42)),
    )

    warmup_runs = int(exp_cfg.get("warmup_runs", 1))
    timed_runs = int(exp_cfg.get("timed_runs", 3))
    timeout_seconds = float(exp_cfg.get("timeout_seconds", 8.0))
    early_stop_time_seconds = float(exp_cfg.get("early_stop_time_seconds", 3.0))
    early_stop_after_sizes = int(exp_cfg.get("early_stop_after_sizes", 2))

    rows = []
    for metric_info in metrics:
        metric_name = metric_info["name"]
        params = metric_info["params"]
        input_type = metric_info["input_type"]
        metric = metric_info["instance"]
        slow_sizes = 0

        for i, n in enumerate(sizes):
            y_true, y_pred_binary, y_pred_continuous = datasets[n]
            y_pred = y_pred_binary if input_type == "binary" else y_pred_continuous

            # Warmup is best-effort: never blocks timed measurements.
            for _ in range(warmup_runs):
                run_compute(metric, y_true, y_pred, timeout_seconds)

            run_results = []
            for run_id in range(timed_runs):
                elapsed, status, error_text = run_compute(metric, y_true, y_pred, timeout_seconds)
                run_results.append((elapsed, status, error_text))
                rows.append(
                    {
                        "metric_name": metric_name,
                        "params": str(params),
                        "input_type": input_type,
                        "size": int(n),
                        "run_id": run_id,
                        "elapsed_sec": float(elapsed) if not np.isnan(elapsed) else np.nan,
                        "status": status,
                        "error": error_text,
                    }
                )

            ok_times = [x[0] for x in run_results if x[1] == "ok" and not np.isnan(x[0])]
            timeout_or_error = any(x[1] in {"timeout", "error"} for x in run_results)
            if not ok_times:
                slow_sizes += 1
            else:
                median_time = float(np.median(ok_times))
                if median_time >= early_stop_time_seconds or timeout_or_error:
                    slow_sizes += 1
                else:
                    slow_sizes = 0

            if early_stop_after_sizes > 0 and slow_sizes >= early_stop_after_sizes:
                for skipped_size in sizes[i + 1 :]:
                    rows.append(
                        {
                            "metric_name": metric_name,
                            "params": str(params),
                            "input_type": input_type,
                            "size": int(skipped_size),
                            "run_id": -1,
                            "elapsed_sec": np.nan,
                            "status": "skipped_early_stop",
                            "error": "",
                        }
                    )
                break

    raw_df = pd.DataFrame(rows)
    if raw_df.empty:
        raise RuntimeError("No benchmark results were produced")

    summary_df = build_summary(raw_df)

    raw_path = output_dir / "raw_timings.csv"
    summary_path = output_dir / "summary.csv"
    report_path = output_dir / "complexity_report.md"

    raw_df.to_csv(raw_path, index=False)
    summary_df.to_csv(summary_path, index=False)
    write_markdown_report(report_path, summary_df, raw_df)

    if bool(plots_cfg.get("enabled", True)):
        plots_generated = generate_plots(
            raw_df=raw_df,
            output_dir=output_dir,
            log_scale=bool(plots_cfg.get("log_scale", True)),
        )
        if not plots_generated:
            print("Plots were skipped because matplotlib is not available in the current environment.")

    print(f"Benchmark completed. Output directory: {output_dir}")
    print(f"Raw timings: {raw_path}")
    print(f"Summary: {summary_path}")
    print(f"Report: {report_path}")


def main():
    parser = argparse.ArgumentParser(description="Run complexity benchmark for TSADmetrics.")
    parser.add_argument(
        "--config",
        type=str,
        default="experiments/complexity_benchmark/benchmark_config.yaml",
        help="Path to benchmark YAML config.",
    )
    parser.add_argument(
        "--tag",
        type=str,
        default=None,
        help="Optional run tag, for example: before_opt or after_opt.",
    )
    args = parser.parse_args()

    config_path = Path(args.config).resolve()
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")

    run_benchmark(config_path=config_path, tag=args.tag)


if __name__ == "__main__":
    main()
