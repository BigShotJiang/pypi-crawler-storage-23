"""Tests for package build and distribution scripts."""
