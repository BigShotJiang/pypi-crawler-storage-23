import json
import os
import tempfile
from typing import Any, Dict, Optional
import requests


def write_gradescope_json_file(
    out_file: str,
    server_url: str,
    course_id: str,
    assignment_id: str,
    headers: Dict[str, str],
    timeout_seconds: int,
    test_errors: Optional[Dict[str, Dict[str, Any]]] = None,
    test_output: Optional[Dict[str, str]] = None,
) -> None:
    """
    Writes the collected test results to a Gradescope-compatible JSON file.

    The output file will follow the following format. This method will include the per-test scores and
    information and skip the global information when possible for simplicity.

    { "score": 44.0, // optional, but required if not on each test case below. Overrides total of tests if specified.
    "execution_time": 136, // optional, seconds
    "output": "Text relevant to the entire submission", // optional
    "output_format": "simple_format", // Optional output format settings, see "Output String Formatting" below
    "test_output_format": "text", // Optional default output format for test case outputs, see "Output String Formatting" below
    "test_name_format": "text", // Optional default output format for test case names, see "Output String Formatting" below
    "visibility": "after_due_date", // Optional visibility setting
    "stdout_visibility": "visible", // Optional stdout visibility setting
    "extra_data": {}, // Optional extra data to be stored
    "tests": // Optional, but required if no top-level score
        [
            {
                "score": 2.0, // optional, but required if not on top level submission
                "max_score": 2.0, // optional
                "status": "passed", // optional, see "Test case status" below
                "name": "Your name here", // optional
                "name_format": "text", // optional formatting for the test case name, see "Output String Formatting" below
                "number": "1.1", // optional (will just be numbered in order of array if no number given)
                "output": "Giant multiline string that will be placed in a <pre> tag and collapsed by default", // optional
                "output_format": "text", // optional formatting for the test case output, see "Output String Formatting" below
                "tags": ["tag1", "tag2", "tag3"], // optional
                "visibility": "visible", // Optional visibility setting
                "extra_data": {} // Optional extra data to be stored
            },
            // and more test cases...
        ],
    "leaderboard": // Optional, will set up leaderboards for these values
        [
        {"name": "Accuracy", "value": .926},
        {"name": "Time", "value": 15.1, "order": "asc"},
        {"name": "Stars", "value": "*****"}
        ]
    }
    """
    # Validation
    if not out_file:
        raise ValueError("out_file cannot be empty")
    if not server_url:
        raise ValueError("server_url cannot be empty")

    test_errors = test_errors or {}
    test_output = test_output or {}

    try:
        utests_response = requests.get(
            f"{server_url}/api/v1/courses/{course_id}/assignments/{assignment_id}/utests",
            headers=headers,
            timeout=timeout_seconds,
        )
        utests_response.raise_for_status()
        utests = utests_response.json()

        attempts_response = requests.get(
            f"{server_url}/api/v1/courses/{course_id}/assignments/{assignment_id}/utest-attempts/my",
            headers=headers,
            timeout=timeout_seconds,
        )
        attempts_response.raise_for_status()
        attempts = attempts_response.json()
    except Exception as exc:
        print(f"Warning: Failed to fetch Gradescope data: {exc}")
        _write_json_atomically(out_file, {"score": 0.0, "tests": []})
        return

    attempts_by_key: Dict[str, Dict[str, Any]] = {}
    for attempt in attempts:
        utest = attempt.get("utest", {})
        key = f"{utest.get('module_name')}::{utest.get('utest_name')}"
        attempts_by_key[key] = attempt

    tests = []
    total_score = 0.0
    seen_keys = set()
    for utest in utests:
        module_name = utest.get("module_name")
        utest_name = utest.get("utest_name")
        key = f"{module_name}::{utest_name}"
        seen_keys.add(key)
        attempt = attempts_by_key.get(key)
        comparisons = attempt.get("comparisons", []) if attempt else []

        max_points = utest.get("max_points", 0.0)
        num_comparisons = utest.get("num_comparisons", 0)
        total_points = num_comparisons if num_comparisons else len(comparisons)

        if total_points == 0 or not comparisons:
            test_score = 0.0
            all_correct = False
            output_lines = []
            error_info = test_errors.get(key)
            error_message = error_info.get("message") if error_info else None
            if error_message:
                output_lines.append(error_message)
            else:
                output_lines.append("No comparisons recorded for this test.")
        else:
            test_score = sum(comp.get("score", 0.0) for comp in comparisons) / total_points * max_points
            all_correct = len(comparisons) == num_comparisons and all(
                comp.get("is_correct", False) for comp in comparisons
            )
            output_lines = []
            for comp in comparisons:
                comp_name = (
                    comp.get("comparison_name")
                    or comp.get("utest_ref_comparison_id")
                    or "unknown"
                )
                is_correct = comp.get("is_correct", False)
                status = "PASSED" if is_correct else "FAILED"
                student_out = comp.get("student_output")

                output_lines.append(f"Comparison '{comp_name}': {status}")
                output_lines.append(f"  Student output: {_format_output(student_out)}")

            if num_comparisons and len(comparisons) < num_comparisons:
                output_lines.append(
                    f"Missing {num_comparisons - len(comparisons)} comparisons for this test."
                )

        output_text = test_output.get(key)
        if output_text:
            output_lines.append("Output:")
            output_lines.append(output_text.rstrip())

        test_entry = {
            "name": utest_name,
            "score": test_score,
            "max_score": max_points,
            "status": "passed" if all_correct else "failed",
            "output": "\n".join(output_lines),
        }
        tests.append(test_entry)
        total_score += test_score

    for key, error_info in test_errors.items():
        if key in seen_keys:
            continue
        _, utest_name = key.split("::", 1)
        output_lines = [error_info.get("message", "Test failed before any comparisons.")]
        output_text = test_output.get(key)
        if output_text:
            output_lines.append("Output:")
            output_lines.append(output_text.rstrip())
        test_entry = {
            "name": utest_name,
            "score": 0.0,
            "max_score": error_info.get("max_points", 0.0),
            "status": "failed",
            "output": "\n".join(output_lines),
        }
        tests.append(test_entry)

    gradescope_json = {"score": total_score, "tests": tests}

    try:
        _write_json_atomically(out_file, gradescope_json)
    except (IOError, OSError) as e:
        print(f"Warning: Failed to write Gradescope JSON to {out_file}: {e}")


def _format_output(value: Any) -> str:
    """Format output value for display in Gradescope."""
    
    if isinstance(value, str):
        value = repr(value)
    elif isinstance(value, (int, float, bool, type(None))):
        value = str(value)
    elif isinstance(value, (list, dict)):
        value = json.dumps(value, indent=2)
    else:
        value = str(value)
    
    # Limit student output to 1000 characters with elipses in the middle if too long.
    if len(value) > 500:
        value = value[:245] + "...NOT DISPLAYING FULL OUTPUT DUE TO LENGTH..." + value[-245:]
    return value


def _write_json_atomically(file_path: str, data: dict) -> None:
    """Write JSON file atomically to avoid partial writes."""
    # Write to temporary file first
    dir_name = os.path.dirname(file_path) or "."
    with tempfile.NamedTemporaryFile(
        mode='w',
        dir=dir_name,
        delete=False,
        suffix='.tmp'
    ) as tmp_file:
        json.dump(data, tmp_file, indent=2)
        tmp_file.flush()
        os.fsync(tmp_file.fileno())
        tmp_name = tmp_file.name

    # Atomic rename (overwrites existing file)
    os.replace(tmp_name, file_path)    
