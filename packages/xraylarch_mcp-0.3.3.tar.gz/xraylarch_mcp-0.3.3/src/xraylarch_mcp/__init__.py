"""xraylarch-mcp: MCP server for X-ray spectroscopy analysis via xraylarch."""

__version__ = "0.3.3"
