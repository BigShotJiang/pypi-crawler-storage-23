"""Automation scripts for ASAP protocol (registry, schemas, fixtures).

This package provides CLI and CI scripts that automate protocol operations.
Scripts are run from the repo root with PYTHONPATH including src/.
"""
