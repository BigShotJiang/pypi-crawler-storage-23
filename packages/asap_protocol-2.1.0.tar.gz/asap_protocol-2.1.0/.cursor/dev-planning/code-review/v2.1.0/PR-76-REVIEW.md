# Code Review: PR #76

> **PR**: [feat(E5): OpenClaw integration — Python bridge, Node skill, docs & Registry UX](https://github.com/adriannoes/asap-protocol/pull/76)
> **Sprint**: E5 · OpenClaw Integration
> **Reviewer**: AI Staff Engineer · 2026-02-28

---

## 1. Executive Summary

| Category | Status | Summary |
| :--- | :--- | :--- |
| **Tech Stack** | ✅ | Follows Pydantic v2, asyncio, TypeScript, Tailwind/Shadcn conventions. No unapproved deps. |
| **Architecture** | ⚠️ | Core E5 is clean. Scope creep in auth refactor (`actions.ts`, `proxy.ts`, `auth.ts`) introduced without justification; duplicated exception handling in `openclaw.py`. |
| **Security** | ⚠️ | `actions.ts` dummy `NextRequest` workaround is fragile & couples to next-auth internals. CORS middleware allows same-origin bypass via omitted Origin header. External image CDN usage in DX page. |
| **Tests** | ✅ | Good coverage for Node skill (273 lines) and Python bridge. Dashboard test updates track the auth refactor correctly. |

> **General Feedback:** The OpenClaw integration core (Python bridge, Node.js skill, docs, usage snippets) is well-structured and follows established patterns from Sprint E3. The main concerns are: (1) an out-of-scope auth refactor in `actions.ts` that introduces a fragile `NextRequest` workaround, (2) duplicated error handling in the Python bridge, and (3) external CDN image loading on the DX page without CSP updates. These should be addressed before merge for production readiness.

---

## 2. Required Fixes (Must Address Before Merge)

### 2.1 Fragile Token Extraction via Dummy `NextRequest` in Server Action

*   **Location:** `apps/web/src/app/dashboard/actions.ts:75-89`
*   **Problem:** The `fetchUserRegistrationIssues` server action now manually reads session cookies, reconstructs cookie names (including the `__Secure-` prefix), and creates a _dummy_ `NextRequest` to call `getToken()`. This tightly couples to next-auth's internal cookie naming convention and can break silently on:
    - Environment differences (secure vs insecure cookies in staging/production)
    - `next-auth` version upgrades that rename cookies
    - `cookieName` configuration changes in `NextAuth()`
*   **Rationale (Expert View):** This is not part of Sprint E5 (OpenClaw integration). The previous `encryptToken`/`decryptToken` approach was simpler and self-contained. If there's a valid reason to remove it (e.g., a bug), it should be documented in the PR description and done in a separate, focused PR with proper testing. The current workaround is cargo-cult code that will be painful to debug in production.
*   **Fix Suggestion:** Either:
    - **Option A (Preferred):** Revert to the previous `encryptToken`/`decryptToken` pattern which was explicit and independent of cookie internals. If there was a bug with it, fix the bug directly.
    - **Option B:** Use the `auth()` callback itself to embed the access token in the session (it's already there in `token.accessToken`) — the session callback can just expose it:
    ```typescript
    // auth.ts — session callback
    async session({ session, token }) {
        // ... existing fields ...
        // Expose token securely to server-side only
        session.accessToken = token.accessToken as string | undefined;
        return session;
    }
    ```
    This avoids cookie reconstruction entirely and is the idiomatic next-auth pattern.

---

### 2.2 CORS Middleware Bypass via Missing `Origin` Header

*   **Location:** `apps/web/src/proxy.ts:10-14`
*   **Problem:** The CORS check only blocks if `origin && origin !== allowedOrigin`. When `origin` is `null` or missing (which happens in server-to-server requests, curl, browser extensions, or Postman), the request passes through without CORS enforcement. This is by design for CORS, but the code _intends_ an allowlist — it should enforce it properly.
*   **Rationale (Expert View):** This is fine for browser-originated requests (browsers always send `Origin` on cross-origin), but if the intent is to restrict API access to only the web app itself, a missing Origin shouldn't automatically succeed. Additionally, this CORS middleware change is **out of scope** for Sprint E5 and should be split into its own PR.
*   **Fix Suggestion:** If these routes are server actions (already protected by CSRF tokens), the CORS middleware is redundant and can be removed. If you're protecting REST API routes, consider:
    ```typescript
    // Reject missing Origin on API routes (strict mode)
    if (!origin || origin !== allowedOrigin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
    ```
    **Note:** Evaluate whether this breaks legitimate server-side callers first.

---

### 2.3 `assert` in Production Code (`get_result`)

*   **Location:** `src/asap/integrations/openclaw.py:23`
*   **Problem:** `assert isinstance(result, dict)` is used for data validation. Python's `-O` flag (optimized bytecode) removes all `assert` statements, which means this check would silently pass in production if someone runs with `python -O`.
*   **Rationale (Expert View):** Per tech-stack-decisions.md §1.1, the project enforces `mypy` strict mode for correctness. Using `assert` for runtime validation undermines this. This is also flagged in the review checklist: "relying on `assert` for data validation (removed in optimized bytecode) instead of Pydantic validators."
*   **Fix Suggestion:**
    ```python
    def get_result(result: str | dict[str, Any]) -> dict[str, Any]:
        """Return success dict or raise ValueError with error message."""
        if is_error_result(result):
            raise ValueError(str(result))
        if not isinstance(result, dict):
            raise TypeError(f"Expected dict result, got {type(result).__name__}")
        return result
    ```

---

### 2.4 External Image CDN without CSP Coverage

*   **Location:** `apps/web/src/app/developer-experience/page.tsx:169-177`
*   **Problem:** The Framework Ecosystem section loads images from two external CDNs:
    - `https://cdn.simpleicons.org/*` (via SimpleIcons)
    - `https://cdn.jsdelivr.net/gh/homarr-labs/*` (LlamaIndex, OpenClaw logos)
    
    Neither domain is whitelisted in the Content-Security-Policy `img-src` directive in `next.config.ts`. While `img-src` currently has `https:` wildcard, relying on external CDNs for critical UI elements introduces availability and security risks (CDN compromise, downtime).
*   **Rationale (Expert View):** The CSP in production is `img-src 'self' blob: data: https:` which does allow all HTTPS images. However, the broader concern is **availability** — if SimpleIcons goes down, your DX page shows broken images. For a marketplace product page, this is unacceptable.
*   **Fix Suggestion:**
    - Copy the ~8 SVG icons locally to `public/icons/` (they're <1KB each).
    - Use Next.js `Image` component with local assets.
    - Add `eslint-disable` only for truly dynamic external sources.

---

## 3. Tech-Specific Bug Hunt (Deep Dive)

*   [x] **Duplicated Exception Handling in `openclaw.py`**: `run_asap()` and `run_asap_auto_skill()` share identical `except` blocks (lines 63-68 and 85-90). Extract to a decorator or context manager per DRY principle.
*   [x] **`@ts-expect-error` Suppression in Test**: `dashboard-actions.test.ts:50` uses `@ts-expect-error` to override `cookies()` return type. While acceptable in tests, ensure this doesn't mask a genuine type mismatch that could surface in production.
*   [x] **`eslint-disable` for `@next/next/no-img-element`**: `developer-experience/page.tsx` uses raw `<img>` tags with `eslint-disable` comments. This bypasses Next.js `Image` optimization (lazy loading, width/height enforcement, CDN optimization). Acceptable for external SVGs only if intentional — document why.
*   [x] **Scope Creep: Auth/CORS Changes**: The PR description mentions "Fix flaky tests (oauth2 token expiry…)" which motivates the auth changes. However, the auth refactor (`auth.ts`, `actions.ts`, `proxy.ts`) is a significant behavioral change that should be a separate PR. It changes how access tokens are retrieved, removes `encryptedAccessToken` from the session, and adds a full CORS middleware. This makes the PR harder to review and revert if issues arise.
*   [x] **`type: ignore` Removals**: Removing `type: ignore[misc, assignment]` from `crewai.py` and `llamaindex.py` is good cleanup, but verify that `mypy` / `pyright` still pass without these suppressions. The fallback `CrewAIBaseTool = None` without annotation may produce type errors depending on mypy strictness.

---

## 4. Improvements & Refactoring (Highly Recommended)

*   [ ] **DRY: Extract Shared Error Handling in `openclaw.py`**
    - Both `run_asap` and `run_asap_auto_skill` catch `AgentRevokedException`, `SignatureVerificationError`, and `ValueError` with identical formatting. Extract into a private method or async context manager:
    ```python
    async def _safe_invoke(self, coro_fn):
        try:
            return await coro_fn()
        except AgentRevokedException as e:
            return f"{_ERROR_PREFIX} Agent revoked: {e!s}"
        except SignatureVerificationError as e:
            return f"{_ERROR_PREFIX} Signature verification failed: {e!s}"
        except ValueError as e:
            return f"{_ERROR_PREFIX} Invalid request or URN: {e!s}"
    ```

*   [ ] **Typing: Generic exception catch in Node.js skill**
    - `packages/asap-openclaw-skill/src/index.ts:179` catches `err` typed as `unknown` but only checks `instanceof Error`. Consider a stricter error boundary or logging to aid debugging when non-Error objects are thrown.

*   [ ] **`docs/register/page.tsx`: Server Component with No Data Fetching**
    - The new `/docs/register` page is a pure React Server Component (good, no `"use client"`). However, it's entirely static content — consider whether this should use `generateStaticParams` or `export const dynamic = 'force-static'` for optimal build-time generation.

*   [ ] **Node Skill: `generateId()` Predictability**
    - `packages/asap-openclaw-skill/src/index.ts:27-29` uses `Date.now().toString(36) + Math.random().toString(36).slice(2)` for correlation IDs. While acceptable for non-security purposes, `Math.random()` is not cryptographically secure. If these IDs ever become security-sensitive, switch to `crypto.randomUUID()`.

*   [ ] **Logging: Silent Error Swallowing in Bridge**
    - `openclaw.py` catches exceptions and returns error strings, but never logs them. Add `logger.warning(...)` before returning error strings so that operators can diagnose failures in production:
    ```python
    except AgentRevokedException as e:
        logger.warning("agent_revoked", urn=urn, error=str(e))
        return f"{_ERROR_PREFIX} Agent revoked: {e!s}"
    ```

*   [ ] **CSP: Vercel Analytics Domains Added but Not Documented**
    - `next.config.ts` adds `va.vercel-scripts.com` and `vitals.vercel-*` domains to CSP, which is correct for Vercel Analytics. Consider adding a code comment explaining why these are needed, and document in the PR description that Vercel Analytics is now enabled.

---

## 5. Verification Steps

> **For the OpenClaw integration (core E5):**
```bash
# Python bridge tests
uv run pytest tests/integrations/test_openclaw.py -v

# Node.js skill tests
cd packages/asap-openclaw-skill && npm test

# Type checking
uv run mypy src/asap/integrations/openclaw.py src/asap/client/market.py

# Web lint + tests
cd apps/web && npm run lint && npm test
```

> **For the auth refactor (if kept in this PR):**
```bash
# Dashboard action tests (updated mocks)
cd apps/web && npx vitest run src/app/dashboard/__tests__/dashboard-actions.test.ts

# Manual: verify dashboard login → My Registrations loads correctly
# Manual: verify CORS behavior — cross-origin fetch to /api/ routes is blocked
```

> **For the DX page external images:**
```bash
# Navigate to /developer-experience and verify all 8 framework icons load
# Block cdn.simpleicons.org in DevTools Network → verify graceful degradation
```
