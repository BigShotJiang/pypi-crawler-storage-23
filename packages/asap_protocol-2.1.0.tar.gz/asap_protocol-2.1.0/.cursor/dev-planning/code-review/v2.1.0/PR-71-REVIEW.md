# Code Review: PR #71

## 1. Executive Summary
| Category | Status | Summary |
| :--- | :--- | :--- |
| **Tech Stack** | ⚠️ | Uses standard `json` module over `orjson` or Pydantic's Rust-based serializers, violating performance standards. |
| **Architecture** | ✅ | Align perfectly with Issue #52 ground rules for Content-Type negotiation without altering the core `Envelope` model. |
| **Security** | ⚠️ | CPU-bound loop during string replacement introduces an event loop blocking/DoS risk for large payloads. |
| **Tests** | ✅ | Excellent test coverage for the new feature itself. |

> **General Feedback:** This PR perfectly executes the architectural vision outlined in Issue #52, keeping the Lambda Lang encoding cleanly segregated at the transport layer via Content-Type negotiation. However, before it can be merged into production, the serialization logic needs to be heavily optimized. The current implementation relies on the standard `json` module and sequential string replacements, which act as a CPU-bound bottleneck that will block the `asyncio` event loop.

## 2. Required Fixes (Must Address Before Merge)
*These issues block the PR from being "Production Ready".*



### Synchronous I/O in Async Path (Denial of Service Risk)
*   **Location:** `src/asap/transport/codecs/lambda_codec.py`
*   **GitHub Inline Comment Suggestion (1 - Encode):** Open `src/asap/transport/codecs/lambda_codec.py` on the PR diff, click `+` on lines `126-127`.
    *   **Inline Feedback to copy:**
        <details>
        <summary>Click to show comment copy text</summary>

        This loop iterating over 35 `.replace()` operations on a potentially massive JSON string is highly CPU-bound. Because FastAPI operates on an `asyncio` event loop, executing this directly will block the event loop, stalling all concurrent agent requests (DoS risk).

        **Suggestion:** Optimize this to a single pass using Python's built-in `re` module. Because `re` is implemented in C under the hood, running one regex substitution is drastically faster than executing a Python `for` loop and avoids creating 35 intermediate strings in memory:

        ```python
        import re

        # Pre-compile globally
        _ENCODE_PATTERN = re.compile("|".join(map(re.escape, _ENCODE_MAP.keys())))

        def _encode_match(m: re.Match) -> str:
            return _ENCODE_MAP[m.group(0)]

        def encode(json_str: str) -> str:
            # Assuming you accepted the suggestion to take json_str directly
            encoded_str = _ENCODE_PATTERN.sub(_encode_match, json_str)
            return _VERSION_PREFIX + encoded_str
        ```

        Even with this optimization, for very large payloads, this should ideally be called via `await asyncio.to_thread(lambda_codec.encode, ...)` from the routing layers to ensure the event loop is never blocked.
        </details>

*   **GitHub Inline Comment Suggestion (2 - Decode):** Open `src/asap/transport/codecs/lambda_codec.py` on the PR diff, click `+` on lines `169-170`.
    *   **Inline Feedback to copy:**
        <details>
        <summary>Click to show comment copy text</summary>

        The same event loop blocking risk applies here during decoding. Please apply the parallel regex optimization here as well:

        ```python
        _DECODE_PATTERN = re.compile("|".join(map(re.escape, _DECODE_MAP.keys())))

        def _decode_match(m: re.Match) -> str:
            return _DECODE_MAP[m.group(0)]

        def decode(encoded_str: str) -> str:
            # Check version prefix...
            json_str = encoded_str[len(_VERSION_PREFIX):]
            return _DECODE_PATTERN.sub(_decode_match, json_str)
        ```
        </details>
*   **Problem:** Taking the raw string and executing an `O(N*K)` string replacement loop in an async context.
*   **Rationale (Expert View):** FastAPI operates on an `asyncio` event loop. Performing extremely heavy CPU-bound string manipulation on potentially massive JSON payloads (e.g., large LLM context windows) will block the event loop entirely. This stalls all concurrent agent requests and introduces a severe Denial-of-Service (DoS) vector.

### Serialization Performance Optimization (Pydantic Rust Core)
*   **Location:** `src/asap/transport/codecs/lambda_codec.py` & `src/asap/transport/server.py`
*   **GitHub Inline Comment Suggestion (1 - Codec Signature):** Open `src/asap/transport/codecs/lambda_codec.py` on the PR diff, click `+` on line `106` (the `def encode` signature).
    *   **Inline Feedback to copy:**
        <details>
        <summary>Click to show comment copy text</summary>

        Accepting a `dict` here forces us to call `json.dumps()` in Python, which is much slower than utilizing Pydantic's native Rust core for serialization. 

        **Suggestion:** Change the signature to accept a pre-serialized JSON string. We can rely on the upstream routing layer to dump the model efficiently and pass it here:

        ```python
        def encode(json_str: str) -> str:
            # Drop the local json.dumps() import and execution.
            # (Apply the regex optimization on `json_str` directly)
        ```
        </details>

*   **GitHub Inline Comment Suggestion (2 - Server Integration):** Open `src/asap/transport/server.py` on the PR diff, click `+` on line `605` (`encoded_body = lambda_codec.encode(rpc_response.model_dump())`).
    *   **Inline Feedback to copy:**
        <details>
        <summary>Click to show comment copy text</summary>

        Running `model_dump()` creates a massive intermediate Python dictionary just to pass it to the codec for serializing again. This completely bypasses Pydantic v2's Rust-based performance architecture.

        **Suggestion:** Serialize directly to JSON using Pydantic's core, and pass the string to the updated codec:

        ```python
        # Leverage Pydantic's native Rust execution for near-native speeds
        encoded_body = lambda_codec.encode(rpc_response.model_dump_json(by_alias=True))
        ```
        </details>
*   **Problem:** The codec accepts a `dict` and uses standard `json.dumps()`. In `server.py`, `rpc_response.model_dump()` creates an intermediate dict just to be re-serialized.
*   **Rationale (Expert View):** Converting Pydantic models to `dict` and then to JSON in Python adds noticeable layer overhead for large payloads. We can keep the codebase lean (without adding external `orjson` dependencies) by ensuring the custom codec plugs into the pre-serialized output of Pydantic's highly-optimized Rust core (`model_dump_json()`).

### Swallowed Exception Without Traceback
*   **Location:** `src/asap/transport/server.py:Line 616-621`
*   **GitHub Inline Comment Suggestion:** Open `src/asap/transport/server.py` on the PR diff, click `+` on lines `616-621` (the `except Exception as e:` block).
*   **Problem:** Catching a generic `Exception` and logging a warning using `str(e)`, completely discarding the stack trace.
*   **Rationale (Expert View):** We heavily depend on observability. Without a stack trace, debugging production encoding failures becomes nearly impossible. 
*   **Fix Suggestion:**
    ```python
    except Exception as e:
        logger.warning(
            "asap.server.lambda_encode_failed",
            error=str(e),
            error_type=type(e).__name__,
            exc_info=True,  # MUST log the stack trace
        )
    ```

## 3. Tech-Specific Bug Hunt (Deep Dive)
*Issues specific to Next.js/FastAPI/Pydantic/Asyncio.*

*   **Event Loop Blocking**: `response.text` decode logic in `client.py` causes the same async loop string-replace blocking on the client side.
    *   **GitHub Inline Comment Suggestion:** Open `src/asap/transport/client.py` on the PR diff, click `+` on line `957`. This is the exact line inside the `try:` block where it checks the content type:
        ```python
        if LAMBDA_CONTENT_TYPE in response_content_type:
            json_response = lambda_codec.decode(response.text) # <--- LINE 957
        ```
    *   **Inline Feedback to copy:** 
        <details>
        <summary>Click to show comment copy text</summary>

        This `decode` call runs string replacement loops directly on `response.text`. For large payloads, this will block the client's `asyncio` event loop while waiting for CPU-bound parsing. 

        **Suggestion:** Offload the decoding to a thread to keep the client's async event loop free:

        ```python
        import asyncio

        if LAMBDA_CONTENT_TYPE in response_content_type:
            # Offload CPU-bound decoding to unblock the main event loop
            json_response = await asyncio.to_thread(lambda_codec.decode, response.text)
        else:
            json_response = response.json()
        ```
        </details>

*   **Pydantic Model Dump Overhead**: `rpc_response.model_dump()` in `server.py` followed by `json.dumps` in the codec creates unnecessary intermediate Python dictionary representations instead of serializing directly to bytes. 
    *   **GitHub Inline Comment Suggestion:** Open `src/asap/transport/server.py` on the PR diff, click `+` on line `605`. This is where `encoded_body = lambda_codec.encode(rpc_response.model_dump())` is called.
    *   **Inline Feedback to copy:**
        <details>
        <summary>Click to show comment copy text</summary>

        Using `model_dump()` followed by `json.dumps()` (inside the lambda codec) forces Pydantic to create a massive intermediate Python dictionary first. This completely bypasses Pydantic v2's Rust-based native serialization performance.

        **Suggestion:** If no `json.dumps` occurs locally anymore, output the string directly using Rust near-native speeds:

        ```python
        # Ensure lambda_codec.encode() accepts a `str` and uses regex optimization instead of dumps()
        encoded_body = lambda_codec.encode(rpc_response.model_dump_json(by_alias=True))
        ```
        </details>

## 4. Improvements & Refactoring (Highly Recommended)
*Code is correct, but can be cleaner/faster/safer.*

*   [ ] **Optimization**: Using a C-compiled Regex or an Aho-Corasick automaton for multiple substring replacements would be drastically faster than 35 sequential string `.replace()` calls.
*   [ ] **Readability**: The `_ENCODE_MAP` with magic string keys (`§Jrpc§`) obscures the payload data format natively.

## 5. Verification Steps
*How should the developer verify the fixes?*
> 1. Run integration tests: `uv run pytest tests/transport/integration/test_lambda_negotiation.py`
> 2. **Load/Concurrency Test:** Send a 10MB payload to the endpoint while monitoring the server via `asyncio` debug mode (`PYTHONASYNCIODEBUG=1`) to explicitly catch event loop blocking > 100ms.
