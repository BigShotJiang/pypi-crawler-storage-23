# Code Review: PR #72

**Status:** All items addressed (post-review follow-up).

---

## 1. Executive Summary
| Category | Status | Summary |
| :--- | :--- | :--- |
| **Tech Stack** | ✅ | Adheres well to Pydantic v2 semantics (`model_validate`) and modern Python 3.13+ typing (`list` instead of `typing.List`). |
| **Architecture** | ⚠️ | Solid IssueOps and revocation logic, but SDK fetching lacks HTTP connection pooling. |
| **Security** | ✅ | Cryptographic logic correctly defers to established CA verification. IssueOps path properly sanitizes inputs. |
| **Tests** | ✅ | Excellent coverage, making proper use of `httpx.MockTransport` instead of messy global mocking. |

> **General Feedback:** The PR successfully implements the foundational Trust & Revocation layer defined for Sprint E1 without major architectural drift. The IssueOps flow perfectly maps to the established registry procedures. However, the exact implementation of the `is_revoked` method needs architectural refinement because it currently forces a performance bottleneck that contradicts the core async architecture.

## 2. Required Fixes (Must Address Before Merge)
*These issues block the PR from being "Production Ready".*

### Missing HTTP Connection Pooling in `is_revoked` — ✅ Addressed
*   **Location:** `src/asap/client/revocation.py:44`
*   **Problem:** The `is_revoked` function instantiates a brand new `httpx.AsyncClient()` on every call within an `async with` block context manager.
*   **Rationale (Expert View):** Because **ADR-25** mandates that the `revoked_agents.json` list must be checked before *every* agent run and absolutely *must not be cached*, instantiating a new client here forces a fresh DNS resolution and TCP/TLS handshake before every single agent execution. Under concurrent load (e.g., via LangChain or CrewAI orchestration workflows), this lack of HTTP connection pooling will cause severe latency spikes and exhaust file descriptors/sockets, completely voiding the benefits of Python's `asyncio`.
*   **Fix Suggestion:** 
    Instead of passing a `transport`, the SDK should accept an optional shared `httpx.AsyncClient` instance explicitly from the caller (the future `MarketClient`), or utilize a global module-level singleton if none is provided.
    
    ```python
    # Example fix: Allow the caller to pass an existing client pool.
    async def is_revoked(
        urn: str,
        revoked_url: str | None = None,
        http_client: httpx.AsyncClient | None = None,
    ) -> bool:
        url = revoked_url or os.environ.get("ASAP_REVOKED_AGENTS_URL", DEFAULT_REVOKED_URL)
        
        client = http_client or httpx.AsyncClient()
        try:
            response = await client.get(url)
            response.raise_for_status()
        finally:
            if http_client is None:
                # Only close if we had to create a temporary fallback client
                await client.aclose()
                
        data = response.json()
        parsed = RevokedAgentsList.model_validate(data)
        return any(entry.urn == urn for entry in parsed.revoked)
    ```

## 3. Tech-Specific Bug Hunt (Deep Dive)
*Issues specific to Next.js/FastAPI/Pydantic/Asyncio.*

*   [x] **Mutable Default Argument**: Checked. `RevokedAgentsList` correctly uses `Field(default_factory=list)`.
*   [x] **Garbage Collected Task**: Checked. No dangling `create_task()` without references.
*   [x] **Fail-Closed Security Posture (Asyncio/HTTPX)**: Docstring in `is_revoked` now flags for Sprint E2 that MarketClient should catch `httpx.HTTPStatusError` and wrap in ASAPError.
*   [x] **Import-Time Env Evaluation**: `trust.py` now uses `_get_ca_key_b64()` at call time inside `verify_agent_trust()`, so monkeypatch after import works.

## 4. Improvements & Refactoring (Highly Recommended)
*Code is correct, but can be cleaner/faster/safer.*

*   [x] **Typing/Data Integrity in Scripts**: `process_revocation.py` now loads with `RevokedAgentsList.model_validate(revoked_data)`, mutates parsed model, and saves with `parsed.model_dump()`.
*   [x] **Optimization (Parse Before Filter)**: `is_revoked` now does a quick dict scan `any(d.get("urn") == urn for d in data.get("revoked", []))` and returns True/False without full Pydantic parse.

## 5. Verification Steps
*How should the developer verify the fixes?*
> Run: `uv run pytest tests/client/test_revocation.py -v` to ensure the function still works whether an `http_client` is passed or not. Focus on testing the new behavior of the persistent client cache.
