"""Scenario templates covering all 12 span types."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ScenarioTemplate:
    """Template for a trace scenario with span hierarchy."""

    name: str  # Scenario identifier
    description: str  # Human-readable description
    trace_structure: dict[str, Any]  # Hierarchical span structure
    weight: float  # Relative frequency (0.0-1.0)
    environments: list[str]  # Environments this scenario runs in
    error_rate: float  # Probability of error (0.0-1.0)
    models: list[str] = field(default_factory=list)  # Model IDs used


# Scenario templates covering all 12 span types:
# SPAN, GENERATION, CHAIN, TOOL, RETRIEVAL, AGENT,
# FUNCTION, REQUEST, SERVER, TASK, CACHE, EMBEDDING

SCENARIOS: list[ScenarioTemplate] = [
    # Scenario 1: Simple Generation (25%)
    # Covers: GENERATION
    ScenarioTemplate(
        name="simple_generation",
        description="Single LLM generation call",
        trace_structure={
            "root": {
                "type": "generation",
                "name": "llm_completion",
                "children": [],
            }
        },
        weight=0.25,
        environments=["dev", "staging", "production"],
        error_rate=0.02,
        models=["gpt-4o-mini", "gpt-3.5-turbo", "claude-3-haiku"],
    ),
    # Scenario 2: RAG Pipeline (20%)
    # Covers: CHAIN, EMBEDDING, RETRIEVAL, GENERATION
    ScenarioTemplate(
        name="rag_pipeline",
        description="Retrieval-Augmented Generation pipeline",
        trace_structure={
            "root": {
                "type": "chain",
                "name": "rag_chain",
                "children": [
                    {
                        "type": "embedding",
                        "name": "embed_query",
                        "children": [],
                    },
                    {
                        "type": "retrieval",
                        "name": "vector_search",
                        "children": [],
                    },
                    {
                        "type": "generation",
                        "name": "generate_answer",
                        "children": [],
                    },
                ],
            }
        },
        weight=0.20,
        environments=["dev", "staging", "production"],
        error_rate=0.05,
        models=["gpt-4o", "gpt-4o-mini", "claude-3-sonnet"],
    ),
    # Scenario 3: Agent with Tools (15%)
    # Covers: AGENT, GENERATION, TOOL, FUNCTION
    ScenarioTemplate(
        name="agent_tool_call",
        description="Agent invoking tools to complete a task",
        trace_structure={
            "root": {
                "type": "agent",
                "name": "task_agent",
                "children": [
                    {
                        "type": "generation",
                        "name": "plan_action",
                        "children": [],
                    },
                    {
                        "type": "tool",
                        "name": "tool_invocation",
                        "children": [
                            {
                                "type": "function",
                                "name": "execute_tool",
                                "children": [],
                            },
                        ],
                    },
                    {
                        "type": "generation",
                        "name": "synthesize_result",
                        "children": [],
                    },
                ],
            }
        },
        weight=0.15,
        environments=["dev", "staging", "production"],
        error_rate=0.08,
        models=["gpt-4o", "claude-3-opus", "claude-3-sonnet"],
    ),
    # Scenario 4: API Request Handler (15%)
    # Covers: SERVER, CACHE, REQUEST, GENERATION
    ScenarioTemplate(
        name="api_request_handler",
        description="Server handling an API request with caching",
        trace_structure={
            "root": {
                "type": "server",
                "name": "api_handler",
                "children": [
                    {
                        "type": "cache",
                        "name": "cache_lookup",
                        "children": [],
                    },
                    {
                        "type": "request",
                        "name": "external_api_call",
                        "children": [
                            {
                                "type": "generation",
                                "name": "llm_request",
                                "children": [],
                            },
                        ],
                    },
                ],
            }
        },
        weight=0.15,
        environments=["staging", "production"],
        error_rate=0.10,
        models=["gpt-4o-mini", "gpt-3.5-turbo"],
    ),
    # Scenario 5: Task Processing Pipeline (10%)
    # Covers: TASK, FUNCTION, GENERATION
    ScenarioTemplate(
        name="task_pipeline",
        description="Background task processing with multiple steps",
        trace_structure={
            "root": {
                "type": "task",
                "name": "background_task",
                "children": [
                    {
                        "type": "function",
                        "name": "validate_input",
                        "children": [],
                    },
                    {
                        "type": "generation",
                        "name": "process_content",
                        "children": [],
                    },
                    {
                        "type": "function",
                        "name": "persist_result",
                        "children": [],
                    },
                ],
            }
        },
        weight=0.10,
        environments=["production"],
        error_rate=0.03,
        models=["gpt-4-turbo", "claude-3-opus"],
    ),
    # Scenario 6: Multi-Agent Workflow (8%)
    # Covers: CHAIN, AGENT, TOOL, GENERATION (complex hierarchy)
    ScenarioTemplate(
        name="multi_agent_workflow",
        description="Multiple agents collaborating on a task",
        trace_structure={
            "root": {
                "type": "chain",
                "name": "multi_agent_chain",
                "children": [
                    {
                        "type": "agent",
                        "name": "researcher_agent",
                        "children": [
                            {
                                "type": "tool",
                                "name": "search_tool",
                                "children": [],
                            },
                            {
                                "type": "generation",
                                "name": "summarize_findings",
                                "children": [],
                            },
                        ],
                    },
                    {
                        "type": "agent",
                        "name": "writer_agent",
                        "children": [
                            {
                                "type": "generation",
                                "name": "draft_content",
                                "children": [],
                            },
                        ],
                    },
                ],
            }
        },
        weight=0.08,
        environments=["dev", "staging"],
        error_rate=0.12,
        models=["gpt-4o", "claude-3-opus"],
    ),
    # Scenario 7: Generic Workflow (7%)
    # Covers: SPAN, FUNCTION
    ScenarioTemplate(
        name="generic_workflow",
        description="Generic processing workflow without LLM",
        trace_structure={
            "root": {
                "type": "span",
                "name": "process_workflow",
                "children": [
                    {
                        "type": "function",
                        "name": "step_1",
                        "children": [],
                    },
                    {
                        "type": "function",
                        "name": "step_2",
                        "children": [],
                    },
                ],
            }
        },
        weight=0.07,
        environments=["dev", "test"],
        error_rate=0.15,
        models=[],  # No LLM models
    ),
]


def get_scenario_by_weight() -> ScenarioTemplate:
    """Select a scenario based on weight distribution."""
    import random

    weights = [s.weight for s in SCENARIOS]
    return random.choices(SCENARIOS, weights=weights, k=1)[0]
