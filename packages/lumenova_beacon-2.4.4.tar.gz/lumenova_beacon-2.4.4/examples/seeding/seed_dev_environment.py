"""
Seeding script for populating a dev environment with varied, realistic traces.

This script generates ~40 spans across 9 different scenarios:
- OpenAI auto-instrumentation
- Anthropic auto-instrumentation with retry patterns
- Decorated functions with nested spans
- LangChain RAG pipelines
- LangGraph basic agent execution
- LangGraph multi-tool research agent
- LangGraph parallel tool execution
- LangGraph with custom state management
- Manual spans with error scenarios

Requirements:
- OPENAI_API_KEY environment variable
- ANTHROPIC_API_KEY environment variable
- BEACON_ENDPOINT, BEACON_API_KEY environment variables
"""

import os
import time
import random
import uuid
from typing import Any, TypedDict, Annotated

# Core Beacon imports
from lumenova_beacon import BeaconClient, trace, BeaconCallbackHandler

# OpenTelemetry instrumentors
from opentelemetry.instrumentation.openai import OpenAIInstrumentor
from opentelemetry.instrumentation.anthropic import AnthropicInstrumentor

# LLM clients
from openai import OpenAI
from anthropic import Anthropic

# LangChain imports
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.tools import tool
from langchain_core.messages import HumanMessage

# LangGraph imports
from langgraph.graph import StateGraph, MessagesState, START, END, add_messages
from langgraph.prebuilt import ToolNode

from dotenv import load_dotenv
load_dotenv()


# ============================================================================
# SCENARIO 1: Simple OpenAI Generation
# ============================================================================

def scenario_1_simple_openai(openai_client: OpenAI) -> None:
    """
    Simple OpenAI chat completion - auto-instrumented.
    Creates 1 generation span.
    """
    print("\n[1/10] Running: Simple OpenAI Generation...")

    response = openai_client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "user",
                "content": "Write a one-sentence explanation of what observability means in software engineering."
            }
        ],
        temperature=0.7,
        max_tokens=100
    )

    print(f"  ✓ Generated response: {response.choices[0].message.content[:60]}...")
    print(f"  ✓ Tokens used: {response.usage.total_tokens}")


# ============================================================================
# SCENARIO 2: Anthropic with Retry Pattern
# ============================================================================

def scenario_2_anthropic_retry(beacon_client: BeaconClient, anthropic_client: Anthropic) -> None:
    """
    Anthropic call with simulated error and retry.
    Creates 3 spans: parent (manual) + 2 child (auto-instrumented).
    """
    print("\n[2/10] Running: Anthropic with Retry Pattern...")

    session_id = f"retry-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")

    with beacon_client.trace("anthropic_with_retry", session_id=session_id) as span:
        span.set_input({"prompt": "Explain distributed tracing", "max_retries": 2})
        span.set_metadata("integration", "anthropic")

        # Simulate first attempt failure
        try:
            # This would normally fail, but we'll simulate with metadata
            span.set_metadata("attempt_1", "simulated_rate_limit_error")
            print("  ! Simulating rate limit error on attempt 1...")
            time.sleep(0.5)  # Simulate delay

            # Retry with actual API call
            print("  → Retrying with backoff...")
            response = anthropic_client.messages.create(
                model="claude-3-5-haiku-20241022",
                max_tokens=150,
                messages=[
                    {
                        "role": "user",
                        "content": "In one sentence, explain what distributed tracing is."
                    }
                ]
            )

            result = response.content[0].text
            span.set_output({"response": result, "attempt": 2, "success": True})
            span.set_metadata("tokens_used", response.usage.input_tokens + response.usage.output_tokens)

            print(f"  ✓ Retry succeeded: {result[:60]}...")

        except Exception as e:
            span.record_exception(e)
            print(f"  ✗ Failed: {e}")
            raise


# ============================================================================
# SCENARIO 3: Decorated Function Pipeline
# ============================================================================

@trace
def validate_user_input(data: dict[str, Any]) -> dict[str, Any]:
    """Validate incoming data - creates child span."""
    time.sleep(0.3)  # Simulate validation logic

    if not data.get("user_id"):
        raise ValueError("Missing required field: user_id")

    return {**data, "validated": True}


@trace
def transform_data(data: dict[str, Any]) -> dict[str, Any]:
    """Transform validated data - creates child span."""
    time.sleep(0.4)

    return {
        "user_id": data["user_id"],
        "processed_at": time.time(),
        "score": random.uniform(0.7, 0.99),
        "validated": data["validated"]
    }


def persist_to_database(beacon_client: BeaconClient, data: dict[str, Any]) -> dict[str, Any]:
    """Persist data using manual span - creates child span."""
    with beacon_client.trace("database_write") as span:
        span.set_input(data)
        span.set_metadata("database", "user_analytics_db")
        span.set_metadata("table", "user_scores")

        time.sleep(0.5)  # Simulate DB write

        result = {**data, "id": random.randint(1000, 9999), "persisted": True}
        span.set_output(result)

        return result


def scenario_3_decorated_pipeline(beacon_client: BeaconClient) -> None:
    """
    Pipeline using decorated functions and manual spans.
    Creates 4 spans: parent + 3 children (validate, transform, persist).
    """
    print("\n[3/10] Running: Decorated Function Pipeline...")

    session_id = f"pipeline-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")

    # Run the pipeline with session_id set on parent span using manual trace
    with beacon_client.trace("user_data_pipeline", session_id=session_id) as span:
        raw_data = {"user_id": "usr_12345", "action": "login", "timestamp": time.time()}
        span.set_input(raw_data)

        print("  → Validating input...")
        validated = validate_user_input(raw_data)

        print("  → Transforming data...")
        transformed = transform_data(validated)

        print("  → Persisting to database...")
        persisted = persist_to_database(beacon_client, transformed)

        span.set_output(persisted)
        print(f"  ✓ Pipeline completed: Record ID {persisted['id']}")


# ============================================================================
# SCENARIO 4: LangChain RAG Pipeline
# ============================================================================

def scenario_4_langchain_rag(handler: BeaconCallbackHandler) -> None:
    """
    LangChain RAG pipeline with retrieval and generation.
    Creates 5-6 spans: retrieval, formatting, prompt, generation, parsing.
    """
    print("\n[4/10] Running: LangChain RAG Pipeline...")

    # Create sample documents
    documents = [
        Document(
            page_content="Observability is the ability to understand the internal state of a system by examining its outputs, such as logs, metrics, and traces.",
            metadata={"source": "obs-guide", "page": 1}
        ),
        Document(
            page_content="Distributed tracing tracks requests as they flow through microservices, creating a complete picture of the request lifecycle.",
            metadata={"source": "tracing-101", "page": 3}
        ),
        Document(
            page_content="Spans represent units of work in distributed tracing, containing timing data, metadata, and parent-child relationships.",
            metadata={"source": "tracing-101", "page": 7}
        ),
    ]

    # Create embeddings and vector store
    print("  → Creating vector store...")
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_documents(documents, embeddings)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

    # Format documents helper
    def format_docs(docs: list[Document]) -> str:
        return "\n\n".join(doc.page_content for doc in docs)

    # Create RAG chain
    prompt = ChatPromptTemplate.from_template(
        """Answer the question based on the following context:

Context: {context}

Question: {question}

Answer:"""
    )

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    rag_chain = (
        {
            "context": retriever | format_docs,
            "question": RunnablePassthrough()
        }
        | prompt
        | llm
        | StrOutputParser()
    )

    # Invoke with tracing
    print("  → Executing RAG chain...")
    answer = rag_chain.invoke(
        "What are spans in distributed tracing?",
        config={"callbacks": [handler]}
    )

    print(f"  ✓ RAG answer: {answer[:80]}...")


# ============================================================================
# SCENARIO 5: LangGraph Agent with Tools
# ============================================================================

# Define tools for the agent
@tool
@trace
def get_weather(location: str) -> str:
    """Get the current weather for a location."""
    time.sleep(0.5)  # Simulate API call

    weather_options = ["sunny", "cloudy", "rainy", "snowy"]
    temp = random.randint(50, 85)

    return f"The weather in {location} is {random.choice(weather_options)} with a temperature of {temp}°F."


@tool
def calculate(beacon_client: BeaconClient, expression: str) -> str:
    """Evaluate a mathematical expression."""
    with beacon_client.trace("calculator_tool") as span:
        span.set_input({"expression": expression})
        span.set_metadata("tool", "calculator")

        try:
            # Simulate error for certain inputs
            if "error" in expression.lower():
                raise ValueError("Invalid expression: contains 'error' keyword")

            # Simple evaluation (in production, use safe_eval)
            result = eval(expression)
            span.set_output({"result": result})

            return f"The result is {result}"

        except Exception as e:
            span.record_exception(e)
            return f"Error calculating '{expression}': {str(e)}"


def scenario_5_langgraph_agent(beacon_client: BeaconClient) -> None:
    """
    LangGraph agent with multiple tool calls.
    Creates 4-5 spans: agent orchestration + tool calls + generation.
    """
    print("\n[5/10] Running: LangGraph Agent Execution...")

    session_id = f"agent-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")

    # Create handler with session_id for this agent
    handler = BeaconCallbackHandler(session_id=session_id)

    # Create tools list - need to bind beacon_client to calculate
    tools = [get_weather, lambda expr: calculate(beacon_client, expr)]
    tools[1].__name__ = "calculate"  # Set name for LangChain

    # Define the agent state and logic
    def should_continue(state: MessagesState) -> str:
        messages = state["messages"]
        last_message = messages[-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    def call_model(state: MessagesState) -> dict[str, Any]:
        messages = state["messages"]

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        llm_with_tools = llm.bind_tools([get_weather])  # Bind only get_weather for simplicity

        response = llm_with_tools.invoke(messages)

        return {"messages": [response]}

    # Build the graph
    workflow = StateGraph(MessagesState)

    workflow.add_node("agent", call_model)
    workflow.add_node("tools", ToolNode([get_weather]))

    workflow.add_edge(START, "agent")
    workflow.add_conditional_edges("agent", should_continue, ["tools", END])
    workflow.add_edge("tools", "agent")

    app = workflow.compile()

    # Invoke agent with tracing
    print("  → Agent processing query...")
    result = app.invoke(
        {"messages": [HumanMessage(content="What's the weather in San Francisco?")]},
        config={"callbacks": [handler]}
    )

    final_message = result["messages"][-1].content
    print(f"  ✓ Agent response: {final_message[:80]}...")


# ============================================================================
# SCENARIO 6: LangGraph Multi-Tool Research Agent
# ============================================================================

@tool
@trace
def search_knowledge_base(query: str) -> str:
    """Search internal knowledge base for information."""
    time.sleep(0.6)

    knowledge = {
        "spans": "Spans are units of work in distributed systems that contain timing, metadata, and parent-child relationships.",
        "traces": "Traces are collections of spans that represent end-to-end request flows through distributed systems.",
        "observability": "Observability is the ability to understand system internal state from external outputs."
    }

    for key, value in knowledge.items():
        if key in query.lower():
            return f"Found: {value}"

    return "No relevant information found in knowledge base."


@tool
@trace
def web_search(query: str) -> str:
    """Search the web for current information."""
    time.sleep(0.7)

    return f"Web search results for '{query}': Found 15 relevant articles about distributed tracing best practices and implementation patterns."


@tool
@trace
def summarize_findings(text: str) -> str:
    """Summarize research findings."""
    time.sleep(0.4)

    word_count = len(text.split())
    return f"Summary: Analyzed {word_count} words. Key insight: Distributed tracing provides visibility into system behavior through structured span data."


def scenario_6_langgraph_research_agent(handler: BeaconCallbackHandler) -> None:
    """
    Multi-tool research agent with sequential tool calls.
    Creates 6-8 spans: agent orchestration + multiple tool invocations.
    """
    print("\n[6/10] Running: LangGraph Multi-Tool Research Agent...")

    # Define research workflow
    def should_continue(state: MessagesState) -> str:
        messages = state["messages"]
        last_message = messages[-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    def call_model(state: MessagesState) -> dict[str, Any]:
        messages = state["messages"]

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        llm_with_tools = llm.bind_tools([search_knowledge_base, web_search])

        response = llm_with_tools.invoke(messages)
        return {"messages": [response]}

    # Build research graph
    workflow = StateGraph(MessagesState)
    workflow.add_node("researcher", call_model)
    workflow.add_node("tools", ToolNode([search_knowledge_base, web_search]))

    workflow.add_edge(START, "researcher")
    workflow.add_conditional_edges("researcher", should_continue, ["tools", END])
    workflow.add_edge("tools", "researcher")

    app = workflow.compile()

    # Invoke research agent
    print("  → Research agent investigating query...")
    result = app.invoke(
        {"messages": [HumanMessage(content="What are the best practices for implementing distributed tracing with spans?")]},
        config={"callbacks": [handler]}
    )

    final_message = result["messages"][-1].content
    print(f"  ✓ Research complete: {final_message[:80]}...")


# ============================================================================
# SCENARIO 7: LangGraph with Parallel Tool Execution
# ============================================================================

@tool
@trace
def check_system_health(service: str) -> str:
    """Check the health status of a service."""
    time.sleep(0.5)

    statuses = ["healthy", "degraded", "healthy", "healthy"]
    status = random.choice(statuses)
    latency = random.randint(50, 200)

    return f"Service '{service}' is {status} with {latency}ms average latency."


@tool
@trace
def get_error_rate(service: str) -> str:
    """Get the error rate for a service."""
    time.sleep(0.4)

    error_rate = random.uniform(0.1, 2.5)
    return f"Service '{service}' error rate: {error_rate:.2f}%"


@tool
@trace
def check_resource_usage(service: str) -> str:
    """Check CPU and memory usage."""
    time.sleep(0.5)

    cpu = random.randint(20, 80)
    memory = random.randint(40, 85)

    return f"Service '{service}' resources: CPU {cpu}%, Memory {memory}%"


def scenario_7_langgraph_parallel_tools() -> None:
    """
    Agent that can call multiple monitoring tools in parallel.
    Creates 5-7 spans: agent + multiple parallel tool calls.
    """
    print("\n[7/10] Running: LangGraph Parallel Tool Execution...")

    session_id = f"monitoring-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")

    # Create handler with session_id for monitoring
    handler = BeaconCallbackHandler(session_id=session_id)

    def should_continue(state: MessagesState) -> str:
        messages = state["messages"]
        last_message = messages[-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"
        return END

    def call_model(state: MessagesState) -> dict[str, Any]:
        messages = state["messages"]

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        llm_with_tools = llm.bind_tools([check_system_health, get_error_rate, check_resource_usage])

        response = llm_with_tools.invoke(messages)
        return {"messages": [response]}

    # Build monitoring graph
    workflow = StateGraph(MessagesState)
    workflow.add_node("monitor", call_model)
    workflow.add_node("tools", ToolNode([check_system_health, get_error_rate, check_resource_usage]))

    workflow.add_edge(START, "monitor")
    workflow.add_conditional_edges("monitor", should_continue, ["tools", END])
    workflow.add_edge("tools", "monitor")

    app = workflow.compile()

    # Invoke monitoring agent
    print("  → Monitoring agent checking services...")
    result = app.invoke(
        {"messages": [HumanMessage(content="Give me a complete health check of the api-gateway service")]},
        config={"callbacks": [handler]}
    )

    final_message = result["messages"][-1].content
    print(f"  ✓ Health check complete: {final_message[:80]}...")


# ============================================================================
# SCENARIO 8: LangGraph with State Transformation
# ============================================================================


class AnalysisState(TypedDict):
    messages: Annotated[list, add_messages]
    analysis_stage: str
    findings: list[str]
    confidence_score: float


@tool
@trace
def analyze_logs(time_range: str) -> str:
    """Analyze system logs for anomalies."""
    time.sleep(0.6)

    anomalies = random.randint(3, 15)
    return f"Found {anomalies} anomalies in logs over {time_range}. Most common: increased latency (45%), timeouts (30%), errors (25%)."


@tool
@trace
def correlate_metrics(metric_type: str) -> str:
    """Correlate metrics across services."""
    time.sleep(0.5)

    correlation = random.uniform(0.6, 0.95)
    return f"Metric correlation for {metric_type}: {correlation:.2f}. Strong correlation detected between frontend latency and database query times."


def scenario_8_langgraph_state_management(handler: BeaconCallbackHandler) -> None:
    """
    LangGraph with custom state and transformations.
    Creates 6-8 spans with state evolution tracking.
    """
    print("\n[8/10] Running: LangGraph with State Management...")

    def analyze_stage_1(state: AnalysisState) -> dict[str, Any]:
        """Initial analysis stage."""
        messages = state["messages"]

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        llm_with_tools = llm.bind_tools([analyze_logs])

        response = llm_with_tools.invoke(messages)

        return {
            "messages": [response],
            "analysis_stage": "log_analysis",
            "findings": ["Started log analysis"]
        }

    def analyze_stage_2(state: AnalysisState) -> dict[str, Any]:
        """Correlation analysis stage."""
        messages = state["messages"]

        llm = ChatOpenAI(model="gpt-4o-mini", temperature=0)
        llm_with_tools = llm.bind_tools([correlate_metrics])

        response = llm_with_tools.invoke(messages)

        return {
            "messages": [response],
            "analysis_stage": "correlation",
            "findings": state["findings"] + ["Completed correlation analysis"],
            "confidence_score": random.uniform(0.75, 0.95)
        }

    def should_continue(state: AnalysisState) -> str:
        messages = state["messages"]
        last_message = messages[-1]

        if hasattr(last_message, "tool_calls") and last_message.tool_calls:
            return "tools"

        # Route based on analysis stage
        stage = state.get("analysis_stage", "")
        if stage == "log_analysis":
            return "stage_2"

        return END

    # Build analysis graph
    workflow = StateGraph(AnalysisState)

    workflow.add_node("stage_1", analyze_stage_1)
    workflow.add_node("stage_2", analyze_stage_2)
    workflow.add_node("tools", ToolNode([analyze_logs, correlate_metrics]))

    workflow.add_edge(START, "stage_1")
    workflow.add_conditional_edges("stage_1", should_continue, ["tools", "stage_2", END])
    workflow.add_edge("tools", "stage_2")
    workflow.add_conditional_edges("stage_2", should_continue, ["tools", END])

    app = workflow.compile()

    # Invoke analysis agent
    print("  → Running multi-stage analysis workflow...")
    result = app.invoke(
        {
            "messages": [HumanMessage(content="Analyze system performance issues from the last hour")],
            "analysis_stage": "initial",
            "findings": [],
            "confidence_score": 0.0
        },
        config={"callbacks": [handler]}
    )

    final_message = result["messages"][-1].content
    confidence = result.get("confidence_score", 0.0)
    print(f"  ✓ Analysis complete (confidence: {confidence:.2f}): {final_message[:60]}...")


# ============================================================================
# SCENARIO 9: Error Scenario
# ============================================================================

@trace
def risky_api_call() -> dict[str, Any]:
    """Simulates an API call that times out - creates child span with error."""
    time.sleep(0.3)

    # Simulate timeout error
    raise TimeoutError("Request to external API timed out after 5 seconds")


def scenario_9_error_handling(beacon_client: BeaconClient) -> None:
    """
    Error scenario with timeout and recovery.
    Creates 2 spans: parent handler + child API call (with error).
    """
    print("\n[9/10] Running: Error Scenario with Exception...")

    session_id = f"error-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")

    with beacon_client.trace("api_request_handler", session_id=session_id) as span:
        try:
            print("  → Making risky API call...")
            risky_api_call()

        except TimeoutError as e:
            span.record_exception(e)
            print(f"  ! Caught expected error: {str(e)}")
            print("  ✓ Error recorded in span")
            # In production, you might implement retry logic or fallback


# ============================================================================
# SCENARIO 10: Multi-Turn Chatbot Conversation
# ============================================================================

def scenario_10_chatbot_conversation() -> None:
    """
    Multi-turn chatbot conversation with shared session_id.
    Demonstrates tracking multiple independent traces that share the same session_id.
    Creates 3 separate traces (one per turn), all linked by session_id.
    """
    print("\n[10/10] Running: Multi-Turn Chatbot Conversation...")

    session_id = f"chat-session-{uuid.uuid4().hex[:8]}"
    print(f"  📍 Session ID: {session_id}")
    print("  (All conversation turns will share this session_id)")

    # Create a LangChain handler with the shared session_id
    handler = BeaconCallbackHandler(session_id=session_id)

    # Create LangChain LLM
    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.7)

    # Maintain conversation history
    messages: list[Any] = []

    # Turn 1: User asks about Python decorators
    print("  → Turn 1: User asks about decorators...")
    messages.append(HumanMessage(content="What are Python decorators and why are they useful?"))

    response1 = llm.invoke(messages, config={"callbacks": [handler]})
    messages.append(response1)
    print(f"    ✓ Bot responded: {response1.content[:60]}...")

    time.sleep(1.5)  # Simulate user reading response

    # Turn 2: User asks for an example
    print("  → Turn 2: User asks for an example...")
    messages.append(HumanMessage(content="Can you show me a simple example of a decorator that logs function calls?"))

    response2 = llm.invoke(messages, config={"callbacks": [handler]})
    messages.append(response2)
    print(f"    ✓ Bot responded: {response2.content[:60]}...")

    time.sleep(1.5)  # Simulate user reading response

    # Turn 3: User asks a follow-up about practical use
    print("  → Turn 3: User asks about practical applications...")
    messages.append(HumanMessage(content="How would I use decorators for caching in a real application?"))

    response3 = llm.invoke(messages, config={"callbacks": [handler]})
    messages.append(response3)
    print(f"    ✓ Bot responded: {response3.content[:60]}...")

    print(f"  ✓ Conversation complete: 3 separate traces with session_id={session_id}")


# ============================================================================
# MAIN ORCHESTRATOR
# ============================================================================

def main() -> None:
    """Main orchestrator that runs all scenarios with delays."""

    print("=" * 70)
    print("🌟 BEACON SDK - DEV ENVIRONMENT SEEDING SCRIPT")
    print("=" * 70)
    print("\nThis script will generate ~44 spans across 10 different scenarios.")
    print("Each scenario demonstrates different tracing patterns and integrations.")
    print("Focus: Multiple LangGraph examples + session_id tracking patterns.")
    print()

    # Verify environment variables
    required_vars = ["OPENAI_API_KEY", "ANTHROPIC_API_KEY", "BEACON_ENDPOINT", "BEACON_API_KEY"]
    missing_vars = [var for var in required_vars if not os.getenv(var)]

    if missing_vars:
        print(f"❌ Missing required environment variables: {', '.join(missing_vars)}")
        print("\nPlease set the following environment variables:")
        print("  $env:OPENAI_API_KEY = 'your-openai-key'")
        print("  $env:ANTHROPIC_API_KEY = 'your-anthropic-key'")
        print("  $env:BEACON_ENDPOINT = 'http://localhost:8000' (or your endpoint)")
        print("  $env:BEACON_API_KEY = 'your-beacon-key'")
        return

    print("✓ Environment variables validated")

    # Initialize Beacon client
    print("\n📡 Initializing Beacon SDK...")
    beacon_client = BeaconClient()

    # Setup auto-instrumentation for OpenAI and Anthropic
    print("🔧 Setting up auto-instrumentation...")
    OpenAIInstrumentor().instrument()
    AnthropicInstrumentor().instrument()

    # Initialize LLM clients
    openai_client = OpenAI()
    anthropic_client = Anthropic()

    # Initialize LangChain callback handler
    langchain_handler = BeaconCallbackHandler()

    print("\n✓ Setup complete! Starting seeding scenarios...\n")

    start_time = time.time()
    span_count = 0

    try:
        # Scenario 1: Simple OpenAI (1 span)
        scenario_1_simple_openai(openai_client)
        span_count += 1
        time.sleep(2)

        # Scenario 2: Anthropic with retry (3 spans)
        scenario_2_anthropic_retry(beacon_client, anthropic_client)
        span_count += 3
        time.sleep(2)

        # Scenario 3: Decorated pipeline (4 spans)
        scenario_3_decorated_pipeline(beacon_client)
        span_count += 4
        time.sleep(2)

        # Scenario 4: LangChain RAG (5-6 spans)
        scenario_4_langchain_rag(langchain_handler)
        span_count += 6
        time.sleep(2)

        # Scenario 5: LangGraph agent (4-5 spans) - with session_id
        scenario_5_langgraph_agent(beacon_client)
        span_count += 5
        time.sleep(2)

        # Scenario 6: LangGraph multi-tool research agent (6-8 spans)
        scenario_6_langgraph_research_agent(langchain_handler)
        span_count += 7
        time.sleep(2)

        # Scenario 7: LangGraph parallel tool execution (5-7 spans) - with session_id
        scenario_7_langgraph_parallel_tools()
        span_count += 6
        time.sleep(2)

        # Scenario 8: LangGraph state management (6-8 spans)
        scenario_8_langgraph_state_management(langchain_handler)
        span_count += 7
        time.sleep(2)

        # Scenario 9: Error handling (2 spans) - with session_id
        scenario_9_error_handling(beacon_client)
        span_count += 2
        time.sleep(2)

        # Scenario 10: Multi-turn chatbot conversation (3 separate traces) - with shared session_id
        scenario_10_chatbot_conversation()
        span_count += 3

    except Exception as e:
        print(f"\n❌ Unexpected error during seeding: {e}")
        raise

    duration = time.time() - start_time

    # Summary
    print("\n" + "=" * 70)
    print("✅ SEEDING COMPLETE!")
    print("=" * 70)
    print(f"Total spans generated: ~{span_count}")
    print(f"Total execution time: {duration:.1f}s")
    print(f"Endpoint: {os.getenv('BEACON_ENDPOINT')}")
    print("\n💡 Check your Beacon dashboard to view the traces!")
    print("=" * 70)


if __name__ == "__main__":
    main()
