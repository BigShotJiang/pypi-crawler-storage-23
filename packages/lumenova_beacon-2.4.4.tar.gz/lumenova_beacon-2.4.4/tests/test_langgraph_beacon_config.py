"""Tests for LangGraphBeaconConfig.

Tests the LangGraphBeaconConfig class (checkpoint resolution, checkpoint_metadata
property, get_config() method, langgraph_config property) and the
create_langgraph_beacon_config convenience wrapper.
"""

from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

from lumenova_beacon import BeaconClient
from lumenova_beacon.tracing.integrations.langchain import (
    BeaconCallbackHandler,
    LangGraphBeaconConfig,
)


@pytest.fixture(autouse=True)
def mock_beacon_client():
    """Patch get_client so BeaconCallbackHandler doesn't need a real client."""
    client = MagicMock(spec=BeaconClient)
    client.config = MagicMock()
    client.config.session_id = None
    client._timestamp_override = None
    with patch(
        "lumenova_beacon.tracing.integrations.langchain.get_client",
        return_value=client,
    ):
        yield client


def _make_graph(state=None):
    """Create a mock compiled LangGraph graph with sync get_state."""
    graph = MagicMock()
    graph.get_state = MagicMock(return_value=state)
    return graph


def _make_state_snapshot(
    metadata: dict | None = None,
    next_nodes: tuple = (),
    interrupts: tuple = (),
):
    """Create a mock StateSnapshot-like object."""
    return SimpleNamespace(
        values={"messages": []},
        next=next_nodes,
        metadata=metadata,
        created_at=None,
        parent_config=None,
        tasks=(),
        interrupts=interrupts,
    )


# =========================================================================
# LangGraphBeaconConfig initialization / checkpoint resolution
# =========================================================================

class TestLangGraphBeaconConfigInit:
    """Tests for LangGraphBeaconConfig checkpoint resolution."""

    def test_fresh_thread_generates_new_ids(self):
        """Fresh thread (no checkpoint) generates new trace_id and root_span_id."""
        graph = _make_graph(state=None)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        assert beacon.trace_id is not None
        assert beacon.root_span_id is not None
        assert len(beacon.trace_id) == 32
        assert len(beacon.root_span_id) == 16
        assert beacon.is_resume is False
        assert beacon.handler._agent_name == "test_agent"
        graph.get_state.assert_called_once()

    def test_interrupted_thread_resumes_trace(self):
        """Interrupted thread (next non-empty) resumes with stored trace_id."""
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "a" * 32,
                    "root_span_id": "b" * 16,
                    "session_id": "session-123",
                },
            },
            next_nodes=("plan",),
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-2",
            agent_name="test_agent",
        )

        assert beacon.is_resume is True
        assert beacon.trace_id == "a" * 32
        assert beacon.root_span_id == "b" * 16
        assert beacon.handler._session_id == "session-123"

    def test_interrupted_thread_with_interrupts_field(self):
        """Thread with state.interrupts also triggers resume."""
        interrupt = SimpleNamespace(value="Please confirm", id="int-1")
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "c" * 32,
                    "root_span_id": "d" * 16,
                },
            },
            next_nodes=(),
            interrupts=(interrupt,),
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-3",
            agent_name="test_agent",
        )

        assert beacon.is_resume is True
        assert beacon.trace_id == "c" * 32

    def test_completed_thread_starts_fresh_trace(self):
        """Completed thread (next empty, no interrupts) starts fresh trace."""
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "e" * 32,
                    "root_span_id": "f" * 16,
                    "session_id": "session-456",
                },
            },
            next_nodes=(),
            interrupts=(),
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-4",
            agent_name="test_agent",
        )

        assert beacon.is_resume is False
        assert beacon.trace_id != "e" * 32
        assert len(beacon.trace_id) == 32
        # Session ID IS reused from previous checkpoint
        assert beacon.handler._session_id == "session-456"

    def test_session_id_reused_from_checkpoint(self):
        """Session ID from previous checkpoint is reused when not provided."""
        state = _make_state_snapshot(
            metadata={"_beacon": {"session_id": "reused-session"}},
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-5",
            agent_name="test_agent",
        )

        assert beacon.handler._session_id == "reused-session"

    def test_explicit_session_id_overrides_checkpoint(self):
        """Explicitly provided session_id overrides the one from checkpoint."""
        state = _make_state_snapshot(
            metadata={"_beacon": {"session_id": "old-session"}},
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-6",
            agent_name="test_agent",
            session_id="explicit-session",
        )

        assert beacon.handler._session_id == "explicit-session"

    def test_get_state_error_falls_back_to_fresh(self):
        """If get_state raises, falls back to fresh trace gracefully."""
        graph = MagicMock()
        graph.get_state = MagicMock(side_effect=RuntimeError("no checkpointer"))

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-7",
            agent_name="test_agent",
        )

        assert beacon.is_resume is False
        assert beacon.trace_id is not None
        assert len(beacon.trace_id) == 32

    def test_no_metadata_in_state(self):
        """State snapshot with metadata=None falls back to fresh trace."""
        state = _make_state_snapshot(metadata=None)
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-8",
            agent_name="test_agent",
        )

        assert beacon.is_resume is False
        assert beacon.trace_id is not None

    def test_session_id_generated_when_not_available(self):
        """A new session_id UUID is generated when none exists."""
        graph = _make_graph(state=None)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-9",
            agent_name="test_agent",
        )

        session_id = beacon.handler._session_id
        assert session_id is not None
        assert len(session_id) == 36
        assert session_id.count("-") == 4

    def test_interrupted_but_no_stored_trace_id_starts_fresh(self):
        """If graph is interrupted but no beacon_trace_id in checkpoint, start fresh."""
        state = _make_state_snapshot(
            metadata={"source": "loop", "step": 2},
            next_nodes=("execute",),
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-10",
            agent_name="test_agent",
        )

        assert beacon.is_resume is False
        assert beacon.trace_id is not None
        assert len(beacon.trace_id) == 32

    def test_environment_forwarded_to_handler(self):
        """Environment is forwarded to BeaconCallbackHandler."""
        graph = _make_graph(state=None)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-11",
            agent_name="test_agent",
            environment="production",
        )

        assert beacon.handler._environment == "production"

    def test_handler_is_beacon_callback_handler(self):
        """The handler property returns a BeaconCallbackHandler."""
        graph = _make_graph(state=None)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-12",
            agent_name="test_agent",
        )

        assert isinstance(beacon.handler, BeaconCallbackHandler)

    def test_backwards_compat_reads_flat_keys_from_metadata(self):
        """Old checkpoints with flat beacon_* keys in metadata still resolve."""
        state = _make_state_snapshot(
            metadata={
                "beacon_trace_id": "x" * 32,
                "beacon_root_span_id": "y" * 16,
                "beacon_session_id": "old-session",
            },
            next_nodes=("plan",),
        )
        graph = _make_graph(state=state)

        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-13",
            agent_name="test_agent",
        )

        assert beacon.is_resume is True
        assert beacon.trace_id == "x" * 32
        assert beacon.root_span_id == "y" * 16
        assert beacon.handler._session_id == "old-session"


# =========================================================================
# checkpoint_metadata property
# =========================================================================

class TestCheckpointMetadataProperty:
    """Tests for the checkpoint_metadata property."""

    def test_returns_nested_beacon_key(self):
        """Returns a dict with a nested _beacon key."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        meta = beacon.checkpoint_metadata

        assert "_beacon" in meta
        assert meta["_beacon"]["trace_id"] == beacon.trace_id
        assert meta["_beacon"]["root_span_id"] == beacon.root_span_id
        assert meta["_beacon"]["session_id"] == beacon.handler._session_id

    def test_resume_ids_included(self):
        """On resume, returns the checkpoint-restored IDs."""
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "a" * 32,
                    "root_span_id": "b" * 16,
                    "session_id": "sess-1",
                },
            },
            next_nodes=("plan",),
        )
        graph = _make_graph(state=state)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-2",
            agent_name="test_agent",
        )

        meta = beacon.checkpoint_metadata

        assert meta["_beacon"]["trace_id"] == "a" * 32
        assert meta["_beacon"]["root_span_id"] == "b" * 16
        assert meta["_beacon"]["session_id"] == "sess-1"


# =========================================================================
# get_config() method
# =========================================================================

class TestGetConfig:
    """Tests for the get_config() method."""

    def test_basic_config_structure(self):
        """Config has configurable, metadata with _beacon, and callbacks."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.get_config()

        assert config["configurable"]["thread_id"] == "thread-1"
        assert "_beacon" in config["metadata"]
        assert config["callbacks"] == [beacon.handler]
        # No flat beacon_* keys in metadata
        assert "beacon_trace_id" not in config["metadata"]

    def test_custom_configurable_merged(self):
        """User-provided configurable keys are merged with thread_id."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.get_config(configurable={"recursion_limit": 50})

        assert config["configurable"]["thread_id"] == "thread-1"
        assert config["configurable"]["recursion_limit"] == 50

    def test_custom_metadata_merged(self):
        """User-provided metadata is merged with beacon keys."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.get_config(metadata={"custom_key": "value"})

        assert config["metadata"]["custom_key"] == "value"
        assert "_beacon" in config["metadata"]

    def test_tags_added(self):
        """Tags are added to config."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.get_config(tags=["production", "v2"])

        assert config["tags"] == ["production", "v2"]

    def test_extra_kwargs_added(self):
        """Extra kwargs are included in config."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.get_config(run_name="my_run")

        assert config["run_name"] == "my_run"

    def test_resume_ids_in_metadata(self):
        """On resume, config metadata contains the restored IDs."""
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "a" * 32,
                    "root_span_id": "b" * 16,
                    "session_id": "session-x",
                },
            },
            next_nodes=("plan",),
        )
        graph = _make_graph(state=state)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-2",
            agent_name="test_agent",
        )

        config = beacon.get_config()

        assert config["metadata"]["_beacon"]["trace_id"] == "a" * 32
        assert config["metadata"]["_beacon"]["root_span_id"] == "b" * 16
        assert config["metadata"]["_beacon"]["session_id"] == "session-x"


# =========================================================================
# langgraph_config property (delegates to get_config)
# =========================================================================

class TestLanggraphConfigProperty:
    """Tests for the langgraph_config property."""

    def test_config_contains_beacon_keys_in_metadata(self):
        """Config has nested _beacon in metadata."""
        graph = _make_graph(state=None)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-1",
            agent_name="test_agent",
        )

        config = beacon.langgraph_config

        assert config["configurable"]["thread_id"] == "thread-1"
        assert config["metadata"]["_beacon"]["trace_id"] == beacon.trace_id
        assert config["metadata"]["_beacon"]["root_span_id"] == beacon.root_span_id
        assert config["metadata"]["_beacon"]["session_id"] == beacon.handler._session_id
        assert config["callbacks"] == [beacon.handler]

    def test_config_preserves_resume_ids(self):
        """On resume, config contains the same trace_id from checkpoint."""
        state = _make_state_snapshot(
            metadata={
                "_beacon": {
                    "trace_id": "a" * 32,
                    "root_span_id": "b" * 16,
                    "session_id": "session-x",
                },
            },
            next_nodes=("plan",),
        )
        graph = _make_graph(state=state)
        beacon = LangGraphBeaconConfig(
            graph=graph,
            thread_id="thread-2",
            agent_name="test_agent",
        )

        config = beacon.langgraph_config

        assert config["metadata"]["_beacon"]["trace_id"] == "a" * 32
        assert config["metadata"]["_beacon"]["root_span_id"] == "b" * 16
        assert config["metadata"]["_beacon"]["session_id"] == "session-x"
