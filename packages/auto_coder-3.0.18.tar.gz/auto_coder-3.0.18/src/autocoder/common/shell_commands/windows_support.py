"""
Windows-specific command wrapping and encoding support.

On Windows, ``subprocess.Popen(..., shell=True)`` delegates to ``cmd.exe``
which uses the console's active code-page (often GBK / cp936) for stdout.
If we hard-code ``encoding='utf-8'``, the output will be garbled.

This module provides helpers that:

1. Detect whether the parent process is PowerShell or cmd.exe.
2. Wrap the command string into an explicit ``argv`` list that launches
   the correct shell (PowerShell or cmd) **with** a UTF-8 preamble so
   that the output can be decoded as UTF-8.
3. Return the matching ``encoding`` string so callers can pass it to
   ``subprocess.Popen``.

Usage from ``ProcessManager``::

    if platform.system() == "Windows" and isinstance(command, str):
        command, shell, encoding = prepare_windows_command(command, encoding)
"""

import ctypes
import os
import platform
import subprocess
from typing import List, Optional, Tuple, Union

from loguru import logger

try:
    import psutil

    _PSUTIL_AVAILABLE = True
except ImportError:
    psutil = None  # type: ignore[assignment]
    _PSUTIL_AVAILABLE = False


# ---------------------------------------------------------------------------
# Shell detection
# ---------------------------------------------------------------------------


def _detect_parent_shell() -> str:
    """Return ``'powershell'``, ``'pwsh'``, or ``'cmd'``.

    Detection order:
    1. Walk the parent-process chain via *psutil* looking for
       ``powershell.exe``, ``pwsh.exe``, or ``cmd.exe``.
    2. Fall back to the ``COMSPEC`` environment variable.
    3. Default to ``'powershell'`` so that PowerShell-only cmdlets
       (``Stop-Process``, ``Get-ChildItem``, etc.) work out of the box.
    """
    if _PSUTIL_AVAILABLE and psutil is not None:
        try:
            proc = psutil.Process()
            visited = set()
            while proc is not None and proc.pid not in visited:
                visited.add(proc.pid)
                name = proc.name().lower()
                if name in ("powershell.exe", "powershell"):
                    return "powershell"
                if name in ("pwsh.exe", "pwsh"):
                    return "pwsh"
                if name in ("cmd.exe", "cmd"):
                    return "cmd"
                try:
                    proc = proc.parent()
                except Exception:
                    break
        except Exception:
            pass

    comspec = os.environ.get("COMSPEC", "").lower()
    if "cmd.exe" in comspec:
        return "cmd"

    return "powershell"


# ---------------------------------------------------------------------------
# Console code-page helpers
# ---------------------------------------------------------------------------


def _get_console_code_page() -> int:
    """Return the active console output code-page via the Win32 API.

    Falls back to ``65001`` (UTF-8) if the call is unavailable.
    """
    try:
        return ctypes.windll.kernel32.GetConsoleOutputCP()  # type: ignore[attr-defined]
    except Exception:
        pass

    try:
        result = subprocess.run(
            ["chcp"],
            capture_output=True,
            text=True,
            shell=True,
            timeout=3,
        )
        parts = result.stdout.strip().split(":")
        if len(parts) >= 2:
            return int(parts[-1].strip().rstrip("."))
    except Exception:
        pass

    return 65001


_CODE_PAGE_TO_ENCODING = {
    65001: "utf-8",
    936: "gbk",
    950: "big5",
    54936: "gb18030",
    437: "cp437",
    850: "cp850",
    1252: "cp1252",
}


def _code_page_to_encoding(cp: int) -> str:
    return _CODE_PAGE_TO_ENCODING.get(cp, f"cp{cp}")


# ---------------------------------------------------------------------------
# Command wrapping
# ---------------------------------------------------------------------------

_POWERSHELL_UTF8_PREAMBLE = (
    "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; "
    "$OutputEncoding = [System.Text.Encoding]::UTF8; "
)


def _wrap_powershell(command: str, shell_exe: str) -> List[str]:
    """Build an argv that runs *command* inside PowerShell with UTF-8 output."""
    full_command = _POWERSHELL_UTF8_PREAMBLE + command
    return [
        shell_exe,
        "-NoProfile",
        "-NonInteractive",
        "-ExecutionPolicy",
        "Bypass",
        "-Command",
        full_command,
    ]


def _wrap_cmd(command: str) -> List[str]:
    """Build an argv that runs *command* inside ``cmd.exe`` with ``chcp 65001``."""
    full_command = f"chcp 65001 >nul & {command}"
    return ["cmd.exe", "/c", full_command]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def prepare_windows_command(
    command: Union[str, List[str]],
    default_encoding: str = "utf-8",
) -> Tuple[Union[str, List[str]], bool, str]:
    """Wrap *command* for proper Windows execution and return the encoding.

    Parameters
    ----------
    command:
        The original command (string or list).
    default_encoding:
        The encoding that the caller would normally use (ignored on Windows;
        the function computes the correct one).

    Returns
    -------
    (wrapped_command, shell, encoding)
        * *wrapped_command* – an argv list (``shell`` should be ``False``).
        * *shell* – always ``False`` because we specify the shell explicitly.
        * *encoding* – the encoding to use for decoding stdout/stderr.

    If *command* is already a list, it is returned unchanged (we cannot
    safely re-wrap it) and ``shell`` / ``encoding`` remain as passed in.
    """
    if not isinstance(command, str):
        return command, True, default_encoding

    parent_shell = _detect_parent_shell()
    logger.debug(f"Windows parent shell detected: {parent_shell}")

    if parent_shell in ("powershell", "pwsh"):
        shell_exe = "pwsh.exe" if parent_shell == "pwsh" else "powershell.exe"
        wrapped = _wrap_powershell(command, shell_exe)
        return wrapped, False, "utf-8"

    # cmd branch – force chcp 65001 so output is UTF-8
    wrapped = _wrap_cmd(command)
    return wrapped, False, "utf-8"
