"""
Tests for windows_support module.

These tests use mocking so they can run on any platform (macOS, Linux, Windows).
"""

import subprocess
from unittest.mock import patch, MagicMock, PropertyMock

import pytest

from autocoder.common.shell_commands.windows_support import (
    _detect_parent_shell,
    _get_console_code_page,
    _code_page_to_encoding,
    _wrap_powershell,
    _wrap_cmd,
    prepare_windows_command,
    _POWERSHELL_UTF8_PREAMBLE,
)


# ---------------------------------------------------------------------------
# _detect_parent_shell
# ---------------------------------------------------------------------------


def _make_mock_proc(name, pid=100, parent=None):
    proc = MagicMock()
    proc.pid = pid
    proc.name.return_value = name
    proc.parent.return_value = parent
    return proc


class TestDetectParentShell:
    """Tests for parent shell detection."""

    def test_detects_powershell_via_psutil(self):
        mock_proc = _make_mock_proc("powershell.exe")
        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_proc

        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                True,
            ),
            patch(
                "autocoder.common.shell_commands.windows_support.psutil", mock_psutil
            ),
        ):
            result = _detect_parent_shell()
        assert result == "powershell"

    def test_detects_pwsh_via_psutil(self):
        mock_proc = _make_mock_proc("pwsh.exe")
        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_proc

        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                True,
            ),
            patch(
                "autocoder.common.shell_commands.windows_support.psutil", mock_psutil
            ),
        ):
            result = _detect_parent_shell()
        assert result == "pwsh"

    def test_detects_cmd_via_psutil(self):
        mock_proc = _make_mock_proc("cmd.exe")
        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = mock_proc

        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                True,
            ),
            patch(
                "autocoder.common.shell_commands.windows_support.psutil", mock_psutil
            ),
        ):
            result = _detect_parent_shell()
        assert result == "cmd"

    def test_walks_parent_chain(self):
        """Should walk up the parent chain to find the shell."""
        grandparent = _make_mock_proc("powershell.exe", pid=1)
        parent = _make_mock_proc("python.exe", pid=50, parent=grandparent)
        child = _make_mock_proc("python.exe", pid=100, parent=parent)

        mock_psutil = MagicMock()
        mock_psutil.Process.return_value = child

        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                True,
            ),
            patch(
                "autocoder.common.shell_commands.windows_support.psutil", mock_psutil
            ),
        ):
            result = _detect_parent_shell()
        assert result == "powershell"

    def test_falls_back_to_comspec_cmd(self):
        """When psutil is not available and COMSPEC contains cmd.exe."""
        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                False,
            ),
            patch.dict("os.environ", {"COMSPEC": r"C:\Windows\system32\cmd.exe"}),
        ):
            result = _detect_parent_shell()
        assert result == "cmd"

    def test_defaults_to_powershell(self):
        """When nothing else matches, default to powershell."""
        with (
            patch(
                "autocoder.common.shell_commands.windows_support._PSUTIL_AVAILABLE",
                False,
            ),
            patch.dict("os.environ", {"COMSPEC": ""}, clear=False),
        ):
            result = _detect_parent_shell()
        assert result == "powershell"


# ---------------------------------------------------------------------------
# _code_page_to_encoding
# ---------------------------------------------------------------------------


class TestCodePageToEncoding:
    def test_utf8(self):
        assert _code_page_to_encoding(65001) == "utf-8"

    def test_gbk(self):
        assert _code_page_to_encoding(936) == "gbk"

    def test_unknown_code_page(self):
        assert _code_page_to_encoding(12345) == "cp12345"


# ---------------------------------------------------------------------------
# _wrap_powershell / _wrap_cmd
# ---------------------------------------------------------------------------


class TestWrapPowershell:
    def test_basic_wrap(self):
        argv = _wrap_powershell("Get-Process", "powershell.exe")
        assert argv[0] == "powershell.exe"
        assert "-NoProfile" in argv
        assert "-NonInteractive" in argv
        assert "-ExecutionPolicy" in argv
        assert "Bypass" in argv
        assert "-Command" in argv
        cmd_arg = argv[-1]
        assert cmd_arg.startswith("[Console]::OutputEncoding")
        assert "Get-Process" in cmd_arg

    def test_pwsh_wrap(self):
        argv = _wrap_powershell("echo hello", "pwsh.exe")
        assert argv[0] == "pwsh.exe"


class TestWrapCmd:
    def test_basic_wrap(self):
        argv = _wrap_cmd("dir")
        assert argv[0] == "cmd.exe"
        assert argv[1] == "/c"
        assert "chcp 65001" in argv[2]
        assert "dir" in argv[2]


# ---------------------------------------------------------------------------
# prepare_windows_command
# ---------------------------------------------------------------------------


class TestPrepareWindowsCommand:
    def test_powershell_branch(self):
        with patch(
            "autocoder.common.shell_commands.windows_support._detect_parent_shell",
            return_value="powershell",
        ):
            cmd, shell, enc = prepare_windows_command("Stop-Process -Name foo")
        assert shell is False
        assert enc == "utf-8"
        assert isinstance(cmd, list)
        assert cmd[0] == "powershell.exe"
        assert "Stop-Process -Name foo" in cmd[-1]

    def test_pwsh_branch(self):
        with patch(
            "autocoder.common.shell_commands.windows_support._detect_parent_shell",
            return_value="pwsh",
        ):
            cmd, shell, enc = prepare_windows_command("echo hello")
        assert shell is False
        assert enc == "utf-8"
        assert cmd[0] == "pwsh.exe"

    def test_cmd_branch(self):
        with patch(
            "autocoder.common.shell_commands.windows_support._detect_parent_shell",
            return_value="cmd",
        ):
            cmd, shell, enc = prepare_windows_command("dir /b")
        assert shell is False
        assert enc == "utf-8"
        assert cmd[0] == "cmd.exe"
        assert "chcp 65001" in cmd[2]

    def test_list_command_passthrough(self):
        """List commands should not be re-wrapped."""
        original = ["python", "-c", "print('hi')"]
        cmd, shell, enc = prepare_windows_command(original, "gbk")
        assert cmd is original
        assert shell is True
        assert enc == "gbk"


# ---------------------------------------------------------------------------
# Integration: ProcessManager uses prepare_windows_command
# ---------------------------------------------------------------------------


class TestProcessManagerWindowsIntegration:
    """Verify that ProcessManager.create_process calls prepare_windows_command on Windows."""

    @patch("autocoder.common.shell_commands.process_manager.platform")
    @patch("autocoder.common.shell_commands.process_manager.subprocess")
    @patch(
        "autocoder.common.shell_commands.process_manager.prepare_windows_command",
    )
    def test_create_process_calls_wrapper(
        self, mock_prepare, mock_subprocess, mock_platform
    ):
        from autocoder.common.shell_commands.process_manager import ProcessManager
        from autocoder.common.shell_commands.timeout_config import TimeoutConfig

        mock_platform.system.return_value = "Windows"
        mock_prepare.return_value = (
            ["powershell.exe", "-Command", "echo hi"],
            False,
            "utf-8",
        )

        mock_process = MagicMock()
        mock_process.pid = 999
        mock_subprocess.Popen.return_value = mock_process
        mock_subprocess.PIPE = subprocess.PIPE
        mock_subprocess.CREATE_NEW_PROCESS_GROUP = 0x00000200

        pm = ProcessManager(TimeoutConfig())
        pm.create_process("echo hi")

        mock_prepare.assert_called_once()
        call_args = mock_subprocess.Popen.call_args
        assert call_args[0][0] == ["powershell.exe", "-Command", "echo hi"]
        assert call_args[1]["shell"] is False
        assert call_args[1]["encoding"] == "utf-8"

    @patch("autocoder.common.shell_commands.process_manager.platform")
    @patch("autocoder.common.shell_commands.process_manager.subprocess")
    @patch(
        "autocoder.common.shell_commands.process_manager.prepare_windows_command",
    )
    def test_create_background_process_calls_wrapper(
        self, mock_prepare, mock_subprocess, mock_platform
    ):
        from autocoder.common.shell_commands.process_manager import ProcessManager
        from autocoder.common.shell_commands.timeout_config import TimeoutConfig

        mock_platform.system.return_value = "Windows"
        mock_prepare.return_value = (
            ["cmd.exe", "/c", "chcp 65001 >nul & dir"],
            False,
            "utf-8",
        )

        mock_process = MagicMock()
        mock_process.pid = 888
        mock_process.stdout = None
        mock_process.stderr = None
        mock_subprocess.Popen.return_value = mock_process
        mock_subprocess.PIPE = subprocess.PIPE
        mock_subprocess.CREATE_NEW_PROCESS_GROUP = 0x00000200

        pm = ProcessManager(TimeoutConfig())
        pm.create_background_process("dir")

        mock_prepare.assert_called_once()
        call_args = mock_subprocess.Popen.call_args
        assert call_args[0][0] == ["cmd.exe", "/c", "chcp 65001 >nul & dir"]
        assert call_args[1]["shell"] is False
        assert call_args[1]["encoding"] == "utf-8"

    @patch("autocoder.common.shell_commands.process_manager.platform")
    @patch("autocoder.common.shell_commands.process_manager.subprocess.Popen")
    def test_non_windows_unchanged(self, mock_popen, mock_platform):
        from autocoder.common.shell_commands.process_manager import ProcessManager
        from autocoder.common.shell_commands.timeout_config import TimeoutConfig

        mock_platform.system.return_value = "Linux"

        mock_process = MagicMock()
        mock_process.pid = 777
        mock_popen.return_value = mock_process

        pm = ProcessManager(TimeoutConfig())
        pm.create_process("echo hello", shell=True, encoding="utf-8")

        call_args = mock_popen.call_args
        assert call_args[0][0] == "echo hello"
        assert call_args[1]["shell"] is True
        assert call_args[1]["encoding"] == "utf-8"
