"""Compatibility utilities for stock_id → symbol migration.

This module is the single source of truth for all identifier migration logic.
Both ``stock_id`` and ``symbol`` are accepted silently (no deprecation warnings).
A ``ValueError`` is raised whenever both names appear in the same context.
"""

from __future__ import annotations

import functools
import inspect
from typing import Any, Dict, Optional

import pandas as pd

CANONICAL_NAME = "symbol"
LEGACY_NAME = "stock_id"


# ---------------------------------------------------------------------------
# DataFrame helpers
# ---------------------------------------------------------------------------

def validate_no_dual_columns(df: pd.DataFrame) -> None:
    """Raise ``ValueError`` if *both* 'symbol' and 'stock_id' exist as columns or index levels."""
    names = set()
    if isinstance(df.columns, pd.MultiIndex):
        names.update(df.columns.names)
    else:
        names.update(df.columns.tolist())
    if isinstance(df.index, pd.MultiIndex):
        names.update(df.index.names)
    else:
        if df.index.name is not None:
            names.add(df.index.name)
    if CANONICAL_NAME in names and LEGACY_NAME in names:
        raise ValueError(
            f"DataFrame contains both '{CANONICAL_NAME}' and '{LEGACY_NAME}'. "
            "Please use only one identifier name."
        )


def resolve_id_column(df: pd.DataFrame) -> str:
    """Return whichever column name (``'symbol'`` or ``'stock_id'``) is present.

    Prefers ``'symbol'``.  Returns ``'symbol'`` if neither is found.
    """
    cols = set(df.columns.tolist())
    if CANONICAL_NAME in cols:
        return CANONICAL_NAME
    if LEGACY_NAME in cols:
        return LEGACY_NAME
    return CANONICAL_NAME


def normalize_id_column(df: pd.DataFrame) -> pd.DataFrame:
    """Silently rename the ``'stock_id'`` column to ``'symbol'`` if present."""
    if LEGACY_NAME in df.columns and CANONICAL_NAME not in df.columns:
        df = df.rename(columns={LEGACY_NAME: CANONICAL_NAME})
    return df


def normalize_index_name(df: pd.DataFrame) -> pd.DataFrame:
    """Silently rename the index name from ``'stock_id'`` to ``'symbol'``."""
    if isinstance(df.index, pd.MultiIndex):
        new_names = [
            CANONICAL_NAME if n == LEGACY_NAME else n for n in df.index.names
        ]
        df.index.names = new_names
    else:
        if df.index.name == LEGACY_NAME:
            df.index.name = CANONICAL_NAME
    return df


# ---------------------------------------------------------------------------
# Function parameter helpers
# ---------------------------------------------------------------------------

def resolve_symbol_param(
    symbol: Optional[str] = None,
    stock_id: Optional[str] = None,
) -> Optional[str]:
    """Resolve dual kwargs — raise if both are given."""
    if symbol is not None and stock_id is not None:
        raise ValueError(
            "Cannot specify both 'symbol' and 'stock_id'. Use 'symbol' only."
        )
    return symbol if symbol is not None else stock_id


def param_alias(old: str = "stock_id", new: str = "symbol"):
    """Decorator that silently accepts the *old* kwarg name as an alias for *new*.

    If both are passed, ``ValueError`` is raised.
    """
    def decorator(fn):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            if old in kwargs:
                if new in kwargs:
                    raise ValueError(
                        f"Cannot specify both '{new}' and '{old}'. "
                        f"Use '{new}' only."
                    )
                kwargs[new] = kwargs.pop(old)
            return fn(*args, **kwargs)
        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Dict helpers (for position dicts, order dicts, etc.)
# ---------------------------------------------------------------------------

def get_symbol(d: Dict[str, Any]) -> Any:
    """Get the identifier value from a dict that may use either key."""
    if CANONICAL_NAME in d:
        return d[CANONICAL_NAME]
    return d.get(LEGACY_NAME)


def normalize_position_dict(d: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure a position dict carries **both** ``'symbol'`` and ``'stock_id'`` keys.

    If both keys exist with *different* values, ``ValueError`` is raised.
    """
    has_new = CANONICAL_NAME in d
    has_old = LEGACY_NAME in d
    if has_new and has_old:
        if d[CANONICAL_NAME] != d[LEGACY_NAME]:
            raise ValueError(
                f"Position dict has conflicting identifiers: "
                f"symbol={d[CANONICAL_NAME]!r}, stock_id={d[LEGACY_NAME]!r}"
            )
        return d
    if has_new:
        d[LEGACY_NAME] = d[CANONICAL_NAME]
    elif has_old:
        d[CANONICAL_NAME] = d[LEGACY_NAME]
    return d
