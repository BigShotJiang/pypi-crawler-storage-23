import random
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Callable, List, Optional

import numpy as np
import pandas as pd

import finlab.backtest as _backtest_module
from finlab import data as _data_module


@contextmanager
def _sandbox():
    """Temporarily suppress uploads and restore truncate_end on exit."""
    saved = _data_module.truncate_end
    _backtest_module._suppress_upload = True
    try:
        yield
    finally:
        _data_module.truncate_end = saved
        _backtest_module._suppress_upload = False

_MISMATCH_COLS = ['symbol', 'column', 'full_value', 'truncated_value']
_COMPARE_COLS = ['exit_date', 'exit_sig_date', 'return', 'position']


@dataclass
class VerifyResult:
    """Result of ``verify_strategy``."""
    passed: bool
    n_tests: int
    n_passed: int
    n_failed: int
    summary_df: pd.DataFrame = field(repr=False)
    details: list = field(repr=False)


def _empty_result(verbose: bool, message: str) -> VerifyResult:
    """Return a trivially-passing VerifyResult with no test data."""
    if verbose:
        print(message)
    return VerifyResult(
        passed=True, n_tests=0, n_passed=0, n_failed=0,
        summary_df=pd.DataFrame(), details=[],
    )


def verify_strategy(
    strategy: Callable,
    n_tests: int = 5,
    test_dates: Optional[List[str]] = None,
    verbose: bool = True,
) -> VerifyResult:
    """Detect lookahead bias by comparing trades at historical truncation points.

    The *strategy* callable should build positions **and** call ``sim()``
    internally, returning the :class:`~finlab.core.report.Report`::

        def my_strategy():
            close = data.get('price:收盤價')
            pos = (close == close.rolling(20).max())
            return sim(pos, resample='M')

        result = verify_strategy(my_strategy)

    Args:
        strategy: Zero-arg callable that returns a ``Report`` (the return
            value of ``sim()``).
        n_tests: Number of random truncation dates to test (default 5).
        test_dates: Explicit date strings to include in addition to the
            random sample.
        verbose: Print progress and summary to stdout.
    """
    with _sandbox():
        # -- Step 1: full-data reference run --
        report_full = strategy()
        trades_full = report_full.trades.copy()

        # -- Step 2: candidate dates from completed trades --
        completed = trades_full[trades_full['exit_date'].notna()]
        if completed.empty:
            return _empty_result(verbose,
                                 "No completed trades — nothing to verify.")

        candidates = sorted(
            pd.to_datetime(completed['exit_date']).dt.normalize().unique())
        # Drop last 2 dates (too close to series end to be meaningful)
        candidates = candidates[:-2] if len(candidates) > 2 else candidates

        if not candidates:
            return _empty_result(
                verbose,
                "No suitable candidate dates found for verification.")

        # -- Step 3: select test dates --
        explicit = {pd.Timestamp(d) for d in test_dates} if test_dates else set()
        remaining = [d for d in candidates if d not in explicit]
        n_random = max(0, n_tests - len(explicit))
        sampled = random.sample(remaining, min(n_random, len(remaining)))
        selected = sorted(explicit | set(sampled))

        if verbose:
            print(f"Verifying strategy consistency across "
                  f"{len(selected)} dates...")

        # -- Step 4: run truncated backtests and compare --
        summary_rows: list = []
        details: list = []

        for idx, test_date in enumerate(selected):
            label = f"[{idx + 1}/{len(selected)}] {test_date:%Y-%m-%d}"
            try:
                _data_module.truncate_end = f"{test_date:%Y-%m-%d}"
                report_t = strategy()
                trades_t = report_t.trades.copy()

                mismatches = _compare_trades(trades_full, trades_t)
                n_checked = int(trades_t['exit_date'].notna().sum())
                n_mismatch = len(mismatches)
                passed = n_mismatch == 0

            except Exception as e:
                summary_rows.append({
                    'test_date': test_date,
                    'trades_checked': 0,
                    'mismatches': 0,
                    'passed': False,
                })
                details.append({
                    'test_date': test_date,
                    'mismatches': pd.DataFrame(),
                    'error': str(e),
                })
                if verbose:
                    print(f"  {label}: ERROR — {e}")
                continue

            summary_rows.append({
                'test_date': test_date,
                'trades_checked': n_checked,
                'mismatches': n_mismatch,
                'passed': passed,
            })
            details.append({
                'test_date': test_date,
                'mismatches': mismatches,
                'error': None,
            })

            if verbose:
                status = ("PASSED" if passed
                          else f"FAILED ({n_mismatch} mismatches)")
                print(f"  {label}: {n_checked} trades checked — {status}")
                if not passed and not mismatches.empty:
                    for _, row in mismatches.head(5).iterrows():
                        print(
                            f"    - {row['symbol']}: {row['column']} "
                            f"differs ({row['full_value']} vs "
                            f"{row['truncated_value']})")

        summary_df = pd.DataFrame(summary_rows)
        n_passed = int(summary_df['passed'].sum())
        n_failed = len(summary_df) - n_passed

        if verbose:
            print(f"\nResult: {n_passed}/{len(summary_df)} PASSED, "
                  f"{n_failed}/{len(summary_df)} FAILED")

        return VerifyResult(
            passed=(n_failed == 0),
            n_tests=len(summary_df),
            n_passed=n_passed,
            n_failed=n_failed,
            summary_df=summary_df,
            details=details,
        )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _base_id(df: pd.DataFrame) -> pd.Series:
    """Extract base symbol (strip name suffix) for merge keys."""
    col = 'symbol' if 'symbol' in df.columns else 'stock_id'
    return df[col].astype(str).str.split(' ').str[0]


def _series_differ(a: pd.Series, b: pd.Series) -> pd.Series:
    """Vectorized comparison: True where values meaningfully differ."""
    a_na, b_na = a.isna(), b.isna()
    both_present = ~a_na & ~b_na
    # One NA, one not → different
    differ = a_na ^ b_na
    if both_present.any():
        ap, bp = a[both_present], b[both_present]
        if (pd.api.types.is_numeric_dtype(a)
                and pd.api.types.is_numeric_dtype(b)):
            differ.loc[both_present] = ~np.isclose(
                ap.astype(float), bp.astype(float), rtol=1e-5)
        else:
            differ.loc[both_present] = ap != bp
    return differ


def _compare_trades(trades_full: pd.DataFrame,
                    trades_trunc: pd.DataFrame,
                    columns: Optional[list] = None) -> pd.DataFrame:
    """Compare closed trades from a truncated run against the full run."""
    if trades_trunc.empty or trades_full.empty:
        return pd.DataFrame(columns=_MISMATCH_COLS)

    closed = trades_trunc[trades_trunc['exit_date'].notna()]
    if closed.empty:
        return pd.DataFrame(columns=_MISMATCH_COLS)

    compare_cols = columns if columns is not None else _COMPARE_COLS
    compare_cols = [c for c in compare_cols
                    if c in trades_full.columns and c in closed.columns]

    full = (trades_full.assign(_key=_base_id(trades_full))
            .drop_duplicates(subset=['_key', 'entry_date'], keep='first'))
    trunc = closed.assign(_key=_base_id(closed))

    merged = trunc.merge(
        full[['_key', 'entry_date'] + compare_cols],
        on=['_key', 'entry_date'],
        how='left',
        suffixes=('_trunc', '_full'),
        indicator=True,
    )

    parts = []

    # Phantom trades: present in truncated but missing in full run
    if columns is None:
        missing = merged.loc[merged['_merge'] == 'left_only']
        if not missing.empty:
            _id_col = 'symbol' if 'symbol' in missing.columns else 'stock_id'
            parts.append(pd.DataFrame({
                'symbol': missing[_id_col].values,
                'column': '(missing in full run)',
                'full_value': None,
                'truncated_value': None,
            }))

    # Column-level mismatches on matched trades
    matched = merged[merged['_merge'] == 'both']
    if not matched.empty:
        for col in compare_cols:
            diff = _series_differ(
                matched[f'{col}_trunc'], matched[f'{col}_full'])
            if diff.any():
                m = matched.loc[diff]
                _id_col = 'symbol' if 'symbol' in m.columns else 'stock_id'
                parts.append(pd.DataFrame({
                    'symbol': m[_id_col].values,
                    'column': col,
                    'full_value': m[f'{col}_full'].values,
                    'truncated_value': m[f'{col}_trunc'].values,
                }))

    if not parts:
        return pd.DataFrame(columns=_MISMATCH_COLS)
    return pd.concat(parts, ignore_index=True)[_MISMATCH_COLS]
