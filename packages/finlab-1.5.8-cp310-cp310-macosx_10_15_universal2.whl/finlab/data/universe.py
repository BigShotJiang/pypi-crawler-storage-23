import re
import pandas as pd
from typing import Optional, Union, List, Type, cast
from types import TracebackType

# Shared universe state used to filter datasets
universe_stocks = set()


def _match_categories_by_regex(all_values: set, patterns: Union[str, List[str]]) -> set:
    """Match values from a set using regex patterns.

    Args:
        all_values: Set of all possible values to match against
        patterns: Single pattern or list of patterns for regex matching

    Returns:
        Set of matched values
    """
    if isinstance(patterns, str):
        patterns = [patterns]
    matched = set()
    for pattern in patterns:
        matched |= {v for v in all_values if isinstance(v, str) and re.search(pattern, v)}
    return matched


def _resolve_sector_alias(new_val, legacy_val):
    """Pick *sector* (new) or *category* (legacy). Raise if both are given."""
    if legacy_val is not None and new_val is not None and new_val != 'ALL':
        raise ValueError("Cannot specify both 'sector' and 'category'. Use 'sector' only.")
    if legacy_val is not None:
        return legacy_val
    return new_val


class universe():
    """Context manager to set a global stock universe filter for data retrieval.

    This context manager limits the set of stocks returned by functions such as
    `finlab.data.get(...)` and `finlab.data.indicator(...)` to a specific market
    and sector selection. The filter is applied globally within the context and
    is restored after the context exits.

    Parameters
    ----------
    market : str, default 'ALL'
        Market scope to include. Supported values:
        - 'ALL': no market filter
        - 'TSE': TWSE (sii)
        - 'OTC': TPEx (otc)
        - 'TSE_OTC': include both TWSE and TPEx
        - 'ETF': exchange-traded funds
        - 'STOCK_FUTURE': underlying of single-stock futures/equity options

    sector : str | list[str], default 'ALL'
        Sector name(s) to include. Supports regex-like substring matching.
        For example, '電子' will match '電子工業', '電子通路業', etc. When a list is
        provided, the union of all matched sectors is included.
        (Also accepts the legacy name ``category``.)

    exclude_sector : str | list[str] | None, default None
        Sector name(s) to exclude from the resulting universe. Also supports
        regex-like substring matching. When None, no exclusion is applied.
        (Also accepts the legacy name ``exclude_category``.)

    Notes
    -----
    - The filter is applied to the internal `universe_stocks` set, which is then
      used by the data processing pipeline to select columns/rows corresponding to
      the chosen stocks.
    - Inside the context, calls to `data.get(...)` will return data limited to the
      specified universe whenever applicable.
    - After exiting the `with` block, the previous universe is restored.

    Examples
    --------
    Limit to TSE/OTC and include only specific sectors:

    >>> from finlab import data
    >>> with data.universe(market='TSE_OTC', sector=['鋼鐵工業', '航運業']):
    ...     close = data.get('price:收盤價')

    Include sectors but exclude financial-related stocks:

    >>> from finlab import data
    >>> with data.universe('TSE_OTC', ['鋼鐵工業', '航運業'], exclude_sector=['金融']):
    ...     close = data.get('price:收盤價')

    Equivalent global (non-context) usage:

    >>> from finlab import data
    >>> data.set_universe(market='TSE_OTC', sector='水泥', exclude_sector='ETF')
    >>> close = data.get('price:收盤價')
    """
    def __init__(
        self,
        market: str = 'ALL',
        sector: Union[str, List[str]] = 'ALL',
        exclude_sector: Optional[Union[str, List[str]]] = None,
        # Legacy aliases
        category: Union[str, List[str]] = None,
        exclude_category: Optional[Union[str, List[str]]] = None,
    ) -> None:
        self._market = market
        self._sector = _resolve_sector_alias(sector, category)
        self._exclude_sector = _resolve_sector_alias(exclude_sector, exclude_category)
        self._previous_stocks = set()

    def __enter__(self):
        global universe_stocks
        self._previous_stocks = universe_stocks
        set_universe(self._market, self._sector, self._exclude_sector)
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        global universe_stocks
        universe_stocks = self._previous_stocks


def set_universe(
    market: str = 'ALL',
    sector: Union[str, List[str]] = 'ALL',
    exclude_sector: Optional[Union[str, List[str]]] = None,
    # Legacy aliases
    category: Union[str, List[str]] = None,
    exclude_category: Optional[Union[str, List[str]]] = None,
) -> None:
    sector = _resolve_sector_alias(sector, category)
    exclude_sector = _resolve_sector_alias(exclude_sector, exclude_category)

    from . import data as data_module

    from finlab.compat import resolve_id_column
    _cats = data_module.get('security_categories').reset_index()
    categories = _cats.set_index(resolve_id_column(_cats))

    market_match = pd.Series(True, categories.index)

    if 'TSE' in market and 'OTC' in market:
        market = 'TSE_OTC'

    if market == 'ALL':
        pass
    elif market == 'TSE':
        market_match = categories.market == 'sii'
    elif market == 'OTC':
        market_match = categories.market == 'otc'
    elif market == 'TSE_OTC':
        market_match = (categories.market == 'sii') | (categories.market == 'otc')
    elif market == 'ETF':
        market_match = categories.market == 'etf'
    elif market == 'STOCK_FUTURE':
        def _get_sf_ids(df):
            col = resolve_id_column(df) if resolve_id_column(df) in df.columns else 'stock_id'
            return set(df[col])
        market_match = data_module.get('single_stock_futures_and_equity_options_underlying')\
            .pipe(lambda df: df[df['是否為股票期貨標的'] == 'Y'])\
            .pipe(lambda df: pd.Series(True, _get_sf_ids(df)).reindex(categories.index).fillna(False))

    sector_match = pd.Series(True, categories.index)
    if sector != 'ALL':
        all_sectors = set(categories.category)
        matched_sectors = _match_categories_by_regex(all_sectors, sector)
        sector_match = categories.category.isin(list(matched_sectors))

    exclude_match = pd.Series(True, categories.index)
    if exclude_sector is not None:
        all_sectors = set(categories.category)
        matched_excluded = _match_categories_by_regex(all_sectors, exclude_sector)
        # Exclude by category names
        exclude_by_sector = ~categories.category.isin(list(matched_excluded))
        # Special-case: if excluding 'ETF', also exclude market == 'etf'
        exclude_by_market = pd.Series(True, categories.index)
        exclude_list = [exclude_sector] if isinstance(exclude_sector, str) else exclude_sector
        if any(isinstance(ca, str) and ca.strip().lower() == 'etf' for ca in exclude_list):
            exclude_by_market = categories.market != 'etf'
        exclude_match = exclude_by_sector & exclude_by_market

    global universe_stocks
    universe_stocks = set(categories.index[market_match & sector_match & exclude_match])


class us_universe:
    """Context manager to set a global stock universe filter for US market data retrieval.

    This context manager limits the set of US stocks returned by data functions to a specific
    sector, industry, and exchange selection. The filter is applied globally
    within the context and is restored after the context exits.

    Parameters
    ----------
    sector : str | list[str], default 'ALL'
        Sector name(s) to include. Supports regex-like substring matching.
        For example, 'Technology' will match 'Technology' sector.
        When a list is provided, the union of all matched sectors is included.

    industry : str | list[str], default 'ALL'
        Industry name(s) to include. Supports regex-like substring matching.
        For example, 'Software' will match 'Software - Application', 'Software - Infrastructure', etc.
        When a list is provided, the union of all matched industries is included.

    exchange : str | list[str], default 'ALL'
        Exchange name(s) to include. Common values: 'NASDAQ', 'NYSE', 'AMEX'.
        When a list is provided, stocks from any of the listed exchanges are included.

    Notes
    -----
    - The filter modifies the global `universe_stocks` set used by the data processing pipeline.
    - Uses ``us_company_profile`` as the metadata source.

    Examples
    --------
    Limit to NASDAQ Technology stocks:

    >>> from finlab import data
    >>> with data.us_universe(sector='Technology', exchange='NASDAQ'):
    ...     close = data.get('us_price:close')

    Include stocks on major exchanges:

    >>> from finlab import data
    >>> with data.us_universe(exchange=['NASDAQ', 'NYSE']):
    ...     close = data.get('us_price:close')
    """
    def __init__(
        self,
        sector: Union[str, List[str]] = 'ALL',
        industry: Union[str, List[str]] = 'ALL',
        exchange: Union[str, List[str]] = 'ALL',
    ) -> None:
        self._sector = sector
        self._industry = industry
        self._exchange = exchange
        self._previous_stocks = set()

    def __enter__(self):
        global universe_stocks
        self._previous_stocks = universe_stocks
        set_us_universe(
            self._sector,
            self._industry,
            self._exchange,
        )
        return self

    def __exit__(
        self,
        exc_type: Optional[Type[BaseException]],
        value: Optional[BaseException],
        traceback: Optional[TracebackType],
    ) -> None:
        global universe_stocks
        universe_stocks = self._previous_stocks


def set_us_universe(
    sector: Union[str, List[str]] = 'ALL',
    industry: Union[str, List[str]] = 'ALL',
    exchange: Union[str, List[str]] = 'ALL',
) -> None:
    """Set global US stock universe filter.

    This function updates the global `universe_stocks` set to limit data retrieval
    to a specific subset of US stocks based on sector, industry, and exchange.
    Uses ``us_company_profile`` as the metadata source.

    Parameters
    ----------
    sector : str | list[str], default 'ALL'
        Sector filter with regex-like substring matching.
    industry : str | list[str], default 'ALL'
        Industry filter with regex-like substring matching.
    exchange : str | list[str], default 'ALL'
        Exchange filter (e.g., 'NASDAQ', 'NYSE', 'AMEX').
    """
    from . import data as data_module

    profile = data_module.get('us_company_profile').set_index('symbol')

    # Sector/industry filtering using shared helper
    def match_column(column: str, patterns: Union[str, List[str]]) -> pd.Series:
        if patterns == 'ALL':
            return pd.Series(True, profile.index)
        all_values = set(profile[column].dropna())
        matched = _match_categories_by_regex(all_values, patterns)
        return cast(pd.Series, profile[column].isin(list(matched)))

    sector_match = match_column('sector', sector)
    industry_match = match_column('industry', industry)

    # Exchange filter
    exchange_match = pd.Series(True, profile.index)
    if exchange != 'ALL':
        if isinstance(exchange, str):
            exchange = [exchange]
        exchange_match = profile.exchange.isin(exchange)

    global universe_stocks
    universe_stocks = set(profile.index[
        sector_match &
        industry_match &
        exchange_match
    ])


not_available_universe_stocks = [
    'benchmark_return', 'institutional_investors_trading_all_market_summary',
    'margin_balance', 'intraday_trading_stat',
    'stock_index_price', 'stock_index_vol',
    'taiex_total_index', 'broker_info',
    'rotc_monthly_revenue', 'rotc_price',
    'world_index', 'rotc_broker_trade_record',
    'security_categories', 'finlab_tw_stock_market_ind',
    'tw_industry_pmi', 'tw_industry_nmi',
    'tw_total_pmi', 'tw_total_nmi',
    'tw_business_indicators', 'tw_business_indicators_details',
    'tw_monetary_aggregates', 'us_unemployment_rate_seasonally_adjusted',
    'us_company_profile',
]


def refine_stock_id(dataset: str, ret: pd.DataFrame) -> pd.DataFrame:
    from .data import process_data  # lazy import to avoid circular dependency
    from finlab.compat import resolve_id_column

    ret = process_data(dataset, ret)

    if dataset in not_available_universe_stocks:
        return ret

    if not universe_stocks:
        return ret

    if ':' in dataset:
        subset_stocks = [c for c in ret.columns if c in universe_stocks]
        if len(subset_stocks) > 0:
            return ret.loc[:, subset_stocks]

    id_col = resolve_id_column(ret)
    if id_col in ret.columns:
        subset_stocks = ret[id_col].isin(list(universe_stocks))
        if bool(subset_stocks.any()):
            return ret.loc[subset_stocks]

    return ret


refine_symbols = refine_stock_id



