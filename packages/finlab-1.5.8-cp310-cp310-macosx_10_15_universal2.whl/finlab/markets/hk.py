import datetime
import pandas as pd
from finlab import data
from finlab.market import Market


class HKMarket(Market):
    """Hong Kong stock market (HKEX)."""

    @staticmethod
    def get_freq():
        return '1d'

    @staticmethod
    def get_name():
        return 'hk_stock'

    @staticmethod
    def get_benchmark():
        return data.get('world_index:adj_close')['^HSI']

    @staticmethod
    def get_asset_id_to_name():
        try:
            from finlab.compat import resolve_id_column
            tickers = data.get('hk_tickers')
            return dict(zip(tickers[resolve_id_column(tickers)], tickers['name']))
        except Exception:
            return {}

    def get_price(self, trade_at_price, adj=True):
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            if trade_at_price == 'volume':
                return data.get('hk_price:volume')

            if adj:
                table_name = 'etl:hk_adj_'
            else:
                table_name = 'hk_price:'

            return data.get(f'{table_name}{trade_at_price}')

        raise ValueError('trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str).')

    def market_close_at_timestamp(self, timestamp=None):
        if timestamp is None:
            timestamp = self.get_price('close').index[-1]

        if timestamp.tzinfo is None or timestamp.tzinfo.utcoffset(timestamp) is None:
            timestamp = timestamp.tz_localize('Asia/Hong_Kong')

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta('16:00:00')
        return market_close.tz_localize('Asia/Hong_Kong')

    @staticmethod
    def market_open_time() -> tuple:
        return (9, 30)

    @staticmethod
    def tzinfo():
        return datetime.timezone(datetime.timedelta(hours=8))
