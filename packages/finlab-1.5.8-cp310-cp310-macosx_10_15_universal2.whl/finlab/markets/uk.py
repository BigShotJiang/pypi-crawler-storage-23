import datetime
import pandas as pd
from finlab import data
from finlab.market import Market


class UKMarket(Market):
    """UK stock market (LSE)."""

    @staticmethod
    def get_freq():
        return '1d'

    @staticmethod
    def get_name():
        return 'uk_stock'

    @staticmethod
    def get_benchmark():
        return data.get('world_index:adj_close')['^FTSE']

    @staticmethod
    def get_asset_id_to_name():
        try:
            from finlab.compat import resolve_id_column
            tickers = data.get('uk_tickers')
            return dict(zip(tickers[resolve_id_column(tickers)], tickers['name']))
        except Exception:
            return {}

    def get_price(self, trade_at_price, adj=True):
        if isinstance(trade_at_price, pd.Series):
            return trade_at_price.to_frame()

        if isinstance(trade_at_price, pd.DataFrame):
            return trade_at_price

        if isinstance(trade_at_price, str):
            if trade_at_price == 'volume':
                return data.get('uk_price:volume')

            if adj:
                table_name = 'etl:uk_adj_'
            else:
                table_name = 'uk_price:'

            return data.get(f'{table_name}{trade_at_price}')

        raise ValueError('trade_at_price is not allowed (accepted types: pd.DataFrame, pd.Series, str).')

    def market_close_at_timestamp(self, timestamp=None):
        if timestamp is None:
            timestamp = self.get_price('close').index[-1]

        if timestamp.tzinfo is None or timestamp.tzinfo.utcoffset(timestamp) is None:
            timestamp = timestamp.tz_localize('Europe/London')

        market_close = pd.Timestamp(timestamp.date()) + pd.Timedelta('16:30:00')
        return market_close.tz_localize('Europe/London')

    @staticmethod
    def market_open_time() -> tuple:
        return (8, 0)

    @staticmethod
    def tzinfo():
        return datetime.timezone.utc
