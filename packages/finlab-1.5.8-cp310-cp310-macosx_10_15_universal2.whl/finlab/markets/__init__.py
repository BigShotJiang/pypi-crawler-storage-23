from finlab.market import Market
from .tw import TWMarket
from .us import USMarket
from .rotc import ROTCMarket
from .hk import HKMarket
from .jp import JPMarket
from .kr import KRMarket
from .uk import UKMarket

_MARKET_NAME_TO_CLASS = {
    'tw_stock': TWMarket,
    'us_stock': USMarket,
    'rotc_stock': ROTCMarket,
    'hk_stock': HKMarket,
    'jp_stock': JPMarket,
    'kr_stock': KRMarket,
    'uk_stock': UKMarket,
}

# Mapping from short market code (used by data.set_market) to Market class
MARKET_CODE_TO_CLASS = {
    'tw': TWMarket,
    'us': USMarket,
    'hk': HKMarket,
    'jp': JPMarket,
    'kr': KRMarket,
    'uk': UKMarket,
}

def get_market_by_name(name:str) -> Market:
    cls = _MARKET_NAME_TO_CLASS.get(name.lower())
    if cls is None:
        raise ValueError(f'Unknown market name: {name!r}')
    return cls()