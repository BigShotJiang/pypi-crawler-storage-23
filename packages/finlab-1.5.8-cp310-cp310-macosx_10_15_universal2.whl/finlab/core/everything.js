var __defProp = Object.defineProperty;
var __typeError = (msg) => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), setter ? setter.call(obj, value) : member.set(obj, value), value);
var _a2, _t2, _e3, _b2, _c2, _d2, _e2, _f2;
const t = ["en", "zh-tw"], e = "PARAGLIDE_LOCALE", i = "PARAGLIDE_LOCALE", s = ["localStorage", "cookie", "preferredLanguage", "baseLocale"];
globalThis.__paraglide = {};
let n = false, r = () => {
  let t2;
  for (const e2 of s) if ("cookie" === e2 ? t2 = c() : "baseLocale" === e2 ? t2 = "zh-tw" : "preferredLanguage" === e2 ? t2 = o() : "localStorage" === e2 && (t2 = localStorage.getItem(i) ?? void 0), void 0 !== t2) {
    const e3 = h(t2);
    return n || (n = true, a(e3, { reload: false })), e3;
  }
  throw new Error("No locale found. Read the docs https://inlang.com/m/gerre34r/library-inlang-paraglideJs/errors#no-locale-found");
};
function o() {
  var _a3;
  if (!((_a3 = navigator == null ? void 0 : navigator.languages) == null ? void 0 : _a3.length)) return;
  const t2 = navigator.languages.map((t3) => {
    var _a4;
    return { fullTag: t3.toLowerCase(), baseTag: (_a4 = t3.split("-")[0]) == null ? void 0 : _a4.toLowerCase() };
  });
  for (const e2 of t2) {
    if (l(e2.fullTag)) return e2.fullTag;
    if (l(e2.baseTag)) return e2.baseTag;
  }
}
let a = (t2, n2) => {
  const o2 = { reload: true, ...n2 };
  let a2;
  try {
    a2 = r();
  } catch {
  }
  for (const n3 of s) if ("cookie" === n3) {
    if ("undefined" == typeof document || "undefined" == typeof window) continue;
    const i2 = window.location.hostname;
    document.cookie = `${e}=${t2}; path=/; max-age=34560000; domain=${i2}`;
  } else {
    if ("baseLocale" === n3) continue;
    "localStorage" === n3 && "undefined" != typeof window && localStorage.setItem(i, t2);
  }
  o2.reload && window.location && t2 !== a2 && window.location.reload();
};
function l(e2) {
  return !!e2 && t.includes(e2);
}
function h(e2) {
  if (false === l(e2)) throw new Error(`Invalid locale: ${e2}. Expected one of: ${t.join(", ")}`);
  return e2;
}
function c() {
  if ("undefined" == typeof document || !document.cookie) return;
  const t2 = document.cookie.match(new RegExp(`(^| )${e}=([^;]+)`)), i2 = t2 == null ? void 0 : t2[2];
  return l(i2) ? i2 : void 0;
}
const u = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Redefine Investing with Science" : "zh-tw" === i2 ? "用科學，重新定義投資" : "title";
}, d = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Let data guide your investments — no more guessing!" : "zh-tw" === i2 ? "數據為你導航，投資不再憑運氣！" : "subtitle";
}, f = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Get Started" : "zh-tw" === i2 ? "開始使用" : "actionButton";
}, p = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy" : "zh-tw" === i2 ? "策略" : "strategy";
}, m = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Benchmark" : "zh-tw" === i2 ? "大盤" : "benchmark";
}, g = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average" : "zh-tw" === i2 ? "平均" : "average";
}, v = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Historical Return" : "zh-tw" === i2 ? "歷史績效" : "profitability_historicalReturn";
}, b = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stock List" : "zh-tw" === i2 ? "持股報酬" : "profitability_stockList";
}, _ = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monthly Return" : "zh-tw" === i2 ? "月報酬" : "profitability_monthlyReturn";
}, y = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monthly Win Rate" : "zh-tw" === i2 ? "月勝率" : "profitability_monthlyWinRatio";
}, w = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Avg Monthly Return" : "zh-tw" === i2 ? "平均月報酬" : "profitability_avgMonthlyReturn";
}, x = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly vs Benchmark" : "zh-tw" === i2 ? "與大盤年報酬比較" : "profitability_YearlyCompareWithBenchmark";
}, k = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Beat Benchmark" : "zh-tw" === i2 ? "贏大盤" : "profitability_yearlyWinRate";
}, S = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Excess Return" : "zh-tw" === i2 ? "超額報酬" : "profitability_exceedReturn";
}, M = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown Depth" : "zh-tw" === i2 ? "回檔幅度" : "risk_drawdownPercentage";
}, z = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown Periods" : "zh-tw" === i2 ? "虧損歷史" : "risk_drawdowPeriods";
}, C = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Profitability" : "zh-tw" === i2 ? "獲利能力" : "tabs_profitability";
}, R = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Risk" : "zh-tw" === i2 ? "抗風險能力" : "tabs_risk";
}, P = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Risk/Reward" : "zh-tw" === i2 ? "風險報酬比" : "tabs_ratio";
}, T = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Win Rate" : "zh-tw" === i2 ? "勝率期望值" : "tabs_winrate";
}, E = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Liquidity" : "zh-tw" === i2 ? "交易流動性" : "tabs_liquidity";
}, A = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Start Date" : "zh-tw" === i2 ? "開始日期" : "metrics_backtest_startDate";
}, L = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "End Date" : "zh-tw" === i2 ? "結束日期" : "metrics_backtest_endDate";
}, V = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Version" : "zh-tw" === i2 ? "版本" : "metrics_backtest_version";
}, O = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Fee Ratio" : "zh-tw" === i2 ? "費用比率" : "metrics_backtest_feeRatio";
}, I = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tax Ratio" : "zh-tw" === i2 ? "稅收比率" : "metrics_backtest_taxRatio";
}, N = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trade At (Close/Open)" : "zh-tw" === i2 ? "交易於（收盤或開盤）" : "metrics_backtest_tradeAt";
}, F = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Market" : "zh-tw" === i2 ? "市場" : "metrics_backtest_market";
}, B = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Frequency" : "zh-tw" === i2 ? "頻率" : "metrics_backtest_freq";
}, q = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Update Date" : "zh-tw" === i2 ? "更新日期" : "metrics_backtest_updateDate";
}, U = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Next Trading Date" : "zh-tw" === i2 ? "下一交易日" : "metrics_backtest_nextTradingDate";
}, K = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Live Performance Start" : "zh-tw" === i2 ? "實時表現開始日期" : "metrics_backtest_livePerformanceStart";
}, G = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop Loss %" : "zh-tw" === i2 ? "止損百分比" : "metrics_backtest_stopLoss";
}, J = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Take Profit %" : "zh-tw" === i2 ? "獲利百分比" : "metrics_backtest_takeProfit";
}, Q = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual Return" : "zh-tw" === i2 ? "年度回報" : "metrics_profitability_annualReturn";
}, tt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Alpha" : "metrics_profitability_alpha";
}, et = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Beta" : "metrics_profitability_beta";
}, at = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Avg Holdings" : "zh-tw" === i2 ? "平均持有" : "metrics_profitability_avgNStock";
}, ct = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Holdings" : "zh-tw" === i2 ? "最多持有" : "metrics_profitability_maxNStock";
}, dt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Drawdown" : "zh-tw" === i2 ? "最大回檔" : "metrics_risk_maxDrawdown";
}, mt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Avg Drawdown" : "zh-tw" === i2 ? "平均回檔幅度" : "metrics_risk_avgDrawdown";
}, gt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Avg Drawdown Days" : "zh-tw" === i2 ? "平均回檔時間" : "metrics_risk_avgDrawdownDays";
}, bt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Volatility" : "zh-tw" === i2 ? "波動性" : "metrics_risk_volatility";
}, _t = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Value at Risk" : "metrics_risk_valueAtRisk";
}, yt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Conditional VaR" : "metrics_risk_cvalueAtRisk";
}, wt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Time to New High Rank" : "zh-tw" === i2 ? "再次創新高時間排名" : "metrics_risk_newHighTimeRank";
}, xt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy Top 10" : "zh-tw" === i2 ? "策略前十大" : "metrics_risk_worst10Strategy";
}, kt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Benchmark Top 10" : "zh-tw" === i2 ? "大盤前十大" : "metrics_risk_worst10Benchmark";
}, Mt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "days" : "metrics_risk_days";
}, zt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sharpe Ratio" : "zh-tw" === i2 ? "夏普值" : "metrics_ratio_sharpeRatio";
}, Ct = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Sortino Ratio" : "metrics_ratio_sortinoRatio";
}, Rt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Calmar Ratio" : "metrics_ratio_calmarRatio";
}, At = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Profit Factor" : "metrics_ratio_profitFactor";
}, Lt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Tail Ratio" : "metrics_ratio_tailRatio";
}, Ot = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Below Benchmark" : "zh-tw" === i2 ? "小於大盤" : "metrics_ratio_worseThanBenchmark";
}, It = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trade Win Rate" : "zh-tw" === i2 ? "逐筆交易勝率" : "metrics_winrate_winRate";
}, Bt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "12M Rolling Win Rate" : "zh-tw" === i2 ? "使用策略12個月勝大盤" : "metrics_winrate_m12WinRate";
}, Gt = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Expectancy" : "zh-tw" === i2 ? "期望值" : "metrics_winrate_expectancy";
}, te = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Adverse Excursion" : "zh-tw" === i2 ? "最大不利偏移" : "metrics_winrate_mae";
}, ee = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Favorable Excursion" : "zh-tw" === i2 ? "最大有利偏移" : "metrics_winrate_mfe";
}, ie = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Small-Cap Ratio" : "zh-tw" === i2 ? "小市值比率" : "metrics_liquidity_smallCapRatio";
}, ne = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Capacity" : "zh-tw" === i2 ? "胃納量" : "metrics_liquidity_capacity";
}, re = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Disposal Stock" : "zh-tw" === i2 ? "處置股" : "metrics_liquidity_disposalStockRatio";
}, oe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Warning Stock" : "zh-tw" === i2 ? "警告股" : "metrics_liquidity_warningStockRatio";
}, ae = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Full Delivery Stock" : "zh-tw" === i2 ? "全額交付股" : "metrics_liquidity_fullDeliveryStockRatio";
}, le = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Buy at Limit Up" : "zh-tw" === i2 ? "買在漲停" : "metrics_liquidity_buyHigh";
}, he = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sell at Limit Down" : "zh-tw" === i2 ? "賣在跌停" : "metrics_liquidity_sellLow";
}, ce = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ticker" : "zh-tw" === i2 ? "名稱代號" : "metrics_stocks_stockId";
}, ue = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return" : "zh-tw" === i2 ? "報酬" : "metrics_stocks_return";
}, de = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry" : "zh-tw" === i2 ? "進場" : "metrics_stocks_entry";
}, fe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit" : "zh-tw" === i2 ? "出場" : "metrics_stocks_exit";
}, pe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Position" : "zh-tw" === i2 ? "持倉" : "metrics_stocks_position";
}, me = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Price" : "zh-tw" === i2 ? "進場價格" : "metrics_stocks_entryPrice";
}, ge = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Price" : "zh-tw" === i2 ? "出場價格" : "metrics_stocks_exitPrice";
}, ve = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Signal" : "zh-tw" === i2 ? "進場訊號" : "metrics_stocks_entrySig";
}, be = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Signal" : "zh-tw" === i2 ? "出場訊號" : "metrics_stocks_exitSig";
}, _e = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Adverse Excursion" : "zh-tw" === i2 ? "不利偏移" : "metrics_stocks_mae";
}, we = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Favorable Excursion" : "zh-tw" === i2 ? "有利偏移" : "metrics_stocks_gmfe";
}, xe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Pre-loss Favorable Excursion" : "zh-tw" === i2 ? "虧損前有利偏移" : "metrics_stocks_bmfe";
}, Se = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Drawdown" : "zh-tw" === i2 ? "最大回檔" : "metrics_stocks_mdd";
}, ze = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Holding Days" : "zh-tw" === i2 ? "持倉天数" : "metrics_stocks_pdays";
}, De = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save Draft" : "zh-tw" === i2 ? "儲存草稿" : "notebook_private_draft";
}, Pe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save" : "zh-tw" === i2 ? "儲存" : "notebook_save_draft";
}, Te = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Publish" : "zh-tw" === i2 ? "準備發布" : "notebook_go_public";
}, $e = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Update Published" : "zh-tw" === i2 ? "更新發布" : "notebook_update_public";
}, Ee = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Python" : "notebook_category_python";
}, Ae = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stock Market" : "zh-tw" === i2 ? "股市" : "notebook_category_market";
}, Le = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Algorithm" : "zh-tw" === i2 ? "演算法" : "notebook_category_algorithm";
}, Ve = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tools" : "zh-tw" === i2 ? "工具" : "notebook_category_tool";
}, Oe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy Metrics" : "zh-tw" === i2 ? "策略指標" : "notebook_category_metric";
}, Ie = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Financial Indicators" : "zh-tw" === i2 ? "財經指標" : "notebook_category_indicator";
}, Ne = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Machine Learning AI" : "zh-tw" === i2 ? "機器學習AI" : "notebook_category_ai";
}, Fe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop Loss" : "zh-tw" === i2 ? "停損" : "position_sl";
}, We = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Take Profit" : "zh-tw" === i2 ? "停利" : "position_tp";
}, Be = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trailing Stop" : "zh-tw" === i2 ? "移動出場" : "position_ts";
}, je = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rebalance Frequency" : "zh-tw" === i2 ? "換股頻率" : "position_resample";
}, qe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Timing" : "zh-tw" === i2 ? "進場時機" : "position_entryTradePrice";
}, He = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Timing" : "zh-tw" === i2 ? "出場時機" : "position_exitTradePrice";
}, Ue = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Scheduled Rebalance" : "zh-tw" === i2 ? "預定換股日" : "position_scheduled";
}, Ke = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Backtest Frequency" : "zh-tw" === i2 ? "回測頻率" : "position_dataFreq";
}, Ye = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Last Updated" : "zh-tw" === i2 ? "更新時間" : "position_created";
}, Ge = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Date" : "zh-tw" === i2 ? "進場日期" : "position_entryDate";
}, Xe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Date" : "zh-tw" === i2 ? "出場日期" : "position_exitDate";
}, Je = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Price" : "zh-tw" === i2 ? "價格" : "position_currentPrice";
}, Qe = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "P&L" : "zh-tw" === i2 ? "盈虧" : "position_profit";
}, Ze = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Current Weight" : "zh-tw" === i2 ? "當前持股比例" : "position_currentWeight";
}, ii = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Target Weight" : "zh-tw" === i2 ? "持股比例" : "position_nextWeight";
}, oi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Momentum" : "zh-tw" === i2 ? "多空力道" : "position_RSV";
}, ui = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 30 min" : "zh-tw" === i2 ? "每30分鐘" : "position_resampleValue_30M";
}, di = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 1 hour" : "zh-tw" === i2 ? "每1小時" : "position_resampleValue_H";
}, fi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 4 hours" : "zh-tw" === i2 ? "每4小時" : "position_resampleValue_4H";
}, pi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 8 hours" : "zh-tw" === i2 ? "每8小時" : "position_resampleValue_8H";
}, mi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Daily" : "zh-tw" === i2 ? "每1天" : "position_resampleValue_D";
}, gi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Weekly" : "zh-tw" === i2 ? "每週" : "position_resampleValue_W";
}, vi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 2 weeks" : "zh-tw" === i2 ? "每2週" : "position_resampleValue_2W";
}, bi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 3 weeks" : "zh-tw" === i2 ? "每3週" : "position_resampleValue_3W";
}, _i = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 4 weeks" : "zh-tw" === i2 ? "每4週" : "position_resampleValue_4W";
}, wi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monthly" : "zh-tw" === i2 ? "每月底" : "position_resampleValue_M";
}, xi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every 2 months" : "zh-tw" === i2 ? "每2個月" : "position_resampleValue_2M";
}, ki = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Month-end" : "zh-tw" === i2 ? "每月底" : "position_resampleValue_ME";
}, Si = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Revenue Release Day" : "zh-tw" === i2 ? "每月收入公佈日" : "position_resampleValue_MRE";
}, Pi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Quarterly" : "zh-tw" === i2 ? "每1季底" : "position_resampleValue_Q";
}, Ei = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Quarter-end" : "zh-tw" === i2 ? "每1季底" : "position_resampleValue_QE";
}, Li = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Semi-annually" : "zh-tw" === i2 ? "每半年" : "position_resampleValue_HY";
}, Ii = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annually" : "zh-tw" === i2 ? "每1年" : "position_resampleValue_Y";
}, Fi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Irregular" : "zh-tw" === i2 ? "不固定" : "position_resampleValue_null";
}, Hi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Open" : "zh-tw" === i2 ? "開盤" : "position_open";
}, Ki = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Close" : "zh-tw" === i2 ? "收盤" : "position_close";
}, Yi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Open-Close Avg" : "zh-tw" === i2 ? "開收均價" : "position_open_close_avg";
}, Xi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "High-Low Avg" : "zh-tw" === i2 ? "高低均價" : "position_high_low_avg";
}, Zi = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry" : "zh-tw" === i2 ? "進場" : "position_type_entry";
}, ts = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Pending Entry" : "zh-tw" === i2 ? "將進場" : "position_type_entry_f";
}, es = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit" : "zh-tw" === i2 ? "出場" : "position_type_exit";
}, ss = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exited" : "zh-tw" === i2 ? "已出場" : "position_type_exit_p";
}, ns = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Hold" : "zh-tw" === i2 ? "持有" : "position_type_hold";
}, rs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop Loss" : "zh-tw" === i2 ? "停損" : "position_type_sl";
}, ls = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Take Profit" : "zh-tw" === i2 ? "停利" : "position_type_tp";
}, hs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stopped Out" : "zh-tw" === i2 ? "已停損" : "position_type_sl_";
}, cs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Profit Taken" : "zh-tw" === i2 ? "已停利" : "position_type_tp_";
}, us = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Asset Name" : "zh-tw" === i2 ? "標的名稱" : "position_assetName";
}, ds = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Action" : "zh-tw" === i2 ? "動作" : "position_action";
}, fs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly Sharpe vs Benchmark" : "zh-tw" === i2 ? "夏普與大盤比較" : "metrics_ratio_yearlySharpeRatio";
}, ms = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Above Benchmark:" : "zh-tw" === i2 ? "大於大盤：" : "metrics_ratio_betterThanBenchmark";
}, gs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Year" : "zh-tw" === i2 ? "年" : "metrics_ratio_year";
}, vs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Time Above Benchmark:" : "zh-tw" === i2 ? "大於大盤的時間：" : "metrics_ratio_timeBetterThanBenchmark";
}, bs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly Tail Ratio vs Benchmark" : "zh-tw" === i2 ? "極端風報比與大盤比較" : "metrics_ratio_yearlyTailRatio";
}, _s = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Volatility" : "zh-tw" === i2 ? "策略報酬率波動 (Volitility)" : "metrics_ratio_volatility";
}, ys = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy-Benchmark Correlation" : "zh-tw" === i2 ? "策略與大盤相關性" : "ratio_correlation";
}, ws = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return Distribution" : "zh-tw" === i2 ? "報酬分布" : "metrics_winrate_returnDistribution";
}, xs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "There is a 5% probability of a loss exceeding" : "zh-tw" === i2 ? "有 5% 的機率，交易將有" : "metrics_winrate_distributionInfo1";
}, ks = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? " %" : "zh-tw" === i2 ? " % 以上的虧損" : "metrics_winrate_distributionInfo2";
}, Ss = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return" : "zh-tw" === i2 ? "報酬率" : "metrics_winrate_return";
}, Ms = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Trade Excursion" : "zh-tw" === i2 ? "交易最大偏移" : "metrics_winrate_maemfe";
}, zs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop Loss Setting:" : "zh-tw" === i2 ? "停損設定：" : "metrics_winrate_stoploss";
}, Ds = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "None" : "zh-tw" === i2 ? "無" : "metrics_winrate_none";
}, Rs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Extra P&L from Stop Loss:" : "zh-tw" === i2 ? "停損造成的額外盈虧：" : "metrics_winrate_extraProfitLoss";
}, Ps = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop Loss Trade Ratio:" : "zh-tw" === i2 ? "停損的交易比例：" : "metrics_winrate_stoplossRatio";
}, Ts = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return vs Max Adverse Excursion" : "zh-tw" === i2 ? "報酬與最大不利偏移" : "metrics_winrate_maeReturn";
}, $s = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulated Stop Loss" : "zh-tw" === i2 ? "模擬停損" : "metrics_winrate_simulatedStopLoss";
}, Es = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulated Take Profit" : "zh-tw" === i2 ? "模擬停利" : "metrics_winrate_simulatedTakeProfit";
}, As = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Take Profit Setting:" : "zh-tw" === i2 ? "停利設定：" : "metrics_winrate_takeProfit";
}, Is = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Extra P&L from Take Profit:" : "zh-tw" === i2 ? "停利造成的額外盈虧：" : "metrics_winrate_extraProfitLossTakingProfit";
}, Ns = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Take Profit Trade Ratio:" : "zh-tw" === i2 ? "停利的交易比例：" : "metrics_winrate_takeProfitRatio";
}, Ws = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return vs Max Favorable Excursion" : "zh-tw" === i2 ? "報酬與最大有利偏移" : "metrics_winrate_mfeReturn";
}, Bs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Portfolio Capacity" : "zh-tw" === i2 ? "投資組合胃納量" : "metrics_liquidity_portfolioCapacity";
}, js = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Safe Liquidity Trade Ratio" : "zh-tw" === i2 ? "安全流動性交易的佔比" : "metrics_liquidity_safeLiquidityTradeRatio";
}, qs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average Return" : "zh-tw" === i2 ? "平均報酬" : "metrics_liquidity_averageReturn";
}, Hs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Total Investment" : "zh-tw" === i2 ? "投資總資金" : "metrics_liquidity_totalInvestment";
}, Us = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Market Cap of Trades" : "zh-tw" === i2 ? "交易標的的市值" : "metrics_liquidity_marketCap";
}, Ks = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trade Ratio" : "zh-tw" === i2 ? "交易的佔比" : "metrics_liquidity_tradeRatio";
}, Ys = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Market Cap Threshold" : "zh-tw" === i2 ? "市值門檻" : "metrics_liquidity_tradeRatioMarketCap";
}, Gs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Volume Threshold" : "zh-tw" === i2 ? "買進成交量門檻" : "metrics_liquidity_tradeRatioEntryVolume";
}, Xs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trade Ratio" : "zh-tw" === i2 ? "交易的佔比" : "metrics_liquidity_tradeRatioExitVolume";
}, Js = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Daily Volume" : "zh-tw" === i2 ? "當天成交量" : "metrics_liquidity_volumeThreshold";
}, Qs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Day Volume" : "zh-tw" === i2 ? "出場當天成交量" : "metrics_liquidity_exitVolume";
}, Zs = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Entry Day Volume" : "zh-tw" === i2 ? "進場當天成交量" : "metrics_liquidity_entryVolume";
}, en = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Market Cap Threshold" : "zh-tw" === i2 ? "市值門檻" : "metrics_liquidity_marketCapThreshold";
}, sn = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `At a capital of ${(s2 = t2).v1}, there is a ${s2.v2}% probability of buying low-liquidity stocks (low volume, wide spreads, volatile prices).` : "zh-tw" === i2 ? ((t3) => `當資金量達到 ${t3.v1} 時，將有 ${t3.v2}%的機率，買到流動性低的股票(低成交量、價差大、價格易波動)。`)(t2) : "metrics_liquidity_portfolioCapacityDescription";
  var s2;
}, rn = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Trades with market cap above ${(s2 = t2).v1} account for ${s2.v2}%.` : "zh-tw" === i2 ? ((t3) => `市值 ${t3.v1} 以上的交易佔 ${t3.v2}%。`)(t2) : "metrics_liquidity_marketCapDescription";
  var s2;
}, on = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Trades with entry-day volume above ${(s2 = t2).v1} lots account for ${s2.v2}%.` : "zh-tw" === i2 ? ((t3) => `買入當天成交量 ${t3.v1} 張以上的交易佔 ${t3.v2}%。`)(t2) : "metrics_liquidity_entryVolumeDescription";
  var s2;
}, an = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Trades with exit-day volume above ${(s2 = t2).v1} lots account for ${s2.v2}%.` : "zh-tw" === i2 ? ((t3) => `賣出當天成交量 ${t3.v1} 張以上的交易佔 ${t3.v2}%。`)(t2) : "metrics_liquidity_exitVolumeDescription";
  var s2;
}, ln = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rolling Tail Ratio" : "zh-tw" === i2 ? "極端風報比" : "metrics_ratio_rollingTailRatio";
}, hn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual Return" : "zh-tw" === i2 ? "年報酬" : "profitability_yearlyReturn";
}, cn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Benchmark Annual Return" : "zh-tw" === i2 ? "大盤年報酬" : "profitability_benchmarkYearlyReturn";
}, un = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Year" : "zh-tw" === i2 ? "年" : "profitability_year";
}, pn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown Ranking" : "zh-tw" === i2 ? "跌幅排名" : "metrics_risk_worstDrawdownPeriod";
}, mn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All" : "zh-tw" === i2 ? "全部" : "profitability_all";
}, vn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Recent" : "zh-tw" === i2 ? "近年" : "profitability_recent";
}, bn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Backtest start date" : "zh-tw" === i2 ? "回測的開始日期" : "metric_description_backtest_startDate";
}, _n = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Backtest end date" : "zh-tw" === i2 ? "回測的結束日期" : "metric_description_backtest_endDate";
}, Sn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Backtest version" : "zh-tw" === i2 ? "回測的版本" : "metric_description_backtest_version";
}, zn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trading fee ratio" : "zh-tw" === i2 ? "交易的手續費比率" : "metric_description_backtest_feeRatio";
}, Cn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trading tax ratio" : "zh-tw" === i2 ? "交易的稅率" : "metric_description_backtest_taxRatio";
}, $n = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Whether trades execute at market close or open" : "zh-tw" === i2 ? "交易是在市場收盤還是開盤時執行" : "metric_description_backtest_tradeAt";
}, En = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Market used for backtesting" : "zh-tw" === i2 ? "進行回測的市場" : "metric_description_backtest_market";
}, An = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Data frequency used in backtest" : "zh-tw" === i2 ? "回測使用的數據頻率" : "metric_description_backtest_freq";
}, On = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Last update date of the backtest" : "zh-tw" === i2 ? "回測最後更新的日期" : "metric_description_backtest_updateDate";
}, In = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Next trading date after the backtest" : "zh-tw" === i2 ? "回測後的下一個交易日期" : "metric_description_backtest_nextTradingDate";
}, Nn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Date when live performance tracking began" : "zh-tw" === i2 ? "實時性能跟踪開始的日期" : "metric_description_backtest_livePerformanceStart";
}, Fn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Maximum allowed loss to stop a trade" : "zh-tw" === i2 ? "允許的最大損失以停止交易" : "metric_description_backtest_stopLoss";
}, Wn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Profit target to exit a trade" : "zh-tw" === i2 ? "退出交易的利潤目標" : "metric_description_backtest_takeProfit";
}, Bn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annualized return of the strategy" : "zh-tw" === i2 ? "策略的年度回報" : "metric_description_profitability_annualReturn";
}, qn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Risk-adjusted outperformance relative to benchmark" : "zh-tw" === i2 ? "相對於基準的策略的風險調整後表現的衡量" : "metric_description_profitability_alpha";
}, Kn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy's sensitivity to market movements" : "zh-tw" === i2 ? "策略對市場變動的敏感性的衡量" : "metric_description_profitability_beta";
}, Yn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average number of stocks held in portfolio" : "zh-tw" === i2 ? "投資組合中持有的平均股票數" : "metric_description_profitability_avgNStock";
}, Gn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Maximum number of stocks held in portfolio" : "zh-tw" === i2 ? "投資組合中持有的最大股票數" : "metric_description_profitability_maxNStock";
}, Xn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Largest peak-to-trough percentage decline" : "zh-tw" === i2 ? "從高點到低谷的最大百分比下降" : "metric_description_risk_maxDrawdown";
}, Jn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average peak-to-trough percentage decline" : "zh-tw" === i2 ? "從高點到低谷的平均百分比下降" : "metric_description_risk_avgDrawdown";
}, Qn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average number of days in drawdown" : "zh-tw" === i2 ? "平均回撤天數" : "metric_description_risk_avgDrawdownDays";
}, Zn = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Standard deviation of strategy returns" : "zh-tw" === i2 ? "策略回報的標準差" : "metric_description_risk_volatility";
}, tr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Maximum expected loss over a specified period at a given confidence level" : "zh-tw" === i2 ? "給定信心區間的指定期間內預期的最大損失" : "metric_description_risk_valueAtRisk";
}, er = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Expected loss given that a specified adverse event has occurred" : "zh-tw" === i2 ? "發生指定不良事件後的預期損失" : "metric_description_risk_cvalueAtRisk";
}, ir = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Measure of risk-adjusted performance" : "zh-tw" === i2 ? "風險調整後表現的衡量" : "metric_description_ratio_sharpeRatio";
}, sr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Risk-adjusted performance considering only downside volatility" : "zh-tw" === i2 ? "只考慮下行波動性的風險調整後表現的衡量" : "metric_description_ratio_sortinoRatio";
}, nr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of annual return to maximum drawdown" : "zh-tw" === i2 ? "年度回報與最大回撤的比率" : "metric_description_ratio_calmarRatio";
}, rr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of total profits to total losses" : "zh-tw" === i2 ? "總利潤與總損失的比率" : "metric_description_ratio_profitFactor";
}, or = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of right tail (wins) to left tail (losses)" : "zh-tw" === i2 ? "右尾（贏）與左尾（輸）的比率" : "metric_description_ratio_tailRatio";
}, ar = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Percentage of profitable trades" : "zh-tw" === i2 ? "盈利交易的百分比" : "metric_description_winrate_winRate";
}, lr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "12-month rolling win rate" : "zh-tw" === i2 ? "12個月滾動勝率" : "metric_description_winrate_m12WinRate";
}, hr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average amount expected to win (or lose) per trade" : "zh-tw" === i2 ? "每筆交易預期贏得（或損失）的平均金額" : "metric_description_winrate_expectancy";
}, cr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max adverse excursion — largest loss before a trade turns profitable" : "zh-tw" === i2 ? "最大不利運動，或交易盈利前的最大損失" : "metric_description_winrate_mae";
}, ur = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max favorable excursion — largest gain before a trade turns into a loss" : "zh-tw" === i2 ? "最大有利運動，或交易變成損失前的最大利潤" : "metric_description_winrate_mfe";
}, dr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Maximum capital deployable without impacting market prices" : "zh-tw" === i2 ? "不影響市場價格可以部署的最大資本金額" : "metric_description_liquidity_capacity";
}, fr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of stocks that can be easily sold" : "zh-tw" === i2 ? "可以輕易出售的股票比率" : "metric_description_liquidity_disposalStockRatio";
}, pr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of stocks that may have liquidity issues" : "zh-tw" === i2 ? "可能存在流動性問題的股票比率" : "metric_description_liquidity_warningStockRatio";
}, mr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ratio of stocks requiring full delivery" : "zh-tw" === i2 ? "需要全額交付的股票比率" : "metric_description_liquidity_fullDeliveryStockRatio";
}, gr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tendency to buy stocks at limit-up prices" : "zh-tw" === i2 ? "購買高價股票的傾向" : "metric_description_liquidity_buyHigh";
}, vr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tendency to sell stocks at limit-down prices" : "zh-tw" === i2 ? "賣出低價股票的傾向" : "metric_description_liquidity_sellLow";
}, br = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Conditions Met" : "zh-tw" === i2 ? "達成條件" : "metrics_condition";
}, _r = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Code" : "zh-tw" === i2 ? "程式碼" : "strategy_code";
}, yr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return" : "zh-tw" === i2 ? "報酬" : "strategy_return";
}, wr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Beat Benchmark" : "zh-tw" === i2 ? "贏大盤" : "strategy_betterThanBenchmark";
}, xr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Lost to Benchmark" : "zh-tw" === i2 ? "輸大盤" : "strategy_worseThanBenchmark";
}, kr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual Return" : "zh-tw" === i2 ? "年度報酬" : "strategy_annualReturn";
}, Sr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Drawdown" : "zh-tw" === i2 ? "最大回檔" : "strategy_maxDrawdown";
}, Mr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sharpe Ratio" : "zh-tw" === i2 ? "夏普比率" : "strategy_sharpeRatio";
}, zr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Week" : "zh-tw" === i2 ? "週" : "strategy_period_W";
}, Cr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Month" : "zh-tw" === i2 ? "月" : "strategy_period_M";
}, Dr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Quarter" : "zh-tw" === i2 ? "季" : "strategy_period_Q";
}, Rr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Half Year" : "zh-tw" === i2 ? "半年" : "strategy_period_HY";
}, Pr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Year" : "zh-tw" === i2 ? "年" : "strategy_period_Y";
}, Tr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All" : "zh-tw" === i2 ? "全部" : "strategy_period_All";
}, $r = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Holdings" : "zh-tw" === i2 ? "選股" : "strategy_tabs_position";
}, Er = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Analysis" : "zh-tw" === i2 ? "分析" : "strategy_tabs_analyze";
}, Ar = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tutorial" : "zh-tw" === i2 ? "教學" : "strategy_tabs_course";
}, Lr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI Optimize" : "zh-tw" === i2 ? "AI 優化" : "strategy_tabs_notebook";
}, Vr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "FinLab Strategies" : "zh-tw" === i2 ? "FinLab 策略" : "viewer_finlabStrategies";
}, Or = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "My Strategy" : "zh-tw" === i2 ? "我的策略" : "viewer_myStrategy";
}, Ir = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Quant Strategy" : "zh-tw" === i2 ? "量化策略" : "viewer_quantStrategy";
}, Nr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rename" : "zh-tw" === i2 ? "重新命名" : "viewer_rename";
}, Fr = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Rename failed: ${t2.v1}` : "zh-tw" === i2 ? `重命名失敗: ${t2.v1}` : "viewer_renameFailed";
}, Wr = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `${t2.v1} Return` : "zh-tw" === i2 ? `${t2.v1}報酬` : "viewer_periodReturn";
}, Br = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Login to View List" : "zh-tw" === i2 ? "登入觀看清單" : "viewer_loginToView";
}, jr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Join to Get Examples" : "zh-tw" === i2 ? "加入會員取得範例" : "viewer_joinToView";
}, qr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Contact Author for Access" : "zh-tw" === i2 ? "聯繫作者取得權限" : "viewer_contactAuthor";
}, Hr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Previous Page" : "zh-tw" === i2 ? "上一頁" : "viewer_previousPage";
}, Ur = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every Monday" : "zh-tw" === i2 ? "每週一" : "position_resampleValue_W_Mon";
}, Kr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every Tuesday" : "zh-tw" === i2 ? "每週二" : "position_resampleValue_W_Tue";
}, Yr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every Wednesday" : "zh-tw" === i2 ? "每週三" : "position_resampleValue_W_Wed";
}, Gr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every Thursday" : "zh-tw" === i2 ? "每週四" : "position_resampleValue_W_Thu";
}, Xr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Every Friday" : "zh-tw" === i2 ? "每週五" : "position_resampleValue_W_Fri";
}, Jr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "General" : "zh-tw" === i2 ? "一般設定" : "settings_general";
}, Qr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI Usage" : "zh-tw" === i2 ? "AI 使用量" : "settings_aiUsage";
}, Zr = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Data Download" : "zh-tw" === i2 ? "資料下載" : "settings_dataDownload";
}, to = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Notifications" : "zh-tw" === i2 ? "訊息通知" : "settings_notifications";
}, eo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Subscription" : "zh-tw" === i2 ? "訂閱方案" : "settings_subscription";
}, io = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Payment History" : "zh-tw" === i2 ? "付款記錄" : "settings_payment";
}, so = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 || "zh-tw" === i2 ? "Google AI" : "settings_googleAi";
}, no = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Language" : "zh-tw" === i2 ? "語言" : "settings_language";
}, ro = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stock Research" : "zh-tw" === i2 ? "選股研究" : "nav_stockResearch";
}, oo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Schedule" : "zh-tw" === i2 ? "排程管理" : "nav_schedule";
}, ao = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Data Catalog" : "zh-tw" === i2 ? "資料目錄" : "nav_database";
}, lo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Navigation" : "zh-tw" === i2 ? "導航" : "nav_navigation";
}, ho = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "My Strategies" : "zh-tw" === i2 ? "我的策略" : "nav_myStrategies";
}, co = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Login" : "zh-tw" === i2 ? "登入" : "common_login";
}, uo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Logout" : "zh-tw" === i2 ? "登出" : "common_logout";
}, fo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Settings" : "zh-tw" === i2 ? "設定" : "common_settings";
}, po = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save" : "zh-tw" === i2 ? "儲存" : "common_save";
}, mo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Close" : "zh-tw" === i2 ? "關閉" : "common_close";
}, go = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cancel" : "zh-tw" === i2 ? "取消" : "common_cancel";
}, vo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "OK" : "zh-tw" === i2 ? "確定" : "common_confirm";
}, bo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Delete" : "zh-tw" === i2 ? "刪除" : "common_delete";
}, _o = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rename" : "zh-tw" === i2 ? "重新命名" : "common_rename";
}, yo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Copy" : "zh-tw" === i2 ? "複製" : "common_copy";
}, wo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Run" : "zh-tw" === i2 ? "執行" : "common_run";
}, xo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Search" : "zh-tw" === i2 ? "搜尋" : "common_search";
}, ko = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "New Strategy" : "zh-tw" === i2 ? "新增策略" : "common_newStrategy";
}, So = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Search strategies..." : "zh-tw" === i2 ? "搜尋策略..." : "common_searchStrategies";
}, Mo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Upgrade Plan" : "zh-tw" === i2 ? "升級方案" : "common_upgradePlan";
}, zo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "My Plan" : "zh-tw" === i2 ? "我的方案" : "common_myPlan";
}, Co = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Loading..." : "zh-tw" === i2 ? "載入中…" : "common_loading";
}, Do = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Today's Data Usage" : "zh-tw" === i2 ? "今日資料用量" : "dataUsage_todayUsage";
}, Ro = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Data Usage" : "zh-tw" === i2 ? "資料用量" : "dataUsage_dataUsage";
}, Po = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Load Failed" : "zh-tw" === i2 ? "取得失敗" : "dataUsage_loadFailed";
}, To = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Request Usage Reset" : "zh-tw" === i2 ? "要求重置當天用量" : "dataUsage_requestReset";
}, $o = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Ask on Discord" : "zh-tw" === i2 ? "請至 Discord 詢問" : "dataUsage_askDiscord";
}, Eo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage resets daily at 8:00 AM Taiwan time" : "zh-tw" === i2 ? "每日於台灣時間，早上八點重置用量" : "dataUsage_resetInfo";
}, Ao = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "In-App Notifications" : "zh-tw" === i2 ? "站內通知" : "notification_inSite";
}, Lo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Weekly Post Notification" : "zh-tw" === i2 ? "每週貼文通知" : "notification_weeklyPost";
}, Vo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Email" : "zh-tw" === i2 ? "Email 收信" : "notification_email";
}, Oo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monthly Article Newsletter" : "zh-tw" === i2 ? "每月文章電子報" : "notification_monthlyNewsletter";
}, Io = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy Signal Notification" : "zh-tw" === i2 ? "策略訊號通知" : "notification_strategySignal";
}, No = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save failed: " : "zh-tw" === i2 ? "儲存失敗：" : "notification_saveFailed";
}, Fo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "month" : "zh-tw" === i2 ? "月" : "payment_month";
}, Wo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "No active subscription" : "zh-tw" === i2 ? "當前無訂閱任何商品" : "payment_noSubscription";
}, Bo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Payment Details" : "zh-tw" === i2 ? "扣款明細" : "payment_paymentDetails";
}, jo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Change Credit Card / Invoice" : "zh-tw" === i2 ? "更換信用卡、發票" : "payment_changeCreditCard";
}, qo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Last 4 Digits" : "zh-tw" === i2 ? "卡片末四碼" : "payment_lastFourDigits";
}, Ho = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Transaction ID" : "zh-tw" === i2 ? "交易序號" : "payment_transactionId";
}, Uo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Payment Time" : "zh-tw" === i2 ? "付款時間" : "payment_paymentTime";
}, Ko = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Amount" : "zh-tw" === i2 ? "費用" : "payment_amount";
}, Yo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Invoice Number" : "zh-tw" === i2 ? "發票號碼" : "payment_invoiceNumber";
}, Go = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "No transaction records" : "zh-tw" === i2 ? "無交易紀錄" : "payment_noRecords";
}, Xo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy" : "zh-tw" === i2 ? "策略" : "header_strategy";
}, Jo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Holdings" : "zh-tw" === i2 ? "選股" : "header_position";
}, Qo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Analysis" : "zh-tw" === i2 ? "分析" : "header_analyze";
}, Zo = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Code" : "zh-tw" === i2 ? "程式" : "header_notebook";
}, ta = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI Optimize" : "zh-tw" === i2 ? "AI 優化" : "header_aiOptimize";
}, ea = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Fullscreen" : "zh-tw" === i2 ? "全螢幕" : "header_fullscreen";
}, ia = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Exit Fullscreen" : "zh-tw" === i2 ? "退出全螢幕" : "header_exitFullscreen";
}, sa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Minimize" : "zh-tw" === i2 ? "縮小" : "header_minimize";
}, na = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Panorama" : "zh-tw" === i2 ? "全景" : "header_panorama";
}, ra = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Close Panel" : "zh-tw" === i2 ? "關閉面板" : "header_closePanel";
}, oa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Toggle Sidebar" : "zh-tw" === i2 ? "切換側邊欄" : "header_toggleSidebar";
}, aa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Fork & Save" : "zh-tw" === i2 ? "複製並儲存" : "header_copyAndSave";
}, la = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Fork Strategy" : "zh-tw" === i2 ? "複製策略" : "header_copyStrategy";
}, ha = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "More Options" : "zh-tw" === i2 ? "更多選項" : "header_moreOptions";
}, ca = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save Strategy" : "zh-tw" === i2 ? "儲存策略" : "header_saveStrategy";
}, ua = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Please login first" : "zh-tw" === i2 ? "請先登入" : "header_pleaseLogin";
}, da = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Upgrade to VIP to fork & save" : "zh-tw" === i2 ? "升級 VIP 後可複製並儲存" : "header_upgradeVipToFork";
}, fa = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `AI auto-optimize strategy ${t2.v1} times` : "zh-tw" === i2 ? `AI 自動優化策略 ${t2.v1} 次` : "header_aiAutoOptimize";
}, pa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "User Menu" : "zh-tw" === i2 ? "使用者選單" : "header_userMenu";
}, ma = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `AI is auto-optimizing... (${t2.v1} remaining)` : "zh-tw" === i2 ? `AI 正在自動優化策略... (剩餘 ${t2.v1} 次)` : "header_aiOptimizing";
}, ga = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stop" : "zh-tw" === i2 ? "停止" : "header_stop";
}, va = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Plan" : "zh-tw" === i2 ? "方案" : "header_plan";
}, ba = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI found a better strategy! Click AI Optimize to view" : "zh-tw" === i2 ? "AI 發現更優策略！點擊 AI 優化 查看" : "toast_aiBetterStrategy";
}, _a = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Auto-optimization complete" : "zh-tw" === i2 ? "自動優化已完成" : "toast_autoOptimizeDone";
}, ya = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy saved" : "zh-tw" === i2 ? "策略已儲存" : "toast_strategySaved";
}, wa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save failed" : "zh-tw" === i2 ? "儲存失敗" : "toast_saveFailed";
}, xa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Forked as my strategy and saved (edits preserved)" : "zh-tw" === i2 ? "已複製為我的策略並儲存（保留編輯）" : "toast_forkedAndSaved";
}, ka = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Not logged in" : "zh-tw" === i2 ? "尚未登入，無法產生新的 API 驗證碼" : "toast_notLoggedIn";
}, Sa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cannot generate a new API token" : "zh-tw" === i2 ? "無法產生新的 API 驗證碼" : "toast_cannotGenerateToken";
}, Ma = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cannot generate a new API token (token invalid)" : "zh-tw" === i2 ? "無法產生新的 API 驗證碼（Token 無效）" : "toast_tokenInvalid";
}, za = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cannot get current user's ID token" : "zh-tw" === i2 ? "無法獲取當前用戶的 ID 令牌" : "toast_cannotGetIdToken";
}, Ca = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Are you sure you want to reset the API token? The previous one will be invalidated!" : "zh-tw" === i2 ? "您確定要重新產生 API 驗證碼嗎？之前的將會不能使用喔！" : "toast_confirmResetToken";
}, Da = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "API Key" : "zh-tw" === i2 ? "API 金鑰" : "general_apiKey";
}, Ra = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Reset API Key" : "zh-tw" === i2 ? "重置 API 金鑰" : "general_resetApiKey";
}, Pa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Resetting..." : "zh-tw" === i2 ? "重置中..." : "general_resetting";
}, Ta = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Delete & Reset API" : "zh-tw" === i2 ? "刪除並重置 API" : "general_deleteAndReset";
}, $a = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Delete All Strategies" : "zh-tw" === i2 ? "刪除所有策略" : "general_deleteAllStrategies";
}, Ea = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Delete All" : "zh-tw" === i2 ? "全部刪除" : "general_deleteAll";
}, Aa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Connection Status" : "zh-tw" === i2 ? "連線狀態" : "googleAi_connectionStatus";
}, La = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Connected" : "zh-tw" === i2 ? "已連結" : "googleAi_connected";
}, Va = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Not Connected" : "zh-tw" === i2 ? "未連結" : "googleAi_disconnected";
}, Oa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Disconnect Google AI" : "zh-tw" === i2 ? "中斷 Google AI 連結" : "googleAi_disconnect";
}, Ia = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Disconnecting..." : "zh-tw" === i2 ? "中斷中..." : "googleAi_disconnecting";
}, Na = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Disconnect" : "zh-tw" === i2 ? "中斷連結" : "googleAi_disconnectBtn";
}, Fa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Connect Google AI" : "zh-tw" === i2 ? "連結 Google AI" : "googleAi_connect";
}, Wa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "This feature is only available for Max plan users." : "zh-tw" === i2 ? "此功能僅限 Max 方案使用者。" : "googleAi_maxOnly";
}, Ba = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Google authorization page has been opened. Please complete authorization and copy the authorization code:" : "zh-tw" === i2 ? "已開啟 Google 授權頁面，請完成授權後複製頁面上的授權代碼：" : "googleAi_authInstructions";
}, ja = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Paste authorization code" : "zh-tw" === i2 ? "貼上授權代碼" : "googleAi_pasteCode";
}, qa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Verifying..." : "zh-tw" === i2 ? "驗證中..." : "googleAi_verifying";
}, Ha = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Submit" : "zh-tw" === i2 ? "提交" : "googleAi_submit";
}, Ua = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Use your own Google AI quota" : "zh-tw" === i2 ? "使用自己的 Google AI 額度" : "googleAi_useOwnQuota";
}, Ka = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "After connecting, AI conversations will use your Google account's Gemini API quota, free from platform usage limits. Authorization will remain active until you manually disconnect." : "zh-tw" === i2 ? "連結後，AI 對話將使用您的 Google 帳號 Gemini API 額度，不受平台用量限制。授權將持續有效，直到您手動中斷連結。" : "googleAi_useOwnQuotaDesc";
}, Ya = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Failed to open authorization page" : "zh-tw" === i2 ? "開啟授權頁面失敗" : "googleAi_authPageFailed";
}, Ga = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Google AI connected" : "zh-tw" === i2 ? "Google AI 已連結" : "googleAi_connectSuccess";
}, Xa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Failed to connect Google AI. Please verify the code is correct." : "zh-tw" === i2 ? "連結 Google AI 失敗，請確認代碼是否正確" : "googleAi_connectFailed";
}, Ja = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Google AI disconnected" : "zh-tw" === i2 ? "Google AI 已中斷連結" : "googleAi_disconnectSuccess";
}, Qa = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Failed to disconnect" : "zh-tw" === i2 ? "中斷連結失敗" : "googleAi_disconnectFailed";
}, Za = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI Usage Tracking" : "zh-tw" === i2 ? "AI 使用量追蹤" : "aiUsage_tracking";
}, tl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monitor your AI feature usage" : "zh-tw" === i2 ? "監控您的 AI 功能使用情況" : "aiUsage_description";
}, el = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Current Usage" : "zh-tw" === i2 ? "當前使用量" : "aiUsage_currentUsage";
}, il = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "VIP User" : "zh-tw" === i2 ? "VIP 用戶" : "aiUsage_vipUser";
}, sl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "VIP User (AI plan not included)" : "zh-tw" === i2 ? "VIP 用戶（未含 AI 方案）" : "aiUsage_vipNoAi";
}, nl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI User" : "zh-tw" === i2 ? "AI 用戶" : "aiUsage_aiUser";
}, rl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Free User" : "zh-tw" === i2 ? "一般用戶" : "aiUsage_freeUser";
}, ol = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage Progress" : "zh-tw" === i2 ? "使用進度" : "aiUsage_progress";
}, al = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage Progress" : "zh-tw" === i2 ? "使用量進度" : "aiUsage_usageProgress";
}, ll = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage limit reached" : "zh-tw" === i2 ? "使用量已達上限" : "aiUsage_limitReached";
}, hl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage near limit" : "zh-tw" === i2 ? "使用量接近上限" : "aiUsage_nearLimit";
}, cl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage normal" : "zh-tw" === i2 ? "使用量正常" : "aiUsage_usageNormal";
}, ul = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "VIP usage limit reached" : "zh-tw" === i2 ? "VIP 用量已達上限" : "aiUsage_vipLimitReached";
}, dl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "You have reached the maximum AI usage limit for the highest tier" : "zh-tw" === i2 ? "您已達到最高等級的 AI 使用量限制" : "aiUsage_vipLimitDesc";
}, fl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI usage limit reached" : "zh-tw" === i2 ? "AI 用量已達上限" : "aiUsage_limitReachedTitle";
}, pl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "You have reached the monthly AI usage limit" : "zh-tw" === i2 ? "您已達到當月 AI 使用量限制" : "aiUsage_limitReachedDesc";
}, ml = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Contact support to upgrade usage" : "zh-tw" === i2 ? "聯繫客服升級用量" : "aiUsage_contactSupport";
}, gl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Contact Support" : "zh-tw" === i2 ? "聯繫客服" : "aiUsage_contactService";
}, vl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Consider upgrading" : "zh-tw" === i2 ? "考慮升級方案" : "aiUsage_considerUpgrade";
}, bl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "You can continue using AI features" : "zh-tw" === i2 ? "您可以繼續使用 AI 功能" : "aiUsage_canContinue";
}, _l = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage Information" : "zh-tw" === i2 ? "使用量說明" : "aiUsage_usageInfo";
}, yl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "As a VIP user, you already enjoy the highest tier of AI usage. Contact our support team if you need more." : "zh-tw" === i2 ? "作為 VIP 用戶，您已享有最高等級的 AI 使用量。如需更多用量，請聯繫我們的客服團隊。" : "aiUsage_vipInfoDesc";
}, wl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Your current VIP plan does not include AI features. Upgrade to an AI plan to use AI optimization features." : "zh-tw" === i2 ? "您目前的 VIP 方案不包含 AI 功能。升級至 AI 方案即可使用 AI 優化功能。" : "aiUsage_vipNoAiInfoDesc";
}, xl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Upgrade your plan for more AI usage, or contact support for a custom plan." : "zh-tw" === i2 ? "升級您的方案以獲得更多 AI 使用量，或聯繫客服了解客製化方案。" : "aiUsage_defaultInfoDesc";
}, kl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Usage Tips" : "zh-tw" === i2 ? "使用建議" : "aiUsage_usageTips";
}, Sl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Check your usage regularly to avoid hitting the limit unexpectedly" : "zh-tw" === i2 ? "定期檢查使用量，避免突然達到上限" : "aiUsage_tip1";
}, Ml = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Consider upgrading your plan for more usage" : "zh-tw" === i2 ? "考慮升級方案以獲得更多使用量" : "aiUsage_tip2";
}, zl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Contact support for custom plans" : "zh-tw" === i2 ? "聯繫客服了解客製化方案" : "aiUsage_tip3";
}, Cl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Login to view and manage strategies" : "zh-tw" === i2 ? "登入以查看與管理策略" : "sidebar_loginToManage";
}, Dl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Login to create, sort, rename, and delete strategies" : "zh-tw" === i2 ? "登入後可建立、排序、重新命名與刪除策略" : "sidebar_loginDescription";
}, Rl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Nothing here yet (but full of potential)" : "zh-tw" === i2 ? "這裡好空喔（但很有潛力）" : "sidebar_emptyState";
}, Pl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Let AI come up with a fun and profitable strategy!" : "zh-tw" === i2 ? "讓 AI 想個有趣又有料的策略吧！" : "sidebar_emptyHint";
}, Tl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Join Discussion" : "zh-tw" === i2 ? "一起討論" : "sidebar_discuss";
}, $l = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Join Discord Community" : "zh-tw" === i2 ? "加入 Discord 社群" : "sidebar_joinDiscord";
}, El = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Custom Sort" : "zh-tw" === i2 ? "自訂排序" : "sidebar_customSort";
}, Al = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Last Updated" : "zh-tw" === i2 ? "最近更新" : "sidebar_lastUpdated";
}, Ll = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Quarterly Return" : "zh-tw" === i2 ? "季報酬" : "sidebar_quarterlyReturn";
}, Vl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual Return" : "zh-tw" === i2 ? "年化報酬" : "sidebar_annualReturn";
}, Ol = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sharpe Ratio" : "zh-tw" === i2 ? "夏普比率" : "sidebar_sharpeRatio";
}, Il = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Drawdown" : "zh-tw" === i2 ? "最大跌幅" : "sidebar_maxDrawdown";
}, Nl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Metrics: On" : "zh-tw" === i2 ? "指標：開" : "sidebar_metricsOn";
}, Fl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Metrics: Off" : "zh-tw" === i2 ? "指標：關" : "sidebar_metricsOff";
}, Wl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual" : "zh-tw" === i2 ? "年化" : "sidebar_annualized";
}, Bl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sharpe" : "zh-tw" === i2 ? "夏普" : "sidebar_sharpe";
}, jl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown" : "zh-tw" === i2 ? "下跌" : "sidebar_drawdown";
}, ql = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rename" : "zh-tw" === i2 ? "重新命名" : "sidebar_renameStrategy";
}, Hl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Delete Strategy" : "zh-tw" === i2 ? "刪除策略" : "sidebar_deleteStrategy";
}, Ul = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Run Strategy" : "zh-tw" === i2 ? "執行策略" : "sidebar_runStrategy";
}, Kl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Enter name" : "zh-tw" === i2 ? "輸入名稱" : "sidebar_enterName";
}, Yl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Waiting to run" : "zh-tw" === i2 ? "等待執行" : "sidebar_waitingToRun";
}, Gl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Running" : "zh-tw" === i2 ? "執行中" : "sidebar_running";
}, Xl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Terms of Service" : "zh-tw" === i2 ? "服務條款" : "sidebar_termsOfService";
}, Jl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sort By" : "zh-tw" === i2 ? "排序方式" : "sidebar_sortBy";
}, Ql = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Toggle Metrics" : "zh-tw" === i2 ? "切換指標" : "sidebar_toggleMetrics";
}, Zl = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "More" : "zh-tw" === i2 ? "更多" : "sidebar_more";
}, th = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Allow AI to auto-switch panel" : "zh-tw" === i2 ? "允許 AI 自動切換面板" : "pane_allowAiSwitch";
}, eh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Save the strategy before leaving? Click OK to save and leave; click Cancel to stay." : "zh-tw" === i2 ? "離開此頁前要儲存策略嗎？按「確定」將儲存並離開；按「取消」留在此頁。" : "pane_leavePageConfirm";
}, ih = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Light" : "zh-tw" === i2 ? "淺色" : "theme_light";
}, sh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Dark" : "zh-tw" === i2 ? "深色" : "theme_dark";
}, nh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "System" : "zh-tw" === i2 ? "系統跟隨" : "theme_system";
}, rh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Theme" : "zh-tw" === i2 ? "主題" : "theme_label";
}, oh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≥ 15%" : "zh-tw" === i2 ? "需 ≥ 15%" : "quality_needGte15";
}, ah = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≥ 10%" : "zh-tw" === i2 ? "需 ≥ 10%" : "quality_needGte10";
}, lh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need between 0–0.8" : "zh-tw" === i2 ? "需介於 0–0.8" : "quality_needBetween0and08";
}, hh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≥ 5 stocks" : "zh-tw" === i2 ? "需 ≥ 5 檔" : "quality_needGte5stocks";
}, ch = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≤ 20 stocks" : "zh-tw" === i2 ? "需 ≤ 20 檔" : "quality_needLte20stocks";
}, uh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 30%" : "zh-tw" === i2 ? "需 < 30%" : "quality_needLt30";
}, dh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 10%" : "zh-tw" === i2 ? "需 < 10%" : "quality_needLt10";
}, fh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 40 days" : "zh-tw" === i2 ? "需 < 40 天" : "quality_needLt40days";
}, ph = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 20%" : "zh-tw" === i2 ? "需 < 20%" : "quality_needLt20";
}, mh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 7%" : "zh-tw" === i2 ? "需 < 7%" : "quality_needLt7";
}, gh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 1.3" : "zh-tw" === i2 ? "需 > 1.3" : "quality_needGt13";
}, vh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 1.8" : "zh-tw" === i2 ? "需 > 1.8" : "quality_needGt18";
}, bh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 0.9" : "zh-tw" === i2 ? "需 > 0.9" : "quality_needGt09";
}, _h = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 1.5" : "zh-tw" === i2 ? "需 > 1.5" : "quality_needGt15";
}, yh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 1.0" : "zh-tw" === i2 ? "需 > 1.0" : "quality_needGt10";
}, wh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 55%" : "zh-tw" === i2 ? "需 > 55%" : "quality_needGt55";
}, xh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need > 70%" : "zh-tw" === i2 ? "需 > 70%" : "quality_needGt70";
}, kh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≥ 2%" : "zh-tw" === i2 ? "需 ≥ 2%" : "quality_needGte2";
}, Sh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need ≥ 500K" : "zh-tw" === i2 ? "需 ≥ 50 萬" : "quality_needGte500k";
}, Mh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Need < 5%" : "zh-tw" === i2 ? "需 < 5%" : "quality_needLt5";
}, zh = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Cumulative return chart. Purple = strategy, gray = benchmark. Annualized return: <strong>${(s2 = t2).ar}</strong>, Alpha: <strong>${s2.al}</strong>, average holdings: <strong>${s2.nstock}</strong>. Click year buttons below to focus on a specific year.` : "zh-tw" === i2 ? ((t3) => `策略的累計報酬走勢圖。紫色線為策略，灰色線為大盤。年化報酬率為 <strong>${t3.ar}</strong>，相對大盤產生了 <strong>${t3.al}</strong> 的 Alpha，期間平均持有 <strong>${t3.nstock}</strong> 股票。點選下方年份按鈕可聚焦到特定年度的表現。`)(t2) : "insight_profitability_historicalReturn";
  var s2;
}, Ch = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Heatmap of monthly returns — darker color = higher return. Spot seasonal patterns such as consistently strong or weak months. Click a cell to view holdings for that period." : "zh-tw" === i2 ? "以熱力圖呈現每月報酬率，顏色越深代表報酬越高。可用來觀察策略是否有明顯的<strong>季節性規律</strong>，例如特定月份表現特別好或特別差。點擊月份格子可查看對應的持股報酬。" : "insight_profitability_monthlyReturn";
}, Dh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stocks held during the selected period and their returns. Combine with the 'Historical Return' chart — click a year/month, then switch here to see which stocks were actually bought." : "zh-tw" === i2 ? "列出策略在選定期間內持有的個股及其報酬。可搭配上方「歷史績效」的圖表互動，點選特定年月後切換到此頁，即可查看<strong>該期間實際買了哪些股票</strong>及各自表現。" : "insight_profitability_stockList";
}, Rh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Annual return comparison: purple = strategy, gray = benchmark. Quickly see which years the strategy beat the benchmark and which years it lagged." : "zh-tw" === i2 ? "比較策略和大盤每年的報酬率。紫色柱為策略，灰色柱為大盤。可以快速看出策略在哪些年份<strong>贏過大盤</strong>、哪些年份落後，幫助判斷策略的穩定性。" : "insight_profitability_yearlyCompare";
}, Ph = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Excess return = strategy return − benchmark return. Positive = outperformed. See whether the strategy's edge is consistent or sporadic." : "zh-tw" === i2 ? "超額報酬 = 策略報酬 − 大盤報酬。正值代表策略<strong>優於大盤</strong>，負值代表落後。透過這張圖可以看出策略相對大盤的附加價值是否穩定，還是偶爾才出現超額收益。" : "insight_profitability_excessReturn";
}, Th = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Worst drawdown periods. Max drawdown: <strong>${(s2 = t2).md}</strong>, average drawdown: <strong>${s2.addDays}</strong>. Click a card to view that drawdown's detailed trajectory and recovery time.` : "zh-tw" === i2 ? ((t3) => `歷史上最嚴重的回撤時期。最大回撤為 <strong>${t3.md}</strong>，平均回撤持續 <strong>${t3.addDays}</strong>。點選上方卡片可查看<strong>各次回撤的詳細走勢</strong>，並觀察策略從低點恢復到新高所需的時間。`)(t2) : "insight_risk_drawdownPeriods";
  var s2;
}, $h = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stocks held during drawdown periods. Use with 'Drawdown Periods' — select a drawdown, then switch here to see which stocks caused the loss." : "zh-tw" === i2 ? "回撤期間策略持有的個股及其報酬表現。可搭配「虧損歷史」圖表互動使用——先點選特定回撤時期，再切換到此頁查看<strong>當時持有哪些股票造成虧損</strong>。" : "insight_risk_stockList";
}, Eh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Top 10 worst drawdowns ranked by magnitude. Toggle strategy vs benchmark. Click a circle to jump to that period on the chart." : "zh-tw" === i2 ? "將歷史上最嚴重的 <strong>10 次回撤</strong>依跌幅排名。可切換比較策略 vs 大盤。點擊各回撤圓圈可在圖表上查看對應時期走勢，直觀了解每次重大虧損的嚴重程度。" : "insight_risk_drawdownRanking";
}, Ah = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Days needed to reach a new high after each drawdown. Fewer days = stronger recovery. Toggle strategy vs benchmark comparison." : "zh-tw" === i2 ? "統計每次回撤後，策略需要多少天才能<strong>再次創新高</strong>。天數越短代表策略恢復力越強。可切換比較策略 vs 大盤的恢復速度。" : "insight_risk_recoveryTime";
}, Lh = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Full historical drawdown chart. Volatility: <strong>${t2.vol}</strong>. Observe how drawdown depth varies across market conditions and whether it improves or worsens over time.` : "zh-tw" === i2 ? `完整的歷史回檔幅度走勢圖，策略整體波動度為 <strong>${t2.vol}</strong>。可以觀察策略在不同市場環境下的<strong>回撤深度變化</strong>，以及是否有逐漸惡化或改善的趨勢。` : "insight_risk_drawdownPercentage";
}, Vh = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Rolling Sharpe ratio: <strong>${t2.sr}</strong>. Higher = better risk-adjusted return. The right chart compares yearly Sharpe with the benchmark.` : "zh-tw" === i2 ? `滾動夏普比率為 <strong>${t2.sr}</strong>，衡量每承受一單位風險能獲得多少報酬。值越高代表<strong>風險調整後表現越好</strong>。右圖為每年的夏普值與大盤比較，可觀察策略在不同年份的風報比穩定性。` : "insight_ratio_sharpe";
}, Oh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Tail Ratio measures extreme positive vs extreme negative returns. Above 1 means extreme gains outweigh extreme losses. The right chart shows yearly comparison." : "zh-tw" === i2 ? "Tail Ratio 衡量策略的極端正報酬與極端負報酬的比值。值大於 1 表示策略的<strong>上行尾部風險優於下行風險</strong>，代表極端行情下策略表現偏正面。右圖為每年比較。" : "insight_ratio_tailRatio";
}, Ih = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Rolling volatility: purple = strategy, gray = benchmark. Check if strategy volatility stays below benchmark and how it spikes during market stress. Sortino: <strong>${t2.so}</strong>.` : "zh-tw" === i2 ? `滾動波動度走勢圖，紫色線為策略，灰色線為大盤。可觀察策略波動度是否<strong>長期低於大盤</strong>，以及在市場動盪時期波動度是否會急劇上升。Sortino 比率為 <strong>${t2.so}</strong>。` : "insight_ratio_volatility";
}, Nh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Rolling correlation between strategy and benchmark. Near 1 = highly correlated, near 0 = independent. Low-correlation strategies are valuable for portfolio diversification." : "zh-tw" === i2 ? "策略報酬與大盤報酬的滾動相關係數。值接近 1 代表高度正相關，接近 0 代表<strong>策略走勢較獨立</strong>。低相關性的策略在資產配置中特別有價值，能有效分散風險。" : "insight_ratio_correlation";
}, Fh = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Distribution of all trade returns. Win rate: <strong>${(s2 = t2).wr}</strong>, per-trade expectancy: <strong>${s2.exp}</strong>. Check for positive skew (longer right tail) and where most trades cluster.` : "zh-tw" === i2 ? ((t3) => `策略所有交易的報酬分布直方圖。整體勝率為 <strong>${t3.wr}</strong>，單筆期望值為 <strong>${t3.exp}</strong>。可觀察報酬是否呈現<strong>正偏態</strong>（右尾較長），以及大部分交易集中在哪個報酬區間。`)(t2) : "insight_winrate_returnDistribution";
  var s2;
}, Wh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulates how performance changes at different stop-loss levels. Drag the slider to adjust. If performance improves, the strategy may benefit from stop-loss protection." : "zh-tw" === i2 ? "模擬在不同停損點下策略績效會如何變化。拖動滑桿調整停損比例，觀察<strong>加入停損機制後</strong>勝率和整體報酬的變化。若績效提升，代表策略可能受益於停損保護。" : "insight_winrate_stopLoss";
}, Bh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulates performance at different take-profit levels. Drag the slider to adjust. If performance drops, profits mainly come from a few big winners." : "zh-tw" === i2 ? "模擬在不同停利點下策略績效會如何變化。拖動滑桿調整停利比例，觀察<strong>加入停利機制後</strong>的報酬變化。若績效下降，代表策略的獲利主要來自少數大幅上漲的交易。" : "insight_winrate_takeProfit";
}, jh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "MAE = max floating loss during a trade, MFE = max floating gain. The scatter plot reveals risk-reward characteristics and systematic biases." : "zh-tw" === i2 ? "MAE（最大不利偏移）= 持有期間的最大浮虧，MFE（最大有利偏移）= 持有期間的最大浮盈。透過兩者的散布圖，可觀察<strong>交易的風險報酬特性</strong>及是否存在系統性偏移。" : "insight_winrate_maeMfe";
}, qh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Evaluates how much capital the strategy can handle. As investment grows, some trades get excluded due to insufficient volume, potentially reducing returns." : "zh-tw" === i2 ? "評估策略可承載的資金規模。隨著投入金額增加，部分交易會因為<strong>成交量不足而被排除</strong>，報酬可能下降。柱狀為可參與交易比例，紅線為對應的中位數報酬。" : "insight_liquidity_portfolioCapacity";
}, Hh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Analyzes how entry-day volume thresholds affect performance. Higher thresholds mean fewer eligible trades but lower liquidity risk." : "zh-tw" === i2 ? "分析進場時的成交量門檻對績效影響。門檻越高，能參與的交易越少，但<strong>流動性風險越低</strong>。觀察報酬是否隨門檻提高而顯著變化，可幫助決定合適的成交量篩選條件。" : "insight_liquidity_entryVolume";
}, Uh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Analyzes how exit-day volume thresholds affect performance. Exit liquidity matters too — insufficient volume at exit can cause slippage losses." : "zh-tw" === i2 ? "分析出場時的成交量門檻對績效影響。出場流動性同樣重要——即使進場順利，若<strong>出場時成交量不足</strong>可能造成滑價損失。觀察不同門檻下報酬率的穩定性。" : "insight_liquidity_exitVolume";
}, Kh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Unnamed Strategy" : "zh-tw" === i2 ? "未命名策略" : "unnamed_strategy";
}, Yh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Unlimited" : "zh-tw" === i2 ? "無限期" : "sub_unlimited";
}, Gh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Manage" : "zh-tw" === i2 ? "管理" : "sub_manage";
}, Xh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Change Credit Card" : "zh-tw" === i2 ? "更換信用卡" : "sub_changeCreditCard";
}, Jh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Change Plan" : "zh-tw" === i2 ? "更改方案" : "sub_changePlan";
}, Qh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cancelling..." : "zh-tw" === i2 ? "取消中..." : "sub_cancelling";
}, Zh = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Cancel Subscription" : "zh-tw" === i2 ? "取消訂閱" : "sub_cancelSubscription";
}, tc = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Thank you for subscribing to the ${t2.plan} plan. Includes` : "zh-tw" === i2 ? `感謝您訂閱 ${t2.plan} 方案，包含` : "sub_thankYou";
}, ec = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Your plan will auto-renew on ${t2.date}` : "zh-tw" === i2 ? `您的方案將於 ${t2.date} 自動續訂` : "sub_autoRenew";
}, ic = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `Your plan will expire on ${t2.date}` : "zh-tw" === i2 ? `您的方案將於 ${t2.date} 到期` : "sub_expireAt";
}, sc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "You are currently on the free trial plan" : "zh-tw" === i2 ? "您目前是免費試用方案" : "sub_freeTrial";
}, nc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Unable to retrieve subscription data" : "zh-tw" === i2 ? "無法獲取訂閱資料" : "sub_cannotGetSubscription";
}, rc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Unable to retrieve user ID" : "zh-tw" === i2 ? "無法獲取用戶 ID" : "sub_cannotGetUserId";
}, oc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Failed to cancel subscription" : "zh-tw" === i2 ? "取消訂閱失敗" : "sub_cancelFailed";
}, ac = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Free after-hours price data" : "zh-tw" === i2 ? "免費盤後價格資料" : "sub_free_feature1";
}, lc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "3 sample strategies" : "zh-tw" === i2 ? "3 個策略範例" : "sub_free_feature2";
}, hc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Listed stock data 2013–2018" : "zh-tw" === i2 ? "上市櫃資料 2013～2018 年" : "sub_free_feature3";
}, cc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Daily data download: 500 MB" : "zh-tw" === i2 ? "每日資料下載：500 MB" : "sub_free_feature4";
}, uc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Trading statistics dashboard" : "zh-tw" === i2 ? "交易統計儀表板" : "sub_free_feature5";
}, dc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All Free plan features" : "zh-tw" === i2 ? "Free 會員所有功能" : "sub_vip_feature1";
}, fc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "30+ premium Alpha strategies" : "zh-tw" === i2 ? "30 種以上具有 Alpha 的高級策略" : "sub_vip_feature2";
}, pc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Listed, OTC & emerging market data from 2010" : "zh-tw" === i2 ? "上市、上櫃、興櫃資料 2010 至今" : "sub_vip_feature3";
}, mc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Top 15 brokerage branches" : "zh-tw" === i2 ? "前 15 大分點券商" : "sub_vip_feature4";
}, gc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Full historical backtesting" : "zh-tw" === i2 ? "完整歷史回測" : "sub_vip_feature5";
}, vc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Daily data download: 5000 MB" : "zh-tw" === i2 ? "每日資料下載：5000 MB" : "sub_vip_feature6";
}, bc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Auto scheduling & order execution" : "zh-tw" === i2 ? "自動排程與下單" : "sub_vip_feature7";
}, _c = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "30+ premium Alpha strategies" : "zh-tw" === i2 ? "30 種以上具有 Alpha 的高級策略" : "sub_ai_feature1";
}, yc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Listed, OTC & emerging market data from 2010" : "zh-tw" === i2 ? "上市、上櫃、興櫃資料 2010 至今" : "sub_ai_feature2";
}, wc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Top 15 brokerage branches" : "zh-tw" === i2 ? "前 15 大分點券商" : "sub_ai_feature3";
}, xc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Full historical backtesting" : "zh-tw" === i2 ? "完整歷史回測" : "sub_ai_feature4";
}, kc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Daily data download: 5000 MB" : "zh-tw" === i2 ? "每日資料下載：5000 MB" : "sub_ai_feature5";
}, Sc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Auto scheduling & order execution" : "zh-tw" === i2 ? "自動排程與下單" : "sub_ai_feature6";
}, Mc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI optimization: ~50 times/month (Gemini flash)" : "zh-tw" === i2 ? "AI 優化：約 50 次/月(Gemini flash)" : "sub_ai_feature7";
}, zc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Advanced AI Gemini 2.5 Pro" : "zh-tw" === i2 ? "高級 AI Gemini 2.5 Pro" : "sub_ai_feature8";
}, Cc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI optimization directions: 3 per run" : "zh-tw" === i2 ? "AI 優化方向：每次 3 個" : "sub_ai_feature9";
}, Dc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Custom optimization system prompts" : "zh-tw" === i2 ? "客製化優化系統提示詞" : "sub_ai_feature10";
}, Rc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All AI plan features" : "zh-tw" === i2 ? "AI 所有功能" : "sub_max_feature1";
}, Pc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "AI optimization: ~800 times/month (Gemini flash)" : "zh-tw" === i2 ? "AI 優化：約 800 次/月(Gemini flash)" : "sub_max_feature2";
}, Tc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "One-click auto optimization" : "zh-tw" === i2 ? "一鍵執行自動優化" : "sub_max_feature3";
}, $c = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All VIP plan features" : "zh-tw" === i2 ? "VIP 所有功能" : "sub_team_feature1";
}, Ec = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Multi-account strategy sharing" : "zh-tw" === i2 ? "支援多帳號共享策略" : "sub_team_feature2";
}, Ac = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Multi-strategy dashboard" : "zh-tw" === i2 ? "多策略儀表板" : "sub_team_feature3";
}, Lc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Asset allocation algorithms" : "zh-tw" === i2 ? "資產配置演算法" : "sub_team_feature4";
}, Vc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Full offline mode" : "zh-tw" === i2 ? "完全離線模式" : "sub_team_feature5";
}, Oc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Historical Performance" : "zh-tw" === i2 ? "歷史績效" : "chart_historicalPerformance";
}, Ic = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly Performance" : "zh-tw" === i2 ? "年度表現" : "chart_yearlyPerformance";
}, Nc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "All" : "zh-tw" === i2 ? "全部" : "chart_all";
}, Fc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Monthly Return" : "zh-tw" === i2 ? "月報酬" : "chart_monthlyReturn";
}, Wc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Average Monthly Return" : "zh-tw" === i2 ? "每月平均報酬率" : "chart_avgMonthlyReturn";
}, Bc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "M" : "zh-tw" === i2 ? "月" : "chart_month";
}, jc = (t2, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? `${t2.v1}M` : "zh-tw" === i2 ? `${t2.v1}月` : "chart_monthSuffix";
}, qc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Stock Return" : "zh-tw" === i2 ? "持股報酬" : "chart_stockReturn";
}, Hc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly vs Benchmark Return" : "zh-tw" === i2 ? "與大盤年報酬比較" : "chart_yearlyVsBenchmark";
}, Uc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Excess Return" : "zh-tw" === i2 ? "超額報酬" : "chart_excessReturn";
}, Kc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown History" : "zh-tw" === i2 ? "虧損歷史" : "chart_drawdownHistory";
}, Yc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "New High" : "zh-tw" === i2 ? "再次創新高" : "chart_newHigh";
}, Gc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "d" : "zh-tw" === i2 ? "天" : "chart_day";
}, Xc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown Ranking" : "zh-tw" === i2 ? "跌幅排名" : "chart_drawdownRanking";
}, Jc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "New High Time Ranking" : "zh-tw" === i2 ? "再次創新高時間排名" : "chart_newHighTimeRanking";
}, Qc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Drawdown Depth" : "zh-tw" === i2 ? "回檔幅度" : "chart_drawdownDepth";
}, Zc = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Y" : "zh-tw" === i2 ? "年" : "chart_year";
}, tu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Q" : "zh-tw" === i2 ? "季" : "chart_quarter";
}, eu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Sharpe Ratio" : "zh-tw" === i2 ? "夏普比率" : "chart_sharpeRatio";
}, iu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly Sharpe vs Benchmark" : "zh-tw" === i2 ? "每年夏普與大盤比較" : "chart_yearlySharpeVsBenchmark";
}, su = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Yearly Tail Ratio" : "zh-tw" === i2 ? "每年極端風報比" : "chart_yearlyTailRatio";
}, nu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Strategy Return Volatility" : "zh-tw" === i2 ? "策略報酬率波動" : "chart_strategyVolatility";
}, ru = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Return Distribution" : "zh-tw" === i2 ? "報酬分布" : "chart_returnDistribution";
}, ou = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulated Stop Loss" : "zh-tw" === i2 ? "模擬停損" : "chart_simulatedStopLoss";
}, au = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Simulated Take Profit" : "zh-tw" === i2 ? "模擬停利" : "chart_simulatedTakeProfit";
}, lu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "Max Trade Deviation (MAE/MFE)" : "zh-tw" === i2 ? "交易最大偏移" : "chart_maxTradeDeviation";
}, hu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "00M" : "zh-tw" === i2 ? "億" : "chart_hundred_million";
}, cu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "0M" : "zh-tw" === i2 ? "千萬" : "chart_ten_million";
}, uu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "M" : "zh-tw" === i2 ? "百萬" : "chart_million";
}, du = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "0K" : "zh-tw" === i2 ? "萬" : "chart_ten_thousand";
}, fu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "above" : "zh-tw" === i2 ? "以上" : "chart_above";
}, pu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "TWD" : "zh-tw" === i2 ? "元" : "chart_currency";
}, mu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "shares" : "zh-tw" === i2 ? "張" : "chart_shares";
}, gu = (t2 = {}, e2 = {}) => {
  const i2 = e2.locale ?? r();
  return "en" === i2 ? "lots" : "zh-tw" === i2 ? "張" : "chart_lots";
}, vu = Object.freeze(Object.defineProperty({ __proto__: null, actionButton: f, aiUsage_aiUser: nl, aiUsage_canContinue: bl, aiUsage_considerUpgrade: vl, aiUsage_contactService: gl, aiUsage_contactSupport: ml, aiUsage_currentUsage: el, aiUsage_defaultInfoDesc: xl, aiUsage_description: tl, aiUsage_freeUser: rl, aiUsage_limitReached: ll, aiUsage_limitReachedDesc: pl, aiUsage_limitReachedTitle: fl, aiUsage_nearLimit: hl, aiUsage_progress: ol, aiUsage_tip1: Sl, aiUsage_tip2: Ml, aiUsage_tip3: zl, aiUsage_tracking: Za, aiUsage_usageInfo: _l, aiUsage_usageNormal: cl, aiUsage_usageProgress: al, aiUsage_usageTips: kl, aiUsage_vipInfoDesc: yl, aiUsage_vipLimitDesc: dl, aiUsage_vipLimitReached: ul, aiUsage_vipNoAi: sl, aiUsage_vipNoAiInfoDesc: wl, aiUsage_vipUser: il, average: g, benchmark: m, chart_above: fu, chart_all: Nc, chart_avgMonthlyReturn: Wc, chart_currency: pu, chart_day: Gc, chart_drawdownDepth: Qc, chart_drawdownHistory: Kc, chart_drawdownRanking: Xc, chart_excessReturn: Uc, chart_historicalPerformance: Oc, chart_hundred_million: hu, chart_lots: gu, chart_maxTradeDeviation: lu, chart_million: uu, chart_month: Bc, chart_monthSuffix: jc, chart_monthlyReturn: Fc, chart_newHigh: Yc, chart_newHighTimeRanking: Jc, chart_quarter: tu, chart_returnDistribution: ru, chart_shares: mu, chart_sharpeRatio: eu, chart_simulatedStopLoss: ou, chart_simulatedTakeProfit: au, chart_stockReturn: qc, chart_strategyVolatility: nu, chart_ten_million: cu, chart_ten_thousand: du, chart_year: Zc, chart_yearlyPerformance: Ic, chart_yearlySharpeVsBenchmark: iu, chart_yearlyTailRatio: su, chart_yearlyVsBenchmark: Hc, common_cancel: go, common_close: mo, common_confirm: vo, common_copy: yo, common_delete: bo, common_loading: Co, common_login: co, common_logout: uo, common_myPlan: zo, common_newStrategy: ko, common_rename: _o, common_run: wo, common_save: po, common_search: xo, common_searchStrategies: So, common_settings: fo, common_upgradePlan: Mo, dataUsage_askDiscord: $o, dataUsage_dataUsage: Ro, dataUsage_loadFailed: Po, dataUsage_requestReset: To, dataUsage_resetInfo: Eo, dataUsage_todayUsage: Do, general_apiKey: Da, general_deleteAll: Ea, general_deleteAllStrategies: $a, general_deleteAndReset: Ta, general_resetApiKey: Ra, general_resetting: Pa, googleAi_authInstructions: Ba, googleAi_authPageFailed: Ya, googleAi_connect: Fa, googleAi_connectFailed: Xa, googleAi_connectSuccess: Ga, googleAi_connected: La, googleAi_connectionStatus: Aa, googleAi_disconnect: Oa, googleAi_disconnectBtn: Na, googleAi_disconnectFailed: Qa, googleAi_disconnectSuccess: Ja, googleAi_disconnected: Va, googleAi_disconnecting: Ia, googleAi_maxOnly: Wa, googleAi_pasteCode: ja, googleAi_submit: Ha, googleAi_useOwnQuota: Ua, googleAi_useOwnQuotaDesc: Ka, googleAi_verifying: qa, header_aiAutoOptimize: fa, header_aiOptimize: ta, header_aiOptimizing: ma, header_analyze: Qo, header_closePanel: ra, header_copyAndSave: aa, header_copyStrategy: la, header_exitFullscreen: ia, header_fullscreen: ea, header_minimize: sa, header_moreOptions: ha, header_notebook: Zo, header_panorama: na, header_plan: va, header_pleaseLogin: ua, header_position: Jo, header_saveStrategy: ca, header_stop: ga, header_strategy: Xo, header_toggleSidebar: oa, header_upgradeVipToFork: da, header_userMenu: pa, insight_liquidity_entryVolume: Hh, insight_liquidity_exitVolume: Uh, insight_liquidity_portfolioCapacity: qh, insight_profitability_excessReturn: Ph, insight_profitability_historicalReturn: zh, insight_profitability_monthlyReturn: Ch, insight_profitability_stockList: Dh, insight_profitability_yearlyCompare: Rh, insight_ratio_correlation: Nh, insight_ratio_sharpe: Vh, insight_ratio_tailRatio: Oh, insight_ratio_volatility: Ih, insight_risk_drawdownPercentage: Lh, insight_risk_drawdownPeriods: Th, insight_risk_drawdownRanking: Eh, insight_risk_recoveryTime: Ah, insight_risk_stockList: $h, insight_winrate_maeMfe: jh, insight_winrate_returnDistribution: Fh, insight_winrate_stopLoss: Wh, insight_winrate_takeProfit: Bh, metric_description_backtest_endDate: _n, metric_description_backtest_feeRatio: zn, metric_description_backtest_freq: An, metric_description_backtest_livePerformanceStart: Nn, metric_description_backtest_market: En, metric_description_backtest_nextTradingDate: In, metric_description_backtest_startDate: bn, metric_description_backtest_stopLoss: Fn, metric_description_backtest_takeProfit: Wn, metric_description_backtest_taxRatio: Cn, metric_description_backtest_tradeAt: $n, metric_description_backtest_updateDate: On, metric_description_backtest_version: Sn, metric_description_liquidity_buyHigh: gr, metric_description_liquidity_capacity: dr, metric_description_liquidity_disposalStockRatio: fr, metric_description_liquidity_fullDeliveryStockRatio: mr, metric_description_liquidity_sellLow: vr, metric_description_liquidity_warningStockRatio: pr, metric_description_profitability_alpha: qn, metric_description_profitability_annualReturn: Bn, metric_description_profitability_avgNStock: Yn, metric_description_profitability_beta: Kn, metric_description_profitability_maxNStock: Gn, metric_description_ratio_calmarRatio: nr, metric_description_ratio_profitFactor: rr, metric_description_ratio_sharpeRatio: ir, metric_description_ratio_sortinoRatio: sr, metric_description_ratio_tailRatio: or, metric_description_risk_avgDrawdown: Jn, metric_description_risk_avgDrawdownDays: Qn, metric_description_risk_cvalueAtRisk: er, metric_description_risk_maxDrawdown: Xn, metric_description_risk_valueAtRisk: tr, metric_description_risk_volatility: Zn, metric_description_winrate_expectancy: hr, metric_description_winrate_m12WinRate: lr, metric_description_winrate_mae: cr, metric_description_winrate_mfe: ur, metric_description_winrate_winRate: ar, metrics_backtest_endDate: L, metrics_backtest_feeRatio: O, metrics_backtest_freq: B, metrics_backtest_livePerformanceStart: K, metrics_backtest_market: F, metrics_backtest_nextTradingDate: U, metrics_backtest_startDate: A, metrics_backtest_stopLoss: G, metrics_backtest_takeProfit: J, metrics_backtest_taxRatio: I, metrics_backtest_tradeAt: N, metrics_backtest_updateDate: q, metrics_backtest_version: V, metrics_condition: br, metrics_liquidity_averageReturn: qs, metrics_liquidity_buyHigh: le, metrics_liquidity_capacity: ne, metrics_liquidity_disposalStockRatio: re, metrics_liquidity_entryVolume: Zs, metrics_liquidity_entryVolumeDescription: on, metrics_liquidity_exitVolume: Qs, metrics_liquidity_exitVolumeDescription: an, metrics_liquidity_fullDeliveryStockRatio: ae, metrics_liquidity_marketCap: Us, metrics_liquidity_marketCapDescription: rn, metrics_liquidity_marketCapThreshold: en, metrics_liquidity_portfolioCapacity: Bs, metrics_liquidity_portfolioCapacityDescription: sn, metrics_liquidity_safeLiquidityTradeRatio: js, metrics_liquidity_sellLow: he, metrics_liquidity_smallCapRatio: ie, metrics_liquidity_totalInvestment: Hs, metrics_liquidity_tradeRatio: Ks, metrics_liquidity_tradeRatioEntryVolume: Gs, metrics_liquidity_tradeRatioExitVolume: Xs, metrics_liquidity_tradeRatioMarketCap: Ys, metrics_liquidity_volumeThreshold: Js, metrics_liquidity_warningStockRatio: oe, metrics_profitability_alpha: tt, metrics_profitability_annualReturn: Q, metrics_profitability_avgNStock: at, metrics_profitability_beta: et, metrics_profitability_maxNStock: ct, metrics_ratio_betterThanBenchmark: ms, metrics_ratio_calmarRatio: Rt, metrics_ratio_profitFactor: At, metrics_ratio_rollingTailRatio: ln, metrics_ratio_sharpeRatio: zt, metrics_ratio_sortinoRatio: Ct, metrics_ratio_tailRatio: Lt, metrics_ratio_timeBetterThanBenchmark: vs, metrics_ratio_volatility: _s, metrics_ratio_worseThanBenchmark: Ot, metrics_ratio_year: gs, metrics_ratio_yearlySharpeRatio: fs, metrics_ratio_yearlyTailRatio: bs, metrics_risk_avgDrawdown: mt, metrics_risk_avgDrawdownDays: gt, metrics_risk_cvalueAtRisk: yt, metrics_risk_days: Mt, metrics_risk_maxDrawdown: dt, metrics_risk_newHighTimeRank: wt, metrics_risk_valueAtRisk: _t, metrics_risk_volatility: bt, metrics_risk_worst10Benchmark: kt, metrics_risk_worst10Strategy: xt, metrics_risk_worstDrawdownPeriod: pn, metrics_stocks_bmfe: xe, metrics_stocks_entry: de, metrics_stocks_entryPrice: me, metrics_stocks_entrySig: ve, metrics_stocks_exit: fe, metrics_stocks_exitPrice: ge, metrics_stocks_exitSig: be, metrics_stocks_gmfe: we, metrics_stocks_mae: _e, metrics_stocks_mdd: Se, metrics_stocks_pdays: ze, metrics_stocks_position: pe, metrics_stocks_return: ue, metrics_stocks_stockId: ce, metrics_winrate_distributionInfo1: xs, metrics_winrate_distributionInfo2: ks, metrics_winrate_expectancy: Gt, metrics_winrate_extraProfitLoss: Rs, metrics_winrate_extraProfitLossTakingProfit: Is, metrics_winrate_m12WinRate: Bt, metrics_winrate_mae: te, metrics_winrate_maeReturn: Ts, metrics_winrate_maemfe: Ms, metrics_winrate_mfe: ee, metrics_winrate_mfeReturn: Ws, metrics_winrate_none: Ds, metrics_winrate_return: Ss, metrics_winrate_returnDistribution: ws, metrics_winrate_simulatedStopLoss: $s, metrics_winrate_simulatedTakeProfit: Es, metrics_winrate_stoploss: zs, metrics_winrate_stoplossRatio: Ps, metrics_winrate_takeProfit: As, metrics_winrate_takeProfitRatio: Ns, metrics_winrate_winRate: It, nav_database: ao, nav_myStrategies: ho, nav_navigation: lo, nav_schedule: oo, nav_stockResearch: ro, notebook_category_ai: Ne, notebook_category_algorithm: Le, notebook_category_indicator: Ie, notebook_category_market: Ae, notebook_category_metric: Oe, notebook_category_python: Ee, notebook_category_tool: Ve, notebook_go_public: Te, notebook_private_draft: De, notebook_save_draft: Pe, notebook_update_public: $e, notification_email: Vo, notification_inSite: Ao, notification_monthlyNewsletter: Oo, notification_saveFailed: No, notification_strategySignal: Io, notification_weeklyPost: Lo, pane_allowAiSwitch: th, pane_leavePageConfirm: eh, payment_amount: Ko, payment_changeCreditCard: jo, payment_invoiceNumber: Yo, payment_lastFourDigits: qo, payment_month: Fo, payment_noRecords: Go, payment_noSubscription: Wo, payment_paymentDetails: Bo, payment_paymentTime: Uo, payment_transactionId: Ho, position_RSV: oi, position_action: ds, position_assetName: us, position_close: Ki, position_created: Ye, position_currentPrice: Je, position_currentWeight: Ze, position_dataFreq: Ke, position_entryDate: Ge, position_entryTradePrice: qe, position_exitDate: Xe, position_exitTradePrice: He, position_high_low_avg: Xi, position_nextWeight: ii, position_open: Hi, position_open_close_avg: Yi, position_profit: Qe, position_resample: je, position_resampleValue_2M: xi, position_resampleValue_2W: vi, position_resampleValue_30M: ui, position_resampleValue_3W: bi, position_resampleValue_4H: fi, position_resampleValue_4W: _i, position_resampleValue_8H: pi, position_resampleValue_D: mi, position_resampleValue_H: di, position_resampleValue_HY: Li, position_resampleValue_M: wi, position_resampleValue_ME: ki, position_resampleValue_MRE: Si, position_resampleValue_Q: Pi, position_resampleValue_QE: Ei, position_resampleValue_W: gi, position_resampleValue_W_Fri: Xr, position_resampleValue_W_Mon: Ur, position_resampleValue_W_Thu: Gr, position_resampleValue_W_Tue: Kr, position_resampleValue_W_Wed: Yr, position_resampleValue_Y: Ii, position_resampleValue_null: Fi, position_scheduled: Ue, position_sl: Fe, position_tp: We, position_ts: Be, position_type_entry: Zi, position_type_entry_f: ts, position_type_exit: es, position_type_exit_p: ss, position_type_hold: ns, position_type_sl: rs, position_type_sl_: hs, position_type_tp: ls, position_type_tp_: cs, profitability_YearlyCompareWithBenchmark: x, profitability_all: mn, profitability_avgMonthlyReturn: w, profitability_benchmarkYearlyReturn: cn, profitability_exceedReturn: S, profitability_historicalReturn: v, profitability_monthlyReturn: _, profitability_monthlyWinRatio: y, profitability_recent: vn, profitability_stockList: b, profitability_year: un, profitability_yearlyReturn: hn, profitability_yearlyWinRate: k, quality_needBetween0and08: lh, quality_needGt09: bh, quality_needGt10: yh, quality_needGt13: gh, quality_needGt15: _h, quality_needGt18: vh, quality_needGt55: wh, quality_needGt70: xh, quality_needGte10: ah, quality_needGte15: oh, quality_needGte2: kh, quality_needGte500k: Sh, quality_needGte5stocks: hh, quality_needLt10: dh, quality_needLt20: ph, quality_needLt30: uh, quality_needLt40days: fh, quality_needLt5: Mh, quality_needLt7: mh, quality_needLte20stocks: ch, ratio_correlation: ys, risk_drawdowPeriods: z, risk_drawdownPercentage: M, settings_aiUsage: Qr, settings_dataDownload: Zr, settings_general: Jr, settings_googleAi: so, settings_language: no, settings_notifications: to, settings_payment: io, settings_subscription: eo, sidebar_annualReturn: Vl, sidebar_annualized: Wl, sidebar_customSort: El, sidebar_deleteStrategy: Hl, sidebar_discuss: Tl, sidebar_drawdown: jl, sidebar_emptyHint: Pl, sidebar_emptyState: Rl, sidebar_enterName: Kl, sidebar_joinDiscord: $l, sidebar_lastUpdated: Al, sidebar_loginDescription: Dl, sidebar_loginToManage: Cl, sidebar_maxDrawdown: Il, sidebar_metricsOff: Fl, sidebar_metricsOn: Nl, sidebar_more: Zl, sidebar_quarterlyReturn: Ll, sidebar_renameStrategy: ql, sidebar_runStrategy: Ul, sidebar_running: Gl, sidebar_sharpe: Bl, sidebar_sharpeRatio: Ol, sidebar_sortBy: Jl, sidebar_termsOfService: Xl, sidebar_toggleMetrics: Ql, sidebar_waitingToRun: Yl, strategy: p, strategy_annualReturn: kr, strategy_betterThanBenchmark: wr, strategy_code: _r, strategy_maxDrawdown: Sr, strategy_period_All: Tr, strategy_period_HY: Rr, strategy_period_M: Cr, strategy_period_Q: Dr, strategy_period_W: zr, strategy_period_Y: Pr, strategy_return: yr, strategy_sharpeRatio: Mr, strategy_tabs_analyze: Er, strategy_tabs_course: Ar, strategy_tabs_notebook: Lr, strategy_tabs_position: $r, strategy_worseThanBenchmark: xr, sub_ai_feature1: _c, sub_ai_feature10: Dc, sub_ai_feature2: yc, sub_ai_feature3: wc, sub_ai_feature4: xc, sub_ai_feature5: kc, sub_ai_feature6: Sc, sub_ai_feature7: Mc, sub_ai_feature8: zc, sub_ai_feature9: Cc, sub_autoRenew: ec, sub_cancelFailed: oc, sub_cancelSubscription: Zh, sub_cancelling: Qh, sub_cannotGetSubscription: nc, sub_cannotGetUserId: rc, sub_changeCreditCard: Xh, sub_changePlan: Jh, sub_expireAt: ic, sub_freeTrial: sc, sub_free_feature1: ac, sub_free_feature2: lc, sub_free_feature3: hc, sub_free_feature4: cc, sub_free_feature5: uc, sub_manage: Gh, sub_max_feature1: Rc, sub_max_feature2: Pc, sub_max_feature3: Tc, sub_team_feature1: $c, sub_team_feature2: Ec, sub_team_feature3: Ac, sub_team_feature4: Lc, sub_team_feature5: Vc, sub_thankYou: tc, sub_unlimited: Yh, sub_vip_feature1: dc, sub_vip_feature2: fc, sub_vip_feature3: pc, sub_vip_feature4: mc, sub_vip_feature5: gc, sub_vip_feature6: vc, sub_vip_feature7: bc, subtitle: d, tabs_liquidity: E, tabs_profitability: C, tabs_ratio: P, tabs_risk: R, tabs_winrate: T, theme_dark: sh, theme_label: rh, theme_light: ih, theme_system: nh, title: u, toast_aiBetterStrategy: ba, toast_autoOptimizeDone: _a, toast_cannotGenerateToken: Sa, toast_cannotGetIdToken: za, toast_confirmResetToken: Ca, toast_forkedAndSaved: xa, toast_notLoggedIn: ka, toast_saveFailed: wa, toast_strategySaved: ya, toast_tokenInvalid: Ma, unnamed_strategy: Kh, viewer_contactAuthor: qr, viewer_finlabStrategies: Vr, viewer_joinToView: jr, viewer_loginToView: Br, viewer_myStrategy: Or, viewer_periodReturn: Wr, viewer_previousPage: Hr, viewer_quantStrategy: Ir, viewer_rename: Nr, viewer_renameFailed: Fr }, Symbol.toStringTag, { value: "Module" })), bu = Object.freeze(Object.defineProperty({ __proto__: null, actionButton: f, aiUsage_aiUser: nl, aiUsage_canContinue: bl, aiUsage_considerUpgrade: vl, aiUsage_contactService: gl, aiUsage_contactSupport: ml, aiUsage_currentUsage: el, aiUsage_defaultInfoDesc: xl, aiUsage_description: tl, aiUsage_freeUser: rl, aiUsage_limitReached: ll, aiUsage_limitReachedDesc: pl, aiUsage_limitReachedTitle: fl, aiUsage_nearLimit: hl, aiUsage_progress: ol, aiUsage_tip1: Sl, aiUsage_tip2: Ml, aiUsage_tip3: zl, aiUsage_tracking: Za, aiUsage_usageInfo: _l, aiUsage_usageNormal: cl, aiUsage_usageProgress: al, aiUsage_usageTips: kl, aiUsage_vipInfoDesc: yl, aiUsage_vipLimitDesc: dl, aiUsage_vipLimitReached: ul, aiUsage_vipNoAi: sl, aiUsage_vipNoAiInfoDesc: wl, aiUsage_vipUser: il, average: g, benchmark: m, chart_above: fu, chart_all: Nc, chart_avgMonthlyReturn: Wc, chart_currency: pu, chart_day: Gc, chart_drawdownDepth: Qc, chart_drawdownHistory: Kc, chart_drawdownRanking: Xc, chart_excessReturn: Uc, chart_historicalPerformance: Oc, chart_hundred_million: hu, chart_lots: gu, chart_maxTradeDeviation: lu, chart_million: uu, chart_month: Bc, chart_monthSuffix: jc, chart_monthlyReturn: Fc, chart_newHigh: Yc, chart_newHighTimeRanking: Jc, chart_quarter: tu, chart_returnDistribution: ru, chart_shares: mu, chart_sharpeRatio: eu, chart_simulatedStopLoss: ou, chart_simulatedTakeProfit: au, chart_stockReturn: qc, chart_strategyVolatility: nu, chart_ten_million: cu, chart_ten_thousand: du, chart_year: Zc, chart_yearlyPerformance: Ic, chart_yearlySharpeVsBenchmark: iu, chart_yearlyTailRatio: su, chart_yearlyVsBenchmark: Hc, common_cancel: go, common_close: mo, common_confirm: vo, common_copy: yo, common_delete: bo, common_loading: Co, common_login: co, common_logout: uo, common_myPlan: zo, common_newStrategy: ko, common_rename: _o, common_run: wo, common_save: po, common_search: xo, common_searchStrategies: So, common_settings: fo, common_upgradePlan: Mo, dataUsage_askDiscord: $o, dataUsage_dataUsage: Ro, dataUsage_loadFailed: Po, dataUsage_requestReset: To, dataUsage_resetInfo: Eo, dataUsage_todayUsage: Do, general_apiKey: Da, general_deleteAll: Ea, general_deleteAllStrategies: $a, general_deleteAndReset: Ta, general_resetApiKey: Ra, general_resetting: Pa, googleAi_authInstructions: Ba, googleAi_authPageFailed: Ya, googleAi_connect: Fa, googleAi_connectFailed: Xa, googleAi_connectSuccess: Ga, googleAi_connected: La, googleAi_connectionStatus: Aa, googleAi_disconnect: Oa, googleAi_disconnectBtn: Na, googleAi_disconnectFailed: Qa, googleAi_disconnectSuccess: Ja, googleAi_disconnected: Va, googleAi_disconnecting: Ia, googleAi_maxOnly: Wa, googleAi_pasteCode: ja, googleAi_submit: Ha, googleAi_useOwnQuota: Ua, googleAi_useOwnQuotaDesc: Ka, googleAi_verifying: qa, header_aiAutoOptimize: fa, header_aiOptimize: ta, header_aiOptimizing: ma, header_analyze: Qo, header_closePanel: ra, header_copyAndSave: aa, header_copyStrategy: la, header_exitFullscreen: ia, header_fullscreen: ea, header_minimize: sa, header_moreOptions: ha, header_notebook: Zo, header_panorama: na, header_plan: va, header_pleaseLogin: ua, header_position: Jo, header_saveStrategy: ca, header_stop: ga, header_strategy: Xo, header_toggleSidebar: oa, header_upgradeVipToFork: da, header_userMenu: pa, insight_liquidity_entryVolume: Hh, insight_liquidity_exitVolume: Uh, insight_liquidity_portfolioCapacity: qh, insight_profitability_excessReturn: Ph, insight_profitability_historicalReturn: zh, insight_profitability_monthlyReturn: Ch, insight_profitability_stockList: Dh, insight_profitability_yearlyCompare: Rh, insight_ratio_correlation: Nh, insight_ratio_sharpe: Vh, insight_ratio_tailRatio: Oh, insight_ratio_volatility: Ih, insight_risk_drawdownPercentage: Lh, insight_risk_drawdownPeriods: Th, insight_risk_drawdownRanking: Eh, insight_risk_recoveryTime: Ah, insight_risk_stockList: $h, insight_winrate_maeMfe: jh, insight_winrate_returnDistribution: Fh, insight_winrate_stopLoss: Wh, insight_winrate_takeProfit: Bh, m: vu, metric_description_backtest_endDate: _n, metric_description_backtest_feeRatio: zn, metric_description_backtest_freq: An, metric_description_backtest_livePerformanceStart: Nn, metric_description_backtest_market: En, metric_description_backtest_nextTradingDate: In, metric_description_backtest_startDate: bn, metric_description_backtest_stopLoss: Fn, metric_description_backtest_takeProfit: Wn, metric_description_backtest_taxRatio: Cn, metric_description_backtest_tradeAt: $n, metric_description_backtest_updateDate: On, metric_description_backtest_version: Sn, metric_description_liquidity_buyHigh: gr, metric_description_liquidity_capacity: dr, metric_description_liquidity_disposalStockRatio: fr, metric_description_liquidity_fullDeliveryStockRatio: mr, metric_description_liquidity_sellLow: vr, metric_description_liquidity_warningStockRatio: pr, metric_description_profitability_alpha: qn, metric_description_profitability_annualReturn: Bn, metric_description_profitability_avgNStock: Yn, metric_description_profitability_beta: Kn, metric_description_profitability_maxNStock: Gn, metric_description_ratio_calmarRatio: nr, metric_description_ratio_profitFactor: rr, metric_description_ratio_sharpeRatio: ir, metric_description_ratio_sortinoRatio: sr, metric_description_ratio_tailRatio: or, metric_description_risk_avgDrawdown: Jn, metric_description_risk_avgDrawdownDays: Qn, metric_description_risk_cvalueAtRisk: er, metric_description_risk_maxDrawdown: Xn, metric_description_risk_valueAtRisk: tr, metric_description_risk_volatility: Zn, metric_description_winrate_expectancy: hr, metric_description_winrate_m12WinRate: lr, metric_description_winrate_mae: cr, metric_description_winrate_mfe: ur, metric_description_winrate_winRate: ar, metrics_backtest_endDate: L, metrics_backtest_feeRatio: O, metrics_backtest_freq: B, metrics_backtest_livePerformanceStart: K, metrics_backtest_market: F, metrics_backtest_nextTradingDate: U, metrics_backtest_startDate: A, metrics_backtest_stopLoss: G, metrics_backtest_takeProfit: J, metrics_backtest_taxRatio: I, metrics_backtest_tradeAt: N, metrics_backtest_updateDate: q, metrics_backtest_version: V, metrics_condition: br, metrics_liquidity_averageReturn: qs, metrics_liquidity_buyHigh: le, metrics_liquidity_capacity: ne, metrics_liquidity_disposalStockRatio: re, metrics_liquidity_entryVolume: Zs, metrics_liquidity_entryVolumeDescription: on, metrics_liquidity_exitVolume: Qs, metrics_liquidity_exitVolumeDescription: an, metrics_liquidity_fullDeliveryStockRatio: ae, metrics_liquidity_marketCap: Us, metrics_liquidity_marketCapDescription: rn, metrics_liquidity_marketCapThreshold: en, metrics_liquidity_portfolioCapacity: Bs, metrics_liquidity_portfolioCapacityDescription: sn, metrics_liquidity_safeLiquidityTradeRatio: js, metrics_liquidity_sellLow: he, metrics_liquidity_smallCapRatio: ie, metrics_liquidity_totalInvestment: Hs, metrics_liquidity_tradeRatio: Ks, metrics_liquidity_tradeRatioEntryVolume: Gs, metrics_liquidity_tradeRatioExitVolume: Xs, metrics_liquidity_tradeRatioMarketCap: Ys, metrics_liquidity_volumeThreshold: Js, metrics_liquidity_warningStockRatio: oe, metrics_profitability_alpha: tt, metrics_profitability_annualReturn: Q, metrics_profitability_avgNStock: at, metrics_profitability_beta: et, metrics_profitability_maxNStock: ct, metrics_ratio_betterThanBenchmark: ms, metrics_ratio_calmarRatio: Rt, metrics_ratio_profitFactor: At, metrics_ratio_rollingTailRatio: ln, metrics_ratio_sharpeRatio: zt, metrics_ratio_sortinoRatio: Ct, metrics_ratio_tailRatio: Lt, metrics_ratio_timeBetterThanBenchmark: vs, metrics_ratio_volatility: _s, metrics_ratio_worseThanBenchmark: Ot, metrics_ratio_year: gs, metrics_ratio_yearlySharpeRatio: fs, metrics_ratio_yearlyTailRatio: bs, metrics_risk_avgDrawdown: mt, metrics_risk_avgDrawdownDays: gt, metrics_risk_cvalueAtRisk: yt, metrics_risk_days: Mt, metrics_risk_maxDrawdown: dt, metrics_risk_newHighTimeRank: wt, metrics_risk_valueAtRisk: _t, metrics_risk_volatility: bt, metrics_risk_worst10Benchmark: kt, metrics_risk_worst10Strategy: xt, metrics_risk_worstDrawdownPeriod: pn, metrics_stocks_bmfe: xe, metrics_stocks_entry: de, metrics_stocks_entryPrice: me, metrics_stocks_entrySig: ve, metrics_stocks_exit: fe, metrics_stocks_exitPrice: ge, metrics_stocks_exitSig: be, metrics_stocks_gmfe: we, metrics_stocks_mae: _e, metrics_stocks_mdd: Se, metrics_stocks_pdays: ze, metrics_stocks_position: pe, metrics_stocks_return: ue, metrics_stocks_stockId: ce, metrics_winrate_distributionInfo1: xs, metrics_winrate_distributionInfo2: ks, metrics_winrate_expectancy: Gt, metrics_winrate_extraProfitLoss: Rs, metrics_winrate_extraProfitLossTakingProfit: Is, metrics_winrate_m12WinRate: Bt, metrics_winrate_mae: te, metrics_winrate_maeReturn: Ts, metrics_winrate_maemfe: Ms, metrics_winrate_mfe: ee, metrics_winrate_mfeReturn: Ws, metrics_winrate_none: Ds, metrics_winrate_return: Ss, metrics_winrate_returnDistribution: ws, metrics_winrate_simulatedStopLoss: $s, metrics_winrate_simulatedTakeProfit: Es, metrics_winrate_stoploss: zs, metrics_winrate_stoplossRatio: Ps, metrics_winrate_takeProfit: As, metrics_winrate_takeProfitRatio: Ns, metrics_winrate_winRate: It, nav_database: ao, nav_myStrategies: ho, nav_navigation: lo, nav_schedule: oo, nav_stockResearch: ro, notebook_category_ai: Ne, notebook_category_algorithm: Le, notebook_category_indicator: Ie, notebook_category_market: Ae, notebook_category_metric: Oe, notebook_category_python: Ee, notebook_category_tool: Ve, notebook_go_public: Te, notebook_private_draft: De, notebook_save_draft: Pe, notebook_update_public: $e, notification_email: Vo, notification_inSite: Ao, notification_monthlyNewsletter: Oo, notification_saveFailed: No, notification_strategySignal: Io, notification_weeklyPost: Lo, pane_allowAiSwitch: th, pane_leavePageConfirm: eh, payment_amount: Ko, payment_changeCreditCard: jo, payment_invoiceNumber: Yo, payment_lastFourDigits: qo, payment_month: Fo, payment_noRecords: Go, payment_noSubscription: Wo, payment_paymentDetails: Bo, payment_paymentTime: Uo, payment_transactionId: Ho, position_RSV: oi, position_action: ds, position_assetName: us, position_close: Ki, position_created: Ye, position_currentPrice: Je, position_currentWeight: Ze, position_dataFreq: Ke, position_entryDate: Ge, position_entryTradePrice: qe, position_exitDate: Xe, position_exitTradePrice: He, position_high_low_avg: Xi, position_nextWeight: ii, position_open: Hi, position_open_close_avg: Yi, position_profit: Qe, position_resample: je, position_resampleValue_2M: xi, position_resampleValue_2W: vi, position_resampleValue_30M: ui, position_resampleValue_3W: bi, position_resampleValue_4H: fi, position_resampleValue_4W: _i, position_resampleValue_8H: pi, position_resampleValue_D: mi, position_resampleValue_H: di, position_resampleValue_HY: Li, position_resampleValue_M: wi, position_resampleValue_ME: ki, position_resampleValue_MRE: Si, position_resampleValue_Q: Pi, position_resampleValue_QE: Ei, position_resampleValue_W: gi, position_resampleValue_W_Fri: Xr, position_resampleValue_W_Mon: Ur, position_resampleValue_W_Thu: Gr, position_resampleValue_W_Tue: Kr, position_resampleValue_W_Wed: Yr, position_resampleValue_Y: Ii, position_resampleValue_null: Fi, position_scheduled: Ue, position_sl: Fe, position_tp: We, position_ts: Be, position_type_entry: Zi, position_type_entry_f: ts, position_type_exit: es, position_type_exit_p: ss, position_type_hold: ns, position_type_sl: rs, position_type_sl_: hs, position_type_tp: ls, position_type_tp_: cs, profitability_YearlyCompareWithBenchmark: x, profitability_all: mn, profitability_avgMonthlyReturn: w, profitability_benchmarkYearlyReturn: cn, profitability_exceedReturn: S, profitability_historicalReturn: v, profitability_monthlyReturn: _, profitability_monthlyWinRatio: y, profitability_recent: vn, profitability_stockList: b, profitability_year: un, profitability_yearlyReturn: hn, profitability_yearlyWinRate: k, quality_needBetween0and08: lh, quality_needGt09: bh, quality_needGt10: yh, quality_needGt13: gh, quality_needGt15: _h, quality_needGt18: vh, quality_needGt55: wh, quality_needGt70: xh, quality_needGte10: ah, quality_needGte15: oh, quality_needGte2: kh, quality_needGte500k: Sh, quality_needGte5stocks: hh, quality_needLt10: dh, quality_needLt20: ph, quality_needLt30: uh, quality_needLt40days: fh, quality_needLt5: Mh, quality_needLt7: mh, quality_needLte20stocks: ch, ratio_correlation: ys, risk_drawdowPeriods: z, risk_drawdownPercentage: M, settings_aiUsage: Qr, settings_dataDownload: Zr, settings_general: Jr, settings_googleAi: so, settings_language: no, settings_notifications: to, settings_payment: io, settings_subscription: eo, sidebar_annualReturn: Vl, sidebar_annualized: Wl, sidebar_customSort: El, sidebar_deleteStrategy: Hl, sidebar_discuss: Tl, sidebar_drawdown: jl, sidebar_emptyHint: Pl, sidebar_emptyState: Rl, sidebar_enterName: Kl, sidebar_joinDiscord: $l, sidebar_lastUpdated: Al, sidebar_loginDescription: Dl, sidebar_loginToManage: Cl, sidebar_maxDrawdown: Il, sidebar_metricsOff: Fl, sidebar_metricsOn: Nl, sidebar_more: Zl, sidebar_quarterlyReturn: Ll, sidebar_renameStrategy: ql, sidebar_runStrategy: Ul, sidebar_running: Gl, sidebar_sharpe: Bl, sidebar_sharpeRatio: Ol, sidebar_sortBy: Jl, sidebar_termsOfService: Xl, sidebar_toggleMetrics: Ql, sidebar_waitingToRun: Yl, strategy: p, strategy_annualReturn: kr, strategy_betterThanBenchmark: wr, strategy_code: _r, strategy_maxDrawdown: Sr, strategy_period_All: Tr, strategy_period_HY: Rr, strategy_period_M: Cr, strategy_period_Q: Dr, strategy_period_W: zr, strategy_period_Y: Pr, strategy_return: yr, strategy_sharpeRatio: Mr, strategy_tabs_analyze: Er, strategy_tabs_course: Ar, strategy_tabs_notebook: Lr, strategy_tabs_position: $r, strategy_worseThanBenchmark: xr, sub_ai_feature1: _c, sub_ai_feature10: Dc, sub_ai_feature2: yc, sub_ai_feature3: wc, sub_ai_feature4: xc, sub_ai_feature5: kc, sub_ai_feature6: Sc, sub_ai_feature7: Mc, sub_ai_feature8: zc, sub_ai_feature9: Cc, sub_autoRenew: ec, sub_cancelFailed: oc, sub_cancelSubscription: Zh, sub_cancelling: Qh, sub_cannotGetSubscription: nc, sub_cannotGetUserId: rc, sub_changeCreditCard: Xh, sub_changePlan: Jh, sub_expireAt: ic, sub_freeTrial: sc, sub_free_feature1: ac, sub_free_feature2: lc, sub_free_feature3: hc, sub_free_feature4: cc, sub_free_feature5: uc, sub_manage: Gh, sub_max_feature1: Rc, sub_max_feature2: Pc, sub_max_feature3: Tc, sub_team_feature1: $c, sub_team_feature2: Ec, sub_team_feature3: Ac, sub_team_feature4: Lc, sub_team_feature5: Vc, sub_thankYou: tc, sub_unlimited: Yh, sub_vip_feature1: dc, sub_vip_feature2: fc, sub_vip_feature3: pc, sub_vip_feature4: mc, sub_vip_feature5: gc, sub_vip_feature6: vc, sub_vip_feature7: bc, subtitle: d, tabs_liquidity: E, tabs_profitability: C, tabs_ratio: P, tabs_risk: R, tabs_winrate: T, theme_dark: sh, theme_label: rh, theme_light: ih, theme_system: nh, title: u, toast_aiBetterStrategy: ba, toast_autoOptimizeDone: _a, toast_cannotGenerateToken: Sa, toast_cannotGetIdToken: za, toast_confirmResetToken: Ca, toast_forkedAndSaved: xa, toast_notLoggedIn: ka, toast_saveFailed: wa, toast_strategySaved: ya, toast_tokenInvalid: Ma, unnamed_strategy: Kh, viewer_contactAuthor: qr, viewer_finlabStrategies: Vr, viewer_joinToView: jr, viewer_loginToView: Br, viewer_myStrategy: Or, viewer_periodReturn: Wr, viewer_previousPage: Hr, viewer_quantStrategy: Ir, viewer_rename: Nr, viewer_renameFailed: Fr }, Symbol.toStringTag, { value: "Module" })), _u = { profitability: { annualReturn: { check: (t2) => t2 > 0.15, text: () => oh() }, alpha: { check: (t2) => t2 > 0.1, text: () => ah() }, beta: { check: (t2) => t2 < 0.8 && t2 > 0, text: () => lh() }, avgNStock: { check: (t2) => t2 >= 5, text: () => hh() }, maxNStock: { check: (t2) => t2 <= 20, text: () => ch() } }, risk: { maxDrawdown: { check: (t2) => t2 > -0.3, text: () => uh() }, avgDrawdown: { check: (t2) => t2 > -0.1, text: () => dh() }, avgDrawdownDays: { check: (t2) => t2 < 40, text: () => fh() }, volatility: { check: (t2) => t2 < 0.2, text: () => ph() }, valueAtRisk: { check: (t2) => t2 > -0.07, text: () => mh() }, cvalueAtRisk: { check: (t2) => t2 > -0.1, text: () => dh() } }, ratio: { sharpeRatio: { check: (t2) => t2 > 1.3, text: () => gh() }, sortinoRatio: { check: (t2) => t2 > 1.8, text: () => vh() }, calmarRatio: { check: (t2) => t2 > 0.9, text: () => bh() }, profitFactor: { check: (t2) => t2 > 1.5, text: () => _h() }, tailRatio: { check: (t2) => t2 > 1, text: () => yh() } }, winrate: { winRate: { check: (t2) => t2 > 0.55, text: () => wh() }, m12WinRate: { check: (t2) => t2 > 0.7, text: () => xh() }, expectancy: { check: (t2) => t2 > 0.02, text: () => kh() }, mae: { check: (t2) => t2 > -0.1, text: () => dh() }, mfe: { check: (t2) => t2 > 0.1, text: () => ah() } }, liquidity: { capacity: { check: (t2) => t2 > 5e5, text: () => Sh() }, disposalStockRatio: { check: (t2) => t2 < 0.05, text: () => Mh() }, warningStockRatio: { check: (t2) => t2 < 0.05, text: () => Mh() }, fullDeliveryStockRatio: { check: (t2) => t2 < 0.05, text: () => Mh() }, buyHigh: { check: (t2) => t2 < 0.05, text: () => Mh() }, sellLow: { check: (t2) => t2 < 0.05, text: () => Mh() } } };
function yu(t2) {
  if (!t2) return false;
  const e2 = t2.toUpperCase();
  return "TW_STOCK" === e2 || "TSE_OTC" === e2 || "TSE" === e2 || "OTC" === e2;
}
function wu(t2) {
  var _a3;
  const e2 = { profitability: 0, risk: 0, ratio: 0, winrate: 0, liquidity: 0 }, i2 = yu((_a3 = t2.backtest) == null ? void 0 : _a3.market);
  for (const s2 in _u) if ("liquidity" !== s2 || i2) for (const i3 in _u[s2]) _u[s2][i3].check(t2[s2][i3]) && (e2[s2]++, "liquidity" === s2 && "capacity" === i3 && (e2[s2] += 10));
  for (const t3 in e2) {
    if ("liquidity" === t3 && !i2) {
      e2[t3] = 0;
      continue;
    }
    let s2 = Object.keys(_u[t3]).length;
    "liquidity" === t3 && (s2 += 10), e2[t3] = e2[t3] / s2;
  }
  return e2;
}
class MetricDisplay {
  constructor() {
    this.percentage = (t2) => (100 * t2).toFixed(1), this.sign = (t2) => "string" == typeof t2 && "-" != t2[0] || "number" == typeof t2 && t2 > 0 ? "+" + String(t2) : String(t2), this.color = (t2) => t2 > 0 ? "text-rise" : "text-fall", this.formatter = { annualReturn: (t2) => this.sign(this.percentage(t2)), alpha: (t2) => this.sign(this.percentage(t2)), avgNStock: (t2) => 0 === t2 ? "-" : t2.toFixed(0), maxNStock: (t2) => 0 === t2 ? "-" : t2.toFixed(0), maxDrawdown: (t2) => this.sign(this.percentage(t2)), avgDrawdown: (t2) => this.sign(this.percentage(t2)), valueAtRisk: (t2) => this.sign(this.percentage(t2)), cvalueAtRisk: (t2) => this.sign(this.percentage(t2)), winRate: (t2) => this.percentage(t2), m12WinRate: (t2) => this.percentage(t2), expectancy: (t2) => this.sign(this.percentage(t2)), mae: (t2) => this.sign(this.percentage(t2)), mfe: (t2) => this.sign(this.percentage(t2)), smallCapRatio: (t2) => this.percentage(t2), capacity: (t2) => (t2 / 1e4).toFixed(0), disposalStockRatio: (t2) => this.percentage(t2), warningStockRatio: (t2) => this.percentage(t2), fullDeliveryStockRatio: (t2) => this.percentage(t2), buyHigh: (t2) => this.percentage(t2), sellLow: (t2) => this.percentage(t2) }, this.units = { annualReturn: "%", alpha: "%", avgNStock: "", maxNStock: "", maxDrawdown: "%", avgDrawdown: "%", avgDrawdownDays: "", valueAtRisk: "%", cvalueAtRisk: "%", winRate: "%", m12WinRate: "%", expectancy: "%", mae: "%", mfe: "%", smallCapRatio: "%", capacity: "", disposalStockRatio: "%", warningStockRatio: "%", fullDeliveryStockRatio: "%", buyHigh: "%", sellLow: "%" };
  }
  format(t2, e2) {
    if (t2 in this.formatter) try {
      return this.formatter[t2](e2);
    } catch {
    }
    try {
      return String(e2.toFixed(2));
    } catch {
    }
    return String(e2);
  }
  getUnit(t2) {
    return t2 in this.units ? this.units[t2] : "";
  }
}
function xu(t2, e2, i2, s2) {
  let n2 = e2.length, r2 = void 0 !== i2 ? i2 : 0, o2 = void 0 !== s2 ? s2 : n2 - 1, a2 = r2 + Math.floor((o2 - r2) / 2);
  0 !== n2 ? t2 >= e2[o2] ? e2.splice(o2 + 1, 0, t2) : t2 < e2[r2] ? e2.splice(r2, 0, t2) : r2 >= o2 || (t2 <= e2[a2] ? xu(t2, e2, r2, a2) : t2 > e2[a2] && xu(t2, e2, a2 + 1, o2)) : e2.push(t2);
}
function ku(t2, e2, i2) {
  let s2 = [], n2 = [];
  t2.slice(0, i2).forEach((t3) => xu(t3, s2));
  for (let r2 = i2; r2 < t2.length; r2++) n2.push(s2[Math.floor(i2 * e2)]), s2.splice(s2.indexOf(t2[r2 - i2]), 1), xu(t2[r2], s2);
  return n2.push(s2[Math.floor(i2 * e2)]), n2;
}
class Report {
  constructor(t2, e2, i2, s2, n2) {
    this.timestamps = t2, this.strategy = e2, this.benchmark = i2, this.trades = s2, this.metrics = n2;
  }
  createTradingviewSeries(t2, e2 = 0, i2 = -1, s2 = 500) {
    const n2 = this.timestamps.map((e3, i3) => ({ time: e3, value: this[t2][i3] })).slice(this.indexOfTimestamps(e2), this.indexOfTimestamps(i2) + 1), r2 = this.timestamps.map((t3, e3) => 0 === e3 || t3.substring(0, 7) !== this.timestamps[e3 - 1].substring(0, 7)), o2 = Math.round(n2.length / s2);
    return n2.filter((t3, e3) => e3 % o2 === 0 || e3 === n2.length - 1 || r2[e3]);
  }
  indexOfTimestamps(t2) {
    return "string" == typeof t2 ? function(t3, e2) {
      let i2 = 0, s2 = t3.length - 1, n2 = -1;
      for (; i2 <= s2; ) {
        const r2 = Math.ceil((i2 + s2) / 2);
        if (t3[r2] === e2) return r2;
        t3[r2] < e2 ? (n2 = r2, i2 = r2 + 1) : (n2 = r2, s2 = r2 - 1);
      }
      return e2 < t3[n2] && (n2 -= 1), n2;
    }(this.timestamps, t2) : t2 < 0 ? Math.min(Math.max(this.timestamps.length + t2, 0), this.timestamps.length - 1) : t2;
  }
  calculateAnnualReturn(t2) {
    const e2 = {};
    let i2 = this[t2][0];
    for (let s2 = 1; s2 < this.timestamps.length; s2++) {
      const n2 = new Date(this.timestamps[s2]).getFullYear();
      if (s2 === this.timestamps.length - 1 || new Date(this.timestamps[s2 + 1]).getFullYear() !== n2) {
        const r2 = this[t2][s2];
        e2[n2] = r2 / i2 - 1, i2 = r2;
      }
    }
    return e2;
  }
  calculateMonthlyReturn(t2) {
    const e2 = {};
    let i2 = this[t2][0];
    for (let s2 = 1; s2 < this.timestamps.length; s2++) {
      const n2 = new Date(this.timestamps[s2]), r2 = n2.getFullYear(), o2 = n2.getMonth() + 1;
      if (s2 === this.timestamps.length - 1 || new Date(this.timestamps[s2 + 1]).getMonth() + 1 !== o2) {
        const n3 = this[t2][s2];
        e2[`${r2}${o2}`] = n3 / i2 - 1, i2 = n3;
      }
    }
    return e2;
  }
  calculateMostRecentNDayReturn(t2, e2) {
    const i2 = this[t2], s2 = i2.length, n2 = {};
    for (const t3 of e2) {
      const e3 = parseInt(t3);
      if (s2 < e3) continue;
      const r2 = 100 * (i2[s2 - 1] / i2[s2 - e3 - 1] - 1);
      n2[t3] = r2;
    }
    return n2;
  }
  createTradingViewDrawdown(t2, e2 = 100) {
    const i2 = this[t2], s2 = [];
    let n2 = -1 / 0, r2 = i2[0];
    for (let t3 = 0; t3 < i2.length; t3++) n2 = Math.max(n2, i2[t3]), r2 = Math.min(r2, i2[t3]), s2.push((i2[t3] - n2) / n2 * 100);
    const o2 = Math.ceil(s2.length / e2);
    return this.timestamps.map((t3, e3) => ({ time: t3, value: s2[e3] })).filter((t3, e3) => e3 % o2 === 0 || e3 === s2.length - 1);
  }
  calculateDrawdown(t2) {
    let e2 = 0, i2 = 1, s2 = 1, n2 = 0, r2 = [];
    const o2 = this[t2];
    for (let t3 = 0; t3 < this.timestamps.length; t3 += 1) {
      const a3 = o2[t3];
      if (a3 > i2) t3 - e2 >= 2 && r2.push({ maxDrawdown: s2 - 1, start: e2, end: t3, at: n2 }), e2 = t3, i2 = a3, s2 = 1, n2 = t3;
      else {
        const e3 = a3 / i2;
        s2 > e3 && (s2 = e3, n2 = t3);
      }
    }
    s2 < 1 && this.timestamps.length - e2 >= 2 && r2.push({ maxDrawdown: s2 - 1, start: e2, end: this.timestamps.length - 1, at: n2 }), r2.sort((t3, e3) => -(t3.end - t3.start) + (e3.end - e3.start));
    const a2 = r2.slice(0, 5);
    return r2.sort((t3, e3) => t3.maxDrawdown - e3.maxDrawdown), [r2.slice(0, 5), a2];
  }
  calculateSharpe(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0;
    const o2 = this[t2];
    for (let t3 = 1; t3 < o2.length; t3++) {
      n2 += o2[t3] / o2[t3 - 1] - 1, t3 >= i2 && (n2 -= o2[t3 - i2 + 1] / o2[t3 - i2] - 1);
      const a2 = n2 / Math.min(t3, i2);
      r2 = 0;
      for (let e3 = Math.max(1, t3 - i2 + 1); e3 <= t3; e3++) {
        const t4 = o2[e3] / o2[e3 - 1] - 1;
        r2 += (t4 - a2) * (t4 - a2);
      }
      if (t3 >= i2 - 1) {
        const n3 = r2 / Math.min(t3, i2), o3 = (a2 - e2) / Math.sqrt(n3);
        s2.push({ time: this.timestamps[t3], value: o3 * Math.sqrt(i2) });
      }
    }
    return s2;
  }
  calculateSortino(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0, o2 = [], a2 = [];
    const l2 = this[t2];
    for (let t3 = 1; t3 < l2.length; t3++) {
      let h2 = l2[t3] / l2[t3 - 1] - 1;
      n2 += h2, o2.push(h2);
      let c2 = n2 / i2, u2 = (h2 - c2) * (h2 - c2);
      if (a2.push(u2), h2 < e2 && (r2 += u2), t3 >= i2) {
        let t4 = o2.shift(), i3 = a2.shift();
        n2 -= t4, t4 < e2 && (r2 -= i3);
      }
      if (t3 >= i2 - 1) {
        let t4 = r2 / i2, n3 = (c2 - e2) / Math.sqrt(t4);
        s2.push(n3);
      }
    }
    return s2.map((t3, e3) => ({ time: this.timestamps[e3 + i2 - 1], value: t3 * Math.sqrt(i2) }));
  }
  calculateVolitility(t2, e2, i2) {
    let s2 = [], n2 = 0, r2 = 0, o2 = [], a2 = [];
    const l2 = this[t2];
    for (let t3 = 1; t3 < l2.length; t3++) {
      let e3 = l2[t3] / l2[t3 - 1] - 1;
      n2 += e3, o2.push(e3);
      let h2 = n2 / i2, c2 = (e3 - h2) * (e3 - h2);
      if (r2 += c2, a2.push(c2), t3 >= i2 && (n2 -= o2.shift(), r2 -= a2.shift()), t3 >= i2 - 1) {
        let t4 = r2 / i2, e4 = Math.sqrt(t4);
        s2.push(e4);
      }
    }
    return s2.map((t3, e3) => ({ time: this.timestamps[e3 + i2 - 1], value: t3 * Math.sqrt(i2) }));
  }
  calculateCorrelation(t2) {
    let e2 = this.strategy, i2 = this.benchmark, s2 = [];
    for (let n2 = 0; n2 < e2.length; n2++) {
      let r2 = 0, o2 = 0, a2 = 0, l2 = 0, h2 = 0;
      for (let s3 = Math.max(0, n2 - t2 + 1); s3 <= n2; s3++) r2 += e2[s3], o2 += i2[s3], a2 += e2[s3] * e2[s3], l2 += i2[s3] * i2[s3], h2 += e2[s3] * i2[s3];
      let c2 = Math.min(n2 + 1, t2), u2 = (c2 * h2 - r2 * o2) / Math.sqrt((c2 * a2 - r2 * r2) * (c2 * l2 - o2 * o2));
      s2.push(u2);
    }
    return s2.map((e3, i3) => ({ time: this.timestamps[i3 + t2 - 1], value: e3 })).filter((t3) => void 0 !== t3.time).slice(1, -1);
  }
  calculateTailRatio(t2, e2) {
    let i2 = this[t2];
    i2 = i2.map((t3, e3) => t3 / i2[e3 - 1] - 1), i2[0] = 0;
    const s2 = ku(i2, 0.95, e2), n2 = ku(i2, 0.05, e2);
    return s2.map((t3, e3) => Math.abs(t3 / n2[e3])).map((t3, i3) => ({ time: this.timestamps[i3 + e2 - 1], value: t3 }));
  }
}
"undefined" != typeof window && ((_a2 = window.__svelte ?? (window.__svelte = {})).v ?? (_a2.v = /* @__PURE__ */ new Set())).add("5");
const Su = "[!", Mu = {}, zu = Symbol();
var Cu = Array.isArray, Du = Array.prototype.indexOf, Ru = Array.from, Pu = Object.keys, Tu = Object.defineProperty, $u = Object.getOwnPropertyDescriptor, Eu = Object.getOwnPropertyDescriptors, Au = Object.prototype, Lu = Array.prototype, Vu = Object.getPrototypeOf, Ou = Object.isExtensible;
function Iu(t2) {
  return "function" == typeof t2;
}
const Nu = () => {
};
function Fu(t2) {
  return t2();
}
function Wu(t2) {
  for (var e2 = 0; e2 < t2.length; e2++) t2[e2]();
}
function Bu(t2, e2) {
  if (Array.isArray(t2)) return t2;
  if (!(Symbol.iterator in t2)) return Array.from(t2);
  const i2 = [];
  for (const s2 of t2) if (i2.push(s2), i2.length === e2) break;
  return i2;
}
const ju = 256, qu = 1024, Hu = 2048, Uu = 4096, Ku = 8192, Yu = 32768, Gu = 65536, Xu = 1 << 21, Ju = Symbol("$state"), Qu = Symbol("legacy props"), Zu = Symbol("");
function td(t2) {
  return t2 === this.v;
}
function ed(t2, e2) {
  return t2 != t2 ? e2 == e2 : t2 !== e2 || null !== t2 && "object" == typeof t2 || "function" == typeof t2;
}
function id(t2, e2) {
  return t2 !== e2;
}
function sd(t2) {
  return !ed(t2, this.v);
}
let nd = false;
function rd(t2) {
  throw new Error("https://svelte.dev/e/lifecycle_outside_component");
}
let od = null;
function ad(t2) {
  od = t2;
}
function ld(t2, e2 = false, i2) {
  var s2 = od = { p: od, c: null, d: false, e: null, m: false, s: t2, x: null, l: null };
  nd && !e2 && (od.l = { s: null, u: null, r1: [], r2: xd(false) }), Zd(() => {
    s2.d = true;
  });
}
function hd(t2) {
  const e2 = od;
  if (null !== e2) {
    void 0 !== t2 && (e2.x = t2);
    const o2 = e2.e;
    if (null !== o2) {
      var i2 = Lf, s2 = $f;
      e2.e = null;
      try {
        for (var n2 = 0; n2 < o2.length; n2++) {
          var r2 = o2[n2];
          Vf(r2.effect), Af(r2.reaction), ef(r2.fn);
        }
      } finally {
        Vf(i2), Af(s2);
      }
    }
    od = e2.p, e2.m = true;
  }
  return t2 || {};
}
function cd() {
  return !nd || null !== od && null === od.l;
}
function ud(t2) {
  if ("object" != typeof t2 || null === t2 || Ju in t2) return t2;
  const e2 = Vu(t2);
  if (e2 !== Au && e2 !== Lu) return t2;
  var i2 = /* @__PURE__ */ new Map(), s2 = Cu(t2), n2 = kd(0), r2 = $f, o2 = (t3) => {
    var e3 = $f;
    Af(r2);
    var i3 = t3();
    return Af(e3), i3;
  };
  return s2 && i2.set("length", kd(t2.length)), new Proxy(t2, { defineProperty: (t3, e3, s3) => ("value" in s3 && false !== s3.configurable && false !== s3.enumerable && false !== s3.writable || function() {
    throw new Error("https://svelte.dev/e/state_descriptors_fixed");
  }(), o2(() => {
    var t4 = i2.get(e3);
    void 0 === t4 ? (t4 = kd(s3.value), i2.set(e3, t4)) : zd(t4, s3.value, true);
  }), true), deleteProperty(t3, e3) {
    var r3 = i2.get(e3);
    if (void 0 === r3) {
      if (e3 in t3) {
        const t4 = o2(() => kd(zu));
        i2.set(e3, t4), dd(n2);
      }
    } else {
      if (s2 && "string" == typeof e3) {
        var a2 = i2.get("length"), l2 = Number(e3);
        Number.isInteger(l2) && l2 < a2.v && zd(a2, l2);
      }
      zd(r3, zu), dd(n2);
    }
    return true;
  }, get(e3, s3, n3) {
    var _a3;
    if (s3 === Ju) return t2;
    var r3 = i2.get(s3), a2 = s3 in e3;
    if (void 0 !== r3 || a2 && !((_a3 = $u(e3, s3)) == null ? void 0 : _a3.writable) || (r3 = o2(() => kd(ud(a2 ? e3[s3] : zu))), i2.set(s3, r3)), void 0 !== r3) {
      var l2 = rp(r3);
      return l2 === zu ? void 0 : l2;
    }
    return Reflect.get(e3, s3, n3);
  }, getOwnPropertyDescriptor(t3, e3) {
    var s3 = Reflect.getOwnPropertyDescriptor(t3, e3);
    if (s3 && "value" in s3) {
      var n3 = i2.get(e3);
      n3 && (s3.value = rp(n3));
    } else if (void 0 === s3) {
      var r3 = i2.get(e3), o3 = r3 == null ? void 0 : r3.v;
      if (void 0 !== r3 && o3 !== zu) return { enumerable: true, configurable: true, value: o3, writable: true };
    }
    return s3;
  }, has(t3, e3) {
    var _a3;
    if (e3 === Ju) return true;
    var s3 = i2.get(e3), n3 = void 0 !== s3 && s3.v !== zu || Reflect.has(t3, e3);
    return !((void 0 !== s3 || null !== Lf && (!n3 || ((_a3 = $u(t3, e3)) == null ? void 0 : _a3.writable))) && (void 0 === s3 && (s3 = o2(() => kd(n3 ? ud(t3[e3]) : zu)), i2.set(e3, s3)), rp(s3) === zu)) && n3;
  }, set(t3, e3, r3, a2) {
    var _a3;
    var l2 = i2.get(e3), h2 = e3 in t3;
    if (s2 && "length" === e3) for (var c2 = r3; c2 < l2.v; c2 += 1) {
      var u2 = i2.get(c2 + "");
      void 0 !== u2 ? zd(u2, zu) : c2 in t3 && (u2 = o2(() => kd(zu)), i2.set(c2 + "", u2));
    }
    void 0 === l2 ? h2 && !((_a3 = $u(t3, e3)) == null ? void 0 : _a3.writable) || (l2 = o2(() => {
      var t4 = kd(void 0);
      return zd(t4, ud(r3)), t4;
    }), i2.set(e3, l2)) : (h2 = l2.v !== zu, zd(l2, o2(() => ud(r3))));
    var d2 = Reflect.getOwnPropertyDescriptor(t3, e3);
    if ((d2 == null ? void 0 : d2.set) && d2.set.call(a2, r3), !h2) {
      if (s2 && "string" == typeof e3) {
        var f2 = i2.get("length"), p2 = Number(e3);
        Number.isInteger(p2) && p2 >= f2.v && zd(f2, p2 + 1);
      }
      dd(n2);
    }
    return true;
  }, ownKeys(t3) {
    rp(n2);
    var e3 = Reflect.ownKeys(t3).filter((t4) => {
      var e4 = i2.get(t4);
      return void 0 === e4 || e4.v !== zu;
    });
    for (var [s3, r3] of i2) r3.v === zu || s3 in t3 || e3.push(s3);
    return e3;
  }, setPrototypeOf() {
    !function() {
      throw new Error("https://svelte.dev/e/state_prototype_fixed");
    }();
  } });
}
function dd(t2, e2 = 1) {
  zd(t2, t2.v + e2);
}
function fd(t2) {
  try {
    if (null !== t2 && "object" == typeof t2 && Ju in t2) return t2[Ju];
  } catch {
  }
  return t2;
}
function pd(t2, e2) {
  return Object.is(fd(t2), fd(e2));
}
function md(t2) {
  var e2 = 2050, i2 = null !== $f && 2 & $f.f ? $f : null;
  return null === Lf || null !== i2 && 0 !== (i2.f & ju) ? e2 |= ju : Lf.f |= 1048576, { ctx: od, deps: null, effects: null, equals: td, f: e2, fn: t2, reactions: null, rv: 0, v: null, wv: 0, parent: i2 ?? Lf };
}
function gd(t2) {
  const e2 = md(t2);
  return If(e2), e2;
}
function vd(t2) {
  const e2 = md(t2);
  return e2.equals = sd, e2;
}
function bd(t2) {
  var e2 = t2.effects;
  if (null !== e2) {
    t2.effects = null;
    for (var i2 = 0; i2 < e2.length; i2 += 1) uf(e2[i2]);
  }
}
function _d(t2) {
  var e2, i2 = Lf;
  Vf(function(t3) {
    for (var e3 = t3.parent; null !== e3; ) {
      if (!(2 & e3.f)) return e3;
      e3 = e3.parent;
    }
    return null;
  }(t2));
  try {
    bd(t2), e2 = Yf(t2);
  } finally {
    Vf(i2);
  }
  return e2;
}
function yd(t2) {
  var e2 = _d(t2);
  t2.equals(e2) || (t2.v = e2, t2.wv = Hf()), Rf || lp(t2, !qf && 0 === (t2.f & ju) || null === t2.deps ? qu : Uu);
}
const wd = /* @__PURE__ */ new Map();
function xd(t2, e2) {
  return { f: 0, v: t2, reactions: null, equals: td, rv: 0, wv: 0 };
}
function kd(t2, e2) {
  const i2 = xd(t2);
  return If(i2), i2;
}
function Sd(t2, e2 = false) {
  var _a3;
  const i2 = xd(t2);
  return e2 || (i2.equals = sd), nd && null !== od && null !== od.l && ((_a3 = od.l).s ?? (_a3.s = [])).push(i2), i2;
}
function Md(t2, e2) {
  return zd(t2, op(() => rp(t2))), e2;
}
function zd(t2, e2, i2 = false) {
  return null !== $f && !Ef && cd() && 18 & $f.f && !(Of == null ? void 0 : Of.includes(t2)) && function() {
    throw new Error("https://svelte.dev/e/state_unsafe_mutation");
  }(), Cd(t2, i2 ? ud(e2) : e2);
}
function Cd(t2, e2) {
  if (!t2.equals(e2)) {
    var i2 = t2.v;
    Rf ? wd.set(t2, e2) : wd.set(t2, i2), t2.v = e2, 2 & t2.f && (0 !== (t2.f & Hu) && _d(t2), lp(t2, 0 === (t2.f & ju) ? qu : Uu)), t2.wv = Hf(), Rd(t2, Hu), !cd() || null === Lf || 0 === (Lf.f & qu) || 96 & Lf.f || (null === Wf ? function(t3) {
      Wf = t3;
    }([t2]) : Wf.push(t2));
  }
  return e2;
}
function Dd(t2, e2 = 1) {
  var i2 = rp(t2), s2 = 1 === e2 ? i2++ : i2--;
  return zd(t2, i2), s2;
}
function Rd(t2, e2) {
  var i2 = t2.reactions;
  if (null !== i2) for (var s2 = cd(), n2 = i2.length, r2 = 0; r2 < n2; r2++) {
    var o2 = i2[r2], a2 = o2.f;
    0 === (a2 & Hu) && (s2 || o2 !== Lf) && (lp(o2, e2), 1280 & a2 && (2 & a2 ? Rd(o2, Uu) : ep(o2)));
  }
}
let Pd, Td = false;
function $d(t2) {
  Td = t2;
}
function Ed(t2) {
  if (null === t2) throw Mu;
  return Pd = t2;
}
function Ad() {
  return Ed(Ud(Pd));
}
function Ld(t2) {
  if (Td) {
    if (null !== Ud(Pd)) throw Mu;
    Pd = t2;
  }
}
function Vd(t2 = 1) {
  if (Td) {
    for (var e2 = t2, i2 = Pd; e2--; ) i2 = Ud(i2);
    Pd = i2;
  }
}
function Od() {
  for (var t2 = 0, e2 = Pd; ; ) {
    if (8 === e2.nodeType) {
      var i2 = e2.data;
      if ("]" === i2) {
        if (0 === t2) return e2;
        t2 -= 1;
      } else "[" !== i2 && i2 !== Su || (t2 += 1);
    }
    var s2 = Ud(e2);
    e2.remove(), e2 = s2;
  }
}
function Id(t2) {
  if (!t2 || 8 !== t2.nodeType) throw Mu;
  return t2.data;
}
var Nd, Fd, Wd, Bd;
function jd() {
  if (void 0 === Nd) {
    Nd = window, Fd = /Firefox/.test(navigator.userAgent);
    var t2 = Element.prototype, e2 = Node.prototype, i2 = Text.prototype;
    Wd = $u(e2, "firstChild").get, Bd = $u(e2, "nextSibling").get, Ou(t2) && (t2.__click = void 0, t2.__className = void 0, t2.__attributes = null, t2.__style = void 0, t2.__e = void 0), Ou(i2) && (i2.__t = void 0);
  }
}
function qd(t2 = "") {
  return document.createTextNode(t2);
}
function Hd(t2) {
  return Wd.call(t2);
}
function Ud(t2) {
  return Bd.call(t2);
}
function Kd(t2, e2) {
  if (!Td) return Hd(t2);
  var i2 = Hd(Pd);
  if (null === i2) i2 = Pd.appendChild(qd());
  else if (e2 && 3 !== i2.nodeType) {
    var s2 = qd();
    return i2 == null ? void 0 : i2.before(s2), Ed(s2), s2;
  }
  return Ed(i2), i2;
}
function Yd(t2, e2) {
  if (!Td) {
    var i2 = Hd(t2);
    return i2 instanceof Comment && "" === i2.data ? Ud(i2) : i2;
  }
  return Pd;
}
function Gd(t2, e2 = 1, i2 = false) {
  let s2 = Td ? Pd : t2;
  for (var n2; e2--; ) n2 = s2, s2 = Ud(s2);
  if (!Td) return s2;
  var r2 = s2 == null ? void 0 : s2.nodeType;
  if (i2 && 3 !== r2) {
    var o2 = qd();
    return null === s2 ? n2 == null ? void 0 : n2.after(o2) : s2.before(o2), Ed(o2), o2;
  }
  return Ed(s2), s2;
}
function Xd(t2) {
  t2.textContent = "";
}
function Jd(t2) {
  null === Lf && null === $f && function() {
    throw new Error("https://svelte.dev/e/effect_orphan");
  }(), null !== $f && 0 !== ($f.f & ju) && null === Lf && function() {
    throw new Error("https://svelte.dev/e/effect_in_unowned_derived");
  }(), Rf && function() {
    throw new Error("https://svelte.dev/e/effect_in_teardown");
  }();
}
function Qd(t2, e2, i2, s2 = true) {
  var n2 = Lf, r2 = { ctx: od, deps: null, nodes_start: null, nodes_end: null, f: t2 | Hu, first: null, fn: e2, last: null, next: null, parent: n2, prev: null, teardown: null, transitions: null, wv: 0 };
  if (i2) try {
    Jf(r2), r2.f |= Yu;
  } catch (t3) {
    throw uf(r2), t3;
  }
  else null !== e2 && ep(r2);
  if ((!i2 || null !== r2.deps || null !== r2.first || null !== r2.nodes_start || null !== r2.teardown || 1048704 & r2.f) && s2 && (null !== n2 && function(t3, e3) {
    var i3 = e3.last;
    null === i3 ? e3.last = e3.first = t3 : (i3.next = t3, t3.prev = i3, e3.last = t3);
  }(r2, n2), null !== $f && 2 & $f.f)) {
    var o2 = $f;
    (o2.effects ?? (o2.effects = [])).push(r2);
  }
  return r2;
}
function Zd(t2) {
  const e2 = Qd(8, null, false);
  return lp(e2, qu), e2.teardown = t2, e2;
}
function tf(t2) {
  if (Jd(), !(null !== Lf && 32 & Lf.f && null !== od) || od.m) return ef(t2);
  var e2 = od;
  (e2.e ?? (e2.e = [])).push({ fn: t2, effect: Lf, reaction: $f });
}
function ef(t2) {
  return Qd(4, t2, false);
}
function sf(t2, e2) {
  var i2 = od, s2 = { effect: null, ran: false };
  i2.l.r1.push(s2), s2.effect = rf(() => {
    t2(), s2.ran || (s2.ran = true, zd(i2.l.r2, true), op(e2));
  });
}
function nf() {
  var t2 = od;
  rf(() => {
    if (rp(t2.l.r2)) {
      for (var e2 of t2.l.r1) {
        var i2 = e2.effect;
        0 !== (i2.f & qu) && lp(i2, Uu), Uf(i2) && Jf(i2), e2.ran = false;
      }
      t2.l.r2.v = false;
    }
  });
}
function rf(t2) {
  return Qd(8, t2, true);
}
function of(t2, e2 = [], i2 = md) {
  const s2 = e2.map(i2);
  return af(() => t2(...s2.map(rp)));
}
function af(t2, e2 = 0) {
  return Qd(24 | e2, t2, true);
}
function lf(t2, e2 = true) {
  return Qd(40, t2, true, e2);
}
function hf(t2) {
  var e2 = t2.teardown;
  if (null !== e2) {
    const t3 = Rf, i2 = $f;
    Pf(true), Af(null);
    try {
      e2.call(null);
    } finally {
      Pf(t3), Af(i2);
    }
  }
}
function cf(t2, e2 = false) {
  var i2 = t2.first;
  for (t2.first = t2.last = null; null !== i2; ) {
    var s2 = i2.next;
    64 & i2.f ? i2.parent = null : uf(i2, e2), i2 = s2;
  }
}
function uf(t2, e2 = true) {
  var i2 = false;
  (e2 || 524288 & t2.f) && null !== t2.nodes_start && null !== t2.nodes_end && (df(t2.nodes_start, t2.nodes_end), i2 = true), cf(t2, e2 && !i2), Xf(t2, 0), lp(t2, 16384);
  var s2 = t2.transitions;
  if (null !== s2) for (const t3 of s2) t3.stop();
  hf(t2);
  var n2 = t2.parent;
  null !== n2 && null !== n2.first && ff(t2), t2.next = t2.prev = t2.teardown = t2.ctx = t2.deps = t2.fn = t2.nodes_start = t2.nodes_end = null;
}
function df(t2, e2) {
  for (; null !== t2; ) {
    var i2 = t2 === e2 ? null : Ud(t2);
    t2.remove(), t2 = i2;
  }
}
function ff(t2) {
  var e2 = t2.parent, i2 = t2.prev, s2 = t2.next;
  null !== i2 && (i2.next = s2), null !== s2 && (s2.prev = i2), null !== e2 && (e2.first === t2 && (e2.first = s2), e2.last === t2 && (e2.last = i2));
}
function pf(t2, e2) {
  var i2 = [];
  gf(t2, i2, true), mf(i2, () => {
    uf(t2), e2 && e2();
  });
}
function mf(t2, e2) {
  var i2 = t2.length;
  if (i2 > 0) {
    var s2 = () => --i2 || e2();
    for (var n2 of t2) n2.out(s2);
  } else e2();
}
function gf(t2, e2, i2) {
  if (0 === (t2.f & Ku)) {
    if (t2.f ^= Ku, null !== t2.transitions) for (const s3 of t2.transitions) (s3.is_global || i2) && e2.push(s3);
    for (var s2 = t2.first; null !== s2; ) {
      var n2 = s2.next;
      gf(s2, e2, !!(0 !== (s2.f & Gu) || 32 & s2.f) && i2), s2 = n2;
    }
  }
}
function vf(t2) {
  bf(t2, true);
}
function bf(t2, e2) {
  if (0 !== (t2.f & Ku)) {
    t2.f ^= Ku, 0 === (t2.f & qu) && (t2.f ^= qu), Uf(t2) && (lp(t2, Hu), ep(t2));
    for (var i2 = t2.first; null !== i2; ) {
      var s2 = i2.next;
      bf(i2, !!(0 !== (i2.f & Gu) || 32 & i2.f) && e2), i2 = s2;
    }
    if (null !== t2.transitions) for (const i3 of t2.transitions) (i3.is_global || e2) && i3.in();
  }
}
const _f = "undefined" == typeof requestIdleCallback ? (t2) => setTimeout(t2, 1) : requestIdleCallback;
let yf = [], wf = [];
function xf() {
  var t2 = yf;
  yf = [], Wu(t2);
}
function kf() {
  var t2 = wf;
  wf = [], Wu(t2);
}
function Sf(t2) {
  0 === yf.length && queueMicrotask(xf), yf.push(t2);
}
function Mf(t2, e2) {
  for (; null !== e2; ) {
    if (128 & e2.f) try {
      return void e2.fn(t2);
    } catch {
    }
    e2 = e2.parent;
  }
  throw t2;
}
let zf = false, Cf = null, Df = false, Rf = false;
function Pf(t2) {
  Rf = t2;
}
let Tf = [], $f = null, Ef = false;
function Af(t2) {
  $f = t2;
}
let Lf = null;
function Vf(t2) {
  Lf = t2;
}
let Of = null;
function If(t2) {
  null !== $f && $f.f & Xu && (null === Of ? Of = [t2] : Of.push(t2));
}
let Nf = null, Ff = 0, Wf = null, Bf = 1, jf = 0, qf = false;
function Hf() {
  return ++Bf;
}
function Uf(t2) {
  var _a3;
  var e2 = t2.f;
  if (0 !== (e2 & Hu)) return true;
  if (0 !== (e2 & Uu)) {
    var i2 = t2.deps, s2 = 0 !== (e2 & ju);
    if (null !== i2) {
      var n2, r2, o2 = !!(512 & e2), a2 = s2 && null !== Lf && !qf, l2 = i2.length;
      if (o2 || a2) {
        var h2 = t2, c2 = h2.parent;
        for (n2 = 0; n2 < l2; n2++) r2 = i2[n2], !o2 && ((_a3 = r2 == null ? void 0 : r2.reactions) == null ? void 0 : _a3.includes(h2)) || (r2.reactions ?? (r2.reactions = [])).push(h2);
        o2 && (h2.f ^= 512), a2 && null !== c2 && 0 === (c2.f & ju) && (h2.f ^= ju);
      }
      for (n2 = 0; n2 < l2; n2++) if (Uf(r2 = i2[n2]) && yd(r2), r2.wv > t2.wv) return true;
    }
    s2 && (null === Lf || qf) || lp(t2, qu);
  }
  return false;
}
function Kf(t2, e2, i2 = true) {
  var s2 = t2.reactions;
  if (null !== s2) for (var n2 = 0; n2 < s2.length; n2++) {
    var r2 = s2[n2];
    (Of == null ? void 0 : Of.includes(t2)) || (2 & r2.f ? Kf(r2, e2, false) : e2 === r2 && (i2 ? lp(r2, Hu) : 0 !== (r2.f & qu) && lp(r2, Uu), ep(r2)));
  }
}
function Yf(t2) {
  var _a3;
  var e2 = Nf, i2 = Ff, s2 = Wf, n2 = $f, r2 = qf, o2 = Of, a2 = od, l2 = Ef, h2 = t2.f;
  Nf = null, Ff = 0, Wf = null, qf = 0 !== (h2 & ju) && (Ef || !Df || null === $f), $f = 96 & h2 ? null : t2, Of = null, ad(t2.ctx), Ef = false, jf++, t2.f |= Xu;
  try {
    var c2 = (0, t2.fn)(), u2 = t2.deps;
    if (null !== Nf) {
      var d2;
      if (Xf(t2, Ff), null !== u2 && Ff > 0) for (u2.length = Ff + Nf.length, d2 = 0; d2 < Nf.length; d2++) u2[Ff + d2] = Nf[d2];
      else t2.deps = u2 = Nf;
      if (!qf) for (d2 = Ff; d2 < u2.length; d2++) ((_a3 = u2[d2]).reactions ?? (_a3.reactions = [])).push(t2);
    } else null !== u2 && Ff < u2.length && (Xf(t2, Ff), u2.length = Ff);
    if (cd() && null !== Wf && !Ef && null !== u2 && !(6146 & t2.f)) for (d2 = 0; d2 < Wf.length; d2++) Kf(Wf[d2], t2);
    return null !== n2 && n2 !== t2 && (jf++, null !== Wf && (null === s2 ? s2 = Wf : s2.push(...Wf))), c2;
  } catch (t3) {
    !function(t4) {
      var e3 = Lf;
      if (0 === (e3.f & Yu)) {
        if (!(128 & e3.f)) throw t4;
        e3.fn(t4);
      } else Mf(t4, e3);
    }(t3);
  } finally {
    Nf = e2, Ff = i2, Wf = s2, $f = n2, qf = r2, Of = o2, ad(a2), Ef = l2, t2.f ^= Xu;
  }
}
function Gf(t2, e2) {
  let i2 = e2.reactions;
  if (null !== i2) {
    var s2 = Du.call(i2, t2);
    if (-1 !== s2) {
      var n2 = i2.length - 1;
      0 === n2 ? i2 = e2.reactions = null : (i2[s2] = i2[n2], i2.pop());
    }
  }
  null === i2 && 2 & e2.f && (null === Nf || !Nf.includes(e2)) && (lp(e2, Uu), 768 & e2.f || (e2.f ^= 512), bd(e2), Xf(e2, 0));
}
function Xf(t2, e2) {
  var i2 = t2.deps;
  if (null !== i2) for (var s2 = e2; s2 < i2.length; s2++) Gf(t2, i2[s2]);
}
function Jf(t2) {
  var e2 = t2.f;
  if (!(16384 & e2)) {
    lp(t2, qu);
    var i2 = Lf, s2 = Df;
    Lf = t2, Df = true;
    try {
      16 & e2 ? function(t3) {
        for (var e3 = t3.first; null !== e3; ) {
          var i3 = e3.next;
          !(32 & e3.f) && uf(e3), e3 = i3;
        }
      }(t2) : cf(t2), hf(t2);
      var n2 = Yf(t2);
      t2.teardown = "function" == typeof n2 ? n2 : null, t2.wv = Bf;
    } finally {
      Df = s2, Lf = i2;
    }
  }
}
function Qf() {
  try {
    !function() {
      throw new Error("https://svelte.dev/e/effect_update_depth_exceeded");
    }();
  } catch (t2) {
    if (null === Cf) throw t2;
    Mf(t2, Cf);
  }
}
function Zf() {
  var t2 = Df;
  try {
    var e2 = 0;
    for (Df = true; Tf.length > 0; ) {
      e2++ > 1e3 && Qf();
      var i2 = Tf, s2 = i2.length;
      Tf = [];
      for (var n2 = 0; n2 < s2; n2++) tp(ip(i2[n2]));
      wd.clear();
    }
  } finally {
    zf = false, Df = t2, Cf = null;
  }
}
function tp(t2) {
  var e2 = t2.length;
  if (0 !== e2) for (var i2 = 0; i2 < e2; i2++) {
    var s2 = t2[i2];
    24576 & s2.f || Uf(s2) && (Jf(s2), null === s2.deps && null === s2.first && null === s2.nodes_start && (null === s2.teardown ? ff(s2) : s2.fn = null));
  }
}
function ep(t2) {
  zf || (zf = true, queueMicrotask(Zf));
  for (var e2 = Cf = t2; null !== e2.parent; ) {
    var i2 = (e2 = e2.parent).f;
    if (96 & i2) {
      if (0 === (i2 & qu)) return;
      e2.f ^= qu;
    }
  }
  Tf.push(e2);
}
function ip(t2) {
  for (var e2 = [], i2 = t2; null !== i2; ) {
    var s2 = i2.f, n2 = !!(96 & s2);
    if ((!n2 || 0 === (s2 & qu)) && 0 === (s2 & Ku)) {
      4 & s2 ? e2.push(i2) : n2 ? i2.f ^= qu : Uf(i2) && Jf(i2);
      var r2 = i2.first;
      if (null !== r2) {
        i2 = r2;
        continue;
      }
    }
    var o2 = i2.parent;
    for (i2 = i2.next; null === i2 && null !== o2; ) i2 = o2.next, o2 = o2.parent;
  }
  return e2;
}
function sp(t2) {
  for (; ; ) {
    if (yf.length > 0 && xf(), wf.length > 0 && kf(), 0 === Tf.length) return zf = false, void (Cf = null);
    zf = true, Zf();
  }
}
async function np() {
  await Promise.resolve(), sp();
}
function rp(t2) {
  var e2 = !!(2 & t2.f);
  if (null === $f || Ef) {
    if (e2 && null === t2.deps && null === t2.effects) {
      var i2 = t2, s2 = i2.parent;
      null !== s2 && 0 === (s2.f & ju) && (i2.f ^= ju);
    }
  } else if (!(Of == null ? void 0 : Of.includes(t2))) {
    var n2 = $f.deps;
    t2.rv < jf && (t2.rv = jf, null === Nf && null !== n2 && n2[Ff] === t2 ? Ff++ : null === Nf ? Nf = [t2] : qf && Nf.includes(t2) || Nf.push(t2));
  }
  return e2 && Uf(i2 = t2) && yd(i2), Rf && wd.has(t2) ? wd.get(t2) : t2.v;
}
function op(t2) {
  var e2 = Ef;
  try {
    return Ef = true, t2();
  } finally {
    Ef = e2;
  }
}
const ap = -7169;
function lp(t2, e2) {
  t2.f = t2.f & ap | e2;
}
function hp(t2) {
  if ("object" == typeof t2 && t2 && !(t2 instanceof EventTarget)) {
    if (Ju in t2) cp(t2);
    else if (!Array.isArray(t2)) for (let e2 in t2) {
      const i2 = t2[e2];
      "object" == typeof i2 && i2 && Ju in i2 && cp(i2);
    }
  }
}
function cp(t2, e2 = /* @__PURE__ */ new Set()) {
  if (!("object" != typeof t2 || null === t2 || t2 instanceof EventTarget || e2.has(t2))) {
    e2.add(t2), t2 instanceof Date && t2.getTime();
    for (let i3 in t2) try {
      cp(t2[i3], e2);
    } catch (t3) {
    }
    const i2 = Vu(t2);
    if (i2 !== Object.prototype && i2 !== Array.prototype && i2 !== Map.prototype && i2 !== Set.prototype && i2 !== Date.prototype) {
      const e3 = Eu(i2);
      for (let i3 in e3) {
        const s2 = e3[i3].get;
        if (s2) try {
          s2.call(t2);
        } catch (t3) {
        }
      }
    }
  }
}
function up(t2, e2) {
  if (e2) {
    const e3 = document.body;
    t2.autofocus = true, Sf(() => {
      document.activeElement === e3 && t2.focus();
    });
  }
}
let dp = false;
function fp() {
  dp || (dp = true, document.addEventListener("reset", (t2) => {
    Promise.resolve().then(() => {
      var _a3;
      if (!t2.defaultPrevented) for (const e2 of t2.target.elements) (_a3 = e2.__on_r) == null ? void 0 : _a3.call(e2);
    });
  }, { capture: true }));
}
function pp(t2) {
  var e2 = $f, i2 = Lf;
  Af(null), Vf(null);
  try {
    return t2();
  } finally {
    Af(e2), Vf(i2);
  }
}
const mp = /* @__PURE__ */ new Set(), gp = /* @__PURE__ */ new Set();
function vp(t2, e2, i2, s2 = {}) {
  function n2(t3) {
    if (s2.capture || yp.call(e2, t3), !t3.cancelBubble) return pp(() => i2 == null ? void 0 : i2.call(this, t3));
  }
  return t2.startsWith("pointer") || t2.startsWith("touch") || "wheel" === t2 ? Sf(() => {
    e2.addEventListener(t2, n2, s2);
  }) : e2.addEventListener(t2, n2, s2), n2;
}
function bp(t2, e2, i2, s2, n2) {
  var r2 = { capture: s2, passive: n2 }, o2 = vp(t2, e2, i2, r2);
  (e2 === document.body || e2 === window || e2 === document || e2 instanceof HTMLMediaElement) && Zd(() => {
    e2.removeEventListener(t2, o2, r2);
  });
}
function _p(t2) {
  for (var e2 = 0; e2 < t2.length; e2++) mp.add(t2[e2]);
  for (var i2 of gp) i2(t2);
}
function yp(t2) {
  var _a3;
  var e2 = this, i2 = e2.ownerDocument, s2 = t2.type, n2 = ((_a3 = t2.composedPath) == null ? void 0 : _a3.call(t2)) || [], r2 = n2[0] || t2.target, o2 = 0, a2 = t2.__root;
  if (a2) {
    var l2 = n2.indexOf(a2);
    if (-1 !== l2 && (e2 === document || e2 === window)) return void (t2.__root = e2);
    var h2 = n2.indexOf(e2);
    if (-1 === h2) return;
    l2 <= h2 && (o2 = l2);
  }
  if ((r2 = n2[o2] || t2.target) !== e2) {
    Tu(t2, "currentTarget", { configurable: true, get: () => r2 || i2 });
    var c2 = $f, u2 = Lf;
    Af(null), Vf(null);
    try {
      for (var d2, f2 = []; null !== r2; ) {
        var p2 = r2.assignedSlot || r2.parentNode || r2.host || null;
        try {
          var m2 = r2["__" + s2];
          if (null != m2 && (!r2.disabled || t2.target === r2)) if (Cu(m2)) {
            var [g2, ...v2] = m2;
            g2.apply(r2, [t2, ...v2]);
          } else m2.call(r2, t2);
        } catch (t3) {
          d2 ? f2.push(t3) : d2 = t3;
        }
        if (t2.cancelBubble || p2 === e2 || null === p2) break;
        r2 = p2;
      }
      if (d2) {
        for (let t3 of f2) queueMicrotask(() => {
          throw t3;
        });
        throw d2;
      }
    } finally {
      t2.__root = e2, delete t2.currentTarget, Af(c2), Vf(u2);
    }
  }
}
function wp(t2) {
  var e2 = document.createElement("template");
  return e2.innerHTML = t2.replaceAll("<!>", "<!---->"), e2.content;
}
function xp(t2, e2) {
  var i2 = Lf;
  null === i2.nodes_start && (i2.nodes_start = t2, i2.nodes_end = e2);
}
function kp(t2, e2) {
  var i2, s2 = !!(1 & e2), n2 = !!(2 & e2), r2 = !t2.startsWith("<!>");
  return () => {
    if (Td) return xp(Pd, null), Pd;
    void 0 === i2 && (i2 = wp(r2 ? t2 : "<!>" + t2), s2 || (i2 = Hd(i2)));
    var e3 = n2 || Fd ? document.importNode(i2, true) : i2.cloneNode(true);
    return s2 ? xp(Hd(e3), e3.lastChild) : xp(e3, e3), e3;
  };
}
function Sp(t2 = "") {
  if (!Td) {
    var e2 = qd(t2 + "");
    return xp(e2, e2), e2;
  }
  var i2 = Pd;
  return 3 !== i2.nodeType && (i2.before(i2 = qd()), Ed(i2)), xp(i2, i2), i2;
}
function Mp() {
  if (Td) return xp(Pd, null), Pd;
  var t2 = document.createDocumentFragment(), e2 = document.createComment(""), i2 = qd();
  return t2.append(e2, i2), xp(e2, i2), t2;
}
function zp(t2, e2) {
  if (Td) return Lf.nodes_end = Pd, void Ad();
  null !== t2 && t2.before(e2);
}
function Cp(t2) {
  return t2.endsWith("capture") && "gotpointercapture" !== t2 && "lostpointercapture" !== t2;
}
const Dp = ["beforeinput", "click", "change", "dblclick", "contextmenu", "focusin", "focusout", "input", "keydown", "keyup", "mousedown", "mousemove", "mouseout", "mouseover", "mouseup", "pointerdown", "pointermove", "pointerout", "pointerover", "pointerup", "touchend", "touchmove", "touchstart"];
function Rp(t2) {
  return Dp.includes(t2);
}
const Pp = { formnovalidate: "formNoValidate", ismap: "isMap", nomodule: "noModule", playsinline: "playsInline", readonly: "readOnly", defaultvalue: "defaultValue", defaultchecked: "defaultChecked", srcobject: "srcObject", novalidate: "noValidate", allowfullscreen: "allowFullscreen", disablepictureinpicture: "disablePictureInPicture", disableremoteplayback: "disableRemotePlayback" };
function Tp(t2) {
  return t2 = t2.toLowerCase(), Pp[t2] ?? t2;
}
const $p = ["touchstart", "touchmove"], Ep = ["textarea", "script", "style", "title"];
let Ap = true;
function Lp(t2) {
  Ap = t2;
}
function Vp(t2, e2) {
  var i2 = null == e2 ? "" : "object" == typeof e2 ? e2 + "" : e2;
  i2 !== (t2.__t ?? (t2.__t = t2.nodeValue)) && (t2.__t = i2, t2.nodeValue = i2 + "");
}
function Op(t2, e2) {
  return Fp(t2, e2);
}
function Ip(t2, e2) {
  jd(), e2.intro = e2.intro ?? false;
  const i2 = e2.target, s2 = Td, n2 = Pd;
  try {
    for (var r2 = Hd(i2); r2 && (8 !== r2.nodeType || "[" !== r2.data); ) r2 = Ud(r2);
    if (!r2) throw Mu;
    $d(true), Ed(r2), Ad();
    const s3 = Fp(t2, { ...e2, anchor: r2 });
    if (null === Pd || 8 !== Pd.nodeType || "]" !== Pd.data) throw Mu;
    return $d(false), s3;
  } catch (s3) {
    if (s3 === Mu) return false === e2.recover && function() {
      throw new Error("https://svelte.dev/e/hydration_failed");
    }(), jd(), Xd(i2), $d(false), Op(t2, e2);
    throw s3;
  } finally {
    $d(s2), Ed(n2);
  }
}
const Np = /* @__PURE__ */ new Map();
function Fp(t2, { target: e2, anchor: i2, props: s2 = {}, events: n2, context: r2, intro: o2 = true }) {
  jd();
  var a2 = /* @__PURE__ */ new Set(), l2 = (t3) => {
    for (var i3 = 0; i3 < t3.length; i3++) {
      var s3 = t3[i3];
      if (!a2.has(s3)) {
        a2.add(s3);
        var n3 = (o3 = s3, $p.includes(o3));
        e2.addEventListener(s3, yp, { passive: n3 });
        var r3 = Np.get(s3);
        void 0 === r3 ? (document.addEventListener(s3, yp, { passive: n3 }), Np.set(s3, 1)) : Np.set(s3, r3 + 1);
      }
    }
    var o3;
  };
  l2(Ru(mp)), gp.add(l2);
  var h2 = void 0, c2 = function() {
    const c3 = Qd(64, () => {
      var c4 = i2 ?? e2.appendChild(qd());
      return lf(() => {
        r2 && (ld({}), od.c = r2), n2 && (s2.$$events = n2), Td && xp(c4, null), Ap = o2, h2 = t2(c4, s2) || {}, Ap = true, Td && (Lf.nodes_end = Pd), r2 && hd();
      }), () => {
        var _a3;
        for (var t3 of a2) {
          e2.removeEventListener(t3, yp);
          var s3 = Np.get(t3);
          0 === --s3 ? (document.removeEventListener(t3, yp), Np.delete(t3)) : Np.set(t3, s3);
        }
        gp.delete(l2), c4 !== i2 && ((_a3 = c4.parentNode) == null ? void 0 : _a3.removeChild(c4));
      };
    }, true);
    return (t3 = {}) => new Promise((e3) => {
      t3.outro ? pf(c3, () => {
        uf(c3), e3(void 0);
      }) : (uf(c3), e3(void 0));
    });
  }();
  return Wp.set(h2, c2), h2;
}
let Wp = /* @__PURE__ */ new WeakMap();
function Bp(t2) {
  null === od && rd(), nd && null !== od.l ? function() {
    var t3 = od.l;
    return t3.u ?? (t3.u = { a: [], b: [], m: [] });
  }().m.push(t2) : tf(() => {
    const e2 = op(t2);
    if ("function" == typeof e2) return e2;
  });
}
function jp(t2) {
  null === od && rd(), Bp(() => () => op(t2));
}
function qp() {
  const t2 = od;
  return null === t2 && rd(), (e2, i2, s2) => {
    var _a3;
    const n2 = (_a3 = t2.s.$$events) == null ? void 0 : _a3[e2];
    if (n2) {
      const r2 = Cu(n2) ? n2.slice() : [n2], o2 = function(t3, e3, { bubbles: i3 = false, cancelable: s3 = false } = {}) {
        return new CustomEvent(t3, { detail: e3, bubbles: i3, cancelable: s3 });
      }(e2, i2, s2);
      for (const e3 of r2) e3.call(t2.x, o2);
      return !o2.defaultPrevented;
    }
    return true;
  };
}
function Hp(t2, e2, [i2, s2] = [0, 0]) {
  Td && 0 === i2 && Ad();
  var n2 = t2, r2 = null, o2 = null, a2 = zu, l2 = false;
  const h2 = (t3, e3 = true) => {
    l2 = true, c2(e3, t3);
  }, c2 = (t3, e3) => {
    if (a2 === (a2 = t3)) return;
    let l3 = false;
    if (Td && -1 !== s2) {
      if (0 === i2) {
        const t4 = Id(n2);
        "[" === t4 ? s2 = 0 : t4 === Su ? s2 = 1 / 0 : (s2 = parseInt(t4.substring(1))) != s2 && (s2 = a2 ? 1 / 0 : -1);
      }
      !!a2 == s2 > i2 && (Ed(n2 = Od()), $d(false), l3 = true, s2 = -1);
    }
    a2 ? (r2 ? vf(r2) : e3 && (r2 = lf(() => e3(n2))), o2 && pf(o2, () => {
      o2 = null;
    })) : (o2 ? vf(o2) : e3 && (o2 = lf(() => e3(n2, [i2 + 1, s2]))), r2 && pf(r2, () => {
      r2 = null;
    })), l3 && $d(true);
  };
  af(() => {
    l2 = false, e2(h2), l2 || c2(null, null);
  }, i2 > 0 ? Gu : 0), Td && (n2 = Pd);
}
function Up(t2, e2, i2) {
  Td && Ad();
  var s2, n2 = t2, r2 = zu, o2 = cd() ? id : ed;
  af(() => {
    o2(r2, r2 = e2()) && (s2 && pf(s2), s2 = lf(() => i2(n2)));
  }), Td && (n2 = Pd);
}
function Kp(t2, e2) {
  return e2;
}
function Yp(t2, e2, i2, s2, n2, r2 = null) {
  var o2 = t2, a2 = { flags: e2, items: /* @__PURE__ */ new Map(), first: null };
  if (4 & e2) {
    var l2 = t2;
    o2 = Td ? Ed(Hd(l2)) : l2.appendChild(qd());
  }
  Td && Ad();
  var h2 = null, c2 = false, u2 = vd(() => {
    var t3 = i2();
    return Cu(t3) ? t3 : null == t3 ? [] : Ru(t3);
  });
  af(() => {
    var t3 = rp(u2), l3 = t3.length;
    if (c2 && 0 === l3) return;
    c2 = 0 === l3;
    let d2 = false;
    if (Td && Id(o2) === Su != (0 === l3) && (Ed(o2 = Od()), $d(false), d2 = true), Td) {
      for (var f2, p2 = null, m2 = 0; m2 < l3; m2++) {
        if (8 === Pd.nodeType && "]" === Pd.data) {
          o2 = Pd, d2 = true, $d(false);
          break;
        }
        var g2 = t3[m2], v2 = s2(g2, m2);
        f2 = Xp(Pd, a2, p2, null, g2, v2, m2, n2, e2, i2), a2.items.set(v2, f2), p2 = f2;
      }
      l3 > 0 && Ed(Od());
    }
    Td || function(t4, e3, i3, s3, n3, r3, o3) {
      var _a3, _b3, _c3, _d3;
      var a3, l4, h3, c3, u3, d3, f3 = !!(8 & n3), p3 = !!(3 & n3), m3 = t4.length, g3 = e3.items, v3 = e3.first, b2 = null, _2 = [], y2 = [];
      if (f3) for (d3 = 0; d3 < m3; d3 += 1) c3 = r3(h3 = t4[d3], d3), void 0 !== (u3 = g3.get(c3)) && ((_a3 = u3.a) == null ? void 0 : _a3.measure(), (l4 ?? (l4 = /* @__PURE__ */ new Set())).add(u3));
      for (d3 = 0; d3 < m3; d3 += 1) if (c3 = r3(h3 = t4[d3], d3), void 0 !== (u3 = g3.get(c3))) {
        if (p3 && Gp(u3, h3, d3, n3), 0 !== (u3.e.f & Ku) && (vf(u3.e), f3 && ((_b3 = u3.a) == null ? void 0 : _b3.unfix(), (l4 ?? (l4 = /* @__PURE__ */ new Set())).delete(u3))), u3 !== v3) {
          if (void 0 !== a3 && a3.has(u3)) {
            if (_2.length < y2.length) {
              var w2, x2 = y2[0];
              b2 = x2.prev;
              var k2 = _2[0], S2 = _2[_2.length - 1];
              for (w2 = 0; w2 < _2.length; w2 += 1) Jp(_2[w2], x2, i3);
              for (w2 = 0; w2 < y2.length; w2 += 1) a3.delete(y2[w2]);
              Qp(e3, k2.prev, S2.next), Qp(e3, b2, k2), Qp(e3, S2, x2), v3 = x2, b2 = S2, d3 -= 1, _2 = [], y2 = [];
            } else a3.delete(u3), Jp(u3, v3, i3), Qp(e3, u3.prev, u3.next), Qp(e3, u3, null === b2 ? e3.first : b2.next), Qp(e3, b2, u3), b2 = u3;
            continue;
          }
          for (_2 = [], y2 = []; null !== v3 && v3.k !== c3; ) 0 === (v3.e.f & Ku) && (a3 ?? (a3 = /* @__PURE__ */ new Set())).add(v3), y2.push(v3), v3 = v3.next;
          if (null === v3) continue;
          u3 = v3;
        }
        _2.push(u3), b2 = u3, v3 = u3.next;
      } else b2 = Xp(v3 ? v3.e.nodes_start : i3, e3, b2, null === b2 ? e3.first : b2.next, h3, c3, d3, s3, n3, o3), g3.set(c3, b2), _2 = [], y2 = [], v3 = b2.next;
      if (null !== v3 || void 0 !== a3) {
        for (var M2 = void 0 === a3 ? [] : Ru(a3); null !== v3; ) 0 === (v3.e.f & Ku) && M2.push(v3), v3 = v3.next;
        var z2 = M2.length;
        if (z2 > 0) {
          var C2 = 4 & n3 && 0 === m3 ? i3 : null;
          if (f3) {
            for (d3 = 0; d3 < z2; d3 += 1) (_c3 = M2[d3].a) == null ? void 0 : _c3.measure();
            for (d3 = 0; d3 < z2; d3 += 1) (_d3 = M2[d3].a) == null ? void 0 : _d3.fix();
          }
          !function(t5, e4, i4, s4) {
            for (var n4 = [], r4 = e4.length, o4 = 0; o4 < r4; o4++) gf(e4[o4].e, n4, true);
            var a4 = r4 > 0 && 0 === n4.length && null !== i4;
            if (a4) {
              var l5 = i4.parentNode;
              Xd(l5), l5.append(i4), s4.clear(), Qp(t5, e4[0].prev, e4[r4 - 1].next);
            }
            mf(n4, () => {
              for (var i5 = 0; i5 < r4; i5++) {
                var n5 = e4[i5];
                a4 || (s4.delete(n5.k), Qp(t5, n5.prev, n5.next)), uf(n5.e, !a4);
              }
            });
          }(e3, M2, C2, g3);
        }
      }
      f3 && Sf(() => {
        var _a4;
        if (void 0 !== l4) for (u3 of l4) (_a4 = u3.a) == null ? void 0 : _a4.apply();
      }), Lf.first = e3.first && e3.first.e, Lf.last = b2 && b2.e;
    }(t3, a2, o2, n2, e2, s2, i2), null !== r2 && (0 === l3 ? h2 ? vf(h2) : h2 = lf(() => r2(o2)) : null !== h2 && pf(h2, () => {
      h2 = null;
    })), d2 && $d(true), rp(u2);
  }), Td && (o2 = Pd);
}
function Gp(t2, e2, i2, s2) {
  1 & s2 && Cd(t2.v, e2), 2 & s2 ? Cd(t2.i, i2) : t2.i = i2;
}
function Xp(t2, e2, i2, s2, n2, r2, o2, a2, l2, h2) {
  var c2 = 1 & l2 ? 16 & l2 ? xd(n2) : Sd(n2) : n2, u2 = 2 & l2 ? xd(o2) : o2, d2 = { i: u2, v: c2, k: r2, a: null, e: null, prev: i2, next: s2 };
  try {
    return d2.e = lf(() => a2(t2, c2, u2, h2), Td), d2.e.prev = i2 && i2.e, d2.e.next = s2 && s2.e, null === i2 ? e2.first = d2 : (i2.next = d2, i2.e.next = d2.e), null !== s2 && (s2.prev = d2, s2.e.prev = d2.e), d2;
  } finally {
  }
}
function Jp(t2, e2, i2) {
  for (var s2 = t2.next ? t2.next.e.nodes_start : i2, n2 = e2 ? e2.e.nodes_start : i2, r2 = t2.e.nodes_start; r2 !== s2; ) {
    var o2 = Ud(r2);
    n2.before(r2), r2 = o2;
  }
}
function Qp(t2, e2, i2) {
  null === e2 ? t2.first = i2 : (e2.next = i2, e2.e.next = i2 && i2.e), null !== i2 && (i2.prev = e2, i2.e.prev = e2 && e2.e);
}
function Zp(t2, e2, i2 = false, s2 = false, n2 = false) {
  var r2 = t2, o2 = "";
  of(() => {
    var t3 = Lf;
    if (o2 !== (o2 = e2() ?? "")) {
      if (null !== t3.nodes_start && (df(t3.nodes_start, t3.nodes_end), t3.nodes_start = t3.nodes_end = null), "" !== o2) {
        if (Td) {
          Pd.data;
          for (var n3 = Ad(), a2 = n3; null !== n3 && (8 !== n3.nodeType || "" !== n3.data); ) a2 = n3, n3 = Ud(n3);
          if (null === n3) throw Mu;
          return xp(Pd, a2), void (r2 = Ed(n3));
        }
        var l2 = o2 + "";
        i2 ? l2 = `<svg>${l2}</svg>` : s2 && (l2 = `<math>${l2}</math>`);
        var h2 = wp(l2);
        if ((i2 || s2) && (h2 = Hd(h2)), xp(Hd(h2), h2.lastChild), i2 || s2) for (; Hd(h2); ) r2.before(Hd(h2));
        else r2.before(h2);
      }
    } else Td && Ad();
  });
}
function tm(t2, e2, i2, s2, n2) {
  var _a3;
  Td && Ad();
  var r2 = (_a3 = e2.$$slots) == null ? void 0 : _a3[i2], o2 = false;
  true === r2 && (r2 = e2["default" === i2 ? "children" : i2], o2 = true), void 0 === r2 ? null !== n2 && n2(t2) : r2(t2, o2 ? () => s2 : s2);
}
function em(t2, e2) {
  Sf(() => {
    var i2 = t2.getRootNode(), s2 = i2.host ? i2 : i2.head ?? i2.ownerDocument.head;
    if (!s2.querySelector("#" + e2.hash)) {
      const t3 = document.createElement("style");
      t3.id = e2.hash, t3.textContent = e2.code, s2.appendChild(t3);
    }
  });
}
function im(t2, e2) {
  var i2, s2 = void 0;
  af(() => {
    s2 !== (s2 = e2()) && (i2 && (uf(i2), i2 = null), s2 && (i2 = lf(() => {
      ef(() => s2(t2));
    })));
  });
}
function sm(t2) {
  var e2, i2, s2 = "";
  if ("string" == typeof t2 || "number" == typeof t2) s2 += t2;
  else if ("object" == typeof t2) if (Array.isArray(t2)) {
    var n2 = t2.length;
    for (e2 = 0; e2 < n2; e2++) t2[e2] && (i2 = sm(t2[e2])) && (s2 && (s2 += " "), s2 += i2);
  } else for (i2 in t2) t2[i2] && (s2 && (s2 += " "), s2 += i2);
  return s2;
}
function nm(t2) {
  return "object" == typeof t2 ? function() {
    for (var t3, e2, i2 = 0, s2 = "", n2 = arguments.length; i2 < n2; i2++) (t3 = arguments[i2]) && (e2 = sm(t3)) && (s2 && (s2 += " "), s2 += e2);
    return s2;
  }(t2) : t2 ?? "";
}
const rm = [..." 	\n\r\f \v\uFEFF"];
function om(t2, e2 = false) {
  var i2 = e2 ? " !important;" : ";", s2 = "";
  for (var n2 in t2) {
    var r2 = t2[n2];
    null != r2 && "" !== r2 && (s2 += " " + n2 + ": " + r2 + i2);
  }
  return s2;
}
function am(t2) {
  return "-" !== t2[0] || "-" !== t2[1] ? t2.toLowerCase() : t2;
}
function lm(t2, e2, i2, s2, n2, r2) {
  var o2 = t2.__className;
  if (Td || o2 !== i2 || void 0 === o2) {
    var a2 = function(t3, e3, i3) {
      var s3 = null == t3 ? "" : "" + t3;
      if (e3 && (s3 = s3 ? s3 + " " + e3 : e3), i3) {
        for (var n3 in i3) if (i3[n3]) s3 = s3 ? s3 + " " + n3 : n3;
        else if (s3.length) for (var r3 = n3.length, o3 = 0; (o3 = s3.indexOf(n3, o3)) >= 0; ) {
          var a3 = o3 + r3;
          0 !== o3 && !rm.includes(s3[o3 - 1]) || a3 !== s3.length && !rm.includes(s3[a3]) ? o3 = a3 : s3 = (0 === o3 ? "" : s3.substring(0, o3)) + s3.substring(a3 + 1);
        }
      }
      return "" === s3 ? null : s3;
    }(i2, s2, r2);
    Td && a2 === t2.getAttribute("class") || (null == a2 ? t2.removeAttribute("class") : e2 ? t2.className = a2 : t2.setAttribute("class", a2)), t2.__className = i2;
  } else if (r2 && n2 !== r2) for (var l2 in r2) {
    var h2 = !!r2[l2];
    null != n2 && h2 === !!n2[l2] || t2.classList.toggle(l2, h2);
  }
  return r2;
}
function hm(t2, e2 = {}, i2, s2) {
  for (var n2 in i2) {
    var r2 = i2[n2];
    e2[n2] !== r2 && (null == i2[n2] ? t2.style.removeProperty(n2) : t2.style.setProperty(n2, r2, s2));
  }
}
function cm(t2, e2, i2, s2) {
  var n2 = t2.__style;
  if (Td || n2 !== e2) {
    var r2 = function(t3, e3) {
      if (e3) {
        var i3, s3, n3 = "";
        if (Array.isArray(e3) ? (i3 = e3[0], s3 = e3[1]) : i3 = e3, t3) {
          t3 = String(t3).replaceAll(/\s*\/\*.*?\*\/\s*/g, "").trim();
          var r3 = false, o2 = 0, a2 = false, l2 = [];
          i3 && l2.push(...Object.keys(i3).map(am)), s3 && l2.push(...Object.keys(s3).map(am));
          var h2 = 0, c2 = -1;
          const e4 = t3.length;
          for (var u2 = 0; u2 < e4; u2++) {
            var d2 = t3[u2];
            if (a2 ? "/" === d2 && "*" === t3[u2 - 1] && (a2 = false) : r3 ? r3 === d2 && (r3 = false) : "/" === d2 && "*" === t3[u2 + 1] ? a2 = true : '"' === d2 || "'" === d2 ? r3 = d2 : "(" === d2 ? o2++ : ")" === d2 && o2--, !a2 && false === r3 && 0 === o2) {
              if (":" === d2 && -1 === c2) c2 = u2;
              else if (";" === d2 || u2 === e4 - 1) {
                if (-1 !== c2) {
                  var f2 = am(t3.substring(h2, c2).trim());
                  l2.includes(f2) || (";" !== d2 && u2++, n3 += " " + t3.substring(h2, u2).trim() + ";");
                }
                h2 = u2 + 1, c2 = -1;
              }
            }
          }
        }
        return i3 && (n3 += om(i3)), s3 && (n3 += om(s3, true)), "" === (n3 = n3.trim()) ? null : n3;
      }
      return null == t3 ? null : String(t3);
    }(e2, s2);
    Td && r2 === t2.getAttribute("style") || (null == r2 ? t2.removeAttribute("style") : t2.style.cssText = r2), t2.__style = e2;
  } else s2 && (Array.isArray(s2) ? (hm(t2, i2 == null ? void 0 : i2[0], s2[0]), hm(t2, i2 == null ? void 0 : i2[1], s2[1], "important")) : hm(t2, i2, s2));
  return s2;
}
function um(t2, e2, i2) {
  if (t2.multiple) {
    if (null == e2) return;
    if (!Cu(e2)) return;
    for (var s2 of t2.options) s2.selected = e2.includes(dm(s2));
  } else {
    for (s2 of t2.options) if (pd(dm(s2), e2)) return void (s2.selected = true);
    i2 && void 0 === e2 || (t2.selectedIndex = -1);
  }
}
function dm(t2) {
  return "__value" in t2 ? t2.__value : t2.value;
}
const fm = Symbol("class"), pm = Symbol("style"), mm = Symbol("is custom element"), gm = Symbol("is html");
function vm(t2) {
  if (Td) {
    var e2 = false, i2 = () => {
      if (!e2) {
        if (e2 = true, t2.hasAttribute("value")) {
          var i3 = t2.value;
          _m(t2, "value", null), t2.value = i3;
        }
        if (t2.hasAttribute("checked")) {
          var s2 = t2.checked;
          _m(t2, "checked", null), t2.checked = s2;
        }
      }
    };
    t2.__on_r = i2, function(t3) {
      0 === wf.length && _f(kf), wf.push(t3);
    }(i2), fp();
  }
}
function bm(t2, e2) {
  e2 ? t2.hasAttribute("selected") || t2.setAttribute("selected", "") : t2.removeAttribute("selected");
}
function _m(t2, e2, i2, s2) {
  var n2 = wm(t2);
  Td && (n2[e2] = t2.getAttribute(e2), "src" === e2 || "srcset" === e2 || "href" === e2 && "LINK" === t2.nodeName) || n2[e2] !== (n2[e2] = i2) && ("loading" === e2 && (t2[Zu] = i2), null == i2 ? t2.removeAttribute(e2) : "string" != typeof i2 && km(t2).includes(e2) ? t2[e2] = i2 : t2.setAttribute(e2, i2));
}
function ym(t2, e2, i2 = [], s2, n2 = false, r2 = md) {
  const o2 = i2.map(r2);
  var a2 = void 0, l2 = {}, h2 = "SELECT" === t2.nodeName, c2 = false;
  af(() => {
    var i3 = e2(...o2.map(rp));
    !function(t3, e3, i4, s3) {
      var n4 = wm(t3), r3 = n4[mm], o3 = !n4[gm];
      let a3 = Td && r3;
      a3 && $d(false);
      var l3 = e3 || {}, h3 = "OPTION" === t3.tagName;
      for (var c3 in e3) c3 in i4 || (i4[c3] = null);
      i4.class ? i4.class = nm(i4.class) : i4[fm] && (i4.class = null), i4[pm] && (i4.style ?? (i4.style = null));
      var u2 = km(t3);
      for (const v2 in i4) {
        let b2 = i4[v2];
        if (h3 && "value" === v2 && null == b2) t3.value = t3.__value = "", l3[v2] = b2;
        else if ("class" !== v2) if ("style" !== v2) {
          var d2 = l3[v2];
          if (b2 !== d2) {
            l3[v2] = b2;
            var f2 = v2[0] + v2[1];
            if ("$$" !== f2) if ("on" === f2) {
              const _2 = {}, y2 = "$$" + v2;
              let w2 = v2.slice(2);
              var p2 = Rp(w2);
              if (Cp(w2) && (w2 = w2.slice(0, -7), _2.capture = true), !p2 && d2) {
                if (null != b2) continue;
                t3.removeEventListener(w2, l3[y2], _2), l3[y2] = null;
              }
              if (null != b2) if (p2) t3[`__${w2}`] = b2, _p([w2]);
              else {
                let x2 = function(t4) {
                  l3[v2].call(this, t4);
                };
                l3[y2] = vp(w2, t3, x2, _2);
              }
              else p2 && (t3[`__${w2}`] = void 0);
            } else if ("style" === v2) _m(t3, v2, b2);
            else if ("autofocus" === v2) up(t3, Boolean(b2));
            else if (r3 || "__value" !== v2 && ("value" !== v2 || null == b2)) if ("selected" === v2 && h3) bm(t3, b2);
            else {
              var m2 = v2;
              o3 || (m2 = Tp(m2));
              var g2 = "defaultValue" === m2 || "defaultChecked" === m2;
              if (null != b2 || r3 || g2) g2 || u2.includes(m2) && (r3 || "string" != typeof b2) ? t3[m2] = b2 : "function" != typeof b2 && _m(t3, m2, b2);
              else if (n4[v2] = null, "value" === m2 || "checked" === m2) {
                let k2 = t3;
                const S2 = void 0 === e3;
                if ("value" === m2) {
                  let M2 = k2.defaultValue;
                  k2.removeAttribute(m2), k2.defaultValue = M2, k2.value = k2.__value = S2 ? M2 : null;
                } else {
                  let z2 = k2.defaultChecked;
                  k2.removeAttribute(m2), k2.defaultChecked = z2, k2.checked = !!S2 && z2;
                }
              } else t3.removeAttribute(v2);
            }
            else t3.value = t3.__value = b2;
          }
        } else cm(t3, b2, e3 == null ? void 0 : e3[pm], i4[pm]), l3[v2] = b2, l3[pm] = i4[pm];
        else lm(t3, "http://www.w3.org/1999/xhtml" === t3.namespaceURI, b2, s3, e3 == null ? void 0 : e3[fm], i4[fm]), l3[v2] = b2, l3[fm] = i4[fm];
      }
      a3 && $d(true);
    }(t2, a2, i3, s2), c2 && h2 && "value" in i3 && um(t2, i3.value, false);
    for (let t3 of Object.getOwnPropertySymbols(l2)) i3[t3] || uf(l2[t3]);
    for (let e3 of Object.getOwnPropertySymbols(i3)) {
      var n3 = i3[e3];
      "@attach" !== e3.description || a2 && n3 === a2[e3] || (l2[e3] && uf(l2[e3]), l2[e3] = lf(() => im(t2, () => n3)));
    }
    a2 = i3;
  }), h2 && function(t3, e3) {
    let i3 = true;
    ef(() => {
      e3 && um(t3, op(e3), i3), i3 = false;
      var s3 = new MutationObserver(() => {
        var e4 = t3.__value;
        um(t3, e4);
      });
      return s3.observe(t3, { childList: true, subtree: true, attributes: true, attributeFilter: ["value"] }), () => {
        s3.disconnect();
      };
    });
  }(t2, () => a2.value), c2 = true;
}
function wm(t2) {
  return t2.__attributes ?? (t2.__attributes = { [mm]: t2.nodeName.includes("-"), [gm]: "http://www.w3.org/1999/xhtml" === t2.namespaceURI });
}
var xm = /* @__PURE__ */ new Map();
function km(t2) {
  var e2, i2 = xm.get(t2.nodeName);
  if (i2) return i2;
  xm.set(t2.nodeName, i2 = []);
  for (var s2 = t2, n2 = Element.prototype; n2 !== s2; ) {
    for (var r2 in e2 = Eu(s2)) e2[r2].set && i2.push(r2);
    s2 = Vu(s2);
  }
  return i2;
}
const Sm = { tick: (t2) => requestAnimationFrame(t2), now: () => performance.now(), tasks: /* @__PURE__ */ new Set() };
function Mm() {
  const t2 = Sm.now();
  Sm.tasks.forEach((e2) => {
    e2.c(t2) || (Sm.tasks.delete(e2), e2.f());
  }), 0 !== Sm.tasks.size && Sm.tick(Mm);
}
function zm(t2, e2) {
  pp(() => {
    t2.dispatchEvent(new CustomEvent(e2));
  });
}
function Cm(t2) {
  if ("float" === t2) return "cssFloat";
  if ("offset" === t2) return "cssOffset";
  if (t2.startsWith("--")) return t2;
  const e2 = t2.split("-");
  return 1 === e2.length ? e2[0] : e2[0] + e2.slice(1).map((t3) => t3[0].toUpperCase() + t3.slice(1)).join("");
}
function Dm(t2) {
  const e2 = {}, i2 = t2.split(";");
  for (const t3 of i2) {
    const [i3, s2] = t3.split(":");
    if (!i3 || void 0 === s2) break;
    e2[Cm(i3.trim())] = s2.trim();
  }
  return e2;
}
const Rm = (t2) => t2;
function Pm(t2, e2, i2, s2) {
  var n2, r2, o2 = !!(4 & t2), a2 = e2.inert, l2 = e2.style.overflow, h2 = { is_global: o2, in() {
    e2.inert = a2, r2 == null ? void 0 : r2.abort(), zm(e2, "introstart"), r2 = Tm(e2, function() {
      var t3 = $f, r3 = Lf;
      Af(null), Vf(null);
      try {
        return n2 ?? (n2 = i2()(e2, (s2 == null ? void 0 : s2()) ?? {}, { direction: "in" }));
      } finally {
        Af(t3), Vf(r3);
      }
    }(), void 0, 1, () => {
      zm(e2, "introend"), r2 == null ? void 0 : r2.abort(), r2 = n2 = void 0, e2.style.overflow = l2;
    });
  }, out: (t3) => (t3 == null ? void 0 : t3(), void (n2 = void 0)), stop: () => {
    r2 == null ? void 0 : r2.abort();
  } }, c2 = Lf;
  if ((c2.transitions ?? (c2.transitions = [])).push(h2), Ap) {
    var u2 = o2;
    if (!u2) {
      for (var d2 = c2.parent; d2 && 0 !== (d2.f & Gu); ) for (; (d2 = d2.parent) && !(16 & d2.f); ) ;
      u2 = !d2 || 0 !== (d2.f & Yu);
    }
    u2 && ef(() => {
      op(() => h2.in());
    });
  }
}
function Tm(t2, e2, i2, s2, n2) {
  if (Iu(e2)) {
    var r2, o2 = false;
    return Sf(() => {
      if (!o2) {
        var a3 = e2({ direction: "in" });
        r2 = Tm(t2, a3, i2, s2, n2);
      }
    }), { abort: () => {
      o2 = true, r2 == null ? void 0 : r2.abort();
    }, deactivate: () => r2.deactivate(), reset: () => r2.reset(), t: () => r2.t() };
  }
  if (!(e2 == null ? void 0 : e2.duration)) return n2(), { abort: Nu, deactivate: Nu, reset: Nu, t: () => s2 };
  const { delay: a2 = 0, css: l2, tick: h2, easing: c2 = Rm } = e2;
  var u2 = [];
  if (h2 && h2(0, 1), l2) {
    var d2 = Dm(l2(0, 1));
    u2.push(d2, d2);
  }
  var f2 = () => 1 - s2, p2 = t2.animate(u2, { duration: a2, fill: "forwards" });
  return p2.onfinish = () => {
    p2.cancel();
    var i3 = 1 - s2, r3 = s2 - i3, o3 = e2.duration * Math.abs(r3), a3 = [];
    if (o3 > 0) {
      var u3 = false;
      if (l2) for (var d3 = Math.ceil(o3 / (1e3 / 60)), m2 = 0; m2 <= d3; m2 += 1) {
        var g2 = i3 + r3 * c2(m2 / d3), v2 = Dm(l2(g2, 1 - g2));
        a3.push(v2), u3 || (u3 = "hidden" === v2.overflow);
      }
      u3 && (t2.style.overflow = "hidden"), f2 = () => {
        var t3 = p2.currentTime;
        return i3 + r3 * c2(t3 / o3);
      }, h2 && function(t3) {
        let e3;
        0 === Sm.tasks.size && Sm.tick(Mm), new Promise((i4) => {
          Sm.tasks.add(e3 = { c: t3, f: i4 });
        });
      }(() => {
        if ("running" !== p2.playState) return false;
        var t3 = f2();
        return h2(t3, 1 - t3), true;
      });
    }
    (p2 = t2.animate(a3, { duration: o3, fill: "forwards" })).onfinish = () => {
      f2 = () => s2, h2 == null ? void 0 : h2(s2, 1 - s2), n2();
    };
  }, { abort: () => {
    p2 && (p2.cancel(), p2.effect = null, p2.onfinish = Nu);
  }, deactivate: () => {
    n2 = Nu;
  }, reset: () => {
  }, t: () => f2() };
}
function $m(t2, e2, i2 = e2) {
  var s2 = cd();
  !function(t3, e3, i3, s3 = i3) {
    t3.addEventListener(e3, () => pp(i3));
    const n2 = t3.__on_r;
    t3.__on_r = n2 ? () => {
      n2(), s3(true);
    } : () => s3(true), fp();
  }(t2, "input", (n2) => {
    var r2 = n2 ? t2.defaultValue : t2.value;
    if (r2 = Em(t2) ? Am(r2) : r2, i2(r2), s2 && r2 !== (r2 = e2())) {
      var o2 = t2.selectionStart, a2 = t2.selectionEnd;
      t2.value = r2 ?? "", null !== a2 && (t2.selectionStart = o2, t2.selectionEnd = Math.min(a2, t2.value.length));
    }
  }), (Td && t2.defaultValue !== t2.value || null == op(e2) && t2.value) && i2(Em(t2) ? Am(t2.value) : t2.value), rf(() => {
    var i3 = e2();
    Em(t2) && i3 === Am(t2.value) || ("date" !== t2.type || i3 || t2.value) && i3 !== t2.value && (t2.value = i3 ?? "");
  });
}
function Em(t2) {
  var e2 = t2.type;
  return "number" === e2 || "range" === e2;
}
function Am(t2) {
  return "" === t2 ? null : +t2;
}
function Lm(t2, e2) {
  return t2 === e2 || (t2 == null ? void 0 : t2[Ju]) === e2;
}
function Vm(t2 = {}, e2, i2, s2) {
  return ef(() => {
    var s3, n2;
    return rf(() => {
      s3 = n2, n2 = [], op(() => {
        t2 !== i2(...n2) && (e2(t2, ...n2), s3 && Lm(i2(...s3), t2) && e2(null, ...s3));
      });
    }), () => {
      Sf(() => {
        n2 && Lm(i2(...n2), t2) && e2(null, ...n2);
      });
    };
  }), t2;
}
function Om(t2 = false) {
  const e2 = od, i2 = e2.l.u;
  if (!i2) return;
  let s2 = () => hp(e2.s);
  if (t2) {
    let t3 = 0, i3 = {};
    const n2 = md(() => {
      let s3 = false;
      const n3 = e2.s;
      for (const t4 in n3) n3[t4] !== i3[t4] && (i3[t4] = n3[t4], s3 = true);
      return s3 && t3++, t3;
    });
    s2 = () => rp(n2);
  }
  i2.b.length && (Jd(), rf(() => {
    Im(e2, s2), Wu(i2.b);
  })), tf(() => {
    const t3 = op(() => i2.m.map(Fu));
    return () => {
      for (const e3 of t3) "function" == typeof e3 && e3();
    };
  }), i2.a.length && tf(() => {
    Im(e2, s2), Wu(i2.a);
  });
}
function Im(t2, e2) {
  if (t2.l.s) for (const e3 of t2.l.s) rp(e3);
  e2();
}
function Nm(t2, e2, i2) {
  if (null == t2) return e2(void 0), Nu;
  const s2 = op(() => t2.subscribe(e2, i2));
  return s2.unsubscribe ? () => s2.unsubscribe() : s2;
}
const Fm = [];
function Wm(t2, e2 = Nu) {
  let i2 = null;
  const s2 = /* @__PURE__ */ new Set();
  function n2(e3) {
    if (ed(t2, e3) && (t2 = e3, i2)) {
      const e4 = !Fm.length;
      for (const e5 of s2) e5[1](), Fm.push(e5, t2);
      if (e4) {
        for (let t3 = 0; t3 < Fm.length; t3 += 2) Fm[t3][0](Fm[t3 + 1]);
        Fm.length = 0;
      }
    }
  }
  function r2(e3) {
    n2(e3(t2));
  }
  return { set: n2, update: r2, subscribe: function(o2, a2 = Nu) {
    const l2 = [o2, a2];
    return s2.add(l2), 1 === s2.size && (i2 = e2(n2, r2) || Nu), o2(t2), () => {
      s2.delete(l2), 0 === s2.size && i2 && (i2(), i2 = null);
    };
  } };
}
let Bm = false, jm = Symbol();
function qm(t2, e2, i2) {
  const s2 = i2[e2] ?? (i2[e2] = { store: null, source: Sd(void 0), unsubscribe: Nu });
  if (s2.store !== t2 && !(jm in i2)) if (s2.unsubscribe(), s2.store = t2 ?? null, null == t2) s2.source.v = void 0, s2.unsubscribe = Nu;
  else {
    var n2 = true;
    s2.unsubscribe = Nm(t2, (t3) => {
      n2 ? s2.source.v = t3 : zd(s2.source, t3);
    }), n2 = false;
  }
  return t2 && jm in i2 ? function(t3) {
    let e3;
    return Nm(t3, (t4) => e3 = t4)(), e3;
  }(t2) : rp(s2.source);
}
function Hm() {
  const t2 = {};
  return [t2, function() {
    Zd(() => {
      for (var e2 in t2) t2[e2].unsubscribe();
      Tu(t2, jm, { enumerable: false, value: true });
    });
  }];
}
const Um = { get(t2, e2) {
  if (!t2.exclude.includes(e2)) return rp(t2.version), e2 in t2.special ? t2.special[e2]() : t2.props[e2];
}, set: (t2, e2, i2) => (e2 in t2.special || (t2.special[e2] = Jm({ get [e2]() {
  return t2.props[e2];
} }, e2, 4)), t2.special[e2](i2), Dd(t2.version), true), getOwnPropertyDescriptor(t2, e2) {
  if (!t2.exclude.includes(e2)) return e2 in t2.props ? { enumerable: true, configurable: true, value: t2.props[e2] } : void 0;
}, deleteProperty: (t2, e2) => (t2.exclude.includes(e2) || (t2.exclude.push(e2), Dd(t2.version)), true), has: (t2, e2) => !t2.exclude.includes(e2) && e2 in t2.props, ownKeys: (t2) => Reflect.ownKeys(t2.props).filter((e2) => !t2.exclude.includes(e2)) };
function Km(t2, e2) {
  return new Proxy({ props: t2, exclude: e2, special: {}, version: xd(0) }, Um);
}
const Ym = { get(t2, e2) {
  let i2 = t2.props.length;
  for (; i2--; ) {
    let s2 = t2.props[i2];
    if (Iu(s2) && (s2 = s2()), "object" == typeof s2 && null !== s2 && e2 in s2) return s2[e2];
  }
}, set(t2, e2, i2) {
  let s2 = t2.props.length;
  for (; s2--; ) {
    let n2 = t2.props[s2];
    Iu(n2) && (n2 = n2());
    const r2 = $u(n2, e2);
    if (r2 && r2.set) return r2.set(i2), true;
  }
  return false;
}, getOwnPropertyDescriptor(t2, e2) {
  let i2 = t2.props.length;
  for (; i2--; ) {
    let s2 = t2.props[i2];
    if (Iu(s2) && (s2 = s2()), "object" == typeof s2 && null !== s2 && e2 in s2) {
      const t3 = $u(s2, e2);
      return t3 && !t3.configurable && (t3.configurable = true), t3;
    }
  }
}, has(t2, e2) {
  if (e2 === Ju || e2 === Qu) return false;
  for (let i2 of t2.props) if (Iu(i2) && (i2 = i2()), null != i2 && e2 in i2) return true;
  return false;
}, ownKeys(t2) {
  const e2 = [];
  for (let i2 of t2.props) if (Iu(i2) && (i2 = i2()), i2) {
    for (const t3 in i2) e2.includes(t3) || e2.push(t3);
    for (const t3 of Object.getOwnPropertySymbols(i2)) e2.includes(t3) || e2.push(t3);
  }
  return e2;
} };
function Gm(...t2) {
  return new Proxy({ props: t2 }, Ym);
}
function Xm(t2) {
  var _a3;
  return ((_a3 = t2.ctx) == null ? void 0 : _a3.d) ?? false;
}
function Jm(t2, e2, i2, s2) {
  var _a3;
  var n2, r2 = !!(1 & i2), o2 = !nd || !!(2 & i2), a2 = !!(8 & i2), l2 = !!(16 & i2), h2 = false;
  a2 ? [n2, h2] = function() {
    var i3 = Bm;
    try {
      return Bm = false, [t2[e2], Bm];
    } finally {
      Bm = i3;
    }
  }() : n2 = t2[e2];
  var c2, u2 = Ju in t2 || Qu in t2, d2 = a2 && (((_a3 = $u(t2, e2)) == null ? void 0 : _a3.set) ?? (u2 && e2 in t2 && ((i3) => t2[e2] = i3))) || void 0, f2 = s2, p2 = true, m2 = false, g2 = () => (m2 = true, p2 && (p2 = false, f2 = l2 ? op(s2) : s2), f2);
  if (void 0 === n2 && void 0 !== s2 && (d2 && o2 && function() {
    throw new Error("https://svelte.dev/e/props_invalid_value");
  }(), n2 = g2(), d2 && d2(n2)), o2) c2 = () => {
    var i3 = t2[e2];
    return void 0 === i3 ? g2() : (p2 = true, m2 = false, i3);
  };
  else {
    var v2 = (r2 ? md : vd)(() => t2[e2]);
    v2.f |= 131072, c2 = () => {
      var t3 = rp(v2);
      return void 0 !== t3 && (f2 = void 0), void 0 === t3 ? f2 : t3;
    };
  }
  if (!(4 & i2) && o2) return c2;
  if (d2) {
    var b2 = t2.$$legacy;
    return function(t3, e3) {
      return arguments.length > 0 ? (o2 && e3 && !b2 && !h2 || d2(e3 ? c2() : t3), t3) : c2();
    };
  }
  var _2 = false, y2 = Sd(n2), w2 = md(() => {
    var t3 = c2(), e3 = rp(y2);
    return _2 ? (_2 = false, e3) : y2.v = t3;
  });
  return a2 && rp(w2), r2 || (w2.equals = sd), function(t3, e3) {
    if (arguments.length > 0) {
      const i3 = e3 ? rp(w2) : o2 && a2 ? ud(t3) : t3;
      if (!w2.equals(i3)) {
        if (_2 = true, zd(y2, i3), m2 && void 0 !== f2 && (f2 = i3), Xm(w2)) return t3;
        op(() => rp(w2));
      }
      return t3;
    }
    return Xm(w2) ? w2.v : rp(w2);
  };
}
class Svelte4Component {
  constructor(t2) {
    __privateAdd(this, _t2);
    __privateAdd(this, _e3);
    var _a3;
    var e2 = /* @__PURE__ */ new Map(), i2 = (t3, i3) => {
      var s3 = Sd(i3);
      return e2.set(t3, s3), s3;
    };
    const s2 = new Proxy({ ...t2.props || {}, $$events: {} }, { get: (t3, s3) => rp(e2.get(s3) ?? i2(s3, Reflect.get(t3, s3))), has: (t3, s3) => s3 === Qu || (rp(e2.get(s3) ?? i2(s3, Reflect.get(t3, s3))), Reflect.has(t3, s3)), set: (t3, s3, n2) => (zd(e2.get(s3) ?? i2(s3, n2), n2), Reflect.set(t3, s3, n2)) });
    __privateSet(this, _e3, (t2.hydrate ? Ip : Op)(t2.component, { target: t2.target, anchor: t2.anchor, props: s2, context: t2.context, intro: t2.intro ?? false, recover: t2.recover })), ((_a3 = t2 == null ? void 0 : t2.props) == null ? void 0 : _a3.$$host) && false !== t2.sync || sp(), __privateSet(this, _t2, s2.$$events);
    for (const t3 of Object.keys(__privateGet(this, _e3))) "$set" !== t3 && "$destroy" !== t3 && "$on" !== t3 && Tu(this, t3, { get() {
      return __privateGet(this, _e3)[t3];
    }, set(e3) {
      __privateGet(this, _e3)[t3] = e3;
    }, enumerable: true });
    __privateGet(this, _e3).$set = (t3) => {
      Object.assign(s2, t3);
    }, __privateGet(this, _e3).$destroy = () => {
      !function(t3) {
        const e3 = Wp.get(t3);
        e3 ? (Wp.delete(t3), e3(void 0)) : Promise.resolve();
      }(__privateGet(this, _e3));
    };
  }
  $set(t2) {
    __privateGet(this, _e3).$set(t2);
  }
  $on(t2, e2) {
    __privateGet(this, _t2)[t2] = __privateGet(this, _t2)[t2] || [];
    const i2 = (...t3) => e2.call(this, ...t3);
    return __privateGet(this, _t2)[t2].push(i2), () => {
      __privateGet(this, _t2)[t2] = __privateGet(this, _t2)[t2].filter((t3) => t3 !== i2);
    };
  }
  $destroy() {
    __privateGet(this, _e3).$destroy();
  }
}
_t2 = new WeakMap();
_e3 = new WeakMap();
let Qm;
function Zm(t2, e2, i2, s2) {
  var _a3;
  const n2 = (_a3 = i2[t2]) == null ? void 0 : _a3.type;
  if (e2 = "Boolean" === n2 && "boolean" != typeof e2 ? null != e2 : e2, !s2 || !i2[t2]) return e2;
  if ("toAttribute" === s2) switch (n2) {
    case "Object":
    case "Array":
      return null == e2 ? null : JSON.stringify(e2);
    case "Boolean":
      return e2 ? "" : null;
    case "Number":
      return null == e2 ? null : e2;
    default:
      return e2;
  }
  else switch (n2) {
    case "Object":
    case "Array":
      return e2 && JSON.parse(e2);
    case "Boolean":
    default:
      return e2;
    case "Number":
      return null != e2 ? +e2 : e2;
  }
}
function tg(t2, e2, i2, s2, n2, r2) {
  let o2 = class extends Qm {
    constructor() {
      super(t2, i2, n2), this.$$p_d = e2;
    }
    static get observedAttributes() {
      return Pu(e2).map((t3) => (e2[t3].attribute || t3).toLowerCase());
    }
  };
  return Pu(e2).forEach((t3) => {
    Tu(o2.prototype, t3, { get() {
      return this.$$c && t3 in this.$$c ? this.$$c[t3] : this.$$d[t3];
    }, set(i3) {
      var _a3;
      i3 = Zm(t3, i3, e2), this.$$d[t3] = i3;
      var s3 = this.$$c;
      if (s3) {
        var n3 = (_a3 = $u(s3, t3)) == null ? void 0 : _a3.get;
        n3 ? s3[t3] = i3 : s3.$set({ [t3]: i3 });
      }
    } });
  }), s2.forEach((t3) => {
    Tu(o2.prototype, t3, { get() {
      var _a3;
      return (_a3 = this.$$c) == null ? void 0 : _a3[t3];
    } });
  }), t2.element = o2, o2;
}
function eg(t2) {
  return t2 + 0.5 | 0;
}
"function" == typeof HTMLElement && (Qm = class extends HTMLElement {
  constructor(t2, e2, i2) {
    super();
    __publicField(this, "$$ctor");
    __publicField(this, "$$s");
    __publicField(this, "$$c");
    __publicField(this, "$$cn", false);
    __publicField(this, "$$d", {});
    __publicField(this, "$$r", false);
    __publicField(this, "$$p_d", {});
    __publicField(this, "$$l", {});
    __publicField(this, "$$l_u", /* @__PURE__ */ new Map());
    __publicField(this, "$$me");
    this.$$ctor = t2, this.$$s = e2, i2 && this.attachShadow({ mode: "open" });
  }
  addEventListener(t2, e2, i2) {
    if (this.$$l[t2] = this.$$l[t2] || [], this.$$l[t2].push(e2), this.$$c) {
      const i3 = this.$$c.$on(t2, e2);
      this.$$l_u.set(e2, i3);
    }
    super.addEventListener(t2, e2, i2);
  }
  removeEventListener(t2, e2, i2) {
    if (super.removeEventListener(t2, e2, i2), this.$$c) {
      const t3 = this.$$l_u.get(e2);
      t3 && (t3(), this.$$l_u.delete(e2));
    }
  }
  async connectedCallback() {
    if (this.$$cn = true, !this.$$c) {
      let e2 = function(t3) {
        return (e3) => {
          const i3 = document.createElement("slot");
          "default" !== t3 && (i3.name = t3), zp(e3, i3);
        };
      };
      if (await Promise.resolve(), !this.$$cn || this.$$c) return;
      const i2 = {}, s2 = function(t3) {
        const e3 = {};
        return t3.childNodes.forEach((t4) => {
          e3[t4.slot || "default"] = true;
        }), e3;
      }(this);
      for (const n2 of this.$$s) n2 in s2 && ("default" !== n2 || this.$$d.children ? i2[n2] = e2(n2) : (this.$$d.children = e2(n2), i2.default = true));
      for (const r2 of this.attributes) {
        const o2 = this.$$g_p(r2.name);
        o2 in this.$$d || (this.$$d[o2] = Zm(o2, r2.value, this.$$p_d, "toProp"));
      }
      for (const a2 in this.$$p_d) a2 in this.$$d || void 0 === this[a2] || (this.$$d[a2] = this[a2], delete this[a2]);
      this.$$c = (t2 = { component: this.$$ctor, target: this.shadowRoot || this, props: { ...this.$$d, $$slots: i2, $$host: this } }, new Svelte4Component(t2)), this.$$me = function(t3) {
        const e3 = Qd(64, t3, true);
        return () => {
          uf(e3);
        };
      }(() => {
        rf(() => {
          var _a3;
          this.$$r = true;
          for (const t3 of Pu(this.$$c)) {
            if (!((_a3 = this.$$p_d[t3]) == null ? void 0 : _a3.reflect)) continue;
            this.$$d[t3] = this.$$c[t3];
            const e3 = Zm(t3, this.$$d[t3], this.$$p_d, "toAttribute");
            null == e3 ? this.removeAttribute(this.$$p_d[t3].attribute || t3) : this.setAttribute(this.$$p_d[t3].attribute || t3, e3);
          }
          this.$$r = false;
        });
      });
      for (const l2 in this.$$l) for (const h2 of this.$$l[l2]) {
        const c2 = this.$$c.$on(l2, h2);
        this.$$l_u.set(h2, c2);
      }
      this.$$l = {};
    }
    var t2;
  }
  attributeChangedCallback(t2, e2, i2) {
    var _a3;
    this.$$r || (t2 = this.$$g_p(t2), this.$$d[t2] = Zm(t2, i2, this.$$p_d, "toProp"), (_a3 = this.$$c) == null ? void 0 : _a3.$set({ [t2]: this.$$d[t2] }));
  }
  disconnectedCallback() {
    this.$$cn = false, Promise.resolve().then(() => {
      !this.$$cn && this.$$c && (this.$$c.$destroy(), this.$$me(), this.$$c = void 0);
    });
  }
  $$g_p(t2) {
    return Pu(this.$$p_d).find((e2) => this.$$p_d[e2].attribute === t2 || !this.$$p_d[e2].attribute && e2.toLowerCase() === t2) || t2;
  }
}), nd = true;
const ig = (t2, e2, i2) => Math.max(Math.min(t2, i2), e2);
function sg(t2) {
  return ig(eg(2.55 * t2), 0, 255);
}
function ng(t2) {
  return ig(eg(255 * t2), 0, 255);
}
function rg(t2) {
  return ig(eg(t2 / 2.55) / 100, 0, 1);
}
function og(t2) {
  return ig(eg(100 * t2), 0, 100);
}
const ag = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, A: 10, B: 11, C: 12, D: 13, E: 14, F: 15, a: 10, b: 11, c: 12, d: 13, e: 14, f: 15 }, lg = [..."0123456789ABCDEF"], hg = (t2) => lg[15 & t2], cg = (t2) => lg[(240 & t2) >> 4] + lg[15 & t2], ug = (t2) => (240 & t2) >> 4 == (15 & t2), dg = /^(hsla?|hwb|hsv)\(\s*([-+.e\d]+)(?:deg)?[\s,]+([-+.e\d]+)%[\s,]+([-+.e\d]+)%(?:[\s,]+([-+.e\d]+)(%)?)?\s*\)$/;
function fg(t2, e2, i2) {
  const s2 = e2 * Math.min(i2, 1 - i2), n2 = (e3, n3 = (e3 + t2 / 30) % 12) => i2 - s2 * Math.max(Math.min(n3 - 3, 9 - n3, 1), -1);
  return [n2(0), n2(8), n2(4)];
}
function pg(t2, e2, i2) {
  const s2 = (s3, n2 = (s3 + t2 / 60) % 6) => i2 - i2 * e2 * Math.max(Math.min(n2, 4 - n2, 1), 0);
  return [s2(5), s2(3), s2(1)];
}
function mg(t2, e2, i2) {
  const s2 = fg(t2, 1, 0.5);
  let n2;
  for (e2 + i2 > 1 && (n2 = 1 / (e2 + i2), e2 *= n2, i2 *= n2), n2 = 0; n2 < 3; n2++) s2[n2] *= 1 - e2 - i2, s2[n2] += e2;
  return s2;
}
function gg(t2) {
  const e2 = t2.r / 255, i2 = t2.g / 255, s2 = t2.b / 255, n2 = Math.max(e2, i2, s2), r2 = Math.min(e2, i2, s2), o2 = (n2 + r2) / 2;
  let a2, l2, h2;
  return n2 !== r2 && (h2 = n2 - r2, l2 = o2 > 0.5 ? h2 / (2 - n2 - r2) : h2 / (n2 + r2), a2 = function(t3, e3, i3, s3, n3) {
    return t3 === n3 ? (e3 - i3) / s3 + (e3 < i3 ? 6 : 0) : e3 === n3 ? (i3 - t3) / s3 + 2 : (t3 - e3) / s3 + 4;
  }(e2, i2, s2, h2, n2), a2 = 60 * a2 + 0.5), [0 | a2, l2 || 0, o2];
}
function vg(t2, e2, i2, s2) {
  return (Array.isArray(e2) ? t2(e2[0], e2[1], e2[2]) : t2(e2, i2, s2)).map(ng);
}
function bg(t2, e2, i2) {
  return vg(fg, t2, e2, i2);
}
function _g(t2) {
  return (t2 % 360 + 360) % 360;
}
const yg = { x: "dark", Z: "light", Y: "re", X: "blu", W: "gr", V: "medium", U: "slate", A: "ee", T: "ol", S: "or", B: "ra", C: "lateg", D: "ights", R: "in", Q: "turquois", E: "hi", P: "ro", O: "al", N: "le", M: "de", L: "yello", F: "en", K: "ch", G: "arks", H: "ea", I: "ightg", J: "wh" }, wg = { OiceXe: "f0f8ff", antiquewEte: "faebd7", aqua: "ffff", aquamarRe: "7fffd4", azuY: "f0ffff", beige: "f5f5dc", bisque: "ffe4c4", black: "0", blanKedOmond: "ffebcd", Xe: "ff", XeviTet: "8a2be2", bPwn: "a52a2a", burlywood: "deb887", caMtXe: "5f9ea0", KartYuse: "7fff00", KocTate: "d2691e", cSO: "ff7f50", cSnflowerXe: "6495ed", cSnsilk: "fff8dc", crimson: "dc143c", cyan: "ffff", xXe: "8b", xcyan: "8b8b", xgTMnPd: "b8860b", xWay: "a9a9a9", xgYF: "6400", xgYy: "a9a9a9", xkhaki: "bdb76b", xmagFta: "8b008b", xTivegYF: "556b2f", xSange: "ff8c00", xScEd: "9932cc", xYd: "8b0000", xsOmon: "e9967a", xsHgYF: "8fbc8f", xUXe: "483d8b", xUWay: "2f4f4f", xUgYy: "2f4f4f", xQe: "ced1", xviTet: "9400d3", dAppRk: "ff1493", dApskyXe: "bfff", dimWay: "696969", dimgYy: "696969", dodgerXe: "1e90ff", fiYbrick: "b22222", flSOwEte: "fffaf0", foYstWAn: "228b22", fuKsia: "ff00ff", gaRsbSo: "dcdcdc", ghostwEte: "f8f8ff", gTd: "ffd700", gTMnPd: "daa520", Way: "808080", gYF: "8000", gYFLw: "adff2f", gYy: "808080", honeyMw: "f0fff0", hotpRk: "ff69b4", RdianYd: "cd5c5c", Rdigo: "4b0082", ivSy: "fffff0", khaki: "f0e68c", lavFMr: "e6e6fa", lavFMrXsh: "fff0f5", lawngYF: "7cfc00", NmoncEffon: "fffacd", ZXe: "add8e6", ZcSO: "f08080", Zcyan: "e0ffff", ZgTMnPdLw: "fafad2", ZWay: "d3d3d3", ZgYF: "90ee90", ZgYy: "d3d3d3", ZpRk: "ffb6c1", ZsOmon: "ffa07a", ZsHgYF: "20b2aa", ZskyXe: "87cefa", ZUWay: "778899", ZUgYy: "778899", ZstAlXe: "b0c4de", ZLw: "ffffe0", lime: "ff00", limegYF: "32cd32", lRF: "faf0e6", magFta: "ff00ff", maPon: "800000", VaquamarRe: "66cdaa", VXe: "cd", VScEd: "ba55d3", VpurpN: "9370db", VsHgYF: "3cb371", VUXe: "7b68ee", VsprRggYF: "fa9a", VQe: "48d1cc", VviTetYd: "c71585", midnightXe: "191970", mRtcYam: "f5fffa", mistyPse: "ffe4e1", moccasR: "ffe4b5", navajowEte: "ffdead", navy: "80", Tdlace: "fdf5e6", Tive: "808000", TivedBb: "6b8e23", Sange: "ffa500", SangeYd: "ff4500", ScEd: "da70d6", pOegTMnPd: "eee8aa", pOegYF: "98fb98", pOeQe: "afeeee", pOeviTetYd: "db7093", papayawEp: "ffefd5", pHKpuff: "ffdab9", peru: "cd853f", pRk: "ffc0cb", plum: "dda0dd", powMrXe: "b0e0e6", purpN: "800080", YbeccapurpN: "663399", Yd: "ff0000", Psybrown: "bc8f8f", PyOXe: "4169e1", saddNbPwn: "8b4513", sOmon: "fa8072", sandybPwn: "f4a460", sHgYF: "2e8b57", sHshell: "fff5ee", siFna: "a0522d", silver: "c0c0c0", skyXe: "87ceeb", UXe: "6a5acd", UWay: "708090", UgYy: "708090", snow: "fffafa", sprRggYF: "ff7f", stAlXe: "4682b4", tan: "d2b48c", teO: "8080", tEstN: "d8bfd8", tomato: "ff6347", Qe: "40e0d0", viTet: "ee82ee", JHt: "f5deb3", wEte: "ffffff", wEtesmoke: "f5f5f5", Lw: "ffff00", LwgYF: "9acd32" };
let xg;
const kg = /^rgba?\(\s*([-+.\d]+)(%)?[\s,]+([-+.e\d]+)(%)?[\s,]+([-+.e\d]+)(%)?(?:[\s,/]+([-+.e\d]+)(%)?)?\s*\)$/, Sg = (t2) => t2 <= 31308e-7 ? 12.92 * t2 : 1.055 * Math.pow(t2, 1 / 2.4) - 0.055, Mg = (t2) => t2 <= 0.04045 ? t2 / 12.92 : Math.pow((t2 + 0.055) / 1.055, 2.4);
function zg(t2, e2, i2) {
  if (t2) {
    let s2 = gg(t2);
    s2[e2] = Math.max(0, Math.min(s2[e2] + s2[e2] * i2, 0 === e2 ? 360 : 1)), s2 = bg(s2), t2.r = s2[0], t2.g = s2[1], t2.b = s2[2];
  }
}
function Cg(t2, e2) {
  return t2 ? Object.assign(e2 || {}, t2) : t2;
}
function Dg(t2) {
  var e2 = { r: 0, g: 0, b: 0, a: 255 };
  return Array.isArray(t2) ? t2.length >= 3 && (e2 = { r: t2[0], g: t2[1], b: t2[2], a: 255 }, t2.length > 3 && (e2.a = ng(t2[3]))) : (e2 = Cg(t2, { r: 0, g: 0, b: 0, a: 1 })).a = ng(e2.a), e2;
}
class Color {
  constructor(t2) {
    if (t2 instanceof Color) return t2;
    const e2 = typeof t2;
    let i2;
    var s2, n2, r2;
    "object" === e2 ? i2 = Dg(t2) : "string" === e2 && (r2 = (s2 = t2).length, "#" === s2[0] && (4 === r2 || 5 === r2 ? n2 = { r: 255 & 17 * ag[s2[1]], g: 255 & 17 * ag[s2[2]], b: 255 & 17 * ag[s2[3]], a: 5 === r2 ? 17 * ag[s2[4]] : 255 } : 7 !== r2 && 9 !== r2 || (n2 = { r: ag[s2[1]] << 4 | ag[s2[2]], g: ag[s2[3]] << 4 | ag[s2[4]], b: ag[s2[5]] << 4 | ag[s2[6]], a: 9 === r2 ? ag[s2[7]] << 4 | ag[s2[8]] : 255 })), i2 = n2 || function(t3) {
      xg || (xg = function() {
        const t4 = {}, e4 = Object.keys(wg), i3 = Object.keys(yg);
        let s3, n3, r3, o2, a2;
        for (s3 = 0; s3 < e4.length; s3++) {
          for (o2 = a2 = e4[s3], n3 = 0; n3 < i3.length; n3++) r3 = i3[n3], a2 = a2.replace(r3, yg[r3]);
          r3 = parseInt(wg[o2], 16), t4[a2] = [r3 >> 16 & 255, r3 >> 8 & 255, 255 & r3];
        }
        return t4;
      }(), xg.transparent = [0, 0, 0, 0]);
      const e3 = xg[t3.toLowerCase()];
      return e3 && { r: e3[0], g: e3[1], b: e3[2], a: 4 === e3.length ? e3[3] : 255 };
    }(t2) || function(t3) {
      return "r" === t3.charAt(0) ? function(t4) {
        const e3 = kg.exec(t4);
        let i3, s3, n3, r3 = 255;
        if (e3) {
          if (e3[7] !== i3) {
            const t5 = +e3[7];
            r3 = e3[8] ? sg(t5) : ig(255 * t5, 0, 255);
          }
          return i3 = +e3[1], s3 = +e3[3], n3 = +e3[5], i3 = 255 & (e3[2] ? sg(i3) : ig(i3, 0, 255)), s3 = 255 & (e3[4] ? sg(s3) : ig(s3, 0, 255)), n3 = 255 & (e3[6] ? sg(n3) : ig(n3, 0, 255)), { r: i3, g: s3, b: n3, a: r3 };
        }
      }(t3) : function(t4) {
        const e3 = dg.exec(t4);
        let i3, s3 = 255;
        if (!e3) return;
        e3[5] !== i3 && (s3 = e3[6] ? sg(+e3[5]) : ng(+e3[5]));
        const n3 = _g(+e3[2]), r3 = +e3[3] / 100, o2 = +e3[4] / 100;
        return i3 = "hwb" === e3[1] ? function(t5, e4, i4) {
          return vg(mg, t5, e4, i4);
        }(n3, r3, o2) : "hsv" === e3[1] ? function(t5, e4, i4) {
          return vg(pg, t5, e4, i4);
        }(n3, r3, o2) : bg(n3, r3, o2), { r: i3[0], g: i3[1], b: i3[2], a: s3 };
      }(t3);
    }(t2)), this._rgb = i2, this._valid = !!i2;
  }
  get valid() {
    return this._valid;
  }
  get rgb() {
    var t2 = Cg(this._rgb);
    return t2 && (t2.a = rg(t2.a)), t2;
  }
  set rgb(t2) {
    this._rgb = Dg(t2);
  }
  rgbString() {
    return this._valid ? function(t2) {
      return t2 && (t2.a < 255 ? `rgba(${t2.r}, ${t2.g}, ${t2.b}, ${rg(t2.a)})` : `rgb(${t2.r}, ${t2.g}, ${t2.b})`);
    }(this._rgb) : void 0;
  }
  hexString() {
    return this._valid ? function(t2) {
      var e2 = ((t3) => ug(t3.r) && ug(t3.g) && ug(t3.b) && ug(t3.a))(t2) ? hg : cg;
      return t2 ? "#" + e2(t2.r) + e2(t2.g) + e2(t2.b) + ((t3, e3) => t3 < 255 ? e3(t3) : "")(t2.a, e2) : void 0;
    }(this._rgb) : void 0;
  }
  hslString() {
    return this._valid ? function(t2) {
      if (!t2) return;
      const e2 = gg(t2), i2 = e2[0], s2 = og(e2[1]), n2 = og(e2[2]);
      return t2.a < 255 ? `hsla(${i2}, ${s2}%, ${n2}%, ${rg(t2.a)})` : `hsl(${i2}, ${s2}%, ${n2}%)`;
    }(this._rgb) : void 0;
  }
  mix(t2, e2) {
    if (t2) {
      const i2 = this.rgb, s2 = t2.rgb;
      let n2;
      const r2 = e2 === n2 ? 0.5 : e2, o2 = 2 * r2 - 1, a2 = i2.a - s2.a, l2 = ((o2 * a2 === -1 ? o2 : (o2 + a2) / (1 + o2 * a2)) + 1) / 2;
      n2 = 1 - l2, i2.r = 255 & l2 * i2.r + n2 * s2.r + 0.5, i2.g = 255 & l2 * i2.g + n2 * s2.g + 0.5, i2.b = 255 & l2 * i2.b + n2 * s2.b + 0.5, i2.a = r2 * i2.a + (1 - r2) * s2.a, this.rgb = i2;
    }
    return this;
  }
  interpolate(t2, e2) {
    return t2 && (this._rgb = function(t3, e3, i2) {
      const s2 = Mg(rg(t3.r)), n2 = Mg(rg(t3.g)), r2 = Mg(rg(t3.b));
      return { r: ng(Sg(s2 + i2 * (Mg(rg(e3.r)) - s2))), g: ng(Sg(n2 + i2 * (Mg(rg(e3.g)) - n2))), b: ng(Sg(r2 + i2 * (Mg(rg(e3.b)) - r2))), a: t3.a + i2 * (e3.a - t3.a) };
    }(this._rgb, t2._rgb, e2)), this;
  }
  clone() {
    return new Color(this.rgb);
  }
  alpha(t2) {
    return this._rgb.a = ng(t2), this;
  }
  clearer(t2) {
    return this._rgb.a *= 1 - t2, this;
  }
  greyscale() {
    const t2 = this._rgb, e2 = eg(0.3 * t2.r + 0.59 * t2.g + 0.11 * t2.b);
    return t2.r = t2.g = t2.b = e2, this;
  }
  opaquer(t2) {
    return this._rgb.a *= 1 + t2, this;
  }
  negate() {
    const t2 = this._rgb;
    return t2.r = 255 - t2.r, t2.g = 255 - t2.g, t2.b = 255 - t2.b, this;
  }
  lighten(t2) {
    return zg(this._rgb, 2, t2), this;
  }
  darken(t2) {
    return zg(this._rgb, 2, -t2), this;
  }
  saturate(t2) {
    return zg(this._rgb, 1, t2), this;
  }
  desaturate(t2) {
    return zg(this._rgb, 1, -t2), this;
  }
  rotate(t2) {
    return function(t3, e2) {
      var i2 = gg(t3);
      i2[0] = _g(i2[0] + e2), i2 = bg(i2), t3.r = i2[0], t3.g = i2[1], t3.b = i2[2];
    }(this._rgb, t2), this;
  }
}
function Rg() {
}
const Pg = /* @__PURE__ */ (() => {
  let t2 = 0;
  return () => t2++;
})();
function Tg(t2) {
  return null == t2;
}
function $g(t2) {
  if (Array.isArray && Array.isArray(t2)) return true;
  const e2 = Object.prototype.toString.call(t2);
  return "[object" === e2.slice(0, 7) && "Array]" === e2.slice(-6);
}
function Eg(t2) {
  return null !== t2 && "[object Object]" === Object.prototype.toString.call(t2);
}
function Ag(t2) {
  return ("number" == typeof t2 || t2 instanceof Number) && isFinite(+t2);
}
function Lg(t2, e2) {
  return Ag(t2) ? t2 : e2;
}
function Vg(t2, e2) {
  return void 0 === t2 ? e2 : t2;
}
const Og = (t2, e2) => "string" == typeof t2 && t2.endsWith("%") ? parseFloat(t2) / 100 * e2 : +t2;
function Ig(t2, e2, i2) {
  if (t2 && "function" == typeof t2.call) return t2.apply(i2, e2);
}
function Ng(t2, e2, i2, s2) {
  let n2, r2, o2;
  if ($g(t2)) for (r2 = t2.length, n2 = 0; n2 < r2; n2++) e2.call(i2, t2[n2], n2);
  else if (Eg(t2)) for (o2 = Object.keys(t2), r2 = o2.length, n2 = 0; n2 < r2; n2++) e2.call(i2, t2[o2[n2]], o2[n2]);
}
function Fg(t2, e2) {
  let i2, s2, n2, r2;
  if (!t2 || !e2 || t2.length !== e2.length) return false;
  for (i2 = 0, s2 = t2.length; i2 < s2; ++i2) if (n2 = t2[i2], r2 = e2[i2], n2.datasetIndex !== r2.datasetIndex || n2.index !== r2.index) return false;
  return true;
}
function Wg(t2) {
  if ($g(t2)) return t2.map(Wg);
  if (Eg(t2)) {
    const e2 = /* @__PURE__ */ Object.create(null), i2 = Object.keys(t2), s2 = i2.length;
    let n2 = 0;
    for (; n2 < s2; ++n2) e2[i2[n2]] = Wg(t2[i2[n2]]);
    return e2;
  }
  return t2;
}
function Bg(t2) {
  return -1 === ["__proto__", "prototype", "constructor"].indexOf(t2);
}
function jg(t2, e2, i2, s2) {
  if (!Bg(t2)) return;
  const n2 = e2[t2], r2 = i2[t2];
  Eg(n2) && Eg(r2) ? qg(n2, r2, s2) : e2[t2] = Wg(r2);
}
function qg(t2, e2, i2) {
  const s2 = $g(e2) ? e2 : [e2], n2 = s2.length;
  if (!Eg(t2)) return t2;
  const r2 = (i2 = i2 || {}).merger || jg;
  let o2;
  for (let e3 = 0; e3 < n2; ++e3) {
    if (o2 = s2[e3], !Eg(o2)) continue;
    const n3 = Object.keys(o2);
    for (let e4 = 0, s3 = n3.length; e4 < s3; ++e4) r2(n3[e4], t2, o2, i2);
  }
  return t2;
}
function Hg(t2, e2) {
  return qg(t2, e2, { merger: Ug });
}
function Ug(t2, e2, i2) {
  if (!Bg(t2)) return;
  const s2 = e2[t2], n2 = i2[t2];
  Eg(s2) && Eg(n2) ? Hg(s2, n2) : Object.prototype.hasOwnProperty.call(e2, t2) || (e2[t2] = Wg(n2));
}
const Kg = { "": (t2) => t2, x: (t2) => t2.x, y: (t2) => t2.y };
function Yg(t2, e2) {
  const i2 = Kg[e2] || (Kg[e2] = function(t3) {
    const e3 = function(t4) {
      const e4 = t4.split("."), i3 = [];
      let s2 = "";
      for (const t5 of e4) s2 += t5, s2.endsWith("\\") ? s2 = s2.slice(0, -1) + "." : (i3.push(s2), s2 = "");
      return i3;
    }(t3);
    return (t4) => {
      for (const i3 of e3) {
        if ("" === i3) break;
        t4 = t4 && t4[i3];
      }
      return t4;
    };
  }(e2));
  return i2(t2);
}
function Gg(t2) {
  return t2.charAt(0).toUpperCase() + t2.slice(1);
}
const Xg = (t2) => void 0 !== t2, Jg = (t2) => "function" == typeof t2, Qg = (t2, e2) => {
  if (t2.size !== e2.size) return false;
  for (const i2 of t2) if (!e2.has(i2)) return false;
  return true;
}, Zg = Math.PI, tv = 2 * Zg, ev = tv + Zg, iv = Number.POSITIVE_INFINITY, sv = Zg / 180, nv = Zg / 2, rv = Zg / 4, ov = 2 * Zg / 3, av = Math.log10, lv = Math.sign;
function hv(t2, e2, i2) {
  return Math.abs(t2 - e2) < i2;
}
function cv(t2) {
  const e2 = Math.round(t2);
  t2 = hv(t2, e2, t2 / 1e3) ? e2 : t2;
  const i2 = Math.pow(10, Math.floor(av(t2))), s2 = t2 / i2;
  return (s2 <= 1 ? 1 : s2 <= 2 ? 2 : s2 <= 5 ? 5 : 10) * i2;
}
function uv(t2) {
  return !function(t3) {
    return "symbol" == typeof t3 || "object" == typeof t3 && null !== t3 && !(Symbol.toPrimitive in t3 || "toString" in t3 || "valueOf" in t3);
  }(t2) && !isNaN(parseFloat(t2)) && isFinite(t2);
}
function dv(t2, e2, i2) {
  let s2, n2, r2;
  for (s2 = 0, n2 = t2.length; s2 < n2; s2++) r2 = t2[s2][i2], isNaN(r2) || (e2.min = Math.min(e2.min, r2), e2.max = Math.max(e2.max, r2));
}
function fv(t2) {
  return t2 * (Zg / 180);
}
function pv(t2) {
  return t2 * (180 / Zg);
}
function mv(t2) {
  if (!Ag(t2)) return;
  let e2 = 1, i2 = 0;
  for (; Math.round(t2 * e2) / e2 !== t2; ) e2 *= 10, i2++;
  return i2;
}
function gv(t2, e2) {
  const i2 = e2.x - t2.x, s2 = e2.y - t2.y, n2 = Math.sqrt(i2 * i2 + s2 * s2);
  let r2 = Math.atan2(s2, i2);
  return r2 < -0.5 * Zg && (r2 += tv), { angle: r2, distance: n2 };
}
function vv(t2, e2) {
  return Math.sqrt(Math.pow(e2.x - t2.x, 2) + Math.pow(e2.y - t2.y, 2));
}
function bv(t2, e2) {
  return (t2 - e2 + ev) % tv - Zg;
}
function _v(t2) {
  return (t2 % tv + tv) % tv;
}
function yv(t2, e2, i2, s2) {
  const n2 = _v(t2), r2 = _v(e2), o2 = _v(i2), a2 = _v(r2 - n2), l2 = _v(o2 - n2), h2 = _v(n2 - r2), c2 = _v(n2 - o2);
  return n2 === r2 || n2 === o2 || s2 && r2 === o2 || a2 > l2 && h2 < c2;
}
function wv(t2, e2, i2) {
  return Math.max(e2, Math.min(i2, t2));
}
function xv(t2, e2, i2, s2 = 1e-6) {
  return t2 >= Math.min(e2, i2) - s2 && t2 <= Math.max(e2, i2) + s2;
}
function kv(t2, e2, i2) {
  i2 = i2 || ((i3) => t2[i3] < e2);
  let s2, n2 = t2.length - 1, r2 = 0;
  for (; n2 - r2 > 1; ) s2 = r2 + n2 >> 1, i2(s2) ? r2 = s2 : n2 = s2;
  return { lo: r2, hi: n2 };
}
const Sv = (t2, e2, i2, s2) => kv(t2, i2, s2 ? (s3) => {
  const n2 = t2[s3][e2];
  return n2 < i2 || n2 === i2 && t2[s3 + 1][e2] === i2;
} : (s3) => t2[s3][e2] < i2), Mv = (t2, e2, i2) => kv(t2, i2, (s2) => t2[s2][e2] >= i2), zv = ["push", "pop", "shift", "splice", "unshift"];
function Cv(t2, e2) {
  const i2 = t2._chartjs;
  if (!i2) return;
  const s2 = i2.listeners, n2 = s2.indexOf(e2);
  -1 !== n2 && s2.splice(n2, 1), s2.length > 0 || (zv.forEach((e3) => {
    delete t2[e3];
  }), delete t2._chartjs);
}
function Dv(t2) {
  const e2 = new Set(t2);
  return e2.size === t2.length ? t2 : Array.from(e2);
}
const Rv = "undefined" == typeof window ? function(t2) {
  return t2();
} : window.requestAnimationFrame;
function Pv(t2, e2) {
  let i2 = [], s2 = false;
  return function(...n2) {
    i2 = n2, s2 || (s2 = true, Rv.call(window, () => {
      s2 = false, t2.apply(e2, i2);
    }));
  };
}
const Tv = (t2) => "start" === t2 ? "left" : "end" === t2 ? "right" : "center", $v = (t2, e2, i2) => "start" === t2 ? e2 : "end" === t2 ? i2 : (e2 + i2) / 2;
function Ev(t2, e2, i2) {
  const s2 = e2.length;
  let n2 = 0, r2 = s2;
  if (t2._sorted) {
    const { iScale: o2, vScale: a2, _parsed: l2 } = t2, h2 = t2.dataset && t2.dataset.options ? t2.dataset.options.spanGaps : null, c2 = o2.axis, { min: u2, max: d2, minDefined: f2, maxDefined: p2 } = o2.getUserBounds();
    if (f2) {
      if (n2 = Math.min(Sv(l2, c2, u2).lo, i2 ? s2 : Sv(e2, c2, o2.getPixelForValue(u2)).lo), h2) {
        const t3 = l2.slice(0, n2 + 1).reverse().findIndex((t4) => !Tg(t4[a2.axis]));
        n2 -= Math.max(0, t3);
      }
      n2 = wv(n2, 0, s2 - 1);
    }
    if (p2) {
      let t3 = Math.max(Sv(l2, o2.axis, d2, true).hi + 1, i2 ? 0 : Sv(e2, c2, o2.getPixelForValue(d2), true).hi + 1);
      if (h2) {
        const e3 = l2.slice(t3 - 1).findIndex((t4) => !Tg(t4[a2.axis]));
        t3 += Math.max(0, e3);
      }
      r2 = wv(t3, n2, s2) - n2;
    } else r2 = s2 - n2;
  }
  return { start: n2, count: r2 };
}
function Av(t2) {
  const { xScale: e2, yScale: i2, _scaleRanges: s2 } = t2, n2 = { xmin: e2.min, xmax: e2.max, ymin: i2.min, ymax: i2.max };
  if (!s2) return t2._scaleRanges = n2, true;
  const r2 = s2.xmin !== e2.min || s2.xmax !== e2.max || s2.ymin !== i2.min || s2.ymax !== i2.max;
  return Object.assign(s2, n2), r2;
}
const Lv = (t2) => 0 === t2 || 1 === t2, Vv = (t2, e2, i2) => -Math.pow(2, 10 * (t2 -= 1)) * Math.sin((t2 - e2) * tv / i2), Ov = (t2, e2, i2) => Math.pow(2, -10 * t2) * Math.sin((t2 - e2) * tv / i2) + 1, Iv = { linear: (t2) => t2, easeInQuad: (t2) => t2 * t2, easeOutQuad: (t2) => -t2 * (t2 - 2), easeInOutQuad: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 : -0.5 * (--t2 * (t2 - 2) - 1), easeInCubic: (t2) => t2 * t2 * t2, easeOutCubic: (t2) => (t2 -= 1) * t2 * t2 + 1, easeInOutCubic: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 : 0.5 * ((t2 -= 2) * t2 * t2 + 2), easeInQuart: (t2) => t2 * t2 * t2 * t2, easeOutQuart: (t2) => -((t2 -= 1) * t2 * t2 * t2 - 1), easeInOutQuart: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 * t2 : -0.5 * ((t2 -= 2) * t2 * t2 * t2 - 2), easeInQuint: (t2) => t2 * t2 * t2 * t2 * t2, easeOutQuint: (t2) => (t2 -= 1) * t2 * t2 * t2 * t2 + 1, easeInOutQuint: (t2) => (t2 /= 0.5) < 1 ? 0.5 * t2 * t2 * t2 * t2 * t2 : 0.5 * ((t2 -= 2) * t2 * t2 * t2 * t2 + 2), easeInSine: (t2) => 1 - Math.cos(t2 * nv), easeOutSine: (t2) => Math.sin(t2 * nv), easeInOutSine: (t2) => -0.5 * (Math.cos(Zg * t2) - 1), easeInExpo: (t2) => 0 === t2 ? 0 : Math.pow(2, 10 * (t2 - 1)), easeOutExpo: (t2) => 1 === t2 ? 1 : 1 - Math.pow(2, -10 * t2), easeInOutExpo: (t2) => Lv(t2) ? t2 : t2 < 0.5 ? 0.5 * Math.pow(2, 10 * (2 * t2 - 1)) : 0.5 * (2 - Math.pow(2, -10 * (2 * t2 - 1))), easeInCirc: (t2) => t2 >= 1 ? t2 : -(Math.sqrt(1 - t2 * t2) - 1), easeOutCirc: (t2) => Math.sqrt(1 - (t2 -= 1) * t2), easeInOutCirc: (t2) => (t2 /= 0.5) < 1 ? -0.5 * (Math.sqrt(1 - t2 * t2) - 1) : 0.5 * (Math.sqrt(1 - (t2 -= 2) * t2) + 1), easeInElastic: (t2) => Lv(t2) ? t2 : Vv(t2, 0.075, 0.3), easeOutElastic: (t2) => Lv(t2) ? t2 : Ov(t2, 0.075, 0.3), easeInOutElastic(t2) {
  const e2 = 0.1125;
  return Lv(t2) ? t2 : t2 < 0.5 ? 0.5 * Vv(2 * t2, e2, 0.45) : 0.5 + 0.5 * Ov(2 * t2 - 1, e2, 0.45);
}, easeInBack(t2) {
  const e2 = 1.70158;
  return t2 * t2 * ((e2 + 1) * t2 - e2);
}, easeOutBack(t2) {
  const e2 = 1.70158;
  return (t2 -= 1) * t2 * ((e2 + 1) * t2 + e2) + 1;
}, easeInOutBack(t2) {
  let e2 = 1.70158;
  return (t2 /= 0.5) < 1 ? t2 * t2 * ((1 + (e2 *= 1.525)) * t2 - e2) * 0.5 : 0.5 * ((t2 -= 2) * t2 * ((1 + (e2 *= 1.525)) * t2 + e2) + 2);
}, easeInBounce: (t2) => 1 - Iv.easeOutBounce(1 - t2), easeOutBounce(t2) {
  const e2 = 7.5625, i2 = 2.75;
  return t2 < 1 / i2 ? e2 * t2 * t2 : t2 < 2 / i2 ? e2 * (t2 -= 1.5 / i2) * t2 + 0.75 : t2 < 2.5 / i2 ? e2 * (t2 -= 2.25 / i2) * t2 + 0.9375 : e2 * (t2 -= 2.625 / i2) * t2 + 0.984375;
}, easeInOutBounce: (t2) => t2 < 0.5 ? 0.5 * Iv.easeInBounce(2 * t2) : 0.5 * Iv.easeOutBounce(2 * t2 - 1) + 0.5 };
function Nv(t2) {
  if (t2 && "object" == typeof t2) {
    const e2 = t2.toString();
    return "[object CanvasPattern]" === e2 || "[object CanvasGradient]" === e2;
  }
  return false;
}
function Fv(t2) {
  return Nv(t2) ? t2 : new Color(t2);
}
function Wv(t2) {
  return Nv(t2) ? t2 : new Color(t2).saturate(0.5).darken(0.1).hexString();
}
const Bv = ["x", "y", "borderWidth", "radius", "tension"], jv = ["color", "borderColor", "backgroundColor"], qv = /* @__PURE__ */ new Map();
function Hv(t2, e2, i2) {
  return function(t3, e3) {
    e3 = e3 || {};
    const i3 = t3 + JSON.stringify(e3);
    let s2 = qv.get(i3);
    return s2 || (s2 = new Intl.NumberFormat(t3, e3), qv.set(i3, s2)), s2;
  }(e2, i2).format(t2);
}
const Uv = { values: (t2) => $g(t2) ? t2 : "" + t2, numeric(t2, e2, i2) {
  if (0 === t2) return "0";
  const s2 = this.chart.options.locale;
  let n2, r2 = t2;
  if (i2.length > 1) {
    const e3 = Math.max(Math.abs(i2[0].value), Math.abs(i2[i2.length - 1].value));
    (e3 < 1e-4 || e3 > 1e15) && (n2 = "scientific"), r2 = function(t3, e4) {
      let i3 = e4.length > 3 ? e4[2].value - e4[1].value : e4[1].value - e4[0].value;
      return Math.abs(i3) >= 1 && t3 !== Math.floor(t3) && (i3 = t3 - Math.floor(t3)), i3;
    }(t2, i2);
  }
  const o2 = av(Math.abs(r2)), a2 = isNaN(o2) ? 1 : Math.max(Math.min(-1 * Math.floor(o2), 20), 0), l2 = { notation: n2, minimumFractionDigits: a2, maximumFractionDigits: a2 };
  return Object.assign(l2, this.options.ticks.format), Hv(t2, s2, l2);
}, logarithmic(t2, e2, i2) {
  if (0 === t2) return "0";
  const s2 = i2[e2].significand || t2 / Math.pow(10, Math.floor(av(t2)));
  return [1, 2, 3, 5, 10, 15].includes(s2) || e2 > 0.8 * i2.length ? Uv.numeric.call(this, t2, e2, i2) : "";
} };
var Kv = { formatters: Uv };
const Yv = /* @__PURE__ */ Object.create(null), Gv = /* @__PURE__ */ Object.create(null);
function Xv(t2, e2) {
  if (!e2) return t2;
  const i2 = e2.split(".");
  for (let e3 = 0, s2 = i2.length; e3 < s2; ++e3) {
    const s3 = i2[e3];
    t2 = t2[s3] || (t2[s3] = /* @__PURE__ */ Object.create(null));
  }
  return t2;
}
function Jv(t2, e2, i2) {
  return "string" == typeof e2 ? qg(Xv(t2, e2), i2) : qg(Xv(t2, ""), e2);
}
class Defaults {
  constructor(t2, e2) {
    this.animation = void 0, this.backgroundColor = "rgba(0,0,0,0.1)", this.borderColor = "rgba(0,0,0,0.1)", this.color = "#666", this.datasets = {}, this.devicePixelRatio = (t3) => t3.chart.platform.getDevicePixelRatio(), this.elements = {}, this.events = ["mousemove", "mouseout", "click", "touchstart", "touchmove"], this.font = { family: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif", size: 12, style: "normal", lineHeight: 1.2, weight: null }, this.hover = {}, this.hoverBackgroundColor = (t3, e3) => Wv(e3.backgroundColor), this.hoverBorderColor = (t3, e3) => Wv(e3.borderColor), this.hoverColor = (t3, e3) => Wv(e3.color), this.indexAxis = "x", this.interaction = { mode: "nearest", intersect: true, includeInvisible: false }, this.maintainAspectRatio = true, this.onHover = null, this.onClick = null, this.parsing = true, this.plugins = {}, this.responsive = true, this.scale = void 0, this.scales = {}, this.showLine = true, this.drawActiveElementsOnTop = true, this.describe(t2), this.apply(e2);
  }
  set(t2, e2) {
    return Jv(this, t2, e2);
  }
  get(t2) {
    return Xv(this, t2);
  }
  describe(t2, e2) {
    return Jv(Gv, t2, e2);
  }
  override(t2, e2) {
    return Jv(Yv, t2, e2);
  }
  route(t2, e2, i2, s2) {
    const n2 = Xv(this, t2), r2 = Xv(this, i2), o2 = "_" + e2;
    Object.defineProperties(n2, { [o2]: { value: n2[e2], writable: true }, [e2]: { enumerable: true, get() {
      const t3 = this[o2], e3 = r2[s2];
      return Eg(t3) ? Object.assign({}, e3, t3) : Vg(t3, e3);
    }, set(t3) {
      this[o2] = t3;
    } } });
  }
  apply(t2) {
    t2.forEach((t3) => t3(this));
  }
}
var Qv = new Defaults({ _scriptable: (t2) => !t2.startsWith("on"), _indexable: (t2) => "events" !== t2, hover: { _fallback: "interaction" }, interaction: { _scriptable: false, _indexable: false } }, [function(t2) {
  t2.set("animation", { delay: void 0, duration: 1e3, easing: "easeOutQuart", fn: void 0, from: void 0, loop: void 0, to: void 0, type: void 0 }), t2.describe("animation", { _fallback: false, _indexable: false, _scriptable: (t3) => "onProgress" !== t3 && "onComplete" !== t3 && "fn" !== t3 }), t2.set("animations", { colors: { type: "color", properties: jv }, numbers: { type: "number", properties: Bv } }), t2.describe("animations", { _fallback: "animation" }), t2.set("transitions", { active: { animation: { duration: 400 } }, resize: { animation: { duration: 0 } }, show: { animations: { colors: { from: "transparent" }, visible: { type: "boolean", duration: 0 } } }, hide: { animations: { colors: { to: "transparent" }, visible: { type: "boolean", easing: "linear", fn: (t3) => 0 | t3 } } } });
}, function(t2) {
  t2.set("layout", { autoPadding: true, padding: { top: 0, right: 0, bottom: 0, left: 0 } });
}, function(t2) {
  t2.set("scale", { display: true, offset: false, reverse: false, beginAtZero: false, bounds: "ticks", clip: true, grace: 0, grid: { display: true, lineWidth: 1, drawOnChartArea: true, drawTicks: true, tickLength: 8, tickWidth: (t3, e2) => e2.lineWidth, tickColor: (t3, e2) => e2.color, offset: false }, border: { display: true, dash: [], dashOffset: 0, width: 1 }, title: { display: false, text: "", padding: { top: 4, bottom: 4 } }, ticks: { minRotation: 0, maxRotation: 50, mirror: false, textStrokeWidth: 0, textStrokeColor: "", padding: 3, display: true, autoSkip: true, autoSkipPadding: 3, labelOffset: 0, callback: Kv.formatters.values, minor: {}, major: {}, align: "center", crossAlign: "near", showLabelBackdrop: false, backdropColor: "rgba(255, 255, 255, 0.75)", backdropPadding: 2 } }), t2.route("scale.ticks", "color", "", "color"), t2.route("scale.grid", "color", "", "borderColor"), t2.route("scale.border", "color", "", "borderColor"), t2.route("scale.title", "color", "", "color"), t2.describe("scale", { _fallback: false, _scriptable: (t3) => !t3.startsWith("before") && !t3.startsWith("after") && "callback" !== t3 && "parser" !== t3, _indexable: (t3) => "borderDash" !== t3 && "tickBorderDash" !== t3 && "dash" !== t3 }), t2.describe("scales", { _fallback: "scale" }), t2.describe("scale.ticks", { _scriptable: (t3) => "backdropPadding" !== t3 && "callback" !== t3, _indexable: (t3) => "backdropPadding" !== t3 });
}]);
function Zv(t2, e2, i2, s2, n2) {
  let r2 = e2[n2];
  return r2 || (r2 = e2[n2] = t2.measureText(n2).width, i2.push(n2)), r2 > s2 && (s2 = r2), s2;
}
function tb(t2, e2, i2, s2) {
  let n2 = (s2 = s2 || {}).data = s2.data || {}, r2 = s2.garbageCollect = s2.garbageCollect || [];
  s2.font !== e2 && (n2 = s2.data = {}, r2 = s2.garbageCollect = [], s2.font = e2), t2.save(), t2.font = e2;
  let o2 = 0;
  const a2 = i2.length;
  let l2, h2, c2, u2, d2;
  for (l2 = 0; l2 < a2; l2++) if (u2 = i2[l2], null == u2 || $g(u2)) {
    if ($g(u2)) for (h2 = 0, c2 = u2.length; h2 < c2; h2++) d2 = u2[h2], null == d2 || $g(d2) || (o2 = Zv(t2, n2, r2, o2, d2));
  } else o2 = Zv(t2, n2, r2, o2, u2);
  t2.restore();
  const f2 = r2.length / 2;
  if (f2 > i2.length) {
    for (l2 = 0; l2 < f2; l2++) delete n2[r2[l2]];
    r2.splice(0, f2);
  }
  return o2;
}
function eb(t2, e2, i2) {
  const s2 = t2.currentDevicePixelRatio, n2 = 0 !== i2 ? Math.max(i2 / 2, 0.5) : 0;
  return Math.round((e2 - n2) * s2) / s2 + n2;
}
function ib(t2, e2) {
  (e2 || t2) && ((e2 = e2 || t2.getContext("2d")).save(), e2.resetTransform(), e2.clearRect(0, 0, t2.width, t2.height), e2.restore());
}
function sb(t2, e2, i2, s2) {
  nb(t2, e2, i2, s2, null);
}
function nb(t2, e2, i2, s2, n2) {
  let r2, o2, a2, l2, h2, c2, u2, d2;
  const f2 = e2.pointStyle, p2 = e2.rotation, m2 = e2.radius;
  let g2 = (p2 || 0) * sv;
  if (f2 && "object" == typeof f2 && (r2 = f2.toString(), "[object HTMLImageElement]" === r2 || "[object HTMLCanvasElement]" === r2)) return t2.save(), t2.translate(i2, s2), t2.rotate(g2), t2.drawImage(f2, -f2.width / 2, -f2.height / 2, f2.width, f2.height), void t2.restore();
  if (!(isNaN(m2) || m2 <= 0)) {
    switch (t2.beginPath(), f2) {
      default:
        n2 ? t2.ellipse(i2, s2, n2 / 2, m2, 0, 0, tv) : t2.arc(i2, s2, m2, 0, tv), t2.closePath();
        break;
      case "triangle":
        c2 = n2 ? n2 / 2 : m2, t2.moveTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), g2 += ov, t2.lineTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), g2 += ov, t2.lineTo(i2 + Math.sin(g2) * c2, s2 - Math.cos(g2) * m2), t2.closePath();
        break;
      case "rectRounded":
        h2 = 0.516 * m2, l2 = m2 - h2, o2 = Math.cos(g2 + rv) * l2, u2 = Math.cos(g2 + rv) * (n2 ? n2 / 2 - h2 : l2), a2 = Math.sin(g2 + rv) * l2, d2 = Math.sin(g2 + rv) * (n2 ? n2 / 2 - h2 : l2), t2.arc(i2 - u2, s2 - a2, h2, g2 - Zg, g2 - nv), t2.arc(i2 + d2, s2 - o2, h2, g2 - nv, g2), t2.arc(i2 + u2, s2 + a2, h2, g2, g2 + nv), t2.arc(i2 - d2, s2 + o2, h2, g2 + nv, g2 + Zg), t2.closePath();
        break;
      case "rect":
        if (!p2) {
          l2 = Math.SQRT1_2 * m2, c2 = n2 ? n2 / 2 : l2, t2.rect(i2 - c2, s2 - l2, 2 * c2, 2 * l2);
          break;
        }
        g2 += rv;
      case "rectRot":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + d2, s2 - o2), t2.lineTo(i2 + u2, s2 + a2), t2.lineTo(i2 - d2, s2 + o2), t2.closePath();
        break;
      case "crossRot":
        g2 += rv;
      case "cross":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2);
        break;
      case "star":
        u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2), g2 += rv, u2 = Math.cos(g2) * (n2 ? n2 / 2 : m2), o2 = Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, d2 = Math.sin(g2) * (n2 ? n2 / 2 : m2), t2.moveTo(i2 - u2, s2 - a2), t2.lineTo(i2 + u2, s2 + a2), t2.moveTo(i2 + d2, s2 - o2), t2.lineTo(i2 - d2, s2 + o2);
        break;
      case "line":
        o2 = n2 ? n2 / 2 : Math.cos(g2) * m2, a2 = Math.sin(g2) * m2, t2.moveTo(i2 - o2, s2 - a2), t2.lineTo(i2 + o2, s2 + a2);
        break;
      case "dash":
        t2.moveTo(i2, s2), t2.lineTo(i2 + Math.cos(g2) * (n2 ? n2 / 2 : m2), s2 + Math.sin(g2) * m2);
        break;
      case false:
        t2.closePath();
    }
    t2.fill(), e2.borderWidth > 0 && t2.stroke();
  }
}
function rb(t2, e2, i2) {
  return i2 = i2 || 0.5, !e2 || t2 && t2.x > e2.left - i2 && t2.x < e2.right + i2 && t2.y > e2.top - i2 && t2.y < e2.bottom + i2;
}
function ob(t2, e2) {
  t2.save(), t2.beginPath(), t2.rect(e2.left, e2.top, e2.right - e2.left, e2.bottom - e2.top), t2.clip();
}
function ab(t2) {
  t2.restore();
}
function lb(t2, e2, i2, s2, n2) {
  if (!e2) return t2.lineTo(i2.x, i2.y);
  if ("middle" === n2) {
    const s3 = (e2.x + i2.x) / 2;
    t2.lineTo(s3, e2.y), t2.lineTo(s3, i2.y);
  } else "after" === n2 != !!s2 ? t2.lineTo(e2.x, i2.y) : t2.lineTo(i2.x, e2.y);
  t2.lineTo(i2.x, i2.y);
}
function hb(t2, e2, i2, s2) {
  if (!e2) return t2.lineTo(i2.x, i2.y);
  t2.bezierCurveTo(s2 ? e2.cp1x : e2.cp2x, s2 ? e2.cp1y : e2.cp2y, s2 ? i2.cp2x : i2.cp1x, s2 ? i2.cp2y : i2.cp1y, i2.x, i2.y);
}
function cb(t2, e2, i2, s2, n2) {
  if (n2.strikethrough || n2.underline) {
    const r2 = t2.measureText(s2), o2 = e2 - r2.actualBoundingBoxLeft, a2 = e2 + r2.actualBoundingBoxRight, l2 = i2 - r2.actualBoundingBoxAscent, h2 = i2 + r2.actualBoundingBoxDescent, c2 = n2.strikethrough ? (l2 + h2) / 2 : h2;
    t2.strokeStyle = t2.fillStyle, t2.beginPath(), t2.lineWidth = n2.decorationWidth || 2, t2.moveTo(o2, c2), t2.lineTo(a2, c2), t2.stroke();
  }
}
function ub(t2, e2) {
  const i2 = t2.fillStyle;
  t2.fillStyle = e2.color, t2.fillRect(e2.left, e2.top, e2.width, e2.height), t2.fillStyle = i2;
}
function db(t2, e2, i2, s2, n2, r2 = {}) {
  const o2 = $g(e2) ? e2 : [e2], a2 = r2.strokeWidth > 0 && "" !== r2.strokeColor;
  let l2, h2;
  for (t2.save(), t2.font = n2.string, function(t3, e3) {
    e3.translation && t3.translate(e3.translation[0], e3.translation[1]), Tg(e3.rotation) || t3.rotate(e3.rotation), e3.color && (t3.fillStyle = e3.color), e3.textAlign && (t3.textAlign = e3.textAlign), e3.textBaseline && (t3.textBaseline = e3.textBaseline);
  }(t2, r2), l2 = 0; l2 < o2.length; ++l2) h2 = o2[l2], r2.backdrop && ub(t2, r2.backdrop), a2 && (r2.strokeColor && (t2.strokeStyle = r2.strokeColor), Tg(r2.strokeWidth) || (t2.lineWidth = r2.strokeWidth), t2.strokeText(h2, i2, s2, r2.maxWidth)), t2.fillText(h2, i2, s2, r2.maxWidth), cb(t2, i2, s2, h2, r2), s2 += Number(n2.lineHeight);
  t2.restore();
}
function fb(t2, e2) {
  const { x: i2, y: s2, w: n2, h: r2, radius: o2 } = e2;
  t2.arc(i2 + o2.topLeft, s2 + o2.topLeft, o2.topLeft, 1.5 * Zg, Zg, true), t2.lineTo(i2, s2 + r2 - o2.bottomLeft), t2.arc(i2 + o2.bottomLeft, s2 + r2 - o2.bottomLeft, o2.bottomLeft, Zg, nv, true), t2.lineTo(i2 + n2 - o2.bottomRight, s2 + r2), t2.arc(i2 + n2 - o2.bottomRight, s2 + r2 - o2.bottomRight, o2.bottomRight, nv, 0, true), t2.lineTo(i2 + n2, s2 + o2.topRight), t2.arc(i2 + n2 - o2.topRight, s2 + o2.topRight, o2.topRight, 0, -nv, true), t2.lineTo(i2 + o2.topLeft, s2);
}
const pb = /^(normal|(\d+(?:\.\d+)?)(px|em|%)?)$/, mb = /^(normal|italic|initial|inherit|unset|(oblique( -?[0-9]?[0-9]deg)?))$/;
function gb(t2, e2) {
  const i2 = ("" + t2).match(pb);
  if (!i2 || "normal" === i2[1]) return 1.2 * e2;
  switch (t2 = +i2[2], i2[3]) {
    case "px":
      return t2;
    case "%":
      t2 /= 100;
  }
  return e2 * t2;
}
const vb = (t2) => +t2 || 0;
function bb(t2, e2) {
  const i2 = {}, s2 = Eg(e2), n2 = s2 ? Object.keys(e2) : e2, r2 = Eg(t2) ? s2 ? (i3) => Vg(t2[i3], t2[e2[i3]]) : (e3) => t2[e3] : () => t2;
  for (const t3 of n2) i2[t3] = vb(r2(t3));
  return i2;
}
function _b(t2) {
  return bb(t2, { top: "y", right: "x", bottom: "y", left: "x" });
}
function yb(t2) {
  return bb(t2, ["topLeft", "topRight", "bottomLeft", "bottomRight"]);
}
function wb(t2) {
  const e2 = _b(t2);
  return e2.width = e2.left + e2.right, e2.height = e2.top + e2.bottom, e2;
}
function xb(t2, e2) {
  t2 = t2 || {}, e2 = e2 || Qv.font;
  let i2 = Vg(t2.size, e2.size);
  "string" == typeof i2 && (i2 = parseInt(i2, 10));
  let s2 = Vg(t2.style, e2.style);
  s2 && !("" + s2).match(mb) && (s2 = void 0);
  const n2 = { family: Vg(t2.family, e2.family), lineHeight: gb(Vg(t2.lineHeight, e2.lineHeight), i2), size: i2, style: s2, weight: Vg(t2.weight, e2.weight), string: "" };
  return n2.string = function(t3) {
    return !t3 || Tg(t3.size) || Tg(t3.family) ? null : (t3.style ? t3.style + " " : "") + (t3.weight ? t3.weight + " " : "") + t3.size + "px " + t3.family;
  }(n2), n2;
}
function kb(t2, e2, i2, s2) {
  let n2, r2, o2;
  for (n2 = 0, r2 = t2.length; n2 < r2; ++n2) if (o2 = t2[n2], void 0 !== o2 && void 0 !== o2) return o2;
}
function Sb(t2, e2) {
  return Object.assign(Object.create(t2), e2);
}
function Mb(t2, e2 = [""], i2, s2, n2 = () => t2[0]) {
  const r2 = i2 || t2;
  void 0 === s2 && (s2 = Vb("_fallback", t2));
  const o2 = { [Symbol.toStringTag]: "Object", _cacheable: true, _scopes: t2, _rootScopes: r2, _fallback: s2, _getTarget: n2, override: (i3) => Mb([i3, ...t2], e2, r2, s2) };
  return new Proxy(o2, { deleteProperty: (e3, i3) => (delete e3[i3], delete e3._keys, delete t2[0][i3], true), get: (i3, s3) => Pb(i3, s3, () => function(t3, e3, i4, s4) {
    let n3;
    for (const r3 of e3) if (n3 = Vb(Db(r3, t3), i4), void 0 !== n3) return Rb(t3, n3) ? Ab(i4, s4, t3, n3) : n3;
  }(s3, e2, t2, i3)), getOwnPropertyDescriptor: (t3, e3) => Reflect.getOwnPropertyDescriptor(t3._scopes[0], e3), getPrototypeOf: () => Reflect.getPrototypeOf(t2[0]), has: (t3, e3) => Ob(t3).includes(e3), ownKeys: (t3) => Ob(t3), set(t3, e3, i3) {
    const s3 = t3._storage || (t3._storage = n2());
    return t3[e3] = s3[e3] = i3, delete t3._keys, true;
  } });
}
function zb(t2, e2, i2, s2) {
  const n2 = { _cacheable: false, _proxy: t2, _context: e2, _subProxy: i2, _stack: /* @__PURE__ */ new Set(), _descriptors: Cb(t2, s2), setContext: (e3) => zb(t2, e3, i2, s2), override: (n3) => zb(t2.override(n3), e2, i2, s2) };
  return new Proxy(n2, { deleteProperty: (e3, i3) => (delete e3[i3], delete t2[i3], true), get: (t3, e3, i3) => Pb(t3, e3, () => function(t4, e4, i4) {
    const { _proxy: s3, _context: n3, _subProxy: r2, _descriptors: o2 } = t4;
    let a2 = s3[e4];
    return Jg(a2) && o2.isScriptable(e4) && (a2 = function(t5, e5, i5, s4) {
      const { _proxy: n4, _context: r3, _subProxy: o3, _stack: a3 } = i5;
      if (a3.has(t5)) throw new Error("Recursion detected: " + Array.from(a3).join("->") + "->" + t5);
      a3.add(t5);
      let l2 = e5(r3, o3 || s4);
      return a3.delete(t5), Rb(t5, l2) && (l2 = Ab(n4._scopes, n4, t5, l2)), l2;
    }(e4, a2, t4, i4)), $g(a2) && a2.length && (a2 = function(t5, e5, i5, s4) {
      const { _proxy: n4, _context: r3, _subProxy: o3, _descriptors: a3 } = i5;
      if (void 0 !== r3.index && s4(t5)) return e5[r3.index % e5.length];
      if (Eg(e5[0])) {
        const i6 = e5, s5 = n4._scopes.filter((t6) => t6 !== i6);
        e5 = [];
        for (const l2 of i6) {
          const i7 = Ab(s5, n4, t5, l2);
          e5.push(zb(i7, r3, o3 && o3[t5], a3));
        }
      }
      return e5;
    }(e4, a2, t4, o2.isIndexable)), Rb(e4, a2) && (a2 = zb(a2, n3, r2 && r2[e4], o2)), a2;
  }(t3, e3, i3)), getOwnPropertyDescriptor: (e3, i3) => e3._descriptors.allKeys ? Reflect.has(t2, i3) ? { enumerable: true, configurable: true } : void 0 : Reflect.getOwnPropertyDescriptor(t2, i3), getPrototypeOf: () => Reflect.getPrototypeOf(t2), has: (e3, i3) => Reflect.has(t2, i3), ownKeys: () => Reflect.ownKeys(t2), set: (e3, i3, s3) => (t2[i3] = s3, delete e3[i3], true) });
}
function Cb(t2, e2 = { scriptable: true, indexable: true }) {
  const { _scriptable: i2 = e2.scriptable, _indexable: s2 = e2.indexable, _allKeys: n2 = e2.allKeys } = t2;
  return { allKeys: n2, scriptable: i2, indexable: s2, isScriptable: Jg(i2) ? i2 : () => i2, isIndexable: Jg(s2) ? s2 : () => s2 };
}
const Db = (t2, e2) => t2 ? t2 + Gg(e2) : e2, Rb = (t2, e2) => Eg(e2) && "adapters" !== t2 && (null === Object.getPrototypeOf(e2) || e2.constructor === Object);
function Pb(t2, e2, i2) {
  if (Object.prototype.hasOwnProperty.call(t2, e2) || "constructor" === e2) return t2[e2];
  const s2 = i2();
  return t2[e2] = s2, s2;
}
function Tb(t2, e2, i2) {
  return Jg(t2) ? t2(e2, i2) : t2;
}
const $b = (t2, e2) => true === t2 ? e2 : "string" == typeof t2 ? Yg(e2, t2) : void 0;
function Eb(t2, e2, i2, s2, n2) {
  for (const r2 of e2) {
    const e3 = $b(i2, r2);
    if (e3) {
      t2.add(e3);
      const r3 = Tb(e3._fallback, i2, n2);
      if (void 0 !== r3 && r3 !== i2 && r3 !== s2) return r3;
    } else if (false === e3 && void 0 !== s2 && i2 !== s2) return null;
  }
  return false;
}
function Ab(t2, e2, i2, s2) {
  const n2 = e2._rootScopes, r2 = Tb(e2._fallback, i2, s2), o2 = [...t2, ...n2], a2 = /* @__PURE__ */ new Set();
  a2.add(s2);
  let l2 = Lb(a2, o2, i2, r2 || i2, s2);
  return null !== l2 && (void 0 === r2 || r2 === i2 || (l2 = Lb(a2, o2, r2, l2, s2), null !== l2)) && Mb(Array.from(a2), [""], n2, r2, () => function(t3, e3, i3) {
    const s3 = t3._getTarget();
    e3 in s3 || (s3[e3] = {});
    const n3 = s3[e3];
    return $g(n3) && Eg(i3) ? i3 : n3 || {};
  }(e2, i2, s2));
}
function Lb(t2, e2, i2, s2, n2) {
  for (; i2; ) i2 = Eb(t2, e2, i2, s2, n2);
  return i2;
}
function Vb(t2, e2) {
  for (const i2 of e2) {
    if (!i2) continue;
    const e3 = i2[t2];
    if (void 0 !== e3) return e3;
  }
}
function Ob(t2) {
  let e2 = t2._keys;
  return e2 || (e2 = t2._keys = function(t3) {
    const e3 = /* @__PURE__ */ new Set();
    for (const i2 of t3) for (const t4 of Object.keys(i2).filter((t5) => !t5.startsWith("_"))) e3.add(t4);
    return Array.from(e3);
  }(t2._scopes)), e2;
}
function Ib(t2, e2, i2, s2) {
  const { iScale: n2 } = t2, { key: r2 = "r" } = this._parsing, o2 = new Array(s2);
  let a2, l2, h2, c2;
  for (a2 = 0, l2 = s2; a2 < l2; ++a2) h2 = a2 + i2, c2 = e2[h2], o2[a2] = { r: n2.parse(Yg(c2, r2), h2) };
  return o2;
}
const Nb = Number.EPSILON || 1e-14, Fb = (t2, e2) => e2 < t2.length && !t2[e2].skip && t2[e2], Wb = (t2) => "x" === t2 ? "y" : "x";
function Bb(t2, e2, i2, s2) {
  const n2 = t2.skip ? e2 : t2, r2 = e2, o2 = i2.skip ? e2 : i2, a2 = vv(r2, n2), l2 = vv(o2, r2);
  let h2 = a2 / (a2 + l2), c2 = l2 / (a2 + l2);
  h2 = isNaN(h2) ? 0 : h2, c2 = isNaN(c2) ? 0 : c2;
  const u2 = s2 * h2, d2 = s2 * c2;
  return { previous: { x: r2.x - u2 * (o2.x - n2.x), y: r2.y - u2 * (o2.y - n2.y) }, next: { x: r2.x + d2 * (o2.x - n2.x), y: r2.y + d2 * (o2.y - n2.y) } };
}
function jb(t2, e2, i2) {
  return Math.max(Math.min(t2, i2), e2);
}
function qb() {
  return "undefined" != typeof window && "undefined" != typeof document;
}
function Hb(t2) {
  let e2 = t2.parentNode;
  return e2 && "[object ShadowRoot]" === e2.toString() && (e2 = e2.host), e2;
}
function Ub(t2, e2, i2) {
  let s2;
  return "string" == typeof t2 ? (s2 = parseInt(t2, 10), -1 !== t2.indexOf("%") && (s2 = s2 / 100 * e2.parentNode[i2])) : s2 = t2, s2;
}
const Kb = (t2) => t2.ownerDocument.defaultView.getComputedStyle(t2, null), Yb = ["top", "right", "bottom", "left"];
function Gb(t2, e2, i2) {
  const s2 = {};
  i2 = i2 ? "-" + i2 : "";
  for (let n2 = 0; n2 < 4; n2++) {
    const r2 = Yb[n2];
    s2[r2] = parseFloat(t2[e2 + "-" + r2 + i2]) || 0;
  }
  return s2.width = s2.left + s2.right, s2.height = s2.top + s2.bottom, s2;
}
function Xb(t2, e2) {
  if ("native" in t2) return t2;
  const { canvas: i2, currentDevicePixelRatio: s2 } = e2, n2 = Kb(i2), r2 = "border-box" === n2.boxSizing, o2 = Gb(n2, "padding"), a2 = Gb(n2, "border", "width"), { x: l2, y: h2, box: c2 } = function(t3, e3) {
    const i3 = t3.touches, s3 = i3 && i3.length ? i3[0] : t3, { offsetX: n3, offsetY: r3 } = s3;
    let o3, a3, l3 = false;
    if (((t4, e4, i4) => (t4 > 0 || e4 > 0) && (!i4 || !i4.shadowRoot))(n3, r3, t3.target)) o3 = n3, a3 = r3;
    else {
      const t4 = e3.getBoundingClientRect();
      o3 = s3.clientX - t4.left, a3 = s3.clientY - t4.top, l3 = true;
    }
    return { x: o3, y: a3, box: l3 };
  }(t2, i2), u2 = o2.left + (c2 && a2.left), d2 = o2.top + (c2 && a2.top);
  let { width: f2, height: p2 } = e2;
  return r2 && (f2 -= o2.width + a2.width, p2 -= o2.height + a2.height), { x: Math.round((l2 - u2) / f2 * i2.width / s2), y: Math.round((h2 - d2) / p2 * i2.height / s2) };
}
const Jb = (t2) => Math.round(10 * t2) / 10;
function Qb(t2, e2, i2) {
  const s2 = e2 || 1, n2 = Math.floor(t2.height * s2), r2 = Math.floor(t2.width * s2);
  t2.height = Math.floor(t2.height), t2.width = Math.floor(t2.width);
  const o2 = t2.canvas;
  return o2.style && (i2 || !o2.style.height && !o2.style.width) && (o2.style.height = `${t2.height}px`, o2.style.width = `${t2.width}px`), (t2.currentDevicePixelRatio !== s2 || o2.height !== n2 || o2.width !== r2) && (t2.currentDevicePixelRatio = s2, o2.height = n2, o2.width = r2, t2.ctx.setTransform(s2, 0, 0, s2, 0, 0), true);
}
const Zb = function() {
  let t2 = false;
  try {
    const e2 = { get passive() {
      return t2 = true, false;
    } };
    qb() && (window.addEventListener("test", null, e2), window.removeEventListener("test", null, e2));
  } catch (t3) {
  }
  return t2;
}();
function t_(t2, e2) {
  const i2 = function(t3, e3) {
    return Kb(t3).getPropertyValue(e3);
  }(t2, e2), s2 = i2 && i2.match(/^(\d+)(\.\d+)?px$/);
  return s2 ? +s2[1] : void 0;
}
function e_(t2, e2, i2, s2) {
  return { x: t2.x + i2 * (e2.x - t2.x), y: t2.y + i2 * (e2.y - t2.y) };
}
function i_(t2, e2, i2, s2) {
  return { x: t2.x + i2 * (e2.x - t2.x), y: "middle" === s2 ? i2 < 0.5 ? t2.y : e2.y : "after" === s2 ? i2 < 1 ? t2.y : e2.y : i2 > 0 ? e2.y : t2.y };
}
function s_(t2, e2, i2, s2) {
  const n2 = { x: t2.cp2x, y: t2.cp2y }, r2 = { x: e2.cp1x, y: e2.cp1y }, o2 = e_(t2, n2, i2), a2 = e_(n2, r2, i2), l2 = e_(r2, e2, i2), h2 = e_(o2, a2, i2), c2 = e_(a2, l2, i2);
  return e_(h2, c2, i2);
}
function n_(t2, e2, i2) {
  return t2 ? /* @__PURE__ */ function(t3, e3) {
    return { x: (i3) => t3 + t3 + e3 - i3, setWidth(t4) {
      e3 = t4;
    }, textAlign: (t4) => "center" === t4 ? t4 : "right" === t4 ? "left" : "right", xPlus: (t4, e4) => t4 - e4, leftForLtr: (t4, e4) => t4 - e4 };
  }(e2, i2) : { x: (t3) => t3, setWidth(t3) {
  }, textAlign: (t3) => t3, xPlus: (t3, e3) => t3 + e3, leftForLtr: (t3, e3) => t3 };
}
function r_(t2, e2) {
  let i2, s2;
  "ltr" !== e2 && "rtl" !== e2 || (i2 = t2.canvas.style, s2 = [i2.getPropertyValue("direction"), i2.getPropertyPriority("direction")], i2.setProperty("direction", e2, "important"), t2.prevTextDirection = s2);
}
function o_(t2, e2) {
  void 0 !== e2 && (delete t2.prevTextDirection, t2.canvas.style.setProperty("direction", e2[0], e2[1]));
}
function a_(t2) {
  return "angle" === t2 ? { between: yv, compare: bv, normalize: _v } : { between: xv, compare: (t3, e2) => t3 - e2, normalize: (t3) => t3 };
}
function l_({ start: t2, end: e2, count: i2, loop: s2, style: n2 }) {
  return { start: t2 % i2, end: e2 % i2, loop: s2 && (e2 - t2 + 1) % i2 == 0, style: n2 };
}
function h_(t2, e2, i2) {
  if (!i2) return [t2];
  const { property: s2, start: n2, end: r2 } = i2, o2 = e2.length, { compare: a2, between: l2, normalize: h2 } = a_(s2), { start: c2, end: u2, loop: d2, style: f2 } = function(t3, e3, i3) {
    const { property: s3, start: n3, end: r3 } = i3, { between: o3, normalize: a3 } = a_(s3), l3 = e3.length;
    let h3, c3, { start: u3, end: d3, loop: f3 } = t3;
    if (f3) {
      for (u3 += l3, d3 += l3, h3 = 0, c3 = l3; h3 < c3 && o3(a3(e3[u3 % l3][s3]), n3, r3); ++h3) u3--, d3--;
      u3 %= l3, d3 %= l3;
    }
    return d3 < u3 && (d3 += l3), { start: u3, end: d3, loop: f3, style: t3.style };
  }(t2, e2, i2), p2 = [];
  let m2, g2, v2, b2 = false, _2 = null;
  for (let t3 = c2, i3 = c2; t3 <= u2; ++t3) g2 = e2[t3 % o2], g2.skip || (m2 = h2(g2[s2]), m2 !== v2 && (b2 = l2(m2, n2, r2), null === _2 && (b2 || l2(n2, v2, m2) && 0 !== a2(n2, v2)) && (_2 = 0 === a2(m2, n2) ? t3 : i3), null !== _2 && (!b2 || 0 === a2(r2, m2) || l2(r2, v2, m2)) && (p2.push(l_({ start: _2, end: t3, loop: d2, count: o2, style: f2 })), _2 = null), i3 = t3, v2 = m2));
  return null !== _2 && p2.push(l_({ start: _2, end: u2, loop: d2, count: o2, style: f2 })), p2;
}
function c_(t2, e2) {
  const i2 = [], s2 = t2.segments;
  for (let n2 = 0; n2 < s2.length; n2++) {
    const r2 = h_(s2[n2], t2.points, e2);
    r2.length && i2.push(...r2);
  }
  return i2;
}
function u_(t2) {
  return { backgroundColor: t2.backgroundColor, borderCapStyle: t2.borderCapStyle, borderDash: t2.borderDash, borderDashOffset: t2.borderDashOffset, borderJoinStyle: t2.borderJoinStyle, borderWidth: t2.borderWidth, borderColor: t2.borderColor };
}
function d_(t2, e2) {
  if (!e2) return false;
  const i2 = [], s2 = function(t3, e3) {
    return Nv(e3) ? (i2.includes(e3) || i2.push(e3), i2.indexOf(e3)) : e3;
  };
  return JSON.stringify(t2, s2) !== JSON.stringify(e2, s2);
}
function f_(t2, e2, i2) {
  return t2.options.clip ? t2[i2] : e2[i2];
}
function p_(t2, e2) {
  const i2 = e2._clip;
  if (i2.disabled) return false;
  const s2 = function(t3, e3) {
    const { xScale: i3, yScale: s3 } = t3;
    return i3 && s3 ? { left: f_(i3, e3, "left"), right: f_(i3, e3, "right"), top: f_(s3, e3, "top"), bottom: f_(s3, e3, "bottom") } : e3;
  }(e2, t2.chartArea);
  return { left: false === i2.left ? 0 : s2.left - (true === i2.left ? 0 : i2.left), right: false === i2.right ? t2.width : s2.right + (true === i2.right ? 0 : i2.right), top: false === i2.top ? 0 : s2.top - (true === i2.top ? 0 : i2.top), bottom: false === i2.bottom ? t2.height : s2.bottom + (true === i2.bottom ? 0 : i2.bottom) };
}
class Animator {
  constructor() {
    this._request = null, this._charts = /* @__PURE__ */ new Map(), this._running = false, this._lastDate = void 0;
  }
  _notify(t2, e2, i2, s2) {
    const n2 = e2.listeners[s2], r2 = e2.duration;
    n2.forEach((s3) => s3({ chart: t2, initial: e2.initial, numSteps: r2, currentStep: Math.min(i2 - e2.start, r2) }));
  }
  _refresh() {
    this._request || (this._running = true, this._request = Rv.call(window, () => {
      this._update(), this._request = null, this._running && this._refresh();
    }));
  }
  _update(t2 = Date.now()) {
    let e2 = 0;
    this._charts.forEach((i2, s2) => {
      if (!i2.running || !i2.items.length) return;
      const n2 = i2.items;
      let r2, o2 = n2.length - 1, a2 = false;
      for (; o2 >= 0; --o2) r2 = n2[o2], r2._active ? (r2._total > i2.duration && (i2.duration = r2._total), r2.tick(t2), a2 = true) : (n2[o2] = n2[n2.length - 1], n2.pop());
      a2 && (s2.draw(), this._notify(s2, i2, t2, "progress")), n2.length || (i2.running = false, this._notify(s2, i2, t2, "complete"), i2.initial = false), e2 += n2.length;
    }), this._lastDate = t2, 0 === e2 && (this._running = false);
  }
  _getAnims(t2) {
    const e2 = this._charts;
    let i2 = e2.get(t2);
    return i2 || (i2 = { running: false, initial: true, items: [], listeners: { complete: [], progress: [] } }, e2.set(t2, i2)), i2;
  }
  listen(t2, e2, i2) {
    this._getAnims(t2).listeners[e2].push(i2);
  }
  add(t2, e2) {
    e2 && e2.length && this._getAnims(t2).items.push(...e2);
  }
  has(t2) {
    return this._getAnims(t2).items.length > 0;
  }
  start(t2) {
    const e2 = this._charts.get(t2);
    e2 && (e2.running = true, e2.start = Date.now(), e2.duration = e2.items.reduce((t3, e3) => Math.max(t3, e3._duration), 0), this._refresh());
  }
  running(t2) {
    if (!this._running) return false;
    const e2 = this._charts.get(t2);
    return !!(e2 && e2.running && e2.items.length);
  }
  stop(t2) {
    const e2 = this._charts.get(t2);
    if (!e2 || !e2.items.length) return;
    const i2 = e2.items;
    let s2 = i2.length - 1;
    for (; s2 >= 0; --s2) i2[s2].cancel();
    e2.items = [], this._notify(t2, e2, Date.now(), "complete");
  }
  remove(t2) {
    return this._charts.delete(t2);
  }
}
var m_ = new Animator();
const g_ = "transparent", v_ = { boolean: (t2, e2, i2) => i2 > 0.5 ? e2 : t2, color(t2, e2, i2) {
  const s2 = Fv(t2 || g_), n2 = s2.valid && Fv(e2 || g_);
  return n2 && n2.valid ? n2.mix(s2, i2).hexString() : e2;
}, number: (t2, e2, i2) => t2 + (e2 - t2) * i2 };
class Animation {
  constructor(t2, e2, i2, s2) {
    const n2 = e2[i2];
    s2 = kb([t2.to, s2, n2, t2.from]);
    const r2 = kb([t2.from, n2, s2]);
    this._active = true, this._fn = t2.fn || v_[t2.type || typeof r2], this._easing = Iv[t2.easing] || Iv.linear, this._start = Math.floor(Date.now() + (t2.delay || 0)), this._duration = this._total = Math.floor(t2.duration), this._loop = !!t2.loop, this._target = e2, this._prop = i2, this._from = r2, this._to = s2, this._promises = void 0;
  }
  active() {
    return this._active;
  }
  update(t2, e2, i2) {
    if (this._active) {
      this._notify(false);
      const s2 = this._target[this._prop], n2 = i2 - this._start, r2 = this._duration - n2;
      this._start = i2, this._duration = Math.floor(Math.max(r2, t2.duration)), this._total += n2, this._loop = !!t2.loop, this._to = kb([t2.to, e2, s2, t2.from]), this._from = kb([t2.from, s2, e2]);
    }
  }
  cancel() {
    this._active && (this.tick(Date.now()), this._active = false, this._notify(false));
  }
  tick(t2) {
    const e2 = t2 - this._start, i2 = this._duration, s2 = this._prop, n2 = this._from, r2 = this._loop, o2 = this._to;
    let a2;
    if (this._active = n2 !== o2 && (r2 || e2 < i2), !this._active) return this._target[s2] = o2, void this._notify(true);
    e2 < 0 ? this._target[s2] = n2 : (a2 = e2 / i2 % 2, a2 = r2 && a2 > 1 ? 2 - a2 : a2, a2 = this._easing(Math.min(1, Math.max(0, a2))), this._target[s2] = this._fn(n2, o2, a2));
  }
  wait() {
    const t2 = this._promises || (this._promises = []);
    return new Promise((e2, i2) => {
      t2.push({ res: e2, rej: i2 });
    });
  }
  _notify(t2) {
    const e2 = t2 ? "res" : "rej", i2 = this._promises || [];
    for (let t3 = 0; t3 < i2.length; t3++) i2[t3][e2]();
  }
}
class Animations {
  constructor(t2, e2) {
    this._chart = t2, this._properties = /* @__PURE__ */ new Map(), this.configure(e2);
  }
  configure(t2) {
    if (!Eg(t2)) return;
    const e2 = Object.keys(Qv.animation), i2 = this._properties;
    Object.getOwnPropertyNames(t2).forEach((s2) => {
      const n2 = t2[s2];
      if (!Eg(n2)) return;
      const r2 = {};
      for (const t3 of e2) r2[t3] = n2[t3];
      ($g(n2.properties) && n2.properties || [s2]).forEach((t3) => {
        t3 !== s2 && i2.has(t3) || i2.set(t3, r2);
      });
    });
  }
  _animateOptions(t2, e2) {
    const i2 = e2.options, s2 = function(t3, e3) {
      if (!e3) return;
      let i3 = t3.options;
      if (i3) return i3.$shared && (t3.options = i3 = Object.assign({}, i3, { $shared: false, $animations: {} })), i3;
      t3.options = e3;
    }(t2, i2);
    if (!s2) return [];
    const n2 = this._createAnimations(s2, i2);
    return i2.$shared && function(t3, e3) {
      const i3 = [], s3 = Object.keys(e3);
      for (let e4 = 0; e4 < s3.length; e4++) {
        const n3 = t3[s3[e4]];
        n3 && n3.active() && i3.push(n3.wait());
      }
      return Promise.all(i3);
    }(t2.options.$animations, i2).then(() => {
      t2.options = i2;
    }, () => {
    }), n2;
  }
  _createAnimations(t2, e2) {
    const i2 = this._properties, s2 = [], n2 = t2.$animations || (t2.$animations = {}), r2 = Object.keys(e2), o2 = Date.now();
    let a2;
    for (a2 = r2.length - 1; a2 >= 0; --a2) {
      const l2 = r2[a2];
      if ("$" === l2.charAt(0)) continue;
      if ("options" === l2) {
        s2.push(...this._animateOptions(t2, e2));
        continue;
      }
      const h2 = e2[l2];
      let c2 = n2[l2];
      const u2 = i2.get(l2);
      if (c2) {
        if (u2 && c2.active()) {
          c2.update(u2, h2, o2);
          continue;
        }
        c2.cancel();
      }
      u2 && u2.duration ? (n2[l2] = c2 = new Animation(u2, t2, l2, h2), s2.push(c2)) : t2[l2] = h2;
    }
    return s2;
  }
  update(t2, e2) {
    if (0 === this._properties.size) return void Object.assign(t2, e2);
    const i2 = this._createAnimations(t2, e2);
    return i2.length ? (m_.add(this._chart, i2), true) : void 0;
  }
}
function b_(t2, e2) {
  const i2 = t2 && t2.options || {}, s2 = i2.reverse, n2 = void 0 === i2.min ? e2 : 0, r2 = void 0 === i2.max ? e2 : 0;
  return { start: s2 ? r2 : n2, end: s2 ? n2 : r2 };
}
function __(t2, e2) {
  const i2 = [], s2 = t2._getSortedDatasetMetas(e2);
  let n2, r2;
  for (n2 = 0, r2 = s2.length; n2 < r2; ++n2) i2.push(s2[n2].index);
  return i2;
}
function y_(t2, e2, i2, s2 = {}) {
  const n2 = t2.keys, r2 = "single" === s2.mode;
  let o2, a2, l2, h2;
  if (null === e2) return;
  let c2 = false;
  for (o2 = 0, a2 = n2.length; o2 < a2; ++o2) {
    if (l2 = +n2[o2], l2 === i2) {
      if (c2 = true, s2.all) continue;
      break;
    }
    h2 = t2.values[l2], Ag(h2) && (r2 || 0 === e2 || lv(e2) === lv(h2)) && (e2 += h2);
  }
  return c2 || s2.all ? e2 : 0;
}
function w_(t2, e2) {
  const i2 = t2 && t2.options.stacked;
  return i2 || void 0 === i2 && void 0 !== e2.stack;
}
function x_(t2, e2, i2) {
  const s2 = t2[e2] || (t2[e2] = {});
  return s2[i2] || (s2[i2] = {});
}
function k_(t2, e2, i2, s2) {
  for (const n2 of e2.getMatchingVisibleMetas(s2).reverse()) {
    const e3 = t2[n2.index];
    if (i2 && e3 > 0 || !i2 && e3 < 0) return n2.index;
  }
  return null;
}
function S_(t2, e2) {
  const { chart: i2, _cachedMeta: s2 } = t2, n2 = i2._stacks || (i2._stacks = {}), { iScale: r2, vScale: o2, index: a2 } = s2, l2 = r2.axis, h2 = o2.axis, c2 = function(t3, e3, i3) {
    return `${t3.id}.${e3.id}.${i3.stack || i3.type}`;
  }(r2, o2, s2), u2 = e2.length;
  let d2;
  for (let t3 = 0; t3 < u2; ++t3) {
    const i3 = e2[t3], { [l2]: r3, [h2]: u3 } = i3;
    d2 = (i3._stacks || (i3._stacks = {}))[h2] = x_(n2, c2, r3), d2[a2] = u3, d2._top = k_(d2, o2, true, s2.type), d2._bottom = k_(d2, o2, false, s2.type), (d2._visualValues || (d2._visualValues = {}))[a2] = u3;
  }
}
function M_(t2, e2) {
  const i2 = t2.scales;
  return Object.keys(i2).filter((t3) => i2[t3].axis === e2).shift();
}
function z_(t2, e2) {
  const i2 = t2.controller.index, s2 = t2.vScale && t2.vScale.axis;
  if (s2) {
    e2 = e2 || t2._parsed;
    for (const t3 of e2) {
      const e3 = t3._stacks;
      if (!e3 || void 0 === e3[s2] || void 0 === e3[s2][i2]) return;
      delete e3[s2][i2], void 0 !== e3[s2]._visualValues && void 0 !== e3[s2]._visualValues[i2] && delete e3[s2]._visualValues[i2];
    }
  }
}
const C_ = (t2) => "reset" === t2 || "none" === t2, D_ = (t2, e2) => e2 ? t2 : Object.assign({}, t2);
class DatasetController {
  constructor(t2, e2) {
    this.chart = t2, this._ctx = t2.ctx, this.index = e2, this._cachedDataOpts = {}, this._cachedMeta = this.getMeta(), this._type = this._cachedMeta.type, this.options = void 0, this._parsing = false, this._data = void 0, this._objectData = void 0, this._sharedOptions = void 0, this._drawStart = void 0, this._drawCount = void 0, this.enableOptionSharing = false, this.supportsDecimation = false, this.$context = void 0, this._syncList = [], this.datasetElementType = new.target.datasetElementType, this.dataElementType = new.target.dataElementType, this.initialize();
  }
  initialize() {
    const t2 = this._cachedMeta;
    this.configure(), this.linkScales(), t2._stacked = w_(t2.vScale, t2), this.addElements(), this.options.fill && this.chart.isPluginEnabled("filler");
  }
  updateIndex(t2) {
    this.index !== t2 && z_(this._cachedMeta), this.index = t2;
  }
  linkScales() {
    const t2 = this.chart, e2 = this._cachedMeta, i2 = this.getDataset(), s2 = (t3, e3, i3, s3) => "x" === t3 ? e3 : "r" === t3 ? s3 : i3, n2 = e2.xAxisID = Vg(i2.xAxisID, M_(t2, "x")), r2 = e2.yAxisID = Vg(i2.yAxisID, M_(t2, "y")), o2 = e2.rAxisID = Vg(i2.rAxisID, M_(t2, "r")), a2 = e2.indexAxis, l2 = e2.iAxisID = s2(a2, n2, r2, o2), h2 = e2.vAxisID = s2(a2, r2, n2, o2);
    e2.xScale = this.getScaleForId(n2), e2.yScale = this.getScaleForId(r2), e2.rScale = this.getScaleForId(o2), e2.iScale = this.getScaleForId(l2), e2.vScale = this.getScaleForId(h2);
  }
  getDataset() {
    return this.chart.data.datasets[this.index];
  }
  getMeta() {
    return this.chart.getDatasetMeta(this.index);
  }
  getScaleForId(t2) {
    return this.chart.scales[t2];
  }
  _getOtherScale(t2) {
    const e2 = this._cachedMeta;
    return t2 === e2.iScale ? e2.vScale : e2.iScale;
  }
  reset() {
    this._update("reset");
  }
  _destroy() {
    const t2 = this._cachedMeta;
    this._data && Cv(this._data, this), t2._stacked && z_(t2);
  }
  _dataCheck() {
    const t2 = this.getDataset(), e2 = t2.data || (t2.data = []), i2 = this._data;
    if (Eg(e2)) {
      const t3 = this._cachedMeta;
      this._data = function(t4, e3) {
        const { iScale: i3, vScale: s3 } = e3, n2 = "x" === i3.axis ? "x" : "y", r2 = "x" === s3.axis ? "x" : "y", o2 = Object.keys(t4), a2 = new Array(o2.length);
        let l2, h2, c2;
        for (l2 = 0, h2 = o2.length; l2 < h2; ++l2) c2 = o2[l2], a2[l2] = { [n2]: c2, [r2]: t4[c2] };
        return a2;
      }(e2, t3);
    } else if (i2 !== e2) {
      if (i2) {
        Cv(i2, this);
        const t3 = this._cachedMeta;
        z_(t3), t3._parsed = [];
      }
      e2 && Object.isExtensible(e2) && ((s2 = e2)._chartjs ? s2._chartjs.listeners.push(this) : (Object.defineProperty(s2, "_chartjs", { configurable: true, enumerable: false, value: { listeners: [this] } }), zv.forEach((t3) => {
        const e3 = "_onData" + Gg(t3), i3 = s2[t3];
        Object.defineProperty(s2, t3, { configurable: true, enumerable: false, value(...t4) {
          const n2 = i3.apply(this, t4);
          return s2._chartjs.listeners.forEach((i4) => {
            "function" == typeof i4[e3] && i4[e3](...t4);
          }), n2;
        } });
      }))), this._syncList = [], this._data = e2;
    }
    var s2;
  }
  addElements() {
    const t2 = this._cachedMeta;
    this._dataCheck(), this.datasetElementType && (t2.dataset = new this.datasetElementType());
  }
  buildOrUpdateElements(t2) {
    const e2 = this._cachedMeta, i2 = this.getDataset();
    let s2 = false;
    this._dataCheck();
    const n2 = e2._stacked;
    e2._stacked = w_(e2.vScale, e2), e2.stack !== i2.stack && (s2 = true, z_(e2), e2.stack = i2.stack), this._resyncElements(t2), (s2 || n2 !== e2._stacked) && (S_(this, e2._parsed), e2._stacked = w_(e2.vScale, e2));
  }
  configure() {
    const t2 = this.chart.config, e2 = t2.datasetScopeKeys(this._type), i2 = t2.getOptionScopes(this.getDataset(), e2, true);
    this.options = t2.createResolver(i2, this.getContext()), this._parsing = this.options.parsing, this._cachedDataOpts = {};
  }
  parse(t2, e2) {
    const { _cachedMeta: i2, _data: s2 } = this, { iScale: n2, _stacked: r2 } = i2, o2 = n2.axis;
    let a2, l2, h2, c2 = 0 === t2 && e2 === s2.length || i2._sorted, u2 = t2 > 0 && i2._parsed[t2 - 1];
    if (false === this._parsing) i2._parsed = s2, i2._sorted = true, h2 = s2;
    else {
      h2 = $g(s2[t2]) ? this.parseArrayData(i2, s2, t2, e2) : Eg(s2[t2]) ? this.parseObjectData(i2, s2, t2, e2) : this.parsePrimitiveData(i2, s2, t2, e2);
      const n3 = () => null === l2[o2] || u2 && l2[o2] < u2[o2];
      for (a2 = 0; a2 < e2; ++a2) i2._parsed[a2 + t2] = l2 = h2[a2], c2 && (n3() && (c2 = false), u2 = l2);
      i2._sorted = c2;
    }
    r2 && S_(this, h2);
  }
  parsePrimitiveData(t2, e2, i2, s2) {
    const { iScale: n2, vScale: r2 } = t2, o2 = n2.axis, a2 = r2.axis, l2 = n2.getLabels(), h2 = n2 === r2, c2 = new Array(s2);
    let u2, d2, f2;
    for (u2 = 0, d2 = s2; u2 < d2; ++u2) f2 = u2 + i2, c2[u2] = { [o2]: h2 || n2.parse(l2[f2], f2), [a2]: r2.parse(e2[f2], f2) };
    return c2;
  }
  parseArrayData(t2, e2, i2, s2) {
    const { xScale: n2, yScale: r2 } = t2, o2 = new Array(s2);
    let a2, l2, h2, c2;
    for (a2 = 0, l2 = s2; a2 < l2; ++a2) h2 = a2 + i2, c2 = e2[h2], o2[a2] = { x: n2.parse(c2[0], h2), y: r2.parse(c2[1], h2) };
    return o2;
  }
  parseObjectData(t2, e2, i2, s2) {
    const { xScale: n2, yScale: r2 } = t2, { xAxisKey: o2 = "x", yAxisKey: a2 = "y" } = this._parsing, l2 = new Array(s2);
    let h2, c2, u2, d2;
    for (h2 = 0, c2 = s2; h2 < c2; ++h2) u2 = h2 + i2, d2 = e2[u2], l2[h2] = { x: n2.parse(Yg(d2, o2), u2), y: r2.parse(Yg(d2, a2), u2) };
    return l2;
  }
  getParsed(t2) {
    return this._cachedMeta._parsed[t2];
  }
  getDataElement(t2) {
    return this._cachedMeta.data[t2];
  }
  applyStack(t2, e2, i2) {
    const s2 = this.chart, n2 = this._cachedMeta, r2 = e2[t2.axis];
    return y_({ keys: __(s2, true), values: e2._stacks[t2.axis]._visualValues }, r2, n2.index, { mode: i2 });
  }
  updateRangeFromParsed(t2, e2, i2, s2) {
    const n2 = i2[e2.axis];
    let r2 = null === n2 ? NaN : n2;
    const o2 = s2 && i2._stacks[e2.axis];
    s2 && o2 && (s2.values = o2, r2 = y_(s2, n2, this._cachedMeta.index)), t2.min = Math.min(t2.min, r2), t2.max = Math.max(t2.max, r2);
  }
  getMinMax(t2, e2) {
    const i2 = this._cachedMeta, s2 = i2._parsed, n2 = i2._sorted && t2 === i2.iScale, r2 = s2.length, o2 = this._getOtherScale(t2), a2 = ((t3, e3, i3) => t3 && !e3.hidden && e3._stacked && { keys: __(i3, true), values: null })(e2, i2, this.chart), l2 = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY }, { min: h2, max: c2 } = function(t3) {
      const { min: e3, max: i3, minDefined: s3, maxDefined: n3 } = t3.getUserBounds();
      return { min: s3 ? e3 : Number.NEGATIVE_INFINITY, max: n3 ? i3 : Number.POSITIVE_INFINITY };
    }(o2);
    let u2, d2;
    function f2() {
      d2 = s2[u2];
      const e3 = d2[o2.axis];
      return !Ag(d2[t2.axis]) || h2 > e3 || c2 < e3;
    }
    for (u2 = 0; u2 < r2 && (f2() || (this.updateRangeFromParsed(l2, t2, d2, a2), !n2)); ++u2) ;
    if (n2) {
      for (u2 = r2 - 1; u2 >= 0; --u2) if (!f2()) {
        this.updateRangeFromParsed(l2, t2, d2, a2);
        break;
      }
    }
    return l2;
  }
  getAllParsedValues(t2) {
    const e2 = this._cachedMeta._parsed, i2 = [];
    let s2, n2, r2;
    for (s2 = 0, n2 = e2.length; s2 < n2; ++s2) r2 = e2[s2][t2.axis], Ag(r2) && i2.push(r2);
    return i2;
  }
  getMaxOverflow() {
    return false;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = e2.iScale, s2 = e2.vScale, n2 = this.getParsed(t2);
    return { label: i2 ? "" + i2.getLabelForValue(n2[i2.axis]) : "", value: s2 ? "" + s2.getLabelForValue(n2[s2.axis]) : "" };
  }
  _update(t2) {
    const e2 = this._cachedMeta;
    this.update(t2 || "default"), e2._clip = function(t3) {
      let e3, i2, s2, n2;
      return Eg(t3) ? (e3 = t3.top, i2 = t3.right, s2 = t3.bottom, n2 = t3.left) : e3 = i2 = s2 = n2 = t3, { top: e3, right: i2, bottom: s2, left: n2, disabled: false === t3 };
    }(Vg(this.options.clip, function(t3, e3, i2) {
      if (false === i2) return false;
      const s2 = b_(t3, i2), n2 = b_(e3, i2);
      return { top: n2.end, right: s2.end, bottom: n2.start, left: s2.start };
    }(e2.xScale, e2.yScale, this.getMaxOverflow())));
  }
  update(t2) {
  }
  draw() {
    const t2 = this._ctx, e2 = this.chart, i2 = this._cachedMeta, s2 = i2.data || [], n2 = e2.chartArea, r2 = [], o2 = this._drawStart || 0, a2 = this._drawCount || s2.length - o2, l2 = this.options.drawActiveElementsOnTop;
    let h2;
    for (i2.dataset && i2.dataset.draw(t2, n2, o2, a2), h2 = o2; h2 < o2 + a2; ++h2) {
      const e3 = s2[h2];
      e3.hidden || (e3.active && l2 ? r2.push(e3) : e3.draw(t2, n2));
    }
    for (h2 = 0; h2 < r2.length; ++h2) r2[h2].draw(t2, n2);
  }
  getStyle(t2, e2) {
    const i2 = e2 ? "active" : "default";
    return void 0 === t2 && this._cachedMeta.dataset ? this.resolveDatasetElementOptions(i2) : this.resolveDataElementOptions(t2 || 0, i2);
  }
  getContext(t2, e2, i2) {
    const s2 = this.getDataset();
    let n2;
    if (t2 >= 0 && t2 < this._cachedMeta.data.length) {
      const e3 = this._cachedMeta.data[t2];
      n2 = e3.$context || (e3.$context = function(t3, e4, i3) {
        return Sb(t3, { active: false, dataIndex: e4, parsed: void 0, raw: void 0, element: i3, index: e4, mode: "default", type: "data" });
      }(this.getContext(), t2, e3)), n2.parsed = this.getParsed(t2), n2.raw = s2.data[t2], n2.index = n2.dataIndex = t2;
    } else n2 = this.$context || (this.$context = function(t3, e3) {
      return Sb(t3, { active: false, dataset: void 0, datasetIndex: e3, index: e3, mode: "default", type: "dataset" });
    }(this.chart.getContext(), this.index)), n2.dataset = s2, n2.index = n2.datasetIndex = this.index;
    return n2.active = !!e2, n2.mode = i2, n2;
  }
  resolveDatasetElementOptions(t2) {
    return this._resolveElementOptions(this.datasetElementType.id, t2);
  }
  resolveDataElementOptions(t2, e2) {
    return this._resolveElementOptions(this.dataElementType.id, e2, t2);
  }
  _resolveElementOptions(t2, e2 = "default", i2) {
    const s2 = "active" === e2, n2 = this._cachedDataOpts, r2 = t2 + "-" + e2, o2 = n2[r2], a2 = this.enableOptionSharing && Xg(i2);
    if (o2) return D_(o2, a2);
    const l2 = this.chart.config, h2 = l2.datasetElementScopeKeys(this._type, t2), c2 = s2 ? [`${t2}Hover`, "hover", t2, ""] : [t2, ""], u2 = l2.getOptionScopes(this.getDataset(), h2), d2 = Object.keys(Qv.elements[t2]), f2 = l2.resolveNamedOptions(u2, d2, () => this.getContext(i2, s2, e2), c2);
    return f2.$shared && (f2.$shared = a2, n2[r2] = Object.freeze(D_(f2, a2))), f2;
  }
  _resolveAnimations(t2, e2, i2) {
    const s2 = this.chart, n2 = this._cachedDataOpts, r2 = `animation-${e2}`, o2 = n2[r2];
    if (o2) return o2;
    let a2;
    if (false !== s2.options.animation) {
      const s3 = this.chart.config, n3 = s3.datasetAnimationScopeKeys(this._type, e2), r3 = s3.getOptionScopes(this.getDataset(), n3);
      a2 = s3.createResolver(r3, this.getContext(t2, i2, e2));
    }
    const l2 = new Animations(s2, a2 && a2.animations);
    return a2 && a2._cacheable && (n2[r2] = Object.freeze(l2)), l2;
  }
  getSharedOptions(t2) {
    if (t2.$shared) return this._sharedOptions || (this._sharedOptions = Object.assign({}, t2));
  }
  includeOptions(t2, e2) {
    return !e2 || C_(t2) || this.chart._animationsDisabled;
  }
  _getSharedOptions(t2, e2) {
    const i2 = this.resolveDataElementOptions(t2, e2), s2 = this._sharedOptions, n2 = this.getSharedOptions(i2), r2 = this.includeOptions(e2, n2) || n2 !== s2;
    return this.updateSharedOptions(n2, e2, i2), { sharedOptions: n2, includeOptions: r2 };
  }
  updateElement(t2, e2, i2, s2) {
    C_(s2) ? Object.assign(t2, i2) : this._resolveAnimations(e2, s2).update(t2, i2);
  }
  updateSharedOptions(t2, e2, i2) {
    t2 && !C_(e2) && this._resolveAnimations(void 0, e2).update(t2, i2);
  }
  _setStyle(t2, e2, i2, s2) {
    t2.active = s2;
    const n2 = this.getStyle(e2, s2);
    this._resolveAnimations(e2, i2, s2).update(t2, { options: !s2 && this.getSharedOptions(n2) || n2 });
  }
  removeHoverStyle(t2, e2, i2) {
    this._setStyle(t2, i2, "active", false);
  }
  setHoverStyle(t2, e2, i2) {
    this._setStyle(t2, i2, "active", true);
  }
  _removeDatasetHoverStyle() {
    const t2 = this._cachedMeta.dataset;
    t2 && this._setStyle(t2, void 0, "active", false);
  }
  _setDatasetHoverStyle() {
    const t2 = this._cachedMeta.dataset;
    t2 && this._setStyle(t2, void 0, "active", true);
  }
  _resyncElements(t2) {
    const e2 = this._data, i2 = this._cachedMeta.data;
    for (const [t3, e3, i3] of this._syncList) this[t3](e3, i3);
    this._syncList = [];
    const s2 = i2.length, n2 = e2.length, r2 = Math.min(n2, s2);
    r2 && this.parse(0, r2), n2 > s2 ? this._insertElements(s2, n2 - s2, t2) : n2 < s2 && this._removeElements(n2, s2 - n2);
  }
  _insertElements(t2, e2, i2 = true) {
    const s2 = this._cachedMeta, n2 = s2.data, r2 = t2 + e2;
    let o2;
    const a2 = (t3) => {
      for (t3.length += e2, o2 = t3.length - 1; o2 >= r2; o2--) t3[o2] = t3[o2 - e2];
    };
    for (a2(n2), o2 = t2; o2 < r2; ++o2) n2[o2] = new this.dataElementType();
    this._parsing && a2(s2._parsed), this.parse(t2, e2), i2 && this.updateElements(n2, t2, e2, "reset");
  }
  updateElements(t2, e2, i2, s2) {
  }
  _removeElements(t2, e2) {
    const i2 = this._cachedMeta;
    if (this._parsing) {
      const s2 = i2._parsed.splice(t2, e2);
      i2._stacked && z_(i2, s2);
    }
    i2.data.splice(t2, e2);
  }
  _sync(t2) {
    if (this._parsing) this._syncList.push(t2);
    else {
      const [e2, i2, s2] = t2;
      this[e2](i2, s2);
    }
    this.chart._dataChanges.push([this.index, ...t2]);
  }
  _onDataPush() {
    const t2 = arguments.length;
    this._sync(["_insertElements", this.getDataset().data.length - t2, t2]);
  }
  _onDataPop() {
    this._sync(["_removeElements", this._cachedMeta.data.length - 1, 1]);
  }
  _onDataShift() {
    this._sync(["_removeElements", 0, 1]);
  }
  _onDataSplice(t2, e2) {
    e2 && this._sync(["_removeElements", t2, e2]);
    const i2 = arguments.length - 2;
    i2 && this._sync(["_insertElements", t2, i2]);
  }
  _onDataUnshift() {
    this._sync(["_insertElements", 0, arguments.length]);
  }
}
__publicField(DatasetController, "defaults", {});
__publicField(DatasetController, "datasetElementType", null);
__publicField(DatasetController, "dataElementType", null);
function R_(t2) {
  const e2 = t2.iScale, i2 = function(t3, e3) {
    if (!t3._cache.$bar) {
      const i3 = t3.getMatchingVisibleMetas(e3);
      let s3 = [];
      for (let e4 = 0, n3 = i3.length; e4 < n3; e4++) s3 = s3.concat(i3[e4].controller.getAllParsedValues(t3));
      t3._cache.$bar = Dv(s3.sort((t4, e4) => t4 - e4));
    }
    return t3._cache.$bar;
  }(e2, t2.type);
  let s2, n2, r2, o2, a2 = e2._length;
  const l2 = () => {
    32767 !== r2 && -32768 !== r2 && (Xg(o2) && (a2 = Math.min(a2, Math.abs(r2 - o2) || a2)), o2 = r2);
  };
  for (s2 = 0, n2 = i2.length; s2 < n2; ++s2) r2 = e2.getPixelForValue(i2[s2]), l2();
  for (o2 = void 0, s2 = 0, n2 = e2.ticks.length; s2 < n2; ++s2) r2 = e2.getPixelForTick(s2), l2();
  return a2;
}
function P_(t2, e2, i2, s2) {
  return $g(t2) ? function(t3, e3, i3, s3) {
    const n2 = i3.parse(t3[0], s3), r2 = i3.parse(t3[1], s3), o2 = Math.min(n2, r2), a2 = Math.max(n2, r2);
    let l2 = o2, h2 = a2;
    Math.abs(o2) > Math.abs(a2) && (l2 = a2, h2 = o2), e3[i3.axis] = h2, e3._custom = { barStart: l2, barEnd: h2, start: n2, end: r2, min: o2, max: a2 };
  }(t2, e2, i2, s2) : e2[i2.axis] = i2.parse(t2, s2), e2;
}
function T_(t2, e2, i2, s2) {
  const n2 = t2.iScale, r2 = t2.vScale, o2 = n2.getLabels(), a2 = n2 === r2, l2 = [];
  let h2, c2, u2, d2;
  for (h2 = i2, c2 = i2 + s2; h2 < c2; ++h2) d2 = e2[h2], u2 = {}, u2[n2.axis] = a2 || n2.parse(o2[h2], h2), l2.push(P_(d2, u2, r2, h2));
  return l2;
}
function $_(t2) {
  return t2 && void 0 !== t2.barStart && void 0 !== t2.barEnd;
}
function E_(t2, e2, i2, s2) {
  let n2 = e2.borderSkipped;
  const r2 = {};
  if (!n2) return void (t2.borderSkipped = r2);
  if (true === n2) return void (t2.borderSkipped = { top: true, right: true, bottom: true, left: true });
  const { start: o2, end: a2, reverse: l2, top: h2, bottom: c2 } = function(t3) {
    let e3, i3, s3, n3, r3;
    return t3.horizontal ? (e3 = t3.base > t3.x, i3 = "left", s3 = "right") : (e3 = t3.base < t3.y, i3 = "bottom", s3 = "top"), e3 ? (n3 = "end", r3 = "start") : (n3 = "start", r3 = "end"), { start: i3, end: s3, reverse: e3, top: n3, bottom: r3 };
  }(t2);
  "middle" === n2 && i2 && (t2.enableBorderRadius = true, (i2._top || 0) === s2 ? n2 = h2 : (i2._bottom || 0) === s2 ? n2 = c2 : (r2[A_(c2, o2, a2, l2)] = true, n2 = h2)), r2[A_(n2, o2, a2, l2)] = true, t2.borderSkipped = r2;
}
function A_(t2, e2, i2, s2) {
  var n2, r2, o2;
  return s2 ? (o2 = i2, t2 = L_(t2 = (n2 = t2) === (r2 = e2) ? o2 : n2 === o2 ? r2 : n2, i2, e2)) : t2 = L_(t2, e2, i2), t2;
}
function L_(t2, e2, i2) {
  return "start" === t2 ? e2 : "end" === t2 ? i2 : t2;
}
function V_(t2, { inflateAmount: e2 }, i2) {
  t2.inflateAmount = "auto" === e2 ? 1 === i2 ? 0.33 : 0 : e2;
}
class BarController extends DatasetController {
  parsePrimitiveData(t2, e2, i2, s2) {
    return T_(t2, e2, i2, s2);
  }
  parseArrayData(t2, e2, i2, s2) {
    return T_(t2, e2, i2, s2);
  }
  parseObjectData(t2, e2, i2, s2) {
    const { iScale: n2, vScale: r2 } = t2, { xAxisKey: o2 = "x", yAxisKey: a2 = "y" } = this._parsing, l2 = "x" === n2.axis ? o2 : a2, h2 = "x" === r2.axis ? o2 : a2, c2 = [];
    let u2, d2, f2, p2;
    for (u2 = i2, d2 = i2 + s2; u2 < d2; ++u2) p2 = e2[u2], f2 = {}, f2[n2.axis] = n2.parse(Yg(p2, l2), u2), c2.push(P_(Yg(p2, h2), f2, r2, u2));
    return c2;
  }
  updateRangeFromParsed(t2, e2, i2, s2) {
    super.updateRangeFromParsed(t2, e2, i2, s2);
    const n2 = i2._custom;
    n2 && e2 === this._cachedMeta.vScale && (t2.min = Math.min(t2.min, n2.min), t2.max = Math.max(t2.max, n2.max));
  }
  getMaxOverflow() {
    return 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, { iScale: i2, vScale: s2 } = e2, n2 = this.getParsed(t2), r2 = n2._custom, o2 = $_(r2) ? "[" + r2.start + ", " + r2.end + "]" : "" + s2.getLabelForValue(n2[s2.axis]);
    return { label: "" + i2.getLabelForValue(n2[i2.axis]), value: o2 };
  }
  initialize() {
    this.enableOptionSharing = true, super.initialize(), this._cachedMeta.stack = this.getDataset().stack;
  }
  update(t2) {
    const e2 = this._cachedMeta;
    this.updateElements(e2.data, 0, e2.data.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { index: r2, _cachedMeta: { vScale: o2 } } = this, a2 = o2.getBasePixel(), l2 = o2.isHorizontal(), h2 = this._getRuler(), { sharedOptions: c2, includeOptions: u2 } = this._getSharedOptions(e2, s2);
    for (let d2 = e2; d2 < e2 + i2; d2++) {
      const e3 = this.getParsed(d2), i3 = n2 || Tg(e3[o2.axis]) ? { base: a2, head: a2 } : this._calculateBarValuePixels(d2), f2 = this._calculateBarIndexPixels(d2, h2), p2 = (e3._stacks || {})[o2.axis], m2 = { horizontal: l2, base: i3.base, enableBorderRadius: !p2 || $_(e3._custom) || r2 === p2._top || r2 === p2._bottom, x: l2 ? i3.head : f2.center, y: l2 ? f2.center : i3.head, height: l2 ? f2.size : Math.abs(i3.size), width: l2 ? Math.abs(i3.size) : f2.size };
      u2 && (m2.options = c2 || this.resolveDataElementOptions(d2, t2[d2].active ? "active" : s2));
      const g2 = m2.options || t2[d2].options;
      E_(m2, g2, p2, r2), V_(m2, g2, h2.ratio), this.updateElement(t2[d2], d2, m2, s2);
    }
  }
  _getStacks(t2, e2) {
    const { iScale: i2 } = this._cachedMeta, s2 = i2.getMatchingVisibleMetas(this._type).filter((t3) => t3.controller.options.grouped), n2 = i2.options.stacked, r2 = [], o2 = this._cachedMeta.controller.getParsed(e2), a2 = o2 && o2[i2.axis], l2 = (t3) => {
      const e3 = t3._parsed.find((t4) => t4[i2.axis] === a2), s3 = e3 && e3[t3.vScale.axis];
      if (Tg(s3) || isNaN(s3)) return true;
    };
    for (const i3 of s2) if ((void 0 === e2 || !l2(i3)) && ((false === n2 || -1 === r2.indexOf(i3.stack) || void 0 === n2 && void 0 === i3.stack) && r2.push(i3.stack), i3.index === t2)) break;
    return r2.length || r2.push(void 0), r2;
  }
  _getStackCount(t2) {
    return this._getStacks(void 0, t2).length;
  }
  _getStackIndex(t2, e2, i2) {
    const s2 = this._getStacks(t2, i2), n2 = void 0 !== e2 ? s2.indexOf(e2) : -1;
    return -1 === n2 ? s2.length - 1 : n2;
  }
  _getRuler() {
    const t2 = this.options, e2 = this._cachedMeta, i2 = e2.iScale, s2 = [];
    let n2, r2;
    for (n2 = 0, r2 = e2.data.length; n2 < r2; ++n2) s2.push(i2.getPixelForValue(this.getParsed(n2)[i2.axis], n2));
    const o2 = t2.barThickness;
    return { min: o2 || R_(e2), pixels: s2, start: i2._startPixel, end: i2._endPixel, stackCount: this._getStackCount(), scale: i2, grouped: t2.grouped, ratio: o2 ? 1 : t2.categoryPercentage * t2.barPercentage };
  }
  _calculateBarValuePixels(t2) {
    const { _cachedMeta: { vScale: e2, _stacked: i2, index: s2 }, options: { base: n2, minBarLength: r2 } } = this, o2 = n2 || 0, a2 = this.getParsed(t2), l2 = a2._custom, h2 = $_(l2);
    let c2, u2, d2 = a2[e2.axis], f2 = 0, p2 = i2 ? this.applyStack(e2, a2, i2) : d2;
    p2 !== d2 && (f2 = p2 - d2, p2 = d2), h2 && (d2 = l2.barStart, p2 = l2.barEnd - l2.barStart, 0 !== d2 && lv(d2) !== lv(l2.barEnd) && (f2 = 0), f2 += d2);
    const m2 = Tg(n2) || h2 ? f2 : n2;
    let g2 = e2.getPixelForValue(m2);
    if (c2 = this.chart.getDataVisibility(t2) ? e2.getPixelForValue(f2 + p2) : g2, u2 = c2 - g2, Math.abs(u2) < r2) {
      u2 = function(t4, e3, i3) {
        return 0 !== t4 ? lv(t4) : (e3.isHorizontal() ? 1 : -1) * (e3.min >= i3 ? 1 : -1);
      }(u2, e2, o2) * r2, d2 === o2 && (g2 -= u2 / 2);
      const t3 = e2.getPixelForDecimal(0), n3 = e2.getPixelForDecimal(1), l3 = Math.min(t3, n3), f3 = Math.max(t3, n3);
      g2 = Math.max(Math.min(g2, f3), l3), c2 = g2 + u2, i2 && !h2 && (a2._stacks[e2.axis]._visualValues[s2] = e2.getValueForPixel(c2) - e2.getValueForPixel(g2));
    }
    if (g2 === e2.getPixelForValue(o2)) {
      const t3 = lv(u2) * e2.getLineWidthForValue(o2) / 2;
      g2 += t3, u2 -= t3;
    }
    return { size: u2, base: g2, head: c2, center: c2 + u2 / 2 };
  }
  _calculateBarIndexPixels(t2, e2) {
    const i2 = e2.scale, s2 = this.options, n2 = s2.skipNull, r2 = Vg(s2.maxBarThickness, 1 / 0);
    let o2, a2;
    if (e2.grouped) {
      const i3 = n2 ? this._getStackCount(t2) : e2.stackCount, l2 = "flex" === s2.barThickness ? function(t3, e3, i4, s3) {
        const n3 = e3.pixels, r3 = n3[t3];
        let o3 = t3 > 0 ? n3[t3 - 1] : null, a3 = t3 < n3.length - 1 ? n3[t3 + 1] : null;
        const l3 = i4.categoryPercentage;
        null === o3 && (o3 = r3 - (null === a3 ? e3.end - e3.start : a3 - r3)), null === a3 && (a3 = r3 + r3 - o3);
        const h3 = r3 - (r3 - Math.min(o3, a3)) / 2 * l3;
        return { chunk: Math.abs(a3 - o3) / 2 * l3 / s3, ratio: i4.barPercentage, start: h3 };
      }(t2, e2, s2, i3) : function(t3, e3, i4, s3) {
        const n3 = i4.barThickness;
        let r3, o3;
        return Tg(n3) ? (r3 = e3.min * i4.categoryPercentage, o3 = i4.barPercentage) : (r3 = n3 * s3, o3 = 1), { chunk: r3 / s3, ratio: o3, start: e3.pixels[t3] - r3 / 2 };
      }(t2, e2, s2, i3), h2 = this._getStackIndex(this.index, this._cachedMeta.stack, n2 ? t2 : void 0);
      o2 = l2.start + l2.chunk * h2 + l2.chunk / 2, a2 = Math.min(r2, l2.chunk * l2.ratio);
    } else o2 = i2.getPixelForValue(this.getParsed(t2)[i2.axis], t2), a2 = Math.min(r2, e2.min * e2.ratio);
    return { base: o2 - a2 / 2, head: o2 + a2 / 2, center: o2, size: a2 };
  }
  draw() {
    const t2 = this._cachedMeta, e2 = t2.vScale, i2 = t2.data, s2 = i2.length;
    let n2 = 0;
    for (; n2 < s2; ++n2) null === this.getParsed(n2)[e2.axis] || i2[n2].hidden || i2[n2].draw(this._ctx);
  }
}
__publicField(BarController, "id", "bar");
__publicField(BarController, "defaults", { datasetElementType: false, dataElementType: "bar", categoryPercentage: 0.8, barPercentage: 0.9, grouped: true, animations: { numbers: { type: "number", properties: ["x", "y", "base", "width", "height"] } } });
__publicField(BarController, "overrides", { scales: { _index_: { type: "category", offset: true, grid: { offset: true } }, _value_: { type: "linear", beginAtZero: true } } });
class BubbleController extends DatasetController {
  initialize() {
    this.enableOptionSharing = true, super.initialize();
  }
  parsePrimitiveData(t2, e2, i2, s2) {
    const n2 = super.parsePrimitiveData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) n2[t3]._custom = this.resolveDataElementOptions(t3 + i2).radius;
    return n2;
  }
  parseArrayData(t2, e2, i2, s2) {
    const n2 = super.parseArrayData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) {
      const s3 = e2[i2 + t3];
      n2[t3]._custom = Vg(s3[2], this.resolveDataElementOptions(t3 + i2).radius);
    }
    return n2;
  }
  parseObjectData(t2, e2, i2, s2) {
    const n2 = super.parseObjectData(t2, e2, i2, s2);
    for (let t3 = 0; t3 < n2.length; t3++) {
      const s3 = e2[i2 + t3];
      n2[t3]._custom = Vg(s3 && s3.r && +s3.r, this.resolveDataElementOptions(t3 + i2).radius);
    }
    return n2;
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta.data;
    let e2 = 0;
    for (let i2 = t2.length - 1; i2 >= 0; --i2) e2 = Math.max(e2, t2[i2].size(this.resolveDataElementOptions(i2)) / 2);
    return e2 > 0 && e2;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart.data.labels || [], { xScale: s2, yScale: n2 } = e2, r2 = this.getParsed(t2), o2 = s2.getLabelForValue(r2.x), a2 = n2.getLabelForValue(r2.y), l2 = r2._custom;
    return { label: i2[t2] || "", value: "(" + o2 + ", " + a2 + (l2 ? ", " + l2 : "") + ")" };
  }
  update(t2) {
    const e2 = this._cachedMeta.data;
    this.updateElements(e2, 0, e2.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2 } = this._cachedMeta, { sharedOptions: a2, includeOptions: l2 } = this._getSharedOptions(e2, s2), h2 = r2.axis, c2 = o2.axis;
    for (let u2 = e2; u2 < e2 + i2; u2++) {
      const e3 = t2[u2], i3 = !n2 && this.getParsed(u2), d2 = {}, f2 = d2[h2] = n2 ? r2.getPixelForDecimal(0.5) : r2.getPixelForValue(i3[h2]), p2 = d2[c2] = n2 ? o2.getBasePixel() : o2.getPixelForValue(i3[c2]);
      d2.skip = isNaN(f2) || isNaN(p2), l2 && (d2.options = a2 || this.resolveDataElementOptions(u2, e3.active ? "active" : s2), n2 && (d2.options.radius = 0)), this.updateElement(e3, u2, d2, s2);
    }
  }
  resolveDataElementOptions(t2, e2) {
    const i2 = this.getParsed(t2);
    let s2 = super.resolveDataElementOptions(t2, e2);
    s2.$shared && (s2 = Object.assign({}, s2, { $shared: false }));
    const n2 = s2.radius;
    return "active" !== e2 && (s2.radius = 0), s2.radius += Vg(i2 && i2._custom, n2), s2;
  }
}
__publicField(BubbleController, "id", "bubble");
__publicField(BubbleController, "defaults", { datasetElementType: false, dataElementType: "point", animations: { numbers: { type: "number", properties: ["x", "y", "borderWidth", "radius"] } } });
__publicField(BubbleController, "overrides", { scales: { x: { type: "linear" }, y: { type: "linear" } } });
class DoughnutController extends DatasetController {
  constructor(t2, e2) {
    super(t2, e2), this.enableOptionSharing = true, this.innerRadius = void 0, this.outerRadius = void 0, this.offsetX = void 0, this.offsetY = void 0;
  }
  linkScales() {
  }
  parse(t2, e2) {
    const i2 = this.getDataset().data, s2 = this._cachedMeta;
    if (false === this._parsing) s2._parsed = i2;
    else {
      let n2, r2, o2 = (t3) => +i2[t3];
      if (Eg(i2[t2])) {
        const { key: t3 = "value" } = this._parsing;
        o2 = (e3) => +Yg(i2[e3], t3);
      }
      for (n2 = t2, r2 = t2 + e2; n2 < r2; ++n2) s2._parsed[n2] = o2(n2);
    }
  }
  _getRotation() {
    return fv(this.options.rotation - 90);
  }
  _getCircumference() {
    return fv(this.options.circumference);
  }
  _getRotationExtents() {
    let t2 = tv, e2 = -tv;
    for (let i2 = 0; i2 < this.chart.data.datasets.length; ++i2) if (this.chart.isDatasetVisible(i2) && this.chart.getDatasetMeta(i2).type === this._type) {
      const s2 = this.chart.getDatasetMeta(i2).controller, n2 = s2._getRotation(), r2 = s2._getCircumference();
      t2 = Math.min(t2, n2), e2 = Math.max(e2, n2 + r2);
    }
    return { rotation: t2, circumference: e2 - t2 };
  }
  update(t2) {
    const e2 = this.chart, { chartArea: i2 } = e2, s2 = this._cachedMeta, n2 = s2.data, r2 = this.getMaxBorderWidth() + this.getMaxOffset(n2) + this.options.spacing, o2 = Math.max((Math.min(i2.width, i2.height) - r2) / 2, 0), a2 = Math.min((h2 = o2, "string" == typeof (l2 = this.options.cutout) && l2.endsWith("%") ? parseFloat(l2) / 100 : +l2 / h2), 1);
    var l2, h2;
    const c2 = this._getRingWeight(this.index), { circumference: u2, rotation: d2 } = this._getRotationExtents(), { ratioX: f2, ratioY: p2, offsetX: m2, offsetY: g2 } = function(t3, e3, i3) {
      let s3 = 1, n3 = 1, r3 = 0, o3 = 0;
      if (e3 < tv) {
        const a3 = t3, l3 = a3 + e3, h3 = Math.cos(a3), c3 = Math.sin(a3), u3 = Math.cos(l3), d3 = Math.sin(l3), f3 = (t4, e4, s4) => yv(t4, a3, l3, true) ? 1 : Math.max(e4, e4 * i3, s4, s4 * i3), p3 = (t4, e4, s4) => yv(t4, a3, l3, true) ? -1 : Math.min(e4, e4 * i3, s4, s4 * i3), m3 = f3(0, h3, u3), g3 = f3(nv, c3, d3), v3 = p3(Zg, h3, u3), b3 = p3(Zg + nv, c3, d3);
        s3 = (m3 - v3) / 2, n3 = (g3 - b3) / 2, r3 = -(m3 + v3) / 2, o3 = -(g3 + b3) / 2;
      }
      return { ratioX: s3, ratioY: n3, offsetX: r3, offsetY: o3 };
    }(d2, u2, a2), v2 = (i2.width - r2) / f2, b2 = (i2.height - r2) / p2, _2 = Math.max(Math.min(v2, b2) / 2, 0), y2 = Og(this.options.radius, _2), w2 = (y2 - Math.max(y2 * a2, 0)) / this._getVisibleDatasetWeightTotal();
    this.offsetX = m2 * y2, this.offsetY = g2 * y2, s2.total = this.calculateTotal(), this.outerRadius = y2 - w2 * this._getRingWeightOffset(this.index), this.innerRadius = Math.max(this.outerRadius - w2 * c2, 0), this.updateElements(n2, 0, n2.length, t2);
  }
  _circumference(t2, e2) {
    const i2 = this.options, s2 = this._cachedMeta, n2 = this._getCircumference();
    return e2 && i2.animation.animateRotate || !this.chart.getDataVisibility(t2) || null === s2._parsed[t2] || s2.data[t2].hidden ? 0 : this.calculateCircumference(s2._parsed[t2] * n2 / tv);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, r2 = this.chart, o2 = r2.chartArea, a2 = r2.options.animation, l2 = (o2.left + o2.right) / 2, h2 = (o2.top + o2.bottom) / 2, c2 = n2 && a2.animateScale, u2 = c2 ? 0 : this.innerRadius, d2 = c2 ? 0 : this.outerRadius, { sharedOptions: f2, includeOptions: p2 } = this._getSharedOptions(e2, s2);
    let m2, g2 = this._getRotation();
    for (m2 = 0; m2 < e2; ++m2) g2 += this._circumference(m2, n2);
    for (m2 = e2; m2 < e2 + i2; ++m2) {
      const e3 = this._circumference(m2, n2), i3 = t2[m2], r3 = { x: l2 + this.offsetX, y: h2 + this.offsetY, startAngle: g2, endAngle: g2 + e3, circumference: e3, outerRadius: d2, innerRadius: u2 };
      p2 && (r3.options = f2 || this.resolveDataElementOptions(m2, i3.active ? "active" : s2)), g2 += e3, this.updateElement(i3, m2, r3, s2);
    }
  }
  calculateTotal() {
    const t2 = this._cachedMeta, e2 = t2.data;
    let i2, s2 = 0;
    for (i2 = 0; i2 < e2.length; i2++) {
      const n2 = t2._parsed[i2];
      null === n2 || isNaN(n2) || !this.chart.getDataVisibility(i2) || e2[i2].hidden || (s2 += Math.abs(n2));
    }
    return s2;
  }
  calculateCircumference(t2) {
    const e2 = this._cachedMeta.total;
    return e2 > 0 && !isNaN(t2) ? tv * (Math.abs(t2) / e2) : 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart, s2 = i2.data.labels || [], n2 = Hv(e2._parsed[t2], i2.options.locale);
    return { label: s2[t2] || "", value: n2 };
  }
  getMaxBorderWidth(t2) {
    let e2 = 0;
    const i2 = this.chart;
    let s2, n2, r2, o2, a2;
    if (!t2) {
      for (s2 = 0, n2 = i2.data.datasets.length; s2 < n2; ++s2) if (i2.isDatasetVisible(s2)) {
        r2 = i2.getDatasetMeta(s2), t2 = r2.data, o2 = r2.controller;
        break;
      }
    }
    if (!t2) return 0;
    for (s2 = 0, n2 = t2.length; s2 < n2; ++s2) a2 = o2.resolveDataElementOptions(s2), "inner" !== a2.borderAlign && (e2 = Math.max(e2, a2.borderWidth || 0, a2.hoverBorderWidth || 0));
    return e2;
  }
  getMaxOffset(t2) {
    let e2 = 0;
    for (let i2 = 0, s2 = t2.length; i2 < s2; ++i2) {
      const t3 = this.resolveDataElementOptions(i2);
      e2 = Math.max(e2, t3.offset || 0, t3.hoverOffset || 0);
    }
    return e2;
  }
  _getRingWeightOffset(t2) {
    let e2 = 0;
    for (let i2 = 0; i2 < t2; ++i2) this.chart.isDatasetVisible(i2) && (e2 += this._getRingWeight(i2));
    return e2;
  }
  _getRingWeight(t2) {
    return Math.max(Vg(this.chart.data.datasets[t2].weight, 1), 0);
  }
  _getVisibleDatasetWeightTotal() {
    return this._getRingWeightOffset(this.chart.data.datasets.length) || 1;
  }
}
__publicField(DoughnutController, "id", "doughnut");
__publicField(DoughnutController, "defaults", { datasetElementType: false, dataElementType: "arc", animation: { animateRotate: true, animateScale: false }, animations: { numbers: { type: "number", properties: ["circumference", "endAngle", "innerRadius", "outerRadius", "startAngle", "x", "y", "offset", "borderWidth", "spacing"] } }, cutout: "50%", rotation: 0, circumference: 360, radius: "100%", spacing: 0, indexAxis: "r" });
__publicField(DoughnutController, "descriptors", { _scriptable: (t2) => "spacing" !== t2, _indexable: (t2) => "spacing" !== t2 && !t2.startsWith("borderDash") && !t2.startsWith("hoverBorderDash") });
__publicField(DoughnutController, "overrides", { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t2) {
  const e2 = t2.data;
  if (e2.labels.length && e2.datasets.length) {
    const { labels: { pointStyle: i2, color: s2 } } = t2.legend.options;
    return e2.labels.map((e3, n2) => {
      const r2 = t2.getDatasetMeta(0).controller.getStyle(n2);
      return { text: e3, fillStyle: r2.backgroundColor, strokeStyle: r2.borderColor, fontColor: s2, lineWidth: r2.borderWidth, pointStyle: i2, hidden: !t2.getDataVisibility(n2), index: n2 };
    });
  }
  return [];
} }, onClick(t2, e2, i2) {
  i2.chart.toggleDataVisibility(e2.index), i2.chart.update();
} } } });
class LineController extends DatasetController {
  initialize() {
    this.enableOptionSharing = true, this.supportsDecimation = true, super.initialize();
  }
  update(t2) {
    const e2 = this._cachedMeta, { dataset: i2, data: s2 = [], _dataset: n2 } = e2, r2 = this.chart._animationsDisabled;
    let { start: o2, count: a2 } = Ev(e2, s2, r2);
    this._drawStart = o2, this._drawCount = a2, Av(e2) && (o2 = 0, a2 = s2.length), i2._chart = this.chart, i2._datasetIndex = this.index, i2._decimated = !!n2._decimated, i2.points = s2;
    const l2 = this.resolveDatasetElementOptions(t2);
    this.options.showLine || (l2.borderWidth = 0), l2.segment = this.options.segment, this.updateElement(i2, void 0, { animated: !r2, options: l2 }, t2), this.updateElements(s2, o2, a2, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2, _stacked: a2, _dataset: l2 } = this._cachedMeta, { sharedOptions: h2, includeOptions: c2 } = this._getSharedOptions(e2, s2), u2 = r2.axis, d2 = o2.axis, { spanGaps: f2, segment: p2 } = this.options, m2 = uv(f2) ? f2 : Number.POSITIVE_INFINITY, g2 = this.chart._animationsDisabled || n2 || "none" === s2, v2 = e2 + i2, b2 = t2.length;
    let _2 = e2 > 0 && this.getParsed(e2 - 1);
    for (let i3 = 0; i3 < b2; ++i3) {
      const f3 = t2[i3], b3 = g2 ? f3 : {};
      if (i3 < e2 || i3 >= v2) {
        b3.skip = true;
        continue;
      }
      const y2 = this.getParsed(i3), w2 = Tg(y2[d2]), x2 = b3[u2] = r2.getPixelForValue(y2[u2], i3), k2 = b3[d2] = n2 || w2 ? o2.getBasePixel() : o2.getPixelForValue(a2 ? this.applyStack(o2, y2, a2) : y2[d2], i3);
      b3.skip = isNaN(x2) || isNaN(k2) || w2, b3.stop = i3 > 0 && Math.abs(y2[u2] - _2[u2]) > m2, p2 && (b3.parsed = y2, b3.raw = l2.data[i3]), c2 && (b3.options = h2 || this.resolveDataElementOptions(i3, f3.active ? "active" : s2)), g2 || this.updateElement(f3, i3, b3, s2), _2 = y2;
    }
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta, e2 = t2.dataset, i2 = e2.options && e2.options.borderWidth || 0, s2 = t2.data || [];
    if (!s2.length) return i2;
    const n2 = s2[0].size(this.resolveDataElementOptions(0)), r2 = s2[s2.length - 1].size(this.resolveDataElementOptions(s2.length - 1));
    return Math.max(i2, n2, r2) / 2;
  }
  draw() {
    const t2 = this._cachedMeta;
    t2.dataset.updateControlPoints(this.chart.chartArea, t2.iScale.axis), super.draw();
  }
}
__publicField(LineController, "id", "line");
__publicField(LineController, "defaults", { datasetElementType: "line", dataElementType: "point", showLine: true, spanGaps: false });
__publicField(LineController, "overrides", { scales: { _index_: { type: "category" }, _value_: { type: "linear" } } });
class PolarAreaController extends DatasetController {
  constructor(t2, e2) {
    super(t2, e2), this.innerRadius = void 0, this.outerRadius = void 0;
  }
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart, s2 = i2.data.labels || [], n2 = Hv(e2._parsed[t2].r, i2.options.locale);
    return { label: s2[t2] || "", value: n2 };
  }
  parseObjectData(t2, e2, i2, s2) {
    return Ib.bind(this)(t2, e2, i2, s2);
  }
  update(t2) {
    const e2 = this._cachedMeta.data;
    this._updateRadius(), this.updateElements(e2, 0, e2.length, t2);
  }
  getMinMax() {
    const t2 = this._cachedMeta, e2 = { min: Number.POSITIVE_INFINITY, max: Number.NEGATIVE_INFINITY };
    return t2.data.forEach((t3, i2) => {
      const s2 = this.getParsed(i2).r;
      !isNaN(s2) && this.chart.getDataVisibility(i2) && (s2 < e2.min && (e2.min = s2), s2 > e2.max && (e2.max = s2));
    }), e2;
  }
  _updateRadius() {
    const t2 = this.chart, e2 = t2.chartArea, i2 = t2.options, s2 = Math.min(e2.right - e2.left, e2.bottom - e2.top), n2 = Math.max(s2 / 2, 0), r2 = (n2 - Math.max(i2.cutoutPercentage ? n2 / 100 * i2.cutoutPercentage : 1, 0)) / t2.getVisibleDatasetCount();
    this.outerRadius = n2 - r2 * this.index, this.innerRadius = this.outerRadius - r2;
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, r2 = this.chart, o2 = r2.options.animation, a2 = this._cachedMeta.rScale, l2 = a2.xCenter, h2 = a2.yCenter, c2 = a2.getIndexAngle(0) - 0.5 * Zg;
    let u2, d2 = c2;
    const f2 = 360 / this.countVisibleElements();
    for (u2 = 0; u2 < e2; ++u2) d2 += this._computeAngle(u2, s2, f2);
    for (u2 = e2; u2 < e2 + i2; u2++) {
      const e3 = t2[u2];
      let i3 = d2, p2 = d2 + this._computeAngle(u2, s2, f2), m2 = r2.getDataVisibility(u2) ? a2.getDistanceFromCenterForValue(this.getParsed(u2).r) : 0;
      d2 = p2, n2 && (o2.animateScale && (m2 = 0), o2.animateRotate && (i3 = p2 = c2));
      const g2 = { x: l2, y: h2, innerRadius: 0, outerRadius: m2, startAngle: i3, endAngle: p2, options: this.resolveDataElementOptions(u2, e3.active ? "active" : s2) };
      this.updateElement(e3, u2, g2, s2);
    }
  }
  countVisibleElements() {
    const t2 = this._cachedMeta;
    let e2 = 0;
    return t2.data.forEach((t3, i2) => {
      !isNaN(this.getParsed(i2).r) && this.chart.getDataVisibility(i2) && e2++;
    }), e2;
  }
  _computeAngle(t2, e2, i2) {
    return this.chart.getDataVisibility(t2) ? fv(this.resolveDataElementOptions(t2, e2).angle || i2) : 0;
  }
}
__publicField(PolarAreaController, "id", "polarArea");
__publicField(PolarAreaController, "defaults", { dataElementType: "arc", animation: { animateRotate: true, animateScale: true }, animations: { numbers: { type: "number", properties: ["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"] } }, indexAxis: "r", startAngle: 0 });
__publicField(PolarAreaController, "overrides", { aspectRatio: 1, plugins: { legend: { labels: { generateLabels(t2) {
  const e2 = t2.data;
  if (e2.labels.length && e2.datasets.length) {
    const { labels: { pointStyle: i2, color: s2 } } = t2.legend.options;
    return e2.labels.map((e3, n2) => {
      const r2 = t2.getDatasetMeta(0).controller.getStyle(n2);
      return { text: e3, fillStyle: r2.backgroundColor, strokeStyle: r2.borderColor, fontColor: s2, lineWidth: r2.borderWidth, pointStyle: i2, hidden: !t2.getDataVisibility(n2), index: n2 };
    });
  }
  return [];
} }, onClick(t2, e2, i2) {
  i2.chart.toggleDataVisibility(e2.index), i2.chart.update();
} } }, scales: { r: { type: "radialLinear", angleLines: { display: false }, beginAtZero: true, grid: { circular: true }, pointLabels: { display: false }, startAngle: 0 } } });
var O_ = Object.freeze({ __proto__: null, BarController, BubbleController, DoughnutController, LineController, PieController: (_b2 = class extends DoughnutController {
}, __publicField(_b2, "id", "pie"), __publicField(_b2, "defaults", { cutout: 0, rotation: 0, circumference: 360, radius: "100%" }), _b2), PolarAreaController, RadarController: (_c2 = class extends DatasetController {
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta.vScale, i2 = this.getParsed(t2);
    return { label: e2.getLabels()[t2], value: "" + e2.getLabelForValue(i2[e2.axis]) };
  }
  parseObjectData(t2, e2, i2, s2) {
    return Ib.bind(this)(t2, e2, i2, s2);
  }
  update(t2) {
    const e2 = this._cachedMeta, i2 = e2.dataset, s2 = e2.data || [], n2 = e2.iScale.getLabels();
    if (i2.points = s2, "resize" !== t2) {
      const e3 = this.resolveDatasetElementOptions(t2);
      this.options.showLine || (e3.borderWidth = 0);
      const r2 = { _loop: true, _fullLoop: n2.length === s2.length, options: e3 };
      this.updateElement(i2, void 0, r2, t2);
    }
    this.updateElements(s2, 0, s2.length, t2);
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = this._cachedMeta.rScale, r2 = "reset" === s2;
    for (let o2 = e2; o2 < e2 + i2; o2++) {
      const e3 = t2[o2], i3 = this.resolveDataElementOptions(o2, e3.active ? "active" : s2), a2 = n2.getPointPositionForValue(o2, this.getParsed(o2).r), l2 = r2 ? n2.xCenter : a2.x, h2 = r2 ? n2.yCenter : a2.y, c2 = { x: l2, y: h2, angle: a2.angle, skip: isNaN(l2) || isNaN(h2), options: i3 };
      this.updateElement(e3, o2, c2, s2);
    }
  }
}, __publicField(_c2, "id", "radar"), __publicField(_c2, "defaults", { datasetElementType: "line", dataElementType: "point", indexAxis: "r", showLine: true, elements: { line: { fill: "start" } } }), __publicField(_c2, "overrides", { aspectRatio: 1, scales: { r: { type: "radialLinear" } } }), _c2), ScatterController: (_d2 = class extends DatasetController {
  getLabelAndValue(t2) {
    const e2 = this._cachedMeta, i2 = this.chart.data.labels || [], { xScale: s2, yScale: n2 } = e2, r2 = this.getParsed(t2), o2 = s2.getLabelForValue(r2.x), a2 = n2.getLabelForValue(r2.y);
    return { label: i2[t2] || "", value: "(" + o2 + ", " + a2 + ")" };
  }
  update(t2) {
    const e2 = this._cachedMeta, { data: i2 = [] } = e2, s2 = this.chart._animationsDisabled;
    let { start: n2, count: r2 } = Ev(e2, i2, s2);
    if (this._drawStart = n2, this._drawCount = r2, Av(e2) && (n2 = 0, r2 = i2.length), this.options.showLine) {
      this.datasetElementType || this.addElements();
      const { dataset: n3, _dataset: r3 } = e2;
      n3._chart = this.chart, n3._datasetIndex = this.index, n3._decimated = !!r3._decimated, n3.points = i2;
      const o2 = this.resolveDatasetElementOptions(t2);
      o2.segment = this.options.segment, this.updateElement(n3, void 0, { animated: !s2, options: o2 }, t2);
    } else this.datasetElementType && (delete e2.dataset, this.datasetElementType = false);
    this.updateElements(i2, n2, r2, t2);
  }
  addElements() {
    const { showLine: t2 } = this.options;
    !this.datasetElementType && t2 && (this.datasetElementType = this.chart.registry.getElement("line")), super.addElements();
  }
  updateElements(t2, e2, i2, s2) {
    const n2 = "reset" === s2, { iScale: r2, vScale: o2, _stacked: a2, _dataset: l2 } = this._cachedMeta, h2 = this.resolveDataElementOptions(e2, s2), c2 = this.getSharedOptions(h2), u2 = this.includeOptions(s2, c2), d2 = r2.axis, f2 = o2.axis, { spanGaps: p2, segment: m2 } = this.options, g2 = uv(p2) ? p2 : Number.POSITIVE_INFINITY, v2 = this.chart._animationsDisabled || n2 || "none" === s2;
    let b2 = e2 > 0 && this.getParsed(e2 - 1);
    for (let h3 = e2; h3 < e2 + i2; ++h3) {
      const e3 = t2[h3], i3 = this.getParsed(h3), p3 = v2 ? e3 : {}, _2 = Tg(i3[f2]), y2 = p3[d2] = r2.getPixelForValue(i3[d2], h3), w2 = p3[f2] = n2 || _2 ? o2.getBasePixel() : o2.getPixelForValue(a2 ? this.applyStack(o2, i3, a2) : i3[f2], h3);
      p3.skip = isNaN(y2) || isNaN(w2) || _2, p3.stop = h3 > 0 && Math.abs(i3[d2] - b2[d2]) > g2, m2 && (p3.parsed = i3, p3.raw = l2.data[h3]), u2 && (p3.options = c2 || this.resolveDataElementOptions(h3, e3.active ? "active" : s2)), v2 || this.updateElement(e3, h3, p3, s2), b2 = i3;
    }
    this.updateSharedOptions(c2, s2, h2);
  }
  getMaxOverflow() {
    const t2 = this._cachedMeta, e2 = t2.data || [];
    if (!this.options.showLine) {
      let t3 = 0;
      for (let i3 = e2.length - 1; i3 >= 0; --i3) t3 = Math.max(t3, e2[i3].size(this.resolveDataElementOptions(i3)) / 2);
      return t3 > 0 && t3;
    }
    const i2 = t2.dataset, s2 = i2.options && i2.options.borderWidth || 0;
    if (!e2.length) return s2;
    const n2 = e2[0].size(this.resolveDataElementOptions(0)), r2 = e2[e2.length - 1].size(this.resolveDataElementOptions(e2.length - 1));
    return Math.max(s2, n2, r2) / 2;
  }
}, __publicField(_d2, "id", "scatter"), __publicField(_d2, "defaults", { datasetElementType: false, dataElementType: "point", showLine: false, fill: false }), __publicField(_d2, "overrides", { interaction: { mode: "point" }, scales: { x: { type: "linear" }, y: { type: "linear" } } }), _d2) });
function I_() {
  throw new Error("This method is not implemented: Check that a complete date adapter is provided.");
}
class DateAdapterBase {
  constructor(t2) {
    __publicField(this, "options");
    this.options = t2 || {};
  }
  static override(t2) {
    Object.assign(DateAdapterBase.prototype, t2);
  }
  init() {
  }
  formats() {
    return I_();
  }
  parse() {
    return I_();
  }
  format() {
    return I_();
  }
  add() {
    return I_();
  }
  diff() {
    return I_();
  }
  startOf() {
    return I_();
  }
  endOf() {
    return I_();
  }
}
var N_ = DateAdapterBase;
function F_(t2, e2, i2, s2) {
  const { controller: n2, data: r2, _sorted: o2 } = t2, a2 = n2._cachedMeta.iScale, l2 = t2.dataset && t2.dataset.options ? t2.dataset.options.spanGaps : null;
  if (a2 && e2 === a2.axis && "r" !== e2 && o2 && r2.length) {
    const o3 = a2._reversePixels ? Mv : Sv;
    if (!s2) {
      const s3 = o3(r2, e2, i2);
      if (l2) {
        const { vScale: e3 } = n2._cachedMeta, { _parsed: i3 } = t2, r3 = i3.slice(0, s3.lo + 1).reverse().findIndex((t3) => !Tg(t3[e3.axis]));
        s3.lo -= Math.max(0, r3);
        const o4 = i3.slice(s3.hi).findIndex((t3) => !Tg(t3[e3.axis]));
        s3.hi += Math.max(0, o4);
      }
      return s3;
    }
    if (n2._sharedOptions) {
      const t3 = r2[0], s3 = "function" == typeof t3.getRange && t3.getRange(e2);
      if (s3) {
        const t4 = o3(r2, e2, i2 - s3), n3 = o3(r2, e2, i2 + s3);
        return { lo: t4.lo, hi: n3.hi };
      }
    }
  }
  return { lo: 0, hi: r2.length - 1 };
}
function W_(t2, e2, i2, s2, n2) {
  const r2 = t2.getSortedVisibleDatasetMetas(), o2 = i2[e2];
  for (let t3 = 0, i3 = r2.length; t3 < i3; ++t3) {
    const { index: i4, data: a2 } = r2[t3], { lo: l2, hi: h2 } = F_(r2[t3], e2, o2, n2);
    for (let t4 = l2; t4 <= h2; ++t4) {
      const e3 = a2[t4];
      e3.skip || s2(e3, i4, t4);
    }
  }
}
function B_(t2, e2, i2, s2, n2) {
  const r2 = [];
  return n2 || t2.isPointInArea(e2) ? (W_(t2, i2, e2, function(i3, o2, a2) {
    (n2 || rb(i3, t2.chartArea, 0)) && i3.inRange(e2.x, e2.y, s2) && r2.push({ element: i3, datasetIndex: o2, index: a2 });
  }, true), r2) : r2;
}
function j_(t2, e2, i2, s2, n2, r2) {
  return r2 || t2.isPointInArea(e2) ? "r" !== i2 || s2 ? function(t3, e3, i3, s3, n3, r3) {
    let o2 = [];
    const a2 = function(t4) {
      const e4 = -1 !== t4.indexOf("x"), i4 = -1 !== t4.indexOf("y");
      return function(t5, s4) {
        const n4 = e4 ? Math.abs(t5.x - s4.x) : 0, r4 = i4 ? Math.abs(t5.y - s4.y) : 0;
        return Math.sqrt(Math.pow(n4, 2) + Math.pow(r4, 2));
      };
    }(i3);
    let l2 = Number.POSITIVE_INFINITY;
    return W_(t3, i3, e3, function(i4, h2, c2) {
      const u2 = i4.inRange(e3.x, e3.y, n3);
      if (s3 && !u2) return;
      const d2 = i4.getCenterPoint(n3);
      if (!r3 && !t3.isPointInArea(d2) && !u2) return;
      const f2 = a2(e3, d2);
      f2 < l2 ? (o2 = [{ element: i4, datasetIndex: h2, index: c2 }], l2 = f2) : f2 === l2 && o2.push({ element: i4, datasetIndex: h2, index: c2 });
    }), o2;
  }(t2, e2, i2, s2, n2, r2) : function(t3, e3, i3, s3) {
    let n3 = [];
    return W_(t3, i3, e3, function(t4, i4, r3) {
      const { startAngle: o2, endAngle: a2 } = t4.getProps(["startAngle", "endAngle"], s3), { angle: l2 } = gv(t4, { x: e3.x, y: e3.y });
      yv(l2, o2, a2) && n3.push({ element: t4, datasetIndex: i4, index: r3 });
    }), n3;
  }(t2, e2, i2, n2) : [];
}
function q_(t2, e2, i2, s2, n2) {
  const r2 = [], o2 = "x" === i2 ? "inXRange" : "inYRange";
  let a2 = false;
  return W_(t2, i2, e2, (t3, s3, l2) => {
    t3[o2] && t3[o2](e2[i2], n2) && (r2.push({ element: t3, datasetIndex: s3, index: l2 }), a2 = a2 || t3.inRange(e2.x, e2.y, n2));
  }), s2 && !a2 ? [] : r2;
}
var H_ = { modes: { index(t2, e2, i2, s2) {
  const n2 = Xb(e2, t2), r2 = i2.axis || "x", o2 = i2.includeInvisible || false, a2 = i2.intersect ? B_(t2, n2, r2, s2, o2) : j_(t2, n2, r2, false, s2, o2), l2 = [];
  return a2.length ? (t2.getSortedVisibleDatasetMetas().forEach((t3) => {
    const e3 = a2[0].index, i3 = t3.data[e3];
    i3 && !i3.skip && l2.push({ element: i3, datasetIndex: t3.index, index: e3 });
  }), l2) : [];
}, dataset(t2, e2, i2, s2) {
  const n2 = Xb(e2, t2), r2 = i2.axis || "xy", o2 = i2.includeInvisible || false;
  let a2 = i2.intersect ? B_(t2, n2, r2, s2, o2) : j_(t2, n2, r2, false, s2, o2);
  if (a2.length > 0) {
    const e3 = a2[0].datasetIndex, i3 = t2.getDatasetMeta(e3).data;
    a2 = [];
    for (let t3 = 0; t3 < i3.length; ++t3) a2.push({ element: i3[t3], datasetIndex: e3, index: t3 });
  }
  return a2;
}, point: (t2, e2, i2, s2) => B_(t2, Xb(e2, t2), i2.axis || "xy", s2, i2.includeInvisible || false), nearest(t2, e2, i2, s2) {
  const n2 = Xb(e2, t2), r2 = i2.axis || "xy", o2 = i2.includeInvisible || false;
  return j_(t2, n2, r2, i2.intersect, s2, o2);
}, x: (t2, e2, i2, s2) => q_(t2, Xb(e2, t2), "x", i2.intersect, s2), y: (t2, e2, i2, s2) => q_(t2, Xb(e2, t2), "y", i2.intersect, s2) } };
const U_ = ["left", "top", "right", "bottom"];
function K_(t2, e2) {
  return t2.filter((t3) => t3.pos === e2);
}
function Y_(t2, e2) {
  return t2.filter((t3) => -1 === U_.indexOf(t3.pos) && t3.box.axis === e2);
}
function G_(t2, e2) {
  return t2.sort((t3, i2) => {
    const s2 = e2 ? i2 : t3, n2 = e2 ? t3 : i2;
    return s2.weight === n2.weight ? s2.index - n2.index : s2.weight - n2.weight;
  });
}
function X_(t2, e2, i2, s2) {
  return Math.max(t2[i2], e2[i2]) + Math.max(t2[s2], e2[s2]);
}
function J_(t2, e2) {
  t2.top = Math.max(t2.top, e2.top), t2.left = Math.max(t2.left, e2.left), t2.bottom = Math.max(t2.bottom, e2.bottom), t2.right = Math.max(t2.right, e2.right);
}
function Q_(t2, e2, i2, s2) {
  const { pos: n2, box: r2 } = i2, o2 = t2.maxPadding;
  if (!Eg(n2)) {
    i2.size && (t2[n2] -= i2.size);
    const e3 = s2[i2.stack] || { size: 0, count: 1 };
    e3.size = Math.max(e3.size, i2.horizontal ? r2.height : r2.width), i2.size = e3.size / e3.count, t2[n2] += i2.size;
  }
  r2.getPadding && J_(o2, r2.getPadding());
  const a2 = Math.max(0, e2.outerWidth - X_(o2, t2, "left", "right")), l2 = Math.max(0, e2.outerHeight - X_(o2, t2, "top", "bottom")), h2 = a2 !== t2.w, c2 = l2 !== t2.h;
  return t2.w = a2, t2.h = l2, i2.horizontal ? { same: h2, other: c2 } : { same: c2, other: h2 };
}
function Z_(t2, e2) {
  const i2 = e2.maxPadding;
  return function(t3) {
    const s2 = { left: 0, top: 0, right: 0, bottom: 0 };
    return t3.forEach((t4) => {
      s2[t4] = Math.max(e2[t4], i2[t4]);
    }), s2;
  }(t2 ? ["left", "right"] : ["top", "bottom"]);
}
function ty(t2, e2, i2, s2) {
  const n2 = [];
  let r2, o2, a2, l2, h2, c2;
  for (r2 = 0, o2 = t2.length, h2 = 0; r2 < o2; ++r2) {
    a2 = t2[r2], l2 = a2.box, l2.update(a2.width || e2.w, a2.height || e2.h, Z_(a2.horizontal, e2));
    const { same: o3, other: u2 } = Q_(e2, i2, a2, s2);
    h2 |= o3 && n2.length, c2 = c2 || u2, l2.fullSize || n2.push(a2);
  }
  return h2 && ty(n2, e2, i2, s2) || c2;
}
function ey(t2, e2, i2, s2, n2) {
  t2.top = i2, t2.left = e2, t2.right = e2 + s2, t2.bottom = i2 + n2, t2.width = s2, t2.height = n2;
}
function iy(t2, e2, i2, s2) {
  const n2 = i2.padding;
  let { x: r2, y: o2 } = e2;
  for (const a2 of t2) {
    const t3 = a2.box, l2 = s2[a2.stack] || { placed: 0, weight: 1 }, h2 = a2.stackWeight / l2.weight || 1;
    if (a2.horizontal) {
      const s3 = e2.w * h2, r3 = l2.size || t3.height;
      Xg(l2.start) && (o2 = l2.start), t3.fullSize ? ey(t3, n2.left, o2, i2.outerWidth - n2.right - n2.left, r3) : ey(t3, e2.left + l2.placed, o2, s3, r3), l2.start = o2, l2.placed += s3, o2 = t3.bottom;
    } else {
      const s3 = e2.h * h2, o3 = l2.size || t3.width;
      Xg(l2.start) && (r2 = l2.start), t3.fullSize ? ey(t3, r2, n2.top, o3, i2.outerHeight - n2.bottom - n2.top) : ey(t3, r2, e2.top + l2.placed, o3, s3), l2.start = r2, l2.placed += s3, r2 = t3.right;
    }
  }
  e2.x = r2, e2.y = o2;
}
var sy = { addBox(t2, e2) {
  t2.boxes || (t2.boxes = []), e2.fullSize = e2.fullSize || false, e2.position = e2.position || "top", e2.weight = e2.weight || 0, e2._layers = e2._layers || function() {
    return [{ z: 0, draw(t3) {
      e2.draw(t3);
    } }];
  }, t2.boxes.push(e2);
}, removeBox(t2, e2) {
  const i2 = t2.boxes ? t2.boxes.indexOf(e2) : -1;
  -1 !== i2 && t2.boxes.splice(i2, 1);
}, configure(t2, e2, i2) {
  e2.fullSize = i2.fullSize, e2.position = i2.position, e2.weight = i2.weight;
}, update(t2, e2, i2, s2) {
  if (!t2) return;
  const n2 = wb(t2.options.layout.padding), r2 = Math.max(e2 - n2.width, 0), o2 = Math.max(i2 - n2.height, 0), a2 = function(t3) {
    const e3 = function(t4) {
      const e4 = [];
      let i4, s4, n4, r4, o4, a4;
      for (i4 = 0, s4 = (t4 || []).length; i4 < s4; ++i4) n4 = t4[i4], { position: r4, options: { stack: o4, stackWeight: a4 = 1 } } = n4, e4.push({ index: i4, box: n4, pos: r4, horizontal: n4.isHorizontal(), weight: n4.weight, stack: o4 && r4 + o4, stackWeight: a4 });
      return e4;
    }(t3), i3 = G_(e3.filter((t4) => t4.box.fullSize), true), s3 = G_(K_(e3, "left"), true), n3 = G_(K_(e3, "right")), r3 = G_(K_(e3, "top"), true), o3 = G_(K_(e3, "bottom")), a3 = Y_(e3, "x"), l3 = Y_(e3, "y");
    return { fullSize: i3, leftAndTop: s3.concat(r3), rightAndBottom: n3.concat(l3).concat(o3).concat(a3), chartArea: K_(e3, "chartArea"), vertical: s3.concat(n3).concat(l3), horizontal: r3.concat(o3).concat(a3) };
  }(t2.boxes), l2 = a2.vertical, h2 = a2.horizontal;
  Ng(t2.boxes, (t3) => {
    "function" == typeof t3.beforeLayout && t3.beforeLayout();
  });
  const c2 = l2.reduce((t3, e3) => e3.box.options && false === e3.box.options.display ? t3 : t3 + 1, 0) || 1, u2 = Object.freeze({ outerWidth: e2, outerHeight: i2, padding: n2, availableWidth: r2, availableHeight: o2, vBoxMaxWidth: r2 / 2 / c2, hBoxMaxHeight: o2 / 2 }), d2 = Object.assign({}, n2);
  J_(d2, wb(s2));
  const f2 = Object.assign({ maxPadding: d2, w: r2, h: o2, x: n2.left, y: n2.top }, n2), p2 = function(t3, e3) {
    const i3 = function(t4) {
      const e4 = {};
      for (const i4 of t4) {
        const { stack: t5, pos: s4, stackWeight: n4 } = i4;
        if (!t5 || !U_.includes(s4)) continue;
        const r4 = e4[t5] || (e4[t5] = { count: 0, placed: 0, weight: 0, size: 0 });
        r4.count++, r4.weight += n4;
      }
      return e4;
    }(t3), { vBoxMaxWidth: s3, hBoxMaxHeight: n3 } = e3;
    let r3, o3, a3;
    for (r3 = 0, o3 = t3.length; r3 < o3; ++r3) {
      a3 = t3[r3];
      const { fullSize: o4 } = a3.box, l3 = i3[a3.stack], h3 = l3 && a3.stackWeight / l3.weight;
      a3.horizontal ? (a3.width = h3 ? h3 * s3 : o4 && e3.availableWidth, a3.height = n3) : (a3.width = s3, a3.height = h3 ? h3 * n3 : o4 && e3.availableHeight);
    }
    return i3;
  }(l2.concat(h2), u2);
  ty(a2.fullSize, f2, u2, p2), ty(l2, f2, u2, p2), ty(h2, f2, u2, p2) && ty(l2, f2, u2, p2), function(t3) {
    const e3 = t3.maxPadding;
    function i3(i4) {
      const s3 = Math.max(e3[i4] - t3[i4], 0);
      return t3[i4] += s3, s3;
    }
    t3.y += i3("top"), t3.x += i3("left"), i3("right"), i3("bottom");
  }(f2), iy(a2.leftAndTop, f2, u2, p2), f2.x += f2.w, f2.y += f2.h, iy(a2.rightAndBottom, f2, u2, p2), t2.chartArea = { left: f2.left, top: f2.top, right: f2.left + f2.w, bottom: f2.top + f2.h, height: f2.h, width: f2.w }, Ng(a2.chartArea, (e3) => {
    const i3 = e3.box;
    Object.assign(i3, t2.chartArea), i3.update(f2.w, f2.h, { left: 0, top: 0, right: 0, bottom: 0 });
  });
} };
class BasePlatform {
  acquireContext(t2, e2) {
  }
  releaseContext(t2) {
    return false;
  }
  addEventListener(t2, e2, i2) {
  }
  removeEventListener(t2, e2, i2) {
  }
  getDevicePixelRatio() {
    return 1;
  }
  getMaximumSize(t2, e2, i2, s2) {
    return e2 = Math.max(0, e2 || t2.width), i2 = i2 || t2.height, { width: e2, height: Math.max(0, s2 ? Math.floor(e2 / s2) : i2) };
  }
  isAttached(t2) {
    return true;
  }
  updateConfig(t2) {
  }
}
class BasicPlatform extends BasePlatform {
  acquireContext(t2) {
    return t2 && t2.getContext && t2.getContext("2d") || null;
  }
  updateConfig(t2) {
    t2.options.animation = false;
  }
}
const ny = "$chartjs", ry = { touchstart: "mousedown", touchmove: "mousemove", touchend: "mouseup", pointerenter: "mouseenter", pointerdown: "mousedown", pointermove: "mousemove", pointerup: "mouseup", pointerleave: "mouseout", pointerout: "mouseout" }, oy = (t2) => null === t2 || "" === t2, ay = !!Zb && { passive: true };
function ly(t2, e2, i2) {
  t2 && t2.canvas && t2.canvas.removeEventListener(e2, i2, ay);
}
function hy(t2, e2) {
  for (const i2 of t2) if (i2 === e2 || i2.contains(e2)) return true;
}
function cy(t2, e2, i2) {
  const s2 = t2.canvas, n2 = new MutationObserver((t3) => {
    let e3 = false;
    for (const i3 of t3) e3 = e3 || hy(i3.addedNodes, s2), e3 = e3 && !hy(i3.removedNodes, s2);
    e3 && i2();
  });
  return n2.observe(document, { childList: true, subtree: true }), n2;
}
function uy(t2, e2, i2) {
  const s2 = t2.canvas, n2 = new MutationObserver((t3) => {
    let e3 = false;
    for (const i3 of t3) e3 = e3 || hy(i3.removedNodes, s2), e3 = e3 && !hy(i3.addedNodes, s2);
    e3 && i2();
  });
  return n2.observe(document, { childList: true, subtree: true }), n2;
}
const dy = /* @__PURE__ */ new Map();
let fy = 0;
function py() {
  const t2 = window.devicePixelRatio;
  t2 !== fy && (fy = t2, dy.forEach((e2, i2) => {
    i2.currentDevicePixelRatio !== t2 && e2();
  }));
}
function my(t2, e2, i2) {
  const s2 = t2.canvas, n2 = s2 && Hb(s2);
  if (!n2) return;
  const r2 = Pv((t3, e3) => {
    const s3 = n2.clientWidth;
    i2(t3, e3), s3 < n2.clientWidth && i2();
  }, window), o2 = new ResizeObserver((t3) => {
    const e3 = t3[0], i3 = e3.contentRect.width, s3 = e3.contentRect.height;
    0 === i3 && 0 === s3 || r2(i3, s3);
  });
  return o2.observe(n2), function(t3, e3) {
    dy.size || window.addEventListener("resize", py), dy.set(t3, e3);
  }(t2, r2), o2;
}
function gy(t2, e2, i2) {
  i2 && i2.disconnect(), "resize" === e2 && function(t3) {
    dy.delete(t3), dy.size || window.removeEventListener("resize", py);
  }(t2);
}
function vy(t2, e2, i2) {
  const s2 = t2.canvas, n2 = Pv((e3) => {
    null !== t2.ctx && i2(function(t3, e4) {
      const i3 = ry[t3.type] || t3.type, { x: s3, y: n3 } = Xb(t3, e4);
      return { type: i3, chart: e4, native: t3, x: void 0 !== s3 ? s3 : null, y: void 0 !== n3 ? n3 : null };
    }(e3, t2));
  }, t2);
  return function(t3, e3, i3) {
    t3 && t3.addEventListener(e3, i3, ay);
  }(s2, e2, n2), n2;
}
class DomPlatform extends BasePlatform {
  acquireContext(t2, e2) {
    const i2 = t2 && t2.getContext && t2.getContext("2d");
    return i2 && i2.canvas === t2 ? (function(t3, e3) {
      const i3 = t3.style, s2 = t3.getAttribute("height"), n2 = t3.getAttribute("width");
      if (t3[ny] = { initial: { height: s2, width: n2, style: { display: i3.display, height: i3.height, width: i3.width } } }, i3.display = i3.display || "block", i3.boxSizing = i3.boxSizing || "border-box", oy(n2)) {
        const e4 = t_(t3, "width");
        void 0 !== e4 && (t3.width = e4);
      }
      if (oy(s2)) if ("" === t3.style.height) t3.height = t3.width / (e3 || 2);
      else {
        const e4 = t_(t3, "height");
        void 0 !== e4 && (t3.height = e4);
      }
    }(t2, e2), i2) : null;
  }
  releaseContext(t2) {
    const e2 = t2.canvas;
    if (!e2[ny]) return false;
    const i2 = e2[ny].initial;
    ["height", "width"].forEach((t3) => {
      const s3 = i2[t3];
      Tg(s3) ? e2.removeAttribute(t3) : e2.setAttribute(t3, s3);
    });
    const s2 = i2.style || {};
    return Object.keys(s2).forEach((t3) => {
      e2.style[t3] = s2[t3];
    }), e2.width = e2.width, delete e2[ny], true;
  }
  addEventListener(t2, e2, i2) {
    this.removeEventListener(t2, e2);
    const s2 = t2.$proxies || (t2.$proxies = {}), n2 = { attach: cy, detach: uy, resize: my }[e2] || vy;
    s2[e2] = n2(t2, e2, i2);
  }
  removeEventListener(t2, e2) {
    const i2 = t2.$proxies || (t2.$proxies = {}), s2 = i2[e2];
    s2 && (({ attach: gy, detach: gy, resize: gy }[e2] || ly)(t2, e2, s2), i2[e2] = void 0);
  }
  getDevicePixelRatio() {
    return window.devicePixelRatio;
  }
  getMaximumSize(t2, e2, i2, s2) {
    return function(t3, e3, i3, s3) {
      const n2 = Kb(t3), r2 = Gb(n2, "margin"), o2 = Ub(n2.maxWidth, t3, "clientWidth") || iv, a2 = Ub(n2.maxHeight, t3, "clientHeight") || iv, l2 = function(t4, e4, i4) {
        let s4, n3;
        if (void 0 === e4 || void 0 === i4) {
          const r3 = t4 && Hb(t4);
          if (r3) {
            const t5 = r3.getBoundingClientRect(), o3 = Kb(r3), a3 = Gb(o3, "border", "width"), l3 = Gb(o3, "padding");
            e4 = t5.width - l3.width - a3.width, i4 = t5.height - l3.height - a3.height, s4 = Ub(o3.maxWidth, r3, "clientWidth"), n3 = Ub(o3.maxHeight, r3, "clientHeight");
          } else e4 = t4.clientWidth, i4 = t4.clientHeight;
        }
        return { width: e4, height: i4, maxWidth: s4 || iv, maxHeight: n3 || iv };
      }(t3, e3, i3);
      let { width: h2, height: c2 } = l2;
      if ("content-box" === n2.boxSizing) {
        const t4 = Gb(n2, "border", "width"), e4 = Gb(n2, "padding");
        h2 -= e4.width + t4.width, c2 -= e4.height + t4.height;
      }
      return h2 = Math.max(0, h2 - r2.width), c2 = Math.max(0, s3 ? h2 / s3 : c2 - r2.height), h2 = Jb(Math.min(h2, o2, l2.maxWidth)), c2 = Jb(Math.min(c2, a2, l2.maxHeight)), h2 && !c2 && (c2 = Jb(h2 / 2)), (void 0 !== e3 || void 0 !== i3) && s3 && l2.height && c2 > l2.height && (c2 = l2.height, h2 = Jb(Math.floor(c2 * s3))), { width: h2, height: c2 };
    }(t2, e2, i2, s2);
  }
  isAttached(t2) {
    const e2 = t2 && Hb(t2);
    return !(!e2 || !e2.isConnected);
  }
}
let by = (_e2 = class {
  constructor() {
    __publicField(this, "x");
    __publicField(this, "y");
    __publicField(this, "active", false);
    __publicField(this, "options");
    __publicField(this, "$animations");
  }
  tooltipPosition(t2) {
    const { x: e2, y: i2 } = this.getProps(["x", "y"], t2);
    return { x: e2, y: i2 };
  }
  hasValue() {
    return uv(this.x) && uv(this.y);
  }
  getProps(t2, e2) {
    const i2 = this.$animations;
    if (!e2 || !i2) return this;
    const s2 = {};
    return t2.forEach((t3) => {
      s2[t3] = i2[t3] && i2[t3].active() ? i2[t3]._to : this[t3];
    }), s2;
  }
}, __publicField(_e2, "defaults", {}), __publicField(_e2, "defaultRoutes"), _e2);
function _y(t2, e2, i2, s2, n2) {
  const r2 = Vg(s2, 0), o2 = Math.min(Vg(n2, t2.length), t2.length);
  let a2, l2, h2, c2 = 0;
  for (i2 = Math.ceil(i2), n2 && (a2 = n2 - s2, i2 = a2 / Math.floor(a2 / i2)), h2 = r2; h2 < 0; ) c2++, h2 = Math.round(r2 + c2 * i2);
  for (l2 = Math.max(r2, 0); l2 < o2; l2++) l2 === h2 && (e2.push(t2[l2]), c2++, h2 = Math.round(r2 + c2 * i2));
}
const yy = (t2, e2, i2) => "top" === e2 || "left" === e2 ? t2[e2] + i2 : t2[e2] - i2, wy = (t2, e2) => Math.min(e2 || t2, t2);
function xy(t2, e2) {
  const i2 = [], s2 = t2.length / e2, n2 = t2.length;
  let r2 = 0;
  for (; r2 < n2; r2 += s2) i2.push(t2[Math.floor(r2)]);
  return i2;
}
function ky(t2, e2, i2) {
  const s2 = t2.ticks.length, n2 = Math.min(e2, s2 - 1), r2 = t2._startPixel, o2 = t2._endPixel, a2 = 1e-6;
  let l2, h2 = t2.getPixelForTick(n2);
  if (!(i2 && (l2 = 1 === s2 ? Math.max(h2 - r2, o2 - h2) : 0 === e2 ? (t2.getPixelForTick(1) - h2) / 2 : (h2 - t2.getPixelForTick(n2 - 1)) / 2, h2 += n2 < e2 ? l2 : -l2, h2 < r2 - a2 || h2 > o2 + a2))) return h2;
}
function Sy(t2) {
  return t2.drawTicks ? t2.tickLength : 0;
}
function My(t2, e2) {
  if (!t2.display) return 0;
  const i2 = xb(t2.font, e2), s2 = wb(t2.padding);
  return ($g(t2.text) ? t2.text.length : 1) * i2.lineHeight + s2.height;
}
function zy(t2, e2, i2) {
  let s2 = Tv(t2);
  return (i2 && "right" !== e2 || !i2 && "right" === e2) && (s2 = /* @__PURE__ */ ((t3) => "left" === t3 ? "right" : "right" === t3 ? "left" : t3)(s2)), s2;
}
class Scale extends by {
  constructor(t2) {
    super(), this.id = t2.id, this.type = t2.type, this.options = void 0, this.ctx = t2.ctx, this.chart = t2.chart, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this._margins = { left: 0, right: 0, top: 0, bottom: 0 }, this.maxWidth = void 0, this.maxHeight = void 0, this.paddingTop = void 0, this.paddingBottom = void 0, this.paddingLeft = void 0, this.paddingRight = void 0, this.axis = void 0, this.labelRotation = void 0, this.min = void 0, this.max = void 0, this._range = void 0, this.ticks = [], this._gridLineItems = null, this._labelItems = null, this._labelSizes = null, this._length = 0, this._maxLength = 0, this._longestTextCache = {}, this._startPixel = void 0, this._endPixel = void 0, this._reversePixels = false, this._userMax = void 0, this._userMin = void 0, this._suggestedMax = void 0, this._suggestedMin = void 0, this._ticksLength = 0, this._borderValue = 0, this._cache = {}, this._dataLimitsCached = false, this.$context = void 0;
  }
  init(t2) {
    this.options = t2.setContext(this.getContext()), this.axis = t2.axis, this._userMin = this.parse(t2.min), this._userMax = this.parse(t2.max), this._suggestedMin = this.parse(t2.suggestedMin), this._suggestedMax = this.parse(t2.suggestedMax);
  }
  parse(t2, e2) {
    return t2;
  }
  getUserBounds() {
    let { _userMin: t2, _userMax: e2, _suggestedMin: i2, _suggestedMax: s2 } = this;
    return t2 = Lg(t2, Number.POSITIVE_INFINITY), e2 = Lg(e2, Number.NEGATIVE_INFINITY), i2 = Lg(i2, Number.POSITIVE_INFINITY), s2 = Lg(s2, Number.NEGATIVE_INFINITY), { min: Lg(t2, i2), max: Lg(e2, s2), minDefined: Ag(t2), maxDefined: Ag(e2) };
  }
  getMinMax(t2) {
    let e2, { min: i2, max: s2, minDefined: n2, maxDefined: r2 } = this.getUserBounds();
    if (n2 && r2) return { min: i2, max: s2 };
    const o2 = this.getMatchingVisibleMetas();
    for (let a2 = 0, l2 = o2.length; a2 < l2; ++a2) e2 = o2[a2].controller.getMinMax(this, t2), n2 || (i2 = Math.min(i2, e2.min)), r2 || (s2 = Math.max(s2, e2.max));
    return i2 = r2 && i2 > s2 ? s2 : i2, s2 = n2 && i2 > s2 ? i2 : s2, { min: Lg(i2, Lg(s2, i2)), max: Lg(s2, Lg(i2, s2)) };
  }
  getPadding() {
    return { left: this.paddingLeft || 0, top: this.paddingTop || 0, right: this.paddingRight || 0, bottom: this.paddingBottom || 0 };
  }
  getTicks() {
    return this.ticks;
  }
  getLabels() {
    const t2 = this.chart.data;
    return this.options.labels || (this.isHorizontal() ? t2.xLabels : t2.yLabels) || t2.labels || [];
  }
  getLabelItems(t2 = this.chart.chartArea) {
    return this._labelItems || (this._labelItems = this._computeLabelItems(t2));
  }
  beforeLayout() {
    this._cache = {}, this._dataLimitsCached = false;
  }
  beforeUpdate() {
    Ig(this.options.beforeUpdate, [this]);
  }
  update(t2, e2, i2) {
    const { beginAtZero: s2, grace: n2, ticks: r2 } = this.options, o2 = r2.sampleSize;
    this.beforeUpdate(), this.maxWidth = t2, this.maxHeight = e2, this._margins = i2 = Object.assign({ left: 0, right: 0, top: 0, bottom: 0 }, i2), this.ticks = null, this._labelSizes = null, this._gridLineItems = null, this._labelItems = null, this.beforeSetDimensions(), this.setDimensions(), this.afterSetDimensions(), this._maxLength = this.isHorizontal() ? this.width + i2.left + i2.right : this.height + i2.top + i2.bottom, this._dataLimitsCached || (this.beforeDataLimits(), this.determineDataLimits(), this.afterDataLimits(), this._range = function(t3, e3, i3) {
      const { min: s3, max: n3 } = t3, r3 = Og(e3, (n3 - s3) / 2), o3 = (t4, e4) => i3 && 0 === t4 ? 0 : t4 + e4;
      return { min: o3(s3, -Math.abs(r3)), max: o3(n3, r3) };
    }(this, n2, s2), this._dataLimitsCached = true), this.beforeBuildTicks(), this.ticks = this.buildTicks() || [], this.afterBuildTicks();
    const a2 = o2 < this.ticks.length;
    this._convertTicksToLabels(a2 ? xy(this.ticks, o2) : this.ticks), this.configure(), this.beforeCalculateLabelRotation(), this.calculateLabelRotation(), this.afterCalculateLabelRotation(), r2.display && (r2.autoSkip || "auto" === r2.source) && (this.ticks = function(t3, e3) {
      const i3 = t3.options.ticks, s3 = function(t4) {
        const e4 = t4.options.offset, i4 = t4._tickSize(), s4 = t4._length / i4 + (e4 ? 0 : 1), n4 = t4._maxLength / i4;
        return Math.floor(Math.min(s4, n4));
      }(t3), n3 = Math.min(i3.maxTicksLimit || s3, s3), r3 = i3.major.enabled ? function(t4) {
        const e4 = [];
        let i4, s4;
        for (i4 = 0, s4 = t4.length; i4 < s4; i4++) t4[i4].major && e4.push(i4);
        return e4;
      }(e3) : [], o3 = r3.length, a3 = r3[0], l2 = r3[o3 - 1], h2 = [];
      if (o3 > n3) return function(t4, e4, i4, s4) {
        let n4, r4 = 0, o4 = i4[0];
        for (s4 = Math.ceil(s4), n4 = 0; n4 < t4.length; n4++) n4 === o4 && (e4.push(t4[n4]), r4++, o4 = i4[r4 * s4]);
      }(e3, h2, r3, o3 / n3), h2;
      const c2 = function(t4, e4, i4) {
        const s4 = function(t5) {
          const e5 = t5.length;
          let i5, s5;
          if (e5 < 2) return false;
          for (s5 = t5[0], i5 = 1; i5 < e5; ++i5) if (t5[i5] - t5[i5 - 1] !== s5) return false;
          return s5;
        }(t4), n4 = e4.length / i4;
        if (!s4) return Math.max(n4, 1);
        const r4 = function(t5) {
          const e5 = [], i5 = Math.sqrt(t5);
          let s5;
          for (s5 = 1; s5 < i5; s5++) t5 % s5 === 0 && (e5.push(s5), e5.push(t5 / s5));
          return i5 === (0 | i5) && e5.push(i5), e5.sort((t6, e6) => t6 - e6).pop(), e5;
        }(s4);
        for (let t5 = 0, e5 = r4.length - 1; t5 < e5; t5++) {
          const e6 = r4[t5];
          if (e6 > n4) return e6;
        }
        return Math.max(n4, 1);
      }(r3, e3, n3);
      if (o3 > 0) {
        let t4, i4;
        const s4 = o3 > 1 ? Math.round((l2 - a3) / (o3 - 1)) : null;
        for (_y(e3, h2, c2, Tg(s4) ? 0 : a3 - s4, a3), t4 = 0, i4 = o3 - 1; t4 < i4; t4++) _y(e3, h2, c2, r3[t4], r3[t4 + 1]);
        return _y(e3, h2, c2, l2, Tg(s4) ? e3.length : l2 + s4), h2;
      }
      return _y(e3, h2, c2), h2;
    }(this, this.ticks), this._labelSizes = null, this.afterAutoSkip()), a2 && this._convertTicksToLabels(this.ticks), this.beforeFit(), this.fit(), this.afterFit(), this.afterUpdate();
  }
  configure() {
    let t2, e2, i2 = this.options.reverse;
    this.isHorizontal() ? (t2 = this.left, e2 = this.right) : (t2 = this.top, e2 = this.bottom, i2 = !i2), this._startPixel = t2, this._endPixel = e2, this._reversePixels = i2, this._length = e2 - t2, this._alignToPixels = this.options.alignToPixels;
  }
  afterUpdate() {
    Ig(this.options.afterUpdate, [this]);
  }
  beforeSetDimensions() {
    Ig(this.options.beforeSetDimensions, [this]);
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = 0, this.right = this.width) : (this.height = this.maxHeight, this.top = 0, this.bottom = this.height), this.paddingLeft = 0, this.paddingTop = 0, this.paddingRight = 0, this.paddingBottom = 0;
  }
  afterSetDimensions() {
    Ig(this.options.afterSetDimensions, [this]);
  }
  _callHooks(t2) {
    this.chart.notifyPlugins(t2, this.getContext()), Ig(this.options[t2], [this]);
  }
  beforeDataLimits() {
    this._callHooks("beforeDataLimits");
  }
  determineDataLimits() {
  }
  afterDataLimits() {
    this._callHooks("afterDataLimits");
  }
  beforeBuildTicks() {
    this._callHooks("beforeBuildTicks");
  }
  buildTicks() {
    return [];
  }
  afterBuildTicks() {
    this._callHooks("afterBuildTicks");
  }
  beforeTickToLabelConversion() {
    Ig(this.options.beforeTickToLabelConversion, [this]);
  }
  generateTickLabels(t2) {
    const e2 = this.options.ticks;
    let i2, s2, n2;
    for (i2 = 0, s2 = t2.length; i2 < s2; i2++) n2 = t2[i2], n2.label = Ig(e2.callback, [n2.value, i2, t2], this);
  }
  afterTickToLabelConversion() {
    Ig(this.options.afterTickToLabelConversion, [this]);
  }
  beforeCalculateLabelRotation() {
    Ig(this.options.beforeCalculateLabelRotation, [this]);
  }
  calculateLabelRotation() {
    const t2 = this.options, e2 = t2.ticks, i2 = wy(this.ticks.length, t2.ticks.maxTicksLimit), s2 = e2.minRotation || 0, n2 = e2.maxRotation;
    let r2, o2, a2, l2 = s2;
    if (!this._isVisible() || !e2.display || s2 >= n2 || i2 <= 1 || !this.isHorizontal()) return void (this.labelRotation = s2);
    const h2 = this._getLabelSizes(), c2 = h2.widest.width, u2 = h2.highest.height, d2 = wv(this.chart.width - c2, 0, this.maxWidth);
    r2 = t2.offset ? this.maxWidth / i2 : d2 / (i2 - 1), c2 + 6 > r2 && (r2 = d2 / (i2 - (t2.offset ? 0.5 : 1)), o2 = this.maxHeight - Sy(t2.grid) - e2.padding - My(t2.title, this.chart.options.font), a2 = Math.sqrt(c2 * c2 + u2 * u2), l2 = pv(Math.min(Math.asin(wv((h2.highest.height + 6) / r2, -1, 1)), Math.asin(wv(o2 / a2, -1, 1)) - Math.asin(wv(u2 / a2, -1, 1)))), l2 = Math.max(s2, Math.min(n2, l2))), this.labelRotation = l2;
  }
  afterCalculateLabelRotation() {
    Ig(this.options.afterCalculateLabelRotation, [this]);
  }
  afterAutoSkip() {
  }
  beforeFit() {
    Ig(this.options.beforeFit, [this]);
  }
  fit() {
    const t2 = { width: 0, height: 0 }, { chart: e2, options: { ticks: i2, title: s2, grid: n2 } } = this, r2 = this._isVisible(), o2 = this.isHorizontal();
    if (r2) {
      const r3 = My(s2, e2.options.font);
      if (o2 ? (t2.width = this.maxWidth, t2.height = Sy(n2) + r3) : (t2.height = this.maxHeight, t2.width = Sy(n2) + r3), i2.display && this.ticks.length) {
        const { first: e3, last: s3, widest: n3, highest: r4 } = this._getLabelSizes(), a2 = 2 * i2.padding, l2 = fv(this.labelRotation), h2 = Math.cos(l2), c2 = Math.sin(l2);
        if (o2) {
          const e4 = i2.mirror ? 0 : c2 * n3.width + h2 * r4.height;
          t2.height = Math.min(this.maxHeight, t2.height + e4 + a2);
        } else {
          const e4 = i2.mirror ? 0 : h2 * n3.width + c2 * r4.height;
          t2.width = Math.min(this.maxWidth, t2.width + e4 + a2);
        }
        this._calculatePadding(e3, s3, c2, h2);
      }
    }
    this._handleMargins(), o2 ? (this.width = this._length = e2.width - this._margins.left - this._margins.right, this.height = t2.height) : (this.width = t2.width, this.height = this._length = e2.height - this._margins.top - this._margins.bottom);
  }
  _calculatePadding(t2, e2, i2, s2) {
    const { ticks: { align: n2, padding: r2 }, position: o2 } = this.options, a2 = 0 !== this.labelRotation, l2 = "top" !== o2 && "x" === this.axis;
    if (this.isHorizontal()) {
      const o3 = this.getPixelForTick(0) - this.left, h2 = this.right - this.getPixelForTick(this.ticks.length - 1);
      let c2 = 0, u2 = 0;
      a2 ? l2 ? (c2 = s2 * t2.width, u2 = i2 * e2.height) : (c2 = i2 * t2.height, u2 = s2 * e2.width) : "start" === n2 ? u2 = e2.width : "end" === n2 ? c2 = t2.width : "inner" !== n2 && (c2 = t2.width / 2, u2 = e2.width / 2), this.paddingLeft = Math.max((c2 - o3 + r2) * this.width / (this.width - o3), 0), this.paddingRight = Math.max((u2 - h2 + r2) * this.width / (this.width - h2), 0);
    } else {
      let i3 = e2.height / 2, s3 = t2.height / 2;
      "start" === n2 ? (i3 = 0, s3 = t2.height) : "end" === n2 && (i3 = e2.height, s3 = 0), this.paddingTop = i3 + r2, this.paddingBottom = s3 + r2;
    }
  }
  _handleMargins() {
    this._margins && (this._margins.left = Math.max(this.paddingLeft, this._margins.left), this._margins.top = Math.max(this.paddingTop, this._margins.top), this._margins.right = Math.max(this.paddingRight, this._margins.right), this._margins.bottom = Math.max(this.paddingBottom, this._margins.bottom));
  }
  afterFit() {
    Ig(this.options.afterFit, [this]);
  }
  isHorizontal() {
    const { axis: t2, position: e2 } = this.options;
    return "top" === e2 || "bottom" === e2 || "x" === t2;
  }
  isFullSize() {
    return this.options.fullSize;
  }
  _convertTicksToLabels(t2) {
    let e2, i2;
    for (this.beforeTickToLabelConversion(), this.generateTickLabels(t2), e2 = 0, i2 = t2.length; e2 < i2; e2++) Tg(t2[e2].label) && (t2.splice(e2, 1), i2--, e2--);
    this.afterTickToLabelConversion();
  }
  _getLabelSizes() {
    let t2 = this._labelSizes;
    if (!t2) {
      const e2 = this.options.ticks.sampleSize;
      let i2 = this.ticks;
      e2 < i2.length && (i2 = xy(i2, e2)), this._labelSizes = t2 = this._computeLabelSizes(i2, i2.length, this.options.ticks.maxTicksLimit);
    }
    return t2;
  }
  _computeLabelSizes(t2, e2, i2) {
    const { ctx: s2, _longestTextCache: n2 } = this, r2 = [], o2 = [], a2 = Math.floor(e2 / wy(e2, i2));
    let l2, h2, c2, u2, d2, f2, p2, m2, g2, v2, b2, _2 = 0, y2 = 0;
    for (l2 = 0; l2 < e2; l2 += a2) {
      if (u2 = t2[l2].label, d2 = this._resolveTickFontOptions(l2), s2.font = f2 = d2.string, p2 = n2[f2] = n2[f2] || { data: {}, gc: [] }, m2 = d2.lineHeight, g2 = v2 = 0, Tg(u2) || $g(u2)) {
        if ($g(u2)) for (h2 = 0, c2 = u2.length; h2 < c2; ++h2) b2 = u2[h2], Tg(b2) || $g(b2) || (g2 = Zv(s2, p2.data, p2.gc, g2, b2), v2 += m2);
      } else g2 = Zv(s2, p2.data, p2.gc, g2, u2), v2 = m2;
      r2.push(g2), o2.push(v2), _2 = Math.max(g2, _2), y2 = Math.max(v2, y2);
    }
    !function(t3, e3) {
      Ng(t3, (t4) => {
        const i3 = t4.gc, s3 = i3.length / 2;
        let n3;
        if (s3 > e3) {
          for (n3 = 0; n3 < s3; ++n3) delete t4.data[i3[n3]];
          i3.splice(0, s3);
        }
      });
    }(n2, e2);
    const w2 = r2.indexOf(_2), x2 = o2.indexOf(y2), k2 = (t3) => ({ width: r2[t3] || 0, height: o2[t3] || 0 });
    return { first: k2(0), last: k2(e2 - 1), widest: k2(w2), highest: k2(x2), widths: r2, heights: o2 };
  }
  getLabelForValue(t2) {
    return t2;
  }
  getPixelForValue(t2, e2) {
    return NaN;
  }
  getValueForPixel(t2) {
  }
  getPixelForTick(t2) {
    const e2 = this.ticks;
    return t2 < 0 || t2 > e2.length - 1 ? null : this.getPixelForValue(e2[t2].value);
  }
  getPixelForDecimal(t2) {
    this._reversePixels && (t2 = 1 - t2);
    const e2 = this._startPixel + t2 * this._length;
    return wv(this._alignToPixels ? eb(this.chart, e2, 0) : e2, -32768, 32767);
  }
  getDecimalForPixel(t2) {
    const e2 = (t2 - this._startPixel) / this._length;
    return this._reversePixels ? 1 - e2 : e2;
  }
  getBasePixel() {
    return this.getPixelForValue(this.getBaseValue());
  }
  getBaseValue() {
    const { min: t2, max: e2 } = this;
    return t2 < 0 && e2 < 0 ? e2 : t2 > 0 && e2 > 0 ? t2 : 0;
  }
  getContext(t2) {
    const e2 = this.ticks || [];
    if (t2 >= 0 && t2 < e2.length) {
      const i2 = e2[t2];
      return i2.$context || (i2.$context = function(t3, e3, i3) {
        return Sb(t3, { tick: i3, index: e3, type: "tick" });
      }(this.getContext(), t2, i2));
    }
    return this.$context || (this.$context = Sb(this.chart.getContext(), { scale: this, type: "scale" }));
  }
  _tickSize() {
    const t2 = this.options.ticks, e2 = fv(this.labelRotation), i2 = Math.abs(Math.cos(e2)), s2 = Math.abs(Math.sin(e2)), n2 = this._getLabelSizes(), r2 = t2.autoSkipPadding || 0, o2 = n2 ? n2.widest.width + r2 : 0, a2 = n2 ? n2.highest.height + r2 : 0;
    return this.isHorizontal() ? a2 * i2 > o2 * s2 ? o2 / i2 : a2 / s2 : a2 * s2 < o2 * i2 ? a2 / i2 : o2 / s2;
  }
  _isVisible() {
    const t2 = this.options.display;
    return "auto" !== t2 ? !!t2 : this.getMatchingVisibleMetas().length > 0;
  }
  _computeGridLineItems(t2) {
    const e2 = this.axis, i2 = this.chart, s2 = this.options, { grid: n2, position: r2, border: o2 } = s2, a2 = n2.offset, l2 = this.isHorizontal(), h2 = this.ticks.length + (a2 ? 1 : 0), c2 = Sy(n2), u2 = [], d2 = o2.setContext(this.getContext()), f2 = d2.display ? d2.width : 0, p2 = f2 / 2, m2 = function(t3) {
      return eb(i2, t3, f2);
    };
    let g2, v2, b2, _2, y2, w2, x2, k2, S2, M2, z2, C2;
    if ("top" === r2) g2 = m2(this.bottom), w2 = this.bottom - c2, k2 = g2 - p2, M2 = m2(t2.top) + p2, C2 = t2.bottom;
    else if ("bottom" === r2) g2 = m2(this.top), M2 = t2.top, C2 = m2(t2.bottom) - p2, w2 = g2 + p2, k2 = this.top + c2;
    else if ("left" === r2) g2 = m2(this.right), y2 = this.right - c2, x2 = g2 - p2, S2 = m2(t2.left) + p2, z2 = t2.right;
    else if ("right" === r2) g2 = m2(this.left), S2 = t2.left, z2 = m2(t2.right) - p2, y2 = g2 + p2, x2 = this.left + c2;
    else if ("x" === e2) {
      if ("center" === r2) g2 = m2((t2.top + t2.bottom) / 2 + 0.5);
      else if (Eg(r2)) {
        const t3 = Object.keys(r2)[0], e3 = r2[t3];
        g2 = m2(this.chart.scales[t3].getPixelForValue(e3));
      }
      M2 = t2.top, C2 = t2.bottom, w2 = g2 + p2, k2 = w2 + c2;
    } else if ("y" === e2) {
      if ("center" === r2) g2 = m2((t2.left + t2.right) / 2);
      else if (Eg(r2)) {
        const t3 = Object.keys(r2)[0], e3 = r2[t3];
        g2 = m2(this.chart.scales[t3].getPixelForValue(e3));
      }
      y2 = g2 - p2, x2 = y2 - c2, S2 = t2.left, z2 = t2.right;
    }
    const R2 = Vg(s2.ticks.maxTicksLimit, h2), P2 = Math.max(1, Math.ceil(h2 / R2));
    for (v2 = 0; v2 < h2; v2 += P2) {
      const t3 = this.getContext(v2), e3 = n2.setContext(t3), s3 = o2.setContext(t3), r3 = e3.lineWidth, h3 = e3.color, c3 = s3.dash || [], d3 = s3.dashOffset, f3 = e3.tickWidth, p3 = e3.tickColor, m3 = e3.tickBorderDash || [], g3 = e3.tickBorderDashOffset;
      b2 = ky(this, v2, a2), void 0 !== b2 && (_2 = eb(i2, b2, r3), l2 ? y2 = x2 = S2 = z2 = _2 : w2 = k2 = M2 = C2 = _2, u2.push({ tx1: y2, ty1: w2, tx2: x2, ty2: k2, x1: S2, y1: M2, x2: z2, y2: C2, width: r3, color: h3, borderDash: c3, borderDashOffset: d3, tickWidth: f3, tickColor: p3, tickBorderDash: m3, tickBorderDashOffset: g3 }));
    }
    return this._ticksLength = h2, this._borderValue = g2, u2;
  }
  _computeLabelItems(t2) {
    const e2 = this.axis, i2 = this.options, { position: s2, ticks: n2 } = i2, r2 = this.isHorizontal(), o2 = this.ticks, { align: a2, crossAlign: l2, padding: h2, mirror: c2 } = n2, u2 = Sy(i2.grid), d2 = u2 + h2, f2 = c2 ? -h2 : d2, p2 = -fv(this.labelRotation), m2 = [];
    let g2, v2, b2, _2, y2, w2, x2, k2, S2, M2, z2, C2, R2 = "middle";
    if ("top" === s2) w2 = this.bottom - f2, x2 = this._getXAxisLabelAlignment();
    else if ("bottom" === s2) w2 = this.top + f2, x2 = this._getXAxisLabelAlignment();
    else if ("left" === s2) {
      const t3 = this._getYAxisLabelAlignment(u2);
      x2 = t3.textAlign, y2 = t3.x;
    } else if ("right" === s2) {
      const t3 = this._getYAxisLabelAlignment(u2);
      x2 = t3.textAlign, y2 = t3.x;
    } else if ("x" === e2) {
      if ("center" === s2) w2 = (t2.top + t2.bottom) / 2 + d2;
      else if (Eg(s2)) {
        const t3 = Object.keys(s2)[0], e3 = s2[t3];
        w2 = this.chart.scales[t3].getPixelForValue(e3) + d2;
      }
      x2 = this._getXAxisLabelAlignment();
    } else if ("y" === e2) {
      if ("center" === s2) y2 = (t2.left + t2.right) / 2 - d2;
      else if (Eg(s2)) {
        const t3 = Object.keys(s2)[0], e3 = s2[t3];
        y2 = this.chart.scales[t3].getPixelForValue(e3);
      }
      x2 = this._getYAxisLabelAlignment(u2).textAlign;
    }
    "y" === e2 && ("start" === a2 ? R2 = "top" : "end" === a2 && (R2 = "bottom"));
    const P2 = this._getLabelSizes();
    for (g2 = 0, v2 = o2.length; g2 < v2; ++g2) {
      b2 = o2[g2], _2 = b2.label;
      const t3 = n2.setContext(this.getContext(g2));
      k2 = this.getPixelForTick(g2) + n2.labelOffset, S2 = this._resolveTickFontOptions(g2), M2 = S2.lineHeight, z2 = $g(_2) ? _2.length : 1;
      const e3 = z2 / 2, i3 = t3.color, a3 = t3.textStrokeColor, h3 = t3.textStrokeWidth;
      let u3, d3 = x2;
      if (r2 ? (y2 = k2, "inner" === x2 && (d3 = g2 === v2 - 1 ? this.options.reverse ? "left" : "right" : 0 === g2 ? this.options.reverse ? "right" : "left" : "center"), C2 = "top" === s2 ? "near" === l2 || 0 !== p2 ? -z2 * M2 + M2 / 2 : "center" === l2 ? -P2.highest.height / 2 - e3 * M2 + M2 : -P2.highest.height + M2 / 2 : "near" === l2 || 0 !== p2 ? M2 / 2 : "center" === l2 ? P2.highest.height / 2 - e3 * M2 : P2.highest.height - z2 * M2, c2 && (C2 *= -1), 0 === p2 || t3.showLabelBackdrop || (y2 += M2 / 2 * Math.sin(p2))) : (w2 = k2, C2 = (1 - z2) * M2 / 2), t3.showLabelBackdrop) {
        const e4 = wb(t3.backdropPadding), i4 = P2.heights[g2], s3 = P2.widths[g2];
        let n3 = C2 - e4.top, r3 = 0 - e4.left;
        switch (R2) {
          case "middle":
            n3 -= i4 / 2;
            break;
          case "bottom":
            n3 -= i4;
        }
        switch (x2) {
          case "center":
            r3 -= s3 / 2;
            break;
          case "right":
            r3 -= s3;
            break;
          case "inner":
            g2 === v2 - 1 ? r3 -= s3 : g2 > 0 && (r3 -= s3 / 2);
        }
        u3 = { left: r3, top: n3, width: s3 + e4.width, height: i4 + e4.height, color: t3.backdropColor };
      }
      m2.push({ label: _2, font: S2, textOffset: C2, options: { rotation: p2, color: i3, strokeColor: a3, strokeWidth: h3, textAlign: d3, textBaseline: R2, translation: [y2, w2], backdrop: u3 } });
    }
    return m2;
  }
  _getXAxisLabelAlignment() {
    const { position: t2, ticks: e2 } = this.options;
    if (-fv(this.labelRotation)) return "top" === t2 ? "left" : "right";
    let i2 = "center";
    return "start" === e2.align ? i2 = "left" : "end" === e2.align ? i2 = "right" : "inner" === e2.align && (i2 = "inner"), i2;
  }
  _getYAxisLabelAlignment(t2) {
    const { position: e2, ticks: { crossAlign: i2, mirror: s2, padding: n2 } } = this.options, r2 = t2 + n2, o2 = this._getLabelSizes().widest.width;
    let a2, l2;
    return "left" === e2 ? s2 ? (l2 = this.right + n2, "near" === i2 ? a2 = "left" : "center" === i2 ? (a2 = "center", l2 += o2 / 2) : (a2 = "right", l2 += o2)) : (l2 = this.right - r2, "near" === i2 ? a2 = "right" : "center" === i2 ? (a2 = "center", l2 -= o2 / 2) : (a2 = "left", l2 = this.left)) : "right" === e2 ? s2 ? (l2 = this.left + n2, "near" === i2 ? a2 = "right" : "center" === i2 ? (a2 = "center", l2 -= o2 / 2) : (a2 = "left", l2 -= o2)) : (l2 = this.left + r2, "near" === i2 ? a2 = "left" : "center" === i2 ? (a2 = "center", l2 += o2 / 2) : (a2 = "right", l2 = this.right)) : a2 = "right", { textAlign: a2, x: l2 };
  }
  _computeLabelArea() {
    if (this.options.ticks.mirror) return;
    const t2 = this.chart, e2 = this.options.position;
    return "left" === e2 || "right" === e2 ? { top: 0, left: this.left, bottom: t2.height, right: this.right } : "top" === e2 || "bottom" === e2 ? { top: this.top, left: 0, bottom: this.bottom, right: t2.width } : void 0;
  }
  drawBackground() {
    const { ctx: t2, options: { backgroundColor: e2 }, left: i2, top: s2, width: n2, height: r2 } = this;
    e2 && (t2.save(), t2.fillStyle = e2, t2.fillRect(i2, s2, n2, r2), t2.restore());
  }
  getLineWidthForValue(t2) {
    const e2 = this.options.grid;
    if (!this._isVisible() || !e2.display) return 0;
    const i2 = this.ticks.findIndex((e3) => e3.value === t2);
    return i2 >= 0 ? e2.setContext(this.getContext(i2)).lineWidth : 0;
  }
  drawGrid(t2) {
    const e2 = this.options.grid, i2 = this.ctx, s2 = this._gridLineItems || (this._gridLineItems = this._computeGridLineItems(t2));
    let n2, r2;
    const o2 = (t3, e3, s3) => {
      s3.width && s3.color && (i2.save(), i2.lineWidth = s3.width, i2.strokeStyle = s3.color, i2.setLineDash(s3.borderDash || []), i2.lineDashOffset = s3.borderDashOffset, i2.beginPath(), i2.moveTo(t3.x, t3.y), i2.lineTo(e3.x, e3.y), i2.stroke(), i2.restore());
    };
    if (e2.display) for (n2 = 0, r2 = s2.length; n2 < r2; ++n2) {
      const t3 = s2[n2];
      e2.drawOnChartArea && o2({ x: t3.x1, y: t3.y1 }, { x: t3.x2, y: t3.y2 }, t3), e2.drawTicks && o2({ x: t3.tx1, y: t3.ty1 }, { x: t3.tx2, y: t3.ty2 }, { color: t3.tickColor, width: t3.tickWidth, borderDash: t3.tickBorderDash, borderDashOffset: t3.tickBorderDashOffset });
    }
  }
  drawBorder() {
    const { chart: t2, ctx: e2, options: { border: i2, grid: s2 } } = this, n2 = i2.setContext(this.getContext()), r2 = i2.display ? n2.width : 0;
    if (!r2) return;
    const o2 = s2.setContext(this.getContext(0)).lineWidth, a2 = this._borderValue;
    let l2, h2, c2, u2;
    this.isHorizontal() ? (l2 = eb(t2, this.left, r2) - r2 / 2, h2 = eb(t2, this.right, o2) + o2 / 2, c2 = u2 = a2) : (c2 = eb(t2, this.top, r2) - r2 / 2, u2 = eb(t2, this.bottom, o2) + o2 / 2, l2 = h2 = a2), e2.save(), e2.lineWidth = n2.width, e2.strokeStyle = n2.color, e2.beginPath(), e2.moveTo(l2, c2), e2.lineTo(h2, u2), e2.stroke(), e2.restore();
  }
  drawLabels(t2) {
    if (!this.options.ticks.display) return;
    const e2 = this.ctx, i2 = this._computeLabelArea();
    i2 && ob(e2, i2);
    const s2 = this.getLabelItems(t2);
    for (const t3 of s2) {
      const i3 = t3.options, s3 = t3.font;
      db(e2, t3.label, 0, t3.textOffset, s3, i3);
    }
    i2 && ab(e2);
  }
  drawTitle() {
    const { ctx: t2, options: { position: e2, title: i2, reverse: s2 } } = this;
    if (!i2.display) return;
    const n2 = xb(i2.font), r2 = wb(i2.padding), o2 = i2.align;
    let a2 = n2.lineHeight / 2;
    "bottom" === e2 || "center" === e2 || Eg(e2) ? (a2 += r2.bottom, $g(i2.text) && (a2 += n2.lineHeight * (i2.text.length - 1))) : a2 += r2.top;
    const { titleX: l2, titleY: h2, maxWidth: c2, rotation: u2 } = function(t3, e3, i3, s3) {
      const { top: n3, left: r3, bottom: o3, right: a3, chart: l3 } = t3, { chartArea: h3, scales: c3 } = l3;
      let u3, d2, f2, p2 = 0;
      const m2 = o3 - n3, g2 = a3 - r3;
      if (t3.isHorizontal()) {
        if (d2 = $v(s3, r3, a3), Eg(i3)) {
          const t4 = Object.keys(i3)[0], s4 = i3[t4];
          f2 = c3[t4].getPixelForValue(s4) + m2 - e3;
        } else f2 = "center" === i3 ? (h3.bottom + h3.top) / 2 + m2 - e3 : yy(t3, i3, e3);
        u3 = a3 - r3;
      } else {
        if (Eg(i3)) {
          const t4 = Object.keys(i3)[0], s4 = i3[t4];
          d2 = c3[t4].getPixelForValue(s4) - g2 + e3;
        } else d2 = "center" === i3 ? (h3.left + h3.right) / 2 - g2 + e3 : yy(t3, i3, e3);
        f2 = $v(s3, o3, n3), p2 = "left" === i3 ? -nv : nv;
      }
      return { titleX: d2, titleY: f2, maxWidth: u3, rotation: p2 };
    }(this, a2, e2, o2);
    db(t2, i2.text, 0, 0, n2, { color: i2.color, maxWidth: c2, rotation: u2, textAlign: zy(o2, e2, s2), textBaseline: "middle", translation: [l2, h2] });
  }
  draw(t2) {
    this._isVisible() && (this.drawBackground(), this.drawGrid(t2), this.drawBorder(), this.drawTitle(), this.drawLabels(t2));
  }
  _layers() {
    const t2 = this.options, e2 = t2.ticks && t2.ticks.z || 0, i2 = Vg(t2.grid && t2.grid.z, -1), s2 = Vg(t2.border && t2.border.z, 0);
    return this._isVisible() && this.draw === Scale.prototype.draw ? [{ z: i2, draw: (t3) => {
      this.drawBackground(), this.drawGrid(t3), this.drawTitle();
    } }, { z: s2, draw: () => {
      this.drawBorder();
    } }, { z: e2, draw: (t3) => {
      this.drawLabels(t3);
    } }] : [{ z: e2, draw: (t3) => {
      this.draw(t3);
    } }];
  }
  getMatchingVisibleMetas(t2) {
    const e2 = this.chart.getSortedVisibleDatasetMetas(), i2 = this.axis + "AxisID", s2 = [];
    let n2, r2;
    for (n2 = 0, r2 = e2.length; n2 < r2; ++n2) {
      const r3 = e2[n2];
      r3[i2] !== this.id || t2 && r3.type !== t2 || s2.push(r3);
    }
    return s2;
  }
  _resolveTickFontOptions(t2) {
    return xb(this.options.ticks.setContext(this.getContext(t2)).font);
  }
  _maxDigits() {
    const t2 = this._resolveTickFontOptions(0).lineHeight;
    return (this.isHorizontal() ? this.width : this.height) / t2;
  }
}
class TypedRegistry {
  constructor(t2, e2, i2) {
    this.type = t2, this.scope = e2, this.override = i2, this.items = /* @__PURE__ */ Object.create(null);
  }
  isForType(t2) {
    return Object.prototype.isPrototypeOf.call(this.type.prototype, t2.prototype);
  }
  register(t2) {
    const e2 = Object.getPrototypeOf(t2);
    let i2;
    (function(t3) {
      return "id" in t3 && "defaults" in t3;
    })(e2) && (i2 = this.register(e2));
    const s2 = this.items, n2 = t2.id, r2 = this.scope + "." + n2;
    if (!n2) throw new Error("class does not have id: " + t2);
    return n2 in s2 || (s2[n2] = t2, function(t3, e3, i3) {
      const s3 = qg(/* @__PURE__ */ Object.create(null), [i3 ? Qv.get(i3) : {}, Qv.get(e3), t3.defaults]);
      Qv.set(e3, s3), t3.defaultRoutes && function(t4, e4) {
        Object.keys(e4).forEach((i4) => {
          const s4 = i4.split("."), n3 = s4.pop(), r3 = [t4].concat(s4).join("."), o2 = e4[i4].split("."), a2 = o2.pop(), l2 = o2.join(".");
          Qv.route(r3, n3, l2, a2);
        });
      }(e3, t3.defaultRoutes), t3.descriptors && Qv.describe(e3, t3.descriptors);
    }(t2, r2, i2), this.override && Qv.override(t2.id, t2.overrides)), r2;
  }
  get(t2) {
    return this.items[t2];
  }
  unregister(t2) {
    const e2 = this.items, i2 = t2.id, s2 = this.scope;
    i2 in e2 && delete e2[i2], s2 && i2 in Qv[s2] && (delete Qv[s2][i2], this.override && delete Yv[i2]);
  }
}
class Registry {
  constructor() {
    this.controllers = new TypedRegistry(DatasetController, "datasets", true), this.elements = new TypedRegistry(by, "elements"), this.plugins = new TypedRegistry(Object, "plugins"), this.scales = new TypedRegistry(Scale, "scales"), this._typedRegistries = [this.controllers, this.scales, this.elements];
  }
  add(...t2) {
    this._each("register", t2);
  }
  remove(...t2) {
    this._each("unregister", t2);
  }
  addControllers(...t2) {
    this._each("register", t2, this.controllers);
  }
  addElements(...t2) {
    this._each("register", t2, this.elements);
  }
  addPlugins(...t2) {
    this._each("register", t2, this.plugins);
  }
  addScales(...t2) {
    this._each("register", t2, this.scales);
  }
  getController(t2) {
    return this._get(t2, this.controllers, "controller");
  }
  getElement(t2) {
    return this._get(t2, this.elements, "element");
  }
  getPlugin(t2) {
    return this._get(t2, this.plugins, "plugin");
  }
  getScale(t2) {
    return this._get(t2, this.scales, "scale");
  }
  removeControllers(...t2) {
    this._each("unregister", t2, this.controllers);
  }
  removeElements(...t2) {
    this._each("unregister", t2, this.elements);
  }
  removePlugins(...t2) {
    this._each("unregister", t2, this.plugins);
  }
  removeScales(...t2) {
    this._each("unregister", t2, this.scales);
  }
  _each(t2, e2, i2) {
    [...e2].forEach((e3) => {
      const s2 = i2 || this._getRegistryForType(e3);
      i2 || s2.isForType(e3) || s2 === this.plugins && e3.id ? this._exec(t2, s2, e3) : Ng(e3, (e4) => {
        const s3 = i2 || this._getRegistryForType(e4);
        this._exec(t2, s3, e4);
      });
    });
  }
  _exec(t2, e2, i2) {
    const s2 = Gg(t2);
    Ig(i2["before" + s2], [], i2), e2[t2](i2), Ig(i2["after" + s2], [], i2);
  }
  _getRegistryForType(t2) {
    for (let e2 = 0; e2 < this._typedRegistries.length; e2++) {
      const i2 = this._typedRegistries[e2];
      if (i2.isForType(t2)) return i2;
    }
    return this.plugins;
  }
  _get(t2, e2, i2) {
    const s2 = e2.get(t2);
    if (void 0 === s2) throw new Error('"' + t2 + '" is not a registered ' + i2 + ".");
    return s2;
  }
}
var Cy = new Registry();
class PluginService {
  constructor() {
    this._init = [];
  }
  notify(t2, e2, i2, s2) {
    "beforeInit" === e2 && (this._init = this._createDescriptors(t2, true), this._notify(this._init, t2, "install"));
    const n2 = s2 ? this._descriptors(t2).filter(s2) : this._descriptors(t2), r2 = this._notify(n2, t2, e2, i2);
    return "afterDestroy" === e2 && (this._notify(n2, t2, "stop"), this._notify(this._init, t2, "uninstall")), r2;
  }
  _notify(t2, e2, i2, s2) {
    s2 = s2 || {};
    for (const n2 of t2) {
      const t3 = n2.plugin;
      if (false === Ig(t3[i2], [e2, s2, n2.options], t3) && s2.cancelable) return false;
    }
    return true;
  }
  invalidate() {
    Tg(this._cache) || (this._oldCache = this._cache, this._cache = void 0);
  }
  _descriptors(t2) {
    if (this._cache) return this._cache;
    const e2 = this._cache = this._createDescriptors(t2);
    return this._notifyStateChanges(t2), e2;
  }
  _createDescriptors(t2, e2) {
    const i2 = t2 && t2.config, s2 = Vg(i2.options && i2.options.plugins, {}), n2 = function(t3) {
      const e3 = {}, i3 = [], s3 = Object.keys(Cy.plugins.items);
      for (let t4 = 0; t4 < s3.length; t4++) i3.push(Cy.getPlugin(s3[t4]));
      const n3 = t3.plugins || [];
      for (let t4 = 0; t4 < n3.length; t4++) {
        const s4 = n3[t4];
        -1 === i3.indexOf(s4) && (i3.push(s4), e3[s4.id] = true);
      }
      return { plugins: i3, localIds: e3 };
    }(i2);
    return false !== s2 || e2 ? function(t3, { plugins: e3, localIds: i3 }, s3, n3) {
      const r2 = [], o2 = t3.getContext();
      for (const a2 of e3) {
        const e4 = a2.id, l2 = Dy(s3[e4], n3);
        null !== l2 && r2.push({ plugin: a2, options: Ry(t3.config, { plugin: a2, local: i3[e4] }, l2, o2) });
      }
      return r2;
    }(t2, n2, s2, e2) : [];
  }
  _notifyStateChanges(t2) {
    const e2 = this._oldCache || [], i2 = this._cache, s2 = (t3, e3) => t3.filter((t4) => !e3.some((e4) => t4.plugin.id === e4.plugin.id));
    this._notify(s2(e2, i2), t2, "stop"), this._notify(s2(i2, e2), t2, "start");
  }
}
function Dy(t2, e2) {
  return e2 || false !== t2 ? true === t2 ? {} : t2 : null;
}
function Ry(t2, { plugin: e2, local: i2 }, s2, n2) {
  const r2 = t2.pluginScopeKeys(e2), o2 = t2.getOptionScopes(s2, r2);
  return i2 && e2.defaults && o2.push(e2.defaults), t2.createResolver(o2, n2, [""], { scriptable: false, indexable: false, allKeys: true });
}
function Py(t2, e2) {
  const i2 = Qv.datasets[t2] || {};
  return ((e2.datasets || {})[t2] || {}).indexAxis || e2.indexAxis || i2.indexAxis || "x";
}
function Ty(t2) {
  if ("x" === t2 || "y" === t2 || "r" === t2) return t2;
}
function $y(t2, ...e2) {
  if (Ty(t2)) return t2;
  for (const s2 of e2) {
    const e3 = s2.axis || ("top" === (i2 = s2.position) || "bottom" === i2 ? "x" : "left" === i2 || "right" === i2 ? "y" : void 0) || t2.length > 1 && Ty(t2[0].toLowerCase());
    if (e3) return e3;
  }
  var i2;
  throw new Error(`Cannot determine type of '${t2}' axis. Please provide 'axis' or 'position' option.`);
}
function Ey(t2, e2, i2) {
  if (i2[e2 + "AxisID"] === t2) return { axis: e2 };
}
function Ay(t2) {
  const e2 = t2.options || (t2.options = {});
  e2.plugins = Vg(e2.plugins, {}), e2.scales = function(t3, e3) {
    const i2 = Yv[t3.type] || { scales: {} }, s2 = e3.scales || {}, n2 = Py(t3.type, e3), r2 = /* @__PURE__ */ Object.create(null);
    return Object.keys(s2).forEach((e4) => {
      const o2 = s2[e4];
      if (!Eg(o2)) return;
      if (o2._proxy) return;
      const a2 = $y(e4, o2, function(t4, e5) {
        if (e5.data && e5.data.datasets) {
          const i3 = e5.data.datasets.filter((e6) => e6.xAxisID === t4 || e6.yAxisID === t4);
          if (i3.length) return Ey(t4, "x", i3[0]) || Ey(t4, "y", i3[0]);
        }
        return {};
      }(e4, t3), Qv.scales[o2.type]), l2 = /* @__PURE__ */ function(t4, e5) {
        return t4 === e5 ? "_index_" : "_value_";
      }(a2, n2), h2 = i2.scales || {};
      r2[e4] = Hg(/* @__PURE__ */ Object.create(null), [{ axis: a2 }, o2, h2[a2], h2[l2]]);
    }), t3.data.datasets.forEach((i3) => {
      const n3 = i3.type || t3.type, o2 = i3.indexAxis || Py(n3, e3), a2 = (Yv[n3] || {}).scales || {};
      Object.keys(a2).forEach((t4) => {
        const e4 = function(t5, e5) {
          let i4 = t5;
          return "_index_" === t5 ? i4 = e5 : "_value_" === t5 && (i4 = "x" === e5 ? "y" : "x"), i4;
        }(t4, o2), n4 = i3[e4 + "AxisID"] || e4;
        r2[n4] = r2[n4] || /* @__PURE__ */ Object.create(null), Hg(r2[n4], [{ axis: e4 }, s2[n4], a2[t4]]);
      });
    }), Object.keys(r2).forEach((t4) => {
      const e4 = r2[t4];
      Hg(e4, [Qv.scales[e4.type], Qv.scale]);
    }), r2;
  }(t2, e2);
}
function Ly(t2) {
  return (t2 = t2 || {}).datasets = t2.datasets || [], t2.labels = t2.labels || [], t2;
}
const Vy = /* @__PURE__ */ new Map(), Oy = /* @__PURE__ */ new Set();
function Iy(t2, e2) {
  let i2 = Vy.get(t2);
  return i2 || (i2 = e2(), Vy.set(t2, i2), Oy.add(i2)), i2;
}
const Ny = (t2, e2, i2) => {
  const s2 = Yg(e2, i2);
  void 0 !== s2 && t2.add(s2);
};
class Config {
  constructor(t2) {
    this._config = function(t3) {
      return (t3 = t3 || {}).data = Ly(t3.data), Ay(t3), t3;
    }(t2), this._scopeCache = /* @__PURE__ */ new Map(), this._resolverCache = /* @__PURE__ */ new Map();
  }
  get platform() {
    return this._config.platform;
  }
  get type() {
    return this._config.type;
  }
  set type(t2) {
    this._config.type = t2;
  }
  get data() {
    return this._config.data;
  }
  set data(t2) {
    this._config.data = Ly(t2);
  }
  get options() {
    return this._config.options;
  }
  set options(t2) {
    this._config.options = t2;
  }
  get plugins() {
    return this._config.plugins;
  }
  update() {
    const t2 = this._config;
    this.clearCache(), Ay(t2);
  }
  clearCache() {
    this._scopeCache.clear(), this._resolverCache.clear();
  }
  datasetScopeKeys(t2) {
    return Iy(t2, () => [[`datasets.${t2}`, ""]]);
  }
  datasetAnimationScopeKeys(t2, e2) {
    return Iy(`${t2}.transition.${e2}`, () => [[`datasets.${t2}.transitions.${e2}`, `transitions.${e2}`], [`datasets.${t2}`, ""]]);
  }
  datasetElementScopeKeys(t2, e2) {
    return Iy(`${t2}-${e2}`, () => [[`datasets.${t2}.elements.${e2}`, `datasets.${t2}`, `elements.${e2}`, ""]]);
  }
  pluginScopeKeys(t2) {
    const e2 = t2.id;
    return Iy(`${this.type}-plugin-${e2}`, () => [[`plugins.${e2}`, ...t2.additionalOptionScopes || []]]);
  }
  _cachedScopes(t2, e2) {
    const i2 = this._scopeCache;
    let s2 = i2.get(t2);
    return s2 && !e2 || (s2 = /* @__PURE__ */ new Map(), i2.set(t2, s2)), s2;
  }
  getOptionScopes(t2, e2, i2) {
    const { options: s2, type: n2 } = this, r2 = this._cachedScopes(t2, i2), o2 = r2.get(e2);
    if (o2) return o2;
    const a2 = /* @__PURE__ */ new Set();
    e2.forEach((e3) => {
      t2 && (a2.add(t2), e3.forEach((e4) => Ny(a2, t2, e4))), e3.forEach((t3) => Ny(a2, s2, t3)), e3.forEach((t3) => Ny(a2, Yv[n2] || {}, t3)), e3.forEach((t3) => Ny(a2, Qv, t3)), e3.forEach((t3) => Ny(a2, Gv, t3));
    });
    const l2 = Array.from(a2);
    return 0 === l2.length && l2.push(/* @__PURE__ */ Object.create(null)), Oy.has(e2) && r2.set(e2, l2), l2;
  }
  chartOptionScopes() {
    const { options: t2, type: e2 } = this;
    return [t2, Yv[e2] || {}, Qv.datasets[e2] || {}, { type: e2 }, Qv, Gv];
  }
  resolveNamedOptions(t2, e2, i2, s2 = [""]) {
    const n2 = { $shared: true }, { resolver: r2, subPrefixes: o2 } = Fy(this._resolverCache, t2, s2);
    let a2 = r2;
    (function(t3, e3) {
      const { isScriptable: i3, isIndexable: s3 } = Cb(t3);
      for (const n3 of e3) {
        const e4 = i3(n3), r3 = s3(n3), o3 = (r3 || e4) && t3[n3];
        if (e4 && (Jg(o3) || Wy(o3)) || r3 && $g(o3)) return true;
      }
      return false;
    })(r2, e2) && (n2.$shared = false, a2 = zb(r2, i2 = Jg(i2) ? i2() : i2, this.createResolver(t2, i2, o2)));
    for (const t3 of e2) n2[t3] = a2[t3];
    return n2;
  }
  createResolver(t2, e2, i2 = [""], s2) {
    const { resolver: n2 } = Fy(this._resolverCache, t2, i2);
    return Eg(e2) ? zb(n2, e2, void 0, s2) : n2;
  }
}
function Fy(t2, e2, i2) {
  let s2 = t2.get(e2);
  s2 || (s2 = /* @__PURE__ */ new Map(), t2.set(e2, s2));
  const n2 = i2.join();
  let r2 = s2.get(n2);
  return r2 || (r2 = { resolver: Mb(e2, i2), subPrefixes: i2.filter((t3) => !t3.toLowerCase().includes("hover")) }, s2.set(n2, r2)), r2;
}
const Wy = (t2) => Eg(t2) && Object.getOwnPropertyNames(t2).some((e2) => Jg(t2[e2])), By = ["top", "bottom", "left", "right", "chartArea"];
function jy(t2, e2) {
  return "top" === t2 || "bottom" === t2 || -1 === By.indexOf(t2) && "x" === e2;
}
function qy(t2, e2) {
  return function(i2, s2) {
    return i2[t2] === s2[t2] ? i2[e2] - s2[e2] : i2[t2] - s2[t2];
  };
}
function Hy(t2) {
  const e2 = t2.chart, i2 = e2.options.animation;
  e2.notifyPlugins("afterRender"), Ig(i2 && i2.onComplete, [t2], e2);
}
function Uy(t2) {
  const e2 = t2.chart, i2 = e2.options.animation;
  Ig(i2 && i2.onProgress, [t2], e2);
}
function Ky(t2) {
  return qb() && "string" == typeof t2 ? t2 = document.getElementById(t2) : t2 && t2.length && (t2 = t2[0]), t2 && t2.canvas && (t2 = t2.canvas), t2;
}
const Yy = {}, Gy = (t2) => {
  const e2 = Ky(t2);
  return Object.values(Yy).filter((t3) => t3.canvas === e2).pop();
};
function Xy(t2, e2, i2) {
  const s2 = Object.keys(t2);
  for (const n2 of s2) {
    const s3 = +n2;
    if (s3 >= e2) {
      const r2 = t2[n2];
      delete t2[n2], (i2 > 0 || s3 > e2) && (t2[s3 + i2] = r2);
    }
  }
}
class Chart {
  static register(...t2) {
    Cy.add(...t2), Jy();
  }
  static unregister(...t2) {
    Cy.remove(...t2), Jy();
  }
  constructor(t2, e2) {
    const i2 = this.config = new Config(e2), s2 = Ky(t2), n2 = Gy(s2);
    if (n2) throw new Error("Canvas is already in use. Chart with ID '" + n2.id + "' must be destroyed before the canvas with ID '" + n2.canvas.id + "' can be reused.");
    const r2 = i2.createResolver(i2.chartOptionScopes(), this.getContext());
    this.platform = new (i2.platform || function(t3) {
      return !qb() || "undefined" != typeof OffscreenCanvas && t3 instanceof OffscreenCanvas ? BasicPlatform : DomPlatform;
    }(s2))(), this.platform.updateConfig(i2);
    const o2 = this.platform.acquireContext(s2, r2.aspectRatio), a2 = o2 && o2.canvas, l2 = a2 && a2.height, h2 = a2 && a2.width;
    this.id = Pg(), this.ctx = o2, this.canvas = a2, this.width = h2, this.height = l2, this._options = r2, this._aspectRatio = this.aspectRatio, this._layers = [], this._metasets = [], this._stacks = void 0, this.boxes = [], this.currentDevicePixelRatio = void 0, this.chartArea = void 0, this._active = [], this._lastEvent = void 0, this._listeners = {}, this._responsiveListeners = void 0, this._sortedMetasets = [], this.scales = {}, this._plugins = new PluginService(), this.$proxies = {}, this._hiddenIndices = {}, this.attached = false, this._animationsDisabled = void 0, this.$context = void 0, this._doResize = /* @__PURE__ */ function(t3, e3) {
      let i3;
      return function(...s3) {
        return e3 ? (clearTimeout(i3), i3 = setTimeout(t3, e3, s3)) : t3.apply(this, s3), e3;
      };
    }((t3) => this.update(t3), r2.resizeDelay || 0), this._dataChanges = [], Yy[this.id] = this, o2 && a2 && (m_.listen(this, "complete", Hy), m_.listen(this, "progress", Uy), this._initialize(), this.attached && this.update());
  }
  get aspectRatio() {
    const { options: { aspectRatio: t2, maintainAspectRatio: e2 }, width: i2, height: s2, _aspectRatio: n2 } = this;
    return Tg(t2) ? e2 && n2 ? n2 : s2 ? i2 / s2 : null : t2;
  }
  get data() {
    return this.config.data;
  }
  set data(t2) {
    this.config.data = t2;
  }
  get options() {
    return this._options;
  }
  set options(t2) {
    this.config.options = t2;
  }
  get registry() {
    return Cy;
  }
  _initialize() {
    return this.notifyPlugins("beforeInit"), this.options.responsive ? this.resize() : Qb(this, this.options.devicePixelRatio), this.bindEvents(), this.notifyPlugins("afterInit"), this;
  }
  clear() {
    return ib(this.canvas, this.ctx), this;
  }
  stop() {
    return m_.stop(this), this;
  }
  resize(t2, e2) {
    m_.running(this) ? this._resizeBeforeDraw = { width: t2, height: e2 } : this._resize(t2, e2);
  }
  _resize(t2, e2) {
    const i2 = this.options, s2 = this.canvas, n2 = i2.maintainAspectRatio && this.aspectRatio, r2 = this.platform.getMaximumSize(s2, t2, e2, n2), o2 = i2.devicePixelRatio || this.platform.getDevicePixelRatio(), a2 = this.width ? "resize" : "attach";
    this.width = r2.width, this.height = r2.height, this._aspectRatio = this.aspectRatio, Qb(this, o2, true) && (this.notifyPlugins("resize", { size: r2 }), Ig(i2.onResize, [this, r2], this), this.attached && this._doResize(a2) && this.render());
  }
  ensureScalesHaveIDs() {
    Ng(this.options.scales || {}, (t2, e2) => {
      t2.id = e2;
    });
  }
  buildOrUpdateScales() {
    const t2 = this.options, e2 = t2.scales, i2 = this.scales, s2 = Object.keys(i2).reduce((t3, e3) => (t3[e3] = false, t3), {});
    let n2 = [];
    e2 && (n2 = n2.concat(Object.keys(e2).map((t3) => {
      const i3 = e2[t3], s3 = $y(t3, i3), n3 = "r" === s3, r2 = "x" === s3;
      return { options: i3, dposition: n3 ? "chartArea" : r2 ? "bottom" : "left", dtype: n3 ? "radialLinear" : r2 ? "category" : "linear" };
    }))), Ng(n2, (e3) => {
      const n3 = e3.options, r2 = n3.id, o2 = $y(r2, n3), a2 = Vg(n3.type, e3.dtype);
      void 0 !== n3.position && jy(n3.position, o2) === jy(e3.dposition) || (n3.position = e3.dposition), s2[r2] = true;
      let l2 = null;
      r2 in i2 && i2[r2].type === a2 ? l2 = i2[r2] : (l2 = new (Cy.getScale(a2))({ id: r2, type: a2, ctx: this.ctx, chart: this }), i2[l2.id] = l2), l2.init(n3, t2);
    }), Ng(s2, (t3, e3) => {
      t3 || delete i2[e3];
    }), Ng(i2, (t3) => {
      sy.configure(this, t3, t3.options), sy.addBox(this, t3);
    });
  }
  _updateMetasets() {
    const t2 = this._metasets, e2 = this.data.datasets.length, i2 = t2.length;
    if (t2.sort((t3, e3) => t3.index - e3.index), i2 > e2) {
      for (let t3 = e2; t3 < i2; ++t3) this._destroyDatasetMeta(t3);
      t2.splice(e2, i2 - e2);
    }
    this._sortedMetasets = t2.slice(0).sort(qy("order", "index"));
  }
  _removeUnreferencedMetasets() {
    const { _metasets: t2, data: { datasets: e2 } } = this;
    t2.length > e2.length && delete this._stacks, t2.forEach((t3, i2) => {
      0 === e2.filter((e3) => e3 === t3._dataset).length && this._destroyDatasetMeta(i2);
    });
  }
  buildOrUpdateControllers() {
    const t2 = [], e2 = this.data.datasets;
    let i2, s2;
    for (this._removeUnreferencedMetasets(), i2 = 0, s2 = e2.length; i2 < s2; i2++) {
      const s3 = e2[i2];
      let n2 = this.getDatasetMeta(i2);
      const r2 = s3.type || this.config.type;
      if (n2.type && n2.type !== r2 && (this._destroyDatasetMeta(i2), n2 = this.getDatasetMeta(i2)), n2.type = r2, n2.indexAxis = s3.indexAxis || Py(r2, this.options), n2.order = s3.order || 0, n2.index = i2, n2.label = "" + s3.label, n2.visible = this.isDatasetVisible(i2), n2.controller) n2.controller.updateIndex(i2), n2.controller.linkScales();
      else {
        const e3 = Cy.getController(r2), { datasetElementType: s4, dataElementType: o2 } = Qv.datasets[r2];
        Object.assign(e3, { dataElementType: Cy.getElement(o2), datasetElementType: s4 && Cy.getElement(s4) }), n2.controller = new e3(this, i2), t2.push(n2.controller);
      }
    }
    return this._updateMetasets(), t2;
  }
  _resetElements() {
    Ng(this.data.datasets, (t2, e2) => {
      this.getDatasetMeta(e2).controller.reset();
    }, this);
  }
  reset() {
    this._resetElements(), this.notifyPlugins("reset");
  }
  update(t2) {
    const e2 = this.config;
    e2.update();
    const i2 = this._options = e2.createResolver(e2.chartOptionScopes(), this.getContext()), s2 = this._animationsDisabled = !i2.animation;
    if (this._updateScales(), this._checkEventBindings(), this._updateHiddenIndices(), this._plugins.invalidate(), false === this.notifyPlugins("beforeUpdate", { mode: t2, cancelable: true })) return;
    const n2 = this.buildOrUpdateControllers();
    this.notifyPlugins("beforeElementsUpdate");
    let r2 = 0;
    for (let t3 = 0, e3 = this.data.datasets.length; t3 < e3; t3++) {
      const { controller: e4 } = this.getDatasetMeta(t3), i3 = !s2 && -1 === n2.indexOf(e4);
      e4.buildOrUpdateElements(i3), r2 = Math.max(+e4.getMaxOverflow(), r2);
    }
    r2 = this._minPadding = i2.layout.autoPadding ? r2 : 0, this._updateLayout(r2), s2 || Ng(n2, (t3) => {
      t3.reset();
    }), this._updateDatasets(t2), this.notifyPlugins("afterUpdate", { mode: t2 }), this._layers.sort(qy("z", "_idx"));
    const { _active: o2, _lastEvent: a2 } = this;
    a2 ? this._eventHandler(a2, true) : o2.length && this._updateHoverStyles(o2, o2, true), this.render();
  }
  _updateScales() {
    Ng(this.scales, (t2) => {
      sy.removeBox(this, t2);
    }), this.ensureScalesHaveIDs(), this.buildOrUpdateScales();
  }
  _checkEventBindings() {
    const t2 = this.options, e2 = new Set(Object.keys(this._listeners)), i2 = new Set(t2.events);
    Qg(e2, i2) && !!this._responsiveListeners === t2.responsive || (this.unbindEvents(), this.bindEvents());
  }
  _updateHiddenIndices() {
    const { _hiddenIndices: t2 } = this, e2 = this._getUniformDataChanges() || [];
    for (const { method: i2, start: s2, count: n2 } of e2) Xy(t2, s2, "_removeElements" === i2 ? -n2 : n2);
  }
  _getUniformDataChanges() {
    const t2 = this._dataChanges;
    if (!t2 || !t2.length) return;
    this._dataChanges = [];
    const e2 = this.data.datasets.length, i2 = (e3) => new Set(t2.filter((t3) => t3[0] === e3).map((t3, e4) => e4 + "," + t3.splice(1).join(","))), s2 = i2(0);
    for (let t3 = 1; t3 < e2; t3++) if (!Qg(s2, i2(t3))) return;
    return Array.from(s2).map((t3) => t3.split(",")).map((t3) => ({ method: t3[1], start: +t3[2], count: +t3[3] }));
  }
  _updateLayout(t2) {
    if (false === this.notifyPlugins("beforeLayout", { cancelable: true })) return;
    sy.update(this, this.width, this.height, t2);
    const e2 = this.chartArea, i2 = e2.width <= 0 || e2.height <= 0;
    this._layers = [], Ng(this.boxes, (t3) => {
      i2 && "chartArea" === t3.position || (t3.configure && t3.configure(), this._layers.push(...t3._layers()));
    }, this), this._layers.forEach((t3, e3) => {
      t3._idx = e3;
    }), this.notifyPlugins("afterLayout");
  }
  _updateDatasets(t2) {
    if (false !== this.notifyPlugins("beforeDatasetsUpdate", { mode: t2, cancelable: true })) {
      for (let t3 = 0, e2 = this.data.datasets.length; t3 < e2; ++t3) this.getDatasetMeta(t3).controller.configure();
      for (let e2 = 0, i2 = this.data.datasets.length; e2 < i2; ++e2) this._updateDataset(e2, Jg(t2) ? t2({ datasetIndex: e2 }) : t2);
      this.notifyPlugins("afterDatasetsUpdate", { mode: t2 });
    }
  }
  _updateDataset(t2, e2) {
    const i2 = this.getDatasetMeta(t2), s2 = { meta: i2, index: t2, mode: e2, cancelable: true };
    false !== this.notifyPlugins("beforeDatasetUpdate", s2) && (i2.controller._update(e2), s2.cancelable = false, this.notifyPlugins("afterDatasetUpdate", s2));
  }
  render() {
    false !== this.notifyPlugins("beforeRender", { cancelable: true }) && (m_.has(this) ? this.attached && !m_.running(this) && m_.start(this) : (this.draw(), Hy({ chart: this })));
  }
  draw() {
    let t2;
    if (this._resizeBeforeDraw) {
      const { width: t3, height: e3 } = this._resizeBeforeDraw;
      this._resizeBeforeDraw = null, this._resize(t3, e3);
    }
    if (this.clear(), this.width <= 0 || this.height <= 0) return;
    if (false === this.notifyPlugins("beforeDraw", { cancelable: true })) return;
    const e2 = this._layers;
    for (t2 = 0; t2 < e2.length && e2[t2].z <= 0; ++t2) e2[t2].draw(this.chartArea);
    for (this._drawDatasets(); t2 < e2.length; ++t2) e2[t2].draw(this.chartArea);
    this.notifyPlugins("afterDraw");
  }
  _getSortedDatasetMetas(t2) {
    const e2 = this._sortedMetasets, i2 = [];
    let s2, n2;
    for (s2 = 0, n2 = e2.length; s2 < n2; ++s2) {
      const n3 = e2[s2];
      t2 && !n3.visible || i2.push(n3);
    }
    return i2;
  }
  getSortedVisibleDatasetMetas() {
    return this._getSortedDatasetMetas(true);
  }
  _drawDatasets() {
    if (false === this.notifyPlugins("beforeDatasetsDraw", { cancelable: true })) return;
    const t2 = this.getSortedVisibleDatasetMetas();
    for (let e2 = t2.length - 1; e2 >= 0; --e2) this._drawDataset(t2[e2]);
    this.notifyPlugins("afterDatasetsDraw");
  }
  _drawDataset(t2) {
    const e2 = this.ctx, i2 = { meta: t2, index: t2.index, cancelable: true }, s2 = p_(this, t2);
    false !== this.notifyPlugins("beforeDatasetDraw", i2) && (s2 && ob(e2, s2), t2.controller.draw(), s2 && ab(e2), i2.cancelable = false, this.notifyPlugins("afterDatasetDraw", i2));
  }
  isPointInArea(t2) {
    return rb(t2, this.chartArea, this._minPadding);
  }
  getElementsAtEventForMode(t2, e2, i2, s2) {
    const n2 = H_.modes[e2];
    return "function" == typeof n2 ? n2(this, t2, i2, s2) : [];
  }
  getDatasetMeta(t2) {
    const e2 = this.data.datasets[t2], i2 = this._metasets;
    let s2 = i2.filter((t3) => t3 && t3._dataset === e2).pop();
    return s2 || (s2 = { type: null, data: [], dataset: null, controller: null, hidden: null, xAxisID: null, yAxisID: null, order: e2 && e2.order || 0, index: t2, _dataset: e2, _parsed: [], _sorted: false }, i2.push(s2)), s2;
  }
  getContext() {
    return this.$context || (this.$context = Sb(null, { chart: this, type: "chart" }));
  }
  getVisibleDatasetCount() {
    return this.getSortedVisibleDatasetMetas().length;
  }
  isDatasetVisible(t2) {
    const e2 = this.data.datasets[t2];
    if (!e2) return false;
    const i2 = this.getDatasetMeta(t2);
    return "boolean" == typeof i2.hidden ? !i2.hidden : !e2.hidden;
  }
  setDatasetVisibility(t2, e2) {
    this.getDatasetMeta(t2).hidden = !e2;
  }
  toggleDataVisibility(t2) {
    this._hiddenIndices[t2] = !this._hiddenIndices[t2];
  }
  getDataVisibility(t2) {
    return !this._hiddenIndices[t2];
  }
  _updateVisibility(t2, e2, i2) {
    const s2 = i2 ? "show" : "hide", n2 = this.getDatasetMeta(t2), r2 = n2.controller._resolveAnimations(void 0, s2);
    Xg(e2) ? (n2.data[e2].hidden = !i2, this.update()) : (this.setDatasetVisibility(t2, i2), r2.update(n2, { visible: i2 }), this.update((e3) => e3.datasetIndex === t2 ? s2 : void 0));
  }
  hide(t2, e2) {
    this._updateVisibility(t2, e2, false);
  }
  show(t2, e2) {
    this._updateVisibility(t2, e2, true);
  }
  _destroyDatasetMeta(t2) {
    const e2 = this._metasets[t2];
    e2 && e2.controller && e2.controller._destroy(), delete this._metasets[t2];
  }
  _stop() {
    let t2, e2;
    for (this.stop(), m_.remove(this), t2 = 0, e2 = this.data.datasets.length; t2 < e2; ++t2) this._destroyDatasetMeta(t2);
  }
  destroy() {
    this.notifyPlugins("beforeDestroy");
    const { canvas: t2, ctx: e2 } = this;
    this._stop(), this.config.clearCache(), t2 && (this.unbindEvents(), ib(t2, e2), this.platform.releaseContext(e2), this.canvas = null, this.ctx = null), delete Yy[this.id], this.notifyPlugins("afterDestroy");
  }
  toBase64Image(...t2) {
    return this.canvas.toDataURL(...t2);
  }
  bindEvents() {
    this.bindUserEvents(), this.options.responsive ? this.bindResponsiveEvents() : this.attached = true;
  }
  bindUserEvents() {
    const t2 = this._listeners, e2 = this.platform, i2 = (i3, s3) => {
      e2.addEventListener(this, i3, s3), t2[i3] = s3;
    }, s2 = (t3, e3, i3) => {
      t3.offsetX = e3, t3.offsetY = i3, this._eventHandler(t3);
    };
    Ng(this.options.events, (t3) => i2(t3, s2));
  }
  bindResponsiveEvents() {
    this._responsiveListeners || (this._responsiveListeners = {});
    const t2 = this._responsiveListeners, e2 = this.platform, i2 = (i3, s3) => {
      e2.addEventListener(this, i3, s3), t2[i3] = s3;
    }, s2 = (i3, s3) => {
      t2[i3] && (e2.removeEventListener(this, i3, s3), delete t2[i3]);
    }, n2 = (t3, e3) => {
      this.canvas && this.resize(t3, e3);
    };
    let r2;
    const o2 = () => {
      s2("attach", o2), this.attached = true, this.resize(), i2("resize", n2), i2("detach", r2);
    };
    r2 = () => {
      this.attached = false, s2("resize", n2), this._stop(), this._resize(0, 0), i2("attach", o2);
    }, e2.isAttached(this.canvas) ? o2() : r2();
  }
  unbindEvents() {
    Ng(this._listeners, (t2, e2) => {
      this.platform.removeEventListener(this, e2, t2);
    }), this._listeners = {}, Ng(this._responsiveListeners, (t2, e2) => {
      this.platform.removeEventListener(this, e2, t2);
    }), this._responsiveListeners = void 0;
  }
  updateHoverStyle(t2, e2, i2) {
    const s2 = i2 ? "set" : "remove";
    let n2, r2, o2, a2;
    for ("dataset" === e2 && (n2 = this.getDatasetMeta(t2[0].datasetIndex), n2.controller["_" + s2 + "DatasetHoverStyle"]()), o2 = 0, a2 = t2.length; o2 < a2; ++o2) {
      r2 = t2[o2];
      const e3 = r2 && this.getDatasetMeta(r2.datasetIndex).controller;
      e3 && e3[s2 + "HoverStyle"](r2.element, r2.datasetIndex, r2.index);
    }
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t2) {
    const e2 = this._active || [], i2 = t2.map(({ datasetIndex: t3, index: e3 }) => {
      const i3 = this.getDatasetMeta(t3);
      if (!i3) throw new Error("No dataset found at index " + t3);
      return { datasetIndex: t3, element: i3.data[e3], index: e3 };
    });
    !Fg(i2, e2) && (this._active = i2, this._lastEvent = null, this._updateHoverStyles(i2, e2));
  }
  notifyPlugins(t2, e2, i2) {
    return this._plugins.notify(this, t2, e2, i2);
  }
  isPluginEnabled(t2) {
    return 1 === this._plugins._cache.filter((e2) => e2.plugin.id === t2).length;
  }
  _updateHoverStyles(t2, e2, i2) {
    const s2 = this.options.hover, n2 = (t3, e3) => t3.filter((t4) => !e3.some((e4) => t4.datasetIndex === e4.datasetIndex && t4.index === e4.index)), r2 = n2(e2, t2), o2 = i2 ? t2 : n2(t2, e2);
    r2.length && this.updateHoverStyle(r2, s2.mode, false), o2.length && s2.mode && this.updateHoverStyle(o2, s2.mode, true);
  }
  _eventHandler(t2, e2) {
    const i2 = { event: t2, replay: e2, cancelable: true, inChartArea: this.isPointInArea(t2) }, s2 = (e3) => (e3.options.events || this.options.events).includes(t2.native.type);
    if (false === this.notifyPlugins("beforeEvent", i2, s2)) return;
    const n2 = this._handleEvent(t2, e2, i2.inChartArea);
    return i2.cancelable = false, this.notifyPlugins("afterEvent", i2, s2), (n2 || i2.changed) && this.render(), this;
  }
  _handleEvent(t2, e2, i2) {
    const { _active: s2 = [], options: n2 } = this, r2 = e2, o2 = this._getActiveElements(t2, s2, i2, r2), a2 = function(t3) {
      return "mouseup" === t3.type || "click" === t3.type || "contextmenu" === t3.type;
    }(t2), l2 = function(t3, e3, i3, s3) {
      return i3 && "mouseout" !== t3.type ? s3 ? e3 : t3 : null;
    }(t2, this._lastEvent, i2, a2);
    i2 && (this._lastEvent = null, Ig(n2.onHover, [t2, o2, this], this), a2 && Ig(n2.onClick, [t2, o2, this], this));
    const h2 = !Fg(o2, s2);
    return (h2 || e2) && (this._active = o2, this._updateHoverStyles(o2, s2, e2)), this._lastEvent = l2, h2;
  }
  _getActiveElements(t2, e2, i2, s2) {
    if ("mouseout" === t2.type) return [];
    if (!i2) return e2;
    const n2 = this.options.hover;
    return this.getElementsAtEventForMode(t2, n2.mode, n2, s2);
  }
}
__publicField(Chart, "defaults", Qv);
__publicField(Chart, "instances", Yy);
__publicField(Chart, "overrides", Yv);
__publicField(Chart, "registry", Cy);
__publicField(Chart, "version", "4.4.9");
__publicField(Chart, "getChart", Gy);
function Jy() {
  return Ng(Chart.instances, (t2) => t2._plugins.invalidate());
}
function Qy(t2, e2, i2, s2) {
  return { x: i2 + t2 * Math.cos(e2), y: s2 + t2 * Math.sin(e2) };
}
function Zy(t2, e2, i2, s2, n2, r2) {
  const { x: o2, y: a2, startAngle: l2, pixelMargin: h2, innerRadius: c2 } = e2, u2 = Math.max(e2.outerRadius + s2 + i2 - h2, 0), d2 = c2 > 0 ? c2 + s2 + i2 + h2 : 0;
  let f2 = 0;
  const p2 = n2 - l2;
  if (s2) {
    const t3 = ((c2 > 0 ? c2 - s2 : 0) + (u2 > 0 ? u2 - s2 : 0)) / 2;
    f2 = (p2 - (0 !== t3 ? p2 * t3 / (t3 + s2) : p2)) / 2;
  }
  const m2 = (p2 - Math.max(1e-3, p2 * u2 - i2 / Zg) / u2) / 2, g2 = l2 + m2 + f2, v2 = n2 - m2 - f2, { outerStart: b2, outerEnd: _2, innerStart: y2, innerEnd: w2 } = function(t3, e3, i3, s3) {
    const n3 = bb(t3.options.borderRadius, ["outerStart", "outerEnd", "innerStart", "innerEnd"]), r3 = (i3 - e3) / 2, o3 = Math.min(r3, s3 * e3 / 2), a3 = (t4) => {
      const e4 = (i3 - Math.min(r3, t4)) * s3 / 2;
      return wv(t4, 0, Math.min(r3, e4));
    };
    return { outerStart: a3(n3.outerStart), outerEnd: a3(n3.outerEnd), innerStart: wv(n3.innerStart, 0, o3), innerEnd: wv(n3.innerEnd, 0, o3) };
  }(e2, d2, u2, v2 - g2), x2 = u2 - b2, k2 = u2 - _2, S2 = g2 + b2 / x2, M2 = v2 - _2 / k2, z2 = d2 + y2, C2 = d2 + w2, R2 = g2 + y2 / z2, P2 = v2 - w2 / C2;
  if (t2.beginPath(), r2) {
    const e3 = (S2 + M2) / 2;
    if (t2.arc(o2, a2, u2, S2, e3), t2.arc(o2, a2, u2, e3, M2), _2 > 0) {
      const e4 = Qy(k2, M2, o2, a2);
      t2.arc(e4.x, e4.y, _2, M2, v2 + nv);
    }
    const i3 = Qy(C2, v2, o2, a2);
    if (t2.lineTo(i3.x, i3.y), w2 > 0) {
      const e4 = Qy(C2, P2, o2, a2);
      t2.arc(e4.x, e4.y, w2, v2 + nv, P2 + Math.PI);
    }
    const s3 = (v2 - w2 / d2 + (g2 + y2 / d2)) / 2;
    if (t2.arc(o2, a2, d2, v2 - w2 / d2, s3, true), t2.arc(o2, a2, d2, s3, g2 + y2 / d2, true), y2 > 0) {
      const e4 = Qy(z2, R2, o2, a2);
      t2.arc(e4.x, e4.y, y2, R2 + Math.PI, g2 - nv);
    }
    const n3 = Qy(x2, g2, o2, a2);
    if (t2.lineTo(n3.x, n3.y), b2 > 0) {
      const e4 = Qy(x2, S2, o2, a2);
      t2.arc(e4.x, e4.y, b2, g2 - nv, S2);
    }
  } else {
    t2.moveTo(o2, a2);
    const e3 = Math.cos(S2) * u2 + o2, i3 = Math.sin(S2) * u2 + a2;
    t2.lineTo(e3, i3);
    const s3 = Math.cos(M2) * u2 + o2, n3 = Math.sin(M2) * u2 + a2;
    t2.lineTo(s3, n3);
  }
  t2.closePath();
}
class ArcElement extends by {
  constructor(t2) {
    super();
    __publicField(this, "circumference");
    __publicField(this, "endAngle");
    __publicField(this, "fullCircles");
    __publicField(this, "innerRadius");
    __publicField(this, "outerRadius");
    __publicField(this, "pixelMargin");
    __publicField(this, "startAngle");
    this.options = void 0, this.circumference = void 0, this.startAngle = void 0, this.endAngle = void 0, this.innerRadius = void 0, this.outerRadius = void 0, this.pixelMargin = 0, this.fullCircles = 0, t2 && Object.assign(this, t2);
  }
  inRange(t2, e2, i2) {
    const s2 = this.getProps(["x", "y"], i2), { angle: n2, distance: r2 } = gv(s2, { x: t2, y: e2 }), { startAngle: o2, endAngle: a2, innerRadius: l2, outerRadius: h2, circumference: c2 } = this.getProps(["startAngle", "endAngle", "innerRadius", "outerRadius", "circumference"], i2), u2 = (this.options.spacing + this.options.borderWidth) / 2, d2 = Vg(c2, a2 - o2), f2 = yv(n2, o2, a2) && o2 !== a2, p2 = d2 >= tv || f2, m2 = xv(r2, l2 + u2, h2 + u2);
    return p2 && m2;
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2, startAngle: s2, endAngle: n2, innerRadius: r2, outerRadius: o2 } = this.getProps(["x", "y", "startAngle", "endAngle", "innerRadius", "outerRadius"], t2), { offset: a2, spacing: l2 } = this.options, h2 = (s2 + n2) / 2, c2 = (r2 + o2 + l2 + a2) / 2;
    return { x: e2 + Math.cos(h2) * c2, y: i2 + Math.sin(h2) * c2 };
  }
  tooltipPosition(t2) {
    return this.getCenterPoint(t2);
  }
  draw(t2) {
    const { options: e2, circumference: i2 } = this, s2 = (e2.offset || 0) / 4, n2 = (e2.spacing || 0) / 2, r2 = e2.circular;
    if (this.pixelMargin = "inner" === e2.borderAlign ? 0.33 : 0, this.fullCircles = i2 > tv ? Math.floor(i2 / tv) : 0, 0 === i2 || this.innerRadius < 0 || this.outerRadius < 0) return;
    t2.save();
    const o2 = (this.startAngle + this.endAngle) / 2;
    t2.translate(Math.cos(o2) * s2, Math.sin(o2) * s2);
    const a2 = s2 * (1 - Math.sin(Math.min(Zg, i2 || 0)));
    t2.fillStyle = e2.backgroundColor, t2.strokeStyle = e2.borderColor, function(t3, e3, i3, s3, n3) {
      const { fullCircles: r3, startAngle: o3, circumference: a3 } = e3;
      let l2 = e3.endAngle;
      if (r3) {
        Zy(t3, e3, i3, s3, l2, n3);
        for (let e4 = 0; e4 < r3; ++e4) t3.fill();
        isNaN(a3) || (l2 = o3 + (a3 % tv || tv));
      }
      Zy(t3, e3, i3, s3, l2, n3), t3.fill();
    }(t2, this, a2, n2, r2), function(t3, e3, i3, s3, n3) {
      const { fullCircles: r3, startAngle: o3, circumference: a3, options: l2 } = e3, { borderWidth: h2, borderJoinStyle: c2, borderDash: u2, borderDashOffset: d2 } = l2, f2 = "inner" === l2.borderAlign;
      if (!h2) return;
      t3.setLineDash(u2 || []), t3.lineDashOffset = d2, f2 ? (t3.lineWidth = 2 * h2, t3.lineJoin = c2 || "round") : (t3.lineWidth = h2, t3.lineJoin = c2 || "bevel");
      let p2 = e3.endAngle;
      if (r3) {
        Zy(t3, e3, i3, s3, p2, n3);
        for (let e4 = 0; e4 < r3; ++e4) t3.stroke();
        isNaN(a3) || (p2 = o3 + (a3 % tv || tv));
      }
      f2 && function(t4, e4, i4) {
        const { startAngle: s4, pixelMargin: n4, x: r4, y: o4, outerRadius: a4, innerRadius: l3 } = e4;
        let h3 = n4 / a4;
        t4.beginPath(), t4.arc(r4, o4, a4, s4 - h3, i4 + h3), l3 > n4 ? (h3 = n4 / l3, t4.arc(r4, o4, l3, i4 + h3, s4 - h3, true)) : t4.arc(r4, o4, n4, i4 + nv, s4 - nv), t4.closePath(), t4.clip();
      }(t3, e3, p2), r3 || (Zy(t3, e3, i3, s3, p2, n3), t3.stroke());
    }(t2, this, a2, n2, r2), t2.restore();
  }
}
__publicField(ArcElement, "id", "arc");
__publicField(ArcElement, "defaults", { borderAlign: "center", borderColor: "#fff", borderDash: [], borderDashOffset: 0, borderJoinStyle: void 0, borderRadius: 0, borderWidth: 2, offset: 0, spacing: 0, angle: void 0, circular: true });
__publicField(ArcElement, "defaultRoutes", { backgroundColor: "backgroundColor" });
__publicField(ArcElement, "descriptors", { _scriptable: true, _indexable: (t2) => "borderDash" !== t2 });
function tw(t2, e2, i2 = e2) {
  t2.lineCap = Vg(i2.borderCapStyle, e2.borderCapStyle), t2.setLineDash(Vg(i2.borderDash, e2.borderDash)), t2.lineDashOffset = Vg(i2.borderDashOffset, e2.borderDashOffset), t2.lineJoin = Vg(i2.borderJoinStyle, e2.borderJoinStyle), t2.lineWidth = Vg(i2.borderWidth, e2.borderWidth), t2.strokeStyle = Vg(i2.borderColor, e2.borderColor);
}
function ew(t2, e2, i2) {
  t2.lineTo(i2.x, i2.y);
}
function iw(t2, e2, i2 = {}) {
  const s2 = t2.length, { start: n2 = 0, end: r2 = s2 - 1 } = i2, { start: o2, end: a2 } = e2, l2 = Math.max(n2, o2), h2 = Math.min(r2, a2), c2 = n2 < o2 && r2 < o2 || n2 > a2 && r2 > a2;
  return { count: s2, start: l2, loop: e2.loop, ilen: h2 < l2 && !c2 ? s2 + h2 - l2 : h2 - l2 };
}
function sw(t2, e2, i2, s2) {
  const { points: n2, options: r2 } = e2, { count: o2, start: a2, loop: l2, ilen: h2 } = iw(n2, i2, s2), c2 = function(t3) {
    return t3.stepped ? lb : t3.tension || "monotone" === t3.cubicInterpolationMode ? hb : ew;
  }(r2);
  let u2, d2, f2, { move: p2 = true, reverse: m2 } = s2 || {};
  for (u2 = 0; u2 <= h2; ++u2) d2 = n2[(a2 + (m2 ? h2 - u2 : u2)) % o2], d2.skip || (p2 ? (t2.moveTo(d2.x, d2.y), p2 = false) : c2(t2, f2, d2, m2, r2.stepped), f2 = d2);
  return l2 && (d2 = n2[(a2 + (m2 ? h2 : 0)) % o2], c2(t2, f2, d2, m2, r2.stepped)), !!l2;
}
function nw(t2, e2, i2, s2) {
  const n2 = e2.points, { count: r2, start: o2, ilen: a2 } = iw(n2, i2, s2), { move: l2 = true, reverse: h2 } = s2 || {};
  let c2, u2, d2, f2, p2, m2, g2 = 0, v2 = 0;
  const b2 = (t3) => (o2 + (h2 ? a2 - t3 : t3)) % r2, _2 = () => {
    f2 !== p2 && (t2.lineTo(g2, p2), t2.lineTo(g2, f2), t2.lineTo(g2, m2));
  };
  for (l2 && (u2 = n2[b2(0)], t2.moveTo(u2.x, u2.y)), c2 = 0; c2 <= a2; ++c2) {
    if (u2 = n2[b2(c2)], u2.skip) continue;
    const e3 = u2.x, i3 = u2.y, s3 = 0 | e3;
    s3 === d2 ? (i3 < f2 ? f2 = i3 : i3 > p2 && (p2 = i3), g2 = (v2 * g2 + e3) / ++v2) : (_2(), t2.lineTo(e3, i3), d2 = s3, v2 = 0, f2 = p2 = i3), m2 = i3;
  }
  _2();
}
function rw(t2) {
  const e2 = t2.options, i2 = e2.borderDash && e2.borderDash.length;
  return t2._decimated || t2._loop || e2.tension || "monotone" === e2.cubicInterpolationMode || e2.stepped || i2 ? sw : nw;
}
const ow = "function" == typeof Path2D;
class LineElement extends by {
  constructor(t2) {
    super(), this.animated = true, this.options = void 0, this._chart = void 0, this._loop = void 0, this._fullLoop = void 0, this._path = void 0, this._points = void 0, this._segments = void 0, this._decimated = false, this._pointsUpdated = false, this._datasetIndex = void 0, t2 && Object.assign(this, t2);
  }
  updateControlPoints(t2, e2) {
    const i2 = this.options;
    if ((i2.tension || "monotone" === i2.cubicInterpolationMode) && !i2.stepped && !this._pointsUpdated) {
      const s2 = i2.spanGaps ? this._loop : this._fullLoop;
      (function(t3, e3, i3, s3, n2) {
        let r2, o2, a2, l2;
        if (e3.spanGaps && (t3 = t3.filter((t4) => !t4.skip)), "monotone" === e3.cubicInterpolationMode) !function(t4, e4 = "x") {
          const i4 = Wb(e4), s4 = t4.length, n3 = Array(s4).fill(0), r3 = Array(s4);
          let o3, a3, l3, h2 = Fb(t4, 0);
          for (o3 = 0; o3 < s4; ++o3) if (a3 = l3, l3 = h2, h2 = Fb(t4, o3 + 1), l3) {
            if (h2) {
              const t5 = h2[e4] - l3[e4];
              n3[o3] = 0 !== t5 ? (h2[i4] - l3[i4]) / t5 : 0;
            }
            r3[o3] = a3 ? h2 ? lv(n3[o3 - 1]) !== lv(n3[o3]) ? 0 : (n3[o3 - 1] + n3[o3]) / 2 : n3[o3 - 1] : n3[o3];
          }
          !function(t5, e5, i5) {
            const s5 = t5.length;
            let n4, r4, o4, a4, l4, h3 = Fb(t5, 0);
            for (let c2 = 0; c2 < s5 - 1; ++c2) l4 = h3, h3 = Fb(t5, c2 + 1), l4 && h3 && (hv(e5[c2], 0, Nb) ? i5[c2] = i5[c2 + 1] = 0 : (n4 = i5[c2] / e5[c2], r4 = i5[c2 + 1] / e5[c2], a4 = Math.pow(n4, 2) + Math.pow(r4, 2), a4 <= 9 || (o4 = 3 / Math.sqrt(a4), i5[c2] = n4 * o4 * e5[c2], i5[c2 + 1] = r4 * o4 * e5[c2])));
          }(t4, n3, r3), function(t5, e5, i5 = "x") {
            const s5 = Wb(i5), n4 = t5.length;
            let r4, o4, a4, l4 = Fb(t5, 0);
            for (let h3 = 0; h3 < n4; ++h3) {
              if (o4 = a4, a4 = l4, l4 = Fb(t5, h3 + 1), !a4) continue;
              const n5 = a4[i5], c2 = a4[s5];
              o4 && (r4 = (n5 - o4[i5]) / 3, a4[`cp1${i5}`] = n5 - r4, a4[`cp1${s5}`] = c2 - r4 * e5[h3]), l4 && (r4 = (l4[i5] - n5) / 3, a4[`cp2${i5}`] = n5 + r4, a4[`cp2${s5}`] = c2 + r4 * e5[h3]);
            }
          }(t4, r3, e4);
        }(t3, n2);
        else {
          let i4 = s3 ? t3[t3.length - 1] : t3[0];
          for (r2 = 0, o2 = t3.length; r2 < o2; ++r2) a2 = t3[r2], l2 = Bb(i4, a2, t3[Math.min(r2 + 1, o2 - (s3 ? 0 : 1)) % o2], e3.tension), a2.cp1x = l2.previous.x, a2.cp1y = l2.previous.y, a2.cp2x = l2.next.x, a2.cp2y = l2.next.y, i4 = a2;
        }
        e3.capBezierPoints && function(t4, e4) {
          let i4, s4, n3, r3, o3, a3 = rb(t4[0], e4);
          for (i4 = 0, s4 = t4.length; i4 < s4; ++i4) o3 = r3, r3 = a3, a3 = i4 < s4 - 1 && rb(t4[i4 + 1], e4), r3 && (n3 = t4[i4], o3 && (n3.cp1x = jb(n3.cp1x, e4.left, e4.right), n3.cp1y = jb(n3.cp1y, e4.top, e4.bottom)), a3 && (n3.cp2x = jb(n3.cp2x, e4.left, e4.right), n3.cp2y = jb(n3.cp2y, e4.top, e4.bottom)));
        }(t3, i3);
      })(this._points, i2, t2, s2, e2), this._pointsUpdated = true;
    }
  }
  set points(t2) {
    this._points = t2, delete this._segments, delete this._path, this._pointsUpdated = false;
  }
  get points() {
    return this._points;
  }
  get segments() {
    return this._segments || (this._segments = function(t2, e2) {
      const i2 = t2.points, s2 = t2.options.spanGaps, n2 = i2.length;
      if (!n2) return [];
      const r2 = !!t2._loop, { start: o2, end: a2 } = function(t3, e3, i3, s3) {
        let n3 = 0, r3 = e3 - 1;
        if (i3 && !s3) for (; n3 < e3 && !t3[n3].skip; ) n3++;
        for (; n3 < e3 && t3[n3].skip; ) n3++;
        for (n3 %= e3, i3 && (r3 += n3); r3 > n3 && t3[r3 % e3].skip; ) r3--;
        return r3 %= e3, { start: n3, end: r3 };
      }(i2, n2, r2, s2);
      return function(t3, e3, i3, s3) {
        return s3 && s3.setContext && i3 ? function(t4, e4, i4, s4) {
          const n3 = t4._chart.getContext(), r3 = u_(t4.options), { _datasetIndex: o3, options: { spanGaps: a3 } } = t4, l2 = i4.length, h2 = [];
          let c2 = r3, u2 = e4[0].start, d2 = u2;
          function f2(t5, e5, s5, n4) {
            const r4 = a3 ? -1 : 1;
            if (t5 !== e5) {
              for (t5 += l2; i4[t5 % l2].skip; ) t5 -= r4;
              for (; i4[e5 % l2].skip; ) e5 += r4;
              t5 % l2 !== e5 % l2 && (h2.push({ start: t5 % l2, end: e5 % l2, loop: s5, style: n4 }), c2 = n4, u2 = e5 % l2);
            }
          }
          for (const t5 of e4) {
            u2 = a3 ? u2 : t5.start;
            let e5, r4 = i4[u2 % l2];
            for (d2 = u2 + 1; d2 <= t5.end; d2++) {
              const a4 = i4[d2 % l2];
              e5 = u_(s4.setContext(Sb(n3, { type: "segment", p0: r4, p1: a4, p0DataIndex: (d2 - 1) % l2, p1DataIndex: d2 % l2, datasetIndex: o3 }))), d_(e5, c2) && f2(u2, d2 - 1, t5.loop, c2), r4 = a4, c2 = e5;
            }
            u2 < d2 - 1 && f2(u2, d2 - 1, t5.loop, c2);
          }
          return h2;
        }(t3, e3, i3, s3) : e3;
      }(t2, true === s2 ? [{ start: o2, end: a2, loop: r2 }] : function(t3, e3, i3, s3) {
        const n3 = t3.length, r3 = [];
        let o3, a3 = e3, l2 = t3[e3];
        for (o3 = e3 + 1; o3 <= i3; ++o3) {
          const i4 = t3[o3 % n3];
          i4.skip || i4.stop ? l2.skip || (s3 = false, r3.push({ start: e3 % n3, end: (o3 - 1) % n3, loop: s3 }), e3 = a3 = i4.stop ? o3 : null) : (a3 = o3, l2.skip && (e3 = o3)), l2 = i4;
        }
        return null !== a3 && r3.push({ start: e3 % n3, end: a3 % n3, loop: s3 }), r3;
      }(i2, o2, a2 < o2 ? a2 + n2 : a2, !!t2._fullLoop && 0 === o2 && a2 === n2 - 1), i2, e2);
    }(this, this.options.segment));
  }
  first() {
    const t2 = this.segments, e2 = this.points;
    return t2.length && e2[t2[0].start];
  }
  last() {
    const t2 = this.segments, e2 = this.points, i2 = t2.length;
    return i2 && e2[t2[i2 - 1].end];
  }
  interpolate(t2, e2) {
    const i2 = this.options, s2 = t2[e2], n2 = this.points, r2 = c_(this, { property: e2, start: s2, end: s2 });
    if (!r2.length) return;
    const o2 = [], a2 = function(t3) {
      return t3.stepped ? i_ : t3.tension || "monotone" === t3.cubicInterpolationMode ? s_ : e_;
    }(i2);
    let l2, h2;
    for (l2 = 0, h2 = r2.length; l2 < h2; ++l2) {
      const { start: h3, end: c2 } = r2[l2], u2 = n2[h3], d2 = n2[c2];
      if (u2 === d2) {
        o2.push(u2);
        continue;
      }
      const f2 = a2(u2, d2, Math.abs((s2 - u2[e2]) / (d2[e2] - u2[e2])), i2.stepped);
      f2[e2] = t2[e2], o2.push(f2);
    }
    return 1 === o2.length ? o2[0] : o2;
  }
  pathSegment(t2, e2, i2) {
    return rw(this)(t2, this, e2, i2);
  }
  path(t2, e2, i2) {
    const s2 = this.segments, n2 = rw(this);
    let r2 = this._loop;
    e2 = e2 || 0, i2 = i2 || this.points.length - e2;
    for (const o2 of s2) r2 &= n2(t2, this, o2, { start: e2, end: e2 + i2 - 1 });
    return !!r2;
  }
  draw(t2, e2, i2, s2) {
    const n2 = this.options || {};
    (this.points || []).length && n2.borderWidth && (t2.save(), function(t3, e3, i3, s3) {
      ow && !e3.options.segment ? function(t4, e4, i4, s4) {
        let n3 = e4._path;
        n3 || (n3 = e4._path = new Path2D(), e4.path(n3, i4, s4) && n3.closePath()), tw(t4, e4.options), t4.stroke(n3);
      }(t3, e3, i3, s3) : function(t4, e4, i4, s4) {
        const { segments: n3, options: r2 } = e4, o2 = rw(e4);
        for (const a2 of n3) tw(t4, r2, a2.style), t4.beginPath(), o2(t4, e4, a2, { start: i4, end: i4 + s4 - 1 }) && t4.closePath(), t4.stroke();
      }(t3, e3, i3, s3);
    }(t2, this, i2, s2), t2.restore()), this.animated && (this._pointsUpdated = false, this._path = void 0);
  }
}
__publicField(LineElement, "id", "line");
__publicField(LineElement, "defaults", { borderCapStyle: "butt", borderDash: [], borderDashOffset: 0, borderJoinStyle: "miter", borderWidth: 3, capBezierPoints: true, cubicInterpolationMode: "default", fill: false, spanGaps: false, stepped: false, tension: 0 });
__publicField(LineElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
__publicField(LineElement, "descriptors", { _scriptable: true, _indexable: (t2) => "borderDash" !== t2 && "fill" !== t2 });
function aw(t2, e2, i2, s2) {
  const n2 = t2.options, { [i2]: r2 } = t2.getProps([i2], s2);
  return Math.abs(e2 - r2) < n2.radius + n2.hitRadius;
}
class PointElement extends by {
  constructor(t2) {
    super();
    __publicField(this, "parsed");
    __publicField(this, "skip");
    __publicField(this, "stop");
    this.options = void 0, this.parsed = void 0, this.skip = void 0, this.stop = void 0, t2 && Object.assign(this, t2);
  }
  inRange(t2, e2, i2) {
    const s2 = this.options, { x: n2, y: r2 } = this.getProps(["x", "y"], i2);
    return Math.pow(t2 - n2, 2) + Math.pow(e2 - r2, 2) < Math.pow(s2.hitRadius + s2.radius, 2);
  }
  inXRange(t2, e2) {
    return aw(this, t2, "x", e2);
  }
  inYRange(t2, e2) {
    return aw(this, t2, "y", e2);
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2 } = this.getProps(["x", "y"], t2);
    return { x: e2, y: i2 };
  }
  size(t2) {
    let e2 = (t2 = t2 || this.options || {}).radius || 0;
    return e2 = Math.max(e2, e2 && t2.hoverRadius || 0), 2 * (e2 + (e2 && t2.borderWidth || 0));
  }
  draw(t2, e2) {
    const i2 = this.options;
    this.skip || i2.radius < 0.1 || !rb(this, e2, this.size(i2) / 2) || (t2.strokeStyle = i2.borderColor, t2.lineWidth = i2.borderWidth, t2.fillStyle = i2.backgroundColor, sb(t2, i2, this.x, this.y));
  }
  getRange() {
    const t2 = this.options || {};
    return t2.radius + t2.hitRadius;
  }
}
__publicField(PointElement, "id", "point");
__publicField(PointElement, "defaults", { borderWidth: 1, hitRadius: 1, hoverBorderWidth: 1, hoverRadius: 4, pointStyle: "circle", radius: 3, rotation: 0 });
__publicField(PointElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
function lw(t2, e2) {
  const { x: i2, y: s2, base: n2, width: r2, height: o2 } = t2.getProps(["x", "y", "base", "width", "height"], e2);
  let a2, l2, h2, c2, u2;
  return t2.horizontal ? (u2 = o2 / 2, a2 = Math.min(i2, n2), l2 = Math.max(i2, n2), h2 = s2 - u2, c2 = s2 + u2) : (u2 = r2 / 2, a2 = i2 - u2, l2 = i2 + u2, h2 = Math.min(s2, n2), c2 = Math.max(s2, n2)), { left: a2, top: h2, right: l2, bottom: c2 };
}
function hw(t2, e2, i2, s2) {
  return t2 ? 0 : wv(e2, i2, s2);
}
function cw(t2, e2, i2, s2) {
  const n2 = null === e2, r2 = null === i2, o2 = t2 && !(n2 && r2) && lw(t2, s2);
  return o2 && (n2 || xv(e2, o2.left, o2.right)) && (r2 || xv(i2, o2.top, o2.bottom));
}
function uw(t2, e2) {
  t2.rect(e2.x, e2.y, e2.w, e2.h);
}
function dw(t2, e2, i2 = {}) {
  const s2 = t2.x !== i2.x ? -e2 : 0, n2 = t2.y !== i2.y ? -e2 : 0, r2 = (t2.x + t2.w !== i2.x + i2.w ? e2 : 0) - s2, o2 = (t2.y + t2.h !== i2.y + i2.h ? e2 : 0) - n2;
  return { x: t2.x + s2, y: t2.y + n2, w: t2.w + r2, h: t2.h + o2, radius: t2.radius };
}
class BarElement extends by {
  constructor(t2) {
    super(), this.options = void 0, this.horizontal = void 0, this.base = void 0, this.width = void 0, this.height = void 0, this.inflateAmount = void 0, t2 && Object.assign(this, t2);
  }
  draw(t2) {
    const { inflateAmount: e2, options: { borderColor: i2, backgroundColor: s2 } } = this, { inner: n2, outer: r2 } = function(t3) {
      const e3 = lw(t3), i3 = e3.right - e3.left, s3 = e3.bottom - e3.top, n3 = function(t4, e4, i4) {
        const s4 = t4.options.borderWidth, n4 = t4.borderSkipped, r4 = _b(s4);
        return { t: hw(n4.top, r4.top, 0, i4), r: hw(n4.right, r4.right, 0, e4), b: hw(n4.bottom, r4.bottom, 0, i4), l: hw(n4.left, r4.left, 0, e4) };
      }(t3, i3 / 2, s3 / 2), r3 = function(t4, e4, i4) {
        const { enableBorderRadius: s4 } = t4.getProps(["enableBorderRadius"]), n4 = t4.options.borderRadius, r4 = yb(n4), o3 = Math.min(e4, i4), a3 = t4.borderSkipped, l2 = s4 || Eg(n4);
        return { topLeft: hw(!l2 || a3.top || a3.left, r4.topLeft, 0, o3), topRight: hw(!l2 || a3.top || a3.right, r4.topRight, 0, o3), bottomLeft: hw(!l2 || a3.bottom || a3.left, r4.bottomLeft, 0, o3), bottomRight: hw(!l2 || a3.bottom || a3.right, r4.bottomRight, 0, o3) };
      }(t3, i3 / 2, s3 / 2);
      return { outer: { x: e3.left, y: e3.top, w: i3, h: s3, radius: r3 }, inner: { x: e3.left + n3.l, y: e3.top + n3.t, w: i3 - n3.l - n3.r, h: s3 - n3.t - n3.b, radius: { topLeft: Math.max(0, r3.topLeft - Math.max(n3.t, n3.l)), topRight: Math.max(0, r3.topRight - Math.max(n3.t, n3.r)), bottomLeft: Math.max(0, r3.bottomLeft - Math.max(n3.b, n3.l)), bottomRight: Math.max(0, r3.bottomRight - Math.max(n3.b, n3.r)) } } };
    }(this), o2 = (a2 = r2.radius).topLeft || a2.topRight || a2.bottomLeft || a2.bottomRight ? fb : uw;
    var a2;
    t2.save(), r2.w === n2.w && r2.h === n2.h || (t2.beginPath(), o2(t2, dw(r2, e2, n2)), t2.clip(), o2(t2, dw(n2, -e2, r2)), t2.fillStyle = i2, t2.fill("evenodd")), t2.beginPath(), o2(t2, dw(n2, e2)), t2.fillStyle = s2, t2.fill(), t2.restore();
  }
  inRange(t2, e2, i2) {
    return cw(this, t2, e2, i2);
  }
  inXRange(t2, e2) {
    return cw(this, t2, null, e2);
  }
  inYRange(t2, e2) {
    return cw(this, null, t2, e2);
  }
  getCenterPoint(t2) {
    const { x: e2, y: i2, base: s2, horizontal: n2 } = this.getProps(["x", "y", "base", "horizontal"], t2);
    return { x: n2 ? (e2 + s2) / 2 : e2, y: n2 ? i2 : (i2 + s2) / 2 };
  }
  getRange(t2) {
    return "x" === t2 ? this.width / 2 : this.height / 2;
  }
}
__publicField(BarElement, "id", "bar");
__publicField(BarElement, "defaults", { borderSkipped: "start", borderWidth: 0, borderRadius: 0, inflateAmount: "auto", pointStyle: void 0 });
__publicField(BarElement, "defaultRoutes", { backgroundColor: "backgroundColor", borderColor: "borderColor" });
var fw = Object.freeze({ __proto__: null, ArcElement, BarElement, LineElement, PointElement });
const pw = ["rgb(54, 162, 235)", "rgb(255, 99, 132)", "rgb(255, 159, 64)", "rgb(255, 205, 86)", "rgb(75, 192, 192)", "rgb(153, 102, 255)", "rgb(201, 203, 207)"], mw = pw.map((t2) => t2.replace("rgb(", "rgba(").replace(")", ", 0.5)"));
function gw(t2) {
  return pw[t2 % pw.length];
}
function vw(t2) {
  return mw[t2 % mw.length];
}
function bw(t2) {
  let e2;
  for (e2 in t2) if (t2[e2].borderColor || t2[e2].backgroundColor) return true;
  return false;
}
var _w = { id: "colors", defaults: { enabled: true, forceOverride: false }, beforeLayout(t2, e2, i2) {
  if (!i2.enabled) return;
  const { data: { datasets: s2 }, options: n2 } = t2.config, { elements: r2 } = n2, o2 = bw(s2) || (a2 = n2) && (a2.borderColor || a2.backgroundColor) || r2 && bw(r2) || "rgba(0,0,0,0.1)" !== Qv.borderColor || "rgba(0,0,0,0.1)" !== Qv.backgroundColor;
  var a2;
  if (!i2.forceOverride && o2) return;
  const l2 = /* @__PURE__ */ function(t3) {
    let e3 = 0;
    return (i3, s3) => {
      const n3 = t3.getDatasetMeta(s3).controller;
      n3 instanceof DoughnutController ? e3 = function(t4, e4) {
        return t4.backgroundColor = t4.data.map(() => gw(e4++)), e4;
      }(i3, e3) : n3 instanceof PolarAreaController ? e3 = function(t4, e4) {
        return t4.backgroundColor = t4.data.map(() => vw(e4++)), e4;
      }(i3, e3) : n3 && (e3 = function(t4, e4) {
        return t4.borderColor = gw(e4), t4.backgroundColor = vw(e4), ++e4;
      }(i3, e3));
    };
  }(t2);
  s2.forEach(l2);
} };
function yw(t2) {
  if (t2._decimated) {
    const e2 = t2._data;
    delete t2._decimated, delete t2._data, Object.defineProperty(t2, "data", { configurable: true, enumerable: true, writable: true, value: e2 });
  }
}
function ww(t2) {
  t2.data.datasets.forEach((t3) => {
    yw(t3);
  });
}
var xw = { id: "decimation", defaults: { algorithm: "min-max", enabled: false }, beforeElementsUpdate: (t2, e2, i2) => {
  if (!i2.enabled) return void ww(t2);
  const s2 = t2.width;
  t2.data.datasets.forEach((e3, n2) => {
    const { _data: r2, indexAxis: o2 } = e3, a2 = t2.getDatasetMeta(n2), l2 = r2 || e3.data;
    if ("y" === kb([o2, t2.options.indexAxis])) return;
    if (!a2.controller.supportsDecimation) return;
    const h2 = t2.scales[a2.xAxisID];
    if ("linear" !== h2.type && "time" !== h2.type) return;
    if (t2.options.parsing) return;
    let c2, { start: u2, count: d2 } = function(t3, e4) {
      const i3 = e4.length;
      let s3, n3 = 0;
      const { iScale: r3 } = t3, { min: o3, max: a3, minDefined: l3, maxDefined: h3 } = r3.getUserBounds();
      return l3 && (n3 = wv(Sv(e4, r3.axis, o3).lo, 0, i3 - 1)), s3 = h3 ? wv(Sv(e4, r3.axis, a3).hi + 1, n3, i3) - n3 : i3 - n3, { start: n3, count: s3 };
    }(a2, l2);
    if (d2 <= (i2.threshold || 4 * s2)) yw(e3);
    else {
      switch (Tg(r2) && (e3._data = l2, delete e3.data, Object.defineProperty(e3, "data", { configurable: true, enumerable: true, get: function() {
        return this._decimated;
      }, set: function(t3) {
        this._data = t3;
      } })), i2.algorithm) {
        case "lttb":
          c2 = function(t3, e4, i3, s3, n3) {
            const r3 = n3.samples || s3;
            if (r3 >= i3) return t3.slice(e4, e4 + i3);
            const o3 = [], a3 = (i3 - 2) / (r3 - 2);
            let l3 = 0;
            const h3 = e4 + i3 - 1;
            let c3, u3, d3, f2, p2, m2 = e4;
            for (o3[l3++] = t3[m2], c3 = 0; c3 < r3 - 2; c3++) {
              let s4, n4 = 0, r4 = 0;
              const h4 = Math.floor((c3 + 1) * a3) + 1 + e4, g2 = Math.min(Math.floor((c3 + 2) * a3) + 1, i3) + e4, v2 = g2 - h4;
              for (s4 = h4; s4 < g2; s4++) n4 += t3[s4].x, r4 += t3[s4].y;
              n4 /= v2, r4 /= v2;
              const b2 = Math.floor(c3 * a3) + 1 + e4, _2 = Math.min(Math.floor((c3 + 1) * a3) + 1, i3) + e4, { x: y2, y: w2 } = t3[m2];
              for (d3 = f2 = -1, s4 = b2; s4 < _2; s4++) f2 = 0.5 * Math.abs((y2 - n4) * (t3[s4].y - w2) - (y2 - t3[s4].x) * (r4 - w2)), f2 > d3 && (d3 = f2, u3 = t3[s4], p2 = s4);
              o3[l3++] = u3, m2 = p2;
            }
            return o3[l3++] = t3[h3], o3;
          }(l2, u2, d2, s2, i2);
          break;
        case "min-max":
          c2 = function(t3, e4, i3, s3) {
            let n3, r3, o3, a3, l3, h3, c3, u3, d3, f2, p2 = 0, m2 = 0;
            const g2 = [], v2 = e4 + i3 - 1, b2 = t3[e4].x, _2 = t3[v2].x - b2;
            for (n3 = e4; n3 < e4 + i3; ++n3) {
              r3 = t3[n3], o3 = (r3.x - b2) / _2 * s3, a3 = r3.y;
              const e5 = 0 | o3;
              if (e5 === l3) a3 < d3 ? (d3 = a3, h3 = n3) : a3 > f2 && (f2 = a3, c3 = n3), p2 = (m2 * p2 + r3.x) / ++m2;
              else {
                const i4 = n3 - 1;
                if (!Tg(h3) && !Tg(c3)) {
                  const e6 = Math.min(h3, c3), s4 = Math.max(h3, c3);
                  e6 !== u3 && e6 !== i4 && g2.push({ ...t3[e6], x: p2 }), s4 !== u3 && s4 !== i4 && g2.push({ ...t3[s4], x: p2 });
                }
                n3 > 0 && i4 !== u3 && g2.push(t3[i4]), g2.push(r3), l3 = e5, m2 = 0, d3 = f2 = a3, h3 = c3 = u3 = n3;
              }
            }
            return g2;
          }(l2, u2, d2, s2);
          break;
        default:
          throw new Error(`Unsupported decimation algorithm '${i2.algorithm}'`);
      }
      e3._decimated = c2;
    }
  });
}, destroy(t2) {
  ww(t2);
} };
function kw(t2, e2, i2, s2) {
  if (s2) return;
  let n2 = e2[t2], r2 = i2[t2];
  return "angle" === t2 && (n2 = _v(n2), r2 = _v(r2)), { property: t2, start: n2, end: r2 };
}
function Sw(t2, e2, i2) {
  for (; e2 > t2; e2--) {
    const t3 = i2[e2];
    if (!isNaN(t3.x) && !isNaN(t3.y)) break;
  }
  return e2;
}
function Mw(t2, e2, i2, s2) {
  return t2 && e2 ? s2(t2[i2], e2[i2]) : t2 ? t2[i2] : e2 ? e2[i2] : 0;
}
function zw(t2, e2) {
  let i2 = [], s2 = false;
  return $g(t2) ? (s2 = true, i2 = t2) : i2 = function(t3, e3) {
    const { x: i3 = null, y: s3 = null } = t3 || {}, n2 = e3.points, r2 = [];
    return e3.segments.forEach(({ start: t4, end: e4 }) => {
      e4 = Sw(t4, e4, n2);
      const o2 = n2[t4], a2 = n2[e4];
      null !== s3 ? (r2.push({ x: o2.x, y: s3 }), r2.push({ x: a2.x, y: s3 })) : null !== i3 && (r2.push({ x: i3, y: o2.y }), r2.push({ x: i3, y: a2.y }));
    }), r2;
  }(t2, e2), i2.length ? new LineElement({ points: i2, options: { tension: 0 }, _loop: s2, _fullLoop: s2 }) : null;
}
function Cw(t2) {
  return t2 && false !== t2.fill;
}
function Dw(t2, e2, i2) {
  let s2 = t2[e2].fill;
  const n2 = [e2];
  let r2;
  if (!i2) return s2;
  for (; false !== s2 && -1 === n2.indexOf(s2); ) {
    if (!Ag(s2)) return s2;
    if (r2 = t2[s2], !r2) return false;
    if (r2.visible) return s2;
    n2.push(s2), s2 = r2.fill;
  }
  return false;
}
function Rw(t2, e2, i2) {
  const s2 = function(t3) {
    const e3 = t3.options, i3 = e3.fill;
    let s3 = Vg(i3 && i3.target, i3);
    return void 0 === s3 && (s3 = !!e3.backgroundColor), false !== s3 && null !== s3 && (true === s3 ? "origin" : s3);
  }(t2);
  if (Eg(s2)) return !isNaN(s2.value) && s2;
  let n2 = parseFloat(s2);
  return Ag(n2) && Math.floor(n2) === n2 ? function(t3, e3, i3, s3) {
    return "-" !== t3 && "+" !== t3 || (i3 = e3 + i3), !(i3 === e3 || i3 < 0 || i3 >= s3) && i3;
  }(s2[0], e2, n2, i2) : ["origin", "start", "end", "stack", "shape"].indexOf(s2) >= 0 && s2;
}
function Pw(t2, e2, i2) {
  const s2 = [];
  for (let n2 = 0; n2 < i2.length; n2++) {
    const r2 = i2[n2], { first: o2, last: a2, point: l2 } = Tw(r2, e2, "x");
    if (!(!l2 || o2 && a2)) {
      if (o2) s2.unshift(l2);
      else if (t2.push(l2), !a2) break;
    }
  }
  t2.push(...s2);
}
function Tw(t2, e2, i2) {
  const s2 = t2.interpolate(e2, i2);
  if (!s2) return {};
  const n2 = s2[i2], r2 = t2.segments, o2 = t2.points;
  let a2 = false, l2 = false;
  for (let t3 = 0; t3 < r2.length; t3++) {
    const e3 = r2[t3], s3 = o2[e3.start][i2], h2 = o2[e3.end][i2];
    if (xv(n2, s3, h2)) {
      a2 = n2 === s3, l2 = n2 === h2;
      break;
    }
  }
  return { first: a2, last: l2, point: s2 };
}
class simpleArc {
  constructor(t2) {
    this.x = t2.x, this.y = t2.y, this.radius = t2.radius;
  }
  pathSegment(t2, e2, i2) {
    const { x: s2, y: n2, radius: r2 } = this;
    return e2 = e2 || { start: 0, end: tv }, t2.arc(s2, n2, r2, e2.end, e2.start, true), !i2.bounds;
  }
  interpolate(t2) {
    const { x: e2, y: i2, radius: s2 } = this, n2 = t2.angle;
    return { x: e2 + Math.cos(n2) * s2, y: i2 + Math.sin(n2) * s2, angle: n2 };
  }
}
function $w(t2, e2, i2) {
  const s2 = function(t3) {
    const { chart: e3, fill: i3, line: s3 } = t3;
    if (Ag(i3)) return function(t4, e4) {
      const i4 = t4.getDatasetMeta(e4);
      return i4 && t4.isDatasetVisible(e4) ? i4.dataset : null;
    }(e3, i3);
    if ("stack" === i3) return function(t4) {
      const { scale: e4, index: i4, line: s4 } = t4, n4 = [], r3 = s4.segments, o3 = s4.points, a3 = function(t5, e5) {
        const i5 = [], s5 = t5.getMatchingVisibleMetas("line");
        for (let t6 = 0; t6 < s5.length; t6++) {
          const n5 = s5[t6];
          if (n5.index === e5) break;
          n5.hidden || i5.unshift(n5.dataset);
        }
        return i5;
      }(e4, i4);
      a3.push(zw({ x: null, y: e4.bottom }, s4));
      for (let t5 = 0; t5 < r3.length; t5++) {
        const e5 = r3[t5];
        for (let t6 = e5.start; t6 <= e5.end; t6++) Pw(n4, o3[t6], a3);
      }
      return new LineElement({ points: n4, options: {} });
    }(t3);
    if ("shape" === i3) return true;
    const n3 = function(t4) {
      return (t4.scale || {}).getPointPositionForValue ? function(t5) {
        const { scale: e4, fill: i4 } = t5, s4 = e4.options, n4 = e4.getLabels().length, r3 = s4.reverse ? e4.max : e4.min, o3 = function(t6, e5, i5) {
          let s5;
          return s5 = "start" === t6 ? i5 : "end" === t6 ? e5.options.reverse ? e5.min : e5.max : Eg(t6) ? t6.value : e5.getBaseValue(), s5;
        }(i4, e4, r3), a3 = [];
        if (s4.grid.circular) {
          const t6 = e4.getPointPositionForValue(0, r3);
          return new simpleArc({ x: t6.x, y: t6.y, radius: e4.getDistanceFromCenterForValue(o3) });
        }
        for (let t6 = 0; t6 < n4; ++t6) a3.push(e4.getPointPositionForValue(t6, o3));
        return a3;
      }(t4) : function(t5) {
        const { scale: e4 = {}, fill: i4 } = t5, s4 = function(t6, e5) {
          let i5 = null;
          return "start" === t6 ? i5 = e5.bottom : "end" === t6 ? i5 = e5.top : Eg(t6) ? i5 = e5.getPixelForValue(t6.value) : e5.getBasePixel && (i5 = e5.getBasePixel()), i5;
        }(i4, e4);
        if (Ag(s4)) {
          const t6 = e4.isHorizontal();
          return { x: t6 ? s4 : null, y: t6 ? null : s4 };
        }
        return null;
      }(t4);
    }(t3);
    return n3 instanceof simpleArc ? n3 : zw(n3, s3);
  }(e2), { chart: n2, index: r2, line: o2, scale: a2, axis: l2 } = e2, h2 = o2.options, c2 = h2.fill, u2 = h2.backgroundColor, { above: d2 = u2, below: f2 = u2 } = c2 || {}, p2 = n2.getDatasetMeta(r2), m2 = p_(n2, p2);
  s2 && o2.points.length && (ob(t2, i2), function(t3, e3) {
    const { line: i3, target: s3, above: n3, below: r3, area: o3, scale: a3, clip: l3 } = e3, h3 = i3._loop ? "angle" : e3.axis;
    t3.save(), "x" === h3 && r3 !== n3 && (Ew(t3, s3, o3.top), Aw(t3, { line: i3, target: s3, color: n3, scale: a3, property: h3, clip: l3 }), t3.restore(), t3.save(), Ew(t3, s3, o3.bottom)), Aw(t3, { line: i3, target: s3, color: r3, scale: a3, property: h3, clip: l3 }), t3.restore();
  }(t2, { line: o2, target: s2, above: d2, below: f2, area: i2, scale: a2, axis: l2, clip: m2 }), ab(t2));
}
function Ew(t2, e2, i2) {
  const { segments: s2, points: n2 } = e2;
  let r2 = true, o2 = false;
  t2.beginPath();
  for (const a2 of s2) {
    const { start: s3, end: l2 } = a2, h2 = n2[s3], c2 = n2[Sw(s3, l2, n2)];
    r2 ? (t2.moveTo(h2.x, h2.y), r2 = false) : (t2.lineTo(h2.x, i2), t2.lineTo(h2.x, h2.y)), o2 = !!e2.pathSegment(t2, a2, { move: o2 }), o2 ? t2.closePath() : t2.lineTo(c2.x, i2);
  }
  t2.lineTo(e2.first().x, i2), t2.closePath(), t2.clip();
}
function Aw(t2, e2) {
  const { line: i2, target: s2, property: n2, color: r2, scale: o2, clip: a2 } = e2, l2 = function(t3, e3, i3) {
    const s3 = t3.segments, n3 = t3.points, r3 = e3.points, o3 = [];
    for (const t4 of s3) {
      let { start: s4, end: a3 } = t4;
      a3 = Sw(s4, a3, n3);
      const l3 = kw(i3, n3[s4], n3[a3], t4.loop);
      if (!e3.segments) {
        o3.push({ source: t4, target: l3, start: n3[s4], end: n3[a3] });
        continue;
      }
      const h2 = c_(e3, l3);
      for (const e4 of h2) {
        const s5 = kw(i3, r3[e4.start], r3[e4.end], e4.loop), a4 = h_(t4, n3, s5);
        for (const t5 of a4) o3.push({ source: t5, target: e4, start: { [i3]: Mw(l3, s5, "start", Math.max) }, end: { [i3]: Mw(l3, s5, "end", Math.min) } });
      }
    }
    return o3;
  }(i2, s2, n2);
  for (const { source: e3, target: h2, start: c2, end: u2 } of l2) {
    const { style: { backgroundColor: l3 = r2 } = {} } = e3, d2 = true !== s2;
    t2.save(), t2.fillStyle = l3, Lw(t2, o2, a2, d2 && kw(n2, c2, u2)), t2.beginPath();
    const f2 = !!i2.pathSegment(t2, e3);
    let p2;
    if (d2) {
      f2 ? t2.closePath() : Vw(t2, s2, u2, n2);
      const e4 = !!s2.pathSegment(t2, h2, { move: f2, reverse: true });
      p2 = f2 && e4, p2 || Vw(t2, s2, c2, n2);
    }
    t2.closePath(), t2.fill(p2 ? "evenodd" : "nonzero"), t2.restore();
  }
}
function Lw(t2, e2, i2, s2) {
  const n2 = e2.chart.chartArea, { property: r2, start: o2, end: a2 } = s2 || {};
  if ("x" === r2 || "y" === r2) {
    let e3, s3, l2, h2;
    "x" === r2 ? (e3 = o2, s3 = n2.top, l2 = a2, h2 = n2.bottom) : (e3 = n2.left, s3 = o2, l2 = n2.right, h2 = a2), t2.beginPath(), i2 && (e3 = Math.max(e3, i2.left), l2 = Math.min(l2, i2.right), s3 = Math.max(s3, i2.top), h2 = Math.min(h2, i2.bottom)), t2.rect(e3, s3, l2 - e3, h2 - s3), t2.clip();
  }
}
function Vw(t2, e2, i2, s2) {
  const n2 = e2.interpolate(i2, s2);
  n2 && t2.lineTo(n2.x, n2.y);
}
var Ow = { id: "filler", afterDatasetsUpdate(t2, e2, i2) {
  const s2 = (t2.data.datasets || []).length, n2 = [];
  let r2, o2, a2, l2;
  for (o2 = 0; o2 < s2; ++o2) r2 = t2.getDatasetMeta(o2), a2 = r2.dataset, l2 = null, a2 && a2.options && a2 instanceof LineElement && (l2 = { visible: t2.isDatasetVisible(o2), index: o2, fill: Rw(a2, o2, s2), chart: t2, axis: r2.controller.options.indexAxis, scale: r2.vScale, line: a2 }), r2.$filler = l2, n2.push(l2);
  for (o2 = 0; o2 < s2; ++o2) l2 = n2[o2], l2 && false !== l2.fill && (l2.fill = Dw(n2, o2, i2.propagate));
}, beforeDraw(t2, e2, i2) {
  const s2 = "beforeDraw" === i2.drawTime, n2 = t2.getSortedVisibleDatasetMetas(), r2 = t2.chartArea;
  for (let e3 = n2.length - 1; e3 >= 0; --e3) {
    const i3 = n2[e3].$filler;
    i3 && (i3.line.updateControlPoints(r2, i3.axis), s2 && i3.fill && $w(t2.ctx, i3, r2));
  }
}, beforeDatasetsDraw(t2, e2, i2) {
  if ("beforeDatasetsDraw" !== i2.drawTime) return;
  const s2 = t2.getSortedVisibleDatasetMetas();
  for (let e3 = s2.length - 1; e3 >= 0; --e3) {
    const i3 = s2[e3].$filler;
    Cw(i3) && $w(t2.ctx, i3, t2.chartArea);
  }
}, beforeDatasetDraw(t2, e2, i2) {
  const s2 = e2.meta.$filler;
  Cw(s2) && "beforeDatasetDraw" === i2.drawTime && $w(t2.ctx, s2, t2.chartArea);
}, defaults: { propagate: true, drawTime: "beforeDatasetDraw" } };
const Iw = (t2, e2) => {
  let { boxHeight: i2 = e2, boxWidth: s2 = e2 } = t2;
  return t2.usePointStyle && (i2 = Math.min(i2, e2), s2 = t2.pointStyleWidth || Math.min(s2, e2)), { boxWidth: s2, boxHeight: i2, itemHeight: Math.max(e2, i2) };
};
class Legend extends by {
  constructor(t2) {
    super(), this._added = false, this.legendHitBoxes = [], this._hoveredItem = null, this.doughnutMode = false, this.chart = t2.chart, this.options = t2.options, this.ctx = t2.ctx, this.legendItems = void 0, this.columnSizes = void 0, this.lineWidths = void 0, this.maxHeight = void 0, this.maxWidth = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.height = void 0, this.width = void 0, this._margins = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t2, e2, i2) {
    this.maxWidth = t2, this.maxHeight = e2, this._margins = i2, this.setDimensions(), this.buildLabels(), this.fit();
  }
  setDimensions() {
    this.isHorizontal() ? (this.width = this.maxWidth, this.left = this._margins.left, this.right = this.width) : (this.height = this.maxHeight, this.top = this._margins.top, this.bottom = this.height);
  }
  buildLabels() {
    const t2 = this.options.labels || {};
    let e2 = Ig(t2.generateLabels, [this.chart], this) || [];
    t2.filter && (e2 = e2.filter((e3) => t2.filter(e3, this.chart.data))), t2.sort && (e2 = e2.sort((e3, i2) => t2.sort(e3, i2, this.chart.data))), this.options.reverse && e2.reverse(), this.legendItems = e2;
  }
  fit() {
    const { options: t2, ctx: e2 } = this;
    if (!t2.display) return void (this.width = this.height = 0);
    const i2 = t2.labels, s2 = xb(i2.font), n2 = s2.size, r2 = this._computeTitleHeight(), { boxWidth: o2, itemHeight: a2 } = Iw(i2, n2);
    let l2, h2;
    e2.font = s2.string, this.isHorizontal() ? (l2 = this.maxWidth, h2 = this._fitRows(r2, n2, o2, a2) + 10) : (h2 = this.maxHeight, l2 = this._fitCols(r2, s2, o2, a2) + 10), this.width = Math.min(l2, t2.maxWidth || this.maxWidth), this.height = Math.min(h2, t2.maxHeight || this.maxHeight);
  }
  _fitRows(t2, e2, i2, s2) {
    const { ctx: n2, maxWidth: r2, options: { labels: { padding: o2 } } } = this, a2 = this.legendHitBoxes = [], l2 = this.lineWidths = [0], h2 = s2 + o2;
    let c2 = t2;
    n2.textAlign = "left", n2.textBaseline = "middle";
    let u2 = -1, d2 = -h2;
    return this.legendItems.forEach((t3, f2) => {
      const p2 = i2 + e2 / 2 + n2.measureText(t3.text).width;
      (0 === f2 || l2[l2.length - 1] + p2 + 2 * o2 > r2) && (c2 += h2, l2[l2.length - (f2 > 0 ? 0 : 1)] = 0, d2 += h2, u2++), a2[f2] = { left: 0, top: d2, row: u2, width: p2, height: s2 }, l2[l2.length - 1] += p2 + o2;
    }), c2;
  }
  _fitCols(t2, e2, i2, s2) {
    const { ctx: n2, maxHeight: r2, options: { labels: { padding: o2 } } } = this, a2 = this.legendHitBoxes = [], l2 = this.columnSizes = [], h2 = r2 - t2;
    let c2 = o2, u2 = 0, d2 = 0, f2 = 0, p2 = 0;
    return this.legendItems.forEach((t3, r3) => {
      const { itemWidth: m2, itemHeight: g2 } = function(t4, e3, i3, s3, n3) {
        const r4 = function(t5, e4, i4, s4) {
          let n4 = t5.text;
          return n4 && "string" != typeof n4 && (n4 = n4.reduce((t6, e5) => t6.length > e5.length ? t6 : e5)), e4 + i4.size / 2 + s4.measureText(n4).width;
        }(s3, t4, e3, i3), o3 = function(t5, e4, i4) {
          let s4 = t5;
          return "string" != typeof e4.text && (s4 = Nw(e4, i4)), s4;
        }(n3, s3, e3.lineHeight);
        return { itemWidth: r4, itemHeight: o3 };
      }(i2, e2, n2, t3, s2);
      r3 > 0 && d2 + g2 + 2 * o2 > h2 && (c2 += u2 + o2, l2.push({ width: u2, height: d2 }), f2 += u2 + o2, p2++, u2 = d2 = 0), a2[r3] = { left: f2, top: d2, col: p2, width: m2, height: g2 }, u2 = Math.max(u2, m2), d2 += g2 + o2;
    }), c2 += u2, l2.push({ width: u2, height: d2 }), c2;
  }
  adjustHitBoxes() {
    if (!this.options.display) return;
    const t2 = this._computeTitleHeight(), { legendHitBoxes: e2, options: { align: i2, labels: { padding: s2 }, rtl: n2 } } = this, r2 = n_(n2, this.left, this.width);
    if (this.isHorizontal()) {
      let n3 = 0, o2 = $v(i2, this.left + s2, this.right - this.lineWidths[n3]);
      for (const a2 of e2) n3 !== a2.row && (n3 = a2.row, o2 = $v(i2, this.left + s2, this.right - this.lineWidths[n3])), a2.top += this.top + t2 + s2, a2.left = r2.leftForLtr(r2.x(o2), a2.width), o2 += a2.width + s2;
    } else {
      let n3 = 0, o2 = $v(i2, this.top + t2 + s2, this.bottom - this.columnSizes[n3].height);
      for (const a2 of e2) a2.col !== n3 && (n3 = a2.col, o2 = $v(i2, this.top + t2 + s2, this.bottom - this.columnSizes[n3].height)), a2.top = o2, a2.left += this.left + s2, a2.left = r2.leftForLtr(r2.x(a2.left), a2.width), o2 += a2.height + s2;
    }
  }
  isHorizontal() {
    return "top" === this.options.position || "bottom" === this.options.position;
  }
  draw() {
    if (this.options.display) {
      const t2 = this.ctx;
      ob(t2, this), this._draw(), ab(t2);
    }
  }
  _draw() {
    const { options: t2, columnSizes: e2, lineWidths: i2, ctx: s2 } = this, { align: n2, labels: r2 } = t2, o2 = Qv.color, a2 = n_(t2.rtl, this.left, this.width), l2 = xb(r2.font), { padding: h2 } = r2, c2 = l2.size, u2 = c2 / 2;
    let d2;
    this.drawTitle(), s2.textAlign = a2.textAlign("left"), s2.textBaseline = "middle", s2.lineWidth = 0.5, s2.font = l2.string;
    const { boxWidth: f2, boxHeight: p2, itemHeight: m2 } = Iw(r2, c2), g2 = this.isHorizontal(), v2 = this._computeTitleHeight();
    d2 = g2 ? { x: $v(n2, this.left + h2, this.right - i2[0]), y: this.top + h2 + v2, line: 0 } : { x: this.left + h2, y: $v(n2, this.top + v2 + h2, this.bottom - e2[0].height), line: 0 }, r_(this.ctx, t2.textDirection);
    const b2 = m2 + h2;
    this.legendItems.forEach((_2, y2) => {
      s2.strokeStyle = _2.fontColor, s2.fillStyle = _2.fontColor;
      const w2 = s2.measureText(_2.text).width, x2 = a2.textAlign(_2.textAlign || (_2.textAlign = r2.textAlign)), k2 = f2 + u2 + w2;
      let S2 = d2.x, M2 = d2.y;
      if (a2.setWidth(this.width), g2 ? y2 > 0 && S2 + k2 + h2 > this.right && (M2 = d2.y += b2, d2.line++, S2 = d2.x = $v(n2, this.left + h2, this.right - i2[d2.line])) : y2 > 0 && M2 + b2 > this.bottom && (S2 = d2.x = S2 + e2[d2.line].width + h2, d2.line++, M2 = d2.y = $v(n2, this.top + v2 + h2, this.bottom - e2[d2.line].height)), function(t3, e3, i3) {
        if (isNaN(f2) || f2 <= 0 || isNaN(p2) || p2 < 0) return;
        s2.save();
        const n3 = Vg(i3.lineWidth, 1);
        if (s2.fillStyle = Vg(i3.fillStyle, o2), s2.lineCap = Vg(i3.lineCap, "butt"), s2.lineDashOffset = Vg(i3.lineDashOffset, 0), s2.lineJoin = Vg(i3.lineJoin, "miter"), s2.lineWidth = n3, s2.strokeStyle = Vg(i3.strokeStyle, o2), s2.setLineDash(Vg(i3.lineDash, [])), r2.usePointStyle) {
          const o3 = { radius: p2 * Math.SQRT2 / 2, pointStyle: i3.pointStyle, rotation: i3.rotation, borderWidth: n3 }, l3 = a2.xPlus(t3, f2 / 2);
          nb(s2, o3, l3, e3 + u2, r2.pointStyleWidth && f2);
        } else {
          const r3 = e3 + Math.max((c2 - p2) / 2, 0), o3 = a2.leftForLtr(t3, f2), l3 = yb(i3.borderRadius);
          s2.beginPath(), Object.values(l3).some((t4) => 0 !== t4) ? fb(s2, { x: o3, y: r3, w: f2, h: p2, radius: l3 }) : s2.rect(o3, r3, f2, p2), s2.fill(), 0 !== n3 && s2.stroke();
        }
        s2.restore();
      }(a2.x(S2), M2, _2), S2 = ((t3, e3, i3, s3) => t3 === (s3 ? "left" : "right") ? i3 : "center" === t3 ? (e3 + i3) / 2 : e3)(x2, S2 + f2 + u2, g2 ? S2 + k2 : this.right, t2.rtl), function(t3, e3, i3) {
        db(s2, i3.text, t3, e3 + m2 / 2, l2, { strikethrough: i3.hidden, textAlign: a2.textAlign(i3.textAlign) });
      }(a2.x(S2), M2, _2), g2) d2.x += k2 + h2;
      else if ("string" != typeof _2.text) {
        const t3 = l2.lineHeight;
        d2.y += Nw(_2, t3) + h2;
      } else d2.y += b2;
    }), o_(this.ctx, t2.textDirection);
  }
  drawTitle() {
    const t2 = this.options, e2 = t2.title, i2 = xb(e2.font), s2 = wb(e2.padding);
    if (!e2.display) return;
    const n2 = n_(t2.rtl, this.left, this.width), r2 = this.ctx, o2 = e2.position, a2 = i2.size / 2, l2 = s2.top + a2;
    let h2, c2 = this.left, u2 = this.width;
    if (this.isHorizontal()) u2 = Math.max(...this.lineWidths), h2 = this.top + l2, c2 = $v(t2.align, c2, this.right - u2);
    else {
      const e3 = this.columnSizes.reduce((t3, e4) => Math.max(t3, e4.height), 0);
      h2 = l2 + $v(t2.align, this.top, this.bottom - e3 - t2.labels.padding - this._computeTitleHeight());
    }
    const d2 = $v(o2, c2, c2 + u2);
    r2.textAlign = n2.textAlign(Tv(o2)), r2.textBaseline = "middle", r2.strokeStyle = e2.color, r2.fillStyle = e2.color, r2.font = i2.string, db(r2, e2.text, d2, h2, i2);
  }
  _computeTitleHeight() {
    const t2 = this.options.title, e2 = xb(t2.font), i2 = wb(t2.padding);
    return t2.display ? e2.lineHeight + i2.height : 0;
  }
  _getLegendItemAt(t2, e2) {
    let i2, s2, n2;
    if (xv(t2, this.left, this.right) && xv(e2, this.top, this.bottom)) {
      for (n2 = this.legendHitBoxes, i2 = 0; i2 < n2.length; ++i2) if (s2 = n2[i2], xv(t2, s2.left, s2.left + s2.width) && xv(e2, s2.top, s2.top + s2.height)) return this.legendItems[i2];
    }
    return null;
  }
  handleEvent(t2) {
    const e2 = this.options;
    if (!function(t3, e3) {
      return !("mousemove" !== t3 && "mouseout" !== t3 || !e3.onHover && !e3.onLeave) || !(!e3.onClick || "click" !== t3 && "mouseup" !== t3);
    }(t2.type, e2)) return;
    const i2 = this._getLegendItemAt(t2.x, t2.y);
    if ("mousemove" === t2.type || "mouseout" === t2.type) {
      const s2 = this._hoveredItem, n2 = ((t3, e3) => null !== t3 && null !== e3 && t3.datasetIndex === e3.datasetIndex && t3.index === e3.index)(s2, i2);
      s2 && !n2 && Ig(e2.onLeave, [t2, s2, this], this), this._hoveredItem = i2, i2 && !n2 && Ig(e2.onHover, [t2, i2, this], this);
    } else i2 && Ig(e2.onClick, [t2, i2, this], this);
  }
}
function Nw(t2, e2) {
  return e2 * (t2.text ? t2.text.length : 0);
}
var Fw = { id: "legend", _element: Legend, start(t2, e2, i2) {
  const s2 = t2.legend = new Legend({ ctx: t2.ctx, options: i2, chart: t2 });
  sy.configure(t2, s2, i2), sy.addBox(t2, s2);
}, stop(t2) {
  sy.removeBox(t2, t2.legend), delete t2.legend;
}, beforeUpdate(t2, e2, i2) {
  const s2 = t2.legend;
  sy.configure(t2, s2, i2), s2.options = i2;
}, afterUpdate(t2) {
  const e2 = t2.legend;
  e2.buildLabels(), e2.adjustHitBoxes();
}, afterEvent(t2, e2) {
  e2.replay || t2.legend.handleEvent(e2.event);
}, defaults: { display: true, position: "top", align: "center", fullSize: true, reverse: false, weight: 1e3, onClick(t2, e2, i2) {
  const s2 = e2.datasetIndex, n2 = i2.chart;
  n2.isDatasetVisible(s2) ? (n2.hide(s2), e2.hidden = true) : (n2.show(s2), e2.hidden = false);
}, onHover: null, onLeave: null, labels: { color: (t2) => t2.chart.options.color, boxWidth: 40, padding: 10, generateLabels(t2) {
  const e2 = t2.data.datasets, { labels: { usePointStyle: i2, pointStyle: s2, textAlign: n2, color: r2, useBorderRadius: o2, borderRadius: a2 } } = t2.legend.options;
  return t2._getSortedDatasetMetas().map((t3) => {
    const l2 = t3.controller.getStyle(i2 ? 0 : void 0), h2 = wb(l2.borderWidth);
    return { text: e2[t3.index].label, fillStyle: l2.backgroundColor, fontColor: r2, hidden: !t3.visible, lineCap: l2.borderCapStyle, lineDash: l2.borderDash, lineDashOffset: l2.borderDashOffset, lineJoin: l2.borderJoinStyle, lineWidth: (h2.width + h2.height) / 4, strokeStyle: l2.borderColor, pointStyle: s2 || l2.pointStyle, rotation: l2.rotation, textAlign: n2 || l2.textAlign, borderRadius: o2 && (a2 || l2.borderRadius), datasetIndex: t3.index };
  }, this);
} }, title: { color: (t2) => t2.chart.options.color, display: false, position: "center", text: "" } }, descriptors: { _scriptable: (t2) => !t2.startsWith("on"), labels: { _scriptable: (t2) => !["generateLabels", "filter", "sort"].includes(t2) } } };
class Title extends by {
  constructor(t2) {
    super(), this.chart = t2.chart, this.options = t2.options, this.ctx = t2.ctx, this._padding = void 0, this.top = void 0, this.bottom = void 0, this.left = void 0, this.right = void 0, this.width = void 0, this.height = void 0, this.position = void 0, this.weight = void 0, this.fullSize = void 0;
  }
  update(t2, e2) {
    const i2 = this.options;
    if (this.left = 0, this.top = 0, !i2.display) return void (this.width = this.height = this.right = this.bottom = 0);
    this.width = this.right = t2, this.height = this.bottom = e2;
    const s2 = $g(i2.text) ? i2.text.length : 1;
    this._padding = wb(i2.padding);
    const n2 = s2 * xb(i2.font).lineHeight + this._padding.height;
    this.isHorizontal() ? this.height = n2 : this.width = n2;
  }
  isHorizontal() {
    const t2 = this.options.position;
    return "top" === t2 || "bottom" === t2;
  }
  _drawArgs(t2) {
    const { top: e2, left: i2, bottom: s2, right: n2, options: r2 } = this, o2 = r2.align;
    let a2, l2, h2, c2 = 0;
    return this.isHorizontal() ? (l2 = $v(o2, i2, n2), h2 = e2 + t2, a2 = n2 - i2) : ("left" === r2.position ? (l2 = i2 + t2, h2 = $v(o2, s2, e2), c2 = -0.5 * Zg) : (l2 = n2 - t2, h2 = $v(o2, e2, s2), c2 = 0.5 * Zg), a2 = s2 - e2), { titleX: l2, titleY: h2, maxWidth: a2, rotation: c2 };
  }
  draw() {
    const t2 = this.ctx, e2 = this.options;
    if (!e2.display) return;
    const i2 = xb(e2.font), s2 = i2.lineHeight / 2 + this._padding.top, { titleX: n2, titleY: r2, maxWidth: o2, rotation: a2 } = this._drawArgs(s2);
    db(t2, e2.text, 0, 0, i2, { color: e2.color, maxWidth: o2, rotation: a2, textAlign: Tv(e2.align), textBaseline: "middle", translation: [n2, r2] });
  }
}
var Ww = { id: "title", _element: Title, start(t2, e2, i2) {
  !function(t3, e3) {
    const i3 = new Title({ ctx: t3.ctx, options: e3, chart: t3 });
    sy.configure(t3, i3, e3), sy.addBox(t3, i3), t3.titleBlock = i3;
  }(t2, i2);
}, stop(t2) {
  const e2 = t2.titleBlock;
  sy.removeBox(t2, e2), delete t2.titleBlock;
}, beforeUpdate(t2, e2, i2) {
  const s2 = t2.titleBlock;
  sy.configure(t2, s2, i2), s2.options = i2;
}, defaults: { align: "center", display: false, font: { weight: "bold" }, fullSize: true, padding: 10, position: "top", text: "", weight: 2e3 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: true, _indexable: false } };
const Bw = /* @__PURE__ */ new WeakMap();
var jw = { id: "subtitle", start(t2, e2, i2) {
  const s2 = new Title({ ctx: t2.ctx, options: i2, chart: t2 });
  sy.configure(t2, s2, i2), sy.addBox(t2, s2), Bw.set(t2, s2);
}, stop(t2) {
  sy.removeBox(t2, Bw.get(t2)), Bw.delete(t2);
}, beforeUpdate(t2, e2, i2) {
  const s2 = Bw.get(t2);
  sy.configure(t2, s2, i2), s2.options = i2;
}, defaults: { align: "center", display: false, font: { weight: "normal" }, fullSize: true, padding: 0, position: "top", text: "", weight: 1500 }, defaultRoutes: { color: "color" }, descriptors: { _scriptable: true, _indexable: false } };
const qw = { average(t2) {
  if (!t2.length) return false;
  let e2, i2, s2 = /* @__PURE__ */ new Set(), n2 = 0, r2 = 0;
  for (e2 = 0, i2 = t2.length; e2 < i2; ++e2) {
    const i3 = t2[e2].element;
    if (i3 && i3.hasValue()) {
      const t3 = i3.tooltipPosition();
      s2.add(t3.x), n2 += t3.y, ++r2;
    }
  }
  if (0 === r2 || 0 === s2.size) return false;
  const o2 = [...s2].reduce((t3, e3) => t3 + e3) / s2.size;
  return { x: o2, y: n2 / r2 };
}, nearest(t2, e2) {
  if (!t2.length) return false;
  let i2, s2, n2, r2 = e2.x, o2 = e2.y, a2 = Number.POSITIVE_INFINITY;
  for (i2 = 0, s2 = t2.length; i2 < s2; ++i2) {
    const s3 = t2[i2].element;
    if (s3 && s3.hasValue()) {
      const t3 = vv(e2, s3.getCenterPoint());
      t3 < a2 && (a2 = t3, n2 = s3);
    }
  }
  if (n2) {
    const t3 = n2.tooltipPosition();
    r2 = t3.x, o2 = t3.y;
  }
  return { x: r2, y: o2 };
} };
function Hw(t2, e2) {
  return e2 && ($g(e2) ? Array.prototype.push.apply(t2, e2) : t2.push(e2)), t2;
}
function Uw(t2) {
  return ("string" == typeof t2 || t2 instanceof String) && t2.indexOf("\n") > -1 ? t2.split("\n") : t2;
}
function Kw(t2, e2) {
  const { element: i2, datasetIndex: s2, index: n2 } = e2, r2 = t2.getDatasetMeta(s2).controller, { label: o2, value: a2 } = r2.getLabelAndValue(n2);
  return { chart: t2, label: o2, parsed: r2.getParsed(n2), raw: t2.data.datasets[s2].data[n2], formattedValue: a2, dataset: r2.getDataset(), dataIndex: n2, datasetIndex: s2, element: i2 };
}
function Yw(t2, e2) {
  const i2 = t2.chart.ctx, { body: s2, footer: n2, title: r2 } = t2, { boxWidth: o2, boxHeight: a2 } = e2, l2 = xb(e2.bodyFont), h2 = xb(e2.titleFont), c2 = xb(e2.footerFont), u2 = r2.length, d2 = n2.length, f2 = s2.length, p2 = wb(e2.padding);
  let m2 = p2.height, g2 = 0, v2 = s2.reduce((t3, e3) => t3 + e3.before.length + e3.lines.length + e3.after.length, 0);
  v2 += t2.beforeBody.length + t2.afterBody.length, u2 && (m2 += u2 * h2.lineHeight + (u2 - 1) * e2.titleSpacing + e2.titleMarginBottom), v2 && (m2 += f2 * (e2.displayColors ? Math.max(a2, l2.lineHeight) : l2.lineHeight) + (v2 - f2) * l2.lineHeight + (v2 - 1) * e2.bodySpacing), d2 && (m2 += e2.footerMarginTop + d2 * c2.lineHeight + (d2 - 1) * e2.footerSpacing);
  let b2 = 0;
  const _2 = function(t3) {
    g2 = Math.max(g2, i2.measureText(t3).width + b2);
  };
  return i2.save(), i2.font = h2.string, Ng(t2.title, _2), i2.font = l2.string, Ng(t2.beforeBody.concat(t2.afterBody), _2), b2 = e2.displayColors ? o2 + 2 + e2.boxPadding : 0, Ng(s2, (t3) => {
    Ng(t3.before, _2), Ng(t3.lines, _2), Ng(t3.after, _2);
  }), b2 = 0, i2.font = c2.string, Ng(t2.footer, _2), i2.restore(), g2 += p2.width, { width: g2, height: m2 };
}
function Gw(t2, e2, i2, s2) {
  const { x: n2, width: r2 } = i2, { width: o2, chartArea: { left: a2, right: l2 } } = t2;
  let h2 = "center";
  return "center" === s2 ? h2 = n2 <= (a2 + l2) / 2 ? "left" : "right" : n2 <= r2 / 2 ? h2 = "left" : n2 >= o2 - r2 / 2 && (h2 = "right"), function(t3, e3, i3, s3) {
    const { x: n3, width: r3 } = s3, o3 = i3.caretSize + i3.caretPadding;
    return "left" === t3 && n3 + r3 + o3 > e3.width || "right" === t3 && n3 - r3 - o3 < 0 || void 0;
  }(h2, t2, e2, i2) && (h2 = "center"), h2;
}
function Xw(t2, e2, i2) {
  const s2 = i2.yAlign || e2.yAlign || function(t3, e3) {
    const { y: i3, height: s3 } = e3;
    return i3 < s3 / 2 ? "top" : i3 > t3.height - s3 / 2 ? "bottom" : "center";
  }(t2, i2);
  return { xAlign: i2.xAlign || e2.xAlign || Gw(t2, e2, i2, s2), yAlign: s2 };
}
function Jw(t2, e2, i2, s2) {
  const { caretSize: n2, caretPadding: r2, cornerRadius: o2 } = t2, { xAlign: a2, yAlign: l2 } = i2, h2 = n2 + r2, { topLeft: c2, topRight: u2, bottomLeft: d2, bottomRight: f2 } = yb(o2);
  let p2 = function(t3, e3) {
    let { x: i3, width: s3 } = t3;
    return "right" === e3 ? i3 -= s3 : "center" === e3 && (i3 -= s3 / 2), i3;
  }(e2, a2);
  const m2 = function(t3, e3, i3) {
    let { y: s3, height: n3 } = t3;
    return "top" === e3 ? s3 += i3 : s3 -= "bottom" === e3 ? n3 + i3 : n3 / 2, s3;
  }(e2, l2, h2);
  return "center" === l2 ? "left" === a2 ? p2 += h2 : "right" === a2 && (p2 -= h2) : "left" === a2 ? p2 -= Math.max(c2, d2) + n2 : "right" === a2 && (p2 += Math.max(u2, f2) + n2), { x: wv(p2, 0, s2.width - e2.width), y: wv(m2, 0, s2.height - e2.height) };
}
function Qw(t2, e2, i2) {
  const s2 = wb(i2.padding);
  return "center" === e2 ? t2.x + t2.width / 2 : "right" === e2 ? t2.x + t2.width - s2.right : t2.x + s2.left;
}
function Zw(t2) {
  return Hw([], Uw(t2));
}
function tx(t2, e2) {
  const i2 = e2 && e2.dataset && e2.dataset.tooltip && e2.dataset.tooltip.callbacks;
  return i2 ? t2.override(i2) : t2;
}
const ex = { beforeTitle: Rg, title(t2) {
  if (t2.length > 0) {
    const e2 = t2[0], i2 = e2.chart.data.labels, s2 = i2 ? i2.length : 0;
    if (this && this.options && "dataset" === this.options.mode) return e2.dataset.label || "";
    if (e2.label) return e2.label;
    if (s2 > 0 && e2.dataIndex < s2) return i2[e2.dataIndex];
  }
  return "";
}, afterTitle: Rg, beforeBody: Rg, beforeLabel: Rg, label(t2) {
  if (this && this.options && "dataset" === this.options.mode) return t2.label + ": " + t2.formattedValue || t2.formattedValue;
  let e2 = t2.dataset.label || "";
  e2 && (e2 += ": ");
  const i2 = t2.formattedValue;
  return Tg(i2) || (e2 += i2), e2;
}, labelColor(t2) {
  const e2 = t2.chart.getDatasetMeta(t2.datasetIndex).controller.getStyle(t2.dataIndex);
  return { borderColor: e2.borderColor, backgroundColor: e2.backgroundColor, borderWidth: e2.borderWidth, borderDash: e2.borderDash, borderDashOffset: e2.borderDashOffset, borderRadius: 0 };
}, labelTextColor() {
  return this.options.bodyColor;
}, labelPointStyle(t2) {
  const e2 = t2.chart.getDatasetMeta(t2.datasetIndex).controller.getStyle(t2.dataIndex);
  return { pointStyle: e2.pointStyle, rotation: e2.rotation };
}, afterLabel: Rg, afterBody: Rg, beforeFooter: Rg, footer: Rg, afterFooter: Rg };
function ix(t2, e2, i2, s2) {
  const n2 = t2[e2].call(i2, s2);
  return void 0 === n2 ? ex[e2].call(i2, s2) : n2;
}
class Tooltip extends by {
  constructor(t2) {
    super(), this.opacity = 0, this._active = [], this._eventPosition = void 0, this._size = void 0, this._cachedAnimations = void 0, this._tooltipItems = [], this.$animations = void 0, this.$context = void 0, this.chart = t2.chart, this.options = t2.options, this.dataPoints = void 0, this.title = void 0, this.beforeBody = void 0, this.body = void 0, this.afterBody = void 0, this.footer = void 0, this.xAlign = void 0, this.yAlign = void 0, this.x = void 0, this.y = void 0, this.height = void 0, this.width = void 0, this.caretX = void 0, this.caretY = void 0, this.labelColors = void 0, this.labelPointStyles = void 0, this.labelTextColors = void 0;
  }
  initialize(t2) {
    this.options = t2, this._cachedAnimations = void 0, this.$context = void 0;
  }
  _resolveAnimations() {
    const t2 = this._cachedAnimations;
    if (t2) return t2;
    const e2 = this.chart, i2 = this.options.setContext(this.getContext()), s2 = i2.enabled && e2.options.animation && i2.animations, n2 = new Animations(this.chart, s2);
    return s2._cacheable && (this._cachedAnimations = Object.freeze(n2)), n2;
  }
  getContext() {
    return this.$context || (this.$context = Sb(this.chart.getContext(), { tooltip: this, tooltipItems: this._tooltipItems, type: "tooltip" }));
  }
  getTitle(t2, e2) {
    const { callbacks: i2 } = e2, s2 = ix(i2, "beforeTitle", this, t2), n2 = ix(i2, "title", this, t2), r2 = ix(i2, "afterTitle", this, t2);
    let o2 = [];
    return o2 = Hw(o2, Uw(s2)), o2 = Hw(o2, Uw(n2)), o2 = Hw(o2, Uw(r2)), o2;
  }
  getBeforeBody(t2, e2) {
    return Zw(ix(e2.callbacks, "beforeBody", this, t2));
  }
  getBody(t2, e2) {
    const { callbacks: i2 } = e2, s2 = [];
    return Ng(t2, (t3) => {
      const e3 = { before: [], lines: [], after: [] }, n2 = tx(i2, t3);
      Hw(e3.before, Uw(ix(n2, "beforeLabel", this, t3))), Hw(e3.lines, ix(n2, "label", this, t3)), Hw(e3.after, Uw(ix(n2, "afterLabel", this, t3))), s2.push(e3);
    }), s2;
  }
  getAfterBody(t2, e2) {
    return Zw(ix(e2.callbacks, "afterBody", this, t2));
  }
  getFooter(t2, e2) {
    const { callbacks: i2 } = e2, s2 = ix(i2, "beforeFooter", this, t2), n2 = ix(i2, "footer", this, t2), r2 = ix(i2, "afterFooter", this, t2);
    let o2 = [];
    return o2 = Hw(o2, Uw(s2)), o2 = Hw(o2, Uw(n2)), o2 = Hw(o2, Uw(r2)), o2;
  }
  _createItems(t2) {
    const e2 = this._active, i2 = this.chart.data, s2 = [], n2 = [], r2 = [];
    let o2, a2, l2 = [];
    for (o2 = 0, a2 = e2.length; o2 < a2; ++o2) l2.push(Kw(this.chart, e2[o2]));
    return t2.filter && (l2 = l2.filter((e3, s3, n3) => t2.filter(e3, s3, n3, i2))), t2.itemSort && (l2 = l2.sort((e3, s3) => t2.itemSort(e3, s3, i2))), Ng(l2, (e3) => {
      const i3 = tx(t2.callbacks, e3);
      s2.push(ix(i3, "labelColor", this, e3)), n2.push(ix(i3, "labelPointStyle", this, e3)), r2.push(ix(i3, "labelTextColor", this, e3));
    }), this.labelColors = s2, this.labelPointStyles = n2, this.labelTextColors = r2, this.dataPoints = l2, l2;
  }
  update(t2, e2) {
    const i2 = this.options.setContext(this.getContext()), s2 = this._active;
    let n2, r2 = [];
    if (s2.length) {
      const t3 = qw[i2.position].call(this, s2, this._eventPosition);
      r2 = this._createItems(i2), this.title = this.getTitle(r2, i2), this.beforeBody = this.getBeforeBody(r2, i2), this.body = this.getBody(r2, i2), this.afterBody = this.getAfterBody(r2, i2), this.footer = this.getFooter(r2, i2);
      const e3 = this._size = Yw(this, i2), o2 = Object.assign({}, t3, e3), a2 = Xw(this.chart, i2, o2), l2 = Jw(i2, o2, a2, this.chart);
      this.xAlign = a2.xAlign, this.yAlign = a2.yAlign, n2 = { opacity: 1, x: l2.x, y: l2.y, width: e3.width, height: e3.height, caretX: t3.x, caretY: t3.y };
    } else 0 !== this.opacity && (n2 = { opacity: 0 });
    this._tooltipItems = r2, this.$context = void 0, n2 && this._resolveAnimations().update(this, n2), t2 && i2.external && i2.external.call(this, { chart: this.chart, tooltip: this, replay: e2 });
  }
  drawCaret(t2, e2, i2, s2) {
    const n2 = this.getCaretPosition(t2, i2, s2);
    e2.lineTo(n2.x1, n2.y1), e2.lineTo(n2.x2, n2.y2), e2.lineTo(n2.x3, n2.y3);
  }
  getCaretPosition(t2, e2, i2) {
    const { xAlign: s2, yAlign: n2 } = this, { caretSize: r2, cornerRadius: o2 } = i2, { topLeft: a2, topRight: l2, bottomLeft: h2, bottomRight: c2 } = yb(o2), { x: u2, y: d2 } = t2, { width: f2, height: p2 } = e2;
    let m2, g2, v2, b2, _2, y2;
    return "center" === n2 ? (_2 = d2 + p2 / 2, "left" === s2 ? (m2 = u2, g2 = m2 - r2, b2 = _2 + r2, y2 = _2 - r2) : (m2 = u2 + f2, g2 = m2 + r2, b2 = _2 - r2, y2 = _2 + r2), v2 = m2) : (g2 = "left" === s2 ? u2 + Math.max(a2, h2) + r2 : "right" === s2 ? u2 + f2 - Math.max(l2, c2) - r2 : this.caretX, "top" === n2 ? (b2 = d2, _2 = b2 - r2, m2 = g2 - r2, v2 = g2 + r2) : (b2 = d2 + p2, _2 = b2 + r2, m2 = g2 + r2, v2 = g2 - r2), y2 = b2), { x1: m2, x2: g2, x3: v2, y1: b2, y2: _2, y3: y2 };
  }
  drawTitle(t2, e2, i2) {
    const s2 = this.title, n2 = s2.length;
    let r2, o2, a2;
    if (n2) {
      const l2 = n_(i2.rtl, this.x, this.width);
      for (t2.x = Qw(this, i2.titleAlign, i2), e2.textAlign = l2.textAlign(i2.titleAlign), e2.textBaseline = "middle", r2 = xb(i2.titleFont), o2 = i2.titleSpacing, e2.fillStyle = i2.titleColor, e2.font = r2.string, a2 = 0; a2 < n2; ++a2) e2.fillText(s2[a2], l2.x(t2.x), t2.y + r2.lineHeight / 2), t2.y += r2.lineHeight + o2, a2 + 1 === n2 && (t2.y += i2.titleMarginBottom - o2);
    }
  }
  _drawColorBox(t2, e2, i2, s2, n2) {
    const r2 = this.labelColors[i2], o2 = this.labelPointStyles[i2], { boxHeight: a2, boxWidth: l2 } = n2, h2 = xb(n2.bodyFont), c2 = Qw(this, "left", n2), u2 = s2.x(c2), d2 = a2 < h2.lineHeight ? (h2.lineHeight - a2) / 2 : 0, f2 = e2.y + d2;
    if (n2.usePointStyle) {
      const e3 = { radius: Math.min(l2, a2) / 2, pointStyle: o2.pointStyle, rotation: o2.rotation, borderWidth: 1 }, i3 = s2.leftForLtr(u2, l2) + l2 / 2, h3 = f2 + a2 / 2;
      t2.strokeStyle = n2.multiKeyBackground, t2.fillStyle = n2.multiKeyBackground, sb(t2, e3, i3, h3), t2.strokeStyle = r2.borderColor, t2.fillStyle = r2.backgroundColor, sb(t2, e3, i3, h3);
    } else {
      t2.lineWidth = Eg(r2.borderWidth) ? Math.max(...Object.values(r2.borderWidth)) : r2.borderWidth || 1, t2.strokeStyle = r2.borderColor, t2.setLineDash(r2.borderDash || []), t2.lineDashOffset = r2.borderDashOffset || 0;
      const e3 = s2.leftForLtr(u2, l2), i3 = s2.leftForLtr(s2.xPlus(u2, 1), l2 - 2), o3 = yb(r2.borderRadius);
      Object.values(o3).some((t3) => 0 !== t3) ? (t2.beginPath(), t2.fillStyle = n2.multiKeyBackground, fb(t2, { x: e3, y: f2, w: l2, h: a2, radius: o3 }), t2.fill(), t2.stroke(), t2.fillStyle = r2.backgroundColor, t2.beginPath(), fb(t2, { x: i3, y: f2 + 1, w: l2 - 2, h: a2 - 2, radius: o3 }), t2.fill()) : (t2.fillStyle = n2.multiKeyBackground, t2.fillRect(e3, f2, l2, a2), t2.strokeRect(e3, f2, l2, a2), t2.fillStyle = r2.backgroundColor, t2.fillRect(i3, f2 + 1, l2 - 2, a2 - 2));
    }
    t2.fillStyle = this.labelTextColors[i2];
  }
  drawBody(t2, e2, i2) {
    const { body: s2 } = this, { bodySpacing: n2, bodyAlign: r2, displayColors: o2, boxHeight: a2, boxWidth: l2, boxPadding: h2 } = i2, c2 = xb(i2.bodyFont);
    let u2 = c2.lineHeight, d2 = 0;
    const f2 = n_(i2.rtl, this.x, this.width), p2 = function(i3) {
      e2.fillText(i3, f2.x(t2.x + d2), t2.y + u2 / 2), t2.y += u2 + n2;
    }, m2 = f2.textAlign(r2);
    let g2, v2, b2, _2, y2, w2, x2;
    for (e2.textAlign = r2, e2.textBaseline = "middle", e2.font = c2.string, t2.x = Qw(this, m2, i2), e2.fillStyle = i2.bodyColor, Ng(this.beforeBody, p2), d2 = o2 && "right" !== m2 ? "center" === r2 ? l2 / 2 + h2 : l2 + 2 + h2 : 0, _2 = 0, w2 = s2.length; _2 < w2; ++_2) {
      for (g2 = s2[_2], v2 = this.labelTextColors[_2], e2.fillStyle = v2, Ng(g2.before, p2), b2 = g2.lines, o2 && b2.length && (this._drawColorBox(e2, t2, _2, f2, i2), u2 = Math.max(c2.lineHeight, a2)), y2 = 0, x2 = b2.length; y2 < x2; ++y2) p2(b2[y2]), u2 = c2.lineHeight;
      Ng(g2.after, p2);
    }
    d2 = 0, u2 = c2.lineHeight, Ng(this.afterBody, p2), t2.y -= n2;
  }
  drawFooter(t2, e2, i2) {
    const s2 = this.footer, n2 = s2.length;
    let r2, o2;
    if (n2) {
      const a2 = n_(i2.rtl, this.x, this.width);
      for (t2.x = Qw(this, i2.footerAlign, i2), t2.y += i2.footerMarginTop, e2.textAlign = a2.textAlign(i2.footerAlign), e2.textBaseline = "middle", r2 = xb(i2.footerFont), e2.fillStyle = i2.footerColor, e2.font = r2.string, o2 = 0; o2 < n2; ++o2) e2.fillText(s2[o2], a2.x(t2.x), t2.y + r2.lineHeight / 2), t2.y += r2.lineHeight + i2.footerSpacing;
    }
  }
  drawBackground(t2, e2, i2, s2) {
    const { xAlign: n2, yAlign: r2 } = this, { x: o2, y: a2 } = t2, { width: l2, height: h2 } = i2, { topLeft: c2, topRight: u2, bottomLeft: d2, bottomRight: f2 } = yb(s2.cornerRadius);
    e2.fillStyle = s2.backgroundColor, e2.strokeStyle = s2.borderColor, e2.lineWidth = s2.borderWidth, e2.beginPath(), e2.moveTo(o2 + c2, a2), "top" === r2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + l2 - u2, a2), e2.quadraticCurveTo(o2 + l2, a2, o2 + l2, a2 + u2), "center" === r2 && "right" === n2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + l2, a2 + h2 - f2), e2.quadraticCurveTo(o2 + l2, a2 + h2, o2 + l2 - f2, a2 + h2), "bottom" === r2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2 + d2, a2 + h2), e2.quadraticCurveTo(o2, a2 + h2, o2, a2 + h2 - d2), "center" === r2 && "left" === n2 && this.drawCaret(t2, e2, i2, s2), e2.lineTo(o2, a2 + c2), e2.quadraticCurveTo(o2, a2, o2 + c2, a2), e2.closePath(), e2.fill(), s2.borderWidth > 0 && e2.stroke();
  }
  _updateAnimationTarget(t2) {
    const e2 = this.chart, i2 = this.$animations, s2 = i2 && i2.x, n2 = i2 && i2.y;
    if (s2 || n2) {
      const i3 = qw[t2.position].call(this, this._active, this._eventPosition);
      if (!i3) return;
      const r2 = this._size = Yw(this, t2), o2 = Object.assign({}, i3, this._size), a2 = Xw(e2, t2, o2), l2 = Jw(t2, o2, a2, e2);
      s2._to === l2.x && n2._to === l2.y || (this.xAlign = a2.xAlign, this.yAlign = a2.yAlign, this.width = r2.width, this.height = r2.height, this.caretX = i3.x, this.caretY = i3.y, this._resolveAnimations().update(this, l2));
    }
  }
  _willRender() {
    return !!this.opacity;
  }
  draw(t2) {
    const e2 = this.options.setContext(this.getContext());
    let i2 = this.opacity;
    if (!i2) return;
    this._updateAnimationTarget(e2);
    const s2 = { width: this.width, height: this.height }, n2 = { x: this.x, y: this.y };
    i2 = Math.abs(i2) < 1e-3 ? 0 : i2;
    const r2 = wb(e2.padding), o2 = this.title.length || this.beforeBody.length || this.body.length || this.afterBody.length || this.footer.length;
    e2.enabled && o2 && (t2.save(), t2.globalAlpha = i2, this.drawBackground(n2, t2, s2, e2), r_(t2, e2.textDirection), n2.y += r2.top, this.drawTitle(n2, t2, e2), this.drawBody(n2, t2, e2), this.drawFooter(n2, t2, e2), o_(t2, e2.textDirection), t2.restore());
  }
  getActiveElements() {
    return this._active || [];
  }
  setActiveElements(t2, e2) {
    const i2 = this._active, s2 = t2.map(({ datasetIndex: t3, index: e3 }) => {
      const i3 = this.chart.getDatasetMeta(t3);
      if (!i3) throw new Error("Cannot find a dataset at index " + t3);
      return { datasetIndex: t3, element: i3.data[e3], index: e3 };
    }), n2 = !Fg(i2, s2), r2 = this._positionChanged(s2, e2);
    (n2 || r2) && (this._active = s2, this._eventPosition = e2, this._ignoreReplayEvents = true, this.update(true));
  }
  handleEvent(t2, e2, i2 = true) {
    if (e2 && this._ignoreReplayEvents) return false;
    this._ignoreReplayEvents = false;
    const s2 = this.options, n2 = this._active || [], r2 = this._getActiveElements(t2, n2, e2, i2), o2 = this._positionChanged(r2, t2), a2 = e2 || !Fg(r2, n2) || o2;
    return a2 && (this._active = r2, (s2.enabled || s2.external) && (this._eventPosition = { x: t2.x, y: t2.y }, this.update(true, e2))), a2;
  }
  _getActiveElements(t2, e2, i2, s2) {
    const n2 = this.options;
    if ("mouseout" === t2.type) return [];
    if (!s2) return e2.filter((t3) => this.chart.data.datasets[t3.datasetIndex] && void 0 !== this.chart.getDatasetMeta(t3.datasetIndex).controller.getParsed(t3.index));
    const r2 = this.chart.getElementsAtEventForMode(t2, n2.mode, n2, i2);
    return n2.reverse && r2.reverse(), r2;
  }
  _positionChanged(t2, e2) {
    const { caretX: i2, caretY: s2, options: n2 } = this, r2 = qw[n2.position].call(this, t2, e2);
    return false !== r2 && (i2 !== r2.x || s2 !== r2.y);
  }
}
__publicField(Tooltip, "positioners", qw);
var sx = { id: "tooltip", _element: Tooltip, positioners: qw, afterInit(t2, e2, i2) {
  i2 && (t2.tooltip = new Tooltip({ chart: t2, options: i2 }));
}, beforeUpdate(t2, e2, i2) {
  t2.tooltip && t2.tooltip.initialize(i2);
}, reset(t2, e2, i2) {
  t2.tooltip && t2.tooltip.initialize(i2);
}, afterDraw(t2) {
  const e2 = t2.tooltip;
  if (e2 && e2._willRender()) {
    const i2 = { tooltip: e2 };
    if (false === t2.notifyPlugins("beforeTooltipDraw", { ...i2, cancelable: true })) return;
    e2.draw(t2.ctx), t2.notifyPlugins("afterTooltipDraw", i2);
  }
}, afterEvent(t2, e2) {
  if (t2.tooltip) {
    const i2 = e2.replay;
    t2.tooltip.handleEvent(e2.event, i2, e2.inChartArea) && (e2.changed = true);
  }
}, defaults: { enabled: true, external: null, position: "average", backgroundColor: "rgba(0,0,0,0.8)", titleColor: "#fff", titleFont: { weight: "bold" }, titleSpacing: 2, titleMarginBottom: 6, titleAlign: "left", bodyColor: "#fff", bodySpacing: 2, bodyFont: {}, bodyAlign: "left", footerColor: "#fff", footerSpacing: 2, footerMarginTop: 6, footerFont: { weight: "bold" }, footerAlign: "left", padding: 6, caretPadding: 2, caretSize: 5, cornerRadius: 6, boxHeight: (t2, e2) => e2.bodyFont.size, boxWidth: (t2, e2) => e2.bodyFont.size, multiKeyBackground: "#fff", displayColors: true, boxPadding: 0, borderColor: "rgba(0,0,0,0)", borderWidth: 0, animation: { duration: 400, easing: "easeOutQuart" }, animations: { numbers: { type: "number", properties: ["x", "y", "width", "height", "caretX", "caretY"] }, opacity: { easing: "linear", duration: 200 } }, callbacks: ex }, defaultRoutes: { bodyFont: "font", footerFont: "font", titleFont: "font" }, descriptors: { _scriptable: (t2) => "filter" !== t2 && "itemSort" !== t2 && "external" !== t2, _indexable: false, callbacks: { _scriptable: false, _indexable: false }, animation: { _fallback: false }, animations: { _fallback: "animation" } }, additionalOptionScopes: ["interaction"] }, nx = Object.freeze({ __proto__: null, Colors: _w, Decimation: xw, Filler: Ow, Legend: Fw, SubTitle: jw, Title: Ww, Tooltip: sx });
function rx(t2) {
  const e2 = this.getLabels();
  return t2 >= 0 && t2 < e2.length ? e2[t2] : t2;
}
class CategoryScale extends Scale {
  constructor(t2) {
    super(t2), this._startValue = void 0, this._valueRange = 0, this._addedLabels = [];
  }
  init(t2) {
    const e2 = this._addedLabels;
    if (e2.length) {
      const t3 = this.getLabels();
      for (const { index: i2, label: s2 } of e2) t3[i2] === s2 && t3.splice(i2, 1);
      this._addedLabels = [];
    }
    super.init(t2);
  }
  parse(t2, e2) {
    if (Tg(t2)) return null;
    const i2 = this.getLabels();
    return ((t3, e3) => null === t3 ? null : wv(Math.round(t3), 0, e3))(e2 = isFinite(e2) && i2[e2] === t2 ? e2 : function(t3, e3, i3, s2) {
      const n2 = t3.indexOf(e3);
      return -1 === n2 ? ((t4, e4, i4, s3) => ("string" == typeof e4 ? (i4 = t4.push(e4) - 1, s3.unshift({ index: i4, label: e4 })) : isNaN(e4) && (i4 = null), i4))(t3, e3, i3, s2) : n2 !== t3.lastIndexOf(e3) ? i3 : n2;
    }(i2, t2, Vg(e2, t2), this._addedLabels), i2.length - 1);
  }
  determineDataLimits() {
    const { minDefined: t2, maxDefined: e2 } = this.getUserBounds();
    let { min: i2, max: s2 } = this.getMinMax(true);
    "ticks" === this.options.bounds && (t2 || (i2 = 0), e2 || (s2 = this.getLabels().length - 1)), this.min = i2, this.max = s2;
  }
  buildTicks() {
    const t2 = this.min, e2 = this.max, i2 = this.options.offset, s2 = [];
    let n2 = this.getLabels();
    n2 = 0 === t2 && e2 === n2.length - 1 ? n2 : n2.slice(t2, e2 + 1), this._valueRange = Math.max(n2.length - (i2 ? 0 : 1), 1), this._startValue = this.min - (i2 ? 0.5 : 0);
    for (let i3 = t2; i3 <= e2; i3++) s2.push({ value: i3 });
    return s2;
  }
  getLabelForValue(t2) {
    return rx.call(this, t2);
  }
  configure() {
    super.configure(), this.isHorizontal() || (this._reversePixels = !this._reversePixels);
  }
  getPixelForValue(t2) {
    return "number" != typeof t2 && (t2 = this.parse(t2)), null === t2 ? NaN : this.getPixelForDecimal((t2 - this._startValue) / this._valueRange);
  }
  getPixelForTick(t2) {
    const e2 = this.ticks;
    return t2 < 0 || t2 > e2.length - 1 ? null : this.getPixelForValue(e2[t2].value);
  }
  getValueForPixel(t2) {
    return Math.round(this._startValue + this.getDecimalForPixel(t2) * this._valueRange);
  }
  getBasePixel() {
    return this.bottom;
  }
}
__publicField(CategoryScale, "id", "category");
__publicField(CategoryScale, "defaults", { ticks: { callback: rx } });
function ox(t2, e2, { horizontal: i2, minRotation: s2 }) {
  const n2 = fv(s2), r2 = (i2 ? Math.sin(n2) : Math.cos(n2)) || 1e-3, o2 = 0.75 * e2 * ("" + t2).length;
  return Math.min(e2 / r2, o2);
}
class LinearScaleBase extends Scale {
  constructor(t2) {
    super(t2), this.start = void 0, this.end = void 0, this._startValue = void 0, this._endValue = void 0, this._valueRange = 0;
  }
  parse(t2, e2) {
    return Tg(t2) || ("number" == typeof t2 || t2 instanceof Number) && !isFinite(+t2) ? null : +t2;
  }
  handleTickRangeOptions() {
    const { beginAtZero: t2 } = this.options, { minDefined: e2, maxDefined: i2 } = this.getUserBounds();
    let { min: s2, max: n2 } = this;
    const r2 = (t3) => s2 = e2 ? s2 : t3, o2 = (t3) => n2 = i2 ? n2 : t3;
    if (t2) {
      const t3 = lv(s2), e3 = lv(n2);
      t3 < 0 && e3 < 0 ? o2(0) : t3 > 0 && e3 > 0 && r2(0);
    }
    if (s2 === n2) {
      let e3 = 0 === n2 ? 1 : Math.abs(0.05 * n2);
      o2(n2 + e3), t2 || r2(s2 - e3);
    }
    this.min = s2, this.max = n2;
  }
  getTickLimit() {
    const t2 = this.options.ticks;
    let e2, { maxTicksLimit: i2, stepSize: s2 } = t2;
    return s2 ? (e2 = Math.ceil(this.max / s2) - Math.floor(this.min / s2) + 1, e2 > 1e3 && (e2 = 1e3)) : (e2 = this.computeTickLimit(), i2 = i2 || 11), i2 && (e2 = Math.min(i2, e2)), e2;
  }
  computeTickLimit() {
    return Number.POSITIVE_INFINITY;
  }
  buildTicks() {
    const t2 = this.options, e2 = t2.ticks;
    let i2 = this.getTickLimit();
    i2 = Math.max(2, i2);
    const s2 = function(t3, e3) {
      const i3 = [], { bounds: s3, step: n2, min: r2, max: o2, precision: a2, count: l2, maxTicks: h2, maxDigits: c2, includeBounds: u2 } = t3, d2 = n2 || 1, f2 = h2 - 1, { min: p2, max: m2 } = e3, g2 = !Tg(r2), v2 = !Tg(o2), b2 = !Tg(l2), _2 = (m2 - p2) / (c2 + 1);
      let y2, w2, x2, k2, S2 = cv((m2 - p2) / f2 / d2) * d2;
      if (S2 < 1e-14 && !g2 && !v2) return [{ value: p2 }, { value: m2 }];
      k2 = Math.ceil(m2 / S2) - Math.floor(p2 / S2), k2 > f2 && (S2 = cv(k2 * S2 / f2 / d2) * d2), Tg(a2) || (y2 = Math.pow(10, a2), S2 = Math.ceil(S2 * y2) / y2), "ticks" === s3 ? (w2 = Math.floor(p2 / S2) * S2, x2 = Math.ceil(m2 / S2) * S2) : (w2 = p2, x2 = m2), g2 && v2 && n2 && function(t4, e4) {
        const i4 = Math.round(t4);
        return i4 - e4 <= t4 && i4 + e4 >= t4;
      }((o2 - r2) / n2, S2 / 1e3) ? (k2 = Math.round(Math.min((o2 - r2) / S2, h2)), S2 = (o2 - r2) / k2, w2 = r2, x2 = o2) : b2 ? (w2 = g2 ? r2 : w2, x2 = v2 ? o2 : x2, k2 = l2 - 1, S2 = (x2 - w2) / k2) : (k2 = (x2 - w2) / S2, k2 = hv(k2, Math.round(k2), S2 / 1e3) ? Math.round(k2) : Math.ceil(k2));
      const M2 = Math.max(mv(S2), mv(w2));
      y2 = Math.pow(10, Tg(a2) ? M2 : a2), w2 = Math.round(w2 * y2) / y2, x2 = Math.round(x2 * y2) / y2;
      let z2 = 0;
      for (g2 && (u2 && w2 !== r2 ? (i3.push({ value: r2 }), w2 < r2 && z2++, hv(Math.round((w2 + z2 * S2) * y2) / y2, r2, ox(r2, _2, t3)) && z2++) : w2 < r2 && z2++); z2 < k2; ++z2) {
        const t4 = Math.round((w2 + z2 * S2) * y2) / y2;
        if (v2 && t4 > o2) break;
        i3.push({ value: t4 });
      }
      return v2 && u2 && x2 !== o2 ? i3.length && hv(i3[i3.length - 1].value, o2, ox(o2, _2, t3)) ? i3[i3.length - 1].value = o2 : i3.push({ value: o2 }) : v2 && x2 !== o2 || i3.push({ value: x2 }), i3;
    }({ maxTicks: i2, bounds: t2.bounds, min: t2.min, max: t2.max, precision: e2.precision, step: e2.stepSize, count: e2.count, maxDigits: this._maxDigits(), horizontal: this.isHorizontal(), minRotation: e2.minRotation || 0, includeBounds: false !== e2.includeBounds }, this._range || this);
    return "ticks" === t2.bounds && dv(s2, this, "value"), t2.reverse ? (s2.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), s2;
  }
  configure() {
    const t2 = this.ticks;
    let e2 = this.min, i2 = this.max;
    if (super.configure(), this.options.offset && t2.length) {
      const s2 = (i2 - e2) / Math.max(t2.length - 1, 1) / 2;
      e2 -= s2, i2 += s2;
    }
    this._startValue = e2, this._endValue = i2, this._valueRange = i2 - e2;
  }
  getLabelForValue(t2) {
    return Hv(t2, this.chart.options.locale, this.options.ticks.format);
  }
}
class LinearScale extends LinearScaleBase {
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(true);
    this.min = Ag(t2) ? t2 : 0, this.max = Ag(e2) ? e2 : 1, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    const t2 = this.isHorizontal(), e2 = t2 ? this.width : this.height, i2 = fv(this.options.ticks.minRotation), s2 = (t2 ? Math.sin(i2) : Math.cos(i2)) || 1e-3, n2 = this._resolveTickFontOptions(0);
    return Math.ceil(e2 / Math.min(40, n2.lineHeight / s2));
  }
  getPixelForValue(t2) {
    return null === t2 ? NaN : this.getPixelForDecimal((t2 - this._startValue) / this._valueRange);
  }
  getValueForPixel(t2) {
    return this._startValue + this.getDecimalForPixel(t2) * this._valueRange;
  }
}
__publicField(LinearScale, "id", "linear");
__publicField(LinearScale, "defaults", { ticks: { callback: Kv.formatters.numeric } });
const ax = (t2) => Math.floor(av(t2)), lx = (t2, e2) => Math.pow(10, ax(t2) + e2);
function hx(t2) {
  return 1 === t2 / Math.pow(10, ax(t2));
}
function cx(t2, e2, i2) {
  const s2 = Math.pow(10, i2), n2 = Math.floor(t2 / s2);
  return Math.ceil(e2 / s2) - n2;
}
class LogarithmicScale extends Scale {
  constructor(t2) {
    super(t2), this.start = void 0, this.end = void 0, this._startValue = void 0, this._valueRange = 0;
  }
  parse(t2, e2) {
    const i2 = LinearScaleBase.prototype.parse.apply(this, [t2, e2]);
    if (0 !== i2) return Ag(i2) && i2 > 0 ? i2 : null;
    this._zero = true;
  }
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(true);
    this.min = Ag(t2) ? Math.max(0, t2) : null, this.max = Ag(e2) ? Math.max(0, e2) : null, this.options.beginAtZero && (this._zero = true), this._zero && this.min !== this._suggestedMin && !Ag(this._userMin) && (this.min = t2 === lx(this.min, 0) ? lx(this.min, -1) : lx(this.min, 0)), this.handleTickRangeOptions();
  }
  handleTickRangeOptions() {
    const { minDefined: t2, maxDefined: e2 } = this.getUserBounds();
    let i2 = this.min, s2 = this.max;
    const n2 = (e3) => i2 = t2 ? i2 : e3, r2 = (t3) => s2 = e2 ? s2 : t3;
    i2 === s2 && (i2 <= 0 ? (n2(1), r2(10)) : (n2(lx(i2, -1)), r2(lx(s2, 1)))), i2 <= 0 && n2(lx(s2, -1)), s2 <= 0 && r2(lx(i2, 1)), this.min = i2, this.max = s2;
  }
  buildTicks() {
    const t2 = this.options, e2 = function(t3, { min: e3, max: i2 }) {
      e3 = Lg(t3.min, e3);
      const s2 = [], n2 = ax(e3);
      let r2 = function(t4, e4) {
        let i3 = ax(e4 - t4);
        for (; cx(t4, e4, i3) > 10; ) i3++;
        for (; cx(t4, e4, i3) < 10; ) i3--;
        return Math.min(i3, ax(t4));
      }(e3, i2), o2 = r2 < 0 ? Math.pow(10, Math.abs(r2)) : 1;
      const a2 = Math.pow(10, r2), l2 = n2 > r2 ? Math.pow(10, n2) : 0, h2 = Math.round((e3 - l2) * o2) / o2, c2 = Math.floor((e3 - l2) / a2 / 10) * a2 * 10;
      let u2 = Math.floor((h2 - c2) / Math.pow(10, r2)), d2 = Lg(t3.min, Math.round((l2 + c2 + u2 * Math.pow(10, r2)) * o2) / o2);
      for (; d2 < i2; ) s2.push({ value: d2, major: hx(d2), significand: u2 }), u2 >= 10 ? u2 = u2 < 15 ? 15 : 20 : u2++, u2 >= 20 && (r2++, u2 = 2, o2 = r2 >= 0 ? 1 : o2), d2 = Math.round((l2 + c2 + u2 * Math.pow(10, r2)) * o2) / o2;
      const f2 = Lg(t3.max, d2);
      return s2.push({ value: f2, major: hx(f2), significand: u2 }), s2;
    }({ min: this._userMin, max: this._userMax }, this);
    return "ticks" === t2.bounds && dv(e2, this, "value"), t2.reverse ? (e2.reverse(), this.start = this.max, this.end = this.min) : (this.start = this.min, this.end = this.max), e2;
  }
  getLabelForValue(t2) {
    return void 0 === t2 ? "0" : Hv(t2, this.chart.options.locale, this.options.ticks.format);
  }
  configure() {
    const t2 = this.min;
    super.configure(), this._startValue = av(t2), this._valueRange = av(this.max) - av(t2);
  }
  getPixelForValue(t2) {
    return void 0 !== t2 && 0 !== t2 || (t2 = this.min), null === t2 || isNaN(t2) ? NaN : this.getPixelForDecimal(t2 === this.min ? 0 : (av(t2) - this._startValue) / this._valueRange);
  }
  getValueForPixel(t2) {
    const e2 = this.getDecimalForPixel(t2);
    return Math.pow(10, this._startValue + e2 * this._valueRange);
  }
}
__publicField(LogarithmicScale, "id", "logarithmic");
__publicField(LogarithmicScale, "defaults", { ticks: { callback: Kv.formatters.logarithmic, major: { enabled: true } } });
function ux(t2) {
  const e2 = t2.ticks;
  if (e2.display && t2.display) {
    const t3 = wb(e2.backdropPadding);
    return Vg(e2.font && e2.font.size, Qv.font.size) + t3.height;
  }
  return 0;
}
function dx(t2, e2, i2, s2, n2) {
  return t2 === s2 || t2 === n2 ? { start: e2 - i2 / 2, end: e2 + i2 / 2 } : t2 < s2 || t2 > n2 ? { start: e2 - i2, end: e2 } : { start: e2, end: e2 + i2 };
}
function fx(t2, e2, i2, s2, n2) {
  const r2 = Math.abs(Math.sin(i2)), o2 = Math.abs(Math.cos(i2));
  let a2 = 0, l2 = 0;
  s2.start < e2.l ? (a2 = (e2.l - s2.start) / r2, t2.l = Math.min(t2.l, e2.l - a2)) : s2.end > e2.r && (a2 = (s2.end - e2.r) / r2, t2.r = Math.max(t2.r, e2.r + a2)), n2.start < e2.t ? (l2 = (e2.t - n2.start) / o2, t2.t = Math.min(t2.t, e2.t - l2)) : n2.end > e2.b && (l2 = (n2.end - e2.b) / o2, t2.b = Math.max(t2.b, e2.b + l2));
}
function px(t2, e2, i2) {
  const s2 = t2.drawingArea, { extra: n2, additionalAngle: r2, padding: o2, size: a2 } = i2, l2 = t2.getPointPosition(e2, s2 + n2 + o2, r2), h2 = Math.round(pv(_v(l2.angle + nv))), c2 = function(t3, e3, i3) {
    return 90 === i3 || 270 === i3 ? t3 -= e3 / 2 : (i3 > 270 || i3 < 90) && (t3 -= e3), t3;
  }(l2.y, a2.h, h2), u2 = function(t3) {
    return 0 === t3 || 180 === t3 ? "center" : t3 < 180 ? "left" : "right";
  }(h2), d2 = function(t3, e3, i3) {
    return "right" === i3 ? t3 -= e3 : "center" === i3 && (t3 -= e3 / 2), t3;
  }(l2.x, a2.w, u2);
  return { visible: true, x: l2.x, y: c2, textAlign: u2, left: d2, top: c2, right: d2 + a2.w, bottom: c2 + a2.h };
}
function mx(t2, e2) {
  if (!e2) return true;
  const { left: i2, top: s2, right: n2, bottom: r2 } = t2;
  return !(rb({ x: i2, y: s2 }, e2) || rb({ x: i2, y: r2 }, e2) || rb({ x: n2, y: s2 }, e2) || rb({ x: n2, y: r2 }, e2));
}
function gx(t2, e2, i2) {
  const { left: s2, top: n2, right: r2, bottom: o2 } = i2, { backdropColor: a2 } = e2;
  if (!Tg(a2)) {
    const i3 = yb(e2.borderRadius), l2 = wb(e2.backdropPadding);
    t2.fillStyle = a2;
    const h2 = s2 - l2.left, c2 = n2 - l2.top, u2 = r2 - s2 + l2.width, d2 = o2 - n2 + l2.height;
    Object.values(i3).some((t3) => 0 !== t3) ? (t2.beginPath(), fb(t2, { x: h2, y: c2, w: u2, h: d2, radius: i3 }), t2.fill()) : t2.fillRect(h2, c2, u2, d2);
  }
}
function vx(t2, e2, i2, s2) {
  const { ctx: n2 } = t2;
  if (i2) n2.arc(t2.xCenter, t2.yCenter, e2, 0, tv);
  else {
    let i3 = t2.getPointPosition(0, e2);
    n2.moveTo(i3.x, i3.y);
    for (let r2 = 1; r2 < s2; r2++) i3 = t2.getPointPosition(r2, e2), n2.lineTo(i3.x, i3.y);
  }
}
class RadialLinearScale extends LinearScaleBase {
  constructor(t2) {
    super(t2), this.xCenter = void 0, this.yCenter = void 0, this.drawingArea = void 0, this._pointLabels = [], this._pointLabelItems = [];
  }
  setDimensions() {
    const t2 = this._padding = wb(ux(this.options) / 2), e2 = this.width = this.maxWidth - t2.width, i2 = this.height = this.maxHeight - t2.height;
    this.xCenter = Math.floor(this.left + e2 / 2 + t2.left), this.yCenter = Math.floor(this.top + i2 / 2 + t2.top), this.drawingArea = Math.floor(Math.min(e2, i2) / 2);
  }
  determineDataLimits() {
    const { min: t2, max: e2 } = this.getMinMax(false);
    this.min = Ag(t2) && !isNaN(t2) ? t2 : 0, this.max = Ag(e2) && !isNaN(e2) ? e2 : 0, this.handleTickRangeOptions();
  }
  computeTickLimit() {
    return Math.ceil(this.drawingArea / ux(this.options));
  }
  generateTickLabels(t2) {
    LinearScaleBase.prototype.generateTickLabels.call(this, t2), this._pointLabels = this.getLabels().map((t3, e2) => {
      const i2 = Ig(this.options.pointLabels.callback, [t3, e2], this);
      return i2 || 0 === i2 ? i2 : "";
    }).filter((t3, e2) => this.chart.getDataVisibility(e2));
  }
  fit() {
    const t2 = this.options;
    t2.display && t2.pointLabels.display ? function(t3) {
      const e2 = { l: t3.left + t3._padding.left, r: t3.right - t3._padding.right, t: t3.top + t3._padding.top, b: t3.bottom - t3._padding.bottom }, i2 = Object.assign({}, e2), s2 = [], n2 = [], r2 = t3._pointLabels.length, o2 = t3.options.pointLabels, a2 = o2.centerPointLabels ? Zg / r2 : 0;
      for (let u2 = 0; u2 < r2; u2++) {
        const r3 = o2.setContext(t3.getPointLabelContext(u2));
        n2[u2] = r3.padding;
        const d2 = t3.getPointPosition(u2, t3.drawingArea + n2[u2], a2), f2 = xb(r3.font), p2 = (l2 = t3.ctx, h2 = f2, c2 = $g(c2 = t3._pointLabels[u2]) ? c2 : [c2], { w: tb(l2, h2.string, c2), h: c2.length * h2.lineHeight });
        s2[u2] = p2;
        const m2 = _v(t3.getIndexAngle(u2) + a2), g2 = Math.round(pv(m2));
        fx(i2, e2, m2, dx(g2, d2.x, p2.w, 0, 180), dx(g2, d2.y, p2.h, 90, 270));
      }
      var l2, h2, c2;
      t3.setCenterPoint(e2.l - i2.l, i2.r - e2.r, e2.t - i2.t, i2.b - e2.b), t3._pointLabelItems = function(t4, e3, i3) {
        const s3 = [], n3 = t4._pointLabels.length, r3 = t4.options, { centerPointLabels: o3, display: a3 } = r3.pointLabels, l3 = { extra: ux(r3) / 2, additionalAngle: o3 ? Zg / n3 : 0 };
        let h3;
        for (let r4 = 0; r4 < n3; r4++) {
          l3.padding = i3[r4], l3.size = e3[r4];
          const n4 = px(t4, r4, l3);
          s3.push(n4), "auto" === a3 && (n4.visible = mx(n4, h3), n4.visible && (h3 = n4));
        }
        return s3;
      }(t3, s2, n2);
    }(this) : this.setCenterPoint(0, 0, 0, 0);
  }
  setCenterPoint(t2, e2, i2, s2) {
    this.xCenter += Math.floor((t2 - e2) / 2), this.yCenter += Math.floor((i2 - s2) / 2), this.drawingArea -= Math.min(this.drawingArea / 2, Math.max(t2, e2, i2, s2));
  }
  getIndexAngle(t2) {
    return _v(t2 * (tv / (this._pointLabels.length || 1)) + fv(this.options.startAngle || 0));
  }
  getDistanceFromCenterForValue(t2) {
    if (Tg(t2)) return NaN;
    const e2 = this.drawingArea / (this.max - this.min);
    return this.options.reverse ? (this.max - t2) * e2 : (t2 - this.min) * e2;
  }
  getValueForDistanceFromCenter(t2) {
    if (Tg(t2)) return NaN;
    const e2 = t2 / (this.drawingArea / (this.max - this.min));
    return this.options.reverse ? this.max - e2 : this.min + e2;
  }
  getPointLabelContext(t2) {
    const e2 = this._pointLabels || [];
    if (t2 >= 0 && t2 < e2.length) {
      const i2 = e2[t2];
      return function(t3, e3, i3) {
        return Sb(t3, { label: i3, index: e3, type: "pointLabel" });
      }(this.getContext(), t2, i2);
    }
  }
  getPointPosition(t2, e2, i2 = 0) {
    const s2 = this.getIndexAngle(t2) - nv + i2;
    return { x: Math.cos(s2) * e2 + this.xCenter, y: Math.sin(s2) * e2 + this.yCenter, angle: s2 };
  }
  getPointPositionForValue(t2, e2) {
    return this.getPointPosition(t2, this.getDistanceFromCenterForValue(e2));
  }
  getBasePosition(t2) {
    return this.getPointPositionForValue(t2 || 0, this.getBaseValue());
  }
  getPointLabelPosition(t2) {
    const { left: e2, top: i2, right: s2, bottom: n2 } = this._pointLabelItems[t2];
    return { left: e2, top: i2, right: s2, bottom: n2 };
  }
  drawBackground() {
    const { backgroundColor: t2, grid: { circular: e2 } } = this.options;
    if (t2) {
      const i2 = this.ctx;
      i2.save(), i2.beginPath(), vx(this, this.getDistanceFromCenterForValue(this._endValue), e2, this._pointLabels.length), i2.closePath(), i2.fillStyle = t2, i2.fill(), i2.restore();
    }
  }
  drawGrid() {
    const t2 = this.ctx, e2 = this.options, { angleLines: i2, grid: s2, border: n2 } = e2, r2 = this._pointLabels.length;
    let o2, a2, l2;
    if (e2.pointLabels.display && function(t3, e3) {
      const { ctx: i3, options: { pointLabels: s3 } } = t3;
      for (let n3 = e3 - 1; n3 >= 0; n3--) {
        const e4 = t3._pointLabelItems[n3];
        if (!e4.visible) continue;
        const r3 = s3.setContext(t3.getPointLabelContext(n3));
        gx(i3, r3, e4);
        const o3 = xb(r3.font), { x: a3, y: l3, textAlign: h2 } = e4;
        db(i3, t3._pointLabels[n3], a3, l3 + o3.lineHeight / 2, o3, { color: r3.color, textAlign: h2, textBaseline: "middle" });
      }
    }(this, r2), s2.display && this.ticks.forEach((t3, e3) => {
      if (0 !== e3 || 0 === e3 && this.min < 0) {
        a2 = this.getDistanceFromCenterForValue(t3.value);
        const i3 = this.getContext(e3), o3 = s2.setContext(i3), l3 = n2.setContext(i3);
        !function(t4, e4, i4, s3, n3) {
          const r3 = t4.ctx, o4 = e4.circular, { color: a3, lineWidth: l4 } = e4;
          !o4 && !s3 || !a3 || !l4 || i4 < 0 || (r3.save(), r3.strokeStyle = a3, r3.lineWidth = l4, r3.setLineDash(n3.dash || []), r3.lineDashOffset = n3.dashOffset, r3.beginPath(), vx(t4, i4, o4, s3), r3.closePath(), r3.stroke(), r3.restore());
        }(this, o3, a2, r2, l3);
      }
    }), i2.display) {
      for (t2.save(), o2 = r2 - 1; o2 >= 0; o2--) {
        const s3 = i2.setContext(this.getPointLabelContext(o2)), { color: n3, lineWidth: r3 } = s3;
        r3 && n3 && (t2.lineWidth = r3, t2.strokeStyle = n3, t2.setLineDash(s3.borderDash), t2.lineDashOffset = s3.borderDashOffset, a2 = this.getDistanceFromCenterForValue(e2.reverse ? this.min : this.max), l2 = this.getPointPosition(o2, a2), t2.beginPath(), t2.moveTo(this.xCenter, this.yCenter), t2.lineTo(l2.x, l2.y), t2.stroke());
      }
      t2.restore();
    }
  }
  drawBorder() {
  }
  drawLabels() {
    const t2 = this.ctx, e2 = this.options, i2 = e2.ticks;
    if (!i2.display) return;
    const s2 = this.getIndexAngle(0);
    let n2, r2;
    t2.save(), t2.translate(this.xCenter, this.yCenter), t2.rotate(s2), t2.textAlign = "center", t2.textBaseline = "middle", this.ticks.forEach((s3, o2) => {
      if (0 === o2 && this.min >= 0 && !e2.reverse) return;
      const a2 = i2.setContext(this.getContext(o2)), l2 = xb(a2.font);
      if (n2 = this.getDistanceFromCenterForValue(this.ticks[o2].value), a2.showLabelBackdrop) {
        t2.font = l2.string, r2 = t2.measureText(s3.label).width, t2.fillStyle = a2.backdropColor;
        const e3 = wb(a2.backdropPadding);
        t2.fillRect(-r2 / 2 - e3.left, -n2 - l2.size / 2 - e3.top, r2 + e3.width, l2.size + e3.height);
      }
      db(t2, s3.label, 0, -n2, l2, { color: a2.color, strokeColor: a2.textStrokeColor, strokeWidth: a2.textStrokeWidth });
    }), t2.restore();
  }
  drawTitle() {
  }
}
__publicField(RadialLinearScale, "id", "radialLinear");
__publicField(RadialLinearScale, "defaults", { display: true, animate: true, position: "chartArea", angleLines: { display: true, lineWidth: 1, borderDash: [], borderDashOffset: 0 }, grid: { circular: false }, startAngle: 0, ticks: { showLabelBackdrop: true, callback: Kv.formatters.numeric }, pointLabels: { backdropColor: void 0, backdropPadding: 2, display: true, font: { size: 10 }, callback: (t2) => t2, padding: 5, centerPointLabels: false } });
__publicField(RadialLinearScale, "defaultRoutes", { "angleLines.color": "borderColor", "pointLabels.color": "color", "ticks.color": "color" });
__publicField(RadialLinearScale, "descriptors", { angleLines: { _fallback: "grid" } });
const bx = { millisecond: { common: true, size: 1, steps: 1e3 }, second: { common: true, size: 1e3, steps: 60 }, minute: { common: true, size: 6e4, steps: 60 }, hour: { common: true, size: 36e5, steps: 24 }, day: { common: true, size: 864e5, steps: 30 }, week: { common: false, size: 6048e5, steps: 4 }, month: { common: true, size: 2628e6, steps: 12 }, quarter: { common: false, size: 7884e6, steps: 4 }, year: { common: true, size: 3154e7 } }, _x = Object.keys(bx);
function yx(t2, e2) {
  return t2 - e2;
}
function wx(t2, e2) {
  if (Tg(e2)) return null;
  const i2 = t2._adapter, { parser: s2, round: n2, isoWeekday: r2 } = t2._parseOpts;
  let o2 = e2;
  return "function" == typeof s2 && (o2 = s2(o2)), Ag(o2) || (o2 = "string" == typeof s2 ? i2.parse(o2, s2) : i2.parse(o2)), null === o2 ? null : (n2 && (o2 = "week" !== n2 || !uv(r2) && true !== r2 ? i2.startOf(o2, n2) : i2.startOf(o2, "isoWeek", r2)), +o2);
}
function xx(t2, e2, i2, s2) {
  const n2 = _x.length;
  for (let r2 = _x.indexOf(t2); r2 < n2 - 1; ++r2) {
    const t3 = bx[_x[r2]], n3 = t3.steps ? t3.steps : Number.MAX_SAFE_INTEGER;
    if (t3.common && Math.ceil((i2 - e2) / (n3 * t3.size)) <= s2) return _x[r2];
  }
  return _x[n2 - 1];
}
function kx(t2, e2, i2) {
  if (i2) {
    if (i2.length) {
      const { lo: s2, hi: n2 } = kv(i2, e2);
      t2[i2[s2] >= e2 ? i2[s2] : i2[n2]] = true;
    }
  } else t2[e2] = true;
}
function Sx(t2, e2, i2) {
  const s2 = [], n2 = {}, r2 = e2.length;
  let o2, a2;
  for (o2 = 0; o2 < r2; ++o2) a2 = e2[o2], n2[a2] = o2, s2.push({ value: a2, major: false });
  return 0 !== r2 && i2 ? function(t3, e3, i3, s3) {
    const n3 = t3._adapter, r3 = +n3.startOf(e3[0].value, s3), o3 = e3[e3.length - 1].value;
    let a3, l2;
    for (a3 = r3; a3 <= o3; a3 = +n3.add(a3, 1, s3)) l2 = i3[a3], l2 >= 0 && (e3[l2].major = true);
    return e3;
  }(t2, s2, n2, i2) : s2;
}
class TimeScale extends Scale {
  constructor(t2) {
    super(t2), this._cache = { data: [], labels: [], all: [] }, this._unit = "day", this._majorUnit = void 0, this._offsets = {}, this._normalized = false, this._parseOpts = void 0;
  }
  init(t2, e2 = {}) {
    const i2 = t2.time || (t2.time = {}), s2 = this._adapter = new N_(t2.adapters.date);
    s2.init(e2), Hg(i2.displayFormats, s2.formats()), this._parseOpts = { parser: i2.parser, round: i2.round, isoWeekday: i2.isoWeekday }, super.init(t2), this._normalized = e2.normalized;
  }
  parse(t2, e2) {
    return void 0 === t2 ? null : wx(this, t2);
  }
  beforeLayout() {
    super.beforeLayout(), this._cache = { data: [], labels: [], all: [] };
  }
  determineDataLimits() {
    const t2 = this.options, e2 = this._adapter, i2 = t2.time.unit || "day";
    let { min: s2, max: n2, minDefined: r2, maxDefined: o2 } = this.getUserBounds();
    function a2(t3) {
      r2 || isNaN(t3.min) || (s2 = Math.min(s2, t3.min)), o2 || isNaN(t3.max) || (n2 = Math.max(n2, t3.max));
    }
    r2 && o2 || (a2(this._getLabelBounds()), "ticks" === t2.bounds && "labels" === t2.ticks.source || a2(this.getMinMax(false))), s2 = Ag(s2) && !isNaN(s2) ? s2 : +e2.startOf(Date.now(), i2), n2 = Ag(n2) && !isNaN(n2) ? n2 : +e2.endOf(Date.now(), i2) + 1, this.min = Math.min(s2, n2 - 1), this.max = Math.max(s2 + 1, n2);
  }
  _getLabelBounds() {
    const t2 = this.getLabelTimestamps();
    let e2 = Number.POSITIVE_INFINITY, i2 = Number.NEGATIVE_INFINITY;
    return t2.length && (e2 = t2[0], i2 = t2[t2.length - 1]), { min: e2, max: i2 };
  }
  buildTicks() {
    const t2 = this.options, e2 = t2.time, i2 = t2.ticks, s2 = "labels" === i2.source ? this.getLabelTimestamps() : this._generate();
    "ticks" === t2.bounds && s2.length && (this.min = this._userMin || s2[0], this.max = this._userMax || s2[s2.length - 1]);
    const n2 = this.min, r2 = function(t3, e3, i3) {
      let s3 = 0, n3 = t3.length;
      for (; s3 < n3 && t3[s3] < e3; ) s3++;
      for (; n3 > s3 && t3[n3 - 1] > i3; ) n3--;
      return s3 > 0 || n3 < t3.length ? t3.slice(s3, n3) : t3;
    }(s2, n2, this.max);
    return this._unit = e2.unit || (i2.autoSkip ? xx(e2.minUnit, this.min, this.max, this._getLabelCapacity(n2)) : function(t3, e3, i3, s3, n3) {
      for (let r3 = _x.length - 1; r3 >= _x.indexOf(i3); r3--) {
        const i4 = _x[r3];
        if (bx[i4].common && t3._adapter.diff(n3, s3, i4) >= e3 - 1) return i4;
      }
      return _x[i3 ? _x.indexOf(i3) : 0];
    }(this, r2.length, e2.minUnit, this.min, this.max)), this._majorUnit = i2.major.enabled && "year" !== this._unit ? function(t3) {
      for (let e3 = _x.indexOf(t3) + 1, i3 = _x.length; e3 < i3; ++e3) if (bx[_x[e3]].common) return _x[e3];
    }(this._unit) : void 0, this.initOffsets(s2), t2.reverse && r2.reverse(), Sx(this, r2, this._majorUnit);
  }
  afterAutoSkip() {
    this.options.offsetAfterAutoskip && this.initOffsets(this.ticks.map((t2) => +t2.value));
  }
  initOffsets(t2 = []) {
    let e2, i2, s2 = 0, n2 = 0;
    this.options.offset && t2.length && (e2 = this.getDecimalForValue(t2[0]), s2 = 1 === t2.length ? 1 - e2 : (this.getDecimalForValue(t2[1]) - e2) / 2, i2 = this.getDecimalForValue(t2[t2.length - 1]), n2 = 1 === t2.length ? i2 : (i2 - this.getDecimalForValue(t2[t2.length - 2])) / 2);
    const r2 = t2.length < 3 ? 0.5 : 0.25;
    s2 = wv(s2, 0, r2), n2 = wv(n2, 0, r2), this._offsets = { start: s2, end: n2, factor: 1 / (s2 + 1 + n2) };
  }
  _generate() {
    const t2 = this._adapter, e2 = this.min, i2 = this.max, s2 = this.options, n2 = s2.time, r2 = n2.unit || xx(n2.minUnit, e2, i2, this._getLabelCapacity(e2)), o2 = Vg(s2.ticks.stepSize, 1), a2 = "week" === r2 && n2.isoWeekday, l2 = uv(a2) || true === a2, h2 = {};
    let c2, u2, d2 = e2;
    if (l2 && (d2 = +t2.startOf(d2, "isoWeek", a2)), d2 = +t2.startOf(d2, l2 ? "day" : r2), t2.diff(i2, e2, r2) > 1e5 * o2) throw new Error(e2 + " and " + i2 + " are too far apart with stepSize of " + o2 + " " + r2);
    const f2 = "data" === s2.ticks.source && this.getDataTimestamps();
    for (c2 = d2, u2 = 0; c2 < i2; c2 = +t2.add(c2, o2, r2), u2++) kx(h2, c2, f2);
    return c2 !== i2 && "ticks" !== s2.bounds && 1 !== u2 || kx(h2, c2, f2), Object.keys(h2).sort(yx).map((t3) => +t3);
  }
  getLabelForValue(t2) {
    const e2 = this._adapter, i2 = this.options.time;
    return i2.tooltipFormat ? e2.format(t2, i2.tooltipFormat) : e2.format(t2, i2.displayFormats.datetime);
  }
  format(t2, e2) {
    const i2 = this.options.time.displayFormats, s2 = this._unit, n2 = e2 || i2[s2];
    return this._adapter.format(t2, n2);
  }
  _tickFormatFunction(t2, e2, i2, s2) {
    const n2 = this.options, r2 = n2.ticks.callback;
    if (r2) return Ig(r2, [t2, e2, i2], this);
    const o2 = n2.time.displayFormats, a2 = this._unit, l2 = this._majorUnit, h2 = a2 && o2[a2], c2 = l2 && o2[l2], u2 = i2[e2], d2 = l2 && c2 && u2 && u2.major;
    return this._adapter.format(t2, s2 || (d2 ? c2 : h2));
  }
  generateTickLabels(t2) {
    let e2, i2, s2;
    for (e2 = 0, i2 = t2.length; e2 < i2; ++e2) s2 = t2[e2], s2.label = this._tickFormatFunction(s2.value, e2, t2);
  }
  getDecimalForValue(t2) {
    return null === t2 ? NaN : (t2 - this.min) / (this.max - this.min);
  }
  getPixelForValue(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForValue(t2);
    return this.getPixelForDecimal((e2.start + i2) * e2.factor);
  }
  getValueForPixel(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForPixel(t2) / e2.factor - e2.end;
    return this.min + i2 * (this.max - this.min);
  }
  _getLabelSize(t2) {
    const e2 = this.options.ticks, i2 = this.ctx.measureText(t2).width, s2 = fv(this.isHorizontal() ? e2.maxRotation : e2.minRotation), n2 = Math.cos(s2), r2 = Math.sin(s2), o2 = this._resolveTickFontOptions(0).size;
    return { w: i2 * n2 + o2 * r2, h: i2 * r2 + o2 * n2 };
  }
  _getLabelCapacity(t2) {
    const e2 = this.options.time, i2 = e2.displayFormats, s2 = i2[e2.unit] || i2.millisecond, n2 = this._tickFormatFunction(t2, 0, Sx(this, [t2], this._majorUnit), s2), r2 = this._getLabelSize(n2), o2 = Math.floor(this.isHorizontal() ? this.width / r2.w : this.height / r2.h) - 1;
    return o2 > 0 ? o2 : 1;
  }
  getDataTimestamps() {
    let t2, e2, i2 = this._cache.data || [];
    if (i2.length) return i2;
    const s2 = this.getMatchingVisibleMetas();
    if (this._normalized && s2.length) return this._cache.data = s2[0].controller.getAllParsedValues(this);
    for (t2 = 0, e2 = s2.length; t2 < e2; ++t2) i2 = i2.concat(s2[t2].controller.getAllParsedValues(this));
    return this._cache.data = this.normalize(i2);
  }
  getLabelTimestamps() {
    const t2 = this._cache.labels || [];
    let e2, i2;
    if (t2.length) return t2;
    const s2 = this.getLabels();
    for (e2 = 0, i2 = s2.length; e2 < i2; ++e2) t2.push(wx(this, s2[e2]));
    return this._cache.labels = this._normalized ? t2 : this.normalize(t2);
  }
  normalize(t2) {
    return Dv(t2.sort(yx));
  }
}
__publicField(TimeScale, "id", "time");
__publicField(TimeScale, "defaults", { bounds: "data", adapters: {}, time: { parser: false, unit: false, round: false, isoWeekday: false, minUnit: "millisecond", displayFormats: {} }, ticks: { source: "auto", callback: false, major: { enabled: false } } });
function Mx(t2, e2, i2) {
  let s2, n2, r2, o2, a2 = 0, l2 = t2.length - 1;
  i2 ? (e2 >= t2[a2].pos && e2 <= t2[l2].pos && ({ lo: a2, hi: l2 } = Sv(t2, "pos", e2)), { pos: s2, time: r2 } = t2[a2], { pos: n2, time: o2 } = t2[l2]) : (e2 >= t2[a2].time && e2 <= t2[l2].time && ({ lo: a2, hi: l2 } = Sv(t2, "time", e2)), { time: s2, pos: r2 } = t2[a2], { time: n2, pos: o2 } = t2[l2]);
  const h2 = n2 - s2;
  return h2 ? r2 + (o2 - r2) * (e2 - s2) / h2 : r2;
}
var zx = Object.freeze({ __proto__: null, CategoryScale, LinearScale, LogarithmicScale, RadialLinearScale, TimeScale, TimeSeriesScale: (_f2 = class extends TimeScale {
  constructor(t2) {
    super(t2), this._table = [], this._minPos = void 0, this._tableRange = void 0;
  }
  initOffsets() {
    const t2 = this._getTimestampsForTable(), e2 = this._table = this.buildLookupTable(t2);
    this._minPos = Mx(e2, this.min), this._tableRange = Mx(e2, this.max) - this._minPos, super.initOffsets(t2);
  }
  buildLookupTable(t2) {
    const { min: e2, max: i2 } = this, s2 = [], n2 = [];
    let r2, o2, a2, l2, h2;
    for (r2 = 0, o2 = t2.length; r2 < o2; ++r2) l2 = t2[r2], l2 >= e2 && l2 <= i2 && s2.push(l2);
    if (s2.length < 2) return [{ time: e2, pos: 0 }, { time: i2, pos: 1 }];
    for (r2 = 0, o2 = s2.length; r2 < o2; ++r2) h2 = s2[r2 + 1], a2 = s2[r2 - 1], l2 = s2[r2], Math.round((h2 + a2) / 2) !== l2 && n2.push({ time: l2, pos: r2 / (o2 - 1) });
    return n2;
  }
  _generate() {
    const t2 = this.min, e2 = this.max;
    let i2 = super.getDataTimestamps();
    return i2.includes(t2) && i2.length || i2.splice(0, 0, t2), i2.includes(e2) && 1 !== i2.length || i2.push(e2), i2.sort((t3, e3) => t3 - e3);
  }
  _getTimestampsForTable() {
    let t2 = this._cache.all || [];
    if (t2.length) return t2;
    const e2 = this.getDataTimestamps(), i2 = this.getLabelTimestamps();
    return t2 = e2.length && i2.length ? this.normalize(e2.concat(i2)) : e2.length ? e2 : i2, t2 = this._cache.all = t2, t2;
  }
  getDecimalForValue(t2) {
    return (Mx(this._table, t2) - this._minPos) / this._tableRange;
  }
  getValueForPixel(t2) {
    const e2 = this._offsets, i2 = this.getDecimalForPixel(t2) / e2.factor - e2.end;
    return Mx(this._table, i2 * this._tableRange + this._minPos, true);
  }
}, __publicField(_f2, "id", "timeseries"), __publicField(_f2, "defaults", TimeScale.defaults), _f2) });
const Cx = [O_, fw, nx, zx], Dx = { light: "light", dark: "dark" }, Rx = Wm("light");
function Px(t2) {
  return t2 && "dark" === Dx[t2] ? "dark" : "light";
}
function Tx(t2) {
  return "light" === Px(t2) ? "#725bf5" : "#7a64f5";
}
function $x(t2 = "AA") {
  return "#777777" + t2;
}
function Ex(t2) {
  return "light" === Px(t2) ? "#000000aa" : "#FFFFFFaa";
}
const Ax = "rgba(241, 99, 102, 1)", Lx = Wm("light");
var Vx, Ox = (Vx = xd(0), function() {
  return 1 === arguments.length ? (zd(Vx, rp(Vx) + 1), arguments[0]) : (rp(Vx), Chart);
}), Ix = kp('<div><div><div class="card-content"><p class="font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="mt-6 text-center"> </p></div></div></div>'), Nx = kp('<div><div><div class="card-content"><p class="text-base-content-200 font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="mt-6 text-center"> </p></div></div></div>'), Fx = kp('<div><div class="flex flex-col justify-center items-center"><div><div class="card-content"><p class="font-light"> </p> <div class="flex mt-9"><p class="text-primary"> </p> <div class="flex-grow"></div> <p class="text-secondary"> </p></div> <canvas width="400" height="200"></canvas> <p class="text-center mt-6"> </p></div></div></div></div>'), Wx = kp('<div class="text-base-content-200"><!> <!> <!></div>');
function Bx(t2, e2) {
  ld(e2, false);
  const [i2, s2] = Hm(), n2 = () => qm(Lx, "$themeChoice", i2), r2 = Sd(), o2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  Ox().register(LinearScale, BarController, CategoryScale, BarElement, LineController, LineElement, PointElement, sx), Ox(Ox().defaults.font.color = "red");
  let a2 = Jm(e2, "browser", 12), l2 = Jm(e2, "report", 12), h2 = Jm(e2, "chartTab", 12, "portfolioCapacity");
  function c2(t3, e3) {
    const i3 = t3.filter((t4) => null !== t4);
    if (0 === i3.length) return 0;
    const s3 = i3.sort((t4, e4) => t4 - e4), n3 = (s3.length - 1) * e3, r3 = Math.floor(n3), o3 = n3 - r3;
    return void 0 !== s3[r3 + 1] ? s3[r3] + o3 * (s3[r3 + 1] - s3[r3]) : s3[r3];
  }
  function u2(t3, e3, i3 = 5) {
    let s3 = {}, n3 = {};
    t3 = t3.filter((t4) => null !== t4[e3] && void 0 !== t4[e3]);
    for (let r3 of function(t4, e4 = 5) {
      let i4 = [], s4 = [5, 10];
      for (; i4.length < t4; ) {
        for (let n4 of s4) if (i4.push(n4 * Math.pow(10, e4)), i4.length === t4) break;
        e4 += 1;
      }
      return i4;
    }(100, i3)) {
      let i4 = t3.map((t4) => t4[e3]);
      i4.sort((t4, e4) => t4 - e4);
      let o3 = i4.findIndex((t4) => t4 > r3) / i4.length, a3 = t3.filter((t4) => t4[e3] > r3).map((t4) => t4.return);
      if (0 === o3 && (n3 = {}, s3 = {}), n3[r3] = c2(a3, 0.5), s3[r3] = 1 - o3, s3[r3] < 0.2) break;
    }
    return { portion: s3, mean: n3 };
  }
  function d2(t3, e3 = "zh") {
    return Math.abs(t3) >= 1e8 ? t3 / 1e8 + hu() : Math.abs(t3) >= 1e7 ? t3 / 1e7 + cu() : Math.abs(t3) >= 1e6 ? t3 / 1e6 + uu() : Math.abs(t3) >= 1e4 ? t3 / 1e4 + du() : t3;
  }
  function f2(t3, e3, i3) {
    const s3 = Ex(rp(r2)), n3 = "#77777755";
    return new (Ox())(e3, { type: "bar", data: { labels: Object.keys(t3.portion), datasets: [{ label: "Data", data: Object.values(t3.portion), backgroundColor: Tx(rp(r2)), yAxisID: "y-axis-1", barPercentage: 0.2, order: 1 }, { label: "Line Data", data: Object.values(t3.mean), type: "line", fill: false, borderColor: "#f16365", borderWidth: 5, pointBackgroundColor: "#f16365", pointBorderColor: "#f16365", yAxisID: "y-axis-2", order: 0 }] }, options: { responsive: true, maintainAspectRatio: true, scales: { x: { type: "category", ticks: { color: s3, callback: (e4) => d2(Object.keys(t3.portion)[e4], "zh") + i3 + fu() }, grid: { color: n3, tickBorderDash: [2, 2] } }, "y-axis-1": { display: true, position: "left", beginAtZero: true, ticks: { callback: (t4) => (100 * t4).toFixed(0) + "%", color: s3 }, grid: { color: n3, tickBorderDash: [2, 2] } }, "y-axis-2": { display: true, position: "right", ticks: { callback: (t4) => (100 * t4).toFixed(1) + "%", color: s3 }, grid: { drawOnChartArea: false, color: n3, tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false } } } });
  }
  l2().trades.forEach((t3) => {
    t3.acceptMoneyFlow = (0.05 * t3["turnover@entry_date"] / t3.position + 0.05 * t3["turnover@entry_date"] / t3.position) / 2, t3["volume_@entry_date"] = t3["volume@entry_date"] / 1e3, t3["volume_@exit_date"] = t3["volume@exit_date"] / 1e3;
  });
  const p2 = u2(l2().trades, "acceptMoneyFlow", 5);
  u2(l2().trades, "market_value@entry_date", 5);
  const m2 = u2(l2().trades, "volume_@entry_date", 1), g2 = u2(l2().trades, "volume_@exit_date", 1);
  let v2 = {}, b2 = Sd({});
  function _2() {
    if ("portfolioCapacity" === h2() && rp(b2).moneyFlow) {
      v2.moneyFlow && (v2.moneyFlow.destroy(), delete v2.moneyFlow);
      const t3 = rp(b2).moneyFlow.getContext("2d");
      v2.moneyFlow = f2(p2, t3, pu());
    }
    if ("entryVolume" === h2() && rp(b2).entryVolume) {
      v2.entryVolume && v2.entryVolume.destroy();
      const t3 = rp(b2).entryVolume.getContext("2d");
      v2.entryVolume = f2(m2, t3, mu());
    }
    if ("exitVolume" === h2() && rp(b2).exitVolume) {
      v2.exitVolume && v2.exitVolume.destroy();
      const t3 = rp(b2).exitVolume.getContext("2d");
      v2.exitVolume = f2(g2, t3, gu());
    }
  }
  let y2 = Sd(false);
  Bp(() => {
    a2() && (zd(y2, true), _2());
  }), sf(() => n2(), () => {
    zd(r2, n2());
  }), sf(() => (rp(y2), hp(h2()), rp(r2), np), () => {
    rp(y2) && (h2() || rp(r2)) && np().then(() => _2());
  }), nf(), Om();
  var w2 = Wx(), x2 = Kd(w2), k2 = (t3) => {
    var e3 = Ix(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3, true);
    Ld(n3);
    var a3 = Gd(n3, 2), l3 = Kd(a3), h3 = Kd(l3, true);
    Ld(l3);
    var c3 = Gd(l3, 4), u3 = Kd(c3, true);
    Ld(c3), Ld(a3);
    var f3 = Gd(a3, 2);
    Vm(f3, (t4) => Md(b2, rp(b2).moneyFlow = t4), () => {
      var _a3;
      return (_a3 = rp(b2)) == null ? void 0 : _a3.moneyFlow;
    });
    var m3 = Gd(f3, 2), g3 = Kd(m3, true);
    Ld(m3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      Vp(r3, t4), Vp(h3, e4), Vp(u3, i4), Vp(g3, s4);
    }, [() => sn({ v1: d2(Object.keys(p2.mean)[1], "zh"), v2: (100 * (1 - Object.values(p2.portion)[1])).toFixed(1) }), () => o2("metrics.liquidity.safeLiquidityTradeRatio"), () => o2("metrics.liquidity.averageReturn"), () => o2("metrics.liquidity.totalInvestment")], vd), zp(t3, e3);
  };
  Hp(x2, (t3) => {
    "portfolioCapacity" === h2() && t3(k2);
  });
  var S2 = Gd(x2, 2), M2 = (t3) => {
    var e3 = Nx(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3, true);
    Ld(n3);
    var a3 = Gd(n3, 2), l3 = Kd(a3), h3 = Kd(l3, true);
    Ld(l3);
    var c3 = Gd(l3, 4), u3 = Kd(c3, true);
    Ld(c3), Ld(a3);
    var f3 = Gd(a3, 2);
    Vm(f3, (t4) => Md(b2, rp(b2).entryVolume = t4), () => {
      var _a3;
      return (_a3 = rp(b2)) == null ? void 0 : _a3.entryVolume;
    });
    var p3 = Gd(f3, 2), g3 = Kd(p3, true);
    Ld(p3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      Vp(r3, t4), Vp(h3, e4), Vp(u3, i4), Vp(g3, s4);
    }, [() => on({ v1: d2(Object.keys(m2.mean)[2]), v2: (100 * Object.values(m2.portion)[2]).toFixed(1) }), () => o2("metrics.liquidity.tradeRatio"), () => o2("metrics.liquidity.averageReturn"), () => o2("metrics.liquidity.volumeThreshold")], vd), zp(t3, e3);
  };
  Hp(S2, (t3) => {
    "entryVolume" === h2() && t3(M2);
  });
  var z2 = Gd(S2, 2), C2 = (t3) => {
    var e3 = Fx(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), a3 = Kd(r3, true);
    Ld(r3);
    var l3 = Gd(r3, 2), h3 = Kd(l3), c3 = Kd(h3, true);
    Ld(h3);
    var u3 = Gd(h3, 4), f3 = Kd(u3, true);
    Ld(u3), Ld(l3);
    var p3 = Gd(l3, 2);
    Vm(p3, (t4) => Md(b2, rp(b2).exitVolume = t4), () => {
      var _a3;
      return (_a3 = rp(b2)) == null ? void 0 : _a3.exitVolume;
    });
    var m3 = Gd(p3, 2), v3 = Kd(m3, true);
    Ld(m3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      Vp(a3, t4), Vp(c3, e4), Vp(f3, i4), Vp(v3, s4);
    }, [() => an({ v1: d2(Object.keys(g2.mean)[2]), v2: (100 * Object.values(g2.portion)[2]).toFixed(1) }), () => o2("metrics.liquidity.tradeRatioExitVolume"), () => o2("metrics.liquidity.averageReturn"), () => o2("metrics.liquidity.volumeThreshold")], vd), zp(t3, e3);
  };
  Hp(z2, (t3) => {
    "exitVolume" === h2() && t3(C2);
  }), Ld(w2), zp(t2, w2);
  var R2 = hd({ get browser() {
    return a2();
  }, set browser(t3) {
    a2(t3), sp();
  }, get report() {
    return l2();
  }, set report(t3) {
    l2(t3), sp();
  }, get chartTab() {
    return h2();
  }, set chartTab(t3) {
    h2(t3), sp();
  } });
  return s2(), R2;
}
function jx(t2) {
  var e2 = t2.width, i2 = t2.height;
  if (e2 < 0) throw new Error("Negative width is not allowed for Size");
  if (i2 < 0) throw new Error("Negative height is not allowed for Size");
  return { width: e2, height: i2 };
}
function qx(t2, e2) {
  return t2.width === e2.width && t2.height === e2.height;
}
tg(Bx, { browser: {}, report: {}, chartTab: {} }, [], [], true);
var Hx = function() {
  function t2(t3) {
    var e2 = this;
    this._resolutionListener = function() {
      return e2._onResolutionChanged();
    }, this._resolutionMediaQueryList = null, this._observers = [], this._window = t3, this._installResolutionListener();
  }
  return t2.prototype.dispose = function() {
    this._uninstallResolutionListener(), this._window = null;
  }, Object.defineProperty(t2.prototype, "value", { get: function() {
    return this._window.devicePixelRatio;
  }, enumerable: false, configurable: true }), t2.prototype.subscribe = function(t3) {
    var e2 = this, i2 = { next: t3 };
    return this._observers.push(i2), { unsubscribe: function() {
      e2._observers = e2._observers.filter(function(t4) {
        return t4 !== i2;
      });
    } };
  }, t2.prototype._installResolutionListener = function() {
    if (null !== this._resolutionMediaQueryList) throw new Error("Resolution listener is already installed");
    var t3 = this._window.devicePixelRatio;
    this._resolutionMediaQueryList = this._window.matchMedia("all and (resolution: ".concat(t3, "dppx)")), this._resolutionMediaQueryList.addListener(this._resolutionListener);
  }, t2.prototype._uninstallResolutionListener = function() {
    null !== this._resolutionMediaQueryList && (this._resolutionMediaQueryList.removeListener(this._resolutionListener), this._resolutionMediaQueryList = null);
  }, t2.prototype._reinstallResolutionListener = function() {
    this._uninstallResolutionListener(), this._installResolutionListener();
  }, t2.prototype._onResolutionChanged = function() {
    var t3 = this;
    this._observers.forEach(function(e2) {
      return e2.next(t3._window.devicePixelRatio);
    }), this._reinstallResolutionListener();
  }, t2;
}(), Ux = function() {
  function t2(t3, e2, i2) {
    var s2;
    this._canvasElement = null, this._bitmapSizeChangedListeners = [], this._suggestedBitmapSize = null, this._suggestedBitmapSizeChangedListeners = [], this._devicePixelRatioObservable = null, this._canvasElementResizeObserver = null, this._canvasElement = t3, this._canvasElementClientSize = jx({ width: this._canvasElement.clientWidth, height: this._canvasElement.clientHeight }), this._transformBitmapSize = null != e2 ? e2 : function(t4) {
      return t4;
    }, this._allowResizeObserver = null === (s2 = null == i2 ? void 0 : i2.allowResizeObserver) || void 0 === s2 || s2, this._chooseAndInitObserver();
  }
  return t2.prototype.dispose = function() {
    var t3, e2;
    if (null === this._canvasElement) throw new Error("Object is disposed");
    null === (t3 = this._canvasElementResizeObserver) || void 0 === t3 || t3.disconnect(), this._canvasElementResizeObserver = null, null === (e2 = this._devicePixelRatioObservable) || void 0 === e2 || e2.dispose(), this._devicePixelRatioObservable = null, this._suggestedBitmapSizeChangedListeners.length = 0, this._bitmapSizeChangedListeners.length = 0, this._canvasElement = null;
  }, Object.defineProperty(t2.prototype, "canvasElement", { get: function() {
    if (null === this._canvasElement) throw new Error("Object is disposed");
    return this._canvasElement;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "canvasElementClientSize", { get: function() {
    return this._canvasElementClientSize;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "bitmapSize", { get: function() {
    return jx({ width: this.canvasElement.width, height: this.canvasElement.height });
  }, enumerable: false, configurable: true }), t2.prototype.resizeCanvasElement = function(t3) {
    this._canvasElementClientSize = jx(t3), this.canvasElement.style.width = "".concat(this._canvasElementClientSize.width, "px"), this.canvasElement.style.height = "".concat(this._canvasElementClientSize.height, "px"), this._invalidateBitmapSize();
  }, t2.prototype.subscribeBitmapSizeChanged = function(t3) {
    this._bitmapSizeChangedListeners.push(t3);
  }, t2.prototype.unsubscribeBitmapSizeChanged = function(t3) {
    this._bitmapSizeChangedListeners = this._bitmapSizeChangedListeners.filter(function(e2) {
      return e2 !== t3;
    });
  }, Object.defineProperty(t2.prototype, "suggestedBitmapSize", { get: function() {
    return this._suggestedBitmapSize;
  }, enumerable: false, configurable: true }), t2.prototype.subscribeSuggestedBitmapSizeChanged = function(t3) {
    this._suggestedBitmapSizeChangedListeners.push(t3);
  }, t2.prototype.unsubscribeSuggestedBitmapSizeChanged = function(t3) {
    this._suggestedBitmapSizeChangedListeners = this._suggestedBitmapSizeChangedListeners.filter(function(e2) {
      return e2 !== t3;
    });
  }, t2.prototype.applySuggestedBitmapSize = function() {
    if (null !== this._suggestedBitmapSize) {
      var t3 = this._suggestedBitmapSize;
      this._suggestedBitmapSize = null, this._resizeBitmap(t3), this._emitSuggestedBitmapSizeChanged(t3, this._suggestedBitmapSize);
    }
  }, t2.prototype._resizeBitmap = function(t3) {
    var e2 = this.bitmapSize;
    qx(e2, t3) || (this.canvasElement.width = t3.width, this.canvasElement.height = t3.height, this._emitBitmapSizeChanged(e2, t3));
  }, t2.prototype._emitBitmapSizeChanged = function(t3, e2) {
    var i2 = this;
    this._bitmapSizeChangedListeners.forEach(function(s2) {
      return s2.call(i2, t3, e2);
    });
  }, t2.prototype._suggestNewBitmapSize = function(t3) {
    var e2 = this._suggestedBitmapSize, i2 = jx(this._transformBitmapSize(t3, this._canvasElementClientSize)), s2 = qx(this.bitmapSize, i2) ? null : i2;
    null === e2 && null === s2 || null !== e2 && null !== s2 && qx(e2, s2) || (this._suggestedBitmapSize = s2, this._emitSuggestedBitmapSizeChanged(e2, s2));
  }, t2.prototype._emitSuggestedBitmapSizeChanged = function(t3, e2) {
    var i2 = this;
    this._suggestedBitmapSizeChangedListeners.forEach(function(s2) {
      return s2.call(i2, t3, e2);
    });
  }, t2.prototype._chooseAndInitObserver = function() {
    var t3 = this;
    this._allowResizeObserver ? new Promise(function(t4) {
      var e2 = new ResizeObserver(function(i2) {
        t4(i2.every(function(t5) {
          return "devicePixelContentBoxSize" in t5;
        })), e2.disconnect();
      });
      e2.observe(document.body, { box: "device-pixel-content-box" });
    }).catch(function() {
      return false;
    }).then(function(e2) {
      return e2 ? t3._initResizeObserver() : t3._initDevicePixelRatioObservable();
    }) : this._initDevicePixelRatioObservable();
  }, t2.prototype._initDevicePixelRatioObservable = function() {
    var t3 = this;
    if (null !== this._canvasElement) {
      var e2 = Kx(this._canvasElement);
      if (null === e2) throw new Error("No window is associated with the canvas");
      this._devicePixelRatioObservable = function(t4) {
        return new Hx(t4);
      }(e2), this._devicePixelRatioObservable.subscribe(function() {
        return t3._invalidateBitmapSize();
      }), this._invalidateBitmapSize();
    }
  }, t2.prototype._invalidateBitmapSize = function() {
    var t3, e2;
    if (null !== this._canvasElement) {
      var i2 = Kx(this._canvasElement);
      if (null !== i2) {
        var s2 = null !== (e2 = null === (t3 = this._devicePixelRatioObservable) || void 0 === t3 ? void 0 : t3.value) && void 0 !== e2 ? e2 : i2.devicePixelRatio, n2 = this._canvasElement.getClientRects(), r2 = void 0 !== n2[0] ? function(t4, e3) {
          return jx({ width: Math.round(t4.left * e3 + t4.width * e3) - Math.round(t4.left * e3), height: Math.round(t4.top * e3 + t4.height * e3) - Math.round(t4.top * e3) });
        }(n2[0], s2) : jx({ width: this._canvasElementClientSize.width * s2, height: this._canvasElementClientSize.height * s2 });
        this._suggestNewBitmapSize(r2);
      }
    }
  }, t2.prototype._initResizeObserver = function() {
    var t3 = this;
    null !== this._canvasElement && (this._canvasElementResizeObserver = new ResizeObserver(function(e2) {
      var i2 = e2.find(function(e3) {
        return e3.target === t3._canvasElement;
      });
      if (i2 && i2.devicePixelContentBoxSize && i2.devicePixelContentBoxSize[0]) {
        var s2 = i2.devicePixelContentBoxSize[0], n2 = jx({ width: s2.inlineSize, height: s2.blockSize });
        t3._suggestNewBitmapSize(n2);
      }
    }), this._canvasElementResizeObserver.observe(this._canvasElement, { box: "device-pixel-content-box" }));
  }, t2;
}();
function Kx(t2) {
  return t2.ownerDocument.defaultView;
}
var Yx = function() {
  function t2(t3, e2, i2) {
    if (0 === e2.width || 0 === e2.height) throw new TypeError("Rendering target could only be created on a media with positive width and height");
    if (this._mediaSize = e2, 0 === i2.width || 0 === i2.height) throw new TypeError("Rendering target could only be created using a bitmap with positive integer width and height");
    this._bitmapSize = i2, this._context = t3;
  }
  return t2.prototype.useMediaCoordinateSpace = function(t3) {
    try {
      return this._context.save(), this._context.setTransform(1, 0, 0, 1, 0, 0), this._context.scale(this._horizontalPixelRatio, this._verticalPixelRatio), t3({ context: this._context, mediaSize: this._mediaSize });
    } finally {
      this._context.restore();
    }
  }, t2.prototype.useBitmapCoordinateSpace = function(t3) {
    try {
      return this._context.save(), this._context.setTransform(1, 0, 0, 1, 0, 0), t3({ context: this._context, mediaSize: this._mediaSize, bitmapSize: this._bitmapSize, horizontalPixelRatio: this._horizontalPixelRatio, verticalPixelRatio: this._verticalPixelRatio });
    } finally {
      this._context.restore();
    }
  }, Object.defineProperty(t2.prototype, "_horizontalPixelRatio", { get: function() {
    return this._bitmapSize.width / this._mediaSize.width;
  }, enumerable: false, configurable: true }), Object.defineProperty(t2.prototype, "_verticalPixelRatio", { get: function() {
    return this._bitmapSize.height / this._mediaSize.height;
  }, enumerable: false, configurable: true }), t2;
}();
function Gx(t2, e2) {
  var i2 = t2.canvasElementClientSize;
  if (0 === i2.width || 0 === i2.height) return null;
  var s2 = t2.bitmapSize;
  if (0 === s2.width || 0 === s2.height) return null;
  var n2 = t2.canvasElement.getContext("2d", e2);
  return null === n2 ? null : new Yx(n2, i2, s2);
}
const Xx = { upColor: "#26a69a", downColor: "#ef5350", wickVisible: true, borderVisible: true, borderColor: "#378658", borderUpColor: "#26a69a", borderDownColor: "#ef5350", wickColor: "#737375", wickUpColor: "#26a69a", wickDownColor: "#ef5350" }, Jx = { upColor: "#26a69a", downColor: "#ef5350", openVisible: true, thinBars: true }, Qx = { color: "#2196f3", lineStyle: 0, lineWidth: 3, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, Zx = { topColor: "rgba( 46, 220, 135, 0.4)", bottomColor: "rgba( 40, 221, 100, 0)", invertFilledArea: false, lineColor: "#33D778", lineStyle: 0, lineWidth: 3, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, tk = { baseValue: { type: "price", price: 0 }, topFillColor1: "rgba(38, 166, 154, 0.28)", topFillColor2: "rgba(38, 166, 154, 0.05)", topLineColor: "rgba(38, 166, 154, 1)", bottomFillColor1: "rgba(239, 83, 80, 0.05)", bottomFillColor2: "rgba(239, 83, 80, 0.28)", bottomLineColor: "rgba(239, 83, 80, 1)", lineWidth: 3, lineStyle: 0, lineType: 0, lineVisible: true, crosshairMarkerVisible: true, crosshairMarkerRadius: 4, crosshairMarkerBorderColor: "", crosshairMarkerBorderWidth: 2, crosshairMarkerBackgroundColor: "", lastPriceAnimation: 0, pointMarkersVisible: false }, ek = { color: "#26a69a", base: 0 }, ik = { color: "#2196f3" }, sk = { title: "", visible: true, lastValueVisible: true, priceLineVisible: true, priceLineSource: 0, priceLineWidth: 1, priceLineColor: "", priceLineStyle: 2, baseLineVisible: true, baseLineWidth: 1, baseLineColor: "#B2B5BE", baseLineStyle: 0, priceFormat: { type: "price", precision: 2, minMove: 0.01 } };
var nk, rk, ok;
function ak(t2, e2) {
  const i2 = { 0: [], 1: [t2.lineWidth, t2.lineWidth], 2: [2 * t2.lineWidth, 2 * t2.lineWidth], 3: [6 * t2.lineWidth, 6 * t2.lineWidth], 4: [t2.lineWidth, 4 * t2.lineWidth] }[e2];
  t2.setLineDash(i2);
}
function lk(t2, e2, i2, s2) {
  t2.beginPath();
  const n2 = t2.lineWidth % 2 ? 0.5 : 0;
  t2.moveTo(i2, e2 + n2), t2.lineTo(s2, e2 + n2), t2.stroke();
}
function hk(t2, e2) {
  if (!t2) throw new Error("Assertion failed" + (e2 ? ": " + e2 : ""));
}
function ck(t2) {
  if (void 0 === t2) throw new Error("Value is undefined");
  return t2;
}
function uk(t2) {
  if (null === t2) throw new Error("Value is null");
  return t2;
}
function dk(t2) {
  return uk(ck(t2));
}
(ok = nk || (nk = {}))[ok.Simple = 0] = "Simple", ok[ok.WithSteps = 1] = "WithSteps", ok[ok.Curved = 2] = "Curved", function(t2) {
  t2[t2.Solid = 0] = "Solid", t2[t2.Dotted = 1] = "Dotted", t2[t2.Dashed = 2] = "Dashed", t2[t2.LargeDashed = 3] = "LargeDashed", t2[t2.SparseDotted = 4] = "SparseDotted";
}(rk || (rk = {}));
const fk = { khaki: "#f0e68c", azure: "#f0ffff", aliceblue: "#f0f8ff", ghostwhite: "#f8f8ff", gold: "#ffd700", goldenrod: "#daa520", gainsboro: "#dcdcdc", gray: "#808080", green: "#008000", honeydew: "#f0fff0", floralwhite: "#fffaf0", lightblue: "#add8e6", lightcoral: "#f08080", lemonchiffon: "#fffacd", hotpink: "#ff69b4", lightyellow: "#ffffe0", greenyellow: "#adff2f", lightgoldenrodyellow: "#fafad2", limegreen: "#32cd32", linen: "#faf0e6", lightcyan: "#e0ffff", magenta: "#f0f", maroon: "#800000", olive: "#808000", orange: "#ffa500", oldlace: "#fdf5e6", mediumblue: "#0000cd", transparent: "#0000", lime: "#0f0", lightpink: "#ffb6c1", mistyrose: "#ffe4e1", moccasin: "#ffe4b5", midnightblue: "#191970", orchid: "#da70d6", mediumorchid: "#ba55d3", mediumturquoise: "#48d1cc", orangered: "#ff4500", royalblue: "#4169e1", powderblue: "#b0e0e6", red: "#f00", coral: "#ff7f50", turquoise: "#40e0d0", white: "#fff", whitesmoke: "#f5f5f5", wheat: "#f5deb3", teal: "#008080", steelblue: "#4682b4", bisque: "#ffe4c4", aquamarine: "#7fffd4", aqua: "#0ff", sienna: "#a0522d", silver: "#c0c0c0", springgreen: "#00ff7f", antiquewhite: "#faebd7", burlywood: "#deb887", brown: "#a52a2a", beige: "#f5f5dc", chocolate: "#d2691e", chartreuse: "#7fff00", cornflowerblue: "#6495ed", cornsilk: "#fff8dc", crimson: "#dc143c", cadetblue: "#5f9ea0", tomato: "#ff6347", fuchsia: "#f0f", blue: "#00f", salmon: "#fa8072", blanchedalmond: "#ffebcd", slateblue: "#6a5acd", slategray: "#708090", thistle: "#d8bfd8", tan: "#d2b48c", cyan: "#0ff", darkblue: "#00008b", darkcyan: "#008b8b", darkgoldenrod: "#b8860b", darkgray: "#a9a9a9", blueviolet: "#8a2be2", black: "#000", darkmagenta: "#8b008b", darkslateblue: "#483d8b", darkkhaki: "#bdb76b", darkorchid: "#9932cc", darkorange: "#ff8c00", darkgreen: "#006400", darkred: "#8b0000", dodgerblue: "#1e90ff", darkslategray: "#2f4f4f", dimgray: "#696969", deepskyblue: "#00bfff", firebrick: "#b22222", forestgreen: "#228b22", indigo: "#4b0082", ivory: "#fffff0", lavenderblush: "#fff0f5", feldspar: "#d19275", indianred: "#cd5c5c", lightgreen: "#90ee90", lightgrey: "#d3d3d3", lightskyblue: "#87cefa", lightslategray: "#789", lightslateblue: "#8470ff", snow: "#fffafa", lightseagreen: "#20b2aa", lightsalmon: "#ffa07a", darksalmon: "#e9967a", darkviolet: "#9400d3", mediumpurple: "#9370d8", mediumaquamarine: "#66cdaa", skyblue: "#87ceeb", lavender: "#e6e6fa", lightsteelblue: "#b0c4de", mediumvioletred: "#c71585", mintcream: "#f5fffa", navajowhite: "#ffdead", navy: "#000080", olivedrab: "#6b8e23", palevioletred: "#d87093", violetred: "#d02090", yellow: "#ff0", yellowgreen: "#9acd32", lawngreen: "#7cfc00", pink: "#ffc0cb", paleturquoise: "#afeeee", palegoldenrod: "#eee8aa", darkolivegreen: "#556b2f", darkseagreen: "#8fbc8f", darkturquoise: "#00ced1", peachpuff: "#ffdab9", deeppink: "#ff1493", violet: "#ee82ee", palegreen: "#98fb98", mediumseagreen: "#3cb371", peru: "#cd853f", saddlebrown: "#8b4513", sandybrown: "#f4a460", rosybrown: "#bc8f8f", purple: "#800080", seagreen: "#2e8b57", seashell: "#fff5ee", papayawhip: "#ffefd5", mediumslateblue: "#7b68ee", plum: "#dda0dd", mediumspringgreen: "#00fa9a" };
function pk(t2) {
  return t2 < 0 ? 0 : t2 > 255 ? 255 : Math.round(t2) || 0;
}
function mk(t2) {
  return t2 <= 0 || t2 > 1 ? Math.min(Math.max(t2, 0), 1) : Math.round(1e4 * t2) / 1e4;
}
const gk = /^#([0-9a-f])([0-9a-f])([0-9a-f])([0-9a-f])?$/i, vk = /^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})?$/i, bk = /^rgb\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*\)$/, _k = /^rgba\(\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d{1,10})\s*,\s*(-?\d*\.?\d+)\s*\)$/;
function yk(t2) {
  (t2 = t2.toLowerCase()) in fk && (t2 = fk[t2]);
  {
    const e2 = _k.exec(t2) || bk.exec(t2);
    if (e2) return [pk(parseInt(e2[1], 10)), pk(parseInt(e2[2], 10)), pk(parseInt(e2[3], 10)), mk(e2.length < 5 ? 1 : parseFloat(e2[4]))];
  }
  {
    const e2 = vk.exec(t2);
    if (e2) return [pk(parseInt(e2[1], 16)), pk(parseInt(e2[2], 16)), pk(parseInt(e2[3], 16)), 1];
  }
  {
    const e2 = gk.exec(t2);
    if (e2) return [pk(17 * parseInt(e2[1], 16)), pk(17 * parseInt(e2[2], 16)), pk(17 * parseInt(e2[3], 16)), 1];
  }
  throw new Error(`Cannot parse color: ${t2}`);
}
function wk(t2) {
  return 0.199 * t2[0] + 0.687 * t2[1] + 0.114 * t2[2];
}
function xk(t2) {
  const e2 = yk(t2);
  return { t: `rgb(${e2[0]}, ${e2[1]}, ${e2[2]})`, i: wk(e2) > 160 ? "black" : "white" };
}
class D {
  constructor() {
    this.h = [];
  }
  l(t2, e2, i2) {
    const s2 = { o: t2, _: e2, u: true === i2 };
    this.h.push(s2);
  }
  v(t2) {
    const e2 = this.h.findIndex((e3) => t2 === e3.o);
    e2 > -1 && this.h.splice(e2, 1);
  }
  p(t2) {
    this.h = this.h.filter((e2) => e2._ !== t2);
  }
  m(t2, e2, i2) {
    const s2 = [...this.h];
    this.h = this.h.filter((t3) => !t3.u), s2.forEach((s3) => s3.o(t2, e2, i2));
  }
  M() {
    return this.h.length > 0;
  }
  S() {
    this.h = [];
  }
}
function kk(t2, ...e2) {
  for (const i2 of e2) for (const e3 in i2) void 0 !== i2[e3] && Object.prototype.hasOwnProperty.call(i2, e3) && !["__proto__", "constructor", "prototype"].includes(e3) && ("object" != typeof i2[e3] || void 0 === t2[e3] || Array.isArray(i2[e3]) ? t2[e3] = i2[e3] : kk(t2[e3], i2[e3]));
  return t2;
}
function Sk(t2) {
  return "number" == typeof t2 && isFinite(t2);
}
function Mk(t2) {
  return "number" == typeof t2 && t2 % 1 == 0;
}
function zk(t2) {
  return "string" == typeof t2;
}
function Ck(t2) {
  return "boolean" == typeof t2;
}
function Dk(t2) {
  const e2 = t2;
  if (!e2 || "object" != typeof e2) return e2;
  let i2, s2, n2;
  for (s2 in i2 = Array.isArray(e2) ? [] : {}, e2) e2.hasOwnProperty(s2) && (n2 = e2[s2], i2[s2] = n2 && "object" == typeof n2 ? Dk(n2) : n2);
  return i2;
}
function Rk(t2) {
  return null !== t2;
}
function Pk(t2) {
  return null === t2 ? void 0 : t2;
}
const Tk = "-apple-system, BlinkMacSystemFont, 'Trebuchet MS', Roboto, Ubuntu, sans-serif";
function $k(t2, e2, i2) {
  return void 0 === e2 && (e2 = Tk), `${i2 = void 0 !== i2 ? `${i2} ` : ""}${t2}px ${e2}`;
}
class W {
  constructor(t2) {
    this.k = { C: 1, T: 5, P: NaN, R: "", D: "", V: "", O: "", B: 0, A: 0, I: 0, L: 0, N: 0 }, this.F = t2;
  }
  W() {
    const t2 = this.k, e2 = this.j(), i2 = this.H();
    return t2.P === e2 && t2.D === i2 || (t2.P = e2, t2.D = i2, t2.R = $k(e2, i2), t2.L = 2.5 / 12 * e2, t2.B = t2.L, t2.A = e2 / 12 * t2.T, t2.I = e2 / 12 * t2.T, t2.N = 0), t2.V = this.$(), t2.O = this.U(), this.k;
  }
  $() {
    return this.F.W().layout.textColor;
  }
  U() {
    return this.F.q();
  }
  j() {
    return this.F.W().layout.fontSize;
  }
  H() {
    return this.F.W().layout.fontFamily;
  }
}
class j {
  constructor() {
    this.Y = [];
  }
  Z(t2) {
    this.Y = t2;
  }
  X(t2, e2, i2) {
    this.Y.forEach((s2) => {
      s2.X(t2, e2, i2);
    });
  }
}
class H {
  X(t2, e2, i2) {
    t2.useBitmapCoordinateSpace((t3) => this.K(t3, e2, i2));
  }
}
class $ extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.G || null === this.G.tt) return;
    const s2 = this.G.tt, n2 = this.G, r2 = Math.max(1, Math.floor(e2)) % 2 / 2, o2 = (o3) => {
      t2.beginPath();
      for (let a2 = s2.to - 1; a2 >= s2.from; --a2) {
        const s3 = n2.it[a2], l2 = Math.round(s3.nt * e2) + r2, h2 = s3.st * i2, c2 = o3 * i2 + r2;
        t2.moveTo(l2, h2), t2.arc(l2, h2, c2, 0, 2 * Math.PI);
      }
      t2.fill();
    };
    n2.et > 0 && (t2.fillStyle = n2.rt, o2(n2.ht + n2.et)), t2.fillStyle = n2.lt, o2(n2.ht);
  }
}
function Ek() {
  return { it: [{ nt: 0, st: 0, ot: 0, _t: 0 }], lt: "", rt: "", ht: 0, et: 0, tt: null };
}
const Ak = { from: 0, to: 1 };
class Y {
  constructor(t2, e2) {
    this.ut = new j(), this.ct = [], this.dt = [], this.ft = true, this.F = t2, this.vt = e2, this.ut.Z(this.ct);
  }
  bt(t2) {
    const e2 = this.F.wt();
    e2.length !== this.ct.length && (this.dt = e2.map(Ek), this.ct = this.dt.map((t3) => {
      const e3 = new $();
      return e3.J(t3), e3;
    }), this.ut.Z(this.ct)), this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.ut;
  }
  Mt() {
    const t2 = 2 === this.vt.W().mode, e2 = this.F.wt(), i2 = this.vt.xt(), s2 = this.F.St();
    e2.forEach((e3, n2) => {
      var r2;
      const o2 = this.dt[n2], a2 = e3.kt(i2);
      if (t2 || null === a2 || !e3.yt()) return void (o2.tt = null);
      const l2 = uk(e3.Ct());
      o2.lt = a2.Tt, o2.ht = a2.ht, o2.et = a2.Pt, o2.it[0]._t = a2._t, o2.it[0].st = e3.Dt().Rt(a2._t, l2.Vt), o2.rt = null !== (r2 = a2.Ot) && void 0 !== r2 ? r2 : this.F.Bt(o2.it[0].st / e3.Dt().At()), o2.it[0].ot = i2, o2.it[0].nt = s2.It(i2), o2.tt = Ak;
    });
  }
}
class Z extends H {
  constructor(t2) {
    super(), this.zt = t2;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    const n2 = this.zt.Lt.yt, r2 = this.zt.Et.yt;
    if (!n2 && !r2) return;
    const o2 = Math.round(this.zt.nt * i2), a2 = Math.round(this.zt.st * s2);
    t2.lineCap = "butt", n2 && o2 >= 0 && (t2.lineWidth = Math.floor(this.zt.Lt.et * i2), t2.strokeStyle = this.zt.Lt.V, t2.fillStyle = this.zt.Lt.V, ak(t2, this.zt.Lt.Nt), function(t3, e3, i3, s3) {
      t3.beginPath();
      const n3 = t3.lineWidth % 2 ? 0.5 : 0;
      t3.moveTo(e3 + n3, 0), t3.lineTo(e3 + n3, s3), t3.stroke();
    }(t2, o2, 0, e2.height)), r2 && a2 >= 0 && (t2.lineWidth = Math.floor(this.zt.Et.et * s2), t2.strokeStyle = this.zt.Et.V, t2.fillStyle = this.zt.Et.V, ak(t2, this.zt.Et.Nt), lk(t2, a2, 0, e2.width));
  }
}
class X {
  constructor(t2) {
    this.ft = true, this.Ft = { Lt: { et: 1, Nt: 0, V: "", yt: false }, Et: { et: 1, Nt: 0, V: "", yt: false }, nt: 0, st: 0 }, this.Wt = new Z(this.Ft), this.jt = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt;
  }
  Mt() {
    const t2 = this.jt.yt(), e2 = uk(this.jt.Ht()), i2 = e2.$t().W().crosshair, s2 = this.Ft;
    if (2 === i2.mode) return s2.Et.yt = false, void (s2.Lt.yt = false);
    s2.Et.yt = t2 && this.jt.Ut(e2), s2.Lt.yt = t2 && this.jt.qt(), s2.Et.et = i2.horzLine.width, s2.Et.Nt = i2.horzLine.style, s2.Et.V = i2.horzLine.color, s2.Lt.et = i2.vertLine.width, s2.Lt.Nt = i2.vertLine.style, s2.Lt.V = i2.vertLine.color, s2.nt = this.jt.Yt(), s2.st = this.jt.Zt();
  }
}
function Lk(t2, e2, i2, s2, n2, r2) {
  t2.fillRect(e2 + r2, i2, s2 - 2 * r2, r2), t2.fillRect(e2 + r2, i2 + n2 - r2, s2 - 2 * r2, r2), t2.fillRect(e2, i2, r2, n2), t2.fillRect(e2 + s2 - r2, i2, r2, n2);
}
function Vk(t2, e2, i2, s2, n2, r2) {
  t2.save(), t2.globalCompositeOperation = "copy", t2.fillStyle = r2, t2.fillRect(e2, i2, s2, n2), t2.restore();
}
function Ok(t2, e2, i2, s2, n2, r2) {
  t2.beginPath(), t2.roundRect ? t2.roundRect(e2, i2, s2, n2, r2) : (t2.lineTo(e2 + s2 - r2[1], i2), 0 !== r2[1] && t2.arcTo(e2 + s2, i2, e2 + s2, i2 + r2[1], r2[1]), t2.lineTo(e2 + s2, i2 + n2 - r2[2]), 0 !== r2[2] && t2.arcTo(e2 + s2, i2 + n2, e2 + s2 - r2[2], i2 + n2, r2[2]), t2.lineTo(e2 + r2[3], i2 + n2), 0 !== r2[3] && t2.arcTo(e2, i2 + n2, e2, i2 + n2 - r2[3], r2[3]), t2.lineTo(e2, i2 + r2[0]), 0 !== r2[0] && t2.arcTo(e2, i2, e2 + r2[0], i2, r2[0]));
}
function Ik(t2, e2, i2, s2, n2, r2, o2 = 0, a2 = [0, 0, 0, 0], l2 = "") {
  if (t2.save(), !o2 || !l2 || l2 === r2) return Ok(t2, e2, i2, s2, n2, a2), t2.fillStyle = r2, t2.fill(), void t2.restore();
  const h2 = o2 / 2;
  var c2;
  Ok(t2, e2 + h2, i2 + h2, s2 - o2, n2 - o2, (c2 = -h2, a2.map((t3) => 0 === t3 ? t3 : t3 + c2))), "transparent" !== r2 && (t2.fillStyle = r2, t2.fill()), "transparent" !== l2 && (t2.lineWidth = o2, t2.strokeStyle = l2, t2.closePath(), t2.stroke()), t2.restore();
}
function Nk(t2, e2, i2, s2, n2, r2, o2) {
  t2.save(), t2.globalCompositeOperation = "copy";
  const a2 = t2.createLinearGradient(0, 0, 0, n2);
  a2.addColorStop(0, r2), a2.addColorStop(1, o2), t2.fillStyle = a2, t2.fillRect(e2, i2, s2, n2), t2.restore();
}
class it {
  constructor(t2, e2) {
    this.J(t2, e2);
  }
  J(t2, e2) {
    this.zt = t2, this.Xt = e2;
  }
  At(t2, e2) {
    return this.zt.yt ? t2.P + t2.L + t2.B : 0;
  }
  X(t2, e2, i2, s2) {
    if (!this.zt.yt || 0 === this.zt.Kt.length) return;
    const n2 = this.zt.V, r2 = this.Xt.t, o2 = t2.useBitmapCoordinateSpace((t3) => {
      const o3 = t3.context;
      o3.font = e2.R;
      const a2 = this.Gt(t3, e2, i2, s2), l2 = a2.Jt;
      return a2.Qt ? Ik(o3, l2.ti, l2.ii, l2.ni, l2.si, r2, l2.ei, [l2.ht, 0, 0, l2.ht], r2) : Ik(o3, l2.ri, l2.ii, l2.ni, l2.si, r2, l2.ei, [0, l2.ht, l2.ht, 0], r2), this.zt.hi && (o3.fillStyle = n2, o3.fillRect(l2.ri, l2.li, l2.ai - l2.ri, l2.oi)), this.zt._i && (o3.fillStyle = e2.O, o3.fillRect(a2.Qt ? l2.ui - l2.ei : 0, l2.ii, l2.ei, l2.ci - l2.ii)), a2;
    });
    t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const i3 = o2.di;
      t3.font = e2.R, t3.textAlign = o2.Qt ? "right" : "left", t3.textBaseline = "middle", t3.fillStyle = n2, t3.fillText(this.zt.Kt, i3.fi, (i3.ii + i3.ci) / 2 + i3.pi);
    });
  }
  Gt(t2, e2, i2, s2) {
    var n2;
    const { context: r2, bitmapSize: o2, mediaSize: a2, horizontalPixelRatio: l2, verticalPixelRatio: h2 } = t2, c2 = this.zt.hi || !this.zt.mi ? e2.T : 0, u2 = this.zt.bi ? e2.C : 0, d2 = e2.L + this.Xt.wi, f2 = e2.B + this.Xt.gi, p2 = e2.A, m2 = e2.I, g2 = this.zt.Kt, v2 = e2.P, b2 = i2.Mi(r2, g2), _2 = Math.ceil(i2.xi(r2, g2)), y2 = v2 + d2 + f2, w2 = e2.C + p2 + m2 + _2 + c2, x2 = Math.max(1, Math.floor(h2));
    let k2 = Math.round(y2 * h2);
    k2 % 2 != x2 % 2 && (k2 += 1);
    const S2 = u2 > 0 ? Math.max(1, Math.floor(u2 * l2)) : 0, M2 = Math.round(w2 * l2), z2 = Math.round(c2 * l2), C2 = null !== (n2 = this.Xt.Si) && void 0 !== n2 ? n2 : this.Xt.ki, R2 = Math.round(C2 * h2) - Math.floor(0.5 * h2), P2 = Math.floor(R2 + x2 / 2 - k2 / 2), T2 = P2 + k2, E2 = "right" === s2, A2 = E2 ? a2.width - u2 : u2, L2 = E2 ? o2.width - S2 : S2;
    let V2, O2, I2;
    return E2 ? (V2 = L2 - M2, O2 = L2 - z2, I2 = A2 - c2 - p2 - u2) : (V2 = L2 + M2, O2 = L2 + z2, I2 = A2 + c2 + p2), { Qt: E2, Jt: { ii: P2, li: R2, ci: T2, ni: M2, si: k2, ht: 2 * l2, ei: S2, ti: V2, ri: L2, ai: O2, oi: x2, ui: o2.width }, di: { ii: P2 / h2, ci: T2 / h2, fi: I2, pi: b2 } };
  }
}
class nt {
  constructor(t2) {
    this.yi = { ki: 0, t: "#000", gi: 0, wi: 0 }, this.Ci = { Kt: "", yt: false, hi: true, mi: false, Ot: "", V: "#FFF", _i: false, bi: false }, this.Ti = { Kt: "", yt: false, hi: false, mi: true, Ot: "", V: "#FFF", _i: true, bi: true }, this.ft = true, this.Pi = new (t2 || it)(this.Ci, this.yi), this.Ri = new (t2 || it)(this.Ti, this.yi);
  }
  Kt() {
    return this.Di(), this.Ci.Kt;
  }
  ki() {
    return this.Di(), this.yi.ki;
  }
  bt() {
    this.ft = true;
  }
  At(t2, e2 = false) {
    return Math.max(this.Pi.At(t2, e2), this.Ri.At(t2, e2));
  }
  Vi() {
    return this.yi.Si || 0;
  }
  Oi(t2) {
    this.yi.Si = t2;
  }
  Bi() {
    return this.Di(), this.Ci.yt || this.Ti.yt;
  }
  Ai() {
    return this.Di(), this.Ci.yt;
  }
  gt(t2) {
    return this.Di(), this.Ci.hi = this.Ci.hi && t2.W().ticksVisible, this.Ti.hi = this.Ti.hi && t2.W().ticksVisible, this.Pi.J(this.Ci, this.yi), this.Ri.J(this.Ti, this.yi), this.Pi;
  }
  Ii() {
    return this.Di(), this.Pi.J(this.Ci, this.yi), this.Ri.J(this.Ti, this.yi), this.Ri;
  }
  Di() {
    this.ft && (this.Ci.hi = true, this.Ti.hi = false, this.zi(this.Ci, this.Ti, this.yi));
  }
}
class st extends nt {
  constructor(t2, e2, i2) {
    super(), this.jt = t2, this.Li = e2, this.Ei = i2;
  }
  zi(t2, e2, i2) {
    if (t2.yt = false, 2 === this.jt.W().mode) return;
    const s2 = this.jt.W().horzLine;
    if (!s2.labelVisible) return;
    const n2 = this.Li.Ct();
    if (!this.jt.yt() || this.Li.Ni() || null === n2) return;
    const r2 = xk(s2.labelBackgroundColor);
    i2.t = r2.t, t2.V = r2.i;
    const o2 = 2 / 12 * this.Li.P();
    i2.wi = o2, i2.gi = o2;
    const a2 = this.Ei(this.Li);
    i2.ki = a2.ki, t2.Kt = this.Li.Fi(a2._t, n2), t2.yt = true;
  }
}
const Fk = /[1-9]/g;
class rt {
  constructor() {
    this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  X(t2, e2) {
    if (null === this.zt || false === this.zt.yt || 0 === this.zt.Kt.length) return;
    const i2 = t2.useMediaCoordinateSpace(({ context: t3 }) => (t3.font = e2.R, Math.round(e2.Wi.xi(t3, uk(this.zt).Kt, Fk))));
    if (i2 <= 0) return;
    const s2 = e2.ji, n2 = i2 + 2 * s2, r2 = n2 / 2, o2 = this.zt.Hi;
    let a2 = this.zt.ki, l2 = Math.floor(a2 - r2) + 0.5;
    l2 < 0 ? (a2 += Math.abs(0 - l2), l2 = Math.floor(a2 - r2) + 0.5) : l2 + n2 > o2 && (a2 -= Math.abs(o2 - (l2 + n2)), l2 = Math.floor(a2 - r2) + 0.5);
    const h2 = l2 + n2, c2 = Math.ceil(0 + e2.C + e2.T + e2.L + e2.P + e2.B);
    t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: i3, verticalPixelRatio: s3 }) => {
      const n3 = uk(this.zt);
      t3.fillStyle = n3.t;
      const r3 = Math.round(l2 * i3), o3 = Math.round(0 * s3), a3 = Math.round(h2 * i3), u2 = Math.round(c2 * s3), d2 = Math.round(2 * i3);
      if (t3.beginPath(), t3.moveTo(r3, o3), t3.lineTo(r3, u2 - d2), t3.arcTo(r3, u2, r3 + d2, u2, d2), t3.lineTo(a3 - d2, u2), t3.arcTo(a3, u2, a3, u2 - d2, d2), t3.lineTo(a3, o3), t3.fill(), n3.hi) {
        const r4 = Math.round(n3.ki * i3), a4 = o3, l3 = Math.round((a4 + e2.T) * s3);
        t3.fillStyle = n3.V;
        const h3 = Math.max(1, Math.floor(i3)), c3 = Math.floor(0.5 * i3);
        t3.fillRect(r4 - c3, a4, h3, l3 - a4);
      }
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const i3 = uk(this.zt), n3 = 0 + e2.C + e2.T + e2.L + e2.P / 2;
      t3.font = e2.R, t3.textAlign = "left", t3.textBaseline = "middle", t3.fillStyle = i3.V;
      const r3 = e2.Wi.Mi(t3, "Apr0");
      t3.translate(l2 + s2, n3 + r3), t3.fillText(i3.Kt, 0, 0);
    });
  }
}
class ht {
  constructor(t2, e2, i2) {
    this.ft = true, this.Wt = new rt(), this.Ft = { yt: false, t: "#4c525e", V: "white", Kt: "", Hi: 0, ki: NaN, hi: true }, this.vt = t2, this.$i = e2, this.Ei = i2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt.J(this.Ft), this.Wt;
  }
  Mt() {
    const t2 = this.Ft;
    if (t2.yt = false, 2 === this.vt.W().mode) return;
    const e2 = this.vt.W().vertLine;
    if (!e2.labelVisible) return;
    const i2 = this.$i.St();
    if (i2.Ni()) return;
    t2.Hi = i2.Hi();
    const s2 = this.Ei();
    if (null === s2) return;
    t2.ki = s2.ki;
    const n2 = i2.Ui(this.vt.xt());
    t2.Kt = i2.qi(uk(n2)), t2.yt = true;
    const r2 = xk(e2.labelBackgroundColor);
    t2.t = r2.t, t2.V = r2.i, t2.hi = i2.W().ticksVisible;
  }
}
class lt {
  constructor() {
    this.Yi = null, this.Zi = 0;
  }
  Xi() {
    return this.Zi;
  }
  Ki(t2) {
    this.Zi = t2;
  }
  Dt() {
    return this.Yi;
  }
  Gi(t2) {
    this.Yi = t2;
  }
  Ji(t2) {
    return [];
  }
  Qi() {
    return [];
  }
  yt() {
    return true;
  }
}
var Wk;
!function(t2) {
  t2[t2.Normal = 0] = "Normal", t2[t2.Magnet = 1] = "Magnet", t2[t2.Hidden = 2] = "Hidden";
}(Wk || (Wk = {}));
class ot extends lt {
  constructor(t2, e2) {
    super(), this.tn = null, this.nn = NaN, this.sn = 0, this.en = true, this.rn = /* @__PURE__ */ new Map(), this.hn = false, this.ln = NaN, this.an = NaN, this._n = NaN, this.un = NaN, this.$i = t2, this.cn = e2, this.dn = new Y(t2, this), this.fn = /* @__PURE__ */ ((t3, e3) => (i3) => {
      const s2 = e3(), n2 = t3();
      if (i3 === uk(this.tn).vn()) return { _t: n2, ki: s2 };
      {
        const t4 = uk(i3.Ct());
        return { _t: i3.pn(s2, t4), ki: s2 };
      }
    })(() => this.nn, () => this.an);
    const i2 = /* @__PURE__ */ ((t3, e3) => () => {
      const i3 = this.$i.St().mn(t3()), s2 = e3();
      return i3 && Number.isFinite(s2) ? { ot: i3, ki: s2 } : null;
    })(() => this.sn, () => this.Yt());
    this.bn = new ht(this, t2, i2), this.wn = new X(this);
  }
  W() {
    return this.cn;
  }
  gn(t2, e2) {
    this._n = t2, this.un = e2;
  }
  Mn() {
    this._n = NaN, this.un = NaN;
  }
  xn() {
    return this._n;
  }
  Sn() {
    return this.un;
  }
  kn(t2, e2, i2) {
    this.hn || (this.hn = true), this.en = true, this.yn(t2, e2, i2);
  }
  xt() {
    return this.sn;
  }
  Yt() {
    return this.ln;
  }
  Zt() {
    return this.an;
  }
  yt() {
    return this.en;
  }
  Cn() {
    this.en = false, this.Tn(), this.nn = NaN, this.ln = NaN, this.an = NaN, this.tn = null, this.Mn();
  }
  Pn(t2) {
    return null !== this.tn ? [this.wn, this.dn] : [];
  }
  Ut(t2) {
    return t2 === this.tn && this.cn.horzLine.visible;
  }
  qt() {
    return this.cn.vertLine.visible;
  }
  Rn(t2, e2) {
    this.en && this.tn === t2 || this.rn.clear();
    const i2 = [];
    return this.tn === t2 && i2.push(this.Dn(this.rn, e2, this.fn)), i2;
  }
  Qi() {
    return this.en ? [this.bn] : [];
  }
  Ht() {
    return this.tn;
  }
  Vn() {
    this.wn.bt(), this.rn.forEach((t2) => t2.bt()), this.bn.bt(), this.dn.bt();
  }
  On(t2) {
    return t2 && !t2.vn().Ni() ? t2.vn() : null;
  }
  yn(t2, e2, i2) {
    this.Bn(t2, e2, i2) && this.Vn();
  }
  Bn(t2, e2, i2) {
    const s2 = this.ln, n2 = this.an, r2 = this.nn, o2 = this.sn, a2 = this.tn, l2 = this.On(i2);
    this.sn = t2, this.ln = isNaN(t2) ? NaN : this.$i.St().It(t2), this.tn = i2;
    const h2 = null !== l2 ? l2.Ct() : null;
    return null !== l2 && null !== h2 ? (this.nn = e2, this.an = l2.Rt(e2, h2)) : (this.nn = NaN, this.an = NaN), s2 !== this.ln || n2 !== this.an || o2 !== this.sn || r2 !== this.nn || a2 !== this.tn;
  }
  Tn() {
    const t2 = this.$i.wt().map((t3) => t3.In().An()).filter(Rk), e2 = 0 === t2.length ? null : Math.max(...t2);
    this.sn = null !== e2 ? e2 : NaN;
  }
  Dn(t2, e2, i2) {
    let s2 = t2.get(e2);
    return void 0 === s2 && (s2 = new st(this, e2, i2), t2.set(e2, s2)), s2;
  }
}
function Bk(t2) {
  return "left" === t2 || "right" === t2;
}
class ut {
  constructor(t2) {
    this.zn = /* @__PURE__ */ new Map(), this.Ln = [], this.En = t2;
  }
  Nn(t2, e2) {
    const i2 = function(t3, e3) {
      return void 0 === t3 ? e3 : { Fn: Math.max(t3.Fn, e3.Fn), Wn: t3.Wn || e3.Wn };
    }(this.zn.get(t2), e2);
    this.zn.set(t2, i2);
  }
  jn() {
    return this.En;
  }
  Hn(t2) {
    const e2 = this.zn.get(t2);
    return void 0 === e2 ? { Fn: this.En } : { Fn: Math.max(this.En, e2.Fn), Wn: e2.Wn };
  }
  $n() {
    this.Un(), this.Ln = [{ qn: 0 }];
  }
  Yn(t2) {
    this.Un(), this.Ln = [{ qn: 1, Vt: t2 }];
  }
  Zn(t2) {
    this.Xn(), this.Ln.push({ qn: 5, Vt: t2 });
  }
  Un() {
    this.Xn(), this.Ln.push({ qn: 6 });
  }
  Kn() {
    this.Un(), this.Ln = [{ qn: 4 }];
  }
  Gn(t2) {
    this.Un(), this.Ln.push({ qn: 2, Vt: t2 });
  }
  Jn(t2) {
    this.Un(), this.Ln.push({ qn: 3, Vt: t2 });
  }
  Qn() {
    return this.Ln;
  }
  ts(t2) {
    for (const e2 of t2.Ln) this.ns(e2);
    this.En = Math.max(this.En, t2.En), t2.zn.forEach((t3, e2) => {
      this.Nn(e2, t3);
    });
  }
  static ss() {
    return new ut(2);
  }
  static es() {
    return new ut(3);
  }
  ns(t2) {
    switch (t2.qn) {
      case 0:
        this.$n();
        break;
      case 1:
        this.Yn(t2.Vt);
        break;
      case 2:
        this.Gn(t2.Vt);
        break;
      case 3:
        this.Jn(t2.Vt);
        break;
      case 4:
        this.Kn();
        break;
      case 5:
        this.Zn(t2.Vt);
        break;
      case 6:
        this.Xn();
    }
  }
  Xn() {
    const t2 = this.Ln.findIndex((t3) => 5 === t3.qn);
    -1 !== t2 && this.Ln.splice(t2, 1);
  }
}
function jk(t2, e2) {
  if (!Sk(t2)) return "n/a";
  if (!Mk(e2)) throw new TypeError("invalid length");
  if (e2 < 0 || e2 > 16) throw new TypeError("invalid length");
  return 0 === e2 ? t2.toString() : ("0000000000000000" + t2.toString()).slice(-e2);
}
class ft {
  constructor(t2, e2) {
    if (e2 || (e2 = 1), Sk(t2) && Mk(t2) || (t2 = 100), t2 < 0) throw new TypeError("invalid base");
    this.Li = t2, this.rs = e2, this.hs();
  }
  format(t2) {
    const e2 = t2 < 0 ? "−" : "";
    return t2 = Math.abs(t2), e2 + this.ls(t2);
  }
  hs() {
    if (this._s = 0, this.Li > 0 && this.rs > 0) {
      let t2 = this.Li;
      for (; t2 > 1; ) t2 /= 10, this._s++;
    }
  }
  ls(t2) {
    const e2 = this.Li / this.rs;
    let i2 = Math.floor(t2), s2 = "";
    const n2 = void 0 !== this._s ? this._s : NaN;
    if (e2 > 1) {
      let r2 = +(Math.round(t2 * e2) - i2 * e2).toFixed(this._s);
      r2 >= e2 && (r2 -= e2, i2 += 1), s2 = "." + jk(+r2.toFixed(this._s) * this.rs, n2);
    } else i2 = Math.round(i2 * e2) / e2, n2 > 0 && (s2 = "." + jk(0, n2));
    return i2.toFixed(0) + s2;
  }
}
class vt extends ft {
  constructor(t2 = 100) {
    super(t2);
  }
  format(t2) {
    return `${super.format(t2)}%`;
  }
}
class pt {
  constructor(t2) {
    this.us = t2;
  }
  format(t2) {
    let e2 = "";
    return t2 < 0 && (e2 = "-", t2 = -t2), t2 < 995 ? e2 + this.cs(t2) : t2 < 999995 ? e2 + this.cs(t2 / 1e3) + "K" : t2 < 999999995 ? (t2 = 1e3 * Math.round(t2 / 1e3), e2 + this.cs(t2 / 1e6) + "M") : (t2 = 1e6 * Math.round(t2 / 1e6), e2 + this.cs(t2 / 1e9) + "B");
  }
  cs(t2) {
    let e2;
    const i2 = Math.pow(10, this.us);
    return e2 = (t2 = Math.round(t2 * i2) / i2) >= 1e-15 && t2 < 1 ? t2.toFixed(this.us).replace(/\.?0+$/, "") : String(t2), e2.replace(/(\.[1-9]*)0+$/, (t3, e3) => e3);
  }
}
function qk(t2, e2, i2, s2, n2, r2, o2) {
  if (0 === e2.length || s2.from >= e2.length || s2.to <= 0) return;
  const { context: a2, horizontalPixelRatio: l2, verticalPixelRatio: h2 } = t2, c2 = e2[s2.from];
  let u2 = r2(t2, c2), d2 = c2;
  if (s2.to - s2.from < 2) {
    const e3 = n2 / 2;
    a2.beginPath();
    const i3 = { nt: c2.nt - e3, st: c2.st }, s3 = { nt: c2.nt + e3, st: c2.st };
    a2.moveTo(i3.nt * l2, i3.st * h2), a2.lineTo(s3.nt * l2, s3.st * h2), o2(t2, u2, i3, s3);
  } else {
    const n3 = (e3, i3) => {
      o2(t2, u2, d2, i3), a2.beginPath(), u2 = e3, d2 = i3;
    };
    let f2 = d2;
    a2.beginPath(), a2.moveTo(c2.nt * l2, c2.st * h2);
    for (let o3 = s2.from + 1; o3 < s2.to; ++o3) {
      f2 = e2[o3];
      const s3 = r2(t2, f2);
      switch (i2) {
        case 0:
          a2.lineTo(f2.nt * l2, f2.st * h2);
          break;
        case 1:
          a2.lineTo(f2.nt * l2, e2[o3 - 1].st * h2), s3 !== u2 && (n3(s3, f2), a2.lineTo(f2.nt * l2, e2[o3 - 1].st * h2)), a2.lineTo(f2.nt * l2, f2.st * h2);
          break;
        case 2: {
          const [t3, i3] = Yk(e2, o3 - 1, o3);
          a2.bezierCurveTo(t3.nt * l2, t3.st * h2, i3.nt * l2, i3.st * h2, f2.nt * l2, f2.st * h2);
          break;
        }
      }
      1 !== i2 && s3 !== u2 && (n3(s3, f2), a2.moveTo(f2.nt * l2, f2.st * h2));
    }
    (d2 !== f2 || d2 === f2 && 1 === i2) && o2(t2, u2, d2, f2);
  }
}
const Hk = 6;
function Uk(t2, e2) {
  return { nt: t2.nt - e2.nt, st: t2.st - e2.st };
}
function Kk(t2, e2) {
  return { nt: t2.nt / e2, st: t2.st / e2 };
}
function Yk(t2, e2, i2) {
  const s2 = Math.max(0, e2 - 1), n2 = Math.min(t2.length - 1, i2 + 1);
  var r2, o2;
  return [(r2 = t2[e2], o2 = Kk(Uk(t2[i2], t2[s2]), Hk), { nt: r2.nt + o2.nt, st: r2.st + o2.st }), Uk(t2[i2], Kk(Uk(t2[n2], t2[e2]), Hk))];
}
function Gk(t2, e2, i2, s2, n2) {
  const { context: r2, horizontalPixelRatio: o2, verticalPixelRatio: a2 } = e2;
  r2.lineTo(n2.nt * o2, t2 * a2), r2.lineTo(s2.nt * o2, t2 * a2), r2.closePath(), r2.fillStyle = i2, r2.fill();
}
class St extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K(t2) {
    var e2;
    if (null === this.G) return;
    const { it: i2, tt: s2, ds: n2, et: r2, Nt: o2, fs: a2 } = this.G, l2 = null !== (e2 = this.G.vs) && void 0 !== e2 ? e2 : this.G.ps ? 0 : t2.mediaSize.height;
    if (null === s2) return;
    const h2 = t2.context;
    h2.lineCap = "butt", h2.lineJoin = "round", h2.lineWidth = r2, ak(h2, o2), h2.lineWidth = 1, qk(t2, i2, a2, s2, n2, this.bs.bind(this), Gk.bind(null, l2));
  }
}
function Xk(t2, e2, i2) {
  return Math.min(Math.max(t2, e2), i2);
}
function Jk(t2, e2, i2) {
  return e2 - t2 <= i2;
}
function Qk(t2) {
  const e2 = Math.ceil(t2);
  return e2 % 2 == 0 ? e2 - 1 : e2;
}
class Tt {
  ws(t2, e2) {
    const i2 = this.gs, { Ms: s2, xs: n2, Ss: r2, ks: o2, ys: a2, vs: l2 } = e2;
    if (void 0 === this.Cs || void 0 === i2 || i2.Ms !== s2 || i2.xs !== n2 || i2.Ss !== r2 || i2.ks !== o2 || i2.vs !== l2 || i2.ys !== a2) {
      const i3 = t2.context.createLinearGradient(0, 0, 0, a2);
      if (i3.addColorStop(0, s2), null != l2) {
        const e3 = Xk(l2 * t2.verticalPixelRatio / a2, 0, 1);
        i3.addColorStop(e3, n2), i3.addColorStop(e3, r2);
      }
      i3.addColorStop(1, o2), this.Cs = i3, this.gs = e2;
    }
    return this.Cs;
  }
}
class Pt extends St {
  constructor() {
    super(...arguments), this.Ts = new Tt();
  }
  bs(t2, e2) {
    return this.Ts.ws(t2, { Ms: e2.Ps, xs: "", Ss: "", ks: e2.Rs, ys: t2.bitmapSize.height });
  }
}
function Zk(t2, e2) {
  const i2 = t2.context;
  i2.strokeStyle = e2, i2.stroke();
}
class Dt extends H {
  constructor() {
    super(...arguments), this.G = null;
  }
  J(t2) {
    this.G = t2;
  }
  K(t2) {
    if (null === this.G) return;
    const { it: e2, tt: i2, ds: s2, fs: n2, et: r2, Nt: o2, Ds: a2 } = this.G;
    if (null === i2) return;
    const l2 = t2.context;
    l2.lineCap = "butt", l2.lineWidth = r2 * t2.verticalPixelRatio, ak(l2, o2), l2.lineJoin = "round";
    const h2 = this.Vs.bind(this);
    void 0 !== n2 && qk(t2, e2, n2, i2, s2, h2, Zk), a2 && function(t3, e3, i3, s3, n3) {
      const { horizontalPixelRatio: r3, verticalPixelRatio: o3, context: a3 } = t3;
      let l3 = null;
      const h3 = Math.max(1, Math.floor(r3)) % 2 / 2, c2 = i3 * o3 + h3;
      for (let i4 = s3.to - 1; i4 >= s3.from; --i4) {
        const s4 = e3[i4];
        if (s4) {
          const e4 = n3(t3, s4);
          e4 !== l3 && (a3.beginPath(), null !== l3 && a3.fill(), a3.fillStyle = e4, l3 = e4);
          const i5 = Math.round(s4.nt * r3) + h3, u2 = s4.st * o3;
          a3.moveTo(i5, u2), a3.arc(i5, u2, c2, 0, 2 * Math.PI);
        }
      }
      a3.fill();
    }(t2, e2, a2, i2, h2);
  }
}
class Vt extends Dt {
  Vs(t2, e2) {
    return e2.lt;
  }
}
function tS(t2, e2, i2, s2, n2 = 0, r2 = e2.length) {
  let o2 = r2 - n2;
  for (; 0 < o2; ) {
    const r3 = o2 >> 1, a2 = n2 + r3;
    s2(e2[a2], i2) === t2 ? (n2 = a2 + 1, o2 -= r3 + 1) : o2 = r3;
  }
  return n2;
}
const eS = tS.bind(null, true), iS = tS.bind(null, false);
function sS(t2, e2) {
  return t2.ot < e2;
}
function nS(t2, e2) {
  return e2 < t2.ot;
}
function rS(t2, e2, i2) {
  const s2 = e2.Os(), n2 = e2.ui(), r2 = eS(t2, s2, sS), o2 = iS(t2, n2, nS);
  if (!i2) return { from: r2, to: o2 };
  let a2 = r2, l2 = o2;
  return r2 > 0 && r2 < t2.length && t2[r2].ot >= s2 && (a2 = r2 - 1), o2 > 0 && o2 < t2.length && t2[o2 - 1].ot <= n2 && (l2 = o2 + 1), { from: a2, to: l2 };
}
class Et {
  constructor(t2, e2, i2) {
    this.Bs = true, this.As = true, this.Is = true, this.zs = [], this.Ls = null, this.Es = t2, this.Ns = e2, this.Fs = i2;
  }
  bt(t2) {
    this.Bs = true, "data" === t2 && (this.As = true), "options" === t2 && (this.Is = true);
  }
  gt() {
    return this.Es.yt() ? (this.Ws(), null === this.Ls ? null : this.js) : null;
  }
  Hs() {
    this.zs = this.zs.map((t2) => Object.assign(Object.assign({}, t2), this.Es.Us().$s(t2.ot)));
  }
  qs() {
    this.Ls = null;
  }
  Ws() {
    this.As && (this.Ys(), this.As = false), this.Is && (this.Hs(), this.Is = false), this.Bs && (this.Zs(), this.Bs = false);
  }
  Zs() {
    const t2 = this.Es.Dt(), e2 = this.Ns.St();
    if (this.qs(), e2.Ni() || t2.Ni()) return;
    const i2 = e2.Xs();
    if (null === i2) return;
    if (0 === this.Es.In().Ks()) return;
    const s2 = this.Es.Ct();
    null !== s2 && (this.Ls = rS(this.zs, i2, this.Fs), this.Gs(t2, e2, s2.Vt), this.Js());
  }
}
class Nt extends Et {
  constructor(t2, e2) {
    super(t2, e2, true);
  }
  Gs(t2, e2, i2) {
    e2.Qs(this.zs, Pk(this.Ls)), t2.te(this.zs, i2, Pk(this.Ls));
  }
  ie(t2, e2) {
    return { ot: t2, _t: e2, nt: NaN, st: NaN };
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => {
      const i2 = e2.Vt[3];
      return this.se(e2.ee, i2, t2);
    });
  }
}
class Ft extends Nt {
  constructor(t2, e2) {
    super(t2, e2), this.js = new j(), this.re = new Pt(), this.he = new Vt(), this.js.Z([this.re, this.he]);
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.re.J({ fs: t2.lineType, it: this.zs, Nt: t2.lineStyle, et: t2.lineWidth, vs: null, ps: t2.invertFilledArea, tt: this.Ls, ds: this.Ns.St().le() }), this.he.J({ fs: t2.lineVisible ? t2.lineType : void 0, it: this.zs, Nt: t2.lineStyle, et: t2.lineWidth, tt: this.Ls, ds: this.Ns.St().le(), Ds: t2.pointMarkersVisible ? t2.pointMarkersRadius || t2.lineWidth / 2 + 2 : void 0 });
  }
}
class Wt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ae = 0, this.oe = 0;
  }
  J(t2) {
    this.zt = t2;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.zt || 0 === this.zt.In.length || null === this.zt.tt) return;
    this.ae = this._e(e2), this.ae >= 2 && Math.max(1, Math.floor(e2)) % 2 != this.ae % 2 && this.ae--, this.oe = this.zt.ue ? Math.min(this.ae, Math.floor(e2)) : this.ae;
    let s2 = null;
    const n2 = this.oe <= this.ae && this.zt.le >= Math.floor(1.5 * e2);
    for (let r2 = this.zt.tt.from; r2 < this.zt.tt.to; ++r2) {
      const o2 = this.zt.In[r2];
      s2 !== o2.ce && (t2.fillStyle = o2.ce, s2 = o2.ce);
      const a2 = Math.floor(0.5 * this.oe), l2 = Math.round(o2.nt * e2), h2 = l2 - a2, c2 = this.oe, u2 = h2 + c2 - 1, d2 = Math.min(o2.de, o2.fe), f2 = Math.max(o2.de, o2.fe), p2 = Math.round(d2 * i2) - a2, m2 = Math.round(f2 * i2) + a2, g2 = Math.max(m2 - p2, this.oe);
      t2.fillRect(h2, p2, c2, g2);
      const v2 = Math.ceil(1.5 * this.ae);
      if (n2) {
        if (this.zt.ve) {
          const e4 = l2 - v2;
          let s4 = Math.max(p2, Math.round(o2.pe * i2) - a2), n4 = s4 + c2 - 1;
          n4 > p2 + g2 - 1 && (n4 = p2 + g2 - 1, s4 = n4 - c2 + 1), t2.fillRect(e4, s4, h2 - e4, n4 - s4 + 1);
        }
        const e3 = l2 + v2;
        let s3 = Math.max(p2, Math.round(o2.me * i2) - a2), n3 = s3 + c2 - 1;
        n3 > p2 + g2 - 1 && (n3 = p2 + g2 - 1, s3 = n3 - c2 + 1), t2.fillRect(u2 + 1, s3, e3 - u2, n3 - s3 + 1);
      }
    }
  }
  _e(t2) {
    const e2 = Math.floor(t2);
    return Math.max(e2, Math.floor(function(t3, e3) {
      return Math.floor(0.3 * t3 * e3);
    }(uk(this.zt).le, t2)));
  }
}
class jt extends Et {
  constructor(t2, e2) {
    super(t2, e2, false);
  }
  Gs(t2, e2, i2) {
    e2.Qs(this.zs, Pk(this.Ls)), t2.be(this.zs, i2, Pk(this.Ls));
  }
  we(t2, e2, i2) {
    return { ot: t2, ge: e2.Vt[0], Me: e2.Vt[1], xe: e2.Vt[2], Se: e2.Vt[3], nt: NaN, pe: NaN, de: NaN, fe: NaN, me: NaN };
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => this.se(e2.ee, e2, t2));
  }
}
class Ht extends jt {
  constructor() {
    super(...arguments), this.js = new Wt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.we(t2, e2, i2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.js.J({ In: this.zs, le: this.Ns.St().le(), ve: t2.openVisible, ue: t2.thinBars, tt: this.Ls });
  }
}
class $t extends St {
  constructor() {
    super(...arguments), this.Ts = new Tt();
  }
  bs(t2, e2) {
    const i2 = this.G;
    return this.Ts.ws(t2, { Ms: e2.ke, xs: e2.ye, Ss: e2.Ce, ks: e2.Te, ys: t2.bitmapSize.height, vs: i2.vs });
  }
}
class Ut extends Dt {
  constructor() {
    super(...arguments), this.Pe = new Tt();
  }
  Vs(t2, e2) {
    const i2 = this.G;
    return this.Pe.ws(t2, { Ms: e2.Re, xs: e2.Re, Ss: e2.De, ks: e2.De, ys: t2.bitmapSize.height, vs: i2.vs });
  }
}
class qt extends Nt {
  constructor(t2, e2) {
    super(t2, e2), this.js = new j(), this.Ve = new $t(), this.Oe = new Ut(), this.js.Z([this.Ve, this.Oe]);
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.Ct();
    if (null === t2) return;
    const e2 = this.Es.W(), i2 = this.Es.Dt().Rt(e2.baseValue.price, t2.Vt), s2 = this.Ns.St().le();
    this.Ve.J({ it: this.zs, et: e2.lineWidth, Nt: e2.lineStyle, fs: e2.lineType, vs: i2, ps: false, tt: this.Ls, ds: s2 }), this.Oe.J({ it: this.zs, et: e2.lineWidth, Nt: e2.lineStyle, fs: e2.lineVisible ? e2.lineType : void 0, Ds: e2.pointMarkersVisible ? e2.pointMarkersRadius || e2.lineWidth / 2 + 2 : void 0, vs: i2, tt: this.Ls, ds: s2 });
  }
}
class Yt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ae = 0;
  }
  J(t2) {
    this.zt = t2;
  }
  K(t2) {
    if (null === this.zt || 0 === this.zt.In.length || null === this.zt.tt) return;
    const { horizontalPixelRatio: e2 } = t2;
    this.ae = function(t3, e3) {
      if (t3 >= 2.5 && t3 <= 4) return Math.floor(3 * e3);
      const i3 = 1 - 0.2 * Math.atan(Math.max(4, t3) - 4) / (0.5 * Math.PI), s3 = Math.floor(t3 * i3 * e3), n2 = Math.floor(t3 * e3), r2 = Math.min(s3, n2);
      return Math.max(Math.floor(e3), r2);
    }(this.zt.le, e2), this.ae >= 2 && Math.floor(e2) % 2 != this.ae % 2 && this.ae--;
    const i2 = this.zt.In;
    this.zt.Be && this.Ae(t2, i2, this.zt.tt), this.zt._i && this.Ie(t2, i2, this.zt.tt);
    const s2 = this.ze(e2);
    (!this.zt._i || this.ae > 2 * s2) && this.Le(t2, i2, this.zt.tt);
  }
  Ae(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "", a2 = Math.min(Math.floor(n2), Math.floor(this.zt.le * n2));
    a2 = Math.max(Math.floor(n2), Math.min(a2, this.ae));
    const l2 = Math.floor(0.5 * a2);
    let h2 = null;
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      i3.Ee !== o2 && (s2.fillStyle = i3.Ee, o2 = i3.Ee);
      const c2 = Math.round(Math.min(i3.pe, i3.me) * r2), u2 = Math.round(Math.max(i3.pe, i3.me) * r2), d2 = Math.round(i3.de * r2), f2 = Math.round(i3.fe * r2);
      let p2 = Math.round(n2 * i3.nt) - l2;
      const m2 = p2 + a2 - 1;
      null !== h2 && (p2 = Math.max(h2 + 1, p2), p2 = Math.min(p2, m2));
      const g2 = m2 - p2 + 1;
      s2.fillRect(p2, d2, g2, c2 - d2), s2.fillRect(p2, u2 + 1, g2, f2 - u2), h2 = m2;
    }
  }
  ze(t2) {
    let e2 = Math.floor(1 * t2);
    this.ae <= 2 * e2 && (e2 = Math.floor(0.5 * (this.ae - 1)));
    const i2 = Math.max(Math.floor(t2), e2);
    return this.ae <= 2 * i2 ? Math.max(Math.floor(t2), Math.floor(1 * t2)) : i2;
  }
  Ie(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "";
    const a2 = this.ze(n2);
    let l2 = null;
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      i3.Ne !== o2 && (s2.fillStyle = i3.Ne, o2 = i3.Ne);
      let h2 = Math.round(i3.nt * n2) - Math.floor(0.5 * this.ae);
      const c2 = h2 + this.ae - 1, u2 = Math.round(Math.min(i3.pe, i3.me) * r2), d2 = Math.round(Math.max(i3.pe, i3.me) * r2);
      if (null !== l2 && (h2 = Math.max(l2 + 1, h2), h2 = Math.min(h2, c2)), this.zt.le * n2 > 2 * a2) Lk(s2, h2, u2, c2 - h2 + 1, d2 - u2 + 1, a2);
      else {
        const t4 = c2 - h2 + 1;
        s2.fillRect(h2, u2, t4, d2 - u2 + 1);
      }
      l2 = c2;
    }
  }
  Le(t2, e2, i2) {
    if (null === this.zt) return;
    const { context: s2, horizontalPixelRatio: n2, verticalPixelRatio: r2 } = t2;
    let o2 = "";
    const a2 = this.ze(n2);
    for (let t3 = i2.from; t3 < i2.to; t3++) {
      const i3 = e2[t3];
      let l2 = Math.round(Math.min(i3.pe, i3.me) * r2), h2 = Math.round(Math.max(i3.pe, i3.me) * r2), c2 = Math.round(i3.nt * n2) - Math.floor(0.5 * this.ae), u2 = c2 + this.ae - 1;
      if (i3.ce !== o2) {
        const t4 = i3.ce;
        s2.fillStyle = t4, o2 = t4;
      }
      this.zt._i && (c2 += a2, l2 += a2, u2 -= a2, h2 -= a2), l2 > h2 || s2.fillRect(c2, l2, u2 - c2 + 1, h2 - l2 + 1);
    }
  }
}
class Zt extends jt {
  constructor() {
    super(...arguments), this.js = new Yt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.we(t2, e2, i2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W();
    this.js.J({ In: this.zs, le: this.Ns.St().le(), Be: t2.wickVisible, _i: t2.borderVisible, tt: this.Ls });
  }
}
class Xt {
  constructor(t2, e2) {
    this.Fe = t2, this.Li = e2;
  }
  X(t2, e2, i2) {
    this.Fe.draw(t2, this.Li, e2, i2);
  }
}
class Kt extends Et {
  constructor(t2, e2, i2) {
    super(t2, e2, false), this.wn = i2, this.js = new Xt(this.wn.renderer(), (e3) => {
      const i3 = t2.Ct();
      return null === i3 ? null : t2.Dt().Rt(e3, i3.Vt);
    });
  }
  We(t2) {
    return this.wn.priceValueBuilder(t2);
  }
  je(t2) {
    return this.wn.isWhitespace(t2);
  }
  Ys() {
    const t2 = this.Es.Us();
    this.zs = this.Es.In().ne().map((e2) => Object.assign(Object.assign({ ot: e2.ee, nt: NaN }, t2.$s(e2.ee)), { He: e2.$e }));
  }
  Gs(t2, e2) {
    e2.Qs(this.zs, Pk(this.Ls));
  }
  Js() {
    this.wn.update({ bars: this.zs.map(oS), barSpacing: this.Ns.St().le(), visibleRange: this.Ls }, this.Es.W());
  }
}
function oS(t2) {
  return { x: t2.nt, time: t2.ot, originalData: t2.He, barColor: t2.ce };
}
class Jt extends H {
  constructor() {
    super(...arguments), this.zt = null, this.Ue = [];
  }
  J(t2) {
    this.zt = t2, this.Ue = [];
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    if (null === this.zt || 0 === this.zt.it.length || null === this.zt.tt) return;
    this.Ue.length || this.qe(e2);
    const s2 = Math.max(1, Math.floor(i2)), n2 = Math.round(this.zt.Ye * i2) - Math.floor(s2 / 2), r2 = n2 + s2;
    for (let e3 = this.zt.tt.from; e3 < this.zt.tt.to; e3++) {
      const o2 = this.zt.it[e3], a2 = this.Ue[e3 - this.zt.tt.from], l2 = Math.round(o2.st * i2);
      let h2, c2;
      t2.fillStyle = o2.ce, l2 <= n2 ? (h2 = l2, c2 = r2) : (h2 = n2, c2 = l2 - Math.floor(s2 / 2) + s2), t2.fillRect(a2.Os, h2, a2.ui - a2.Os + 1, c2 - h2);
    }
  }
  qe(t2) {
    if (null === this.zt || 0 === this.zt.it.length || null === this.zt.tt) return void (this.Ue = []);
    const e2 = Math.ceil(this.zt.le * t2) <= 1 ? 0 : Math.max(1, Math.floor(t2)), i2 = Math.round(this.zt.le * t2) - e2;
    this.Ue = new Array(this.zt.tt.to - this.zt.tt.from);
    for (let e3 = this.zt.tt.from; e3 < this.zt.tt.to; e3++) {
      const s3 = this.zt.it[e3], n2 = Math.round(s3.nt * t2);
      let r2, o2;
      if (i2 % 2) {
        const t3 = (i2 - 1) / 2;
        r2 = n2 - t3, o2 = n2 + t3;
      } else {
        const t3 = i2 / 2;
        r2 = n2 - t3, o2 = n2 + t3 - 1;
      }
      this.Ue[e3 - this.zt.tt.from] = { Os: r2, ui: o2, Ze: n2, Xe: s3.nt * t2, ot: s3.ot };
    }
    for (let t3 = this.zt.tt.from + 1; t3 < this.zt.tt.to; t3++) {
      const i3 = this.Ue[t3 - this.zt.tt.from], s3 = this.Ue[t3 - this.zt.tt.from - 1];
      i3.ot === s3.ot + 1 && i3.Os - s3.ui !== e2 + 1 && (s3.Ze > s3.Xe ? s3.ui = i3.Os - e2 - 1 : i3.Os = s3.ui + e2 + 1);
    }
    let s2 = Math.ceil(this.zt.le * t2);
    for (let t3 = this.zt.tt.from; t3 < this.zt.tt.to; t3++) {
      const e3 = this.Ue[t3 - this.zt.tt.from];
      e3.ui < e3.Os && (e3.ui = e3.Os);
      const i3 = e3.ui - e3.Os + 1;
      s2 = Math.min(i3, s2);
    }
    if (e2 > 0 && s2 < 4) for (let t3 = this.zt.tt.from; t3 < this.zt.tt.to; t3++) {
      const e3 = this.Ue[t3 - this.zt.tt.from];
      e3.ui - e3.Os + 1 > s2 && (e3.Ze > e3.Xe ? e3.ui -= 1 : e3.Os += 1);
    }
  }
}
class Qt extends Nt {
  constructor() {
    super(...arguments), this.js = new Jt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = { it: this.zs, le: this.Ns.St().le(), tt: this.Ls, Ye: this.Es.Dt().Rt(this.Es.W().base, uk(this.Es.Ct()).Vt) };
    this.js.J(t2);
  }
}
class ti extends Nt {
  constructor() {
    super(...arguments), this.js = new Vt();
  }
  se(t2, e2, i2) {
    return Object.assign(Object.assign({}, this.ie(t2, e2)), i2.$s(t2));
  }
  Js() {
    const t2 = this.Es.W(), e2 = { it: this.zs, Nt: t2.lineStyle, fs: t2.lineVisible ? t2.lineType : void 0, et: t2.lineWidth, Ds: t2.pointMarkersVisible ? t2.pointMarkersRadius || t2.lineWidth / 2 + 2 : void 0, tt: this.Ls, ds: this.Ns.St().le() };
    this.js.J(e2);
  }
}
const aS = /[2-9]/g;
class ni {
  constructor(t2 = 50) {
    this.Ke = 0, this.Ge = 1, this.Je = 1, this.Qe = {}, this.tr = /* @__PURE__ */ new Map(), this.ir = t2;
  }
  nr() {
    this.Ke = 0, this.tr.clear(), this.Ge = 1, this.Je = 1, this.Qe = {};
  }
  xi(t2, e2, i2) {
    return this.sr(t2, e2, i2).width;
  }
  Mi(t2, e2, i2) {
    const s2 = this.sr(t2, e2, i2);
    return ((s2.actualBoundingBoxAscent || 0) - (s2.actualBoundingBoxDescent || 0)) / 2;
  }
  sr(t2, e2, i2) {
    const s2 = i2 || aS, n2 = String(e2).replace(s2, "0");
    if (this.tr.has(n2)) return ck(this.tr.get(n2)).er;
    if (this.Ke === this.ir) {
      const t3 = this.Qe[this.Je];
      delete this.Qe[this.Je], this.tr.delete(t3), this.Je++, this.Ke--;
    }
    t2.save(), t2.textBaseline = "middle";
    const r2 = t2.measureText(n2);
    return t2.restore(), 0 === r2.width && e2.length || (this.tr.set(n2, { er: r2, rr: this.Ge }), this.Qe[this.Ge] = n2, this.Ke++, this.Ge++), r2;
  }
}
class si {
  constructor(t2) {
    this.hr = null, this.k = null, this.lr = "right", this.ar = t2;
  }
  _r(t2, e2, i2) {
    this.hr = t2, this.k = e2, this.lr = i2;
  }
  X(t2) {
    null !== this.k && null !== this.hr && this.hr.X(t2, this.k, this.ar, this.lr);
  }
}
class ei {
  constructor(t2, e2, i2) {
    this.ur = t2, this.ar = new ni(50), this.cr = e2, this.F = i2, this.j = -1, this.Wt = new si(this.ar);
  }
  gt() {
    const t2 = this.F.dr(this.cr);
    if (null === t2) return null;
    const e2 = t2.vr(this.cr) ? t2.pr() : this.cr.Dt();
    if (null === e2) return null;
    const i2 = t2.mr(e2);
    if ("overlay" === i2) return null;
    const s2 = this.F.br();
    return s2.P !== this.j && (this.j = s2.P, this.ar.nr()), this.Wt._r(this.ur.Ii(), s2, i2), this.Wt;
  }
}
class ri extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  wr(t2, e2) {
    var i2;
    if (!(null === (i2 = this.zt) || void 0 === i2 ? void 0 : i2.yt)) return null;
    const { st: s2, et: n2, gr: r2 } = this.zt;
    return e2 >= s2 - n2 - 7 && e2 <= s2 + n2 + 7 ? { Mr: this.zt, gr: r2 } : null;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    if (false === this.zt.yt) return;
    const n2 = Math.round(this.zt.st * s2);
    n2 < 0 || n2 > e2.height || (t2.lineCap = "butt", t2.strokeStyle = this.zt.V, t2.lineWidth = Math.floor(this.zt.et * i2), ak(t2, this.zt.Nt), lk(t2, n2, 0, e2.width));
  }
}
class hi {
  constructor(t2) {
    this.Sr = { st: 0, V: "rgba(0, 0, 0, 0)", et: 1, Nt: 0, yt: false }, this.kr = new ri(), this.ft = true, this.Es = t2, this.Ns = t2.$t(), this.kr.J(this.Sr);
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.Es.yt() ? (this.ft && (this.yr(), this.ft = false), this.kr) : null;
  }
}
class li extends hi {
  constructor(t2) {
    super(t2);
  }
  yr() {
    this.Sr.yt = false;
    const t2 = this.Es.Dt(), e2 = t2.Cr().Cr;
    if (2 !== e2 && 3 !== e2) return;
    const i2 = this.Es.W();
    if (!i2.baseLineVisible || !this.Es.yt()) return;
    const s2 = this.Es.Ct();
    null !== s2 && (this.Sr.yt = true, this.Sr.st = t2.Rt(s2.Vt, s2.Vt), this.Sr.V = i2.baseLineColor, this.Sr.et = i2.baseLineWidth, this.Sr.Nt = i2.baseLineStyle);
  }
}
class ai extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  $e() {
    return this.zt;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }) {
    const s2 = this.zt;
    if (null === s2) return;
    const n2 = Math.max(1, Math.floor(e2)), r2 = n2 % 2 / 2, o2 = Math.round(s2.Xe.x * e2) + r2, a2 = s2.Xe.y * i2;
    t2.fillStyle = s2.Tr, t2.beginPath();
    const l2 = Math.max(2, 1.5 * s2.Pr) * e2;
    t2.arc(o2, a2, l2, 0, 2 * Math.PI, false), t2.fill(), t2.fillStyle = s2.Rr, t2.beginPath(), t2.arc(o2, a2, s2.ht * e2, 0, 2 * Math.PI, false), t2.fill(), t2.lineWidth = n2, t2.strokeStyle = s2.Dr, t2.beginPath(), t2.arc(o2, a2, s2.ht * e2 + n2 / 2, 0, 2 * Math.PI, false), t2.stroke();
  }
}
const lS = [{ Vr: 0, Or: 0.25, Br: 4, Ar: 10, Ir: 0.25, zr: 0, Lr: 0.4, Er: 0.8 }, { Vr: 0.25, Or: 0.525, Br: 10, Ar: 14, Ir: 0, zr: 0, Lr: 0.8, Er: 0 }, { Vr: 0.525, Or: 1, Br: 14, Ar: 14, Ir: 0, zr: 0, Lr: 0, Er: 0 }];
function hS(t2, e2, i2, s2) {
  return function(t3, e3) {
    if ("transparent" === t3) return t3;
    const i3 = yk(t3), s3 = i3[3];
    return `rgba(${i3[0]}, ${i3[1]}, ${i3[2]}, ${e3 * s3})`;
  }(t2, i2 + (s2 - i2) * e2);
}
function cS(t2, e2) {
  const i2 = t2 % 2600 / 2600;
  let s2;
  for (const t3 of lS) if (i2 >= t3.Vr && i2 <= t3.Or) {
    s2 = t3;
    break;
  }
  hk(void 0 !== s2, "Last price animation internal logic error");
  const n2 = (i2 - s2.Vr) / (s2.Or - s2.Vr);
  return { Rr: hS(e2, n2, s2.Ir, s2.zr), Dr: hS(e2, n2, s2.Lr, s2.Er), ht: (r2 = n2, o2 = s2.Br, a2 = s2.Ar, o2 + (a2 - o2) * r2) };
  var r2, o2, a2;
}
class ci {
  constructor(t2) {
    this.Wt = new ai(), this.ft = true, this.Nr = true, this.Fr = performance.now(), this.Wr = this.Fr - 1, this.jr = t2;
  }
  Hr() {
    this.Wr = this.Fr - 1, this.bt();
  }
  $r() {
    if (this.bt(), 2 === this.jr.W().lastPriceAnimation) {
      const t2 = performance.now(), e2 = this.Wr - t2;
      if (e2 > 0) return void (e2 < 650 && (this.Wr += 2600));
      this.Fr = t2, this.Wr = t2 + 2600;
    }
  }
  bt() {
    this.ft = true;
  }
  Ur() {
    this.Nr = true;
  }
  yt() {
    return 0 !== this.jr.W().lastPriceAnimation;
  }
  qr() {
    switch (this.jr.W().lastPriceAnimation) {
      case 0:
        return false;
      case 1:
        return true;
      case 2:
        return performance.now() <= this.Wr;
    }
  }
  gt() {
    return this.ft ? (this.Mt(), this.ft = false, this.Nr = false) : this.Nr && (this.Yr(), this.Nr = false), this.Wt;
  }
  Mt() {
    this.Wt.J(null);
    const t2 = this.jr.$t().St(), e2 = t2.Xs(), i2 = this.jr.Ct();
    if (null === e2 || null === i2) return;
    const s2 = this.jr.Zr(true);
    if (s2.Xr || !e2.Kr(s2.ee)) return;
    const n2 = { x: t2.It(s2.ee), y: this.jr.Dt().Rt(s2._t, i2.Vt) }, r2 = s2.V, o2 = this.jr.W().lineWidth, a2 = cS(this.Gr(), r2);
    this.Wt.J({ Tr: r2, Pr: o2, Rr: a2.Rr, Dr: a2.Dr, ht: a2.ht, Xe: n2 });
  }
  Yr() {
    const t2 = this.Wt.$e();
    if (null !== t2) {
      const e2 = cS(this.Gr(), t2.Tr);
      t2.Rr = e2.Rr, t2.Dr = e2.Dr, t2.ht = e2.ht;
    }
  }
  Gr() {
    return this.qr() ? performance.now() - this.Fr : 2599;
  }
}
function uS(t2, e2) {
  return Qk(Math.min(Math.max(t2, 12), 30) * e2);
}
function dS(t2, e2) {
  switch (t2) {
    case "arrowDown":
    case "arrowUp":
      return uS(e2, 1);
    case "circle":
      return uS(e2, 0.8);
    case "square":
      return uS(e2, 0.7);
  }
}
function fS(t2) {
  return function(t3) {
    const e2 = Math.ceil(t3);
    return e2 % 2 != 0 ? e2 - 1 : e2;
  }(uS(t2, 1));
}
function pS(t2) {
  return Math.max(uS(t2, 0.1), 3);
}
function mS(t2, e2, i2) {
  return e2 ? t2 : i2 ? Math.ceil(t2 / 2) : 0;
}
function gS(t2, e2, i2, s2, n2) {
  const r2 = dS("square", i2), o2 = (r2 - 1) / 2, a2 = t2 - o2, l2 = e2 - o2;
  return s2 >= a2 && s2 <= a2 + r2 && n2 >= l2 && n2 <= l2 + r2;
}
function vS(t2, e2, i2, s2) {
  const n2 = (dS("arrowUp", s2) - 1) / 2 * i2.Jr, r2 = (Qk(s2 / 2) - 1) / 2 * i2.Jr;
  e2.beginPath(), t2 ? (e2.moveTo(i2.nt - n2, i2.st), e2.lineTo(i2.nt, i2.st - n2), e2.lineTo(i2.nt + n2, i2.st), e2.lineTo(i2.nt + r2, i2.st), e2.lineTo(i2.nt + r2, i2.st + n2), e2.lineTo(i2.nt - r2, i2.st + n2), e2.lineTo(i2.nt - r2, i2.st)) : (e2.moveTo(i2.nt - n2, i2.st), e2.lineTo(i2.nt, i2.st + n2), e2.lineTo(i2.nt + n2, i2.st), e2.lineTo(i2.nt + r2, i2.st), e2.lineTo(i2.nt + r2, i2.st - n2), e2.lineTo(i2.nt - r2, i2.st - n2), e2.lineTo(i2.nt - r2, i2.st)), e2.fill();
}
class Mi extends H {
  constructor() {
    super(...arguments), this.zt = null, this.ar = new ni(), this.j = -1, this.H = "", this.Qr = "";
  }
  J(t2) {
    this.zt = t2;
  }
  _r(t2, e2) {
    this.j === t2 && this.H === e2 || (this.j = t2, this.H = e2, this.Qr = $k(t2, e2), this.ar.nr());
  }
  wr(t2, e2) {
    if (null === this.zt || null === this.zt.tt) return null;
    for (let i2 = this.zt.tt.from; i2 < this.zt.tt.to; i2++) {
      const s2 = this.zt.it[i2];
      if (_S(s2, t2, e2)) return { Mr: s2.th, gr: s2.gr };
    }
    return null;
  }
  K({ context: t2, horizontalPixelRatio: e2, verticalPixelRatio: i2 }, s2, n2) {
    if (null !== this.zt && null !== this.zt.tt) {
      t2.textBaseline = "middle", t2.font = this.Qr;
      for (let s3 = this.zt.tt.from; s3 < this.zt.tt.to; s3++) {
        const n3 = this.zt.it[s3];
        void 0 !== n3.Kt && (n3.Kt.Hi = this.ar.xi(t2, n3.Kt.ih), n3.Kt.At = this.j, n3.Kt.nt = n3.nt - n3.Kt.Hi / 2), bS(n3, t2, e2, i2);
      }
    }
  }
}
function bS(t2, e2, i2, s2) {
  e2.fillStyle = t2.V, void 0 !== t2.Kt && function(t3, e3, i3, s3, n2, r2) {
    t3.save(), t3.scale(n2, r2), t3.fillText(e3, i3, s3), t3.restore();
  }(e2, t2.Kt.ih, t2.Kt.nt, t2.Kt.st, i2, s2), function(t3, e3, i3) {
    if (0 !== t3.Ks) {
      switch (t3.nh) {
        case "arrowDown":
          return void vS(false, e3, i3, t3.Ks);
        case "arrowUp":
          return void vS(true, e3, i3, t3.Ks);
        case "circle":
          return void function(t4, e4, i4) {
            const s3 = (dS("circle", i4) - 1) / 2;
            t4.beginPath(), t4.arc(e4.nt, e4.st, s3 * e4.Jr, 0, 2 * Math.PI, false), t4.fill();
          }(e3, i3, t3.Ks);
        case "square":
          return void function(t4, e4, i4) {
            const s3 = dS("square", i4), n2 = (s3 - 1) * e4.Jr / 2, r2 = e4.nt - n2, o2 = e4.st - n2;
            t4.fillRect(r2, o2, s3 * e4.Jr, s3 * e4.Jr);
          }(e3, i3, t3.Ks);
      }
      t3.nh;
    }
  }(t2, e2, function(t3, e3, i3) {
    const s3 = Math.max(1, Math.floor(e3)) % 2 / 2;
    return { nt: Math.round(t3.nt * e3) + s3, st: t3.st * i3, Jr: e3 };
  }(t2, i2, s2));
}
function _S(t2, e2, i2) {
  return !(void 0 === t2.Kt || !function(t3, e3, i3, s2, n2, r2) {
    const o2 = s2 / 2;
    return n2 >= t3 && n2 <= t3 + i3 && r2 >= e3 - o2 && r2 <= e3 + o2;
  }(t2.Kt.nt, t2.Kt.st, t2.Kt.Hi, t2.Kt.At, e2, i2)) || function(t3, e3, i3) {
    if (0 === t3.Ks) return false;
    switch (t3.nh) {
      case "arrowDown":
      case "arrowUp":
        return function(t4, e4, i4, s2, n2, r2) {
          return gS(e4, i4, s2, n2, r2);
        }(0, t3.nt, t3.st, t3.Ks, e3, i3);
      case "circle":
        return function(t4, e4, i4, s2, n2) {
          const r2 = 2 + dS("circle", i4) / 2, o2 = t4 - s2, a2 = e4 - n2;
          return Math.sqrt(o2 * o2 + a2 * a2) <= r2;
        }(t3.nt, t3.st, t3.Ks, e3, i3);
      case "square":
        return gS(t3.nt, t3.st, t3.Ks, e3, i3);
    }
  }(t2, e2, i2);
}
function yS(t2, e2, i2, s2, n2, r2, o2, a2, l2) {
  const h2 = Sk(i2) ? i2 : i2.Se, c2 = Sk(i2) ? i2 : i2.Me, u2 = Sk(i2) ? i2 : i2.xe, d2 = Sk(e2.size) ? Math.max(e2.size, 0) : 1, f2 = fS(a2.le()) * d2, p2 = f2 / 2;
  switch (t2.Ks = f2, e2.position) {
    case "inBar":
      return t2.st = o2.Rt(h2, l2), void (void 0 !== t2.Kt && (t2.Kt.st = t2.st + p2 + r2 + 0.6 * n2));
    case "aboveBar":
      return t2.st = o2.Rt(c2, l2) - p2 - s2.sh, void 0 !== t2.Kt && (t2.Kt.st = t2.st - p2 - 0.6 * n2, s2.sh += 1.2 * n2), void (s2.sh += f2 + r2);
    case "belowBar":
      return t2.st = o2.Rt(u2, l2) + p2 + s2.eh, void 0 !== t2.Kt && (t2.Kt.st = t2.st + p2 + r2 + 0.6 * n2, s2.eh += 1.2 * n2), void (s2.eh += f2 + r2);
  }
  e2.position;
}
class yi {
  constructor(t2, e2) {
    this.ft = true, this.rh = true, this.hh = true, this.ah = null, this.oh = null, this.Wt = new Mi(), this.jr = t2, this.$i = e2, this.zt = { it: [], tt: null };
  }
  bt(t2) {
    this.ft = true, this.hh = true, "data" === t2 && (this.rh = true, this.oh = null);
  }
  gt(t2) {
    if (!this.jr.yt()) return null;
    this.ft && this._h();
    const e2 = this.$i.W().layout;
    return this.Wt._r(e2.fontSize, e2.fontFamily), this.Wt.J(this.zt), this.Wt;
  }
  uh() {
    if (this.hh) {
      if (this.jr.dh().length > 0) {
        const t2 = this.$i.St().le(), e2 = pS(t2), i2 = 1.5 * fS(t2) + 2 * e2, s2 = this.fh();
        this.ah = { above: mS(i2, s2.aboveBar, s2.inBar), below: mS(i2, s2.belowBar, s2.inBar) };
      } else this.ah = null;
      this.hh = false;
    }
    return this.ah;
  }
  fh() {
    return null === this.oh && (this.oh = this.jr.dh().reduce((t2, e2) => (t2[e2.position] || (t2[e2.position] = true), t2), { inBar: false, aboveBar: false, belowBar: false })), this.oh;
  }
  _h() {
    const t2 = this.jr.Dt(), e2 = this.$i.St(), i2 = this.jr.dh();
    this.rh && (this.zt.it = i2.map((t3) => ({ ot: t3.time, nt: 0, st: 0, Ks: 0, nh: t3.shape, V: t3.color, th: t3.th, gr: t3.id, Kt: void 0 })), this.rh = false);
    const s2 = this.$i.W().layout;
    this.zt.tt = null;
    const n2 = e2.Xs();
    if (null === n2) return;
    const r2 = this.jr.Ct();
    if (null === r2) return;
    if (0 === this.zt.it.length) return;
    let o2 = NaN;
    const a2 = pS(e2.le()), l2 = { sh: a2, eh: a2 };
    this.zt.tt = rS(this.zt.it, n2, true);
    for (let n3 = this.zt.tt.from; n3 < this.zt.tt.to; n3++) {
      const h2 = i2[n3];
      h2.time !== o2 && (l2.sh = a2, l2.eh = a2, o2 = h2.time);
      const c2 = this.zt.it[n3];
      c2.nt = e2.It(h2.time), void 0 !== h2.text && h2.text.length > 0 && (c2.Kt = { ih: h2.text, nt: 0, st: 0, Hi: 0, At: 0 });
      const u2 = this.jr.ph(h2.time);
      null !== u2 && yS(c2, h2, u2, l2, s2.fontSize, a2, t2, e2, r2.Vt);
    }
    this.ft = false;
  }
}
class Ci extends hi {
  constructor(t2) {
    super(t2);
  }
  yr() {
    const t2 = this.Sr;
    t2.yt = false;
    const e2 = this.Es.W();
    if (!e2.priceLineVisible || !this.Es.yt()) return;
    const i2 = this.Es.Zr(0 === e2.priceLineSource);
    i2.Xr || (t2.yt = true, t2.st = i2.ki, t2.V = this.Es.mh(i2.V), t2.et = e2.priceLineWidth, t2.Nt = e2.priceLineStyle);
  }
}
class Ti extends nt {
  constructor(t2) {
    super(), this.jt = t2;
  }
  zi(t2, e2, i2) {
    t2.yt = false, e2.yt = false;
    const s2 = this.jt;
    if (!s2.yt()) return;
    const n2 = s2.W(), r2 = n2.lastValueVisible, o2 = "" !== s2.bh(), a2 = 0 === n2.seriesLastValueMode, l2 = s2.Zr(false);
    if (l2.Xr) return;
    r2 && (t2.Kt = this.wh(l2, r2, a2), t2.yt = 0 !== t2.Kt.length), (o2 || a2) && (e2.Kt = this.gh(l2, r2, o2, a2), e2.yt = e2.Kt.length > 0);
    const h2 = s2.mh(l2.V), c2 = xk(h2);
    i2.t = c2.t, i2.ki = l2.ki, e2.Ot = s2.$t().Bt(l2.ki / s2.Dt().At()), t2.Ot = h2, t2.V = c2.i, e2.V = c2.i;
  }
  gh(t2, e2, i2, s2) {
    let n2 = "";
    const r2 = this.jt.bh();
    return i2 && 0 !== r2.length && (n2 += `${r2} `), e2 && s2 && (n2 += this.jt.Dt().Mh() ? t2.xh : t2.Sh), n2.trim();
  }
  wh(t2, e2, i2) {
    return e2 ? i2 ? this.jt.Dt().Mh() ? t2.Sh : t2.xh : t2.Kt : "";
  }
}
function wS(t2, e2, i2, s2) {
  const n2 = Number.isFinite(e2), r2 = Number.isFinite(i2);
  return n2 && r2 ? t2(e2, i2) : n2 || r2 ? n2 ? e2 : i2 : s2;
}
class Ri {
  constructor(t2, e2) {
    this.kh = t2, this.yh = e2;
  }
  Ch(t2) {
    return null !== t2 && this.kh === t2.kh && this.yh === t2.yh;
  }
  Th() {
    return new Ri(this.kh, this.yh);
  }
  Ph() {
    return this.kh;
  }
  Rh() {
    return this.yh;
  }
  Dh() {
    return this.yh - this.kh;
  }
  Ni() {
    return this.yh === this.kh || Number.isNaN(this.yh) || Number.isNaN(this.kh);
  }
  ts(t2) {
    return null === t2 ? this : new Ri(wS(Math.min, this.Ph(), t2.Ph(), -1 / 0), wS(Math.max, this.Rh(), t2.Rh(), 1 / 0));
  }
  Vh(t2) {
    if (!Sk(t2)) return;
    if (0 === this.yh - this.kh) return;
    const e2 = 0.5 * (this.yh + this.kh);
    let i2 = this.yh - e2, s2 = this.kh - e2;
    i2 *= t2, s2 *= t2, this.yh = e2 + i2, this.kh = e2 + s2;
  }
  Oh(t2) {
    Sk(t2) && (this.yh += t2, this.kh += t2);
  }
  Bh() {
    return { minValue: this.kh, maxValue: this.yh };
  }
  static Ah(t2) {
    return null === t2 ? null : new Ri(t2.minValue, t2.maxValue);
  }
}
class Di {
  constructor(t2, e2) {
    this.Ih = t2, this.zh = e2 || null;
  }
  Lh() {
    return this.Ih;
  }
  Eh() {
    return this.zh;
  }
  Bh() {
    return null === this.Ih ? null : { priceRange: this.Ih.Bh(), margins: this.zh || void 0 };
  }
  static Ah(t2) {
    return null === t2 ? null : new Di(Ri.Ah(t2.priceRange), t2.margins);
  }
}
class Vi extends hi {
  constructor(t2, e2) {
    super(t2), this.Nh = e2;
  }
  yr() {
    const t2 = this.Sr;
    t2.yt = false;
    const e2 = this.Nh.W();
    if (!this.Es.yt() || !e2.lineVisible) return;
    const i2 = this.Nh.Fh();
    null !== i2 && (t2.yt = true, t2.st = i2, t2.V = e2.color, t2.et = e2.lineWidth, t2.Nt = e2.lineStyle, t2.gr = this.Nh.W().id);
  }
}
class Oi extends nt {
  constructor(t2, e2) {
    super(), this.jr = t2, this.Nh = e2;
  }
  zi(t2, e2, i2) {
    t2.yt = false, e2.yt = false;
    const s2 = this.Nh.W(), n2 = s2.axisLabelVisible, r2 = "" !== s2.title, o2 = this.jr;
    if (!n2 || !o2.yt()) return;
    const a2 = this.Nh.Fh();
    if (null === a2) return;
    r2 && (e2.Kt = s2.title, e2.yt = true), e2.Ot = o2.$t().Bt(a2 / o2.Dt().At()), t2.Kt = this.Wh(s2.price), t2.yt = true;
    const l2 = xk(s2.axisLabelColor || s2.color);
    i2.t = l2.t;
    const h2 = s2.axisLabelTextColor || l2.i;
    t2.V = h2, e2.V = h2, i2.ki = a2;
  }
  Wh(t2) {
    const e2 = this.jr.Ct();
    return null === e2 ? "" : this.jr.Dt().Fi(t2, e2.Vt);
  }
}
class Bi {
  constructor(t2, e2) {
    this.jr = t2, this.cn = e2, this.jh = new Vi(t2, this), this.ur = new Oi(t2, this), this.Hh = new ei(this.ur, t2, t2.$t());
  }
  $h(t2) {
    kk(this.cn, t2), this.bt(), this.jr.$t().Uh();
  }
  W() {
    return this.cn;
  }
  qh() {
    return this.jh;
  }
  Yh() {
    return this.Hh;
  }
  Zh() {
    return this.ur;
  }
  bt() {
    this.jh.bt(), this.ur.bt();
  }
  Fh() {
    const t2 = this.jr, e2 = t2.Dt();
    if (t2.$t().St().Ni() || e2.Ni()) return null;
    const i2 = t2.Ct();
    return null === i2 ? null : e2.Rt(this.cn.price, i2.Vt);
  }
}
class Ai extends lt {
  constructor(t2) {
    super(), this.$i = t2;
  }
  $t() {
    return this.$i;
  }
}
const xS = { Bar: (t2, e2, i2, s2) => {
  var n2;
  const r2 = e2.upColor, o2 = e2.downColor, a2 = uk(t2(i2, s2)), l2 = dk(a2.Vt[0]) <= dk(a2.Vt[3]);
  return { ce: null !== (n2 = a2.V) && void 0 !== n2 ? n2 : l2 ? r2 : o2 };
}, Candlestick: (t2, e2, i2, s2) => {
  var n2, r2, o2;
  const a2 = e2.upColor, l2 = e2.downColor, h2 = e2.borderUpColor, c2 = e2.borderDownColor, u2 = e2.wickUpColor, d2 = e2.wickDownColor, f2 = uk(t2(i2, s2)), p2 = dk(f2.Vt[0]) <= dk(f2.Vt[3]);
  return { ce: null !== (n2 = f2.V) && void 0 !== n2 ? n2 : p2 ? a2 : l2, Ne: null !== (r2 = f2.Ot) && void 0 !== r2 ? r2 : p2 ? h2 : c2, Ee: null !== (o2 = f2.Xh) && void 0 !== o2 ? o2 : p2 ? u2 : d2 };
}, Custom: (t2, e2, i2, s2) => {
  var n2;
  return { ce: null !== (n2 = uk(t2(i2, s2)).V) && void 0 !== n2 ? n2 : e2.color };
}, Area: (t2, e2, i2, s2) => {
  var n2, r2, o2, a2;
  const l2 = uk(t2(i2, s2));
  return { ce: null !== (n2 = l2.lt) && void 0 !== n2 ? n2 : e2.lineColor, lt: null !== (r2 = l2.lt) && void 0 !== r2 ? r2 : e2.lineColor, Ps: null !== (o2 = l2.Ps) && void 0 !== o2 ? o2 : e2.topColor, Rs: null !== (a2 = l2.Rs) && void 0 !== a2 ? a2 : e2.bottomColor };
}, Baseline: (t2, e2, i2, s2) => {
  var n2, r2, o2, a2, l2, h2;
  const c2 = uk(t2(i2, s2));
  return { ce: c2.Vt[3] >= e2.baseValue.price ? e2.topLineColor : e2.bottomLineColor, Re: null !== (n2 = c2.Re) && void 0 !== n2 ? n2 : e2.topLineColor, De: null !== (r2 = c2.De) && void 0 !== r2 ? r2 : e2.bottomLineColor, ke: null !== (o2 = c2.ke) && void 0 !== o2 ? o2 : e2.topFillColor1, ye: null !== (a2 = c2.ye) && void 0 !== a2 ? a2 : e2.topFillColor2, Ce: null !== (l2 = c2.Ce) && void 0 !== l2 ? l2 : e2.bottomFillColor1, Te: null !== (h2 = c2.Te) && void 0 !== h2 ? h2 : e2.bottomFillColor2 };
}, Line: (t2, e2, i2, s2) => {
  var n2, r2;
  const o2 = uk(t2(i2, s2));
  return { ce: null !== (n2 = o2.V) && void 0 !== n2 ? n2 : e2.color, lt: null !== (r2 = o2.V) && void 0 !== r2 ? r2 : e2.color };
}, Histogram: (t2, e2, i2, s2) => {
  var n2;
  return { ce: null !== (n2 = uk(t2(i2, s2)).V) && void 0 !== n2 ? n2 : e2.color };
} };
class zi {
  constructor(t2) {
    this.Kh = (t3, e2) => void 0 !== e2 ? e2.Vt : this.jr.In().Gh(t3), this.jr = t2, this.Jh = xS[t2.Qh()];
  }
  $s(t2, e2) {
    return this.Jh(this.Kh, this.jr.W(), t2, e2);
  }
}
var kS;
!function(t2) {
  t2[t2.NearestLeft = -1] = "NearestLeft", t2[t2.None = 0] = "None", t2[t2.NearestRight = 1] = "NearestRight";
}(kS || (kS = {}));
const SS = 30;
class Ni {
  constructor() {
    this.tl = [], this.il = /* @__PURE__ */ new Map(), this.nl = /* @__PURE__ */ new Map();
  }
  sl() {
    return this.Ks() > 0 ? this.tl[this.tl.length - 1] : null;
  }
  el() {
    return this.Ks() > 0 ? this.rl(0) : null;
  }
  An() {
    return this.Ks() > 0 ? this.rl(this.tl.length - 1) : null;
  }
  Ks() {
    return this.tl.length;
  }
  Ni() {
    return 0 === this.Ks();
  }
  Kr(t2) {
    return null !== this.hl(t2, 0);
  }
  Gh(t2) {
    return this.ll(t2);
  }
  ll(t2, e2 = 0) {
    const i2 = this.hl(t2, e2);
    return null === i2 ? null : Object.assign(Object.assign({}, this.al(i2)), { ee: this.rl(i2) });
  }
  ne() {
    return this.tl;
  }
  ol(t2, e2, i2) {
    if (this.Ni()) return null;
    let s2 = null;
    for (const n2 of i2) s2 = MS(s2, this._l(t2, e2, n2));
    return s2;
  }
  J(t2) {
    this.nl.clear(), this.il.clear(), this.tl = t2;
  }
  rl(t2) {
    return this.tl[t2].ee;
  }
  al(t2) {
    return this.tl[t2];
  }
  hl(t2, e2) {
    const i2 = this.ul(t2);
    if (null === i2 && 0 !== e2) switch (e2) {
      case -1:
        return this.cl(t2);
      case 1:
        return this.dl(t2);
      default:
        throw new TypeError("Unknown search mode");
    }
    return i2;
  }
  cl(t2) {
    let e2 = this.fl(t2);
    return e2 > 0 && (e2 -= 1), e2 !== this.tl.length && this.rl(e2) < t2 ? e2 : null;
  }
  dl(t2) {
    const e2 = this.vl(t2);
    return e2 !== this.tl.length && t2 < this.rl(e2) ? e2 : null;
  }
  ul(t2) {
    const e2 = this.fl(t2);
    return e2 === this.tl.length || t2 < this.tl[e2].ee ? null : e2;
  }
  fl(t2) {
    return eS(this.tl, t2, (t3, e2) => t3.ee < e2);
  }
  vl(t2) {
    return iS(this.tl, t2, (t3, e2) => t3.ee > e2);
  }
  pl(t2, e2, i2) {
    let s2 = null;
    for (let n2 = t2; n2 < e2; n2++) {
      const t3 = this.tl[n2].Vt[i2];
      Number.isNaN(t3) || (null === s2 ? s2 = { ml: t3, bl: t3 } : (t3 < s2.ml && (s2.ml = t3), t3 > s2.bl && (s2.bl = t3)));
    }
    return s2;
  }
  _l(t2, e2, i2) {
    if (this.Ni()) return null;
    let s2 = null;
    const n2 = uk(this.el()), r2 = uk(this.An()), o2 = Math.max(t2, n2), a2 = Math.min(e2, r2), l2 = Math.ceil(o2 / SS) * SS, h2 = Math.max(l2, Math.floor(a2 / SS) * SS);
    {
      const t3 = this.fl(o2), n3 = this.vl(Math.min(a2, l2, e2));
      s2 = MS(s2, this.pl(t3, n3, i2));
    }
    let c2 = this.il.get(i2);
    void 0 === c2 && (c2 = /* @__PURE__ */ new Map(), this.il.set(i2, c2));
    for (let t3 = Math.max(l2 + 1, o2); t3 < h2; t3 += SS) {
      const e3 = Math.floor(t3 / SS);
      let n3 = c2.get(e3);
      if (void 0 === n3) {
        const t4 = this.fl(e3 * SS), s3 = this.vl((e3 + 1) * SS - 1);
        n3 = this.pl(t4, s3, i2), c2.set(e3, n3);
      }
      s2 = MS(s2, n3);
    }
    {
      const t3 = this.fl(h2), e3 = this.vl(a2);
      s2 = MS(s2, this.pl(t3, e3, i2));
    }
    return s2;
  }
}
function MS(t2, e2) {
  return null === t2 ? e2 : null === e2 ? t2 : { ml: Math.min(t2.ml, e2.ml), bl: Math.max(t2.bl, e2.bl) };
}
class Wi {
  constructor(t2) {
    this.wl = t2;
  }
  X(t2, e2, i2) {
    this.wl.draw(t2);
  }
  gl(t2, e2, i2) {
    var s2, n2;
    null === (n2 = (s2 = this.wl).drawBackground) || void 0 === n2 || n2.call(s2, t2);
  }
}
class ji {
  constructor(t2) {
    this.tr = null, this.wn = t2;
  }
  gt() {
    var t2;
    const e2 = this.wn.renderer();
    if (null === e2) return null;
    if ((null === (t2 = this.tr) || void 0 === t2 ? void 0 : t2.Ml) === e2) return this.tr.xl;
    const i2 = new Wi(e2);
    return this.tr = { Ml: e2, xl: i2 }, i2;
  }
  Sl() {
    var t2, e2, i2;
    return null !== (i2 = null === (e2 = (t2 = this.wn).zOrder) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : "normal";
  }
}
function zS(t2) {
  var e2, i2, s2, n2, r2;
  return { Kt: t2.text(), ki: t2.coordinate(), Si: null === (e2 = t2.fixedCoordinate) || void 0 === e2 ? void 0 : e2.call(t2), V: t2.textColor(), t: t2.backColor(), yt: null === (s2 = null === (i2 = t2.visible) || void 0 === i2 ? void 0 : i2.call(t2)) || void 0 === s2 || s2, hi: null === (r2 = null === (n2 = t2.tickVisible) || void 0 === n2 ? void 0 : n2.call(t2)) || void 0 === r2 || r2 };
}
class $i {
  constructor(t2, e2) {
    this.Wt = new rt(), this.kl = t2, this.yl = e2;
  }
  gt() {
    return this.Wt.J(Object.assign({ Hi: this.yl.Hi() }, zS(this.kl))), this.Wt;
  }
}
class Ui extends nt {
  constructor(t2, e2) {
    super(), this.kl = t2, this.Li = e2;
  }
  zi(t2, e2, i2) {
    const s2 = zS(this.kl);
    i2.t = s2.t, t2.V = s2.V;
    const n2 = 2 / 12 * this.Li.P();
    i2.wi = n2, i2.gi = n2, i2.ki = s2.ki, i2.Si = s2.Si, t2.Kt = s2.Kt, t2.yt = s2.yt, t2.hi = s2.hi;
  }
}
class qi {
  constructor(t2, e2) {
    this.Cl = null, this.Tl = null, this.Pl = null, this.Rl = null, this.Dl = null, this.Vl = t2, this.jr = e2;
  }
  Ol() {
    return this.Vl;
  }
  Vn() {
    var t2, e2;
    null === (e2 = (t2 = this.Vl).updateAllViews) || void 0 === e2 || e2.call(t2);
  }
  Pn() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).paneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Cl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Cl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Cl = { Ml: n2, xl: r2 }, r2;
  }
  Qi() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).timeAxisViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Tl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Tl.xl;
    const r2 = this.jr.$t().St(), o2 = n2.map((t3) => new $i(t3, r2));
    return this.Tl = { Ml: n2, xl: o2 }, o2;
  }
  Rn() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).priceAxisViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Pl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Pl.xl;
    const r2 = this.jr.Dt(), o2 = n2.map((t3) => new Ui(t3, r2));
    return this.Pl = { Ml: n2, xl: o2 }, o2;
  }
  Bl() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).priceAxisPaneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Rl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Rl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Rl = { Ml: n2, xl: r2 }, r2;
  }
  Al() {
    var t2, e2, i2, s2;
    const n2 = null !== (i2 = null === (e2 = (t2 = this.Vl).timeAxisPaneViews) || void 0 === e2 ? void 0 : e2.call(t2)) && void 0 !== i2 ? i2 : [];
    if ((null === (s2 = this.Dl) || void 0 === s2 ? void 0 : s2.Ml) === n2) return this.Dl.xl;
    const r2 = n2.map((t3) => new ji(t3));
    return this.Dl = { Ml: n2, xl: r2 }, r2;
  }
  Il(t2, e2) {
    var i2, s2, n2;
    return null !== (n2 = null === (s2 = (i2 = this.Vl).autoscaleInfo) || void 0 === s2 ? void 0 : s2.call(i2, t2, e2)) && void 0 !== n2 ? n2 : null;
  }
  wr(t2, e2) {
    var i2, s2, n2;
    return null !== (n2 = null === (s2 = (i2 = this.Vl).hitTest) || void 0 === s2 ? void 0 : s2.call(i2, t2, e2)) && void 0 !== n2 ? n2 : null;
  }
}
function CS(t2, e2, i2, s2) {
  t2.forEach((t3) => {
    e2(t3).forEach((t4) => {
      t4.Sl() === i2 && s2.push(t4);
    });
  });
}
function DS(t2) {
  return t2.Pn();
}
function RS(t2) {
  return t2.Bl();
}
function PS(t2) {
  return t2.Al();
}
class Gi extends Ai {
  constructor(t2, e2, i2, s2, n2) {
    super(t2), this.zt = new Ni(), this.jh = new Ci(this), this.zl = [], this.Ll = new li(this), this.El = null, this.Nl = null, this.Fl = [], this.Wl = [], this.jl = null, this.Hl = [], this.cn = e2, this.$l = i2;
    const r2 = new Ti(this);
    this.rn = [r2], this.Hh = new ei(r2, this, t2), "Area" !== i2 && "Line" !== i2 && "Baseline" !== i2 || (this.El = new ci(this)), this.Ul(), this.ql(n2);
  }
  S() {
    null !== this.jl && clearTimeout(this.jl);
  }
  mh(t2) {
    return this.cn.priceLineColor || t2;
  }
  Zr(t2) {
    const e2 = { Xr: true }, i2 = this.Dt();
    if (this.$t().St().Ni() || i2.Ni() || this.zt.Ni()) return e2;
    const s2 = this.$t().St().Xs(), n2 = this.Ct();
    if (null === s2 || null === n2) return e2;
    let r2, o2;
    if (t2) {
      const t3 = this.zt.sl();
      if (null === t3) return e2;
      r2 = t3, o2 = t3.ee;
    } else {
      const t3 = this.zt.ll(s2.ui(), -1);
      if (null === t3) return e2;
      if (r2 = this.zt.Gh(t3.ee), null === r2) return e2;
      o2 = t3.ee;
    }
    const a2 = r2.Vt[3], l2 = this.Us().$s(o2, { Vt: r2 }), h2 = i2.Rt(a2, n2.Vt);
    return { Xr: false, _t: a2, Kt: i2.Fi(a2, n2.Vt), xh: i2.Yl(a2), Sh: i2.Zl(a2, n2.Vt), V: l2.ce, ki: h2, ee: o2 };
  }
  Us() {
    return null !== this.Nl || (this.Nl = new zi(this)), this.Nl;
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    const e2 = t2.priceScaleId;
    void 0 !== e2 && e2 !== this.cn.priceScaleId && this.$t().Xl(this, e2), kk(this.cn, t2), void 0 !== t2.priceFormat && (this.Ul(), this.$t().Kl()), this.$t().Gl(this), this.$t().Jl(), this.wn.bt("options");
  }
  J(t2, e2) {
    this.zt.J(t2), this.Ql(), this.wn.bt("data"), this.dn.bt("data"), null !== this.El && (e2 && e2.ta ? this.El.$r() : 0 === t2.length && this.El.Hr());
    const i2 = this.$t().dr(this);
    this.$t().ia(i2), this.$t().Gl(this), this.$t().Jl(), this.$t().Uh();
  }
  na(t2) {
    this.Fl = t2, this.Ql();
    const e2 = this.$t().dr(this);
    this.dn.bt("data"), this.$t().ia(e2), this.$t().Gl(this), this.$t().Jl(), this.$t().Uh();
  }
  sa() {
    return this.Fl;
  }
  dh() {
    return this.Wl;
  }
  ea(t2) {
    const e2 = new Bi(this, t2);
    return this.zl.push(e2), this.$t().Gl(this), e2;
  }
  ra(t2) {
    const e2 = this.zl.indexOf(t2);
    -1 !== e2 && this.zl.splice(e2, 1), this.$t().Gl(this);
  }
  Qh() {
    return this.$l;
  }
  Ct() {
    const t2 = this.ha();
    return null === t2 ? null : { Vt: t2.Vt[3], la: t2.ot };
  }
  ha() {
    const t2 = this.$t().St().Xs();
    if (null === t2) return null;
    const e2 = t2.Os();
    return this.zt.ll(e2, 1);
  }
  In() {
    return this.zt;
  }
  ph(t2) {
    const e2 = this.zt.Gh(t2);
    return null === e2 ? null : "Bar" === this.$l || "Candlestick" === this.$l || "Custom" === this.$l ? { ge: e2.Vt[0], Me: e2.Vt[1], xe: e2.Vt[2], Se: e2.Vt[3] } : e2.Vt[3];
  }
  aa(t2) {
    const e2 = [];
    CS(this.Hl, DS, "top", e2);
    const i2 = this.El;
    return null !== i2 && i2.yt() ? (null === this.jl && i2.qr() && (this.jl = setTimeout(() => {
      this.jl = null, this.$t().oa();
    }, 0)), i2.Ur(), e2.unshift(i2), e2) : e2;
  }
  Pn() {
    const t2 = [];
    this._a() || t2.push(this.Ll), t2.push(this.wn, this.jh, this.dn);
    const e2 = this.zl.map((t3) => t3.qh());
    return t2.push(...e2), CS(this.Hl, DS, "normal", t2), t2;
  }
  ua() {
    return this.ca(DS, "bottom");
  }
  da(t2) {
    return this.ca(RS, t2);
  }
  fa(t2) {
    return this.ca(PS, t2);
  }
  va(t2, e2) {
    return this.Hl.map((i2) => i2.wr(t2, e2)).filter((t3) => null !== t3);
  }
  Ji(t2) {
    return [this.Hh, ...this.zl.map((t3) => t3.Yh())];
  }
  Rn(t2, e2) {
    if (e2 !== this.Yi && !this._a()) return [];
    const i2 = [...this.rn];
    for (const t3 of this.zl) i2.push(t3.Zh());
    return this.Hl.forEach((t3) => {
      i2.push(...t3.Rn());
    }), i2;
  }
  Qi() {
    const t2 = [];
    return this.Hl.forEach((e2) => {
      t2.push(...e2.Qi());
    }), t2;
  }
  Il(t2, e2) {
    if (void 0 !== this.cn.autoscaleInfoProvider) {
      const i2 = this.cn.autoscaleInfoProvider(() => {
        const i3 = this.pa(t2, e2);
        return null === i3 ? null : i3.Bh();
      });
      return Di.Ah(i2);
    }
    return this.pa(t2, e2);
  }
  ma() {
    return this.cn.priceFormat.minMove;
  }
  ba() {
    return this.wa;
  }
  Vn() {
    var t2;
    this.wn.bt(), this.dn.bt();
    for (const t3 of this.rn) t3.bt();
    for (const t3 of this.zl) t3.bt();
    this.jh.bt(), this.Ll.bt(), null === (t2 = this.El) || void 0 === t2 || t2.bt(), this.Hl.forEach((t3) => t3.Vn());
  }
  Dt() {
    return uk(super.Dt());
  }
  kt(t2) {
    if ("Line" !== this.$l && "Area" !== this.$l && "Baseline" !== this.$l || !this.cn.crosshairMarkerVisible) return null;
    const e2 = this.zt.Gh(t2);
    return null === e2 ? null : { _t: e2.Vt[3], ht: this.ga(), Ot: this.Ma(), Pt: this.xa(), Tt: this.Sa(t2) };
  }
  bh() {
    return this.cn.title;
  }
  yt() {
    return this.cn.visible;
  }
  ka(t2) {
    this.Hl.push(new qi(t2, this));
  }
  ya(t2) {
    this.Hl = this.Hl.filter((e2) => e2.Ol() !== t2);
  }
  Ca() {
    if (this.wn instanceof Kt != 0) return (t2) => this.wn.We(t2);
  }
  Ta() {
    if (this.wn instanceof Kt != 0) return (t2) => this.wn.je(t2);
  }
  _a() {
    return !Bk(this.Dt().Pa());
  }
  pa(t2, e2) {
    if (!Mk(t2) || !Mk(e2) || this.zt.Ni()) return null;
    const i2 = "Line" === this.$l || "Area" === this.$l || "Baseline" === this.$l || "Histogram" === this.$l ? [3] : [2, 1], s2 = this.zt.ol(t2, e2, i2);
    let n2 = null !== s2 ? new Ri(s2.ml, s2.bl) : null;
    if ("Histogram" === this.Qh()) {
      const t3 = this.cn.base, e3 = new Ri(t3, t3);
      n2 = null !== n2 ? n2.ts(e3) : e3;
    }
    let r2 = this.dn.uh();
    return this.Hl.forEach((i3) => {
      const s3 = i3.Il(t2, e2);
      if (null == s3 ? void 0 : s3.priceRange) {
        const t3 = new Ri(s3.priceRange.minValue, s3.priceRange.maxValue);
        n2 = null !== n2 ? n2.ts(t3) : t3;
      }
      var o2, a2, l2, h2;
      (null == s3 ? void 0 : s3.margins) && (o2 = r2, a2 = s3.margins, r2 = { above: Math.max(null !== (l2 = null == o2 ? void 0 : o2.above) && void 0 !== l2 ? l2 : 0, a2.above), below: Math.max(null !== (h2 = null == o2 ? void 0 : o2.below) && void 0 !== h2 ? h2 : 0, a2.below) });
    }), new Di(n2, r2);
  }
  ga() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline":
        return this.cn.crosshairMarkerRadius;
    }
    return 0;
  }
  Ma() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline": {
        const t2 = this.cn.crosshairMarkerBorderColor;
        if (0 !== t2.length) return t2;
      }
    }
    return null;
  }
  xa() {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline":
        return this.cn.crosshairMarkerBorderWidth;
    }
    return 0;
  }
  Sa(t2) {
    switch (this.$l) {
      case "Line":
      case "Area":
      case "Baseline": {
        const t3 = this.cn.crosshairMarkerBackgroundColor;
        if (0 !== t3.length) return t3;
      }
    }
    return this.Us().$s(t2).ce;
  }
  Ul() {
    switch (this.cn.priceFormat.type) {
      case "custom":
        this.wa = { format: this.cn.priceFormat.formatter };
        break;
      case "volume":
        this.wa = new pt(this.cn.priceFormat.precision);
        break;
      case "percent":
        this.wa = new vt(this.cn.priceFormat.precision);
        break;
      default: {
        const t2 = Math.pow(10, this.cn.priceFormat.precision);
        this.wa = new ft(t2, this.cn.priceFormat.minMove * t2);
      }
    }
    null !== this.Yi && this.Yi.Ra();
  }
  Ql() {
    const t2 = this.$t().St();
    if (!t2.Da() || this.zt.Ni()) return void (this.Wl = []);
    const e2 = uk(this.zt.el());
    this.Wl = this.Fl.map((i2, s2) => {
      const n2 = uk(t2.Va(i2.time, true)), r2 = n2 < e2 ? 1 : -1;
      return { time: uk(this.zt.ll(n2, r2)).ee, position: i2.position, shape: i2.shape, color: i2.color, id: i2.id, th: s2, text: i2.text, size: i2.size, originalTime: i2.originalTime };
    });
  }
  ql(t2) {
    switch (this.dn = new yi(this, this.$t()), this.$l) {
      case "Bar":
        this.wn = new Ht(this, this.$t());
        break;
      case "Candlestick":
        this.wn = new Zt(this, this.$t());
        break;
      case "Line":
        this.wn = new ti(this, this.$t());
        break;
      case "Custom":
        this.wn = new Kt(this, this.$t(), ck(t2));
        break;
      case "Area":
        this.wn = new Ft(this, this.$t());
        break;
      case "Baseline":
        this.wn = new qt(this, this.$t());
        break;
      case "Histogram":
        this.wn = new Qt(this, this.$t());
        break;
      default:
        throw Error("Unknown chart style assigned: " + this.$l);
    }
  }
  ca(t2, e2) {
    const i2 = [];
    return CS(this.Hl, t2, e2, i2), i2;
  }
}
class Ji {
  constructor(t2) {
    this.cn = t2;
  }
  Oa(t2, e2, i2) {
    let s2 = t2;
    if (0 === this.cn.mode) return s2;
    const n2 = i2.vn(), r2 = n2.Ct();
    if (null === r2) return s2;
    const o2 = n2.Rt(t2, r2), a2 = i2.Ba().filter((t3) => t3 instanceof Gi).reduce((t3, s3) => {
      if (i2.vr(s3) || !s3.yt()) return t3;
      const n3 = s3.Dt(), r3 = s3.In();
      if (n3.Ni() || !r3.Kr(e2)) return t3;
      const o3 = r3.Gh(e2);
      if (null === o3) return t3;
      const a3 = dk(s3.Ct());
      return t3.concat([n3.Rt(o3.Vt[3], a3.Vt)]);
    }, []);
    if (0 === a2.length) return s2;
    a2.sort((t3, e3) => Math.abs(t3 - o2) - Math.abs(e3 - o2));
    const l2 = a2[0];
    return s2 = n2.pn(l2, r2), s2;
  }
}
class Qi extends H {
  constructor() {
    super(...arguments), this.zt = null;
  }
  J(t2) {
    this.zt = t2;
  }
  K({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (null === this.zt) return;
    const n2 = Math.max(1, Math.floor(i2));
    t2.lineWidth = n2, function(t3, e3) {
      t3.save(), t3.lineWidth % 2 && t3.translate(0.5, 0.5), e3(), t3.restore();
    }(t2, () => {
      const r2 = uk(this.zt);
      if (r2.Aa) {
        t2.strokeStyle = r2.Ia, ak(t2, r2.za), t2.beginPath();
        for (const s3 of r2.La) {
          const r3 = Math.round(s3.Ea * i2);
          t2.moveTo(r3, -n2), t2.lineTo(r3, e2.height + n2);
        }
        t2.stroke();
      }
      if (r2.Na) {
        t2.strokeStyle = r2.Fa, ak(t2, r2.Wa), t2.beginPath();
        for (const i3 of r2.ja) {
          const r3 = Math.round(i3.Ea * s2);
          t2.moveTo(-n2, r3), t2.lineTo(e2.width + n2, r3);
        }
        t2.stroke();
      }
    });
  }
}
class tn {
  constructor(t2) {
    this.Wt = new Qi(), this.ft = true, this.tn = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    if (this.ft) {
      const t2 = this.tn.$t().W().grid, e2 = { Na: t2.horzLines.visible, Aa: t2.vertLines.visible, Fa: t2.horzLines.color, Ia: t2.vertLines.color, Wa: t2.horzLines.style, za: t2.vertLines.style, ja: this.tn.vn().Ha(), La: (this.tn.$t().St().Ha() || []).map((t3) => ({ Ea: t3.coord })) };
      this.Wt.J(e2), this.ft = false;
    }
    return this.Wt;
  }
}
class nn {
  constructor(t2) {
    this.wn = new tn(t2);
  }
  qh() {
    return this.wn;
  }
}
const TS = { $a: 4, Ua: 1e-4 };
function $S(t2, e2) {
  const i2 = 100 * (t2 - e2) / e2;
  return e2 < 0 ? -i2 : i2;
}
function ES(t2, e2) {
  const i2 = $S(t2.Ph(), e2), s2 = $S(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function AS(t2, e2) {
  const i2 = 100 * (t2 - e2) / e2 + 100;
  return e2 < 0 ? -i2 : i2;
}
function LS(t2, e2) {
  const i2 = AS(t2.Ph(), e2), s2 = AS(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function VS(t2, e2) {
  const i2 = Math.abs(t2);
  if (i2 < 1e-15) return 0;
  const s2 = Math.log10(i2 + e2.Ua) + e2.$a;
  return t2 < 0 ? -s2 : s2;
}
function OS(t2, e2) {
  const i2 = Math.abs(t2);
  if (i2 < 1e-15) return 0;
  const s2 = Math.pow(10, i2 - e2.$a) - e2.Ua;
  return t2 < 0 ? -s2 : s2;
}
function IS(t2, e2) {
  if (null === t2) return null;
  const i2 = VS(t2.Ph(), e2), s2 = VS(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function NS(t2, e2) {
  if (null === t2) return null;
  const i2 = OS(t2.Ph(), e2), s2 = OS(t2.Rh(), e2);
  return new Ri(i2, s2);
}
function FS(t2) {
  if (null === t2) return TS;
  const e2 = Math.abs(t2.Rh() - t2.Ph());
  if (e2 >= 1 || e2 < 1e-15) return TS;
  const i2 = Math.ceil(Math.abs(Math.log10(e2))), s2 = TS.$a + i2;
  return { $a: s2, Ua: 1 / Math.pow(10, s2) };
}
class dn {
  constructor(t2, e2) {
    if (this.qa = t2, this.Ya = e2, function(t3) {
      if (t3 < 0) return false;
      for (let e3 = t3; e3 > 1; e3 /= 10) if (e3 % 10 != 0) return false;
      return true;
    }(this.qa)) this.Za = [2, 2.5, 2];
    else {
      this.Za = [];
      for (let t3 = this.qa; 1 !== t3; ) {
        if (t3 % 2 == 0) this.Za.push(2), t3 /= 2;
        else {
          if (t3 % 5 != 0) throw new Error("unexpected base");
          this.Za.push(2, 2.5), t3 /= 5;
        }
        if (this.Za.length > 100) throw new Error("something wrong with base");
      }
    }
  }
  Xa(t2, e2, i2) {
    const s2 = 0 === this.qa ? 0 : 1 / this.qa;
    let n2 = Math.pow(10, Math.max(0, Math.ceil(Math.log10(t2 - e2)))), r2 = 0, o2 = this.Ya[0];
    for (; ; ) {
      const t3 = Jk(n2, s2, 1e-14) && n2 > s2 + 1e-14, e3 = Jk(n2, i2 * o2, 1e-14), a3 = Jk(n2, 1, 1e-14);
      if (!(t3 && e3 && a3)) break;
      n2 /= o2, o2 = this.Ya[++r2 % this.Ya.length];
    }
    if (n2 <= s2 + 1e-14 && (n2 = s2), n2 = Math.max(1, n2), this.Za.length > 0 && (a2 = n2, Math.abs(a2 - 1) < 1e-14)) for (r2 = 0, o2 = this.Za[0]; Jk(n2, i2 * o2, 1e-14) && n2 > s2 + 1e-14; ) n2 /= o2, o2 = this.Za[++r2 % this.Za.length];
    var a2;
    return n2;
  }
}
class fn {
  constructor(t2, e2, i2, s2) {
    this.Ka = [], this.Li = t2, this.qa = e2, this.Ga = i2, this.Ja = s2;
  }
  Xa(t2, e2) {
    if (t2 < e2) throw new Error("high < low");
    const i2 = this.Li.At(), s2 = (t2 - e2) * this.Qa() / i2, n2 = new dn(this.qa, [2, 2.5, 2]), r2 = new dn(this.qa, [2, 2, 2.5]), o2 = new dn(this.qa, [2.5, 2, 2]), a2 = [];
    return a2.push(n2.Xa(t2, e2, s2), r2.Xa(t2, e2, s2), o2.Xa(t2, e2, s2)), function(t3) {
      if (t3.length < 1) throw Error("array is empty");
      let e3 = t3[0];
      for (let i3 = 1; i3 < t3.length; ++i3) t3[i3] < e3 && (e3 = t3[i3]);
      return e3;
    }(a2);
  }
  io() {
    const t2 = this.Li, e2 = t2.Ct();
    if (null === e2) return void (this.Ka = []);
    const i2 = t2.At(), s2 = this.Ga(i2 - 1, e2), n2 = this.Ga(0, e2), r2 = this.Li.W().entireTextOnly ? this.no() / 2 : 0, o2 = r2, a2 = i2 - 1 - r2, l2 = Math.max(s2, n2), h2 = Math.min(s2, n2);
    if (l2 === h2) return void (this.Ka = []);
    let c2 = this.Xa(l2, h2), u2 = l2 % c2;
    u2 += u2 < 0 ? c2 : 0;
    const d2 = l2 >= h2 ? 1 : -1;
    let f2 = null, p2 = 0;
    for (let i3 = l2 - u2; i3 > h2; i3 -= c2) {
      const s3 = this.Ja(i3, e2, true);
      null !== f2 && Math.abs(s3 - f2) < this.Qa() || s3 < o2 || s3 > a2 || (p2 < this.Ka.length ? (this.Ka[p2].Ea = s3, this.Ka[p2].so = t2.eo(i3)) : this.Ka.push({ Ea: s3, so: t2.eo(i3) }), p2++, f2 = s3, t2.ro() && (c2 = this.Xa(i3 * d2, h2)));
    }
    this.Ka.length = p2;
  }
  Ha() {
    return this.Ka;
  }
  no() {
    return this.Li.P();
  }
  Qa() {
    return Math.ceil(2.5 * this.no());
  }
}
function WS(t2) {
  return t2.slice().sort((t3, e2) => uk(t3.Xi()) - uk(e2.Xi()));
}
var BS;
!function(t2) {
  t2[t2.Normal = 0] = "Normal", t2[t2.Logarithmic = 1] = "Logarithmic", t2[t2.Percentage = 2] = "Percentage", t2[t2.IndexedTo100 = 3] = "IndexedTo100";
}(BS || (BS = {}));
const jS = new vt(), qS = new ft(100, 1);
class wn {
  constructor(t2, e2, i2, s2) {
    this.ho = 0, this.lo = null, this.Ih = null, this.ao = null, this.oo = { _o: false, uo: null }, this.co = 0, this.do = 0, this.fo = new D(), this.vo = new D(), this.po = [], this.mo = null, this.bo = null, this.wo = null, this.Mo = null, this.wa = qS, this.xo = FS(null), this.So = t2, this.cn = e2, this.ko = i2, this.yo = s2, this.Co = new fn(this, 100, this.To.bind(this), this.Po.bind(this));
  }
  Pa() {
    return this.So;
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    if (kk(this.cn, t2), this.Ra(), void 0 !== t2.mode && this.Ro({ Cr: t2.mode }), void 0 !== t2.scaleMargins) {
      const e2 = ck(t2.scaleMargins.top), i2 = ck(t2.scaleMargins.bottom);
      if (e2 < 0 || e2 > 1) throw new Error(`Invalid top margin - expect value between 0 and 1, given=${e2}`);
      if (i2 < 0 || i2 > 1) throw new Error(`Invalid bottom margin - expect value between 0 and 1, given=${i2}`);
      if (e2 + i2 > 1) throw new Error(`Invalid margins - sum of margins must be less than 1, given=${e2 + i2}`);
      this.Do(), this.bo = null;
    }
  }
  Vo() {
    return this.cn.autoScale;
  }
  ro() {
    return 1 === this.cn.mode;
  }
  Mh() {
    return 2 === this.cn.mode;
  }
  Oo() {
    return 3 === this.cn.mode;
  }
  Cr() {
    return { Wn: this.cn.autoScale, Bo: this.cn.invertScale, Cr: this.cn.mode };
  }
  Ro(t2) {
    const e2 = this.Cr();
    let i2 = null;
    void 0 !== t2.Wn && (this.cn.autoScale = t2.Wn), void 0 !== t2.Cr && (this.cn.mode = t2.Cr, 2 !== t2.Cr && 3 !== t2.Cr || (this.cn.autoScale = true), this.oo._o = false), 1 === e2.Cr && t2.Cr !== e2.Cr && (function(t3, e3) {
      if (null === t3) return false;
      const i3 = OS(t3.Ph(), e3), s3 = OS(t3.Rh(), e3);
      return isFinite(i3) && isFinite(s3);
    }(this.Ih, this.xo) ? (i2 = NS(this.Ih, this.xo), null !== i2 && this.Ao(i2)) : this.cn.autoScale = true), 1 === t2.Cr && t2.Cr !== e2.Cr && (i2 = IS(this.Ih, this.xo), null !== i2 && this.Ao(i2));
    const s2 = e2.Cr !== this.cn.mode;
    s2 && (2 === e2.Cr || this.Mh()) && this.Ra(), s2 && (3 === e2.Cr || this.Oo()) && this.Ra(), void 0 !== t2.Bo && e2.Bo !== t2.Bo && (this.cn.invertScale = t2.Bo, this.Io()), this.vo.m(e2, this.Cr());
  }
  zo() {
    return this.vo;
  }
  P() {
    return this.ko.fontSize;
  }
  At() {
    return this.ho;
  }
  Lo(t2) {
    this.ho !== t2 && (this.ho = t2, this.Do(), this.bo = null);
  }
  Eo() {
    if (this.lo) return this.lo;
    const t2 = this.At() - this.No() - this.Fo();
    return this.lo = t2, t2;
  }
  Lh() {
    return this.Wo(), this.Ih;
  }
  Ao(t2, e2) {
    const i2 = this.Ih;
    (e2 || null === i2 && null !== t2 || null !== i2 && !i2.Ch(t2)) && (this.bo = null, this.Ih = t2);
  }
  Ni() {
    return this.Wo(), 0 === this.ho || !this.Ih || this.Ih.Ni();
  }
  jo(t2) {
    return this.Bo() ? t2 : this.At() - 1 - t2;
  }
  Rt(t2, e2) {
    return this.Mh() ? t2 = $S(t2, e2) : this.Oo() && (t2 = AS(t2, e2)), this.Po(t2, e2);
  }
  te(t2, e2, i2) {
    this.Wo();
    const s2 = this.Fo(), n2 = uk(this.Lh()), r2 = n2.Ph(), o2 = n2.Rh(), a2 = this.Eo() - 1, l2 = this.Bo(), h2 = a2 / (o2 - r2), c2 = void 0 === i2 ? 0 : i2.from, u2 = void 0 === i2 ? t2.length : i2.to, d2 = this.Ho();
    for (let i3 = c2; i3 < u2; i3++) {
      const n3 = t2[i3], o3 = n3._t;
      if (isNaN(o3)) continue;
      let a3 = o3;
      null !== d2 && (a3 = d2(n3._t, e2));
      const c3 = s2 + h2 * (a3 - r2), u3 = l2 ? c3 : this.ho - 1 - c3;
      n3.st = u3;
    }
  }
  be(t2, e2, i2) {
    this.Wo();
    const s2 = this.Fo(), n2 = uk(this.Lh()), r2 = n2.Ph(), o2 = n2.Rh(), a2 = this.Eo() - 1, l2 = this.Bo(), h2 = a2 / (o2 - r2), c2 = void 0 === i2 ? 0 : i2.from, u2 = void 0 === i2 ? t2.length : i2.to, d2 = this.Ho();
    for (let i3 = c2; i3 < u2; i3++) {
      const n3 = t2[i3];
      let o3 = n3.ge, a3 = n3.Me, c3 = n3.xe, u3 = n3.Se;
      null !== d2 && (o3 = d2(n3.ge, e2), a3 = d2(n3.Me, e2), c3 = d2(n3.xe, e2), u3 = d2(n3.Se, e2));
      let f2 = s2 + h2 * (o3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2;
      n3.pe = p2, f2 = s2 + h2 * (a3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.de = p2, f2 = s2 + h2 * (c3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.fe = p2, f2 = s2 + h2 * (u3 - r2), p2 = l2 ? f2 : this.ho - 1 - f2, n3.me = p2;
    }
  }
  pn(t2, e2) {
    const i2 = this.To(t2, e2);
    return this.$o(i2, e2);
  }
  $o(t2, e2) {
    let i2 = t2;
    return this.Mh() ? i2 = function(t3, e3) {
      return e3 < 0 && (t3 = -t3), t3 / 100 * e3 + e3;
    }(i2, e2) : this.Oo() && (i2 = function(t3, e3) {
      return t3 -= 100, e3 < 0 && (t3 = -t3), t3 / 100 * e3 + e3;
    }(i2, e2)), i2;
  }
  Ba() {
    return this.po;
  }
  Uo() {
    if (this.mo) return this.mo;
    let t2 = [];
    for (let e2 = 0; e2 < this.po.length; e2++) {
      const i2 = this.po[e2];
      null === i2.Xi() && i2.Ki(e2 + 1), t2.push(i2);
    }
    return t2 = WS(t2), this.mo = t2, this.mo;
  }
  qo(t2) {
    -1 === this.po.indexOf(t2) && (this.po.push(t2), this.Ra(), this.Yo());
  }
  Zo(t2) {
    const e2 = this.po.indexOf(t2);
    if (-1 === e2) throw new Error("source is not attached to scale");
    this.po.splice(e2, 1), 0 === this.po.length && (this.Ro({ Wn: true }), this.Ao(null)), this.Ra(), this.Yo();
  }
  Ct() {
    let t2 = null;
    for (const e2 of this.po) {
      const i2 = e2.Ct();
      null !== i2 && (null === t2 || i2.la < t2.la) && (t2 = i2);
    }
    return null === t2 ? null : t2.Vt;
  }
  Bo() {
    return this.cn.invertScale;
  }
  Ha() {
    const t2 = null === this.Ct();
    if (null !== this.bo && (t2 || this.bo.Xo === t2)) return this.bo.Ha;
    this.Co.io();
    const e2 = this.Co.Ha();
    return this.bo = { Ha: e2, Xo: t2 }, this.fo.m(), e2;
  }
  Ko() {
    return this.fo;
  }
  Go(t2) {
    this.Mh() || this.Oo() || null === this.wo && null === this.ao && (this.Ni() || (this.wo = this.ho - t2, this.ao = uk(this.Lh()).Th()));
  }
  Jo(t2) {
    if (this.Mh() || this.Oo()) return;
    if (null === this.wo) return;
    this.Ro({ Wn: false }), (t2 = this.ho - t2) < 0 && (t2 = 0);
    let e2 = (this.wo + 0.2 * (this.ho - 1)) / (t2 + 0.2 * (this.ho - 1));
    const i2 = uk(this.ao).Th();
    e2 = Math.max(e2, 0.1), i2.Vh(e2), this.Ao(i2);
  }
  Qo() {
    this.Mh() || this.Oo() || (this.wo = null, this.ao = null);
  }
  t_(t2) {
    this.Vo() || null === this.Mo && null === this.ao && (this.Ni() || (this.Mo = t2, this.ao = uk(this.Lh()).Th()));
  }
  i_(t2) {
    if (this.Vo()) return;
    if (null === this.Mo) return;
    const e2 = uk(this.Lh()).Dh() / (this.Eo() - 1);
    let i2 = t2 - this.Mo;
    this.Bo() && (i2 *= -1);
    const s2 = i2 * e2, n2 = uk(this.ao).Th();
    n2.Oh(s2), this.Ao(n2, true), this.bo = null;
  }
  n_() {
    this.Vo() || null !== this.Mo && (this.Mo = null, this.ao = null);
  }
  ba() {
    return this.wa || this.Ra(), this.wa;
  }
  Fi(t2, e2) {
    switch (this.cn.mode) {
      case 2:
        return this.s_($S(t2, e2));
      case 3:
        return this.ba().format(AS(t2, e2));
      default:
        return this.Wh(t2);
    }
  }
  eo(t2) {
    switch (this.cn.mode) {
      case 2:
        return this.s_(t2);
      case 3:
        return this.ba().format(t2);
      default:
        return this.Wh(t2);
    }
  }
  Yl(t2) {
    return this.Wh(t2, uk(this.e_()).ba());
  }
  Zl(t2, e2) {
    return t2 = $S(t2, e2), this.s_(t2, jS);
  }
  r_() {
    return this.po;
  }
  h_(t2) {
    this.oo = { uo: t2, _o: false };
  }
  Vn() {
    this.po.forEach((t2) => t2.Vn());
  }
  Ra() {
    this.bo = null;
    const t2 = this.e_();
    let e2 = 100;
    null !== t2 && (e2 = Math.round(1 / t2.ma())), this.wa = qS, this.Mh() ? (this.wa = jS, e2 = 100) : this.Oo() ? (this.wa = new ft(100, 1), e2 = 100) : null !== t2 && (this.wa = t2.ba()), this.Co = new fn(this, e2, this.To.bind(this), this.Po.bind(this)), this.Co.io();
  }
  Yo() {
    this.mo = null;
  }
  e_() {
    return this.po[0] || null;
  }
  No() {
    return this.Bo() ? this.cn.scaleMargins.bottom * this.At() + this.do : this.cn.scaleMargins.top * this.At() + this.co;
  }
  Fo() {
    return this.Bo() ? this.cn.scaleMargins.top * this.At() + this.co : this.cn.scaleMargins.bottom * this.At() + this.do;
  }
  Wo() {
    this.oo._o || (this.oo._o = true, this.l_());
  }
  Do() {
    this.lo = null;
  }
  Po(t2, e2) {
    if (this.Wo(), this.Ni()) return 0;
    t2 = this.ro() && t2 ? VS(t2, this.xo) : t2;
    const i2 = uk(this.Lh()), s2 = this.Fo() + (this.Eo() - 1) * (t2 - i2.Ph()) / i2.Dh();
    return this.jo(s2);
  }
  To(t2, e2) {
    if (this.Wo(), this.Ni()) return 0;
    const i2 = this.jo(t2), s2 = uk(this.Lh()), n2 = s2.Ph() + s2.Dh() * ((i2 - this.Fo()) / (this.Eo() - 1));
    return this.ro() ? OS(n2, this.xo) : n2;
  }
  Io() {
    this.bo = null, this.Co.io();
  }
  l_() {
    const t2 = this.oo.uo;
    if (null === t2) return;
    let e2 = null;
    const i2 = this.r_();
    let s2 = 0, n2 = 0;
    for (const r3 of i2) {
      if (!r3.yt()) continue;
      const i3 = r3.Ct();
      if (null === i3) continue;
      const o3 = r3.Il(t2.Os(), t2.ui());
      let a2 = o3 && o3.Lh();
      if (null !== a2) {
        switch (this.cn.mode) {
          case 1:
            a2 = IS(a2, this.xo);
            break;
          case 2:
            a2 = ES(a2, i3.Vt);
            break;
          case 3:
            a2 = LS(a2, i3.Vt);
        }
        if (e2 = null === e2 ? a2 : e2.ts(uk(a2)), null !== o3) {
          const t3 = o3.Eh();
          null !== t3 && (s2 = Math.max(s2, t3.above), n2 = Math.max(n2, t3.below));
        }
      }
    }
    if (s2 === this.co && n2 === this.do || (this.co = s2, this.do = n2, this.bo = null, this.Do()), null !== e2) {
      if (e2.Ph() === e2.Rh()) {
        const t3 = this.e_(), i3 = 5 * (null === t3 || this.Mh() || this.Oo() ? 1 : t3.ma());
        this.ro() && (e2 = NS(e2, this.xo)), e2 = new Ri(e2.Ph() - i3, e2.Rh() + i3), this.ro() && (e2 = IS(e2, this.xo));
      }
      if (this.ro()) {
        const t3 = NS(e2, this.xo), i3 = FS(t3);
        if (r2 = i3, o2 = this.xo, r2.$a !== o2.$a || r2.Ua !== o2.Ua) {
          const s3 = null !== this.ao ? NS(this.ao, this.xo) : null;
          this.xo = i3, e2 = IS(t3, i3), null !== s3 && (this.ao = IS(s3, i3));
        }
      }
      this.Ao(e2);
    } else null === this.Ih && (this.Ao(new Ri(-0.5, 0.5)), this.xo = FS(null));
    var r2, o2;
    this.oo._o = true;
  }
  Ho() {
    return this.Mh() ? $S : this.Oo() ? AS : this.ro() ? (t2) => VS(t2, this.xo) : null;
  }
  a_(t2, e2, i2) {
    return void 0 === e2 ? (void 0 === i2 && (i2 = this.ba()), i2.format(t2)) : e2(t2);
  }
  Wh(t2, e2) {
    return this.a_(t2, this.yo.priceFormatter, e2);
  }
  s_(t2, e2) {
    return this.a_(t2, this.yo.percentageFormatter, e2);
  }
}
class gn {
  constructor(t2, e2) {
    this.po = [], this.o_ = /* @__PURE__ */ new Map(), this.ho = 0, this.__ = 0, this.u_ = 1e3, this.mo = null, this.c_ = new D(), this.yl = t2, this.$i = e2, this.d_ = new nn(this);
    const i2 = e2.W();
    this.f_ = this.v_("left", i2.leftPriceScale), this.p_ = this.v_("right", i2.rightPriceScale), this.f_.zo().l(this.m_.bind(this, this.f_), this), this.p_.zo().l(this.m_.bind(this, this.p_), this), this.b_(i2);
  }
  b_(t2) {
    if (t2.leftPriceScale && this.f_.$h(t2.leftPriceScale), t2.rightPriceScale && this.p_.$h(t2.rightPriceScale), t2.localization && (this.f_.Ra(), this.p_.Ra()), t2.overlayPriceScales) {
      const e2 = Array.from(this.o_.values());
      for (const i2 of e2) {
        const e3 = uk(i2[0].Dt());
        e3.$h(t2.overlayPriceScales), t2.localization && e3.Ra();
      }
    }
  }
  w_(t2) {
    switch (t2) {
      case "left":
        return this.f_;
      case "right":
        return this.p_;
    }
    return this.o_.has(t2) ? ck(this.o_.get(t2))[0].Dt() : null;
  }
  S() {
    this.$t().g_().p(this), this.f_.zo().p(this), this.p_.zo().p(this), this.po.forEach((t2) => {
      t2.S && t2.S();
    }), this.c_.m();
  }
  M_() {
    return this.u_;
  }
  x_(t2) {
    this.u_ = t2;
  }
  $t() {
    return this.$i;
  }
  Hi() {
    return this.__;
  }
  At() {
    return this.ho;
  }
  S_(t2) {
    this.__ = t2, this.k_();
  }
  Lo(t2) {
    this.ho = t2, this.f_.Lo(t2), this.p_.Lo(t2), this.po.forEach((e2) => {
      if (this.vr(e2)) {
        const i2 = e2.Dt();
        null !== i2 && i2.Lo(t2);
      }
    }), this.k_();
  }
  Ba() {
    return this.po;
  }
  vr(t2) {
    const e2 = t2.Dt();
    return null === e2 || this.f_ !== e2 && this.p_ !== e2;
  }
  qo(t2, e2, i2) {
    const s2 = void 0 !== i2 ? i2 : this.C_().y_ + 1;
    this.T_(t2, e2, s2);
  }
  Zo(t2) {
    const e2 = this.po.indexOf(t2);
    hk(-1 !== e2, "removeDataSource: invalid data source"), this.po.splice(e2, 1);
    const i2 = uk(t2.Dt()).Pa();
    if (this.o_.has(i2)) {
      const e3 = ck(this.o_.get(i2)), s3 = e3.indexOf(t2);
      -1 !== s3 && (e3.splice(s3, 1), 0 === e3.length && this.o_.delete(i2));
    }
    const s2 = t2.Dt();
    s2 && s2.Ba().indexOf(t2) >= 0 && s2.Zo(t2), null !== s2 && (s2.Yo(), this.P_(s2)), this.mo = null;
  }
  mr(t2) {
    return t2 === this.f_ ? "left" : t2 === this.p_ ? "right" : "overlay";
  }
  R_() {
    return this.f_;
  }
  D_() {
    return this.p_;
  }
  V_(t2, e2) {
    t2.Go(e2);
  }
  O_(t2, e2) {
    t2.Jo(e2), this.k_();
  }
  B_(t2) {
    t2.Qo();
  }
  A_(t2, e2) {
    t2.t_(e2);
  }
  I_(t2, e2) {
    t2.i_(e2), this.k_();
  }
  z_(t2) {
    t2.n_();
  }
  k_() {
    this.po.forEach((t2) => {
      t2.Vn();
    });
  }
  vn() {
    let t2 = null;
    return this.$i.W().rightPriceScale.visible && 0 !== this.p_.Ba().length ? t2 = this.p_ : this.$i.W().leftPriceScale.visible && 0 !== this.f_.Ba().length ? t2 = this.f_ : 0 !== this.po.length && (t2 = this.po[0].Dt()), null === t2 && (t2 = this.p_), t2;
  }
  pr() {
    let t2 = null;
    return this.$i.W().rightPriceScale.visible ? t2 = this.p_ : this.$i.W().leftPriceScale.visible && (t2 = this.f_), t2;
  }
  P_(t2) {
    null !== t2 && t2.Vo() && this.L_(t2);
  }
  E_(t2) {
    const e2 = this.yl.Xs();
    t2.Ro({ Wn: true }), null !== e2 && t2.h_(e2), this.k_();
  }
  N_() {
    this.L_(this.f_), this.L_(this.p_);
  }
  F_() {
    this.P_(this.f_), this.P_(this.p_), this.po.forEach((t2) => {
      this.vr(t2) && this.P_(t2.Dt());
    }), this.k_(), this.$i.Uh();
  }
  Uo() {
    return null === this.mo && (this.mo = WS(this.po)), this.mo;
  }
  W_() {
    return this.c_;
  }
  j_() {
    return this.d_;
  }
  L_(t2) {
    const e2 = t2.r_();
    if (e2 && e2.length > 0 && !this.yl.Ni()) {
      const e3 = this.yl.Xs();
      null !== e3 && t2.h_(e3);
    }
    t2.Vn();
  }
  C_() {
    const t2 = this.Uo();
    if (0 === t2.length) return { H_: 0, y_: 0 };
    let e2 = 0, i2 = 0;
    for (let s2 = 0; s2 < t2.length; s2++) {
      const n2 = t2[s2].Xi();
      null !== n2 && (n2 < e2 && (e2 = n2), n2 > i2 && (i2 = n2));
    }
    return { H_: e2, y_: i2 };
  }
  T_(t2, e2, i2) {
    let s2 = this.w_(e2);
    if (null === s2 && (s2 = this.v_(e2, this.$i.W().overlayPriceScales)), this.po.push(t2), !Bk(e2)) {
      const i3 = this.o_.get(e2) || [];
      i3.push(t2), this.o_.set(e2, i3);
    }
    s2.qo(t2), t2.Gi(s2), t2.Ki(i2), this.P_(s2), this.mo = null;
  }
  m_(t2, e2, i2) {
    e2.Cr !== i2.Cr && this.L_(t2);
  }
  v_(t2, e2) {
    const i2 = Object.assign({ visible: true, autoScale: true }, Dk(e2)), s2 = new wn(t2, i2, this.$i.W().layout, this.$i.W().localization);
    return s2.Lo(this.At()), s2;
  }
}
class Mn {
  constructor(t2, e2, i2 = 50) {
    this.Ke = 0, this.Ge = 1, this.Je = 1, this.tr = /* @__PURE__ */ new Map(), this.Qe = /* @__PURE__ */ new Map(), this.U_ = t2, this.q_ = e2, this.ir = i2;
  }
  Y_(t2) {
    const e2 = t2.time, i2 = this.q_.cacheKey(e2), s2 = this.tr.get(i2);
    if (void 0 !== s2) return s2.Z_;
    if (this.Ke === this.ir) {
      const t3 = this.Qe.get(this.Je);
      this.Qe.delete(this.Je), this.tr.delete(ck(t3)), this.Je++, this.Ke--;
    }
    const n2 = this.U_(t2);
    return this.tr.set(i2, { Z_: n2, rr: this.Ge }), this.Qe.set(this.Ge, i2), this.Ke++, this.Ge++, n2;
  }
}
class xn {
  constructor(t2, e2) {
    hk(t2 <= e2, "right should be >= left"), this.X_ = t2, this.K_ = e2;
  }
  Os() {
    return this.X_;
  }
  ui() {
    return this.K_;
  }
  G_() {
    return this.K_ - this.X_ + 1;
  }
  Kr(t2) {
    return this.X_ <= t2 && t2 <= this.K_;
  }
  Ch(t2) {
    return this.X_ === t2.Os() && this.K_ === t2.ui();
  }
}
function HS(t2, e2) {
  return null === t2 || null === e2 ? t2 === e2 : t2.Ch(e2);
}
class kn {
  constructor() {
    this.J_ = /* @__PURE__ */ new Map(), this.tr = null, this.Q_ = false;
  }
  tu(t2) {
    this.Q_ = t2, this.tr = null;
  }
  iu(t2, e2) {
    this.nu(e2), this.tr = null;
    for (let i2 = e2; i2 < t2.length; ++i2) {
      const e3 = t2[i2];
      let s2 = this.J_.get(e3.timeWeight);
      void 0 === s2 && (s2 = [], this.J_.set(e3.timeWeight, s2)), s2.push({ index: i2, time: e3.time, weight: e3.timeWeight, originalTime: e3.originalTime });
    }
  }
  su(t2, e2) {
    const i2 = Math.ceil(e2 / t2);
    return null !== this.tr && this.tr.eu === i2 || (this.tr = { Ha: this.ru(i2), eu: i2 }), this.tr.Ha;
  }
  nu(t2) {
    if (0 === t2) return void this.J_.clear();
    const e2 = [];
    this.J_.forEach((i2, s2) => {
      t2 <= i2[0].index ? e2.push(s2) : i2.splice(eS(i2, t2, (e3) => e3.index < t2), 1 / 0);
    });
    for (const t3 of e2) this.J_.delete(t3);
  }
  ru(t2) {
    let e2 = [];
    for (const i2 of Array.from(this.J_.keys()).sort((t3, e3) => e3 - t3)) {
      if (!this.J_.get(i2)) continue;
      const s2 = e2;
      e2 = [];
      const n2 = s2.length;
      let r2 = 0;
      const o2 = ck(this.J_.get(i2)), a2 = o2.length;
      let l2 = 1 / 0, h2 = -1 / 0;
      for (let i3 = 0; i3 < a2; i3++) {
        const a3 = o2[i3], c2 = a3.index;
        for (; r2 < n2; ) {
          const t3 = s2[r2], i4 = t3.index;
          if (!(i4 < c2)) {
            l2 = i4;
            break;
          }
          r2++, e2.push(t3), h2 = i4, l2 = 1 / 0;
        }
        if (l2 - c2 >= t2 && c2 - h2 >= t2) e2.push(a3), h2 = c2;
        else if (this.Q_) return s2;
      }
      for (; r2 < n2; r2++) e2.push(s2[r2]);
    }
    return e2;
  }
}
class yn {
  constructor(t2) {
    this.hu = t2;
  }
  lu() {
    return null === this.hu ? null : new xn(Math.floor(this.hu.Os()), Math.ceil(this.hu.ui()));
  }
  au() {
    return this.hu;
  }
  static ou() {
    return new yn(null);
  }
}
function US(t2, e2) {
  return t2.weight > e2.weight ? t2 : e2;
}
class Tn {
  constructor(t2, e2, i2, s2) {
    this.__ = 0, this._u = null, this.uu = [], this.Mo = null, this.wo = null, this.cu = new kn(), this.du = /* @__PURE__ */ new Map(), this.fu = yn.ou(), this.vu = true, this.pu = new D(), this.mu = new D(), this.bu = new D(), this.wu = null, this.gu = null, this.Mu = [], this.cn = e2, this.yo = i2, this.xu = e2.rightOffset, this.Su = e2.barSpacing, this.$i = t2, this.q_ = s2, this.ku(), this.cu.tu(e2.uniformDistribution);
  }
  W() {
    return this.cn;
  }
  yu(t2) {
    kk(this.yo, t2), this.Cu(), this.ku();
  }
  $h(t2, e2) {
    var i2;
    kk(this.cn, t2), this.cn.fixLeftEdge && this.Tu(), this.cn.fixRightEdge && this.Pu(), void 0 !== t2.barSpacing && this.$i.Gn(t2.barSpacing), void 0 !== t2.rightOffset && this.$i.Jn(t2.rightOffset), void 0 !== t2.minBarSpacing && this.$i.Gn(null !== (i2 = t2.barSpacing) && void 0 !== i2 ? i2 : this.Su), this.Cu(), this.ku(), this.bu.m();
  }
  mn(t2) {
    var e2, i2;
    return null !== (i2 = null === (e2 = this.uu[t2]) || void 0 === e2 ? void 0 : e2.time) && void 0 !== i2 ? i2 : null;
  }
  Ui(t2) {
    var e2;
    return null !== (e2 = this.uu[t2]) && void 0 !== e2 ? e2 : null;
  }
  Va(t2, e2) {
    if (this.uu.length < 1) return null;
    if (this.q_.key(t2) > this.q_.key(this.uu[this.uu.length - 1].time)) return e2 ? this.uu.length - 1 : null;
    const i2 = eS(this.uu, this.q_.key(t2), (t3, e3) => this.q_.key(t3.time) < e3);
    return this.q_.key(t2) < this.q_.key(this.uu[i2].time) ? e2 ? i2 : null : i2;
  }
  Ni() {
    return 0 === this.__ || 0 === this.uu.length || null === this._u;
  }
  Da() {
    return this.uu.length > 0;
  }
  Xs() {
    return this.Ru(), this.fu.lu();
  }
  Du() {
    return this.Ru(), this.fu.au();
  }
  Vu() {
    const t2 = this.Xs();
    if (null === t2) return null;
    const e2 = { from: t2.Os(), to: t2.ui() };
    return this.Ou(e2);
  }
  Ou(t2) {
    const e2 = Math.round(t2.from), i2 = Math.round(t2.to), s2 = uk(this.Bu()), n2 = uk(this.Au());
    return { from: uk(this.Ui(Math.max(s2, e2))), to: uk(this.Ui(Math.min(n2, i2))) };
  }
  Iu(t2) {
    return { from: uk(this.Va(t2.from, true)), to: uk(this.Va(t2.to, true)) };
  }
  Hi() {
    return this.__;
  }
  S_(t2) {
    if (!isFinite(t2) || t2 <= 0) return;
    if (this.__ === t2) return;
    const e2 = this.Du(), i2 = this.__;
    if (this.__ = t2, this.vu = true, this.cn.lockVisibleTimeRangeOnResize && 0 !== i2) {
      const e3 = this.Su * t2 / i2;
      this.Su = e3;
    }
    if (this.cn.fixLeftEdge && null !== e2 && e2.Os() <= 0) {
      const e3 = i2 - t2;
      this.xu -= Math.round(e3 / this.Su) + 1, this.vu = true;
    }
    this.zu(), this.Lu();
  }
  It(t2) {
    if (this.Ni() || !Mk(t2)) return 0;
    const e2 = this.Eu() + this.xu - t2;
    return this.__ - (e2 + 0.5) * this.Su - 1;
  }
  Qs(t2, e2) {
    const i2 = this.Eu(), s2 = void 0 === e2 ? 0 : e2.from, n2 = void 0 === e2 ? t2.length : e2.to;
    for (let e3 = s2; e3 < n2; e3++) {
      const s3 = t2[e3].ot, n3 = i2 + this.xu - s3, r2 = this.__ - (n3 + 0.5) * this.Su - 1;
      t2[e3].nt = r2;
    }
  }
  Nu(t2) {
    return Math.ceil(this.Fu(t2));
  }
  Jn(t2) {
    this.vu = true, this.xu = t2, this.Lu(), this.$i.Wu(), this.$i.Uh();
  }
  le() {
    return this.Su;
  }
  Gn(t2) {
    this.ju(t2), this.Lu(), this.$i.Wu(), this.$i.Uh();
  }
  Hu() {
    return this.xu;
  }
  Ha() {
    if (this.Ni()) return null;
    if (null !== this.gu) return this.gu;
    const t2 = this.Su, e2 = 5 * (this.$i.W().layout.fontSize + 4) / 8 * (this.cn.tickMarkMaxCharacterLength || 8), i2 = Math.round(e2 / t2), s2 = uk(this.Xs()), n2 = Math.max(s2.Os(), s2.Os() - i2), r2 = Math.max(s2.ui(), s2.ui() - i2), o2 = this.cu.su(t2, e2), a2 = this.Bu() + i2, l2 = this.Au() - i2, h2 = this.$u(), c2 = this.cn.fixLeftEdge || h2, u2 = this.cn.fixRightEdge || h2;
    let d2 = 0;
    for (const t3 of o2) {
      if (!(n2 <= t3.index && t3.index <= r2)) continue;
      let i3;
      d2 < this.Mu.length ? (i3 = this.Mu[d2], i3.coord = this.It(t3.index), i3.label = this.Uu(t3), i3.weight = t3.weight) : (i3 = { needAlignCoordinate: false, coord: this.It(t3.index), label: this.Uu(t3), weight: t3.weight }, this.Mu.push(i3)), this.Su > e2 / 2 && !h2 ? i3.needAlignCoordinate = false : i3.needAlignCoordinate = c2 && t3.index <= a2 || u2 && t3.index >= l2, d2++;
    }
    return this.Mu.length = d2, this.gu = this.Mu, this.Mu;
  }
  qu() {
    this.vu = true, this.Gn(this.cn.barSpacing), this.Jn(this.cn.rightOffset);
  }
  Yu(t2) {
    this.vu = true, this._u = t2, this.Lu(), this.Tu();
  }
  Zu(t2, e2) {
    const i2 = this.Fu(t2), s2 = this.le(), n2 = s2 + e2 * (s2 / 10);
    this.Gn(n2), this.cn.rightBarStaysOnScroll || this.Jn(this.Hu() + (i2 - this.Fu(t2)));
  }
  Go(t2) {
    this.Mo && this.n_(), null === this.wo && null === this.wu && (this.Ni() || (this.wo = t2, this.Xu()));
  }
  Jo(t2) {
    if (null === this.wu) return;
    const e2 = Xk(this.__ - t2, 0, this.__), i2 = Xk(this.__ - uk(this.wo), 0, this.__);
    0 !== e2 && 0 !== i2 && this.Gn(this.wu.le * e2 / i2);
  }
  Qo() {
    null !== this.wo && (this.wo = null, this.Ku());
  }
  t_(t2) {
    null === this.Mo && null === this.wu && (this.Ni() || (this.Mo = t2, this.Xu()));
  }
  i_(t2) {
    if (null === this.Mo) return;
    const e2 = (this.Mo - t2) / this.le();
    this.xu = uk(this.wu).Hu + e2, this.vu = true, this.Lu();
  }
  n_() {
    null !== this.Mo && (this.Mo = null, this.Ku());
  }
  Gu() {
    this.Ju(this.cn.rightOffset);
  }
  Ju(t2, e2 = 400) {
    if (!isFinite(t2)) throw new RangeError("offset is required and must be finite number");
    if (!isFinite(e2) || e2 <= 0) throw new RangeError("animationDuration (optional) must be finite positive number");
    const i2 = this.xu, s2 = performance.now();
    this.$i.Zn({ Qu: (t3) => (t3 - s2) / e2 >= 1, tc: (n2) => {
      const r2 = (n2 - s2) / e2;
      return r2 >= 1 ? t2 : i2 + (t2 - i2) * r2;
    } });
  }
  bt(t2, e2) {
    this.vu = true, this.uu = t2, this.cu.iu(t2, e2), this.Lu();
  }
  nc() {
    return this.pu;
  }
  sc() {
    return this.mu;
  }
  ec() {
    return this.bu;
  }
  Eu() {
    return this._u || 0;
  }
  rc(t2) {
    const e2 = t2.G_();
    this.ju(this.__ / e2), this.xu = t2.ui() - this.Eu(), this.Lu(), this.vu = true, this.$i.Wu(), this.$i.Uh();
  }
  hc() {
    const t2 = this.Bu(), e2 = this.Au();
    null !== t2 && null !== e2 && this.rc(new xn(t2, e2 + this.cn.rightOffset));
  }
  lc(t2) {
    const e2 = new xn(t2.from, t2.to);
    this.rc(e2);
  }
  qi(t2) {
    return void 0 !== this.yo.timeFormatter ? this.yo.timeFormatter(t2.originalTime) : this.q_.formatHorzItem(t2.time);
  }
  $u() {
    const { handleScroll: t2, handleScale: e2 } = this.$i.W();
    return !(t2.horzTouchDrag || t2.mouseWheel || t2.pressedMouseMove || t2.vertTouchDrag || e2.axisDoubleClickReset.time || e2.axisPressedMouseMove.time || e2.mouseWheel || e2.pinch);
  }
  Bu() {
    return 0 === this.uu.length ? null : 0;
  }
  Au() {
    return 0 === this.uu.length ? null : this.uu.length - 1;
  }
  ac(t2) {
    return (this.__ - 1 - t2) / this.Su;
  }
  Fu(t2) {
    const e2 = this.ac(t2), i2 = this.Eu() + this.xu - e2;
    return Math.round(1e6 * i2) / 1e6;
  }
  ju(t2) {
    const e2 = this.Su;
    this.Su = t2, this.zu(), e2 !== this.Su && (this.vu = true, this.oc());
  }
  Ru() {
    if (!this.vu) return;
    if (this.vu = false, this.Ni()) return void this._c(yn.ou());
    const t2 = this.Eu(), e2 = this.__ / this.Su, i2 = this.xu + t2, s2 = new xn(i2 - e2 + 1, i2);
    this._c(new yn(s2));
  }
  zu() {
    const t2 = this.uc();
    if (this.Su < t2 && (this.Su = t2, this.vu = true), 0 !== this.__) {
      const t3 = 0.5 * this.__;
      this.Su > t3 && (this.Su = t3, this.vu = true);
    }
  }
  uc() {
    return this.cn.fixLeftEdge && this.cn.fixRightEdge && 0 !== this.uu.length ? this.__ / this.uu.length : this.cn.minBarSpacing;
  }
  Lu() {
    const t2 = this.cc();
    null !== t2 && this.xu < t2 && (this.xu = t2, this.vu = true);
    const e2 = this.dc();
    this.xu > e2 && (this.xu = e2, this.vu = true);
  }
  cc() {
    const t2 = this.Bu(), e2 = this._u;
    return null === t2 || null === e2 ? null : t2 - e2 - 1 + (this.cn.fixLeftEdge ? this.__ / this.Su : Math.min(2, this.uu.length));
  }
  dc() {
    return this.cn.fixRightEdge ? 0 : this.__ / this.Su - Math.min(2, this.uu.length);
  }
  Xu() {
    this.wu = { le: this.le(), Hu: this.Hu() };
  }
  Ku() {
    this.wu = null;
  }
  Uu(t2) {
    let e2 = this.du.get(t2.weight);
    return void 0 === e2 && (e2 = new Mn((t3) => this.fc(t3), this.q_), this.du.set(t2.weight, e2)), e2.Y_(t2);
  }
  fc(t2) {
    return this.q_.formatTickmark(t2, this.yo);
  }
  _c(t2) {
    const e2 = this.fu;
    this.fu = t2, HS(e2.lu(), this.fu.lu()) || this.pu.m(), HS(e2.au(), this.fu.au()) || this.mu.m(), this.oc();
  }
  oc() {
    this.gu = null;
  }
  Cu() {
    this.oc(), this.du.clear();
  }
  ku() {
    this.q_.updateFormatter(this.yo);
  }
  Tu() {
    if (!this.cn.fixLeftEdge) return;
    const t2 = this.Bu();
    if (null === t2) return;
    const e2 = this.Xs();
    if (null === e2) return;
    const i2 = e2.Os() - t2;
    if (i2 < 0) {
      const t3 = this.xu - i2 - 1;
      this.Jn(t3);
    }
    this.zu();
  }
  Pu() {
    this.Lu(), this.zu();
  }
}
class Pn {
  X(t2, e2, i2) {
    t2.useMediaCoordinateSpace((t3) => this.K(t3, e2, i2));
  }
  gl(t2, e2, i2) {
    t2.useMediaCoordinateSpace((t3) => this.vc(t3, e2, i2));
  }
  vc(t2, e2, i2) {
  }
}
class Rn extends Pn {
  constructor(t2) {
    super(), this.mc = /* @__PURE__ */ new Map(), this.zt = t2;
  }
  K(t2) {
  }
  vc(t2) {
    if (!this.zt.yt) return;
    const { context: e2, mediaSize: i2 } = t2;
    let s2 = 0;
    for (const t3 of this.zt.bc) {
      if (0 === t3.Kt.length) continue;
      e2.font = t3.R;
      const n3 = this.wc(e2, t3.Kt);
      n3 > i2.width ? t3.Zu = i2.width / n3 : t3.Zu = 1, s2 += t3.gc * t3.Zu;
    }
    let n2 = 0;
    switch (this.zt.Mc) {
      case "top":
        n2 = 0;
        break;
      case "center":
        n2 = Math.max((i2.height - s2) / 2, 0);
        break;
      case "bottom":
        n2 = Math.max(i2.height - s2, 0);
    }
    e2.fillStyle = this.zt.V;
    for (const t3 of this.zt.bc) {
      e2.save();
      let s3 = 0;
      switch (this.zt.xc) {
        case "left":
          e2.textAlign = "left", s3 = t3.gc / 2;
          break;
        case "center":
          e2.textAlign = "center", s3 = i2.width / 2;
          break;
        case "right":
          e2.textAlign = "right", s3 = i2.width - 1 - t3.gc / 2;
      }
      e2.translate(s3, n2), e2.textBaseline = "top", e2.font = t3.R, e2.scale(t3.Zu, t3.Zu), e2.fillText(t3.Kt, 0, t3.Sc), e2.restore(), n2 += t3.gc * t3.Zu;
    }
  }
  wc(t2, e2) {
    const i2 = this.kc(t2.font);
    let s2 = i2.get(e2);
    return void 0 === s2 && (s2 = t2.measureText(e2).width, i2.set(e2, s2)), s2;
  }
  kc(t2) {
    let e2 = this.mc.get(t2);
    return void 0 === e2 && (e2 = /* @__PURE__ */ new Map(), this.mc.set(t2, e2)), e2;
  }
}
class Dn {
  constructor(t2) {
    this.ft = true, this.Ft = { yt: false, V: "", bc: [], Mc: "center", xc: "center" }, this.Wt = new Rn(this.Ft), this.jt = t2;
  }
  bt() {
    this.ft = true;
  }
  gt() {
    return this.ft && (this.Mt(), this.ft = false), this.Wt;
  }
  Mt() {
    const t2 = this.jt.W(), e2 = this.Ft;
    e2.yt = t2.visible, e2.yt && (e2.V = t2.color, e2.xc = t2.horzAlign, e2.Mc = t2.vertAlign, e2.bc = [{ Kt: t2.text, R: $k(t2.fontSize, t2.fontFamily, t2.fontStyle), gc: 1.2 * t2.fontSize, Sc: 0, Zu: 0 }]);
  }
}
class Vn extends lt {
  constructor(t2, e2) {
    super(), this.cn = e2, this.wn = new Dn(this);
  }
  Rn() {
    return [];
  }
  Pn() {
    return [this.wn];
  }
  W() {
    return this.cn;
  }
  Vn() {
    this.wn.bt();
  }
}
var KS, YS, GS, XS, JS;
!function(t2) {
  t2[t2.OnTouchEnd = 0] = "OnTouchEnd", t2[t2.OnNextTap = 1] = "OnNextTap";
}(KS || (KS = {}));
class Ln {
  constructor(t2, e2, i2) {
    this.yc = [], this.Cc = [], this.__ = 0, this.Tc = null, this.Pc = new D(), this.Rc = new D(), this.Dc = null, this.Vc = t2, this.cn = e2, this.q_ = i2, this.Oc = new W(this), this.yl = new Tn(this, e2.timeScale, this.cn.localization, i2), this.vt = new ot(this, e2.crosshair), this.Bc = new Ji(e2.crosshair), this.Ac = new Vn(this, e2.watermark), this.Ic(), this.yc[0].x_(2e3), this.zc = this.Lc(0), this.Ec = this.Lc(1);
  }
  Kl() {
    this.Nc(ut.es());
  }
  Uh() {
    this.Nc(ut.ss());
  }
  oa() {
    this.Nc(new ut(1));
  }
  Gl(t2) {
    const e2 = this.Fc(t2);
    this.Nc(e2);
  }
  Wc() {
    return this.Tc;
  }
  jc(t2) {
    const e2 = this.Tc;
    this.Tc = t2, null !== e2 && this.Gl(e2.Hc), null !== t2 && this.Gl(t2.Hc);
  }
  W() {
    return this.cn;
  }
  $h(t2) {
    kk(this.cn, t2), this.yc.forEach((e2) => e2.b_(t2)), void 0 !== t2.timeScale && this.yl.$h(t2.timeScale), void 0 !== t2.localization && this.yl.yu(t2.localization), (t2.leftPriceScale || t2.rightPriceScale) && this.Pc.m(), this.zc = this.Lc(0), this.Ec = this.Lc(1), this.Kl();
  }
  $c(t2, e2) {
    if ("left" === t2) return void this.$h({ leftPriceScale: e2 });
    if ("right" === t2) return void this.$h({ rightPriceScale: e2 });
    const i2 = this.Uc(t2);
    null !== i2 && (i2.Dt.$h(e2), this.Pc.m());
  }
  Uc(t2) {
    for (const e2 of this.yc) {
      const i2 = e2.w_(t2);
      if (null !== i2) return { Ht: e2, Dt: i2 };
    }
    return null;
  }
  St() {
    return this.yl;
  }
  qc() {
    return this.yc;
  }
  Yc() {
    return this.Ac;
  }
  Zc() {
    return this.vt;
  }
  Xc() {
    return this.Rc;
  }
  Kc(t2, e2) {
    t2.Lo(e2), this.Wu();
  }
  S_(t2) {
    this.__ = t2, this.yl.S_(this.__), this.yc.forEach((e2) => e2.S_(t2)), this.Wu();
  }
  Ic(t2) {
    const e2 = new gn(this.yl, this);
    void 0 !== t2 ? this.yc.splice(t2, 0, e2) : this.yc.push(e2);
    const i2 = void 0 === t2 ? this.yc.length - 1 : t2, s2 = ut.es();
    return s2.Nn(i2, { Fn: 0, Wn: true }), this.Nc(s2), e2;
  }
  V_(t2, e2, i2) {
    t2.V_(e2, i2);
  }
  O_(t2, e2, i2) {
    t2.O_(e2, i2), this.Jl(), this.Nc(this.Gc(t2, 2));
  }
  B_(t2, e2) {
    t2.B_(e2), this.Nc(this.Gc(t2, 2));
  }
  A_(t2, e2, i2) {
    e2.Vo() || t2.A_(e2, i2);
  }
  I_(t2, e2, i2) {
    e2.Vo() || (t2.I_(e2, i2), this.Jl(), this.Nc(this.Gc(t2, 2)));
  }
  z_(t2, e2) {
    e2.Vo() || (t2.z_(e2), this.Nc(this.Gc(t2, 2)));
  }
  E_(t2, e2) {
    t2.E_(e2), this.Nc(this.Gc(t2, 2));
  }
  Jc(t2) {
    this.yl.Go(t2);
  }
  Qc(t2, e2) {
    const i2 = this.St();
    if (i2.Ni() || 0 === e2) return;
    const s2 = i2.Hi();
    t2 = Math.max(1, Math.min(t2, s2)), i2.Zu(t2, e2), this.Wu();
  }
  td(t2) {
    this.nd(0), this.sd(t2), this.ed();
  }
  rd(t2) {
    this.yl.Jo(t2), this.Wu();
  }
  hd() {
    this.yl.Qo(), this.Uh();
  }
  nd(t2) {
    this.yl.t_(t2);
  }
  sd(t2) {
    this.yl.i_(t2), this.Wu();
  }
  ed() {
    this.yl.n_(), this.Uh();
  }
  wt() {
    return this.Cc;
  }
  ld(t2, e2, i2, s2, n2) {
    this.vt.gn(t2, e2);
    let r2 = NaN, o2 = this.yl.Nu(t2);
    const a2 = this.yl.Xs();
    null !== a2 && (o2 = Math.min(Math.max(a2.Os(), o2), a2.ui()));
    const l2 = s2.vn(), h2 = l2.Ct();
    null !== h2 && (r2 = l2.pn(e2, h2)), r2 = this.Bc.Oa(r2, o2, s2), this.vt.kn(o2, r2, s2), this.oa(), n2 || this.Rc.m(this.vt.xt(), { x: t2, y: e2 }, i2);
  }
  ad(t2, e2, i2) {
    const s2 = i2.vn(), n2 = s2.Ct(), r2 = s2.Rt(t2, uk(n2)), o2 = this.yl.Va(e2, true), a2 = this.yl.It(uk(o2));
    this.ld(a2, r2, null, i2, true);
  }
  od(t2) {
    this.Zc().Cn(), this.oa(), t2 || this.Rc.m(null, null, null);
  }
  Jl() {
    const t2 = this.vt.Ht();
    if (null !== t2) {
      const e2 = this.vt.xn(), i2 = this.vt.Sn();
      this.ld(e2, i2, null, t2);
    }
    this.vt.Vn();
  }
  _d(t2, e2, i2) {
    const s2 = this.yl.mn(0);
    void 0 !== e2 && void 0 !== i2 && this.yl.bt(e2, i2);
    const n2 = this.yl.mn(0), r2 = this.yl.Eu(), o2 = this.yl.Xs();
    if (null !== o2 && null !== s2 && null !== n2) {
      const e3 = o2.Kr(r2), a2 = this.q_.key(s2) > this.q_.key(n2), l2 = null !== t2 && t2 > r2 && !a2, h2 = this.yl.W().allowShiftVisibleRangeOnWhitespaceReplacement, c2 = e3 && (!(void 0 === i2) || h2) && this.yl.W().shiftVisibleRangeOnNewBar;
      if (l2 && !c2) {
        const e4 = t2 - r2;
        this.yl.Jn(this.yl.Hu() - e4);
      }
    }
    this.yl.Yu(t2);
  }
  ia(t2) {
    null !== t2 && t2.F_();
  }
  dr(t2) {
    const e2 = this.yc.find((e3) => e3.Uo().includes(t2));
    return void 0 === e2 ? null : e2;
  }
  Wu() {
    this.Ac.Vn(), this.yc.forEach((t2) => t2.F_()), this.Jl();
  }
  S() {
    this.yc.forEach((t2) => t2.S()), this.yc.length = 0, this.cn.localization.priceFormatter = void 0, this.cn.localization.percentageFormatter = void 0, this.cn.localization.timeFormatter = void 0;
  }
  ud() {
    return this.Oc;
  }
  br() {
    return this.Oc.W();
  }
  g_() {
    return this.Pc;
  }
  dd(t2, e2, i2) {
    const s2 = this.yc[0], n2 = this.fd(e2, t2, s2, i2);
    return this.Cc.push(n2), 1 === this.Cc.length ? this.Kl() : this.Uh(), n2;
  }
  vd(t2) {
    const e2 = this.dr(t2), i2 = this.Cc.indexOf(t2);
    hk(-1 !== i2, "Series not found"), this.Cc.splice(i2, 1), uk(e2).Zo(t2), t2.S && t2.S();
  }
  Xl(t2, e2) {
    const i2 = uk(this.dr(t2));
    i2.Zo(t2);
    const s2 = this.Uc(e2);
    if (null === s2) {
      const s3 = t2.Xi();
      i2.qo(t2, e2, s3);
    } else {
      const n2 = s2.Ht === i2 ? t2.Xi() : void 0;
      s2.Ht.qo(t2, e2, n2);
    }
  }
  hc() {
    const t2 = ut.ss();
    t2.$n(), this.Nc(t2);
  }
  pd(t2) {
    const e2 = ut.ss();
    e2.Yn(t2), this.Nc(e2);
  }
  Kn() {
    const t2 = ut.ss();
    t2.Kn(), this.Nc(t2);
  }
  Gn(t2) {
    const e2 = ut.ss();
    e2.Gn(t2), this.Nc(e2);
  }
  Jn(t2) {
    const e2 = ut.ss();
    e2.Jn(t2), this.Nc(e2);
  }
  Zn(t2) {
    const e2 = ut.ss();
    e2.Zn(t2), this.Nc(e2);
  }
  Un() {
    const t2 = ut.ss();
    t2.Un(), this.Nc(t2);
  }
  md() {
    return this.cn.rightPriceScale.visible ? "right" : "left";
  }
  bd() {
    return this.Ec;
  }
  q() {
    return this.zc;
  }
  Bt(t2) {
    const e2 = this.Ec, i2 = this.zc;
    if (e2 === i2) return e2;
    if (t2 = Math.max(0, Math.min(100, Math.round(100 * t2))), null === this.Dc || this.Dc.Ps !== i2 || this.Dc.Rs !== e2) this.Dc = { Ps: i2, Rs: e2, wd: /* @__PURE__ */ new Map() };
    else {
      const e3 = this.Dc.wd.get(t2);
      if (void 0 !== e3) return e3;
    }
    const s2 = function(t3, e3, i3) {
      const [s3, n2, r2, o2] = yk(t3), [a2, l2, h2, c2] = yk(e3), u2 = [pk(s3 + i3 * (a2 - s3)), pk(n2 + i3 * (l2 - n2)), pk(r2 + i3 * (h2 - r2)), mk(o2 + i3 * (c2 - o2))];
      return `rgba(${u2[0]}, ${u2[1]}, ${u2[2]}, ${u2[3]})`;
    }(i2, e2, t2 / 100);
    return this.Dc.wd.set(t2, s2), s2;
  }
  Gc(t2, e2) {
    const i2 = new ut(e2);
    if (null !== t2) {
      const s2 = this.yc.indexOf(t2);
      i2.Nn(s2, { Fn: e2 });
    }
    return i2;
  }
  Fc(t2, e2) {
    return void 0 === e2 && (e2 = 2), this.Gc(this.dr(t2), e2);
  }
  Nc(t2) {
    this.Vc && this.Vc(t2), this.yc.forEach((t3) => t3.j_().qh().bt());
  }
  fd(t2, e2, i2, s2) {
    const n2 = new Gi(this, t2, e2, i2, s2), r2 = void 0 !== t2.priceScaleId ? t2.priceScaleId : this.md();
    return i2.qo(n2, r2), Bk(r2) || n2.$h(t2), n2;
  }
  Lc(t2) {
    const e2 = this.cn.layout;
    return "gradient" === e2.background.type ? 0 === t2 ? e2.background.topColor : e2.background.bottomColor : e2.background.color;
  }
}
function QS(t2) {
  return !Sk(t2) && !zk(t2);
}
function ZS(t2) {
  return Sk(t2);
}
!function(t2) {
  t2[t2.Disabled = 0] = "Disabled", t2[t2.Continuous = 1] = "Continuous", t2[t2.OnDataUpdate = 2] = "OnDataUpdate";
}(YS || (YS = {})), function(t2) {
  t2[t2.LastBar = 0] = "LastBar", t2[t2.LastVisible = 1] = "LastVisible";
}(GS || (GS = {})), function(t2) {
  t2.Solid = "solid", t2.VerticalGradient = "gradient";
}(XS || (XS = {})), function(t2) {
  t2[t2.Year = 0] = "Year", t2[t2.Month = 1] = "Month", t2[t2.DayOfMonth = 2] = "DayOfMonth", t2[t2.Time = 3] = "Time", t2[t2.TimeWithSeconds = 4] = "TimeWithSeconds";
}(JS || (JS = {}));
const tM = (t2) => t2.getUTCFullYear();
class jn {
  constructor(t2 = "yyyy-MM-dd", e2 = "default") {
    this.gd = t2, this.Md = e2;
  }
  Y_(t2) {
    return function(t3, e2, i2) {
      return e2.replace(/yyyy/g, ((t4) => jk(tM(t4), 4))(t3)).replace(/yy/g, ((t4) => jk(tM(t4) % 100, 2))(t3)).replace(/MMMM/g, ((t4, e3) => new Date(t4.getUTCFullYear(), t4.getUTCMonth(), 1).toLocaleString(e3, { month: "long" }))(t3, i2)).replace(/MMM/g, ((t4, e3) => new Date(t4.getUTCFullYear(), t4.getUTCMonth(), 1).toLocaleString(e3, { month: "short" }))(t3, i2)).replace(/MM/g, ((t4) => jk(((t5) => t5.getUTCMonth() + 1)(t4), 2))(t3)).replace(/dd/g, ((t4) => jk(((t5) => t5.getUTCDate())(t4), 2))(t3));
    }(t2, this.gd, this.Md);
  }
}
class Hn {
  constructor(t2) {
    this.xd = t2 || "%h:%m:%s";
  }
  Y_(t2) {
    return this.xd.replace("%h", jk(t2.getUTCHours(), 2)).replace("%m", jk(t2.getUTCMinutes(), 2)).replace("%s", jk(t2.getUTCSeconds(), 2));
  }
}
const eM = { Sd: "yyyy-MM-dd", kd: "%h:%m:%s", yd: " ", Cd: "default" };
class Un {
  constructor(t2 = {}) {
    const e2 = Object.assign(Object.assign({}, eM), t2);
    this.Td = new jn(e2.Sd, e2.Cd), this.Pd = new Hn(e2.kd), this.Rd = e2.yd;
  }
  Y_(t2) {
    return `${this.Td.Y_(t2)}${this.Rd}${this.Pd.Y_(t2)}`;
  }
}
function iM(t2) {
  return 60 * t2 * 60 * 1e3;
}
function sM(t2) {
  return 60 * t2 * 1e3;
}
const nM = [{ Dd: 1e3, Vd: 10 }, { Dd: sM(1), Vd: 20 }, { Dd: sM(5), Vd: 21 }, { Dd: sM(30), Vd: 22 }, { Dd: iM(1), Vd: 30 }, { Dd: iM(3), Vd: 31 }, { Dd: iM(6), Vd: 32 }, { Dd: iM(12), Vd: 33 }];
function rM(t2, e2) {
  if (t2.getUTCFullYear() !== e2.getUTCFullYear()) return 70;
  if (t2.getUTCMonth() !== e2.getUTCMonth()) return 60;
  if (t2.getUTCDate() !== e2.getUTCDate()) return 50;
  for (let i2 = nM.length - 1; i2 >= 0; --i2) if (Math.floor(e2.getTime() / nM[i2].Dd) !== Math.floor(t2.getTime() / nM[i2].Dd)) return nM[i2].Vd;
  return 0;
}
function oM(t2) {
  let e2 = t2;
  if (zk(t2) && (e2 = lM(t2)), !QS(e2)) throw new Error("time must be of type BusinessDay");
  const i2 = new Date(Date.UTC(e2.year, e2.month - 1, e2.day, 0, 0, 0, 0));
  return { Od: Math.round(i2.getTime() / 1e3), Bd: e2 };
}
function aM(t2) {
  if (!ZS(t2)) throw new Error("time must be of type isUTCTimestamp");
  return { Od: t2 };
}
function lM(t2) {
  const e2 = new Date(t2);
  if (isNaN(e2.getTime())) throw new Error(`Invalid date string=${t2}, expected format=yyyy-mm-dd`);
  return { day: e2.getUTCDate(), month: e2.getUTCMonth() + 1, year: e2.getUTCFullYear() };
}
function hM(t2) {
  zk(t2.time) && (t2.time = lM(t2.time));
}
class is {
  options() {
    return this.cn;
  }
  setOptions(t2) {
    this.cn = t2, this.updateFormatter(t2.localization);
  }
  preprocessData(t2) {
    Array.isArray(t2) ? function(t3) {
      t3.forEach(hM);
    }(t2) : hM(t2);
  }
  createConverterToInternalObj(t2) {
    return uk(function(t3) {
      return 0 === t3.length ? null : QS(t3[0].time) || zk(t3[0].time) ? oM : aM;
    }(t2));
  }
  key(t2) {
    return "object" == typeof t2 && "Od" in t2 ? t2.Od : this.key(this.convertHorzItemToInternal(t2));
  }
  cacheKey(t2) {
    const e2 = t2;
    return void 0 === e2.Bd ? new Date(1e3 * e2.Od).getTime() : new Date(Date.UTC(e2.Bd.year, e2.Bd.month - 1, e2.Bd.day)).getTime();
  }
  convertHorzItemToInternal(t2) {
    return ZS(e2 = t2) ? aM(e2) : QS(e2) ? oM(e2) : oM(lM(e2));
    var e2;
  }
  updateFormatter(t2) {
    if (!this.cn) return;
    const e2 = t2.dateFormat;
    this.cn.timeScale.timeVisible ? this.Ad = new Un({ Sd: e2, kd: this.cn.timeScale.secondsVisible ? "%h:%m:%s" : "%h:%m", yd: "   ", Cd: t2.locale }) : this.Ad = new jn(e2, t2.locale);
  }
  formatHorzItem(t2) {
    const e2 = t2;
    return this.Ad.Y_(new Date(1e3 * e2.Od));
  }
  formatTickmark(t2, e2) {
    const i2 = function(t3, e3, i3) {
      switch (t3) {
        case 0:
        case 10:
          return e3 ? i3 ? 4 : 3 : 2;
        case 20:
        case 21:
        case 22:
        case 30:
        case 31:
        case 32:
        case 33:
          return e3 ? 3 : 2;
        case 50:
          return 2;
        case 60:
          return 1;
        case 70:
          return 0;
      }
    }(t2.weight, this.cn.timeScale.timeVisible, this.cn.timeScale.secondsVisible), s2 = this.cn.timeScale;
    if (void 0 !== s2.tickMarkFormatter) {
      const n2 = s2.tickMarkFormatter(t2.originalTime, i2, e2.locale);
      if (null !== n2) return n2;
    }
    return function(t3, e3, i3) {
      const s3 = {};
      switch (e3) {
        case 0:
          s3.year = "numeric";
          break;
        case 1:
          s3.month = "short";
          break;
        case 2:
          s3.day = "numeric";
          break;
        case 3:
          s3.hour12 = false, s3.hour = "2-digit", s3.minute = "2-digit";
          break;
        case 4:
          s3.hour12 = false, s3.hour = "2-digit", s3.minute = "2-digit", s3.second = "2-digit";
      }
      const n2 = void 0 === t3.Bd ? new Date(1e3 * t3.Od) : new Date(Date.UTC(t3.Bd.year, t3.Bd.month - 1, t3.Bd.day));
      return new Date(n2.getUTCFullYear(), n2.getUTCMonth(), n2.getUTCDate(), n2.getUTCHours(), n2.getUTCMinutes(), n2.getUTCSeconds(), n2.getUTCMilliseconds()).toLocaleString(i3, s3);
    }(t2.time, i2, e2.locale);
  }
  maxTickMarkWeight(t2) {
    let e2 = t2.reduce(US, t2[0]).weight;
    return e2 > 30 && e2 < 50 && (e2 = 30), e2;
  }
  fillWeightsForPoints(t2, e2) {
    !function(t3, e3 = 0) {
      if (0 === t3.length) return;
      let i2 = 0 === e3 ? null : t3[e3 - 1].time.Od, s2 = null !== i2 ? new Date(1e3 * i2) : null, n2 = 0;
      for (let r2 = e3; r2 < t3.length; ++r2) {
        const e4 = t3[r2], o2 = new Date(1e3 * e4.time.Od);
        null !== s2 && (e4.timeWeight = rM(o2, s2)), n2 += e4.time.Od - (i2 || e4.time.Od), i2 = e4.time.Od, s2 = o2;
      }
      if (0 === e3 && t3.length > 1) {
        const e4 = Math.ceil(n2 / (t3.length - 1)), i3 = new Date(1e3 * (t3[0].time.Od - e4));
        t3[0].timeWeight = rM(new Date(1e3 * t3[0].time.Od), i3);
      }
    }(t2, e2);
  }
  static Id(t2) {
    return kk({ localization: { dateFormat: "dd MMM 'yy" } }, null != t2 ? t2 : {});
  }
}
const cM = "undefined" != typeof window;
function uM() {
  return !!cM && window.navigator.userAgent.toLowerCase().indexOf("firefox") > -1;
}
function dM() {
  return !!cM && /iPhone|iPad|iPod/.test(window.navigator.platform);
}
function fM(t2) {
  return t2 + t2 % 2;
}
function pM(t2, e2) {
  return t2.zd - e2.zd;
}
function mM(t2, e2, i2) {
  const s2 = (t2.zd - e2.zd) / (t2.ot - e2.ot);
  return Math.sign(s2) * Math.min(Math.abs(s2), i2);
}
class as {
  constructor(t2, e2, i2, s2) {
    this.Ld = null, this.Ed = null, this.Nd = null, this.Fd = null, this.Wd = null, this.jd = 0, this.Hd = 0, this.$d = t2, this.Ud = e2, this.qd = i2, this.rs = s2;
  }
  Yd(t2, e2) {
    if (null !== this.Ld) {
      if (this.Ld.ot === e2) return void (this.Ld.zd = t2);
      if (Math.abs(this.Ld.zd - t2) < this.rs) return;
    }
    this.Fd = this.Nd, this.Nd = this.Ed, this.Ed = this.Ld, this.Ld = { ot: e2, zd: t2 };
  }
  Vr(t2, e2) {
    if (null === this.Ld || null === this.Ed) return;
    if (e2 - this.Ld.ot > 50) return;
    let i2 = 0;
    const s2 = mM(this.Ld, this.Ed, this.Ud), n2 = pM(this.Ld, this.Ed), r2 = [s2], o2 = [n2];
    if (i2 += n2, null !== this.Nd) {
      const t3 = mM(this.Ed, this.Nd, this.Ud);
      if (Math.sign(t3) === Math.sign(s2)) {
        const e3 = pM(this.Ed, this.Nd);
        if (r2.push(t3), o2.push(e3), i2 += e3, null !== this.Fd) {
          const t4 = mM(this.Nd, this.Fd, this.Ud);
          if (Math.sign(t4) === Math.sign(s2)) {
            const e4 = pM(this.Nd, this.Fd);
            r2.push(t4), o2.push(e4), i2 += e4;
          }
        }
      }
    }
    let a2 = 0;
    for (let t3 = 0; t3 < r2.length; ++t3) a2 += o2[t3] / i2 * r2[t3];
    Math.abs(a2) < this.$d || (this.Wd = { zd: t2, ot: e2 }, this.Hd = a2, this.jd = function(t3, e3) {
      const i3 = Math.log(e3);
      return Math.log(1 * i3 / -t3) / i3;
    }(Math.abs(a2), this.qd));
  }
  tc(t2) {
    const e2 = uk(this.Wd), i2 = t2 - e2.ot;
    return e2.zd + this.Hd * (Math.pow(this.qd, i2) - 1) / Math.log(this.qd);
  }
  Qu(t2) {
    return null === this.Wd || this.Zd(t2) === this.jd;
  }
  Zd(t2) {
    const e2 = t2 - uk(this.Wd).ot;
    return Math.min(e2, this.jd);
  }
}
class os {
  constructor(t2, e2) {
    this.Xd = void 0, this.Kd = void 0, this.Gd = void 0, this.en = false, this.Jd = t2, this.Qd = e2, this.tf();
  }
  bt() {
    this.tf();
  }
  if() {
    this.Xd && this.Jd.removeChild(this.Xd), this.Kd && this.Jd.removeChild(this.Kd), this.Xd = void 0, this.Kd = void 0;
  }
  nf() {
    return this.en !== this.sf() || this.Gd !== this.ef();
  }
  ef() {
    return wk(yk(this.Qd.W().layout.textColor)) > 160 ? "dark" : "light";
  }
  sf() {
    return this.Qd.W().layout.attributionLogo;
  }
  rf() {
    const t2 = new URL(location.href);
    return t2.hostname ? "&utm_source=" + t2.hostname + t2.pathname : "";
  }
  tf() {
    this.nf() && (this.if(), this.en = this.sf(), this.en && (this.Gd = this.ef(), this.Kd = document.createElement("style"), this.Kd.innerText = "a#tv-attr-logo{--fill:#131722;--stroke:#fff;position:absolute;left:10px;bottom:10px;height:19px;width:35px;margin:0;padding:0;border:0;z-index:3;}a#tv-attr-logo[data-dark]{--fill:#D1D4DC;--stroke:#131722;}", this.Xd = document.createElement("a"), this.Xd.href = `https://www.tradingview.com/?utm_medium=lwc-link&utm_campaign=lwc-chart${this.rf()}`, this.Xd.title = "Charting by TradingView", this.Xd.id = "tv-attr-logo", this.Xd.target = "_blank", this.Xd.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 35 19" width="35" height="19" fill="none"><g fill-rule="evenodd" clip-path="url(#a)" clip-rule="evenodd"><path fill="var(--stroke)" d="M2 0H0v10h6v9h21.4l.5-1.3 6-15 1-2.7H23.7l-.5 1.3-.2.6a5 5 0 0 0-7-.9V0H2Zm20 17h4l5.2-13 .8-2h-7l-1 2.5-.2.5-1.5 3.8-.3.7V17Zm-.8-10a3 3 0 0 0 .7-2.7A3 3 0 1 0 16.8 7h4.4ZM14 7V2H2v6h6v9h4V7h2Z"/><path fill="var(--fill)" d="M14 2H2v6h6v9h6V2Zm12 15h-7l6-15h7l-6 15Zm-7-9a3 3 0 1 0 0-6 3 3 0 0 0 0 6Z"/></g><defs><clipPath id="a"><path fill="var(--stroke)" d="M0 0h35v19H0z"/></clipPath></defs></svg>', this.Xd.toggleAttribute("data-dark", "dark" === this.Gd), this.Jd.appendChild(this.Kd), this.Jd.appendChild(this.Xd)));
  }
}
function gM(t2, e2) {
  const i2 = uk(t2.ownerDocument).createElement("canvas");
  t2.appendChild(i2);
  const s2 = (n2 = { options: { allowResizeObserver: false }, transform: (t3, e3) => ({ width: Math.max(t3.width, e3.width), height: Math.max(t3.height, e3.height) }) }, new Ux(i2, n2.transform, n2.options));
  var n2;
  return s2.resizeCanvasElement(e2), s2;
}
function vM(t2) {
  var e2;
  t2.width = 1, t2.height = 1, null === (e2 = t2.getContext("2d")) || void 0 === e2 || e2.clearRect(0, 0, 1, 1);
}
function bM(t2, e2, i2, s2) {
  t2.gl && t2.gl(e2, i2, s2);
}
function _M(t2, e2, i2, s2) {
  t2.X(e2, i2, s2);
}
function yM(t2, e2, i2, s2) {
  const n2 = t2(i2, s2);
  for (const t3 of n2) {
    const i3 = t3.gt();
    null !== i3 && e2(i3);
  }
}
class ps {
  constructor(t2, e2, i2) {
    this.hf = 0, this.lf = null, this.af = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY }, this._f = 0, this.uf = null, this.cf = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY }, this.df = null, this.ff = false, this.vf = null, this.pf = null, this.mf = false, this.bf = false, this.wf = false, this.gf = null, this.Mf = null, this.xf = null, this.Sf = null, this.kf = null, this.yf = null, this.Cf = null, this.Tf = 0, this.Pf = false, this.Rf = false, this.Df = false, this.Vf = 0, this.Of = null, this.Bf = !dM(), this.Af = (t3) => {
      this.If(t3);
    }, this.zf = (t3) => {
      if (this.Lf(t3)) {
        const e3 = this.Ef(t3);
        if (++this._f, this.uf && this._f > 1) {
          const { Nf: i3 } = this.Ff(kM(t3), this.cf);
          i3 < 30 && !this.wf && this.Wf(e3, this.Hf.jf), this.$f();
        }
      } else {
        const e3 = this.Ef(t3);
        if (++this.hf, this.lf && this.hf > 1) {
          const { Nf: i3 } = this.Ff(kM(t3), this.af);
          i3 < 5 && !this.bf && this.Uf(e3, this.Hf.qf), this.Yf();
        }
      }
    }, this.Zf = t2, this.Hf = e2, this.cn = i2, this.Xf();
  }
  S() {
    null !== this.gf && (this.gf(), this.gf = null), null !== this.Mf && (this.Mf(), this.Mf = null), null !== this.Sf && (this.Sf(), this.Sf = null), null !== this.kf && (this.kf(), this.kf = null), null !== this.yf && (this.yf(), this.yf = null), null !== this.xf && (this.xf(), this.xf = null), this.Kf(), this.Yf();
  }
  Gf(t2) {
    this.Sf && this.Sf();
    const e2 = this.Jf.bind(this);
    if (this.Sf = () => {
      this.Zf.removeEventListener("mousemove", e2);
    }, this.Zf.addEventListener("mousemove", e2), this.Lf(t2)) return;
    const i2 = this.Ef(t2);
    this.Uf(i2, this.Hf.Qf), this.Bf = true;
  }
  Yf() {
    null !== this.lf && clearTimeout(this.lf), this.hf = 0, this.lf = null, this.af = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY };
  }
  $f() {
    null !== this.uf && clearTimeout(this.uf), this._f = 0, this.uf = null, this.cf = { nt: Number.NEGATIVE_INFINITY, st: Number.POSITIVE_INFINITY };
  }
  Jf(t2) {
    if (this.Df || null !== this.pf) return;
    if (this.Lf(t2)) return;
    const e2 = this.Ef(t2);
    this.Uf(e2, this.Hf.tv), this.Bf = true;
  }
  iv(t2) {
    const e2 = MM(t2.changedTouches, uk(this.Of));
    if (null === e2) return;
    if (this.Vf = SM(t2), null !== this.Cf) return;
    if (this.Rf) return;
    this.Pf = true;
    const i2 = this.Ff(kM(e2), uk(this.pf)), { nv: s2, sv: n2, Nf: r2 } = i2;
    if (this.mf || !(r2 < 5)) {
      if (!this.mf) {
        const t3 = 0.5 * s2, e3 = n2 >= t3 && !this.cn.ev(), i3 = t3 > n2 && !this.cn.rv();
        e3 || i3 || (this.Rf = true), this.mf = true, this.wf = true, this.Kf(), this.$f();
      }
      if (!this.Rf) {
        const i3 = this.Ef(t2, e2);
        this.Wf(i3, this.Hf.hv), xM(t2);
      }
    }
  }
  lv(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Ff(kM(t2), uk(this.vf)), { Nf: i2 } = e2;
    if (i2 >= 5 && (this.bf = true, this.Yf()), this.bf) {
      const e3 = this.Ef(t2);
      this.Uf(e3, this.Hf.av);
    }
  }
  Ff(t2, e2) {
    const i2 = Math.abs(e2.nt - t2.nt), s2 = Math.abs(e2.st - t2.st);
    return { nv: i2, sv: s2, Nf: i2 + s2 };
  }
  ov(t2) {
    let e2 = MM(t2.changedTouches, uk(this.Of));
    if (null === e2 && 0 === t2.touches.length && (e2 = t2.changedTouches[0]), null === e2) return;
    this.Of = null, this.Vf = SM(t2), this.Kf(), this.pf = null, this.yf && (this.yf(), this.yf = null);
    const i2 = this.Ef(t2, e2);
    if (this.Wf(i2, this.Hf._v), ++this._f, this.uf && this._f > 1) {
      const { Nf: t3 } = this.Ff(kM(e2), this.cf);
      t3 < 30 && !this.wf && this.Wf(i2, this.Hf.jf), this.$f();
    } else this.wf || (this.Wf(i2, this.Hf.uv), this.Hf.uv && xM(t2));
    0 === this._f && xM(t2), 0 === t2.touches.length && this.ff && (this.ff = false, xM(t2));
  }
  If(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Ef(t2);
    if (this.vf = null, this.Df = false, this.kf && (this.kf(), this.kf = null), uM() && this.Zf.ownerDocument.documentElement.removeEventListener("mouseleave", this.Af), !this.Lf(t2)) if (this.Uf(e2, this.Hf.cv), ++this.hf, this.lf && this.hf > 1) {
      const { Nf: i2 } = this.Ff(kM(t2), this.af);
      i2 < 5 && !this.bf && this.Uf(e2, this.Hf.qf), this.Yf();
    } else this.bf || this.Uf(e2, this.Hf.dv);
  }
  Kf() {
    null !== this.df && (clearTimeout(this.df), this.df = null);
  }
  fv(t2) {
    if (null !== this.Of) return;
    const e2 = t2.changedTouches[0];
    this.Of = e2.identifier, this.Vf = SM(t2);
    const i2 = this.Zf.ownerDocument.documentElement;
    this.wf = false, this.mf = false, this.Rf = false, this.pf = kM(e2), this.yf && (this.yf(), this.yf = null);
    {
      const e3 = this.iv.bind(this), s3 = this.ov.bind(this);
      this.yf = () => {
        i2.removeEventListener("touchmove", e3), i2.removeEventListener("touchend", s3);
      }, i2.addEventListener("touchmove", e3, { passive: false }), i2.addEventListener("touchend", s3, { passive: false }), this.Kf(), this.df = setTimeout(this.vv.bind(this, t2), 240);
    }
    const s2 = this.Ef(t2, e2);
    this.Wf(s2, this.Hf.pv), this.uf || (this._f = 0, this.uf = setTimeout(this.$f.bind(this), 500), this.cf = kM(e2));
  }
  mv(t2) {
    if (0 !== t2.button) return;
    const e2 = this.Zf.ownerDocument.documentElement;
    uM() && e2.addEventListener("mouseleave", this.Af), this.bf = false, this.vf = kM(t2), this.kf && (this.kf(), this.kf = null);
    {
      const t3 = this.lv.bind(this), i3 = this.If.bind(this);
      this.kf = () => {
        e2.removeEventListener("mousemove", t3), e2.removeEventListener("mouseup", i3);
      }, e2.addEventListener("mousemove", t3), e2.addEventListener("mouseup", i3);
    }
    if (this.Df = true, this.Lf(t2)) return;
    const i2 = this.Ef(t2);
    this.Uf(i2, this.Hf.bv), this.lf || (this.hf = 0, this.lf = setTimeout(this.Yf.bind(this), 500), this.af = kM(t2));
  }
  Xf() {
    this.Zf.addEventListener("mouseenter", this.Gf.bind(this)), this.Zf.addEventListener("touchcancel", this.Kf.bind(this));
    {
      const t2 = this.Zf.ownerDocument, e2 = (t3) => {
        this.Hf.wv && (t3.composed && this.Zf.contains(t3.composedPath()[0]) || t3.target && this.Zf.contains(t3.target) || this.Hf.wv());
      };
      this.Mf = () => {
        t2.removeEventListener("touchstart", e2);
      }, this.gf = () => {
        t2.removeEventListener("mousedown", e2);
      }, t2.addEventListener("mousedown", e2), t2.addEventListener("touchstart", e2, { passive: true });
    }
    dM() && (this.xf = () => {
      this.Zf.removeEventListener("dblclick", this.zf);
    }, this.Zf.addEventListener("dblclick", this.zf)), this.Zf.addEventListener("mouseleave", this.gv.bind(this)), this.Zf.addEventListener("touchstart", this.fv.bind(this), { passive: true }), function(t2) {
      cM && void 0 !== window.chrome && t2.addEventListener("mousedown", (t3) => {
        if (1 === t3.button) return t3.preventDefault(), false;
      });
    }(this.Zf), this.Zf.addEventListener("mousedown", this.mv.bind(this)), this.Mv(), this.Zf.addEventListener("touchmove", () => {
    }, { passive: false });
  }
  Mv() {
    void 0 === this.Hf.xv && void 0 === this.Hf.Sv && void 0 === this.Hf.kv || (this.Zf.addEventListener("touchstart", (t2) => this.yv(t2.touches), { passive: true }), this.Zf.addEventListener("touchmove", (t2) => {
      if (2 === t2.touches.length && null !== this.Cf && void 0 !== this.Hf.Sv) {
        const e2 = wM(t2.touches[0], t2.touches[1]) / this.Tf;
        this.Hf.Sv(this.Cf, e2), xM(t2);
      }
    }, { passive: false }), this.Zf.addEventListener("touchend", (t2) => {
      this.yv(t2.touches);
    }));
  }
  yv(t2) {
    1 === t2.length && (this.Pf = false), 2 !== t2.length || this.Pf || this.ff ? this.Cv() : this.Tv(t2);
  }
  Tv(t2) {
    const e2 = this.Zf.getBoundingClientRect() || { left: 0, top: 0 };
    this.Cf = { nt: (t2[0].clientX - e2.left + (t2[1].clientX - e2.left)) / 2, st: (t2[0].clientY - e2.top + (t2[1].clientY - e2.top)) / 2 }, this.Tf = wM(t2[0], t2[1]), void 0 !== this.Hf.xv && this.Hf.xv(), this.Kf();
  }
  Cv() {
    null !== this.Cf && (this.Cf = null, void 0 !== this.Hf.kv && this.Hf.kv());
  }
  gv(t2) {
    if (this.Sf && this.Sf(), this.Lf(t2)) return;
    if (!this.Bf) return;
    const e2 = this.Ef(t2);
    this.Uf(e2, this.Hf.Pv), this.Bf = !dM();
  }
  vv(t2) {
    const e2 = MM(t2.touches, uk(this.Of));
    if (null === e2) return;
    const i2 = this.Ef(t2, e2);
    this.Wf(i2, this.Hf.Rv), this.wf = true, this.ff = true;
  }
  Lf(t2) {
    return t2.sourceCapabilities && void 0 !== t2.sourceCapabilities.firesTouchEvents ? t2.sourceCapabilities.firesTouchEvents : SM(t2) < this.Vf + 500;
  }
  Wf(t2, e2) {
    e2 && e2.call(this.Hf, t2);
  }
  Uf(t2, e2) {
    e2 && e2.call(this.Hf, t2);
  }
  Ef(t2, e2) {
    const i2 = e2 || t2, s2 = this.Zf.getBoundingClientRect() || { left: 0, top: 0 };
    return { clientX: i2.clientX, clientY: i2.clientY, pageX: i2.pageX, pageY: i2.pageY, screenX: i2.screenX, screenY: i2.screenY, localX: i2.clientX - s2.left, localY: i2.clientY - s2.top, ctrlKey: t2.ctrlKey, altKey: t2.altKey, shiftKey: t2.shiftKey, metaKey: t2.metaKey, Dv: !t2.type.startsWith("mouse") && "contextmenu" !== t2.type && "click" !== t2.type, Vv: t2.type, Ov: i2.target, Bv: t2.view, Av: () => {
      "touchstart" !== t2.type && xM(t2);
    } };
  }
}
function wM(t2, e2) {
  const i2 = t2.clientX - e2.clientX, s2 = t2.clientY - e2.clientY;
  return Math.sqrt(i2 * i2 + s2 * s2);
}
function xM(t2) {
  t2.cancelable && t2.preventDefault();
}
function kM(t2) {
  return { nt: t2.pageX, st: t2.pageY };
}
function SM(t2) {
  return t2.timeStamp || performance.now();
}
function MM(t2, e2) {
  for (let i2 = 0; i2 < t2.length; ++i2) if (t2[i2].identifier === e2) return t2[i2];
  return null;
}
function zM(t2) {
  return { Hc: t2.Hc, Iv: { gr: t2.zv.externalId }, Lv: t2.zv.cursorStyle };
}
function CM(t2, e2, i2) {
  for (const s2 of t2) {
    const t3 = s2.gt();
    if (null !== t3 && t3.wr) {
      const n2 = t3.wr(e2, i2);
      if (null !== n2) return { Bv: s2, Iv: n2 };
    }
  }
  return null;
}
function DM(t2, e2) {
  return (i2) => {
    var s2, n2, r2, o2;
    return (null !== (n2 = null === (s2 = i2.Dt()) || void 0 === s2 ? void 0 : s2.Pa()) && void 0 !== n2 ? n2 : "") !== e2 ? [] : null !== (o2 = null === (r2 = i2.da) || void 0 === r2 ? void 0 : r2.call(i2, t2)) && void 0 !== o2 ? o2 : [];
  };
}
function RM(t2, e2, i2, s2) {
  if (!t2.length) return;
  let n2 = 0;
  const r2 = i2 / 2, o2 = t2[0].At(s2, true);
  let a2 = 1 === e2 ? r2 - (t2[0].Vi() - o2 / 2) : t2[0].Vi() - o2 / 2 - r2;
  a2 = Math.max(0, a2);
  for (let r3 = 1; r3 < t2.length; r3++) {
    const o3 = t2[r3], l2 = t2[r3 - 1], h2 = l2.At(s2, false), c2 = o3.Vi(), u2 = l2.Vi();
    if (1 === e2 ? c2 > u2 - h2 : c2 < u2 + h2) {
      const s3 = u2 - h2 * e2;
      o3.Oi(s3);
      const r4 = s3 - e2 * h2 / 2;
      if ((1 === e2 ? r4 < 0 : r4 > i2) && a2 > 0) {
        const s4 = 1 === e2 ? -1 - r4 : r4 - i2, o4 = Math.min(s4, a2);
        for (let i3 = n2; i3 < t2.length; i3++) t2[i3].Oi(t2[i3].Vi() + e2 * o4);
        a2 -= o4;
      }
    } else n2 = r3, a2 = 1 === e2 ? u2 - h2 - c2 : c2 - (u2 + h2);
  }
}
class Cs {
  constructor(t2, e2, i2, s2) {
    this.Li = null, this.Ev = null, this.Nv = false, this.Fv = new ni(200), this.Qr = null, this.Wv = 0, this.jv = false, this.Hv = () => {
      this.jv || this.tn.$v().$t().Uh();
    }, this.Uv = () => {
      this.jv || this.tn.$v().$t().Uh();
    }, this.tn = t2, this.cn = e2, this.ko = e2.layout, this.Oc = i2, this.qv = "left" === s2, this.Yv = DM("normal", s2), this.Zv = DM("top", s2), this.Xv = DM("bottom", s2), this.Kv = document.createElement("div"), this.Kv.style.height = "100%", this.Kv.style.overflow = "hidden", this.Kv.style.width = "25px", this.Kv.style.left = "0", this.Kv.style.position = "relative", this.Gv = gM(this.Kv, jx({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const n2 = this.Gv.canvasElement;
    n2.style.position = "absolute", n2.style.zIndex = "1", n2.style.left = "0", n2.style.top = "0", this.Jv = gM(this.Kv, jx({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const r2 = this.Jv.canvasElement;
    r2.style.position = "absolute", r2.style.zIndex = "2", r2.style.left = "0", r2.style.top = "0";
    const o2 = { bv: this.Qv.bind(this), pv: this.Qv.bind(this), av: this.tp.bind(this), hv: this.tp.bind(this), wv: this.ip.bind(this), cv: this.np.bind(this), _v: this.np.bind(this), qf: this.sp.bind(this), jf: this.sp.bind(this), Qf: this.ep.bind(this), Pv: this.rp.bind(this) };
    this.hp = new ps(this.Jv.canvasElement, o2, { ev: () => !this.cn.handleScroll.vertTouchDrag, rv: () => true });
  }
  S() {
    this.hp.S(), this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), vM(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), vM(this.Gv.canvasElement), this.Gv.dispose(), null !== this.Li && this.Li.Ko().p(this), this.Li = null;
  }
  lp() {
    return this.Kv;
  }
  P() {
    return this.ko.fontSize;
  }
  ap() {
    const t2 = this.Oc.W();
    return this.Qr !== t2.R && (this.Fv.nr(), this.Qr = t2.R), t2;
  }
  op() {
    if (null === this.Li) return 0;
    let t2 = 0;
    const e2 = this.ap(), i2 = uk(this.Gv.canvasElement.getContext("2d"));
    i2.save();
    const s2 = this.Li.Ha();
    i2.font = this._p(), s2.length > 0 && (t2 = Math.max(this.Fv.xi(i2, s2[0].so), this.Fv.xi(i2, s2[s2.length - 1].so)));
    const n2 = this.up();
    for (let e3 = n2.length; e3--; ) {
      const s3 = this.Fv.xi(i2, n2[e3].Kt());
      s3 > t2 && (t2 = s3);
    }
    const r2 = this.Li.Ct();
    if (null !== r2 && null !== this.Ev && 2 !== (o2 = this.cn.crosshair).mode && o2.horzLine.visible && o2.horzLine.labelVisible) {
      const e3 = this.Li.pn(1, r2), s3 = this.Li.pn(this.Ev.height - 2, r2);
      t2 = Math.max(t2, this.Fv.xi(i2, this.Li.Fi(Math.floor(Math.min(e3, s3)) + 0.11111111111111, r2)), this.Fv.xi(i2, this.Li.Fi(Math.ceil(Math.max(e3, s3)) - 0.11111111111111, r2)));
    }
    var o2;
    i2.restore();
    const a2 = t2 || 34;
    return fM(Math.ceil(e2.C + e2.T + e2.A + e2.I + 5 + a2));
  }
  cp(t2) {
    null !== this.Ev && qx(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`);
  }
  dp() {
    return uk(this.Ev).width;
  }
  Gi(t2) {
    this.Li !== t2 && (null !== this.Li && this.Li.Ko().p(this), this.Li = t2, t2.Ko().l(this.fo.bind(this), this));
  }
  Dt() {
    return this.Li;
  }
  nr() {
    const t2 = this.tn.fp();
    this.tn.$v().$t().E_(t2, uk(this.Dt()));
  }
  vp(t2) {
    if (null === this.Ev) return;
    if (1 !== t2) {
      this.pp(), this.Gv.applySuggestedBitmapSize();
      const t3 = Gx(this.Gv);
      null !== t3 && (t3.useBitmapCoordinateSpace((t4) => {
        this.mp(t4), this.Ie(t4);
      }), this.tn.bp(t3, this.Xv), this.wp(t3), this.tn.bp(t3, this.Yv), this.gp(t3));
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = Gx(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.Mp(e2), this.tn.bp(e2, this.Zv));
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  bt() {
    var t2;
    null === (t2 = this.Li) || void 0 === t2 || t2.Ha();
  }
  Qv(t2) {
    if (null === this.Li || this.Li.Ni() || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp();
    this.Nv = true, e2.V_(i2, this.Li, t2.localY);
  }
  tp(t2) {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp(), s2 = this.Li;
    e2.O_(i2, s2, t2.localY);
  }
  ip() {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const t2 = this.tn.$v().$t(), e2 = this.tn.fp(), i2 = this.Li;
    this.Nv && (this.Nv = false, t2.B_(e2, i2));
  }
  np(t2) {
    if (null === this.Li || !this.cn.handleScale.axisPressedMouseMove.price) return;
    const e2 = this.tn.$v().$t(), i2 = this.tn.fp();
    this.Nv = false, e2.B_(i2, this.Li);
  }
  sp(t2) {
    this.cn.handleScale.axisDoubleClickReset.price && this.nr();
  }
  ep(t2) {
    null !== this.Li && (!this.tn.$v().$t().W().handleScale.axisPressedMouseMove.price || this.Li.Mh() || this.Li.Oo() || this.kp(1));
  }
  rp(t2) {
    this.kp(0);
  }
  up() {
    const t2 = [], e2 = null === this.Li ? void 0 : this.Li;
    return ((i2) => {
      for (let s2 = 0; s2 < i2.length; ++s2) {
        const n2 = i2[s2].Rn(this.tn.fp(), e2);
        for (let e3 = 0; e3 < n2.length; e3++) t2.push(n2[e3]);
      }
    })(this.tn.fp().Uo()), t2;
  }
  mp({ context: t2, bitmapSize: e2 }) {
    const { width: i2, height: s2 } = e2, n2 = this.tn.fp().$t(), r2 = n2.q(), o2 = n2.bd();
    r2 === o2 ? Vk(t2, 0, 0, i2, s2, r2) : Nk(t2, 0, 0, i2, s2, r2, o2);
  }
  Ie({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2 }) {
    if (null === this.Ev || null === this.Li || !this.Li.W().borderVisible) return;
    t2.fillStyle = this.Li.W().borderColor;
    const s2 = Math.max(1, Math.floor(this.ap().C * i2));
    let n2;
    n2 = this.qv ? e2.width - s2 : 0, t2.fillRect(n2, 0, s2, e2.height);
  }
  wp(t2) {
    if (null === this.Ev || null === this.Li) return;
    const e2 = this.Li.Ha(), i2 = this.Li.W(), s2 = this.ap(), n2 = this.qv ? this.Ev.width - s2.T : 0;
    i2.borderVisible && i2.ticksVisible && t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: r2, verticalPixelRatio: o2 }) => {
      t3.fillStyle = i2.borderColor;
      const a2 = Math.max(1, Math.floor(o2)), l2 = Math.floor(0.5 * o2), h2 = Math.round(s2.T * r2);
      t3.beginPath();
      for (const i3 of e2) t3.rect(Math.floor(n2 * r2), Math.round(i3.Ea * o2) - l2, h2, a2);
      t3.fill();
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      var r2;
      t3.font = this._p(), t3.fillStyle = null !== (r2 = i2.textColor) && void 0 !== r2 ? r2 : this.ko.textColor, t3.textAlign = this.qv ? "right" : "left", t3.textBaseline = "middle";
      const o2 = this.qv ? Math.round(n2 - s2.A) : Math.round(n2 + s2.T + s2.A), a2 = e2.map((e3) => this.Fv.Mi(t3, e3.so));
      for (let i3 = e2.length; i3--; ) {
        const s3 = e2[i3];
        t3.fillText(s3.so, o2, s3.Ea + a2[i3]);
      }
    });
  }
  pp() {
    if (null === this.Ev || null === this.Li) return;
    const t2 = [], e2 = this.Li.Uo().slice(), i2 = this.tn.fp(), s2 = this.ap();
    this.Li === i2.pr() && this.tn.fp().Uo().forEach((t3) => {
      i2.vr(t3) && e2.push(t3);
    });
    const n2 = this.Li;
    e2.forEach((e3) => {
      e3.Rn(i2, n2).forEach((e4) => {
        e4.Oi(null), e4.Bi() && t2.push(e4);
      });
    }), t2.forEach((t3) => t3.Oi(t3.ki())), this.Li.W().alignLabels && this.yp(t2, s2);
  }
  yp(t2, e2) {
    if (null === this.Ev) return;
    const i2 = this.Ev.height / 2, s2 = t2.filter((t3) => t3.ki() <= i2), n2 = t2.filter((t3) => t3.ki() > i2);
    s2.sort((t3, e3) => e3.ki() - t3.ki()), n2.sort((t3, e3) => t3.ki() - e3.ki());
    for (const i3 of t2) {
      const t3 = Math.floor(i3.At(e2) / 2), s3 = i3.ki();
      s3 > -t3 && s3 < t3 && i3.Oi(t3), s3 > this.Ev.height - t3 && s3 < this.Ev.height + t3 && i3.Oi(this.Ev.height - t3);
    }
    RM(s2, 1, this.Ev.height, e2), RM(n2, -1, this.Ev.height, e2);
  }
  gp(t2) {
    if (null === this.Ev) return;
    const e2 = this.up(), i2 = this.ap(), s2 = this.qv ? "right" : "left";
    e2.forEach((e3) => {
      e3.Ai() && e3.gt(uk(this.Li)).X(t2, i2, this.Fv, s2);
    });
  }
  Mp(t2) {
    if (null === this.Ev || null === this.Li) return;
    const e2 = this.tn.$v().$t(), i2 = [], s2 = this.tn.fp(), n2 = e2.Zc().Rn(s2, this.Li);
    n2.length && i2.push(n2);
    const r2 = this.ap(), o2 = this.qv ? "right" : "left";
    i2.forEach((e3) => {
      e3.forEach((e4) => {
        e4.gt(uk(this.Li)).X(t2, r2, this.Fv, o2);
      });
    });
  }
  kp(t2) {
    this.Kv.style.cursor = 1 === t2 ? "ns-resize" : "default";
  }
  fo() {
    const t2 = this.op();
    this.Wv < t2 && this.tn.$v().$t().Kl(), this.Wv = t2;
  }
  _p() {
    return $k(this.ko.fontSize, this.ko.fontFamily);
  }
}
function PM(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.ua) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function TM(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.Pn) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function $M(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.Ji) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
function EM(t2, e2) {
  var i2, s2;
  return null !== (s2 = null === (i2 = t2.aa) || void 0 === i2 ? void 0 : i2.call(t2, e2)) && void 0 !== s2 ? s2 : [];
}
class Vs {
  constructor(t2, e2) {
    this.Ev = jx({ width: 0, height: 0 }), this.Cp = null, this.Tp = null, this.Pp = null, this.Rp = null, this.Dp = false, this.Vp = new D(), this.Op = new D(), this.Bp = 0, this.Ap = false, this.Ip = null, this.zp = false, this.Lp = null, this.Ep = null, this.jv = false, this.Hv = () => {
      this.jv || null === this.Np || this.$i().Uh();
    }, this.Uv = () => {
      this.jv || null === this.Np || this.$i().Uh();
    }, this.Qd = t2, this.Np = e2, this.Np.W_().l(this.Fp.bind(this), this, true), this.Wp = document.createElement("td"), this.Wp.style.padding = "0", this.Wp.style.position = "relative";
    const i2 = document.createElement("div");
    i2.style.width = "100%", i2.style.height = "100%", i2.style.position = "relative", i2.style.overflow = "hidden", this.jp = document.createElement("td"), this.jp.style.padding = "0", this.Hp = document.createElement("td"), this.Hp.style.padding = "0", this.Wp.appendChild(i2), this.Gv = gM(i2, jx({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const s2 = this.Gv.canvasElement;
    s2.style.position = "absolute", s2.style.zIndex = "1", s2.style.left = "0", s2.style.top = "0", this.Jv = gM(i2, jx({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const n2 = this.Jv.canvasElement;
    n2.style.position = "absolute", n2.style.zIndex = "2", n2.style.left = "0", n2.style.top = "0", this.$p = document.createElement("tr"), this.$p.appendChild(this.jp), this.$p.appendChild(this.Wp), this.$p.appendChild(this.Hp), this.Up(), this.hp = new ps(this.Jv.canvasElement, this, { ev: () => null === this.Ip && !this.Qd.W().handleScroll.vertTouchDrag, rv: () => null === this.Ip && !this.Qd.W().handleScroll.horzTouchDrag });
  }
  S() {
    null !== this.Cp && this.Cp.S(), null !== this.Tp && this.Tp.S(), this.Pp = null, this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), vM(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), vM(this.Gv.canvasElement), this.Gv.dispose(), null !== this.Np && this.Np.W_().p(this), this.hp.S();
  }
  fp() {
    return uk(this.Np);
  }
  qp(t2) {
    var e2, i2;
    null !== this.Np && this.Np.W_().p(this), this.Np = t2, null !== this.Np && this.Np.W_().l(Vs.prototype.Fp.bind(this), this, true), this.Up(), this.Qd.Yp().indexOf(this) === this.Qd.Yp().length - 1 ? (this.Pp = null !== (e2 = this.Pp) && void 0 !== e2 ? e2 : new os(this.Wp, this.Qd), this.Pp.bt()) : (null === (i2 = this.Pp) || void 0 === i2 || i2.if(), this.Pp = null);
  }
  $v() {
    return this.Qd;
  }
  lp() {
    return this.$p;
  }
  Up() {
    if (null !== this.Np && (this.Zp(), 0 !== this.$i().wt().length)) {
      if (null !== this.Cp) {
        const t2 = this.Np.R_();
        this.Cp.Gi(uk(t2));
      }
      if (null !== this.Tp) {
        const t2 = this.Np.D_();
        this.Tp.Gi(uk(t2));
      }
    }
  }
  Xp() {
    null !== this.Cp && this.Cp.bt(), null !== this.Tp && this.Tp.bt();
  }
  M_() {
    return null !== this.Np ? this.Np.M_() : 0;
  }
  x_(t2) {
    this.Np && this.Np.x_(t2);
  }
  Qf(t2) {
    if (!this.Np) return;
    this.Kp();
    const e2 = t2.localX, i2 = t2.localY;
    this.Gp(e2, i2, t2);
  }
  bv(t2) {
    this.Kp(), this.Jp(), this.Gp(t2.localX, t2.localY, t2);
  }
  tv(t2) {
    var e2;
    if (!this.Np) return;
    this.Kp();
    const i2 = t2.localX, s2 = t2.localY;
    this.Gp(i2, s2, t2);
    const n2 = this.wr(i2, s2);
    this.Qd.Qp(null !== (e2 = null == n2 ? void 0 : n2.Lv) && void 0 !== e2 ? e2 : null), this.$i().jc(n2 && { Hc: n2.Hc, Iv: n2.Iv });
  }
  dv(t2) {
    null !== this.Np && (this.Kp(), this.tm(t2));
  }
  qf(t2) {
    null !== this.Np && this.im(this.Op, t2);
  }
  jf(t2) {
    this.qf(t2);
  }
  av(t2) {
    this.Kp(), this.nm(t2), this.Gp(t2.localX, t2.localY, t2);
  }
  cv(t2) {
    null !== this.Np && (this.Kp(), this.Ap = false, this.sm(t2));
  }
  uv(t2) {
    null !== this.Np && this.tm(t2);
  }
  Rv(t2) {
    if (this.Ap = true, null === this.Ip) {
      const e2 = { x: t2.localX, y: t2.localY };
      this.rm(e2, e2, t2);
    }
  }
  Pv(t2) {
    null !== this.Np && (this.Kp(), this.Np.$t().jc(null), this.hm());
  }
  lm() {
    return this.Vp;
  }
  am() {
    return this.Op;
  }
  xv() {
    this.Bp = 1, this.$i().Un();
  }
  Sv(t2, e2) {
    if (!this.Qd.W().handleScale.pinch) return;
    const i2 = 5 * (e2 - this.Bp);
    this.Bp = e2, this.$i().Qc(t2.nt, i2);
  }
  pv(t2) {
    this.Ap = false, this.zp = null !== this.Ip, this.Jp();
    const e2 = this.$i().Zc();
    null !== this.Ip && e2.yt() && (this.Lp = { x: e2.Yt(), y: e2.Zt() }, this.Ip = { x: t2.localX, y: t2.localY });
  }
  hv(t2) {
    if (null === this.Np) return;
    const e2 = t2.localX, i2 = t2.localY;
    if (null === this.Ip) this.nm(t2);
    else {
      this.zp = false;
      const s2 = uk(this.Lp), n2 = s2.x + (e2 - this.Ip.x), r2 = s2.y + (i2 - this.Ip.y);
      this.Gp(n2, r2, t2);
    }
  }
  _v(t2) {
    0 === this.$v().W().trackingMode.exitMode && (this.zp = true), this.om(), this.sm(t2);
  }
  wr(t2, e2) {
    const i2 = this.Np;
    return null === i2 ? null : function(t3, e3, i3) {
      const s2 = t3.Uo(), n2 = function(t4, e4, i4) {
        var s3, n3;
        let r2, o2;
        for (const h2 of t4) {
          const t5 = null !== (n3 = null === (s3 = h2.va) || void 0 === s3 ? void 0 : s3.call(h2, e4, i4)) && void 0 !== n3 ? n3 : [];
          for (const e5 of t5) a2 = e5.zOrder, (!(l2 = null == r2 ? void 0 : r2.zOrder) || "top" === a2 && "top" !== l2 || "normal" === a2 && "bottom" === l2) && (r2 = e5, o2 = h2);
        }
        var a2, l2;
        return r2 && o2 ? { zv: r2, Hc: o2 } : null;
      }(s2, e3, i3);
      if ("top" === (null == n2 ? void 0 : n2.zv.zOrder)) return zM(n2);
      for (const r2 of s2) {
        if (n2 && n2.Hc === r2 && "bottom" !== n2.zv.zOrder && !n2.zv.isBackground) return zM(n2);
        const s3 = CM(r2.Pn(t3), e3, i3);
        if (null !== s3) return { Hc: r2, Bv: s3.Bv, Iv: s3.Iv };
        if (n2 && n2.Hc === r2 && "bottom" !== n2.zv.zOrder && n2.zv.isBackground) return zM(n2);
      }
      return (null == n2 ? void 0 : n2.zv) ? zM(n2) : null;
    }(i2, t2, e2);
  }
  _m(t2, e2) {
    uk("left" === e2 ? this.Cp : this.Tp).cp(jx({ width: t2, height: this.Ev.height }));
  }
  um() {
    return this.Ev;
  }
  cp(t2) {
    qx(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Wp.style.width = t2.width + "px", this.Wp.style.height = t2.height + "px");
  }
  dm() {
    const t2 = uk(this.Np);
    t2.P_(t2.R_()), t2.P_(t2.D_());
    for (const e2 of t2.Ba()) if (t2.vr(e2)) {
      const i2 = e2.Dt();
      null !== i2 && t2.P_(i2), e2.Vn();
    }
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  vp(t2) {
    if (0 === t2) return;
    if (null === this.Np) return;
    if (t2 > 1 && this.dm(), null !== this.Cp && this.Cp.vp(t2), null !== this.Tp && this.Tp.vp(t2), 1 !== t2) {
      this.Gv.applySuggestedBitmapSize();
      const t3 = Gx(this.Gv);
      null !== t3 && (t3.useBitmapCoordinateSpace((t4) => {
        this.mp(t4);
      }), this.Np && (this.fm(t3, PM), this.vm(t3), this.pm(t3), this.fm(t3, TM), this.fm(t3, $M)));
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = Gx(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.bm(e2), this.fm(e2, EM));
  }
  wm() {
    return this.Cp;
  }
  gm() {
    return this.Tp;
  }
  bp(t2, e2) {
    this.fm(t2, e2);
  }
  Fp() {
    null !== this.Np && this.Np.W_().p(this), this.Np = null;
  }
  tm(t2) {
    this.im(this.Vp, t2);
  }
  im(t2, e2) {
    const i2 = e2.localX, s2 = e2.localY;
    t2.M() && t2.m(this.$i().St().Nu(i2), { x: i2, y: s2 }, e2);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    const { width: i2, height: s2 } = e2, n2 = this.$i(), r2 = n2.q(), o2 = n2.bd();
    r2 === o2 ? Vk(t2, 0, 0, i2, s2, o2) : Nk(t2, 0, 0, i2, s2, r2, o2);
  }
  vm(t2) {
    const e2 = uk(this.Np).j_().qh().gt();
    null !== e2 && e2.X(t2, false);
  }
  pm(t2) {
    const e2 = this.$i().Yc();
    this.Mm(t2, TM, bM, e2), this.Mm(t2, TM, _M, e2);
  }
  bm(t2) {
    this.Mm(t2, TM, _M, this.$i().Zc());
  }
  fm(t2, e2) {
    const i2 = uk(this.Np).Uo();
    for (const s2 of i2) this.Mm(t2, e2, bM, s2);
    for (const s2 of i2) this.Mm(t2, e2, _M, s2);
  }
  Mm(t2, e2, i2, s2) {
    const n2 = uk(this.Np), r2 = n2.$t().Wc(), o2 = null !== r2 && r2.Hc === s2, a2 = null !== r2 && o2 && void 0 !== r2.Iv ? r2.Iv.Mr : void 0;
    yM(e2, (e3) => i2(e3, t2, o2, a2), s2, n2);
  }
  Zp() {
    if (null === this.Np) return;
    const t2 = this.Qd, e2 = this.Np.R_().W().visible, i2 = this.Np.D_().W().visible;
    e2 || null === this.Cp || (this.jp.removeChild(this.Cp.lp()), this.Cp.S(), this.Cp = null), i2 || null === this.Tp || (this.Hp.removeChild(this.Tp.lp()), this.Tp.S(), this.Tp = null);
    const s2 = t2.$t().ud();
    e2 && null === this.Cp && (this.Cp = new Cs(this, t2.W(), s2, "left"), this.jp.appendChild(this.Cp.lp())), i2 && null === this.Tp && (this.Tp = new Cs(this, t2.W(), s2, "right"), this.Hp.appendChild(this.Tp.lp()));
  }
  xm(t2) {
    return t2.Dv && this.Ap || null !== this.Ip;
  }
  Sm(t2) {
    return Math.max(0, Math.min(t2, this.Ev.width - 1));
  }
  km(t2) {
    return Math.max(0, Math.min(t2, this.Ev.height - 1));
  }
  Gp(t2, e2, i2) {
    this.$i().ld(this.Sm(t2), this.km(e2), i2, uk(this.Np));
  }
  hm() {
    this.$i().od();
  }
  om() {
    this.zp && (this.Ip = null, this.hm());
  }
  rm(t2, e2, i2) {
    this.Ip = t2, this.zp = false, this.Gp(e2.x, e2.y, i2);
    const s2 = this.$i().Zc();
    this.Lp = { x: s2.Yt(), y: s2.Zt() };
  }
  $i() {
    return this.Qd.$t();
  }
  sm(t2) {
    if (!this.Dp) return;
    const e2 = this.$i(), i2 = this.fp();
    if (e2.z_(i2, i2.vn()), this.Rp = null, this.Dp = false, e2.ed(), null !== this.Ep) {
      const t3 = performance.now(), i3 = e2.St();
      this.Ep.Vr(i3.Hu(), t3), this.Ep.Qu(t3) || e2.Zn(this.Ep);
    }
  }
  Kp() {
    this.Ip = null;
  }
  Jp() {
    if (this.Np) {
      if (this.$i().Un(), document.activeElement !== document.body && document.activeElement !== document.documentElement) uk(document.activeElement).blur();
      else {
        const t2 = document.getSelection();
        null !== t2 && t2.removeAllRanges();
      }
      !this.Np.vn().Ni() && this.$i().St().Ni();
    }
  }
  nm(t2) {
    if (null === this.Np) return;
    const e2 = this.$i(), i2 = e2.St();
    if (i2.Ni()) return;
    const s2 = this.Qd.W(), n2 = s2.handleScroll, r2 = s2.kineticScroll;
    if ((!n2.pressedMouseMove || t2.Dv) && (!n2.horzTouchDrag && !n2.vertTouchDrag || !t2.Dv)) return;
    const o2 = this.Np.vn(), a2 = performance.now();
    if (null !== this.Rp || this.xm(t2) || (this.Rp = { x: t2.clientX, y: t2.clientY, Od: a2, ym: t2.localX, Cm: t2.localY }), null !== this.Rp && !this.Dp && (this.Rp.x !== t2.clientX || this.Rp.y !== t2.clientY)) {
      if (t2.Dv && r2.touch || !t2.Dv && r2.mouse) {
        const t3 = i2.le();
        this.Ep = new as(0.2 / t3, 7 / t3, 0.997, 15 / t3), this.Ep.Yd(i2.Hu(), this.Rp.Od);
      } else this.Ep = null;
      o2.Ni() || e2.A_(this.Np, o2, t2.localY), e2.nd(t2.localX), this.Dp = true;
    }
    this.Dp && (o2.Ni() || e2.I_(this.Np, o2, t2.localY), e2.sd(t2.localX), null !== this.Ep && this.Ep.Yd(i2.Hu(), a2));
  }
}
class Os {
  constructor(t2, e2, i2, s2, n2) {
    this.ft = true, this.Ev = jx({ width: 0, height: 0 }), this.Hv = () => this.vp(3), this.qv = "left" === t2, this.Oc = i2.ud, this.cn = e2, this.Tm = s2, this.Pm = n2, this.Kv = document.createElement("div"), this.Kv.style.width = "25px", this.Kv.style.height = "100%", this.Kv.style.overflow = "hidden", this.Gv = gM(this.Kv, jx({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
  }
  S() {
    this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), vM(this.Gv.canvasElement), this.Gv.dispose();
  }
  lp() {
    return this.Kv;
  }
  um() {
    return this.Ev;
  }
  cp(t2) {
    qx(this.Ev, t2) || (this.Ev = t2, this.Gv.resizeCanvasElement(t2), this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`, this.ft = true);
  }
  vp(t2) {
    if (t2 < 3 && !this.ft) return;
    if (0 === this.Ev.width || 0 === this.Ev.height) return;
    this.ft = false, this.Gv.applySuggestedBitmapSize();
    const e2 = Gx(this.Gv);
    null !== e2 && e2.useBitmapCoordinateSpace((t3) => {
      this.mp(t3), this.Ie(t3);
    });
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  Ie({ context: t2, bitmapSize: e2, horizontalPixelRatio: i2, verticalPixelRatio: s2 }) {
    if (!this.Tm()) return;
    t2.fillStyle = this.cn.timeScale.borderColor;
    const n2 = Math.floor(this.Oc.W().C * i2), r2 = Math.floor(this.Oc.W().C * s2), o2 = this.qv ? e2.width - n2 : 0;
    t2.fillRect(o2, 0, n2, r2);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    Vk(t2, 0, 0, e2.width, e2.height, this.Pm());
  }
}
function AM(t2) {
  return (e2) => {
    var i2, s2;
    return null !== (s2 = null === (i2 = e2.fa) || void 0 === i2 ? void 0 : i2.call(e2, t2)) && void 0 !== s2 ? s2 : [];
  };
}
const LM = AM("normal"), VM = AM("top"), OM = AM("bottom");
class Ls {
  constructor(t2, e2) {
    this.Rm = null, this.Dm = null, this.k = null, this.Vm = false, this.Ev = jx({ width: 0, height: 0 }), this.Om = new D(), this.Fv = new ni(5), this.jv = false, this.Hv = () => {
      this.jv || this.Qd.$t().Uh();
    }, this.Uv = () => {
      this.jv || this.Qd.$t().Uh();
    }, this.Qd = t2, this.q_ = e2, this.cn = t2.W().layout, this.Xd = document.createElement("tr"), this.Bm = document.createElement("td"), this.Bm.style.padding = "0", this.Am = document.createElement("td"), this.Am.style.padding = "0", this.Kv = document.createElement("td"), this.Kv.style.height = "25px", this.Kv.style.padding = "0", this.Im = document.createElement("div"), this.Im.style.width = "100%", this.Im.style.height = "100%", this.Im.style.position = "relative", this.Im.style.overflow = "hidden", this.Kv.appendChild(this.Im), this.Gv = gM(this.Im, jx({ width: 16, height: 16 })), this.Gv.subscribeSuggestedBitmapSizeChanged(this.Hv);
    const i2 = this.Gv.canvasElement;
    i2.style.position = "absolute", i2.style.zIndex = "1", i2.style.left = "0", i2.style.top = "0", this.Jv = gM(this.Im, jx({ width: 16, height: 16 })), this.Jv.subscribeSuggestedBitmapSizeChanged(this.Uv);
    const s2 = this.Jv.canvasElement;
    s2.style.position = "absolute", s2.style.zIndex = "2", s2.style.left = "0", s2.style.top = "0", this.Xd.appendChild(this.Bm), this.Xd.appendChild(this.Kv), this.Xd.appendChild(this.Am), this.zm(), this.Qd.$t().g_().l(this.zm.bind(this), this), this.hp = new ps(this.Jv.canvasElement, this, { ev: () => true, rv: () => !this.Qd.W().handleScroll.horzTouchDrag });
  }
  S() {
    this.hp.S(), null !== this.Rm && this.Rm.S(), null !== this.Dm && this.Dm.S(), this.Jv.unsubscribeSuggestedBitmapSizeChanged(this.Uv), vM(this.Jv.canvasElement), this.Jv.dispose(), this.Gv.unsubscribeSuggestedBitmapSizeChanged(this.Hv), vM(this.Gv.canvasElement), this.Gv.dispose();
  }
  lp() {
    return this.Xd;
  }
  Lm() {
    return this.Rm;
  }
  Em() {
    return this.Dm;
  }
  bv(t2) {
    if (this.Vm) return;
    this.Vm = true;
    const e2 = this.Qd.$t();
    !e2.St().Ni() && this.Qd.W().handleScale.axisPressedMouseMove.time && e2.Jc(t2.localX);
  }
  pv(t2) {
    this.bv(t2);
  }
  wv() {
    const t2 = this.Qd.$t();
    !t2.St().Ni() && this.Vm && (this.Vm = false, this.Qd.W().handleScale.axisPressedMouseMove.time && t2.hd());
  }
  av(t2) {
    const e2 = this.Qd.$t();
    !e2.St().Ni() && this.Qd.W().handleScale.axisPressedMouseMove.time && e2.rd(t2.localX);
  }
  hv(t2) {
    this.av(t2);
  }
  cv() {
    this.Vm = false;
    const t2 = this.Qd.$t();
    t2.St().Ni() && !this.Qd.W().handleScale.axisPressedMouseMove.time || t2.hd();
  }
  _v() {
    this.cv();
  }
  qf() {
    this.Qd.W().handleScale.axisDoubleClickReset.time && this.Qd.$t().Kn();
  }
  jf() {
    this.qf();
  }
  Qf() {
    this.Qd.$t().W().handleScale.axisPressedMouseMove.time && this.kp(1);
  }
  Pv() {
    this.kp(0);
  }
  um() {
    return this.Ev;
  }
  Nm() {
    return this.Om;
  }
  Fm(t2, e2, i2) {
    qx(this.Ev, t2) || (this.Ev = t2, this.jv = true, this.Gv.resizeCanvasElement(t2), this.Jv.resizeCanvasElement(t2), this.jv = false, this.Kv.style.width = `${t2.width}px`, this.Kv.style.height = `${t2.height}px`, this.Om.m(t2)), null !== this.Rm && this.Rm.cp(jx({ width: e2, height: t2.height })), null !== this.Dm && this.Dm.cp(jx({ width: i2, height: t2.height }));
  }
  Wm() {
    const t2 = this.jm();
    return Math.ceil(t2.C + t2.T + t2.P + t2.L + t2.B + t2.Hm);
  }
  bt() {
    this.Qd.$t().St().Ha();
  }
  xp() {
    return this.Gv.bitmapSize;
  }
  Sp(t2, e2, i2) {
    const s2 = this.xp();
    s2.width > 0 && s2.height > 0 && t2.drawImage(this.Gv.canvasElement, e2, i2);
  }
  vp(t2) {
    if (0 === t2) return;
    if (1 !== t2) {
      this.Gv.applySuggestedBitmapSize();
      const e3 = Gx(this.Gv);
      null !== e3 && (e3.useBitmapCoordinateSpace((t3) => {
        this.mp(t3), this.Ie(t3), this.$m(e3, OM);
      }), this.wp(e3), this.$m(e3, LM)), null !== this.Rm && this.Rm.vp(t2), null !== this.Dm && this.Dm.vp(t2);
    }
    this.Jv.applySuggestedBitmapSize();
    const e2 = Gx(this.Jv);
    null !== e2 && (e2.useBitmapCoordinateSpace(({ context: t3, bitmapSize: e3 }) => {
      t3.clearRect(0, 0, e3.width, e3.height);
    }), this.Um([...this.Qd.$t().wt(), this.Qd.$t().Zc()], e2), this.$m(e2, VM));
  }
  $m(t2, e2) {
    const i2 = this.Qd.$t().wt();
    for (const s2 of i2) yM(e2, (e3) => bM(e3, t2, false, void 0), s2, void 0);
    for (const s2 of i2) yM(e2, (e3) => _M(e3, t2, false, void 0), s2, void 0);
  }
  mp({ context: t2, bitmapSize: e2 }) {
    Vk(t2, 0, 0, e2.width, e2.height, this.Qd.$t().bd());
  }
  Ie({ context: t2, bitmapSize: e2, verticalPixelRatio: i2 }) {
    if (this.Qd.W().timeScale.borderVisible) {
      t2.fillStyle = this.qm();
      const s2 = Math.max(1, Math.floor(this.jm().C * i2));
      t2.fillRect(0, 0, e2.width, s2);
    }
  }
  wp(t2) {
    const e2 = this.Qd.$t().St(), i2 = e2.Ha();
    if (!i2 || 0 === i2.length) return;
    const s2 = this.q_.maxTickMarkWeight(i2), n2 = this.jm(), r2 = e2.W();
    r2.borderVisible && r2.ticksVisible && t2.useBitmapCoordinateSpace(({ context: t3, horizontalPixelRatio: e3, verticalPixelRatio: s3 }) => {
      t3.strokeStyle = this.qm(), t3.fillStyle = this.qm();
      const r3 = Math.max(1, Math.floor(e3)), o2 = Math.floor(0.5 * e3);
      t3.beginPath();
      const a2 = Math.round(n2.T * s3);
      for (let s4 = i2.length; s4--; ) {
        const n3 = Math.round(i2[s4].coord * e3);
        t3.rect(n3 - o2, 0, r3, a2);
      }
      t3.fill();
    }), t2.useMediaCoordinateSpace(({ context: t3 }) => {
      const e3 = n2.C + n2.T + n2.L + n2.P / 2;
      t3.textAlign = "center", t3.textBaseline = "middle", t3.fillStyle = this.$(), t3.font = this._p();
      for (const n3 of i2) if (n3.weight < s2) {
        const i3 = n3.needAlignCoordinate ? this.Ym(t3, n3.coord, n3.label) : n3.coord;
        t3.fillText(n3.label, i3, e3);
      }
      this.Qd.W().timeScale.allowBoldLabels && (t3.font = this.Zm());
      for (const n3 of i2) if (n3.weight >= s2) {
        const i3 = n3.needAlignCoordinate ? this.Ym(t3, n3.coord, n3.label) : n3.coord;
        t3.fillText(n3.label, i3, e3);
      }
    });
  }
  Ym(t2, e2, i2) {
    const s2 = this.Fv.xi(t2, i2), n2 = s2 / 2, r2 = Math.floor(e2 - n2) + 0.5;
    return r2 < 0 ? e2 += Math.abs(0 - r2) : r2 + s2 > this.Ev.width && (e2 -= Math.abs(this.Ev.width - (r2 + s2))), e2;
  }
  Um(t2, e2) {
    const i2 = this.jm();
    for (const s2 of t2) for (const t3 of s2.Qi()) t3.gt().X(e2, i2);
  }
  qm() {
    return this.Qd.W().timeScale.borderColor;
  }
  $() {
    return this.cn.textColor;
  }
  j() {
    return this.cn.fontSize;
  }
  _p() {
    return $k(this.j(), this.cn.fontFamily);
  }
  Zm() {
    return $k(this.j(), this.cn.fontFamily, "bold");
  }
  jm() {
    null === this.k && (this.k = { C: 1, N: NaN, L: NaN, B: NaN, ji: NaN, T: 5, P: NaN, R: "", Wi: new ni(), Hm: 0 });
    const t2 = this.k, e2 = this._p();
    if (t2.R !== e2) {
      const i2 = this.j();
      t2.P = i2, t2.R = e2, t2.L = 3 * i2 / 12, t2.B = 3 * i2 / 12, t2.ji = 9 * i2 / 12, t2.N = 0, t2.Hm = 4 * i2 / 12, t2.Wi.nr();
    }
    return this.k;
  }
  kp(t2) {
    this.Kv.style.cursor = 1 === t2 ? "ew-resize" : "default";
  }
  zm() {
    const t2 = this.Qd.$t(), e2 = t2.W();
    e2.leftPriceScale.visible || null === this.Rm || (this.Bm.removeChild(this.Rm.lp()), this.Rm.S(), this.Rm = null), e2.rightPriceScale.visible || null === this.Dm || (this.Am.removeChild(this.Dm.lp()), this.Dm.S(), this.Dm = null);
    const i2 = { ud: this.Qd.$t().ud() }, s2 = () => e2.leftPriceScale.borderVisible && t2.St().W().borderVisible, n2 = () => t2.bd();
    e2.leftPriceScale.visible && null === this.Rm && (this.Rm = new Os("left", e2, i2, s2, n2), this.Bm.appendChild(this.Rm.lp())), e2.rightPriceScale.visible && null === this.Dm && (this.Dm = new Os("right", e2, i2, s2, n2), this.Am.appendChild(this.Dm.lp()));
  }
}
const IM = !!cM && !!navigator.userAgentData && navigator.userAgentData.brands.some((t2) => t2.brand.includes("Chromium")) && !!cM && ((null === (NM = null === navigator || void 0 === navigator ? void 0 : navigator.userAgentData) || void 0 === NM ? void 0 : NM.platform) ? "Windows" === navigator.userAgentData.platform : navigator.userAgent.toLowerCase().indexOf("win") >= 0);
var NM;
class Fs {
  constructor(t2, e2, i2) {
    var s2;
    this.Xm = [], this.Km = 0, this.ho = 0, this.__ = 0, this.Gm = 0, this.Jm = 0, this.Qm = null, this.tb = false, this.Vp = new D(), this.Op = new D(), this.Rc = new D(), this.ib = null, this.nb = null, this.Jd = t2, this.cn = e2, this.q_ = i2, this.Xd = document.createElement("div"), this.Xd.classList.add("tv-lightweight-charts"), this.Xd.style.overflow = "hidden", this.Xd.style.direction = "ltr", this.Xd.style.width = "100%", this.Xd.style.height = "100%", (s2 = this.Xd).style.userSelect = "none", s2.style.webkitUserSelect = "none", s2.style.msUserSelect = "none", s2.style.MozUserSelect = "none", s2.style.webkitTapHighlightColor = "transparent", this.sb = document.createElement("table"), this.sb.setAttribute("cellspacing", "0"), this.Xd.appendChild(this.sb), this.eb = this.rb.bind(this), FM(this.cn) && this.hb(true), this.$i = new Ln(this.Vc.bind(this), this.cn, i2), this.$t().Xc().l(this.lb.bind(this), this), this.ab = new Ls(this, this.q_), this.sb.appendChild(this.ab.lp());
    const n2 = e2.autoSize && this.ob();
    let r2 = this.cn.width, o2 = this.cn.height;
    if (n2 || 0 === r2 || 0 === o2) {
      const e3 = t2.getBoundingClientRect();
      r2 = r2 || e3.width, o2 = o2 || e3.height;
    }
    this._b(r2, o2), this.ub(), t2.appendChild(this.Xd), this.cb(), this.$i.St().ec().l(this.$i.Kl.bind(this.$i), this), this.$i.g_().l(this.$i.Kl.bind(this.$i), this);
  }
  $t() {
    return this.$i;
  }
  W() {
    return this.cn;
  }
  Yp() {
    return this.Xm;
  }
  fb() {
    return this.ab;
  }
  S() {
    this.hb(false), 0 !== this.Km && window.cancelAnimationFrame(this.Km), this.$i.Xc().p(this), this.$i.St().ec().p(this), this.$i.g_().p(this), this.$i.S();
    for (const t2 of this.Xm) this.sb.removeChild(t2.lp()), t2.lm().p(this), t2.am().p(this), t2.S();
    this.Xm = [], uk(this.ab).S(), null !== this.Xd.parentElement && this.Xd.parentElement.removeChild(this.Xd), this.Rc.S(), this.Vp.S(), this.Op.S(), this.pb();
  }
  _b(t2, e2, i2 = false) {
    if (this.ho === e2 && this.__ === t2) return;
    const s2 = function(t3) {
      const e3 = Math.floor(t3.width), i3 = Math.floor(t3.height);
      return jx({ width: e3 - e3 % 2, height: i3 - i3 % 2 });
    }(jx({ width: t2, height: e2 }));
    this.ho = s2.height, this.__ = s2.width;
    const n2 = this.ho + "px", r2 = this.__ + "px";
    uk(this.Xd).style.height = n2, uk(this.Xd).style.width = r2, this.sb.style.height = n2, this.sb.style.width = r2, i2 ? this.mb(ut.es(), performance.now()) : this.$i.Kl();
  }
  vp(t2) {
    void 0 === t2 && (t2 = ut.es());
    for (let e2 = 0; e2 < this.Xm.length; e2++) this.Xm[e2].vp(t2.Hn(e2).Fn);
    this.cn.timeScale.visible && this.ab.vp(t2.jn());
  }
  $h(t2) {
    const e2 = FM(this.cn);
    this.$i.$h(t2);
    const i2 = FM(this.cn);
    i2 !== e2 && this.hb(i2), this.cb(), this.bb(t2);
  }
  lm() {
    return this.Vp;
  }
  am() {
    return this.Op;
  }
  Xc() {
    return this.Rc;
  }
  wb() {
    null !== this.Qm && (this.mb(this.Qm, performance.now()), this.Qm = null);
    const t2 = this.gb(null), e2 = document.createElement("canvas");
    e2.width = t2.width, e2.height = t2.height;
    const i2 = uk(e2.getContext("2d"));
    return this.gb(i2), e2;
  }
  Mb(t2) {
    return "left" === t2 && !this.xb() || "right" === t2 && !this.Sb() || 0 === this.Xm.length ? 0 : uk("left" === t2 ? this.Xm[0].wm() : this.Xm[0].gm()).dp();
  }
  kb() {
    return this.cn.autoSize && null !== this.ib;
  }
  yb() {
    return this.Xd;
  }
  Qp(t2) {
    this.nb = t2, this.nb ? this.yb().style.setProperty("cursor", t2) : this.yb().style.removeProperty("cursor");
  }
  Cb() {
    return this.nb;
  }
  Tb() {
    return ck(this.Xm[0]).um();
  }
  bb(t2) {
    (void 0 !== t2.autoSize || !this.ib || void 0 === t2.width && void 0 === t2.height) && (t2.autoSize && !this.ib && this.ob(), false === t2.autoSize && null !== this.ib && this.pb(), t2.autoSize || void 0 === t2.width && void 0 === t2.height || this._b(t2.width || this.__, t2.height || this.ho));
  }
  gb(t2) {
    let e2 = 0, i2 = 0;
    const s2 = this.Xm[0], n2 = (e3, i3) => {
      let s3 = 0;
      for (let n3 = 0; n3 < this.Xm.length; n3++) {
        const r3 = this.Xm[n3], o2 = uk("left" === e3 ? r3.wm() : r3.gm()), a2 = o2.xp();
        null !== t2 && o2.Sp(t2, i3, s3), s3 += a2.height;
      }
    };
    this.xb() && (n2("left", 0), e2 += uk(s2.wm()).xp().width);
    for (let s3 = 0; s3 < this.Xm.length; s3++) {
      const n3 = this.Xm[s3], r3 = n3.xp();
      null !== t2 && n3.Sp(t2, e2, i2), i2 += r3.height;
    }
    e2 += s2.xp().width, this.Sb() && (n2("right", e2), e2 += uk(s2.gm()).xp().width);
    const r2 = (e3, i3, s3) => {
      uk("left" === e3 ? this.ab.Lm() : this.ab.Em()).Sp(uk(t2), i3, s3);
    };
    if (this.cn.timeScale.visible) {
      const e3 = this.ab.xp();
      if (null !== t2) {
        let n3 = 0;
        this.xb() && (r2("left", n3, i2), n3 = uk(s2.wm()).xp().width), this.ab.Sp(t2, n3, i2), n3 += e3.width, this.Sb() && r2("right", n3, i2);
      }
      i2 += e3.height;
    }
    return jx({ width: e2, height: i2 });
  }
  Pb() {
    let t2 = 0, e2 = 0, i2 = 0;
    for (const s3 of this.Xm) this.xb() && (e2 = Math.max(e2, uk(s3.wm()).op(), this.cn.leftPriceScale.minimumWidth)), this.Sb() && (i2 = Math.max(i2, uk(s3.gm()).op(), this.cn.rightPriceScale.minimumWidth)), t2 += s3.M_();
    e2 = fM(e2), i2 = fM(i2);
    const s2 = this.__, n2 = this.ho, r2 = Math.max(s2 - e2 - i2, 0), o2 = this.cn.timeScale.visible;
    let a2 = o2 ? Math.max(this.ab.Wm(), this.cn.timeScale.minimumHeight) : 0;
    var l2;
    a2 = (l2 = a2) + l2 % 2;
    const h2 = 0 + a2, c2 = n2 < h2 ? 0 : n2 - h2, u2 = c2 / t2;
    let d2 = 0;
    for (let t3 = 0; t3 < this.Xm.length; ++t3) {
      const s3 = this.Xm[t3];
      s3.qp(this.$i.qc()[t3]);
      let n3 = 0, o3 = 0;
      o3 = t3 === this.Xm.length - 1 ? c2 - d2 : Math.round(s3.M_() * u2), n3 = Math.max(o3, 2), d2 += n3, s3.cp(jx({ width: r2, height: n3 })), this.xb() && s3._m(e2, "left"), this.Sb() && s3._m(i2, "right"), s3.fp() && this.$i.Kc(s3.fp(), n3);
    }
    this.ab.Fm(jx({ width: o2 ? r2 : 0, height: a2 }), o2 ? e2 : 0, o2 ? i2 : 0), this.$i.S_(r2), this.Gm !== e2 && (this.Gm = e2), this.Jm !== i2 && (this.Jm = i2);
  }
  hb(t2) {
    t2 ? this.Xd.addEventListener("wheel", this.eb, { passive: false }) : this.Xd.removeEventListener("wheel", this.eb);
  }
  Rb(t2) {
    switch (t2.deltaMode) {
      case t2.DOM_DELTA_PAGE:
        return 120;
      case t2.DOM_DELTA_LINE:
        return 32;
    }
    return IM ? 1 / window.devicePixelRatio : 1;
  }
  rb(t2) {
    if (!(0 !== t2.deltaX && this.cn.handleScroll.mouseWheel || 0 !== t2.deltaY && this.cn.handleScale.mouseWheel)) return;
    const e2 = this.Rb(t2), i2 = e2 * t2.deltaX / 100, s2 = -e2 * t2.deltaY / 100;
    if (t2.cancelable && t2.preventDefault(), 0 !== s2 && this.cn.handleScale.mouseWheel) {
      const e3 = Math.sign(s2) * Math.min(1, Math.abs(s2)), i3 = t2.clientX - this.Xd.getBoundingClientRect().left;
      this.$t().Qc(i3, e3);
    }
    0 !== i2 && this.cn.handleScroll.mouseWheel && this.$t().td(-80 * i2);
  }
  mb(t2, e2) {
    var i2;
    const s2 = t2.jn();
    3 === s2 && this.Db(), 3 !== s2 && 2 !== s2 || (this.Vb(t2), this.Ob(t2, e2), this.ab.bt(), this.Xm.forEach((t3) => {
      t3.Xp();
    }), 3 === (null === (i2 = this.Qm) || void 0 === i2 ? void 0 : i2.jn()) && (this.Qm.ts(t2), this.Db(), this.Vb(this.Qm), this.Ob(this.Qm, e2), t2 = this.Qm, this.Qm = null)), this.vp(t2);
  }
  Ob(t2, e2) {
    for (const i2 of t2.Qn()) this.ns(i2, e2);
  }
  Vb(t2) {
    const e2 = this.$i.qc();
    for (let i2 = 0; i2 < e2.length; i2++) t2.Hn(i2).Wn && e2[i2].N_();
  }
  ns(t2, e2) {
    const i2 = this.$i.St();
    switch (t2.qn) {
      case 0:
        i2.hc();
        break;
      case 1:
        i2.lc(t2.Vt);
        break;
      case 2:
        i2.Gn(t2.Vt);
        break;
      case 3:
        i2.Jn(t2.Vt);
        break;
      case 4:
        i2.qu();
        break;
      case 5:
        t2.Vt.Qu(e2) || i2.Jn(t2.Vt.tc(e2));
    }
  }
  Vc(t2) {
    null !== this.Qm ? this.Qm.ts(t2) : this.Qm = t2, this.tb || (this.tb = true, this.Km = window.requestAnimationFrame((t3) => {
      if (this.tb = false, this.Km = 0, null !== this.Qm) {
        const e2 = this.Qm;
        this.Qm = null, this.mb(e2, t3);
        for (const i2 of e2.Qn()) if (5 === i2.qn && !i2.Vt.Qu(t3)) {
          this.$t().Zn(i2.Vt);
          break;
        }
      }
    }));
  }
  Db() {
    this.ub();
  }
  ub() {
    const t2 = this.$i.qc(), e2 = t2.length, i2 = this.Xm.length;
    for (let t3 = e2; t3 < i2; t3++) {
      const t4 = ck(this.Xm.pop());
      this.sb.removeChild(t4.lp()), t4.lm().p(this), t4.am().p(this), t4.S();
    }
    for (let s2 = i2; s2 < e2; s2++) {
      const e3 = new Vs(this, t2[s2]);
      e3.lm().l(this.Bb.bind(this), this), e3.am().l(this.Ab.bind(this), this), this.Xm.push(e3), this.sb.insertBefore(e3.lp(), this.ab.lp());
    }
    for (let i3 = 0; i3 < e2; i3++) {
      const e3 = t2[i3], s2 = this.Xm[i3];
      s2.fp() !== e3 ? s2.qp(e3) : s2.Up();
    }
    this.cb(), this.Pb();
  }
  Ib(t2, e2, i2) {
    var s2;
    const n2 = /* @__PURE__ */ new Map();
    let r2;
    if (null !== t2 && this.$i.wt().forEach((e3) => {
      const i3 = e3.In().ll(t2);
      null !== i3 && n2.set(e3, i3);
    }), null !== t2) {
      const e3 = null === (s2 = this.$i.St().Ui(t2)) || void 0 === s2 ? void 0 : s2.originalTime;
      void 0 !== e3 && (r2 = e3);
    }
    const o2 = this.$t().Wc(), a2 = null !== o2 && o2.Hc instanceof Gi ? o2.Hc : void 0, l2 = null !== o2 && void 0 !== o2.Iv ? o2.Iv.gr : void 0;
    return { zb: r2, ee: null != t2 ? t2 : void 0, Lb: null != e2 ? e2 : void 0, Eb: a2, Nb: n2, Fb: l2, Wb: null != i2 ? i2 : void 0 };
  }
  Bb(t2, e2, i2) {
    this.Vp.m(() => this.Ib(t2, e2, i2));
  }
  Ab(t2, e2, i2) {
    this.Op.m(() => this.Ib(t2, e2, i2));
  }
  lb(t2, e2, i2) {
    this.Rc.m(() => this.Ib(t2, e2, i2));
  }
  cb() {
    const t2 = this.cn.timeScale.visible ? "" : "none";
    this.ab.lp().style.display = t2;
  }
  xb() {
    return this.Xm[0].fp().R_().W().visible;
  }
  Sb() {
    return this.Xm[0].fp().D_().W().visible;
  }
  ob() {
    return "ResizeObserver" in window && (this.ib = new ResizeObserver((t2) => {
      const e2 = t2.find((t3) => t3.target === this.Jd);
      e2 && this._b(e2.contentRect.width, e2.contentRect.height);
    }), this.ib.observe(this.Jd, { box: "border-box" }), true);
  }
  pb() {
    null !== this.ib && this.ib.disconnect(), this.ib = null;
  }
}
function FM(t2) {
  return Boolean(t2.handleScroll.mouseWheel || t2.handleScale.mouseWheel);
}
function WM(t2, e2) {
  var i2 = {};
  for (var s2 in t2) Object.prototype.hasOwnProperty.call(t2, s2) && e2.indexOf(s2) < 0 && (i2[s2] = t2[s2]);
  if (null != t2 && "function" == typeof Object.getOwnPropertySymbols) {
    var n2 = 0;
    for (s2 = Object.getOwnPropertySymbols(t2); n2 < s2.length; n2++) e2.indexOf(s2[n2]) < 0 && Object.prototype.propertyIsEnumerable.call(t2, s2[n2]) && (i2[s2[n2]] = t2[s2[n2]]);
  }
  return i2;
}
function BM(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.color && (r2.V = i2.color), r2;
}
function jM(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.lineColor && (r2.lt = i2.lineColor), void 0 !== i2.topColor && (r2.Ps = i2.topColor), void 0 !== i2.bottomColor && (r2.Rs = i2.bottomColor), r2;
}
function qM(t2, e2, i2, s2) {
  const n2 = i2.value, r2 = { ee: e2, ot: t2, Vt: [n2, n2, n2, n2], zb: s2 };
  return void 0 !== i2.topLineColor && (r2.Re = i2.topLineColor), void 0 !== i2.bottomLineColor && (r2.De = i2.bottomLineColor), void 0 !== i2.topFillColor1 && (r2.ke = i2.topFillColor1), void 0 !== i2.topFillColor2 && (r2.ye = i2.topFillColor2), void 0 !== i2.bottomFillColor1 && (r2.Ce = i2.bottomFillColor1), void 0 !== i2.bottomFillColor2 && (r2.Te = i2.bottomFillColor2), r2;
}
function HM(t2, e2, i2, s2) {
  const n2 = { ee: e2, ot: t2, Vt: [i2.open, i2.high, i2.low, i2.close], zb: s2 };
  return void 0 !== i2.color && (n2.V = i2.color), n2;
}
function UM(t2, e2, i2, s2) {
  const n2 = { ee: e2, ot: t2, Vt: [i2.open, i2.high, i2.low, i2.close], zb: s2 };
  return void 0 !== i2.color && (n2.V = i2.color), void 0 !== i2.borderColor && (n2.Ot = i2.borderColor), void 0 !== i2.wickColor && (n2.Xh = i2.wickColor), n2;
}
function KM(t2, e2, i2, s2, n2) {
  const r2 = ck(n2)(i2), o2 = Math.max(...r2), a2 = Math.min(...r2), l2 = r2[r2.length - 1], h2 = [l2, o2, a2, l2], c2 = i2, { time: u2, color: d2 } = c2;
  return { ee: e2, ot: t2, Vt: h2, zb: s2, $e: WM(c2, ["time", "color"]), V: d2 };
}
function YM(t2) {
  return void 0 !== t2.Vt;
}
function GM(t2, e2) {
  return void 0 !== e2.customValues && (t2.jb = e2.customValues), t2;
}
function XM(t2) {
  return (e2, i2, s2, n2, r2, o2) => function(t3, e3) {
    return e3 ? e3(t3) : void 0 === (i3 = t3).open && void 0 === i3.value;
    var i3;
  }(s2, o2) ? GM({ ot: e2, ee: i2, zb: n2 }, s2) : GM(t2(e2, i2, s2, n2, r2), s2);
}
function JM(t2) {
  return { Candlestick: XM(UM), Bar: XM(HM), Area: XM(jM), Baseline: XM(qM), Histogram: XM(BM), Line: XM(BM), Custom: XM(KM) }[t2];
}
function QM(t2) {
  return { ee: 0, Hb: /* @__PURE__ */ new Map(), la: t2 };
}
function ZM(t2, e2) {
  if (void 0 !== t2 && 0 !== t2.length) return { $b: e2.key(t2[0].ot), Ub: e2.key(t2[t2.length - 1].ot) };
}
function tz(t2) {
  let e2;
  return t2.forEach((t3) => {
    void 0 === e2 && (e2 = t3.zb);
  }), ck(e2);
}
class se {
  constructor(t2) {
    this.qb = /* @__PURE__ */ new Map(), this.Yb = /* @__PURE__ */ new Map(), this.Zb = /* @__PURE__ */ new Map(), this.Xb = [], this.q_ = t2;
  }
  S() {
    this.qb.clear(), this.Yb.clear(), this.Zb.clear(), this.Xb = [];
  }
  Kb(t2, e2) {
    let i2 = 0 !== this.qb.size, s2 = false;
    const n2 = this.Yb.get(t2);
    if (void 0 !== n2) if (1 === this.Yb.size) i2 = false, s2 = true, this.qb.clear();
    else for (const e3 of this.Xb) e3.pointData.Hb.delete(t2) && (s2 = true);
    let r2 = [];
    if (0 !== e2.length) {
      const i3 = e2.map((t3) => t3.time), n3 = this.q_.createConverterToInternalObj(e2), o3 = JM(t2.Qh()), a2 = t2.Ca(), l2 = t2.Ta();
      r2 = e2.map((e3, r3) => {
        const h2 = n3(e3.time), c2 = this.q_.key(h2);
        let u2 = this.qb.get(c2);
        void 0 === u2 && (u2 = QM(h2), this.qb.set(c2, u2), s2 = true);
        const d2 = o3(h2, u2.ee, e3, i3[r3], a2, l2);
        return u2.Hb.set(t2, d2), d2;
      });
    }
    i2 && this.Gb(), this.Jb(t2, r2);
    let o2 = -1;
    if (s2) {
      const t3 = [];
      this.qb.forEach((e3) => {
        t3.push({ timeWeight: 0, time: e3.la, pointData: e3, originalTime: tz(e3.Hb) });
      }), t3.sort((t4, e3) => this.q_.key(t4.time) - this.q_.key(e3.time)), o2 = this.Qb(t3);
    }
    return this.tw(t2, o2, function(t3, e3, i3) {
      const s3 = ZM(t3, i3), n3 = ZM(e3, i3);
      if (void 0 !== s3 && void 0 !== n3) return { ta: s3.Ub >= n3.Ub && s3.$b >= n3.$b };
    }(this.Yb.get(t2), n2, this.q_));
  }
  vd(t2) {
    return this.Kb(t2, []);
  }
  iw(t2, e2) {
    const i2 = e2;
    !function(t3) {
      void 0 === t3.zb && (t3.zb = t3.time);
    }(i2), this.q_.preprocessData(e2);
    const s2 = this.q_.createConverterToInternalObj([e2])(e2.time), n2 = this.Zb.get(t2);
    if (void 0 !== n2 && this.q_.key(s2) < this.q_.key(n2)) throw new Error(`Cannot update oldest data, last time=${n2}, new time=${s2}`);
    let r2 = this.qb.get(this.q_.key(s2));
    const o2 = void 0 === r2;
    void 0 === r2 && (r2 = QM(s2), this.qb.set(this.q_.key(s2), r2));
    const a2 = JM(t2.Qh()), l2 = t2.Ca(), h2 = t2.Ta(), c2 = a2(s2, r2.ee, e2, i2.zb, l2, h2);
    r2.Hb.set(t2, c2), this.nw(t2, c2);
    const u2 = { ta: YM(c2) };
    if (!o2) return this.tw(t2, -1, u2);
    const d2 = { timeWeight: 0, time: r2.la, pointData: r2, originalTime: tz(r2.Hb) }, f2 = eS(this.Xb, this.q_.key(d2.time), (t3, e3) => this.q_.key(t3.time) < e3);
    this.Xb.splice(f2, 0, d2);
    for (let t3 = f2; t3 < this.Xb.length; ++t3) ez(this.Xb[t3].pointData, t3);
    return this.q_.fillWeightsForPoints(this.Xb, f2), this.tw(t2, f2, u2);
  }
  nw(t2, e2) {
    let i2 = this.Yb.get(t2);
    void 0 === i2 && (i2 = [], this.Yb.set(t2, i2));
    const s2 = 0 !== i2.length ? i2[i2.length - 1] : null;
    null === s2 || this.q_.key(e2.ot) > this.q_.key(s2.ot) ? YM(e2) && i2.push(e2) : YM(e2) ? i2[i2.length - 1] = e2 : i2.splice(-1, 1), this.Zb.set(t2, e2.ot);
  }
  Jb(t2, e2) {
    0 !== e2.length ? (this.Yb.set(t2, e2.filter(YM)), this.Zb.set(t2, e2[e2.length - 1].ot)) : (this.Yb.delete(t2), this.Zb.delete(t2));
  }
  Gb() {
    for (const t2 of this.Xb) 0 === t2.pointData.Hb.size && this.qb.delete(this.q_.key(t2.time));
  }
  Qb(t2) {
    let e2 = -1;
    for (let i2 = 0; i2 < this.Xb.length && i2 < t2.length; ++i2) {
      const s2 = this.Xb[i2], n2 = t2[i2];
      if (this.q_.key(s2.time) !== this.q_.key(n2.time)) {
        e2 = i2;
        break;
      }
      n2.timeWeight = s2.timeWeight, ez(n2.pointData, i2);
    }
    if (-1 === e2 && this.Xb.length !== t2.length && (e2 = Math.min(this.Xb.length, t2.length)), -1 === e2) return -1;
    for (let i2 = e2; i2 < t2.length; ++i2) ez(t2[i2].pointData, i2);
    return this.q_.fillWeightsForPoints(t2, e2), this.Xb = t2, e2;
  }
  sw() {
    if (0 === this.Yb.size) return null;
    let t2 = 0;
    return this.Yb.forEach((e2) => {
      0 !== e2.length && (t2 = Math.max(t2, e2[e2.length - 1].ee));
    }), t2;
  }
  tw(t2, e2, i2) {
    const s2 = { ew: /* @__PURE__ */ new Map(), St: { Eu: this.sw() } };
    if (-1 !== e2) this.Yb.forEach((e3, n2) => {
      s2.ew.set(n2, { $e: e3, rw: n2 === t2 ? i2 : void 0 });
    }), this.Yb.has(t2) || s2.ew.set(t2, { $e: [], rw: i2 }), s2.St.hw = this.Xb, s2.St.lw = e2;
    else {
      const e3 = this.Yb.get(t2);
      s2.ew.set(t2, { $e: e3 || [], rw: i2 });
    }
    return s2;
  }
}
function ez(t2, e2) {
  t2.ee = e2, t2.Hb.forEach((t3) => {
    t3.ee = e2;
  });
}
function iz(t2) {
  const e2 = { value: t2.Vt[3], time: t2.zb };
  return void 0 !== t2.jb && (e2.customValues = t2.jb), e2;
}
function sz(t2) {
  const e2 = iz(t2);
  return void 0 !== t2.V && (e2.color = t2.V), e2;
}
function nz(t2) {
  const e2 = iz(t2);
  return void 0 !== t2.lt && (e2.lineColor = t2.lt), void 0 !== t2.Ps && (e2.topColor = t2.Ps), void 0 !== t2.Rs && (e2.bottomColor = t2.Rs), e2;
}
function rz(t2) {
  const e2 = iz(t2);
  return void 0 !== t2.Re && (e2.topLineColor = t2.Re), void 0 !== t2.De && (e2.bottomLineColor = t2.De), void 0 !== t2.ke && (e2.topFillColor1 = t2.ke), void 0 !== t2.ye && (e2.topFillColor2 = t2.ye), void 0 !== t2.Ce && (e2.bottomFillColor1 = t2.Ce), void 0 !== t2.Te && (e2.bottomFillColor2 = t2.Te), e2;
}
function oz(t2) {
  const e2 = { open: t2.Vt[0], high: t2.Vt[1], low: t2.Vt[2], close: t2.Vt[3], time: t2.zb };
  return void 0 !== t2.jb && (e2.customValues = t2.jb), e2;
}
function az(t2) {
  const e2 = oz(t2);
  return void 0 !== t2.V && (e2.color = t2.V), e2;
}
function lz(t2) {
  const e2 = oz(t2), { V: i2, Ot: s2, Xh: n2 } = t2;
  return void 0 !== i2 && (e2.color = i2), void 0 !== s2 && (e2.borderColor = s2), void 0 !== n2 && (e2.wickColor = n2), e2;
}
function hz(t2) {
  return { Area: nz, Line: sz, Baseline: rz, Histogram: sz, Bar: az, Candlestick: lz, Custom: cz }[t2];
}
function cz(t2) {
  const e2 = t2.zb;
  return Object.assign(Object.assign({}, t2.$e), { time: e2 });
}
const uz = { vertLine: { color: "#9598A1", width: 1, style: 3, visible: true, labelVisible: true, labelBackgroundColor: "#131722" }, horzLine: { color: "#9598A1", width: 1, style: 3, visible: true, labelVisible: true, labelBackgroundColor: "#131722" }, mode: 1 }, dz = { vertLines: { color: "#D6DCDE", style: 0, visible: true }, horzLines: { color: "#D6DCDE", style: 0, visible: true } }, fz = { background: { type: "solid", color: "#FFFFFF" }, textColor: "#191919", fontSize: 12, fontFamily: Tk, attributionLogo: true }, pz = { autoScale: true, mode: 0, invertScale: false, alignLabels: true, borderVisible: true, borderColor: "#2B2B43", entireTextOnly: false, visible: false, ticksVisible: false, scaleMargins: { bottom: 0.1, top: 0.2 }, minimumWidth: 0 }, mz = { rightOffset: 0, barSpacing: 6, minBarSpacing: 0.5, fixLeftEdge: false, fixRightEdge: false, lockVisibleTimeRangeOnResize: false, rightBarStaysOnScroll: false, borderVisible: true, borderColor: "#2B2B43", visible: true, timeVisible: false, secondsVisible: true, shiftVisibleRangeOnNewBar: true, allowShiftVisibleRangeOnWhitespaceReplacement: false, ticksVisible: false, uniformDistribution: false, minimumHeight: 0, allowBoldLabels: true }, gz = { color: "rgba(0, 0, 0, 0)", visible: false, fontSize: 48, fontFamily: Tk, fontStyle: "", text: "", horzAlign: "center", vertAlign: "center" };
function vz() {
  return { width: 0, height: 0, autoSize: false, layout: fz, crosshair: uz, grid: dz, overlayPriceScales: Object.assign({}, pz), leftPriceScale: Object.assign(Object.assign({}, pz), { visible: false }), rightPriceScale: Object.assign(Object.assign({}, pz), { visible: true }), timeScale: mz, watermark: gz, localization: { locale: cM ? navigator.language : "", dateFormat: "dd MMM 'yy" }, handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: true }, handleScale: { axisPressedMouseMove: { time: true, price: true }, axisDoubleClickReset: { time: true, price: true }, mouseWheel: true, pinch: true }, kineticScroll: { mouse: false, touch: true }, trackingMode: { exitMode: 1 } };
}
class Me {
  constructor(t2, e2) {
    this.aw = t2, this.ow = e2;
  }
  applyOptions(t2) {
    this.aw.$t().$c(this.ow, t2);
  }
  options() {
    return this.Li().W();
  }
  width() {
    return Bk(this.ow) ? this.aw.Mb(this.ow) : 0;
  }
  Li() {
    return uk(this.aw.$t().Uc(this.ow)).Dt;
  }
}
function bz(t2, e2, i2) {
  const s2 = WM(t2, ["time", "originalTime"]), n2 = Object.assign({ time: e2 }, s2);
  return void 0 !== i2 && (n2.originalTime = i2), n2;
}
const _z = { color: "#FF0000", price: 0, lineStyle: 2, lineWidth: 1, lineVisible: true, axisLabelVisible: true, title: "", axisLabelColor: "", axisLabelTextColor: "" };
class ke {
  constructor(t2) {
    this.Nh = t2;
  }
  applyOptions(t2) {
    this.Nh.$h(t2);
  }
  options() {
    return this.Nh.W();
  }
  _w() {
    return this.Nh;
  }
}
class ye {
  constructor(t2, e2, i2, s2, n2) {
    this.uw = new D(), this.Es = t2, this.cw = e2, this.dw = i2, this.q_ = n2, this.fw = s2;
  }
  S() {
    this.uw.S();
  }
  priceFormatter() {
    return this.Es.ba();
  }
  priceToCoordinate(t2) {
    const e2 = this.Es.Ct();
    return null === e2 ? null : this.Es.Dt().Rt(t2, e2.Vt);
  }
  coordinateToPrice(t2) {
    const e2 = this.Es.Ct();
    return null === e2 ? null : this.Es.Dt().pn(t2, e2.Vt);
  }
  barsInLogicalRange(t2) {
    if (null === t2) return null;
    const e2 = new yn(new xn(t2.from, t2.to)).lu(), i2 = this.Es.In();
    if (i2.Ni()) return null;
    const s2 = i2.ll(e2.Os(), 1), n2 = i2.ll(e2.ui(), -1), r2 = uk(i2.el()), o2 = uk(i2.An());
    if (null !== s2 && null !== n2 && s2.ee > n2.ee) return { barsBefore: t2.from - r2, barsAfter: o2 - t2.to };
    const a2 = { barsBefore: null === s2 || s2.ee === r2 ? t2.from - r2 : s2.ee - r2, barsAfter: null === n2 || n2.ee === o2 ? o2 - t2.to : o2 - n2.ee };
    return null !== s2 && null !== n2 && (a2.from = s2.zb, a2.to = n2.zb), a2;
  }
  setData(t2) {
    this.q_, this.Es.Qh(), this.cw.pw(this.Es, t2), this.mw("full");
  }
  update(t2) {
    this.Es.Qh(), this.cw.bw(this.Es, t2), this.mw("update");
  }
  dataByIndex(t2, e2) {
    const i2 = this.Es.In().ll(t2, e2);
    return null === i2 ? null : hz(this.seriesType())(i2);
  }
  data() {
    const t2 = hz(this.seriesType());
    return this.Es.In().ne().map((e2) => t2(e2));
  }
  subscribeDataChanged(t2) {
    this.uw.l(t2);
  }
  unsubscribeDataChanged(t2) {
    this.uw.v(t2);
  }
  setMarkers(t2) {
    this.q_;
    const e2 = t2.map((t3) => bz(t3, this.q_.convertHorzItemToInternal(t3.time), t3.time));
    this.Es.na(e2);
  }
  markers() {
    return this.Es.sa().map((t2) => bz(t2, t2.originalTime, void 0));
  }
  applyOptions(t2) {
    this.Es.$h(t2);
  }
  options() {
    return Dk(this.Es.W());
  }
  priceScale() {
    return this.dw.priceScale(this.Es.Dt().Pa());
  }
  createPriceLine(t2) {
    const e2 = kk(Dk(_z), t2), i2 = this.Es.ea(e2);
    return new ke(i2);
  }
  removePriceLine(t2) {
    this.Es.ra(t2._w());
  }
  seriesType() {
    return this.Es.Qh();
  }
  attachPrimitive(t2) {
    this.Es.ka(t2), t2.attached && t2.attached({ chart: this.fw, series: this, requestUpdate: () => this.Es.$t().Kl() });
  }
  detachPrimitive(t2) {
    this.Es.ya(t2), t2.detached && t2.detached();
  }
  mw(t2) {
    this.uw.M() && this.uw.m(t2);
  }
}
class Ce {
  constructor(t2, e2, i2) {
    this.ww = new D(), this.mu = new D(), this.Om = new D(), this.$i = t2, this.yl = t2.St(), this.ab = e2, this.yl.nc().l(this.gw.bind(this)), this.yl.sc().l(this.Mw.bind(this)), this.ab.Nm().l(this.xw.bind(this)), this.q_ = i2;
  }
  S() {
    this.yl.nc().p(this), this.yl.sc().p(this), this.ab.Nm().p(this), this.ww.S(), this.mu.S(), this.Om.S();
  }
  scrollPosition() {
    return this.yl.Hu();
  }
  scrollToPosition(t2, e2) {
    e2 ? this.yl.Ju(t2, 1e3) : this.$i.Jn(t2);
  }
  scrollToRealTime() {
    this.yl.Gu();
  }
  getVisibleRange() {
    const t2 = this.yl.Vu();
    return null === t2 ? null : { from: t2.from.originalTime, to: t2.to.originalTime };
  }
  setVisibleRange(t2) {
    const e2 = { from: this.q_.convertHorzItemToInternal(t2.from), to: this.q_.convertHorzItemToInternal(t2.to) }, i2 = this.yl.Iu(e2);
    this.$i.pd(i2);
  }
  getVisibleLogicalRange() {
    const t2 = this.yl.Du();
    return null === t2 ? null : { from: t2.Os(), to: t2.ui() };
  }
  setVisibleLogicalRange(t2) {
    hk(t2.from <= t2.to, "The from index cannot be after the to index."), this.$i.pd(t2);
  }
  resetTimeScale() {
    this.$i.Kn();
  }
  fitContent() {
    this.$i.hc();
  }
  logicalToCoordinate(t2) {
    const e2 = this.$i.St();
    return e2.Ni() ? null : e2.It(t2);
  }
  coordinateToLogical(t2) {
    return this.yl.Ni() ? null : this.yl.Nu(t2);
  }
  timeToCoordinate(t2) {
    const e2 = this.q_.convertHorzItemToInternal(t2), i2 = this.yl.Va(e2, false);
    return null === i2 ? null : this.yl.It(i2);
  }
  coordinateToTime(t2) {
    const e2 = this.$i.St(), i2 = e2.Nu(t2), s2 = e2.Ui(i2);
    return null === s2 ? null : s2.originalTime;
  }
  width() {
    return this.ab.um().width;
  }
  height() {
    return this.ab.um().height;
  }
  subscribeVisibleTimeRangeChange(t2) {
    this.ww.l(t2);
  }
  unsubscribeVisibleTimeRangeChange(t2) {
    this.ww.v(t2);
  }
  subscribeVisibleLogicalRangeChange(t2) {
    this.mu.l(t2);
  }
  unsubscribeVisibleLogicalRangeChange(t2) {
    this.mu.v(t2);
  }
  subscribeSizeChange(t2) {
    this.Om.l(t2);
  }
  unsubscribeSizeChange(t2) {
    this.Om.v(t2);
  }
  applyOptions(t2) {
    this.yl.$h(t2);
  }
  options() {
    return Object.assign(Object.assign({}, Dk(this.yl.W())), { barSpacing: this.yl.le() });
  }
  gw() {
    this.ww.M() && this.ww.m(this.getVisibleRange());
  }
  Mw() {
    this.mu.M() && this.mu.m(this.getVisibleLogicalRange());
  }
  xw(t2) {
    this.Om.m(t2.width, t2.height);
  }
}
function yz(t2) {
  return function(t3) {
    if (Ck(t3.handleScale)) {
      const e3 = t3.handleScale;
      t3.handleScale = { axisDoubleClickReset: { time: e3, price: e3 }, axisPressedMouseMove: { time: e3, price: e3 }, mouseWheel: e3, pinch: e3 };
    } else if (void 0 !== t3.handleScale) {
      const { axisPressedMouseMove: e3, axisDoubleClickReset: i2 } = t3.handleScale;
      Ck(e3) && (t3.handleScale.axisPressedMouseMove = { time: e3, price: e3 }), Ck(i2) && (t3.handleScale.axisDoubleClickReset = { time: i2, price: i2 });
    }
    const e2 = t3.handleScroll;
    Ck(e2) && (t3.handleScroll = { horzTouchDrag: e2, vertTouchDrag: e2, mouseWheel: e2, pressedMouseMove: e2 });
  }(t2), t2;
}
class Re {
  constructor(t2, e2, i2) {
    this.Sw = /* @__PURE__ */ new Map(), this.kw = /* @__PURE__ */ new Map(), this.yw = new D(), this.Cw = new D(), this.Tw = new D(), this.Pw = new se(e2);
    const s2 = void 0 === i2 ? Dk(vz()) : kk(Dk(vz()), yz(i2));
    this.q_ = e2, this.aw = new Fs(t2, s2, e2), this.aw.lm().l((t3) => {
      this.yw.M() && this.yw.m(this.Rw(t3()));
    }, this), this.aw.am().l((t3) => {
      this.Cw.M() && this.Cw.m(this.Rw(t3()));
    }, this), this.aw.Xc().l((t3) => {
      this.Tw.M() && this.Tw.m(this.Rw(t3()));
    }, this);
    const n2 = this.aw.$t();
    this.Dw = new Ce(n2, this.aw.fb(), this.q_);
  }
  remove() {
    this.aw.lm().p(this), this.aw.am().p(this), this.aw.Xc().p(this), this.Dw.S(), this.aw.S(), this.Sw.clear(), this.kw.clear(), this.yw.S(), this.Cw.S(), this.Tw.S(), this.Pw.S();
  }
  resize(t2, e2, i2) {
    this.autoSizeActive() || this.aw._b(t2, e2, i2);
  }
  addCustomSeries(t2, e2) {
    const i2 = dk(t2), s2 = Object.assign(Object.assign({}, ik), i2.defaultOptions());
    return this.Vw("Custom", s2, e2, i2);
  }
  addAreaSeries(t2) {
    return this.Vw("Area", Zx, t2);
  }
  addBaselineSeries(t2) {
    return this.Vw("Baseline", tk, t2);
  }
  addBarSeries(t2) {
    return this.Vw("Bar", Jx, t2);
  }
  addCandlestickSeries(t2 = {}) {
    return function(t3) {
      void 0 !== t3.borderColor && (t3.borderUpColor = t3.borderColor, t3.borderDownColor = t3.borderColor), void 0 !== t3.wickColor && (t3.wickUpColor = t3.wickColor, t3.wickDownColor = t3.wickColor);
    }(t2), this.Vw("Candlestick", Xx, t2);
  }
  addHistogramSeries(t2) {
    return this.Vw("Histogram", ek, t2);
  }
  addLineSeries(t2) {
    return this.Vw("Line", Qx, t2);
  }
  removeSeries(t2) {
    const e2 = ck(this.Sw.get(t2)), i2 = this.Pw.vd(e2);
    this.aw.$t().vd(e2), this.Ow(i2), this.Sw.delete(t2), this.kw.delete(e2);
  }
  pw(t2, e2) {
    this.Ow(this.Pw.Kb(t2, e2));
  }
  bw(t2, e2) {
    this.Ow(this.Pw.iw(t2, e2));
  }
  subscribeClick(t2) {
    this.yw.l(t2);
  }
  unsubscribeClick(t2) {
    this.yw.v(t2);
  }
  subscribeCrosshairMove(t2) {
    this.Tw.l(t2);
  }
  unsubscribeCrosshairMove(t2) {
    this.Tw.v(t2);
  }
  subscribeDblClick(t2) {
    this.Cw.l(t2);
  }
  unsubscribeDblClick(t2) {
    this.Cw.v(t2);
  }
  priceScale(t2) {
    return new Me(this.aw, t2);
  }
  timeScale() {
    return this.Dw;
  }
  applyOptions(t2) {
    this.aw.$h(yz(t2));
  }
  options() {
    return this.aw.W();
  }
  takeScreenshot() {
    return this.aw.wb();
  }
  autoSizeActive() {
    return this.aw.kb();
  }
  chartElement() {
    return this.aw.yb();
  }
  paneSize() {
    const t2 = this.aw.Tb();
    return { height: t2.height, width: t2.width };
  }
  setCrosshairPosition(t2, e2, i2) {
    const s2 = this.Sw.get(i2);
    if (void 0 === s2) return;
    const n2 = this.aw.$t().dr(s2);
    null !== n2 && this.aw.$t().ad(t2, e2, n2);
  }
  clearCrosshairPosition() {
    this.aw.$t().od(true);
  }
  Vw(t2, e2, i2 = {}, s2) {
    !function(t3) {
      if (void 0 === t3 || "custom" === t3.type) return;
      const e3 = t3;
      void 0 !== e3.minMove && void 0 === e3.precision && (e3.precision = function(t4) {
        if (t4 >= 1) return 0;
        let e4 = 0;
        for (; e4 < 8; e4++) {
          const i3 = Math.round(t4);
          if (Math.abs(i3 - t4) < 1e-8) return e4;
          t4 *= 10;
        }
        return e4;
      }(e3.minMove));
    }(i2.priceFormat);
    const n2 = kk(Dk(sk), Dk(e2), i2), r2 = this.aw.$t().dd(t2, n2, s2), o2 = new ye(r2, this, this, this, this.q_);
    return this.Sw.set(o2, r2), this.kw.set(r2, o2), o2;
  }
  Ow(t2) {
    const e2 = this.aw.$t();
    e2._d(t2.St.Eu, t2.St.hw, t2.St.lw), t2.ew.forEach((t3, e3) => e3.J(t3.$e, t3.rw)), e2.Wu();
  }
  Bw(t2) {
    return ck(this.kw.get(t2));
  }
  Rw(t2) {
    const e2 = /* @__PURE__ */ new Map();
    t2.Nb.forEach((t3, i3) => {
      const s2 = i3.Qh(), n2 = hz(s2)(t3);
      if ("Custom" !== s2) hk(function(t4) {
        return function(t5) {
          return void 0 !== t5.open;
        }(t4) || function(t5) {
          return void 0 !== t5.value;
        }(t4);
      }(n2));
      else {
        const t4 = i3.Ta();
        hk(!t4 || false === t4(n2));
      }
      e2.set(this.Bw(i3), n2);
    });
    const i2 = void 0 !== t2.Eb && this.kw.has(t2.Eb) ? this.Bw(t2.Eb) : void 0;
    return { time: t2.zb, logical: t2.ee, point: t2.Lb, hoveredSeries: i2, hoveredObjectId: t2.Fb, seriesData: e2, sourceEvent: t2.Wb };
  }
}
Object.assign(Object.assign({}, sk), ik);
class TwChart {
  constructor(t2, e2) {
    this.series = [], this.lineSeries = [], this.priceLines = [], this.colors = ["#725bf5", "#777777", "#1dcdbc", "#2b3440", "#ffffff", "#3abff8", "#36d399", "#fbbd23", "#f87272"], this.lightTheme = { layout: { textColor: "rgba(0, 0, 0, 0.7)" }, timeScale: { borderColor: "rgba(0, 0, 0, 0.1)", timeVisible: true, secondsVisible: false } }, this.darkTheme = { layout: { textColor: "rgba(255, 255, 255, 0.7)" }, timeScale: { borderColor: "rgba(255, 255, 255, 0.1)", timeVisible: true, secondsVisible: false } }, this.selectTheme = { light: this.lightTheme, dark: this.darkTheme }, this.candlestickSeries = null, this.volumeSeries = null, this.htmlEle = t2, this.series = [], this.lineSeries = [];
    let i2 = { autoSize: true, localization: { locale: "zh-TW", dateFormat: "yyyy-MM-dd", priceFormatter: (t3) => t3.toFixed(2) }, rightPriceScale: { scaleMargins: { top: 0.1, bottom: 0.1 }, visible: true, mode: BS.Normal, borderVisible: false, ticksVisible: true, borderColor: "rgba(197, 203, 206, 0.4)" }, leftPriceScale: { scaleMargins: { top: 0.1, bottom: 0.1 }, visible: true, mode: BS.Normal, borderVisible: false, ticksVisible: true, borderColor: "red" }, timeScale: { borderColor: "red", borderVisible: false }, handleScroll: { pressedMouseMove: true, mouseWheel: false }, handleScale: { mouseWheel: false, pinch: true }, layout: { background: { type: XS.Solid, color: "transparent" } }, grid: { vertLines: { color: "rgba(197, 203, 206, 0.0)", style: rk.Dotted, visible: false }, horzLines: { color: "rgba(197, 203, 206, 0.0)", style: rk.Dotted, visible: false } }, crosshair: { horzLine: { visible: false, labelVisible: true }, vertLine: { visible: false, style: 0, width: 2, color: "rgba(32, 38, 46, 0.1)", labelVisible: true } } };
    i2.rightPriceScale.mode = e2 ? BS.Percentage : BS.Normal, i2.leftPriceScale.visible = false, this.chart = function(t3, e3) {
      return function(t4, e4, i3) {
        let s2;
        if (zk(t4)) {
          const e5 = document.getElementById(t4);
          hk(null !== e5, `Cannot find element in DOM with id=${t4}`), s2 = e5;
        } else s2 = t4;
        const n2 = new Re(s2, e4, i3);
        return e4.setOptions(n2.options()), n2;
      }(t3, new is(), is.Id(e3));
    }(this.htmlEle, i2);
  }
  setTheme(t2) {
    t2 && this.chart.applyOptions(this.selectTheme[t2]);
  }
  _updateLeftPriceScaleVisibility() {
    const t2 = [...this.series, ...this.lineSeries, this.volumeSeries ?? void 0, this.candlestickSeries ?? void 0].filter(Boolean).some((t3) => {
      try {
        return "left" === t3.options().priceScaleId;
      } catch {
        return false;
      }
    });
    this.chart.applyOptions({ leftPriceScale: { visible: t2 } });
  }
  resetAreaSeries(t2, e2 = "right") {
    if (this.series[t2]) try {
      this.chart.removeSeries(this.series[t2]);
    } catch (t3) {
    }
    const i2 = this.colors[t2 % this.colors.length];
    this.series[t2] = this.chart.addAreaSeries({ lineColor: i2, topColor: i2 + "77", bottomColor: i2 + "00", priceLineVisible: false, priceScaleId: e2 }), this._updateLeftPriceScaleVisibility();
  }
  resetLineSeries(t2, e2) {
    if (this.lineSeries[t2]) try {
      this.chart.removeSeries(this.lineSeries[t2]);
    } catch (t3) {
    }
    const i2 = (e2 == null ? void 0 : e2.color) ?? this.colors[t2 % this.colors.length];
    this.lineSeries[t2] = this.chart.addLineSeries({ color: i2, priceLineVisible: false, priceScaleId: (e2 == null ? void 0 : e2.priceScaleId) ?? "right", lineWidth: (e2 == null ? void 0 : e2.lineWidth) ?? 1 }), this._updateLeftPriceScaleVisibility();
  }
  updatePriceLines(t2, e2) {
    this.series[t2] && this.priceLines.forEach((e3) => {
      try {
        this.series[t2].removePriceLine(e3);
      } catch (t3) {
      }
    }), this.priceLines = [], this.series[t2] && e2.forEach((e3) => {
      const i2 = this.series[t2].createPriceLine(e3);
      this.priceLines.push(i2);
    });
  }
  setTimeScale(t2, e2) {
    this.chart.timeScale().setVisibleRange({ from: t2.getTime() / 1e3, to: e2.getTime() / 1e3 });
  }
  addCandlestickSeries() {
    this.candlestickSeries && this.chart.removeSeries(this.candlestickSeries), this.candlestickSeries = this.chart.addCandlestickSeries({ upColor: "#f43098", downColor: "#00d3bb", borderDownColor: "#00d3bb", borderUpColor: "#f43098", wickDownColor: "#00d3bb", wickUpColor: "#f43098" });
  }
  addVolumeSeries() {
    if (this.volumeSeries) try {
      this.chart.removeSeries(this.volumeSeries);
    } catch (t2) {
    }
    this.volumeSeries = this.chart.addHistogramSeries({ priceScaleId: "left", priceFormat: { type: "volume" }, color: "#9aa0a6" });
    try {
      this.volumeSeries.priceScale().applyOptions({ scaleMargins: { top: 0.75, bottom: 0 } });
    } catch (t2) {
    }
    this._updateLeftPriceScaleVisibility();
  }
  updateCandlestickSeriesData(t2) {
    if (this.candlestickSeries) {
      const e2 = t2.map((t3) => {
        let e3;
        return "string" != typeof t3.time ? null : (e3 = t3.time, { time: e3, open: t3.open, high: t3.high, low: t3.low, close: t3.close });
      }).filter((t3) => null !== t3);
      this.candlestickSeries.setData(e2), this.chart.timeScale().scrollToRealTime();
    }
  }
  updateVolumeSeriesData(t2) {
    if (!this.volumeSeries) return;
    const e2 = t2.map((t3) => "string" != typeof t3.time ? null : { time: t3.time, value: t3.value, color: t3.color }).filter(Boolean);
    this.volumeSeries.setData(e2);
  }
  updateLineSeriesData(t2, e2) {
    if (!this.lineSeries[t2]) return;
    const i2 = e2.map((t3) => "string" != typeof t3.time ? null : { time: t3.time, value: t3.value }).filter(Boolean);
    this.lineSeries[t2].setData(i2);
  }
  addTradeMarkers(t2, e2, i2) {
    if (!this.chart || !this.candlestickSeries) return;
    let s2 = [];
    t2.forEach((t3) => {
      s2.push({ time: t3.time, position: "belowBar", color: i2, shape: "arrowUp", text: "進場" });
    }), 0 !== e2.length && e2.forEach((t3) => {
      s2.push({ time: t3.time, position: "aboveBar", color: i2, shape: "arrowDown", text: `Sell @ ${t3.price}` });
    }), this.candlestickSeries && this.candlestickSeries.setMarkers(s2);
  }
}
function wz(t2, e2) {
  if ("#" === t2[0]) {
    const i3 = Math.round(255 * e2).toString(16).padStart(2, "0");
    return `${t2.slice(0, 7)}${i3}`;
  }
  if (t2.startsWith("rgb")) {
    const i3 = t2.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (!i3) throw new Error(`Invalid RGB color format: ${t2}`);
    return `rgba(${parseInt(i3[1])}, ${parseInt(i3[2])}, ${parseInt(i3[3])}, ${e2})`;
  }
  const i2 = t2.match(/^oklch\(([^)]+)\)/);
  if (!i2) return t2;
  const s2 = i2[1].split(/\s+/);
  if (s2.length < 3) throw new Error(`Incomplete OKLCH components in: ${t2}`);
  return `oklch(${s2[0]} ${s2[1]} ${s2[2]} / ${e2})`;
}
function xz() {
  return "undefined" == typeof document ? "" : (document.documentElement.getAttribute("data-theme"), getComputedStyle(document.documentElement).getPropertyValue("--color-error"));
}
function kz() {
  return "undefined" == typeof document ? "" : (document.documentElement.getAttribute("data-theme"), getComputedStyle(document.documentElement).getPropertyValue("--color-success"));
}
function Sz(t2) {
  return 0 === t2 ? "undefined" == typeof document ? "#6b7280" : "dark" === document.documentElement.getAttribute("data-theme") ? "#d1d5db" : "#6b7280" : t2 > 0 ? xz() : kz();
}
function Mz(t2) {
  return "undefined" == typeof document ? "" : getComputedStyle(document.documentElement).getPropertyValue("--color-" + t2);
}
function zz(t2) {
  return 0 === t2 ? "text-base-content-100" : t2 > 0 ? "text-error" : "text-success";
}
const Cz = { xmlns: "http://www.w3.org/2000/svg", width: 24, height: 24, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 2, "stroke-linecap": "round", "stroke-linejoin": "round" };
var Dz = function(t2, e2, i2 = "svg") {
  var s2, n2 = `<${i2}>${t2.startsWith("<!>") ? "<!>" + t2 : t2}</${i2}>`;
  return () => {
    if (Td) return xp(Pd, null), Pd;
    if (!s2) {
      var t3 = Hd(wp(n2));
      s2 = Hd(t3);
    }
    var e3 = s2.cloneNode(true);
    return xp(e3, e3), e3;
  };
}("<svg><!><!></svg>", 0, "svg");
function Rz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = Km(i2, ["name", "color", "size", "strokeWidth", "absoluteStrokeWidth", "iconNode"]);
  ld(e2, false);
  let n2 = Jm(e2, "name", 12, void 0), r2 = Jm(e2, "color", 12, "currentColor"), o2 = Jm(e2, "size", 12, 24), a2 = Jm(e2, "strokeWidth", 12, 2), l2 = Jm(e2, "absoluteStrokeWidth", 12, false), h2 = Jm(e2, "iconNode", 28, () => []);
  Om();
  var c2 = Dz();
  ym(c2, (t3, e3) => ({ ...Cz, ...s2, width: o2(), height: o2(), stroke: r2(), "stroke-width": t3, class: e3 }), [() => l2() ? 24 * Number(a2()) / Number(o2()) : a2(), () => ((...t3) => t3.filter((t4, e3, i3) => Boolean(t4) && i3.indexOf(t4) === e3).join(" "))("lucide-icon", "lucide", n2() ? `lucide-${n2()}` : "", i2.class)]);
  var u2 = Kd(c2);
  return Yp(u2, 1, h2, Kp, (t3, e3) => {
    var i3 = gd(() => Bu(rp(e3), 2)), s3 = Mp();
    (function(t4, e4, s4, n3) {
      let r3 = Td;
      var o3, a3;
      Td && Ad();
      var l3 = null;
      Td && 1 === Pd.nodeType && (l3 = Pd, Ad());
      var h3, c3 = Td ? Pd : t4;
      af(() => {
        const t5 = rp(i3)[0] || null;
        t5 !== o3 && (h3 && (null === t5 ? pf(h3, () => {
          h3 = null, a3 = null;
        }) : t5 === a3 ? vf(h3) : (uf(h3), Lp(false))), t5 && t5 !== a3 && (h3 = lf(() => {
          if (xp(l3 = Td ? l3 : document.createElementNS("http://www.w3.org/2000/svg", t5), l3), n3) {
            Td && (i4 = t5, Ep.includes(i4)) && l3.append(document.createComment(""));
            var e5 = Td ? Hd(l3) : l3.appendChild(qd());
            Td && (null === e5 ? $d(false) : Ed(e5)), n3(l3);
          }
          var i4;
          Lf.nodes_end = l3, c3.before(l3);
        })), (o3 = t5) && (a3 = o3), Lp(true));
      }, Gu), r3 && ($d(true), Ed(c3));
    })(Yd(s3), 0, 0, (t4, e4) => {
      ym(t4, () => ({ ...rp(i3)[1] }));
    }), zp(t3, s3);
  }), tm(Gd(u2), e2, "default", {}, null), Ld(c2), zp(t2, c2), hd({ get name() {
    return n2();
  }, set name(t3) {
    n2(t3), sp();
  }, get color() {
    return r2();
  }, set color(t3) {
    r2(t3), sp();
  }, get size() {
    return o2();
  }, set size(t3) {
    o2(t3), sp();
  }, get strokeWidth() {
    return a2();
  }, set strokeWidth(t3) {
    a2(t3), sp();
  }, get absoluteStrokeWidth() {
    return l2();
  }, set absoluteStrokeWidth(t3) {
    l2(t3), sp();
  }, get iconNode() {
    return h2();
  }, set iconNode(t3) {
    h2(t3), sp();
  } });
}
function Pz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m7 7 10 10" }], ["path", { d: "M17 7v10H7" }]];
  Rz(t2, Gm({ name: "arrow-down-right" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Tz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M12 5v14" }], ["path", { d: "m19 12-7 7-7-7" }]];
  Rz(t2, Gm({ name: "arrow-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function $z(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M7 7h10v10" }], ["path", { d: "M7 17 17 7" }]];
  Rz(t2, Gm({ name: "arrow-up-right" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Ez(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m5 12 7-7 7 7" }], ["path", { d: "M12 19V5" }]];
  Rz(t2, Gm({ name: "arrow-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Az(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M8 2v4" }], ["path", { d: "M16 2v4" }], ["rect", { width: "18", height: "18", x: "3", y: "4", rx: "2" }], ["path", { d: "M3 10h18" }]];
  Rz(t2, Gm({ name: "calendar" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Lz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m6 9 6 6 6-6" }]];
  Rz(t2, Gm({ name: "chevron-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Vz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m18 15-6-6-6 6" }]];
  Rz(t2, Gm({ name: "chevron-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Oz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m21 21-6-6m6 6v-4.8m0 4.8h-4.8" }], ["path", { d: "M3 16.2V21m0 0h4.8M3 21l6-6" }], ["path", { d: "M21 7.8V3m0 0h-4.8M21 3l-6 6" }], ["path", { d: "M3 7.8V3m0 0h4.8M3 3l6 6" }]];
  Rz(t2, Gm({ name: "expand" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Iz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m5 8 6 6" }], ["path", { d: "m4 14 6-6 2-3" }], ["path", { d: "M2 5h12" }], ["path", { d: "M7 2h1" }], ["path", { d: "m22 22-5-10-5 10" }], ["path", { d: "M14 18h6" }]];
  Rz(t2, Gm({ name: "languages" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Nz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M8 3v3a2 2 0 0 1-2 2H3" }], ["path", { d: "M21 8h-3a2 2 0 0 1-2-2V3" }], ["path", { d: "M3 16h3a2 2 0 0 1 2 2v3" }], ["path", { d: "M16 21v-3a2 2 0 0 1 2-2h3" }]];
  Rz(t2, Gm({ name: "minimize" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Fz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" }]];
  Rz(t2, Gm({ name: "moon" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Wz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["line", { x1: "19", x2: "5", y1: "5", y2: "19" }], ["circle", { cx: "6.5", cy: "6.5", r: "2.5" }], ["circle", { cx: "17.5", cy: "17.5", r: "2.5" }]];
  Rz(t2, Gm({ name: "percent" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Bz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["circle", { cx: "11", cy: "11", r: "8" }], ["path", { d: "m21 21-4.3-4.3" }]];
  Rz(t2, Gm({ name: "search" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function jz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["circle", { cx: "12", cy: "12", r: "4" }], ["path", { d: "M12 2v2" }], ["path", { d: "M12 20v2" }], ["path", { d: "m4.93 4.93 1.41 1.41" }], ["path", { d: "m17.66 17.66 1.41 1.41" }], ["path", { d: "M2 12h2" }], ["path", { d: "M20 12h2" }], ["path", { d: "m6.34 17.66-1.41 1.41" }], ["path", { d: "m19.07 4.93-1.41 1.41" }]];
  Rz(t2, Gm({ name: "sun" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function qz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["polyline", { points: "22 17 13.5 8.5 8.5 13.5 2 7" }], ["polyline", { points: "16 17 22 17 22 11" }]];
  Rz(t2, Gm({ name: "trending-down" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Hz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["polyline", { points: "22 7 13.5 15.5 8.5 10.5 2 17" }], ["polyline", { points: "16 7 22 7 22 13" }]];
  Rz(t2, Gm({ name: "trending-up" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
function Uz(t2, e2) {
  const i2 = Km(e2, ["children", "$$slots", "$$events", "$$legacy", "$$host"]), s2 = [["path", { d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3" }], ["path", { d: "M12 9v4" }], ["path", { d: "M12 17h.01" }]];
  Rz(t2, Gm({ name: "triangle-alert" }, () => i2, { get iconNode() {
    return s2;
  }, children: (t3, i3) => {
    var s3 = Mp();
    tm(Yd(s3), e2, "default", {}, null), zp(t3, s3);
  }, $$slots: { default: true } }));
}
tg(Rz, { name: {}, color: {}, size: {}, strokeWidth: {}, absoluteStrokeWidth: {}, iconNode: {} }, ["default"], [], true), tg(Pz, {}, ["default"], [], true), tg(Tz, {}, ["default"], [], true), tg($z, {}, ["default"], [], true), tg(Ez, {}, ["default"], [], true), tg(Az, {}, ["default"], [], true), tg(Lz, {}, ["default"], [], true), tg(Vz, {}, ["default"], [], true), tg(Oz, {}, ["default"], [], true), tg(Iz, {}, ["default"], [], true), tg(Nz, {}, ["default"], [], true), tg(Fz, {}, ["default"], [], true), tg(Wz, {}, ["default"], [], true), tg(Bz, {}, ["default"], [], true), tg(jz, {}, ["default"], [], true), tg(qz, {}, ["default"], [], true), tg(Hz, {}, ["default"], [], true), tg(Uz, {}, ["default"], [], true);
const Kz = (t2) => t2;
function Yz(t2) {
  const e2 = t2 - 1;
  return e2 * e2 * e2 + 1;
}
function Gz(t2) {
  const e2 = "string" == typeof t2 && t2.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e2 ? [parseFloat(e2[1]), e2[2] || "px"] : [t2, "px"];
}
function Xz(t2, { delay: e2 = 0, duration: i2 = 400, easing: s2 = Kz } = {}) {
  const n2 = +getComputedStyle(t2).opacity;
  return { delay: e2, duration: i2, easing: s2, css: (t3) => "opacity: " + t3 * n2 };
}
function Jz(t2, { delay: e2 = 0, duration: i2 = 400, easing: s2 = Yz, x: n2 = 0, y: r2 = 0, opacity: o2 = 0 } = {}) {
  const a2 = getComputedStyle(t2), l2 = +a2.opacity, h2 = "none" === a2.transform ? "" : a2.transform, c2 = l2 * (1 - o2), [u2, d2] = Gz(n2), [f2, p2] = Gz(r2);
  return { delay: e2, duration: i2, easing: s2, css: (t3, e3) => `
			transform: ${h2} translate(${(1 - t3) * u2}${d2}, ${(1 - t3) * f2}${p2});
			opacity: ${l2 - c2 * e3}` };
}
var Qz = kp("<div><!></div>"), Zz = kp("<div><!></div>"), tC = kp("<div><!></div>"), eC = kp("<div><!></div>"), iC = kp("<div><!></div>"), sC = kp('<div class="flex flex-col items-end"><div class="text-xs text-neutral-400 dark:text-white/40">MAE</div> <div class="font-medium"> </div></div>'), nC = kp('<div class="flex flex-col items-end"><div class="text-xs text-neutral-400 dark:text-white/40">GMFE</div> <div class="font-medium"> </div></div>'), rC = kp('<div class="grid grid-cols-12 p-4 gap-3 relative"><div class="col-span-2 flex items-center"><div class="font-medium text-neutral-800 dark:text-white"> </div></div> <div class="col-span-2 flex items-center"><div class="flex items-center gap-2"><div class="w-8 h-8 rounded-lg flex items-center justify-center"><!></div> <div class="font-medium"> </div></div></div> <div class="col-span-2 flex items-center"><div class="flex flex-col"><div class="font-medium"> </div> <div class="text-xs text-neutral-400 dark:text-white/40"> </div></div></div> <div class="col-span-2 flex items-center"><div class="flex flex-col"><div class="font-medium"> </div> <div class="text-xs text-neutral-400 dark:text-white/40"> </div></div></div> <div class="col-span-2 flex items-center"><div class="font-medium"> </div></div> <div class="col-span-2 flex items-center justify-end gap-3"><!> <!></div></div>'), oC = kp('<button class="inline-flex items-center justify-center rounded-md border border-neutral-200 bg-neutral-50 text-neutral-700 px-2 py-1 text-xs dark:bg-zinc-700 dark:text-white dark:border-white/10" disabled>...</button>'), aC = kp("<button> </button>"), lC = kp('<div class="rounded-xl border border-neutral-200 overflow-hidden bg-white text-neutral-700 dark:border-white/10 dark:bg-white/5 dark:text-white/80"><div class="grid grid-cols-12 p-3 gap-3 border-b border-neutral-200 text-neutral-500 text-xs font-medium bg-neutral-50 dark:border-white/10 dark:bg-white/5 dark:text-white/60"><div class="col-span-2 flex items-center gap-1 cursor-pointer select-none"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer select-none"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer select-none"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer select-none"> <!></div> <div class="col-span-2 flex items-center gap-1 cursor-pointer select-none"> <!></div> <div class="col-span-2 text-center">指標</div></div> <div class="grid grid-cols-1 divide-y divide-neutral-200 dark:divide-white/10"><!> <div class="p-4 flex justify-center items-center border-t border-neutral-200 dark:border-white/10"><div class="flex items-center gap-1"><button class="inline-flex items-center justify-center rounded-md border border-neutral-200 bg-neutral-50 text-neutral-700 px-2 py-1 text-xs dark:bg-zinc-700 dark:text-white dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed" title="上一頁"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m15 18-6-6 6-6"></path></svg></button> <!> <button class="inline-flex items-center justify-center rounded-md border border-neutral-200 bg-neutral-50 text-neutral-700 px-2 py-1 text-xs dark:bg-zinc-700 dark:text-white dark:border-white/10 disabled:opacity-50 disabled:cursor-not-allowed" title="下一頁"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"></path></svg></button></div> <div class="ml-4 text-sm text-neutral-500 dark:text-white/60"> </div></div></div></div>'), hC = kp('<div class="flex items-center gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2 text-sm text-amber-500"><!> <p> <code class="px-2 py-1 mx-1 rounded-md bg-neutral-800 text-neutral-100 font-mono">report.trades</code> </p></div>'), cC = kp('<p class="text-neutral-500 dark:text-white/60"></p>'), uC = kp('<div class="flex flex-col items-center justify-center p-12 text-center rounded-xl border border-neutral-200 bg-white text-neutral-700 dark:border-white/10 dark:bg-white/5 dark:text-white/80"><div class="w-16 h-16 mb-6 rounded-full bg-neutral-100 dark:bg-white/10 flex items-center justify-center"><!></div> <h3 class="text-xl font-medium mb-3 text-neutral-800 dark:text-white"></h3> <!></div>'), dC = kp('<div class="mb-12"><!></div>');
function fC(t2, e2) {
  ld(e2, false);
  const i2 = Sd(), s2 = Sd(), n2 = Sd(), r2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  let o2 = Jm(e2, "browser", 12), a2 = Jm(e2, "report", 12), l2 = Jm(e2, "theme", 12, "light"), h2 = Jm(e2, "candle", 12, "red"), c2 = Jm(e2, "tstart", 12, null), u2 = Jm(e2, "tend", 12, null);
  Bp(() => {
    o2();
  });
  const d2 = (t3) => t3 ? t3 == null ? void 0 : t3.toLocaleDateString() : "-";
  let f2 = Sd("entry"), p2 = Sd("dn"), m2 = Sd([]), g2 = Sd(1), v2 = Sd(1), b2 = Sd([]);
  function _2(t3) {
    t3 >= 1 && t3 <= rp(v2) && zd(g2, t3);
  }
  function y2() {
    const t3 = [], e3 = [];
    let i3;
    for (let e4 = 1; e4 <= rp(v2); e4++) (1 === e4 || e4 === rp(v2) || e4 >= rp(g2) - 2 && e4 <= rp(g2) + 2) && t3.push(e4);
    return t3.forEach((t4) => {
      i3 && (t4 - i3 === 2 ? e3.push(i3 + 1) : t4 - i3 !== 1 && e3.push("...")), e3.push(t4), i3 = t4;
    }), e3;
  }
  const w2 = (t3) => {
    if (null == t3) return "-";
    const e3 = Math.abs(100 * t3).toFixed(1);
    return e3.endsWith(".0") ? Math.abs(100 * t3).toFixed(0) + "%" : e3 + "%";
  };
  function x2(t3) {
    return null == t3 ? { color: "text-base-content/50", bgColor: "bg-base-300/20", icon: null } : t3 > 0.3 ? { color: `color: ${Sz(1)}`, bgColor: `background-color: ${wz(Sz(1), 0.1)}`, icon: $z } : t3 > 0 ? { color: `color: ${Sz(1)}`, bgColor: `background-color: ${wz(Sz(1), 0.05)}`, icon: Hz } : t3 > -0.2 ? { color: `color: ${Sz(-1)}`, bgColor: `background-color: ${wz(Sz(-1), 0.05)}`, icon: Pz } : { color: `color: ${Sz(-1)}`, bgColor: `background-color: ${wz(Sz(-1), 0.1)}`, icon: qz };
  }
  sf(() => (hp(a2()), hp(c2()), hp(u2()), rp(m2), rp(p2), rp(f2), rp(v2), rp(g2)), () => {
    if (a2() || c2() || u2()) {
      zd(m2, a2().trades), c2() && u2() && zd(m2, a2().trades.filter((t4) => {
        const e4 = t4.entry, i3 = t4.entry >= c2() & t4.entry <= u2(), s3 = t4.exit >= c2() & t4.exit <= u2();
        return e4 && i3 || s3;
      })), zd(m2, rp(m2).filter((t4) => t4.exit)), zd(m2, rp(m2).filter((t4) => Object.entries(t4).every(([t5, e4]) => "exit" === t5 || "exitSig" === t5 || null !== e4))), zd(m2, rp(m2).sort((t4, e4) => "up" === rp(p2) ? t4[rp(f2)] > e4[rp(f2)] ? 1 : -1 : t4[rp(f2)] < e4[rp(f2)] ? 1 : -1)), zd(v2, Math.ceil(rp(m2).length / 10)), rp(g2) > rp(v2) && zd(g2, 1);
      const t3 = 10 * (rp(g2) - 1), e3 = Math.min(t3 + 10, rp(m2).length);
      zd(b2, rp(m2).slice(t3, e3)), zd(n2, rp(m2).length > 10);
    }
  }), sf(() => rp(m2), () => {
    zd(i2, rp(m2).length > 0 ? rp(m2)[0].entry : null);
  }), sf(() => (hp(c2()), rp(i2)), () => {
    zd(s2, c2() > rp(i2));
  }), sf(() => {
  }, () => {
    zd(n2, true);
  }), nf(), Om();
  var k2 = Mp(), S2 = Yd(k2), M2 = (t3) => {
    var e3 = dC(), i3 = Kd(e3), n3 = (t4) => {
      var e4 = lC(), i4 = Kd(e4), s3 = Kd(i4), n4 = Kd(s3), o4 = Gd(n4), a3 = (t5) => {
        var e5 = Qz(), i5 = Kd(e5), s4 = (t6) => {
          Lz(t6, { size: 14 });
        }, n5 = (t6) => {
          Vz(t6, { size: 14 });
        };
        Hp(i5, (t6) => {
          "dn" === rp(p2) ? t6(s4) : t6(n5, false);
        }), Ld(e5), Pm(1, e5, () => Xz, () => ({ duration: 150 })), zp(t5, e5);
      };
      Hp(o4, (t5) => {
        "stockId" === rp(f2) && t5(a3);
      }), Ld(s3);
      var l3 = Gd(s3, 2), h3 = Kd(l3), c3 = Gd(h3), u3 = (t5) => {
        var e5 = Zz(), i5 = Kd(e5), s4 = (t6) => {
          Lz(t6, { size: 14 });
        }, n5 = (t6) => {
          Vz(t6, { size: 14 });
        };
        Hp(i5, (t6) => {
          "dn" === rp(p2) ? t6(s4) : t6(n5, false);
        }), Ld(e5), Pm(1, e5, () => Xz, () => ({ duration: 150 })), zp(t5, e5);
      };
      Hp(c3, (t5) => {
        "return" === rp(f2) && t5(u3);
      }), Ld(l3);
      var k3 = Gd(l3, 2), S3 = Kd(k3), M3 = Gd(S3), z2 = (t5) => {
        var e5 = tC(), i5 = Kd(e5), s4 = (t6) => {
          Lz(t6, { size: 14 });
        }, n5 = (t6) => {
          Vz(t6, { size: 14 });
        };
        Hp(i5, (t6) => {
          "dn" === rp(p2) ? t6(s4) : t6(n5, false);
        }), Ld(e5), Pm(1, e5, () => Xz, () => ({ duration: 150 })), zp(t5, e5);
      };
      Hp(M3, (t5) => {
        "entry" === rp(f2) && t5(z2);
      }), Ld(k3);
      var C2 = Gd(k3, 2), R2 = Kd(C2), P2 = Gd(R2), T2 = (t5) => {
        var e5 = eC(), i5 = Kd(e5), s4 = (t6) => {
          Lz(t6, { size: 14 });
        }, n5 = (t6) => {
          Vz(t6, { size: 14 });
        };
        Hp(i5, (t6) => {
          "dn" === rp(p2) ? t6(s4) : t6(n5, false);
        }), Ld(e5), Pm(1, e5, () => Xz, () => ({ duration: 150 })), zp(t5, e5);
      };
      Hp(P2, (t5) => {
        "exit" === rp(f2) && t5(T2);
      }), Ld(C2);
      var E2 = Gd(C2, 2), A2 = Kd(E2), L2 = Gd(A2), V2 = (t5) => {
        var e5 = iC(), i5 = Kd(e5), s4 = (t6) => {
          Lz(t6, { size: 14 });
        }, n5 = (t6) => {
          Vz(t6, { size: 14 });
        };
        Hp(i5, (t6) => {
          "dn" === rp(p2) ? t6(s4) : t6(n5, false);
        }), Ld(e5), Pm(1, e5, () => Xz, () => ({ duration: 150 })), zp(t5, e5);
      };
      Hp(L2, (t5) => {
        "position" === rp(f2) && t5(V2);
      }), Ld(E2), Vd(2), Ld(i4);
      var O2 = Gd(i4, 2), I2 = Kd(O2);
      Yp(I2, 1, () => rp(b2), Kp, (t5, e5, i5) => {
        var s4 = rC();
        const n5 = vd(() => x2(rp(e5).return)), r3 = vd(() => x2(rp(e5).position));
        var o5 = Kd(s4), a4 = Kd(o5), l4 = Kd(a4, true);
        Ld(a4), Ld(o5);
        var h4 = Gd(o5, 2), c4 = Kd(h4), u4 = Kd(c4), f3 = Kd(u4), p3 = (t6) => {
          var e6 = Mp();
          !function(t7) {
            Td && Ad();
            var e7, i6, s5 = t7;
            af(() => {
              e7 !== (e7 = rp(n5).icon) && (i6 && (pf(i6), i6 = null), e7 && (i6 = lf(() => ((t8, e8) => {
                e8(t8, { size: 14, get style() {
                  return rp(n5).color;
                } });
              })(s5, e7))));
            }, Gu), Td && (s5 = Pd);
          }(Yd(e6)), zp(t6, e6);
        };
        Hp(f3, (t6) => {
          rp(n5).icon && t6(p3);
        }), Ld(u4);
        var m3 = Gd(u4, 2), g3 = Kd(m3, true);
        Ld(m3), Ld(c4), Ld(h4);
        var v3 = Gd(h4, 2), b3 = Kd(v3), _3 = Kd(b3), y3 = Kd(_3, true);
        Ld(_3);
        var k4 = Gd(_3, 2), S4 = Kd(k4, true);
        Ld(k4), Ld(b3), Ld(v3);
        var M4 = Gd(v3, 2), z3 = Kd(M4), C3 = Kd(z3), R3 = Kd(C3, true);
        Ld(C3);
        var P3 = Gd(C3, 2), T3 = Kd(P3, true);
        Ld(P3), Ld(z3), Ld(M4);
        var E3 = Gd(M4, 2), A3 = Kd(E3), L3 = Kd(A3, true);
        Ld(A3), Ld(E3);
        var V3 = Gd(E3, 2), O3 = Kd(V3), I3 = (t6) => {
          var i6 = sC(), s5 = Gd(Kd(i6), 2), n6 = Kd(s5, true);
          Ld(s5), Ld(i6), of((t7, e6) => {
            cm(s5, t7), Vp(n6, e6);
          }, [() => `color: ${Sz(rp(e5).mae)}`, () => w2(rp(e5).mae)], vd), zp(t6, i6);
        };
        Hp(O3, (t6) => {
          void 0 !== rp(e5).mae && null !== rp(e5).mae && t6(I3);
        });
        var N3 = Gd(O3, 2), F3 = (t6) => {
          var i6 = nC(), s5 = Gd(Kd(i6), 2), n6 = Kd(s5, true);
          Ld(s5), Ld(i6), of((t7, e6) => {
            cm(s5, t7), Vp(n6, e6);
          }, [() => `color: ${Sz(rp(e5).gmfe)}`, () => w2(rp(e5).gmfe)], vd), zp(t6, i6);
        };
        Hp(N3, (t6) => {
          void 0 !== rp(e5).gmfe && null !== rp(e5).gmfe && t6(F3);
        }), Ld(V3), Ld(s4), of((t6, i6, s5, o6) => {
          Vp(l4, rp(e5).stockId || "-"), cm(u4, rp(n5).bgColor), cm(m3, rp(n5).color), Vp(g3, t6), Vp(y3, i6), Vp(S4, rp(e5).entryPrice ? `$${rp(e5).entryPrice}` : ""), Vp(R3, s5), Vp(T3, rp(e5).exitPrice ? `$${rp(e5).exitPrice}` : ""), cm(A3, rp(r3).color), Vp(L3, o6);
        }, [() => w2(rp(e5).return), () => d2(rp(e5).entry), () => d2(rp(e5).exit), () => w2(rp(e5).position)], vd), Pm(1, s4, () => Jz, () => ({ y: 20, duration: 300, delay: 30 * i5 })), zp(t5, s4);
      });
      var N2 = Gd(I2, 2), F2 = Kd(N2), B2 = Kd(F2), q2 = Gd(B2, 2);
      Yp(q2, 1, y2, Kp, (t5, e5) => {
        var i5 = Mp(), s4 = Yd(i5), n5 = (t6) => {
          zp(t6, oC());
        }, r3 = (t6) => {
          var i6 = aC(), s5 = Kd(i6, true);
          Ld(i6), of(() => {
            lm(i6, 1, "inline-flex items-center justify-center rounded-md px-2 py-1 text-xs border border-neutral-200 bg-neutral-50 text-neutral-700 dark:bg-zinc-700 dark:text-white dark:border-white/10 " + (rp(g2) === rp(e5) ? "bg-gray-900 text-white border-gray-900 dark:bg-white dark:text-gray-900 dark:border-white" : "")), Vp(s5, rp(e5));
          }), bp("click", i6, () => _2(rp(e5))), zp(t6, i6);
        };
        Hp(s4, (t6) => {
          "..." === rp(e5) ? t6(n5) : t6(r3, false);
        }), zp(t5, i5);
      });
      var U2 = Gd(q2, 2);
      Ld(F2);
      var K2 = Gd(F2, 2), G2 = Kd(K2, true);
      Ld(K2), Ld(N2), Ld(O2), Ld(e4), of((t5, e5, i5, s4, r3) => {
        Vp(n4, `${t5 ?? ""} `), Vp(h3, `${e5 ?? ""} `), Vp(S3, `${i5 ?? ""} `), Vp(R2, `${s4 ?? ""} `), Vp(A2, `${r3 ?? ""} `), B2.disabled = 1 === rp(g2), U2.disabled = rp(g2) === rp(v2), Vp(G2, `第 ${rp(g2)} 頁，共 ${rp(v2)} 頁 (${rp(m2).length} 筆交易)`);
      }, [() => r2("metrics.stocks.stockId"), () => r2("metrics.stocks.return"), () => r2("metrics.stocks.entry"), () => r2("metrics.stocks.exit"), () => r2("metrics.stocks.position")], vd), bp("click", s3, () => {
        "stockId" !== rp(f2) ? zd(f2, "stockId") : zd(p2, "up" === rp(p2) ? "dn" : "up");
      }), bp("click", l3, () => {
        "return" !== rp(f2) ? zd(f2, "return") : zd(p2, "up" === rp(p2) ? "dn" : "up");
      }), bp("click", k3, () => {
        "entry" !== rp(f2) ? zd(f2, "entry") : zd(p2, "up" === rp(p2) ? "dn" : "up");
      }), bp("click", C2, () => {
        "exit" !== rp(f2) ? zd(f2, "exit") : zd(p2, "up" === rp(p2) ? "dn" : "up");
      }), bp("click", E2, () => {
        "position" !== rp(f2) ? zd(f2, "position") : zd(p2, "up" === rp(p2) ? "dn" : "up");
      }), bp("click", B2, () => _2(rp(g2) - 1)), bp("click", U2, () => _2(rp(g2) + 1)), zp(t4, e4);
    }, o3 = (t4) => {
      var e4 = uC(), i4 = Kd(e4);
      Bz(Kd(i4), { class: "w-8 h-8 text-neutral-400 dark:text-white/60" }), Ld(i4);
      var n4 = Gd(i4, 2);
      n4.textContent = "沒有交易記錄";
      var r3 = Gd(n4, 2), o4 = (t5) => {
        var e5 = hC(), i5 = Kd(e5);
        Uz(i5, { size: 16, class: "text-amber-500" });
        var s3 = Gd(i5, 2), n5 = Kd(s3);
        n5.nodeValue = "網頁資料受限，請使用程式碼 ", Gd(n5, 2).nodeValue = " 查看所有紀錄", Ld(s3), Ld(e5), zp(t5, e5);
      }, a3 = (t5) => {
        var e5 = cC();
        e5.textContent = "這段時間沒有交易，請選擇其他時間範圍", zp(t5, e5);
      };
      Hp(r3, (t5) => {
        rp(s2) ? t5(o4) : t5(a3, false);
      }), Ld(e4), Pm(1, e4, () => Xz, () => ({ duration: 300 })), zp(t4, e4);
    };
    Hp(i3, (t4) => {
      0 !== rp(m2).length ? t4(n3) : t4(o3, false);
    }), Ld(e3), zp(t3, e3);
  };
  return Hp(S2, (t3) => {
    a2() && 0 != a2().trades.length && t3(M2);
  }), zp(t2, k2), hd({ get browser() {
    return o2();
  }, set browser(t3) {
    o2(t3), sp();
  }, get report() {
    return a2();
  }, set report(t3) {
    a2(t3), sp();
  }, get theme() {
    return l2();
  }, set theme(t3) {
    l2(t3), sp();
  }, get candle() {
    return h2();
  }, set candle(t3) {
    h2(t3), sp();
  }, get tstart() {
    return c2();
  }, set tstart(t3) {
    c2(t3), sp();
  }, get tend() {
    return u2();
  }, set tend(t3) {
    u2(t3), sp();
  } });
}
function pC(t2) {
  const e2 = Ex(t2.theme), i2 = "#77777755";
  return { y: { beginAtZero: t2.yBeginAtZero ?? true, ticks: { color: e2, display: t2.yDisplay ?? true, ...t2.yTickCallback ? { callback: t2.yTickCallback } : {} }, grid: { color: i2, tickBorderDash: [2, 2], display: t2.gridDisplay ?? false }, border: { display: t2.borderDisplay ?? false } }, x: { ticks: { color: e2, display: t2.xDisplay ?? true, ...t2.xTickCallback ? { callback: t2.xTickCallback } : {} }, grid: { color: i2, tickBorderDash: [2, 2], display: t2.gridDisplay ?? false }, border: { display: t2.borderDisplay ?? false } } };
}
function mC(t2) {
  return { responsive: t2.responsive ?? true, maintainAspectRatio: t2.maintainAspectRatio ?? true, plugins: { legend: { display: t2.legendDisplay ?? false } }, scales: t2.scales ?? pC(t2) };
}
tg(fC, { browser: {}, report: {}, theme: {}, candle: {}, tstart: {}, tend: {} }, [], [], true);
var gC = kp('<div class="absolute bg-primary/10 rounded-lg text-center whitespace-nowrap text-base-content text-sm flex justify-center items-start pt-2"> </div>'), vC = kp('<button><span class="font-medium tabular-nums"> </span> <span> </span></button>'), bC = kp('<div><div><div class="mb-12"><div class="relative overflow-hidden"><div class="text-primary h-64 z-0"></div> <!> <div class="mt-4"><div class="flex items-center gap-3 mb-2"><h3 class="text-sm font-medium text-base-content/50 uppercase tracking-wide"> </h3> <button> </button></div> <div class="grid grid-cols-4 @xs:grid-cols-5 @sm:grid-cols-7 gap-1.5"></div></div></div></div></div></div>'), _C = kp('<div class="w-full rounded-t"></div>'), yC = kp('<div class="w-full rounded-b"></div>'), wC = kp('<div class="flex-1 flex flex-col items-stretch relative group"><div class="absolute left-1/2 -translate-x-1/2 -top-5 text-xs font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none z-10"> </div> <div class="flex-1 flex items-end"><!></div> <div class="flex-1"><!></div></div>'), xC = kp('<div class="flex-1 text-center text-[10px] text-base-content/40"> </div>'), kC = kp('<div class="flex justify-center items-center"> </div>'), SC = kp("<div> </div>"), MC = kp('<div class="h-12 flex justify-start items-center"> </div> <!> <div class="flex justify-center items-center border border-base-content/0"> </div>', 1), zC = kp('<div><div><div><div><div class="card-content"><div class="flex items-start gap-6"><div class="stats shrink-0"><div class="stat pl-0"><div class="stat-title"> </div> <div class="text-3xl font-light"><span> </span></div> <div class="stat-desc"> </div></div> <div class="stat"><div class="stat-title"> </div> <div class="text-3xl font-light"><span> </span></div> <div class="stat-desc"> </div></div></div> <div class="flex-1 min-w-0 self-center"><div class="flex gap-[3px] h-24"></div> <div class="flex gap-[3px] border-t border-base-content/10 pt-1"></div></div></div> <div class="relative"><div><div class="grid grid-cols-14 mt-3 text-xs text-base-content-200 rounded-xl min-w-[640px] pb-4 overflow-y-hidden svelte-13tqbdu"><div class="h-5 md:h-10 flex justify-start items-center"> </div> <!> <div class="flex justify-center items-center"></div> <!></div></div></div></div></div></div></div></div>'), CC = kp('<div><div><div><div class="text-base-content/70 text-xl mb-3"><!></div> <div class="relative"><!></div></div></div></div>'), DC = kp('<div><div><div><div><div class="stat-title"> </div> <div class="text-3xl font-light"> <span class="stat-desc"> </span></div></div> <div><div class="text-sm mt-3 flex gap-2"><div class="badge rounded text-white"> </div> <div class="badge rounded text-white"> </div></div> <div class="relative h-36 mt-3 w-full"><canvas></canvas></div></div></div></div></div>'), RC = kp('<div><div><div><div class="text-base-content-100"><div class="pl-0"><div class="stat-title"> </div> <div class="text-3xl font-light gap-2"> </div></div> <div class="text-sm mt-3 flex"><div class="badge rounded text-white"> </div></div> <div class="relative h-36 mt-3 w-full"><canvas></canvas></div></div></div></div></div>'), PC = kp("<!> <!> <!> <!> <!>", 1);
const TC = { hash: "svelte-13tqbdu", code: ".grid-cols-14.svelte-13tqbdu {grid-template-columns:repeat(14, minmax(0, 1fr));}" };
function $C(t2, e2) {
  ld(e2, false), em(t2, TC);
  const [i2, s2] = Hm(), n2 = () => qm(Lx, "$themeChoice", i2), r2 = Sd(), o2 = Sd(), a2 = Sd(), l2 = Sd(), h2 = Sd(), c2 = Sd(), u2 = Sd(), d2 = Sd(), f2 = Sd(), p2 = Sd(), m2 = Sd(), g2 = Sd(), v2 = Sd(), b2 = Sd(), _2 = Sd(), y2 = Sd(), w2 = Sd(), x2 = Sd();
  Chart.register(LinearScale, BarController, CategoryScale, BarElement, sx);
  let k2 = Jm(e2, "browser", 12), S2 = Jm(e2, "report", 12), M2 = Jm(e2, "showAll", 12, true), z2 = Jm(e2, "chartTab", 12, "historicalReturn");
  const C2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  void 0 !== window && (window.report = S2());
  let R2 = Sd(), P2 = null, T2 = Sd(false);
  function E2() {
    if ("historicalReturn" === z2() && rp(R2)) {
      if (P2) try {
        P2.chart.remove();
      } catch (t3) {
      }
      P2 = null, B2("all");
    }
    "yearlyCompare" !== z2() && "excessReturn" !== z2() || function() {
      if (!k2()) return;
      if (!rp(b2)) return;
      if (!rp(x2)) return;
      mt2 && mt2.destroy(), gt2 && gt2.destroy();
      const t3 = function(t4, e4) {
        const i3 = Object.keys(t4), s3 = {}, n3 = i3.reduce((i4, n4) => {
          const r3 = t4[n4] - e4[n4];
          return s3[n4] = r3, i4 + r3;
        }, 0) / i3.length;
        return { result: s3, mean: n3 };
      }(rp(b2), rp(x2));
      zd(tt2, t3.mean), zd(et2, Object.values(t3.result).filter((t4) => t4 > 0).length), zd(at2, Object.values(t3.result).length - rp(et2));
      const e3 = Object.keys(rp(b2));
      if (rp(ct2)) {
        const t4 = rp(ct2).getContext("2d");
        mt2 = new Chart(t4, { type: "bar", data: { labels: e3, datasets: [{ label: C2("profitability.yearlyReturn"), data: Object.values(rp(b2)), backgroundColor: Tx(rp(r2)), borderWidth: 0, borderRadius: 4, barPercentage: 0.7, categoryPercentage: 0.8 }, { label: C2("profitability.benchmarkYearlyReturn"), data: Object.values(rp(x2)), backgroundColor: $x("AA"), borderWidth: 0, borderRadius: 4, barPercentage: 0.7, categoryPercentage: 0.8 }] }, options: { ...mC({ theme: rp(r2), maintainAspectRatio: false }), layout: { padding: 0 } } });
      }
      if (rp(dt2)) {
        const i3 = rp(dt2).getContext("2d");
        gt2 = new Chart(i3, { type: "bar", data: { labels: e3, datasets: [{ label: C2("profitability.exceedReturn"), data: Object.values(t3.result), backgroundColor: Tx(rp(r2)), borderWidth: 0, borderRadius: 4, barPercentage: 0.6, categoryPercentage: 0.8 }] }, options: mC({ theme: rp(r2), maintainAspectRatio: false }) });
      }
    }();
  }
  Bp(() => {
    zd(T2, true), E2();
  }), jp(() => {
    mt2 && mt2.destroy(), gt2 && gt2.destroy();
  });
  let A2 = Sd(null), L2 = Sd(null), V2 = Sd(null), O2 = Sd(M2() ? null : rp(a2)), I2 = Sd();
  function N2() {
    if (rp(V2) && rp(O2) && S2() && P2 && rp(R2)) {
      const t3 = `${rp(O2)}-${rp(V2) < 10 ? `0${rp(V2)}` : String(rp(V2))}-01`, e3 = `${rp(O2)}-${rp(V2) + 1 < 10 ? `0${rp(V2) + 1}` : String(rp(V2) + 1)}-01`, i3 = S2().indexOfTimestamps(t3), s3 = S2().indexOfTimestamps(e3);
      if (!S2().timestamps[i3] | !S2().timestamps[s3]) return;
      const n3 = P2.chart.timeScale().timeToCoordinate(S2().timestamps[i3]), r3 = P2.chart.timeScale().timeToCoordinate(S2().timestamps[s3]);
      n3 && r3 && (Md(I2, rp(I2).style.height = "80%"), Md(I2, rp(I2).style.width = r3 - n3 + "px"), Md(I2, rp(I2).style.left = n3 + "px"), Md(I2, rp(I2).style.top = "0"));
    }
  }
  async function F2(t3, e3) {
    if (!P2) return;
    const i3 = S2().indexOfTimestamps(t3), s3 = S2().indexOfTimestamps(e3);
    P2.setTimeScale(new Date(S2().timestamps[i3]), new Date(S2().timestamps[s3]));
  }
  function B2(t3) {
    P2 || (P2 = new TwChart(rp(R2), true)), P2.setTheme(function(t4) {
      return "light" === t4 || "dark" === t4 ? t4 : "undefined" != typeof document && "dark" === document.documentElement.getAttribute("data-theme") ? "dark" : "light";
    }(rp(r2)));
    const e3 = "all" === t3 ? S2().timestamps.length : 100, i3 = S2().timestamps.length / (e3 / 100), s3 = S2().createTradingviewSeries("strategy", 0, -1, i3), n3 = S2().createTradingviewSeries("benchmark", 0, -1, i3);
    P2.resetAreaSeries(0), P2.resetAreaSeries(1), P2.series[0].setData(s3), P2.series[1].setData(n3), P2.chart.subscribeCrosshairMove((t4) => {
      const e4 = new Date(t4.time);
      zd(A2, e4.getMonth() + 1), zd(L2, e4.getFullYear() || rp(L2));
    }), P2.chart.subscribeClick((t4) => {
      const e4 = new Date(t4.time);
      zd(V2, e4.getMonth() + 1), zd(O2, e4.getFullYear()), N2();
    }), P2.chart.timeScale().subscribeVisibleTimeRangeChange((t4) => {
      N2();
    }), "all" === t3 && P2.setTimeScale(new Date(S2().timestamps[0]), new Date(S2().timestamps[S2().timestamps.length - 1]));
  }
  function q2(t3) {
    return t3 > 0 ? "+" + String(t3) : t3;
  }
  function U2(t3) {
    return 0 === t3.length ? 0 : t3[0] + U2(t3.slice(1));
  }
  let K2 = Sd(null), G2 = Sd(null);
  function J2(t3) {
    if (!t3 || 0 == t3) return "rgba(0,0,0,0)";
    const e3 = Math.max(Math.abs(rp(d2)), Math.abs(rp(f2))) || 1;
    let i3 = Math.abs(t3) / e3;
    return i3 = Math.min(0.6, i3), wz(t3 > 0 ? xz() : kz(), i3);
  }
  function Q2(t3) {
    if (!t3 || 0 == t3) return "rgba(0,0,0,0)";
    let e3 = Math.abs(t3 > 0 ? t3 / rp(w2) : t3 / rp(y2)) / 2;
    return wz(t3 > 0 ? xz() : kz(), e3);
  }
  let tt2 = Sd(null), et2 = Sd(null), at2 = Sd(null), ct2 = Sd(), dt2 = Sd(), mt2 = null, gt2 = null;
  sf(() => n2(), () => {
    zd(r2, n2());
  }), sf(() => (rp(T2), hp(z2()), rp(r2), np), () => {
    rp(T2) && (z2() || rp(r2)) && np().then(() => E2());
  }), sf(() => hp(S2()), () => {
    zd(o2, new Date(S2().timestamps[0]).getFullYear());
  }), sf(() => hp(S2()), () => {
    zd(a2, new Date(S2().timestamps[S2().timestamps.length - 1]).getFullYear());
  }), sf(() => (rp(O2), rp(V2)), () => {
    zd(l2, rp(O2) ? new Date(new Date(rp(O2), (rp(V2) || 1) - 1)) : null);
  }), sf(() => (rp(O2), rp(V2)), () => {
    zd(h2, rp(O2) ? new Date(new Date(rp(O2), rp(V2) || 12) - 864e5) : null);
  }), sf(() => hp(S2()), () => {
    zd(c2, S2().calculateMonthlyReturn("strategy"));
  }), sf(() => rp(c2), () => {
    zd(u2, Object.values(rp(c2)).filter((t3) => t3 == t3));
  }), sf(() => rp(u2), () => {
    zd(d2, Math.max(...rp(u2)));
  }), sf(() => rp(u2), () => {
    zd(f2, Math.min(...rp(u2)));
  }), sf(() => rp(u2), () => {
    zd(p2, U2(rp(u2)) / rp(u2).length);
  }), sf(() => rp(c2), () => {
    zd(m2, (() => {
      const t3 = Array(12).fill(0), e3 = Array(12).fill(0);
      for (const [i3, s3] of Object.entries(rp(c2))) {
        if (s3 != s3) continue;
        const n3 = parseInt(i3.slice(4)) - 1;
        n3 >= 0 && n3 < 12 && (t3[n3] += s3, e3[n3]++);
      }
      return t3.map((t4, i3) => e3[i3] > 0 ? t4 / e3[i3] : 0);
    })());
  }), sf(() => rp(m2), () => {
    zd(g2, Math.max(...rp(m2).map(Math.abs), 1e-3));
  }), sf(() => rp(u2), () => {
    zd(v2, rp(u2).filter((t3) => t3 > 0).length / rp(u2).length * 100);
  }), sf(() => hp(S2()), () => {
    zd(b2, S2().calculateAnnualReturn("strategy"));
  }), sf(() => rp(b2), () => {
    zd(_2, Object.values(rp(b2)).filter((t3) => t3 == t3));
  }), sf(() => rp(_2), () => {
    zd(y2, Math.min(...rp(_2)));
  }), sf(() => rp(_2), () => {
    zd(w2, Math.max(...rp(_2)));
  }), sf(() => hp(S2()), () => {
    zd(x2, S2().calculateAnnualReturn("benchmark"));
  }), sf(() => (rp(c2), rp(r2)), () => {
    (rp(c2) || rp(r2)) && zd(K2, Object.fromEntries(Object.keys(rp(c2)).map((t3) => [t3, J2(rp(c2)[t3])])));
  }), sf(() => (rp(b2), rp(r2)), () => {
    (rp(b2) || rp(r2)) && zd(G2, Object.fromEntries(Object.keys(rp(b2)).map((t3) => [t3, Q2(rp(b2)[t3])])));
  }), nf(), Om();
  var bt2 = PC(), _t3 = Yd(bt2), yt2 = (t3) => {
    var e3 = bC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3);
    Vm(r3, (t4) => zd(R2, t4), () => rp(R2));
    var l3 = Gd(r3, 2), h3 = (t4) => {
      var e4 = gC(), i4 = Kd(e4);
      Ld(e4), Vm(e4, (t5) => zd(I2, t5), () => rp(I2)), of(() => Vp(i4, `${rp(O2) ?? ""}-${(rp(V2) < 10 ? "0" + rp(V2) : rp(V2)) ?? ""}`)), zp(t4, e4);
    };
    Hp(l3, (t4) => {
      rp(V2) && rp(O2) && t4(h3);
    });
    var c3 = Gd(l3, 2), u3 = Kd(c3), d3 = Kd(u3), f3 = Kd(d3, true);
    Ld(d3);
    var p3 = Gd(d3, 2), m3 = Kd(p3, true);
    Ld(p3), Ld(u3);
    var g3 = Gd(u3, 2);
    Yp(g3, 5, () => Array.from(Array(rp(a2) + 1).keys()).slice(rp(o2)), Kp, (t4, e4) => {
      var i4 = vC(), s4 = Kd(i4), n4 = Kd(s4, true);
      Ld(s4);
      var r4 = Gd(s4, 2), o3 = Kd(r4);
      Ld(r4), Ld(i4), of((t5, s5) => {
        lm(i4, 1, "flex items-baseline justify-center gap-1.5 px-2.5 py-1 rounded-lg border text-sm transition-all\n									" + (rp(L2) === rp(e4) ? "border-primary bg-primary/10 text-base-content" : "border-base-content/10 text-base-content/60 hover:border-base-content/25 hover:text-base-content/80")), Vp(n4, rp(e4)), lm(r4, 1, `tabular-nums ${t5 ?? ""}`, "svelte-13tqbdu"), Vp(o3, `${s5 ?? ""}%`);
      }, [() => zz(rp(b2)[rp(e4)]), () => (100 * rp(b2)[rp(e4)] || 0).toFixed(1)], vd), bp("click", i4, () => {
        B2("year"), F2(rp(e4) - 1 + "-12-31", `${rp(e4)}-12-31`), zd(L2, rp(e4));
      }), zp(t4, i4);
    }), Ld(g3), Ld(c3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4) => {
      Vp(f3, t4), lm(p3, 1, "text-xs px-2 py-0.5 rounded-full border transition-all\n								" + (null === rp(L2) ? "border-primary bg-primary/10 text-primary" : "border-base-content/15 text-base-content/40 hover:border-base-content/30 hover:text-base-content/60")), Vp(m3, e4);
    }, [() => Ic(), () => Nc()], vd), bp("click", p3, () => {
      B2("all"), F2(0, -1), zd(L2, null);
    }), zp(t3, e3);
  };
  Hp(_t3, (t3) => {
    "historicalReturn" === z2() && t3(yt2);
  });
  var wt2 = Gd(_t3, 2), xt2 = (t3) => {
    var e3 = zC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), l3 = Kd(r3), h3 = Kd(l3), d3 = Kd(h3), f3 = Kd(d3), b3 = Kd(f3, true);
    Ld(f3);
    var _3 = Gd(f3, 2), y3 = Kd(_3), w3 = Kd(y3);
    Ld(y3), Ld(_3);
    var x3 = Gd(_3, 2), k3 = Kd(x3, true);
    Ld(x3), Ld(d3);
    var S3 = Gd(d3, 2), M3 = Kd(S3), z3 = Kd(M3, true);
    Ld(M3);
    var R3 = Gd(M3, 2), P3 = Kd(R3), T3 = Kd(P3);
    Ld(P3), Ld(R3);
    var E3 = Gd(R3, 2), I3 = Kd(E3);
    Ld(E3), Ld(S3), Ld(h3);
    var U3 = Gd(h3, 2), G3 = Kd(U3);
    Yp(G3, 5, () => rp(m2), Kp, (t4, e4) => {
      var i4 = wC();
      const s4 = vd(() => Math.abs(rp(e4)) / rp(g2) * 50);
      var n4 = Kd(i4), r4 = Kd(n4);
      Ld(n4);
      var o3 = Gd(n4, 2), a3 = Kd(o3), l4 = (t5) => {
        var i5 = _C();
        of((t6) => cm(i5, `height:${rp(s4) ?? ""}%;background:${t6 ?? ""};min-height:${rp(e4) > 0 ? 2 : 0}px`), [xz], vd), zp(t5, i5);
      };
      Hp(a3, (t5) => {
        rp(e4) >= 0 && t5(l4);
      }), Ld(o3);
      var h4 = Gd(o3, 2), c3 = Kd(h4), u3 = (t5) => {
        var e5 = yC();
        of((t6) => cm(e5, `height:${rp(s4) ?? ""}%;background:${t6 ?? ""};min-height:2px`), [kz], vd), zp(t5, e5);
      };
      Hp(c3, (t5) => {
        rp(e4) < 0 && t5(u3);
      }), Ld(h4), Ld(i4), of((t5) => Vp(r4, `${t5 ?? ""}%`), [() => q2((100 * rp(e4)).toFixed(2))], vd), zp(t4, i4);
    }), Ld(G3);
    var J3 = Gd(G3, 2);
    Yp(J3, 4, () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], Kp, (t4, e4) => {
      var i4 = xC(), s4 = Kd(i4, true);
      Ld(i4), of((t5) => Vp(s4, t5), [() => jc({ v1: e4 })], vd), zp(t4, i4);
    }), Ld(J3), Ld(U3), Ld(l3);
    var Q3 = Gd(l3, 2), tt3 = Kd(Q3), et3 = Kd(tt3), at3 = Kd(et3), ct3 = Kd(at3, true);
    Ld(at3);
    var dt3 = Gd(at3, 2);
    Yp(dt3, 0, () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], Kp, (t4, e4) => {
      var i4 = kC(), s4 = Kd(i4, true);
      Ld(i4), of((t5) => Vp(s4, t5), [() => jc({ v1: e4 })], vd), zp(t4, i4);
    }), Yp(Gd(dt3, 4), 1, () => Array.from(Array(rp(a2) + 1).keys()).slice(rp(o2)).reverse(), Kp, (t4, e4) => {
      var i4 = MC(), s4 = Yd(i4), n4 = Kd(s4, true);
      Ld(s4);
      var r4 = Gd(s4, 2);
      Yp(r4, 0, () => [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], Kp, (t5, i5) => {
        var s5 = SC(), n5 = Kd(s5);
        Ld(s5), of((t6) => {
          lm(s5, 1, `cursor-pointer flex justify-center items-center hover:bg-primary/10 transition-colors duration-150
											${rp(e4) === rp(L2) ? "border-t-2 border-b-2 border-primary" : ""} 											${rp(e4) === rp(L2) && 1 == i5 ? "border-l-2 border-primary rounded-l-lg" : ""} 											${rp(e4) === rp(L2) && 12 == i5 ? "border-r-2 border-primary rounded-r-lg" : ""} 											${i5 === rp(A2) && rp(e4) === rp(L2) ? "border-b-2 border-primary font-bold" : ""}`, "svelte-13tqbdu"), cm(s5, `background:${rp(K2)[`${rp(e4)}${i5}`]}`), Vp(n5, `${t6 ?? ""}%`);
        }, [() => q2((100 * (rp(c2)[`${rp(e4)}${i5}`] || 0)).toFixed(1))], vd), bp("click", s5, () => {
          B2("year"), F2(rp(e4) - 1 + "-12-31", `${rp(e4)}-12-31`), zd(L2, rp(e4)), zd(O2, rp(e4)), zd(V2, i5), N2();
        }), zp(t5, s5);
      });
      var o3 = Gd(r4, 2), a3 = Kd(o3, true);
      Ld(o3), of(() => {
        Vp(n4, rp(e4)), Vp(a3, rp(e4));
      }), zp(t4, i4);
    }), Ld(et3), Ld(tt3), Ld(Q3), Ld(r3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n4, r4, o3, a3, l4, h4) => {
      Vp(b3, t4), lm(y3, 1, e4, "svelte-13tqbdu"), Vp(w3, `${i4 ?? ""}%`), Vp(k3, s4), Vp(z3, n4), lm(P3, 1, r4, "svelte-13tqbdu"), Vp(T3, `${o3 ?? ""}%`), Vp(I3, `${a3 ?? ""} / ${rp(u2).length ?? ""}`), lm(tt3, 1, l4, "svelte-13tqbdu"), Vp(ct3, h4);
    }, [() => C2("profitability.avgMonthlyReturn"), () => nm(zz(rp(p2))), () => q2((100 * rp(p2)).toFixed(2)), () => C2("average"), () => C2("profitability.monthlyWinRatio"), () => nm(zz(rp(v2) - 0.5)), () => rp(v2).toFixed(1), () => rp(u2).filter((t4) => t4 > 0).length, () => `overflow-x-auto
							${function() {
      const t4 = navigator.userAgent || navigator.vendor;
      return /iPad|iPhone|iPod|android/i.test(t4);
    }() ? "no-scrollbar" : "show-scrollbar"}
						`, () => C2("profitability.monthlyReturn")], vd), zp(t3, e3);
  };
  Hp(wt2, (t3) => {
    "monthlyReturn" === z2() && t3(xt2);
  });
  var kt2 = Gd(wt2, 2), Mt2 = (t3) => {
    var e3 = CC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), o3 = Kd(n3), a3 = (t4) => {
      var e4 = Sp();
      of((t5, i4) => Vp(e4, `${t5 ?? ""}~${i4 ?? ""}`), [() => {
        var _a3;
        return (_a3 = rp(l2)) == null ? void 0 : _a3.toLocaleDateString();
      }, () => {
        var _a3;
        return (_a3 = rp(h2)) == null ? void 0 : _a3.toLocaleDateString();
      }], vd), zp(t4, e4);
    };
    Hp(o3, (t4) => {
      rp(O2) && t4(a3);
    }), Ld(n3);
    var c3 = Gd(n3, 2);
    fC(Kd(c3), { get report() {
      return S2();
    }, get theme() {
      return rp(r2);
    }, get browser() {
      return k2();
    }, get tstart() {
      return rp(l2);
    }, get tend() {
      return rp(h2);
    } }), Ld(c3), Ld(s3), Ld(i3), Ld(e3), zp(t3, e3);
  };
  Hp(kt2, (t3) => {
    "stockList" === z2() && t3(Mt2);
  });
  var zt2 = Gd(kt2, 2), Ct2 = (t3) => {
    var e3 = DC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), o3 = Kd(n3), a3 = Kd(o3, true);
    Ld(o3);
    var l3 = Gd(o3, 2), h3 = Kd(l3), c3 = Gd(h3), u3 = Kd(c3, true);
    Ld(c3), Ld(l3), Ld(n3);
    var d3 = Gd(n3, 2), f3 = Kd(d3), p3 = Kd(f3), m3 = Kd(p3, true);
    Ld(p3);
    var g3 = Gd(p3, 2), v3 = Kd(g3, true);
    Ld(g3), Ld(f3);
    var b3 = Gd(f3, 2);
    Vm(Kd(b3), (t4) => zd(ct2, t4), () => rp(ct2)), Ld(b3), Ld(d3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n4, r3) => {
      Vp(a3, t4), Vp(h3, `${rp(et2) ?? ""} / ${rp(et2) + rp(at2)} `), Vp(u3, e4), cm(p3, `background:${i4 ?? ""}`), Vp(m3, s4), cm(g3, `background:${n4 ?? ""}`), Vp(v3, r3);
    }, [() => C2("profitability.yearlyWinRate"), () => C2("profitability.year"), () => Tx(rp(r2)), () => C2("strategy"), () => $x("AA"), () => C2("benchmark")], vd), zp(t3, e3);
  };
  Hp(zt2, (t3) => {
    "yearlyCompare" === z2() && t3(Ct2);
  });
  var Rt2 = Gd(zt2, 2), At2 = (t3) => {
    var e3 = RC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), o3 = Kd(n3), a3 = Kd(o3), l3 = Kd(a3, true);
    Ld(a3);
    var h3 = Gd(a3, 2), c3 = Kd(h3);
    Ld(h3), Ld(o3);
    var u3 = Gd(o3, 2), d3 = Kd(u3), f3 = Kd(d3, true);
    Ld(d3), Ld(u3);
    var p3 = Gd(u3, 2);
    Vm(Kd(p3), (t4) => zd(dt2, t4), () => rp(dt2)), Ld(p3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      Vp(l3, t4), Vp(c3, `${e4 ?? ""}%`), cm(d3, `background:${i4 ?? ""}`), Vp(f3, s4);
    }, [() => C2("average"), () => q2((100 * rp(tt2)).toFixed(2)), () => Tx(rp(r2)), () => C2("strategy")], vd), zp(t3, e3);
  };
  Hp(Rt2, (t3) => {
    "excessReturn" === z2() && t3(At2);
  }), zp(t2, bt2);
  var Lt2 = hd({ get browser() {
    return k2();
  }, set browser(t3) {
    k2(t3), sp();
  }, get report() {
    return S2();
  }, set report(t3) {
    S2(t3), sp();
  }, get showAll() {
    return M2();
  }, set showAll(t3) {
    M2(t3), sp();
  }, get chartTab() {
    return z2();
  }, set chartTab(t3) {
    z2(t3), sp();
  } });
  return s2(), Lt2;
}
tg($C, { browser: {}, report: {}, showAll: {}, chartTab: {} }, [], [], true);
var EC = kp("<button> </button> <button> </button> <button> </button>", 1), AC = kp('<div><div class="grid grid-cols-6 gap-12"><div class="col-span-6 md:col-span-3"><div class="pb-0"><div class="flex items-center mb-4"><!></div> <div><div class="w-full mb-6"><div class="font-light"><div class="text-normal"> </div> <div class="text-3xl"> </div></div></div></div></div> <div class="pl-0 pt-0 pr-0 -mt-8"><div class="h-48"></div></div></div> <div class="col-span-6 md:col-span-3"><div><div><span> </span> <div class="w-full overflow-x-auto relative"><div class="text-sm mt-2 flex gap-2"><div class="badge rounded bg-primary text-white"> </div> <div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-[rgba(241,99,102,1)] text-white"> </div></div></div></div></div> <div class="pt-0 pr-0"><canvas class="h-48 mt-6 w-full"></canvas></div></div></div></div>'), LC = kp('<div><div class="grid grid-cols-6 gap-12"><div class="col-span-6 md:col-span-3"><div><div class="flex items-end mb-4"><!></div> <div><div class="w-full mb-6"><div class="font-light"><div class="text-normal"> </div> <div class="text-3xl"> </div></div></div></div></div> <div class="pl-0 pt-0 pr-0 -mt-8"><div class="h-48"></div></div></div> <div class="col-span-6 md:col-span-3"><div><div><span> </span> <div class="w-full overflow-x-auto relative"><div class="text-sm mt-3 flex gap-2"><div class="badge rounded badge-primary text-white"> </div> <div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-[rgba(241,99,102,1)] text-white"> </div></div></div></div></div> <div class="pt-0 pr-0"><canvas class="h-48 mt-4 w-full"></canvas></div></div></div></div>'), VC = kp('<div><div class="pb-0"><div class="flex items-end mb-4"><!></div> <div><div class="w-full font-light"><div class="font-normal"> </div> <div class="text-3xl"> </div></div></div></div> <div class="pl-0 pt-0 pr-0"><div class="h-48"></div></div></div>'), OC = kp('<div><div class="pb-0"><div class="flex items-end mb-4"><!></div></div> <div class="pl-0 pt-0 pr-0"><div class="h-48"></div></div></div>'), IC = kp('<div class="hidden"><div class="h-48"></div></div> <!> <!> <!> <!>', 1);
function NC(t2, e2) {
  ld(e2, false);
  const i2 = Sd(), s2 = Sd(), n2 = Sd(), r2 = Sd(), o2 = Sd(), a2 = Sd(), l2 = Sd(), h2 = Sd(), c2 = Sd(), u2 = Sd(), d2 = Sd(), f2 = Sd(), g2 = Sd(), v2 = Sd(), b2 = Sd(), _2 = Sd(), y2 = Sd(), w2 = Sd(), x2 = (t3) => {
    var e3 = EC(), i3 = Yd(e3);
    let s3;
    var n3 = Kd(i3, true);
    Ld(i3);
    var r3 = Gd(i3, 2);
    let o3;
    var a3 = Kd(r3, true);
    Ld(r3);
    var l3 = Gd(r3, 2);
    let h3;
    var c3 = Kd(l3, true);
    Ld(l3), of((t4, e4, u3, d3, f3, p2) => {
      s3 = lm(i3, 1, "btn btn-xs ml-2", null, s3, t4), Vp(n3, e4), o3 = lm(r3, 1, "btn btn-xs ml-2", null, o3, u3), Vp(a3, d3), h3 = lm(l3, 1, "btn btn-primary btn-xs ml-2", null, h3, f3), Vp(c3, p2);
    }, [() => ({ "btn-primary": 252 == rp(P2) }), () => Zc(), () => ({ "btn-primary": 60 == rp(P2) }), () => tu(), () => ({ "btn-primary": 20 == rp(P2) }), () => Bc()], vd), bp("click", i3, () => ct2(252)), bp("click", r3, () => ct2(60)), bp("click", l3, () => ct2(20)), zp(t3, e3);
  };
  Chart.register(LinearScale, BarController, CategoryScale, BarElement, sx);
  let k2 = Jm(e2, "browser", 12), S2 = Jm(e2, "report", 12), M2 = Jm(e2, "theme", 12), z2 = Jm(e2, "lang", 12, "en"), C2 = Jm(e2, "chartTab", 12, "sharpe");
  function R2(t3, e3) {
    let i3 = 0;
    for (let s3 = 0; s3 < t3.length; s3++) t3[s3] > e3[s3] && i3++;
    return i3 / t3.length;
  }
  let P2 = Sd(252), T2 = Sd(), E2 = null, A2 = Sd(), L2 = null, V2 = Sd(), O2 = null, I2 = Sd(), N2 = null, F2 = Sd(), B2 = null, q2 = Sd(), U2 = null;
  function K2(t3, e3) {
    return rp(b2) ? rp(b2).map((i3) => {
      const s3 = t3[i3].value, n3 = e3[i3].value;
      return s3 > n3 ? 1 : s3 < n3 ? 0 : 0.5;
    }).reduce((t4, e4) => t4 + e4, 0) : 0;
  }
  let G2 = Sd(), J2 = null, Q2 = Sd(false);
  function tt2() {
    k2() && (function() {
      if (rp(V2)) {
        if (O2) try {
          O2.chart.remove();
        } catch (t3) {
        }
        O2 = new TwChart(rp(V2), false), O2.setTheme(Px(M2())), O2.resetAreaSeries(0), O2.resetAreaSeries(1), O2.series[0].setData(rp(r2)), O2.series[1].setData(rp(o2)), O2.setTimeScale(new Date(rp(r2)[0].time), new Date(rp(r2)[rp(r2).length - 1].time));
      }
    }(), "sharpe" === C2() ? (function() {
      if (rp(T2)) {
        if (E2) try {
          E2.chart.remove();
        } catch (t3) {
        }
        E2 = new TwChart(rp(T2), false), E2.setTheme(Px(M2())), E2.resetAreaSeries(0), E2.resetAreaSeries(1), E2.series[0].setData(rp(i2)), E2.series[1].setData(rp(s2)), E2.setTimeScale(new Date(rp(i2)[0].time), new Date(rp(i2)[rp(i2).length - 1].time));
      }
    }(), at2()) : "tailRatio" === C2() ? (function() {
      var _a3;
      if (rp(F2)) {
        if (B2) try {
          B2.chart.remove();
        } catch (t3) {
        }
        B2 = new TwChart(rp(F2), false), B2.setTheme(Px(M2())), B2.resetAreaSeries(0), B2.resetAreaSeries(1), B2.series[0].setData(rp(c2)), B2.series[1].setData(rp(u2)), B2.setTimeScale(new Date(rp(c2)[0].time), new Date((_a3 = rp(c2)[rp(i2).length - 1]) == null ? void 0 : _a3.time));
      }
    }(), at2()) : "volatility" === C2() ? function() {
      var _a3;
      if (rp(I2)) {
        if (N2) try {
          N2.chart.remove();
        } catch (t3) {
        }
        N2 = new TwChart(rp(I2), false), N2.setTheme(Px(M2())), N2.resetAreaSeries(0), N2.resetAreaSeries(1), N2.series[0].setData(rp(a2)), N2.series[1].setData(rp(l2)), N2.setTimeScale(new Date(rp(a2)[0].time), new Date((_a3 = rp(a2)[rp(a2).length - 1]) == null ? void 0 : _a3.time));
      }
    }() : "correlation" === C2() && function() {
      if (rp(G2)) {
        if (J2) try {
          J2.chart.remove();
        } catch (t3) {
        }
        J2 = new TwChart(rp(G2), false), J2.setTheme(Px(M2())), J2.resetAreaSeries(0), J2.series[0].setData(rp(w2));
      }
    }());
  }
  function et2(t3, e3) {
    return t3.map((t4, i3) => t4 < e3[i3] ? Ax : Tx(M2()));
  }
  function at2() {
    if (rp(A2)) {
      L2 && L2.destroy();
      var t3 = rp(A2).getContext("2d");
      L2 = new Chart(t3, { type: "bar", data: { labels: rp(v2), datasets: [{ label: zt(), data: rp(b2).map((t4) => rp(i2)[t4].value), backgroundColor: et2(rp(b2).map((t4) => rp(i2)[t4].value), rp(b2).map((t4) => rp(s2)[t4].value)), borderWidth: 0, barPercentage: 0.5 }, { label: m(), data: rp(b2).map((t4) => rp(s2)[t4].value), backgroundColor: $x("77"), borderWidth: 0, barPercentage: 0.5 }] }, options: mC({ theme: M2() }) });
    }
    if (rp(q2)) {
      U2 && U2.destroy();
      var e3 = rp(q2).getContext("2d");
      U2 = new Chart(e3, { type: "bar", data: { labels: rp(v2), datasets: [{ label: Lt(), data: rp(b2).map((t4) => rp(c2)[t4].value), backgroundColor: et2(rp(b2).map((t4) => rp(c2)[t4].value), rp(b2).map((t4) => rp(u2)[t4].value)), borderWidth: 0, barPercentage: 0.5 }, { label: m(), data: rp(b2).map((t4) => rp(u2)[t4].value), backgroundColor: $x("77"), borderWidth: 0, barPercentage: 0.5 }] }, options: mC({ theme: M2() }) });
    }
  }
  async function ct2(t3) {
    zd(P2, t3), await np(), tt2();
  }
  Bp(() => {
    k2() && (zd(Q2, true), tt2());
  }), jp(() => {
    L2 && L2.destroy(), U2 && U2.destroy();
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(i2, S2().calculateSharpe("strategy", 0, rp(P2)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(s2, S2().calculateSharpe("benchmark", 0, rp(P2)));
  }), sf(() => (rp(i2), rp(s2)), () => {
    zd(n2, R2(rp(i2).map((t3) => t3.value), rp(s2).map((t3) => t3.value)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(r2, S2().calculateSortino("strategy", 0, rp(P2)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(o2, S2().calculateSortino("benchmark", 0, rp(P2)));
  }), sf(() => (hp(S2()), rp(r2)), () => {
    zd(a2, S2().calculateVolitility("strategy", 0, 10).slice(-rp(r2).length));
  }), sf(() => (hp(S2()), rp(r2)), () => {
    zd(l2, S2().calculateVolitility("benchmark", 0, 10).slice(-rp(r2).length));
  }), sf(() => (rp(a2), rp(l2)), () => {
    zd(h2, R2(rp(a2).map((t3) => t3.value), rp(l2).map((t3) => t3.value)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(c2, S2().calculateTailRatio("strategy", rp(P2)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(u2, S2().calculateTailRatio("benchmark", rp(P2)));
  }), sf(() => (rp(c2), rp(u2)), () => {
    zd(d2, R2(rp(c2).map((t3) => t3.value), rp(u2).map((t3) => t3.value)));
  }), sf(() => rp(i2), () => {
    zd(f2, rp(i2) ? parseInt(rp(i2)[0].time.slice(0, 4)) : 0);
  }), sf(() => rp(i2), () => {
    zd(g2, rp(i2) ? parseInt(rp(i2)[rp(i2).length - 1].time.slice(0, 4)) : 0);
  }), sf(() => (rp(g2), rp(f2)), () => {
    zd(v2, Array.from(Array(rp(g2) + 1).keys()).slice(rp(f2)));
  }), sf(() => (rp(v2), hp(S2()), rp(i2)), () => {
    zd(b2, rp(v2) ? rp(v2).map((t3) => Math.max(Math.min(S2().indexOfTimestamps(t3 + "-12-31") - 249, rp(i2).length - 1), 0)) : []);
  }), sf(() => (rp(i2), rp(s2)), () => {
    zd(_2, K2(rp(i2), rp(s2)));
  }), sf(() => (rp(c2), rp(u2)), () => {
    zd(y2, K2(rp(c2), rp(u2)));
  }), sf(() => (hp(S2()), rp(P2)), () => {
    zd(w2, S2().calculateCorrelation(rp(P2)));
  }), sf(() => (rp(Q2), hp(C2()), hp(M2()), np), () => {
    rp(Q2) && (C2() || M2()) && np().then(() => tt2());
  }), nf(), Om();
  var dt2 = IC(), mt2 = Yd(dt2);
  Vm(Kd(mt2), (t3) => zd(V2, t3), () => rp(V2)), Ld(mt2);
  var gt2 = Gd(mt2, 2), bt2 = (t3) => {
    var e3 = AC(), i3 = Kd(e3), s3 = Kd(i3), r3 = Kd(s3), o3 = Kd(r3), a3 = Kd(o3);
    x2(a3), Ld(o3);
    var l3 = Gd(o3, 2), h3 = Kd(l3), c3 = Kd(h3), u3 = Kd(c3), d3 = Kd(u3, true);
    Ld(u3);
    var f3 = Gd(u3, 2), g3 = Kd(f3);
    Ld(f3), Ld(c3), Ld(h3), Ld(l3), Ld(r3);
    var v3 = Gd(r3, 2);
    Vm(Kd(v3), (t4) => zd(T2, t4), () => rp(T2)), Ld(v3), Ld(s3);
    var y3 = Gd(s3, 2), w3 = Kd(y3), k3 = Kd(w3), S3 = Kd(k3), M3 = Kd(S3);
    Ld(S3);
    var z3 = Gd(S3, 2), C3 = Kd(z3), R3 = Kd(C3), P3 = Kd(R3, true);
    Ld(R3);
    var E3 = Gd(R3, 2), L3 = Kd(E3, true);
    Ld(E3);
    var V3 = Gd(E3, 2), O3 = Kd(V3, true);
    Ld(V3), Ld(C3), Ld(z3), Ld(k3), Ld(w3);
    var I3 = Gd(w3, 2);
    Vm(Kd(I3), (t4) => zd(A2, t4), () => rp(A2)), Ld(I3), Ld(y3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n3, r4, o4) => {
      Vp(d3, t4), Vp(g3, `${e4 ?? ""}％`), Vp(M3, `${i4 ?? ""}
						${rp(_2) ?? ""} / ${rp(b2).length ?? ""}
						${s4 ?? ""}`), Vp(P3, n3), Vp(L3, r4), Vp(O3, o4);
    }, [() => vs(), () => (100 * rp(n2)).toFixed(2), () => vs(), () => gs(), () => p(), () => m(), () => Ot()], vd), zp(t3, e3);
  };
  Hp(gt2, (t3) => {
    "sharpe" === C2() && t3(bt2);
  });
  var _t3 = Gd(gt2, 2), yt2 = (t3) => {
    var e3 = LC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), o3 = Kd(r3);
    x2(o3), Ld(r3);
    var a3 = Gd(r3, 2), l3 = Kd(a3), h3 = Kd(l3), c3 = Kd(h3), u3 = Kd(c3, true);
    Ld(c3);
    var f3 = Gd(c3, 2), g3 = Kd(f3);
    Ld(f3), Ld(h3), Ld(l3), Ld(a3), Ld(n3);
    var v3 = Gd(n3, 2);
    Vm(Kd(v3), (t4) => zd(F2, t4), () => rp(F2)), Ld(v3), Ld(s3);
    var _3 = Gd(s3, 2), w3 = Kd(_3), k3 = Kd(w3), S3 = Kd(k3), M3 = Kd(S3);
    Ld(S3);
    var z3 = Gd(S3, 2), C3 = Kd(z3), R3 = Kd(C3), P3 = Kd(R3, true);
    Ld(R3);
    var T3 = Gd(R3, 2), E3 = Kd(T3, true);
    Ld(T3);
    var A3 = Gd(T3, 2), L3 = Kd(A3, true);
    Ld(A3), Ld(C3), Ld(z3), Ld(k3), Ld(w3);
    var V3 = Gd(w3, 2);
    Vm(Kd(V3), (t4) => zd(q2, t4), () => rp(q2)), Ld(V3), Ld(_3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n4, r4, o4) => {
      Vp(u3, t4), Vp(g3, `${e4 ?? ""}％`), Vp(M3, `${i4 ?? ""}
						${rp(y2) ?? ""} / ${rp(b2).length ?? ""}
						${s4 ?? ""}`), Vp(P3, n4), Vp(E3, r4), Vp(L3, o4);
    }, [() => vs(), () => (100 * rp(d2)).toFixed(2), () => vs(), () => gs(), () => p(), () => m(), () => Ot()], vd), zp(t3, e3);
  };
  Hp(_t3, (t3) => {
    "tailRatio" === C2() && t3(yt2);
  });
  var wt2 = Gd(_t3, 2), xt2 = (t3) => {
    var e3 = VC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3);
    x2(n3), Ld(s3);
    var r3 = Gd(s3, 2), o3 = Kd(r3), a3 = Kd(o3), l3 = Kd(a3, true);
    Ld(a3);
    var c3 = Gd(a3, 2), u3 = Kd(c3);
    Ld(c3), Ld(o3), Ld(r3), Ld(i3);
    var d3 = Gd(i3, 2);
    Vm(Kd(d3), (t4) => zd(I2, t4), () => rp(I2)), Ld(d3), Ld(e3), of((t4, e4) => {
      Vp(l3, t4), Vp(u3, `${e4 ?? ""}％`);
    }, [() => vs(), () => (100 * rp(h2)).toFixed(2)], vd), zp(t3, e3);
  };
  Hp(wt2, (t3) => {
    "volatility" === C2() && t3(xt2);
  });
  var kt2 = Gd(wt2, 2), Mt2 = (t3) => {
    var e3 = OC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3);
    x2(n3), Ld(s3), Ld(i3);
    var r3 = Gd(i3, 2);
    Vm(Kd(r3), (t4) => zd(G2, t4), () => rp(G2)), Ld(r3), Ld(e3), zp(t3, e3);
  };
  return Hp(kt2, (t3) => {
    "correlation" === C2() && t3(Mt2);
  }), zp(t2, dt2), hd({ get browser() {
    return k2();
  }, set browser(t3) {
    k2(t3), sp();
  }, get report() {
    return S2();
  }, set report(t3) {
    S2(t3), sp();
  }, get theme() {
    return M2();
  }, set theme(t3) {
    M2(t3), sp();
  }, get lang() {
    return z2();
  }, set lang(t3) {
    z2(t3), sp();
  }, get chartTab() {
    return C2();
  }, set chartTab(t3) {
    C2(t3), sp();
  } });
}
tg(NC, { browser: {}, report: {}, theme: {}, lang: {}, chartTab: {} }, [], [], true);
var FC = kp('<div><div class="flex flex-col justify-center items-center"><div class="text-medium"> </div> <div> </div></div></div>'), WC = kp('<div><div class="rounded-lg"><div class="pb-0"><div><div><div class="carousel carousel-center max-w-full space-x-2 overflow-x-auto"></div></div></div></div> <div class="relative"><div class="text-primary h-64 z-0"></div> <div class="-mt-24 mb-12 mr-20 text-right"><div class="stat-title"> </div> <div class="stat-value"><span> </span> <span class="text-sm"> </span></div></div></div></div></div>'), BC = kp('<div><div class="rounded-lg"><div><h4 class="text-base-content/70 text-xl font-light mb-3"> </h4> <!></div></div></div>'), jC = kp('<div class="flex flex-col justify-center items-center text-sm rounded-full pb-4 hover:cursor-pointer hover:text-base hover:-mt-6 hover:shadow-2xl hover:shadow-primary"><div class="mt-3 border-b border-base-content/20 pb-4 px-2 text-center w-full"> <br/> </div> <div><div></div> <div></div></div> <div> <br/>% <br/></div></div>'), qC = kp('<div><div class="text-center relative rounded-lg"><div><div><div class="flex justify-center gap-2"><button> </button> <button> </button></div> <div><div class="grid grid-cols-5 justify-start items-start mt-6"></div></div> <div class="absolute inset-x-0 bottom-0 flex justify-center my-3 text-sm gap-2" style="direction:rtl"><div class="badge rounded bg-gray-500 text-white"> </div> <div class="badge rounded bg-primary text-white"> </div></div></div></div></div></div>'), HC = kp('<div class="flex flex-col justify-center items-center text-sm rounded-full pb-4 hover:cursor-pointer hover:text-base hover:-mt-6 hover:shadow-2xl hover:shadow-primary"><div class="mt-3 border-b border-base-content/20 pb-4 px-2 text-center w-full"> <br/> </div> <div><div></div></div> <div> <br/> </div></div>'), UC = kp('<div><div class="rounded-lg text-center"><div><div><div class="flex justify-center gap-2"><span> </span> <span> </span></div> <div><div class="flex justify-between items-start mt-6 text-sm"></div></div> <div class="relative inset-x-0 bottom-0 flex justify-center my-3 text-sm" style="direction:rtl"><div class="badge rounded badge-primary text-white"> </div></div></div></div></div></div>'), KC = kp('<div><div class="rounded-lg"><div class="text-primary h-48 z-0"></div></div></div>'), YC = kp("<!> <!> <!> <!> <!>", 1);
function GC(t2, e2) {
  ld(e2, false);
  const [i2, s2] = Hm(), n2 = () => qm(Lx, "$themeChoice", i2), r2 = Sd(), o2 = Sd(), a2 = Sd(), l2 = Sd(), h2 = Sd(), c2 = Sd(), u2 = Sd(), d2 = Sd(), f2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  let p2 = Jm(e2, "browser", 12), m2 = Jm(e2, "report", 12), g2 = Jm(e2, "chartTab", 12, "drawdownPeriods");
  function v2(t3) {
    return "light" === t3 || "dark" === t3 ? t3 : "undefined" != typeof document && "dark" === document.documentElement.getAttribute("data-theme") ? "dark" : "light";
  }
  let b2 = Sd(), _2 = Sd(), y2 = null, w2 = null, x2 = Sd(null), k2 = Sd(null), S2 = Sd(null);
  function M2(t3, e3) {
    if (y2) if ("string" == typeof t3 && "string" == typeof e3) {
      const i3 = new Date(t3), s3 = new Date(e3);
      y2.setTimeScale(i3, s3), zd(x2, R2({ start: t3, end: e3 })), zd(x2, ((i3 - s3) / 864e5).toFixed(0)), zd(k2, i3), zd(S2, s3);
    } else {
      const i3 = m2().indexOfTimestamps(t3), s3 = m2().indexOfTimestamps(e3), n3 = new Date(m2().timestamps[i3]), r3 = new Date(m2().timestamps[s3]);
      y2.setTimeScale(n3, r3), zd(k2, n3), zd(S2, r3);
    }
  }
  function z2(t3) {
    if (!rp(b2)) return;
    if (y2) try {
      y2.chart.remove();
    } catch (t4) {
    }
    y2 = new TwChart(rp(b2), true), y2.setTheme(v2(rp(r2)));
    const e3 = m2().timestamps.length / 1, i3 = m2().createTradingviewSeries("strategy", 0, -1, e3), s3 = m2().createTradingviewSeries("benchmark", 0, -1, e3);
    y2.resetAreaSeries(0), y2.resetAreaSeries(1), y2.series[0].setData(i3), y2.series[1].setData(s3), y2.chart.subscribeCrosshairMove((t4) => {
    }), y2.chart.subscribeClick((t4) => {
    }), y2.chart.timeScale().subscribeVisibleTimeRangeChange((t4) => {
    });
  }
  let C2 = Sd("strategy");
  const R2 = (t3) => ((new Date(m2().timestamps[t3.end]) - new Date(m2().timestamps[t3.start])) / 864e5).toFixed(0);
  let P2 = Sd(false);
  function T2() {
    if ("drawdownPeriods" === g2() && rp(b2)) {
      const t3 = rp(l2)[0];
      z2(), M2(m2().timestamps[t3.start], m2().timestamps[t3.end]);
    }
    "drawdownPercentage" === g2() && function() {
      if (rp(_2)) {
        if (w2) try {
          w2.chart.remove();
        } catch (t3) {
        }
        w2 = new TwChart(rp(_2), false), w2.setTheme(v2(rp(r2))), w2.resetAreaSeries(0), w2.resetAreaSeries(1), w2.series[0].setData(rp(o2)), w2.series[1].setData(rp(a2)), w2.setTimeScale(new Date(m2().timestamps[0]), new Date(m2().timestamps[m2().timestamps.length - 1]));
      }
    }();
  }
  Bp(() => {
    p2() && (zd(P2, true), T2());
  }), sf(() => n2(), () => {
    zd(r2, n2());
  }), sf(() => hp(m2()), () => {
    zd(o2, m2().createTradingViewDrawdown("strategy", m2().timestamps.length));
  }), sf(() => hp(m2()), () => {
    zd(a2, m2().createTradingViewDrawdown("benchmark", m2().timestamps.length));
  }), sf(() => (rp(l2), rp(h2), hp(m2())), () => {
    var t3;
    t3 = Bu(m2().calculateDrawdown("strategy"), 2), zd(l2, t3[0]), zd(h2, t3[1]);
  }), sf(() => (rp(c2), rp(u2), hp(m2())), () => {
    var t3;
    t3 = Bu(m2().calculateDrawdown("benchmark"), 2), zd(c2, t3[0]), zd(u2, t3[1]);
  }), sf(() => rp(l2), () => {
    zd(d2, rp(l2)[0]);
  }), sf(() => (rp(P2), hp(g2()), rp(r2), np), () => {
    rp(P2) && (g2() || rp(r2)) && np().then(() => T2());
  }), nf(), Om();
  var E2 = YC(), A2 = Yd(E2), L2 = (t3) => {
    var e3 = WC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), o3 = Kd(r3);
    Yp(o3, 5, () => rp(l2), Kp, (t4, e4) => {
      var i4 = FC(), s4 = Kd(i4), n4 = Kd(s4), r4 = Kd(n4, true);
      Ld(n4);
      var o4 = Gd(n4, 2), a4 = Kd(o4);
      Ld(o4), Ld(s4), Ld(i4), of((t5, s5, n5) => {
        lm(i4, 1, "cursor-pointer carousel-item px-5 py-3 rounded-lg border transition-all duration-300 " + (rp(d2) === rp(e4) ? "border-primary shadow-sm" : "border-base-content/20")), Vp(r4, t5), lm(o4, 1, `text-sm ${s5 ?? ""}`), Vp(a4, `${n5 ?? ""}%`);
      }, [() => m2().timestamps[rp(e4).start].slice(0, 4), () => zz(-1), () => (100 * rp(e4).maxDrawdown).toFixed(1)], vd), bp("click", i4, () => {
        z2(), M2(m2().timestamps[rp(e4).start], m2().timestamps[rp(e4).end]), zd(d2, rp(e4));
      }), zp(t4, i4);
    }), Ld(o3), Ld(r3), Ld(n3), Ld(s3);
    var a3 = Gd(s3, 2), h3 = Kd(a3);
    Vm(h3, (t4) => zd(b2, t4), () => rp(b2));
    var c3 = Gd(h3, 2), u3 = Kd(c3), f3 = Kd(u3, true);
    Ld(u3);
    var p3 = Gd(u3, 2), g3 = Kd(p3), v3 = Kd(g3, true);
    Ld(g3);
    var _3 = Gd(g3, 2), y3 = Kd(_3, true);
    Ld(_3), Ld(p3), Ld(c3), Ld(a3), Ld(i3), Ld(e3), of((t4, e4, i4) => {
      Vp(f3, t4), Vp(v3, e4), Vp(y3, i4);
    }, [() => Yc(), () => Math.abs(rp(x2)), () => Gc()], vd), zp(t3, e3);
  };
  Hp(A2, (t3) => {
    "drawdownPeriods" === g2() && t3(L2);
  });
  var V2 = Gd(A2, 2), O2 = (t3) => {
    var e3 = BC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), o3 = Kd(n3);
    Ld(n3), fC(Gd(n3, 2), { get report() {
      return m2();
    }, get theme() {
      return rp(r2);
    }, get browser() {
      return p2();
    }, get tstart() {
      return rp(k2);
    }, get tend() {
      return rp(S2);
    } }), Ld(s3), Ld(i3), Ld(e3), of((t4, e4) => Vp(o3, `${t4 ?? ""}~${e4 ?? ""}`), [() => {
      var _a3;
      return (_a3 = rp(k2)) == null ? void 0 : _a3.toLocaleDateString();
    }, () => {
      var _a3;
      return (_a3 = rp(S2)) == null ? void 0 : _a3.toLocaleDateString();
    }], vd), zp(t3, e3);
  };
  Hp(V2, (t3) => {
    "stockList" === g2() && t3(O2);
  });
  var I2 = Gd(V2, 2), N2 = (t3) => {
    var e3 = qC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), h3 = Kd(r3), u3 = Kd(h3, true);
    Ld(h3);
    var p3 = Gd(h3, 2), g3 = Kd(p3, true);
    Ld(p3), Ld(r3);
    var v3 = Gd(r3, 2), b3 = Kd(v3);
    Yp(b3, 5, () => "strategy" === rp(C2) ? rp(l2) : rp(c2), Kp, (t4, e4) => {
      var i4 = jC(), s4 = Kd(i4), n4 = Kd(s4), r4 = Gd(n4, 2);
      Ld(s4);
      var h4 = Gd(s4, 2), u4 = Kd(h4), p4 = Gd(u4, 2);
      Ld(h4);
      var g4 = Gd(h4, 2), v4 = Kd(g4, true);
      Vd(3), Ld(g4), Ld(i4), of((t5, e5, i5, s5, o3) => {
        Vp(n4, `${t5 ?? ""} `), Vp(r4, ` ${e5 ?? ""}`), lm(h4, 1, "flex justify-center " + ("benchmark" === rp(C2) ? "flex-row-reverse" : "")), cm(u4, i5), lm(u4, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === rp(C2) ? "bg-primary" : "bg-gray-400")), cm(p4, s5), lm(p4, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === rp(C2) ? "bg-gray-400" : "bg-primary")), lm(g4, 1, `w-20 pt-2 text-center text-primary ${0 === f2 ? "text-2xl font-bold" : ""} ${"strategy" === rp(C2) ? "text-primary" : "text-gray-400"}`), Vp(v4, o3);
      }, [() => m2().timestamps[rp(e4).at].slice(0, 4), () => jc({ v1: m2().timestamps[rp(e4).at].slice(5, 7) }), () => `height:${(rp(e4).maxDrawdown / rp(l2)[0].maxDrawdown * 160).toFixed(0)}px`, () => `height:${(("strategy" === rp(C2) ? rp(a2) : rp(o2))[rp(e4).at].value / 100 / Math.max(rp(l2)[0].maxDrawdown, rp(c2)[0].maxDrawdown) * 160).toFixed(0)}px`, () => (100 * rp(e4).maxDrawdown).toFixed(1)], vd), bp("click", i4, () => {
        z2(), M2(m2().timestamps[rp(e4).start], m2().timestamps[rp(e4).end]), zd(d2, rp(e4));
      }), zp(t4, i4);
    }), Ld(b3), Ld(v3);
    var _3 = Gd(v3, 2), y3 = Kd(_3), w3 = Kd(y3, true);
    Ld(y3);
    var x3 = Gd(y3, 2), k3 = Kd(x3, true);
    Ld(x3), Ld(_3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      lm(h3, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 rounded-xl " + ("strategy" === rp(C2) ? "outline outline-primary" : "")), Vp(u3, t4), lm(p3, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 rounded-xl " + ("benchmark" === rp(C2) ? "outline outline-primary" : "")), Vp(g3, e4), Vp(w3, i4), Vp(k3, s4);
    }, [() => f2("metrics.risk.worst10Strategy"), () => f2("metrics.risk.worst10Benchmark"), () => f2("benchmark"), () => f2("strategy")], vd), bp("click", h3, () => {
      zd(C2, "strategy");
    }), bp("click", p3, () => {
      zd(C2, "benchmark");
    }), zp(t3, e3);
  };
  Hp(I2, (t3) => {
    "drawdownRanking" === g2() && t3(N2);
  });
  var F2 = Gd(I2, 2), B2 = (t3) => {
    var e3 = UC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), o3 = Kd(r3), a3 = Kd(o3, true);
    Ld(o3);
    var l3 = Gd(o3, 2), c3 = Kd(l3, true);
    Ld(l3), Ld(r3);
    var p3 = Gd(r3, 2), g3 = Kd(p3);
    Yp(g3, 5, () => "strategy" === rp(C2) ? rp(h2) : rp(u2), Kp, (t4, e4) => {
      var i4 = HC(), s4 = Kd(i4), n4 = Kd(s4), r4 = Gd(n4, 2);
      Ld(s4);
      var o4 = Gd(s4, 2), a4 = Kd(o4);
      Ld(o4);
      var l4 = Gd(o4, 2), c4 = Kd(l4), p4 = Gd(c4, 2);
      Ld(l4), Ld(i4), of((t5, e5, i5, s5, o5) => {
        Vp(n4, `${t5 ?? ""} `), Vp(r4, ` ${e5 ?? ""}`), cm(a4, i5), lm(a4, 1, "w-3 rounded-b-full mx-1 " + ("strategy" === rp(C2) ? "bg-primary" : "bg-gray-400")), lm(l4, 1, `w-14 pt-2 text-center ${0 === f2 ? "text-2xl font-bold" : ""} ${"strategy" === rp(C2) ? "text-primary" : "text-gray-400"}`), Vp(c4, `${s5 ?? ""} `), Vp(p4, ` ${o5 ?? ""}`);
      }, [() => m2().timestamps[rp(e4).at].slice(0, 4), () => jc({ v1: m2().timestamps[rp(e4).at].slice(5, 7) }), () => `height:${(R2(rp(e4)) / Math.min(R2(rp(h2)[0]), R2(rp(u2)[0])) * 160).toFixed(0)}px`, () => R2(rp(e4)), () => f2("metrics.risk.days")], vd), bp("click", i4, () => {
        z2(), M2(m2().timestamps[rp(e4).start], m2().timestamps[rp(e4).end]), zd(d2, rp(e4));
      }), zp(t4, i4);
    }), Ld(g3), Ld(p3);
    var v3 = Gd(p3, 2), b3 = Kd(v3), _3 = Kd(b3, true);
    Ld(b3), Ld(v3), Ld(n3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4) => {
      lm(o3, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 cursor-pointer rounded-xl " + ("strategy" === rp(C2) ? "outline outline-primary" : "")), Vp(a3, t4), lm(l3, 1, "border border-base-content/10 text-sm hover:badge-primary hover:text-white px-2 py-1 cursor-pointer rounded-xl " + ("benchmark" === rp(C2) ? "outline outline-primary" : "")), Vp(c3, e4), Vp(_3, i4);
    }, [() => f2("metrics.risk.worst10Strategy"), () => f2("metrics.risk.worst10Benchmark"), () => f2("strategy")], vd), bp("click", o3, () => {
      zd(C2, "strategy");
    }), bp("click", l3, () => {
      zd(C2, "benchmark");
    }), zp(t3, e3);
  };
  Hp(F2, (t3) => {
    "recoveryTime" === g2() && t3(B2);
  });
  var q2 = Gd(F2, 2), U2 = (t3) => {
    var e3 = KC(), i3 = Kd(e3);
    Vm(Kd(i3), (t4) => zd(_2, t4), () => rp(_2)), Ld(i3), Ld(e3), zp(t3, e3);
  };
  Hp(q2, (t3) => {
    "drawdownPercentage" === g2() && t3(U2);
  }), zp(t2, E2);
  var K2 = hd({ get browser() {
    return p2();
  }, set browser(t3) {
    p2(t3), sp();
  }, get report() {
    return m2();
  }, set report(t3) {
    m2(t3), sp();
  }, get chartTab() {
    return g2();
  }, set chartTab(t3) {
    g2(t3), sp();
  } });
  return s2(), K2;
}
tg(GC, { browser: {}, report: {}, chartTab: {} }, [], [], true);
var XC = kp('<div><div><div class="card-content"><span> <span class="font-light"> </span> </span> <canvas class="mt-3 max-h-[400px]"></canvas> <div class="text-sm text-center pb-6 mt-3"> </div></div></div></div>'), JC = kp('<div><div><div class="card-content"><span> <span class="font-bold font-light"> </span></span> <br/> <span> <span class="font-bold font-light"> </span> %</span> <br/> <span> <span class="font-bold font-light"> </span></span> <input type="range" min="0" max="0.3" class="range range-secondary mt-6" step="0.05"/> <div class="w-full flex justify-between text-xs px-2"><span class="font-bold text-sm">0％</span> <span class="font-bold text-sm">5％</span> <span class="font-bold text-sm">10％</span> <span class="font-bold text-sm">15％</span> <span class="font-bold text-sm">20％</span> <span class="font-bold text-sm">25％</span> <span class="font-bold text-sm">30％</span></div> <h3 class="text-2xl font-bold mt-12 mb-6 text-center text-base-content-200"> </h3> <div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div></div>'), QC = kp('<div><div><div class="card-content"><span> <span class="font-bold font-light"> </span></span> <br/> <span> <span class="font-bold font-light"> </span>%</span> <br/> <span> <span class="font-bold font-light"> </span></span> <input type="range" min="0" max="0.3" class="range range-primary mt-6" step="0.05"/> <div class="w-full flex justify-between text-xs px-2"><span class="font-bold text-sm">0％</span> <span class="font-bold text-sm">5％</span> <span class="font-bold text-sm">10％</span> <span class="font-bold text-sm">15％</span> <span class="font-bold text-sm">20％</span> <span class="font-bold text-sm">25％</span> <span class="font-bold text-sm">30％</span></div> <h3 class="text-2xl font-bold mt-12 mb-6 text-center text-base-content-200"> </h3> <div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div></div>'), ZC = kp('<div><div><div class="card-content"><div class="text-base-content-100 text-sm font-bold mt-3"> </div> <canvas class="mt-3"></canvas> <div class="text-base-content-100 text-sm text-center font-bold"> </div></div></div></div>'), tD = kp('<div class="text-base-content-200"><!> <!> <!> <!></div>');
function eD(t2, e2) {
  ld(e2, false);
  const [i2, s2] = Hm(), n2 = () => qm(Lx, "$themeChoice", i2), r2 = Sd(), o2 = Sd(), a2 = Sd(), l2 = Sd(), h2 = Sd(), c2 = Sd(), u2 = Sd(), d2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  let f2 = Jm(e2, "lang", 12, "en"), p2 = Jm(e2, "chartTab", 12, "returnDistribution");
  Chart.register(BubbleController, LinearScale, PointElement, sx, CategoryScale, BarController, BarElement, LineElement, LineController);
  let m2 = Jm(e2, "browser", 12), g2 = Jm(e2, "report", 12), v2 = Sd(0), b2 = Sd(0);
  const _2 = g2().trades.map((t3) => t3.return), y2 = _2.reduce((t3, e3) => t3 + e3, 0) / _2.length, w2 = _2.reduce((t3, e3) => t3 + Math.pow(e3 - y2, 2), 0) / _2.length, x2 = Math.sqrt(w2);
  [..._2].sort((t3, e3) => t3 - e3);
  let k2 = Sd(), S2 = null, M2 = Sd();
  const z2 = function(t3, e3 = 0.95) {
    const i3 = t3;
    return 0 === i3.length ? null : (i3.sort((t4, e4) => t4 - e4), i3[Math.floor((1 - e3) * i3.length)]);
  }(g2().trades.map((t3) => t3.return)), C2 = g2().trades.filter((t3) => t3.return > 0), R2 = g2().trades.filter((t3) => t3.return <= 0);
  function P2(t3, e3, i3, s3) {
    const n3 = Math.max(...g2().trades.map((t4) => Math.abs(t4[e3]))), o3 = Math.max(...g2().trades.map((t4) => Math.abs(t4[i3]))), a3 = g2().trades.map((t4) => Math.log(Math.abs(t4.return) + 1)), l3 = Math.max(...a3), h3 = Math.min(...a3);
    function c3(t4, e4, i4, s4, n4) {
      return (t4 - e4) / (i4 - e4) * (n4 - s4) + s4;
    }
    function u3(t4, i4) {
      const s4 = 0 !== rp(v2) ? rp(v2) : 1;
      return "mae" === e3 ? i4 < -s4 ? -s4 : t4 : "gmfe" === e3 && i4 > rp(b2) && 0 !== rp(b2) ? rp(b2) : t4;
    }
    const d3 = { type: "bubble", data: { datasets: [{ label: "Winning", data: C2.map((t4) => ({ x: Math.abs(t4[e3]), y: Math.abs(u3(t4[i3], t4[e3])), r: c3(Math.log(Math.abs(t4.return) + 1), h3, l3, 3, 20), t: t4 })), backgroundColor: "rgba(99, 102, 241, 0.5)" }, { label: "Losing", data: R2.map((t4) => ({ x: Math.abs(t4[e3]), y: Math.abs(u3(t4[i3], t4[e3])), r: c3(Math.log(Math.abs(t4.return) + 1), h3, l3, 3, 20), t: t4 })), backgroundColor: "rgba(241, 99, 102, 0.5)" }, { label: "45-degree Line", data: [{ x: 0, y: 0 }, { x: 0.5, y: 0.5 }], type: "line", fill: false, borderColor: "rgba(125, 125, 125, 0.8)", pointRadius: 0, borderWidth: 1, tension: 0 }] }, options: { responsive: true, maintainAspectRatio: true, animation: false, scales: { x: { type: "linear", beginAtZero: true, max: Math.min(0.5, n3, o3), ticks: { color: Ex(rp(r2)), callback: (t4, e4, i4) => (100 * t4).toFixed(1) + "%" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, y: { type: "linear", beginAtZero: true, max: Math.min(0.5, o3, n3), ticks: { color: Ex(rp(r2)), callback: (t4, e4, i4) => (100 * t4).toFixed(1) + "%" }, grid: { color: "#77777755", tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false }, zoom: { pan: { enabled: true, mode: "xy" }, zoom: { wheel: { enabled: true }, pinch: { enabled: true }, mode: "xy" } }, tooltip: { callbacks: { title: (t4) => t4[0].raw.t.stockId + " " + t4[0].dataset.label, label(t4) {
      const s4 = t4.raw.x.toFixed(2), n4 = t4.raw.y.toFixed(2);
      return t4.raw.t.stock, `${e3}: ${s4}, ${i3}:${n4}`;
    } } } } } };
    return new Chart(t3, d3);
  }
  let T2 = Sd(), E2 = Sd();
  const A2 = {};
  let L2 = Sd(false);
  function V2() {
    if ("returnDistribution" === p2() && rp(k2)) {
      S2 && (S2.destroy(), S2 = null);
      const t3 = function(t4) {
        const e3 = -3 * x2, i3 = (3 * x2 - e3) / 50, s3 = new Array(50).fill(0), n3 = [];
        t4.forEach((t5) => {
          const n4 = Math.min(Math.floor((t5 - e3) / i3), 49);
          s3[n4]++;
        });
        for (let t5 = 0; t5 < 50; t5++) n3.push([e3 + t5 * i3, e3 + (t5 + 1) * i3]);
        return { bins: s3, ranges: n3 };
      }(_2);
      !function(t4) {
        const e3 = rp(k2), i3 = t4.ranges.map((t5) => t5[0]), s3 = i3.map((t5) => t5 >= 0 ? Tx(rp(r2)) : Ax);
        null !== S2 && S2.destroy(), S2 = new Chart(e3, { type: "bar", data: { labels: i3, datasets: [{ data: t4.bins, backgroundColor: s3 }] }, options: { responsive: true, maintainAspectRatio: true, scales: { x: { type: "category", ticks: { callback: (t5, e4, s4) => (100 * i3[e4]).toFixed(1) + "%", color: Ex(rp(r2)) }, grid: { color: "#77777755", tickBorderDash: [2, 2] } }, y: { type: "linear", ticks: { callback: (t5, e4, i4) => t5 + " trades", color: Ex(rp(r2)) }, grid: { color: "#77777755", tickBorderDash: [2, 2] } } }, plugins: { legend: { display: false } } } });
      }(t3);
    }
    "maeMfe" === p2() && rp(M2) && (A2.maemfe && A2.maemfe.destroy(), A2.maemfe = P2(rp(M2), "mae", "gmfe")), "stopLoss" === p2() && rp(T2) && (A2.mae && A2.mae.destroy(), A2.mae = P2(rp(T2), "mae", "return")), "takeProfit" === p2() && rp(E2) && (A2.mfe && A2.mfe.destroy(), A2.mfe = P2(rp(E2), "gmfe", "return"));
  }
  Bp(() => {
    m2() && (zd(L2, true), V2());
  }), jp(() => {
    var _a3, _b3, _c3;
    (_a3 = A2.maemfe) == null ? void 0 : _a3.destroy(), (_b3 = A2.mae) == null ? void 0 : _b3.destroy(), (_c3 = A2.mfe) == null ? void 0 : _c3.destroy(), S2 == null ? void 0 : S2.destroy();
  }), sf(() => n2(), () => {
    zd(r2, n2());
  }), sf(() => (hp(g2()), rp(v2)), () => {
    zd(o2, g2().trades.filter((t3) => t3.mae < -rp(v2)).map((t3) => t3.return));
  }), sf(() => (rp(v2), rp(o2)), () => {
    zd(a2, 0 === rp(v2) ? 0 : rp(o2).reduce((t3, e3) => t3 + e3, 0) / rp(o2).length + rp(v2) || 0);
  }), sf(() => (rp(v2), rp(o2), hp(g2())), () => {
    zd(l2, 0 === rp(v2) ? 0 : rp(o2).length / g2().trades.length);
  }), sf(() => (hp(g2()), rp(b2)), () => {
    zd(h2, g2().trades.filter((t3) => t3.gmfe > rp(b2)).map((t3) => t3.return));
  }), sf(() => (rp(b2), rp(h2)), () => {
    zd(c2, 0 === rp(b2) ? 0 : rp(h2).reduce((t3, e3) => t3 + e3, 0) / rp(h2).length - rp(b2) || 0);
  }), sf(() => (rp(b2), rp(h2), hp(g2())), () => {
    zd(u2, 0 === rp(b2) ? 0 : rp(h2).length / g2().trades.length);
  }), sf(() => (rp(L2), hp(p2()), rp(r2), rp(v2), rp(b2), np), () => {
    rp(L2) && (p2(), rp(r2), rp(v2), rp(b2), np().then(() => V2()));
  }), nf(), Om();
  var O2 = tD(), I2 = Kd(O2), N2 = (t3) => {
    var e3 = XC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), o3 = Gd(r3), a3 = Kd(o3, true);
    Ld(o3);
    var l3 = Gd(o3);
    Ld(n3);
    var h3 = Gd(n3, 2);
    Vm(h3, (t4) => zd(k2, t4), () => rp(k2));
    var c3 = Gd(h3, 2), u3 = Kd(c3, true);
    Ld(c3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4) => {
      Vp(r3, `${t4 ?? ""} `), Vp(a3, e4), Vp(l3, ` ${i4 ?? ""}`), Vp(u3, s4);
    }, [() => d2("metrics.winrate.distributionInfo1"), () => (100 * z2).toFixed(1), () => d2("metrics.winrate.distributionInfo2"), () => d2("metrics.winrate.return")], vd), zp(t3, e3);
  };
  Hp(I2, (t3) => {
    "returnDistribution" === p2() && t3(N2);
  });
  var F2 = Gd(I2, 2), B2 = (t3) => {
    var e3 = JC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3), o3 = Gd(r3), h3 = Kd(o3, true);
    Ld(o3), Ld(n3);
    var c3 = Gd(n3, 4), u3 = Kd(c3), f3 = Gd(u3), p3 = Kd(f3, true);
    Ld(f3), Vd(), Ld(c3);
    var m3 = Gd(c3, 4), g3 = Kd(m3), b3 = Gd(g3), _3 = Kd(b3);
    Ld(b3), Ld(m3);
    var y3 = Gd(m3, 2);
    vm(y3);
    var w3 = Gd(y3, 4), x3 = Kd(w3, true);
    Ld(w3);
    var k3 = Gd(w3, 2), S3 = Kd(k3, true);
    Ld(k3);
    var M3 = Gd(k3, 2);
    Vm(M3, (t4) => zd(T2, t4), () => rp(T2));
    var z3 = Gd(M3, 2), C3 = Kd(z3, true);
    Ld(z3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n4, o4, a3, l3, c4) => {
      Vp(r3, `${t4 ?? ""} `), Vp(h3, e4), Vp(u3, `${i4 ?? ""} `), Vp(p3, s4), Vp(g3, `${n4 ?? ""} `), Vp(_3, `${o4 ?? ""}%`), Vp(x3, a3), Vp(S3, l3), Vp(C3, c4);
    }, [() => d2("metrics.winrate.stoploss"), () => 0 !== rp(v2) ? 100 * rp(v2) + "%" : d2("metrics.winrate.none"), () => d2("metrics.winrate.extraProfitLoss"), () => (rp(a2) > 0 ? "+" : "") + (100 * rp(a2)).toFixed(1), () => d2("metrics.winrate.stoplossRatio"), () => (100 * rp(l2)).toFixed(1), () => d2("metrics.winrate.maeReturn"), () => d2("metrics.winrate.return"), () => d2("metrics.winrate.mae")], vd), $m(y3, () => rp(v2), (t4) => zd(v2, t4)), zp(t3, e3);
  };
  Hp(F2, (t3) => {
    "stopLoss" === p2() && t3(B2);
  });
  var q2 = Gd(F2, 2), U2 = (t3) => {
    var e3 = QC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3, true), o3 = Gd(r3), a3 = Kd(o3, true);
    Ld(o3), Ld(n3);
    var l3 = Gd(n3, 4), h3 = Kd(l3), f3 = Gd(h3), p3 = Kd(f3, true);
    Ld(f3), Vd(), Ld(l3);
    var m3 = Gd(l3, 4), g3 = Kd(m3, true), v3 = Gd(g3), _3 = Kd(v3);
    Ld(v3), Ld(m3);
    var y3 = Gd(m3, 2);
    vm(y3);
    var w3 = Gd(y3, 4), x3 = Kd(w3, true);
    Ld(w3);
    var k3 = Gd(w3, 2), S3 = Kd(k3, true);
    Ld(k3);
    var M3 = Gd(k3, 2);
    Vm(M3, (t4) => zd(E2, t4), () => rp(E2));
    var z3 = Gd(M3, 2), C3 = Kd(z3, true);
    Ld(z3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4, i4, s4, n4, o4, l4, c3, u3) => {
      Vp(r3, t4), Vp(a3, e4), Vp(h3, `${i4 ?? ""} `), Vp(p3, s4), Vp(g3, n4), Vp(_3, `${o4 ?? ""}%`), Vp(x3, l4), Vp(S3, c3), Vp(C3, u3);
    }, [() => d2("metrics.winrate.takeProfit"), () => 0 !== rp(b2) ? 100 * rp(b2) + "%" : d2("metrics.winrate.none"), () => d2("metrics.winrate.extraProfitLossTakingProfit"), () => (rp(c2) > 0 ? "+" : "") + (100 * rp(c2)).toFixed(1), () => d2("metrics.winrate.takeProfitRatio"), () => (100 * rp(u2)).toFixed(1), () => d2("metrics.winrate.mfeReturn"), () => d2("metrics.winrate.return"), () => d2("metrics.winrate.mfe")], vd), $m(y3, () => rp(b2), (t4) => zd(b2, t4)), zp(t3, e3);
  };
  Hp(q2, (t3) => {
    "takeProfit" === p2() && t3(U2);
  });
  var K2 = Gd(q2, 2), G2 = (t3) => {
    var e3 = ZC(), i3 = Kd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3, true);
    Ld(n3);
    var o3 = Gd(n3, 2);
    Vm(o3, (t4) => zd(M2, t4), () => rp(M2));
    var a3 = Gd(o3, 2), l3 = Kd(a3, true);
    Ld(a3), Ld(s3), Ld(i3), Ld(e3), of((t4, e4) => {
      Vp(r3, t4), Vp(l3, e4);
    }, [() => d2("metrics.winrate.mfe"), () => d2("metrics.winrate.mae")], vd), zp(t3, e3);
  };
  Hp(K2, (t3) => {
    "maeMfe" === p2() && t3(G2);
  }), Ld(O2), zp(t2, O2);
  var J2 = hd({ get lang() {
    return f2();
  }, set lang(t3) {
    f2(t3), sp();
  }, get chartTab() {
    return p2();
  }, set chartTab(t3) {
    p2(t3), sp();
  }, get browser() {
    return m2();
  }, set browser(t3) {
    m2(t3), sp();
  }, get report() {
    return g2();
  }, set report(t3) {
    g2(t3), sp();
  } });
  return s2(), J2;
}
tg(eD, { lang: {}, chartTab: {}, browser: {}, report: {} }, [], [], true);
const iD = Wm(null);
class Stock {
  constructor(t2) {
    this.timestamps = t2.date, this.open = t2.open, this.high = t2.high, this.close = t2.close, this.low = t2.low, this.volume = t2.volume;
  }
  createTradingviewSeries(t2, e2 = 0, i2 = -1, s2 = 500) {
    const n2 = this[t2], r2 = this.timestamps.map((t3, e3) => ({ time: t3.toDate(), value: n2[e3] })).slice(this.indexOfTimestamps(e2), this.indexOfTimestamps(i2) + 1), o2 = Math.round(r2.length / s2);
    return r2.filter((t3, e3) => e3 % o2 === 0 || e3 === r2.length - 1);
  }
  indexOfTimestamps(t2) {
    return "string" == typeof t2 ? this.timestamps.findIndex((e2) => e2 === t2) : t2 < 0 ? Math.max(this.timestamps.length + t2, 0) : Math.min(t2, this.timestamps.length - 1);
  }
  createCandlestickSeries(t2 = 0, e2 = -1) {
    const i2 = this.indexOfTimestamps(t2), s2 = this.indexOfTimestamps(e2) + 1;
    return this.timestamps.slice(i2, s2).map((t3, e3) => ({ time: t3, open: this.open[i2 + e3], high: this.high[i2 + e3], low: this.low[i2 + e3], close: this.close[i2 + e3] }));
  }
}
var sD = kp('<div class="flex justify-center items-center h-80"><span class="loading loading-lg text-base-content/50"></span></div>'), nD = kp('<div class="flex flex-col gap-4 justify-center items-center h-80 px-4 text-center"><div class="alert alert-error shadow-lg text-sm"><span> </span></div> <button class="btn btn-sm btn-outline">重試</button></div>'), rD = kp("<div></div>"), oD = kp('<div class="card my-8 bg-black/50"><div class="relative"><!> <!> <div class="absolute top-3 left-3 bg-base-300 flex gap-2 items-center"><div> </div> <div><span class="bg-primary/50 px-2 py-1 text-xs card"> </span></div></div> <div class="card-actions justify-end absolute top-2 right-2 z-[10]"><button class="btn btn-xs btn-circle btn-outline">✕</button></div></div></div>');
function aD(t2, e2) {
  ld(e2, false);
  const [i2, s2] = Hm(), n2 = () => qm(iD, "$stockStore", i2);
  let r2 = Jm(e2, "width", 12, ""), o2 = Sd(), a2 = Sd();
  async function l2(t3) {
    await u2(t3), await np(), rp(o2);
  }
  let h2 = Sd(false), c2 = Sd(null);
  async function u2(t3) {
    zd(h2, true), zd(c2, null);
    try {
      await async function(t4) {
        const e3 = await async function(t5) {
          try {
            const e4 = await fetch(`https://firestore.googleapis.com/v1/projects/fdata-299302/databases/(default)/documents/twStock/${t5}`);
            if (!e4.ok) throw new Error("Failed to fetch stock data");
            const i4 = (await e4.json()).fields.price.mapValue.fields, s4 = { date: i4.date.arrayValue.values.map((t6) => t6.timestampValue), open: i4.open.arrayValue.values.map((t6) => parseFloat(t6.doubleValue || t6.integerValue || 0)), high: i4.high.arrayValue.values.map((t6) => parseFloat(t6.doubleValue || t6.integerValue || 0)), close: i4.close.arrayValue.values.map((t6) => parseFloat(t6.doubleValue || t6.integerValue || 0)), low: i4.low.arrayValue.values.map((t6) => parseFloat(t6.doubleValue || t6.integerValue || 0)), volume: i4.volume.arrayValue.values.map((t6) => parseFloat(t6.doubleValue || t6.integerValue || 0)) };
            return new Stock(s4);
          } catch (t6) {
            return null;
          }
        }(t4);
        if (!e3) throw new Error("Failed to fetch stock data");
        const i3 = e3.createCandlestickSeries(0, -1);
        function s3(t5, e4) {
          var _a3;
          let s4 = 0;
          const n3 = [];
          for (let r3 = 0; r3 < t5.length; r3++) if (s4 += t5[r3], r3 >= e4 && (s4 -= t5[r3 - e4]), r3 >= e4 - 1) {
            const t6 = (_a3 = i3[r3]) == null ? void 0 : _a3.time;
            t6 && n3.push({ time: t6, value: s4 / e4 });
          }
          return n3;
        }
        i3.forEach((t5, e4) => {
          try {
            if ("string" != typeof t5.time) throw new Error("Invalid date format");
            t5.time = t5.time.split("T")[0];
          } catch (e5) {
            t5.time = null;
          }
        }), f2 = i3, p2 = i3.map((t5, e4) => ({ bar: t5, i: e4 })).filter(({ bar: t5 }) => !!t5.time).map(({ bar: t5, i: i4 }) => {
          const s4 = e3.volume[i4] ?? 0, n3 = t5 && "number" == typeof t5.open && "number" == typeof t5.close && t5.close >= t5.open ? "#f43098" : "#00d3bb";
          return { time: t5.time, value: s4, color: n3 };
        }), v2 = s3(e3.close, 20), b2 = s3(e3.close, 60), _2 = s3(e3.close, 120), y2 = s3(e3.close, 250);
      }(t3.assetId), w2();
    } catch (t4) {
      zd(c2, "無法載入股票資料，請稍後再試");
    } finally {
      zd(h2, false);
    }
  }
  function d2() {
    rp(a2) && u2(rp(a2));
  }
  let f2, p2, m2 = Sd(), g2 = null, v2 = [], b2 = [], _2 = [], y2 = [];
  function w2() {
    var _a3, _b3, _c3, _d3;
    g2 || (g2 = new TwChart(rp(m2), false));
    const t3 = Px(qm(Rx, "$theme", i2));
    g2.setTheme("dark" === t3 ? "dark" : "light"), g2.addCandlestickSeries(), g2.updateCandlestickSeriesData(f2), g2.addVolumeSeries(), g2.updateVolumeSeriesData(p2), g2.resetLineSeries(0, { color: "#f6c02d80", priceScaleId: "right", lineWidth: 2 }), g2.updateLineSeriesData(0, v2), g2.resetLineSeries(1, { color: "#3abff880", priceScaleId: "right", lineWidth: 2 }), g2.updateLineSeriesData(1, b2), g2.resetLineSeries(2, { color: "#725bf580", priceScaleId: "right", lineWidth: 2 }), g2.updateLineSeriesData(2, _2), g2.resetLineSeries(3, { color: "#9aa0a680", priceScaleId: "right", lineWidth: 2 }), g2.updateLineSeriesData(3, y2), g2.chart.applyOptions({ leftPriceScale: { visible: false } });
    const e3 = "light" === t3 ? "rgb(107 114 128)" : "rgb(209 213 219)";
    g2.chart.applyOptions({ grid: { vertLines: { color: "#77777777", style: rk.Dotted, visible: true }, horzLines: { color: "#77777777", style: rk.Dotted, visible: true } }, crosshair: { horzLine: { visible: true, color: "#777777", style: rk.Dotted, labelVisible: true }, vertLine: { visible: true, color: "#777777", style: rk.Dotted, labelVisible: true } } });
    const s3 = new Date((_a3 = rp(a2)) == null ? void 0 : _a3.entryDate), n3 = new Date((_b3 = rp(a2)) == null ? void 0 : _b3.exitDate), r3 = !isNaN(s3.getTime()), o3 = !isNaN(n3.getTime()), l3 = Number((_c3 = rp(a2)) == null ? void 0 : _c3.entryPrice), h3 = Number((_d3 = rp(a2)) == null ? void 0 : _d3.exitPrice);
    function c3(t4) {
      const e4 = 6e4 * t4.getTimezoneOffset();
      return new Date(t4 - e4).toISOString().split("T")[0];
    }
    const u3 = [];
    r3 && Number.isFinite(l3) && u3.push({ time: c3(s3), price: l3 });
    const d3 = [];
    r3 && o3 && n3 > s3 && Number.isFinite(h3) && d3.push({ time: c3(n3), price: h3 }), (u3.length > 0 || d3.length > 0) && g2.addTradeMarkers(u3, d3, e3);
  }
  const x2 = qp();
  function k2() {
    x2("close"), l2(rp(a2)), iD.set(null);
  }
  function S2(t3) {
    "Escape" === t3.key && k2();
  }
  Bp(() => {
    window.addEventListener("keydown", S2);
  }), jp(() => {
    window.removeEventListener("keydown", S2);
  }), sf(() => n2(), () => {
    zd(a2, n2());
  }), sf(() => rp(a2), () => {
    rp(a2) && l2(rp(a2));
  }), nf(), Om();
  var M2 = oD(), z2 = Kd(M2), C2 = Kd(z2), R2 = (t3) => {
    zp(t3, sD());
  }, P2 = (t3, e3) => {
    var i3 = (t4) => {
      var e4 = nD(), i4 = Kd(e4), s3 = Kd(i4), n3 = Kd(s3, true);
      Ld(s3), Ld(i4);
      var r3 = Gd(i4, 2);
      Ld(e4), of(() => Vp(n3, rp(c2))), bp("click", r3, d2), zp(t4, e4);
    };
    Hp(t3, (t4) => {
      rp(c2) && t4(i3);
    }, e3);
  };
  Hp(C2, (t3) => {
    rp(h2) ? t3(R2) : t3(P2, false);
  });
  var T2 = Gd(C2, 2), E2 = (t3) => {
    var e3 = rD();
    Vm(e3, (t4) => zd(m2, t4), () => rp(m2)), of(() => lm(e3, 1, "mt-12 mb-4 h-64 w-full " + (rp(h2) ? "hidden" : "block"))), zp(t3, e3);
  };
  Hp(T2, (t3) => {
    rp(a2) && t3(E2);
  });
  var A2 = Gd(T2, 2), L2 = Kd(A2), V2 = Kd(L2, true);
  Ld(L2);
  var O2 = Gd(L2, 2), I2 = Kd(O2), N2 = Kd(I2, true);
  Ld(I2), Ld(O2), Ld(A2);
  var F2 = Gd(A2, 2), B2 = Kd(F2);
  Ld(F2), Ld(z2), Ld(M2), Vm(M2, (t3) => zd(o2, t3), () => rp(o2)), of(() => {
    cm(M2, `width: ${r2() ?? ""}`), Vp(V2, n2().assetName), Vp(N2, n2().industry);
  }), bp("click", B2, k2), zp(t2, M2);
  var q2 = hd({ get width() {
    return r2();
  }, set width(t3) {
    r2(t3), sp();
  } });
  return s2(), q2;
}
tg(aD, { width: {} }, [], [], true);
var lD = kp('<span class="pl-2"> </span>'), hD = kp("<th> <!></th>"), cD = kp("<td><!></td>"), uD = kp('<tr class="relative"><td class="p-0"><!></td></tr>'), dD = kp('<tr class="border-b border-neutral-200 dark:border-white/10 hover:bg-neutral-50 dark:hover:bg-white/5 cursor-pointer"></tr> <!>', 1), fD = kp('<div style="clip-path: inset(0 0 0 0);"><div class="relative w-full"><div class="overflow-x-auto overflow-y-hidden"><table class="min-w-full table-fixed m-0"><thead class="h-8 pb-2"><tr></tr></thead><tbody></tbody></table></div></div></div>');
function pD(t2, e2) {
  ld(e2, false);
  const [i2, s2] = Hm(), n2 = () => qm(iD, "$stockStore", i2);
  let r2 = Jm(e2, "rows", 28, () => []), o2 = Jm(e2, "columns", 28, () => []), a2 = Jm(e2, "theme", 12, "light"), l2 = Sd([]), h2 = Sd(), c2 = Sd(), u2 = Sd(), d2 = Sd(), f2 = Sd("100%");
  const p2 = qp();
  function m2() {
    p2("close");
  }
  function g2(t3) {
    t3.detail;
  }
  sf(() => hp(r2()), () => {
    zd(l2, r2()), zd(h2, null), zd(c2, true);
  }), sf(() => n2(), () => {
    zd(d2, n2());
  }), sf(() => (rp(d2), rp(u2)), () => {
    rp(d2) && rp(u2) && zd(f2, `${rp(u2).clientWidth}px`);
  }), nf(), Om();
  var v2 = fD(), b2 = Kd(v2), _2 = Kd(b2), y2 = Kd(_2), w2 = Kd(y2), x2 = Kd(w2);
  Yp(x2, 5, o2, (t3) => t3.key, (t3, e3) => {
    var i3 = hD(), s3 = Kd(i3), n3 = Gd(s3), o3 = (t4) => {
      var e4 = lD(), i4 = Kd(e4, true);
      Ld(e4), of(() => Vp(i4, rp(c2) ? "▲" : "▼")), zp(t4, e4);
    };
    Hp(n3, (t4) => {
      rp(h2) === rp(e3).key && t4(o3);
    }), Ld(i3), of(() => {
      cm(i3, `width: ${rp(e3).width ?? ""};`), lm(i3, 1, `tracking-wider p-2 cursor-pointer font-medium whitespace-nowrap text-xs ${"name" === rp(e3).key ? "pl-0 text-left" : "text-right"} ${rp(h2) === rp(e3).key ? "text-gray-600 dark:text-gray-300" : "text-neutral-600 dark:text-white/70"}`), Vp(s3, `${rp(e3).name ?? ""} `);
    }), bp("click", i3, () => function(t4) {
      if (!t4.sort) return;
      const e4 = t4.key;
      rp(h2) === e4 ? zd(c2, !rp(c2)) : (zd(h2, e4), zd(c2, true)), zd(l2, [...r2()].sort((t5, i4) => {
        const s4 = t5[e4], n4 = i4[e4];
        if (s4 === n4) return 0;
        const r3 = s4 < n4 ? -1 : 1;
        return rp(c2) ? r3 : -r3;
      }));
    }(rp(e3))), zp(t3, i3);
  }), Ld(x2), Ld(w2);
  var k2 = Gd(w2);
  Yp(k2, 5, () => rp(l2), (t3) => t3.assetId, (t3, i3) => {
    var s3 = dD(), n3 = Yd(s3), r3 = gd(() => function(t4) {
      p2("click", t4);
    }(rp(i3)));
    Yp(n3, 5, o2, (t4) => t4.name, (t4, s4) => {
      var n4 = cD(), r4 = Kd(n4), o3 = (t5) => {
        var s5 = Mp();
        tm(Yd(s5), e2, "name", { get row() {
          return rp(i3);
        } }, (t6) => {
          var e3 = Sp();
          of(() => Vp(e3, rp(i3).name)), zp(t6, e3);
        }), zp(t5, s5);
      }, a3 = (t5, n5) => {
        var r5 = (t6) => {
          var s5 = Mp();
          tm(Yd(s5), e2, "action", { get row() {
            return rp(i3);
          } }, (t7) => {
            var e3 = Sp();
            of(() => Vp(e3, rp(i3).action)), zp(t7, e3);
          }), zp(t6, s5);
        }, o4 = (t6, n6) => {
          var r6 = (t7) => {
            var s5 = Mp();
            tm(Yd(s5), e2, "entryDate", { get row() {
              return rp(i3);
            } }, (t8) => {
              var e3 = Sp();
              of(() => Vp(e3, rp(i3).entryDate)), zp(t8, e3);
            }), zp(t7, s5);
          }, o5 = (t7, n7) => {
            var r7 = (t8) => {
              var s5 = Mp();
              tm(Yd(s5), e2, "profit", { get row() {
                return rp(i3);
              } }, (t9) => {
                var e3 = Sp();
                of(() => Vp(e3, rp(i3).profit)), zp(t9, e3);
              }), zp(t8, s5);
            }, o6 = (t8, n8) => {
              var r8 = (t9) => {
                var s5 = Mp();
                tm(Yd(s5), e2, "currentWeight", { get row() {
                  return rp(i3);
                } }, (t10) => {
                  var e3 = Sp();
                  of(() => Vp(e3, rp(i3).currentWeight)), zp(t10, e3);
                }), zp(t9, s5);
              }, o7 = (t9, n9) => {
                var r9 = (t10) => {
                  var s5 = Mp();
                  tm(Yd(s5), e2, "nextWeight", { get row() {
                    return rp(i3);
                  } }, (t11) => {
                    var e3 = Sp();
                    of(() => Vp(e3, rp(i3).nextWeight)), zp(t11, e3);
                  }), zp(t10, s5);
                }, o8 = (t10, n10) => {
                  var r10 = (t11) => {
                    var s5 = Mp();
                    tm(Yd(s5), e2, "RSV", { get row() {
                      return rp(i3);
                    } }, (t12) => {
                      var e3 = Sp();
                      of(() => Vp(e3, rp(i3).RSV)), zp(t12, e3);
                    }), zp(t11, s5);
                  }, o9 = (t11) => {
                    var e3 = Sp();
                    of(() => Vp(e3, rp(i3)[rp(s4).key] ? rp(i3)[rp(s4).key] : "-")), zp(t11, e3);
                  };
                  Hp(t10, (t11) => {
                    "RSV" === rp(s4).key ? t11(r10) : t11(o9, false);
                  }, n10);
                };
                Hp(t9, (t10) => {
                  "nextWeight" === rp(s4).key ? t10(r9) : t10(o8, false);
                }, n9);
              };
              Hp(t8, (t9) => {
                "currentWeight" === rp(s4).key ? t9(r8) : t9(o7, false);
              }, n8);
            };
            Hp(t7, (t8) => {
              "profit" === rp(s4).key ? t8(r7) : t8(o6, false);
            }, n7);
          };
          Hp(t6, (t7) => {
            "entryDate" === rp(s4).key ? t7(r6) : t7(o5, false);
          }, n6);
        };
        Hp(t5, (t6) => {
          "action" === rp(s4).key ? t6(r5) : t6(o4, false);
        }, n5);
      };
      Hp(r4, (t5) => {
        "name" === rp(s4).key ? t5(o3) : t5(a3, false);
      }), Ld(n4), of(() => {
        cm(n4, `width: ${rp(s4).width ?? ""};`), lm(n4, 1, "whitespace-nowrap px-2 py-3 text-sm text-neutral-800 dark:text-white/90 " + ("name" === rp(s4).key ? "pl-0 text-left" : "text-right"));
      }), zp(t4, n4);
    }), Ld(n3);
    var l3 = Gd(n3, 2), h3 = (t4) => {
      var e3 = uD(), i4 = Kd(e3);
      aD(Kd(i4), { get width() {
        return rp(f2);
      }, get theme() {
        return a2();
      }, $$events: { close: m2, heightChange: g2 } }), Ld(i4), Ld(e3), of(() => _m(i4, "colspan", o2().length)), zp(t4, e3);
    };
    Hp(l3, (t4) => {
      rp(d2) && rp(i3).assetId === rp(d2).assetId && t4(h3);
    }), bp("click", n3, function(...t4) {
      var _a3;
      (_a3 = rp(r3)) == null ? void 0 : _a3.apply(this, t4);
    }), zp(t3, s3);
  }), Ld(k2), Ld(y2), Ld(_2), Vm(_2, (t3) => zd(u2, t3), () => rp(u2)), Ld(b2), Ld(v2), zp(t2, v2);
  var S2 = hd({ get rows() {
    return r2();
  }, set rows(t3) {
    r2(t3), sp();
  }, get columns() {
    return o2();
  }, set columns(t3) {
    o2(t3), sp();
  }, get theme() {
    return a2();
  }, set theme(t3) {
    a2(t3), sp();
  } });
  return s2(), S2;
}
function mD(t2) {
  const e2 = function(t3) {
    if (!t3) return 0;
    const e3 = t3.codePointAt(0);
    if (void 0 === e3) throw new Error("Invalid character");
    return e3 % 360;
  }(t2), i2 = function(t3) {
    let e3, i3, s3;
    {
      const n2 = (t4, e4, i4) => (i4 < 0 && (i4 += 1), i4 > 1 && (i4 -= 1), i4 < 1 / 6 ? t4 + 6 * (e4 - t4) * i4 : i4 < 0.5 ? e4 : i4 < 2 / 3 ? t4 + (e4 - t4) * (2 / 3 - i4) * 6 : t4);
      let r2 = 0.75, o2 = 1 - r2;
      e3 = n2(o2, r2, t3 + 1 / 3), i3 = n2(o2, r2, t3), s3 = n2(o2, r2, t3 - 1 / 3);
    }
    return [Math.round(255 * e3), Math.round(255 * i3), Math.round(255 * s3)];
  }(e2 / 360), s2 = function(t3, e3, i3) {
    const s3 = (t4) => {
      const e4 = t4.toString(16);
      return 1 === e4.length ? "0" + e4 : e4;
    };
    return `#${s3(t3)}${s3(e3)}${s3(i3)}`;
  }(...i2);
  return s2 + "77";
}
function gD(t2) {
  const e2 = {};
  for (let [i2, s2] of t2.entries()) s2 instanceof Map ? e2[i2] = gD(s2) : e2[i2] = s2;
  return e2;
}
function vD(t2) {
  if ("object" != typeof t2 || null === t2) return false;
  t2 instanceof Map && (t2 = gD(t2));
  const e2 = ["assetName", "assetId"], i2 = ["entryDate", "exitDate"], s2 = ["entryPrice", "exitPrice", "currentPrice", "profit", "currentWeight", "nextWeight", "rsv20"];
  for (const i3 of e2) if ("string" != typeof t2[i3]) return false;
  for (const e3 of i2) if (!(t2[e3] instanceof Date) && void 0 !== t2[e3]) return false;
  for (const e3 of s2) if ("number" != typeof t2[e3]) return false;
  if (null !== t2.action) {
    if ("object" != typeof t2.action || null === t2.action) return false;
    const e3 = ["type", "reason", "date", "profit"];
    for (const i3 of e3) if (!(i3 in t2.action)) return false;
    if (!["entry", "exit", "hold", "entry_f", "exit_p"].includes(t2.action.type)) return false;
    if (!["sl", "tp", "sl_", "tp_", "_", "enter", "exit", "sl_enter", "tp_enter"].includes(t2.action.reason)) return false;
    if (!(t2.action.date instanceof Date) && void 0 !== t2.action.date) return false;
    if ("number" != typeof t2.action.profit) return false;
  }
  return true;
}
tg(pD, { rows: {}, columns: {}, theme: {} }, ["name", "action", "entryDate", "profit", "currentWeight", "nextWeight", "RSV"], [], true), Chart.register(...Cx);
var bD = kp('<p class="text-sm"> </p>'), _D = kp(" <br/> ", 1), yD = kp('<div class="flex flex-col items-center gap-2"><h1 class="flex items-end font-bold text-4xl"><span class="text-sm"><!></span> <span style="position: relative; top: 3px;"> </span> <span class="text-sm"><!></span></h1> <!></div>'), wD = kp('<div class="hidden md:flex gap-4"><div class="relative w-full" style="aspect-ratio: 1 / 1;"><canvas id="myPieChart"></canvas> <div class="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"><!></div></div></div> <div class="block md:hidden"><p> </p> <h1 class="flex items-end font-bold text-4xl mt-1.5 -ml-2 mb-3"><span class="text-sm"><!></span> <span style="position: relative; top: 3px;"> </span> <span class="text-sm"><!></span></h1></div>', 1);
const xD = { hash: "svelte-acpgfn", code: "" };
function kD(t2, e2) {
  ld(e2, false), em(t2, xD);
  const i2 = Sd();
  let s2, n2 = Jm(e2, "stockNames", 28, () => ["testStock", "testStock2"]), r2 = Jm(e2, "stockReturns", 28, () => [0.1, -0.1]), o2 = Jm(e2, "positionSizes", 28, () => [0.6, 0.4]), a2 = Jm(e2, "title", 12, "報酬"), l2 = Jm(e2, "theme", 12), h2 = Sd(null), c2 = Sd(0), u2 = Sd(null);
  const d2 = (t3, e3) => {
    const i3 = 0.95 * Math.abs(t3 / e3) + 0.05;
    return wz(t3 > 0 ? xz() : kz(), i3);
  }, f2 = Sz;
  Bp(() => {
    (() => {
      (() => {
        let t4 = o2().reduce((t5, e4) => t5 + (0 !== e4 ? e4 : 0), 0);
        zd(c2, o2().reduce((t5, e4, i4) => 0 !== e4 ? t5 + e4 * r2()[i4] : t5, 0) / t4);
      })();
      const t3 = o2().map((t4, e4) => t4 * r2()[e4]), e3 = [...Array(n2().length).keys()].sort(function(e4, i4) {
        const s3 = (t3[i4] > 0) - (t3[e4] > 0), n3 = (t3[e4], t3[i4] * o2()[i4] - t3[e4] * o2()[e4]);
        return 0 === s3 ? -n3 : -s3;
      }).filter((t4) => o2()[t4] > 0), i3 = e3.map((t4) => 100 * o2()[t4] + Math.abs(r2()[t4])), a3 = e3.map((t4) => n2()[t4]), l3 = e3.map((t4) => r2()[t4]), h3 = e3.map((t4) => o2()[t4]), p3 = e3.map((e4) => t3[e4]), m3 = Math.max(...p3.map(Math.abs));
      i3.map((t4) => t4).sort((t4, e4) => e4 - t4)[4];
      const g3 = { labels: a3, datasets: [{ data: h3, backgroundColor: p3.map((t4) => d2(t4, m3)), hoverBackgroundColor: p3.map((t4) => d2(t4, m3)) }] }, v3 = document.getElementById("myPieChart"), b3 = v3.getContext("2d"), _3 = { type: "doughnut", data: g3, options: { cutout: "75%", rotation: 0, responsive: true, animation: { duration: 0 }, elements: { arc: { borderWidth: 6, borderColor: "#00000000" } }, plugins: { legend: { display: false }, tooltip: { enabled: false } }, onHover(t4, e4) {
        if (e4.length > 0) {
          const t5 = e4[0].index;
          zd(u2, a3[t5]);
        } else zd(u2, null);
      } }, plugins: [{ id: "htmlLegend", afterDraw(t4) {
        const e4 = t4.canvas, i4 = t4.data.datasets[0], s3 = e4.parentNode;
        document.getElementsByClassName("chart-label").length > 0 || i4.data.forEach((i5, n3) => {
          const r3 = t4.getDatasetMeta(0).data[n3];
          r3.tooltipPosition();
          const o3 = (r3.endAngle - r3.startAngle) / 2 + r3.startAngle, a4 = r3.outerRadius + 40, c3 = t4.width / 2 + Math.cos(o3) * a4, u3 = t4.height / 2 + Math.sin(o3) * a4;
          let d3 = 1 - 1.5 * (t4.height - Math.abs(u3 - t4.height)) / t4.height;
          d3 < 0.7 && (d3 = 0.7), h3[n3] < 0.03 && (d3 = 0);
          const p4 = document.createElement("div");
          p4.style.lineHeight = "1", p4.style.opacity = d3;
          const m4 = document.createElement("span");
          var g4;
          m4.style.fontSize = "0.9rem", m4.innerHTML = (g4 = Math.round(1e4 * l3[n3]) / 100) > 0 ? `+${g4}` : g4;
          const v4 = document.createElement("span");
          v4.style.fontSize = "0.6rem", v4.innerHTML = "%", h3[n3] > 0.04 || d3 > 0.7 ? (m4.style.color = f2(l3[n3]), v4.style.color = f2(l3[n3])) : (m4.style.color = "#00000000", v4.style.color = "#00000000"), m4.style.fontWeight = "bold";
          const b4 = document.createElement("span");
          b4.innerHTML = t4.data.labels[n3], b4.style.fontSize = "0.8rem", p4.appendChild(b4), p4.appendChild(document.createElement("br")), p4.appendChild(m4), p4.appendChild(v4);
          const _4 = document.createElement("div");
          _4.className = "chart-label", _4.style.position = "absolute", _4.style.transform = "translate(-50%, -50%)", _4.style.pointerEvents = "none", _4.style.whiteSpace = "nowrap", _4.style.textAlign = "right", _4.appendChild(p4), s3.appendChild(_4), _4.style.left = e4.offsetLeft + c3 + "px", _4.style.top = e4.offsetTop + u3 + "px";
          const y3 = document.createElement("div");
          y3.style.lineHeight = "1.2", y3.style.color = "#FFFFFFaa", y3.style.opacity = d3;
          const w3 = document.createElement("span");
          w3.style.fontSize = "0.7rem", w3.innerHTML = Math.round(100 * h3[n3]) / 100, y3.appendChild(w3);
          const x3 = t4.width / 2 + Math.cos(o3) * a4 / 1.6, k3 = t4.height / 2 + Math.sin(o3) * a4 / 1.6, S3 = document.createElement("div");
          S3.style.position = "absolute", S3.className = "chart-label", S3.style.transform = "translate(-50%, -50%)", S3.style.pointerEvents = "none", S3.style.whiteSpace = "nowrap", S3.style.textAlign = "right", S3.style.marginTop = "-24px", S3.style.zIndex = 1e3, S3.style.left = e4.offsetLeft + x3 + "px", S3.style.top = e4.offsetTop + k3 + 20 + "px";
        });
      }, beforeDraw(t4) {
        const e4 = t4.canvas.parentNode;
        e4 && e4.querySelectorAll(".chart-label").forEach((t5) => t5.remove());
      } }] };
      s2 && (s2.destroy(), s2 = null, b3.clearRect(0, 0, v3.width, v3.height)), s2 = new Chart(b3, _3);
    })();
  });
  let p2 = Sd();
  sf(() => rp(u2), () => {
    rp(u2) && setTimeout(() => {
      zd(u2, null);
    }, 2e3);
  }), sf(() => (rp(u2), rp(c2), hp(r2()), hp(n2())), () => {
    zd(i2, null === rp(u2) ? Math.round(1e4 * rp(c2)) / 100 : Math.round(1e4 * r2()[n2().indexOf(rp(u2))]) / 100);
  }), nf(), Om();
  var m2 = wD(), g2 = Yd(m2), v2 = Kd(g2), b2 = Gd(Kd(v2), 2);
  ((t3) => {
    var e3 = yD(), s3 = Kd(e3), r3 = Kd(s3), l3 = Kd(r3), c3 = (t4) => {
      Ez(t4, { size: "1.5em" });
    }, d3 = (t4) => {
      Tz(t4, { size: "1.5em" });
    };
    Hp(l3, (t4) => {
      rp(i2) > 0 ? t4(c3) : t4(d3, false);
    }), Ld(r3);
    var p3 = Gd(r3, 2), m3 = Kd(p3, true);
    Ld(p3);
    var g3 = Gd(p3, 2);
    Wz(Kd(g3), { size: "1.2em" }), Ld(g3), Ld(s3);
    var v3 = Gd(s3, 2), b3 = (t4) => {
      var e4 = bD(), i3 = Kd(e4, true);
      Ld(e4), Vm(e4, (t5) => zd(h2, t5), () => rp(h2)), of(() => Vp(i3, a2())), zp(t4, e4);
    }, _3 = (t4) => {
      var e4 = _D(), i3 = Yd(e4), s4 = Gd(i3, 2);
      of((t5) => {
        Vp(i3, `${rp(u2) ?? ""} `), Vp(s4, ` ${t5 ?? ""}`);
      }, [() => Math.round(100 * o2()[n2().indexOf(rp(u2))]) / 100], vd), zp(t4, e4);
    };
    Hp(v3, (t4) => {
      null === rp(u2) ? t4(b3) : t4(_3, false);
    }), Ld(e3), of((t4, e4) => {
      cm(s3, `color: ${t4 ?? ""}`), Vp(m3, e4);
    }, [() => f2(rp(i2)), () => Math.abs(rp(i2))], vd), zp(t3, e3);
  })(Kd(b2)), Ld(b2), Ld(v2), Ld(g2), Vm(g2, (t3) => zd(p2, t3), () => rp(p2));
  var _2 = Gd(g2, 2), y2 = Kd(_2), w2 = Kd(y2, true);
  Ld(y2);
  var x2 = Gd(y2, 2), k2 = Kd(x2), S2 = Kd(k2), M2 = (t3) => {
    Ez(t3, { size: "2em" });
  }, z2 = (t3) => {
    Tz(t3, { size: "2em" });
  };
  Hp(S2, (t3) => {
    rp(i2) > 0 ? t3(M2) : t3(z2, false);
  }), Ld(k2);
  var C2 = Gd(k2, 2), R2 = Kd(C2, true);
  Ld(C2);
  var P2 = Gd(C2, 2);
  return Wz(Kd(P2), { size: "2em" }), Ld(P2), Ld(x2), Ld(_2), of((t3, e3) => {
    Vp(w2, a2()), cm(x2, `color: ${t3 ?? ""}`), Vp(R2, e3);
  }, [() => f2(rp(i2)), () => Math.abs(rp(i2))], vd), zp(t2, m2), hd({ get stockNames() {
    return n2();
  }, set stockNames(t3) {
    n2(t3), sp();
  }, get stockReturns() {
    return r2();
  }, set stockReturns(t3) {
    r2(t3), sp();
  }, get positionSizes() {
    return o2();
  }, set positionSizes(t3) {
    o2(t3), sp();
  }, get title() {
    return a2();
  }, set title(t3) {
    a2(t3), sp();
  }, get theme() {
    return l2();
  }, set theme(t3) {
    l2(t3), sp();
  } });
}
tg(kD, { stockNames: {}, stockReturns: {}, positionSizes: {}, title: {}, theme: {} }, [], [], true);
const SD = (t2, e2, i2) => {
  zd(e2, !rp(e2)), i2();
};
var MD = kp('<button class="btn btn-ghost btn-xs top-0 right-0 absolute"><!></button>'), zD = kp("<div><canvas></canvas></div>"), CD = kp('<div class="relative -ml-2"><!> <!></div>');
function DD(t2, e2) {
  ld(e2, true);
  const [i2, s2] = Hm();
  let n2 = Jm(e2, "stockNames", 7), r2 = Jm(e2, "stockReturns", 7), o2 = Jm(e2, "positionSizes", 7);
  const a2 = Sz;
  let l2 = null, h2 = null, c2 = kd(240), u2 = kd(false), d2 = kd(false);
  const f2 = () => {
    if (!h2) return;
    const t3 = r2().map((t4, e4) => ({ returnVal: t4, index: e4 })).filter((t4) => !isNaN(t4.returnVal)).filter((t4) => o2()[t4.index] > 0).sort((t4, e4) => e4.returnVal - t4.returnVal).map((t4) => t4.index);
    let e3 = t3;
    if (t3.length > 15 && !rp(u2)) {
      const i4 = 7;
      e3 = [...t3.slice(0, i4), -1, ...t3.slice(-8)], zd(d2, true);
    } else t3.length > 15 && zd(d2, true);
    const i3 = e3.map((t4) => -1 === t4 ? "..." : n2()[t4]), s3 = e3.map((t4) => -1 === t4 ? 0 : r2()[t4]);
    e3.map((t4) => -1 === t4 ? 0 : Math.abs(r2()[t4]));
    const c3 = { labels: i3, datasets: [{ data: s3, backgroundColor: s3.map((t4) => ((t5, e4) => {
      const i4 = Math.max(...e4.filter((t6) => t6 == t6).map(Math.abs)), s4 = 0.7 * Math.abs(t5 / i4) + 0.3;
      return wz(t5 >= 0 ? xz() : kz(), s4);
    })(t4, s3)), borderRadius: 12, borderWidth: 0 }] }, f3 = h2.getContext("2d");
    if (!f3) return;
    const p3 = document.querySelector(".text-base-content") || h2.parentElement || document.body, m3 = getComputedStyle(p3).color || "#6b7280", g3 = { type: "bar", data: c3, options: { responsive: true, maintainAspectRatio: false, indexAxis: "x", layout: { padding: { top: 36, bottom: 0, left: 16, right: 0 } }, animation: { duration: 0 }, scales: { x: { display: true, max: void 0, ticks: { color: m3, minRotation: 0, maxRotation: 90, beginAtZero: true, autoSkip: false, callback: (t4, e4) => i3[e4] }, grid: { display: false } }, y: { display: false, max: Math.max(0.01, ...s3.map((t4) => Math.abs(t4))), ticks: { beginAtZero: true, color: m3, format: { style: "percent" }, display: false, autoSkip: false, callback: (t4, e4) => t4 }, position: "left", grid: { display: false } } }, plugins: { legend: { enabled: false, display: false }, tooltip: { enabled: false } } }, plugins: [{ id: "barLabels", afterDatasetsDraw(t4) {
      t4.options.animation.duration = 0;
      const e4 = t4.ctx;
      t4.options.scales.x.ticks.color = m3, t4.options.scales.y.ticks.color = m3, t4.data.datasets.forEach(function(n3, r3) {
        t4.getDatasetMeta(r3).data.forEach(function(t5, n4) {
          const r4 = s3[n4];
          e4.fillStyle = a2(r4), e4.textAlign = "center";
          {
            const s4 = 15;
            e4.font = "12px sans-serif", i3.length > 12 ? (e4.save(), e4.translate(t5.x, r4 >= 0 ? t5.y - s4 - 5 : t5.y - t5.height - 20), e4.rotate(-Math.PI / 2), e4.textAlign = "center", e4.fillText(Math.abs(Math.round(1e3 * r4) / 10) + "%", 0, 0 + t5.width / 2 - 6), e4.restore()) : e4.fillText(Math.abs(Math.round(1e3 * r4) / 10) + "%", t5.x, r4 >= 0 ? t5.y - s4 : t5.y - t5.height - 14);
          }
        });
      });
    } }] };
    l2 && l2.destroy(), l2 = new Chart(f3, g3);
  };
  tf(() => (h2 && qm(Rx, "$theme", i2) && f2(), () => {
    l2 && l2.destroy();
  })), Bp(() => f2());
  var p2 = CD(), m2 = Kd(p2), g2 = (t3) => {
    var e3 = MD();
    e3.__click = [SD, u2, f2];
    var i3 = Kd(e3), s3 = (t4) => {
      Nz(t4, { size: 16 });
    }, n3 = (t4) => {
      Oz(t4, { size: 16 });
    };
    Hp(i3, (t4) => {
      rp(u2) ? t4(s3) : t4(n3, false);
    }), Ld(e3), zp(t3, e3);
  };
  Hp(m2, (t3) => {
    rp(d2) && t3(g2);
  });
  var v2 = Gd(m2, 2), b2 = (t3) => {
    var e3 = zD(), i3 = Kd(e3);
    Vm(i3, (t4) => h2 = t4, () => h2), Ld(e3), of(() => {
      cm(e3, `height: ${rp(c2) ?? ""}px;width: 100%;`), _m(i3, "height", rp(c2));
    }), zp(t3, e3);
  };
  Hp(v2, (t3) => {
    0 != rp(c2) && t3(b2);
  }), Ld(p2), zp(t2, p2);
  var _2 = hd({ get stockNames() {
    return n2();
  }, set stockNames(t3) {
    n2(t3), sp();
  }, get stockReturns() {
    return r2();
  }, set stockReturns(t3) {
    r2(t3), sp();
  }, get positionSizes() {
    return o2();
  }, set positionSizes(t3) {
    o2(t3), sp();
  } });
  return s2(), _2;
}
function RD(t2) {
  var _a3, _b3;
  if ("stringValue" in t2) return t2.stringValue;
  if ("integerValue" in t2) return parseInt(t2.integerValue, 10);
  if ("doubleValue" in t2) return t2.doubleValue;
  if ("booleanValue" in t2) return t2.booleanValue;
  if ("nullValue" in t2) return null;
  if ("arrayValue" in t2 && ((_a3 = t2.arrayValue) == null ? void 0 : _a3.values)) return t2.arrayValue.values.map(RD);
  if ("mapValue" in t2 && ((_b3 = t2.mapValue) == null ? void 0 : _b3.fields)) {
    const e2 = {};
    for (const [i2, s2] of Object.entries(t2.mapValue.fields)) e2[i2] = RD(s2);
    return e2;
  }
  return null;
}
_p(["click"]), tg(DD, { stockNames: {}, stockReturns: {}, positionSizes: {} }, [], [], true);
const PD = 3e5, TD = function() {
  const t2 = Wm({});
  let e2 = null, i2 = false, s2 = 0;
  async function n2() {
    if (!i2) return;
    const e3 = Date.now();
    if (!(e3 - s2 < PD)) try {
      const i3 = await async function() {
        try {
          const t3 = await fetch("https://firestore.googleapis.com/v1/projects/fdata-299302/databases/(default)/documents/twIntraday/realtime");
          if (!t3.ok) throw new Error(`HTTP error! status: ${t3.status}`);
          return function(t4) {
            var _a3;
            if (!t4 || !t4.fields) return {};
            const e4 = {};
            for (const [i4, s3] of Object.entries(t4.fields)) if ((_a3 = s3.mapValue) == null ? void 0 : _a3.fields) {
              e4[i4] = {};
              for (const [t5, n3] of Object.entries(s3.mapValue.fields)) e4[i4][t5] = RD(n3);
            }
            return e4;
          }(await t3.json());
        } catch (t3) {
          throw t3;
        }
      }();
      t2.set(i3), s2 = e3;
    } catch (t3) {
    }
  }
  function r2() {
    "undefined" == typeof window || e2 || (i2 = true, n2(), e2 = setInterval(n2, PD));
  }
  function o2() {
    i2 = false, e2 && (clearInterval(e2), e2 = null);
  }
  return "undefined" != typeof window && document.addEventListener("visibilitychange", () => {
    document.hidden ? o2() : r2();
  }), { subscribe: t2.subscribe, start: r2, stop: o2 };
}();
var $D = kp('<div class="chart-label font-normal z-[99] hover:z-[100] hover:border rounded-box text-base-content/70 svelte-1v9yy1w"><span class="label-text svelte-1v9yy1w"> </span> <span class="label-value svelte-1v9yy1w"> </span></div>'), ED = kp('<div class="svelte-1v9yy1w"><div class="w-full relative mb-16 svelte-1v9yy1w" style="height: 216px;"><div class="absolute inset-0 flex items-center justify-center z-10 pointer-events-none svelte-1v9yy1w"><div class="text-center svelte-1v9yy1w"><div class="text-lg font-extralight text-base-content svelte-1v9yy1w">產業比例</div></div></div> <canvas class="svelte-1v9yy1w"></canvas> <div class="z-[99] absolute top-0 left-0 w-full h-full pointer-events-none svelte-1v9yy1w"></div></div></div>'), AD = kp('<div class="svelte-1v9yy1w"><!></div>');
const LD = { hash: "svelte-1v9yy1w", code: "\n	@keyframes svelte-1v9yy1w-fadeIn {\n		from {\n			opacity: 0;\n			transform: translateY(-5px);\n		}\n		to {\n			opacity: 1;\n			transform: translateY(0);\n		}\n	}.chart-label.svelte-1v9yy1w {position:absolute;transform:translate(-50%, -50%);padding:4px 8px;font-size:10px;z-index:10;display:flex;flex-direction:column;align-items:center;\n		animation: svelte-1v9yy1w-fadeInZoom 0.5s ease-out forwards;transition:all 0.3s ease;white-space:nowrap;min-width:60px;text-align:center;}.label-text.svelte-1v9yy1w {font-size:12px;overflow:hidden;text-overflow:ellipsis;max-width:90px;}.label-value.svelte-1v9yy1w {font-size:11px;font-weight:700;}\n\n	@keyframes svelte-1v9yy1w-fadeInZoom {\n		0% {\n			opacity: 0;\n			transform: translate(-50%, -50%) scale(0.8);\n		}\n		100% {\n			opacity: 1;\n			transform: translate(-50%, -50%) scale(1);\n		}\n	}" };
tg(function(t2, e2) {
  ld(e2, true), em(t2, LD);
  const [i2, s2] = Hm();
  Chart.register(ArcElement, sx, Fw, Ww);
  let n2 = gd(() => ({ theme: qm(Rx, "$theme", i2), industries: [Mz("primary"), Mz("secondary"), Mz("accent"), Mz("info"), Mz("success"), Mz("warning"), Mz("error"), Mz("neutral"), Mz("base-300"), Mz("base-200")], stocks: ["#FF8394", "#FFA3B4", "#FFC3D4", "#06B6D4", "#22D3EE", "#67E8F9", "#FFDE76", "#FFEE96", "#FFFEB6", "#6BD0D0", "#8BE0E0", "#ABF0F0", "#B986FF", "#D9A6FF", "#F9C6FF", "#FFAF60", "#FFBF80", "#FFCFA0", "#D9DBDF", "#E9EBEF", "#F9FBFF", "#9BD063", "#BBE083", "#DBF0A3"] })), r2 = Jm(e2, "portfolioData", 7), o2 = kd(ud({ industries: [] }));
  tf(() => {
    const t3 = r2().filter((t4) => t4.currentWeight > 0), e3 = /* @__PURE__ */ new Map();
    let i3 = 0;
    t3.forEach((t4) => {
      e3.has(t4.industry) || (e3.set(t4.industry, { name: t4.industry, weight: 0, color: rp(n2).industries[i3 % rp(n2).industries.length], stocks: [], colorIndex: i3 }), i3++);
      const s4 = e3.get(t4.industry);
      s4.weight += t4.currentWeight;
      const r3 = s4.colorIndex, o3 = s4.stocks.length, a3 = rp(n2).stocks[3 * r3 + o3 % 3];
      s4.stocks.push({ name: t4.assetName, weight: t4.currentWeight, profit: t4.profit, price: t4.currentPrice, color: a3 });
    });
    const s3 = Array.from(e3.values()).sort((t4, e4) => e4.weight - t4.weight);
    s3.forEach((t4, e4) => {
      t4.color = rp(n2).industries[e4 % rp(n2).industries.length], t4.colorIndex = e4, t4.stocks.forEach((t5, i4) => {
        t5.color = rp(n2).stocks[3 * e4 + i4 % 3];
      });
    }), zd(o2, { industries: s3 }, true);
  });
  let a2, l2 = gd(() => {
    var _a3;
    return ((_a3 = rp(o2).industries) == null ? void 0 : _a3.map((t3) => `${t3.name} (${(100 * t3.weight).toFixed(1)}%)`)) || [];
  }), h2 = gd(() => {
    var _a3;
    return ((_a3 = rp(o2).industries) == null ? void 0 : _a3.map((t3) => (100 * t3.weight).toFixed(1))) || [];
  }), c2 = gd(() => {
    var _a3;
    return ((_a3 = rp(o2).industries) == null ? void 0 : _a3.map((t3) => t3.name)) || [];
  }), u2 = gd(() => {
    var _a3;
    return ((_a3 = rp(o2).industries) == null ? void 0 : _a3.map((t3) => t3.weight)) || [];
  }), d2 = gd(() => {
    var _a3;
    return ((_a3 = rp(o2).industries) == null ? void 0 : _a3.map((t3) => t3.color)) || [];
  }), f2 = kd(null), p2 = kd(ud([]));
  function m2() {
    if (!a2) return;
    const t3 = a2.chartArea, e3 = (t3.left + t3.right) / 2, i3 = (t3.top + t3.bottom) / 2;
    let s3 = -0.5 * Math.PI;
    const n3 = Math.min(t3.right - t3.left, t3.bottom - t3.top) / 2, r3 = 1.2 * n3;
    zd(p2, rp(u2).map((t4, o3) => {
      const a3 = 2 * Math.PI * t4, u3 = s3 + a3 / 2, f3 = e3 + Math.cos(u3) * r3, p3 = i3 + Math.sin(u3) * r3, m3 = e3 + Math.cos(u3) * (0.85 * n3), g3 = i3 + Math.sin(u3) * (0.85 * n3);
      return s3 += a3, { x: f3, y: p3, lineStartX: m3, lineStartY: g3, visible: t4 > 0.03, label: rp(c2)[o3], fullLabel: rp(l2)[o3], weight: rp(h2)[o3], color: rp(d2)[o3], angle: u3 };
    }), true);
  }
  tf(() => {
    rp(f2) && rp(o2).industries && rp(o2).industries.length > 0 && (a2 && a2.destroy(), Chart.defaults.color = "#fff", Chart.defaults.borderColor = "#444", Chart.defaults.backgroundColor = "#1e1e2f", a2 = new Chart(rp(f2), { type: "doughnut", data: { datasets: [{ label: "Industries", data: rp(u2), backgroundColor: rp(d2).map((t3) => wz(t3, 0.7)), borderColor: "rgba(0,0,0,0)", borderWidth: 0, radius: "100%" }] }, options: { responsive: true, maintainAspectRatio: false, cutout: "80%", layout: { padding: 0 }, plugins: { tooltip: { enabled: true, backgroundColor: "rgba(30, 30, 47, 0.9)", titleColor: "#fff", bodyColor: "#fff", borderColor: "#555", borderWidth: 1, displayColors: true, callbacks: { title: (t3) => "", label(t3) {
      const e3 = t3.datasetIndex, i3 = t3.dataIndex;
      if (0 === e3) {
        const t4 = rp(o2).industries[i3];
        return [`${t4.name}`, `占比: ${(100 * t4.weight).toFixed(1)}%`, `股票數: ${t4.stocks.length} 檔`];
      }
      return "";
    } } } }, animation: { onComplete() {
      m2();
    } } } }), m2());
  }), jp(() => {
    a2 && a2.destroy();
  });
  var g2 = AD(), v2 = Kd(g2), b2 = (t3) => {
    var e3 = ED(), i3 = Kd(e3), s3 = Gd(Kd(i3), 2);
    Vm(s3, (t4) => zd(f2, t4), () => rp(f2));
    var n3 = Gd(s3, 2);
    Yp(n3, 21, () => rp(p2), Kp, (t4, e4) => {
      var i4 = Mp(), s4 = Yd(i4), n4 = (t5) => {
        var i5 = $D(), s5 = Kd(i5), n5 = Kd(s5, true);
        Ld(s5);
        var r3 = Gd(s5, 2), o3 = Kd(r3);
        Ld(r3), Ld(i5), of(() => {
          cm(i5, `
								left: ${rp(e4).x ?? ""}px;
								top: ${rp(e4).y ?? ""}px;
								color: ;
							`), Vp(n5, rp(e4).label), Vp(o3, `${rp(e4).weight ?? ""}%`);
        }), zp(t5, i5);
      };
      Hp(s4, (t5) => {
        rp(e4).visible && t5(n4);
      }), zp(t4, i4);
    }), Ld(n3), Ld(i3), Ld(e3), zp(t3, e3);
  };
  Hp(v2, (t3) => {
    rp(o2).industries && rp(o2).industries.length > 0 && t3(b2);
  }), Ld(g2), zp(t2, g2);
  var _2 = hd({ get portfolioData() {
    return r2();
  }, set portfolioData(t3) {
    r2(t3), sp();
  } });
  return s2(), _2;
}, { portfolioData: {} }, [], [], true);
var VD = kp('<div class="w-[1.2em] h-[1.2em] flex items-center justify-center">—</div>'), OD = kp('<div class="stat-desc flex gap-2 items-center"><!> <!></div>'), ID = kp('<div class="flex flex-col gap-3"><div class="stat-title"> </div> <div class="stat-value text-5xl flex items-end font-extralight -ml-1.5"><!> <span class="text-sm"><!></span></div> <!></div>');
tg(function(t2, e2) {
  ld(e2, true);
  let i2 = Jm(e2, "stockNames", 23, () => []), s2 = Jm(e2, "stockReturns", 23, () => []), n2 = Jm(e2, "positionSizes", 23, () => []), r2 = Jm(e2, "purchaseDates", 23, () => []), o2 = Jm(e2, "title", 7, "總回報率"), a2 = gd(() => {
    let t3 = n2().reduce((t4, e4) => t4 + (0 !== e4 ? e4 : 0), 0), e3 = n2().reduce((t4, e4, i3) => 0 !== e4 ? t4 + e4 * s2()[i3] : t4, 0) / t3;
    return Math.round(1e4 * e3) / 100;
  }), l2 = gd(() => Sz(rp(a2))), h2 = gd(() => r2().length ? r2().reduce((t3, e3) => t3 < e3 ? t3 : e3) : null);
  var c2 = ID(), u2 = Kd(c2), d2 = Kd(u2, true);
  Ld(u2);
  var f2 = Gd(u2, 2), p2 = Kd(f2), m2 = (t3) => {
    Ez(t3, { size: "0.7em" });
  }, g2 = (t3, e3) => {
    var i3 = (t4) => {
      Tz(t4, { size: "0.7em" });
    }, s3 = (t4) => {
      zp(t4, VD());
    };
    Hp(t3, (t4) => {
      rp(a2) < 0 ? t4(i3) : t4(s3, false);
    }, e3);
  };
  Hp(p2, (t3) => {
    rp(a2) > 0 ? t3(m2) : t3(g2, false);
  });
  var v2 = Gd(p2), b2 = Gd(v2);
  Wz(Kd(b2), { size: "2em" }), Ld(b2), Ld(f2);
  var _2 = Gd(f2, 2), y2 = (t3) => {
    var e3 = OD(), i3 = Kd(e3);
    Az(i3, { size: "1em" });
    var s3 = Gd(i3, 2), n3 = (t4) => {
      var e4 = Sp();
      of((t5) => Vp(e4, `從 ${t5 ?? ""} 持有至今的報酬率`), [() => rp(h2).toLocaleDateString("zh-TW", { year: "numeric", month: "long", day: "numeric" })]), zp(t4, e4);
    }, r3 = (t4) => {
      zp(t4, Sp("最近日報酬率"));
    };
    Hp(s3, (t4) => {
      "累計報酬" === o2() ? t4(n3) : t4(r3, false);
    }), Ld(e3), zp(t3, e3);
  };
  return Hp(_2, (t3) => {
    rp(h2) && t3(y2);
  }), Ld(c2), of((t3) => {
    Vp(d2, o2()), cm(f2, `color: ${rp(l2) ?? ""}`), Vp(v2, ` ${t3 ?? ""} `);
  }, [() => Math.abs(rp(a2))]), zp(t2, c2), hd({ get stockNames() {
    return i2();
  }, set stockNames(t3 = []) {
    i2(t3), sp();
  }, get stockReturns() {
    return s2();
  }, set stockReturns(t3 = []) {
    s2(t3), sp();
  }, get positionSizes() {
    return n2();
  }, set positionSizes(t3 = []) {
    n2(t3), sp();
  }, get purchaseDates() {
    return r2();
  }, set purchaseDates(t3 = []) {
    r2(t3), sp();
  }, get title() {
    return o2();
  }, set title(t3 = "總回報率") {
    o2(t3), sp();
  } });
}, { stockNames: {}, stockReturns: {}, positionSizes: {}, purchaseDates: {}, title: {} }, [], [], true);
var ND = kp('<div class="w-[240px] md:w-1/3 md:mx-auto"><!></div>'), FD = kp('<div class="md:w-2/3 overflow-scroll"><!></div>'), WD = kp('<div class="px-6 md:pl-12 md:pr-0 mb-6 md:mb-12 relative pt-6"><div><div class="flex items-start md:gap-24 flex-col md:flex-row"><!> <!></div></div></div> <div class="flex flex-wrap items-center gap-4 justify-end mb-12 px-6 md:pr-3"><div class="inline-flex items-center gap-1 p-1 rounded-xl border border-neutral-200 bg-neutral-50/50 shadow-sm dark:border-white/10 dark:bg-white/[0.06] dark:backdrop-blur-md dark:shadow-[0_4px_30px_rgba(0,0,0,0.08)]"><button>累計報酬</button> <button>即時行情</button></div> <button class="inline-flex items-center gap-2 text-xs text-neutral-600 dark:text-white/80"><span><span></span></span> <span>隱藏名稱</span></button></div>', 1), BD = kp("<button> </button>"), jD = kp('<div class="w-full overflow-x-auto mb-8"><div class="inline-flex items-center gap-2 border border-neutral-200 dark:border-white/10 rounded-2xl p-2 bg-white dark:bg-white/5"></div></div>'), qD = kp('<span class="text-xs font-normal text-neutral-600 dark:text-white/70"> </span>'), HD = kp('<span class="h-1 w-10 bg-neutral-200/70 dark:bg-white/10 rounded-full overflow-hidden"><span></span></span>'), UD = kp('<span class="ml-2 inline-flex items-center"><!></span>'), KD = kp('<div class="flex items-baseline gap-1"><span class="text-xs text-neutral-500 dark:text-white/60"> </span> <span class="text-sm font-medium text-neutral-900 dark:text-white"> </span> <!> <!></div>'), YD = kp('<div class="mb-4 mx-4 md:mx-0 @container"><div class="grid grid-cols-1 gap-x-6 gap-y-2 items-center @md:grid-cols-2 @lg:grid-cols-4"></div></div>'), GD = kp('<span class="whitespace-nowrap font-bold text-neutral-800 dark:text-white/90"> </span> <br/>', 1), XD = kp('<div class="flex-grow text-left"><span class="font-light lining-nums ml-4 svelte-vti74z"> </span></div>'), JD = kp('<div class="text-base font-bold relative text-ellipsis overflow-hidden text-left"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"><!></div> <div><!> <span class="font-light text-neutral-500 dark:text-white/60"> </span></div> <!></div></div>'), QD = kp('<div class="text-2xl text-neutral-800 dark:text-white font-bold items-center flex mb-4"><h2> </h2> <button class="ml-4 inline-flex items-center gap-2 text-xs text-neutral-600 dark:text-white/80"><span><span></span></span> <span class="text-sm">顯示買入部位</span></button></div> <div class="grid grid-cols-2 md:grid-cols-3 gap-4 pt-1 mt-4"></div>', 1), ZD = kp('<hr class="my-6 border-neutral-200 dark:border-white/10"/>'), tR = kp('<span class="whitespace-nowrap font-bold text-neutral-700 dark:text-white/80"> </span> <br/>', 1), eR = kp('<div class="font-bold relative text-ellipsis overflow-hidden text-left"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"><!></div> <div><!> <span class="font-light text-neutral-500 dark:text-white/60"> </span></div></div></div>'), iR = kp('<h2 class="text-2xl font-bold flex items-center mb-4 text-neutral-800 dark:text-white"> </h2> <div class="grid grid-cols-2 md:grid-cols-3 gap-4 pt-1 mb-4"></div>', 1), sR = kp('<div class="md:rounded-2xl h-full border border-neutral-200 bg-white dark:bg-white/5 dark:border-white/10 p-4 sm:p-8 mb-4"><!> <!> <!></div>'), nR = kp('<h2 class="text-2xl text-neutral-800 dark:text-white font-bold mb-2 text-left">當前部位</h2>'), rR = kp('<span class="whitespace-nowrap font-bold text-neutral-700 dark:text-white/80"> </span> <br/>', 1), oR = kp('<div slot="name" class="text-base font-bold relative text-ellipsis overflow-hidden text-left cursor-pointer"><div class="flex flex-nowrap items-center"><div class="mr-3 w-8 h-8 rounded-full text-white font-bold justify-center items-center flex"> </div> <div><!> <span class="font-light text-neutral-500 dark:text-white/60"> </span></div></div></div>'), aR = kp('<div slot="profit"><span class="lining-nums svelte-vti74z"> </span><br/> <span class="text-sm text-neutral-600 dark:text-white/70"> </span></div>'), lR = kp('<div slot="entryDate"><span class="lining-nums svelte-vti74z"> </span><br/> <!> <span class="text-sm text-neutral-600 dark:text-white/70"> </span><br/></div>'), hR = kp('<div slot="currentWeight" class="lining-nums svelte-vti74z"><span> </span></div>'), cR = kp('<div slot="nextWeight" class="lining-nums svelte-vti74z"><span> </span></div>'), uR = kp(' <br/> <div class="h-1.5 w-16 bg-neutral-200/70 dark:bg-white/10 rounded-full overflow-hidden mt-1"><div class="h-full bg-gray-500 dark:bg-gray-400"></div></div>', 1), dR = kp('<div slot="RSV" class="text-neutral-700 dark:text-white/80"><!></div>'), fR = kp('<div class="min-h-[320px] flex items-center justify-center"><p>目前沒有持股喔！</p></div>'), pR = kp('<!> <div class="rounded-2xl border border-neutral-200 bg-neutral-50/50 dark:bg-white/5 dark:border-white/10 h-full mb-4 p-4 sm:p-8 relative"><!> <!></div>', 1), mR = kp('<div class="w-full text-left relative"><!> <!> <!> <!></div>');
const gR = { hash: "svelte-vti74z", code: ".lining-nums.svelte-vti74z {font-weight:300;font-size:18px;line-height:32px;}" };
function vR(t2, e2) {
  ld(e2, true), em(t2, gR);
  const [i2, s2] = Hm(), n2 = () => qm(iD, "$stockStore", i2), r2 = (t3) => {
    const e3 = t3.replaceAll(".", "_");
    return bu[e3] ? bu[e3]() : e3;
  };
  let o2 = Jm(e2, "reportPosition", 7), a2 = Jm(e2, "lang", 7), l2 = kd(false), h2 = kd("");
  function c2(t3) {
    const e3 = {};
    for (const [i3, s3] of t3.entries()) e3[i3] = s3;
    return e3.action && (e3.action = c2(e3.action)), e3;
  }
  function u2(t3) {
    null !== t3 && (t3.created = new Date(t3.created), t3.scheduled = new Date(t3.scheduled));
  }
  function d2(t3) {
    t3.forEach((t4) => {
      t4 instanceof Map && (t4 = c2(t4)), t4.entryDate = new Date(t4.entryDate), t4.exitDate = new Date(t4.exitDate), t4.entrySigDate = new Date(t4.entrySigDate), t4.exitSigDate = new Date(t4.exitSigDate), t4.action && (t4.action.date = new Date(t4.action.date)), vD(t4);
    });
  }
  function f2(t3) {
    const e3 = {};
    return t3.forEach((t4) => {
      const i3 = t4.assetId;
      (!e3[i3] || new Date(t4.entrySigDate) > new Date(e3[i3].entrySigDate)) && (e3[i3] = t4);
    }), Object.values(e3);
  }
  tf(() => {
    "" === rp(h2) && p2() && zd(h2, rp(b2)[0], true);
  });
  let p2 = () => {
    let t3 = false;
    return o2() && (t3 = !("positionConfig" in o2())), t3;
  }, m2 = gd(() => {
    let t3 = null;
    if (p2()) {
      let e3 = rp(h2);
      "" != e3 && e3 in o2() || (e3 = Object.keys(o2())[0]), t3 = o2()[e3];
    } else t3 = o2();
    return t3 && t3.positions ? (d2(t3.positions), t3 = f2(t3.positions), t3 = t3.sort((t4, e3) => {
      var _a3, _b3, _c3, _d3, _e4, _f3, _g2, _h2;
      return "entry" === ((_a3 = t4.action) == null ? void 0 : _a3.type) && "entry" !== ((_b3 = e3.action) == null ? void 0 : _b3.type) ? -1 : "entry" !== ((_c3 = t4.action) == null ? void 0 : _c3.type) && "entry" === ((_d3 = e3.action) == null ? void 0 : _d3.type) ? 1 : "exit" === ((_e4 = t4.action) == null ? void 0 : _e4.type) && "exit" !== ((_f3 = e3.action) == null ? void 0 : _f3.type) ? -1 : "exit" !== ((_g2 = t4.action) == null ? void 0 : _g2.type) && "exit" === ((_h2 = e3.action) == null ? void 0 : _h2.type) ? 1 : e3.entryDate.getTime() - t4.entryDate.getTime();
    }), t3) : [];
  }), g2 = gd(() => {
    let t3 = [];
    if (p2()) for (const [e3, i3] of Object.entries(o2())) {
      const e4 = f2(i3.positions);
      for (let s3 = 0; s3 < e4.length; s3++) {
        const n3 = t3.findIndex((t4) => t4.assetName === e4[s3].assetName), r3 = e4[s3].currentWeight * i3.positionConfig.weight;
        if (0 !== r3) if (-1 === n3) t3.push({ assetName: e4[s3].assetName, assetId: e4[s3].assetId, currentWeight: r3, profit: e4[s3].profit });
        else {
          const o3 = t3[n3].currentWeight;
          t3[n3].profit = (o3 * t3[n3].profit + r3 * e4[s3].profit) / (o3 + r3), t3[n3].currentWeight += e4[s3].currentWeight * i3.positionConfig.weight;
        }
      }
    }
    else t3 = rp(m2).filter((t4) => 0 !== t4.currentWeight);
    return t3;
  }), v2 = gd(() => {
    var _a3, _b3;
    if (p2()) {
      let t3 = rp(h2);
      return "" == t3 && (t3 = Object.keys(o2())[0]), o2()[t3] && u2(o2()[t3].positionConfig), ((_a3 = o2()[t3]) == null ? void 0 : _a3.positionConfig) || {};
    }
    return u2(o2().positionConfig), ((_b3 = o2()) == null ? void 0 : _b3.positionConfig) || {};
  });
  tf(() => {
    rp(m2) && E2();
  });
  let b2 = gd(() => {
    let t3 = null;
    return t3 = p2() ? Object.keys(o2()).sort((t4, e3) => t4.localeCompare(e3)) : [], t3;
  });
  function _2(t3) {
    try {
      return bu[t3]();
    } catch (e3) {
      return t3;
    }
  }
  Bp(() => TD.start()), jp(() => {
    N2(), TD.stop();
  });
  const y2 = { resample: { formatter: (t3) => {
    try {
      return bu["position_resampleValue_" + t3]();
    } catch (e3) {
      return t3;
    }
  }, unit: "" }, scheduled: { formatter: (t3) => rp(v2).isDailyStrategy ? t3 == null ? void 0 : t3.toLocaleDateString() : t3 == null ? void 0 : t3.toLocaleString(), unit: "" }, entryTradePrice: { formatter: (t3) => _2(`position_${t3}`) || t3, unit: "進場" }, exitTradePrice: { formatter: (t3) => _2(`position_${t3}`) || t3, unit: "出場" }, sl: { shown: (t3) => 1 != t3, formatter: (t3) => 100 !== t3 ? -(100 * t3).toFixed() : "無", unit: "%" }, tp: { shown: (t3) => t3 < 1e5, formatter: (t3) => "+" + (100 * t3).toFixed(), unit: "%" }, ts: { shown: (t3) => t3 < 1e5, formatter: (t3) => "+" + (100 * t3).toFixed(), unit: "%" } };
  let w2 = gd(() => rp(m2).filter((t3) => "hold" == t3.action.type || "exit" == t3.action.type));
  const x2 = /* @__PURE__ */ new Date();
  function k2(t3 = null) {
    !t3 || t3 instanceof Date || (t3 = new Date(t3)), t3 || (t3 = /* @__PURE__ */ new Date());
    const e3 = t3.getTime() + 6e4 * t3.getTimezoneOffset(), i3 = new Date(e3 + 288e5);
    return i3.setHours(15, 0, 0, 0), i3;
  }
  let S2, M2 = gd(() => rp(m2).filter((t3) => {
    var _a3, _b3, _c3;
    return t3.exitSigDate >= new Date(rp(v2).lastTimestamp) && x2 > k2(t3.exitSigDate) && (0 === t3.nextWeight || "exit" === ((_a3 = t3.action) == null ? void 0 : _a3.type) && ("tp" === ((_b3 = t3.action) == null ? void 0 : _b3.reason) || "sl" === ((_c3 = t3.action) == null ? void 0 : _c3.reason))) || function(t4) {
      var _a4, _b4;
      return ("tp_enter" === ((_a4 = t4.action) == null ? void 0 : _a4.reason) || "sl_enter" === ((_b4 = t4.action) == null ? void 0 : _b4.reason)) && 0 !== t4.currentWeight && rp(v2).scheduled && x2 < k2(rp(v2).scheduled);
    }(t3);
  })), z2 = gd(() => rp(m2).filter((t3) => t3.entrySigDate >= new Date(rp(v2).lastTimestamp) && x2 > k2(t3.entrySigDate) && 0 !== t3.nextWeight || function(t4) {
    var _a3, _b3;
    return ("tp_enter" === ((_a3 = t4.action) == null ? void 0 : _a3.reason) || "sl_enter" === ((_b3 = t4.action) == null ? void 0 : _b3.reason)) && 0 === t4.currentWeight && rp(v2).scheduled && x2 >= k2(rp(v2).scheduled);
  }(t3))), C2 = kd(false), R2 = gd(() => 0 !== rp(z2).length || 0 !== rp(M2).length ? [{ key: "name", name: r2("position.assetName"), sort: false, width: "160px" }, { key: "profit", name: r2("position.profit"), sort: true, width: "160px" }, { key: "entryDate", name: r2("position.entryDate"), sort: true, width: "180px" }, { key: "currentWeight", name: r2("position.currentWeight"), sort: true, width: "160px" }, { key: "nextWeight", name: r2("position.nextWeight"), sort: true, width: "160px" }, { key: "RSV", name: r2("position.RSV"), sort: false, width: "60px" }] : [{ key: "name", name: r2("position.assetName"), sort: false, width: "160px" }, { key: "profit", name: r2("position.profit"), sort: true, width: "160px" }, { key: "entryDate", name: r2("position.entryDate"), sort: true, width: "180px" }, { key: "currentWeight", name: r2("position.currentWeight"), sort: true, width: "160px" }, { key: "RSV", name: r2("position.RSV"), sort: false, width: "60px" }]);
  function P2() {
    localStorage.setItem("strategyAnalyticTab", "position"), E2();
  }
  let T2 = "position";
  async function E2(t3) {
    if (await np(), !S2) return;
    let e3 = S2.scrollHeight + 120, i3 = t3 ? t3.assetId : "";
    window.parent.postMessage({ frameHeight: e3, tab: T2 + " " + i3 }, "*");
  }
  const A2 = (t3) => {
    t3 = t3.detail, localStorage.setItem("strategyAnalyticTab", "position"), E2(t3), null === n2() || n2().assetId !== t3.assetId ? iD.set(t3) : iD.set(null);
  };
  let L2 = kd("cumulative");
  function V2(t3) {
    zd(L2, t3, true), "cumulative" === t3 ? TD.stop() : TD.start();
  }
  let O2 = gd(() => "cumulative" === rp(L2) ? rp(g2).map((t3) => {
    const e3 = B2(t3);
    return Number.isFinite(e3) ? e3 : Number.isFinite(t3.profit) ? t3.profit : 0;
  }) : rp(g2).map((t3) => {
    var _a3;
    return ((_a3 = F2(t3.assetId)) == null ? void 0 : _a3.r) / 100;
  })), I2 = kd(ud({}));
  const N2 = TD.subscribe((t3) => zd(I2, t3, true));
  function F2(t3) {
    return rp(I2)[t3] ? rp(I2)[t3] : { c: 0, h: 0, l: 0, o: 0, p: 0, r: 0, v: 0 };
  }
  function B2(t3) {
    const e3 = function(t4) {
      var _a3;
      const e4 = (_a3 = F2(t4)) == null ? void 0 : _a3.a;
      return Number.isFinite(e4) ? e4 : NaN;
    }(t3.assetId), i3 = t3.entryAdjPrice;
    return Number.isFinite(e3) && Number.isFinite(i3) && 0 !== i3 ? e3 / i3 - 1 : NaN;
  }
  function q2(t3) {
    const e3 = B2(t3);
    return "realtime" === rp(L2) && Number.isFinite(e3) ? e3 : t3.profit;
  }
  function U2(t3) {
    return Number.isFinite(t3.currentPrice) ? t3.currentPrice : NaN;
  }
  var K2 = mR(), G2 = Kd(K2), J2 = (t3) => {
    var e3 = WD(), i3 = Yd(e3), s3 = Kd(i3), n3 = Kd(s3), r3 = Kd(n3);
    Up(r3, () => [rp(g2), rp(L2), rp(l2)], (t4) => {
      var e4 = ND(), i4 = Kd(e4);
      const s4 = gd(() => rp(g2).map((t5) => rp(l2) ? "* * * * *" : t5.assetName)), n4 = gd(() => rp(g2).map((t5) => t5.currentWeight)), r4 = gd(() => "cumulative" === rp(L2) ? "當期累計報酬" : "即時行情");
      kD(i4, { get stockNames() {
        return rp(s4);
      }, get stockReturns() {
        return rp(O2);
      }, get positionSizes() {
        return rp(n4);
      }, get title() {
        return rp(r4);
      } }), Ld(e4), zp(t4, e4);
    }), Up(Gd(r3, 2), () => [rp(g2), rp(L2), rp(l2)], (t4) => {
      var e4 = FD(), i4 = Kd(e4);
      const s4 = gd(() => rp(g2).map((t5) => rp(l2) ? "* * * * *" : t5.assetName)), n4 = gd(() => rp(g2).map((t5) => t5.currentWeight));
      DD(i4, { get stockNames() {
        return rp(s4);
      }, get stockReturns() {
        return rp(O2);
      }, get positionSizes() {
        return rp(n4);
      } }), Ld(e4), zp(t4, e4);
    }), Ld(n3), Ld(s3), Ld(i3);
    var o3 = Gd(i3, 2), a3 = Kd(o3), h3 = Kd(a3), c3 = Gd(h3, 2);
    Ld(a3);
    var u3 = Gd(a3, 2), d3 = Kd(u3), f3 = Kd(d3);
    Ld(d3), Vd(2), Ld(u3), Ld(o3), of(() => {
      lm(h3, 1, "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition " + ("cumulative" === rp(L2) ? "bg-white text-neutral-900 shadow dark:bg-white/10 dark:text-white dark:shadow-[inset_0_0_0_1px_rgba(255,255,255,0.12)]" : "text-neutral-700 hover:bg-neutral-100 dark:text-white/70 dark:hover:bg-white/5"), "svelte-vti74z"), lm(c3, 1, "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs transition " + ("realtime" === rp(L2) ? "bg-white text-neutral-900 shadow dark:bg-white/10 dark:text-white dark:shadow-[inset_0_0_0_1px_rgba(255,255,255,0.12)]" : "text-neutral-700 hover:bg-neutral-100 dark:text-white/70 dark:hover:bg-white/5"), "svelte-vti74z"), lm(d3, 1, "inline-flex h-5 w-9 items-center rounded-full transition-all " + (rp(l2) ? "bg-neutral-800 dark:bg-white/70" : "bg-neutral-300/70 dark:bg-white/20"), "svelte-vti74z"), lm(f3, 1, "h-4 w-4 bg-white rounded-full shadow transform transition-all " + (rp(l2) ? "translate-x-4" : "translate-x-1"), "svelte-vti74z");
    }), bp("click", h3, () => V2("cumulative")), bp("click", c3, () => V2("realtime")), bp("click", u3, () => zd(l2, !rp(l2))), zp(t3, e3);
  };
  Hp(G2, (t3) => {
    rp(O2) && rp(O2).length > 0 && t3(J2);
  });
  var Q2 = Gd(G2, 2), tt2 = (t3) => {
    var e3 = jD(), i3 = Kd(e3);
    Yp(i3, 21, () => rp(b2), Kp, (t4, e4) => {
      var i4 = BD(), s3 = Kd(i4, true);
      Ld(i4), of(() => {
        lm(i4, 1, "px-3 py-1.5 rounded-xl text-xs transition " + (rp(e4) === rp(h2) ? "bg-neutral-900 text-white dark:bg-white/90 dark:text-neutral-900 shadow" : "text-neutral-700 hover:bg-neutral-100 dark:text-white/80 dark:hover:bg-white/10"), "svelte-vti74z"), Vp(s3, rp(e4));
      }), bp("click", i4, () => zd(h2, rp(e4), true)), zp(t4, i4);
    }), Ld(i3), Ld(e3), zp(t3, e3);
  };
  Hp(Q2, (t3) => {
    rp(b2).length > 1 && t3(tt2);
  });
  var et2 = Gd(Q2, 2), at2 = (t3) => {
    var e3 = YD(), i3 = Kd(e3);
    Yp(i3, 21, () => Object.entries(y2), Kp, (t4, e4) => {
      var i4 = gd(() => Bu(rp(e4), 2));
      let s3 = () => rp(i4)[0], n3 = () => rp(i4)[1];
      var r3 = Mp(), o3 = Yd(r3), a3 = (t5) => {
        var e5 = KD(), i5 = Kd(e5), r4 = Kd(i5);
        Ld(i5);
        var o4 = Gd(i5, 2), a4 = Kd(o4, true);
        Ld(o4);
        var l3 = Gd(o4, 2), h3 = (t6) => {
          var e6 = qD(), i6 = Kd(e6, true);
          Ld(e6), of(() => Vp(i6, n3().unit)), zp(t6, e6);
        };
        Hp(l3, (t6) => {
          n3().unit && t6(h3);
        });
        var c3 = Gd(l3, 2), u3 = (t6) => {
          var e6 = UD();
          Up(Kd(e6), () => rp(v2)[s3()], (t7) => {
            var e7 = HD(), i6 = Kd(e7);
            Ld(e7), of(() => {
              lm(i6, 1, ("sl" === s3() ? "bg-rose-500" : "bg-emerald-500") + " block h-full", "svelte-vti74z"), cm(i6, `width: ${100 * (s3(), rp(v2)[s3()])}%`);
            }), zp(t7, e7);
          }), Ld(e6), zp(t6, e6);
        };
        Hp(c3, (t6) => {
          "sl" !== s3() && "tp" !== s3() && "ts" !== s3() || t6(u3);
        }), Ld(e5), of((t6, e6) => {
          Vp(r4, `${t6 ?? ""}:`), Vp(a4, e6);
        }, [() => bu["position_" + s3()](), () => n3().formatter(rp(v2)[s3()])]), zp(t5, e5);
      };
      Hp(o3, (t5) => {
        "shown" in n3() && !n3().shown(rp(v2)[s3()]) || t5(a3);
      }), zp(t4, r3);
    }), Ld(i3), Ld(e3), zp(t3, e3);
  };
  Hp(et2, (t3) => {
    rp(v2) && t3(at2);
  });
  var ct2 = Gd(et2, 2), dt2 = (t3) => {
    var e3 = pR(), i3 = Yd(e3), s3 = (t4) => {
      var e4 = sR(), i4 = Kd(e4), s4 = (t5) => {
        var e5 = QD(), i5 = Yd(e5), s5 = Kd(i5), n5 = Kd(s5);
        Ld(s5);
        var r5 = Gd(s5, 2), o5 = Kd(r5), a5 = Kd(o5);
        Ld(o5), Vd(2), Ld(r5), Ld(i5);
        var l4 = Gd(i5, 2);
        Yp(l4, 21, () => rp(z2), Kp, (t6, e6) => {
          var i6 = JD(), s6 = Kd(i6), n6 = Kd(s6), r6 = Kd(n6), o6 = (t7) => {
            var i7 = Sp();
            of(() => Vp(i7, rp(e6).assetName[0])), zp(t7, i7);
          };
          Hp(r6, (t7) => {
            rp(e6).assetName && t7(o6);
          }), Ld(n6);
          var a6 = Gd(n6, 2), l5 = Kd(a6), h4 = (t7) => {
            var i7 = GD(), s7 = Yd(i7), n7 = Kd(s7, true);
            Ld(s7), Vd(2), of(() => Vp(n7, rp(e6).assetName)), zp(t7, i7);
          };
          Hp(l5, (t7) => {
            rp(e6).assetName && t7(h4);
          });
          var c3 = Gd(l5, 2), u3 = Kd(c3, true);
          Ld(c3), Ld(a6);
          var d3 = Gd(a6, 2), f3 = (t7) => {
            var i7 = XD(), s7 = Kd(i7), n7 = Kd(s7);
            Ld(s7), Ld(i7), of((t8, e7) => {
              cm(s7, `color: ${t8 ?? ""}`), Vp(n7, `${e7 ?? ""}%`);
            }, [() => Sz(rp(e6).profit), () => Math.abs(100 * rp(e6).nextWeight).toFixed(1)]), zp(t7, i7);
          };
          Hp(d3, (t7) => {
            rp(C2) && t7(f3);
          }), Ld(s6), Ld(i6), of((t7) => {
            cm(n6, `background: ${t7 ?? ""}`), Vp(u3, rp(e6).assetId);
          }, [() => mD(rp(e6).assetName[0])]), zp(t6, i6);
        }), Ld(l4), of(() => {
          Vp(n5, `${{ close: "收盤", open: "開盤" }[rp(v2).entryTradePrice] || "盤中"}買入`), lm(o5, 1, "inline-flex h-5 w-9 items-center rounded-full transition-all " + (rp(C2) ? "bg-neutral-800 dark:bg-white/70" : "bg-neutral-300/70 dark:bg-white/20"), "svelte-vti74z"), lm(a5, 1, "h-4 w-4 bg-white rounded-full shadow transform transition-all " + (rp(C2) ? "translate-x-4" : "translate-x-1"), "svelte-vti74z");
        }), bp("click", r5, () => zd(C2, !rp(C2))), zp(t5, e5);
      };
      Hp(i4, (t5) => {
        0 !== rp(z2).length && t5(s4);
      });
      var n4 = Gd(i4, 2), r4 = (t5) => {
        zp(t5, ZD());
      };
      Hp(n4, (t5) => {
        0 !== rp(z2).length && 0 !== rp(M2).length && t5(r4);
      });
      var o4 = Gd(n4, 2), a4 = (t5) => {
        var e5 = iR(), i5 = Yd(e5), s5 = Kd(i5);
        Ld(i5);
        var n5 = Gd(i5, 2);
        Yp(n5, 21, () => rp(M2), Kp, (t6, e6) => {
          var i6 = eR(), s6 = Kd(i6), n6 = Kd(s6), r5 = Kd(n6), o5 = (t7) => {
            var i7 = Sp();
            of(() => Vp(i7, rp(e6).assetName[0])), zp(t7, i7);
          };
          Hp(r5, (t7) => {
            rp(e6).assetName && t7(o5);
          }), Ld(n6);
          var a5 = Gd(n6, 2), l4 = Kd(a5), h4 = (t7) => {
            var i7 = tR(), s7 = Yd(i7), n7 = Kd(s7, true);
            Ld(s7), Vd(2), of(() => Vp(n7, rp(e6).assetName)), zp(t7, i7);
          };
          Hp(l4, (t7) => {
            rp(e6).assetName && t7(h4);
          });
          var c3 = Gd(l4, 2), u3 = Kd(c3, true);
          Ld(c3), Ld(a5), Ld(s6), Ld(i6), of((t7) => {
            cm(n6, `background: ${t7 ?? ""}`), Vp(u3, rp(e6).assetId);
          }, [() => mD(rp(e6).assetName[0])]), zp(t6, i6);
        }), Ld(n5), of(() => Vp(s5, `${{ close: "收盤", open: "開盤" }[rp(v2).entryTradePrice] || "盤中"}賣出`)), zp(t5, e5);
      };
      Hp(o4, (t5) => {
        0 != rp(M2).length && t5(a4);
      }), Ld(e4), zp(t4, e4);
    };
    Hp(i3, (t4) => {
      0 === rp(M2).length && 0 === rp(z2).length || t4(s3);
    });
    var n3 = Gd(i3, 2), r3 = Kd(n3), o3 = (t4) => {
      zp(t4, nR());
    };
    Hp(r3, (t4) => {
      0 === rp(M2).length && 0 === rp(z2).length || t4(o3);
    });
    var a3 = Gd(r3, 2), l3 = (t4) => {
      pD(t4, { get rows() {
        return rp(w2);
      }, get columns() {
        return rp(R2);
      }, $$events: { close: P2, click: A2 }, $$slots: { name: (t5, e4) => {
        var i4 = oR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = Kd(n4), o4 = Kd(r4, true);
        Ld(r4);
        var a4 = Gd(r4, 2), l4 = Kd(a4), h4 = (t6) => {
          var e5 = rR(), i5 = Yd(e5), n5 = Kd(i5, true);
          Ld(i5), Vd(2), of(() => Vp(n5, rp(s4).assetName ? rp(s4).assetName : "")), zp(t6, e5);
        };
        Hp(l4, (t6) => {
          rp(s4).assetName && t6(h4);
        });
        var c3 = Gd(l4, 2), u3 = Kd(c3, true);
        Ld(c3), Ld(a4), Ld(n4), Ld(i4), of((t6) => {
          cm(r4, `background: ${t6 ?? ""}`), Vp(o4, rp(s4).assetName ? rp(s4).assetName[0] : ""), Vp(u3, rp(s4).assetId);
        }, [() => mD(rp(s4).assetName[0])]), zp(t5, i4);
      }, profit: (t5, e4) => {
        var i4 = aR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = Kd(n4);
        Ld(n4);
        var o4 = Gd(n4, 3), a4 = Kd(o4, true);
        Ld(o4), Ld(i4), of((t6, e5, i5, s5) => {
          cm(n4, `color: ${t6 ?? ""}`), Vp(r4, `${e5 ?? ""}${i5 ?? ""}%`), Vp(a4, s5);
        }, [() => Sz(q2(rp(s4))), () => q2(rp(s4)) > 0 ? "▴ " : "▾ ", () => (100 * q2(rp(s4))).toFixed(2), () => Number.isFinite(U2(rp(s4))) ? U2(rp(s4)).toFixed(2) : "-"]), zp(t5, i4);
      }, entryDate: (t5, e4) => {
        var i4 = lR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = Kd(n4, true);
        Ld(n4);
        var o4 = Gd(n4, 3), a4 = (t6) => {
          var e5 = Sp();
          of((t7) => Vp(e5, t7), [() => rp(s4).entryDate.toLocaleTimeString()]), zp(t6, e5);
        };
        Hp(o4, (t6) => {
          rp(v2).isDailyStrategy || t6(a4);
        });
        var l4 = Gd(o4, 2), h4 = Kd(l4, true);
        Ld(l4), Vd(), Ld(i4), of((t6, e5) => {
          Vp(r4, t6), Vp(h4, e5);
        }, [() => rp(s4).entryDate.toLocaleDateString(), () => rp(s4).entryPrice == rp(s4).entryPrice ? rp(s4).entryPrice.toFixed(2) : "-"]), zp(t5, i4);
      }, currentWeight: (t5, e4) => {
        var i4 = hR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = Kd(n4);
        Ld(n4), Ld(i4), of((t6, e5) => {
          cm(n4, `color: ${t6 ?? ""}`), Vp(r4, `${e5 ?? ""}%`);
        }, [() => Sz(rp(s4).currentWeight), () => (100 * rp(s4).currentWeight).toFixed(1)]), zp(t5, i4);
      }, nextWeight: (t5, e4) => {
        var i4 = cR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = Kd(n4);
        Ld(n4), Ld(i4), of((t6, e5) => {
          cm(n4, `color: ${t6 ?? ""}`), Vp(r4, `${e5 ?? ""}%`);
        }, [() => Sz(rp(s4).nextWeight), () => (100 * rp(s4).nextWeight).toFixed(1)]), zp(t5, i4);
      }, RSV: (t5, e4) => {
        var i4 = dR();
        const s4 = gd(() => e4.row);
        var n4 = Kd(i4), r4 = (t6) => {
          var e5 = uR(), i5 = Yd(e5), n5 = Gd(i5, 3), r5 = Kd(n5);
          Ld(n5), of((t7) => {
            Vp(i5, `${t7 ?? ""}%`), cm(r5, `width: ${100 * rp(s4).rsv20}%`);
          }, [() => (100 * rp(s4).rsv20).toFixed(2)]), zp(t6, e5);
        }, o4 = (t6) => {
          zp(t6, Sp("-"));
        };
        Hp(n4, (t6) => {
          isFinite(rp(s4).rsv20) ? t6(r4) : t6(o4, false);
        }), Ld(i4), zp(t5, i4);
      } } });
    }, h3 = (t4) => {
      zp(t4, fR());
    };
    Hp(a3, (t4) => {
      rp(w2) && rp(w2).length > 0 ? t4(l3) : t4(h3, false);
    }), Ld(n3), zp(t3, e3);
  };
  Hp(ct2, (t3) => {
    rp(v2) && t3(dt2);
  }), Ld(K2), Vm(K2, (t3) => S2 = t3, () => S2), zp(t2, K2);
  var mt2 = hd({ get reportPosition() {
    return o2();
  }, set reportPosition(t3) {
    o2(t3), sp();
  }, get lang() {
    return a2();
  }, set lang(t3) {
    a2(t3), sp();
  } });
  return s2(), mt2;
}
tg(vR, { reportPosition: {}, lang: {} }, [], [], true);
var bR = kp('<a role="tab" tabindex="1"> </a>'), _R = kp('<div class="sticky top-0 z-[21] backdrop-blur-lg text-left"><div class="flex h-12 items-center"><div style="margin-left: -4px" class="flex-1 flex items-center text-base-content"><div class="h-6 [&amp;>svg]:h-full [&amp;>svg]:w-auto"><!></div></div> <div class="w-1/3"><div role="tablist" class="tabs tabs-border w-full border border-primary rounded-lg overflow-hidden"></div></div> <div class="flex-1 flex items-center justify-end gap-1"><button class="btn btn-ghost btn-sm btn-circle opacity-70 hover:opacity-100"><!></button> <button class="btn btn-ghost btn-sm btn-circle opacity-70 hover:opacity-100"><!></button></div></div></div>'), yR = kp('<button><span></span> <span> </span> <span class="da-accent-score svelte-bbaf2u"> </span></button>'), wR = kp('<div class="da-metric-card bg-base-100 dark:bg-base-300 svelte-bbaf2u"><div class="flex items-center justify-between mb-1.5"><span class="text-xs font-medium uppercase tracking-wide text-base-content/60 truncate"> </span> <span></span></div> <div class="text-xl font-semibold tracking-tight leading-tight"> <span class="text-xs font-normal text-base-content/60 ml-0.5"> </span></div> <div class="mt-1 text-xs text-base-content/50 truncate"> </div></div>'), xR = kp('<div class="da-overview svelte-bbaf2u"></div>'), kR = kp("<button> </button>"), SR = kp('<div class="da-chart-insight svelte-bbaf2u"><span class="shrink-0 mt-px">&#9432;</span> <p><!></p></div>'), MR = kp('<div class="da-panel @container svelte-bbaf2u"><div class="flex flex-wrap gap-2"></div> <!> <div class="da-sub-tabs svelte-bbaf2u"></div> <div class="da-chart-pane svelte-bbaf2u"><div><!> <!></div></div></div>'), zR = kp('<div class="pb-4 mt-12"><!></div>'), CR = kp("<!> <div></div> <!>", 1), DR = kp("<div><!></div>");
const RR = { hash: "svelte-bbaf2u", code: "\n	/* ─── Design A: Command Center Panel ─── */\n	/* daisyUI v5 uses --color-base-100, --color-base-content etc. */.da-panel.svelte-bbaf2u {display:flex;flex-direction:column;}\n\n	/* Layer 2: Overview Metrics */.da-overview.svelte-bbaf2u {display:flex;gap:8px;padding:16px 0;overflow-x:auto;scrollbar-width:none;flex-shrink:0;border-bottom:1px solid color-mix(in oklch, var(--color-base-content) 10%, transparent);}.da-overview.svelte-bbaf2u::-webkit-scrollbar {display:none;}.da-overview.svelte-bbaf2u .da-metric-card:where(.svelte-bbaf2u) {flex:1;min-width:120px;}\n\n	/* Per-chart insight line (inside chart pane) */.da-chart-insight.svelte-bbaf2u {display:flex;align-items:center;gap:6px;margin-bottom:16px;padding:8px 12px;border-radius:8px;background:var(--color-base-300);color:color-mix(in oklch, var(--color-base-content) 65%, transparent);line-height:1.4;}\n\n	/* Sub-tabs — underline style, horizontally scrollable */.da-sub-tabs.svelte-bbaf2u {display:flex;gap:0;padding:0;border-bottom:1px solid color-mix(in oklch, var(--color-base-content) 10%, transparent);flex-shrink:0;overflow-x:auto;scrollbar-width:none;}.da-sub-tabs.svelte-bbaf2u::-webkit-scrollbar {display:none;}.da-sub-tab.svelte-bbaf2u {padding:10px 16px;font-weight:500;color:color-mix(in oklch, var(--color-base-content) 55%, transparent);border:none;background:transparent;cursor:pointer;border-bottom:2px solid transparent;transition:all 0.2s;white-space:nowrap;flex-shrink:0;}.da-sub-tab.svelte-bbaf2u:hover {color:color-mix(in oklch, var(--color-base-content) 60%, transparent);}.da-sub-tab.active.svelte-bbaf2u {color:var(--color-base-content);border-bottom-color:var(--color-base-content);}\n\n	/* Chart/content pane */.da-chart-pane.svelte-bbaf2u {padding:24px 0 0;}\n\n	/* Metric cards */.da-metric-card.svelte-bbaf2u {padding:14px 16px;border-radius:12px;border:1px solid color-mix(in oklch, var(--color-base-content) 5%, transparent);transition:border-color 0.2s;}.da-metric-card.svelte-bbaf2u:hover {border-color:color-mix(in oklch, var(--color-base-content) 10%, transparent);}\n\n	/* ─── Accent Border Pills ─── */.da-accent-pill.svelte-bbaf2u {display:flex;align-items:center;gap:8px;padding:10px 16px;border-radius:10px;border:1px solid color-mix(in oklch, var(--color-base-content) 8%, transparent);background:transparent;cursor:pointer;font-weight:500;font-size:14px;color:color-mix(in oklch, var(--color-base-content) 65%, transparent);transition:all 0.2s;}.da-accent-pill.svelte-bbaf2u:hover {border-color:color-mix(in oklch, var(--color-base-content) 20%, transparent);color:color-mix(in oklch, var(--color-base-content) 70%, transparent);}.da-accent-pill.active.svelte-bbaf2u {border-color:var(--color-base-content);color:var(--color-base-100);background:var(--color-base-content);}.da-accent-bar.svelte-bbaf2u {width:3px;height:20px;border-radius:2px;flex-shrink:0;}.da-accent-score.svelte-bbaf2u {font-size:11px;font-weight:600;opacity:0.35;font-variant-numeric:tabular-nums;}" };
customElements.define("strategy-analytic", tg(function(e2, s2) {
  ld(s2, true), em(e2, RR);
  let n2 = Jm(s2, "report", 7), o2 = Jm(s2, "lang", 7), l2 = Jm(s2, "theme", 7), h2 = Jm(s2, "browser", 7), c2 = Jm(s2, "reportPosition", 7), u2 = Jm(s2, "webcomponent", 7), d2 = kd(ud(function() {
    try {
      const e3 = localStorage.getItem(i);
      if (e3 && t.includes(e3)) return e3;
    } catch {
    }
    return o2() || r();
  }()));
  function f2() {
    const t2 = "zh-tw" === rp(d2) ? "en" : "zh-tw";
    a(t2, { reload: false });
    try {
      localStorage.setItem(i, t2);
    } catch {
    }
    zd(d2, t2, true);
  }
  tf(() => {
    rp(d2) && r() !== rp(d2) && a(rp(d2), { reload: false });
  });
  const p2 = new MetricDisplay();
  let m2 = kd(ud("position" === localStorage.getItem("strategyAnalyticTab") ? "profitability" : localStorage.getItem("strategyAnalyticTab") || "profitability"));
  const g2 = { profitability: [{ key: "historicalReturn", labelKey: "profitability_historicalReturn" }, { key: "monthlyReturn", labelKey: "profitability_monthlyReturn" }, { key: "stockList", labelKey: "profitability_stockList" }, { key: "yearlyCompare", labelKey: "profitability_YearlyCompareWithBenchmark" }, { key: "excessReturn", labelKey: "profitability_exceedReturn" }], risk: [{ key: "drawdownPeriods", labelKey: "risk_drawdowPeriods" }, { key: "stockList", labelKey: "profitability_stockList" }, { key: "drawdownRanking", labelKey: "metrics_risk_worstDrawdownPeriod" }, { key: "recoveryTime", labelKey: "metrics_risk_newHighTimeRank" }, { key: "drawdownPercentage", labelKey: "risk_drawdownPercentage" }], ratio: [{ key: "sharpe", labelKey: "metrics_ratio_sharpeRatio" }, { key: "tailRatio", labelKey: "metrics_ratio_tailRatio" }, { key: "volatility", labelKey: "metrics_ratio_volatility" }, { key: "correlation", labelKey: "ratio_correlation" }], winrate: [{ key: "returnDistribution", labelKey: "metrics_winrate_returnDistribution" }, { key: "stopLoss", labelKey: "metrics_winrate_simulatedStopLoss" }, { key: "takeProfit", labelKey: "metrics_winrate_simulatedTakeProfit" }, { key: "maeMfe", labelKey: "metrics_winrate_maemfe" }], liquidity: [{ key: "portfolioCapacity", labelKey: "metrics_liquidity_portfolioCapacity" }, { key: "entryVolume", labelKey: "metrics_liquidity_entryVolume" }, { key: "exitVolume", labelKey: "metrics_liquidity_exitVolume" }] };
  let v2 = kd(ud(g2.profitability[0].key)), b2 = gd(() => n2() ? wu(n2().metrics) : {}), _2 = gd(() => {
    var _a3;
    return !!n2() && yu((_a3 = n2().metrics.backtest) == null ? void 0 : _a3.market);
  });
  const y2 = { good: "bg-success", ok: "bg-warning", bad: "bg-error" }, w2 = { "profitability.historicalReturn": "insight_profitability_historicalReturn", "profitability.monthlyReturn": "insight_profitability_monthlyReturn", "profitability.stockList": "insight_profitability_stockList", "profitability.yearlyCompare": "insight_profitability_yearlyCompare", "profitability.excessReturn": "insight_profitability_excessReturn", "risk.drawdownPeriods": "insight_risk_drawdownPeriods", "risk.stockList": "insight_risk_stockList", "risk.drawdownRanking": "insight_risk_drawdownRanking", "risk.recoveryTime": "insight_risk_recoveryTime", "risk.drawdownPercentage": "insight_risk_drawdownPercentage", "ratio.sharpe": "insight_ratio_sharpe", "ratio.tailRatio": "insight_ratio_tailRatio", "ratio.volatility": "insight_ratio_volatility", "ratio.correlation": "insight_ratio_correlation", "winrate.returnDistribution": "insight_winrate_returnDistribution", "winrate.stopLoss": "insight_winrate_stopLoss", "winrate.takeProfit": "insight_winrate_takeProfit", "winrate.maeMfe": "insight_winrate_maeMfe", "liquidity.portfolioCapacity": "insight_liquidity_portfolioCapacity", "liquidity.entryVolume": "insight_liquidity_entryVolume", "liquidity.exitVolume": "insight_liquidity_exitVolume" };
  let x2 = gd(() => {
    if (!n2()) return "";
    const t2 = n2().metrics, e3 = p2.format("annualReturn", t2.profitability.annualReturn) + "%", i2 = p2.format("alpha", t2.profitability.alpha) + "%", s3 = t2.profitability.avgNStock.toFixed(0), r2 = p2.format("maxDrawdown", t2.risk.maxDrawdown) + "%", o3 = t2.risk.avgDrawdownDays.toFixed(0), a2 = null == t2.risk.volatility || isNaN(t2.risk.volatility) ? "N/A" : (100 * t2.risk.volatility).toFixed(1) + "%", l3 = t2.ratio.sharpeRatio.toFixed(2), h3 = t2.ratio.sortinoRatio.toFixed(2), c3 = p2.format("winRate", t2.winrate.winRate) + "%", u3 = p2.format("expectancy", t2.winrate.expectancy) + "%", d3 = `${rp(m2)}.${rp(v2)}`, f3 = w2[d3];
    return f3 && bu[f3] ? bu[f3]({ ar: e3, al: i2, nstock: s3, md: r2, addDays: o3, vol: a2, sr: l3, so: h3, wr: c3, exp: u3 }) : "";
  });
  const k2 = ["profitability", "risk", "ratio", "winrate", "liquidity"];
  let S2 = gd(() => k2.filter((t2) => "liquidity" !== t2 || rp(_2)));
  tf(() => {
    const t2 = g2[rp(m2)];
    t2 && zd(v2, t2[0].key, true);
  });
  let M2 = ["analyze", "position"];
  const z2 = { analyze: () => Er(), position: () => $r() };
  let C2, R2, P2 = kd("analyze"), T2 = null;
  function E2() {
    if (!C2) return;
    const t2 = document.getElementById("panel");
    let e3;
    if (t2) {
      const i2 = window.getComputedStyle(document.body), s3 = parseFloat(i2.marginTop) || 0, n3 = parseFloat(i2.marginBottom) || 0;
      e3 = t2.offsetHeight + s3 + n3;
    } else e3 = document.documentElement.scrollHeight;
    window.parent.postMessage({ frameHeight: e3, tab: rp(P2) + " " + rp(m2) }, "*");
  }
  async function A2() {
    await np(), await new Promise((t2) => setTimeout(t2, 500)), E2();
  }
  Bp(async () => ("light" !== l2() && "dark" !== l2() || Lx.set(l2()), u2() && (await A2(), T2 = new ResizeObserver(() => {
    E2();
  }), T2.observe(C2)), () => {
    T2 == null ? void 0 : T2.disconnect();
  }));
  var L2 = DR();
  return Up(Kd(L2), () => rp(d2), (t2) => {
    var e3 = CR(), i2 = Yd(e3), s3 = (t3) => {
      var e4 = _R(), i3 = Kd(e4), s4 = Kd(i3), n3 = Kd(s4);
      Zp(Kd(n3), () => '<svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="1226.000000pt" height="348.000000pt" viewBox="0 0 1226.000000 348.000000" preserveAspectRatio="xMidYMid meet">\n\n<g transform="translate(0.000000,348.000000) scale(0.100000,-0.100000)" fill="currentColor" stroke="none">\n<path d="M1453 3192 c-74 -27 -119 -60 -157 -117 -62 -94 -71 -189 -26 -293 55 -128 216 -208 347 -172 184 51 286 262 203 423 -72 139 -230 208 -367 159z"/>\n<path d="M1045 2575 c-47 -25 -64 -45 -76 -86 -17 -54 -4 -104 36 -144 87 -86 229 -35 242 88 5 49 -18 100 -58 130 -37 26 -106 32 -144 12z"/>\n<path d="M4600 2167 c-30 -7 -58 -25 -87 -54 -41 -40 -43 -46 -43 -100 0 -72 27 -114 94 -148 142 -71 316 9 316 145 0 115 -138 193 -280 157z"/>\n<path d="M10490 1295 l0 -885 160 0 160 0 0 40 c0 22 2 40 6 40 3 0 26 -10 52 -21 120 -55 285 -83 443 -76 358 16 611 192 689 480 31 114 25 278 -13 385 -76 213 -239 352 -481 411 -197 48 -451 18 -638 -75 -26 -13 -50 -24 -53 -24 -3 0 -5 137 -5 305 l0 305 -160 0 -160 0 0 -885z m911 95 c177 -54 278 -180 279 -343 0 -127 -54 -228 -161 -297 -89 -57 -152 -73 -289 -73 -152 1 -256 30 -372 105 l-48 30 0 213 0 213 41 36 c53 45 167 99 244 115 33 7 65 15 70 16 37 12 180 3 236 -15z"/>\n<path d="M1146 2123 l-29 -5 7 -146 c3 -81 11 -184 16 -230 l9 -82 -367 -553 c-420 -630 -467 -705 -457 -715 3 -4 454 -8 1001 -10 823 -2 994 0 994 11 0 22 -113 210 -454 757 l-327 525 5 75 c4 41 9 141 13 221 l6 146 -39 6 c-42 7 -330 7 -378 0z m327 -723 c268 -427 477 -771 477 -786 0 -16 -543 -27 -933 -18 l-316 7 16 31 c26 49 472 727 510 774 l35 43 91 -3 92 -3 28 -45z"/>\n<path d="M1163 1058 c-54 -59 -213 -303 -213 -326 0 -9 91 -12 353 -12 347 0 397 3 397 22 0 24 -170 258 -188 258 -8 0 -37 -20 -64 -45 -28 -25 -56 -45 -64 -45 -8 0 -54 38 -103 85 -50 47 -92 85 -94 85 -2 0 -13 -10 -24 -22z"/>\n<path d="M2735 2068 c-3 -7 -4 -382 -3 -833 l3 -820 173 -3 172 -2 0 330 0 330 485 0 486 0 -3 138 -3 137 -482 3 -483 2 0 215 0 215 570 0 570 0 0 150 0 150 -740 0 c-583 0 -742 -3 -745 -12z"/>\n<path d="M7107 2074 c-4 -4 -7 -380 -7 -836 l0 -828 655 0 655 0 0 150 0 150 -480 2 -481 3 -2 680 -2 680 -166 3 c-91 1 -168 -1 -172 -4z"/>\n<path d="M5965 1693 c-118 -7 -258 -44 -355 -93 -22 -11 -45 -18 -50 -15 -6 3 -10 24 -10 46 l0 39 -160 0 -160 0 0 -630 0 -630 160 0 160 0 0 423 0 423 48 35 c109 82 211 114 357 114 107 0 112 -1 187 -38 81 -39 128 -84 167 -160 42 -82 45 -111 48 -459 l4 -338 159 0 160 0 0 343 c0 188 -5 371 -10 407 -38 266 -202 447 -460 510 -75 18 -170 27 -245 23z"/>\n<path d="M9330 1693 c-143 -6 -361 -42 -500 -84 -99 -30 -98 -28 -75 -96 10 -32 21 -62 25 -68 3 -5 12 -28 19 -50 8 -22 17 -50 22 -62 l8 -22 65 24 c164 59 371 89 524 74 164 -16 271 -78 322 -185 35 -76 46 -74 -170 -33 -90 16 -155 21 -295 22 -177 0 -218 -4 -345 -41 -117 -33 -220 -114 -267 -211 -23 -47 -27 -67 -27 -150 0 -82 4 -104 26 -152 109 -238 460 -330 874 -229 23 5 79 25 125 45 46 19 90 33 96 30 8 -2 13 -23 13 -50 l0 -46 158 3 157 3 3 237 c4 374 -16 581 -66 690 -12 26 -22 50 -22 53 0 4 -18 32 -41 63 -118 166 -332 246 -629 235z m205 -752 c96 -16 209 -43 223 -54 16 -13 6 -45 -22 -69 -34 -29 -176 -96 -241 -114 -107 -29 -168 -36 -276 -31 -86 4 -115 9 -155 29 -150 75 -112 215 67 247 62 12 316 6 404 -8z"/>\n<path d="M4510 1040 l0 -630 160 0 160 0 0 630 0 630 -160 0 -160 0 0 -630z"/>\n</g>\n</svg>\n'), Ld(n3), Ld(s4);
      var r3 = Gd(s4, 2), o4 = Kd(r3);
      Yp(o4, 21, () => M2, Kp, (t4, e5) => {
        var i4 = bR();
        let s5;
        var n4 = Kd(i4, true);
        Ld(i4), of((t5, e6) => {
          s5 = lm(i4, 1, "rounded-none w-1/2 flex items-center h-8 justify-center text-sm text-base-content cursor-pointer select-none", null, s5, t5), Vp(n4, e6);
        }, [() => ({ "bg-primary": rp(P2) === rp(e5), "opacity-70": rp(P2) === rp(e5), "text-primary-content": rp(P2) === rp(e5) }), () => {
          var _a3;
          return ((_a3 = z2[rp(e5)]) == null ? void 0 : _a3.call(z2)) ?? rp(e5);
        }]), bp("click", i4, () => {
          zd(P2, rp(e5), true), void 0 !== window && window.scrollY > R2.offsetTop && window.scrollTo(0, R2.offsetTop), A2();
        }), zp(t4, i4);
      }), Ld(o4), Ld(r3);
      var a3 = Gd(r3, 2), h3 = Kd(a3);
      Iz(Kd(h3), { class: "w-4 h-4" }), Ld(h3);
      var c3 = Gd(h3, 2), u3 = Kd(c3), p3 = (t4) => {
        jz(t4, { class: "w-4 h-4" });
      }, m3 = (t4) => {
        Fz(t4, { class: "w-4 h-4" });
      };
      Hp(u3, (t4) => {
        "dark" === l2() ? t4(p3) : t4(m3, false);
      }), Ld(c3), Ld(a3), Ld(i3), Ld(e4), of(() => {
        _m(h3, "title", "zh-tw" === rp(d2) ? "Switch to English" : "切換至中文"), _m(c3, "title", "dark" === l2() ? "Light mode" : "Dark mode");
      }), bp("click", h3, f2), bp("click", c3, () => {
        const t4 = "dark" === document.documentElement.getAttribute("data-theme") ? "light" : "dark";
        localStorage.setItem("theme", t4), l2(t4), Lx.set(t4), document.documentElement.setAttribute("data-theme", t4);
      }), zp(t3, e4);
    };
    Hp(i2, (t3) => {
      u2() && t3(s3);
    });
    var r2 = Gd(i2, 2);
    Vm(r2, (t3) => R2 = t3, () => R2);
    var o3 = Gd(r2, 2), a2 = (t3) => {
      var e4 = Mp(), i3 = Yd(e4), s4 = (t4) => {
        var e5 = MR(), i4 = Kd(e5);
        Yp(i4, 21, () => rp(S2), Kp, (t5, e6) => {
          var i5 = yR();
          const s6 = gd(() => function(t6) {
            return t6 >= 0.7 ? "good" : t6 >= 0.4 ? "ok" : "bad";
          }(rp(b2)[rp(e6)] || 0)), n3 = gd(() => Math.round(100 * (rp(b2)[rp(e6)] || 0)));
          let r4;
          var o5 = Kd(i5), a4 = Gd(o5, 2), l3 = Kd(a4, true);
          Ld(a4);
          var h3 = Gd(a4, 2), c4 = Kd(h3, true);
          Ld(h3), Ld(i5), of((t6, e7) => {
            r4 = lm(i5, 1, "da-accent-pill svelte-bbaf2u", null, r4, t6), lm(o5, 1, `da-accent-bar ${y2[rp(s6)] ?? ""}`, "svelte-bbaf2u"), Vp(l3, e7), Vp(c4, rp(n3));
          }, [() => ({ active: rp(m2) === rp(e6) }), () => bu[`tabs_${rp(e6)}`]()]), bp("click", i5, () => function(t6) {
            zd(m2, t6, true), localStorage.setItem("strategyAnalyticTab", t6), A2();
          }(rp(e6))), zp(t5, i5);
        }), Ld(i4);
        var s5 = Gd(i4, 2), r3 = (t5) => {
          var e6 = xR();
          Yp(e6, 21, () => Object.entries(n2().metrics[rp(m2)]), Kp, (t6, e7) => {
            var i5 = gd(() => Bu(rp(e7), 2));
            let s6 = () => rp(i5)[0], n3 = () => rp(i5)[1];
            var r4 = Mp(), o5 = Yd(r4), a4 = (t7) => {
              var e8 = wR();
              const i6 = gd(() => _u[rp(m2)][s6()].check(n3()));
              var r5 = Kd(e8), o6 = Kd(r5), a5 = Kd(o6, true);
              Ld(o6);
              var l3 = Gd(o6, 2);
              Ld(r5);
              var h3 = Gd(r5, 2), c4 = Kd(h3, true), u4 = Gd(c4), d3 = Kd(u4, true);
              Ld(u4), Ld(h3);
              var f4 = Gd(h3, 2), g3 = Kd(f4, true);
              Ld(f4), Ld(e8), of((t8, e9, s7, n4) => {
                Vp(a5, t8), lm(l3, 1, "w-1.5 h-1.5 rounded-full shrink-0 " + (rp(i6) ? "bg-success" : "bg-error")), Vp(c4, e9), Vp(d3, s7), Vp(g3, n4);
              }, [() => bu[`metrics_${rp(m2)}_${s6()}`](), () => p2.format(s6(), n3()), () => p2.getUnit(s6()), () => _u[rp(m2)][s6()].text()]), zp(t7, e8);
            };
            Hp(o5, (t7) => {
              var _a3;
              ((_a3 = _u[rp(m2)]) == null ? void 0 : _a3[s6()]) && t7(a4);
            }), zp(t6, r4);
          }), Ld(e6), zp(t5, e6);
        };
        Hp(s5, (t5) => {
          _u[rp(m2)] && t5(r3);
        });
        var o4 = Gd(s5, 2);
        Yp(o4, 21, () => g2[rp(m2)] || [], Kp, (t5, e6) => {
          var i5 = kR(), s6 = Kd(i5, true);
          Ld(i5), of((t6) => {
            lm(i5, 1, "da-sub-tab " + (rp(v2) === rp(e6).key ? "active" : ""), "svelte-bbaf2u"), Vp(s6, t6);
          }, [() => {
            var _a3;
            return ((_a3 = bu[rp(e6).labelKey]) == null ? void 0 : _a3.call(bu)) ?? rp(e6).labelKey;
          }]), bp("click", i5, () => zd(v2, rp(e6).key, true)), zp(t5, i5);
        }), Ld(o4);
        var a3 = Gd(o4, 2), c3 = Kd(a3), u3 = Kd(c3), f3 = (t5) => {
          var e6 = SR(), i5 = Gd(Kd(e6), 2);
          Zp(Kd(i5), () => rp(x2)), Ld(i5), Ld(e6), zp(t5, e6);
        };
        Hp(u3, (t5) => {
          rp(x2) && t5(f3);
        });
        var _4 = Gd(u3, 2), w3 = (t5) => {
          $C(t5, { get report() {
            return n2();
          }, get browser() {
            return h2();
          }, get theme() {
            return l2();
          }, get lang() {
            return rp(d2);
          }, get chartTab() {
            return rp(v2);
          } });
        }, k3 = (t5, e6) => {
          var i5 = (t6) => {
            GC(t6, { get report() {
              return n2();
            }, get browser() {
              return h2();
            }, get theme() {
              return l2();
            }, get lang() {
              return rp(d2);
            }, get chartTab() {
              return rp(v2);
            } });
          }, s6 = (t6, e7) => {
            var i6 = (t7) => {
              NC(t7, { get report() {
                return n2();
              }, get browser() {
                return h2();
              }, get theme() {
                return l2();
              }, get lang() {
                return rp(d2);
              }, get chartTab() {
                return rp(v2);
              } });
            }, s7 = (t7, e8) => {
              var i7 = (t8) => {
                eD(t8, { get report() {
                  return n2();
                }, get browser() {
                  return h2();
                }, get theme() {
                  return l2();
                }, get lang() {
                  return rp(d2);
                }, get chartTab() {
                  return rp(v2);
                } });
              }, s8 = (t8, e9) => {
                var i8 = (t9) => {
                  Bx(t9, { get report() {
                    return n2();
                  }, get browser() {
                    return h2();
                  }, get theme() {
                    return l2();
                  }, get lang() {
                    return rp(d2);
                  }, get chartTab() {
                    return rp(v2);
                  } });
                };
                Hp(t8, (t9) => {
                  "liquidity" === rp(m2) && t9(i8);
                }, e9);
              };
              Hp(t7, (t8) => {
                "winrate" === rp(m2) ? t8(i7) : t8(s8, false);
              }, e8);
            };
            Hp(t6, (t7) => {
              "ratio" === rp(m2) ? t7(i6) : t7(s7, false);
            }, e7);
          };
          Hp(t5, (t6) => {
            "risk" === rp(m2) ? t6(i5) : t6(s6, false);
          }, e6);
        };
        Hp(_4, (t5) => {
          "profitability" === rp(m2) ? t5(w3) : t5(k3, false);
        }), Ld(c3), Ld(a3), Ld(e5), zp(t4, e5);
      };
      Hp(i3, (t4) => {
        n2() && t4(s4);
      }), zp(t3, e4);
    }, _3 = (t3) => {
      var e4 = zR();
      vR(Kd(e4), { get reportPosition() {
        return c2();
      }, get lang() {
        return rp(d2);
      } }), Ld(e4), zp(t3, e4);
    };
    Hp(o3, (t3) => {
      "analyze" === rp(P2) ? t3(a2) : t3(_3, false);
    }), of(() => lm(r2, 1, nm(u2() ? "pt-4" : ""))), zp(t2, e3);
  }), Ld(L2), Vm(L2, (t2) => C2 = t2, () => C2), of(() => lm(L2, 1, nm(u2() ? "bg-base-300 dark:bg-base-200" : ""))), zp(e2, L2), hd({ get report() {
    return n2();
  }, set report(t2) {
    n2(t2), sp();
  }, get lang() {
    return o2();
  }, set lang(t2) {
    o2(t2), sp();
  }, get theme() {
    return l2();
  }, set theme(t2) {
    l2(t2), sp();
  }, get browser() {
    return h2();
  }, set browser(t2) {
    h2(t2), sp();
  }, get reportPosition() {
    return c2();
  }, set reportPosition(t2) {
    c2(t2), sp();
  }, get webcomponent() {
    return u2();
  }, set webcomponent(t2) {
    u2(t2), sp();
  } });
}, { report: { reflect: true, type: "Object" }, lang: { reflect: true, type: "String" }, theme: { reflect: true, type: "String" }, browser: { reflect: true, type: "Boolean" }, webcomponent: { reflect: true, type: "Boolean" }, reportPosition: { reflect: true, type: "Object" } }, [], [], false));
try {
  const e2 = localStorage.getItem(i);
  e2 && t.includes(e2) && a(e2, { reload: false });
} catch {
}
export {
  MetricDisplay,
  Report,
  wu as calculateScores,
  _u as qualityMetrics
};
