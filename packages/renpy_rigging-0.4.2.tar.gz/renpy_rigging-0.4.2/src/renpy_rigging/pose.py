"""
Pose application and blending.

A pose is a set of deltas that modify a rig's neutral state.
Poses can affect joint positions/rotations and part transforms.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, TYPE_CHECKING

from .math2d import Vec2, lerp, lerp_angle
from .rig import Rig, Joint, Part

if TYPE_CHECKING:
    from .attachment import AttachmentPoseState


@dataclass
class JointDelta:
    """
    Delta values for a joint in a pose.

    All values are relative to the rig's neutral state.
    """

    pos: Optional[Vec2] = None  # Position offset
    rot: Optional[float] = None  # Rotation offset (degrees)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {}
        if self.pos is not None:
            d["pos"] = [self.pos.x, self.pos.y]
        if self.rot is not None:
            d["rot"] = self.rot
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> JointDelta:
        """Create from dictionary."""
        pos = None
        if "pos" in data:
            p = data["pos"]
            pos = Vec2(p[0], p[1])
        return cls(
            pos=pos,
            rot=data.get("rot")
        )

    def is_empty(self) -> bool:
        """Check if this delta has no effect."""
        return self.pos is None and self.rot is None


@dataclass
class PartDelta:
    """
    Delta values for a part in a pose.

    All values are relative to the rig's neutral state.
    """

    pos: Optional[Vec2] = None  # Position offset
    rot: Optional[float] = None  # Rotation offset (degrees)
    scale: Optional[Vec2] = None  # Scale multiplier
    pivot: Optional[Vec2] = None  # Pivot offset
    z: Optional[int] = None  # Z-order override (absolute, not delta)
    visible: Optional[bool] = None  # Visibility override

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {}
        if self.pos is not None:
            d["pos"] = [self.pos.x, self.pos.y]
        if self.rot is not None:
            d["rot"] = self.rot
        if self.scale is not None:
            d["scale"] = [self.scale.x, self.scale.y]
        if self.pivot is not None:
            d["pivot"] = [self.pivot.x, self.pivot.y]
        if self.z is not None:
            d["z"] = self.z
        if self.visible is not None:
            d["visible"] = self.visible
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> PartDelta:
        """Create from dictionary."""
        pos = None
        if "pos" in data:
            p = data["pos"]
            pos = Vec2(p[0], p[1])
        scale = None
        if "scale" in data:
            s = data["scale"]
            if isinstance(s, list):
                scale = Vec2(s[0], s[1])
            else:
                scale = Vec2(s, s)
        pivot = None
        if "pivot" in data:
            p = data["pivot"]
            pivot = Vec2(p[0], p[1])
        return cls(
            pos=pos,
            rot=data.get("rot"),
            scale=scale,
            pivot=pivot,
            z=data.get("z"),
            visible=data.get("visible")
        )

    def is_empty(self) -> bool:
        """Check if this delta has no effect."""
        return (self.pos is None and self.rot is None and
                self.scale is None and self.pivot is None and
                self.z is None and self.visible is None)


@dataclass
class Pose:
    """
    A pose containing deltas for joints and parts.

    Poses are applied on top of the rig's neutral state.
    Only modified values need to be specified.

    Poses can also specify which overlays are visible when this pose is active,
    and per-attachment state (pose, visibility, joint override).
    """

    name: str = ""
    joints: Dict[str, JointDelta] = field(default_factory=dict)
    parts: Dict[str, PartDelta] = field(default_factory=dict)
    overlays: Optional[Dict[str, bool]] = None  # Per-overlay overrides: True=include, False=exclude, None/missing=inherit
    attachments: Dict[str, "AttachmentPoseState"] = field(default_factory=dict)  # Per-attachment state
    sound: Optional[str] = None  # Relative path to sound file

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {}

        if self.joints:
            joints_dict = {}
            for name, delta in self.joints.items():
                delta_dict = delta.to_dict()
                if delta_dict:  # Only include non-empty deltas
                    joints_dict[name] = delta_dict
            if joints_dict:
                d["joints"] = joints_dict

        if self.parts:
            parts_dict = {}
            for name, delta in self.parts.items():
                delta_dict = delta.to_dict()
                if delta_dict:  # Only include non-empty deltas
                    parts_dict[name] = delta_dict
            if parts_dict:
                d["parts"] = parts_dict

        if self.overlays:
            d["overlays"] = dict(self.overlays)

        if self.attachments:
            attachments_dict = {}
            for name, state in self.attachments.items():
                state_dict = state.to_dict()
                if state_dict:  # Only include non-default states
                    attachments_dict[name] = state_dict
            if attachments_dict:
                d["attachments"] = attachments_dict

        if self.sound is not None:
            d["sound"] = self.sound

        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> Pose:
        """Create from dictionary."""
        from .attachment import AttachmentPoseState

        joints = {}
        for joint_name, joint_data in data.get("joints", {}).items():
            joints[joint_name] = JointDelta.from_dict(joint_data)

        parts = {}
        for part_name, part_data in data.get("parts", {}).items():
            parts[part_name] = PartDelta.from_dict(part_data)

        raw_overlays = data.get("overlays")
        if isinstance(raw_overlays, list):
            # Backward compat: convert old list format to dict (all included)
            overlays = {name: True for name in raw_overlays} if raw_overlays else None
        elif isinstance(raw_overlays, dict):
            overlays = raw_overlays if raw_overlays else None
        else:
            overlays = None

        attachments = {}
        for attach_name, attach_data in data.get("attachments", {}).items():
            attachments[attach_name] = AttachmentPoseState.from_dict(attach_data)

        sound = data.get("sound")

        return cls(name=name, joints=joints, parts=parts, overlays=overlays,
                   attachments=attachments, sound=sound)

    def is_empty(self) -> bool:
        """Check if this pose has no deltas, overlays, or attachments."""
        return not self.joints and not self.parts and not self.overlays and not self.attachments and self.sound is None

    def get_joint_delta(self, name: str) -> JointDelta:
        """Get joint delta, returning empty delta if not found."""
        return self.joints.get(name, JointDelta())

    def get_part_delta(self, name: str) -> PartDelta:
        """Get part delta, returning empty delta if not found."""
        return self.parts.get(name, PartDelta())


@dataclass
class PoseLibrary:
    """
    A collection of named poses.
    """

    poses: Dict[str, Pose] = field(default_factory=dict)

    def get(self, name: str) -> Optional[Pose]:
        """Get a pose by name."""
        return self.poses.get(name)

    def add(self, pose: Pose) -> None:
        """Add or replace a pose."""
        self.poses[pose.name] = pose

    def remove(self, name: str) -> bool:
        """Remove a pose by name. Returns True if removed."""
        if name in self.poses:
            del self.poses[name]
            return True
        return False

    def list_names(self) -> List[str]:
        """Return a list of all pose names."""
        return list(self.poses.keys())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {name: pose.to_dict() for name, pose in self.poses.items()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> PoseLibrary:
        """Create from dictionary."""
        poses = {}
        for name, pose_data in data.items():
            poses[name] = Pose.from_dict(name, pose_data)
        return cls(poses=poses)


def flip_posed_rig(rig: Rig, flip_h: bool = False, flip_v: bool = False) -> None:
    """
    Flip a posed rig in-place around its root joint.

    Modifies joint positions, rotations, and part transforms so the entire
    rig appears mirrored.  Must be called on a **cloned** rig (after
    apply_pose) — it mutates joints and parts directly.

    Args:
        rig: A cloned, posed rig to flip in-place.
        flip_h: Mirror horizontally (negate X).
        flip_v: Mirror vertically (negate Y).
    """
    if not flip_h and not flip_v:
        return

    # Single-axis flip negates angles; double-axis (= 180° rotation) preserves them.
    negate_rot = flip_h != flip_v

    for joint in rig.joints.values():
        # Non-root joints: negate local_pos components
        if joint.parent is not None:
            lx = -joint.local_pos.x if flip_h else joint.local_pos.x
            ly = -joint.local_pos.y if flip_v else joint.local_pos.y
            joint.local_pos = Vec2(lx, ly)

        # All joints: negate rotation for single-axis flip
        if negate_rot:
            joint.rotation = -joint.rotation

    for part in rig.parts.values():
        # Negate position offsets
        px = -part.pos.x if flip_h else part.pos.x
        py = -part.pos.y if flip_v else part.pos.y
        part.pos = Vec2(px, py)

        # Negate scale to flip the image
        sx = -part.scale.x if flip_h else part.scale.x
        sy = -part.scale.y if flip_v else part.scale.y
        part.scale = Vec2(sx, sy)

        # Negate rotation for single-axis flip
        if negate_rot:
            part.rotation = -part.rotation

    rig.update_world_positions()


def apply_pose(rig: Rig, pose: Pose, flip_h: bool = False, flip_v: bool = False) -> Rig:
    """
    Apply a pose to a rig and return a new modified rig.

    The original rig is not modified.

    Args:
        rig: The base rig
        pose: The pose to apply

    Returns:
        A new Rig with the pose applied
    """
    # Clone the rig to avoid modifying the original
    result = rig.clone()

    # Apply joint deltas
    for joint_name, delta in pose.joints.items():
        joint = result.joints.get(joint_name)
        if joint:
            if delta.pos is not None:
                joint.local_pos = joint.local_pos + delta.pos
            if delta.rot is not None:
                joint.rotation = joint.rotation + delta.rot

    # Apply part deltas
    for part_name, delta in pose.parts.items():
        part = result.parts.get(part_name)
        if part:
            if delta.pos is not None:
                part.pos = part.pos + delta.pos
            if delta.rot is not None:
                part.rotation = part.rotation + delta.rot
            if delta.scale is not None:
                part.scale = Vec2(
                    part.scale.x * delta.scale.x,
                    part.scale.y * delta.scale.y
                )
            if delta.pivot is not None:
                part.pivot = part.pivot + delta.pivot
            if delta.z is not None:
                part.z = delta.z
            if delta.visible is not None:
                part.visible = delta.visible

    # Recalculate world positions
    result.update_world_positions()

    # Apply flip
    if flip_h or flip_v:
        flip_posed_rig(result, flip_h, flip_v)

    return result


def blend_poses(pose_a: Pose, pose_b: Pose, t: float) -> Pose:
    """
    Blend between two poses.

    Args:
        pose_a: The starting pose
        pose_b: The ending pose
        t: Blend factor (0.0 = pose_a, 1.0 = pose_b)

    Returns:
        A new interpolated Pose
    """
    # Overlays: discrete switch at t=0.5 (dict-based overrides)
    if t < 0.5:
        overlays = pose_a.overlays if pose_a.overlays else pose_b.overlays
    else:
        overlays = pose_b.overlays if pose_b.overlays else pose_a.overlays

    # Attachments: discrete switch at t=0.5 (same as overlays)
    if t < 0.5:
        attachments = pose_a.attachments if pose_a.attachments else pose_b.attachments
    else:
        attachments = pose_b.attachments if pose_b.attachments else pose_a.attachments

    # Sound: discrete switch at t=0.5 (same as overlays)
    if t < 0.5:
        sound = pose_a.sound if pose_a.sound is not None else pose_b.sound
    else:
        sound = pose_b.sound if pose_b.sound is not None else pose_a.sound

    result = Pose(name=f"blend({pose_a.name}, {pose_b.name}, {t:.2f})", overlays=overlays,
                  attachments=attachments, sound=sound)

    # Collect all joint names from both poses
    all_joints = set(pose_a.joints.keys()) | set(pose_b.joints.keys())

    for joint_name in all_joints:
        delta_a = pose_a.get_joint_delta(joint_name)
        delta_b = pose_b.get_joint_delta(joint_name)

        blended = JointDelta()

        # Blend position
        if delta_a.pos is not None or delta_b.pos is not None:
            pos_a = delta_a.pos or Vec2.zero()
            pos_b = delta_b.pos or Vec2.zero()
            blended.pos = pos_a.lerp(pos_b, t)

        # Blend rotation
        if delta_a.rot is not None or delta_b.rot is not None:
            rot_a = delta_a.rot or 0.0
            rot_b = delta_b.rot or 0.0
            blended.rot = lerp_angle(rot_a, rot_b, t)

        if not blended.is_empty():
            result.joints[joint_name] = blended

    # Collect all part names from both poses
    all_parts = set(pose_a.parts.keys()) | set(pose_b.parts.keys())

    for part_name in all_parts:
        delta_a = pose_a.get_part_delta(part_name)
        delta_b = pose_b.get_part_delta(part_name)

        blended = PartDelta()

        # Blend position
        if delta_a.pos is not None or delta_b.pos is not None:
            pos_a = delta_a.pos or Vec2.zero()
            pos_b = delta_b.pos or Vec2.zero()
            blended.pos = pos_a.lerp(pos_b, t)

        # Blend rotation
        if delta_a.rot is not None or delta_b.rot is not None:
            rot_a = delta_a.rot or 0.0
            rot_b = delta_b.rot or 0.0
            blended.rot = lerp_angle(rot_a, rot_b, t)

        # Blend scale
        if delta_a.scale is not None or delta_b.scale is not None:
            scale_a = delta_a.scale or Vec2.one()
            scale_b = delta_b.scale or Vec2.one()
            blended.scale = scale_a.lerp(scale_b, t)

        # Blend pivot
        if delta_a.pivot is not None or delta_b.pivot is not None:
            pivot_a = delta_a.pivot or Vec2.zero()
            pivot_b = delta_b.pivot or Vec2.zero()
            blended.pivot = pivot_a.lerp(pivot_b, t)

        # Z-order: use whichever is set, prefer pose_b at t > 0.5
        if delta_a.z is not None or delta_b.z is not None:
            if t < 0.5:
                blended.z = delta_a.z if delta_a.z is not None else delta_b.z
            else:
                blended.z = delta_b.z if delta_b.z is not None else delta_a.z

        # Visibility: use whichever is set, prefer pose_b at t > 0.5
        if delta_a.visible is not None or delta_b.visible is not None:
            if t < 0.5:
                blended.visible = delta_a.visible if delta_a.visible is not None else delta_b.visible
            else:
                blended.visible = delta_b.visible if delta_b.visible is not None else delta_a.visible

        if not blended.is_empty():
            result.parts[part_name] = blended

    return result


def combine_poses(poses: List[Pose], weights: Optional[List[float]] = None,
                   normalize: bool = True) -> Pose:
    """
    Combine multiple poses with optional weights.

    Args:
        poses: List of poses to combine
        weights: Optional weights for each pose (default: equal weights)
        normalize: If True (default), normalize weights to sum to 1.0.
            If False, use weights as-is for additive blending (e.g. multi-track compositing).

    Returns:
        A new combined Pose
    """
    if not poses:
        return Pose(name="empty")

    if len(poses) == 1:
        return poses[0]

    if weights is None:
        if normalize:
            weights = [1.0 / len(poses)] * len(poses)
        else:
            weights = [1.0] * len(poses)

    # Normalize weights
    if normalize:
        total_weight = sum(weights)
        if total_weight > 0:
            weights = [w / total_weight for w in weights]

    # Combine overlays: merge all override dicts (later poses take precedence)
    combined_overlays = {}
    for pose in poses:
        if pose.overlays:
            combined_overlays.update(pose.overlays)
    combined_overlays = combined_overlays if combined_overlays else None

    # Combine attachments: merge all attachment states (later poses take precedence)
    combined_attachments = {}
    for pose in poses:
        combined_attachments.update(pose.attachments)

    # Sound: last pose with a sound wins
    combined_sound = None
    for pose in poses:
        if pose.sound is not None:
            combined_sound = pose.sound

    result = Pose(name="combined", overlays=combined_overlays,
                  attachments=combined_attachments, sound=combined_sound)

    # Collect all joint names
    all_joints = set()
    for pose in poses:
        all_joints.update(pose.joints.keys())

    for joint_name in all_joints:
        combined = JointDelta()
        combined_pos = Vec2.zero()
        combined_rot = 0.0
        has_pos = False
        has_rot = False

        for pose, weight in zip(poses, weights):
            delta = pose.get_joint_delta(joint_name)
            if delta.pos is not None:
                combined_pos = combined_pos + delta.pos * weight
                has_pos = True
            if delta.rot is not None:
                combined_rot += delta.rot * weight
                has_rot = True

        if has_pos:
            combined.pos = combined_pos
        if has_rot:
            combined.rot = combined_rot

        if not combined.is_empty():
            result.joints[joint_name] = combined

    # Collect all part names
    all_parts = set()
    for pose in poses:
        all_parts.update(pose.parts.keys())

    for part_name in all_parts:
        combined = PartDelta()
        combined_pos = Vec2.zero()
        combined_rot = 0.0
        combined_scale = Vec2.zero()
        combined_pivot = Vec2.zero()
        has_pos = False
        has_rot = False
        has_scale = False
        has_pivot = False

        for pose, weight in zip(poses, weights):
            delta = pose.get_part_delta(part_name)
            if delta.pos is not None:
                combined_pos = combined_pos + delta.pos * weight
                has_pos = True
            if delta.rot is not None:
                combined_rot += delta.rot * weight
                has_rot = True
            if delta.scale is not None:
                combined_scale = combined_scale + delta.scale * weight
                has_scale = True
            if delta.pivot is not None:
                combined_pivot = combined_pivot + delta.pivot * weight
                has_pivot = True

        if has_pos:
            combined.pos = combined_pos
        if has_rot:
            combined.rot = combined_rot
        if has_scale:
            combined.scale = combined_scale
        if has_pivot:
            combined.pivot = combined_pivot

        if not combined.is_empty():
            result.parts[part_name] = combined

    return result
