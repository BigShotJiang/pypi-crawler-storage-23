"""
Rig data structures.

Defines the core classes for representing a 2D skeletal rig:
- Joint: A point in the skeleton hierarchy
- Part: A visual component (image) attached to a joint
- Rig: The complete character rig with all joints and parts
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, TYPE_CHECKING

from .math2d import Vec2, Transform2D

if TYPE_CHECKING:
    from .attachment import AttachmentConfig


@dataclass
class BorderConfig:
    """Border/outline settings for a rig."""
    enabled: bool = False
    width: int = 3
    color: tuple = (0, 0, 0)

    def to_dict(self) -> Dict[str, Any]:
        d: Dict[str, Any] = {"enabled": self.enabled, "width": self.width}
        if self.color != (0, 0, 0):
            d["color"] = "#{:02x}{:02x}{:02x}".format(*self.color)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BorderConfig":
        color = (0, 0, 0)
        if "color" in data:
            hex_str = data["color"].lstrip("#")
            color = (int(hex_str[0:2], 16), int(hex_str[2:4], 16), int(hex_str[4:6], 16))
        return cls(
            enabled=data.get("enabled", False),
            width=data.get("width", 3),
            color=color,
        )


@dataclass
class Joint:
    """
    A joint in the skeleton hierarchy.

    Joints form a tree structure where each joint's position is
    relative to its parent. The root joint has no parent and uses
    absolute coordinates.

    Attributes:
        name: Unique identifier for this joint
        parent: Name of the parent joint (None for root)
        local_pos: Position relative to parent joint
        world_pos: Cached world position (computed during update)
        rotation: Local rotation in degrees (applied to children)
    """

    name: str
    parent: Optional[str] = None
    local_pos: Vec2 = field(default_factory=Vec2.zero)
    world_pos: Vec2 = field(default_factory=Vec2.zero)
    rotation: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON export."""
        d = {
            "parent": self.parent,
            "pos": [self.local_pos.x, self.local_pos.y]
        }
        if self.rotation != 0.0:
            d["rot"] = self.rotation
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> Joint:
        """Create a Joint from dictionary data."""
        pos = data.get("pos", [0, 0])
        return cls(
            name=name,
            parent=data.get("parent"),
            local_pos=Vec2(pos[0], pos[1]),
            rotation=data.get("rot", 0.0)
        )


@dataclass
class Part:
    """
    A visual part attached to a joint.

    Parts are the actual images that make up the character.
    Each part is attached to a joint and has its own local
    transform (offset, rotation, scale) relative to that joint.

    Attributes:
        name: Unique identifier for this part
        image: Path to the image file (relative to rig directory)
        parent_joint: Name of the joint this part is attached to
        pos: Local offset from the joint position
        pivot: The rotation/scale pivot point within the image
        rotation: Local rotation in degrees
        scale: Local scale factor
        z: Z-order for rendering (higher = on top)
        visible: Whether this part should be rendered
    """

    name: str
    image: str
    parent_joint: str
    pos: Vec2 = field(default_factory=Vec2.zero)
    pivot: Vec2 = field(default_factory=Vec2.zero)
    rotation: float = 0.0
    scale: Vec2 = field(default_factory=Vec2.one)
    z: int = 0
    visible: bool = True

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary for JSON export."""
        d = {
            "image": self.image,
            "parent_joint": self.parent_joint,
            "pos": [self.pos.x, self.pos.y],
            "pivot": [self.pivot.x, self.pivot.y],
            "z": self.z
        }
        if self.rotation != 0.0:
            d["rot"] = self.rotation
        if self.scale.x != 1.0 or self.scale.y != 1.0:
            d["scale"] = [self.scale.x, self.scale.y]
        if not self.visible:
            d["visible"] = False
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> Part:
        """Create a Part from dictionary data."""
        pos = data.get("pos", [0, 0])
        pivot = data.get("pivot", [0, 0])
        scale = data.get("scale", [1, 1])
        return cls(
            name=name,
            image=data.get("image", ""),
            parent_joint=data.get("parent_joint", "root"),
            pos=Vec2(pos[0], pos[1]),
            pivot=Vec2(pivot[0], pivot[1]),
            rotation=data.get("rot", 0.0),
            scale=Vec2(scale[0], scale[1]) if isinstance(scale, list) else Vec2(scale, scale),
            z=data.get("z", 0),
            visible=data.get("visible", True)
        )

    def get_world_transform(self, joint_world_pos: Vec2, joint_world_rot: float) -> Transform2D:
        """
        Calculate the world transform for this part.

        Args:
            joint_world_pos: The world position of the parent joint
            joint_world_rot: The accumulated world rotation of the parent joint

        Returns:
            A Transform2D representing this part's world transform
        """
        # The part's position is offset from the joint, then rotated
        rotated_offset = self.pos.rotated(joint_world_rot)
        world_pos = joint_world_pos + rotated_offset

        return Transform2D(
            position=world_pos,
            rotation=joint_world_rot + self.rotation,
            scale=self.scale,
            pivot=self.pivot
        )


@dataclass
class Rig:
    """
    A complete character rig.

    Contains the skeleton (joints) and visual components (parts)
    that make up a character. Provides methods for loading from
    JSON and computing world transforms.

    Attributes:
        name: Name of this rig
        canvas_size: The canvas dimensions [width, height]
        joints: Dictionary of joints by name
        parts: Dictionary of parts by name
        base_path: Base directory path for resolving image paths
    """

    name: str = "unnamed"
    canvas_size: Vec2 = field(default_factory=lambda: Vec2(1000, 1400))
    joints: Dict[str, Joint] = field(default_factory=dict)
    parts: Dict[str, Part] = field(default_factory=dict)
    base_path: str = ""
    attachment_config: Optional["AttachmentConfig"] = None
    border: Optional[BorderConfig] = None
    active_overlays: List[str] = field(default_factory=list)
    slots: List[str] = field(default_factory=list)

    def get_root_joint(self) -> Optional[Joint]:
        """Return the root joint (the one with no parent)."""
        for joint in self.joints.values():
            if joint.parent is None:
                return joint
        return None

    def get_children(self, joint_name: str) -> List[Joint]:
        """Return all joints that are children of the given joint."""
        return [j for j in self.joints.values() if j.parent == joint_name]

    def get_joint_order(self) -> List[str]:
        """
        Return joint names in hierarchical order (parents before children).
        This ensures proper world position calculation.
        """
        order = []
        visited = set()

        def visit(name: str):
            if name in visited:
                return
            joint = self.joints.get(name)
            if joint is None:
                return
            if joint.parent and joint.parent not in visited:
                visit(joint.parent)
            visited.add(name)
            order.append(name)

        for name in self.joints:
            visit(name)

        return order

    def update_world_positions(self):
        """
        Compute world positions for all joints.
        Must be called after modifying joint local positions or rotations.
        """
        # Process joints in hierarchical order
        for name in self.get_joint_order():
            joint = self.joints[name]
            if joint.parent is None:
                # Root joint: local position is world position
                joint.world_pos = joint.local_pos
            else:
                parent = self.joints.get(joint.parent)
                if parent:
                    # Child joint: position is relative to parent, rotated by parent's rotation
                    rotated_local = joint.local_pos.rotated(self._get_world_rotation(joint.parent))
                    joint.world_pos = parent.world_pos + rotated_local
                else:
                    joint.world_pos = joint.local_pos

    def _get_world_rotation(self, joint_name: str) -> float:
        """Get the accumulated world rotation for a joint."""
        total = 0.0
        current = joint_name
        while current:
            joint = self.joints.get(current)
            if joint:
                total += joint.rotation
                current = joint.parent
            else:
                break
        return total

    def get_world_rotation(self, joint_name: str) -> float:
        """Get the accumulated world rotation for a joint (public API)."""
        return self._get_world_rotation(joint_name)

    def get_parts_sorted_by_z(self) -> List[Part]:
        """Return parts sorted by z-order for rendering."""
        return sorted(self.parts.values(), key=lambda p: p.z)

    def get_part_world_transform(self, part_name: str) -> Optional[Transform2D]:
        """Get the world transform for a specific part."""
        part = self.parts.get(part_name)
        if not part:
            return None

        joint = self.joints.get(part.parent_joint)
        if not joint:
            return None

        world_rot = self._get_world_rotation(part.parent_joint)
        return part.get_world_transform(joint.world_pos, world_rot)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the rig to a dictionary for JSON export."""
        d = {
            "name": self.name,
            "canvas": [self.canvas_size.x, self.canvas_size.y],
            "joints": {name: joint.to_dict() for name, joint in self.joints.items()},
            "parts": {name: part.to_dict() for name, part in self.parts.items()}
        }
        # Include attachment config if present
        if self.attachment_config is not None:
            d["attachment"] = self.attachment_config.to_dict()
        if self.border is not None:
            d["border"] = self.border.to_dict()
        if self.active_overlays:
            d["active_overlays"] = list(self.active_overlays)
        if self.slots:
            d["slots"] = list(self.slots)
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any], name: str = "unnamed", base_path: str = "") -> Rig:
        """Create a Rig from dictionary data."""
        from .attachment import AttachmentConfig

        # Use name from dict if caller didn't provide one
        name = data.get("name", name)
        canvas = data.get("canvas", [1000, 1400])

        joints = {}
        for joint_name, joint_data in data.get("joints", {}).items():
            joints[joint_name] = Joint.from_dict(joint_name, joint_data)

        parts = {}
        for part_name, part_data in data.get("parts", {}).items():
            parts[part_name] = Part.from_dict(part_name, part_data)

        # Parse attachment config if present
        attachment_config = None
        if "attachment" in data:
            attachment_config = AttachmentConfig.from_dict(data["attachment"])

        # Parse border config if present
        border = None
        if "border" in data:
            border = BorderConfig.from_dict(data["border"])

        active_overlays = data.get("active_overlays", [])
        slots = data.get("slots", [])

        rig = cls(
            name=name,
            canvas_size=Vec2(canvas[0], canvas[1]),
            joints=joints,
            parts=parts,
            base_path=base_path,
            attachment_config=attachment_config,
            border=border,
            active_overlays=active_overlays,
            slots=slots,
        )

        # Initialize world positions
        rig.update_world_positions()

        return rig

    def clone(self) -> Rig:
        """Create a deep copy of this rig."""
        import copy
        return copy.deepcopy(self)
