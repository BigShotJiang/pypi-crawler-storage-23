"""
Pure-Python render item collection (the "render plan").

Collects all renderable items (parts, overlays, attachments) into a
z-sorted list that can be consumed by any renderer backend. No Ren'Py
dependency.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .math2d import Vec2, Transform2D
from .rig import Rig
from .pose import Pose, apply_pose, flip_posed_rig
from .overlay import OverlayLibrary
from .attachment import (
    AttachmentConfig, AttachmentInstance,
    compute_attachment_transform, get_attachment_part_world_transform,
)
from .animation import resolve_frame_toggles


def build_render_items(
    posed_rig: Rig,
    overlay_library: OverlayLibrary,
    active_overlays: list,
    attachment_instances: Dict[str, AttachmentInstance],
    pose: Optional[Pose] = None,
    flip_h: bool = False,
    flip_v: bool = False,
) -> List[Tuple]:
    """Collect all renderable items sorted by z-order.

    Returns a list of ``(z_order, item_type, data)`` tuples where:

    - ``item_type`` is ``'part'``, ``'overlay'``, or ``'attachment'``
    - ``data`` is:
      - ``Part`` for ``'part'``
      - ``(OverlayPart, overlay_name, Part)`` for ``'overlay'``
      - ``(Part, AttachmentInstance, Transform2D)`` for ``'attachment'``
    """
    items: list = []

    # Resolve active overlays with pose overrides (include/exclude/inherit)
    pose_overlay_overrides = pose.overlays if pose else None
    all_overlays = resolve_frame_toggles(active_overlays, pose_overlay_overrides)

    # First, collect which parts are replaced by overlays
    replaced_parts: set = set()
    for overlay_name in all_overlays:
        overlay = overlay_library.get(overlay_name)
        if overlay is None:
            continue
        for part_name, overlay_part in overlay.parts.items():
            if overlay_part.replace:
                replaced_parts.add(part_name)

    # Add all visible parts (except those that are replaced)
    for part in posed_rig.parts.values():
        if part.visible and part.name not in replaced_parts:
            items.append((part.z, 'part', part))

    # Add overlay parts
    for overlay_name in all_overlays:
        overlay = overlay_library.get(overlay_name)
        if overlay is None:
            continue

        for part_name, overlay_part in overlay.parts.items():
            base_part = posed_rig.parts.get(part_name)
            if base_part is None or not base_part.visible:
                continue

            # Compute effective z-order
            effective_z = base_part.z + overlay_part.effective_z_delta
            items.append((effective_z, 'overlay', (overlay_part, overlay_name, base_part)))

    # Add attachment parts
    for attach_name, instance in attachment_instances.items():
        # Check if attachment is visible
        if not instance.visible:
            continue

        # Check for pose-specific attachment state
        attach_state = None
        if pose and pose.attachments:
            attach_state = pose.attachments.get(attach_name)
            if attach_state and not attach_state.visible:
                continue

        # Determine host joint (pose override > instance > attachment default)
        host_joint = instance.host_joint
        if attach_state and attach_state.host_joint:
            host_joint = attach_state.host_joint

        if not host_joint or host_joint not in posed_rig.joints:
            continue

        # Get attachment rig and apply pose
        attach_rig = instance.attachment_rig
        if attach_rig is None:
            continue

        # Check for active attachment animation
        if instance._player and instance._player.is_playing:
            current_pose = instance._player.get_current_pose()
            posed_attach_rig = apply_pose(attach_rig, current_pose)
        else:
            # Determine attachment pose
            attach_pose_name = instance.current_pose
            if attach_state and attach_state.pose:
                attach_pose_name = attach_state.pose

            # Apply attachment pose if available
            if instance.attachment_poses and attach_pose_name != "neutral":
                attach_pose = instance.attachment_poses.get(attach_pose_name)
                if attach_pose:
                    posed_attach_rig = apply_pose(attach_rig, attach_pose)
                else:
                    posed_attach_rig = attach_rig.clone()
            else:
                posed_attach_rig = attach_rig.clone()

        # Apply flip to attachment rig clone
        if flip_h or flip_v:
            flip_posed_rig(posed_attach_rig, flip_h, flip_v)
        else:
            posed_attach_rig.update_world_positions()

        # Get attachment config
        config = attach_rig.attachment_config or AttachmentConfig()

        # Compute flipped offsets for attachment
        pos_offset = instance.pos_offset
        rot_offset = instance.rot_offset
        if (flip_h or flip_v) and pos_offset is not None:
            flip_px = -pos_offset.x if flip_h else pos_offset.x
            flip_py = -pos_offset.y if flip_v else pos_offset.y
            pos_offset = Vec2(flip_px, flip_py)
        if (flip_h != flip_v) and rot_offset:
            rot_offset = -rot_offset

        # Compute root transform for attachment (with binding offsets)
        root_transform = compute_attachment_transform(
            posed_rig, host_joint, config,
            pos_offset=pos_offset,
            rot_offset=rot_offset
        )

        # Apply scale offset from the attachment binding
        if instance.scale_offset.x != 1.0 or instance.scale_offset.y != 1.0:
            root_transform = Transform2D(
                position=root_transform.position,
                rotation=root_transform.rotation,
                scale=Vec2(
                    root_transform.scale.x * instance.scale_offset.x,
                    root_transform.scale.y * instance.scale_offset.y
                ),
                pivot=root_transform.pivot
            )

        # Calculate z-offset
        base_z_offset = config.z_offset + instance.z_offset

        # Add each attachment part to render items
        for part in posed_attach_rig.parts.values():
            if not part.visible:
                continue

            # Compute world transform for this attachment part
            world_transform = get_attachment_part_world_transform(
                posed_attach_rig, part.name, root_transform
            )
            if world_transform is None:
                continue

            # Effective z includes attachment's z-offset
            effective_z = part.z + base_z_offset
            items.append((effective_z, 'attachment', (part, instance, world_transform)))

    # Sort by z-order (stable sort preserves order for equal z)
    items.sort(key=lambda x: x[0])
    return items
