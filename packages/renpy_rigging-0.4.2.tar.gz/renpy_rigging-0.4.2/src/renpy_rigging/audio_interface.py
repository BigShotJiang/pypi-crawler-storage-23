"""
Audio backend protocol and null implementation.

Defines the interface that audio backends must implement, plus a no-op
backend for testing and headless use outside Ren'Py.
"""

from __future__ import annotations

from typing import Optional


class AudioBackend:
    """Protocol-style base class for audio backends.

    Subclass and override methods to integrate with a specific engine.
    """

    def play(self, path: str, channel: str, loop: bool = False, base_path: str = "") -> None:
        raise NotImplementedError

    def stop(self, channel: str) -> None:
        raise NotImplementedError

    def get_playing(self, channel: str) -> Optional[str]:
        raise NotImplementedError

    def register_channels(self) -> None:
        raise NotImplementedError


class NullAudioBackend(AudioBackend):
    """No-op backend for testing and headless use."""

    def play(self, path: str, channel: str, loop: bool = False, base_path: str = "") -> None:
        pass

    def stop(self, channel: str) -> None:
        pass

    def get_playing(self, channel: str) -> Optional[str]:
        return None

    def register_channels(self) -> None:
        pass
