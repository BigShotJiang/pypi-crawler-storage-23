"""
Audio channel management for rig sound effects.

Provides pre-registered Ren'Py audio channels for pose sounds,
scene ambient audio, and animation timeline sound effects.

Uses a pluggable backend: auto-selects Ren'Py when available,
falls back to a no-op backend otherwise. Call ``set_audio_backend()``
to override explicitly.
"""

from __future__ import annotations

import os
from typing import Optional

from .audio_interface import AudioBackend, NullAudioBackend

# Channel names
CHANNEL_POSE = "rig_pose"
CHANNEL_SCENE = "rig_scene"
CHANNEL_SFX_PREFIX = "rig_sfx_"
SFX_CHANNEL_COUNT = 4


# ── Ren'Py backend ──────────────────────────────────────────────────

class _RenpyAudioBackend(AudioBackend):
    """Backend that delegates to ``renpy.music.*``."""

    def __init__(self):
        import renpy.exports as _renpy
        self._renpy = _renpy

    def play(self, path, channel, loop=False, base_path=""):
        resolved = self._resolve_path(path, base_path)
        if not resolved:
            return
        self._renpy.music.play(resolved, channel=channel, loop=loop)

    def stop(self, channel):
        self._renpy.music.stop(channel=channel)

    def get_playing(self, channel):
        return self._renpy.music.get_playing(channel=channel)

    def register_channels(self):
        self._renpy.music.register_channel(CHANNEL_POSE, "sfx", loop=False)
        self._renpy.music.register_channel(CHANNEL_SCENE, "sfx", loop=True)
        for i in range(SFX_CHANNEL_COUNT):
            self._renpy.music.register_channel(
                "{}{}".format(CHANNEL_SFX_PREFIX, i), "sfx", loop=False
            )

    def _resolve_path(self, path, base_path=""):
        """Resolve a sound path relative to base_path."""
        if not path:
            return ""
        full_path = path
        if base_path:
            full_path = os.path.join(base_path, path)
        full_path = full_path.replace("\\", "/")

        gamedir = self._renpy.config.gamedir.replace("\\", "/")
        if not gamedir.endswith("/"):
            gamedir += "/"
        if full_path.startswith(gamedir):
            full_path = full_path[len(gamedir):]

        return full_path


# ── Global backend instance ─────────────────────────────────────────

_backend: Optional[AudioBackend] = None


def _get_backend() -> AudioBackend:
    """Return the active backend, auto-detecting on first call."""
    global _backend
    if _backend is None:
        try:
            _backend = _RenpyAudioBackend()
        except ImportError:
            _backend = NullAudioBackend()
    return _backend


def set_audio_backend(backend: AudioBackend) -> None:
    """Override the global audio backend.

    Useful for testing or integrating with non-Ren'Py engines.
    """
    global _backend
    _backend = backend


# ── Public API (unchanged signatures) ───────────────────────────────

def register_channels():
    """Register rig audio channels with the active backend. Call at init time."""
    _get_backend().register_channels()


def play_sound(path, channel, loop=False, base_path=""):
    """Play a sound file, resolving path relative to base_path."""
    if not path:
        return
    _get_backend().play(path, channel, loop=loop, base_path=base_path)


def stop_channel(channel):
    """Stop a channel."""
    _get_backend().stop(channel)


def get_playing(channel):
    """Get the currently playing file on a channel, or None."""
    return _get_backend().get_playing(channel)
