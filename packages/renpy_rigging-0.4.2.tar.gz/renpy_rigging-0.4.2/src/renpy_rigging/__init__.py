"""
renpy-rigging: A 2D skeletal rigging, posing, and animation system for Ren'Py.

This package provides:
- Rig data structures for 2D skeletal characters
- Pose application and blending
- Animation playback
- Ren'Py-native displayable rendering

Basic Usage:
    from renpy_rigging import Rig, PoseLibrary, AnimationLibrary, RigRenderer

    # Load assets
    rig = Rig.load("characters/vince/rig.json")
    poses = PoseLibrary.load("characters/vince/poses.json")
    anims = AnimationLibrary.load("characters/vince/animations.json")

    # Create renderer
    renderer = RigRenderer(rig, poses, anims)

    # In Ren'Py script:
    # show expression renderer.show_pose("neutral") at center
    # show expression renderer.play_animation("idle", loop=True) at center
"""

__version__ = "0.4.2"

# Core data structures
from .math2d import Vec2, Transform2D, lerp, lerp_angle

from .rig import (
    BorderConfig,
    Joint,
    Part,
    Rig,
)

from .pose import (
    JointDelta,
    PartDelta,
    Pose,
    PoseLibrary,
    apply_pose,
    flip_posed_rig,
    blend_poses,
    combine_poses,
)

from .animation import (
    AnimationFrame,
    AnimationSound,
    AnimationTrack,
    Animation,
    AnimationLibrary,
    AnimationPlayer,
    PlayMode,
    EaseType,
    resolve_frame_toggles,
)

from .overlay import (
    OverlayPart,
    Overlay,
    OverlayLibrary,
)

from .attachment import (
    AttachmentConfig,
    AttachmentPoseState,
    AttachmentBinding,
    AttachmentLibrary,
    AttachmentInstance,
    compute_attachment_transform,
    get_attachment_part_world_transform,
)

from .scene import (
    SceneBackground,
    SceneLayer,
    SceneItem,
    SceneCharacter,
    SceneAttachment,
    SceneActionStep,
    SceneActionTrack,
    SceneAction,
    ActionStepper,
    Scene,
)

# Audio utilities
from .audio import (
    CHANNEL_POSE,
    CHANNEL_SCENE,
    CHANNEL_SFX_PREFIX,
    SFX_CHANNEL_COUNT,
    register_channels,
    play_sound,
    stop_channel,
    get_playing,
)

# I/O utilities
from .io import (
    load_json,
    save_json,
    load_rig,
    save_rig,
    load_poses,
    save_poses,
    load_animations,
    save_animations,
    load_overlays,
    save_overlays,
    load_attachments,
    save_attachments,
    list_attachments,
    RigAssets,
    load_scene,
    save_scene,
    list_scenes,
)

# Pure-Python extraction modules (always available, no Ren'Py required)
from .png_utils import get_png_dimensions, get_png_opaque_bbox, compute_content_bounds
from .color_utils import parse_color, border_offsets, compute_blit_position, compute_anchor_blit
from .render_plan import build_render_items
from .rig_state import RigState
from .audio_interface import AudioBackend, NullAudioBackend

# Ren'Py rendering (only available inside Ren'Py)
try:
    from .render import (
        RigDisplayable,
        DynamicRig,
        RigRenderer,
        SceneDisplayable,
        SceneRenderer,
        SceneActionPlayer,
        SceneManager,
    )
except RuntimeError:
    # Ren'Py not available - render classes won't work
    RigDisplayable = None
    DynamicRig = None
    RigRenderer = None
    SceneDisplayable = None
    SceneRenderer = None
    SceneActionPlayer = None
    SceneManager = None

# Convenience loaders that mirror the API shown in the README
Rig.load = classmethod(lambda cls, path, base_path="": load_rig(path, base_path))
PoseLibrary.load = classmethod(lambda cls, path, base_path="": load_poses(path, base_path))
AnimationLibrary.load = classmethod(lambda cls, path, base_path="": load_animations(path, base_path))
OverlayLibrary.load = classmethod(lambda cls, path, base_path="": load_overlays(path, base_path))
AttachmentLibrary.load = classmethod(lambda cls, path, base_path="": load_attachments(path, base_path))
Scene.load = classmethod(lambda cls, path, base_path="": load_scene(path, base_path))


__all__ = [
    # Version
    "__version__",

    # Math utilities
    "Vec2",
    "Transform2D",
    "lerp",
    "lerp_angle",

    # Core data structures
    "Joint",
    "Part",
    "Rig",

    # Pose system
    "JointDelta",
    "PartDelta",
    "Pose",
    "PoseLibrary",
    "apply_pose",
    "flip_posed_rig",
    "blend_poses",
    "combine_poses",

    # Animation system
    "AnimationFrame",
    "AnimationSound",
    "AnimationTrack",
    "Animation",
    "AnimationLibrary",
    "AnimationPlayer",
    "PlayMode",
    "EaseType",
    "resolve_frame_toggles",

    # Overlay system
    "OverlayPart",
    "Overlay",
    "OverlayLibrary",

    # Attachment system
    "AttachmentConfig",
    "AttachmentPoseState",
    "AttachmentBinding",
    "AttachmentLibrary",
    "AttachmentInstance",
    "compute_attachment_transform",
    "get_attachment_part_world_transform",

    # Scene system
    "SceneBackground",
    "SceneLayer",
    "SceneItem",
    "SceneCharacter",
    "SceneAttachment",
    "SceneActionStep",
    "SceneActionTrack",
    "SceneAction",
    "ActionStepper",
    "Scene",

    # Audio utilities
    "CHANNEL_POSE",
    "CHANNEL_SCENE",
    "CHANNEL_SFX_PREFIX",
    "SFX_CHANNEL_COUNT",
    "register_channels",
    "play_sound",
    "stop_channel",
    "get_playing",

    # I/O utilities
    "load_json",
    "save_json",
    "load_rig",
    "save_rig",
    "load_poses",
    "save_poses",
    "load_animations",
    "save_animations",
    "load_overlays",
    "save_overlays",
    "load_attachments",
    "save_attachments",
    "list_attachments",
    "load_scene",
    "save_scene",
    "list_scenes",
    "RigAssets",

    # Pure-Python extraction modules
    "get_png_dimensions",
    "get_png_opaque_bbox",
    "compute_content_bounds",
    "parse_color",
    "border_offsets",
    "compute_blit_position",
    "compute_anchor_blit",
    "build_render_items",
    "RigState",
    "AudioBackend",
    "NullAudioBackend",

    # Ren'Py rendering
    "RigDisplayable",
    "DynamicRig",
    "RigRenderer",
    "SceneDisplayable",
    "SceneRenderer",
    "SceneActionPlayer",
    "SceneManager",
]
