"""
Pure-Python color and geometry helpers.

Provides color parsing, border offset generation, and blit position
computation used by the rendering pipeline. No Ren'Py dependency.
"""

from __future__ import annotations

import math
from typing import Tuple

from .math2d import Transform2D


def parse_color(color) -> Tuple[int, int, int]:
    """Normalise a color to an (r, g, b) tuple.

    Accepts hex strings (``"#rgb"``, ``"#rrggbb"``) or ``(r, g, b)`` tuples.
    """
    if isinstance(color, str):
        h = color.lstrip("#")
        if len(h) == 3:
            h = h[0]*2 + h[1]*2 + h[2]*2
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    return tuple(color[:3])


def border_offsets(width: int) -> list:
    """Return ``(dx, dy)`` tuples forming a filled circle of the given radius."""
    offsets = []
    for dx in range(-width, width + 1):
        for dy in range(-width, width + 1):
            if dx * dx + dy * dy <= width * width and (dx, dy) != (0, 0):
                offsets.append((dx, dy))
    return offsets


def compute_anchor_blit(
    orig_w: float, orig_h: float,
    pivot_x: float, pivot_y: float,
    scale_x: float, scale_y: float,
    rotation: float,
    world_x: float, world_y: float,
) -> Tuple[float, float]:
    """Compute blit position using anchor-based (pivot-centered) transform math.

    Transforms the four image corners around the pivot point using the same
    scale+rotate order as Ren'Py's ``transform_anchor=True``, finds the AABB,
    and returns where to blit so the pivot aligns with (world_x, world_y).
    """
    if rotation == 0 and scale_x == 1 and scale_y == 1:
        return (world_x - pivot_x, world_y - pivot_y)

    rad = math.radians(rotation) if rotation else 0
    cos_a = math.cos(rad)
    sin_a = math.sin(rad)

    corners = [(0, 0), (orig_w, 0), (orig_w, orig_h), (0, orig_h)]
    min_x = float('inf')
    min_y = float('inf')

    for cx, cy in corners:
        # Scale around pivot
        sx = pivot_x + (cx - pivot_x) * scale_x
        sy = pivot_y + (cy - pivot_y) * scale_y
        # Rotate around pivot
        dx = sx - pivot_x
        dy = sy - pivot_y
        rx = pivot_x + dx * cos_a - dy * sin_a
        ry = pivot_y + dx * sin_a + dy * cos_a
        if rx < min_x:
            min_x = rx
        if ry < min_y:
            min_y = ry

    # Pivot position in the normalized AABB render
    anchor_x = pivot_x - min_x
    anchor_y = pivot_y - min_y

    return (world_x - anchor_x, world_y - anchor_y)


def compute_blit_position(
    transform: Transform2D, orig_w: float, orig_h: float
) -> Tuple[float, float]:
    """Compute the top-left blit position for a rig part.

    Uses the transform's pivot, scale, rotation, and world position to
    determine where the rendered image should be placed so that the
    part's pivot aligns with its world position.

    Args:
        transform: The part's world transform.
        orig_w: Original image width in pixels.
        orig_h: Original image height in pixels.

    Returns:
        ``(blit_x, blit_y)`` in canvas coordinates.
    """
    return compute_anchor_blit(
        orig_w, orig_h,
        transform.pivot.x, transform.pivot.y,
        transform.scale.x, transform.scale.y,
        transform.rotation,
        transform.position.x, transform.position.y,
    )
