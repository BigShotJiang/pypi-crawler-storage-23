"""
Overlay system for layering additional art assets over character rigs.

An overlay associates art assets with body parts (e.g., a suit coat covering
torso and arm parts). Overlays inherit transforms from the parts they cover
and render on top with a configurable z-delta.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any


@dataclass
class OverlayPart:
    """
    A single part within an overlay.

    Each overlay part covers a specific rig part and renders on top of it,
    inheriting the same world transform.
    """

    part_name: str  # The rig part this overlays (e.g., "arm1_l")
    path: Optional[str] = None  # Image path relative to character dir, or None for default
    z_delta: Optional[int] = None  # Z offset relative to the base part (default: 0 if replace, else +1)
    replace: bool = False  # If True, hide the base part when this overlay is active

    @property
    def effective_z_delta(self) -> int:
        """Get the effective z_delta, applying defaults based on replace flag."""
        if self.z_delta is not None:
            return self.z_delta
        return 0 if self.replace else 1

    def get_image_path(self, overlay_name: str) -> str:
        """
        Get the image path for this overlay part, relative to the rig directory.

        Args:
            overlay_name: The name of the parent overlay (used for path construction)

        Returns:
            The image path relative to the rig's base_path:
            overlays/<overlay_name>/<path_or_part_name.png>
        """
        filename = self.path if self.path is not None else f"{self.part_name}.png"
        return f"overlays/{overlay_name}/{filename}"

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        # If using all defaults, just return True for compact JSON
        if self.path is None and self.z_delta is None and not self.replace:
            return True

        d = {}
        if self.path is not None:
            d["path"] = self.path
        if self.z_delta is not None:
            d["z_delta"] = self.z_delta
        if self.replace:
            d["replace"] = self.replace
        return d if d else True

    @classmethod
    def from_dict(cls, part_name: str, data: Any) -> OverlayPart:
        """
        Create from dictionary or True shorthand.

        Args:
            part_name: The rig part name this overlays
            data: Either True (for defaults) or a dict with path/z_delta/replace
        """
        if data is True:
            return cls(part_name=part_name)

        # Check for dict-like object (hasattr 'get' method) for broader compatibility
        if hasattr(data, 'get'):
            return cls(
                part_name=part_name,
                path=data.get("path"),
                z_delta=data.get("z_delta"),  # None if not specified, effective_z_delta handles default
                replace=data.get("replace", False)
            )

        raise ValueError(f"Invalid overlay part data: {data}")


@dataclass
class Overlay:
    """
    An overlay that covers multiple rig parts with additional art.

    For example, a suit coat overlay might cover torso, arm1_l, arm1_r,
    arm2_l, and arm2_r parts.
    """

    name: str = ""
    parts: Dict[str, OverlayPart] = field(default_factory=dict)
    slot: str = ""

    def get_part(self, part_name: str) -> Optional[OverlayPart]:
        """Get an overlay part by name, or None if not covered."""
        return self.parts.get(part_name)

    def covers_part(self, part_name: str) -> bool:
        """Check if this overlay covers a specific rig part."""
        return part_name in self.parts

    def get_covered_parts(self) -> List[str]:
        """Return list of rig part names covered by this overlay."""
        return list(self.parts.keys())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {
            part_name: part.to_dict()
            for part_name, part in self.parts.items()
        }
        if self.slot:
            d["_slot"] = self.slot
        return d

    @classmethod
    def from_dict(cls, name: str, data: Dict[str, Any]) -> Overlay:
        """Create from dictionary."""
        data = dict(data)  # shallow copy to avoid mutating caller's dict
        slot = data.pop("_slot", "")
        parts = {}
        for part_name, part_data in data.items():
            parts[part_name] = OverlayPart.from_dict(part_name, part_data)
        return cls(name=name, parts=parts, slot=slot)


@dataclass
class OverlayLibrary:
    """
    A collection of named overlays for a character.

    Loaded from overlays.json in the character directory.
    """

    overlays: Dict[str, Overlay] = field(default_factory=dict)

    def get(self, name: str) -> Optional[Overlay]:
        """Get an overlay by name."""
        return self.overlays.get(name)

    def add(self, overlay: Overlay) -> None:
        """Add or replace an overlay."""
        self.overlays[overlay.name] = overlay

    def remove(self, name: str) -> bool:
        """Remove an overlay by name. Returns True if removed."""
        if name in self.overlays:
            del self.overlays[name]
            return True
        return False

    def list_names(self) -> List[str]:
        """Return a list of all overlay names."""
        return list(self.overlays.keys())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {name: overlay.to_dict() for name, overlay in self.overlays.items()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> OverlayLibrary:
        """Create from dictionary."""
        overlays = {}
        for name, overlay_data in data.items():
            overlays[name] = Overlay.from_dict(name, overlay_data)
        return cls(overlays=overlays)
