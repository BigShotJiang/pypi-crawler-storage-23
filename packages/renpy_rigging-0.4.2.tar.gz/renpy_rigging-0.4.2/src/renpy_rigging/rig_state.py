"""
Pure-Python rig state management.

Tracks overlays, attachments, outline settings, and other mutable state
for a rigged character. No Ren'Py dependency — usable for testing,
headless rendering, and non-Ren'Py engines.
"""

from __future__ import annotations

import os
from typing import Dict, List, Optional

from .math2d import Vec2, Transform2D
from .rig import Rig
from .pose import Pose, PoseLibrary, apply_pose, flip_posed_rig
from .animation import AnimationLibrary, AnimationPlayer
from .overlay import OverlayLibrary
from .attachment import (
    AttachmentConfig, AttachmentPoseState, AttachmentBinding,
    AttachmentLibrary, AttachmentInstance,
)
from .render_plan import build_render_items


class RigState:
    """Pure-Python state container for a rigged character.

    Manages overlays, attachments, outline settings, and provides
    ``build_render_items()`` for producing a render plan without any
    engine dependency.

    Users who want pure-Python access (testing, headless rendering,
    non-Ren'Py engines) can use this class directly. Inside Ren'Py,
    ``RigDisplayable`` wraps a ``RigState`` instance.
    """

    def __init__(
        self,
        rig: Rig,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        overlays: Optional[OverlayLibrary] = None,
        attachment_library: Optional[AttachmentLibrary] = None,
        base_path: str = "",
    ):
        self.rig = rig
        self.poses = poses or PoseLibrary()
        self.animations = animations or AnimationLibrary()
        self.overlays = overlays or OverlayLibrary()
        self.attachment_library = attachment_library or AttachmentLibrary()
        self.base_path = base_path

        # Runtime overlay toggles (merged with pose overlays at render time)
        self.active_overlays: list = []

        # Attachment instances (keyed by attachment name)
        self.attachment_instances: Dict[str, AttachmentInstance] = {}

        # Current animation player
        self._player: Optional[AnimationPlayer] = None

        # Track last-played pose sound to avoid re-triggering
        self._current_pose_sound: Optional[str] = None

        # On-demand outline (mutable — DynamicRig reads these each frame)
        self.outline_color = None   # (r, g, b) tuple or hex string or None
        self.outline_width = 3      # pixels
        self.outline_alpha = 1.0    # 0.0–1.0

    # ── Attachment management ────────────────────────────────────

    def add_attachment(
        self,
        name: str,
        attachment_rig: Optional[Rig] = None,
        host_joint: Optional[str] = None,
        poses: Optional[PoseLibrary] = None,
        animations: Optional[AnimationLibrary] = None,
        z_offset: int = 0,
        pos_offset: Optional[Vec2] = None,
        rot_offset: Optional[float] = None,
        scale_offset: Optional[Vec2] = None,
        slot: str = ""
    ) -> AttachmentInstance:
        """Add an attachment to this character.

        If only name is provided, the attachment will be loaded from the
        attachment library (attachments.json). Otherwise, all parameters
        must be provided.

        Returns:
            The created AttachmentInstance.
        """
        # If attachment_rig is not provided, try to load from attachment library
        if attachment_rig is None:
            binding = self.attachment_library.get(name)
            if binding is None:
                raise ValueError(
                    f"Attachment '{name}' not found in attachment library. "
                    f"Either provide attachment_rig explicitly or add '{name}' to attachments.json"
                )

            # Load the attachment rig
            from .io import load_rig, load_poses, load_animations

            # binding.path is relative to base_path (or game directory)
            attach_rig_path = os.path.join(binding.path, "rig.json")
            attachment_rig = load_rig(attach_rig_path, self.base_path)

            # Load attachment poses if available and not provided
            if poses is None:
                try:
                    attach_poses_path = os.path.join(binding.path, "poses.json")
                    poses = load_poses(attach_poses_path, self.base_path)
                except (FileNotFoundError, IOError):
                    pass

            # Load attachment animations if available and not provided
            if animations is None:
                try:
                    attach_anims_path = os.path.join(binding.path, "animations.json")
                    animations = load_animations(attach_anims_path, self.base_path)
                except (FileNotFoundError, IOError):
                    pass

            # Use binding values if not explicitly provided
            if host_joint is None:
                host_joint = binding.default_joint
            if pos_offset is None and (binding.pos.x != 0 or binding.pos.y != 0):
                pos_offset = binding.pos
            if rot_offset is None:
                rot_offset = binding.rot
            if z_offset == 0 and binding.z_offset != 0:
                z_offset = binding.z_offset
            if scale_offset is None and (binding.scale.x != 1 or binding.scale.y != 1):
                scale_offset = binding.scale
            if not slot and binding.slot:
                slot = binding.slot

        # Fall back to the attachment rig's own config slot
        if not slot and attachment_rig and attachment_rig.attachment_config:
            slot = attachment_rig.attachment_config.slot or ""

        # Slot-aware eviction: remove any existing attachment in the same slot
        if slot:
            for inst_name, inst in list(self.attachment_instances.items()):
                if inst.slot == slot:
                    self.remove_attachment(inst_name)

        # Validate required parameters
        if attachment_rig is None:
            raise ValueError("attachment_rig is required")
        if host_joint is None:
            raise ValueError("host_joint is required")
        if rot_offset is None:
            rot_offset = 0.0
        if scale_offset is None:
            scale_offset = Vec2.one()

        instance = AttachmentInstance(
            name=name,
            attachment_rig=attachment_rig,
            attachment_poses=poses,
            attachment_animations=animations,
            host_joint=host_joint,
            z_offset=z_offset,
            pos_offset=pos_offset,
            rot_offset=rot_offset,
            scale_offset=scale_offset,
            slot=slot
        )
        self.attachment_instances[name] = instance
        return instance

    def remove_attachment(self, name: str) -> bool:
        """Remove an attachment by name.

        Returns:
            True if removed, False if not found.
        """
        if name in self.attachment_instances:
            del self.attachment_instances[name]
            return True
        return False

    def get_attachment(self, name: str) -> Optional[AttachmentInstance]:
        """Get an attachment instance by name."""
        return self.attachment_instances.get(name)

    def set_attachment_pose(self, name: str, pose_name: str) -> None:
        """Set the current pose for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.current_pose = pose_name

    def set_attachment_visible(self, name: str, visible: bool) -> None:
        """Set visibility for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.visible = visible

    def set_attachment_host_joint(self, name: str, host_joint: str) -> None:
        """Change the host joint for an attachment."""
        instance = self.attachment_instances.get(name)
        if instance:
            instance.host_joint = host_joint

    # ── Overlay management ───────────────────────────────────────

    def add_overlay(self, name: str) -> None:
        """Add an overlay by name.

        If the overlay defines a slot, any active overlay occupying the
        same slot is removed first.
        """
        overlay = self.overlays.get(name)
        if overlay and overlay.slot:
            self.active_overlays = [
                n for n in self.active_overlays
                if not (self.overlays.get(n) and self.overlays.get(n).slot == overlay.slot)
            ]
        if name not in self.active_overlays:
            self.active_overlays.append(name)

    def remove_overlay(self, name: str) -> None:
        """Remove an overlay by name. No-op if not active."""
        if name in self.active_overlays:
            self.active_overlays.remove(name)

    def get_overlay_by_slot(self, slot: str) -> Optional[str]:
        """Return the name of the active overlay occupying *slot*, or None."""
        for name in self.active_overlays:
            overlay = self.overlays.get(name)
            if overlay and overlay.slot == slot:
                return name
        return None

    def get_attachment_by_slot(self, slot: str) -> Optional[AttachmentInstance]:
        """Return the attachment instance occupying *slot*, or None."""
        for instance in self.attachment_instances.values():
            if instance.slot == slot:
                return instance
        return None

    # ── Render plan ──────────────────────────────────────────────

    def get_render_items(self, posed_rig: Rig, pose: Optional[Pose] = None,
                         flip_h: bool = False, flip_v: bool = False) -> list:
        """Build a z-sorted render plan for the current state.

        Delegates to :func:`build_render_items` with this state's
        overlays and attachments.
        """
        return build_render_items(
            posed_rig, self.overlays, self.active_overlays,
            self.attachment_instances, pose, flip_h, flip_v)
