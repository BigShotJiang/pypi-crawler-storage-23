"""
Pure-Python PNG parsing utilities.

Provides dimension reading and opaque-pixel bounding box computation
using only stdlib (``struct``, ``zlib``). No Ren'Py or PIL dependency.
"""

from __future__ import annotations

import math
import os
import struct
import zlib
from functools import lru_cache
from typing import Optional, Tuple

from .math2d import Vec2, Transform2D
from .rig import Rig
from .color_utils import compute_anchor_blit


def get_png_dimensions(filepath: str) -> Optional[Tuple[int, int]]:
    """Read width and height from a PNG file's IHDR chunk."""
    try:
        with open(filepath, 'rb') as f:
            header = f.read(24)
        if len(header) < 24 or header[:8] != b'\x89PNG\r\n\x1a\n':
            return None
        w, h = struct.unpack('>II', header[16:24])
        return (w, h)
    except (IOError, OSError):
        return None


def paeth_predictor(a: int, b: int, c: int) -> int:
    """PNG Paeth filter predictor."""
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def unfilter_scanlines(
    raw: bytes, width: int, height: int, bpp: int
) -> list:
    """
    Reverse PNG per-row filtering and return a list of unfiltered row
    bytearrays.

    Supports filter types 0-4 (None, Sub, Up, Average, Paeth).
    Only handles non-interlaced images.
    """
    stride = width * bpp          # bytes per pixel-row (no filter byte)
    rows: list = []
    prev = bytearray(stride)     # "previous row" starts as all zeros
    pos = 0

    for _ in range(height):
        ftype = raw[pos]
        pos += 1
        cur = bytearray(raw[pos:pos + stride])
        pos += stride

        if ftype == 1:            # Sub
            for i in range(bpp, stride):
                cur[i] = (cur[i] + cur[i - bpp]) & 0xFF
        elif ftype == 2:          # Up
            for i in range(stride):
                cur[i] = (cur[i] + prev[i]) & 0xFF
        elif ftype == 3:          # Average
            for i in range(stride):
                a = cur[i - bpp] if i >= bpp else 0
                cur[i] = (cur[i] + (a + prev[i]) // 2) & 0xFF
        elif ftype == 4:          # Paeth
            for i in range(stride):
                a = cur[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                cur[i] = (cur[i] + paeth_predictor(a, b, c)) & 0xFF
        # ftype 0 (None) → cur is already correct

        rows.append(cur)
        prev = cur

    return rows


@lru_cache(maxsize=512)
def get_png_opaque_bbox(filepath: str) -> Optional[Tuple[int, int, int, int]]:
    """
    Return the tight bounding box of non-transparent pixels in a PNG.

    Pure-Python implementation using only ``struct`` and ``zlib`` (stdlib).
    Results are cached because part images don't change at runtime.

    Handles RGBA (color type 6) and Grey+Alpha (color type 4) at 8-bit
    depth.  Images without an alpha channel (types 0, 2, 3) are treated
    as fully opaque.  Interlaced images or unsupported bit depths fall
    back to the full image rectangle.

    Returns:
        (left, top, right, bottom) of opaque content, or ``None`` if the
        image is fully transparent.
    """
    try:
        with open(filepath, 'rb') as f:
            data = f.read()
    except (IOError, OSError):
        return None

    # ── PNG signature ────────────────────────────────────────────
    if len(data) < 29 or data[:8] != b'\x89PNG\r\n\x1a\n':
        return None

    # ── IHDR (must be the first chunk) ───────────────────────────
    ihdr_len = struct.unpack('>I', data[8:12])[0]
    if data[12:16] != b'IHDR' or ihdr_len != 13:
        return None
    ihdr = data[16:29]
    width, height = struct.unpack('>II', ihdr[0:8])
    bit_depth  = ihdr[8]
    color_type = ihdr[9]
    interlace  = ihdr[12]

    # Interlaced PNGs have a different raw-data layout – bail out
    # to the safe "full image" fallback.
    if interlace != 0:
        return (0, 0, width, height)

    # Determine bytes-per-pixel and the offset of the alpha byte
    # within each pixel.
    if color_type == 6 and bit_depth == 8:      # RGBA
        bpp = 4
        alpha_off = 3
    elif color_type == 4 and bit_depth == 8:    # Grey + Alpha
        bpp = 2
        alpha_off = 1
    elif color_type in (0, 2, 3):               # No alpha channel
        return (0, 0, width, height)
    else:
        # 16-bit or unusual combos – fall back to full rect
        return (0, 0, width, height)

    # ── Collect IDAT chunks ──────────────────────────────────────
    idat_parts: list = []
    pos = 8
    while pos + 8 <= len(data):
        clen = struct.unpack('>I', data[pos:pos + 4])[0]
        ctype = data[pos + 4:pos + 8]
        cdata = data[pos + 8:pos + 8 + clen]
        pos += 12 + clen                        # len + type + data + crc
        if ctype == b'IDAT':
            idat_parts.append(cdata)
        elif ctype == b'IEND':
            break
    if not idat_parts:
        return None

    # ── Decompress & unfilter ────────────────────────────────────
    try:
        raw = zlib.decompress(b''.join(idat_parts))
    except zlib.error:
        return None

    rows = unfilter_scanlines(raw, width, height, bpp)

    # ── Scan alpha channel for opaque-pixel bounds ───────────────
    top = -1
    bottom = -1
    left = width
    right = -1

    for y, row in enumerate(rows):
        for x in range(width):
            if row[x * bpp + alpha_off] > 0:
                if top < 0:
                    top = y
                bottom = y
                if x < left:
                    left = x
                if x > right:
                    right = x

    if top < 0:
        return None                              # fully transparent

    return (left, top, right + 1, bottom + 1)


def compute_content_bounds(
    posed_rig: Rig,
    image_base_dir: str
) -> Optional[Tuple[float, float, float, float]]:
    """
    Compute the bounding box of all visible parts' **opaque pixels**.

    For each part image, reads the alpha channel to find the tight rectangle
    of non-transparent pixels, then applies the same scale/rotation/pivot
    math as _blit_rig_item to project that rectangle into world space.

    Args:
        posed_rig: Rig with world positions already computed.
        image_base_dir: Absolute directory containing part images.

    Returns:
        (x, y, w, h) content bounding box clamped to the canvas, or None.
    """
    min_x = float('inf')
    min_y = float('inf')
    max_x = float('-inf')
    max_y = float('-inf')
    has_content = False

    for part in posed_rig.parts.values():
        if not part.visible:
            continue
        xform = posed_rig.get_part_world_transform(part.name)
        if not xform:
            continue

        img_path = os.path.join(image_base_dir, part.image)
        dims = get_png_dimensions(img_path)
        if not dims:
            continue
        full_w, full_h = float(dims[0]), float(dims[1])

        # ── Tight opaque bounds ──────────────────────────────────
        # Use the alpha-channel bbox so transparent padding is excluded.
        # The opaque region becomes the "effective image", and the pivot
        # is shifted so the same world-space alignment is preserved.
        opaque = get_png_opaque_bbox(img_path)
        if opaque is not None:
            ob_l, ob_t, ob_r, ob_b = opaque
            img_w = float(ob_r - ob_l)
            img_h = float(ob_b - ob_t)
            px = xform.pivot.x - ob_l
            py = xform.pivot.y - ob_t
        else:
            # Fully transparent image → nothing to show
            continue

        sx, sy = xform.scale.x, xform.scale.y
        wx, wy = xform.position.x, xform.position.y

        bx, by = compute_anchor_blit(
            img_w, img_h, px, py,
            sx, sy, xform.rotation, wx, wy)

        # Compute rendered AABB size using corner transform
        rad = math.radians(xform.rotation) if xform.rotation else 0
        cos_a, sin_a = math.cos(rad), math.sin(rad)
        corners = [(0, 0), (img_w, 0), (img_w, img_h), (0, img_h)]
        xs = []
        ys = []
        for ccx, ccy in corners:
            scx = px + (ccx - px) * sx
            scy = py + (ccy - py) * sy
            ddx = scx - px
            ddy = scy - py
            xs.append(px + ddx * cos_a - ddy * sin_a)
            ys.append(py + ddx * sin_a + ddy * cos_a)
        render_w = max(xs) - min(xs)
        render_h = max(ys) - min(ys)

        min_x = min(min_x, bx)
        min_y = min(min_y, by)
        max_x = max(max_x, bx + render_w)
        max_y = max(max_y, by + render_h)
        has_content = True

    if has_content and max_x > min_x and max_y > min_y:
        return (min_x, min_y, max_x - min_x, max_y - min_y)
    return None
