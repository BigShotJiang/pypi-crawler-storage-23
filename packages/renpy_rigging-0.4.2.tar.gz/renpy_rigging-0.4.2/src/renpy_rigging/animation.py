"""
Animation playback system.

Animations are sequences of poses with timing information.
The animation system handles playback, looping, and interpolation.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional, Any, Callable

from .math2d import ease_in, ease_out, ease_in_out
from .pose import Pose, PoseLibrary, blend_poses, combine_poses


class PlayMode(Enum):
    """Animation playback modes."""
    ONCE = "once"           # Play once and stop
    LOOP = "loop"           # Loop continuously
    PING_PONG = "ping_pong" # Play forward then backward


class EaseType(Enum):
    """Easing function types for interpolation."""
    LINEAR = "linear"
    EASE_IN = "ease_in"
    EASE_OUT = "ease_out"
    EASE_IN_OUT = "ease_in_out"


@dataclass
class AnimationFrame:
    """
    A single frame in an animation.

    Attributes:
        pose: Name of the pose for this frame
        ms: Duration of this frame in milliseconds
        ease: Easing function for transition TO this frame
        overlays: Per-frame overlay overrides. None = inherit defaults.
            Dict maps overlay name to True (force on) or False (force off).
        attachments: Per-frame attachment overrides. None = inherit defaults.
            Dict maps attachment name to True (force on) or False (force off).
    """

    pose: str
    ms: int = 100
    ease: EaseType = EaseType.LINEAR
    overlays: Optional[Dict[str, bool]] = None
    attachments: Optional[Dict[str, bool]] = None
    sound: Optional[str] = None  # None=inherit from pose, ""=mute, "path"=override
    flip_h: bool = False
    flip_v: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d = {"pose": self.pose, "ms": self.ms}
        if self.ease != EaseType.LINEAR:
            d["ease"] = self.ease.value
        if self.overlays is not None:
            d["overlays"] = self.overlays
        if self.attachments is not None:
            d["attachments"] = self.attachments
        if self.sound is not None:
            d["sound"] = self.sound
        if self.flip_h:
            d["flip_h"] = True
        if self.flip_v:
            d["flip_v"] = True
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AnimationFrame:
        """Create from dictionary."""
        ease = EaseType.LINEAR
        if "ease" in data:
            try:
                ease = EaseType(data["ease"])
            except ValueError:
                pass
        overlays = data.get("overlays")
        attachments = data.get("attachments")
        sound = data.get("sound")
        return cls(
            pose=data.get("pose", "neutral"),
            ms=data.get("ms", 100),
            ease=ease,
            overlays=dict(overlays) if overlays is not None else None,
            attachments=dict(attachments) if attachments is not None else None,
            sound=sound,
            flip_h=data.get("flip_h", False),
            flip_v=data.get("flip_v", False),
        )


@dataclass
class AnimationSound:
    """
    A sound effect on the animation timeline.

    Attributes:
        path: Sound file path (relative to rig directory)
        start_ms: Start time on the animation timeline
        duration_ms: Duration window (sound loops within this window); 0 = play once
    """

    path: str
    start_ms: int = 0
    duration_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d: Dict[str, Any] = {"path": self.path}
        if self.start_ms != 0:
            d["start_ms"] = self.start_ms
        if self.duration_ms != 0:
            d["duration_ms"] = self.duration_ms
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnimationSound":
        """Create from dictionary."""
        return cls(
            path=data["path"],
            start_ms=data.get("start_ms", 0),
            duration_ms=data.get("duration_ms", 0),
        )


@dataclass
class AnimationTrack:
    """
    A single track within an animation, containing a sequence of frames.

    Attributes:
        name: Display name for the track
        frames: List of frames in this track
        weight: Blend weight for compositing (0.0–2.0)
        muted: If True, track is skipped during compositing
    """

    name: str = "Track 1"
    frames: List[AnimationFrame] = field(default_factory=list)
    weight: float = 1.0
    muted: bool = False

    @property
    def total_duration_ms(self) -> int:
        """Total duration of this track in milliseconds."""
        return sum(frame.ms for frame in self.frames)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        d: Dict[str, Any] = {"name": self.name}
        d["frames"] = [frame.to_dict() for frame in self.frames]
        if self.weight != 1.0:
            d["weight"] = self.weight
        if self.muted:
            d["muted"] = True
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnimationTrack":
        """Create from dictionary."""
        frames = [AnimationFrame.from_dict(d) for d in data.get("frames", [])]
        return cls(
            name=data.get("name", "Track 1"),
            frames=frames,
            weight=data.get("weight", 1.0),
            muted=data.get("muted", False),
        )


@dataclass
class Animation:
    """
    A sequence of animation frames, organized into one or more tracks.

    Multi-track animations composite their tracks additively using
    weighted pose blending. Single-track animations behave identically
    to the legacy flat-frames format.

    Attributes:
        name: Unique identifier for this animation
        tracks: List of animation tracks
        mode: Playback mode (once, loop, ping_pong)
        sounds: Animation-level sound timeline
    """

    name: str
    tracks: List[AnimationTrack] = field(default_factory=lambda: [AnimationTrack()])
    mode: PlayMode = PlayMode.LOOP
    sounds: List[AnimationSound] = field(default_factory=list)

    @property
    def frames(self) -> List[AnimationFrame]:
        """Backward-compat accessor: frames from track 0."""
        if self.tracks:
            return self.tracks[0].frames
        return []

    @frames.setter
    def frames(self, value: List[AnimationFrame]) -> None:
        """Backward-compat setter: set frames on track 0."""
        if not self.tracks:
            self.tracks.append(AnimationTrack())
        self.tracks[0].frames = value

    def to_dict(self) -> Any:
        """Serialize to list or dictionary.

        Single default track with no extra settings: old format for zero JSON diff.
        Multi-track or non-default track settings: new tracks format.
        """
        is_single_default = (
            len(self.tracks) == 1
            and self.tracks[0].weight == 1.0
            and not self.tracks[0].muted
            and self.tracks[0].name == "Track 1"
        )

        if is_single_default:
            frames_list = [frame.to_dict() for frame in self.tracks[0].frames]
            if self.sounds:
                return {
                    "frames": frames_list,
                    "sounds": [s.to_dict() for s in self.sounds],
                }
            return frames_list
        else:
            d: Dict[str, Any] = {
                "tracks": [track.to_dict() for track in self.tracks],
            }
            if self.sounds:
                d["sounds"] = [s.to_dict() for s in self.sounds]
            return d

    @classmethod
    def from_dict(cls, name: str, data,
                  mode: PlayMode = PlayMode.LOOP) -> "Animation":
        """Create from dictionary or list (backwards compatible).

        Accepts:
        - A list of frame dicts (oldest format)
        - A dict with "frames" and optional "sounds" keys (single-track format)
        - A dict with "tracks" key (multi-track format)
        """
        if isinstance(data, list):
            # Oldest format: just a list of frames
            track = AnimationTrack(frames=[AnimationFrame.from_dict(d) for d in data])
            return cls(name=name, tracks=[track], mode=mode)
        elif "tracks" in data:
            # Multi-track format
            tracks = [AnimationTrack.from_dict(t) for t in data["tracks"]]
            sounds = [AnimationSound.from_dict(s) for s in data.get("sounds", [])]
            return cls(name=name, tracks=tracks, mode=mode, sounds=sounds)
        else:
            # Single-track dict format with frames and sounds
            frames = [AnimationFrame.from_dict(d) for d in data.get("frames", [])]
            sounds = [AnimationSound.from_dict(s) for s in data.get("sounds", [])]
            track = AnimationTrack(frames=frames)
            return cls(name=name, tracks=[track], mode=mode, sounds=sounds)

    @property
    def total_duration_ms(self) -> int:
        """Total duration of the animation in milliseconds (max across unmuted tracks)."""
        durations = [
            track.total_duration_ms
            for track in self.tracks
            if not track.muted
        ]
        return max(durations) if durations else 0

    @property
    def frame_count(self) -> int:
        """Number of frames in track 0."""
        return len(self.frames)

    def get_frame_at_time(self, time_ms: int) -> tuple[int, float]:
        """
        Get the frame index and blend factor for a given time (track 0).

        Args:
            time_ms: Time in milliseconds from animation start

        Returns:
            Tuple of (frame_index, blend_factor)
            blend_factor is 0.0 at frame start, approaching 1.0 at frame end
        """
        if not self.frames:
            return (0, 0.0)

        total = self.total_duration_ms
        if total == 0:
            return (0, 0.0)

        # Handle looping
        if self.mode == PlayMode.LOOP:
            time_ms = time_ms % total
        elif self.mode == PlayMode.PING_PONG:
            cycle = time_ms // total
            time_ms = time_ms % total
            if cycle % 2 == 1:
                time_ms = total - time_ms
        else:
            # ONCE mode: clamp to end
            time_ms = min(time_ms, total)

        # Find the current frame
        elapsed = 0
        for i, frame in enumerate(self.frames):
            if elapsed + frame.ms > time_ms:
                # This is the current frame
                frame_progress = (time_ms - elapsed) / frame.ms if frame.ms > 0 else 0.0
                return (i, frame_progress)
            elapsed += frame.ms

        # At the end
        return (len(self.frames) - 1, 1.0)

    def get_track_frame_at_time(self, track_index: int, time_ms: int) -> tuple[int, float]:
        """
        Get the frame index and blend factor for a given time on a specific track.

        Args:
            track_index: Index of the track
            time_ms: Time in milliseconds from animation start

        Returns:
            Tuple of (frame_index, blend_factor).
            Returns (-1, 0.0) when the time is past this track's end,
            meaning the track should stop contributing to the composite.
        """
        if track_index < 0 or track_index >= len(self.tracks):
            return (-1, 0.0)

        track = self.tracks[track_index]
        if not track.frames:
            return (-1, 0.0)

        track_total = track.total_duration_ms
        if track_total == 0:
            return (-1, 0.0)

        # Use the animation's total duration for looping (max across tracks)
        total = self.total_duration_ms

        # Handle looping
        if self.mode == PlayMode.LOOP:
            time_ms = time_ms % total if total > 0 else 0
        elif self.mode == PlayMode.PING_PONG:
            if total > 0:
                cycle = time_ms // total
                time_ms = time_ms % total
                if cycle % 2 == 1:
                    time_ms = total - time_ms
        else:
            time_ms = min(time_ms, total)

        # Past this track's end — track stops contributing
        if time_ms >= track_total:
            return (-1, 0.0)

        # Find the current frame within this track
        elapsed = 0
        for i, frame in enumerate(track.frames):
            if elapsed + frame.ms > time_ms:
                frame_progress = (time_ms - elapsed) / frame.ms if frame.ms > 0 else 0.0
                return (i, frame_progress)
            elapsed += frame.ms

        return (-1, 0.0)


@dataclass
class AnimationLibrary:
    """
    A collection of named animations.
    """

    animations: Dict[str, Animation] = field(default_factory=dict)

    def get(self, name: str) -> Optional[Animation]:
        """Get an animation by name."""
        return self.animations.get(name)

    def add(self, animation: Animation) -> None:
        """Add or replace an animation."""
        self.animations[animation.name] = animation

    def remove(self, name: str) -> bool:
        """Remove an animation by name. Returns True if removed."""
        if name in self.animations:
            del self.animations[name]
            return True
        return False

    def list_names(self) -> List[str]:
        """Return a list of all animation names."""
        return list(self.animations.keys())

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {name: anim.to_dict() for name, anim in self.animations.items()}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> AnimationLibrary:
        """Create from dictionary."""
        animations = {}
        for name, anim_data in data.items():
            animations[name] = Animation.from_dict(name, anim_data)
        return cls(animations=animations)


def resolve_frame_toggles(
    defaults: List[str],
    overrides: Optional[Dict[str, bool]]
) -> List[str]:
    """
    Apply per-frame overrides to a default list of active names.

    Args:
        defaults: List of names that are active by default
        overrides: Optional dict mapping name -> True (force on) / False (force off).
            None means inherit entirely from defaults. Absent keys also inherit.

    Returns:
        Resolved list of active names.
    """
    if overrides is None:
        return list(defaults)

    result = set(defaults)
    for name, active in overrides.items():
        if active:
            result.add(name)
        else:
            result.discard(name)
    return list(result)


def _apply_ease(t: float, ease_type: EaseType) -> float:
    """Apply easing function to a 0-1 value."""
    if ease_type == EaseType.LINEAR:
        return t
    elif ease_type == EaseType.EASE_IN:
        return ease_in(t)
    elif ease_type == EaseType.EASE_OUT:
        return ease_out(t)
    elif ease_type == EaseType.EASE_IN_OUT:
        return ease_in_out(t)
    return t


class AnimationPlayer:
    """
    Manages playback of an animation.

    Tracks current time, handles pose interpolation, and provides
    the current pose for rendering.
    """

    def __init__(
        self,
        animation: Animation,
        poses: PoseLibrary,
        interpolate: bool = True
    ):
        """
        Create an animation player.

        Args:
            animation: The animation to play
            poses: The pose library containing referenced poses
            interpolate: Whether to interpolate between poses
        """
        self.animation = animation
        self.poses = poses
        self.interpolate = interpolate

        self._start_time: Optional[float] = None
        self._paused: bool = False
        self._pause_time: float = 0.0
        self._speed: float = 1.0
        self._on_complete: Optional[Callable[[], None]] = None
        self._completed: bool = False

    def start(self) -> None:
        """Start or restart playback from the beginning."""
        self._start_time = time.time()
        self._paused = False
        self._completed = False

    def stop(self) -> None:
        """Stop playback."""
        self._start_time = None
        self._paused = False

    def pause(self) -> None:
        """Pause playback."""
        if not self._paused and self._start_time is not None:
            self._pause_time = time.time()
            self._paused = True

    def resume(self) -> None:
        """Resume playback after pause."""
        if self._paused and self._start_time is not None:
            pause_duration = time.time() - self._pause_time
            self._start_time += pause_duration
            self._paused = False

    def set_speed(self, speed: float) -> None:
        """Set playback speed multiplier."""
        self._speed = max(0.0, speed)

    def on_complete(self, callback: Callable[[], None]) -> None:
        """Set callback to be called when animation completes (ONCE mode only)."""
        self._on_complete = callback

    @property
    def is_playing(self) -> bool:
        """Check if animation is currently playing."""
        return self._start_time is not None and not self._paused

    @property
    def is_paused(self) -> bool:
        """Check if animation is paused."""
        return self._paused

    @property
    def is_complete(self) -> bool:
        """Check if animation has completed (ONCE mode)."""
        return self._completed

    @property
    def elapsed_ms(self) -> int:
        """Get elapsed time in milliseconds."""
        if self._start_time is None:
            return 0
        if self._paused:
            elapsed = self._pause_time - self._start_time
        else:
            elapsed = time.time() - self._start_time
        return int(elapsed * 1000 * self._speed)

    def _get_track_pose(self, track_index: int, elapsed: int) -> Optional[Pose]:
        """Get the interpolated pose for a single track at the given time.

        Returns None when the track has no frames, is muted, or the elapsed
        time is past the track's end (shorter track stops contributing).
        """
        track = self.animation.tracks[track_index]
        if not track.frames or track.muted:
            return None

        frame_idx, blend_factor = self.animation.get_track_frame_at_time(track_index, elapsed)
        if frame_idx < 0:
            return None  # Past this track's end
        current_frame = track.frames[frame_idx]

        current_pose = self.poses.get(current_frame.pose)
        if current_pose is None:
            current_pose = Pose(name=current_frame.pose)

        if not self.interpolate or blend_factor == 0.0:
            return current_pose

        next_idx = (frame_idx + 1) % len(track.frames)
        if self.animation.mode == PlayMode.ONCE and frame_idx == len(track.frames) - 1:
            return current_pose

        next_frame = track.frames[next_idx]
        next_pose = self.poses.get(next_frame.pose)
        if next_pose is None:
            next_pose = Pose(name=next_frame.pose)

        eased_factor = _apply_ease(blend_factor, next_frame.ease)
        return blend_poses(current_pose, next_pose, eased_factor)

    def get_current_pose(self) -> Pose:
        """
        Get the current pose based on elapsed time.

        For multi-track animations, composites all non-muted tracks
        using additive weighted blending.

        Returns:
            The current pose (interpolated if enabled)
        """
        if self._start_time is None or not self.animation.tracks:
            return Pose(name="empty")

        elapsed = self.elapsed_ms

        # Check for completion
        if (self.animation.mode == PlayMode.ONCE and
            elapsed >= self.animation.total_duration_ms and
            not self._completed):
            self._completed = True
            if self._on_complete:
                self._on_complete()

        # Collect poses from all active tracks
        active_tracks = [
            (i, track) for i, track in enumerate(self.animation.tracks)
            if not track.muted and track.frames
        ]

        if not active_tracks:
            return Pose(name="empty")

        # Single-track fast path — identical to legacy behavior
        if len(active_tracks) == 1:
            pose = self._get_track_pose(active_tracks[0][0], elapsed)
            return pose if pose is not None else Pose(name="empty")

        # Multi-track: composite all track poses
        poses = []
        weights = []
        for track_idx, track in active_tracks:
            pose = self._get_track_pose(track_idx, elapsed)
            if pose is not None:
                poses.append(pose)
                weights.append(track.weight)

        if not poses:
            return Pose(name="empty")
        if len(poses) == 1:
            return poses[0]

        return combine_poses(poses, weights, normalize=False)

    def get_current_pose_name(self) -> str:
        """Get the name of the current (non-interpolated) pose."""
        if self._start_time is None or not self.animation.frames:
            return "neutral"
        frame_idx, _ = self.animation.get_frame_at_time(self.elapsed_ms)
        return self.animation.frames[frame_idx].pose

    def get_current_frame(self) -> Optional[AnimationFrame]:
        """Get the current AnimationFrame based on elapsed time."""
        if self._start_time is None or not self.animation.frames:
            return None
        frame_idx, _ = self.animation.get_frame_at_time(self.elapsed_ms)
        return self.animation.frames[frame_idx]

    def seek(self, time_ms: int) -> None:
        """Seek to a specific time in the animation."""
        if self._start_time is None:
            self._start_time = time.time()
        # Adjust start time to make elapsed_ms equal to time_ms
        self._start_time = time.time() - (time_ms / 1000.0 / self._speed)

    def seek_to_frame(self, frame_idx: int) -> None:
        """Seek to a specific frame."""
        if frame_idx < 0 or frame_idx >= len(self.animation.frames):
            return
        time_ms = sum(f.ms for f in self.animation.frames[:frame_idx])
        self.seek(time_ms)
