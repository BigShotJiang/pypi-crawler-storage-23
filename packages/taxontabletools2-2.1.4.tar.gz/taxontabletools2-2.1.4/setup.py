import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="taxontabletools2",
    version="2.1.4",
    author="Till-Hendrik Macher",
    author_email="macher@uni-trier.de",
    description="Taxontabletools2 - A comprehensive, platform-independent graphical user interface software to explore and visualise DNA metabarcoding data",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://pypi.org/project/taxontabletools2",
    packages=setuptools.find_packages(),
    license = 'MIT',
    install_requires=[
        "streamlit>=1.54.0",
        "pandas>=2.4.2",
        "numpy>=2.4.2",
        "plotly>=6.5.2",
        "matplotlib>=3.10.8",
        "matplotlib-venn>=1.1.2",
        "scipy>=1.17.1",
        "biom-format",
        "statsmodels",
        "openpyxl>=3.1.5",
        "psutil>=7.2.2",
        "pymannkendall>=1.4.3",
        "tqdm>=4.67.3",
        "natsort",
        "kaleido>=1.2.0",
        "GitPython>=3.1.46",
    ],
    include_package_data = True,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.12',
    entry_points = {
        "console_scripts" : [
            "taxontabletools2 = taxontabletools2.__main__:main",
        ]
    },
)
