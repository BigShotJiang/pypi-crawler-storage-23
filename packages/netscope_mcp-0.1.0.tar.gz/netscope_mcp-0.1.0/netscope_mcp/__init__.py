"""netscope-mcp: MCP server for the NetScope network scanner."""

__version__ = "0.1.0"
