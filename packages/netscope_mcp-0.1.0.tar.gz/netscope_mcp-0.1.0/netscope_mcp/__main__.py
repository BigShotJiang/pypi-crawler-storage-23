"""Allow running with: python -m netscope_mcp"""

from netscope_mcp.server import main

main()
