"""
MineCode - MCP Server for Minecraft Datapack Development
"""

__version__ = "0.1.0"
__author__ = "Your Name"
