# [Project Name]

*Initialized: [date]*

## What This Is

## Core Value

## Success Criteria

- [ ] 
- [ ] 
- [ ] 

## Context

## Constraints