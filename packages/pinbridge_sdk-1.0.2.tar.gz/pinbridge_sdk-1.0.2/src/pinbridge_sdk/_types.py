"""Shared typing aliases."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any
from uuid import UUID

RequestJson = Mapping[str, Any] | list[Any]
HeadersLike = Mapping[str, str]
PathValue = str | int | UUID
RequestFiles = Mapping[str, Any]
RequestData = Mapping[str, Any]
