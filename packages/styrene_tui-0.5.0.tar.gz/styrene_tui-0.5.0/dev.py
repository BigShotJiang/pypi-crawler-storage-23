"""Development entry point for hot reload with textual run --dev.

This bypasses CLI argument parsing and creates a basic app instance
for rapid iteration during development.
"""

from styrene.app import StyreneApp

# Create app instance with defaults for dev mode
app = StyreneApp()

if __name__ == "__main__":
    app.run()
