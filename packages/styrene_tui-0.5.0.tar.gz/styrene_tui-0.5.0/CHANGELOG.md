# Changelog

All notable changes to styrene (formerly styrene-tui) will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres on [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2026-01-26

### Changed
- **Package renamed** from `styrene-tui` to `styrene`
  - Entry point remains `styrene` (unchanged)
  - Cleaner naming: just "styrene" for the TUI

### Removed
- **Daemon extracted** to separate `styrened` package
  - Daemon code moved to lightweight `styrened` package
  - TUI now focuses purely on interactive use
  - Daemon users should install `styrened` instead

### Added
- Version information in `__init__.py`

## [0.2.0] - 2026-01-26

### Added
- Dependency on **styrene-core>=0.1.0** for headless library functionality
- Re-export layer in `__init__.py` files for backward compatibility
- Comprehensive migration documentation in `MIGRATION.md`
- Three adversarial assessment reports documenting migration process

### Changed
- **BREAKING (internal)**: Migrated core functionality to styrene-core library
  - Models: MeshDevice, Message, RNSErrorState, ReticulumState, wire protocols
  - Protocols: Protocol base, ChatProtocol, StyreneProtocol, ProtocolRegistry
  - Services: RNSService, LXMFService, AutoReplyHandler, NodeStore, HubConnection, CoreLifecycle
- **NOT BREAKING (external)**: Public API maintained through re-exports
- Import paths updated throughout TUI code to use `styrene_core.*` instead of `styrene.*`
- `StyreneLifecycle` refactored to wrap `CoreLifecycle` from styrene-core
- `pyproject.toml` dependencies updated:
  - Removed: rns, lxmf, sqlalchemy, msgpack (now from styrene-core)
  - Added: styrene-core>=0.1.0
  - Kept: textual, psutil (TUI-specific)
- Configuration system split into CoreConfig (in styrene-core) and TUI-specific configs
- Backward compatibility maintained via `@property` decorators on config objects

### Deprecated
- Direct imports of migrated modules (use `styrene_core.*` instead)
  - `from styrene.models.mesh_device` → `from styrene_core.models.mesh_device`
  - `from styrene.protocols.chat` → `from styrene_core.protocols.chat`
  - `from styrene.services.rns_service` → `from styrene_core.services.rns_service`
- Note: Re-exports in `styrene.*` namespaces maintain backward compatibility

### Removed
- ~3,850 lines of duplicate code now in styrene-core:
  - 5 model files
  - 4 protocol files
  - 5 service files

### Fixed
- pyproject.toml dependencies correctly reference styrene-core
- styrene-bond-rpc package imports updated to use styrene_core
- Docstring examples updated with correct import paths
- ReticulumConfig import source corrected in tests

### Security
- No security changes in this release

## Migration Details

This release completes a systematic 10-phase migration to extract reusable components into styrene-core:

**Phase 1-8**: Repository setup, model/protocol/service migration, config splitting, lifecycle separation
**Phase 9**: Import updates and duplicate removal (~60 import statements updated)
**Phase 10**: Documentation and final verification

**Migration Verification**:
- ✅ All integration tests passing (15/15)
- ✅ TUI and daemon import successfully
- ✅ Typecheck passing
- ✅ No duplicate code remains

See `MIGRATION.md` and adversarial assessment reports for complete migration details.

## [0.1.0] - 2025-01-XX

### Added
- Initial monolithic implementation (pre-migration)
- TUI with Textual framework
- LXMF messaging over Reticulum
- Device discovery and management
- RPC server/client for remote device control
- Imperial CRT theme system
- SQLite message/device storage

(Earlier changelog entries not tracked - this version represents the pre-migration baseline)
