# Phase 11: Extract Daemon → styrened

**Goal**: Split daemon functionality into standalone `styrened` package optimized for edge deployments.

## Rationale

1. **Edge Optimization**: Daemon doesn't need textual (5MB+ saved)
2. **Nix Flake**: NixOS deployments want declarative daemon package
3. **Clear Separation**: styrene = interactive, styrened = service
4. **Unix Convention**: Following httpd, sshd, dockerd naming pattern

## Architecture

### Before (Current)
```
styrene-tui/
├── src/styrene/
│   ├── app.py              # TUI
│   ├── daemon.py           # Daemon (pulls in textual!)
│   └── services/
│       └── app_lifecycle   # Imports textual via TUI code
```

### After (Phase 11)
```
styrene/              # TUI only (renamed from styrene-tui)
├── src/styrene/
│   ├── app.py        # TUI
│   └── services/     # TUI services only

styrened/             # NEW - Daemon only
├── src/styrened/
│   ├── daemon.py     # Extracted daemon
│   └── cli.py        # Entry point
├── flake.nix         # Nix flake for NixOS
├── pyproject.toml    # Depends: styrene-core only
└── README.md

styrene-core/         # Unchanged
└── ...
```

## Package Matrix

| Package | Purpose | Dependencies | Distribution |
|---------|---------|--------------|--------------|
| styrene-core | Library | rns, lxmf, sqlalchemy | PyPI |
| styrene | TUI | styrene-core, textual | PyPI |
| styrened | Daemon | styrene-core only | PyPI + Nix |

## Implementation Steps

### Step 1: Create styrened Repository

```bash
cd /Users/cwilson/workspace/vanderlyn/styrene-lab/
mkdir styrened
cd styrened
git init
```

**Structure**:
```
styrened/
├── src/
│   └── styrened/
│       ├── __init__.py
│       ├── daemon.py       # From styrene.daemon
│       └── __main__.py     # Entry point
├── flake.nix               # Nix flake
├── pyproject.toml
├── README.md
├── CHANGELOG.md
└── .gitignore
```

### Step 2: Extract Daemon Code

**Copy from styrene-tui**:
- `src/styrene/daemon.py` → `src/styrened/daemon.py`

**Modify daemon.py**:
- Remove TUI-specific imports
- Use `CoreLifecycle` instead of `StyreneLifecycle`
- Remove hub connection (TUI-specific)
- Keep RPC server functionality

**Before**:
```python
from styrene.services.app_lifecycle import StyreneLifecycle  # Has textual!
```

**After**:
```python
from styrene_core.services.lifecycle import CoreLifecycle  # No textual!
```

### Step 3: Create pyproject.toml

```toml
[project]
name = "styrened"
version = "0.1.0"
description = "Styrene daemon for headless edge deployments"
dependencies = [
    "styrene-core>=0.1.0",  # Only core, no TUI!
]

[project.scripts]
styrened = "styrened.__main__:main"
```

### Step 4: Create Nix Flake

```nix
{
  description = "Styrene daemon for Reticulum mesh networks";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";
  };

  outputs = { self, nixpkgs }: {
    packages.x86_64-linux.default =
      # Python package derivation
      # ...
  };
}
```

### Step 5: Update styrene-tui → styrene

**Rename package**:
- `name = "styrene-tui"` → `name = "styrene"`

**Remove daemon**:
- Delete `src/styrene/daemon.py`

**Update entry points**:
```toml
[project.scripts]
styrene = "styrene.__main__:main"  # TUI only
```

### Step 6: Documentation

**Update all three packages**:
1. styrene-core: Mention both styrene and styrened
2. styrene: Remove daemon docs, link to styrened
3. styrened: Full daemon documentation + Nix usage

## Verification Checklist

- [ ] styrened has zero textual dependency (check with `pip show styrened`)
- [ ] styrened starts and runs RPC server
- [ ] styrene (TUI) starts without daemon code
- [ ] Nix flake builds successfully
- [ ] All three packages have updated documentation
- [ ] No circular dependencies

## Dependency Graph (Final)

```
User Applications
       ↓
   ┌───┴───┐
   ↓       ↓
styrene  styrened
   ↓       ↓
   └───┬───┘
       ↓
  styrene-core
       ↓
   ┌───┴───┐
   ↓       ↓
  RNS     LXMF
```

## Timeline

- Step 1: Repository setup (30 min)
- Step 2: Extract daemon code (1 hour)
- Step 3: pyproject.toml (15 min)
- Step 4: Nix flake (1 hour)
- Step 5: Rename styrene-tui (30 min)
- Step 6: Documentation (1 hour)

**Total**: ~4 hours

## Success Criteria

1. ✅ styrened depends only on styrene-core (no textual)
2. ✅ styrened can be built as Nix flake
3. ✅ styrene (TUI) is clean Python package
4. ✅ All three packages documented
5. ✅ No functionality lost from original styrene-tui

## Next Steps After Phase 11

1. Publish styrened to PyPI
2. Publish Nix flake to Flakehub or GitHub
3. Create NixOS module for systemd service
4. Update styrene-lab organization README

---

**Status**: Ready to execute
**Risk Level**: LOW (clean extraction, no API changes)
