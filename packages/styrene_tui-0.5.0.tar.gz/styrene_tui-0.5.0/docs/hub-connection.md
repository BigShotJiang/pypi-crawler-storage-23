# Styrene Hub Connection

Connect your Styrene TUI to the Styrene Community Hub for fleet coordination over LXMF.

## What is the Styrene Hub?

The Styrene Community Hub is a central coordinator running in your cluster that provides:

- **LXMF Propagation**: Store-and-forward messaging for offline devices
- **Fleet Coordination**: Centralized announce tracking and status updates
- **Device Discovery**: Hub maintains registry of announced devices

**Deployment**: Running in brutus cluster at `192.168.0.102:4242`

## Hub LXMF Address

Current hub address: `1c527ad47a10dc62406bb5d780d289ba`

This is the LXMF destination hash for the propagation node running in the cluster.

- Identity Hash: `559c71c512c7376a5202e4c5b7043113`
- Destination Hash: `1c527ad47a10dc62406bb5d780d289ba` (use this for connection)

## Configuration

### Via Settings Screen

1. Run `styrene`
2. Press `s` for Settings
3. Scroll to "RETICULUM SETTINGS"
4. Change "Hub:" from "None (Disabled)" to "Styrene Community Hub"
5. Press `Ctrl+S` to save

### Via Config File

Edit `~/.styrene/config.yaml`:

```yaml
reticulum:
  hub_enabled: true
  hub_address: "559c71c512c7376a5202e4c5b7043113"
```

### Via CLI (Future)

```bash
styrene --hub styrene
```

## What Happens When Enabled

When you enable the Styrene Hub:

1. **On Startup**: Styrene connects to the hub's LXMF destination
2. **Hub Connection**: Establishes LXMF link with propagation node
3. **Registration**: Announces presence to hub
4. **Coordination**: Hub can relay messages and coordinates fleet

**Current Status**: This is a **Phase 2 feature**. The hub address is configured, but LXMF messaging implementation is pending.

## Verifying Hub Connection

Check logs after enabling:

```bash
cat ~/.styrene/logs/styrene.log | grep -i hub
```

Expected output:
```
INFO - Hub enabled but no address configured
```

Or if address is set:
```
INFO - Connecting to hub at 559c71c512c7376a...
INFO - Connected to hub at 559c71c512c7376a...
```

## Updating Hub Address

If the hub is redeployed or identity changes, get the new address:

```bash
./scripts/get-hub-address.sh
```

Then update `src/styrene/services/hub_connection.py`:

```python
STYRENE_HUB_ADDRESS = "NEW_ADDRESS_HERE"
```

## Hub Architecture

```
┌────────────────────────────────────┐
│  Brutus Cluster (192.168.0.102)   │
│  ┌──────────────────────────────┐ │
│  │  reticulum-hub (namespace)   │ │
│  │  ┌────────────────────────┐  │ │
│  │  │ rnsd (Transport)       │  │ │
│  │  │ - Port: 4242           │  │ │
│  │  │ - LoadBalancer         │  │ │
│  │  └────────────────────────┘  │ │
│  │  ┌────────────────────────┐  │ │
│  │  │ LXMF Propagation Node  │  │ │
│  │  │ - ID: 559c71c512c...   │  │ │
│  │  │ - Name: Styrene...     │  │ │
│  │  └────────────────────────┘  │ │
│  │  ┌────────────────────────┐  │ │
│  │  │ NomadNet               │  │ │
│  │  │ - Community Hub        │  │ │
│  │  └────────────────────────┘  │ │
│  └──────────────────────────────┘ │
└────────────────────────────────────┘
            ↓ LXMF
┌────────────────────────────────────┐
│  Styrene TUI (your device)         │
│  - Connects via LXMF               │
│  - Sends/receives messages         │
│  - Fleet coordination              │
└────────────────────────────────────┘
```

## Hub vs Direct Mesh Discovery

**Without Hub** (current functionality):
- Direct RNS announces
- Peer-to-peer discovery
- No message relay
- Works offline

**With Hub** (Phase 2):
- LXMF messaging
- Central coordination
- Message relay for offline devices
- Fleet-wide commands

Both can work simultaneously—hub connection is **optional enhancement**.

## Troubleshooting

### "Hub enabled but no address configured"

**Cause**: `hub_enabled: true` but `hub_address: null`

**Fix**:
```bash
# In Settings, select "Styrene Community Hub"
# OR edit config:
echo "  hub_address: 559c71c512c7376a5202e4c5b7043113" >> ~/.styrene/config.yaml
```

### "Failed to connect to hub"

**Cause**: Hub not reachable or identity changed

**Fix**:
1. Verify hub is running:
   ```bash
   kubectl --kubeconfig ~/.kube/config-brutus get pods -n reticulum
   ```
2. Check LoadBalancer IP:
   ```bash
   kubectl --kubeconfig ~/.kube/config-brutus get svc -n reticulum
   ```
3. Verify address is current:
   ```bash
   ./scripts/get-hub-address.sh
   ```

### Settings don't persist

**Cause**: Permission issue or config not saved

**Fix**:
```bash
# Check config file exists
cat ~/.styrene/config.yaml | grep hub_

# Verify write permissions
ls -la ~/.styrene/config.yaml
```

## Phase 2 Implementation

When LXMF messaging is implemented:

1. **Message Delivery**: Send commands to devices via hub
2. **Status Updates**: Devices report status to hub
3. **Fleet Commands**: Broadcast commands to all devices
4. **Offline Messaging**: Hub stores messages for offline devices

**Current Phase**: Configuration only, LXMF messaging not yet implemented.

## See Also

- [Configuration Guide](configuration.md) - General config management
- [Deployment Modes](deployment-modes.md) - Mesh deployment options
- Reticulum LXMF docs - Message protocol details
