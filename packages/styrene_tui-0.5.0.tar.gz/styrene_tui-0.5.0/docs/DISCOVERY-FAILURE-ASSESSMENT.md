# Discovery Failure Assessment

**Date:** 2026-01-25
**Issue:** Q502 not discoverable by MacBook TUI despite both configured for hub routing

## Problem Statement

**Q502's TCPClientInterface fails to establish RNS connection to hub, preventing announce propagation.**

## Routing Status

### Working Routes ✅

| Source | Destination | Via | Status | Evidence |
|--------|-------------|-----|--------|----------|
| MacBook | Hub | TCP 192.168.0.102:4242 | **WORKING** | Logs: "Connected to hub at 6fc8bf22aa293588..." |
| MacBook | Global Mesh | Hub relay | **WORKING** | Sees 230+ devices |
| Q502 | Local | AutoInterface | **WORKING** | Logs: "Discovered: [devices]" |

### Broken Routes ❌

| Source | Destination | Via | Status | Root Cause |
|--------|-------------|-----|--------|------------|
| Q502 | Hub | TCP 192.168.0.102:4242 | **BROKEN** | TCPClientInterface not connecting |
| Q502 | MacBook | Hub relay | **BROKEN** | Q502 not connected to hub |
| MacBook | Q502 | Hub relay | **BROKEN** | Q502 announces not propagated |

## Affected Devices

### Q502 (styrene-node.vanderlyn.local)
**Status:** Isolated
**Config:** TCPClientInterface → 192.168.0.102:4242
**Symptoms:**
- TCP connectivity works: `nc -zv 192.168.0.102 4242` succeeds
- RNS not connecting: "Hub destination not in path table. Requesting path..."
- No "Connected to hub" messages in logs
- Announces every 30s but only locally visible
- Discovers other devices via AutoInterface multicast

**Impact:** Cannot communicate with fleet, isolated to local network segment

### MacBook Pro (MacBookPro.vanderlyn.local)
**Status:** Hub-connected
**Config:** TCPClientInterface → 192.168.0.102:4242
**Symptoms:**
- Successfully connects to hub: "Connected to hub at 6fc8bf22aa293588..."
- Sees global mesh (230+ devices)
- Does NOT see Q502 in discovery
- Cannot send messages to Q502 (not in database)

**Impact:** Fleet functionality works for global mesh, but local Q502 device unreachable

### Hub (192.168.0.102:4242)
**Status:** Operational
**Location:** K8s brutus cluster
**External Clients:** 0 (should be 2: Q502 + MacBook)
**Internal Clients:** 3 (K8s pods: lxmd, nomadnet, styrene-daemon)

**Impact:** Functioning correctly but Q502 never establishes connection

## Network Topology

```
┌─────────────────────────────────────────────────────────────┐
│ Local Network (192.168.0.0/24)                              │
│                                                              │
│  ┌──────────────┐          ┌──────────────┐                │
│  │   Q502       │          │  MacBook     │                │
│  │              │          │              │                │
│  │ AutoIface ✅ │          │ AutoIface ✅ │                │
│  │ TCPClient ❌ │          │ TCPClient ✅ │                │
│  └──────┬───────┘          └──────┬───────┘                │
│         │                         │                         │
│         │ TCP fails              │ TCP works               │
│         │ (config exists)        │                         │
│         │                         │                         │
│         └─────────┬───────────────┘                         │
│                   │                                         │
│                   ▼                                         │
│         ┌─────────────────┐                                │
│         │  Hub (K8s)      │                                │
│         │  192.168.0.102  │                                │
│         │  :4242          │                                │
│         │                 │                                │
│         │  External: 0    │  ◄─── PROBLEM                  │
│         │  Expected: 2    │                                │
│         └────────┬────────┘                                │
│                  │                                          │
└──────────────────┼──────────────────────────────────────────┘
                   │
                   ▼
          ┌────────────────┐
          │  Global Mesh   │
          │  (RNS network) │
          │                │
          │  230+ devices  │
          └────────────────┘
```

## Root Cause

**Q502's Reticulum TCPClientInterface fails to initialize connection despite:**
1. Valid configuration (`~/.config/reticulum/config`)
2. Working TCP connectivity (verified with `nc`)
3. Correct target (192.168.0.102:4242)

**Hypothesis:** RNS TCPClientInterface initialization issue on Q502:
- Config may not be loaded by RNS
- Interface may be disabled at RNS level
- RNS may be using different config path
- TCPClientInterface may fail silently during init

## Verification Steps Completed

✅ TCP connectivity: Both devices can reach 192.168.0.102:4242
✅ Hub operational: K8s pod running, accepting connections
✅ Config files: Both have TCPClientInterface configured correctly
✅ Announce format: Both include LXMF destinations
✅ LXMF initialization: Both initialize successfully
❌ RNS interface list: Not yet inspected (need to check what interfaces RNS actually loaded)

## Next Diagnostic Steps

1. **Check RNS interface state on Q502:**
   - What interfaces did RNS actually initialize?
   - Is TCPClientInterface present in RNS.Transport.interfaces?
   - Are there any interface initialization errors?

2. **Compare RNS states:**
   - MacBook: Which interfaces are active?
   - Q502: Which interfaces are active?
   - Why does MacBook succeed but Q502 fails with identical config?

3. **Check Reticulum config loading:**
   - Is RNS using the config at `~/.config/reticulum/config`?
   - Are there any config syntax errors preventing interface load?
   - Does RNS log interface initialization anywhere?

## Impact Assessment

**Severity:** High
**Scope:** Q502 device completely isolated from fleet

**Affected Functionality:**
- ❌ Fleet discovery (Q502 ↔ MacBook)
- ❌ LXMF messaging (Q502 ↔ MacBook)
- ❌ RPC commands (MacBook → Q502)
- ❌ Status monitoring (MacBook viewing Q502 state)
- ✅ Local discovery on Q502 (AutoInterface working)
- ✅ MacBook → Global mesh (hub connection working)

**Workaround:** None. AutoInterface only provides local subnet discovery.

## Test Evidence

```bash
# Q502 - Hub connection fails
$ grep -i hub /tmp/styrene-daemon.log
Hub destination 6fc8bf22aa293588... not in path table. Requesting path...
Failed to connect to hub at 6fc8bf22aa293588...

# MacBook - Hub connection works
$ grep "Connected to hub" /tmp/styrene-tui.log
Connected to hub at 6fc8bf22aa293588... (1 hops)
Connected to hub at 6fc8bf22aa293588...

# Hub - No external clients
$ kubectl -n reticulum logs -l app.kubernetes.io/name=reticulum | grep "TCPServerInterface"
TCPServerInterface[Styrene Backbone/0.0.0.0:4242]
  Status    : Up
  Clients   : 3  # All internal K8s pods, no external clients
```

## Resolution Path

**Goal:** Get Q502's TCPClientInterface to establish RNS connection to hub

**Approach:**
1. Inspect RNS interface initialization on Q502
2. Compare with working MacBook configuration
3. Identify why TCPClientInterface isn't loading/connecting
4. Fix initialization or configuration issue
5. Verify Q502 appears in hub's client list
6. Verify MacBook can discover Q502

**Success Criteria:**
- Q502 logs show: "Connected to hub at 6fc8bf22aa293588..."
- Hub shows 2 external clients
- MacBook test discovers Q502 with LXMF destination
- Message send from MacBook → Q502 succeeds
