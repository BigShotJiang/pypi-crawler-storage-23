# Testing Guide: Deployment Modes & Configuration

Step-by-step guide to test the new deployment modes and configuration persistence.

## Prerequisites

```bash
# Install dependencies
pip install -e ".[api]"  # Includes FastAPI and uvicorn

# Verify installation
python -c "import RNS; import styrene; print('Ready')"
```

## Test 1: Fresh Install - Standalone Mode

**Objective**: Verify default behavior creates config and identity.

```bash
# Clean slate (backup first if you have existing config!)
rm -rf ~/.styrene ~/.config/reticulum ~/.reticulum

# First run
python -m styrene

# Expected behavior:
# - Creates ~/.styrene/
# - Generates operator.key
# - Creates ~/.styrene/config.yaml with defaults
# - Generates ~/.config/reticulum/config (standalone mode)
# - Starts TUI in standalone mode
```

**Verification**:

```bash
# Check Styrene config
cat ~/.styrene/config.yaml | grep "mode:"
# Should show: mode: standalone

# Check identity
ls -lh ~/.styrene/operator.key
# Should show: -rw------- (600 permissions)

# Check RNS config
cat ~/.config/reticulum/config | grep "enable_transport"
# Should show: enable_transport = false

# Check AutoInterface present
cat ~/.config/reticulum/config | grep "AutoInterface"
# Should find: [[AutoInterface]]
```

## Test 2: Hub Mode with CLI Flags

**Objective**: Verify CLI flags are persisted and RNS config regenerates.

```bash
# Clean slate
rm -rf ~/.styrene ~/.config/reticulum

# Run with hub mode
python -m styrene --mode hub --port 4242
```

**Verification**:

```bash
# Check mode persisted
cat ~/.styrene/config.yaml | grep "mode:"
# Should show: mode: hub

# Check server enabled
cat ~/.styrene/config.yaml | grep -A3 "server:"
# Should show:
#   enabled: true
#   port: 4242

# Check RNS transport enabled
cat ~/.config/reticulum/config | grep "enable_transport"
# Should show: enable_transport = true

# Check TCP Server Interface
cat ~/.config/reticulum/config | grep "TCP Server Interface"
# Should find: [[TCP Server Interface]]
```

**Test announce**:

In the TUI, you should see:
- Dashboard loads
- Mesh status panel shows counts
- Identity displayed in Reticulum panel
- No errors in logs

## Test 3: Peer Mode with Multiple Peers

**Objective**: Verify peer connections are saved.

```bash
# Clean slate
rm -rf ~/.styrene ~/.config/reticulum

# Run with peers
python -m styrene --mode peer \
  --peer home.vanderlyn.house:4242 \
  --peer dublin.connect.reticulum.network:4965
```

**Verification**:

```bash
# Check mode
cat ~/.styrene/config.yaml | grep "mode:"
# Should show: mode: peer

# Check peers saved
cat ~/.styrene/config.yaml | grep -A5 "peers:"
# Should show:
#   peers:
#   - host: home.vanderlyn.house
#     port: 4242
#   ...

# Check RNS config has TCPClientInterface
cat ~/.config/reticulum/config | grep "TCPClientInterface"
# Should find multiple entries

# Check target hosts
cat ~/.config/reticulum/config | grep "target_host"
# Should show both peers
```

## Test 4: Headless Mode with API

**Objective**: Verify headless daemon and HTTP API work.

```bash
# Clean slate
rm -rf ~/.styrene ~/.config/reticulum

# Run headless with API
python -m styrene --headless --mode hub --api-port 8000
```

**Expected output**:

```
INFO - Operator identity ready (mode: hub)
INFO - Created Reticulum config: ~/.config/reticulum/config
INFO - RNS service initialized
INFO - Announced as Styrene node: your-hostname
INFO - Starting API on 0.0.0.0:8000
INFO - Styrene daemon running
```

**Test API** (in another terminal):

```bash
# Health check
curl http://localhost:8000/health
# Response: {"status":"ok"}

# Service status
curl http://localhost:8000/api/status
# Response: RNS initialized, transport enabled, etc.

# Configuration
curl http://localhost:8000/api/config
# Response: mode, transport_enabled, interfaces

# Discovered devices (initially empty)
curl http://localhost:8000/api/mesh/devices
# Response: []
```

**Stop daemon**:

```bash
# Press Ctrl+C in headless terminal
# Should see: "Received signal 2, shutting down..."
```

## Test 5: Existing RNS Config (NomadNet Scenario)

**Objective**: Verify Styrene respects existing RNS config.

```bash
# Clean Styrene config only
rm -rf ~/.styrene

# Create mock RNS config (simulating NomadNet)
mkdir -p ~/.config/reticulum
cat > ~/.config/reticulum/config <<'EOF'
[reticulum]
enable_transport = false
share_instance = true

[interfaces]
[[My Custom Interface]]
type = AutoInterface
enabled = true
EOF

# Run Styrene
python -m styrene
```

**Verification**:

```bash
# Check RNS config NOT overwritten
cat ~/.config/reticulum/config | grep "My Custom Interface"
# Should still find it (not regenerated)

# Check Styrene created its own config
cat ~/.styrene/config.yaml
# Should exist with defaults
```

**Logs should show**:
```
INFO - Using existing Reticulum config
```

## Test 6: CLI Override of Existing Config

**Objective**: Verify CLI flags regenerate RNS config.

```bash
# Using setup from Test 5 (existing RNS config)

# Override with CLI flags
python -m styrene --mode hub --port 4242
```

**Expected**:
- RNS config should be OVERWRITTEN
- Custom interface removed
- Hub settings applied

**Verification**:

```bash
# Check RNS config regenerated
cat ~/.config/reticulum/config | grep "My Custom Interface"
# Should NOT find it (overwritten)

cat ~/.config/reticulum/config | grep "enable_transport"
# Should show: enable_transport = true
```

**Warning message** (future enhancement):
```
WARN - Regenerating RNS config (existing config will be overwritten)
```

## Test 7: Config Persistence Across Runs

**Objective**: Verify config persists without CLI flags.

```bash
# Clean slate
rm -rf ~/.styrene ~/.config/reticulum

# First run with flags
python -m styrene --mode hub --port 4242 --peer peer.example.com:4242
# Exit TUI (press 'q')

# Second run without flags
python -m styrene
```

**Expected**:
- Should start in hub mode
- Server on port 4242
- Peer connection configured

**Verification**:

```bash
# Check config still has settings
cat ~/.styrene/config.yaml | grep "mode:"
# Should show: mode: hub

cat ~/.styrene/config.yaml | grep -A2 "peers:"
# Should show peer.example.com
```

**Logs should show**:
```
INFO - Operator identity ready (mode: hub)
INFO - Using existing Reticulum config
```

## Test 8: Two Styrene Instances (Hub + Peer)

**Objective**: Verify two instances can discover each other.

### Terminal 1: Hub

```bash
python -m styrene --mode hub --port 4242
```

### Terminal 2: Peer

```bash
# Different config directory (to simulate separate device)
export STYRENE_CONFIG=~/.styrene-peer  # (future feature)

# Or manually use different identity
python -m styrene --mode peer --peer localhost:4242
```

**Expected**:
- Hub accepts connection from peer
- Both show each other in mesh device table (after announce interval)

**Verification** (in Hub terminal):
- Check "MESH DEVICES" table
- Should see peer device appear after ~5 minutes (announce interval)

## Test 9: Configuration Validation

**Objective**: Verify invalid config is caught.

```bash
# Create invalid config
cat > ~/.styrene/config.yaml <<'EOF'
reticulum:
  mode: invalid_mode
  interfaces:
    server:
      port: 99999  # Invalid port
EOF

# Run Styrene
python -m styrene
```

**Expected**:
- Warning about config validation
- Falls back to defaults
- Doesn't crash

**Logs should show**:
```
WARNING - Config validation failed: ...
INFO - Using default configuration
```

## Test 10: Unit Tests

**Objective**: Verify all automated tests pass.

```bash
# Run all config tests
pytest tests/services/test_config_persistence.py -v

# Expected output:
# test_save_and_load_config PASSED
# test_cli_overrides_persist PASSED
# test_rns_config_generation PASSED
# test_config_defaults PASSED
# test_auto_enable_server_in_hub_mode PASSED

# Run all tests
pytest -v
```

## Troubleshooting Tests

### Test fails: "RNS library not available"

```bash
pip install rns
```

### Test fails: "Permission denied" on ~/.styrene/

```bash
chmod 700 ~/.styrene
```

### Test fails: RNS initialization error

Check logs:

```bash
cat ~/.styrene/logs/styrene.log
```

Common issues:
- Port already in use (change `--port`)
- RNS config syntax error (regenerate with `rm ~/.config/reticulum/config`)

### API tests fail: "Connection refused"

```bash
# Check API enabled
cat ~/.styrene/config.yaml | grep -A2 "api:"

# Should show:
#   enabled: true
#   port: 8000

# Check nothing else on port 8000
lsof -i :8000
```

## Success Criteria

All tests should:

✅ Create config directory on first run
✅ Generate operator identity (600 permissions)
✅ Persist CLI flags to config file
✅ Generate RNS config if missing
✅ Respect existing RNS config (unless CLI override)
✅ Start in correct deployment mode
✅ Enable appropriate interfaces
✅ Run headless daemon without errors
✅ Serve HTTP API responses
✅ Discover other devices (after announce interval)
✅ Pass all unit tests

## Next Steps

After verifying tests:

1. **Deploy to real devices**: Test on RPi, laptop, server
2. **Test announce discovery**: Run two devices, verify they see each other
3. **Test NomadNet coexistence**: Run both Styrene and NomadNet
4. **Performance test**: 10+ devices announcing
5. **Long-running stability**: Leave hub running for 24h

## Cleanup

Remove test configs:

```bash
# Backup if needed
mv ~/.styrene ~/.styrene.backup
mv ~/.config/reticulum ~/.config/reticulum.backup

# Or delete
rm -rf ~/.styrene ~/.config/reticulum
```
