"""Data models for Styrene TUI.

This package contains dataclasses representing the various data
structures used throughout the application.
"""

from styrene.models.config import (
    AdvancedConfig,
    ConfigLoadError,
    ConfigValidationError,
    ConfigValidationErrors,
    FleetConfig,
    GatewayMode,
    LogLevel,
    MeshDefaults,
    ProvisioningDefaults,
    ReticulumConfig,
    StyreneConfig,
    ThemeMode,
    TUIConfig,
)
from styrene.models.device_hardware import Hardware
from styrene.models.fleet import Device, DeviceStatus
from styrene.models.hardware import (
    DiskInfo,
    DiskType,
    InterfaceCategory,
    NetworkInterface,
    NetworkInterfaceType,
    SystemInfo,
)
# Re-export from styrene-core (duplicates migrated)
from styrened.models.messages import Base, Message, get_session, init_db
from styrened.models.reticulum import (
    ReticulumIdentity,
    ReticulumInterface,
    ReticulumNotConfiguredError,
    ReticulumState as ReticulumStateConfig,
)

from styrene.models.profiles import Profile
from styrene.models.roles import Role
from styrened.rpc.messages import (
    ExecCommand,
    ExecResult,
    StatusRequest,
    StatusResponse,
)

__all__ = [
    "AdvancedConfig",
    "Base",
    "ConfigLoadError",
    "ConfigValidationError",
    "ConfigValidationErrors",
    "Device",
    "DeviceStatus",
    "DiskInfo",
    "DiskType",
    "ExecCommand",
    "ExecResult",
    "FleetConfig",
    "GatewayMode",
    "Hardware",
    "InterfaceCategory",
    "LogLevel",
    "MeshDefaults",
    "Message",
    "NetworkInterface",
    "NetworkInterfaceType",
    "Profile",
    "ProvisioningDefaults",
    "ReticulumConfig",
    "ReticulumIdentity",
    "ReticulumInterface",
    "ReticulumNotConfiguredError",
    "ReticulumStateConfig",
    "Role",
    "StatusRequest",
    "StatusResponse",
    "StyreneConfig",
    "SystemInfo",
    "TUIConfig",
    "ThemeMode",
    "get_session",
    "init_db",
]
