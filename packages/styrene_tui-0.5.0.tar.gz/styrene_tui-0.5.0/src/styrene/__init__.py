"""Styrene - Terminal UI for Reticulum mesh network management.

Built on styrene-core for headless library functionality.
For headless daemon, see styrened package.
"""

__version__ = "0.5.0"
