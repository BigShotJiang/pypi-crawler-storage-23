"""Styrene TUI widgets.

Custom Textual widgets for the fleet management interface.
"""

from styrene.widgets.hardware_panel import HardwarePanel
from styrene.widgets.reticulum_panel import ReticulumPanel

__all__ = [
    "HardwarePanel",
    "ReticulumPanel",
]
