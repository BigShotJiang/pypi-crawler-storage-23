# Directive Priority Hierarchy

## 1. System Instructions
**Source**: Claude Code base functionality (built-in)
- Tool usage policies
- Security constraints
- Core behavioral patterns
- Professional objectivity standards

## 2. Global User Directives
**Source**: `~/.claude/CLAUDE.md`
- Iterative development (baselines first, no anticipation)
- Test-Driven Development (tests before implementation)
- Direct communication (no preambles, concise responses)
- Assessment: See → Name → Code → Measure
- No AI attribution in commits (critical)

## 3. Repository Immutable Guardrails
**Source**: `/Users/cwilson/workspace/vanderlyn/CLAUDE.md`
- Docker stack management (komodo-cli only, never direct docker compose)
- DNS/DHCP via technitium-operations skill only
- Hardware services on physical hosts (never K8s)
- **Secrets handling (CRITICAL)**: Never output/commit/display secrets
- No AI attribution in commits
- Research docs before claiming version-specific knowledge

## 4. Project-Specific Guidance
**Source**: `/Users/cwilson/workspace/vanderlyn/styrene-lab/styrene-tui/CLAUDE.md`
- Makefile as operational source of truth
- Test-first development workflow
- RNS singleton test patterns
- Theming system (phosphex-derived colors)
- tmux visual testing harness

## 5. Skill-Specific Context
**Source**: `.claude/skills/*/SKILL.md` (when invoked)
- Domain-specific procedures
- Context-sensitive guidance

**Override Rule**: Higher levels cannot be overridden by lower levels. Immutable guardrails apply everywhere regardless of subdirectory context.
