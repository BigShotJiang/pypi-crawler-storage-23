#!/usr/bin/env bash
# Validation script for styrene-tui development
# Run before committing changes

set -e

cd "$(dirname "$0")/.."

echo "=== Ruff (lint) ==="
source .venv/bin/activate
ruff check .

echo ""
echo "=== Ruff (format check) ==="
ruff format --check .

echo ""
echo "=== Mypy (types) ==="
mypy src/

echo ""
echo "=== Pytest ==="
pytest -v

echo ""
echo "=== All checks passed ==="
