#!/bin/bash
# Get Styrene Community Hub LXMF address from brutus cluster

set -e

echo "Retrieving LXMF address from Styrene Community Hub..."
echo

# Get pod name
POD=$(kubectl --kubeconfig ~/.kube/config-brutus get pods -n reticulum -o jsonpath='{.items[0].metadata.name}')

if [ -z "$POD" ]; then
    echo "Error: Could not find reticulum-hub pod"
    exit 1
fi

echo "Pod: $POD"
echo

# Get LXMF identity hash and destination hash
echo "Getting hub addresses..."
kubectl --kubeconfig ~/.kube/config-brutus exec -n reticulum "$POD" -- \
    python3 << 'PYEOF'
import RNS

# Initialize RNS (required for destination creation)
RNS.Reticulum()

# Load identity
identity = RNS.Identity.from_file('/app/.lxmf/identity')

# Create LXMF delivery destination
destination = RNS.Destination(
    identity,
    RNS.Destination.IN,
    RNS.Destination.SINGLE,
    "lxmf",
    "delivery"
)

print(f"Identity Hash:    {identity.hash.hex()}")
print(f"Destination Hash: {destination.hash.hex()}")
PYEOF

echo
echo "Update src/styrene/services/hub_connection.py with the DESTINATION hash:"
echo "STYRENE_HUB_ADDRESS = \"<destination-hash-from-above>\""
