#!/bin/bash
# Recreate venv with Python 3.11 baseline
set -e

echo "=== Python 3.11 Baseline Migration ==="
echo

# Check Python 3.11 is available
if ! command -v python3.11 &> /dev/null; then
    echo "❌ Python 3.11 not found"
    echo "Install with: brew install python@3.11"
    exit 1
fi

echo "✓ Python 3.11 found: $(python3.11 --version)"
echo

# Backup current venv if it exists
if [ -d ".venv" ]; then
    echo "Backing up existing venv..."
    mv .venv .venv.bak.$(date +%Y%m%d_%H%M%S)
    echo "✓ Backup created"
    echo
fi

# Create new venv with Python 3.11
echo "Creating new venv with Python 3.11..."
python3.11 -m venv .venv
echo "✓ venv created"
echo

# Activate and install
echo "Installing dependencies..."
source .venv/bin/activate
pip install --upgrade pip
pip install -e ".[dev]"
echo "✓ Dependencies installed"
echo

# Verify
echo "=== Verification ==="
echo "Python version: $(.venv/bin/python --version)"
echo "RNS version: $(.venv/bin/python -c 'import RNS; print(RNS.__version__)')"
echo "LXMF version: $(.venv/bin/python -c 'import LXMF; print(LXMF.__version__)')"
echo

echo "✅ Migration complete"
echo
echo "Next steps:"
echo "  1. source .venv/bin/activate"
echo "  2. Test hub connection: make run"
echo "  3. Compare with Q502 behavior"
