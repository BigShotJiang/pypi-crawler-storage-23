# Styrene Bond RPC

RPC server for Styrene Bond device management over LXMF.

## Features

- Protocol abstraction for RPC message routing
- Command handler registration
- Authorization service
- Systemd integration for NixOS

## License

MIT
