"""Styrene Bond RPC - Device management server over LXMF."""

from styrene_bond_rpc.server import RPCServer
from styrene_bond_rpc.handlers import (
    handle_status,
    handle_exec,
    handle_reboot,
    handle_update_config,
)
from styrene_bond_rpc.auth import AuthorizationService

__all__ = [
    "RPCServer",
    "AuthorizationService",
    "handle_status",
    "handle_exec",
    "handle_reboot",
    "handle_update_config",
]
__version__ = "0.1.0"
