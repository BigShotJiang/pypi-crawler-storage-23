# CLI Tools Reference

Quick reference for testing Styrene functionality without the TUI.

## Installation

```bash
# Install styrene in development mode
pip install -e .

# Or with dev dependencies
pip install -e ".[dev]"
```

## Available Commands

### Reticulum

```bash
# Status
python -m styrene.cli.reticulum_cli status

# Initialize
python -m styrene.cli.reticulum_cli init

# Device discovery
python -m styrene.cli.reticulum_cli discover

# Hub connection
python -m styrene.cli.reticulum_cli hub-connect <address>

# Verbose mode
python -m styrene.cli.reticulum_cli -v status
```

### Fleet Management

```bash
# List devices
python -m styrene.cli.fleet_cli list

# Show summary
python -m styrene.cli.fleet_cli summary

# Device details
python -m styrene.cli.fleet_cli device <name>
```

### Hardware Detection

```bash
# System info
python -m styrene.cli.hardware_cli system

# Disk info
python -m styrene.cli.hardware_cli disks

# Network info
python -m styrene.cli.hardware_cli network

# All hardware
python -m styrene.cli.hardware_cli all
```

## Examples

### Check if RNS is running

```bash
$ python -m styrene.cli.reticulum_cli status
=== Reticulum Service Status ===
RNS Initialized: True
Operator Identity: 50260be4428db7af
Transport Enabled: False
Interface Count: 2

Hub Connected: False
```

### Monitor fleet status

```bash
$ python -m styrene.cli.fleet_cli summary
=== Fleet Summary ===

  Online:    3
  Offline:   1
  Pending:   1
  Error:     0
  ───────────────
  Total:     5
```

### Check available removable storage

```bash
$ python -m styrene.cli.hardware_cli disks | grep -A20 REMOVABLE
REMOVABLE DISKS:
  disk4           7.5 GB (/Volumes/USB)
```

### Discover Styrene devices on mesh

```bash
$ python -m styrene.cli.reticulum_cli discover
Initializing services...
✓ Services initialized

Starting device discovery...
Listening for announces (Ctrl+C to stop)...

✓ STYRENE | rpi-01               | a1b2c3d4e5f6... | announces: 1
✓ STYRENE | rpi-02               | f6e5d4c3b2a1... | announces: 1
  OTHER   | unknown-device       | 1234567890ab... | announces: 1

--- Summary: 3 total, 2 styrene ---
```

## Scripting

Use in shell scripts:

```bash
#!/bin/bash
# Check if any devices are offline

summary=$(python -m styrene.cli.fleet_cli summary)
offline=$(echo "$summary" | grep Offline | awk '{print $2}')

if [ "$offline" -gt 0 ]; then
    echo "ALERT: $offline devices offline"
    python -m styrene.cli.fleet_cli list | grep OFFLINE
    exit 1
fi

echo "All devices online"
exit 0
```

## Python Integration

Run from Python scripts:

```python
from styrene.cli.reticulum_cli import cmd_status
import argparse

# Create minimal args object
args = argparse.Namespace(verbose=False)

# Run command
exit_code = cmd_status(args)

if exit_code == 0:
    print("Status check passed")
```

Or use the services directly (recommended):

```python
from styrene.services.app_lifecycle import initialize_styrene, get_service_status

# Initialize
lifecycle = initialize_styrene()

# Check status
status = get_service_status()
print(f"RNS: {status['rns_initialized']}")

# Cleanup
lifecycle.shutdown()
```

## See Also

- [Standalone Usage Guide](docs/standalone-usage.md) - Full Python API documentation
- [Example Script](examples/standalone_example.py) - Working example
- [Service Tests](tests/services/) - Test patterns
