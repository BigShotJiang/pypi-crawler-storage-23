"""The 'Parry' logic - Security scanning engine"""
