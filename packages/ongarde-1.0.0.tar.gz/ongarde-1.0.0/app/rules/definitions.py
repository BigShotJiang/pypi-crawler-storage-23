"""Blocked commands & regex definitions"""
