"""Security rules and scanning module"""
