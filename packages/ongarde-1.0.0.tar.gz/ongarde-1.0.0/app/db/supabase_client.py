"""Supabase client configuration and connections"""
