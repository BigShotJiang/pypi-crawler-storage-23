"""Proxy module for request/response handling"""
