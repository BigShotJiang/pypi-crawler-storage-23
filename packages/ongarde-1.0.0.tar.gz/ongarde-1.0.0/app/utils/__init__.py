"""OnGarde utility modules."""
