## Harvard Cortical Atlas

### Source
HarvardOxford-cort-maxprob-thr25-1mm.nii.gz from fsl v6074


### Processing

The file HarvardOxford-Cortical.xml was editted to create HarvardOxford-Cortical_index.txt with just the roi labels