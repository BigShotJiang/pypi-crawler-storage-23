## JHU Labels and Tracts

### Source
JHU-ICBM-labels-1mm.nii.gz and JHU-ICBM-tracts-maxprob-thr25-1mm.nii.gz from fsl v6074


### Processing

The file JHU-labels.xml was edited to create JHU-labels_index.txt with just the roi labels

The file JHU-tracts.xml was edited to create JHU-tracts_index.txt with just the roi labels