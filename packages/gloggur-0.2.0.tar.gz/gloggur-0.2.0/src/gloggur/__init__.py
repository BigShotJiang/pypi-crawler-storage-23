"""Gloggur: symbol-level codebase indexer for semantic search."""

__all__ = ["__version__"]

__version__ = "0.2.0"
