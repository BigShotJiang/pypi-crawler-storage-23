from __future__ import annotations

from gloggur.cli.main import cli


def main() -> None:
    """Run the gloggur CLI entrypoint."""
    cli()


if __name__ == "__main__":
    main()
