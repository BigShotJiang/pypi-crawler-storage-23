"""Fix platform server.

App factory for the centralized fix platform.
"""

from server.app import create_app

__all__ = ["create_app"]
