To use this module, you need to:

1.  Go to Partner
2.  Click *Bank Account(s)* in "Invoicing" page.
3.  Create/modify IBAN bank account.
4.  When you put the bank account number, module extracts bank digits
    from the format of the country, and try to match an existing bank by
    country and code.
5.  If there's a match, the bank is selected automatically.
