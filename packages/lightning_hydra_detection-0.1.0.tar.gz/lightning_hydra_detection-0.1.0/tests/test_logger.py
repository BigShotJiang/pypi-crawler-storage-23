from pathlib import Path

from aim.pytorch_lightning import AimLogger
from hydra.core.hydra_config import HydraConfig
from lightning.pytorch.loggers.csv_logs import CSVLogger
from lightning.pytorch.loggers.mlflow import MLFlowLogger
from lightning.pytorch.loggers.tensorboard import TensorBoardLogger
from omegaconf import DictConfig

from lightning_hydra_detection.train import train
from tests.helpers.run_if import run_if


def test_aim(tmp_path: Path, cfg_aim: DictConfig):
    """Run 3 epochs test with aim logger.

    It checks if the aim tree structure is created in tmp_path and assumes aim writes correctly
    metrics during training after that.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_aim (DictConfig): A DictConfig containing a valid training configuration using
    aim logger.
    """
    HydraConfig().set_config(cfg_aim)
    _, obj_dict = train(cfg_aim)

    # Check object created
    assert isinstance(obj_dict["logger"], list)
    assert len(obj_dict["logger"]) == 1
    assert isinstance(obj_dict["logger"][0], AimLogger)

    # Check if aim directory exists
    aim_path: Path = tmp_path / ".aim"
    assert aim_path.is_dir()

    # Check subfolders has been created
    assert (aim_path / "check_ins").is_dir()
    assert (aim_path / "locks").is_dir()
    assert (aim_path / "meta").is_dir()
    assert (aim_path / "run_metadata.sqlite").exists()
    assert (aim_path / "seqs").is_dir()
    assert (aim_path / "VERSION").exists()


def test_csv(tmp_path: Path, cfg_csv: DictConfig):
    """Run 3 epochs test with csv logger.

    It checks if the csv tree structure is created in tmp_path and assumes csv writes correctly
    metrics during training after that.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_csv (DictConfig): A DictConfig containing a valid training configuration using
    csv logger.
    """
    HydraConfig().set_config(cfg_csv)
    _, obj_dict = train(cfg_csv)

    # Check object created
    assert isinstance(obj_dict["logger"], list)
    assert len(obj_dict["logger"]) == 1
    assert isinstance(obj_dict["logger"][0], CSVLogger)

    # Check if csv files are created and logged
    csv_path: Path = tmp_path / "csv"
    assert csv_path.is_dir()

    # Check subfolder has been created by default "version_0"
    for folder in csv_path.iterdir():
        assert folder.is_dir()
        assert (csv_path / folder / "hparams.yaml").exists()
        assert (csv_path / folder / "metrics.csv").exists()


@run_if(tensorboard=True)
def test_tensorboard(tmp_path: Path, cfg_tensorboard: DictConfig):
    """Run 3 epochs test with tensorboard logger.

    It checks if the tensorboard tree is created in tmp_path and assumes tensorboard writes
    correctly metrics during training after that.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_tensorboard (DictConfig): A DictConfig containing a valid training configuration
        using tensorboard logger.
    """
    HydraConfig().set_config(cfg_tensorboard)
    _, obj_dict = train(cfg_tensorboard)

    # Check object created
    assert isinstance(obj_dict["logger"], list)
    assert len(obj_dict["logger"]) == 1
    assert isinstance(obj_dict["logger"][0], TensorBoardLogger)

    # Check if tensorboard files are created and logged
    tensorboard_path: Path = tmp_path / "tensorboard"
    assert tensorboard_path.is_dir()

    # Check subfolder has been created by default "version_0"
    for folder in tensorboard_path.iterdir():
        assert folder.is_dir()
        for file in folder.iterdir():
            assert (
                file.name == "hparams.yaml"
                or file.name.startswith("events.out.tfevents.")
                or file.name == "checkpoints"
            )


@run_if(mlflow=True)
def test_mlflow(tmp_path: Path, cfg_mlflow: DictConfig):
    """Run 3 epochs test with mlflow logger.

    It checks if the mlflow tree structure is created in tmp_path and assumes mlflow writes
    correctly metrics during training after that.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_mlflow (DictConfig): A DictConfig containing a valid training configuration using
        mlflow logger.
    """
    HydraConfig().set_config(cfg_mlflow)
    _, obj_dict = train(cfg_mlflow)

    # Check object created
    assert isinstance(obj_dict["logger"], list)
    assert len(obj_dict["logger"]) == 1
    assert isinstance(obj_dict["logger"][0], MLFlowLogger)

    mlflow_path: Path = tmp_path / "mlflow" / "mlruns"
    assert mlflow_path.is_dir()

    experiment_id = obj_dict["logger"][0].experiment_id
    run_id = obj_dict["logger"][0].run_id

    run_path: Path = mlflow_path / experiment_id / run_id
    assert run_path.is_dir()

    assert (run_path / "artifacts").is_dir()
    assert (run_path / "metrics").is_dir()
    assert (run_path / "params").is_dir()
    assert (run_path / "tags").is_dir()
    assert (run_path / "meta.yaml").exists()

    for f in (run_path / "metrics").iterdir():
        assert f.name in ("test", "train", "val", "epoch", "lr")
