import pytest
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig

from lightning_hydra_detection.eval import evaluate
from tests.conftest import ALL_MODELS


@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_eval_fast(cfg_eval_fast: DictConfig, model: str) -> None:
    """Method to test evaluation.

    Tests evaluation script `eval.py`.

    Args:
        cfg_eval_fast (DictConfig): A DictConfig containing a valid evaluation configuration.
        model (str): The name of the model.
    """
    HydraConfig().set_config(cfg_eval_fast)
    test_metric_dict, _ = evaluate(cfg_eval_fast)

    assert not test_metric_dict or test_metric_dict["test/acc"] >= 0.0


@pytest.mark.slow
@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_eval(cfg_eval: DictConfig, model: str) -> None:
    """Method to test evaluation.

    Tests evaluation script `eval.py`.

    Args:
        cfg_eval (DictConfig): A DictConfig containing a valid evaluation configuration.
        model (str): The name of the model.
    """
    HydraConfig().set_config(cfg_eval)
    test_metric_dict, _ = evaluate(cfg_eval)

    assert not test_metric_dict or test_metric_dict["test/acc"] >= 0.0
