from importlib.abc import Traversable

import pytest
import torchvision.transforms.v2 as transforms
from pytorch_lightning.trainer.states import TrainerFn
from torch import Tensor, float32, int64
from torchvision import tv_tensors

from lightning_hydra_detection.data.coco_datamodule import COCODataModule
from lightning_hydra_detection.utils.torchvision_target_format import (
    EnsureValidTVTensors,
)


@pytest.mark.parametrize("batch_size", [1, 3])
def test_EnsureValidTVTensors(data_dir: Traversable, batch_size: int) -> None:
    """Tests EnsureValidTVTensors to check the types of the transformations outputs.

    Args:
        data_dir (Traversable):  A Traversable representing the test data directory.
        batch_size (int): Batch size of the data to be loaded by the dataloader.
    """
    # Setup
    dm = COCODataModule(
        data_dir=str(data_dir),
        batch_size=batch_size,
    )
    # Change path for tests/resources/COCO
    dm.train_transforms = transforms.Compose(
        [
            transforms.ToImage(),
            EnsureValidTVTensors(),
        ]
    )

    # `prepare_data()` is done with `fetch_coco_samples`
    dm.setup(TrainerFn.FITTING)
    coco_dataloader = dm.train_dataloader()

    for transformed_img, transformed_labels in iter(coco_dataloader):
        assert len(transformed_img) <= batch_size  # collate_fn
        assert len(transformed_labels) == len(transformed_img)

        for i in range(len(transformed_img)):
            # Test types
            assert isinstance(transformed_img[i], tv_tensors.Image)
            assert isinstance(transformed_labels[i], dict)

            assert isinstance(transformed_labels[i]["labels"], Tensor)
            assert isinstance(transformed_labels[i]["boxes"], tv_tensors.BoundingBoxes)

            assert transformed_labels[i]["labels"].dtype == int64
            assert transformed_labels[i]["boxes"].dtype == float32

            # Test shapes
            assert transformed_img[i].shape[1:] == transformed_labels[i]["boxes"].canvas_size
            assert transformed_labels[i]["boxes"].shape == (
                transformed_labels[i]["labels"].shape[0],
                4,
            )
