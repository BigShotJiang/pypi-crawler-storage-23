import json
from importlib.abc import Traversable
from pathlib import Path

import pytest
from lightning import seed_everything
from pytorch_lightning.trainer.states import TrainerFn
from torch import Tensor, float32, int64
from torchvision.datasets import CocoDetection

from lightning_hydra_detection.data.coco_datamodule import COCODataModule
from lightning_hydra_detection.data.components.unlabeled_image_folder import (
    ImageMeta,
    UnlabeledImageFolder,
)
from lightning_hydra_detection.data.mnist_datamodule import MNISTDataModule


@pytest.mark.parametrize("batch_size", [32, 128])
def test_mnist_datamodule(data_dir, batch_size: int) -> None:
    """Tests `MNISTDataModule`.

    Tests `MNISTDataModule` to verify that it can be downloaded correctly, that the necessary
    attributes were created (e.g., the dataloader objects), and that dtypes and batch sizes
    correctly match.

    Args:
        data_dir (Traversable): A Traversable representing the test data directory.
        batch_size (int): Batch size of the data to be loaded by the dataloader.
    """
    dm = MNISTDataModule(data_dir=str(data_dir), batch_size=batch_size)
    dm.prepare_data()

    assert not dm.data_train and not dm.data_val and not dm.data_test
    assert Path(data_dir, "MNIST").exists()
    assert Path(data_dir, "MNIST", "raw").exists()

    dm.setup()
    assert dm.data_train and dm.data_val and dm.data_test
    assert dm.train_dataloader() and dm.val_dataloader() and dm.test_dataloader()

    num_datapoints = len(dm.data_train) + len(dm.data_val) + len(dm.data_test)
    assert num_datapoints == 70_000

    batch = next(iter(dm.train_dataloader()))
    x, y = batch
    assert len(x) == batch_size
    assert len(y) == batch_size
    assert x.dtype == float32
    assert y.dtype == int64


@pytest.mark.parametrize("batch_size", [32, 128])
def test_coco_datamodule(data_dir, batch_size: int) -> None:
    """Tests `COCODataModule`.

    Tests `COCODataModule` to verify that the necessary attributes were created (e.g., the
    dataloader objects), and that dtypes and batch sizes correctly match.

    Args:
        data_dir (Traversable): A Traversable representing the test data directory.
        batch_size (int): Batch size of the data to be loaded by the dataloader.
    """
    seed_everything(4, workers=True)

    dm = COCODataModule(data_dir=str(data_dir), batch_size=batch_size)

    assert not any([dm.data_train, dm.data_val, dm.data_test, dm.data_predict])
    assert Path(data_dir, "COCO").exists()

    # train dataloader
    dm.setup(stage=TrainerFn.FITTING)
    assert dm.data_train
    assert dm.train_dataloader()

    batch = next(iter(dm.train_dataloader()))
    x, y = batch
    assert len(x) <= batch_size  # collate_fn
    assert len(y) == len(x)
    assert x[0].dtype == float32
    assert y[0]["boxes"].dtype == float32
    assert y[0]["labels"].dtype == int64
    # for i, item in enumerate(dm.train_dataloader()):
    #     print(f"{i}/{len(dm.train_dataloader())}")

    # valid dataloader
    dm.setup(stage=TrainerFn.VALIDATING)
    assert dm.data_val
    assert dm.val_dataloader()

    batch = next(iter(dm.val_dataloader()))
    x, y = batch

    assert len(x) <= batch_size  # collate_fn
    assert x[0].dtype == float32
    assert y[0]["boxes"].dtype == float32
    assert y[0]["labels"].dtype == int64
    # for i, item in enumerate(dm.val_dataloader()):
    #     print(f"{i}/{len(dm.val_dataloader())}")

    # test dataloader with unlabeled images
    dm.setup(stage=TrainerFn.TESTING)
    assert dm.data_test
    assert isinstance(dm.data_test, UnlabeledImageFolder)
    assert dm.test_dataloader()

    batch = next(iter(dm.test_dataloader()))
    assert isinstance(batch, tuple)
    x, meta = batch
    assert isinstance(x[0], Tensor)

    assert len(x) <= batch_size
    assert x[0].dtype == float32
    assert isinstance(meta[0], ImageMeta)
    assert all([meta[0].original_spatial_shape, meta[0].spatial_shape, meta[0].filepath])

    # for i, item in enumerate(dm.test_dataloader()):
    #     print(f"{i}/{len(dm.test_dataloader())}")

    # test dataloader with annotations
    dm.data_test = None
    assert not dm.data_test
    dm.images_testset_path = dm.images_validset_path
    dm.labels_testset_path = dm.labels_validset_path
    dm.hparams.data_name = "Testing"
    dm.setup(stage=TrainerFn.TESTING)

    assert dm.data_test
    assert isinstance(dm.data_test, CocoDetection)
    assert dm.test_dataloader()

    batch = next(iter(dm.test_dataloader()))
    assert isinstance(batch, tuple)
    x, y = batch

    assert len(x) <= batch_size  # collate_fn
    assert len(y) == len(x)
    assert x[0].dtype == float32
    assert y[0]["boxes"].dtype == float32
    assert y[0]["labels"].dtype == int64

    # predict dataloader
    dm.hparams.data_dir = dm.images_testset_path
    dm.setup(stage=TrainerFn.PREDICTING)
    assert dm.data_predict
    assert isinstance(dm.data_predict, UnlabeledImageFolder)
    assert dm.predict_dataloader()

    batch = next(iter(dm.predict_dataloader()))
    assert isinstance(batch, tuple)
    x, meta = batch
    assert isinstance(x[0], Tensor)
    assert len(x) <= batch_size
    assert x[0].dtype == float32
    assert isinstance(meta[0], ImageMeta)
    assert all([meta[0].original_spatial_shape, meta[0].spatial_shape, meta[0].filepath])


def test_coco_datamodule_format_batch_to_coco(
    data_dir: Traversable, tmp_path: Path, batch_prediction: tuple[list, list]
):
    """Check validity of coco format returns by `format_prediction_to_coco`.

    Check if a random batch `batch_prediction` can be loaded with COCO API.

    Args:
        data_dir (Traversable): A Traversable representing the test data directory.
        tmp_path (Path): The temporary path to test and download COCO.
        batch_prediction (tuple(list, list)): A random batch prediction.
    """
    datamodule = COCODataModule(data_dir=str(data_dir))

    batch_indicies = list(range(len(batch_prediction[0])))
    # Format prediction
    coco_prediction, annotation_id = datamodule.format_batch_to_coco(
        batch_prediction[0], batch_prediction[1], batch_indicies
    )

    # Correct number of annotations
    assert annotation_id == len(batch_prediction[0][0]["labels"]) + 1

    prediction_path = tmp_path / "prediction.json"
    with open(prediction_path, "w") as jsonfile:
        json.dump(coco_prediction, jsonfile)

    # Check that a COCO dataset can be instanciated with the output annotation file
    assert CocoDetection(datamodule.images_validset_path, annFile=prediction_path)


@pytest.mark.slow
def test_coco_datamodule_prepare_data(tmp_path: Path):
    """Test `prepare_data()` method from `COCODataModule`.

    It verifies the downloading and extraction mechanism of this method by downloading the entire
    COCO dataset in `tmp_path`.

    Args:
        tmp_path (Path): The temporary path to test and download COCO.
    """
    data_dir = tmp_path
    dm = COCODataModule(data_dir=str(data_dir), auto_download_dataset=True)
    dm.prepare_data()

    assert data_dir.joinpath("COCO").is_dir()

    coco_data_dir = data_dir.joinpath("COCO")
    # Test `images` directory
    assert coco_data_dir.joinpath("images").is_dir()
    for folder in ["train", "valid", "test"]:
        assert coco_data_dir.joinpath("images", folder).is_dir()

    # Test `labels` directory
    assert coco_data_dir.joinpath("labels").is_dir()
    for folder in ["train", "valid"]:
        assert coco_data_dir.joinpath("labels", folder).is_dir()
        if folder == "train":
            assert coco_data_dir.joinpath("labels", folder, "instances_train2017.json").exists()

        else:
            assert coco_data_dir.joinpath("labels", folder, "instances_val2017.json").exists()
