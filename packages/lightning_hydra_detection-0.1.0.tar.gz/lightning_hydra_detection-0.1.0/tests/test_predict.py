import json
from pathlib import Path

import pytest
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig

from lightning_hydra_detection.predict import predict
from tests.conftest import ALL_MODELS


def coco_prediction_format(tmp_path: Path, images_predictset_path: str, prediction_filename: str):
    """Test if `prediction_filename` file correspond to COCO format.

    Check if the prediction file correspond to COCO predictions format. It checks if all keys exist
    and their type. It also test the length and format of `bbox`. Image filenames should also
    exist.

    Args:
        tmp_path (Path): The temporary logging path.
        images_predictset_path (Path): The path to the predict image directory.
        prediction_filename (str): The filename in which prediction data is stored.
    """
    with open(tmp_path / prediction_filename) as jsonfile:
        predictions = json.load(jsonfile)

    assert isinstance(predictions, dict)

    assert all(["info", "categories", "images", "annotations", "licenses" in predictions])

    assert isinstance(predictions["annotations"], list)
    assert isinstance(predictions["images"], list)

    for img in predictions["images"]:
        assert (images_predictset_path / img["file_name"]).is_file()

    for pred in predictions["annotations"]:
        assert isinstance(pred, dict)

        assert all(["bbox", "category_id", "score", "id", "image_id" in pred])

        assert isinstance(pred["bbox"], list)
        assert isinstance(pred["category_id"], int)
        assert isinstance(pred["score"], float)

        assert len(pred["bbox"]) == 4

        # Is `image_id` corresponding to an image `id`
        assert pred["image_id"] in map(lambda d: d["id"], predictions["images"])

        # Are predicted bboxes in correct format
        for img in predictions["images"]:
            if img["id"] == pred["image_id"]:
                width = img["width"]
                height = img["height"]
                break
        x, y, w, h = pred["bbox"]

        assert x >= 0.0 and x <= width
        assert y >= 0.0 and y <= height
        assert w >= 0.0 and x + w <= width + 1e-3  # Should be strict but not enough training
        assert y >= 0.0 and y + h <= height + 1e-3  # Should be strict but not enough training


@pytest.mark.parametrize("model", ALL_MODELS)
def test_predict_fast(tmp_path: Path, cfg_predict_fast: DictConfig, model: str) -> None:
    """Run 1 training, 1 prediction stage and check saved predictions.

    Tests predicting stage from a `cfg_predict` config. The structure of the JSON prediction
    output file is checked.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_predict_fast (DictConfig): A DictConfig containing a valid prediction configuration.
        model (str): The name of the model.
    """
    # Prediction stage
    HydraConfig().set_config(cfg_predict_fast)
    _, object_dict = predict(cfg_predict_fast)

    # Test files predictions write on epoch interval
    assert any([f.name == "predictions.json" for f in tmp_path.iterdir()])


@pytest.mark.slow
@pytest.mark.parametrize("model", ALL_MODELS)
def test_predict(tmp_path: Path, cfg_predict: DictConfig, model: str) -> None:
    """Run 1 training, 1 prediction stage and check saved predictions.

    Tests predicting stage from a `cfg_predict` config. The structure of the JSON prediction
    output file is checked.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_predict (DictConfig): A DictConfig containing a valid prediction configuration.
        model (str): The name of the model.
    """
    # Prediction stage
    HydraConfig().set_config(cfg_predict)
    _, object_dict = predict(cfg_predict)

    # Test files predictions write on epoch interval
    assert any([f.name == "predictions.json" for f in tmp_path.iterdir()])
