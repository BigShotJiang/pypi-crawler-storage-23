import pytest
from hydra.core.hydra_config import HydraConfig
from lightning.pytorch.accelerators import CPUAccelerator, CUDAAccelerator
from lightning.pytorch.strategies.ddp import DDPStrategy
from omegaconf import DictConfig

from lightning_hydra_detection.train import train
from tests.conftest import ALL_MODELS
from tests.helpers.run_if import run_if


@pytest.mark.slow
@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_cpu(cfg_train_cpu: DictConfig, model: str) -> None:
    """Run for 1 train, val over 3 epochs on CPU.

    Args:
        cfg_train_cpu (DictConfig): A DictConfig containing a valid training configuration.
        model (str): The name of the model to train.
    """
    HydraConfig().set_config(cfg_train_cpu)
    _, object_dict = train(cfg_train_cpu)

    assert isinstance(object_dict["trainer"].accelerator, CPUAccelerator)


@pytest.mark.slow
def test_train_gpu(cfg_train_gpu: DictConfig) -> None:
    """Run for 1 train, val over 3 epochs on GPU.

    Args:
        cfg_train_gpu (DictConfig): A DictConfig containing a valid training configuration.
    """
    HydraConfig().set_config(cfg_train_gpu)
    _, object_dict = train(cfg_train_gpu)

    assert isinstance(object_dict["trainer"].accelerator, CUDAAccelerator)


@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_fast_dev_run_cpu(cfg_train_fast_cpu: DictConfig, model: str) -> None:
    """Run for 1 train, val and test loop on CPU with the global and fast configs.

    Args:
        cfg_train_fast_cpu (DictConfig): A DictConfig containing a valid training configuration.
        model (str): The name of the model to train.
    """
    HydraConfig().set_config(cfg_train_fast_cpu)
    _, object_dict = train(cfg_train_fast_cpu)

    assert isinstance(object_dict["trainer"].accelerator, CPUAccelerator)


@run_if(min_gpus=1)
@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_fast_dev_run_gpu(cfg_train_fast_gpu: DictConfig, model: str) -> None:
    """Run for 1 train, val and test loop on GPU with the global and fast configs.

    Args:
        cfg_train_fast_gpu (DictConfig): A DictConfig containing a valid training configuration.
        model (str): The name of the model to train.
    """
    HydraConfig().set_config(cfg_train_fast_gpu)
    _, object_dict = train(cfg_train_fast_gpu)

    assert isinstance(object_dict["trainer"].accelerator, CUDAAccelerator)


@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_mixed_precision(cfg_train_mixed_precision: DictConfig, model: str) -> None:
    """Train 1 epoch on GPU with mixed-precision and the global and fast configs.

    Args:
        cfg_train_mixed_precision (DictConfig): A DictConfig containing a valid training
        model (str): The name of the model to train.
    configuration.
    """
    HydraConfig().set_config(cfg_train_mixed_precision)
    _, object_dict = train(cfg_train_mixed_precision)

    assert object_dict["trainer"].precision == "16-mixed"


@pytest.mark.parametrize("model", ALL_MODELS)
def test_train_ddp_sim(cfg_train_ddp_sim: DictConfig, model: str) -> None:
    """Simulate DDP (Distributed Data Parallel) on 2 CPU processes with global and fast configs.

    Args:
        cfg_train_ddp_sim (DictConfig): A DictConfig containing a valid training configuration.
        model (str): The name of the model to train.
    """
    HydraConfig().set_config(cfg_train_ddp_sim)
    _, object_dict = train(cfg_train_ddp_sim)

    assert isinstance(object_dict["trainer"].strategy, DDPStrategy)
