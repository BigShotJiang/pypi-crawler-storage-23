from pathlib import Path

from hydra.core.hydra_config import HydraConfig
from lightning.pytorch.callbacks.early_stopping import EarlyStopping
from omegaconf import DictConfig, open_dict

from lightning_hydra_detection.train import train


def test_model_checkpoint(tmp_path: Path, cfg_model_checkpoint: DictConfig) -> None:
    """Test model checkpoint callback and resuming.

    Run 3 epochs, finish, check the saved checkpoints. The last checkpoint is used to resume the
    training for another epoch. The number of checkpoints meant to be saved are checked again.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_model_checkpoint (DictConfig): A DictConfig containing a valid training configuration.
    """
    HydraConfig().set_config(cfg_model_checkpoint)
    metric_dict_1, _ = train(cfg_model_checkpoint)

    model_checkpoint_dirpath = Path(cfg_model_checkpoint.callbacks.model_checkpoint.dirpath)
    ckpt_files = list(model_checkpoint_dirpath.glob("*.ckpt"))
    # Assert if 'last.ckpt' exists
    if cfg_model_checkpoint.callbacks.model_checkpoint.save_last:
        assert any([file.name == "last.ckpt" for file in ckpt_files])

    # Check if the number of saved checkpoints is correct
    if (
        cfg_model_checkpoint.trainer.max_epochs
        >= cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
    ):
        assert (
            len(ckpt_files)
            == cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
            + cfg_model_checkpoint.callbacks.model_checkpoint.save_last
        )
    else:
        assert (
            len(ckpt_files)
            <= cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
            + cfg_model_checkpoint.callbacks.model_checkpoint.save_last
        )

    # Resume from checkpoints and add an epoch to the config
    with open_dict(cfg_model_checkpoint):
        if cfg_model_checkpoint.callbacks.model_checkpoint.save_last:
            cfg_model_checkpoint.ckpt_path = model_checkpoint_dirpath.joinpath("last.ckpt")
        else:
            cfg_model_checkpoint.ckpt_path = sorted(ckpt_files)[-1]

        cfg_model_checkpoint.trainer.max_epochs = cfg_model_checkpoint.trainer.max_epochs + 1

    metric_dict_2, _ = train(cfg_model_checkpoint)

    ckpt_files = list(model_checkpoint_dirpath.glob("*.ckpt"))

    # Check if the number of saved checkpoints is correct
    if (
        cfg_model_checkpoint.trainer.max_epochs
        >= cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
    ):
        assert (
            len(ckpt_files)
            == cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
            + cfg_model_checkpoint.callbacks.model_checkpoint.save_last
        )
    else:
        assert (
            len(ckpt_files)
            <= cfg_model_checkpoint.callbacks.model_checkpoint.save_top_k
            + cfg_model_checkpoint.callbacks.model_checkpoint.save_last
        )


def test_early_stopping(tmp_path: Path, cfg_train_early_stopping: DictConfig) -> None:
    """Test early stopping configuration.

    Run a training with large min_delta value to force early stopping. Depending on the early
    stopping patience and the max epoch, early stopping interrupts the training.

    Args:
        tmp_path (Path): The temporary logging path.
        cfg_train_early_stopping (DictConfig): A DictConfig containing a valid training
        configuration using the early stopping callback.
    """
    HydraConfig().set_config(cfg_train_early_stopping)
    metric_dict_1, object_dict = train(cfg_train_early_stopping)

    for callback in object_dict["callbacks"]:
        if isinstance(callback, EarlyStopping):
            if (
                cfg_train_early_stopping.trainer.max_epochs
                > cfg_train_early_stopping.callbacks.early_stopping.patience
            ):
                # Has the callback reached its limit
                assert (
                    callback.wait_count
                    == cfg_train_early_stopping.callbacks.early_stopping.patience
                )
                # Has the training stopped
                assert (
                    callback.stopped_epoch
                    == cfg_train_early_stopping.callbacks.early_stopping.patience
                )
                assert cfg_train_early_stopping.trainer.max_epochs > callback.stopped_epoch

            else:
                # Has the callback count reached max_epochs limit
                assert callback.wait_count == cfg_train_early_stopping.trainer.max_epochs - 1
                # Has the training stopped
                assert callback.stopped_epoch == 0
