from typing import Any

import hydra
from omegaconf import DictConfig

from lightning_hydra_detection.utils import (
    RankedLogger,
    extras,
    instantiate_callbacks,
    instantiate_loggers,
    log_hyperparameters,
)

log = RankedLogger(__name__, rank_zero_only=True)


def predict(cfg: DictConfig) -> tuple[dict[str, Any], dict[str, Any]]:
    """Predict given checkpoint on a datamodule testset.

    This method is wrapped in optional @task_wrapper decorator, that controls the behavior during
    failure. Useful for multiruns, saving info about the crash, etc.

    Args:
        cfg (DictConfig): Configuration composed by Hydra.

    Returns:
        tuple[dict[str, Any], dict[str, Any]]: The metrics and instantiated objects.
    """
    assert cfg.ckpt_path

    log.info(f"Instantiating datamodule <{cfg.data._target_}>")
    datamodule = hydra.utils.instantiate(cfg.data)

    log.info(f"Instantiating task <{cfg.task._target_}>")
    task = hydra.utils.instantiate(cfg.task)

    log.info("Instantiating callbacks...")
    callbacks = instantiate_callbacks(cfg.get("callbacks"))

    log.info("Instantiating loggers...")
    logger = instantiate_loggers(cfg.get("logger"))

    log.info(f"Instantiating trainer <{cfg.trainer._target_}>")
    trainer = hydra.utils.instantiate(cfg.trainer, callbacks=callbacks, logger=logger)

    object_dict = {
        "cfg": cfg,
        "datamodule": datamodule,
        "task": task,
        "callbacks": callbacks,
        "logger": logger,
        "trainer": trainer,
    }

    if logger:
        log.info("Logging hyperparameters!")
        log_hyperparameters(object_dict)

    log.info("Starting Predicting!")
    trainer.predict(
        model=task, datamodule=datamodule, ckpt_path=cfg.ckpt_path, return_predictions=False
    )

    metric_dict = trainer.callback_metrics

    return metric_dict, object_dict


@hydra.main(
    version_base="1.3",
    config_path="pkg://lightning_hydra_detection.configs",
    config_name="predict.yaml",
)
def main(cfg: DictConfig) -> None:
    """Main entry point for prediction.

    :param cfg: DictConfig configuration composed by Hydra.
    """
    # apply extra utilities
    # (e.g. ask for tags if none are provided in cfg, print cfg tree, etc.)
    extras(cfg)

    predict(cfg)


if __name__ == "__main__":
    main()
