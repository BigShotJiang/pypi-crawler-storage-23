from typing import Any

import torch
from lightning import LightningModule
from torch import Tensor
from torchmetrics import MaxMetric, MeanMetric
from torchmetrics.detection.mean_ap import MeanAveragePrecision

from lightning_hydra_detection.data.components.unlabeled_image_folder import ImageMeta


class DetectLitModule(LightningModule):
    """Example of a `LightningModule` for COCO classification.

    A `LightningModule` implements 8 key methods:

    ```python
    def __init__(self):
    # Define initialization code here.

    def setup(self, stage):
    # Things to setup before each stage, 'fit', 'validate', 'test', 'predict'.
    # This hook is called on every process when using DDP.

    def training_step(self, batch, batch_idx):
    # The complete training step.

    def validation_step(self, batch, batch_idx):
    # The complete validation step.

    def test_step(self, batch, batch_idx):
    # The complete test step.

    def predict_step(self, batch, batch_idx):
    # The complete predict step.

    def configure_optimizers(self):
    # Define and configure optimizers and LR schedulers.
    ```

    Docs:
        https://lightning.ai/docs/pytorch/latest/common/lightning_module.html
    """

    def __init__(
        self,
        model: torch.nn.Module,
        optimizer: torch.optim.Optimizer,
        lr_decay_config: dict,
        lr_scheduler_config: dict,
        compile: bool,
    ) -> None:
        """Initialize a `COCOLitModule`.

        Args:
            model (torch.nn.Module): The model to train.
            optimizer (torch.optim.Optimizer): The optimizer to use for training.
            lr_decay_config (dict): A dictionary to configure the layer-wise learning rate decay to
                use for training.
            lr_scheduler_config (dict): A dictionary to configure the learning rate scheduler to
                use for training.
            compile (bool): A boolean to either compile or not the model.
        """
        super().__init__()

        # this line allows to access init params with 'self.hparams' attribute
        # also ensures init params will be stored in ckpt
        self.save_hyperparameters(ignore=["model"], logger=False)

        self.model = model

        # metric objects for calculating and averaging accuracy across batches
        self.val_acc = MeanAveragePrecision()
        self.test_acc = MeanAveragePrecision()

        # for averaging loss across batches
        self.val_loss = MeanMetric()
        self.train_loss = MeanMetric()

        # for tracking best so far validation accuracy
        self.val_acc_best = MaxMetric()

    def forward(self, x: Tensor) -> Tensor:
        """Perform a forward pass through the model `self.model`.

        :param x: A tensor of images.
        :return: A tensor of logits.
        """
        return self.model(x)

    def on_train_start(self) -> None:
        """Lightning hook that is called when training begins."""
        # by default lightning executes validation step sanity checks before training starts,
        # so it's worth to make sure validation metrics don't store results from these checks
        self.val_loss.reset()
        self.val_acc.reset()
        self.val_acc_best.reset()

    def training_step(
        self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int
    ) -> torch.Tensor:
        """Perform a single training step on a batch of data from the training set.

        :param batch: A batch of data (a tuple) containing the input tensor of images and target
            labels.
        :param batch_idx: The index of the current batch.
        :return: A tensor of losses between model predictions and targets.
        """
        x, y = batch

        # FasterRCNN outputs loss in training mode
        loss_dict = self.model(x, y)
        loss = sum(loss for loss in loss_dict.values())

        # update and log metrics
        # Note: Use update() when logging on epoch to avoid extra computation
        self.train_loss.update(loss)
        self.log("train/loss", self.train_loss, on_step=True, on_epoch=True, prog_bar=True)

        # return loss for backpropagation
        return loss

    def on_train_epoch_end(self) -> None:
        """Lightning hook that is called when a training epoch ends."""
        pass

    def validation_step(self, batch: tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> None:
        """Perform a single validation step on a batch of data from the validation set.

        :param batch: A batch of data (a tuple) containing the input tensor of images and target
            labels.
        :param batch_idx: The index of the current batch.
        """
        x, y = batch

        # Torch models only output loss when in train mode
        # Pytorch Lightning already disable gradient when calling validation_step, so we don't have to:
        # https://github.com/Lightning-AI/pytorch-lightning/issues/2171
        self.model.train()
        loss_dict = self.model(x, y)
        self.model.eval()
        preds = self.forward(x)
        loss = sum(loss for loss in loss_dict.values())

        # update and log metrics
        self.val_loss.update(loss)
        self.val_acc.update(preds, y)
        self.log("val/loss", self.val_loss, on_step=True, on_epoch=True, prog_bar=True)

    def on_validation_epoch_end(self) -> None:
        """Lightning hook that is called when a validation epoch ends."""
        lightning_optimizer = self.optimizers()
        for param_group in lightning_optimizer.optimizer.param_groups:
            lr = param_group["lr"]
        acc = self.val_acc.compute()["map"]  # get current val acc
        self.val_acc_best(acc)  # update best so far val acc

        self.log("lr", lr, on_step=False, on_epoch=True, prog_bar=True)
        self.log("val/acc", acc, on_step=False, on_epoch=True, prog_bar=True)
        self.log("val/acc_best", self.val_acc_best.compute(), sync_dist=True, prog_bar=True)

        # Reset metrics computed in {train/val/test}_epoch_end
        self.val_acc.reset()

    def test_step(self, batch: Tensor | tuple[torch.Tensor, torch.Tensor], batch_idx: int) -> None:
        """Perform a single test step on a batch of data from the test set.

        :param batch: A batch of data (a tuple) containing the input tensor of images and target
            labels.
        :param batch_idx: The index of the current batch.
        """
        # FasterRCNN outputs preds in non-training mode
        preds = self.forward(batch[0])

        if not isinstance(batch[1][0], ImageMeta):
            y = batch[1]
            self.test_acc.update(preds, y)

    def on_test_epoch_end(self) -> None:
        """Lightning hook that is called when a test epoch ends."""
        map_50_95 = self.test_acc.compute()["map"]
        self.log("test/acc", map_50_95, on_step=False, on_epoch=True)

    def predict_step(self, batch: Tensor, batch_idx: int) -> tuple:
        """Perform a single predict step on a batch of data from the predict set.

        Args:
            batch: A batch of data (a tuple) containing the input tensor of images and metakeys.
            batch_idx: The index of the current batch.

        Returns:
            tuple: The tensor predictions and the associated metadata.
        """
        x, meta = batch
        preds = self.forward(x)

        return preds, meta

    def setup(self, stage: str) -> None:
        """Lightning hook that is called at the beginning of a stage.

        This is a good hook when you need to build models dynamically or adjust something about
        them. This hook is called on every process when using DDP.

        :param stage: Either `"fit"`, `"validate"`, `"test"`, or `"predict"`.
        """
        if self.hparams.compile and stage == "fit":
            self.model = torch.compile(self.model)

    def configure_optimizers(self) -> dict[str, Any]:
        """Choose what optimizers and learning-rate schedulers to use in your optimization.

        Normally you'd need one. But in the case of GANs or similar you might have multiple.

        Examples:
        --------
            https://lightning.ai/docs/pytorch/latest/common/lightning_module.html#configure-optimizers

        :return: A dict containing the configured optimizers and learning-rate schedulers
        to be used for training.
        """
        optimizer = self.hparams.optimizer(params=self.trainer.model.parameters())
        if self.hparams.lr_decay_config:
            pass
        if self.hparams.lr_scheduler_config:
            if self.hparams.lr_scheduler_config.scheduler.func.__name__ == "SequentialLR":
                # Instantiate nested schedulers
                schedulers = self.hparams.lr_scheduler_config.scheduler.keywords["schedulers"]
                for i in range(len(schedulers)):
                    schedulers[i] = schedulers[i](optimizer=optimizer)

            scheduler = self.hparams.lr_scheduler_config.scheduler(optimizer=optimizer)

            return {
                "optimizer": optimizer,
                "lr_scheduler": {
                    "scheduler": scheduler,
                    "monitor": self.hparams.lr_scheduler_config.monitor,
                    "interval": self.hparams.lr_scheduler_config.interval,
                    "frequency": self.hparams.lr_scheduler_config.frequency,
                    "strict": self.hparams.lr_scheduler_config.strict,
                    "name": self.hparams.lr_scheduler_config.name,
                },
            }

        return {"optimizer": optimizer}
