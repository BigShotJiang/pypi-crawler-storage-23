from .faster_rcnn import build_faster_rcnn_resnet50_fpn
from .ssd import build_ssd300_vgg16
from .simple_dense_net import SimpleDenseNet