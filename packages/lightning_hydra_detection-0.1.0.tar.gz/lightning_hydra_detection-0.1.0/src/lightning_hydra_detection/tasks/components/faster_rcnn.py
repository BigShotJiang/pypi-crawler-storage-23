from typing import Any

from torchvision.models import ResNet50_Weights
from torchvision.models.detection import (
    FasterRCNN_ResNet50_FPN_V2_Weights,
    fasterrcnn_resnet50_fpn_v2,
)
from torchvision.models.detection.faster_rcnn import FasterRCNN, FastRCNNPredictor


def build_faster_rcnn_resnet50_fpn(
    weights: FasterRCNN_ResNet50_FPN_V2_Weights | None = None,
    progress: bool = True,
    num_classes: int | None = None,
    weights_backbone: ResNet50_Weights = ResNet50_Weights.IMAGENET1K_V2,
    trainable_backbone_layers: int | None = None,
    **kwargs: Any,
) -> FasterRCNN:
    """Build a Faster RCNN Resnet 50 FPN model for fine-tuning.

    The function either changes the last layer of the model with the desired number of classes
    (when `weights` is defined and `num_classes` is different than 91, i.e. the number of classes for COCO) or either creates the model with the passed parameters.

    Please refer to Torchvision documentation for more details on `faster_rcnn_resnet50_fon_v2
    <https://docs.pytorch.org/vision/stable/models/generated/torchvision.models.detection.fasterrcnn_resnet50_fpn_v2.html#fasterrcnn-resnet50-fpn-v2>`.


    Args:
        weights (FasterRCNN_ResNet50_FPN_Weights, optional): The pretrained weights to use.
        progress (bool): If True, displays a progress bar of the download to stderr. Default is
        True.
        num_classes (int, optional): Number of output classes of the model (including the
        background).
        weights_backbone (ResNet50_Weights): The pretrained weights for the backbone.
        trainable_backbone_layers (int, optional): Number of trainable (not frozen) layers starting
        from final block. Valid values are between 0 and 5, with 5 meaning all backbone layers are
        trainable. If None is passed (the default) this value is set to 3.
        **kwargs (Any): Parameters passed to the
          torchvision.models.detection.faster_rcnn.FasterRCNN base class.

    Returns:
        FasterRCNN: The instantiated Faster RCNN model.
    """
    if num_classes != 91 and weights:
        # load a model pre-trained on COCO with 91 classes
        model = fasterrcnn_resnet50_fpn_v2(
            weights=weights,
            progess=progress,
            weights_backbone=weights_backbone,
            trainable_backbone_layers=trainable_backbone_layers,
            **kwargs,
        )

        # get number of input features for the classifier
        in_features = model.roi_heads.box_predictor.cls_score.in_features
        # replace the pre-trained head with a new one
        model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes)

    else:
        model = fasterrcnn_resnet50_fpn_v2(
            weights=weights,
            progess=progress,
            num_classes=num_classes,
            weights_backbone=weights_backbone,
            trainable_backbone_layers=trainable_backbone_layers,
            **kwargs,
        )

    return model
