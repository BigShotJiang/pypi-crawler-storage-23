
from typing import Any

import torch
from torchvision.models import VGG16_Weights
from torchvision.models.detection import (
    SSD300_VGG16_Weights,
    ssd300_vgg16
)
from torchvision.models.detection._utils import retrieve_out_channels
from torchvision.models.detection.ssd import SSD, SSDClassificationHead


def build_ssd300_vgg16(
    weights: SSD300_VGG16_Weights | str | None = None,
    progress: bool = True,
    num_classes: int | None = None,
    weights_backbone: VGG16_Weights = VGG16_Weights,
    trainable_backbone_layers: int | None = None,
    **kwargs: Any,
) -> SSD:
    """Build a SSD300 VGG16 model for fine-tuning.

    The function either changes the last layer of the model with the desired number of classes
    (when `weights` is defined and `num_classes` is different than 91, i.e. the number of classes
    for COCO) or either creates the model with the passed parameters.

    Please refer to Torchvision documentation for more details on `build_ssd300_vgg16
    <https://docs.pytorch.org/vision/main/models/generated/torchvision.models.detection.ssd300_vgg16>`.


    Args:
        weights (SSD300_VGG16_Weights, optional): The pretrained weights to use.
        progress (bool): If True, displays a progress bar of the download to stderr. Default is
        True.
        num_classes (int, optional): Number of output classes of the model (including the
        background).
        weights_backbone (VGG16_Weights): The pretrained weights for the backbone.
        trainable_backbone_layers (int, optional): Number of trainable (not frozen) layers starting
        from final block. Valid values are between 0 and 5, with 5 meaning all backbone layers are
        trainable. If None is passed (the default) this value is set to 5.
        **kwargs (Any): Parameters passed to the
          torchvision.models.detection.ssd.SSD base class.

    Returns:
        FasterRCNN: The instantiated SSDlite model.
    """
    local_weights_path = None
    if isinstance(weights, str):
        local_weights_path = weights
        weights = None

    base_num_classes = 91 if (weights or local_weights_path) else num_classes

    # load a model pre-trained on COCO with 91 classes
    model = ssd300_vgg16(
        weights=weights,
        progress=progress,
        num_classes=base_num_classes,
        weights_backbone=weights_backbone,
        trainable_backbone_layers=trainable_backbone_layers,
        **kwargs,
    )

    if local_weights_path:
        state_dict = torch.load(local_weights_path, map_location="cpu")
        model.load_state_dict(state_dict)

    if num_classes != base_num_classes:
        # Hard coded parameters in torchvision
        size = (300, 300)
        # Retrieve parameters
        in_channels = retrieve_out_channels(model.backbone, size)
        num_anchors = model.anchor_generator.num_anchors_per_location()

        # replace the pre-trained classification head with a new one
        model.head.classification_head = SSDClassificationHead(
            in_channels=in_channels,
            num_anchors=num_anchors,
            num_classes=num_classes,
        )

    return model
