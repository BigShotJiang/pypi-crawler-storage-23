from .classif_module import ClassifLitModule
from .detect_module import DetectLitModule
