from typing import Any

import torch
from torchvision import tv_tensors
from torchvision.tv_tensors import BoundingBoxFormat, TVTensor


class EnsureValidTVTensors(torch.nn.Module):
    """Ensure that a target associated to an image has valid `TVTensors`.

    The expected inputs are an image and its associated target. The keys
    `_dataset_boxes_key`, `_dataset_labels_key` for the target are defined in Torchvision.dataset`.
    The attribute `_dataset_bbox_format` depends on the dataset format (ex. COCO).
    Note that if the Torchvision datasets are wrapped by wrap_dataset_for_transforms_v2 method
    (e.g. CocoDetection is used by coco_dectection_wrapper_factory), then the keys and the bbox
    format correspond to the wrapper ones.

    Read the docs:
    - https://pytorch.org/vision/main/models/generated/torchvision.models.detection.fasterrcnn_resnet50_fpn.html#fasterrcnn-resnet50-fpn
    - https://pytorch.org/vision/stable/generated/torchvision.datasets.wrap_dataset_for_transforms_v2.html#wrap-dataset-for-transforms-v2

    Attributes:
        _dataset_boxes_key (str): Defines the boxes key of the target dict.
            Defaults to `"boxes"`.
        _dataset_labels_key (str): Defines the labels key of the target dict.
            Defaults to `"labels"`.
        _dataset_bbox_format (BoundingBoxFormat): The bounding box format from the `dataset_type'.
            Defaults to `BoundingBoxFormat.XYXY`.
    """

    _dataset_boxes_key: str = "boxes"
    _dataset_labels_key: str = "labels"
    _dataset_bbox_format: BoundingBoxFormat = BoundingBoxFormat.XYXY

    def __init__(self, target_bbox_format: BoundingBoxFormat = BoundingBoxFormat.XYXY):
        super().__init__()
        self._dataset_bbox_format = target_bbox_format

    def forward(self, img: torch.Tensor, target: dict[str, Any]) -> tuple[Any, Any]:
        """Ensure that positive and negative detection targets are `TVTensors.BoundingBoxes`.

        Args:
            img (Tensor): The input image.
            target (dict[str, Any]): The dictionary of annotations to the expected
        `dataset_type`.

        Returns:
            tuple[Tensor, target: dict[str, Any]: The initialized image `img` and
                the `target` dictionary converted to tv_tensors.BoundingBoxes. For hard
                negative examples, the keys corresponding to the dataset_type are
                created as empty tensors in the correct type and format.
        """
        if self._dataset_boxes_key not in target:
            target[self._dataset_boxes_key] = tv_tensors.BoundingBoxes(
                torch.empty((0, 4), dtype=torch.float32),
                format=self._dataset_bbox_format,
                canvas_size=img.shape[-2:],
            )
        else:
            if not isinstance(target[self._dataset_boxes_key], TVTensor):
                target[self._dataset_boxes_key] = tv_tensors.BoundingBoxes(
                    target[self._dataset_boxes_key],
                    format=self._dataset_bbox_format,
                    canvas_size=img.shape[-2:],
                )

        if self._dataset_labels_key not in target:
            target[self._dataset_labels_key] = torch.empty(0, dtype=torch.int64)

        return img, target
