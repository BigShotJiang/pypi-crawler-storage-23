from .coco_datamodule import COCODataModule
from .mnist_datamodule import MNISTDataModule
