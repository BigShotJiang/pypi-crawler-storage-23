import json
import tempfile
from collections import defaultdict
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from pathlib import Path
from typing import Any

import torch
import torchvision.transforms.v2 as transforms
from lightning import LightningDataModule
from pytorch_lightning.trainer.states import TrainerFn
from torch import Tensor, float32
from torch.utils.data import DataLoader, Dataset, random_split
from torchvision.datasets import CocoDetection, wrap_dataset_for_transforms_v2
from torchvision.datasets.utils import download_and_extract_archive
from torchvision.tv_tensors import BoundingBoxFormat
from torchvision.utils import draw_bounding_boxes, save_image

from lightning_hydra_detection.data.components import (
    ImageMeta,
    UnlabeledImageFolder,
)
from lightning_hydra_detection.utils.torchvision_target_format import (
    EnsureValidTVTensors,
)
from lightning_hydra_detection.utils.utils import show


def collate_fn(batch: Any):
    """Define the collate function for a detection task.

    Args:
        batch (Any): The batch yielded by the `Dataset`.
    """
    return tuple(zip(*batch, strict=False))


def download_and_extract_coco_archive(download_root: str):
    """Download and extract all the COCO dataset in `download_root`.

    Args:
        download_root (str): The root directory to download into.
    """
    # Populate download links for COCO
    folders = ["train2017", "val2017", "test2017", "annotations"]
    url_template = "http://images.cocodataset.org/{}/{}.zip"
    urls = []
    for folder in folders:
        curr_url = url_template.format("zips", folder)
        if "annotations" in folder:
            curr_url = url_template.format("annotations", f"{folder}_trainval2017")
        urls += [curr_url]

    # Download COCO
    with ThreadPoolExecutor(max_workers=4) as executor:
        futures = [
            executor.submit(download_and_extract_archive, url, download_root) for url in urls
        ]
        for future in futures:
            future.result()


class COCODataModule(LightningDataModule):
    """`LightningDataModule` for the COCO dataset.

    The COCO dataset consists of over 120,000 images with object instances
    annotated. It includes 80 object classes such as person, animal, and
    vehicle. The dataset provides instance-level labels for bounding boxes and
    polygons. It is widely used as a benchmark for object detection,
    segmentation, and captioning tasks.

    For more information on the `LightningDataModule`:
        https://lightning.ai/docs/pytorch/latest/data/datamodule.html

    Attributes:
        train_transforms_begin (Sequence[Callable]): The list of first pre-processing transforms
            for the train and valid step. Defaults to (`ToImage`, `EnsureValidTVTensors`).
        train_transforms_end (Sequence[Callable]): The list of last pre-processing transforms for
            the train and valid step. Defaults to (`ClampBoundingBoxes`,
            `SanitizeBoundingBoxes`).
        test_transforms_begin (Sequence[Callable]): The list of first pre-processing transforms
            for the test step. Defaults to (`ToImage`).
        test_transforms_end (Sequence[Callable]): The list of last pre-processing transforms for
            the test step. Defaults to (`ToDType`).
        predict_transforms_begin (Sequence[Callable]): The list of first pre-processing transforms
            for the prediction step. Defaults to (`ToImage`).
        predict_transforms_end (Sequence[Callable]): The list of last pre-processing transforms for
            the prediction step. Defaults to (`ToDType`).
        post_transforms_end (Sequence[Callable]): The list of last post-processing transforms.
             Defaults to (`EnsureValidTVTensors`, `ConvertBoundingBoxes`).
        batch_size_per_device (int): The batch size per device.
        data_path (Path): The root directory on disk for the COCO dataset.
        data_train Dataset | None: The testing `Dataset`. Defaults to `None`.
        data_val: Dataset | None: The testing `Dataset`. Defaults to `None`.
        data_test: Dataset | None: The testing `Dataset`. Defaults to `None`.
        images_trainset_path (Path): The path to the training images.
        images_validset_path (Path): The path to the validation images.
        images_testset_path (Path): The path to the testing images.
        labels_trainset_path (Path): The path to the training labels.
        labels_validset_path (Path): The path to the valid labels.
        coco_detection_label_pattern (str): The match pattern to find the COCO detection label
            files. Defaults to "instances*.json".
    """

    coco_bbox_format: BoundingBoxFormat = BoundingBoxFormat.XYWH
    tv_model_bbox_format: BoundingBoxFormat = BoundingBoxFormat.XYXY

    train_transforms_begin: list[Callable] = [
        transforms.ToImage(),
        EnsureValidTVTensors(coco_bbox_format),  # COCO annotations tv tensor
        transforms.ConvertBoundingBoxFormat(tv_model_bbox_format),
    ]
    train_transforms_end: list[Callable] = [
        transforms.ToDtype(dtype=float32, scale=True),
        transforms.ClampBoundingBoxes(),
        # ClampBoundingBoxes may be call before SanitizeBoundingBoxes
        # Avoid calling SanitizeBoundingBoxes when RandomIoUCrop is called
        transforms.SanitizeBoundingBoxes(),
    ]
    test_transforms_begin: list[Callable] = [
        transforms.ToImage(),
        EnsureValidTVTensors(coco_bbox_format),  # COCO annotations tv tensor
        transforms.ConvertBoundingBoxFormat(tv_model_bbox_format),
    ]
    test_transforms_end: list[Callable] = [
        transforms.ToDtype(dtype=float32, scale=True),
        transforms.ClampBoundingBoxes(),
        # ClampBoundingBoxes may be call before SanitizeBoundingBoxes
        # Avoid calling SanitizeBoundingBoxes when RandomIoUCrop is called
        transforms.SanitizeBoundingBoxes(),
    ]
    predict_transforms_begin: list[Callable] = [
        transforms.ToImage(),
    ]
    predict_transforms_end: list[Callable] = [
        transforms.ToDtype(dtype=float32, scale=True),
    ]
    post_transforms_end: list[Callable] = [
        EnsureValidTVTensors(),
        transforms.ConvertBoundingBoxFormat(coco_bbox_format),
    ]

    data_train: Dataset | None = None
    data_val: Dataset | None = None
    data_test: Dataset | None = None
    data_predict: Dataset | None = None
    coco_detection_label_pattern: str = "instances*.json"

    def __init__(
        self,
        data_dir: str = "data/",
        data_name: str = "COCO",
        auto_partition_from_train: bool = False,
        train_val_test_split: tuple[float, float, float] = (0.8, 0.1, 0.1),
        batch_size: int = 64,
        num_workers: int = 0,
        pin_memory: bool = False,
        predict_mode: bool = False,
        auto_download_dataset: bool = False,
        train_transforms: list | None = None,
        test_transforms: list | None = None,
        predict_transforms: list | None = None,
        post_transforms: list | None = None,
        test_on_val_split: bool = False,
    ) -> None:
        """Initialize a `COCODataModule`.

        Args:
            data_dir (str, optional): The data directory. Defaults to "data/".
            data_name (str, optional): The data name, if using a custom dataset (not COCO).
                Defaults to "COCO".
            auto_partition_from_train (bool, optional): Enable automatic partitioning of the
                dataset from the train folder on disk. Defaults to `False`.
            train_val_test_split (tuple[float, float, float]): The train, validation and test
                split. If folders exists on disk, this is ignored.
                Defaults to (0.8, 0.1, 0.1).
            batch_size (int, optional): The batch size. Defaults to `64`.
            num_workers (int, optional): The number of workers. Defaults to `0`.
            pin_memory (bool, optional): Whether to pin memory. Defaults to `False`.
            predict_mode (bool, optional): Whether the trainer is in the
                prediction phase. Defaults to `False`.
            auto_download_dataset (bool, optional): Whether to automatically download COCO or not.
            train_transforms (list, optional): The transformations and augmentations to apply
                to the train and validation datasets.
            test_transforms (list, optional): The transformations and augmentations to apply
                to the test dataset.
            predict_transforms (list, optional): The transformations and augmentations to apply
                to the prediction dataset.
            post_transforms (list, optional): The transformations and augmentations to apply
                for post-processing.
        """
        super().__init__()

        # Ensures that init params are accessible with `self.hparams`` and stored in ckpt
        self.save_hyperparameters(logger=False)

        self.batch_size_per_device = batch_size
        self.data_path = Path(data_dir).joinpath(data_name)
        self.images_trainset_path = Path(self.data_path).joinpath("images", "train")
        self.images_validset_path = Path(self.data_path).joinpath("images", "valid")
        self.images_testset_path = Path(self.data_path).joinpath("images", "valid" if test_on_val_split else "test")
        self.labels_trainset_path = Path(self.data_path).joinpath("labels", "train")
        self.labels_validset_path = Path(self.data_path).joinpath("labels", "valid")
        self.labels_testset_path = Path(self.data_path).joinpath("labels", "valid" if test_on_val_split else "test")

        has_test_labels = (
            self.labels_testset_path.exists() and len(list(self.labels_testset_path.glob("*"))) > 0
        )

        # Initialize if needed transforms
        if not train_transforms:
            train_transforms = []
        if not test_transforms:
            test_transforms = []
        if not predict_transforms:
            predict_transforms = []
        if not post_transforms:
            post_transforms = []

        self.predict_pre_transforms = transforms.Compose(
            self.predict_transforms_begin + predict_transforms + self.predict_transforms_end
        )
        self.train_pre_transforms = transforms.Compose(
            self.train_transforms_begin + train_transforms + self.train_transforms_end
        )
        self.test_pre_transforms = transforms.Compose(
            self.test_transforms_begin + test_transforms + self.test_transforms_end
        )
        if not has_test_labels:
            self.test_pre_transforms = self.predict_pre_transforms
        self.post_transforms = transforms.Compose(post_transforms + self.post_transforms_end)

    def prepare_data(self) -> None:
        """Download COCO dataset if needed.

        A lightning hook to download incrementally the COCO dataset if the user did not specify
        a `data_name` and if the data on disk is not valid. It is called only within a single
        process on CPU. For multi-node training, the execution of this depends on
        `self.prepare_data_per_node()`.
        """
        if (
            not self.hparams.predict_mode
            and not all(
                [
                    self.images_trainset_path.exists(),
                    self.images_validset_path.exists(),
                    self.images_testset_path.exists(),
                    self.labels_trainset_path.exists(),
                    self.labels_validset_path.exists(),
                ]
            )
            and self.hparams.auto_download_dataset
        ):
            tempdir = tempfile.TemporaryDirectory(prefix="lightning-hydra-detection-")
            with tempdir as tempdirname:
                download_and_extract_coco_archive(tempdirname)

                # Create data hierarchy for training
                for curr_path in Path(tempdirname).iterdir():
                    folder = curr_path.name
                    if folder == "train2017" and not self.images_trainset_path.exists():
                        self.images_trainset_path.mkdir(parents=True, exist_ok=True)
                        curr_path.rename(self.images_trainset_path)
                    elif folder == "val2017" and not self.images_validset_path.exists():
                        self.images_validset_path.mkdir(parents=True, exist_ok=True)
                        curr_path.rename(self.images_validset_path)
                    elif folder == "test2017" and not self.images_testset_path.exists():
                        self.images_testset_path.mkdir(parents=True, exist_ok=True)
                        curr_path.rename(self.images_testset_path)
                    elif folder == "annotations" and not all(
                        [
                            self.labels_trainset_path.exists(),
                            self.labels_validset_path.exists(),
                        ]
                    ):
                        self.labels_trainset_path.mkdir(parents=True, exist_ok=True)
                        self.labels_validset_path.mkdir(parents=True, exist_ok=True)
                        label_trainset_file = self.labels_trainset_path.joinpath(
                            "instances_train2017.json"
                        )
                        label_validset_file = self.labels_validset_path.joinpath(
                            "instances_val2017.json"
                        )
                        curr_path.joinpath("instances_train2017.json").rename(label_trainset_file)
                        curr_path.joinpath("instances_val2017.json").rename(label_validset_file)

    def _find_label_file(self, stage: TrainerFn) -> Path:
        """Find the COCO label file for the current stage.

        Args:
            stage (TrainerFn): The stage to setup, can be either `TrainerFn.FITTING`,
                `TrainerFn.VALIDATING`, `TrainerFn.TESTING` or `TrainerFn.PREDICTING`.

        Returns:
            Path: The label file path which has been found.
        """
        if stage == TrainerFn.FITTING:
            label_folder_to_check = self.labels_trainset_path
        elif stage == TrainerFn.VALIDATING:
            label_folder_to_check = self.labels_validset_path
        elif stage == TrainerFn.TESTING:
            label_folder_to_check = self.labels_testset_path

        label_filepaths = list(label_folder_to_check.glob(self.coco_detection_label_pattern))
        if not label_filepaths:
            raise RuntimeError(f"No label file found in {label_folder_to_check}!")
        label_filepath = label_filepaths[0]
        with open(label_filepath) as f:
            label_train_data = json.load(f)
        if "annotations" not in label_train_data:
            raise RuntimeError(f"The label file {label_filepath} does not contain annotations!")

        return label_filepath

    def setup(self, stage: TrainerFn) -> None:
        """Setup the dataset.

        A lightning hook that loads the data on disk and setup the different train/val/test
        `Dataset`. It is called after `self.prepare_data()` and before each stage: `trainer.fit()`,
        `trainer.validate()`, `trainer.test()`, and `trainer.predict()`.

        Args:
            stage (TrainerFn): The stage to setup, can be either `TrainerFn.FITTING`,
                `TrainerFn.VALIDATING`, `TrainerFn.TESTING` or `TrainerFn.PREDICTING`.
        """
        # Divide batch size by the number of devices.
        if self.trainer is not None:
            if self.hparams.batch_size % self.trainer.world_size != 0:
                raise RuntimeError(
                    f"Batch size ({self.hparams.batch_size}) is not divisible"
                    " by the number of devices ({self.trainer.world_size})."
                )
            self.batch_size_per_device = self.hparams.batch_size // self.trainer.world_size
        # if train folder does not exists nothing can be done
        if (stage != TrainerFn.PREDICTING) and (
            not self.images_trainset_path.exists() or not self.labels_trainset_path.exists()
        ):
            raise RuntimeError(
                f"The folders {self.images_trainset_path} or {self.labels_trainset_path}"
                " does not exist."
            )
        # checks that valid and test folders exists if auto partitioning is disabled
        # label test folder is not mandatory
        if (
            stage != TrainerFn.PREDICTING
            and not self.hparams.auto_partition_from_train
            and (
                not self.images_validset_path.exists()
                or not self.images_testset_path.exists()
                or not self.labels_validset_path.exists()
            )
        ):
            raise RuntimeError(
                f"The folders {self.images_validset_path} or {self.images_testset_path}"
                f" or {self.labels_validset_path} does not exist."
                " Enable `auto_partition_from_train` for automatic splitting."
            )
        # datasets creation depending on the current stage
        # validation dataset is created during fit stage because lightning requires it
        if stage == TrainerFn.FITTING:
            if not self.data_train:
                label_train_filepath = self._find_label_file(stage)
                trainset = CocoDetection(
                    root=self.images_trainset_path,
                    annFile=label_train_filepath,
                    transforms=self.train_pre_transforms,
                )
                trainset = wrap_dataset_for_transforms_v2(trainset)
                if self.hparams.auto_partition_from_train:
                    self.data_train, self.data_val, self.data_test = random_split(
                        dataset=trainset,
                        lengths=self.hparams.train_val_test_split,
                    )
                else:
                    self.data_train = trainset
            if not self.data_val:
                label_valid_filepath = self._find_label_file(TrainerFn.VALIDATING)
                validset = CocoDetection(
                    root=self.images_validset_path,
                    annFile=label_valid_filepath,
                    transforms=self.train_pre_transforms,
                )
                self.data_val = wrap_dataset_for_transforms_v2(validset)
        elif stage == TrainerFn.TESTING and not self.data_test:
            if self.labels_testset_path.exists():
                label_test_filepath = self._find_label_file(stage)
                testset = CocoDetection(
                    root=self.images_testset_path,
                    annFile=label_test_filepath,
                    transforms=self.test_pre_transforms,
                )
                self.data_test = wrap_dataset_for_transforms_v2(testset)
            else:
                print("No test label file detected, will only run inference on test images.")
                self.data_test = UnlabeledImageFolder(
                    root=str(self.images_testset_path), transforms=self.test_pre_transforms
                )

        elif (stage == TrainerFn.PREDICTING) and (not self.data_predict):
            if not Path(self.hparams.data_dir).exists():
                raise RuntimeError(f"Prediction set path {self.hparams.data_dir} does not exist.")
            self.data_predict = UnlabeledImageFolder(
                root=Path(self.hparams.data_dir), transforms=self.predict_pre_transforms
            )

    def train_dataloader(self) -> DataLoader:
        """Create and return the train dataloader.

        Returns:
            DataLoader: The train dataloader.
        """
        return DataLoader(
            dataset=self.data_train,
            batch_size=self.batch_size_per_device,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=True,
            collate_fn=collate_fn,
            drop_last=False
        )

    def val_dataloader(self) -> DataLoader[Any]:
        """Create and return the validation dataloader.

        Returns:
            DataLoader: The validation dataloader.
        """
        return DataLoader(
            dataset=self.data_val,
            batch_size=self.batch_size_per_device,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=False,
            collate_fn=collate_fn,
            drop_last=True
        )

    def test_dataloader(self) -> DataLoader[Any]:
        """Create and return the test dataloader.

        Returns:
            DataLoader: The test dataloader.
        """
        return DataLoader(
            dataset=self.data_test,
            batch_size=self.batch_size_per_device,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=False,
            collate_fn=collate_fn,
            drop_last=False
        )

    def predict_dataloader(self) -> DataLoader[Any]:
        """Create and return the test dataloader.

        Returns:
            DataLoader: The predict dataloader.
        """
        return DataLoader(
            dataset=self.data_predict,
            batch_size=self.batch_size_per_device,
            num_workers=self.hparams.num_workers,
            pin_memory=self.hparams.pin_memory,
            shuffle=False,
            collate_fn=collate_fn,
        )

    def _init_coco_result(self) -> dict[str, Any]:
        """Initialize the COCO result dictionary."""
        res = {
            "info": {},
            "categories": [],  # Missing
            "images": [],
            "annotations": [],
            "licenses": [],
        }

        date = datetime.now()
        res["info"] = {
            "year": date.strftime("%Y"),
            "version": "1.0",
            "description": "",
            "contributor": "",
            "date_created": date.isoformat(),
        }

        return res

    def post_process_batch(
        self, batch: list[Tensor], prediction: tuple[list, list]
    ) -> tuple[list[Any], list[dict]]:
        """Post process a batch and its prediction.

        Args:
            batch (list[Tensor]): Batch of images.
            prediction (tuple[list, list]): The list return by a prediction step.
            The first element should be the prediction and the second the image metadata.

        Returns:
            tuple[list[Any], list[dict]]: The post-processed batch of images and targets.
        """
        post_processed_images = list()
        post_processed_targets = list()

        for i in range(len(batch)):
            # Transform image and prediction to the original format.
            post_processed_image, post_processed_target = self.post_transforms(
                batch[i], prediction[0][i]
            )

            post_processed_images.append(post_processed_image)
            post_processed_targets.append(post_processed_target)

        return post_processed_images, post_processed_targets

    def format_batch_to_coco(
        self,
        batch_targets: list[dict[str, Any]],
        batch_image_meta: list[Any],
        batch_indicies: list[Any],
        annotation_id: int = 1,
    ) -> tuple[dict[str, Any], int]:
        """Format batch to COCO.

        The targets `batch_targets` are stored in a dictionary in which
        the keys `annotations` and `images` are created to correspond to COCO
        format.

        Args:
            batch_targets (list[dict[str, Any]]): The predicted or annotated target of a batch.
            batch_image_meta (list[ImageMeta]): The list of image metadata.
            batch_indicies (list[Any]): A sequence of the batch indicies.
            annotation_id (int): The id of the first annotation. Defaults to 1.

        Returns:
            tuple(dict[str, Any], int): A tuple containing the formatted dict with `annotations`
            and `images` keys and the id of the first annotation of the next batch.
        """
        res = defaultdict(list)
        for i, (target, img_meta) in enumerate(zip(batch_targets, batch_image_meta, strict=False)):
            n_preds = len(target["boxes"])

            bbox = target["boxes"].tolist()
            # Format the bbox to keep 6 decimal places for a lighter json file.
            bbox = [[round(e, 6) for e in box_list] for box_list in bbox]

            for j in range(n_preds):
                annotation = {
                    "id": annotation_id,
                    "image_id": batch_indicies[i] + 1,
                    "category_id": int(target["labels"][j]),
                    "bbox": bbox[j],
                }
                annotation_id += 1

                # Add score if in target
                if "scores" in target:
                    annotation["score"] = (
                        round(float(target["scores"][j]), 3),
                    )  # Round the confidence score

                res["annotations"].append(annotation)

            # Image metadata
            res["images"].append(
                {
                    "id": batch_indicies[i] + 1,
                    "file_name": str(img_meta.filepath.name),
                    "width": img_meta.original_spatial_shape[0],
                    "height": img_meta.original_spatial_shape[1],
                }
            )

        return res, annotation_id

    def write_predictions(
        self,
        output_dir: str,
        predictions: list[tuple[list, list]],
        batch_indices: Sequence[Any],
    ) -> None:
        """Store predictions at the end of the epoch.

        Predictions are stored to `output_dir` with the following name
        "predictions.json".

        Args:
            output_dir (str): The output path where predictions are stored.
            predictions (list[tuple[list, list]]): The predictions, a list of prediction per batch
            in which the lists contain the prediction and image metadata.
            batch_indices (Sequence[int]): A sequence of the batch indicies.
        """
        filename = "predictions.json"
        annotation_id = 1

        # Init COCO output structure
        coco_predictions = self._init_coco_result()

        for i, batch_ids in enumerate(batch_indices[0]):
            # Post-process batch
            batch = [
                torch.empty((3, *meta_img.spatial_shape[::-1])) for meta_img in predictions[i][1]
            ]
            _, post_processed_targets = self.post_process_batch(batch, predictions[i])

            # Format post processed predictions to COCO
            formatted_prediction, annotation_id = self.format_batch_to_coco(
                post_processed_targets, predictions[i][1], batch_ids, annotation_id
            )

            # Extend COCO batch predictions to JSON structure
            coco_predictions["annotations"].extend(formatted_prediction["annotations"])
            coco_predictions["images"].extend(formatted_prediction["images"])

        # Save in json file
        with open(Path(output_dir, filename), "w") as jsonfile:
            json.dump(coco_predictions, jsonfile)

    def visualize_prediction(
        self, batch: tuple[list, list], prediction: tuple[list, list], score_threshold: float
    ):
        """At the end of a batch, plot the prediction on original image(s).

        Args:
            batch (tuple[list, list]): The batch passed to the model containing respectively the
            lists of images and image metadata.
            prediction (tuple[list, list]): The batch prediction containing respectively the
            lists of predictions and image metadata.
            score_threshold (float): The threshold above which the boxes are drawn.
        """
        # Function draw_bounding_boxes needs boxes in XYXY format
        # Find the index in the transforms list of the last `transforms.ConvertBoundingBoxFormat`
        for i in range(len(self.post_transforms.transforms)):
            if isinstance(self.post_transforms.transforms[i], transforms.ConvertBoundingBoxFormat):
                convert_bbox_last_id = i

        old_transform_bbox_fmt = self.post_transforms.transforms[convert_bbox_last_id].format
        self.post_transforms.transforms[convert_bbox_last_id].format = BoundingBoxFormat.XYXY

        # Post-process batch and prediction
        post_processed_batch = self.post_process_batch(batch[0], prediction)

        # Draw bounding boxes on images
        images_to_plot = self._draw_bboxes_batch(post_processed_batch, score_threshold)

        show(images_to_plot)

        # Reset bounding box format
        self.post_transforms.transforms[convert_bbox_last_id].format = old_transform_bbox_fmt

    def _draw_bboxes_batch(self, batch: tuple[list, list], threshold: float = 0.0) -> list[Tensor]:
        """Drawn bounding boxes on images from `batch`.

        It draws bounding boxes if `batch` contains annotations. It do not draw bounding boxes
        below `threshold`, only if the item in the annotation list has the key `"scores"`.

        Args:
            batch (tuple[list, list]): A batch pass to the model step. The tuple contains a list of
                images and the list of associated targets.
            threshold (float, optional): The threshold above which the boxes are drawn. It is only
                used if the target key `"scores"` exists.


        Returns:
            list[Tensor]: The images with the drawn bounding boxes.
        """
        has_annotations = isinstance(batch[1][0], dict)

        images = list()
        for i in range(len(batch[0])):
            img = batch[0][i]
            target = batch[1][i]

            if has_annotations:
                # Draw only boxes above threshold if "scores" key exits.
                if "scores" in target:
                    img = draw_bounding_boxes(
                        image=img,
                        boxes=target["boxes"][target["scores"] > threshold],
                        labels=[
                            str(label)
                            for label in target["labels"][target["scores"] > threshold].tolist()
                        ],
                    )
                else:
                    img = draw_bounding_boxes(
                        image=img,
                        boxes=target["boxes"],
                        labels=[str(label) for label in target["labels"].tolist()],
                    )

            images.append(img)

        return images

    def visualize_batch(self, batch: tuple[list, list]):
        """Visualize training, validation, testing or prediction images.

        Args:
            batch (tuple[list, list]): The batch pass to a model step.
        """
        images = self._draw_bboxes_batch(batch)
        show(images)

    def write_batch(self, batch: tuple[list, list], batch_idx: int, save_path: Path):
        """Write training, validation, testing or prediction images.

        The images are saved to JPG format. The filename depends on
        `trainer.state.stage`, `trainer.current_epoch` and `batch_idx` values.

        Args:
            batch (tuple[list, list]): The batch pass to a model step.
            batch_idx (int): The batch index.
            save_path (Path): The path to save the batch.
        """
        image_path = save_path.joinpath("images")
        image_path.mkdir()
        labels_path = save_path.joinpath("labels")
        labels_path.mkdir()

        filename = (
            f"{self.trainer.state.stage}_epoch_"
            f"{self.trainer.current_epoch:03d}_batch_{batch_idx:03d}"
        )
        # Save images
        for i, img in enumerate(batch[0]):
            img_filename = filename + f"_id_{i:03d}.jpg"
            save_image(img, fp=image_path.joinpath(img_filename))

        # Save annotations if exist
        if isinstance(batch[1][0], dict):
            # Create images metadata
            images_meta = []
            for img in batch[0]:
                img_filename = filename + f"_id_{i:03d}.jpg"
                meta = ImageMeta(
                    tuple(img.shape[1:][::-1]),
                    tuple(img.shape[1:][::-1]),
                    image_path.joinpath(img_filename),
                )
                images_meta.append(meta)

            # Initialize coco annotation structure
            coco_result = self._init_coco_result()
            # Format batch to COCO
            coco_annotations, _ = self.format_batch_to_coco(
                batch[1], images_meta, list(range(len(batch[1])))
            )

            # Extend COCO batch predictions to JSON structure
            coco_result["annotations"].extend(coco_annotations["annotations"])
            coco_result["images"].extend(coco_annotations["images"])

            # Save in json file
            with open(Path(labels_path, filename + ".json"), "w") as jsonfile:
                json.dump(coco_result, jsonfile)
