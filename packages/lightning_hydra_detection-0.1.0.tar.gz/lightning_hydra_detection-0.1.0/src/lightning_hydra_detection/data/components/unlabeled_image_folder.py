from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

import torch
from torchvision.datasets.vision import VisionDataset
from torchvision.io import ImageReadMode, read_image
from torchvision.transforms.functional import get_image_size


@dataclass
class ImageMeta:
    """A generic image metadata class to keep information flow within dataloader transforms."""

    original_spatial_shape: tuple[int, int]
    """The original image size before pre-processing (width, height)"""
    spatial_shape: tuple[int, int]
    """The image size after pre-processing resizing (width, height)"""
    filepath: Path
    """The original image path."""


class UnlabeledImageFolder(VisionDataset):
    """A generic image dataset to load a list of images from a directory.

    Attributes:
        image_list (list[Path]): List of images path.
        ids (list[int]): List of image ids used for indexing.
    """

    def __init__(self, root: str | Path, transforms: Sequence[Callable] | None = None) -> None:
        """Initialize an `UnlabeledImageFolder`.

        Args:
            root (str): Root directory where images are downloaded to.
            transforms (Sequence[Callable] | None, optional):  A function/transform that takes in
                a PIL image and returns a transformed version (ex. ``transforms.PILToTensor``).
                Defaults to None.
        """
        super().__init__(root, transforms)

        self.image_list = [f for f in Path(root).glob("*") if f.is_file()]
        self.ids = list(range(len(self.image_list)))

    def _load_image(self, id: int) -> torch.Tensor:
        """Load an image sample from the image list.

        Args:
            id (int): Index of the image to load from the image list.

        Returns:
            torch.Tensor: The returned image.
        """
        img_path = self.image_list[id]
        img_tensor = read_image(str(img_path), ImageReadMode.RGB)

        return img_tensor, img_path

    def __getitem__(self, index: int) -> torch.Tensor:
        """Returns an image sample from the dataset.

        Args:
            index (int): Index to yield from the list of images.

        Returns:
            torch.Tensor: The returned image.
        """
        id = self.ids[index]
        image, filepath = self._load_image(id)
        original_spatial_shape = tuple(get_image_size(image))

        if self.transforms is not None:
            image = self.transforms(image)
        spatial_shape = tuple(get_image_size(image))

        image_meta = ImageMeta(original_spatial_shape, spatial_shape, filepath.resolve())

        return image, image_meta

    def __len__(self) -> int:
        """Returns the length of the dataset.

        Returns:
            int: The length of the dataset.
        """
        return len(self.ids)
