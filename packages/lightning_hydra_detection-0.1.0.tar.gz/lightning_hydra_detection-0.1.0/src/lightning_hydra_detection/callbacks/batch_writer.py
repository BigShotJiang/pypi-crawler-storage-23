from collections.abc import Sequence
from pathlib import Path
from typing import Any

import lightning.pytorch as pl
from lightning.pytorch.callbacks import Callback


class BatchWriter(Callback):
    """Lightning custom callback to write model input data.

    It called the loaded datamodule that executes its writing method.
    """

    def __init__(self, save_dir: str, writing_stages: str | Sequence = "all"):
        """Initialize the batch write callback.

        Args:
            save_dir (str): The directory to save batches.
            writing_stages (str | Sequence[str]): The stages at which to write batches. It can be a
                single string or a sequence of the following values: `"train"`, `"val"`, `"test"`,
                `"predict"` or `"all"`. Defaults to "all" stages.
        """
        self.save_dir = save_dir
        Path(self.save_dir).mkdir()

        if isinstance(writing_stages, str):
            self.writing_stages = set([writing_stages])
        elif isinstance(writing_stages, Sequence):
            self.writing_stages = set(writing_stages)
        else:
            raise TypeError(
                "Invalid type for `writing_stages` parameter",
                f"(type: {type(writing_stages)}).",
                "It should be a string or a sequence of string of `'train'`,",
                "`'val'`, `'test''`, `'predict'` or `'all'`.",
            )

        if not {"train", "val", "test", "predict", "all"} & self.writing_stages:
            raise ValueError(
                f"Invalid value for `writing_stages` parameter {writing_stages}.",
                "It should be a string or a sequence of string of `'train'`,",
                "`'val'`, `'test''`, `'predict'` or `'all'`.",
            )

    def on_train_batch_start(
        self, trainer: "pl.Trainer", pl_module: "pl.LightningModule", batch: Any, batch_idx: int
    ) -> None:
        """Call `write_batch` method of the instantiate datamodule."""
        if self.writing_stages & {"all", "train"}:
            # Create saving path
            save_path = Path(
                self.save_dir,
                f"{trainer.state.stage}",
                f"epoch_{trainer.current_epoch:03d}",
                f"batch_{batch_idx:03d}",
            )
            save_path.mkdir(parents=True)

            trainer.datamodule.write_batch(batch, batch_idx, save_path)

    def on_validation_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `write_batch` method of the instantiate datamodule."""
        if self.writing_stages & {"all", "val"}:
            # Create saving path
            save_path = Path(
                self.save_dir,
                f"{trainer.state.stage}",
                f"epoch_{trainer.current_epoch:03d}",
                f"batch_{batch_idx:03d}",
            )
            save_path.mkdir(parents=True)

            trainer.datamodule.write_batch(batch, batch_idx, save_path)

    def on_test_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `write_batch` method of the instantiate datamodule."""
        if self.writing_stages & {"all", "test"}:
            # Create saving path
            save_path = Path(
                self.save_dir,
                f"{trainer.state.stage}",
                f"epoch_{trainer.current_epoch:03d}",
                f"batch_{batch_idx:03d}",
            )
            save_path.mkdir(parents=True)

            trainer.datamodule.write_batch(batch, batch_idx, save_path)

    def on_predict_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `write_batch` method of the instantiate datamodule."""
        if self.writing_stages & {"all", "predict"}:
            # Create saving path
            save_path = Path(
                self.save_dir,
                f"{trainer.state.stage}",
                f"epoch_{trainer.current_epoch:03d}",
                f"batch_{batch_idx:03d}",
            )
            save_path.mkdir(parents=True)

            trainer.datamodule.write_batch(batch, batch_idx, save_path)
