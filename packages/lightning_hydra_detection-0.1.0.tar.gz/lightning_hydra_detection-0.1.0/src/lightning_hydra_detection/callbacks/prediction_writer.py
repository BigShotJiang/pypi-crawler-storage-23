from collections.abc import Sequence
from pathlib import Path
from typing import Any

from lightning.pytorch import LightningModule, Trainer
from lightning.pytorch.callbacks import BasePredictionWriter


class PredictionWriter(BasePredictionWriter):
    """Callback for writing and saving predictions.

    The callback uses a defined method of the datamodule `trainer.datamodule`.
    """

    _WRITE_INTERVAL = "epoch"

    def __init__(self, output_dir: str):
        """Initialize `PredictionWriter` class.

        Args:
            output_dir (str): The path were to store prediction file(s).
        """
        super().__init__(self._WRITE_INTERVAL)
        self.output_dir = Path(output_dir)

    def write_on_epoch_end(
        self,
        trainer: Trainer,
        pl_module: LightningModule,
        predictions: Sequence[Any],
        batch_indices: Sequence[Any],
    ):
        """Call datamodule method `write_predictions`.

        The datamodule method handles the writing and formatting mechanisms.
        """
        trainer.datamodule.write_predictions(self.output_dir, predictions, batch_indices)
