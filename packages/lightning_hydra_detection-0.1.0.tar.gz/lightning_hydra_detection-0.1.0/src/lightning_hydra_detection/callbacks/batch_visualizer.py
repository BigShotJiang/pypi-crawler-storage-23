from collections.abc import Sequence
from typing import Any

import lightning.pytorch as pl
from lightning.pytorch.callbacks import Callback


class BatchVisualizer(Callback):
    """Lightning custom callback to visualize model input data.

    It called the loaded datamodule that executes its visualize method.
    """

    def __init__(self, visualization_stages: str | Sequence[str] = "all"):
        """Initialize the batch visualizer callback.

        Args:
            visualization_stages (str | Sequence[str]): The stages at which to visualize batches.
                It can be a single string or a sequence of the following values: `"train"`,
                `"val"`, `"test"`, `"predict"` or `"all"`. Defaults to "all" stages.
        """
        if isinstance(visualization_stages, str):
            self.visualization_stages = set([visualization_stages])
        elif isinstance(visualization_stages, Sequence):
            self.visualization_stages = set(visualization_stages)
        else:
            raise TypeError(
                "Invalid type for `visualization_stages` parameter",
                f"(type: {type(visualization_stages)}).",
                "It should be a string or a sequence of string of `'train'`,",
                "`'val'`, `'test''`, `'predict'` or `'all'`.",
            )

        if not {"train", "val", "test", "predict", "all"} & self.visualization_stages:
            raise ValueError(
                f"Invalid value for `visualization_stages` parameter {visualization_stages}.",
                "It should be a string or a sequence of string of `'train'`,",
                "`'val'`, `'test''`, `'predict'` or `'all'`.",
            )

    def on_train_batch_start(
        self, trainer: "pl.Trainer", pl_module: "pl.LightningModule", batch: Any, batch_idx: int
    ) -> None:
        """Call `visualize_batch` method of the instantiate datamodule."""
        if self.visualization_stages & {"all", "train"}:
            trainer.datamodule.visualize_batch(batch)

    def on_validation_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `visualize_batch` method of the instantiate datamodule."""
        if self.visualization_stages & {"all", "val"}:
            trainer.datamodule.visualize_batch(batch)

    def on_test_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `visualize_batch` method of the instantiate datamodule."""
        if self.visualization_stages & {"all", "test"}:
            trainer.datamodule.visualize_batch(batch)

    def on_predict_batch_start(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `visualize_batch` method of the instantiate datamodule."""
        if self.visualization_stages & {"all", "predict"}:
            trainer.datamodule.visualize_batch(batch)
