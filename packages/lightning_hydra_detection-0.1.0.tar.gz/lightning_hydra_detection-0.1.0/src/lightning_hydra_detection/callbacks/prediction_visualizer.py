from typing import Any

import lightning.pytorch as pl
from lightning.pytorch.callbacks import Callback


class PredictionVisualizer(Callback):
    """Lightning custom callback to visualize predictions.

    It called the loaded datamodule that executes its visualize method.
    """

    def __init__(self, score_threshold: float = 0.8):
        """Initialize the prediction visualizer callback.

        Args:
            score_threshold (float): The threshold above which the boxes are drawn.
        """
        if score_threshold > 1 or score_threshold < 0:
            raise ValueError("Parameter 'score_threshold' must be between 0 and 1 (inclusive).")
        self.score_threshold = score_threshold

    def on_predict_batch_end(
        self,
        trainer: "pl.Trainer",
        pl_module: "pl.LightningModule",
        outputs: Any,
        batch: Any,
        batch_idx: int,
        dataloader_idx: int = 0,
    ) -> None:
        """Call `visualize_prediction` method of the instantiate datamodule."""
        trainer.datamodule.visualize_prediction(batch, outputs, self.score_threshold)
