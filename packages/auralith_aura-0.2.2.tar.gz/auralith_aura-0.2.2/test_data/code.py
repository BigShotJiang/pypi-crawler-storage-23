def greet(): return 'Hello from Python'
