# SPDX-License-Identifier: Apache-2.0
# AURA MEMORY OS - Three-Tier Memory with Two-Speed WAL
#
# Provides a cognitively-inspired memory architecture for AI agents:
#   /pad       - Working notepad (transient, fast writes)
#   /episodic  - Session logs (auto-archived)
#   /fact      - Immutable truths (persistent knowledge)

"""
Aura Memory OS v2.1

Three-Tier Memory Architecture:
    /pad       → Working notes, scratch space, thinking-out-loud
    /episodic  → Session transcripts, conversation history
    /fact      → Verified facts, user preferences, persistent knowledge

Two-Speed Write-Ahead Log:
    Speed 1: Instant JSONL append (~0.001s) for agent responsiveness
    Speed 2: Background compilation to .aura shards (session end / threshold)

v2.1 Performance Enhancements:
    • Temporal decay scoring — recency-boosted retrieval
    • Noise filtering — blocks meta-questions and denials from memory
    • Entry deduplication — content-hash dedup prevents redundant writes
    • Bloom filters — skip shards that can't contain query terms
    • SimHash — lightweight semantic similarity without embedding models
    • Tiered priority scoring — facts > episodic > pad in search ranking
"""

import os
import json
import math
import time
import struct
import logging
import hashlib
from pathlib import Path
from typing import Optional, List, Dict, Any, Set
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict

logger = logging.getLogger(__name__)

# Default memory root
DEFAULT_MEMORY_ROOT = Path.home() / ".aura" / "memory"

# WAL flush threshold (number of entries before background compile)
WAL_FLUSH_THRESHOLD = 100

# Shard size target (bytes) before rotation
SHARD_SIZE_TARGET = 5 * 1024 * 1024  # 5MB

# --- v2.1: Temporal Decay ---
RECENCY_HALF_LIFE_DAYS = 14   # How fast memories fade (14 days = 50% weight)
RECENCY_WEIGHT = 0.20         # Max recency boost

# --- v2.1: Tiered Priority Weights ---
TIER_WEIGHT = {
    "fact": 1.0,      # Facts always rank highest
    "episodic": 0.7,  # Session history is secondary
    "pad": 0.4,       # Scratch notes rank lowest
}

# --- v2.1: Noise Patterns ---
# Common meta-questions and denials that pollute memory search results.
# These are filtered on write (for episodic auto-recording) and on query.
NOISE_PATTERNS_WRITE = [
    "i don't have information",
    "i don't have any information",
    "it looks like i don't",
    "i'm not able to find",
    "i cannot find",
    "i don't recall",
    "i'm unable to locate",
    "no information available",
    "i don't have access to",
    "let me search for that",
    "let me look that up",
]

NOISE_PATTERNS_QUERY = [
    "do you remember",
    "can you recall",
    "did i tell you",
    "did we discuss",
    "what did we talk about",
    "do you recall",
]


# ═══════════════════════════════════════════════════════════════
#  BLOOM FILTER (Zero-dependency, ~1KB per shard)
# ═══════════════════════════════════════════════════════════════

class BloomFilter:
    """
    Lightweight bloom filter for shard-level term presence testing.
    
    Uses ~1KB of memory per filter (8192 bits).
    False positive rate: ~1% at 500 terms.
    False negative rate: 0% (guaranteed).
    
    Usage:
        bf = BloomFilter()
        bf.add("sourdough")
        bf.add("recipe")
        bf.might_contain("sourdough")  # True (definitely)
        bf.might_contain("pizza")      # False (definitely not in set)
    """
    
    __slots__ = ('bit_array', 'size', 'num_hashes')
    
    def __init__(self, size: int = 8192, num_hashes: int = 5):
        self.size = size
        self.num_hashes = num_hashes
        self.bit_array = bytearray(size // 8)
    
    def _hashes(self, item: str) -> List[int]:
        """Generate multiple hash positions using double hashing."""
        h = hashlib.md5(item.encode('utf-8')).digest()
        h1 = int.from_bytes(h[:4], 'little')
        h2 = int.from_bytes(h[4:8], 'little')
        return [(h1 + i * h2) % self.size for i in range(self.num_hashes)]
    
    def add(self, item: str):
        """Add an item to the bloom filter."""
        for pos in self._hashes(item):
            self.bit_array[pos // 8] |= (1 << (pos % 8))
    
    def might_contain(self, item: str) -> bool:
        """Check if item might be in the set. False = definitely not present."""
        for pos in self._hashes(item):
            if not (self.bit_array[pos // 8] & (1 << (pos % 8))):
                return False
        return True
    
    def add_text(self, text: str):
        """Add all words from a text string."""
        for word in text.lower().split():
            if len(word) >= 3:  # Skip very short words
                self.add(word)
    
    def might_contain_any(self, words: Set[str]) -> bool:
        """Check if the filter might contain any of the given words."""
        return any(self.might_contain(w) for w in words if len(w) >= 3)
    
    def to_bytes(self) -> bytes:
        """Serialize bloom filter to bytes for storage alongside shards."""
        return bytes(self.bit_array)
    
    @classmethod
    def from_bytes(cls, data: bytes, size: int = 8192, num_hashes: int = 5) -> 'BloomFilter':
        """Reconstruct bloom filter from stored bytes."""
        bf = cls(size=size, num_hashes=num_hashes)
        bf.bit_array = bytearray(data)
        return bf


# ═══════════════════════════════════════════════════════════════
#  SIMHASH (Lightweight semantic fingerprinting, ~64 bits/entry)
# ═══════════════════════════════════════════════════════════════

class SimHash:
    """
    SimHash — locality-sensitive hashing for approximate text similarity.
    
    Produces a 64-bit fingerprint where similar texts have similar hashes.
    Similarity is measured by Hamming distance (number of differing bits).
    
    No embedding model needed. No GPU. No external dependencies.
    RAM cost: 8 bytes per entry.
    
    This won't match "sourdough recipe" to "bread baking" (that needs
    embeddings), but it WILL match:
        - "the auth module uses JWT tokens" ↔ "auth module JWT token usage"
        - "user prefers dark mode" ↔ "dark mode is the user preference"
    
    Good enough for agent memory where slight rephrasings are common.
    """
    
    # Common English stop words to ignore
    STOP_WORDS = frozenset({
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'shall', 'can', 'to', 'of', 'in', 'for',
        'on', 'with', 'at', 'by', 'from', 'as', 'into', 'about', 'that',
        'this', 'it', 'its', 'and', 'but', 'or', 'not', 'no', 'so', 'if',
        'then', 'than', 'too', 'very', 'just', 'i', 'you', 'we', 'they',
        'he', 'she', 'me', 'my', 'your', 'our', 'them', 'what', 'which',
    })
    
    @staticmethod
    def _tokenize(text: str) -> List[str]:
        """Extract meaningful tokens, removing stop words and short terms."""
        words = text.lower().split()
        return [w for w in words if len(w) >= 3 and w not in SimHash.STOP_WORDS]
    
    @staticmethod
    def _word_hash(word: str) -> int:
        """Hash a single word to a 64-bit integer."""
        h = hashlib.md5(word.encode('utf-8')).digest()
        return int.from_bytes(h[:8], 'little')
    
    @staticmethod
    def compute(text: str) -> int:
        """
        Compute the 64-bit SimHash fingerprint for a text.
        
        Algorithm:
        1. Tokenize text into words
        2. Hash each word to 64-bit
        3. For each bit position, sum +1 (if bit=1) or -1 (if bit=0)
        4. Final hash: bit i = 1 if sum[i] > 0, else 0
        """
        tokens = SimHash._tokenize(text)
        if not tokens:
            return 0
        
        # Use n-grams (bigrams) for better semantic capture
        features = list(tokens)  # unigrams
        for i in range(len(tokens) - 1):
            features.append(tokens[i] + " " + tokens[i + 1])  # bigrams
        
        # Weighted bit accumulator (64 positions)
        v = [0] * 64
        
        for feature in features:
            h = SimHash._word_hash(feature)
            for i in range(64):
                if h & (1 << i):
                    v[i] += 1
                else:
                    v[i] -= 1
        
        # Build final hash
        fingerprint = 0
        for i in range(64):
            if v[i] > 0:
                fingerprint |= (1 << i)
        
        return fingerprint
    
    @staticmethod
    def distance(hash1: int, hash2: int) -> int:
        """Hamming distance between two SimHash fingerprints (0 = identical)."""
        xor = hash1 ^ hash2
        # Count set bits (Brian Kernighan's algorithm)
        count = 0
        while xor:
            xor &= xor - 1
            count += 1
        return count
    
    @staticmethod
    def similarity(hash1: int, hash2: int) -> float:
        """Similarity score between 0.0 (completely different) and 1.0 (identical)."""
        if hash1 == 0 and hash2 == 0:
            return 0.0
        return 1.0 - (SimHash.distance(hash1, hash2) / 64.0)


# ═══════════════════════════════════════════════════════════════
#  DEDUPLICATION
# ═══════════════════════════════════════════════════════════════

class ContentDedup:
    """
    Content deduplication using exact and near-duplicate detection.
    
    Uses a combination of:
    1. Exact hash — SHA-256 of normalized content (catches identical entries)
    2. SimHash — Catches rephrasings with >90% similarity
    
    Memory cost: ~40 bytes per tracked entry (32 byte hash + 8 byte simhash)
    """
    
    def __init__(self, similarity_threshold: float = 0.90):
        self.seen_hashes: Set[str] = set()
        self.seen_simhashes: List[int] = []
        self.threshold = similarity_threshold
    
    def _normalize(self, text: str) -> str:
        """Normalize content for comparison (lowercase, strip whitespace)."""
        return ' '.join(text.lower().split())
    
    def is_duplicate(self, content: str) -> bool:
        """Check if content is a duplicate of something already seen."""
        normalized = self._normalize(content)
        
        # Check 1: Exact duplicate
        content_hash = hashlib.sha256(normalized.encode()).hexdigest()[:16]
        if content_hash in self.seen_hashes:
            return True
        
        # Check 2: Near-duplicate via SimHash
        sh = SimHash.compute(normalized)
        if sh != 0:
            for existing_sh in self.seen_simhashes:
                if SimHash.similarity(sh, existing_sh) >= self.threshold:
                    return True
        
        return False
    
    def register(self, content: str):
        """Register content as seen (call after confirming it's not a duplicate)."""
        normalized = self._normalize(content)
        content_hash = hashlib.sha256(normalized.encode()).hexdigest()[:16]
        self.seen_hashes.add(content_hash)
        
        sh = SimHash.compute(normalized)
        if sh != 0:
            self.seen_simhashes.append(sh)
    
    def load_from_entries(self, entries: List[Dict[str, Any]]):
        """Pre-populate dedup index from existing entries."""
        for entry in entries:
            content = entry.get('content', '')
            if content:
                self.register(content)


# ═══════════════════════════════════════════════════════════════
#  DATA CLASSES
# ═══════════════════════════════════════════════════════════════

@dataclass
class MemoryEntry:
    """A single memory entry in the WAL."""
    namespace: str          # pad, episodic, fact
    content: str            # Raw text content
    timestamp: str          # ISO 8601
    source: str             # Where this came from (agent, user, system)
    session_id: str         # Session identifier
    entry_id: str           # Unique entry hash
    tags: List[str] = None  # Optional classification tags
    simhash: int = 0        # v2.1: SimHash fingerprint for fuzzy matching

    def __post_init__(self):
        self.tags = self.tags or []
        if self.simhash == 0 and self.content:
            self.simhash = SimHash.compute(self.content)


@dataclass
class ShardInfo:
    """Metadata about a compiled .aura shard."""
    shard_id: str
    namespace: str
    path: str
    created_at: str
    entry_count: int
    size_bytes: int
    session_ids: List[str]


# ═══════════════════════════════════════════════════════════════
#  TWO-SPEED WRITE-AHEAD LOG
# ═══════════════════════════════════════════════════════════════

class TwoSpeedWAL:
    """
    Two-Speed Write-Ahead Log.
    
    Speed 1 (Instant): Appends to a JSONL scratchpad (~0.001s)
    Speed 2 (Background): Compiles JSONL into .aura binary shards
    
    This ensures agents are never blocked by I/O while maintaining
    durable, queryable memory.
    """
    
    def __init__(self, memory_root: Path, namespace: str):
        self.memory_root = memory_root
        self.namespace = namespace
        self.wal_dir = memory_root / namespace / "wal"
        self.shard_dir = memory_root / namespace / "shards"
        self.bloom_dir = memory_root / namespace / "bloom"  # v2.1
        
        # Ensure directories exist
        self.wal_dir.mkdir(parents=True, exist_ok=True)
        self.shard_dir.mkdir(parents=True, exist_ok=True)
        self.bloom_dir.mkdir(parents=True, exist_ok=True)
        
        # Active WAL file
        self.wal_path = self.wal_dir / "active.jsonl"
        self._entry_count = self._count_wal_entries()
    
    def _count_wal_entries(self) -> int:
        """Count entries in active WAL."""
        if not self.wal_path.exists():
            return 0
        try:
            with open(self.wal_path, 'r', encoding='utf-8') as f:
                return sum(1 for line in f if line.strip())
        except Exception:
            return 0
    
    def append(self, entry: MemoryEntry) -> float:
        """
        Speed 1: Instant append to JSONL WAL.
        
        Returns: Time taken in seconds (should be ~0.001s)
        """
        start = time.perf_counter()
        
        entry_dict = asdict(entry)
        line = json.dumps(entry_dict, ensure_ascii=False) + "\n"
        
        with open(self.wal_path, 'a', encoding='utf-8') as f:
            f.write(line)
        
        self._entry_count += 1
        elapsed = time.perf_counter() - start
        
        logger.debug(f"WAL append: {elapsed:.4f}s ({self.namespace})")
        return elapsed
    
    @property
    def needs_flush(self) -> bool:
        """Check if WAL has enough entries to warrant compilation."""
        return self._entry_count >= WAL_FLUSH_THRESHOLD
    
    def flush_to_shard(self) -> Optional[ShardInfo]:
        """
        Speed 2: Compile WAL entries into an .aura shard.
        
        v2.1: Also builds a bloom filter alongside the shard for
        fast negative lookups during query.
        
        Called at session end or when WAL threshold is reached.
        """
        if not self.wal_path.exists() or self._entry_count == 0:
            return None
        
        # Read all WAL entries
        entries = []
        session_ids = set()
        bloom = BloomFilter()  # v2.1: Build bloom filter during compilation
        
        try:
            with open(self.wal_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            entry = json.loads(line)
                            entries.append(entry)
                            session_ids.add(entry.get('session_id', 'unknown'))
                            # v2.1: Add content words to bloom filter
                            bloom.add_text(entry.get('content', ''))
                        except json.JSONDecodeError:
                            logger.warning(f"Skipping malformed WAL entry")
        except Exception as e:
            logger.error(f"Failed to read WAL: {e}")
            return None
        
        if not entries:
            return None
        
        # Generate shard ID
        timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        content_hash = hashlib.sha256(
            json.dumps(entries, sort_keys=True).encode()
        ).hexdigest()[:8]
        shard_id = f"{self.namespace}_{timestamp}_{content_hash}"
        
        # Write compiled shard
        shard_path = self.shard_dir / f"{shard_id}.jsonl"
        
        try:
            with open(shard_path, 'w', encoding='utf-8') as f:
                for entry in entries:
                    f.write(json.dumps(entry, ensure_ascii=False) + "\n")
            
            # v2.1: Save bloom filter alongside shard
            bloom_path = self.bloom_dir / f"{shard_id}.bloom"
            bloom_path.write_bytes(bloom.to_bytes())
            
            shard_size = shard_path.stat().st_size
            
            # Clear WAL
            self.wal_path.unlink(missing_ok=True)
            self._entry_count = 0
            
            shard_info = ShardInfo(
                shard_id=shard_id,
                namespace=self.namespace,
                path=str(shard_path),
                created_at=datetime.utcnow().isoformat() + 'Z',
                entry_count=len(entries),
                size_bytes=shard_size,
                session_ids=list(session_ids)
            )
            
            logger.info(f"Compiled shard: {shard_id} ({len(entries)} entries, "
                       f"{shard_size / 1024:.1f} KB, bloom: {len(bloom.to_bytes())} B)")
            
            return shard_info
            
        except Exception as e:
            logger.error(f"Failed to compile shard: {e}")
            return None
    
    def read_wal(self) -> List[Dict[str, Any]]:
        """Read all entries from active WAL."""
        entries = []
        if not self.wal_path.exists():
            return entries
        
        try:
            with open(self.wal_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line.strip():
                        try:
                            entries.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        except Exception:
            pass
        
        return entries
    
    def load_bloom(self, shard_id: str) -> Optional[BloomFilter]:
        """
        v2.1: Load a shard's bloom filter for fast pre-screening.
        Returns None if no bloom filter exists (legacy shards).
        """
        bloom_path = self.bloom_dir / f"{shard_id}.bloom"
        if bloom_path.exists():
            try:
                data = bloom_path.read_bytes()
                return BloomFilter.from_bytes(data)
            except Exception:
                return None
        return None


# ═══════════════════════════════════════════════════════════════
#  AURA MEMORY OS — THE MAIN CLASS
# ═══════════════════════════════════════════════════════════════

class AuraMemoryOS:
    """
    Three-Tier Memory Operating System.
    
    Manages three cognitive memory tiers:
        /pad       - Working notepad, transient scratch space
        /episodic  - Session transcripts, auto-archived
        /fact      - Immutable knowledge, user preferences
    
    Each tier has its own Two-Speed WAL for instant writes
    with background compilation.
    
    v2.1 Enhancements:
        - Temporal decay: Recent memories rank higher
        - Noise filtering: Meta-questions filtered on write/query
        - Entry dedup: Prevents storing the same fact twice
        - Bloom filters: Skip irrelevant shards entirely
        - SimHash: Fuzzy matching without embedding models
        - Tiered scoring: Facts > Episodic > Pad in rankings
    """
    
    NAMESPACES = ('pad', 'episodic', 'fact')
    
    def __init__(self, memory_root: Optional[str] = None, session_id: Optional[str] = None):
        self.memory_root = Path(memory_root) if memory_root else DEFAULT_MEMORY_ROOT
        self.session_id = session_id or datetime.utcnow().strftime("session_%Y%m%d_%H%M%S")
        
        # Initialize WALs for each tier
        self.wals = {
            ns: TwoSpeedWAL(self.memory_root, ns)
            for ns in self.NAMESPACES
        }
        
        # v2.1: Initialize dedup engine per namespace
        self._dedup = {ns: ContentDedup() for ns in self.NAMESPACES}
        self._load_dedup_index()
        
        logger.info(f"AuraMemoryOS v2.1 initialized: {self.memory_root} (session: {self.session_id})")
    
    def _load_dedup_index(self):
        """Pre-populate dedup index from existing WAL entries."""
        for ns in self.NAMESPACES:
            entries = self.wals[ns].read_wal()
            if entries:
                self._dedup[ns].load_from_entries(entries)
    
    @staticmethod
    def _is_noise(content: str, patterns: List[str]) -> bool:
        """Check if content matches noise patterns."""
        content_lower = content.lower()
        return any(p in content_lower for p in patterns)
    
    def write(self, namespace: str, content: str, source: str = "agent",
              tags: Optional[List[str]] = None) -> Optional[MemoryEntry]:
        """
        Write a memory entry to the specified namespace.
        
        v2.1 Enhancements:
            - Noise filtering: Blocks meta-questions and agent denials
            - Deduplication: Skips content already stored (exact or near-match)
        
        Args:
            namespace: One of 'pad', 'episodic', 'fact'
            content: Text content to remember
            source: Origin (agent, user, system)
            tags: Optional classification tags
        
        Returns:
            The created MemoryEntry, or None if filtered/deduplicated
        """
        if namespace not in self.NAMESPACES:
            raise ValueError(f"Invalid namespace '{namespace}'. Must be one of: {self.NAMESPACES}")
        
        # v2.1: Noise filtering (skip meta-questions and denials)
        if self._is_noise(content, NOISE_PATTERNS_WRITE):
            logger.debug(f"Noise filtered (write): {content[:50]}...")
            return None
        
        # v2.1: Deduplication check
        if self._dedup[namespace].is_duplicate(content):
            logger.debug(f"Duplicate filtered: {content[:50]}...")
            return None
        
        # Generate entry ID
        entry_id = hashlib.sha256(
            f"{content}{time.time()}".encode()
        ).hexdigest()[:16]
        
        entry = MemoryEntry(
            namespace=namespace,
            content=content,
            timestamp=datetime.utcnow().isoformat() + 'Z',
            source=source,
            session_id=self.session_id,
            entry_id=entry_id,
            tags=tags,
            # simhash is auto-computed in __post_init__
        )
        
        # Speed 1: Instant WAL append
        write_time = self.wals[namespace].append(entry)
        
        # v2.1: Register in dedup index
        self._dedup[namespace].register(content)
        
        # Check if background compilation needed
        if self.wals[namespace].needs_flush:
            logger.info(f"WAL threshold reached for /{namespace}, auto-flushing...")
            self.wals[namespace].flush_to_shard()
        
        return entry
    
    def end_session(self):
        """
        End the current session, flushing all WALs to shards.
        
        This should be called when an agent session ends to ensure
        all buffered memory is durably persisted.
        """
        flushed = []
        for namespace in self.NAMESPACES:
            shard = self.wals[namespace].flush_to_shard()
            if shard:
                flushed.append(shard)
        
        if flushed:
            print(f"Session ended. Compiled {len(flushed)} memory shard(s):")
            for shard in flushed:
                print(f"   /{shard.namespace}: {shard.entry_count} entries "
                      f"({shard.size_bytes / 1024:.1f} KB)")
        else:
            print(f"Session ended. No new memories to compile.")
    
    def list_shards(self):
        """List all compiled memory shards across all tiers."""
        print(f"Aura Memory Shards ({self.memory_root})")
        print()
        
        total_size = 0
        total_shards = 0
        
        for namespace in self.NAMESPACES:
            shard_dir = self.memory_root / namespace / "shards"
            if not shard_dir.exists():
                continue
            
            shards = sorted(shard_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
            
            if shards:
                print(f"  /{namespace}:")
                for shard_path in shards:
                    stat = shard_path.stat()
                    size_kb = stat.st_size / 1024
                    modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
                    
                    # Count entries
                    try:
                        with open(shard_path, 'r', encoding='utf-8') as f:
                            entry_count = sum(1 for line in f if line.strip())
                    except Exception:
                        entry_count = '?'
                    
                    print(f"    {shard_path.stem}  |  {entry_count} entries  |  "
                          f"{size_kb:.1f} KB  |  {modified}")
                    
                    total_size += stat.st_size
                    total_shards += 1
                print()
            
            # Also show active WAL entries
            wal = self.wals[namespace]
            if wal._entry_count > 0:
                print(f"    Active WAL: {wal._entry_count} buffered entries")
                print()
        
        if total_shards == 0:
            print("  No compiled shards found. Memory is still in WAL buffers.")
        else:
            print(f"  Total: {total_shards} shard(s), {total_size / 1024:.1f} KB")
    
    def prune_shards(self, before_date: Optional[str] = None, 
                     shard_ids: Optional[List[str]] = None,
                     namespace: Optional[str] = None):
        """
        Prune memory shards by date or ID.
        
        Args:
            before_date: Delete shards older than this date (YYYY-MM-DD)
            shard_ids: Delete specific shards by ID
            namespace: Only prune within this namespace (default: all)
        """
        namespaces = [namespace] if namespace else list(self.NAMESPACES)
        deleted = 0
        freed_bytes = 0
        
        for ns in namespaces:
            shard_dir = self.memory_root / ns / "shards"
            bloom_dir = self.memory_root / ns / "bloom"
            if not shard_dir.exists():
                continue
            
            for shard_path in shard_dir.glob("*.jsonl"):
                should_delete = False
                
                if shard_ids and shard_path.stem in shard_ids:
                    should_delete = True
                
                if before_date:
                    try:
                        cutoff = datetime.strptime(before_date, "%Y-%m-%d")
                        shard_mtime = datetime.fromtimestamp(shard_path.stat().st_mtime)
                        if shard_mtime < cutoff:
                            should_delete = True
                    except ValueError:
                        print(f"Invalid date format: {before_date}. Use YYYY-MM-DD")
                        return
                
                if should_delete:
                    size = shard_path.stat().st_size
                    shard_path.unlink()
                    deleted += 1
                    freed_bytes += size
                    logger.info(f"Pruned shard: {shard_path.stem}")
                    
                    # v2.1: Also clean up bloom filter
                    bloom_path = bloom_dir / f"{shard_path.stem}.bloom"
                    if bloom_path.exists():
                        bloom_path.unlink()
        
        if deleted > 0:
            print(f"Pruned {deleted} shard(s), freed {freed_bytes / 1024:.1f} KB")
        else:
            print(f"No shards matched the pruning criteria.")
    
    def show_usage(self):
        """Show total memory storage usage."""
        print(f"Aura Memory Usage ({self.memory_root})")
        print()
        
        grand_total = 0
        
        for namespace in self.NAMESPACES:
            ns_dir = self.memory_root / namespace
            if not ns_dir.exists():
                print(f"  /{namespace}: 0 KB")
                continue
            
            total_bytes = sum(
                f.stat().st_size for f in ns_dir.rglob("*") if f.is_file()
            )
            grand_total += total_bytes
            
            # Count shards and WAL entries
            shard_dir = ns_dir / "shards"
            shard_count = len(list(shard_dir.glob("*.jsonl"))) if shard_dir.exists() else 0
            wal_entries = self.wals[namespace]._entry_count
            
            print(f"  /{namespace}: {total_bytes / 1024:.1f} KB  "
                  f"({shard_count} shard(s), {wal_entries} buffered)")
        
        print()
        print(f"  Total: {grand_total / 1024:.1f} KB ({grand_total / (1024*1024):.2f} MB)")
    
    def query(self, query_text: str, namespace: Optional[str] = None, 
              top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Enhanced keyword + fuzzy search across memory.
        
        v2.1 Scoring Formula:
            final_score = (keyword_overlap * tier_weight) + recency_boost + simhash_bonus
        
        Where:
            keyword_overlap = |query_words ∩ content_words| / |query_words|
            tier_weight     = {fact: 1.0, episodic: 0.7, pad: 0.4}
            recency_boost   = exp(-age_days / half_life) * recency_weight
            simhash_bonus   = simhash_similarity * 0.15 (if > 0.75 threshold)
        
        v2.1 Bloom Filter Optimization:
            Before scanning a shard, check its bloom filter. If the filter
            says "definitely no query terms present," skip the entire shard.
        
        Args:
            query_text: Search query
            namespace: Limit search to specific namespace (default: all)
            top_k: Number of results to return
        
        Returns:
            List of matching entries with relevance scores
        """
        namespaces = [namespace] if namespace else list(self.NAMESPACES)
        results = []
        query_lower = query_text.lower()
        query_words = set(query_lower.split())
        query_words_meaningful = {w for w in query_words if len(w) >= 3}
        
        # v2.1: Pre-compute query SimHash for fuzzy matching
        query_simhash = SimHash.compute(query_text)
        
        now = datetime.utcnow()
        
        for ns in namespaces:
            tier_weight = TIER_WEIGHT.get(ns, 0.5)
            
            # Search active WAL (always searched, no bloom filter needed)
            wal_entries = self.wals[ns].read_wal()
            for entry in wal_entries:
                score = self._score_entry(entry, query_words, query_simhash, 
                                          tier_weight, now)
                if score > 0:
                    results.append({
                        'content': entry.get('content', ''),
                        'namespace': ns,
                        'timestamp': entry.get('timestamp', ''),
                        'source': entry.get('source', ''),
                        'score': round(score, 4),
                        'location': 'wal'
                    })
            
            # Search compiled shards (with bloom filter pre-screening)
            shard_dir = self.memory_root / ns / "shards"
            if shard_dir.exists():
                shards_scanned = 0
                shards_skipped = 0
                
                for shard_path in shard_dir.glob("*.jsonl"):
                    shard_id = shard_path.stem
                    
                    # v2.1: Bloom filter pre-screening
                    bloom = self.wals[ns].load_bloom(shard_id)
                    if bloom and query_words_meaningful:
                        if not bloom.might_contain_any(query_words_meaningful):
                            shards_skipped += 1
                            continue  # Skip this shard entirely
                    
                    shards_scanned += 1
                    
                    try:
                        with open(shard_path, 'r', encoding='utf-8') as f:
                            for line in f:
                                if line.strip():
                                    try:
                                        entry = json.loads(line)
                                        score = self._score_entry(
                                            entry, query_words, query_simhash,
                                            tier_weight, now
                                        )
                                        if score > 0:
                                            results.append({
                                                'content': entry.get('content', ''),
                                                'namespace': ns,
                                                'timestamp': entry.get('timestamp', ''),
                                                'source': entry.get('source', ''),
                                                'score': round(score, 4),
                                                'location': shard_id
                                            })
                                    except json.JSONDecodeError:
                                        continue
                    except Exception:
                        continue
                
                if shards_skipped > 0:
                    logger.debug(f"Bloom filter: scanned {shards_scanned}, "
                               f"skipped {shards_skipped} shard(s) in /{ns}")
        
        # v2.1: Filter noise from results
        results = [r for r in results 
                   if not self._is_noise(r['content'], NOISE_PATTERNS_QUERY)]
        
        # Sort by score descending
        results.sort(key=lambda x: x['score'], reverse=True)
        return results[:top_k]
    
    def _score_entry(self, entry: Dict[str, Any], query_words: set,
                     query_simhash: int, tier_weight: float,
                     now: datetime) -> float:
        """
        v2.1: Compute composite relevance score for a single entry.
        
        Combines:
            1. Keyword overlap (base score)
            2. Tier weight (facts > episodic > pad)
            3. Temporal decay (recent = higher)
            4. SimHash similarity bonus (fuzzy text matching)
        """
        content = entry.get('content', '').lower()
        content_words = set(content.split())
        
        # Base: keyword overlap
        overlap = len(query_words & content_words)
        if overlap == 0:
            # No keyword match — check SimHash for fuzzy match
            entry_simhash = entry.get('simhash', 0)
            if entry_simhash and query_simhash:
                sim = SimHash.similarity(query_simhash, entry_simhash)
                if sim >= 0.80:  # High similarity threshold for simhash-only
                    # Use simhash similarity as the base score
                    keyword_score = sim * 0.5  # Lower weight since no keyword match
                else:
                    return 0.0
            else:
                return 0.0
        else:
            keyword_score = overlap / max(len(query_words), 1)
        
        # Tier weighting
        weighted_score = keyword_score * tier_weight
        
        # Temporal decay boost
        recency_boost = 0.0
        timestamp_str = entry.get('timestamp', '')
        if timestamp_str:
            try:
                entry_time = datetime.fromisoformat(timestamp_str.replace('Z', '+00:00'))
                age_days = max((now - entry_time.replace(tzinfo=None)).total_seconds() / 86400, 0)
                recency_boost = math.exp(-age_days / RECENCY_HALF_LIFE_DAYS) * RECENCY_WEIGHT
            except (ValueError, TypeError):
                pass
        
        # SimHash similarity bonus (augments keyword matches)
        simhash_bonus = 0.0
        entry_simhash = entry.get('simhash', 0)
        if entry_simhash and query_simhash and overlap > 0:
            sim = SimHash.similarity(query_simhash, entry_simhash)
            if sim >= 0.75:
                simhash_bonus = sim * 0.15
        
        return weighted_score + recency_boost + simhash_bonus
