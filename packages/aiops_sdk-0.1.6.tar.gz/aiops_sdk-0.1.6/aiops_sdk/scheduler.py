import threading
import time
from .heartbeat import send_heartbeat

_heartbeat_lock = threading.Lock()
_heartbeat_started = False


def start_heartbeat(interval=30):
    global _heartbeat_started
    with _heartbeat_lock:
        if _heartbeat_started:
            return
        _heartbeat_started = True

    def _run():
        while True:
            send_heartbeat()
            time.sleep(interval)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()
