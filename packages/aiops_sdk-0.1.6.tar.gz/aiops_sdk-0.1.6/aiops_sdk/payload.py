# aiops_sdk/payload.py

from .config import Config
from .utils import hostname, timestamp


def base_payload():
    """
    Build the base fields included in every payload sent to the platform.

    Config values fall back to meaningful strings rather than None so the
    platform always receives identifiable data even if init() was called
    with an incomplete environment (e.g. AIOPS_SERVICE_NAME not set).
    """
    return {
        "service":     Config.service_name  or "unknown-service",
        "environment": Config.environment   or "unknown",
        "host":        hostname(),
        "timestamp":   timestamp(),

        # Normalised fields always present in every payload.
        # Callers override these via payload.update({...}).
        "signal_type":   None,
        "status_code":   None,
        "request_path":  None,  # populated by Flask/HTTP integrations
    }
