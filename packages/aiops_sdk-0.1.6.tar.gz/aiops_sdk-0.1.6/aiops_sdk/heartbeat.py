from .client import send_async
from .payload import base_payload
from .config import Config

def send_heartbeat():
    payload = base_payload()
    payload.update({
        "signal_type": "heartbeat",
        # get_base_url() returns AIOPS_SERVICE_BASE_URL env var if set,
        # otherwise the URL auto-detected from the first Flask request Host header.
        # None on the very first heartbeat (before any request) — the platform
        # skips fixer registration when base_url is absent, which is fine.
        # All subsequent heartbeats carry the detected URL automatically.
        "base_url": Config.get_base_url(),
    })
    send_async("/v1/sdk/heartbeat", payload)
