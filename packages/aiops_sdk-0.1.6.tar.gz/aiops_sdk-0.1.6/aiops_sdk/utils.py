import socket
import time

def hostname():
    try:
        return socket.gethostname()
    except Exception:
        return "unknown-host"

def timestamp():
    return int(time.time())
