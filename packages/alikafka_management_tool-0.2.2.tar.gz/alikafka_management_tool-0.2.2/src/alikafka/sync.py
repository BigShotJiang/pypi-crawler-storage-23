"""
Synchronization Manager
Handles bidirectional sync between YAML and Aliyun Kafka
"""
from typing import Optional, List, Dict, Any
from dataclasses import dataclass

from rich.console import Console
from rich.table import Table

from .client import AliKafkaClient
from .config import ConfigManager
from .models import Topic, ConsumerGroup, SASLUser
from .git_helper import GitHelper

console = Console()


@dataclass
class SyncResult:
    """Result of a sync operation"""
    success: bool
    created: int = 0
    updated: int = 0
    deleted: int = 0
    acls_created: int = 0
    acls_deleted: int = 0
    errors: List[str] = None

    def __post_init__(self):
        if self.errors is None:
            self.errors = []


class SyncManager:
    """Manages synchronization between YAML config and Aliyun Kafka"""

    def __init__(self, client: AliKafkaClient, config: ConfigManager):
        """
        Initialize sync manager

        Args:
            client: AliKafkaClient instance
            config: ConfigManager instance
        """
        self.client = client
        self.config = config
        self.git_helper = GitHelper()

    # ==================== Apply: YAML -> Kafka ====================

    def apply_all(
        self,
        instance_id: str,
        dry_run: bool = False,
        topics_only: bool = False,
        groups_only: bool = False,
        users_only: bool = False,
        auto_password: bool = True
    ) -> SyncResult:
        """
        Apply all configurations from YAML to Kafka

        Args:
            instance_id: The instance ID
            dry_run: If True, show what would change without applying
            topics_only: Only sync topics
            groups_only: Only sync consumer groups
            users_only: Only sync SASL users
            auto_password: Auto-generate passwords for new SASL users

        Returns:
            SyncResult object
        """
        if dry_run:
            console.print("\n[yellow]DRY RUN MODE[/yellow] - No changes will be applied\n")

        total_result = SyncResult(success=True)

        # Apply topics first (consumer groups may depend on them)
        if not groups_only and not users_only:
            result = self.apply_topics(instance_id, dry_run)
            total_result.created += result.created
            total_result.updated += result.updated
            total_result.deleted += result.deleted
            total_result.errors.extend(result.errors)
            if not result.success:
                total_result.success = False

        # Apply consumer groups
        if not topics_only and not users_only:
            result = self.apply_consumer_groups(instance_id, dry_run)
            total_result.created += result.created
            total_result.updated += result.updated
            total_result.deleted += result.deleted
            total_result.errors.extend(result.errors)
            if not result.success:
                total_result.success = False

        # Apply SASL users
        if not topics_only and not groups_only:
            result = self.apply_sasl_users(instance_id, dry_run, auto_password)
            total_result.created += result.created
            total_result.updated += result.updated
            total_result.deleted += result.deleted
            total_result.acls_created += result.acls_created
            total_result.acls_deleted += result.acls_deleted
            total_result.errors.extend(result.errors)
            if not result.success:
                total_result.success = False

        # Show git status and suggestion
        if not dry_run and total_result.success:
            self._show_git_suggestion("apply", instance_id, {
                "topics": {"created": total_result.created if topics_only or not (groups_only or users_only) else 0},
                "consumer groups": {"created": total_result.created if groups_only or not (topics_only or users_only) else 0},
                "SASL users": {"created": total_result.created if users_only or not (topics_only or groups_only) else 0}
            })

        return total_result

    def apply_topics(self, instance_id: str, dry_run: bool = False) -> SyncResult:
        """
        Apply topics from YAML to Kafka

        Args:
            instance_id: The instance ID
            dry_run: If True, show what would change without applying

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        # Load desired state from YAML
        desired_topics = self.config.load_topics(instance_id)

        # Get current state from Kafka
        try:
            current_topics = self.client.list_topics(instance_id)
        except Exception as e:
            console.print(f"[red]Error fetching current topics:[/red] {e}")
            result.success = False
            result.errors.append(str(e))
            return result

        # Calculate diff
        current_map = {t.name: t for t in current_topics}
        desired_map = {t.name: t for t in desired_topics}

        to_create = [t for name, t in desired_map.items() if name not in current_map]

        # Check updates with validation
        to_update = []
        immutable_warnings = []

        for name, desired_topic in desired_map.items():
            if name in current_map:
                current_topic = current_map[name]

                # Track changes
                changes = []

                # Check partition_num changes
                if desired_topic.partition_num != current_topic.partition_num:
                    if desired_topic.partition_num > current_topic.partition_num:
                        # Can increase partitions
                        changes.append(f"partitions: {current_topic.partition_num} -> {desired_topic.partition_num}")
                    else:
                        # Cannot decrease partitions - this is a warning
                        immutable_warnings.append(
                            f"Topic '{name}': Cannot decrease partitions from {current_topic.partition_num} to {desired_topic.partition_num}"
                        )

                # Check remark changes
                if desired_topic.remark != current_topic.remark:
                    changes.append(f"remark updated")

                # Check immutable attributes
                if desired_topic.local_topic != current_topic.local_topic:
                    immutable_warnings.append(
                        f"Topic '{name}': Cannot modify local_topic (current: {current_topic.local_topic}, desired: {desired_topic.local_topic})"
                    )

                if desired_topic.compact_topic != current_topic.compact_topic:
                    immutable_warnings.append(
                        f"Topic '{name}': Cannot modify compact_topic (current: {current_topic.compact_topic}, desired: {desired_topic.compact_topic})"
                    )

                # Only add to update list if there are mutable changes
                if changes:
                    to_update.append((desired_topic, current_topic, changes))

        to_delete = [t for name, t in current_map.items() if name not in desired_map]

        # Show immutable attribute warnings
        if immutable_warnings:
            console.print("\n[yellow]⚠ Immutable Attribute Warnings:[/yellow]")
            for warning in immutable_warnings:
                console.print(f"  [yellow]![/yellow] {warning}")

        # Show diff
        if to_create or to_update or to_delete:
            self._print_diff_table("Topics", to_create, to_update, to_delete)

        # Apply changes
        if dry_run:
            result.created = len(to_create)
            result.updated = len(to_update)
            result.deleted = len(to_delete)
            return result

        # Create new topics
        for topic in to_create:
            try:
                if self.client.create_topic(instance_id, topic):
                    result.created += 1
            except Exception as e:
                console.print(f"[red]Error creating topic '{topic.name}':[/red] {e}")
                result.errors.append(f"Create topic '{topic.name}': {e}")

        # Update existing topics
        for desired_topic, current_topic, changes in to_update:
            try:
                # Update partition_num if increased
                if desired_topic.partition_num > current_topic.partition_num:
                    if not self.client.modify_partition_num(
                        instance_id,
                        desired_topic.name,
                        current_topic.partition_num,
                        desired_topic.partition_num
                    ):
                        result.errors.append(f"Modify partitions for '{desired_topic.name}'")

                # Update remark if changed
                if desired_topic.remark != current_topic.remark:
                    if not self.client.modify_topic_remark(
                        instance_id,
                        desired_topic.name,
                        desired_topic.remark
                    ):
                        result.errors.append(f"Modify remark for '{desired_topic.name}'")

                result.updated += 1
            except Exception as e:
                console.print(f"[red]Error updating topic '{desired_topic.name}':[/red] {e}")
                result.errors.append(f"Update topic '{desired_topic.name}': {e}")

        # Delete old topics
        for topic in to_delete:
            try:
                if self.client.delete_topic(instance_id, topic.name):
                    result.deleted += 1
            except Exception as e:
                console.print(f"[red]Error deleting topic '{topic.name}':[/red] {e}")
                result.errors.append(f"Delete topic '{topic.name}': {e}")

        return result

    def apply_consumer_groups(self, instance_id: str, dry_run: bool = False) -> SyncResult:
        """
        Apply consumer groups from YAML to Kafka

        Args:
            instance_id: The instance ID
            dry_run: If True, show what would change without applying

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        # Load desired state from YAML
        desired_groups = self.config.load_consumer_groups(instance_id)

        # Get current state from Kafka
        try:
            current_groups = self.client.list_consumer_groups(instance_id)
        except Exception as e:
            console.print(f"[red]Error fetching current consumer groups:[/red] {e}")
            result.success = False
            result.errors.append(str(e))
            return result

        # Calculate diff
        current_map = {g.group_name: g for g in current_groups}
        desired_map = {g.group_name: g for g in desired_groups}

        to_create = [g for name, g in desired_map.items() if name not in current_map]
        to_delete = [g for name, g in current_map.items() if name not in desired_map]

        # Check for immutable attribute changes (remark, tags)
        immutable_warnings = []

        for name, desired_group in desired_map.items():
            if name in current_map:
                current_group = current_map[name]

                # Check remark changes
                if desired_group.remark != current_group.remark:
                    immutable_warnings.append(
                        f"Consumer Group '{name}': Cannot modify remark (current: \"{current_group.remark}\", desired: \"{desired_group.remark}\") - use console to update"
                    )

                # Check tags changes - compare tag lists
                def tags_to_dict(tags):
                    return {tag.key: tag.value for tag in tags}

                current_tags_dict = tags_to_dict(current_group.tags or [])
                desired_tags_dict = tags_to_dict(desired_group.tags or [])

                if current_tags_dict != desired_tags_dict:
                    current_tags_str = ", ".join([f"{k}:{v}" for k, v in current_tags_dict.items()]) if current_tags_dict else "(none)"
                    desired_tags_str = ", ".join([f"{k}:{v}" for k, v in desired_tags_dict.items()]) if desired_tags_dict else "(none)"
                    immutable_warnings.append(
                        f"Consumer Group '{name}': Cannot modify tags (current: [{current_tags_str}], desired: [{desired_tags_str}]) - use console to update"
                    )

        # Show immutable attribute warnings
        if immutable_warnings:
            console.print("\n[yellow]⚠ Configuration Differences (Cannot update via API):[/yellow]")
            for warning in immutable_warnings:
                console.print(f"  [yellow]![/yellow] {warning}")

        # Show diff
        if to_create or to_delete:
            self._print_diff_table("Consumer Groups", to_create, [], to_delete)

        # Apply changes
        if dry_run:
            result.created = len(to_create)
            result.deleted = len(to_delete)
            return result

        # Create new consumer groups
        for group in to_create:
            try:
                if self.client.create_consumer_group(instance_id, group):
                    result.created += 1
            except Exception as e:
                console.print(f"[red]Error creating consumer group '{group.group_name}':[/red] {e}")
                result.errors.append(f"Create consumer group '{group.group_name}': {e}")

        # Delete old consumer groups
        for group in to_delete:
            try:
                if self.client.delete_consumer_group(instance_id, group.group_name):
                    result.deleted += 1
            except Exception as e:
                console.print(f"[red]Error deleting consumer group '{group.group_name}':[/red] {e}")
                result.errors.append(f"Delete consumer group '{group.group_name}': {e}")

        return result

    def apply_sasl_users(self, instance_id: str, dry_run: bool = False, auto_password: bool = True) -> SyncResult:
        """
        Apply SASL users and their ACL permissions from YAML to Kafka

        Args:
            instance_id: The instance ID
            dry_run: If True, show what would change without applying
            auto_password: Auto-generate passwords for new SASL users

        Returns:
            SyncResult object
        """
        from .models import ACLPermission
        from .password_helper import PasswordHelper

        result = SyncResult(success=True)

        # Load desired state from YAML
        desired_users = self.config.load_sasl_users(instance_id)

        # Get current state from Kafka
        try:
            current_users = self.client.list_sasl_users(instance_id)
        except Exception as e:
            console.print(f"[red]Error fetching current SASL users:[/red] {e}")
            result.success = False
            result.errors.append(str(e))
            return result

        # Calculate diff for users
        current_map = {u.username: u for u in current_users}
        desired_map = {u.username: u for u in desired_users}

        # New users (not in current_map)
        to_create = [u for name, u in desired_map.items() if name not in current_map]
        to_delete = [u for name, u in current_map.items() if name not in desired_map]

        # Show user diff
        if to_create or to_delete:
            self._print_diff_table("SASL Users", to_create, [], to_delete)

        # Initialize tracking variables
        successfully_created = set()  # For actual execution
        acl_disabled_warning_shown = False

        # Actual user creation/deletion (skip in dry-run mode)
        if not dry_run:
            # Delete old SASL users first
            # Note: Deleting a user automatically deletes all their ACL permissions
            for user in to_delete:
                try:
                    if self.client.delete_sasl_user(instance_id, user.username):
                        result.deleted += 1
                        console.print(f"  [red]✗[/red] Deleted user: {user.username}")
                except Exception as e:
                    console.print(f"[red]Error deleting SASL user '{user.username}':[/red] {e}")
                    result.errors.append(f"Delete SASL user '{user.username}': {e}")

            # Create new SASL users
            for user in to_create:
                try:
                    # Resolve password using PasswordHelper
                    password = PasswordHelper.get_password(
                        user.username,
                        user.password,
                        allow_prompt=not auto_password  # Disable prompt if auto_password is enabled
                    )

                    # If no password found and auto_password is enabled, generate one
                    if not password and auto_password:
                        password = PasswordHelper.generate_password()
                        # Show partial password (first 3 + last 4 chars)
                        masked = f"{password[:3]}...{password[-4:]}"
                        console.print(f"  [dim]Generated password for '{user.username}': {masked}[/dim]")

                    if not password:
                        console.print(f"[yellow]Warning:[/yellow] Skipped user '{user.username}': No password provided (use environment variable, add password field, or enable --auto-password)")
                        continue

                    # Create user with resolved password
                    if self.client.create_sasl_user(instance_id, user, password):
                        successfully_created.add(user.username)
                        result.created += 1
                        console.print(f"  [green]✓[/green] Created user: {user.username}")
                except Exception as e:
                    # Check if ACL is disabled for this instance
                    if "Acl.Disable.Error" in str(e):
                        if not acl_disabled_warning_shown:
                            console.print(f"\n[yellow]⚠ ACL function is disabled for this instance[/yellow]")
                            console.print("[dim]SASL users cannot be created until ACL is enabled in Aliyun Kafka console.[/dim]")
                            console.print("[dim]Please enable ACL functionality first, then retry.[/dim]\n")
                            acl_disabled_warning_shown = True
                        # Skip all remaining user creations if ACL is disabled
                        break
                    else:
                        console.print(f"[red]Error creating SASL user '{user.username}':[/red] {e}")
                        result.errors.append(f"Create SASL user '{user.username}': {e}")
        else:
            # Dry-run mode: count potential changes
            result.created = len(to_create)
            result.deleted = len(to_delete)

        # Apply ACL permissions for ALL desired users (both new and existing)
        # Note: Deleted users' ACLs are automatically deleted when user is deleted
        if not dry_run:
            console.print("\n[dim]Synchronizing ACL permissions...[/dim]")
        else:
            console.print("\n[dim]Checking ACL permissions...[/dim]")

        # Track if ACL is disabled for this instance
        acl_disabled = False
        acl_disabled_warning_shown = False

        # Fetch ALL ACL permissions ONCE for the entire instance
        # This is much more efficient than calling get_user_acls for each user
        try:
            all_acls_map = self.client.get_all_acl_permissions(instance_id)
        except Exception as e:
            console.print(f"[red]Error fetching ACL permissions:[/red] {e}")
            result.errors.append(f"Fetch ACL permissions: {e}")
            return result

        # First pass: collect all ACL changes for summary table
        all_acl_changes = []  # List of (action, username, acl) tuples

        for user in desired_users:
            # Skip if this is a new user that failed to create (only in actual execution)
            is_new_user = user.username in {u.username for u in to_create}
            if is_new_user and user.username not in successfully_created and not dry_run:
                # New user but creation failed - skip ACL (only in actual execution)
                continue

            # Get current ACLs for this user from the cached map
            current_acls = all_acls_map.get(user.username, [])

            # Convert to comparable format
            current_acl_set = self._acl_to_set(current_acls)
            desired_acl_set = self._acl_to_set(user.acl_permissions)

            # Calculate ACL diff
            acls_to_create = [acl for acl in user.acl_permissions
                              if self._acl_to_key(acl) not in current_acl_set]
            acls_to_delete = [acl for acl in current_acls
                              if self._acl_to_key(acl) not in desired_acl_set]

            # Collect changes for summary table
            for acl in acls_to_create:
                all_acl_changes.append(('create', user.username, acl))
            for acl in acls_to_delete:
                all_acl_changes.append(('delete', user.username, acl))

        # Show ACL summary table if there are changes
        if all_acl_changes:
            self._print_acl_diff_table(all_acl_changes)

        # Second pass: apply ACL changes (skip if ACL is disabled)
        for user in desired_users:
            # Skip if this is a new user that failed to create (only in actual execution)
            is_new_user = user.username in {u.username for u in to_create}
            if is_new_user and user.username not in successfully_created and not dry_run:
                # New user but creation failed - skip ACL (only in actual execution)
                continue

            # Skip ACL operations if ACL is disabled for this instance
            if acl_disabled:
                if not acl_disabled_warning_shown and user.acl_permissions:
                    console.print(f"\n[yellow]⚠ ACL function is disabled for this instance[/yellow]")
                    console.print("[dim]ACL permissions in YAML will be ignored. Enable ACL in Aliyun Kafka console to use ACL features.[/dim]\n")
                    acl_disabled_warning_shown = True
                continue

            # Get current ACLs for this user from the cached map (no need to re-fetch)
            current_acls = all_acls_map.get(user.username, [])

            # Convert to comparable format
            current_acl_set = self._acl_to_set(current_acls)
            desired_acl_set = self._acl_to_set(user.acl_permissions)

            # Calculate ACL diff
            acls_to_create = [acl for acl in user.acl_permissions
                              if self._acl_to_key(acl) not in current_acl_set]
            acls_to_delete = [acl for acl in current_acls
                              if self._acl_to_key(acl) not in desired_acl_set]

            # Apply ACL changes
            if not dry_run:
                for acl in acls_to_create:
                    try:
                        if self.client.create_acl(instance_id, user.username, acl):
                            result.acls_created += 1
                            console.print(f"    [green]✓[/green] Created ACL: {acl.permission_type.value}:{acl.resource}")
                    except Exception as e:
                        # Check if ACL is disabled
                        if "Acl.Disable.Error" in str(e):
                            acl_disabled = True
                            if not acl_disabled_warning_shown:
                                console.print(f"\n[yellow]⚠ ACL function is disabled for this instance[/yellow]")
                                console.print("[dim]ACL permissions in YAML will be ignored. Enable ACL in Aliyun Kafka console to use ACL features.[/dim]\n")
                                acl_disabled_warning_shown = True
                            # Stop ACL operations for this instance
                            break
                        console.print(f"    [red]Error creating ACL:[/red] {e}")
                        result.errors.append(f"Create ACL for user '{user.username}': {e}")

                # Stop processing ACL if disabled
                if acl_disabled:
                    continue

                for acl in acls_to_delete:
                    try:
                        if self.client.delete_acl(instance_id, user.username, acl):
                            result.acls_deleted += 1
                            console.print(f"    [yellow]✓[/yellow] Deleted ACL: {acl.permission_type.value}:{acl.resource}")
                    except Exception as e:
                        console.print(f"    [red]Error deleting ACL:[/red] {e}")
                        result.errors.append(f"Delete ACL for user '{user.username}': {e}")

        # Display password retrieval reminder for newly created users
        if successfully_created and auto_password and not dry_run:
            console.print("\n[bold cyan]Password Retrieval:[/bold cyan]")
            console.print("Passwords have been set and sent to Aliyun Kafka.")
            console.print("Please retrieve the passwords from:")
            console.print("  [blue]Aliyun Kafka Console → SASL Users[/blue]")
            for username in successfully_created:
                console.print(f"  [dim]• {username}[/dim]")
            console.print()  # Empty line for spacing

        return result

    # ==================== Export: Kafka -> YAML ====================

    def export_instance_metadata(self, instance_id: str) -> SyncResult:
        """
        Export instance metadata from Kafka to YAML

        Args:
            instance_id: The instance ID

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        try:
            metadata = self.client.get_instance_detail(instance_id)
            if metadata:
                self.config.save_instance_metadata(instance_id, metadata)
                console.print(f"[green]✓[/green] Exported instance metadata: {metadata.name}")

                # Add instance ID to name mapping for directory naming
                self.config.add_instance_mapping(instance_id, metadata.name)
            else:
                console.print("[yellow]Warning:[/yellow] Could not fetch instance metadata")
                result.success = False

        except Exception as e:
            console.print(f"[red]Error exporting instance metadata:[/red] {e}")
            result.success = False
            result.errors.append(str(e))

        return result

    def export_all(self, instance_id: str, force: bool = False) -> SyncResult:
        """
        Export all resources from Kafka to YAML

        Args:
            instance_id: The instance ID
            force: Overwrite existing YAML files

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        # Export instance metadata
        metadata_result = self.export_instance_metadata(instance_id)
        result.errors.extend(metadata_result.errors)
        if not metadata_result.success:
            result.success = False

        # Export topics
        topic_result = self.export_topics(instance_id)
        result.created += topic_result.created
        result.errors.extend(topic_result.errors)
        if not topic_result.success:
            result.success = False

        # Export consumer groups
        group_result = self.export_consumer_groups(instance_id)
        result.created += group_result.created
        result.errors.extend(group_result.errors)
        if not group_result.success:
            result.success = False

        # Fetch all ACL permissions before exporting SASL users
        console.print("\n[dim]Fetching ACL permissions for all users...[/dim]")
        acl_permissions_map = self.client.get_all_acl_permissions(instance_id)
        if acl_permissions_map:
            console.print(f"[green]✓[/green] Fetched ACL permissions for {len(acl_permissions_map)} users")
        else:
            console.print("[yellow]Warning:[/yellow] Could not fetch ACL permissions. Users will be exported without ACL data.")

        # Export SASL users with ACL permissions
        user_result = self.export_sasl_users(instance_id, acl_permissions_map)
        result.created += user_result.created
        result.errors.extend(user_result.errors)
        if not user_result.success:
            result.success = False

        # Export instance allowlist
        allowlist_result = self.export_instance_allowlist(instance_id)
        result.errors.extend(allowlist_result.errors)
        if not allowlist_result.success:
            result.success = False

        # Show git status and suggestion
        if result.success:
            self._show_git_suggestion("export", instance_id, {
                "topics": {"exported": topic_result.created},
                "consumer groups": {"exported": group_result.created},
                "SASL users": {"exported": user_result.created},
                "allowlist": {"exported": 1}
            })

        return result

    def export_topics(self, instance_id: str) -> SyncResult:
        """
        Export topics from Kafka to YAML

        Args:
            instance_id: The instance ID

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        try:
            topics = self.client.list_topics(instance_id)
            self.config.save_topics(instance_id, topics)
            result.created = len(topics)
            console.print(f"[green]✓[/green] Exported {len(topics)} topics")

        except Exception as e:
            console.print(f"[red]Error exporting topics:[/red] {e}")
            result.success = False
            result.errors.append(str(e))

        return result

    def export_consumer_groups(self, instance_id: str) -> SyncResult:
        """
        Export consumer groups from Kafka to YAML

        Args:
            instance_id: The instance ID

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        try:
            groups = self.client.list_consumer_groups(instance_id)
            self.config.save_consumer_groups(instance_id, groups)
            result.created = len(groups)
            console.print(f"[green]✓[/green] Exported {len(groups)} consumer groups")

        except Exception as e:
            console.print(f"[red]Error exporting consumer groups:[/red] {e}")
            result.success = False
            result.errors.append(str(e))

        return result

    def export_sasl_users(self, instance_id: str, acl_permissions_map: dict = None) -> SyncResult:
        """
        Export SASL users from Kafka to YAML

        Args:
            instance_id: The instance ID
            acl_permissions_map: Optional dict mapping username -> list of ACLPermission objects

        Returns:
            SyncResult object
        """
        result = SyncResult(success=True)

        try:
            users = self.client.describe_sasl_users(instance_id, acl_permissions_map)
            self.config.save_sasl_users(instance_id, users)
            result.created = len(users)

            # Count users with ACL permissions
            users_with_acls = sum(1 for u in users if u.acl_permissions)
            total_acls = sum(len(u.acl_permissions) for u in users)

            console.print(f"[green]✓[/green] Exported {len(users)} SASL users")
            if users_with_acls > 0:
                console.print(f"[dim]  └─ {users_with_acls} users with {total_acls} ACL permissions[/dim]")
            console.print("[dim]Note: Passwords are not exported. Use ${PASSWORD} placeholders in YAML.[/dim]")

        except Exception as e:
            console.print(f"[red]Error exporting SASL users:[/red] {e}")
            result.success = False
            result.errors.append(str(e))

        return result

    def export_instance_allowlist(self, instance_id: str) -> SyncResult:
        """
        Export instance allowlist from Kafka to YAML

        Args:
            instance_id: The instance ID

        Returns:
            SyncResult object
        """
        from .models import InstanceAllowlist, EndpointAllowlist

        result = SyncResult(success=True)

        try:
            # Get allowlist data from API
            allowlist_api_data = self.client.get_allowed_ip_list(instance_id)

            if not allowlist_api_data:
                console.print("[yellow]Warning:[/yellow] No allowlist data found for this instance")
                # Create empty allowlist
                allowlist_api_data = {'internet_list': [], 'vpc_list': []}

            # Get instance metadata for endpoint URLs
            metadata = self.client.get_instance_detail(instance_id)

            # Build allowlist object with endpoints and IPs
            allowlist = InstanceAllowlist(instance_id=instance_id)

            # Helper function to create endpoint allowlist
            def create_endpoint_allowlist(endpoint_url: str, port_range: str, description: str,
                                          allowed_ips: list, security_group_id: str = None) -> EndpointAllowlist:
                return EndpointAllowlist(
                    endpoint=endpoint_url or "",
                    port_range=port_range,
                    description=description,
                    allowed_ips=allowed_ips or [],
                    security_group_id=security_group_id
                )

            # Process VPC list (default endpoint: port 9092)
            for item in allowlist_api_data.get('vpc_list', []):
                port_range = item.get('port_range', '')
                if '9092' in port_range:
                    allowlist.vpc_default_endpoint = create_endpoint_allowlist(
                        endpoint_url=metadata.domain_endpoint if metadata else "",
                        port_range=port_range,
                        description="通过默认接入点可以在 VPC 内对实例进行访问",
                        allowed_ips=item.get('allowed_ip_list', []),
                        security_group_id=item.get('security_group_id')
                    )
                elif '9094' in port_range:
                    allowlist.vpc_sasl_endpoint = create_endpoint_allowlist(
                        endpoint_url=metadata.sasl_domain_endpoint if metadata else "",
                        port_range=port_range,
                        description="通过 SASL 接入点可以在 VPC 内对实例进行访问",
                        allowed_ips=item.get('allowed_ip_list', []),
                        security_group_id=item.get('security_group_id')
                    )

            # Process Internet list
            for item in allowlist_api_data.get('internet_list', []):
                port_range = item.get('port_range', '')
                if '9092' in port_range:
                    allowlist.internet_default_endpoint = create_endpoint_allowlist(
                        endpoint_url="",  # Internet endpoint usually not configured
                        port_range=port_range,
                        description="通过公网默认接入点可以从公网对实例进行访问",
                        allowed_ips=item.get('allowed_ip_list', []),
                        security_group_id=item.get('security_group_id')
                    )
                elif '9093' in port_range or '9094' in port_range:
                    allowlist.internet_sasl_endpoint = create_endpoint_allowlist(
                        endpoint_url="",
                        port_range=port_range,
                        description="通过公网 SASL 接入点可以从公网对实例进行访问",
                        allowed_ips=item.get('allowed_ip_list', []),
                        security_group_id=item.get('security_group_id')
                    )

            # Save to YAML
            self.config.save_instance_allowlist(instance_id, allowlist)
            console.print(f"[green]✓[/green] Exported instance allowlist")

        except Exception as e:
            console.print(f"[red]Error exporting instance allowlist:[/red] {e}")
            result.success = False
            result.errors.append(str(e))

        return result

    # ==================== Diff ====================

    def diff(self, instance_id: str) -> SyncResult:
        """
        Show differences between YAML and Kafka state

        Args:
            instance_id: The instance ID

        Returns:
            SyncResult object with diff information
        """
        console.print(f"\n[bold cyan]Diff for instance: {instance_id}[/bold cyan]\n")

        result = SyncResult(success=True)

        # Topics diff
        self.apply_topics(instance_id, dry_run=True)

        # Consumer groups diff
        self.apply_consumer_groups(instance_id, dry_run=True)

        # SASL users diff
        self.apply_sasl_users(instance_id, dry_run=True)

        return result

    # ==================== Helpers ====================

    def _print_diff_table(self, resource_type: str, to_create: List, to_update: List, to_delete: List):
        """Print a formatted diff table"""
        if not (to_create or to_update or to_delete):
            return

        console.print(f"\n[bold cyan]{resource_type} Changes:[/bold cyan]")

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Action", style="bold", width=12)
        table.add_column("Name", width=35)
        table.add_column("Details", width=100, overflow="fold")

        for item in to_create:
            name = getattr(item, "name", getattr(item, "group_name", getattr(item, "username", "Unknown")))
            # Generate details based on resource type
            details = ""
            if hasattr(item, "partition_num"):
                # Topic
                details = f"partitions: {item.partition_num}"
                # Add tags if present - show key:value format
                if hasattr(item, "tags") and item.tags:
                    tag_pairs = ", ".join([f"{tag.key}:{tag.value}" for tag in item.tags[:3]])  # Max 3 tags
                    if len(item.tags) > 3:
                        tag_pairs += f" +{len(item.tags) - 3} more"
                    details += f", tags: {tag_pairs}"
            elif hasattr(item, "remark"):
                # Consumer group
                if item.remark:
                    details = f"remark: {item.remark}"
            elif hasattr(item, "type"):
                # SASL user
                details = f"type: {item.type}"

            table.add_row("[green]+ Create[/green]", name, details)

        for item in to_update:
            # Handle update items with different tuple formats
            if isinstance(item, tuple):
                if len(item) == 3:
                    # New format: (desired_item, current_item, changes)
                    desired_item, current_item, changes = item
                    name = getattr(desired_item, "name", getattr(desired_item, "group_name", getattr(desired_item, "username", "Unknown")))
                    details = ", ".join(changes) if changes else "Configuration changed"
                    table.add_row("[yellow]~ Update[/yellow]", name, details)
                elif len(item) == 2:
                    # Legacy format: (desired_item, current_item)
                    desired_item, current_item = item
                    name = getattr(desired_item, "name", getattr(desired_item, "group_name", getattr(desired_item, "username", "Unknown")))
                    # Show specific changes
                    changes = []
                    if hasattr(desired_item, "partition_num") and desired_item.partition_num != current_item.partition_num:
                        changes.append(f"partitions: {current_item.partition_num} -> {desired_item.partition_num}")
                    if hasattr(desired_item, "remark") and desired_item.remark != current_item.remark:
                        changes.append(f"remark updated")
                    if hasattr(desired_item, "local_topic") and desired_item.local_topic != current_item.local_topic:
                        changes.append(f"local_topic: {current_item.local_topic} -> {desired_item.local_topic}")
                    if hasattr(desired_item, "compact_topic") and desired_item.compact_topic != current_item.compact_topic:
                        changes.append(f"compact_topic: {current_item.compact_topic} -> {desired_item.compact_topic}")

                    details = ", ".join(changes)
                    table.add_row("[yellow]~ Update[/yellow]", name, details)
            else:
                # Single object (not a tuple)
                name = getattr(item, "name", getattr(item, "group_name", getattr(item, "username", "Unknown")))
                table.add_row("[yellow]~ Update[/yellow]", name, "Configuration changed")

        for item in to_delete:
            name = getattr(item, "name", getattr(item, "group_name", getattr(item, "username", "Unknown")))
            table.add_row("[red]- Delete[/red]", name, "")

        console.print(table)

    def _print_acl_diff_table(self, acl_changes: List):
        """Print a formatted ACL diff table

        Args:
            acl_changes: List of tuples (action, username, acl_permission)
                       where action is 'create' or 'delete'
        """
        if not acl_changes:
            return

        console.print(f"\n[bold cyan]ACL Permissions Changes:[/bold cyan]")

        table = Table(show_header=True, header_style="bold magenta")
        table.add_column("Action", style="bold", width=12)
        table.add_column("User", width=25)
        table.add_column("Permission", width=60, overflow="fold")

        for action, username, acl in acl_changes:
            action_str = "[green]+ Add[/green]" if action == 'create' else "[red]- Remove[/red]"

            # Format permission details
            perm_str = f"{acl.permission_type.value}:{acl.resource} "
            perm_str += f"({acl.operation.value}, {acl.pattern_type.value})"

            table.add_row(action_str, username, perm_str)

        console.print(table)

    def _show_git_suggestion(self, operation: str, instance_id: str, changes: Dict[str, Dict[str, int]]):
        """Show git status and commit suggestion"""
        # Print git status
        self.git_helper.print_git_status()

        # Generate and show commit suggestion
        message = self.git_helper.suggest_commit_message(operation, instance_id, changes)
        self.git_helper.print_commit_suggestion(message)

    def _acl_to_set(self, acls: list) -> set:
        """Convert list of ACL permissions to a set of keys for comparison"""
        return {self._acl_to_key(acl) for acl in acls}

    def _acl_to_key(self, acl) -> str:
        """Convert ACL permission to a comparable key string"""
        return f"{acl.permission_type.value}:{acl.resource}:{acl.operation.value}:{acl.pattern_type.value}"
