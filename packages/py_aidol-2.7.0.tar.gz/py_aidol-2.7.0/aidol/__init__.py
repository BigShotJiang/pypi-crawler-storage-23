"""
AIdol - Asynchronous chat module for AI idol interaction
"""

__version__ = "0.1.0"

# No top-level exports - use full paths for clarity
