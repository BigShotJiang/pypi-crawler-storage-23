# Sworn

**Deterministic, fail-closed AI code governance.**

Every commit is sworn.

---

Sworn is a Python CLI that installs git pre-commit hooks, runs a configurable
gate pipeline on every commit, and produces tamper-evident evidence logs.

Cross-tool enforcement for Claude, Codex, Cursor, Copilot, and any AI coding
tool that commits through git.

**Coming soon.** This is a namespace reservation. The first release is in development.

## What Sworn Does

- Gates every commit through a deterministic, fail-closed pipeline
- Produces tamper-evident evidence logs with SHA256 hash chains
- Maps gates to compliance frameworks (CMMC, SOC 2)
- Runs locally — no cloud, no AI in the governance loop
- Works with any AI coding tool via git pre-commit hooks

## Install

```bash
pip install sworn
```

## License

Apache 2.0
