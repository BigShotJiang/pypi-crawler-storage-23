"""Sworn — Deterministic AI code governance. Every commit is sworn."""

__version__ = "0.0.1"
