"""
Unit tests for User.check_membership to verify owner and member paths
work with string project_guid (as passed from routes).
Run from repo root: python tests/test_user_check_membership.py
"""
import sys
import uuid

# Project GUID used in routes (e.g. from specialist.project_guid)
PROJECT_GUID_STR = "b28fea8c-e063-4193-a5ba-3481d40b10a1"
PROJECT_GUID_UUID = uuid.UUID(PROJECT_GUID_STR)


def test_check_membership_owner_path_string_compare():
    """Owner: owned_projects contains project; project_guid passed as string must match."""
    owned_guids = [PROJECT_GUID_UUID]
    member_project_guids = [str(g) for g in owned_guids]
    project_guid_str = str(PROJECT_GUID_STR)
    assert project_guid_str in member_project_guids, "string project_guid must match owned list (strings)"
    assert PROJECT_GUID_STR in member_project_guids


def test_check_membership_uuid_parsing_for_db():
    """UserProjects filter gets UUID; string project_guid must parse to same UUID."""
    parsed = uuid.UUID(PROJECT_GUID_STR)
    assert parsed == PROJECT_GUID_UUID


def test_check_membership_member_path_uuid_used_in_filter():
    """When querying UserProjects we pass a UUID so the DB filter matches."""
    project_guid_str = PROJECT_GUID_STR
    try:
        project_guid_for_db = uuid.UUID(project_guid_str)
    except (ValueError, TypeError, AttributeError):
        project_guid_for_db = project_guid_str
    assert project_guid_for_db == PROJECT_GUID_UUID
    assert isinstance(project_guid_for_db, uuid.UUID)


if __name__ == "__main__":
    ok = 0
    for name, fn in [
        ("owner path string compare", test_check_membership_owner_path_string_compare),
        ("uuid parsing for DB", test_check_membership_uuid_parsing_for_db),
        ("member path UUID in filter", test_check_membership_member_path_uuid_used_in_filter),
    ]:
        try:
            fn()
            print(f"OK  {name}")
            ok += 1
        except AssertionError as e:
            print(f"FAIL {name}: {e}")
    sys.exit(0 if ok == 3 else 1)
