from __future__ import annotations

import argparse
import getpass
import hashlib
import json
import os
import platform
import re
import sys
import time
import uuid
import webbrowser
from dataclasses import asdict
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlparse

from cli import __version__
from cli.api import APIClient, APIError
from cli.config import CLIConfig, DEFAULT_API_URL, load_config, save_config
from cli.lineage import (
    LINEAGE_HOOK,
    LINEAGE_HOOKS,
    _lineage_basic_auth_credentials,
    capture_event,
    install_lineage_hook,
    lineage_daemon_status,
    installed_lineage_hooks,
    is_lineage_enabled,
    pending_events_count,
    remove_lineage_hook,
    resolve_repo_root,
    run_lineage_watch_loop,
    start_lineage_daemon,
    stop_lineage_daemon,
    sync_events,
)
from cli.policy import find_local_rego_files, get_tool_cred_mappings, policy_test_rows


_USE_COLOR = False
_SPINNER_FRAMES = ("🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘")
_VERBOSITY = 0  # -1 quiet, 0 normal, 1 verbose
_COMPLETION_MARKER_START = "# >>> senselab-cli completion >>>"
_COMPLETION_MARKER_END = "# <<< senselab-cli completion <<<"
_WORKFLOW_TERMINAL_STATUSES = {"COMPLETED", "FAILED", "TERMINATED", "TIMED_OUT", "TIMEOUT"}
_LINEAGE_MODES = {"metadata-only"}
_STATUS_EMOJIS = {
    "info": "💡",
    "ok": "✅",
    "warn": "⚠️",
    "error": "❌",
}
_ENVIRONMENTS: dict[str, dict[str, str]] = {
    "prod": {
        "api_base_url": "https://prod-backend-api.app.raia.live",
        "frontend_url": "https://app.raia.live",
    },
    "dev": {
        "api_base_url": "https://dev-backend-api.app.raia.live",
        "frontend_url": "https://dev.app.raia.live",
    },
}


def _configure_ui(no_color: bool, verbose: bool, quiet: bool) -> None:
    global _USE_COLOR
    global _VERBOSITY
    _VERBOSITY = 1 if verbose else (-1 if quiet else 0)
    if no_color or os.getenv("NO_COLOR"):
        _USE_COLOR = False
        return
    if os.getenv("FORCE_COLOR"):
        _USE_COLOR = True
        return
    _USE_COLOR = bool(sys.stdout.isatty())


def _style(text: str, *, color: str | None = None, bold: bool = False) -> str:
    if not _USE_COLOR:
        return text
    colors = {
        "red": "31",
        "green": "32",
        "yellow": "33",
        "blue": "34",
        "cyan": "36",
    }
    codes: list[str] = []
    if bold:
        codes.append("1")
    if color in colors:
        codes.append(colors[color])
    if not codes:
        return text
    return f"\033[{';'.join(codes)}m{text}\033[0m"


def _print_status(
    level: str,
    message: str,
    *,
    next_step: str | None = None,
    stream: Any = sys.stdout,
) -> None:
    if _VERBOSITY < 0 and level != "error":
        return
    if _VERBOSITY == 0 and level == "info" and next_step is None:
        # Keep default output concise unless there is guidance attached.
        pass
    palette = {
        "info": ("[INFO]", "cyan"),
        "ok": ("[OK]", "green"),
        "warn": ("[WARN]", "yellow"),
        "error": ("[ERROR]", "red"),
    }
    label, color = palette.get(level, ("[INFO]", "cyan"))
    stream_is_tty = bool(getattr(stream, "isatty", lambda: False)())
    emoji = _STATUS_EMOJIS.get(level, "") if stream_is_tty else ""
    prefix = f"{emoji} " if emoji else ""
    print(f"{prefix}{_style(label, color=color, bold=True)} {message}", file=stream)
    if next_step:
        print(
            f"{_style('[NEXT]', color='blue', bold=True)} {next_step}",
            file=stream,
        )


def _print_senselab_banner(stream: Any = sys.stdout) -> None:
    lines = [
        "  ____  _____ _   _ ____  _____ _        _    ____  ",
        " / ___|| ____| \\ | / ___|| ____| |      / \\  | __ ) ",
        " \\___ \\|  _| |  \\| \\___ \\|  _| | |     / _ \\ |  _ \\ ",
        "  ___) | |___| |\\  |___) | |___| |___ / ___ \\| |_) |",
        " |____/|_____|_| \\_|____/|_____|_____/_/   \\_\\____/ ",
    ]
    for line in lines:
        print(_style(line, color="cyan", bold=True), file=stream)
    print(_style("SenseLab CLI", color="blue", bold=True), file=stream)


def _resolve_subcommand(args: argparse.Namespace) -> str | None:
    if getattr(args, "command", None) == "connectors":
        return getattr(args, "connectors_command", None) or "list"
    if getattr(args, "command", None) == "policy":
        return getattr(args, "policy_command", None)
    if getattr(args, "command", None) in {"agent", "agents", "specialists"}:
        return getattr(args, "agent_mode", None) or getattr(args, "agent_ref", None)
    if getattr(args, "command", None) == "config":
        return getattr(args, "config_command", None)
    if getattr(args, "command", None) == "lineage":
        return getattr(args, "lineage_command", None)
    return None


def _detect_shell(requested: str) -> str:
    if requested in {"bash", "zsh"}:
        return requested
    shell_path = os.getenv("SHELL", "")
    shell = shell_path.split("/")[-1].strip().lower()
    if shell in {"bash", "zsh"}:
        return shell
    return "zsh"


def _value_after_flag(argv: list[str], flag: str) -> str | None:
    for i, token in enumerate(argv):
        if token == flag and i + 1 < len(argv):
            return argv[i + 1]
    return None


def _rewrite_legacy_argv(argv: list[str]) -> list[str]:
    if not argv:
        return argv

    cmd = argv[0]
    if cmd == "specialists":
        rewritten = ["agent", "list"] + argv[1:]
        return rewritten

    if cmd == "chat":
        specialist = _value_after_flag(argv[1:], "--specialist")
        query = _value_after_flag(argv[1:], "--query")
        if specialist and query:
            rewritten = ["agent", specialist, "--chat", query]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    if cmd == "run":
        specialist = _value_after_flag(argv[1:], "--specialist")
        function = _value_after_flag(argv[1:], "--function")
        if specialist and function:
            rewritten = ["agent", specialist, "--run", function]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    if cmd == "functions":
        specialist = _value_after_flag(argv[1:], "--specialist")
        if specialist:
            rewritten = ["agent", specialist, "function"]
            project = _value_after_flag(argv[1:], "--project")
            if project:
                rewritten.extend(["--project", project])
            output = _value_after_flag(argv[1:], "--output") or _value_after_flag(argv[1:], "-o")
            if output:
                rewritten.extend(["--output", output])
            return rewritten

    if cmd == "whoami":
        rewritten = ["config", "list"] + argv[1:]
        return rewritten

    return argv


def _prompt_if_missing(
    value: str | None,
    *,
    prompt_text: str,
    example: str | None = None,
) -> str:
    if value:
        return value
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        guidance = f" Example: {example}" if example else ""
        raise APIError(f"Missing required option.{guidance}")
    suffix = f" (e.g. {example})" if example else ""
    typed = input(f"{prompt_text}{suffix}: ").strip()
    if not typed:
        raise APIError("Missing required option.")
    return typed


def _normalize_error_message_for_hash(message: str) -> str:
    normalized = message.strip().lower()
    normalized = re.sub(
        r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b",
        "<uuid>",
        normalized,
    )
    normalized = re.sub(r"\b\d+\b", "<num>", normalized)
    return normalized


def _message_hash(message: str | None) -> str | None:
    if not message:
        return None
    normalized = _normalize_error_message_for_hash(message)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _categorize_api_error(error: APIError) -> str:
    status = error.status_code
    message = error.message.lower()
    if status in (401, 403) or "not logged in" in message or "token" in message:
        return "auth"
    if status == 404:
        return "not_found"
    if status == 429:
        return "rate_limit"
    if status in (400, 422):
        return "validation"
    if status and status >= 500:
        return "server"
    if "timed out" in message or "timeout" in message:
        return "timeout"
    if "failed to reach api" in message or "connection" in message:
        return "network"
    return "api"


def _print_output(data: Any, output: str = "table") -> None:
    if output == "json":
        print(json.dumps(data, indent=2, default=str))
        return
    if isinstance(data, (dict, list)):
        print(json.dumps(data, indent=2, default=str))
        return
    print(str(data))


def _print_compact_table(
    rows: list[dict[str, Any]],
    columns: list[tuple[str, str]],
    max_widths: dict[str, int] | None = None,
) -> None:
    if not rows:
        _print_status("info", "No results found.")
        return
    keys = [k for k, _ in columns]
    headers = [h for _, h in columns]
    table_rows: list[list[str]] = []
    for row in rows:
        values = []
        for key in keys:
            val = row.get(key)
            if val is None:
                values.append("")
            elif isinstance(val, bool):
                values.append("yes" if val else "no")
            else:
                values.append(str(val))
        table_rows.append(values)

    def _truncate(text: str, width: int) -> str:
        if width <= 0:
            return ""
        if len(text) <= width:
            return text
        if width == 1:
            return "…"
        return text[: max(0, width - 1)] + "…"

    widths: list[int] = []
    for i, key in enumerate(keys):
        max_content = max(len(r[i]) for r in table_rows)
        target = max(len(headers[i]), max_content)
        if max_widths and key in max_widths:
            target = max(len(headers[i]), min(target, max_widths[key]))
        widths.append(target)

    header_line = "  ".join(
        _style(_truncate(headers[i], widths[i]).ljust(widths[i]), color="blue", bold=True)
        for i in range(len(headers))
    )
    sep_line = "  ".join("-" * widths[i] for i in range(len(headers)))
    print(header_line)
    print(sep_line)
    for row in table_rows:
        print("  ".join(_truncate(row[i], widths[i]).ljust(widths[i]) for i in range(len(headers))))


def _render_projects_table(projects: list[dict[str, Any]]) -> None:
    rows = []
    for item in projects:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "project_guid": item.get("project_guid", ""),
                "name": item.get("name", ""),
                "description": item.get("description", ""),
            }
        )
    _print_compact_table(
        rows,
        [
            ("project_guid", "PROJECT [P]"),
            ("name", "NAME"),
            ("description", "DESCRIPTION"),
        ],
        max_widths={
            "project_guid": 36,
            "name": 24,
            "description": 64,
        },
    )


def _render_specialists_table(specialists: list[dict[str, Any]]) -> None:
    def specialist_role(item: dict[str, Any]) -> str:
        direct = item.get("role_name")
        if direct:
            return str(direct)

        role = item.get("role")
        if isinstance(role, dict):
            for key in ("name", "role_name", "description"):
                value = role.get(key)
                if value:
                    return str(value)
        elif isinstance(role, str) and role.strip():
            return role.strip()

        for key in ("specialist_role", "role_info"):
            nested = item.get(key)
            if isinstance(nested, dict):
                for nested_key in ("name", "role_name", "description"):
                    value = nested.get(nested_key)
                    if value:
                        return str(value)

        return "-"

    rows = []
    for item in specialists:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "specialist_guid": item.get("specialist_guid") or item.get("id") or "",
                "name": item.get("name", ""),
                "role": specialist_role(item),
                "active": item.get("is_active"),
            }
        )
    _print_compact_table(
        rows,
        [
            ("specialist_guid", "AGENT [A]"),
            ("name", "NAME"),
            ("role", "ROLE"),
            ("active", "ACTIVE"),
        ],
        max_widths={
            "specialist_guid": 36,
            "name": 24,
            "role": 28,
            "active": 6,
        },
    )


def _render_functions_table(functions: list[dict[str, Any]]) -> None:
    rows = []
    for item in functions:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "function_guid": item.get("workflow_guid") or item.get("id") or "",
                "name": item.get("name") or item.get("workflow_name") or "",
                "description": item.get("description", ""),
            }
        )
    _print_compact_table(
        rows,
        [
            ("function_guid", "FUNCTION [F]"),
            ("name", "NAME"),
            ("description", "DESCRIPTION"),
        ],
        max_widths={
            "function_guid": 36,
            "name": 28,
            "description": 64,
        },
    )


def _render_roles_table(roles: list[dict[str, Any]]) -> None:
    rows: list[dict[str, Any]] = []
    for item in roles:
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "role_guid": str(item.get("role_guid") or ""),
                "name": str(item.get("name") or ""),
                "description": str(item.get("description") or ""),
            }
        )
    _print_compact_table(
        rows,
        [
            ("role_guid", "ROLE GUID"),
            ("name", "NAME"),
            ("description", "DESCRIPTION"),
        ],
        max_widths={
            "role_guid": 36,
            "name": 24,
            "description": 72,
        },
    )


def _render_functions_by_agent_table(rows: list[dict[str, Any]]) -> None:
    _print_compact_table(
        rows,
        [
            ("agent", "AGENT"),
            ("function", "FUNCTION"),
            ("function_id", "ID"),
        ],
        max_widths={
            "agent": 24,
            "function": 28,
            "function_id": 36,
        },
    )


def _render_policy_list_table(rows: list[dict[str, Any]]) -> None:
    _print_compact_table(
        rows,
        [
            ("policy_name", "POLICY"),
            ("phase", "PHASE"),
            ("connectors", "CONNECTORS"),
            ("is_active", "ACTIVE"),
            ("policy_guid", "ID"),
        ],
        max_widths={
            "policy_name": 30,
            "phase": 8,
            "connectors": 26,
            "is_active": 6,
            "policy_guid": 36,
        },
    )


def _render_policy_test_table(rows: list[dict[str, Any]]) -> None:
    _print_compact_table(
        rows,
        [
            ("filename", "FILE"),
            ("phase", "PHASE"),
            ("connector", "CONNECTOR"),
            ("branch", "BRANCH"),
            ("size_chars", "SIZE"),
        ],
        max_widths={
            "filename": 32,
            "phase": 8,
            "connector": 20,
            "branch": 20,
            "size_chars": 8,
        },
    )


def _format_seconds_as_hours(seconds: Any) -> str:
    try:
        raw = float(seconds or 0)
    except Exception:
        raw = 0.0
    return f"{raw / 3600:.1f}"


def _truncate(text: str, max_len: int) -> str:
    clean = " ".join((text or "").split())
    if len(clean) <= max_len:
        return clean
    return clean[: max_len - 3].rstrip() + "..."


def _render_agent_stats_dashboard(
    *,
    agent_name: str,
    totals: dict[str, Any],
    recent_activity: list[dict[str, Any]],
    functions_enabled: list[dict[str, Any]],
    tool_metrics: list[dict[str, Any]],
) -> None:
    tokens_sent = int(totals.get("total_tokens_sent") or 0)
    tokens_received = int(totals.get("total_tokens_received") or 0)
    actions_executed = int(totals.get("total_activities") or 0)
    hours_worked = _format_seconds_as_hours(totals.get("total_working_time"))

    title = f" AGENT STATS • {agent_name} "
    metrics = (
        f"Tokens Sent: {tokens_sent:,}  |  Tokens Received: {tokens_received:,}  |  "
        f"Actions: {actions_executed:,}  |  Hours Worked: {hours_worked}"
    )
    inner_width = max(len(title), len(metrics)) + 2
    print(_style(f"╔{'═' * inner_width}╗", color="blue", bold=True))
    print(_style(f"║{title.center(inner_width)}║", color="blue", bold=True))
    print(_style(f"╠{'═' * inner_width}╣", color="blue", bold=True))
    print(_style(f"║ {metrics.ljust(inner_width - 2)} ║", color="cyan", bold=True))
    print(_style(f"╚{'═' * inner_width}╝", color="blue", bold=True))
    print()

    print(_style("Recent Activity", color="blue", bold=True))
    activity_rows: list[dict[str, Any]] = []
    for item in recent_activity[:10]:
        if not isinstance(item, dict):
            continue
        activity_rows.append(
            {
                "time": str(item.get("created_at") or ""),
                "status": str(item.get("status") or ""),
                "prompt": _truncate(str(item.get("prompt") or ""), 64),
            }
        )
    _print_compact_table(
        activity_rows,
        [
            ("time", "TIME"),
            ("status", "STATUS"),
            ("prompt", "ACTIVITY"),
        ],
    )
    print()

    print(_style("Functions Enabled", color="blue", bold=True))
    function_rows = []
    for item in functions_enabled:
        if not isinstance(item, dict):
            continue
        function_rows.append(
            {
                "function_name": _function_name(item) or "",
                "function_id": _function_guid(item) or "",
            }
        )
    _print_compact_table(
        function_rows,
        [
            ("function_name", "FUNCTION"),
            ("function_id", "ID"),
        ],
    )
    print()

    print(_style("Used Tools", color="blue", bold=True))
    tool_rows: list[dict[str, Any]] = []
    for item in tool_metrics:
        if not isinstance(item, dict):
            continue
        tool_rows.append(
            {
                "tool": str(item.get("plugin") or item.get("tool_cred_name") or ""),
                "actions": int(item.get("execution_count") or 0),
                "tokens": int(item.get("total_tokens_sent") or 0)
                + int(item.get("total_tokens_received") or 0),
                "hours": _format_seconds_as_hours(item.get("total_working_time")),
            }
        )
    _print_compact_table(
        tool_rows,
        [
            ("tool", "TOOL"),
            ("actions", "ACTIONS"),
            ("tokens", "TOKENS"),
            ("hours", "HOURS"),
        ],
    )


def _role_functions_rows(roles: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for role in roles:
        if not isinstance(role, dict):
            continue
        role_name = str(role.get("name") or role.get("role_guid") or "").strip()
        prompts = role.get("workflow_prompts") or []
        if not isinstance(prompts, list) or not prompts:
            rows.append(
                {
                    "role": role_name,
                    "function_name": "",
                    "function_id": "",
                }
            )
            continue
        for idx, prompt in enumerate(prompts):
            if not isinstance(prompt, dict):
                continue
            rows.append(
                {
                    "role": role_name if idx == 0 else "",
                    "function_name": str(prompt.get("name") or "").strip(),
                    "function_id": str(prompt.get("id") or "").strip(),
                }
            )
    return rows


def _render_role_functions_table(roles: list[dict[str, Any]]) -> None:
    _print_compact_table(
        _role_functions_rows(roles),
        [
            ("role", "ROLE"),
            ("function_name", "FUNCTION"),
            ("function_id", "FUNCTION ID"),
        ],
        max_widths={
            "role": 24,
            "function_name": 30,
            "function_id": 36,
        },
    )


def _connector_type(item: dict[str, Any]) -> str:
    connector_url = str(item.get("connector_url", "")).strip("/")
    parts = connector_url.split("/")
    if not parts:
        return str(item.get("name", "")).lower().replace(" ", "_")
    # /api/connectors/<type>/...
    if len(parts) >= 3 and parts[1] == "connectors":
        return parts[2]
    # /api/github/connect/..., /api/jira/connect/...
    if len(parts) >= 2 and parts[1] not in {"connectors"}:
        return parts[1]
    return str(item.get("name", "")).lower().replace(" ", "_")


def _connector_required_fields(item: dict[str, Any]) -> list[str]:
    required: list[str] = []
    form = item.get("form", [])
    for field in form:
        if not isinstance(field, dict):
            continue
        field_type = field.get("type")
        field_name = field.get("name")
        if field_type == "params":
            for nested in field.get("fields", []):
                if not isinstance(nested, dict):
                    continue
                nested_type = nested.get("type")
                if nested_type in {"hidden"}:
                    continue
                if nested.get("required", True):
                    required.append(str(nested.get("name")))
        elif field_type not in {"default"} and field_name:
            if field.get("required", True):
                required.append(str(field_name))
    deduped = []
    seen = set()
    for value in required:
        if value in seen:
            continue
        seen.add(value)
        deduped.append(value)
    return deduped


def _connector_agent_definition_example(item: dict[str, Any]) -> str:
    connector_type = _connector_type(item)
    if connector_type == "aws":
        return (
            "connectors:\n"
            "  - connector: \"connector name\"\n"
            "    type: \"aws\"\n"
            "    config:\n"
            "      region: \"region name\"\n"
            "      services:\n"
            "        - \"service 1\"\n"
            "        - \"service 2\""
        )
    if connector_type == "gcp":
        return (
            "connectors:\n"
            "  - connector: \"connector name\"\n"
            "    type: \"gcp\"\n"
            "    config:\n"
            "      region: \"region name\"\n"
            "      services:\n"
            "        - \"service 1\"\n"
            "        - \"service 2\""
        )
    if connector_type == "github":
        return (
            "connectors:\n"
            "  - connector: \"connector name\"\n"
            "    type: \"github\"\n"
            "    config:\n"
            "      repos:\n"
            "        - \"owner/repo\""
        )
    if connector_type == "gitlab":
        return (
            "connectors:\n"
            "  - connector: \"connector name\"\n"
            "    type: \"gitlab\"\n"
            "    config:\n"
            "      repos:\n"
            "        - \"group/project\""
        )
    return (
        "connectors:\n"
        "  - connector: \"connector name\"\n"
        f"    type: \"{connector_type}\"\n"
        "    config:\n"
        f"      plugin: \"{item.get('name') or 'Plugin Name'}\"\n"
        "      context: \"what this connector should be used for\""
    )


def _connector_summary_rows(connectors: list[dict[str, Any]]) -> list[dict[str, Any]]:
    summarized = []
    for item in connectors:
        if not isinstance(item, dict):
            continue
        summarized.append(
            {
                "name": item.get("name"),
                "type": _connector_type(item),
            }
        )
    summarized.sort(key=lambda x: str(x.get("name", "")).lower())
    return summarized


def _connector_instance_plugin(instance: dict[str, Any]) -> str:
    return str(instance.get("plugin") or instance.get("connection_type") or "").strip()


def _connector_instance_rows_for_show(
    instances: list[dict[str, Any]],
    connector_ref: str,
) -> list[dict[str, Any]]:
    ref = connector_ref.strip().casefold()
    rows: list[dict[str, Any]] = []
    for item in instances:
        if not isinstance(item, dict):
            continue
        plugin = _connector_instance_plugin(item)
        if not plugin:
            continue
        if plugin.casefold() != ref:
            continue
        rows.append(
            {
                "name": item.get("connection_name") or "",
                "default": "yes" if item.get("default") else "no",
                "id": str(item.get("id") or ""),
            }
        )
    rows.sort(key=lambda row: (row.get("default") != "yes", str(row.get("name", "")).casefold()))
    return rows


def _resolve_connector_reference(
    connectors: list[dict[str, Any]],
    connector_ref: str,
) -> dict[str, Any]:
    ref = connector_ref.strip()
    by_type: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    for item in connectors:
        if not isinstance(item, dict):
            continue
        ctype = _connector_type(item)
        name = str(item.get("name", "")).strip()
        if ctype.casefold() == ref.casefold():
            by_type.append(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)
    matches = by_type or by_name
    if not matches:
        raise APIError(
            f"Connector '{ref}' was not found.",
            suggestion="Run `sense-cli connectors list` to see available connectors.",
        )
    return matches[0]


def _normalize_chat_answer(answer: str) -> str:
    normalized = answer
    if "\\n" in normalized and "\n" not in normalized:
        normalized = normalized.replace("\\n", "\n")
    return normalized


def _render_answer_with_styles(answer: str) -> None:
    for raw_line in answer.splitlines():
        line = raw_line.rstrip()
        if line.startswith("### "):
            print(_style(f"[SECTION] {line[4:]}", color="cyan", bold=True))
            continue
        if line.startswith("## "):
            print(_style(f"[TOPIC] {line[3:]}", color="blue", bold=True))
            continue
        if line.startswith("# "):
            print(_style(f"[TITLE] {line[2:]}", color="blue", bold=True))
            continue
        if re.match(r"^\d+\.\s", line):
            print(_style(line, color="green", bold=True))
            continue
        if line.lstrip().startswith("- "):
            print(_style(line, color="yellow"))
            continue
        print(line)


def _render_chat_response(
    result: dict[str, Any],
    *,
    output: str,
    source_label: str,
) -> None:
    if output == "json":
        _print_output(result, output)
        return

    answer = _normalize_chat_answer(str(result.get("answer", ""))).strip()
    if answer:
        print(_style(f"=== AGENT: {source_label} ===", color="blue", bold=True))
        _render_answer_with_styles(answer)
    else:
        _print_output(result, output)
        return


def _specialist_guid(item: dict[str, Any]) -> str | None:
    guid = item.get("specialist_guid") or item.get("id")
    return str(guid) if guid else None


def _specialist_name(item: dict[str, Any]) -> str:
    name = item.get("name")
    return str(name).strip() if name else ""


def _resolve_specialist_reference(
    api: APIClient,
    *,
    project_guid: str,
    specialist_ref: str,
) -> tuple[str, str]:
    specialists = api.get_specialists(project_guid)
    ref = specialist_ref.strip()

    by_guid = []
    by_name = []
    for specialist in specialists:
        if not isinstance(specialist, dict):
            continue
        guid = _specialist_guid(specialist)
        if guid and guid == ref:
            by_guid.append(specialist)
            continue

        name = _specialist_name(specialist)
        if not name:
            continue
        if name.casefold() == ref.casefold():
            by_name.append(specialist)

    if by_guid:
        resolved = by_guid[0]
        return _specialist_guid(resolved) or ref, _specialist_name(resolved) or ref

    if len(by_name) == 1:
        resolved = by_name[0]
        return _specialist_guid(resolved) or ref, _specialist_name(resolved) or ref

    if len(by_name) > 1:
        options = ", ".join(
            [
                f"{_specialist_name(item)} ({_specialist_guid(item)})"
                for item in by_name[:5]
                if _specialist_guid(item)
            ]
        )
        raise APIError(
            f"More than one specialist matches '{ref}'.",
            suggestion=f"Use the specialist ID instead. Matches: {options}",
        )

    raise APIError(
        "This agent does not exist in your project.",
        suggestion="Run `sense-cli agents` to list valid agents.",
    )


def _function_guid(item: dict[str, Any]) -> str | None:
    guid = item.get("workflow_guid") or item.get("id")
    return str(guid) if guid else None


def _function_name(item: dict[str, Any]) -> str:
    name = item.get("name") or item.get("workflow_name")
    return str(name).strip() if name else ""


def _resolve_function_reference(
    api: APIClient,
    *,
    project_guid: str,
    specialist_guid: str,
    function_ref: str,
) -> tuple[str, str]:
    functions = api.get_functions(project_guid, specialist_guid)
    ref = function_ref.strip()
    by_guid: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    for item in functions:
        if not isinstance(item, dict):
            continue
        guid = _function_guid(item)
        if guid and guid == ref:
            by_guid.append(item)
            continue
        name = _function_name(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)

    if by_guid:
        chosen = by_guid[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) == 1:
        chosen = by_name[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) > 1:
        options = ", ".join(
            [
                f"{_function_name(item)} ({_function_guid(item)})"
                for item in by_name[:5]
                if _function_guid(item)
            ]
        )
        raise APIError(
            f"More than one function matches '{ref}'.",
            suggestion=f"Use the function ID instead. Matches: {options}",
        )
    raise APIError(
        "This function does not exist for the selected agent.",
        suggestion="Run `sense-cli agent <agent> function list` to list valid function IDs.",
    )


def _find_specialist(
    api: APIClient, *, project_guid: str, specialist_guid: str
) -> dict[str, Any] | None:
    specialists = api.get_specialists(project_guid)
    for item in specialists:
        if not isinstance(item, dict):
            continue
        if _specialist_guid(item) == specialist_guid:
            return item
    return None


def _role_workflow_prompts(specialist: dict[str, Any] | None) -> list[dict[str, Any]]:
    if not specialist:
        return []
    role = specialist.get("role")
    if not isinstance(role, dict):
        return []
    prompts = role.get("workflow_prompts")
    if not isinstance(prompts, list):
        return []
    normalized: list[dict[str, Any]] = []
    for item in prompts:
        if not isinstance(item, dict):
            continue
        prompt_id = item.get("id")
        name = item.get("name")
        prompt = item.get("prompt")
        if not prompt_id or not name:
            continue
        normalized.append(
            {
                "id": str(prompt_id),
                "name": str(name).strip(),
                "prompt": str(prompt or ""),
            }
        )
    return normalized


def _function_catalog_rows(
    specialist: dict[str, Any] | None,
    enabled_functions: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    prompts = _role_workflow_prompts(specialist)
    by_prompt_id: dict[str, dict[str, Any]] = {}
    extras: list[dict[str, Any]] = []

    for item in enabled_functions:
        if not isinstance(item, dict):
            continue
        prompt_id = item.get("prompt_id")
        row = {
            "name": _function_name(item) or str(prompt_id or "custom"),
            "prompt_id": str(prompt_id) if prompt_id else "",
            "enabled": "yes",
            "workflow_id": _function_guid(item) or "",
        }
        if row["prompt_id"]:
            by_prompt_id[row["prompt_id"]] = row
        else:
            extras.append(row)

    rows: list[dict[str, Any]] = []
    for prompt in prompts:
        enabled_row = by_prompt_id.get(prompt["id"])
        rows.append(
            {
                "name": prompt["name"],
                "prompt_id": prompt["id"],
                "enabled": "yes" if enabled_row else "no",
                "workflow_id": enabled_row["workflow_id"] if enabled_row else "",
            }
        )

    seen = {f"{row['name']}::{row['workflow_id']}" for row in rows}
    for row in extras:
        key = f"{row['name']}::{row['workflow_id']}"
        if key in seen:
            continue
        rows.append(row)
        seen.add(key)

    return rows


def _resolve_role_prompt_reference(
    specialist: dict[str, Any] | None, ref: str
) -> dict[str, Any]:
    prompts = _role_workflow_prompts(specialist)
    typed = ref.strip()
    if not typed:
        raise APIError("Function reference cannot be empty.")

    by_id = [item for item in prompts if item["id"] == typed]
    if by_id:
        return by_id[0]

    by_name = [item for item in prompts if item["name"].casefold() == typed.casefold()]
    if len(by_name) == 1:
        return by_name[0]
    if len(by_name) > 1:
        options = ", ".join([f"{item['name']} ({item['id']})" for item in by_name[:5]])
        raise APIError(
            f"More than one role function matches '{typed}'.",
            suggestion=f"Use function ID instead. Matches: {options}",
        )

    raise APIError(
        "This role function is not available for the selected agent.",
        suggestion="Run `sense-cli agent <agent> function list` to view available role functions.",
    )


def _resolve_enable_prompt_reference(
    *,
    specialist: dict[str, Any] | None,
    enabled_functions: list[dict[str, Any]],
    function_ref: str,
) -> dict[str, Any]:
    typed = function_ref.strip()
    if not typed:
        raise APIError("Function reference cannot be empty.")

    prompts = _role_workflow_prompts(specialist)
    by_prompt_id = [item for item in prompts if item["id"] == typed]
    if by_prompt_id:
        return by_prompt_id[0]

    by_prompt_name = [item for item in prompts if item["name"].casefold() == typed.casefold()]
    if len(by_prompt_name) == 1:
        return by_prompt_name[0]
    if len(by_prompt_name) > 1:
        options = ", ".join([f"{item['name']} ({item['id']})" for item in by_prompt_name[:5]])
        raise APIError(
            f"More than one role function matches '{typed}'.",
            suggestion=f"Use function ID instead. Matches: {options}",
        )

    # Also accept enabled workflow names/IDs and map back to role prompt IDs.
    by_workflow_guid = []
    by_workflow_name = []
    for item in enabled_functions:
        if not isinstance(item, dict):
            continue
        guid = _function_guid(item)
        if guid and guid == typed:
            by_workflow_guid.append(item)
            continue
        name = _function_name(item)
        if name and name.casefold() == typed.casefold():
            by_workflow_name.append(item)

    candidate = None
    if by_workflow_guid:
        candidate = by_workflow_guid[0]
    elif len(by_workflow_name) == 1:
        candidate = by_workflow_name[0]
    elif len(by_workflow_name) > 1:
        options = ", ".join(
            [
                f"{_function_name(item)} ({_function_guid(item)})"
                for item in by_workflow_name[:5]
                if _function_guid(item)
            ]
        )
        raise APIError(
            f"More than one enabled workflow matches '{typed}'.",
            suggestion=f"Use function ID instead. Matches: {options}",
        )

    if isinstance(candidate, dict):
        prompt_id = candidate.get("prompt_id")
        if prompt_id:
            for prompt in prompts:
                if prompt["id"] == str(prompt_id):
                    return prompt

    raise APIError(
        "This role function is not available for the selected agent.",
        suggestion="Run `sense-cli agent <agent> function list` to view available function names and IDs.",
    )


def _resolve_agent_run_target(
    *,
    specialist: dict[str, Any] | None,
    enabled_functions: list[dict[str, Any]],
    function_ref: str,
) -> tuple[str, str]:
    ref = function_ref.strip()
    if not ref:
        raise APIError("Function reference cannot be empty.")

    by_guid: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    by_prompt_id: list[dict[str, Any]] = []
    enabled_by_prompt_id: dict[str, dict[str, Any]] = {}
    for item in enabled_functions:
        if not isinstance(item, dict):
            continue
        guid = _function_guid(item)
        if guid and guid == ref:
            by_guid.append(item)
            continue

        name = _function_name(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)
            continue

        prompt_id = item.get("prompt_id")
        if prompt_id and str(prompt_id) == ref:
            by_prompt_id.append(item)
        if prompt_id:
            enabled_by_prompt_id[str(prompt_id)] = item

    if by_guid:
        chosen = by_guid[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_prompt_id) == 1:
        chosen = by_prompt_id[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) == 1:
        chosen = by_name[0]
        return _function_guid(chosen) or ref, _function_name(chosen) or ref
    if len(by_name) > 1:
        options = ", ".join(
            [
                f"{_function_name(item)} ({_function_guid(item)})"
                for item in by_name[:5]
                if _function_guid(item)
            ]
        )
        raise APIError(
            f"More than one function matches '{ref}'.",
            suggestion=f"Use the function ID instead. Matches: {options}",
        )

    prompt_match = None
    try:
        prompt_match = _resolve_role_prompt_reference(specialist, ref)
    except APIError:
        prompt_match = None

    if prompt_match:
        enabled_match = enabled_by_prompt_id.get(prompt_match["id"])
        if enabled_match:
            return (
                _function_guid(enabled_match) or prompt_match["id"],
                _function_name(enabled_match) or prompt_match["name"],
            )
        raise APIError(
            "This function is available for the agent role but is not enabled yet.",
            suggestion=(
                f"Run `sense-cli agent <agent> function --enable \"{prompt_match['name']}\"` first, "
                "then retry."
            ),
        )

    raise APIError(
        "This function does not exist for the selected agent.",
        suggestion="Run `sense-cli agent <agent> function list` to list valid function IDs.",
    )


def _resolve_disable_workflow_target(
    *,
    specialist: dict[str, Any] | None,
    enabled_functions: list[dict[str, Any]],
    function_ref: str,
) -> tuple[str, str]:
    ref = function_ref.strip()
    if not ref:
        raise APIError("Function reference cannot be empty.")

    by_guid: list[dict[str, Any]] = []
    by_name: list[dict[str, Any]] = []
    by_prompt_id: list[dict[str, Any]] = []
    for item in enabled_functions:
        if not isinstance(item, dict):
            continue
        guid = _function_guid(item)
        if guid and guid == ref:
            by_guid.append(item)
            continue
        name = _function_name(item)
        if name and name.casefold() == ref.casefold():
            by_name.append(item)
            continue
        prompt_id = item.get("prompt_id")
        if prompt_id and str(prompt_id) == ref:
            by_prompt_id.append(item)

    chosen: dict[str, Any] | None = None
    if by_guid:
        chosen = by_guid[0]
    elif len(by_prompt_id) == 1:
        chosen = by_prompt_id[0]
    elif len(by_name) == 1:
        chosen = by_name[0]
    elif len(by_name) > 1:
        options = ", ".join(
            [
                f"{_function_name(item)} ({_function_guid(item)})"
                for item in by_name[:5]
                if _function_guid(item)
            ]
        )
        raise APIError(
            f"More than one enabled function matches '{ref}'.",
            suggestion=f"Use the function ID instead. Matches: {options}",
        )

    if chosen:
        return _function_guid(chosen) or ref, _function_name(chosen) or ref

    try:
        prompt = _resolve_role_prompt_reference(specialist, ref)
    except APIError:
        prompt = None
    if prompt:
        raise APIError(
            f"Function '{prompt['name']}' is not enabled for this agent.",
            suggestion=f"Run `sense-cli agent <agent> function --enable \"{prompt['name']}\"` first.",
        )

    raise APIError(
        "This function does not exist for the selected agent.",
        suggestion="Run `sense-cli agent <agent> function list` to list valid functions.",
    )


def _set_default_project_if_single(config: CLIConfig, api: APIClient) -> None:
    try:
        projects = api.get_projects()
    except Exception:
        return
    if len(projects) != 1:
        return
    only_guid = projects[0].get("project_guid")
    if not only_guid:
        return
    if config.default_project_guid != str(only_guid):
        config.default_project_guid = str(only_guid)
        save_config(config)


def _resolve_project_guid(
    explicit_project: str | None, config: CLIConfig, required: bool = True
) -> str | None:
    project_guid = explicit_project or config.default_project_guid
    if required and not project_guid:
        if config.token:
            try:
                api = _build_api(config)
                _set_default_project_if_single(config, api)
                project_guid = config.default_project_guid
            except Exception:
                pass
        if sys.stdin.isatty() and sys.stdout.isatty():
            project_guid = input(
                "Project GUID (e.g. 48c14bb7-6122-4773-9676-4840b95f631b): "
            ).strip()
        if not project_guid:
            raise APIError(
                "No default project configured.",
                suggestion="Run `sense-cli login` or provide --project <guid>.",
            )
    return project_guid


def _build_api(config: CLIConfig) -> APIClient:
    return APIClient(base_url=config.base_url, token=config.token)


def _derive_frontend_url(base_url: str) -> str:
    parsed = urlparse(base_url)
    host = parsed.netloc
    host_no_port = host.split(":", 1)[0].lower()

    # Default production mapping: api.example.com -> app.example.com
    if host_no_port.startswith("api."):
        host = "app." + host_no_port[len("api.") :]
    # SenseLab backend hostnames used in dev/prod deployments.
    elif host_no_port in {"backend-api.app.raia.live", "prod-backend-api.app.raia.live"}:
        host = "app.raia.live"
    else:
        match = re.match(r"^([a-z0-9-]+)-backend-api\.app\.raia\.live$", host_no_port)
        if match:
            env_prefix = match.group(1)
            host = "app.raia.live" if env_prefix == "prod" else f"{env_prefix}.app.raia.live"
    scheme = parsed.scheme or "https"
    return f"{scheme}://{host}"


def _apply_env_override(config: CLIConfig, env_name: str | None) -> None:
    if not env_name:
        return
    env_cfg = _ENVIRONMENTS.get(env_name)
    if not env_cfg:
        return
    config.base_url = env_cfg["api_base_url"]
    config.frontend_url = env_cfg["frontend_url"]


def _build_connect_url(config: CLIConfig, explicit_url: str | None, flow: str) -> str:
    if explicit_url:
        return explicit_url
    base = config.frontend_url or _derive_frontend_url(config.base_url)
    return f"{base.rstrip('/')}"


class _CallbackHandler(BaseHTTPRequestHandler):
    token: str | None = None
    state: str | None = None
    error: str | None = None

    def do_GET(self):  # noqa: N802
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        _CallbackHandler.token = params.get("token", [None])[0]
        _CallbackHandler.state = params.get("state", [None])[0]
        _CallbackHandler.error = params.get("error", [None])[0]
        self.send_response(200)
        self.send_header("Content-type", "text/html")
        self.end_headers()
        if _CallbackHandler.error:
            self.wfile.write(_callback_page_html(success=False))
            return
        self.wfile.write(_callback_page_html(success=True))

    def log_message(self, format: str, *args):  # noqa: A003
        return


def _callback_page_html(*, success: bool) -> bytes:
    title = "SenseLab CLI Connected" if success else "SenseLab CLI Connection Failed"
    subtitle = (
        "Authentication completed successfully. You can close this tab and return to the terminal."
        if success
        else "Authentication could not be completed. Return to the terminal and retry login."
    )
    status_label = "Connected" if success else "Failed"
    status_color = "#22d3ee" if success else "#fb7185"
    border_color = "#06b6d4" if success else "#f43f5e"
    html = f"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>{title}</title>
  <style>
    :root {{
      color-scheme: dark;
      --bg: #020617;
      --panel: #0b1220;
      --text: #e2e8f0;
      --muted: #94a3b8;
      --accent: {status_color};
      --border: {border_color};
    }}
    body {{
      margin: 0;
      min-height: 100vh;
      display: grid;
      place-items: center;
      background:
        radial-gradient(1200px 500px at 10% -10%, rgba(34, 211, 238, 0.14), transparent 60%),
        radial-gradient(900px 400px at 90% 110%, rgba(34, 211, 238, 0.10), transparent 55%),
        var(--bg);
      color: var(--text);
      font-family: Inter, ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif;
      padding: 24px;
      box-sizing: border-box;
    }}
    .card {{
      width: min(580px, 92vw);
      border-radius: 16px;
      border: 1px solid rgba(148, 163, 184, 0.18);
      border-left: 4px solid var(--border);
      background: linear-gradient(180deg, rgba(11, 18, 32, 0.96), rgba(11, 18, 32, 0.92));
      box-shadow: 0 20px 50px rgba(2, 6, 23, 0.55);
      padding: 26px 24px;
    }}
    .brand {{
      display: inline-block;
      font-size: 12px;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--accent);
      font-weight: 700;
      margin-bottom: 8px;
    }}
    h1 {{
      margin: 0 0 10px;
      font-size: 24px;
      line-height: 1.25;
      font-weight: 700;
    }}
    p {{
      margin: 0 0 14px;
      color: var(--muted);
      line-height: 1.5;
      font-size: 15px;
    }}
    .status {{
      margin-top: 8px;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: var(--accent);
      font-weight: 700;
      font-size: 14px;
      border: 1px solid rgba(148, 163, 184, 0.2);
      border-radius: 999px;
      padding: 6px 11px;
    }}
    .dot {{
      width: 9px;
      height: 9px;
      border-radius: 50%;
      background: var(--accent);
      box-shadow: 0 0 10px var(--accent);
    }}
  </style>
</head>
<body>
  <main class="card">
    <span class="brand">SenseLab</span>
    <h1>{title}</h1>
    <p>{subtitle}</p>
    <div class="status"><span class="dot"></span>{status_label}</div>
  </main>
</body>
</html>"""
    return html.encode("utf-8")


def _maybe_set_default_project(config: CLIConfig, api: APIClient) -> None:
    _set_default_project_if_single(config, api)


def _run_browser_auth_flow(
    config: CLIConfig,
    *,
    connect_url: str,
    flow: str,
    callback_mode: str,
    port: int,
    timeout: int,
) -> int:
    state = str(uuid.uuid4())
    callback_url = f"http://127.0.0.1:{port}/callback"
    if callback_mode == "scheme":
        callback_url = "senselab-cli://callback"

    target = (
        f"{connect_url}?callback={quote(callback_url, safe=':/?=&')}"
        f"&state={quote(state)}&source=cli&flow={quote(flow)}"
    )
    _print_status("info", f"Opening browser: {target}")
    webbrowser.open(target)

    if callback_mode == "scheme":
        _print_status(
            "info",
            "Custom URL scheme mode selected. Ensure senselab-cli:// is registered "
            "on your OS and complete auth in browser.",
        )
        return 0

    _CallbackHandler.token = None
    _CallbackHandler.state = None
    _CallbackHandler.error = None
    server = HTTPServer(("127.0.0.1", port), _CallbackHandler)
    start = time.time()
    spin_index = 0
    while time.time() - start < timeout:
        elapsed = int(time.time() - start)
        spinner = _SPINNER_FRAMES[spin_index % len(_SPINNER_FRAMES)]
        spin_index += 1
        print(
            f"\r{_style('[WAIT]', color='blue', bold=True)} "
            f"Waiting for browser callback {spinner} ({elapsed}s/{timeout}s)",
            end="",
            file=sys.stderr,
            flush=True,
        )
        server.timeout = 1
        server.handle_request()
        if _CallbackHandler.error:
            print(file=sys.stderr)
            _print_status("error", f"Authentication failed: {_CallbackHandler.error}")
            return 1
        if _CallbackHandler.token:
            if _CallbackHandler.state != state:
                print(file=sys.stderr)
                _print_status("warn", "Ignoring callback with invalid state parameter.")
                _CallbackHandler.token = None
                _CallbackHandler.state = None
                continue
            config.token = _CallbackHandler.token
            api = _build_api(config)
            _maybe_set_default_project(config, api)
            try:
                who = api.whoami()
                config.email = who.get("email") or config.email
            except Exception:
                pass
            save_config(config)
            print(file=sys.stderr)
            _print_senselab_banner(stream=sys.stderr)
            _print_status(
                "ok",
                "Authentication succeeded and token saved.",
                next_step="Run `sense-cli projects -o json` to confirm project access.",
            )
            return 0
    print(file=sys.stderr)
    _print_status(
        "error",
        "Timed out waiting for callback token.",
        next_step="Retry `sense-cli login` and complete browser auth before timeout.",
    )
    return 1


def _handle_login(args: argparse.Namespace, config: CLIConfig) -> int:
    if args.prompt_token:
        if not (sys.stdin.isatty() and sys.stdout.isatty()):
            raise APIError(
                "Hidden token prompt requires an interactive terminal.",
                suggestion="Use `sense-cli login --token <token>` in non-interactive environments.",
            )
        try:
            typed_token = getpass.getpass("SenseLab token (input hidden): ").strip()
        except (EOFError, KeyboardInterrupt) as e:
            raise APIError(
                "Token prompt cancelled.",
                suggestion="Retry with `sense-cli login --prompt-token`.",
            ) from e
        if not typed_token:
            raise APIError(
                "No token entered.",
                suggestion="Run `sense-cli login --prompt-token` and paste a valid token.",
            )
        args.token = typed_token

    if args.token:
        previous_token = config.token
        candidate_token = args.token.strip()
        config.token = candidate_token
        api = _build_api(config)
        try:
            api.get_projects()
        except APIError as e:
            config.token = previous_token
            save_config(config)
            raise APIError(
                "Provided token is invalid.",
                suggestion="Get a valid token and run `sense-cli login --token <token>` again.",
            ) from e

        _set_default_project_if_single(config, api)
        try:
            who = api.whoami()
            config.email = who.get("email") or config.email
        except APIError:
            pass
        save_config(config)
        _print_senselab_banner()
        _print_status(
            "ok",
            "Token saved.",
            next_step="Run `sense-cli projects -o json` to validate access.",
        )
        return 0

    connect_url = _build_connect_url(config, args.connect_url, flow="login")
    return _run_browser_auth_flow(
        config,
        connect_url=connect_url,
        flow="login",
        callback_mode=args.callback_mode,
        port=args.port,
        timeout=args.timeout,
    )


def _handle_config_list(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    auth_status = "Not logged in"
    if config.token:
        try:
            auth_status = "Logged in"
            try:
                api.get_projects()
                _set_default_project_if_single(config, api)
            except APIError:
                auth_status = "Token invalid"
        except APIError:
            auth_status = "Token invalid"

    payload = {
        "api_base_url": config.base_url,
        "default_project_guid": config.default_project_guid,
        "email": config.email,
        "auth_status": auth_status,
    }
    _print_output(payload, args.output)
    return 0


def _handle_projects(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    projects = api.get_projects()
    _set_default_project_if_single(config, api)
    if args.output == "json":
        _print_output(projects, args.output)
    else:
        _render_projects_table(projects)
    return 0


def _handle_specialists(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialists = api.get_specialists(project_guid)
    if args.output == "json":
        _print_output(specialists, args.output)
    else:
        _render_specialists_table(specialists)
    return 0


def _handle_agent(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    ref = (args.agent_ref or "").strip()
    role_mode = ref.casefold() == "roles" or getattr(args, "agent_mode", None) == "roles"
    wants_list_flag = bool(getattr(args, "list", False))
    global_function_list_mode = (
        ref.casefold() in {"function", "functions"}
        and not any(
            [
                getattr(args, "chat", None),
                getattr(args, "run", None),
                getattr(args, "enable", None),
                getattr(args, "disable", None),
            ]
        )
    )

    if role_mode:
        roles = api.get_specialist_roles(project_guid, is_active=True)
        if getattr(args, "role_functions", False):
            if args.output == "json":
                _print_output(_role_functions_rows(roles), args.output)
            else:
                print(_style("=== ROLE FUNCTIONS ===", color="blue", bold=True))
                _render_role_functions_table(roles)
            return 0
        if args.output == "json":
            _print_output(roles, args.output)
        else:
            _render_roles_table(roles)
        return 0

    if getattr(args, "agent_mode", None) == "stats":
        if not ref:
            raise APIError(
                "Agent reference is required for stats.",
                suggestion="Run `sense-cli agent <agent> stats`.",
            )
        specialist_guid, specialist_name = _resolve_specialist_reference(
            api,
            project_guid=project_guid,
            specialist_ref=ref,
        )
        totals = api.get_specialist_totals(project_guid, specialist_guid)
        recent_activity = api.get_specialist_activity(project_guid, specialist_guid, limit=15)
        functions_enabled = api.get_functions(project_guid, specialist_guid)
        tool_metrics = api.get_specialist_tool_metrics(project_guid, specialist_guid)
        payload = {
            "agent": specialist_name,
            "totals": totals,
            "recent_activity": recent_activity,
            "functions_enabled": functions_enabled,
            "tool_metrics": tool_metrics,
        }
        if args.output == "json":
            _print_output(payload, args.output)
        else:
            _render_agent_stats_dashboard(
                agent_name=specialist_name,
                totals=totals,
                recent_activity=recent_activity,
                functions_enabled=functions_enabled,
                tool_metrics=tool_metrics,
            )
        return 0

    if global_function_list_mode:
        specialists = api.get_specialists(project_guid)
        rows: list[dict[str, Any]] = []
        for item in specialists:
            if not isinstance(item, dict):
                continue
            specialist_guid = _specialist_guid(item)
            if not specialist_guid:
                continue
            specialist_name = _specialist_name(item) or specialist_guid
            functions = api.get_functions(project_guid, specialist_guid)
            for fn in functions:
                if not isinstance(fn, dict):
                    continue
                rows.append(
                    {
                        "agent": specialist_name,
                        "function": _function_name(fn) or "",
                        "function_id": _function_guid(fn) or "",
                    }
                )
        rows.sort(
            key=lambda row: (
                str(row.get("agent", "")).casefold(),
                str(row.get("function", "")).casefold(),
            )
        )
        if args.output == "json":
            _print_output(rows, args.output)
        else:
            print(_style("=== FUNCTIONS BY AGENT ===", color="blue", bold=True))
            _render_functions_by_agent_table(rows)
        return 0

    if not ref or ref.casefold() == "list":
        specialists = api.get_specialists(project_guid)
        if args.output == "json":
            _print_output(specialists, args.output)
        else:
            _render_specialists_table(specialists)
        return 0

    specialist_guid, specialist_name = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=ref,
    )
    specialist = _find_specialist(api, project_guid=project_guid, specialist_guid=specialist_guid)

    if getattr(args, "chat", None) and getattr(args, "run", None):
        raise APIError("Use only one action at a time: --chat or --run.")
    if getattr(args, "enable", None) and getattr(args, "disable", None):
        raise APIError("Use only one function mutation flag at a time: --enable or --disable.")

    if getattr(args, "chat", None):
        query = str(args.chat).strip()
        if not query:
            raise APIError("Chat prompt cannot be empty.")
        _print_status(
            "info",
            f"{specialist_name} is getting your response...",
            stream=sys.stderr,
        )
        result = api.run_specialist_sync(project_guid, specialist_guid, query)
        _render_chat_response(result, output=args.output, source_label=specialist_name)
        return 0

    if getattr(args, "run", None):
        function_ref = str(args.run).strip()
        enabled_functions = api.get_functions(project_guid, specialist_guid)
        function_guid, function_name = _resolve_agent_run_target(
            specialist=specialist,
            enabled_functions=enabled_functions,
            function_ref=function_ref,
        )
        _print_status(
            "info",
            f"Running {function_name} on {specialist_name}...",
            stream=sys.stderr,
        )
        started = api.execute_function(project_guid, specialist_guid, function_guid)
        execution_guid = started.get("execution_guid")
        if not execution_guid:
            _print_output(started, args.output)
            return 1
        if getattr(args, "no_wait", False):
            _print_output(started, args.output)
            return 0

        status, payload = _stream_workflow_execution(
            api,
            project_guid=project_guid,
            workflow_guid=function_guid,
            execution_guid=str(execution_guid),
            timeout=getattr(args, "timeout", 300),
            poll_interval=getattr(args, "poll_interval", 2),
        )

        result_payload = {
            "execution_guid": execution_guid,
            "status": status,
            "result": payload,
        }
        if args.output == "json":
            _print_output(result_payload, args.output)
        else:
            _print_workflow_summary(payload if isinstance(payload, dict) else {})
        return 0 if status == "COMPLETED" else 1

    function_mode = getattr(args, "agent_mode", None) == "function"
    wants_list = wants_list_flag or (
        function_mode and getattr(args, "function_action", None) in {None, "list"}
    )
    if (getattr(args, "enable", None) or getattr(args, "disable", None)) and not function_mode:
        raise APIError(
            "Function mutation flags require function mode.",
            suggestion="Use `sense-cli agent <agent> function --enable <function>` or `--disable <function>`.",
        )

    if getattr(args, "enable", None):
        enabled_functions = api.get_functions(project_guid, specialist_guid)
        selected_prompt = _resolve_enable_prompt_reference(
            specialist=specialist,
            enabled_functions=enabled_functions,
            function_ref=str(args.enable),
        )
        enabled_prompt_ids = {
            str(item.get("prompt_id"))
            for item in enabled_functions
            if isinstance(item, dict) and item.get("prompt_id")
        }
        if selected_prompt["id"] in enabled_prompt_ids:
            _print_status("info", f"{selected_prompt['name']} is already enabled for {specialist_name}.")
            return 0

        _print_status("info", f"Enabling {selected_prompt['name']} for {specialist_name}...")
        result = api.generate_functions_for_specialist(
            project_guid,
            specialist_guid,
            [selected_prompt],
        )
        if args.output == "json":
            _print_output(result, args.output)
        else:
            _print_status(
                "ok",
                f"Enabled function '{selected_prompt['name']}' for {specialist_name}.",
                next_step=f"Run `sense-cli agent {specialist_name} function list` to confirm.",
            )
        return 0

    if getattr(args, "disable", None):
        enabled_functions = api.get_functions(project_guid, specialist_guid)
        function_guid, function_name = _resolve_disable_workflow_target(
            specialist=specialist,
            enabled_functions=enabled_functions,
            function_ref=str(args.disable),
        )
        _print_status("info", f"Disabling {function_name} for {specialist_name}...")
        api.disable_function_for_specialist(project_guid, specialist_guid, function_guid)
        _print_status(
            "ok",
            f"Disabled function '{function_name}' for {specialist_name}.",
            next_step=f"Run `sense-cli agent {specialist_name} function list` to confirm.",
        )
        return 0

    if function_mode and not wants_list:
        raise APIError(
            "Unsupported function action.",
            suggestion=(
                "Use `sense-cli agent <agent> function list`, "
                "`--enable <function>`, or `--disable <function>`."
            ),
        )

    enabled_functions = api.get_functions(project_guid, specialist_guid)
    if function_mode:
        rows = _function_catalog_rows(specialist, enabled_functions)
        rows.sort(key=lambda row: (row.get("enabled") != "yes", str(row.get("name", "")).casefold()))
        if args.output == "json":
            _print_output(rows, args.output)
        else:
            print(_style(f"=== AGENT FUNCTIONS: {specialist_name} ===", color="blue", bold=True))
            _print_compact_table(
                rows,
                [
                    ("name", "FUNCTION"),
                    ("prompt_id", "ID"),
                    ("enabled", "ENABLED"),
                ],
            )
        return 0

    if args.output == "json":
        _print_output(enabled_functions, args.output)
    else:
        print(_style(f"=== AGENT: {specialist_name} ===", color="blue", bold=True))
        _render_functions_table(enabled_functions)
    return 0


def _handle_functions(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid = _prompt_if_missing(
        args.specialist,
        prompt_text="Specialist GUID",
        example="f2a92d52-9f42-4d8f-b0af-263cbcb4e2d1",
    )
    specialist_guid, _ = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=specialist_guid,
    )
    functions = api.get_functions(project_guid, specialist_guid)
    if args.output == "json":
        _print_output(functions, args.output)
    else:
        _render_functions_table(functions)
    return 0


def _handle_chat(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid: str | None = None
    specialist_name: str | None = None
    if args.specialist:
        specialist_guid, specialist_name = _resolve_specialist_reference(
            api,
            project_guid=project_guid,
            specialist_ref=args.specialist,
        )

    if args.query:
        if specialist_guid:
            _print_status(
                "info",
                f"{specialist_name} is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_specialist_sync(project_guid, specialist_guid, args.query)
            _render_chat_response(
                result,
                output=args.output,
                source_label=specialist_name or "Specialist",
            )
        else:
            _print_status(
                "info",
                "SenseLab is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_orchestrator_sync(project_guid, args.query)
            _render_chat_response(
                result,
                output=args.output,
                source_label="SenseLab Orchestrator",
            )
        return 0

    conversation_guid: str | None = None
    _print_status("info", "Interactive chat mode. Empty line or Ctrl+C to exit.")
    while True:
        query = input("> ").strip()
        if not query:
            break
        if specialist_guid:
            _print_status(
                "info",
                f"{specialist_name} is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_specialist_sync(
                project_guid,
                specialist_guid,
                query,
                conversation_guid=conversation_guid,
            )
        else:
            _print_status(
                "info",
                "SenseLab is getting your response...",
                stream=sys.stderr,
            )
            result = api.run_orchestrator_sync(
                project_guid,
                query,
                conversation_guid=conversation_guid,
            )
        conversation_guid = result.get("conversation_guid", conversation_guid)
        if args.output == "json":
            _print_output(result, args.output)
        else:
            _render_chat_response(
                result,
                output=args.output,
                source_label=specialist_name if specialist_guid else "SenseLab Orchestrator",
            )
    return 0


def _parse_status(payload: dict[str, Any]) -> str:
    for key in ("workflow_status", "status", "state"):
        if payload.get(key):
            return str(payload[key]).upper()
    return "UNKNOWN"


def _workflow_task_rows(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for item in payload.get("task_status", []) or []:
        if not isinstance(item, dict):
            continue
        name = item.get("label") or item.get("name") or item.get("id") or "task"
        status = str(item.get("status") or "UNKNOWN").upper()
        duration = item.get("duration")
        rows.append(
            {
                "task": str(name),
                "status": status,
                "duration": duration if isinstance(duration, (int, float)) else "",
            }
        )
    return rows


def _print_workflow_summary(payload: dict[str, Any]) -> None:
    status = _parse_status(payload)
    duration = payload.get("workflow_duration")
    duration_text = f" ({duration}s)" if isinstance(duration, (int, float)) else ""
    if status == "COMPLETED":
        _print_status("ok", f"Workflow completed{duration_text}.")
    elif status in {"FAILED", "TERMINATED", "TIMED_OUT", "TIMEOUT"}:
        _print_status("error", f"Workflow ended with status {status}{duration_text}.")
    else:
        _print_status("info", f"Workflow status: {status}{duration_text}.")

    rows = _workflow_task_rows(payload)
    if rows:
        print(_style("=== WORKFLOW TASKS ===", color="blue", bold=True))
        _print_compact_table(
            rows,
            [
                ("task", "TASK"),
                ("status", "STATUS"),
                ("duration", "SEC"),
            ],
        )


def _stream_workflow_execution(
    api: APIClient,
    *,
    project_guid: str,
    workflow_guid: str,
    execution_guid: str,
    timeout: int,
    poll_interval: int,
) -> tuple[str, dict[str, Any]]:
    deadline = time.time() + timeout
    last_payload: dict[str, Any] = {}
    task_states: dict[str, str] = {}
    spin_index = 0

    while time.time() < deadline:
        elapsed = int(timeout - max(0, deadline - time.time()))
        spinner = _SPINNER_FRAMES[spin_index % len(_SPINNER_FRAMES)]
        spin_index += 1
        print(
            f"\r{_style('[WAIT]', color='blue', bold=True)} "
            f"Running function {spinner} ({elapsed}s/{timeout}s)",
            end="",
            file=sys.stderr,
            flush=True,
        )

        payload = api.get_execution_status(project_guid, workflow_guid, execution_guid)
        last_payload = payload
        updates: list[str] = []
        for item in payload.get("task_status", []) or []:
            if not isinstance(item, dict):
                continue
            task_id = str(item.get("id") or item.get("label") or item.get("name") or "")
            if not task_id:
                continue
            status = str(item.get("status") or "UNKNOWN").upper()
            previous = task_states.get(task_id)
            if previous == status:
                continue
            task_states[task_id] = status
            label = str(item.get("label") or item.get("name") or task_id)
            duration = item.get("duration")
            duration_text = f" ({duration}s)" if isinstance(duration, (int, float)) else ""
            summary = _task_progress_summary(item)
            if summary:
                updates.append(f"{label} -> {status}{duration_text} | {summary}")
            else:
                updates.append(f"{label} -> {status}{duration_text}")

        if updates:
            print(file=sys.stderr)
            for line in updates:
                print(f"{_style('[STEP]', color='cyan', bold=True)} {line}", file=sys.stderr)

        status = _parse_status(payload)
        if status in _WORKFLOW_TERMINAL_STATUSES:
            print(file=sys.stderr)
            return status, payload

        time.sleep(max(1, poll_interval))

    print(file=sys.stderr)
    return "TIMEOUT", last_payload


def _task_progress_summary(task: dict[str, Any]) -> str:
    inputs = task.get("input")
    if not isinstance(inputs, dict):
        return ""
    for key in ("prompt", "query", "instruction", "task_prompt", "message"):
        value = inputs.get(key)
        if not value:
            continue
        text = " ".join(str(value).split())
        if not text:
            continue
        if len(text) > 90:
            text = text[:87].rstrip() + "..."
        return text
    return ""


def _handle_run(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    specialist_guid = _prompt_if_missing(
        args.specialist,
        prompt_text="Specialist GUID",
        example="f2a92d52-9f42-4d8f-b0af-263cbcb4e2d1",
    )
    function_guid = _prompt_if_missing(
        args.function,
        prompt_text="Function/workflow GUID",
        example="4e4d2d87-83d7-4b62-a3e3-f3ce3720b2f3",
    )
    specialist_guid, _ = _resolve_specialist_reference(
        api,
        project_guid=project_guid,
        specialist_ref=specialist_guid,
    )

    started = api.execute_function(project_guid, specialist_guid, function_guid)
    execution_guid = started.get("execution_guid")
    if not execution_guid:
        _print_output(started, args.output)
        return 1

    if not args.wait:
        _print_output(started, args.output)
        return 0

    deadline = time.time() + args.timeout
    last_payload: dict[str, Any] = {}
    spin_index = 0
    while time.time() < deadline:
        elapsed = int(args.timeout - max(0, deadline - time.time()))
        spinner = _SPINNER_FRAMES[spin_index % len(_SPINNER_FRAMES)]
        spin_index += 1
        print(
            f"\r{_style('[WAIT]', color='blue', bold=True)} "
            f"Waiting workflow completion {spinner} ({elapsed}s/{args.timeout}s)",
            end="",
            file=sys.stderr,
            flush=True,
        )
        status_payload = api.get_execution_status(project_guid, function_guid, execution_guid)
        last_payload = status_payload
        status = _parse_status(status_payload)
        if status in {"COMPLETED", "FAILED", "TERMINATED"}:
            print(file=sys.stderr)
            _print_output(
                {
                    "execution_guid": execution_guid,
                    "status": status,
                    "result": status_payload,
                },
                args.output,
            )
            return 0 if status == "COMPLETED" else 1
        time.sleep(args.poll_interval)

    _print_output(
        {
            "execution_guid": execution_guid,
            "status": "TIMEOUT",
            "last_result": last_payload,
        },
        args.output,
    )
    return 1


def _handle_connectors_list(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    connectors = api.list_connectors()
    if getattr(args, "raw", False):
        _print_output(connectors, args.output)
        return 0
    rows = _connector_summary_rows(connectors)
    if args.output == "json":
        _print_output(rows, args.output)
    else:
        _print_compact_table(
            rows,
            [
                ("name", "CONNECTOR"),
                ("type", "TYPE"),
            ],
        )
    return 0


def _handle_connectors_describe(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    connectors = api.list_connectors()
    connector_ref = _prompt_if_missing(
        args.connector_ref,
        prompt_text="Connector name or type",
        example="github",
    )
    item = _resolve_connector_reference(connectors, connector_ref)

    payload = {
        "name": item.get("name"),
        "type": _connector_type(item),
        "description": item.get("description") or "No description provided.",
        "auth_mode": "oauth" if item.get("oauth") else "manual",
        "required_fields": _connector_required_fields(item),
        "add_command": f"sense-cli connectors add {_connector_type(item)}",
        "agent_definition": _connector_agent_definition_example(item),
    }

    if args.output == "json":
        _print_output(payload, args.output)
        return 0

    print(_style(f"=== CONNECTOR: {payload['name']} ===", color="blue", bold=True))
    print(_style(f"Type: {payload['type']}", color="cyan"))
    print(_style(f"Auth mode: {payload['auth_mode']}", color="cyan"))
    print()
    print(_style("Description", color="blue", bold=True))
    print(payload["description"])
    print()
    print(_style("Required fields", color="blue", bold=True))
    if payload["required_fields"]:
        for field in payload["required_fields"]:
            print(_style(f"- {field}", color="yellow"))
    else:
        print("No required fields.")
    print()
    print(_style("Connect command", color="blue", bold=True))
    print(payload["add_command"])
    print()
    print(_style("Agent definition", color="blue", bold=True))
    print(payload["agent_definition"])
    return 0


def _handle_connectors_show(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(getattr(args, "project", None), config, required=True)
    connector_ref = _prompt_if_missing(
        getattr(args, "connector_ref", None),
        prompt_text="Connector name",
        example="AWS",
    )
    instances = api.list_connector_instances(project_guid)
    rows = _connector_instance_rows_for_show(instances, connector_ref)
    if args.output == "json":
        _print_output(rows, args.output)
        return 0
    print(_style(f"=== CONNECTIONS: {connector_ref} ===", color="blue", bold=True))
    _print_compact_table(
        rows,
        [
            ("name", "NAME"),
            ("default", "DEFAULT"),
            ("id", "ID"),
        ],
    )
    return 0


def _handle_connectors_add(args: argparse.Namespace, config: CLIConfig) -> int:
    base = args.frontend_url or config.frontend_url or _derive_frontend_url(config.base_url)
    connector_type = str(args.connector_type).strip()
    if not connector_type:
        raise APIError("Connector type cannot be empty.")

    connector_name = ""
    try:
        api = _build_api(config)
        connectors = api.list_connectors()
        item = _resolve_connector_reference(connectors, connector_type)
        connector_name = str(item.get("name") or "").strip()
    except Exception:
        connector_name = ""

    if not connector_name:
        fallback_names = {
            "github": "Github",
            "gitlab": "Gitlab",
            "jira": "Jira",
            "aws": "AWS",
            "gcp": "GCP",
            "datadog": "Datadog",
            "slack": "Slack",
        }
        connector_name = fallback_names.get(connector_type.casefold(), connector_type.title())

    url = f"{base.rstrip('/')}/connectors?source=cli&connectorName={quote(connector_name)}"
    webbrowser.open(url)
    _print_status(
        "ok",
        f"Opened browser for connector setup: {url}",
        next_step=(
            f"Complete setup for {connector_type} in the browser, "
            "then run `sense-cli connectors show <connector>`."
        ),
    )
    return 0


def _handle_signup(args: argparse.Namespace, config: CLIConfig) -> int:
    connect_url = _build_connect_url(config, args.frontend_url, flow="signup")
    return _run_browser_auth_flow(
        config,
        connect_url=connect_url,
        flow="signup",
        callback_mode=args.callback_mode,
        port=args.port,
        timeout=args.timeout,
    )


def _handle_apply(args: argparse.Namespace, config: CLIConfig) -> int:
    try:
        from cli.apply import apply_assistant_config, load_apply_file
    except ImportError as e:
        raise APIError(
            "Missing dependency for apply command. Install project dependencies (PyYAML)."
        ) from e
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    file_path = _prompt_if_missing(
        args.file,
        prompt_text="Path to YAML file",
        example="assistant.yaml",
    )
    _print_status("info", "[STEP] Validating YAML file...", stream=sys.stderr)
    yaml_payload = load_apply_file(file_path)

    def _apply_progress(step: str, message: str) -> None:
        _print_status("info", f"[STEP] {message}", stream=sys.stderr)

    result = apply_assistant_config(
        api=api,
        project_guid=project_guid,
        payload=yaml_payload,
        dry_run=args.dry_run,
        progress=_apply_progress,
    )
    _print_output(asdict(result), args.output)
    return 0


def _policy_backend_and_auth(
    args: argparse.Namespace,
    config: CLIConfig,
) -> tuple[str, str, str]:
    backend = os.getenv("BACKEND_URL") or config.base_url
    token_name = (getattr(args, "token_name", None) or os.getenv("TOKEN_NAME") or "").strip()
    token_secret = (getattr(args, "token_secret", None) or os.getenv("TOKEN_SECRET") or "").strip()
    if not backend or not token_name or not token_secret:
        raise APIError(
            "Error: BACKEND_URL, TOKEN_NAME, and TOKEN_SECRET environment variables must be set."
        )
    return backend, token_name, token_secret


def _handle_policy_test(args: argparse.Namespace, config: CLIConfig) -> int:
    del config
    policy_files = find_local_rego_files(args.path)
    rows = policy_test_rows(policy_files, repo=args.repo, branch=args.branch)
    payload = {
        "repo": args.repo,
        "branch": args.branch,
        "path": args.path,
        "commit": args.commit,
        "parsed": len(rows),
        "policies": rows,
    }
    if args.output == "json":
        _print_output(payload, args.output)
        return 0
    _print_status("ok", f"Successfully parsed {len(rows)} policies.")
    _render_policy_test_table(rows)
    return 0


def _handle_policy_list(args: argparse.Namespace, config: CLIConfig) -> int:
    api = _build_api(config)
    project_guid = _resolve_project_guid(args.project, config, required=True)
    active_only: bool | None = True
    if str(args.active_only).strip().lower() in {"false", "0", "no"}:
        active_only = False
    policies = api.list_policies(
        project_guid,
        active_only=active_only,
        name_filter=args.name_filter,
        phase_filter=args.phase_filter,
        connector_filter=args.connector_filter,
        repo_id=args.repo_id,
        filename_filter=args.filename_filter,
        policy_guid=args.policy_guid,
    )
    if args.output == "json":
        _print_output(policies, args.output)
        return 0

    rows: list[dict[str, Any]] = []
    for item in policies:
        if not isinstance(item, dict):
            continue
        connectors = item.get("connector_patterns")
        if isinstance(connectors, list):
            connectors_text = ",".join(str(x) for x in connectors)
        else:
            connectors_text = str(connectors or "")
        rows.append(
            {
                "policy_name": item.get("policy_name") or item.get("filename") or "",
                "phase": item.get("phase") or "",
                "connectors": connectors_text,
                "is_active": bool(item.get("is_active", False)),
                "policy_guid": str(item.get("policy_guid") or ""),
            }
        )
    _render_policy_list_table(rows)
    return 0


def _handle_policy_sync(args: argparse.Namespace, config: CLIConfig) -> int:
    backend, token_name, token_secret = _policy_backend_and_auth(args, config)
    _print_status("info", f"Syncing policies from local path: {args.path}")

    policy_files = find_local_rego_files(args.path)
    _print_status("info", f"Found {len(policy_files)} .rego files")

    tool_cred_mappings: dict[str, str] = {}
    if args.auto_assignment:
        tool_cred_mappings = get_tool_cred_mappings(policy_files)
        _print_status(
            "info",
            f"Found tool_cred_guid in {len(tool_cred_mappings)} files for auto-assignment",
        )

    api = APIClient(base_url=backend, token=config.token)
    repo_info = {
        "repo_url": args.repo,
        "branch": args.branch,
        "path": args.path,
        "commit_sha": args.commit,
    }
    result = api.sync_policies_basic(
        token_name=token_name,
        token_secret=token_secret,
        repo_info=repo_info,
        files=policy_files,
    )

    assignment_summary: dict[str, Any] = {
        "successful": 0,
        "failed": 0,
        "details": [],
    }
    if args.auto_assignment and tool_cred_mappings and isinstance(result.get("policies"), list):
        _print_status("info", "Auto-assigning policies to tool credentials...")
        for policy in result["policies"]:
            if not isinstance(policy, dict):
                continue
            filename = str(policy.get("filename") or "")
            policy_guid = str(policy.get("id") or "")
            phase = str(policy.get("phase") or "pre")
            tool_cred_guid = tool_cred_mappings.get(filename)
            if not filename or not policy_guid or not tool_cred_guid:
                continue
            try:
                api.create_policy_assignment_basic(
                    token_name=token_name,
                    token_secret=token_secret,
                    policy_guid=policy_guid,
                    tool_cred_guid=tool_cred_guid,
                    phase=phase,
                    priority=100,
                )
                assignment_summary["successful"] += 1
                assignment_summary["details"].append(
                    {
                        "filename": filename,
                        "tool_cred_guid": tool_cred_guid,
                        "status": "success",
                    }
                )
            except APIError as e:
                assignment_summary["failed"] += 1
                assignment_summary["details"].append(
                    {
                        "filename": filename,
                        "tool_cred_guid": tool_cred_guid,
                        "status": "failed",
                        "message": e.message,
                    }
                )

    payload: dict[str, Any] = {
        "repo_id": result.get("repo_id"),
        "synced": int(result.get("synced") or 0),
        "deactivated": int(result.get("deactivated") or 0),
    }
    if args.auto_assignment:
        payload["auto_assignment"] = assignment_summary

    if args.output == "json":
        _print_output(payload, args.output)
        return 0

    _print_status("ok", f"Successfully synced {payload['synced']} policies")
    _print_status("info", f"Repository ID: {payload.get('repo_id')}")
    if args.auto_assignment:
        _print_status(
            "info",
            f"Auto-assignment summary - successful: {assignment_summary['successful']}, "
            f"failed: {assignment_summary['failed']}",
        )
    return 0


def _handle_logout(config: CLIConfig) -> int:
    config.token = None
    config.email = None
    config.default_project_guid = None
    save_config(config)
    _print_status("ok", "Logged out.")
    return 0


def _handle_telemetry_toggle(args: argparse.Namespace, config: CLIConfig) -> int:
    config.telemetry_disabled = args.state == "off"
    save_config(config)
    _print_status(
        "ok",
        f"Telemetry {'disabled' if config.telemetry_disabled else 'enabled'}.",
    )
    return 0


def _lineage_status_payload(repo_root: Path) -> dict[str, Any]:
    enabled = is_lineage_enabled(repo_root)
    installed_hooks = installed_lineage_hooks(repo_root)
    daemon = lineage_daemon_status(repo_root)
    return {
        "repo_root": str(repo_root),
        "enabled": enabled,
        "hook": LINEAGE_HOOK,
        "hooks": installed_hooks,
        "pending_events": pending_events_count(repo_root),
        "daemon": daemon,
    }


def _handle_lineage_enable(args: argparse.Namespace, config: CLIConfig) -> int:
    mode = str(args.mode or "metadata-only")
    if mode not in _LINEAGE_MODES:
        raise APIError(f"Unsupported lineage mode: {mode}")
    repo_root = resolve_repo_root(args.repo)
    install_lineage_hook(repo_root)
    config.lineage_enabled = True
    config.lineage_mode = mode
    config.lineage_last_repo = str(repo_root)
    save_config(config)
    daemon = start_lineage_daemon(
        repo_root=repo_root,
        project_guid=args.project or config.default_project_guid,
        runtime_env=getattr(args, "env", None),
    )
    payload = _lineage_status_payload(repo_root)
    payload["daemon"] = daemon
    if args.output == "json":
        _print_output(payload, "json")
        return 0
    _print_status("ok", f"Lineage enabled for repository: {repo_root}")
    _print_status("info", f"Hooks installed: {', '.join(LINEAGE_HOOKS)}")
    _print_status("info", f"Background watcher running: {bool((daemon or {}).get('running'))}")
    return 0


def _handle_lineage_disable(args: argparse.Namespace, config: CLIConfig) -> int:
    repo_root = resolve_repo_root(args.repo)
    stop_lineage_daemon(repo_root)
    removed = remove_lineage_hook(repo_root)
    if not args.keep_config:
        config.lineage_enabled = False
        config.lineage_last_repo = str(repo_root)
        save_config(config)
    payload = _lineage_status_payload(repo_root)
    payload["removed"] = removed
    if args.output == "json":
        _print_output(payload, "json")
        return 0
    _print_status("ok", f"Lineage disabled for repository: {repo_root}")
    return 0


def _handle_lineage_status(args: argparse.Namespace, config: CLIConfig) -> int:
    repo_root = resolve_repo_root(args.repo)
    payload = _lineage_status_payload(repo_root)
    payload["mode"] = config.lineage_mode
    payload["configured"] = bool(config.lineage_enabled)
    if args.output == "json":
        _print_output(payload, "json")
        return 0
    _print_status(
        "info",
        f"Lineage is {'enabled' if payload['enabled'] else 'disabled'} for {repo_root}.",
    )
    _print_status("info", f"Pending events: {payload['pending_events']}")
    daemon = payload.get("daemon") or {}
    _print_status("info", f"Background watcher running: {bool(daemon.get('running'))}")
    return 0


def _handle_lineage_capture(args: argparse.Namespace, config: CLIConfig) -> int:
    _ = config
    repo_root = resolve_repo_root(args.repo)
    capture_event(
        repo_root,
        hook_name=args.hook or LINEAGE_HOOK,
        commit_msg_file=getattr(args, "commit_msg_file", None),
    )
    return 0


def _handle_lineage_sync(args: argparse.Namespace, config: CLIConfig) -> int:
    repo_root = resolve_repo_root(args.repo)
    if args.batch_size < 1 or args.batch_size > 1000:
        raise APIError("Batch size must be between 1 and 1000.")
    token_name = (
        getattr(args, "token_name", None)
        or os.getenv("LINEAGE_TOKEN_NAME")
        or os.getenv("SENSELAB_LINEAGE_TOKEN_NAME")
        or None
    )
    token_secret = (
        getattr(args, "token_secret", None)
        or os.getenv("LINEAGE_TOKEN_SECRET")
        or os.getenv("SENSELAB_LINEAGE_TOKEN_SECRET")
        or None
    )
    basic_token_name, basic_token_secret = _lineage_basic_auth_credentials()
    if token_name:
        basic_token_name = str(token_name).strip()
    if token_secret:
        basic_token_secret = str(token_secret).strip()
    has_basic_auth = bool(basic_token_name and basic_token_secret)
    if not config.token and not has_basic_auth:
        raise APIError(
            "Not logged in.",
            suggestion=(
                "Run `sense-cli login` or provide non-expiring lineage credentials "
                "via --token-name/--token-secret (or LINEAGE_TOKEN_NAME/LINEAGE_TOKEN_SECRET)."
            ),
        )
    api = _build_api(config)
    project_guid = args.project or config.default_project_guid
    sent, remaining = sync_events(
        config=config,
        api=api,
        repo_root=repo_root,
        project_guid=project_guid,
        basic_token_name=basic_token_name,
        basic_token_secret=basic_token_secret,
        batch_size=args.batch_size,
    )
    payload = {
        "repo_root": str(repo_root),
        "sent": sent,
        "remaining": remaining,
    }
    if args.output == "json":
        _print_output(payload, "json")
        return 0
    _print_status("ok", f"Synced {sent} lineage events.")
    return 0


def _handle_lineage_watch(args: argparse.Namespace, config: CLIConfig) -> int:
    repo_root = resolve_repo_root(args.repo)
    run_lineage_watch_loop(
        config=config,
        repo_root=repo_root,
        project_guid=args.project or config.default_project_guid,
        interval_seconds=args.interval,
        runtime_env=getattr(args, "env", None),
        once=bool(args.once),
    )
    return 0


def _render_completion_script(shell: str) -> str:
    commands = [
        "login",
        "logout",
        "signup",
        "projects",
        "agent",
        "policy",
        "connectors",
        "config",
        "apply",
        "version",
        "completion",
        "telemetry",
        "lineage",
    ]
    if shell == "bash":
        command_list = " ".join(commands)
        return (
            "_sense_cli_complete() {\n"
            "  local cur prev\n"
            "  local cmd\n"
            "  COMPREPLY=()\n"
            "  cur=\"${COMP_WORDS[COMP_CWORD]}\"\n"
            "  prev=\"${COMP_WORDS[COMP_CWORD-1]}\"\n"
            "  cmd=\"${COMP_WORDS[1]}\"\n"
            f"  local cmds=\"{command_list}\"\n"
            "  if [[ ${COMP_CWORD} -eq 1 ]]; then\n"
            "    COMPREPLY=( $(compgen -W \"${cmds}\" -- ${cur}) )\n"
            "    return 0\n"
            "  fi\n"
            "  case \"${prev}\" in\n"
            "    --output|-o) COMPREPLY=( $(compgen -W \"json table\" -- ${cur}) ); return 0 ;;\n"
            "    --callback-mode) COMPREPLY=( $(compgen -W \"localhost scheme\" -- ${cur}) ); return 0 ;;\n"
            "    connectors) COMPREPLY=( $(compgen -W \"list show describe add\" -- ${cur}) ); return 0 ;;\n"
            "    policy) COMPREPLY=( $(compgen -W \"sync list test\" -- ${cur}) ); return 0 ;;\n"
            "    config) COMPREPLY=( $(compgen -W \"list\" -- ${cur}) ); return 0 ;;\n"
            "    telemetry) COMPREPLY=( $(compgen -W \"on off\" -- ${cur}) ); return 0 ;;\n"
            "    lineage) COMPREPLY=( $(compgen -W \"enable disable status capture sync\" -- ${cur}) ); return 0 ;;\n"
            "    completion) COMPREPLY=( $(compgen -W \"bash zsh\" -- ${cur}) ); return 0 ;;\n"
            "  esac\n"
            "  case \"${cmd}\" in\n"
            "    login)\n"
            "      COMPREPLY=( $(compgen -W \"--token --prompt-token --connect-url --port --timeout --callback-mode\" -- ${cur}) ) ;;\n"
            "    signup)\n"
            "      COMPREPLY=( $(compgen -W \"--frontend-url --port --timeout --callback-mode\" -- ${cur}) ) ;;\n"
            "    projects)\n"
            "      COMPREPLY=( $(compgen -W \"--output -o\" -- ${cur}) ) ;;\n"
            "    agent)\n"
            "      COMPREPLY=( $(compgen -W \"list roles function stats --project --chat --run --enable --disable --functions --list --no-wait --timeout --poll-interval --output -o\" -- ${cur}) ) ;;\n"
            "    policy)\n"
            "      COMPREPLY=( $(compgen -W \"sync list test --repo --branch --path --commit --auto-assignment --project --active-only --name-filter --phase-filter --connector-filter --repo-id --filename-filter --policy-guid --token-name --token-secret --output -o\" -- ${cur}) ) ;;\n"
            "    connectors)\n"
            "      COMPREPLY=( $(compgen -W \"list show describe add\" -- ${cur}) ) ;;\n"
            "    apply)\n"
            "      COMPREPLY=( $(compgen -W \"--file -f --project --dry-run --output -o\" -- ${cur}) ) ;;\n"
            "    config)\n"
            "      COMPREPLY=( $(compgen -W \"list\" -- ${cur}) ) ;;\n"
            "    completion)\n"
            "      COMPREPLY=( $(compgen -W \"bash zsh\" -- ${cur}) ) ;;\n"
            "    telemetry)\n"
            "      COMPREPLY=( $(compgen -W \"on off\" -- ${cur}) ) ;;\n"
            "    lineage)\n"
            "      COMPREPLY=( $(compgen -W \"enable disable status capture sync --repo --mode --keep-config --hook --commit-msg-file --project --batch-size --token-name --token-secret --output -o\" -- ${cur}) ) ;;\n"
            "  esac\n"
            "}\n"
            "complete -F _sense_cli_complete sense-cli\n"
        )
    # zsh
    return (
        "#compdef sense-cli\n"
        "_sense_cli() {\n"
        "  local context state line\n"
        "  _arguments -C \\\n"
        "    '1:command:(login logout signup projects agent policy connectors config apply version completion telemetry lineage)' \\\n"
        "    '*::arg:->args'\n"
        "  case $state in\n"
        "    args)\n"
        "      case $words[2] in\n"
        "        login)\n"
        "          _arguments '--token[CI/CD token]' '--prompt-token[Prompt for token with hidden input]' '--connect-url[Frontend connect URL]' '--port[Local callback port]' '--timeout[Callback timeout]' '--callback-mode[Callback mode]:mode:(localhost scheme)' ;;\n"
        "        signup)\n"
        "          _arguments '--frontend-url[Frontend base URL]' '--port[Local callback port]' '--timeout[Callback timeout]' '--callback-mode[Callback mode]:mode:(localhost scheme)' ;;\n"
        "        projects)\n"
        "          _arguments '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        agent)\n"
        "          _arguments '1:agent:(list roles function)' '2:mode:(function roles stats)' '3:action:(list)' '--project[Project GUID]' '--chat[Ask agent something]' '--run[Run function/workflow]' '--enable[Enable role function by name or id]' '--disable[Disable enabled function by name or id]' '--functions[List role functions with IDs]' '--list[Alias for function list]' '--no-wait[Return immediately when running workflow]' '--timeout[Wait timeout in seconds]' '--poll-interval[Execution status polling interval]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        policy)\n"
        "          _arguments '1:subcommand:(sync list test)' '--repo[Git repository URL]' '--branch[Git branch]' '--path[Local path with .rego files]' '--commit[Commit SHA]' '--auto-assignment[Auto-assign policies by tool_cred_guid]' '--project[Project GUID]' '--active-only[Show active policies only]:state:(true false)' '--name-filter[Filter by policy name]' '--phase-filter[Filter by phase]:phase:(pre post)' '--connector-filter[Filter by connector]' '--repo-id[Filter by repository ID]' '--filename-filter[Filter by filename]' '--policy-guid[Filter by policy GUID]' '--token-name[Basic auth token name for policy sync]' '--token-secret[Basic auth token secret for policy sync]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        connectors)\n"
        "          _arguments '1:subcommand:(list show describe add)' '--project[Project GUID]' '--frontend-url[Frontend base URL]' ;;\n"
        "        config)\n"
        "          _arguments '1:subcommand:(list)' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        apply)\n"
        "          _arguments '--file[YAML path]' '-f[YAML path]' '--project[Project GUID]' '--dry-run[Validate only]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "        completion)\n"
        "          _arguments '1:shell:(bash zsh)' ;;\n"
        "        telemetry)\n"
        "          _arguments '1:state:(on off)' ;;\n"
        "        lineage)\n"
        "          _arguments '1:subcommand:(enable disable status capture sync)' '--repo[Repository path]' '--mode[Lineage mode]:mode:(metadata-only)' '--keep-config[Keep lineage config enabled state]' '--hook[Hook name]' '--commit-msg-file[Path to commit message file]' '--project[Project GUID]' '--batch-size[Batch size]' '--token-name[Basic auth token name for lineage sync]' '--token-secret[Basic auth token secret for lineage sync]' '--output[Output format]:fmt:(json table)' '-o[Output format]:fmt:(json table)' ;;\n"
        "      esac\n"
        "      ;;\n"
        "  esac\n"
        "}\n"
        "compdef _sense_cli sense-cli\n"
    )


def _install_completion_script(shell: str) -> int:
    script = _render_completion_script(shell)
    rc_path = Path.home() / (".zshrc" if shell == "zsh" else ".bashrc")
    block = f"{_COMPLETION_MARKER_START}\n{script.rstrip()}\n{_COMPLETION_MARKER_END}\n"

    existing = rc_path.read_text(encoding="utf-8") if rc_path.exists() else ""
    pattern = re.compile(
        rf"{re.escape(_COMPLETION_MARKER_START)}.*?{re.escape(_COMPLETION_MARKER_END)}\n?",
        flags=re.DOTALL,
    )
    if pattern.search(existing):
        updated = pattern.sub(block, existing)
    else:
        updated = existing
        if updated and not updated.endswith("\n"):
            updated += "\n"
        updated += "\n" + block

    rc_path.write_text(updated, encoding="utf-8")
    _print_status(
        "ok",
        f"Installed completion for {shell} in {rc_path}.",
        next_step=f"Run `source {rc_path}` or open a new terminal.",
    )
    return 0


def _is_completion_installed(shell: str) -> bool:
    rc_path = Path.home() / (".zshrc" if shell == "zsh" else ".bashrc")
    if not rc_path.exists():
        return False
    content = rc_path.read_text(encoding="utf-8")
    return (
        _COMPLETION_MARKER_START in content and _COMPLETION_MARKER_END in content
    )


def _maybe_prompt_completion_install(config: CLIConfig, command: str | None) -> None:
    if config.completion_prompted:
        return
    if command in {"completion", "telemetry", "lineage"}:
        return
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return

    shell = _detect_shell("auto")
    if shell not in {"bash", "zsh"}:
        config.completion_prompted = True
        save_config(config)
        return

    if _is_completion_installed(shell):
        config.completion_prompted = True
        save_config(config)
        return

    prompt = f"Install shell completion for {shell} now? [Y/n]: "
    try:
        answer = input(prompt).strip().lower()
    except EOFError:
        return

    if answer in {"", "y", "yes"}:
        _install_completion_script(shell)
    else:
        _print_status(
            "info",
            "Skipping completion install.",
            next_step="Run `sense-cli completion auto --install` anytime.",
        )

    config.completion_prompted = True
    save_config(config)


def _send_telemetry(
    config: CLIConfig,
    *,
    command: str,
    success: bool,
    error_code: str | None,
    http_status: int | None,
    error_category: str | None,
    backend_message_hash: str | None,
    subcommand: str | None,
    flags: dict[str, Any],
) -> None:
    if config.telemetry_disabled:
        return
    try:
        import requests
    except ImportError:
        return
    payload = {
        "command": command,
        "subcommand": subcommand,
        "success": success,
        "error_code": error_code,
        "http_status": http_status,
        "error_category": error_category,
        "backend_message_hash": backend_message_hash,
        "flags": flags,
        "cli_version": __version__,
        "platform": platform.platform(),
        "python_version": platform.python_version(),
    }
    endpoint = f"{config.base_url.rstrip('/')}/api/cli/telemetry"
    try:
        requests.post(endpoint, json=payload, timeout=2)
    except Exception:
        return


def _build_parser() -> argparse.ArgumentParser:
    examples = (
        "Examples:\n"
        "  sense-cli login --token <JWT>\n"
        "  sense-cli projects --output json\n"
        "  sense-cli agent list --project <project_guid>\n"
        "  sense-cli agent roles --list\n"
        "  sense-cli agent roles --functions\n"
        "  sense-cli agent function --list\n"
        "  sense-cli agent <agent_name_or_id> stats\n"
        "  sense-cli agent <agent_name_or_id> function list\n"
        "  sense-cli agent <agent_name_or_id> function --enable <function_name_or_id>\n"
        "  sense-cli agent <agent_name_or_id> function --disable <function_name_or_id>\n"
        "  sense-cli agent <agent_name_or_id> --chat \"hello\"\n"
        "  sense-cli agent <agent_name_or_id> --run <function_name_or_id>\n"
        "  sense-cli policy test --repo <repo_url> --branch <branch> --commit <sha>\n"
        "  sense-cli policy sync --repo <repo_url> --branch <branch> --commit <sha>\n"
        "  sense-cli policy list --output table\n"
        "  sense-cli connectors show AWS\n"
        "  sense-cli apply -f assistant.yaml --project <project_guid>\n"
        "  sense-cli completion auto --install\n"
    )
    parser = argparse.ArgumentParser(
        prog="sense-cli",
        description="SenseLab CLI for managing AI agents.",
        epilog=examples,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI colors in CLI output.",
    )
    parser.add_argument(
        "--env",
        choices=("prod", "dev"),
        help="Runtime environment override (default: prod).",
    )
    verbosity = parser.add_mutually_exclusive_group()
    verbosity.add_argument(
        "--verbose",
        action="store_true",
        help="Show additional progress and guidance output.",
    )
    verbosity.add_argument(
        "--quiet",
        action="store_true",
        help="Show only command results and errors.",
    )
    sub = parser.add_subparsers(dest="command")

    login = sub.add_parser("login", help="Authenticate and store token.")
    login_auth = login.add_mutually_exclusive_group()
    login_auth.add_argument("--token", help="CI/CD token to store as CLI token.")
    login_auth.add_argument(
        "--prompt-token",
        action="store_true",
        help="Prompt for token with hidden input (safer for local terminal use).",
    )
    login.add_argument(
        "--connect-url",
        help="Frontend Connect CLI URL; opens browser and waits callback.",
    )
    login.add_argument("--port", type=int, default=8765)
    login.add_argument("--timeout", type=int, default=180)
    login.add_argument(
        "--callback-mode",
        choices=("localhost", "scheme"),
        default="localhost",
        help="Callback target mode for browser login.",
    )

    sub.add_parser("logout", help="Clear stored credentials.")

    signup = sub.add_parser("signup", help="Open browser to sign-up flow.")
    signup.add_argument("--frontend-url", help="Frontend base URL.")
    signup.add_argument("--port", type=int, default=8765)
    signup.add_argument("--timeout", type=int, default=600)
    signup.add_argument(
        "--callback-mode",
        choices=("localhost", "scheme"),
        default="localhost",
        help="Callback target mode for browser signup.",
    )

    projects = sub.add_parser("projects", help="List projects.")
    projects.add_argument("-o", "--output", choices=("json", "table"), default="table")

    agent_examples = (
        "Examples:\n"
        "  sense-cli agent list\n"
        "  sense-cli agent roles --list\n"
        "  sense-cli agent roles --functions\n"
        "  sense-cli agent function --list\n"
        "  sense-cli agent Bart stats\n"
        "  sense-cli agent Bart --chat \"check service health\"\n"
        "  sense-cli agent Bart --run <workflow_id>\n"
        "  sense-cli agent Bart function list\n"
        "  sense-cli agent Bart function --enable \"Service Health Monitor\"\n"
        "  sense-cli agent Bart function --disable \"Service Health Monitor\"\n"
    )
    agent = sub.add_parser(
        "agent",
        aliases=["agents"],
        help="Agent operations.",
        description="List agents, chat, run workflows, and manage role functions for a specific agent.",
        epilog=agent_examples,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    agent.add_argument(
        "agent_ref",
        nargs="?",
        help="Agent name/id, or `list`, `roles`, `function` shortcuts.",
    )
    agent.add_argument(
        "agent_mode",
        nargs="?",
        choices=("function", "roles", "stats"),
        help="Optional mode: `function` manages role functions, `roles` lists roles, `stats` shows dashboard metrics.",
    )
    agent.add_argument(
        "function_action",
        nargs="?",
        choices=("list",),
        help="Function action. Use `list` to show available functions with Enabled status.",
    )
    agent.add_argument("--project")
    agent.add_argument("--chat", help="Ask the selected agent a question.")
    agent.add_argument("--run", help="Run a function/workflow on the selected agent.")
    agent.add_argument(
        "--enable",
        help="Enable a role function by name or ID (use with `function`).",
    )
    agent.add_argument(
        "--disable",
        help="Disable an enabled function by name or ID (use with `function`).",
    )
    agent.add_argument(
        "--no-wait",
        action="store_true",
        help="Return immediately with execution GUID when running a function.",
    )
    agent.add_argument("--timeout", type=int, default=300)
    agent.add_argument("--poll-interval", type=int, default=2)
    agent.add_argument(
        "--list",
        action="store_true",
        help="Alias for `function list`.",
    )
    agent.add_argument(
        "--functions",
        action="store_true",
        dest="role_functions",
        help="With `agent roles`, list role functions and IDs.",
    )
    agent.add_argument("-o", "--output", choices=("json", "table"), default="table")

    connectors = sub.add_parser("connectors", help="Connector operations.")
    connectors_sub = connectors.add_subparsers(dest="connectors_command")
    connectors_list = connectors_sub.add_parser("list", help="List available connectors.")
    connectors_list.add_argument(
        "-o", "--output", choices=("json", "table"), default="table"
    )
    connectors_list.add_argument(
        "--raw",
        action="store_true",
        help="Return full backend connector payload.",
    )
    connectors_show = connectors_sub.add_parser(
        "show",
        help="Show configured connections for a connector (name/default/id).",
    )
    connectors_show.add_argument("connector_ref", nargs="?")
    connectors_show.add_argument("--project")
    connectors_show.add_argument(
        "-o",
        "--output",
        choices=("json", "table"),
        default="table",
    )
    connectors_describe = connectors_sub.add_parser(
        "describe",
        help="Describe connector requirements.",
    )
    connectors_describe.add_argument("connector_ref", nargs="?")
    connectors_describe.add_argument(
        "-o",
        "--output",
        choices=("json", "table"),
        default="table",
    )
    connectors_add = connectors_sub.add_parser("add", help="Open OAuth flow for connector.")
    connectors_add.add_argument("connector_type")
    connectors_add.add_argument(
        "--frontend-url",
        help="Optional frontend base URL override (defaults from configured API URL).",
    )

    policy = sub.add_parser("policy", help="Policy management operations.")
    policy_sub = policy.add_subparsers(dest="policy_command")

    policy_sync = policy_sub.add_parser("sync", help="Sync local .rego policies to backend.")
    policy_sync.add_argument("--repo", required=True, help="Git repository URL.")
    policy_sync.add_argument("--branch", default="main", help="Git branch to sync.")
    policy_sync.add_argument(
        "--path",
        default="/raia/policies/",
        help="Path within local repo containing .rego files.",
    )
    policy_sync.add_argument("--commit", required=True, help="Commit SHA.")
    policy_sync.add_argument(
        "--auto-assignment",
        action="store_true",
        help="Auto-assign policies to tool credentials based on tool_cred_guid in .rego files.",
    )
    policy_sync.add_argument("--token-name", help="Basic auth token name (or TOKEN_NAME env var).")
    policy_sync.add_argument(
        "--token-secret",
        help="Basic auth token secret (or TOKEN_SECRET env var).",
    )
    policy_sync.add_argument("-o", "--output", choices=("json", "table"), default="table")

    policy_list = policy_sub.add_parser("list", help="List synced policies in project.")
    policy_list.add_argument("--project", help="Project GUID (defaults to current project).")
    policy_list.add_argument(
        "--active-only",
        choices=("true", "false"),
        default="true",
        help="Show only active policies.",
    )
    policy_list.add_argument("--name-filter")
    policy_list.add_argument("--phase-filter", choices=("pre", "post"))
    policy_list.add_argument("--connector-filter")
    policy_list.add_argument("--repo-id")
    policy_list.add_argument("--filename-filter")
    policy_list.add_argument("--policy-guid")
    policy_list.add_argument("-o", "--output", choices=("json", "table"), default="table")

    policy_test = policy_sub.add_parser(
        "test",
        help="Parse and validate local .rego policy files without uploading.",
    )
    policy_test.add_argument("--repo", required=True, help="Git repository URL.")
    policy_test.add_argument("--branch", default="main", help="Git branch.")
    policy_test.add_argument(
        "--path",
        default="/raia/policies/",
        help="Path within local repo containing .rego files.",
    )
    policy_test.add_argument("--commit", required=True, help="Commit SHA.")
    policy_test.add_argument("--project-guid")
    policy_test.add_argument("-o", "--output", choices=("json", "table"), default="table")

    config_cmd = sub.add_parser("config", help="CLI config operations.")
    config_sub = config_cmd.add_subparsers(dest="config_command")
    config_list = config_sub.add_parser("list", help="Show current configuration and auth.")
    config_list.add_argument("-o", "--output", choices=("json", "table"), default="table")

    apply_cmd = sub.add_parser("apply", help="Apply assistant config from YAML.")
    apply_cmd.add_argument("-f", "--file")
    apply_cmd.add_argument("--project")
    apply_cmd.add_argument("--dry-run", action="store_true")
    apply_cmd.add_argument("-o", "--output", choices=("json", "table"), default="table")

    sub.add_parser("version", help="Show CLI version.")

    completion = sub.add_parser("completion", help="Print shell completion instructions.")
    completion.add_argument("shell", nargs="?", choices=("bash", "zsh", "auto"), default="auto")
    completion.add_argument(
        "--install",
        action="store_true",
        help="Install completion into your shell rc file automatically.",
    )

    telemetry = sub.add_parser("telemetry", help="Enable or disable CLI telemetry.")
    telemetry.add_argument("state", choices=("on", "off"))

    lineage = sub.add_parser("lineage", help="Manage repository lineage capture.")
    lineage_sub = lineage.add_subparsers(dest="lineage_command")
    lineage_enable = lineage_sub.add_parser(
        "enable", help="Enable lineage capture in the target git repository."
    )
    lineage_enable.add_argument("--repo", help="Repository path (defaults to current directory git root).")
    lineage_enable.add_argument("--mode", choices=sorted(_LINEAGE_MODES), default="metadata-only")
    lineage_enable.add_argument("--project", help="Project GUID override for background sync.")
    lineage_enable.add_argument("-o", "--output", choices=("json", "table"), default="table")

    lineage_disable = lineage_sub.add_parser(
        "disable", help="Disable lineage capture in the target git repository."
    )
    lineage_disable.add_argument("--repo", help="Repository path (defaults to current directory git root).")
    lineage_disable.add_argument("--keep-config", action="store_true")
    lineage_disable.add_argument("-o", "--output", choices=("json", "table"), default="table")

    lineage_status = lineage_sub.add_parser(
        "status", help="Show lineage capture status for the target repository."
    )
    lineage_status.add_argument("--repo", help="Repository path (defaults to current directory git root).")
    lineage_status.add_argument("-o", "--output", choices=("json", "table"), default="table")

    lineage_capture = lineage_sub.add_parser(
        "capture", help=argparse.SUPPRESS
    )
    lineage_capture.add_argument("--repo")
    lineage_capture.add_argument("--hook", default=LINEAGE_HOOK)
    lineage_capture.add_argument("--commit-msg-file")

    lineage_watch = lineage_sub.add_parser("watch", help=argparse.SUPPRESS)
    lineage_watch.add_argument("--repo")
    lineage_watch.add_argument("--project")
    lineage_watch.add_argument("--interval", type=int, default=10)
    lineage_watch.add_argument("--once", action="store_true")

    lineage_sync = lineage_sub.add_parser("sync", help="Sync locally captured lineage events to backend.")
    lineage_sync.add_argument("--repo", help="Repository path (defaults to current directory git root).")
    lineage_sync.add_argument("--project", help="Project GUID (defaults to current configured project).")
    lineage_sync.add_argument("--batch-size", type=int, default=100)
    lineage_sync.add_argument(
        "--token-name",
        help="Basic auth token name for lineage sync (or LINEAGE_TOKEN_NAME env var).",
    )
    lineage_sync.add_argument(
        "--token-secret",
        help="Basic auth token secret for lineage sync (or LINEAGE_TOKEN_SECRET env var).",
    )
    lineage_sync.add_argument("-o", "--output", choices=("json", "table"), default="table")

    return parser


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    argv = _rewrite_legacy_argv(argv)
    parser = _build_parser()
    args = parser.parse_args(argv)
    _configure_ui(
        getattr(args, "no_color", False),
        getattr(args, "verbose", False),
        getattr(args, "quiet", False),
    )
    config = load_config()
    _apply_env_override(config, getattr(args, "env", None))
    if not config.base_url:
        config.base_url = DEFAULT_API_URL

    command = args.command or "help"
    _maybe_prompt_completion_install(config, command)
    success = False
    error_code: str | None = None
    http_status: int | None = None
    error_category: str | None = None
    backend_message_hash: str | None = None
    subcommand = _resolve_subcommand(args)
    try:
        if args.command == "login":
            rc = _handle_login(args, config)
            success = rc == 0
            return rc
        if args.command == "logout":
            rc = _handle_logout(config)
            success = rc == 0
            return rc
        if args.command == "signup":
            rc = _handle_signup(args, config)
            success = rc == 0
            return rc
        if args.command == "projects":
            rc = _handle_projects(args, config)
            success = rc == 0
            return rc
        if args.command in {"agent", "agents"}:
            rc = _handle_agent(args, config)
            success = rc == 0
            return rc
        if args.command == "policy":
            if args.policy_command == "sync":
                rc = _handle_policy_sync(args, config)
                success = rc == 0
                return rc
            if args.policy_command == "list":
                rc = _handle_policy_list(args, config)
                success = rc == 0
                return rc
            if args.policy_command == "test":
                rc = _handle_policy_test(args, config)
                success = rc == 0
                return rc
            parser.print_help()
            return 1
        if args.command == "connectors":
            if args.connectors_command in (None, "list"):
                if not getattr(args, "output", None):
                    args.output = "table"
                rc = _handle_connectors_list(args, config)
                success = rc == 0
                return rc
            if args.connectors_command == "show":
                rc = _handle_connectors_show(args, config)
                success = rc == 0
                return rc
            if args.connectors_command == "describe":
                rc = _handle_connectors_describe(args, config)
                success = rc == 0
                return rc
            if args.connectors_command == "add":
                rc = _handle_connectors_add(args, config)
                success = rc == 0
                return rc
        if args.command == "config" and args.config_command == "list":
            rc = _handle_config_list(args, config)
            success = rc == 0
            return rc
        if args.command == "apply":
            rc = _handle_apply(args, config)
            success = rc == 0
            return rc
        if args.command == "version":
            print(__version__)
            success = True
            return 0
        if args.command == "completion":
            detected_shell = _detect_shell(args.shell)
            if getattr(args, "install", False):
                rc = _install_completion_script(detected_shell)
                success = rc == 0
                return rc
            print(_render_completion_script(detected_shell))
            success = True
            return 0
        if args.command == "telemetry":
            rc = _handle_telemetry_toggle(args, config)
            success = rc == 0
            return rc
        if args.command == "lineage":
            if args.lineage_command == "enable":
                rc = _handle_lineage_enable(args, config)
                success = rc == 0
                return rc
            if args.lineage_command == "disable":
                rc = _handle_lineage_disable(args, config)
                success = rc == 0
                return rc
            if args.lineage_command == "status":
                rc = _handle_lineage_status(args, config)
                success = rc == 0
                return rc
            if args.lineage_command == "capture":
                rc = _handle_lineage_capture(args, config)
                success = rc == 0
                return rc
            if args.lineage_command == "sync":
                rc = _handle_lineage_sync(args, config)
                success = rc == 0
                return rc
            if args.lineage_command == "watch":
                rc = _handle_lineage_watch(args, config)
                success = rc == 0
                return rc
            parser.print_help()
            return 1
        parser.print_help()
        return 1
    except APIError as e:
        _print_status(
            "error",
            str(e),
            next_step="Run `sense-cli --help` to check command usage and flags.",
            stream=sys.stderr,
        )
        error_code = "api_error"
        http_status = e.status_code
        error_category = _categorize_api_error(e)
        backend_message_hash = _message_hash(e.message)
        return 1
    except KeyboardInterrupt:
        error_code = "keyboard_interrupt"
        error_category = "interrupt"
        return 130
    except Exception as e:
        _print_status(
            "error",
            f"Unexpected error: {e}",
            next_step="Retry with `-o json` and check backend logs if issue persists.",
            stream=sys.stderr,
        )
        error_code = "unexpected_error"
        error_category = "unexpected"
        backend_message_hash = _message_hash(str(e))
        return 1
    finally:
        if command not in {"telemetry", "help"}:
            flags = {
                k: v
                for k, v in vars(args).items()
                if k != "command" and v not in (None, False, "")
            }
            _send_telemetry(
                config,
                command=command,
                success=success,
                error_code=error_code,
                http_status=http_status,
                error_category=error_category,
                backend_message_hash=backend_message_hash,
                subcommand=subcommand,
                flags=flags,
            )


if __name__ == "__main__":
    raise SystemExit(main())

