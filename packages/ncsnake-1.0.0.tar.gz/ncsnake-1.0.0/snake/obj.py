class snake:
        def __init__(self):
                x=0
                y=0
                self.kilia=[]
                self.kilia.append([x,y])
                self.kilia.append([x+1,y])
                self.dir="down"
                self.boukia=[]
                
                
                
                
        def up(self):
                self.dir="up"
        def down(self):
            self.dir="down"
        def left(self):
           self.dir="left"
        def right(self):
            self.dir="right"
        def get_bigger(self):
    
            teil = self.kilia[-1][:] 
            self.kilia.append(teil)
        def eat(self):
            
            self.boukia.append(0) 
                 #self.get_bigger()
        def move(self):
        
            head = self.kilia[0][:] 
            if self.dir == "up":
                head[0] -= 1 
                if head[0]<0:
                     head[0]=15
            elif self.dir == "down":
                head[0] += 1
                if head[0]>15:
                     head[0]=0
            elif self.dir == "right":
                head[1] += 1
                if head[1]>17:
                     head[1]=0
            elif self.dir == "left":
                head[1] -= 1
                if head[1]<0:
                     head[1]=17

            self.kilia.insert(0, head)
            self.kilia.pop()
            
            for i in range(len(self.boukia)):
                self.boukia[i] += 1

            
            new_boukia = []
            for b in self.boukia:
                if b < len(self.kilia):
                    new_boukia.append(b)
                else:
                    self.get_bigger()   

            self.boukia = new_boukia
            
        

class food:
        def __init__(self,_x,_y):
            self.x=_x
            self.y=_y
        def set_xy(self,_x,_y):
            self.x=_x
            self.y=_y