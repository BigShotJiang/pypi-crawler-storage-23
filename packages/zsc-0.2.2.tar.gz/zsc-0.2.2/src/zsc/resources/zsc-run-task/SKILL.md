---
name: zsc-run-task
description: Skill for executing a task: implement TODOs, update task file, and mark completion. Use when the user wants to run a task, do the work, implement TODO items, or finish a task. Task creation and design is handled by zsc-create-task.
---

# zsc-run-task

**Scope: execute and run a task.** This skill takes an existing task (from `.agents/tasks/task_{no}_{feat_name}/`), works through its TODO_LIST step by step, updates the task file as items are done, and when all TODOs are complete performs the task completion steps. Task **creation and design** (闭环描述, TODO_LIST design) are handled by **zsc-create-task**; this skill only runs the task.

## Scope boundary (mandatory, highest priority)

**Whenever this skill is used, regardless of the user's prompt:**
- **Allowed**: Work on **one** chosen task only: read that task's 闭环描述 and TODO_LIST and the project codebase; edit that task's `.md` under `.agents/tasks/` (e.g. mark TODOs done, write completion record); implement TODOs by modifying project code (e.g. `src/`, `tests/`) as required by the task.
- **Not allowed**: Create new tasks or new task directories under `.agents/tasks` (use **zsc-create-task**). Do not change the design (闭环描述 / TODO_LIST structure) of other tasks; only execute the selected task and update that task's file and project code as needed.

## When to use

- User wants to "run" a task, "execute" a task, or "do" a task.
- User wants to implement the TODOs of a task (e.g. "做 task_02 的 TODO").
- User wants to make progress on or finish a specific task.
- User says they want to work on a task and actually complete the work.

Do **not** use this for creating a new task or only designing/editing the TODO list without doing the work—use **zsc-create-task** for that.

## Task file location

- Task dir: `.agents/tasks/task_{no}_{feat_name}/`
- Task file: canonical name is same as directory, e.g. `task_01_scan_plugin/task_01_scan_plugin.md` (unique for @ reference in AI tools); legacy `task.md` is supported when reading.

## Workflow

### 1. Identify the task

- If the user named a task (e.g. "task_02", "zsc_task_cli"), open that task's directory and its task file: `{task_dir_name}.md` (e.g. `task_02_foo.md`), or legacy `task.md` if present.
- If unclear, list tasks (e.g. suggest `zsc task list`) and ask which one to run, or pick the most relevant open task.

### 2. Read 闭环描述 and TODO_LIST

- Read the closed-loop description to understand the target resource and lifecycle.
- Read the TODO_LIST. Work only on unchecked `- [ ]` items.

### 3. Implement TODOs one by one

- Take the first (or next) unchecked `- [ ]` item.
- Do the work: write code, add tests, update docs, etc., as the item requires.
- After completing an item:
  - Mark it done in the task file: change `- [ ]` to `- [x]` for that item, or remove it and keep the list current (per project habit).
  - Optionally add a short note or commit.
- Proceed to the next unchecked item. Confirm with the user when appropriate (e.g. after a big step).

### 4. Task completion (when all TODOs are done)

When there are **no remaining unchecked `- [ ]` items** for this round:

1. **Rewrite the `## TODO_LIST` section** (do not only tick boxes).
2. **Keep** the maintenance note line:
   - `> 只维护最新版本；完成后清空 TODO，仅保留"完成记录 + 日期"。`
3. Keep a single line indicating this round is done, e.g.:
   - `- （本轮已完成，TODO 清空）`
4. Add **one line completion record with date**, e.g.:
   - `- 2026-02-24：Brief summary of what was done this round.`
5. **Remove** all previous `- [ ]` / `- [x]` items so only the maintenance note and the new completion record remain.
6. If `task_records/log` has only intermediate files, clear its contents (keep the directory).
7. If the lifecycle changed after this round, **update the 闭环描述** so it reflects current behavior.

## Notes

- **zsc-run-task** = execute and complete a task. **zsc-create-task** = create and design a task (no execution).
- Prefer one or a few TODOs per run unless the user asks to do the whole task in one go.
- When in doubt, run one TODO, update the file, then continue.
