---
name: zsc-update-task
description: Skill for updating an existing task's content (闭环描述, TODO_LIST, etc.) when it becomes stale. Edit-only; does not execute TODOs—use zsc-run-task for execution. Use when the user wants to refresh a task's context, update 闭环描述 or TODO_LIST, or revise task design without running the task.
---

# zsc-update-task

**Scope: update (edit) an existing task only.** This skill revises a task under `.agents/tasks/`: update 闭环描述, TODO_LIST, or other sections so the task reflects current context (e.g. after codebase changes or when the task has gone stale). It **does not** implement TODOs or run the task—use **zsc-run-task** for execution. Task **creation** is handled by **zsc-create-task**.

## Scope boundary (mandatory, highest priority)

**Whenever this skill is used, regardless of the user's prompt:**
- **Allowed**: Read the project (including `.agents/tasks` and codebase) to understand context; **edit only** the chosen task's files under `.agents/tasks/` (e.g. the task's `.md` file, or content under `task_records/log/`). Update 闭环描述, TODO_LIST structure and items, or other task content so the task stays accurate and actionable.
- **Not allowed**: Create new task directories (use **zsc-create-task**). Do not implement TODOs or modify project code outside `.agents/tasks` (use **zsc-run-task** for that). This skill is for **editing the task document only**.
- Even if the user explicitly asks to "change code", "implement TODO", or "modify the feature", you must **only** update task content under `.agents/tasks/` and **never** touch code or tests outside that directory.

## When to use

- User says the task is "stale" (过期) or wants to "update" or "refresh" a task.
- User wants to revise 闭环描述 or TODO_LIST based on current codebase/context.
- User wants to change task design (add/remove/reorder TODO items, update lifecycle description) without doing the work—edit the task file only.

Do **not** use for creating a new task (**zsc-create-task**) or for executing TODOs (**zsc-run-task**).

## Task file location

- Task dir: `.agents/tasks/task_{no}_{feat_name}/`
- Task file: canonical name is same as directory, e.g. `task_01_scan_plugin/task_01_scan_plugin.md` (unique for @ reference); legacy `task.md` supported when reading.

## Workflow

### 1. Identify the task to update

- If the user named a task (e.g. "task_02", "zsc_task_cli"), open that task's directory and its `.md` file.
- If unclear, list tasks (e.g. run `zsc task list`) and ask which one to update, or pick the most relevant one.

### 2. Gather current context

- Read the task's current 闭环描述 and TODO_LIST.
- Optionally read the codebase or user's prompt to understand what has changed or what should be reflected (e.g. new modules, renamed APIs).

### 3. Edit the task file only

- **Update 闭环描述** if the target resource or lifecycle has changed—keep it accurate with current behavior.
- **Update TODO_LIST**: add, remove, reorder, or reword items; keep the maintenance note. Do **not** implement the items (no code changes outside `.agents/tasks`).
- Save changes to the task's `.md` (and optionally to `task_records/log/` if you add notes there).

### 4. Confirm

- Summarize what was updated (e.g. "已更新闭环描述与 3 条 TODO"). Remind the user that to **execute** the task they should use **zsc-run-task**.

## Notes

- **zsc-update-task** = edit task content only (闭环描述, TODO_LIST, etc.). **zsc-run-task** = execute the task and modify project code.
- Always keep the TODO_LIST maintenance note: `> 只维护最新版本；完成后清空 TODO，仅保留"完成记录 + 日期"。` and the completion marker line when present.
