from __future__ import annotations

__all__ = ["__version__"]

try:
    # Python 3.8+
    from importlib.metadata import PackageNotFoundError, version
except ImportError:  # pragma: no cover - Python < 3.8 fallback
    # Backport for Python 3.7
    from importlib_metadata import PackageNotFoundError, version  # type: ignore


try:
    __version__ = version("zsc")
except PackageNotFoundError:
    # Fallback for editable installs without distribution metadata; keep in sync with pyproject.toml
    __version__ = "0.1.6"

