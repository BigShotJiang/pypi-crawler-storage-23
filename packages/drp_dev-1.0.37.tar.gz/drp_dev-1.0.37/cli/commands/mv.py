"""mv — Rename or move a file within the drive."""

from . import Arg, Command, register

cmd = register(Command(
    name="mv",
    description="Rename or move a file within the drive. No re-upload — server-side update.",
    shell_only=True,
    args=(
        Arg("src",
            "Current drive path or filename.",
            required=True),
        Arg("dest",
            "New drive path or filename.",
            required=True),
    ),
))


def run(shell, args_str):
    """Rename or move a file within the drive."""
    from cli.session import api_get, api_patch, check_auth

    if not check_auth(shell):
        return

    args = args_str.strip().split() if args_str.strip() else []
    if len(args) < 2:
        shell.poutput("usage: mv <src> <dest>")
        return

    src, dest = args[0], args[1]

    # Check if src is a folder
    path = shell.cwd.strip("/")
    params = {"path": path} if path else {}
    resp = api_get("/api/v1/folders/", params=params)
    if resp.status_code == 200:
        data = resp.json()
        for folder in data.get("folders", []):
            if folder.get("name") == src or folder.get("slug") == src:
                resp2 = api_patch(f"/api/v1/folders/{folder['id']}/",
                                  json={"name": dest})
                if resp2.status_code == 200:
                    shell.poutput(f"  renamed: {src} → {dest}")
                else:
                    shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
                return

    # File move: download, re-upload with new name, delete old
    import requests
    from cli.session import api_delete, api_post

    key = src
    for f in resp.json().get("files", []) if resp.status_code == 200 else []:
        if f.get("filename") == src and f.get("key"):
            key = f["key"]
            break

    detail = api_get(f"/api/v1/keys/{key}/")
    if detail.status_code != 200:
        shell.poutput(f"  not found: {src}")
        return

    info = detail.json()
    url = info.get("download_url")
    if not url:
        shell.poutput("  error: no download URL")
        return

    r = requests.get(url)
    folder = shell.cwd.strip("/")
    fname = dest if "." in dest else info.get("filename", key)
    resp2 = api_post("/api/v1/keys/", files={"file": (fname, r.content)},
                     data={"folder": folder, "key": dest if "." not in dest else ""})
    if resp2.status_code not in (200, 201):
        shell.poutput(f"  error: {resp2.json().get('error', resp2.status_code)}")
        return

    api_delete(f"/api/v1/keys/{key}/")
    d = resp2.json()
    shell.poutput(f"  moved: {src} → {d.get('key', dest)}")
