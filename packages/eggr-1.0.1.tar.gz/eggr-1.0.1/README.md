# eggr

A Python package that extracts the longest reachable increasing sequence from a list of numbers where each step cannot exceed a specified distance.

This is my fourth python library :D

Commands:

eggr.eggr(list,intiger) # Intiger determines the max jump length, and it favours bigger jumps, but if there aren't any bigger ones, it will do the biggest jump that isnt bigger than the maximum jump length.

!NB!

Use: pip install eggr

But, to import it to python: import eggr
