import os

import setuptools

module = os.environ.get("MODULE")

if module == "kili-common-storage":
    setuptools.setup(
        name="kili-common-storage",
        version="1.0.1",
        author="Ken.Hu",
        author_email="ken.hu@kilimall.com",
        description="A storage package for kilimall lite",
        long_description="",
        long_description_content_type="text/markdown",
        url="",
        packages=setuptools.find_packages(),
        classifiers=[
            "Programming Language :: Python :: 3",
            "License :: OSI Approved :: MIT License",
            "Operating System :: OS Independent",
        ],
        install_requires=[
            "esdk-obs-python==3.22.2",
            "opencv-python==4.6.0.66"
        ]
    )
