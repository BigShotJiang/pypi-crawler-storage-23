"""Management commands for Django Observability."""
