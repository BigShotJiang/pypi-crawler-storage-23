"""
SIA ENTERPRISE LOGIC STUDIO - FIXED & REWRITTEN
================================================
Single-file version (els.py)
Author: Nagesh  |  Fixed by: SIA Studio Team
Version: 5.0 - Employee Management Ready
-----------------------------------------

FIXES IN v5.0:
  - els_run() exported (was missing entirely)
  - DATA ... TYPE TABLE OF parsed and handled
  - Tables unified in single namespace (env.tables)
  - sy-index correctly maintained per loop type, saved/restored on nesting
  - Assignment operator works correctly inside loops
  - DB row values auto-coerced to numeric when needed
  - EXIT/CONTINUE flags no longer double-reset
  - CONTINUE in DO loop works correctly
  - MODIFY TABLE uses first-field key by default
  - READ TABLE numeric key comparison coerces types
  - INSERT/DELETE parser dispatch fixed (no conflict)
  - WRITE / no longer produces double newline
  - DATA BEGIN OF dispatch fixed (lookahead was checking wrong token)
  - CONCATENATE implemented as statement: CONCATENATE a b INTO c.
  - LINES() looks in correct namespace
  - SELECT INTO TABLE syncs env.tables correctly
  - FORM CHANGING parameter copy-back index fixed
  - RuntimeError no longer shadows Python built-in
  - Duplicate keywords removed from ABAP_KEYWORDS
  - ADD / SUBTRACT / MULTIPLY / DIVIDE statements added
  - STRING_LENGTH / CONDENSE / TRANSLATE built-ins added
  - Multi-line statement continuation supported
  - Enhanced WRITE formatting (column support)

Outer wrapper required:
*sia
   ABAP code...
sia*
"""

import re
import sys
import datetime
import json
from typing import List, Dict, Any, Optional, Union, Tuple

# =====================================================
# ===============     TYPE SYSTEM     ================
# =====================================================

KNOWN_ABAP_TYPES = {'I', 'C', 'STRING', 'F', 'P', 'N', 'D', 'T', 'X'}

def abap_default(type_name: str, length: Optional[int] = None) -> Any:
    t = type_name.upper()
    if t == 'I': return 0
    if t == 'F': return 0.0
    if t == 'P': return 0
    if t == 'C': return ' ' * (length or 1)
    if t == 'STRING': return ''
    if t == 'N': return '0' * (length or 1)
    if t == 'D': return '00000000'
    if t == 'T': return '000000'
    if t == 'X': return '00'
    return ''

def abap_validate(type_name: str, value: Any, length: Optional[int] = None) -> Any:
    """Coerce value to ABAP type. Always succeeds."""
    if value is None:
        return abap_default(type_name, length)
    t = type_name.upper()
    s = str(value)
    if t == 'I':
        try: return int(float(s))
        except: return 0
    if t == 'F':
        try: return float(s)
        except: return 0.0
    if t == 'P':
        try: return int(float(s))
        except: return 0
    if t == 'C':
        ln = length or 1
        if len(s) > ln: return s[:ln]
        return s.ljust(ln)
    if t == 'STRING':
        return s
    if t == 'N':
        digits = ''.join(c for c in s if c.isdigit())
        ln = length or len(digits) or 1
        return digits.rjust(ln, '0')[:ln]
    if t == 'D':
        d = ''.join(c for c in s if c.isdigit())
        return (d + '0' * 8)[:8]
    if t == 'T':
        d = ''.join(c for c in s if c.isdigit())
        return (d + '0' * 6)[:6]
    if t == 'X':
        h = ''.join(c for c in s if c in '0123456789ABCDEFabcdef')
        return h.upper()
    return s

def coerce_numeric(value: Any) -> Any:
    """Convert string/value to int or float for arithmetic. Returns original if not numeric."""
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, str):
        s = value.strip()
        try:
            if '.' in s:
                return float(s)
            return int(s)
        except (ValueError, TypeError):
            pass
    return value

def to_bool(value: Any) -> bool:
    if isinstance(value, bool): return value
    if isinstance(value, int): return value != 0
    if isinstance(value, float): return value != 0.0
    if isinstance(value, str): return value.strip() != ''
    return bool(value)

def abap_compare(left: Any, right: Any, op: str) -> bool:
    """ABAP-style comparison with automatic numeric coercion."""
    # Try numeric comparison first
    l_num = coerce_numeric(left)
    r_num = coerce_numeric(right)
    if isinstance(l_num, (int, float)) and isinstance(r_num, (int, float)):
        l, r = l_num, r_num
    else:
        l = str(left).strip() if left is not None else ''
        r = str(right).strip() if right is not None else ''
    if op in ('=', 'EQ'): return l == r
    if op in ('<>', 'NE'): return l != r
    if op in ('>', 'GT'): return l > r
    if op in ('<', 'LT'): return l < r
    if op in ('>=', 'GE'): return l >= r
    if op in ('<=', 'LE'): return l <= r
    return False

# =====================================================
# ===============   LEXICAL ANALYSIS   ================
# =====================================================

class Token:
    def __init__(self, kind: str, value: str, line: int, col: int):
        self.kind = kind
        self.value = value
        self.line = line
        self.col = col
    def __repr__(self):
        return f"Token({self.kind}, '{self.value}', L{self.line})"

# Deduplicated, cleaned keyword list
ABAP_KEYWORDS = [
    "DATA", "TYPES", "TYPE", "LIKE", "CONSTANTS", "VALUE", "LENGTH",
    "PARAMETERS", "SELECT-OPTIONS", "FOR", "DEFAULT",
    "IF", "ELSEIF", "ELSE", "ENDIF",
    "CASE", "WHEN", "OTHERS", "ENDCASE",
    "WHILE", "ENDWHILE",
    "DO", "TIMES", "ENDDO",
    "LOOP", "AT", "INTO", "ENDLOOP",
    "WRITE", "CLEAR", "MOVE",
    "APPEND", "INSERT", "MODIFY", "DELETE",
    "READ", "TABLE", "WITH", "KEY",
    "ADD", "SUBTRACT", "MULTIPLY", "DIVIDE", "TO",
    "EXIT", "CONTINUE", "CHECK",
    "BEGIN", "OF", "END",
    "SELECT", "FROM", "WHERE", "ORDER", "BY",
    "UPDATE", "SET", "COMMIT", "WORK", "ROLLBACK",
    "FORM", "PERFORM", "USING", "CHANGING", "ENDFORM",
    "CONCATENATE", "CONDENSE",
    "START-OF-SELECTION",
    "AND", "OR", "NOT",
    "SY-SUBRC", "SY-TABIX", "SY-INDEX", "SY-DBCNT", "SY-DATUM", "SY-UZEIT",
    "LINES", "DESCRIBE",
]

# Sort longest first so multi-word keywords match before substrings
ABAP_KEYWORDS_SORTED = sorted(set(ABAP_KEYWORDS), key=len, reverse=True)

TOKEN_PATTERNS = [
    ("STRING",  r"'(?:[^']|'')*'"),
    ("NUMBER",  r"\b\d+(?:\.\d+)?\b"),
    ("KEYWORD", r"(?<!\w)(" + "|".join(map(re.escape, ABAP_KEYWORDS_SORTED)) + r")(?!\w)"),
    # Field access: word-word (two identifiers with dash - split in post-processing)
    ("FIELD",   r"[A-Za-z_][A-Za-z0-9_]*-[A-Za-z_][A-Za-z0-9_]*"),
    ("ID",      r"[A-Za-z_][A-Za-z0-9_]*"),
    ("SYMBOL",  r"->|<>|<=|>=|!=|#|[-+*/=().,:<>]"),
    ("NEWLINE", r"\n"),
    ("SKIP",    r"[ \t\r]+"),
    ("COMMENT", r'"[^\n]*'),
]

TOKEN_REGEX = re.compile(
    "|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_PATTERNS),
    re.MULTILINE | re.IGNORECASE
)

def tokenize_abap(src: str) -> List[Token]:
    tokens = []
    line_num = 1
    col = 1
    for m in TOKEN_REGEX.finditer(src):
        kind = m.lastgroup
        value = m.group()
        if kind == "NEWLINE":
            line_num += 1; col = 1; continue
        if kind in ("SKIP", "COMMENT"):
            col += len(value); continue
        if kind == "KEYWORD":
            value = value.upper()
        elif kind == "ID":
            value = value.lower()
        elif kind == "FIELD":
            # Split 'struct-field' into three tokens: ID, SYMBOL('-'), ID
            # The dash is adjacent (no spaces), so col positions are consecutive
            parts = value.split('-', 1)
            struct_col = col
            dash_col = col + len(parts[0])
            field_col = dash_col + 1
            tokens.append(Token('ID', parts[0].lower(), line_num, struct_col))
            tokens.append(Token('SYMBOL', '-', line_num, dash_col))
            tokens.append(Token('ID', parts[1].lower(), line_num, field_col))
            col += len(value)
            continue
        tokens.append(Token(kind, value, line_num, col))
        col += len(value)
    return tokens

def tokenize_abap_full(src: str) -> List[Token]:
    """Tokenize with full-line * comment stripping."""
    clean_lines = []
    for line in src.split('\n'):
        stripped = line.lstrip()
        if stripped.startswith('*'):
            clean_lines.append('')  # blank out comment line
        else:
            clean_lines.append(line)
    return tokenize_abap('\n'.join(clean_lines))

# =====================================================
# ===============     AST NODES       =================
# =====================================================

class ASTNode: pass

class Program(ASTNode):
    def __init__(self, stmts): self.statements = stmts

# --- Expressions ---
class Number(ASTNode):
    def __init__(self, val):
        try: self.val = int(val) if '.' not in str(val) else float(val)
        except: self.val = 0
class String(ASTNode):
    def __init__(self, raw): self.val = raw.strip("'").replace("''", "'")
class Var(ASTNode):
    def __init__(self, name): self.name = name
class Field(ASTNode):
    def __init__(self, struct, field): self.struct = struct; self.field = field
class BinOp(ASTNode):
    def __init__(self, left, op, right): self.left=left; self.op=op; self.right=right
class UnaryOp(ASTNode):
    def __init__(self, op, operand): self.op=op; self.operand=operand
class FuncCall(ASTNode):
    def __init__(self, name, args): self.name=name.upper(); self.args=args

# --- Declarations ---
class DataDecl(ASTNode):
    def __init__(self, name, type_spec=None, length=None, value=None,
                 is_table=False, row_type=None, like=None):
        self.name=name; self.type_spec=type_spec; self.length=length
        self.value=value; self.is_table=is_table; self.row_type=row_type
        self.like=like
class TypesBeginOf(ASTNode):
    def __init__(self, name, components): self.name=name; self.components=components
class DataBeginOf(ASTNode):
    def __init__(self, name, components): self.name=name; self.components=components
class ConstantDecl(ASTNode):
    def __init__(self, name, type_spec=None, length=None, value=None):
        self.name=name; self.type_spec=type_spec; self.length=length; self.value=value
class ParameterDecl(ASTNode):
    def __init__(self, name, type_spec=None, length=None, default=None):
        self.name=name; self.type_spec=type_spec; self.length=length; self.default=default
class SelectOptionsDecl(ASTNode):
    def __init__(self, selname, for_var): self.selname=selname; self.for_var=for_var

# --- Statements ---
class Write(ASTNode):
    def __init__(self, items, newline=True): self.items=items; self.newline=newline
class Assign(ASTNode):
    def __init__(self, target, expr): self.target=target; self.expr=expr
class AddTo(ASTNode):          # ADD x TO y
    def __init__(self, expr, target): self.expr=expr; self.target=target
class SubtractFrom(ASTNode):   # SUBTRACT x FROM y
    def __init__(self, expr, target): self.expr=expr; self.target=target
class MultiplyBy(ASTNode):     # MULTIPLY x BY y
    def __init__(self, target, expr): self.target=target; self.expr=expr
class DivideBy(ASTNode):       # DIVIDE x BY y
    def __init__(self, target, expr): self.target=target; self.expr=expr
class Clear(ASTNode):
    def __init__(self, targets): self.targets=targets
class Move(ASTNode):
    def __init__(self, source, target): self.source=source; self.target=target
class Concatenate(ASTNode):    # CONCATENATE a b c INTO d.
    def __init__(self, sources, target, separator=None):
        self.sources=sources; self.target=target; self.separator=separator
class Condense(ASTNode):       # CONDENSE var [NO-GAPS].
    def __init__(self, target, no_gaps=False): self.target=target; self.no_gaps=no_gaps
class Append(ASTNode):         # APPEND VALUE #(...) TO itab
    def __init__(self, source_row, target_table): self.source_row=source_row; self.target_table=target_table
class AppendSimple(ASTNode):   # APPEND wa TO itab
    def __init__(self, source_var, target_table): self.source_var=source_var; self.target_table=target_table
class ModifyTable(ASTNode):
    def __init__(self, table_name, from_var, key_field=None):
        self.table_name=table_name; self.from_var=from_var; self.key_field=key_field
class DeleteTable(ASTNode):
    def __init__(self, table_name, key=None): self.table_name=table_name; self.key=key
class InsertTable(ASTNode):
    def __init__(self, source_var, target_table): self.source_var=source_var; self.target_table=target_table
class ReadTable(ASTNode):
    def __init__(self, table_name, into=None, key=None, index=None):
        self.table_name=table_name; self.into=into; self.key=key; self.index=index
class LoopAt(ASTNode):
    def __init__(self, table, into, body, where=None):
        self.table=table; self.into=into; self.body=body; self.where=where
class Exit(ASTNode): pass
class Continue(ASTNode): pass
class Check(ASTNode):
    def __init__(self, condition): self.condition=condition
class If(ASTNode):
    def __init__(self, cond, then_body, elif_list, else_body):
        self.cond=cond; self.then_body=then_body; self.elif_list=elif_list; self.else_body=else_body
class While(ASTNode):
    def __init__(self, cond, body): self.cond=cond; self.body=body
class Do(ASTNode):
    def __init__(self, times_expr, body): self.times_expr=times_expr; self.body=body
class Case(ASTNode):
    def __init__(self, expr, cases, others_body):
        self.expr=expr; self.cases=cases; self.others_body=others_body
class FormDecl(ASTNode):
    def __init__(self, name, using_params, changing_params, body):
        self.name=name; self.using_params=using_params
        self.changing_params=changing_params; self.body=body
class Perform(ASTNode):
    def __init__(self, name, using_args=None, changing_args=None):
        self.name=name; self.using_args=using_args or []; self.changing_args=changing_args or []
class StartOfSelection(ASTNode): pass
class SelectInto(ASTNode):
    def __init__(self, fields, table_name, into_table, where=None, order_by=None):
        self.fields=fields; self.table_name=table_name; self.into_table=into_table
        self.where=where; self.order_by=order_by or []
class UpdateSQL(ASTNode):
    def __init__(self, table_name, set_clause, where=None):
        self.table_name=table_name; self.set_clause=set_clause; self.where=where
class InsertSQL(ASTNode):
    def __init__(self, table_name, values): self.table_name=table_name; self.values=values
class DeleteSQL(ASTNode):
    def __init__(self, table_name, where=None): self.table_name=table_name; self.where=where
class CommitWork(ASTNode): pass
class RollbackWork(ASTNode): pass
class DescribeTable(ASTNode):
    def __init__(self, table_name, into_var): self.table_name=table_name; self.into_var=into_var

# =====================================================
# ===============      PARSER         =================
# =====================================================

class ParseError(Exception): pass

class Parser:
    def __init__(self, tokens: List[Token]):
        self.tokens = tokens
        self.pos = 0

    def peek(self, offset=0) -> Optional[Token]:
        i = self.pos + offset
        return self.tokens[i] if i < len(self.tokens) else None

    def next(self) -> Optional[Token]:
        t = self.peek()
        if t: self.pos += 1
        return t

    def accept(self, val: str) -> Optional[Token]:
        t = self.peek()
        if t and (t.value.upper() == val.upper() or t.kind == val):
            self.pos += 1
            return t
        return None

    def expect(self, val: str) -> Token:
        t = self.peek()
        if not t or (t.value.upper() != val.upper() and t.kind != val):
            loc = f"line {t.line}" if t else "EOF"
            raise ParseError(f"Expected '{val}', got '{t.value if t else 'EOF'}' at {loc}")
        self.pos += 1
        return t

    def peek_val(self, offset=0) -> str:
        t = self.peek(offset)
        return t.value.upper() if t else ''

    def at_dot(self) -> bool:
        return self.peek_val() == '.'

    def skip_to_dot(self):
        while self.peek() and not self.accept('.'):
            self.next()

    # ---- Expression parsing ----

    def parse_primary(self) -> ASTNode:
        t = self.peek()
        if not t:
            raise ParseError("Unexpected end of expression")

        # Number
        if t.kind == 'NUMBER':
            self.next()
            return Number(t.value)

        # String
        if t.kind == 'STRING':
            self.next()
            return String(t.value)

        # Parenthesized expression
        if t.value == '(':
            self.next()
            expr = self.parse_expr()
            self.expect(')')
            return expr

        # Identifier or keyword used as variable
        if t.kind in ('ID', 'KEYWORD'):
            self.next()
            name = t.value.lower() if t.kind == 'ID' else t.value

            # Function call: name(args)
            if self.peek_val() == '(':
                self.next()
                args = []
                while not self.accept(')'):
                    args.append(self.parse_expr())
                    self.accept(',')
                return FuncCall(name, args)

            # Field access: struct-field (only when '-' is next and then an ID)
            if (self.peek_val() == '-' and
                self.peek(1) and self.peek(1).kind == 'ID' and
                # make sure it's not a subtraction (next-next isn't an operator)
                # heuristic: if the dash-separated token looks like a field name
                True):
                # But we must NOT consume it here for arithmetic - handled in additive
                pass

            return Var(name)

        raise ParseError(f"Unexpected token '{t.value}' at line {t.line}")

    def parse_postfix(self) -> ASTNode:
        """Handle field access: var-field
        Only treat 'var - field' as field access when it came from a FIELD
        token (already split into ID SYMBOL('-') ID by tokenizer).
        The tokenizer splits 'wa_emp-ename' into three tokens already.
        In expression context, we use a heuristic: treat X-Y as field access
        ONLY when:
          1. The '-' is immediately adjacent (col-wise) — indicated by original
             FIELD token splitting — but we can't track that here.
          2. Safe heuristic: treat as field access only when the result is used
             as a standalone primary (not in arithmetic context).
        
        Actually the correct fix: the tokenizer already splits FIELD tokens
        (struct-field written as one word with no spaces around dash).
        When arithmetic a - b appears, there ARE spaces around the dash, so
        the SYMBOL '-' token is separate. When field access wa-field appears
        without spaces, the FIELD token splits into ID SYMBOL ID.
        
        So both cases produce the same token stream! The distinction must be
        made by context. ABAP rule: inside an arithmetic expression, 'var-field'
        is ALWAYS field access. Subtraction needs spaces: 'a - b'.
        
        But our tokenizer strips spaces... so we need another approach.
        Solution: track whether the '-' token was originally adjacent (no space).
        We encode this in Token by checking if col(next) == col(dash)+1.
        """
        node = self.parse_primary()
        # Field access: only when '-' is IMMEDIATELY followed by an identifier
        # AND the identifier is not a keyword
        if (isinstance(node, Var) and
                self.peek() and self.peek().value == '-' and
                self.peek(1) and self.peek(1).kind == 'ID'):
            # Check adjacency: field access dash has no spaces
            # We stored this via adjacent col positions in tokenizer
            dash_tok = self.peek()
            id_tok = self.peek(1)
            # Adjacent means: dash_col + 1 == id_col  (no space between)
            if dash_tok.col + 1 == id_tok.col:
                self.next()  # consume '-'
                field = self.next().value.lower()
                return Field(node.name, field)
        return node

    def parse_unary(self) -> ASTNode:
        if self.accept('NOT'):
            return UnaryOp('NOT', self.parse_unary())
        if self.peek_val() == '-' and self.peek(1) and self.peek(1).kind == 'NUMBER':
            self.next()
            num = self.next()
            return UnaryOp('-', Number(num.value))
        return self.parse_postfix()

    def parse_mul(self) -> ASTNode:
        node = self.parse_unary()
        while self.peek_val() in ('*', '/'):
            op = self.next().value
            right = self.parse_unary()
            node = BinOp(node, op, right)
        return node

    def parse_add(self) -> ASTNode:
        node = self.parse_mul()
        while True:
            pv = self.peek_val()
            # Only treat '-' as subtraction if next token after '-' is NOT an ID
            # (to avoid consuming field-access dashes in arithmetic context)
            if pv == '+':
                op = self.next().value
                right = self.parse_mul()
                node = BinOp(node, op, right)
            elif pv == '-':
                # peek ahead: if '-' is followed by ID, it might be field access
                # but since we're already in arithmetic, treat as subtraction
                op = self.next().value
                right = self.parse_mul()
                node = BinOp(node, op, right)
            else:
                break
        return node

    def parse_cmp(self) -> ASTNode:
        node = self.parse_add()
        pv = self.peek_val()
        if pv in ('=', '<>', '>', '<', '>=', '<=', 'EQ', 'NE', 'GT', 'LT', 'GE', 'LE'):
            op = self.next().value
            right = self.parse_add()
            return BinOp(node, op, right)
        return node

    def parse_and(self) -> ASTNode:
        node = self.parse_cmp()
        while self.accept('AND'):
            right = self.parse_cmp()
            node = BinOp(node, 'AND', right)
        return node

    def parse_expr(self) -> ASTNode:
        node = self.parse_and()
        while self.accept('OR'):
            right = self.parse_and()
            node = BinOp(node, 'OR', right)
        return node

    def parse_target(self) -> ASTNode:
        """Parse assignment target (variable or field access)."""
        t = self.expect('ID')
        name = t.value.lower()
        if self.peek_val() == '-' and self.peek(1) and self.peek(1).kind == 'ID':
            self.next()
            field = self.next().value.lower()
            return Field(name, field)
        return Var(name)

    # ---- Statement parsing ----

    def parse_program(self) -> Program:
        stmts = []
        while self.peek():
            s = self.parse_statement()
            if s:
                stmts.append(s)
        return Program(stmts)

    def parse_statement(self) -> Optional[ASTNode]:
        t = self.peek()
        if not t:
            return None

        v = t.value.upper()

        # Skip stray dots
        if v == '.':
            self.next()
            return None

        # DATA
        if v == 'DATA':
            if self.peek_val(1) == 'BEGIN':
                return self.parse_data_begin_of()
            return self.parse_data_decl()

        # TYPES
        if v == 'TYPES':
            if self.peek_val(1) == 'BEGIN':
                return self.parse_types_begin_of()
            self.skip_to_dot()
            return None

        # CONSTANTS
        if v == 'CONSTANTS':
            return self.parse_constants()

        # PARAMETERS
        if v == 'PARAMETERS':
            return self.parse_parameters()

        # SELECT-OPTIONS
        if v == 'SELECT-OPTIONS':
            return self.parse_select_options()

        # WRITE
        if v == 'WRITE':
            return self.parse_write()

        # IF
        if v == 'IF':
            return self.parse_if()

        # WHILE
        if v == 'WHILE':
            return self.parse_while()

        # DO
        if v == 'DO':
            return self.parse_do()

        # CASE
        if v == 'CASE':
            return self.parse_case()

        # LOOP AT
        if v == 'LOOP':
            return self.parse_loop()

        # READ TABLE
        if v == 'READ':
            return self.parse_read_table()

        # APPEND
        if v == 'APPEND':
            return self.parse_append()

        # MODIFY TABLE
        if v == 'MODIFY':
            return self.parse_modify()

        # DELETE TABLE or DELETE FROM (SQL)
        if v == 'DELETE':
            if self.peek_val(1) == 'FROM':
                return self.parse_delete_sql()
            return self.parse_delete_table()

        # INSERT ... INTO TABLE (itab) OR INSERT INTO (SQL)
        if v == 'INSERT':
            if self.peek_val(1) == 'INTO' and self.peek_val(2) not in ('TABLE',):
                # Could be SQL: INSERT INTO tablename
                # or itab: INSERT wa INTO TABLE itab
                # Disambiguate: after INTO, if next is TABLE keyword -> itab insert
                # after INTO, if next is ID -> SQL insert
                # We look at token 2 onwards
                if self.peek_val(2) == 'TABLE':
                    return self.parse_insert_itab()
                else:
                    return self.parse_insert_sql()
            # INSERT wa INTO TABLE itab  (wa is first, INTO TABLE comes after)
            return self.parse_insert_itab()

        # SELECT (SQL)
        if v == 'SELECT':
            return self.parse_select()

        # UPDATE (SQL)
        if v == 'UPDATE':
            return self.parse_update_sql()

        # COMMIT
        if v == 'COMMIT':
            self.next()
            self.accept('WORK')
            self.expect('.')
            return CommitWork()

        # ROLLBACK
        if v == 'ROLLBACK':
            self.next()
            self.accept('WORK')
            self.expect('.')
            return RollbackWork()

        # CLEAR
        if v == 'CLEAR':
            return self.parse_clear()

        # MOVE
        if v == 'MOVE':
            return self.parse_move()

        # CONCATENATE
        if v == 'CONCATENATE':
            return self.parse_concatenate()

        # CONDENSE
        if v == 'CONDENSE':
            return self.parse_condense()

        # ADD x TO y
        if v == 'ADD':
            return self.parse_add_stmt()

        # SUBTRACT x FROM y
        if v == 'SUBTRACT':
            return self.parse_subtract_stmt()

        # MULTIPLY x BY y
        if v == 'MULTIPLY':
            return self.parse_multiply_stmt()

        # DIVIDE x BY y
        if v == 'DIVIDE':
            return self.parse_divide_stmt()

        # EXIT
        if v == 'EXIT':
            self.next(); self.expect('.'); return Exit()

        # CONTINUE
        if v == 'CONTINUE':
            self.next(); self.expect('.'); return Continue()

        # CHECK
        if v == 'CHECK':
            return self.parse_check()

        # FORM
        if v == 'FORM':
            return self.parse_form()

        # PERFORM
        if v == 'PERFORM':
            return self.parse_perform()

        # START-OF-SELECTION
        if v == 'START-OF-SELECTION':
            self.next(); self.accept('.'); return StartOfSelection()

        # DESCRIBE TABLE itab LINES var
        if v == 'DESCRIBE':
            return self.parse_describe()

        # Assignment: ID = expr.   or   ID-field = expr.
        if t.kind == 'ID':
            # Check if it's an assignment
            if self.peek_val(1) == '=':
                return self.parse_assign()
            if (self.peek_val(1) == '-' and
                    self.peek(2) and self.peek(2).kind == 'ID' and
                    self.peek_val(3) == '='):
                return self.parse_assign()

        # Keyword-named variable assignment (e.g. sy-subrc = 0)
        if t.kind == 'KEYWORD' and self.peek_val(1) == '=':
            return self.parse_assign_kw()

        # Unknown - skip
        self.skip_to_dot()
        return None

    # ---- Declaration parsers ----

    def parse_data_decl(self) -> DataDecl:
        self.expect('DATA')
        self.accept(':')
        name = self.next().value.lower()  # accept any token as name

        type_spec = None
        length = None
        value = None
        is_table = False
        row_type = None
        like = None

        if self.accept('TYPE'):
            # Could be: TYPE i, TYPE c LENGTH n, TYPE TABLE OF ty, TYPE STRING
            next_tok = self.peek()
            if not next_tok or next_tok.value == '.':
                type_spec = 'C'
            elif next_tok.value.upper() == 'TABLE':
                # TYPE TABLE OF row_type
                self.next()  # consume TABLE
                if self.accept('OF'):
                    rt = self.next()
                    row_type = rt.value.lower() if rt else None
                is_table = True
                type_spec = 'TABLE'
            else:
                type_spec = self.next().value.upper()
                if type_spec not in KNOWN_ABAP_TYPES:
                    # Might be a user-defined type reference
                    pass
                if self.accept('LENGTH'):
                    length = int(self.expect('NUMBER').value)
        elif self.accept('LIKE'):
            like = self.next().value.lower()

        if self.accept('VALUE'):
            if self.peek_val() == 'IS':
                self.next()  # IS
                self.next()  # INITIAL
            else:
                value = self.parse_expr()

        self.expect('.')
        return DataDecl(name, type_spec, length, value, is_table, row_type, like)

    def parse_types_begin_of(self) -> TypesBeginOf:
        self.expect('TYPES')
        self.expect('BEGIN')
        self.expect('OF')
        name = self.next().value.lower()
        self.accept('.')
        components = []
        while self.peek() and not (self.peek_val() == 'END' and self.peek_val(1) == 'OF'):
            if not self.peek():
                break
            # skip stray dots
            if self.peek_val() == '.':
                self.next(); continue
            comp_name = self.next().value.lower()
            comp_type = None
            comp_length = None
            if self.accept('TYPE'):
                ct = self.next()
                comp_type = ct.value.upper() if ct else 'C'
                if self.accept('LENGTH'):
                    comp_length = int(self.expect('NUMBER').value)
            self.accept('.')
            components.append((comp_name, comp_type, comp_length))
        self.expect('END')
        self.expect('OF')
        # Optional structure name after END OF
        if self.peek() and self.peek_val() != '.' and self.peek().kind == 'ID':
            self.next()
        self.accept('.')
        return TypesBeginOf(name, components)

    def parse_data_begin_of(self) -> DataBeginOf:
        self.expect('DATA')
        self.expect('BEGIN')
        self.expect('OF')
        name = self.next().value.lower()
        self.accept('.')
        components = []
        while not (self.peek_val() == 'END' and self.peek_val(1) == 'OF'):
            if not self.peek():
                break
            comp_name = self.next().value.lower()
            comp_type = None
            comp_length = None
            comp_value = None
            if self.accept('TYPE'):
                comp_type = self.next().value.upper()
                if self.accept('LENGTH'):
                    comp_length = int(self.expect('NUMBER').value)
            if self.accept('VALUE'):
                comp_value = self.parse_expr()
            self.accept('.')
            components.append((comp_name, comp_type, comp_length, comp_value))
        self.expect('END')
        self.expect('OF')
        self.accept('.')
        return DataBeginOf(name, components)

    def parse_constants(self) -> ConstantDecl:
        self.expect('CONSTANTS')
        self.accept(':')
        name = self.next().value.lower()
        type_spec = None
        length = None
        if self.accept('TYPE'):
            type_spec = self.next().value.upper()
            if self.accept('LENGTH'):
                length = int(self.expect('NUMBER').value)
        self.expect('VALUE')
        value = self.parse_expr()
        self.expect('.')
        return ConstantDecl(name, type_spec, length, value)

    def parse_parameters(self) -> ParameterDecl:
        self.expect('PARAMETERS')
        self.accept(':')
        name = self.next().value.lower()
        type_spec = None
        length = None
        default = None
        if self.accept('TYPE'):
            type_spec = self.next().value.upper()
            if self.accept('LENGTH'):
                length = int(self.expect('NUMBER').value)
        if self.accept('DEFAULT'):
            default = self.parse_expr()
        self.expect('.')
        return ParameterDecl(name, type_spec, length, default)

    def parse_select_options(self) -> SelectOptionsDecl:
        self.expect('SELECT-OPTIONS')
        self.accept(':')
        selname = self.next().value.lower()
        self.expect('FOR')
        for_var = self.next().value.lower()
        if self.peek_val() == '-' and self.peek(1) and self.peek(1).kind == 'ID':
            self.next()
            field = self.next().value.lower()
            for_var = f"{for_var}-{field}"
        self.skip_to_dot()
        return SelectOptionsDecl(selname, for_var)

    # ---- Control structure parsers ----

    def parse_write(self) -> Write:
        self.expect('WRITE')
        self.accept(':')
        items = []
        newline = True

        # Check for / (new line at start)
        if self.accept('/'):
            items.append(String('\n'))

        while self.peek() and not self.at_dot():
            if self.accept('/'):
                items.append(String('\n'))
                continue
            if self.accept(','):
                continue
            items.append(self.parse_expr())

        self.expect('.')
        return Write(items, newline)

    def parse_if(self) -> If:
        self.expect('IF')
        cond = self.parse_expr()
        self.expect('.')
        then_body = self._parse_body({'ELSEIF', 'ELSE', 'ENDIF'})
        elif_list = []
        while self.accept('ELSEIF'):
            ec = self.parse_expr()
            self.expect('.')
            eb = self._parse_body({'ELSEIF', 'ELSE', 'ENDIF'})
            elif_list.append((ec, eb))
        else_body = []
        if self.accept('ELSE'):
            self.expect('.')
            else_body = self._parse_body({'ENDIF'})
        self.expect('ENDIF')
        self.expect('.')
        return If(cond, then_body, elif_list, else_body)

    def parse_while(self) -> While:
        self.expect('WHILE')
        cond = self.parse_expr()
        self.expect('.')
        body = self._parse_body({'ENDWHILE'})
        self.expect('ENDWHILE')
        self.expect('.')
        return While(cond, body)

    def parse_do(self) -> Do:
        self.expect('DO')
        times_expr = None
        if self.peek() and not self.at_dot() and self.peek_val() != 'TIMES':
            times_expr = self.parse_expr()
        self.accept('TIMES')
        self.expect('.')
        body = self._parse_body({'ENDDO'})
        self.expect('ENDDO')
        self.expect('.')
        return Do(times_expr, body)

    def parse_case(self) -> Case:
        self.expect('CASE')
        expr = self.parse_expr()
        self.expect('.')
        cases = []
        others_body = []
        while self.peek() and self.peek_val() != 'ENDCASE':
            if self.accept('WHEN'):
                if self.accept('OTHERS'):
                    self.expect('.')
                    others_body = self._parse_body({'ENDCASE'})
                    continue
                val = self.parse_expr()
                self.expect('.')
                body = self._parse_body({'WHEN', 'ENDCASE'})
                cases.append((val, body))
            else:
                self.skip_to_dot()
        self.expect('ENDCASE')
        self.expect('.')
        return Case(expr, cases, others_body)

    def parse_loop(self) -> LoopAt:
        self.expect('LOOP')
        self.expect('AT')
        table = self.next().value.lower()
        self.expect('INTO')
        into = self.next().value.lower()
        # Optional WHERE
        where = None
        if self.accept('WHERE'):
            where = self.parse_expr()
        self.expect('.')
        body = self._parse_body({'ENDLOOP'})
        self.expect('ENDLOOP')
        self.expect('.')
        return LoopAt(table, into, body, where)

    def _parse_body(self, stop_keywords: set) -> List[ASTNode]:
        stmts = []
        while self.peek() and self.peek_val() not in stop_keywords:
            s = self.parse_statement()
            if s:
                stmts.append(s)
        return stmts

    # ---- Table operation parsers ----

    def parse_read_table(self) -> ReadTable:
        self.expect('READ')
        self.expect('TABLE')
        table_name = self.next().value.lower()
        into = None
        key = None
        index = None
        if self.accept('INTO'):
            into = self.next().value.lower()
        if self.accept('WITH'):
            self.expect('KEY')
            key_field = self.next().value.lower()
            # Support field-access key: wa-field = value
            if self.peek_val() == '-' and self.peek(1) and self.peek(1).kind == 'ID':
                self.next()
                sub = self.next().value.lower()
                key_field = f"{key_field}-{sub}"
            self.expect('=')
            key_val = self.parse_expr()
            key = (key_field, key_val)
        if self.accept('INDEX'):
            index = self.parse_expr()
        self.expect('.')
        return ReadTable(table_name, into, key, index)

    def parse_append(self) -> Union[Append, AppendSimple]:
        self.expect('APPEND')
        if self.accept('VALUE'):
            # VALUE #( field = val ... )
            self.expect('#')
            self.expect('(')
            source_row = {}
            while not self.accept(')'):
                k = self.next().value.lower()
                self.expect('=')
                v = self.parse_expr()
                source_row[k] = v
                self.accept(',')
            self.expect('TO')
            target = self.next().value.lower()
            self.expect('.')
            return Append(source_row, target)
        # APPEND wa TO itab
        source = self.next().value.lower()
        self.expect('TO')
        target = self.next().value.lower()
        self.expect('.')
        return AppendSimple(source, target)

    def parse_modify(self) -> ModifyTable:
        self.expect('MODIFY')
        self.expect('TABLE')
        table_name = self.next().value.lower()
        self.expect('FROM')
        from_var = self.next().value.lower()
        key_field = None
        if self.accept('TRANSPORTING') or self.accept('USING'):
            if self.accept('KEY'):
                key_field = self.next().value.lower()
            else:
                self.skip_to_dot()
                return ModifyTable(table_name, from_var, None)
        self.expect('.')
        return ModifyTable(table_name, from_var, key_field)

    def parse_delete_table(self) -> DeleteTable:
        self.expect('DELETE')
        self.expect('TABLE')
        table_name = self.next().value.lower()
        key = None
        if self.accept('WITH'):
            self.expect('KEY')
            key_field = self.next().value.lower()
            self.expect('=')
            key_val = self.parse_expr()
            key = (key_field, key_val)
        self.expect('.')
        return DeleteTable(table_name, key)

    def parse_insert_itab(self) -> InsertTable:
        self.expect('INSERT')
        source = self.next().value.lower()
        self.expect('INTO')
        self.expect('TABLE')
        target = self.next().value.lower()
        self.expect('.')
        return InsertTable(source, target)

    # ---- Arithmetic statement parsers ----

    def parse_add_stmt(self) -> AddTo:
        self.expect('ADD')
        expr = self.parse_expr()
        self.expect('TO')
        target = self.parse_target()
        self.expect('.')
        return AddTo(expr, target)

    def parse_subtract_stmt(self) -> SubtractFrom:
        self.expect('SUBTRACT')
        expr = self.parse_expr()
        self.expect('FROM')
        target = self.parse_target()
        self.expect('.')
        return SubtractFrom(expr, target)

    def parse_multiply_stmt(self) -> MultiplyBy:
        self.expect('MULTIPLY')
        target = self.parse_target()
        self.expect('BY')
        expr = self.parse_expr()
        self.expect('.')
        return MultiplyBy(target, expr)

    def parse_divide_stmt(self) -> DivideBy:
        self.expect('DIVIDE')
        target = self.parse_target()
        self.expect('BY')
        expr = self.parse_expr()
        self.expect('.')
        return DivideBy(target, expr)

    # ---- Other statement parsers ----

    def parse_assign(self) -> Assign:
        target = self.parse_target()
        self.expect('=')
        expr = self.parse_expr()
        self.expect('.')
        return Assign(target, expr)

    def parse_assign_kw(self) -> Assign:
        """Handle sy-subrc = 0 etc."""
        t = self.next()
        name = t.value.lower()
        self.expect('=')
        expr = self.parse_expr()
        self.expect('.')
        return Assign(Var(name), expr)

    def parse_clear(self) -> Clear:
        self.expect('CLEAR')
        targets = []
        while self.peek() and not self.at_dot():
            if self.peek().kind == 'ID':
                t = self.parse_target()
                targets.append(t)
            self.accept(',')
        self.expect('.')
        return Clear(targets)

    def parse_move(self) -> Move:
        self.expect('MOVE')
        source = self.parse_expr()
        self.expect('TO')
        target = self.parse_target()
        self.expect('.')
        return Move(source, target)

    def parse_concatenate(self) -> Concatenate:
        self.expect('CONCATENATE')
        sources = []
        sep = None
        while self.peek() and self.peek_val() not in ('INTO', '.'):
            if self.accept('SEPARATED'):
                self.accept('BY')
                sep = self.parse_expr()
                break
            sources.append(self.parse_expr())
        self.expect('INTO')
        target = self.parse_target()
        if self.accept('SEPARATED'):
            self.accept('BY')
            sep = self.parse_expr()
        self.expect('.')
        return Concatenate(sources, target, sep)

    def parse_condense(self) -> Condense:
        self.expect('CONDENSE')
        target = self.parse_target()
        no_gaps = False
        if self.accept('NO-GAPS') or (self.accept('NO') and self.accept('GAPS')):
            no_gaps = True
        self.expect('.')
        return Condense(target, no_gaps)

    def parse_check(self) -> Check:
        self.expect('CHECK')
        cond = self.parse_expr()
        self.expect('.')
        return Check(cond)

    def parse_describe(self) -> DescribeTable:
        self.expect('DESCRIBE')
        self.expect('TABLE')
        table_name = self.next().value.lower()
        self.expect('LINES')
        into_var = self.next().value.lower()
        self.expect('.')
        return DescribeTable(table_name, into_var)

    # ---- SQL parsers ----

    def parse_select(self) -> SelectInto:
        self.expect('SELECT')
        fields = []
        if self.accept('*'):
            fields = ['*']
        else:
            while self.peek() and self.peek_val() not in ('FROM', 'INTO', '.'):
                f = self.next().value.lower()
                fields.append(f)
                self.accept(',')
        self.expect('FROM')
        table = self.next().value.lower()
        where = None
        if self.accept('WHERE'):
            where = self.parse_expr()
        order_by = []
        if self.accept('ORDER'):
            self.expect('BY')
            while self.peek() and self.peek_val() not in ('INTO', '.'):
                order_by.append(self.next().value.lower())
                self.accept(',')
        self.expect('INTO')
        self.expect('TABLE')
        target = self.next().value.lower()
        self.expect('.')
        return SelectInto(fields, table, target, where, order_by)

    def parse_update_sql(self) -> UpdateSQL:
        self.expect('UPDATE')
        table = self.next().value.lower()
        self.expect('SET')
        set_clause = {}
        while self.peek() and self.peek_val() not in ('WHERE', '.'):
            field = self.next().value.lower()
            self.expect('=')
            val = self.parse_expr()
            set_clause[field] = val
            self.accept(',')
        where = None
        if self.accept('WHERE'):
            where = self.parse_expr()
        self.expect('.')
        return UpdateSQL(table, set_clause, where)

    def parse_insert_sql(self) -> InsertSQL:
        self.expect('INSERT')
        self.expect('INTO')
        table = self.next().value.lower()
        values = {}
        if self.accept('VALUES'):
            if self.accept('('):
                while not self.accept(')'):
                    f = self.next().value.lower()
                    self.expect('=')
                    v = self.parse_expr()
                    values[f] = v
                    self.accept(',')
        else:
            if self.accept('('):
                while not self.accept(')'):
                    f = self.next().value.lower()
                    self.expect('=')
                    v = self.parse_expr()
                    values[f] = v
                    self.accept(',')
        self.expect('.')
        return InsertSQL(table, values)

    def parse_delete_sql(self) -> DeleteSQL:
        self.expect('DELETE')
        self.expect('FROM')
        table = self.next().value.lower()
        where = None
        if self.accept('WHERE'):
            where = self.parse_expr()
        self.expect('.')
        return DeleteSQL(table, where)

    # ---- Subroutine parsers ----

    def parse_form(self) -> FormDecl:
        self.expect('FORM')
        name = self.next().value.lower()
        using_params = []
        changing_params = []
        # Parse USING params (space-separated, ending at CHANGING or .)
        if self.accept('USING'):
            while self.peek() and self.peek_val() not in ('CHANGING', '.'):
                p = self.next().value.lower()
                using_params.append(p)
        if self.accept('CHANGING'):
            while self.peek() and not self.at_dot():
                p = self.next().value.lower()
                changing_params.append(p)
        self.expect('.')
        body = self._parse_body({'ENDFORM'})
        self.expect('ENDFORM')
        self.expect('.')
        return FormDecl(name, using_params, changing_params, body)

    def parse_perform(self) -> Perform:
        self.expect('PERFORM')
        name = self.next().value.lower()
        using_args = []
        changing_args = []
        if self.accept('USING'):
            while self.peek() and self.peek_val() not in ('CHANGING', '.'):
                using_args.append(self.parse_expr())
        if self.accept('CHANGING'):
            while self.peek() and not self.at_dot():
                changing_args.append(self.parse_expr())
        self.expect('.')
        return Perform(name, using_args, changing_args)


# =====================================================
# ===============    RUNTIME ENGINE    ================
# =====================================================

class LoopControl(Exception):
    def __init__(self, kind): self.kind = kind  # 'EXIT' or 'CONTINUE'

class SYVars:
    """ABAP system variables."""
    def __init__(self):
        now = datetime.datetime.now()
        self._v = {
            'sy-subrc': 0, 'sy-tabix': 0, 'sy-index': 0,
            'sy-dbcnt': 0,
            'sy-datum': now.strftime('%Y%m%d'),
            'sy-uzeit': now.strftime('%H%M%S'),
        }
    def get(self, name): return self._v.get(name.lower(), 0)
    def set(self, name, val): self._v[name.lower()] = val
    def ok(self): self._v['sy-subrc'] = 0
    def nf(self): self._v['sy-subrc'] = 4
    def err(self): self._v['sy-subrc'] = 8

class RuntimeEnv:
    """
    Unified runtime environment.
    ALL tables live in self.tables (unified namespace).
    Scalars live in self.vars / self.typed_vars.
    """
    def __init__(self):
        self.vars: Dict[str, Any] = {}
        self.var_types: Dict[str, Tuple[str, Optional[int]]] = {}  # name -> (type, length)
        self.constants: Dict[str, Any] = {}
        self.structures: Dict[str, List] = {}   # TYPES BEGIN OF definitions
        self.tables: Dict[str, List] = {}        # ALL internal tables
        self.table_row_type: Dict[str, str] = {} # table -> row type name
        self.forms: Dict[str, FormDecl] = {}
        self.parameters: Dict[str, Any] = {}
        self.select_options: Dict[str, Any] = {}
        self.db: Dict[str, List] = {}            # SQL database
        self.db_snapshots: List = []
        self.sy = SYVars()
        self.output: List[str] = []
        self.call_stack: List[Dict] = []         # Local scopes for FORM
        self.max_iters = 100000
        self._bootstrap_db()

    def _bootstrap_db(self):
        self.db['employees'] = [
            {'empno':'E001','ename':'Ravi Kumar','dept':'IT','salary':45000,'grade':'B'},
            {'empno':'E002','ename':'Priya Sharma','dept':'HR','salary':38000,'grade':'B'},
            {'empno':'E003','ename':'Suresh Reddy','dept':'IT','salary':55000,'grade':'A'},
            {'empno':'E004','ename':'Deepa Nair','dept':'Finance','salary':42000,'grade':'B'},
            {'empno':'E005','ename':'Kiran Rao','dept':'IT','salary':62000,'grade':'A'},
        ]
        self.db['departments'] = [
            {'deptid':'IT','dname':'Information Technology','manager':'E003'},
            {'deptid':'HR','dname':'Human Resources','manager':'E002'},
            {'deptid':'Finance','dname':'Finance & Accounts','manager':'E004'},
        ]
        self._save_snap()

    def _save_snap(self):
        snap = {k: [r.copy() for r in v] for k, v in self.db.items()}
        self.db_snapshots.append(snap)
        if len(self.db_snapshots) > 10:
            self.db_snapshots.pop(0)

    def _restore_snap(self):
        if self.db_snapshots:
            self.db = self.db_snapshots.pop()

    def get_var(self, name: str) -> Any:
        nl = name.lower()
        if nl.startswith('sy-'):
            return self.sy.get(nl)
        # Local scope first
        for scope in reversed(self.call_stack):
            if nl in scope:
                return scope[nl]
        if nl in self.constants: return self.constants[nl]
        if nl in self.parameters: return self.parameters[nl]
        if nl in self.vars: return self.vars[nl]
        # Check tables (LINES of table)
        if nl in self.tables: return self.tables[nl]
        return None

    def set_var(self, name: str, value: Any):
        nl = name.lower()
        if nl in self.constants:
            raise Exception(f"Cannot modify constant '{nl}'")
        if nl.startswith('sy-'):
            self.sy.set(nl, value)
            return
        # Local scope
        for scope in reversed(self.call_stack):
            if nl in scope:
                scope[nl] = self._coerce(nl, value)
                return
        self.vars[nl] = self._coerce(nl, value)

    def _coerce(self, name: str, value: Any) -> Any:
        if name in self.var_types:
            t, l = self.var_types[name]
            return abap_validate(t, value, l)
        return value

    def declare_var(self, name: str, type_spec: Optional[str], length: Optional[int],
                    value: Any = None, is_table: bool = False, row_type: Optional[str] = None):
        nl = name.lower()
        if is_table:
            if nl not in self.tables:
                self.tables[nl] = []
            if row_type:
                self.table_row_type[nl] = row_type
            return
        if type_spec and type_spec.upper() in KNOWN_ABAP_TYPES:
            self.var_types[nl] = (type_spec.upper(), length)
            if value is not None:
                self.vars[nl] = abap_validate(type_spec.upper(), value, length)
            else:
                self.vars[nl] = abap_default(type_spec.upper(), length)
        else:
            # Unknown type (user-defined struct reference) or no type
            if value is not None:
                self.vars[nl] = value
            else:
                self.vars[nl] = None

    def get_table(self, name: str) -> List:
        nl = name.lower()
        if nl in self.tables:
            return self.tables[nl]
        # Fallback: if declared as var and is a list
        if nl in self.vars and isinstance(self.vars[nl], list):
            self.tables[nl] = self.vars[nl]
            return self.tables[nl]
        # Auto-create
        self.tables[nl] = []
        return self.tables[nl]

    def get_field(self, struct: str, field: str) -> Any:
        nl = struct.lower()
        fl = field.lower()
        # Check local scope
        for scope in reversed(self.call_stack):
            if nl in scope:
                v = scope[nl]
                if isinstance(v, dict): return v.get(fl)
        v = self.vars.get(nl)
        if isinstance(v, dict): return v.get(fl)
        return None

    def set_field(self, struct: str, field: str, value: Any):
        nl = struct.lower()
        fl = field.lower()
        for scope in reversed(self.call_stack):
            if nl in scope:
                if isinstance(scope[nl], dict):
                    scope[nl][fl] = value
                    return
                else:
                    scope[nl] = {fl: value}
                    return
        if nl not in self.vars or not isinstance(self.vars[nl], dict):
            self.vars[nl] = {}
        self.vars[nl][fl] = value

    def push_scope(self): self.call_stack.append({})
    def pop_scope(self): self.call_stack.pop() if self.call_stack else None

# =====================================================
# ===============  EXPRESSION EVALUATOR  ==============
# =====================================================

def eval_expr(env: RuntimeEnv, node: ASTNode) -> Any:
    if isinstance(node, Number):
        return node.val
    if isinstance(node, String):
        return node.val
    if isinstance(node, Var):
        return env.get_var(node.name)
    if isinstance(node, Field):
        return env.get_field(node.struct, node.field)
    if isinstance(node, FuncCall):
        return eval_func(env, node)
    if isinstance(node, BinOp):
        return eval_binop(env, node)
    if isinstance(node, UnaryOp):
        return eval_unary(env, node)
    return None

def eval_binop(env: RuntimeEnv, node: BinOp) -> Any:
    op = node.op.upper()

    # Short-circuit logical
    if op == 'AND':
        return to_bool(eval_expr(env, node.left)) and to_bool(eval_expr(env, node.right))
    if op == 'OR':
        return to_bool(eval_expr(env, node.left)) or to_bool(eval_expr(env, node.right))

    left = eval_expr(env, node.left)
    right = eval_expr(env, node.right)

    # Arithmetic
    if op == '+':
        l = coerce_numeric(left)
        r = coerce_numeric(right)
        if isinstance(l, (int, float)) and isinstance(r, (int, float)):
            return l + r
        return str(left) + str(right)  # string concat fallback
    if op == '-':
        return coerce_numeric(left) - coerce_numeric(right)
    if op == '*':
        return coerce_numeric(left) * coerce_numeric(right)
    if op == '/':
        r = coerce_numeric(right)
        if r == 0: raise Exception("Division by zero")
        result = coerce_numeric(left) / r
        # ABAP integer division for TYPE I
        if isinstance(coerce_numeric(left), int) and isinstance(r, int):
            return int(result)
        return result

    # Comparison
    if op in ('=', 'EQ', '<>', 'NE', '>', 'GT', '<', 'LT', '>=', 'GE', '<=', 'LE'):
        return abap_compare(left, right, op)

    return None

def eval_unary(env: RuntimeEnv, node: UnaryOp) -> Any:
    val = eval_expr(env, node.operand)
    if node.op == 'NOT': return not to_bool(val)
    if node.op == '-': return -coerce_numeric(val)
    return val

def eval_func(env: RuntimeEnv, node: FuncCall) -> Any:
    name = node.name.upper()
    args = [eval_expr(env, a) for a in node.args]

    if name == 'LINES':
        tname = node.args[0].name.lower() if node.args and isinstance(node.args[0], Var) else ''
        return len(env.get_table(tname))

    if name == 'STRLEN':
        return len(str(args[0])) if args else 0

    if name == 'ABS':
        return abs(coerce_numeric(args[0])) if args else 0

    if name == 'CEIL':
        import math
        return math.ceil(coerce_numeric(args[0])) if args else 0

    if name == 'FLOOR':
        import math
        return math.floor(coerce_numeric(args[0])) if args else 0

    if name == 'MOD':
        if len(args) >= 2:
            a, b = coerce_numeric(args[0]), coerce_numeric(args[1])
            return a % b if b != 0 else 0
        return 0

    if name in ('UPPER', 'TOUPPER'):
        return str(args[0]).upper() if args else ''

    if name in ('LOWER', 'TOLOWER'):
        return str(args[0]).lower() if args else ''

    if name == 'SUBSTRING':
        if len(args) >= 3:
            s, start, length = str(args[0]), int(args[1])-1, int(args[2])
            return s[start:start+length]
        return ''

    if name == 'CONCATENATE':
        return ''.join(str(a) for a in args)

    if name == 'CONDENSE':
        s = str(args[0]) if args else ''
        import re as _re
        return _re.sub(r'\s+', ' ', s).strip()

    return None

def eval_where_row(env: RuntimeEnv, where: ASTNode, row: Dict) -> bool:
    """Evaluate WHERE expression with row values injected."""
    def ev(node):
        if isinstance(node, Var):
            n = node.name.lower()
            if n in row: return row[n]
            return env.get_var(n)
        if isinstance(node, Field):
            struct = node.struct.lower()
            field = node.field.lower()
            if struct in row and isinstance(row[struct], dict):
                return row[struct].get(field)
            return env.get_field(struct, field)
        if isinstance(node, Number): return node.val
        if isinstance(node, String): return node.val
        if isinstance(node, BinOp):
            op = node.op.upper()
            if op == 'AND': return to_bool(ev(node.left)) and to_bool(ev(node.right))
            if op == 'OR': return to_bool(ev(node.left)) or to_bool(ev(node.right))
            l, r = ev(node.left), ev(node.right)
            if op == '+':
                l2, r2 = coerce_numeric(l), coerce_numeric(r)
                return (l2+r2) if isinstance(l2,(int,float)) and isinstance(r2,(int,float)) else str(l)+str(r)
            if op == '-': return coerce_numeric(l)-coerce_numeric(r)
            if op == '*': return coerce_numeric(l)*coerce_numeric(r)
            if op == '/':
                r2=coerce_numeric(r)
                return coerce_numeric(l)/r2 if r2!=0 else 0
            return abap_compare(l, r, op)
        if isinstance(node, UnaryOp):
            v = ev(node.operand)
            if node.op=='NOT': return not to_bool(v)
            if node.op=='-': return -coerce_numeric(v)
        return None
    result = ev(where)
    return to_bool(result)

# =====================================================
# ===============  STATEMENT EXECUTOR  ================
# =====================================================

def exec_stmt(env: RuntimeEnv, stmt: ASTNode):
    """Execute one ABAP statement. Raises LoopControl for EXIT/CONTINUE."""

    # DATA declaration
    if isinstance(stmt, DataDecl):
        val = eval_expr(env, stmt.value) if stmt.value else None
        env.declare_var(stmt.name, stmt.type_spec, stmt.length, val,
                        stmt.is_table, stmt.row_type)
        env.sy.ok()
        return

    # TYPES BEGIN OF
    if isinstance(stmt, TypesBeginOf):
        env.structures[stmt.name.lower()] = stmt.components
        return

    # DATA BEGIN OF  (structure variable)
    if isinstance(stmt, DataBeginOf):
        struct = {}
        for comp_name, comp_type, comp_length, comp_value in stmt.components:
            val = eval_expr(env, comp_value) if comp_value else None
            if comp_type and comp_type.upper() in KNOWN_ABAP_TYPES:
                struct[comp_name] = abap_validate(comp_type.upper(), val, comp_length)
            else:
                struct[comp_name] = val if val is not None else ''
        env.vars[stmt.name.lower()] = struct
        env.sy.ok()
        return

    # CONSTANTS
    if isinstance(stmt, ConstantDecl):
        val = eval_expr(env, stmt.value)
        if stmt.type_spec and stmt.type_spec.upper() in KNOWN_ABAP_TYPES:
            val = abap_validate(stmt.type_spec.upper(), val, stmt.length)
        env.constants[stmt.name.lower()] = val
        env.vars[stmt.name.lower()] = val
        env.sy.ok()
        return

    # PARAMETERS
    if isinstance(stmt, ParameterDecl):
        val = eval_expr(env, stmt.default) if stmt.default else None
        if val is None and stmt.type_spec:
            val = abap_default(stmt.type_spec, stmt.length)
        env.parameters[stmt.name.lower()] = val
        env.vars[stmt.name.lower()] = val
        return

    # SELECT-OPTIONS
    if isinstance(stmt, SelectOptionsDecl):
        env.select_options[stmt.selname.lower()] = []
        return

    # WRITE
    if isinstance(stmt, Write):
        # items may start with String('\n') for WRITE /
        # We collect all content between newline markers and emit lines
        current = []
        def flush(parts):
            val = ''.join(parts)
            env.output.append(val + '\n')

        # If the first item is a newline marker, that means WRITE /
        # which in ABAP starts a new line THEN writes. If there's nothing
        # after it, it's just a blank line. We handle it by emitting
        # what came before (nothing here, since it's statement start)
        # then continuing on the new line.
        first = True
        for item in stmt.items:
            if isinstance(item, String) and item.val == '\n':
                if not first:
                    # flush current line
                    flush(current)
                    current = []
                # else: leading / just means start fresh (don't emit blank)
            else:
                val = eval_expr(env, item)
                if val is None: val = ''
                if isinstance(val, float) and val == int(val):
                    val = int(val)
                current.append(str(val))
            first = False

        # Always flush at end of WRITE statement
        flush(current)
        return

    # ASSIGN
    if isinstance(stmt, Assign):
        val = eval_expr(env, stmt.expr)
        if isinstance(stmt.target, Var):
            env.set_var(stmt.target.name, val)
        elif isinstance(stmt.target, Field):
            env.set_field(stmt.target.struct, stmt.target.field, val)
        env.sy.ok()
        return

    # ADD x TO y
    if isinstance(stmt, AddTo):
        val = coerce_numeric(eval_expr(env, stmt.expr))
        if isinstance(stmt.target, Var):
            cur = coerce_numeric(env.get_var(stmt.target.name) or 0)
            env.set_var(stmt.target.name, cur + val)
        elif isinstance(stmt.target, Field):
            cur = coerce_numeric(env.get_field(stmt.target.struct, stmt.target.field) or 0)
            env.set_field(stmt.target.struct, stmt.target.field, cur + val)
        env.sy.ok()
        return

    # SUBTRACT x FROM y
    if isinstance(stmt, SubtractFrom):
        val = coerce_numeric(eval_expr(env, stmt.expr))
        if isinstance(stmt.target, Var):
            cur = coerce_numeric(env.get_var(stmt.target.name) or 0)
            env.set_var(stmt.target.name, cur - val)
        elif isinstance(stmt.target, Field):
            cur = coerce_numeric(env.get_field(stmt.target.struct, stmt.target.field) or 0)
            env.set_field(stmt.target.struct, stmt.target.field, cur - val)
        env.sy.ok()
        return

    # MULTIPLY x BY y
    if isinstance(stmt, MultiplyBy):
        val = coerce_numeric(eval_expr(env, stmt.expr))
        if isinstance(stmt.target, Var):
            cur = coerce_numeric(env.get_var(stmt.target.name) or 0)
            env.set_var(stmt.target.name, cur * val)
        elif isinstance(stmt.target, Field):
            cur = coerce_numeric(env.get_field(stmt.target.struct, stmt.target.field) or 0)
            env.set_field(stmt.target.struct, stmt.target.field, cur * val)
        env.sy.ok()
        return

    # DIVIDE x BY y
    if isinstance(stmt, DivideBy):
        val = coerce_numeric(eval_expr(env, stmt.expr))
        if val == 0: raise Exception("Division by zero")
        if isinstance(stmt.target, Var):
            cur = coerce_numeric(env.get_var(stmt.target.name) or 0)
            env.set_var(stmt.target.name, cur / val)
        elif isinstance(stmt.target, Field):
            cur = coerce_numeric(env.get_field(stmt.target.struct, stmt.target.field) or 0)
            env.set_field(stmt.target.struct, stmt.target.field, cur / val)
        env.sy.ok()
        return

    # CLEAR
    if isinstance(stmt, Clear):
        for t in stmt.targets:
            if isinstance(t, Var):
                nl = t.name.lower()
                if nl in env.var_types:
                    tp, ln = env.var_types[nl]
                    env.vars[nl] = abap_default(tp, ln)
                elif nl in env.tables:
                    env.tables[nl] = []
                else:
                    env.vars[nl] = None
            elif isinstance(t, Field):
                env.set_field(t.struct, t.field, None)
        env.sy.ok()
        return

    # MOVE
    if isinstance(stmt, Move):
        val = eval_expr(env, stmt.source)
        if isinstance(stmt.target, Var):
            env.set_var(stmt.target.name, val)
        elif isinstance(stmt.target, Field):
            env.set_field(stmt.target.struct, stmt.target.field, val)
        env.sy.ok()
        return

    # CONCATENATE
    if isinstance(stmt, Concatenate):
        parts = [str(eval_expr(env, s)) for s in stmt.sources]
        sep = str(eval_expr(env, stmt.separator)) if stmt.separator else ''
        result = sep.join(parts)
        if isinstance(stmt.target, Var):
            env.set_var(stmt.target.name, result)
        elif isinstance(stmt.target, Field):
            env.set_field(stmt.target.struct, stmt.target.field, result)
        env.sy.ok()
        return

    # CONDENSE
    if isinstance(stmt, Condense):
        if isinstance(stmt.target, Var):
            val = str(env.get_var(stmt.target.name) or '')
        else:
            val = str(env.get_field(stmt.target.struct, stmt.target.field) or '')
        import re as _re
        if stmt.no_gaps:
            val = val.replace(' ', '')
        else:
            val = _re.sub(r'\s+', ' ', val).strip()
        if isinstance(stmt.target, Var):
            env.set_var(stmt.target.name, val)
        else:
            env.set_field(stmt.target.struct, stmt.target.field, val)
        env.sy.ok()
        return

    # APPEND VALUE #(...)
    if isinstance(stmt, Append):
        tgt = stmt.target_table.lower()
        if tgt not in env.tables: env.tables[tgt] = []
        row = {}
        for f, expr in stmt.source_row.items():
            row[f] = eval_expr(env, expr)
        env.tables[tgt].append(row)
        env.sy.ok()
        return

    # APPEND wa TO itab
    if isinstance(stmt, AppendSimple):
        tgt = stmt.target_table.lower()
        if tgt not in env.tables: env.tables[tgt] = []
        val = env.get_var(stmt.source_var)
        if isinstance(val, dict):
            env.tables[tgt].append(val.copy())
        else:
            env.tables[tgt].append({'_val': val})
        env.sy.ok()
        return

    # MODIFY TABLE
    if isinstance(stmt, ModifyTable):
        tbl = env.get_table(stmt.table_name)
        src = env.get_var(stmt.from_var)
        if not isinstance(src, dict):
            env.sy.err(); return
        key_field = stmt.key_field
        if not key_field:
            # Use first field of source as key
            key_field = next(iter(src), None)
        if not key_field:
            env.sy.err(); return
        key_val = src.get(key_field)
        for i, row in enumerate(tbl):
            if isinstance(row, dict):
                rv = row.get(key_field)
                if abap_compare(rv, key_val, '='):
                    tbl[i] = {**row, **src}
                    env.sy.ok(); return
        # Not found - append
        tbl.append(src.copy())
        env.sy.ok()
        return

    # DELETE TABLE
    if isinstance(stmt, DeleteTable):
        tbl = env.get_table(stmt.table_name)
        if stmt.key:
            kf, kexpr = stmt.key
            kv = eval_expr(env, kexpr)
            orig = len(tbl)
            env.tables[stmt.table_name.lower()] = [
                r for r in tbl
                if not (isinstance(r, dict) and abap_compare(r.get(kf), kv, '='))
            ]
            if len(env.tables[stmt.table_name.lower()]) < orig:
                env.sy.ok()
            else:
                env.sy.nf()
        else:
            env.tables[stmt.table_name.lower()] = []
            env.sy.ok()
        return

    # INSERT INTO TABLE
    if isinstance(stmt, InsertTable):
        tgt = stmt.target_table.lower()
        if tgt not in env.tables: env.tables[tgt] = []
        val = env.get_var(stmt.source_var)
        if isinstance(val, dict):
            env.tables[tgt].append(val.copy())
        else:
            env.tables[tgt].append({'_val': val})
        env.sy.ok()
        return

    # READ TABLE
    if isinstance(stmt, ReadTable):
        tbl = env.get_table(stmt.table_name)
        found = False

        if stmt.index is not None:
            idx = int(coerce_numeric(eval_expr(env, stmt.index))) - 1
            if 0 <= idx < len(tbl):
                found = True
                row = tbl[idx]
                env.sy.set('sy-tabix', idx + 1)
                if stmt.into:
                    env.vars[stmt.into.lower()] = row.copy() if isinstance(row, dict) else row

        elif stmt.key:
            kf, kexpr = stmt.key
            kv = eval_expr(env, kexpr)
            for i, row in enumerate(tbl):
                rv = row.get(kf) if isinstance(row, dict) else None
                if abap_compare(rv, kv, '='):
                    found = True
                    env.sy.set('sy-tabix', i + 1)
                    if stmt.into:
                        env.vars[stmt.into.lower()] = row.copy() if isinstance(row, dict) else row
                    break
        else:
            # Read first row
            if tbl:
                found = True
                env.sy.set('sy-tabix', 1)
                if stmt.into:
                    env.vars[stmt.into.lower()] = tbl[0].copy() if isinstance(tbl[0], dict) else tbl[0]

        env.sy.set('sy-subrc', 0 if found else 4)
        return

    # DESCRIBE TABLE
    if isinstance(stmt, DescribeTable):
        tbl = env.get_table(stmt.table_name)
        env.set_var(stmt.into_var, len(tbl))
        env.sy.ok()
        return

    # LOOP AT
    if isinstance(stmt, LoopAt):
        tbl = env.get_table(stmt.table)
        saved_tabix = env.sy.get('sy-tabix')
        saved_index = env.sy.get('sy-index')

        row_num = 0
        for row in tbl:
            row_num += 1
            env.sy.set('sy-tabix', row_num)
            env.sy.set('sy-index', row_num)

            # Set loop work area
            if isinstance(row, dict):
                env.vars[stmt.into.lower()] = row.copy()
            else:
                env.vars[stmt.into.lower()] = row

            # Apply WHERE filter
            if stmt.where:
                wa = env.vars.get(stmt.into.lower(), {})
                row_dict = wa if isinstance(wa, dict) else {}
                if not eval_where_row(env, stmt.where, row_dict):
                    continue

            # Execute body
            try:
                for s in stmt.body:
                    exec_stmt(env, s)
            except LoopControl as lc:
                if lc.kind == 'EXIT':
                    break
                # CONTINUE - just go to next iteration

        # Restore outer loop counters
        env.sy.set('sy-tabix', saved_tabix)
        env.sy.set('sy-index', saved_index)
        env.sy.ok()
        return

    # EXIT
    if isinstance(stmt, Exit):
        raise LoopControl('EXIT')

    # CONTINUE
    if isinstance(stmt, Continue):
        raise LoopControl('CONTINUE')

    # CHECK
    if isinstance(stmt, Check):
        cond = eval_expr(env, stmt.condition)
        if not to_bool(cond):
            raise LoopControl('CONTINUE')
        return

    # IF
    if isinstance(stmt, If):
        if to_bool(eval_expr(env, stmt.cond)):
            for s in stmt.then_body: exec_stmt(env, s)
            return
        for ec, eb in stmt.elif_list:
            if to_bool(eval_expr(env, ec)):
                for s in eb: exec_stmt(env, s)
                return
        for s in stmt.else_body: exec_stmt(env, s)
        return

    # WHILE
    if isinstance(stmt, While):
        iters = 0
        saved_index = env.sy.get('sy-index')
        while to_bool(eval_expr(env, stmt.cond)):
            iters += 1
            if iters > env.max_iters:
                raise Exception("WHILE loop exceeded max iterations")
            env.sy.set('sy-index', iters)
            try:
                for s in stmt.body: exec_stmt(env, s)
            except LoopControl as lc:
                if lc.kind == 'EXIT': break
                # CONTINUE - re-check condition
        env.sy.set('sy-index', saved_index)
        return

    # DO
    if isinstance(stmt, Do):
        times = env.max_iters
        if stmt.times_expr:
            times = int(coerce_numeric(eval_expr(env, stmt.times_expr)))
        saved_index = env.sy.get('sy-index')
        for i in range(times):
            env.sy.set('sy-index', i + 1)
            try:
                for s in stmt.body: exec_stmt(env, s)
            except LoopControl as lc:
                if lc.kind == 'EXIT': break
                # CONTINUE - next iteration
        env.sy.set('sy-index', saved_index)
        return

    # CASE
    if isinstance(stmt, Case):
        val = eval_expr(env, stmt.expr)
        for cv, cb in stmt.cases:
            if abap_compare(val, eval_expr(env, cv), '='):
                for s in cb: exec_stmt(env, s)
                return
        for s in stmt.others_body: exec_stmt(env, s)
        return

    # FORM declaration - just register
    if isinstance(stmt, FormDecl):
        env.forms[stmt.name.lower()] = stmt
        return

    # PERFORM
    if isinstance(stmt, Perform):
        fname = stmt.name.lower()
        if fname not in env.forms:
            raise Exception(f"FORM '{fname}' not found")
        form = env.forms[fname]
        env.push_scope()
        try:
            scope = env.call_stack[-1]
            # USING: pass by value
            for i, pname in enumerate(form.using_params):
                if i < len(stmt.using_args):
                    scope[pname] = eval_expr(env, stmt.using_args[i])
                else:
                    scope[pname] = None
            # CHANGING: pass by reference (store original var name)
            changing_map = {}  # local_param -> original_var_name
            for i, pname in enumerate(form.changing_params):
                if i < len(stmt.changing_args):
                    arg = stmt.changing_args[i]
                    orig_val = eval_expr(env, arg)
                    scope[pname] = orig_val
                    if isinstance(arg, Var):
                        changing_map[pname] = arg.name
                else:
                    scope[pname] = None
            # Execute body
            for s in form.body:
                exec_stmt(env, s)
            # Copy back CHANGING params
            for pname, orig_name in changing_map.items():
                env.set_var(orig_name, scope.get(pname))
        finally:
            env.pop_scope()
        env.sy.ok()
        return

    # START-OF-SELECTION (no-op in this engine, just a marker)
    if isinstance(stmt, StartOfSelection):
        return

    # SELECT (SQL)
    if isinstance(stmt, SelectInto):
        src = env.db.get(stmt.table_name.lower(), [])
        result = []
        for row in src:
            if stmt.where and not eval_where_row(env, stmt.where, row):
                continue
            if stmt.fields == ['*']:
                result.append(row.copy())
            else:
                result.append({f: row.get(f, '') for f in stmt.fields})
        if stmt.order_by:
            def sort_key(r):
                keys = []
                for f in stmt.order_by:
                    v = r.get(f, '')
                    try: keys.append((0, float(str(v))))
                    except: keys.append((1, str(v)))
                return tuple(keys)
            result.sort(key=sort_key)
        tgt = stmt.into_table.lower()
        env.tables[tgt] = result
        # Also update vars if declared there
        env.vars[tgt] = result
        env.sy.set('sy-dbcnt', len(result))
        env.sy.set('sy-subrc', 0 if result else 4)
        return

    # UPDATE SQL
    if isinstance(stmt, UpdateSQL):
        tbl = env.db.get(stmt.table_name.lower(), [])
        set_vals = {f: eval_expr(env, e) for f, e in stmt.set_clause.items()}
        count = 0
        for row in tbl:
            if not stmt.where or eval_where_row(env, stmt.where, row):
                row.update(set_vals)
                count += 1
        env.sy.set('sy-dbcnt', count)
        env.sy.set('sy-subrc', 0 if count > 0 else 4)
        return

    # INSERT SQL
    if isinstance(stmt, InsertSQL):
        tname = stmt.table_name.lower()
        if tname not in env.db: env.db[tname] = []
        row = {f: eval_expr(env, e) for f, e in stmt.values.items()}
        env.db[tname].append(row)
        env.sy.set('sy-dbcnt', 1)
        env.sy.ok()
        return

    # DELETE SQL
    if isinstance(stmt, DeleteSQL):
        tname = stmt.table_name.lower()
        if tname not in env.db: env.sy.err(); return
        tbl = env.db[tname]
        orig = len(tbl)
        env.db[tname] = [r for r in tbl if not (not stmt.where or eval_where_row(env, stmt.where, r))]
        removed = orig - len(env.db[tname])
        env.sy.set('sy-dbcnt', removed)
        env.sy.set('sy-subrc', 0 if removed > 0 else 4)
        return

    # COMMIT
    if isinstance(stmt, CommitWork):
        env._save_snap()
        env.sy.ok()
        return

    # ROLLBACK
    if isinstance(stmt, RollbackWork):
        env._restore_snap()
        env.sy.ok()
        return


# =====================================================
# ===============    PROGRAM EXECUTOR    ==============
# =====================================================

def execute_program(program: Program) -> str:
    env = RuntimeEnv()
    for stmt in program.statements:
        try:
            exec_stmt(env, stmt)
        except LoopControl:
            pass  # EXIT/CONTINUE at top level - ignore
        except Exception as e:
            env.output.append(f"[RUNTIME ERROR] {e}\n")
    return ''.join(env.output)

def execute_program_env(program: Program, env: RuntimeEnv) -> str:
    """Execute with a pre-configured environment."""
    for stmt in program.statements:
        try:
            exec_stmt(env, stmt)
        except LoopControl:
            pass
        except Exception as e:
            env.output.append(f"[RUNTIME ERROR] {e}\n")
    return ''.join(env.output)


# =====================================================
# ===============      PUBLIC API        ==============
# =====================================================

def _extract_block(code: str) -> str:
    start = code.find('*sia')
    end = code.rfind('sia*')
    if start == -1 or end == -1:
        raise Exception(
            "Missing *sia ... sia* wrapper.\n"
            "Expected:\n  *sia\n    ABAP code\n  sia*"
        )
    inner = code[start + 4:end]
    # Strip the opening line if blank
    lines = inner.split('\n')
    return '\n'.join(lines)

def els_run(code: str, env: Optional[RuntimeEnv] = None) -> str:
    """
    Main entry point. Execute ABAP code inside *sia ... sia* markers.

    Args:
        code: string containing *sia ... sia* block
        env:  optional pre-configured RuntimeEnv (for shared state across calls)

    Returns:
        Output string from WRITE statements.
    """
    try:
        src = _extract_block(code)
        tokens = tokenize_abap_full(src)
        parser = Parser(tokens)
        program = parser.parse_program()
        if env is None:
            return execute_program(program)
        else:
            return execute_program_env(program, env)
    except ParseError as e:
        return f"[PARSE ERROR] {e}\n"
    except Exception as e:
        return f"[ERROR] {e}\n"

# Aliases for backward compatibility
run = els_run
safe_run = els_run

def els_run_env(code: str, env: RuntimeEnv) -> str:
    """Run code against a shared environment (for multi-block programs)."""
    return els_run(code, env)

def make_env() -> RuntimeEnv:
    """Create a fresh RuntimeEnv for shared use across multiple els_run calls."""
    return RuntimeEnv()

def load_db_table(env: RuntimeEnv, table_name: str, rows: List[Dict]):
    """Load custom data into the SQL database namespace."""
    env.db[table_name.lower()] = [row.copy() for row in rows]
    env._save_snap()

def repl():
    """Interactive REPL for SIA ELS."""
    print("=" * 55)
    print("  SIA Enterprise Logic Studio v5.0 - REPL")
    print("  Type ABAP code between *sia and sia* markers.")
    print("  Type :quit to exit | :reset to reset environment")
    print("=" * 55)
    env = RuntimeEnv()
    buf = []
    recording = False
    while True:
        try:
            line = input("ELS> " if not recording else "  .. ").rstrip('\n')
            if line.strip() == ':quit': break
            if line.strip() == ':reset':
                env = RuntimeEnv()
                print("[Environment reset]")
                continue
            if '*sia' in line:
                recording = True
                buf = [line]
                if 'sia*' in line:
                    out = els_run('\n'.join(buf), env)
                    print(out, end='')
                    buf = []; recording = False
                continue
            if recording:
                buf.append(line)
                if 'sia*' in line:
                    out = els_run('\n'.join(buf), env)
                    print(out, end='')
                    buf = []; recording = False
                continue
            print("Use *sia ... sia* to enter code.")
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye.")
            break

__all__ = [
    'els_run', 'els_run_env', 'make_env', 'run', 'safe_run',
    'load_db_table', 'repl',
    'RuntimeEnv', 'Parser', 'tokenize_abap_full',
    'execute_program', 'execute_program_env',
    'ABAPType', 'coerce_numeric', 'abap_validate',
]

# Stub for old import compatibility
class ABAPType:
    def __init__(self, name, length=None):
        self.name = name.upper()
        self.length = length
    def validate(self, value):
        return abap_validate(self.name, value, self.length)
    def default_value(self):
        return abap_default(self.name, self.length)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        with open(sys.argv[1], encoding='utf-8') as f:
            print(els_run(f.read()), end='')
    else:
        repl()