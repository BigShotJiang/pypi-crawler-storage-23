"""
HDQS Quantum Computing Library
Hyper-Dimensional Quantum System Client
Default Server: 31.97.239.213:8000
"""
__version__ = "1.0.0"
__author__ = "Sia Software Innovations Private Limited"
__server_ip__ = "31.97.239.213"
__server_port__ = 8000
__default_url__ = f"http://{__server_ip__}:{__server_port__}"

# First import hdqs components that should always exist
from .hdqs import (
    HDQSClient,
    LocalHDQSClient,
    HDQSError,
    connect,
    hdqs,
    call,
    create_circuit,
    run_circuit,
    measure,
    analyze,
    run_demo,
    create_hyper_system,
    DEFAULT_SERVER_IP,
    DEFAULT_SERVER_PORT,
    DEFAULT_BASE_URL
)

# Initialize ELS exports as None first
els_run       = None
els_run_env   = None
make_env      = None
run           = None
safe_run      = None
repl          = None
load_db_table = None
ABAPType      = None
RuntimeEnv    = None
# Legacy v4.x names kept as None so old code doesn't crash on attribute access
run_file           = None
extract_sia_block  = None
TypedVariable      = None
RuntimeError       = None
SystemVariables    = None
SelectionOption    = None

els_core = None

# Try to import ELS module (v5.0)
try:
    from . import els_core

    from .els_core import (
        # Primary API (v5.0)
        els_run         as els_run_func,
        els_run_env     as els_run_env_func,
        make_env        as make_env_func,
        load_db_table   as load_db_table_func,
        repl            as repl_func,
        # Backward-compat aliases present in v5.0
        run             as run_func,
        safe_run        as safe_run_func,
        # Type helpers
        ABAPType        as ABAPType_class,
        RuntimeEnv      as RuntimeEnv_class,
    )

    els_run       = els_run_func
    els_run_env   = els_run_env_func
    make_env      = make_env_func
    load_db_table = load_db_table_func
    repl          = repl_func
    run           = run_func
    safe_run      = safe_run_func
    ABAPType      = ABAPType_class
    RuntimeEnv    = RuntimeEnv_class

    # Legacy v4.x names — point to nearest equivalent so old imports don't break
    run_file          = None   # no file-based runner in v5; use els_run(open(...).read())
    extract_sia_block = None   # internal detail, not re-exported
    TypedVariable     = None   # removed in v5 refactor
    RuntimeError      = None   # no longer shadows built-in
    SystemVariables   = None   # internal, not public
    SelectionOption   = None   # internal, not public

except ImportError:
    # ELS is optional — silently skip
    pass

# Try to import other optional modules (unchanged)
try:
    from . import qbt
except ImportError:
    qbt = None

try:
    from . import vqram
except ImportError:
    vqram = None

try:
    from . import ntt
except ImportError:
    ntt = None

__all__ = [
    # HDQS core
    "HDQSClient",
    "LocalHDQSClient",
    "HDQSError",
    "connect",
    "hdqs",
    "call",
    "create_circuit",
    "run_circuit",
    "measure",
    "analyze",
    "run_demo",
    "create_hyper_system",
    "DEFAULT_SERVER_IP",
    "DEFAULT_SERVER_PORT",
    "DEFAULT_BASE_URL",
    # Optional sub-modules
    "qbt",
    "vqram",
    "ntt",
    # ELS v5.0 primary API
    "els_run",
    "els_run_env",
    "make_env",
    "load_db_table",
    "repl",
    # ELS backward-compat aliases
    "run",
    "safe_run",
    "ABAPType",
    "RuntimeEnv",
    # ELS legacy stubs (None in v5, kept so old code doesn't get AttributeError)
    "run_file",
    "extract_sia_block",
    "TypedVariable",
    "RuntimeError",
    "SystemVariables",
    "SelectionOption",
]

# Module alias: `from sia import els` still works, points to els_core
if els_core is not None:
    import sys
    sys.modules[__name__ + '.els'] = sys.modules[__name__ + '.els_core']
