# Zypp CLI — Implementation Plan

## Goal

Replace local `.env` and `secrets.auto.tfvars` files with Azure Key Vault as the single source of truth for secrets. The CLI gives developers a simple way to load Key Vault secrets into their shell environment.

## Architecture

```
zyppcli (pip install zyppcli → `zypp` command)
└── depends on: keyvault (zypp-io/keyvault package)
```

- `keyvault` stays a Python library with the existing API (`get_keyvault_secrets`, `secrets_to_environment`, etc.)
- `zyppcli` is a separate package that provides the `zypp` CLI command and uses `keyvault` as a dependency
- Designed to be extended with future subcommands beyond Key Vault

## CLI Design

### Command: `zypp keyvault load`

```bash
eval $(zypp keyvault load --vault myproject-kv)
```

**What it does:**
1. Authenticates via `DefaultAzureCredential` (picks up `az login` credentials)
2. Fetches all enabled secrets from the specified vault using `keyvault.get_keyvault_secrets()`
3. Prints `export KEY=VALUE` lines to stdout
4. The shell evaluates the output and sets the environment variables

**Flags:**
- `--vault` (required): Name of the Azure Key Vault

**Output format:**
```bash
export DB_PASSWORD='value1'
export API_KEY='value2'
```

**Key details:**
- Secret names are uppercased and hyphens are replaced with underscores (e.g. `db-password` → `DB_PASSWORD`), matching existing `keyvault` library behavior
- Secret values must be single-quoted in the export statements to handle special characters in values
- Azure Key Vault secret names only allow alphanumeric characters and hyphens, so name escaping is not needed

### Authentication

- Uses `DefaultAzureCredential` from the Azure SDK (already used by the `keyvault` library)
- For local development, developers authenticate via `az login` — the credential chain picks this up automatically
- If not authenticated, the CLI should show a clear error message suggesting the user run `az login`

## Tech Stack

- **CLI framework:** `argparse` (stdlib, no extra dependencies)
- **Dependencies:** `keyvault` (this is the main dependency that handles the Azure SDK interaction)

## Project Structure

```
zyppcli/
├── pyproject.toml
├── zyppcli/
│   ├── __init__.py
│   ├── __main__.py          # entry point: `python -m zyppcli`
│   └── commands/
│       ├── __init__.py
│       └── keyvault.py      # `zypp keyvault load` implementation
```

Register the CLI entry point in `pyproject.toml`:
```toml
[project.scripts]
zypp = "zyppcli.__main__:main"
```

Use subparsers in argparse so new command groups can be added easily:
```
zypp keyvault load --vault <name>
zypp <future-command> ...
```

## Broader Context: Eliminating Secrets on Disk

This CLI is part of a broader effort to remove all local secret files:

| Scenario | Before | After |
|---|---|---|
| Local development | `.env` files with secrets | `eval $(zypp keyvault load --vault myproject-kv)` |
| Terraform deploys | `secrets.auto.tfvars` with duplicated secrets | Key Vault references: `@Microsoft.KeyVault(VaultName=...;SecretName=...)` |

Azure Key Vault becomes the single source of truth. One vault per project.
