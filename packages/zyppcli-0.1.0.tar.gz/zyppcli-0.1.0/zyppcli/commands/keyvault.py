import argparse
import logging
import sys

from azure.identity import DefaultAzureCredential
from azure.keyvault.secrets import SecretClient

logger = logging.getLogger(__name__)


def register(subparsers: argparse._SubParsersAction) -> None:
    """Register the 'keyvault' command and its subcommands."""
    keyvault_parser = subparsers.add_parser("keyvault", help="Azure Key Vault operations")
    keyvault_subparsers = keyvault_parser.add_subparsers(dest="keyvault_command")

    load_parser = keyvault_subparsers.add_parser("load", help="Load secrets as shell export statements")
    load_parser.add_argument("--vault", required=True, help="Name of the Azure Key Vault")


def run(args: argparse.Namespace) -> None:
    """Execute the specified 'keyvault' command."""
    if args.keyvault_command == "load":
        _load(args.vault)
    else:
        logger.error("Usage: zypp keyvault load --vault <name>")
        sys.exit(1)


def _get_secrets(vault_name: str) -> dict[str, str]:
    """Fetch secrets from the specified Azure Key Vault."""
    credential = DefaultAzureCredential(exclude_environment_credential=True)
    client = SecretClient(vault_url=f"https://{vault_name}.vault.azure.net", credential=credential)

    secrets = {}
    for prop in client.list_properties_of_secrets():
        if prop.enabled:
            secrets[prop.name] = client.get_secret(prop.name).value

    return secrets


def _load(vault_name: str) -> None:
    """Load secrets from the specified Azure Key Vault and print them as shell export statements."""
    try:
        secrets = _get_secrets(vault_name)
    except Exception as e:
        logger.exception("Failed to fetch secrets from '%s': %s", vault_name, e)
        logger.info("Hint: Make sure you are authenticated via `az login`.")
        sys.exit(1)

    for name, value in secrets.items():
        env_name = name.replace("-", "_").upper()
        escaped_value = value.replace("'", "'\\''")
        print(f"export {env_name}='{escaped_value}'")
