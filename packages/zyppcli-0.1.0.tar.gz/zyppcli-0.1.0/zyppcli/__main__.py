import argparse
import logging
import sys

from zyppcli import __version__
from zyppcli.commands import keyvault


def main() -> None:
    """Entry point for the Zypp CLI."""
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s", stream=sys.stderr)

    parser = argparse.ArgumentParser(prog="zypp", description="Zypp CLI")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command")
    keyvault.register(subparsers)

    args = parser.parse_args()

    if args.command == "keyvault":
        keyvault.run(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
