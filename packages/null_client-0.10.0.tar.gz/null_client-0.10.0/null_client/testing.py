"""
null_client.testing
~~~~~~~~~~~~~~~~~~~

Pytest fixtures and helpers for running integration tests against a real
null server.

Install the testing extra to get pytest::

    pip install null-client[testing]

Quickest way to use in an external project's ``conftest.py``::

    pytest_plugins = ["null_client.testing"]

This makes the ``null_server`` and ``null_client`` fixtures available to all
tests.  Example::

    from null_client import Client
    from null_client.testing import ServerProcess

    def test_roundtrip(null_server: ServerProcess) -> None:
        client = Client(null_server.url)
        h = client.put_blob(b"hello")
        assert client.get_blob(h) == b"hello"

Or import individual fixtures explicitly::

    from null_client.testing import null_server, null_client

----

**Binary resolution** (in order of preference):

1. ``NULL_SERVER_BINARY`` env var — explicit path to the ``null`` binary.
2. ``null`` binary already on ``PATH``.
3. ``target/debug/null`` relative to an auto-detected Cargo workspace root
   (useful when running tests *inside* the null repo without a prior build).
4. Build from source: the null repo is cloned to
   ``~/.cache/null-client/src/`` and ``cargo build`` is run.  The resulting
   binary is cached at ``~/.cache/null-client/bin/null``.
   Set ``NULL_SERVER_NO_AUTO_BUILD=1`` to disable this fallback.
   Set ``NULL_SERVER_REBUILD=1`` to force a fresh build even when a cached
   binary already exists.
"""

from __future__ import annotations

import os
import shutil
import signal
import socket
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Generator

import httpx
import pytest

from null_client import Client


_REPO_URL = "https://git.sr.ht/~tsileo/null"
_DEFAULT_CACHE_DIR = Path.home() / ".cache" / "null-client"


@dataclass
class ServerProcess:
    """A running null-server process."""

    process: subprocess.Popen
    url: str
    port: int
    workspace: Path

    def stop(self) -> None:
        """Gracefully stop the server."""
        if self.process.poll() is None:
            self.process.send_signal(signal.SIGTERM)
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()


def find_free_port() -> int:
    """Return an available TCP port on 127.0.0.1."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def wait_for_server(url: str, timeout: float = 10.0) -> bool:
    """Poll ``GET /records`` until the server responds 200 or *timeout* expires."""
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            resp = httpx.get(f"{url}/records", timeout=1.0)
            if resp.status_code == 200:
                return True
        except httpx.ConnectError:
            pass
        time.sleep(0.1)
    return False


def _find_cargo_workspace_root() -> Path | None:
    """Walk up from cwd looking for a Cargo workspace that contains null."""
    for parent in [Path.cwd(), *Path.cwd().parents]:
        if (parent / "Cargo.toml").exists() and (parent / "crates").exists():
            return parent
    return None


def _find_local_debug_binary() -> Path | None:
    """Return ``target/debug/null`` if it exists in a detected Cargo workspace."""
    root = _find_cargo_workspace_root()
    if root is not None:
        candidate = root / "target" / "debug" / "null"
        if candidate.exists():
            return candidate
    return None


def build_from_source(cache_dir: Path = _DEFAULT_CACHE_DIR) -> Path:
    """Clone the null repo and build the server binary, caching the result.

    Subsequent calls reuse the cached binary unless ``NULL_SERVER_REBUILD=1``
    is set.  Requires ``git`` and ``cargo`` to be on ``PATH``.

    Args:
        cache_dir: Directory used for the source clone and compiled binary.
                   Defaults to ``~/.cache/null-client/``.

    Returns:
        Path to the compiled ``null`` binary.
    """
    src_dir = cache_dir / "src"
    bin_dir = cache_dir / "bin"
    bin_path = bin_dir / "null"

    force_rebuild = os.environ.get("NULL_SERVER_REBUILD", "") == "1"

    if bin_path.exists() and not force_rebuild:
        return bin_path

    bin_dir.mkdir(parents=True, exist_ok=True)

    if src_dir.exists():
        subprocess.run(["git", "pull", "--ff-only"], cwd=src_dir, check=True)
    else:
        subprocess.run(["git", "clone", _REPO_URL, str(src_dir)], check=True)

    subprocess.run(["cargo", "build", "--bin", "null"], cwd=src_dir, check=True)

    built = src_dir / "target" / "debug" / "null"
    if not built.exists():
        raise FileNotFoundError(
            f"cargo build succeeded but binary not found at {built}"
        )

    shutil.copy2(built, bin_path)
    bin_path.chmod(0o755)

    return bin_path


def get_null_server_binary() -> Path:
    """Resolve the ``null`` server binary.

    Resolution order:

    1. ``NULL_SERVER_BINARY`` env var (explicit path).
    2. ``null`` binary on ``PATH``.
    3. ``target/debug/null`` in a Cargo workspace detected from ``cwd``
       (works when running tests inside the null repo).
    4. :func:`build_from_source` — clone + ``cargo build`` into
       ``~/.cache/null-client/``.  Disable with ``NULL_SERVER_NO_AUTO_BUILD=1``.
    """
    # 1. Explicit override
    explicit = os.environ.get("NULL_SERVER_BINARY")
    if explicit:
        p = Path(explicit)
        if not p.exists():
            raise FileNotFoundError(f"NULL_SERVER_BINARY={explicit!r} does not exist")
        return p

    # 2. Binary on PATH
    on_path = shutil.which("null")
    if on_path:
        return Path(on_path)

    # 3. Local debug build (inside the null repo)
    local = _find_local_debug_binary()
    if local is not None:
        return local

    # 4. Build from source
    if os.environ.get("NULL_SERVER_NO_AUTO_BUILD", "") == "1":
        raise RuntimeError(
            "null server binary not found and NULL_SERVER_NO_AUTO_BUILD=1 is set.\n"
            "Provide the binary via NULL_SERVER_BINARY or add null to PATH."
        )

    return build_from_source()


@pytest.fixture
def null_server(tmp_path: Path) -> Generator[ServerProcess, None, None]:
    """Start a fresh null-server on a random port; tear it down after the test.

    Each test gets an isolated data directory under pytest's ``tmp_path``,
    so tests never share state.

    Usage::

        # conftest.py
        pytest_plugins = ["null_client.testing"]

        # test_something.py
        from null_client.testing import ServerProcess

        def test_roundtrip(null_server: ServerProcess) -> None:
            ...
    """
    binary = get_null_server_binary()
    port = find_free_port()
    url = f"http://127.0.0.1:{port}"

    server_dir = tmp_path / "null-server"
    server_dir.mkdir()

    env = os.environ.copy()
    env.setdefault("RUST_LOG", "warn")

    process = subprocess.Popen(
        [str(binary), "--port", str(port), "--data-dir", str(server_dir)],
        cwd=server_dir,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    if not wait_for_server(url):
        stdout, stderr = process.communicate(timeout=2)
        pytest.fail(
            f"null-server failed to start on port {port}.\n"
            f"stdout: {stdout.decode()}\n"
            f"stderr: {stderr.decode()}"
        )

    server = ServerProcess(process=process, url=url, port=port, workspace=server_dir)

    yield server

    server.stop()


@pytest.fixture
def null_client(null_server: ServerProcess) -> Client:
    """Return a :class:`~null_client.Client` connected to the test server.

    Depends on :fixture:`null_server`.
    """
    return Client(null_server.url)
