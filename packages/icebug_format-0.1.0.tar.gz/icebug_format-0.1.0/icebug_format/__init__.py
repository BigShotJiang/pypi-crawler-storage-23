from icebug_format.cli import main

__all__ = ["main"]
