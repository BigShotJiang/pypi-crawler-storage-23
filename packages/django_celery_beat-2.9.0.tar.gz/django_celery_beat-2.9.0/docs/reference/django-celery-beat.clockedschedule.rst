=====================================================
 ``django_celery_beat.clockedschedule``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_beat.clockedschedule

.. automodule:: django_celery_beat.clockedschedule
    :members:
    :undoc-members:
