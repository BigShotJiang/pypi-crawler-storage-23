=====================================================
 ``django_celery_beat.admin``
=====================================================

.. contents::
    :local:
.. currentmodule:: django_celery_beat.admin

.. automodule:: django_celery_beat.admin
    :members:
    :undoc-members:
