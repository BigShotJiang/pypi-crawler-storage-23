=======================================================================
 django-celery-beat - Database-backed Periodic Tasks
=======================================================================

.. include:: includes/introduction.txt

Contents
========

.. toctree::
    :maxdepth: 1

    copyright

.. toctree::
    :maxdepth: 2

    reference/index

.. toctree::
    :maxdepth: 1

    changelog
    glossary

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

