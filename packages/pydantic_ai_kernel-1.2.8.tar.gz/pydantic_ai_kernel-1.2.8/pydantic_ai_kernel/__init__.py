"""An example Jupyter kernel"""

__version__ = "1.2.8"


from .kernel import PydanticAIBaseKernel  # noqa: F401
from .agent_config import AgentConfig, ModelProviderConfig, ModelConfig  # noqa: F401
