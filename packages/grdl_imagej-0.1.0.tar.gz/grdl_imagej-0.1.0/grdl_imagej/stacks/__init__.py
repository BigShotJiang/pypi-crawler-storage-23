"""ImageJ Image > Stacks - Multi-slice stack operations."""
from grdl_imagej.stacks.z_projection import ZProjection

__all__ = ['ZProjection']
