"""Tests for @Dialog.accept_media decorator and _finalize_dialog _media_steps population."""

from whatsapp.messages.dialogs import Dialog, DialogContext, DialogTurnResult, DialogTurnStatus


@Dialog.set(name="MediaTestDialog", main=False)
class MediaTestDialog(Dialog):
    @Dialog.step()
    @Dialog.accept_media("image", "document")
    async def upload_step(self, dc: DialogContext):
        return DialogTurnResult(DialogTurnStatus.Waiting)

    @Dialog.step()
    async def text_only_step(self, dc: DialogContext):
        return DialogTurnResult(DialogTurnStatus.Waiting)

    @Dialog.step()
    @Dialog.accept_media()  # accept all types
    async def any_media_step(self, dc: DialogContext):
        return DialogTurnResult(DialogTurnStatus.Waiting)


@Dialog.set(name="NoMediaDialog", main=False)
class NoMediaDialog(Dialog):
    @Dialog.step()
    async def plain_step(self, dc: DialogContext):
        return DialogTurnResult(DialogTurnStatus.Waiting)


def test_accept_media_sets_metadata():
    """_accept_media_types attribute is set on the method."""
    # find the raw method before finalization
    step = MediaTestDialog._steps[0]
    assert hasattr(step, "_accept_media_types")
    assert step._accept_media_types == ["image", "document"]


def test_finalize_dialog_populates_media_steps():
    """_finalize_dialog must collect _accept_media_types into _media_steps."""
    assert "upload_step" in MediaTestDialog._media_steps
    assert MediaTestDialog._media_steps["upload_step"] == ["image", "document"]


def test_text_only_step_not_in_media_steps():
    """Steps without @accept_media should not appear in _media_steps."""
    assert "text_only_step" not in MediaTestDialog._media_steps


def test_accept_media_no_args_means_all_types():
    """@Dialog.accept_media() with no args stores an empty list (accept all)."""
    assert "any_media_step" in MediaTestDialog._media_steps
    assert MediaTestDialog._media_steps["any_media_step"] == []


def test_dialog_without_media_steps():
    """Dialog with no @accept_media decorators should have empty _media_steps."""
    assert NoMediaDialog._media_steps == {}
