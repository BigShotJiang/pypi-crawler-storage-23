# miblab-ssa
Statistical shape analysis for medical imaging data
