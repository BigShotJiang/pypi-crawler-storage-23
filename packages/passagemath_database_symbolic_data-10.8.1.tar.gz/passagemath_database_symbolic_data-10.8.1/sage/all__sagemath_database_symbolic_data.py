# sage_setup: distribution = sagemath-database-symbolic-data
