"""Entry point for ``python -m uup_builder``."""

from uup_builder.cli import main

if __name__ == "__main__":
    main()