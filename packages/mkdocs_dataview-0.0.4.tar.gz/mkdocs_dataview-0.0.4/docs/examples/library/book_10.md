---
title: American Gods
type: book
genre: Fantasy
author: Neil Gaiman
publishing_date: 2001-06-19
awards:
  - Hugo Award
  - Locus Award
---

# American Gods

**Genre**: Fantasy
**Author**: Neil Gaiman
**Published**: 2001-06-19

## Summary
This is a placeholder summary for **American Gods** by Neil Gaiman. It is a celebrated work in the fantasy genre.

## Awards
Hugo Award, Locus Award
