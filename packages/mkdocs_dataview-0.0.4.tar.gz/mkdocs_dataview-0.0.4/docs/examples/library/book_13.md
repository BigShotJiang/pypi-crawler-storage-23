---
title: A Game of Thrones
type: book
genre: Fantasy
author: George R. R. Martin
publishing_date: 1996-08-01
awards:
  - Locus Award
---

# A Game of Thrones

**Genre**: Fantasy
**Author**: George R. R. Martin
**Published**: 1996-08-01

## Summary
This is a placeholder summary for **A Game of Thrones** by George R. R. Martin. It is a celebrated work in the fantasy genre.

## Awards
Locus Award
