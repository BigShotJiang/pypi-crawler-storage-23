---
title: Five Decembers
type: book
genre: Detective
author: James Kestrel
publishing_date: 2021-10-19
awards:
  - Edgar Award
---

# Five Decembers

**Genre**: Detective
**Author**: James Kestrel
**Published**: 2021-10-19

## Summary
This is a placeholder summary for **Five Decembers** by James Kestrel. It is a celebrated work in the detective genre.

## Awards
Edgar Award
