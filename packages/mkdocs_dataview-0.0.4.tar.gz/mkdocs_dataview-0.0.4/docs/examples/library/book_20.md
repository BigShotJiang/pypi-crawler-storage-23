---
title: Funny Story
type: book
genre: Romance
author: Emily Henry
publishing_date: 2024-04-23
awards:
  - Goodreads Choice Award
---

# Funny Story

**Genre**: Romance
**Author**: Emily Henry
**Published**: 2024-04-23

## Summary
This is a placeholder summary for **Funny Story** by Emily Henry. It is a celebrated work in the romance genre.

## Awards
Goodreads Choice Award
