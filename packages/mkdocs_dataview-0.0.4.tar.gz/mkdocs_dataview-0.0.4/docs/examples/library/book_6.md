---
title: Djinn Patrol on the Purple Line
type: book
genre: Detective
author: Deepa Anappara
publishing_date: 2020-01-30
awards:
  - Edgar Award
---

# Djinn Patrol on the Purple Line

**Genre**: Detective
**Author**: Deepa Anappara
**Published**: 2020-01-30

## Summary
This is a placeholder summary for **Djinn Patrol on the Purple Line** by Deepa Anappara. It is a celebrated work in the detective genre.

## Awards
Edgar Award
