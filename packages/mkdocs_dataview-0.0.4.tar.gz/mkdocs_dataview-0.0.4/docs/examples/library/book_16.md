---
title: Together
type: book
genre: Romance
author: Julie Cohen
publishing_date: 2017-07-13
awards:
  - RoNA Award
---

# Together

**Genre**: Romance
**Author**: Julie Cohen
**Published**: 2017-07-13

## Summary
This is a placeholder summary for **Together** by Julie Cohen. It is a celebrated work in the romance genre.

## Awards
RoNA Award
