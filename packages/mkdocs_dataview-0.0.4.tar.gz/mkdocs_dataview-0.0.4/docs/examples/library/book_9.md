---
title: The Fifth Season
type: book
genre: Fantasy
author: N.K. Jemisin
publishing_date: 2015-08-04
awards:
  - Hugo Award
---

# The Fifth Season

**Genre**: Fantasy
**Author**: N.K. Jemisin
**Published**: 2015-08-04

## Summary
This is a placeholder summary for **The Fifth Season** by N.K. Jemisin. It is a celebrated work in the fantasy genre.

## Awards
Hugo Award
