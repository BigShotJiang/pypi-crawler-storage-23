---
title: Bones and Silence
type: book
genre: Detective
author: Reginald Hill
publishing_date: 1990-01-01
awards:
  - CWA Gold Dagger
---

# Bones and Silence

**Genre**: `= this.metadata.genre`  
**Author**: `= this.metadata.author`.  
**Published**: `= this.metadata.publishing_date` 

## Summary
This is a placeholder summary for **Bones and Silence** by Reginald Hill. It is a celebrated work in the detective genre.

## Awards

```dataview
TABLE this.metadata.awards WHERE 1
```
