---
title: The Honjin Murders
type: book
genre: Detective
author: Seishi Yokomizo
publishing_date: 1947-01-01
awards:
  - Mystery Writers of Japan Award
---

# The Honjin Murders

**Genre**: Detective
**Author**: Seishi Yokomizo
**Published**: 1947-01-01

## Summary
This is a placeholder summary for **The Honjin Murders** by Seishi Yokomizo. It is a celebrated work in the detective genre.

## Awards
Mystery Writers of Japan Award
