---
title: The Stranger Diaries
type: book
genre: Detective
author: Elly Griffiths
publishing_date: 2018-11-01
awards:
  - Edgar Award
---

# The Stranger Diaries

**Genre**: Detective
**Author**: Elly Griffiths
**Published**: 2018-11-01

## Summary
This is a placeholder summary for **The Stranger Diaries** by Elly Griffiths. It is a celebrated work in the detective genre.

## Awards
Edgar Award
