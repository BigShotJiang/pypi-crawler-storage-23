---
title: The Rose Code
type: book
genre: Romance
author: Kate Quinn
publishing_date: 2021-03-09
awards:
  - IBPA Gold Winner
---

# The Rose Code

**Genre**: Romance
**Author**: Kate Quinn
**Published**: 2021-03-09

## Summary
This is a placeholder summary for **The Rose Code** by Kate Quinn. It is a celebrated work in the romance genre.

## Awards
IBPA Gold Winner
