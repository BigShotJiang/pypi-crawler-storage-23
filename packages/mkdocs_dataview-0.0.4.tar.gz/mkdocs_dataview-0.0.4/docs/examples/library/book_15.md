---
title: A Night on the Orient Express
type: book
genre: Romance
author: Veronica Henry
publishing_date: 2013-07-04
awards:
  - RoNA Award
---

# A Night on the Orient Express

**Genre**: Romance
**Author**: Veronica Henry
**Published**: 2013-07-04

## Summary
This is a placeholder summary for **A Night on the Orient Express** by Veronica Henry. It is a celebrated work in the romance genre.

## Awards
RoNA Award
