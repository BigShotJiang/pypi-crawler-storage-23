---
title: The Duchess Deal
type: book
genre: Romance
author: Tessa Dare
publishing_date: 2017-08-22
awards:
  - Audie Award
---

# The Duchess Deal

**Genre**: Romance
**Author**: Tessa Dare
**Published**: 2017-08-22

## Summary
This is a placeholder summary for **The Duchess Deal** by Tessa Dare. It is a celebrated work in the romance genre.

## Awards
Audie Award
