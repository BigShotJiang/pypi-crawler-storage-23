---
title: Dune
type: book
genre: Fantasy
author: Frank Herbert
publishing_date: 1965-08-01
awards:
  - Hugo Award
  - Nebula Award
---

# Dune

**Genre**: Fantasy
**Author**: Frank Herbert
**Published**: 1965-08-01

## Summary
This is a placeholder summary for **Dune** by Frank Herbert. It is a celebrated work in the fantasy genre.

## Awards
Hugo Award, Nebula Award
