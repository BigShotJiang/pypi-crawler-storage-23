---
title: Jonathan Strange & Mr Norrell
type: book
genre: Fantasy
author: Susanna Clarke
publishing_date: 2004-09-08
awards:
  - Hugo Award
  - World Fantasy Award
---

# Jonathan Strange & Mr Norrell

**Genre**: Fantasy
**Author**: Susanna Clarke
**Published**: 2004-09-08

## Summary
This is a placeholder summary for **Jonathan Strange & Mr Norrell** by Susanna Clarke. It is a celebrated work in the fantasy genre.

## Awards
Hugo Award, World Fantasy Award
