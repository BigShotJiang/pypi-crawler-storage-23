---
title: Summer of Love
type: book
genre: Romance
author: Katie Fforde
publishing_date: 2012-01-01
awards:
  - RoNA Award
---

# Summer of Love

**Genre**: Romance
**Author**: Katie Fforde
**Published**: 2012-01-01

## Summary
This is a placeholder summary for **Summer of Love** by Katie Fforde. It is a celebrated work in the romance genre.

## Awards
RoNA Award
