---
title: Long Shot
type: book
genre: Romance
author: Kennedy Ryan
publishing_date: 2019-03-19
awards:
  - RITA Award
---

# Long Shot

**Genre**: Romance
**Author**: Kennedy Ryan
**Published**: 2019-03-19

## Summary
This is a placeholder summary for **Long Shot** by Kennedy Ryan. It is a celebrated work in the romance genre.

## Awards
RITA Award
