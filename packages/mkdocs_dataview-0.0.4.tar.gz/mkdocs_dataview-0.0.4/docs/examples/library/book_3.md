---
title: Promised Land
type: book
genre: Detective
author: Robert B. Parker
publishing_date: 1976-03-12
awards:
  - Edgar Award
---

# Promised Land

**Genre**: Detective
**Author**: Robert B. Parker
**Published**: 1976-03-12

## Summary
This is a placeholder summary for **Promised Land** by Robert B. Parker. It is a celebrated work in the detective genre.

## Awards
Edgar Award
