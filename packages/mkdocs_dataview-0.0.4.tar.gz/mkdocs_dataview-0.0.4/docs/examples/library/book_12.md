---
title: The Saint of Bright Doors
type: book
genre: Fantasy
author: Vajra Chandrasekera
publishing_date: 2023-02-21
awards:
  - Nebula Award
---

# The Saint of Bright Doors

**Genre**: Fantasy
**Author**: Vajra Chandrasekera
**Published**: 2023-02-21

## Summary
This is a placeholder summary for **The Saint of Bright Doors** by Vajra Chandrasekera. It is a celebrated work in the fantasy genre.

## Awards
Nebula Award
