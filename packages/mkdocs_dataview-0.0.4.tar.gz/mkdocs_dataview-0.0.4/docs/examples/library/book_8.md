---
title: The Left Hand of Darkness
type: book
genre: Fantasy
author: Ursula K. Le Guin
publishing_date: 1969-03-01
awards:
  - Hugo Award
  - Nebula Award
---

# The Left Hand of Darkness

**Genre**: Fantasy
**Author**: Ursula K. Le Guin
**Published**: 1969-03-01

## Summary
This is a placeholder summary for **The Left Hand of Darkness** by Ursula K. Le Guin. It is a celebrated work in the fantasy genre.

## Awards
Hugo Award, Nebula Award
