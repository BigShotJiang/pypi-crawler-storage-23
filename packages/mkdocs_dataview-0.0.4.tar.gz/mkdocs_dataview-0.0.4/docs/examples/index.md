# Usage Examples



Here is one exmamle using it as index for book library.