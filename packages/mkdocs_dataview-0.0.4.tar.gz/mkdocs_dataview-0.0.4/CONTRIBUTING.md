# Contributing to mkdocs-dataview-plugin

Go to [dev-guide](docs/dev-guide/index.md)
