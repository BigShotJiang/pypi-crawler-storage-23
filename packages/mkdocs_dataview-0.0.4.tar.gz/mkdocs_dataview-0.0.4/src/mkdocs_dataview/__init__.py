"""
__init__ module for dataview package
"""

__version__ = "0.0.4"
