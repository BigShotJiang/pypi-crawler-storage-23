"""
Module for handling dataview like queries.

- parsing queries
- executing queries
- rendering queries
"""

__version__ = "0.0.0.dev"
