import pytest

from rayforce import F64, I64, Symbol, Table, Vector
from tests.helpers.assertions import (
    assert_column_sorted,
    assert_column_values,
    assert_contains_columns,
)

pytestmark = pytest.mark.plugin


@pytest.fixture
def sqlglot():
    try:
        import sqlglot

        return sqlglot
    except ImportError:
        pytest.skip("sqlglot is not installed")


@pytest.fixture
def sample_table():
    return Table(
        {
            "id": Vector([1, 2, 3, 4, 5], ray_type=I64),
            "name": Vector(["Alice", "Bob", "Charlie", "Diana", "Eve"], ray_type=Symbol),
            "age": Vector([25, 30, 35, 28, 32], ray_type=I64),
            "salary": Vector([50000.0, 60000.0, 70000.0, 55000.0, 65000.0], ray_type=F64),
            "dept": Vector(["eng", "sales", "eng", "sales", "eng"], ray_type=Symbol),
        }
    )


# ---------------------------------------------------------------------------
# SELECT tests
# ---------------------------------------------------------------------------


def test_select_all(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self")
    assert len(result.columns()) == 5


def test_select_columns(sqlglot, sample_table):
    result = sample_table.sql("SELECT name, age FROM self")
    assert_contains_columns(result, ["name", "age"])
    assert len(result.columns()) == 2


def test_select_with_alias(sqlglot, sample_table):
    result = sample_table.sql("SELECT name AS employee_name, age AS years FROM self")
    assert_contains_columns(result, ["employee_name", "years"])


# ---------------------------------------------------------------------------
# WHERE tests
# ---------------------------------------------------------------------------


def test_where_equals(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age = 30")
    assert len(result) == 1
    assert_column_values(result, "name", ["Bob"])


def test_where_greater_than(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age > 30")
    assert len(result) == 2  # Charlie (35), Eve (32)


def test_where_less_than(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age < 30")
    assert len(result) == 2  # Alice (25), Diana (28)


def test_where_and(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age > 25 AND age < 35")
    assert len(result) == 3  # Bob (30), Diana (28), Eve (32)


def test_where_or(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age = 25 OR age = 35")
    assert len(result) == 2  # Alice (25), Charlie (35)


def test_where_in(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age IN (25, 30, 35)")
    assert len(result) == 3


def test_parenthesized_or(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT * FROM self WHERE (dept = 'eng' OR dept = 'sales') AND age > 28"
    )
    assert len(result) >= 1


def test_nested_parentheses(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT * FROM self WHERE ((dept = 'eng' OR dept = 'sales') AND age > 28) OR age = 25"
    )
    assert len(result) >= 2


def test_deeply_nested_logic(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT * FROM self WHERE dept = 'eng' AND (age > 30 OR (salary > 60000 AND age >= 25))"
    )
    assert len(result) >= 1


def test_negative_number(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE salary > -100")
    assert len(result) == 5


def test_empty_result(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE salary > 999999")
    assert len(result) == 0


def test_range_with_and(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age >= 28 AND age <= 32")
    assert len(result) >= 2


def test_float_comparison(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE salary > 55000.5")
    assert len(result) >= 2


def test_in_combined_with_and(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE dept IN ('eng', 'sales') AND age > 28")
    assert len(result) >= 1


# ---------------------------------------------------------------------------
# GROUP BY / aggregation tests
# ---------------------------------------------------------------------------


def test_group_by_count(sqlglot, sample_table):
    result = sample_table.sql("SELECT dept, COUNT(id) AS cnt FROM self GROUP BY dept")
    assert len(result) == 2  # eng, sales


def test_group_by_sum(sqlglot, sample_table):
    result = sample_table.sql("SELECT dept, SUM(salary) AS total FROM self GROUP BY dept")
    assert len(result) == 2


def test_group_by_avg(sqlglot, sample_table):
    result = sample_table.sql("SELECT dept, AVG(age) AS avg_age FROM self GROUP BY dept")
    assert len(result) == 2


def test_min_max(sqlglot, sample_table):
    result = sample_table.sql("SELECT MIN(age) AS min_age, MAX(age) AS max_age FROM self")
    assert_column_values(result, "min_age", [25])
    assert_column_values(result, "max_age", [35])


def test_multiple_aggregations_no_group(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT COUNT(id) AS cnt, AVG(salary) AS avg_sal, MIN(age) AS min_age, MAX(age) AS max_age FROM self"
    )
    assert_column_values(result, "cnt", [5])


def test_combined_where_and_group(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT dept, AVG(salary) AS avg_sal FROM self WHERE age > 25 GROUP BY dept"
    )
    assert len(result) == 2


def test_combined_where_group_order(sqlglot, sample_table):
    result = sample_table.sql(
        "SELECT dept, COUNT(id) AS cnt FROM self WHERE salary > 50000 GROUP BY dept ORDER BY cnt DESC"
    )
    assert len(result) == 2


def test_complex_aggregation(sqlglot, sample_table):
    result = sample_table.sql("""
        SELECT
            dept,
            AVG(salary) AS avg_sal,
            MAX(age) AS max_age,
            COUNT(id) AS cnt
        FROM self
        WHERE age > 25
        GROUP BY dept
        ORDER BY avg_sal DESC
    """)
    assert len(result) == 2  # eng and sales have people > 25


# ---------------------------------------------------------------------------
# ORDER BY tests
# ---------------------------------------------------------------------------


def test_order_by_asc(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self ORDER BY age")
    assert_column_sorted(result, "age")


def test_order_by_desc(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self ORDER BY age DESC")
    assert_column_sorted(result, "age", desc=True)


# ---------------------------------------------------------------------------
# Arithmetic expression tests
# ---------------------------------------------------------------------------


def test_arithmetic_expression(sqlglot, sample_table):
    result = sample_table.sql("SELECT salary * 1.1 AS new_salary FROM self")
    assert_contains_columns(result, ["new_salary"])


def test_arithmetic_subtraction(sqlglot, sample_table):
    result = sample_table.sql("SELECT name, salary - 10000 AS adjusted FROM self")
    assert_contains_columns(result, ["adjusted"])


def test_arithmetic_division(sqlglot, sample_table):
    result = sample_table.sql("SELECT name, salary / 12 AS monthly FROM self")
    assert_contains_columns(result, ["monthly"])


# ---------------------------------------------------------------------------
# UPDATE tests
# ---------------------------------------------------------------------------


def test_update_single_column(sqlglot, sample_table):
    result = sample_table.sql("UPDATE self SET salary = 99999.0 WHERE id = 1")
    for i, id_val in enumerate(result["id"]):
        if id_val.value == 1:
            assert result["salary"][i].value == 99999.0
            break


def test_update_all_rows(sqlglot, sample_table):
    result = sample_table.sql("UPDATE self SET age = 100")
    assert_column_values(result, "age", [100, 100, 100, 100, 100])


def test_update_with_expression(sqlglot, sample_table):
    result = sample_table.sql("UPDATE self SET salary = salary + 1000.0 WHERE age > 30")
    # Ages > 30: Charlie (35, 70000->71000), Eve (32, 65000->66000)
    for i, age_val in enumerate(result["age"]):
        if age_val.value > 30:
            assert result["salary"][i].value > 65000


def test_update_multiple_columns(sqlglot, sample_table):
    result = sample_table.sql("UPDATE self SET age = 99, salary = 1.0 WHERE id = 2")
    for i, id_val in enumerate(result["id"]):
        if id_val.value == 2:
            assert result["age"][i].value == 99
            assert result["salary"][i].value == 1.0
            break


def test_update_with_complex_where(sqlglot, sample_table):
    result = sample_table.sql(
        "UPDATE self SET salary = 0.0 WHERE (dept = 'eng' OR dept = 'sales') AND age < 30"
    )
    # Should update Alice (eng, 25) and Diana (sales, 28)
    updated_count = sum(1 for s in result["salary"] if s.value == 0.0)
    assert updated_count == 2


# ---------------------------------------------------------------------------
# INSERT tests
# ---------------------------------------------------------------------------


def test_insert_single_row_with_columns(sqlglot):
    table = Table(
        {
            "id": Vector([1, 2], ray_type=I64),
            "name": Vector(["Alice", "Bob"], ray_type=Symbol),
        }
    )
    result = table.sql("INSERT INTO self (id, name) VALUES (3, 'Charlie')")
    assert len(result) == 3
    assert_column_values(result, "id", [1, 2, 3])
    assert_column_values(result, "name", ["Alice", "Bob", "Charlie"])


def test_insert_multiple_rows_with_columns(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    result = table.sql("INSERT INTO self (id, name) VALUES (2, 'Bob'), (3, 'Charlie')")
    assert len(result) == 3
    assert_column_values(result, "id", [1, 2, 3])


def test_insert_without_columns(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    result = table.sql("INSERT INTO self VALUES (2, 'Bob')")
    assert len(result) == 2
    assert_column_values(result, "id", [1, 2])
    assert_column_values(result, "name", ["Alice", "Bob"])


def test_insert_multiple_rows_without_columns(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    result = table.sql("INSERT INTO self VALUES (2, 'Bob'), (3, 'Charlie')")
    assert len(result) == 3


def test_insert_with_float_values(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "price": Vector([10.5], ray_type=F64),
        }
    )
    result = table.sql("INSERT INTO self (id, price) VALUES (2, 20.5)")
    assert len(result) == 2
    assert_column_values(result, "price", [10.5, 20.5])


def test_insert_with_negative_values(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "value": Vector([100], ray_type=I64),
        }
    )
    result = table.sql("INSERT INTO self (id, value) VALUES (2, -50)")
    assert len(result) == 2
    assert_column_values(result, "value", [100, -50])


# ---------------------------------------------------------------------------
# UPSERT tests
# ---------------------------------------------------------------------------


def test_upsert_update_existing(sqlglot):
    table = Table(
        {
            "id": Vector([1, 2], ray_type=I64),
            "name": Vector(["Alice", "Bob"], ray_type=Symbol),
        }
    )
    result = table.sql(
        "INSERT INTO self (id, name) VALUES (1, 'Alice Updated') ON CONFLICT (id) DO UPDATE"
    )
    assert len(result) == 2
    for i, id_val in enumerate(result["id"]):
        if id_val.value == 1:
            assert result["name"][i].value == "Alice Updated"
            break


def test_upsert_insert_new(sqlglot):
    table = Table(
        {
            "id": Vector([1, 2], ray_type=I64),
            "name": Vector(["Alice", "Bob"], ray_type=Symbol),
        }
    )
    result = table.sql(
        "INSERT INTO self (id, name) VALUES (3, 'Charlie') ON CONFLICT (id) DO UPDATE"
    )
    assert len(result) == 3
    ids = [v.value for v in result["id"]]
    assert 3 in ids


def test_upsert_multiple_rows(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    result = table.sql("""
        INSERT INTO self (id, name)
        VALUES (1, 'Alice Updated'), (2, 'Bob')
        ON CONFLICT (id) DO UPDATE
    """)
    assert len(result) == 2
    names = [v.value for v in result["name"]]
    assert "Alice Updated" in names
    assert "Bob" in names


def test_upsert_composite_key(sqlglot):
    table = Table(
        {
            "region": Vector(["US", "EU"], ray_type=Symbol),
            "id": Vector([1, 1], ray_type=I64),
            "value": Vector([100, 200], ray_type=I64),
        }
    )
    result = table.sql("""
        INSERT INTO self (region, id, value)
        VALUES ('US', 1, 150)
        ON CONFLICT (region, id) DO UPDATE
    """)
    assert len(result) == 2
    for i, region in enumerate(result["region"]):
        if region.value == "US" and result["id"][i].value == 1:
            assert result["value"][i].value == 150
            break


def test_upsert_do_nothing_raises(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    with pytest.raises(ValueError, match="DO NOTHING is not supported"):
        table.sql("INSERT INTO self (id, name) VALUES (1, 'Bob') ON CONFLICT (id) DO NOTHING")


def test_upsert_mismatched_key_raises(sqlglot):
    table = Table(
        {
            "id": Vector([1], ray_type=I64),
            "name": Vector(["Alice"], ray_type=Symbol),
        }
    )
    with pytest.raises(ValueError, match="must match the first"):
        table.sql("INSERT INTO self (id, name) VALUES (1, 'Bob') ON CONFLICT (name) DO UPDATE")


# ---------------------------------------------------------------------------
# Error / edge-case tests
# ---------------------------------------------------------------------------


def test_invalid_sql_raises(sqlglot, sample_table):
    with pytest.raises(ValueError, match="Statement not supported"):
        sample_table.sql("DELETE FROM self WHERE id = 1")


# ---------------------------------------------------------------------------
# SQLQuery IPC tests
# ---------------------------------------------------------------------------


def test_sql_query_ipc_select(sqlglot):
    from rayforce.plugins.sql import SQLQuery

    query = SQLQuery(Table("employees"), "SELECT name, age FROM self WHERE age > 30")
    assert query.ipc is not None


def test_sql_query_ipc_update(sqlglot):
    from rayforce.plugins.sql import SQLQuery

    query = SQLQuery(Table("employees"), "UPDATE self SET salary = 100000.0 WHERE level = 'senior'")
    assert query.ipc is not None


def test_sql_query_ipc_insert(sqlglot):
    from rayforce.plugins.sql import SQLQuery

    query = SQLQuery(Table("employees"), "INSERT INTO self (id, name) VALUES (1, 'Alice')")
    assert query.ipc is not None


def test_sql_query_ipc_upsert(sqlglot):
    from rayforce.plugins.sql import SQLQuery

    query = SQLQuery(
        Table("employees"),
        "INSERT INTO self (id, name) VALUES (1, 'Alice') ON CONFLICT (id) DO UPDATE",
    )
    assert query.ipc is not None


def test_sql_query_stores_parsed(sqlglot):
    from rayforce.plugins.sql import ParsedSelect, SQLQuery

    query = SQLQuery(Table("employees"), "SELECT * FROM self")
    assert isinstance(query.parsed, ParsedSelect)


# ---------------------------------------------------------------------------
# LIMIT / OFFSET tests
# ---------------------------------------------------------------------------


def test_select_limit(sqlglot, sample_table):
    """LIMIT clause — the SQL plugin parses but does not enforce LIMIT,
    so this test documents that LIMIT is silently ignored (all rows returned).
    """
    result = sample_table.sql("SELECT * FROM self LIMIT 3")
    # LIMIT is not enforced; all 5 rows are returned.
    assert len(result) == 5


def test_select_limit_offset(sqlglot, sample_table):
    """LIMIT with OFFSET — also silently ignored."""
    result = sample_table.sql("SELECT * FROM self LIMIT 2 OFFSET 1")
    assert len(result) == 5


# ---------------------------------------------------------------------------
# DISTINCT tests
# ---------------------------------------------------------------------------


def test_select_distinct_not_enforced(sqlglot, sample_table):
    """SELECT DISTINCT is parsed but not enforced — all rows are returned."""
    result = sample_table.sql("SELECT DISTINCT dept FROM self")
    # DISTINCT is not enforced, so duplicates are present.
    assert len(result) == 5


def test_select_distinct_multiple_columns(sqlglot, sample_table):
    """SELECT DISTINCT with multiple columns — also not enforced."""
    result = sample_table.sql("SELECT DISTINCT dept, age FROM self")
    assert len(result) == 5


# ---------------------------------------------------------------------------
# HAVING clause tests
# ---------------------------------------------------------------------------


def test_having_clause_not_enforced(sqlglot, sample_table):
    """HAVING is parsed but not enforced — groups are not filtered."""
    result = sample_table.sql(
        "SELECT dept, COUNT(id) AS cnt FROM self GROUP BY dept HAVING COUNT(id) > 2"
    )
    # HAVING is ignored, both groups are returned.
    assert len(result) == 2


def test_having_with_avg_not_enforced(sqlglot, sample_table):
    """HAVING with AVG aggregation — also not enforced."""
    result = sample_table.sql(
        "SELECT dept, AVG(salary) AS avg_sal FROM self GROUP BY dept HAVING AVG(salary) > 60000"
    )
    assert len(result) == 2


# ---------------------------------------------------------------------------
# Subquery tests
# ---------------------------------------------------------------------------


def test_subquery_in_where_not_supported(sqlglot, sample_table):
    """Subquery in WHERE clause is not supported and raises an error."""
    with pytest.raises((IndexError, ValueError, NotImplementedError, AttributeError)):
        sample_table.sql("SELECT * FROM self WHERE age IN (SELECT MAX(age) FROM self)")


def test_subquery_scalar_not_supported(sqlglot, sample_table):
    """Scalar subquery in WHERE clause is not supported and raises an error."""
    with pytest.raises((ValueError, NotImplementedError, KeyError, AttributeError)):
        sample_table.sql("SELECT * FROM self WHERE age > (SELECT AVG(age) FROM self)")


# ---------------------------------------------------------------------------
# Window function tests
# ---------------------------------------------------------------------------


def test_window_row_number(sqlglot, sample_table):
    """Window function ROW_NUMBER()."""
    try:
        result = sample_table.sql("SELECT name, ROW_NUMBER() OVER (ORDER BY age) AS rn FROM self")
        assert_contains_columns(result, ["name", "rn"])
    except (ValueError, NotImplementedError, KeyError, AttributeError):
        pytest.skip("Window functions not supported by SQL plugin")


def test_window_rank(sqlglot, sample_table):
    """Window function RANK()."""
    try:
        result = sample_table.sql(
            "SELECT name, RANK() OVER (PARTITION BY dept ORDER BY salary DESC) AS rnk FROM self"
        )
        assert_contains_columns(result, ["name", "rnk"])
    except (ValueError, NotImplementedError, KeyError, AttributeError):
        pytest.skip("Window functions not supported by SQL plugin")


# ---------------------------------------------------------------------------
# Additional edge cases
# ---------------------------------------------------------------------------


def test_select_count_star_not_supported(sqlglot, sample_table):
    """COUNT(*) without a column argument is not supported."""
    with pytest.raises((TypeError, ValueError)):
        sample_table.sql("SELECT COUNT(*) AS total FROM self")


def test_select_where_not_equals(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE dept != 'eng'")
    assert len(result) == 2  # Bob (sales), Diana (sales)


def test_select_where_gte_and_lte(sqlglot, sample_table):
    result = sample_table.sql("SELECT * FROM self WHERE age >= 30 AND age <= 32")
    assert len(result) == 2  # Bob (30), Eve (32)


def test_update_returns_all_columns(sqlglot, sample_table):
    """After UPDATE the result should still have all original columns."""
    result = sample_table.sql("UPDATE self SET age = 99 WHERE id = 1")
    assert len(result.columns()) == 5


def test_insert_preserves_types(sqlglot):
    """After INSERT, column types should be preserved."""
    table = Table(
        {
            "id": Vector([1, 2], ray_type=I64),
            "score": Vector([10.0, 20.0], ray_type=F64),
        }
    )
    result = table.sql("INSERT INTO self (id, score) VALUES (3, 30.0)")
    assert len(result) == 3
    assert_column_values(result, "id", [1, 2, 3])


def test_sql_query_stores_parsed(sqlglot):
    from rayforce.plugins.sql import ParsedSelect, SQLQuery

    query = SQLQuery(Table("employees"), "SELECT * FROM self")
    assert isinstance(query.parsed, ParsedSelect)


def test_missing_sqlglot_raises(monkeypatch):
    import importlib
    import sys

    from rayforce.plugins import sql as sql_module

    original_sqlglot = sys.modules.get("sqlglot")
    if "sqlglot" in sys.modules:
        del sys.modules["sqlglot"]

    original_import = __import__

    def mock_import(name, *args, **kwargs):
        if name == "sqlglot":
            raise ImportError("No module named 'sqlglot'")
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr("builtins.__import__", mock_import)

    importlib.reload(sql_module)

    from rayforce.plugins.sql import _ensure_sqlglot

    with pytest.raises(ImportError, match="sqlglot is required"):
        _ensure_sqlglot()

    # Restore sqlglot and reload the module to restore proper state
    if original_sqlglot:
        sys.modules["sqlglot"] = original_sqlglot
    monkeypatch.undo()
    importlib.reload(sql_module)
