
# SwiftGUI-Logging

Still WIP
