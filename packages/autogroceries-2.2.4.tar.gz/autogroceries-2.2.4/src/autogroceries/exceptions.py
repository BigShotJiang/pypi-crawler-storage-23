class TwoFactorAuthenticationRequiredError(Exception):
    pass


class MissingCredentialsError(Exception):
    pass
