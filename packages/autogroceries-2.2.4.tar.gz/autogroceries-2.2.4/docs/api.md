# API Reference

::: autogroceries.shopper.base

::: autogroceries.shopper.sainsburys

::: autogroceries.delay

::: autogroceries.logging
