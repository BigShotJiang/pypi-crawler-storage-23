# pidevkit-ai

Core AI utilities and provider adapters used across the `pidevkit` workspace.

## Install

```bash
pip install pidevkit-ai
```

## Import

```python
from pidevkit.ai import stream, get_models
```
