from __future__ import annotations


def is_context_overflow(message: str | None) -> bool:
    if not message:
        return False
    normalized = message.lower()
    triggers = [
        "context length",
        "maximum context",
        "too many tokens",
        "prompt is too long",
    ]
    return any(trigger in normalized for trigger in triggers)


def isContextOverflow(message: str | None) -> bool:
    return is_context_overflow(message)


__all__ = ["is_context_overflow", "isContextOverflow"]
