from __future__ import annotations

import asyncio
import json
import math
import re
import time
from collections import deque
from collections.abc import AsyncIterator, Awaitable, Callable, Mapping
from datetime import UTC
from email.utils import parsedate_to_datetime
from typing import Any

from .types import AssistantMessage, Context, Model, StopReason, ToolCall, Usage

_RESET_AFTER_PATTERN = re.compile(r"reset after (?:(\d+)h)?(?:(\d+)m)?(\d+(?:\.\d+)?)s", re.IGNORECASE)
_RETRY_IN_PATTERN = re.compile(r"Please retry in ([0-9.]+)(ms|s)", re.IGNORECASE)
_RETRY_DELAY_FIELD_PATTERN = re.compile(r'"retryDelay":\s*"([0-9.]+)(ms|s)"', re.IGNORECASE)
_CLAUDE_THINKING_BETA_HEADER = "interleaved-thinking-2025-05-14"
_DEFAULT_ENDPOINT = "https://cloudcode-pa.googleapis.com"
_EMPTY_STREAM_RETRIES = 1
_TOOL_CALL_COUNTER = 0


class AssistantMessageEventStream:
    def __init__(self) -> None:
        self._queue: deque[dict[str, Any]] = deque()
        self._waiters: deque[asyncio.Future[dict[str, Any] | None]] = deque()
        self._done = False
        self._final_result: asyncio.Future[dict[str, Any]] = self._new_future()

    def _new_future(self) -> asyncio.Future[Any]:
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.get_event_loop()
        return loop.create_future()

    def push(self, event: dict[str, Any]) -> None:
        if self._done:
            return

        event_type = event.get("type")
        if event_type in {"done", "error"}:
            self._done = True
            if not self._final_result.done():
                if event_type == "done":
                    self._final_result.set_result(event.get("message", {}))
                else:
                    self._final_result.set_result(event.get("error", {}))

        if self._waiters:
            waiter = self._waiters.popleft()
            if not waiter.done():
                waiter.set_result(event)
            return

        self._queue.append(event)

    def end(self, result: dict[str, Any] | None = None) -> None:
        self._done = True
        if result is not None and not self._final_result.done():
            self._final_result.set_result(result)
        while self._waiters:
            waiter = self._waiters.popleft()
            if not waiter.done():
                waiter.set_result(None)

    async def result(self) -> dict[str, Any]:
        return await self._final_result

    def __aiter__(self) -> AsyncIterator[dict[str, Any]]:
        return self._iterate()

    async def _iterate(self) -> AsyncIterator[dict[str, Any]]:
        while True:
            if self._queue:
                yield self._queue.popleft()
                continue

            if self._done:
                return

            waiter = self._new_future()
            self._waiters.append(waiter)
            item = await waiter
            if item is None:
                return
            yield item


def _normalize_delay(ms: float) -> int | None:
    if ms <= 0:
        return None
    return int(math.ceil(ms + 1000))


def _to_now_ms(now_ms: int | float | None) -> float:
    if now_ms is not None:
        return float(now_ms)
    return time.time() * 1000


def _mapping_get_case_insensitive(mapping: Mapping[str, Any], key: str) -> str | None:
    key_lower = key.lower()
    for header_key, header_value in mapping.items():
        if str(header_key).lower() == key_lower:
            return str(header_value)
    return None


def _extract_headers(response: Any | None) -> Mapping[str, Any] | None:
    if response is None:
        return None
    if isinstance(response, Mapping):
        return response

    headers = getattr(response, "headers", None)
    if isinstance(headers, Mapping):
        return headers
    return None


def _parse_retry_after_date(value: str) -> float | None:
    try:
        parsed = parsedate_to_datetime(value)
    except (TypeError, ValueError, IndexError):
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.timestamp() * 1000


def _parse_float(value: str) -> float | None:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(parsed):
        return None
    return parsed


def _parse_int_base10(value: str) -> int | None:
    try:
        return int(value, 10)
    except (TypeError, ValueError):
        return None


def extract_retry_delay(
    error_text: str,
    response: Any | None = None,
    *,
    now_ms: int | float | None = None,
) -> int | None:
    """Port of google-gemini-cli.ts extractRetryDelay()."""
    headers = _extract_headers(response)
    current_ms = _to_now_ms(now_ms)

    if headers:
        retry_after = _mapping_get_case_insensitive(headers, "retry-after")
        if retry_after:
            retry_after_seconds = _parse_float(retry_after)
            if retry_after_seconds is not None:
                delay = _normalize_delay(retry_after_seconds * 1000)
                if delay is not None:
                    return delay

            retry_after_date_ms = _parse_retry_after_date(retry_after)
            if retry_after_date_ms is not None:
                delay = _normalize_delay(retry_after_date_ms - current_ms)
                if delay is not None:
                    return delay

        rate_limit_reset = _mapping_get_case_insensitive(headers, "x-ratelimit-reset")
        if rate_limit_reset:
            reset_seconds = _parse_int_base10(rate_limit_reset)
            if reset_seconds is not None:
                delay = _normalize_delay(reset_seconds * 1000 - current_ms)
                if delay is not None:
                    return delay

        rate_limit_reset_after = _mapping_get_case_insensitive(headers, "x-ratelimit-reset-after")
        if rate_limit_reset_after:
            reset_after_seconds = _parse_float(rate_limit_reset_after)
            if reset_after_seconds is not None:
                delay = _normalize_delay(reset_after_seconds * 1000)
                if delay is not None:
                    return delay

    duration_match = _RESET_AFTER_PATTERN.search(error_text)
    if duration_match:
        hours = int(duration_match.group(1) or 0)
        minutes = int(duration_match.group(2) or 0)
        seconds = _parse_float(duration_match.group(3))
        if seconds is not None:
            total_ms = ((hours * 60 + minutes) * 60 + seconds) * 1000
            delay = _normalize_delay(total_ms)
            if delay is not None:
                return delay

    retry_in_match = _RETRY_IN_PATTERN.search(error_text)
    if retry_in_match:
        value = _parse_float(retry_in_match.group(1))
        if value is not None and value > 0:
            unit = retry_in_match.group(2).lower()
            delay = _normalize_delay(value if unit == "ms" else value * 1000)
            if delay is not None:
                return delay

    retry_delay_match = _RETRY_DELAY_FIELD_PATTERN.search(error_text)
    if retry_delay_match:
        value = _parse_float(retry_delay_match.group(1))
        if value is not None and value > 0:
            unit = retry_delay_match.group(2).lower()
            delay = _normalize_delay(value if unit == "ms" else value * 1000)
            if delay is not None:
                return delay

    return None


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _default_usage() -> Usage:
    return {
        "input": 0,
        "output": 0,
        "cacheRead": 0,
        "cacheWrite": 0,
        "totalTokens": 0,
        "cost": {
            "input": 0.0,
            "output": 0.0,
            "cacheRead": 0.0,
            "cacheWrite": 0.0,
            "total": 0.0,
        },
    }


def _is_claude_thinking_model(model_id: str) -> bool:
    normalized = model_id.lower()
    return "claude" in normalized and "thinking" in normalized


def _map_stop_reason(reason: str | None) -> StopReason:
    if not reason:
        return "stop"

    normalized = reason.upper()
    if normalized in {"MAX_TOKENS", "LENGTH"}:
        return "length"
    if normalized == "STOP":
        return "stop"
    return "stop"


def _response_status(response: Any) -> int:
    status = getattr(response, "status", None)
    if isinstance(status, int):
        return status

    if isinstance(response, Mapping):
        mapped_status = response.get("status")
        if isinstance(mapped_status, int):
            return mapped_status

    return 200


def _response_headers(response: Any) -> Mapping[str, Any]:
    headers = getattr(response, "headers", None)
    if isinstance(headers, Mapping):
        return headers

    if isinstance(response, Mapping):
        mapped_headers = response.get("headers")
        if isinstance(mapped_headers, Mapping):
            return mapped_headers

    return {}


def _response_ok(response: Any) -> bool:
    ok = getattr(response, "ok", None)
    if isinstance(ok, bool):
        return ok
    status = _response_status(response)
    return 200 <= status < 300


def _coerce_bytes(value: Any) -> bytes:
    if isinstance(value, bytes):
        return value
    if isinstance(value, bytearray):
        return bytes(value)
    if isinstance(value, memoryview):
        return value.tobytes()
    if isinstance(value, str):
        return value.encode("utf-8")
    return str(value).encode("utf-8")


async def _iter_response_chunks(response: Any) -> AsyncIterator[bytes]:
    body = getattr(response, "body", None)
    if body is None and isinstance(response, Mapping):
        body = response.get("body")

    if body is None:
        read_fn = getattr(response, "read", None)
        if callable(read_fn):
            read_result = read_fn()
            if isinstance(read_result, Awaitable):
                read_result = await read_result
            if read_result:
                yield _coerce_bytes(read_result)
        return

    if isinstance(body, (bytes, bytearray, memoryview, str)):
        payload = _coerce_bytes(body)
        if payload:
            yield payload
        return

    if hasattr(body, "__aiter__"):
        async for chunk in body:
            if chunk is None:
                continue
            yield _coerce_bytes(chunk)
        return

    if hasattr(body, "__iter__"):
        for chunk in body:
            if chunk is None:
                continue
            yield _coerce_bytes(chunk)
        return

    read_body = getattr(body, "read", None)
    if callable(read_body):
        payload = read_body()
        if isinstance(payload, Awaitable):
            payload = await payload
        if payload:
            yield _coerce_bytes(payload)


async def _response_text(response: Any) -> str:
    text_fn = getattr(response, "text", None)
    if callable(text_fn):
        value = text_fn()
        if isinstance(value, Awaitable):
            value = await value
        return str(value)

    chunks: list[str] = []
    async for chunk in _iter_response_chunks(response):
        chunks.append(chunk.decode("utf-8", errors="replace"))
    return "".join(chunks)


def _next_tool_call_id(name: str) -> str:
    global _TOOL_CALL_COUNTER
    _TOOL_CALL_COUNTER += 1
    return f"{name}_{int(time.time() * 1000)}_{_TOOL_CALL_COUNTER}"


async def _consume_sse_response(
    response: Any,
    output: AssistantMessage,
    stream: AssistantMessageEventStream,
    *,
    started: bool,
) -> tuple[bool, bool]:
    if not _response_ok(response):
        status = _response_status(response)
        error_text = await _response_text(response)
        raise RuntimeError(f"Cloud Code Assist API error ({status}): {error_text}")

    has_content = False
    buffer = ""
    current_text_block: dict[str, Any] | None = None

    def ensure_started() -> None:
        nonlocal started
        if not started:
            stream.push({"type": "start", "partial": output})
            started = True

    def content_index() -> int:
        return len(output["content"]) - 1

    def close_text_block() -> None:
        nonlocal current_text_block
        if current_text_block is None:
            return
        stream.push(
            {
                "type": "text_end",
                "contentIndex": content_index(),
                "content": current_text_block.get("text", ""),
                "partial": output,
            }
        )
        current_text_block = None

    async for chunk in _iter_response_chunks(response):
        buffer += chunk.decode("utf-8", errors="replace")

        while "\n" in buffer:
            line, buffer = buffer.split("\n", 1)
            line = line.rstrip("\r")
            if not line.startswith("data:"):
                continue

            payload = line[5:].strip()
            if not payload or payload == "[DONE]":
                continue

            try:
                parsed = json.loads(payload)
            except json.JSONDecodeError:
                continue

            response_data = parsed.get("response")
            if not isinstance(response_data, Mapping):
                continue

            candidate = (response_data.get("candidates") or [{}])[0]
            if isinstance(candidate, Mapping):
                content = candidate.get("content")
                if isinstance(content, Mapping):
                    for part in content.get("parts") or []:
                        if not isinstance(part, Mapping):
                            continue

                        text_part = part.get("text")
                        if isinstance(text_part, str):
                            has_content = True
                            if current_text_block is None:
                                current_text_block = {"type": "text", "text": ""}
                                output["content"].append(current_text_block)
                                ensure_started()
                                stream.push(
                                    {
                                        "type": "text_start",
                                        "contentIndex": content_index(),
                                        "partial": output,
                                    }
                                )

                            current_text_block["text"] = current_text_block.get("text", "") + text_part
                            stream.push(
                                {
                                    "type": "text_delta",
                                    "contentIndex": content_index(),
                                    "delta": text_part,
                                    "partial": output,
                                }
                            )

                        function_call = part.get("functionCall")
                        if isinstance(function_call, Mapping):
                            has_content = True
                            close_text_block()

                            name = str(function_call.get("name", ""))
                            tool_call_id = str(function_call.get("id") or "") or _next_tool_call_id(name or "tool")
                            args = function_call.get("args")
                            parsed_args = args if isinstance(args, dict) else {}

                            tool_call: ToolCall = {
                                "type": "toolCall",
                                "id": tool_call_id,
                                "name": name,
                                "arguments": parsed_args,
                            }
                            output["content"].append(tool_call)
                            ensure_started()
                            stream.push({"type": "toolcall_start", "contentIndex": content_index(), "partial": output})
                            stream.push(
                                {
                                    "type": "toolcall_delta",
                                    "contentIndex": content_index(),
                                    "delta": json.dumps(parsed_args),
                                    "partial": output,
                                }
                            )
                            stream.push(
                                {
                                    "type": "toolcall_end",
                                    "contentIndex": content_index(),
                                    "toolCall": tool_call,
                                    "partial": output,
                                }
                            )

                finish_reason = candidate.get("finishReason")
                if isinstance(finish_reason, str):
                    output["stopReason"] = _map_stop_reason(finish_reason)

            usage_metadata = response_data.get("usageMetadata")
            if isinstance(usage_metadata, Mapping):
                prompt_tokens = _as_int(usage_metadata.get("promptTokenCount"), 0)
                cache_read_tokens = _as_int(usage_metadata.get("cachedContentTokenCount"), 0)
                output_tokens = _as_int(usage_metadata.get("candidatesTokenCount"), 0) + _as_int(
                    usage_metadata.get("thoughtsTokenCount"),
                    0,
                )
                total_tokens = _as_int(usage_metadata.get("totalTokenCount"), prompt_tokens + output_tokens)
                output["usage"] = {
                    "input": max(0, prompt_tokens - cache_read_tokens),
                    "output": output_tokens,
                    "cacheRead": cache_read_tokens,
                    "cacheWrite": 0,
                    "totalTokens": total_tokens,
                    "cost": {
                        "input": 0.0,
                        "output": 0.0,
                        "cacheRead": 0.0,
                        "cacheWrite": 0.0,
                        "total": 0.0,
                    },
                }

    if buffer:
        trailing = buffer.rstrip("\r")
        if trailing.startswith("data:"):
            payload = trailing[5:].strip()
            if payload and payload != "[DONE]":
                try:
                    parsed = json.loads(payload)
                    response_data = parsed.get("response")
                    if isinstance(response_data, Mapping):
                        candidate = (response_data.get("candidates") or [{}])[0]
                        if isinstance(candidate, Mapping):
                            finish_reason = candidate.get("finishReason")
                            if isinstance(finish_reason, str):
                                output["stopReason"] = _map_stop_reason(finish_reason)
                except json.JSONDecodeError:
                    pass

    close_text_block()

    if any(isinstance(block, Mapping) and block.get("type") == "toolCall" for block in output["content"]):
        output["stopReason"] = "toolUse"

    return has_content, started


FetchFn = Callable[..., Awaitable[Any]]


def stream_google_gemini_cli(
    model: Model,
    context: Context,
    options: Mapping[str, Any] | None = None,
    *,
    fetch: FetchFn | None = None,
) -> AssistantMessageEventStream:
    """Minimal async stream implementation for google-gemini-cli tests."""

    stream = AssistantMessageEventStream()
    stream_options = dict(options or {})
    fetch_fn: FetchFn | None = fetch
    if fetch_fn is None:
        maybe_fetch = stream_options.get("fetch")
        if callable(maybe_fetch):
            fetch_fn = maybe_fetch

    async def _run() -> None:
        output: AssistantMessage = {
            "role": "assistant",
            "content": [],
            "api": "google-gemini-cli",
            "provider": str(model.get("provider", "")),
            "model": str(model.get("id", "")),
            "usage": _default_usage(),
            "stopReason": "stop",
            "timestamp": int(time.time() * 1000),
        }

        try:
            if fetch_fn is None:
                raise RuntimeError("stream_google_gemini_cli requires a fetch function")

            api_key_raw = stream_options.get("apiKey")
            if not isinstance(api_key_raw, str) or not api_key_raw:
                raise RuntimeError("Google Cloud Code Assist requires OAuth authentication.")

            try:
                parsed_api_key = json.loads(api_key_raw)
            except json.JSONDecodeError as error:
                raise RuntimeError("Invalid Google Cloud Code Assist credentials.") from error

            if not isinstance(parsed_api_key, Mapping):
                raise RuntimeError("Invalid Google Cloud Code Assist credentials.")

            access_token = parsed_api_key.get("token")
            project_id = parsed_api_key.get("projectId")
            if not isinstance(access_token, str) or not access_token:
                raise RuntimeError("Missing token in Google Cloud credentials.")
            if not isinstance(project_id, str) or not project_id:
                raise RuntimeError("Missing projectId in Google Cloud credentials.")

            base_url = str(model.get("baseUrl", "")).strip() or _DEFAULT_ENDPOINT
            request_url = f"{base_url}/v1internal:streamGenerateContent?alt=sse"

            request_headers: dict[str, str] = {
                "Authorization": f"Bearer {access_token}",
                "Content-Type": "application/json",
                "Accept": "text/event-stream",
            }

            if _is_claude_thinking_model(str(model.get("id", ""))):
                request_headers["anthropic-beta"] = _CLAUDE_THINKING_BETA_HEADER

            custom_headers = stream_options.get("headers")
            if isinstance(custom_headers, Mapping):
                for key, value in custom_headers.items():
                    request_headers[str(key)] = str(value)

            request_payload = {
                "project": project_id,
                "model": str(model.get("id", "")),
                "request": {
                    "contents": context.get("messages", []),
                    "tools": context.get("tools", []),
                },
            }
            request_body = json.dumps(request_payload)

            started = False
            received_content = False

            for attempt in range(_EMPTY_STREAM_RETRIES + 1):
                response = await fetch_fn(
                    request_url,
                    method="POST",
                    headers=request_headers,
                    body=request_body,
                )
                received_content, started = await _consume_sse_response(
                    response,
                    output,
                    stream,
                    started=started,
                )
                if received_content:
                    break

                if attempt < _EMPTY_STREAM_RETRIES:
                    output["content"] = []
                    output["usage"] = _default_usage()
                    output["stopReason"] = "stop"
                    output.pop("errorMessage", None)
                    output["timestamp"] = int(time.time() * 1000)
                    started = False

            if not received_content:
                raise RuntimeError("Cloud Code Assist API returned an empty response")

            done_reason: StopReason = output.get("stopReason", "stop")
            if done_reason not in {"stop", "length", "toolUse"}:
                done_reason = "stop"
                output["stopReason"] = "stop"

            stream.push({"type": "done", "reason": done_reason, "message": output})
            stream.end()
        except Exception as error:  # noqa: BLE001 - stream always reports provider failures as event payloads.
            output["stopReason"] = "error"
            output["errorMessage"] = str(error)
            stream.push({"type": "error", "reason": "error", "error": output})
            stream.end()

    asyncio.create_task(_run())
    return stream


extractRetryDelay = extract_retry_delay
streamGoogleGeminiCli = stream_google_gemini_cli
