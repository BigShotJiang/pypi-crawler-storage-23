from __future__ import annotations

import json
import re
from typing import Any

from .transform_messages import transform_messages
from .types import Content, Context, Model, Part

_BASE64_SIGNATURE_PATTERN = re.compile(r"^[A-Za-z0-9+/]+={0,2}$")
_TOOL_CALL_ID_RE = re.compile(r"[^a-zA-Z0-9_-]")


def sanitize_surrogates(value: str) -> str:
    return "".join("\uFFFD" if 0xD800 <= ord(ch) <= 0xDFFF else ch for ch in value)


def is_thinking_part(part: dict[str, Any]) -> bool:
    return part.get("thought") is True


def retain_thought_signature(existing: str | None, incoming: str | None) -> str | None:
    if isinstance(incoming, str) and len(incoming) > 0:
        return incoming
    return existing


def _is_valid_thought_signature(signature: str | None) -> bool:
    if not signature:
        return False
    if len(signature) % 4 != 0:
        return False
    return _BASE64_SIGNATURE_PATTERN.fullmatch(signature) is not None


def _resolve_thought_signature(is_same_provider_and_model: bool, signature: str | None) -> str | None:
    if is_same_provider_and_model and _is_valid_thought_signature(signature):
        return signature
    return None


def requires_tool_call_id(model_id: str) -> bool:
    return model_id.startswith("claude-") or model_id.startswith("gpt-oss-")


def _normalize_tool_call_id(model_id: str, tool_call_id: str) -> str:
    if not requires_tool_call_id(model_id):
        return tool_call_id
    return _TOOL_CALL_ID_RE.sub("_", tool_call_id)[:64]


def _supports_image_input(model: Model) -> bool:
    return "image" in model.get("input", [])


def convert_messages(model: Model, context: Context) -> list[Content]:
    contents: list[Content] = []

    def normalize_tool_call_id(tool_call_id: str, _model: Model, _source: dict[str, Any]) -> str:
        return _normalize_tool_call_id(str(model.get("id", "")), tool_call_id)

    transformed_messages = transform_messages(
        context.get("messages", []),
        model,
        normalize_tool_call_id=normalize_tool_call_id,
    )

    for msg in transformed_messages:
        role = msg.get("role")

        if role == "user":
            user_content = msg.get("content")
            if isinstance(user_content, str):
                contents.append({"role": "user", "parts": [{"text": sanitize_surrogates(user_content)}]})
                continue

            parts: list[Part] = []
            for item in user_content or []:
                if item.get("type") == "text":
                    parts.append({"text": sanitize_surrogates(str(item.get("text", "")))})
                elif item.get("type") == "image":
                    parts.append(
                        {
                            "inlineData": {
                                "mimeType": str(item.get("mimeType", "")),
                                "data": str(item.get("data", "")),
                            }
                        }
                    )

            filtered_parts = parts if _supports_image_input(model) else [part for part in parts if part.get("text") is not None]
            if filtered_parts:
                contents.append({"role": "user", "parts": filtered_parts})
            continue

        if role == "assistant":
            parts: list[Part] = []
            is_same_provider_and_model = msg.get("provider") == model.get("provider") and msg.get("model") == model.get("id")
            model_id = str(model.get("id", ""))
            include_tool_call_id = requires_tool_call_id(model_id)
            is_gemini3 = "gemini-3" in model_id.lower()

            for block in msg.get("content", []):
                block_type = block.get("type")
                if block_type == "text":
                    text = str(block.get("text", ""))
                    if not text or text.strip() == "":
                        continue
                    thought_signature = _resolve_thought_signature(
                        is_same_provider_and_model,
                        block.get("textSignature"),
                    )
                    part: Part = {"text": sanitize_surrogates(text)}
                    if thought_signature:
                        part["thoughtSignature"] = thought_signature
                    parts.append(part)
                    continue

                if block_type == "thinking":
                    thinking_text = str(block.get("thinking", ""))
                    if not thinking_text or thinking_text.strip() == "":
                        continue

                    if is_same_provider_and_model:
                        thought_signature = _resolve_thought_signature(
                            is_same_provider_and_model,
                            block.get("thinkingSignature"),
                        )
                        part = {"thought": True, "text": sanitize_surrogates(thinking_text)}
                        if thought_signature:
                            part["thoughtSignature"] = thought_signature
                        parts.append(part)
                    else:
                        parts.append({"text": sanitize_surrogates(thinking_text)})
                    continue

                if block_type == "toolCall":
                    thought_signature = _resolve_thought_signature(
                        is_same_provider_and_model,
                        block.get("thoughtSignature"),
                    )

                    if is_gemini3 and not thought_signature:
                        args = block.get("arguments")
                        args_text = json.dumps(args if isinstance(args, dict) else {}, indent=2)
                        parts.append(
                            {
                                "text": (
                                    f"[Historical context: a different model called tool \"{block.get('name', '')}\" "
                                    f"with arguments: {args_text}. Do not mimic this format - use proper function calling.]"
                                )
                            }
                        )
                        continue

                    function_call: dict[str, Any] = {
                        "name": str(block.get("name", "")),
                        "args": block.get("arguments") if isinstance(block.get("arguments"), dict) else {},
                    }
                    if include_tool_call_id and block.get("id"):
                        function_call["id"] = str(block.get("id"))

                    part = {"functionCall": function_call}
                    if thought_signature:
                        part["thoughtSignature"] = thought_signature
                    parts.append(part)

            if parts:
                contents.append({"role": "model", "parts": parts})
            continue

        if role == "toolResult":
            content_blocks = msg.get("content", [])
            text_content = [c for c in content_blocks if c.get("type") == "text"]
            text_result = "\n".join(str(c.get("text", "")) for c in text_content)
            image_content = (
                [c for c in content_blocks if c.get("type") == "image"] if _supports_image_input(model) else []
            )

            has_text = len(text_result) > 0
            has_images = len(image_content) > 0
            supports_multimodal_function_response = "gemini-3" in str(model.get("id", ""))
            response_value = sanitize_surrogates(text_result) if has_text else "(see attached image)" if has_images else ""

            image_parts: list[Part] = [
                {
                    "inlineData": {
                        "mimeType": str(image_block.get("mimeType", "")),
                        "data": str(image_block.get("data", "")),
                    }
                }
                for image_block in image_content
            ]

            response_payload: dict[str, str] = {"error" if msg.get("isError") else "output": response_value}

            function_response: dict[str, Any] = {
                "name": str(msg.get("toolName", "")),
                "response": response_payload,
            }
            if has_images and supports_multimodal_function_response:
                function_response["parts"] = image_parts
            if requires_tool_call_id(str(model.get("id", ""))):
                function_response["id"] = str(msg.get("toolCallId", ""))

            function_response_part: Part = {"functionResponse": function_response}

            last_content = contents[-1] if contents else None
            if (
                last_content
                and last_content.get("role") == "user"
                and any(part.get("functionResponse") is not None for part in last_content.get("parts", []))
            ):
                last_content["parts"].append(function_response_part)
            else:
                contents.append({"role": "user", "parts": [function_response_part]})

            if has_images and not supports_multimodal_function_response:
                contents.append({"role": "user", "parts": [{"text": "Tool result image:"}, *image_parts]})

    return contents


isThinkingPart = is_thinking_part
retainThoughtSignature = retain_thought_signature
requiresToolCallId = requires_tool_call_id
convertMessages = convert_messages
