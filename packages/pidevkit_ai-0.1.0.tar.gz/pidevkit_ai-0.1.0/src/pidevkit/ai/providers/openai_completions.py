from __future__ import annotations

from typing import Any

from ..stream import normalize_tool_call_id


def _normalize_content(content: Any) -> Any:  # noqa: ANN401
    if isinstance(content, list):
        normalized: list[dict[str, Any]] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            if item.get("type") == "image":
                normalized.append(
                    {
                        "type": "input_image",
                        "image_url": f"data:{item.get('mimeType', 'image/png')};base64,{item.get('data', '')}",
                    }
                )
            elif item.get("type") == "text":
                normalized.append({"type": "text", "text": item.get("text", "")})
        return normalized
    return content


def convert_messages(messages: list[dict[str, Any]], tool_choice: str | dict[str, Any] | None = None) -> dict[str, Any]:
    converted: list[dict[str, Any]] = []

    for message in messages:
        role = message.get("role")
        if role == "toolResult":
            converted.append(
                {
                    "role": "tool",
                    "tool_call_id": normalize_tool_call_id(str(message.get("toolCallId", ""))),
                    "name": message.get("toolName", ""),
                    "content": _normalize_content(message.get("content")),
                }
            )
        else:
            converted.append(
                {
                    "role": role,
                    "content": _normalize_content(message.get("content")),
                }
            )

    payload: dict[str, Any] = {"messages": converted}
    if tool_choice is not None:
        payload["tool_choice"] = tool_choice
    return payload


def convertMessages(messages: list[dict[str, Any]], tool_choice: str | dict[str, Any] | None = None) -> dict[str, Any]:
    return convert_messages(messages, tool_choice)


__all__ = ["convert_messages", "convertMessages"]
