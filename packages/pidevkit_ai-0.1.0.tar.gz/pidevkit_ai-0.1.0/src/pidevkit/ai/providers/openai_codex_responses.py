from __future__ import annotations

import json
from typing import Any


def stream_openai_codex_responses(chunks: list[str]) -> list[dict[str, Any]]:
    events: list[dict[str, Any]] = []
    for chunk in chunks:
        for line in chunk.splitlines():
            if not line.startswith("data:"):
                continue
            payload = line[5:].strip()
            if payload == "[DONE]":
                events.append({"type": "done"})
                continue
            try:
                parsed = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if isinstance(parsed, dict):
                events.append(parsed)
    return events


def streamOpenAICodexResponses(chunks: list[str]) -> list[dict[str, Any]]:
    return stream_openai_codex_responses(chunks)


__all__ = ["stream_openai_codex_responses", "streamOpenAICodexResponses"]
