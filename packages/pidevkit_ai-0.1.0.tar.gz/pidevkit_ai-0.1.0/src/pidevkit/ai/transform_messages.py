from __future__ import annotations

import time
from typing import Any, Callable

from .types import AssistantMessage, Message, Model, ToolCall, ToolResultMessage


def _now_ms() -> int:
    return int(time.time() * 1000)


def _append_missing_tool_results(
    result: list[Message],
    pending_tool_calls: list[ToolCall],
    existing_tool_result_ids: set[str],
) -> None:
    for tool_call in pending_tool_calls:
        tool_call_id = tool_call.get("id")
        if not tool_call_id or tool_call_id in existing_tool_result_ids:
            continue
        result.append(
            ToolResultMessage(
                role="toolResult",
                toolCallId=tool_call_id,
                toolName=str(tool_call.get("name", "")),
                content=[{"type": "text", "text": "No result provided"}],
                isError=True,
                timestamp=_now_ms(),
            )
        )


def transform_messages(
    messages: list[Message],
    model: Model,
    normalize_tool_call_id: Callable[[str, Model, AssistantMessage], str] | None = None,
) -> list[Message]:
    """Port of packages/ai/src/providers/transform-messages.ts."""
    tool_call_id_map: dict[str, str] = {}

    transformed: list[Message] = []
    for msg in messages:
        role = msg.get("role")

        if role == "user":
            transformed.append(msg)
            continue

        if role == "toolResult":
            original_tool_call_id = str(msg.get("toolCallId", ""))
            normalized_id = tool_call_id_map.get(original_tool_call_id)
            if normalized_id and normalized_id != original_tool_call_id:
                normalized = dict(msg)
                normalized["toolCallId"] = normalized_id
                transformed.append(normalized)
            else:
                transformed.append(msg)
            continue

        if role != "assistant":
            transformed.append(msg)
            continue

        assistant_msg = msg
        is_same_model = (
            assistant_msg.get("provider") == model.get("provider")
            and assistant_msg.get("api") == model.get("api")
            and assistant_msg.get("model") == model.get("id")
        )

        transformed_content: list[dict[str, Any]] = []
        for block in assistant_msg.get("content", []):
            if block.get("type") == "thinking":
                thinking_signature = block.get("thinkingSignature")
                thinking_text = str(block.get("thinking", ""))

                if is_same_model and thinking_signature:
                    transformed_content.append(block)
                    continue
                if not thinking_text or thinking_text.strip() == "":
                    continue
                if is_same_model:
                    transformed_content.append(block)
                    continue
                transformed_content.append({"type": "text", "text": thinking_text})
                continue

            if block.get("type") == "text":
                if is_same_model:
                    transformed_content.append(block)
                else:
                    transformed_content.append({"type": "text", "text": str(block.get("text", ""))})
                continue

            if block.get("type") == "toolCall":
                tool_call = dict(block)
                tool_call_id = str(tool_call.get("id", ""))

                if not is_same_model and tool_call.get("thoughtSignature"):
                    tool_call.pop("thoughtSignature", None)

                if not is_same_model and normalize_tool_call_id and tool_call_id:
                    normalized_id = normalize_tool_call_id(tool_call_id, model, assistant_msg)
                    if normalized_id != tool_call_id:
                        tool_call_id_map[tool_call_id] = normalized_id
                        tool_call["id"] = normalized_id

                transformed_content.append(tool_call)
                continue

            transformed_content.append(block)

        transformed_assistant = dict(assistant_msg)
        transformed_assistant["content"] = transformed_content
        transformed.append(transformed_assistant)

    result: list[Message] = []
    pending_tool_calls: list[ToolCall] = []
    existing_tool_result_ids: set[str] = set()

    for msg in transformed:
        role = msg.get("role")

        if role == "assistant":
            if pending_tool_calls:
                _append_missing_tool_results(result, pending_tool_calls, existing_tool_result_ids)
                pending_tool_calls = []
                existing_tool_result_ids = set()

            stop_reason = msg.get("stopReason")
            if stop_reason in {"error", "aborted"}:
                continue

            tool_calls = [block for block in msg.get("content", []) if block.get("type") == "toolCall"]
            if tool_calls:
                pending_tool_calls = tool_calls
                existing_tool_result_ids = set()

            result.append(msg)
            continue

        if role == "toolResult":
            tool_call_id = msg.get("toolCallId")
            if isinstance(tool_call_id, str) and tool_call_id:
                existing_tool_result_ids.add(tool_call_id)
            result.append(msg)
            continue

        if role == "user":
            if pending_tool_calls:
                _append_missing_tool_results(result, pending_tool_calls, existing_tool_result_ids)
                pending_tool_calls = []
                existing_tool_result_ids = set()
            result.append(msg)
            continue

        result.append(msg)

    return result


transformMessages = transform_messages
