from __future__ import annotations

from typing import Any, Literal, TypedDict

Api = str
Provider = str


class StreamCost(TypedDict):
    input: float
    output: float
    cacheRead: float
    cacheWrite: float
    total: float


class Usage(TypedDict):
    input: int
    output: int
    cacheRead: int
    cacheWrite: int
    totalTokens: int
    cost: StreamCost


class ModelCost(TypedDict):
    input: float
    output: float
    cacheRead: float
    cacheWrite: float


class Model(TypedDict, total=False):
    id: str
    name: str
    api: Api
    provider: Provider
    baseUrl: str
    reasoning: bool
    input: list[Literal["text", "image"]]
    cost: ModelCost
    contextWindow: int
    maxTokens: int
    headers: dict[str, str]


StopReason = Literal["stop", "length", "toolUse", "error", "aborted"]


class TextContent(TypedDict, total=False):
    type: Literal["text"]
    text: str
    textSignature: str


class ThinkingContent(TypedDict, total=False):
    type: Literal["thinking"]
    thinking: str
    thinkingSignature: str


class ImageContent(TypedDict):
    type: Literal["image"]
    data: str
    mimeType: str


class ToolCall(TypedDict, total=False):
    type: Literal["toolCall"]
    id: str
    name: str
    arguments: dict[str, Any]
    thoughtSignature: str


class UserMessage(TypedDict):
    role: Literal["user"]
    content: str | list[TextContent | ImageContent]
    timestamp: int


class AssistantMessage(TypedDict, total=False):
    role: Literal["assistant"]
    content: list[TextContent | ThinkingContent | ToolCall]
    api: Api
    provider: Provider
    model: str
    usage: Usage
    stopReason: StopReason
    errorMessage: str
    timestamp: int


class ToolResultMessage(TypedDict, total=False):
    role: Literal["toolResult"]
    toolCallId: str
    toolName: str
    content: list[TextContent | ImageContent]
    details: Any
    isError: bool
    timestamp: int


Message = UserMessage | AssistantMessage | ToolResultMessage


class Tool(TypedDict, total=False):
    name: str
    description: str
    parameters: dict[str, Any]


class Context(TypedDict, total=False):
    systemPrompt: str
    messages: list[Message]
    tools: list[Tool]


class InlineData(TypedDict):
    mimeType: str
    data: str


class FunctionCall(TypedDict, total=False):
    name: str
    args: dict[str, Any]
    id: str


class FunctionResponsePayload(TypedDict, total=False):
    output: str
    error: str


class FunctionResponse(TypedDict, total=False):
    name: str
    response: FunctionResponsePayload
    parts: list["Part"]
    id: str


class Part(TypedDict, total=False):
    text: str
    thought: bool
    thoughtSignature: str
    functionCall: FunctionCall
    functionResponse: FunctionResponse
    inlineData: InlineData


class Content(TypedDict):
    role: Literal["user", "model"]
    parts: list[Part]
