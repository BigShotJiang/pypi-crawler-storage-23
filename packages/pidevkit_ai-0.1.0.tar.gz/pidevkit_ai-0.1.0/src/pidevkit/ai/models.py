from __future__ import annotations

from .types import Model

_MODEL_REGISTRY: dict[str, dict[str, Model]] = {
    "openai": {
        "gpt-5-mini": {
            "id": "gpt-5-mini",
            "name": "GPT-5 Mini",
            "api": "openai-responses",
            "provider": "openai",
            "baseUrl": "https://api.openai.com/v1",
            "reasoning": True,
            "input": ["text", "image"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        },
        "gpt-5.2-codex": {
            "id": "gpt-5.2-codex",
            "name": "GPT-5.2 Codex",
            "api": "openai-responses",
            "provider": "openai",
            "baseUrl": "https://api.openai.com/v1",
            "reasoning": True,
            "input": ["text", "image"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        },
    },
    "anthropic": {
        "claude-opus-4-6": {
            "id": "claude-opus-4-6",
            "name": "Claude Opus 4.6",
            "api": "anthropic-messages",
            "provider": "anthropic",
            "baseUrl": "https://api.anthropic.com",
            "reasoning": True,
            "input": ["text"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        },
        "claude-sonnet-4-5": {
            "id": "claude-sonnet-4-5",
            "name": "Claude Sonnet 4.5",
            "api": "anthropic-messages",
            "provider": "anthropic",
            "baseUrl": "https://api.anthropic.com",
            "reasoning": True,
            "input": ["text"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        },
    },
    "openrouter": {
        "anthropic/claude-opus-4.6": {
            "id": "anthropic/claude-opus-4.6",
            "name": "Anthropic Claude Opus 4.6",
            "api": "openai-completions",
            "provider": "openrouter",
            "baseUrl": "https://openrouter.ai/api/v1",
            "reasoning": True,
            "input": ["text"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        }
    },
    "amazon-bedrock": {
        "anthropic.claude-3-5-sonnet": {
            "id": "anthropic.claude-3-5-sonnet",
            "name": "Claude 3.5 Sonnet",
            "api": "anthropic-messages",
            "provider": "amazon-bedrock",
            "baseUrl": "https://bedrock-runtime.us-west-2.amazonaws.com",
            "reasoning": True,
            "input": ["text", "image"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        }
    },
    "opencode": {
        "zen-1": {
            "id": "zen-1",
            "name": "OpenCode Zen 1",
            "api": "openai-completions",
            "provider": "opencode",
            "baseUrl": "https://api.opencode.ai/v1",
            "reasoning": True,
            "input": ["text"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 200000,
            "maxTokens": 32000,
        }
    },
    "google": {
        "gemini-2.5-flash": {
            "id": "gemini-2.5-flash",
            "name": "Gemini 2.5 Flash",
            "api": "google-generative-ai",
            "provider": "google",
            "baseUrl": "https://generativelanguage.googleapis.com",
            "reasoning": True,
            "input": ["text", "image"],
            "cost": {"input": 0.0, "output": 0.0, "cacheRead": 0.0, "cacheWrite": 0.0},
            "contextWindow": 1000000,
            "maxTokens": 32000,
        }
    },
}


def get_model(provider: str, model_id: str) -> Model | None:
    provider_models = _MODEL_REGISTRY.get(provider)
    if not provider_models:
        return None

    model = provider_models.get(model_id)
    if model is None:
        return None
    return dict(model)


def get_models(provider: str) -> list[Model]:
    provider_models = _MODEL_REGISTRY.get(provider)
    if not provider_models:
        return []
    return [dict(model) for model in provider_models.values()]


def get_providers() -> list[str]:
    return sorted(_MODEL_REGISTRY.keys())


def supports_xhigh(model: Model) -> bool:
    model_id = str(model.get("id", ""))
    if "gpt-5.2" in model_id or "gpt-5.3" in model_id:
        return True

    if str(model.get("api", "")) == "anthropic-messages":
        normalized = model_id.lower()
        return "opus-4-6" in normalized or "opus-4.6" in normalized

    return False


getModel = get_model
getModels = get_models
getProviders = get_providers
supportsXhigh = supports_xhigh
