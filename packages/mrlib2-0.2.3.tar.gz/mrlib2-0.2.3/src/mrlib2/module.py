import requests
import sys

def minimax():
	API_KEY = "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"
	MODEL = "minimax/minimax-m2.5"
	ENDPOINT = "https://openrouter.ai/api/v1/chat/completions"

	HEADERS = {
		"Authorization": f"Bearer {API_KEY}",
		"X-Title": "Russian Chat Bot"
	}

	messages = [
		{"role": "system", "content": "Ты — интеллектуальный помощник. Отвечай всегда на русском языке. Будь вежливым и точным."}
	]

	print(f"💬 Чат с {MODEL} запущен. Напишите 'выход' для завершения.\n")

	while True:
		try:
			user_input = input("Вы: ").strip()
			if not user_input:
				print("Бот: Пожалуйста, введите сообщение.")
				continue
			if user_input.lower() in ["выход", "exit", "quit", "стоп"]:
				print("Бот: До свидания!")
				break

			messages.append({"role": "user", "content": user_input})

			response = requests.post(
				url=ENDPOINT,
				headers=HEADERS,
				json={
					"model": MODEL,
					"messages": messages,
					"temperature": 0.7,
					"max_tokens": 512
				},
				timeout=30
			)

			if response.status_code == 200:
				data = response.json()
				bot_response = data["choices"][0]["message"]["content"]
				print(f"Бот: {bot_response}")
				with open("log.txt", "a", encoding="utf-8") as f:
					f.write("Вы: " + user_input + "\n")
					f.write("Бот: " + bot_response + "\n")

				messages.append({"role": "assistant", "content": bot_response})
			else:
				error_msg = response.json().get("error", {}).get("message", response.text)
				print(f"❌ Ошибка API ({response.status_code}): {error_msg}")
				if response.status_code == 402:
					print("💡 Подсказка: возможно, закончился баланс. Проверьте аккаунт на https://openrouter.ai/keys")
				elif response.status_code == 404:
					print("💡 Модель не найдена. Убедитесь, что указана правильная модель.")

		except requests.exceptions.Timeout:
			print("❌ Ошибка: таймаут соединения с сервером.")
		except requests.exceptions.RequestException as e:
			print(f"❌ Ошибка сети: {e}")
		except KeyboardInterrupt:
			print("\n👋 Программа остановлена.")
			sys.exit(0)
		except Exception as e:
			print(f"❌ Неизвестная ошибка: {e}")

	print("Чат завершён.")

if __name__ == "__main__":
	minimax()
