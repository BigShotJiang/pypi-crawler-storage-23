from __future__ import annotations

REDNOTE_PLATFORM = "Rednote"
TIKTOK_PLATFORM = "TikTok"
