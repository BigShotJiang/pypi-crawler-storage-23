from __future__ import annotations

import sys
from pathlib import Path


def write_output(content: str, out_file: str | None = None) -> None:
    print(content)
    if out_file:
        path = Path(out_file).expanduser().resolve()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content + "\n", encoding="utf-8")


def write_error(content: str) -> None:
    sys.stderr.write(content + "\n")
    sys.stderr.flush()
