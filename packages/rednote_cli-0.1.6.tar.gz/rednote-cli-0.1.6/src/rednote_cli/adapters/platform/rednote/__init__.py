"""Rednote platform adapters."""
