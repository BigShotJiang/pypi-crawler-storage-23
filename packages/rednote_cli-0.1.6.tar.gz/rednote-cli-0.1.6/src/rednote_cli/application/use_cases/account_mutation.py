from __future__ import annotations

from rednote_cli.adapters.persistence.file_account_repo import FileAccountRepository
from rednote_cli.infra.platforms import REDNOTE_PLATFORM


def execute_account_activate(account_uid: str) -> dict:
    repo = FileAccountRepository()
    changed = repo.activate(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"changed": changed, "platform": REDNOTE_PLATFORM, "account_uid": account_uid, "active": True}


def execute_account_deactivate(account_uid: str) -> dict:
    repo = FileAccountRepository()
    changed = repo.deactivate(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"changed": changed, "platform": REDNOTE_PLATFORM, "account_uid": account_uid, "active": False}


def execute_account_delete(account_uid: str) -> dict:
    repo = FileAccountRepository()
    deleted = repo.delete(platform=REDNOTE_PLATFORM, account_uid=account_uid)
    return {"deleted": deleted, "platform": REDNOTE_PLATFORM, "account_uid": account_uid}
