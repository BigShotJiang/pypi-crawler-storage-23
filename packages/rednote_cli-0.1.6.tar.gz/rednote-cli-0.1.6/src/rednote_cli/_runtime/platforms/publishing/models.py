from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Optional


class PublishTarget(str, Enum):
    IMAGE = "image"
    VIDEO = "video"
    ARTICLE = "article"


class PublishStage(str, Enum):
    INIT = "init"
    MEDIA_READY = "media_ready"
    PAGE_READY = "page_ready"
    UPLOAD_DONE = "upload_done"
    FORM_FILLED = "form_filled"
    SUBMITTED = "submitted"
    VERIFIED = "verified"
    FAILED = "failed"


@dataclass
class PublishRequest:
    target: PublishTarget
    title: str
    content: str
    media_list: list[str]
    tags: list[str] = field(default_factory=list)
    schedule_at: Optional[datetime] = None
    account_uid: Optional[str] = None


@dataclass
class PublishResult:
    success: bool
    stage: PublishStage
    uploaded_count: int = 0
    publish_url: str = ""
    publish_id: str = ""
    risk_flags: list[str] = field(default_factory=list)
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "success": self.success,
            "stage": self.stage.value,
            "uploaded_count": self.uploaded_count,
            "publish_url": self.publish_url,
            "publish_id": self.publish_id,
            "risk_flags": self.risk_flags,
            "message": self.message,
        }
        payload.update(self.data)
        return payload
