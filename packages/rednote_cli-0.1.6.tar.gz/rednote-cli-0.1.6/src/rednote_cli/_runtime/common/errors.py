class PublishNoteException(Exception):
    """Base exception for publish-note workflow."""

    def __init__(self, message: str = "", details: dict | None = None):
        super().__init__(message)
        self.details = details


class InvalidPublishParameterError(PublishNoteException, ValueError):
    """Raised when publish-note inputs are invalid."""


class UnsupportedPublishTargetError(PublishNoteException):
    """Raised when publish target is unsupported."""


class PublishWorkflowNotReadyError(PublishNoteException):
    """Raised when target exists but workflow is not implemented yet."""


class PublishMediaPreparationError(PublishNoteException):
    """Raised when media validation/download fails."""


class PublishExecutionError(PublishNoteException):
    """Raised when publish execution fails unexpectedly."""
