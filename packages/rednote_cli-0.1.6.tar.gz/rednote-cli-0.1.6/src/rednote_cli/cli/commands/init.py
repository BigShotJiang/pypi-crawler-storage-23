from __future__ import annotations

import typer

from rednote_cli.application.use_cases.init_runtime import execute_runtime_init
from rednote_cli.cli.options import CliContext
from rednote_cli.cli.runtime import run_sync_command

app = typer.Typer(help="初始化运行环境与本地存储", no_args_is_help=True)


@app.command("runtime")
def init_runtime(ctx: typer.Context):
    """
    初始化运行时目录与存储文件。

    返回字段包括 `app_home`、`accounts_dir`、`settings_file`、`task_schedules_file`。
    """
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="init.runtime", func=execute_runtime_init)
