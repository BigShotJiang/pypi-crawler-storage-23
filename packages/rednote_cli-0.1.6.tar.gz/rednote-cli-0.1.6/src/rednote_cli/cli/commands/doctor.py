from __future__ import annotations

import typer

from rednote_cli.application.use_cases.doctor import execute_doctor
from rednote_cli.cli.options import CliContext
from rednote_cli.cli.runtime import run_sync_command

app = typer.Typer(help="环境诊断与依赖自检", no_args_is_help=True)


@app.command("run")
def doctor_run(ctx: typer.Context):
    """
    执行自检并输出可机读诊断结果。

    推荐：`rednote-cli doctor run --format json`。
    """
    cli_ctx: CliContext = ctx.obj
    run_sync_command(ctx=cli_ctx, command="doctor.run", func=execute_doctor)
