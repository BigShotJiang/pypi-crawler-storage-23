# CHANGELOG

<!-- version list -->

## v1.0.17 (2026-02-24)

### Bug Fixes

- Add marker for hotreload
  ([`fb0fd1d`](https://github.com/PyMoX-fr/Kit/commit/fb0fd1da912bc81b50c3b0959c77aa15c0f1f27f))


## v1.0.16 (2026-02-24)


## v1.0.15 (2026-02-24)


## v1.0.14 (2026-02-24)

### Bug Fixes

- New pp tk
  ([`ef10cf5`](https://github.com/PyMoX-fr/Kit/commit/ef10cf502de7a48bdb1d10e8ccea2aa74c489ed6))


## v1.0.13 (2026-02-24)

### Bug Fixes

- New folder
  ([`38661c7`](https://github.com/PyMoX-fr/Kit/commit/38661c72ee656a2a29073c23a37eb274fca40046))


## v1.0.1 (2026-02-24)

### Bug Fixes

- Good folder for module
  ([`148c659`](https://github.com/PyMoX-fr/Kit/commit/148c65988f2d75c2e712e57609cdaf731d9324da))


## v1.0.0 (2026-02-24)

- Initial Release
