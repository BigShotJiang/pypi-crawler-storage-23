# pylint: disable=missing-module-docstring
from .git_show_bigfiles import _main_
raise SystemExit(_main_())
