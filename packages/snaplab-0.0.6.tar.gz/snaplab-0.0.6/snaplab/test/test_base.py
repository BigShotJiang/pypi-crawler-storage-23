import pytest
from sklearn.base import BaseEstimator, RegressorMixin

from snaplab.evaluation.base import BaseEvaluator


# -----------------------------------
# Dummy Evaluator for testing
# -----------------------------------
class DummyEvaluator(BaseEvaluator):
    def evaluate(self):
        return {"ok": True}


# -----------------------------------
# Dummy sklearn-compatible model
# -----------------------------------
class DummyModel(BaseEstimator, RegressorMixin):
    def predict(self, X):
        return X


# -----------------------------------
# Tests
# -----------------------------------

def test_base_initialization_valid():
    model = DummyModel()
    X = [1, 2, 3]
    y = [1, 2, 3]

    evaluator = DummyEvaluator(model, X, y)

    assert evaluator.model is model
    assert evaluator.X_test == X
    assert evaluator.y_test == y


def test_invalid_model():
    with pytest.raises(TypeError):
        DummyEvaluator(object(), [1], [1])


def test_length_mismatch():
    model = DummyModel()
    with pytest.raises(ValueError):
        DummyEvaluator(model, [1, 2], [1])


def test_none_inputs():
    model = DummyModel()
    with pytest.raises(ValueError):
        DummyEvaluator(model, None, None)