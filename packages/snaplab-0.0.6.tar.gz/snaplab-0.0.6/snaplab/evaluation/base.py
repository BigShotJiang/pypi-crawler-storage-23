from abc import ABC, abstractmethod
from .core.validation import validate_evaluation_input
from .core.inspector import get_model_type


class BaseEvaluator(ABC):
    """
    Base class for all evaluators.
    Provides shared logic and enforces interface.
    """
    def __init__(self, model, x_test, y_test, parallel=False):
        self.model = model
        self.X_test = x_test
        self.y_test = y_test
        self.parallel = parallel

        validate_evaluation_input(model, x_test, y_test)
        self._model_type = get_model_type(model)

    @property
    def model_type(self):
        return self._model_type

    ## Abstract Method
    @abstractmethod
    def evaluate(self) -> dict:
        pass
