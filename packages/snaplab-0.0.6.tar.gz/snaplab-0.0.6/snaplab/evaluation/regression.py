import numpy as np
from sklearn.metrics import (
    mean_squared_error,
    mean_absolute_error,
    root_mean_squared_error,
    r2_score,
    explained_variance_score,
    max_error,
    median_absolute_error,
    mean_absolute_percentage_error,
)

from .base import BaseEvaluator


class RegressionEvaluator(BaseEvaluator):
    """
    Evaluator for regression models.
    Supports standard regression metrics.
    """

    def evaluate(self) -> dict:
        if self.model_type != "regression":
            raise ValueError("Provided model is not a regression model")

        y_pred = self.model.predict(self.X_test)

        y_true = np.asarray(self.y_test)
        y_pred = np.asarray(y_pred)

        # Store for plotting
        self.y_true_ = y_true
        self.y_pred_ = y_pred

        return {
            "r2_score": float(r2_score(y_true, y_pred)),
            "explained_variance": float(explained_variance_score(y_true, y_pred)),
            "mse": float(mean_squared_error(y_true, y_pred)),
            "rmse": float(root_mean_squared_error(y_true, y_pred)),
            "mae": float(mean_absolute_error(y_true, y_pred)),
            "median_ae": float(median_absolute_error(y_true, y_pred)),
            "mape": float(mean_absolute_percentage_error(y_true, y_pred)),
            "max_error": float(max_error(y_true, y_pred)),
        }