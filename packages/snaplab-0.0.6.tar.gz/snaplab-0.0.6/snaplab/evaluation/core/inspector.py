from sklearn.base import is_classifier, is_regressor


def get_model_type(model) -> str:
    """
        Determine the model type.

        Returns
        -------
        str
            "classification", "regression", or "unknown"
    """
    if is_classifier(model):
        return "classification"

    if is_regressor(model):
        return "regression"

    return "unknown"
