def validate_evaluation_input(model, X_test, y_test):
    """
        Validate the evaluation inputs.

        This method ensures that:
        - A model is provided.
        - The model implements a callable `predict` method.
        - Test features (X_test) and targets (y_test) are not None.
        - X_test and y_test have matching lengths.

        Raises
        ------
        ValueError
            If the model is None.
            If X_test or y_test is None.
            If X_test and y_test do not have the same length.

        TypeError
            If the model does not implement a callable `predict` method.
        """
    if model is None:
        raise ValueError("model cannot be None")

    if not callable(getattr(model, "predict", None)):
        raise TypeError("model must implement a callable 'predict' method")

    if X_test is None or y_test is None:
        raise ValueError("X_test and y_test cannot be None")

    if len(X_test) != len(y_test):
        raise ValueError("X_test and y_test must have the same length")

    if len(X_test) == 0:
        raise ValueError("Test data cannot be empty")