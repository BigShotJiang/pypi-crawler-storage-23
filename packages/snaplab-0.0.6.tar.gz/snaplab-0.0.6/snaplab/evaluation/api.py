from .classification import ClassificationEvaluator
from .regression import RegressionEvaluator
from .result import EvaluationResult
from .core.inspector import get_model_type


def evaluate(model, X_test, y_test, parallel: bool = False) -> EvaluationResult:
    """
    Public evaluation entry point.

    Automatically selects the correct evaluator
    based on model type.

    Parameters
    ----------
    model : object
        Trained model implementing `predict`.
    X_test : array-like
        Test features.
    y_test : array-like
        True labels.
    parallel : bool, default=False
        Whether to enable parallel computation.

    Returns
    -------
    EvaluationResult
        Object containing computed metrics.
        Renders as HTML in Jupyter, prints cleanly in terminals.
        Use `.to_dict()` for raw metrics dictionary.

    Raises
    ------
    ValueError
        If model type is unsupported.
    """

    model_type = get_model_type(model)

    if model_type == "classification":
        evaluator = ClassificationEvaluator(model, X_test, y_test, parallel)
        metrics = evaluator.evaluate()
        return EvaluationResult(
            metrics, model_type,
            confusion_matrix=evaluator.confusion_matrix_,
            class_labels=evaluator.class_labels_,
            y_true=evaluator.y_true_,
            y_pred=evaluator.y_pred_,
            y_proba=evaluator.y_proba_,
        )

    elif model_type == "regression":
        evaluator = RegressionEvaluator(model, X_test, y_test, parallel)
        metrics = evaluator.evaluate()
        return EvaluationResult(
            metrics, model_type,
            y_true=evaluator.y_true_,
            y_pred=evaluator.y_pred_,
        )

    else:
        raise ValueError("Unsupported model type")