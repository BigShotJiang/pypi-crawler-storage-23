"""CLI for scanning models"""

import logging

from modelscan._version import __version__

logging.getLogger("modelscan").addHandler(logging.NullHandler())
