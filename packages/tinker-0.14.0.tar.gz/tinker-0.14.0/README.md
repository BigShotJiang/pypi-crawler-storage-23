<h1 align="center">Tinker Python SDK</h1>
<div align="center">
  <img src="https://github.com/thinking-machines-lab/tinker/blob/829c151ba7c6740a84db02e41f03825084c37fed/docs/images/logo.png" width="60%" />

  Documentation:
  <a href="http://tinker-docs.thinkingmachines.ai/">tinker-docs.thinkingmachines.ai</a>
</div>
