import setuptools
setuptools.setup()
 