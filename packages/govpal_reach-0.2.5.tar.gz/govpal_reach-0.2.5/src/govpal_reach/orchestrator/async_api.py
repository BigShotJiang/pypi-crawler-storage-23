"""Async wrappers around govpal sync API for use in async frameworks (e.g. FastAPI)."""

import asyncio
from uuid import UUID
from typing import Any, Optional

from govpal.identity import (
    request_otp as _request_otp_sync,
    verify_otp as _verify_otp_sync,
    get_user_by_phone,
    get_profile as _get_profile_sync,
    upsert_profile as _upsert_profile_sync,
    delete_user_by_phone as _delete_user_by_phone_sync,
    generate_identity_token as _generate_identity_token_sync,
    validate_identity_token as _validate_identity_token_sync,
)
from govpal.identity.models import UserProfile
from govpal.orchestrator.api import (
    discover_reps_for_address as _discover_sync,
    send_message_to_representatives as _send_sync,
    delivery_method_for_rep as _method_sync,
)


def _dsn_from_config(config: Any) -> Optional[str]:
    if config is None:
        return None
    return getattr(config, "database_url", None)


async def request_otp(
    phone: str, *, config: Any = None, **kwargs: Any
) -> tuple[bool, Optional[str]]:
    dsn = _dsn_from_config(config) if "dsn" not in kwargs else kwargs.get("dsn")
    return await asyncio.to_thread(
        _request_otp_sync,
        phone,
        dsn=dsn,
        **{k: v for k, v in kwargs.items() if k != "config"},
    )


async def verify_otp(
    phone: str, code: str, *, config: Any = None, **kwargs: Any
) -> tuple[bool, Any]:
    dsn = _dsn_from_config(config) if "dsn" not in kwargs else kwargs.get("dsn")
    success, err = await asyncio.to_thread(
        _verify_otp_sync,
        phone,
        code,
        dsn=dsn,
        **{k: v for k, v in kwargs.items() if k != "config"},
    )
    if not success:
        return success, err
    user = get_user_by_phone(phone, dsn=dsn)
    if not user:
        return True, {}
    return True, {
        "user_id": str(user.id),
        "phone": user.phone,
        "phone_verified": user.phone_verified,
    }


async def discover_reps_for_address(
    address: str, *, config: Any = None, **kwargs: Any
) -> list:
    return await asyncio.to_thread(_discover_sync, address, config=config, **kwargs)


async def send_message_to_representatives(
    body: str,
    subject: str,
    profile: Any,
    phone: str,
    reps: list,
    *,
    config: Any = None,
    **kwargs: Any,
) -> list:
    return await asyncio.to_thread(
        _send_sync, body, subject, profile, phone, reps, config=config, **kwargs
    )


def delivery_method_for_rep(rep: dict) -> Optional[str]:
    return _method_sync(rep)


async def get_profile_for_user(
    user_id: str,
    *,
    config: Any = None,
    **kwargs: Any,
) -> Optional[dict]:
    """Load user profile; return dict with first_name, last_name, email, address, or None."""
    dsn = _dsn_from_config(config) if "dsn" not in kwargs else kwargs.get("dsn")
    profile = await asyncio.to_thread(
        _get_profile_sync,
        UUID(user_id),
        dsn=dsn,
        config=config,
        **{k: v for k, v in kwargs.items() if k not in ("config", "dsn")},
    )
    if not profile:
        return None
    name_parts = [profile.first_name, profile.last_name]
    name = " ".join(p for p in name_parts if p).strip() or None
    return {
        "first_name": profile.first_name,
        "last_name": profile.last_name,
        "name": name,
        "email": profile.email,
        "address": profile.full_address_for_display() or profile.address,
    }


async def save_user_profile(
    user_id: str,
    *,
    first_name: Optional[str] = None,
    last_name: Optional[str] = None,
    email: Optional[str] = None,
    address: Optional[str] = None,
    config: Any = None,
    **kwargs: Any,
) -> None:
    """Upsert user profile (encrypted)."""
    dsn = _dsn_from_config(config) if "dsn" not in kwargs else kwargs.get("dsn")
    profile = UserProfile(
        user_id=UUID(user_id),
        first_name=first_name,
        last_name=last_name,
        email=email,
        address=address,
    )
    await asyncio.to_thread(
        _upsert_profile_sync,
        profile,
        dsn=dsn,
        config=config,
        **{k: v for k, v in kwargs.items() if k not in ("config", "dsn")},
    )


async def delete_user(
    phone: str,
    *,
    config: Any = None,
    **kwargs: Any,
) -> bool:
    """Delete user by phone; returns True if deleted, False if not found."""
    dsn = _dsn_from_config(config) if "dsn" not in kwargs else kwargs.get("dsn")
    return await asyncio.to_thread(
        _delete_user_by_phone_sync,
        phone,
        dsn=dsn,
        config=config,
        **{k: v for k, v in kwargs.items() if k != "config"},
    )


async def generate_identity_token(
    user_id: str,
    phone: str,
    *,
    config: Any = None,
    **kwargs: Any,
) -> str:
    """Produce Fernet identity token (180-day TTL)."""
    return await asyncio.to_thread(
        _generate_identity_token_sync,
        user_id,
        phone,
        config=config,
        **{k: v for k, v in kwargs.items() if k != "config"},
    )


async def validate_identity_token(
    token: str,
    *,
    config: Any = None,
    **kwargs: Any,
) -> Optional[dict]:
    """Validate identity token; return dict with user_id and phone or None."""
    return await asyncio.to_thread(
        _validate_identity_token_sync,
        token,
        config=config,
        **{k: v for k, v in kwargs.items() if k != "config"},
    )


__all__ = [
    "request_otp",
    "verify_otp",
    "discover_reps_for_address",
    "send_message_to_representatives",
    "delivery_method_for_rep",
    "get_profile_for_user",
    "save_user_profile",
    "delete_user",
    "generate_identity_token",
    "validate_identity_token",
]
