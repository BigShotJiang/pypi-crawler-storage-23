from govpal.alembic import get_versions_path

__all__ = ["get_versions_path"]
