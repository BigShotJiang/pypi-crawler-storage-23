"""Compatibility package: re-export govpal as govpal_reach so clients can use either import name."""

from govpal.config import Config, ValidationResult, validate_config, validate_config_live
from govpal import __version__, get_version_info

__all__ = [
    "Config",
    "ValidationResult",
    "validate_config",
    "validate_config_live",
    "__version__",
    "get_version_info",
]
