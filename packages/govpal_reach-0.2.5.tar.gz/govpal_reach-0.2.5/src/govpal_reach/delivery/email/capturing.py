from govpal.delivery.email.capturing import (
    CapturingEmailProvider,
    get_capturing_provider,
)

__all__ = ["CapturingEmailProvider", "get_capturing_provider"]
