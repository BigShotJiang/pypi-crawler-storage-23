"""Config abstraction for env/file-based configuration."""

import os
from dataclasses import dataclass
from typing import Any

# (Config attribute name, env var / dict key). Order matches Config field order.
_CONFIG_KEYS: list[tuple[str, str]] = [
    ("database_url", "DATABASE_URL"),
    ("pii_encryption_key", "PII_ENCRYPTION_KEY"),
    ("google_civic_api_key", "GOOGLE_CIVIC_API_KEY"),
    ("google_address_validation_api_key", "GOOGLE_ADDRESS_VALIDATION_API_KEY"),
    ("openstates_api_key", "OPENSTATES_API_KEY"),
    ("usps_user_id", "USPS_USER_ID"),
    ("govpal_email_from_brand", "GOVPAL_EMAIL_FROM_BRAND"),
    ("postmark_server_token", "POSTMARK_SERVER_TOKEN"),
    ("postmark_from_address", "POSTMARK_FROM_ADDRESS"),
    ("plivo_auth_id", "PLIVO_AUTH_ID"),
    ("plivo_auth_token", "PLIVO_AUTH_TOKEN"),
    ("plivo_src_number", "PLIVO_SRC_NUMBER"),
    ("plivo_verify_app_uuid", "PLIVO_VERIFY_APP_UUID"),
    ("twilio_account_sid", "TWILIO_ACCOUNT_SID"),
    ("twilio_auth_token", "TWILIO_AUTH_TOKEN"),
    ("twilio_phone_number", "TWILIO_PHONE_NUMBER"),
    ("twilio_verify_service_sid", "TWILIO_VERIFY_SERVICE_SID"),
    ("sms_provider", "SMS_PROVIDER"),
]


@dataclass(frozen=True)
class Config:
    """
    Library configuration. Populate from env or dict for testing/override.

    When Config is passed to library APIs, it overrides os.environ lookups.
    Missing values are empty string or None as appropriate.
    """

    database_url: str = ""
    pii_encryption_key: str = ""
    google_civic_api_key: str = ""
    google_address_validation_api_key: str = ""
    openstates_api_key: str = ""
    usps_user_id: str = ""
    govpal_email_from_brand: str = ""
    postmark_server_token: str = ""
    postmark_from_address: str = ""
    plivo_auth_id: str = ""
    plivo_auth_token: str = ""
    plivo_src_number: str = ""
    plivo_verify_app_uuid: str = ""
    twilio_account_sid: str = ""
    twilio_auth_token: str = ""
    twilio_phone_number: str = ""
    twilio_verify_service_sid: str = ""
    sms_provider: str = ""

    @classmethod
    def from_env(cls) -> "Config":
        """Load config from os.environ."""
        kwargs = {
            attr: (os.environ.get(env_key) or "").strip()
            for attr, env_key in _CONFIG_KEYS
        }
        return cls(**kwargs)

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Config":
        """
        Load config from flat dict (e.g. test_app load_config).
        Keys match env var names; values are strings.
        """

        def _get(k: str) -> str:
            v = d.get(k)
            return (v or "").strip() if isinstance(v, str) else ""

        kwargs = {attr: _get(env_key) for attr, env_key in _CONFIG_KEYS}
        return cls(**kwargs)


# Validation result type
from typing import Literal

ValidationStatus = Literal["valid", "invalid", "missing", "skipped"]


@dataclass
class ValidationResult:
    """Result of validating a single service's API key."""

    service: str
    status: ValidationStatus
    message: str


def _validate_sms_config(config: "Config") -> ValidationResult:
    """Check SMS provider credentials (Twilio or Plivo)."""
    # Check which provider is selected
    provider = (config.sms_provider or "").lower().strip()

    has_twilio = bool(
        config.twilio_account_sid
        and config.twilio_auth_token
        and config.twilio_verify_service_sid
    )
    has_plivo = bool(
        config.plivo_auth_id
        and config.plivo_auth_token
        and config.plivo_verify_app_uuid
    )

    if not has_twilio and not has_plivo:
        return ValidationResult(
            service="SMS Provider",
            status="missing",
            message="Neither Twilio nor Plivo credentials configured",
        )

    # If provider specified, check that one
    if provider == "plivo":
        if has_plivo:
            return ValidationResult(
                service="SMS Provider (Plivo)",
                status="valid",
                message="Plivo credentials present",
            )
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="invalid",
            message="SMS_PROVIDER=plivo but Plivo credentials missing",
        )

    # Default to Twilio
    if has_twilio:
        return ValidationResult(
            service="SMS Provider (Twilio)",
            status="valid",
            message="Twilio credentials present",
        )
    if has_plivo:
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="valid",
            message="Plivo credentials present (Twilio not configured)",
        )

    return ValidationResult(
        service="SMS Provider",
        status="missing",
        message="No SMS provider credentials configured",
    )


def _validate_postmark_config(config: "Config") -> ValidationResult:
    """Check Postmark email credentials."""
    if not config.postmark_server_token:
        return ValidationResult(
            service="Postmark",
            status="missing",
            message="POSTMARK_SERVER_TOKEN not set",
        )
    if not config.postmark_from_address:
        return ValidationResult(
            service="Postmark",
            status="invalid",
            message="POSTMARK_FROM_ADDRESS not set (token present)",
        )
    return ValidationResult(
        service="Postmark",
        status="valid",
        message="Postmark credentials present",
    )


def _validate_google_civic_config(config: "Config") -> ValidationResult:
    """Check Google Civic API key."""
    if not config.google_civic_api_key:
        return ValidationResult(
            service="Google Civic API",
            status="missing",
            message="GOOGLE_CIVIC_API_KEY not set",
        )
    return ValidationResult(
        service="Google Civic API",
        status="valid",
        message="API key present",
    )


def _validate_openstates_config(config: "Config") -> ValidationResult:
    """Check Open States API key."""
    if not config.openstates_api_key:
        return ValidationResult(
            service="Open States API",
            status="missing",
            message="OPENSTATES_API_KEY not set",
        )
    return ValidationResult(
        service="Open States API",
        status="valid",
        message="API key present",
    )


def validate_config(config: "Config") -> list[ValidationResult]:
    """Validate all API keys in config (presence check only, no network calls).

    Returns a list of ValidationResult for each service. This is a fast
    synchronous check that only verifies credentials are present.

    Args:
        config: The Config instance to validate.

    Returns:
        List of ValidationResult, one per service.
    """
    return [
        _validate_sms_config(config),
        _validate_postmark_config(config),
        _validate_google_civic_config(config),
        _validate_openstates_config(config),
    ]


async def validate_config_live(config: "Config") -> list[ValidationResult]:
    """Validate API keys with live API calls to verify they work.

    This makes actual API requests to verify each service is accessible.
    Use for startup validation when you want to catch invalid keys early.

    Args:
        config: The Config instance to validate.

    Returns:
        List of ValidationResult, one per service.
    """
    results = []

    # SMS provider - test with live API call (Twilio or Plivo)
    results.append(await _test_twilio_live(config))

    # Postmark - test server token with live API call
    results.append(await _test_postmark_live(config))

    # Google Civic - test with a known address
    results.append(await _test_google_civic_live(config))

    # Open States - test with a known location
    results.append(await _test_openstates_live(config))

    return results


async def _test_twilio_live(config: "Config") -> ValidationResult:
    """Test Twilio credentials by fetching account info."""
    provider = (config.sms_provider or "").lower().strip()

    # Skip if Plivo is explicitly selected
    if provider == "plivo":
        return await _test_plivo_live(config)

    if not config.twilio_account_sid or not config.twilio_auth_token:
        # Check if Plivo is configured as fallback
        if config.plivo_auth_id and config.plivo_auth_token:
            return await _test_plivo_live(config)
        return ValidationResult(
            service="SMS Provider",
            status="missing",
            message="No SMS provider credentials configured",
        )

    import asyncio
    import base64
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

    try:
        url = f"https://api.twilio.com/2010-04-01/Accounts/{config.twilio_account_sid}.json"
        credentials = f"{config.twilio_account_sid}:{config.twilio_auth_token}"
        auth_header = base64.b64encode(credentials.encode()).decode()

        def _fetch():
            req = Request(
                url,
                headers={
                    "Authorization": f"Basic {auth_header}",
                    "User-Agent": "GovPal-Reach/1.0",
                },
            )
            with urlopen(req, timeout=10) as resp:
                return resp.status

        status = await asyncio.to_thread(_fetch)
        if status == 200:
            return ValidationResult(
                service="SMS Provider (Twilio)",
                status="valid",
                message="Credentials validated successfully",
            )
        return ValidationResult(
            service="SMS Provider (Twilio)",
            status="invalid",
            message=f"Unexpected status: {status}",
        )

    except HTTPError as e:
        if e.code == 401:
            return ValidationResult(
                service="SMS Provider (Twilio)",
                status="invalid",
                message="Invalid credentials (401 Unauthorized)",
            )
        return ValidationResult(
            service="SMS Provider (Twilio)",
            status="invalid",
            message=f"HTTP error: {e.code}",
        )
    except (URLError, OSError) as e:
        return ValidationResult(
            service="SMS Provider (Twilio)",
            status="invalid",
            message=f"Connection error: {e}",
        )
    except Exception as e:
        return ValidationResult(
            service="SMS Provider (Twilio)",
            status="invalid",
            message=f"Validation error: {e}",
        )


async def _test_plivo_live(config: "Config") -> ValidationResult:
    """Test Plivo credentials by fetching account info."""
    if not config.plivo_auth_id or not config.plivo_auth_token:
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="missing",
            message="Plivo credentials not configured",
        )

    import asyncio
    import base64
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

    try:
        url = f"https://api.plivo.com/v1/Account/{config.plivo_auth_id}/"
        credentials = f"{config.plivo_auth_id}:{config.plivo_auth_token}"
        auth_header = base64.b64encode(credentials.encode()).decode()

        def _fetch():
            req = Request(
                url,
                headers={
                    "Authorization": f"Basic {auth_header}",
                    "User-Agent": "GovPal-Reach/1.0",
                },
            )
            with urlopen(req, timeout=10) as resp:
                return resp.status

        status = await asyncio.to_thread(_fetch)
        if status == 200:
            return ValidationResult(
                service="SMS Provider (Plivo)",
                status="valid",
                message="Credentials validated successfully",
            )
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="invalid",
            message=f"Unexpected status: {status}",
        )

    except HTTPError as e:
        if e.code == 401:
            return ValidationResult(
                service="SMS Provider (Plivo)",
                status="invalid",
                message="Invalid credentials (401 Unauthorized)",
            )
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="invalid",
            message=f"HTTP error: {e.code}",
        )
    except (URLError, OSError) as e:
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="invalid",
            message=f"Connection error: {e}",
        )
    except Exception as e:
        return ValidationResult(
            service="SMS Provider (Plivo)",
            status="invalid",
            message=f"Validation error: {e}",
        )


async def _test_postmark_live(config: "Config") -> ValidationResult:
    """Test Postmark server token by fetching server info."""
    if not config.postmark_server_token:
        return ValidationResult(
            service="Postmark",
            status="missing",
            message="POSTMARK_SERVER_TOKEN not set",
        )

    import asyncio
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

    try:
        url = "https://api.postmarkapp.com/server"

        def _fetch():
            req = Request(
                url,
                headers={
                    "X-Postmark-Server-Token": config.postmark_server_token,
                    "Accept": "application/json",
                    "User-Agent": "GovPal-Reach/1.0",
                },
            )
            with urlopen(req, timeout=10) as resp:
                return resp.status

        status = await asyncio.to_thread(_fetch)
        if status == 200:
            if not config.postmark_from_address:
                return ValidationResult(
                    service="Postmark",
                    status="invalid",
                    message="Token valid but POSTMARK_FROM_ADDRESS not set",
                )
            return ValidationResult(
                service="Postmark",
                status="valid",
                message="Server token validated successfully",
            )
        return ValidationResult(
            service="Postmark",
            status="invalid",
            message=f"Unexpected status: {status}",
        )

    except HTTPError as e:
        if e.code == 401:
            return ValidationResult(
                service="Postmark",
                status="invalid",
                message="Invalid server token (401 Unauthorized)",
            )
        return ValidationResult(
            service="Postmark",
            status="invalid",
            message=f"HTTP error: {e.code}",
        )
    except (URLError, OSError) as e:
        return ValidationResult(
            service="Postmark",
            status="invalid",
            message=f"Connection error: {e}",
        )
    except Exception as e:
        return ValidationResult(
            service="Postmark",
            status="invalid",
            message=f"Validation error: {e}",
        )


async def _test_google_civic_live(config: "Config") -> ValidationResult:
    """Test Google Civic API key with a real request."""
    if not config.google_civic_api_key:
        return ValidationResult(
            service="Google Civic API",
            status="missing",
            message="GOOGLE_CIVIC_API_KEY not set",
        )

    import asyncio
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    try:
        # Use elections endpoint - simple list that just needs API key
        url = f"https://www.googleapis.com/civicinfo/v2/elections?key={config.google_civic_api_key}"
        def _fetch():
            req = Request(url, headers={"User-Agent": "GovPal-Reach/1.0"})
            with urlopen(req, timeout=10) as resp:
                return resp.status

        status = await asyncio.to_thread(_fetch)
        if status == 200:
            return ValidationResult(
                service="Google Civic API",
                status="valid",
                message="API key validated successfully",
            )
        return ValidationResult(
            service="Google Civic API",
            status="invalid",
            message=f"Unexpected status: {status}",
        )

    except HTTPError as e:
        if e.code == 400:
            return ValidationResult(
                service="Google Civic API",
                status="invalid",
                message="Invalid API key (400 Bad Request)",
            )
        elif e.code == 403:
            return ValidationResult(
                service="Google Civic API",
                status="invalid",
                message="API key forbidden or quota exceeded (403)",
            )
        return ValidationResult(
            service="Google Civic API",
            status="invalid",
            message=f"HTTP error: {e.code}",
        )
    except (URLError, OSError) as e:
        return ValidationResult(
            service="Google Civic API",
            status="invalid",
            message=f"Connection error: {e}",
        )
    except Exception as e:
        return ValidationResult(
            service="Google Civic API",
            status="invalid",
            message=f"Validation error: {e}",
        )


async def _test_openstates_live(config: "Config") -> ValidationResult:
    """Test Open States API key with a real request."""
    if not config.openstates_api_key:
        return ValidationResult(
            service="Open States API",
            status="missing",
            message="OPENSTATES_API_KEY not set",
        )

    import asyncio
    from urllib.parse import urlencode
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError

    try:
        # Use DC coordinates as known test case
        params = {"lat": 38.8977, "lng": -77.0365, "apikey": config.openstates_api_key}
        url = f"https://v3.openstates.org/people.geo?{urlencode(params)}"

        def _fetch():
            req = Request(
                url,
                headers={
                    "User-Agent": "GovPal-Reach/1.0",
                    "X-API-Key": config.openstates_api_key,
                },
            )
            with urlopen(req, timeout=10) as resp:
                return resp.status

        status = await asyncio.to_thread(_fetch)
        if status == 200:
            return ValidationResult(
                service="Open States API",
                status="valid",
                message="API key validated successfully",
            )
        return ValidationResult(
            service="Open States API",
            status="invalid",
            message=f"Unexpected status: {status}",
        )

    except HTTPError as e:
        if e.code == 401:
            return ValidationResult(
                service="Open States API",
                status="invalid",
                message="Invalid API key (401 Unauthorized)",
            )
        elif e.code == 403:
            return ValidationResult(
                service="Open States API",
                status="invalid",
                message="API key forbidden (403)",
            )
        return ValidationResult(
            service="Open States API",
            status="invalid",
            message=f"HTTP error: {e.code}",
        )
    except (URLError, OSError) as e:
        return ValidationResult(
            service="Open States API",
            status="invalid",
            message=f"Connection error: {e}",
        )
    except Exception as e:
        return ValidationResult(
            service="Open States API",
            status="invalid",
            message=f"Validation error: {e}",
        )
