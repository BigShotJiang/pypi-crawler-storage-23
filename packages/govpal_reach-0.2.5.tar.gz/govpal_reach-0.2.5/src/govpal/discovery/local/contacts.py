"""Contact overrides query (LA City Council, County Supervisors). Phase 4 gr-jom.4."""

from typing import TYPE_CHECKING, Any, TypedDict

from psycopg.rows import dict_row

from govpal.db import get_connection, gpr_table

if TYPE_CHECKING:
    from govpal.config import Config


class ContactOverride(TypedDict, total=False):
    """Row shape from contact_overrides (target_type, jurisdiction, district, official_name, email, webform_url, phone, address, source)."""

    target_type: str
    jurisdiction: str | None
    district: str | None
    official_name: str | None
    email: str | None
    webform_url: str | None
    phone: str | None
    address: str | None
    source: str | None


def get_contact_overrides(
    target_type: str,
    jurisdiction: str | None = None,
    district: str | None = None,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> list[ContactOverride]:
    """
    Query contact_overrides by target_type and optional jurisdiction/district.
    Returns list of ContactOverride dicts with official_name, email, webform_url, phone, address, etc.
    """
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            conditions = ["target_type = %s"]
            params: list[Any] = [target_type]
            if jurisdiction:
                conditions.append("jurisdiction = %s")
                params.append(jurisdiction)
            if district is not None:
                conditions.append("district = %s")
                params.append(str(district))
            sql = f"""
                SELECT target_type, jurisdiction, district, official_name,
                       email, webform_url, phone, address, source
                FROM {gpr_table("contact_overrides")}
                WHERE {" AND ".join(conditions)}
                ORDER BY district NULLS LAST
            """
            cur.execute(sql, params)
            rows = cur.fetchall()
    return list(rows)
