"""Region → source mapping. (Phase 4: LA Local.)"""

from typing import TypedDict

# LA GeoHub Boundaries MapServer (Council Districts=13, NC Certified=18, Board of Supervisors=4)
LA_GEOHUB_BOUNDARIES = (
    "https://maps.lacity.org/lahub/rest/services/Boundaries/MapServer"
)
# LA County GIS (supervisors) – alternative; GeoHub layer 4 is "Board of Supervisors" (LA City view)
LA_COUNTY_SUPERVISORS = "https://public.gis.lacounty.gov/public/rest/services/LACounty_Dynamic/Political_Boundaries/MapServer/33"

# Layer IDs on LA GeoHub Boundaries MapServer
LA_GEOHUB_LAYER_COUNCIL = 13  # Council Districts
LA_GEOHUB_LAYER_SUPERVISORS = 4  # Board of Supervisors (LA view)
LA_GEOHUB_LAYER_NC = 18  # Neighborhood Councils (Certified)


class RegionLayerConfig(TypedDict):
    """Per-layer config: endpoint, layer_id, target_type, name_field."""

    endpoint: str
    layer_id: int
    target_type: str
    name_field: str


class RegionConfig(TypedDict):
    """Region config: city, county, neighborhood layer configs."""

    city: RegionLayerConfig
    county: RegionLayerConfig
    neighborhood: RegionLayerConfig


# Region config: region name -> city/county/neighborhood layer configs
_REGION_CONFIG: dict[str, RegionConfig] = {
    "Los Angeles": {
        "city": {
            "endpoint": f"{LA_GEOHUB_BOUNDARIES}/{LA_GEOHUB_LAYER_COUNCIL}",
            "layer_id": LA_GEOHUB_LAYER_COUNCIL,
            "target_type": "city",
            "name_field": "DISTRICT",  # may vary; discover from first feature
        },
        "county": {
            "endpoint": f"{LA_GEOHUB_BOUNDARIES}/{LA_GEOHUB_LAYER_SUPERVISORS}",
            "layer_id": LA_GEOHUB_LAYER_SUPERVISORS,
            "target_type": "county",
            "name_field": "DISTRICT",
        },
        "neighborhood": {
            "endpoint": f"{LA_GEOHUB_BOUNDARIES}/{LA_GEOHUB_LAYER_NC}",
            "layer_id": LA_GEOHUB_LAYER_NC,
            "target_type": "neighborhood",
            "name_field": "NAME",  # LA GeoHub NC layer uses NAME (e.g. "VENICE NC")
        },
    },
}


def get_region_config(region: str) -> RegionConfig | None:
    """
    Return source config for a region (city, county, neighborhood sources).

    Args:
        region: Region name (e.g. "Los Angeles").

    Returns:
        RegionConfig with keys "city", "county", "neighborhood", each holding endpoint/layer_id/name_field.
        None if region is unknown.
    """
    return _REGION_CONFIG.get(region)


def get_supported_regions() -> list[str]:
    """Return list of supported region names."""
    return list(_REGION_CONFIG.keys())
