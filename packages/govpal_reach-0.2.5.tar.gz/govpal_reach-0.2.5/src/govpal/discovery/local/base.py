"""ABC: RegionalSource (point-in-polygon + contacts). (Phase 4: LA Local.)"""

from abc import ABC, abstractmethod
from typing import Any


class RegionalSource(ABC):
    """
    Abstract regional data source: point-in-polygon lookup and optional contact resolution.
    Implementations: LA (GeoHub city/county, EmpowerLA NC).
    """

    @abstractmethod
    def lookup(self, lat: float, lng: float) -> dict[str, Any]:
        """
        Look up regional districts for a (lat, lng) point.

        Args:
            lat: Latitude (WGS84).
            lng: Longitude (WGS84).

        Returns:
            Dict with keys such as: city_district, county_district, neighborhood (NC name/id).
            Missing or unknown values are omitted or None.
        """
        pass
