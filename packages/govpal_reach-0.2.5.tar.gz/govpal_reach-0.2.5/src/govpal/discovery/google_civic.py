"""Google Civic API – RepProvider impl."""

import os
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from govpal.discovery.interfaces import Rep, RepProvider
from govpal.discovery.utils import parse_json

GOOGLE_CIVIC_BASE = "https://www.googleapis.com/civicinfo/v2/representatives"


class GoogleCivicProvider(RepProvider):
    """Google Civic Information API – reps by address."""

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.environ.get("GOOGLE_CIVIC_API_KEY", "")

    def get_reps_by_address(self, address: str) -> list[Rep]:
        if not self.api_key or not address or not address.strip():
            return []
        params = {"address": address.strip(), "key": self.api_key}
        url = f"{GOOGLE_CIVIC_BASE}?{urlencode(params)}"
        try:
            req = Request(url, headers={"User-Agent": "GovPal-Reach/1.0"})
            with urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    return []
                data = parse_json(resp.read())
        except (HTTPError, URLError, OSError, ValueError):
            return []
        return _normalize_response(data)

    def get_reps_by_coords(self, lat: float, lng: float) -> list[Rep]:
        # Google Civic requires address; coords lookup not supported
        return []


def _normalize_response(data: dict) -> list[Rep]:
    """Map Google Civic offices + officials to Rep list."""
    offices = data.get("offices", [])
    officials = data.get("officials", [])
    if not offices or not officials:
        return []
    reps: list[Rep] = []
    for office in offices:
        office_name = office.get("name", "")
        levels = office.get("levels", [])
        level = _best_level(levels)
        division_id = office.get("divisionId", "")
        district = _district_from_division(division_id)
        for idx in office.get("officialIndices", []):
            if idx >= len(officials):
                continue
            off = officials[idx]
            rep = {
                "level": level,
                "office": office_name,
                "name": off.get("name", ""),
                "party": off.get("party"),
                "district": district,
                "jurisdiction": division_id,
                "contact_email": (off.get("emails") or [None])[0],
                "contact_form_url": (off.get("urls") or [None])[0],
                "contact_phone": (off.get("phones") or [None])[0],
                "photo_url": off.get("photoUrl"),
                "data_source": "google_civic",
            }
            reps.append(rep)
    return reps


_LEVEL_PRIORITY = ["country", "administrativeArea1", "administrativeArea2", "locality"]


def _best_level(levels: list[str]) -> str:
    """Pick the highest-priority level when Google Civic returns multiple."""
    if not levels:
        return "unknown"
    for candidate in _LEVEL_PRIORITY:
        if candidate in levels:
            return _level_from_ocd(candidate)
    return _level_from_ocd(levels[0])


def _level_from_ocd(ocd_level: str) -> str:
    m = {
        "country": "federal",
        "administrativeArea1": "state",
        "administrativeArea2": "county",
        "locality": "city",
    }
    return m.get(ocd_level, ocd_level)


def _district_from_division(division_id: str) -> str:
    # e.g. ocd-division/country:us/state:ca/cd:14 -> CA-14
    if "/cd:" in division_id:
        parts = division_id.split("/cd:")[-1].split("/")
        cd = parts[0] if parts else ""
        state = ""
        for p in division_id.split("/"):
            if p.startswith("state:"):
                state = p.split(":")[-1].upper()
                break
        return f"{state}-{cd}" if state and cd else division_id
    return ""
