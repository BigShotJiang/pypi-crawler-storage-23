"""Open States API – RepProvider impl (state legislators by lat/lng)."""

import os
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from govpal.discovery.interfaces import Rep, RepProvider
from govpal.discovery.utils import parse_json

OPEN_STATES_BASE = "https://v3.openstates.org/people.geo"


class OpenStatesProvider(RepProvider):
    """Open States API v3 – state legislators by lat/lng."""

    def __init__(self, api_key: str | None = None) -> None:
        self.api_key = api_key or os.environ.get("OPENSTATES_API_KEY", "")

    def get_reps_by_address(self, address: str) -> list[Rep]:
        # Open States requires lat/lng; address lookup not supported
        return []

    def get_reps_by_coords(self, lat: float, lng: float) -> list[Rep]:
        if not self.api_key:
            return []
        params = {"lat": lat, "lng": lng, "apikey": self.api_key}
        url = f"{OPEN_STATES_BASE}?{urlencode(params)}"
        try:
            req = Request(
                url,
                headers={"User-Agent": "GovPal-Reach/1.0", "X-API-Key": self.api_key},
            )
            with urlopen(req, timeout=10) as resp:
                if resp.status != 200:
                    return []
                data = parse_json(resp.read())
        except (HTTPError, URLError, OSError, ValueError):
            return []
        return _normalize_response(data)


def _level_from_role(role: dict) -> str:
    """Derive rep level from Open States role metadata."""
    div_id = role.get("division_id", "")

    if "/cd:" in div_id:
        return "federal"
    if "/sldu:" in div_id or "/sldl:" in div_id:
        return "state"

    jurisdiction = role.get("jurisdiction") or {}
    classification = jurisdiction.get("classification", "")
    if classification == "government":
        return "federal"
    if classification == "county":
        return "county"
    if classification == "municipality":
        return "city"

    # ocd-division/country:us/state:XX with no district subdivision = US Senator
    if div_id and "/state:" in div_id and div_id.count("/") <= 3:
        return "federal"

    return "state"


def _normalize_response(data: dict) -> list[Rep]:
    """Map Open States Person results to Rep list."""
    results = data.get("results", [])
    if not results:
        return []
    reps: list[Rep] = []
    for p in results:
        role = p.get("current_role") or {}
        level = _level_from_role(role)
        district = ""
        if isinstance(role.get("district"), (int, str)):
            district = str(role.get("district", ""))
        div_id = role.get("division_id", "")
        if div_id and "/cd:" in div_id:
            parts = div_id.split("/cd:")[-1].split("/")
            cd = parts[0] if parts else ""
            state = ""
            for part in div_id.split("/"):
                if part.startswith("state:"):
                    state = part.split(":")[-1].upper()
                    break
            district = f"{state}-{cd}" if state and cd else district
        elif div_id and not district:
            # Extract district from sldu:14 or sldl:42
            last = div_id.split("/")[-1]
            if ":" in last:
                district = last.split(":")[-1]
            else:
                district = last
        contact_url = None
        for link in p.get("links") or []:
            if isinstance(link, dict) and link.get("url"):
                contact_url = link.get("url")
                break
        rep: Rep = {
            "level": level,
            "office": role.get("title", ""),
            "name": p.get("name", ""),
            "party": p.get("party"),
            "district": district,
            "jurisdiction": div_id,
            "contact_email": p.get("email"),
            "contact_form_url": contact_url,
            "contact_phone": None,  # Open States Person may have in offices
            "photo_url": p.get("image"),
            "data_source": "open_states",
        }
        # Check offices for phone
        for off in p.get("offices") or []:
            if isinstance(off, dict) and off.get("voice"):
                rep["contact_phone"] = off.get("voice")
                break
        reps.append(rep)
    return reps
