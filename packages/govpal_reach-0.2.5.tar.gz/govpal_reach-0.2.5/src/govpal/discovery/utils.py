"""Shared discovery utilities."""

import json


def parse_json(raw: bytes) -> dict:
    """Decode UTF-8 bytes and parse as JSON. Returns dict."""
    return json.loads(raw.decode("utf-8"))
