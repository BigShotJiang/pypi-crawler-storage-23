"""Discovery – representative lookup (pluggable RepProvider, GeocodingProvider)."""
