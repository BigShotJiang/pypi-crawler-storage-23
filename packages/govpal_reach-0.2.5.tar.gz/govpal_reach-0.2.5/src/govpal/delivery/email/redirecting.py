"""RedirectingEmailProvider: rewrites recipients to safe test addresses for dev/staging."""

from typing import TypedDict

from govpal.delivery.email.interfaces import EmailProvider


class RedirectRecord(TypedDict, total=False):
    """Record of a redirect: original recipient -> test address."""

    original_to: str
    redirected_to: str
    ok: bool


class RedirectingEmailProvider(EmailProvider):
    """
    Wraps a real EmailProvider; rewrites all recipients to safe test addresses.

    Use for dev, staging, and integration tests: real emails are sent, but only
    to GP_TEST_RECIPIENTS. Original recipient is preserved in the subject as
    [TO: original@rep.gov] for verification.
    """

    def __init__(self, inner: EmailProvider, test_recipients: list[str]) -> None:
        self.inner = inner
        self.test_recipients = test_recipients if test_recipients else []
        self.redirected: list[RedirectRecord] = []

    def send(
        self,
        to: str,
        subject: str,
        body: str,
        *,
        from_name: str | None = None,
        reply_to: str | None = None,
    ) -> bool:
        tagged_subject = f"[TO: {to}] {subject}"
        if not self.test_recipients:
            self.redirected.append(
                {"original_to": to, "redirected_to": "", "ok": False}
            )
            return False
        results: list[bool] = []
        for test_addr in self.test_recipients:
            ok = self.inner.send(
                test_addr,
                tagged_subject,
                body,
                from_name=from_name,
                reply_to=reply_to,
            )
            results.append(ok)
            self.redirected.append(
                {"original_to": to, "redirected_to": test_addr, "ok": ok}
            )
        return all(results)
