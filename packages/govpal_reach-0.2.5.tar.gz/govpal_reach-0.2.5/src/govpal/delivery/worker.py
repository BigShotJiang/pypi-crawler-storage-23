"""
GovPal delivery worker – PGQueuer consumer for delivery jobs.

Run: pgq run govpal.delivery.worker:create_pgqueuer --max-concurrent-tasks 2
"""

import inspect
import json
import logging
import os
from datetime import timedelta
from typing import Any

_log = logging.getLogger(__name__)

# Lazy imports for pgqueuer (optional at import time)
try:
    import psycopg
    from pgqueuer import PgQueuer
    from pgqueuer.db import PsycopgDriver
    from pgqueuer.errors import MaxRetriesExceeded
    from pgqueuer.executors import RetryWithBackoffEntrypointExecutor
    from pgqueuer.models import Context, Job

    _PGQUEUER_AVAILABLE = True
except ImportError:
    _PGQUEUER_AVAILABLE = False

from govpal.db import get_connection, gpr_table
from govpal.delivery.interfaces import MessageContent, Rep, UserProfile
from govpal.delivery.queue import QUEUE_ENTRYPOINT
from govpal.delivery.rate_limiter import process_delivery_job
from govpal.delivery.composite import CompositeDeliveryProvider
from govpal.delivery.rate_limiter import SimpleRateLimiter
from govpal.identity.repository import get_profile


DELIVERY_ENTRYPOINT = QUEUE_ENTRYPOINT  # "delivery"


def _default_send_to_dead_letter(job: "Job", reason: str) -> None:
    """Default: log only. Overridden when DLQ table is available via insert_dead_letter_job."""
    _log.warning(
        "Delivery job %s exhausted retries: %s. Payload: %s",
        job.id,
        reason,
        job.payload,
    )


async def _default_send_to_dead_letter_async(job: "Job", reason: str) -> None:
    """Async default for resources; just calls sync version."""
    _default_send_to_dead_letter(job, reason)


def insert_dead_letter_job(dsn: str, job: "Job", reason: str) -> None:
    """
    Insert a failed delivery job into gpr_dead_letter_jobs (Option B DLQ).

    Call this when RetryWithBackoff raises MaxRetriesExceeded. Payload is stored as JSONB;
    message_id, representative_id, delivery_method are extracted for indexing.
    """
    payload_bytes = job.payload or b"{}"
    try:
        payload_obj = json.loads(payload_bytes.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        payload_obj = {}
    message_id = payload_obj.get("message_id")
    representative_id = payload_obj.get("representative_id")
    delivery_method = payload_obj.get("delivery_method", "")

    table = gpr_table("dead_letter_jobs")
    with get_connection(dsn) as conn:
        with conn.cursor() as cur:
            cur.execute(
                f"""
                INSERT INTO {table}
                (original_job_id, payload, reason, message_id, representative_id, delivery_method)
                VALUES (%s, %s::jsonb, %s, %s::uuid, %s::uuid, %s)
                """,
                (
                    job.id,
                    json.dumps(payload_obj),
                    reason,
                    message_id or None,
                    representative_id or None,
                    delivery_method or None,
                ),
            )
        conn.commit()
    _log.info(
        "Inserted dead letter job original_job_id=%s message_id=%s", job.id, message_id
    )


class GovPalDeliveryExecutor(RetryWithBackoffEntrypointExecutor):
    """
    Delivery executor with retry and dead-letter on final failure.

    On MaxRetriesExceeded, calls context.resources["send_to_dead_letter"](job, reason) if present.
    """

    async def execute(self, job: "Job", context: "Context") -> None:
        try:
            await super().execute(job, context)
        except MaxRetriesExceeded as e:
            send_to_dlq = context.resources.get("send_to_dead_letter")
            if callable(send_to_dlq):
                if inspect.iscoroutinefunction(send_to_dlq):
                    await send_to_dlq(job, str(e))
                else:
                    send_to_dlq(job, str(e))
            raise


def _load_message(conn: Any, message_id: str) -> dict[str, Any] | None:
    """Load gpr_messages row by id. Returns dict with subject, body, user_id, representative_id, delivery_method, status."""
    table = gpr_table("messages")
    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT id, user_id, representative_id, delivery_method, status, subject, body
            FROM {table}
            WHERE id = %s
            """,
            (message_id,),
        )
        row = cur.fetchone()
    if not row:
        return None
    return {
        "id": row[0],
        "user_id": row[1],
        "representative_id": row[2],
        "delivery_method": row[3],
        "status": row[4],
        "subject": row[5] or "",
        "body": row[6] or "",
    }


def _load_rep(conn: Any, representative_id: str) -> Rep | None:
    """Load gpr_representatives row as Rep dict."""
    table = gpr_table("representatives")
    with conn.cursor() as cur:
        cur.execute(
            f"""
            SELECT id, level, office, name, party, district, jurisdiction,
                   contact_email, contact_form_url, contact_phone, photo_url,
                   data_source, honorific
            FROM {table}
            WHERE id = %s
            """,
            (representative_id,),
        )
        row = cur.fetchone()
    if not row:
        return None
    return {
        "level": row[1] or "",
        "office": row[2],
        "name": row[3] or "",
        "party": row[4],
        "district": row[5] or "",
        "jurisdiction": row[6] or "",
        "contact_email": row[7],
        "contact_form_url": row[8],
        "contact_phone": row[9],
        "photo_url": row[10],
        "data_source": row[11] or "",
        "honorific": row[12],
    }


def _user_profile_to_delivery_dict(profile: Any) -> UserProfile:
    """Convert identity UserProfile to delivery UserProfile dict."""
    address = getattr(profile, "full_address_for_display", None)
    if callable(address):
        address = address()
    elif not address:
        address = profile.address or ""
    return {
        "first_name": profile.first_name or "",
        "last_name": profile.last_name or "",
        "email": profile.email or "",
        "address": address,
        "phone": getattr(profile, "phone", None) or "",
    }


def _handle_delivery_job(
    job: "Job",
    pgq: "PgQueuer",
) -> None:
    """
    Sync job handler: decode payload, load message/rep/user from DB,
    call process_delivery_job, update gpr_messages status/sent_at or error_message.
    """
    resources = pgq.resources
    dsn = resources.get("dsn") or os.environ.get("DATABASE_URL")
    if not dsn:
        raise ValueError("dsn or DATABASE_URL required for delivery worker")

    payload_bytes = job.payload
    if not payload_bytes:
        raise ValueError("Delivery job has no payload")
    payload = json.loads(payload_bytes.decode("utf-8"))
    message_id = str(payload.get("message_id", ""))
    representative_id = str(payload.get("representative_id", ""))
    delivery_method = str(payload.get("delivery_method", "email"))

    if not message_id or not representative_id:
        raise ValueError("Payload must contain message_id and representative_id")

    with get_connection(dsn) as conn:
        msg_row = _load_message(conn, message_id)
        if not msg_row:
            raise ValueError(f"Message not found: {message_id}")
        rep = _load_rep(conn, representative_id)
        if not rep:
            raise ValueError(f"Representative not found: {representative_id}")

        from uuid import UUID as _UUID

        uid = msg_row["user_id"]
        profile = get_profile(
            uid if isinstance(uid, _UUID) else _UUID(str(uid)), dsn=dsn
        )
        if not profile:
            raise ValueError(
                f"User profile not found for user_id: {msg_row['user_id']}"
            )

        message_content: MessageContent = {
            "subject": msg_row["subject"] or "",
            "body": msg_row["body"] or "",
        }
        user_profile = _user_profile_to_delivery_dict(profile)
        delivery_provider = (
            resources.get("delivery_provider") or CompositeDeliveryProvider()
        )
        rate_limiter = resources.get("rate_limiter")

        ok = process_delivery_job(
            payload={
                "message_id": message_id,
                "representative_id": representative_id,
                "delivery_method": delivery_method,
            },
            message=message_content,
            rep=rep,
            user_profile=user_profile,
            delivery_provider=delivery_provider,
            rate_limiter=rate_limiter,
        )

        table = gpr_table("messages")
        with conn.cursor() as cur:
            if ok:
                cur.execute(
                    f"UPDATE {table} SET status = 'sent', sent_at = NOW() WHERE id = %s",
                    (message_id,),
                )
            else:
                cur.execute(
                    f"UPDATE {table} SET status = 'failed', error_message = %s WHERE id = %s",
                    ("Delivery failed", message_id),
                )
        conn.commit()


async def create_pgqueuer() -> "PgQueuer":
    """
    Factory for GovPal delivery worker (PGQueuer instance).

    Connects to DB via DATABASE_URL, registers entrypoint "delivery" with
    RetryWithBackoffEntrypointExecutor (max_attempts=2, max_delay=5s).
    Run: pgq run govpal.delivery.worker:create_pgqueuer --max-concurrent-tasks 2
    """
    if not _PGQUEUER_AVAILABLE:
        raise RuntimeError("pgqueuer is not installed; install with: uv add pgqueuer")

    dsn = os.environ.get("DATABASE_URL", "")
    if not dsn.strip():
        raise ValueError("DATABASE_URL must be set to run GovPal delivery worker")

    conn = await psycopg.AsyncConnection.connect(dsn, autocommit=True)
    driver = PsycopgDriver(conn)

    delivery_provider = CompositeDeliveryProvider()
    rate_limiter = SimpleRateLimiter(interval_seconds=4.0)

    async def send_to_dead_letter_insert(job: Job, reason: str) -> None:
        """Insert failed job into gpr_dead_letter_jobs (runs sync insert in thread)."""
        import anyio.to_thread

        await anyio.to_thread.run_sync(insert_dead_letter_job, dsn, job, reason)

    resources: dict[str, Any] = {
        "dsn": dsn,
        "delivery_provider": delivery_provider,
        "rate_limiter": rate_limiter,
        "send_to_dead_letter": send_to_dead_letter_insert,
    }

    pgq = PgQueuer(driver, resources=resources)

    def executor_factory(params: Any) -> GovPalDeliveryExecutor:
        return GovPalDeliveryExecutor(
            parameters=params,
            max_attempts=2,
            max_delay=timedelta(seconds=5),
        )

    def handle_delivery(job: Job) -> None:
        _handle_delivery_job(job, pgq)

    pgq.entrypoint(
        DELIVERY_ENTRYPOINT,
        executor_factory=executor_factory,
    )(handle_delivery)

    return pgq
