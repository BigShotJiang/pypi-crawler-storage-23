"""Rate limiter and queue worker."""

import logging
import time
from typing import Any, Callable, Protocol

_log = logging.getLogger(__name__)

from govpal.delivery.interfaces import (
    DeliveryProvider,
    MessageContent,
    Rep,
    UserProfile,
)


class RateLimiter(Protocol):
    """Protocol for rate limiting – wait between operations."""

    def wait(self) -> None:
        """Block for the configured interval (e.g. 3–5 s between submissions)."""
        ...


class SimpleRateLimiter:
    """Rate limiter using time.sleep."""

    def __init__(
        self,
        interval_seconds: float = 4.0,
        sleep_fn: Callable[[float], None] | None = None,
    ) -> None:
        self.interval_seconds = interval_seconds
        self._sleep = sleep_fn or time.sleep

    def wait(self) -> None:
        self._sleep(self.interval_seconds)


def process_delivery_job(
    payload: dict[str, Any],
    message: MessageContent,
    rep: Rep,
    user_profile: UserProfile,
    delivery_provider: DeliveryProvider,
    rate_limiter: RateLimiter | None = None,
) -> bool:
    """
    Process one delivery job.

    Args:
        payload: Dict with message_id, representative_id, delivery_method.
        message: Message content (subject, body).
        rep: Representative (contact_email, contact_form_url).
        user_profile: User (first_name, last_name, email).
        delivery_provider: Provider for email or webform.
        rate_limiter: Optional; called before processing.

    Returns:
        True if delivery succeeded, False otherwise.
    """
    if rate_limiter:
        rate_limiter.wait()
    method = payload.get("delivery_method", "email")
    try:
        return delivery_provider.deliver(
            message=message,
            rep=rep,
            user_profile=user_profile,
            delivery_method=method,
        )
    except Exception as e:
        _log.warning("Delivery failed: %s", e)
        return False
