"""ABC: DeliveryProvider (email, webform)."""

from abc import ABC, abstractmethod
from typing import TypedDict

from govpal.discovery.interfaces import Rep


class UserProfileShape(TypedDict, total=False):
    """Shape expected by DeliveryProvider.deliver for user_profile. first_name, last_name, email required for email delivery."""

    first_name: str
    last_name: str
    email: str
    phone: str | None
    address: str | None


class MessageContentShape(TypedDict, total=False):
    """Shape expected by DeliveryProvider.deliver for message. subject and body required."""

    subject: str
    body: str


# Type aliases; deliver() accepts dicts conforming to these shapes.
UserProfile = UserProfileShape
MessageContent = MessageContentShape

__all__ = [
    "DeliveryProvider",
    "MessageContent",
    "MessageContentShape",
    "Rep",
    "UserProfile",
    "UserProfileShape",
]


class DeliveryProvider(ABC):
    """Abstract delivery provider. Implementations: Postmark (email), Playwright (webform)."""

    @abstractmethod
    def deliver(
        self,
        message: MessageContent,
        rep: Rep,
        user_profile: UserProfile,
        delivery_method: str,
    ) -> bool:
        """
        Deliver a message to a representative.

        Args:
            message: Dict with 'subject', 'body', and optional fields.
            rep: Representative dict with contact_email, contact_form_url, etc.
            user_profile: User dict with first_name, last_name, email, etc.
            delivery_method: 'email' or 'webform'.

        Returns:
            True if delivery succeeded or was accepted, False otherwise.
        """
        pass
