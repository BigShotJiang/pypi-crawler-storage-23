"""Identity tokens (Fernet-encrypted, TTL) for returning-user session resume."""

import json
from typing import TYPE_CHECKING

from cryptography.fernet import Fernet, InvalidToken

from govpal.identity.pii import _get_key

if TYPE_CHECKING:
    from govpal.config import Config

IDENTITY_TOKEN_TTL = 180 * 24 * 3600  # 180 days in seconds


def generate_identity_token(
    user_id: str,
    phone: str,
    *,
    config: "Config | None" = None,
) -> str:
    """Produce a Fernet-encrypted token containing user_id and phone. No TTL in payload; TTL is enforced on decrypt."""
    key = _get_key(config)
    f = Fernet(key)
    payload = json.dumps({"user_id": user_id, "phone": phone}).encode("utf-8")
    return f.encrypt(payload).decode("utf-8")


def validate_identity_token(
    token: str,
    *,
    config: "Config | None" = None,
) -> dict | None:
    """Decrypt token and validate TTL. Returns dict with user_id and phone, or None if invalid/expired."""
    key = _get_key(config)
    f = Fernet(key)
    try:
        payload = f.decrypt(token.encode("utf-8"), ttl=IDENTITY_TOKEN_TTL)
        return json.loads(payload)
    except (InvalidToken, json.JSONDecodeError):
        return None
