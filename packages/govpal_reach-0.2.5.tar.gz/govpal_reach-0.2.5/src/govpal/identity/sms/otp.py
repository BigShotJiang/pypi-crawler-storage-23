"""OTP flow via Twilio/Plivo Verify (no local OTP storage)."""

from typing import Optional

from govpal.identity import repository
from govpal.identity.sms.interfaces import SMSProvider
from govpal.identity.sms.provider import get_sms_provider


def request_otp(
    phone: str,
    *,
    provider: Optional[SMSProvider] = None,
    channel: str = "sms",
    dsn: Optional[str] = None,
) -> tuple[bool, Optional[str]]:
    """
    Send OTP to phone via provider Verify API. Creates or gets user, stores session_id.
    Returns (success, error_message). On success, user must then call verify_otp(phone, code).
    """
    prov = provider or get_sms_provider()
    if prov is None:
        raise ValueError(
            "No SMS provider configured; set TWILIO_* or PLIVO_* and optionally SMS_PROVIDER"
        )
    ok, session_id, err_detail = prov.verify_send(phone, channel=channel)
    if not ok:
        return False, err_detail or "Failed to send verification code"
    if not session_id:
        return False, err_detail or "No session returned from provider"
    user = repository.get_or_create_user(phone, dsn=dsn)
    repository.update_verify_session_uuid(user.id, session_id, dsn=dsn)
    return True, None


def verify_otp(
    phone: str,
    code: str,
    *,
    provider: Optional[SMSProvider] = None,
    dsn: Optional[str] = None,
) -> tuple[bool, Optional[str]]:
    """
    Verify OTP code for phone. On success, sets users.phone_verified = True and clears session.
    Returns (success, error_message).
    """
    prov = provider or get_sms_provider()
    if prov is None:
        raise ValueError(
            "No SMS provider configured; set TWILIO_* or PLIVO_* and optionally SMS_PROVIDER"
        )
    user = repository.get_user_by_phone(phone, dsn=dsn)
    if not user:
        return False, "User not found"
    session_id = user.verify_session_uuid
    if not session_id:
        return False, "No verification session; request OTP first"
    if not prov.verify_validate(session_id, code):
        return False, "Invalid or expired code"
    repository.update_phone_verified(user.id, True, dsn=dsn)
    return True, None
