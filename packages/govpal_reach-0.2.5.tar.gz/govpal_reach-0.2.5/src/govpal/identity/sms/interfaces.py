"""ABC: SMSProvider. Implementations: Twilio (primary), Plivo (alternative)."""

from abc import ABC, abstractmethod
from typing import Optional


class SMSProvider(ABC):
    """Abstract SMS/OTP provider. Implementations: Twilio (primary), Plivo (alternative)."""

    @abstractmethod
    def send(self, to: str, message: str) -> bool:
        """
        Send an SMS to the given number.

        Args:
            to: E.164 phone number (e.g. '+14155551234').
            message: Plain text body (no encoding requirement beyond provider limits).

        Returns:
            True if the provider accepted the message for delivery, False otherwise.
        """
        pass

    @abstractmethod
    def verify_send(
        self, recipient: str, channel: str = "sms"
    ) -> tuple[bool, Optional[str], Optional[str]]:
        """
        Send OTP to recipient via provider's Verify API.
        Returns (success, session_id_or_none, error_message_or_none).
        session_id is stored and passed to verify_validate.
        On failure, error_message should describe the cause (e.g. exception or API error).
        """
        pass

    @abstractmethod
    def verify_validate(self, session_id: str, otp: str) -> bool:
        """
        Validate OTP code for the given session. Returns True if the code is valid.
        """
        pass
