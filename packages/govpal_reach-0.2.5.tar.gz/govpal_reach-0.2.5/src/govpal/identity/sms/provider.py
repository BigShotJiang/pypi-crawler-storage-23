"""SMS provider selection: Twilio (primary) or Plivo from env and SMS_PROVIDER."""

import os
from typing import TYPE_CHECKING, Optional

from govpal.identity.sms.interfaces import SMSProvider
from govpal.identity.sms.plivo import PlivoProvider
from govpal.identity.sms.twilio import TwilioProvider

if TYPE_CHECKING:
    from govpal.config import Config


def _has_twilio_creds(config: "Config | None" = None) -> bool:
    """Twilio is configured for Verify (and optionally SMS) with Account SID, Auth Token, Verify Service SID. Phone number is optional (required only for generic send())."""
    if config:
        return bool(
            config.twilio_account_sid
            and config.twilio_auth_token
            and config.twilio_verify_service_sid
        )
    return bool(
        os.environ.get("TWILIO_ACCOUNT_SID")
        and os.environ.get("TWILIO_AUTH_TOKEN")
        and os.environ.get("TWILIO_VERIFY_SERVICE_SID")
    )


def _has_plivo_creds(config: "Config | None" = None) -> bool:
    if config:
        return bool(
            config.plivo_auth_id
            and config.plivo_auth_token
            and config.plivo_src_number
            and config.plivo_verify_app_uuid
        )
    return bool(
        os.environ.get("PLIVO_AUTH_ID")
        and os.environ.get("PLIVO_AUTH_TOKEN")
        and os.environ.get("PLIVO_SRC_NUMBER")
        and os.environ.get("PLIVO_VERIFY_APP_UUID")
    )


def _twilio_from_config(config: "Config | None" = None) -> TwilioProvider:
    """Build TwilioProvider from config or env."""
    if config:
        return TwilioProvider(
            account_sid=config.twilio_account_sid or None,
            auth_token=config.twilio_auth_token or None,
            phone_number=config.twilio_phone_number or None,
            verify_service_sid=config.twilio_verify_service_sid or None,
        )
    return TwilioProvider()


def _plivo_from_config(config: "Config | None" = None) -> PlivoProvider:
    """Build PlivoProvider from config or env."""
    if config:
        return PlivoProvider(
            auth_id=config.plivo_auth_id or None,
            auth_token=config.plivo_auth_token or None,
            src_number=config.plivo_src_number or None,
            verify_app_uuid=config.plivo_verify_app_uuid or None,
        )
    return PlivoProvider()


def get_sms_provider(config: "Config | None" = None) -> Optional[SMSProvider]:
    """
    Return the SMS/OTP provider from config or env: SMS_PROVIDER (twilio|plivo) or credential fallback.
    If both Twilio and Plivo credentials are set and SMS_PROVIDER is unset, defaults to Twilio.
    When config is provided, uses config for SMS_PROVIDER and credential checks; otherwise uses os.environ.
    Returns None if no credentials are present.
    """
    if config:
        switch = (config.sms_provider or "").strip().lower()
    else:
        switch = (os.environ.get("SMS_PROVIDER") or "").strip().lower()
    has_twilio = _has_twilio_creds(config)
    has_plivo = _has_plivo_creds(config)

    if switch == "twilio" and has_twilio:
        return _twilio_from_config(config)
    if switch == "plivo" and has_plivo:
        return _plivo_from_config(config)
    if has_twilio and not has_plivo:
        return _twilio_from_config(config)
    if has_plivo and not has_twilio:
        return _plivo_from_config(config)
    if has_twilio and has_plivo:
        return _twilio_from_config(config)
    return None
