"""Parse/normalize US addresses via usaddress-scourgify; optional ZIP+4 lookup."""

import os
import re
from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from govpal.config import Config


class AddressComponents(TypedDict, total=False):
    """Address components for ZIP+4 lookup. street_address_2 is optional."""

    street_address_1: str | None
    street_address_2: str | None
    city: str | None
    state: str | None
    zip_code: str | None


def parse_address(raw: str) -> AddressComponents | None:
    """
    Parse and normalize a US address string using usaddress-scourgify.

    Follows USPS pub 28 and RESO guidelines. Returns a dict with separate
    address fields suitable for storage and validation:
    street_address_1, street_address_2, city, state, zip_code.
    Street and city are title-cased; state and zip_code are as returned by scourgify (abbreviated).
    Returns None if the address cannot be parsed or validated (e.g. invalid
    postal code).

    See: https://github.com/GreenBuildingRegistry/usaddress-scourgify
    Scourgify returns uppercase; we apply title case to street and city before returning.
    """
    s = (raw or "").strip()
    if not s:
        return None
    try:
        from scourgify import normalize_address_record
        from scourgify.exceptions import (
            AddressNormalizationError,
            AmbiguousAddressError,
            UnParseableAddressError,
        )
    except ImportError:
        return None
    try:
        rec = normalize_address_record(s)
    except (
        AddressNormalizationError,
        AmbiguousAddressError,
        UnParseableAddressError,
        ValueError,
    ):
        return None
    if not rec:
        return None
    return {
        "street_address_1": _address_title_case(rec.get("address_line_1")),
        "street_address_2": _address_title_case(rec.get("address_line_2")),
        "city": _address_title_case(rec.get("city")),
        "state": rec.get("state") or None,
        "zip_code": rec.get("postal_code") or None,
    }


def _address_title_case(s: str | None) -> str | None:
    """Convert address/city string to title case for display and storage. Scourgify returns uppercase."""
    if not s or not s.strip():
        return None
    return s.strip().title()


def _parse_city_state_zip(tail: str) -> tuple[str | None, str | None, str | None]:
    """Parse 'City' or 'City, ST 12345' or 'ST 12345' into (city, state, zip_code)."""
    tail = (tail or "").strip()
    if not tail:
        return None, None, None
    match = re.search(r",?\s*([A-Za-z]{2})\s+(\d{5}(?:-\d{4})?)\s*$", tail)
    if match:
        state = match.group(1).upper()
        zip_code = match.group(2)
        city_part = tail[: match.start()].strip().rstrip(",").strip()
        city = city_part or None
        return city, state, zip_code
    match2 = re.match(r"([A-Za-z]{2})\s+(\d{5}(?:-\d{4})?)\s*$", tail)
    if match2:
        return None, match2.group(1).upper(), match2.group(2)
    if re.match(r"^\d{5}", tail):
        zip_code = tail[:5] if len(tail) >= 5 else tail
        return None, None, zip_code
    return tail or None, None, None


def _get_zip_validation_api_key(
    api_key: str | None = None,
    config: "Config | None" = None,
) -> str:
    """Return Google Address Validation API key from arg, config, or env."""
    if api_key is not None and (api_key or "").strip():
        return api_key.strip()
    if config:
        v = (
            config.google_address_validation_api_key
            or config.google_civic_api_key
            or ""
        ).strip()
        if v:
            return v
    return (
        os.environ.get("GOOGLE_ADDRESS_VALIDATION_API_KEY")
        or os.environ.get("GOOGLE_CIVIC_API_KEY")
        or ""
    ).strip()


def enhance_and_validate_zip_plus_four(
    street_address_1: str | None,
    city: str | None,
    state: str | None,
    zip_code: str | None,
    street_address_2: str | None = None,
    api_key: str | None = None,
    config: "Config | None" = None,
) -> tuple[str, str | None]:
    """
    Enhance (add +4) and validate (correct) US ZIP to ZIP+4; return warning if corrected.

    Uses Google Address Validation API when config or GOOGLE_ADDRESS_VALIDATION_API_KEY (or
    GOOGLE_CIVIC_API_KEY) is set and address components are present; otherwise falls
    back to USPS (if configured) or 5-digit ZIP.

    Returns:
        (zip_plus_four_string, warning_or_none). warning is set when the API corrected
        the postal code (e.g. wrong +4 replaced).
    """
    zip_code = (zip_code or "").strip()
    if not zip_code:
        return "", None
    zip5_only = zip_code.split("-")[0].strip() if zip_code else ""
    if len(zip5_only) != 5 or not zip5_only.isdigit():
        return zip_code, None
    street_1 = (street_address_1 or "").strip()
    city_s = (city or "").strip()
    state_s = (state or "").strip()[:2].upper()
    if not street_1 or not city_s or not state_s:
        zip_result = _fallback_zip_plus_four(
            street_1 or street_address_1,
            city_s or city,
            state_s or state,
            zip5_only,
            config=config,
        )
        return (zip_result or zip5_only), None

    key = _get_zip_validation_api_key(api_key, config=config)
    if not key:
        zip_result = _fallback_zip_plus_four(
            street_1, city_s, state_s, zip5_only, config=config
        )
        return (zip_result or zip5_only), None

    result_zip, warning = _google_address_validate_zip(
        street_1=street_1,
        street_2=(street_address_2 or "").strip() or None,
        city=city_s,
        state=state_s,
        zip_code=zip5_only,
        api_key=key,
    )
    if result_zip is not None:
        return result_zip, warning
    zip_result = _fallback_zip_plus_four(
        street_1, city_s, state_s, zip5_only, config=config
    )
    return (zip_result or zip5_only), None


def _fallback_zip_plus_four(
    street_1: str,
    city: str,
    state: str,
    zip5: str,
    *,
    config: "Config | None" = None,
) -> str | None:
    """USPS lookup if USPS_USER_ID set (via config or env), else return 5-digit. Used to avoid recursion from get_zip_plus_four."""
    user_id = (
        (config.usps_user_id or "").strip()
        if config
        else (os.environ.get("USPS_USER_ID") or "").strip()
    )
    if user_id and street_1 and city and state and zip5:
        return _usps_zip_code_lookup(user_id, street_1, city, state, zip5)
    return zip5 if zip5 else None


def _google_address_validate_zip(
    street_1: str,
    city: str,
    state: str,
    zip_code: str,
    api_key: str,
    street_2: str | None = None,
) -> tuple[str | None, str | None]:
    """Call Google Address Validation API; return (zip_plus_four_or_none, warning_or_none)."""
    import json
    from urllib.error import HTTPError, URLError
    from urllib.request import Request, urlopen

    address_lines = [street_1]
    if street_2:
        address_lines.append(street_2)
    body = {
        "address": {
            "regionCode": "US",
            "locality": city,
            "administrativeArea": state,
            "postalCode": zip_code,
            "addressLines": address_lines,
        },
        "enableUspsCass": True,
    }
    url = f"https://addressvalidation.googleapis.com/v1:validateAddress?key={api_key}"
    try:
        req = Request(
            url,
            data=json.dumps(body).encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/json",
                "User-Agent": "GovPal-Reach/1.0",
            },
        )
        with urlopen(req, timeout=10) as resp:
            if resp.status != 200:
                return None, None
            data = json.loads(resp.read().decode("utf-8"))
    except (HTTPError, URLError, OSError, ValueError, KeyError):
        return None, None

    result = data.get("result")
    if not result:
        return None, None
    usps = result.get("uspsData") or {}
    std = usps.get("standardizedAddress") or {}
    z5 = (std.get("zipCode") or "").strip()
    z4 = (std.get("zipCodeExtension") or "").strip()
    if not z5 or len(z5) != 5:
        return None, None
    zip_plus_four = f"{z5}-{z4}" if z4 else z5

    warning = None
    verdict = result.get("verdict") or {}
    if verdict.get("hasReplacedComponents"):
        addr = result.get("address") or {}
        for comp in addr.get("addressComponents") or []:
            if (comp.get("componentType") or "").lower() in (
                "postal_code",
                "postal_code_prefix",
                "postal_code_suffix",
            ):
                if comp.get("replaced"):
                    warning = f"ZIP code was corrected to {zip_plus_four}."
                    break

    return zip_plus_four, warning


def get_zip_plus_four(
    street_address_1: str | None,
    city: str | None,
    state: str | None,
    zip5: str | None,
    *,
    api_key: str | None = None,
    config: "Config | None" = None,
) -> str:
    """
    Return ZIP+4 when available, otherwise 5-digit ZIP.

    Uses Google Address Validation API when config or GOOGLE_ADDRESS_VALIDATION_API_KEY (or
    GOOGLE_CIVIC_API_KEY) is set; otherwise USPS Web Tools when USPS_USER_ID is set.
    USPS Web Tools is being retired Jan 2026.
    """
    zip_plus_four, _ = enhance_and_validate_zip_plus_four(
        street_address_1, city, state, zip5, api_key=api_key, config=config
    )
    return zip_plus_four


def get_zip_plus_four_from_components(
    components: AddressComponents,
    *,
    api_key: str | None = None,
    config: "Config | None" = None,
) -> str:
    """
    Return ZIP+4 from address components. Convenience wrapper over get_zip_plus_four.
    """
    return get_zip_plus_four(
        street_address_1=components.get("street_address_1"),
        city=components.get("city"),
        state=components.get("state"),
        zip5=components.get("zip_code"),
        api_key=api_key,
        config=config,
    )


def enhance_and_validate_zip_plus_four_from_components(
    components: AddressComponents,
    api_key: str | None = None,
    config: "Config | None" = None,
) -> tuple[str, str | None]:
    """
    Enhance and validate ZIP+4 from address components. Convenience wrapper over
    enhance_and_validate_zip_plus_four. Returns (zip_plus_four_string, warning_or_none).
    """
    return enhance_and_validate_zip_plus_four(
        street_address_1=components.get("street_address_1"),
        city=components.get("city"),
        state=components.get("state"),
        zip_code=components.get("zip_code"),
        street_address_2=components.get("street_address_2"),
        api_key=api_key,
        config=config,
    )


def _usps_zip_code_lookup(
    user_id: str,
    address2: str,
    city: str,
    state: str,
    zip5: str,
) -> str | None:
    """Call USPS ZipCode Lookup API; return ZIP+4 string or None on failure."""
    import xml.etree.ElementTree as ET
    from urllib.error import HTTPError, URLError
    from urllib.parse import quote
    from urllib.request import Request, urlopen

    # Request: Address1 optional, Address2 required (street), City, State, Zip5 optional
    xml = (
        f'<ZipCodeLookupRequest USERID="{quote(user_id)}">'
        f'<Address ID="0">'
        f"<Address1></Address1>"
        f"<Address2>{_escape_xml(address2)}</Address2>"
        f"<City>{_escape_xml(city)}</City>"
        f"<State>{_escape_xml(state)}</State>"
        f"<Zip5>{zip5}</Zip5>"
        f"<Zip4></Zip4>"
        f"</Address>"
        f"</ZipCodeLookupRequest>"
    )
    url = f"https://secure.shippingapis.com/ShippingAPI.dll?API=ZipCodeLookup&XML={quote(xml)}"
    try:
        req = Request(url, headers={"User-Agent": "GovPal-Reach/1.0"})
        with urlopen(req, timeout=10) as resp:
            if resp.status != 200:
                return None
            body = resp.read().decode("utf-8")
    except (HTTPError, URLError, OSError):
        return None
    if "<Error>" in body:
        return None
    try:
        root = ET.fromstring(body)
        addr = root.find(".//Address")
        if addr is None:
            return None
        z5 = addr.find("Zip5")
        z4 = addr.find("Zip4")
        if z5 is not None and z5.text and z5.text.strip():
            zip5_val = z5.text.strip()
            if z4 is not None and z4.text and z4.text.strip():
                return f"{zip5_val}-{z4.text.strip()}"
            return zip5_val
    except ET.ParseError:
        pass
    return None


def _escape_xml(s: str) -> str:
    return (
        (s or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
        .replace("'", "&apos;")
    )
