"""User and profile persistence with PII encryption. (Phase 3.)"""

from typing import TYPE_CHECKING
from uuid import UUID

from psycopg.rows import dict_row

from govpal.db import get_connection, gpr_table
from govpal.identity.models import User, UserProfile
from govpal.identity.pii import decrypt_field, encrypt_field

if TYPE_CHECKING:
    from govpal.config import Config


def get_user_by_phone(
    phone: str,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> User | None:
    """Return user by phone, or None."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT id, phone, phone_verified, created_at,
                       verify_session_uuid
                FROM {table}
                WHERE phone = %s
            """.format(table=gpr_table("users")),
                (phone,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return User.from_row(
        id=row["id"],
        phone=row["phone"],
        phone_verified=row["phone_verified"],
        created_at=row["created_at"],
        verify_session_uuid=row.get("verify_session_uuid"),
    )


def create_user(
    phone: str,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> User:
    """Insert user; return User. Raises if phone already exists."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO {table} (phone)
                VALUES (%s)
                RETURNING id, phone, phone_verified, created_at, verify_session_uuid
                """.format(table=gpr_table("users")),
                (phone,),
            )
            row = cur.fetchone()
            conn.commit()
    return User.from_row(
        id=row["id"],
        phone=row["phone"],
        phone_verified=row["phone_verified"],
        created_at=row["created_at"],
        verify_session_uuid=row.get("verify_session_uuid"),
    )


def get_or_create_user(
    phone: str,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> User:
    """Return existing user or create and return new user."""
    user = get_user_by_phone(phone, dsn=dsn, config=config)
    if user:
        return user
    return create_user(phone, dsn=dsn, config=config)


def delete_user_by_phone(
    phone: str,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> bool:
    """
    Delete user by phone. user_profiles are removed via ON DELETE CASCADE.
    Returns True if a row was deleted, False if no user existed.
    """
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                "DELETE FROM {table} WHERE phone = %s".format(table=gpr_table("users")),
                (phone,),
            )
            deleted = cur.rowcount
            conn.commit()
    return deleted > 0


def update_phone_verified(
    user_id: UUID,
    verified: bool,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> None:
    """Set users.phone_verified and clear verify_session_uuid."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                UPDATE {table}
                SET phone_verified = %s, verify_session_uuid = NULL
                WHERE id = %s
                """.format(table=gpr_table("users")),
                (verified, user_id),
            )
            conn.commit()


def update_verify_session_uuid(
    user_id: UUID,
    session_uuid: str | None,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> None:
    """Set users.verify_session_uuid (for OTP flow)."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                UPDATE {table}
                SET verify_session_uuid = %s
                WHERE id = %s
                """.format(table=gpr_table("users")),
                (session_uuid, user_id),
            )
            conn.commit()


def get_profile(
    user_id: UUID,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> UserProfile | None:
    """Load user_profiles row and decrypt PII."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                SELECT user_id, first_name_encrypted, last_name_encrypted,
                       address_encrypted, email_encrypted, zip_code, updated_at,
                       street_address_1_encrypted, street_address_2_encrypted,
                       city_encrypted, state_encrypted
                FROM {table}
                WHERE user_id = %s
                """.format(table=gpr_table("user_profiles")),
                (user_id,),
            )
            row = cur.fetchone()
    if not row:
        return None
    return UserProfile.from_row(
        user_id=row["user_id"],
        first_name=decrypt_field(row.get("first_name_encrypted"), config=config),
        last_name=decrypt_field(row.get("last_name_encrypted"), config=config),
        address=decrypt_field(row.get("address_encrypted"), config=config),
        email=decrypt_field(row.get("email_encrypted"), config=config),
        zip_code=row.get("zip_code"),
        updated_at=row.get("updated_at"),
        street_address_1=decrypt_field(
            row.get("street_address_1_encrypted"), config=config
        ),
        street_address_2=decrypt_field(
            row.get("street_address_2_encrypted"), config=config
        ),
        city=decrypt_field(row.get("city_encrypted"), config=config),
        state=decrypt_field(row.get("state_encrypted"), config=config),
    )


def upsert_profile(
    profile: UserProfile,
    *,
    dsn: str | None = None,
    config: "Config | None" = None,
) -> None:
    """Insert or update user_profiles with encrypted PII."""
    with get_connection(dsn, config=config) as conn:
        with conn.cursor(row_factory=dict_row) as cur:
            cur.execute(
                """
                INSERT INTO {table} (
                    user_id, first_name_encrypted, last_name_encrypted,
                    address_encrypted, email_encrypted, zip_code, updated_at,
                    street_address_1_encrypted, street_address_2_encrypted,
                    city_encrypted, state_encrypted
                )
                VALUES (%s, %s, %s, %s, %s, %s, NOW(), %s, %s, %s, %s)
                ON CONFLICT (user_id) DO UPDATE SET
                    first_name_encrypted = EXCLUDED.first_name_encrypted,
                    last_name_encrypted = EXCLUDED.last_name_encrypted,
                    address_encrypted = EXCLUDED.address_encrypted,
                    email_encrypted = EXCLUDED.email_encrypted,
                    zip_code = EXCLUDED.zip_code,
                    updated_at = NOW(),
                    street_address_1_encrypted = EXCLUDED.street_address_1_encrypted,
                    street_address_2_encrypted = EXCLUDED.street_address_2_encrypted,
                    city_encrypted = EXCLUDED.city_encrypted,
                    state_encrypted = EXCLUDED.state_encrypted
                """.format(table=gpr_table("user_profiles")),
                (
                    profile.user_id,
                    encrypt_field(profile.first_name, config=config),
                    encrypt_field(profile.last_name, config=config),
                    encrypt_field(profile.address, config=config),
                    encrypt_field(profile.email, config=config),
                    profile.zip_code,
                    encrypt_field(profile.street_address_1, config=config),
                    encrypt_field(profile.street_address_2, config=config),
                    encrypt_field(profile.city, config=config),
                    encrypt_field(profile.state, config=config),
                ),
            )
            conn.commit()
