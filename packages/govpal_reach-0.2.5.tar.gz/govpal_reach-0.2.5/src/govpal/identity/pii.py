"""Field-level encryption for PII. (Implementation: Phase 3.)"""

import base64
import os
from typing import TYPE_CHECKING, Optional

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

if TYPE_CHECKING:
    from govpal.config import Config


def _derive_key(raw: str) -> bytes:
    """Derive Fernet key from raw string: 44-char base64 or passphrase (PBKDF2). Raises if raw is empty."""
    if not (raw or "").strip():
        raise ValueError("PII_ENCRYPTION_KEY must be set for PII encryption")
    raw_bytes = raw.strip().encode("utf-8")
    # Fernet key is 44-byte URL-safe base64; accept if valid
    if len(raw_bytes) == 44:
        try:
            base64.urlsafe_b64decode(raw_bytes)
            return raw_bytes
        except Exception:
            pass
    # Derive 32-byte key via PBKDF2, then encode for Fernet
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"govpal-pii-v1",
        iterations=100000,
    )
    return base64.urlsafe_b64encode(kdf.derive(raw_bytes))


def _get_key(config: "Config | None" = None) -> bytes:
    """Fernet key from config.pii_encryption_key or PII_ENCRYPTION_KEY env."""
    if config and (config.pii_encryption_key or "").strip():
        return _derive_key(config.pii_encryption_key)
    raw = os.environ.get("PII_ENCRYPTION_KEY", "") or ""
    return _derive_key(raw)


def encrypt_field(
    plaintext: Optional[str],
    *,
    config: "Config | None" = None,
) -> Optional[bytes]:
    """
    Encrypt a PII string for storage. Returns None for None or empty string.
    When config is provided and config.pii_encryption_key is set, uses that key; otherwise uses PII_ENCRYPTION_KEY env.
    """
    if plaintext is None or plaintext == "":
        return None
    f = Fernet(_get_key(config))
    return f.encrypt(plaintext.encode("utf-8"))


def decrypt_field(
    ciphertext: Optional[bytes],
    *,
    config: "Config | None" = None,
) -> Optional[str]:
    """
    Decrypt stored PII. Returns None for None or empty bytes.
    When config is provided and config.pii_encryption_key is set, uses that key; otherwise uses PII_ENCRYPTION_KEY env.
    """
    if ciphertext is None or len(ciphertext) == 0:
        return None
    f = Fernet(_get_key(config))
    try:
        return f.decrypt(ciphertext).decode("utf-8")
    except InvalidToken:
        raise ValueError("Decryption failed (wrong key or corrupted data)")


def get_fernet_for_tests(key: bytes) -> Fernet:
    """Return a Fernet instance for the given key (tests only). Key: 32 raw bytes or 44 base64."""
    if len(key) == 32:
        key = base64.urlsafe_b64encode(key)
    return Fernet(key)
