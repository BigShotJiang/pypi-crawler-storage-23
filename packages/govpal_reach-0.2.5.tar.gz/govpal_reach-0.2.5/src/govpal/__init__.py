"""GovPal Reach – civic engagement library (address → reps → delivery)."""

from importlib.metadata import version as _version, PackageNotFoundError
from pathlib import Path

from govpal.config import Config, ValidationResult, validate_config, validate_config_live

__all__ = [
    "Config",
    "ValidationResult",
    "validate_config",
    "validate_config_live",
    "__version__",
    "get_version_info",
]

try:
    __version__ = _version("govpal-reach")
except PackageNotFoundError:
    __version__ = "0.0.0+unknown"


def get_version_info() -> dict:
    """Return version info for logging on startup.
    
    Returns dict with:
        - version: The library version string
        - source: "local" if installed from file:// path, "pypi" if from PyPI
        - path: File system path for local installs, None for PyPI installs
    """
    info = {"version": __version__, "source": "pypi", "path": None}
    
    try:
        from importlib.metadata import distribution
        import json
        
        dist = distribution("govpal-reach")
        
        # Check direct_url.json to see if installed from file:// path
        for f in dist.files or []:
            if f.name == "direct_url.json":
                try:
                    data = json.loads(f.read_text())
                    url = data.get("url", "")
                    if url.startswith("file://"):
                        info["source"] = "local"
                        info["path"] = url[7:]  # Strip file://
                except Exception:
                    pass
                break
                
    except Exception:
        pass
    
    return info
