"""Alembic migrations for GovPal Reach. Idempotent revisions; safe to run upgrade head after any library update."""

from pathlib import Path


def get_versions_path() -> Path:
    """Return the path to the library's Alembic versions directory for use in version_locations."""
    try:
        from importlib.resources import files

        ref = files("govpal")
        return Path(ref) / "alembic" / "versions"
    except Exception:
        import pkg_resources

        return Path(pkg_resources.resource_filename("govpal", "alembic/versions"))
