"""Rename tables to gpr_ prefix. Idempotent: skip renames if already gpr_*.

Revision ID: 008_reach_gpr_table_namespace
Revises: 007_reach_widen_district_column
"""

from typing import Sequence, Union

from alembic import op
from sqlalchemy import text

revision: str = "008_reach_gpr_table_namespace"
down_revision: Union[str, None] = "007_reach_widen_district_column"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

RENAMES = [
    ("users", "gpr_users"),
    ("user_profiles", "gpr_user_profiles"),
    ("representatives", "gpr_representatives"),
    ("regional_sources", "gpr_regional_sources"),
    ("contact_overrides", "gpr_contact_overrides"),
    ("static_officials", "gpr_static_officials"),
    ("messages", "gpr_messages"),
]


def _table_exists(conn, name: str) -> bool:
    r = conn.execute(
        text("SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = :t"),
        {"t": name},
    )
    return r.scalar() is not None


def upgrade() -> None:
    conn = op.get_bind()
    for old_name, new_name in RENAMES:
        if _table_exists(conn, old_name) and not _table_exists(conn, new_name):
            op.rename_table(old_name, new_name)


def downgrade() -> None:
    for old_name, new_name in RENAMES:
        op.rename_table(new_name, old_name)
