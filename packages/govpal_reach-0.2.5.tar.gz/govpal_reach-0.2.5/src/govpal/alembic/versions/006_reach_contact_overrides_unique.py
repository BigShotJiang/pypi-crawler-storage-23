"""Unique constraint on contact_overrides for upsert. Idempotent: dedupe then add constraint only if not exists.

Revision ID: 006_reach_contact_overrides_unique
Revises: 005_reach_user_profile_address_fields
"""

from typing import Sequence, Union

from alembic import op

revision: str = "006_reach_contact_overrides_unique"
down_revision: Union[str, None] = "005_reach_user_profile_address_fields"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("""
        DELETE FROM contact_overrides a
        USING contact_overrides b
        WHERE a.target_type = b.target_type
          AND (a.jurisdiction IS NOT DISTINCT FROM b.jurisdiction)
          AND (a.district IS NOT DISTINCT FROM b.district)
          AND a.id > b.id
    """)
    op.execute("""
        DO $$
        BEGIN
          IF NOT EXISTS (
            SELECT 1 FROM pg_constraint
            WHERE conname = 'contact_overrides_target_jurisdiction_district_key'
          ) THEN
            ALTER TABLE contact_overrides
              ADD CONSTRAINT contact_overrides_target_jurisdiction_district_key
              UNIQUE (target_type, jurisdiction, district);
          END IF;
        END $$
    """)


def downgrade() -> None:
    op.drop_constraint(
        "contact_overrides_target_jurisdiction_district_key",
        "contact_overrides",
        type_="unique",
    )
