"""Add subject and body to gpr_messages. Idempotent (ADD COLUMN IF NOT EXISTS).

Revision ID: 009_reach_gpr_messages_subject_body
Revises: 008_reach_gpr_table_namespace
"""

from typing import Sequence, Union

from alembic import op

revision: str = "009_reach_gpr_messages_subject_body"
down_revision: Union[str, None] = "008_reach_gpr_table_namespace"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute("ALTER TABLE gpr_messages ADD COLUMN IF NOT EXISTS subject TEXT")
    op.execute("ALTER TABLE gpr_messages ADD COLUMN IF NOT EXISTS body TEXT")


def downgrade() -> None:
    op.drop_column("gpr_messages", "subject")
    op.drop_column("gpr_messages", "body")
