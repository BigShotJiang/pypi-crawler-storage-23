"""Add verify_session_uuid to users for Plivo OTP flow. Idempotent (ADD COLUMN IF NOT EXISTS).

Revision ID: 002_reach_verify_session_uuid
Revises: 001_reach_initial
"""

from typing import Sequence, Union

from alembic import op

revision: str = "002_reach_verify_session_uuid"
down_revision: Union[str, None] = "001_reach_initial"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE users ADD COLUMN IF NOT EXISTS verify_session_uuid VARCHAR(36)"
    )
    op.execute(
        "COMMENT ON COLUMN users.verify_session_uuid IS 'Plivo Verify session UUID; set on OTP send, cleared on verify or expiry'"
    )


def downgrade() -> None:
    op.drop_column("users", "verify_session_uuid")
