"""Add honorific to representatives. Idempotent (ADD COLUMN IF NOT EXISTS).

Revision ID: 004_reach_representatives_honorific
Revises: 002_reach_verify_session_uuid
"""

from typing import Sequence, Union

from alembic import op

revision: str = "004_reach_representatives_honorific"
down_revision: Union[str, None] = "002_reach_verify_session_uuid"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.execute(
        "ALTER TABLE representatives ADD COLUMN IF NOT EXISTS honorific VARCHAR(50)"
    )
    op.execute(
        "COMMENT ON COLUMN representatives.honorific IS 'Optional greeting title (e.g. Councilmember, Supervisor); overrides default by level for local reps'"
    )


def downgrade() -> None:
    op.drop_column("representatives", "honorific")
