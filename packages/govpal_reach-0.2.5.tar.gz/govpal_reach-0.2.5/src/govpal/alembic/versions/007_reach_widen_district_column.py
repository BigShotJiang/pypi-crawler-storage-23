"""Widen district column. Idempotent: ALTER COLUMN type is safe to re-run.

Revision ID: 007_reach_widen_district_column
Revises: 006_reach_contact_overrides_unique
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

revision: str = "007_reach_widen_district_column"
down_revision: Union[str, None] = "006_reach_contact_overrides_unique"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "contact_overrides",
        "district",
        existing_type=sa.String(50),
        type_=sa.String(200),
        existing_nullable=True,
    )
    op.alter_column(
        "representatives",
        "district",
        existing_type=sa.String(50),
        type_=sa.String(200),
        existing_nullable=True,
    )


def downgrade() -> None:
    op.alter_column(
        "contact_overrides",
        "district",
        existing_type=sa.String(200),
        type_=sa.String(50),
        existing_nullable=True,
    )
    op.alter_column(
        "representatives",
        "district",
        existing_type=sa.String(200),
        type_=sa.String(50),
        existing_nullable=True,
    )
