"""Create gpr_dead_letter_jobs table. Idempotent (create_table if_not_exists).

Revision ID: 010_reach_gpr_dead_letter_jobs
Revises: 009_reach_gpr_messages_subject_body
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "010_reach_gpr_dead_letter_jobs"
down_revision: Union[str, None] = "009_reach_gpr_messages_subject_body"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "gpr_dead_letter_jobs",
        sa.Column(
            "id",
            postgresql.UUID(as_uuid=True),
            server_default=sa.text("gen_random_uuid()"),
            primary_key=True,
        ),
        sa.Column("original_job_id", sa.BigInteger(), nullable=False),
        sa.Column("payload", postgresql.JSONB(), nullable=False),
        sa.Column("reason", sa.Text(), nullable=False),
        sa.Column("message_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("representative_id", postgresql.UUID(as_uuid=True), nullable=True),
        sa.Column("delivery_method", sa.String(20), nullable=True),
        sa.Column(
            "created_at",
            sa.DateTime(timezone=True),
            server_default=sa.func.now(),
            nullable=True,
        ),
        if_not_exists=True,
    )
    op.create_index(
        "idx_gpr_dead_letter_jobs_created_at",
        "gpr_dead_letter_jobs",
        ["created_at"],
        if_not_exists=True,
    )
    op.create_index(
        "idx_gpr_dead_letter_jobs_message_id",
        "gpr_dead_letter_jobs",
        ["message_id"],
        if_not_exists=True,
    )


def downgrade() -> None:
    op.drop_index(
        "idx_gpr_dead_letter_jobs_message_id", table_name="gpr_dead_letter_jobs"
    )
    op.drop_index(
        "idx_gpr_dead_letter_jobs_created_at", table_name="gpr_dead_letter_jobs"
    )
    op.drop_table("gpr_dead_letter_jobs")
