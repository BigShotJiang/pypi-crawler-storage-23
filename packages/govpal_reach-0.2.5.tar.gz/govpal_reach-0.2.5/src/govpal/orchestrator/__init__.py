"""Orchestrator – high-level API for host app."""
