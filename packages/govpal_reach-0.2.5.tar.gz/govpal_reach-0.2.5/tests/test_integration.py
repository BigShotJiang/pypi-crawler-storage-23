"""
Integration tests: multi-module flows with no live API or DB.

Run with: uv run pytest -m integration

These tests exercise composed behavior (orchestrator + discovery/delivery)
with mocks at external boundaries, so they run without DATABASE_URL or API keys.
"""

import pytest

from govpal.discovery.interfaces import GeocodingProvider, Rep, RepProvider
from govpal.orchestrator.api import discover_reps_for_address


class _MockGeocoding(GeocodingProvider):
    def geocode(self, address: str) -> tuple[float, float] | None:
        return (34.05, -118.24)


class _MockRepProvider(RepProvider):
    def __init__(self, reps: list[Rep]) -> None:
        self.reps = reps

    def get_reps_by_address(self, address: str) -> list[Rep]:
        return self.reps.copy()

    def get_reps_by_coords(self, lat: float, lng: float) -> list[Rep]:
        return self.reps.copy()


@pytest.mark.integration
def test_discover_reps_for_address_composed_flow() -> None:
    """Orchestrator discovery flow: geocode + rep providers composed without live APIs."""
    reps: list[Rep] = [
        {
            "level": "federal",
            "name": "Rep Jane Doe",
            "contact_email": "jane@house.gov",
            "data_source": "test",
        },
        {
            "level": "state",
            "name": "Sen John Smith",
            "contact_email": "john@senate.gov",
            "data_source": "test",
        },
    ]
    result = discover_reps_for_address(
        "123 Main St, Los Angeles, CA 90012",
        geocoding_provider=_MockGeocoding(),
        rep_providers=[_MockRepProvider(reps)],
    )
    assert len(result) == 2
    names = {r["name"] for r in result}
    assert "Rep Jane Doe" in names
    assert "Sen John Smith" in names
