"""Tests for Config abstraction."""

from unittest.mock import patch

from govpal.config import Config, ValidationResult, validate_config


class TestConfigFromEnv:
    """Config.from_env reads from os.environ."""

    def test_loads_database_url(self) -> None:
        with patch.dict("os.environ", {"DATABASE_URL": "postgres://test"}, clear=False):
            cfg = Config.from_env()
        assert cfg.database_url == "postgres://test"

    def test_loads_google_civic_key(self) -> None:
        with patch.dict("os.environ", {"GOOGLE_CIVIC_API_KEY": "abc123"}, clear=False):
            cfg = Config.from_env()
        assert cfg.google_civic_api_key == "abc123"

    def test_missing_keys_are_empty(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            cfg = Config.from_env()
        assert cfg.database_url == ""
        assert cfg.google_civic_api_key == ""


class TestConfigFromDict:
    """Config.from_dict loads from flat dict."""

    def test_loads_from_dict(self) -> None:
        d = {
            "DATABASE_URL": "postgres://local",
            "GOOGLE_CIVIC_API_KEY": "key1",
            "OPENSTATES_API_KEY": "key2",
        }
        cfg = Config.from_dict(d)
        assert cfg.database_url == "postgres://local"
        assert cfg.google_civic_api_key == "key1"
        assert cfg.openstates_api_key == "key2"

    def test_empty_dict_yields_empty_config(self) -> None:
        cfg = Config.from_dict({})
        assert cfg.database_url == ""
        assert cfg.google_civic_api_key == ""


class TestValidateConfig:
    """Test config validation functions."""

    def test_validate_config_all_missing(self) -> None:
        config = Config()
        results = validate_config(config)
        assert len(results) == 4
        statuses = {r.service: r.status for r in results}
        assert statuses["SMS Provider"] == "missing"
        assert statuses["Postmark"] == "missing"
        assert statuses["Google Civic API"] == "missing"
        assert statuses["Open States API"] == "missing"

    def test_validate_config_twilio_present(self) -> None:
        config = Config(
            twilio_account_sid="ACxxx",
            twilio_auth_token="token",
            twilio_verify_service_sid="VAxxx",
        )
        results = validate_config(config)
        sms_result = next(r for r in results if "SMS" in r.service)
        assert sms_result.status == "valid"
        assert "Twilio" in sms_result.service

    def test_validate_config_plivo_present(self) -> None:
        config = Config(
            plivo_auth_id="authid",
            plivo_auth_token="token",
            plivo_verify_app_uuid="uuid",
            sms_provider="plivo",
        )
        results = validate_config(config)
        sms_result = next(r for r in results if "SMS" in r.service)
        assert sms_result.status == "valid"
        assert "Plivo" in sms_result.service

    def test_validate_config_postmark_partial(self) -> None:
        config = Config(postmark_server_token="token")
        results = validate_config(config)
        pm_result = next(r for r in results if r.service == "Postmark")
        assert pm_result.status == "invalid"
        assert "FROM_ADDRESS" in pm_result.message

    def test_validate_config_postmark_complete(self) -> None:
        config = Config(
            postmark_server_token="token",
            postmark_from_address="noreply@example.com",
        )
        results = validate_config(config)
        pm_result = next(r for r in results if r.service == "Postmark")
        assert pm_result.status == "valid"

    def test_validate_config_google_civic_present(self) -> None:
        config = Config(google_civic_api_key="AIza...")
        results = validate_config(config)
        gc_result = next(r for r in results if r.service == "Google Civic API")
        assert gc_result.status == "valid"

    def test_validate_config_openstates_present(self) -> None:
        config = Config(openstates_api_key="xxx")
        results = validate_config(config)
        os_result = next(r for r in results if r.service == "Open States API")
        assert os_result.status == "valid"


class TestValidationResult:
    """Test ValidationResult dataclass."""

    def test_validation_result_fields(self) -> None:
        r = ValidationResult(service="Test", status="valid", message="OK")
        assert r.service == "Test"
        assert r.status == "valid"
        assert r.message == "OK"


class TestGetVersionInfo:
    """Test version info function."""

    def test_get_version_info_returns_dict(self) -> None:
        from govpal import get_version_info
        info = get_version_info()
        assert "version" in info
        assert "source" in info
        assert "path" in info
        assert info["version"]  # Not empty

    def test_version_matches_pyproject(self) -> None:
        from govpal import __version__
        # Version should be semver-ish
        assert "." in __version__
