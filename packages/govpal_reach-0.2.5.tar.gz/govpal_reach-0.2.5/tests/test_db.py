"""Tests for shared database connection helper."""

from unittest.mock import MagicMock, patch

import pytest

from govpal.db import GPR_TABLE_PREFIX, get_connection, gpr_table


class TestGetConnection:
    """get_connection uses DATABASE_URL or dsn."""

    def test_raises_when_no_dsn_and_no_env(self) -> None:
        with patch("govpal.db.os.environ.get", return_value=None):
            with pytest.raises(ValueError, match="DATABASE_URL or dsn must be set"):
                get_connection()

    def test_uses_dsn_when_provided(self) -> None:
        with patch("govpal.db.psycopg.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_conn.__enter__ = MagicMock(return_value=mock_conn)
            mock_conn.__exit__ = MagicMock(return_value=None)
            mock_connect.return_value = mock_conn

            with get_connection("postgres://test"):
                pass

            mock_connect.assert_called_once_with("postgres://test")

    def test_uses_config_database_url_when_dsn_none(self) -> None:
        mock_config = MagicMock()
        mock_config.database_url = "postgres://from_config"
        with patch("govpal.db.psycopg.connect") as mock_connect:
            mock_conn = MagicMock()
            mock_conn.__enter__ = MagicMock(return_value=mock_conn)
            mock_conn.__exit__ = MagicMock(return_value=None)
            mock_connect.return_value = mock_conn

            with get_connection(dsn=None, config=mock_config):
                pass

            mock_connect.assert_called_once_with("postgres://from_config")


class TestGprTablePrefix:
    """gpr_ table namespace for GovPal application tables."""

    def test_prefix_constant(self) -> None:
        assert GPR_TABLE_PREFIX == "gpr_"

    def test_gpr_table_returns_prefixed_name(self) -> None:
        assert gpr_table("users") == "gpr_users"
        assert gpr_table("user_profiles") == "gpr_user_profiles"
        assert gpr_table("messages") == "gpr_messages"
        assert gpr_table("contact_overrides") == "gpr_contact_overrides"
        assert gpr_table("representatives") == "gpr_representatives"
