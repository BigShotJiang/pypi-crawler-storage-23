# 🛡️ Gate V.A.U.L.T.
**Virtual Access & Universal Login Terminal**

[![FastAPI](https://img.shields.io/badge/FastAPI-005571?style=for-the-badge&logo=fastapi)](https://fastapi.tiangolo.com)
[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://www.python.org)
[![License](https://img.shields.io/badge/License-MIT-green?style=for-the-badge)](LICENSE)

---

Welcome to...
              _______                 _          _________
 |\     /|   (  ___  )   |\     /|   ( \         \__   __/
 | )   ( |   | (   ) |   | )   ( |   | (            ) (   
 | |   | |   | (___) |   | |   | |   | |            | |   
 ( (   ) )   |  ___  |   | |   | |   | |            | |   
  \ \_/ /    | (   ) |   | |   | |   | |            | |   
   \   /   _ | )   ( | _ | (___) | _ | (____/\ _    | |   
    \_/   (_)|/     \|(_)(_______)(_)(_______/(_)   )_(

Version: **FastAPI**
Gate **V.A.U.L.T** is a high-performance, asynchronous authentication build with FastAPI. Designed for high-stakes environments where security, tracking, and speed are non-negotiable.
<br>
## The V.A.U.L.T Standard
- V – Virtual Access;
​
- A — Authentication & Authorization;
​
- U — Universal Login;
​
- L — Logging and Register;

- ​T – Tracking & Token Management;

## Installation

```bash
pip install gate_vault
```

## Initializing

```bash
gate new vault # you need to put a name, default folder GATE_VAULT
# Then choose your version (Available: FastAPI (future new Gates)) 
```
