To manually run the MRP scheduler:

1.  Go to *Manufacturing \> Planning \> Run MRP Multi Level*.
2.  On the wizard click *Run MRP*.

To launch replenishment orders (moves, purchases, production orders...):

1.  Go to *Manufacturing \> Planning \> MRP Inventory*.
2.  Filter with *To procure*.
3.  Select multiple records and click on *Action \> Procure* or click
    the right hand side gears in any record.
4.  On the wizard, check everything is ok and click *Execute*.
