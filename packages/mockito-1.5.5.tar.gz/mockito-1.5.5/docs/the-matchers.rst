The matchers
============


.. automodule:: mockito.matchers
   :members:
