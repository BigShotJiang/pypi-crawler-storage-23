
class Foo(object):
    def no_arg(self):
        pass


def one_arg(arg):
    return arg


def send(value):
    return value
