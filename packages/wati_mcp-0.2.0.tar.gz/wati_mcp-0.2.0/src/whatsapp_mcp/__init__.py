"""WhatsApp MCP Server using Wati API."""

from .main import run_server

__all__ = ["run_server"] 