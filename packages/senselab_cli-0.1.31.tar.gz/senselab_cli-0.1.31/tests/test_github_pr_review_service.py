import unittest
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

from service.github_pr_review_service import GitHubPRReviewService


class GitHubPRReviewServiceTest(unittest.TestCase):
    def setUp(self):
        self.client = MagicMock()
        self.service = GitHubPRReviewService(github_client=self.client)

    def test_build_dedupe_key_is_deterministic(self):
        key1 = self.service.build_dedupe_key(
            installation_id=1,
            repo_full_name="org/repo",
            pr_number=12,
            head_sha="abc",
            assistant_guid="assistant-1",
            review_mode="PR_REVIEW",
        )
        key2 = self.service.build_dedupe_key(
            installation_id=1,
            repo_full_name="org/repo",
            pr_number=12,
            head_sha="abc",
            assistant_guid="assistant-1",
            review_mode="PR_REVIEW",
        )
        key3 = self.service.build_dedupe_key(
            installation_id=1,
            repo_full_name="org/repo",
            pr_number=12,
            head_sha="def",
            assistant_guid="assistant-1",
            review_mode="PR_REVIEW",
        )
        key4 = self.service.build_dedupe_key(
            installation_id=1,
            repo_full_name="org/repo",
            pr_number=12,
            head_sha="abc",
            assistant_guid="assistant-1",
            review_mode="PR_REVIEW",
            workflow_id="workflow-a",
        )
        key5 = self.service.build_dedupe_key(
            installation_id=1,
            repo_full_name="org/repo",
            pr_number=12,
            head_sha="abc",
            assistant_guid="assistant-1",
            review_mode="PR_REVIEW",
            workflow_id="workflow-b",
        )
        self.assertEqual(key1, key2)
        self.assertNotEqual(key1, key3)
        self.assertNotEqual(key4, key5)

    def test_normalize_findings_enforces_shape(self):
        findings = [
            {
                "title": "Missing timeout",
                "description": "External call has no timeout.",
                "severity": "high",
                "category": "retries_timeouts_circuit_breakers",
                "file_path": "src/a.py",
                "line": "12",
            },
            {
                "message": "Potential SQL injection",
                "path": "src/b.py",
                "line_start": 44,
            },
            "not-a-dict",
        ]
        normalized = self.service.normalize_findings(findings)
        self.assertEqual(len(normalized), 2)
        self.assertEqual(normalized[0]["line"], 12)
        self.assertEqual(normalized[0]["severity"], "high")
        self.assertIn("fingerprint", normalized[0])
        self.assertEqual(normalized[1]["file_path"], "src/b.py")
        self.assertEqual(normalized[1]["line"], 44)

    def test_extract_review_artifacts_builds_markdown_and_findings(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": ["Finding summary line 1", "Finding summary line 2"],
                        "findings": [
                            {
                                "title": "No retries",
                                "description": "Worker call does not retry",
                                "severity": "medium",
                                "category": "retries_timeouts_circuit_breakers",
                                "file_path": "worker.py",
                                "line": 9,
                            }
                        ],
                    }
                }
            ],
        }
        summary_markdown, findings, payload = self.service.extract_review_artifacts(execution_status)
        self.assertIn("## SenseLab PR Review", summary_markdown)
        self.assertIn("COMPLETED", summary_markdown)
        self.assertIn("| Severity | Count |", summary_markdown)
        self.assertIn("<details>", summary_markdown)
        self.assertIn("Suggested author checklist", summary_markdown)
        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["file_path"], "worker.py")
        self.assertEqual(payload["workflow_status"], "COMPLETED")

    def test_extract_review_artifacts_uses_markdown_fallback_counts(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "Decision: Request changes\n"
                            "Critical/Major inline comments: 3\n"
                            "Top 3 risk hotspots:\n"
                            "- Missing input validation — file_a.py\n"
                            "- Weak fallback handling — file_b.py\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 3)
        self.assertIn("Findings detected:** `3`", summary_markdown)
        self.assertIn("🔴 Blocking findings", summary_markdown)

    def test_extract_review_artifacts_parses_equals_style_severity_breakdown(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "A) Top-level PR Review\n"
                            "Recommendation: Request changes\n"
                            "Severity breakdown: critical=2, high=4, medium=2, low=0"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 8)
        self.assertIn("Findings detected:** `8`", summary_markdown)
        self.assertIn("| 🔴 Critical | 2 |", summary_markdown)
        self.assertIn("| 🟠 High | 4 |", summary_markdown)
        self.assertIn("| 🟡 Medium | 2 |", summary_markdown)
        self.assertIn("| 🟢 Low | 0 |", summary_markdown)

    def test_extract_review_artifacts_specialized_security_json_has_quality_counters(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            """```json
{
  "security_summary": "A) Security Summary\\nRecommendation: Request changes",
  "inline_comments": [
    {
      "id": "IC-1",
      "ReviewType": "Potential issue",
      "Severity": "Major",
      "filePath": "raia/policies/aws_no_ecs_pre.rego",
      "startLine": 33,
      "endLine": 34,
      "message": "Missing guard for resources."
    },
    {
      "id": "IC-2",
      "ReviewType": "Potential issue",
      "Severity": "Minor",
      "filePath": "raia/policies/aws_no_ecs_pre.rego",
      "startLine": 36,
      "endLine": 36,
      "message": "Message says access granted in deny."
    }
  ]
}
```"""
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 2)
        self.assertIn("Findings detected:** `2`", summary_markdown)
        self.assertIn("| 🟠 High | 1 |", summary_markdown)
        self.assertIn("| 🟡 Medium | 1 |", summary_markdown)
        self.assertIn("A) Security Summary", summary_markdown)

    def test_extract_review_artifacts_parses_markdown_inline_comments_and_sets_mode_title(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "A) Security Summary\n"
                            "B) Inline Comments\n\n"
                            "1) **ReviewType:** Potential issue\n"
                            " **File:** `raia/policies/aws_no_ecs_pre.rego`\n"
                            " **Message (3 sentences):** Missing guard for resources.\n\n"
                            "2) **ReviewType:** Potential issue\n"
                            " **File:** `raia/policies/aws_no_ecs_pre.rego`\n"
                            " **Message (3 sentences):** Message says access granted in deny.\n"
                        ]
                    }
                }
            ],
        }
        run = SimpleNamespace(review_mode="SECURITY_DEEP_DIVE")
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status, run=run)
        self.assertEqual(len(findings), 2)
        self.assertIn("Findings detected:** `2`", summary_markdown)
        self.assertIn("| 🟡 Medium | 2 |", summary_markdown)
        self.assertIn("SenseLab PR Review · Security Deep Dive", summary_markdown)

    def test_extract_review_artifacts_prefers_nonzero_breakdown_counts(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "### Security summary\n"
                            "**Findings detected:** 0\n"
                            "| 🔴 Critical | 0 |\n"
                            "| 🟠 High | 0 |\n"
                            "| 🟡 Medium | 0 |\n"
                            "| 🟢 Low | 0 |\n"
                            "Findings count + criticality breakdown\n"
                            "- Total findings: 6\n"
                            "- Critical: 0\n"
                            "- High: 2\n"
                            "- Medium: 3\n"
                            "- Low: 1\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 6)
        self.assertIn("Findings detected:** `6`", summary_markdown)
        self.assertIn("| 🟠 High | 2 |", summary_markdown)
        self.assertIn("| 🟡 Medium | 3 |", summary_markdown)
        self.assertIn("| 🟢 Low | 1 |", summary_markdown)

    def test_extract_review_artifacts_parses_inline_comment_template_severity(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "B) Inline Comments\n\n"
                            "- **InlineCommentID:** IC-1\n"
                            "- **File:** `raia/policies/aws_no_ecs_pre.rego`\n"
                            "- **Anchor (new-file line):** 36\n"
                            "- **Severity:** critical\n"
                            "- **Category:** Correctness & Reliability\n"
                            "- **Comment:** This is a deny rule with access granted text.\n\n"
                            "- **InlineCommentID:** IC-2\n"
                            "- **File:** `raia/policies/aws_no_ecs_pre.rego`\n"
                            "- **Anchor (new-file line):** 47\n"
                            "- **Severity:** high\n"
                            "- **Category:** Security\n"
                            "- **Comment:** Missing guard for input.parameters.\n\n"
                            "Final breakdown (findings by severity)\n"
                            "- **critical:** 1 (IC-1)\n"
                            "- **high:** 4 (IC-2, IC-3, IC-4, IC-5)\n"
                            "- **medium:** 4\n"
                            "- **low:** 3\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 2)
        self.assertIn("Findings detected:** `2`", summary_markdown)
        self.assertIn("| 🔴 Critical | 1 |", summary_markdown)
        self.assertIn("| 🟠 High | 1 |", summary_markdown)
        self.assertIn("| 🟡 Medium | 0 |", summary_markdown)
        self.assertIn("| 🟢 Low | 0 |", summary_markdown)

    def test_extract_review_artifacts_parses_bullet_inline_comment_template(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "## B) Inline Comments\n"
                            "- id: CMT-01\n"
                            "- ReviewType: Potential issue\n"
                            "- Severity: Critical\n"
                            "- filePath: raia/policies/aws_no_ecs_pre.rego\n"
                            "- startLine: 30\n"
                            "- endLine: 31\n"
                            "- message: Missing guard for input.resources.\n\n"
                            "- id: CMT-02\n"
                            "- ReviewType: Potential issue\n"
                            "- Severity: Major\n"
                            "- filePath: raia/policies/aws_no_ecs_pre.rego\n"
                            "- startLine: 46\n"
                            "- endLine: 47\n"
                            "- message: Missing guard for input.parameters.\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 2)
        self.assertIn("Findings detected:** `2`", summary_markdown)
        self.assertIn("| 🔴 Critical | 1 |", summary_markdown)
        self.assertIn("| 🟠 High | 1 |", summary_markdown)

    def test_extract_review_artifacts_parses_non_dashed_inline_comment_template(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "B) Inline Comments\n"
                            "id: CMT-01\n"
                            "ReviewType: Potential issue\n"
                            "Severity: Critical\n"
                            "filePath: raia/policies/aws_no_ecs_pre.rego\n"
                            "startLine: 30\n"
                            "endLine: 31\n"
                            "message: Missing guard for input.resources.\n\n"
                            "id: CMT-02\n"
                            "ReviewType: Potential issue\n"
                            "Severity: Major\n"
                            "filePath: raia/policies/aws_no_ecs_pre.rego\n"
                            "startLine: 46\n"
                            "endLine: 47\n"
                            "message: Missing guard for input.parameters.\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 2)
        self.assertIn("Findings detected:** `2`", summary_markdown)
        self.assertIn("| 🔴 Critical | 1 |", summary_markdown)
        self.assertIn("| 🟠 High | 1 |", summary_markdown)

    def test_extract_review_artifacts_maps_major_minor_trivial_info_severity_breakdown(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "Findings count + criticality breakdown\n"
                            "- Major: 2\n"
                            "- Minor: 1\n"
                            "- Trivial: 1\n"
                            "- Info: 1\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 5)
        self.assertIn("| 🔴 Critical | 0 |", summary_markdown)
        self.assertIn("| 🟠 High | 2 |", summary_markdown)
        self.assertIn("| 🟡 Medium | 1 |", summary_markdown)
        self.assertIn("| 🟢 Low | 2 |", summary_markdown)

    def test_extract_review_artifacts_ignores_webhook_skip_sentinel_answer(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "SKIPPED_GITHUB_WRITE_FOR_WEBHOOK_PR_REVIEW",
                            "A) Security Summary\n"
                            "Severity breakdown: critical=0, high=2, medium=0, low=0",
                        ]
                    }
                }
            ],
        }
        summary_markdown, findings, _ = self.service.extract_review_artifacts(execution_status)
        self.assertEqual(len(findings), 2)
        self.assertNotIn("SKIPPED_GITHUB_WRITE_FOR_WEBHOOK_PR_REVIEW", summary_markdown)
        self.assertIn("| 🟠 High | 2 |", summary_markdown)

    def test_extract_review_artifacts_infers_title_from_summary_when_mode_missing(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "answers": [
                            "A) Security Summary\n"
                            "Recommendation: Request changes\n"
                            "B) Inline Comments\n"
                        ]
                    }
                }
            ],
        }
        summary_markdown, _, _ = self.service.extract_review_artifacts(execution_status, run=None)
        self.assertIn("SenseLab PR Review · Security Deep Dive", summary_markdown)

    def test_extract_review_artifacts_keeps_extracted_findings_with_code_context(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "findings": [
                            {
                                "title": "Missing guard",
                                "description": "Missing null guard.",
                                "severity": "high",
                                "category": "safety",
                                "file_path": "src/policy.rego",
                                "line": 37,
                            }
                        ]
                    }
                }
            ],
        }
        with patch.object(
            self.service,
            "_synthesize_review_with_raia_llm",
            return_value=(
                "Synthesized summary",
                [
                    {
                        "title": "Fallback summary finding",
                        "body": "No exact file context.",
                        "severity": "medium",
                        "category": "summary",
                    }
                ],
            ),
        ):
            _, findings, _ = self.service.extract_review_artifacts(execution_status)

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["file_path"], "src/policy.rego")
        self.assertEqual(findings[0]["line"], 37)

    def test_extract_review_artifacts_uses_synthesized_findings_when_extracted_lacks_context(self):
        execution_status = {
            "workflow_status": "COMPLETED",
            "task_status": [
                {
                    "output": {
                        "findings": [
                            {
                                "title": "Summary-only finding",
                                "description": "No path or line.",
                                "severity": "high",
                                "category": "summary",
                            }
                        ]
                    }
                }
            ],
        }
        with patch.object(
            self.service,
            "_synthesize_review_with_raia_llm",
            return_value=(
                "Synthesized summary",
                [
                    {
                        "title": "Actionable finding",
                        "body": "Specific file and line available.",
                        "severity": "high",
                        "category": "correctness",
                        "file_path": "src/app.py",
                        "line": 12,
                    }
                ],
            ),
        ):
            _, findings, _ = self.service.extract_review_artifacts(execution_status)

        self.assertEqual(len(findings), 1)
        self.assertEqual(findings[0]["file_path"], "src/app.py")
        self.assertEqual(findings[0]["line"], 12)


if __name__ == "__main__":
    unittest.main()
