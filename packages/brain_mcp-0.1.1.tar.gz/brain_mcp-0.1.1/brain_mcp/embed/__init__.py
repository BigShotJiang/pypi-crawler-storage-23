# brain-mcp embed package
