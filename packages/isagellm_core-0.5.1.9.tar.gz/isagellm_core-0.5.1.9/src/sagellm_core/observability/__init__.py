"""Observability module for sageLLM.

Provides structured logging, metrics, tracing, and Prometheus export.
"""

from __future__ import annotations

from sagellm_core.observability.logger import (
    StructuredFormatter,
    TraceContextAdapter,
    get_logger,
    setup_logger,
)
from sagellm_core.observability.metrics import EngineMetrics, MetricsCollector
from sagellm_core.observability.prometheus import (
    PROMETHEUS_AVAILABLE,
    PrometheusExporter,
)

__all__ = [
    "MetricsCollector",
    "EngineMetrics",
    "setup_logger",
    "get_logger",
    "StructuredFormatter",
    "TraceContextAdapter",
    "PrometheusExporter",
    "PROMETHEUS_AVAILABLE",
]
