from django.apps import AppConfig  # pragma: no cover


class StrawberryConfig(AppConfig):  # pragma: no cover
    name = "strawberry"
