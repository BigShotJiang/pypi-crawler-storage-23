"""Tests for the DGMaxClient SDK."""
