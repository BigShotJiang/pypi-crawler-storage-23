"""Unit tests for the DGMaxClient SDK."""
