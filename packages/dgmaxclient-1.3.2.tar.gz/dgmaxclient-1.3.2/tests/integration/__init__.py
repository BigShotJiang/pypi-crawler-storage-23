"""Integration tests for the DGMaxClient SDK.

These tests require actual API access and should be run with proper credentials.
"""
