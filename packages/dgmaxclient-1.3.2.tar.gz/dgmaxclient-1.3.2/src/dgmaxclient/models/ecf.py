"""
Pydantic models for ECF (Electronic Fiscal Document) payloads.

Provides runtime validation, IDE autocomplete, and strict structure
enforcement for ECF payloads sent to the DGMax API.

All non-required fields default to None and are omitted from
serialization via model_dump(exclude_none=True).
"""

from typing import Any

from pydantic import BaseModel, ConfigDict


class ECFBaseModel(BaseModel):
    """Base model for ECF payload structures.

    Uses extra="forbid" to reject unrecognized fields — catches typos
    and enforces strict adherence to the DGII e-CF schema.
    """

    model_config = ConfigDict(
        extra="forbid",
        populate_by_name=True,
    )


# --- IdDoc ---


class ECFIdDoc(ECFBaseModel):
    """Document identification (IdDoc) section.

    Required for all document types (E31-E47).

    Attributes:
        tipo_ecf: Document type number (31, 32, 33, 34, 41, 43-47)
        e_ncf: Electronic fiscal number (eNCF)
    """

    # Required
    tipo_ecf: int
    e_ncf: str

    # Sequence / dates
    fecha_vencimiento_secuencia: str | None = None
    indicador_envio_diferido: int | None = None
    indicador_monto_gravado: int | None = None
    tipo_ingresos: str | None = None

    # Payment
    tipo_pago: int | None = None
    tipo_cuenta_pago: int | None = None
    numero_cuenta_pago: str | None = None
    banco_pago: str | None = None
    fecha_limite_pago: str | None = None
    termino_pago: str | None = None
    tabla_formas_de_pago: list[dict[str, Any]] | None = None
    tabla_forma_pago: list[dict[str, Any]] | None = None

    # Pagination
    fecha_desde: str | None = None
    fecha_hasta: str | None = None
    total_paginas: int | None = None

    # Credit notes (E34)
    indicador_nota_credito: int | None = None


# --- Emisor ---


class ECFEmisor(ECFBaseModel):
    """Issuer (Emisor) section.

    Attributes:
        rnc_emisor: RNC of the issuing company
        razon_social_emisor: Legal name of the issuer
    """

    # Required
    rnc_emisor: str
    razon_social_emisor: str

    # Company info
    nombre_comercial: str | None = None
    sucursal: str | None = None
    direccion_emisor: str | None = None
    municipio_emisor: str | None = None
    provincia_emisor: str | None = None

    # Contact
    telefono_emisor: str | None = None
    correo_emisor: str | None = None
    web_site_emisor: str | None = None
    nombre_contacto: str | None = None
    actividad_economica: str | None = None

    # Sales
    codigo_vendedor: str | None = None
    numero_factura_interna: str | None = None
    numero_orden_compra: str | None = None
    zona_venta: str | None = None
    ruta_venta: str | None = None
    informacion_adicional_emisor: str | None = None

    # Dates
    fecha_emision: str | None = None
    fecha_salida_mercancia: str | None = None


# --- Comprador ---


class ECFComprador(ECFBaseModel):
    """Buyer (Comprador) section.

    All fields are optional because different document types require
    different buyer information (e.g., E32 consumer invoices may not
    have RNC).
    """

    # Identification
    rnc_comprador: str | None = None
    identificador_extranjero: str | None = None
    tipo_identificacion_comprador: int | None = None
    numero_identificacion_comprador: str | None = None

    # Company info
    razon_social_comprador: str | None = None

    # Contact
    contacto: str | None = None
    correo_comprador: str | None = None
    telefono_comprador: str | None = None
    telefono_adicional: str | None = None

    # Address
    direccion_comprador: str | None = None
    municipio_comprador: str | None = None
    provincia_comprador: str | None = None
    pais_comprador: str | None = None

    # Delivery
    fecha_entrega: str | None = None
    contacto_entrega: str | None = None
    direccion_entrega: str | None = None

    # Additional
    fecha_orden_compra: str | None = None
    codigo_interno_comprador: str | None = None
    responsable_pago: str | None = None
    informacion_adicional_comprador: str | None = None


# --- Totales ---


class ECFTotales(ECFBaseModel):
    """Totals section.

    Fields vary by document type:
    - E31: monto_gravado_total, monto_gravado_i1, itbis1, total_itbis,
           total_itbis1, monto_total
    - E32: monto_gravado_i3, itbis3, total_itbis3, monto_total
    - E43: monto_exento, monto_total
    - E41/E47: includes retencion fields

    All fields are optional since different document types require
    different subsets.
    """

    # Taxable amounts
    monto_gravado_total: str | None = None
    monto_gravado_i1: str | None = None
    monto_gravado_i2: str | None = None
    monto_gravado_i3: str | None = None
    monto_exento: str | None = None

    # ITBIS rates and totals
    itbis1: str | None = None
    itbis2: str | None = None
    itbis3: str | None = None
    total_itbis: str | None = None
    total_itbis1: str | None = None
    total_itbis2: str | None = None
    total_itbis3: str | None = None

    # Retention / withholding
    total_itbis_retenido: str | None = None
    itbis_retenido: str | None = None
    itbis_percibido: str | None = None
    itbis_percibido_total: str | None = None
    total_isr: str | None = None
    total_isr_retenido: str | None = None
    isr_retencion: str | None = None
    isr_percibido: str | None = None

    # Additional taxes
    impuesto_adicional: str | None = None
    total_impuesto_adicional: str | None = None
    total_isc: str | None = None
    total_otros_impuestos_adicionales: str | None = None

    # Totals
    monto_total: str | None = None
    monto_no_facturable: str | None = None
    monto_periodo: str | None = None
    saldo_anterior: str | None = None
    monto_avance_pago: str | None = None
    valor_pagar: str | None = None
    valor_pagado: str | None = None
    total_pedido: str | None = None

    # Discounts / surcharges
    descuento_total: str | None = None
    recargo_total: str | None = None
    total_descuento: str | None = None
    sub_total: str | None = None
    itbis_total: str | None = None
    total_monto_gravado: str | None = None

    # Items / payment metadata
    cantidad_items: int | None = None
    fecha_pago: str | None = None
    forma_pago: str | int | None = None
    tipo_pago: int | None = None
    tipo_moneda: str | None = None
    tipo_cambio: str | None = None


# --- Item / DetallesItems ---


class ECFItem(ECFBaseModel):
    """Line item in the document.

    Attributes:
        numero_linea: Line number (sequential, starting at "1")
        indicador_facturacion: Billing indicator (1=18%, 2=16%, 3=0%, 4=Exempt)
        nombre_item: Item name (max 80 chars)
    """

    # Required
    numero_linea: str
    indicador_facturacion: int
    nombre_item: str

    # Item details
    indicador_bien_o_servicio: int | None = None
    descripcion_item: str | None = None
    cantidad_item: str | None = None
    unidad_medida: int | str | None = None

    # Pricing
    precio_unitario_item: str | None = None
    precio_unitario_referencia: str | None = None
    descuento_monto: str | None = None
    recargo_monto: str | None = None
    monto_item: str | None = None

    # Codification
    tabla_codificacion_item: list[dict[str, Any]] | None = None
    tabla_codificacion: list[dict[str, Any]] | None = None
    codigo_item: str | None = None
    codigo_barras: str | None = None

    # Quantities
    tabla_quantidad_y_cantidad: list[dict[str, Any]] | None = None

    # Dates
    fecha_elaboracion: str | None = None
    fecha_vencimiento_item: str | None = None

    # Sub-discounts / surcharges
    tabla_sub_descuento: list[dict[str, Any]] | None = None
    tabla_sub_recargo: list[dict[str, Any]] | None = None

    # Taxes
    retencion: dict[str, Any] | None = None
    tabla_impuesto_adicional: list[dict[str, Any]] | None = None
    otros_impuestos: dict[str, Any] | None = None


class ECFDetallesItems(ECFBaseModel):
    """Container for line items."""

    item: list[ECFItem]


# --- InformacionReferencia ---


class ECFInformacionReferencia(ECFBaseModel):
    """Reference information for debit/credit notes (E33/E34).

    Attributes:
        ncf_modificado: Original NCF being modified
        fecha_ncf_modificado: Date of original NCF (DD-MM-YYYY)
        codigo_modificacion: Modification code (1-4)
        razon_modificacion: Reason for modification
    """

    ncf_modificado: str | None = None
    fecha_ncf_modificado: str | None = None
    codigo_modificacion: int | None = None
    razon_modificacion: str | None = None


# --- Encabezado ---


class ECFEncabezado(ECFBaseModel):
    """Document header (Encabezado).

    Attributes:
        id_doc: Document identification
        emisor: Issuer information
        totales: Document totals
    """

    # Required sections
    id_doc: ECFIdDoc
    emisor: ECFEmisor
    totales: ECFTotales

    # Optional sections
    version: float | None = None
    comprador: ECFComprador | None = None
    informaciones_adicionales: dict[str, Any] | None = None
    transporte: dict[str, Any] | None = None
    otra_moneda: dict[str, Any] | None = None
    informacion_referencia: ECFInformacionReferencia | None = None


# --- Top-level ECF Payload ---


class ECFPayload(ECFBaseModel):
    """Top-level ECF document payload.

    This is the main model for constructing electronic fiscal documents.

    Attributes:
        encabezado: Document header with id_doc, emisor, comprador, totales
        detalles_items: Container with list of line items

    Examples:
        >>> payload = ECFPayload(
        ...     encabezado=ECFEncabezado(
        ...         id_doc=ECFIdDoc(tipo_ecf=31, e_ncf="E310000000001"),
        ...         emisor=ECFEmisor(
        ...             rnc_emisor="123456789",
        ...             razon_social_emisor="Mi Empresa SRL",
        ...         ),
        ...         totales=ECFTotales(monto_total="1000.00"),
        ...     ),
        ...     detalles_items=ECFDetallesItems(
        ...         item=[
        ...             ECFItem(
        ...                 numero_linea="1",
        ...                 indicador_facturacion=1,
        ...                 nombre_item="Servicio",
        ...                 monto_item="1000.00",
        ...             )
        ...         ]
        ...     ),
        ... )
    """

    # Required
    encabezado: ECFEncabezado
    detalles_items: ECFDetallesItems

    # Optional
    subtotales: dict[str, Any] | None = None
    descuentos_o_recargos: dict[str, Any] | None = None
    paginacion: dict[str, Any] | None = None
    informacion_referencia: ECFInformacionReferencia | None = None
    fecha_hora_firma: str | None = None
