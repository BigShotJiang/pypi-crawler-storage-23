"""
DGMaxClient - Python SDK for DGMax API.

A Python SDK for interacting with the DGMax electronic fiscal document
API for the Dominican Republic.

Examples:
    >>> from dgmaxclient import DGMaxClient
    >>>
    >>> # Initialize the client
    >>> client = DGMaxClient(api_key="dgmax_xxx")
    >>>
    >>> # List companies
    >>> companies = client.companies.list()
    >>>
    >>> # Create an invoice
    >>> invoice = client.invoices.create({...})
    >>>
    >>> # List received documents
    >>> received = client.received_documents.list()
"""

from dgmaxclient.client import DGMaxClient
from dgmaxclient.exceptions import (
    DGMaxAuthenticationError,
    DGMaxConnectionError,
    DGMaxError,
    DGMaxRateLimitError,
    DGMaxRequestError,
    DGMaxServerError,
    DGMaxTimeoutError,
    DGMaxValidationError,
)
from dgmaxclient.models import (
    APIResponse,
    ApproveDocumentRequest,
    CertificateCreate,
    CertificatePublic,
    CommercialApproval,
    CommercialApprovalAction,
    CommercialApprovalActionResponse,
    CommercialApprovalDirection,
    CommercialApprovalFilters,
    CommercialApprovalSubmissionStatus,
    CompanyCreate,
    CompanyPublic,
    CompanyRef,
    CompanyType,
    CompanyUpdate,
    DGIIEstado,
    DocumentCreateRequest,
    DocumentFilters,
    DocumentStatus,
    DocumentType,
    ElectronicDocument,
    ErrorDetail,
    ErrorResponse,
    ExternalDocumentStatus,
    Mensaje,
    PaginatedResponse,
    PaginationParams,
    ReceivedDocument,
    ReceivedDocumentFilters,
    ReceivedDocumentStatus,
    RejectDocumentRequest,
)
from dgmaxclient.models.ecf import (
    ECFBaseModel,
    ECFComprador,
    ECFDetallesItems,
    ECFEmisor,
    ECFEncabezado,
    ECFIdDoc,
    ECFInformacionReferencia,
    ECFItem,
    ECFPayload,
    ECFTotales,
)
from dgmaxclient.resources import (
    BaseResource,
    CertificationResource,
    CompaniesResource,
    CreditNotesResource,
    DebitNotesResource,
    DocumentResource,
    ExportsResource,
    FiscalInvoicesResource,
    GovernmentalResource,
    InvoicesResource,
    MinorExpensesResource,
    PaymentsAbroadResource,
    PurchasesResource,
    ReceivedDocumentsResource,
    SpecialRegimesResource,
)

__version__ = "1.3.2"
__author__ = "DGMax"
__email__ = "support@dgmax.do"

__all__ = [
    # Client
    "DGMaxClient",
    # Exceptions
    "DGMaxError",
    "DGMaxAuthenticationError",
    "DGMaxValidationError",
    "DGMaxRequestError",
    "DGMaxServerError",
    "DGMaxTimeoutError",
    "DGMaxConnectionError",
    "DGMaxRateLimitError",
    # Resources
    "BaseResource",
    "DocumentResource",
    "FiscalInvoicesResource",
    "InvoicesResource",
    "DebitNotesResource",
    "CreditNotesResource",
    "PurchasesResource",
    "MinorExpensesResource",
    "SpecialRegimesResource",
    "GovernmentalResource",
    "ExportsResource",
    "PaymentsAbroadResource",
    "ReceivedDocumentsResource",
    "CompaniesResource",
    "CertificationResource",
    # Pagination
    "PaginatedResponse",
    "PaginationParams",
    # ECF models
    "ECFBaseModel",
    "ECFPayload",
    "ECFEncabezado",
    "ECFIdDoc",
    "ECFEmisor",
    "ECFComprador",
    "ECFTotales",
    "ECFItem",
    "ECFDetallesItems",
    "ECFInformacionReferencia",
    # Request models
    "CompanyRef",
    "DocumentCreateRequest",
    "ApproveDocumentRequest",
    "RejectDocumentRequest",
    # Response / base models
    "APIResponse",
    "ErrorResponse",
    "ErrorDetail",
    "DocumentFilters",
    "DocumentStatus",
    "DocumentType",
    "DGIIEstado",
    "ElectronicDocument",
    "ExternalDocumentStatus",
    "Mensaje",
    "ReceivedDocument",
    "ReceivedDocumentStatus",
    "CommercialApproval",
    "CommercialApprovalAction",
    "CommercialApprovalActionResponse",
    "CommercialApprovalDirection",
    "CommercialApprovalSubmissionStatus",
    # Filter models
    "ReceivedDocumentFilters",
    "CommercialApprovalFilters",
    # Company models
    "CertificateCreate",
    "CertificatePublic",
    "CompanyCreate",
    "CompanyPublic",
    "CompanyType",
    "CompanyUpdate",
]
