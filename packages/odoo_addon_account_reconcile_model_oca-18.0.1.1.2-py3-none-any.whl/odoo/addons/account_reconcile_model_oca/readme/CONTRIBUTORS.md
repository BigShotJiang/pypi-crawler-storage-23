- Dixmit

  - Enric Tobella

- Trobz \<<https://www.trobz.com/>\>
  - Do Anh Duy \<<duyda@trobz.com>\>

- [Tecnativa](https://www.tecnativa.com):
  - Víctor Martínez

- Jacques-Etienne Baudoux (BCIM) \<<je@bcim.be>\>
