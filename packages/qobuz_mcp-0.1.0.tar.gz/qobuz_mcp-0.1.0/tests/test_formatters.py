from __future__ import annotations

from qobuz_mcp.formatters import (
    format_album,
    format_artist,
    format_artist_albums,
    format_duration,
    format_favorites,
    format_featured_albums,
    format_genres,
    format_playlist,
    format_playlists,
    format_quality,
    format_search_results,
    format_track,
    format_track_url,
)
from qobuz_mcp.models.album import Album, AlbumTracklist
from qobuz_mcp.models.artist import Artist, ArtistAlbums
from qobuz_mcp.models.common import Genre, Page
from qobuz_mcp.models.playlist import (
    Playlist,
    PlaylistTrack,
    PlaylistTracks,
    UserPlaylists,
)
from qobuz_mcp.models.track import AlbumSummary, Performer, Track, TrackFileUrl

# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


class TestFormatDuration:
    def test_seconds_only(self) -> None:
        assert format_duration(45) == "0:45"

    def test_minutes_and_seconds(self) -> None:
        assert format_duration(185) == "3:05"

    def test_hours_minutes_seconds(self) -> None:
        assert format_duration(3723) == "1:02:03"

    def test_zero(self) -> None:
        assert format_duration(0) == "0:00"


class TestFormatQuality:
    def test_cd_quality(self) -> None:
        assert format_quality(16, 44.1) == "CD 16-bit / 44.1 kHz"

    def test_hi_res_24bit_96(self) -> None:
        assert format_quality(24, 96.0) == "Hi-Res 24-bit / 96 kHz"

    def test_hi_res_24bit_192(self) -> None:
        assert format_quality(24, 192.0) == "Hi-Res 24-bit / 192 kHz"

    def test_none_values(self) -> None:
        assert format_quality(None, None) == "Unknown"

    def test_partial_none(self) -> None:
        assert format_quality(16, None) == "Unknown"


# ------------------------------------------------------------------
# Track
# ------------------------------------------------------------------


def _make_track(
    track_id: int = 1,
    title: str = "Test Track",
    duration: int = 240,
    isrc: str | None = "USABC1234567",
) -> Track:
    return Track(
        id=track_id,
        title=title,
        duration=duration,
        isrc=isrc,
        performer=Performer(id=10, name="Test Artist"),
        album=AlbumSummary(id="abc123", title="Test Album"),
        bit_depth=24,
        sampling_rate=96.0,
    )


class TestFormatTrack:
    def test_includes_key_fields(self) -> None:
        result = format_track(_make_track())
        assert "Test Track" in result
        assert "Test Artist" in result
        assert "Test Album" in result
        assert "4:00" in result
        assert "Hi-Res 24-bit / 96 kHz" in result
        assert "USABC1234567" in result
        assert "Track ID: 1" in result

    def test_no_isrc_omits_isrc_line(self) -> None:
        result = format_track(_make_track(isrc=None))
        assert "ISRC" not in result

    def test_missing_performer_shows_unknown(self) -> None:
        track = Track(id=1, title="Solo", duration=60)
        result = format_track(track)
        assert "Unknown" in result


class TestFormatTrackUrl:
    def test_basic_output(self) -> None:
        url_info = TrackFileUrl(
            url="https://example.com/track.flac",
            format_id=27,
            mime_type="audio/flac",
            bit_depth=24,
            sampling_rate=192.0,
        )
        result = format_track_url(url_info)
        assert "https://example.com/track.flac" in result
        assert "27" in result
        assert "audio/flac" in result
        assert "Hi-Res" in result

    def test_no_mime_type(self) -> None:
        url_info = TrackFileUrl(url="https://example.com/track.flac", format_id=6)
        result = format_track_url(url_info)
        assert "MIME type" not in result


# ------------------------------------------------------------------
# Album
# ------------------------------------------------------------------


def _make_album_tracklist() -> AlbumTracklist:
    tracks: Page[Track] = Page(
        items=[
            Track(id=101, title="Track One", duration=180, track_number=1),
            Track(id=102, title="Track Two", duration=210, track_number=2),
        ],
        total=2,
    )
    return AlbumTracklist(
        id="xyz789",
        title="Great Album",
        tracks_count=2,
        duration=390,
        tracks=tracks,
    )


class TestFormatAlbum:
    def test_includes_tracklist(self) -> None:
        result = format_album(_make_album_tracklist())
        assert "Great Album" in result
        assert "Track One" in result
        assert "Track Two" in result
        assert "ID: 101" in result
        assert "Album ID: xyz789" in result

    def test_no_tracks_still_renders(self) -> None:
        album = AlbumTracklist(id="a1", title="Empty", tracks_count=0, duration=0)
        result = format_album(album)
        assert "Empty" in result


class TestFormatFeaturedAlbums:
    def test_empty_list(self) -> None:
        assert format_featured_albums([]) == "No featured albums found."

    def test_shows_albums(self) -> None:
        albums = [Album(id="a1", title="New Album", released_at=1700000000)]
        result = format_featured_albums(albums)
        assert "New Album" in result
        assert "a1" in result


# ------------------------------------------------------------------
# Artist
# ------------------------------------------------------------------


class TestFormatArtist:
    def test_basic_artist(self) -> None:
        artist = Artist(id=42, name="Cool Artist", albums_count=10)
        result = format_artist(artist)
        assert "Cool Artist" in result
        assert "10" in result
        assert "Artist ID: 42" in result


class TestFormatArtistAlbums:
    def test_shows_total_and_items(self) -> None:
        albums = ArtistAlbums(
            items=[
                Album(id="a1", title="First Album"),
                Album(id="a2", title="Second Album"),
            ],
            total=5,
        )
        result = format_artist_albums(albums)
        assert "5 total" in result
        assert "First Album" in result
        assert "Second Album" in result


# ------------------------------------------------------------------
# Genres
# ------------------------------------------------------------------


class TestFormatGenres:
    def test_empty(self) -> None:
        assert format_genres([]) == "No genres found."

    def test_lists_genres(self) -> None:
        genres = [Genre(id=1, name="Jazz"), Genre(id=2, name="Classical")]
        result = format_genres(genres)
        assert "Jazz" in result
        assert "Classical" in result
        assert "ID: 1" in result


# ------------------------------------------------------------------
# Search & Favorites
# ------------------------------------------------------------------


class TestFormatSearchResults:
    def test_no_results(self) -> None:
        result = format_search_results({}, "tracks")
        assert "No tracks found" in result

    def test_empty_items(self) -> None:
        data: dict[str, object] = {"tracks": {"items": [], "total": 0}}
        result = format_search_results(data, "tracks")
        assert "No tracks found" in result

    def test_track_results(self) -> None:
        data: dict[str, object] = {
            "tracks": {
                "items": [{"id": 1, "title": "Song A", "duration": 180}],
                "total": 1,
            }
        }
        result = format_search_results(data, "tracks")
        assert "Song A" in result
        assert "1 total" in result

    def test_unknown_type_prints_header_only(self) -> None:
        # fmt is None for unrecognised types — items are silently skipped.
        # In practice this path is unreachable; result_type is Literal in server.py.
        data: dict[str, object] = {"videos": {"items": [{"id": 1}], "total": 1}}
        result = format_search_results(data, "videos")
        assert "videos" in result
        assert "1 total" in result


class TestFormatFavorites:
    def test_no_favorites(self) -> None:
        result = format_favorites({}, "tracks")
        assert "No favorite tracks found" in result

    def test_empty_favorites(self) -> None:
        data: dict[str, object] = {"tracks": {"items": [], "total": 0}}
        result = format_favorites(data, "tracks")
        assert "no favorite tracks" in result.lower()


# ------------------------------------------------------------------
# Playlists
# ------------------------------------------------------------------


def _make_playlist(playlist_id: int = 1, name: str = "My Playlist") -> Playlist:
    return Playlist(id=playlist_id, name=name, tracks_count=3, is_public=False)


class TestFormatPlaylists:
    def test_empty(self) -> None:
        playlists = UserPlaylists(items=[], total=0)
        assert format_playlists(playlists) == "You have no playlists."

    def test_lists_playlists(self) -> None:
        playlists = UserPlaylists(
            items=[_make_playlist(1, "Morning"), _make_playlist(2, "Evening")],
            total=2,
        )
        result = format_playlists(playlists)
        assert "Morning" in result
        assert "Evening" in result
        assert "private" in result


class TestFormatPlaylist:
    def test_includes_tracks(self) -> None:
        tracks: Page[PlaylistTrack] = Page(
            items=[
                PlaylistTrack(id=10, title="Alpha", playlist_track_id=100),
                PlaylistTrack(id=20, title="Beta", playlist_track_id=200),
            ],
            total=2,
        )
        playlist = PlaylistTracks(id=5, name="Test List", tracks_count=2, tracks=tracks)
        result = format_playlist(playlist)
        assert "Test List" in result
        assert "Alpha" in result
        assert "Playlist Track ID: 100" in result

    def test_no_tracks(self) -> None:
        playlist = PlaylistTracks(id=5, name="Empty List", tracks_count=0)
        result = format_playlist(playlist)
        assert "Empty List" in result
