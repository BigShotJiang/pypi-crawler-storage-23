# Code Style & Conventions

This document is the authoritative reference for all coding conventions in **qobuz-mcp**. Every contribution must follow these rules. Automated tooling (ruff, mypy) enforces most of them; the rest are enforced at review.

---

## Toolchain

| Tool | Purpose | Command |
|------|---------|---------|
| `ruff check` | Lint (pyflakes, isort, bugbear, etc.) | `uv run ruff check src/ tests/` |
| `ruff format` | Format (replaces black) | `uv run ruff format src/ tests/` |
| `mypy` | Static type checking (strict mode) | `uv run mypy src/` |
| `pytest` | Test runner | `uv run pytest -v` |

Run all checks before committing:
```bash
uv run ruff check src/ tests/ && uv run ruff format --check src/ tests/ && uv run mypy src/ && uv run pytest -v
```

---

## Type Annotations

Every file must begin with:
```python
from __future__ import annotations
```

This enables deferred annotation evaluation (PEP 563), allowing forward references without string quoting.

**Rules:**
- All function parameters and return types must be annotated — no bare `Any` except where genuinely unavoidable (always add a comment explaining why).
- Use `X | None` instead of `Optional[X]`.
- Use `list[T]`, `dict[K, V]`, `tuple[X, ...]` instead of `List`, `Dict`, `Tuple` from `typing`.
- Imports used only in type annotations go inside an `if TYPE_CHECKING:` block to avoid runtime overhead.

```python
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from qobuz_mcp.models import Album
```

---

## Docstrings

Use **Google style** for all public functions, methods, and classes.

```python
async def get_track(self, track_id: str) -> Track:
    """Fetch a single track by its Qobuz ID.

    Args:
        track_id: The unique Qobuz track identifier.

    Returns:
        A fully populated Track model instance.

    Raises:
        QobuzAuthError: If the auth token is missing or expired.
        QobuzNotFoundError: If no track with the given ID exists.
        QobuzAPIError: If the API returns any other non-2xx status.
    """
```

- **Classes:** Describe what the class represents; document attributes in the class docstring if they are not self-evident.
- **Private methods** (`_name`): A single-line docstring is sufficient unless the logic is non-trivial.
- **MCP tool functions:** The docstring becomes the tool description visible to the LLM — write it from the perspective of an AI assistant reading the tool list.

---

## Naming Conventions

| Construct | Convention | Example |
|-----------|-----------|---------|
| Module | `snake_case` | `client.py`, `formatters.py` |
| Class | `PascalCase` | `QobuzClient`, `AlbumTracklist` |
| Function / method | `snake_case` | `get_album()`, `format_track()` |
| Constant | `UPPER_SNAKE_CASE` | `BASE_URL`, `QUALITY_FORMATS` |
| Private attribute / method | `_snake_case` | `_auth_token`, `_raise_for_status()` |
| Type alias | `PascalCase` | `TrackId = str` |
| MCP tool | `snake_case` (FastMCP uses the function name) | `async def get_track_url(...)` |

---

## Async Rules

- All I/O-touching functions in `client.py` are `async def`. No synchronous HTTP calls anywhere.
- `httpx.AsyncClient` is created **once** in the FastMCP lifespan context manager and shared across all tool calls for the lifetime of the server process.
- `asyncio.run()` is called **only** in `__main__.py` as a fallback. Never call it inside a tool or client method — the event loop is already running.
- Tool functions in `server.py` are `async def` and `await` every client call.

```python
# Correct lifespan pattern
@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    settings = get_settings()
    async with httpx.AsyncClient(base_url=BASE_URL) as http:
        client = await QobuzClient.create(..., http_client=http)
        yield {"qobuz": client}
```

---

## Logging

- Each module that emits log messages declares a module-level logger as the first statement after imports:
  ```python
  import logging

  logger = logging.getLogger(__name__)
  ```
- **No `print()` calls** in library code. Use `logger.*` instead.
- Log levels:
  - `DEBUG` — HTTP request/response details, token acquisition
  - `INFO` — server startup, successful login
  - `WARNING` — retried requests, missing optional fields
  - `ERROR` — unrecoverable errors before re-raising
- In `server.py` tools, additionally use `ctx.info()` / `ctx.debug()` for MCP-protocol-level messages that surface to the MCP client.
- **No logging configuration** in library code. Leave that to `__main__.py` or the end user.

---

## Error Handling

### Exception hierarchy (`exceptions.py`)

```
QobuzError                  ← catch-all for this library
├── QobuzAuthError          ← HTTP 401, missing/expired token
└── QobuzAPIError           ← any non-2xx response
    ├── QobuzNotFoundError  ← HTTP 404
    └── QobuzRateLimitError ← HTTP 429
```

### Mapping rule in `client.py`

A single private method handles all status mapping — never inline this logic in individual API methods:

```python
@staticmethod
def _raise_for_status(response: httpx.Response) -> None:
    if response.is_success:
        return
    if response.status_code == 401:
        raise QobuzAuthError(response.text)
    if response.status_code == 404:
        raise QobuzNotFoundError(404, response.text)
    if response.status_code == 429:
        raise QobuzRateLimitError(429, response.text)
    raise QobuzAPIError(response.status_code, response.text)
```

### Tool error handling in `server.py`

Tools **never re-raise** exceptions — they return user-friendly strings so the LLM can report the problem gracefully:

```python
@mcp.tool
async def get_track(track_id: str, ctx: Context) -> str:
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        track = await client.get_track(track_id)
    except QobuzNotFoundError:
        return f"Track '{track_id}' was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzError as exc:
        return f"Error retrieving track: {exc}"
    return format_track(track)
```

---

## Pydantic Model Conventions

### Base model

All domain models inherit `QobuzModel` defined in `models/common.py`:

```python
from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel


class QobuzModel(BaseModel):
    """Base model for all Qobuz API response objects."""

    model_config = ConfigDict(
        alias_generator=to_camel,   # API uses camelCase JSON keys
        populate_by_name=True,      # also accept snake_case in code
        extra="ignore",             # tolerate unknown fields silently
    )
```

### Field naming

Qobuz API returns `camelCase` JSON keys. Python attributes use `snake_case`. The `alias_generator=to_camel` on `QobuzModel` handles this mapping globally.

Use an explicit `Field(alias="...")` **only** when the API key does not follow standard camelCase (e.g. `"isrc"` staying lowercase).

### Generic paginator

```python
from typing import Generic, TypeVar

T = TypeVar("T")


class Page(QobuzModel, Generic[T]):
    """A paginated API response wrapping a list of items."""

    items: list[T]
    total: int
    limit: int
    offset: int
```

### Optional fields

Default all optional fields explicitly — never leave them without a default:

```python
isrc: str | None = None
parental_warning: bool = False
tracks_count: int = 0
```

---

## Module Responsibilities

Each module has a clearly defined scope. Violating these boundaries is a bug.

| Module | Owns | Must NOT |
|--------|------|---------|
| `exceptions.py` | The `QobuzError` hierarchy | Import any other `qobuz_mcp` module |
| `models/common.py` | `QobuzModel` base, `Image`, `Genre`, `Page[T]` | Import from other model submodules |
| `models/track.py` | `Track`, `TrackFileUrl`, nested track types | Import from `album.py`, `playlist.py` |
| `models/album.py` | `Album`, `AlbumTracklist`, `Label` | Import from `playlist.py`, `user.py` |
| `models/artist.py` | `Artist`, `ArtistAlbums`, `Biography` | Import from `playlist.py`, `user.py` |
| `models/playlist.py` | `Playlist`, `PlaylistTracks`, `PlaylistTrack` | Import from `user.py` |
| `models/user.py` | `LoginResponse`, `User` | — |
| `models/__init__.py` | Re-export all public model types | Define any models directly |
| `config.py` | `Settings`, `get_settings()` | Make HTTP calls, import `client.py` or `server.py` |
| `client.py` | All 18 HTTP methods, auth, stream signing; returns typed models | String formatting, MCP imports, config loading |
| `formatters.py` | `format_*()` pure functions: model → string | HTTP calls, importing `client.py`, MCP imports |
| `server.py` | `FastMCP` instance, lifespan, 18 `@mcp.tool` functions, `main()` | HTTP logic, formatting logic, model definitions |
| `__init__.py` | `__version__` string | Any imports that trigger side effects |
| `__main__.py` | `main()` entry point, `asyncio.run()` if needed | Business logic |

---

## Key Architectural Patterns

### Lifespan (server.py)

```python
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

import httpx
from fastmcp import FastMCP

from qobuz_mcp.client import QobuzClient
from qobuz_mcp.config import get_settings


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Initialize and tear down the shared Qobuz API client."""
    settings = get_settings()
    async with httpx.AsyncClient(base_url=BASE_URL) as http:
        client = await QobuzClient.create(
            app_id=settings.app_id,
            app_secret=settings.app_secret,
            username=settings.username,
            password=settings.password.get_secret_value(),
            http_client=http,
        )
        yield {"qobuz": client}


mcp = FastMCP("qobuz", lifespan=lifespan)
```

### Tool pattern (server.py)

```python
from fastmcp import Context

from qobuz_mcp.exceptions import QobuzAuthError, QobuzError, QobuzNotFoundError
from qobuz_mcp.formatters import format_track


@mcp.tool
async def get_track(track_id: str, ctx: Context) -> str:
    """Get detailed information about a track by its Qobuz ID.

    Args:
        track_id: The Qobuz track ID (numeric string).
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted string with title, artist, album, duration, quality, and ISRC.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        track = await client.get_track(track_id)
    except QobuzNotFoundError:
        return f"Track '{track_id}' was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzError as exc:
        return f"Error retrieving track: {exc}"
    return format_track(track)
```

### HTTP helper pattern (client.py)

```python
async def _get(self, path: str, **params: object) -> dict[str, object]:
    """Send a GET request and return the parsed JSON body.

    Args:
        path: API path relative to BASE_URL (e.g. "/track/get").
        **params: Query parameters merged with base auth params.

    Returns:
        Parsed JSON response as a plain dict.

    Raises:
        QobuzAuthError: On HTTP 401.
        QobuzNotFoundError: On HTTP 404.
        QobuzRateLimitError: On HTTP 429.
        QobuzAPIError: On any other non-2xx status.
    """
    response = await self._http.get(
        path, params={**self._base_params(), **params}
    )
    self._raise_for_status(response)
    return response.json()  # type: ignore[no-any-return]
```

### Formatter pattern (formatters.py)

```python
def format_track(track: Track) -> str:
    """Format a Track model as a human-readable string.

    Args:
        track: A populated Track model instance.

    Returns:
        Multi-line string suitable for returning from an MCP tool.
    """
    lines = [
        f"Track: {track.title}",
        f"Artist: {track.performer.name if track.performer else 'Unknown'}",
        f"Album: {track.album.title if track.album else 'Unknown'}",
        f"Duration: {format_duration(track.duration)}",
        f"Quality: {format_quality(track.bit_depth, track.sampling_rate)}",
    ]
    if track.isrc:
        lines.append(f"ISRC: {track.isrc}")
    lines.append(f"Track ID: {track.id}")
    return "\n".join(lines)
```
