# qobuz-mcp

Connect your [Qobuz](https://www.qobuz.com) account to Claude. Search music, manage playlists, browse your favorites, and get streaming URLs — all through conversation.

## Requirements

- An active Qobuz paid subscription (email/password login — Google OAuth accounts are not supported)
- [uv](https://github.com/astral-sh/uv) installed

## Installation

Add this to your Claude Desktop config file:

- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
- **Linux:** `~/.config/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "qobuz": {
      "command": "uvx",
      "args": ["qobuz-mcp"],
      "env": {
        "QOBUZ_APP_ID": "798273057",
        "QOBUZ_APP_SECRET": "abb21364945c0583309667d13ca3d93a",
        "QOBUZ_USERNAME": "your@email.com",
        "QOBUZ_PASSWORD": "your_password"
      }
    }
  }
}
```

Restart Claude Desktop and you're ready to go.

> **Note:** The `app_id` and `app_secret` above are extracted from Qobuz's own web player and are provided here for convenience. If they stop working, up-to-date values can be found in open-source clients such as [streamrip](https://github.com/nathom/streamrip).

## What you can do

Once connected, just talk to Claude naturally.

### Search & browse

- *"Search for albums by Radiohead"*
- *"Find the track 'Pyramids' by Frank Ocean"*
- *"Show me the tracklist for OK Computer"*
- *"Tell me about the artist Nils Frahm — how many albums does he have?"*
- *"Show me all studio albums by Nick Cave"*

### Discovery

- *"What are Qobuz's new releases this week?"*
- *"Show me the best-selling albums right now"*
- *"What are the editor's picks in jazz?"*
- *"List all available genres"*
- *"Show me press award winners in classical music"*

### Favorites

- *"Show my favorite tracks"*
- *"Add OK Computer to my favorite albums"*
- *"Like the artist Floating Points"*
- *"Remove this track from my favorites"*
- *"What albums have I saved?"*

### Playlists

- *"Show all my playlists"*
- *"Create a playlist called 'Late Night' with a description"*
- *"Add these three tracks to my Morning Run playlist"*
- *"Show me what's in my Workout playlist"*
- *"Rename my playlist to 'Road Trip'"*
- *"Remove the second track from this playlist"*
- *"Delete my old playlist"*

### Streaming

- *"Get me a streaming URL for this track in Hi-Res"*
- *"Give me a CD-quality link for that song"*

> **Note:** Streaming URLs are time-limited and expire after a few minutes. Hi-Res formats (24-bit) require a Qobuz Hi-Res subscription — ask for CD quality if you're on a standard plan.

## License

MIT — see [LICENSE](LICENSE).
