from __future__ import annotations

import re
from datetime import UTC, datetime

from qobuz_mcp.models.album import Album, AlbumTracklist
from qobuz_mcp.models.artist import Artist, ArtistAlbums
from qobuz_mcp.models.common import Genre
from qobuz_mcp.models.playlist import Playlist, PlaylistTracks, UserPlaylists
from qobuz_mcp.models.track import Track, TrackFileUrl

# ------------------------------------------------------------------
# Shared helpers
# ------------------------------------------------------------------


def format_duration(seconds: int) -> str:
    """Format a duration in seconds to a human-readable string.

    Args:
        seconds: Duration in seconds.

    Returns:
        String in M:SS or H:MM:SS format.
    """
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


def format_quality(bit_depth: int | None, sampling_rate: float | None) -> str:
    """Format audio quality parameters as a readable label.

    Args:
        bit_depth: Bit depth (e.g. 16, 24).
        sampling_rate: Sampling rate in kHz (e.g. 44.1, 96.0).

    Returns:
        Human-readable quality string, or 'Unknown' if data is absent.
    """
    if bit_depth is None or sampling_rate is None:
        return "Unknown"
    if bit_depth > 16 or sampling_rate > 44.1:
        return f"Hi-Res {bit_depth}-bit / {sampling_rate:g} kHz"
    return f"CD {bit_depth}-bit / {sampling_rate:g} kHz"


def _strip_html(text: str) -> str:
    """Remove HTML tags from a string.

    Args:
        text: Raw string potentially containing HTML.

    Returns:
        Plain text with tags removed.
    """
    return re.sub(r"<[^>]+>", "", text)


def _release_year(released_at: int | None) -> str:
    """Convert a Unix timestamp to a year string.

    Args:
        released_at: Unix timestamp, or None.

    Returns:
        Four-digit year string, or empty string if timestamp is absent.
    """
    if released_at is None:
        return ""
    return str(datetime.fromtimestamp(released_at, tz=UTC).year)


# ------------------------------------------------------------------
# Track
# ------------------------------------------------------------------


def format_track(track: Track) -> str:
    """Format a Track model as a human-readable string.

    Args:
        track: A populated Track model instance.

    Returns:
        Multi-line string with title, artist, album, duration, quality, and ID.
    """
    performer = track.performer.name if track.performer else "Unknown"
    album = track.album.title if track.album else "Unknown"
    lines = [
        f"Track: {track.title}",
        f"Artist: {performer}",
        f"Album: {album}",
        f"Duration: {format_duration(track.duration)}",
        f"Quality: {format_quality(track.bit_depth, track.sampling_rate)}",
    ]
    if track.isrc:
        lines.append(f"ISRC: {track.isrc}")
    lines.append(f"Track ID: {track.id}")
    return "\n".join(lines)


def format_track_url(url_info: TrackFileUrl) -> str:
    """Format streaming URL info as a human-readable string.

    Args:
        url_info: A TrackFileUrl model instance.

    Returns:
        Multi-line string with URL, format ID, and quality if available.
    """
    lines = [
        f"Stream URL: {url_info.url}",
        f"Format ID: {url_info.format_id}",
    ]
    if url_info.mime_type:
        lines.append(f"MIME type: {url_info.mime_type}")
    lines.append(
        f"Quality: {format_quality(url_info.bit_depth, url_info.sampling_rate)}"
    )
    return "\n".join(lines)


# ------------------------------------------------------------------
# Album
# ------------------------------------------------------------------


def format_album(album: AlbumTracklist) -> str:
    """Format an AlbumTracklist model as a human-readable string.

    Args:
        album: A populated AlbumTracklist model instance.

    Returns:
        Multi-line string with album metadata and full tracklist.
    """
    artist = album.artist.name if album.artist else "Unknown"
    quality = format_quality(album.maximum_bit_depth, album.maximum_sampling_rate)
    lines = [
        f"Album: {album.title}",
        f"Artist: {artist}",
        f"Label: {album.label.name if album.label else 'Unknown'}",
        f"Genre: {album.genre.name if album.genre else 'Unknown'}",
        f"Released: {_release_year(album.released_at) or 'Unknown'}",
        f"Duration: {format_duration(album.duration)}",
        f"Tracks: {album.tracks_count}",
        f"Quality: {quality}",
        f"Album ID: {album.id}",
    ]
    if album.description:
        desc = _strip_html(album.description)[:300]
        lines.append(f"\nDescription: {desc}")
    if album.tracks and album.tracks.items:
        lines.append("\nTracklist:")
        for track in album.tracks.items:
            lines.append(
                f"  {track.track_number:2d}. {track.title}"
                f" ({format_duration(track.duration)}) [ID: {track.id}]"
            )
    return "\n".join(lines)


def format_featured_albums(albums: list[Album]) -> str:
    """Format a list of featured albums as a human-readable string.

    Args:
        albums: List of Album model instances.

    Returns:
        Multi-line string listing album titles, artists, and IDs.
    """
    if not albums:
        return "No featured albums found."
    lines = [f"Featured Albums ({len(albums)}):"]
    for album in albums:
        artist = album.artist.name if album.artist else "Unknown"
        year = _release_year(album.released_at)
        suffix = f" ({year})" if year else ""
        lines.append(f"  • {album.title}{suffix} — {artist} [ID: {album.id}]")
    return "\n".join(lines)


# ------------------------------------------------------------------
# Artist
# ------------------------------------------------------------------


def format_artist(artist: Artist) -> str:
    """Format an Artist model as a human-readable string.

    Args:
        artist: A populated Artist model instance.

    Returns:
        Multi-line string with artist name, album count, and biography excerpt.
    """
    lines = [
        f"Artist: {artist.name}",
        f"Albums: {artist.albums_count}",
        f"Artist ID: {artist.id}",
    ]
    if artist.biography and artist.biography.content:
        bio = _strip_html(artist.biography.content)[:500]
        lines.append(f"\nBiography:\n{bio}")
    return "\n".join(lines)


def format_artist_albums(albums: ArtistAlbums) -> str:
    """Format a paginated artist album listing as a human-readable string.

    Args:
        albums: An ArtistAlbums model instance.

    Returns:
        Multi-line string listing album titles, years, and IDs.
    """
    lines = [f"Albums ({albums.total} total, showing {len(albums.items)}):"]
    for album in albums.items:
        year = _release_year(album.released_at)
        suffix = f" ({year})" if year else ""
        lines.append(f"  • {album.title}{suffix} [ID: {album.id}]")
    return "\n".join(lines)


# ------------------------------------------------------------------
# Discovery
# ------------------------------------------------------------------


def format_genres(genres: list[Genre]) -> str:
    """Format a list of genres as a human-readable string.

    Args:
        genres: List of Genre model instances.

    Returns:
        Multi-line string listing genre names and IDs.
    """
    if not genres:
        return "No genres found."
    lines = ["Genres:"]
    for genre in genres:
        lines.append(f"  • {genre.name} [ID: {genre.id}]")
    return "\n".join(lines)


# ------------------------------------------------------------------
# Search & Favorites  (raw dict input — items may be any type)
# ------------------------------------------------------------------


def _format_raw_track(raw: dict[str, object]) -> str:
    """Format a raw track dict from a search or favorites response.

    Args:
        raw: Raw track dict from the API.

    Returns:
        Single-line formatted string.
    """
    track = Track.model_validate(raw)
    performer = track.performer.name if track.performer else "Unknown"
    album = track.album.title if track.album else "Unknown"
    return f"  • {track.title} — {performer} [{album}] [ID: {track.id}]"


def _format_raw_album(raw: dict[str, object]) -> str:
    """Format a raw album dict from a search or favorites response.

    Args:
        raw: Raw album dict from the API.

    Returns:
        Single-line formatted string.
    """
    album = Album.model_validate(raw)
    artist = album.artist.name if album.artist else "Unknown"
    year = _release_year(album.released_at)
    suffix = f" ({year})" if year else ""
    return f"  • {album.title}{suffix} — {artist} [ID: {album.id}]"


def _format_raw_artist(raw: dict[str, object]) -> str:
    """Format a raw artist dict from a search or favorites response.

    Args:
        raw: Raw artist dict from the API.

    Returns:
        Single-line formatted string.
    """
    artist = Artist.model_validate(raw)
    return f"  • {artist.name} [ID: {artist.id}]"


def _format_raw_playlist(raw: dict[str, object]) -> str:
    """Format a raw playlist dict from a search response.

    Args:
        raw: Raw playlist dict from the API.

    Returns:
        Single-line formatted string.
    """
    pl = Playlist.model_validate(raw)
    owner = pl.owner.name if pl.owner else "Unknown"
    return f"  • {pl.name} by {owner} ({pl.tracks_count} tracks) [ID: {pl.id}]"


_FORMATTERS = {
    "tracks": _format_raw_track,
    "albums": _format_raw_album,
    "artists": _format_raw_artist,
    "playlists": _format_raw_playlist,
}


def format_search_results(data: dict[str, object], result_type: str) -> str:
    """Format a raw catalog search response as a human-readable string.

    Args:
        data: Raw API response dict from the search endpoint.
        result_type: The searched type — tracks, albums, artists, or playlists.

    Returns:
        Multi-line string listing matching items with IDs.
    """
    type_data = data.get(result_type)
    if not isinstance(type_data, dict):
        return f"No {result_type} found."
    items: list[object] = type_data.get("items", [])
    total = type_data.get("total", 0)
    if not items:
        return f"No {result_type} found for this search."
    fmt = _FORMATTERS.get(result_type)
    lines = [f"Search results — {result_type} ({total} total, showing {len(items)}):"]
    for raw in items:
        if not isinstance(raw, dict):
            continue
        if fmt:
            lines.append(fmt(raw))
    return "\n".join(lines)


def format_favorites(data: dict[str, object], item_type: str) -> str:
    """Format a raw favorites response as a human-readable string.

    Args:
        data: Raw API response dict from the favorites endpoint.
        item_type: The favorites type — tracks, albums, or artists.

    Returns:
        Multi-line string listing favorited items with IDs.
    """
    type_data = data.get(item_type)
    if not isinstance(type_data, dict):
        return f"No favorite {item_type} found."
    items: list[object] = type_data.get("items", [])
    total = type_data.get("total", 0)
    if not items:
        return f"You have no favorite {item_type}."
    fmt = _FORMATTERS.get(item_type)
    lines = [f"Favorite {item_type} ({total} total, showing {len(items)}):"]
    for raw in items:
        if not isinstance(raw, dict):
            continue
        if fmt:
            lines.append(fmt(raw))
    return "\n".join(lines)


# ------------------------------------------------------------------
# Playlists
# ------------------------------------------------------------------


def format_playlists(playlists: UserPlaylists) -> str:
    """Format a paginated list of user playlists as a human-readable string.

    Args:
        playlists: A UserPlaylists model instance.

    Returns:
        Multi-line string listing playlist names, track counts, and IDs.
    """
    if not playlists.items:
        return "You have no playlists."
    lines = [f"Playlists ({playlists.total} total, showing {len(playlists.items)}):"]
    for pl in playlists.items:
        visibility = "public" if pl.is_public else "private"
        lines.append(
            f"  • {pl.name} ({pl.tracks_count} tracks, {visibility}) [ID: {pl.id}]"
        )
    return "\n".join(lines)


def format_playlist(playlist: PlaylistTracks) -> str:
    """Format a PlaylistTracks model as a human-readable string.

    Args:
        playlist: A populated PlaylistTracks model instance.

    Returns:
        Multi-line string with playlist metadata and full track listing.
    """
    visibility = "public" if playlist.is_public else "private"
    lines = [
        f"Playlist: {playlist.name}",
        f"Tracks: {playlist.tracks_count}",
        f"Visibility: {visibility}",
        f"Playlist ID: {playlist.id}",
    ]
    if playlist.description:
        lines.append(f"Description: {playlist.description}")
    if playlist.tracks and playlist.tracks.items:
        lines.append("\nTracks:")
        for i, track in enumerate(playlist.tracks.items, 1):
            ptid = str(track.playlist_track_id) if track.playlist_track_id else "N/A"
            lines.append(
                f"  {i:3d}. {track.title}"
                f" [Track ID: {track.id}, Playlist Track ID: {ptid}]"
            )
    return "\n".join(lines)
