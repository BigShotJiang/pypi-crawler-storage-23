from __future__ import annotations

from qobuz_mcp.server import main

if __name__ == "__main__":
    main()
