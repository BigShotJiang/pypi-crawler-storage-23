from __future__ import annotations

from pydantic import Field

from qobuz_mcp.models.common import Page, QobuzModel


class PlaylistOwner(QobuzModel):
    """Playlist owner info."""

    id: int
    name: str


class PlaylistTrack(QobuzModel):
    """A track entry within a playlist."""

    id: int
    title: str = ""
    duration: int = 0
    # Qobuz returns this field in snake_case; used when removing tracks
    playlist_track_id: int | None = Field(default=None, alias="playlist_track_id")


class Playlist(QobuzModel):
    """A Qobuz user playlist."""

    id: int
    name: str
    description: str | None = None
    is_public: bool = False
    is_collaborative: bool = False
    tracks_count: int = 0
    owner: PlaylistOwner | None = None
    image_rectangle: list[str] = []


class PlaylistTracks(Playlist):
    """Playlist with its full track listing."""

    tracks: Page[PlaylistTrack] | None = None


class UserPlaylists(Page[Playlist]):
    """Paginated list of user playlists."""
