from __future__ import annotations

from qobuz_mcp.models.common import Genre, Image, Page, QobuzModel
from qobuz_mcp.models.track import Track


class ArtistSummary(QobuzModel):
    """Minimal artist info embedded in an album response."""

    id: int
    name: str


class Label(QobuzModel):
    """Record label."""

    id: int
    name: str


class Album(QobuzModel):
    """A Qobuz album."""

    id: str
    title: str
    artist: ArtistSummary | None = None
    image: Image | None = None
    label: Label | None = None
    genre: Genre | None = None
    released_at: int | None = None
    tracks_count: int = 0
    duration: int = 0
    maximum_bit_depth: int | None = None
    maximum_sampling_rate: float | None = None
    parental_warning: bool = False
    description: str | None = None


class AlbumTracklist(Album):
    """Album with its full track listing."""

    tracks: Page[Track] | None = None
