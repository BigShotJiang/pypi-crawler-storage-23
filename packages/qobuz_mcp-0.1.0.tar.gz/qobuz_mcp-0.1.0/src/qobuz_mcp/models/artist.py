from __future__ import annotations

from qobuz_mcp.models.album import Album
from qobuz_mcp.models.common import Image, Page, QobuzModel


class Biography(QobuzModel):
    """Artist biography text."""

    content: str | None = None
    language: str | None = None


class ArtistAlbums(Page[Album]):
    """Paginated artist album listing."""


class Artist(QobuzModel):
    """A Qobuz artist."""

    id: int
    name: str
    image: Image | None = None
    biography: Biography | None = None
    albums_count: int = 0
    slug: str | None = None
