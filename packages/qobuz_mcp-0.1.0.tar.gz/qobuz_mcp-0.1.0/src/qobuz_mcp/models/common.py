from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel

T = TypeVar("T")


class QobuzModel(BaseModel):
    """Base model for all Qobuz API response objects."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        extra="ignore",
    )


class Image(QobuzModel):
    """Cover art URL set for an album or artist."""

    small: str | None = None
    thumbnail: str | None = None
    large: str | None = None
    back: str | None = None


class Genre(QobuzModel):
    """Music genre."""

    id: int
    name: str
    slug: str | None = None
    color: str | None = None


class Page(QobuzModel, Generic[T]):
    """A paginated API response wrapping a list of items."""

    items: list[T] = []
    total: int = 0
    limit: int = 0
    offset: int = 0
