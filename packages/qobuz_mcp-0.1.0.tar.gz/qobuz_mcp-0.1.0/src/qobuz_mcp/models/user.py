from __future__ import annotations

from pydantic import Field

from qobuz_mcp.models.common import QobuzModel


class User(QobuzModel):
    """Qobuz user account."""

    id: int
    login: str
    display_name: str | None = None


class LoginResponse(QobuzModel):
    """Response payload from /user/login."""

    # Qobuz returns this field in snake_case, not camelCase
    user_auth_token: str = Field(alias="user_auth_token")
    user: User | None = None
