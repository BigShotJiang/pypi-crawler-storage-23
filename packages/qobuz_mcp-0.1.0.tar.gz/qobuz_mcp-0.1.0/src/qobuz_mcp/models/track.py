from __future__ import annotations

from qobuz_mcp.models.common import Image, QobuzModel


class Performer(QobuzModel):
    """Track performer (primary artist credit)."""

    id: int
    name: str


class AlbumSummary(QobuzModel):
    """Minimal album info embedded in a track response."""

    id: str
    title: str
    image: Image | None = None


class Track(QobuzModel):
    """A Qobuz track."""

    id: int
    title: str
    duration: int = 0
    track_number: int = 0
    isrc: str | None = None
    performer: Performer | None = None
    album: AlbumSummary | None = None
    bit_depth: int | None = None
    sampling_rate: float | None = None
    parental_warning: bool = False
    copyright: str | None = None


class TrackFileUrl(QobuzModel):
    """Streaming URL details for a track."""

    url: str
    format_id: int
    mime_type: str | None = None
    sampling_rate: float | None = None
    bit_depth: int | None = None
