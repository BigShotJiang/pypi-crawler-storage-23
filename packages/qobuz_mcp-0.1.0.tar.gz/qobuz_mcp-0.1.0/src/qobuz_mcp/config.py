from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables or a .env file."""

    app_id: str
    app_secret: str
    username: str
    password: SecretStr

    model_config = SettingsConfigDict(
        env_prefix="QOBUZ_",
        env_file=Path(__file__).parent.parent.parent / ".env",
        env_file_encoding="utf-8",
    )


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached application settings.

    Returns:
        A Settings instance populated from environment variables.
    """
    return Settings()  # type: ignore[call-arg]
