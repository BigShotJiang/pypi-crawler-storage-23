from __future__ import annotations

import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any, Literal

import httpx
from mcp.server.fastmcp import Context, FastMCP

from qobuz_mcp.client import BASE_URL, QobuzClient
from qobuz_mcp.config import get_settings
from qobuz_mcp.exceptions import (
    QobuzAuthError,
    QobuzError,
    QobuzNotFoundError,
    QobuzRateLimitError,
)
from qobuz_mcp.formatters import (
    format_album,
    format_artist,
    format_artist_albums,
    format_favorites,
    format_featured_albums,
    format_genres,
    format_playlist,
    format_playlists,
    format_search_results,
    format_track,
    format_track_url,
)

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict[str, Any]]:
    """Initialize and tear down the shared Qobuz API client.

    Args:
        server: The FastMCP server instance (unused but required by the protocol).

    Yields:
        A context dict with key "qobuz" holding the authenticated QobuzClient.
    """
    settings = get_settings()
    async with httpx.AsyncClient(base_url=BASE_URL) as http:
        client = await QobuzClient.create(
            app_id=settings.app_id,
            app_secret=settings.app_secret,
            username=settings.username,
            password=settings.password.get_secret_value(),
            http_client=http,
        )
        logger.info("Qobuz MCP server started.")
        yield {"qobuz": client}
    logger.info("Qobuz MCP server stopped.")


mcp = FastMCP("qobuz", lifespan=lifespan)


# ------------------------------------------------------------------
# Search
# ------------------------------------------------------------------


@mcp.tool()
async def search(
    query: str,
    ctx: Context,
    result_type: Literal["tracks", "albums", "artists", "playlists"] = "tracks",
    limit: int = 20,
    offset: int = 0,
) -> str:
    """Search the Qobuz catalog for tracks, albums, artists, or playlists.

    Args:
        query: Search terms (artist name, album title, song title, etc.).
        ctx: FastMCP context providing the shared Qobuz client.
        result_type: What to search — "tracks", "albums", "artists", or "playlists".
        limit: Maximum number of results (default 20).
        offset: Pagination offset for retrieving additional pages.

    Returns:
        Formatted list of matching results with IDs for follow-up lookups.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        data = await client.search(
            query, result_type=result_type, limit=limit, offset=offset
        )
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Search error: {exc}"
    return format_search_results(data, result_type)


# ------------------------------------------------------------------
# Catalog
# ------------------------------------------------------------------


@mcp.tool()
async def get_track(track_id: int, ctx: Context) -> str:
    """Get detailed information about a track by its Qobuz track ID.

    Args:
        track_id: The Qobuz track ID (numeric).
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted string with title, artist, album, duration, quality, and ISRC.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        track = await client.get_track(track_id)
    except QobuzNotFoundError:
        return f"Track {track_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving track: {exc}"
    return format_track(track)


@mcp.tool()
async def get_album(album_id: str, ctx: Context) -> str:
    """Get detailed information about an album including its full tracklist.

    Args:
        album_id: The Qobuz album ID (alphanumeric string).
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted string with album metadata and numbered tracklist with track IDs.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        album = await client.get_album(album_id)
    except QobuzNotFoundError:
        return f"Album '{album_id}' was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving album: {exc}"
    return format_album(album)


@mcp.tool()
async def get_artist(artist_id: int, ctx: Context) -> str:
    """Get information about an artist including their biography.

    Args:
        artist_id: The Qobuz artist ID (numeric).
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted string with artist name, album count, and biography excerpt.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        artist = await client.get_artist(artist_id)
    except QobuzNotFoundError:
        return f"Artist {artist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving artist: {exc}"
    return format_artist(artist)


@mcp.tool()
async def get_artist_albums(
    artist_id: int,
    ctx: Context,
    limit: int = 20,
    offset: int = 0,
) -> str:
    """Get a paginated list of albums for an artist.

    Args:
        artist_id: The Qobuz artist ID (numeric).
        ctx: FastMCP context providing the shared Qobuz client.
        limit: Maximum number of albums to return (default 20).
        offset: Pagination offset for retrieving additional pages.

    Returns:
        Formatted list of albums with release years and album IDs.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        albums = await client.get_artist_albums(artist_id, limit=limit, offset=offset)
    except QobuzNotFoundError:
        return f"Artist {artist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving artist albums: {exc}"
    return format_artist_albums(albums)


# ------------------------------------------------------------------
# Discovery
# ------------------------------------------------------------------


@mcp.tool()
async def get_featured_albums(
    ctx: Context,
    category: Literal[
        "new-releases-full",
        "press-awards",
        "editor-picks",
        "most-streamed",
        "best-sellers",
    ] = "new-releases-full",
    genre_id: int | None = None,
    limit: int = 20,
    offset: int = 0,
) -> str:
    """Get editorial / featured albums from Qobuz.

    Args:
        ctx: FastMCP context providing the shared Qobuz client.
        category: Editorial category — "new-releases-full", "press-awards",
            "editor-picks", "most-streamed", or "best-sellers".
        genre_id: Optional genre ID to filter results (use get_genres to list IDs).
        limit: Maximum number of albums to return (default 20).
        offset: Pagination offset.

    Returns:
        Formatted list of featured albums with artists and album IDs.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        albums = await client.get_featured_albums(
            category=category, genre_id=genre_id, limit=limit, offset=offset
        )
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving featured albums: {exc}"
    return format_featured_albums(albums)


@mcp.tool()
async def get_genres(ctx: Context) -> str:
    """Get the full list of Qobuz music genres.

    Args:
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted list of genre names and their IDs for use in other tools.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        genres = await client.get_genres()
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving genres: {exc}"
    return format_genres(genres)


# ------------------------------------------------------------------
# Streaming
# ------------------------------------------------------------------


@mcp.tool()
async def get_track_url(
    track_id: int,
    ctx: Context,
    format_id: int = 27,
) -> str:
    """Get a time-limited streaming URL for a track.

    Args:
        track_id: The Qobuz track ID (numeric).
        ctx: FastMCP context providing the shared Qobuz client.
        format_id: Audio format — 5 (MP3 320kbps), 6 (CD 16-bit/44.1kHz),
            7 (Hi-Res 24-bit/96kHz), 27 (Hi-Res 24-bit/192kHz). Defaults to 27.

    Returns:
        Formatted string with the streaming URL, format, and quality details.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        url_info = await client.get_track_url(track_id, format_id=format_id)
    except QobuzNotFoundError:
        return f"Track {track_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving stream URL: {exc}"
    return format_track_url(url_info)


# ------------------------------------------------------------------
# Favorites
# ------------------------------------------------------------------


@mcp.tool()
async def get_favorites(
    ctx: Context,
    item_type: Literal["tracks", "albums", "artists"] = "tracks",
    limit: int = 50,
    offset: int = 0,
) -> str:
    """Get the user's favorited tracks, albums, or artists.

    Args:
        ctx: FastMCP context providing the shared Qobuz client.
        item_type: Favorites type — "tracks", "albums", or "artists".
        limit: Maximum number of results (default 50).
        offset: Pagination offset.

    Returns:
        Formatted list of favorited items with IDs.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        data = await client.get_favorites(
            item_type=item_type, limit=limit, offset=offset
        )
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving favorites: {exc}"
    return format_favorites(data, item_type)


@mcp.tool()
async def add_favorite(
    item_type: Literal["tracks", "albums", "artists"], item_id: str, ctx: Context
) -> str:
    """Add a track, album, or artist to the user's favorites.

    Args:
        item_type: The item type — "tracks", "albums", or "artists".
        item_id: The Qobuz ID of the item to like. Track IDs are numeric strings;
            album IDs may be alphanumeric (e.g. "0060254732627").
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        await client.add_favorite(item_type, item_id)
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error adding favorite: {exc}"
    return f"Added {item_type.rstrip('s')} {item_id} to your favorites."


@mcp.tool()
async def remove_favorite(
    item_type: Literal["tracks", "albums", "artists"], item_id: str, ctx: Context
) -> str:
    """Remove a track, album, or artist from the user's favorites.

    Args:
        item_type: The item type — "tracks", "albums", or "artists".
        item_id: The Qobuz ID of the item to unlike. Track IDs are numeric strings;
            album IDs may be alphanumeric (e.g. "0060254732627").
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        await client.remove_favorite(item_type, item_id)
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error removing favorite: {exc}"
    return f"Removed {item_type.rstrip('s')} {item_id} from your favorites."


# ------------------------------------------------------------------
# Playlists
# ------------------------------------------------------------------


@mcp.tool()
async def get_user_playlists(
    ctx: Context,
    limit: int = 20,
    offset: int = 0,
) -> str:
    """List the user's Qobuz playlists.

    Args:
        ctx: FastMCP context providing the shared Qobuz client.
        limit: Maximum number of playlists to return (default 20).
        offset: Pagination offset.

    Returns:
        Formatted list of playlists with names, track counts, visibility, and IDs.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        playlists = await client.get_user_playlists(limit=limit, offset=offset)
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving playlists: {exc}"
    return format_playlists(playlists)


@mcp.tool()
async def get_playlist(playlist_id: int, ctx: Context) -> str:
    """Get detailed information about a playlist including its full track listing.

    Args:
        playlist_id: The Qobuz playlist ID.
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Formatted string with playlist metadata and all tracks with both their
        Track ID and Playlist Track ID (needed for removal).
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        playlist = await client.get_playlist(playlist_id)
    except QobuzNotFoundError:
        return f"Playlist {playlist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error retrieving playlist: {exc}"
    return format_playlist(playlist)


@mcp.tool()
async def create_playlist(
    name: str,
    ctx: Context,
    description: str = "",
    is_public: bool = False,
) -> str:
    """Create a new Qobuz playlist.

    Args:
        name: Playlist name.
        ctx: FastMCP context providing the shared Qobuz client.
        description: Optional playlist description.
        is_public: Whether the playlist should be publicly visible (default False).

    Returns:
        Confirmation message with the new playlist ID, or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        playlist = await client.create_playlist(
            name, description=description, is_public=is_public
        )
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error creating playlist: {exc}"
    return f"Playlist '{playlist.name}' created. Playlist ID: {playlist.id}"


@mcp.tool()
async def update_playlist(
    playlist_id: int,
    ctx: Context,
    name: str | None = None,
    description: str | None = None,
    is_public: bool | None = None,
) -> str:
    """Update an existing playlist's name, description, or visibility.

    Args:
        playlist_id: The Qobuz playlist ID to update.
        ctx: FastMCP context providing the shared Qobuz client.
        name: New name, or omit to leave unchanged.
        description: New description, or omit to leave unchanged.
        is_public: New visibility setting, or omit to leave unchanged.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        playlist = await client.update_playlist(
            playlist_id, name=name, description=description, is_public=is_public
        )
    except QobuzNotFoundError:
        return f"Playlist {playlist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error updating playlist: {exc}"
    return f"Playlist '{playlist.name}' (ID: {playlist.id}) updated successfully."


@mcp.tool()
async def delete_playlist(playlist_id: int, ctx: Context) -> str:
    """Permanently delete a playlist.

    Args:
        playlist_id: The Qobuz playlist ID to delete.
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        await client.delete_playlist(playlist_id)
    except QobuzNotFoundError:
        return f"Playlist {playlist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error deleting playlist: {exc}"
    return f"Playlist {playlist_id} deleted."


@mcp.tool()
async def add_tracks_to_playlist(
    playlist_id: int,
    track_ids: list[int],
    ctx: Context,
) -> str:
    """Add one or more tracks to a playlist.

    Args:
        playlist_id: The Qobuz playlist ID.
        track_ids: List of Qobuz track IDs to add (use search or get_album to find IDs).
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        await client.add_tracks_to_playlist(playlist_id, track_ids)
    except QobuzNotFoundError:
        return f"Playlist {playlist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error adding tracks: {exc}"
    count = len(track_ids)
    return f"Added {count} track{'s' if count != 1 else ''} to playlist {playlist_id}."


@mcp.tool()
async def remove_tracks_from_playlist(
    playlist_id: int,
    playlist_track_ids: list[int],
    ctx: Context,
) -> str:
    """Remove one or more tracks from a playlist using their Playlist Track IDs.

    Use get_playlist() first to see each track's Playlist Track ID — this is
    different from the regular Track ID and is specific to this playlist.

    Args:
        playlist_id: The Qobuz playlist ID.
        playlist_track_ids: List of Playlist Track IDs to remove.
            These are shown in get_playlist() output as "Playlist Track ID".
        ctx: FastMCP context providing the shared Qobuz client.

    Returns:
        Confirmation message or an error description.
    """
    client: QobuzClient = ctx.request_context.lifespan_context["qobuz"]
    try:
        await client.remove_tracks_from_playlist(playlist_id, playlist_track_ids)
    except QobuzNotFoundError:
        return f"Playlist {playlist_id} was not found."
    except QobuzAuthError:
        return "Authentication failed. Check your Qobuz credentials."
    except QobuzRateLimitError:
        return "Qobuz rate limit reached. Please wait a moment and try again."
    except QobuzError as exc:
        return f"Error removing tracks: {exc}"
    count = len(playlist_track_ids)
    return (
        f"Removed {count} track{'s' if count != 1 else ''} from playlist {playlist_id}."
    )


# ------------------------------------------------------------------
# Entry point
# ------------------------------------------------------------------


def main() -> None:
    """Start the Qobuz MCP server on stdio transport."""
    logging.basicConfig(level=logging.INFO)
    mcp.run()
