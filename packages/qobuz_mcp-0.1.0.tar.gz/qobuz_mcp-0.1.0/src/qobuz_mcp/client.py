from __future__ import annotations

import hashlib
import logging
import time

import httpx
from pydantic import ValidationError

from qobuz_mcp.exceptions import (
    QobuzAPIError,
    QobuzAuthError,
    QobuzNotFoundError,
    QobuzRateLimitError,
)
from qobuz_mcp.models.album import Album, AlbumTracklist
from qobuz_mcp.models.artist import Artist, ArtistAlbums
from qobuz_mcp.models.common import Genre
from qobuz_mcp.models.playlist import Playlist, PlaylistTracks, UserPlaylists
from qobuz_mcp.models.track import Track, TrackFileUrl
from qobuz_mcp.models.user import LoginResponse

logger = logging.getLogger(__name__)

BASE_URL = "https://www.qobuz.com/api.json/0.2"


class QobuzClient:
    """HTTP client for the Qobuz API.

    Attributes:
        _app_id: Qobuz application ID.
        _app_secret: Application secret used to sign stream URL requests.
        _user_auth_token: Session token obtained after login.
        _http: Shared async HTTP client.
    """

    def __init__(
        self,
        app_id: str,
        app_secret: str,
        user_auth_token: str,
        http_client: httpx.AsyncClient,
    ) -> None:
        self._app_id = app_id
        self._app_secret = app_secret
        self._user_auth_token = user_auth_token
        self._http = http_client

    @classmethod
    async def create(
        cls,
        app_id: str,
        app_secret: str,
        username: str,
        password: str,
        http_client: httpx.AsyncClient,
    ) -> QobuzClient:
        """Authenticate with Qobuz and return a configured client instance.

        Args:
            app_id: Qobuz application ID.
            app_secret: Application secret for stream URL signing.
            username: Qobuz account email.
            password: Qobuz account password.
            http_client: Pre-configured async HTTP client.

        Returns:
            An authenticated QobuzClient ready to make API calls.

        Raises:
            QobuzAuthError: If credentials are invalid or no token is returned.
            QobuzAPIError: If the login request fails for any other reason.
        """
        response = await http_client.post(
            "/user/login",
            params={"app_id": app_id},
            data={"username": username, "password": password},
        )
        if response.status_code == 401:
            raise QobuzAuthError("Invalid Qobuz credentials.")
        if not response.is_success:
            raise QobuzAPIError(response.status_code, response.text)

        try:
            login = LoginResponse.model_validate(response.json())
        except ValidationError as exc:
            raise QobuzAuthError("No auth token in login response.") from exc
        if not login.user_auth_token:
            raise QobuzAuthError("No auth token in login response.")

        logger.info("Qobuz login successful for %s", username)
        return cls(
            app_id=app_id,
            app_secret=app_secret,
            user_auth_token=login.user_auth_token,
            http_client=http_client,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _base_params(self) -> dict[str, str]:
        """Return query parameters included in every authenticated request.

        Returns:
            Dict containing app_id and user_auth_token.
        """
        return {
            "app_id": self._app_id,
            "user_auth_token": self._user_auth_token,
        }

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Map HTTP error codes to typed exceptions.

        Args:
            response: The httpx response to inspect.

        Raises:
            QobuzAuthError: On HTTP 401.
            QobuzNotFoundError: On HTTP 404.
            QobuzRateLimitError: On HTTP 429.
            QobuzAPIError: On any other non-2xx status.
        """
        if response.is_success:
            return
        if response.status_code == 401:
            raise QobuzAuthError(response.text)
        if response.status_code == 404:
            raise QobuzNotFoundError(404, response.text)
        if response.status_code == 429:
            raise QobuzRateLimitError(429, response.text)
        raise QobuzAPIError(response.status_code, response.text)

    async def _get(self, path: str, **params: object) -> dict[str, object]:
        """Send a GET request and return the parsed JSON body.

        Args:
            path: API path relative to BASE_URL (e.g. "/track/get").
            **params: Query parameters merged with base auth params.

        Returns:
            Parsed JSON response as a plain dict.

        Raises:
            QobuzAuthError: On HTTP 401.
            QobuzNotFoundError: On HTTP 404.
            QobuzRateLimitError: On HTTP 429.
            QobuzAPIError: On any other non-2xx status.
        """
        clean = {k: str(v) for k, v in params.items() if v is not None}
        logger.debug("GET %s params=%s", path, list(clean.keys()))
        response = await self._http.get(path, params={**self._base_params(), **clean})
        self._raise_for_status(response)
        return response.json()  # type: ignore[no-any-return]

    async def _post(self, path: str, **data: object) -> dict[str, object]:
        """Send a POST request with form-encoded data and return the parsed JSON body.

        Args:
            path: API path relative to BASE_URL.
            **data: Form fields merged into the request body.

        Returns:
            Parsed JSON response as a plain dict.

        Raises:
            QobuzAuthError: On HTTP 401.
            QobuzNotFoundError: On HTTP 404.
            QobuzRateLimitError: On HTTP 429.
            QobuzAPIError: On any other non-2xx status.
        """
        clean = {k: str(v) for k, v in data.items() if v is not None}
        logger.debug("POST %s fields=%s", path, list(clean.keys()))
        response = await self._http.post(
            path,
            params=self._base_params(),
            data=clean,
        )
        self._raise_for_status(response)
        return response.json()  # type: ignore[no-any-return]

    def _sign_stream_request(self, track_id: int, format_id: int) -> dict[str, str]:
        """Generate signed parameters required for a track stream URL request.

        Args:
            track_id: Qobuz track ID.
            format_id: Audio format ID (5=MP3, 6=CD, 7=Hi-Res 96kHz, 27=Hi-Res 192kHz).

        Returns:
            Dict with request_ts, request_sig, and intent keys.
        """
        ts = str(int(time.time()))
        sig_str = (
            f"trackgetFileUrlformat_id{format_id}"
            f"intentstreamtrack_id{track_id}{ts}{self._app_secret}"
        )
        sig = hashlib.md5(sig_str.encode()).hexdigest()
        return {"request_ts": ts, "request_sig": sig, "intent": "stream"}

    # ------------------------------------------------------------------
    # Catalog
    # ------------------------------------------------------------------

    async def search(
        self,
        query: str,
        result_type: str = "tracks",
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, object]:
        """Search the Qobuz catalog.

        Args:
            query: Search terms.
            result_type: Result type — one of tracks, albums, artists, playlists.
            limit: Maximum number of results to return.
            offset: Pagination offset.

        Returns:
            Raw API response dict containing the result list under the result_type key.
        """
        return await self._get(
            "/catalog/search",
            query=query,
            type=result_type,
            limit=limit,
            offset=offset,
        )

    async def get_track(self, track_id: int) -> Track:
        """Fetch a single track by its Qobuz ID.

        Args:
            track_id: The unique Qobuz track identifier.

        Returns:
            A fully populated Track model instance.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If no track with the given ID exists.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        data = await self._get("/track/get", track_id=track_id)
        return Track.model_validate(data)

    async def get_album(self, album_id: str) -> AlbumTracklist:
        """Fetch an album with its full track listing.

        Args:
            album_id: The unique Qobuz album identifier.

        Returns:
            An AlbumTracklist model with metadata and all tracks.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If no album with the given ID exists.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        data = await self._get("/album/get", album_id=album_id)
        return AlbumTracklist.model_validate(data)

    async def get_artist(self, artist_id: int) -> Artist:
        """Fetch artist info including biography.

        Args:
            artist_id: The unique Qobuz artist identifier.

        Returns:
            An Artist model with biography.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If no artist with the given ID exists.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        data = await self._get(
            "/artist/get",
            artist_id=artist_id,
            extra="biographies",
        )
        return Artist.model_validate(data)

    async def get_artist_albums(
        self,
        artist_id: int,
        limit: int = 20,
        offset: int = 0,
    ) -> ArtistAlbums:
        """Fetch a paginated list of albums for an artist.

        Args:
            artist_id: The unique Qobuz artist identifier.
            limit: Maximum number of albums to return.
            offset: Pagination offset.

        Returns:
            An ArtistAlbums model with items, total, limit, and offset.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If no artist with the given ID exists.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        data = await self._get(
            "/artist/get",
            artist_id=artist_id,
            extra="albums",
            albums_limit=limit,
            albums_offset=offset,
        )
        raw_albums = data.get("albums", {})
        return ArtistAlbums.model_validate(raw_albums)

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    async def get_featured_albums(
        self,
        category: str = "new-releases-full",
        genre_id: int | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[Album]:
        """Fetch editorial / featured albums.

        Args:
            category: Editorial category — e.g. new-releases-full, press-awards,
                editor-picks, most-streamed, best-sellers.
            genre_id: Optional genre filter.
            limit: Maximum number of albums to return.
            offset: Pagination offset.

        Returns:
            List of Album models.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        params: dict[str, object] = {"type": category, "limit": limit, "offset": offset}
        if genre_id is not None:
            params["genre_id"] = genre_id
        data = await self._get("/album/getFeatured", **params)
        albums_data = data.get("albums", {})
        items: list[object] = (
            albums_data.get("items", []) if isinstance(albums_data, dict) else []
        )
        return [Album.model_validate(item) for item in items]

    async def get_genres(self) -> list[Genre]:
        """Fetch the full list of Qobuz music genres.

        Returns:
            List of Genre models sorted by the API.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        data = await self._get("/genre/list")
        genres_data = data.get("genres", {})
        items: list[object] = (
            genres_data.get("items", []) if isinstance(genres_data, dict) else []
        )
        return [Genre.model_validate(item) for item in items]

    # ------------------------------------------------------------------
    # Streaming
    # ------------------------------------------------------------------

    async def get_track_url(self, track_id: int, format_id: int = 27) -> TrackFileUrl:
        """Fetch a time-limited streaming URL for a track.

        Args:
            track_id: The Qobuz track ID.
            format_id: Audio format — 5 (MP3 320), 6 (CD), 7 (Hi-Res 96kHz),
                27 (Hi-Res 192kHz). Defaults to 27.

        Returns:
            A TrackFileUrl model containing the streaming URL and format details.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If the track does not exist.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        sign_params = self._sign_stream_request(track_id, format_id)
        data = await self._get(
            "/track/getFileUrl",
            track_id=track_id,
            format_id=format_id,
            **sign_params,
        )
        return TrackFileUrl.model_validate(data)

    # ------------------------------------------------------------------
    # Favorites
    # ------------------------------------------------------------------

    async def get_favorites(
        self,
        item_type: str = "tracks",
        limit: int = 50,
        offset: int = 0,
    ) -> dict[str, object]:
        """Fetch the user's favorited items of a given type.

        Args:
            item_type: One of tracks, albums, or artists.
            limit: Maximum number of results to return.
            offset: Pagination offset.

        Returns:
            Raw API response dict; results are under the key matching item_type.
        """
        return await self._get(
            "/favorite/getUserFavorites",
            type=item_type,
            limit=limit,
            offset=offset,
        )

    async def add_favorite(self, item_type: str, item_id: int | str) -> None:
        """Add an item to the user's favorites.

        Args:
            item_type: One of tracks, albums, or artists.
            item_id: The Qobuz ID of the item to like.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        # Qobuz expects e.g. "track_ids", "album_ids", "artist_ids"
        param_key = f"{item_type.rstrip('s')}_ids"
        await self._post("/favorite/create", **{param_key: item_id})

    async def remove_favorite(self, item_type: str, item_id: int | str) -> None:
        """Remove an item from the user's favorites.

        Args:
            item_type: One of tracks, albums, or artists.
            item_id: The Qobuz ID of the item to unlike.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        param_key = f"{item_type.rstrip('s')}_ids"
        await self._post("/favorite/delete", **{param_key: item_id})

    # ------------------------------------------------------------------
    # Playlists
    # ------------------------------------------------------------------

    async def get_user_playlists(
        self,
        limit: int = 20,
        offset: int = 0,
    ) -> UserPlaylists:
        """Fetch the user's playlists.

        Args:
            limit: Maximum number of playlists to return.
            offset: Pagination offset.

        Returns:
            Paginated UserPlaylists model with items, total, limit, and offset.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        data = await self._get(
            "/playlist/getUserPlaylists",
            limit=limit,
            offset=offset,
        )
        playlists_data = data.get("playlists", {})
        if not isinstance(playlists_data, dict):
            playlists_data = {}
        return UserPlaylists.model_validate(playlists_data)

    async def get_playlist(self, playlist_id: int) -> PlaylistTracks:
        """Fetch a playlist with its full track listing.

        Args:
            playlist_id: The Qobuz playlist ID.

        Returns:
            A PlaylistTracks model with metadata and all tracks.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If the playlist does not exist.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        data = await self._get(
            "/playlist/get",
            playlist_id=playlist_id,
            extra="tracks",
        )
        return PlaylistTracks.model_validate(data)

    async def create_playlist(
        self,
        name: str,
        description: str = "",
        is_public: bool = False,
    ) -> Playlist:
        """Create a new playlist.

        Args:
            name: Playlist name.
            description: Optional playlist description.
            is_public: Whether the playlist is publicly visible.

        Returns:
            The newly created Playlist model.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        data = await self._post(
            "/playlist/create",
            name=name,
            description=description,
            is_public=int(is_public),
        )
        return Playlist.model_validate(data)

    async def update_playlist(
        self,
        playlist_id: int,
        name: str | None = None,
        description: str | None = None,
        is_public: bool | None = None,
    ) -> Playlist:
        """Update an existing playlist's metadata.

        Args:
            playlist_id: The Qobuz playlist ID to update.
            name: New name, or None to leave unchanged.
            description: New description, or None to leave unchanged.
            is_public: New visibility setting, or None to leave unchanged.

        Returns:
            The updated Playlist model.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If the playlist does not exist.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        params: dict[str, object] = {"playlist_id": playlist_id}
        if name is not None:
            params["name"] = name
        if description is not None:
            params["description"] = description
        if is_public is not None:
            params["is_public"] = int(is_public)
        data = await self._post("/playlist/update", **params)
        return Playlist.model_validate(data)

    async def delete_playlist(self, playlist_id: int) -> None:
        """Permanently delete a playlist.

        Args:
            playlist_id: The Qobuz playlist ID to delete.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzNotFoundError: If the playlist does not exist.
            QobuzAPIError: If the API returns any other non-2xx status.
        """
        await self._post("/playlist/delete", playlist_id=playlist_id)

    async def add_tracks_to_playlist(
        self,
        playlist_id: int,
        track_ids: list[int],
    ) -> None:
        """Add one or more tracks to a playlist.

        Args:
            playlist_id: The target playlist ID.
            track_ids: List of Qobuz track IDs to add.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        await self._post(
            "/playlist/addTracks",
            playlist_id=playlist_id,
            track_ids=",".join(str(t) for t in track_ids),
        )

    async def remove_tracks_from_playlist(
        self,
        playlist_id: int,
        playlist_track_ids: list[int],
    ) -> None:
        """Remove one or more tracks from a playlist by their playlist-track IDs.

        Args:
            playlist_id: The target playlist ID.
            playlist_track_ids: List of playlist-track IDs (not regular track IDs).
                Retrieve these from get_playlist() — each track's playlist_track_id.

        Raises:
            QobuzAuthError: If the auth token is missing or expired.
            QobuzAPIError: If the API returns a non-2xx status.
        """
        await self._post(
            "/playlist/deleteTracks",
            playlist_id=playlist_id,
            track_ids=",".join(str(t) for t in playlist_track_ids),
        )
