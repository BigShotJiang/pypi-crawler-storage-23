from __future__ import annotations


class QobuzError(Exception):
    """Base exception for all Qobuz API errors."""


class QobuzAuthError(QobuzError):
    """Raised on HTTP 401 or when the auth token is missing or expired."""


class QobuzAPIError(QobuzError):
    """Raised on any non-2xx API response."""

    def __init__(self, status_code: int, message: str) -> None:
        self.status_code = status_code
        super().__init__(f"HTTP {status_code}: {message}")


class QobuzNotFoundError(QobuzAPIError):
    """Raised on HTTP 404."""


class QobuzRateLimitError(QobuzAPIError):
    """Raised on HTTP 429."""
