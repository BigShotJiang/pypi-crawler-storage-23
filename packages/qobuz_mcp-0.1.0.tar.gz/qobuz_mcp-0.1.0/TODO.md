# TODO

## Before publishing to PyPI

- [ ] Publish package to PyPI (`uv publish`) so `uvx qobuz-mcp` works for end users
- [ ] Implement automatic credential fetching from Qobuz's web bundle at startup — `app_id` from `production.api.appId` and the signing secret derived from `atob(seed+info+extras)` for the production timezone (berlin). This way users never need to supply or update these manually (same approach as streamrip's `QobuzSpoofer`)
- [ ] Add support or a clear error message for Google OAuth accounts (currently unsupported — the Qobuz API has no OAuth flow)
