# iterion

> Description TBD.

## Setup

```bash
uv sync
```

## Development

```bash
uv run pytest tests/
```
