import iterion


def test_version_exists():
    assert hasattr(iterion, "__version__")
    assert isinstance(iterion.__version__, str)
