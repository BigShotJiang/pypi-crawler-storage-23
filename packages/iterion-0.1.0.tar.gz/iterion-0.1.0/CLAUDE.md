# CLAUDE.md

## Project Overview

`iterion` — Python package for iterative, agentic model selection on tabular data. A rules-based engine that inspects data, fits candidate models, evaluates against thresholds, and iteratively refines — documenting every decision with reasoning, confidence, and alternatives. Designed for external orchestration: Claude Code drives the loop via the StageRunner, reading interim results and making refinement decisions.

Published to PyPI as `iterion`.

## Architecture

Pipeline-of-Stages with an optimization loop:

```
AnalysisPrompt → Inspector → Modeler → Evaluator → Advisor → [loop or terminate] → AnalysisReport
```

- **Inspector**: Automated EDA (missing values, outliers, distributions, correlations)
- **Modeler**: Registry-based model fitting (OLS, RLM, Ridge, GBR, RF, etc.)
- **Evaluator**: Score models, compare against thresholds, track improvement
- **Advisor**: Deterministic rule engine. Rules handle known statistical patterns (VIF, heteroscedasticity, etc.)
- **Orchestrator**: Loop controller with configurable auto-approve (for programmatic use)
- **StageRunner**: Stage-by-stage executor with file I/O. Each stage writes JSON + markdown. External agent (Claude Code) drives the iteration loop.

## Setup & Commands

```bash
uv sync
uv run pytest tests/
```

## Key Conventions

- Pydantic v2 for all contracts (not dataclasses)
- structlog for logging, never print()
- Type hints on all function signatures
- Tests: pytest, synthetic data with seeded RNG
- `@register_model` decorator for pluggable models
- Every agent decision logged as a `Decision` model with: what, why, evidence, confidence, alternatives, references, source

## Directory Structure

```
src/iterion/        # Package source
tests/              # pytest test suite
docs/plans/         # Design and implementation plans
docs/features/      # Feature documentation (one per feature/batch)
```

## Development Workflow Rules

1. **Everything must be tested.** Every new feature, bug fix, or behavior change needs pytest coverage. Tests use synthetic data with seeded RNG. No untested code ships.
2. **Feature documentation is mandatory.** After every plan is implemented, create a feature markdown in `docs/features/` named `YYYY-MM-DD-<slug>.md`. Document: what changed, why, files touched, tests added, open items.
3. **Commits follow `<type>: <description>` format.** Types: `feat fix refactor docs test chore`.
