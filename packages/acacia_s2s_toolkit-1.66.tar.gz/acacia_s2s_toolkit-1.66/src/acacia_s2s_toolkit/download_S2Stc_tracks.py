# script that can downloaded forecasted S2S TC tracks
import xarray as xr
import numpy as np
import pandas as pd
import ftplib
import os
import huracanpy as hpy
from acacia_s2s_toolkit import argument_output

def load_fc_tracks(model,fcdate):
    # load in data
    session = ftplib.FTP('aux.ecmwf.int')
    session.login(user='s2sidx',passwd='s2sidx')
    session.cwd("TCYC")
    
    # create filepath
    mn = model.lower().strip() # model name
    yy = fcdate[:4] # year component
    mm = fcdate[4:6] # month component
    TC_fn = f"TC.{fcdate}"
    
    filepath = f"{mn}/real-time/{yy}/{mm}/{TC_fn}" # creates full filename
    local_filename = TC_fn
    
    # retrieve the full year file
    with open(local_filename,'wb') as f:
        session.retrbinary(f"RETR {filepath}", f.write)
    
    print(f"File '{filepath}' has been downloaded.")
    
    session.quit()
    return local_filename

def download_forecast_TCtracks(fcdate,model,origin_id,leadtime_hour,filename_save): 
    '''
    need to do something with leadtime_hour parameter
    '''
    
    fn = load_fc_tracks(model,fcdate) # load in forecast TC track file from Frederic's FTP site
    
    # untar the file. will give all ensemble members. for ECMWF 101.
    os.system(f'tar -xf {fn}')
    
    short_name = origin_id  # need to get short name. add to look-up file
    num_ens_mems = argument_output.get_single_parameter(origin_id,fcdate,'fcNumEns')+1
    
    # loop through all basins
    basins = ['atl','aus','cnp','enp','nin','sin','spc','wnp']
    all_fcs = []
    
    for num in range(num_ens_mems):
        # untar first ens mem
        os.system(f'tar -xf {short_name}.{fcdate}.{num}')
        
        all_storms = []
        
        # loop through basins and read files
        for basin in basins:
            # open up single basin file
            with open(basin, "r") as f:
                lines = f.readlines()
        
            if len(lines) > 1:
                storms = hpy.load(basin,source='ecmwf')
                n = storms.sizes['record']
                # add dimension with basin
                storms = storms.assign_coords(basin=('record', np.repeat(basin, n)))
        
                all_storms.append(storms)
        
        # concatenate along the existing 'record' axis
        combined = xr.concat(
            all_storms,
            dim='record',
            join='outer',                       # allow variables that may be missing in some basins
            combine_attrs='drop_conflicts'      # avoid attribute conflicts
        )
        
        combined = combined.reset_coords('basin')
        
        # enforce a consistent variable ordering
        combined = combined[['track_id', 'time', 'lat', 'lon', 'wind', 'pres', 'lat_wind', 'lon_wind', 'basin']]
        n = combined.sizes['record']
        combined = combined.assign_coords(ens_mem=('record', np.repeat(num, n)))
    
        all_fcs.append(combined)
    
        # remove extracted file
        os.remove(f"{short_name}.{fcdate}.{num}")
    
    # concatenate along the existing 'record' axis
    combined_allens = xr.concat(
            all_fcs,
            dim='record',
            join='outer',                       # allow variables that may be missing in some basins
            combine_attrs='drop_conflicts'      # avoid attribute conflicts
        )
    
    combined_allens = combined_allens.reset_coords('ens_mem')
    combined_allens = combined_allens[['track_id', 'time', 'lat', 'lon', 'wind', 'pres', 'lat_wind', 'lon_wind', 'basin','ens_mem']]
    
    combined_allens = combined_allens.drop_vars(['lat_wind','lon_wind'])
    
    combined_allens.to_netcdf(f"{filename_save}.nc")
    
    print(f"downloaded TC tracks for {num_ens_mems} ensemble members for model {model} at fc_date {fcdate}. Saved as netcdf output under filename, {filename_save}")
    
    # then will need to remove basin files from last ensemble member
    for basin in basins:
        os.remove(f"{basin}")
    os.remove(f"{fn}") # plus remove original tar file downloaded
