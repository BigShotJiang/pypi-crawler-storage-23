# pylinux 🐧

> Build Linux distros in **pure Python** — compiled to C, linked into an ELF kernel, packaged as a bootable ISO.

```
pip install pylinux-sdk
pylux new my-distro
cd my-distro
pyinlux build
pylux run
```

---

## How it works

```
your Python source
      │
      ▼ (pylux.compiler — AST → C99)
  C source files
      │
      ▼ (gcc cross-compiler)
  .o object files
      │
      ▼ (ld + linker script)
  kernel.elf  (multiboot2, bare-metal)
      │
      ▼ (grub-mkrescue + xorriso)
  your-distro.iso  ← bootable!
      │
      ▼ (qemu-system-x86_64)
  🖥️  running in VM
```

---

## Commands

| Command | Description |
|---|---|
| `pylux new <n>` | Init project in `<name>/` |
| `pylux build` | Full build: Python → C → ELF → ISO |
| `pylux run` | Boot ISO in QEMU |
| `pylux debug` | QEMU + GDB stub on :1234 |
| `pylux compile` | Python → C only |
| `pylux check` | Syntax-check all sources |
| `pylux clean` | Remove build artifacts |
| `pylux clean --all` | Remove artifacts + cache |
| `pylux add <mod>` | Scaffold a new module/driver |
| `pylux info` | Toolchain & project info |
| `pylux config show` | Dump pylux.toml |
| `pylux config set vm.memory_mb 1024` | Edit a config value |
| `pylux log` | Tail latest build log |
| `pylux disasm` | objdump the kernel ELF |
| `pylux shell` | Cross-compile env shell |

---

## pylux directives

Inside your `.py` files, special comments control the compiler:

```python
# pylux: multiboot2          — emit multiboot2 header in this file
# pylux: arch=x86_64         — override target arch
# pylux: stack_size=131072   — set kernel stack size
# pylux: c_inline            — entire file: function bodies become C stubs
# pylux: no_stack_protector  — compile with -fno-stack-protector
# pylux: io_access           — allow I/O port intrinsics
# pylux: module_type=driver  — metadata tag

# inside a function body:
# pylux: asm("movq $0, %rax")
# pylux: c_inline("*(volatile uint32_t*)0xB8000 = 0x0F48;")
# pylux: register_irq(1, my_handler)
```

---

## Prerequisites

```bash
# Ubuntu / Debian
sudo apt install gcc nasm binutils grub-pc-bin xorriso qemu-system-x86

# Fedora / RHEL
sudo dnf install gcc nasm binutils grub2-tools xorriso qemu-system-x86

# Arch
sudo pacman -S gcc nasm binutils grub libisoburn qemu-system-x86
```

---

## Project layout (after `pylux new`)

```
my-distro/
├── pylux.toml              ← project config
├── src/
│   ├── kernel.py           ← kernel entry: kernel_main()
│   ├── boot.py             ← GDT / IDT / paging setup
│   ├── drivers/
│   │   ├── vga.py          ← VGA text-mode driver
│   │   ├── keyboard.py     ← PS/2 keyboard
│   │   └── timer.py        ← PIT 8254 timer
│   └── kstd/
│       ├── string.py       ← strlen, strcpy, itoa …
│       ├── memory.py       ← kmalloc / kfree
│       └── io.py           ← io_inb / io_outb
└── .pylux/
    ├── build/              ← generated C, .o files, kernel.elf, ISO
    ├── cache/
    └── logs/
```

---

## License

MIT
