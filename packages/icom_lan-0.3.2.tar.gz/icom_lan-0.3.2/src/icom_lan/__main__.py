"""Allow running as: python -m icom_lan"""
from .cli import main

main()
