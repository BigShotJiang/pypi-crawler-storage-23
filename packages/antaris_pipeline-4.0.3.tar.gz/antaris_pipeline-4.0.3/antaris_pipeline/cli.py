"""
Command Line Interface for Antaris Pipeline 2.0

Provides easy access to pipeline functions and telemetrics.
"""

import json
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import track

from . import Pipeline, create_config, ProfileType, TelemetricsCollector


console = Console()


@click.group()
@click.version_option()
def main():
    """Antaris Pipeline 2.0 - Unified AI Agent Infrastructure"""
    pass


@main.command()
@click.option("--profile", type=click.Choice([p.value for p in ProfileType]), 
              default="balanced", help="Configuration profile")
@click.option("--config", type=click.Path(exists=True), help="Config file path")
@click.option("--output", type=click.Path(), help="Save config to file")
def config(profile: str, config: Optional[str], output: Optional[str]):
    """Generate or validate pipeline configuration."""
    
    if config:
        # Load and validate existing config
        config_obj = create_config.from_file(config)
        console.print(f"✅ Configuration loaded from {config}")
    else:
        # Create new config from profile
        config_obj = create_config(ProfileType(profile))
        console.print(f"📋 Generated {profile} configuration")
    
    # Validate SLA requirements
    sla_validation = config_obj.validate_sla_requirements()
    
    table = Table(title="Configuration Validation")
    table.add_column("Requirement", style="cyan")
    table.add_column("Status", style="bold")
    
    for requirement, valid in sla_validation.items():
        status = "✅ PASS" if valid else "❌ FAIL"
        table.add_row(requirement.replace("_", " ").title(), status)
    
    console.print(table)
    
    if output:
        config_obj.to_file(output)
        console.print(f"💾 Configuration saved to {output}")
    else:
        console.print("\n📄 Configuration:")
        console.print(json.dumps(config_obj.model_dump(mode="json"), indent=2))


@main.command()
@click.argument("input_text")
@click.option("--config", type=click.Path(exists=True), help="Config file path")
@click.option("--profile", type=click.Choice([p.value for p in ProfileType]), 
              default="balanced", help="Configuration profile")
@click.option("--dry-run", is_flag=True, help="Show what would happen without API calls")
def process(input_text: str, config: Optional[str], profile: str, dry_run: bool):
    """Process input through the pipeline."""
    
    # Load configuration
    if config:
        config_obj = create_config.from_file(config)
    else:
        config_obj = create_config(ProfileType(profile))
    
    # Create pipeline
    # NOTE: This is a simplified version - real implementation would need
    # actual package instances
    console.print("🚀 Initializing pipeline...")
    
    if dry_run:
        # Simulate pipeline execution
        console.print("\n🔍 Dry-run simulation:")
        
        simulation = {
            "input": {"text": input_text, "length": len(input_text)},
            "guard_input": {"would_allow": True, "scan_time_ms": 15},
            "memory": {"would_retrieve": 3, "retrieval_time_ms": 45},
            "context": {"would_optimize": True, "context_length": len(input_text) + 1200},
            "router": {
                "would_select": "claude-sonnet-4-20250514",
                "confidence": 0.85,
                "estimated_cost": 0.024
            },
            "guard_output": {"would_scan": True, "scan_time_ms": 12},
            "total_estimated_time_ms": 150
        }
        
        console.print(Panel(
            json.dumps(simulation, indent=2),
            title="Pipeline Dry-Run Results",
            border_style="green"
        ))
        
    else:
        console.print("❌ Full pipeline processing requires package instances")
        console.print("💡 Use --dry-run to see what would happen")


@main.group()
def telemetrics():
    """Analyze and query telemetrics data.

    \b
    Subcommands:
      summary  — print statistics from a JSONL file
      replay   — list all events from a JSONL file
      query    — filter events from a JSONL file

    \b
    Examples:
      antaris-pipeline telemetrics summary telemetrics/telemetrics_abc123.jsonl
      antaris-pipeline telemetrics replay  telemetrics/telemetrics_abc123.jsonl
      antaris-pipeline telemetrics query   telemetrics/telemetrics_abc123.jsonl --module guard
      antaris-pipeline telemetrics query   telemetrics/telemetrics_abc123.jsonl --since 3600
    """
    pass


@telemetrics.command("summary")
@click.argument("jsonl_file", type=click.Path(exists=True))
def telemetrics_summary(jsonl_file: str):
    """Print a human-readable summary of a telemetrics JSONL file."""
    import uuid as _uuid

    collector = TelemetricsCollector(
        session_id=str(_uuid.uuid4()),
        output_dir="/tmp/antaris_tel_cli",
    )

    # Replay events from file into collector
    events = collector.replay_events(jsonl_file)
    if not events:
        console.print("[yellow]⚠️  No events found in file.[/yellow]")
        return

    for ev in events:
        collector.collect_event(ev)

    summary_data = collector.get_summary()

    console.print(f"\n[bold cyan]📊 Telemetrics Summary[/bold cyan]")
    console.print(f"  Session:      {summary_data.get('session_id', 'n/a')}")
    console.print(f"  Total events: {summary_data['total_events']}")

    # Events by module
    if summary_data.get("events_by_module"):
        table = Table(title="Events by Module")
        table.add_column("Module", style="cyan")
        table.add_column("Count", justify="right", style="bold")
        for module, count in sorted(summary_data["events_by_module"].items()):
            table.add_row(module, str(count))
        console.print(table)

    # Performance
    perf = summary_data.get("performance", {})
    console.print(f"\n[bold]⚡ Performance[/bold]")
    console.print(f"  Avg latency: {perf.get('avg_latency_ms', 0):.1f} ms")
    console.print(f"  Total cost:  ${perf.get('total_cost_usd', 0):.6f}")
    console.print(f"  Total tokens: {perf.get('total_tokens', 0):,}")

    # Security
    sec = summary_data.get("security", {})
    console.print(f"\n[bold]🔒 Security[/bold]")
    console.print(f"  Total scans: {sec.get('total_scans', 0)}")
    console.print(f"  Blocked:     {sec.get('blocks', 0)}")
    console.print(
        f"  Block rate:  {sec.get('block_rate', 0)*100:.1f}%"
    )


@telemetrics.command("replay")
@click.argument("jsonl_file", type=click.Path(exists=True))
@click.option("--limit", default=50, help="Max events to show (default 50)")
def telemetrics_replay(jsonl_file: str, limit: int):
    """List events stored in a telemetrics JSONL file."""
    import uuid as _uuid

    collector = TelemetricsCollector(
        session_id=str(_uuid.uuid4()),
        output_dir="/tmp/antaris_tel_cli",
    )
    events = collector.replay_events(jsonl_file)
    if not events:
        console.print("[yellow]⚠️  No events found in file.[/yellow]")
        return

    shown = events[:limit]
    table = Table(title=f"Events from {Path(jsonl_file).name} ({len(shown)}/{len(events)})")
    table.add_column("Timestamp", style="dim")
    table.add_column("Module", style="cyan")
    table.add_column("Event Type", style="green")
    table.add_column("Confidence", justify="right")
    table.add_column("Latency ms", justify="right")

    for ev in shown:
        ts = ev.timestamp.strftime("%H:%M:%S")
        conf = f"{ev.confidence:.2f}" if ev.confidence is not None else "-"
        lat = (
            f"{ev.performance.latency_ms:.1f}"
            if ev.performance and ev.performance.latency_ms is not None
            else "-"
        )
        table.add_row(ts, ev.module, ev.event_type.value, conf, lat)

    console.print(table)
    if len(events) > limit:
        console.print(
            f"[dim]... {len(events) - limit} more events. Use --limit to show more.[/dim]"
        )


@telemetrics.command("query")
@click.argument("jsonl_file", type=click.Path(exists=True))
@click.option("--module", default=None, help="Filter by module (e.g. guard, router)")
@click.option("--event-type", default=None, help="Filter by event type (e.g. guard.deny)")
@click.option("--since", "since_seconds", default=None, type=int, help="Only events in last N seconds")
@click.option("--limit", default=100, help="Max events to return (default 100)")
def telemetrics_query(
    jsonl_file: str,
    module: Optional[str],
    event_type: Optional[str],
    since_seconds: Optional[int],
    limit: int,
):
    """Query/filter events from a telemetrics JSONL file."""
    import uuid as _uuid

    collector = TelemetricsCollector(
        session_id=str(_uuid.uuid4()),
        output_dir="/tmp/antaris_tel_cli",
    )
    all_events = collector.replay_events(jsonl_file)
    if not all_events:
        console.print("[yellow]⚠️  No events found in file.[/yellow]")
        return

    # Load into collector then query
    for ev in all_events:
        collector.collect_event(ev)

    results = collector.query_events(
        module=module,
        event_type=event_type,
        since_seconds=since_seconds,
        limit=limit,
    )

    if not results:
        console.print("[yellow]No events matched the query.[/yellow]")
        return

    filters_applied = []
    if module:
        filters_applied.append(f"module={module}")
    if event_type:
        filters_applied.append(f"event_type={event_type}")
    if since_seconds:
        filters_applied.append(f"since={since_seconds}s")
    filter_str = ", ".join(filters_applied) if filters_applied else "none"

    table = Table(title=f"Query results ({len(results)} events) — filters: {filter_str}")
    table.add_column("Timestamp", style="dim")
    table.add_column("Module", style="cyan")
    table.add_column("Event Type", style="green")
    table.add_column("Confidence", justify="right")
    table.add_column("Payload preview", style="dim")

    for ev in results:
        ts = ev.timestamp.strftime("%H:%M:%S")
        conf = f"{ev.confidence:.2f}" if ev.confidence is not None else "-"
        preview = str(ev.payload)[:60] + ("…" if len(str(ev.payload)) > 60 else "")
        table.add_row(ts, ev.module, ev.event_type.value, conf, preview)

    console.print(table)


@main.command()
@click.option("--port", default=8080, help="Server port")
@click.option("--host", default="0.0.0.0", help="Server host")
@click.option("--session-id", help="Session ID for telemetrics")
def serve(port: int, host: str, session_id: Optional[str]):
    """Start telemetrics dashboard server."""
    
    session_id = session_id or f"cli_{int(__import__('time').time())}"
    
    console.print(f"🌐 Starting telemetrics server...")
    console.print(f"📊 Dashboard: http://{host}:{port}")
    console.print(f"🔍 Session ID: {session_id}")
    
    try:
        collector = TelemetricsCollector(session_id)
        from .telemetrics import TelemetricsServer
        
        server = TelemetricsServer(collector, port)
        server.start()
        
    except ImportError:
        console.print("❌ Telemetrics server requires: pip install antaris-pipeline[telemetrics]")
    except KeyboardInterrupt:
        console.print("\n👋 Server stopped")


@main.command()
def validate():
    """Validate pipeline installation and dependencies."""
    
    console.print("🔍 Validating Antaris Pipeline installation...")
    
    validation_results = []
    
    # Check core dependencies
    try:
        import antaris_memory
        validation_results.append(("antaris-memory", "✅ FOUND", f"v{antaris_memory.__version__}"))
    except ImportError as e:
        validation_results.append(("antaris-memory", "❌ MISSING", str(e)))
    
    try:
        import antaris_router
        validation_results.append(("antaris-router", "✅ FOUND", f"v{antaris_router.__version__}"))
    except ImportError as e:
        validation_results.append(("antaris-router", "❌ MISSING", str(e)))
    
    try:
        import antaris_guard
        validation_results.append(("antaris-guard", "✅ FOUND", f"v{antaris_guard.__version__}"))
    except ImportError as e:
        validation_results.append(("antaris-guard", "❌ MISSING", str(e)))
    
    try:
        import antaris_context
        validation_results.append(("antaris-context", "✅ FOUND", f"v{antaris_context.__version__}"))
    except ImportError as e:
        validation_results.append(("antaris-context", "❌ MISSING", str(e)))
    
    # Check optional dependencies
    try:
        import uvicorn, fastapi
        validation_results.append(("Telemetrics Server", "✅ AVAILABLE", "FastAPI + Uvicorn"))
    except ImportError:
        validation_results.append(("Telemetrics Server", "⚠️ OPTIONAL", "pip install antaris-pipeline[telemetrics]"))
    
    # Display results
    table = Table(title="Installation Validation")
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("Details", style="dim")
    
    for component, status, details in validation_results:
        table.add_row(component, status, details)
    
    console.print(table)
    
    # Check if all core packages are available
    missing_packages = [r for r in validation_results if "MISSING" in r[1]]
    
    if missing_packages:
        console.print("\n❌ Missing required packages. Install with:")
        console.print("pip install antaris-memory antaris-router antaris-guard antaris-context")
    else:
        console.print("\n✅ All core packages available!")
        console.print("🚀 Ready to create unified pipelines")


if __name__ == "__main__":
    main()