"""
Configuration management for Antaris Pipeline 2.0

Provides unified configuration across all 4 packages with validation.
"""

from pathlib import Path
from typing import Any, Dict, Optional, Union
from enum import Enum

import yaml
from pydantic import BaseModel, Field, field_validator


class ProfileType(str, Enum):
    """Predefined configuration profiles."""
    STRICT_SAFETY = "strict_safety"
    BALANCED = "balanced" 
    PERMISSIVE = "permissive"
    DEBUG = "debug"
    COST_OPTIMIZED = "cost_optimized"
    PERFORMANCE = "performance"


class MemoryConfig(BaseModel):
    """Configuration for antaris-memory."""
    
    storage_path: Path = Field(default=Path("./memory_store"))
    max_memory_mb: int = Field(default=1024, ge=100)
    consolidation_interval_hours: int = Field(default=24, ge=1)
    decay_half_life_hours: float = Field(default=168.0, ge=1.0)  # 1 week default
    
    # BM25 search configuration
    bm25_k1: float = Field(default=1.2, ge=0.0, le=3.0)
    bm25_b: float = Field(default=0.75, ge=0.0, le=1.0)
    
    # Context packet settings
    context_packet_max_tokens: int = Field(default=4000, ge=100)
    include_mistakes_by_default: bool = Field(default=True)
    
    # Performance settings
    enable_concurrent_access: bool = Field(default=True)
    max_concurrent_writes: int = Field(default=10, ge=1)
    # Bug fix: memory search timeout — falls back to empty results on slow disk I/O
    search_timeout_ms: int = Field(default=2000, ge=100, le=30000)


class RouterConfig(BaseModel):
    """Configuration for antaris-router."""
    
    default_model: str = Field(default="claude-sonnet-4-20250514")
    fallback_models: list[str] = Field(default_factory=lambda: ["claude-opus-4-6"])
    
    # Classification settings
    enable_semantic_classification: bool = Field(default=True)
    confidence_threshold: float = Field(default=0.7, ge=0.0, le=1.0)
    
    # Cost optimization
    cost_optimization_enabled: bool = Field(default=True)
    max_cost_per_request_usd: float = Field(default=1.0, ge=0.0)
    
    # Performance tracking
    track_model_performance: bool = Field(default=True)
    performance_window_hours: int = Field(default=24, ge=1)
    
    # Auto-fallback settings
    enable_auto_fallback: bool = Field(default=True)
    fallback_latency_threshold_ms: int = Field(default=30000, ge=1000)


class GuardConfig(BaseModel):
    """Configuration for antaris-guard."""
    
    # Security scanning
    enable_input_scanning: bool = Field(default=True)
    enable_output_scanning: bool = Field(default=True)
    enable_behavioral_analysis: bool = Field(default=True)
    
    # Policy settings
    default_policy_strictness: float = Field(default=0.7, ge=0.0, le=1.0)
    enable_policy_learning: bool = Field(default=True)
    
    # Pattern matching
    custom_patterns_path: Optional[Path] = None
    enable_unicode_normalization: bool = Field(default=True)
    
    # Audit and compliance
    audit_trail_enabled: bool = Field(default=True)
    audit_retention_days: int = Field(default=90, ge=1)
    
    # Performance settings
    max_scan_time_ms: int = Field(default=1000, ge=100)
    enable_pattern_caching: bool = Field(default=True)


class ContextConfig(BaseModel):
    """Configuration for antaris-context."""
    
    # Context window management
    default_max_tokens: int = Field(default=8000, ge=1000)
    enable_adaptive_budgeting: bool = Field(default=True)
    # Bug fix: model context windows are now configurable instead of hardcoded.
    # Override or extend this dict to support new models without a code change.
    model_context_limits: Dict[str, int] = Field(default_factory=lambda: {
        "claude-sonnet-4-20250514": 200000,
        "claude-sonnet-4-6": 200000,
        "claude-opus-4-6": 200000,
        "claude-haiku-3-5": 200000,
        "claude-haiku-4-5-20251001": 200000,
        "gpt-4o": 128000,
        "gpt-4o-mini": 128000,
        "gpt-4-turbo": 128000,
        "gemini-1.5-pro": 1000000,
        "gemini-1.5-flash": 1000000,
    })
    
    # Compression settings
    enable_compression: bool = Field(default=True)
    compression_ratio_target: float = Field(default=0.8, ge=0.1, le=1.0)
    min_section_tokens: int = Field(default=50, ge=10)
    
    # Priority settings
    enable_importance_scoring: bool = Field(default=True)
    conversation_context_weight: float = Field(default=0.8, ge=0.0, le=1.0)
    
    # Optimization
    enable_cross_turn_optimization: bool = Field(default=True)
    sliding_window_size: int = Field(default=10, ge=1)


class TelemetricsConfig(BaseModel):
    """Configuration for telemetrics system."""
    
    # Collection settings
    enable_telemetrics: bool = Field(default=True)
    buffer_size: int = Field(default=10000, ge=100)
    output_format: str = Field(default="jsonl", pattern="^(jsonl|json|csv)$")
    
    # Storage settings
    output_directory: Path = Field(default=Path("./telemetrics"))
    enable_file_output: bool = Field(default=True)
    enable_clickhouse: bool = Field(default=False)
    
    # Server settings
    enable_server: bool = Field(default=True)
    server_port: int = Field(default=8080, ge=1000, le=65535)
    server_host: str = Field(default="0.0.0.0")
    
    # Analytics settings
    enable_real_time_analytics: bool = Field(default=True)
    analytics_window_hours: int = Field(default=24, ge=1)


class PipelineConfig(BaseModel):
    """Unified configuration for Antaris Pipeline 2.0."""
    
    # Profile and metadata
    profile: ProfileType = Field(default=ProfileType.BALANCED)
    session_id: Optional[str] = None
    
    # Package configurations
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    router: RouterConfig = Field(default_factory=RouterConfig)
    guard: GuardConfig = Field(default_factory=GuardConfig)
    context: ContextConfig = Field(default_factory=ContextConfig)
    telemetrics: TelemetricsConfig = Field(default_factory=TelemetricsConfig)
    
    # Cross-package intelligence settings
    enable_cross_optimization: bool = Field(default=True)
    cross_optimization_aggressiveness: float = Field(default=0.5, ge=0.0, le=1.0)
    
    # Performance and reliability
    enable_dry_run_mode: bool = Field(default=False)
    enable_performance_slas: bool = Field(default=True)
    max_total_latency_ms: int = Field(default=5000, ge=100)
    
    # Error handling
    enable_graceful_degradation: bool = Field(default=True)
    max_retries: int = Field(default=3, ge=0)
    
    @field_validator('profile', mode='before')
    @classmethod
    def apply_profile_defaults(cls, v):
        """Apply profile-specific defaults."""
        # This will be called before other field validation
        return v
    
    def apply_profile(self) -> None:
        """Apply profile-specific settings after initialization."""
        
        if self.profile == ProfileType.STRICT_SAFETY:
            self._apply_strict_safety_profile()
        elif self.profile == ProfileType.PERMISSIVE:
            self._apply_permissive_profile()
        elif self.profile == ProfileType.DEBUG:
            self._apply_debug_profile()
        elif self.profile == ProfileType.COST_OPTIMIZED:
            self._apply_cost_optimized_profile()
        elif self.profile == ProfileType.PERFORMANCE:
            self._apply_performance_profile()
        # BALANCED is the default, no changes needed
    
    def _apply_strict_safety_profile(self) -> None:
        """Apply strict safety profile settings."""
        self.guard.default_policy_strictness = 0.9
        self.guard.enable_behavioral_analysis = True
        self.guard.max_scan_time_ms = 2000  # Allow more time for thorough scanning
        
        self.router.confidence_threshold = 0.8  # Require higher confidence
        self.router.enable_auto_fallback = True
        
        self.memory.include_mistakes_by_default = True
        
        self.context.compression_ratio_target = 0.9  # Less aggressive compression
    
    def _apply_permissive_profile(self) -> None:
        """Apply permissive profile settings."""
        self.guard.default_policy_strictness = 0.3
        self.guard.max_scan_time_ms = 500  # Faster, less thorough scanning
        
        self.router.confidence_threshold = 0.5  # Lower confidence threshold
        self.router.cost_optimization_enabled = True
        
        self.context.compression_ratio_target = 0.6  # More aggressive compression
    
    def _apply_debug_profile(self) -> None:
        """Apply debug profile settings."""
        self.enable_dry_run_mode = True
        self.telemetrics.enable_telemetrics = True
        self.telemetrics.enable_server = True
        self.telemetrics.enable_real_time_analytics = True
        
        # Enable all tracking and logging
        self.router.track_model_performance = True
        self.guard.audit_trail_enabled = True
        self.memory.enable_concurrent_access = False  # Simpler debugging
    
    def _apply_cost_optimized_profile(self) -> None:
        """Apply cost optimization profile."""
        self.router.cost_optimization_enabled = True
        self.router.max_cost_per_request_usd = 0.05  # Very aggressive cost limit
        
        self.context.enable_compression = True
        self.context.compression_ratio_target = 0.5  # Aggressive compression
        
        self.memory.decay_half_life_hours = 72.0  # Shorter memory retention
        self.memory.consolidation_interval_hours = 12  # More frequent cleanup
        
        self.guard.max_scan_time_ms = 300  # Faster scanning to reduce latency costs
    
    def _apply_performance_profile(self) -> None:
        """Apply performance-optimized profile."""
        self.max_total_latency_ms = 2000  # Strict latency requirements
        
        self.router.fallback_latency_threshold_ms = 5000
        self.guard.max_scan_time_ms = 500
        self.guard.enable_pattern_caching = True
        
        self.memory.max_concurrent_writes = 20  # Higher concurrency
        self.context.enable_adaptive_budgeting = True
        
        self.telemetrics.buffer_size = 1000  # Smaller buffer for performance
    
    @classmethod
    def from_file(cls, config_path: Union[str, Path]) -> "PipelineConfig":
        """Load configuration from YAML file."""
        
        config_path = Path(config_path)
        
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r') as f:
            config_data = yaml.safe_load(f)
        
        config = cls(**config_data)
        config.apply_profile()  # Apply profile-specific settings
        
        return config
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> "PipelineConfig":
        """Create configuration from dictionary."""
        config = cls(**config_dict)
        config.apply_profile()
        return config
    
    def to_file(self, config_path: Union[str, Path]) -> None:
        """Save configuration to YAML file."""
        
        config_path = Path(config_path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(config_path, 'w') as f:
            yaml.dump(self.model_dump(), f, default_flow_style=False, indent=2)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        return self.model_dump()
    
    def validate_sla_requirements(self) -> Dict[str, bool]:
        """Validate that configuration can meet SLA requirements."""
        
        validation_results = {
            "latency_achievable": True,
            "cost_achievable": True,
            "quality_achievable": True,
            "security_adequate": True
        }
        
        # Check latency feasibility
        estimated_latency = (
            self.guard.max_scan_time_ms * 2 +  # Input + output scanning
            100 +  # Memory retrieval estimate
            50 +   # Context building estimate
            30     # Router decision estimate
        )
        
        if estimated_latency > self.max_total_latency_ms:
            validation_results["latency_achievable"] = False
        
        # Check cost feasibility
        if (self.router.max_cost_per_request_usd < 0.01 and 
            self.router.default_model in ["claude-opus-4-6", "gpt-4"]):
            validation_results["cost_achievable"] = False
        
        # Check quality vs speed tradeoffs
        if (self.guard.max_scan_time_ms < 200 and 
            self.guard.default_policy_strictness > 0.8):
            validation_results["quality_achievable"] = False
        
        # Check security adequacy
        if (self.guard.default_policy_strictness < 0.5 and 
            not self.guard.enable_behavioral_analysis):
            validation_results["security_adequate"] = False
        
        return validation_results


# Profile presets for easy configuration
PROFILE_PRESETS = {
    ProfileType.STRICT_SAFETY: {
        "profile": ProfileType.STRICT_SAFETY,
        "guard": {"default_policy_strictness": 0.9},
        "router": {"confidence_threshold": 0.8}
    },
    ProfileType.COST_OPTIMIZED: {
        "profile": ProfileType.COST_OPTIMIZED,
        "router": {"max_cost_per_request_usd": 0.05},
        "context": {"compression_ratio_target": 0.5}
    },
    ProfileType.PERFORMANCE: {
        "profile": ProfileType.PERFORMANCE,
        "max_total_latency_ms": 2000,
        "guard": {"max_scan_time_ms": 500}
    }
}


def create_config(profile: ProfileType = ProfileType.BALANCED, **overrides) -> PipelineConfig:
    """
    Create a configuration with profile and overrides.
    
    Args:
        profile: Configuration profile to use
        **overrides: Override specific configuration values
        
    Returns:
        PipelineConfig instance
    """
    
    # Start with profile preset; always include the profile key so PipelineConfig.from_dict
    # sets the correct profile even for profiles that have no preset entry.
    base_config = dict(PROFILE_PRESETS.get(profile, {}))
    base_config["profile"] = profile  # ensure profile is always set

    # Apply overrides
    for key, value in overrides.items():
        if isinstance(value, dict) and key in base_config:
            base_config[key].update(value)
        else:
            base_config[key] = value
    
    config = PipelineConfig.from_dict(base_config)
    return config


# Export key classes and functions
__all__ = [
    "PipelineConfig",
    "MemoryConfig", 
    "RouterConfig",
    "GuardConfig",
    "ContextConfig",
    "TelemetricsConfig",
    "ProfileType",
    "PROFILE_PRESETS",
    "create_config"
]