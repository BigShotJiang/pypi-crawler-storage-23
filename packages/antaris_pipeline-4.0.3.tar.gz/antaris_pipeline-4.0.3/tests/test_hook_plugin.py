"""
Tests for HookPlugin ABC, register_plugin() / unregister_plugin(),
and ForgeMemoryPlugin (with optional dependencies absent).
"""

import pytest
from antaris_pipeline.hooks import (
    HookPlugin,
    PipelineHooks,
    HookPhase,
    HookContext,
    HookResult,
)
from antaris_pipeline.forge_plugin import ForgeMemoryPlugin


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class _ConcretePlugin(HookPlugin):
    """Minimal concrete plugin for lifecycle tests."""

    def __init__(self):
        self.installed = False
        self.uninstalled = False

    def install(self, hooks: PipelineHooks) -> None:
        self.installed = True
        hooks.register(HookPhase.SESSION_START, self._on_start, name="concrete.start")

    def uninstall(self, hooks: PipelineHooks) -> None:
        self.uninstalled = True
        hooks.unregister(HookPhase.SESSION_START, "concrete.start")

    def _on_start(self, ctx: HookContext) -> HookResult:
        return HookResult(success=True, data={"from": "concrete"})


class _MultiPhasePlugin(HookPlugin):
    """Plugin that touches every phase for thorough uninstall testing."""

    def install(self, hooks: PipelineHooks) -> None:
        hooks.register(HookPhase.SESSION_START, self._noop, name="multi.start")
        hooks.register(HookPhase.BEFORE_LLM, self._noop, name="multi.before_llm")
        hooks.register(HookPhase.SESSION_END, self._noop, name="multi.end")

    def uninstall(self, hooks: PipelineHooks) -> None:
        hooks.unregister(HookPhase.SESSION_START, "multi.start")
        hooks.unregister(HookPhase.BEFORE_LLM, "multi.before_llm")
        hooks.unregister(HookPhase.SESSION_END, "multi.end")

    def _noop(self, ctx: HookContext) -> HookResult:
        return HookResult()


# ---------------------------------------------------------------------------
# HookPlugin ABC
# ---------------------------------------------------------------------------

class TestHookPluginABC:
    def test_cannot_instantiate_directly(self):
        """HookPlugin is abstract; direct instantiation must fail."""
        with pytest.raises(TypeError):
            HookPlugin()  # type: ignore[abstract]

    def test_concrete_subclass_can_be_instantiated(self):
        plugin = _ConcretePlugin()
        assert plugin is not None

    def test_name_defaults_to_class_name(self):
        plugin = _ConcretePlugin()
        assert plugin.name == "_ConcretePlugin"

    def test_custom_name_via_override(self):
        class _Named(HookPlugin):
            @property
            def name(self) -> str:
                return "my-plugin"

            def install(self, hooks): ...

        assert _Named().name == "my-plugin"

    def test_uninstall_is_a_noop_by_default(self):
        """Calling uninstall on a plugin that doesn't override it must not raise."""
        class _Minimal(HookPlugin):
            def install(self, hooks): ...

        hooks = PipelineHooks()
        plugin = _Minimal()
        plugin.uninstall(hooks)  # should not raise


# ---------------------------------------------------------------------------
# register_plugin / unregister_plugin
# ---------------------------------------------------------------------------

class TestRegisterPlugin:
    def test_register_plugin_calls_install(self):
        plugin = _ConcretePlugin()
        hooks = PipelineHooks()

        assert not plugin.installed
        hooks.register_plugin(plugin)
        assert plugin.installed

    def test_unregister_plugin_calls_uninstall(self):
        plugin = _ConcretePlugin()
        hooks = PipelineHooks()
        hooks.register_plugin(plugin)

        assert not plugin.uninstalled
        hooks.unregister_plugin(plugin)
        assert plugin.uninstalled

    def test_registered_hook_is_callable(self):
        plugin = _ConcretePlugin()
        hooks = PipelineHooks()
        hooks.register_plugin(plugin)

        results = hooks.trigger_session_start(session_id="s1", agent_id="a1")
        assert len(results) == 1
        assert results[0].success
        assert results[0].data["from"] == "concrete"

    def test_unregister_removes_hook(self):
        plugin = _ConcretePlugin()
        hooks = PipelineHooks()
        hooks.register_plugin(plugin)
        hooks.unregister_plugin(plugin)

        results = hooks.trigger_session_start(session_id="s2", agent_id="a1")
        assert len(results) == 0

    def test_multiple_plugins_coexist(self):
        p1 = _ConcretePlugin()
        p2 = _MultiPhasePlugin()
        hooks = PipelineHooks()

        hooks.register_plugin(p1)
        hooks.register_plugin(p2)

        # SESSION_START has hooks from both plugins
        results = hooks.trigger_session_start(session_id="s3")
        assert len(results) == 2

    def test_unregister_one_leaves_other_intact(self):
        p1 = _ConcretePlugin()
        p2 = _MultiPhasePlugin()
        hooks = PipelineHooks()

        hooks.register_plugin(p1)
        hooks.register_plugin(p2)
        hooks.unregister_plugin(p1)

        results = hooks.trigger_session_start(session_id="s4")
        assert len(results) == 1  # only multi.start remains

    def test_register_plugin_with_multi_phase_plugin(self):
        plugin = _MultiPhasePlugin()
        hooks = PipelineHooks()
        hooks.register_plugin(plugin)

        listed = hooks.list_hooks()
        assert "multi.start" in listed[HookPhase.SESSION_START.value]
        assert "multi.before_llm" in listed[HookPhase.BEFORE_LLM.value]
        assert "multi.end" in listed[HookPhase.SESSION_END.value]

    def test_unregister_multi_phase_plugin_cleans_all_phases(self):
        plugin = _MultiPhasePlugin()
        hooks = PipelineHooks()
        hooks.register_plugin(plugin)
        hooks.unregister_plugin(plugin)

        listed = hooks.list_hooks()
        assert "multi.start" not in listed[HookPhase.SESSION_START.value]
        assert "multi.before_llm" not in listed[HookPhase.BEFORE_LLM.value]
        assert "multi.end" not in listed[HookPhase.SESSION_END.value]


# ---------------------------------------------------------------------------
# ForgeMemoryPlugin — loads cleanly without optional deps
# ---------------------------------------------------------------------------

class TestForgeMemoryPlugin:
    def test_instantiates_without_optional_deps(self):
        """ForgeMemoryPlugin must import and instantiate even without guard/memory."""
        plugin = ForgeMemoryPlugin()
        assert plugin is not None

    def test_name_is_forge_memory_plugin(self):
        plugin = ForgeMemoryPlugin()
        assert plugin.name == "ForgeMemoryPlugin"

    def test_install_registers_three_hooks(self):
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin(agent_id="test-agent")
        hooks.register_plugin(plugin)

        listed = hooks.list_hooks()
        assert "ForgeMemoryPlugin.session_start" in listed[HookPhase.SESSION_START.value]
        assert "ForgeMemoryPlugin.before_llm" in listed[HookPhase.BEFORE_LLM.value]
        assert "ForgeMemoryPlugin.session_end" in listed[HookPhase.SESSION_END.value]

    def test_uninstall_removes_all_hooks(self):
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin()
        hooks.register_plugin(plugin)
        hooks.unregister_plugin(plugin)

        listed = hooks.list_hooks()
        assert "ForgeMemoryPlugin.session_start" not in listed[HookPhase.SESSION_START.value]
        assert "ForgeMemoryPlugin.before_llm" not in listed[HookPhase.BEFORE_LLM.value]
        assert "ForgeMemoryPlugin.session_end" not in listed[HookPhase.SESSION_END.value]

    def test_session_start_returns_success_without_memory(self):
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin()
        hooks.register_plugin(plugin)

        results = hooks.trigger_session_start(session_id="forge-s1", agent_id="a1")
        assert any(r.success for r in results)

    def test_before_llm_returns_success_without_guard(self):
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin()
        hooks.register_plugin(plugin)

        # Must not raise and must return a result
        results = hooks.trigger_before_llm(session_id="forge-s1", query="Hello world")
        assert len(results) == 1
        # Without guard, should succeed (no blocking)
        assert results[0].success

    def test_session_end_returns_success_without_memory(self):
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin()
        hooks.register_plugin(plugin)

        results = hooks.trigger_session_end(session_id="forge-s1", agent_id="a1")
        assert any(r.success for r in results)

    def test_full_session_lifecycle_without_optional_deps(self):
        """Full session start → before_llm → session_end without crashing."""
        hooks = PipelineHooks()
        plugin = ForgeMemoryPlugin(agent_id="forge-test")
        hooks.register_plugin(plugin)

        sid = "lifecycle-test-session"
        start_results = hooks.trigger_session_start(session_id=sid)
        before_results = hooks.trigger_before_llm(session_id=sid, query="Tell me something")
        end_results = hooks.trigger_session_end(session_id=sid)

        assert all(r.success for r in start_results)
        assert all(r.success for r in before_results)
        assert all(r.success for r in end_results)

    def test_plugin_is_a_hookplugin(self):
        assert issubclass(ForgeMemoryPlugin, HookPlugin)
