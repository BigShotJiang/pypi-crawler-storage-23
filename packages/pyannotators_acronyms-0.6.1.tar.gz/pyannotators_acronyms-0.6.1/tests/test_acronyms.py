import json
from pathlib import Path

from dirty_equals import Contains, HasLen, IsList, IsPartialDict
from pymultirole_plugins.v1.schema import Document, Sentence

from pyannotators_acronyms.acronyms import AcronymsAnnotator, AcronymsParameters


def test_acronyms():
    sents = [
        "Le comité d'établissement (CE) s'est réuni.",
        "Les technologies de l'information et de la communication (TIC) prennent diverses formes : Internet, ordinateur, téléphone portable, modem, progiciels, etc.",
        "Les représentants du MoDem (Mouvement Démocrate) à la région, élus en 2015 sur la liste de M. Wauquiez, avaient annoncé en mars qu'ils quittaient la majorité, sans pour autant rejoindre l'opposition.",
        "Y compris dans la majorité, la vice-présidente du groupe LREM (La République En Marche) Sophie Beaudouin-Hubière a écrit au Premier ministre LREM Jean Castex pour dénoncer une décision d'autant plus injuste que les règles de distanciation ont été bien respectées DANS ces commerces.",
        "Ce CE n'est pas ambigu.",
        "Le Conseil d'Etat (CE) est une autre possibilité pour CE.",
        "La vice-présidente Les Républicains (LR) de l'Assemblée nationale Annie Genevard a aussi pointé le désarroi des petits commerçants, la situation accentuant le risque réel de dépérissement de nos centres-villes.",
        "Aide directe ou préfinancement du CESU ? Cette aide peut prendre la forme, en pratique, d'une aide financière directe versée aux salariés ou de chèques emploi-service universel (CESU).",
        "Exonération ZRR et ZRU : nouveaux formulaires \n\nLes embauches effectuées dans les zones de revitalisation rurale (ZRR) et de redynamisation urbaine (ZRU)",
        "L'employeur doit inviter les syndicats intéressés à négocier le protocole d'accord préélectoral en vue de l'élection d'un comité social et économique (CSE).",
        "Ce CE là est ambigu.",
        "Le Comité d'hygiène, de sécurité et des conditions de travail (CHSCT) se réunira demain",
    ]
    text = ""
    sentences = []
    for sent in sents:
        sstart = len(text)
        text += sent + "\n\n"
        send = len(text)
        sentences.append(Sentence(start=sstart, end=send))
    doc = Document(text=text, sentences=sentences, metadata={"language": "fr"})
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    docs: list[Document] = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    acros = ["CE", "TIC", "MoDem", "LREM", "LR", "CESU", "ZRR", "CSE", "CHSCT"]
    expands = [
        "comité d'établissement",
        "technologies de l'information et de la communication",
        "Mouvement Démocrate",
        "La République En Marche",
        "Conseil d'Etat",
        "Les Républicains",
        "chèques emploi-service universel",
        "zones de revitalisation rurale",
        "comité social et économique",
        "Comité d'hygiène, de sécurité et des conditions de travail",
    ]
    assert len(doc0.annotations) == 24
    shorts = [a.text for a in doc0.annotations if a.label == "Acronym"]
    assert shorts == HasLen(len(acros), ...)
    assert shorts == Contains(*acros)
    assert shorts != Contains("ZRU", "DANS")
    longs = [a.text for a in doc0.annotations if a.label == "Expanded"]
    assert longs == HasLen(len(expands), ...)
    assert longs == Contains(*expands)
    ce1 = doc0.annotations[0]
    assert ce1.model_dump() == IsPartialDict(
        label="Acronym",
        text="CE",
        terms=IsList(IsPartialDict(preferredForm="comité d'établissement"), length=1),
    )
    ce1_1 = doc0.annotations[9]
    assert ce1_1.model_dump() == IsPartialDict(
        label="Acronym",
        text="CE",
        terms=IsList(IsPartialDict(preferredForm="comité d'établissement"), length=1),
    )
    ce2 = doc0.annotations[10]
    assert ce2.model_dump() == IsPartialDict(
        label="Acronym",
        text="CE",
        terms=IsList(IsPartialDict(preferredForm="Conseil d'Etat"), length=1),
    )
    ce1_2_1 = doc0.annotations[12]
    assert ce1_2_1.model_dump() == IsPartialDict(label="Acronym", text="CE", terms=HasLen(2))
    ce1_2_2 = doc0.annotations[21]
    assert ce1_2_2.model_dump() == IsPartialDict(label="Acronym", text="CE", terms=HasLen(2))

    parameters.short_label = "short"
    parameters.long_label = "long"
    docs: list[Document] = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    labels = list({a.labelName for a in doc0.annotations})
    assert labels == IsList("short", "long", check_order=False)


def test_unsupported_language():
    doc = Document(text="Some text", metadata={"language": "xx_unsupported"})
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    import pytest

    with pytest.raises(AttributeError, match="Metadata language"):
        annotator.annotate([doc], parameters)


def test_missing_language():
    doc = Document(text="Some text", metadata={})
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    import pytest

    with pytest.raises(AttributeError, match="Metadata language None"):
        annotator.annotate([doc], parameters)


def test_no_sentences():
    """Document without pre-existing sentences should auto-create a single span."""
    doc = Document(text="Internet of Things (IoT) is everywhere.", metadata={"language": "en"})
    assert doc.sentences is None or len(doc.sentences) == 0
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    docs = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    assert len(doc0.annotations) > 0
    shorts = [a.text for a in doc0.annotations if a.label == "Acronym"]
    assert "IoT" in shorts


def test_propagate_false():
    """With propagate=False, standalone acronyms should not get expanded."""
    text = "Internet of Things (IoT) is great. IoT is everywhere."
    sentences = [
        Sentence(start=0, end=35),
        Sentence(start=35, end=len(text)),
    ]
    doc = Document(text=text, sentences=sentences, metadata={"language": "en"})
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters(propagate=False)
    docs = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    # The standalone "IoT" in second sentence should NOT have terms (no propagation)
    standalone_iots = [a for a in doc0.annotations if a.label == "Acronym" and a.start >= 35]
    assert len(standalone_iots) == 0


def test_get_model():
    assert AcronymsAnnotator.get_model() is AcronymsParameters


def test_document_language():
    from pyannotators_acronyms.acronyms import document_language

    doc_with_lang = Document(text="test", metadata={"language": "fr"})
    assert document_language(doc_with_lang, "en") == "fr"

    doc_no_meta = Document(text="test")
    assert document_language(doc_no_meta, "en") == "en"

    doc_empty_meta = Document(text="test", metadata={})
    assert document_language(doc_empty_meta, None) is None


def test_special_characters_cleaned():
    """Acronyms should be detected even with NBSP and other special spaces."""
    # Use NBSP (\u00a0) instead of regular space
    text = "Internet\u00a0of\u00a0Things (IoT) is great."
    doc = Document(text=text, metadata={"language": "en"})
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    docs = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    shorts = [a.text for a in doc0.annotations if a.label == "Acronym"]
    assert "IoT" in shorts


def test_max_size():
    """Acronyms longer than max_size should not be detected."""
    text = "ABCDEFG (Alpha Beta Charlie Delta Echo Foxtrot Golf) is long."
    doc = Document(text=text, metadata={"language": "en"})
    annotator = AcronymsAnnotator()
    # Default max_size=6, ABCDEFG has 7 chars so should not match
    parameters = AcronymsParameters(max_size=6)
    docs = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    shorts = [a.text for a in doc0.annotations if a.label == "Acronym"]
    assert "ABCDEFG" not in shorts

    # With max_size=7 it should match
    parameters2 = AcronymsParameters(max_size=7)
    docs2 = annotator.annotate([doc], parameters2)
    doc2 = docs2[0]
    shorts2 = [a.text for a in doc2.annotations if a.label == "Acronym"]
    assert "ABCDEFG" in shorts2


def test_ifpen():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/ifpen_en-document-2023_en.json")
    with source.open("r") as fin:
        jdoc = json.load(fin)
        doc = Document(**jdoc)
    annotator = AcronymsAnnotator()
    parameters = AcronymsParameters()
    docs: list[Document] = annotator.annotate([doc], parameters)
    doc0 = docs[0]
    assert len(doc0.annotations) > 0
