"""Annotator based on Spacy NER"""

__version__ = "0.6.1"
