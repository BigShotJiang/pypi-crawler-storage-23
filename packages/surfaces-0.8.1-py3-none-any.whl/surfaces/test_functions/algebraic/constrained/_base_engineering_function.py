# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License

"""Base class for engineering design optimization test functions."""

from typing import Any, Callable, Dict, List, Optional, Tuple, Union

import numpy as np

from surfaces._array_utils import ArrayLike, get_array_namespace
from surfaces.modifiers import BaseModifier

from ..._base_single_objective import BaseSingleObjectiveTestFunction


class EngineeringFunction(BaseSingleObjectiveTestFunction):
    """Base class for real-world engineering design optimization problems.

    Engineering functions represent practical design optimization problems
    from domains like structural mechanics, manufacturing, and mechanical
    engineering. Unlike purely mathematical test functions, these problems
    have physical meaning and constraints derived from engineering principles.

    Most engineering problems are inherently constrained. This base class
    provides infrastructure for handling constraints via penalty methods,
    converting constrained problems into unconstrained ones suitable for
    general-purpose optimizers.

    Parameters
    ----------
    objective : str, default="minimize"
        Either "minimize" or "maximize".
    modifiers : list of BaseModifier, optional
        List of modifiers to apply to function evaluations.
    penalty_coefficient : float, default=1e6
        Coefficient for constraint violation penalties. Higher values
        enforce constraints more strictly but may create steep gradients.

    Attributes
    ----------
    n_dim : int
        Number of design variables.
    variable_names : list of str
        Names of design variables (e.g., ["thickness", "radius"]).
    variable_bounds : list of tuple
        Bounds for each variable as (min, max) pairs.

    Notes
    -----
    Constraint handling uses the exterior penalty method:

    .. math::

        F(x) = f(x) + r \\sum_{i} \\max(0, g_i(x))^2

    where f(x) is the objective, g_i(x) are inequality constraints
    (g_i(x) <= 0 is feasible), and r is the penalty coefficient.
    """

    _spec = {
        "default_bounds": None,  # Engineering functions have variable-specific bounds
        "continuous": True,
        "differentiable": True,
        "constrained": True,
    }

    default_size: int = 10000

    # Subclasses should define these
    variable_names: List[str] = []
    variable_bounds: List[Tuple[float, float]] = []

    def __init__(
        self,
        objective: str = "minimize",
        modifiers: Optional[List[BaseModifier]] = None,
        memory: bool = False,
        collect_data: bool = True,
        callbacks: Optional[Union[Callable, List[Callable]]] = None,
        catch_errors: Optional[Dict[type, float]] = None,
        penalty_coefficient: float = 1e6,
    ) -> None:
        self.penalty_coefficient = penalty_coefficient
        super().__init__(objective, modifiers, memory, collect_data, callbacks, catch_errors)

    @property
    def n_dim(self) -> int:
        """Number of design variables."""
        return len(self.variable_names)

    def _default_search_space(self) -> Dict[str, Any]:
        """Build search space from variable_names and variable_bounds."""
        search_space_ = {}
        total_size = self.default_size
        dim_size = int(total_size ** (1 / self.n_dim))

        for i, (name, (lb, ub)) in enumerate(zip(self.variable_names, self.variable_bounds)):
            step_size = (ub - lb) / dim_size
            values = np.arange(lb, ub, step_size)
            search_space_[name] = values

        return search_space_

    def _get_values(self, params: Dict[str, Any]) -> np.ndarray:
        """Extract variable values from params dict in order."""
        return np.array([params[name] for name in self.variable_names])

    def _constraints(self, params: Dict[str, Any]) -> List[float]:
        """Evaluate constraint functions.

        Override in subclasses to define problem-specific constraints.
        Each constraint g_i should be formulated such that g_i <= 0 is feasible.

        Parameters
        ----------
        params : dict
            Design variable values.

        Returns
        -------
        list of float
            Constraint function values. Negative or zero means feasible.
        """
        return []

    def constraints(self, params: Dict[str, Any]) -> List[float]:
        """Public API: evaluate constraint functions."""
        return self._constraints(params)

    def constraint_violations(self, params: Dict[str, Any]) -> List[float]:
        """Calculate constraint violations (positive values only).

        Parameters
        ----------
        params : dict
            Design variable values.

        Returns
        -------
        list of float
            Violation amounts. Zero means constraint is satisfied.
        """
        return [max(0, g) for g in self._constraints(params)]

    def is_feasible(self, params: Dict[str, Any]) -> bool:
        """Check if a solution satisfies all constraints.

        Parameters
        ----------
        params : dict
            Design variable values.

        Returns
        -------
        bool
            True if all constraints are satisfied.
        """
        return all(g <= 0 for g in self._constraints(params))

    def penalty(self, params: Dict[str, Any]) -> float:
        """Calculate total penalty for constraint violations.

        Parameters
        ----------
        params : dict
            Design variable values.

        Returns
        -------
        float
            Penalty value (sum of squared violations times coefficient).
        """
        violations = self.constraint_violations(params)
        return self.penalty_coefficient * sum(v**2 for v in violations)

    def _raw_objective(self, params: Dict[str, Any]) -> float:
        """Evaluate the raw objective function without penalties.

        Override in subclasses to define the engineering objective.

        Parameters
        ----------
        params : dict
            Design variable values.

        Returns
        -------
        float
            Raw objective function value.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement _raw_objective(self, params)"
        )

    def raw_objective(self, params: Dict[str, Any]) -> float:
        """Public API: evaluate raw objective without penalties."""
        return self._raw_objective(params)

    def _objective(self, params: Dict[str, Any]) -> float:
        """Sub-template: raw objective + penalty for constraint violations."""
        return self._raw_objective(params) + self.penalty(params)

    def _batch_raw_objective(self, X: ArrayLike) -> ArrayLike:
        """Compute raw objective for batch of points.

        Override in subclasses to provide vectorized implementation.

        Parameters
        ----------
        X : ArrayLike
            Input batch of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Raw objective values of shape (n_points,).
        """
        raise NotImplementedError("Subclasses must implement _batch_raw_objective")

    def _batch_constraints(self, X: ArrayLike) -> ArrayLike:
        """Compute constraint values for batch of points.

        Override in subclasses to provide vectorized implementation.

        Parameters
        ----------
        X : ArrayLike
            Input batch of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Constraint values of shape (n_points, n_constraints).
            Each row contains constraint values for one point.
            Negative or zero values indicate feasibility.
        """
        raise NotImplementedError("Subclasses must implement _batch_constraints")

    def _batch_penalty(self, X: ArrayLike) -> ArrayLike:
        """Compute penalty for batch of points using exterior penalty method.

        Parameters
        ----------
        X : ArrayLike
            Input batch of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Penalty values of shape (n_points,).
        """
        xp = get_array_namespace(X)
        G = self._batch_constraints(X)  # Shape: (n_points, n_constraints)
        # Violations: max(0, g)^2
        violations = xp.maximum(G, 0.0) ** 2
        # Sum over constraints
        return self.penalty_coefficient * xp.sum(violations, axis=1)

    def _batch_objective(self, X: ArrayLike) -> ArrayLike:
        """Compute penalized objective for batch of points.

        Parameters
        ----------
        X : ArrayLike
            Input batch of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Penalized objective values of shape (n_points,).
        """
        return self._batch_raw_objective(X) + self._batch_penalty(X)
