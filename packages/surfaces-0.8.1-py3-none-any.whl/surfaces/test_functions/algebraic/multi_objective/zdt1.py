# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License

"""ZDT1 multi-objective test function."""

from typing import Any, Dict

import numpy as np

from surfaces._array_utils import ArrayLike, get_array_namespace

from ._base_multi_objective import BaseMultiObjectiveTestFunction


class ZDT1(BaseMultiObjectiveTestFunction):
    """ZDT1 multi-objective test function.

    The ZDT1 function is a widely used benchmark for multi-objective
    optimization. It has a convex Pareto front.

    The function is defined as:

    .. math::

        f_1(x) = x_1

        f_2(x) = g(x) \\cdot \\left[1 - \\sqrt{\\frac{x_1}{g(x)}}\\right]

        g(x) = 1 + \\frac{9}{n-1} \\sum_{i=2}^{n} x_i

    Parameters
    ----------
    n_dim : int, default=30
        Number of input dimensions. Must be >= 2.
    **kwargs
        Additional keyword arguments passed to
        :class:`BaseMultiObjectiveTestFunction` (modifiers, memory, etc.).

    Attributes
    ----------
    n_objectives : int
        Number of objectives (always 2).

    References
    ----------
    .. [1] Zitzler, E., Deb, K., & Thiele, L. (2000). Comparison of
       multiobjective evolutionary algorithms: Empirical results.
       Evolutionary computation, 8(2), 173-195.

    Examples
    --------
    >>> from surfaces.test_functions.algebraic.multi_objective import ZDT1
    >>> func = ZDT1(n_dim=30)
    >>> result = func(np.zeros(30))
    >>> result.shape
    (2,)
    >>> result[0]  # f1 = x1 = 0
    0.0
    """

    name = "ZDT1"
    n_objectives = 2
    _spec = {
        "continuous": True,
        "differentiable": True,
        "convex_front": True,
        "scalable": True,
        "default_bounds": (0.0, 1.0),
    }

    def __init__(self, n_dim: int = 30, **kwargs):
        if n_dim < 2:
            raise ValueError(f"n_dim must be >= 2, got {n_dim}")
        super().__init__(n_dim, **kwargs)

    def _objective(self, params: Dict[str, Any]) -> np.ndarray:
        x = self._params_to_array(params)

        f1 = x[0]

        g = 1 + 9 * np.sum(x[1:]) / (self.n_dim - 1)
        f2 = g * (1 - np.sqrt(f1 / g))

        return np.array([f1, f2])

    def _pareto_front(self, n_points: int) -> np.ndarray:
        """Pareto front: f2 = 1 - sqrt(f1) for f1 in [0, 1]."""
        f1 = np.linspace(0, 1, n_points)
        f2 = 1 - np.sqrt(f1)
        return np.column_stack([f1, f2])

    def _pareto_set(self, n_points: int) -> np.ndarray:
        """Pareto set: x1 in [0, 1] with x2 = ... = xn = 0."""
        x = np.zeros((n_points, self.n_dim))
        x[:, 0] = np.linspace(0, 1, n_points)
        return x

    def _batch_objective(self, X: ArrayLike) -> ArrayLike:
        """Vectorized ZDT1 evaluation.

        Parameters
        ----------
        X : ArrayLike
            Input array of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Output array of shape (n_points, 2).
        """
        xp = get_array_namespace(X)

        # f1 = x1
        f1 = X[:, 0]

        # g = 1 + 9 * sum(x[1:]) / (n_dim - 1)
        g = 1 + 9 * xp.sum(X[:, 1:], axis=1) / (self.n_dim - 1)

        # f2 = g * (1 - sqrt(f1 / g))
        f2 = g * (1 - xp.sqrt(f1 / g))

        return xp.stack([f1, f2], axis=1)
