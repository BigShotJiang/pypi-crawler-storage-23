# Author: Simon Blanke
# Email: simon.blanke@yahoo.com
# License: MIT License

import math
from typing import Any, Callable, Dict, List, Optional, Union

from surfaces._array_utils import ArrayLike, get_array_namespace
from surfaces.modifiers import BaseModifier

from ..._base_algebraic_function import AlgebraicFunction


class GriewankFunction(AlgebraicFunction):
    """Griewank N-dimensional test function.

    A multimodal function with many regularly distributed local minima.
    The number of local minima increases with dimensionality.

    The function is defined as:

    .. math::

        f(\\vec{x}) = \\sum_{i=1}^{n} \\frac{x_i^2}{4000}
        - \\prod_{i=1}^{n} \\cos\\left(\\frac{x_i}{\\sqrt{i}}\\right) + 1

    The global minimum is :math:`f(\\vec{0}) = 0`.

    Parameters
    ----------
    n_dim : int
        Number of dimensions.
    metric : str, default="score"
        Either "loss" (minimize) or "score" (maximize).
    modifiers : list of BaseModifier, optional
        List of modifiers to apply to function evaluations.

    Attributes
    ----------
    n_dim : int
        Number of dimensions.

    Examples
    --------
    >>> from surfaces.test_functions import GriewankFunction
    >>> func = GriewankFunction(n_dim=2)
    >>> result = func({"x0": 0.0, "x1": 0.0})
    >>> abs(result) < 1e-10
    True
    """

    _spec = {
        "convex": False,
        "unimodal": False,
        "separable": False,
        "scalable": True,
        "default_bounds": (-100.0, 100.0),
    }

    f_global = 0.0

    latex_formula = r"f(\vec{x}) = \sum_{i=1}^{n} \frac{x_i^2}{4000} - \prod_{i=1}^{n} \cos\left(\frac{x_i}{\sqrt{i}}\right) + 1"
    pgfmath_formula = (
        "#1^2/4000 + #2^2/4000 - cos(deg(#1))*cos(deg(#2/sqrt(2))) + 1"  # 2D specialization
    )

    # Function sheet attributes
    tagline = (
        "A product of cosines superimposed on a parabolic bowl. "
        "Local minima become less pronounced at larger scales."
    )
    display_bounds = (-10.0, 10.0)
    display_projection = {"fixed_value": 0.0}  # Fix all dims except x0, x1 to 0
    reference = "Griewank (1981)"
    reference_url = "https://www.sfu.ca/~ssurjano/griewank.html"

    def __init__(
        self,
        n_dim: int = 2,
        objective: str = "minimize",
        modifiers: Optional[List[BaseModifier]] = None,
        memory: bool = False,
        collect_data: bool = True,
        callbacks: Optional[Union[Callable, List[Callable]]] = None,
        catch_errors: Optional[Dict[type, float]] = None,
    ) -> None:
        super().__init__(objective, modifiers, memory, collect_data, callbacks, catch_errors)
        self.n_dim = n_dim
        self.x_global = tuple(0.0 for _ in range(n_dim))

    def _objective(self, params: Dict[str, Any]) -> float:
        loss_sum = 0.0
        loss_product = 1.0
        for dim in range(self.n_dim):
            dim_str = "x" + str(dim)
            x = params[dim_str]

            loss_sum += x**2 / 4000
            loss_product *= math.cos(x / math.sqrt(dim + 1))

        return loss_sum - loss_product + 1

    def _batch_objective(self, X: ArrayLike) -> ArrayLike:
        """Vectorized batch evaluation.

        Parameters
        ----------
        X : ArrayLike
            Array of shape (n_points, n_dim).

        Returns
        -------
        ArrayLike
            Array of shape (n_points,).
        """
        xp = get_array_namespace(X)

        # f(x) = sum(x_i^2/4000) - prod(cos(x_i/sqrt(i+1))) + 1
        sum_term = xp.sum(X**2 / 4000, axis=1)

        # Create sqrt(i+1) divisor: [1, sqrt(2), sqrt(3), ..., sqrt(n)]
        sqrt_indices = xp.sqrt(xp.arange(1, self.n_dim + 1, dtype=X.dtype))
        cos_args = X / sqrt_indices  # Broadcasting: (n_points, n_dim) / (n_dim,)
        prod_term = xp.prod(xp.cos(cos_args), axis=1)

        return sum_term - prod_term + 1

    def _search_space(
        self,
        min: float = -100,
        max: float = 100,
        size: int = 10000,
        value_types: str = "array",
    ) -> Dict[str, Any]:
        return super()._create_n_dim_search_space(min, max, size=size, value_types=value_types)
