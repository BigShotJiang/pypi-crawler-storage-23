"""Gradient Boosting Regressor test function with surrogate support."""

from typing import Any, Dict, List, Optional

import numpy as np

from surfaces.modifiers import BaseModifier

from .._base_regression import BaseRegression
from ..datasets import DATASETS


class GradientBoostingRegressorFunction(BaseRegression):
    """Gradient Boosting Regressor test function.

    A machine learning test function that evaluates Gradient Boosting
    regression with different hyperparameters using cross-validation.

    Parameters
    ----------
    dataset : str, default="diabetes"
        Dataset to use for evaluation. One of: "diabetes", "california".
        This is a fixed parameter (like a coefficient), not part of the search space.
    cv : int, default=5
        Number of cross-validation folds.
        This is a fixed parameter, not part of the search space.
    use_surrogate : bool, default=False
        If True, use pre-trained surrogate model for fast evaluation (~1ms).
        Falls back to real evaluation if no surrogate is available.
    objective : str, default="maximize"
        Either "minimize" or "maximize".
    modifiers : list of BaseModifier, optional
        List of modifiers to apply to function evaluations.

    Attributes
    ----------
    available_datasets : list
        Available dataset names: ["diabetes", "california"].
    available_cv : list
        Available CV fold options: [2, 3, 5, 10].

    Examples
    --------
    Basic usage with real evaluation:

    >>> from surfaces.test_functions import GradientBoostingRegressorFunction
    >>> func = GradientBoostingRegressorFunction(dataset="diabetes", cv=5)
    >>> func.search_space
    {'n_estimators': [3, 8, 13, ...], 'max_depth': [2, 3, 4, ...]}
    >>> result = func({"n_estimators": 50, "max_depth": 5})

    Fast evaluation with surrogate (requires surfaces[surrogates]):

    >>> func = GradientBoostingRegressorFunction(dataset="diabetes", cv=5, use_surrogate=True)
    >>> result = func({"n_estimators": 50, "max_depth": 5})  # ~1ms
    """

    _name_ = "gradient_boosting_regressor"

    # Available options (for validation and documentation)
    available_datasets = list(DATASETS.keys())
    available_cv = [2, 3, 5, 10]

    # Search space parameters (only actual hyperparameters)
    para_names = ["n_estimators", "max_depth"]
    n_estimators_default = list(np.arange(3, 150, 5))
    max_depth_default = list(np.arange(2, 25))

    def __init__(
        self,
        dataset: str = "diabetes",
        cv: int = 5,
        objective: str = "maximize",
        modifiers: Optional[List[BaseModifier]] = None,
        memory: bool = False,
        collect_data: bool = True,
        callbacks=None,
        catch_errors=None,
        use_surrogate: bool = False,
    ):
        # Validate dataset
        if dataset not in DATASETS:
            raise ValueError(
                f"Unknown dataset '{dataset}'. " f"Available: {self.available_datasets}"
            )

        # Validate cv
        if cv not in self.available_cv:
            raise ValueError(f"Invalid cv={cv}. Available: {self.available_cv}")

        # Store fixed parameters (like coefficients in math functions)
        self.dataset = dataset
        self.cv = cv

        # Load dataset for real evaluation
        self._dataset_loader = DATASETS[dataset]

        super().__init__(
            objective=objective,
            modifiers=modifiers,
            memory=memory,
            collect_data=collect_data,
            callbacks=callbacks,
            catch_errors=catch_errors,
            use_surrogate=use_surrogate,
        )

    def _default_search_space(self) -> Dict[str, Any]:
        """Search space containing only hyperparameters (not dataset/cv)."""
        return {
            "n_estimators": self.n_estimators_default,
            "max_depth": self.max_depth_default,
        }

    def _ml_objective(self, params: Dict[str, Any]) -> float:
        from sklearn.ensemble import GradientBoostingRegressor
        from sklearn.model_selection import cross_val_score

        X, y = self._dataset_loader()
        gbr = GradientBoostingRegressor(
            n_estimators=params["n_estimators"],
            max_depth=params["max_depth"],
        )
        scores = cross_val_score(gbr, X, y, cv=self.cv, scoring="r2")
        return scores.mean()

    def _get_surrogate_params(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Add fixed parameters (dataset, cv) to params for surrogate prediction."""
        return {
            **params,
            "dataset": self.dataset,
            "cv": self.cv,
        }
