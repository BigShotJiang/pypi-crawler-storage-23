"""Tests for config.py."""

from __future__ import annotations

import pytest

from defistream_mcp.config import ServerConfig


class TestServerConfig:
    def test_from_env_full(self, config_env):
        cfg = ServerConfig.from_env()
        assert cfg.api_key == "dsk_test_key_12345"
        assert cfg.base_url == "https://api.example.com/v1"
        assert cfg.transport == "stdio"
        assert cfg.download_dir == "/tmp/test-downloads"

    def test_from_env_defaults(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        # Clear optional vars
        monkeypatch.delenv("DEFISTREAM_BASE_URL", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_TRANSPORT", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_HOST", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_PORT", raising=False)
        monkeypatch.delenv("DEFISTREAM_DOWNLOAD_DIR", raising=False)

        monkeypatch.delenv("DEFISTREAM_LOCAL", raising=False)

        cfg = ServerConfig.from_env()
        assert cfg.api_key == "dsk_abc"
        assert cfg.base_url == "https://api.defistream.dev/v1"
        assert cfg.transport == "stdio"
        assert cfg.host == "0.0.0.0"
        assert cfg.port == 8000
        assert cfg.download_dir == "."
        assert cfg.local is False

    def test_missing_api_key_is_ok(self, monkeypatch):
        """API key is now optional - users provide their own per-request."""
        monkeypatch.delenv("DEFISTREAM_API_KEY", raising=False)
        monkeypatch.delenv("DEFISTREAM_BASE_URL", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_TRANSPORT", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_HOST", raising=False)
        monkeypatch.delenv("DEFISTREAM_MCP_PORT", raising=False)
        monkeypatch.delenv("DEFISTREAM_DOWNLOAD_DIR", raising=False)

        monkeypatch.delenv("DEFISTREAM_LOCAL", raising=False)
        cfg = ServerConfig.from_env()
        assert cfg.api_key == ""

    def test_invalid_transport(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_MCP_TRANSPORT", "grpc")
        with pytest.raises(ValueError, match="'stdio', 'sse', or 'http'"):
            ServerConfig.from_env()

    def test_invalid_port(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_MCP_PORT", "not_a_number")
        with pytest.raises(ValueError, match="DEFISTREAM_MCP_PORT must be an integer"):
            ServerConfig.from_env()

    def test_custom_host_port(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_MCP_HOST", "127.0.0.1")
        monkeypatch.setenv("DEFISTREAM_MCP_PORT", "9000")
        cfg = ServerConfig.from_env()
        assert cfg.host == "127.0.0.1"
        assert cfg.port == 9000

    def test_trailing_slash_stripped(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_BASE_URL", "https://api.example.com/v1/")
        cfg = ServerConfig.from_env()
        assert cfg.base_url == "https://api.example.com/v1"

    def test_local_flag_sets_url(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_LOCAL", "true")
        monkeypatch.delenv("DEFISTREAM_BASE_URL", raising=False)
        cfg = ServerConfig.from_env()
        assert cfg.base_url == "http://localhost:8081/v1"
        assert cfg.local is True

    def test_local_flag_variants(self, monkeypatch):
        for val in ("1", "True", "YES", "true"):
            monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
            monkeypatch.setenv("DEFISTREAM_LOCAL", val)
            monkeypatch.delenv("DEFISTREAM_BASE_URL", raising=False)
            cfg = ServerConfig.from_env()
            assert cfg.local is True, f"DEFISTREAM_LOCAL={val!r} should be truthy"

    def test_explicit_url_overrides_local(self, monkeypatch):
        monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_abc")
        monkeypatch.setenv("DEFISTREAM_LOCAL", "true")
        monkeypatch.setenv("DEFISTREAM_BASE_URL", "https://custom.example.com/v1")
        cfg = ServerConfig.from_env()
        assert cfg.base_url == "https://custom.example.com/v1"

    def test_frozen(self, sample_config):
        with pytest.raises(AttributeError):
            sample_config.api_key = "changed"
