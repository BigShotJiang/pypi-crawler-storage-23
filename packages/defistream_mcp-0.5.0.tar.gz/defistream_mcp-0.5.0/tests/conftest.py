"""Shared fixtures for MCP server tests."""

from __future__ import annotations

import os

import pytest

import defistream_mcp.config as config_module
from defistream_mcp.config import ServerConfig


@pytest.fixture(autouse=True)
def _no_dotenv(monkeypatch):
    """Prevent .env files from leaking into tests."""
    monkeypatch.setattr(config_module, "_load_dotenv", lambda: None)


@pytest.fixture()
def config_env(monkeypatch):
    """Set minimal environment variables for ServerConfig."""
    monkeypatch.setenv("DEFISTREAM_API_KEY", "dsk_test_key_12345")
    monkeypatch.setenv("DEFISTREAM_BASE_URL", "https://api.example.com/v1")
    monkeypatch.setenv("DEFISTREAM_MCP_TRANSPORT", "stdio")
    monkeypatch.setenv("DEFISTREAM_DOWNLOAD_DIR", "/tmp/test-downloads")


@pytest.fixture()
def sample_config(config_env) -> ServerConfig:
    """Return a ServerConfig built from test env vars."""
    return ServerConfig.from_env()
