"""Tests for tools.py query builders and helpers."""

from __future__ import annotations

import pytest

from defistream_mcp.tools import _build_query, _build_range_params, _parse_query


# ---------------------------------------------------------------------------
# _build_range_params
# ---------------------------------------------------------------------------


class TestBuildRangeParams:
    def test_block_range(self):
        result = _build_range_params(100, 200, None, None)
        assert result == {"block_start": 100, "block_end": 200}

    def test_time_range(self):
        result = _build_range_params(None, None, "2025-01-01", "2025-01-02")
        assert result == {"since": "2025-01-01", "until": "2025-01-02"}

    def test_mutual_exclusivity(self):
        with pytest.raises(ValueError, match="block_start/block_end or since/until"):
            _build_range_params(100, 200, "2025-01-01", None)

    def test_partial_block_start_only(self):
        result = _build_range_params(100, None, None, None)
        assert result == {"block_start": 100}

    def test_partial_block_end_only(self):
        result = _build_range_params(None, 200, None, None)
        assert result == {"block_end": 200}

    def test_partial_since_only(self):
        result = _build_range_params(None, None, "2025-01-01", None)
        assert result == {"since": "2025-01-01"}

    def test_no_range(self):
        result = _build_range_params(None, None, None, None)
        assert result == {}


# ---------------------------------------------------------------------------
# _build_query
# ---------------------------------------------------------------------------


class TestBuildQuery:
    def test_basic_event_query(self):
        result = _build_query("erc20", "transfer", "ETH", {"token": "USDT"})
        assert result.startswith("/erc20/events/transfer?")
        assert "network=ETH" in result
        assert "token=USDT" in result
        assert "/aggregate" not in result

    def test_aggregate_query(self):
        result = _build_query(
            "aave_v3", "deposit", "ETH", {},
            aggregate=True, group_by="time", period="1h",
        )
        assert "/aave_v3/events/deposit/aggregate?" in result
        assert "group_by=time" in result
        assert "period=1h" in result

    def test_verbose_flag(self):
        result = _build_query("lido", "deposit", "ETH", {}, verbose=True)
        assert "verbose=true" in result

    def test_verbose_off_by_default(self):
        result = _build_query("lido", "deposit", "ETH", {})
        assert "verbose" not in result

    def test_with_value_flag(self):
        result = _build_query("erc20", "transfer", "ETH", {"token": "USDT"}, with_value=True)
        assert "with_value=true" in result

    def test_with_value_off_by_default(self):
        result = _build_query("erc20", "transfer", "ETH", {"token": "USDT"})
        assert "with_value" not in result

    def test_with_value_and_verbose_together(self):
        result = _build_query("aave_v3", "deposit", "ETH", {}, verbose=True, with_value=True)
        assert "verbose=true" in result
        assert "with_value=true" in result

    def test_with_value_on_aggregate(self):
        result = _build_query(
            "aave_v3", "deposit", "ETH", {},
            aggregate=True, group_by="time", period="1h", with_value=True,
        )
        assert "/aggregate?" in result
        assert "with_value=true" in result

    def test_filters_none_values(self):
        result = _build_query(
            "native_token", "transfer", "ETH",
            {"sender": None, "receiver": "0xabc"},
        )
        assert "sender" not in result
        assert "receiver=0xabc" in result

    def test_all_none_extra(self):
        result = _build_query(
            "stader", "deposit", "ETH",
            {"involving": None, "involving_label": None},
        )
        assert result == "/stader/events/deposit?network=ETH"

    def test_uniswap_v3_pool_params(self):
        result = _build_query(
            "uniswap_v3", "swap", "ETH",
            {"symbol0": "WETH", "symbol1": "USDC", "fee": 3000},
        )
        assert "symbol0=WETH" in result
        assert "symbol1=USDC" in result
        assert "fee=3000" in result

    def test_aggregate_without_group_by_defaults(self):
        result = _build_query("erc20", "transfer", "ETH", {"token": "USDT"}, aggregate=True)
        assert "group_by=time" in result
        assert "period=1h" in result

    def test_multi_token_comma_separated(self):
        result = _build_query("erc20", "transfer", "ETH", {"token": "USDT,USDC,DAI"})
        assert "/erc20/events/transfer?" in result
        # urlencode encodes commas as %2C
        assert "token=USDT%2CUSDC%2CDAI" in result or "token=USDT,USDC,DAI" in result


# ---------------------------------------------------------------------------
# _parse_query
# ---------------------------------------------------------------------------


class TestParseQuery:
    def test_with_params(self):
        path, params = _parse_query("/erc20/events/transfer?network=ETH&token=USDT")
        assert path == "/erc20/events/transfer"
        assert params["network"] == "ETH"
        assert params["token"] == "USDT"

    def test_without_params(self):
        path, params = _parse_query("/aave_v3/events/deposit")
        assert path == "/aave_v3/events/deposit"
        assert params == {}

    def test_numeric_param_is_string(self):
        _, params = _parse_query("/erc20/events/transfer?block_start=100")
        assert params["block_start"] == "100"

    def test_aggregate_path(self):
        path, params = _parse_query(
            "/erc20/events/transfer/aggregate?network=ETH&group_by=time&period=1h"
        )
        assert path == "/erc20/events/transfer/aggregate"
        assert params["group_by"] == "time"

    def test_roundtrip_build_then_parse(self):
        """Build a query and then parse it back — should preserve path and params."""
        query = _build_query(
            "erc20", "transfer", "ETH",
            {"token": "USDT", "block_start": 100, "block_end": 200},
        )
        path, params = _parse_query(query)
        assert path == "/erc20/events/transfer"
        assert params["network"] == "ETH"
        assert params["token"] == "USDT"
        assert params["block_start"] == "100"
        assert params["block_end"] == "200"

    def test_roundtrip_aggregate(self):
        query = _build_query(
            "aave_v3", "deposit", "ARB", {"eth_market_type": "Core"},
            aggregate=True, group_by="block_number", period="1000",
        )
        path, params = _parse_query(query)
        assert path == "/aave_v3/events/deposit/aggregate"
        assert params["network"] == "ARB"
        assert params["group_by"] == "block_number"
        assert params["period"] == "1000"
        assert params["eth_market_type"] == "Core"


# ---------------------------------------------------------------------------
# Query builder integration (call the builders through register_tools)
# ---------------------------------------------------------------------------


class TestQueryBuildersViaRegister:
    """Test each protocol builder by invoking it through the registered MCP tools.

    We create a minimal mock MCP server that captures @mcp.tool() registrations.
    """

    @pytest.fixture(autouse=True)
    def _register(self, sample_config):
        from defistream_mcp.tools import register_tools

        self.tools: dict = {}

        class FakeMCP:
            def __init__(self, tools_dict):
                self._tools = tools_dict

            def tool(self):
                def decorator(fn):
                    self._tools[fn.__name__] = fn
                    return fn
                return decorator

        register_tools(FakeMCP(self.tools), sample_config)

    # -- erc20 --
    def test_erc20_minimal(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDT",
            block_start=100, block_end=200,
        )
        assert "/erc20/events/transfer?" in q
        assert "token=USDT" in q
        assert "block_start=100" in q

    def test_erc20_aggregate(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDC",
            since="2025-01-01", until="2025-01-02",
            aggregate=True, group_by="time", period="1d",
        )
        assert "/aggregate?" in q
        assert "group_by=time" in q
        assert "period=1d" in q

    def test_erc20_multi_token(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDT,USDC,DAI",
            block_start=100, block_end=200,
        )
        assert "/erc20/events/transfer?" in q
        assert "token=USDT%2CUSDC%2CDAI" in q or "token=USDT,USDC,DAI" in q

    def test_erc20_filters(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDT",
            block_start=100, block_end=200,
            sender="0xabc", min_amount=1000,
        )
        assert "sender=0xabc" in q
        assert "min_amount=1000" in q

    # -- native_token --
    def test_native_token_minimal(self):
        q = self.tools["native_token_query_builder"](
            event_type="transfer", network="ETH",
            block_start=100, block_end=200,
        )
        assert "/native_token/events/transfer?" in q
        assert "network=ETH" in q

    # -- aave_v3 --
    def test_aave_v3_with_market_type(self):
        q = self.tools["aave_v3_query_builder"](
            event_type="deposit", network="ETH",
            block_start=100, block_end=200,
            eth_market_type="Core",
        )
        assert "/aave_v3/events/deposit?" in q
        assert "eth_market_type=Core" in q

    # -- uniswap_v3 --
    def test_uniswap_v3_required_params(self):
        q = self.tools["uniswap_v3_query_builder"](
            event_type="swap", network="ETH",
            symbol0="WETH", symbol1="USDC", fee=3000,
            block_start=100, block_end=200,
        )
        assert "/uniswap_v3/events/swap?" in q
        assert "symbol0=WETH" in q
        assert "symbol1=USDC" in q
        assert "fee=3000" in q

    # -- lido --
    def test_lido_minimal(self):
        q = self.tools["lido_query_builder"](
            event_type="deposit", network="ETH",
            since="2025-01-01", until="2025-01-02",
        )
        assert "/lido/events/deposit?" in q

    # -- stader --
    def test_stader_minimal(self):
        q = self.tools["stader_query_builder"](
            event_type="deposit", network="ETH",
            block_start=100, block_end=200,
        )
        assert "/stader/events/deposit?" in q

    # -- threshold --
    def test_threshold_minimal(self):
        q = self.tools["threshold_query_builder"](
            event_type="mint", network="ETH",
            block_start=100, block_end=200,
        )
        assert "/threshold/events/mint?" in q

    # -- with_value across builders --
    def test_erc20_with_value(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDT",
            block_start=100, block_end=200, with_value=True,
        )
        assert "with_value=true" in q

    def test_aave_v3_with_value(self):
        q = self.tools["aave_v3_query_builder"](
            event_type="deposit", network="ETH",
            block_start=100, block_end=200, with_value=True,
        )
        assert "with_value=true" in q

    def test_uniswap_v3_with_value(self):
        q = self.tools["uniswap_v3_query_builder"](
            event_type="swap", network="ETH",
            symbol0="WETH", symbol1="USDC", fee=3000,
            block_start=100, block_end=200, with_value=True,
        )
        assert "with_value=true" in q

    def test_with_value_off_by_default_builder(self):
        q = self.tools["erc20_query_builder"](
            event_type="transfer", network="ETH", token="USDT",
            block_start=100, block_end=200,
        )
        assert "with_value" not in q

    # -- range validation propagates --
    def test_range_error_propagates(self):
        with pytest.raises(ValueError, match="block_start/block_end or since/until"):
            self.tools["erc20_query_builder"](
                event_type="transfer", network="ETH", token="USDT",
                block_start=100, block_end=200,
                since="2025-01-01", until="2025-01-02",
            )

    # -- query_local_execution_guide --
    def test_query_local_execution_guide(self):
        guide = self.tools["query_local_execution_guide"](
            query="/erc20/events/transfer?network=ETH&token=USDT&block_start=100&block_end=200",
        )
        assert "## Query Local Execution Guide" in guide
        assert "curl" in guide
        assert "Python" in guide
        assert "JavaScript" in guide
        assert "YOUR_API_KEY" in guide
