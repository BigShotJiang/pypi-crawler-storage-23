"""Tests for formatters.py."""

from __future__ import annotations

from defistream_mcp.formatters import (
    build_download_url,
    format_aggregate_response,
    format_download_summary,
    format_events_response,
    format_local_execution_guide,
)


class TestFormatEventsResponse:
    def test_basic(self):
        body = {
            "status": "success",
            "events": [{"block_number": 1, "amount": 10.0}],
            "count": 1,
        }
        result = format_events_response(body, {})
        assert "1 event(s) returned." in result
        assert '"block_number": 1' in result

    def test_quota_headers(self):
        body = {"status": "success", "events": [], "count": 0}
        headers = {"x-request-cost": "5", "x-ratelimit-remaining": "9995"}
        result = format_events_response(body, headers)
        assert "cost=5 blocks" in result
        assert "remaining=9995 blocks" in result

    def test_empty_events(self):
        body = {"status": "success", "events": [], "count": 0}
        result = format_events_response(body, {})
        assert "0 event(s) returned." in result


class TestFormatAggregateResponse:
    def test_basic(self):
        body = {
            "status": "success",
            "data": [{"time": "2025-01-01T00:00:00Z", "agg_amount": 100, "count": 5}],
            "count": 1,
            "group_by": "time",
            "period": "1h",
            "columns_aggregated": [
                {
                    "source_column": "amount",
                    "aggregation": "sum",
                    "output_column": "agg_amount",
                }
            ],
        }
        result = format_aggregate_response(body, {})
        assert "1 bucket(s) returned." in result
        assert "group_by: time" in result
        assert "period: 1h" in result
        assert "agg_amount" in result


class TestFormatDownloadSummary:
    def test_bytes(self):
        assert "512 B" in format_download_summary("/tmp/f.csv", 512)

    def test_kilobytes(self):
        assert "1.5 KB" in format_download_summary("/tmp/f.csv", 1536)

    def test_megabytes(self):
        assert "2.0 MB" in format_download_summary("/tmp/f.csv", 2 * 1024 * 1024)

    def test_includes_path(self):
        result = format_download_summary("/data/out.parquet", 100)
        assert "/data/out.parquet" in result


class TestBuildDownloadUrl:
    def test_basic(self):
        url = build_download_url(
            "https://api.defistream.dev/v1",
            "erc20",
            "transfer",
            {"network": "ETH", "block_start": 100, "block_end": 200, "format": "csv"},
        )
        assert "erc20/events/transfer" in url
        assert "network=ETH" in url
        assert "format=csv" in url

    def test_skips_none(self):
        url = build_download_url(
            "https://api.defistream.dev/v1",
            "aave_v3",
            "deposit",
            {"network": "ETH", "token": None, "block_start": 100},
        )
        assert "token" not in url
        assert "network=ETH" in url


class TestFormatLocalExecutionGuide:
    def test_basic_query(self):
        guide = format_local_execution_guide(
            "/erc20/events/transfer?network=ETH&token=USDT&block_start=100&block_end=200",
            "https://api.defistream.dev/v1",
        )
        # Check structure
        assert "## Query Local Execution Guide" in guide
        assert "**Query**:" in guide
        assert "**Base URL**:" in guide

        # Check curl examples
        assert "### Option 1: curl (CSV)" in guide
        assert "### Option 2: curl (JSON)" in guide
        assert "### Option 3: curl (Parquet download link)" in guide
        assert "X-API-Key: YOUR_API_KEY" in guide

        # Check Python examples
        assert "### Option 4: Python (requests)" in guide
        assert "### Option 5: Python (aiohttp)" in guide
        assert "### Option 7: Python Client Library" in guide

        # Check JavaScript example
        assert "### Option 6: JavaScript (fetch)" in guide

        # Check format options
        assert "### Format Options" in guide
        assert "`format=json`" in guide
        assert "`format=csv`" in guide
        assert "`format=parquet`" in guide
        assert "`link=true`" in guide

    def test_includes_base_url(self):
        guide = format_local_execution_guide(
            "/erc20/events/transfer?network=ETH&token=USDT",
            "https://custom.api.example.com/v1",
        )
        assert "https://custom.api.example.com/v1" in guide

    def test_includes_query_params_in_urls(self):
        guide = format_local_execution_guide(
            "/aave_v3/events/deposit?network=ETH&block_start=100&block_end=200",
            "https://api.defistream.dev/v1",
        )
        # Check that URLs include proper params
        assert "network=ETH" in guide
        assert "block_start=100" in guide
        assert "format=csv" in guide
        assert "format=json" in guide
        assert "link=true" in guide
