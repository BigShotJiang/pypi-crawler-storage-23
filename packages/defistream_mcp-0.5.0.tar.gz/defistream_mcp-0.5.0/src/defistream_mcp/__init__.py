"""DeFiStream MCP Server — Model Context Protocol server for the DeFiStream API."""

__version__ = "0.5.0"
