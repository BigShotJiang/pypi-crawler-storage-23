"""Pure formatting helpers for MCP tool responses."""

from __future__ import annotations

import json
from typing import Any


def format_events_response(
    body: dict[str, Any],
    headers: dict[str, str],
) -> str:
    """Format a JSON events response."""
    events = body.get("events", [])
    total = body.get("count", len(events))

    parts: list[str] = [f"{total} event(s) returned.\n"]
    parts.append(json.dumps(events, indent=2))
    parts.append(_format_quota(headers))
    return "\n".join(parts)


def format_aggregate_response(
    body: dict[str, Any],
    headers: dict[str, str],
) -> str:
    """Format an aggregate query response."""
    data = body.get("data", [])
    parts: list[str] = [
        f"{body.get('count', len(data))} bucket(s) returned.",
        f"group_by: {body.get('group_by', '?')}  period: {body.get('period', '?')}",
    ]

    cols = body.get("columns_aggregated", [])
    if cols:
        col_names = [c.get("output_column", "?") for c in cols]
        parts.append(f"Aggregated columns: {', '.join(col_names)}")

    parts.append("")
    parts.append(json.dumps(data, indent=2))
    parts.append(_format_quota(headers))
    return "\n".join(parts)


def format_download_summary(
    file_path: str,
    size_bytes: int,
) -> str:
    """Summarise a completed file download."""
    if size_bytes < 1024:
        size_str = f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        size_str = f"{size_bytes / 1024:.1f} KB"
    else:
        size_str = f"{size_bytes / (1024 * 1024):.1f} MB"
    return f"Downloaded to {file_path} ({size_str})"


def build_download_url(
    base_url: str,
    protocol: str,
    event_type: str,
    params: dict[str, Any],
) -> str:
    """Build a full download URL for SSE transport."""
    from urllib.parse import urlencode

    qs = urlencode({k: v for k, v in params.items() if v is not None})
    path = f"{base_url}/{protocol}/events/{event_type}"
    return f"{path}?{qs}" if qs else path


def format_link_response(
    body: dict[str, Any],
    headers: dict[str, str],
) -> str:
    """Format a link response from the API."""
    filename = body.get("filename", "unknown")
    link = body.get("link", "")
    expiry = body.get("expiry", "unknown")
    size = body.get("size")

    parts: list[str] = [
        "Download link generated:",
        f"  Filename: {filename}",
        f"  Link: {link}",
        f"  Expires: {expiry}",
    ]

    if size is not None:
        parts.append(f"  Size: {size}")

    parts.append("")
    parts.append("Use directly with polars/pandas:")
    parts.append(f'  pl.read_{"parquet" if filename.endswith(".parquet") else "csv"}("{link}")')
    parts.append(_format_quota(headers))

    return "\n".join(parts)


def _format_quota(headers: dict[str, str]) -> str:
    """Format rate-limit / quota headers into a short summary line."""
    remaining = headers.get("x-ratelimit-remaining")
    cost = headers.get("x-request-cost")
    if not remaining and not cost:
        return ""
    parts = []
    if cost:
        parts.append(f"cost={cost} blocks")
    if remaining:
        parts.append(f"remaining={remaining} blocks")
    return "\n[Quota: " + ", ".join(parts) + "]"


def format_local_execution_guide(query: str, base_url: str) -> str:
    """Format a guide for executing a query locally using various methods."""
    from urllib.parse import parse_qs, urlencode

    # Parse the query to extract components for the Python client example
    if "?" in query:
        path, qs = query.split("?", 1)
        params = parse_qs(qs, keep_blank_values=True)
        # Flatten single-value lists
        params_flat = {k: v[0] if len(v) == 1 else v for k, v in params.items()}
    else:
        path = query
        params_flat = {}

    # Build full URL
    full_url = f"{base_url}{query}"

    # Build URL with CSV format
    csv_params = dict(params_flat)
    csv_params["format"] = "csv"
    csv_qs = urlencode(csv_params)
    csv_url = f"{base_url}{path}?{csv_qs}"

    # Build URL with JSON format
    json_params = dict(params_flat)
    json_params["format"] = "json"
    json_qs = urlencode(json_params)
    json_url = f"{base_url}{path}?{json_qs}"

    # Build URL with parquet + link
    parquet_params = dict(params_flat)
    parquet_params["format"] = "parquet"
    parquet_params["link"] = "true"
    parquet_qs = urlencode(parquet_params)
    parquet_url = f"{base_url}{path}?{parquet_qs}"

    # Extract protocol info for Python client example
    path_parts = path.strip("/").split("/")
    protocol = path_parts[0] if path_parts else "erc20"
    event_type = path_parts[2] if len(path_parts) > 2 else "transfer"

    # Build Python client method call
    client_params = []
    for k, v in params_flat.items():
        if k in ("format", "link", "verbose"):
            continue
        if isinstance(v, str):
            client_params.append(f'{k}="{v}"')
        else:
            client_params.append(f"{k}={v}")
    client_args = ", ".join(client_params)

    guide = f"""## Query Local Execution Guide

**Query**: {query}

**Base URL**: {base_url}

### Option 1: curl (CSV)
```bash
curl -H "X-API-Key: YOUR_API_KEY" \\
  "{csv_url}"
```

### Option 2: curl (JSON)
```bash
curl -H "X-API-Key: YOUR_API_KEY" \\
  "{json_url}"
```

### Option 3: curl (Parquet download link)
```bash
curl -H "X-API-Key: YOUR_API_KEY" \\
  "{parquet_url}"
```

### Option 4: Python (requests)
```python
import requests

headers = {{"X-API-Key": "YOUR_API_KEY"}}
resp = requests.get("{csv_url}", headers=headers)
print(resp.text)
```

### Option 5: Python (aiohttp)
```python
import aiohttp
import asyncio

async def fetch():
    headers = {{"X-API-Key": "YOUR_API_KEY"}}
    async with aiohttp.ClientSession() as session:
        async with session.get("{csv_url}", headers=headers) as resp:
            data = await resp.text()
            print(data)

asyncio.run(fetch())
```

### Option 6: JavaScript (fetch)
```javascript
const resp = await fetch("{csv_url}", {{
  headers: {{ "X-API-Key": "YOUR_API_KEY" }}
}});
const data = await resp.text();
console.log(data);
```

### Option 7: Python Client Library
```python
from defistream import DeFiStream

client = DeFiStream(api_key="YOUR_API_KEY")
df = client.{protocol}.{event_type}({client_args}).as_df()
print(df)
```

### Format Options
- `format=json` — JSON response (max 10,000 blocks)
- `format=csv` — CSV streaming (unlimited blocks)
- `format=parquet` — Parquet file (unlimited blocks)
- `link=true` — Returns shareable download link (1 hour expiry, CSV/Parquet only)
"""
    return guide
