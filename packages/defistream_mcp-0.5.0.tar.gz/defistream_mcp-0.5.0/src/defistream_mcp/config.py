"""Environment-based configuration for the DeFiStream MCP server."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

_PRODUCTION_URL = "https://api.defistream.dev/v1"
_LOCAL_URL = "http://localhost:8081/v1"


def _load_dotenv() -> None:
    """Load .env from mcp-server/ dir and monorepo root. Existing env vars take precedence."""
    pkg_dir = Path(__file__).resolve().parents[2]  # mcp-server/
    load_dotenv(pkg_dir / ".env", override=False)
    # Also try monorepo root (one level up from mcp-server/)
    load_dotenv(pkg_dir.parent / ".env", override=False)


@dataclass(frozen=True)
class ServerConfig:
    """Server configuration loaded from environment variables."""

    api_key: str = ""  # Optional - only for testing/utility tools; users provide their own
    base_url: str = _PRODUCTION_URL
    transport: str = "stdio"
    host: str = "0.0.0.0"  # Bind address for SSE transport
    port: int = 8000  # Port for SSE transport
    download_dir: str = "."
    local: bool = False

    @classmethod
    def from_env(cls) -> ServerConfig:
        """Build config from environment variables.

        Env vars:
            DEFISTREAM_API_KEY      (optional) — API key for utility tools; users provide their own for queries
            DEFISTREAM_LOCAL        (optional) — "true" to use local gateway
            DEFISTREAM_BASE_URL     (optional) — API base URL (overrides --local)
            DEFISTREAM_MCP_TRANSPORT(optional) — "stdio" or "sse"
            DEFISTREAM_MCP_HOST     (optional) — Bind address for SSE (default: 0.0.0.0)
            DEFISTREAM_MCP_PORT     (optional) — Port for SSE (default: 8000)
            DEFISTREAM_DOWNLOAD_DIR (optional) — default download directory
        """
        _load_dotenv()

        # API key is now optional - users provide their own per-request
        api_key = os.environ.get("DEFISTREAM_API_KEY", "")

        local = os.environ.get("DEFISTREAM_LOCAL", "").lower() in ("1", "true", "yes")

        # Explicit DEFISTREAM_BASE_URL takes precedence, then local flag, then production
        explicit_url = os.environ.get("DEFISTREAM_BASE_URL")
        if explicit_url:
            base_url = explicit_url.rstrip("/")
        elif local:
            base_url = _LOCAL_URL
        else:
            base_url = _PRODUCTION_URL

        transport = os.environ.get("DEFISTREAM_MCP_TRANSPORT", "stdio").lower()
        if transport not in ("stdio", "sse", "http"):
            raise ValueError(
                f"DEFISTREAM_MCP_TRANSPORT must be 'stdio', 'sse', or 'http', got '{transport}'"
            )

        host = os.environ.get("DEFISTREAM_MCP_HOST", "0.0.0.0")

        port_str = os.environ.get("DEFISTREAM_MCP_PORT", "8000")
        try:
            port = int(port_str)
        except ValueError:
            raise ValueError(
                f"DEFISTREAM_MCP_PORT must be an integer, got '{port_str}'"
            )

        return cls(
            api_key=api_key,
            base_url=base_url,
            transport=transport,
            host=host,
            port=port,
            download_dir=os.environ.get("DEFISTREAM_DOWNLOAD_DIR", "."),
            local=local,
        )
