"""Async HTTP client wrapper for the DeFiStream API."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

import httpx

from .config import ServerConfig

logger = logging.getLogger(__name__)

_client: DeFiStreamAPIClient | None = None


def get_client() -> DeFiStreamAPIClient:
    """Return the module-level API client. Must call ``init_client`` first."""
    if _client is None:
        raise RuntimeError("API client not initialised — call init_client() first")
    return _client


def init_client(config: ServerConfig) -> DeFiStreamAPIClient:
    """Create and store the module-level API client."""
    global _client
    _client = DeFiStreamAPIClient(config)
    return _client


def create_client_with_key(api_key: str) -> DeFiStreamAPIClient:
    """Create a temporary client with a user-provided API key.

    Uses the base_url and other settings from the global client's config.
    This allows users to authenticate requests with their own API keys.
    """
    if _client is None:
        raise RuntimeError("API client not initialised — call init_client() first")

    temp_config = ServerConfig(
        api_key=api_key,
        base_url=_client.config.base_url,
        transport=_client.config.transport,
        host=_client.config.host,
        port=_client.config.port,
        download_dir=_client.config.download_dir,
        local=_client.config.local,
    )
    return DeFiStreamAPIClient(temp_config)


class DeFiStreamAPIClient:
    """Lightweight async wrapper around the DeFiStream REST API."""

    def __init__(self, config: ServerConfig) -> None:
        self.config = config
        self._http = httpx.AsyncClient(
            base_url=config.base_url,
            headers={"X-API-Key": config.api_key},
            timeout=httpx.Timeout(60.0, connect=10.0),
        )

    async def get_json(
        self,
        path: str,
        params: dict[str, Any] | None = None,
    ) -> tuple[Any, dict[str, str]]:
        """GET *path* and return ``(parsed_json, response_headers)``."""
        resp = await self._http.get(path, params=params)
        resp.raise_for_status()
        headers = {
            k: v
            for k, v in resp.headers.items()
            if k.lower().startswith("x-ratelimit") or k.lower() == "x-request-cost"
        }
        return resp.json(), headers

    async def download_to_file(
        self,
        path: str,
        params: dict[str, Any],
        output_path: Path,
    ) -> int:
        """Stream a GET response to *output_path*. Returns bytes written."""
        total = 0
        async with self._http.stream("GET", path, params=params) as resp:
            resp.raise_for_status()
            with open(output_path, "wb") as f:
                async for chunk in resp.aiter_bytes(chunk_size=65_536):
                    f.write(chunk)
                    total += len(chunk)
        return total

    def build_url(self, path: str, params: dict[str, Any]) -> str:
        """Build the full URL for *path* with query params (for SSE download links)."""
        req = self._http.build_request("GET", path, params=params)
        return str(req.url)

    async def close(self) -> None:
        await self._http.aclose()
