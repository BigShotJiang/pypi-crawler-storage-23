"""DeFiStream MCP Server — entry point."""

from __future__ import annotations

import logging
import sys

from mcp.server.fastmcp import FastMCP

from .api_client import init_client
from .config import ServerConfig
from .resources import register_resources
from .tools import register_tools

# All logging goes to stderr so stdout stays clean for stdio transport.
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)


def create_server(config: ServerConfig) -> FastMCP:
    """Build and wire the FastMCP server instance."""
    # Pass host/port to FastMCP constructor for SSE transport
    mcp = FastMCP("defistream", host=config.host, port=config.port)
    init_client(config)
    register_resources(mcp)
    register_tools(mcp, config)
    return mcp


def main() -> None:
    """CLI entry point (``defistream-mcp``)."""
    try:
        config = ServerConfig.from_env()
    except ValueError as exc:
        logger.error("Configuration error: %s", exc)
        sys.exit(1)

    logger.info(
        "Starting DeFiStream MCP server (transport=%s, base_url=%s)",
        config.transport,
        config.base_url,
    )

    server = create_server(config)

    if config.transport == "http":
        logger.info("HTTP server listening on %s:%d", config.host, config.port)
        server.run(transport="streamable-http")
    elif config.transport == "sse":
        logger.info("SSE server listening on %s:%d", config.host, config.port)
        server.run(transport="sse")
    else:
        server.run(transport="stdio")


if __name__ == "__main__":
    main()
