"""Static MCP resources providing context to LLMs."""

from __future__ import annotations

PROTOCOLS_TEXT = """\
DeFiStream supported protocols and their query builder tools:

- erc20 — ERC-20 token transfer events (USDT, USDC, WETH, …) → erc20_query_builder
- native_token — Native blockchain token transfers (ETH, MATIC, BNB, …) → native_token_query_builder
- aave_v3 — AAVE V3 lending protocol events (deposit, withdraw, borrow, repay, flashloan, liquidation) → aave_v3_query_builder
- uniswap_v3 — Uniswap V3 DEX events (swap, deposit, withdraw, collect) → uniswap_v3_query_builder
- lido — Lido liquid staking events (deposit, withdrawal_request, withdrawal_claimed, l2_deposit, l2_withdrawal_request) → lido_query_builder
- stader — Stader ETHx staking events → stader_query_builder
- threshold — Threshold tBTC bridge events → threshold_query_builder
- binance — Binance exchange data:
  - Raw trades → binance_raw_trades_query_builder (CSV/Parquet only, max 7 days)
  - OHLCV candles → binance_ohlcv_query_builder (JSON, CSV, Parquet, max 31 days)
  - Book depth → binance_book_depth_query_builder (CSV/Parquet only, max 31 days)
  - Open interest → open_interest_query_builder (CSV/Parquet only, max 31 days)
  - Long/short ratios → binance_long_short_ratios_query_builder (CSV/Parquet only, max 31 days)
  - Funding rate → binance_funding_rate_query_builder (CSV/Parquet only, max 31 days)

Workflow:
1. Use a protocol query builder to create a query path.
2. Pass the query path to execute_query() for JSON/CSV results, or download_query_as_link() for CSV/Parquet.
3. Use supported_networks(protocol) to check if a network is valid before building queries.
"""

API_LIMITS_TEXT = """\
DeFiStream API limits and constraints:

Per-provider range limits:

  ERC-20 / Native Token:
    - Max time range: 7 days
    - Max block range (CSV/Parquet): 1,000,000 blocks (10,000,000 for ARB)
    - Max block range (JSON): 10,000 blocks

  AAVE V3 / Uniswap V3 / Lido / Stader / Threshold:
    - Max time range: 31 days
    - Max block range (CSV/Parquet): 10,000,000 blocks
    - Max block range (JSON): 10,000 blocks

Range specification (one required):
  - block_start + block_end  (integer block numbers)
  - since + until            (ISO 8601 timestamps or Unix seconds)
  Cannot mix block range with time range.

execute_query tool:
  - Returns results as CSV.
  - For very large ranges, use download_query_as_link instead.

download_query_as_link tool:
  - Returns a shareable download link (CSV or Parquet).

Quota:
  - Each request costs blocks from your monthly block budget.
  - Cost formula: max(100, round(block_range × network_discount × aggregate_discount)).
  - Response headers report remaining quota.

Rate limiting:
  - basic plan: 60 req/min
  - pro plan: 300 req/min
"""


def register_resources(mcp):  # noqa: ANN001
    """Register static resources on the FastMCP instance."""

    @mcp.resource("defistream://protocols")
    def protocols_resource() -> str:
        """Overview of all DeFiStream protocols."""
        return PROTOCOLS_TEXT

    @mcp.resource("defistream://api-limits")
    def api_limits_resource() -> str:
        """API limits, block range caps, and quota information."""
        return API_LIMITS_TEXT
