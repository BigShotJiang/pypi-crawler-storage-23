"""
Artificial Bee Colony (ABC) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class ArtificialBeeColony(BaseOptimizer):
    """
    Artificial Bee Colony algorithm for Neural Architecture Search.
    
    ABC simulates the foraging behavior of honey bee colonies. It employs three
    types of bees: employed bees, onlooker bees, and scout bees.
    
    - Employed bees exploit food sources (solutions)
    - Onlooker bees choose food sources based on quality (waggle dance)
    - Scout bees randomly search for new food sources when old ones are abandoned
    
    Attributes:
        colony_size: Number of employed/onlooker bees
        limit: Maximum trials before abandoning a food source
        max_iterations: Maximum number of iterations
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Artificial Bee Colony Optimizer.
        
        Args:
            settings: Dictionary containing:
                - colony_size: Number of employed bees (default: 10)
                - limit: Abandonment threshold (default: 5)
                - max_iterations: Maximum iterations (default: 10)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.colony_size = settings.get('colony_size', 10)
        self.limit = settings.get('limit', 5)
        self.max_iterations = settings.get('max_iterations', 10)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.bee_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize food sources
        self.food_sources = self._initialize_sources()
        self.trials = np.zeros(self.colony_size)
        
        # Bee phases
        self._phase = "employed"
        self._current_new_position = None
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """
        Create a mapping from continuous position vector to discrete architecture.
        
        Returns:
            Tuple of (topology_map, dimensions)
        """
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_sources(self) -> List[Dict[str, Any]]:
        """
        Initialize food sources with random positions.
        
        Returns:
            List of food source dictionaries
        """
        sources = []
        for _ in range(self.colony_size):
            position = np.random.rand(self.dimensions)
            source = {
                'position': position.copy(),
                'reward': -1.0,
            }
            sources.append(source)
        return sources
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """
        Convert a continuous position vector to a discrete neural network topology.
        
        Args:
            position: Continuous position vector in [0, 1]^d
            
        Returns:
            List of layer dictionaries defining the architecture
        """
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], np.ndarray]:
        """
        Generate the next topology to evaluate.
        
        Cycles through employed bees and then onlooker bees.
        
        Returns:
            Tuple of (bee_index, topology, new_position)
        """
        bee_to_evaluate = self.bee_index % self.colony_size
        
        if self._phase == "employed":
            # Employed bees explore near their current source
            current_pos = self.food_sources[bee_to_evaluate]['position']
            partner_idx = random.choice([i for i in range(self.colony_size) if i != bee_to_evaluate])
            partner_pos = self.food_sources[partner_idx]['position']
            
            # Create a new candidate position using ABC equation
            new_pos = current_pos.copy()
            dim_to_change = random.randint(0, self.dimensions - 1)
            phi = random.uniform(-1, 1)
            new_pos[dim_to_change] = current_pos[dim_to_change] + phi * (
                current_pos[dim_to_change] - partner_pos[dim_to_change]
            )
            new_pos = np.clip(new_pos, 0, 1)
            
            topology = self._discretize_position(new_pos)
            self._current_new_position = new_pos
            
            return bee_to_evaluate, topology, new_pos
        
        elif self._phase == "onlooker":
            # Onlooker bees choose a source based on fitness (waggle dance)
            fitness = np.array([max(0, s['reward']) for s in self.food_sources])
            total_fitness = np.sum(fitness)
            
            if total_fitness == 0:
                chosen_source_idx = random.randint(0, self.colony_size - 1)
            else:
                probabilities = fitness / total_fitness
                chosen_source_idx = np.random.choice(range(self.colony_size), p=probabilities)
            
            # Onlooker explores near the chosen source
            current_pos = self.food_sources[chosen_source_idx]['position']
            partner_idx = random.choice([i for i in range(self.colony_size) if i != chosen_source_idx])
            partner_pos = self.food_sources[partner_idx]['position']
            
            new_pos = current_pos.copy()
            dim_to_change = random.randint(0, self.dimensions - 1)
            phi = random.uniform(-1, 1)
            new_pos[dim_to_change] = current_pos[dim_to_change] + phi * (
                current_pos[dim_to_change] - partner_pos[dim_to_change]
            )
            new_pos = np.clip(new_pos, 0, 1)
            
            topology = self._discretize_position(new_pos)
            self._current_new_position = new_pos
            
            return chosen_source_idx, topology, new_pos
    
    def update(self, bee_index: int, reward: float, state: Optional[np.ndarray] = None) -> None:
        """
        Update the food source based on the reward (greedy selection).
        
        Args:
            bee_index: Index of the food source being updated
            reward: The accuracy/fitness achieved
            state: The new position that was evaluated
        """
        new_position = state if state is not None else self._current_new_position
        
        # Greedy selection: keep the better solution
        if reward > self.food_sources[bee_index]['reward']:
            self.food_sources[bee_index]['position'] = new_position.copy()
            self.food_sources[bee_index]['reward'] = reward
            self.trials[bee_index] = 0
        else:
            self.trials[bee_index] += 1
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(new_position)
        
        # Move to the next bee
        self.bee_index += 1
        
        # Check if we need to switch phases or run scout phase
        if self.bee_index % self.colony_size == 0:
            if self._phase == "employed":
                self._phase = "onlooker"
            elif self._phase == "onlooker":
                self._run_scout_phase()
                self._phase = "employed"
                self.iteration += 1
    
    def _run_scout_phase(self) -> None:
        """
        Check for abandoned food sources and replace them with new random ones.
        """
        for i in range(self.colony_size):
            if self.trials[i] >= self.limit:
                # Abandon this source and become a scout
                self.food_sources[i]['position'] = np.random.rand(self.dimensions)
                self.food_sources[i]['reward'] = -1.0
                self.trials[i] = 0
    
    def is_finished(self) -> bool:
        """
        Check if optimization is complete.
        
        Returns:
            True if maximum iterations reached
        """
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state for checkpointing.
        
        Returns:
            Dictionary containing all state needed to resume
        """
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'bee_index': self.bee_index,
            'phase': self._phase,
            'food_sources': [{
                'position': s['position'].tolist(),
                'reward': s['reward']
            } for s in self.food_sources],
            'trials': self.trials.tolist()
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """
        Restore the optimizer state from a checkpoint.
        
        Args:
            state: Dictionary containing previously saved state
        """
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.bee_index = state.get('bee_index', 0)
        self._phase = state.get('phase', 'employed')
        
        sources_state = state.get('food_sources', [])
        self.food_sources = []
        for s_state in sources_state:
            self.food_sources.append({
                'position': np.array(s_state['position']),
                'reward': s_state['reward']
            })
        
        self.trials = np.array(state.get('trials', np.zeros(self.colony_size)))