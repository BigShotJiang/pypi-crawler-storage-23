"""
Ant Colony Optimization (ACO) for Neural Architecture Search.
"""

import random
import copy
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class AntColony(BaseOptimizer):
    """
    Ant Colony Optimization algorithm for Neural Architecture Search.
    
    ACO simulates the foraging behavior of ants to find optimal paths (architectures).
    Pheromone trails guide the search toward promising regions of the search space.
    
    Attributes:
        alpha: Relative importance of pheromone trail
        beta: Relative importance of heuristic information (not used in basic version)
        rho: Pheromone evaporation rate
        q: Constant for pheromone deposit
        max_iterations: Maximum number of ants to deploy
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Ant Colony Optimizer.
        
        Args:
            settings: Dictionary containing:
                - alpha: Pheromone importance (default: 1.0)
                - beta: Heuristic importance (default: 1.0)
                - rho: Evaporation rate (default: 0.1)
                - q: Pheromone deposit constant (default: 1.0)
                - max_iterations: Number of ants to deploy (default: 10)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.alpha = settings.get('alpha', 1.0)
        self.beta = settings.get('beta', 1.0)
        self.rho = settings.get('rho', 0.1)
        self.q = settings.get('q', 1.0)
        self.max_iterations = settings.get('max_iterations', 10)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.ant_count = settings.get('ant_count', self.max_iterations)
        self.pheromones = self._initialize_pheromones()
        
        # Current topology being evaluated (for pheromone deposit)
        self._current_topology = None
        self._local_best_reward = -1.0
    
    def _initialize_pheromones(self) -> Dict[str, Dict[str, Dict[Any, float]]]:
        """
        Initialize pheromone trails for all parameters in the search space.
        
        Returns:
            Nested dictionary of pheromone values for each parameter choice
        """
        pheromones = {}
        for node_type, params in self.search_space.items():
            pheromones[node_type] = {}
            for param, values in params.items():
                if isinstance(values, list):
                    pheromones[node_type][param] = {value: 1.0 for value in values}
        return pheromones
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], None]:
        """
        Generate a neural network topology using ant-based path selection.
        
        Returns:
            Tuple of (ant_id, topology, None) - no additional state needed for ACO
        """
        self.iteration += 1
        topology = self._build_topology()
        # Store current topology for pheromone deposit in update
        self._current_topology = topology
        return self.iteration - 1, topology, None
    
    def _build_topology(self) -> List[Dict[str, Any]]:
        """
        Build a topology by having an ant traverse the search space.
        
        Returns:
            List of layer dictionaries defining the neural network architecture
        """
        topology = []
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            node = {'type': layer_type}
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        choices = self.pheromones[layer_type][param]
                        chosen_value = self._probabilistic_choice(choices)
                        node[param] = chosen_value
            topology.append(node)
        
        return topology
    
    def _probabilistic_choice(self, choices: Dict[Any, float]) -> Any:
        """
        Make a probabilistic choice based on pheromone levels.
        
        Args:
            choices: Dictionary mapping values to pheromone levels
            
        Returns:
            The chosen value based on probability distribution
        """
        total_pheromone = sum(choices.values())
        if total_pheromone == 0:
            return random.choice(list(choices.keys()))
        
        probabilities = [p / total_pheromone for p in choices.values()]
        chosen = random.choices(list(choices.keys()), weights=probabilities, k=1)[0]
        return chosen
    
    def update(self, agent_id: int, reward: float, state: Optional[Any] = None) -> None:
        """
        Update pheromone trails based on the reward achieved.
        
        Args:
            agent_id: Identifier for the ant (not used in ACO)
            reward: The accuracy/fitness achieved by the topology
            state: Not used in ACO
        """
        # Evaporate all pheromones
        self._evaporate_pheromones()
        
        # Deposit pheromone based on reward using the current topology
        if reward > 0 and self._current_topology is not None:
            self._deposit_pheromone(self._current_topology, reward)
        
        # Update global best (only for positive rewards)
        if reward > 0 and reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = copy.deepcopy(self._current_topology)
        
        # Update local best
        if reward > self._local_best_reward:
            self._local_best_reward = reward
    
    def _evaporate_pheromones(self) -> None:
        """Apply pheromone evaporation to all trails."""
        for node_type in self.pheromones:
            for param in self.pheromones[node_type]:
                for value in self.pheromones[node_type][param]:
                    self.pheromones[node_type][param][value] *= (1 - self.rho)
    
    def _deposit_pheromone(self, topology: List[Dict[str, Any]], reward: float) -> None:
        """
        Deposit pheromone on the paths taken by successful ants.
        
        Args:
            topology: The architecture that achieved the reward
            reward: The reward achieved
        """
        deposit = self.q * (reward / 100.0)  # Normalize reward
        
        for node in topology:
            node_type = node['type']
            if node_type in self.search_space:
                for param, chosen_value in node.items():
                    if param != 'type' and param in self.pheromones[node_type]:
                        if chosen_value in self.pheromones[node_type][param]:
                            self.pheromones[node_type][param][chosen_value] += deposit
        
        # Update global best topology
        if reward > self._global_best_reward:
            self._global_best_topology = copy.deepcopy(topology)
    
    def is_finished(self) -> bool:
        """
        Check if the optimization is complete.
        
        Returns:
            True if maximum iterations reached
        """
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state for checkpointing.
        
        Returns:
            Dictionary containing all state needed to resume
        """
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'pheromones': copy.deepcopy(self.pheromones),
            'local_best_reward': self._local_best_reward,
            'current_topology': copy.deepcopy(self._current_topology)
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """
        Restore the optimizer state from a checkpoint.
        
        Args:
            state: Dictionary containing previously saved state
        """
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.pheromones = state.get('pheromones', self._initialize_pheromones())
        self._local_best_reward = state.get('local_best_reward', -1.0)
        self._current_topology = state.get('current_topology', None)
