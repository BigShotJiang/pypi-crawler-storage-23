"""
Bat Algorithm (BA) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class BatAlgorithm(BaseOptimizer):
    """
    Bat Algorithm for Neural Architecture Search.
    
    BA is inspired by the echolocation behavior of microbats. Bats emit
    ultrasound pulses and listen to the echoes to detect and locate prey.
    The algorithm balances exploration and exploitation through:
    - Frequency tuning (exploration)
    - Loudness and pulse rate control (exploitation)
    
    Attributes:
        population_size: Number of bats
        max_iterations: Maximum number of iterations
        f_min: Minimum frequency (default: 0)
        f_max: Maximum frequency (default: 2)
        alpha: Loudness decay rate (default: 0.9)
        gamma: Pulse rate increase rate (default: 0.9)
        r0: Initial pulse rate (default: 0.5)
        a0: Initial loudness (default: 0.5)
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Bat Algorithm.
        
        Args:
            settings: Dictionary containing:
                - population_size: Number of bats (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - f_min: Minimum frequency (default: 0)
                - f_max: Maximum frequency (default: 2)
                - alpha: Loudness decay (default: 0.9)
                - gamma: Pulse rate increase (default: 0.9)
                - r0: Initial pulse rate (default: 0.5)
                - a0: Initial loudness (default: 0.5)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.population_size = settings.get('population_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.f_min = settings.get('f_min', 0)
        self.f_max = settings.get('f_max', 2)
        self.alpha = settings.get('alpha', 0.9)
        self.gamma = settings.get('gamma', 0.9)
        self.r0 = settings.get('r0', 0.5)
        self.a0 = settings.get('a0', 0.5)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.bat_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize bats
        self.bats = self._initialize_bats()
        self._best_position = np.zeros(self.dimensions)
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_bats(self) -> List[Dict[str, Any]]:
        """Initialize bats with random positions, velocities, and parameters."""
        bats = []
        for _ in range(self.population_size):
            position = np.random.rand(self.dimensions)
            bat = {
                'position': position.copy(),
                'velocity': np.zeros(self.dimensions),
                'frequency': 0,
                'pulse_rate': self.r0,
                'loudness': self.a0,
                'reward': -1.0,
            }
            bats.append(bat)
        return bats
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _update_best(self) -> None:
        """Update the best position found."""
        best_bat = max(self.bats, key=lambda b: b['reward'])
        if best_bat['reward'] > self._global_best_reward:
            self._best_position = best_bat['position'].copy()
            self._global_best_reward = best_bat['reward']
            self._global_best_topology = self._discretize_position(self._best_position)
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], np.ndarray]:
        """
        Generate a new position for the current bat.
        
        Returns:
            Tuple of (bat_index, topology, new_position)
        """
        bat = self.bats[self.bat_index]
        
        # Update frequency
        beta = random.random()
        bat['frequency'] = self.f_min + (self.f_max - self.f_min) * beta
        
        # Update velocity
        bat['velocity'] = bat['velocity'] + (bat['position'] - self._best_position) * bat['frequency']
        
        # Generate new position
        if random.random() > bat['pulse_rate']:
            # Local search: random walk around best solution
            avg_loudness = np.mean([b['loudness'] for b in self.bats])
            epsilon = (random.random() * 2 - 1) * avg_loudness
            new_position = self._best_position + epsilon
        else:
            # Global search: move based on velocity
            new_position = bat['position'] + bat['velocity']
        
        new_position = np.clip(new_position, 0, 1)
        topology = self._discretize_position(new_position)
        
        return self.bat_index, topology, new_position
    
    def update(self, bat_index: int, reward: float, state: Optional[np.ndarray] = None) -> None:
        """
        Update bat position if new solution is better.
        
        Args:
            bat_index: Index of the bat
            reward: Reward achieved by the candidate solution
            state: The new position that was evaluated
        """
        bat = self.bats[bat_index]
        new_position = state
        
        # Accept new solution with probability based on loudness
        if reward > bat['reward'] and random.random() < bat['loudness']:
            bat['position'] = new_position.copy()
            bat['reward'] = reward
            
            # Update loudness and pulse rate
            bat['loudness'] *= self.alpha
            bat['pulse_rate'] = self.r0 * (1 - np.exp(-self.gamma * self.iteration))
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(new_position)
        
        self.bat_index += 1
        if self.bat_index >= self.population_size:
            self.bat_index = 0
            self.iteration += 1
            self._update_best()
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'bat_index': self.bat_index,
            'bats': [{
                'position': b['position'].tolist(),
                'velocity': b['velocity'].tolist(),
                'frequency': b['frequency'],
                'pulse_rate': b['pulse_rate'],
                'loudness': b['loudness'],
                'reward': b['reward']
            } for b in self.bats],
            'best_position': self._best_position.tolist(),
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.bat_index = state.get('bat_index', 0)
        
        bats_state = state.get('bats', [])
        self.bats = []
        for b_state in bats_state:
            self.bats.append({
                'position': np.array(b_state['position']),
                'velocity': np.array(b_state['velocity']),
                'frequency': b_state['frequency'],
                'pulse_rate': b_state['pulse_rate'],
                'loudness': b_state['loudness'],
                'reward': b_state['reward']
            })
        
        self._best_position = np.array(state.get('best_position', np.zeros(self.dimensions)))