"""
Grey Wolf Optimizer (GWO) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class GreyWolfOptimizer(BaseOptimizer):
    """
    Grey Wolf Optimizer algorithm for Neural Architecture Search.
    
    GWO mimics the leadership hierarchy and hunting mechanism of grey wolves.
    The population is divided into four groups: alpha (α), beta (β), delta (δ),
    and omega (ω). The first three are the best solutions, while omega wolves
    follow the leadership.
    
    Attributes:
        pack_size: Number of wolves in the pack
        max_iterations: Maximum number of iterations
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Grey Wolf Optimizer.
        
        Args:
            settings: Dictionary containing:
                - pack_size: Number of wolves (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.pack_size = settings.get('pack_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.wolf_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize pack
        self.pack = self._initialize_pack()
        
        # Alpha, Beta, Delta wolves (top 3 best solutions)
        self._alpha_position = np.zeros(self.dimensions)
        self._alpha_reward = -1.0
        self._beta_position = np.zeros(self.dimensions)
        self._beta_reward = -1.0
        self._delta_position = np.zeros(self.dimensions)
        self._delta_reward = -1.0
        
        self._update_hierarchy()
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_pack(self) -> List[Dict[str, Any]]:
        """Initialize the wolf pack with random positions."""
        pack = []
        for _ in range(self.pack_size):
            position = np.random.rand(self.dimensions)
            wolf = {
                'position': position.copy(),
                'reward': -1.0,
            }
            pack.append(wolf)
        return pack
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _update_hierarchy(self) -> None:
        """Update alpha, beta, delta based on current rewards."""
        # Sort pack by reward
        sorted_pack = sorted(self.pack, key=lambda w: w['reward'], reverse=True)
        
        if sorted_pack[0]['reward'] > self._alpha_reward:
            self._alpha_reward = sorted_pack[0]['reward']
            self._alpha_position = sorted_pack[0]['position'].copy()
            self._global_best_reward = self._alpha_reward
            self._global_best_topology = self._discretize_position(self._alpha_position)
        
        if len(sorted_pack) > 1 and sorted_pack[1]['reward'] > self._beta_reward:
            self._beta_reward = sorted_pack[1]['reward']
            self._beta_position = sorted_pack[1]['position'].copy()
        
        if len(sorted_pack) > 2 and sorted_pack[2]['reward'] > self._delta_reward:
            self._delta_reward = sorted_pack[2]['reward']
            self._delta_position = sorted_pack[2]['position'].copy()
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], None]:
        """Get the next wolf's topology for evaluation."""
        wolf = self.pack[self.wolf_index]
        topology = self._discretize_position(wolf['position'])
        
        return self.wolf_index, topology, None
    
    def _update_positions(self) -> None:
        """Update all wolf positions based on GWO equations."""
        # a decreases linearly from 2 to 0
        a = 2 - self.iteration * (2 / self.max_iterations)
        
        for i, wolf in enumerate(self.pack):
            # Calculate distance to alpha, beta, delta
            r1, r2 = random.random(), random.random()
            a_alpha = 2 * a * r1 - a
            c_alpha = 2 * r2
            d_alpha = abs(c_alpha * self._alpha_position - wolf['position'])
            x1 = self._alpha_position - a_alpha * d_alpha
            
            r1, r2 = random.random(), random.random()
            a_beta = 2 * a * r1 - a
            c_beta = 2 * r2
            d_beta = abs(c_beta * self._beta_position - wolf['position'])
            x2 = self._beta_position - a_beta * d_beta
            
            r1, r2 = random.random(), random.random()
            a_delta = 2 * a * r1 - a
            c_delta = 2 * r2
            d_delta = abs(c_delta * self._delta_position - wolf['position'])
            x3 = self._delta_position - a_delta * d_delta
            
            # New position is average of the three
            wolf['position'] = np.clip((x1 + x2 + x3) / 3, 0, 1)
            wolf['reward'] = -1.0  # Reset reward for new position
    
    def update(self, wolf_index: int, reward: float, state: Optional[Any] = None) -> None:
        """Update wolf's reward and check hierarchy update."""
        self.pack[wolf_index]['reward'] = reward
        
        # Update hierarchy immediately after each evaluation
        self._update_hierarchy()
        
        self.wolf_index += 1
        if self.wolf_index >= self.pack_size:
            self._update_positions()
            self.wolf_index = 0
            self.iteration += 1
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'wolf_index': self.wolf_index,
            'pack': [{
                'position': w['position'].tolist(),
                'reward': w['reward']
            } for w in self.pack],
            'alpha_position': self._alpha_position.tolist(),
            'alpha_reward': self._alpha_reward,
            'beta_position': self._beta_position.tolist(),
            'beta_reward': self._beta_reward,
            'delta_position': self._delta_position.tolist(),
            'delta_reward': self._delta_reward,
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.wolf_index = state.get('wolf_index', 0)
        
        pack_state = state.get('pack', [])
        self.pack = []
        for w_state in pack_state:
            self.pack.append({
                'position': np.array(w_state['position']),
                'reward': w_state['reward']
            })
        
        self._alpha_position = np.array(state.get('alpha_position', np.zeros(self.dimensions)))
        self._alpha_reward = state.get('alpha_reward', -1.0)
        self._beta_position = np.array(state.get('beta_position', np.zeros(self.dimensions)))
        self._beta_reward = state.get('beta_reward', -1.0)
        self._delta_position = np.array(state.get('delta_position', np.zeros(self.dimensions)))
        self._delta_reward = state.get('delta_reward', -1.0)