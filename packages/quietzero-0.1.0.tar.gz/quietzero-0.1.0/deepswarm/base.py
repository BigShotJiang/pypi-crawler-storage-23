"""
Base optimizer interface for all swarm intelligence algorithms.
"""

from abc import ABC, abstractmethod
from typing import Tuple, List, Dict, Any, Optional


class BaseOptimizer(ABC):
    """
    Abstract base class for all swarm optimization algorithms.
    
    All swarm algorithms (ACO, PSO, ABC, GWO, etc.) must implement this interface
    to work with the DeepSwarm architecture search framework.
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the optimizer with settings.
        
        Args:
            settings: Dictionary containing algorithm-specific parameters
        """
        self.settings = settings
        self._global_best_reward = -1.0
        self._global_best_topology = None
    
    @abstractmethod
    def generate_topology(self) -> Tuple[int, Dict[str, Any], Optional[Any]]:
        """
        Generate the next neural network topology to evaluate.
        
        Returns:
            Tuple containing:
                - agent_id (int): Identifier for the agent (ant, particle, bee, etc.)
                - topology (dict): The neural network topology to evaluate
                - state (Any, optional): Additional state to pass back during update.
                                         None if not needed by the algorithm.
        """
        pass
    
    @abstractmethod
    def update(self, agent_id: int, reward: float, state: Optional[Any] = None) -> None:
        """
        Update the optimizer state after evaluating a topology.
        
        Args:
            agent_id: The identifier of the agent that was evaluated
            reward: The reward (accuracy/fitness) achieved by the topology
            state: Optional state returned by generate_topology (e.g., new position for ABC)
        """
        pass
    
    @abstractmethod
    def is_finished(self) -> bool:
        """
        Check if the optimization process is complete.
        
        Returns:
            True if the algorithm has finished (e.g., max iterations reached)
        """
        pass
    
    @property
    def global_best_reward(self) -> float:
        """
        Get the best reward found so far.
        
        Returns:
            The highest reward achieved across all evaluations
        """
        return self._global_best_reward
    
    @property
    def global_best_topology(self) -> Optional[List[Dict[str, Any]]]:
        """
        Get the best topology found so far.
        
        Returns:
            The topology that achieved the global best reward
        """
        return self._global_best_topology
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state of the optimizer for checkpointing.
        
        Returns:
            Dictionary containing all state needed to resume optimization
        """
        return {
            'settings': self.settings,
            'global_best_reward': self._global_best_reward,
            'global_best_topology': self._global_best_topology
        }
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """
        Restore the optimizer state from a checkpoint.
        
        Args:
            state: Dictionary containing previously saved state
        """
        self._global_best_reward = state.get('global_best_reward', -1.0)
        self._global_best_topology = state.get('global_best_topology', None)