"""
Firefly Algorithm (FA) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class FireflyAlgorithm(BaseOptimizer):
    """
    Firefly Algorithm for Neural Architecture Search.
    
    FA is inspired by the flashing behavior of fireflies. The algorithm
    is based on three rules:
    1. All fireflies are unisex and attracted to other fireflies
    2. Attractiveness is proportional to brightness (fitness)
    3. Brightness decreases with distance (light absorption)
    
    Attributes:
        population_size: Number of fireflies
        max_iterations: Maximum number of iterations
        alpha: Randomization parameter (default: 0.2)
        beta0: Attractiveness at r=0 (default: 1.0)
        gamma: Light absorption coefficient (default: 1.0)
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Firefly Algorithm.
        
        Args:
            settings: Dictionary containing:
                - population_size: Number of fireflies (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - alpha: Randomization parameter (default: 0.2)
                - beta0: Base attractiveness (default: 1.0)
                - gamma: Light absorption coefficient (default: 1.0)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.population_size = settings.get('population_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.alpha = settings.get('alpha', 0.2)
        self.beta0 = settings.get('beta0', 1.0)
        self.gamma = settings.get('gamma', 1.0)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.firefly_i = 0
        self.firefly_j = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize fireflies
        self.fireflies = self._initialize_fireflies()
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_fireflies(self) -> List[Dict[str, Any]]:
        """Initialize fireflies with random positions."""
        fireflies = []
        for _ in range(self.population_size):
            position = np.random.rand(self.dimensions)
            firefly = {
                'position': position.copy(),
                'reward': -1.0,
            }
            fireflies.append(firefly)
        return fireflies
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _calculate_distance(self, x1: np.ndarray, x2: np.ndarray) -> float:
        """Calculate Euclidean distance between two fireflies."""
        return np.sqrt(np.sum((x1 - x2) ** 2))
    
    def _calculate_attractiveness(self, r: float) -> float:
        """Calculate attractiveness based on distance."""
        return self.beta0 * np.exp(-self.gamma * r ** 2)
    
    def generate_topology(self) -> Tuple[Tuple[int, int], List[Dict[str, Any]], np.ndarray]:
        """
        Generate movement for firefly i towards firefly j.
        
        Returns:
            Tuple of ((i, j), topology, new_position)
        """
        fi = self.fireflies[self.firefly_i]
        fj = self.fireflies[self.firefly_j]
        
        # Move firefly i towards j if j is brighter
        if fj['reward'] > fi['reward']:
            r = self._calculate_distance(fi['position'], fj['position'])
            beta = self._calculate_attractiveness(r)
            
            # Movement equation
            new_position = fi['position'] + beta * (fj['position'] - fi['position'])
            new_position = np.clip(new_position, 0, 1)
        else:
            new_position = fi['position'].copy()
        
        topology = self._discretize_position(new_position)
        
        return (self.firefly_i, self.firefly_j), topology, new_position
    
    def _apply_random_movement(self) -> None:
        """Apply random movement to all fireflies."""
        for firefly in self.fireflies:
            # Add small random perturbation
            epsilon = self.alpha * (np.random.rand(self.dimensions) - 0.5)
            firefly['position'] = np.clip(firefly['position'] + epsilon, 0, 1)
    
    def update(self, indices: Tuple[int, int], reward: float, state: Optional[np.ndarray] = None) -> None:
        """
        Update firefly position if new position is better.
        
        Args:
            indices: Tuple of (i, j) firefly indices
            reward: Reward achieved by the candidate solution
            state: The new position that was evaluated
        """
        i, j = indices
        new_position = state
        
        # Update if better
        if reward > self.fireflies[i]['reward']:
            self.fireflies[i]['position'] = new_position.copy()
            self.fireflies[i]['reward'] = reward
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(new_position)
        
        # Advance indices
        self.firefly_j += 1
        if self.firefly_j >= self.population_size:
            self.firefly_i += 1
            self.firefly_j = 0
        
        if self.firefly_i >= self.population_size:
            # End of iteration - apply random movement and restart
            self._apply_random_movement()
            self.firefly_i = 0
            self.firefly_j = 0
            self.iteration += 1
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'firefly_i': self.firefly_i,
            'firefly_j': self.firefly_j,
            'fireflies': [{
                'position': f['position'].tolist(),
                'reward': f['reward']
            } for f in self.fireflies],
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.firefly_i = state.get('firefly_i', 0)
        self.firefly_j = state.get('firefly_j', 0)
        
        fireflies_state = state.get('fireflies', [])
        self.fireflies = []
        for f_state in fireflies_state:
            self.fireflies.append({
                'position': np.array(f_state['position']),
                'reward': f_state['reward']
            })