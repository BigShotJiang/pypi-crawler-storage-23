import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np

class DynamicNet(nn.Module):
    def __init__(self, topology, input_shape, output_shape):
        super(DynamicNet, self).__init__()
        self.layers = nn.ModuleList()
        self._build_model(topology, input_shape, output_shape)

    def _build_model(self, topology, input_shape, output_shape):
        in_channels = input_shape[0]
        h, w = input_shape[1], input_shape[2]
        is_flattened = False
        in_features = 0

        for layer_info in topology:
            layer_type = layer_info['type'].lower()
            if 'conv2d' in layer_type:
                out_channels = layer_info['filters']
                self.layers.append(nn.Conv2d(in_channels, out_channels, kernel_size=layer_info['kernel_size'], padding='same'))
                self.layers.append(nn.ReLU())
                in_channels = out_channels
            elif 'pool2d' in layer_type:
                pool_size = layer_info['pool_size']
                self.layers.append(nn.MaxPool2d(kernel_size=pool_size, stride=pool_size))
                h //= pool_size
                w //= pool_size
            elif 'flatten' in layer_type:
                if not is_flattened:
                    self.layers.append(nn.Flatten())
                    is_flattened = True
                    in_features = in_channels * h * w
            elif 'dense' in layer_type:
                if not is_flattened:
                    self.layers.append(nn.Flatten())
                    is_flattened = True
                    in_features = in_channels * h * w
                
                out_features = layer_info['units']
                self.layers.append(nn.Linear(in_features, out_features))
                in_features = out_features # For the next dense layer
                
                activation = layer_info.get('activation', 'relu')
                if activation == 'relu':
                    self.layers.append(nn.ReLU())
        
        # Add final output layer
        self.layers.append(nn.Linear(in_features, output_shape))

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

class PyTorchBackend:
    def __init__(self, gpus=0):
        self.device = torch.device("cuda" if gpus > 0 and torch.cuda.is_available() else "cpu")
        print(f"Using {self.device} for training.")

    def create_model(self, topology, input_shape, output_shape):
        model = DynamicNet(topology, input_shape, output_shape).to(self.device)
        return model

    def train_model(self, model, dataset, batch_size, epochs, verbose=1):
        X_train = torch.from_numpy(dataset.training_examples).float()
        y_train = torch.from_numpy(dataset.training_labels).long()
        train_dataset = TensorDataset(X_train, y_train)
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters())
        model.train()
        for epoch in range(epochs):
            for inputs, labels in train_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

    def evaluate_model(self, model, dataset, batch_size):
        X_test = torch.from_numpy(dataset.testing_examples).float()
        y_test = torch.from_numpy(dataset.testing_labels).long()
        test_dataset = TensorDataset(X_test, y_test)
        test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for inputs, labels in test_loader:
                inputs, labels = inputs.to(self.device), labels.to(self.device)
                outputs = model(inputs)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()
        return 100 * correct / total