"""
Cuckoo Search (CS) for Neural Architecture Search.
"""

import random
import copy
import math
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class CuckooSearch(BaseOptimizer):
    """
    Cuckoo Search algorithm for Neural Architecture Search.
    
    CS is inspired by the brood parasitism of some cuckoo species. It uses
    Lévy flights for exploration, which provides a good balance between
    local and global search capabilities.
    
    Attributes:
        population_size: Number of nests (host nests)
        pa: Probability of alien eggs being discovered (abandonment rate)
        max_iterations: Maximum number of iterations
        beta: Lévy flight exponent (default: 1.5)
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Cuckoo Search Optimizer.
        
        Args:
            settings: Dictionary containing:
                - population_size: Number of nests (default: 10)
                - pa: Abandonment probability (default: 0.25)
                - max_iterations: Maximum iterations (default: 10)
                - beta: Lévy exponent (default: 1.5)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.population_size = settings.get('population_size', 10)
        self.pa = settings.get('pa', 0.25)
        self.max_iterations = settings.get('max_iterations', 10)
        self.beta = settings.get('beta', 1.5)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.nest_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize nests
        self.nests = self._initialize_nests()
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_nests(self) -> List[Dict[str, Any]]:
        """Initialize nests with random positions."""
        nests = []
        for _ in range(self.population_size):
            position = np.random.rand(self.dimensions)
            nest = {
                'position': position.copy(),
                'reward': -1.0,
            }
            nests.append(nest)
        return nests
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _levy_flight(self) -> np.ndarray:
        """
        Generate a Lévy flight step.
        
        Uses Mantegna's algorithm to generate Lévy distributed random numbers.
        
        Returns:
            Lévy flight step vector
        """
        sigma = (math.gamma(1 + self.beta) * np.sin(np.pi * self.beta / 2) /
                 (math.gamma((1 + self.beta) / 2) * self.beta * 2 ** ((self.beta - 1) / 2))) ** (1 / self.beta)
        
        u = np.random.randn(self.dimensions) * sigma
        v = np.random.randn(self.dimensions)
        step = u / (np.abs(v) ** (1 / self.beta))
        
        return step
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], np.ndarray]:
        """
        Generate a new candidate solution using Lévy flight.
        
        Returns:
            Tuple of (nest_index, topology, new_position)
        """
        # Get current nest
        nest = self.nests[self.nest_index]
        
        # Generate new solution via Lévy flight from best nest
        best_nest = max(self.nests, key=lambda n: n['reward'])
        
        # Lévy flight step
        step = self._levy_flight()
        step_size = 0.01 * step  # Scale factor
        
        # New position: move from current towards best via Lévy flight
        new_position = nest['position'] + step_size * (nest['position'] - best_nest['position'])
        new_position = np.clip(new_position, 0, 1)
        
        topology = self._discretize_position(new_position)
        
        return self.nest_index, topology, new_position
    
    def _abandon_worst_nests(self) -> None:
        """Abandon worst nests with probability pa and build new ones."""
        # Sort nests by reward
        sorted_indices = sorted(range(len(self.nests)), 
                                key=lambda i: self.nests[i]['reward'])
        
        # Number of nests to abandon
        n_abandon = int(self.pa * self.population_size)
        
        # Abandon worst nests
        for i in range(n_abandon):
            worst_idx = sorted_indices[i]
            # Build new nest with random position
            self.nests[worst_idx]['position'] = np.random.rand(self.dimensions)
            self.nests[worst_idx]['reward'] = -1.0
    
    def update(self, nest_index: int, reward: float, state: Optional[np.ndarray] = None) -> None:
        """
        Update nest if new solution is better.
        
        Args:
            nest_index: Index of the nest
            reward: Reward achieved by the candidate solution
            state: The new position that was evaluated
        """
        new_position = state
        
        # Replace if better (greedy selection)
        if reward > self.nests[nest_index]['reward']:
            self.nests[nest_index]['position'] = new_position.copy()
            self.nests[nest_index]['reward'] = reward
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(new_position)
        
        self.nest_index += 1
        if self.nest_index >= self.population_size:
            self._abandon_worst_nests()
            self.nest_index = 0
            self.iteration += 1
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'nest_index': self.nest_index,
            'nests': [{
                'position': n['position'].tolist(),
                'reward': n['reward']
            } for n in self.nests],
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.nest_index = state.get('nest_index', 0)
        
        nests_state = state.get('nests', [])
        self.nests = []
        for n_state in nests_state:
            self.nests.append({
                'position': np.array(n_state['position']),
                'reward': n_state['reward']
            })