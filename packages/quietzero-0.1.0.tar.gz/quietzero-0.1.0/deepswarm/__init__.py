"""
QuietZero: Neural Architecture Search with Swarm Intelligence Algorithms.

A library for discovering optimal neural network architectures using various
swarm intelligence optimization algorithms including:
- Ant Colony Optimization (ACO)
- Particle Swarm Optimization (PSO)
- Artificial Bee Colony (ABC)
- Grey Wolf Optimizer (GWO)
- Firefly Algorithm (FA)
- Bat Algorithm (BA)
- Cuckoo Search (CS)
- Whale Optimization Algorithm (WOA)
- Moth Flame Optimizer (MFO)

Example usage:
    from quietzero import DeepSwarm, PyTorchBackend, AntColony
    
    backend = PyTorchBackend()
    optimizer = AntColony(settings={'max_iterations': 10, ...})
    deepswarm = DeepSwarm(backend=backend, optimizer=optimizer, settings=settings)
    best_topology, best_reward = deepswarm.find_architecture(dataset)
"""

__version__ = "0.1.0"
__author__ = "Tashin Ahmed"

# Base classes
from .base import BaseOptimizer

# Swarm algorithms
from .aco import AntColony
from .pso import ParticleSwarm
from .abc import ArtificialBeeColony
from .gwo import GreyWolfOptimizer
from .woa import WhaleOptimization
from .cs import CuckooSearch
from .fa import FireflyAlgorithm
from .ba import BatAlgorithm
from .mfo import MothFlameOptimizer

# Core classes
from .deepswarm import DeepSwarm
from .model import PyTorchBackend, DynamicNet

__all__ = [
    # Version info
    "__version__",
    "__author__",
    
    # Base class
    "BaseOptimizer",
    
    # Swarm algorithms
    "AntColony",
    "ParticleSwarm",
    "ArtificialBeeColony",
    "GreyWolfOptimizer",
    "WhaleOptimization",
    "CuckooSearch",
    "FireflyAlgorithm",
    "BatAlgorithm",
    "MothFlameOptimizer",
    
    # Core classes
    "DeepSwarm",
    "PyTorchBackend",
    "DynamicNet",
]
