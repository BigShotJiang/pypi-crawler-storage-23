"""
Particle Swarm Optimization (PSO) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class ParticleSwarm(BaseOptimizer):
    """
    Particle Swarm Optimization algorithm for Neural Architecture Search.
    
    PSO simulates the social behavior of bird flocking or fish schooling.
    Particles move through the search space influenced by their personal best
    and the global best position found by the swarm.
    
    Attributes:
        swarm_size: Number of particles in the swarm
        max_iterations: Maximum number of iterations
        inertia: Inertia weight (w) - controls exploration vs exploitation
        cognition: Cognitive coefficient (c1) - personal best influence
        social: Social coefficient (c2) - global best influence
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Particle Swarm Optimizer.
        
        Args:
            settings: Dictionary containing:
                - swarm_size: Number of particles (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - inertia: Inertia weight (default: 0.7)
                - cognition: Personal influence (default: 1.5)
                - social: Global influence (default: 1.5)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.swarm_size = settings.get('swarm_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.inertia = settings.get('inertia', 0.7)
        self.cognition = settings.get('cognition', 1.5)
        self.social = settings.get('social', 1.5)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.particle_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize swarm
        self.swarm = self._initialize_swarm()
        self._global_best_position = np.zeros(self.dimensions)
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """
        Create a mapping from continuous position vector to discrete architecture.
        
        Returns:
            Tuple of (topology_map, dimensions)
        """
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_swarm(self) -> List[Dict[str, Any]]:
        """
        Initialize the swarm with random positions and velocities.
        
        Returns:
            List of particle dictionaries
        """
        swarm = []
        for _ in range(self.swarm_size):
            position = np.random.rand(self.dimensions)
            particle = {
                'position': position.copy(),
                'velocity': np.random.rand(self.dimensions) * 0.1,
                'best_position': position.copy(),
                'best_reward': -1.0,
            }
            swarm.append(particle)
        return swarm
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """
        Convert a continuous position vector to a discrete neural network topology.
        
        Args:
            position: Continuous position vector in [0, 1]^d
            
        Returns:
            List of layer dictionaries defining the architecture
        """
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            # Map continuous value [0, 1] to a discrete choice
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        # Build topology with correct layer sequence
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], None]:
        """
        Get the next particle's topology for evaluation.
        
        Returns:
            Tuple of (particle_index, topology, None)
        """
        particle = self.swarm[self.particle_index]
        topology = self._discretize_position(particle['position'])
        
        return self.particle_index, topology, None
    
    def update(self, particle_index: int, reward: float, state: Optional[Any] = None) -> None:
        """
        Update particle velocity and position based on reward.
        
        Args:
            particle_index: Index of the particle being updated
            reward: The accuracy/fitness achieved
            state: Not used in PSO
        """
        particle = self.swarm[particle_index]
        
        # Update personal best
        if reward > particle['best_reward']:
            particle['best_reward'] = reward
            particle['best_position'] = particle['position'].copy()
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_position = particle['position'].copy()
            self._global_best_topology = self._discretize_position(self._global_best_position)
        
        # Update velocity using PSO equation
        r1, r2 = random.random(), random.random()
        inertia_term = self.inertia * particle['velocity']
        cognitive_term = self.cognition * r1 * (particle['best_position'] - particle['position'])
        social_term = self.social * r2 * (self._global_best_position - particle['position'])
        
        particle['velocity'] = inertia_term + cognitive_term + social_term
        
        # Update position and clamp to [0, 1]
        particle['position'] = np.clip(particle['position'] + particle['velocity'], 0, 1)
        
        self.particle_index += 1
        if self.particle_index >= self.swarm_size:
            self.particle_index = 0
            self.iteration += 1
    
    def is_finished(self) -> bool:
        """
        Check if optimization is complete.
        
        Returns:
            True if maximum iterations reached
        """
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """
        Get the current state for checkpointing.
        
        Returns:
            Dictionary containing all state needed to resume
        """
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'particle_index': self.particle_index,
            'swarm': [{
                'position': p['position'].tolist(),
                'velocity': p['velocity'].tolist(),
                'best_position': p['best_position'].tolist(),
                'best_reward': p['best_reward']
            } for p in self.swarm],
            'global_best_position': self._global_best_position.tolist()
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """
        Restore the optimizer state from a checkpoint.
        
        Args:
            state: Dictionary containing previously saved state
        """
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.particle_index = state.get('particle_index', 0)
        
        swarm_state = state.get('swarm', [])
        self.swarm = []
        for p_state in swarm_state:
            self.swarm.append({
                'position': np.array(p_state['position']),
                'velocity': np.array(p_state['velocity']),
                'best_position': np.array(p_state['best_position']),
                'best_reward': p_state['best_reward']
            })
        
        self._global_best_position = np.array(state.get('global_best_position', np.zeros(self.dimensions)))