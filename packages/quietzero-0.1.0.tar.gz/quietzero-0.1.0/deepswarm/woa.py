"""
Whale Optimization Algorithm (WOA) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class WhaleOptimization(BaseOptimizer):
    """
    Whale Optimization Algorithm for Neural Architecture Search.
    
    WOA mimics the social behavior of humpback whales, specifically their
    bubble-net hunting strategy. The algorithm balances exploration and
    exploitation through shrinking encircling prey and spiral updating position.
    
    Attributes:
        population_size: Number of whales in the population
        max_iterations: Maximum number of iterations
        b: Spiral shape constant (default: 1)
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Whale Optimizer.
        
        Args:
            settings: Dictionary containing:
                - population_size: Number of whales (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - b: Spiral shape constant (default: 1)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.population_size = settings.get('population_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.b = settings.get('b', 1)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.whale_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize population
        self.population = self._initialize_population()
        self._leader_position = np.zeros(self.dimensions)
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_population(self) -> List[Dict[str, Any]]:
        """Initialize the whale population with random positions."""
        population = []
        for _ in range(self.population_size):
            position = np.random.rand(self.dimensions)
            whale = {
                'position': position.copy(),
                'reward': -1.0,
            }
            population.append(whale)
        return population
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _update_leader(self) -> None:
        """Update leader position based on best reward."""
        best_whale = max(self.population, key=lambda w: w['reward'])
        if best_whale['reward'] > self._global_best_reward:
            self._leader_position = best_whale['position'].copy()
            self._global_best_reward = best_whale['reward']
            self._global_best_topology = self._discretize_position(self._leader_position)
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], None]:
        """Get the next whale's topology for evaluation."""
        whale = self.population[self.whale_index]
        topology = self._discretize_position(whale['position'])
        
        return self.whale_index, topology, None
    
    def _update_positions(self) -> None:
        """Update all whale positions using WOA equations."""
        a = 2 - self.iteration * (2 / self.max_iterations)  # a decreases from 2 to 0
        a2 = -1 + self.iteration * (-1 / self.max_iterations)  # a2 decreases from -1 to -2
        
        for whale in self.population:
            r = random.random()
            a_rand = 2 * a * r - a
            
            # Exploitation: Shrinking encircling mechanism
            if abs(a_rand) < 1:
                # Encircle prey (move towards leader)
                c = 2 * random.random()
                distance = abs(c * self._leader_position - whale['position'])
                whale['position'] = np.clip(
                    self._leader_position - a_rand * distance, 0, 1
                )
            else:
                # Exploration: Search for prey (random whale)
                random_whale = random.choice(self.population)
                c = 2 * random.random()
                distance = abs(c * random_whale['position'] - whale['position'])
                whale['position'] = np.clip(
                    random_whale['position'] - a_rand * distance, 0, 1
                )
            
            # Spiral updating position (bubble net attack)
            l = (a2 - 1) * random.random() + 1
            distance_to_leader = abs(self._leader_position - whale['position'])
            whale['position'] = np.clip(
                distance_to_leader * np.exp(self.b * l) * np.cos(2 * np.pi * l) 
                + self._leader_position, 0, 1
            )
            
            whale['reward'] = -1.0  # Reset for new evaluation
    
    def update(self, whale_index: int, reward: float, state: Optional[Any] = None) -> None:
        """Update whale's reward."""
        self.population[whale_index]['reward'] = reward
        
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(
                self.population[whale_index]['position']
            )
        
        self.whale_index += 1
        if self.whale_index >= self.population_size:
            self._update_positions()
            self.whale_index = 0
            self.iteration += 1
            self._update_leader()
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'whale_index': self.whale_index,
            'population': [{
                'position': w['position'].tolist(),
                'reward': w['reward']
            } for w in self.population],
            'leader_position': self._leader_position.tolist(),
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.whale_index = state.get('whale_index', 0)
        
        pop_state = state.get('population', [])
        self.population = []
        for w_state in pop_state:
            self.population.append({
                'position': np.array(w_state['position']),
                'reward': w_state['reward']
            })
        
        self._leader_position = np.array(state.get('leader_position', np.zeros(self.dimensions)))