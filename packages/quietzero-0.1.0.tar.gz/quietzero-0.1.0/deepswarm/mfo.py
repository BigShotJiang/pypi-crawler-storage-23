"""
Moth Flame Optimizer (MFO) for Neural Architecture Search.
"""

import random
import copy
import numpy as np
from typing import Tuple, List, Dict, Any, Optional

from .base import BaseOptimizer


class MothFlameOptimizer(BaseOptimizer):
    """
    Moth Flame Optimizer for Neural Architecture Search.
    
    MFO is inspired by the navigation method of moths in nature called
    transverse orientation. Moths fly at night by maintaining a fixed angle
    with respect to the moon. In the algorithm:
    - Moths are the search agents that move around the search space
    - Flames are the best positions found so far (like flames attracting moths)
    
    Attributes:
        population_size: Number of moths
        max_iterations: Maximum number of iterations
        b: Constant defining the shape of logarithmic spiral (default: 1)
        search_space: Dictionary defining the architecture search space
    """
    
    def __init__(self, settings: Dict[str, Any]):
        """
        Initialize the Moth Flame Optimizer.
        
        Args:
            settings: Dictionary containing:
                - population_size: Number of moths (default: 10)
                - max_iterations: Maximum iterations (default: 10)
                - b: Spiral shape constant (default: 1)
                - search_space: Architecture search space definition
        """
        super().__init__(settings)
        self.population_size = settings.get('population_size', 10)
        self.max_iterations = settings.get('max_iterations', 10)
        self.b = settings.get('b', 1)
        self.search_space = settings.get('search_space', {})
        
        # Internal state
        self.iteration = 0
        self.moth_index = 0
        self.topology_map, self.dimensions = self._create_topology_map()
        
        # Initialize moths and flames
        self.moths = self._initialize_moths()
        self.flames = None  # Will be initialized after first evaluation
        self._flame_count = self.population_size
    
    def _create_topology_map(self) -> Tuple[List[Dict[str, Any]], int]:
        """Create a mapping from continuous position vector to discrete architecture."""
        topology_map = []
        dimensions = 0
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        
        for layer_type in layer_sequence:
            if layer_type in self.search_space:
                params = self.search_space[layer_type]
                for param, values in params.items():
                    if isinstance(values, list) and len(values) > 0:
                        topology_map.append({
                            'layer_type': layer_type,
                            'param': param,
                            'values': values
                        })
                        dimensions += 1
        
        return topology_map, dimensions
    
    def _initialize_moths(self) -> List[Dict[str, Any]]:
        """Initialize moths with random positions."""
        moths = []
        for _ in range(self.population_size):
            position = np.random.rand(self.dimensions)
            moth = {
                'position': position.copy(),
                'reward': -1.0,
            }
            moths.append(moth)
        return moths
    
    def _discretize_position(self, position: np.ndarray) -> List[Dict[str, Any]]:
        """Convert a continuous position vector to a discrete neural network topology."""
        topology_dict = {}
        topology = []
        
        for i, pos in enumerate(position):
            map_item = self.topology_map[i]
            layer_type = map_item['layer_type']
            param = map_item['param']
            values = map_item['values']
            
            choice_index = min(int(pos * len(values)), len(values) - 1)
            
            if layer_type not in topology_dict:
                topology_dict[layer_type] = {'type': layer_type}
            
            topology_dict[layer_type][param] = values[choice_index]
        
        layer_sequence = ['conv2d', 'pool2d', 'conv2d', 'pool2d', 'flatten', 'dense', 'dense']
        for l_type in layer_sequence:
            if l_type in topology_dict:
                topology.append(topology_dict[l_type])
        
        return topology
    
    def _initialize_flames(self) -> List[Dict[str, Any]]:
        """Initialize flames as sorted copy of moths."""
        # Sort moths by reward (descending)
        sorted_moths = sorted(self.moths, key=lambda m: m['reward'], reverse=True)
        flames = []
        for moth in sorted_moths:
            flames.append({
                'position': moth['position'].copy(),
                'reward': moth['reward']
            })
        return flames
    
    def _calculate_flame_count(self) -> int:
        """Calculate the number of flames for current iteration."""
        # Linearly decrease flame count from N to 1
        return round(self.population_size - self.iteration * (self.population_size - 1) / self.max_iterations)
    
    def generate_topology(self) -> Tuple[int, List[Dict[str, Any]], np.ndarray]:
        """
        Generate a new position for the current moth using logarithmic spiral.
        
        Returns:
            Tuple of (moth_index, topology, new_position)
        """
        if self.moth_index >= self.population_size:
            # Update flames with best positions
            self._update_flames()
            self.moth_index = 0
            self.iteration += 1
            self._flame_count = self._calculate_flame_count()
        
        # Initialize flames after first round of evaluations
        if self.flames is None and all(m['reward'] >= 0 for m in self.moths):
            self.flames = self._initialize_flames()
        
        moth = self.moths[self.moth_index]
        
        if self.flames is None:
            # First iteration: use current position
            new_position = moth['position'].copy()
        else:
            # Move moth towards corresponding flame using logarithmic spiral
            flame_idx = min(self.moth_index, len(self.flames) - 1)
            flame = self.flames[flame_idx]
            
            # Calculate distance to flame
            d = np.abs(flame['position'] - moth['position'])
            
            # Logarithmic spiral
            t = random.uniform(-1, 1)
            new_position = d * np.exp(self.b * t) * np.cos(2 * np.pi * t) + flame['position']
            new_position = np.clip(new_position, 0, 1)
        
        topology = self._discretize_position(new_position)
        
        return self.moth_index, topology, new_position
    
    def _update_flames(self) -> None:
        """Update flames with best positions from moths and current flames."""
        if self.flames is None:
            self.flames = self._initialize_flames()
            return
        
        # Combine moths and flames
        all_solutions = list(self.moths) + list(self.flames)
        
        # Sort by reward (descending)
        all_solutions.sort(key=lambda x: x['reward'], reverse=True)
        
        # Keep top N as flames
        self.flames = []
        for i in range(self.population_size):
            self.flames.append({
                'position': all_solutions[i]['position'].copy(),
                'reward': all_solutions[i]['reward']
            })
        
        # Update global best
        if self.flames[0]['reward'] > self._global_best_reward:
            self._global_best_reward = self.flames[0]['reward']
            self._global_best_topology = self._discretize_position(self.flames[0]['position'])
    
    def update(self, moth_index: int, reward: float, state: Optional[np.ndarray] = None) -> None:
        """
        Update moth with the new solution.
        
        Args:
            moth_index: Index of the moth
            reward: Reward achieved by the candidate solution
            state: The new position that was evaluated
        """
        new_position = state
        
        # Update moth position and reward
        self.moths[moth_index]['position'] = new_position.copy()
        self.moths[moth_index]['reward'] = reward
        
        # Update global best
        if reward > self._global_best_reward:
            self._global_best_reward = reward
            self._global_best_topology = self._discretize_position(new_position)
        
        self.moth_index += 1
        
        # Complete iteration when all moths evaluated
        if self.moth_index >= self.population_size:
            # Initialize flames after first round of evaluations
            if self.flames is None:
                self.flames = self._initialize_flames()
            else:
                self._update_flames()
            
            self.moth_index = 0
            self.iteration += 1
            self._flame_count = self._calculate_flame_count()
    
    def is_finished(self) -> bool:
        """Check if optimization is complete."""
        return self.iteration >= self.max_iterations
    
    def get_state(self) -> Dict[str, Any]:
        """Get the current state for checkpointing."""
        state = super().get_state()
        state.update({
            'iteration': self.iteration,
            'moth_index': self.moth_index,
            'flame_count': self._flame_count,
            'moths': [{
                'position': m['position'].tolist(),
                'reward': m['reward']
            } for m in self.moths],
            'flames': [{
                'position': f['position'].tolist(),
                'reward': f['reward']
            } for f in self.flames] if self.flames else None,
        })
        return state
    
    def set_state(self, state: Dict[str, Any]) -> None:
        """Restore the optimizer state from a checkpoint."""
        super().set_state(state)
        self.iteration = state.get('iteration', 0)
        self.moth_index = state.get('moth_index', 0)
        self._flame_count = state.get('flame_count', self.population_size)
        
        moths_state = state.get('moths', [])
        self.moths = []
        for m_state in moths_state:
            self.moths.append({
                'position': np.array(m_state['position']),
                'reward': m_state['reward']
            })
        
        flames_state = state.get('flames')
        if flames_state:
            self.flames = []
            for f_state in flames_state:
                self.flames.append({
                    'position': np.array(f_state['position']),
                    'reward': f_state['reward']
                })
        else:
            self.flames = None