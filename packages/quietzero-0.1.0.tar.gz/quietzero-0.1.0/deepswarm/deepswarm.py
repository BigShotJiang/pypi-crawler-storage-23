"""
DeepSwarm: Neural Architecture Search with Swarm Intelligence.
"""

import os
import json
import pickle
from datetime import datetime
from typing import Tuple, List, Dict, Any, Optional, Callable
from concurrent.futures import ProcessPoolExecutor, as_completed
import numpy as np

from .base import BaseOptimizer


class DeepSwarm:
    """
    Main class for Neural Architecture Search using swarm intelligence algorithms.
    
    DeepSwarm orchestrates the architecture search process by:
    1. Generating candidate architectures using a swarm optimizer
    2. Building and training models using a backend
    3. Evaluating and providing feedback to the optimizer
    
    Attributes:
        backend: Backend for model creation, training, and evaluation
        optimizer: Swarm optimization algorithm (ACO, PSO, ABC, etc.)
        settings: Configuration dictionary
        log_dir: Directory for TensorBoard logs
        checkpoint_dir: Directory for saving checkpoints
    """
    
    def __init__(
        self,
        backend: Any,
        optimizer: BaseOptimizer,
        settings: Dict[str, Any],
        log_dir: Optional[str] = None,
        checkpoint_dir: Optional[str] = None
    ):
        """
        Initialize DeepSwarm.
        
        Args:
            backend: Backend for model operations (PyTorchBackend, etc.)
            optimizer: Swarm optimization algorithm implementing BaseOptimizer
            settings: Configuration dictionary with training parameters
            log_dir: Optional directory for TensorBoard logs
            checkpoint_dir: Optional directory for checkpoints
        """
        self.backend = backend
        self.optimizer = optimizer
        self.settings = settings
        self.log_dir = log_dir
        self.checkpoint_dir = checkpoint_dir
        
        # Initialize TensorBoard writer if log_dir provided
        self.writer = None
        if self.log_dir:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.writer = SummaryWriter(log_dir=self.log_dir)
                print(f"TensorBoard logging enabled: {self.log_dir}")
            except ImportError:
                print("Warning: tensorboard not installed. Logging disabled.")
        
        # Create checkpoint directory if needed
        if self.checkpoint_dir:
            os.makedirs(self.checkpoint_dir, exist_ok=True)
        
        # Evaluation counter
        self.evaluation_count = 0
    
    def find_architecture(
        self,
        dataset: Any,
        resume_from: Optional[str] = None,
        parallel_workers: int = 1
    ) -> Tuple[List[Dict[str, Any]], float]:
        """
        Search for the best neural network architecture.
        
        Args:
            dataset: Dataset object with training_examples, training_labels,
                    testing_examples, testing_labels
            resume_from: Optional path to checkpoint file to resume from
            parallel_workers: Number of parallel workers for evaluation (default: 1)
            
        Returns:
            Tuple of (best_topology, best_reward)
        """
        # Resume from checkpoint if provided
        if resume_from:
            self._load_checkpoint(resume_from)
            print(f"Resumed from checkpoint: {resume_from}")
        
        print(f"Starting architecture search with {self.optimizer.__class__.__name__}")
        print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        input_shape = dataset.training_examples.shape[1:]
        output_shape = len(np.unique(dataset.training_labels))
        
        while not self.optimizer.is_finished():
            if parallel_workers > 1:
                self._parallel_evaluation_step(dataset, input_shape, output_shape, parallel_workers)
            else:
                self._sequential_evaluation_step(dataset, input_shape, output_shape)
        
        # Get final results
        best_topology = self.optimizer.global_best_topology
        best_reward = self.optimizer.global_best_reward
        
        print(f"\n{'='*60}")
        print(f"Architecture search completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Best reward (accuracy): {best_reward:.2f}%")
        print(f"Total evaluations: {self.evaluation_count}")
        print(f"{'='*60}")
        
        # Close TensorBoard writer
        if self.writer:
            self.writer.close()
        
        return best_topology, best_reward
    
    def _sequential_evaluation_step(
        self,
        dataset: Any,
        input_shape: Tuple[int, ...],
        output_shape: int
    ) -> None:
        """
        Perform a single sequential evaluation step.
        
        Args:
            dataset: Dataset object
            input_shape: Shape of input data
            output_shape: Number of output classes
        """
        # Generate topology
        optimizer_output = self.optimizer.generate_topology()
        
        if len(optimizer_output) == 3:
            agent_id, topology, agent_state = optimizer_output
        else:
            agent_id, topology = optimizer_output
            agent_state = None
        
        self.evaluation_count += 1
        
        try:
            # Create, train, and evaluate model
            reward = self._evaluate_topology(
                topology, dataset, input_shape, output_shape
            )
            
            # Log to TensorBoard
            if self.writer:
                self.writer.add_scalar('Reward/current', reward, self.evaluation_count)
                self.writer.add_scalar('Reward/best', self.optimizer.global_best_reward, self.evaluation_count)
            
            # Update optimizer
            if agent_state is not None:
                self.optimizer.update(agent_id, reward, agent_state)
            else:
                self.optimizer.update(agent_id, reward)
            
            self._log_progress(reward)
            
        except Exception as e:
            print(f"Error evaluating topology (agent {agent_id}): {e}")
            if agent_state is not None:
                self.optimizer.update(agent_id, 0, agent_state)
            else:
                self.optimizer.update(agent_id, 0)
        
        # Save checkpoint periodically
        if self.checkpoint_dir and self.evaluation_count % 10 == 0:
            self._save_checkpoint()
    
    def _parallel_evaluation_step(
        self,
        dataset: Any,
        input_shape: Tuple[int, ...],
        output_shape: int,
        num_workers: int
    ) -> None:
        """
        Perform parallel evaluation of multiple topologies.
        
        Args:
            dataset: Dataset object
            input_shape: Shape of input data
            output_shape: Number of output classes
            num_workers: Number of parallel workers
        """
        # Collect batch of topologies to evaluate
        batch = []
        for _ in range(num_workers):
            if self.optimizer.is_finished():
                break
            
            optimizer_output = self.optimizer.generate_topology()
            if len(optimizer_output) == 3:
                agent_id, topology, agent_state = optimizer_output
            else:
                agent_id, topology = optimizer_output
                agent_state = None
            
            batch.append((agent_id, topology, agent_state))
        
        if not batch:
            return
        
        # Evaluate in parallel
        # Note: Due to multiprocessing limitations, we use sequential evaluation
        # but structure the code for future parallel implementation
        for agent_id, topology, agent_state in batch:
            self.evaluation_count += 1
            
            try:
                reward = self._evaluate_topology(
                    topology, dataset, input_shape, output_shape
                )
                
                if self.writer:
                    self.writer.add_scalar('Reward/current', reward, self.evaluation_count)
                    self.writer.add_scalar('Reward/best', self.optimizer.global_best_reward, self.evaluation_count)
                
                if agent_state is not None:
                    self.optimizer.update(agent_id, reward, agent_state)
                else:
                    self.optimizer.update(agent_id, reward)
                
                self._log_progress(reward)
                
            except Exception as e:
                print(f"Error evaluating topology (agent {agent_id}): {e}")
                if agent_state is not None:
                    self.optimizer.update(agent_id, 0, agent_state)
                else:
                    self.optimizer.update(agent_id, 0)
        
        # Save checkpoint
        if self.checkpoint_dir:
            self._save_checkpoint()
    
    def _evaluate_topology(
        self,
        topology: List[Dict[str, Any]],
        dataset: Any,
        input_shape: Tuple[int, ...],
        output_shape: int
    ) -> float:
        """
        Evaluate a single topology.
        
        Args:
            topology: List of layer dictionaries
            dataset: Dataset object
            input_shape: Shape of input data
            output_shape: Number of output classes
            
        Returns:
            Reward (accuracy) achieved by the topology
        """
        model = self.backend.create_model(topology, input_shape, output_shape)
        
        self.backend.train_model(
            model,
            dataset,
            batch_size=self.settings.get('training', {}).get('batch_size', 128),
            epochs=self.settings.get('training', {}).get('epochs', 5)
        )
        
        reward = self.backend.evaluate_model(
            model,
            dataset,
            batch_size=self.settings.get('training', {}).get('batch_size', 128)
        )
        
        return reward
    
    def _log_progress(self, reward: float) -> None:
        """
        Log progress to console.
        
        Args:
            reward: Current reward
        """
        best_reward = self.optimizer.global_best_reward
        print(f"Evaluation {self.evaluation_count} | "
              f"Reward: {reward:.2f}% | "
              f"Best: {best_reward:.2f}%")
    
    def _save_checkpoint(self) -> str:
        """
        Save current state to a checkpoint file.
        
        Returns:
            Path to the saved checkpoint
        """
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        checkpoint_path = os.path.join(
            self.checkpoint_dir,
            f'checkpoint_{timestamp}.pkl'
        )
        
        checkpoint = {
            'optimizer_state': self.optimizer.get_state(),
            'optimizer_class': self.optimizer.__class__.__name__,
            'settings': self.settings,
            'evaluation_count': self.evaluation_count,
            'timestamp': timestamp
        }
        
        with open(checkpoint_path, 'wb') as f:
            pickle.dump(checkpoint, f)
        
        print(f"Checkpoint saved: {checkpoint_path}")
        return checkpoint_path
    
    def _load_checkpoint(self, checkpoint_path: str) -> None:
        """
        Load state from a checkpoint file.
        
        Args:
            checkpoint_path: Path to the checkpoint file
        """
        with open(checkpoint_path, 'rb') as f:
            checkpoint = pickle.load(f)
        
        self.optimizer.set_state(checkpoint['optimizer_state'])
        self.evaluation_count = checkpoint.get('evaluation_count', 0)
        
        print(f"Loaded checkpoint from: {checkpoint['timestamp']}")
        print(f"Previous evaluations: {self.evaluation_count}")
        print(f"Previous best reward: {self.optimizer.global_best_reward:.2f}%")
    
    def save_best_model(
        self,
        dataset: Any,
        output_path: str
    ) -> None:
        """
        Save the best found model to disk.
        
        Args:
            dataset: Dataset object for model creation
            output_path: Path to save the model
        """
        import torch
        
        best_topology = self.optimizer.global_best_topology
        if best_topology is None:
            print("No best model found. Run find_architecture() first.")
            return
        
        input_shape = dataset.training_examples.shape[1:]
        output_shape = len(np.unique(dataset.training_labels))
        
        model = self.backend.create_model(best_topology, input_shape, output_shape)
        
        # Train the best model
        self.backend.train_model(
            model,
            dataset,
            batch_size=self.settings.get('training', {}).get('batch_size', 128),
            epochs=self.settings.get('training', {}).get('epochs', 5)
        )
        
        torch.save({
            'model_state_dict': model.state_dict(),
            'topology': best_topology,
            'reward': self.optimizer.global_best_reward
        }, output_path)
        
        print(f"Best model saved to: {output_path}")