"""Slop-Mop: Quality gates for AI-assisted codebases."""

__version__ = "0.2.1"
