"""PR-related quality checks."""

from slopmop.checks.pr.comments import PRCommentsCheck

__all__ = ["PRCommentsCheck"]
