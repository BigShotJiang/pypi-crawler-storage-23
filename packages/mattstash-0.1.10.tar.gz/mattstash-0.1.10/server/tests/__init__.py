"""Test suite for MattStash Server."""
