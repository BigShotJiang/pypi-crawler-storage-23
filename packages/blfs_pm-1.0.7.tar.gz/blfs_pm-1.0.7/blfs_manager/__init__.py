__VERSION__ = '1.0.7'
__PKGNAME__ = 'blfs-pm'
