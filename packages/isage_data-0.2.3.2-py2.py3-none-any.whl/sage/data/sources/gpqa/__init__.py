"""GPQA dataset source wrapper."""

from .dataloader import GPQADataLoader

__all__ = ["GPQADataLoader"]
