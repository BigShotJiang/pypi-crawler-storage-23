See project abstract at [docs/abstract](docs/abstract.md)
