VERSION = "0.2.7"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
