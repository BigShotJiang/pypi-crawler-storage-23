# 🎂 Happy Birthday Jyoti! 🎉

A birthday celebration package from **Team TongaDive**!

## Installation & Run (One Command!)

```bash
pip install jyoti && python3 -m jyoti
```

That's it! The celebration starts immediately. After the first run, just type `jyoti` in any **new** terminal — it works forever.

### Windows
```
pip install jyoti
jyoti
```

### Linux / macOS
```bash
pip install jyoti && python3 -m jyoti
```
After this, open a new terminal and `jyoti` will work directly.

## Features

- 🎂 Beautiful ASCII birthday cake
- 🎈 Animated balloons rising
- 🎊 Confetti rain animation
- 🎆 Fireworks display
- 🌈 Rainbow text effects
- 🎵 Birthday music (auto-downloaded)
- 📸 Special birthday photo
- 💖 Love messages from the team

## With Love From

Sindhu, Akaash, Neha, Rajat, Ujjwal, Leena, Anubha, Partho, Sumit, Rudraksh, Kavita, Muskan, Ishika

**Take care - Love yourself Always** 💕

## 🌟 TEAM TONGADIVE 🌟

## License

MIT
