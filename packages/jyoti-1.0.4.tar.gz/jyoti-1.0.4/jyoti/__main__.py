"""
Allow running as: python -m jyoti
Also auto-fixes shell so the 'jyoti' command works in all future terminal sessions.
"""

import os
import sys
import platform
from pathlib import Path


def _auto_fix_shell():
    """
    Add both a shell function AND PATH export to shell config files.
    The shell function ensures 'jyoti' works even if ~/.local/bin isn't in PATH.
    """
    try:
        if platform.system() == "Windows":
            return

        home = Path.home()

        # Determine which python to use in the function
        python_cmd = "python3"

        # The block we inject into shell configs
        jyoti_block = (
            '\n# === jyoti birthday celebration (Team TongaDive) 🎂 ===\n'
            'export PATH="$HOME/.local/bin:$PATH"\n'
            'jyoti() { ' + python_cmd + ' -m jyoti "$@"; }\n'
            '# === end jyoti ===\n'
        )

        shell_configs = [
            home / ".bashrc",
            home / ".zshrc",
            home / ".profile",
            home / ".bash_profile",
        ]

        for config_file in shell_configs:
            if config_file.exists():
                try:
                    content = config_file.read_text(encoding="utf-8", errors="ignore")
                    # Only add if our block isn't already there
                    if "jyoti birthday celebration" not in content:
                        with open(config_file, "a", encoding="utf-8") as f:
                            f.write(jyoti_block)
                except (PermissionError, OSError):
                    continue

        # If no shell config existed, create .bashrc
        bashrc = home / ".bashrc"
        if not bashrc.exists():
            try:
                with open(bashrc, "w", encoding="utf-8") as f:
                    f.write(jyoti_block)
            except (PermissionError, OSError):
                pass

    except Exception:
        pass


# Fix shell before running celebration
_auto_fix_shell()

from jyoti.cli import main
main()
