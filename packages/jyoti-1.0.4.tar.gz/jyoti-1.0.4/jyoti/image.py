"""
Cross-platform image display.
Opens the bundled birthday image using the OS default image viewer.
"""

import os
import sys
import subprocess
import platform
import threading


def _get_image_path():
    """Get the path to the bundled birthday image."""
    # The image is bundled inside the package's assets folder
    package_dir = os.path.dirname(os.path.abspath(__file__))
    img_path = os.path.join(package_dir, "assets", "img.png")
    if os.path.exists(img_path):
        return img_path
    return None


def open_image():
    """Open the birthday image using OS default viewer. Non-blocking."""
    def _worker():
        img_path = _get_image_path()
        if img_path is None:
            return

        system = platform.system().lower()
        try:
            if system == "windows":
                # Use os.startfile on Windows
                os.startfile(img_path)
            elif system == "darwin":
                # macOS
                subprocess.Popen(
                    ["open", img_path],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            else:
                # Linux / other Unix
                openers = ["xdg-open", "eog", "feh", "display", "sxiv"]
                for opener in openers:
                    try:
                        subprocess.Popen(
                            [opener, img_path],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL,
                        )
                        return
                    except FileNotFoundError:
                        continue
        except Exception:
            pass

    thread = threading.Thread(target=_worker, daemon=True)
    thread.start()
    return thread
