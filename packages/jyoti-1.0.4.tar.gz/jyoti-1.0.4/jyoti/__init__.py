"""
🎂 HAPPY BIRTHDAY JYOTI! 🎂
A birthday celebration package from Team TongaDive.
"""

__version__ = "1.0.4"
__author__ = "Team TongaDive"
