"""
CLI entry point for the 'jyoti' command.
Orchestrates: image opening, audio playback, and terminal animations.
Also auto-fixes shell on Linux/macOS so 'jyoti' works in future terminals.
"""

import os
import sys
import time
import platform
from pathlib import Path
from jyoti.image import open_image
from jyoti.audio import play_birthday_audio
from jyoti.animations import run_celebration


def _auto_fix_shell():
    """Add shell function + PATH to shell config files on Linux/macOS."""
    try:
        if platform.system() == "Windows":
            return

        home = Path.home()
        python_cmd = "python3"

        jyoti_block = (
            '\n# === jyoti birthday celebration (Team TongaDive) 🎂 ===\n'
            'export PATH="$HOME/.local/bin:$PATH"\n'
            'jyoti() { ' + python_cmd + ' -m jyoti "$@"; }\n'
            '# === end jyoti ===\n'
        )

        shell_configs = [
            home / ".bashrc",
            home / ".zshrc",
            home / ".profile",
            home / ".bash_profile",
        ]

        for config_file in shell_configs:
            if config_file.exists():
                try:
                    content = config_file.read_text(encoding="utf-8", errors="ignore")
                    if "jyoti birthday celebration" not in content:
                        with open(config_file, "a", encoding="utf-8") as f:
                            f.write(jyoti_block)
                except (PermissionError, OSError):
                    continue

        bashrc = home / ".bashrc"
        if not bashrc.exists():
            try:
                with open(bashrc, "w", encoding="utf-8") as f:
                    f.write(jyoti_block)
            except (PermissionError, OSError):
                pass
    except Exception:
        pass


def main():
    """Main entry point - triggered when user types 'jyoti' in terminal."""
    # Auto-fix shell for future sessions (Linux/macOS)
    _auto_fix_shell()

    try:
        # Step 1: Open the birthday image immediately
        open_image()

        # Step 2: Start birthday audio in background
        play_birthday_audio()

        # Small delay so image viewer launches before terminal takes over
        time.sleep(0.3)

        # Step 3: Run the full terminal celebration animation
        run_celebration()

    except KeyboardInterrupt:
        # Graceful exit on Ctrl+C
        print("\n\n🎂 Happy Birthday Jyoti! See you! 🎉\n")
        sys.exit(0)
    except Exception as e:
        # Fallback: at minimum show the birthday message
        print("\n")
        print("=" * 60)
        print("   🎂  HAPPY BIRTHDAY JYOTI!  🎂")
        print("=" * 60)
        print()
        print("   With love from:")
        print("   Sindhu, Akaash, Neha, Rajat, Ujjwal, Leena,")
        print("   Anubha, Partho, Sumit, Rudraksh, Kavita, Muskan, Ishika")
        print()
        print("   🌟 TEAM TONGADIVE 🌟")
        print("   Take care - Love yourself Always 💕")
        print("=" * 60)
        print()


if __name__ == "__main__":
    main()
