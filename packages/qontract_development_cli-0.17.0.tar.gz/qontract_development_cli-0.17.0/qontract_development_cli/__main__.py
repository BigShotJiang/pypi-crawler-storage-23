import logging

from .cli import app

log = logging.getLogger("qontract-development")


if __name__ == "__main__":
    app()
