"""This module provides utilities for working with Bible book metadata and collections.

This defines canonical sets of Bible books, along with

* standard identifiers, abbreviations, and names
* (forthcoming) the canons that recognize this book, ordered
* (forthcoming) the chapter contents of each book and their final
  verse. This is tradition-specific: Gen 31 has 55 verses in ESV, but
  54 in BHS.

>>> from biblelib import book
>>> allbooks = book.Books()
>>> allbooks["MRK"]
<Book: MRK>
# return an OSIS id for a book instance
>>> allbooks["MRK"].osisID
'Mark'
>>>
# retrive a Book instance from an OSIS ID
>>> allbooks.fromosis("Matt").name
'Matthew'
# convert number from Logos scheme to USFM: Tobit should be 68,
# not 40
>>> allbooks.fromlogos("bible.40").usfmnumber
'68'

# if you don't know which abbreviation scheme to use for a book
# name/abbrev: this raises a ValueError if it's not following any
# existing scheme
>>> allbooks.findbook("Ge")
<Book: GEN>
>>> allbooks.findbook("Genesis")
<Book: GEN>

See the tests `Biblelib/tests` for additional examples.

To do:

    Add other canons: [Logos' Canon Comparison
    interactive](https://ref.ly/logosres/interactive:canon-comparison?pos=index.html)
    has 14.
    Indicate relations to alternate books, e.g. 'DAN' and 'DAG' (Greek Daniel, which includes other content)?

    STEPBible has its own reference scheme described at
    https://github.com/STEPBible/STEPBible-Data?tab=readme-ov-file:
    not sure it's required here.

"""

from collections import UserDict
from csv import DictReader
from dataclasses import dataclass, field
from pathlib import Path
import re
from typing import Any, Optional, Union
import warnings


# This directory: where books.tsv is also located.
BOOKSPATH = Path(__file__).parent


@dataclass(order=True)
class Book:
    """Dataclass for managing metadata identifying a book from the Bible.

    Typically accessed from Books, which instantiates the full set, or
    subclasses (pending: for a given canon).

    Attributes:
        logosID (int): the index number of this book in the Logos
            bible datatype. Provides a standard ordinal index for
            ordering.
        usfmnumber (str): the USFM string for this book. 1-2
            characters: single-digit strings are not zero-padded.
        usfmname (str): the three-character USFM name for this book
        osisID (str): the OSIS identifier for this book
        biblia (str): biblia.com abbreviaton for this book
        name (str): the common English name for this book
        altname (str): a longer or alternate English name, or empty string

    Todo:
        Add canon information.

    """

    # from the Logos bible datatype: some gaps for Ethiopic canon
    # first to support ordinal sorting
    logosID: int
    # despite the name, this is a 1-2 character string
    usfmnumber: str
    # three characters
    usfmname: str
    osisID: str
    biblia: str
    name: str
    altname: str = ""
    _canon_traditions: tuple = ("Catholic", "Jewish", "Protestant")
    # keep this in sync with the attributes below
    _abbreviationschemes: tuple = ("logosID", "usfmnumber", "usfmname", "osisID")
    _fieldnames: tuple = ("logosID", "usfmnumber", "usfmname", "osisID", "name", "altname")
    # canon-specific
    ordinal: int = field(init=False, default=0)

    # - add in JPS sequence numbers for OT books?

    def __repr__(self) -> str:
        """Return a string representation, using USFM name."""
        return f"<Book: {self.usfmname}>"

    def __hash__(self) -> int:
        """Return a hash code.

        Instances are populated with static data, so they're
        functionally immutable (but don't change attribute values!).
        """
        return hash(self.osisID)

    @property
    def usfmnumberalt(self) -> str:
        """Return an alternate USFM number, based on Matt="41" rather than "40".

        In some filenames associated with Paratext and legacy data,
        Matt is "41" and subsequent book numbers are one higher,
        through Revelation.  See
        [https://github.com/usfm-bible/tcdocs/issues/3](https://github.com/usfm-bible/tcdocs/issues/3)
        for discussion of this issue.

        Returns:
            a string representing an adjusted USFM number.

        """
        if 87 >= self.logosID >= 61:
            # only affects NT books
            return str(int(self.usfmnumber) + 1)
        else:
            return self.usfmnumber

    def render(self, attrname: str = "osisID") -> str:
        """Return a string rendering the attrname property of Book.

        Args:
            attrname: a dataclass attribute to use for rendering the book.

        Returns:
            str: a rendered representation of Book

        """
        assert attrname in self.__dataclass_fields__, f"Invalid attrname: {attrname}"
        attrval = getattr(self, attrname)
        if attrname == "logosID":
            rendered = f"bible.{attrval}"
        else:
            rendered = attrval
        return rendered

    @property
    def logosURI(self) -> str:
        """Return a URI to open this book in Logos Bible Software in your preferred Bible.

        Example:
            >>> Books()["MRK"].logosURI
            'https://ref.ly/logosref/bible.62'
        """
        return f"https://ref.ly/logosref/{self.render('logosID')}"

    @property
    def bibliaURI(self) -> str:
        """Return a URI to open this book at biblia.com.

        Example:
            >>> Books()["MRK"].logosURI
            'https://biblia.com/books/nrsv/Mk'
        """
        return f"https://biblia.com/books/nrsv/{self.render('biblia')}"

    # other URIs to consider
    # YouVersion
    # Bible Gateway
    # Ref.ly? Different Bible book abbreviations, not sure how important


@dataclass
class LocalizedBooks:
    """Book names and abbreviations localized to a specific language.

    Data is loaded from ``books_<lang>.tsv`` in the same directory as
    ``books.tsv``. The TSV file has three tab-separated columns:
    ``usfmname``, ``name``, and ``abbrev``.

    Language-level settings are stored as metadata in comment lines near
    the top of the file using the format ``# key: value``.  Currently
    recognised keys:

    * ``cv_sep`` — chapter-verse separator character (default ``":"``)

    Example::

        >>> fra = LocalizedBooks("fra")
        >>> fra.get_name("GEN")
        'Genèse'
        >>> fra.get_abbrev("MRK")
        'Mc'
        >>> fra.cv_sep
        '.'

    Language codes follow the ISO 639-3 three-letter convention used
    elsewhere in biblelib (e.g. ``"fra"`` for French, ``"spa"`` for
    Spanish).

    """

    lang: str
    cv_sep: str = field(default=":", init=False)
    _data: dict[str, dict[str, str]] = field(default_factory=dict, init=False, repr=False)

    def __post_init__(self) -> None:
        """Load localization data from the TSV file."""
        path = BOOKSPATH / f"books_{self.lang}.tsv"
        if not path.exists():
            raise FileNotFoundError(f"No localization file for language: {self.lang}")
        with path.open(encoding="utf-8") as f:
            lines = f.readlines()
        # Parse language-level metadata from comment lines (# key: value)
        for line in lines:
            m = re.match(r"^#\s*cv_sep:\s*(.+)$", line.rstrip())
            if m:
                self.cv_sep = m.group(1)
                break
        reader: DictReader = DictReader(filter(lambda row: row[0] != "#", iter(lines)), dialect="excel-tab")
        self._data = {row["usfmname"]: {"name": row["name"], "abbrev": row["abbrev"]} for row in reader}

    def get_name(self, usfmname: str) -> str:
        """Return the full localized book name for a USFM name like ``"GEN"``."""
        entry: Optional[dict[str, str]] = self._data.get(usfmname)
        assert entry is not None, f"No localized name for '{usfmname}' in language '{self.lang}'"
        return entry["name"]

    def get_abbrev(self, usfmname: str) -> str:
        """Return the localized abbreviation for a USFM name like ``"GEN"``."""
        entry: Optional[dict[str, str]] = self._data.get(usfmname)
        assert entry is not None, f"No localized abbrev for '{usfmname}' in language '{self.lang}'"
        return entry["abbrev"]


_LOCALIZED_BOOKS: dict[str, Optional["LocalizedBooks"]] = {}


def get_localized_books(lang: str) -> Optional["LocalizedBooks"]:
    """Return a cached :class:`LocalizedBooks` instance for *lang*.

    Returns ``None`` (and emits a :mod:`warnings` warning) if no
    localization file exists for *lang*; callers should fall back to
    English in that case.

    Example::

        >>> fra = get_localized_books("fra")
        >>> fra.get_name("MAT")
        'Matthieu'
        >>> get_localized_books("zzz") is None  # unsupported language
        True

    """
    if lang not in _LOCALIZED_BOOKS:
        try:
            _LOCALIZED_BOOKS[lang] = LocalizedBooks(lang)
        except FileNotFoundError:
            warnings.warn(
                f"Language '{lang}' is not supported by biblelib; falling back to English.",
                stacklevel=3,
            )
            _LOCALIZED_BOOKS[lang] = None
    return _LOCALIZED_BOOKS[lang]


class Books(UserDict):
    """A canonical collection of Bible Book instances."""

    # to add:
    # - Catholic
    # - JPS/Tanakh
    # there are others: LXX? Syriac, Ethiopian, etc.
    source: Path = BOOKSPATH / "books.tsv"
    mappingfields: set = set(Book._fieldnames)
    canon: str = "Protestant"
    logosmap: dict = {}
    namemap: dict = {}
    nameregexp: re.Pattern = re.compile("")
    osismap: dict = {}
    bibliamap: dict = {}
    usfmnumbermap: dict = {}
    # some minor standardization: this is not an extensible approach,
    # and long form names should use a different approach
    quickfixes = {"Psalm": "Psalms", "Song of Solomon": "Song of Songs"}

    def __init__(self, sourcefile: str = "", canon: str = "Protestant") -> None:
        """Initialize a Books instance.

        Instantiates a dict whose keys are 3-character USFM names.

        Args:
            sourcefile: TSV file with book data to load. Canonical
                location is
                https://github.com/Clear-Bible/Biblelib/blob/biblelib/books/books.tsv.
            canon: the canon to use in selecting and ordering books

        """
        super().__init__()
        if sourcefile:
            self.source = Path(sourcefile)
        # need implementation
        if canon != "Protestant":
            raise NotImplementedError("Canon support not yet implemented: default is Protestant.")
        # need smarts here about different canons
        # self.data = [Book(*b) for b in _bookdata]
        with self.source.open(encoding="utf-8") as f:
            # drop comment lines when reading`
            reader: DictReader = DictReader(filter(lambda row: row[0] != "#", f), dialect="excel-tab")
            # make sure the fieldnames in the file are the same as the
            # dataclass attributes
            fieldnameset: set = set(reader.fieldnames[0].split("\t"))
            assert not fieldnameset.difference(
                self.mappingfields
            ), f"Fieldname discrepancy header: {fieldnameset} vs {self.mappingfields}"
            self.data = {row["usfmname"]: self.rowtobook(row) for row in reader}
        # initialize here so you have nameregexp before calling fromname().
        self.namemap = {b.name: b for _, b in self.data.items()}
        # Includes some hacks for common variations
        self.namemap.update({alt: self.namemap[std] for alt, std in self.quickfixes.items()})
        # self.namemap = {b.name: b for _, b in (list(self.data.items()) + list(self.quickfixes.items()))}
        # use this for matching a reference string to determine if
        # it's only a book name. Hack like checking for a space or
        # number are not roubst enough.
        self.nameregexp = re.compile("|".join(self.namemap.keys()))

    @staticmethod
    def rowtobook(row: dict) -> Book:
        """Convert a raw dict read from TSV to data for Book."""
        # logosID should be an int
        row["logosID"] = int(row["logosID"])
        # zero-pad initial USFM numbers
        if len(row["usfmnumber"]) == 1:
            row["usfmnumber"] = "0" + row["usfmnumber"]
        if not row["altname"]:
            row["altname"] = ""
        return Book(**row)

    def fromlogos(self, logosID: Union[int, str]) -> Book:
        """Return the book instance for a Logos bible book index.

        Args:
            logosID: the Logos identifier to use in looking up the
                Book. Either a datatype reference string like
                'bible.62', or a bare int.
        """
        if isinstance(logosID, str):
            if logosID.startswith("bible."):
                logosID = int(logosID[6:])
            else:
                logosID = int(logosID)
        if not self.logosmap:
            # initialize on demand
            self.logosmap = {b.logosID: b for _, b in self.data.items()}
        bookinst: Book = self.logosmap.get(logosID)
        assert bookinst, f"Invalid logoID: {logosID}"
        return bookinst

    def fromname(self, bookname: str) -> Book:
        """Return the book instance for a book name.

        Args:
            bookname: the full name  to use in looking up the Book,
                like "Matthew".
        """
        # some minor standardization: this is not an extensible
        # approach, and long form names should use a different
        # approach
        bookname = self.quickfixes.get(bookname, bookname)
        bookinst: Book = self.namemap.get(bookname)
        assert bookinst, f"Invalid book name: {bookname}"
        return bookinst

    def _ensure_osismap(self) -> dict[str, str]:
        """Generate the OSIS map if needed."""
        if not self.osismap:
            # initialize on demand
            self.osismap = {b.osisID: b for _, b in self.data.items()}
        return self.osismap

    def fromosis(self, osisID: str) -> Book:
        """Return the book instance for an OSIS identifier.

        Args:
            osisID: the OSIS identifier to use in looking up the Book,
                like "Matt".
        """
        self._ensure_osismap()
        bookinst: Book = self.osismap.get(osisID)
        assert bookinst, f"Invalid OSIS book name: {osisID}"
        return bookinst

    def _ensure_bibliamap(self) -> dict[str, str]:
        """Generate the Biblia map if needed."""
        if not self.bibliamap:
            # initialize on demand
            self.bibliamap = {b.biblia: b for _, b in self.data.items()}
        return self.bibliamap

    def frombiblia(self, biblia: str) -> Book:
        """Return the book instance for a Biblia identifier.

        Args:
            biblia: the Biblia identifier to use in looking up the Book,
                like "Matt".
        """
        self._ensure_bibliamap()
        bookinst: Book = self.bibliamap.get(biblia)
        assert bookinst, f"Invalid Biblia book name: {biblia}"
        return bookinst

    def fromusfmnumber(self, usfmnumber: str, legacynumbering: bool = False) -> Book:
        """Return the book instance for a USFM number.

        Args:
            usfmnumber: the USFM book number to use in looking up the Book,
                like "40".
            legacynumbering: if true, treat MAT and subsequent NT
                books as 41, not 40. This is how some legacy resources
                are numbered.

        """
        # maps "41" -> "40", etc. through 67/66, for the legacy
        # numbering system that assigns 41 to MAT. The resulting book
        # instance uses non-legacy numbers: this is just to get to the
        # right Book instance.
        _legacynumbermap = {str(i): str(i + 1) for i in list(range(40, 67))}
        if legacynumbering:
            usfmnumbermap = {_legacynumbermap.get(b.usfmnumber, b.usfmnumber): b for _, b in self.data.items()}
        else:
            usfmnumbermap = {b.usfmnumber: b for _, b in self.data.items()}
        #        return usfmnumbermap[usfmnumber]
        bookinst: Book = usfmnumbermap.get(usfmnumber)
        assert bookinst, f"Invalid USFM number: {usfmnumber}"
        return bookinst

    def get_bookname(self, usfmnumber: str, style: str) -> str:
        """Return the book name for usfmnumber in the requested style."""
        assert style in (
            "usfmname",
            "name",
            "osisID",
            "biblia",
        ), f"Unknown style {style} for book name."
        bookinst: Book = self.fromusfmnumber(usfmnumber)
        ref: str = getattr(bookinst, style)
        return ref

    def findbook(self, bookname: str) -> Book:
        """Find the book instance for a book name.

        Case must match. If not found in any name map, raise a
        ValueError.

        This may require looking at multiple naming schemes to find a
        match. The first match is returned, but i don't believe order
        consulted should change results.

        Args:
            bookname: the abbreviation or full name to use in looking up the Book,
                like 'MATT', 'MRK, or "Matthew".

        """
        # some minor standardization: this is not an extensible
        # approach, and long form names should use a different
        # approach
        bookname = self.quickfixes.get(bookname, bookname)
        namemaps = [self.data, self.namemap, self.logosmap, self.bibliamap, self.osismap]
        # there's probably a smarter way
        self._ensure_osismap()
        self._ensure_bibliamap()
        for namemap in namemaps:
            if bookname in namemap:
                book: Book = namemap[bookname]
                return book
        else:
            raise ValueError(f"Book name not found: {bookname}")


class _Canon(Books):
    """Return an Books instance representing a specific canon and order."""

    bookids = []

    def __init__(self, *args, **kwargs) -> None:
        """Initialize a Books instance for a Canon."""
        super().__init__(*args, **kwargs)
        # reset the data to only recognized bookids, adding an ordinal
        # for ordering
        srcdata = self.data
        self.data = {}
        for index, bookid in enumerate(self.bookids):
            book = srcdata[bookid]
            book.ordinal = index
            self.data[bookid] = book


class NTCanon(_Canon):
    """Return an Book instance representing the New Testament canon."""

    # fmt: off
    bookids = [
        "MAT", "MRK", "LUK", "JHN", "ACT", "ROM", "1CO", "2CO", "GAL", "EPH", "PHP", "COL", "1TH", "2TH",
        "1TI", "2TI", "TIT", "PHM", "HEB", "JAS", "1PE", "2PE", "1JN", "2JN", "3JN", "JUD", "REV"]


class ProtestantCanon(_Canon):
    """Return an Book instance representing the 66-book Protestant canon.

    This does not include the Deuterocanonical books.
    """

    # fmt: off
    bookids = [
        "GEN", "EXO", "LEV", "NUM", "DEU", "JOS", "JDG", "RUT", "1SA", "2SA", "1KI", "2KI", "1CH", "2CH",
        "EZR", "NEH", "EST", "JOB", "PSA", "PRO", "ECC", "SNG", "ISA", "JER", "LAM", "EZK", "DAN",
        "HOS", "JOL", "AMO", "OBA", "JON", "MIC", "NAM", "HAB", "ZEP", "HAG", "ZEC", "MAL",
        "MAT", "MRK", "LUK", "JHN", "ACT", "ROM", "1CO", "2CO", "GAL", "EPH", "PHP", "COL", "1TH", "2TH",
        "1TI", "2TI", "TIT", "PHM", "HEB", "JAS", "1PE", "2PE", "1JN", "2JN", "3JN", "JUD", "REV"]
    # fmt: on


class CatholicCanon(_Canon):
    """Return a  Book instance representing the 73-book Catholic canon.

    This reflects the order in the New American Bible. The order may
    differ in other editions (e.g. Douay-Rheims puts "1MA" and "2MA"
    after "MAL".)

    """

    # fmt: off
    bookids = [
        "GEN", "EXO", "LEV", "NUM", "DEU", "JOS", "JDG", "RUT", "1SA", "2SA", "1KI", "2KI", "1CH", "2CH",
        "EZR", "NEH", "TOB", "JDT", "ESG", "1MA", "2MA",
        "JOB", "PSA", "PRO", "ECC", "SNG", "WIS", "SIR",
        "ISA", "JER", "LAM", "BAR", "EZK",
        # should this be Greek Daniel "DAG"?
        "DAN",
        "HOS", "JOL", "AMO", "OBA", "JON", "MIC", "NAM", "HAB", "ZEP", "HAG", "ZEC", "MAL",
        "MAT", "MRK", "LUK", "JHN", "ACT", "ROM", "1CO", "2CO", "GAL", "EPH", "PHP", "COL", "1TH", "2TH",
        "1TI", "2TI", "TIT", "PHM", "HEB", "JAS", "1PE", "2PE", "1JN", "2JN", "3JN", "JUD", "REV"]
    # fmt: on


# maybe subclass Books for specific canons??
