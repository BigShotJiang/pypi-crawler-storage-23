import os
import json
import logging
from typing import Iterator, AsyncIterator, List, Optional, Any, overload
import litellm
from pydantic import BaseModel
from windows_use.llms.base import BaseChatLLM
from windows_use.llms.views import ChatLLMResponse, ChatLLMUsage, Metadata
from windows_use.messages import BaseMessage, SystemMessage, HumanMessage, AIMessage, ImageMessage, ToolMessage
from windows_use.tool import Tool

logger = logging.getLogger(__name__)


class ChatLiteLLM(BaseChatLLM):
    """
    LiteLLM wrapper implementation following the BaseChatLLM protocol.

    LiteLLM provides a unified interface to 100+ LLM providers using the OpenAI format.
    Model names follow the LiteLLM convention: "provider/model-name"
    (e.g., "anthropic/claude-3-5-sonnet-latest", "openai/gpt-4o", "gemini/gemini-2.0-flash").

    Supports:
    - Standard chat completions via any LiteLLM-supported provider
    - Tool/function calling
    - Structured outputs (via JSON mode fallback)
    - Streaming (sync and async)
    - Vision (image inputs)
    - Custom API keys and base URLs per provider
    """

    def __init__(
        self,
        model: str,
        api_key: Optional[str] = None,
        api_base: Optional[str] = None,
        timeout: float = 600.0,
        max_retries: int = 2,
        temperature: Optional[float] = None,
        drop_params: bool = True,
        **kwargs,
    ):
        """
        Initialize the LiteLLM wrapper.

        Args:
            model: The model name in LiteLLM format (e.g., "anthropic/claude-3-5-sonnet-latest").
            api_key: API key for the provider. If not set, LiteLLM will use the
                     appropriate environment variable (e.g., OPENAI_API_KEY, ANTHROPIC_API_KEY).
            api_base: Custom base URL for the provider API.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retries for failed requests.
            temperature: Sampling temperature.
            drop_params: If True, LiteLLM will silently drop unsupported params instead of raising.
            **kwargs: Additional arguments passed through to litellm.completion().
        """
        self._model = model
        self.api_key = api_key
        self.api_base = api_base
        self.timeout = timeout
        self.max_retries = max_retries
        self.temperature = temperature
        self.drop_params = drop_params
        self.kwargs = kwargs

        # Configure LiteLLM settings
        litellm.drop_params = self.drop_params

    @property
    def model_name(self) -> str:
        return self._model

    @property
    def provider(self) -> str:
        return "litellm"

    def _convert_messages(self, messages: List[BaseMessage]) -> List[dict]:
        """
        Convert BaseMessage objects to OpenAI-compatible message dictionaries.
        LiteLLM uses the OpenAI message format for all providers.
        """
        converted = []
        for msg in messages:
            if isinstance(msg, SystemMessage):
                converted.append({"role": "system", "content": msg.content})
            elif isinstance(msg, HumanMessage):
                converted.append({"role": "user", "content": msg.content})
            elif isinstance(msg, ImageMessage):
                content_list = []
                if msg.content:
                    content_list.append({"type": "text", "text": msg.content})

                b64_imgs = msg.convert_images(format="base64")
                for b64 in b64_imgs:
                    content_list.append({
                        "type": "image_url",
                        "image_url": {"url": f"data:{msg.mime_type};base64,{b64}"},
                    })
                converted.append({"role": "user", "content": content_list})
            elif isinstance(msg, AIMessage):
                converted.append({"role": "assistant", "content": msg.content or ""})
            elif isinstance(msg, ToolMessage):
                # Reconstruct the tool call and result for history consistency
                tool_call = {
                    "id": msg.id,
                    "type": "function",
                    "function": {
                        "name": msg.name,
                        "arguments": json.dumps(msg.params),
                    },
                }
                converted.append({
                    "role": "assistant",
                    "content": None,
                    "tool_calls": [tool_call],
                })
                converted.append({
                    "role": "tool",
                    "tool_call_id": msg.id,
                    "content": msg.content or "",
                })
        return converted

    def _convert_tools(self, tools: List[Tool]) -> List[dict]:
        """
        Convert Tool objects to OpenAI-compatible tool definitions.
        """
        return [
            {
                "type": "function",
                "function": tool.json_schema,
            }
            for tool in tools
        ]

    def _build_params(
        self,
        messages: List[dict],
        tools: Optional[List[dict]] = None,
        stream: bool = False,
        json_mode: bool = False,
    ) -> dict:
        """
        Build the common parameters dict for litellm calls.
        """
        params: dict[str, Any] = {
            "model": self._model,
            "messages": messages,
            "timeout": self.timeout,
            "num_retries": self.max_retries,
            **self.kwargs,
        }

        if self.api_key:
            params["api_key"] = self.api_key
        if self.api_base:
            params["api_base"] = self.api_base
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if tools:
            params["tools"] = tools
        if stream:
            params["stream"] = True
            params["stream_options"] = {"include_usage": True}
        if json_mode:
            params["response_format"] = {"type": "json_object"}

        return params

    def _extract_usage(self, usage_data: Any) -> ChatLLMUsage:
        """
        Extract usage information from a LiteLLM response.
        """
        prompt_tokens = getattr(usage_data, "prompt_tokens", 0) or 0
        completion_tokens = getattr(usage_data, "completion_tokens", 0) or 0
        total_tokens = getattr(usage_data, "total_tokens", 0) or 0

        # Extract reasoning/thinking tokens if available
        reasoning_tokens = None
        if hasattr(usage_data, "completion_tokens_details") and usage_data.completion_tokens_details:
            reasoning_tokens = getattr(
                usage_data.completion_tokens_details, "reasoning_tokens", None
            )

        # Extract cache tokens if available
        cache_creation = None
        cache_read = None
        if hasattr(usage_data, "cache_creation_input_tokens"):
            cache_creation = getattr(usage_data, "cache_creation_input_tokens", None)
        if hasattr(usage_data, "cache_read_input_tokens"):
            cache_read = getattr(usage_data, "cache_read_input_tokens", None)

        return ChatLLMUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            total_tokens=total_tokens,
            reasoning_tokens=reasoning_tokens,
            cache_creation_input_tokens=cache_creation,
            cache_read_input_tokens=cache_read,
        )

    def _process_response(self, response: Any) -> ChatLLMResponse:
        """
        Process a LiteLLM response (OpenAI-compatible format) into ChatLLMResponse.
        """
        choice = response.choices[0]
        message = choice.message
        usage = self._extract_usage(response.usage) if response.usage else None

        # Check for thinking/reasoning content
        thinking = None
        if hasattr(message, "reasoning_content") and message.reasoning_content:
            thinking = message.reasoning_content

        content = None
        if hasattr(message, "tool_calls") and message.tool_calls:
            tool_call = message.tool_calls[0]
            try:
                params = json.loads(tool_call.function.arguments)
            except json.JSONDecodeError:
                logger.warning(f"Failed to parse tool arguments: {tool_call.function.arguments}")
                params = {}

            content = ToolMessage(
                id=tool_call.id,
                name=tool_call.function.name,
                params=params,
            )
        else:
            content = AIMessage(content=message.content or "")

        if thinking and hasattr(content, "thinking"):
            content.thinking = thinking

        return ChatLLMResponse(
            content=content,
            thinking=thinking,
            usage=usage,
        )

    @overload
    def invoke(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> ChatLLMResponse: ...

    def invoke(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> ChatLLMResponse:
        converted_messages = self._convert_messages(messages)
        converted_tools = self._convert_tools(tools) if tools else None

        if structured_output:
            # Use JSON mode and parse the output into the structured model
            params = self._build_params(
                converted_messages, converted_tools, json_mode=True
            )
            response = litellm.completion(**params)

            try:
                content_text = response.choices[0].message.content
                parsed_data = json.loads(content_text)
                parsed_obj = structured_output(**parsed_data)

                usage = self._extract_usage(response.usage) if response.usage else None
                return ChatLLMResponse(content=parsed_obj, usage=usage)
            except (json.JSONDecodeError, TypeError, ValueError) as e:
                logger.error(f"Failed to parse structured output: {e}")
                # Fall through to normal processing

        params = self._build_params(converted_messages, converted_tools, json_mode=json_mode)
        response = litellm.completion(**params)
        return self._process_response(response)

    @overload
    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> ChatLLMResponse: ...

    async def ainvoke(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> ChatLLMResponse:
        converted_messages = self._convert_messages(messages)
        converted_tools = self._convert_tools(tools) if tools else None

        if structured_output:
            params = self._build_params(
                converted_messages, converted_tools, json_mode=True
            )
            response = await litellm.acompletion(**params)

            try:
                content_text = response.choices[0].message.content
                parsed_data = json.loads(content_text)
                parsed_obj = structured_output(**parsed_data)

                usage = self._extract_usage(response.usage) if response.usage else None
                return ChatLLMResponse(content=parsed_obj, usage=usage)
            except (json.JSONDecodeError, TypeError, ValueError) as e:
                logger.error(f"Failed to parse structured output: {e}")

        params = self._build_params(converted_messages, converted_tools, json_mode=json_mode)
        response = await litellm.acompletion(**params)
        return self._process_response(response)

    @overload
    def stream(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> Iterator[ChatLLMResponse]: ...

    def stream(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> Iterator[ChatLLMResponse]:
        converted_messages = self._convert_messages(messages)
        converted_tools = self._convert_tools(tools) if tools else None
        params = self._build_params(
            converted_messages, converted_tools, stream=True, json_mode=json_mode
        )

        response = litellm.completion(**params)

        for chunk in response:
            if not chunk.choices:
                # Final chunk may contain usage
                if hasattr(chunk, "usage") and chunk.usage:
                    yield ChatLLMResponse(usage=self._extract_usage(chunk.usage))
                continue

            delta = chunk.choices[0].delta

            if hasattr(delta, "content") and delta.content:
                yield ChatLLMResponse(content=AIMessage(content=delta.content))

            # Handle reasoning/thinking content in stream
            if hasattr(delta, "reasoning_content") and delta.reasoning_content:
                yield ChatLLMResponse(thinking=delta.reasoning_content)

    @overload
    async def astream(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> AsyncIterator[ChatLLMResponse]: ...

    async def astream(
        self,
        messages: list[BaseMessage],
        tools: list[Tool] = [],
        structured_output: BaseModel | None = None,
        json_mode: bool = False,
    ) -> AsyncIterator[ChatLLMResponse]:
        converted_messages = self._convert_messages(messages)
        converted_tools = self._convert_tools(tools) if tools else None
        params = self._build_params(
            converted_messages, converted_tools, stream=True, json_mode=json_mode
        )

        response = await litellm.acompletion(**params)

        async for chunk in response:
            if not chunk.choices:
                if hasattr(chunk, "usage") and chunk.usage:
                    yield ChatLLMResponse(usage=self._extract_usage(chunk.usage))
                continue

            delta = chunk.choices[0].delta

            if hasattr(delta, "content") and delta.content:
                yield ChatLLMResponse(content=AIMessage(content=delta.content))

            if hasattr(delta, "reasoning_content") and delta.reasoning_content:
                yield ChatLLMResponse(thinking=delta.reasoning_content)

    def get_metadata(self) -> Metadata:
        # Try to get model info from LiteLLM's model registry
        try:
            model_info = litellm.get_model_info(self._model)
            context_window = model_info.get("max_input_tokens", 128000)
            owned_by = model_info.get("litellm_provider", "unknown")
        except Exception:
            context_window = 128000  # Safe default
            owned_by = "unknown"

        return Metadata(
            name=self._model,
            context_window=context_window,
            owned_by=owned_by,
        )
