"""
telegram_async - Nowoczesna biblioteka asynchroniczna do Telegram Bot API
Wzorowana na aiogram 3.x

Szybki start:
    from telegram_async import Bot, Dispatcher, types
    from telegram_async.filters import Command

    bot = Bot("TOKEN")
    dp = Dispatcher()

    @dp.message(Command("start"))
    async def start(message: types.Message):
        await message.answer("Cześć!")

    async def main():
        await dp.start_polling(bot)
"""

from .bot import Bot
from .client import TelegramClient
from .dispatcher import Dispatcher
from .context import Context
from . import types
from . import filters
from . import keyboards
from . import fsm

__version__ = "0.1.0"
__all__ = [
    "Bot",
    "Dispatcher",
    "Context",
    "types",
    "filters",
    "keyboards",
    "fsm",
]