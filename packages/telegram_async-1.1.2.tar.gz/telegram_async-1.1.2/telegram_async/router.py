from typing import Dict, List, Callable, Any, Optional, Union
from .filters import Filter
from .context import Context
from .exceptions import SkipHandler


class Router:
    def __init__(self, name: str = "main"):
        self.name = name
        self.message_handlers: List[Dict[str, Any]] = []
        self.callback_handlers: List[Dict[str, Any]] = []
        self.routers: List[Router] = []

    def message(self, *filters: Filter):
        """Dekorator dla handlerów wiadomości"""

        def decorator(func: Callable):
            self.message_handlers.append({
                'func': func,
                'filters': filters
            })
            return func

        return decorator

    def callback(self, *filters: Filter):
        """Dekorator dla handlerów callback query"""

        def decorator(func: Callable):
            self.callback_handlers.append({
                'func': func,
                'filters': filters
            })
            return func

        return decorator

    def include_router(self, router: 'Router'):
        """Dołącz pod-router"""
        self.routers.append(router)

    async def process_message(
            self,
            context: Context,
            state: Optional['State'] = None
    ) -> bool:
        """Przetwórz wiadomość przez wszystkie handlery"""

        # Sprawdź pod-routery
        for router in self.routers:
            if await router.process_message(context, state):
                return True

        # Sprawdź handlery
        for handler in self.message_handlers:
            try:
                if await self._check_filters(handler['filters'], context.message, state):
                    await handler['func'](context)
                    return True
            except SkipHandler:
                continue

        return False

    async def process_callback(
            self,
            context: Context,
            state: Optional['State'] = None
    ) -> bool:
        """Przetwórz callback query"""

        # Sprawdź pod-routery
        for router in self.routers:
            if await router.process_callback(context, state):
                return True

        # Sprawdź handlery
        for handler in self.callback_handlers:
            try:
                if await self._check_filters(handler['filters'], context.callback_query, state):
                    await handler['func'](context)
                    return True
            except SkipHandler:
                continue

        return False

    async def _check_filters(
            self,
            filters: tuple[Filter],
            obj: Any,
            state: Optional['State'] = None
    ) -> bool:
        """Sprawdź czy obiekt przechodzi przez filtry"""

        for filter_obj in filters:
            # Sprawdź stan jeśli to potrzebne
            if isinstance(filter_obj, StateFilter) and state:
                if not await filter_obj(obj, state):
                    return False
            else:
                if not await filter_obj(obj):
                    return False

        return True


# Alias dla StateFilter (będzie zaimplementowany w fsm.py)
class StateFilter:
    def __init__(self, state: Optional[str] = None):
        self.state = state

    async def __call__(self, obj: Any, state: 'State') -> bool:
        current_state = await state.get_state()

        if self.state is None:
            return current_state is not None

        return current_state == self.state