from dataclasses import dataclass
from typing import Optional, Dict, Any, List
from datetime import datetime


@dataclass
class User:
    id: int
    is_bot: bool
    first_name: str
    last_name: Optional[str] = None
    username: Optional[str] = None
    language_code: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict) -> 'User':
        return cls(
            id=data['id'],
            is_bot=data.get('is_bot', False),
            first_name=data.get('first_name', ''),
            last_name=data.get('last_name'),
            username=data.get('username'),
            language_code=data.get('language_code')
        )


@dataclass
class Chat:
    id: int
    type: str
    title: Optional[str] = None
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict) -> 'Chat':
        return cls(
            id=data['id'],
            type=data['type'],
            title=data.get('title'),
            username=data.get('username'),
            first_name=data.get('first_name'),
            last_name=data.get('last_name')
        )


@dataclass
class Message:
    message_id: int
    date: datetime
    chat: Chat
    from_user: Optional[User] = None
    text: Optional[str] = None
    caption: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict) -> 'Message':
        return cls(
            message_id=data['message_id'],
            date=datetime.fromtimestamp(data['date']),
            chat=Chat.from_dict(data['chat']),
            from_user=User.from_dict(data['from']) if 'from' in data else None,
            text=data.get('text'),
            caption=data.get('caption')
        )


@dataclass
class CallbackQuery:
    id: str
    from_user: User
    message: Optional[Message] = None
    data: Optional[str] = None
    chat_instance: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict) -> 'CallbackQuery':
        return cls(
            id=data['id'],
            from_user=User.from_dict(data['from']),
            message=Message.from_dict(data['message']) if 'message' in data else None,
            data=data.get('data'),
            chat_instance=data.get('chat_instance')
        )


@dataclass
class Update:
    update_id: int
    message: Optional[Message] = None
    edited_message: Optional[Message] = None
    channel_post: Optional[Message] = None
    edited_channel_post: Optional[Message] = None
    callback_query: Optional[CallbackQuery] = None

    @classmethod
    def from_dict(cls, data: Dict) -> 'Update':
        return cls(
            update_id=data['update_id'],
            message=Message.from_dict(data['message']) if 'message' in data else None,
            edited_message=Message.from_dict(data['edited_message']) if 'edited_message' in data else None,
            channel_post=Message.from_dict(data['channel_post']) if 'channel_post' in data else None,
            edited_channel_post=Message.from_dict(
                data['edited_channel_post']) if 'edited_channel_post' in data else None,
            callback_query=CallbackQuery.from_dict(data['callback_query']) if 'callback_query' in data else None
        )