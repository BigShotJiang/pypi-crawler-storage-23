from typing import List, Dict, Any, Optional, Union


class InlineKeyboardButton:
    def __init__(
            self,
            text: str,
            callback_data: Optional[str] = None,
            url: Optional[str] = None
    ):
        self.text = text
        self.callback_data = callback_data
        self.url = url

    def to_dict(self) -> Dict[str, str]:
        data = {'text': self.text}
        if self.callback_data:
            data['callback_data'] = self.callback_data
        if self.url:
            data['url'] = self.url
        return data


class InlineKeyboardMarkup:
    def __init__(self, inline_keyboard: List[List[InlineKeyboardButton]]):
        self.inline_keyboard = inline_keyboard

    @classmethod
    def row(cls, *buttons: InlineKeyboardButton) -> 'InlineKeyboardMarkup':
        return cls([list(buttons)])

    def add(self, *buttons: InlineKeyboardButton) -> 'InlineKeyboardMarkup':
        self.inline_keyboard.append(list(buttons))
        return self

    def to_dict(self) -> Dict[str, List[List[Dict]]]:
        return {
            'inline_keyboard': [
                [btn.to_dict() for btn in row]
                for row in self.inline_keyboard
            ]
        }


class ReplyKeyboardButton:
    def __init__(self, text: str):
        self.text = text

    def to_dict(self) -> Dict[str, str]:
        return {'text': self.text}


class ReplyKeyboardMarkup:
    def __init__(
            self,
            keyboard: List[List[ReplyKeyboardButton]],
            resize_keyboard: bool = True,
            one_time_keyboard: bool = False
    ):
        self.keyboard = keyboard
        self.resize_keyboard = resize_keyboard
        self.one_time_keyboard = one_time_keyboard

    @classmethod
    def row(cls, *buttons: str) -> 'ReplyKeyboardMarkup':
        keyboard = [[ReplyKeyboardButton(text) for text in buttons]]
        return cls(keyboard)

    def add(self, *buttons: str) -> 'ReplyKeyboardMarkup':
        self.keyboard.append([ReplyKeyboardButton(text) for text in buttons])
        return self

    def to_dict(self) -> Dict[str, Any]:
        return {
            'keyboard': [
                [btn.to_dict() for btn in row]
                for row in self.keyboard
            ],
            'resize_keyboard': self.resize_keyboard,
            'one_time_keyboard': self.one_time_keyboard
        }


class ForceReply:
    def __init__(self, selective: bool = True):
        self.selective = selective

    def to_dict(self) -> Dict[str, Any]:
        return {
            'force_reply': True,
            'selective': self.selective
        }