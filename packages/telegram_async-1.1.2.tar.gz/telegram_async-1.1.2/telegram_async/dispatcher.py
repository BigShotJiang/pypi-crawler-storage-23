import asyncio
from typing import Dict, List, Callable, Any, Optional
from .context import Context
from .types import Update
from .client import TelegramClient


class Dispatcher:
    """Dyspozytor wiadomości"""

    def __init__(self):
        self.handlers: Dict[str, List[Callable]] = {
            'message': [],
            'callback': [],
            'command': {}
        }
        self.middlewares: List[Callable] = []
        self._startup_hooks: List[Callable] = []  # Dodane
        self._shutdown_hooks: List[Callable] = []  # Dodane
        self._running = False

    def startup(self):
        """Dekorator dla funkcji uruchamianych przy starcie"""

        def decorator(func: Callable):
            self._startup_hooks.append(func)
            return func

        return decorator

    def shutdown(self):
        """Dekorator dla funkcji uruchamianych przy zamykaniu"""

        def decorator(func: Callable):
            self._shutdown_hooks.append(func)
            return func

        return decorator

    async def _run_startup_hooks(self):
        """Uruchamia hooki startupowe"""
        for hook in self._startup_hooks:
            try:
                await hook()
            except Exception as e:
                print(f"Błąd w hooku startupowym: {e}")

    async def _run_shutdown_hooks(self):
        """Uruchamia hooki shutdownowe"""
        for hook in self._shutdown_hooks:
            try:
                await hook()
            except Exception as e:
                print(f"Błąd w hooku shutdownowym: {e}")

    def message(self, *filters):
        """Dekorator dla handlerów wiadomości"""

        def decorator(func: Callable):
            self.handlers['message'].append({
                'func': func,
                'filters': filters
            })
            return func

        return decorator

    def command(self, command: str):
        """Dekorator dla handlerów komend"""

        def decorator(func: Callable):
            self.handlers['command'][command] = func
            return func

        return decorator

    def callback(self, *filters):
        """Dekorator dla callback query"""

        def decorator(func: Callable):
            self.handlers['callback'].append({
                'func': func,
                'filters': filters
            })
            return func

        return decorator

    def middleware(self):
        """Dekorator dla middleware"""

        def decorator(func: Callable):
            self.middlewares.append(func)
            return func

        return decorator

    async def process_update(self, client: TelegramClient, update_data: Dict):
        """Przetwarza pojedynczy update"""
        try:
            update = Update.from_dict(update_data)
            ctx = Context(client, update)

            # Uruchom middleware
            async def run_handlers():
                if update.message:
                    await self._process_message(ctx)
                elif update.callback_query:
                    await self._process_callback(ctx)

            await self._run_middlewares(ctx, run_handlers)
        except Exception as e:
            print(f"Error processing update: {e}")

    async def _run_middlewares(self, ctx: Context, handler: Callable):
        """Uruchamia łańcuch middleware"""
        index = 0

        async def next_middleware():
            nonlocal index
            if index < len(self.middlewares):
                current = self.middlewares[index]
                index += 1
                await current(ctx, next_middleware)
            else:
                await handler()

        await next_middleware()

    async def _process_message(self, ctx: Context):
        """Przetwarza wiadomość"""
        if not ctx.message or not ctx.message.text:
            return

        # Sprawdź czy to komenda
        if ctx.message.text.startswith('/'):
            cmd = ctx.message.text.split()[0][1:]  # usuń '/'
            # Obsługa komend z @username
            if '@' in cmd:
                cmd = cmd.split('@')[0]

            if cmd in self.handlers['command']:
                await self.handlers['command'][cmd](ctx)
                return

        # Sprawdź handlery wiadomości
        for handler in self.handlers['message']:
            if await self._check_filters(handler['filters'], ctx.message):
                await handler['func'](ctx)
                return

    async def _process_callback(self, ctx: Context):
        """Przetwarza callback query"""
        if not ctx.callback_query:
            return

        for handler in self.handlers['callback']:
            if await self._check_filters(handler['filters'], ctx.callback_query):
                await handler['func'](ctx)
                return

    async def _check_filters(self, filters_list, obj) -> bool:
        """Sprawdza czy obiekt przechodzi przez filtry"""
        for f in filters_list:
            if not await f(obj):
                return False
        return True

    async def start_polling(self, client: TelegramClient, skip_updates: bool = True):
        """Rozpoczyna polling"""
        print("🤖 Bot wystartował! Naciśnij Ctrl+C aby zatrzymać.")
        self._running = True
        offset = None

        # Uruchom hooki startupowe
        await self._run_startup_hooks()

        try:
            # Pomiń stare update'y jeśli trzeba
            if skip_updates:
                try:
                    updates = await client.get_updates(limit=1)
                    if updates:
                        offset = updates[-1]['update_id'] + 1
                except Exception as e:
                    print(f"Błąd podczas pomijania update'ów: {e}")

            while self._running:
                try:
                    # Pobierz update'y
                    updates = await client.get_updates(
                        offset=offset,
                        timeout=30
                    )

                    # Przetwórz każdy update
                    for update in updates:
                        if offset is None or update['update_id'] >= offset:
                            offset = update['update_id'] + 1
                            # Utwórz task dla każdego update'u
                            asyncio.create_task(self.process_update(client, update))

                    # Krótka pauza
                    await asyncio.sleep(0.1)

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    print(f"❌ Błąd w pollingu: {e}")
                    await asyncio.sleep(1)

        except KeyboardInterrupt:
            print("\n👋 Zatrzymywanie bota...")
        finally:
            self._running = False
            # Uruchom hooki shutdownowe
            await self._run_shutdown_hooks()
            await client.close()
            print("✅ Bot zatrzymany")