from abc import ABC, abstractmethod
from typing import Union, Callable, Any, Optional
from .types import Message, CallbackQuery


class Filter(ABC):
    @abstractmethod
    async def __call__(self, obj: Any) -> bool:
        pass


class Command(Filter):
    def __init__(self, command: Union[str, list], prefix: str = '/'):
        self.commands = [command] if isinstance(command, str) else command
        self.prefix = prefix

    async def __call__(self, obj: Union[Message, CallbackQuery]) -> bool:
        if isinstance(obj, CallbackQuery):
            return False

        text = obj.text or obj.caption or ''
        for cmd in self.commands:
            if text.startswith(f"{self.prefix}{cmd}"):
                return True
        return False


class Text(Filter):
    def __init__(self, text: Union[str, list], ignore_case: bool = True):
        self.texts = [text] if isinstance(text, str) else text
        self.ignore_case = ignore_case

    async def __call__(self, obj: Message) -> bool:
        if not obj.text and not obj.caption:
            return False

        content = obj.text or obj.caption or ''
        if self.ignore_case:
            content = content.lower()
            texts = [t.lower() for t in self.texts]
        else:
            texts = self.texts

        return content in texts


class CallbackData(Filter):
    def __init__(self, data: Union[str, list]):
        self.data_patterns = [data] if isinstance(data, str) else data

    async def __call__(self, obj: CallbackQuery) -> bool:
        if not isinstance(obj, CallbackQuery):
            return False

        for pattern in self.data_patterns:
            if obj.data == pattern:
                return True
        return False


class State(Filter):
    def __init__(self, state: Optional[str] = None):
        self.state = state

    async def __call__(self, obj: Any) -> bool:
        return True  # Stan sprawdzany jest w dispatcherze


def command(command: Union[str, list]) -> Command:
    return Command(command)


def text(text: Union[str, list]) -> Text:
    return Text(text)


def callback_data(data: Union[str, list]) -> CallbackData:
    return CallbackData(data)


def state(state: str = None) -> State:
    return State(state)