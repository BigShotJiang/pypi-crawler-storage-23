from typing import Dict, Any, Optional
from .context import Context


class State:
    def __init__(self, state: str):
        self.state = state

    def __str__(self) -> str:
        return self.state


class StatesGroup:
    @classmethod
    def __init_subclass__(cls, **kwargs):
        cls._states = []
        for attr_name in dir(cls):
            attr = getattr(cls, attr_name)
            if isinstance(attr, State):
                cls._states.append(attr)


class Storage:
    async def set_state(self, user_id: int, state: Optional[str]):
        raise NotImplementedError

    async def get_state(self, user_id: int) -> Optional[str]:
        raise NotImplementedError

    async def set_data(self, user_id: int, data: Dict[str, Any]):
        raise NotImplementedError

    async def get_data(self, user_id: int) -> Dict[str, Any]:
        raise NotImplementedError

    async def update_data(self, user_id: int, **kwargs):
        data = await self.get_data(user_id)
        data.update(kwargs)
        await self.set_data(user_id, data)

    async def clear(self, user_id: int):
        await self.set_state(user_id, None)
        await self.set_data(user_id, {})


class MemoryStorage(Storage):
    def __init__(self):
        self._data: Dict[int, Dict[str, Any]] = {}
        self._states: Dict[int, Optional[str]] = {}

    async def set_state(self, user_id: int, state: Optional[str]):
        self._states[user_id] = state

    async def get_state(self, user_id: int) -> Optional[str]:
        return self._states.get(user_id)

    async def set_data(self, user_id: int, data: Dict[str, Any]):
        self._data[user_id] = data

    async def get_data(self, user_id: int) -> Dict[str, Any]:
        return self._data.get(user_id, {}).copy()

    async def clear(self, user_id: int):
        if user_id in self._states:
            del self._states[user_id]
        if user_id in self._data:
            del self._data[user_id]


class FSMContext:
    def __init__(self, storage: Storage, user_id: int):
        self.storage = storage
        self.user_id = user_id

    async def set_state(self, state: Optional[Union[str, State]]):
        if isinstance(state, State):
            state = state.state
        await self.storage.set_state(self.user_id, state)

    async def get_state(self) -> Optional[str]:
        return await self.storage.get_state(self.user_id)

    async def set_data(self, data: Dict[str, Any]):
        await self.storage.set_data(self.user_id, data)

    async def get_data(self) -> Dict[str, Any]:
        return await self.storage.get_data(self.user_id)

    async def update_data(self, **kwargs):
        await self.storage.update_data(self.user_id, **kwargs)

    async def clear(self):
        await self.storage.clear(self.user_id)


class FSMContextProxy:
    def __init__(self, context: Context, state: FSMContext):
        self.context = context
        self.state = state

    async def set_state(self, state: Optional[Union[str, State]]):
        await self.state.set_state(state)

    async def get_state(self) -> Optional[str]:
        return await self.state.get_state()

    async def set_data(self, data: Dict[str, Any]):
        await self.state.set_data(data)

    async def get_data(self) -> Dict[str, Any]:
        return await self.state.get_data()

    async def update_data(self, **kwargs):
        await self.state.update_data(**kwargs)

    async def clear(self):
        await self.state.clear()