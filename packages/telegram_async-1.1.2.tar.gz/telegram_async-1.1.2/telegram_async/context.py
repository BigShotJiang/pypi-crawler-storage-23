from typing import Optional, Dict, Any
from .types import Message, CallbackQuery, Update
from .client import TelegramClient


class Context:
    """Kontekst dla handlerów"""

    def __init__(self, client: TelegramClient, update: Update):
        self.client = client
        self.update = update
        self.message: Optional[Message] = update.message
        self.callback_query: Optional[CallbackQuery] = update.callback_query
        self.data: Dict[str, Any] = {}  # miejsce na dane użytkownika

    @property
    def chat_id(self) -> Optional[int]:
        if self.message:
            return self.message.chat.id
        elif self.callback_query and self.callback_query.message:
            return self.callback_query.message.chat.id
        return None

    @property
    def user_id(self) -> Optional[int]:
        if self.message and self.message.from_user:
            return self.message.from_user.id
        elif self.callback_query:
            return self.callback_query.from_user.id
        return None

    async def reply(self, text: str, **kwargs):
        """Odpowiada na wiadomość"""
        if self.chat_id:
            return await self.client.send_message(self.chat_id, text, **kwargs)

    async def answer_callback(self, text: str = None, show_alert: bool = False):
        """Odpowiada na callback query"""
        if self.callback_query:
            return await self.client.answer_callback_query(
                self.callback_query.id,
                text,
                show_alert
            )

    async def edit_message(self, text: str, reply_markup: Optional[Dict] = None):
        """Edytuje wiadomość"""
        if self.message:
            return await self.client.edit_message_text(
                text,
                chat_id=self.message.chat.id,
                message_id=self.message.message_id,
                reply_markup=reply_markup
            )
        elif self.callback_query and self.callback_query.message:
            return await self.client.edit_message_text(
                text,
                chat_id=self.callback_query.message.chat.id,
                message_id=self.callback_query.message.message_id,
                reply_markup=reply_markup
            )
        return None