class TelegramError(Exception):
    """Base exception for all Telegram errors"""
    pass


class TelegramAPIError(TelegramError):
    """Raised when Telegram API returns an error"""
    pass


class SkipHandler(Exception):
    """Raised to skip current handler"""
    pass


class CancelHandler(Exception):
    """Raised to cancel all further processing"""
    pass