# SPDX-License-Identifier: MIT

"""disnake.types
~~~~~~~~~~~~~~

Typings for the Discord API

:copyright: (c) 2015-2021 Rapptz, 2021-present Disnake Development
:license: MIT, see LICENSE for more details.

"""
