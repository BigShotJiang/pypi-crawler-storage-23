# SPDX-License-Identifier: MIT

LocalizationDict = dict[str, str]
