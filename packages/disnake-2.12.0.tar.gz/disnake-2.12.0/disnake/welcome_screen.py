# SPDX-License-Identifier: MIT

from __future__ import annotations

from typing import TYPE_CHECKING

from . import utils
from .partial_emoji import PartialEmoji, _EmojiTag

if TYPE_CHECKING:
    from .emoji import Emoji
    from .guild import Guild
    from .invite import PartialInviteGuild
    from .state import ConnectionState
    from .types.welcome_screen import (
        WelcomeScreen as WelcomeScreenPayload,
        WelcomeScreenChannel as WelcomeScreenChannelPayload,
    )

__all__ = (
    "WelcomeScreen",
    "WelcomeScreenChannel",
)

MISSING = utils.MISSING


class WelcomeScreenChannel:
    """Represents a Discord welcome screen channel.

    .. versionadded:: 2.5

    Attributes
    ----------
    id: :class:`int`
        The ID of the guild channel this welcome screen channel represents.
    description: :class:`str`
        The description of this channel in the official UI.
    emoji: :class:`Emoji` | :class:`PartialEmoji` | :data:`None`
        The emoji associated with this channel's welcome message, if any.
    """

    __slots__ = (
        "id",
        "description",
        "emoji",
    )

    def __init__(
        self,
        *,
        id: int,
        description: str,
        emoji: str | Emoji | PartialEmoji | None = None,
    ) -> None:
        self.id: int = id
        self.description: str = description
        self.emoji: Emoji | PartialEmoji | None = None
        if emoji is None:
            self.emoji = None
        elif isinstance(emoji, str):
            self.emoji = PartialEmoji.from_str(emoji)
        elif isinstance(emoji, _EmojiTag):
            self.emoji = emoji
        else:
            msg = "emoji must be None, a str, PartialEmoji, or Emoji instance."
            raise TypeError(msg)

    def __repr__(self) -> str:
        return f"<WelcomeScreenChannel id={self.id!r} emoji={self.emoji!r} description={self.description!r}>"

    @classmethod
    def _from_data(
        cls,
        *,
        data: WelcomeScreenChannelPayload,
        state: ConnectionState,
    ) -> WelcomeScreenChannel:
        emoji = state._get_emoji_from_fields(
            name=data.get("emoji_name"),
            id=utils._get_as_snowflake(data, "emoji_id"),
        )

        return cls(id=int(data["channel_id"]), description=data["description"], emoji=emoji)

    def to_dict(self) -> WelcomeScreenChannelPayload:
        result: WelcomeScreenChannelPayload = {
            "channel_id": self.id,
            "description": self.description,
        }  # pyright: ignore[reportAssignmentType]

        if self.emoji is not None:
            if self.emoji.id:
                result["emoji_id"] = self.emoji.id
            result["emoji_name"] = self.emoji.name

        return result


class WelcomeScreen:
    r"""Represents a Discord welcome screen for a :class:`Guild`.

    .. versionadded:: 2.5

    Attributes
    ----------
    description: :class:`str` | :data:`None`
        The guild description in the welcome screen.
    channels: :class:`list`\[:class:`WelcomeScreenChannel`]
        The welcome screen's channels.
    """

    __slots__ = (
        "description",
        "channels",
        "_guild",
        "_state",
    )

    def __init__(
        self,
        *,
        data: WelcomeScreenPayload,
        state: ConnectionState,
        guild: Guild | PartialInviteGuild,
    ) -> None:
        self._state = state
        self._guild = guild
        self.description: str | None = data.get("description")
        self.channels: list[WelcomeScreenChannel] = [
            WelcomeScreenChannel._from_data(data=channel, state=state)
            for channel in data["welcome_channels"]
        ]

    def __repr__(self) -> str:
        return f"<WelcomeScreen description={self.description!r} channels={self.channels!r} enabled={self.enabled!r}>"

    @property
    def enabled(self) -> bool:
        """:class:`bool`: Whether the welcome screen is displayed to users.
        This is equivalent to checking if ``WELCOME_SCREEN_ENABLED`` is present in :attr:`Guild.features`.
        """
        return "WELCOME_SCREEN_ENABLED" in self._guild.features

    async def edit(
        self,
        *,
        enabled: bool = MISSING,
        description: str | None = MISSING,
        channels: list[WelcomeScreenChannel] | None = MISSING,
        reason: str | None = None,
    ) -> WelcomeScreen:
        r"""|coro|

        Edits the welcome screen.

        You must have the :attr:`~Permissions.manage_guild` permission to
        use this.

        This requires 'COMMUNITY' in :attr:`.Guild.features`.

        Parameters
        ----------
        enabled: :class:`bool`
            Whether the welcome screen is enabled.
        description: :class:`str` | :data:`None`
            The new guild description in the welcome screen.
        channels: :class:`list`\[:class:`WelcomeScreenChannel`] | :data:`None`
            The new welcome channels.
        reason: :class:`str` | :data:`None`
            The reason for editing the welcome screen. Shows up on the audit log.

        Raises
        ------
        Forbidden
            You do not have permissions to change the welcome screen
            or the guild is not allowed to create welcome screens.
        HTTPException
            Editing the welcome screen failed.
        TypeError
            ``channels`` is not a list of :class:`~disnake.WelcomeScreenChannel` instances

        Returns
        -------
        :class:`WelcomeScreen`
            The newly edited welcome screen.
        """
        from .guild import Guild

        if not isinstance(self._guild, Guild):
            msg = "May not edit a WelcomeScreen from a PartialInviteGuild."
            raise TypeError(msg)

        return await self._guild.edit_welcome_screen(
            enabled=enabled,
            channels=channels,
            description=description,
            reason=reason,
        )
