# SPDX-License-Identifier: MIT

from __future__ import annotations

import datetime
from collections.abc import Mapping, Sized
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Literal,
    Protocol,
    cast,
    overload,
)

from . import utils
from .colour import Colour
from .file import File
from .utils import MISSING, classproperty, warn_deprecated

__all__ = ("Embed",)


# backwards compatibility, hidden from type-checkers to have them show errors when accessed
if not TYPE_CHECKING:

    def __getattr__(name: str) -> None:
        if name == "EmptyEmbed":
            warn_deprecated(
                "`EmptyEmbed` is deprecated and will be removed in a future version. Use `None` instead.",
                stacklevel=2,
            )
            return None  # noqa: RET501
        msg = f"module '{__name__}' has no attribute '{name}'"
        raise AttributeError(msg)


class EmbedProxy:
    def __init__(self, layer: Mapping[str, Any] | None) -> None:
        if layer is not None:
            self.__dict__.update(layer)

    def __len__(self) -> int:
        return len(self.__dict__)

    def __repr__(self) -> str:
        inner = ", ".join((f"{k}={v!r}" for k, v in self.__dict__.items() if not k.startswith("_")))
        return f"EmbedProxy({inner})"

    def __getattr__(self, attr: str) -> None:
        return None

    def __eq__(self, other: object) -> bool:
        return isinstance(other, EmbedProxy) and self.__dict__ == other.__dict__


if TYPE_CHECKING:
    from typing_extensions import Self

    from disnake.types.embed import (
        Embed as EmbedData,
        EmbedAuthor as EmbedAuthorPayload,
        EmbedField as EmbedFieldPayload,
        EmbedFooter as EmbedFooterPayload,
        EmbedImage as EmbedImagePayload,
        EmbedProvider as EmbedProviderPayload,
        EmbedThumbnail as EmbedThumbnailPayload,
        EmbedType,
        EmbedVideo as EmbedVideoPayload,
    )

    class _EmbedFooterProxy(Sized, Protocol):
        text: str | None
        icon_url: str | None
        proxy_icon_url: str | None

    class _EmbedFieldProxy(Sized, Protocol):
        name: str | None
        value: str | None
        inline: bool | None

    class _EmbedMediaProxy(Sized, Protocol):
        url: str | None
        proxy_url: str | None
        height: int | None
        width: int | None

    class _EmbedVideoProxy(Sized, Protocol):
        url: str | None
        proxy_url: str | None
        height: int | None
        width: int | None

    class _EmbedProviderProxy(Sized, Protocol):
        name: str | None
        url: str | None

    class _EmbedAuthorProxy(Sized, Protocol):
        name: str | None
        url: str | None
        icon_url: str | None
        proxy_icon_url: str | None

    _FileKey = Literal["image", "thumbnail", "footer", "author"]


class Embed:
    """Represents a Discord embed.

    .. collapse:: operations

        .. describe:: x == y

            Checks if two embeds are equal.

            .. versionadded:: 2.6

        .. describe:: x != y

            Checks if two embeds are not equal.

            .. versionadded:: 2.6

        .. describe:: len(x)

            Returns the total size of the embed.
            Useful for checking if it's within the 6000 character limit.
            Check if all aspects of the embed are within the limits with :func:`Embed.check_limits`.

        .. describe:: bool(b)

            Returns whether the embed has any data set.

            .. versionadded:: 2.0

    Certain properties return an ``EmbedProxy``, a type
    that acts similar to a regular :class:`dict` except using dotted access,
    e.g. ``embed.author.icon_url``.

    For ease of use, all parameters that expect a :class:`str` are implicitly
    cast to :class:`str` for you.

    Attributes
    ----------
    title: :class:`str` | :data:`None`
        The title of the embed.
    type: :class:`str` | :data:`None`
        The type of embed. Usually "rich".
        Possible strings for embed types can be found on Discord's
        :ddocs:`api-docs <resources/message#embed-object-embed-types>`.
    description: :class:`str` | :data:`None`
        The description of the embed.
    url: :class:`str` | :data:`None`
        The URL of the embed.
    timestamp: :class:`datetime.datetime` | :data:`None`
        The timestamp of the embed content. This is an aware datetime.
        If a naive datetime is passed, it is converted to an aware
        datetime with the local timezone.
    colour: :class:`Colour` | :data:`None`
        The colour code of the embed. Aliased to ``color`` as well.
        In addition to :class:`Colour`, :class:`int` can also be assigned to it,
        in which case the value will be converted to a :class:`Colour` object.
    """

    __slots__ = (
        "title",
        "url",
        "type",
        "_timestamp",
        "_colour",
        "_footer",
        "_image",
        "_thumbnail",
        "_video",
        "_provider",
        "_author",
        "_fields",
        "description",
        "_files",
    )

    _default_colour: ClassVar[Colour | None] = None
    _colour: Colour | None

    def __init__(
        self,
        *,
        title: object | None = None,
        type: EmbedType | None = "rich",
        description: object | None = None,
        url: object | None = None,
        timestamp: datetime.datetime | None = None,
        colour: int | Colour | None = MISSING,
        color: int | Colour | None = MISSING,
    ) -> None:
        self.title: str | None = str(title) if title is not None else None
        self.type: EmbedType | None = type
        self.description: str | None = str(description) if description is not None else None
        self.url: str | None = str(url) if url is not None else None

        self.timestamp = timestamp

        # possible values:
        # - MISSING: embed color will be _default_color
        # - None: embed color will not be set
        # - Color: embed color will be set to specified color
        if colour is not MISSING:
            color = colour
        self.colour = color

        self._thumbnail: EmbedThumbnailPayload | None = None
        self._video: EmbedVideoPayload | None = None
        self._provider: EmbedProviderPayload | None = None
        self._author: EmbedAuthorPayload | None = None
        self._image: EmbedImagePayload | None = None
        self._footer: EmbedFooterPayload | None = None
        self._fields: list[EmbedFieldPayload] | None = None

        self._files: dict[_FileKey, File] = {}

    # see `EmptyEmbed` above
    if not TYPE_CHECKING:
        # n.b. this is the only use site of classproperty
        @classproperty
        def Empty(self) -> None:
            warn_deprecated(
                "`Embed.Empty` is deprecated and will be removed in a future version. Use `None` instead.",
                stacklevel=3,
            )
            return None  # noqa: RET501

    @classmethod
    def from_dict(cls, data: EmbedData) -> Self:
        """Converts a :class:`dict` to a :class:`Embed` provided it is in the
        format that Discord expects it to be in.

        You can find out about this format in the
        :ddocs:`official Discord documentation <resources/message#embed-object>`.

        Parameters
        ----------
        data: :class:`dict`
            The dictionary to convert into an embed.
        """
        # we are bypassing __init__ here since it doesn't apply here
        self = cls.__new__(cls)

        # fill in the basic fields

        self.title = str(title) if (title := data.get("title")) is not None else None
        self.type = data.get("type")
        self.description = (
            str(description) if (description := data.get("description")) is not None else None
        )
        self.url = str(url) if (url := data.get("url")) is not None else None

        self._files = {}

        # try to fill in the more rich fields

        self.colour = data.get("color")
        self.timestamp = utils.parse_time(data.get("timestamp"))

        self._thumbnail = data.get("thumbnail")
        self._video = data.get("video")
        self._provider = data.get("provider")
        self._author = data.get("author")
        self._image = data.get("image")
        self._footer = data.get("footer")
        self._fields = data.get("fields")

        return self

    def copy(self) -> Self:
        """Returns a shallow copy of the embed."""
        embed = type(self).from_dict(self.to_dict())

        # assign manually to keep behavior of default colors
        embed._colour = self._colour

        # copy files and fields collections
        embed._files = self._files.copy()
        if self._fields is not None:
            embed._fields = self._fields.copy()

        return embed

    def __len__(self) -> int:
        total = len((self.title or "").strip()) + len((self.description or "").strip())
        if self._fields:
            for field in self._fields:
                total += len(field["name"].strip()) + len(field["value"].strip())

        if self._footer and (footer_text := self._footer.get("text")):
            total += len(footer_text.strip())

        if self._author and (author_name := self._author.get("name")):
            total += len(author_name.strip())

        return total

    def __bool__(self) -> bool:
        return any(
            (
                self.title,
                self.url,
                self.description,
                self._colour,
                self._fields,
                self._timestamp,
                self._author,
                self._thumbnail,
                self._footer,
                self._image,
                self._provider,
                self._video,
            )
        )

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Embed):
            return False
        for slot in self.__slots__:
            if slot == "_colour":
                slot = "color"
            if (getattr(self, slot) or None) != (getattr(other, slot) or None):
                return False
        return True

    @property
    def colour(self) -> Colour | None:
        col = self._colour
        return col if col is not MISSING else type(self)._default_colour

    @colour.setter
    def colour(self, value: int | Colour | None) -> None:
        if isinstance(value, int):
            self._colour = Colour(value=value)
        elif value is MISSING or value is None or isinstance(value, Colour):
            self._colour = value
        else:
            msg = f"Expected disnake.Colour, int, or None but received {type(value).__name__} instead."
            raise TypeError(msg)

    @colour.deleter
    def colour(self) -> None:
        self._colour = MISSING

    color = colour

    @property
    def timestamp(self) -> datetime.datetime | None:
        return self._timestamp

    @timestamp.setter
    def timestamp(self, value: datetime.datetime | None) -> None:
        if isinstance(value, datetime.datetime):
            if value.tzinfo is None:
                value = value.astimezone()
            self._timestamp = value
        elif value is None:
            self._timestamp = value
        else:
            msg = f"Expected datetime.datetime or None received {type(value).__name__} instead"
            raise TypeError(msg)

    @property
    def footer(self) -> _EmbedFooterProxy:
        """Returns an ``EmbedProxy`` denoting the footer contents.

        Possible attributes you can access are:

        - ``text``
        - ``icon_url``
        - ``proxy_icon_url``

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedFooterProxy", EmbedProxy(self._footer))

    @overload
    def set_footer(self, *, text: object, icon_url: object | None = ...) -> Self: ...

    @overload
    def set_footer(self, *, text: object, icon_file: File = ...) -> Self: ...

    def set_footer(
        self, *, text: object, icon_url: object | None = MISSING, icon_file: File = MISSING
    ) -> Self:
        """Sets the footer for the embed content.

        This function returns the class instance to allow for fluent-style
        chaining.

        At most one of ``icon_url`` or ``icon_file`` may be passed.

        .. warning::
            Passing a :class:`disnake.File` object will make the embed not
            reusable.

        .. warning::
            If used with the other ``set_*`` methods, you must ensure
            that the :attr:`.File.filename` is unique to avoid duplication.

        Parameters
        ----------
        text: :class:`str`
            The footer text.

            .. versionchanged:: 2.6
                No longer optional, must be set to a valid string.

        icon_url: :class:`str` | :data:`None`
            The URL of the footer icon. Only HTTP(S) is supported.
        icon_file: :class:`File`
            The file to use as the footer icon.

            .. versionadded:: 2.10
        """
        self._footer = {
            "text": str(text),
        }

        result = self._handle_resource(icon_url, icon_file, key="footer", required=False)
        if result is not None:
            self._footer["icon_url"] = result

        return self

    def remove_footer(self) -> Self:
        """Clears embed's footer information.

        This function returns the class instance to allow for fluent-style
        chaining.

        .. versionadded:: 2.0
        """
        self._footer = None
        return self

    @property
    def image(self) -> _EmbedMediaProxy:
        """Returns an ``EmbedProxy`` denoting the image contents.

        Possible attributes you can access are:

        - ``url``
        - ``proxy_url``
        - ``width``
        - ``height``

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedMediaProxy", EmbedProxy(self._image))

    @overload
    def set_image(self, url: object | None) -> Self: ...

    @overload
    def set_image(self, *, file: File) -> Self: ...

    def set_image(self, url: object | None = MISSING, *, file: File = MISSING) -> Self:
        """Sets the image for the embed content.

        This function returns the class instance to allow for fluent-style
        chaining.

        Exactly one of ``url`` or ``file`` must be passed.

        .. warning::
            Passing a :class:`disnake.File` object will make the embed not
            reusable.

        .. warning::
            If used with the other ``set_*`` methods, you must ensure
            that the :attr:`.File.filename` is unique to avoid duplication.

        .. versionchanged:: 1.4
            Passing :data:`None` removes the image.

        Parameters
        ----------
        url: :class:`str` | :data:`None`
            The source URL for the image. Only HTTP(S) is supported.
        file: :class:`File`
            The file to use as the image.

            .. versionadded:: 2.2
        """
        result = self._handle_resource(url, file, key="image")
        self._image = {"url": result} if result is not None else None
        return self

    @property
    def thumbnail(self) -> _EmbedMediaProxy:
        """Returns an ``EmbedProxy`` denoting the thumbnail contents.

        Possible attributes you can access are:

        - ``url``
        - ``proxy_url``
        - ``width``
        - ``height``

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedMediaProxy", EmbedProxy(self._thumbnail))

    @overload
    def set_thumbnail(self, url: object | None) -> Self: ...

    @overload
    def set_thumbnail(self, *, file: File) -> Self: ...

    def set_thumbnail(self, url: object | None = MISSING, *, file: File = MISSING) -> Self:
        """Sets the thumbnail for the embed content.

        This function returns the class instance to allow for fluent-style
        chaining.

        Exactly one of ``url`` or ``file`` must be passed.

        .. warning::
            Passing a :class:`disnake.File` object will make the embed not
            reusable.

        .. warning::
            If used with the other ``set_*`` methods, you must ensure
            that the :attr:`.File.filename` is unique to avoid duplication.

        .. versionchanged:: 1.4
            Passing :data:`None` removes the thumbnail.

        Parameters
        ----------
        url: :class:`str` | :data:`None`
            The source URL for the thumbnail. Only HTTP(S) is supported.
        file: :class:`File`
            The file to use as the image.

            .. versionadded:: 2.2
        """
        result = self._handle_resource(url, file, key="thumbnail")
        self._thumbnail = {"url": result} if result is not None else None
        return self

    @property
    def video(self) -> _EmbedVideoProxy:
        """Returns an ``EmbedProxy`` denoting the video contents.

        Possible attributes include:

        - ``url`` for the video URL.
        - ``proxy_url`` for the proxied video URL.
        - ``height`` for the video height.
        - ``width`` for the video width.

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedVideoProxy", EmbedProxy(self._video))

    @property
    def provider(self) -> _EmbedProviderProxy:
        """Returns an ``EmbedProxy`` denoting the provider contents.

        The only attributes that might be accessed are ``name`` and ``url``.

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedProviderProxy", EmbedProxy(self._provider))

    @property
    def author(self) -> _EmbedAuthorProxy:
        """Returns an ``EmbedProxy`` denoting the author contents.

        See :meth:`set_author` for possible values you can access.

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("_EmbedAuthorProxy", EmbedProxy(self._author))

    @overload
    def set_author(
        self, *, name: object, url: object | None = ..., icon_url: object | None = ...
    ) -> Self: ...

    @overload
    def set_author(
        self, *, name: object, url: object | None = ..., icon_file: File = ...
    ) -> Self: ...

    def set_author(
        self,
        *,
        name: object,
        url: object | None = None,
        icon_url: object | None = MISSING,
        icon_file: File = MISSING,
    ) -> Self:
        """Sets the author for the embed content.

        This function returns the class instance to allow for fluent-style
        chaining.

        At most one of ``icon_url`` or ``icon_file`` may be passed.

        .. warning::
            Passing a :class:`disnake.File` object will make the embed not
            reusable.

        .. warning::
            If used with the other ``set_*`` methods, you must ensure
            that the :attr:`.File.filename` is unique to avoid duplication.

        Parameters
        ----------
        name: :class:`str`
            The name of the author.
        url: :class:`str` | :data:`None`
            The URL for the author.
        icon_url: :class:`str` | :data:`None`
            The URL of the author icon. Only HTTP(S) is supported.
        icon_file: :class:`File`
            The file to use as the author icon.

            .. versionadded:: 2.10
        """
        self._author = {
            "name": str(name),
        }

        if url is not None:
            self._author["url"] = str(url)

        result = self._handle_resource(icon_url, icon_file, key="author", required=False)
        if result is not None:
            self._author["icon_url"] = result

        return self

    def remove_author(self) -> Self:
        """Clears embed's author information.

        This function returns the class instance to allow for fluent-style
        chaining.

        .. versionadded:: 1.4
        """
        self._author = None
        return self

    @property
    def fields(self) -> list[_EmbedFieldProxy]:
        r""":class:`list`\[``EmbedProxy``]: Returns a :class:`list` of ``EmbedProxy`` denoting the field contents.

        See :meth:`add_field` for possible values you can access.

        If an attribute is not set, it will be :data:`None`.
        """
        return cast("list[_EmbedFieldProxy]", [EmbedProxy(d) for d in (self._fields or [])])

    def add_field(self, name: object, value: object, *, inline: bool = True) -> Self:
        """Adds a field to the embed object.

        This function returns the class instance to allow for fluent-style
        chaining.

        Parameters
        ----------
        name: :class:`str`
            The name of the field.
        value: :class:`str`
            The value of the field.
        inline: :class:`bool`
            Whether the field should be displayed inline.
            Defaults to ``True``.
        """
        field: EmbedFieldPayload = {
            "inline": inline,
            "name": str(name),
            "value": str(value),
        }

        if self._fields is not None:
            self._fields.append(field)
        else:
            self._fields = [field]

        return self

    def insert_field_at(
        self, index: int, name: object, value: object, *, inline: bool = True
    ) -> Self:
        """Inserts a field before a specified index to the embed.

        This function returns the class instance to allow for fluent-style
        chaining.

        .. versionadded:: 1.2

        Parameters
        ----------
        index: :class:`int`
            The index of where to insert the field.
        name: :class:`str`
            The name of the field.
        value: :class:`str`
            The value of the field.
        inline: :class:`bool`
            Whether the field should be displayed inline.
            Defaults to ``True``.
        """
        field: EmbedFieldPayload = {
            "inline": inline,
            "name": str(name),
            "value": str(value),
        }

        if self._fields is not None:
            self._fields.insert(index, field)
        else:
            self._fields = [field]

        return self

    def clear_fields(self) -> None:
        """Removes all fields from this embed."""
        self._fields = None

    def remove_field(self, index: int) -> None:
        """Removes a field at a specified index.

        If the index is invalid or out of bounds then the error is
        silently swallowed.

        .. note::

            When deleting a field by index, the index of the other fields
            shift to fill the gap just like a regular list.

        Parameters
        ----------
        index: :class:`int`
            The index of the field to remove.
        """
        if self._fields is not None:
            try:
                del self._fields[index]
            except IndexError:
                pass

    def set_field_at(self, index: int, name: object, value: object, *, inline: bool = True) -> Self:
        """Modifies a field to the embed object.

        The index must point to a valid pre-existing field.

        This function returns the class instance to allow for fluent-style
        chaining.

        Parameters
        ----------
        index: :class:`int`
            The index of the field to modify.
        name: :class:`str`
            The name of the field.
        value: :class:`str`
            The value of the field.
        inline: :class:`bool`
            Whether the field should be displayed inline.
            Defaults to ``True``.

        Raises
        ------
        IndexError
            An invalid index was provided.
        """
        if not self._fields:
            msg = "field index out of range"
            raise IndexError(msg)
        try:
            self._fields[index]
        except IndexError:
            msg = "field index out of range"
            raise IndexError(msg) from None

        field: EmbedFieldPayload = {
            "inline": inline,
            "name": str(name),
            "value": str(value),
        }
        self._fields[index] = field
        return self

    def to_dict(self) -> EmbedData:
        """Converts this embed object into a dict."""
        # add in the raw data into the dict
        result: EmbedData = {}
        if self._footer is not None:
            result["footer"] = self._footer
        if self._image is not None:
            result["image"] = self._image
        if self._thumbnail is not None:
            result["thumbnail"] = self._thumbnail
        if self._video is not None:
            result["video"] = self._video
        if self._provider is not None:
            result["provider"] = self._provider
        if self._author is not None:
            result["author"] = self._author
        if self._fields is not None:
            result["fields"] = self._fields

        # deal with basic convenience wrappers
        if self.colour:
            result["color"] = self.colour.value

        if self._timestamp:
            result["timestamp"] = utils.isoformat_utc(self._timestamp)

        # add in the non raw attribute ones
        if self.type:
            result["type"] = self.type

        if self.description:
            result["description"] = self.description

        if self.url:
            result["url"] = self.url

        if self.title:
            result["title"] = self.title

        return result

    @classmethod
    def set_default_colour(cls, value: int | Colour | None) -> Colour | None:
        """Set the default colour of all new embeds.

        .. versionadded:: 2.4

        Returns
        -------
        :class:`Colour` | :data:`None`
            The colour that was set.
        """
        if value is None or isinstance(value, Colour):
            cls._default_colour = value
        elif isinstance(value, int):
            cls._default_colour = Colour(value=value)
        else:
            msg = f"Expected disnake.Colour, int, or None but received {type(value).__name__} instead."
            raise TypeError(msg)
        return cls._default_colour

    set_default_color = set_default_colour

    @classmethod
    def get_default_colour(cls) -> Colour | None:
        """Get the default colour of all new embeds.

        .. versionadded:: 2.4

        Returns
        -------
        :class:`Colour` | :data:`None`
            The default colour.

        """
        return cls._default_colour

    get_default_color = get_default_colour

    def _handle_resource(
        self, url: object | None, file: File | None, *, key: _FileKey, required: bool = True
    ) -> str | None:
        if required:
            if not (url is MISSING) ^ (file is MISSING):
                msg = "Exactly one of url or file must be provided"
                raise TypeError(msg)
        else:
            if url is not MISSING and file is not MISSING:
                msg = "At most one of url or file may be provided, not both."
                raise TypeError(msg)

        if file:
            if file.filename is None:
                msg = "File must have a filename"
                raise TypeError(msg)
            self._files[key] = file
            return f"attachment://{file.filename}"
        else:
            self._files.pop(key, None)
            return str(url) if url else None

    def check_limits(self) -> None:
        """Checks if this embed fits within the limits dictated by Discord.
        There is also a 6000 character limit across all embeds in a message.

        Returns nothing on success, raises :exc:`ValueError` if an attribute exceeds the limits.

        +--------------------------+------------------------------------+
        |   Field                  |              Limit                 |
        +--------------------------+------------------------------------+
        | title                    |        256 characters              |
        +--------------------------+------------------------------------+
        | description              |        4096 characters             |
        +--------------------------+------------------------------------+
        | fields                   |        Up to 25 field objects      |
        +--------------------------+------------------------------------+
        | field.name               |        256 characters              |
        +--------------------------+------------------------------------+
        | field.value              |        1024 characters             |
        +--------------------------+------------------------------------+
        | footer.text              |        2048 characters             |
        +--------------------------+------------------------------------+
        | author.name              |        256 characters              |
        +--------------------------+------------------------------------+

        .. versionadded:: 2.6

        Raises
        ------
        ValueError
            One or more of the embed attributes are too long.
        """
        if self.title and len(self.title.strip()) > 256:
            msg = "Embed title cannot be longer than 256 characters"
            raise ValueError(msg)

        if self.description and len(self.description.strip()) > 4096:
            msg = "Embed description cannot be longer than 4096 characters"
            raise ValueError(msg)

        if self._footer and len(self._footer.get("text", "").strip()) > 2048:
            msg = "Embed footer text cannot be longer than 2048 characters"
            raise ValueError(msg)

        if self._author and len(self._author.get("name", "").strip()) > 256:
            msg = "Embed author name cannot be longer than 256 characters"
            raise ValueError(msg)

        if self._fields:
            if len(self._fields) > 25:
                msg = "Embeds cannot have more than 25 fields"
                raise ValueError(msg)

            for field_index, field in enumerate(self._fields):
                if len(field["name"].strip()) > 256:
                    msg = f"Embed field {field_index} name cannot be longer than 256 characters"
                    raise ValueError(msg)
                if len(field["value"].strip()) > 1024:
                    msg = f"Embed field {field_index} value cannot be longer than 1024 characters"
                    raise ValueError(msg)

        if len(self) > 6000:
            msg = "Embed total size cannot be longer than 6000 characters"
            raise ValueError(msg)
