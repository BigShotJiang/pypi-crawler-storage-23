# SPDX-License-Identifier: MIT

from typing import Literal, NamedTuple

__version__ = "2.12.0"


class VersionInfo(NamedTuple):
    major: int
    minor: int
    micro: int
    releaselevel: Literal["alpha", "beta", "candidate", "final"]
    serial: int

version_info: VersionInfo = VersionInfo(2, 12, 0, 'final', 0)

