"""Tests for mempool watcher (MempoolFeed + Rust feed)."""

import pytest


# ---------------------------------------------------------------------------
# MempoolFeed dataclass
# ---------------------------------------------------------------------------


def test_mempool_feed_defaults():
    from horizon.feeds import MempoolFeed

    feed = MempoolFeed()
    assert feed.rpc_url == ""
    assert feed._type == "mempool"
    assert feed.interval == 2.0
    assert len(feed.ctf_addresses) == 2
    assert "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E" in feed.ctf_addresses


def test_mempool_feed_custom_url():
    from horizon.feeds import MempoolFeed

    feed = MempoolFeed(rpc_url="https://polygon-rpc.com")
    assert feed.rpc_url == "https://polygon-rpc.com"
    assert feed._type == "mempool"


def test_mempool_feed_custom_addresses():
    from horizon.feeds import MempoolFeed

    custom = ["0x1234567890abcdef1234567890abcdef12345678"]
    feed = MempoolFeed(
        rpc_url="https://polygon-rpc.com",
        ctf_addresses=custom,
        interval=5.0,
    )
    assert feed.ctf_addresses == custom
    assert feed.interval == 5.0


def test_mempool_feed_custom_interval():
    from horizon.feeds import MempoolFeed

    feed = MempoolFeed(interval=10.0)
    assert feed.interval == 10.0


# ---------------------------------------------------------------------------
# Rust mempool module (calldata decoding, block parsing)
# These tests verify the Rust code via PyO3 if the extension is built.
# We test the FeedConfig variant exists by checking that the engine
# accepts "mempool" as a feed type.
# ---------------------------------------------------------------------------


def test_mempool_feed_config_variant():
    """Verify MempoolFeed wires correctly by checking that strategy imports it."""
    from horizon.feeds import MempoolFeed
    from horizon.strategy import _start_feeds, MempoolFeed as StrategyMempoolFeed

    assert MempoolFeed is StrategyMempoolFeed


# ---------------------------------------------------------------------------
# Exports
# ---------------------------------------------------------------------------


def test_mempool_feed_exported():
    import horizon

    assert hasattr(horizon, "MempoolFeed")


def test_mempool_feed_in_all():
    import horizon

    assert "MempoolFeed" in horizon.__all__
