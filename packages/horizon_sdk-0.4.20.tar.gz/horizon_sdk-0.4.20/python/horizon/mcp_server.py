"""Horizon SDK MCP Server.

Exposes the Horizon trading engine as MCP tools for Claude Code,
Cursor, Claude Desktop, and other MCP-compatible clients.

Run: python -m horizon.mcp
"""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

from horizon import tools

mcp = FastMCP(
    "horizon-sdk",
    instructions=(
        "Horizon SDK - prediction market trading engine. "
        "Use these tools to check positions, submit orders, manage risk, "
        "discover markets, analyze wallets, start live data feeds (Binance, "
        "Chainlink, Alpaca, Polymarket, Kalshi, ESPN, NWS, and custom REST), "
        "check feed health, run Monte Carlo simulations, execute arbitrage, "
        "compute Kelly-optimal sizing, run quantitative analytics, stress tests, "
        "signal diagnostics, stock hedging analysis, and manage account "
        "credentials on Polymarket and Kalshi."
    ),
)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def engine_status() -> dict:
    """Get trading engine status: PnL, open orders, positions, kill switch state, uptime."""
    return tools.engine_status()


@mcp.tool()
def list_positions() -> list[dict]:
    """List all open positions with size, entry price, PnL, and exchange."""
    return tools.list_positions()


@mcp.tool()
def list_open_orders(market_id: str | None = None) -> list[dict]:
    """List open orders. Optionally filter by market_id."""
    return tools.list_open_orders(market_id)


@mcp.tool()
def list_recent_fills(limit: int = 20) -> list[dict]:
    """List recent trade fills. Default last 20."""
    return tools.list_recent_fills(limit)


@mcp.tool()
def submit_order(
    market_id: str, side: str, price: float, size: float, market_side: str = "yes",
) -> dict:
    """Submit a limit order. side: 'buy' or 'sell'. market_side: 'yes' or 'no'. price: 0-1 (probability). Returns order ID."""
    return tools.submit_order(market_id, side, price, size, market_side)


@mcp.tool()
def cancel_order(order_id: str) -> dict:
    """Cancel a single order by its ID."""
    return tools.cancel_order(order_id)


@mcp.tool()
def cancel_all_orders() -> dict:
    """Cancel ALL open orders across all exchanges. Use with caution."""
    return tools.cancel_all_orders()


@mcp.tool()
def cancel_market_orders(market_id: str) -> dict:
    """Cancel all orders for a specific market."""
    return tools.cancel_market_orders(market_id)


@mcp.tool()
def activate_kill_switch(reason: str) -> dict:
    """EMERGENCY STOP. Activates the kill switch and cancels all orders. Use only in emergencies."""
    return tools.activate_kill_switch(reason)


@mcp.tool()
def deactivate_kill_switch() -> dict:
    """Deactivate the kill switch to resume normal trading."""
    return tools.deactivate_kill_switch()


@mcp.tool()
def get_feed_snapshot(name: str) -> dict:
    """Get the latest price/bid/ask snapshot for a named feed."""
    return tools.get_feed_snapshot(name)


@mcp.tool()
def list_all_feeds() -> list[dict]:
    """List all active feed snapshots with current prices."""
    return tools.list_all_feeds()


@mcp.tool()
def start_feed(
    name: str,
    feed_type: str,
    config_json: str | None = None,
    symbol: str | None = None,
    url: str | None = None,
    interval: float = 5.0,
) -> dict:
    """Start a live data feed. feed_type: 'binance_ws', 'polymarket_book', 'kalshi_book', 'rest', 'predictit', 'manifold', 'espn', 'nws', 'rest_json_path', 'chainlink', 'alpaca'. For chainlink: config_json='{"contract_address":"0x...","rpc_url":"https://..."}'. For alpaca: config_json='{"symbol":"AAPL","feed":"iex"}'. For binance_ws: symbol='btcusdt'."""
    return tools.start_feed(name, feed_type, config_json, symbol, url, interval)


@mcp.tool()
def discover_markets(
    exchange: str = "polymarket",
    query: str = "",
    limit: int = 10,
    market_type: str = "all",
    category: str = "",
) -> list[dict]:
    """Search for prediction markets on Polymarket or Kalshi. market_type: 'all' (binary+multi), 'binary', or 'multi'. category: tag filter (e.g., 'crypto', 'politics', 'sports')."""
    return tools.discover(exchange, query, limit, market_type, category)


@mcp.tool()
def kelly_sizing(
    prob: float,
    price: float,
    bankroll: float = 1000.0,
    fraction: float = 0.25,
    max_size: float = 100.0,
) -> dict:
    """Compute Kelly-optimal position size. prob: estimated probability (0-1). price: market price (0-1)."""
    return tools.kelly_sizing(prob, price, bankroll, fraction, max_size)


@mcp.tool()
def check_parity(market_id: str, feed_name: str | None = None) -> dict:
    """Check YES/NO price parity for a market. Optionally specify feed_name to use a specific feed."""
    return tools.check_parity(market_id, feed_name)


@mcp.tool()
def get_feed_metrics(name: str) -> dict:
    """Get connection metrics for a feed: update count, errors, reconnects, connection status."""
    return tools.feed_metrics(name)


@mcp.tool()
def get_all_feed_metrics() -> list[dict]:
    """Get connection metrics for all active feeds."""
    return tools.all_feed_metrics()


@mcp.tool()
def add_stop_loss(
    market_id: str, side: str, order_side: str, size: float, trigger: float
) -> dict:
    """Add a stop-loss order. side: 'yes'/'no'. order_side: 'buy'/'sell'. Triggers at price."""
    return tools.add_stop_loss(market_id, side, order_side, size, trigger)


@mcp.tool()
def add_take_profit(
    market_id: str, side: str, order_side: str, size: float, trigger: float
) -> dict:
    """Add a take-profit order. side: 'yes'/'no'. order_side: 'buy'/'sell'. Triggers at price."""
    return tools.add_take_profit(market_id, side, order_side, size, trigger)


@mcp.tool()
def list_contingent_orders() -> list[dict]:
    """List all pending stop-loss and take-profit orders."""
    return tools.list_contingent_orders()


# ---------------------------------------------------------------------------
# Feed Health
# ---------------------------------------------------------------------------

@mcp.tool()
def check_feed_health(stale_threshold: float = 30.0) -> dict:
    """Check staleness and health of all feeds. Reports which feeds are stale, age in seconds, and whether all feeds are down."""
    return tools.check_feed_health(stale_threshold)


# ---------------------------------------------------------------------------
# Discovery
# ---------------------------------------------------------------------------

@mcp.tool()
def discover_events(query: str = "", limit: int = 10, min_volume: float = 0.0) -> list[dict]:
    """Discover multi-outcome events on Polymarket. Returns events with all outcomes and prices."""
    return tools.discover_event(query, limit, min_volume)


@mcp.tool()
def get_market_detail(slug_or_id: str, exchange: str = "polymarket") -> dict:
    """Get comprehensive detail for a single market: metadata, prices, price history, orderbook, trades, holders."""
    return tools.market_detail(slug_or_id, exchange)


@mcp.tool()
def top_markets(exchange: str = "polymarket", limit: int = 10, category: str = "") -> list[dict]:
    """Get the highest-volume active markets. Exchange: 'polymarket' or 'kalshi'."""
    return tools.get_top_markets(exchange, limit, category)


# ---------------------------------------------------------------------------
# Wallet Analytics (Polymarket public - no auth needed)
# ---------------------------------------------------------------------------

@mcp.tool()
def get_wallet_trades(address: str, limit: int = 50, condition_id: str | None = None) -> list[dict]:
    """Fetch trade history for a Polymarket wallet address (0x...). No auth required."""
    return tools.wallet_trades(address, limit, condition_id)


@mcp.tool()
def get_market_trades(condition_id: str, limit: int = 50, side: str | None = None, min_size: float = 0.0) -> list[dict]:
    """Fetch recent trades for a Polymarket market by condition ID. Filter by side ('BUY'/'SELL') and min USDC size."""
    return tools.market_trades(condition_id, limit, side, min_size)


@mcp.tool()
def get_wallet_positions(address: str, limit: int = 50, sort_by: str = "CURRENT") -> list[dict]:
    """Fetch open positions for a Polymarket wallet. Sort: TOKENS, CURRENT, INITIAL, CASHPNL, PERCENTPNL, PRICE, AVGPRICE."""
    return tools.wallet_positions(address, limit, sort_by)


@mcp.tool()
def get_wallet_value(address: str) -> dict:
    """Get total USD value of all open positions in a Polymarket wallet."""
    return tools.wallet_value(address)


@mcp.tool()
def get_wallet_profile(address: str) -> dict:
    """Get public profile for a Polymarket wallet: pseudonym, name, bio, X handle."""
    return tools.wallet_profile(address)


@mcp.tool()
def get_top_holders(condition_id: str, limit: int = 20) -> list[dict]:
    """Get top token holders for a Polymarket market. Returns wallet, amount, and optional pseudonym."""
    return tools.market_top_holders(condition_id, limit)


@mcp.tool()
def analyze_market_flow(condition_id: str, trade_limit: int = 500, top_n: int = 10) -> dict:
    """Analyze trade flow for a market: buy/sell volume, net flow, unique wallets, top buyers/sellers."""
    return tools.market_flow(condition_id, trade_limit, top_n)


# ---------------------------------------------------------------------------
# Simulation
# ---------------------------------------------------------------------------

@mcp.tool()
def simulate_portfolio(scenarios: int = 10000, seed: int | None = None) -> dict:
    """Run Monte Carlo simulation on current engine positions. Returns VaR, CVaR, win probability, mean/median PnL."""
    return tools.simulate_portfolio(scenarios, seed)


# ---------------------------------------------------------------------------
# Arbitrage
# ---------------------------------------------------------------------------

@mcp.tool()
def execute_arbitrage(
    market_id: str,
    buy_exchange: str,
    sell_exchange: str,
    buy_price: float,
    sell_price: float,
    size: float,
) -> dict:
    """Execute atomic cross-exchange arbitrage. Buys on one exchange, sells on another. Auto-cancels buy if sell fails."""
    return tools.execute_arb(market_id, buy_exchange, sell_exchange, buy_price, sell_price, size)


# ---------------------------------------------------------------------------
# Quantitative Analytics
# ---------------------------------------------------------------------------

@mcp.tool()
def shannon_entropy(p: float) -> dict:
    """Compute binary Shannon entropy for a probability (0-1). Maximum at p=0.5."""
    return tools.compute_shannon_entropy(p)


@mcp.tool()
def kl_divergence(p: list[float], q: list[float]) -> dict:
    """Compute KL divergence between two probability distributions. Measures information loss."""
    return tools.compute_kl_divergence(p, q)


@mcp.tool()
def hurst_exponent(prices: list[float]) -> dict:
    """Compute Hurst exponent for a price series. >0.5 trending, <0.5 mean-reverting, ~0.5 random walk."""
    return tools.compute_hurst_exponent(prices)


@mcp.tool()
def variance_ratio_test(returns: list[float], period: int = 2) -> dict:
    """Variance ratio test for market efficiency. 1.0 = random walk."""
    return tools.compute_variance_ratio(returns, period)


@mcp.tool()
def cornish_fisher_var(returns: list[float], confidence: float = 0.95) -> dict:
    """Cornish-Fisher VaR and CVaR (skew/kurtosis-adjusted). More accurate than Gaussian VaR for prediction markets."""
    return tools.compute_cornish_fisher_var(returns, confidence)


@mcp.tool()
def prediction_greeks(
    price: float, size: float, is_yes: bool = True, t_hours: float = 24.0, vol: float = 0.2,
) -> dict:
    """Compute prediction Greeks (delta, gamma, theta, vega) for a binary market position."""
    return tools.compute_prediction_greeks(price, size, is_yes, t_hours, vol)


@mcp.tool()
def deflated_sharpe(
    sharpe: float, n_obs: int, n_trials: int, skew: float = 0.0, kurt: float = 3.0,
) -> dict:
    """Deflated Sharpe Ratio test: is the observed Sharpe statistically significant given multiple strategy trials?"""
    return tools.compute_deflated_sharpe(sharpe, n_obs, n_trials, skew, kurt)


@mcp.tool()
def signal_diagnostics(predictions: list[float], outcomes: list[float]) -> dict:
    """Signal quality diagnostics: information coefficient (Spearman), half-life, Hurst exponent."""
    return tools.run_signal_diagnostics(predictions, outcomes)


@mcp.tool()
def market_efficiency_test(prices: list[float]) -> dict:
    """Analyze market efficiency: variance ratio, Hurst exponent, and efficiency flag."""
    return tools.run_market_efficiency(prices)


@mcp.tool()
def stress_test(n_simulations: int = 10000, seed: int | None = None) -> dict:
    """Run stress test on current positions under adverse scenarios (correlation spike, all-resolve-no, liquidity shock, tail risk)."""
    return tools.run_stress_test(n_simulations, seed)


# ---------------------------------------------------------------------------
# Tearsheet
# ---------------------------------------------------------------------------

@mcp.tool()
def generate_tearsheet(
    equity_curve: list[float] | None = None,
    timestamps: list[float] | None = None,
    trades: list[dict] | None = None,
    initial_capital: float = 1000.0,
) -> dict:
    """Generate a comprehensive tearsheet: monthly returns, drawdown analysis, trade stats, tail ratio."""
    return tools.generate_tearsheet_report(equity_curve, timestamps, trades, initial_capital)


# ---------------------------------------------------------------------------
# Bayesian Optimization
# ---------------------------------------------------------------------------

@mcp.tool()
def bayesian_optimize(
    param_space: dict[str, list[float]],
    n_iterations: int = 20,
    n_initial: int = 5,
    seed: int | None = None,
) -> dict:
    """Run Bayesian optimization with GP surrogate to find optimal strategy parameters. param_space: {name: [min, max]}."""
    return tools.run_bayesian_optimize(param_space, n_iterations, n_initial, seed)


# ---------------------------------------------------------------------------
# Portfolio Management
# ---------------------------------------------------------------------------

@mcp.tool()
def portfolio_metrics() -> dict:
    """Get portfolio metrics: total value, PnL, exposure, diversification, concentration."""
    return tools.get_portfolio_metrics()


@mcp.tool()
def portfolio_weights(method: str = "equal") -> dict:
    """Compute optimal portfolio weights. method: 'equal', 'kelly', 'risk_parity', 'min_variance'."""
    return tools.get_portfolio_weights(method)


# ---------------------------------------------------------------------------
# Hot-Reload Parameters
# ---------------------------------------------------------------------------

@mcp.tool()
def update_params(params: dict[str, float]) -> dict:
    """Hot-reload: update runtime parameters on the trading engine. Changes take effect next cycle."""
    return tools.update_runtime_params(params)


@mcp.tool()
def get_params() -> dict:
    """Get all current runtime parameters from the trading engine."""
    return tools.get_runtime_params()


# ---------------------------------------------------------------------------
# Hawkes Process
# ---------------------------------------------------------------------------

@mcp.tool()
def hawkes_intensity(
    event_times: list[float],
    mu: float = 0.1,
    alpha: float = 0.5,
    beta: float = 1.0,
) -> dict:
    """Compute Hawkes self-exciting process intensity from event timestamps. Useful for trade arrival modeling."""
    return tools.compute_hawkes_intensity(event_times, mu, alpha, beta)


# ---------------------------------------------------------------------------
# Ledoit-Wolf Correlation
# ---------------------------------------------------------------------------

@mcp.tool()
def correlation_matrix(
    returns: list[list[float]],
) -> dict:
    """Compute Ledoit-Wolf shrinkage covariance matrix from return observations. Each row is [asset1_return, asset2_return, ...]."""
    return tools.compute_correlation_matrix(returns)


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# AFML: Information-Driven Bars
# ---------------------------------------------------------------------------

@mcp.tool()
def tick_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: int,
) -> list[dict]:
    """Generate tick bars (fixed ticks per bar). AFML Ch. 2. Returns OHLCV bars."""
    return tools.compute_tick_bars(timestamps, prices, volumes, bar_size)


@mcp.tool()
def volume_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: float,
) -> list[dict]:
    """Generate volume bars (fixed total volume per bar). AFML Ch. 2."""
    return tools.compute_volume_bars(timestamps, prices, volumes, bar_size)


@mcp.tool()
def dollar_bars(
    timestamps: list[float], prices: list[float], volumes: list[float], bar_size: float,
) -> list[dict]:
    """Generate dollar bars (fixed dollar value per bar). AFML Ch. 2."""
    return tools.compute_dollar_bars(timestamps, prices, volumes, bar_size)


# ---------------------------------------------------------------------------
# AFML: Triple Barrier Labeling
# ---------------------------------------------------------------------------

@mcp.tool()
def cusum_filter(prices: list[float], threshold: float) -> list[int]:
    """CUSUM structural break filter. Returns indices where cumulative deviation exceeds threshold."""
    return tools.compute_cusum_filter(prices, threshold)


@mcp.tool()
def triple_barrier_labels(
    prices: list[float],
    timestamps: list[float],
    events: list[int],
    pt_sl: list[float] | None = None,
    min_ret: float = 0.0,
    max_holding: int = 100,
    vol_span: int = 20,
) -> list[dict]:
    """Apply triple barrier labeling (profit-taking, stop-loss, vertical barrier). AFML Ch. 3."""
    return tools.compute_triple_barrier(prices, timestamps, events, pt_sl, min_ret, max_holding, vol_span)


# ---------------------------------------------------------------------------
# AFML: Fractional Differentiation
# ---------------------------------------------------------------------------

@mcp.tool()
def frac_diff(
    series: list[float], d: float, threshold: float = 1e-5,
) -> list[float]:
    """Apply fractional differentiation (FFD). Makes series stationary while preserving memory. AFML Ch. 5."""
    return tools.compute_frac_diff(series, d, threshold)


@mcp.tool()
def min_frac_diff(
    series: list[float], p_threshold: float = 0.05, max_d: float = 1.0, n_steps: int = 10,
) -> dict:
    """Find minimum d for stationarity via grid search + ADF test. AFML Ch. 5."""
    return tools.compute_min_frac_diff(series, p_threshold, max_d, n_steps)


# ---------------------------------------------------------------------------
# AFML: HRP & Denoising
# ---------------------------------------------------------------------------

@mcp.tool()
def hrp_weights(covariance: list[list[float]]) -> dict:
    """Compute Hierarchical Risk Parity portfolio weights from covariance matrix. Lopez de Prado."""
    return tools.compute_hrp_weights(covariance)


@mcp.tool()
def denoise_covariance(covariance: list[list[float]], n_observations: int) -> dict:
    """Denoise covariance matrix using Marcenko-Pastur random matrix theory. Separates signal from noise eigenvalues."""
    return tools.compute_denoise_covariance(covariance, n_observations)


# ---------------------------------------------------------------------------
# Wallet Profiler
# ---------------------------------------------------------------------------

@mcp.tool()
def profile_wallet(address: str, trade_limit: int = 500) -> dict:
    """Deep behavioral profile for a Polymarket wallet. Analyzes temporal patterns, market selection, order flow, edge detection, and generates concrete profit strategies (copy, fade, front-run, etc.)."""
    return tools.wallet_profiler(address, trade_limit)


# ---------------------------------------------------------------------------
# Stealth Execution (Ultra)
# ---------------------------------------------------------------------------

@mcp.tool()
def stealth_estimate_impact(market_id: str, size: float, feed_name: str | None = None) -> dict:
    """Estimate market impact before execution. Returns slippage (bps), Kyle's lambda, recommended strategy (market/twap/iceberg/sniper), and estimated duration. Ultra tier."""
    return tools.stealth_estimate_impact(market_id, size, feed_name)


@mcp.tool()
def stealth_execute(
    market_id: str, side: str, order_side: str, size: float, price: float, strategy: str = "auto",
) -> dict:
    """Execute an order using stealth algorithms. strategy: 'auto', 'twap', 'iceberg', 'sniper'. Returns execution plan with routes and child orders. Ultra tier."""
    return tools.stealth_execute_order(market_id, side, order_side, size, price, strategy)


# ---------------------------------------------------------------------------
# Sentinel Risk Monitoring (Ultra)
# ---------------------------------------------------------------------------

@mcp.tool()
def sentinel_report() -> dict:
    """Portfolio risk report: regime detection, VaR/CVaR, drawdown levels, correlation alerts, hedge suggestions, risk budget. Ultra tier."""
    return tools.get_sentinel_report()


# ---------------------------------------------------------------------------
# Oracle Forecasting (Ultra)
# ---------------------------------------------------------------------------

@mcp.tool()
def oracle_forecast(
    market_id: str, market_title: str = "", market_price: float = 0.0,
    exchange: str = "polymarket",
) -> dict:
    """Forecast market probability using 6-signal ensemble (smart money, microstructure, momentum, volume, concentration, temporal). exchange: 'polymarket' or 'kalshi' (Kalshi uses 3/6 signals). Returns ensemble_prob, edge_bps, signal breakdown. Ultra tier."""
    return tools.oracle_forecast_market(market_id, market_title, market_price, exchange=exchange)


@mcp.tool()
def oracle_edges(
    min_edge_bps: float = 200.0, max_markets: int = 30,
    exchange: str = "polymarket",
) -> list[dict]:
    """Scan top markets for edge opportunities where ensemble forecast diverges from market price. exchange: 'polymarket' or 'kalshi'. Ultra tier."""
    return tools.oracle_scan_edges(min_edge_bps, max_markets, exchange=exchange)


# ---------------------------------------------------------------------------
# Whale Galaxy (Ultra)
# ---------------------------------------------------------------------------

@mcp.tool()
def whale_galaxy_scan(top_n: int = 20, max_markets: int = 50) -> dict:
    """Scan Polymarket for whale wallets: rank by score, detect coordinated clusters, generate alerts. Ultra tier."""
    return tools.whale_galaxy_scan(top_n, max_markets)


# ---------------------------------------------------------------------------
# LLM Signal Engine
# ---------------------------------------------------------------------------

@mcp.tool()
def llm_forecast(
    market_id: str, market_title: str = "", market_price: float = 0.5,
    provider: str = "anthropic", model: str = "",
) -> dict:
    """Forecast market probability via LLM + news analysis. Returns llm_prob, edge_bps, reasoning, confidence. model: any litellm-compatible model string (e.g., 'openrouter/meta-llama/llama-3-70b')."""
    return tools.llm_forecast_market(market_id, market_title, market_price, provider, model)


@mcp.tool()
def llm_scan(
    min_edge_bps: float = 200.0, max_markets: int = 20, provider: str = "anthropic",
    model: str = "", exchange: str = "polymarket",
) -> list[dict]:
    """Scan top markets for LLM-detected edges. Returns markets where |edge| exceeds threshold. exchange: 'polymarket' or 'kalshi'. model: any litellm-compatible model string."""
    return tools.llm_scan_markets(min_edge_bps, max_markets, provider, model, exchange=exchange)


# ---------------------------------------------------------------------------
# Resolution Analysis
# ---------------------------------------------------------------------------

@mcp.tool()
def analyze_resolution(
    market_id: str, market_title: str = "", provider: str = "anthropic",
    model: str = "", exchange: str = "polymarket",
) -> dict:
    """Analyze resolution conditions, ambiguity risks, and edge cases for a market. exchange: 'polymarket' or 'kalshi'. Returns ambiguity_score, conditions, risk_level. model: any litellm-compatible model string."""
    return tools.analyze_resolution_tool(market_id, market_title, provider, model, exchange=exchange)


# ---------------------------------------------------------------------------
# Resolution Sniping
# ---------------------------------------------------------------------------

@mcp.tool()
def sniper_scan(
    provider: str = "anthropic", max_markets: int = 10, model: str = "",
    exchange: str = "polymarket",
) -> list[dict]:
    """Scan for markets about to resolve. exchange: 'polymarket' or 'kalshi'. Returns resolution signals with confidence and evidence. model: any litellm-compatible model string."""
    return tools.sniper_scan_tool(provider, max_markets, model, exchange=exchange)


# ---------------------------------------------------------------------------
# Wallet Tracker (Ultra)
# ---------------------------------------------------------------------------

@mcp.tool()
def track_wallet(wallet: str, market_id: str = "", limit: int = 500) -> dict | list[dict]:
    """Compute directional signals for a Polymarket wallet. If market_id is given, returns signal for that market; otherwise returns signals for all markets the wallet holds positions in, sorted by strength. Ultra tier."""
    return tools.track_wallet_tool(wallet, market_id, limit)


@mcp.tool()
def wallet_consensus(market_id: str, min_quality: float = 0.1) -> dict:
    """Compute multi-wallet consensus signal for a market. Discovers top holders, scores each, and aggregates into a weighted directional signal. min_quality: minimum |composite_score| to include a wallet. Ultra tier."""
    return tools.wallet_consensus_tool(market_id, min_quality)


@mcp.tool()
def scan_wallet_signals(wallet: str, limit: int = 500) -> list[dict]:
    """Scan all positions held by a wallet and return directional signals sorted by strength. Equivalent to track_wallet without a market_id. Ultra tier."""
    return tools.scan_wallet_signals_tool(wallet, limit)


# ---------------------------------------------------------------------------
# Microstructure Invariance
# ---------------------------------------------------------------------------

@mcp.tool()
def invariance_analysis(
    dollar_volume: float, volatility: float, n_trades: int, avg_trade_size: float,
) -> dict:
    """Compute microstructure invariance: trading activity, invariant bet size, market impact, and efficiency score. Based on Kyle-Obizhaeva invariance."""
    return tools.invariance_analysis_tool(dollar_volume, volatility, n_trades, avg_trade_size)


# ---------------------------------------------------------------------------
# Signal Selection (Elastic Net)
# ---------------------------------------------------------------------------

@mcp.tool()
def signal_selection(
    x: list[list[float]], y: list[float], alpha: float = 1.0, l1_ratio: float = 0.5,
) -> dict:
    """Fit elastic net regression for signal selection. Identifies which features are predictive (nonzero coefficients). alpha: regularization strength. l1_ratio: 1.0=LASSO, 0.0=Ridge."""
    return tools.signal_selection_tool(x, y, alpha, l1_ratio)


# ---------------------------------------------------------------------------
# ACD Duration Model
# ---------------------------------------------------------------------------

@mcp.tool()
def duration_analysis(
    durations: list[float], omega: float = 0.1, alpha: float = 0.1, beta: float = 0.8,
) -> dict:
    """Analyze trade inter-arrival durations using an ACD (Autoregressive Conditional Duration) model. Detects unusual timing patterns."""
    return tools.duration_analysis_tool(durations, omega, alpha, beta)


# ---------------------------------------------------------------------------
# Volatility Signature Plot
# ---------------------------------------------------------------------------

@mcp.tool()
def volatility_signature(
    prices: list[float], max_freq: int | None = None, n_points: int = 20,
) -> dict:
    """Compute volatility signature plot: realized volatility at different sampling frequencies. Identifies optimal sampling frequency and microstructure noise."""
    return tools.volatility_signature_tool(prices, max_freq, n_points)


# ---------------------------------------------------------------------------
# Kalman Filter
# ---------------------------------------------------------------------------

@mcp.tool()
def kalman_filter_state(
    observations: list[float], state_dim: int = 1, obs_dim: int = 1,
) -> dict:
    """Run Kalman filter on scalar observations. Returns filtered state estimate. Useful for tracking latent market state."""
    return tools.kalman_filter_state_tool(observations, state_dim, obs_dim)


# ---------------------------------------------------------------------------
# Particle Filter
# ---------------------------------------------------------------------------

@mcp.tool()
def particle_filter_state(
    observations: list[float], n_particles: int = 1000, process_noise: float = 0.1, measurement_noise: float = 0.5,
) -> dict:
    """Run particle filter (Sequential Monte Carlo) on observations. Handles nonlinear/non-Gaussian state estimation."""
    return tools.particle_filter_state_tool(observations, n_particles, process_noise, measurement_noise)


# ---------------------------------------------------------------------------
# BOCPD Change Point Detection
# ---------------------------------------------------------------------------

@mcp.tool()
def bocpd_detect(
    observations: list[float], hazard_rate: float = 250.0, threshold: float = 0.5,
) -> dict:
    """Bayesian Online Change Point Detection. Identifies structural breaks in a time series (regime changes, volatility shifts)."""
    return tools.bocpd_detect_tool(observations, hazard_rate, threshold)


# ---------------------------------------------------------------------------
# Lead-Lag Analysis
# ---------------------------------------------------------------------------

@mcp.tool()
def lead_lag_analysis(
    series_a: list[float], series_b: list[float], max_lag: int = 10,
) -> dict:
    """Cross-correlation analysis to detect lead-lag relationships between two series. Returns peak lag and correlation at each lag."""
    return tools.lead_lag_analysis_tool(series_a, series_b, max_lag)


# ---------------------------------------------------------------------------
# Granger Causality
# ---------------------------------------------------------------------------

@mcp.tool()
def granger_test(
    x: list[float], y: list[float], max_lag: int = 5,
) -> dict:
    """Granger causality test: does x Granger-cause y? Returns F-statistic, p-value, and significance at 5% level."""
    return tools.granger_test_tool(x, y, max_lag)


# ---------------------------------------------------------------------------
# Market Graph Analysis
# ---------------------------------------------------------------------------

@mcp.tool()
def market_graph_analysis(
    corr_matrix: list[list[float]], names: list[str], threshold: float = 0.5,
) -> dict:
    """Build correlation graph from a matrix. Returns nodes with centrality metrics, edges, communities, MST, and density."""
    return tools.market_graph_analysis_tool(corr_matrix, names, threshold)


# ---------------------------------------------------------------------------
# Garleanu-Pedersen Optimal Execution
# ---------------------------------------------------------------------------

@mcp.tool()
def gp_optimal_execution(
    current_pos: float, target_pos: float, alpha_decay: float, temp_impact: float,
    perm_impact: float, risk_aversion: float, n_steps: int, dt: float,
) -> dict:
    """Compute Garleanu-Pedersen optimal execution trajectory. Balances alpha decay against market impact."""
    return tools.gp_optimal_execution_tool(
        current_pos, target_pos, alpha_decay, temp_impact, perm_impact, risk_aversion, n_steps, dt,
    )


# ---------------------------------------------------------------------------
# Almgren-Chriss Optimal Liquidation
# ---------------------------------------------------------------------------

@mcp.tool()
def ac_optimal_liquidation(
    total_shares: float, n_steps: int, volatility: float, perm_impact: float,
    temp_impact: float, risk_aversion: float,
) -> dict:
    """Compute Almgren-Chriss optimal liquidation schedule. Minimizes execution cost subject to risk constraint."""
    return tools.ac_optimal_liquidation_tool(
        total_shares, n_steps, volatility, perm_impact, temp_impact, risk_aversion,
    )


# ---------------------------------------------------------------------------
# Queue Fill Probability
# ---------------------------------------------------------------------------

@mcp.tool()
def queue_fill_probability(
    queue_size: float, position: float, arrival_rate: float, cancel_rate: float, time_horizon: float,
) -> dict:
    """Estimate probability of being filled given queue position. Models order arrival and cancellation dynamics."""
    return tools.queue_fill_probability_tool(queue_size, position, arrival_rate, cancel_rate, time_horizon)


# ---------------------------------------------------------------------------
# Copula Fitting
# ---------------------------------------------------------------------------

@mcp.tool()
def fit_copula(
    u: list[float], v: list[float], family: str = "gaussian",
) -> dict:
    """Fit a copula to bivariate data (uniform marginals). family: 'gaussian', 'student_t', 'clayton', 'gumbel', 'frank'."""
    return tools.fit_copula_tool(u, v, family)


@mcp.tool()
def best_copula(
    u: list[float], v: list[float],
) -> dict:
    """Find the best-fitting copula family for bivariate data by AIC. Tests Gaussian, Student-t, Clayton, Gumbel, Frank."""
    return tools.best_copula_tool(u, v)


# ---------------------------------------------------------------------------
# Vine Copulas
# ---------------------------------------------------------------------------

@mcp.tool()
def vine_copula_fit(
    data: list[list[float]], vine_type: str = "cvine",
) -> dict:
    """Fit a vine copula for high-dimensional dependence modeling. vine_type: 'cvine' (star) or 'dvine' (path). Ultra tier."""
    return tools.vine_copula_fit_tool(data, vine_type)


@mcp.tool()
def vine_tail_risk(
    data: list[list[float]], vine_type: str = "cvine", threshold: float = 0.05, n_sim: int = 10000,
) -> dict:
    """Estimate joint tail risk using vine copula simulation. Returns probability of simultaneous extreme events. Ultra tier."""
    return tools.vine_tail_risk_tool(data, vine_type, threshold, n_sim)


# ---------------------------------------------------------------------------
# Cross-Impact Matrix
# ---------------------------------------------------------------------------

@mcp.tool()
def cross_impact_matrix(
    returns_matrix: list[list[float]], volume_matrix: list[list[float]], names: list[str],
) -> dict:
    """Estimate cross-impact matrix: how order flow in one market impacts returns in others. Ultra tier."""
    return tools.cross_impact_matrix_tool(returns_matrix, volume_matrix, names)


# ---------------------------------------------------------------------------
# Entropy Pooling
# ---------------------------------------------------------------------------

@mcp.tool()
def entropy_pooling(
    prior_probs: list[float], scenarios: list[list[float]], views: list[dict],
) -> dict:
    """Meucci entropy pooling: update scenario probabilities with views while minimizing KL divergence. views: list of {coefficients, bound, is_equality}. Ultra tier."""
    return tools.entropy_pooling_tool(prior_probs, scenarios, views)


# ---------------------------------------------------------------------------
# Robust Portfolio
# ---------------------------------------------------------------------------

@mcp.tool()
def robust_portfolio(
    expected_returns: list[float], covariance: list[list[float]], return_uncertainty: list[float],
    uncertainty_budget: float = 1.0,
) -> dict:
    """Robust portfolio optimization under return uncertainty. Optimizes worst-case return within uncertainty set. Ultra tier."""
    return tools.robust_portfolio_tool(expected_returns, covariance, return_uncertainty, uncertainty_budget)


# ---------------------------------------------------------------------------
# Optimal Exit (Longstaff-Schwartz)
# ---------------------------------------------------------------------------

@mcp.tool()
def optimal_exit(
    s0: float, mu: float, sigma: float, dt: float, n_steps: int, n_paths: int, strike: float,
) -> dict:
    """Compute optimal exit policy via Longstaff-Schwartz. Generates GBM paths, then solves for optimal stopping boundary."""
    return tools.optimal_exit_tool(s0, mu, sigma, dt, n_steps, n_paths, strike)


# ---------------------------------------------------------------------------
# Binary Option Pricing
# ---------------------------------------------------------------------------

@mcp.tool()
def binary_option_price(
    model: str, strike: float, time_to_expiry: float, s0: float = 1.0, r: float = 0.0,
) -> dict:
    """Price a binary option using characteristic function models. model: 'heston' (stochastic vol), 'merton' (jump diffusion), 'vg' (variance gamma)."""
    return tools.binary_option_price_tool(model, strike, time_to_expiry, s0, r)


# ---------------------------------------------------------------------------
# HJB Optimal Market Making
# ---------------------------------------------------------------------------

@mcp.tool()
def hjb_optimal_quotes(
    max_inventory: int = 10, n_time_steps: int = 100, gamma: float = 0.1, sigma: float = 0.3,
    kappa: float = 1.5, alpha: float = 0.01, terminal_time: float = 1.0,
    current_inventory: int = 0, time_fraction: float = 0.0,
) -> dict:
    """Solve HJB equation for optimal bid/ask quotes (Avellaneda-Stoikov market making). Returns optimal spread given inventory and time. Ultra tier."""
    return tools.hjb_optimal_quotes_tool(
        max_inventory, n_time_steps, gamma, sigma, kappa, alpha, terminal_time,
        current_inventory, time_fraction,
    )


# ---------------------------------------------------------------------------
# Resources
# ---------------------------------------------------------------------------

@mcp.resource("horizon://status")
def resource_status() -> str:
    """Current engine status as JSON context."""
    import json
    return json.dumps(tools.engine_status(), indent=2)


@mcp.resource("horizon://positions")
def resource_positions() -> str:
    """Current positions as JSON context."""
    import json
    return json.dumps(tools.list_positions(), indent=2)


# ---------------------------------------------------------------------------
# Stock Hedging Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def hedge_analysis(
    spot_prices: list[float],
    hedge_prices: list[float],
    window: int = 60,
    position_size: float = 1.0,
) -> dict:
    """Compute hedge ratio, effectiveness, basis risk, and sensitivities between a spot and hedge instrument."""
    return tools.hedge_analysis(spot_prices, hedge_prices, window, position_size)


@mcp.tool()
def hedge_scenario_analysis(
    spot_position: float,
    spot_price: float,
    hedge_position: float,
    hedge_price: float,
    spot_moves: list[float] | None = None,
    correlation: float = 0.8,
    hedge_vol: float = 0.2,
    spot_vol: float = 0.2,
) -> list[dict] | dict:
    """Run scenario analysis: P&L under various spot price moves for a hedged position."""
    return tools.hedge_scenario_analysis(
        spot_position, spot_price, hedge_position, hedge_price,
        spot_moves, correlation, hedge_vol, spot_vol,
    )


@mcp.tool()
def multi_ticker_hedge(
    spot_returns: list[float],
    hedge_returns_matrix: list[list[float]],
    tickers: list[str],
) -> dict:
    """Find optimal multi-ticker hedge weights using OLS with Cholesky decomposition."""
    return tools.multi_ticker_hedge_analysis(spot_returns, hedge_returns_matrix, tickers)


@mcp.tool()
def hedge_cost_summary() -> dict:
    """Get hedge trading cost summary from the running engine."""
    return tools.hedge_cost_summary()


# ---------------------------------------------------------------------------
# Account & Credentials
# ---------------------------------------------------------------------------

@mcp.tool()
def horizon_setup(email: str, password: str = "", name: str = "") -> dict:
    """Create a Horizon account and generate an SDK API key. Tries login first, then signup. Password: prefers HORIZON_PASSWORD env var over the argument (avoids log exposure). Saves encrypted key to ~/.horizon/credentials.json."""
    return tools.horizon_setup(email, password, name)


@mcp.tool()
def horizon_login(email: str, password: str = "") -> dict:
    """Login to existing Horizon account and generate a new SDK key. Password: prefers HORIZON_PASSWORD env var over the argument. Saves encrypted key to ~/.horizon/credentials.json."""
    return tools.horizon_login(email, password)


@mcp.tool()
def horizon_key_status() -> dict:
    """Check if Horizon SDK credentials are configured. Reports whether a key is set via env var or saved file."""
    return tools.horizon_key_status()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the MCP server on stdio transport."""
    mcp.run(transport="stdio")
