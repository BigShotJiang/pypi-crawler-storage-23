"""Freeplay MCP Server - Workflow-oriented tools for the Freeplay API."""

import logging
import sys

from fastmcp import FastMCP

from .tools import (
    create_prompt_version,
    find_logging_issues,
    get_deployed_prompt_versions,
    get_prompt_version,
    list_insights,
    list_projects,
    list_prompt_templates,
    optimize_prompt,
    search,
)

# Configure logging to stderr (stdout corrupts MCP JSON-RPC)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
mcp = FastMCP("freeplay")

# Register all tools with the MCP server
TOOLS = [
    list_projects,
    search,
    list_prompt_templates,
    get_prompt_version,
    create_prompt_version,
    get_deployed_prompt_versions,
    find_logging_issues,
    list_insights,
]

for tool in TOOLS:
    mcp.tool()(tool)

# Register long-running tools
mcp.tool()(optimize_prompt)


def main() -> None:
    """Run the Freeplay MCP server."""
    logger.info("Starting Freeplay MCP server")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
