#ifndef IO_H
#define IO_H

#ifdef IO_IMPORT
#define EXTERN
#else
#define EXTERN extern
#endif





#undef IO_IMPORT
#undef EXTERN


#endif
