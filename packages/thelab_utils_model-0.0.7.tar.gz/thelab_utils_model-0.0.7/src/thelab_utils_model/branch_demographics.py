from urllib.parse import urlencode
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
from dataclasses import dataclass, field
import polars as pl

#========================================================================
# Helper Functions
#========================================================================
def safe_get(attr_dict, key):
    """
    Quick support function to safely retrieve value from dictionary
    """
    return attr_dict.get(key, None)

#========================================================================
# Get Demographics Data
#========================================================================
@dataclass
class GetDemographicsData:
    """
    Library to return branch demographics including the following attributes:
        - Total Popoulation
        - Population Density
        - Median Networth
        - Total Households
        - Median Household Income
        - Number of Businesses
        - Number of NAICS Employees
        - Median Home Value
        - Population Growth
        - Daytime Population
        - Median Age
    """
    api_token: str = field(
        metadata={'description': 'API token from ESRI'}
    )
    branch: pl.DataFrame = field(
        metadata={'description': """
            Columns Required:
                - InstitutionID
                - BranchName
                - BranchID
                - InstitutionType
                - MileRadius
                - Latitude
                - Longitude
        """}
    )

    def get_analysis_var(self):

        return [
            'AtRisk.TOTPOP_CY',
            'populationtotals.POPDENS_CY',
            'AtRisk.TOTHH_CY',
            'homevalue.MEDVAL_CY',
            'populationtotals.POPGRW20CY',
            'DaytimePopulation.DPOP_CY',
            'networth.MEDNW_CY',
            'Health.MEDHINC_CY',
            'businesses.N01_BUS',
            'employees.N01_EMP',
            # 'householdincome.MEDHINC_FY',
            '5yearincrements.MEDAGE_CY',
            # 'EmploymentUnemployment.UNEMPRT_CY',
            # 'homevalue.VALBASE',
            # 'housingunittotals.RENTER20',
            # 'language.ACSENGA18'
        ]

    def fetch_demographics_data(self, row):
        """
        Function to retreive demographics data from ESRI API
        """
        latitude, longitude = row['Latitude'], row['Longitude']

        radii = row['MileRadius']

        analysis_var = self.get_analysis_var()

        if not isinstance(latitude, type(None)):
            esri_endpoint = 'https://geoenrich.arcgis.com/arcgis/rest/services/World/GeoEnrichmentServer/Geoenrichment/Enrich?'
            studyAreas = [{"geometry": {"x": longitude, "y": latitude}}]
            studyAreasOptions = {'bufferUnits': 'Miles', 'bufferRadii': [radii]}

            api_data = urlencode({
                "studyAreas": studyAreas,
                "studyAreasOptions": studyAreasOptions,
                "analysisVariables": analysis_var,
                "f": "pjson",
                "token":  self.api_token
            })
            
            
            url_request = f"{esri_endpoint}{api_data}"
            response = requests.get(url_request)
            
            data = response.json()
            access_feature_set = data['results'][0]['value']['FeatureSet']
        
            try:
                access_point = access_feature_set[0]['features'][0]['attributes']
                df_new = pl.DataFrame({
                    'BranchName': row['BranchName'],
                    'InstitutionID': row['InstitutionID'],
                    'BranchID': row['BranchID'],
                    'InstitutionType': row['InstitutionType'],
                    'Latitude': row['Latitude'],
                    'Longitude': row['Longitude'],
                    "TotalPopulation": safe_get(access_point, "TOTPOP_CY"),
                    "PopulationDensity": safe_get(access_point, "POPDENS_CY"),
                    "TotalHouseholds": safe_get(access_point, "TOTHH_CY"),
                    "MedianHouseholdIncome": safe_get(access_point, "MEDHINC_CY"),
                    "MedianHomeValue": safe_get(access_point, "MEDVAL_CY"),
                    "NumberOfBusinesses": safe_get(access_point, "N01_BUS"),
                    "NumberOfNAICSEmployees": safe_get(access_point, "N01_EMP"),
                    "PopulationGrowth": safe_get(access_point, "POPGRW20CY"),
                    "DaytimePopulation": safe_get(access_point, "DPOP_CY"),
                    "MedianNetWorth": safe_get(access_point, "MEDNW_CY"),
                    "MedianAge": safe_get(access_point, 'MEDAGE_CY')
                }).cast(pl.String)
            except Exception as error:
                print(error)
        return df_new 

    def run_demographics_data(self):
        """
        Function to retrieve demographics data for each branch
        """
        # Rebuild esri input to pull the data
        esri_input = self.branch.with_columns(
            [
                pl.lit(None).alias(col_name)
                for col_name in self.get_analysis_var()
            ]
        )
        
        df_demographics = pl.DataFrame()

        # Run in parallel
        with ThreadPoolExecutor(max_workers=16) as executor:

            futures = {executor.submit(self.fetch_demographics_data, row): row for row in esri_input.iter_rows(named=True)}

            for future in as_completed(futures):
                df_demographics = df_demographics.vstack(future.result())

        df_demographics = df_demographics.with_columns(
            pl.concat_str(['InstitutionID','BranchID','InstitutionType'], separator='.').alias('UniqueKey')
        )

        return df_demographics