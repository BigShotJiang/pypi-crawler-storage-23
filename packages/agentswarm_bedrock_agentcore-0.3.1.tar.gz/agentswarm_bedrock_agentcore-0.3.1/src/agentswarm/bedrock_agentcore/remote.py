import json
import uuid
import asyncio
from typing import Any, Dict, Optional

try:
    import boto3
except ImportError:
    boto3 = None

from agentswarm.agents.base_agent import BaseAgent, InputType, OutputType
from agentswarm.datamodels.context import Context


class BedrockSimpleRemoteAgent(BaseAgent[InputType, OutputType]):
    """
    A simple remote agent that invokes a Bedrock AgentCore agent using boto3.
    It uses the native Bedrock AgentCore invocation and handles context synchronization.
    """

    def __init__(
        self,
        agent_runtime_arn: str,
        region_name: Optional[str] = None,
        endpoint_url: Optional[str] = None,
    ):
        self.agent_runtime_arn = agent_runtime_arn
        self.region_name = region_name or agent_runtime_arn.split(":")[3]
        self.endpoint_url = endpoint_url

        if boto3 is None:
            raise ImportError(
                "boto3 is not installed. Please install it with: pip install boto3"
            )

        self.client = boto3.client("bedrock-agentcore", region_name=self.region_name)

    def id(self) -> str:
        return f"bedrock_simple_{self.agent_runtime_arn.split('/')[-1]}"

    def description(self, user_id: str) -> str:
        return f"Simple Bedrock Remote Agent ({self.agent_runtime_arn})"

    async def execute(
        self, user_id: str, context: Context, input: InputType = None
    ) -> OutputType:
        """
        Executes the agent by invoking the remote Bedrock AgentCore runtime.
        """
        # Save counts for context merging
        base_messages_count = len(context.messages)
        base_thoughts_count = len(context.thoughts)
        base_usage_count = len(context.usage)

        # Prepare payload
        input_val = (
            (input.model_dump() if hasattr(input, "model_dump") else input)
            if input is not None
            else None
        )

        bedrock_payload = {
            "input": input_val,
            "user_id": user_id,
            "context": context.to_dict(),
        }

        # Session ID must be 33+ chars for Bedrock AgentCore
        session_id = str(uuid.uuid4())

        # Invoke the agent runtime
        kwargs = {
            "agentRuntimeArn": self.agent_runtime_arn,
            "runtimeSessionId": session_id,
            "payload": json.dumps(bedrock_payload),
        }

        if self.endpoint_url:
            kwargs["qualifier"] = self.endpoint_url

        # boto3 call is synchronous, so we wrap it in run_in_executor
        loop = asyncio.get_event_loop()
        response = await loop.run_in_executor(
            None, lambda: self.client.invoke_agent_runtime(**kwargs)
        )

        response_body = response["response"].read()
        result_data = json.loads(response_body)

        # Update context if returned
        remote_context_dict = result_data.get("updated_context")
        if remote_context_dict:
            remote_context = Context.from_dict(remote_context_dict)
            context.merge(
                remote_context,
                base_messages_count,
                base_thoughts_count,
                base_usage_count,
            )

        # Return the result
        result = result_data.get("result")

        output_type = self._get_generic_type(1)
        if output_type and result is not None:
            if hasattr(output_type, "model_validate"):
                return output_type.model_validate(result)

        return result
