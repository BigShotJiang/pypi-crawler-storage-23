from typing import Any, Dict, Optional
from bedrock_agentcore.runtime.app import BedrockAgentCoreApp
from agentswarm.agents.base_agent import BaseAgent
from agentswarm.datamodels.context import Context
from agentswarm.llms.llm import LLM


class BedrockAgentCoreWrapper:
    """
    Wraps an AgentSwarm agent to be compatible with Bedrock AgentCore.
    """

    def __init__(self, agent: BaseAgent, default_llm: Optional[LLM] = None):
        self.agent = agent
        self.default_llm = default_llm
        self.app = BedrockAgentCoreApp()
        self._setup_routes()

    def _setup_routes(self):
        @self.app.entrypoint
        async def handle_invoke(request: Dict[str, Any]) -> Dict[str, Any]:
            # Map Bedrock AgentCore request to AgentSwarm execution
            user_id = request.get("user_id", "default_user")
            payload = request.get("payload", {})
            input_text = payload.get("input")
            context_dict = payload.get("context", {})

            context = Context.from_dict(context_dict, default_llm=self.default_llm)

            result = await self.agent.execute(
                user_id=user_id, context=context, input=input_text
            )

            return {
                "result": result,
                "updated_context": context.to_dict(),
            }

    def run(self, host: str = "0.0.0.0", port: int = 8000):
        self.app.run(host=host, port=port)
