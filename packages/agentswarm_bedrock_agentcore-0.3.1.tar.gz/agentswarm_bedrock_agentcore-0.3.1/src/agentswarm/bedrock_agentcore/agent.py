import asyncio
from typing import Any, Dict, Optional, TypeVar

from agentswarm.agents.base_agent import BaseAgent, InputType, OutputType
from agentswarm.agents.remote_agent import (
    RemoteAgent,
    RemoteExecutionMode,
    RemoteExecutionHandler,
)
from agentswarm.datamodels.context import Context

from .app import BedrockAgentCoreWrapper

# Only import bedrock if needed or handle it gracefully
try:
    from bedrock_agentcore.runtime.agent_core_runtime_client import (
        AgentCoreRuntimeClient,
    )
except ImportError:
    AgentCoreRuntimeClient = None


from agentswarm.llms.llm import LLM


class BedrockAgent(BaseAgent[InputType, OutputType]):
    """
    Base class for agents that want to be hosted as Bedrock AgentCore agents.
    """

    def __init__(self, default_llm: Optional[LLM] = None):
        self.default_llm = default_llm
        self._app: Optional[Any] = None

    @property
    def app(self):
        """
        Returns the Bedrock AgentCore app for this agent.
        """
        if self._app is None:
            wrapper = BedrockAgentCoreWrapper(self, default_llm=self.default_llm)
            self._app = wrapper.app
        return self._app

    def serve(
        self, host: str = "0.0.0.0", port: int = 8000, default_llm: Optional[LLM] = None
    ):
        """
        Starts a Bedrock AgentCore compatible server for this agent.
        """
        if default_llm:
            self.default_llm = default_llm
            self._app = None  # Force re-creation with new LLM

        self.app.run(host=host, port=port)


class BedrockRemoteAgent(RemoteAgent[InputType, OutputType]):
    """
    Proxy agent that communicates with a remote Bedrock AgentCore agent.
    """

    def __init__(
        self,
        endpoint_url: str,
        remote_agent_id: str,
        mode: RemoteExecutionMode = RemoteExecutionMode.SYNC,
        timeout: float = 30.0,
        region: Optional[str] = None,
    ):
        super().__init__(mode=mode)
        self.endpoint_url = endpoint_url or ""
        self.remote_agent_id = remote_agent_id
        self.timeout = timeout
        self.region = region

    def id(self) -> str:
        return f"bedrock_remote_{self.remote_agent_id}"

    def description(self, user_id: str) -> str:
        return f"Remote Bedrock agent proxy for {self.remote_agent_id}"

    def get_remote_agent_id(self) -> str:
        return self.remote_agent_id

    async def _call_remote_sync(self, payload: dict) -> dict:
        """
        Calls the remote agent. If endpoint_url is a URL, it uses HTTP POST.
        Otherwise, it assumes an AWS Bedrock agent (not yet fully implemented).
        """
        import httpx

        if self.endpoint_url.startswith(("http://", "https://", "ws://", "wss://")):
            # Local or direct network call to a BedrockAgentCore server
            base_url = self.endpoint_url.replace("ws://", "http://").replace(
                "wss://", "https://"
            )
            url = f"{base_url.rstrip('/')}/invocations"

            # Map AgentSwarm payload to Bedrock AgentCore wrapper format
            bedrock_payload = {
                "user_id": payload.get("user_id"),
                "payload": {
                    "input": payload.get("input"),
                    "context": payload.get("context"),
                },
            }

            async with httpx.AsyncClient() as client:
                response = await client.post(
                    url, json=bedrock_payload, timeout=self.timeout
                )
                response.raise_for_status()
                return response.json()

        elif self.endpoint_url.startswith("arn:aws:bedrock-agentcore:"):
            # AWS Bedrock cloud invocation
            import boto3
            import json
            import uuid

            region = self.region or self.endpoint_url.split(":")[3]
            client = boto3.client("bedrock-agentcore", region_name=region)

            # Map AgentSwarm payload to Bedrock AgentCore wrapper format
            # The wrapper expects: handle_invocation(user_id, payload)
            # We wrap our payload in the 'payload' key
            bedrock_payload = {
                "input": payload.get("input"),
                "context": payload.get("context"),
            }

            # runtimeSessionId must be 33+ chars. We'll use a UUID or the user_id if long enough
            session_id = payload.get("user_id") or str(uuid.uuid4())
            if len(session_id) < 33:
                session_id = f"session-{session_id}".ljust(33, "0")

            response = client.invoke_agent_runtime(
                agentRuntimeArn=self.endpoint_url,
                runtimeSessionId=session_id,
                payload=json.dumps(bedrock_payload),
            )

            response_body = response["response"].read()
            return json.loads(response_body)

        raise NotImplementedError(
            f"Backend for endpoint {self.endpoint_url} not yet implemented."
        )

    async def _call_remote_async_init(self, payload: dict) -> RemoteExecutionHandler:
        # Bedrock AgentCore might not have a native "async init/poll" pattern like HttpRemoteAgent,
        # as it is already built on WebSockets (duplex).
        # We can simulate it if needed, or stick to Sync (which is actually async under the hood).
        raise NotImplementedError(
            "Async mode not yet implemented for BedrockRemoteAgent"
        )

    async def _poll_for_result(
        self,
        handler: RemoteExecutionHandler,
        context: Context,
        base_messages_count: int,
        base_thoughts_count: int,
        base_usage_count: int,
    ) -> OutputType:
        raise NotImplementedError(
            "Async mode not yet implemented for BedrockRemoteAgent"
        )
