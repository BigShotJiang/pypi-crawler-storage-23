# -*- coding: utf-8 -*-
"""Allow ``python -m grdl_rt.ui`` to launch the runner GUI."""

import sys

from grdl_rt.ui import main

sys.exit(main())
