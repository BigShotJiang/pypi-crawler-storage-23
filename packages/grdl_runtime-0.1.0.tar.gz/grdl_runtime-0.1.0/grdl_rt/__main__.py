# -*- coding: utf-8 -*-
"""Enable ``python -m grdl_rt`` execution."""
import sys

from grdl_rt.cli import main

if __name__ == "__main__":
    sys.exit(main())
