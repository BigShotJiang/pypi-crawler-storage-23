"""Local media buffer for frames and future sensor modalities.

Stores frames to a temp directory during collection, then provides a
file manifest for the upload step.
"""
from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any


class MediaBuffer:
    """Buffer that saves rendered frames to a local directory.

    Accepts numpy arrays (HWC uint8), PIL Images, or file paths.
    PIL / numpy are imported lazily so the SDK has no hard imaging dependency.
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir)
        self._frames_dir = self._base / "frames"
        self._frames_dir.mkdir(parents=True, exist_ok=True)
        self._count = 0

    @property
    def frame_count(self) -> int:
        return self._count

    def add_frame(
        self,
        step: int,
        image: Any,
        *,
        format: str = "jpg",
        quality: int = 85,
    ) -> Path:
        """Save a single frame to disk.

        Args:
            step: Environment step number (used in filename).
            image: One of:
                - numpy ndarray (H, W, C) uint8
                - PIL Image
                - str or Path to an existing image file
            format: Image format extension (default ``"jpg"``).
            quality: JPEG quality 1-100 (default 85).

        Returns:
            Path to the saved file.
        """
        dest = self._frames_dir / f"frame_{step}.{format}"

        if isinstance(image, (str, Path)):
            src = Path(image)
            if src != dest:
                shutil.copy2(src, dest)
        elif _is_pil_image(image):
            save_kwargs: dict[str, Any] = {}
            if format in ("jpg", "jpeg"):
                save_kwargs["quality"] = quality
            image.save(str(dest), **save_kwargs)
        elif _is_ndarray(image):
            pil_img = _ndarray_to_pil(image)
            save_kwargs = {}
            if format in ("jpg", "jpeg"):
                save_kwargs["quality"] = quality
            pil_img.save(str(dest), **save_kwargs)
        else:
            raise TypeError(
                f"Unsupported image type: {type(image).__name__}. "
                "Expected numpy array, PIL Image, or file path."
            )

        self._count += 1
        return dest

    def list_files(self) -> list[dict[str, Any]]:
        """Return upload manifest entries for all stored media files.

        Each entry has:
            key:   S3 key suffix, e.g. ``"frames/frame_42.jpg"``
            local: absolute local path
            size:  file size in bytes
        """
        result: list[dict[str, Any]] = []
        for f in sorted(self._frames_dir.iterdir()):
            if f.is_file():
                result.append({
                    "key": f"exports/frames/{f.name}",
                    "local": str(f),
                    "size": f.stat().st_size,
                })
        return result

    def cleanup(self) -> None:
        """Remove the temp directory and all stored media."""
        if self._base.exists():
            shutil.rmtree(self._base, ignore_errors=True)


# ---------------------------------------------------------------------------
# Lazy helpers — avoid hard PIL / numpy dependency
# ---------------------------------------------------------------------------


def _is_pil_image(obj: Any) -> bool:
    try:
        from PIL import Image
        return isinstance(obj, Image.Image)
    except ImportError:
        return False


def _is_ndarray(obj: Any) -> bool:
    try:
        import numpy as np
        return isinstance(obj, np.ndarray)
    except ImportError:
        return False


def _ndarray_to_pil(arr: Any) -> Any:
    from PIL import Image
    return Image.fromarray(arr)
