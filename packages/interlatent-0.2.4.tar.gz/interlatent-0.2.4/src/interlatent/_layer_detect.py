"""Auto-detect hookable layers in PyTorch models (lazy torch import)."""
from __future__ import annotations

from typing import List


def _find_submodule(root, dotted: str):
    """Traverse a dotted attribute path to find a submodule."""
    mod = root
    for attr in dotted.split("."):
        mod = getattr(mod, attr, None)
        if mod is None:
            return None
    return mod


def detect_hookable_layers(
    model,
    max_layers: int = 3,
) -> List[str]:
    """Walk ``model.named_modules()`` and return dotted paths of hookable layers.

    Detection patterns (checked in order):
    1. SB3 MLP — ``mlp_extractor.policy_net``: return last ``nn.Linear``.
    2. SB3 CNN — ``features_extractor``: return last conv + last MLP linear.
    3. Generic fallback — all ``nn.Linear`` modules, return second-to-last.
    """
    import torch.nn as nn

    # Unwrap SB3 wrapper
    root = getattr(model, "policy", model)

    # Pattern 1: SB3 MLP extractor
    layers = _detect_sb3_mlp(root, nn)
    if layers:
        return layers[:max_layers]

    # Pattern 2: SB3 CNN extractor
    layers = _detect_sb3_cnn(root, nn)
    if layers:
        return layers[:max_layers]

    # Pattern 3: generic fallback
    layers = _detect_generic_linear(root, nn)
    return layers[:max_layers]


def _detect_sb3_mlp(root, nn) -> List[str]:
    mlp = _find_submodule(root, "mlp_extractor.policy_net")
    if mlp is None:
        return []

    last_linear = None
    for name, mod in mlp.named_modules():
        if isinstance(mod, nn.Linear):
            last_linear = name

    if last_linear is None:
        return []

    path = f"mlp_extractor.policy_net.{last_linear}" if last_linear else "mlp_extractor.policy_net"
    return [path]


def _detect_sb3_cnn(root, nn) -> List[str]:
    feat_ext = _find_submodule(root, "features_extractor")
    if feat_ext is None:
        return []

    last_conv = None
    last_linear = None
    for name, mod in feat_ext.named_modules():
        if name == "":
            continue
        if isinstance(mod, (nn.Conv1d, nn.Conv2d, nn.Conv3d)):
            last_conv = f"features_extractor.{name}"
        elif isinstance(mod, nn.Linear):
            last_linear = f"features_extractor.{name}"

    layers = []
    if last_conv:
        layers.append(last_conv)
    if last_linear:
        layers.append(last_linear)
    return layers


def _detect_generic_linear(root, nn) -> List[str]:
    linears: List[str] = []
    for name, mod in root.named_modules():
        if name == "":
            continue
        if isinstance(mod, nn.Linear):
            linears.append(name)

    if len(linears) >= 2:
        return [linears[-2]]
    elif linears:
        return [linears[0]]
    return []
