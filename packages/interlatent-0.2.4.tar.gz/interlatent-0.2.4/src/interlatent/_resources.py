from __future__ import annotations

import time
from typing import Any

from ._http import HTTPClient


class IndexResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def retrieve(self) -> dict[str, Any]:
        return self._http.request("GET", "/api/v1/index")


class EnvironmentsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self) -> list[dict[str, Any]]:
        return self._http.request("GET", "/api/v1/environments")

    def runs(self, env_id: str, *, limit: int = 20, offset: int = 0) -> dict[str, Any]:
        return self._http.request(
            "GET",
            f"/api/v1/environments/{env_id}/runs",
            params={"limit": limit, "offset": offset},
        )


class RunsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def retrieve(self, run_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/runs/{run_id}")

    def create(
        self,
        *,
        run_id: str,
        environment: str,
        layer: str,
        created_at: str | None = None,
        policy_path: str | None = None,
        collect_steps: int | None = None,
        pipeline_status: dict[str, bool] | None = None,
        tags: dict[str, str] | None = None,
        sdk_version: str | None = None,
        model_framework: str | None = None,
        failure_taxonomy: dict[str, str] | None = None,
        metric_definitions: list[str] | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "run_id": run_id,
            "environment": environment,
            "layer": layer,
            "created_at": created_at,
            "policy_path": policy_path,
            "collect_steps": collect_steps,
            "pipeline_status": pipeline_status or {},
            "tags": tags or {},
        }
        if sdk_version is not None:
            body["sdk_version"] = sdk_version
        if model_framework is not None:
            body["model_framework"] = model_framework
        if failure_taxonomy is not None:
            body["failure_taxonomy"] = failure_taxonomy
        if metric_definitions is not None:
            body["metric_definitions"] = metric_definitions
        return self._http.request("POST", "/api/v1/runs", json_body=body)

    def upload_urls(self, run_id: str, *, files: list[dict[str, Any]]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/runs/{run_id}/upload-urls",
            json_body={"files": files},
        )

    def upload_complete(self, run_id: str, *, manifest: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/runs/{run_id}/upload-complete",
            json_body={"manifest": manifest},
        )

    def update(
        self,
        run_id: str,
        *,
        pipeline_status: dict[str, bool] | None = None,
        tags: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        return self._http.request(
            "PATCH",
            f"/api/v1/runs/{run_id}",
            json_body={"pipeline_status": pipeline_status, "tags": tags},
        )

    # -- Processing --

    def process(
        self,
        run_id: str,
        *,
        sae_k: int = 32,
        sae_epochs: int = 20,
        sae_l1: float = 0.05,
        sae_top_k: int = 0,
        normalize: bool = True,
        skip_autolabel: bool = False,
        skip_export: bool = False,
    ) -> dict[str, Any]:
        """Trigger server-side processing for a run.

        Returns a dict with ``run_id``, ``job_id``, ``status``.
        """
        return self._http.request(
            "POST",
            f"/api/v1/runs/{run_id}/process",
            json_body={
                "sae_k": sae_k,
                "sae_epochs": sae_epochs,
                "sae_l1": sae_l1,
                "sae_top_k": sae_top_k,
                "normalize": normalize,
                "skip_autolabel": skip_autolabel,
                "skip_export": skip_export,
            },
            timeout=120,  # Modal cold start + Vercel cold start can be slow
        )

    def status(self, run_id: str) -> dict[str, Any]:
        """Get run status including latest processing job."""
        return self._http.request("GET", f"/api/v1/runs/{run_id}/status")

    def results(self, run_id: str) -> dict[str, Any]:
        """Get processing results (report, export URLs, etc.)."""
        return self._http.request("GET", f"/api/v1/runs/{run_id}/results")

    def wait(
        self,
        run_id: str,
        *,
        timeout: float = 300.0,
        poll: float = 5.0,
    ) -> dict[str, Any]:
        """Poll until server-side processing is completed or failed.

        Args:
            run_id: The run to poll.
            timeout: Max seconds to wait.
            poll: Seconds between polls.

        Returns:
            Final status dict from ``GET /runs/{id}/status``.

        Raises:
            TimeoutError: If processing doesn't finish within *timeout*.
        """
        deadline = time.monotonic() + timeout
        while True:
            data = self.status(run_id)
            processing = data.get("processing")
            if processing:
                st = processing.get("status", "")
                if st in ("completed", "failed"):
                    return data
            if time.monotonic() >= deadline:
                raise TimeoutError(
                    f"Processing for run {run_id} did not complete "
                    f"within {timeout}s (last status: {data})"
                )
            time.sleep(poll)


class EpisodesResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def meta(self, episode_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/meta")

    def chunk(self, episode_id: str, chunk_index: int) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/episodes/{episode_id}/chunks/{chunk_index}")

    def frame(self, episode_id: str, filename: str) -> bytes:
        data = self._http.request("GET", f"/api/v1/episodes/{episode_id}/frames/{filename}")
        if isinstance(data, bytes):
            return data
        if isinstance(data, str):
            return data.encode("utf-8")
        raise TypeError("Expected frame bytes response")


class LatentsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self, run_id: str) -> list[dict[str, Any]]:
        return self._http.request("GET", f"/api/v1/runs/{run_id}/latents")

    def retrieve(self, run_id: str, latent_id: int) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/runs/{run_id}/latents/{latent_id}")

    def create(self, run_id: str, *, latents: list[dict[str, Any]]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/runs/{run_id}/latents",
            json_body={"latents": latents},
        )


class CheckpointsResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def list(self, run_id: str) -> list[dict[str, Any]]:
        return self._http.request("GET", f"/api/v1/runs/{run_id}/checkpoints")

    def retrieve(self, run_id: str, checkpoint_id: str) -> dict[str, Any]:
        return self._http.request("GET", f"/api/v1/runs/{run_id}/checkpoints/{checkpoint_id}")

    def create(self, run_id: str, *, report: dict[str, Any]) -> dict[str, Any]:
        return self._http.request(
            "POST",
            f"/api/v1/runs/{run_id}/checkpoints",
            json_body={"report": report},
        )


class AuthResource:
    def __init__(self, http: HTTPClient) -> None:
        self._http = http

    def login(self, *, email: str, password: str) -> dict[str, Any]:
        return self._http.request(
            "POST",
            "/api/v1/auth/login",
            json_body={"email": email, "password": password},
        )
