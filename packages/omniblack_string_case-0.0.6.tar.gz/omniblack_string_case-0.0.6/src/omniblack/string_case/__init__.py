from collections.abc import Iterable
import importlib.metadata
from enum import Enum
from typing import cast


try:
    from regex import compile

    unicode_re = True
except ImportError:
    from re import compile

    unicode_re = False


__version__ = importlib.metadata.version(cast(str, __package__))

if unicode_re:
    word_pattern = compile(
        r"[\. \-_]+|"
        r"(?<=\p{Lowercase=true})(?=\p{Uppercase=true})",
    )
else:
    word_pattern = compile(r"[\. \-_]+|(?<=[a-z])(?=[A-Z])")


def words(string: str) -> Iterable[str]:
    yield from (word for word in word_pattern.split(string) if word)


class Cases(Enum):
    Camel = "Camel"
    CapKebab = "CapKebab"
    CapSnake = "CapSnake"
    Kebab = "Kebab"
    Pascal = "Pascal"
    Snake = "Snake"
    Title = "Title"

    Cobol = CapKebab

    def __init__(self, name):
        self.cap_boundary = name in {"Camel", "Pascal", "Title"}
        self.cap_first = name in {"Pascal", "Title"}
        self.cap_all = name in {"CapSnake", "CapKebab"}

        match name:
            case "Snake" | "CapSnake":
                self.separator = "_"
            case "Kebab" | "CapKebab":
                self.separator = "-"
            case "Title":
                self.separator = " "
            case "Pascal" | "Camel":
                self.separator = ""

    def handle_word(self, word: str, first: bool) -> str:
        if (self.cap_boundary and not first) or self.cap_first:
            return word.title()
        elif self.cap_all:
            return word.upper()
        else:
            return word.lower()

    def to(self, string: str) -> str:
        found_words = [
            self.handle_word(word, index == 0)
            for index, word in enumerate(words(string))
        ]

        return self.separator.join(found_words)


__all__ = (
    "Cases",
    "words",
    "word_pattern",
)
