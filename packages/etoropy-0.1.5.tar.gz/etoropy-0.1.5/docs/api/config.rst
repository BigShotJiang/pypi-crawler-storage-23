Configuration
=============

.. autopydantic_settings:: etoropy.EToroConfig
   :members:
   :show-inheritance:
