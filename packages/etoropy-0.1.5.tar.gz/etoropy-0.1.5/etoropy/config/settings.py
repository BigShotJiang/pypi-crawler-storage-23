from __future__ import annotations

from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings

from .constants import (
    DEFAULT_BASE_URL,
    DEFAULT_RATE_LIMIT_MAX_REQUESTS,
    DEFAULT_RATE_LIMIT_WINDOW,
    DEFAULT_RETRY_ATTEMPTS,
    DEFAULT_RETRY_DELAY,
    DEFAULT_TIMEOUT,
    DEFAULT_WS_URL,
)


class EToroConfig(BaseSettings):
    """SDK configuration, loaded from environment variables or passed directly.

    Every field can be set via its ``ETORO_``-prefixed env var
    (e.g. ``ETORO_API_KEY``, ``ETORO_MODE``).

    :param api_key: eToro Public API key.
    :param user_key: eToro user key.
    :param mode: ``"demo"`` (paper trading) or ``"real"`` (live trading).
    :param base_url: REST API base URL.
    :param ws_url: WebSocket endpoint URL.
    :param timeout: HTTP request timeout in seconds.
    :param retry_attempts: Max retries on transient failures (0 = no retry).
    :param retry_delay: Base delay in seconds between retries.
    :param rate_limit: Enable or disable the built-in rate limiter (default ``True``).
    :param rate_limit_max_requests: Max requests allowed in the sliding window (default 20).
    :param rate_limit_window: Sliding window size in seconds (default 10.0).
    """

    model_config = {"env_prefix": "ETORO_"}

    api_key: str = Field(min_length=1, description="eToro API key")
    user_key: str = Field(min_length=1, description="eToro user key")
    mode: Literal["demo", "real"] = "demo"
    base_url: str = DEFAULT_BASE_URL
    ws_url: str = DEFAULT_WS_URL
    timeout: float = DEFAULT_TIMEOUT
    retry_attempts: int = Field(default=DEFAULT_RETRY_ATTEMPTS, ge=0)
    retry_delay: float = Field(default=DEFAULT_RETRY_DELAY, gt=0)
    rate_limit: bool = True
    rate_limit_max_requests: int = Field(default=DEFAULT_RATE_LIMIT_MAX_REQUESTS, ge=1)
    rate_limit_window: float = Field(default=DEFAULT_RATE_LIMIT_WINDOW, gt=0)
