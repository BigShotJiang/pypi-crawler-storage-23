from archipy.helpers.interceptors.fastapi.metric.interceptor import FastAPIMetricInterceptor

__all__ = ["FastAPIMetricInterceptor"]
