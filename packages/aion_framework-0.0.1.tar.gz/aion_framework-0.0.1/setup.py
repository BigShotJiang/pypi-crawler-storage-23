from setuptools import setup

setup(
    name="aion-framework", 
    version="0.0.1",
    description="The Durable Application Framework for Agentic AI",
    long_description="# Aion Framework\n\nDurable Application Framework for Agentic AI. Coming soon.",
    long_description_content_type="text/markdown",
    author="Amaresh Pandey", # Change this
    author_email="aajsearch@gmail.com", # Change this
    url="https://github.com/aion-framework/aion", 
    packages=[],
)
