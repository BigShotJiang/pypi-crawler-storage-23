"""Google Calendar tools for FastMCP2."""
