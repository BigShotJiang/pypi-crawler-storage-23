"""Google Photos MCP integration package."""
