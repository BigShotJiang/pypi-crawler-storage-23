from .metropolis import MetropolisKernel

class NVTKernel(MetropolisKernel):
    """
    Metropolis-Hastings kernel for the NVT ensemble.
    """
    def __init__(self, temperature: float, rng=None):
        super().__init__(
            sampling_temperature=temperature,
            rng=rng
        )
    