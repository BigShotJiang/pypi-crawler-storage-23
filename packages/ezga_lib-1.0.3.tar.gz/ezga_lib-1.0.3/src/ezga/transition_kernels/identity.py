from typing import Any, List
from sage_lib.partition.Partition import Partition
from .base import TransitionKernel

class IdentityKernel(TransitionKernel):
    """
    Identity kernel that accepts all candidates (100% acceptance).
    Useful for simple trajectory following without Metropolis-Hastings criteria.
    """

    def __init__(self, **kwargs):
        pass

    def step(
        self,
        parents: Any,
        candidates: List[Any],
        **kwargs
    ) -> List[Any]:
        """
        Always returns the candidates, effectively accepting them all.
        """
        if not candidates:
            return []
            
        # Handle candidates being a list of partitions or other objects
        candidates_list = candidates
        
        return candidates_list
