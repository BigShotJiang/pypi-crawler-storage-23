"""
convergenve.py
=============

Sub-package for checking convergence.
"""
