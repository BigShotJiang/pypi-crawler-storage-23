# SPDX-License-Identifier: MIT
from ezga.cli import app

if __name__ == "__main__":
    app()