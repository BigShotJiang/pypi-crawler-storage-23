# Unit tests for MCP server.
