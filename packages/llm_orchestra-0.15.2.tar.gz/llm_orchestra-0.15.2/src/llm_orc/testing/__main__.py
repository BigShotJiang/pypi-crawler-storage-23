"""Main entry point for contract validator CLI module."""

from llm_orc.testing.contract_validator import main

if __name__ == "__main__":
    main()
