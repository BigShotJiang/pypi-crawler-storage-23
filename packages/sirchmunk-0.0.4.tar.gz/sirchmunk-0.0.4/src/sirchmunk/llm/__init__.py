# Copyright (c) ModelScope Contributors. All rights reserved.
from .openai_chat import OpenAIChat
