DROP VIEW gqlite_{{ graph_name }}_edges_undirected;
DROP TABLE gqlite_{{ graph_name }}_edges;
DROP TABLE gqlite_{{ graph_name }}_nodes;