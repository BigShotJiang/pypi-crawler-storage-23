use super::FResult;
use crate::prelude::*;

#[derive(Debug, Default)]
pub(super) struct Size {}

impl Size
{
  fn call_impl(value: value::Value) -> FResult<i64>
  {
    match value
    {
      value::Value::String(str) => Ok(str.len() as i64),
      value::Value::Array(arr) => Ok(arr.len() as i64),
      value::Value::Map(obj) => Ok(obj.len() as i64),
      value::Value::Path(..) => Ok(1.into()),
      _ => Err(RunTimeError::InvalidArgument {
        function_name: "size",
        index: 0,
        expected_type: "array, map or string",
        value: format!("{:?}", value),
      }),
    }
  }
}

super::declare_function!(size, Size, call_impl(graphcore::Value) -> i64, null_handling(null_returns_null));
