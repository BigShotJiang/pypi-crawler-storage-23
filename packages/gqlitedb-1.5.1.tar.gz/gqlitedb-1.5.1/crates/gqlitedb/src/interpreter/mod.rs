pub(crate) mod evaluators;
pub(crate) mod instructions;

pub(crate) type Program = Vec<instructions::Block>;
