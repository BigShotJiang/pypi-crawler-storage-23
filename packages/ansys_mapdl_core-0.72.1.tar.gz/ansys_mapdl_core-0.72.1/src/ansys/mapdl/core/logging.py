# Copyright (C) 2016 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Logging module.

This module supplies a general framework for logging in PyMAPDL.  This module is
built upon `logging <https://docs.python.org/3/library/logging.html>`_ library
and it does not intend to replace it rather provide a way to interact between
``logging`` and PyMAPDL.

The loggers used in the module include the name of the instance which
is intended to be unique.  This name is printed in all the active
outputs and it is used to track the different MAPDL instances.


How to use
==========

Global logger
~~~~~~~~~~~~~
There is a global logger named ``pymapdl_global`` which is created at
``ansys.mapdl.core.__init__``.  If you want to use this global logger,
you must call at the top of your module:

.. code:: python

   from ansys.mapdl.core import LOG

You could also rename it to avoid conflicts with other loggers (if any):

.. code:: python

   from ansys.mapdl.core import LOG as logger


It should be noticed that the default logging level of ``LOG`` is ``ERROR``.
To change this and output lower level messages you can use the next snippet:

.. code:: python

   LOG.logger.setLevel("DEBUG")
   LOG.file_handler.setLevel("DEBUG")  # If present.
   LOG.std_out_handler.setLevel("DEBUG")  # If present.


Alternatively:

.. code:: python

   LOG.setLevel("DEBUG")

This way ensures all the handlers are set to the input log level.

By default, this logger does not log to a file. If you wish to do so,
you can add a file handler using:

.. code:: python

   import os

   file_path = os.path.join(os.getcwd(), "pymapdl.log")
   LOG.log_to_file(file_path)

This sets the logger to be redirected also to that file.  If you wish
to change the characteristics of this global logger from the beginning
of the execution, you must edit the file ``__init__`` in the directory
``ansys.mapdl.core``.

To log using this logger, just call the desired method as a normal logger.

.. code:: pycon

    >>> import logging
    >>> from ansys.mapdl.core.logging import Logger
    >>> LOG = Logger(level=logging.DEBUG, to_file=False, to_stdout=True)
    >>> LOG.debug("This is LOG debug message.")

    DEBUG -  -  <ipython-input-24-80df150fe31f> - <module> - This is LOG debug message.


Instance Logger
~~~~~~~~~~~~~~~
Every time an instance of :class:`Mapdl <ansys.mapdl.core.mapdl.MapdlBase>` is
created, a logger is created and stored in two places:

* ``MapdlBase._log``. For backward compatibility.
* ``LOG._instances``. This field is a ``dict`` where the key is the name of the
  created logger.

These instance loggers inheritate the ``pymapdl_global`` output handlers and
logging level unless otherwise specified.  The way this logger works is very
similar to the global logger.  You can add a file handler if you wish using
:func:`log_to_file() <PymapdlCustomAdapter.log_to_file>` or change the log level
using :func:`logger.Logging.setLevel`.

You can use this logger like this:

.. code:: pycon
    >>> from ansys.mapdl.core import launch_mapdl
    >>> mapdl = launch_mapdl()
    >>> mapdl._log.info("This is a useful message")

    INFO - GRPC_127.0.0.1:50056 -  <ipython-input-19-f09bb2d8785c> - <module> - This is a useful message



Other loggers
~~~~~~~~~~~~~
You can create your own loggers using python ``logging`` library as
you would do in any other script.  There shall no be conflicts between
these loggers.
"""

from copy import copy
from datetime import datetime
import logging
import sys
from types import TracebackType
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Literal,
    Mapping,
    MutableMapping,
    Optional,
    Type,
    Union,
    cast,
)
import weakref

if TYPE_CHECKING:  # pragma: no cover
    from ansys.mapdl.core.mapdl import MapdlBase

## Default configuration
LOG_LEVEL = logging.DEBUG
FILE_NAME = "pymapdl.log"

# For convenience
DEBUG = logging.DEBUG
INFO = logging.INFO
WARN = logging.WARN
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL

## Formatting

STDOUT_MSG_FORMAT = (
    "%(levelname)s - %(instance_name)s -  %(module)s - %(funcName)s - %(message)s"
)

FILE_MSG_FORMAT = STDOUT_MSG_FORMAT

DEFAULT_STDOUT_HEADER = """
LEVEL - INSTANCE NAME - MODULE - FUNCTION - MESSAGE
"""
DEFAULT_FILE_HEADER = DEFAULT_STDOUT_HEADER

NEW_SESSION_HEADER = f"""
===============================================================================
       NEW SESSION - {datetime.now().strftime("%m/%d/%Y, %H:%M:%S")}
==============================================================================="""

LOG_LEVEL_STRING_TYPE = Literal["DEBUG", "INFO", "WARN", "WARNING", "ERROR", "CRITICAL"]
LOG_LEVEL_TYPE = Union[LOG_LEVEL_STRING_TYPE, int]

string_to_loglevel: Dict[LOG_LEVEL_STRING_TYPE, int] = {
    "DEBUG": DEBUG,
    "INFO": INFO,
    "WARN": WARN,
    "WARNING": WARN,
    "ERROR": ERROR,
    "CRITICAL": CRITICAL,
}


class PymapdlCustomAdapter(logging.LoggerAdapter):
    """This is key to keep the reference to the MAPDL instance name dynamic.

    If we use the standard approach which is supplying ``extra`` input
    to the logger, we would need to keep inputting MAPDL instances
    every time we do a log.

    Using adapters we just need to specify the MAPDL instance we refer
    to once.
    """

    level = None  # This is maintained for compatibility with ``supress_logging``, but it does nothing.
    file_handler: Optional[logging.FileHandler] = None
    std_out_handler: Optional[logging.StreamHandler] = None

    def __init__(self, logger: logging.Logger, extra: Optional["MapdlBase"] = None):
        self.logger = logger
        if extra is not None:
            self.extra = weakref.proxy(extra)  # type: ignore[assignment]
        else:
            self.extra = None
        self.file_handler = logger.file_handler  # type: ignore[attr-defined]
        self.std_out_handler = logger.std_out_handler  # type: ignore[attr-defined]

    def process(self, msg: str, kwargs: MutableMapping[str, Dict[str, str]]):
        kwargs["extra"] = {}
        # This are the extra parameters sent to log
        if self.extra is not None:
            kwargs["extra"]["instance_name"] = self.extra.name  # type: ignore[union-attr,attr-defined]
        return msg, kwargs

    def log_to_file(
        self, filename: str = FILE_NAME, level: LOG_LEVEL_TYPE = LOG_LEVEL
    ) -> None:
        """Add file handler to logger.

        Parameters
        ----------
        filename : str, optional
            Name of the file where the logs are recorded. By default FILE_NAME
        level : str or int, optional
            Level of logging. E.x. 'DEBUG'. By default LOG_LEVEL
        """

        addfile_handler(self.logger, filename=filename, level=level, write_headers=True)
        self.file_handler = self.logger.file_handler

    def log_to_stdout(self, level: LOG_LEVEL_TYPE = LOG_LEVEL) -> None:
        """Add standard output handler to the logger.

        Parameters
        ----------
        level : str or int, optional
            Level of logging record. By default LOG_LEVEL
        """
        if self.std_out_handler:
            raise Exception("Stdout logger already defined.")

        add_stdout_handler(self.logger, level=level)
        self.std_out_handler = self.logger.std_out_handler

    def setLevel(self, level: Union[int, str] = "DEBUG"):
        """Change the log level of the object and the attached handlers."""
        if isinstance(level, str):
            level = string_to_loglevel[cast(LOG_LEVEL_STRING_TYPE, level.upper())]
        self.logger.setLevel(level)
        for each_handler in self.logger.handlers:
            each_handler.setLevel(level)
        self.level = level


class PymapdlPercentStyle(logging.PercentStyle):
    def __init__(self, fmt, *, defaults=None):
        self._fmt = fmt or self.default_format
        self._defaults = defaults

    def _format(self, record) -> str:
        defaults = self._defaults
        if defaults:
            values = defaults | record.__dict__
        else:
            values = record.__dict__

        # We can do here any changes we want in record, for example adding a key.

        # We could create an if here if we want conditional formatting, and even
        # change the record.__dict__.
        # Since now we don't want to create conditional fields, it is fine to keep
        # the same MSG_FORMAT for all of them.

        # For the case of logging exceptions to the logger.
        values.setdefault("instance_name", "")

        return STDOUT_MSG_FORMAT % values


class PymapdlFormatter(logging.Formatter):
    """Customized ``Formatter`` class used to overwrite the defaults format styles."""

    def __init__(
        self,
        fmt: str = STDOUT_MSG_FORMAT,
        datefmt: Optional[str] = None,
        style: Literal["%", "{", "$"] = "%",
        validate: bool = True,
        defaults: Optional[Mapping[str, Any]] = None,
    ):
        if sys.version_info[1] < 8:
            super().__init__(fmt, datefmt, style)
        else:
            # 3.8: The validate parameter was added
            super().__init__(fmt, datefmt, style, validate)
        self._style = PymapdlPercentStyle(fmt, defaults=defaults)  # overwriting


class InstanceFilter(logging.Filter):
    """Ensures that instance_name record always exists."""

    def filter(self, record: logging.LogRecord):
        if not hasattr(record, "instance_name") and hasattr(record, "name"):
            record.instance_name = record.name
        elif not hasattr(record, "instance_name"):  # pragma: no cover
            record.instance_name = ""
        return True


class Logger:
    """Logger used for each PyMAPDL session.

    This class allows you to add handlers to the logger to output to a file or
    standard output.

    Parameters
    ----------
    level : int, optional
        Logging level to filter the message severity allowed in the logger.
        The default is ``logging.DEBUG``.
    to_file : bool, optional
        Write log messages to a file. The default is ``False``.
    to_stdout : bool, optional
        Write log messages into the standard output. The default is
        ``True``.
    filename : str, optional
        Name of the file where log messages are written to.
        The default is ``FILE_NAME``.

    Examples
    --------
    Demonstrate logger usage from an instance mapdl. This is automatically
    created when creating an Mapdl instance.

    >>> from ansys.mapdl.core import launch_mapdl
    >>> mapdl = launch_mapdl(loglevel='DEBUG')
    >>> mapdl._log.info('This is a useful message')
    INFO -  -  <ipython-input-24-80df150fe31f> - <module> - This is LOG debug message.

    Import the global pymapdl logger and add a file output handler.

    >>> import os
    >>> from ansys.mapdl.core import LOG
    >>> file_path = os.path.join(os.getcwd(), 'pymapdl.log')
    >>> LOG.log_to_file(file_path)
    """

    file_handler: Optional[logging.FileHandler] = None
    std_out_handler: Optional[logging.StreamHandler] = None
    _level = logging.DEBUG
    _instances: Dict[str, Any] = {}

    def __init__(
        self,
        level: LOG_LEVEL_TYPE = logging.DEBUG,
        to_file: bool = False,
        to_stdout: bool = True,
        filename: str = FILE_NAME,
        catch_all_exceptions: bool = False,
    ):
        """Customized logger class for PyMAPDL.

        Parameters
        ----------
        level : str or int, optional
            Level of logging as defined in the package ``logging``. By default 'DEBUG'.
        to_file : bool, optional
            To record the logs in a file, by default ``False``.
        to_stdout : bool, optional
            To output the logs to the standard output, which is the
            command line. By default ``True``.
        filename : str, optional
            Name of the output file. By default ``pymapdl.log``.
        """

        # create default main logger
        self.logger: logging.Logger = logging.getLogger("pymapdl_global")
        self.logger.addFilter(InstanceFilter())
        if isinstance(level, str):
            level = cast(LOG_LEVEL_STRING_TYPE, level.upper())

        self.logger.setLevel(level)
        self.logger.propagate = True
        self.level = self.logger.level  # TODO: TO REMOVE

        # Writing logging methods.
        self.debug = self.logger.debug
        self.info = self.logger.info
        self.warning = self.logger.warning
        self.error = self.logger.error
        self.critical = self.logger.critical
        self.log = self.logger.log

        if to_file:
            # We record to file
            self.log_to_file(filename=filename, level=level)

        if to_stdout:
            self.log_to_stdout(level=level)

        # Using logger to record unhandled exceptions
        if catch_all_exceptions:
            self.add_handling_uncaught_expections(self.logger)

    def log_to_file(
        self, filename: str = FILE_NAME, level: LOG_LEVEL_TYPE = LOG_LEVEL
    ) -> None:
        """Add file handler to logger.

        Parameters
        ----------
        filename : str, optional
            Name of the file where the logs are recorded. By default
            ``'pymapdl.log'``.
        level : str or int, optional
            Level of logging. By default ``'DEBUG'``.

        Examples
        --------
        Write to ``pymapdl.log`` in the current working directory.

        >>> from ansys.mapdl.core import LOG
        >>> import os
        >>> file_path = os.path.join(os.getcwd(), 'pymapdl.log')
        >>> LOG.log_to_file(file_path)
        """

        addfile_handler(self, filename=filename, level=level, write_headers=True)

    def log_to_stdout(self, level: LOG_LEVEL_TYPE = LOG_LEVEL):
        """Add standard output handler to the logger.

        Parameters
        ----------
        level : str or int, optional
            Level of logging record. By default  ``'DEBUG'``.
        """

        add_stdout_handler(self, level=level)

    def setLevel(self, level: LOG_LEVEL_TYPE = "DEBUG"):
        """Change the log level of the object and the attached handlers."""
        if isinstance(level, str):
            level = string_to_loglevel[cast(LOG_LEVEL_STRING_TYPE, level.upper())]
        self.logger.setLevel(level)
        for each_handler in self.logger.handlers:
            each_handler.setLevel(level)
        self._level = level

    def _make_child_logger(
        self, logger_name: str, level: Optional[LOG_LEVEL_TYPE]
    ) -> logging.Logger:
        """Create a child logger.

        Uses ``getChild`` or copying attributes between ``pymapdl_global``
        logger and the new one.
        """
        logger = logging.getLogger(logger_name)
        logger.std_out_handler = None  # type: ignore[attr-defined]
        logger.file_handler = None  # type: ignore[attr-defined]

        if self.logger.hasHandlers():
            for each_handler in self.logger.handlers:
                new_handler = copy(each_handler)
                if each_handler == self.file_handler:
                    logger.file_handler = new_handler  # type: ignore[attr-defined]
                elif each_handler == self.std_out_handler:
                    logger.std_out_handler = new_handler  # type: ignore[attr-defined]

                if level:
                    # The logger handlers are copied and changed the loglevel is
                    # the specified log level is lower than the one of the
                    # global.
                    if isinstance(level, str):
                        new_loglevel = string_to_loglevel[
                            cast(LOG_LEVEL_STRING_TYPE, level.upper())
                        ]
                    elif isinstance(level, int):  # pragma: no cover
                        new_loglevel = level

                    if each_handler.level > new_loglevel:
                        new_handler.setLevel(level)

                logger.addHandler(new_handler)

        if level:
            if isinstance(level, str):
                level = string_to_loglevel[cast(LOG_LEVEL_STRING_TYPE, level.upper())]
            logger.setLevel(level)

        else:
            logger.setLevel(self.logger.level)

        logger.propagate = True
        return logger

    def add_child_logger(
        self, logger_name: str, level: Optional[LOG_LEVEL_TYPE] = None
    ):
        """Add a child logger to the main logger.

        This logger is more general than an instance logger which is designed to
        track the state of the MAPDL instances.

        If the logging level is in the arguments, a new logger with a reference
        to the ``_global`` logger handlers is created instead of a child.

        Parameters
        ----------
        logger_name : str
            Name of the logger.
        level : str or int, optional
            Level of logging

        Returns
        -------
        logging.logger
            Logger class.
        """
        name = self.logger.name + "." + logger_name
        self._instances[name] = self._make_child_logger(name, level)
        return self._instances[name]

    def _add_mapdl_instance_logger(
        self,
        name: Optional[str],
        mapdl_instance: "MapdlBase",
        level: Optional[LOG_LEVEL_TYPE],
    ) -> logging.Logger:
        if isinstance(name, str):
            instance_logger = PymapdlCustomAdapter(
                self._make_child_logger(name, level), mapdl_instance
            )
        elif not name:  # pragma: no cover
            instance_logger = PymapdlCustomAdapter(
                self._make_child_logger("NO_NAMED_YET", level), mapdl_instance
            )
        else:
            raise ValueError("You can only input 'str' classes to this method.")

        return instance_logger

    def add_instance_logger(
        self,
        name: str,
        mapdl_instance: "MapdlBase",
        level: Optional[LOG_LEVEL_TYPE] = None,
    ) -> logging.Logger:
        """Create a logger for a MAPDL instance.

        The MAPDL instance logger is a logger with an adapter which add the
        contextual information such as MAPDL instance name. This logger is
        returned and you can use it to log events as a normal logger. It is also
        stored in the ``_instances`` field.

        Parameters
        ----------
        name : str
            Name for the new logger
        mapdl_instance : ansys.mapdl.core.mapdl.MapdlBase
            Mapdl instance object. This should contain the attribute ``name``.

        Returns
        -------
        ansys.mapdl.core.logging.PymapdlCustomAdapter
            Logger adapter customized to add MAPDL information to the
            logs.  You can use this class to log events in the same
            way you would with the logger class.

        Raises
        ------
        Exception
            You can only input strings as ``name`` to this method.
        """
        count_ = 0
        new_name = name
        while new_name in logging.root.manager.__dict__.keys():
            count_ += 1
            new_name = name + "_" + str(count_)

        self._instances[new_name] = self._add_mapdl_instance_logger(
            new_name, mapdl_instance, level
        )
        return self._instances[new_name]

    def __getitem__(self, key: str):
        if key in self._instances.keys():
            return self._instances[key]
        else:
            raise KeyError(f"There is no instances with name {key}")

    def add_handling_uncaught_expections(self, logger: logging.Logger):
        """This just redirect the output of an exception to the logger."""

        def handle_exception(
            exc_type: Type[BaseException],
            exc_value: BaseException,
            exc_traceback: Optional[TracebackType],
        ):
            if issubclass(exc_type, KeyboardInterrupt):
                sys.__excepthook__(exc_type, exc_value, exc_traceback)
                return
            logger.critical(
                "Uncaught exception",
                exc_info=(exc_type, exc_value, exc_traceback),
            )

        sys.excepthook = handle_exception


def addfile_handler(
    logger: Union[Logger, logging.Logger],
    filename: str = FILE_NAME,
    level: LOG_LEVEL_TYPE = LOG_LEVEL,
    write_headers: bool = False,
):
    """Add a file handler to the input.

    Parameters
    ----------
    logger : logging.Logger or logging.Logger
        Logger where to add the file handler.
    filename : str, optional
        Name of the output file. By default FILE_NAME
    level : str or int, optional
        Level of log recording. By default LOG_LEVEL
    write_headers : bool, optional
        Record the headers to the file. By default False

    Returns
    -------
    logger
        Return the logger or Logger object.
    """

    file_handler = logging.FileHandler(filename)
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(FILE_MSG_FORMAT))

    if isinstance(logger, Logger):
        logger.file_handler = file_handler
        logger.logger.addHandler(file_handler)

    elif isinstance(logger, logging.Logger):
        logger.file_handler = file_handler  # type: ignore[attr-defined]
        logger.addHandler(file_handler)

    if write_headers:
        file_handler.stream.write(NEW_SESSION_HEADER)
        file_handler.stream.write(DEFAULT_FILE_HEADER)

    return logger


def add_stdout_handler(
    logger: Union[Logger, logging.Logger],
    level: LOG_LEVEL_TYPE = LOG_LEVEL,
    write_headers: bool = False,
):
    """Add a file handler to the logger.

    Parameters
    ----------
    logger : logging.Logger or logging.Logger
        Logger where to add the file handler.
    level : str or int, optional
        Level of log recording. By default ``logging.DEBUG``.
    write_headers : bool, optional
        Record the headers to the file. By default ``False``.

    Returns
    -------
    logger
        The logger or Logger object.
    """

    std_out_handler = logging.StreamHandler()
    std_out_handler.setLevel(level)
    std_out_handler.setFormatter(PymapdlFormatter(STDOUT_MSG_FORMAT))

    if isinstance(logger, Logger):
        logger.std_out_handler = std_out_handler
        logger.logger.addHandler(std_out_handler)

    elif isinstance(logger, logging.Logger):
        logger.addHandler(std_out_handler)

    if write_headers:
        std_out_handler.stream.write(DEFAULT_STDOUT_HEADER)

    return logger
