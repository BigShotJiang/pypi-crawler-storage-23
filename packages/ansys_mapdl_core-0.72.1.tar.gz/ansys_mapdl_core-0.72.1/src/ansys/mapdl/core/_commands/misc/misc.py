# Copyright (C) 2016 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from ansys.mapdl.core._commands import CommandsBase

"""Miscellaneous methods not covered in the documentation."""


class Misc(CommandsBase):
    def verify(self, case="", level="", **kwargs):
        """Enter the verification run mode.

        .. note::
           This command is only valid at the ``/BEGIN`` level, obtained
           with ``mapdl.finish()``.

        Parameters
        ----------
        case : str, optional
            Optional title of the verification manual file.  Also accepts
            ``'OFF'`` to disable the verification run mode.

        level : int, optional
            Verification level ranging from 1 to 6 defaulting to 4.

        Returns
        -------
        str
            Command output.

        Examples
        --------
        Enter the verification routine with the default option.

        >>> mapdl.finish()
        >>> mapdl.verify('VM1')
        '*** VERIFICATION RUN - CASE VM1                              ***  OPTION=  4'
        """
        return self.run(f"/VERIFY,{case},{level}", **kwargs)
