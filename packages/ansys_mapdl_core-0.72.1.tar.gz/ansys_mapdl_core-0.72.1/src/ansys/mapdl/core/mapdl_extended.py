# Copyright (C) 2016 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from functools import wraps
import os
import pathlib
import re
import tempfile
from typing import Union
import warnings

import numpy as np
from numpy.typing import DTypeLike, NDArray

from ansys.mapdl.core import LOG as logger
from ansys.mapdl.core.commands import CommandListingOutput, CommandOutput
from ansys.mapdl.core.errors import (
    CommandDeprecated,
    ComponentDoesNotExits,
    IncorrectWorkingDirectory,
    MapdlCommandIgnoredError,
    MapdlRuntimeError,
)
from ansys.mapdl.core.mapdl_core import _MapdlCore
from ansys.mapdl.core.mapdl_types import KwargDict, MapdlFloat
from ansys.mapdl.core.misc import (
    allow_iterables_vmin,
    allow_pickable_entities,
    check_deprecated_vtk_kwargs,
    random_string,
    requires_graphics,
    supress_logging,
)
from ansys.mapdl.core.plotting import GraphicsBackend

TMP_VAR = "__tmpvar__"


class _MapdlCommandExtended(_MapdlCore):
    """Class that extended MAPDL capabilities by wrapping or overwriting commands"""

    def __init__(self, *args, **kwargs):
        """Initialize the MAPDL command extended class.

        Parameters
        ----------
        *args : list
            Positional arguments to pass to the base class.

        **kwargs : dict
            Keyword arguments to pass to the base class.
        """
        super().__init__(*args, **kwargs)
        self._graphics_backend = GraphicsBackend.PYVISTA

    @wraps(_MapdlCore.file)
    def file(self, fname: str = "", ext: str = "", **kwargs) -> str:
        """Wraps file to upload the file to the MAPDL working directory."""
        fname = self._get_file_name(fname, ext, "cdb")
        fname = self._get_file_path(fname, kwargs.get("progress_bar", False))
        file_, ext_, path_ = self._decompose_fname(fname)

        if self._local:
            return super().file(fname=path_ / file_, ext=ext_, **kwargs)
        else:
            return super().file(fname=file_, ext=ext_, **kwargs)

    @wraps(_MapdlCore.lsread)
    def lsread(self, *args, **kwargs):
        """Wraps the ``LSREAD`` which does not work in interactive mode.

        Parameters
        ----------
        *args : tuple
            Positional arguments to pass to the LSREAD command.
        **kwargs : dict
            Keyword arguments to pass to the LSREAD command.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        self._log.debug("Forcing 'LSREAD' to run in non-interactive mode.")
        with self.non_interactive:
            super().lsread(*args, **kwargs)
        return self._response.strip()

    @wraps(_MapdlCore.use)
    def use(self, *args, **kwargs):
        """Wrap the use command.

        Parameters
        ----------
        *args : tuple
            Positional arguments to pass to the USE command.
        **kwargs : dict
            Keyword arguments to pass to the USE command.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        # Because of `name` can be a macro file or a macro block on a macro library
        # file, we are going to test if the file exists locally first, then remote,
        # and if not, silently assume that it is a macro in a macro library.
        # I do not think there is a way to check if the macro exists before use it.
        if "name" in kwargs:
            name = kwargs.pop("name")
        else:
            if len(args) < 1:
                raise ValueError("Missing `name` argument")
            name = args[0]

        base_name = os.path.basename(name)

        # Check if it is a file local
        if os.path.exists(name):
            self.upload(name)

        elif base_name in self.list_files():
            # the file exists in the MAPDL working directory, so do nothing.
            pass

        else:
            if os.path.dirname(name):
                # It seems you provided a path (or something like that)
                raise FileNotFoundError(
                    f"The name supplied to 'mapdl.use' ('{name}') is not a file in the Python "
                    "working directory, nor in the MAPDL working directory. "
                )
            # Preferring logger.warning over warn (from warnings), since it is less intrusive.
            self._log.warning(
                f"The name supplied to 'mapdl.use' ('{name}') is not a file in the Python "
                "working directory, nor in the MAPDL working directory. "
                "PyMAPDL will assume it is a macro block inside a macro library "
                "file previously defined using 'mapdl.ulib'."
            )
            # If MAPDL cannot find named macro file, it will throw a runtime error.

        # Update arg because the path is no longer needed
        args = (base_name, *args[1:])

        with self.non_interactive:
            super().use(*args, **kwargs)

        return self._response  # returning last response

    @wraps(_MapdlCore.set)
    def set(
        self,
        lstep="",
        sbstep="",
        fact="",
        kimg="",
        time="",
        angle="",
        nset="",
        order="",
        **kwargs,
    ):
        """Wraps SET to return a Command listing

        Returns
        -------
        CommandListingOutput or str
            Command listing output when LIST is specified, otherwise MAPDL command output.
        """
        output = super().set(
            lstep, sbstep, fact, kimg, time, angle, nset, order, **kwargs
        )

        if (
            isinstance(lstep, str)
            and lstep.upper() == "LIST"
            and not sbstep
            and not fact
        ):
            return CommandListingOutput(
                output,
                magicwords=["SET", "TIME/FREQ"],
                columns_names=[
                    "SET",
                    "TIME/FREQ",
                    "LOAD STEP",
                    "SUBSTEP",
                    "CUMULATIVE",
                ],
            )
        else:
            return output

    @wraps(_MapdlCore.vsel)
    def vsel(self, *args, **kwargs) -> str:
        """Wraps superclassed VSEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().vsel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities(entity="volu", plot_function="vplot")
        @allow_iterables_vmin(entity="volume")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.nsel)
    def nsel(self, *args, **kwargs) -> str:
        """Wraps previons NSEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().nsel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities()
        @allow_iterables_vmin(entity="node")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.esel)
    def esel(self, *args, **kwargs) -> str:
        """Wraps previons ESEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().esel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities(entity="elem", plot_function="eplot")
        @allow_iterables_vmin(entity="elem")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.ksel)
    def ksel(self, *args, **kwargs) -> str:
        """Wraps superclassed KSEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().ksel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities(entity="kp", plot_function="kplot")
        @allow_iterables_vmin(entity="kp")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.lsel)
    def lsel(self, *args, **kwargs) -> str:
        """Wraps superclassed LSEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().lsel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities(entity="line", plot_function="lplot")
        @allow_iterables_vmin(entity="line")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.asel)
    def asel(self, *args, **kwargs) -> str:
        """Wraps superclassed ASEL to allow to use a list/tuple/array for vmin.

        It will raise an error in case vmax or vinc are used too.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        sel_func = (
            super().asel
        )  # using super() inside the wrapped function confuses the references

        @allow_pickable_entities(entity="area", plot_function="aplot")
        @allow_iterables_vmin(entity="area")
        def wrapped(self, *args, **kwargs):
            return sel_func(*args, **kwargs)

        return wrapped(self, *args, **kwargs)

    @wraps(_MapdlCore.dim)
    def dim(
        self,
        par="",
        type_="",
        imax="",
        jmax="",
        kmax="",
        var1="",
        var2="",
        var3="",
        csysid="",
        **kwargs,
    ):
        self._check_parameter_name(par)  # parameter name check
        if "(" in par or ")" in par:
            raise ValueError(
                "Parenthesis are not allowed as parameter name in 'mapdl.dim'."
            )

        return super().dim(
            par, type_, imax, jmax, kmax, var1, var2, var3, csysid, **kwargs
        )

    @wraps(_MapdlCore.mpwrite)
    def mpwrite(
        self,
        fname="",
        ext="",
        lib="LIB",
        mat="",
        download_file=False,
        progress_bar=False,
        **kwargs,
    ):
        fname_ = fname + "." + ext
        if not self._local:
            if os.path.dirname(fname_):
                raise IOError(
                    "Only writing files to the MAPDL working directory is allowed. "
                    f"The supplied path {fname_} is not allowed."
                )

        output = super().mpwrite(fname, ext, lib=lib, mat=mat, **kwargs)
        if download_file:
            self.download(os.path.basename(fname_), progress_bar=progress_bar)

        return output

    def mpread(self, fname="", ext="", lib="", **kwargs):
        """APDL Command: MPREAD

        Reads a file containing material properties.

        Parameters
        ----------
        fname
            File name and directory path (248 characters maximum,
            including directory). If you do not specify the ``LIB``
            option, the default directory is the current working
            directory. If you specify the ``LIB`` option, the default is
            the following search path: the current working directory,
            the user's home directory, ``MPLIB_DIR`` (as specified by the
            ``/MPLIB,READ,PATH`` command) and ``/ansys_dir/matlib`` (as
            defined by installation). If you use the default for your
            directory, you can use all 248 characters for the file
            name.

        ext
            Filename extension (eight-character maximum).

        lib
            Reads material library files previously written with the
            MPWRITE command.  (See the description of the ``LIB`` option
            for the ``MPWRITE`` command.)  The only allowed value for ``LIB``
            is ``LIB``.

            .. note:: The argument "LIB" is not supported by the MAPDL gRPC server.

        Notes
        -----
        Material properties written to a file without the ``LIB`` option
        do not support nonlinear properties.  Also, properties written
        to a file without the ``LIB`` option are restored in the same
        material number as originally defined.  To avoid errors, use
        ``MPREAD`` with the ``LIB`` option only when reading files written
        using MPWRITE with the ``LIB`` option.

        If you omit the ``LIB`` option for ``MPREAD``, this command supports
        only linear properties.

        Material numbers are hardcoded.  If you write a material file
        without specifying the ``LIB`` option, then read that file in
        using the ``MPREAD`` command with the ``LIB`` option, the ANSYS
        program will not write the file to a new material number.
        Instead, it will write the file to the "old" material number
        (the number specified on the MPWRITE command that created the
        file.)

        This command is also valid in SOLUTION.
        """
        if lib:
            raise NotImplementedError(
                "The 'lib' argument is not supported by the MAPDL gRPC server."
            )

        fname = self._get_file_name(fname, ext, "mp")
        fname = self._get_file_path(fname, kwargs.get("progress_bar", False))
        file_, ext_, path_ = self._decompose_fname(fname)
        with self.non_interactive:
            # Use not interactive to avoid gRPC issues. See #975
            if self._local:
                # If local, we can use the full path
                super().mpread(fname=path_ / file_, ext=ext_, lib=lib, **kwargs)
            else:
                super().mpread(fname=file_, ext=ext_, lib=lib, **kwargs)

        return self.last_response

    @wraps(_MapdlCore.cwd)
    def cwd(self, *args, **kwargs):
        """Wraps cwd.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        try:
            output = super().cwd(*args, mute=False, **kwargs)
        except MapdlCommandIgnoredError as e:
            raise IncorrectWorkingDirectory(e.args[0])

        self._path = self._wrap_directory(args[0])  # caching
        return output

    @wraps(_MapdlCore.list)
    def list(self, filename, ext=""):
        if hasattr(self, "_local"):  # gRPC
            if not self._local:
                return self._download_as_raw(filename).decode()

        path = pathlib.Path(filename)
        if path.parent != ".":
            path = self.directory / filename

        path = str(path) + ext
        with open(path) as fid:
            return fid.read()

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def kplot(
        self,
        np1="",
        np2="",
        ninc="",
        lab="",
        *,
        graphics_backend=None,
        show_keypoint_numbering=True,
        **kwargs,
    ):
        """Display the selected keypoints.

        APDL Command: KPLOT

        .. note::
            PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
            values set with the ``PNUM`` command.

        Parameters
        ----------
        np1, np2, ninc
            Display keypoints from NP1 to NP2 (defaults to NP1) in
            steps of NINC (defaults to 1).  If NP1 = ALL (default),
            NP2 and NINC are ignored and all selected keypoints [KSEL]
            are displayed.

        lab
            Determines what keypoints are plotted (one of the following):

            (blank) - Plots all keypoints.

            HPT - Plots only those keypoints that are hard points.

        graphics_backend : GraphicsBackend, optional
            Plot the currently selected lines using ``ansys-tools-visualization_interface``.

        show_keypoint_numbering : bool, optional
            Display keypoint numbers when ``graphics_backend=GraphicsBackend.PYVISTA``.



        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.

        Notes
        -----
        This command is valid in any processor.
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if graphics_backend is GraphicsBackend.PYVISTA:
            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            pl = kwargs.get("plotter", None)
            pl = MapdlPlotter().switch_scene(pl)

            kwargs.setdefault("title", "MAPDL Keypoint Plot")
            if not self.geometry.n_keypoint:
                warnings.warn(
                    "Either no keypoints have been "
                    "selected or there are no keypoints in "
                    "the database."
                )
                pl.plot([], [], [], **kwargs)
                return pl.show(**kwargs)

            keypoints = self.geometry.get_keypoints(return_as_array=True)
            points = [{"points": keypoints}]

            labels = []
            if show_keypoint_numbering:
                labels.append(
                    {"points": keypoints, "labels": self.geometry.knum.astype(int)}
                )
            pl.plot([], points, labels, **kwargs)
            return pl.show(**kwargs)

        # otherwise, use the legacy plotter
        if graphics_backend is GraphicsBackend.MAPDL:
            with self._enable_interactive_plotting():
                return super().kplot(np1=np1, np2=np2, ninc=ninc, lab=lab, **kwargs)

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def lplot(
        self,
        nl1="",
        nl2="",
        ninc="",
        *,
        graphics_backend=None,
        show_line_numbering=True,
        show_keypoint_numbering=False,
        color_lines=False,
        **kwargs,
    ):
        """Display the selected lines.

        APDL Command: LPLOT

        .. note::
            PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
            values set with the ``PNUM`` command.

        Parameters
        ----------
        nl1, nl2, ninc
            Display lines from NL1 to NL2 (defaults to NL1) in steps
            of NINC (defaults to 1).  If NL1 = ALL (default), NL2 and
            NINC are ignored and display all selected lines [LSEL].

        graphics_backend : GraphicsBackend, optional
            Plot the currently selected lines using ``ansys-tools-visualization_interface``.

        show_line_numbering : bool, optional
            Display line and keypoint numbers when ``graphics_backend=GraphicsBackend.PYVISTA``.

        show_keypoint_numbering : bool, optional
            Number keypoints.  Only valid when ``show_keypoints=True``

        color_lines : bool, optional
            Color each line with a different color.

        **kwargs
            See :class:`ansys.mapdl.core.plotting.visualizer.MapdlPlotter` for
            more keyword arguments applicable when visualizing with
            ``graphics_backend=GraphicsBackend.PYVISTA``.

        Notes
        -----
        Mesh divisions on plotted lines are controlled by the ``ldiv``
        option of the ``psymb`` command when ``graphics_backend=GraphicsBackend.MAPDL``.
        Otherwise, line divisions are controlled automatically.

        This command is valid in any processor.

        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.

        Examples
        --------
        >>> mapdl.lplot(graphics_backend=GraphicsBackend.PYVISTA, cpos='xy', line_width=10)
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if graphics_backend:
            from ansys.mapdl.core.plotting.theme import get_ansys_colors
            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            kwargs.setdefault("show_scalar_bar", False)
            kwargs.setdefault("title", "MAPDL Line Plot")
            if not self.geometry.n_line:
                warnings.warn(
                    "Either no lines have been selected or there is nothing to plot."
                )
                pl = MapdlPlotter()
                pl.plot([], [], [], **kwargs)
                return pl.show(**kwargs)

            lines = self.geometry.get_lines(return_as_list=True)
            meshes = []

            if color_lines:
                size_ = len(lines)
                # Because this is only going to be used for plotting
                # purposes, we don't need to allocate
                # a huge vector with random numbers (colours).
                # By default `pyvista.DataSetMapper.set_scalars` `n_colors`
                # argument is set to 256, so let do here the same.
                # We will limit the number of randoms values (colours)
                # to 256.
                #
                # Link: https://docs.pyvista.org/api/plotting/_autosummary/pyvista.DataSetMapper.set_scalars.html#pyvista.DataSetMapper.set_scalars
                size_ = min([256, size_])
                # Generating a colour array,
                # Size = number of areas.
                # Values are random between 0 and min(256, number_areas)
                colors = get_ansys_colors(size_)

                # Creating a mapping of colors
                ent_num = []
                for line in lines:
                    ent_num.append(int(np.unique(line["entity_num"])[0]))
                ent_num.sort()

                # expand color array until matching the number of areas.
                # In this case we start to repeat colors in the same order.
                colors = np.resize(colors, (len(ent_num), 4))

                for line, color in zip(lines, colors):
                    meshes.append({"mesh": line, "color": color})

            else:
                for line in lines:
                    meshes.append({"mesh": line, "color": kwargs.get("color", "white")})

            labels = []
            if show_line_numbering:
                for line in lines:
                    labels.append(
                        {
                            "points": line.points[len(line.points) // 2],
                            "labels": line["entity_num"].astype(int),
                        }
                    )

            if show_keypoint_numbering:
                labels.append(
                    {
                        "points": self.geometry.get_keypoints(return_as_array=True),
                        "labels": self.geometry.knum.astype(int),
                    }
                )
            pl = MapdlPlotter()
            pl.plot(meshes, [], labels, **kwargs)
            return pl.show(**kwargs)
        else:
            with self._enable_interactive_plotting():
                return super().lplot(nl1=nl1, nl2=nl2, ninc=ninc, **kwargs)

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def aplot(
        self,
        na1="",
        na2="",
        ninc="",
        degen="",
        scale="",
        *,
        graphics_backend=None,
        quality=4,
        show_area_numbering=False,
        show_line_numbering=False,
        color_areas=False,
        show_lines=False,
        **kwargs,
    ):
        """Display the selected areas.

        Displays the selected areas from ``na1`` to ``na2`` in steps
        of ``ninc``.

        APDL Command: ``APLOT``

        .. note::
            PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
            values set with the ``PNUM`` command.

        Parameters
        ----------
        na1 : int, optional
            Minimum area to display.

        na2 : int, optional
            Maximum area to display.

        ninc : int, optional
            Increment between minimum and maximum area.

        degen, str, optional
            Degeneracy marker.  This option is ignored when ``graphics_backend=GraphicsBackend.PYVISTA``.

        scale : float, optional
            Scale factor for the size of the degeneracy-marker star.
            The scale is the size in window space (-1 to 1 in both
            directions) (defaults to 0.075).  This option is ignored
            when ``graphics_backend != GraphicsBackend.MAPDL``.

        graphics_backend : GraphicsBackend, optional
            Plot the currently selected areas using ``ansys-tools-visualization_interface``.
            As this creates a temporary surface mesh, this may have a
            long execution time for large meshes.

        quality : int, optional
            Quality of the mesh to display.  Varies between 1 (worst)
            to 10 (best) when ``graphics_backend=GraphicsBackend.PYVISTA``.

        show_area_numbering : bool, optional
            Display area numbers when ``graphics_backend=GraphicsBackend.PYVISTA``.

        show_line_numbering : bool, optional
            Display line numbers when ``graphics_backend=GraphicsBackend.PYVISTA``.

        color_areas : Union[bool, str, np.array], optional
            Only used when ``graphics_backend=GraphicsBackend.PYVISTA``.
            If ``color_areas`` is a bool, randomly color areas when ``True``.
            If ``color_areas`` is a string, it must be a valid color string
            which will be applied to all areas.
            If ``color_areas`` is an array or list made of color names (str) or
            the RGBa numbers ([R, G, B, transparency]), it colors each area with
            the colors, specified in that array or list.

        show_lines : bool, optional
            Plot lines and areas.  Change the thickness of the lines
            with ``line_width=``

        **kwargs
            See :class:`ansys.mapdl.core.plotting.visualizer.MapdlPlotter` for
            more keyword arguments applicable when visualizing with
            ``graphics_backend=GraphicsBackend.PYVISTA``.

        Examples
        --------
        Plot areas between 1 and 4 in increments of 2.

        >>> mapdl.block(0, 1, 0, 1, 0, 1)
        >>> mapdl.aplot(1, 4, 2)

        Plot all areas and randomly color the areas.  Label center of
        areas by their number.

        >>> mapdl.aplot(show_area_numbering=True, color_areas=True)

        Return the plotting instance and modify it.

        >>> mapdl.aplot()
        >>> pl = mapdl.aplot(return_plotter=True)
        >>> pl.show_bounds()
        >>> pl.set_background('black')
        >>> pl.add_text('my text')
        >>> pl.show()

        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if graphics_backend:
            from matplotlib.colors import to_rgba

            from ansys.mapdl.core.plotting.theme import get_ansys_colors
            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            kwargs.setdefault("show_scalar_bar", False)
            kwargs.setdefault("title", "MAPDL Area Plot")
            kwargs.setdefault("scalar_bar_args", {"title": "Scalar Bar Title"})

            if not self.geometry.n_area:
                warnings.warn(
                    "Either no areas have been selected or there is nothing to plot."
                )
                pl = MapdlPlotter()
                pl.plot([], [], [], **kwargs)
                return pl.show(**kwargs)

            surfs = self.geometry.get_areas(return_as_list=True, quality=quality)
            meshes = []
            labels = []

            # anums = np.unique(surf["entity_num"])
            anums = self.geometry.anum  # This might need double check

            # individual surface isolation is quite slow, so just
            # color individual areas
            if (isinstance(color_areas, np.ndarray) and len(color_areas) > 1) or (
                not isinstance(color_areas, np.ndarray) and color_areas
            ):
                if isinstance(color_areas, bool):
                    size_ = len(anums)
                    # Because this is only going to be used for plotting
                    # purposes, we don't need to allocate
                    # a huge vector with random numbers (colours).
                    # By default `pyvista.DataSetMapper.set_scalars` `n_colors`
                    # argument is set to 256, so let do here the same.
                    # We will limit the number of randoms values (colours)
                    # to 256.
                    #
                    # Link: https://docs.pyvista.org/api/plotting/_autosummary/pyvista.DataSetMapper.set_scalars.html#pyvista.DataSetMapper.set_scalars
                    size_ = min([256, size_])
                    # Generating a colour array,
                    # Size = number of areas.
                    # Values are random between 0 and min(256, number_areas)
                    colors = get_ansys_colors(size_)

                elif isinstance(color_areas, str):
                    # A color is provided as a string
                    colors = np.atleast_2d(to_rgba(color_areas))

                else:
                    if len(anums) != len(color_areas):
                        raise ValueError(
                            "The length of the parameter array 'color_areas' "
                            "should be the same as the number of areas."
                            f"\nanums: {anums}"
                            f"\ncolor_areas: {color_areas}"
                        )

                    if isinstance(color_areas[0], str):
                        colors = [to_rgba(each) for each in color_areas]
                    else:
                        colors = color_areas

                # Creating a mapping of colors
                ent_num = []
                for each_surf in surfs:
                    ent_num.append(int(np.unique(each_surf["entity_num"])[0]))
                ent_num.sort()

                # expand color array until matching the number of areas.
                # In this case we start to repeat colors in the same order.
                colors = np.resize(colors, (len(ent_num), 3))

                for surf, color in zip(surfs, colors):
                    meshes.append({"mesh": surf, "color": color})

            else:
                for surf in surfs:
                    meshes.append({"mesh": surf, "color": kwargs.get("color", "white")})

            if show_area_numbering:
                centers = []

                for surf in surfs:
                    anum = np.unique(surf["entity_num"])
                    if len(anum) != 1:
                        raise RuntimeError(
                            f"The pv.Unstructured from the entity {anum[0]} contains entities"
                            f"from other entities {anum}"  # Sanity check
                        )

                    area = surf.extract_cells(surf["entity_num"] == anum)
                    centers.append(area.center)

                labels.append(
                    {"points": np.array(centers), "labels": anums.astype(int)}
                )

            if show_lines or show_line_numbering:
                kwargs.setdefault("line_width", 2)
                # subselect lines belonging to the current areas

                with self.save_selection:
                    self.lsla("S", mute=True)
                    lines = self.geometry.get_lines()

                if show_lines:
                    meshes.append(
                        {"mesh": lines, "color": kwargs.get("edge_color", "k")}
                    )
                if show_line_numbering:
                    labels.append(
                        {
                            "points": lines.points[50::101],
                            "labels": lines["entity_num"].astype(int),
                        }
                    )
            pl = MapdlPlotter()
            pl.plot(meshes, [], labels, **kwargs)
            return pl.show(**kwargs)
        if graphics_backend is GraphicsBackend.MAPDL:
            with self._enable_interactive_plotting():
                return super().aplot(
                    na1=na1, na2=na2, ninc=ninc, degen=degen, scale=scale, **kwargs
                )

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def vplot(
        self,
        nv1="",
        nv2="",
        ninc="",
        degen="",
        scale="",
        *,
        graphics_backend=None,
        quality=4,
        show_volume_numbering=False,
        show_area_numbering=False,
        show_line_numbering=False,
        color_areas=False,
        show_lines=True,
        **kwargs,
    ):
        """Plot the selected volumes.

        APDL Command: VPLOT

        .. note::
            PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
            values set with the ``PNUM`` command.

        Parameters
        ----------
        nv1, nv2, ninc
            Display volumes from NV1 to NV2 (defaults to NV1) in steps
            of NINC (defaults to 1).  If NV1 = ALL (default), NV2 and
            NINC are ignored and all selected volumes [VSEL] are
            displayed.  Ignored when ``graphics_backend=GraphicsBackend.PYVISTA``.

        degen
            Degeneracy marker.  ``"blank"`` No degeneracy marker is
            used (default), or ``"DEGE"``.  A red star is placed on
            keypoints at degeneracies (see the Modeling and Meshing
            Guide).  Not available if /FACET,WIRE is set.  Ignored
            when ``graphics_backend=GraphicsBackend.PYVISTA``.

        scale
            Scale factor for the size of the degeneracy-marker star.  The scale
            is the size in window space (-1 to 1 in both directions) (defaults
            to .075).  Ignored when ``graphics_backend=GraphicsBackend.PYVISTA``.

        graphics_backend : GraphicsBackend, optional
            Plot the currently selected volumes using ``ansys-tools-visualization_interface``.
            As this creates a temporary surface mesh, this may have a
            long execution time for large meshes.

        quality : int, optional
            quality of the mesh to display.  Varies between 1 (worst)
            to 10 (best).  Applicable when ``graphics_backend=GraphicsBackend.PYVISTA``.

        show_numbering : bool, optional
            Display line and keypoint numbers when ``graphics_backend=GraphicsBackend.PYVISTA``.

        **kwargs
            See :class:`ansys.mapdl.core.plotting.visualizer.MapdlPlotter` for
            more keyword arguments applicable when visualizing with
            ``graphics_backend=GraphicsBackend.PYVISTA``.

        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.

        Examples
        --------
        Plot while displaying area numbers.

        >>> mapdl.vplot(show_area_numbering=True)
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if graphics_backend is GraphicsBackend.PYVISTA:
            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            pl = kwargs.get("plotter", None)
            pl = MapdlPlotter().switch_scene(pl)

            kwargs.setdefault("title", "MAPDL Volume Plot")
            if not self.geometry.n_volu:
                warnings.warn(
                    "Either no volumes have been selected or there is nothing to plot."
                )
                pl = MapdlPlotter()
                pl.plot([], [], [], **kwargs)
                return pl.show(**kwargs)

            # Storing entities selection
            with self.save_selection:
                volumes = self.geometry.vnum
                meshes = []
                points = []
                labels = []

                return_plotter = kwargs.pop("return_plotter", False)
                color_areas = True

                for each_volu in volumes:
                    self.vsel("S", vmin=each_volu)
                    self.aslv("S", mute=True)  # select areas attached to active volumes

                    pl_aplot = self.aplot(
                        graphics_backend=GraphicsBackend.PYVISTA,
                        color_areas=color_areas,
                        quality=quality,
                        show_area_numbering=show_area_numbering,
                        show_line_numbering=show_line_numbering,
                        show_lines=show_lines,
                        return_plotter=True,
                        **kwargs,
                    )

                    meshes_ = pl_aplot.get_meshes_from_plotter()

                    for each_mesh in meshes_:
                        each_mesh.cell_data["entity_num"] = int(each_volu)

                    meshes.extend(meshes_)

                meshes = [{"mesh": meshes}]

            pl.plot(meshes, points, labels, **kwargs)
            return pl.show(return_plotter=return_plotter, **kwargs)

        elif graphics_backend is GraphicsBackend.MAPDL:
            with self._enable_interactive_plotting():
                return super().vplot(
                    nv1=nv1, nv2=nv2, ninc=ninc, degen=degen, scale=scale, **kwargs
                )
        else:
            raise ValueError(f"Invalid graphics backend: {graphics_backend}. ")

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def nplot(self, nnum="", *, graphics_backend=None, **kwargs):
        """APDL Command: NPLOT

        Displays nodes.

        .. note::
           PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
           values set with the ``PNUM`` command.

        Parameters
        ----------
        nnum : bool, int, optional
            Node number key:

            - ``False`` : No node numbers on display (default).
            - ``True`` : Include node numbers on display.

            .. note::
               This parameter is only valid when ``graphics_backend==GraphicsBackend.PYVISTA``

        graphics_backend : GraphicsBackend, optional
            Plot the currently selected nodes using an specific backend.
            Defaults to current ``graphics_backend`` setting as set on the
            initialization of MAPDL.

        plot_bc : bool, optional
            Activate the plotting of the boundary conditions.
            Defaults to ``False``.

            .. warning:: This is in alpha state.

        plot_bc_legend : bool, optional
            Shows the boundary conditions legend.
            Defaults to ``False``

        plot_bc_labels : bool, optional
            Shows the boundary conditions label per node.
            Defaults to ``False``.

        bc_labels : List[str], Tuple(str), optional
            List or tuple of strings with the boundary conditions
            to plot, i.e. ``["UX", "UZ"]``.
            You can obtain the allowed boundary conditions by
            evaluating ``ansys.mapdl.core.plotting.BCS``.
            You can use also the following shortcuts:

            * **'mechanical'**
              To plot the following mechanical boundary conditions: ``'UX'``,
              ``'UY'``, ``'UZ'``, ``'FX'``, ``'FY'``, and ``'FZ'``.  Rotational
              or momentum boundary conditions are not allowed.

            * ``'thermal'``
              To plot the following boundary conditions: 'TEMP' and
              'HEAT'.

            * ``'electrical'``
              To plot the following electrical boundary conditions:
              ``'VOLT'``, ``'CHRGS'``, and ``'AMPS'``.

            Defaults to all the allowed boundary conditions present
            in the responses of :func:`ansys.mapdl.core.Mapdl.dlist`
            and :func:`ansys.mapdl.core.Mapdl.flist()`.

        bc_target : List[str], Tuple(str), optional
            Specify the boundary conditions target
            to plot, i.e. "Nodes", "Elements".
            You can obtain the allowed boundary conditions target by
            evaluating ``ansys.mapdl.core.plotting.ALLOWED_TARGETS``.
            Defaults to only ``"Nodes"``.

        bc_glyph_size : float, optional
            Specify the size of the glyph used for the boundary
            conditions plotting.
            By default is ratio of the bounding box dimensions.

        bc_labels_font_size : float, optional
            Size of the text on the boundary conditions labels.
            By default it is 16.

        Examples
        --------
        Plot using VTK while showing labels and changing the background.

        >>> mapdl.prep7()
        >>> mapdl.n(1, 0, 0, 0)
        >>> mapdl.n(11, 10, 0, 0)
        >>> mapdl.fill(1, 11, 9)
        >>> mapdl.nplot(
        ...     nnum=True,
        ...     graphics_backend=GraphicsBackend.PYVISTA,
        ...     background='w',
        ...     color='k',
        ...     show_bounds=True
        ... )

        Plot without using VTK.

        >>> mapdl.prep7()
        >>> mapdl.n(1, 0, 0, 0)
        >>> mapdl.n(11, 10, 0, 0)
        >>> mapdl.fill(1, 11, 9)
        >>> mapdl.nplot(graphics_backend=GraphicsBackend.MAPDL)

        Plot nodal boundary conditions.

        >>> mapdl.nplot(
        ...     plot_bc=True,
        ...     plot_bc_labels=True,
        ...     bc_labels="mechanical",
        ... )

        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if "knum" in kwargs:
            raise ValueError("`knum` keyword deprecated.  Please use `nnum` instead.")

        if graphics_backend is GraphicsBackend.PYVISTA:
            import pyvista as pv

            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            pl = kwargs.get("plotter", None)
            pl = MapdlPlotter().switch_scene(pl)

            kwargs.setdefault("title", "MAPDL Node Plot")
            if not self.mesh.n_node:
                warnings.warn("There are no nodes to plot.")
                pl.plot([], [], [], **kwargs)
                return pl.show(**kwargs)

            labels = []
            if nnum:
                # must eliminate duplicate points or labeling fails miserably.
                pcloud = pv.PolyData(self.mesh.nodes)
                pcloud["labels"] = self.mesh.nnum
                pcloud.clean(inplace=True)

                labels = [
                    {"points": pcloud.points, "labels": pcloud["labels"].astype(int)}
                ]
            points = [{"points": self.mesh.nodes}]
            pl.plot([], points, labels, mapdl=self, **kwargs)
            return pl.show(**kwargs)

        elif graphics_backend is GraphicsBackend.MAPDL:
            # otherwise, use the built-in nplot
            if isinstance(nnum, bool):
                nnum = int(nnum)

            with self._enable_interactive_plotting():
                return super().nplot(nnum, **kwargs)
        else:
            raise ValueError(f"Invalid graphics backend: {graphics_backend}. ")

    @check_deprecated_vtk_kwargs
    @requires_graphics
    def eplot(self, show_node_numbering=False, *, graphics_backend=None, **kwargs):
        """Plots the currently selected elements.

        APDL Command: EPLOT

        .. note::
            PyMAPDL plotting commands with ``graphics_backend=GraphicsBackend.PYVISTA`` ignore any
            values set with the ``PNUM`` command.

        Parameters
        ----------
        graphics_backend : GraphicsBackend, optional
            Plot the currently selected elements using the picked backend.
            Defaults to current ``graphics_backend`` setting.

        show_node_numbering : bool, optional
            Plot the node numbers of surface nodes.

        plot_bc : bool, optional
            Activate the plotting of the boundary conditions.
            Defaults to ``False``.

            .. warning:: This is in alpha state.

        plot_bc_legend : bool, optional
            Shows the boundary conditions legend.
            Defaults to ``False``

        plot_bc_labels : bool, optional
            Shows the boundary conditions label per node.
            Defaults to ``False``.

        bc_labels : List[str], Tuple(str), optional
            List or tuple of strings with the boundary conditions
            to plot, i.e. ``["UX", "UZ"]``.
            You can obtain the allowed boundary conditions by
            evaluating ``ansys.mapdl.core.plotting.BCS``.
            You can use also the following shortcuts:

            * **'mechanical'**
              To plot the following mechanical boundary conditions: ``'UX'``,
              ``'UY'``, ``'UZ'``, ``'FX'``, ``'FY'``, and ``'FZ'``.  Rotational
              or momentum boundary conditions are not allowed.

            * ``'thermal'``
              To plot the following boundary conditions: 'TEMP' and
              'HEAT'.

            * ``'electrical'``
              To plot the following electrical boundary conditions:
              ``'VOLT'``, ``'CHRGS'``, and ``'AMPS'``.

            Defaults to all the allowed boundary conditions present
            in the responses of :func:`ansys.mapdl.core.Mapdl.dlist`
            and :func:`ansys.mapdl.core.Mapdl.flist()`.

        bc_target : List[str], Tuple(str), optional
            Specify the boundary conditions target
            to plot, i.e. "Nodes", "Elements".
            You can obtain the allowed boundary conditions target by
            evaluating ``ansys.mapdl.core.plotting.ALLOWED_TARGETS``.
            Defaults to only ``"Nodes"``.

        bc_glyph_size : float, optional
            Specify the size of the glyph used for the boundary
            conditions plotting.
            By default is ratio of the bounding box dimensions.

        bc_labels_font_size : float, optional
            Size of the text on the boundary conditions labels.
            By default it is 16.

        **kwargs
            See ``help(ansys.mapdl.core.plotting.visualizer.MapdlPlotter)`` for more
            keyword arguments related to visualizing using ``graphics_backend``.

        Examples
        --------
        >>> mapdl.clear()
        >>> mapdl.prep7()
        >>> mapdl.block(0, 1, 0, 1, 0, 1)
        >>> mapdl.et(1, 186)
        >>> mapdl.esize(0.1)
        >>> mapdl.vmesh('ALL')
        >>> mapdl.vgen(2, 'all')
        >>> mapdl.eplot(show_edges=True, smooth_shading=True,
                        show_node_numbering=True)

        Save a screenshot to disk without showing the plot

        >>> mapdl.eplot(background='w', show_edges=True, smooth_shading=True,
                        window_size=[1920, 1080], savefig='screenshot.png',
                        off_screen=True)

        Returns
        -------
        object
            Plot display object when using PyVista graphics backend, None otherwise.
        """
        if graphics_backend is None:
            graphics_backend = self._graphics_backend

        if graphics_backend is GraphicsBackend.PYVISTA:
            from ansys.mapdl.core.plotting.visualizer import MapdlPlotter

            pl = kwargs.get("plotter", None)
            pl = MapdlPlotter().switch_scene(pl)
            pl.mapdl = self

            kwargs.setdefault("title", "MAPDL Element Plot")
            if not self._mesh.n_elem:
                warnings.warn("There are no elements to plot.")
                pl.plot([], [], [], mapdl=self, **kwargs)
                return pl.show(**kwargs)

            # TODO: Consider caching the surface
            esurf = self.mesh._grid.linear_copy().extract_surface().clean()
            kwargs.setdefault("show_edges", True)

            # if show_node_numbering:
            labels = []
            if show_node_numbering:
                labels = [
                    {
                        "points": esurf.points,
                        "labels": esurf["ansys_node_num"].astype(int),
                    }
                ]

            pl.plot(
                [{"mesh": esurf, "style": kwargs.pop("style", "surface")}],
                [],
                labels,
                mapdl=self,
                **kwargs,
            )
            return pl.show(**kwargs)
        elif graphics_backend is GraphicsBackend.MAPDL:
            # otherwise, use MAPDL plotter
            with self._enable_interactive_plotting():
                return self.run("EPLOT", **kwargs)

    @wraps(_MapdlCore.clear)
    def clear(self, read: str = "NOSTART", **kwargs):
        """Wraps the MAPDL ``CLEAR`` command to use `NOSTART` with mute=True"""
        if self.is_grpc:
            self._create_session()
        kwargs.setdefault("mute", True)
        super().clear(read=read, **kwargs)

    @wraps(_MapdlCore.cmplot)
    def cmplot(self, label: str = "", entity: str = "", keyword: str = "", **kwargs):
        """Wraps cmplot"""

        label = label.upper()
        entity = entity.upper()

        if label in ["N", "P"]:
            raise ValueError(f"The label '{label}' is not supported.")

        if (not label or label == "ALL") and not entity:
            raise ValueError(
                "If not using label or label =='ALL', then you "
                "need to provide a valid entity."
            )

        if label != "ALL":
            if label not in self.components:
                raise ComponentDoesNotExits(f"The component '{label}' does not exist.")

            if not entity:
                entity = self.components[label].type
            else:
                entity_ = self.components[label].type
                if entity_.upper() != entity.upper():
                    raise ValueError(
                        f"The component entity supplied '{entity}' "
                        "does not seems to match the component "
                        f"type '{entity_}' with name '{label}' "
                        "in MAPDL."
                    )

        if label and not entity:
            # supposing entity
            entity = self.components[label].type

        if entity[:4] not in ["NODE", "ELEM", "KP", "LINE", "AREA", "VOLU"]:
            raise ValueError(f"The entity '{entity}' is not allowed.")

        cmps_names = self.components.names
        self.cm("__tmp_cm__", entity=entity)
        if label == "ALL":
            self.cmsel("ALL", entity=entity)
        else:
            self.cmsel("S", name=label, entity=entity)

        mapping = {
            "NODE": self.nplot,
            "ELEM": self.eplot,
            "KP": self.kplot,
            "LINE": self.lplot,
            "AREA": self.aplot,
            "VOLU": self.vplot,
        }
        func = mapping[entity]

        kwargs.setdefault("title", "PyMAPDL CMPLOT")
        output = func(**kwargs)

        # returning to previous selection
        self.cmsel("s", "__tmp_cm__", entity=entity)
        self.components.select(cmps_names)
        return output

    @wraps(_MapdlCore.inquire)
    def inquire(self, strarray="", func="", arg1="", arg2="", **kwargs):
        """Wraps original INQUIRE function

        Returns
        -------
        float or bool or str
            The inquired value. Type depends on the inquiry function used.
        """
        func_options = [
            "LOGIN",
            "DOCU",
            "APDL",
            "PROG",
            "AUTH",
            "USER",
            "DIRECTORY",
            "JOBNAME",
            "RSTDIR",
            "RSTFILE",
            "RSTEXT",
            "OUTPUT",
            "ENV",
            "TITLE",
            "EXIST",
            "DATE",
            "SIZE",
            "WRITE",
            "READ",
            "EXEC",
            "LINES",
        ]

        if strarray.upper() in func_options and func.upper() not in func_options:
            # Likely you are using the old ``_Mapdl.inquire`` implementation.
            raise ValueError(
                "Arguments of this method have changed. `Mapdl.inquire` now includes the optional `strarray` parameter "
                f"as the first argument. Either use `inquire(func={strarray})`, or `inquire("
                ", {strarray})`"
            )

        if func == "":
            func = "DIRECTORY"

        if strarray.upper() not in func_options and func.upper() not in func_options:
            raise ValueError(
                f"The arguments (strarray='{strarray}', func='{func}') are not valid."
            )

        response = ""
        n_try = 3
        i_try = 0
        while i_try < n_try and not response:
            response = self.run(
                f"/INQUIRE,{strarray},{func},{arg1},{arg2}", mute=False, **kwargs
            )
            i_try += 1

        if not response:
            if not self._store_commands:
                raise MapdlRuntimeError("/INQUIRE command didn't return a response.")
            else:
                # Exit since we are in non-interactive mode
                return None

        if func.upper() in [
            "ENV",
            "TITLE",
        ]:  # the output is multiline, we just need the last line.
            response = response.splitlines()[-1]

        response = response.split("=")[1].strip()

        if len(response) >= 248:
            warnings.warn(
                "Response might have been truncated to 248 characters because of "
                "MAPDL string limitations. "
                "Check the output of 'mapdl.inquire' carefully. "
                "Alternatively, you can use 'mapdl.sys('printenv') to obtain "
                "the environment variables on Linux."
            )

        # Check if the function is to check existence
        # so it makes sense to return a boolean
        if func.upper() in ["EXIST", "WRITE", "READ", "EXEC"]:
            if "1.0" in response:
                return True
            elif "0.0" in response:
                return False
            else:
                raise MapdlRuntimeError(
                    f"Unexpected output from 'mapdl.inquire' function:\n{response}"
                )

        if func.upper() in [
            "LOGIN",
            "DOCU",
            "APDL",
            "PROG",
            "AUTH",
            "USER",
            "DIRECTORY",
            "JOBNAME",
            "RSTDIR",
            "RSTFILE",
            "RSTEXT",
            "OUTPUT",
            "ENV",
            "TITLE",
            "DATE",
        ]:
            return response

        try:
            return float(response)
        except ValueError:
            return response

    @wraps(_MapdlCore.parres)
    def parres(self, lab="", fname="", ext="", **kwargs):
        """Wraps the original /PARRES function"""
        if not fname:
            fname = self.jobname

        fname = self._get_file_name(
            fname=fname, ext=ext, default_extension="parm"
        )  # Although documentation says `PARM`

        # Getting the path for local/remote
        filename = self._get_file_path(fname, progress_bar=False)

        return self.input(filename)

    @wraps(_MapdlCore.lgwrite)
    def lgwrite(self, fname="", ext="", kedit="", remove_grpc_extra=True, **kwargs):
        """Wraps original /LGWRITE"""
        if not fname:
            fname = self.jobname

        fname = self._get_file_name(fname=fname, ext=ext, default_extension="lgw")

        if self.is_local:
            fname_ = fname
        else:
            file_, ext_, _ = self._decompose_fname(fname)
            fname_ = self._get_file_name(fname=file_, ext=ext_)

        # generate the log and download if necessary
        output = super().lgwrite(fname=fname_, ext="", kedit=kedit, **kwargs)

        # Let's download the file to the location
        self._download(fname_, fname)
        fname_ = fname  # Update path

        # remove extra grpc /OUT commands
        REMOVE_LINES = ("/OUT", "/OUT,anstmp")
        REMOVE_LINES_STARTING = (
            "*SET,__PYMAPDL_SESSION_ID__",
            "! *STATUS,__PYMAPDL_SESSION_ID__",
            "*STATUS,__PYMAPDL_SESSION_ID__",
        )

        if remove_grpc_extra and self.is_grpc:
            with open(fname_, "r") as fid:
                lines = [
                    line.strip() + "\n"
                    for line in fid
                    if (
                        line.strip() not in REMOVE_LINES
                        and not line.startswith(REMOVE_LINES_STARTING)
                    )
                ]

            with open(fname_, "w") as fid:
                fid.writelines(lines)

        return output

    @wraps(_MapdlCore.vwrite)
    def vwrite(
        self,
        par1="",
        par2="",
        par3="",
        par4="",
        par5="",
        par6="",
        par7="",
        par8="",
        par9="",
        par10="",
        par11="",
        par12="",
        par13="",
        par14="",
        par15="",
        par16="",
        par17="",
        par18="",
        par19="",
        **kwargs,
    ):
        """Wrapping *VWRITE"""

        # cannot be run in interactive mode
        if not self._store_commands:
            raise MapdlRuntimeError(
                "*VWRITE cannot run interactively.  \n\nPlease use "
                "``with mapdl.non_interactive:``"
            )

        return super().vwrite(
            par1=par1,
            par2=par2,
            par3=par3,
            par4=par4,
            par5=par5,
            par6=par6,
            par7=par7,
            par8=par8,
            par9=par9,
            par10=par10,
            par11=par11,
            par12=par12,
            par13=par13,
            par14=par14,
            par15=par15,
            par16=par16,
            par17=par17,
            par18=par18,
            par19=par19,
            **kwargs,
        )

    @wraps(_MapdlCore.mwrite)
    def mwrite(
        self, parr="", fname="", ext="", label="", n1="", n2="", n3="", **kwargs
    ):
        """Wrapping *MWRITE"""

        # cannot be run in interactive mode
        if not self._store_commands:
            raise MapdlRuntimeError(
                "*MWRITE cannot run interactively.  \n\nPlease use "
                "``with mapdl.non_interactive:``"
            )

        return super().mwrite(
            parr=parr,
            fname=fname,
            ext=ext,
            label=label,
            n1=n1,
            n2=n2,
            n3=n3,
            **kwargs,
        )

    @wraps(_MapdlCore.nrm)
    def nrm(self, name="", normtype="", parr="", normalize="", **kwargs):
        """Wraps *NRM"""
        if not parr:
            parr = "__temp_par__"
        super().nrm(
            name=name, normtype=normtype, parr=parr, normalize=normalize, **kwargs
        )
        return self.parameters[parr]

    @wraps(_MapdlCore.com)
    def com(self, comment="", **kwargs):
        """Wraps /COM"""
        if self.print_com and not self.mute and not kwargs.get("mute", False):
            print("/COM,%s" % (str(comment)))

        return super().com(comment=comment, **kwargs)

    @wraps(_MapdlCore.lssolve)
    def lssolve(self, lsmin="", lsmax="", lsinc="", **kwargs):
        """Wraps LSSOLVE"""
        with self.non_interactive:
            super().lssolve(lsmin=lsmin, lsmax=lsmax, lsinc=lsinc, **kwargs)
        return self.last_response

    @wraps(_MapdlCore.edasmp)
    def edasmp(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edasmp()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edasmp(*args, **kwargs)

    @wraps(_MapdlCore.edbound)
    def edbound(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edbound()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edbound(*args, **kwargs)

    @wraps(_MapdlCore.edbx)
    def edbx(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edbx()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edbx(*args, **kwargs)

    @wraps(_MapdlCore.edcgen)
    def edcgen(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcgen()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcgen(*args, **kwargs)

    @wraps(_MapdlCore.edclist)
    def edclist(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edclist()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edclist(*args, **kwargs)

    @wraps(_MapdlCore.edcmore)
    def edcmore(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcmore()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcmore(*args, **kwargs)

    @wraps(_MapdlCore.edcnstr)
    def edcnstr(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcnstr()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcnstr(*args, **kwargs)

    @wraps(_MapdlCore.edcontact)
    def edcontact(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcontact()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcontact(*args, **kwargs)

    @wraps(_MapdlCore.edcrb)
    def edcrb(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcrb()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcrb(*args, **kwargs)

    @wraps(_MapdlCore.edcurve)
    def edcurve(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcurve()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcurve(*args, **kwargs)

    @wraps(_MapdlCore.eddbl)
    def eddbl(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.eddbl()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().eddbl(*args, **kwargs)

    @wraps(_MapdlCore.eddc)
    def eddc(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.eddc()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().eddc(*args, **kwargs)

    @wraps(_MapdlCore.edipart)
    def edipart(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edipart()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edipart(*args, **kwargs)

    @wraps(_MapdlCore.edlcs)
    def edlcs(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edlcs()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edlcs(*args, **kwargs)

    @wraps(_MapdlCore.edmp)
    def edmp(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edmp()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edmp(*args, **kwargs)

    @wraps(_MapdlCore.ednb)
    def ednb(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.ednb()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().ednb(*args, **kwargs)

    @wraps(_MapdlCore.edndtsd)
    def edndtsd(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edndtsd()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edndtsd(*args, **kwargs)

    @wraps(_MapdlCore.ednrot)
    def ednrot(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.ednrot()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().ednrot(*args, **kwargs)

    @wraps(_MapdlCore.edpart)
    def edpart(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edpart()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edpart(*args, **kwargs)

    @wraps(_MapdlCore.edpc)
    def edpc(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edpc()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edpc(*args, **kwargs)

    @wraps(_MapdlCore.edsp)
    def edsp(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edsp()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edsp(*args, **kwargs)

    @wraps(_MapdlCore.edweld)
    def edweld(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edweld()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edweld(*args, **kwargs)

    @wraps(_MapdlCore.edadapt)
    def edadapt(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edadapt()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edadapt(*args, **kwargs)

    @wraps(_MapdlCore.edale)
    def edale(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edale()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edale(*args, **kwargs)

    @wraps(_MapdlCore.edbvis)
    def edbvis(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edbvis()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edbvis(*args, **kwargs)

    @wraps(_MapdlCore.edcadapt)
    def edcadapt(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcadapt()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcadapt(*args, **kwargs)

    @wraps(_MapdlCore.edcpu)
    def edcpu(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcpu()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcpu(*args, **kwargs)

    @wraps(_MapdlCore.edcsc)
    def edcsc(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcsc()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcsc(*args, **kwargs)

    @wraps(_MapdlCore.edcts)
    def edcts(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edcts()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edcts(*args, **kwargs)

    @wraps(_MapdlCore.eddamp)
    def eddamp(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.eddamp()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().eddamp(*args, **kwargs)

    @wraps(_MapdlCore.eddrelax)
    def eddrelax(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.eddrelax()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().eddrelax(*args, **kwargs)

    @wraps(_MapdlCore.eddump)
    def eddump(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.eddump()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().eddump(*args, **kwargs)

    @wraps(_MapdlCore.edenergy)
    def edenergy(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edenergy()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edenergy(*args, **kwargs)

    @wraps(_MapdlCore.edfplot)
    def edfplot(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edfplot()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edfplot(*args, **kwargs)

    @wraps(_MapdlCore.edgcale)
    def edgcale(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edgcale()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edgcale(*args, **kwargs)

    @wraps(_MapdlCore.edhgls)
    def edhgls(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edhgls()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edhgls(*args, **kwargs)

    @wraps(_MapdlCore.edhist)
    def edhist(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edhist()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edhist(*args, **kwargs)

    @wraps(_MapdlCore.edhtime)
    def edhtime(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edhtime()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edhtime(*args, **kwargs)

    @wraps(_MapdlCore.edint)
    def edint(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edint()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edint(*args, **kwargs)

    @wraps(_MapdlCore.edis)
    def edis(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edis()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edis(*args, **kwargs)

    @wraps(_MapdlCore.edload)
    def edload(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edload()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edload(*args, **kwargs)

    @wraps(_MapdlCore.edopt)
    def edopt(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edopt()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edopt(*args, **kwargs)

    @wraps(_MapdlCore.edout)
    def edout(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edout()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edout(*args, **kwargs)

    @wraps(_MapdlCore.edpl)
    def edpl(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edpl()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edpl(*args, **kwargs)

    @wraps(_MapdlCore.edpvel)
    def edpvel(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edpvel()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edpvel(*args, **kwargs)

    @wraps(_MapdlCore.edrc)
    def edrc(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edrc()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edrc(*args, **kwargs)

    @wraps(_MapdlCore.edrd)
    def edrd(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edrd()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edrd(*args, **kwargs)

    @wraps(_MapdlCore.edri)
    def edri(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edri()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edri(*args, **kwargs)

    @wraps(_MapdlCore.edrst)
    def edrst(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edrst()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edrst(*args, **kwargs)

    @wraps(_MapdlCore.edrun)
    def edrun(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edrun()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edrun(*args, **kwargs)

    @wraps(_MapdlCore.edshell)
    def edshell(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edshell()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edshell(*args, **kwargs)

    @wraps(_MapdlCore.edsolv)
    def edsolv(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edsolv()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edsolv(*args, **kwargs)

    @wraps(_MapdlCore.edstart)
    def edstart(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edstart()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edstart(*args, **kwargs)

    @wraps(_MapdlCore.edterm)
    def edterm(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edterm()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edterm(*args, **kwargs)

    @wraps(_MapdlCore.edtp)
    def edtp(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edtp()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edtp(*args, **kwargs)

    @wraps(_MapdlCore.edvel)
    def edvel(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edvel()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edvel(*args, **kwargs)

    @wraps(_MapdlCore.edwrite)
    def edwrite(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.edwrite()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().edwrite(*args, **kwargs)

    @wraps(_MapdlCore.rexport)
    def rexport(self, *args, **kwargs):
        if self.version >= 19.1:
            raise CommandDeprecated(
                "The command 'Mapdl.rexport()' for explicit analysis was deprecated in Ansys 19.1"
            )
        super().rexport(*args, **kwargs)

    @wraps(_MapdlCore.get)
    def get(
        self,
        par: str = "__floatparameter__",
        entity: str = "",
        entnum: str = "",
        item1: str = "",
        it1num: MapdlFloat = "",
        item2: str = "",
        it2num: MapdlFloat = "",
        item3: MapdlFloat = "",
        it3num: MapdlFloat = "",
        item4: MapdlFloat = "",
        it4num: MapdlFloat = "",
        **kwargs: KwargDict,
    ) -> Union[float, str]:
        self._check_parameter_name(par)

        command = f"*GET,{par},{entity},{entnum},{item1},{it1num},{item2},{it2num},{item3},{it3num},{item4},{it4num}"

        response = self.run(command, **kwargs)

        if not response:
            # If no response is received, re-run the command with force_output to ensure output is captured.
            with self.force_output:
                response = self.run(command, **kwargs)

        if self._store_commands:
            # Return early in non_interactive
            return

        value = response.split("=")[-1].strip()
        if item3:
            if len(value.splitlines()) > 1:
                self._log.info(
                    f"The command '{command}' is showing the next message: '{value.splitlines()[1].strip()}'"
                )
            value = value.splitlines()[0]

        try:  # always either a float or string
            return float(value)
        except ValueError:
            return value

    @wraps(_MapdlCore.cmlist)
    def cmlist(self, *args, **kwargs):
        from ansys.mapdl.core.commands import ComponentListing

        return ComponentListing(super().cmlist(*args, **kwargs))

    @wraps(_MapdlCore.ndinqr)
    def ndinqr(self, node, key, **kwargs):
        """Wrap the ``ndinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().ndinqr(node, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.elmiqr)
    def elmiqr(self, ielem, key, **kwargs):
        """Wrap the ``elmiqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().elmiqr(ielem, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.kpinqr)
    def kpinqr(self, knmi, key, **kwargs):
        """Wrap the ``kpinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().kpinqr(knmi, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.lsinqr)
    def lsinqr(self, line, key, **kwargs):
        """Wrap the ``lsinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().lsinqr(line, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.arinqr)
    def arinqr(self, anmi, key, **kwargs):
        """Wrap the ``arinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().arinqr(anmi, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.vlinqr)
    def vlinqr(self, vnmi, key, **kwargs):
        """Wrap the ``vlinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().vlinqr(vnmi, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.rlinqr)
    def rlinqr(self, nreal, key, **kwargs):
        """Wrap the ``rlinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().rlinqr(nreal, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.gapiqr)
    def gapiqr(self, ngap, key, **kwargs):
        """Wrap the ``gapiqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().gapiqr(ngap, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.masiqr)
    def masiqr(self, node, key, **kwargs):
        """Wrap the ``masiqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().masiqr(node, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.ceinqr)
    def ceinqr(self, nce, key, **kwargs):
        """Wrap the ``ceinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().ceinqr(nce, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.cpinqr)
    def cpinqr(self, ncp, key, **kwargs):
        """Wrap the ``cpinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().cpinqr(ncp, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.csyiqr)
    def csyiqr(self, ncsy, key, **kwargs):
        """Wrap the ``csyiqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().csyiqr(ncsy, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.etyiqr)
    def etyiqr(self, itype, key, **kwargs):
        """Wrap the ``etyiqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().etyiqr(itype, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.foriqr)
    def foriqr(self, node, key, **kwargs):
        """Wrap the ``foriqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().foriqr(node, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.sectinqr)
    def sectinqr(self, nsect, key, **kwargs):
        """Wrap the ``sectinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().sectinqr(nsect, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.mpinqr)
    def mpinqr(self, mat, iprop, key, **kwargs):
        """Wrap the ``mpinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().mpinqr(mat, iprop, key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.dget)
    def dget(self, node, idf, kcmplx, **kwargs):
        """Wrap the ``dget`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().dget(node, idf, kcmplx, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.fget)
    def fget(self, node, idf, kcmplx, **kwargs):
        """Wrap the ``fget`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().fget(node, idf, kcmplx, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.erinqr)
    def erinqr(self, key, **kwargs):
        """Wrap the ``erinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().erinqr(key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.wrinqr)
    def wrinqr(self, key, **kwargs):
        """Wrap the ``wrinqr`` method to take advantage of the gRPC methods.

        Returns
        -------
        float
            Scalar parameter value.
        """
        super().wrinqr(key, pname=TMP_VAR, mute=True, **kwargs)
        return self.scalar_param(TMP_VAR)

    @wraps(_MapdlCore.catiain)
    def catiain(self, name="", extension="", path="", blank="", **kwargs):
        """Wrap the ``catiain`` method to take advantage of the gRPC methods.

        Returns
        -------
        str
            Command output from MAPDL.
        """
        if self.platform == "windows":
            raise OSError(
                "The command 'catiain' is not supported on Windows. Use the 'mapdl.cat5in' method instead to import Catia v5 files."
            )
        return super().catiain(
            name=name, extension=extension, path=path, blank=blank, **kwargs
        )

    @wraps(_MapdlCore.cat5in)
    def cat5in(
        self,
        name="",
        extension="",
        path="",
        entity="",
        fmt="",
        nocl="",
        noan="",
        **kwargs,
    ):
        """Wrap the ``cat5in`` method to take advantage of the gRPC methods."""
        if self.platform == "linux":
            raise OSError(
                "The command 'cat5in' is not supported on Linux. Use the 'mapdl.catiain' method instead to import Catia v4 files."
            )

        fname = name
        if path:
            fname = os.path.join(path, name)
        fname = self._get_file_name(fname, extension, "CATPart")
        fname = self._get_file_path(fname, False)
        name, extension, path = self._decompose_fname(fname)

        path = "" if path == path.parent else str(path)

        # wrapping path in single quotes because of #2286
        path = f"'{path}'"
        self.finish()
        return super().cat5in(
            name=name,
            extension=extension,
            path=path,
            entity=entity,
            fmt=fmt,
            nocl=nocl,
            noan=noan,
            **kwargs,
        )

    @wraps(_MapdlCore.igesin)
    def igesin(self, fname, ext="", **kwargs):
        """Wrap the IGESIN command to handle the remote case."""

        fname = self._get_file_name(fname=fname, ext=ext)
        filename = self._get_file_path(fname, progress_bar=False)

        # Entering aux15 preprocessor
        self.aux15()

        if " " not in fname:
            return super().igesin(fname=filename, **kwargs)

        # Bug in reading file paths with whitespaces.
        # https://github.com/ansys/pymapdl/issues/1601

        msg_ = f"Applying \\IGESIN whitespace patch.\nSee #1601 issue in PyMAPDL repository.\nReading file {fname}"
        self.input_strings("\n".join([f"! {each}" for each in msg_.splitlines()]))
        self._log.debug(msg_)

        cmd = f"*dim,__iges_file__,string,248\n*set,__iges_file__(1), '{filename}'"
        self.input_strings(cmd)

        out = super().igesin(fname="__iges_file__(1)", **kwargs)
        self.run("__iges_file__ =")  # cleaning array.
        self.run("! Ending \\IGESIN whitespace patch.")
        return out

    @wraps(_MapdlCore.satin)
    def satin(
        self,
        name,
        extension="",
        path="",
        entity="",
        fmt="",
        nocl="",
        noan="",
        **kwargs,
    ):
        """Wraps ~SATIN command"""
        fname = name
        if path:
            fname = os.path.join(path, name)
        fname = self._get_file_name(fname, extension, "sat")
        fname = self._get_file_path(fname, False)
        name, extension, path = self._decompose_fname(fname)

        path = "" if path == path.parent else str(path)

        # wrapping path in single quotes because of #2286
        path = f"'{path}'"
        return super().satin(
            name=name,
            extension=extension,
            path=path,
            entity=entity,
            fmt=fmt,
            nocl=nocl,
            noan=noan,
            **kwargs,
        )

    @wraps(_MapdlCore.parain)
    def parain(
        self,
        name,
        extension="",
        path="",
        entity="",
        fmt="",
        scale="",
        **kwargs,
    ):
        """Wraps ~parain command"""
        fname = name
        if path:
            fname = os.path.join(path, name)
        fname = self._get_file_name(fname, extension, "x_t")
        fname = self._get_file_path(fname, False)
        name, extension, path = self._decompose_fname(fname)

        path = "" if path == path.parent else str(path)

        # wrapping path in single quotes because of #2286
        path = f"'{path}'"
        return super().parain(
            name=name,
            extension=extension,
            path=path,
            entity=entity,
            fmt=fmt,
            scale=scale,
            **kwargs,
        )

    @wraps(_MapdlCore.osresult)
    def osresult(self, item="", comp="", freq="", cname="", **kwargs) -> CommandOutput:
        result = super().osresult(item, comp, freq, cname, **kwargs)
        if item.upper().strip() == "STATUS":
            from ansys.mapdl.core.misc import expand_all_inner_lists

            columns_names = ["ITEM", "FREQUENCY", "COMPONENT"]
            result = CommandListingOutput(result)
            table_match = re.search(
                r"ITEM\s+FREQUENCY\s+COMPONENT(.*)", result, flags=re.DOTALL
            )
            if table_match:
                table = table_match.group(1)
                table = [each.split() for each in table.splitlines() if each.strip()]
                table = expand_all_inner_lists(
                    table, target_length=len(columns_names), fill_value=""
                )

                result._columns_names = columns_names
                result._cache = np.array(table)
        return result

    @wraps(_MapdlCore.aflist)
    def aflist(self, **kwargs):
        # Running in non-interactive to avoid the `aflist.tmp` command being locked
        # because of `/INPUT` issue on MAPDL side. See #4390 for more details.
        with self.non_interactive:
            return super().aflist(**kwargs)


class _MapdlExtended(_MapdlCommandExtended):
    """Extend Mapdl class with new functions"""

    def set_graphics_backend(self, backend: GraphicsBackend):
        """Set the graphics backend to use for plotting."""
        self._graphics_backend = backend

    def load_table(
        self, name, array, var1="", var2="", var3="", csysid="", col_header=False
    ):
        """Load a table from Python to into MAPDL.

        Uses :func:`tread <Mapdl.tread>` to transfer the table.

        Parameters
        ----------
        name : str
            An alphanumeric name used to identify this table.  Name
            may be up to 32 characters, beginning with a letter and
            containing only letters, numbers, and underscores.
            Examples: ``"ABC" "A3X" "TOP_END"``.

        array : numpy.ndarray or list
            List as a table or :class:`numpy.ndarray` array.

        var1 : str, optional
            Variable name corresponding to the first dimension (row).
            Default ``"Row"``.

            A primary variable (listed below) or can be an independent
            parameter. If specifying an independent parameter, then you must
            define an additional table for the independent parameter. The
            additional table must have the same name as the independent
            parameter and may be a function of one or more primary variables or
            another independent parameter. All independent parameters must
            relate to a primary variable.

            - ``"TIME"``: Time
            - ``"FREQ"``: Frequency
            - ``"X"``: X-coordinate location
            - ``"Y"``: Y-coordinate location
            - ``"Z"``: Z-coordinate location
            - ``"TEMP"``: Temperature
            - ``"VELOCITY"``: Velocity
            - ``"PRESSURE"``: Pressure
            - ``"GAP"``: Geometric gap/penetration
            - ``"SECTOR"``: Cyclic sector number
            - ``"OMEGS"``: Amplitude of the rotational velocity vector
            - ``"ECCENT"``: Eccentricity
            - ``"THETA"``: Phase shift
            - ``"ELEM"``: Element number
            - ``"NODE"``: Node number
            - ``"CONC"``: Concentration

        var2 : str, optional
            Variable name corresponding to the first dimension (column).
            See ``var1``.  Default column.

        var3 : str, optional
            Variable name corresponding to the first dimension (plane).
            See ``var1``. Default Plane.

        csysid : str, optional
            An integer corresponding to the coordinate system ID number.
            APDL Default = 0 (global Cartesian)

        col_header : bool, optional
            Indicates if the first row of the input array is a header.
            Set to True if the array includes a header row.
            Default is False.

        Examples
        --------
        Transfer a table to MAPDL. The first column is time values and must be
        ascending in order.

        >>> my_conv = np.array([[0, 0.001],
                                [120, 0.001],
                                [130, 0.005],
                                [700, 0.005],
                                [710, 0.002],
                                [1000, 0.002]])
        >>> mapdl.load_table('MY_TABLE', my_conv, 'TIME')
        >>> mapdl.parameters['MY_TABLE']
        array([[0.001],
               [0.001],
               [0.005],
               [0.005],
               [0.002],
               [0.002]])
        """
        if not isinstance(array, np.ndarray):
            raise ValueError("The table should be a Numpy array")
        if array.shape[0] < 2 or array.shape[1] < 2:
            raise ValueError(
                "One or two of the array dimensions are too small to create a table."
            )

        if array.ndim == 2:
            # MAPDL considers the first row to be column header when col num > 2.
            # When col header is not available duplicate the first row
            if array.shape[1] > 2:
                if col_header is False:
                    array = np.vstack((array[0], array))
                imax_val = array.shape[0] - 1
            else:
                imax_val = array.shape[0]

            self.dim(
                name,
                "TABLE",
                imax=imax_val,
                jmax=array.shape[1] - 1,
                kmax="",
                var1=var1,
                var2=var2,
                var3=var3,
                csysid=csysid,
            )
        else:
            raise ValueError(
                f"Expecting only a 2D table, but input contains\n{array.ndim} dimensions"
            )

        if not np.all(array[:-1, 0] <= array[1:, 0]):
            raise ValueError(
                "The underlying ``TREAD`` command requires that the first column is in "
                "ascending order."
            )

        base_name = random_string() + ".txt"
        filename = os.path.join(tempfile.gettempdir(), base_name)
        np.savetxt(filename, array, header="File generated by PyMAPDL:load_table")

        if not self._local:
            self.upload(filename, progress_bar=False)
            filename = base_name

        # skip the first line its a header we wrote in np.savetxt
        self.tread(name, filename, nskip=1, mute=True)

        if not self._local:
            self.slashdelete(filename)

    def load_array(self, name, array):
        """
        Load an array from Python to MAPDL.

        Uses ``VREAD`` to transfer the array.
        The format of the numbers used in the intermediate file is F24.18.

        Parameters
        ----------
        name : str
            An alphanumeric name used to identify this table.  Name
            may be up to 32 characters, beginning with a letter and
            containing only letters, numbers, and underscores.
            Examples: ``"ABC" "A3X" "TOP_END"``.

        array : np.ndarray or list
            List as a table or ``numpy`` array.

        Examples
        --------
        >>> my_conv = np.array([[0, 0.001],
        ...                     [120, 0.001],
        ...                     [130, 0.005],
        ...                     [700, 0.005],
        ...                     [710, 0.002],
        ...                     [1000, 0.002]])
        >>> mapdl.load_array('MY_ARRAY', my_conv)
        >>> mapdl.parameters['MY_ARRAY']
        array([[0.0e+00, 1.0e-03],
                [1.2e+02, 1.0e-03],
                [1.3e+02, 5.0e-03],
                [7.0e+02, 5.0e-03],
                [7.1e+02, 2.0e-03],
                [1.0e+03, 2.0e-03]])
        """
        if not isinstance(array, np.ndarray):
            array = np.asarray(array)

        if array.ndim > 2:
            raise NotImplementedError(
                "Only loading of 1D or 2D arrays is supported at the moment."
            )

        jmax = 1
        kmax = ""

        if array.ndim > 0:
            imax = array.shape[0]

        if array.ndim > 1:
            jmax = array.shape[1]

        self.dim(name, "ARRAY", imax=imax, jmax=jmax, kmax="")

        base_name = random_string() + ".txt"
        filename = os.path.join(tempfile.gettempdir(), base_name)
        self._log.info(f"Generating file for table in {filename}")
        np.savetxt(
            filename,
            array.ravel(),
            delimiter="",
            header="File generated by PyMAPDL:load_array",
            fmt="%+24.18e",  # adding sign.
        )

        if not self._local:
            self.upload(filename, progress_bar=False)
            filename = base_name

        with self.non_interactive:
            label = "jik"
            n1 = jmax
            n2 = imax
            n3 = kmax
            self.vread(name, filename, n1=n1, n2=n2, n3=n3, label=label, nskip=1)
            fmt = f"(1E25.18)"  # Adding one extra space for the sign
            logger.info("Using *VREAD with format %s in %s", fmt, filename)
            self.run(fmt)

        if self._local:
            os.remove(filename)
        else:
            self.slashdelete(filename)

    @supress_logging
    def get_array(
        self,
        entity: str = "",
        entnum: str = "",
        item1: str = "",
        it1num: MapdlFloat = "",
        item2: str = "",
        it2num: MapdlFloat = "",
        kloop: MapdlFloat = "",
        **kwargs: KwargDict,
    ) -> NDArray[np.float64]:
        """Uses the ``*VGET`` command to Return an array from ANSYS as a
        Python array.

        See `VGET
        <https://www.mm.bme.hu/~gyebro/files/ans_help_v182/ans_cmd/Hlp_C_VGET_st.html>`
        for more details.

        Parameters
        ----------
        entity
            Entity keyword.  Valid keywords are NODE, ELEM, KP, LINE,
            AREA, VOLU, etc

        entnum
            The number of the entity.

        item1
            The name of a particular item for the given entity.  Valid
            items are as shown in the Item1 columns of the tables
            below.

        it1num
            The number (or label) for the specified Item1 (if any).
            Valid IT1NUM values are as shown in the IT1NUM columns of
            the tables below.  Some Item1 labels do not require an
            IT1NUM value.

        item2, it2num
            A second set of item labels and numbers to further qualify
            the item for which data is to be retrieved.  Most items do
            not require this level of information.

        kloop
            Field to be looped on:

            - 0 or 2 : Loop on the ENTNUM field (default).
            - 3 : Loop on the Item1 field.
            - 4 : Loop on the IT1NUM field. Successive items are as shown with IT1NUM.
            - 5 : Loop on the Item2 field.
            - 6 : Loop on the IT2NUM field. Successive items are as shown with IT2NUM.

        Notes
        -----
        Please reference your Ansys help manual ``*VGET`` command tables
        for all the available ``*VGET`` values.

        Returns
        -------
        numpy.ndarray
            Array from MAPDL.

        Examples
        --------
        List the current selected node numbers

        >>> mapdl.get_array('NODE', item1='NLIST')
        array([  1.,   2.,   3.,   4.,   5.,   6.,   7.,   8.,
              ...
              314., 315., 316., 317., 318., 319., 320., 321.])

        List the displacement in the X direction for the first result

        >>> mapdl.post1()
        >>> mapdl.set(1, 1)
        >>> disp_x = mapdl.get_array('NODE', item1='U', it1num='X')
        array([ 0.01605306, -0.01605306,  0.00178402, -0.01605306,
               ...
               -0.00178402, -0.01234851,  0.01234851, -0.01234851])
        """
        if self._store_commands:
            raise MapdlRuntimeError(
                "Cannot use `mapdl.get_array` when in `non_interactive` mode, "
                "since it does not return anything until the `non_interactive` context "
                "manager is finished.\n"
                "Exit `non_interactive` mode before using this method.\n\n"
                "Alternatively you can use `mapdl.vget` to specify the name of the MAPDL parameter where to store the retrieved value."
            )

        arr = self._get_array(
            entity, entnum, item1, it1num, item2, it2num, kloop, **kwargs
        )

        # edge case where corba refuses to return the array
        ntry = 0
        while arr.size == 1 and arr[0] == -1:
            arr = self._get_array(
                entity, entnum, item1, it1num, item2, it2num, kloop, **kwargs
            )
            if ntry > 5:
                raise MapdlRuntimeError("Unable to get array for %s" % entity)
            ntry += 1
        return arr

    def _get_array(
        self,
        entity: str = "",
        entnum: str = "",
        item1: str = "",
        it1num: MapdlFloat = "",
        item2: str = "",
        it2num: MapdlFloat = "",
        kloop: MapdlFloat = "",
        dtype: DTypeLike = None,
        delete_after: bool = True,
        **kwargs,
    ) -> NDArray[np.float64]:
        """Uses the VGET command to get an array from ANSYS"""
        parm_name = kwargs.pop("parm", None)

        if self._store_commands and not parm_name:
            raise MapdlRuntimeError(
                "Cannot use `mapdl._get_array` when in `non_interactive` mode, "
                "since it does not return anything until the `non_interactive` context "
                "manager is finished.\n"
                "Exit `non_interactive` mode before using this method.\n\n"
                "Alternatively you can use `mapdl.vget` or use the `parm` kwarg in "
                "`mapdl._get_array` to specify the name of the MAPDL parameter where to store the retrieved value. In any case, this function will return `None`"
            )

        if parm_name is None:
            parm_name = "__vget_tmp_%d__" % self._vget_arr_counter
            self._vget_arr_counter += 1

        out = self.starvget(
            parm_name,
            entity,
            entnum,
            item1,
            it1num,
            item2,
            it2num,
            kloop,
            mute=False,
        )

        if self._store_commands:
            # Return early
            return None

        # check if empty array
        if "the dimension number 1 is 0" in out:
            return np.empty(0)

        with self.non_interactive:
            self.vwrite("%s(1)" % parm_name)  # type: ignore[arg-type]
            self.run("(F20.12)")  # type: ignore[arg-type]

        array = np.fromstring(self.last_response, sep="\n")

        if delete_after or "__vget_tmp_" in parm_name:
            self.run(f"{parm_name}=")

        if dtype:
            return array.astype(dtype)
        else:
            return array

    def get_nodal_constrains(self, label=None):
        """
        Get the applied nodal constrains:

        Uses ``DLIST``.

        Parameters
        ----------
        label : [str], optional
            If given, the output nodal constrains are filtered to correspondent given label.
            Example of labels are ``UX``, ``UZ``, ``VOLT`` or ``TEMP``. By default None

        Returns
        -------
        List[List[Str]] or numpy.array
            If parameter ``label`` is give, the output is converted to a
            numpy array instead of a list of list of strings.
        """
        constrains = self.dlist().to_list()
        if label:
            constrains = np.array(
                [[each[0], each[2], each[3]] for each in constrains if each[1] == label]
            )
        return constrains

    def get_nodal_loads(self, label=None):
        """
        Get the applied nodal loads.

        Uses ``FLIST``.

        Parameters
        ----------
        label : [str], optional
            If given, the output nodal loads are filtered to correspondent given label.
            Example of labels are ``FX``, ``FZ``, ``CHRGS`` or ``CSGZ``. By default None

        Returns
        -------
        List[List[Str]] or numpy.array
            If parameter ``label`` is give, the output is converted to a
            numpy array instead of a list of list of strings.
        """
        loads = self.flist().to_list()
        if label:
            loads = np.array(
                [[each[0], each[2], each[3]] for each in loads if each[1] == label]
            )
        return loads

    def modal_analysis(
        self,
        method="lanb",
        nmode="",
        freqb="",
        freqe="",
        cpxmod="",
        nrmkey="",
        modtype="",
        memory_option="",
        mxpand="",
        elcalc=False,
    ) -> str:
        """Run a modal with basic settings analysis

        Parameters
        ----------
        method : str
            Mode-extraction method to be used for the modal analysis.
            Defaults to lanb (block lanczos).  Must be one of the following:

            - LANB : Block Lanczos
            - LANPCG : PCG Lanczos
            - SNODE : Supernode modal solver
            - SUBSP : Subspace algorithm
            - UNSYM : Unsymmetric matrix
            - DAMP : Damped system
            - QRDAMP : Damped system using QR algorithm
            - VT : Variational Technology

        nmode : int, optional
            The number of modes to extract. The value can depend on
            the value supplied for Method. NMODE has no default and
            must be specified. If Method = LANB, LANPCG, or SNODE, the
            number of modes that can be extracted can equal the DOFs
            in the model after the application of all boundary
            conditions.

        freqb : float, optional
            The beginning, or lower end, of the frequency range of
            interest.

        freqe : float, optional
            The ending, or upper end, of the frequency range of
            interest (in Hz). The default for Method = SNODE is
            described below. The default for all other methods is to
            calculate all modes, regardless of their maximum
            frequency.

        cpxmod : str, optional
            Complex eigenmode key. Valid only when ``method='QRDAMP'``
            or ``method='unsym'``

            - AUTO : Determine automatically if the eigensolutions are
              real or complex and output them accordingly. This is
              the default for ``method='UNSYM'``.  Not supported for
              Method = QRDAMP.
            - ON or CPLX : Calculate and output complex eigenmode
              shapes.
            - OFF or REAL : Do not calculate complex eigenmode
              shapes. This is required if a mode-
              superposition analysis is intended after the
              modal analysis for Method = QRDAMP. This is the
              default for this method.

        nrmkey : bool, optional
            Mode shape normalization key.  When ``True`` (default),
            normalize the mode shapes to the mass matrix.  When False,
            Normalize the mode shapes to unity instead of to the mass
            matrix.  If a subsequent spectrum or mode-superposition
            analysis is planned, the mode shapes should be normalized
            to the mass matrix.

        modtype : str, optional
            Type of modes calculated by the eigensolver. Only
            applicable to the unsymmetric eigensolver.

            - Blank : Right eigenmodes. This value is the default.
            - BOTH : Right and left eigenmodes. The left eigenmodes are
              written to Jobname.LMODE.  This option must be
              activated if a mode-superposition analysis is intended.

        memory_option : str, optional
            Memory allocation option:

            * ``DEFAULT`` - Default Memory mode
                      Use the default memory allocation strategy for
                      the sparse solver. The default strategy attempts
                      to run in the INCORE memory mode. If there is
                      not enough available physical memory when the
                      solver starts to run in the ``INCORE`` memory
                      mode, the solver will then attempt to run in the
                      ``OUTOFCORE`` memory mode.

            * ``INCORE`` - In-core memory mode
                     Use a memory allocation strategy in the sparse
                     solver that will attempt to obtain enough memory
                     to run with the entire factorized matrix in
                     memory. This option uses the most amount of
                     memory and should avoid doing any I/O. By
                     avoiding I/O, this option achieves optimal solver
                     performance. However, a significant amount of
                     memory is required to run in this mode, and it is
                     only recommended on machines with a large amount
                     of memory. If the allocation for in-core memory
                     fails, the solver will automatically revert to
                     out-of-core memory mode.

            * ``OUTOFCORE`` - Out of core memory mode.
                        Use a memory allocation strategy in the sparse
                        solver that will attempt to allocate only
                        enough work space to factor each individual
                        frontal matrix in memory, but will store the
                        entire factorized matrix on disk. Typically,
                        this memory mode results in poor performance
                        due to the potential bottleneck caused by the
                        I/O to the various files written by the
                        solver.

        mxpand : bool, optional
            Number of modes or array name (enclosed in percent signs)
            to expand and write.  If -1, do not expand and do not
            write modes to the results file during the
            analysis. Default ``""``.
        elcalc : bool, optional
            Calculate element results, reaction forces, energies, and
            the nodal degree of freedom solution.  Default ``False``.

        Returns
        -------
        str
            Output from MAPDL SOLVE command.

        Notes
        -----
        For models that involve a non-symmetric element stiffness
        matrix, as in the case of a contact element with frictional
        contact, the QRDAMP eigensolver (MODOPT, QRDAMP) extracts
        modes in the modal subspace formed by the eigenmodes from the
        symmetrized eigenproblem. The QRDAMP eigensolver symmetrizes
        the element stiffness matrix on the first pass of the
        eigensolution, and in the second pass, eigenmodes are
        extracted in the modal subspace of the first eigensolution
        pass. For such non- symmetric eigenproblems, you should verify
        the eigenvalue and eigenmode results using the non-symmetric
        matrix eigensolver (MODOPT,UNSYM).

        The DAMP and QRDAMP options cannot be followed by a subsequent
        spectrum analysis. The UNSYM method supports spectrum analysis
        when eigensolutions are real.

        Examples
        --------
        Modal analysis using default parameters for the first 6 modes

        >>> mapdl.modal_analysis(nmode=6)
        """
        if nrmkey:
            if nrmkey.upper() != "OFF":
                nrmkey = "ON"
        nrmkey = "OFF"

        self.slashsolu(mute=True)
        self.antype(2, "new", mute=True)
        self.modopt(method, nmode, freqb, freqe, cpxmod, nrmkey, modtype, mute=True)
        self.bcsoption(memory_option, mute=True)

        if mxpand:
            self.mxpand(mute=True)
        if elcalc:
            self.mxpand(elcalc="YES", mute=True)

        out = self.solve()
        self.finish(mute=True)
        return out

    def get_value(
        self,
        entity: str = "",
        entnum: str = "",
        item1: str = "",
        it1num: MapdlFloat = "",
        item2: str = "",
        it2num: MapdlFloat = "",
        item3: MapdlFloat = "",
        it3num: MapdlFloat = "",
        item4: MapdlFloat = "",
        it4num: MapdlFloat = "",
        **kwargs: KwargDict,
    ) -> Union[float, str]:
        """Runs the MAPDL GET command and returns a Python value.

        This method uses :func:`Mapdl.get`.

        See the full MAPDL command documentation at `*GET
        <https://www.mm.bme.hu/~gyebro/files/ans_help_v182/ans_cmd/Hlp_C_GET.html>`_

        .. note::
           This method is not available when within the
           :func:`Mapdl.non_interactive`
           context manager.

        Parameters
        ----------
        entity : str
            Entity keyword. Valid keywords are ``"NODE"``, ``"ELEM"``,
            ``"KP"``, ``"LINE"``, ``"AREA"``, ``"VOLU"``, ``"PDS"``,
            etc.

        entnum : str, int, optional
            The number or label for the entity. In some cases, a zero
            (or blank ``""``) ``entnum`` represents all entities of
            the set.

        item1 : str, optional
            The name of a particular item for the given entity.

        it1num : str, int, optional
            The number (or label) for the specified Item1 (if
            any). Some Item1 labels do not require an IT1NUM value.

        item2 : str, optional
            A second set of item labels and numbers to further qualify the item
            for which data are to be retrieved. Most items do not require this
            level of information.

        it2num : str, int, optional
            The number (or label) for the specified ``item2`` (if
            any). Some ``item2`` labels do not require an ``it2num``
            value.

        item3 : str, optional
            A third set of item labels and numbers to further qualify the item
            for which data are to be retrieved. Most items do not require this
            level of information.

        it3num : str, int, optional
            The number (or label) for the specified ``item3`` (if
            any). Some ``item3`` labels do not require an ``it3num``
            value.

        item4 : str, optional
            A fourth set of item labels and numbers to further qualify the item
            for which data are to be retrieved. Most items do not require this level of information.

        it4num : str, int, optional
            The number (or label) for the specified ``item4`` (if
            any). Some ``item4`` labels do not require an ``it4num``
            value.

        Returns
        -------
        float
            Floating point value of the parameter.

        Examples
        --------
        Retrieve the number of nodes.

        >>> value = mapdl.get_value('node', '', 'count')
        >>> value
        3003

        Retrieve the number of nodes using keywords.

        >>> value = mapdl.get_value(entity='node', item1='count')
        >>> value
        3003
        """
        return self._get(
            entity=entity,
            entnum=entnum,
            item1=item1,
            it1num=it1num,
            item2=item2,
            it2num=it2num,
            item3=item3,
            it3num=it3num,
            item4=item4,
            it4num=it4num,
            **kwargs,
        )
