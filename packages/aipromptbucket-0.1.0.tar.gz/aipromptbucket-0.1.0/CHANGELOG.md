# Changelog

## 0.1.0 (2025-02-24)

- Initial release
- Full API client with 28 methods
- `get_prompt()` drop-in function
- `configure()` for global defaults
- CLI scanner (`apb scan`)
- Retry logic with exponential backoff
