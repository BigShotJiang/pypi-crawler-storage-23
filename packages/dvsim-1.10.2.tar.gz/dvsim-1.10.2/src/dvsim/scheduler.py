# Copyright lowRISC contributors (OpenTitan project).
# Licensed under the Apache License, Version 2.0, see LICENSE for details.
# SPDX-License-Identifier: Apache-2.0

"""Job scheduler."""

import contextlib
import os
import selectors
from collections.abc import (
    Callable,
    Mapping,
    MutableMapping,
    MutableSequence,
    MutableSet,
    Sequence,
)
from itertools import dropwhile
from signal import SIGINT, SIGTERM, signal
from types import FrameType
from typing import TYPE_CHECKING, Any

from dvsim import instrumentation
from dvsim.instrumentation import NoOpInstrumentation
from dvsim.job.data import CompletedJobStatus, JobSpec
from dvsim.job.status import JobStatus
from dvsim.launcher.base import Launcher, LauncherBusyError, LauncherError
from dvsim.logging import log
from dvsim.utils.status_printer import get_status_printer
from dvsim.utils.timer import Timer

if TYPE_CHECKING:
    from dvsim.flow.base import FlowCfg


def total_sub_items(
    d: Mapping[str, Sequence[str]] | Mapping["FlowCfg", Sequence[JobSpec]],
) -> int:
    """Return the total number of sub items in a mapping.

    Given a dict whose key values are lists, return sum of lengths of
    these lists.
    """
    return sum(len(v) for v in d.values())


def get_next_item(arr: Sequence, index: int) -> tuple[Any, int]:
    """Perpetually get an item from a list.

    Returns the next item on the list by advancing the index by 1. If the index
    is already the last item on the list, it loops back to the start, thus
    implementing a circular list.

    Args:
        arr: subscriptable list.
        index: index of the last item returned.

    Returns:
        (item, index) if successful.

    Raises:
        IndexError if arr is empty.

    """
    index += 1
    try:
        item = arr[index]
    except IndexError:
        index = 0
        try:
            item = arr[index]
        except IndexError:
            msg = "List is empty!"
            raise IndexError(msg) from None

    return item, index


class Scheduler:
    """An object that runs one or more jobs from JobSpec items."""

    def __init__(
        self,
        items: Sequence[JobSpec],
        launcher_cls: type[Launcher],
        *,
        interactive: bool = False,
    ) -> None:
        """Initialise a job scheduler.

        Args:
            items: sequence of jobs to deploy.
            launcher_cls: Launcher class to use to deploy the jobs.
            interactive: launch the tools in interactive mode.

        """
        # Start any instrumentation
        inst = instrumentation.get()
        self._instrumentation = NoOpInstrumentation() if inst is None else inst
        self._instrumentation.start()

        self._jobs: Mapping[str, JobSpec] = {i.full_name: i for i in items}

        # 'scheduled[target][cfg]' is a list of JobSpec object names for the chosen
        # target and cfg. As items in _scheduled are ready to be run (once
        # their dependencies pass), they are moved to the _queued list, where
        # they wait until slots are available for them to be dispatched.
        # When all items (in all cfgs) of a target are done, it is removed from
        # this dictionary.
        self._scheduled: MutableMapping[str, MutableMapping[str, MutableSequence[str]]] = {}
        self.add_to_scheduled(jobs=self._jobs)

        # Print status periodically using an external status printer.
        self._status_printer = get_status_printer(interactive)
        self._status_printer.print_header()

        # Sets of items, split up by their current state. The sets are
        # disjoint and their union equals the keys of self.item_status.
        # _queued is a list so that we dispatch things in order (relevant
        # for things like tests where we have ordered things cleverly to
        # try to see failures early). They are maintained for each target.

        # The list of available targets and the list of running items in each
        # target are polled in a circular fashion, looping back to the start.
        # This is done to allow us to poll a smaller subset of jobs rather than
        # the entire regression. We keep rotating through our list of running
        # items, picking up where we left off on the last poll.
        self._targets: Sequence[str] = list(self._scheduled.keys())
        self._total: MutableMapping[str, int] = {}

        self._queued: MutableMapping[str, MutableSequence[str]] = {}
        self._running: MutableMapping[str, MutableSequence[str]] = {}

        self._passed: MutableMapping[str, MutableSet[str]] = {}
        self._failed: MutableMapping[str, MutableSet[str]] = {}
        self._killed: MutableMapping[str, MutableSet[str]] = {}

        self._last_target_polled_idx = -1
        self._last_item_polled_idx = {}

        for target in self._scheduled:
            self._queued[target] = []
            self._running[target] = []

            self._passed[target] = set()
            self._failed[target] = set()
            self._killed[target] = set()

            self._total[target] = total_sub_items(self._scheduled[target])
            self._last_item_polled_idx[target] = -1

            # Stuff for printing the status.
            width = len(str(self._total[target]))
            field_fmt = f"{{:0{width}d}}"
            self._msg_fmt = (
                f"Q: {field_fmt}, D: {field_fmt}, P: {field_fmt}, "
                f"F: {field_fmt}, K: {field_fmt}, T: {field_fmt}"
            )
            msg = self._msg_fmt.format(0, 0, 0, 0, 0, self._total[target])
            self._status_printer.init_target(target=target, msg=msg)

        # A map from the job names tracked by this class to their
        # current status, corresponding to membership in the dicts
        # above. This is not per-target.
        self.job_status: MutableMapping[str, JobStatus] = {}

        # Create the launcher instance for all items.
        self._launchers: Mapping[str, Launcher] = {
            full_name: launcher_cls(job_spec) for full_name, job_spec in self._jobs.items()
        }

        # The chosen launcher class. This allows us to access launcher
        # variant-specific settings such as max parallel jobs & poll rate.
        self._launcher_cls: type[Launcher] = launcher_cls

    def _handle_exit_signal(self, last_received_signal: int, handler: Callable) -> None:
        """Handle a received exit (SIGINT/SIGTERM signal) in the main scheduler loop.

        On either signal, this will tell runners to quit and cancel future jobs.
        On receiving a SIGINT specifically, this re-installs the old signal handler
        such that subsequent SIGINT signals will kill the process (non-gracefully).
        """
        log.info(
            "Received signal %s. Exiting gracefully.",
            last_received_signal,
        )

        if last_received_signal == SIGINT:
            log.info(
                "Send another to force immediate quit (but you may "
                "need to manually kill child processes)",
            )

            # Restore old handler to catch a second SIGINT
            signal(SIGINT, handler)

        self._kill()

    def run(self) -> Sequence[CompletedJobStatus]:
        """Run all scheduled jobs and return the results.

        Returns the results (status) of all items dispatched for all
        targets and cfgs.
        """
        # Notify instrumentation that the scheduler started
        self._instrumentation.on_scheduler_start()
        timer = Timer()

        # On SIGTERM or SIGINT, tell the runner to quit.
        # On a second SIGINT specifically, die.
        sel = selectors.DefaultSelector()
        signal_rfd, signal_wfd = os.pipe()
        sel.register(signal_rfd, selectors.EVENT_READ)
        last_received_signal: int | None = None

        def on_signal(signal_received: int, _: FrameType | None) -> None:
            # To allow async-safe-signal logic where signals can be handled
            # while sleeping, we use a selector to perform a blocking wait,
            # and signal the event through a pipe. We then set a flag with
            # the received signal. Like this, we can receive a signal
            # at any point, and it can also interrupt the poll wait to take
            # immediate effect.
            nonlocal last_received_signal
            last_received_signal = signal_received
            os.write(signal_wfd, b"\x00")

        # Install the SIGINT and SIGTERM handlers before scheduling jobs.
        old_handler = signal(SIGINT, on_signal)
        signal(SIGTERM, on_signal)

        # Enqueue all items of the first target.
        self._enqueue_successors(None)

        try:
            while True:
                if last_received_signal is not None:
                    self._handle_exit_signal(last_received_signal, old_handler)
                    last_received_signal = None

                hms = timer.hms()
                changed = self._poll(hms) or timer.check_time()
                self._dispatch(hms)
                if changed and self._check_if_done(hms):
                    break

                # Wait between each poll, except we may be woken by a signal.
                sel.select(timeout=self._launcher_cls.poll_freq)

        finally:
            signal(SIGINT, old_handler)

        # Cleanup the status printer.
        self._status_printer.exit()

        # Finish instrumentation and generate the instrumentation report
        self._instrumentation.on_scheduler_end()
        self._instrumentation.stop()
        instrumentation.flush()

        # We got to the end without anything exploding. Return the results.
        results = []
        for name, status in self.job_status.items():
            launcher = self._launchers[name]
            job_spec = self._jobs[name]

            results.append(
                CompletedJobStatus(
                    name=job_spec.name,
                    job_type=job_spec.job_type,
                    seed=job_spec.seed,
                    block=job_spec.block,
                    tool=job_spec.tool,
                    workspace_cfg=job_spec.workspace_cfg,
                    full_name=name,
                    qual_name=job_spec.qual_name,
                    target=job_spec.target,
                    log_path=job_spec.log_path,
                    job_runtime=launcher.job_runtime.with_unit("s").get()[0],
                    simulated_time=launcher.simulated_time.with_unit("us").get()[0],
                    status=status,
                    fail_msg=launcher.fail_msg,
                )
            )

        return results

    def add_to_scheduled(self, jobs: Mapping[str, JobSpec]) -> None:
        """Add jobs to the schedule.

        Args:
            jobs: the jobs to add to the schedule.

        """
        for full_name, job_spec in jobs.items():
            target_dict = self._scheduled.setdefault(job_spec.target, {})
            cfg_list = target_dict.setdefault(job_spec.block.name, [])

            if job_spec not in cfg_list:
                cfg_list.append(full_name)

    def _unschedule_item(self, job_name: str) -> None:
        """Remove deploy item from the schedule."""
        job = self._jobs[job_name]
        target_dict = self._scheduled[job.target]
        cfg_list = target_dict.get(job.block.name)

        if cfg_list is not None:
            with contextlib.suppress(ValueError):
                cfg_list.remove(job_name)

            # When all items in _scheduled[target][cfg] are finally removed,
            # the cfg key is deleted.
            if not cfg_list:
                del target_dict[job.block.name]

    def _enqueue_successors(self, job_name: str | None = None) -> None:
        """Move an item's successors from _scheduled to _queued.

        'item' is the recently run job that has completed. If None, then we
        move all available items in all available cfgs in _scheduled's first
        target. If 'item' is specified, then we find its successors and move
        them to _queued.
        """
        for next_job_name in self._get_successors(job_name):
            target = self._jobs[next_job_name].target
            if next_job_name in self.job_status or next_job_name in self._queued[target]:
                msg = f"Job {next_job_name} already scheduled"
                raise RuntimeError(msg)

            self.job_status[next_job_name] = JobStatus.QUEUED
            self._queued[target].append(next_job_name)
            self._unschedule_item(next_job_name)

    def _cancel_successors(self, job_name: str) -> None:
        """Cancel an item's successors.

        Recursively move them from _scheduled or _queued to _killed.

        Args:
            job_name: job whose successors are to be canceled.

        """
        items = list(self._get_successors(job_name))
        while items:
            next_item = items.pop()
            self._cancel_item(next_item, cancel_successors=False)
            items.extend(self._get_successors(next_item))

    def _get_successor_target(self, job_name: str) -> str | None:
        """Find the first target in the scheduled list that follows the target of a given job.

        Args:
            job_name: name of the job (to find the successor target of).

        Returns:
            the successor, or None if no such target exists or there is no successor.

        """
        job: JobSpec = self._jobs[job_name]

        if job.target not in self._scheduled:
            msg = f"Scheduler does not contain target {job.target}"
            raise KeyError(msg)

        # Find the first target that follows the target in the scheduled list.
        target_iter = dropwhile(lambda x: x != job.target, self._scheduled)
        next(target_iter, None)
        return next(target_iter, None)

    def _get_successors(self, job_name: str | None = None) -> Sequence[str]:
        """Find immediate successors of an item.

        We choose the target that follows the item's current target and find
        the list of successors whose dependency list contains "job_name". If
        "job_name" is None, we pick successors from all cfgs, else we pick
        successors only from the cfg to which the item belongs.

        Args:
            job_name: name of the job

        Returns:
            list of the jobs successors, or an empty list if there are none.

        """
        if job_name is None:
            target = next(iter(self._scheduled), None)
            cfgs = set() if target is None else set(self._scheduled[target])
        else:
            target = self._get_successor_target(job_name)
            job: JobSpec = self._jobs[job_name]
            cfgs = {job.block.name}

        if target is None:
            return ()

        # Find item's successors that can be enqueued. We assume here that
        # only the immediately succeeding target can be enqueued at this
        # time.
        successors = []
        for cfg in cfgs:
            for next_item in self._scheduled[target][cfg]:
                if job_name is not None:
                    job = self._jobs[next_item]
                    if not job.dependencies:
                        raise RuntimeError(
                            "Job item exists but the next item's dependency list is empty?"
                        )
                    if job_name not in job.dependencies:
                        continue

                if self._ok_to_enqueue(next_item):
                    successors.append(next_item)

        return successors

    def _ok_to_enqueue(self, job_name: str) -> bool:
        """Check if all dependencies jobs are completed.

        Args:
            job_name: name of job.

        Returns:
            true if ALL dependencies of item are complete.

        """
        for dep in self._jobs[job_name].dependencies:
            # Ignore dependencies that were not scheduled to run.
            if dep not in self._jobs:
                continue

            # Has the dep even been enqueued?
            if dep not in self.job_status:
                return False

            # Has the dep completed?
            if not self.job_status[dep].ended:
                return False

        return True

    def _ok_to_run(self, job_name: str) -> bool:
        """Check if a job is ready to start.

        The item's needs_all_dependencies_passing setting is used to figure
        out whether we can run this item or not, based on its dependent jobs'
        statuses.

        Args:
            job_name: name of the job to check

        Returns:
            true if the required dependencies have passed.

        """
        job: JobSpec = self._jobs[job_name]
        # 'item' can run only if its dependencies have passed (their results
        # should already show up in the item to status map).
        for dep_name in job.dependencies:
            # Ignore dependencies that were not scheduled to run.
            if dep_name not in self._jobs:
                continue

            dep_status = self.job_status[dep_name]
            if not dep_status.ended:
                msg = f"Expected dependent job {dep_name} to be ended, not {dep_status.name}."
                raise ValueError(msg)

            if job.needs_all_dependencies_passing:
                if dep_status != JobStatus.PASSED:
                    return False
            elif dep_status == JobStatus.PASSED:
                return True

        return job.needs_all_dependencies_passing

    def _poll(self, hms: str) -> bool:
        """Check for running items that have finished.

        Returns:
            True if something changed.

        """
        max_poll = min(
            self._launcher_cls.max_poll,
            total_sub_items(self._running),
        )

        # If there are no jobs running, we are likely done (possibly because
        # of a SIGINT). Since poll() was called anyway, signal that something
        # has indeed changed.
        if not max_poll:
            return True

        changed = False
        while max_poll:
            target, self._last_target_polled_idx = get_next_item(
                self._targets,
                self._last_target_polled_idx,
            )

            while self._running[target] and max_poll:
                max_poll -= 1
                job_name, self._last_item_polled_idx[target] = get_next_item(
                    self._running[target],
                    self._last_item_polled_idx[target],
                )
                try:
                    status = self._launchers[job_name].poll()
                except LauncherError as e:
                    log.error("Error when dispatching target: %s", str(e))
                    status = JobStatus.KILLED
                level = log.VERBOSE

                if status == JobStatus.DISPATCHED:
                    continue

                if status == JobStatus.PASSED:
                    self._passed[target].add(job_name)
                    self._instrumentation.on_job_status_change(self._jobs[job_name], status)

                elif status == JobStatus.FAILED:
                    self._failed[target].add(job_name)
                    self._instrumentation.on_job_status_change(self._jobs[job_name], status)
                    level = log.ERROR

                else:
                    # Killed, still Queued, or some error when dispatching.
                    self._killed[target].add(job_name)
                    self._instrumentation.on_job_status_change(self._jobs[job_name], status.KILLED)
                    level = log.ERROR

                self._running[target].pop(self._last_item_polled_idx[target])
                self._last_item_polled_idx[target] -= 1
                self.job_status[job_name] = status

                log.log(
                    level,
                    "[%s]: [%s]: [status] [%s: %s]",
                    hms,
                    target,
                    job_name,
                    status.shorthand,
                )

                # Enqueue item's successors regardless of its status.
                #
                # It may be possible that a failed item's successor may not
                # need all of its dependents to pass (if it has other dependent
                # jobs). Hence we enqueue all successors rather than canceling
                # them right here. We leave it to _dispatch() to figure out
                # whether an enqueued item can be run or not.
                self._enqueue_successors(job_name)
                changed = True

        return changed

    def _dispatch_job(self, hms: str, target: str, job_name: str) -> None:
        """Dispatch the named queued job.

        Args:
            hms: time as a string formatted in hh:mm:ss
            target: the target to dispatch this job to
            job_name: the name of the job to dispatch

        """
        try:
            self._launchers[job_name].launch()

        except LauncherError:
            log.exception("Error launching %s", job_name)
            self._kill_item(job_name)

        except LauncherBusyError:
            log.exception("Launcher busy")

            self._queued[target].append(job_name)

            log.verbose(
                "[%s]: [%s]: [requeued]: %s",
                hms,
                target,
                job_name,
            )
            return

        self._running[target].append(job_name)
        self.job_status[job_name] = JobStatus.DISPATCHED
        self._instrumentation.on_job_status_change(self._jobs[job_name], JobStatus.DISPATCHED)

    def _dispatch(self, hms: str) -> None:
        """Dispatch some queued items if possible.

        Args:
            hms: time as a string formatted in hh:mm:ss

        """
        slots = self._launcher_cls.max_parallel - total_sub_items(self._running)
        if slots <= 0:
            return

        # Compute how many slots to allocate to each target based on their
        # weights.
        sum_weight = 0
        slots_filled = 0
        total_weight = sum(
            self._jobs[self._queued[t][0]].weight for t in self._queued if self._queued[t]
        )

        for target in self._scheduled:
            if not self._queued[target]:
                continue

            # N slots are allocated to M targets each with W(m) weights with
            # the formula:
            #
            # N(m) = N * W(m) / T, where,
            #   T is the sum total of all weights.
            #
            # This is however, problematic due to fractions. Even after
            # rounding off to the nearest digit, slots may not be fully
            # utilized (one extra left). An alternate approach that avoids this
            # problem is as follows:
            #
            # N(m) = (N * S(W(m)) / T) - F(m), where,
            #   S(W(m)) is the running sum of weights upto current target m.
            #   F(m) is the running total of slots filled.
            #
            # The computed slots per target is nearly identical to the first
            # solution, except that it prioritizes the slot allocation to
            # targets that are earlier in the list such that in the end, all
            # slots are fully consumed.
            sum_weight += self._jobs[self._queued[target][0]].weight
            target_slots = round((slots * sum_weight) / total_weight) - slots_filled
            if target_slots <= 0:
                continue
            slots_filled += target_slots

            to_dispatch = []
            while self._queued[target] and target_slots > 0:
                next_item = self._queued[target].pop(0)
                if not self._ok_to_run(next_item):
                    self._cancel_item(next_item, cancel_successors=False)
                    self._enqueue_successors(next_item)
                    continue

                to_dispatch.append(next_item)
                target_slots -= 1

            if not to_dispatch:
                continue

            log.verbose(
                "[%s]: [%s]: [dispatch]:\n%s",
                hms,
                target,
                ", ".join(job_name for job_name in to_dispatch),
            )

            for job_name in to_dispatch:
                self._dispatch_job(hms, target, job_name)

    def _kill(self) -> None:
        """Kill any running items and cancel any that are waiting."""
        # Cancel any waiting items. We take a copy of self._queued to avoid
        # iterating over the set as we modify it.
        for target in self._queued:
            for item in list(self._queued[target]):
                self._cancel_item(item)

        # Kill any running items. Again, take a copy of the set to avoid
        # modifying it while iterating over it.
        for target in self._running:
            for item in list(self._running[target]):
                self._kill_item(item)

    def _check_if_done(self, hms: str) -> bool:
        """Check if we are done executing all jobs.

        Also, prints the status of currently running jobs.
        """
        done = True
        for target in self._scheduled:
            done_cnt = sum(
                [
                    len(self._passed[target]),
                    len(self._failed[target]),
                    len(self._killed[target]),
                ],
            )
            done = done and (done_cnt == self._total[target])

            # Skip if a target has not even begun executing.
            if not (self._queued[target] or self._running[target] or done_cnt > 0):
                continue

            perc = done_cnt / self._total[target] * 100

            running = ", ".join(
                [f"{job_name}" for job_name in self._running[target]],
            )
            msg = self._msg_fmt.format(
                len(self._queued[target]),
                len(self._running[target]),
                len(self._passed[target]),
                len(self._failed[target]),
                len(self._killed[target]),
                self._total[target],
            )
            self._status_printer.update_target(
                target=target,
                msg=msg,
                hms=hms,
                perc=perc,
                running=running,
            )
        return done

    def _cancel_item(self, job_name: str, *, cancel_successors: bool = True) -> None:
        """Cancel an item and optionally all of its successors.

        Supplied item may be in _scheduled list or the _queued list. From
        either, we move it straight to _killed.

        Args:
            job_name: name of the job to cancel
            cancel_successors: if set then cancel successors as well (True).

        """
        job = self._jobs[job_name]
        self.job_status[job_name] = JobStatus.KILLED
        self._killed[job.target].add(job_name)
        self._instrumentation.on_job_status_change(job, JobStatus.KILLED)
        if job_name in self._queued[job.target]:
            self._queued[job.target].remove(job_name)
        else:
            self._unschedule_item(job_name)

        if cancel_successors:
            self._cancel_successors(job_name)

    def _kill_item(self, job_name: str) -> None:
        """Kill a running item and cancel all of its successors.

        Args:
            job_name: name of the job to kill

        """
        job = self._jobs[job_name]
        self._launchers[job_name].kill()
        self.job_status[job_name] = JobStatus.KILLED
        self._killed[job.target].add(job_name)
        self._instrumentation.on_job_status_change(job, JobStatus.KILLED)
        self._running[job.target].remove(job_name)
        self._cancel_successors(job_name)
