<!--
# Copyright lowRISC contributors (OpenTitan project).
# Licensed under the Apache License, Version 2.0, see LICENSE for details.
# SPDX-License-Identifier: Apache-2.0
-->
# FOO DV document

<!-- TODO: Remove "draft: true" from header before submitting -->

# testplan

{{< incGenFromIpDesc "foo_testplan.hjson" "testplan" >}}
