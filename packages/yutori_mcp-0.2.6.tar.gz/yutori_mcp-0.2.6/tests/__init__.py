"""Tests for the Yutori MCP server."""
