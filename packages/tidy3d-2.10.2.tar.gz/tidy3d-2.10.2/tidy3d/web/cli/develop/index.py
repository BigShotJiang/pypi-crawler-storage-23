"""Console script subcommand for tidy3d."""

from __future__ import annotations

import click

__all__ = [
    "develop",
]


@click.group(name="develop")
def develop() -> None:
    """
    Development related command group in the CLI.

    This command group includes several subcommands for various development tasks such as
    verifying and setting up the development environment, building documentation, testing, and more.
    """
