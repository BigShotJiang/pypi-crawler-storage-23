To use this module, you need to:

1.  Go to Sales -\> Contracts and select or create a new contract.
2.  Fill fields for selecting the recurrency and invoice parameters:
    - Type defines document that contract will generate, can be "Sales"
      or "Invoices"
    - Sale Autoconfirm, validate Sales Orders if type is "Sales"
