This module extends functionality of contracts to be able to generate
sales orders instead of invoices.
