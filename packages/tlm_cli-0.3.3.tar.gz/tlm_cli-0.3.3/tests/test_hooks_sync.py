"""
Tests for hook_session_start with server sync support.

When TLM API client is available, hook_session_start should:
1. Call GET /sync with 3s timeout
2. Write sync data to cache
3. Return context from sync data
4. Fall back to cache on timeout
5. Fall back to raw .tlm/ files if no cache
"""

import json
from unittest.mock import MagicMock, patch
from pathlib import Path

import pytest

from tlm.hooks import hook_session_start
from tlm.cache import TLMCache


SYNC_DATA = {
    "profile": "## Stack\nPython, FastAPI",
    "knowledge": "# Knowledge\nUses PostgreSQL.",
    "enforcement_config": {
        "approved": True,
        "checks": [{"name": "Tests", "command": "pytest", "blocker": True, "when": "pre_commit"}],
        "environments": {"staging": {}, "production": {}},
    },
    "specs": [{"filename": "auth-spec.md", "content": "# Auth Spec"}],
    "latest_synthesis": {
        "spec_accuracy_percent": 85,
        "interview_improvements": ["Ask about error recovery"],
    },
    "project_lessons": "Spec accuracy: 85%. Ask about error recovery.",
}


@pytest.fixture
def project_root(tmp_path):
    """Create a basic TLM project directory."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "lessons").mkdir()
    (tlm_dir / "commits").mkdir()
    (tlm_dir / "sessions").mkdir()

    # State file
    (tlm_dir / "state.json").write_text(json.dumps({
        "phase": "idle", "last_updated": "2024-01-01T00:00:00",
    }))

    # Config with project_id
    (tlm_dir / "config.json").write_text(json.dumps({
        "project_name": "test-app",
        "project_id": "42",
    }))

    # Knowledge file (fallback data)
    (tlm_dir / "knowledge.md").write_text("# Knowledge\nLocal knowledge data.")

    return tmp_path


class TestHookSessionStartSync:
    @patch("tlm.hooks.get_client")
    def test_sync_success_updates_cache(self, mock_get_client, project_root):
        """When sync succeeds, data should be cached and used for context."""
        mock_client = MagicMock()
        mock_client.sync.return_value = SYNC_DATA
        mock_get_client.return_value = mock_client

        result = hook_session_start(str(project_root))

        assert "TLM" in result
        # Should include data from sync
        mock_client.sync.assert_called_once()

    @patch("tlm.hooks.get_client")
    def test_sync_failure_falls_back_to_cache(self, mock_get_client, project_root):
        """When sync fails, should fall back to cached data."""
        from tlm.api_client import TLMConnectionError

        # Pre-populate cache
        cache = TLMCache(str(project_root / ".tlm"))
        cache.write_sync(SYNC_DATA)

        mock_client = MagicMock()
        mock_client.sync.side_effect = TLMConnectionError("timeout")
        mock_get_client.return_value = mock_client

        result = hook_session_start(str(project_root))

        # Should still return context (from cache)
        assert "TLM" in result

    @patch("tlm.hooks.get_client")
    def test_no_client_falls_back_to_files(self, mock_get_client, project_root):
        """When no API client (no auth), should read raw .tlm/ files."""
        mock_get_client.return_value = None

        result = hook_session_start(str(project_root))

        # Should still return context from local files
        assert "TLM" in result
        assert "Local knowledge data" in result or "knowledge" in result.lower()

    @patch("tlm.hooks.get_client")
    def test_sync_with_no_project_id_skips_sync(self, mock_get_client, project_root):
        """If no project_id in config, skip sync and use local files."""
        # Remove project_id from config
        config_file = project_root / ".tlm" / "config.json"
        config_file.write_text(json.dumps({"project_name": "test-app"}))

        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        result = hook_session_start(str(project_root))

        mock_client.sync.assert_not_called()
        assert "TLM" in result
