"""Tests for session_learner — builds session summaries from prompts and transcripts."""

import json
import tempfile
from pathlib import Path

import pytest

from tlm.session_learner import build_session_summary, _find_repeated_instructions, _parse_transcript


@pytest.fixture
def tlm_dir(tmp_path):
    """Create a minimal .tlm directory with state."""
    tlm = tmp_path / ".tlm"
    tlm.mkdir()
    (tlm / "state.json").write_text(json.dumps({"phase": "idle"}))
    (tlm / "config.json").write_text(json.dumps({"session_learning": True}))
    return str(tlm)


class TestBuildSessionSummary:
    def test_no_data_returns_none(self, tlm_dir):
        result = build_session_summary(tlm_dir)
        assert result is None

    def test_with_prompts(self, tlm_dir):
        prompts_file = Path(tlm_dir) / "session_prompts.jsonl"
        prompts_file.write_text(
            '{"timestamp": "2026-02-17T10:00:00", "prompt": "Build a login page"}\n'
            '{"timestamp": "2026-02-17T10:05:00", "prompt": "Add tests first"}\n'
        )
        result = build_session_summary(tlm_dir)
        assert result is not None
        assert len(result["user_prompts"]) == 2
        assert result["user_prompts"][0] == "Build a login page"
        assert result["session_duration_minutes"] == 5

    def test_caps_prompts_at_50(self, tlm_dir):
        prompts_file = Path(tlm_dir) / "session_prompts.jsonl"
        lines = []
        for i in range(60):
            lines.append(json.dumps({"timestamp": "2026-02-17T10:00:00", "prompt": f"prompt {i}"}))
        prompts_file.write_text("\n".join(lines) + "\n")

        result = build_session_summary(tlm_dir)
        assert len(result["user_prompts"]) == 50

    def test_reads_phase_from_state(self, tlm_dir):
        state_file = Path(tlm_dir) / "state.json"
        state_file.write_text(json.dumps({"phase": "implementation"}))

        prompts_file = Path(tlm_dir) / "session_prompts.jsonl"
        prompts_file.write_text('{"timestamp": "2026-02-17T10:00:00", "prompt": "test"}\n')

        result = build_session_summary(tlm_dir)
        assert result["phase_flow"] == "implementation"


class TestFindRepeatedInstructions:
    def test_exact_duplicates(self):
        prompts = ["run the tests", "build the feature", "run the tests", "run the tests"]
        result = _find_repeated_instructions(prompts)
        assert any("run the tests" in r for r in result)

    def test_short_duplicates_ignored(self):
        prompts = ["yes", "yes", "yes"]
        result = _find_repeated_instructions(prompts)
        assert len(result) == 0  # "yes" is too short (<10 chars)

    def test_no_repeats(self):
        prompts = ["build a login page", "add error handling", "deploy to staging"]
        result = _find_repeated_instructions(prompts)
        assert len(result) == 0

    def test_pattern_detection(self):
        prompts = [
            "always write tests first",
            "implement the feature. always write tests first.",
            "add validation logic",
        ]
        result = _find_repeated_instructions(prompts)
        assert any("always" in r.lower() or "test" in r.lower() for r in result)


class TestParseTranscript:
    def test_empty_file(self, tmp_path):
        t = tmp_path / "transcript.jsonl"
        t.write_text("")
        result = _parse_transcript(str(t))
        assert result["files_changed"] == []

    def test_nonexistent_file(self):
        result = _parse_transcript("/nonexistent/path.jsonl")
        assert result["files_changed"] == []

    def test_tracks_files_changed(self, tmp_path):
        t = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({"tool_name": "Write", "tool_input": {"file_path": "/src/main.py"}}),
            json.dumps({"tool_name": "Edit", "tool_input": {"file_path": "/src/utils.py"}}),
            json.dumps({"tool_name": "Read", "tool_input": {"file_path": "/src/config.py"}}),
        ]
        t.write_text("\n".join(lines) + "\n")

        result = _parse_transcript(str(t))
        assert "/src/main.py" in result["files_changed"]
        assert "/src/utils.py" in result["files_changed"]
        assert "/src/config.py" not in result["files_changed"]

    def test_counts_tools(self, tmp_path):
        t = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({"tool_name": "Write", "tool_input": {}}),
            json.dumps({"tool_name": "Write", "tool_input": {}}),
            json.dumps({"tool_name": "Bash", "tool_input": {}}),
        ]
        t.write_text("\n".join(lines) + "\n")

        result = _parse_transcript(str(t))
        assert result["tools_used"]["Write"] == 2
        assert result["tools_used"]["Bash"] == 1

    def test_deduplicates_files(self, tmp_path):
        t = tmp_path / "transcript.jsonl"
        lines = [
            json.dumps({"tool_name": "Write", "tool_input": {"file_path": "/src/main.py"}}),
            json.dumps({"tool_name": "Edit", "tool_input": {"file_path": "/src/main.py"}}),
        ]
        t.write_text("\n".join(lines) + "\n")

        result = _parse_transcript(str(t))
        assert len(result["files_changed"]) == 1
