"""
Tests for TLM Cache Manager — local cache for server sync data.

Tests cache read/write/expiry/fallback behavior.
"""

import json
import time
from pathlib import Path
from unittest.mock import patch

import pytest

from tlm.cache import TLMCache


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def cache_dir(tmp_path):
    """Create a .tlm/ directory for caching."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    return tlm_dir


@pytest.fixture
def cache(cache_dir):
    """Create a TLMCache instance."""
    return TLMCache(str(cache_dir))


SAMPLE_SYNC_DATA = {
    "knowledge": "# Knowledge\n- Uses PostgreSQL",
    "profile": "## Stack\nPython, FastAPI",
    "enforcement_config": {
        "checks": [{"name": "tests", "command": "pytest"}],
        "environments": {},
    },
    "latest_synthesis": {
        "total_commits": 5,
        "spec_accuracy_percent": 80,
        "interview_improvements": ["Ask about edge cases"],
    },
    "specs": [
        {"filename": "2026-02-15-payments.md", "content": "# Payment Spec"},
    ],
    "project_lessons": "Spec accuracy: 80%. MUST ASK: about edge cases.",
}


# ─── Write Tests ──────────────────────────────────────────────

class TestCacheWrite:
    def test_write_sync_data(self, cache, cache_dir):
        cache.write_sync(SAMPLE_SYNC_DATA)
        cache_file = cache_dir / "cache.json"
        assert cache_file.exists()

    def test_written_data_includes_timestamp(self, cache, cache_dir):
        cache.write_sync(SAMPLE_SYNC_DATA)
        data = json.loads((cache_dir / "cache.json").read_text())
        assert "synced_at" in data

    def test_write_overwrites_existing(self, cache, cache_dir):
        cache.write_sync({"knowledge": "old"})
        cache.write_sync({"knowledge": "new"})
        data = json.loads((cache_dir / "cache.json").read_text())
        assert data["data"]["knowledge"] == "new"


# ─── Read Tests ───────────────────────────────────────────────

class TestCacheRead:
    def test_read_after_write(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        data = cache.read_sync()
        assert data is not None
        assert data["knowledge"] == SAMPLE_SYNC_DATA["knowledge"]
        assert data["profile"] == SAMPLE_SYNC_DATA["profile"]

    def test_read_empty_cache(self, cache):
        data = cache.read_sync()
        assert data is None

    def test_read_corrupted_cache(self, cache, cache_dir):
        (cache_dir / "cache.json").write_text("not json at all")
        data = cache.read_sync()
        assert data is None

    def test_read_missing_data_key(self, cache, cache_dir):
        (cache_dir / "cache.json").write_text(json.dumps({"synced_at": "2026-02-15"}))
        data = cache.read_sync()
        assert data is None


# ─── Expiry Tests ─────────────────────────────────────────────

class TestCacheExpiry:
    def test_fresh_cache_not_stale(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        assert not cache.is_stale()

    def test_old_cache_is_stale(self, cache, cache_dir):
        # Write cache with old timestamp
        cache_data = {
            "synced_at": "2020-01-01T00:00:00",
            "data": SAMPLE_SYNC_DATA,
        }
        (cache_dir / "cache.json").write_text(json.dumps(cache_data))
        assert cache.is_stale()

    def test_missing_cache_is_stale(self, cache):
        assert cache.is_stale()

    def test_custom_ttl(self, cache_dir):
        cache = TLMCache(str(cache_dir), ttl_seconds=1)
        cache.write_sync(SAMPLE_SYNC_DATA)
        assert not cache.is_stale()
        # Sleep past TTL
        time.sleep(1.1)
        assert cache.is_stale()


# ─── Individual Field Access ──────────────────────────────────

class TestCacheFields:
    def test_get_knowledge(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        assert cache.get_knowledge() == SAMPLE_SYNC_DATA["knowledge"]

    def test_get_profile(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        assert cache.get_profile() == SAMPLE_SYNC_DATA["profile"]

    def test_get_enforcement_config(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        config = cache.get_enforcement_config()
        assert config["checks"][0]["name"] == "tests"

    def test_get_latest_synthesis(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        synthesis = cache.get_latest_synthesis()
        assert synthesis["total_commits"] == 5

    def test_get_specs(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        specs = cache.get_specs()
        assert len(specs) == 1
        assert specs[0]["filename"] == "2026-02-15-payments.md"

    def test_get_project_lessons(self, cache):
        cache.write_sync(SAMPLE_SYNC_DATA)
        lessons = cache.get_project_lessons()
        assert "80%" in lessons

    def test_get_field_no_cache(self, cache):
        assert cache.get_knowledge() is None
        assert cache.get_profile() is None
        assert cache.get_enforcement_config() is None
        assert cache.get_latest_synthesis() is None
        assert cache.get_specs() is None
        assert cache.get_project_lessons() is None


# ─── Fallback Tests ───────────────────────────────────────────

class TestCacheFallback:
    def test_fallback_to_raw_knowledge(self, cache, cache_dir):
        """When cache is empty, fall back to reading .tlm/knowledge.md directly."""
        (cache_dir / "knowledge.md").write_text("# Raw Knowledge\n- Direct file")
        knowledge = cache.get_knowledge_with_fallback()
        assert "Raw Knowledge" in knowledge

    def test_fallback_to_raw_profile(self, cache, cache_dir):
        (cache_dir / "profile.md").write_text("## Raw Profile\nPython stack")
        profile = cache.get_profile_with_fallback()
        assert "Raw Profile" in profile

    def test_fallback_to_raw_enforcement(self, cache, cache_dir):
        config = {"checks": [{"name": "lint"}], "approved": True}
        (cache_dir / "enforcement.json").write_text(json.dumps(config))
        result = cache.get_enforcement_config_with_fallback()
        assert result["checks"][0]["name"] == "lint"

    def test_cache_preferred_over_fallback(self, cache, cache_dir):
        """Cache should be preferred over raw files."""
        (cache_dir / "knowledge.md").write_text("# Raw old knowledge")
        cache.write_sync(SAMPLE_SYNC_DATA)
        knowledge = cache.get_knowledge_with_fallback()
        assert "PostgreSQL" in knowledge  # From cache, not raw file

    def test_fallback_returns_none_if_nothing(self, cache):
        assert cache.get_knowledge_with_fallback() is None
        assert cache.get_profile_with_fallback() is None
        assert cache.get_enforcement_config_with_fallback() is None


# ─── Clear Tests ──────────────────────────────────────────────

class TestCacheClear:
    def test_clear_cache(self, cache, cache_dir):
        cache.write_sync(SAMPLE_SYNC_DATA)
        cache.clear()
        assert cache.read_sync() is None

    def test_clear_nonexistent_cache(self, cache):
        # Should not raise
        cache.clear()
