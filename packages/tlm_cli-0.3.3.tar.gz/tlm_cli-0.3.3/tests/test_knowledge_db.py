"""Tests for KnowledgeDB — SQLite knowledge store with vector search."""

import json
import tempfile
import os
from pathlib import Path

import pytest
from tlm.knowledge_db import KnowledgeDB, _vec_to_blob, _blob_to_vec, _cosine_similarity


@pytest.fixture
def db(tmp_path):
    """Create a fresh KnowledgeDB in a temp directory."""
    db = KnowledgeDB(str(tmp_path))
    db.init_db()
    yield db
    db.close()


class TestInitDB:
    def test_creates_tables(self, db):
        tables = db.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        table_names = {t["name"] for t in tables}
        assert "rules" in table_names
        assert "specs" in table_names
        assert "commits" in table_names
        assert "metrics" in table_names

    def test_idempotent(self, db):
        """Calling init_db twice doesn't break anything."""
        db.init_db()
        tables = db.conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table'"
        ).fetchall()
        assert len(tables) >= 4


class TestRules:
    def test_add_and_list(self, db):
        rule_id = db.add_rule("Always write tests first", source="user_added", tags=["testing"])
        assert rule_id > 0

        rules = db.list_rules()
        assert len(rules) == 1
        assert rules[0]["rule_text"] == "Always write tests first"
        assert rules[0]["source"] == "user_added"
        assert rules[0]["relevance_tags"] == ["testing"]
        assert rules[0]["approved"] == 1

    def test_disable_and_enable(self, db):
        rule_id = db.add_rule("Test rule")
        db.disable_rule(rule_id)

        # Disabled rules don't show in default list
        assert len(db.list_rules()) == 0
        # But show in full list
        assert len(db.list_rules(include_disabled=True)) == 1

        db.enable_rule(rule_id)
        assert len(db.list_rules()) == 1

    def test_get_rule(self, db):
        rule_id = db.add_rule("Specific rule", source="base")
        rule = db.get_rule(rule_id)
        assert rule is not None
        assert rule["rule_text"] == "Specific rule"

    def test_get_nonexistent_rule(self, db):
        assert db.get_rule(999) is None

    def test_add_with_embedding(self, db):
        embedding = [0.1, 0.2, 0.3, 0.4]
        rule_id = db.add_rule("Rule with vector", embedding=embedding)
        rule = db.get_rule(rule_id)
        assert rule["has_embedding"] is True


class TestVectorSearch:
    def test_cosine_similarity(self):
        assert _cosine_similarity([1, 0, 0], [1, 0, 0]) == pytest.approx(1.0)
        assert _cosine_similarity([1, 0, 0], [0, 1, 0]) == pytest.approx(0.0)
        assert _cosine_similarity([1, 0, 0], [-1, 0, 0]) == pytest.approx(-1.0)

    def test_vec_roundtrip(self):
        vec = [0.1, 0.2, 0.3, 0.4, 0.5]
        blob = _vec_to_blob(vec)
        restored = _blob_to_vec(blob)
        for a, b in zip(vec, restored):
            assert a == pytest.approx(b, abs=1e-6)

    def test_search_by_embedding(self, db):
        # Add rules with embeddings
        db.add_rule("Testing rule", tags=["testing"], embedding=[1.0, 0.0, 0.0])
        db.add_rule("Security rule", tags=["security"], embedding=[0.0, 1.0, 0.0])
        db.add_rule("Deploy rule", tags=["deployment"], embedding=[0.0, 0.0, 1.0])

        # Search for something similar to testing
        results = db.search_rules([0.9, 0.1, 0.0], limit=2)
        assert len(results) == 2
        assert results[0]["rule_text"] == "Testing rule"

    def test_search_fallback_no_embeddings(self, db):
        """When no rules have embeddings, falls back to most recent."""
        db.add_rule("Rule 1")
        db.add_rule("Rule 2")
        db.add_rule("Rule 3")

        results = db.search_rules([1.0, 0.0], limit=2)
        assert len(results) == 2

    def test_search_by_tags(self, db):
        db.add_rule("Test rule", tags=["testing", "tdd"])
        db.add_rule("Security rule", tags=["security"])
        db.add_rule("Deploy rule", tags=["deployment"])

        results = db.search_rules_by_tags(["testing"], limit=5)
        assert len(results) == 1
        assert results[0]["rule_text"] == "Test rule"


class TestSpecs:
    def test_add_and_list(self, db):
        spec_id = db.add_spec("Login Feature", "Build a login with email/password")
        assert spec_id > 0

        specs = db.list_specs()
        assert len(specs) == 1
        assert specs[0]["feature_name"] == "Login Feature"

    def test_add_with_review(self, db):
        review = {"severity": "pass", "gaps": []}
        spec_id = db.add_spec("Feature", "content", review_result=review)
        specs = db.list_specs()
        assert specs[0]["review_result"] == review


class TestCommits:
    def test_add_and_list(self, db):
        commit_id = db.add_commit("abc123", category="bug_fix")
        assert commit_id > 0

        commits = db.list_commits()
        assert len(commits) == 1
        assert commits[0]["hash"] == "abc123"
        assert commits[0]["category"] == "bug_fix"

    def test_duplicate_hash_ignored(self, db):
        db.add_commit("abc123", category="bug_fix")
        db.add_commit("abc123", category="feature_work")  # Duplicate

        commits = db.list_commits()
        assert len(commits) == 1
        assert commits[0]["category"] == "bug_fix"  # First one wins


class TestMetrics:
    def test_add_and_list(self, db):
        db.add_metric("2026-W07", spec_accuracy=75.0, total_commits=10,
                       planned_commits=7, unplanned_commits=3)

        metrics = db.list_metrics()
        assert len(metrics) == 1
        assert metrics[0]["spec_accuracy"] == 75.0
        assert metrics[0]["total_commits"] == 10


class TestMigration:
    def test_migrate_knowledge_md(self, tmp_path):
        # Create a knowledge.md file
        knowledge = tmp_path / "knowledge.md"
        knowledge.write_text("""# TLM Knowledge Base
_Initialized 2026-02-01_

---
_Session: 2026-02-15_

- Always validate email before saving
- Use UTC timestamps everywhere
""")

        db = KnowledgeDB(str(tmp_path))
        db.init_db()
        imported = db.migrate_from_flat_files()

        assert imported["rules"] == 2
        rules = db.list_rules()
        assert any("email" in r["rule_text"] for r in rules)
        db.close()

    def test_migrate_commits(self, tmp_path):
        commits_dir = tmp_path / "commits"
        commits_dir.mkdir()
        (commits_dir / "abc123.json").write_text(json.dumps({
            "hash": "abc123",
            "category": "bug_fix",
            "lessons": [{"type": "missed_edge_case"}],
        }))

        db = KnowledgeDB(str(tmp_path))
        db.init_db()
        imported = db.migrate_from_flat_files()

        assert imported["commits"] == 1
        commits = db.list_commits()
        assert commits[0]["hash"] == "abc123"
        db.close()

    def test_migrate_specs(self, tmp_path):
        specs_dir = tmp_path / "specs"
        specs_dir.mkdir()
        (specs_dir / "2026-02-15-login.md").write_text("# Login Feature\n\nBuild login with email.")

        db = KnowledgeDB(str(tmp_path))
        db.init_db()
        imported = db.migrate_from_flat_files()

        assert imported["specs"] == 1
        specs = db.list_specs()
        assert specs[0]["feature_name"] == "Login Feature"
        db.close()

    def test_migrate_synthesis(self, tmp_path):
        lessons_dir = tmp_path / "lessons"
        lessons_dir.mkdir()
        (lessons_dir / "2026-02-15-synthesis.json").write_text(json.dumps({
            "period": "2026-02-01 to 2026-02-15",
            "spec_accuracy_percent": 65,
            "total_commits": 10,
            "planned_commits": 6,
            "unplanned_commits": 4,
            "interview_improvements": ["Ask about error handling"],
        }))

        db = KnowledgeDB(str(tmp_path))
        db.init_db()
        imported = db.migrate_from_flat_files()

        assert imported["metrics"] == 1
        assert imported["rules"] >= 1  # interview improvement becomes a rule

        metrics = db.list_metrics()
        assert metrics[0]["spec_accuracy"] == 65
        db.close()
