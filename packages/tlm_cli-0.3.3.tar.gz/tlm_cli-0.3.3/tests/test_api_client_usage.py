"""
Tests for CLI api_client.py — usage exceptions and usage() method.
"""

import json
from unittest.mock import patch, MagicMock

import pytest

from tlm.api_client import TLMClient, TLMAuthError, TLMServerError


class TestCreditsError:
    """Test TLMCreditsError for 402 responses."""

    def test_credits_error_exists(self):
        from tlm.api_client import TLMCreditsError
        assert issubclass(TLMCreditsError, Exception)

    def test_credits_error_fields(self):
        from tlm.api_client import TLMCreditsError
        err = TLMCreditsError({
            "credits_remaining": 0,
            "tier": "free",
            "upgrade_url": "https://tlmforge.dev/#pricing",
        })
        assert err.args[0]["credits_remaining"] == 0
        assert err.args[0]["tier"] == "free"

    @patch("httpx.post")
    def test_402_raises_credits_error(self, mock_post):
        from tlm.api_client import TLMCreditsError
        mock_resp = MagicMock()
        mock_resp.status_code = 402
        mock_resp.json.return_value = {
            "detail": {
                "error": "credits_exhausted",
                "credits_remaining": 0,
                "tier": "free",
                "upgrade_url": "https://tlmforge.dev/#pricing",
            }
        }
        mock_post.return_value = mock_resp

        client = TLMClient(api_key="test-key")
        with pytest.raises(TLMCreditsError):
            client.scan("1", "tree", "samples")


class TestProjectLimitError:
    """Test TLMProjectLimitError class still exists for backwards compat."""

    def test_project_limit_error_exists(self):
        from tlm.api_client import TLMProjectLimitError
        assert issubclass(TLMProjectLimitError, Exception)

    @patch("httpx.get")
    def test_403_auth_still_raises_auth_error(self, mock_get):
        """Regular 403 (not project limit) should still raise TLMAuthError."""
        mock_resp = MagicMock()
        mock_resp.status_code = 403
        mock_resp.json.return_value = {"detail": "Not authenticated"}
        mock_get.return_value = mock_resp

        client = TLMClient(api_key="bad-key")
        with pytest.raises(TLMAuthError):
            client.me()


class TestUsageMethod:
    """Test the usage() method on TLMClient."""

    @patch("httpx.get")
    def test_usage_method_exists(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "credits_total": 150,
            "credits_used": 50,
            "credits_remaining": 950,
            "tier": "free",
        }
        mock_get.return_value = mock_resp

        client = TLMClient(api_key="test-key")
        result = client.usage()
        assert result["credits_remaining"] == 950

    @patch("httpx.get")
    def test_usage_calls_correct_endpoint(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {"credits_total": 150}
        mock_get.return_value = mock_resp

        client = TLMClient(api_key="test-key")
        client.usage()

        call_args = mock_get.call_args
        assert "/usage" in call_args[0][0]
