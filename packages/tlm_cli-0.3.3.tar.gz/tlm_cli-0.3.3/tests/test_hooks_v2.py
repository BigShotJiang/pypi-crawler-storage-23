"""Tests for v2 hook upgrades — blocking gates, quality control, deployment gate."""

import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.hooks import (
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_prompt_submit,
    hook_stop,
    _is_deploy_command,
    _is_git_commit,
    _is_test_file,
    _is_test_file_heuristic,
    _match_test_patterns,
    _get_test_patterns,
    _get_quality_level,
    _capture_prompt,
)


@pytest.fixture
def project_dir(tmp_path):
    """Create a minimal TLM project directory."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()

    config = {
        "project_name": "test-project",
        "quality_control": "standard",
        "session_learning": True,
    }
    (tlm_dir / "config.json").write_text(json.dumps(config))

    state = {"phase": "idle", "activity_type": None, "active_spec": None}
    (tlm_dir / "state.json").write_text(json.dumps(state))

    return tmp_path


def _set_state(project_dir, phase, activity_type=None, active_spec=None,
               spec_review_status="none"):
    state = {"phase": phase, "activity_type": activity_type, "active_spec": active_spec,
             "spec_review_status": spec_review_status}
    (project_dir / ".tlm" / "state.json").write_text(json.dumps(state))


def _set_quality(project_dir, level):
    config_file = project_dir / ".tlm" / "config.json"
    config = json.loads(config_file.read_text())
    config["quality_control"] = level
    config_file.write_text(json.dumps(config))


# ─── Spec Gate (hook_guard) ─────────────────────────────────

class TestSpecGate:
    def test_idle_allows_everything(self, project_dir):
        _set_state(project_dir, "idle")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/src/main.py"},
        })
        assert result == {}

    def test_tlm_active_blocks_source_code(self, project_dir):
        _set_state(project_dir, "tlm_active")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/src/main.py"},
        })
        assert result.get("decision") == "block"
        assert "discovery interview" in result.get("reason", "").lower()

    def test_tlm_active_allows_test_files(self, project_dir):
        _set_state(project_dir, "tlm_active")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/src/tests/test_main.py"},
        })
        assert result == {}

    def test_tlm_active_allows_tlm_dir(self, project_dir):
        _set_state(project_dir, "tlm_active")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/project/.tlm/state.json"},
        })
        assert result == {}

    def test_implementation_warns_non_test(self, project_dir):
        _set_state(project_dir, "implementation", spec_review_status="approved")
        # Pre-populate session test tracking with a non-matching test file so the
        # hook reaches the additionalContext "warn" path rather than the hard block
        # that fires when no test files have been written in the session at all.
        cache_dir = project_dir / ".tlm" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "session_tests.json").write_text(
            json.dumps({"test_files_written": ["/tests/test_other.py"], "session_start": "2026-02-18T00:00:00"})
        )
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/src/main.py"},
        })
        assert "additionalContext" in result
        assert "tdd" in result["additionalContext"].lower()

    def test_implementation_no_warn_test(self, project_dir):
        _set_state(project_dir, "implementation")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/tests/test_main.py"},
        })
        assert result == {}

    def test_non_write_tools_ignored(self, project_dir):
        _set_state(project_dir, "tlm_active")
        result = hook_guard(str(project_dir), {
            "tool_name": "Read",
            "tool_input": {"file_path": "/src/main.py"},
        })
        assert result == {}

    def test_edit_tool_also_blocked(self, project_dir):
        _set_state(project_dir, "tlm_active")
        result = hook_guard(str(project_dir), {
            "tool_name": "Edit",
            "tool_input": {"file_path": "/src/main.py"},
        })
        assert result.get("decision") == "block"


# ─── Compliance Gate (hook_compliance_gate) ──────────────────

class TestComplianceGate:
    def test_non_commit_ignored(self, project_dir):
        result = hook_compliance_gate(str(project_dir), {
            "command": "ls -la",
        })
        assert result == {}

    def test_git_commit_detected(self, project_dir):
        """Git commit triggers compliance check — at minimum returns something."""
        with patch("tlm.hooks._run_mechanical_checks", return_value=[]):
            with patch("tlm.hooks.get_client", return_value=None):
                result = hook_compliance_gate(str(project_dir), {
                    "command": "git commit -m 'test'",
                })
                # Standard quality with no server → fallback context
                assert "additionalContext" in result or result == {}

    def test_relaxed_skips_llm_review(self, project_dir):
        _set_quality(project_dir, "relaxed")
        with patch("tlm.hooks._run_mechanical_checks", return_value=[]):
            result = hook_compliance_gate(str(project_dir), {
                "command": "git commit -m 'test'",
            })
            assert "additionalContext" in result
            assert "compliance" in result["additionalContext"].lower()

    def test_mechanical_failure_blocks_high(self, project_dir):
        _set_quality(project_dir, "high")
        with patch("tlm.hooks._run_mechanical_checks", return_value=["tests: 2 tests failed"]):
            result = hook_compliance_gate(str(project_dir), {
                "command": "git commit -m 'test'",
            })
            assert result.get("decision") == "block"
            assert "mechanical checks failed" in result.get("reason", "").lower()

    def test_mechanical_failure_blocks_standard(self, project_dir):
        _set_quality(project_dir, "standard")
        with patch("tlm.hooks._run_mechanical_checks", return_value=["lint: errors found"]):
            result = hook_compliance_gate(str(project_dir), {
                "command": "git commit -m 'test'",
            })
            assert result.get("decision") == "block"

    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff content")
    @patch("tlm.hooks._get_changed_files", return_value=["src/main.py"])
    def test_high_blocks_on_review_issues(self, mock_files, mock_diff, mock_mech, mock_client, project_dir):
        _set_quality(project_dir, "high")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "block",
            "models_used": ["gemini-2.5-pro"],
            "reviews": [{"issues": [{"severity": "error", "description": "SQL injection"}]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(project_dir), {
            "command": "git commit -m 'test'",
        })
        assert result.get("decision") == "block"
        assert "review blocked" in result.get("reason", "").lower()

    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff content")
    @patch("tlm.hooks._get_changed_files", return_value=["src/main.py"])
    def test_standard_warns_on_review_issues(self, mock_files, mock_diff, mock_mech, mock_client, project_dir):
        _set_quality(project_dir, "standard")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "warn",
            "models_used": ["gemini-2.5-pro"],
            "reviews": [{"issues": [{"severity": "warning", "description": "Missing null check"}]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(project_dir), {
            "command": "git commit -m 'test'",
        })
        assert "additionalContext" in result
        assert "warnings" in result["additionalContext"].lower()

    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff content")
    @patch("tlm.hooks._get_changed_files", return_value=["src/main.py"])
    def test_review_pass_allows(self, mock_files, mock_diff, mock_mech, mock_client, project_dir):
        _set_quality(project_dir, "standard")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "pass",
            "models_used": ["gemini-2.5-pro"],
            "reviews": [],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(project_dir), {
            "command": "git commit -m 'test'",
        })
        assert result == {}

    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="")
    def test_no_diff_skips_review(self, mock_diff, mock_mech, mock_client, project_dir):
        _set_quality(project_dir, "standard")
        mock_client.return_value = MagicMock()

        result = hook_compliance_gate(str(project_dir), {
            "command": "git commit -m 'test'",
        })
        assert result == {}

    def test_no_tlm_dir_allows(self, tmp_path):
        result = hook_compliance_gate(str(tmp_path), {
            "command": "git commit -m 'test'",
        })
        assert result == {}


# ─── Deployment Gate (hook_deployment_gate) ──────────────────

class TestDeploymentGate:
    def test_non_deploy_ignored(self, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "git push origin feature-branch",
        })
        assert result == {}

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_deploy_always_blocks(self, mock_mech, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "firebase deploy",
        })
        assert result.get("decision") == "block"
        assert "deployment gate" in result.get("reason", "").lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=["tests failed"])
    def test_deploy_blocks_with_failures(self, mock_mech, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "fly deploy",
        })
        assert result.get("decision") == "block"
        assert "mechanical checks failed" in result.get("reason", "").lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_docker_push_blocked(self, mock_mech, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "docker push myimage:latest",
        })
        assert result.get("decision") == "block"

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_git_push_main_blocked(self, mock_mech, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "git push origin main",
        })
        assert result.get("decision") == "block"

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_git_push_production_blocked(self, mock_mech, project_dir):
        result = hook_deployment_gate(str(project_dir), {
            "command": "git push origin production",
        })
        assert result.get("decision") == "block"

    def test_no_tlm_dir_allows(self, tmp_path):
        result = hook_deployment_gate(str(tmp_path), {
            "command": "firebase deploy",
        })
        assert result == {}


# ─── Deploy Command Detection ───────────────────────────────

class TestIsDeployCommand:
    def test_firebase_deploy(self):
        assert _is_deploy_command("firebase deploy") is True

    def test_fly_deploy(self):
        assert _is_deploy_command("fly deploy") is True

    def test_docker_push(self):
        assert _is_deploy_command("docker push myimage:v1") is True

    def test_git_push_main(self):
        assert _is_deploy_command("git push origin main") is True

    def test_git_push_production(self):
        assert _is_deploy_command("git push origin production") is True

    def test_git_push_feature_branch(self):
        assert _is_deploy_command("git push origin feature-branch") is False

    def test_kubectl_apply_prod(self):
        assert _is_deploy_command("kubectl apply -f deploy.yaml --context prod") is True

    def test_helm_upgrade(self):
        assert _is_deploy_command("helm upgrade my-release chart/") is True

    def test_sam_deploy(self):
        assert _is_deploy_command("sam deploy --guided") is True

    def test_ls_not_deploy(self):
        assert _is_deploy_command("ls -la") is False

    def test_git_commit_not_deploy(self):
        assert _is_deploy_command("git commit -m 'deploy mention'") is False


# ─── Git Commit Detection ───────────────────────────────────

class TestIsGitCommit:
    def test_simple_commit(self):
        assert _is_git_commit("git commit -m 'test'") is True

    def test_commit_amend(self):
        assert _is_git_commit("git commit --amend") is True

    def test_not_commit(self):
        assert _is_git_commit("git push origin main") is False

    def test_git_status(self):
        assert _is_git_commit("git status") is False


# ─── Test File Detection ────────────────────────────────────

class TestIsTestFile:
    """Tests for _is_test_file with heuristic fallback (no enforcement config)."""

    def test_test_prefix(self):
        assert _is_test_file("/src/tests/test_main.py") is True

    def test_test_suffix(self):
        assert _is_test_file("/src/main_test.py") is True

    def test_spec_file(self):
        assert _is_test_file("/src/main.spec.js") is True

    def test_regular_file(self):
        assert _is_test_file("/src/main.py") is False

    def test_jest_tests_dir(self):
        assert _is_test_file("/src/__tests__/main.js") is True

    def test_test_data_not_matched_by_heuristic(self):
        """test_data/ directory should NOT match as a test file."""
        assert _is_test_file_heuristic("/src/test_data/config.yaml") is False

    def test_test_fixtures_not_matched_by_heuristic(self):
        """test_fixtures/ directory should NOT match as a test file."""
        assert _is_test_file_heuristic("/src/test_fixtures/sample.json") is False


class TestIsTestFileWithEnforcement:
    """Tests for _is_test_file with LLM-derived test_patterns from enforcement.json."""

    def _write_enforcement(self, project_dir, test_patterns):
        enforcement = {"approved": True, "test_patterns": test_patterns}
        enforcement_file = project_dir / ".tlm" / "enforcement.json"
        enforcement_file.write_text(json.dumps(enforcement))

    def test_python_patterns_from_config(self, project_dir):
        self._write_enforcement(project_dir, {
            "directories": ["tests/"],
            "file_globs": ["test_*.py", "*_test.py"],
        })
        assert _is_test_file("/app/tests/test_auth.py", str(project_dir)) is True
        assert _is_test_file("/app/src/auth.py", str(project_dir)) is False

    def test_go_patterns_from_config(self, project_dir):
        self._write_enforcement(project_dir, {
            "directories": [],
            "file_globs": ["*_test.go"],
        })
        assert _is_test_file("/app/handler_test.go", str(project_dir)) is True
        assert _is_test_file("/app/handler.go", str(project_dir)) is False

    def test_js_patterns_from_config(self, project_dir):
        self._write_enforcement(project_dir, {
            "directories": ["__tests__/"],
            "file_globs": ["*.test.ts", "*.spec.ts"],
        })
        assert _is_test_file("/app/__tests__/app.js", str(project_dir)) is True
        assert _is_test_file("/app/utils.test.ts", str(project_dir)) is True
        assert _is_test_file("/app/utils.ts", str(project_dir)) is False

    def test_test_data_not_matched_with_config(self, project_dir):
        """test_data/ is NOT a test directory when enforcement config is present."""
        self._write_enforcement(project_dir, {
            "directories": ["tests/"],
            "file_globs": ["test_*.py"],
        })
        assert _is_test_file("/app/test_data/config.yaml", str(project_dir)) is False

    def test_falls_back_without_enforcement(self, project_dir):
        """Without enforcement.json, falls back to heuristic."""
        # No enforcement.json written
        assert _is_test_file("/app/tests/test_main.py", str(project_dir)) is True

    def test_falls_back_without_test_patterns(self, project_dir):
        """enforcement.json without test_patterns falls back to heuristic."""
        enforcement = {"approved": True, "checks": []}
        (project_dir / ".tlm" / "enforcement.json").write_text(json.dumps(enforcement))
        assert _is_test_file("/app/tests/test_main.py", str(project_dir)) is True

    def test_match_test_patterns_directory(self):
        patterns = {"directories": ["spec/", "tests/"], "file_globs": []}
        assert _match_test_patterns("/app/spec/auth_spec.rb", patterns) is True
        assert _match_test_patterns("/app/src/main.rb", patterns) is False

    def test_match_test_patterns_glob(self):
        patterns = {"directories": [], "file_globs": ["*_spec.rb", "*Spec.hs"]}
        assert _match_test_patterns("/app/auth_spec.rb", patterns) is True
        assert _match_test_patterns("/app/AuthSpec.hs", patterns) is True
        assert _match_test_patterns("/app/main.rb", patterns) is False

    def test_get_test_patterns_invalid_json(self, project_dir):
        (project_dir / ".tlm" / "enforcement.json").write_text("not json")
        assert _get_test_patterns(str(project_dir)) is None


# ─── Quality Level ──────────────────────────────────────────

class TestGetQualityLevel:
    def test_default_standard(self, tmp_path):
        assert _get_quality_level(str(tmp_path)) == "standard"

    def test_reads_from_config(self, project_dir):
        _set_quality(project_dir, "high")
        assert _get_quality_level(str(project_dir)) == "high"

    def test_malformed_config(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        (tlm_dir / "config.json").write_text("invalid json")
        assert _get_quality_level(str(tmp_path)) == "standard"


# ─── Prompt Capture ─────────────────────────────────────────

class TestPromptCapture:
    def test_captures_prompt(self, project_dir):
        _capture_prompt(str(project_dir), "Build a login page")
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        assert prompts_file.exists()
        line = json.loads(prompts_file.read_text().strip())
        assert line["prompt"] == "Build a login page"
        assert "timestamp" in line

    def test_appends_multiple(self, project_dir):
        _capture_prompt(str(project_dir), "First prompt")
        _capture_prompt(str(project_dir), "Second prompt")
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        lines = prompts_file.read_text().strip().split("\n")
        assert len(lines) == 2

    def test_caps_at_500_chars(self, project_dir):
        long_prompt = "x" * 1000
        _capture_prompt(str(project_dir), long_prompt)
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        line = json.loads(prompts_file.read_text().strip())
        assert len(line["prompt"]) == 500

    def test_respects_session_learning_off(self, project_dir):
        config_file = project_dir / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        config["session_learning"] = False
        config_file.write_text(json.dumps(config))

        _capture_prompt(str(project_dir), "Should not be saved")
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        assert not prompts_file.exists()

    def test_no_tlm_dir(self, tmp_path):
        # Should not crash
        _capture_prompt(str(tmp_path), "test")


# ─── Prompt Submit Hook ────────────────────────────────────

class TestPromptSubmit:
    def test_idle_phase(self, project_dir):
        result = hook_prompt_submit(str(project_dir))
        assert "additionalContext" in result
        assert "classify" in result["additionalContext"].lower()

    def test_tlm_active_phase(self, project_dir):
        _set_state(project_dir, "tlm_active", "new_feature")
        result = hook_prompt_submit(str(project_dir))
        assert "interview" in result["additionalContext"].lower()

    def test_implementation_phase(self, project_dir):
        _set_state(project_dir, "implementation")
        result = hook_prompt_submit(str(project_dir))
        assert "tdd" in result["additionalContext"].lower()

    def test_captures_prompt_text(self, project_dir):
        hook_prompt_submit(str(project_dir), prompt_text="Build a feature")
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        assert prompts_file.exists()


# ─── Stop Hook ──────────────────────────────────────────────

class TestStopHook:
    def test_no_tlm_dir(self, tmp_path):
        result = hook_stop(str(tmp_path))
        assert result == {}

    def test_no_prompts_file(self, project_dir):
        result = hook_stop(str(project_dir))
        assert result == {}

    def test_session_learning_disabled(self, project_dir):
        config_file = project_dir / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        config["session_learning"] = False
        config_file.write_text(json.dumps(config))

        # Create prompts file
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text('{"timestamp": "2026-02-17T10:00:00", "prompt": "test"}\n')

        result = hook_stop(str(project_dir))
        assert result == {}

    @patch("tlm.hooks.get_client")
    def test_stop_with_inferred_rules(self, mock_client, project_dir):
        # Create prompts file
        prompts_file = project_dir / ".tlm" / "session_prompts.jsonl"
        prompts_file.write_text('{"timestamp": "2026-02-17T10:00:00", "prompt": "test prompt"}\n')

        client = MagicMock()
        client.learn_session.return_value = {
            "inferred_rules": [
                {"rule_text": "Always test first", "tags": ["testing"]},
            ],
            "workflow_patterns": [],
        }
        mock_client.return_value = client

        result = hook_stop(str(project_dir))
        assert "additionalContext" in result
        assert "1 new pattern" in result["additionalContext"]

        # Bug 1 regression: prompts file must be cleaned up on success path
        assert not prompts_file.exists(), "session_prompts.jsonl should be deleted after learning"
