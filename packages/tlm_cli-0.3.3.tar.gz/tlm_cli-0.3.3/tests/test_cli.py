"""
Tests for TLM CLI — auth (manual + interactive), signup deprecation, error messages,
config approval menu, background analysis, lockfile management, status display.
"""

import json
import os
import signal
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock, call, mock_open

import pytest

from tlm.cli import (
    cmd_auth, cmd_logout, cmd_signup, main, _get_backend,
    _interactive_config_approval, cmd_learn, cmd_status, cmd_install,
)
from tlm.api_client import TLMAuthError, TLMConnectionError, TLMServerError, DEFAULT_BASE_URL
from tlm.engine import Project


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def credentials_dir(tmp_path):
    """Temporary directory for credentials."""
    cred_dir = tmp_path / ".tlm"
    cred_dir.mkdir()
    return str(cred_dir)


@pytest.fixture
def cred_file(credentials_dir):
    """Path to the credentials.json in tmp dir."""
    return Path(credentials_dir) / "credentials.json"


# ─── cmd_auth manual key Tests ────────────────────────────────

class TestCmdAuth:
    @patch("tlm.cli.save_credentials")
    def test_manual_key_saves(self, mock_save):
        """tlm auth <key> saves the API key."""
        cmd_auth(api_key="tlm_sk_test123")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url=None)

    @patch("tlm.cli.save_credentials")
    def test_manual_key_with_url(self, mock_save):
        """tlm auth <key> --url <url> saves both key and URL."""
        cmd_auth(api_key="tlm_sk_test123", base_url="http://localhost:8000")
        mock_save.assert_called_once_with("tlm_sk_test123", base_url="http://localhost:8000")

    def test_manual_key_rejects_invalid(self):
        """tlm auth rejects keys not starting with tlm_sk_."""
        with pytest.raises(SystemExit):
            cmd_auth(api_key="bad_key_format")

    @patch("tlm.cli.save_credentials")
    def test_manual_key_none_url_preserves(self, mock_save):
        """When no --url is given, base_url=None is passed (preserves existing)."""
        cmd_auth(api_key="tlm_sk_abc")
        _, kwargs = mock_save.call_args
        assert kwargs["base_url"] is None


# ─── cmd_auth interactive Tests ──────────────────────────────

class TestCmdAuthInteractive:
    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_prints_auth_url(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """Interactive auth prints the server auth page URL."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        out = capsys.readouterr().out
        assert "tlmforge.dev" in out

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_prompts_for_key_paste(self, mock_cls, mock_save, mock_input, mock_gc):
        """Interactive auth calls input() to prompt for key."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        mock_input.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_valid_key_paste_saves(self, mock_cls, mock_save, mock_input, mock_gc):
        """Pasting a valid key saves it."""
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        mock_save.assert_called_once()
        saved_key = mock_save.call_args[0][0]
        assert saved_key == "tlm_sk_abc123"

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMTIzIiwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIiwiaWF0IjoxNjk5MDAwMDAwfQ.dGhpc19pc19hX2Zha2Vfc2lnbmF0dXJlX2Zvcl90ZXN0aW5nX3B1cnBvc2Vz")
    @patch("tlm.cli.TLMClient")
    @patch("tlm.cli.save_credentials")
    def test_firebase_token_paste_exchanges(self, mock_save, mock_cls, mock_input, mock_gc):
        """Pasting a Firebase token (JWT) exchanges it for a TLM key."""
        mock_client = MagicMock()
        mock_client.exchange_firebase_token.return_value = {
            "api_key": "tlm_sk_from_firebase",
            "email": "user@example.com",
        }
        mock_client.me.return_value = {"email": "user@example.com"}
        mock_cls.return_value = mock_client
        cmd_auth()
        mock_client.exchange_firebase_token.assert_called_once()
        mock_save.assert_called_once_with("tlm_sk_from_firebase", base_url=mock_save.call_args[1]["base_url"])

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJ1c2VyMTIzIiwiZW1haWwiOiJ1c2VyQGV4YW1wbGUuY29tIiwiaWF0IjoxNjk5MDAwMDAwfQ.YmFkX3NpZ25hdHVyZV9mb3JfdGVzdGluZ19wdXJwb3Nlc19vbmx5")
    @patch("tlm.cli.TLMClient")
    def test_firebase_token_exchange_failure_shows_error(self, mock_cls, mock_input, mock_gc, capsys):
        """If Firebase token exchange fails, shows error message."""
        mock_client = MagicMock()
        mock_client.exchange_firebase_token.side_effect = TLMServerError("Invalid Firebase token")
        mock_cls.return_value = mock_client
        with pytest.raises(SystemExit):
            cmd_auth()
        out = capsys.readouterr().out
        assert "Invalid Firebase token" in out or "exchange" in out.lower() or "failed" in out.lower()

    @patch("tlm.cli.get_client")
    def test_already_authenticated_shows_status(self, mock_gc, capsys):
        """If already authenticated, shows email and doesn't prompt."""
        mock_client = MagicMock()
        mock_client.me.return_value = {"email": "user@test.com"}
        mock_gc.return_value = mock_client
        cmd_auth()
        out = capsys.readouterr().out
        assert "user@test.com" in out

    @patch("tlm.cli.get_client")
    @patch("builtins.input", return_value="tlm_sk_new")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_stale_creds_prompts(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If me() fails (stale creds), shows URL and prompts for new key."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMAuthError("bad key")
        mock_gc.return_value = mock_client
        mock_cls.return_value.me.return_value = {"email": "a@b.com"}
        cmd_auth()
        out = capsys.readouterr().out
        assert "tlmforge.dev" in out
        mock_input.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_verifies_after_save(self, mock_cls, mock_save, mock_input, mock_gc):
        """After saving, calls me() on new client to verify."""
        mock_new_client = MagicMock()
        mock_new_client.me.return_value = {"email": "a@b.com"}
        mock_cls.return_value = mock_new_client
        cmd_auth()
        mock_new_client.me.assert_called_once()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_verify_failure_warns_but_saves(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If verification fails, key is still saved with a warning."""
        mock_cls.return_value.me.side_effect = TLMAuthError("bad")
        cmd_auth()
        mock_save.assert_called_once()
        out = capsys.readouterr().out
        assert "Could not verify" in out or "saved" in out.lower()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", return_value="tlm_sk_abc123")
    @patch("tlm.cli.save_credentials")
    @patch("tlm.cli.TLMClient")
    def test_connection_error_on_verify_warns(self, mock_cls, mock_save, mock_input, mock_gc, capsys):
        """If server unreachable during verify, saves key and warns."""
        mock_cls.return_value.me.side_effect = TLMConnectionError("unreachable")
        cmd_auth()
        mock_save.assert_called_once()
        out = capsys.readouterr().out
        assert "saved" in out.lower() or "unreachable" in out.lower()

    @patch("tlm.cli.get_client", return_value=None)
    @patch("builtins.input", side_effect=KeyboardInterrupt)
    def test_keyboard_interrupt_clean_exit(self, mock_input, mock_gc):
        """KeyboardInterrupt during input exits cleanly."""
        with pytest.raises(SystemExit):
            cmd_auth()


# ─── cmd_signup (deprecated) Tests ───────────────────────────

class TestCmdSignup:
    @patch("tlm.cli.cmd_auth")
    def test_signup_prints_deprecation(self, mock_auth, capsys):
        """tlm signup prints deprecation notice and calls cmd_auth."""
        cmd_signup()
        out = capsys.readouterr().out
        assert "deprecated" in out.lower() or "tlm auth" in out
        mock_auth.assert_called_once()


# ─── Main argument parsing Tests ─────────────────────────────

class TestMainArgParsing:
    @patch("tlm.cli.cmd_auth")
    def test_main_auth_no_args(self, mock_auth):
        """tlm auth (no key) calls cmd_auth() with no api_key."""
        with patch.object(sys, 'argv', ['tlm', 'auth']):
            main()
        mock_auth.assert_called_once_with(api_key=None, base_url=None)

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_with_key(self, mock_auth):
        """tlm auth <key> passes api_key."""
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test']):
            main()
        mock_auth.assert_called_once_with(api_key="tlm_sk_test", base_url=None)

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_with_url(self, mock_auth):
        """tlm auth --url <url> passes base_url."""
        with patch.object(sys, 'argv', ['tlm', 'auth', '--url', 'http://localhost:8000']):
            main()
        mock_auth.assert_called_once_with(api_key=None, base_url="http://localhost:8000")

    @patch("tlm.cli.cmd_auth")
    def test_main_auth_key_and_url(self, mock_auth):
        """tlm auth <key> --url <url> passes both."""
        with patch.object(sys, 'argv', ['tlm', 'auth', 'tlm_sk_test', '--url', 'http://localhost:8000']):
            main()
        mock_auth.assert_called_once_with(api_key="tlm_sk_test", base_url="http://localhost:8000")

    @patch("tlm.cli.cmd_signup")
    def test_main_signup_deprecated(self, mock_signup):
        """tlm signup calls cmd_signup (which prints deprecation)."""
        with patch.object(sys, 'argv', ['tlm', 'signup']):
            main()
        mock_signup.assert_called_once()


# ─── Error message Tests ────────────────────────────────────

class TestErrorMessages:
    @patch("tlm.cli.get_client", return_value=None)
    def test_get_backend_says_tlm_auth(self, mock_gc, capsys):
        """_get_backend error message says 'tlm auth'."""
        with pytest.raises(SystemExit):
            _get_backend()
        out = capsys.readouterr().out
        assert "tlm auth" in out

    @patch("tlm.cli.get_client", return_value=None)
    def test_get_backend_no_tlm_dev(self, mock_gc, capsys):
        """_get_backend error message does NOT reference tlmforge.dev."""
        with pytest.raises(SystemExit):
            _get_backend()
        out = capsys.readouterr().out
        assert "tlmforge.dev" not in out


# ─── _get_backend auth validation Tests ──────────────────────

class TestGetBackendValidation:
    """Tests for early auth validation (client.me()) in _get_backend()."""

    @patch("tlm.cli.get_client")
    def test_server_unreachable_exits_with_message(self, mock_get_client, capsys):
        """When server is unreachable, exits with clear message."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMConnectionError("Connection refused")
        mock_get_client.return_value = mock_client

        with pytest.raises(SystemExit) as exc_info:
            _get_backend()
        assert exc_info.value.code == 1
        out = capsys.readouterr().out
        assert "Cannot reach" in out

    @patch("tlm.cli.get_client")
    def test_invalid_auth_exits_with_message(self, mock_get_client, capsys):
        """When API key is invalid, exits with message mentioning 'tlm auth'."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMAuthError("Invalid API key")
        mock_get_client.return_value = mock_client

        with pytest.raises(SystemExit) as exc_info:
            _get_backend()
        assert exc_info.value.code == 1
        out = capsys.readouterr().out
        assert "invalid or expired" in out.lower()
        assert "tlm auth" in out

    @patch("tlm.cli.get_client")
    def test_server_error_exits_with_message(self, mock_get_client, capsys):
        """When server returns 500, exits with server error message."""
        mock_client = MagicMock()
        mock_client.me.side_effect = TLMServerError("Internal Server Error")
        mock_get_client.return_value = mock_client

        with pytest.raises(SystemExit) as exc_info:
            _get_backend()
        assert exc_info.value.code == 1
        out = capsys.readouterr().out
        assert "server error" in out.lower()

    @patch("tlm.cli.get_client")
    def test_valid_auth_proceeds(self, mock_get_client):
        """When me() succeeds, _get_backend() returns normally."""
        mock_client = MagicMock()
        mock_client.me.return_value = {"email": "user@example.com"}
        mock_get_client.return_value = mock_client

        _, client, project_id = _get_backend()

        assert client is mock_client
        assert project_id is None


# ─── _get_backend auto-project-creation Tests ────────────────

class TestGetBackendAutoProject:
    @patch("tlm.cli.get_client")
    def test_creates_project_on_server_when_no_project_id(self, mock_get_client, tmp_path):
        """_get_backend auto-creates project on server when project_id is missing."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 42,
            "name": "my-project",
            "fingerprint": "abc123",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _, client, project_id = _get_backend(project)

        assert project_id == 42
        mock_client.create_project.assert_called_once()

    @patch("tlm.cli.get_client")
    def test_saves_project_id_to_config(self, mock_get_client, tmp_path):
        """Auto-created project_id is saved to .tlm/config.json."""
        mock_client = MagicMock()
        mock_client.create_project.return_value = {
            "project_id": 99,
            "name": "test-proj",
            "fingerprint": "xyz",
        }
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()

        _get_backend(project)

        config = json.loads(project.config_file.read_text())
        assert config["project_id"] == 99

    @patch("tlm.cli.get_client")
    def test_reuses_existing_project_id(self, mock_get_client, tmp_path):
        """_get_backend does NOT create project if project_id already exists."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        project = Project(str(tmp_path))
        project.init()
        config = json.loads(project.config_file.read_text())
        config["project_id"] = 77
        project.config_file.write_text(json.dumps(config))

        _, client, project_id = _get_backend(project)

        assert project_id == 77
        mock_client.create_project.assert_not_called()

    @patch("tlm.cli.get_client")
    def test_no_project_skips_creation(self, mock_get_client):
        """_get_backend without a project arg doesn't try to create one."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        _, client, project_id = _get_backend(None)

        assert project_id is None
        mock_client.create_project.assert_not_called()


# ─── Config approval menu Tests ──────────────────────────────

class TestConfigApprovalMenu:
    """Tests for _interactive_config_approval() numbered menu."""

    def _make_config_gen(self):
        mock = MagicMock()
        mock.update_config.return_value = {"project_summary": "updated"}
        return mock

    def _make_project(self, tmp_path):
        project = Project(str(tmp_path))
        project.init()
        return project

    @patch("builtins.input", return_value="1")
    def test_numbered_option_1_approves(self, mock_input, tmp_path, capsys):
        """Input '1' approves and saves config."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)
        config = {"project_summary": "test"}

        _interactive_config_approval(cg, config, project)

        cg.save_approved.assert_called_once_with(config)
        out = capsys.readouterr().out
        assert "approved" in out.lower()

    @patch("builtins.input", return_value="3")
    def test_numbered_option_3_quits(self, mock_input, tmp_path, capsys):
        """Input '3' exits without saving."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)

        _interactive_config_approval(cg, {}, project)

        cg.save_approved.assert_not_called()
        out = capsys.readouterr().out
        assert "without saving" in out.lower()

    @patch("builtins.input", side_effect=["2", "change X to Y", "1"])
    def test_numbered_option_2_prompts_for_correction(self, mock_input, tmp_path, capsys):
        """Input '2' asks for correction text, then loops back."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)

        _interactive_config_approval(cg, {}, project)

        cg.update_config.assert_called_once()
        # Eventually approved with '1'
        cg.save_approved.assert_called_once()

    @patch("builtins.input", return_value="yes")
    def test_word_yes_still_works(self, mock_input, tmp_path, capsys):
        """Input 'yes' still approves (backward compat)."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)
        config = {"project_summary": "test"}

        _interactive_config_approval(cg, config, project)

        cg.save_approved.assert_called_once_with(config)

    @patch("builtins.input", return_value="quit")
    def test_word_quit_still_works(self, mock_input, tmp_path, capsys):
        """Input 'quit' still exits without saving."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)

        _interactive_config_approval(cg, {}, project)

        cg.save_approved.assert_not_called()

    @patch("builtins.input", side_effect=["change X to Y", "1"])
    def test_free_text_treated_as_correction(self, mock_input, tmp_path, capsys):
        """Free text input is treated as correction."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)

        _interactive_config_approval(cg, {}, project)

        cg.update_config.assert_called_once()
        args = cg.update_config.call_args[0]
        assert "change X to Y" in args

    @patch("builtins.input", return_value="1")
    def test_approval_shows_correct_next_message(self, mock_input, tmp_path, capsys):
        """After approval, output mentions 'Keep building normally' NOT 'tlm build'."""
        cg = self._make_config_gen()
        project = self._make_project(tmp_path)

        _interactive_config_approval(cg, {}, project)

        out = capsys.readouterr().out
        assert "tlm build" not in out
        assert "keep building" in out.lower() or "tlm help" in out.lower()


# ─── Archaeological dig auto-background Tests ────────────────

class TestArchaeologicalDig:
    """Tests for auto-background history analysis in cmd_install."""

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.cli.Scanner")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli._interactive_config_approval")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_auto_starts_background_analysis(
        self, mock_run, mock_popen, mock_approval,
        mock_cg, mock_scanner, mock_backend, tmp_path, capsys
    ):
        """With commits, spawns background process without asking."""
        mock_run.return_value = MagicMock(returncode=0, stdout="50\n")
        (tmp_path / ".tlm").mkdir(exist_ok=True)

        with patch("tlm.cli.Project") as MockProject:
            project = MagicMock()
            project.root = tmp_path
            project.enforcement.approved = False
            MockProject.return_value = project

            cmd_install()

        # Should have called Popen (background), NOT input()
        mock_popen.assert_called_once()
        popen_args = mock_popen.call_args
        assert "tlm" in str(popen_args)

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.cli.Scanner")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli._interactive_config_approval")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_background_analysis_message_shown(
        self, mock_run, mock_popen, mock_approval,
        mock_cg, mock_scanner, mock_backend, tmp_path, capsys
    ):
        """Prints 'Analyzing N commits in the background'."""
        mock_run.return_value = MagicMock(returncode=0, stdout="42\n")

        with patch("tlm.cli.Project") as MockProject:
            project = MagicMock()
            project.root = tmp_path
            project.enforcement.approved = False
            MockProject.return_value = project

            cmd_install()

        out = capsys.readouterr().out
        assert "42" in out
        assert "background" in out.lower()

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.cli.Scanner")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli._interactive_config_approval")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_mentions_tlm_status(
        self, mock_run, mock_popen, mock_approval,
        mock_cg, mock_scanner, mock_backend, tmp_path, capsys
    ):
        """Output mentions `tlm status` for checking progress."""
        mock_run.return_value = MagicMock(returncode=0, stdout="10\n")

        with patch("tlm.cli.Project") as MockProject:
            project = MagicMock()
            project.root = tmp_path
            project.enforcement.approved = False
            MockProject.return_value = project

            cmd_install()

        out = capsys.readouterr().out
        assert "tlm status" in out

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.cli.Scanner")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli._interactive_config_approval")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_no_commits_no_analysis(
        self, mock_run, mock_popen, mock_approval,
        mock_cg, mock_scanner, mock_backend, tmp_path, capsys
    ):
        """Repo with 0 commits triggers no analysis."""
        mock_run.return_value = MagicMock(returncode=0, stdout="0\n")

        with patch("tlm.cli.Project") as MockProject:
            project = MagicMock()
            project.root = tmp_path
            project.enforcement.approved = False
            MockProject.return_value = project

            cmd_install()

        mock_popen.assert_not_called()

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.cli.Scanner")
    @patch("tlm.cli.ConfigGenerator")
    @patch("tlm.cli._interactive_config_approval")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_no_git_no_analysis(
        self, mock_run, mock_popen, mock_approval,
        mock_cg, mock_scanner, mock_backend, tmp_path, capsys
    ):
        """Non-git directory: no error, no analysis."""
        mock_run.side_effect = FileNotFoundError("git not found")

        with patch("tlm.cli.Project") as MockProject:
            project = MagicMock()
            project.root = tmp_path
            project.enforcement.approved = False
            MockProject.return_value = project

            cmd_install()  # Should not raise

        mock_popen.assert_not_called()


# ─── cmd_learn lockfile Tests ────────────────────────────────

class TestCmdLearnBackground:
    """Tests for lockfile management in cmd_learn."""

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.learner.Learner")
    def test_creates_lockfile_on_start(self, MockLearner, mock_backend, tmp_path, capsys):
        """cmd_learn writes .tlm/learn.lock."""
        project = Project(str(tmp_path))
        project.init()

        learner = MagicMock()
        learner.get_commit_count_since_last_session.return_value = 5
        learner.learn_since_last_session.return_value = {"total_commits": 0}
        MockLearner.return_value = learner

        lockfile = tmp_path / ".tlm" / "learn.lock"
        lockfile_created = []

        original_learn = learner.learn_since_last_session
        def side_effect(*a, **kw):
            lockfile_created.append(lockfile.exists())
            return {"total_commits": 0}
        learner.learn_since_last_session.side_effect = side_effect

        with patch("tlm.cli.Project", return_value=project):
            cmd_learn()

        assert lockfile_created[0] is True, "Lockfile should exist during learning"

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.learner.Learner")
    def test_removes_lockfile_on_success(self, MockLearner, mock_backend, tmp_path, capsys):
        """Lockfile cleaned up after successful completion."""
        project = Project(str(tmp_path))
        project.init()

        learner = MagicMock()
        learner.get_commit_count_since_last_session.return_value = 3
        learner.learn_since_last_session.return_value = {"total_commits": 0}
        MockLearner.return_value = learner

        with patch("tlm.cli.Project", return_value=project):
            cmd_learn()

        lockfile = tmp_path / ".tlm" / "learn.lock"
        assert not lockfile.exists(), "Lockfile should be cleaned up after success"

    @patch("tlm.cli._get_backend", return_value=(None, MagicMock(), 1))
    @patch("tlm.learner.Learner")
    def test_removes_lockfile_on_failure(self, MockLearner, mock_backend, tmp_path, capsys):
        """Lockfile cleaned up even on error."""
        project = Project(str(tmp_path))
        project.init()

        learner = MagicMock()
        learner.get_commit_count_since_last_session.return_value = 5
        learner.learn_since_last_session.side_effect = RuntimeError("API error")
        MockLearner.return_value = learner

        with patch("tlm.cli.Project", return_value=project):
            try:
                cmd_learn()
            except RuntimeError:
                pass

        lockfile = tmp_path / ".tlm" / "learn.lock"
        assert not lockfile.exists(), "Lockfile should be cleaned up even on error"


# ─── Status background learning Tests ────────────────────────

class TestStatusBackgroundLearning:
    """Tests for cmd_status showing background learning state."""

    def _setup_project(self, tmp_path):
        """Create a minimal initialized project for status tests."""
        project = Project(str(tmp_path))
        project.init()
        # Write minimal config
        config = {"project_name": "test", "created": "2024-01-01", "sessions_used": 0}
        project.config_file.write_text(json.dumps(config))
        # Create .git dir for hook checks
        (tmp_path / ".git" / "hooks").mkdir(parents=True, exist_ok=True)
        return project

    @patch("tlm.cli.logo")
    def test_shows_learning_in_progress(self, mock_logo, tmp_path, capsys):
        """When lockfile exists with alive PID, shows learning indicator."""
        project = self._setup_project(tmp_path)

        # Write lockfile with current PID (known to be alive)
        lockfile = tmp_path / ".tlm" / "learn.lock"
        lockfile.write_text(str(os.getpid()))

        with patch("tlm.cli.Project", return_value=project):
            cmd_status()

        out = capsys.readouterr().out
        assert "background" in out.lower() or "analyzing" in out.lower()

    @patch("tlm.cli.logo")
    def test_shows_nothing_when_idle(self, mock_logo, tmp_path, capsys):
        """No lockfile means no learning indicator."""
        project = self._setup_project(tmp_path)

        with patch("tlm.cli.Project", return_value=project):
            cmd_status()

        out = capsys.readouterr().out
        assert "analyzing history" not in out.lower()


# ─── cmd_init removal Tests ──────────────────────────────────

class TestCmdInitRemoved:
    """Verify cmd_init has been removed and init alias routes to cmd_install."""

    def test_cmd_init_not_importable(self):
        """cmd_init should no longer exist in cli module."""
        from tlm import cli
        assert not hasattr(cli, "cmd_init"), "cmd_init should be removed from cli.py"

    @patch("tlm.cli.cmd_install")
    def test_init_alias_calls_install(self, mock_install, capsys):
        """Running 'tlm init' should print deprecation and call cmd_install."""
        with patch.object(sys, 'argv', ['tlm', 'init']):
            main()
        mock_install.assert_called_once()
        out = capsys.readouterr().out
        assert "deprecated" in out.lower()


# ─── cmd_logout Tests ────────────────────────────────────────

class TestCmdLogout:
    """Tests for cmd_logout() credential removal."""

    @patch("tlm.cli.DEFAULT_CREDENTIALS_DIR")
    def test_logout_removes_credentials(self, mock_dir, tmp_path, capsys):
        """cmd_logout deletes credentials.json and prints success."""
        mock_dir.__str__ = lambda self: str(tmp_path)
        # Patch Path(DEFAULT_CREDENTIALS_DIR) to use tmp_path
        cred_file = tmp_path / "credentials.json"
        cred_file.write_text('{"api_key": "tlm_sk_test"}')

        with patch("tlm.cli.Path") as MockPath:
            mock_path_obj = MagicMock()
            mock_path_obj.__truediv__ = lambda self, x: cred_file
            mock_path_obj.exists.return_value = True
            MockPath.return_value = mock_path_obj
            # Use real Path for the unlink
            with patch("tlm.cli.DEFAULT_CREDENTIALS_DIR", str(tmp_path)):
                cmd_logout()

        assert not cred_file.exists()
        out = capsys.readouterr().out
        assert "Logged out" in out
        assert "tlm auth" in out

    def test_logout_when_not_logged_in(self, tmp_path, capsys):
        """cmd_logout prints 'Not logged in' when no credentials exist."""
        with patch("tlm.cli.DEFAULT_CREDENTIALS_DIR", str(tmp_path)):
            cmd_logout()
        out = capsys.readouterr().out
        assert "Not logged in" in out

    @patch("tlm.cli.get_client")
    def test_auth_already_logged_in_mentions_logout(self, mock_gc, capsys):
        """cmd_auth output mentions 'tlm logout' when already authenticated."""
        mock_client = MagicMock()
        mock_client.me.return_value = {"email": "user@test.com"}
        mock_gc.return_value = mock_client
        cmd_auth()
        out = capsys.readouterr().out
        assert "tlm logout" in out

    @patch("tlm.cli.cmd_logout")
    def test_dispatch_logout(self, mock_logout):
        """'tlm logout' dispatches to cmd_logout."""
        with patch.object(sys, 'argv', ['tlm', 'logout']):
            main()
        mock_logout.assert_called_once()
