"""
Tests verifying the client has no direct anthropic dependency.

After Phase 8 cleanup, the client should:
1. Not import anthropic anywhere
2. Not have Claude class in engine.py
3. Work without ANTHROPIC_API_KEY when using API client
4. Have httpx as dependency instead
"""

import importlib
import sys
from unittest.mock import patch, MagicMock

import pytest


class TestNoAnthropicDependency:
    def test_engine_has_no_anthropic_import(self):
        """engine.py should not import anthropic."""
        import tlm.engine as engine_mod
        source = open(engine_mod.__file__).read()
        assert "from anthropic" not in source
        assert "import anthropic" not in source

    def test_learner_has_no_anthropic_import(self):
        """learner.py should not import anthropic."""
        import tlm.learner as learner_mod
        source = open(learner_mod.__file__).read()
        assert "from anthropic" not in source
        assert "import anthropic" not in source

    def test_no_claude_class_in_engine(self):
        """Claude class should be removed from engine.py."""
        import tlm.engine as engine_mod
        assert not hasattr(engine_mod, "Claude")

    def test_no_brain_module(self):
        """prompts/brain.py should not exist in client package."""
        from pathlib import Path
        import tlm
        tlm_dir = Path(tlm.__file__).parent
        brain_path = tlm_dir / "prompts" / "brain.py"
        assert not brain_path.exists(), f"brain.py should be removed: {brain_path}"

    def test_httpx_available(self):
        """httpx should be importable (is a dependency)."""
        import httpx
        assert httpx is not None

    def test_api_client_works_without_anthropic(self):
        """api_client.py should work without anthropic installed."""
        from tlm.api_client import TLMClient
        client = TLMClient(api_key="tlm_sk_test", base_url="http://localhost:8000")
        assert client.api_key == "tlm_sk_test"
