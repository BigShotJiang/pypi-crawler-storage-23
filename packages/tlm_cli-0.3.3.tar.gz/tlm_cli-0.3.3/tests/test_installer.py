"""
Tests for TLM Installer — install/uninstall, file generation, settings merge.
"""

import json
import os
import stat
import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from tlm.installer import Installer
from tlm.engine import Project


# ─── Fixtures ─────────────────────────────────────────────────

SAMPLE_ENFORCEMENT_CONFIG = {
    "approved": True,
    "project_summary": "A Python web app using Flask + PostgreSQL",
    "environments": {
        "staging": {
            "description": "Staging on Heroku",
            "check_exists_command": "heroku apps:info -a myapp-staging",
            "deploy_command": "git push heroku-staging main",
            "verify_command": "curl -f https://myapp-staging.herokuapp.com/health",
        },
        "production": {
            "description": "Production on Heroku",
            "check_exists_command": "heroku apps:info -a myapp",
            "deploy_command": "git push heroku main",
            "verify_command": "curl -f https://myapp.herokuapp.com/health",
        },
    },
    "checks": [
        {
            "name": "Tests",
            "command": "pytest tests/",
            "blocker": True,
            "when": "pre_commit",
            "category": "testing",
        },
        {
            "name": "Lint",
            "command": "flake8 src/",
            "blocker": False,
            "when": "pre_commit",
            "category": "linting",
        },
    ],
    "coverage": {
        "command": "pytest --cov=src tests/",
        "min_line_coverage": 70,
    },
    "drift_files": ["requirements.txt", "Dockerfile"],
}


@pytest.fixture
def project_dir(tmp_path):
    """Create a project directory with git repo and .tlm/."""
    repo = tmp_path / "myproject"
    repo.mkdir()

    # Init git
    subprocess.run(["git", "init"], cwd=str(repo), capture_output=True,
                    env={**os.environ, "GIT_CONFIG_NOSYSTEM": "1"})
    subprocess.run(["git", "config", "user.name", "Test"], cwd=str(repo), capture_output=True)
    subprocess.run(["git", "config", "user.email", "t@t.com"], cwd=str(repo), capture_output=True)

    # Init .tlm/
    project = Project(str(repo))
    project.init()

    # Write enforcement config
    (repo / ".tlm" / "enforcement.json").write_text(json.dumps(SAMPLE_ENFORCEMENT_CONFIG, indent=2))

    # Write profile
    (repo / ".tlm" / "profile.md").write_text("## Stack\nPython, Flask, PostgreSQL\n")

    return repo


@pytest.fixture
def installer(project_dir):
    return Installer(str(project_dir))


# ─── Install Tests ────────────────────────────────────────────

class TestInstall:
    def test_generates_claude_md(self, installer, project_dir):
        installer.install()
        claude_md = project_dir / "CLAUDE.md"
        assert claude_md.exists()
        content = claude_md.read_text()
        assert "TLM" in content
        assert "Self-Classification" in content
        assert "TDD" in content

    def test_claude_md_has_project_commands(self, installer, project_dir):
        installer.install()
        content = (project_dir / "CLAUDE.md").read_text()
        assert "pytest tests/" in content  # From enforcement config

    def test_claude_md_has_deployment_protocol(self, installer, project_dir):
        installer.install()
        content = (project_dir / "CLAUDE.md").read_text()
        assert "staging" in content
        assert "production" in content

    def test_creates_settings_json(self, installer, project_dir):
        installer.install()
        settings_file = project_dir / ".claude" / "settings.json"
        assert settings_file.exists()
        settings = json.loads(settings_file.read_text())
        assert "hooks" in settings

    def test_settings_has_all_hooks(self, installer, project_dir):
        installer.install()
        settings = json.loads((project_dir / ".claude" / "settings.json").read_text())
        hooks = settings["hooks"]

        # Hooks should be dict format keyed by event name
        assert isinstance(hooks, dict)
        total = sum(len(entries) for entries in hooks.values())
        assert total >= 6  # 6 TLM hooks

        # Events covered
        assert "SessionStart" in hooks
        assert "UserPromptSubmit" in hooks
        assert "PreToolUse" in hooks
        assert "Stop" in hooks

    def test_settings_merge_preserves_existing(self, installer, project_dir):
        """Install should merge, not overwrite existing settings."""
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir(exist_ok=True)
        existing = {
            "permissions": {"allow": ["Read", "Glob"]},
            "hooks": [
                {"type": "UserPromptSubmit", "command": "echo existing", "_custom": True}
            ]
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing, indent=2))

        installer.install()

        settings = json.loads((claude_dir / "settings.json").read_text())
        assert isinstance(settings["hooks"], dict)
        assert settings["permissions"]["allow"] == ["Read", "Glob"]
        # Custom hook preserved under UserPromptSubmit event key
        uph = settings["hooks"].get("UserPromptSubmit", [])
        custom = [h for h in uph if h.get("_custom")]
        assert len(custom) == 1

    def test_creates_hook_wrapper_scripts(self, installer, project_dir):
        installer.install()
        hooks_dir = project_dir / ".claude" / "hooks"
        assert hooks_dir.exists()

        # Should have wrapper scripts
        scripts = list(hooks_dir.glob("tlm-*"))
        assert len(scripts) >= 3

    def test_hook_scripts_are_executable(self, installer, project_dir):
        installer.install()
        for script in (project_dir / ".claude" / "hooks").glob("tlm-*"):
            assert os.access(str(script), os.X_OK)

    def test_hook_scripts_call_tlm(self, installer, project_dir):
        installer.install()
        for script in (project_dir / ".claude" / "hooks").glob("tlm-*"):
            content = script.read_text()
            assert "tlm _hook" in content

    def test_creates_git_post_commit_hook(self, installer, project_dir):
        installer.install()
        hook = project_dir / ".git" / "hooks" / "post-commit"
        assert hook.exists()
        assert "TLM" in hook.read_text()
        assert os.access(str(hook), os.X_OK)

    def test_initializes_state_json(self, installer, project_dir):
        installer.install()
        state_file = project_dir / ".tlm" / "state.json"
        assert state_file.exists()
        state = json.loads(state_file.read_text())
        assert state["phase"] == "idle"

    def test_idempotent_install(self, installer, project_dir):
        """Running install twice should not duplicate hooks."""
        installer.install()
        hooks1 = json.loads((project_dir / ".claude" / "settings.json").read_text())["hooks"]
        first_count = sum(len(v) for v in hooks1.values())

        installer.install()
        hooks2 = json.loads((project_dir / ".claude" / "settings.json").read_text())["hooks"]
        second_count = sum(len(v) for v in hooks2.values())

        # Same number of hooks after second install
        assert first_count == second_count

    def test_creates_rules_dir(self, installer, project_dir):
        installer.install()
        rules_dir = project_dir / ".claude" / "rules"
        assert rules_dir.exists()
        rule_files = list(rules_dir.glob("tlm-*.md"))
        assert len(rule_files) >= 1

    def test_handles_dict_format_hooks(self, installer, project_dir):
        """Install with pre-existing dict-format hooks (real Claude Code format)."""
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir(exist_ok=True)
        existing = {
            "hooks": {
                "PreToolUse": [
                    {
                        "matcher": "Bash",
                        "hooks": [{"type": "command", "command": "echo custom-lint"}],
                        "_custom": True,
                    }
                ]
            }
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing, indent=2))

        installer.install()

        settings = json.loads((claude_dir / "settings.json").read_text())
        hooks = settings["hooks"]
        assert isinstance(hooks, dict)

        # Custom hook preserved
        pre_tool = hooks.get("PreToolUse", [])
        custom = [h for h in pre_tool if h.get("_custom")]
        assert len(custom) == 1

        # TLM hooks added
        tlm = [h for h in pre_tool if h.get("_tlm")]
        assert len(tlm) >= 1

    def test_preserves_existing_claude_md(self, installer, project_dir):
        """If CLAUDE.md already has non-TLM content, preserve it."""
        existing_content = "# My Project\n\nExisting rules here.\n"
        (project_dir / "CLAUDE.md").write_text(existing_content)

        installer.install()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "My Project" in content
        assert "Existing rules here" in content
        assert "TLM" in content


# ─── Uninstall Tests ──────────────────────────────────────────

class TestUninstall:
    def test_removes_tlm_from_claude_md(self, installer, project_dir):
        installer.install()
        installer.uninstall()

        claude_md = project_dir / "CLAUDE.md"
        if claude_md.exists():
            content = claude_md.read_text()
            assert "# TLM" not in content

    def test_removes_tlm_hooks_from_settings(self, installer, project_dir):
        installer.install()
        installer.uninstall()

        settings_file = project_dir / ".claude" / "settings.json"
        if settings_file.exists():
            settings = json.loads(settings_file.read_text())
            hooks = settings.get("hooks", {})
            assert isinstance(hooks, dict)
            for entries in hooks.values():
                tlm = [h for h in entries if h.get("_tlm")]
                assert len(tlm) == 0

    def test_preserves_non_tlm_hooks(self, installer, project_dir):
        """Uninstall should keep user's custom hooks."""
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir(exist_ok=True)
        existing = {
            "hooks": [
                {"type": "UserPromptSubmit", "command": "echo custom", "_custom": True}
            ]
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing, indent=2))

        installer.install()
        installer.uninstall()

        settings = json.loads((claude_dir / "settings.json").read_text())
        hooks = settings["hooks"]
        assert isinstance(hooks, dict)
        uph = hooks.get("UserPromptSubmit", [])
        custom = [h for h in uph if h.get("_custom")]
        assert len(custom) == 1

    def test_uninstall_handles_dict_format(self, installer, project_dir):
        """Uninstall with dict-format hooks (real Claude Code format)."""
        claude_dir = project_dir / ".claude"
        claude_dir.mkdir(exist_ok=True)
        existing = {
            "hooks": {
                "SessionStart": [
                    {
                        "hooks": [{"type": "command", "command": "tlm _hook session"}],
                        "_tlm": True,
                    }
                ],
                "PreToolUse": [
                    {
                        "matcher": "Bash",
                        "hooks": [{"type": "command", "command": "echo custom-lint"}],
                        "_custom": True,
                    },
                    {
                        "matcher": "Bash",
                        "hooks": [{"type": "command", "command": "tlm _hook compliance"}],
                        "_tlm": True,
                    },
                ],
            }
        }
        (claude_dir / "settings.json").write_text(json.dumps(existing, indent=2))

        installer.uninstall()

        settings = json.loads((claude_dir / "settings.json").read_text())
        hooks = settings["hooks"]
        assert isinstance(hooks, dict)

        # TLM hooks removed
        for entries in hooks.values():
            tlm = [h for h in entries if h.get("_tlm")]
            assert len(tlm) == 0

        # Custom hook preserved
        pre_tool = hooks.get("PreToolUse", [])
        custom = [h for h in pre_tool if h.get("_custom")]
        assert len(custom) == 1

    def test_removes_hook_scripts(self, installer, project_dir):
        installer.install()
        installer.uninstall()

        hooks_dir = project_dir / ".claude" / "hooks"
        tlm_scripts = list(hooks_dir.glob("tlm-*")) if hooks_dir.exists() else []
        assert len(tlm_scripts) == 0

    def test_removes_git_hooks(self, installer, project_dir):
        installer.install()
        installer.uninstall()

        post_hook = project_dir / ".git" / "hooks" / "post-commit"
        if post_hook.exists():
            assert "TLM" not in post_hook.read_text()

    def test_keeps_tlm_data(self, installer, project_dir):
        """Uninstall should keep .tlm/ data (knowledge, specs, etc.)."""
        installer.install()
        installer.uninstall()

        assert (project_dir / ".tlm").exists()
        assert (project_dir / ".tlm" / "knowledge.md").exists()

    def test_removes_rules_files(self, installer, project_dir):
        installer.install()
        installer.uninstall()

        rules_dir = project_dir / ".claude" / "rules"
        if rules_dir.exists():
            tlm_rules = list(rules_dir.glob("tlm-*.md"))
            assert len(tlm_rules) == 0

    def test_preserves_existing_claude_md_content(self, installer, project_dir):
        """Uninstall should keep non-TLM CLAUDE.md content."""
        existing = "# My Project\n\nCustom rules.\n"
        (project_dir / "CLAUDE.md").write_text(existing)

        installer.install()
        installer.uninstall()

        content = (project_dir / "CLAUDE.md").read_text()
        assert "My Project" in content
        assert "Custom rules" in content
