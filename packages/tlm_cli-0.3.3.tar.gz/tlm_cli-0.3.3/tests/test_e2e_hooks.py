"""E2E tests for TLM hook integration flows.

Tests the full client-side integration using a real temp git repo
with a real .tlm/ project — no mocks except for server HTTP calls.

Covers:
  - Installer hook wiring (6 hooks, settings.json, wrapper scripts)
  - Spec gate (hook_guard) with real state transitions
  - Compliance gate (hook_compliance_gate) with quality levels
  - Deployment gate (hook_deployment_gate)
  - Session learning (prompt capture → summary → server → DB)
  - Knowledge DB lifecycle across hooks
"""

import json
import os
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_deployment_gate,
    hook_stop,
)
from tlm.installer import Installer
from tlm.knowledge_db import KnowledgeDB
from tlm.state import write_state


# ─── Fixtures ──────────────────────────────────────────────────


@pytest.fixture
def project(tmp_path):
    """Create a real git repo + installed TLM project.

    Sets up:
    - git init
    - Installer().install()
    - .tlm/config.json with project_id, quality_control, session_learning
    - .tlm/state.json with idle phase
    - .tlm/knowledge.db via KnowledgeDB.init_db()
    """
    # Create git repo
    subprocess.run(
        ["git", "init"], cwd=str(tmp_path),
        capture_output=True, check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=str(tmp_path), capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test"],
        cwd=str(tmp_path), capture_output=True,
    )

    # Create .tlm/ dir and config before install
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir(exist_ok=True)

    config = {
        "project_name": "test-e2e",
        "project_id": 42,
        "quality_control": "standard",
        "session_learning": True,
        "sessions_used": 0,
    }
    (tlm_dir / "config.json").write_text(json.dumps(config, indent=2))

    # Initialize knowledge.db
    db = KnowledgeDB(str(tlm_dir))
    db.init_db()
    db.close()

    # Run installer
    installer = Installer(str(tmp_path))
    installer.install()

    return tmp_path


def _set_state(project_path, phase, activity_type=None, active_spec=None,
               spec_review_status="none"):
    """Helper to write state.json."""
    state = {
        "phase": phase,
        "activity_type": activity_type,
        "active_spec": active_spec,
        "spec_review_status": spec_review_status,
        "last_updated": None,
    }
    (project_path / ".tlm" / "state.json").write_text(json.dumps(state))


def _set_quality(project_path, level):
    """Helper to set quality_control in config.json."""
    config_file = project_path / ".tlm" / "config.json"
    config = json.loads(config_file.read_text())
    config["quality_control"] = level
    config_file.write_text(json.dumps(config, indent=2))


def _set_session_learning(project_path, enabled):
    """Helper to set session_learning in config.json."""
    config_file = project_path / ".tlm" / "config.json"
    config = json.loads(config_file.read_text())
    config["session_learning"] = enabled
    config_file.write_text(json.dumps(config, indent=2))


# ─── TestInstallerHookWiring ──────────────────────────────────


class TestInstallerHookWiring:
    """Verify installer creates all 6 hook scripts, settings, and wiring."""

    EXPECTED_HOOKS = [
        "tlm-session",
        "tlm-prompt",
        "tlm-guard",
        "tlm-compliance",
        "tlm-deployment",
        "tlm-stop",
    ]

    def test_installer_creates_all_6_hook_scripts(self, project):
        hooks_dir = project / ".claude" / "hooks"
        assert hooks_dir.exists()
        for name in self.EXPECTED_HOOKS:
            script = hooks_dir / name
            assert script.exists(), f"Missing hook script: {name}"
            assert os.access(str(script), os.X_OK), f"Not executable: {name}"

    def test_settings_json_has_all_6_hooks(self, project):
        settings_file = project / ".claude" / "settings.json"
        assert settings_file.exists()
        settings = json.loads(settings_file.read_text())
        hooks = settings.get("hooks", {})

        assert isinstance(hooks, dict)

        # Count TLM hooks across all events
        tlm_hooks = []
        for event, entries in hooks.items():
            for entry in entries:
                if entry.get("_tlm"):
                    tlm_hooks.append({**entry, "event": event})
        assert len(tlm_hooks) == 6

        events = {h["event"] for h in tlm_hooks}
        assert "SessionStart" in events
        assert "UserPromptSubmit" in events
        assert "PreToolUse" in events
        assert "Stop" in events

        # Check matcher filters on PreToolUse hooks
        pre_tool_hooks = [h for h in tlm_hooks if h["event"] == "PreToolUse"]
        matchers = {h.get("matcher") for h in pre_tool_hooks}
        assert "Write|Edit" in matchers
        assert "Bash" in matchers

    def test_hook_scripts_call_tlm_hook(self, project):
        hooks_dir = project / ".claude" / "hooks"
        hook_to_arg = {
            "tlm-session": "session",
            "tlm-prompt": "prompt",
            "tlm-guard": "guard",
            "tlm-compliance": "compliance",
            "tlm-deployment": "deployment",
            "tlm-stop": "stop",
        }
        for script_name, arg in hook_to_arg.items():
            content = (hooks_dir / script_name).read_text()
            assert f"tlm _hook {arg}" in content, (
                f"Hook script {script_name} doesn't call 'tlm _hook {arg}'"
            )

    def test_state_json_initialized(self, project):
        state_file = project / ".tlm" / "state.json"
        assert state_file.exists()
        state = json.loads(state_file.read_text())
        assert state["phase"] == "idle"

    def test_claude_md_generated(self, project):
        claude_md = project / "CLAUDE.md"
        assert claude_md.exists()
        content = claude_md.read_text()
        assert "TLM:START" in content
        assert "TLM:END" in content


# ─── TestSpecGateE2E ──────────────────────────────────────────


class TestSpecGateE2E:
    """Full flow: state → hook_guard → decision.

    Note: file_path uses generic absolute paths (not project-relative)
    because _is_test_file() would match /test_ in pytest tmp dir names.
    """

    def test_idle_allows_write(self, project):
        _set_state(project, "idle")
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/src/main.py"},
        })
        assert result == {}

    def test_interview_blocks_source(self, project):
        _set_state(project, "tlm_active")
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/src/main.py"},
        })
        assert result.get("decision") == "block"

    def test_interview_allows_test(self, project):
        _set_state(project, "tlm_active")
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_main.py"},
        })
        assert result == {}

    def test_interview_allows_tlm_dir(self, project):
        _set_state(project, "tlm_active")
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/.tlm/state.json"},
        })
        assert result == {}

    def test_implementation_warns_tdd(self, project):
        _set_state(project, "implementation", spec_review_status="approved")
        # Pre-populate session test tracking with a non-matching test file so the
        # hook reaches the additionalContext "warn" path rather than the hard block
        # that fires when no test files have been written in the session at all.
        cache_dir = project / ".tlm" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "session_tests.json").write_text(
            json.dumps({"test_files_written": ["/app/tests/test_other.py"], "session_start": "2026-02-18T00:00:00"})
        )
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/src/main.py"},
        })
        assert "additionalContext" in result
        assert "tdd" in result["additionalContext"].lower()

    def test_non_write_tool_passthrough(self, project):
        _set_state(project, "tlm_active")
        result = hook_guard(str(project), {
            "tool_name": "Bash",
            "tool_input": {"command": "ls -la"},
        })
        assert result == {}

    def test_edit_tool_also_guarded(self, project):
        _set_state(project, "tlm_active")
        result = hook_guard(str(project), {
            "tool_name": "Edit",
            "tool_input": {"file_path": "/app/src/app.py"},
        })
        assert result.get("decision") == "block"


# ─── TestComplianceGateE2E ────────────────────────────────────


class TestComplianceGateE2E:
    """Full flow: quality level → mechanical checks → server review."""

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_relaxed_skips_server_review(self, mock_mech, project):
        _set_quality(project, "relaxed")
        result = hook_compliance_gate(str(project), {
            "command": "git commit -m 'test'"
        })
        assert "additionalContext" in result
        assert "decision" not in result  # Not blocked

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff --git a/file.py")
    @patch("tlm.hooks._get_changed_files", return_value=["file.py"])
    @patch("tlm.hooks.get_client")
    def test_standard_with_server_warns(
        self, mock_client, mock_files, mock_diff, mock_mech, project
    ):
        _set_quality(project, "standard")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "warn",
            "models_used": ["claude"],
            "reviews": [{"issues": [
                {"severity": "warning", "description": "Missing error handling"}
            ]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(project), {
            "command": "git commit -m 'test'"
        })
        assert "additionalContext" in result
        assert "warning" in result["additionalContext"].lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff --git a/file.py")
    @patch("tlm.hooks._get_changed_files", return_value=["file.py"])
    @patch("tlm.hooks.get_client")
    def test_high_with_server_blocks(
        self, mock_client, mock_files, mock_diff, mock_mech, project
    ):
        _set_quality(project, "high")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "block",
            "models_used": ["claude", "gemini"],
            "reviews": [{"issues": [
                {"severity": "error", "description": "SQL injection", "fix": "Use parameterized queries"}
            ]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(project), {
            "command": "git commit -m 'test'"
        })
        assert result.get("decision") == "block"
        assert "SQL injection" in result.get("reason", "")

    @patch("tlm.hooks._run_mechanical_checks", return_value=["tests: 2 tests failed"])
    def test_mechanical_failure_blocks_any_quality(self, mock_mech, project):
        for level in ("high", "standard"):
            _set_quality(project, level)
            result = hook_compliance_gate(str(project), {
                "command": "git commit -m 'test'"
            })
            assert result.get("decision") == "block"
            assert "tests" in result.get("reason", "").lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks._get_staged_diff", return_value="diff --git a/file.py")
    @patch("tlm.hooks._get_changed_files", return_value=["file.py"])
    @patch("tlm.hooks.get_client")
    def test_server_unreachable_falls_back(
        self, mock_client, mock_files, mock_diff, mock_mech, project
    ):
        _set_quality(project, "standard")
        client = MagicMock()
        client.review_code.side_effect = ConnectionError("Server unreachable")
        mock_client.return_value = client

        result = hook_compliance_gate(str(project), {
            "command": "git commit -m 'test'"
        })
        # Falls back to context injection instead of blocking
        assert "additionalContext" in result
        assert "decision" not in result

    def test_non_commit_passthrough(self, project):
        result = hook_compliance_gate(str(project), {
            "command": "ls -la"
        })
        assert result == {}


# ─── TestDeploymentGateE2E ────────────────────────────────────


class TestDeploymentGateE2E:
    """Full flow: deploy command detection → always blocks."""

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_firebase_deploy_blocked(self, mock_mech, project):
        result = hook_deployment_gate(str(project), {
            "command": "firebase deploy"
        })
        assert result.get("decision") == "block"

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_git_push_main_blocked(self, mock_mech, project):
        result = hook_deployment_gate(str(project), {
            "command": "git push origin main"
        })
        assert result.get("decision") == "block"

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_feature_branch_push_allowed(self, mock_mech, project):
        result = hook_deployment_gate(str(project), {
            "command": "git push origin feature-x"
        })
        assert result == {}

    @patch("tlm.hooks._run_mechanical_checks", return_value=["lint: 3 errors"])
    def test_deploy_blocked_with_mechanical_failures(self, mock_mech, project):
        result = hook_deployment_gate(str(project), {
            "command": "firebase deploy"
        })
        assert result.get("decision") == "block"
        assert "mechanical" in result.get("reason", "").lower()

    def test_non_deploy_passthrough(self, project):
        result = hook_deployment_gate(str(project), {
            "command": "npm run build"
        })
        assert result == {}


# ─── TestSessionLearningE2E ──────────────────────────────────


class TestSessionLearningE2E:
    """Full integration: capture → summary → server → DB."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_prompt_capture_writes_jsonl(self, mock_sync, mock_client, project):
        prompts_file = project / ".tlm" / "session_prompts.jsonl"

        hook_prompt_submit(str(project), prompt_text="Add user auth")
        assert prompts_file.exists()

        lines = prompts_file.read_text().strip().split("\n")
        assert len(lines) == 1
        entry = json.loads(lines[0])
        assert entry["prompt"] == "Add user auth"
        assert "timestamp" in entry

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_multiple_prompts_captured(self, mock_sync, mock_client, project):
        prompts_file = project / ".tlm" / "session_prompts.jsonl"

        hook_prompt_submit(str(project), prompt_text="First prompt")
        hook_prompt_submit(str(project), prompt_text="Second prompt")
        hook_prompt_submit(str(project), prompt_text="Third prompt")

        lines = prompts_file.read_text().strip().split("\n")
        assert len(lines) == 3

    @patch("tlm.hooks.get_client")
    def test_stop_hook_sends_summary_and_writes_rules(self, mock_get_client, project):
        # Write prompts to session_prompts.jsonl
        prompts_file = project / ".tlm" / "session_prompts.jsonl"
        for prompt in ["Add user auth", "Use JWT tokens", "Add rate limiting"]:
            entry = json.dumps({"timestamp": "2026-01-01T00:00:00", "prompt": prompt})
            with open(prompts_file, "a") as f:
                f.write(entry + "\n")

        # Mock server returning inferred rules
        client = MagicMock()
        client.learn_session.return_value = {
            "inferred_rules": [
                {"rule_text": "Always use JWT for auth", "tags": ["auth"]},
                {"rule_text": "Add rate limiting to all APIs", "tags": ["security"]},
            ],
            "workflow_patterns": [],
        }
        mock_get_client.return_value = client

        result = hook_stop(str(project))

        # Verify rules were written to knowledge.db
        db = KnowledgeDB(str(project / ".tlm"))
        db.init_db()
        rules = db.list_rules()
        db.close()

        rule_texts = [r["rule_text"] for r in rules]
        assert "Always use JWT for auth" in rule_texts
        assert "Add rate limiting to all APIs" in rule_texts

        # Verify result reports learned patterns
        assert "additionalContext" in result
        assert "2" in result["additionalContext"]  # Learned 2 new pattern(s)

        # Bug regression: session_prompts.jsonl must be cleaned up on success path
        assert not prompts_file.exists(), "session_prompts.jsonl should be deleted after learning"

    def test_session_learning_disabled_skips_capture(self, project):
        _set_session_learning(project, False)

        hook_prompt_submit(str(project), prompt_text="This should not be captured")

        prompts_file = project / ".tlm" / "session_prompts.jsonl"
        assert not prompts_file.exists()

    def test_session_learning_disabled_stop_returns_empty(self, project):
        _set_session_learning(project, False)

        result = hook_stop(str(project))
        assert result == {}

    @patch("tlm.hooks.get_client", return_value=None)
    def test_stop_without_server_cleans_up(self, mock_client, project):
        # Write prompts
        prompts_file = project / ".tlm" / "session_prompts.jsonl"
        entry = json.dumps({"timestamp": "2026-01-01T00:00:00", "prompt": "test"})
        prompts_file.write_text(entry + "\n")

        result = hook_stop(str(project))

        # Should clean up session_prompts.jsonl even without server
        assert not prompts_file.exists()
        assert result == {}


# ─── TestKnowledgeDBLifecycle ─────────────────────────────────


class TestKnowledgeDBLifecycle:
    """Full lifecycle: rules in DB → injected in session_start."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_rules_injected_in_session_start(self, mock_sync, mock_client, project):
        # Add rules to knowledge.db
        db = KnowledgeDB(str(project / ".tlm"))
        db.init_db()
        db.add_rule("Always write tests first", source="user_added")
        db.add_rule("Use dependency injection", source="learned")
        db.add_rule("Never commit secrets", source="base")
        db.close()

        result = hook_session_start(str(project))

        assert "Always write tests first" in result
        assert "Use dependency injection" in result
        assert "Never commit secrets" in result
        assert "3 active" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_migration_then_session_start(self, mock_sync, mock_client, project):
        tlm_dir = project / ".tlm"

        # Create old-style knowledge.md with facts
        knowledge_file = tlm_dir / "knowledge.md"
        knowledge_file.write_text(
            "# Knowledge Base\n\n"
            "- Project uses FastAPI for the backend\n"
            "- PostgreSQL is the primary database\n"
            "- All endpoints require authentication\n"
        )

        # Create old-style commits dir
        commits_dir = tlm_dir / "commits"
        commits_dir.mkdir(exist_ok=True)
        (commits_dir / "abc123.json").write_text(json.dumps({
            "hash": "abc123",
            "category": "feature",
            "lessons": ["Good test coverage"],
        }))

        # Create old-style specs dir
        specs_dir = tlm_dir / "specs"
        specs_dir.mkdir(exist_ok=True)
        (specs_dir / "auth-feature.md").write_text(
            "# Auth Feature\n\nImplement user authentication."
        )

        # Run migration
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        imported = db.migrate_from_flat_files()
        db.close()

        assert imported["rules"] >= 3  # 3 knowledge.md lines
        assert imported["commits"] == 1
        assert imported["specs"] == 1

        # Verify migrated rules appear in session_start
        result = hook_session_start(str(project))
        assert "FastAPI" in result or "PostgreSQL" in result or "authentication" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_disabled_rules_not_injected(self, mock_sync, mock_client, project):
        db = KnowledgeDB(str(project / ".tlm"))
        db.init_db()
        rule_id = db.add_rule("This rule is disabled", source="test")
        db.add_rule("This rule is active", source="test")
        db.disable_rule(rule_id)
        db.close()

        result = hook_session_start(str(project))
        assert "This rule is disabled" not in result
        assert "This rule is active" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_with_no_rules(self, mock_sync, mock_client, project):
        result = hook_session_start(str(project))
        assert "TLM" in result
        assert "rules" not in result.lower() or "0 active" not in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_shows_phase(self, mock_sync, mock_client, project):
        _set_state(project, "implementation", active_spec=".tlm/specs/auth.md")
        result = hook_session_start(str(project))
        assert "implementation" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_shows_quality(self, mock_sync, mock_client, project):
        _set_quality(project, "high")
        result = hook_session_start(str(project))
        assert "high" in result


# ─── TestPromptSubmitE2E ──────────────────────────────────────


class TestPromptSubmitE2E:
    """Full prompt submit flow with different phases."""

    def test_idle_phase_classifies_request(self, project):
        _set_state(project, "idle")
        result = hook_prompt_submit(str(project), prompt_text="Add auth")
        assert "additionalContext" in result
        assert "classify" in result["additionalContext"].lower()

    def test_tlm_active_reminds_interview(self, project):
        _set_state(project, "tlm_active", activity_type="feature")
        result = hook_prompt_submit(str(project), prompt_text="Yes, JWT")
        assert "additionalContext" in result
        assert "interview" in result["additionalContext"].lower()

    def test_implementation_reminds_tdd(self, project):
        _set_state(project, "implementation")
        result = hook_prompt_submit(str(project), prompt_text="Implement login")
        assert "additionalContext" in result
        assert "tdd" in result["additionalContext"].lower()

    def test_deployment_reminds_pipeline(self, project):
        _set_state(project, "deployment")
        result = hook_prompt_submit(str(project), prompt_text="Deploy to prod")
        assert "additionalContext" in result
        assert "deployment" in result["additionalContext"].lower()


# ─── TestFullHookChain ────────────────────────────────────────


class TestFullHookChain:
    """Test realistic multi-hook flows as they'd happen in a real session."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_session_to_commit_flow(self, mock_mech, mock_sync, mock_client, project):
        """Simulate: session_start → prompt → guard(write test) → guard(write code) → commit."""
        # 1. Session starts in idle
        _set_state(project, "idle")
        session_ctx = hook_session_start(str(project))
        assert "TLM" in session_ctx

        # 2. User asks to build a feature, transitions to implementation
        _set_state(project, "implementation", spec_review_status="approved")
        prompt_result = hook_prompt_submit(str(project), prompt_text="Implement login")
        assert "tdd" in prompt_result["additionalContext"].lower()

        # 3. Writing a test file — allowed (and tracked in session_tests.json)
        guard_test = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_login.py"},
        })
        assert guard_test == {}

        # 4. Writing source code for a DIFFERENT module — TDD reminder (warn, not block)
        # Using "payments.py" which does not match the tracked "test_login.py", so the
        # hook warns that no specific test for this module has been written.
        guard_src = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/src/payments.py"},
        })
        assert "additionalContext" in guard_src

        # 5. Commit — compliance check (relaxed, so just context)
        _set_quality(project, "relaxed")
        commit_result = hook_compliance_gate(str(project), {
            "command": "git commit -m 'feat: add login'"
        })
        assert "additionalContext" in commit_result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_interview_guard_blocks_code(self, mock_sync, mock_client, project):
        """Simulate: session_start in tlm_active → guard blocks all source writes."""
        _set_state(project, "tlm_active", activity_type="feature")

        # Session starts
        session_ctx = hook_session_start(str(project))
        assert "tlm_active" in session_ctx

        # Any source code write is blocked
        for path in ["/app/src/main.py", "/app/lib/utils.py", "/app/app.py"]:
            result = hook_guard(str(project), {
                "tool_name": "Write",
                "tool_input": {"file_path": path},
            })
            assert result.get("decision") == "block", f"Should block write to {path}"

        # But test files are allowed
        result = hook_guard(str(project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_main.py"},
        })
        assert result == {}
