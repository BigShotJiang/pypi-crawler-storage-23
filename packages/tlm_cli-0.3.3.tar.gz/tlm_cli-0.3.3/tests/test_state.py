"""
Tests for TLM State Manager — session state CRUD and phase transitions.
"""

import json
import datetime
from pathlib import Path
from unittest.mock import patch

import pytest

from tlm.state import read_state, write_state, transition_phase, set_active_spec, DEFAULT_STATE


@pytest.fixture
def project_root(tmp_path):
    """Create a project with .tlm/ directory."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    return tmp_path


# ─── read_state Tests ─────────────────────────────────────────

class TestReadState:
    def test_returns_default_when_no_file(self, project_root):
        state = read_state(project_root)
        assert state["phase"] == "idle"
        assert state["activity_type"] is None
        assert state["active_spec"] is None

    def test_reads_existing_state(self, project_root):
        state_file = project_root / ".tlm" / "state.json"
        state_file.write_text(json.dumps({
            "phase": "implementation",
            "activity_type": "feature_request",
            "active_spec": ".tlm/specs/my-spec.md",
            "last_updated": "2026-02-15T10:00:00",
        }))
        state = read_state(project_root)
        assert state["phase"] == "implementation"
        assert state["activity_type"] == "feature_request"
        assert state["active_spec"] == ".tlm/specs/my-spec.md"

    def test_returns_default_on_invalid_json(self, project_root):
        state_file = project_root / ".tlm" / "state.json"
        state_file.write_text("not json")
        state = read_state(project_root)
        assert state["phase"] == "idle"

    def test_returns_default_when_no_tlm_dir(self, tmp_path):
        state = read_state(tmp_path)
        assert state["phase"] == "idle"


# ─── write_state Tests ────────────────────────────────────────

class TestWriteState:
    def test_writes_state_file(self, project_root):
        state = {"phase": "tlm_active", "activity_type": "security_review",
                 "active_spec": None, "last_updated": "2026-02-15T10:00:00"}
        write_state(project_root, state)

        state_file = project_root / ".tlm" / "state.json"
        assert state_file.exists()
        written = json.loads(state_file.read_text())
        assert written["phase"] == "tlm_active"
        assert written["activity_type"] == "security_review"

    def test_overwrites_existing_state(self, project_root):
        write_state(project_root, {"phase": "idle", "activity_type": None,
                                    "active_spec": None, "last_updated": ""})
        write_state(project_root, {"phase": "deployment", "activity_type": "deploy",
                                    "active_spec": None, "last_updated": ""})

        state = read_state(project_root)
        assert state["phase"] == "deployment"

    def test_creates_tlm_dir_if_missing(self, tmp_path):
        write_state(tmp_path, {"phase": "idle", "activity_type": None,
                                "active_spec": None, "last_updated": ""})
        assert (tmp_path / ".tlm" / "state.json").exists()


# ─── transition_phase Tests ───────────────────────────────────

class TestTransitionPhase:
    def test_transitions_to_tlm_active(self, project_root):
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        state = read_state(project_root)
        assert state["phase"] == "tlm_active"
        assert state["activity_type"] == "feature_request"

    def test_transitions_to_implementation(self, project_root):
        transition_phase(project_root, "implementation")
        state = read_state(project_root)
        assert state["phase"] == "implementation"

    def test_transitions_to_idle(self, project_root):
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        transition_phase(project_root, "idle")
        state = read_state(project_root)
        assert state["phase"] == "idle"
        assert state["activity_type"] is None

    def test_sets_last_updated(self, project_root):
        transition_phase(project_root, "tlm_active")
        state = read_state(project_root)
        assert state["last_updated"] is not None
        # Should be a valid ISO timestamp
        datetime.datetime.fromisoformat(state["last_updated"])

    def test_rejects_invalid_phase(self, project_root):
        with pytest.raises(ValueError, match="Invalid phase"):
            transition_phase(project_root, "invalid_phase")

    def test_context_merges_into_state(self, project_root):
        transition_phase(project_root, "deployment", context={
            "activity_type": "deploy",
            "active_spec": ".tlm/specs/deploy.md",
        })
        state = read_state(project_root)
        assert state["activity_type"] == "deploy"
        assert state["active_spec"] == ".tlm/specs/deploy.md"


# ─── set_active_spec Tests ────────────────────────────────────

class TestSetActiveSpec:
    def test_sets_spec_path(self, project_root):
        set_active_spec(project_root, ".tlm/specs/payments.md")
        state = read_state(project_root)
        assert state["active_spec"] == ".tlm/specs/payments.md"

    def test_clears_spec_with_none(self, project_root):
        set_active_spec(project_root, ".tlm/specs/payments.md")
        set_active_spec(project_root, None)
        state = read_state(project_root)
        assert state["active_spec"] is None

    def test_preserves_other_fields(self, project_root):
        transition_phase(project_root, "implementation", context={"activity_type": "feature_request"})
        set_active_spec(project_root, ".tlm/specs/feature.md")
        state = read_state(project_root)
        assert state["phase"] == "implementation"
        assert state["activity_type"] == "feature_request"
        assert state["active_spec"] == ".tlm/specs/feature.md"
