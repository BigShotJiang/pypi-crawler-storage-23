"""E2E tests for TLM CLI commands.

Tests cmd_rules, cmd_config, cmd_history, cmd_migrate against a real
project directory with real knowledge.db — no mocks except for
server HTTP calls and cwd patching.

Covers:
  - Rules CLI: list, add, disable, enable
  - Config CLI: show defaults, set quality, toggle session learning
  - History CLI: empty state, with metric data
  - Migrate CLI: flat files → SQLite, empty migration
"""

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.cli import cmd_rules, cmd_config, cmd_history, cmd_migrate
from tlm.knowledge_db import KnowledgeDB


# ─── Fixtures ──────────────────────────────────────────────────


@pytest.fixture
def installed_project(tmp_path, monkeypatch):
    """Create a minimal installed TLM project and cd into it.

    Sets up:
    - .tlm/ dir with config.json, knowledge.db
    - Patches cwd so Project(".") works
    """
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()

    # Subdirectories expected by Project
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "sessions").mkdir()
    (tlm_dir / "lessons").mkdir()
    (tlm_dir / "commits").mkdir()

    config = {
        "project_name": "test-cli",
        "created": "2026-01-01",
        "quality_control": "standard",
        "session_learning": True,
        "sessions_used": 3,
        "total_commits_analyzed": 15,
    }
    (tlm_dir / "config.json").write_text(json.dumps(config, indent=2))

    # Knowledge.md (for Project to find)
    (tlm_dir / "knowledge.md").write_text("# Knowledge Base\n")

    # Initialize knowledge.db
    db = KnowledgeDB(str(tlm_dir))
    db.init_db()
    db.close()

    # Patch cwd so Project(".") resolves to tmp_path
    monkeypatch.chdir(tmp_path)

    return tmp_path


# ─── TestRulesCLI ─────────────────────────────────────────────


class TestRulesCLI:
    """E2E tests for `tlm rules` command."""

    @patch("tlm.cli.get_client", return_value=None)
    def test_rules_list_empty(self, mock_client, installed_project, capsys):
        cmd_rules()
        captured = capsys.readouterr()
        assert "no rules yet" in captured.out.lower()

    @patch("tlm.cli.get_client", return_value=None)
    def test_rules_add_and_list(self, mock_client, installed_project, capsys):
        # Add a rule
        cmd_rules("add", ["Always test first"])
        captured = capsys.readouterr()
        assert "added" in captured.out.lower()

        # List rules — should show the added rule
        cmd_rules()
        captured = capsys.readouterr()
        assert "Always test first" in captured.out
        assert "user_added" in captured.out

    @patch("tlm.cli.get_client", return_value=None)
    def test_rules_add_multiple_and_list(self, mock_client, installed_project, capsys):
        cmd_rules("add", ["Rule one"])
        cmd_rules("add", ["Rule two"])
        cmd_rules("add", ["Rule three"])

        cmd_rules()
        captured = capsys.readouterr()
        assert "Rule one" in captured.out
        assert "Rule two" in captured.out
        assert "Rule three" in captured.out
        assert "3" in captured.out  # Total count

    @patch("tlm.cli.get_client", return_value=None)
    def test_rules_disable_and_enable(self, mock_client, installed_project, capsys):
        # Add a rule
        cmd_rules("add", ["Temporary rule"])
        capsys.readouterr()  # Clear

        # Disable the rule (ID 1)
        cmd_rules("disable", ["1"])
        captured = capsys.readouterr()
        assert "disabled" in captured.out.lower()

        # List — should show disabled status
        cmd_rules()
        captured = capsys.readouterr()
        assert "disabled" in captured.out.lower()

        # Enable it back
        cmd_rules("enable", ["1"])
        captured = capsys.readouterr()
        assert "enabled" in captured.out.lower()

        # List — should show active again
        cmd_rules()
        captured = capsys.readouterr()
        assert "active" in captured.out.lower()

    @patch("tlm.cli.get_client")
    def test_rules_add_with_embedding(self, mock_get_client, installed_project, capsys):
        """When server is available, rules get embeddings."""
        client = MagicMock()
        client.embed.return_value = {"vectors": [[0.1, 0.2, 0.3]]}
        mock_get_client.return_value = client

        cmd_rules("add", ["Use dependency injection"])
        captured = capsys.readouterr()
        assert "added" in captured.out.lower()
        assert "embedding" in captured.out.lower()


# ─── TestConfigCLI ────────────────────────────────────────────


class TestConfigCLI:
    """E2E tests for `tlm config` command."""

    def test_config_show_defaults(self, installed_project, capsys):
        cmd_config()
        captured = capsys.readouterr()
        assert "standard" in captured.out  # default quality
        assert "on" in captured.out  # session learning default
        assert "test-cli" in captured.out  # project name

    def test_config_quality_high(self, installed_project, capsys):
        cmd_config("quality", ["high"])
        captured = capsys.readouterr()
        assert "high" in captured.out.lower()

        # Verify config.json actually changed
        config_file = installed_project / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        assert config["quality_control"] == "high"

    def test_config_quality_relaxed(self, installed_project, capsys):
        cmd_config("quality", ["relaxed"])
        captured = capsys.readouterr()
        assert "relaxed" in captured.out.lower()

        config_file = installed_project / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        assert config["quality_control"] == "relaxed"

    def test_config_quality_invalid(self, installed_project, capsys):
        cmd_config("quality", ["extreme"])
        captured = capsys.readouterr()
        assert "usage" in captured.out.lower()

    def test_config_session_learning_off(self, installed_project, capsys):
        cmd_config("session-learning", ["off"])
        captured = capsys.readouterr()
        assert "disabled" in captured.out.lower()

        config_file = installed_project / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        assert config["session_learning"] is False

    def test_config_session_learning_on(self, installed_project, capsys):
        # First disable, then re-enable
        cmd_config("session-learning", ["off"])
        capsys.readouterr()

        cmd_config("session-learning", ["on"])
        captured = capsys.readouterr()
        assert "enabled" in captured.out.lower()

        config_file = installed_project / ".tlm" / "config.json"
        config = json.loads(config_file.read_text())
        assert config["session_learning"] is True

    def test_config_show_after_changes(self, installed_project, capsys):
        cmd_config("quality", ["high"])
        cmd_config("session-learning", ["off"])
        capsys.readouterr()

        cmd_config()
        captured = capsys.readouterr()
        assert "high" in captured.out
        assert "off" in captured.out


# ─── TestHistoryCLI ──────────────────────────────────────────


class TestHistoryCLI:
    """E2E tests for `tlm history` command."""

    def test_history_empty(self, installed_project, capsys):
        cmd_history()
        captured = capsys.readouterr()
        assert "no metrics yet" in captured.out.lower()

    def test_history_with_data(self, installed_project, capsys):
        # Add metrics to knowledge.db
        db = KnowledgeDB(str(installed_project / ".tlm"))
        db.init_db()
        db.add_metric("2026-W01", spec_accuracy=85.0, total_commits=10,
                       planned_commits=8, unplanned_commits=2, bugs_caught_by_review=1)
        db.add_metric("2026-W02", spec_accuracy=90.0, total_commits=15,
                       planned_commits=13, unplanned_commits=2, bugs_caught_by_review=0)
        db.add_metric("2026-W03", spec_accuracy=72.0, total_commits=8,
                       planned_commits=5, unplanned_commits=3, bugs_caught_by_review=2)
        db.close()

        cmd_history()
        captured = capsys.readouterr()

        # Should show accuracy bars
        assert "85" in captured.out
        assert "90" in captured.out
        assert "72" in captured.out
        assert "2026-W01" in captured.out
        assert "2026-W03" in captured.out


# ─── TestMigrateCLI ──────────────────────────────────────────


class TestMigrateCLI:
    """E2E tests for `tlm migrate` command."""

    def test_migrate_with_flat_files(self, installed_project, capsys):
        tlm_dir = installed_project / ".tlm"

        # Create old-style knowledge.md with real facts
        (tlm_dir / "knowledge.md").write_text(
            "# Knowledge Base\n\n"
            "- Project uses React for the frontend\n"
            "- API is built with Express.js\n"
            "- MongoDB is the primary database\n"
        )

        # Create old-style commits
        commits_dir = tlm_dir / "commits"
        (commits_dir / "def456.json").write_text(json.dumps({
            "hash": "def456",
            "category": "bugfix",
            "lessons": ["Check null before access"],
        }))

        # Create old-style specs
        specs_dir = tlm_dir / "specs"
        (specs_dir / "search.md").write_text(
            "# Search Feature\n\nImplement full-text search."
        )

        # Create old-style lessons/synthesis
        lessons_dir = tlm_dir / "lessons"
        (lessons_dir / "2026-01-synthesis.json").write_text(json.dumps({
            "period": "2026-W01",
            "spec_accuracy_percent": 75,
            "total_commits": 5,
            "planned_commits": 4,
            "unplanned_commits": 1,
            "interview_improvements": ["Ask about search performance requirements"],
        }))

        cmd_migrate()
        captured = capsys.readouterr()

        assert "migration complete" in captured.out.lower()
        assert "rules imported" in captured.out.lower()
        assert "commits imported" in captured.out.lower()
        assert "specs imported" in captured.out.lower()
        assert "metrics imported" in captured.out.lower()

    def test_migrate_empty(self, installed_project, capsys):
        # Ensure knowledge.md has no real facts (just the header)
        tlm_dir = installed_project / ".tlm"
        (tlm_dir / "knowledge.md").write_text("# Knowledge Base\n")

        cmd_migrate()
        captured = capsys.readouterr()
        assert "no flat files to migrate" in captured.out.lower()

    def test_migrate_idempotent(self, installed_project, capsys):
        tlm_dir = installed_project / ".tlm"

        # Add some flat files
        (tlm_dir / "knowledge.md").write_text(
            "# Knowledge Base\n\n"
            "- Always validate user input\n"
        )

        # Migrate once
        cmd_migrate()
        capsys.readouterr()

        # Migrate again — should still work (adds duplicates, but doesn't crash)
        cmd_migrate()
        captured = capsys.readouterr()
        # Second migration either reports new imports or says already has rules
        assert "knowledge.db already has" in captured.out.lower() or "migration complete" in captured.out.lower()
