"""
Integration tests against running TLM server.

Requires a running server. Set TLM_TEST_SERVER_URL env var or defaults to http://localhost:8003.

Run: TLM_TEST_SERVER_URL=http://localhost:8003 ./venv/bin/python -m pytest tests/test_integration_server.py -v
"""

import os
import uuid
import pytest
import httpx


SERVER_URL = os.environ.get("TLM_TEST_SERVER_URL", "http://localhost:8003")


def _unique_email():
    return f"test-{uuid.uuid4().hex[:8]}@tlmforge.dev"


@pytest.fixture
def server_url():
    return SERVER_URL


class TestHealth:
    def test_health_endpoint(self, server_url):
        resp = httpx.get(f"{server_url}/health")
        assert resp.status_code == 200
        assert resp.json()["status"] == "ok"


class TestSignup:
    def test_signup_creates_user(self, server_url):
        email = _unique_email()
        resp = httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass123",
        })
        assert resp.status_code == 200
        data = resp.json()
        assert "api_key" in data
        assert data["api_key"].startswith("tlm_sk_")
        assert data["email"] == email

    def test_signup_duplicate_email_fails(self, server_url):
        email = _unique_email()
        httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass123",
        })
        resp = httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass123",
        })
        assert resp.status_code == 409


class TestLogin:
    def test_login_with_valid_credentials(self, server_url):
        email = _unique_email()
        httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "mypass",
        })
        resp = httpx.post(f"{server_url}/api/v1/auth/login", json={
            "email": email,
            "password": "mypass",
        })
        assert resp.status_code == 200
        assert "api_key" in resp.json()

    def test_login_wrong_password(self, server_url):
        email = _unique_email()
        httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "mypass",
        })
        resp = httpx.post(f"{server_url}/api/v1/auth/login", json={
            "email": email,
            "password": "wrongpass",
        })
        assert resp.status_code == 401


class TestAuthMe:
    def test_me_with_valid_key(self, server_url):
        email = _unique_email()
        signup_resp = httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass",
        })
        api_key = signup_resp.json()["api_key"]

        resp = httpx.get(f"{server_url}/api/v1/auth/me", headers={
            "Authorization": f"Bearer {api_key}",
        })
        assert resp.status_code == 200
        assert resp.json()["email"] == email

    def test_me_without_key_fails(self, server_url):
        resp = httpx.get(f"{server_url}/api/v1/auth/me")
        assert resp.status_code in (401, 403)


# ─── Full Flow: signup → create project → scan ──────────────

class TestFullFlow:
    def _auth_headers(self, api_key):
        return {"Authorization": f"Bearer {api_key}"}

    def test_signup_then_create_project(self, server_url):
        """Full flow: signup → create project → project appears in list."""
        email = _unique_email()
        signup_resp = httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass",
        })
        api_key = signup_resp.json()["api_key"]
        headers = self._auth_headers(api_key)

        # Create project
        resp = httpx.post(f"{server_url}/api/v1/projects", json={
            "name": "test-project",
            "fingerprint": "abc123",
        }, headers=headers)
        assert resp.status_code == 200
        project_id = resp.json()["project_id"]
        assert project_id is not None

        # List projects
        resp = httpx.get(f"{server_url}/api/v1/projects", headers=headers)
        assert resp.status_code == 200
        projects = resp.json()["projects"]
        assert any(p["project_id"] == project_id for p in projects)

    def test_scan_project(self, server_url):
        """Full flow: signup → create project → scan → get profile."""
        email = _unique_email()
        signup_resp = httpx.post(f"{server_url}/api/v1/auth/signup", json={
            "email": email,
            "password": "testpass",
        })
        api_key = signup_resp.json()["api_key"]
        headers = self._auth_headers(api_key)

        # Create project
        proj_resp = httpx.post(f"{server_url}/api/v1/projects", json={
            "name": "scan-test",
            "fingerprint": "scan123",
        }, headers=headers)
        project_id = proj_resp.json()["project_id"]

        # Scan
        resp = httpx.post(
            f"{server_url}/api/v1/projects/{project_id}/scan",
            json={
                "file_tree": "src/\n  main.py\n  utils.py\ntests/\n  test_main.py",
                "samples": "=== pyproject.toml ===\n[project]\nname = 'my-app'",
            },
            headers=headers,
            timeout=60.0,
        )
        assert resp.status_code == 200
        assert "profile" in resp.json()
        assert len(resp.json()["profile"]) > 10
