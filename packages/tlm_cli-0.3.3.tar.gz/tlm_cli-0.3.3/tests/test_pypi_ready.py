"""Tests to verify TLM package is ready for PyPI publication."""

import tomllib
from pathlib import Path

ROOT = Path(__file__).parent.parent


def _load_pyproject():
    with open(ROOT / "pyproject.toml", "rb") as f:
        return tomllib.load(f)


# ─── pyproject.toml metadata ─────────────────────────────────


class TestPyprojectMetadata:

    def test_name_is_get_tlm(self):
        data = _load_pyproject()
        assert data["project"]["name"] == "tlm-cli"

    def test_has_version(self):
        data = _load_pyproject()
        version = data["project"]["version"]
        assert version
        # Semver-ish: at least X.Y.Z
        parts = version.split(".")
        assert len(parts) >= 3, f"Version {version} should be X.Y.Z"

    def test_has_description(self):
        data = _load_pyproject()
        assert data["project"]["description"]

    def test_has_authors(self):
        data = _load_pyproject()
        authors = data["project"]["authors"]
        assert len(authors) >= 1
        assert authors[0]["name"]

    def test_has_license(self):
        data = _load_pyproject()
        assert "license" in data["project"]

    def test_requires_python(self):
        data = _load_pyproject()
        assert data["project"]["requires-python"] == ">=3.9"

    def test_has_project_urls(self):
        data = _load_pyproject()
        urls = data["project"]["urls"]
        assert "Homepage" in urls
        assert "Source" in urls

    def test_has_classifiers(self):
        data = _load_pyproject()
        classifiers = data["project"]["classifiers"]
        assert len(classifiers) >= 3
        classifier_text = "\n".join(classifiers)
        assert "Python" in classifier_text

    def test_has_httpx_dependency(self):
        data = _load_pyproject()
        deps = data["project"]["dependencies"]
        assert any("httpx" in d for d in deps)

    def test_has_cli_entrypoint(self):
        data = _load_pyproject()
        scripts = data["project"]["scripts"]
        assert scripts["tlm"] == "tlm.cli:main"

    def test_readme_referenced(self):
        data = _load_pyproject()
        assert data["project"]["readme"] == "README.md"


# ─── README.md content ────────────────────────────────────────


class TestReadmeForPyPI:

    def _read_readme(self):
        return (ROOT / "README.md").read_text()

    def test_readme_exists(self):
        assert (ROOT / "README.md").exists()

    def test_has_pip_install_instruction(self):
        content = self._read_readme()
        assert "pipx install tlm-cli" in content

    def test_has_signup_instruction(self):
        content = self._read_readme()
        assert "tlm signup" in content

    def test_has_install_instruction(self):
        content = self._read_readme()
        assert "tlm install" in content

    def test_has_quick_start_section(self):
        content = self._read_readme()
        assert "Quick Start" in content or "quick start" in content.lower()

    def test_no_dev_install_as_primary(self):
        """PyPI README should lead with `pipx install tlm-cli`, not `pip install -e .`"""
        content = self._read_readme()
        lines = content.split("\n")
        # Find the first pip install line
        for line in lines:
            if "pip install" in line:
                assert "pipx install tlm-cli" in line, \
                    f"First pip install should be 'pipx install tlm-cli', got: {line.strip()}"
                break

    def test_no_anthropic_api_key_reference(self):
        """Client no longer uses Anthropic directly — should reference TLM server."""
        content = self._read_readme()
        assert "ANTHROPIC_API_KEY" not in content
