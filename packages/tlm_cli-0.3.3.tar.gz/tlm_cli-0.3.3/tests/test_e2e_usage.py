"""
E2E usage-tracking tests against the live TLM server.

Verifies the full path: client → HTTP → credit deduction → DB state → response.

Requires:
  - Running server (TLM_TEST_SERVER_URL, defaults to http://localhost:8003)
  - PostgreSQL accessible via psql

Run:
  cd /home/thegpc806/tlm/mvp && ./venv/bin/python -m pytest tests/test_e2e_usage.py -v
"""

import os
import subprocess
import uuid

import httpx
import pytest

from tlm.api_client import TLMClient, TLMCreditsError, TLMProjectLimitError


SERVER_URL = os.environ.get("TLM_TEST_SERVER_URL", "http://localhost:8003")
DB_PASSWORD = os.environ.get("TLM_TEST_DB_PASSWORD", "sbQa9cO3Rfrx-xPLlaEJG6dryw0djVNt")
DB_USER = "tlm_user"
DB_NAME = "tlm"
DB_HOST = "localhost"


def _unique_email():
    return f"e2e-{uuid.uuid4().hex[:8]}@tlmforge.dev"


def _psql_query(sql: str) -> str:
    """Run a psql query and return raw output."""
    result = subprocess.run(
        [
            "psql",
            "-h", DB_HOST,
            "-U", DB_USER,
            "-d", DB_NAME,
            "-t",    # tuples only (no header/footer)
            "-A",    # unaligned output
            "-F", "|",  # pipe-delimited
            "-c", sql,
        ],
        capture_output=True,
        text=True,
        env={**os.environ, "PGPASSWORD": DB_PASSWORD},
        timeout=10,
    )
    assert result.returncode == 0, f"psql failed: {result.stderr}"
    return result.stdout.strip()


def _signup_and_client() -> tuple[TLMClient, str, str]:
    """Signup a fresh user, return (client, api_key, email)."""
    email = _unique_email()
    resp = httpx.post(f"{SERVER_URL}/api/v1/auth/signup", json={
        "email": email,
        "password": "testpass123",
    })
    assert resp.status_code == 200, f"Signup failed: {resp.text}"
    api_key = resp.json()["api_key"]
    client = TLMClient(api_key=api_key, base_url=SERVER_URL)
    return client, api_key, email


def _create_project(api_key: str, name: str = "e2e-proj", fingerprint: str = None) -> int:
    """Create a project and return project_id."""
    if fingerprint is None:
        fingerprint = uuid.uuid4().hex[:12]
    resp = httpx.post(
        f"{SERVER_URL}/api/v1/projects",
        json={"name": name, "fingerprint": fingerprint},
        headers={"Authorization": f"Bearer {api_key}"},
    )
    assert resp.status_code == 200, f"Create project failed: {resp.text}"
    return resp.json()["project_id"]


# ─── Tests ────────────────────────────────────────────────────


class TestUsageEndpoint:
    def test_usage_endpoint_fresh_user(self):
        """Fresh user → GET /usage → 150 credits, 0 used, free tier."""
        client, _, _ = _signup_and_client()
        usage = client.usage()
        assert usage["credits_total"] == 150
        assert usage["credits_used"] == 0
        assert usage["credits_remaining"] == 150
        assert usage["tier"] == "free"

    def test_me_includes_credits(self):
        """GET /auth/me → response includes credits_remaining and credits_total."""
        client, _, _ = _signup_and_client()
        me = client.me()
        assert "credits_remaining" in me
        assert "credits_total" in me
        assert me["credits_remaining"] == 150
        assert me["credits_total"] == 150


class TestScanCredits:
    def test_scan_deducts_credits_and_logs_event(self):
        """Scan → credits deducted, usage_events row with tokens > 0."""
        client, api_key, email = _signup_and_client()
        project_id = _create_project(api_key)

        # Scan via raw httpx so we can inspect response headers
        resp = httpx.post(
            f"{SERVER_URL}/api/v1/projects/{project_id}/scan",
            json={
                "file_tree": "src/\n  main.py\n  utils.py\ntests/\n  test_main.py",
                "samples": "=== pyproject.toml ===\n[project]\nname = 'e2e-test'",
            },
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=60.0,
        )
        assert resp.status_code == 200
        assert "profile" in resp.json()

        # Check X-Credits-Remaining header
        remaining_header = resp.headers.get("x-credits-remaining")
        assert remaining_header is not None, "Missing X-Credits-Remaining header"
        remaining = int(remaining_header)
        assert remaining < 150, f"Expected credits < 150, got {remaining}"

        # Verify via /usage endpoint
        usage = client.usage()
        assert usage["credits_used"] > 0
        assert usage["credits_remaining"] < 150

        # Verify DB: usage_events row exists
        user_id = _psql_query(
            f"SELECT id FROM users WHERE email = '{email}'"
        )
        assert user_id, f"User not found in DB for {email}"

        events_raw = _psql_query(
            f"SELECT operation, credits, input_tokens, output_tokens "
            f"FROM usage_events WHERE user_id = {user_id} ORDER BY id DESC LIMIT 1"
        )
        assert events_raw, "No usage_events row found"
        parts = events_raw.split("|")
        assert len(parts) == 4, f"Unexpected psql output: {events_raw}"
        operation, credits, input_tokens, output_tokens = parts
        assert operation == "scan"
        assert int(credits) > 0
        assert int(input_tokens) > 0
        assert int(output_tokens) > 0


class TestCreditExhaustion:
    def test_402_when_credits_exhausted(self):
        """Set credits_used = credits_total in DB → scan returns 402 / TLMCreditsError."""
        client, api_key, email = _signup_and_client()
        project_id = _create_project(api_key)

        # Exhaust credits via direct DB update
        _psql_query(
            f"UPDATE users SET credits_used = credits_total WHERE email = '{email}'"
        )

        with pytest.raises(TLMCreditsError):
            client.scan(str(project_id), "src/\n  main.py", "# nothing")


class TestUnlimitedProjects:
    def test_free_tier_allows_multiple_projects(self):
        """Free tier allows unlimited projects — no project limit enforced."""
        client, api_key, _ = _signup_and_client()

        # Both projects should succeed
        _create_project(api_key, name="proj-1", fingerprint="fp-aaa")
        _create_project(api_key, name="proj-2", fingerprint="fp-bbb")

    def test_same_fingerprint_returns_existing(self):
        """Same fingerprint → returns existing project."""
        client, api_key, _ = _signup_and_client()

        fp = "fp-same-" + uuid.uuid4().hex[:6]
        result1 = client.create_project("proj-1", fp)
        result2 = client.create_project("proj-1-again", fp)

        # Same project returned
        assert result1["project_id"] == result2["project_id"]
