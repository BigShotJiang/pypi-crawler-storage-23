"""
Tests for learner classes when using TLM API client (server-backed mode).

CommitAnalyzer and LearningSynthesizer should work identically whether
backed by Claude (local) or TLMClient (server).
"""

import json
from unittest.mock import MagicMock
from pathlib import Path

import pytest

from tlm.engine import Project
from tlm.learner import CommitAnalyzer, LearningSynthesizer, Learner


SAMPLE_COMMIT = {
    "hash": "abc1234",
    "message": "Add user auth",
    "author": "dev",
    "date": "2024-01-15T10:00:00",
    "diff": "diff --git a/auth.py b/auth.py\n+def login():\n+    pass",
}

SAMPLE_ANALYSIS = {
    "hash": "abc1234",
    "category": "feature",
    "planned": True,
    "matching_spec": "auth-spec.md",
    "summary": "Added user authentication",
    "lessons": ["Auth needs rate limiting"],
}

SAMPLE_SYNTHESIS = {
    "total_commits": 5,
    "planned_commits": 4,
    "unplanned_commits": 1,
    "spec_accuracy_percent": 80,
    "bug_patterns": [],
    "unplanned_features": [],
    "architecture_evolutions": [],
    "testing_gaps": [],
    "operational_lessons": [],
    "interview_improvements": ["Ask about rate limiting"],
}


@pytest.fixture
def project_with_tlm(tmp_path):
    project = Project(str(tmp_path))
    project.init()
    return project


@pytest.fixture
def mock_api_client():
    return MagicMock()


class TestCommitAnalyzerAPI:
    def test_analyze_commit_calls_api(self, project_with_tlm, mock_api_client):
        mock_api_client.analyze_commit.return_value = {"analysis": SAMPLE_ANALYSIS}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api_client, project_id="123")

        result = analyzer.analyze_commit(SAMPLE_COMMIT)

        assert result == SAMPLE_ANALYSIS
        mock_api_client.analyze_commit.assert_called_once_with("123", SAMPLE_COMMIT)

    def test_analyze_batch_calls_api_for_each(self, project_with_tlm, mock_api_client):
        mock_api_client.analyze_commit.return_value = {"analysis": SAMPLE_ANALYSIS}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api_client, project_id="123")

        commits = [SAMPLE_COMMIT, {**SAMPLE_COMMIT, "hash": "def5678"}]
        results = analyzer.analyze_batch(commits)

        assert len(results) == 2
        assert mock_api_client.analyze_commit.call_count == 2

    def test_analyze_batch_with_progress(self, project_with_tlm, mock_api_client):
        mock_api_client.analyze_commit.return_value = {"analysis": SAMPLE_ANALYSIS}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api_client, project_id="123")

        progress_calls = []
        def progress(current, total, hash_str, summary):
            progress_calls.append((current, total))

        analyzer.analyze_batch([SAMPLE_COMMIT], progress_callback=progress)
        assert progress_calls == [(1, 1)]


class TestLearningSynthesizerAPI:
    def test_synthesize_calls_api(self, project_with_tlm, mock_api_client):
        mock_api_client.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS}
        synth = LearningSynthesizer(project_with_tlm, api_client=mock_api_client, project_id="123")

        result = synth.synthesize([SAMPLE_ANALYSIS])

        assert result == SAMPLE_SYNTHESIS
        mock_api_client.synthesize.assert_called_once_with("123", [SAMPLE_ANALYSIS])


class TestLearnerAPI:
    def test_learn_last_commit_uses_api(self, project_with_tlm, mock_api_client):
        """Learner.learn_last_commit should use API-backed CommitAnalyzer."""
        mock_api_client.analyze_commit.return_value = {"analysis": SAMPLE_ANALYSIS}
        learner = Learner(project_with_tlm, api_client=mock_api_client, project_id="123")

        # Mock git reader to return a commit
        learner.git = MagicMock()
        learner.git.get_last_commit.return_value = SAMPLE_COMMIT

        result = learner.learn_last_commit()

        assert result == SAMPLE_ANALYSIS
        mock_api_client.analyze_commit.assert_called_once()
