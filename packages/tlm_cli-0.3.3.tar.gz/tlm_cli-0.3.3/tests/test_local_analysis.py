"""
Tests for Scanner._get_local_analysis — silent local Claude analysis.

Verifies:
- Returns None when claude CLI not found
- Returns None on subprocess timeout
- Returns stdout on success
- Execution is silent (capture_output=True, no stderr leak)
- local_analysis is passed through to API client
"""

from unittest.mock import MagicMock, patch, call
import subprocess

import pytest

from tlm.engine import Project, Scanner


@pytest.fixture
def project_with_tlm(tmp_path):
    project = Project(str(tmp_path))
    project.init()
    return project


@pytest.fixture
def mock_api_client():
    client = MagicMock()
    client.scan.return_value = {"profile": "## Stack\nTest profile"}
    return client


class TestGetLocalAnalysis:
    @patch("tlm.engine.shutil.which", return_value=None)
    def test_claude_not_found(self, mock_which, project_with_tlm, mock_api_client):
        """When claude CLI is not installed, _get_local_analysis returns None."""
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")

        result = scanner._get_local_analysis("file_tree", "samples")

        assert result is None
        mock_which.assert_called_once_with("claude")

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_timeout_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """When claude subprocess times out, return None."""
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=90)

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = scanner._get_local_analysis("file_tree", "samples")

        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_success_returns_stdout(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """On success, return stripped stdout."""
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="## Stack\nPython, FastAPI\n## Testing\npytest\n",
        )

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = scanner._get_local_analysis("file_tree", "samples")

        assert result == "## Stack\nPython, FastAPI\n## Testing\npytest"

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_is_silent(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Verify subprocess is called with capture_output=True for silent execution."""
        mock_run.return_value = MagicMock(returncode=0, stdout="profile")

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        scanner._get_local_analysis("file_tree", "samples")

        # Verify capture_output=True is passed
        call_kwargs = mock_run.call_args
        assert call_kwargs.kwargs.get("capture_output") is True
        assert call_kwargs.kwargs.get("text") is True

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_no_model_flag(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Verify --model flag is NOT passed — uses user's default."""
        mock_run.return_value = MagicMock(returncode=0, stdout="profile")

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        scanner._get_local_analysis("file_tree", "samples")

        cmd_args = mock_run.call_args[0][0]
        assert "--model" not in cmd_args

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_nonzero_exit_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Non-zero exit code returns None."""
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="error")

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = scanner._get_local_analysis("file_tree", "samples")

        assert result is None

    @patch("tlm.engine.subprocess.run")
    @patch("tlm.engine.shutil.which", return_value="/usr/bin/claude")
    def test_exception_returns_none(self, mock_which, mock_run, project_with_tlm, mock_api_client):
        """Any exception returns None (graceful degradation)."""
        mock_run.side_effect = OSError("Permission denied")

        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        result = scanner._get_local_analysis("file_tree", "samples")

        assert result is None


class TestScannerWithLocalAnalysis:
    @patch("tlm.engine.Scanner._get_local_analysis", return_value="## Stack\nLocal analysis")
    def test_scan_passes_local_analysis_to_api(self, mock_local, project_with_tlm, mock_api_client):
        """Scanner.scan() should call _get_local_analysis and pass result to API."""
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        scanner.scan()

        # Verify local_analysis was passed in the API call
        call_kwargs = mock_api_client.scan.call_args
        assert call_kwargs.kwargs.get("local_analysis") == "## Stack\nLocal analysis" or \
            (len(call_kwargs[0]) >= 4 and call_kwargs[0][3] == "## Stack\nLocal analysis")

    @patch("tlm.engine.Scanner._get_local_analysis", return_value=None)
    def test_scan_works_without_local_analysis(self, mock_local, project_with_tlm, mock_api_client):
        """Scanner.scan() works even when local analysis returns None."""
        scanner = Scanner(project_with_tlm, api_client=mock_api_client, project_id="123")
        profile = scanner.scan()

        assert profile == "## Stack\nTest profile"
