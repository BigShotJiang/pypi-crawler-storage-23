"""
Tests for TLM gaps feature — extraction, CLI command, status display, hook injection.
"""

import json
import os
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.engine import Project, extract_gaps_from_profile


# ─── Sample profiles ──────────────────────────────────────────

PROFILE_WITH_GAPS = """# Technical Project Profile

## Stack
- **Language(s)**: Python
- **Framework(s)**: FastAPI

## Testing
- **Test Framework**: pytest

## Gaps
- **CI/CD Pipeline**: No GitHub Actions, Jenkins, or other CI configuration detected
- **SSL/TLS Configuration**: No HTTPS/SSL configuration visible
- **Backup Strategy**: No database backup configuration detected
- **Logging Configuration**: No logging setup files detected
- **Rate Limiting**: No rate limiting middleware or configuration detected
- **Documentation**: No README.md in root, API documentation unclear
"""

PROFILE_NO_GAPS = """# Technical Project Profile

## Stack
- **Language(s)**: Python

## Testing
- **Test Framework**: pytest
"""

PROFILE_EMPTY_GAPS = """# Technical Project Profile

## Stack
- Python

## Gaps
"""


# ─── extract_gaps_from_profile ─────────────────────────────────

class TestExtractGapsFromProfile:
    def test_extracts_all_gaps(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        assert len(gaps) == 6

    def test_gap_has_required_fields(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        for gap in gaps:
            assert "id" in gap
            assert "category" in gap
            assert "description" in gap
            assert "severity" in gap
            assert "dismissed" in gap

    def test_dismissed_defaults_false(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        for gap in gaps:
            assert gap["dismissed"] is False

    def test_high_severity_for_security(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        ssl_gap = next(g for g in gaps if "SSL" in g["category"])
        assert ssl_gap["severity"] == "high"

    def test_high_severity_for_cicd(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        cicd_gap = next(g for g in gaps if "CI/CD" in g["category"])
        assert cicd_gap["severity"] == "high"

    def test_high_severity_for_backup(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        backup_gap = next(g for g in gaps if "Backup" in g["category"])
        assert backup_gap["severity"] == "high"

    def test_medium_severity_for_logging(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        log_gap = next(g for g in gaps if "Logging" in g["category"])
        assert log_gap["severity"] == "medium"

    def test_medium_severity_for_rate_limiting(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        rl_gap = next(g for g in gaps if "Rate Limiting" in g["category"])
        assert rl_gap["severity"] == "medium"

    def test_low_severity_for_documentation(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        doc_gap = next(g for g in gaps if "Documentation" in g["category"])
        assert doc_gap["severity"] == "low"

    def test_stable_ids(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        ids = [g["id"] for g in gaps]
        assert "no-ci-cd-pipeline" in ids
        assert "no-ssl-tls-configuration" in ids

    def test_no_gaps_section_returns_empty(self):
        gaps = extract_gaps_from_profile(PROFILE_NO_GAPS)
        assert gaps == []

    def test_empty_gaps_section_returns_empty(self):
        gaps = extract_gaps_from_profile(PROFILE_EMPTY_GAPS)
        assert gaps == []

    def test_empty_string_returns_empty(self):
        gaps = extract_gaps_from_profile("")
        assert gaps == []

    def test_description_matches_profile(self):
        gaps = extract_gaps_from_profile(PROFILE_WITH_GAPS)
        cicd_gap = next(g for g in gaps if "CI/CD" in g["category"])
        assert "No GitHub Actions" in cicd_gap["description"]


# ─── gaps.json file management ─────────────────────────────────

class TestGapsJsonFile:
    def test_gaps_json_written_by_project(self, tmp_path):
        """Project can save and load gaps.json."""
        project = Project(str(tmp_path))
        project.init()

        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": False},
        ]
        gaps_file = project.tlm_dir / "gaps.json"
        gaps_file.write_text(json.dumps({"gaps": gaps}, indent=2))

        loaded = json.loads(gaps_file.read_text())
        assert len(loaded["gaps"]) == 1
        assert loaded["gaps"][0]["id"] == "no-cicd"


# ─── CLI: tlm gaps command ─────────────────────────────────────

class TestCmdGaps:
    def _setup_project(self, tmp_path, gaps=None):
        project = Project(str(tmp_path))
        project.init()
        if gaps is not None:
            gaps_file = project.tlm_dir / "gaps.json"
            gaps_file.write_text(json.dumps({"gaps": gaps}, indent=2))
        return project

    def test_gaps_shows_all(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        gaps = [
            {"id": "no-cicd", "category": "CI/CD Pipeline", "description": "No CI/CD", "severity": "high", "dismissed": False},
            {"id": "no-logging", "category": "Logging", "description": "No logging", "severity": "medium", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps()
        out = capsys.readouterr().out
        assert "No CI/CD" in out
        assert "No logging" in out
        assert "HIGH" in out.upper() or "high" in out

    def test_gaps_no_file_shows_message(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        project = self._setup_project(tmp_path)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps()
        out = capsys.readouterr().out
        assert "no gaps" in out.lower() or "tlm install" in out.lower()

    def test_gaps_dismiss_marks_dismissed(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": False},
            {"id": "no-logging", "category": "Logging", "description": "No logging", "severity": "medium", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps(action="dismiss", args=["1"])

        # Verify file updated
        loaded = json.loads((project.tlm_dir / "gaps.json").read_text())
        assert loaded["gaps"][0]["dismissed"] is True
        assert loaded["gaps"][1]["dismissed"] is False

    def test_gaps_dismiss_with_reason(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps(action="dismiss", args=["1", "--reason", "handled externally"])

        loaded = json.loads((project.tlm_dir / "gaps.json").read_text())
        assert loaded["gaps"][0]["dismissed"] is True
        assert loaded["gaps"][0].get("dismiss_reason") == "handled externally"

    def test_gaps_dismiss_invalid_number(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps(action="dismiss", args=["99"])
        out = capsys.readouterr().out
        assert "invalid" in out.lower() or "not found" in out.lower()

    def test_gaps_shows_dismissed_count(self, tmp_path, capsys):
        from tlm.cli import cmd_gaps
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": True},
            {"id": "no-logging", "category": "Logging", "description": "No logging", "severity": "medium", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_gaps()
        out = capsys.readouterr().out
        assert "1 active" in out or "1 dismissed" in out


# ─── CLI: tlm status with gaps ─────────────────────────────────

class TestStatusWithGaps:
    def _setup_project(self, tmp_path, gaps=None):
        project = Project(str(tmp_path))
        project.init()
        config = {"project_name": "test", "created": "2024-01-01", "sessions_used": 0}
        project.config_file.write_text(json.dumps(config))
        (tmp_path / ".git" / "hooks").mkdir(parents=True, exist_ok=True)
        if gaps is not None:
            gaps_file = project.tlm_dir / "gaps.json"
            gaps_file.write_text(json.dumps({"gaps": gaps}, indent=2))
        return project

    @patch("tlm.cli.logo")
    def test_status_shows_gaps(self, mock_logo, tmp_path, capsys):
        from tlm.cli import cmd_status
        gaps = [
            {"id": "no-cicd", "category": "CI/CD Pipeline", "description": "No CI/CD pipeline", "severity": "high", "dismissed": False},
            {"id": "no-logging", "category": "Logging", "description": "No logging config", "severity": "medium", "dismissed": False},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_status()
        out = capsys.readouterr().out
        assert "Project Health" in out or "gaps" in out.lower()
        assert "No CI/CD" in out

    @patch("tlm.cli.logo")
    def test_status_hides_dismissed_gaps(self, mock_logo, tmp_path, capsys):
        from tlm.cli import cmd_status
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD", "severity": "high", "dismissed": True},
        ]
        project = self._setup_project(tmp_path, gaps)
        with patch("tlm.cli.Project", return_value=project):
            cmd_status()
        out = capsys.readouterr().out
        # Dismissed gaps should not appear as active
        assert "No CI/CD" not in out or "0 active" in out.lower() or "dismissed" in out.lower()

    @patch("tlm.cli.logo")
    def test_status_no_gaps_file_ok(self, mock_logo, tmp_path, capsys):
        from tlm.cli import cmd_status
        project = self._setup_project(tmp_path)
        with patch("tlm.cli.Project", return_value=project):
            cmd_status()
        # Should not crash, no gaps section shown
        out = capsys.readouterr().out
        assert "Project Health" not in out


# ─── Hooks: session start with gaps ────────────────────────────

class TestSessionStartWithGaps:
    def _setup_project(self, tmp_path, gaps=None):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir(exist_ok=True)
        config = {"project_name": "test", "quality_control": "standard"}
        (tlm_dir / "config.json").write_text(json.dumps(config))
        state = {"phase": "idle"}
        (tlm_dir / "state.json").write_text(json.dumps(state))
        if gaps is not None:
            (tlm_dir / "gaps.json").write_text(json.dumps({"gaps": gaps}, indent=2))
        return tmp_path

    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_shows_high_severity_gaps(self, mock_sync, tmp_path):
        from tlm.hooks import hook_session_start
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD pipeline", "severity": "high", "dismissed": False},
            {"id": "no-ssl", "category": "Security", "description": "No SSL/TLS", "severity": "high", "dismissed": False},
            {"id": "no-logging", "category": "Logging", "description": "No logging", "severity": "medium", "dismissed": False},
        ]
        self._setup_project(tmp_path, gaps)
        result = hook_session_start(str(tmp_path))
        assert "No CI/CD" in result
        assert "No SSL/TLS" in result
        assert "gaps" in result.lower()

    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_hides_dismissed_gaps(self, mock_sync, tmp_path):
        from tlm.hooks import hook_session_start
        gaps = [
            {"id": "no-cicd", "category": "CI/CD", "description": "No CI/CD pipeline", "severity": "high", "dismissed": True},
        ]
        self._setup_project(tmp_path, gaps)
        result = hook_session_start(str(tmp_path))
        assert "No CI/CD" not in result

    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_no_gaps_file_ok(self, mock_sync, tmp_path):
        from tlm.hooks import hook_session_start
        self._setup_project(tmp_path)
        result = hook_session_start(str(tmp_path))
        # Should not crash, no gaps mentioned
        assert "Known project gaps" not in result

    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_start_caps_at_5_high_severity(self, mock_sync, tmp_path):
        from tlm.hooks import hook_session_start
        gaps = [
            {"id": f"gap-{i}", "category": f"Cat{i}", "description": f"Gap {i}", "severity": "high", "dismissed": False}
            for i in range(8)
        ]
        self._setup_project(tmp_path, gaps)
        result = hook_session_start(str(tmp_path))
        # Should show at most 5 high-severity gaps
        gap_lines = [l for l in result.split("\n") if "Gap " in l]
        assert len(gap_lines) <= 5
