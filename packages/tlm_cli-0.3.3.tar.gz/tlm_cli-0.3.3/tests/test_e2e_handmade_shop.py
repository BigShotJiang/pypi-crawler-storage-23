"""E2E scenario tests — Handmade Products Shop.

Full TLM lifecycle test: a user building a website to sell handmade products.
Real git repo, real .tlm/ structure, mocked server HTTP calls.

Tests exercise the complete chain:
  session start → gap enforcement → interview → spec review
  → TDD enforcement → compliance → session learning

Each test phase builds on prior state (sequential within a class).
"""

import json
import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.hooks import (
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
    hook_compliance_gate,
    hook_stop,
)
from tlm.installer import Installer
from tlm.knowledge_db import KnowledgeDB
from tlm.state import write_state, read_state


# ─── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture
def shop_project(tmp_path):
    """Create a realistic handmade products shop project.

    Sets up:
    - Git repo with initial commit
    - .tlm/ with config (quality=standard), knowledge DB (3 facts)
    - gaps.json with realistic gaps
    - Basic project files: app/, templates/, static/
    - TLM installed via Installer
    """
    root = tmp_path / "handmade-shop"
    root.mkdir()

    # Create git repo
    subprocess.run(["git", "init"], cwd=str(root), capture_output=True, check=True)
    subprocess.run(
        ["git", "config", "user.email", "artisan@shop.com"],
        cwd=str(root), capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Artisan Dev"],
        cwd=str(root), capture_output=True,
    )

    # Create project file structure
    (root / "app").mkdir()
    (root / "app" / "__init__.py").write_text("")
    (root / "app" / "main.py").write_text(
        "from flask import Flask\napp = Flask(__name__)\n"
    )
    (root / "app" / "models.py").write_text(
        "# Product model placeholder\n"
    )
    (root / "templates").mkdir()
    (root / "templates" / "index.html").write_text("<h1>Handmade Shop</h1>\n")
    (root / "static").mkdir()
    (root / "static" / "style.css").write_text("body { font-family: serif; }\n")
    (root / "requirements.txt").write_text("flask\nstripe\nsqlalchemy\n")

    # Initial commit
    subprocess.run(["git", "add", "."], cwd=str(root), capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial shop scaffold"],
        cwd=str(root), capture_output=True,
    )

    # Set up .tlm/ directory
    tlm_dir = root / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    (tlm_dir / "lessons").mkdir()
    (tlm_dir / "commits").mkdir()

    # Config
    config = {
        "project_name": "handmade-shop",
        "project_id": 99,
        "quality_control": "standard",
        "session_learning": True,
        "sessions_used": 3,
    }
    (tlm_dir / "config.json").write_text(json.dumps(config, indent=2))

    # Knowledge DB with 3 facts
    db = KnowledgeDB(str(tlm_dir))
    db.init_db()
    db.add_rule("Project uses Flask for the web framework", source="scan")
    db.add_rule("Products have images stored in S3", source="scan")
    db.add_rule("Payments processed via Stripe", source="scan")
    db.close()

    # Knowledge.md (flat file)
    (tlm_dir / "knowledge.md").write_text(
        "# Handmade Shop Knowledge\n\n"
        "- Framework: Flask\n"
        "- Image storage: S3\n"
        "- Payments: Stripe\n"
    )

    # Gaps
    gaps = {
        "gaps": [
            {
                "id": "no-test-framework",
                "category": "Testing",
                "description": "No test framework configured (pytest or unittest)",
                "severity": "high",
                "dismissed": False,
            },
            {
                "id": "no-ci-cd-pipeline",
                "category": "CI/CD",
                "description": "No CI/CD pipeline configured",
                "severity": "high",
                "dismissed": False,
            },
            {
                "id": "no-ssl-tls",
                "category": "Security",
                "description": "No SSL/TLS configuration found",
                "severity": "high",
                "dismissed": False,
            },
            {
                "id": "no-rate-limiting",
                "category": "Security",
                "description": "No rate limiting on API endpoints",
                "severity": "medium",
                "dismissed": False,
            },
        ]
    }
    (tlm_dir / "gaps.json").write_text(json.dumps(gaps, indent=2))

    # State — idle
    write_state(str(root), {
        "phase": "idle",
        "activity_type": None,
        "active_spec": None,
        "spec_review_status": "none",
        "spec_review_gaps": [],
    })

    # Install TLM hooks
    installer = Installer(str(root))
    installer.install()

    return root


def _set_state(root, phase, activity_type=None, active_spec=None,
               spec_review_status="none"):
    write_state(str(root), {
        "phase": phase,
        "activity_type": activity_type,
        "active_spec": active_spec,
        "spec_review_status": spec_review_status,
        "spec_review_gaps": [],
    })


def _set_quality(root, level):
    config_file = root / ".tlm" / "config.json"
    config = json.loads(config_file.read_text())
    config["quality_control"] = level
    config_file.write_text(json.dumps(config, indent=2))


# ═══════════════════════════════════════════════════════════════════
# PHASE 0: SESSION START
# ═══════════════════════════════════════════════════════════════════


class TestSessionStart:
    """Session start loads context: gaps, knowledge, quality level."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_includes_gaps(self, mock_sync, mock_client, shop_project):
        result = hook_session_start(str(shop_project))
        assert "Known project gaps" in result
        assert "test framework" in result.lower() or "testing" in result.lower()

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_includes_knowledge(self, mock_sync, mock_client, shop_project):
        result = hook_session_start(str(shop_project))
        assert "Flask" in result or "Stripe" in result or "S3" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_includes_quality(self, mock_sync, mock_client, shop_project):
        result = hook_session_start(str(shop_project))
        assert "standard" in result

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_session_clears_caches(self, mock_sync, mock_client, shop_project):
        """Session start clears interview guide and session test caches."""
        cache_dir = shop_project / ".tlm" / "cache"
        (cache_dir / "interview_guide.json").write_text("{}")
        (cache_dir / "session_tests.json").write_text("{}")

        hook_session_start(str(shop_project))

        assert not (cache_dir / "interview_guide.json").exists()
        assert not (cache_dir / "session_tests.json").exists()


# ═══════════════════════════════════════════════════════════════════
# PHASE 1: GAP BLOCKING
# ═══════════════════════════════════════════════════════════════════


class TestGapBlocking:
    """Prerequisite gaps block TLM activation and implementation."""

    def test_prerequisite_gap_blocks_tlm_active_from_nonidle(self, shop_project):
        """no-test-framework blocks transition to tlm_active from a non-idle phase.

        Tests mid-session transition (e.g. implementation → new feature).
        The idle → tlm_active path is covered by TestIdleToTlmActiveGapEnforcement
        in test_enforcement_v3.py.
        """
        _set_state(shop_project, "implementation", "other_feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "tlm_active", "activity_type": "feature"}),
            },
        })
        assert result.get("decision") == "block"
        assert "test framework" in result["reason"].lower() or "infrastructure" in result["reason"].lower()

    def test_prerequisite_gap_blocks_implementation(self, shop_project):
        """no-test-framework blocks transition to implementation."""
        _set_state(shop_project, "tlm_active", "feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") == "block"

    def test_relaxed_quality_warns_instead(self, shop_project):
        """Relaxed quality: prerequisite gap warns, doesn't block."""
        _set_quality(shop_project, "relaxed")
        _set_state(shop_project, "implementation", "other_feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "tlm_active", "activity_type": "feature"}),
            },
        })
        assert result.get("decision") != "block"
        assert "additionalContext" in result
        assert "test framework" in result["additionalContext"].lower()

    def test_dismissed_prerequisite_allows(self, shop_project):
        """Dismissed prerequisite gap doesn't block."""
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        _set_state(shop_project, "idle")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "tlm_active", "activity_type": "feature"}),
            },
        })
        # Should not block (the other gaps are not prerequisite)
        assert result.get("decision") != "block"


# ═══════════════════════════════════════════════════════════════════
# PHASE 2: INTERVIEW
# ═══════════════════════════════════════════════════════════════════


class TestInterview:
    """During interview phase: source writes blocked, tests/specs allowed."""

    def test_source_writes_blocked(self, shop_project):
        """Source code writes blocked during interview."""
        _set_state(shop_project, "tlm_active", "feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products/views.py"},
        })
        assert result.get("decision") == "block"
        assert "interview" in result["reason"].lower()

    def test_test_writes_allowed(self, shop_project):
        """Test file writes allowed during interview."""
        _set_state(shop_project, "tlm_active", "feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_products.py"},
        })
        assert result == {}

    def test_spec_writes_allowed(self, shop_project):
        """Spec file writes allowed during interview."""
        _set_state(shop_project, "tlm_active", "feature")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "specs" / "product-catalog.md"),
            },
        })
        # Spec writes trigger spec review status update, but don't block
        assert result.get("decision") != "block"

    @patch("tlm.hooks.get_client")
    def test_prompt_includes_interview_guidance(self, mock_client, shop_project):
        """Prompt submit in tlm_active includes interview guide context."""
        _set_state(shop_project, "tlm_active", "feature")

        # Mock server-sourced interview guide
        client = MagicMock()
        client.get_interview_guide.return_value = {
            "guide": {
                "interview_protocol": {
                    "structure": [
                        {"phase": "Scope", "questions_range": "1-3", "focus": "Product catalog"},
                    ],
                    "must_ask": ["How many product categories?"],
                },
                "rules": ["Ask ONE question at a time"],
                "relevant_gaps": ["No test framework"],
            }
        }
        mock_client.return_value = client

        result = hook_prompt_submit(str(shop_project), prompt_text="I want product categories")
        ctx = result["additionalContext"]
        assert "interview" in ctx.lower()
        assert "Scope" in ctx or "Product catalog" in ctx or "ONE question" in ctx


# ═══════════════════════════════════════════════════════════════════
# PHASE 3: SPEC REVIEW
# ═══════════════════════════════════════════════════════════════════


class TestSpecReview:
    """Spec review gates implementation phase transition."""

    def _write_shop_spec(self, root, good=True):
        """Write a product catalog spec."""
        content = (
            "# Product Catalog Feature\n\n"
            "## Overview\n"
            "Add product listing with categories, images, and pricing.\n\n"
            "## Data Model\n"
            "- Product: name, description, price, images[], category\n"
            "- Category: name, slug\n\n"
            "## API Endpoints\n"
            "- GET /products — list with pagination\n"
            "- GET /products/<id> — single product\n"
            "- POST /products — create (admin only)\n\n"
        )
        if good:
            content += (
                "## Error Handling\n"
                "- 404 on missing product\n"
                "- 403 on unauthorized create\n"
                "- Validate image sizes\n\n"
                "## Testing Strategy\n"
                "- Unit tests for model validation\n"
                "- Integration tests for API endpoints\n"
            )
        spec_path = root / ".tlm" / "specs" / "product-catalog.md"
        spec_path.write_text(content)
        return ".tlm/specs/product-catalog.md"

    @patch("tlm.hooks.get_client")
    def test_bad_spec_blocks_implementation(self, mock_client, shop_project):
        """Spec with gaps blocks transition to implementation."""
        spec = self._write_shop_spec(shop_project, good=False)
        _set_state(shop_project, "tlm_active", "feature", spec)

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "block",
            "gaps": [
                {"severity": "blocker", "description": "No error handling specified"},
                {"severity": "blocker", "description": "No testing strategy"},
            ],
            "models_used": ["gemini-2.5-pro", "claude-sonnet"],
        }
        mock_client.return_value = client

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        # This hits the gap check first (no-test-framework), but let's dismiss that
        # to isolate the spec review gate
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") == "block"
        assert "error handling" in result["reason"].lower() or "spec review" in result["reason"].lower()

    @patch("tlm.hooks.get_client")
    def test_good_spec_allows_implementation(self, mock_client, shop_project):
        """Good spec passes review → implementation allowed."""
        spec = self._write_shop_spec(shop_project, good=True)
        _set_state(shop_project, "tlm_active", "feature", spec)

        # Dismiss prerequisite gap for this test
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "pass",
            "gaps": [],
        }
        mock_client.return_value = client

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") != "block"

        state = read_state(str(shop_project))
        assert state["spec_review_status"] == "approved"

    @patch("tlm.hooks.get_client")
    def test_warnings_pass_at_standard(self, mock_client, shop_project):
        """Standard quality: warnings don't block, but surface context."""
        spec = self._write_shop_spec(shop_project, good=True)
        _set_state(shop_project, "tlm_active", "feature", spec)

        # Dismiss prerequisite gap
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "warn",
            "gaps": [{"severity": "warning", "description": "Consider pagination limits"}],
        }
        mock_client.return_value = client

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") != "block"
        assert "additionalContext" in result
        assert "pagination" in result["additionalContext"].lower()

    @patch("tlm.hooks.get_client")
    def test_warnings_block_at_high(self, mock_client, shop_project):
        """High quality: even warnings block."""
        _set_quality(shop_project, "high")
        spec = self._write_shop_spec(shop_project, good=True)
        _set_state(shop_project, "tlm_active", "feature", spec)

        # Dismiss prerequisite gap
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "warn",
            "gaps": [{"severity": "warning", "description": "Image upload size unclear"}],
        }
        mock_client.return_value = client

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") == "block"

    @patch("tlm.hooks.get_client", return_value=None)
    def test_server_down_auto_approves(self, mock_client, shop_project):
        """No server → spec auto-approved."""
        spec = self._write_shop_spec(shop_project, good=True)
        _set_state(shop_project, "tlm_active", "feature", spec)

        # Dismiss prerequisite gap
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert result.get("decision") != "block"

        state = read_state(str(shop_project))
        assert state["spec_review_status"] == "approved"


# ═══════════════════════════════════════════════════════════════════
# PHASE 4: TDD ENFORCEMENT
# ═══════════════════════════════════════════════════════════════════


class TestTDD:
    """TDD enforcement during implementation phase."""

    def test_source_blocked_without_tests(self, shop_project):
        """Source write blocked when no tests written this session."""
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="approved")
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products/views.py"},
        })
        assert result.get("decision") == "block"
        assert "test first" in result["reason"].lower()

    def test_test_write_allowed_and_tracked(self, shop_project):
        """Test file write allowed and tracked during implementation."""
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="approved")

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_products.py"},
        })
        assert result == {}

        # Verify tracking
        tracking_file = shop_project / ".tlm" / "cache" / "session_tests.json"
        assert tracking_file.exists()
        data = json.loads(tracking_file.read_text())
        assert "/app/tests/test_products.py" in data["test_files_written"]

    def test_source_allowed_after_matching_test(self, shop_project):
        """Source write allowed after matching test is written."""
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="approved")

        # First write a test
        hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_products.py"},
        })

        # Now source write should be allowed
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert result is None or result == {} or "decision" not in result

    def test_unmatched_source_warned(self, shop_project):
        """Source write for unmatched module gets TDD warning."""
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="approved")

        # Write test for products
        hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_products.py"},
        })

        # Source write for DIFFERENT module → warning
        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/payments/stripe_handler.py"},
        })
        assert "additionalContext" in result
        assert "stripe_handler" in result["additionalContext"].lower()

    def test_rejected_spec_blocks_source(self, shop_project):
        """Source write blocked when spec review status is rejected."""
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="rejected")
        state = read_state(str(shop_project))
        state["spec_review_gaps"] = ["Missing error handling"]
        write_state(str(shop_project), state)

        # Track a test so TDD check passes
        from tlm.hooks import _track_test_write
        _track_test_write(str(shop_project), "/app/tests/test_products.py")

        result = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert result.get("decision") == "block"
        assert "rejected" in result["reason"].lower()


# ═══════════════════════════════════════════════════════════════════
# PHASE 5: COMPLIANCE
# ═══════════════════════════════════════════════════════════════════


class TestCompliance:
    """Compliance gate before git commit."""

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._get_staged_diff", return_value="diff content")
    @patch("tlm.hooks._get_changed_files", return_value=["app/products.py"])
    def test_standard_with_warnings_warns(self, mock_files, mock_diff, mock_client,
                                          mock_mech, shop_project):
        """Standard quality: code review warnings don't block commit."""
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "warn",
            "models_used": ["gemini-2.5-pro"],
            "reviews": [{"issues": [
                {"severity": "warning", "description": "N+1 query on product list"}
            ]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(shop_project), {
            "command": "git commit -m 'feat: add product catalog'"
        })
        assert "additionalContext" in result
        assert "decision" not in result

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client")
    @patch("tlm.hooks._get_staged_diff", return_value="diff content")
    @patch("tlm.hooks._get_changed_files", return_value=["app/products.py"])
    def test_high_with_block_verdict_blocks(self, mock_files, mock_diff, mock_client,
                                             mock_mech, shop_project):
        """High quality: block verdict blocks commit."""
        _set_quality(shop_project, "high")
        client = MagicMock()
        client.review_code.return_value = {
            "combined_verdict": "block",
            "models_used": ["gemini-2.5-pro", "claude-sonnet"],
            "reviews": [{"issues": [
                {"severity": "error", "description": "SQL injection in product search"}
            ]}],
        }
        mock_client.return_value = client

        result = hook_compliance_gate(str(shop_project), {
            "command": "git commit -m 'feat: add search'"
        })
        assert result.get("decision") == "block"
        assert "sql injection" in result["reason"].lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=["tests: 3 tests failed"])
    def test_mechanical_failure_blocks(self, mock_mech, shop_project):
        """Mechanical check failures block commit."""
        result = hook_compliance_gate(str(shop_project), {
            "command": "git commit -m 'feat: product images'"
        })
        assert result.get("decision") == "block"
        assert "mechanical" in result["reason"].lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_relaxed_skips_server_review(self, mock_mech, shop_project):
        """Relaxed quality: no server review, just context injection."""
        _set_quality(shop_project, "relaxed")
        result = hook_compliance_gate(str(shop_project), {
            "command": "git commit -m 'chore: update styles'"
        })
        assert "additionalContext" in result
        assert "decision" not in result


# ═══════════════════════════════════════════════════════════════════
# PHASE 6: LEARNING
# ═══════════════════════════════════════════════════════════════════


class TestLearning:
    """Session learning: prompt capture → stop → server → rules in DB."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_prompts_captured(self, mock_sync, mock_client, shop_project):
        """Prompts captured during session."""
        hook_prompt_submit(str(shop_project), prompt_text="Add product categories")
        hook_prompt_submit(str(shop_project), prompt_text="Yes, with images and Stripe")

        prompts_file = shop_project / ".tlm" / "session_prompts.jsonl"
        assert prompts_file.exists()
        lines = prompts_file.read_text().strip().split("\n")
        assert len(lines) == 2
        assert "product categories" in json.loads(lines[0])["prompt"]

    @patch("tlm.hooks.get_client")
    def test_stop_sends_to_server(self, mock_client, shop_project):
        """Stop hook sends session summary to server."""
        # Write prompts
        prompts_file = shop_project / ".tlm" / "session_prompts.jsonl"
        for prompt in ["Add product catalog", "Use categories", "Add image upload"]:
            entry = json.dumps({"timestamp": "2026-02-18T10:00:00", "prompt": prompt})
            with open(prompts_file, "a") as f:
                f.write(entry + "\n")

        client = MagicMock()
        client.learn_session.return_value = {
            "inferred_rules": [
                {"rule_text": "Products always need image support", "tags": ["products"]},
            ],
            "workflow_patterns": [],
        }
        mock_client.return_value = client

        result = hook_stop(str(shop_project))
        assert "additionalContext" in result
        assert "1 new pattern" in result["additionalContext"]

    @patch("tlm.hooks.get_client")
    def test_rules_written_to_db(self, mock_client, shop_project):
        """Learned rules written to knowledge.db."""
        prompts_file = shop_project / ".tlm" / "session_prompts.jsonl"
        entry = json.dumps({"timestamp": "2026-02-18T10:00:00", "prompt": "test"})
        prompts_file.write_text(entry + "\n")

        client = MagicMock()
        client.learn_session.return_value = {
            "inferred_rules": [
                {"rule_text": "Always validate image dimensions", "tags": ["validation"]},
                {"rule_text": "Use Stripe webhook for payment events", "tags": ["payments"]},
            ],
        }
        mock_client.return_value = client

        hook_stop(str(shop_project))

        db = KnowledgeDB(str(shop_project / ".tlm"))
        db.init_db()
        rules = db.list_rules()
        db.close()

        rule_texts = [r["rule_text"] for r in rules]
        assert "Always validate image dimensions" in rule_texts
        assert "Use Stripe webhook for payment events" in rule_texts

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_next_session_includes_learned_rules(self, mock_sync, mock_client,
                                                  shop_project):
        """Rules learned in previous session appear in next session_start."""
        db = KnowledgeDB(str(shop_project / ".tlm"))
        db.init_db()
        db.add_rule("Products always need image support", source="learned_from_session")
        db.close()

        result = hook_session_start(str(shop_project))
        assert "image support" in result.lower()


# ═══════════════════════════════════════════════════════════════════
# FULL CHAIN TESTS
# ═══════════════════════════════════════════════════════════════════


class TestFullChain:
    """End-to-end chain tests simulating realistic multi-hook flows."""

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    def test_full_happy_path(self, mock_mech, mock_sync, mock_client, shop_project):
        """Full flow: session → interview → implementation → commit.

        This test simulates the happy path with gaps dismissed and no server.
        """
        # Dismiss prerequisite gap
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        # 1. Session start
        ctx = hook_session_start(str(shop_project))
        assert "TLM" in ctx

        # 2. Interview phase — source blocked
        _set_state(shop_project, "tlm_active", "feature")
        guard = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert guard.get("decision") == "block"

        # 3. Spec saved → transition to implementation (auto-approved since no server)
        spec_path = shop_project / ".tlm" / "specs" / "products.md"
        spec_path.write_text("# Products\nCatalog feature.")
        _set_state(shop_project, "tlm_active", "feature",
                   active_spec=".tlm/specs/products.md")

        transition = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "state.json"),
                "content": json.dumps({"phase": "implementation"}),
            },
        })
        assert transition.get("decision") != "block"

        # 4. Implementation — write test first (spec was auto-approved in step 3)
        _set_state(shop_project, "implementation", "feature",
                   spec_review_status="approved")
        test_guard = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/tests/test_products.py"},
        })
        assert test_guard == {}

        # 5. Now source code allowed
        src_guard = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        # Should either be empty or additionalContext (no block)
        assert src_guard.get("decision") != "block"

        # 6. Commit — relaxed compliance (no server)
        _set_quality(shop_project, "relaxed")
        commit = hook_compliance_gate(str(shop_project), {
            "command": "git commit -m 'feat: add products'"
        })
        assert commit.get("decision") != "block"

    @patch("tlm.hooks.get_client", return_value=None)
    @patch("tlm.hooks._try_server_sync", return_value=None)
    def test_interview_to_implementation_with_spec(self, mock_sync, mock_client,
                                                     shop_project):
        """Interview → write spec → transition to implementation."""
        # Dismiss prerequisite gap
        gaps_file = shop_project / ".tlm" / "gaps.json"
        gaps = json.loads(gaps_file.read_text())
        for g in gaps["gaps"]:
            if g["id"] == "no-test-framework":
                g["dismissed"] = True
        gaps_file.write_text(json.dumps(gaps))

        _set_state(shop_project, "tlm_active", "feature")

        # Write spec (allowed during interview)
        spec_guard = hook_guard(str(shop_project), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(shop_project / ".tlm" / "specs" / "shop-spec.md"),
            },
        })
        assert spec_guard.get("decision") != "block"

        # Verify spec review status set to pending
        state = read_state(str(shop_project))
        assert state["spec_review_status"] == "pending"
