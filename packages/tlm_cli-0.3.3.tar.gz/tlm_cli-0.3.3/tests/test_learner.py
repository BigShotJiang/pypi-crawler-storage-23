"""
Tests for TLM Learner — git analysis, commit classification, synthesis, knowledge update.

Uses a real temp git repo for GitReader tests.
Mocks api_client for all server-dependent tests.
"""

import json
import os
import subprocess
import datetime
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from tlm.learner import GitReader, CommitAnalyzer, LearningSynthesizer, KnowledgeUpdater, Learner
from tlm.engine import Project


# ─── Fixtures ─────────────────────────────────────────────────

@pytest.fixture
def tmp_git_repo(tmp_path):
    """Create a temporary git repo with a few commits."""
    repo = tmp_path / "repo"
    repo.mkdir()

    def run_git(*args):
        subprocess.run(
            ["git"] + list(args),
            cwd=str(repo), capture_output=True, text=True,
            env={**os.environ, "GIT_AUTHOR_NAME": "Test", "GIT_AUTHOR_EMAIL": "test@test.com",
                 "GIT_COMMITTER_NAME": "Test", "GIT_COMMITTER_EMAIL": "test@test.com"},
        )

    run_git("init")
    run_git("config", "user.name", "Test")
    run_git("config", "user.email", "test@test.com")

    # Commit 1: initial
    (repo / "main.py").write_text("print('hello')\n")
    run_git("add", ".")
    run_git("commit", "-m", "Initial commit")

    # Commit 2: feature
    (repo / "feature.py").write_text("def greet(name):\n    return f'Hi {name}'\n")
    run_git("add", ".")
    run_git("commit", "-m", "Add greeting feature")

    # Commit 3: bug fix
    (repo / "main.py").write_text("print('hello world')\n")
    run_git("add", ".")
    run_git("commit", "-m", "Fix: correct greeting output")

    return repo


@pytest.fixture
def project_with_tlm(tmp_path):
    """Create a project with .tlm/ directory initialized."""
    repo = tmp_path / "proj"
    repo.mkdir()
    project = Project(str(repo))
    project.init()
    return project


@pytest.fixture
def mock_api():
    """Create a mock API client for server-backed tests."""
    api = MagicMock()
    return api


PROJECT_ID = "test-project-123"

SAMPLE_COMMIT_ANALYSIS_DICT = {
    "hash": "abc1234",
    "category": "bug_fix",
    "planned": False,
    "matching_spec": None,
    "summary": "Fixed null pointer in payment handler",
    "unplanned_reason": "Spec didn't cover null user case",
    "lessons": [
        {
            "type": "missed_edge_case",
            "insight": "Payment handler didn't account for null user",
            "interview_question": "What happens when a payment is attempted with no logged-in user?",
        }
    ],
}

SAMPLE_COMMIT_ANALYSIS_PLANNED_DICT = {
    "hash": "def5678",
    "category": "feature_work",
    "planned": True,
    "matching_spec": "2026-02-15-add-payments.md",
    "summary": "Implemented Stripe payment integration",
    "unplanned_reason": None,
    "lessons": [],
}

SAMPLE_SYNTHESIS_DICT = {
    "period": "2026-02-01 to 2026-02-15",
    "total_commits": 3,
    "planned_commits": 1,
    "unplanned_commits": 2,
    "spec_accuracy_percent": 33,
    "bug_patterns": [
        {
            "pattern": "Input validation gaps",
            "evidence": ["commit abc: Fixed null pointer"],
            "frequency": 2,
            "severity": "medium",
            "lesson": "Team consistently misses null/empty validation",
            "interview_questions": ["For each input field: what are the exact validation rules?"],
        }
    ],
    "unplanned_features": [
        {
            "what": "Rate limiting on public API",
            "commits": ["ghi9012"],
            "lesson": "Public endpoints always need rate limiting",
            "interview_questions": ["Does this feature expose any public endpoints that need rate limiting?"],
        }
    ],
    "architecture_evolutions": [],
    "testing_gaps": [],
    "operational_lessons": [],
    "interview_improvements": [
        "For each input field: what are the exact validation rules?",
        "Does this feature expose any public endpoints that need rate limiting?",
    ],
}

# Keep JSON strings for backward compat with KnowledgeUpdater tests
SAMPLE_COMMIT_ANALYSIS = json.dumps(SAMPLE_COMMIT_ANALYSIS_DICT)
SAMPLE_SYNTHESIS = json.dumps(SAMPLE_SYNTHESIS_DICT)


# ─── GitReader Tests ──────────────────────────────────────────

class TestGitReader:
    def test_get_all_commits(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        commits = reader.get_all_commits()
        assert len(commits) == 3
        assert commits[0]["message"] == "Initial commit"
        assert commits[2]["message"] == "Fix: correct greeting output"

    def test_get_all_commits_have_diffs(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        commits = reader.get_all_commits()
        for c in commits:
            assert "diff" in c
            assert len(c["diff"]) > 0

    def test_get_last_commit(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        commit = reader.get_last_commit()
        assert commit is not None
        assert commit["message"] == "Fix: correct greeting output"
        assert "diff" in commit

    def test_get_commits_since(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        # Get all commits — use a date far in the past
        commits = reader.get_commits_since("2020-01-01T00:00:00")
        assert len(commits) == 3

    def test_get_commit_count_since(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        count = reader.get_commit_count_since("2020-01-01T00:00:00")
        assert count == 3

    def test_empty_repo(self, tmp_path):
        repo = tmp_path / "empty"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        reader = GitReader(str(repo))
        commits = reader.get_all_commits()
        assert commits == []

    def test_get_last_commit_empty_repo(self, tmp_path):
        repo = tmp_path / "empty"
        repo.mkdir()
        subprocess.run(["git", "init"], cwd=str(repo), capture_output=True)
        reader = GitReader(str(repo))
        assert reader.get_last_commit() is None

    def test_non_git_directory(self, tmp_path):
        reader = GitReader(str(tmp_path))
        commits = reader.get_all_commits()
        assert commits == []

    def test_commit_count_no_matches(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        # Far future date — no commits after this
        count = reader.get_commit_count_since("2099-01-01T00:00:00")
        assert count == 0

    def test_commit_fields(self, tmp_git_repo):
        reader = GitReader(str(tmp_git_repo))
        commit = reader.get_last_commit()
        assert "hash" in commit
        assert "message" in commit
        assert "author" in commit
        assert "date" in commit
        assert "diff" in commit
        assert len(commit["hash"]) == 40  # Full SHA


# ─── CommitAnalyzer Tests ────────────────────────────────────

class TestCommitAnalyzer:
    def test_analyze_commit(self, project_with_tlm, mock_api):
        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        commit = {
            "hash": "abc1234" * 5 + "abcdef12",
            "message": "Fix null pointer",
            "author": "dev",
            "date": "2026-02-15T10:00:00",
            "diff": "--- a/payment.py\n+++ b/payment.py\n- if user:\n+ if user is not None:",
        }
        result = analyzer.analyze_commit(commit)

        assert result["category"] == "bug_fix"
        assert result["planned"] is False
        assert len(result["lessons"]) == 1
        mock_api.analyze_commit.assert_called_once_with(PROJECT_ID, commit)

    def test_analyze_commit_planned(self, project_with_tlm, mock_api):
        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_PLANNED_DICT}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        commit = {
            "hash": "def5678" * 5 + "abcdef12",
            "message": "Add Stripe integration",
            "author": "dev",
            "date": "2026-02-15T10:00:00",
            "diff": "diff content",
        }
        result = analyzer.analyze_commit(commit)

        assert result["planned"] is True
        assert result["matching_spec"] == "2026-02-15-add-payments.md"

    def test_analyze_commit_requires_api_client(self, project_with_tlm):
        """Without api_client, CommitAnalyzer raises RuntimeError."""
        analyzer = CommitAnalyzer(project_with_tlm)

        commit = {
            "hash": "bad1234" * 5 + "abcdef12",
            "message": "Some commit",
            "author": "dev",
            "date": "2026-02-15T10:00:00",
            "diff": "diff content",
        }
        with pytest.raises(RuntimeError, match="requires api_client"):
            analyzer.analyze_commit(commit)

    def test_analyze_commit_unknown_category(self, project_with_tlm, mock_api):
        """Server returns analysis with unknown category."""
        unknown_analysis = {
            "hash": "abc1234",
            "category": "unknown",
            "planned": False,
            "matching_spec": None,
            "summary": "Could not classify",
            "unplanned_reason": "Ambiguous commit",
            "lessons": [],
        }
        mock_api.analyze_commit.return_value = {"analysis": unknown_analysis}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        commit = {
            "hash": "abc1234" * 5 + "abcdef12",
            "message": "Fix something",
            "author": "dev",
            "date": "2026-02-15T10:00:00",
            "diff": "diff content",
        }
        result = analyzer.analyze_commit(commit)
        assert result["category"] == "unknown"
        assert result["lessons"] == []

    def test_analyze_batch_with_progress(self, project_with_tlm, mock_api):
        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}
        analyzer = CommitAnalyzer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        commits = [
            {"hash": f"hash{i}" * 5 + "abcdef12", "message": f"Commit {i}",
             "author": "dev", "date": "2026-02-15T10:00:00", "diff": "diff"}
            for i in range(3)
        ]

        progress_calls = []
        def progress(current, total, hash_str, summary):
            progress_calls.append((current, total))

        results = analyzer.analyze_batch(commits, progress_callback=progress)
        assert len(results) == 3
        assert progress_calls == [(1, 3), (2, 3), (3, 3)]


# ─── LearningSynthesizer Tests ────────────────────────────────

class TestLearningSynthesizer:
    def test_synthesize(self, project_with_tlm, mock_api):
        mock_api.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS_DICT}
        synthesizer = LearningSynthesizer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        analyzed = [
            {"hash": "a", "planned": True, "date": "2026-02-01"},
            {"hash": "b", "planned": False, "date": "2026-02-10"},
            {"hash": "c", "planned": False, "date": "2026-02-15"},
        ]
        result = synthesizer.synthesize(analyzed)

        assert result["total_commits"] == 3
        assert result["spec_accuracy_percent"] == 33
        assert len(result["bug_patterns"]) == 1
        assert len(result["interview_improvements"]) == 2
        mock_api.synthesize.assert_called_once_with(PROJECT_ID, analyzed)

    def test_synthesize_requires_api_client(self, project_with_tlm):
        """Without api_client, LearningSynthesizer raises RuntimeError."""
        synthesizer = LearningSynthesizer(project_with_tlm)
        with pytest.raises(RuntimeError, match="requires api_client"):
            synthesizer.synthesize([{"hash": "a", "planned": True}])

    def test_synthesize_all_planned(self, project_with_tlm, mock_api):
        synthesis_100 = {
            "period": "2026-02-01 to 2026-02-15",
            "total_commits": 2, "planned_commits": 2, "unplanned_commits": 0,
            "spec_accuracy_percent": 100,
            "bug_patterns": [], "unplanned_features": [],
            "architecture_evolutions": [], "testing_gaps": [],
            "operational_lessons": [], "interview_improvements": [],
        }
        mock_api.synthesize.return_value = {"synthesis": synthesis_100}
        synthesizer = LearningSynthesizer(project_with_tlm, api_client=mock_api, project_id=PROJECT_ID)

        analyzed = [
            {"hash": "a", "planned": True, "date": "2026-02-01"},
            {"hash": "b", "planned": True, "date": "2026-02-15"},
        ]
        result = synthesizer.synthesize(analyzed)
        assert result["spec_accuracy_percent"] == 100


# ─── KnowledgeUpdater Tests ──────────────────────────────────

class TestKnowledgeUpdater:
    def test_update_from_synthesis(self, project_with_tlm):
        updater = KnowledgeUpdater(project_with_tlm)
        synthesis = json.loads(SAMPLE_SYNTHESIS)

        updater.update_from_synthesis(synthesis)

        # Check knowledge.md was updated
        knowledge = project_with_tlm.get_knowledge()
        assert "Input validation gaps" in knowledge
        assert "Rate limiting on public API" in knowledge

        # Check config.json was updated
        config = project_with_tlm.get_config()
        assert config["total_commits_analyzed"] == 3
        assert len(config["spec_accuracy_history"]) == 1
        assert config["spec_accuracy_history"][0]["accuracy"] == 33
        assert "last_learning_at" in config

        # Check synthesis file was saved
        lessons_dir = project_with_tlm.tlm_dir / "lessons"
        synthesis_files = list(lessons_dir.glob("*-synthesis.json"))
        assert len(synthesis_files) == 1

    def test_update_accumulates(self, project_with_tlm):
        """Multiple updates should accumulate, not overwrite."""
        updater = KnowledgeUpdater(project_with_tlm)
        synthesis = json.loads(SAMPLE_SYNTHESIS)

        updater.update_from_synthesis(synthesis)
        updater.update_from_synthesis(synthesis)

        config = project_with_tlm.get_config()
        assert config["total_commits_analyzed"] == 6
        assert len(config["spec_accuracy_history"]) == 2

    def test_get_project_lessons_no_data(self, project_with_tlm):
        updater = KnowledgeUpdater(project_with_tlm)
        result = updater.get_project_lessons()
        assert "No commit history analyzed" in result

    def test_get_project_lessons_with_data(self, project_with_tlm):
        updater = KnowledgeUpdater(project_with_tlm)
        synthesis = json.loads(SAMPLE_SYNTHESIS)
        updater.update_from_synthesis(synthesis)

        result = updater.get_project_lessons()
        assert "33%" in result
        assert "MUST ASK" in result
        assert "validation rules" in result
        assert "not suggestions" in result.lower()


# ─── Learner (Orchestrator) Tests ─────────────────────────────

class TestLearner:
    def test_learn_full_history(self, tmp_git_repo, mock_api):
        """Full pipeline: git repo → analyze → synthesize → update knowledge."""
        project = Project(str(tmp_git_repo))
        project.init()

        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}
        mock_api.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS_DICT}

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        result = learner.learn_full_history()

        assert result["total_commits"] == 3
        assert mock_api.analyze_commit.call_count == 3
        assert mock_api.synthesize.call_count == 1

        # Verify knowledge was updated
        knowledge = project.get_knowledge()
        assert "Input validation" in knowledge

    def test_learn_since_last_session_no_session(self, tmp_git_repo, mock_api):
        """No previous session — nothing to learn from."""
        project = Project(str(tmp_git_repo))
        project.init()

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        result = learner.learn_since_last_session()

        assert result["total_commits"] == 0
        assert mock_api.analyze_commit.call_count == 0

    def test_learn_since_last_session_with_commits(self, tmp_git_repo, mock_api):
        """Has previous session and new commits since then."""
        project = Project(str(tmp_git_repo))
        project.init()

        # Set last_session_at to the past
        config = project.get_config()
        config["last_session_at"] = "2020-01-01T00:00:00"
        project.config_file.write_text(json.dumps(config, indent=2))

        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}
        mock_api.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS_DICT}

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        result = learner.learn_since_last_session()

        assert result["total_commits"] == 3

    def test_learn_last_commit(self, tmp_git_repo, mock_api):
        """Post-commit hook: analyze single commit and save to .tlm/commits/."""
        project = Project(str(tmp_git_repo))
        project.init()

        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        result = learner.learn_last_commit()

        assert result["category"] == "bug_fix"

        # Verify saved to commits dir
        commits_dir = project.tlm_dir / "commits"
        commit_files = list(commits_dir.glob("*.json"))
        assert len(commit_files) == 1

    def test_learn_uses_preanalyzed_commits(self, tmp_git_repo, mock_api):
        """If post-commit hook already analyzed commits, use those instead of re-analyzing."""
        project = Project(str(tmp_git_repo))
        project.init()

        # Set last session
        config = project.get_config()
        config["last_session_at"] = "2020-01-01T00:00:00"
        project.config_file.write_text(json.dumps(config, indent=2))

        # Simulate hook having already analyzed commits
        commits_dir = project.tlm_dir / "commits"
        commits_dir.mkdir(exist_ok=True)
        for i in range(2):
            analysis = SAMPLE_COMMIT_ANALYSIS_DICT.copy()
            analysis["hash"] = f"preanalyzed{i}"
            (commits_dir / f"preanalyzed{i}.json").write_text(json.dumps(analysis))

        # Mock only expects synthesis call (not per-commit analysis)
        mock_api.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS_DICT}

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        result = learner.learn_since_last_session()

        # Should have called synthesize once, not analyze_commit per-commit
        assert mock_api.analyze_commit.call_count == 0
        assert mock_api.synthesize.call_count == 1
        assert result["total_commits"] == 3

        # Verify commits were marked as processed
        unprocessed = list(commits_dir.glob("*.json"))
        processed = [f for f in unprocessed if f.name.endswith("-processed.json")]
        assert len(processed) == 2

    def test_get_commit_count_since_last_session(self, tmp_git_repo, mock_api):
        project = Project(str(tmp_git_repo))
        project.init()

        config = project.get_config()
        config["last_session_at"] = "2020-01-01T00:00:00"
        project.config_file.write_text(json.dumps(config, indent=2))

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        count = learner.get_commit_count_since_last_session()
        assert count == 3

    def test_get_commit_count_no_session(self, tmp_git_repo, mock_api):
        project = Project(str(tmp_git_repo))
        project.init()

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        count = learner.get_commit_count_since_last_session()
        assert count == 0

    def test_progress_callback(self, tmp_git_repo, mock_api):
        """Verify progress callback is called during analysis."""
        project = Project(str(tmp_git_repo))
        project.init()

        config = project.get_config()
        config["last_session_at"] = "2020-01-01T00:00:00"
        project.config_file.write_text(json.dumps(config, indent=2))

        mock_api.analyze_commit.return_value = {"analysis": SAMPLE_COMMIT_ANALYSIS_DICT}
        mock_api.synthesize.return_value = {"synthesis": SAMPLE_SYNTHESIS_DICT}

        progress_calls = []
        def progress(current, total, hash_str, summary):
            progress_calls.append(current)

        learner = Learner(project, api_client=mock_api, project_id=PROJECT_ID)
        learner.learn_since_last_session(progress_callback=progress)

        assert progress_calls == [1, 2, 3]
