"""
Tests for TLM Hook Handlers — session_start, prompt_submit, guard, compliance_gate.

Hooks read state files and return JSON for Claude Code.
Tests simulate stdin/stdout as Claude Code would provide.
"""

import json
import datetime
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.hooks import hook_session_start, hook_prompt_submit, hook_guard, hook_compliance_gate
from tlm.state import write_state, transition_phase, set_spec_review_status


@pytest.fixture
def project_root(tmp_path):
    """Create a project with .tlm/ directory and basic files."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    specs_dir = tlm_dir / "specs"
    specs_dir.mkdir()
    lessons_dir = tlm_dir / "lessons"
    lessons_dir.mkdir()

    # Knowledge file
    (tlm_dir / "knowledge.md").write_text("# Knowledge\n- Uses PostgreSQL\n- Has REST API\n")

    # Config
    (tlm_dir / "config.json").write_text(json.dumps({
        "project_name": "test-project",
        "sessions_used": 3,
        "last_session_at": "2026-02-14T10:00:00",
    }))

    # State
    write_state(tmp_path, {
        "phase": "idle",
        "activity_type": None,
        "active_spec": None,
        "last_updated": "2026-02-15T10:00:00",
    })

    return tmp_path


@pytest.fixture
def project_with_spec(project_root):
    """Project with an active spec."""
    spec_path = project_root / ".tlm" / "specs" / "2026-02-15-payments.md"
    spec_path.write_text("# Payment Feature Spec\n\n## Requirements\n- Stripe integration\n")

    transition_phase(project_root, "implementation", context={
        "activity_type": "feature_request",
        "active_spec": ".tlm/specs/2026-02-15-payments.md",
    })

    return project_root


@pytest.fixture
def project_with_lessons(project_root):
    """Project with learning synthesis."""
    synthesis = {
        "total_commits": 10,
        "spec_accuracy_percent": 70,
        "interview_improvements": [
            "Ask about null handling for every input field",
            "Ask about rate limiting for public endpoints",
        ],
        "bug_patterns": [{"pattern": "null checks", "frequency": 3}],
    }
    (project_root / ".tlm" / "lessons" / "2026-02-14-synthesis.json").write_text(
        json.dumps(synthesis)
    )
    return project_root


# ─── SessionStart Hook Tests ──────────────────────────────────

class TestSessionStartHook:
    def test_returns_context_string(self, project_root):
        result = hook_session_start(str(project_root))
        assert isinstance(result, str)
        assert "TLM" in result

    def test_includes_state(self, project_root):
        result = hook_session_start(str(project_root))
        assert "idle" in result

    def test_includes_knowledge_summary(self, project_root):
        result = hook_session_start(str(project_root))
        assert "PostgreSQL" in result or "knowledge" in result.lower()

    def test_includes_active_spec_when_set(self, project_with_spec):
        result = hook_session_start(str(project_with_spec))
        assert "payments" in result.lower() or "spec" in result.lower()

    def test_includes_lessons_when_available(self, project_with_lessons):
        result = hook_session_start(str(project_with_lessons))
        assert "null handling" in result.lower() or "lesson" in result.lower()

    def test_handles_missing_tlm_dir(self, tmp_path):
        result = hook_session_start(str(tmp_path))
        assert "not initialized" in result.lower() or "no .tlm" in result.lower()

    def test_includes_commit_count_info(self, project_root):
        """Should mention commit learning status."""
        result = hook_session_start(str(project_root))
        # Should at least mention the project
        assert len(result) > 0


# ─── PromptSubmit Hook Tests ─────────────────────────────────

class TestPromptSubmitHook:
    def test_returns_additional_context(self, project_root):
        result = hook_prompt_submit(str(project_root))
        assert isinstance(result, dict)
        assert "additionalContext" in result

    def test_includes_phase_reminder(self, project_root):
        result = hook_prompt_submit(str(project_root))
        context = result["additionalContext"]
        assert "TLM" in context

    def test_idle_phase_reminds_classification(self, project_root):
        result = hook_prompt_submit(str(project_root))
        context = result["additionalContext"]
        assert "classify" in context.lower() or "significant" in context.lower()

    def test_active_phase_reminds_interview(self, project_root):
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        result = hook_prompt_submit(str(project_root))
        context = result["additionalContext"]
        assert "interview" in context.lower() or "question" in context.lower()

    def test_implementation_phase_reminds_tdd(self, project_root):
        transition_phase(project_root, "implementation")
        result = hook_prompt_submit(str(project_root))
        context = result["additionalContext"]
        assert "test" in context.lower() or "TDD" in context

    def test_handles_missing_state(self, tmp_path):
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        result = hook_prompt_submit(str(tmp_path))
        assert isinstance(result, dict)


# ─── Guard Hook Tests (PreToolUse) ───────────────────────────

class TestGuardHook:
    def test_pass_through_for_read_tools(self, project_root):
        tool_input = {"tool_name": "Read", "tool_input": {"file_path": "/some/file.py"}}
        result = hook_guard(str(project_root), tool_input)
        assert result is None or result == {}

    def test_pass_through_in_idle(self, project_root):
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "src/app.py"}}
        result = hook_guard(str(project_root), tool_input)
        assert result is None or result == {}

    def test_tdd_reminder_during_implementation(self, project_root):
        transition_phase(project_root, "implementation")
        set_spec_review_status(str(project_root), "approved")
        # Pre-populate session test tracking with a non-matching test file so the
        # hook reaches the "warn" path instead of the "no tests written" block path.
        cache_dir = project_root / ".tlm" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "session_tests.json").write_text(
            json.dumps({"test_files_written": ["tests/test_other.py"], "session_start": "2026-02-18T00:00:00"})
        )
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "src/app.py"}}
        result = hook_guard(str(project_root), tool_input)
        # Should inject TDD reminder (warn), not block
        assert result is not None and result != {}
        assert "additionalContext" in result
        ctx = result["additionalContext"]
        assert "test" in ctx.lower()

    def test_no_tdd_reminder_for_test_files(self, project_root):
        transition_phase(project_root, "implementation")
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "tests/test_app.py"}}
        result = hook_guard(str(project_root), tool_input)
        # Should pass through — writing tests is the right thing
        assert result is None or result == {} or "additionalContext" not in result

    def test_interview_guard_during_tlm_active(self, project_root):
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "src/feature.py"}}
        result = hook_guard(str(project_root), tool_input)
        # Should BLOCK source code writes during interview
        assert result.get("decision") == "block"
        assert "interview" in result.get("reason", "").lower() or "discovery" in result.get("reason", "").lower()

    def test_edit_also_guarded(self, project_root):
        transition_phase(project_root, "implementation")
        set_spec_review_status(str(project_root), "approved")
        # Pre-populate session test tracking with a non-matching test file so the
        # hook reaches the "warn" path instead of the "no tests written" block path.
        cache_dir = project_root / ".tlm" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "session_tests.json").write_text(
            json.dumps({"test_files_written": ["tests/test_other.py"], "session_start": "2026-02-18T00:00:00"})
        )
        tool_input = {"tool_name": "Edit", "tool_input": {"file_path": "src/app.py"}}
        result = hook_guard(str(project_root), tool_input)
        # Edit should be treated same as Write for TDD — warn, not block
        assert result is not None and result != {}
        assert "additionalContext" in result


# ─── Compliance Gate Hook Tests (PreToolUse on Bash git commit) ──

class TestComplianceGateHook:
    def test_pass_through_non_commit_commands(self, project_root):
        tool_input = {"command": "ls -la"}
        result = hook_compliance_gate(str(project_root), tool_input)
        assert result is None or result == {}

    def test_pass_through_git_non_commit(self, project_root):
        tool_input = {"command": "git status"}
        result = hook_compliance_gate(str(project_root), tool_input)
        assert result is None or result == {}

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client", return_value=None)
    def test_injects_compliance_reminder_on_git_commit(self, mock_client, mock_mech, project_with_spec):
        tool_input = {"command": "git commit -m 'add feature'"}
        result = hook_compliance_gate(str(project_with_spec), tool_input)
        # With standard quality and no server → falls back to context injection
        assert result is not None
        assert "additionalContext" in result
        ctx = result["additionalContext"]
        assert "spec" in ctx.lower() or "compliance" in ctx.lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client", return_value=None)
    def test_injects_on_git_commit_amend(self, mock_client, mock_mech, project_with_spec):
        tool_input = {"command": "git commit --amend -m 'fix'"}
        result = hook_compliance_gate(str(project_with_spec), tool_input)
        assert result is not None
        assert "additionalContext" in result

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client", return_value=None)
    def test_includes_spec_reference(self, mock_client, mock_mech, project_with_spec):
        tool_input = {"command": "git commit -m 'done'"}
        result = hook_compliance_gate(str(project_with_spec), tool_input)
        ctx = result["additionalContext"]
        assert "payments" in ctx.lower() or "spec" in ctx.lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client", return_value=None)
    def test_no_spec_still_reminds_checks(self, mock_client, mock_mech, project_root):
        tool_input = {"command": "git commit -m 'something'"}
        result = hook_compliance_gate(str(project_root), tool_input)
        # With standard quality and no server → falls back to context injection
        if result:
            assert "additionalContext" in result

    def test_pass_through_when_no_tlm(self, tmp_path):
        tool_input = {"command": "git commit -m 'init'"}
        result = hook_compliance_gate(str(tmp_path), tool_input)
        assert result is None or result == {}


# ─── Branding & Attribution Tests ────────────────────────────

class TestBrandingAttribution:
    """Verify each hook includes TLM branding/attribution instructions."""

    def test_idle_prompt_submit_has_activation_branding(self, project_root):
        """Idle hook should instruct Claude to say 'TLM >' when activating."""
        result = hook_prompt_submit(str(project_root))
        ctx = result["additionalContext"]
        assert "TLM >" in ctx
        assert "refine your requirements" in ctx.lower()

    def test_active_prompt_submit_has_completion_branding(self, project_root):
        """Active hook should instruct Claude to say 'TLM > Requirements captured.'"""
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        result = hook_prompt_submit(str(project_root))
        ctx = result["additionalContext"]
        assert "TLM > Requirements captured" in ctx

    def test_implementation_prompt_submit_has_tdd_branding(self, project_root):
        """Implementation hook should instruct Claude to say 'TLM > Tests first.'"""
        transition_phase(project_root, "implementation")
        result = hook_prompt_submit(str(project_root))
        ctx = result["additionalContext"]
        assert "TLM > Tests first" in ctx

    def test_guard_interview_block_has_branding(self, project_root):
        """Guard hook during interview should BLOCK with TLM branding."""
        transition_phase(project_root, "tlm_active", context={"activity_type": "feature_request"})
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "src/feature.py"}}
        result = hook_guard(str(project_root), tool_input)
        assert result.get("decision") == "block"
        assert "TLM >" in result.get("reason", "")

    def test_guard_tdd_reminder_has_branding(self, project_root):
        """Guard TDD reminder should have TLM branding."""
        transition_phase(project_root, "implementation")
        set_spec_review_status(str(project_root), "approved")
        # Pre-populate session test tracking with a non-matching test file so the
        # hook reaches the additionalContext "warn" path, which carries [TLM] branding.
        cache_dir = project_root / ".tlm" / "cache"
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / "session_tests.json").write_text(
            json.dumps({"test_files_written": ["tests/test_other.py"], "session_start": "2026-02-18T00:00:00"})
        )
        tool_input = {"tool_name": "Write", "tool_input": {"file_path": "src/app.py"}}
        result = hook_guard(str(project_root), tool_input)
        assert "additionalContext" in result, (
            "Expected additionalContext warn path — ensure test_files_written contains a non-matching test"
        )
        ctx = result["additionalContext"]
        assert "[TLM]" in ctx
        assert "tdd" in ctx.lower()

    @patch("tlm.hooks._run_mechanical_checks", return_value=[])
    @patch("tlm.hooks.get_client", return_value=None)
    def test_compliance_gate_has_branding(self, mock_client, mock_mech, project_with_spec):
        """Compliance gate should include TLM branding."""
        tool_input = {"command": "git commit -m 'done'"}
        result = hook_compliance_gate(str(project_with_spec), tool_input)
        ctx = result["additionalContext"]
        assert "[TLM]" in ctx or "TLM >" in ctx

    def test_session_start_has_knowledge_attribution(self, project_root):
        """Session start should instruct attribution via 'Based on TLM\\'s analysis'."""
        result = hook_session_start(str(project_root))
        assert "Based on TLM's analysis" in result
