"""Tests for v3 enforcement features — interview guidance, spec review gate,
TDD compliance, prerequisite gap enforcement, quality-gated blocking.

Tests the decision logic of each new enforcement function with:
  - Pure logic tests (no I/O, no mocks)
  - File-system tests (tmp_path fixture)
  - Server-mocked tests (MagicMock for api_client)
"""

import json
import datetime
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from tlm.hooks import (
    _should_block_for_quality,
    _format_interview_guide,
    _check_tdd_compliance,
    _track_test_write,
    _check_prerequisite_gaps,
    _spec_review_gate,
    _get_interview_guidance,
    _minimal_interview_fallback,
    hook_guard,
)
from tlm.engine import is_prerequisite_gap
from tlm.state import set_spec_review_status, read_state


# ─── Fixtures ──────────────────────────────────────────────────────


@pytest.fixture
def project_dir(tmp_path):
    """Create a minimal TLM project directory."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "cache").mkdir()
    (tlm_dir / "specs").mkdir()

    config = {
        "project_name": "test-project",
        "quality_control": "standard",
        "session_learning": True,
    }
    (tlm_dir / "config.json").write_text(json.dumps(config))

    state = {
        "phase": "idle",
        "activity_type": None,
        "active_spec": None,
        "spec_review_status": "none",
        "spec_review_gaps": [],
    }
    (tlm_dir / "state.json").write_text(json.dumps(state))

    return tmp_path


def _set_state(project_dir, phase, activity_type=None, active_spec=None,
               spec_review_status="none"):
    state = {
        "phase": phase,
        "activity_type": activity_type,
        "active_spec": active_spec,
        "spec_review_status": spec_review_status,
        "spec_review_gaps": [],
    }
    (project_dir / ".tlm" / "state.json").write_text(json.dumps(state))


def _set_quality(project_dir, level):
    config_file = project_dir / ".tlm" / "config.json"
    config = json.loads(config_file.read_text())
    config["quality_control"] = level
    config_file.write_text(json.dumps(config))


# ═══════════════════════════════════════════════════════════════════
# PURE LOGIC TESTS (no I/O, no mocks)
# ═══════════════════════════════════════════════════════════════════


class TestShouldBlockForQuality:
    """Tests for _should_block_for_quality — quality × severity × gap matrix."""

    # ── severity=pass always allows ──

    def test_pass_severity_high_quality(self):
        assert _should_block_for_quality("high", "pass", []) is False

    def test_pass_severity_standard_quality(self):
        assert _should_block_for_quality("standard", "pass", []) is False

    def test_pass_severity_relaxed_quality(self):
        assert _should_block_for_quality("relaxed", "pass", []) is False

    # ── high quality: blocks on any non-info gap ──

    def test_high_blocks_on_warning_gap(self):
        gaps = [{"severity": "warning", "description": "Missing error handling"}]
        assert _should_block_for_quality("high", "warn", gaps) is True

    def test_high_blocks_on_blocker_gap(self):
        gaps = [{"severity": "blocker", "description": "SQL injection"}]
        assert _should_block_for_quality("high", "block", gaps) is True

    def test_high_allows_info_only_gaps(self):
        gaps = [{"severity": "info", "description": "Consider adding logging"}]
        assert _should_block_for_quality("high", "warn", gaps) is False

    def test_high_blocks_on_block_severity_no_gaps(self):
        assert _should_block_for_quality("high", "block", []) is True

    # ── standard quality: blocks on blockers only ──

    def test_standard_blocks_on_blocker(self):
        gaps = [{"severity": "blocker", "description": "Missing auth"}]
        assert _should_block_for_quality("standard", "block", gaps) is True

    def test_standard_allows_warning_gaps(self):
        gaps = [{"severity": "warning", "description": "Missing error handling"}]
        assert _should_block_for_quality("standard", "warn", gaps) is False

    def test_standard_blocks_on_block_severity_no_gaps(self):
        assert _should_block_for_quality("standard", "block", []) is True

    # ── relaxed quality: blocks only security/data_integrity blockers ──

    def test_relaxed_blocks_security_blocker(self):
        gaps = [{"severity": "blocker", "category": "security", "description": "XSS"}]
        assert _should_block_for_quality("relaxed", "block", gaps) is True

    def test_relaxed_blocks_data_integrity_blocker(self):
        gaps = [{"severity": "blocker", "category": "data_integrity", "description": "No FK"}]
        assert _should_block_for_quality("relaxed", "block", gaps) is True

    def test_relaxed_allows_non_security_blocker(self):
        gaps = [{"severity": "blocker", "category": "performance", "description": "N+1"}]
        assert _should_block_for_quality("relaxed", "block", gaps) is False

    def test_relaxed_allows_warnings(self):
        gaps = [{"severity": "warning", "category": "security", "description": "No CSRF"}]
        assert _should_block_for_quality("relaxed", "warn", gaps) is False

    def test_relaxed_allows_block_severity_empty_gaps(self):
        """Block severity alone doesn't trigger block at relaxed — needs security gap."""
        assert _should_block_for_quality("relaxed", "block", []) is False

    # ── mixed gap lists ──

    def test_standard_mixed_gaps_blocks_if_blocker_present(self):
        gaps = [
            {"severity": "warning", "description": "Style issue"},
            {"severity": "blocker", "description": "Missing validation"},
        ]
        assert _should_block_for_quality("standard", "warn", gaps) is True

    def test_high_mixed_gaps_blocks_if_warning_present(self):
        gaps = [
            {"severity": "info", "description": "Nice to have"},
            {"severity": "warning", "description": "Edge case"},
        ]
        assert _should_block_for_quality("high", "warn", gaps) is True

    # ── non-dict gaps handled gracefully ──

    def test_string_gaps_dont_crash(self):
        gaps = ["some string gap"]
        # string gaps don't have .get(), should not crash
        assert _should_block_for_quality("standard", "block", gaps) is True


class TestFormatInterviewGuide:
    """Tests for _format_interview_guide — formatting guide dict into string."""

    def test_empty_guide(self):
        result = _format_interview_guide({})
        assert result == ""

    def test_structure_only(self):
        guide = {
            "interview_protocol": {
                "structure": [
                    {"phase": "Scope", "questions_range": "1-3", "focus": "What and why"},
                ]
            }
        }
        result = _format_interview_guide(guide)
        assert "Interview phases:" in result
        assert "Scope" in result
        assert "1-3" in result
        assert "What and why" in result

    def test_depth_calibration(self):
        guide = {
            "interview_protocol": {
                "depth_calibration": "12-16 questions (external integration)"
            }
        }
        result = _format_interview_guide(guide)
        assert "Depth:" in result
        assert "12-16" in result

    def test_must_ask_questions(self):
        guide = {
            "interview_protocol": {
                "must_ask": [
                    "What payment provider are you using?",
                    "How will you handle refunds?",
                ]
            }
        }
        result = _format_interview_guide(guide)
        assert "Must-ask questions:" in result
        assert "payment provider" in result
        assert "refunds" in result

    def test_rules(self):
        guide = {"rules": ["Ask ONE question at a time", "Chase ambiguity"]}
        result = _format_interview_guide(guide)
        assert "Rules:" in result
        assert "ONE question" in result
        assert "|" in result  # Joined with pipe

    def test_relevant_gaps(self):
        guide = {"relevant_gaps": ["No CI/CD pipeline", "No SSL configured"]}
        result = _format_interview_guide(guide)
        assert "Relevant project gaps" in result
        assert "CI/CD" in result

    def test_full_guide(self):
        guide = {
            "interview_protocol": {
                "structure": [
                    {"phase": "Scope", "questions_range": "1-3", "focus": "Goals",
                     "domain_tips": ["Ask about target users"]},
                    {"phase": "Domain", "questions_range": "3-8", "focus": "Technical"},
                ],
                "depth_calibration": "standard",
                "must_ask": ["What database?"],
            },
            "rules": ["One Q at a time"],
            "relevant_gaps": ["No tests"],
        }
        result = _format_interview_guide(guide)
        assert "Interview phases:" in result
        assert "Scope" in result
        assert "Tips: Ask about target users" in result
        assert "Depth:" in result
        assert "Must-ask" in result
        assert "Rules:" in result
        assert "Relevant project gaps" in result

    def test_domain_tips_concatenated(self):
        guide = {
            "interview_protocol": {
                "structure": [
                    {"phase": "Security", "questions_range": "2-4", "focus": "Auth",
                     "domain_tips": ["OWASP top 10", "Rate limiting"]},
                ]
            }
        }
        result = _format_interview_guide(guide)
        assert "OWASP top 10; Rate limiting" in result

    def test_must_ask_limited_to_5(self):
        guide = {
            "interview_protocol": {
                "must_ask": [f"Question {i}" for i in range(10)],
            }
        }
        result = _format_interview_guide(guide)
        assert "Question 4" in result
        assert "Question 5" not in result


class TestIsPrerequisiteGap:
    """Tests for is_prerequisite_gap — gap classification logic."""

    def test_known_prerequisite_by_id(self):
        gap = {"id": "no-test-framework", "description": "No test framework"}
        assert is_prerequisite_gap(gap) is True

    def test_known_prerequisite_no_testing(self):
        gap = {"id": "no-testing", "description": "No tests"}
        assert is_prerequisite_gap(gap) is True

    def test_known_prerequisite_no_environments(self):
        gap = {"id": "no-environments", "description": "No environment promotion"}
        assert is_prerequisite_gap(gap) is True

    def test_prerequisite_by_keyword(self):
        gap = {"id": "no-testing-framework-configured", "description": "Missing testing"}
        assert is_prerequisite_gap(gap) is True

    def test_non_prerequisite_gap(self):
        gap = {"id": "no-rate-limiting", "description": "No rate limiting"}
        assert is_prerequisite_gap(gap) is False

    def test_non_prerequisite_security_gap(self):
        gap = {"id": "no-ssl-tls", "description": "No SSL/TLS"}
        assert is_prerequisite_gap(gap) is False

    def test_non_prerequisite_ci_cd(self):
        gap = {"id": "no-ci-cd-pipeline", "description": "No CI/CD pipeline"}
        assert is_prerequisite_gap(gap) is False

    def test_empty_gap_id(self):
        gap = {"id": "", "description": "Something"}
        assert is_prerequisite_gap(gap) is False

    def test_missing_id_key(self):
        gap = {"description": "No ID field"}
        assert is_prerequisite_gap(gap) is False


# ═══════════════════════════════════════════════════════════════════
# FILE-SYSTEM TESTS (tmp_path, no server mocks)
# ═══════════════════════════════════════════════════════════════════


class TestTDDEnforcement:
    """Tests for _check_tdd_compliance and _track_test_write."""

    def test_blocks_without_any_tests(self, project_dir):
        """Source write blocked when no test files written this session."""
        result = _check_tdd_compliance(str(project_dir), "/app/src/main.py")
        assert result is not None
        assert result["decision"] == "block"
        assert "test first" in result["reason"].lower()

    def test_allows_with_matching_test(self, project_dir):
        """Source write allowed when matching test exists."""
        _track_test_write(str(project_dir), "/app/tests/test_main.py")
        result = _check_tdd_compliance(str(project_dir), "/app/src/main.py")
        assert result is None  # No block

    def test_warns_on_mismatched_test(self, project_dir):
        """Source write warns (not blocks) when test exists but doesn't match module."""
        _track_test_write(str(project_dir), "/app/tests/test_auth.py")
        result = _check_tdd_compliance(str(project_dir), "/app/src/payments.py")
        assert result is not None
        assert "decision" not in result  # Not a block
        assert "additionalContext" in result
        assert "payments.py" in result["additionalContext"]

    def test_track_write_creates_file(self, project_dir):
        """_track_test_write creates session_tests.json."""
        _track_test_write(str(project_dir), "/tests/test_foo.py")
        tracking_file = project_dir / ".tlm" / "cache" / "session_tests.json"
        assert tracking_file.exists()
        data = json.loads(tracking_file.read_text())
        assert "/tests/test_foo.py" in data["test_files_written"]

    def test_track_write_appends(self, project_dir):
        """_track_test_write appends to existing tracking file."""
        _track_test_write(str(project_dir), "/tests/test_a.py")
        _track_test_write(str(project_dir), "/tests/test_b.py")
        tracking_file = project_dir / ".tlm" / "cache" / "session_tests.json"
        data = json.loads(tracking_file.read_text())
        assert len(data["test_files_written"]) == 2

    def test_track_write_no_duplicates(self, project_dir):
        """Same file tracked twice doesn't duplicate."""
        _track_test_write(str(project_dir), "/tests/test_a.py")
        _track_test_write(str(project_dir), "/tests/test_a.py")
        tracking_file = project_dir / ".tlm" / "cache" / "session_tests.json"
        data = json.loads(tracking_file.read_text())
        assert len(data["test_files_written"]) == 1

    def test_session_reset_clears_tracking(self, project_dir):
        """Session start should clear the cache — verify empty tracking blocks."""
        _track_test_write(str(project_dir), "/tests/test_x.py")
        # Simulate session reset by deleting cache file
        (project_dir / ".tlm" / "cache" / "session_tests.json").unlink()
        result = _check_tdd_compliance(str(project_dir), "/app/src/x.py")
        assert result is not None
        assert result["decision"] == "block"

    def test_corrupt_tracking_file_blocks(self, project_dir):
        """Corrupt session_tests.json treated as empty → blocks."""
        cache_dir = project_dir / ".tlm" / "cache"
        (cache_dir / "session_tests.json").write_text("not json")
        result = _check_tdd_compliance(str(project_dir), "/app/src/main.py")
        assert result is not None
        assert result["decision"] == "block"

    def test_matching_test_suffix_pattern(self, project_dir):
        """test_foo matches foo.py (prefix removed from test name)."""
        _track_test_write(str(project_dir), "/tests/test_auth.py")
        result = _check_tdd_compliance(str(project_dir), "/app/auth.py")
        assert result is None

    def test_matching_spec_suffix_pattern(self, project_dir):
        """auth_spec matches auth.py."""
        _track_test_write(str(project_dir), "/spec/auth_spec.py")
        result = _check_tdd_compliance(str(project_dir), "/app/auth.py")
        assert result is None

    def test_matching_by_name_inclusion(self, project_dir):
        """test_user_auth matches user_auth.py by substring match."""
        _track_test_write(str(project_dir), "/tests/test_user_auth.py")
        result = _check_tdd_compliance(str(project_dir), "/app/user_auth.py")
        assert result is None

    def test_creates_cache_dir_if_missing(self, tmp_path):
        """_track_test_write creates cache dir if it doesn't exist."""
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()
        # No cache dir exists
        _track_test_write(str(tmp_path), "/tests/test_foo.py")
        assert (tlm_dir / "cache" / "session_tests.json").exists()

    def test_multiple_tests_one_matches(self, project_dir):
        """Multiple tracked tests, one matching — should pass."""
        _track_test_write(str(project_dir), "/tests/test_unrelated.py")
        _track_test_write(str(project_dir), "/tests/test_billing.py")
        result = _check_tdd_compliance(str(project_dir), "/app/billing.py")
        assert result is None

    def test_multiple_tests_none_matching(self, project_dir):
        """Multiple tracked tests, none matching — should warn."""
        _track_test_write(str(project_dir), "/tests/test_auth.py")
        _track_test_write(str(project_dir), "/tests/test_users.py")
        result = _check_tdd_compliance(str(project_dir), "/app/payments.py")
        assert result is not None
        assert "additionalContext" in result


class TestPrerequisiteGapEnforcement:
    """Tests for _check_prerequisite_gaps with real file system."""

    def _write_gaps(self, project_dir, gaps):
        gaps_file = project_dir / ".tlm" / "gaps.json"
        gaps_file.write_text(json.dumps({"gaps": gaps}))

    def test_blocks_prerequisite_at_standard(self, project_dir):
        """Prerequisite gap blocks at standard quality."""
        self._write_gaps(project_dir, [
            {"id": "no-test-framework", "description": "No test framework", "dismissed": False},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is not None
        assert result["decision"] == "block"
        assert "test framework" in result["reason"].lower()

    def test_blocks_prerequisite_at_high(self, project_dir):
        """Prerequisite gap blocks at high quality."""
        _set_quality(project_dir, "high")
        self._write_gaps(project_dir, [
            {"id": "no-test-environment", "description": "No test environment", "dismissed": False},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is not None
        assert result["decision"] == "block"

    def test_warns_at_relaxed(self, project_dir):
        """Prerequisite gap warns (not blocks) at relaxed quality."""
        _set_quality(project_dir, "relaxed")
        self._write_gaps(project_dir, [
            {"id": "no-test-framework", "description": "No test framework", "dismissed": False},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is not None
        assert "decision" not in result
        assert "additionalContext" in result
        assert "test framework" in result["additionalContext"].lower()

    def test_dismissed_gaps_ignored(self, project_dir):
        """Dismissed prerequisite gaps don't block."""
        self._write_gaps(project_dir, [
            {"id": "no-test-framework", "description": "No test framework", "dismissed": True},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is None

    def test_non_prerequisite_gaps_dont_block(self, project_dir):
        """Non-prerequisite gaps don't block."""
        self._write_gaps(project_dir, [
            {"id": "no-rate-limiting", "description": "No rate limiting", "dismissed": False},
            {"id": "no-ssl-tls", "description": "No SSL", "dismissed": False},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is None

    def test_no_gaps_file_allows(self, project_dir):
        """No gaps.json → no blocking."""
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is None

    def test_corrupt_gaps_file_allows(self, project_dir):
        """Corrupt gaps.json → no blocking (graceful degradation)."""
        (project_dir / ".tlm" / "gaps.json").write_text("not json")
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is None

    def test_empty_gaps_list_allows(self, project_dir):
        """Empty gaps list → no blocking."""
        self._write_gaps(project_dir, [])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is None

    def test_mixed_prerequisite_and_non_prerequisite(self, project_dir):
        """Only prerequisite gaps cause blocking, non-prerequisite ignored."""
        self._write_gaps(project_dir, [
            {"id": "no-rate-limiting", "description": "No rate limiting", "dismissed": False},
            {"id": "no-test-framework", "description": "No test framework", "dismissed": False},
            {"id": "no-ssl-tls", "description": "No SSL", "dismissed": False},
        ])
        result = _check_prerequisite_gaps(str(project_dir))
        assert result is not None
        assert result["decision"] == "block"
        # Only the prerequisite gap should be in the reason
        assert "test framework" in result["reason"].lower()
        assert "rate limiting" not in result["reason"].lower()


class TestSetSpecReviewStatus:
    """Tests for set_spec_review_status in state.py."""

    def test_set_approved(self, project_dir):
        set_spec_review_status(str(project_dir), "approved")
        state = read_state(str(project_dir))
        assert state["spec_review_status"] == "approved"

    def test_set_rejected_with_gaps(self, project_dir):
        gaps = ["Missing error handling", "No rate limiting"]
        set_spec_review_status(str(project_dir), "rejected", gaps)
        state = read_state(str(project_dir))
        assert state["spec_review_status"] == "rejected"
        assert state["spec_review_gaps"] == gaps

    def test_set_pending(self, project_dir):
        set_spec_review_status(str(project_dir), "pending")
        state = read_state(str(project_dir))
        assert state["spec_review_status"] == "pending"

    def test_invalid_status_raises(self, project_dir):
        with pytest.raises(ValueError, match="Invalid spec review status"):
            set_spec_review_status(str(project_dir), "invalid")

    def test_preserves_other_state_fields(self, project_dir):
        _set_state(project_dir, "implementation", "feature", ".tlm/specs/auth.md")
        set_spec_review_status(str(project_dir), "approved")
        state = read_state(str(project_dir))
        assert state["phase"] == "implementation"
        assert state["activity_type"] == "feature"
        assert state["active_spec"] == ".tlm/specs/auth.md"


# ═══════════════════════════════════════════════════════════════════
# SERVER-MOCKED TESTS
# ═══════════════════════════════════════════════════════════════════


class TestSpecReviewGate:
    """Tests for _spec_review_gate — blocks implementation based on server review."""

    def _write_spec(self, project_dir, content="# Auth Feature\nImplement login."):
        spec_path = project_dir / ".tlm" / "specs" / "auth.md"
        spec_path.write_text(content)
        return ".tlm/specs/auth.md"

    @patch("tlm.hooks.get_client")
    def test_blocks_on_server_block_verdict(self, mock_client, project_dir):
        """Server returns block → gate blocks."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "block",
            "gaps": [{"severity": "blocker", "description": "Missing auth flow"}],
            "models_used": ["gemini-2.5-pro"],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert result.get("decision") == "block"
        assert "missing auth flow" in result["reason"].lower()

    @patch("tlm.hooks.get_client")
    def test_approves_on_pass(self, mock_client, project_dir):
        """Server returns pass → gate allows."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "pass",
            "gaps": [],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert result == {}

        # Verify state updated to approved
        new_state = read_state(str(project_dir))
        assert new_state["spec_review_status"] == "approved"

    @patch("tlm.hooks.get_client")
    def test_warnings_pass_at_standard(self, mock_client, project_dir):
        """Standard quality: warnings don't block, but are surfaced."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "warn",
            "gaps": [{"severity": "warning", "description": "Consider error handling"}],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert "decision" not in result  # Not blocked
        assert "additionalContext" in result
        assert "error handling" in result["additionalContext"].lower()

    @patch("tlm.hooks.get_client")
    def test_warnings_block_at_high(self, mock_client, project_dir):
        """High quality: warnings DO block."""
        _set_quality(project_dir, "high")
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "warn",
            "gaps": [{"severity": "warning", "description": "Missing edge case"}],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert result.get("decision") == "block"

    @patch("tlm.hooks.get_client", return_value=None)
    def test_server_down_auto_approves(self, mock_client, project_dir):
        """No server connection → auto-approve with warning."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        result = _spec_review_gate(str(project_dir), state)
        assert "decision" not in result
        assert "additionalContext" in result
        assert "skipped" in result["additionalContext"].lower()

        new_state = read_state(str(project_dir))
        assert new_state["spec_review_status"] == "approved"

    @patch("tlm.hooks.get_client")
    def test_server_error_auto_approves(self, mock_client, project_dir):
        """Server throws exception → auto-approve with warning."""
        from tlm.api_client import TLMConnectionError

        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.side_effect = TLMConnectionError("timeout")
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert "decision" not in result
        assert "additionalContext" in result

    @patch("tlm.hooks.get_client")
    def test_rejected_status_written_to_state(self, mock_client, project_dir):
        """Blocked review writes rejected status + gaps to state."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "block",
            "gaps": [
                {"severity": "blocker", "description": "No error handling"},
                {"severity": "blocker", "description": "Missing validation"},
            ],
        }
        mock_client.return_value = client

        _spec_review_gate(str(project_dir), state)

        new_state = read_state(str(project_dir))
        assert new_state["spec_review_status"] == "rejected"
        assert len(new_state["spec_review_gaps"]) == 2
        assert "No error handling" in new_state["spec_review_gaps"]

    def test_no_spec_allows_transition(self, project_dir):
        """No spec found → allow transition without review."""
        _set_state(project_dir, "tlm_active")
        state = read_state(str(project_dir))
        result = _spec_review_gate(str(project_dir), state)
        assert result == {}

    @patch("tlm.hooks.get_client")
    def test_finds_latest_spec_without_active_spec(self, mock_client, project_dir):
        """When no active_spec in state, finds latest spec in specs dir."""
        # Write two specs
        (project_dir / ".tlm" / "specs" / "2026-01-01-old.md").write_text("Old spec")
        (project_dir / ".tlm" / "specs" / "2026-02-18-new.md").write_text("New spec")

        _set_state(project_dir, "tlm_active")  # No active_spec
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {"severity": "pass", "gaps": []}
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        # Verify it called review_spec (found a spec to review)
        client.review_spec.assert_called_once()
        # The spec content should be from the latest file
        call_kwargs = client.review_spec.call_args
        assert "New spec" in call_kwargs.kwargs.get("spec", "") or "New spec" in call_kwargs[1].get("spec", "")

    @patch("tlm.hooks.get_client")
    def test_models_used_in_block_reason(self, mock_client, project_dir):
        """Block reason includes which models were used."""
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "block",
            "gaps": [{"severity": "blocker", "description": "Issue"}],
            "models_used": ["gemini-2.5-pro", "claude-sonnet"],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        assert "gemini-2.5-pro" in result["reason"]
        assert "claude-sonnet" in result["reason"]

    @patch("tlm.hooks.get_client")
    def test_relaxed_quality_only_security_blocks(self, mock_client, project_dir):
        """Relaxed quality: only security/data_integrity blockers block."""
        _set_quality(project_dir, "relaxed")
        spec = self._write_spec(project_dir)
        _set_state(project_dir, "tlm_active", active_spec=spec)
        state = read_state(str(project_dir))

        client = MagicMock()
        client.review_spec.return_value = {
            "severity": "block",
            "gaps": [{"severity": "blocker", "category": "performance", "description": "Slow query"}],
        }
        mock_client.return_value = client

        result = _spec_review_gate(str(project_dir), state)
        # Performance blocker at relaxed shouldn't block
        assert result.get("decision") != "block"


class TestInterviewGuidance:
    """Tests for _get_interview_guidance — server fetch + session caching."""

    @patch("tlm.hooks.get_client")
    def test_fetches_from_server_on_cache_miss(self, mock_client, project_dir):
        """No cache → fetches from server."""
        client = MagicMock()
        client.get_interview_guide.return_value = {
            "guide": {
                "interview_protocol": {
                    "structure": [{"phase": "Scope", "questions_range": "1-3", "focus": "Goals"}],
                    "must_ask": ["What database?"],
                },
                "rules": ["One at a time"],
            }
        }
        mock_client.return_value = client

        result = _get_interview_guidance(str(project_dir), "feature")
        assert "Scope" in result
        assert "database" in result.lower()
        client.get_interview_guide.assert_called_once()

    @patch("tlm.hooks.get_client")
    def test_uses_cache_on_hit(self, mock_client, project_dir):
        """Cached guide → no server call."""
        cache_file = project_dir / ".tlm" / "cache" / "interview_guide.json"
        guide = {
            "guide": {
                "interview_protocol": {
                    "structure": [{"phase": "Cached", "questions_range": "1-2", "focus": "Cached"}],
                },
                "rules": ["Cached rule"],
            }
        }
        cache_file.write_text(json.dumps(guide))

        client = MagicMock()
        mock_client.return_value = client

        result = _get_interview_guidance(str(project_dir), "feature")
        assert "Cached" in result
        client.get_interview_guide.assert_not_called()

    @patch("tlm.hooks.get_client", return_value=None)
    def test_server_down_returns_fallback(self, mock_client, project_dir):
        """No server → returns minimal fallback guidance."""
        result = _get_interview_guidance(str(project_dir), "feature")
        assert "scope" in result.lower()
        assert "failure modes" in result.lower()

    @patch("tlm.hooks.get_client")
    def test_server_error_returns_fallback(self, mock_client, project_dir):
        """Server throws → returns minimal fallback."""
        from tlm.api_client import TLMConnectionError

        client = MagicMock()
        client.get_interview_guide.side_effect = TLMConnectionError("timeout")
        mock_client.return_value = client

        result = _get_interview_guidance(str(project_dir), "feature")
        assert "scope" in result.lower()

    @patch("tlm.hooks.get_client")
    def test_caches_after_successful_fetch(self, mock_client, project_dir):
        """Successful fetch → writes cache file."""
        client = MagicMock()
        client.get_interview_guide.return_value = {
            "guide": {
                "interview_protocol": {"structure": []},
                "rules": ["Rule A"],
            }
        }
        mock_client.return_value = client

        _get_interview_guidance(str(project_dir), "feature")
        cache_file = project_dir / ".tlm" / "cache" / "interview_guide.json"
        assert cache_file.exists()
        cached = json.loads(cache_file.read_text())
        assert "Rule A" in cached["guide"]["rules"]

    def test_corrupt_cache_refetches(self, project_dir):
        """Corrupt cache file → treated as cache miss."""
        cache_file = project_dir / ".tlm" / "cache" / "interview_guide.json"
        cache_file.write_text("not valid json")

        with patch("tlm.hooks.get_client", return_value=None):
            result = _get_interview_guidance(str(project_dir), "feature")
            # Falls back to minimal guidance
            assert "scope" in result.lower()


class TestMinimalInterviewFallback:
    """Tests for _minimal_interview_fallback."""

    def test_contains_all_phases(self):
        result = _minimal_interview_fallback()
        assert "scope" in result.lower()
        assert "domain depth" in result.lower()
        assert "failure modes" in result.lower()
        assert "operations" in result.lower()
        assert "testing" in result.lower()
        assert "safety" in result.lower()

    def test_contains_rules(self):
        result = _minimal_interview_fallback()
        assert "one question" in result.lower()
        assert "spec" in result.lower()


# ═══════════════════════════════════════════════════════════════════
# BUG FIX TESTS — 3 enforcement bypasses
# ═══════════════════════════════════════════════════════════════════


class TestIdleToTlmActiveGapEnforcement:
    """Bug 1: Gap enforcement must work when transitioning from idle.

    The most common flow is idle → tlm_active. Prerequisite gaps must
    block this transition regardless of current phase.
    """

    def _write_gaps(self, project_dir, gaps):
        gaps_file = project_dir / ".tlm" / "gaps.json"
        gaps_file.write_text(json.dumps({"gaps": gaps}))

    def test_idle_to_tlm_active_blocked_by_prerequisite_gap(self, project_dir):
        """From idle, transition to tlm_active blocked when prerequisite gap exists."""
        self._write_gaps(project_dir, [
            {"id": "no-test-framework", "description": "No test framework configured",
             "dismissed": False},
        ])
        _set_state(project_dir, "idle")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(project_dir / ".tlm" / "state.json"),
                "content": json.dumps({
                    "phase": "tlm_active", "activity_type": "feature",
                }),
            },
        })
        assert result.get("decision") == "block"
        assert ("infrastructure" in result["reason"].lower()
                or "test framework" in result["reason"].lower())

    def test_idle_to_tlm_active_allowed_when_no_gaps(self, project_dir):
        """From idle, transition to tlm_active allowed when no prerequisite gaps."""
        _set_state(project_dir, "idle")
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {
                "file_path": str(project_dir / ".tlm" / "state.json"),
                "content": json.dumps({
                    "phase": "tlm_active", "activity_type": "feature",
                }),
            },
        })
        assert result.get("decision") != "block"


class TestTestTrackingDuringInterview:
    """Bug 2: Tests written during interview must be tracked for TDD.

    Tests written during tlm_active should carry forward so that
    TDD enforcement in implementation doesn't block unnecessarily.
    """

    def test_test_tracked_during_interview_carries_to_implementation(self, project_dir):
        """Test written during tlm_active is tracked and carries to implementation."""
        _set_state(project_dir, "tlm_active", "feature")

        # Write a test during interview — should be allowed AND tracked
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/tests/test_products.py"},
        })
        assert result == {}  # Test writes allowed during interview

        # Verify the test was tracked in session_tests.json
        tracking_file = project_dir / ".tlm" / "cache" / "session_tests.json"
        assert tracking_file.exists(), (
            "Test file write during interview should be tracked in session_tests.json"
        )

        # Transition to implementation with approved spec
        _set_state(project_dir, "implementation", "feature",
                   spec_review_status="approved")

        # Source write should pass TDD check (matching test already tracked)
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert result is None or result == {} or "decision" not in result


class TestSpecStatusEnforcement:
    """Bug 3: Only approved spec status should allow source writes.

    Status 'none' (never reviewed) and 'pending' (in progress) must
    block, not just 'rejected'.
    """

    def _setup_with_tracked_test(self, project_dir):
        """Pre-track a test so TDD check passes (isolates spec check)."""
        _track_test_write(str(project_dir), "/app/tests/test_products.py")

    def test_spec_status_none_blocks_source_write(self, project_dir):
        """Implementation with spec_review_status='none' blocks source writes."""
        _set_state(project_dir, "implementation", "feature",
                   spec_review_status="none")
        self._setup_with_tracked_test(project_dir)
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert result.get("decision") == "block"
        assert "spec" in result["reason"].lower()

    def test_spec_status_pending_blocks_source_write(self, project_dir):
        """Implementation with spec_review_status='pending' blocks source writes."""
        _set_state(project_dir, "implementation", "feature",
                   spec_review_status="pending")
        self._setup_with_tracked_test(project_dir)
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        assert result.get("decision") == "block"
        assert "spec" in result["reason"].lower()

    def test_spec_status_approved_allows_source_write(self, project_dir):
        """Implementation with spec_review_status='approved' passes spec check."""
        _set_state(project_dir, "implementation", "feature",
                   spec_review_status="approved")
        self._setup_with_tracked_test(project_dir)
        result = hook_guard(str(project_dir), {
            "tool_name": "Write",
            "tool_input": {"file_path": "/app/products.py"},
        })
        # Should pass spec check AND TDD check (matching test exists)
        assert result is None or result == {} or "decision" not in result
