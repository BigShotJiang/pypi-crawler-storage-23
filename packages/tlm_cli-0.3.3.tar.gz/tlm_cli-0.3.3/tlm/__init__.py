"""TLM — Your AI Tech Lead + Manager. The annoying agent that makes Claude do the right thing."""
__version__ = "0.3.0"
