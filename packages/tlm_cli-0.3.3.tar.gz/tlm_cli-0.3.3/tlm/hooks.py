"""
TLM Hook Handlers — Context injection and enforcement for Claude Code.

Hook handlers:
    hook_session_start      — SessionStart: loads project context + knowledge.db rules
    hook_prompt_submit      — UserPromptSubmit: reminds Claude of TLM rules + captures prompt
    hook_guard              — PreToolUse (Write/Edit): blocking spec gate
    hook_compliance_gate    — PreToolUse (Bash): blocking review gate on git commit
    hook_deployment_gate    — PreToolUse (Bash): blocking deployment gate
"""

import json
import re
import subprocess
import datetime
from pathlib import Path

from tlm.state import read_state, set_spec_review_status
from tlm.api_client import get_client, TLMConnectionError
from tlm.cache import TLMCache
from tlm.knowledge_db import KnowledgeDB

# ANSI colors for user-visible hook output (block reasons + session_start).
# Only used in strings the user sees in their terminal — never in
# additionalContext (which goes to Claude's internal context, not the screen).
_C = "\033[36m"   # cyan — TLM branding
_G = "\033[32m"   # green — good news, loaded successfully
_Y = "\033[33m"   # amber — TLM prevented something
_R = "\033[31m"   # red — detected issues
_B = "\033[1m"    # bold
_D = "\033[2m"    # dim
_X = "\033[0m"    # reset


def _get_quality_level(project_root: str) -> str:
    """Read quality_control from .tlm/config.json. Default: standard."""
    config_file = Path(project_root) / ".tlm" / "config.json"
    try:
        config = json.loads(config_file.read_text())
        return config.get("quality_control", "standard")
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        return "standard"


def _get_project_id(project_root: str) -> str | None:
    """Read project_id from .tlm/config.json."""
    config_file = Path(project_root) / ".tlm" / "config.json"
    try:
        config = json.loads(config_file.read_text())
        return config.get("project_id")
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        return None


def _try_server_sync(project_root: str) -> dict | None:
    """Try to sync project data from TLM server. Returns sync data or None."""
    root = Path(project_root)
    config_file = root / ".tlm" / "config.json"

    client = get_client()
    if not client:
        return None

    if not config_file.exists():
        return None

    try:
        config = json.loads(config_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    project_id = config.get("project_id")
    if not project_id:
        return None

    try:
        return client.sync(project_id, timeout=3.0)
    except (TLMConnectionError, Exception):
        return None


def hook_session_start(project_root: str) -> str:
    """SessionStart hook: inject project context + knowledge.db rules into Claude's session."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return "TLM is not initialized in this project. Run `tlm install` to set up."

    # Clear session caches (interview guide, session test tracking)
    cache_dir = tlm_dir / "cache"
    if cache_dir.exists():
        for cache_file in ("interview_guide.json", "session_tests.json"):
            (cache_dir / cache_file).unlink(missing_ok=True)

    # Try server sync → cache → raw files
    cache = TLMCache(str(tlm_dir))
    sync_data = _try_server_sync(project_root)

    if sync_data:
        cache.write_sync(sync_data)

    parts = [f"{_C}{_B}[TLM]{_X} You are operating under TLM rules. Read CLAUDE.md for full details.",
             f"{_D}When using knowledge facts, attribute: 'Based on TLM's analysis of your project, [fact].'{_X}\n"]

    # Current state
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")
    active_spec = state.get("active_spec")

    parts.append(f"{_B}Current phase:{_X} {phase}")
    if activity:
        parts.append(f"{_B}Activity type:{_X} {activity}")
    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            spec_preview = spec_path.read_text()[:500]
            parts.append(f"{_B}Active spec:{_X} {active_spec}")
            parts.append(f"Spec preview:\n{_D}{spec_preview}{_X}")

    # Quality control level
    quality = _get_quality_level(project_root)
    parts.append(f"\n{_B}Quality control:{_X} {quality}")

    # Knowledge from knowledge.db (vector search if possible, else recent rules)
    try:
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        rules = db.list_rules()
        if rules:
            parts.append(f"\n{_G}Project rules ({len(rules)} active):{_X}")
            for rule in rules[:10]:
                parts.append(f"  {_D}-{_X} {rule['rule_text']}")
            if len(rules) > 10:
                parts.append(f"  {_D}... and {len(rules) - 10} more{_X}")
        db.close()
    except Exception:
        pass

    # Knowledge — prefer cache/sync, fall back to file
    knowledge = cache.get_knowledge_with_fallback()
    if knowledge:
        facts = [l.strip() for l in knowledge.split("\n")
                 if l.strip() and not l.startswith(("#", "_", "---"))]
        if facts:
            parts.append(f"\n{_G}Project knowledge ({len(facts)} facts):{_X}")
            for fact in facts[:10]:
                parts.append(f"  {_D}{fact}{_X}")
            if len(facts) > 10:
                parts.append(f"  {_D}... and {len(facts) - 10} more (see .tlm/knowledge.md){_X}")

    # Latest lessons — prefer cache/sync, fall back to files
    cached = cache.read_sync()
    if cached and cached.get("latest_synthesis"):
        synthesis = cached["latest_synthesis"]
        improvements = synthesis.get("interview_improvements", [])
        accuracy = synthesis.get("spec_accuracy_percent")
        if accuracy is not None:
            parts.append(f"\n{_G}Learning: spec accuracy {accuracy}%{_X}")
        if improvements:
            parts.append(f"{_B}Lesson-driven interview additions:{_X}")
            for imp in improvements[:5]:
                parts.append(f"  - MUST ASK: {imp}")
    else:
        lessons_dir = tlm_dir / "lessons"
        if lessons_dir.exists():
            synthesis_files = sorted(lessons_dir.glob("*-synthesis.json"), reverse=True)
            if synthesis_files:
                try:
                    synthesis = json.loads(synthesis_files[0].read_text())
                    improvements = synthesis.get("interview_improvements", [])
                    accuracy = synthesis.get("spec_accuracy_percent")
                    if accuracy is not None:
                        parts.append(f"\n{_G}Learning: spec accuracy {accuracy}%{_X}")
                    if improvements:
                        parts.append(f"{_B}Lesson-driven interview additions:{_X}")
                        for imp in improvements[:5]:
                            parts.append(f"  - MUST ASK: {imp}")
                except (json.JSONDecodeError, OSError):
                    pass

    # Unprocessed commits count
    commits_dir = tlm_dir / "commits"
    if commits_dir.exists():
        unprocessed = [f for f in commits_dir.glob("*.json")
                       if not f.name.endswith("-processed.json")]
        if unprocessed:
            parts.append(f"\n{len(unprocessed)} commits analyzed since last synthesis.")

    # Project gaps
    gaps_file = tlm_dir / "gaps.json"
    if gaps_file.exists():
        try:
            gaps_data = json.loads(gaps_file.read_text())
            active = [g for g in gaps_data.get("gaps", []) if not g.get("dismissed")]
            if active:
                high = [g for g in active if g.get("severity") == "high"]
                parts.append(f"\n{_Y}Known project gaps ({len(active)}):{_X}")
                for g in high[:5]:
                    parts.append(f"  {_Y}⚠{_X} {g['description']}")
                if len(active) > len(high[:5]):
                    remaining = len(active) - len(high[:5])
                    parts.append(f"  {_D}... and {remaining} lower-severity gaps{_X}")
        except (json.JSONDecodeError, OSError):
            pass

    # Enforcement config — prefer cache/sync, fall back to file
    enforcement_config = cache.get_enforcement_config_with_fallback()
    if enforcement_config and enforcement_config.get("approved"):
        envs = list(enforcement_config.get("environments", {}).keys())
        checks_count = len(enforcement_config.get("checks", []))
        parts.append(f"\n{_G}Enforcement: {checks_count} checks, environments: {', '.join(envs)}{_X}")
    elif not (cached and cached.get("enforcement_config")):
        enforcement_file = tlm_dir / "enforcement.json"
        if enforcement_file.exists():
            try:
                config = json.loads(enforcement_file.read_text())
                if config.get("approved"):
                    envs = list(config.get("environments", {}).keys())
                    checks_count = len(config.get("checks", []))
                    parts.append(f"\n{_G}Enforcement: {checks_count} checks, environments: {', '.join(envs)}{_X}")
            except (json.JSONDecodeError, OSError):
                pass

    return "\n".join(parts)


def hook_prompt_submit(project_root: str, prompt_text: str = "") -> dict:
    """UserPromptSubmit hook: remind Claude of TLM state + capture prompt text.

    Returns dict with additionalContext key for Claude Code.
    """
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")

    # Capture prompt to session_prompts.jsonl if session learning is on
    if prompt_text:
        _capture_prompt(project_root, prompt_text)

    if phase == "idle":
        context = (
            "[TLM] Before responding, classify this request: "
            "Is it a significant engineering activity? "
            "Check Tier 1 (always activate) and Tier 2 (self-classify) "
            "in CLAUDE.md. If significant, enter interview mode first. "
            "If activating TLM, start your response with "
            "'TLM > [reason]. Let me refine your requirements first.'"
        )
    elif phase == "tlm_active":
        # Get server-sourced interview guidance (cached per session)
        interview_guidance = _get_interview_guidance(project_root, activity)
        context = (
            f"[TLM] You are in interview mode (activity: {activity or 'unknown'}). "
            "Continue asking questions one at a time. "
            "Do not write code until the interview is complete and spec is generated. "
            "When interview is complete and spec is saved, start with "
            "'TLM > Requirements captured. Here\\'s the spec: [path]. Ready to implement.'"
        )
        if interview_guidance:
            context += f"\n\n[TLM Interview Guide]\n{interview_guidance}"
    elif phase == "implementation":
        active_spec = state.get("active_spec")
        spec_note = f" Active spec: {active_spec}." if active_spec else ""
        context = (
            f"[TLM] Implementation phase.{spec_note} "
            "TDD is mandatory: write tests first, verify they fail, "
            "then implement, then verify they pass. "
            "When starting to write tests, say 'TLM > Tests first.'"
        )
    elif phase == "deployment":
        context = (
            "[TLM] Deployment phase. Follow the deployment pipeline "
            "from enforcement config. Never skip environments."
        )
    else:
        context = "[TLM] TLM rules are active. Check CLAUDE.md."

    return {"additionalContext": context}


def hook_guard(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Write/Edit tools: BLOCKING spec gate + TDD enforcement.

    In tlm_active phase: BLOCKS file writes (except test files and .tlm/).
    On spec write: triggers spec review via server.
    On phase transition to implementation: blocks if spec not approved.
    In implementation phase: enforces TDD (blocks source writes without tests).
    """
    tool_name = tool_input.get("tool_name", "")
    file_input = tool_input.get("tool_input", {})
    file_path = file_input.get("file_path", "")

    if tool_name not in ("Write", "Edit"):
        return {}

    state = read_state(project_root)
    phase = state.get("phase", "idle")

    root = Path(project_root)
    tlm_dir = root / ".tlm"
    is_tlm_file = "/.tlm/" in file_path or file_path.startswith(".tlm/")
    is_spec_file = is_tlm_file and "/specs/" in file_path
    is_state_file = is_tlm_file and file_path.endswith("state.json")
    is_test_file = _is_test_file(file_path, project_root=project_root)

    # ── Spec write detection: mark review as pending ──
    if is_spec_file:
        set_spec_review_status(project_root, "pending")
        return {}

    # ── Phase transition detection: spec review + gap enforcement ──
    # Must run BEFORE idle early-return so idle→tlm_active transitions
    # are checked for prerequisite gaps.
    if is_state_file:
        new_content = file_input.get("content", "") or file_input.get("new_string", "")
        if '"phase"' in new_content:
            # Transitioning to implementation: spec review gate
            if '"implementation"' in new_content:
                # Check prerequisite gaps first
                gap_block = _check_prerequisite_gaps(project_root)
                if gap_block:
                    return gap_block
                return _spec_review_gate(project_root, state)
            # Transitioning to tlm_active: check prerequisite gaps
            if '"tlm_active"' in new_content:
                gap_block = _check_prerequisite_gaps(project_root)
                if gap_block:
                    return gap_block
        return {}

    if phase == "idle":
        return {}

    # ── During interview (tlm_active): BLOCK source code writes ──
    if phase == "tlm_active" and not is_test_file:
        if is_tlm_file:
            return {}
        return {
            "decision": "block",
            "reason": (
                f"{_Y}TLM >{_X} Complete the discovery interview and get spec approval "
                f"before writing code. Run {_B}tlm build{_X} or finish the interview first."
            ),
        }

    # ── During implementation: TDD + spec approval enforcement ──
    if phase == "implementation" and not is_test_file:
        if is_tlm_file:
            return {}

        # Block if spec not approved — only "approved" allows source writes
        spec_status = state.get("spec_review_status", "none")
        if spec_status != "approved":
            if spec_status == "rejected":
                gaps = state.get("spec_review_gaps", [])
                gaps_text = "\n".join(f"  - {g.get('description', g) if isinstance(g, dict) else g}" for g in gaps[:5])
                return {
                    "decision": "block",
                    "reason": (
                        f"{_R}TLM > Spec review REJECTED.{_X} Fix the spec before implementing.\n"
                        f"Gaps found:\n{gaps_text}\n\n"
                        "Update the spec in .tlm/specs/ to address these gaps."
                    ),
                }
            elif spec_status == "pending":
                return {
                    "decision": "block",
                    "reason": (
                        f"{_Y}TLM > Spec review in progress.{_X} "
                        "Wait for the spec review to complete before writing implementation code."
                    ),
                }
            else:  # "none" or any other
                return {
                    "decision": "block",
                    "reason": (
                        f"{_Y}TLM > Spec has not been reviewed yet.{_X} "
                        "Save the spec to .tlm/specs/ to trigger review, "
                        "then transition to implementation."
                    ),
                }

        # TDD enforcement — check if tests written this session
        tdd_result = _check_tdd_compliance(project_root, file_path)
        if tdd_result:
            return tdd_result

    # Track test file writes (in both interview and implementation phases)
    if is_test_file and phase in ("tlm_active", "implementation"):
        _track_test_write(project_root, file_path)

    return {}


def _spec_review_gate(project_root: str, state: dict) -> dict:
    """Gate implementation phase transition on spec review approval."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"
    quality = _get_quality_level(project_root)

    # Find the spec to review
    spec_content = ""
    active_spec = state.get("active_spec")
    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            spec_content = spec_path.read_text()
    else:
        specs_dir = tlm_dir / "specs"
        if specs_dir.exists():
            specs = sorted(specs_dir.glob("*.md"), reverse=True)
            if specs:
                spec_content = specs[0].read_text()

    if not spec_content:
        # No spec found — allow transition (nothing to review)
        return {}

    # Get project knowledge for review context
    knowledge = ""
    try:
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        rules = db.list_rules()
        knowledge = "\n".join(r["rule_text"] for r in rules[:10])
        db.close()
    except Exception:
        pass

    # Call server for spec review
    client = get_client()
    if not client:
        # No server — allow with warning
        set_spec_review_status(project_root, "approved")
        return {
            "additionalContext": (
                "[TLM] Spec review skipped (server unreachable). "
                "Proceeding to implementation without review."
            ),
        }

    try:
        result = client.review_spec(
            spec=spec_content,
            project_knowledge=knowledge,
            quality_level=quality,
        )
    except (TLMConnectionError, Exception):
        set_spec_review_status(project_root, "approved")
        return {
            "additionalContext": (
                "[TLM] Spec review skipped (server error). "
                "Proceeding to implementation without review."
            ),
        }

    severity = result.get("severity", "pass")
    gaps = result.get("gaps", [])

    # Apply quality-gated approval
    should_block = _should_block_for_quality(quality, severity, gaps)

    if should_block:
        gap_descriptions = [
            g.get("description", str(g)) if isinstance(g, dict) else str(g)
            for g in gaps[:10]
        ]
        set_spec_review_status(project_root, "rejected", gap_descriptions)

        gaps_text = "\n".join(f"  {_R}-{_X} [{g.get('severity', '?')}] {g.get('description', g)}"
                              for g in gaps[:10] if isinstance(g, dict))
        if not gaps_text:
            gaps_text = "\n".join(f"  {_R}-{_X} {g}" for g in gap_descriptions)

        models_used = result.get("models_used", [])
        model_info = f" (models: {', '.join(models_used)})" if models_used else ""

        return {
            "decision": "block",
            "reason": (
                f"{_R}TLM > Spec review BLOCKED implementation{_X}{model_info}\n\n"
                f"Gaps found:\n{gaps_text}\n\n"
                "Fix the spec in .tlm/specs/ to address these gaps, "
                "then try transitioning to implementation again."
            ),
        }
    else:
        set_spec_review_status(project_root, "approved")
        if gaps:
            gaps_text = "\n".join(f"  - {g.get('description', g) if isinstance(g, dict) else g}"
                                  for g in gaps[:5])
            return {
                "additionalContext": (
                    f"[TLM] Spec review passed with warnings:\n{gaps_text}\n"
                    "Proceeding to implementation. Consider addressing these in the future."
                ),
            }
        return {}


def _check_prerequisite_gaps(project_root: str) -> dict | None:
    """Check if prerequisite infrastructure gaps exist that should block feature work.

    Returns block dict if blocking, None if OK.
    """
    from tlm.engine import is_prerequisite_gap

    root = Path(project_root)
    quality = _get_quality_level(project_root)

    # Relaxed quality: warn but don't block
    gaps_file = root / ".tlm" / "gaps.json"
    if not gaps_file.exists():
        return None

    try:
        gaps_data = json.loads(gaps_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    active_gaps = [g for g in gaps_data.get("gaps", []) if not g.get("dismissed")]
    prerequisite_gaps = [g for g in active_gaps if is_prerequisite_gap(g)]

    if not prerequisite_gaps:
        return None

    gap_descriptions = [g.get("description", g.get("id", "unknown")) for g in prerequisite_gaps]
    gaps_text = "\n".join(f"  {_R}-{_X} {desc}" for desc in gap_descriptions)

    if quality in ("high", "standard"):
        return {
            "decision": "block",
            "reason": (
                f"{_R}TLM > Critical infrastructure gaps must be resolved first:{_X}\n"
                f"{gaps_text}\n\n"
                "Ask Claude to help you set up the missing infrastructure before starting feature work.\n"
                f"To bypass this check, set quality_control to 'relaxed' in .tlm/config.json."
            ),
        }
    else:
        # Relaxed: warn
        return {
            "additionalContext": (
                f"[TLM] Warning: your project has infrastructure gaps that should be addressed:\n"
                + "\n".join(f"  - {desc}" for desc in gap_descriptions)
                + "\nConsider fixing these before building new features."
            ),
        }


def _should_block_for_quality(quality: str, severity: str, gaps: list) -> bool:
    """Determine if spec review should block based on quality level.

    high: block on ANY gap (blocker or warning). Only info gaps allowed.
    standard: block on any blocker. Warnings allowed but surfaced.
    relaxed: block only on critical security/data-integrity blockers.
    """
    if severity == "pass":
        return False

    if quality == "high":
        # Block if any non-info gap
        for g in gaps:
            if isinstance(g, dict) and g.get("severity") in ("blocker", "warning"):
                return True
        return severity == "block"

    elif quality == "standard":
        # Block only on blockers
        for g in gaps:
            if isinstance(g, dict) and g.get("severity") == "blocker":
                return True
        return severity == "block"

    else:  # relaxed
        # Block only on security/data-integrity blockers
        for g in gaps:
            if isinstance(g, dict) and g.get("severity") == "blocker":
                category = g.get("category", "")
                if category in ("security", "data_integrity"):
                    return True
        return False


def hook_compliance_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: BLOCKING review gate on git commit.

    Behavior depends on quality_control setting:
    - high: Blocks on issues (calls /api/v2/review/code)
    - standard: Warns on issues (calls /api/v2/review/code)
    - relaxed: Mechanical checks only, skips LLM review
    """
    command = tool_input.get("command", "")

    if not _is_git_commit(command):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    quality = _get_quality_level(project_root)
    state = read_state(project_root)
    active_spec = state.get("active_spec")

    # Always run mechanical checks
    mechanical_issues = _run_mechanical_checks(project_root)

    if mechanical_issues:
        issues_text = "\n".join(f"  {_R}-{_X} {i}" for i in mechanical_issues)
        if quality in ("high", "standard"):
            return {
                "decision": "block",
                "reason": f"{_R}TLM > Mechanical checks failed:{_X}\n{issues_text}\n\nFix these before committing.",
            }

    # LLM review (high and standard only)
    if quality == "relaxed":
        # Mechanical checks passed (or no blockers), allow
        parts = ["[TLM] COMPLIANCE CHECK before commit:",
                 "Tell the user: 'TLM > Running compliance check before commit.'"]
        if active_spec:
            parts.append(f"\nVerify changes against spec: {active_spec}")
        parts.append("\nEnsure all tests pass before committing.")
        return {"additionalContext": "\n".join(parts)}

    # Try server-side LLM review
    client = get_client()
    if not client:
        # No server connection — fall back to context injection
        return _compliance_context_fallback(project_root, active_spec)

    # Get staged diff
    diff = _get_staged_diff(project_root)
    if not diff:
        return {}  # No changes to review

    # Get spec content
    spec_content = ""
    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            spec_content = spec_path.read_text()
    else:
        specs = sorted((tlm_dir / "specs").glob("*.md"), reverse=True) if (tlm_dir / "specs").exists() else []
        if specs:
            spec_content = specs[0].read_text()

    # Get knowledge for context
    knowledge = ""
    try:
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        rules = db.list_rules()
        knowledge = "\n".join(r["rule_text"] for r in rules[:10])
        db.close()
    except Exception:
        pass

    # Call server review
    try:
        result = client.review_code(
            spec=spec_content or "(no spec available)",
            code=diff,
            files_changed=_get_changed_files(project_root),
            project_knowledge=knowledge,
        )
    except Exception:
        # Server unreachable — fall back to context injection
        return _compliance_context_fallback(project_root, active_spec)

    verdict = result.get("combined_verdict", "pass")
    models_used = result.get("models_used", [])
    reviews = result.get("reviews", [])

    # Collect all issues
    all_issues = []
    for review in reviews:
        for issue in review.get("issues", []):
            severity = issue.get("severity", "suggestion")
            desc = issue.get("description", "")
            fix = issue.get("fix", "")
            all_issues.append(f"[{severity}] {desc}" + (f" → {fix}" if fix else ""))

    if verdict == "block" and quality == "high":
        issues_text = "\n".join(f"  {_R}-{_X} {i}" for i in all_issues[:10])
        return {
            "decision": "block",
            "reason": (
                f"{_R}TLM > Code review BLOCKED commit{_X} {_D}(models: {', '.join(models_used)}){_X}\n\n"
                f"Issues found:\n{issues_text}\n\n"
                "Fix these issues before committing."
            ),
        }
    elif verdict in ("block", "warn"):
        issues_text = "\n".join(f"  {i}" for i in all_issues[:10])
        return {
            "additionalContext": (
                f"[TLM] Code review warnings (models: {', '.join(models_used)}):\n{issues_text}\n\n"
                "These are warnings — commit will proceed, but consider fixing them."
            ),
        }

    return {}


def hook_deployment_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: ALWAYS blocks deploy/push-to-prod commands.

    Runs full review regardless of quality setting.
    """
    command = tool_input.get("command", "")

    if not _is_deploy_command(command):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    # Check if all tests pass
    test_issues = _run_mechanical_checks(project_root)
    if test_issues:
        issues_text = "\n".join(f"  {_R}-{_X} {i}" for i in test_issues)
        return {
            "decision": "block",
            "reason": (
                f"{_R}TLM > DEPLOYMENT BLOCKED{_X} — mechanical checks failed:\n"
                f"{issues_text}\n\n"
                "All checks must pass before deploying."
            ),
        }

    # Always require review for deployments
    return {
        "decision": "block",
        "reason": (
            f"{_Y}TLM > DEPLOYMENT GATE{_X} — Run {_B}tlm check{_X} before deploying.\n"
            "All quality gates must pass before deployment to any environment."
        ),
    }


def hook_stop(project_root: str, transcript_path: str = "") -> dict:
    """Stop hook: session learning + summary when Claude session ends.

    Reads session transcript and sends summary to server for pattern detection.
    """
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    # Check if session learning is enabled
    config_file = tlm_dir / "config.json"
    try:
        config = json.loads(config_file.read_text())
        if not config.get("session_learning", True):
            return {}
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        pass

    # Build session summary from captured prompts
    prompts_file = tlm_dir / "session_prompts.jsonl"
    if not prompts_file.exists():
        return {}

    try:
        from tlm.session_learner import build_session_summary, analyze_session
        summary = build_session_summary(str(tlm_dir), transcript_path)
        if not summary:
            return {}

        # Send to server for analysis
        client = get_client()
        if client:
            project_id = _get_project_id(project_root)
            knowledge = ""
            try:
                db = KnowledgeDB(str(tlm_dir))
                db.init_db()
                rules = db.list_rules()
                knowledge = "\n".join(r["rule_text"] for r in rules[:10])
                db.close()
            except Exception:
                pass

            try:
                result = client.learn_session(summary, project_knowledge=knowledge)
                inferred = result.get("inferred_rules", [])
                if inferred:
                    # Write to knowledge.db
                    db = KnowledgeDB(str(tlm_dir))
                    db.init_db()
                    for rule in inferred:
                        db.add_rule(
                            rule.get("rule_text", ""),
                            source="learned_from_session",
                            tags=rule.get("tags", []),
                        )
                    db.close()
                    prompts_file.unlink(missing_ok=True)
                    return {
                        "additionalContext": (
                            f"TLM > Learned {len(inferred)} new pattern(s) from this session. "
                            "Review with `tlm rules`."
                        ),
                    }
            except Exception:
                pass

        # Clean up session prompts
        prompts_file.unlink(missing_ok=True)

    except ImportError:
        pass  # session_learner not yet available

    return {}


# ─── Internal helpers ─────────────────────────────────────────

def _get_interview_guidance(project_root: str, activity_type: str = None) -> str:
    """Get server-sourced interview guidance, with session caching.

    Returns formatted guidance string, or empty string if unavailable.
    """
    root = Path(project_root)
    tlm_dir = root / ".tlm"
    cache_file = tlm_dir / "cache" / "interview_guide.json"

    # Check session cache first
    if cache_file.exists():
        try:
            cached = json.loads(cache_file.read_text())
            guide = cached.get("guide", {})
            return _format_interview_guide(guide)
        except (json.JSONDecodeError, OSError):
            pass

    # Fetch from server
    client = get_client()
    if not client:
        return _minimal_interview_fallback()

    # Gather project context
    project_profile = ""
    profile_file = tlm_dir / "profile.md"
    if profile_file.exists():
        try:
            project_profile = profile_file.read_text()
        except OSError:
            pass

    knowledge = ""
    try:
        db = KnowledgeDB(str(tlm_dir))
        db.init_db()
        rules = db.list_rules()
        knowledge = "\n".join(r["rule_text"] for r in rules[:10])
        db.close()
    except Exception:
        pass

    gaps = ""
    gaps_file = tlm_dir / "gaps.json"
    if gaps_file.exists():
        try:
            gaps_data = json.loads(gaps_file.read_text())
            active = [g for g in gaps_data.get("gaps", []) if not g.get("dismissed")]
            gaps = "\n".join(f"- {g['description']}" for g in active)
        except (json.JSONDecodeError, OSError):
            pass

    lessons = ""
    lessons_dir = tlm_dir / "lessons"
    if lessons_dir.exists():
        synthesis_files = sorted(lessons_dir.glob("*-synthesis.json"), reverse=True)
        if synthesis_files:
            try:
                synthesis = json.loads(synthesis_files[0].read_text())
                improvements = synthesis.get("interview_improvements", [])
                lessons = "\n".join(f"- {imp}" for imp in improvements[:5])
            except (json.JSONDecodeError, OSError):
                pass

    try:
        result = client.get_interview_guide(
            project_profile=project_profile,
            feature_type=activity_type or "",
            project_knowledge=knowledge,
            project_gaps=gaps,
            project_lessons=lessons,
        )
        guide = result.get("guide", {})

        # Cache for this session
        cache_file.parent.mkdir(parents=True, exist_ok=True)
        cache_file.write_text(json.dumps({"guide": guide}))

        return _format_interview_guide(guide)
    except (TLMConnectionError, Exception):
        return _minimal_interview_fallback()


def _format_interview_guide(guide: dict) -> str:
    """Format a guide dict into a concise string for additionalContext."""
    parts = []
    protocol = guide.get("interview_protocol", {})

    # Structure
    structure = protocol.get("structure", [])
    if structure:
        parts.append("Interview phases:")
        for phase in structure:
            tips = phase.get("domain_tips", [])
            tips_str = f" Tips: {'; '.join(tips)}" if tips else ""
            parts.append(
                f"  - {phase.get('phase', '?')} ({phase.get('questions_range', '?')} Qs): "
                f"{phase.get('focus', '')}{tips_str}"
            )

    # Depth
    depth = protocol.get("depth_calibration", "")
    if depth:
        parts.append(f"Depth: {depth}")

    # Must-ask
    must_ask = protocol.get("must_ask", [])
    if must_ask:
        parts.append("Must-ask questions:")
        for q in must_ask[:5]:
            parts.append(f"  - {q}")

    # Rules
    rules = guide.get("rules", [])
    if rules:
        parts.append("Rules: " + " | ".join(rules))

    # Relevant gaps
    gaps = guide.get("relevant_gaps", [])
    if gaps:
        parts.append("Relevant project gaps to mention: " + "; ".join(gaps))

    return "\n".join(parts)


def _track_test_write(project_root: str, file_path: str):
    """Track test file writes for TDD enforcement."""
    tlm_dir = Path(project_root) / ".tlm"
    cache_dir = tlm_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    tracking_file = cache_dir / "session_tests.json"

    tracking = {"test_files_written": [], "session_start": datetime.datetime.now().isoformat()}
    if tracking_file.exists():
        try:
            tracking = json.loads(tracking_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    files = tracking.get("test_files_written", [])
    if file_path not in files:
        files.append(file_path)
        tracking["test_files_written"] = files
        tracking_file.write_text(json.dumps(tracking))


def _check_tdd_compliance(project_root: str, source_file_path: str) -> dict | None:
    """Check if TDD is being followed — tests must be written before source code.

    Returns a block dict if tests haven't been written, None if OK.
    """
    tlm_dir = Path(project_root) / ".tlm"
    tracking_file = tlm_dir / "cache" / "session_tests.json"

    # Check if any test files have been written this session
    test_files = []
    if tracking_file.exists():
        try:
            tracking = json.loads(tracking_file.read_text())
            test_files = tracking.get("test_files_written", [])
        except (json.JSONDecodeError, OSError):
            pass

    if not test_files:
        # No test files written yet — BLOCK
        return {
            "decision": "block",
            "reason": (
                f"{_Y}TLM > Write the test first. TDD is non-negotiable.{_X}\n"
                "You must write and run failing tests before writing implementation code.\n"
                "Write your test file first, then you can write the source code."
            ),
        }

    # Tests exist but check if any match this source module (warn if not)
    source_stem = Path(source_file_path).stem.lower()
    # Strip common prefixes/suffixes to get base name
    base_name = source_stem
    for prefix in ("test_", "tests_"):
        if base_name.startswith(prefix):
            base_name = base_name[len(prefix):]

    has_matching_test = False
    for test_path in test_files:
        test_stem = Path(test_path).stem.lower()
        # Check various patterns: test_foo matches foo, foo_test matches foo
        test_base = test_stem
        for prefix in ("test_", "tests_"):
            if test_base.startswith(prefix):
                test_base = test_base[len(prefix):]
        for suffix in ("_test", "_tests", "_spec"):
            if test_base.endswith(suffix):
                test_base = test_base[:len(test_base) - len(suffix)]

        if base_name == test_base or source_stem in test_stem or test_base in source_stem:
            has_matching_test = True
            break

    if not has_matching_test:
        # Tests exist but none match — warn, don't block
        return {
            "additionalContext": (
                f"[TLM] TDD: Tests have been written this session ({len(test_files)} test files), "
                f"but none appear to specifically test '{Path(source_file_path).name}'. "
                "Make sure you have tests covering this module."
            ),
        }

    return None  # All good


def _minimal_interview_fallback() -> str:
    """Minimal interview guidance when server is unreachable."""
    return (
        "Interview phases: scope (1-3 Qs), domain depth (3-8 Qs), failure modes (2-4 Qs), "
        "operations (1-3 Qs), testing (1-2 Qs), safety (1-2 Qs).\n"
        "Rules: Ask ONE question at a time. Chase every ambiguity. "
        "When complete: generate spec to .tlm/specs/, update knowledge.md."
    )


def _capture_prompt(project_root: str, prompt_text: str):
    """Append user prompt to session_prompts.jsonl."""
    tlm_dir = Path(project_root) / ".tlm"
    if not tlm_dir.exists():
        return

    # Check if session learning is enabled
    config_file = tlm_dir / "config.json"
    try:
        config = json.loads(config_file.read_text())
        if not config.get("session_learning", True):
            return
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        pass

    prompts_file = tlm_dir / "session_prompts.jsonl"
    entry = json.dumps({
        "timestamp": datetime.datetime.now().isoformat(),
        "prompt": prompt_text[:500],  # Cap at 500 chars
    })
    with open(prompts_file, "a") as f:
        f.write(entry + "\n")


def _is_test_file(file_path: str, project_root: str = None) -> bool:
    """Check if a file path is a test file.

    Uses test_patterns from enforcement.json if available (LLM-derived,
    language-agnostic). Falls back to basic heuristics.
    """
    if project_root:
        patterns = _get_test_patterns(project_root)
        if patterns:
            return _match_test_patterns(file_path, patterns)

    return _is_test_file_heuristic(file_path)


def _get_test_patterns(project_root: str) -> dict | None:
    """Read test_patterns from enforcement.json."""
    enforcement_file = Path(project_root) / ".tlm" / "enforcement.json"
    try:
        config = json.loads(enforcement_file.read_text())
        return config.get("test_patterns")
    except (json.JSONDecodeError, OSError, FileNotFoundError):
        return None


def _match_test_patterns(file_path: str, patterns: dict) -> bool:
    """Match file against LLM-derived test patterns."""
    import fnmatch
    path_lower = file_path.lower()

    for test_dir in patterns.get("directories", []):
        dir_segment = f"/{test_dir.strip('/')}/"
        if dir_segment.lower() in path_lower:
            return True

    filename = Path(file_path).name.lower()
    for glob_pattern in patterns.get("file_globs", []):
        if fnmatch.fnmatch(filename, glob_pattern.lower()):
            return True

    return False


def _is_test_file_heuristic(file_path: str) -> bool:
    """Fallback: basic path-segment heuristics."""
    parts = Path(file_path).parts
    if not parts:
        return False
    filename = parts[-1].lower()

    if (filename.startswith("test_") or filename.startswith("test.")
            or "_test." in filename or ".test." in filename
            or "_spec." in filename or ".spec." in filename):
        return True

    test_dirs = {"tests", "test", "spec", "specs", "__tests__"}
    return any(part.lower() in test_dirs for part in parts[:-1])


def _is_git_commit(command: str) -> bool:
    """Check if a shell command is a git commit."""
    return bool(re.search(r'\bgit\s+commit\b', command))


def _is_deploy_command(command: str) -> bool:
    """Check if a shell command is a deployment command."""
    deploy_patterns = [
        r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
        r'\b(eb|firebase|fly|sam|serverless)\s+deploy\b',
        r'\bkubectl\s+apply\b.*\b(prod|production)\b',
        r'\bdocker\s+push\b',
        r'\bhelm\s+(install|upgrade)\b',
    ]
    for pattern in deploy_patterns:
        if re.search(pattern, command, re.IGNORECASE):
            return True
    return False


def _run_mechanical_checks(project_root: str) -> list[str]:
    """Run enforcement checks. Returns list of failure messages."""
    try:
        from tlm.enforcer import Enforcer
        enforcer = Enforcer(project_root)
        report = enforcer.run_checks("pre_commit")
        if not report.passed:
            return [f"{b.name}: {b.message}" for b in report.blockers]
    except Exception:
        pass
    return []


def _get_staged_diff(project_root: str) -> str:
    """Get git staged diff."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        if result.stdout.strip():
            return result.stdout[:50000]  # Cap at 50KB
        # Fall back to unstaged diff
        result = subprocess.run(
            ["git", "diff"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        return result.stdout[:50000]
    except Exception:
        return ""


def _get_changed_files(project_root: str) -> list[str]:
    """Get list of changed files from git."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        files = result.stdout.strip().split("\n")
        if not files or files == [""]:
            result = subprocess.run(
                ["git", "diff", "--name-only"],
                capture_output=True, text=True, cwd=project_root, timeout=10,
            )
            files = result.stdout.strip().split("\n")
        return [f for f in files if f]
    except Exception:
        return []


def _compliance_context_fallback(project_root: str, active_spec: str | None) -> dict:
    """Fall back to context injection when server is unreachable."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    parts = ["[TLM] COMPLIANCE CHECK before commit:",
             "Tell the user: 'TLM > Running compliance check before commit.'"]

    if active_spec:
        spec_path = root / active_spec
        if spec_path.exists():
            parts.append(f"\n1. Verify changes against spec: {active_spec}")
            parts.append("   - Are ALL spec items implemented?")
            parts.append("   - Are ALL specified test cases written and passing?")
            parts.append("   - Are there changes NOT covered by the spec?")

    enforcement_file = tlm_dir / "enforcement.json"
    if enforcement_file.exists():
        try:
            config = json.loads(enforcement_file.read_text())
            if config.get("approved"):
                checks = config.get("checks", [])
                pre_commit_checks = [c for c in checks if c.get("when") == "pre_commit"]
                if pre_commit_checks:
                    parts.append(f"\n2. Run ALL pre-commit enforcement checks ({len(pre_commit_checks)} configured):")
                    for check in pre_commit_checks:
                        blocker = "BLOCKER" if check.get("blocker") else "warning"
                        parts.append(f"   - [{blocker}] {check.get('name', '?')}: `{check.get('command', '?')}`")
                    parts.append("\n   Run these checks and verify they pass before committing.")
        except (json.JSONDecodeError, OSError):
            pass

    if len(parts) == 2:
        parts.append("Ensure all tests pass before committing.")

    parts.append("\nIf you have NOT verified compliance, pause and check now.")
    return {"additionalContext": "\n".join(parts)}
