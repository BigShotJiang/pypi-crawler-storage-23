"""
TLM Cache — Local cache manager for server sync data.

Caches data from GET /sync endpoint to .tlm/cache.json.
Provides fallback to raw .tlm/ files when cache is empty.

Usage:
    from tlm.cache import TLMCache

    cache = TLMCache("/path/to/.tlm")
    cache.write_sync(sync_data)
    knowledge = cache.get_knowledge_with_fallback()
"""

import json
import datetime
from pathlib import Path
from typing import Optional


# Default cache TTL: 1 hour
DEFAULT_TTL_SECONDS = 3600


class TLMCache:
    """Local cache for server sync data."""

    def __init__(self, tlm_dir: str, ttl_seconds: int = DEFAULT_TTL_SECONDS):
        self.tlm_dir = Path(tlm_dir)
        self.cache_file = self.tlm_dir / "cache.json"
        self.ttl_seconds = ttl_seconds

    # ─── Core Read/Write ──────────────────────────

    def write_sync(self, data: dict):
        """Write sync data to cache with timestamp."""
        cache_data = {
            "synced_at": datetime.datetime.now().isoformat(),
            "data": data,
        }
        self.cache_file.write_text(json.dumps(cache_data, indent=2))

    def read_sync(self) -> Optional[dict]:
        """Read cached sync data. Returns None if cache is empty or corrupted."""
        if not self.cache_file.exists():
            return None
        try:
            cache_data = json.loads(self.cache_file.read_text())
            if "data" not in cache_data:
                return None
            return cache_data["data"]
        except (json.JSONDecodeError, OSError, KeyError):
            return None

    def is_stale(self) -> bool:
        """Check if cache is stale (older than TTL or missing)."""
        if not self.cache_file.exists():
            return True
        try:
            cache_data = json.loads(self.cache_file.read_text())
            synced_at = datetime.datetime.fromisoformat(cache_data["synced_at"])
            age = (datetime.datetime.now() - synced_at).total_seconds()
            return age > self.ttl_seconds
        except (json.JSONDecodeError, OSError, KeyError, ValueError):
            return True

    def clear(self):
        """Clear the cache file."""
        if self.cache_file.exists():
            self.cache_file.unlink()

    # ─── Field Accessors (from cache) ─────────────

    def _get_field(self, field: str):
        """Get a specific field from cached data."""
        data = self.read_sync()
        if data is None:
            return None
        return data.get(field)

    def get_knowledge(self) -> Optional[str]:
        return self._get_field("knowledge")

    def get_profile(self) -> Optional[str]:
        return self._get_field("profile")

    def get_enforcement_config(self) -> Optional[dict]:
        return self._get_field("enforcement_config")

    def get_latest_synthesis(self) -> Optional[dict]:
        return self._get_field("latest_synthesis")

    def get_specs(self) -> Optional[list]:
        return self._get_field("specs")

    def get_project_lessons(self) -> Optional[str]:
        return self._get_field("project_lessons")

    # ─── Fallback Accessors (cache → raw files) ───

    def get_knowledge_with_fallback(self) -> Optional[str]:
        """Get knowledge from cache, falling back to .tlm/knowledge.md."""
        cached = self.get_knowledge()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "knowledge.md"
        if raw_file.exists():
            return raw_file.read_text()
        return None

    def get_profile_with_fallback(self) -> Optional[str]:
        """Get profile from cache, falling back to .tlm/profile.md."""
        cached = self.get_profile()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "profile.md"
        if raw_file.exists():
            return raw_file.read_text()
        return None

    def get_enforcement_config_with_fallback(self) -> Optional[dict]:
        """Get enforcement config from cache, falling back to .tlm/enforcement.json."""
        cached = self.get_enforcement_config()
        if cached is not None:
            return cached
        raw_file = self.tlm_dir / "enforcement.json"
        if raw_file.exists():
            try:
                return json.loads(raw_file.read_text())
            except (json.JSONDecodeError, OSError):
                pass
        return None
