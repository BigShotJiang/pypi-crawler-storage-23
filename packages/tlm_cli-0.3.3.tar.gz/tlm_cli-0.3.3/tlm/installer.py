"""
TLM Installer — Install/uninstall TLM into a project.

Generates:
  - CLAUDE.md with TLM rules (from templates in prompts/rules.py)
  - .claude/settings.json with Claude Code hooks
  - .claude/hooks/tlm-* wrapper scripts
  - .claude/rules/tlm-*.md rule files
  - Git post-commit hook for learning
  - .tlm/state.json initialization
"""

import json
import os
import stat
from pathlib import Path

from tlm.state import write_state, DEFAULT_STATE
from tlm.prompts.rules import build_claude_md, build_rule_files


# TLM marker used to identify TLM content in CLAUDE.md
TLM_MARKER_START = "<!-- TLM:START -->"
TLM_MARKER_END = "<!-- TLM:END -->"


def _is_tlm_hook(entry: dict) -> bool:
    """Return True if a hook entry belongs to TLM.

    Handles both dict-format entries (with nested hooks list)
    and flat list-format entries (with command string).
    """
    if entry.get("_tlm"):
        return True
    # Check command field (flat list format)
    cmd = entry.get("command", "")
    if "tlm _hook" in cmd or "/tlm-" in cmd:
        return True
    # Check nested hooks list (dict format)
    for h in entry.get("hooks", []):
        cmd = h.get("command", "")
        if "tlm _hook" in cmd or "/tlm-" in cmd:
            return True
    return False


def _extract_non_tlm_hooks(settings: dict) -> dict:
    """Extract non-TLM hooks from settings, returns dict format.

    Handles both formats:
    - Dict format: {"hooks": {"EventName": [entries...]}}
    - List format: {"hooks": [{"event": "X", "command": "..."}]}
    """
    hooks = settings.get("hooks", {})
    result = {}

    if isinstance(hooks, dict):
        for event, entries in hooks.items():
            non_tlm = [e for e in entries if not _is_tlm_hook(e)]
            if non_tlm:
                result[event] = non_tlm
    elif isinstance(hooks, list):
        for entry in hooks:
            if _is_tlm_hook(entry):
                continue
            # Determine event name
            event = entry.get("event") or entry.get("type")
            if not event:
                matcher = entry.get("matcher", {})
                if isinstance(matcher, dict):
                    event = matcher.get("event", "Unknown")
                else:
                    event = "Unknown"
            # Convert flat entry to dict format
            if "hooks" in entry:
                converted = {k: v for k, v in entry.items()
                             if k not in ("event", "type")}
            else:
                converted = {
                    "hooks": [{"type": "command",
                               "command": entry.get("command", "")}],
                }
                # Preserve extra keys (e.g. _custom)
                for k, v in entry.items():
                    if k not in ("event", "type", "command"):
                        converted[k] = v
                # Convert tool_name to matcher
                if "tool_name" in entry:
                    converted["matcher"] = converted.pop("tool_name")
            result.setdefault(event, []).append(converted)

    return result


class Installer:
    """Installs and uninstalls TLM into a project."""

    def __init__(self, project_root: str):
        self.root = Path(project_root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.claude_dir = self.root / ".claude"
        self.hooks_dir = self.claude_dir / "hooks"
        self.rules_dir = self.claude_dir / "rules"
        self.settings_file = self.claude_dir / "settings.json"
        self.claude_md = self.root / "CLAUDE.md"

    def install(self):
        """Full TLM installation.

        1. Generate CLAUDE.md with TLM rules
        2. Create/merge .claude/settings.json with hooks
        3. Create hook wrapper scripts
        4. Create rule files
        5. Install git post-commit hook
        6. Initialize state
        """
        enforcement_config = self._load_enforcement_config()

        self._generate_claude_md(enforcement_config)
        self._setup_hooks(enforcement_config)
        self._create_rule_files(enforcement_config)
        self._install_git_hooks()
        self._initialize_state()

    def uninstall(self):
        """Remove TLM from project.

        Removes: TLM section from CLAUDE.md, TLM hooks from settings,
                 hook scripts, rule files, git hooks.
        Keeps: .tlm/ data directory.
        """
        self._remove_claude_md_section()
        self._remove_tlm_hooks()
        self._remove_hook_scripts()
        self._remove_rule_files()
        self._remove_git_hooks()

    # ─── CLAUDE.md ────────────────────────────────────────────

    def _generate_claude_md(self, enforcement_config: dict):
        """Generate or update CLAUDE.md with TLM rules."""
        tlm_content = (
            f"{TLM_MARKER_START}\n"
            f"{build_claude_md(enforcement_config)}\n"
            f"{TLM_MARKER_END}"
        )

        if self.claude_md.exists():
            existing = self.claude_md.read_text()

            # Replace existing TLM section
            if TLM_MARKER_START in existing:
                start = existing.index(TLM_MARKER_START)
                end = existing.index(TLM_MARKER_END) + len(TLM_MARKER_END)
                new_content = existing[:start] + tlm_content + existing[end:]
            else:
                # Also handle old-style marker
                if "# TLM Engineering Rules" in existing:
                    marker = "# TLM Engineering Rules"
                    new_content = existing[:existing.index(marker)].rstrip() + "\n\n" + tlm_content
                else:
                    new_content = existing.rstrip() + "\n\n" + tlm_content
            self.claude_md.write_text(new_content + "\n")
        else:
            self.claude_md.write_text(tlm_content + "\n")

    def _remove_claude_md_section(self):
        """Remove TLM section from CLAUDE.md, keep the rest."""
        if not self.claude_md.exists():
            return

        content = self.claude_md.read_text()

        if TLM_MARKER_START in content and TLM_MARKER_END in content:
            start = content.index(TLM_MARKER_START)
            end = content.index(TLM_MARKER_END) + len(TLM_MARKER_END)
            remaining = (content[:start] + content[end:]).strip()
            if remaining:
                self.claude_md.write_text(remaining + "\n")
            else:
                self.claude_md.unlink()
        elif "# TLM" in content:
            # Old-style: remove from first TLM header onwards
            idx = content.index("# TLM")
            remaining = content[:idx].strip()
            if remaining:
                self.claude_md.write_text(remaining + "\n")
            else:
                self.claude_md.unlink()

    # ─── Settings & Hooks ─────────────────────────────────────

    def _setup_hooks(self, enforcement_config: dict):
        """Create hook scripts and merge into settings.json."""
        self.claude_dir.mkdir(exist_ok=True)
        self.hooks_dir.mkdir(exist_ok=True)

        # Create wrapper scripts
        scripts = self._create_hook_scripts()

        # Merge into settings.json
        self._merge_settings(scripts)

    def _create_hook_scripts(self) -> dict:
        """Create thin wrapper scripts in .claude/hooks/.

        Returns dict mapping script name to hook event type.
        """
        scripts = {
            "tlm-session": {
                "event": "SessionStart",
                "content": _HOOK_SCRIPT_SESSION,
            },
            "tlm-prompt": {
                "event": "UserPromptSubmit",
                "content": _HOOK_SCRIPT_PROMPT,
            },
            "tlm-guard": {
                "event": "PreToolUse",
                "content": _HOOK_SCRIPT_GUARD,
                "tool_name": "Write|Edit",
            },
            "tlm-compliance": {
                "event": "PreToolUse",
                "content": _HOOK_SCRIPT_COMPLIANCE,
                "tool_name": "Bash",
            },
            "tlm-deployment": {
                "event": "PreToolUse",
                "content": _HOOK_SCRIPT_DEPLOYMENT,
                "tool_name": "Bash",
            },
            "tlm-stop": {
                "event": "Stop",
                "content": _HOOK_SCRIPT_STOP,
            },
        }

        result = {}
        for name, info in scripts.items():
            script_path = self.hooks_dir / name
            script_path.write_text(info["content"])
            script_path.chmod(script_path.stat().st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
            result[name] = info

        return result

    def _merge_settings(self, scripts: dict):
        """Merge TLM hooks into .claude/settings.json.

        Reads existing hooks in either dict or list format,
        removes old TLM hooks, adds new TLM hooks, writes dict format.
        """
        settings = {}
        if self.settings_file.exists():
            try:
                settings = json.loads(self.settings_file.read_text())
            except json.JSONDecodeError:
                settings = {}

        # Get existing non-TLM hooks in dict format
        existing_hooks = _extract_non_tlm_hooks(settings)

        # Build TLM hooks in dict format
        tlm_hooks = {}
        for name, info in scripts.items():
            event = info["event"]
            entry = {
                "_tlm": True,
                "hooks": [{"type": "command",
                           "command": str(self.hooks_dir / name)}],
            }
            if "tool_name" in info:
                entry["matcher"] = info["tool_name"]
            tlm_hooks.setdefault(event, []).append(entry)

        # Merge: existing non-TLM + TLM
        merged = {}
        all_events = set(list(existing_hooks.keys()) + list(tlm_hooks.keys()))
        for event in sorted(all_events):
            merged[event] = (existing_hooks.get(event, [])
                             + tlm_hooks.get(event, []))

        settings["hooks"] = merged
        self.settings_file.write_text(json.dumps(settings, indent=2))

    def _remove_tlm_hooks(self):
        """Remove TLM hooks from settings.json.

        Handles both dict and list format input, writes dict format.
        """
        if not self.settings_file.exists():
            return

        try:
            settings = json.loads(self.settings_file.read_text())
        except json.JSONDecodeError:
            return

        settings["hooks"] = _extract_non_tlm_hooks(settings)
        self.settings_file.write_text(json.dumps(settings, indent=2))

    def _remove_hook_scripts(self):
        """Remove TLM hook wrapper scripts."""
        if not self.hooks_dir.exists():
            return
        for script in self.hooks_dir.glob("tlm-*"):
            script.unlink()

    # ─── Rule Files ───────────────────────────────────────────

    def _create_rule_files(self, enforcement_config: dict):
        """Create .claude/rules/tlm-*.md files."""
        self.rules_dir.mkdir(parents=True, exist_ok=True)
        rules = build_rule_files(enforcement_config)
        for filename, content in rules.items():
            (self.rules_dir / filename).write_text(content + "\n")

    def _remove_rule_files(self):
        """Remove TLM rule files."""
        if not self.rules_dir.exists():
            return
        for rule_file in self.rules_dir.glob("tlm-*.md"):
            rule_file.unlink()

    # ─── Git Hooks ────────────────────────────────────────────

    def _install_git_hooks(self):
        """Install git post-commit hook for learning."""
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return

        hooks_dir = git_dir / "hooks"
        hooks_dir.mkdir(exist_ok=True)

        hook_path = hooks_dir / "post-commit"
        if hook_path.exists():
            existing = hook_path.read_text()
            if "TLM" in existing:
                return  # Already installed
            # Backup existing
            backup = hooks_dir / "post-commit.backup"
            hook_path.rename(backup)

        hook_path.write_text(_GIT_POST_COMMIT_HOOK)
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IEXEC)

    def _remove_git_hooks(self):
        """Remove TLM git hooks, restore backups."""
        git_dir = self.root / ".git"
        if not git_dir.exists():
            return

        hooks_dir = git_dir / "hooks"
        for hook_name in ("post-commit",):
            hook_path = hooks_dir / hook_name
            if hook_path.exists() and "TLM" in hook_path.read_text():
                hook_path.unlink()
                backup = hooks_dir / f"{hook_name}.backup"
                if backup.exists():
                    backup.rename(hook_path)

    # ─── State ────────────────────────────────────────────────

    def _initialize_state(self):
        """Initialize .tlm/state.json."""
        write_state(self.root, dict(DEFAULT_STATE))

    # ─── Internal ─────────────────────────────────────────────

    def _load_enforcement_config(self) -> dict:
        """Load the approved enforcement config."""
        config_file = self.tlm_dir / "enforcement.json"
        if not config_file.exists():
            return {}
        try:
            return json.loads(config_file.read_text())
        except json.JSONDecodeError:
            return {}


# =============================================================================
# Hook Wrapper Scripts
# Thin shell scripts that call `tlm _hook <name>`.
# =============================================================================

_HOOK_SCRIPT_SESSION = """#!/bin/sh
# TLM SessionStart Hook — loads project context into Claude Code
tlm _hook session 2>/dev/null || true
"""

_HOOK_SCRIPT_PROMPT = """#!/bin/sh
# TLM UserPromptSubmit Hook — reminds Claude of TLM rules
tlm _hook prompt 2>/dev/null || true
"""

_HOOK_SCRIPT_GUARD = """#!/bin/sh
# TLM PreToolUse Guard — TDD enforcement for Write/Edit
tlm _hook guard 2>/dev/null || true
"""

_HOOK_SCRIPT_COMPLIANCE = """#!/bin/sh
# TLM PreToolUse Compliance Gate — spec check before git commit
tlm _hook compliance 2>/dev/null || true
"""

_HOOK_SCRIPT_DEPLOYMENT = """#!/bin/sh
# TLM PreToolUse Deployment Gate — blocks deploy commands without review
tlm _hook deployment 2>/dev/null || true
"""

_HOOK_SCRIPT_STOP = """#!/bin/sh
# TLM Stop Hook — session learning when Claude session ends
tlm _hook stop 2>/dev/null || true
"""


# =============================================================================
# Git Hook Content
# =============================================================================

_GIT_POST_COMMIT_HOOK = """#!/bin/sh
# TLM Post-Commit Learner — analyzes commits in background
# This runs silently after every commit. Never blocks git.

if ! command -v tlm &> /dev/null; then
    exit 0
fi

if [ -z "$ANTHROPIC_API_KEY" ]; then
    exit 0
fi

if [ ! -d ".tlm" ]; then
    exit 0
fi

# Run analysis in background — never block the developer
nohup tlm _analyze-last-commit > /dev/null 2>&1 &
"""
