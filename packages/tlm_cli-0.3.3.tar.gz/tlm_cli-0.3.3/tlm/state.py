"""
TLM State Manager — Session state for .tlm/state.json.

Tracks the current phase of TLM activity:
  idle → tlm_active → implementation → deployment → idle

Used by hooks to inject appropriate context into Claude Code sessions.
"""

import json
import datetime
from pathlib import Path


VALID_PHASES = ("idle", "tlm_active", "implementation", "deployment")

VALID_SPEC_REVIEW_STATUSES = ("none", "pending", "approved", "rejected")

DEFAULT_STATE = {
    "phase": "idle",
    "activity_type": None,
    "active_spec": None,
    "spec_review_status": "none",
    "spec_review_gaps": [],
    "last_updated": None,
}


def read_state(project_root) -> dict:
    """Read .tlm/state.json. Returns DEFAULT_STATE if missing or invalid."""
    state_file = Path(project_root) / ".tlm" / "state.json"
    if not state_file.exists():
        return dict(DEFAULT_STATE)
    try:
        return json.loads(state_file.read_text())
    except (json.JSONDecodeError, OSError):
        return dict(DEFAULT_STATE)


def write_state(project_root, state: dict):
    """Write state to .tlm/state.json. Creates .tlm/ if needed."""
    tlm_dir = Path(project_root) / ".tlm"
    tlm_dir.mkdir(exist_ok=True)
    state_file = tlm_dir / "state.json"
    state_file.write_text(json.dumps(state, indent=2))


def transition_phase(project_root, new_phase: str, context: dict = None):
    """Transition to a new phase, optionally merging context fields.

    Args:
        project_root: Path to project root.
        new_phase: One of VALID_PHASES.
        context: Optional dict with keys like activity_type, active_spec.

    Raises:
        ValueError: If new_phase is not valid.
    """
    if new_phase not in VALID_PHASES:
        raise ValueError(f"Invalid phase: {new_phase}. Must be one of {VALID_PHASES}")

    state = read_state(project_root)
    state["phase"] = new_phase
    state["last_updated"] = datetime.datetime.now().isoformat()

    # Reset activity_type when going idle
    if new_phase == "idle":
        state["activity_type"] = None
        state["spec_review_status"] = "none"
        state["spec_review_gaps"] = []

    if context:
        for key in ("activity_type", "active_spec", "spec_review_status", "spec_review_gaps"):
            if key in context:
                state[key] = context[key]

    write_state(project_root, state)


def set_spec_review_status(project_root, status: str, gaps: list = None):
    """Update spec review status and optional gap list."""
    if status not in VALID_SPEC_REVIEW_STATUSES:
        raise ValueError(f"Invalid spec review status: {status}")

    state = read_state(project_root)
    state["spec_review_status"] = status
    if gaps is not None:
        state["spec_review_gaps"] = gaps
    state["last_updated"] = datetime.datetime.now().isoformat()
    write_state(project_root, state)


def set_active_spec(project_root, spec_path):
    """Set or clear the active spec path in state."""
    state = read_state(project_root)
    state["active_spec"] = spec_path
    state["last_updated"] = datetime.datetime.now().isoformat()
    write_state(project_root, state)
