"""
TLM API Client — HTTP client for TLM server.

All LLM intelligence lives on the server. This client is a thin HTTP wrapper
that sends requests and returns responses. No LLM code here.

Usage:
    from tlm.api_client import get_client, save_credentials

    # One-time auth
    save_credentials("tlm_sk_abc123")

    # Get client from saved credentials
    client = get_client()
    result = client.scan("proj_123", file_tree, samples)
"""

import json
from pathlib import Path
from typing import Optional

import httpx
from httpx import ConnectError as _HttpxConnectError
from httpx import TimeoutException as _HttpxTimeoutException


# ─── Exceptions ───────────────────────────────────────────────

class TLMAuthError(Exception):
    """Authentication failed (401/403)."""
    pass


class TLMCreditsError(Exception):
    """Credits exhausted (402)."""
    pass


class TLMProjectLimitError(Exception):
    """Project limit reached (403)."""
    pass


class TLMServerError(Exception):
    """Server returned an error (4xx/5xx)."""
    pass


class TLMConnectionError(Exception):
    """Cannot reach TLM server."""
    pass


# ─── Credential Management ───────────────────────────────────

DEFAULT_CREDENTIALS_DIR = str(Path.home() / ".tlm")
DEFAULT_BASE_URL = "http://65.109.65.78:8003"


def save_credentials(api_key: str, credentials_dir: str = DEFAULT_CREDENTIALS_DIR, base_url: str = None):
    """Save API key to ~/.tlm/credentials.json."""
    cred_dir = Path(credentials_dir)
    cred_dir.mkdir(parents=True, exist_ok=True)
    cred_file = cred_dir / "credentials.json"

    # Preserve existing fields
    existing = {}
    if cred_file.exists():
        try:
            existing = json.loads(cred_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    existing["api_key"] = api_key
    if base_url:
        existing["base_url"] = base_url

    cred_file.write_text(json.dumps(existing, indent=2))


def load_credentials(credentials_dir: str = DEFAULT_CREDENTIALS_DIR) -> Optional[str]:
    """Load API key from ~/.tlm/credentials.json. Returns None if not found."""
    cred_file = Path(credentials_dir) / "credentials.json"
    if not cred_file.exists():
        return None
    try:
        data = json.loads(cred_file.read_text())
        return data.get("api_key")
    except (json.JSONDecodeError, OSError, KeyError):
        return None


def _load_base_url(credentials_dir: str = DEFAULT_CREDENTIALS_DIR) -> str:
    """Load base URL from credentials or use default."""
    cred_file = Path(credentials_dir) / "credentials.json"
    if cred_file.exists():
        try:
            data = json.loads(cred_file.read_text())
            return data.get("base_url", DEFAULT_BASE_URL)
        except (json.JSONDecodeError, OSError):
            pass
    return DEFAULT_BASE_URL


def get_client(credentials_dir: str = DEFAULT_CREDENTIALS_DIR) -> Optional["TLMClient"]:
    """Get a TLMClient from saved credentials. Returns None if no credentials."""
    api_key = load_credentials(credentials_dir)
    if not api_key:
        return None
    base_url = _load_base_url(credentials_dir)
    return TLMClient(api_key=api_key, base_url=base_url)


# ─── TLM Client ──────────────────────────────────────────────

class TLMClient:
    """HTTP client for TLM server. All methods are synchronous."""

    def __init__(self, api_key: str, base_url: str = DEFAULT_BASE_URL):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _url(self, path: str) -> str:
        return f"{self.base_url}/api/v1{path}"

    def _url_v2(self, path: str) -> str:
        return f"{self.base_url}/api/v2{path}"

    def _post_v2(self, path: str, data: dict, timeout: float = 120.0) -> dict:
        try:
            resp = httpx.post(self._url_v2(path), json=data, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _handle_response(self, resp) -> dict:
        """Handle response, raising appropriate exceptions."""
        if resp.status_code == 402:
            detail = {}
            try:
                detail = resp.json().get("detail", {})
            except Exception:
                pass
            raise TLMCreditsError(detail)

        if resp.status_code == 403:
            detail = {}
            try:
                detail = resp.json().get("detail", {})
            except Exception:
                detail = resp.text
            # Check if it's a project limit error vs auth error
            if isinstance(detail, dict) and detail.get("error") == "project_limit_reached":
                raise TLMProjectLimitError(detail)
            raise TLMAuthError(f"Authentication failed: {detail}")

        if resp.status_code == 401:
            detail = ""
            try:
                detail = resp.json().get("detail", "")
            except Exception:
                detail = resp.text
            raise TLMAuthError(f"Authentication failed: {detail}")

        if resp.status_code >= 400:
            detail = ""
            try:
                detail = resp.json().get("detail", "")
            except Exception:
                detail = resp.text
            raise TLMServerError(f"Server error ({resp.status_code}): {detail}")

        return resp.json()

    def _post(self, path: str, data: dict, timeout: float = 60.0) -> dict:
        try:
            resp = httpx.post(self._url(path), json=data, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _get(self, path: str, params: dict = None, timeout: float = 30.0) -> dict:
        try:
            resp = httpx.get(self._url(path), params=params, headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    def _delete(self, path: str, timeout: float = 30.0) -> dict:
        try:
            resp = httpx.delete(self._url(path), headers=self._headers(), timeout=timeout)
        except (_HttpxConnectError, _HttpxTimeoutException) as e:
            raise TLMConnectionError(f"Cannot reach TLM server: {e}")
        return self._handle_response(resp)

    # ─── Auth ─────────────────────────────────────

    def signup(self, email: str, password: str) -> dict:
        return self._post("/auth/signup", {"email": email, "password": password})

    def login(self, email: str, password: str) -> dict:
        return self._post("/auth/login", {"email": email, "password": password})

    def me(self) -> dict:
        return self._get("/auth/me")

    def exchange_firebase_token(self, firebase_token: str) -> dict:
        """Exchange a Firebase ID token for a TLM API key."""
        return self._post("/auth/firebase", {"firebase_token": firebase_token})

    # ─── Projects ─────────────────────────────────

    def create_project(self, name: str, fingerprint: str) -> dict:
        return self._post("/projects", {"name": name, "fingerprint": fingerprint})

    def list_projects(self) -> dict:
        return self._get("/projects")

    def delete_project(self, project_id: str) -> dict:
        return self._delete(f"/projects/{project_id}")

    # ─── Intelligence (LLM on server) ─────────────

    def scan(self, project_id: str, file_tree: str, samples: str, *, local_analysis: str = None) -> dict:
        payload = {
            "file_tree": file_tree,
            "samples": samples,
        }
        if local_analysis is not None:
            payload["local_analysis"] = local_analysis
        return self._post(f"/projects/{project_id}/scan", payload)

    def generate_config(self, project_id: str, profile: str, file_tree: str, samples: str) -> dict:
        return self._post(f"/projects/{project_id}/generate-config", {
            "profile": profile,
            "file_tree": file_tree,
            "samples": samples,
        })

    def update_config(self, project_id: str, current_config: dict, feedback: str, profile: str) -> dict:
        return self._post(f"/projects/{project_id}/update-config", {
            "current_config": current_config,
            "feedback": feedback,
            "profile": profile,
        })

    def approve_config(self, project_id: str, config: dict) -> dict:
        return self._post(f"/projects/{project_id}/approve-config", {
            "config": config,
        })

    def check_drift(self, project_id: str, config: dict, changed_files: dict, file_contents: dict) -> dict:
        return self._post(f"/projects/{project_id}/check-drift", {
            "config": config,
            "changed_files": changed_files,
            "file_contents": file_contents,
        })

    def compliance_check(self, project_id: str, spec: str, diff: str, profile: str, enforcement_config: str) -> dict:
        return self._post(f"/projects/{project_id}/compliance-check", {
            "spec": spec,
            "diff": diff,
            "profile": profile,
            "enforcement_config": enforcement_config,
        })

    # ─── Discovery ────────────────────────────────

    def discovery_start(self, project_id: str, feature_request: str) -> dict:
        return self._post(f"/projects/{project_id}/discovery/start", {
            "feature_request": feature_request,
        })

    def discovery_respond(self, project_id: str, session_id: str, user_input: str) -> dict:
        return self._post(f"/projects/{project_id}/discovery/{session_id}/respond", {
            "user_input": user_input,
        })

    def discovery_generate(self, project_id: str, session_id: str) -> dict:
        return self._post(f"/projects/{project_id}/discovery/{session_id}/generate", {})

    # ─── Learning ─────────────────────────────────

    def analyze_commit(self, project_id: str, commit: dict) -> dict:
        return self._post(f"/projects/{project_id}/analyze-commit", {
            "commit": commit,
        }, timeout=180.0)

    def synthesize(self, project_id: str, analyzed_commits: list) -> dict:
        return self._post(f"/projects/{project_id}/synthesize", {
            "analyzed_commits": analyzed_commits,
        }, timeout=180.0)

    def learning_status(self, project_id: str) -> dict:
        return self._get(f"/projects/{project_id}/learning-status")

    # ─── Usage ────────────────────────────────────

    def usage(self) -> dict:
        return self._get("/usage")

    # ─── Sync ─────────────────────────────────────

    def sync(self, project_id: str, timeout: float = 3.0) -> dict:
        return self._get(f"/projects/{project_id}/sync", timeout=timeout)

    # ─── v2: Review ──────────────────────────────

    def get_interview_guide(self, project_profile: str = "", feature_type: str = "",
                            project_knowledge: str = "", project_gaps: str = "",
                            project_lessons: str = "") -> dict:
        return self._post_v2("/review/interview-guide", {
            "project_profile": project_profile,
            "feature_type": feature_type,
            "project_knowledge": project_knowledge,
            "project_gaps": project_gaps,
            "project_lessons": project_lessons,
        })

    def review_spec(self, spec: str, project_knowledge: str = "", learned_rules: str = "",
                    quality_level: str = "standard", spec_type: str = "feature") -> dict:
        return self._post_v2("/review/spec", {
            "spec": spec,
            "project_knowledge": project_knowledge,
            "learned_rules": learned_rules,
            "quality_level": quality_level,
            "spec_type": spec_type,
        })

    def review_code(self, spec: str, code: str, files_changed: list = None,
                    project_knowledge: str = "", learned_rules: str = "") -> dict:
        return self._post_v2("/review/code", {
            "spec": spec,
            "code": code,
            "files_changed": files_changed or [],
            "project_knowledge": project_knowledge,
            "learned_rules": learned_rules,
        })

    # ─── v2: Embedding ───────────────────────────

    def embed(self, texts: list) -> dict:
        return self._post_v2("/embed", {"texts": texts})

    # ─── v2: Session Learning ────────────────────

    def learn_session(self, session_summary: dict, project_knowledge: str = "") -> dict:
        return self._post_v2("/learn/session", {
            "session_summary": session_summary,
            "project_knowledge": project_knowledge,
        })

    # ─── Error Reporting ─────────────────────────

    def report_error(self, project_id: str, error_type: str, error_detail: str, context: str = ""):
        """Fire-and-forget error report. Swallows all exceptions."""
        try:
            httpx.post(
                self._url(f"/projects/{project_id}/error-report"),
                json={
                    "error_type": error_type,
                    "error_detail": error_detail,
                    "context": context,
                },
                headers=self._headers(),
                timeout=3.0,
            )
        except Exception:
            pass
