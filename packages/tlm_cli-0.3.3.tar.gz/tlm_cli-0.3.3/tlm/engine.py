"""
TLM Engine

Orchestrates:
1. Project scanning (via TLM server API)
2. Enforcement config generation + interactive approval
3. Drift detection
4. Discovery interview
5. Spec + TDD instruction generation
6. Compliance checking
7. Knowledge management

All LLM calls go through the TLM server. No direct anthropic dependency.
"""

import os
import re
import json
import glob
import shutil
import subprocess
import datetime
import logging
from pathlib import Path
from tlm.enforcer import EnforcementConfig
from tlm.knowledge_db import KnowledgeDB

logger = logging.getLogger(__name__)


# ─── Project Manager ──────────────────────────────────────────

class Project:
    """Manages the .tlm/ directory."""

    def __init__(self, root: str = "."):
        self.root = Path(root).resolve()
        self.tlm_dir = self.root / ".tlm"
        self.specs_dir = self.tlm_dir / "specs"
        self.sessions_dir = self.tlm_dir / "sessions"
        self.knowledge_file = self.tlm_dir / "knowledge.md"
        self.profile_file = self.tlm_dir / "profile.md"
        self.config_file = self.tlm_dir / "config.json"
        self.claude_md = self.root / "CLAUDE.md"
        self.lessons_dir = self.tlm_dir / "lessons"
        self.commits_dir = self.tlm_dir / "commits"
        self.enforcement = EnforcementConfig(self.tlm_dir)
        self._knowledge_db = None

    @property
    def initialized(self) -> bool:
        return self.tlm_dir.exists()

    @property
    def knowledge_db(self) -> KnowledgeDB:
        """Lazy-loaded knowledge database."""
        if self._knowledge_db is None:
            self._knowledge_db = KnowledgeDB(str(self.tlm_dir))
        return self._knowledge_db

    def init(self):
        self.tlm_dir.mkdir(exist_ok=True)
        self.specs_dir.mkdir(exist_ok=True)
        self.sessions_dir.mkdir(exist_ok=True)
        self.lessons_dir.mkdir(exist_ok=True)
        self.commits_dir.mkdir(exist_ok=True)
        if not self.knowledge_file.exists():
            self.knowledge_file.write_text(
                f"# TLM Knowledge Base\n"
                f"_Initialized {datetime.date.today()}_\n\n"
            )
        if not self.config_file.exists():
            self.config_file.write_text(json.dumps({
                "project_name": self.root.name,
                "created": str(datetime.date.today()),
                "sessions_used": 0,
                "quality_control": "standard",
            }, indent=2))
        # Initialize knowledge.db
        self.knowledge_db.init_db()
        # Migrate flat files if knowledge.db is fresh
        if not self.knowledge_db.list_rules():
            imported = self.knowledge_db.migrate_from_flat_files()
            if any(imported.values()):
                return imported
        return None

    def get_profile(self) -> str:
        if self.profile_file.exists():
            return self.profile_file.read_text()
        return "(not scanned yet)"

    def save_profile(self, content: str):
        self.profile_file.write_text(content)

    def get_knowledge(self) -> str:
        if self.knowledge_file.exists():
            return self.knowledge_file.read_text()
        return "(empty)"

    def append_knowledge(self, content: str):
        if content.strip() and "nothing new" not in content.lower() and "no new knowledge" not in content.lower():
            with open(self.knowledge_file, "a") as f:
                f.write(f"\n---\n_Session: {datetime.datetime.now().isoformat()}_\n\n")
                f.write(content.strip() + "\n")

    def get_specs_summary(self) -> str:
        specs = []
        for f in sorted(self.specs_dir.glob("*.md")):
            lines = f.read_text().split("\n")
            title = next((l for l in lines if l.startswith("# ")), f.name)
            specs.append(f"- {f.name}: {title}")
        return "\n".join(specs) if specs else "(none)"

    def get_enforcement_summary(self) -> str:
        if not self.enforcement.exists:
            return "(no enforcement config)"
        config = self.enforcement.load()
        return json.dumps(config, indent=2)

    def save_spec(self, name: str, content: str) -> Path:
        slug = name.lower().replace(" ", "-")
        slug = "".join(c for c in slug if c.isalnum() or c == "-")[:50]
        path = self.specs_dir / f"{datetime.date.today()}-{slug}.md"
        path.write_text(content)
        return path

    def save_claude_md(self, content: str) -> Path:
        if self.claude_md.exists():
            existing = self.claude_md.read_text()
            if "# TLM Engineering Rules" in existing:
                marker = "# TLM Engineering Rules"
                before = existing[:existing.index(marker)]
                self.claude_md.write_text(before.rstrip() + "\n\n" + content + "\n")
            else:
                self.claude_md.write_text(existing.rstrip() + "\n\n" + content + "\n")
        else:
            self.claude_md.write_text(content + "\n")
        return self.claude_md

    def save_session(self, name: str, transcript: list) -> Path:
        slug = name.lower().replace(" ", "-")[:40]
        path = self.sessions_dir / f"{datetime.date.today()}-{slug}.json"
        path.write_text(json.dumps(transcript, indent=2))
        return path

    def increment_sessions(self):
        if self.config_file.exists():
            cfg = json.loads(self.config_file.read_text())
            cfg["sessions_used"] = cfg.get("sessions_used", 0) + 1
            cfg["last_session_at"] = datetime.datetime.now().isoformat()
            self.config_file.write_text(json.dumps(cfg, indent=2))

    def get_config(self) -> dict:
        if self.config_file.exists():
            return json.loads(self.config_file.read_text())
        return {}

    # Dot-directories to traverse despite the "skip all dot-dirs" policy
    _DOT_WHITELIST = {".github"}

    def scan_files(self) -> tuple[str, str]:
        """Get project file listing and sample file contents."""
        ignore = {
            ".git", "node_modules", "__pycache__", ".tlm", ".next",
            ".vercel", ".firebase", "dist", "build", ".dart_tool",
            "coverage", ".pytest_cache", "venv", ".venv", "env",
            ".gradle", ".idea", ".vscode", ".pub-cache", ".flutter-plugins",
        }
        # Platform-specific nested ignores (matched as relative subpaths)
        nested_ignore = {"ios/Pods", "android/.gradle"}

        listing = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            rel = os.path.relpath(dirpath, self.root)
            # Check nested ignore patterns
            if rel in nested_ignore:
                dirnames.clear()
                continue
            dirnames[:] = [
                d for d in dirnames
                if d not in ignore and (not d.startswith(".") or d in self._DOT_WHITELIST)
            ]
            depth = rel.count(os.sep) if rel != "." else 0
            if depth > 5:
                dirnames.clear()
                continue
            indent = "  " * depth
            if rel != ".":
                listing.append(f"{indent}{os.path.basename(dirpath)}/")
            for f in sorted(filenames)[:40]:
                listing.append(f"{indent}  {f}")
        file_tree = "\n".join(listing[:500])

        # Sample key config/manifest files (root level)
        sample_files = []
        key_patterns = [
            "package.json", "pyproject.toml", "Cargo.toml", "pubspec.yaml",
            "go.mod", "requirements.txt", "Gemfile", "Makefile", "Dockerfile",
            "docker-compose*.yml", "docker-compose*.yaml",
            ".env.example", ".env.sample",
            "firebase.json", ".firebaserc", "vercel.json", "netlify.toml",
            "fly.toml", "render.yaml", "railway.json", "railway.toml",
            "serverless.yml", "serverless.yaml", "samconfig.toml", "cdk.json",
            ".elasticbeanstalk/config.yml",
            "jest.config.*", "vitest.config.*", "pytest.ini", "setup.cfg",
            "tsconfig.json", "next.config.*",
            ".github/workflows/*.yml",
            "CLAUDE.md",
        ]
        for pattern in key_patterns:
            for match in glob.glob(str(self.root / pattern)):
                try:
                    content = Path(match).read_text()[:2000]
                    rel_path = os.path.relpath(match, self.root)
                    sample_files.append(f"=== {rel_path} ===\n{content}")
                except Exception:
                    pass

        # Monorepo-aware manifest scanning: check one level of subdirectories
        monorepo_manifests = [
            "package.json", "pyproject.toml", "pubspec.yaml",
            "Cargo.toml", "go.mod", "requirements.txt",
        ]
        try:
            for entry in sorted(self.root.iterdir()):
                if entry.is_dir() and entry.name not in ignore and not entry.name.startswith("."):
                    for manifest in monorepo_manifests:
                        manifest_path = entry / manifest
                        if manifest_path.exists():
                            try:
                                content = manifest_path.read_text()[:2000]
                                rel_path = os.path.relpath(str(manifest_path), self.root)
                                sample_files.append(f"=== {rel_path} ===\n{content}")
                            except Exception:
                                pass
        except OSError:
            pass

        # Grab test files — one per top-level directory
        test_patterns = [
            "tests/**/*.py", "test/**/*.py",
            "__tests__/**/*.js", "__tests__/**/*.ts",
            "test/**/*.dart", "*_test.go", "spec/**/*_spec.rb",
            "*/tests/**/*.py", "*/__tests__/**/*.ts", "*/__tests__/**/*.js",
            "*/test/**/*.dart",
        ]
        sampled_dirs = set()
        for pat in test_patterns:
            matches = glob.glob(str(self.root / pat), recursive=True)
            for match_path in matches:
                # Determine the top-level directory this test belongs to
                rel_path = os.path.relpath(match_path, self.root)
                top_dir = rel_path.split(os.sep)[0] if os.sep in rel_path else "."
                if top_dir in sampled_dirs:
                    continue
                sampled_dirs.add(top_dir)
                try:
                    content = Path(match_path).read_text()[:1500]
                    sample_files.append(f"=== {rel_path} ===\n{content}")
                except Exception:
                    pass

        samples = "\n\n".join(sample_files) if sample_files else "(no key files found)"
        return file_tree, samples


# ─── Gap Extraction ───────────────────────────────────────────

# Severity keywords: category substrings → severity level
_HIGH_KEYWORDS = ["security", "ci/cd", "cicd", "backup", "ssl", "tls", "auth"]
_MEDIUM_KEYWORDS = ["logging", "monitoring", "rate limit", "health", "performance"]

# Prerequisite gap IDs — these block feature work at high/standard quality
_PREREQUISITE_GAP_IDS = {
    "no-test-environment",
    "no-testing",
    "no-test-framework",
    "no-environment-promotion",
    "no-environments",
}

# Broader prerequisite keywords — if gap id contains these, it's prerequisite
_PREREQUISITE_KEYWORDS = [
    "test-environment", "test-framework", "testing-framework",
    "environment-promotion", "no-environments",
]


def is_prerequisite_gap(gap: dict) -> bool:
    """Check if a gap is a prerequisite that blocks feature work."""
    gap_id = gap.get("id", "")
    if gap_id in _PREREQUISITE_GAP_IDS:
        return True
    return any(kw in gap_id for kw in _PREREQUISITE_KEYWORDS)


def extract_gaps_from_profile(profile_text: str) -> list[dict]:
    """Parse the ## Gaps section from a profile markdown and return structured gap data.

    Returns list of dicts with: id, category, description, severity, dismissed.
    """
    if not profile_text:
        return []

    # Find the ## Gaps section
    match = re.search(r'^## Gaps\s*\n(.*?)(?=^## |\Z)', profile_text, re.MULTILINE | re.DOTALL)
    if not match:
        return []

    gaps_text = match.group(1).strip()
    if not gaps_text:
        return []

    gaps = []
    for line in gaps_text.split("\n"):
        line = line.strip()
        # Match "- **Category**: description"
        m = re.match(r'^-\s+\*\*(.+?)\*\*:\s*(.+)$', line)
        if not m:
            continue

        category = m.group(1).strip()
        description = m.group(2).strip()

        # Generate stable ID from category
        gap_id = "no-" + re.sub(r'[^a-z0-9]+', '-', category.lower()).strip('-')

        # Assign severity based on keywords
        cat_lower = category.lower()
        desc_lower = description.lower()
        combined = cat_lower + " " + desc_lower

        if any(kw in combined for kw in _HIGH_KEYWORDS):
            severity = "high"
        elif any(kw in combined for kw in _MEDIUM_KEYWORDS):
            severity = "medium"
        else:
            severity = "low"

        gaps.append({
            "id": gap_id,
            "category": category,
            "description": description,
            "severity": severity,
            "dismissed": False,
        })

    return gaps


# ─── Project Scanner ───────────────────────────────────────────

class Scanner:
    def __init__(self, project: Project, claude=None, *, api_client=None, project_id: str = None):
        self.project = project
        self.api_client = api_client
        self.project_id = project_id

    def _get_local_analysis(self, file_tree: str, samples: str) -> str | None:
        """Run silent local Claude analysis using claude CLI.

        Returns markdown profile on success, None on any failure.
        Zero user-visible side effects — capture_output=True suppresses all output.
        """
        if not shutil.which("claude"):
            logger.debug("claude CLI not found, skipping local analysis")
            return None

        prompt = (
            "Examine this project and produce a concise technical profile.\n\n"
            f"<file_tree>\n{file_tree}\n</file_tree>\n\n"
            f"<key_files>\n{samples}\n</key_files>\n\n"
            "Produce a markdown report with sections: "
            "## Stack, ## Testing, ## Environments, ## Patterns, ## Gaps. "
            "Be factual. Only report what you can detect from the files."
        )

        try:
            result = subprocess.run(
                ["claude", "-p", prompt],
                capture_output=True,
                text=True,
                timeout=90,
            )
            if result.returncode != 0:
                logger.debug("claude CLI exited with code %d", result.returncode)
                return None
            output = result.stdout.strip()
            return output if output else None
        except subprocess.TimeoutExpired:
            logger.debug("claude CLI timed out after 90s")
            return None
        except Exception as e:
            logger.debug("claude CLI failed: %s", e)
            return None

    def scan(self) -> str:
        file_tree, samples = self.project.scan_files()

        if not self.api_client:
            raise RuntimeError("Scanner requires api_client (server mode)")

        # Get local analysis from Claude CLI (silent, best-effort)
        local_analysis = self._get_local_analysis(file_tree, samples)

        result = self.api_client.scan(
            self.project_id, file_tree, samples,
            local_analysis=local_analysis,
        )
        profile = result["profile"]

        self.project.save_profile(profile)
        return profile


# ─── Config Generator ─────────────────────────────────────────

class ConfigGenerator:
    """
    Generates enforcement config via LLM, then runs interactive approval.

    Flow:
    1. LLM scans project → generates enforcement.json
    2. Present to user interactively
    3. User corrects / approves
    4. Save as approved config
    """

    def __init__(self, project: Project, claude=None, *, api_client=None, project_id: str = None):
        self.project = project
        self.api_client = api_client
        self.project_id = project_id

    def generate(self) -> dict:
        """Have the LLM generate an enforcement config."""
        if not self.api_client:
            raise RuntimeError("ConfigGenerator requires api_client (server mode)")
        file_tree, samples = self.project.scan_files()
        result = self.api_client.generate_config(
            self.project_id, self.project.get_profile(), file_tree, samples
        )
        return result["config"]

    def update_config(self, current_config: dict, feedback: str) -> dict:
        """Have the LLM update the config based on user feedback."""
        if not self.api_client:
            raise RuntimeError("ConfigGenerator requires api_client (server mode)")
        result = self.api_client.update_config(
            self.project_id, current_config, feedback, self.project.get_profile()
        )
        return result["config"]

    def save_approved(self, config: dict):
        """Save config and mark as approved."""
        self.project.enforcement.save(config)
        self.project.enforcement.approve()


# ─── Drift Detector ───────────────────────────────────────────

class DriftDetector:
    """Detects if project setup has changed since config was approved."""

    def __init__(self, project: Project, claude=None, *, api_client=None, project_id: str = None):
        self.project = project
        self.api_client = api_client
        self.project_id = project_id

    def check(self) -> dict:
        """Quick check: have drift indicator files changed?

        Returns: {"drifted": bool, "changed_files": [...], "stale": bool, "reason": str}
        """
        drift = self.project.enforcement.check_drift()

        if not drift["drifted"]:
            return {"drifted": False, "stale": False, "changed_files": [], "reason": ""}

        if not self.api_client:
            raise RuntimeError("DriftDetector requires api_client (server mode)")

        # Files changed — ask LLM if it's meaningful
        config = self.project.enforcement.load()

        # Read current contents of changed files
        file_contents = {}
        for filename in drift["changed_files"]:
            filepath = self.project.root / filename
            if filepath.exists():
                try:
                    file_contents[filename] = filepath.read_text()[:3000]
                except Exception:
                    file_contents[filename] = "(unreadable)"
            else:
                file_contents[filename] = "(deleted)"

        result = self.api_client.check_drift(
            self.project_id, config, drift["details"], file_contents
        )
        return {
            "drifted": True,
            "stale": result.get("stale", True),
            "changed_files": drift["changed_files"],
            "reason": result.get("reason", ""),
            "affected_sections": result.get("affected_sections", []),
        }


# ─── Discovery Engine ──────────────────────────────────────────

class DiscoveryEngine:
    def __init__(self, project: Project, claude=None, *, api_client=None, project_id: str = None):
        self.project = project
        self.api_client = api_client
        self.project_id = project_id
        self.history = []
        self.feature_request = ""
        self._session_id = None
        self._last_generate_result = None

    def start(self, feature_request: str) -> str:
        if not self.api_client:
            raise RuntimeError("DiscoveryEngine requires api_client (server mode)")
        self.feature_request = feature_request
        result = self.api_client.discovery_start(self.project_id, feature_request)
        self._session_id = result["session_id"]
        response = result["response"]
        self.history = [
            {"role": "user", "content": f"I want to build: {feature_request}"},
            {"role": "assistant", "content": response},
        ]
        return response

    def respond(self, user_input: str) -> str:
        if not self.api_client:
            raise RuntimeError("DiscoveryEngine requires api_client (server mode)")
        result = self.api_client.discovery_respond(
            self.project_id, self._session_id, user_input
        )
        response = result["response"]
        self.history.append({"role": "user", "content": user_input})
        self.history.append({"role": "assistant", "content": response})
        return response

    def is_complete(self, response: str) -> bool:
        signals = ["complete picture", "generating your spec", "generate the spec",
                    "ready to generate", "have enough to", "generate your spec"]
        return any(s in response.lower() for s in signals)

    def generate_outputs(self) -> tuple[str, str]:
        if not self.api_client:
            raise RuntimeError("DiscoveryEngine requires api_client (server mode)")
        result = self.api_client.discovery_generate(self.project_id, self._session_id)
        self._last_generate_result = result
        return result["spec"], result["instructions"]

    def extract_knowledge(self, spec: str) -> str:
        # When using API, knowledge comes from the generate response
        if self._last_generate_result and "knowledge" in self._last_generate_result:
            return self._last_generate_result["knowledge"]
        return ""


# ─── Compliance Checker ────────────────────────────────────────

class ComplianceChecker:
    def __init__(self, project: Project, claude=None, *, api_client=None, project_id: str = None):
        self.project = project
        self.api_client = api_client
        self.project_id = project_id

    def check(self, spec_path: str = None) -> str:
        if not self.api_client:
            raise RuntimeError("ComplianceChecker requires api_client (server mode)")

        diff = self._get_diff()
        if not diff:
            return "No changes detected. Stage changes with `git add` first."

        if spec_path:
            spec = Path(spec_path).read_text()
        else:
            specs = sorted(self.project.specs_dir.glob("*.md"), reverse=True)
            if not specs:
                return "No specs found. Run `tlm build` first."
            spec = specs[0].read_text()

        result = self.api_client.compliance_check(
            self.project_id, spec, diff,
            self.project.get_profile(),
            self.project.get_enforcement_summary(),
        )
        return result["result"]

    def _get_diff(self) -> str:
        try:
            result = subprocess.run(
                ["git", "diff", "--cached"], capture_output=True, text=True,
                cwd=str(self.project.root)
            )
            if result.stdout.strip():
                return result.stdout
            result = subprocess.run(
                ["git", "diff"], capture_output=True, text=True,
                cwd=str(self.project.root)
            )
            return result.stdout
        except FileNotFoundError:
            return ""
