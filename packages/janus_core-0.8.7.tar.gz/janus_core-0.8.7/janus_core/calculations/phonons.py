"""Phonon calculations."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, get_args

from ase import Atoms
from numpy import ndarray
import phonopy
from phonopy.file_IO import parse_QPOINTS, write_force_constants_to_hdf5
from phonopy.phonon.band_structure import (
    get_band_qpoints_and_path_connections,
    get_band_qpoints_by_seekpath,
)
from phonopy.structure.atoms import PhonopyAtoms
from yaml import safe_load

from janus_core.calculations.base import BaseCalculation
from janus_core.calculations.geom_opt import GeomOpt
from janus_core.helpers.janus_types import (
    Architectures,
    ASEReadArgs,
    Devices,
    MaybeList,
    MaybeSequence,
    PathLike,
    PhononCalcs,
)
from janus_core.helpers.struct_io import PhonopyAtomsAdaptor
from janus_core.helpers.utils import (
    build_file_dir,
    none_to_dict,
    set_minimize_logging,
    track_progress,
)


class Phonons(BaseCalculation):
    """
    Configure, perform phonon calculations and write out results.

    Parameters
    ----------
    struct
        ASE Atoms structure, or filepath to structure to simulate.
    arch
        MLIP architecture to use for calculations. Default is `None`.
    device
        Device to run MLIP model on. Default is "cpu".
    model
        MLIP model label, path to model, or loaded model. Default is `None`.
    read_kwargs
        Keyword arguments to pass to ase.io.read. By default,
        read_kwargs["index"] is -1.
    calc_kwargs
        Keyword arguments to pass to the selected calculator. Default is {}.
    attach_logger
        Whether to attach a logger. Default is True if "filename" is passed in
        log_kwargs, else False.
    log_kwargs
        Keyword arguments to pass to `config_logger`. Default is {}.
    track_carbon
        Whether to track carbon emissions of calculation. Requires attach_logger.
        Default is True if attach_logger is True, else False.
    tracker_kwargs
        Keyword arguments to pass to `config_tracker`. Default is {}.
    calcs
        Phonon calculations to run. Default calculates force constants only.
    supercell
        The size of a supercell for calculation, or the supercell itself.
        If a single number is provided, it is interpreted as the size, so a
        diagonal supercell of that size in all dimensions is constructed.
        If three values are provided, they are interpreted as the diagonal
        values of a diagonal supercell. If nine values are provided, they
        are assumed to be the full supercell matrix in the style of Phonopy,
        so the first three values will be used as the first row, the second
        three as the second row, etc. Default is 2.
    displacement
        Displacement for force constants calculation, in A. Default is 0.01.
    displacement_kwargs
        Keyword arguments to pass to generate_displacements. Default is {}.
    mesh
        Mesh for sampling. Default is (10, 10, 10).
    symmetrize
        Whether to symmetrize structure and force constants after calculation.
        Default is False.
    minimize
        Whether to perform geometry optimisation before calculating phonons.
        Default is False.
    minimize_kwargs
        Keyword arguments to pass to geometry optimizer. Default is {}.
    n_qpoints
        Number of q-points to sample along generated path, including end points.
        Unused if `qpoint_file` is specified. Default is 51.
    qpoint_file
        Path to yaml file with info to generate a path of q-points for band structure.
        Default is `None`.
    dos_kwargs
        Keyword arguments to pass to run_total_dos. Default is {}.
    pdos_kwargs
        Keyword arguments to pass to run_projected_dos. Default is {}.
    temp_min
        Start temperature for thermal properties calculations, in K. Default is 0.0.
    temp_max
        End temperature for thermal properties calculations, in K. Default is 1000.0.
    temp_step
        Temperature step for thermal properties calculations, in K. Default is 50.0.
    hdf5
        Whether to write force constants and bands in hdf5 or not. Default is True.
    hdf5_compression
        Compression scheme to use for force constants, gzip or lzf. Default is None.
    plot_to_file
        Whether to plot various graphs as band stuctures, dos/pdos in svg.
        Default is False.
    write_results
        Default for whether to write out results to file. Default is True.
    write_full
        Whether to maximize information written in various output files.
        Default is True.
    file_prefix
        Prefix for output filenames. Default is inferred from chemical formula of the
        structure.
    enable_progress_bar
        Whether to show a progress bar during phonon calculations. Default is False.

    Attributes
    ----------
    calc : ase.calculators.calculator.Calculator
        ASE Calculator attached to structure.
    results : dict
        Results of phonon calculations.
    """

    def __init__(
        self,
        struct: Atoms | PathLike,
        arch: Architectures | None = None,
        device: Devices = "cpu",
        model: PathLike | None = None,
        read_kwargs: ASEReadArgs | None = None,
        calc_kwargs: dict[str, Any] | None = None,
        attach_logger: bool | None = None,
        log_kwargs: dict[str, Any] | None = None,
        track_carbon: bool | None = None,
        tracker_kwargs: dict[str, Any] | None = None,
        calcs: MaybeSequence[PhononCalcs] = (),
        supercell: MaybeList[int] = 2,
        displacement: float = 0.01,
        displacement_kwargs: dict[str, Any] | None = None,
        mesh: tuple[int, int, int] = (10, 10, 10),
        symmetrize: bool = False,
        minimize: bool = False,
        minimize_kwargs: dict[str, Any] | None = None,
        n_qpoints: int = 51,
        qpoint_file: PathLike | None = None,
        dos_kwargs: dict[str, Any] | None = None,
        pdos_kwargs: dict[str, Any] | None = None,
        temp_min: float = 0.0,
        temp_max: float = 1000.0,
        temp_step: float = 50.0,
        hdf5: bool = True,
        hdf5_compression: str | None = None,
        plot_to_file: bool = False,
        write_results: bool = True,
        write_full: bool = True,
        file_prefix: PathLike | None = None,
        enable_progress_bar: bool = False,
    ) -> None:
        """
        Initialise Phonons class.

        Parameters
        ----------
        struct
            ASE Atoms structure, or filepath to structure to simulate.
        arch
            MLIP architecture to use for calculations. Default is `None`.
        device
            Device to run MLIP model on. Default is "cpu".
        model
            MLIP model label, path to model, or loaded model. Default is `None`.
        read_kwargs
            Keyword arguments to pass to ase.io.read. By default,
            read_kwargs["index"] is -1.
        calc_kwargs
            Keyword arguments to pass to the selected calculator. Default is {}.
        attach_logger
            Whether to attach a logger. Default is True if "filename" is passed in
            log_kwargs, else False.
        log_kwargs
            Keyword arguments to pass to `config_logger`. Default is {}.
        track_carbon
            Whether to track carbon emissions of calculation. Requires attach_logger.
            Default is True if attach_logger is True, else False.
        tracker_kwargs
            Keyword arguments to pass to `config_tracker`. Default is {}.
        calcs
            Phonon calculations to run. Default calculates force constants only.
        supercell
            The size of a supercell for calculation, or the supercell itself.
            If a single number is provided, it is interpreted as the size, so a
            diagonal supercell of that size in all dimensions is constructed.
            If three values are provided, they are interpreted as the diagonal
            values of a diagonal supercell. If nine values are provided, they
            are assumed to be the full supercell matrix in the style of Phonopy,
            so the first three values will be used as the first row, the second
            three as the second row, etc. Default is 2.
        displacement
            Displacement for force constants calculation, in A. Default is 0.01.
        displacement_kwargs
            Keyword arguments to pass to generate_displacements. Default is {}.
        mesh
            Mesh for sampling. Default is (10, 10, 10).
        symmetrize
            Whether to symmetrize structure and force constants after calculation.
            Default is False.
        minimize
            Whether to perform geometry optimisation before calculating phonons.
            Default is False.
        minimize_kwargs
            Keyword arguments to pass to geometry optimizer. Default is {}.
        n_qpoints
            Number of q-points to sample along generated path, including end points.
            Unused if `qpoint_file` is specified. Default is 51.
        qpoint_file
           Path to yaml file with info to generate a path of q-points for band
           structure. Default is `None`.
        dos_kwargs
            Keyword arguments to pass to run_total_dos. Default is {}.
        pdos_kwargs
            Keyword arguments to pass to run_projected_dos. Default is {}.
        temp_min
            Start temperature for thermal calculations, in K. Default is 0.0.
        temp_max
            End temperature for thermal calculations, in K. Default is 1000.0.
        temp_step
            Temperature step for thermal calculations, in K. Default is 50.0.
        hdf5
            Whether to write force constants and bands in hdf5 or not. Default is True.
        hdf5_compression
            Compression scheme to use for force constants, gzip or lzf. Default is None.
        plot_to_file
            Whether to plot various graphs as band stuctures, dos/pdos in svg.
            Default is False.
        write_results
            Default for whether to write out results to file. Default is True.
        write_full
            Whether to maximize information written in various output files.
            Default is True.
        file_prefix
            Prefix for output filenames. Default is inferred from structure name, or
            chemical formula of the structure.
        enable_progress_bar
            Whether to show a progress bar during phonon calculations. Default is False.
        """
        read_kwargs, displacement_kwargs, minimize_kwargs, dos_kwargs, pdos_kwargs = (
            none_to_dict(
                read_kwargs,
                displacement_kwargs,
                minimize_kwargs,
                dos_kwargs,
                pdos_kwargs,
            )
        )

        self.calcs = calcs
        self.displacement = displacement
        self.displacement_kwargs = displacement_kwargs
        self.mesh = mesh
        self.minimize = minimize
        self.minimize_kwargs = minimize_kwargs
        self.symmetrize = symmetrize
        self.n_qpoints = n_qpoints
        self.qpoint_file = qpoint_file
        self.dos_kwargs = dos_kwargs
        self.pdos_kwargs = pdos_kwargs
        self.temp_min = temp_min
        self.temp_max = temp_max
        self.temp_step = temp_step
        self.hdf5 = hdf5
        self.hdf5_compression = hdf5_compression
        self.plot_to_file = plot_to_file
        self.write_results = write_results
        self.write_full = write_full
        self.enable_progress_bar = enable_progress_bar

        # Ensure supercell is a valid list
        self.supercell = [supercell] * 3 if isinstance(supercell, int) else supercell
        if len(self.supercell) not in [3, 9]:
            raise ValueError(
                "`supercell` must be an integer, or list of length 3 or 9. A list of "
                "length 3 must specify the values of a diagonal supercell, and a list "
                "of length 9 must specify all values of a full supercell matrix, where "
                "the first three values are the first row, the second three are the "
                "second row, etc."
            )

        # Read last image by default
        read_kwargs.setdefault("index", -1)

        # Initialise structures and logging
        super().__init__(
            struct=struct,
            calc_name=__name__,
            arch=arch,
            device=device,
            model=model,
            read_kwargs=read_kwargs,
            sequence_allowed=False,
            calc_kwargs=calc_kwargs,
            attach_logger=attach_logger,
            log_kwargs=log_kwargs,
            track_carbon=track_carbon,
            tracker_kwargs=tracker_kwargs,
            file_prefix=file_prefix,
        )

        if not self.struct.calc:
            raise ValueError("Please attach a calculator to `struct`.")

        # Use phonons logger for geometry optimization
        set_minimize_logging(
            self.logger, self.minimize_kwargs, self.log_kwargs, self.track_carbon
        )

        # Write out file by default if minimizing
        self.minimize_kwargs.setdefault("write_results", True)

        # If not specified otherwise, save optimized structure consistently with
        # other phonon output files
        opt_file = self._build_filename("opt.extxyz")
        if "write_kwargs" in self.minimize_kwargs:
            # Use _build_filename even if given filename to ensure directory exists
            self.minimize_kwargs["write_kwargs"]["filename"] = self._build_filename(
                "", filename=self.minimize_kwargs["write_kwargs"].get("filename")
            )
        else:
            self.minimize_kwargs["write_kwargs"] = {"filename": opt_file}

        # Output files
        self.phonopy_file = self._build_filename("phonopy.yml")
        self.force_consts_file = self._build_filename("force_constants.hdf5")

        suffix = ".hdf5" if hdf5 else ".yml"
        filename = "bands" + suffix
        if not self.qpoint_file:
            filename = f"auto_{filename}"
        self.bands_file = self._build_filename(filename)
        self.bands_plot_file = self._build_filename("bands.svg")
        self.qpoints_file = self._build_filename("qpoints" + suffix)
        self.dos_file = self._build_filename("dos.dat")
        self.dos_plot_file = self._build_filename("dos.svg")
        self.bands_dos_plot_file = self._build_filename("bs-dos.svg")
        self.pdos_file = self._build_filename("pdos.dat")
        self.pdos_plot_file = self._build_filename("pdos.svg")
        self.thermal_file = self._build_filename("thermal.yml")

        self.calc = self.struct.calc
        self.results = {}

    @property
    def calcs(self) -> Sequence[PhononCalcs]:
        """
        Phonon calculations to be run.

        Returns
        -------
        Sequence[PhononCalcs]
            Phonon calculations.
        """
        return self._calcs

    @calcs.setter
    def calcs(self, value: MaybeSequence[PhononCalcs]) -> None:
        """
        Setter for `calcs`.

        Parameters
        ----------
        value
            Phonon calculations to be run.
        """
        if isinstance(value, str):
            value = (value,)

            for calc in value:
                if calc not in get_args(PhononCalcs):
                    raise NotImplementedError(
                        f"Calculations '{calc}' cannot currently be performed."
                    )

        # If none specified, only force constants will be calculated
        if not value:
            value = ()

        self._calcs = value

    @property
    def symmetrize(self) -> bool:
        """
        Whether to symmetrize structure and force constants after calculation.

        Returns
        -------
        bool
            Whether to symmetrize structure and force constants after calculation.
        """
        return self._symmetrize

    @symmetrize.setter
    def symmetrize(self, value: bool) -> None:
        """
        Set symmetrize value and corresponding minimize_kwargs value.

        Parameters
        ----------
        value
            Whether to symmetrize structure and force constants after calculation.
        """
        self.minimize_kwargs.setdefault("symmetrize", value)
        self._symmetrize = value

    @property
    def output_files(self) -> None:
        """
        Dictionary of output file labels and paths.

        Returns
        -------
        dict[str, PathLike]
            Output file labels and paths.
        """
        return {
            "log": self.log_kwargs["filename"] if self.logger else None,
            "params": self.phonopy_file if self.write_results else None,
            "force_constants": (self.force_consts_file if self.hdf5 else None),
            "bands": (
                self.bands_file
                if self.write_results and "bands" in self.calcs
                else None
            ),
            "qpoints": (
                self.qpoints_file
                if self.write_results and "qpoints" in self.calcs
                else None
            ),
            "bands_plot": self.bands_plot_file if self.plot_to_file else None,
            "dos": (
                self.dos_file if self.write_results and "dos" in self.calcs else None
            ),
            "dos_plot": (
                self.dos_plot_file
                if self.plot_to_file and "dos" in self.calcs
                else None
            ),
            "band_dos_plot": (
                self.bands_dos_plot_file
                if self.plot_to_file and "dos" in self.calcs and "bands" in self.calcs
                else None
            ),
            "pdos": (
                self.pdos_file if self.write_results and "pdos" in self.calcs else None
            ),
            "pdos_plot": (
                self.pdos_plot_file
                if self.plot_to_file and "pdos" in self.calcs
                else None
            ),
            "thermal": (
                self.thermal_file
                if self.write_results and "thermal" in self.calcs
                else None
            ),
            "minimized_initial_structure": (
                self.minimize_kwargs["write_kwargs"]["filename"]
                if self.minimize
                else None
            ),
        }

    def calc_force_constants(
        self, write_force_consts: bool | None = None, **kwargs
    ) -> None:
        """
        Calculate force constants and optionally write results.

        Parameters
        ----------
        write_force_consts
            Whether to write out results to file. Default is self.write_results.
        **kwargs
            Additional keyword arguments to pass to `write_force_constants`.
        """
        if write_force_consts is None:
            write_force_consts = self.write_results

        if self.minimize:
            optimizer = GeomOpt(self.struct, **self.minimize_kwargs)
            optimizer.run()

        if self.logger:
            self.logger.info("Starting phonons calculation")
        if self.tracker:
            self.tracker.start_task("Phonon calculation")

        self._set_info_units()

        cell = PhonopyAtomsAdaptor.get_phonopy_atoms(self.struct)

        if len(self.supercell) == 3:
            supercell_matrix = (
                (self.supercell[0], 0, 0),
                (0, self.supercell[1], 0),
                (0, 0, self.supercell[2]),
            )
        else:
            supercell_matrix = (
                tuple(self.supercell[:3]),
                tuple(self.supercell[3:6]),
                tuple(self.supercell[6:]),
            )

        phonon = phonopy.Phonopy(cell, supercell_matrix)
        phonon.generate_displacements(
            distance=self.displacement,
            **self.displacement_kwargs,
        )
        disp_supercells = phonon.supercells_with_displacements

        if self.enable_progress_bar:
            disp_supercells = track_progress(
                disp_supercells, description="Computing displacements..."
            )

        phonon.forces = [
            self._calc_forces(supercell)
            for supercell in disp_supercells
            if supercell is not None
        ]

        phonon.produce_force_constants()
        self.results["phonon"] = phonon

        if self.symmetrize:
            self.results["phonon"].symmetrize_force_constants(level=1)

        if self.logger:
            self.logger.info("Phonons calculation complete")
        if self.tracker:
            emissions = self.tracker.stop_task().emissions
            self.struct.info["emissions"] = emissions
            self.tracker.flush()

        if write_force_consts:
            self.write_force_constants(**kwargs)

    def write_force_constants(
        self,
        *,
        phonopy_file: PathLike | None = None,
        hdf5: bool | None = None,
        compression: str | None = None,
        force_consts_file: PathLike | None = None,
    ) -> None:
        """
        Write results of force constants calculations.

        Parameters
        ----------
        phonopy_file
            Name of yaml file to save params of phonopy and optionally force constants.
            Default is inferred from `file_prefix`.
        hdf5
            Whether to save the force constants separately to an hdf5 file. Default is
            self.hdf5.
        compression
            Compression scheme to use fo hdf5 file, gzip or lzf. Default is None.
        force_consts_file
            Name of hdf5 file to save force constants. Unused if `hdf5`
            is False. Default is inferred from `file_prefix`.
        """
        if "phonon" not in self.results:
            raise ValueError(
                "Force constants have not been calculated yet. "
                "Please run `calc_force_constants` first"
            )

        if hdf5 is None:
            hdf5 = self.hdf5

        if compression is None:
            compression = self.hdf5_compression

        if phonopy_file:
            self.phonopy_file = phonopy_file
        if force_consts_file:
            self.force_consts_file = force_consts_file

        phonon = self.results["phonon"]

        save_force_consts = not hdf5
        build_file_dir(self.phonopy_file)
        phonon.save(self.phonopy_file, settings={"force_constants": save_force_consts})

        if hdf5:
            build_file_dir(self.force_consts_file)
            write_force_constants_to_hdf5(
                phonon.force_constants,
                filename=self.force_consts_file,
                compression=compression,
            )

    def calc_bands(self, write_bands: bool | None = None, **kwargs) -> None:
        """
        Calculate band structure and optionally write and plot results.

        Parameters
        ----------
        write_bands
            Whether to write out results to file. Default is self.write_results.
        **kwargs
            Additional keyword arguments to pass to `write_bands`.
        """
        if write_bands is None:
            write_bands = self.write_results

        # Calculate phonons if not already in results
        if "phonon" not in self.results:
            # Use general (self.write_results) setting for writing force constants
            self.calc_force_constants(write_force_consts=self.write_results)

        if write_bands:
            self.write_bands(**kwargs)

    def write_bands(
        self,
        *,
        hdf5: bool | None = None,
        bands_file: PathLike | None = None,
        save_plots: bool | None = None,
        plot_file: PathLike | None = None,
    ) -> None:
        """
        Write results of band structure calculations.

        Parameters
        ----------
        hdf5
            Whether to save the bands in an hdf5 file. Default is
            self.hdf5.
        bands_file
            Name of yaml file to save band structure. Default is inferred from
            `file_prefix`.
        save_plots
            Whether to save plot to file. Default is self.plot_to_file.
        plot_file
            Name of svg file if saving band structure plot. Default is inferred from
            `file_prefix`.
        """
        if "phonon" not in self.results:
            raise ValueError(
                "Force constants have not been calculated yet. "
                "Please run `calc_force_constants` first"
            )

        if hdf5 is None:
            hdf5 = self.hdf5

        if save_plots is None:
            save_plots = self.plot_to_file

        if bands_file:
            self.bands_file = bands_file

        if plot_file:
            self.bands_plot_file = plot_file

        if self.qpoint_file:
            with open(self.qpoint_file, encoding="utf8") as file:
                paths_info = safe_load(file)

            labels = paths_info["labels"]
            num_q_points = sum(len(q) for q in paths_info["paths"])
            num_labels = len(labels)
            assert num_q_points == num_labels, (
                "Number of labels is different to number of q-points specified"
            )

            q_points, connections = get_band_qpoints_and_path_connections(
                band_paths=paths_info["paths"], npoints=paths_info["npoints"]
            )

        else:
            q_points, labels, connections = get_band_qpoints_by_seekpath(
                self.results["phonon"].primitive, self.n_qpoints
            )

        self.results["phonon"].run_band_structure(
            paths=q_points,
            path_connections=connections,
            labels=labels,
            with_eigenvectors=self.write_full,
            with_group_velocities=self.write_full,
        )

        build_file_dir(self.bands_file)
        if hdf5:
            self.results["phonon"].write_hdf5_band_structure(
                filename=self.bands_file,
            )
        else:
            self.results["phonon"].write_yaml_band_structure(
                filename=self.bands_file,
            )

        bplt = self.results["phonon"].plot_band_structure()
        if save_plots:
            build_file_dir(self.bands_plot_file)
            bplt.savefig(self.bands_plot_file)

    def calc_qpoints(self, write_qpoints: bool | None = None, **kwargs) -> None:
        """
        Calculate phonons at qpoints supplied by file QPOINTS, analoguous to phonopy.

        Parameters
        ----------
        write_qpoints
            Whether to write out results to file. Default is self.write_results.
        **kwargs
            Additional keyword arguments to pass to `write_bands`.
        """
        if write_qpoints is None:
            write_qpoints = self.write_results

        # Calculate phonons if not already in results
        if "phonon" not in self.results:
            # Use general (self.write_results) setting for writing force constants
            self.calc_force_constants(write_force_consts=self.write_results)

        if write_qpoints:
            self.write_qpoints(**kwargs)

    def write_qpoints(
        self,
        *,
        hdf5: bool | None = None,
        qpoints_file: PathLike | None = None,
    ) -> None:
        """
        Write results of qpoints mode calculations.

        Parameters
        ----------
        hdf5
            Whether to save the bands in an hdf5 file. Default is
            self.hdf5.
        qpoints_file
            Name of yaml file to save band structure. Default is inferred from
            `file_prefix`.
        """
        if "phonon" not in self.results:
            raise ValueError(
                "Force constants have not been calculated yet. "
                "Please run `calc_force_constants` first"
            )

        if hdf5 is None:
            hdf5 = self.hdf5

        if qpoints_file:
            self.qpoints_file = qpoints_file

        # maybe use self.qpoint_file or allow custom input filename
        # also allow passing a list of points programmatically
        q_points = parse_QPOINTS()

        fonons = self.results["phonon"]

        fonons.run_qpoints(
            q_points,
            with_eigenvectors=self.write_full,
            with_group_velocities=self.write_full,
            with_dynamical_matrices=self.write_full,
            # nac_q_direction = self.nac_q_direction,
        )

        build_file_dir(self.qpoints_file)
        if hdf5:
            # not in phonopy yet
            # fonons.write_hdf5_qpoints_phonon(filename=self.qpoints_file)

            # until the above is implemented in phonopy
            fonons._qpoints.write_hdf5(filename=self.qpoints_file)
        else:
            # not in phonopy yet
            # fonons.write_yaml_qpoints_phonon(filename=self.qpoints_file)

            # until the above is implemented in phonopy
            fonons._qpoints.write_yaml(filename=self.qpoints_file)

    def calc_thermal_props(
        self,
        mesh: tuple[int, int, int] | None = None,
        write_thermal: bool | None = None,
        **kwargs,
    ) -> None:
        """
        Calculate thermal properties and optionally write results.

        Parameters
        ----------
        mesh
            Mesh for sampling. Default is self.mesh.
        write_thermal
            Whether to write out thermal properties to file. Default is
            self.write_results.
        **kwargs
            Additional keyword arguments to pass to `write_thermal_props`.
        """
        if write_thermal is None:
            write_thermal = self.write_results

        if mesh is None:
            mesh = self.mesh

        # Calculate phonons if not already in results
        if "phonon" not in self.results:
            # Use general (self.write_results) setting for writing force constants
            self.calc_force_constants(write_force_consts=self.write_results)

        if self.logger:
            self.logger.info("Starting thermal properties calculation")
        if self.tracker:
            self.tracker.start_task("Thermal calculation")

        self.results["phonon"].run_mesh(mesh)
        self.results["phonon"].run_thermal_properties(
            t_step=self.temp_step, t_max=self.temp_max, t_min=self.temp_min
        )
        self.results["thermal_properties"] = self.results[
            "phonon"
        ].get_thermal_properties_dict()

        if self.logger:
            self.logger.info("Thermal properties calculation complete")
        if self.tracker:
            emissions = self.tracker.stop_task().emissions
            self.struct.info["emissions"] = emissions
            self.tracker.flush()

        if write_thermal:
            self.write_thermal_props(**kwargs)

    def write_thermal_props(self, thermal_file: PathLike | None = None) -> None:
        """
        Write results of thermal properties calculations.

        Parameters
        ----------
        thermal_file
            Name of data file to save thermal properties. Default is inferred from
            `file_prefix`.
        """
        if thermal_file:
            self.thermal_file = thermal_file

        build_file_dir(self.thermal_file)
        self.results["phonon"].write_yaml_thermal_properties(self.thermal_file)

    def calc_dos(
        self,
        *,
        mesh: tuple[int, int, int] | None = None,
        write_dos: bool | None = None,
        **kwargs,
    ) -> None:
        """
        Calculate density of states and optionally write results.

        Parameters
        ----------
        mesh
            Mesh for sampling. Default is self.mesh.
        write_dos
            Whether to write out results to file. Default is True.
        **kwargs
            Additional keyword arguments to pass to `write_dos`.
        """
        if write_dos is None:
            write_dos = self.write_results

        if mesh is None:
            mesh = self.mesh

        # Calculate phonons if not already in results
        if "phonon" not in self.results:
            # Use general (self.write_results) setting for writing force constants
            self.calc_force_constants(write_force_consts=self.write_results)

        if self.logger:
            self.logger.info("Starting DOS calculation")
        if self.tracker:
            self.tracker.start_task("DOS calculation")

        self.results["phonon"].run_mesh(mesh)
        self.results["phonon"].run_total_dos(**self.dos_kwargs)

        if self.logger:
            self.logger.info("DOS calculation complete")
        if self.tracker:
            emissions = self.tracker.stop_task().emissions
            self.struct.info["emissions"] = emissions
            self.tracker.flush()

        if write_dos:
            self.write_dos(**kwargs)

    def write_dos(
        self,
        *,
        dos_file: PathLike | None = None,
        plot_to_file: bool | None = None,
        plot_file: PathLike | None = None,
        plot_bands: bool = False,
        plot_bands_file: PathLike | None = None,
    ) -> None:
        """
        Write results of DOS calculation.

        Parameters
        ----------
        dos_file
            Name of data file to save the calculated DOS. Default is inferred from
            `file_prefix`.
        plot_to_file
            Whether to save plot to file. Default is self.plot_to_file.
        plot_file
            Name of svg file if saving plot of the DOS. Default is inferred from
            `file_prefix`.
        plot_bands
            Whether to plot the band structure and DOS together. Default is
            self.plot_to_file.
        plot_bands_file
            Name of svg file if saving plot of the band structure and DOS.
            Default is inferred from `file_prefix`.
        """
        # Calculate phonons if not already in results
        if "phonon" not in self.results or self.results["phonon"].total_dos is None:
            raise ValueError(
                "The DOS has not been calculated yet. Please run `calc_dos` first"
            )

        if plot_bands and self.results["phonon"].band_structure is None:
            raise ValueError(
                "The band structure has not been calculated yet. "
                "Please run `calc_bands` first, or set `plot_bands = False`"
            )

        if plot_to_file is None:
            plot_to_file = self.plot_to_file
        if plot_bands is None:
            plot_bands = self.plot_to_file

        if dos_file:
            self.dos_file = dos_file
        if plot_file:
            self.dos_plot_file = plot_file
        if plot_bands_file:
            self.bands_dos_plot_file = plot_bands_file

        build_file_dir(self.dos_file)
        self.results["phonon"].total_dos.write(self.dos_file)

        bplt = self.results["phonon"].plot_total_dos()
        if plot_to_file:
            build_file_dir(self.dos_plot_file)
            bplt.savefig(self.dos_plot_file)

        if plot_bands:
            bplt = self.results["phonon"].plot_band_structure_and_dos()
            if plot_to_file:
                build_file_dir(self.bands_dos_plot_file)
                bplt.savefig(self.bands_dos_plot_file)

    def calc_pdos(
        self,
        *,
        mesh: tuple[int, int, int] | None = None,
        write_pdos: bool | None = None,
        **kwargs,
    ) -> None:
        """
        Calculate projected density of states and optionally write results.

        Parameters
        ----------
        mesh
            Mesh for sampling. Default is self.mesh.
        write_pdos
            Whether to write out results to file. Default is self.write_results.
        **kwargs
            Additional keyword arguments to pass to `write_pdos`.
        """
        if write_pdos is None:
            write_pdos = self.write_results

        if mesh is None:
            mesh = self.mesh

        # Calculate phonons if not already in results
        if "phonon" not in self.results:
            # Use general (self.write_results) setting for writing force constants
            self.calc_force_constants(write_force_consts=self.write_results)

        if self.logger:
            self.logger.info("Starting PDOS calculation")
        if self.tracker:
            self.tracker.start_task("PDOS calculation")

        self.results["phonon"].run_mesh(
            mesh, with_eigenvectors=True, is_mesh_symmetry=False
        )
        self.results["phonon"].run_projected_dos(**self.pdos_kwargs)

        if self.logger:
            self.logger.info("PDOS calculation complete")
        if self.tracker:
            emissions = self.tracker.stop_task().emissions
            self.struct.info["emissions"] = emissions
            self.tracker.flush()

        if write_pdos:
            self.write_pdos(**kwargs)

    def write_pdos(
        self,
        *,
        pdos_file: PathLike | None = None,
        plot_to_file: bool | None = None,
        plot_file: PathLike | None = None,
    ) -> None:
        """
        Write results of PDOS calculation.

        Parameters
        ----------
        pdos_file
            Name of file to save the calculated PDOS. Default is inferred from
            `file_prefix`.
        plot_to_file
            Whether to save plot to file. Default is self.plot_to_file.
        plot_file
            Name of svg file if saving plot of the calculated PDOS. Default is inferred
            from `file_prefix`.
        """
        # Calculate phonons if not already in results
        if "phonon" not in self.results or self.results["phonon"].projected_dos is None:
            raise ValueError(
                "The PSDOS has not been calculated yet. Please run `calc_pdos` first"
            )

        if plot_to_file is None:
            plot_to_file = self.plot_to_file

        if pdos_file:
            self.pdos_file = pdos_file
        if plot_file:
            self.pdos_plot_file = plot_file

        build_file_dir(self.pdos_file)
        self.results["phonon"].projected_dos.write(self.pdos_file)

        bplt = self.results["phonon"].plot_projected_dos()
        if plot_to_file:
            build_file_dir(self.pdos_plot_file)
            bplt.savefig(self.pdos_plot_file)

    def _calc_forces(self, struct: PhonopyAtoms) -> ndarray:
        """
        Calculate forces on PhonopyAtoms structure.

        Parameters
        ----------
        struct
            Structure to calculate forces on.

        Returns
        -------
        ndarray
            Forces on the structure.
        """
        return PhonopyAtomsAdaptor.get_atoms(struct, self.calc).get_forces()

    def run(self) -> None:
        """Run phonon calculations."""
        # Calculate force constants
        self.calc_force_constants()

        # Calculate band structure
        if "bands" in self.calcs:
            self.calc_bands()

        if "qpoints" in self.calcs:
            self.calc_qpoints()

        # Calculate thermal properties if specified
        if "thermal" in self.calcs:
            self.calc_thermal_props()

        # Calculate DOS and PDOS if specified
        if "dos" in self.calcs:
            self.calc_dos(plot_bands="bands" in self.calcs)

        if "pdos" in self.calcs:
            self.calc_pdos()
