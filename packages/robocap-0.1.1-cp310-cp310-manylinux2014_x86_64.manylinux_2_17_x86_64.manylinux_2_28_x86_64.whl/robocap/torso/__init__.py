"""躯干模块"""

from .r1_torso import R1Torso

__all__ = ['R1Torso']
