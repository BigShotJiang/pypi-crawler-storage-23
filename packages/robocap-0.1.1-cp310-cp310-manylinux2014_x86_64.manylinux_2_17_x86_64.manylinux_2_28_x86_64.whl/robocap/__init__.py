"""
Robocap: ROS2 机器人能力封装

为 Gazebo 仿真中的机器人提供高级控制接口。

Usage:
    from robocap import UR5Arm

    arm = UR5Arm(
        name='ur5',
        joints=[
            {'cmd': '/ur5/j1/cmd', 'state': '/ur5/j1/state'},
            {'cmd': '/ur5/j2/cmd', 'state': '/ur5/j2/state'},
            {'cmd': '/ur5/j3/cmd', 'state': '/ur5/j3/state'},
            {'cmd': '/ur5/j4/cmd', 'state': '/ur5/j4/state'},
            {'cmd': '/ur5/j5/cmd', 'state': '/ur5/j5/state'},
            {'cmd': '/ur5/j6/cmd', 'state': '/ur5/j6/state'},
        ]
    )

    arm.move_to(0.3, 0.2, 0.4)
"""

__version__ = "0.1.1"

# 机械臂
from .arms import UR5Arm, UR10Arm, GalaxeaA1XArm

# 移动底盘
from .mobile import ScoutMini, R1Base

# 客户端
from .clients import MobileClient, ArmClient, TorsoClient

# 躯干
from .torso import R1Torso

# 异常
from .exceptions import (
    RobocapError,
    IKSolutionError,
    JointLimitError,
    CommunicationError,
    TrajectoryError,
)

# 基类（供扩展使用）
from .base import ArmBase, MobileBase, TorsoBase

__all__ = [
    # 版本
    '__version__',
    # 机械臂
    'UR5Arm',
    'UR10Arm',
    'GalaxeaA1XArm',
    # 移动底盘
    'ScoutMini',
    'R1Base',
    # 客户端
    'MobileClient',
    'ArmClient',
    'TorsoClient',
    # 躯干
    'R1Torso',
    # 基类
    'ArmBase',
    'MobileBase',
    'TorsoBase',
    # 异常
    'RobocapError',
    'IKSolutionError',
    'JointLimitError',
    'CommunicationError',
    'TrajectoryError',
]
