"""机械臂模块"""

from .ur5 import UR5Arm
from .ur10 import UR10Arm
from .galaxea_a1x import GalaxeaA1XArm

__all__ = ['UR5Arm', 'UR10Arm', 'GalaxeaA1XArm']
