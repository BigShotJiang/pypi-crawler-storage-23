"""
Entry point for running the CLI as a module: python -m glyphh.cli
"""
from .main import cli

if __name__ == "__main__":
    cli()
