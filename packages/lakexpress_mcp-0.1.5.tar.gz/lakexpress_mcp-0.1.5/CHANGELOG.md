# Changelog

All notable changes to the LakeXpress MCP Server will be documented in this file.

## [0.1.5] - 2026-02-27

### Added
- Rich descriptions for all properties in MCP tool schemas (helps LLMs provide correct parameters)
- Conditional requirement notes in descriptions (e.g., "publish_method requires publish_target")
- Version requirement annotations on version-gated features (e.g., "requires LakeXpress 0.2.9+")
- Lightweight version-aware warnings in `preview_command` output for incompatible features

## [0.1.4] - 2026-02-27

### Added
- SAP HANA (`saphana`) as a supported source database (LakeXpress v0.2.9)
- `--quiet_fbcp` flag support for `sync` and `sync[export]` commands (LakeXpress v0.2.9)
- Version registry entry for LakeXpress v0.2.9

## [0.1.3] - 2026-02-24

### Added
- PyPI, License, and MCP Registry badges in README
- GitHub Actions workflow for automated PyPI publishing on release
- Missing environment variables (`LAKEXPRESS_LOG_DIR`, `LOG_LEVEL`) in server.json
- GitHub repository topics for MCP Registry discoverability

### Fixed
- Timeout default in server.json (corrected from 1800 to 3600 to match actual code)
- Documentation URL in pyproject.toml

## [0.1.1] - 2026-02-23

### Added

- `server.json` MCP Registry configuration file with package metadata, transport settings, and environment variable definitions

### Changed

- GitHub repository URL updated from `aetperf/lakexpress-mcp` to `arpe-io/lakexpress-mcp` in `pyproject.toml`


## [0.1.0] - 2026-02-20

### Added
- Initial release of LakeXpress MCP Server
- 6 MCP tools: preview_command, execute_command, validate_auth_file, list_capabilities, suggest_workflow, get_version
- Support for all 14 LakeXpress subcommands: logdb (init/drop/truncate/locks/release-locks), config (create/delete/list), sync, sync[export], sync[publish], run, status, cleanup
- Version detection and capabilities registry for LakeXpress v0.2.8
- Comprehensive input validation with Pydantic models
- Command builder with proper CLI argument construction
- Execution logging with configurable log directory
- Auth file validation tool
- Workflow suggestion engine
