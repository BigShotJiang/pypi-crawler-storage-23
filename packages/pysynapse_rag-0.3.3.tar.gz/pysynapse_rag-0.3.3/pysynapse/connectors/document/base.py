import os
from collections.abc import AsyncGenerator
from pathlib import Path

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError


class BaseDocumentConnector:
    """
    Base class for all file connectors.

    Accepts a single file path or a directory.
    For directories, recursively walks and filters by supported extensions.
    """

    #: Extensions handled by the subclass (e.g. {".txt", ".md"})
    SUPPORTED_EXTENSIONS: frozenset[str] = frozenset()

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        if not self.path.exists():
            raise ConnectorError(f"Path not found: {self.path}")
        if self.path.is_file() and self.path.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
            raise ConnectorError(
                f"Extension '{self.path.suffix}' not supported by {type(self).__name__}. "
                f"Accepted extensions: {self.SUPPORTED_EXTENSIONS}"
            )

    def _iter_paths(self) -> list[Path]:
        """Return the list of files to process."""
        if self.path.is_file():
            return [self.path]

        # Directory: recursive scan
        files = []
        for root, _, filenames in os.walk(self.path):
            for name in filenames:
                p = Path(root) / name
                if p.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                    files.append(p)
        if not files:
            raise ConnectorError(
                f"No compatible file found in '{self.path}' "
                f"for extensions {self.SUPPORTED_EXTENSIONS}"
            )
        return sorted(files)

    def load(self) -> AsyncGenerator[Document, None]:
        """To be implemented in each subclass."""
        raise NotImplementedError
