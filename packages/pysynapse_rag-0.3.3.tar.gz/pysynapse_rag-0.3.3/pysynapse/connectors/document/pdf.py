import asyncio
from collections.abc import AsyncGenerator
from pathlib import Path

from pysynapse.connectors.document.base import BaseDocumentConnector
from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError


class PdfConnector(BaseDocumentConnector):
    """
    PDF connector.

    Each page becomes a Document (or the full text if `by_page=False`).
    """

    SUPPORTED_EXTENSIONS = frozenset({".pdf"})

    def __init__(self, path: str | Path, by_page: bool = True) -> None:
        super().__init__(path)
        self.by_page = by_page

    async def load(self) -> AsyncGenerator[Document, None]:
        loop = asyncio.get_event_loop()
        for file_path in self._iter_paths():
            try:
                docs = await loop.run_in_executor(None, self._read_pdf, file_path)
            except Exception as e:
                raise ConnectorError(f"Error reading PDF '{file_path}': {e}") from e
            for doc in docs:
                yield doc

    def _read_pdf(self, file_path: Path) -> list[Document]:
        import pypdf

        docs = []
        with open(file_path, "rb") as f:
            reader = pypdf.PdfReader(f)
            total_pages = len(reader.pages)

            if self.by_page:
                for page_num, page in enumerate(reader.pages, start=1):
                    text = page.extract_text() or ""
                    if text.strip():
                        docs.append(Document(
                            text=text,
                            metadata={
                                "source": str(file_path),
                                "filename": file_path.name,
                                "page": page_num,
                                "total_pages": total_pages,
                            },
                        ))
            else:
                full_text = "\n\n".join(
                    page.extract_text() or "" for page in reader.pages
                )
                if full_text.strip():
                    docs.append(Document(
                        text=full_text,
                        metadata={
                            "source": str(file_path),
                            "filename": file_path.name,
                            "total_pages": total_pages,
                        },
                    ))
        return docs
