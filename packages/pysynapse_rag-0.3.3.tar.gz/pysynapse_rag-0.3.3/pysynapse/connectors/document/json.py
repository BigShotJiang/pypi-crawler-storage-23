import json
from collections.abc import AsyncGenerator
from pathlib import Path

import aiofiles

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError

# Only scalar types are valid in ChromaDB metadata
_SCALAR = (str, int, float, bool)


class JsonConnector:
    """
    Connector for JSON and JSON Lines files.

    - ``.json``  — expects a JSON array of objects (or a single object).
    - ``.jsonl`` — expects one JSON object per line.

    Each object becomes a ``Document``.  The field named ``text_field``
    (default ``"text"``) is used as the document body; all other scalar
    fields become metadata.
    """

    SUPPORTED_EXTENSIONS = frozenset({".json", ".jsonl"})

    def __init__(
        self,
        path: str | Path,
        text_field: str = "text",
    ) -> None:
        self.path = Path(path)
        self.text_field = text_field
        if not self.path.exists():
            raise ConnectorError(f"Path not found: {self.path}")

    def _iter_paths(self) -> list[Path]:
        if self.path.is_file():
            if self.path.suffix.lower() not in self.SUPPORTED_EXTENSIONS:
                raise ConnectorError(
                    f"Unsupported extension '{self.path.suffix}'. "
                    f"Expected: {sorted(self.SUPPORTED_EXTENSIONS)}"
                )
            return [self.path]
        import os
        files = []
        for root, _, filenames in os.walk(self.path):
            for name in filenames:
                p = Path(root) / name
                if p.suffix.lower() in self.SUPPORTED_EXTENSIONS:
                    files.append(p)
        return sorted(files)

    def _obj_to_document(self, obj: dict, file_path: Path) -> Document | None:
        text = obj.get(self.text_field, "")
        if not str(text).strip():
            return None
        metadata: dict = {
            "source": str(file_path),
            "filename": file_path.name,
        }
        for k, v in obj.items():
            if k != self.text_field and isinstance(v, _SCALAR):
                metadata[k] = v
        return Document(text=str(text), metadata=metadata)

    async def load(self) -> AsyncGenerator[Document, None]:
        for file_path in self._iter_paths():
            ext = file_path.suffix.lower()
            try:
                if ext == ".json":
                    async with aiofiles.open(file_path, encoding="utf-8") as f:
                        content = await f.read()
                    data = json.loads(content)
                    if isinstance(data, dict):
                        data = [data]
                    if not isinstance(data, list):
                        raise ConnectorError(
                            f"'{file_path}': expected a JSON array or object, got {type(data).__name__}"
                        )
                    for obj in data:
                        doc = self._obj_to_document(obj, file_path)
                        if doc:
                            yield doc

                elif ext == ".jsonl":
                    async with aiofiles.open(file_path, encoding="utf-8") as f:
                        async for line in f:
                            line = line.strip()
                            if not line:
                                continue
                            obj = json.loads(line)
                            doc = self._obj_to_document(obj, file_path)
                            if doc:
                                yield doc

            except ConnectorError:
                raise
            except Exception as e:
                raise ConnectorError(f"Error reading JSON '{file_path}': {e}") from e
