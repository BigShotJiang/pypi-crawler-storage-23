import os
from collections.abc import AsyncGenerator
from pathlib import Path

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError

_SUPPORTED_EXTENSIONS = frozenset({
    ".txt", ".md", ".rst", ".text",
    ".csv",
    ".pdf",
    ".docx", ".doc",
    ".json", ".jsonl",
})


class MultiConnector:
    """
    Connector that loads ALL supported file types from a directory.

    Automatically picks the right sub-connector for each file based on its
    extension (.txt/.md/.rst, .csv, .pdf, .docx/.doc, .json/.jsonl).
    """

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        if not self.path.exists():
            raise ConnectorError(f"Path not found: {self.path}")
        if not self.path.is_dir():
            raise ConnectorError(
                f"MultiConnector requires a directory, got a file: {self.path}. "
                "Use the specific connector (TxtConnector, PdfConnector, …) for single files."
            )

    def _iter_paths(self) -> list[Path]:
        files = []
        for root, _, filenames in os.walk(self.path):
            for name in filenames:
                p = Path(root) / name
                if p.suffix.lower() in _SUPPORTED_EXTENSIONS:
                    files.append(p)
        return sorted(files)

    async def load(self) -> AsyncGenerator[Document, None]:
        from pysynapse.connectors.document.csv import CsvConnector
        from pysynapse.connectors.document.docx import DocxConnector
        from pysynapse.connectors.document.json import JsonConnector
        from pysynapse.connectors.document.pdf import PdfConnector
        from pysynapse.connectors.document.txt import TxtConnector

        files = self._iter_paths()
        if not files:
            raise ConnectorError(
                f"No supported files found in '{self.path}'. "
                f"Supported extensions: {sorted(_SUPPORTED_EXTENSIONS)}"
            )

        for file_path in files:
            ext = file_path.suffix.lower()
            if ext in {".txt", ".md", ".rst", ".text"}:
                connector = TxtConnector(file_path)
            elif ext == ".csv":
                connector = CsvConnector(file_path)
            elif ext == ".pdf":
                connector = PdfConnector(file_path)
            elif ext in {".docx", ".doc"}:
                connector = DocxConnector(file_path)
            elif ext in {".json", ".jsonl"}:
                connector = JsonConnector(file_path)
            else:
                continue

            async for doc in connector.load():
                yield doc
