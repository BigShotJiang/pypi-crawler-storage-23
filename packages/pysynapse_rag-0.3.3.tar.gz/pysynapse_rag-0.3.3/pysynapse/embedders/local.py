import asyncio
from functools import partial

from pysynapse.core.exceptions import EmbedderError


class LocalEmbedder:
    """
    Local embedder based on sentence-transformers.

    Runs synchronously in an executor to avoid blocking the asyncio loop.
    Default model: 'all-MiniLM-L6-v2' (384 dimensions, fast and efficient).
    """

    DEFAULT_MODEL = "all-MiniLM-L6-v2"

    def __init__(self, model_name: str = DEFAULT_MODEL) -> None:
        self.model_name = model_name
        self._model = None  # lazy load

    def _get_model(self):
        if self._model is None:
            try:
                from sentence_transformers import SentenceTransformer
            except ImportError as e:
                raise EmbedderError(
                    "sentence-transformers is not installed. "
                    "Install it with: pip install sentence-transformers"
                ) from e
            self._model = SentenceTransformer(self.model_name)
        return self._model

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Encode a list of texts into embedding vectors (async via executor)."""
        if not texts:
            return []
        loop = asyncio.get_event_loop()
        try:
            model = self._get_model()
            result = await loop.run_in_executor(
                None,
                partial(model.encode, texts, convert_to_numpy=True, show_progress_bar=False),
            )
            return result.tolist()
        except Exception as e:
            raise EmbedderError(f"Embedding error: {e}") from e

    async def embed_one(self, text: str) -> list[float]:
        results = await self.embed([text])
        return results[0]
