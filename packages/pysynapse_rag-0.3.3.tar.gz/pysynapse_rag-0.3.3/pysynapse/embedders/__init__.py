from pysynapse.embedders.local import LocalEmbedder

__all__ = ["LocalEmbedder"]
