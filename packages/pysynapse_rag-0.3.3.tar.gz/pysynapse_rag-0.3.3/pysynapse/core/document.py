from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4


@dataclass
class Document:
    """Universal data unit flowing through the pysynapse pipeline."""

    text: str
    metadata: dict[str, Any] = field(default_factory=dict)
    id: str = field(default_factory=lambda: str(uuid4()))

    def __repr__(self) -> str:
        preview = self.text[:80].replace("\n", " ")
        return f"Document(id={self.id!r}, text={preview!r}...)"
