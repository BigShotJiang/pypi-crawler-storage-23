from collections.abc import AsyncIterator
from typing import Protocol, runtime_checkable

from pysynapse.core.document import Document


@runtime_checkable
class DataConnector(Protocol):
    """Protocol implemented by every datasource connector."""

    def load(self) -> AsyncIterator[Document]:
        """Load and yield documents from the source."""
        ...


@runtime_checkable
class Embedder(Protocol):
    """Protocol implemented by every embedding engine."""

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Return one embedding vector per text."""
        ...

    async def embed_one(self, text: str) -> list[float]:
        """Convenience: embed a single text."""
        results = await self.embed([text])
        return results[0]


@runtime_checkable
class VectorStore(Protocol):
    """Protocol implemented by every vector store backend."""

    async def add(
        self,
        documents: list[Document],
        embeddings: list[list[float]],
    ) -> None:
        """Persist documents with their embeddings."""
        ...

    async def search(
        self,
        query_embedding: list[float],
        k: int = 5,
    ) -> list[Document]:
        """Return the k nearest documents."""
        ...
