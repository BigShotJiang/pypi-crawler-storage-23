from pysynapse.processors.chunker import RecursiveCharacterChunker

__all__ = ["RecursiveCharacterChunker"]
