from pysynapse.core.document import Document


class RecursiveCharacterChunker:
    """
    Split text into target-size chunks with overlap,
    respecting a hierarchy of separators.

    Pure Python, no external dependency.
    """

    DEFAULT_SEPARATORS = ["\n\n", "\n", ". ", " ", ""]

    def __init__(
        self,
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        separators: list[str] | None = None,
    ) -> None:
        if chunk_overlap >= chunk_size:
            raise ValueError("chunk_overlap must be less than chunk_size")
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.separators = separators or self.DEFAULT_SEPARATORS

    def split_text(self, text: str) -> list[str]:
        """Return a list of chunks from raw text."""
        return self._split(text, self.separators)

    def split_document(self, document: Document) -> list[Document]:
        """Split a Document into multiple Documents with inherited metadata."""
        chunks = self.split_text(document.text)
        return [
            Document(
                text=chunk,
                metadata={**document.metadata, "chunk_index": i, "source_id": document.id},
            )
            for i, chunk in enumerate(chunks)
        ]

    def split_documents(self, documents: list[Document]) -> list[Document]:
        result = []
        for doc in documents:
            result.extend(self.split_document(doc))
        return result

    # --- Internal logic ---

    def _split(self, text: str, separators: list[str]) -> list[str]:
        if not text.strip():
            return []

        # Find the first separator that produces multiple parts
        separator = separators[-1]  # fallback: empty separator (char by char)
        for sep in separators:
            if sep == "" or sep in text:
                separator = sep
                break

        if separator:
            parts = text.split(separator)
        else:
            parts = list(text)

        chunks: list[str] = []
        current = ""

        for part in parts:
            candidate = (current + separator + part).lstrip(separator) if current else part

            if len(candidate) <= self.chunk_size:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                # If the part itself exceeds chunk_size, re-split with the next separator
                if len(part) > self.chunk_size and len(separators) > 1:
                    sub_chunks = self._split(part, separators[1:])
                    chunks.extend(sub_chunks[:-1])
                    current = sub_chunks[-1] if sub_chunks else ""
                else:
                    current = part

        if current:
            chunks.append(current)

        return self._apply_overlap(chunks)

    def _apply_overlap(self, chunks: list[str]) -> list[str]:
        if self.chunk_overlap == 0 or len(chunks) <= 1:
            return chunks

        result = [chunks[0]]
        for chunk in chunks[1:]:
            overlap_text = result[-1][-self.chunk_overlap:]
            merged = overlap_text + " " + chunk if overlap_text else chunk
            result.append(merged)
        return result
