import asyncio
import concurrent.futures
import inspect
import logging
from collections.abc import Callable
from pathlib import Path
from typing import AsyncIterator

from pysynapse.core.document import Document
from pysynapse.core.exceptions import EmbedderError, StoreError
from pysynapse.core.protocols import DataConnector, Embedder, VectorStore
from pysynapse.processors.chunker import RecursiveCharacterChunker

logger = logging.getLogger(__name__)


def _run_sync(coro):
    """Run *coro* from a synchronous context.

    Works in plain scripts (no running loop) and inside a running loop
    such as Jupyter notebooks, by delegating to a fresh thread in the
    latter case.
    """
    try:
        asyncio.get_running_loop()
        # A loop is already running — delegate to a new thread.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    except RuntimeError:
        return asyncio.run(coro)


async def _with_retry(fn: Callable, max_retries: int, base_delay: float):
    """Retry *fn* on EmbedderError / StoreError with exponential back-off."""
    for attempt in range(max_retries):
        try:
            return await fn()
        except (EmbedderError, StoreError):
            if attempt == max_retries - 1:
                raise
            wait = base_delay * (2 ** attempt)
            logger.warning(
                "Transient error on attempt %d/%d — retrying in %.1fs.",
                attempt + 1,
                max_retries,
                wait,
            )
            await asyncio.sleep(wait)


class Pipeline:
    """
    Orchestrates the flow: DataConnector → Chunker → Embedder → VectorStore.

    Usage:
        # Basic
        pipeline = Pipeline(connector=..., embedder=..., store=...)
        count = await pipeline.run()
        results = await pipeline.search("my question", k=5)

        # As a context manager (auto-closes the store)
        async with Pipeline(connector=..., embedder=..., store=...) as pipeline:
            count = await pipeline.run()
            results = await pipeline.search("my question", k=5)
    """

    def __init__(
        self,
        connector: DataConnector,
        embedder: Embedder,
        store: VectorStore,
        chunker: RecursiveCharacterChunker | None = None,
        batch_size: int = 32,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        on_progress: Callable[[int], None] | None = None,
    ) -> None:
        self.connector = connector
        self.embedder = embedder
        self.store = store
        self.chunker = chunker or RecursiveCharacterChunker()
        self.batch_size = batch_size
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.on_progress = on_progress

    # ------------------------------------------------------------------ #
    # Factory                                                              #
    # ------------------------------------------------------------------ #

    @classmethod
    def from_files(
        cls,
        path: str | Path,
        *,
        embedder=None,
        persist_directory: str = "./.pysynapse",
        collection_name: str = "pysynapse",
        model_name: str = "all-MiniLM-L6-v2",
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        **kwargs,
    ) -> "Pipeline":
        """
        Create a ready-to-use Pipeline from a file or directory.

        Auto-detects the connector based on file extension.
        Uses LocalEmbedder (default) and a persistent ChromaStore with sensible defaults.

        Args:
            path:               File or directory to index.
            embedder:           Custom embedder instance. Defaults to LocalEmbedder.
            persist_directory:  Where ChromaDB stores its data on disk.
            collection_name:    ChromaDB collection name.
            model_name:         sentence-transformers model (only used if embedder is None).
            chunk_size:         Max characters per chunk.
            chunk_overlap:      Overlap between consecutive chunks.
            **kwargs:           Extra arguments forwarded to Pipeline.__init__
                                (batch_size, max_retries, retry_delay, on_progress).

        Example::

            async with Pipeline.from_files("./my_docs") as pipeline:
                await pipeline.run()
                results = await pipeline.search("What is RAG?", k=3)
        """
        from pysynapse.stores.chroma import ChromaConfig, ChromaStore

        path = Path(path)
        connector = cls._connector_for(path)
        if embedder is None:
            from pysynapse.embedders.local import LocalEmbedder
            embedder = LocalEmbedder(model_name=model_name)
        store = ChromaStore(ChromaConfig(
            persist_directory=persist_directory,
            collection_name=collection_name,
        ))
        chunker = RecursiveCharacterChunker(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        return cls(connector=connector, embedder=embedder, store=store, chunker=chunker, **kwargs)

    @staticmethod
    def _connector_for(path: Path) -> DataConnector:
        """Return the right connector for *path* based on its extension."""
        if path.is_dir():
            from pysynapse.connectors.document.multi import MultiConnector
            return MultiConnector(path)

        ext = path.suffix.lower()
        if ext == ".csv":
            from pysynapse.connectors.document.csv import CsvConnector
            return CsvConnector(path)
        if ext == ".pdf":
            from pysynapse.connectors.document.pdf import PdfConnector
            return PdfConnector(path)
        if ext in {".docx", ".doc"}:
            from pysynapse.connectors.document.docx import DocxConnector
            return DocxConnector(path)
        if ext in {".json", ".jsonl"}:
            from pysynapse.connectors.document.json import JsonConnector
            return JsonConnector(path)
        from pysynapse.connectors.document.txt import TxtConnector
        return TxtConnector(path)

    # ------------------------------------------------------------------ #
    # Async context manager                                                #
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "Pipeline":
        return self

    async def __aexit__(self, *_) -> None:
        close = getattr(self.store, "close", None)
        if callable(close):
            close()

    # ------------------------------------------------------------------ #
    # Sync context manager                                                 #
    # ------------------------------------------------------------------ #

    def __enter__(self) -> "Pipeline":
        return self

    def __exit__(self, *_) -> None:
        close = getattr(self.store, "close", None)
        if callable(close):
            close()

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def run(self) -> int:
        """
        Run the full pipeline: load → chunk → embed → store.

        Returns the total number of chunks indexed.
        Calls on_progress(total_so_far) after each batch if provided.
        """
        total = 0
        batch: list[Document] = []

        async for raw_doc in self._load():
            chunks = self.chunker.split_document(raw_doc)
            batch.extend(chunks)

            while len(batch) >= self.batch_size:
                to_process = batch[: self.batch_size]
                batch = batch[self.batch_size :]
                await _with_retry(
                    lambda b=to_process: self._index_batch(b),
                    self.max_retries,
                    self.retry_delay,
                )
                total += len(to_process)
                logger.info("Indexed batch: %d chunks (total so far: %d).", len(to_process), total)
                if self.on_progress:
                    self.on_progress(total)

        if batch:
            await _with_retry(
                lambda b=batch: self._index_batch(b),
                self.max_retries,
                self.retry_delay,
            )
            total += len(batch)
            logger.info("Indexed final batch: %d chunks (total: %d).", len(batch), total)
            if self.on_progress:
                self.on_progress(total)

        logger.info("Pipeline complete: %d chunks indexed.", total)
        return total

    async def search(
        self,
        query: str,
        k: int = 5,
        score_threshold: float | None = None,
        where: dict | None = None,
    ) -> list[Document]:
        """
        Vector search — returns the k nearest documents to the query.

        Each result has 'distance' and 'score' fields in its metadata.
        score = 1 - distance  (0 = no match, 1 = identical).

        Args:
            query:            Natural language query string.
            k:                Maximum number of results to return.
            score_threshold:  If set, exclude results with score < threshold.
            where:            Metadata filter dict passed to the vector store.
                              Example: {"filename": "report.pdf"}
        """
        query_embedding = await self.embedder.embed_one(query)
        sig = inspect.signature(self.store.search)
        if where is not None and "where" in sig.parameters:
            results = await self.store.search(query_embedding, k=k, where=where)
        else:
            results = await self.store.search(query_embedding, k=k)

        for doc in results:
            doc.metadata["score"] = round(1 - doc.metadata.get("distance", 1.0), 4)

        if score_threshold is not None:
            results = [doc for doc in results if doc.metadata["score"] >= score_threshold]
        return results

    async def count(self) -> int:
        """Return the number of chunks currently indexed in the vector store."""
        count_fn = getattr(self.store, "count", None)
        if not callable(count_fn):
            raise StoreError("This store does not support count()")
        return await count_fn()

    async def clear(self) -> None:
        """Remove all documents from the vector store."""
        clear_fn = getattr(self.store, "clear", None)
        if not callable(clear_fn):
            raise StoreError("This store does not support clear()")
        await clear_fn()

    # ------------------------------------------------------------------ #
    # Sync convenience wrappers                                            #
    # ------------------------------------------------------------------ #

    def run_sync(self) -> int:
        """Synchronous wrapper for :meth:`run`. Safe to call from plain scripts."""
        return _run_sync(self.run())

    def search_sync(
        self,
        query: str,
        k: int = 5,
        score_threshold: float | None = None,
        where: dict | None = None,
    ) -> list[Document]:
        """Synchronous wrapper for :meth:`search`."""
        return _run_sync(self.search(query, k=k, score_threshold=score_threshold, where=where))

    def count_sync(self) -> int:
        """Synchronous wrapper for :meth:`count`."""
        return _run_sync(self.count())

    def clear_sync(self) -> None:
        """Synchronous wrapper for :meth:`clear`."""
        _run_sync(self.clear())

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    async def _load(self) -> AsyncIterator[Document]:
        async for doc in self.connector.load():
            yield doc

    async def _index_batch(self, documents: list[Document]) -> None:
        texts = [doc.text for doc in documents]
        embeddings = await self.embedder.embed(texts)
        await self.store.add(documents, embeddings)
        logger.debug("Stored batch of %d chunks.", len(documents))
