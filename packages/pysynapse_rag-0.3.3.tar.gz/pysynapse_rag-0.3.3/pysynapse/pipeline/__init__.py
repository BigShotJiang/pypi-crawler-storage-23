from pysynapse.pipeline.pipeline import Pipeline

__all__ = ["Pipeline"]
