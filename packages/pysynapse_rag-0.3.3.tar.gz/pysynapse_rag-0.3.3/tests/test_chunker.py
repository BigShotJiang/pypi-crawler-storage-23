import pytest

from pysynapse.core.document import Document
from pysynapse.processors.chunker import RecursiveCharacterChunker


def test_split_short_text_returns_single_chunk():
    chunker = RecursiveCharacterChunker(chunk_size=512)
    result = chunker.split_text("Hello world")
    assert result == ["Hello world"]


def test_split_long_text_produces_multiple_chunks():
    chunker = RecursiveCharacterChunker(chunk_size=50, chunk_overlap=0)
    text = "First paragraph.\n\nSecond paragraph.\n\nThird paragraph."
    result = chunker.split_text(text)
    assert len(result) > 1
    for chunk in result:
        # With overlap at 0, chunks may slightly exceed chunk_size;
        # the test mainly verifies that splitting occurs.
        assert len(chunk) > 0


def test_split_empty_text_returns_empty():
    chunker = RecursiveCharacterChunker()
    assert chunker.split_text("") == []
    assert chunker.split_text("   ") == []


def test_split_document_inherits_metadata():
    chunker = RecursiveCharacterChunker(chunk_size=30, chunk_overlap=0)
    doc = Document(text="A long enough text to be split into several chunks.", metadata={"source": "test.txt"})
    chunks = chunker.split_document(doc)
    assert len(chunks) >= 1
    for i, chunk in enumerate(chunks):
        assert chunk.metadata["source"] == "test.txt"
        assert chunk.metadata["source_id"] == doc.id
        assert chunk.metadata["chunk_index"] == i


def test_chunk_overlap_raises_on_invalid():
    with pytest.raises(ValueError):
        RecursiveCharacterChunker(chunk_size=100, chunk_overlap=100)


def test_split_documents_multiple():
    chunker = RecursiveCharacterChunker(chunk_size=20, chunk_overlap=0)
    docs = [
        Document(text="Short text."),
        Document(text="Another slightly longer text for testing."),
    ]
    result = chunker.split_documents(docs)
    assert len(result) >= 2
