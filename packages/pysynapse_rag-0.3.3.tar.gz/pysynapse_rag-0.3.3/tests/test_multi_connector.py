"""
Tests for MultiConnector — loads mixed file types from a directory.
"""
import pytest

from pysynapse.connectors.document.multi import MultiConnector
from pysynapse.core.exceptions import ConnectorError


@pytest.mark.asyncio
async def test_multi_connector_loads_txt_files(tmp_path):
    (tmp_path / "a.txt").write_text("Hello from a text file.")
    (tmp_path / "b.md").write_text("Hello from a markdown file.")

    docs = []
    async for doc in MultiConnector(tmp_path).load():
        docs.append(doc)

    assert len(docs) == 2
    filenames = {d.metadata["filename"] for d in docs}
    assert filenames == {"a.txt", "b.md"}


@pytest.mark.asyncio
async def test_multi_connector_loads_csv(tmp_path):
    (tmp_path / "data.csv").write_text("text,label\nhello world,greeting\ngoodbye,farewell\n")

    docs = []
    async for doc in MultiConnector(tmp_path).load():
        docs.append(doc)

    assert len(docs) == 2
    assert all(d.metadata["filename"] == "data.csv" for d in docs)


@pytest.mark.asyncio
async def test_multi_connector_skips_unsupported_extensions(tmp_path):
    (tmp_path / "valid.txt").write_text("Valid file content.")
    (tmp_path / "ignored.xyz").write_text("This should be ignored.")
    (tmp_path / "ignored.log").write_text("This too.")

    docs = []
    async for doc in MultiConnector(tmp_path).load():
        docs.append(doc)

    assert len(docs) == 1
    assert docs[0].metadata["filename"] == "valid.txt"


@pytest.mark.asyncio
async def test_multi_connector_scans_subdirectories(tmp_path):
    sub = tmp_path / "sub"
    sub.mkdir()
    (tmp_path / "root.txt").write_text("Root file.")
    (sub / "nested.txt").write_text("Nested file.")

    docs = []
    async for doc in MultiConnector(tmp_path).load():
        docs.append(doc)

    assert len(docs) == 2
    filenames = {d.metadata["filename"] for d in docs}
    assert filenames == {"root.txt", "nested.txt"}


@pytest.mark.asyncio
async def test_multi_connector_empty_directory_raises(tmp_path):
    with pytest.raises(ConnectorError, match="No supported files"):
        async for _ in MultiConnector(tmp_path).load():
            pass


def test_multi_connector_file_path_raises(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("test")
    with pytest.raises(ConnectorError, match="requires a directory"):
        MultiConnector(f)


def test_multi_connector_nonexistent_path_raises():
    with pytest.raises(ConnectorError, match="Path not found"):
        MultiConnector("/nonexistent/path/xyz_abc")
