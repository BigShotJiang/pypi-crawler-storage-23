import tempfile
from pathlib import Path

import pytest

from pysynapse.connectors.document.txt import TxtConnector
from pysynapse.core.exceptions import ConnectorError


@pytest.mark.asyncio
async def test_load_single_txt_file():
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False, encoding="utf-8") as f:
        f.write("Hello world!")
        tmp_path = Path(f.name)

    try:
        connector = TxtConnector(tmp_path)
        docs = [doc async for doc in connector.load()]
        assert len(docs) == 1
        assert docs[0].text == "Hello world!"
        assert docs[0].metadata["filename"] == tmp_path.name
    finally:
        tmp_path.unlink()


@pytest.mark.asyncio
async def test_load_directory_of_txt_files():
    with tempfile.TemporaryDirectory() as tmp_dir:
        for i, content in enumerate(["First", "Second", "Third"]):
            (Path(tmp_dir) / f"file_{i}.txt").write_text(content, encoding="utf-8")

        connector = TxtConnector(tmp_dir)
        docs = [doc async for doc in connector.load()]
        assert len(docs) == 3
        texts = {doc.text for doc in docs}
        assert "First" in texts


@pytest.mark.asyncio
async def test_load_empty_file_is_skipped():
    with tempfile.NamedTemporaryFile(suffix=".txt", mode="w", delete=False, encoding="utf-8") as f:
        f.write("   ")
        tmp_path = Path(f.name)

    try:
        connector = TxtConnector(tmp_path)
        docs = [doc async for doc in connector.load()]
        assert docs == []
    finally:
        tmp_path.unlink()


def test_nonexistent_path_raises():
    with pytest.raises(ConnectorError):
        TxtConnector("/path/that/does/not/exist.txt")


def test_wrong_extension_raises():
    with tempfile.NamedTemporaryFile(suffix=".xyz", delete=False) as f:
        tmp_path = Path(f.name)
    try:
        with pytest.raises(ConnectorError):
            TxtConnector(tmp_path)
            # Error is raised at init
    finally:
        tmp_path.unlink(missing_ok=True)
