"""
Tests for features added in 0.3.3:
  - Pipeline.count() / count_sync()
  - Pipeline.clear() / clear_sync()
  - score added to result metadata
  - where= metadata filtering in search()
  - JsonConnector (.json and .jsonl)
  - embedder= kwarg in Pipeline.from_files()
"""
import json
import tempfile
from collections.abc import AsyncGenerator
from pathlib import Path

import pytest

from pysynapse.core.document import Document
from pysynapse.core.exceptions import StoreError
from pysynapse.pipeline.pipeline import Pipeline
from pysynapse.processors.chunker import RecursiveCharacterChunker


# ------------------------------------------------------------------ #
# Shared fakes                                                         #
# ------------------------------------------------------------------ #

class FakeEmbedder:
    async def embed(self, texts):
        return [[0.0] * 4 for _ in texts]

    async def embed_one(self, text):
        return [0.0] * 4


class FakeStore:
    def __init__(self):
        self.documents: list[Document] = []
        self._cleared = False

    async def add(self, documents, embeddings):
        self.documents.extend(documents)

    async def search(self, query_embedding, k=5):
        return self.documents[:k]

    async def count(self):
        return len(self.documents)

    async def clear(self):
        self.documents.clear()
        self._cleared = True


class FakeConnector:
    def __init__(self, texts):
        self.texts = texts

    async def load(self) -> AsyncGenerator[Document, None]:
        for text in self.texts:
            yield Document(text=text, metadata={"source": "fake"})


# ------------------------------------------------------------------ #
# count()                                                              #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_count_returns_indexed_document_count():
    store = FakeStore()
    pipeline = Pipeline(
        connector=FakeConnector(["doc one", "doc two", "doc three"]),
        embedder=FakeEmbedder(),
        store=store,
        chunker=RecursiveCharacterChunker(chunk_size=512, chunk_overlap=0),
    )
    await pipeline.run()
    assert await pipeline.count() == 3


@pytest.mark.asyncio
async def test_count_raises_if_store_does_not_support_it():
    class MinimalStore:
        async def add(self, documents, embeddings):
            pass
        async def search(self, query_embedding, k=5):
            return []

    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=MinimalStore(),
    )
    with pytest.raises(StoreError):
        await pipeline.count()


def test_count_sync_works():
    store = FakeStore()
    pipeline = Pipeline(
        connector=FakeConnector(["a", "b"]),
        embedder=FakeEmbedder(),
        store=store,
        chunker=RecursiveCharacterChunker(chunk_size=512, chunk_overlap=0),
    )
    pipeline.run_sync()
    assert pipeline.count_sync() == 2


# ------------------------------------------------------------------ #
# clear()                                                              #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_clear_empties_store():
    store = FakeStore()
    pipeline = Pipeline(
        connector=FakeConnector(["some text"]),
        embedder=FakeEmbedder(),
        store=store,
    )
    await pipeline.run()
    assert await pipeline.count() == 1
    await pipeline.clear()
    assert store._cleared
    assert await pipeline.count() == 0


@pytest.mark.asyncio
async def test_clear_raises_if_store_does_not_support_it():
    class MinimalStore:
        async def add(self, documents, embeddings):
            pass
        async def search(self, query_embedding, k=5):
            return []

    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=MinimalStore(),
    )
    with pytest.raises(StoreError):
        await pipeline.clear()


def test_clear_sync_works():
    store = FakeStore()
    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=store,
    )
    pipeline.run_sync()
    pipeline.clear_sync()
    assert store._cleared


# ------------------------------------------------------------------ #
# score in metadata                                                    #
# ------------------------------------------------------------------ #

class StoreWithDistances(FakeStore):
    async def search(self, query_embedding, k=5):
        return [
            Document(text="near", metadata={"distance": 0.1}),
            Document(text="far",  metadata={"distance": 0.9}),
        ]


@pytest.mark.asyncio
async def test_search_adds_score_to_metadata():
    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=StoreWithDistances(),
    )
    results = await pipeline.search("q")
    for doc in results:
        assert "score" in doc.metadata
    assert results[0].metadata["score"] == pytest.approx(0.9, abs=1e-4)
    assert results[1].metadata["score"] == pytest.approx(0.1, abs=1e-4)


@pytest.mark.asyncio
async def test_score_defaults_to_zero_when_no_distance():
    """Documents without a distance field should get score=0."""
    class StoreNoDist(FakeStore):
        async def search(self, query_embedding, k=5):
            return [Document(text="no dist", metadata={})]

    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=StoreNoDist(),
    )
    results = await pipeline.search("q")
    assert results[0].metadata["score"] == pytest.approx(0.0, abs=1e-4)


# ------------------------------------------------------------------ #
# where= metadata filtering                                            #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_where_passed_to_store_when_supported():
    received_where = {}

    class FilterableStore(FakeStore):
        async def search(self, query_embedding, k=5, where=None):
            received_where["value"] = where
            return []

    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=FilterableStore(),
    )
    await pipeline.search("q", where={"filename": "report.pdf"})
    assert received_where["value"] == {"filename": "report.pdf"}


@pytest.mark.asyncio
async def test_where_not_passed_when_store_does_not_support_it():
    """Pipeline must not crash when store.search() has no where= param."""
    call_args = {}

    class OldStore(FakeStore):
        async def search(self, query_embedding, k=5):
            call_args["ok"] = True
            return []

    pipeline = Pipeline(
        connector=FakeConnector(["text"]),
        embedder=FakeEmbedder(),
        store=OldStore(),
    )
    results = await pipeline.search("q", where={"x": "y"})
    assert call_args.get("ok")
    assert results == []


# ------------------------------------------------------------------ #
# JsonConnector                                                        #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_json_connector_loads_array():
    data = [
        {"text": "hello world", "author": "alice"},
        {"text": "foo bar baz", "category": "test"},
    ]
    with tempfile.NamedTemporaryFile(
        suffix=".json", mode="w", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        tmp = Path(f.name)

    try:
        from pysynapse.connectors.document.json import JsonConnector
        docs = [doc async for doc in JsonConnector(tmp).load()]
        assert len(docs) == 2
        assert docs[0].text == "hello world"
        assert docs[0].metadata["author"] == "alice"
        assert docs[1].text == "foo bar baz"
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_json_connector_loads_single_object():
    data = {"text": "singleton document"}
    with tempfile.NamedTemporaryFile(
        suffix=".json", mode="w", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        tmp = Path(f.name)

    try:
        from pysynapse.connectors.document.json import JsonConnector
        docs = [doc async for doc in JsonConnector(tmp).load()]
        assert len(docs) == 1
        assert docs[0].text == "singleton document"
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_jsonl_connector_loads_lines():
    lines = [
        {"text": "line one", "id": 1},
        {"text": "line two", "id": 2},
        {"text": "", "id": 3},  # empty text — should be skipped
    ]
    with tempfile.NamedTemporaryFile(
        suffix=".jsonl", mode="w", delete=False, encoding="utf-8"
    ) as f:
        for obj in lines:
            f.write(json.dumps(obj) + "\n")
        tmp = Path(f.name)

    try:
        from pysynapse.connectors.document.json import JsonConnector
        docs = [doc async for doc in JsonConnector(tmp).load()]
        assert len(docs) == 2
        assert docs[0].text == "line one"
        assert docs[1].text == "line two"
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_json_connector_custom_text_field():
    data = [{"body": "custom field text", "score": 42}]
    with tempfile.NamedTemporaryFile(
        suffix=".json", mode="w", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        tmp = Path(f.name)

    try:
        from pysynapse.connectors.document.json import JsonConnector
        docs = [doc async for doc in JsonConnector(tmp, text_field="body").load()]
        assert len(docs) == 1
        assert docs[0].text == "custom field text"
        assert docs[0].metadata["score"] == 42
    finally:
        tmp.unlink()


@pytest.mark.asyncio
async def test_json_connector_skips_non_scalar_metadata():
    """Non-scalar fields (lists, dicts) must not appear in metadata."""
    data = [{"text": "hello", "tags": ["a", "b"], "nested": {"x": 1}}]
    with tempfile.NamedTemporaryFile(
        suffix=".json", mode="w", delete=False, encoding="utf-8"
    ) as f:
        json.dump(data, f)
        tmp = Path(f.name)

    try:
        from pysynapse.connectors.document.json import JsonConnector
        docs = [doc async for doc in JsonConnector(tmp).load()]
        assert "tags" not in docs[0].metadata
        assert "nested" not in docs[0].metadata
    finally:
        tmp.unlink()


# ------------------------------------------------------------------ #
# embedder= in from_files()                                            #
# ------------------------------------------------------------------ #

@pytest.mark.asyncio
async def test_from_files_uses_custom_embedder():
    """from_files() should use the provided embedder, not LocalEmbedder."""
    with tempfile.NamedTemporaryFile(
        suffix=".txt", mode="w", delete=False, encoding="utf-8"
    ) as f:
        f.write("hello from custom embedder")
        tmp = Path(f.name)

    embed_calls = []

    class TrackedEmbedder:
        async def embed(self, texts):
            embed_calls.append(texts)
            return [[0.1] * 4 for _ in texts]

        async def embed_one(self, text):
            return [0.1] * 4

    try:
        import chromadb
    except ImportError:
        pytest.skip("chromadb not installed")

    try:
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as persist_dir:
            pipeline = Pipeline.from_files(
                tmp,
                embedder=TrackedEmbedder(),
                persist_directory=persist_dir,
            )
            async with pipeline:
                await pipeline.run()

        assert len(embed_calls) >= 1
    finally:
        tmp.unlink()
