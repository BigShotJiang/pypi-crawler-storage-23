# Traceflow AI (SDK)

AI/LLM observability: capture prompts, completions, tokens, cost, and latency; send traces to your dashboard.

## Install

```bash
pip install traceflow-ai[openai]
```

## Use

```python
import ai_obs
ai_obs.init(endpoint="http://localhost:8000")
# Use openai.chat.completions.create(...) as usual — traces appear in the dashboard
```

Optional: run the OBS-Agent dashboard (or your own ingest API) so traces have somewhere to go.

## PyPI

- **Package:** [traceflow-ai](https://pypi.org/project/traceflow-ai/)
- **Import:** `import ai_obs` (package name on PyPI is `traceflow-ai`)
