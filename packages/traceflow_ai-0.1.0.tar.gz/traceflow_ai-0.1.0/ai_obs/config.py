from typing import Any

_config: dict[str, Any] = {"endpoint": "", "enabled": True, "attributes": {}}


def get() -> dict[str, Any]:
    return _config


def set_endpoint(url: str) -> None:
    _config["endpoint"] = url.rstrip("/")


def set_attributes(attrs: dict[str, Any]) -> None:
    _config["attributes"] = attrs
