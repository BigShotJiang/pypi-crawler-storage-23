from .filter_utils_mixin import FilterUtilsMixin
from ..utils import safe_str_to_number
from django.db.models import Q
from django_filters import rest_framework as filters

class BaseFilter(FilterUtilsMixin, filters.FilterSet):
    def _apply_custom_method(self, queryset, filter_instance, filter_op, filter_value):
        """
        Dispatch to the custom filter method declared on the filter instance.

        Custom methods can return either:
        1. Just a Q object: Q(...)
        2. Tuple (queryset, Q): (modified_queryset, Q(...))

        The tuple form is useful for methods that need to apply annotations
        before constructing the Q object.

        Args:
            queryset: The queryset to filter
            filter_instance: The filter instance from the FilterSet
            filter_op: The filter operator (e.g., '__gte', '__lte', '')
            filter_value: The value to filter by

        Returns:
            tuple: (queryset, Q_object)
        """
        method_name = filter_instance.method
        method = getattr(self, method_name, None)

        if method is None:
            # Fallback: if method doesn't exist, use standard filtering
            return queryset, Q(**{f"{filter_instance.field_name}{filter_op}": filter_value})

        # Build the full field lookup with operator
        field_lookup = f"{filter_instance.field_name}{filter_op}"

        # Custom methods receive (queryset, field_name_with_operator, value)
        result = method(queryset, field_lookup, filter_value)

        # Support both return types:
        # 1. Tuple (queryset, Q): for methods that modify the queryset
        # 2. Just Q object: for simple transformations
        if isinstance(result, tuple):
            modified_queryset, q_object = result
            return modified_queryset, q_object
        else:
            # Just a Q object, queryset unchanged
            return queryset, result

    def parse_list_values(self, value_str):
        """
        Parses a string with values separated by && and returns a list.
        Automatically converts to numbers if possible.
        """
        if self.list_separator not in value_str:
            return None

        values = []
        for val in value_str.split(self.list_separator):
            val = val.strip()
            if self.is_numeric(val):
                values.append(safe_str_to_number(val))
            elif self.is_boolean(val):
                values.append(str(val).lower() == 'true')
            else:
                values.append(val)
        return values

    def filter_field(self, queryset, filter_name, filter_op, filter_value):
        """
        Generic method for filtering based on dynamic comparisons.
        """
        if filter_op is None:
            return queryset

        is_exclude_filter = filter_name.endswith('__not_in')

        if is_exclude_filter:
            # Remove the _not_in suffix to get the actual field name
            base_field_name = filter_name[:-8]  # Remove '__not_in'

            # Parse the values in the list
            list_values = self.parse_list_values(filter_value)

            if list_values:
                # Apply exclusion with __in
                return queryset.exclude(**{f"{base_field_name}__in": list_values})
            else:
                # If not a list, apply simple exclusion
                value_to_filter = (
                    safe_str_to_number(filter_value)
                    if self.is_numeric(filter_value)
                    else filter_value
                )
                return queryset.exclude(**{f"{base_field_name}{filter_op}": value_to_filter})

        value_to_filter = (
            safe_str_to_number(filter_value)) \
            if filter_op in ['__gte', '__lte', '__gt', '__lt', ''] and self.is_numeric(filter_value) \
            else filter_value

        if self.is_boolean(value_to_filter):
            value_to_filter = str(value_to_filter).lower() == 'true'

        return queryset.filter(**{f"{filter_name}{filter_op}": value_to_filter})

    def apply_or_filters(self, queryset, or_filters):
        """
        Apply OR filters using Q objects.
        Dispatches to custom methods when declared.
        """
        or_filter_subquery = Q()
        active_filters = self.get_filters()

        for or_filter in or_filters:
            filter_name, filter_op, filter_value = self.parse_filter(or_filter)

            if filter_name in active_filters:
                filter_instance = active_filters[filter_name]

                # Check if this filter uses a custom method
                if filter_instance.method:
                    # Use the unified method that returns (queryset, Q_object)
                    queryset, q_object = self._apply_custom_method(
                        queryset, filter_instance, filter_op, filter_value
                    )
                    or_filter_subquery |= q_object
                else:
                    # Standard field filtering
                    curr_filter_name = filter_instance.field_name
                    or_filter_subquery |= Q(**{f"{curr_filter_name}{filter_op}": filter_value})
            else:
                # Filter not defined in FilterSet, use as-is
                or_filter_subquery |= Q(**{f"{filter_name}{filter_op}": filter_value})

        queryset = queryset.filter(or_filter_subquery)
        return queryset

    def filter_queryset(self, queryset):
        """
        Overrides the `filter_queryset` method to apply filters dynamically.
        Invoked when Django applies filters to the query.

        Examples of possible filters:
        - filter[]=field1=@value1,field2>value2                                        (OR filter)

        - filter=field1=@value1,field2>value2                                          (OR filter)

        - filter[]=field1=@value1&filter[]=field2>value2                               (AND filter)

        - filter==field1@@value

        - filter[]=field1_not_in==10&&20&&30                                           (Exclude list)

        - filter[]=field1=@value1,field2=@value2&filter[]=field3=@value3               (OR then AND filter)
          Generates: ...WHERE (field1 LIKE '%value1%' OR field2 LIKE '%value2%') AND field3 LIKE '%value3%'
        """
        and_filter_key = 'and'
        or_filter_key = 'or'

        filter_without_brackets = self.data.get(self.filter_param, None)
        filter_with_brackets = self.data.getlist(self.filters_param, [])

        filter_category = {
            or_filter_key: filter_without_brackets.split(self.filters_separator) if filter_without_brackets else [],
            and_filter_key: []
        }

        for item in filter_with_brackets:
            if "," in item:
                filter_category[or_filter_key].extend(item.split(self.filters_separator))
            else:
                filter_category[and_filter_key].append(item)

        # Apply OR filters
        if filter_category[or_filter_key]:
            queryset = self.apply_or_filters(queryset, filter_category[or_filter_key])

        if not filter_category[and_filter_key]:
            return queryset

        # Get filters defined in the FilterSet
        active_filters = self.get_filters()

        # Apply AND filters
        for and_filter in filter_category[and_filter_key]:
            filter_name, filter_op, filter_value = self.parse_filter(and_filter)

            if filter_name in active_filters:
                filter_instance = active_filters[filter_name]

                # Check if this filter uses a custom method
                if filter_instance.method:
                    # Get (queryset, Q_object) from the custom method and apply it
                    queryset, q_object = self._apply_custom_method(
                        queryset, filter_instance, filter_op, filter_value
                    )
                    queryset = queryset.filter(q_object)
                else:
                    # Standard field filtering
                    queryset = self.filter_field(
                        queryset, filter_instance.field_name, filter_op, filter_value
                    )

        return queryset