"""
Fingerprint utility functions for computing SHA-256 based identity hashes.

These functions enable change detection to determine when entities need to be
created or updated by computing deterministic fingerprints from their field values.
"""

import hashlib
from datetime import datetime
from typing import Any, Dict, Iterable, Optional


def compute_sha256(data: str) -> str:
    """
    Compute SHA-256 hash of the input string.

    Args:
        data: The string to hash

    Returns:
        64-character lowercase hex string
    """
    return hashlib.sha256(data.encode('utf-8')).hexdigest()


def format_value(value: Any) -> Optional[str]:
    """
    Format a field value for inclusion in a fingerprint string.

    Args:
        value: The value to format

    Returns:
        Formatted string representation, or None if the value should be skipped
    """
    if value is None:
        return None

    if isinstance(value, bool):
        return "true" if value else "false"

    if isinstance(value, datetime):
        return value.isoformat()

    return str(value)


def build_fingerprint_string(fields: Dict[str, Any]) -> str:
    """
    Build a deterministic string from field name-value pairs.

    Fields are sorted by name for determinism. Fields with None values are skipped.

    Args:
        fields: Dictionary of field names to values

    Returns:
        Concatenated string of "name=value" pairs separated by "|"
    """
    parts = []
    for key in sorted(fields.keys()):
        formatted = format_value(fields[key])
        if formatted is not None:
            parts.append(f"{key}={formatted}")
    return "|".join(parts)


def format_id_list(ids: Iterable[int]) -> str:
    """
    Format a list of IDs as a comma-separated string.

    IDs are sorted numerically for determinism.

    Args:
        ids: Iterable of integer IDs

    Returns:
        Comma-separated string of sorted IDs
    """
    return ",".join(str(id_) for id_ in sorted(ids))


def combine_fingerprints(fingerprints: Iterable[str]) -> str:
    """
    Combine multiple fingerprints into a single hash.

    Fingerprints are sorted for determinism before being concatenated and hashed.

    Args:
        fingerprints: Iterable of fingerprint hex strings

    Returns:
        64-character lowercase hex string, or empty string if no fingerprints
    """
    sorted_fps = sorted(fingerprints)
    if not sorted_fps:
        return ""
    combined = "|".join(sorted_fps)
    return compute_sha256(combined)