def raise_for_status_codes(response, status_codes: tuple | list):
    """
    Raises HTTPError if the status code is in the specified list.

    Args:
        response: requests.Response object
        status_codes: Status codes that should raise an exception

    Raises:
        HTTPError: If status code is in status_codes
    """
    if response.status_code in status_codes:
        response.raise_for_status()

def raise_for_auth_errors(response):
    """
    Raises HTTPError only for authentication/authorization errors (401, 403).

    Args:
        response: requests.Response object

    Raises:
        HTTPError: If status code is 401 or 403
    """
    raise_for_status_codes(response, (401, 403))

def raise_for_external_catch(response):
    response.raise_for_status()
