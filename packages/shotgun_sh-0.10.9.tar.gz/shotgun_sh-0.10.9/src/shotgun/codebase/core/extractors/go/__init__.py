"""Go language extractor."""

from __future__ import annotations

from .extractor import GoExtractor

__all__ = ["GoExtractor"]
