"""aichat2md - Convert AI chat conversations to structured Markdown."""

__version__ = "1.3.1"
__author__ = "PlaceNameDay"
__description__ = "Convert AI chat conversations to structured Markdown"
