"""
graph.py
"""


class Graph:
    def __init__(self):
        pass
