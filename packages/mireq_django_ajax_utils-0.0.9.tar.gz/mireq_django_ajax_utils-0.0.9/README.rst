=================
Django ajax utils
=================

|version| |downloads| |license|

This is small set of ajax utility functions. It's used mostly in my internal
projects.

Install
-------

.. code:: bash

	pip install mireq-django-ajax-utils

.. |version| image:: https://badge.fury.io/py/mireq-django-ajax-utils.svg
	:target: https://pypi.python.org/pypi/mireq-django-ajax-utils/

.. |downloads| image:: https://img.shields.io/pypi/dw/mireq-django-ajax-utils.svg
	:target: https://pypi.python.org/pypi/mireq-django-ajax-utils/

.. |license| image:: https://img.shields.io/pypi/l/mireq-django-ajax-utils.svg
	:target: https://pypi.python.org/pypi/mireq-django-ajax-utils/
