Models
======

.. currentmodule:: terminusgps_notifications.models

.. autoclass:: MessagePackage
    :autoclasstoc:
    :members:

.. autoclass:: TerminusgpsNotificationsCustomer
    :autoclasstoc:
    :members:

.. autoclass:: WialonToken
    :autoclasstoc:
    :members:

.. autoclass:: WialonNotification
    :members:
