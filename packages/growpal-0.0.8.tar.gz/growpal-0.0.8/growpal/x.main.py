import os
import numpy as np
from aegon.libutils               import readxyzs, writexyzs, rename, cutter_energy
from growpal.libgrowpal           import growpal_parallel, display_info
from growpal.libselect_clustering import selectbyclustering_comb_prom
from aegon.libdisc_usr            import comparator_usr_serial
#from aegon.libcalc_lj import opt_LJ_parallel
from libcalc_lj_claude import opt_LJ_serial, opt_LJ_parallel
#-------------------------------------------------------------------------------
nproc = 12
growatom='Mo'
ecut=50.0
rule=[150, 150, 150, 150, 150, 100, 100, 50]
#-------------------------------------------------------------------------------
file = 'LJ004.xyz'
input_text = """4
  0.00000000     iso0000
Mo      0.852815904     -0.274712872      1.603815762
Mo      1.081981474      0.988964204     -1.107369757
Mo     -1.571705013      0.906080743      0.289473871
Mo     -0.363092365     -1.620332074     -0.785919877
4
  0.92657914     iso0001
Mo      0.000000000     -1.503125904      0.000000000
Mo      0.000000000      1.503125904      0.000000000
Mo     -2.589378456      0.000000000      0.000000000
Mo      2.589378456      0.000000000      0.000000000
"""
with open(file, "w") as f: f.write(input_text)
#-------------------------------------------------------------------------------
molecu0=False
if __name__ == "__main__":
    for iii in range(4, 100+1):
        base_name = 'LJ'+str(iii).zfill(3)
        if os.path.isfile(base_name+'.xyz'):
            print ("%s exists" %(base_name))
            anterior=base_name+'.xyz'
            continue
        if not molecu0:
            molecu0 = readxyzs(anterior)
        molecu0 = rename(molecu0, base_name, 5)
        molecu1 = growpal_parallel(molecu0, growatom, dtol=1.2, n_cores=nproc)
        #----------OPT----------------
        for counter in range(5):
            molecu0 = opt_LJ_parallel(molecu1, 12)
            molecu1 = comparator_usr_serial(molecu0, tols=0.99, tole=0.1, mono=True)
        #--------------------------------------------
        molecu1=cutter_energy(molecu1, ecut)
        molecu0=selectbyclustering_comb_prom(molecu1, rule, "MBTR_dis", "MBTR_cos")
        display_info(molecu0[0:5], base_name)
        writexyzs(molecu0, base_name+'.xyz')
