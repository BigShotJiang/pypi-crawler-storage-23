from aegon.libutils import readxyzs, writexyzs
from aegon.libcalc_lj import lj_energy
from aegon.libdata_lj import get_lj_cluster
import os
ii=4
file='LJ'+str(ii).zfill(3)+'.xyz'
while os.path.isfile(file):
    mol=readxyzs(file)
    nm=len(mol)
    positions = mol[0].get_positions()
    efili=lj_energy(positions)
    etrue=get_lj_cluster(ii).info["e"]
    deltae=(efili-etrue)
    print('%s (%s) %11.6f %5.2f' %(file,f"{nm:02d}",efili,deltae))
    ii=ii+1
    file='LJ'+str(ii).zfill(3)+'.xyz'
