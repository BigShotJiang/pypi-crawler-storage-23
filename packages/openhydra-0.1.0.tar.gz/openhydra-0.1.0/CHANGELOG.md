# Changelog

All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog, and this project uses Semantic Versioning.

## [Unreleased]

### Added

- `SECURITY.md` with vulnerability reporting guidance.
- `CHANGELOG.md` for release and change tracking.

## [0.1.0] - 2026-02-22

### Added

- Initial public project baseline for OpenHydra, including:
  - local-first workflow engine
  - CLI commands (`run`, `serve`, `status`, `doctor`, onboarding/init flows)
  - pluggable channels (web, Slack, Discord, WhatsApp, email)
  - skills, memory, gates, and role-based workflow execution

