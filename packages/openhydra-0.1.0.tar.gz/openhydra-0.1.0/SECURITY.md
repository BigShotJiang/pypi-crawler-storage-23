# Security Policy

## Supported Versions

Security fixes are applied to the latest code on the default development branch.
Older snapshots may not receive backported fixes.

## Reporting a Vulnerability

Please do not open public GitHub issues for suspected security vulnerabilities.

Instead, report privately to the maintainers using one of these channels:

- GitHub Security Advisories (preferred): use the repository's "Report a vulnerability" flow.
- Private maintainer contact: if advisories are unavailable, contact maintainers directly and include:
  - affected version/commit
  - impact and attack scenario
  - reproduction steps or proof of concept
  - suggested remediation (if available)

## Response Expectations

- Initial acknowledgement target: within 72 hours.
- Triage and impact assessment target: within 7 days.
- A fix timeline will be shared after triage based on severity and exploitability.

## Disclosure

Please allow maintainers time to investigate and ship a fix before public disclosure.
Coordinated disclosure is appreciated.
