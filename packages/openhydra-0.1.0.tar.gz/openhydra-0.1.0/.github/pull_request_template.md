## Summary

Describe what changed and why.

## Type of change

- [ ] feat
- [ ] fix
- [ ] docs
- [ ] test
- [ ] chore

## Validation

- [ ] `uv run ruff check src/ tests/`
- [ ] `uv run pytest`
- [ ] Added/updated tests for behavior changes

## Config / Environment Changes

List new config keys, env vars, migrations, or operational impact.

## Checklist

- [ ] Conventional Commit title (`feat:`, `fix:`, etc.)
- [ ] No secrets committed
- [ ] Docs updated when needed
