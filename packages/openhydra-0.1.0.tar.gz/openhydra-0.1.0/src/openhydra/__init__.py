"""OpenHydra — lightweight local-first multi-agent orchestration."""

__version__ = "0.1.0"
