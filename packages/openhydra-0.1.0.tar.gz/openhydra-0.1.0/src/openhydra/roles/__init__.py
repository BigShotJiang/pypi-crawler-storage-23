"""Role catalog and executor."""
