"""Memory store adapters and embedding providers."""
