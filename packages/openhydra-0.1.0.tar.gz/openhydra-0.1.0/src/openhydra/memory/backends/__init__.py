"""Built-in memory backend implementations."""
