"""Channel interfaces for OpenHydra — Web, Slack, Discord, WhatsApp."""
