"""Channel authorization — challenge-based identity verification."""
