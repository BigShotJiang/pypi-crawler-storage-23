"""Agent provider registry and adapters."""
