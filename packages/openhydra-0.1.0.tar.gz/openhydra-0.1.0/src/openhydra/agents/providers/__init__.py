"""Built-in agent provider implementations."""
