"""Tool execution and MCP bridge."""
