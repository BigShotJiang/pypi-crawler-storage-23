"""Agenda — scheduled autonomous task execution."""
