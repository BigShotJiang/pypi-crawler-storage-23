"""Skill security scanning pipeline."""
