"""Built-in skill source implementations."""
