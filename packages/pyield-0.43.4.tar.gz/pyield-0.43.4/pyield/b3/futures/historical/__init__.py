"""Pacote interno para histórico de futuros B3."""
