"""Namespace interno para utilitários compartilhados do pacote.

Este módulo não faz parte da API pública estável do PYield.
"""
