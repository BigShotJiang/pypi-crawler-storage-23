# is-42 🌌

> _"The Answer to the Ultimate Question of Life, the Universe, and Everything."_
> — Deep Thought

**The ultimate answer detection package.** Detects the number **42** in any conceivable form — across 30+ languages, number systems, math expressions, cultural references, and more.

**Zero dependencies.** Pure Python. Pure wisdom.

## Installation

```bash
pip install is-42
```

## Quick Start

```python
from is_42 import is_42, why_42

# === Numeric ===
is_42(42)          # True
is_42(42.0)        # True
is_42(42 + 0j)     # True

# === Multilingual (30+ languages) ===
is_42("四十二")      # True  (Chinese)
is_42("forty-two")  # True  (English)
is_42("four two")   # True  (English informal)
is_42("quarante-deux")  # True  (French)
is_42("zweiundvierzig") # True  (German)
is_42("сорок два")      # True  (Russian)
is_42("よんじゅうに")     # True  (Japanese)
is_42("사십이")          # True  (Korean)

# === Roman Numerals ===
is_42("XLII")     # True
is_42("xlii")     # True

# === Math Expressions (safe sandbox, no eval!) ===
is_42("6 * 7")                  # True
is_42("(122*381+6)**0 + 41")    # True
is_42("2^5 + 10")               # True

# === Base Conversions ===
is_42("0b101010")   # True  (binary)
is_42("0o52")       # True  (octal)
is_42("0x2A")       # True  (hex)
is_42("4.2e1")      # True  (scientific)
is_42("４２")        # True  (full-width)
is_42("④②")         # True  (circled digits)

# === Cultural References ===
is_42("The Answer to Life, the Universe, and Everything")  # True
is_42("Deep Thought")    # True
is_42("Don't Panic")     # True

# === Creative ===
is_42("!" * 42)          # True  (42 identical characters)
is_42("....- ..---")     # True  (Morse code for 42)

# === Not 42? ===
is_42(43)            # False
is_42("hello")       # False
```

### `why_42()` — The Explanation Function

```python
>>> why_42("XLII")
'Roman numeral: XLII = XLII = 42'

>>> why_42("6 * 7")
'math expression: 6 * 7 = 42'

>>> why_42("Deep Thought")
'cultural reference: Douglas Adams — Deep Thought (the supercomputer that computed 42)'

>>> why_42(43)
None
```

## Supported Detection Methods

| Category | Examples |
|----------|---------|
| 🔢 Numeric | `42`, `42.0`, `42+0j`, `Decimal("42")`, `Fraction(84,2)` |
| 🌍 Multilingual | 30+ languages: Chinese, English, French, German, Japanese, Korean, Russian, Arabic, Hindi, ... |
| 🏛️ Roman | `XLII`, Unicode Roman characters |
| 🧮 Math | `6*7`, `2^5+10`, `(122*381+6)**0+41` |
| 💻 Bases | Binary `0b101010`, Octal `0o52`, Hex `0x2A`, Scientific `4.2e1` |
| 🎭 Encoding | Full-width `４２`, Circled `④②`, Thai `๔โ`, Arabic-Indic `٤٢` |
| 🌌 Cultural | "The Answer to Life...", "Deep Thought", "Don't Panic" |
| 🎨 Creative | 42 identical chars, Morse code `....- ..---`, Tally marks |

## License

MIT © is-42 contributors
