"""
is-42: The ultimate answer detection package.

Detects whether a given input represents the number 42 in any conceivable way.
"""

__version__ = "0.1.0"

from .core import is_42, why_42

__all__ = ["is_42", "why_42"]
