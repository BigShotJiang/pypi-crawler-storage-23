"""
Roman numeral checker: detects XLII in various forms.
"""

# Standard Roman numeral representations of 42
_ROMAN_FORMS = {
    "xlii",  # standard
}

# Unicode Roman numeral characters
# Ⅹ = U+2169 (Roman Numeral Ten)
# Ⅼ = U+216C (Roman Numeral Fifty) — not needed for 42
# Ⅱ = U+2161 (Roman Numeral Two)
# ⅩⅬⅡ — combining individual Unicode Roman chars
_UNICODE_ROMAN = {
    "\u2169\u216c\u2161\u2160",  # ⅩⅬⅡⅠ — nah, these don't compose well
}

# We'll do a smarter approach: normalize Unicode Roman chars to ASCII


_UNICODE_TO_ASCII = {
    "\u2160": "I",   # Ⅰ
    "\u2161": "II",  # Ⅱ
    "\u2162": "III", # Ⅲ
    "\u2163": "IV",  # Ⅳ
    "\u2164": "V",   # Ⅴ
    "\u2165": "VI",  # Ⅵ
    "\u2166": "VII", # Ⅶ
    "\u2167": "VIII",# Ⅷ
    "\u2168": "IX",  # Ⅸ
    "\u2169": "X",   # Ⅹ
    "\u216A": "XI",  # Ⅺ
    "\u216B": "XII", # Ⅻ
    "\u216C": "L",   # Ⅼ
    "\u216D": "C",   # Ⅽ
    "\u216E": "D",   # Ⅾ
    "\u216F": "M",   # Ⅿ
    # Lowercase variants
    "\u2170": "I",   # ⅰ
    "\u2171": "II",  # ⅱ
    "\u2172": "III", # ⅲ
    "\u2173": "IV",  # ⅳ
    "\u2174": "V",   # ⅴ
    "\u2175": "VI",  # ⅵ
    "\u2176": "VII", # ⅶ
    "\u2177": "VIII",# ⅷ
    "\u2178": "IX",  # ⅸ
    "\u2179": "X",   # ⅹ
    "\u217A": "XI",  # ⅺ
    "\u217B": "XII", # ⅻ
    "\u217C": "L",   # ⅼ
    "\u217D": "C",   # ⅽ
    "\u217E": "D",   # ⅾ
    "\u217F": "M",   # ⅿ
}


def _normalize_roman(s):
    """Normalize a string by replacing Unicode Roman chars with ASCII equivalents."""
    result = []
    for ch in s:
        if ch in _UNICODE_TO_ASCII:
            result.append(_UNICODE_TO_ASCII[ch])
        else:
            result.append(ch)
    return "".join(result).strip().upper()


def _roman_to_int(s):
    """Convert a Roman numeral string to an integer. Returns None if invalid."""
    roman_values = {
        "I": 1, "V": 5, "X": 10, "L": 50,
        "C": 100, "D": 500, "M": 1000,
    }
    s = s.strip().upper()
    if not s:
        return None
    total = 0
    prev = 0
    for ch in reversed(s):
        if ch not in roman_values:
            return None
        val = roman_values[ch]
        if val < prev:
            total -= val
        else:
            total += val
        prev = val
    return total


def check(value):
    """Check if value represents 42 as a Roman numeral."""
    if not isinstance(value, str):
        return None

    s = value.strip()
    if not s:
        return None

    # Normalize Unicode Roman numerals to ASCII
    normalized = _normalize_roman(s)

    # Try parsing as Roman numeral
    result = _roman_to_int(normalized)
    if result == 42:
        if s.upper() != normalized:
            return f"Unicode Roman numeral: {s} → {normalized} = 42"
        return f"Roman numeral: {s} = XLII = 42"

    return None
