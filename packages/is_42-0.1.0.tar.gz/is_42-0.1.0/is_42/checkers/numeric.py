"""
Numeric checker: detects 42 as int, float, complex, Decimal, Fraction, etc.
"""

import decimal
import fractions


def check(value):
    """Check if value is numerically equal to 42."""
    # Direct numeric types
    if isinstance(value, bool):
        # bool is a subclass of int, so must check first
        return None

    if isinstance(value, (int, float, complex)):
        try:
            if isinstance(value, complex):
                if value == 42 + 0j:
                    return "complex number 42+0j"
            elif value == 42:
                type_name = type(value).__name__
                return f"{type_name} value 42"
        except (ValueError, TypeError):
            pass
        return None

    if isinstance(value, decimal.Decimal):
        try:
            if value == decimal.Decimal("42"):
                return "Decimal value 42"
        except (decimal.InvalidOperation, TypeError):
            pass
        return None

    if isinstance(value, fractions.Fraction):
        if value == fractions.Fraction(42):
            return f"Fraction {value.numerator}/{value.denominator} = 42"
        return None

    return None
