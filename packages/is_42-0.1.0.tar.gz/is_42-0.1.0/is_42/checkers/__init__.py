"""Checkers package for is-42."""
