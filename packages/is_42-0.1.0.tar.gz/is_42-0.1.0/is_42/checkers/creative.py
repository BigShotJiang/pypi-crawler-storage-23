"""
Creative checker: fun and unconventional ways to represent 42.

- 42 identical characters in a row
- Morse code for 42
- Tally marks (groups of 5)
"""

import re


def _check_repeated_chars(s):
    """Check if the string is exactly 42 identical characters."""
    if len(s) != 42:
        return None
    if len(set(s)) == 1:
        char = s[0]
        # Get a readable representation
        if char.isprintable() and not char.isspace():
            return f"42 repeated '{char}' characters"
        else:
            return f"42 repeated U+{ord(char):04X} characters"
    return None


def _check_morse(s):
    """Check if the string is Morse code for 42.

    4 = ....-
    2 = ..---
    42 = ....- ..---
    Separators can be space, /, |, or just concatenated.
    """
    # Normalize separators
    cleaned = s.strip()
    # Allow various separators between digits
    # Standard: "....- ..---"
    # Also accept: "....-.----", "....- / ..---", etc.

    # Remove all separator chars, leaving only dots and dashes
    morse_only = re.sub(r"[\s/|,]+", " ", cleaned).strip()

    # Morse representations of 42
    _VALID_MORSE = {
        "....- ..---",     # standard with space separator
        "....-..---",      # no separator
    }

    if morse_only in _VALID_MORSE:
        return f"Morse code: {s} = ·····−  ··−−− = 42"

    # Also allow with explicit dot/dash unicode chars
    # · (middle dot U+00B7), – (en dash U+2013), — (em dash U+2014)
    unicode_cleaned = cleaned
    unicode_cleaned = unicode_cleaned.replace("\u00b7", ".").replace("\u2022", ".")
    unicode_cleaned = unicode_cleaned.replace("\u2013", "-").replace("\u2014", "-")
    unicode_cleaned = unicode_cleaned.replace("\u2212", "-")  # MINUS SIGN
    unicode_cleaned = unicode_cleaned.replace("_", "-")
    unicode_cleaned = re.sub(r"[\s/|,]+", " ", unicode_cleaned).strip()

    if unicode_cleaned in _VALID_MORSE:
        return f"Morse code (Unicode): {s} = 42"

    return None


def _check_tally(s):
    """Check if the string is tally marks totaling 42.

    Tally marks: 正 (Chinese, each = 5), ㊄ (traditional)
    Also: 卌 = 40 in ancient Chinese
    Western tally: groups of 5 strokes (||||| or 卌)
    """
    cleaned = s.strip()
    if not cleaned:
        return None

    # Chinese 正 character tally (正 = 5)
    if all(ch == "正" for ch in cleaned):
        count = len(cleaned)
        if count * 5 == 42:
            return None  # 42 is not divisible by 5
        return None

    # 正 + single strokes
    zheng_count = cleaned.count("正")
    remaining = cleaned.replace("正", "").strip()
    if zheng_count > 0:
        # remaining should be tally strokes: | or 丨
        stroke_count = 0
        for ch in remaining:
            if ch in "|丨一":
                stroke_count += 1
            elif ch.isspace():
                continue
            else:
                stroke_count = -1
                break
        if stroke_count >= 0:
            total = zheng_count * 5 + stroke_count
            if total == 42:
                return f"tally marks: {zheng_count}×正 + {stroke_count} strokes = 42"

    # 卌 (= 40) + 二 (= 2) or similar
    if "卌" in cleaned:
        rest = cleaned.replace("卌", "").strip()
        if rest in ("二", "2", "②", "贰", "貳", "||", "丨丨"):
            return f"ancient Chinese: 卌({40}) + {rest}({2}) = 42"

    return None


def check(value):
    """Check creative representations of 42."""
    if not isinstance(value, str):
        return None

    s = value.strip()
    if not s:
        return None

    for checker in [_check_repeated_chars, _check_morse, _check_tally]:
        result = checker(s)
        if result:
            return result

    return None
