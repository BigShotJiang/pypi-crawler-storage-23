"""
Multilingual checker: detects 42 written as words in 30+ languages.

Includes formal and informal/colloquial spellings.
All matching is case-insensitive with whitespace/hyphens normalized.
"""

# Each entry: (normalized form, language description)
# Normalization: lowercased, stripped, hyphens and spaces collapsed
_WORDS = {
    # === Chinese 中文 ===
    "四十二": "Chinese (四十二)",
    "四二": "Chinese informal (四二)",
    "四拾贰": "Chinese formal (四拾贰)",
    "肆拾贰": "Chinese financial (肆拾贰)",
    "四十又二": "Chinese archaic (四十又二)",
    "卌二": "Chinese (卌二, 卌=40)",
    # === Special: 莱万汀 ===
    "莱万汀": "莱万汀",
    # === English ===
    "fortytwo": "English (forty-two)",
    "fourtwo": "English informal (four two)",
    "fourtyTwo": "English misspelling (fourty-two)",
    "fourtytwo": "English misspelling (fourty-two)",
    # === French ===
    "quarantedeux": "French (quarante-deux)",
    # === German ===
    "zweiundvierzig": "German (zweiundvierzig)",
    # === Spanish ===
    "cuarentaydos": "Spanish (cuarenta y dos)",
    "cuarentados": "Spanish informal (cuarenta dos)",
    # === Portuguese ===
    "quarentaedois": "Portuguese (quarenta e dois)",
    "quarentaeduas": "Portuguese feminine (quarenta e duas)",
    # === Italian ===
    "quarantadue": "Italian (quarantadue)",
    # === Japanese ===
    "よんじゅうに": "Japanese hiragana (よんじゅうに)",
    "しじゅうに": "Japanese hiragana alt (しじゅうに)",
    "ヨンジュウニ": "Japanese katakana (ヨンジュウニ)",
    "四十二": "Japanese Kanji (四十二)",  # same as Chinese
    # === Korean ===
    "사십이": "Korean sino (사십이)",
    "마흔둘": "Korean native (마흔둘)",
    # === Russian ===
    "сорокдва": "Russian (сорок два)",
    # === Ukrainian ===
    "сорокдва": "Ukrainian/Russian (сорок два)",
    # === Arabic ===
    "اثنانوأربعون": "Arabic (اثنان وأربعون)",
    "٤٢": "Arabic-Indic numerals (٤٢)",
    # === Hindi ===
    "बयालीस": "Hindi (बयालीस)",
    "bayaalis": "Hindi transliterated (bayaalis)",
    # === Turkish ===
    "kirkiki": "Turkish (kırk iki)",
    "kırkiki": "Turkish (kırk iki)",
    # === Thai ===
    "สี่สิบสอง": "Thai (สี่สิบสอง)",
    "๔๒": "Thai numerals (๔๒)",
    # === Vietnamese ===
    "bốnmươihai": "Vietnamese (bốn mươi hai)",
    "bonmuoihai": "Vietnamese ASCII (bon muoi hai)",
    # === Dutch ===
    "tweeënveertig": "Dutch (tweeënveertig)",
    "tweeenveertig": "Dutch ASCII (tweeenveertig)",
    # === Polish ===
    "czterdzieścidwa": "Polish (czterdzieści dwa)",
    "czterdziescidwa": "Polish ASCII (czterdziesci dwa)",
    # === Swedish ===
    "fyrtiotvå": "Swedish (fyrtiotvå)",
    "fyrtiotva": "Swedish ASCII (fyrtiotva)",
    # === Greek ===
    "σαράνταδύο": "Greek (σαράντα δύο)",
    "μβʹ": "Greek numeral (μβʹ)",
    "μβ": "Greek numeral (μβ)",
    # === Hebrew ===
    "ארבעיםושתיים": "Hebrew (ארבעים ושתיים)",
    "מב": "Hebrew numeral (מב)",
    # === Indonesian / Malay ===
    "empatpuluhdua": "Indonesian/Malay (empat puluh dua)",
    # === Romanian ===
    "patruzecișidoi": "Romanian (patruzeci și doi)",
    "patruzecisidoi": "Romanian ASCII (patruzeci si doi)",
    # === Czech ===
    "čtyřicetdva": "Czech (čtyřicet dva)",
    "ctyricetdva": "Czech ASCII (ctyricet dva)",
    # === Hungarian ===
    "negyvenkettő": "Hungarian (negyvenkettő)",
    "negyvenketto": "Hungarian ASCII (negyvenketto)",
    # === Finnish ===
    "neljäkymmentäkaksi": "Finnish (neljäkymmentäkaksi)",
    "neljakymmentakaksi": "Finnish ASCII (neljakymmentakaksi)",
    # === Danish ===
    "toogfyrre": "Danish (toogfyrre)",
    # === Norwegian ===
    "førtito": "Norwegian (førtito)",
    "fortito": "Norwegian ASCII (fortito)",
    # === Latin ===
    "quadragintaduo": "Latin (quadraginta duo)",
    # === Esperanto ===
    "kvardekdu": "Esperanto (kvardek du)",
    # === Swahili ===
    "arobaininamibili": "Swahili (arobaini na mbili)",
    # === Bengali ===
    "বিয়াল্লিশ": "Bengali (বিয়াল্লিশ)",
    # === Persian / Farsi ===
    "چهلودو": "Persian (چهل و دو)",
    "۴۲": "Persian numerals (۴۲)",
}


def _normalize(s):
    """Normalize a string for matching: lowercase, remove spaces/hyphens/underscores."""
    s = s.strip().lower()
    s = s.replace("-", "").replace(" ", "").replace("_", "").replace("\u00a0", "")
    return s


def check(value):
    """Check if value is 42 written as words in any supported language."""
    if not isinstance(value, str):
        return None

    normalized = _normalize(value)
    if not normalized:
        return None

    for word, description in _WORDS.items():
        if _normalize(word) == normalized:
            return f"multilingual: {description}"

    return None
