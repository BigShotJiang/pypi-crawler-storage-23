"""
Cultural reference checker: detects well-known references to 42.

Inspired by Douglas Adams' "The Hitchhiker's Guide to the Galaxy",
where 42 is the "Answer to the Ultimate Question of Life, the Universe,
and Everything", computed by the supercomputer Deep Thought.
"""

import re


def _normalize(s):
    """Normalize for fuzzy matching: lowercase, collapse whitespace, remove punctuation."""
    s = s.strip().lower()
    # Remove common punctuation (keep letters, digits, spaces)
    s = re.sub(r"[''\"\"\",.!?;:()（）【】「」\-—–…·•、。！？；：]", "", s)
    # Collapse whitespace
    s = re.sub(r"\s+", " ", s).strip()
    return s


# Exact-match phrases (after normalization)
_PHRASES = {
    # === English ===
    "the answer to life the universe and everything":
        "Douglas Adams — The Answer to Life, the Universe, and Everything",
    "the answer to the ultimate question of life the universe and everything":
        "Douglas Adams — The Answer to the Ultimate Question",
    "the answer to the ultimate question":
        "Douglas Adams — The Answer to the Ultimate Question",
    "the ultimate answer":
        "Douglas Adams — The Ultimate Answer",
    "the answer":
        "Douglas Adams — The Answer",
    "deep thought":
        "Douglas Adams — Deep Thought (the supercomputer that computed 42)",
    "dont panic":
        "Douglas Adams — DON'T PANIC (The Hitchhiker's Guide motto)",
    "six times nine":
        "Douglas Adams — 6×9=42 (in base 13!)",
    "six by nine":
        "Douglas Adams — 6×9=42 (in base 13!)",
    "6 times 9":
        "Douglas Adams — 6×9=42 (in base 13!)",
    "6 by 9":
        "Douglas Adams — 6×9=42 (in base 13!)",
    "hitchhikers guide to the galaxy":
        "Douglas Adams — The Hitchhiker's Guide to the Galaxy",
    "hitchhikers guide":
        "Douglas Adams — The Hitchhiker's Guide",

    # === Chinese 中文 ===
    "生命宇宙以及一切的答案":
        "Douglas Adams — 生命、宇宙以及一切的答案",
    "生命宇宙及一切的终极答案":
        "Douglas Adams — 生命、宇宙及一切的终极答案",
    "生命宇宙和一切的答案":
        "Douglas Adams — 生命、宇宙和一切的答案",
    "宇宙的终极答案":
        "Douglas Adams — 宇宙的终极答案",
    "宇宙的答案":
        "Douglas Adams — 宇宙的答案",
    "终极答案":
        "Douglas Adams — 终极答案",
    "银河系漫游指南":
        "Douglas Adams — 银河系漫游指南",
    "银河系搭车客指南":
        "Douglas Adams — 银河系搭车客指南",

    # === French ===
    "la réponse à la grande question sur la vie lunivers et le reste":
        "Douglas Adams — La réponse (French)",
    "la réponse ultime":
        "Douglas Adams — La réponse ultime (French)",
    "la reponse ultime":
        "Douglas Adams — La réponse ultime (French)",
    "le guide du voyageur galactique":
        "Douglas Adams — Le Guide du voyageur galactique (French)",

    # === German ===
    "die antwort auf die frage nach dem leben dem universum und dem ganzen rest":
        "Douglas Adams — Die Antwort (German)",
    "die antwort":
        "Douglas Adams — Die Antwort (German)",
    "per anhalter durch die galaxis":
        "Douglas Adams — Per Anhalter durch die Galaxis (German)",

    # === Spanish ===
    "la respuesta a la vida el universo y todo lo demás":
        "Douglas Adams — La respuesta (Spanish)",
    "la respuesta":
        "Douglas Adams — La respuesta (Spanish)",
    "guía del autoestopista galáctico":
        "Douglas Adams — Guía del autoestopista galáctico (Spanish)",

    # === Japanese ===
    "生命宇宙そして万物についての究極の疑問の答え":
        "Douglas Adams — 究極の答え (Japanese)",
    "銀河ヒッチハイクガイド":
        "Douglas Adams — 銀河ヒッチハイク・ガイド (Japanese)",

    # === Russian ===
    "ответ на главный вопрос жизни вселенной и всего такого":
        "Douglas Adams — Ответ (Russian)",
    "автостопом по галактике":
        "Douglas Adams — Автостопом по галактике (Russian)",

    # === Korean ===
    "삶 우주 그리고 모든 것에 대한 궁극적인 해답":
        "Douglas Adams — 궁극의 해답 (Korean)",
    "은하수를 여행하는 히치하이커를 위한 안내서":
        "Douglas Adams — 은하수를 여행하는 히치하이커를 위한 안내서 (Korean)",
}


def check(value):
    """Check if value is a well-known cultural reference to 42."""
    if not isinstance(value, str):
        return None

    normalized = _normalize(value)
    if not normalized:
        return None

    for phrase, description in _PHRASES.items():
        if normalized == _normalize(phrase):
            return f"cultural reference: {description}"

    return None
