def end_chat() -> None:
    """Use this tool to end chat with user if you think that user don't need your help at the moment.
  
    Args:
      None

    Returns:
      None
    """
    return None