# dgbowl-schemas
## Schemas and validators for the `dgbowl` suite of tools.

Currently implemented schemas are:
- `Recipe` validator for **dgpost**, versions `{2.2, 2.1, 1.0}`
- `DataSchema` validator for **yadg**, versions `{6.0, 5.1, 5.0, 4.2, 4.1, 4.0}`
- `Payload` validator for **tomato**,  at version `{2.2, 2.1, 2.0, 1.0, 0.2, 0.1}`

