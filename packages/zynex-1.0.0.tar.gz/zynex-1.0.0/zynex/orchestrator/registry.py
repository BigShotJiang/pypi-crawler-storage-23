from __future__ import annotations

from typing import Dict

from zynex.common.interfaces import DCheckModule
from zynex.modules.core_quality.module import CoreModule


def _load_entrypoint_modules() -> Dict[str, DCheckModule]:
    """
    Discover external modules via Python entry points.

    Expected entry point group:
      [project.entry-points."zynex.modules"]
      gdpr = "dcheck_gdpr.module:GDPRModule"
    """
    modules: Dict[str, DCheckModule] = {}

    try:
        # Python 3.10+ (and newer) supports importlib.metadata in stdlib
        from importlib.metadata import entry_points
    except Exception:
        return modules  # No plugin support available

    try:
        eps = entry_points()

        # Compatibility across Python versions:
        # - New API: eps.select(group="zynex.modules")
        # - Old API: eps.get("zynex.modules", [])
        group = "zynex.modules"
        if hasattr(eps, "select"):
            candidates = list(eps.select(group=group))
        else:
            candidates = list(eps.get(group, []))  # type: ignore[attr-defined]

        for ep in candidates:
            try:
                obj = ep.load()

                # Support either a module instance or a class
                if isinstance(obj, type):
                    inst = obj()
                else:
                    inst = obj

                if not isinstance(inst, DCheckModule):
                    # Wrong type; ignore
                    continue

                # Use module.name as the orchestrator key
                modules[inst.name] = inst

            except Exception:
                # Fail-open: never crash orchestrator due to a plugin
                continue

    except Exception:
        # Any discovery failure should not break core usage
        return modules

    return modules


def discover_modules() -> Dict[str, DCheckModule]:
    """
    Step 1: built-in modules.
    Step 2: plugin discovery via entry points.
    """
    builtin_modules: Dict[str, DCheckModule] = {}
    core = CoreModule()
    builtin_modules[core.name] = core

    plugins = _load_entrypoint_modules()

    for name, mod in plugins.items():
        if name in builtin_modules:
            warnings.warn(
                f"Plugin '{name}' conflicts with a built-in module and will be ignored.",
                UserWarning,
                stacklevel=2,
            )
        else:
            builtin_modules[name] = mod

    return builtin_modules