"""Backward-compatible setuptools entrypoint.

Build configuration lives in `pyproject.toml`.
"""

from setuptools import setup

setup()