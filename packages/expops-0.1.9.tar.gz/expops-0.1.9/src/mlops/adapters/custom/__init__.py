from .custom_adapter import CustomModelAdapter

Adapter = CustomModelAdapter 