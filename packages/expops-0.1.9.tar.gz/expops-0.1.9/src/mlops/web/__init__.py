"""Web app package for simple local UI (API + static frontend)."""


