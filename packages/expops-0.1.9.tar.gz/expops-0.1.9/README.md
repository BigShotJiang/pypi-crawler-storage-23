# ExpOps

`expops` is a project-based experiment runner: keep each experiment isolated under a workspace, run pipelines, and save run artifacts (with optional tracking/backends).

**[User Guide](https://local-minima-lab.github.io/expops-docs/)**

**Install**:

```bash
pip install expops
```

The installed CLI command is **`expops`**.

## Initial Setup

### Prerequisites

- Git installed and configured
- Access to the project repository
- Required dependencies installed

### First-Time Setup

```bash
# Clone the repository
git clone <repository-url>
cd mlops-platform
```

## Branch Naming Convention

Use descriptive branch names that follow this pattern:

```
<type>/<short-description>
```

**Types:**
- `feature/` - New features or enhancements
- `bugfix/` - Bug fixes
- `refactor/` - Code refactoring
- `test/` - Adding or updating tests
- `docs/` - Adding or updating documents

**Examples:**
- `feature/model-versioning`
- `bugfix/api-timeout-error`

## Development Workflow

### Step 1: Create a New Branch

Always create a new branch from the latest `main` branch:

```bash
# Update main branch
git checkout main
git pull origin main

# Create and switch to new branch
git checkout -b feature/your-feature-name
```

### Step 2: Make Changes

- Write clean, well-documented code
- Follow the project's coding standards
- Keep changes focused and atomic
- Test your changes locally

### Step 3: Regular Commits

Commit your changes regularly with meaningful messages:

```bash
git add <changed-files>
git commit -m "descriptive commit message"
```

### Step 4: Keep Branch Updated

Regularly sync your branch with main to avoid conflicts:

```bash
git checkout main
git pull origin main
git checkout feature/your-feature-name
git merge main
```

This would also trigger the CI/CD pipeline on Github Actions, which includes running automated testing.

## Testing Requirements

### Writing Tests

- Write unit tests for new functions and classes
- Place tests in the `tests/` directory
- Name test files as `test_<module_name>.py`

## Merge and Deployment

### Merging

1. Ensure all CI/CD checks pass
2. Rebase if needed to keep history clean
3. Merge using "Squash and merge" or "Rebase and merge"
4. Delete the feature branch after merging

```bash
# After merge, update local main
git checkout main
git pull origin main
git branch -d feature/your-feature-name
```

### Post-Merge

- Monitor for any issues in staging/production
- Update project documentation if needed
- Close related issues

## Publishing to PyPI

The project uses GitHub Actions to automatically build and publish to PyPI when a git tag is pushed.

### Steps to Publish

1. **Update version and create a git tag**:
   ```bash
   # Create a new version tag (e.g., v1.0.0, v1.1.0, v2.0.0)
   git tag v<version-number>
   
   # Example:
   git tag v1.0.0
   ```

2. **Push the tag to GitHub**:
   ```bash
   git push origin v<version-number>
   
   # Example:
   git push origin v1.0.0
   ```