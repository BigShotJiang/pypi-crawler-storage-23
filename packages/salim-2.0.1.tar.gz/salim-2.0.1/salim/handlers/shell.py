"""
Shell execution handlers — run commands, pipes, scheduling.
Uses HTML parse_mode to avoid Markdown parse errors with special chars in output.
"""
from __future__ import annotations

import asyncio
import html
import os
import shlex
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, truncate

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)


class ShellHandlers:

    @require_auth
    async def cmd_run(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "💻 <b>Shell</b>\n\nUsage: <code>/run &lt;command&gt;</code>\n\n"
                "Examples:\n<code>/run ls -la ~/Desktop</code>\n<code>/run git status</code>\n"
                "<code>/run ps aux | grep python</code>", parse_mode=H
            )
            return

        cmd = " ".join(ctx.args)
        msg = await update.effective_message.reply_text(
            f"🔄 Running: <code>{esc(cmd[:100])}</code>...", parse_mode=H
        )
        out, rc = await run_shell_async(cmd, timeout=120, cwd=self._cwd)
        icon = "✅" if rc == 0 else "❌"
        result = truncate(out)

        if len(out) > 3500:
            import io
            file_obj = io.BytesIO(out.encode())
            file_obj.name = "output.txt"
            await msg.delete()
            await update.effective_message.reply_document(
                document=file_obj, filename="output.txt",
                caption=f"{icon} <code>{esc(cmd[:100])}</code> → exit {rc}", parse_mode=H
            )
        else:
            await msg.edit_text(
                f"{icon} <code>{esc(cmd[:100])}</code>\n\n<pre>{esc(result)}</pre>\n<i>Exit: {rc}</i>",
                parse_mode=H
            )

    @require_auth
    async def cmd_runbg(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/runbg &lt;command&gt;</code>", parse_mode=H
            )
            return
        cmd = " ".join(ctx.args)
        await update.effective_message.reply_text(
            f"🚀 Running in background: <code>{esc(cmd)}</code>", parse_mode=H
        )

        async def _bg():
            out, rc = await run_shell_async(cmd, timeout=3600, cwd=self._cwd)
            icon = "✅" if rc == 0 else "❌"
            await update.effective_message.reply_text(
                f"{icon} <b>Background task done</b>\n<code>{esc(cmd[:80])}</code>\n\n"
                f"<pre>{esc(truncate(out, 1000))}</pre>", parse_mode=H
            )

        asyncio.create_task(_bg())

    @require_auth
    async def cmd_pipe(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/pipe cmd1 ||| cmd2 ||| cmd3</code>", parse_mode=H
            )
            return
        raw = " ".join(ctx.args)
        cmd = raw.replace("|||", "|")
        ctx.args = shlex.split(cmd)
        await self.cmd_run(update, ctx)

    @require_auth
    async def cmd_env(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if ctx.args and ctx.args[0] == "set":
            kv = " ".join(ctx.args[1:])
            if "=" in kv:
                k, v = kv.split("=", 1)
                os.environ[k.strip()] = v.strip()
                await update.effective_message.reply_text(
                    f"✅ Set <code>{esc(k.strip())}</code> = <code>{esc(v.strip())}</code>", parse_mode=H
                )
                return

        env = os.environ.copy()
        safe_keys = [k for k in sorted(env.keys())
                     if not any(s in k.upper() for s in ["TOKEN","SECRET","PASSWORD","KEY","API"])]
        lines = [f"{esc(k)}={esc(env[k][:80])}" for k in safe_keys[:40]]
        text = "🌍 <b>Environment Variables</b> (sensitive keys hidden)\n\n<pre>" + "\n".join(lines) + "</pre>"
        await update.effective_message.reply_text(text, parse_mode=H)

    @require_auth
    async def cmd_which(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/which &lt;program&gt;</code>", parse_mode=H
            )
            return
        import shutil as sh
        prog = ctx.args[0]
        path = sh.which(prog)
        if path:
            out, _ = await run_shell_async(
                f"{prog} --version 2>&1 || {prog} -version 2>&1 || {prog} -V 2>&1 | head -1"
            )
            await update.effective_message.reply_text(
                f"🔍 <code>{esc(prog)}</code> → <code>{esc(path)}</code>\n{esc(out[:200])}", parse_mode=H
            )
        else:
            await update.effective_message.reply_text(
                f"❌ <code>{esc(prog)}</code> not found in PATH", parse_mode=H
            )

    @require_auth
    async def cmd_cron(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if len(ctx.args) < 2:
            await update.effective_message.reply_text(
                "⏰ <b>Scheduler</b>\n\nUsage: <code>/cron &lt;seconds&gt; &lt;command&gt;</code>\n"
                "Example: <code>/cron 60 uptime</code>\n\n"
                "Use <code>/cronjobs</code> to list, <code>/cronstop &lt;id&gt;</code> to stop.", parse_mode=H
            )
            return
        try:
            interval = int(ctx.args[0])
            cmd = " ".join(ctx.args[1:])
        except ValueError:
            await update.effective_message.reply_text("❌ First argument must be seconds (integer)")
            return

        job_id = f"cron_{len(ctx.bot_data.get('cron_jobs', {})) + 1}"
        ctx.bot_data.setdefault("cron_jobs", {})[job_id] = {"cmd": cmd, "interval": interval, "count": 0}

        async def _tick(ctx2):
            info = ctx2.bot_data.get("cron_jobs", {}).get(job_id)
            if not info:
                return
            info["count"] += 1
            out, rc = await run_shell_async(cmd, timeout=max(interval - 5, 30))
            icon = "✅" if rc == 0 else "❌"
            await update.effective_message.reply_text(
                f"⏰ <b>Cron <code>{esc(job_id)}</code></b> run #{info['count']}\n"
                f"<code>{esc(cmd)}</code>\n\n<pre>{esc(truncate(out, 800))}</pre>", parse_mode=H
            )

        ctx.job_queue.run_repeating(_tick, interval=interval, first=interval, name=job_id)
        await update.effective_message.reply_text(
            f"✅ Scheduled <code>{esc(job_id)}</code>: <code>{esc(cmd)}</code> every {interval}s", parse_mode=H
        )

    @require_auth
    async def cmd_cronstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: <code>/cronstop &lt;job_id&gt;</code>", parse_mode=H
            )
            return
        job_id = ctx.args[0]
        for j in ctx.job_queue.get_jobs_by_name(job_id):
            j.schedule_removal()
        ctx.bot_data.get("cron_jobs", {}).pop(job_id, None)
        await update.effective_message.reply_text(
            f"🛑 Stopped <code>{esc(job_id)}</code>", parse_mode=H
        )

    @require_auth
    async def cmd_cronjobs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        jobs = ctx.bot_data.get("cron_jobs", {})
        if not jobs:
            await update.effective_message.reply_text("No cron jobs running.")
            return
        lines = [
            f"• <code>{esc(jid)}</code>: <code>{esc(info['cmd'])}</code> "
            f"every {info['interval']}s (ran {info['count']}×)"
            for jid, info in jobs.items()
        ]
        await update.effective_message.reply_text(
            "⏰ <b>Active Cron Jobs</b>\n\n" + "\n".join(lines), parse_mode=H
        )
