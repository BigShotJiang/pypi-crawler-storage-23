"""
Salim Agent — Autonomous Multi-Step Task Executor

Give Salim a complex goal in plain English. It will:
  1. Plan the steps needed to achieve the goal
  2. Execute each step using real Salim capabilities
  3. Report progress after each step
  4. Adapt the plan based on results
  5. Deliver a final summary

This is the same kind of agentic loop used by OpenClaw — the AI acts as a
planner that calls tools (Salim commands) in sequence until the goal is done.

Commands:
  /agent <goal>        — start autonomous task
  /agentstop           — stop running agent
  /agentstatus         — check what agent is doing
  /agentlog            — show last agent run log

Examples:
  /agent clean up my desktop folder, organize files by type
  /agent check system health and save a report to desktop
  /agent find all pdf files, create a list of them in notes
  /agent run my test suite and email me the results
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.agent")

AGENT_DIR = Path.home() / ".salim" / "agent"

# Max steps per agent run (safety limit)
MAX_STEPS = 15
# Max seconds per individual step
STEP_TIMEOUT = 30


def _agent_log_file(user_id: int) -> Path:
    AGENT_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return AGENT_DIR / f"{user_id}_last.json"


def save_agent_log(user_id: int, log: dict):
    path = _agent_log_file(user_id)
    path.write_text(json.dumps(log, indent=2, ensure_ascii=False))
    path.chmod(0o600)


def load_agent_log(user_id: int) -> dict:
    path = _agent_log_file(user_id)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


# Active agent tasks per user
_active_agents: dict[int, asyncio.Task] = {}


AGENT_SYSTEM_PROMPT = """You are the planning brain of Salim, an autonomous laptop control agent.

Your job: Given a user's goal, plan and execute a sequence of concrete steps using available tools.

AVAILABLE TOOLS (what you can call):
- shell: run any shell command and get output
- screenshot: take a screenshot of the screen
- find_files: search for files by name pattern
- read_file: read contents of a file
- write_file: write content to a file
- get_system_info: get CPU/RAM/disk stats
- list_dir: list files in a directory
- create_dir: create a directory
- delete_file: delete a file
- notify: send desktop notification
- open_app: open an application
- copy_clipboard: copy text to clipboard
- get_processes: get running processes

RESPONSE FORMAT — you must respond with ONLY valid JSON:

At each step, you see the goal, previous steps taken, and their results.
You respond with the next action to take:

{
  "thought": "what I'm thinking about the situation",
  "action": "shell",
  "parameters": {"command": "ls -la ~/Desktop"},
  "expecting": "list of files on desktop"
}

OR, when the goal is complete:
{
  "thought": "the goal has been achieved",
  "action": "done",
  "summary": "I organized 15 files on the desktop into 4 folders by type",
  "parameters": {}
}

OR, when you need to stop:
{
  "thought": "cannot proceed because...",
  "action": "stop",
  "reason": "explanation of why we're stopping",
  "parameters": {}
}

RULES:
- Be conservative: prefer read-only operations before modifying files
- For destructive actions (delete, overwrite), only proceed if the goal explicitly asks for it
- If a step fails, adapt and try an alternative approach
- Maximum {max_steps} steps total
- Each step must make concrete progress toward the goal
- Never loop endlessly; stop if stuck after 2 failed attempts
""".replace("{max_steps}", str(MAX_STEPS))


async def _execute_tool(action: str, parameters: dict) -> tuple[bool, str]:
    """
    Execute a tool action. Returns (success, output_text).
    All operations are real — no mocks.
    """
    try:
        if action == "shell":
            cmd = parameters.get("command", "")
            if not cmd:
                return False, "No command provided"
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=STEP_TIMEOUT, cwd=str(Path.home())
            )
            output = (result.stdout or "").strip()
            err = (result.stderr or "").strip()
            if result.returncode != 0 and err:
                return False, f"Exit {result.returncode}: {err[:1000]}"
            return True, (output or "(command completed with no output)")[:2000]

        elif action == "screenshot":
            try:
                import pyautogui
                import io
                from PIL import Image
                img = pyautogui.screenshot()
                path = Path.home() / ".salim" / "agent" / f"screenshot_{int(time.time())}.png"
                path.parent.mkdir(exist_ok=True)
                img.save(str(path))
                return True, f"Screenshot saved: {path}"
            except ImportError:
                # Fallback to scrot/screencapture
                path = Path.home() / ".salim" / "agent" / f"screenshot_{int(time.time())}.png"
                path.parent.mkdir(exist_ok=True)
                import platform as _plt
                if _plt.system() == "Darwin":
                    result = subprocess.run(["screencapture", "-x", str(path)], capture_output=True)
                else:
                    result = subprocess.run(["scrot", str(path)], capture_output=True)
                return result.returncode == 0, f"Screenshot saved: {path}"

        elif action == "find_files":
            pattern = parameters.get("pattern", "*")
            directory = Path(parameters.get("directory", str(Path.home()))).expanduser()
            max_results = parameters.get("max_results", 20)
            results = []
            try:
                for p in directory.rglob(pattern):
                    results.append(str(p))
                    if len(results) >= max_results:
                        break
            except Exception as e:
                return False, str(e)
            return True, "\n".join(results) if results else "No files found"

        elif action == "read_file":
            path = Path(parameters.get("path", "")).expanduser()
            if not path.exists():
                return False, f"File not found: {path}"
            try:
                content = path.read_text(errors="replace")
                return True, content[:3000]
            except Exception as e:
                return False, str(e)

        elif action == "write_file":
            path = Path(parameters.get("path", "")).expanduser()
            content = parameters.get("content", "")
            if not path.parent.exists():
                path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
            return True, f"Written {len(content)} chars to {path}"

        elif action == "get_system_info":
            try:
                import psutil
                cpu = psutil.cpu_percent(interval=0.5)
                mem = psutil.virtual_memory()
                disk = psutil.disk_usage("/")
                return True, (
                    f"CPU: {cpu}%\n"
                    f"RAM: {mem.percent}% ({round(mem.used/1e9,1)}/{round(mem.total/1e9,1)} GB)\n"
                    f"Disk: {disk.percent}% ({round(disk.free/1e9,1)} GB free)"
                )
            except Exception as e:
                return False, str(e)

        elif action == "list_dir":
            path = Path(parameters.get("path", str(Path.home()))).expanduser()
            try:
                items = list(path.iterdir())
                lines = [f"{'[DIR]' if p.is_dir() else '[FILE]'} {p.name}" for p in sorted(items)[:50]]
                return True, "\n".join(lines) or "(empty directory)"
            except Exception as e:
                return False, str(e)

        elif action == "create_dir":
            path = Path(parameters.get("path", "")).expanduser()
            path.mkdir(parents=True, exist_ok=True)
            return True, f"Created: {path}"

        elif action == "delete_file":
            path = Path(parameters.get("path", "")).expanduser()
            if not path.exists():
                return False, f"Not found: {path}"
            if path.is_dir():
                import shutil
                shutil.rmtree(str(path))
            else:
                path.unlink()
            return True, f"Deleted: {path}"

        elif action == "notify":
            title = parameters.get("title", "Salim Agent")
            message = parameters.get("message", "")
            import platform as _plt
            sys = _plt.system()
            if sys == "Darwin":
                subprocess.run([
                    "osascript", "-e",
                    f'display notification "{message}" with title "{title}"'
                ], capture_output=True)
            elif sys == "Linux":
                subprocess.run(["notify-send", title, message], capture_output=True)
            elif sys == "Windows":
                subprocess.run(["msg", "*", message], capture_output=True)
            return True, f"Notification sent: {title} — {message}"

        elif action == "get_processes":
            try:
                import psutil
                procs = []
                for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
                    try:
                        procs.append(f"{p.info['pid']:>6}  {p.info['cpu_percent']:>5.1f}%  {p.info['name']}")
                    except Exception:
                        pass
                return True, "\n".join(sorted(procs, key=lambda x: float(x.split()[1].rstrip("%")), reverse=True)[:20])
            except Exception as e:
                return False, str(e)

        elif action == "open_app":
            app = parameters.get("app", "")
            import platform as _plt
            if _plt.system() == "Darwin":
                subprocess.Popen(["open", "-a", app])
            elif _plt.system() == "Windows":
                subprocess.Popen(["start", app], shell=True)
            else:
                subprocess.Popen(["xdg-open", app])
            return True, f"Opened: {app}"

        elif action == "copy_clipboard":
            text = parameters.get("text", "")
            try:
                import pyperclip
                pyperclip.copy(text)
                return True, f"Copied to clipboard: {text[:100]}"
            except Exception as e:
                return False, str(e)

        else:
            return False, f"Unknown action: {action}"

    except subprocess.TimeoutExpired:
        return False, f"Step timed out after {STEP_TIMEOUT}s"
    except Exception as e:
        return False, f"Error: {e}"


async def run_agent(
    goal: str,
    user_id: int,
    ai_instance,
    progress_callback,  # async callable(step_num, thought, action, result)
    stop_event: asyncio.Event,
) -> str:
    """
    Core agent loop. Returns final summary string.

    progress_callback(step, thought, action_desc, result) is called after each step
    so the user sees live progress in Telegram.
    """
    steps_taken = []
    log = {
        "goal": goal,
        "started": datetime.now().isoformat(),
        "user_id": user_id,
        "steps": [],
    }

    consecutive_failures = 0

    for step_num in range(1, MAX_STEPS + 1):
        if stop_event.is_set():
            log["stopped"] = "user_requested"
            save_agent_log(user_id, log)
            return "⏹ Agent stopped by user."

        # Build the prompt showing all prior steps
        steps_context = ""
        if steps_taken:
            steps_context = "\n\nSTEPS TAKEN SO FAR:\n"
            for i, s in enumerate(steps_taken, 1):
                steps_context += (
                    f"\nStep {i}: {s['action']}({json.dumps(s['params'])})\n"
                    f"Result: {'✅' if s['success'] else '❌'} {s['output'][:300]}\n"
                )

        prompt = (
            f"GOAL: {goal}\n"
            f"STEP: {step_num}/{MAX_STEPS}\n"
            f"OS: {__import__('platform').system()}\n"
            f"{steps_context}\n\n"
            f"What is the next action to take? Respond with JSON only."
        )

        try:
            raw, _provider = await ai_instance._call_with_fallback(
                [{"role": "user", "content": prompt}],
                system=AGENT_SYSTEM_PROMPT,
                max_tokens=512,
                temperature=0.2,
            )
            raw = re.sub(r"```(?:json)?|```", "", raw).strip()
            plan = json.loads(raw)
        except Exception as e:
            logger.error(f"Agent planning error at step {step_num}: {e}")
            consecutive_failures += 1
            if consecutive_failures >= 3:
                return f"⚠️ Agent stopped: AI planning failed 3 times. Last error: {e}"
            continue

        action = plan.get("action", "stop")
        thought = plan.get("thought", "")
        params = plan.get("parameters", {})

        # ── Terminal actions ──────────────────────────────────────────────────
        if action == "done":
            summary = plan.get("summary", "Task completed.")
            log["completed"] = datetime.now().isoformat()
            log["summary"] = summary
            log["steps"] = steps_taken
            save_agent_log(user_id, log)
            await progress_callback(step_num, thought, "✅ Done", summary)
            return summary

        if action == "stop":
            reason = plan.get("reason", "Agent stopped.")
            log["stopped"] = reason
            log["steps"] = steps_taken
            save_agent_log(user_id, log)
            await progress_callback(step_num, thought, "⏹ Stop", reason)
            return f"⏹ Stopped: {reason}"

        # ── Execute the action ────────────────────────────────────────────────
        action_desc = f"{action}({', '.join(f'{k}={v}' for k,v in list(params.items())[:2])})"
        await progress_callback(step_num, thought, action_desc, None)

        success, output = await _execute_tool(action, params)

        steps_taken.append({
            "step": step_num,
            "action": action,
            "params": params,
            "success": success,
            "output": output[:500],
            "thought": thought,
        })

        if not success:
            consecutive_failures += 1
        else:
            consecutive_failures = 0

        await progress_callback(step_num, thought, action_desc, output if success else f"❌ {output}")

        if consecutive_failures >= 3:
            log["stopped"] = "too_many_failures"
            log["steps"] = steps_taken
            save_agent_log(user_id, log)
            return f"⚠️ Agent stopped after 3 consecutive failures. Last: {output}"

        # Small delay to avoid hammering
        await asyncio.sleep(0.5)

    log["stopped"] = "max_steps_reached"
    log["steps"] = steps_taken
    save_agent_log(user_id, log)
    return f"⚠️ Reached maximum {MAX_STEPS} steps. Goal may be partially complete."


class AgentHandlers:
    """Mixin for SalimBot — adds /agent command."""

    @require_auth
    async def cmd_agent(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /agent <goal>  — start autonomous multi-step task
        """
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        user_id = update.effective_user.id
        goal = " ".join(ctx.args) if ctx.args else ""

        if not goal:
            await msg.reply_text(
                "🤖 <b>Salim Autonomous Agent</b>\n\n"
                "Give me a complex goal and I'll plan and execute it step by step.\n\n"
                "<b>Usage:</b> <code>/agent &lt;your goal&gt;</code>\n\n"
                "<b>Examples:</b>\n"
                "• <code>/agent organize my desktop by file type</code>\n"
                "• <code>/agent check system health and save report to desktop</code>\n"
                "• <code>/agent find all log files older than 7 days and delete them</code>\n"
                "• <code>/agent list all python files in my home folder</code>\n\n"
                "<i>The agent runs real commands. You'll see each step live.</i>",
                parse_mode="HTML",
            )
            return

        if not self._ai.is_configured():
            await msg.reply_text(
                "⚠️ AI not configured. Run <code>salim setup</code> to add an API key.",
                parse_mode="HTML",
            )
            return

        # Stop any existing agent for this user
        if user_id in _active_agents and not _active_agents[user_id].done():
            _active_agents[user_id].cancel()
            await asyncio.sleep(0.1)

        # Create the live progress message
        progress_msg = await msg.reply_text(
            f"🤖 <b>Agent starting…</b>\n\n"
            f"🎯 Goal: <i>{esc(goal)}</i>\n\n"
            f"<i>Planning first step…</i>",
            parse_mode="HTML",
        )

        step_log = []
        stop_event = asyncio.Event()
        # Store stop event so /agentstop can access it
        self._agent_stop_events = getattr(self, "_agent_stop_events", {})
        self._agent_stop_events[user_id] = stop_event

        async def progress_callback(step_num: int, thought: str, action_desc: str, result):
            """Update the Telegram message with live progress."""
            step_log.append({
                "step": step_num,
                "thought": thought[:100] if thought else "",
                "action": action_desc,
                "result": str(result)[:200] if result else None,
            })

            lines = [
                f"🤖 <b>Agent Running</b>",
                f"🎯 <i>{esc(goal[:80])}</i>",
                f"",
            ]
            # Show last 5 steps
            for entry in step_log[-5:]:
                s = entry["step"]
                t = entry.get("thought", "")
                a = entry.get("action", "")
                r = entry.get("result")
                status = "✅" if r and not r.startswith("❌") else ("⏳" if r is None else "❌")
                lines.append(f"{status} <b>Step {s}:</b> <code>{esc(a[:50])}</code>")
                if t:
                    lines.append(f"   💭 <i>{esc(t[:80])}</i>")
                if r:
                    lines.append(f"   📤 <code>{esc(str(r)[:100])}</code>")

            if result is None:
                lines.append(f"\n<i>Executing step {step_num}…</i>")

            try:
                await progress_msg.edit_text(
                    "\n".join(lines),
                    parse_mode="HTML",
                )
            except Exception:
                pass  # Message unchanged — Telegram ignores identical edits

        async def agent_task():
            try:
                summary = await run_agent(
                    goal=goal,
                    user_id=user_id,
                    ai_instance=self._ai,
                    progress_callback=progress_callback,
                    stop_event=stop_event,
                )
                # Final message
                total_steps = len(step_log)
                final_lines = [
                    f"🤖 <b>Agent Complete</b>",
                    f"🎯 <i>{esc(goal[:80])}</i>",
                    f"",
                    f"📊 {total_steps} step{'s' if total_steps != 1 else ''} executed",
                    f"",
                    f"📝 <b>Summary:</b>",
                    f"{esc(summary)}",
                    f"",
                    f"<i>/agentlog to see full step details</i>",
                ]
                await progress_msg.edit_text("\n".join(final_lines), parse_mode="HTML")
            except asyncio.CancelledError:
                await progress_msg.edit_text(
                    f"⏹ <b>Agent stopped</b>\n🎯 <i>{esc(goal[:80])}</i>",
                    parse_mode="HTML",
                )
            except Exception as e:
                await progress_msg.edit_text(
                    f"⚠️ <b>Agent error:</b> {esc(str(e))}",
                    parse_mode="HTML",
                )
            finally:
                _active_agents.pop(user_id, None)

        task = asyncio.create_task(agent_task())
        _active_agents[user_id] = task

    @require_auth
    async def cmd_agentstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a running agent."""
        user_id = update.effective_user.id
        stop_events = getattr(self, "_agent_stop_events", {})
        if user_id in stop_events:
            stop_events[user_id].set()
        if user_id in _active_agents and not _active_agents[user_id].done():
            _active_agents[user_id].cancel()
            await update.effective_message.reply_text("⏹ Agent stopped.")
        else:
            await update.effective_message.reply_text("ℹ️ No agent is currently running.")

    @require_auth
    async def cmd_agentstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Check if an agent is running."""
        user_id = update.effective_user.id
        if user_id in _active_agents and not _active_agents[user_id].done():
            await update.effective_message.reply_text(
                "🤖 <b>Agent is running.</b>\n<i>Use /agentstop to cancel.</i>",
                parse_mode="HTML",
            )
        else:
            await update.effective_message.reply_text("ℹ️ No agent currently running.")

    @require_auth
    async def cmd_agentlog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show the last agent run log."""
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        user_id = update.effective_user.id
        log = load_agent_log(user_id)
        if not log:
            await update.effective_message.reply_text(
                "📋 No agent runs yet. Try: <code>/agent organize my desktop</code>",
                parse_mode="HTML",
            )
            return

        lines = [
            f"📋 <b>Last Agent Run</b>",
            f"🎯 Goal: <i>{esc(log.get('goal', '?'))}</i>",
            f"⏰ Started: {esc(log.get('started', '?')[:16])}",
        ]
        if log.get("summary"):
            lines += ["", f"✅ <b>Summary:</b> {esc(log['summary'])}"]
        if log.get("stopped"):
            lines += ["", f"⏹ Stopped: {esc(log['stopped'])}"]

        steps = log.get("steps", [])
        if steps:
            lines += ["", f"<b>Steps ({len(steps)}):</b>"]
            for s in steps:
                ok = "✅" if s.get("success") else "❌"
                lines.append(
                    f"{ok} <b>Step {s['step']}:</b> {esc(s.get('action','?'))} "
                    f"→ {esc(str(s.get('output',''))[:100])}"
                )

        await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")
