"""
Salim Persistent Memory — User Profile & Habit Learning

Stores and retrieves a persistent user profile that survives restarts.
Learns: name, timezone, working hours, language, preferences, frequently used
commands, file paths, recurring patterns, etc.

The profile is injected as context into every AI call so Salim personalizes
responses and remembers things you've told it across sessions.

Storage: ~/.salim/memory/<user_id>.json  (human-readable JSON)

Commands:
  /memory              — show your current profile
  /memory set <k> <v>  — manually set a preference
  /memory forget <key> — delete a specific memory
  /memory clear        — wipe entire profile
  /memory learn        — trigger profile update from recent history
"""
from __future__ import annotations

import asyncio
import json
import logging
import platform
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.memory")

MEMORY_DIR = Path.home() / ".salim" / "memory"

# Keys the memory system tracks automatically
AUTO_KEYS = {
    "name":            "User's preferred name",
    "timezone":        "User's timezone (e.g. Asia/Karachi, UTC+5)",
    "language":        "Preferred response language",
    "wake_time":       "Typical wake-up time (e.g. 07:00)",
    "sleep_time":      "Typical sleep time (e.g. 23:00)",
    "work_start":      "Start of working hours (e.g. 09:00)",
    "work_end":        "End of working hours (e.g. 18:00)",
    "working_days":    "Working days (e.g. Mon-Fri)",
    "role":            "Job role or occupation",
    "projects":        "Active projects user mentions",
    "tools":           "Frequently used software/tools",
    "download_dir":    "Preferred download location",
    "desktop_dir":     "Desktop path",
    "briefing_time":   "Daily briefing time (e.g. 08:00)",
    "briefing_enabled":"Whether daily briefing is enabled (true/false)",
    "style":           "Preferred response style (brief/detailed/technical)",
    "interests":       "Topics the user is interested in",
    "last_seen":       "Last interaction timestamp",
}


def _memory_file(user_id: int) -> Path:
    MEMORY_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return MEMORY_DIR / f"{user_id}.json"


def load_memory(user_id: int) -> dict:
    """Load full memory profile for a user."""
    path = _memory_file(user_id)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_memory(user_id: int, data: dict):
    """Overwrite memory profile."""
    path = _memory_file(user_id)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    path.chmod(0o600)


def set_memory(user_id: int, key: str, value: Any):
    """Set a single memory key."""
    data = load_memory(user_id)
    data[key] = value
    data["last_updated"] = datetime.now().isoformat()
    save_memory(user_id, data)


def get_memory(user_id: int, key: str, default: Any = None) -> Any:
    return load_memory(user_id).get(key, default)


def delete_memory_key(user_id: int, key: str):
    data = load_memory(user_id)
    data.pop(key, None)
    save_memory(user_id, data)


def clear_memory(user_id: int):
    path = _memory_file(user_id)
    if path.exists():
        path.unlink()


def update_last_seen(user_id: int):
    """Update last_seen timestamp — called on every interaction."""
    set_memory(user_id, "last_seen", datetime.now().isoformat())


def build_memory_context(user_id: int) -> str:
    """
    Build a memory context string to inject into every AI system prompt.
    Returns empty string if no meaningful memory exists.
    """
    data = load_memory(user_id)
    if not data:
        return ""

    lines = ["[USER MEMORY — what you know about this user:]"]
    important_keys = [
        "name", "timezone", "role", "language", "style",
        "work_start", "work_end", "working_days",
        "wake_time", "sleep_time",
        "briefing_time", "briefing_enabled",
        "projects", "tools", "interests",
        "download_dir", "desktop_dir",
    ]
    shown = set()
    # Show important keys first
    for key in important_keys:
        if key in data and data[key]:
            lines.append(f"  {key}: {data[key]}")
            shown.add(key)
    # Show any additional user-set keys
    skip = {"last_updated", "last_seen", "command_counts", "inferred_habits"}
    for key, val in data.items():
        if key not in shown and key not in skip and val:
            if isinstance(val, (str, int, float, bool)):
                lines.append(f"  {key}: {val}")
    lines.append("Use this information to personalize responses and avoid asking for info already known.")
    return "\n".join(lines)


def learn_from_text(user_id: int, text: str):
    """
    Extract facts from user messages and update memory automatically.
    Called passively on every user message — fast, no AI call needed.
    """
    data = load_memory(user_id)
    changed = False
    text_lower = text.lower().strip()

    # ── Name detection ────────────────────────────────────────────────────────
    name_patterns = [
        r"(?:my name is|i'm|i am|call me)\s+([A-Z][a-z]{1,20})",
        r"^([A-Z][a-z]{1,20})\s+here",
    ]
    if "name" not in data:
        for pat in name_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                data["name"] = m.group(1).strip()
                changed = True
                break

    # ── Timezone detection ─────────────────────────────────────────────────────
    tz_patterns = [
        r"(?:i'm in|i live in|my timezone is|i'm at)\s+(UTC[+-]\d{1,2}|\w+/\w+)",
        r"(UTC[+-]\d{1,2})",
        r"\b(Asia/\w+|America/\w+|Europe/\w+|Africa/\w+|Pacific/\w+)\b",
    ]
    if "timezone" not in data:
        for pat in tz_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                data["timezone"] = m.group(1).strip()
                changed = True
                break

    # ── Role detection ─────────────────────────────────────────────────────────
    role_patterns = [
        r"i(?:'m| am) (?:a |an )?(.{3,30}?)(?:\.|,|$)",
        r"(?:my job|my role|i work as) (?:is |as )?(.{3,30}?)(?:\.|,|$)",
    ]
    role_kws = ["developer", "engineer", "designer", "manager", "student", "doctor",
                "teacher", "analyst", "scientist", "freelancer", "cto", "ceo", "founder"]
    if "role" not in data:
        for pat in role_patterns:
            m = re.search(pat, text_lower)
            if m:
                candidate = m.group(1).strip()
                if any(kw in candidate for kw in role_kws):
                    data["role"] = candidate
                    changed = True
                    break

    # ── Language preference ────────────────────────────────────────────────────
    if "language" not in data:
        lang_m = re.search(
            r"(?:respond|reply|answer|speak)\s+in\s+([a-zA-Z]{3,20})", text_lower
        )
        if lang_m:
            data["language"] = lang_m.group(1).strip()
            changed = True

    # ── Work hours ─────────────────────────────────────────────────────────────
    if "work_start" not in data:
        wh_m = re.search(r"(?:i work|working hours?).{0,20}?(\d{1,2}(?::\d{2})?(?:\s*[ap]m)?)", text_lower)
        if wh_m:
            data["work_start"] = wh_m.group(1).strip()
            changed = True

    # ── Track command frequency ────────────────────────────────────────────────
    cmd_match = re.match(r"^/(\w+)", text)
    if cmd_match:
        cmd = cmd_match.group(1)
        counts = data.get("command_counts", {})
        counts[cmd] = counts.get(cmd, 0) + 1
        data["command_counts"] = counts
        changed = True

    if changed:
        data["last_updated"] = datetime.now().isoformat()
        save_memory(user_id, data)


async def learn_from_ai(user_id: int, user_message: str, ai_response: str, ai_instance) -> None:
    """
    Use the AI to extract facts from a conversation exchange and update memory.
    Called asynchronously after non-trivial exchanges — won't block main flow.
    """
    data = load_memory(user_id)
    existing = {k: v for k, v in data.items()
                if k not in ("command_counts", "last_seen", "last_updated", "inferred_habits")}

    extract_prompt = f"""You are a memory extractor for a personal AI assistant.

Given this conversation exchange, extract any NEW facts about the user.
Return a JSON object with ONLY new keys not already known.
Return empty {{}} if nothing new was learned.

ALREADY KNOWN: {json.dumps(existing, ensure_ascii=False)}

USER SAID: {user_message[:500]}
ASSISTANT REPLIED: {ai_response[:500]}

Extract keys like: name, timezone, role, language, projects, tools, interests,
work_start, work_end, wake_time, sleep_time, style, download_dir, briefing_time, briefing_enabled.

Return ONLY valid JSON. No explanation."""

    try:
        from salim.ai import SalimAI
        from salim.config import Config
        cfg = Config()
        ai_obj = ai_instance if ai_instance else SalimAI(cfg)
        raw, _ = await ai_obj._call_with_fallback(
            [{"role": "user", "content": extract_prompt}],
            system="You are a JSON-only extractor. Output only valid JSON, nothing else.",
            max_tokens=256,
            temperature=0.1,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        new_facts = json.loads(raw)
        if isinstance(new_facts, dict) and new_facts:
            for k, v in new_facts.items():
                if v and k not in ("last_updated", "last_seen"):
                    data[k] = v
            data["last_updated"] = datetime.now().isoformat()
            save_memory(user_id, data)
            logger.info(f"Memory updated for user {user_id}: {list(new_facts.keys())}")
    except Exception as e:
        logger.debug(f"Memory AI extraction skipped: {e}")


class MemoryHandlers:
    """Mixin for SalimBot — adds /memory commands."""

    @require_auth
    async def cmd_memory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /memory              — view profile
        /memory set <k> <v>  — set a value
        /memory forget <key> — remove a key
        /memory clear        — wipe everything
        /memory learn        — re-extract from recent history
        """
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if args and args[0].lower() == "clear":
            clear_memory(user_id)
            await msg.reply_text(
                "🧹 <b>Memory cleared.</b>\n"
                "<i>Salim no longer remembers anything about you.\n"
                "It will start learning again from scratch.</i>",
                parse_mode="HTML",
            )
            return

        if args and args[0].lower() == "forget" and len(args) >= 2:
            key = args[1].lower()
            delete_memory_key(user_id, key)
            await msg.reply_text(
                f"🗑️ Forgot: <code>{esc(key)}</code>", parse_mode="HTML"
            )
            return

        if args and args[0].lower() == "set" and len(args) >= 3:
            key = args[1].lower()
            value = " ".join(args[2:])
            set_memory(user_id, key, value)
            await msg.reply_text(
                f"✅ Memory updated:\n"
                f"<code>{esc(key)}</code> = <code>{esc(value)}</code>",
                parse_mode="HTML",
            )
            return

        if args and args[0].lower() == "learn":
            thinking = await msg.reply_text("🧠 <i>Re-learning from your recent conversation history…</i>", parse_mode="HTML")
            from salim.handlers.history import load_history
            history = load_history(user_id, 30)
            if not history:
                await thinking.edit_text("📭 No history to learn from yet.", parse_mode="HTML")
                return
            # Run AI extraction on last few exchanges
            try:
                pairs = []
                user_msgs = [h["content"] for h in history if h.get("role") == "user"]
                asst_msgs = [h["content"] for h in history if h.get("role") == "assistant"]
                combined_user = " ".join(user_msgs[-5:])
                combined_asst = " ".join(asst_msgs[-5:])
                await learn_from_ai(user_id, combined_user, combined_asst, self._ai if hasattr(self, "_ai") else None)
                data = load_memory(user_id)
                count = len([v for v in data.values() if v and not isinstance(v, dict)])
                await thinking.edit_text(
                    f"🧠 <b>Learning complete!</b>\n"
                    f"<i>{count} facts now stored in memory.</i>",
                    parse_mode="HTML",
                )
            except Exception as e:
                await thinking.edit_text(f"⚠️ Learning failed: {esc(str(e))}", parse_mode="HTML")
            return

        # ── Show memory ────────────────────────────────────────────────────────
        data = load_memory(user_id)
        if not data:
            await msg.reply_text(
                "🧠 <b>No memory yet.</b>\n\n"
                "<i>Salim will automatically learn about you as you chat.\n\n"
                "You can also manually set preferences:</i>\n"
                "<code>/memory set name Ahmed</code>\n"
                "<code>/memory set timezone UTC+5</code>\n"
                "<code>/memory set briefing_time 08:00</code>\n"
                "<code>/memory set style brief</code>",
                parse_mode="HTML",
            )
            return

        skip = {"command_counts", "last_seen", "inferred_habits"}
        lines = ["🧠 <b>Your Memory Profile</b>\n"]
        for k, v in data.items():
            if k in skip:
                continue
            if isinstance(v, dict):
                continue
            icon = {
                "name": "👤", "timezone": "🌍", "role": "💼", "language": "🗣️",
                "wake_time": "⏰", "sleep_time": "😴", "work_start": "🏢", "work_end": "🏠",
                "projects": "📁", "tools": "🔧", "interests": "⭐", "style": "✏️",
                "briefing_time": "📰", "briefing_enabled": "🔔",
            }.get(k, "📌")
            lines.append(f"{icon} <b>{esc(k)}</b>: <code>{esc(str(v))}</code>")

        # Show top 5 most used commands
        counts = data.get("command_counts", {})
        if counts:
            top = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:5]
            top_str = ", ".join(f"/{cmd}({n})" for cmd, n in top)
            lines.append(f"\n📊 <b>Top commands:</b> {esc(top_str)}")

        last = data.get("last_updated", "")
        if last:
            lines.append(f"\n<i>Last updated: {esc(last[:16])}</i>")

        lines.append(
            "\n<i>Commands: /memory set &lt;k&gt; &lt;v&gt; · /memory forget &lt;k&gt; · /memory clear</i>"
        )
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
