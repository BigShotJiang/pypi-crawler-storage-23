# 🖥️ Salim — Control Your Laptop from Telegram

<p align="center">
  <strong>Type a message on your phone. Your laptop does it.</strong><br>
  Screenshots · Files · Shell · Processes · Power · Mouse & Keyboard · AI
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.9+-blue.svg" alt="Python 3.9+">
  <img src="https://img.shields.io/badge/platform-macOS%20%7C%20Linux%20%7C%20Windows-lightgrey" alt="Platform">
  <img src="https://img.shields.io/badge/License-MIT-green.svg" alt="MIT License">
  <img src="https://img.shields.io/badge/AI-NVIDIA%20%7C%20Groq%20%7C%20Z.AI-orange" alt="AI Providers">
</p>

---

## 🤔 What Is This?

Salim turns your laptop into a bot you can control from **anywhere in the world** using Telegram — the free messaging app.

Left your laptop at home? Left a download running? Want to check if your computer is overheating? Need to grab a file from your machine while you're out?

**Just text your bot.** That's it.

You can use plain English thanks to built-in AI — or use quick `/commands` if you prefer.

```
You:    "take a screenshot"
Salim:  📸 [sends screenshot to Telegram]

You:    "how much RAM am I using?"
Salim:  🧠 RAM: 8.2 GB / 16 GB (51%)

You:    "find my day 3 recording"
Salim:  🔍 Found 3 results:
        1️⃣ 🎬 day3_recording.mp4 — ~/Videos — 2.1 GB
        [⬇️ Send] [🗑️ Delete]
```

---

## ⚡ Get Started in 3 Minutes

### Step 1 — Install

```bash
pip install salim
```

That's the only command needed. Python 3.9 or newer required.

> **Don't have Python?** Download it free from [python.org](https://python.org). After installing, open Terminal (Mac/Linux) or Command Prompt (Windows) and run the command above.

---

### Step 2 — Run Setup

```bash
salim setup
```

A friendly wizard will walk you through everything:

1. **Get a Telegram bot token** — takes 30 seconds (instructions shown on screen)
2. **Add your Telegram user ID** — so only *you* can control your laptop
3. **Optionally add free AI keys** — lets you type in plain English instead of commands

---

### Step 3 — Start

```bash
salim start
```

Open Telegram, find your bot, send `/start` — and you're in control.

---

## 🤖 AI Mode — Just Type Naturally

When you set up AI (optional but recommended — it's free!), you don't need to remember any commands. Just talk normally:

| What you type | What happens |
|---|---|
| `take a screenshot` | Takes and sends a screenshot |
| `how's my RAM?` | Shows memory usage |
| `find my day 3 recording` | Searches laptop, shows results with buttons |
| `write a csv about GDC` | AI writes a CSV file and saves it to Desktop |
| `write me a resume for Ahmed` | Creates a professional Word resume (.docx) |
| `create an invoice for Acme Corp` | Builds a formatted Excel invoice (.xlsx) |
| `make a cover letter for Google` | Generates a formatted cover letter (.docx) |
| `mute the volume` | Mutes your speakers |
| `lock my screen` | Locks the laptop |
| `check what's running` | Lists active processes |
| `shut down` | Asks for confirmation, then shuts down |

**Three free AI providers — all optional:**

| Provider | Where to get key | Speed |
|---|---|---|
| 🟢 **NVIDIA NIM** | [build.nvidia.com](https://build.nvidia.com) | Fast |
| 🟡 **Groq** | [console.groq.com](https://console.groq.com) | Ultra-fast |
| 🔵 **Z.AI (Zhipu)** | [z.ai](https://z.ai) | Fast & 100% free |

Salim tries them in order — if one fails, it falls back to the next automatically.

---

## 📱 All Commands

You can also use slash commands directly — no AI needed.

### 🖥️ System Info

| Command | What it does |
|---|---|
| `/info` | Full overview: OS, CPU, RAM, disk, battery, uptime |
| `/cpu` | Per-core CPU usage with visual bar chart |
| `/mem` | RAM and swap usage |
| `/disk` | All drives with used/free space |
| `/battery` | Charge level, plugged in or not, time remaining |
| `/network` | IP addresses, connection speed |
| `/uptime` | How long the computer has been running |
| `/top` | Live resource monitor (updates 5 times) |

### ⚙️ Processes

| Command | What it does |
|---|---|
| `/ps [name]` | List running programs (optional: filter by name) |
| `/kill <pid>` | Stop a process by its ID |
| `/top` | See what's using the most CPU/RAM |

### 💻 Shell (Run Commands)

| Command | What it does |
|---|---|
| `/run <command>` | Run any terminal command |
| `/runbg <command>` | Run in background, get notified when done |
| `/pipe cmd1 \|\|\| cmd2` | Chain commands with pipes |
| `/env` | View environment variables |
| `/which <program>` | Find where a program is installed |
| `/cron <seconds> <cmd>` | Run a command repeatedly on a schedule |
| `/cronjobs` | List your scheduled tasks |
| `/cronstop <id>` | Stop a scheduled task |

### 📂 Files

| Command | What it does |
|---|---|
| `/ls [path]` | List files in a directory |
| `/cd <path>` | Change working directory |
| `/pwd` | Show current directory |
| `/cat <file>` | Read a file's contents |
| `/find <name>` | Search for files by name |
| `/grep <text>` | Search inside files for text |
| `/mkdir <name>` | Create a folder |
| `/rm <path>` | Delete a file or folder (asks for confirmation) |
| `/mv <from> <to>` | Move or rename a file |
| `/cp <from> <to>` | Copy a file |
| `/write <file> <text>` | Write text to a file |
| `/download <path>` | Send a file from your laptop to Telegram |
| `/upload` | Send a file from Telegram to your laptop |
| `/zip <path>` | Create a zip archive |
| `/unzip <file>` | Extract a zip archive |

### 📸 Screen & Input

| Command | What it does |
|---|---|
| `/screenshot` or `/ss` | Take and send a screenshot |
| `/screenshot 3` | Take screenshot after 3-second delay |
| `/type <text>` | Type text as if using the keyboard |
| `/key <shortcut>` | Press a keyboard shortcut (e.g. `ctrl+c`, `cmd+space`) |
| `/click <x> <y>` | Click the mouse at screen coordinates |
| `/scroll <amount>` | Scroll the mouse wheel |
| `/move <x> <y>` | Move mouse cursor |
| `/mousepos` | See current cursor position |
| `/open <app or url>` | Open an app, file, or website |

### 📋 Clipboard

| Command | What it does |
|---|---|
| `/copy <text>` | Copy text to clipboard |
| `/paste` | Read what's in the clipboard |

### 🔔 Notifications & Media

| Command | What it does |
|---|---|
| `/notify <title> \| <message>` | Send a desktop notification |
| `/volume` | Check current volume level |
| `/volume 50` | Set volume to 50% |
| `/volume mute` | Mute or unmute |
| `/brightness 80` | Set screen brightness to 80% |

### 🔋 Power

| Command | What it does |
|---|---|
| `/shutdown` | Shut down (asks for confirmation) |
| `/restart` | Restart (asks for confirmation) |
| `/sleep` | Put laptop to sleep |
| `/hibernate` | Hibernate |
| `/lock` | Lock the screen |
| `/logout` | Log out the current user |
| `/screensaver` | Start the screensaver |
| `/displays` | List connected displays |

### 📄 Document Writer

| Command | What it does |
|---|---|
| `/doc resume for <name>` | Creates a professional CV/resume (.docx) |
| `/doc cover letter for <position>` | Formal cover letter (.docx) |
| `/doc job application for <company>` | Job application letter (.docx) |
| `/doc resignation letter` | Resignation letter (.docx) |
| `/doc NOC for <person>` | No Objection Certificate (.docx) |
| `/doc memo about <topic>` | Office memo / memorandum (.docx) |
| `/doc meeting minutes` | Minutes of meeting (.docx) |
| `/doc business report on <topic>` | Formal business report (.docx) |
| `/doc invoice for <client>` | Professional invoice with auto-totals (.xlsx) |
| `/doc budget tracker for <month>` | Monthly budget with variance tracking (.xlsx) |
| `/doc expense report` | Expense report with total (.xlsx) |
| `/doc project plan` | Project task tracker with status colors (.xlsx) |
| `/doc attendance sheet` | Staff attendance with auto-count (.xlsx) |
| `/doc salary sheet` | Payroll sheet with net salary formula (.xlsx) |
| `/doc inventory list` | Stock inventory with reorder alerts (.xlsx) |

All documents are saved to your Desktop and sent directly to Telegram.

**Formatting standards applied automatically:**
- Font: Calibri 11pt (professional docs) · Times New Roman 12pt (formal/legal)
- Margins: 1 inch all sides, US Letter page size
- Color-coded headers, justified body text, bold section titles
- Excel files use live formulas (not hardcoded values)

### ⚙️ Bot Settings

| Command | What it does |
|---|---|
| `/config` | View all settings |
| `/config set <key> <value>` | Change a setting |
| `/logs` | See recent command history |
| `/status` | Quick check: is everything working? |

---

## 🔒 Security — Only You Can Control It

Salim is built so that **no one else can touch your laptop** through the bot:

- **User whitelist** — Only Telegram accounts you approve can send commands
- **Silent rejection** — Strangers get zero response (no hints that a bot even exists)
- **Confirmation dialogs** — Dangerous actions (shutdown, delete) require you to tap "Yes" in Telegram
- **Audit log** — Every command is recorded with timestamp and who sent it
- **Secure storage** — Your credentials are stored locally with strict file permissions (`chmod 600`)
- **Token privacy** — Your bot token is never shown in full or written to logs

### Adding trusted users

```bash
salim adduser    # Interactive — shows you step-by-step
```

Or add multiple user IDs directly in `~/.salim/config.env`:
```
SALIM_ALLOWED_IDS=111222333,444555666
```

> **Finding your Telegram user ID:** Message [@userinfobot](https://t.me/userinfobot) on Telegram and send `/start`. It will reply with your numeric ID.

---

## 🛠️ CLI Commands

```bash
salim setup      # Run the setup wizard (first-time or to change settings)
salim start      # Start your bot
salim start -v   # Start with detailed logging
salim status     # Check configuration and installed features
salim config     # View or edit settings interactively
salim logs       # View the command history
salim test       # Test your Telegram connection
salim adduser    # Add a new authorized user
salim stop       # Stop the bot (if running in background)
salim uninstall  # Remove all Salim data from your computer
```

---

## 🔧 Configuration File

Settings are saved in `~/.salim/config.env`. You can edit this file directly or use `salim config`.

```env
SALIM_BOT_TOKEN=1234567890:ABCdef...        # Your Telegram bot token
SALIM_ALLOWED_IDS=123456789                  # Comma-separated user IDs
SALIM_DOWNLOAD_DIR=/Users/you/Downloads      # Where to look for downloadable files
SALIM_UPLOAD_DIR=/Users/you/Desktop         # Where to save uploaded files
SALIM_MAX_FILE_MB=50                         # Max size of files to send via Telegram
SALIM_SCREENSHOT_QUALITY=85                 # JPEG quality for screenshots (1-100)
SALIM_LOG_COMMANDS=true                     # Keep an audit log of all commands

# AI keys (optional — set during setup or add manually)
SALIM_NVIDIA_API_KEY=nvapi-...
SALIM_NVIDIA_MODEL=meta/llama-4-maverick-17b-128e-instruct
SALIM_GROQ_API_KEY=gsk_...
SALIM_GROQ_MODEL=openai/gpt-oss-120b
SALIM_ZAI_API_KEY=...
SALIM_ZAI_MODEL=glm-4.7-flash
```

You can also change settings from inside Telegram:
```
/config set max_file_mb 200
/config set screenshot_quality 95
```

---

## 🚀 Run Automatically at Startup

Want Salim to start every time your computer boots?

### macOS

```bash
# Save this as ~/Library/LaunchAgents/com.salim.plist
```

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>             <string>com.salim</string>
    <key>ProgramArguments</key>  <array><string>/usr/local/bin/salim</string><string>start</string><string>--no-banner</string></array>
    <key>RunAtLoad</key>         <true/>
    <key>KeepAlive</key>         <true/>
    <key>StandardErrorPath</key> <string>/tmp/salim.err</string>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.salim.plist
```

### Linux (systemd)

```ini
# /etc/systemd/system/salim.service
[Unit]
Description=Salim Laptop Control Bot
After=network.target

[Service]
Type=simple
User=youruser
ExecStart=/usr/local/bin/salim start --no-banner
Restart=always
RestartSec=10
Environment=DISPLAY=:0

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now salim
```

### Windows (Task Scheduler)

```powershell
$action  = New-ScheduledTaskAction -Execute "salim" -Argument "start --no-banner"
$trigger = New-ScheduledTaskTrigger -AtLogOn
Register-ScheduledTask -TaskName "Salim" -Action $action -Trigger $trigger -RunLevel Highest
```

---

## 📦 Optional Features

Some features require extra packages. Install them for the full experience:

```bash
pip install pyautogui Pillow pyperclip aiofiles
```

| Package | What it unlocks |
|---|---|
| `pyautogui` | Screenshots, mouse control, keyboard automation |
| `Pillow` | Screenshot compression (smaller file sizes) |
| `pyperclip` | Clipboard read/write |
| `aiofiles` | Faster file transfers |

If these aren't installed, Salim will tell you which commands need them and how to get them.

---

## ❓ Common Questions

**Do I need technical knowledge to use this?**
Not at all. Run `pip install salim` then `salim setup` — the wizard explains every step clearly with examples.

**Is it safe to leave running?**
Yes. Only your approved Telegram accounts can send commands. All others are completely ignored.

**What if I lose internet / Telegram goes down?**
Salim will automatically reconnect. The bot just waits patiently.

**Can multiple people control one laptop?**
Yes — add multiple Telegram user IDs with `salim adduser`. Each person's commands are logged separately.

**Do I need to pay for the AI features?**
No. All three AI providers (NVIDIA NIM, Groq, Z.AI) have **completely free tiers** that are more than enough for personal use. Z.AI's Flash models have no stated limits at all.

**Does this work on Windows?**
Yes — macOS, Linux, and Windows are all supported.

**What if a command fails?**
Salim tells you exactly what went wrong in plain English. For AI key problems, it tells you the exact error (like "401 Unauthorized") so you know whether it's a wrong key or a network issue.

---

## 📄 License

MIT — free to use, modify, and share. See [LICENSE](LICENSE).

---

<p align="center">
  Made with ❤️ — Control your world from your pocket.
</p>
