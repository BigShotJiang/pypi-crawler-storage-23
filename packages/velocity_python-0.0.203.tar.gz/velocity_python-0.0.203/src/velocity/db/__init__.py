"""Velocity DB public API.

Keep top-level imports lightweight so users can install base package
without pulling in database-specific optional dependencies.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

from velocity.db import exceptions
from velocity.db import utils

if TYPE_CHECKING:  # pragma: no cover
    # For type checkers only; runtime imports are lazy.
    from velocity.db.servers import mysql, postgres, sqlite, sqlserver

# Export commonly used utility functions
from velocity.db.utils import (
    safe_sort_rows,
    safe_sort_key_none_last,
    safe_sort_key_none_first,
    safe_sort_key_with_default,
    group_by_fields,
    safe_sort_grouped_rows,
)

__all__ = [
    "exceptions",
    "postgres",
    "mysql",
    "sqlite",
    "sqlserver",
    "utils",
    "safe_sort_rows",
    "safe_sort_key_none_last",
    "safe_sort_key_none_first",
    "safe_sort_key_with_default",
    "group_by_fields",
    "safe_sort_grouped_rows",
]


_SERVER_MODULES = {"postgres", "mysql", "sqlite", "sqlserver"}


def __getattr__(name: str):
    if name in _SERVER_MODULES:
        # e.g. velocity.db.postgres -> velocity.db.servers.postgres
        return importlib.import_module(f"velocity.db.servers.{name}")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    return sorted(set(globals().keys()) | _SERVER_MODULES)
