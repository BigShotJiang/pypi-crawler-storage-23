import decimal

from velocity.misc.conv import iconv


def test_money_to_cents_none_and_empty():
    assert iconv.money_to_cents(None) == 0
    assert iconv.money_to_cents("") == 0
    assert iconv.money_to_cents("   ") == 0


def test_money_to_cents_numeric_types():
    assert iconv.money_to_cents(10) == 1000
    assert iconv.money_to_cents(10.5) == 1050
    assert iconv.money_to_cents(decimal.Decimal("10.50")) == 1050


def test_money_to_cents_string_values():
    assert iconv.money_to_cents("10") == 1000
    assert iconv.money_to_cents("10.50") == 1050
