import unittest

from velocity.aws.handlers.lambda_handler import LambdaHandler


class _Perf:
    def start(self, *args, **kwargs):
        return None

    def log(self, *args, **kwargs):
        return None


class _Context:
    def __init__(self, action=None, postdata=None, session=None):
        self._action = action
        self._postdata = postdata
        self._session = session if isinstance(session, dict) else {}
        self.perf = _Perf()

    def action(self):
        return self._action

    def args(self):
        return {}

    def postdata(self):
        return self._postdata

    def session(self):
        return self._session

    def get_cognito_user(self, aws_event):  # pragma: no cover
        raise AssertionError("get_cognito_user should not be called")

    def get_cognito_user_optional(self, aws_event):  # pragma: no cover
        raise AssertionError("get_cognito_user_optional should not be called")


class _Handler(LambdaHandler):
    def _enhanced_before_action(self, tx, context):
        return False

    def _enhanced_error_handler(self, tx, context, exc, tb):
        return False


class TestLambdaHandlerAuthModes(unittest.TestCase):
    def test_auth_mode_none_skips_cognito(self):
        h = _Handler(
            aws_event={}, aws_context=type("C", (), {"aws_request_id": "rid"})()
        )
        h.auth_mode = "none"
        h.require_db_user = False
        h.beforeAction(tx=object(), context=_Context(action="anything", postdata={}))

    def test_public_actions_bypass_auth_and_db_user(self):
        h = _Handler(
            aws_event={}, aws_context=type("C", (), {"aws_request_id": "rid"})()
        )
        h.auth_mode = "required"
        h.require_db_user = True
        h.user_table = "users"
        h.public_actions = ["public-action"]

        # Should not call cognito, should not require session email
        h.beforeAction(
            tx=object(), context=_Context(action="public-action", postdata={})
        )

    def test_onerror_does_not_require_payload(self):
        h = _Handler(
            aws_event={}, aws_context=type("C", (), {"aws_request_id": "rid"})()
        )
        h.onError(
            tx=object(),
            context=_Context(action="anything", postdata={}),
            exc="E",
            tb="TB",
        )
        h.onError(
            tx=object(),
            context=_Context(action="anything", postdata={"payload": "not-a-dict"}),
            exc="E",
            tb="TB",
        )


if __name__ == "__main__":
    unittest.main()
