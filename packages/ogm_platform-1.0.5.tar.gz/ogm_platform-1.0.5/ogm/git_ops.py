"""Git operations module."""

import shutil
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import urlparse

try:
    from git import Repo
    from git.exc import InvalidGitRepositoryError
except ImportError:

    class MockRepo:
        pass

    RepoClass = MockRepo
    GitCommandErrorClass = Exception
    InvalidGitRepositoryErrorClass = Exception

try:
    from rich.console import Console

    console = Console()
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    console = MockConsole()  # type: ignore


class GitManager:
    """Manages Git repository operations."""

    def __init__(self, repos_dir: Path, auth_manager=None):
        """Initialize Git manager.

        Args:
            repos_dir: Directory to store cloned repositories
            auth_manager: AuthManager instance for authentication
        """
        self.repos_dir = Path(repos_dir)
        self.repos_dir.mkdir(parents=True, exist_ok=True)
        self.auth_manager = auth_manager

    def _prepare_auth(self, url: str) -> tuple[str, Dict]:
        """Prepare authentication for Git URL.

        Args:
            url: Repository URL

        Returns:
            Tuple of (prepared_url, git_kwargs) for authentication
        """
        git_kwargs: Dict = {}
        prepared_url = url

        if not self.auth_manager:
            return prepared_url, git_kwargs

        parsed = urlparse(url)

        # Handle HTTPS with token authentication
        if parsed.scheme == "https":
            git_creds = self.auth_manager.get_git_credentials()
            if git_creds:
                # Replace URL with token-authenticated version
                hostname = parsed.hostname
                username = git_creds.get("username", "")
                token = git_creds.get("token", "")

                prepared_url = f"https://{username}:{token}@{hostname}{parsed.path}"
                git_kwargs["env"] = {
                    "GIT_TERMINAL_PROMPT": "0",  # Disable Git prompt
                }
                console.print(f"[cyan]Using token authentication for {hostname}[/cyan]")

        # Handle SSH with key authentication
        elif parsed.scheme == "ssh" or "git@" in url:
            # Check for SSH key
            ssh_key = Path.home() / ".ssh" / "id_rsa"
            if ssh_key.exists():
                git_kwargs["env"] = {
                    "GIT_SSH_COMMAND": f"ssh -i {ssh_key} -o StrictHostKeyChecking=no"
                }
                console.print("[cyan]Using SSH key authentication[/cyan]")

        return prepared_url, git_kwargs

    def clone_repository(self, config, progress_callback=None):
        """Clone a repository."""
        if Repo is None:
            console.print("[red]GitPython not installed. Run: pip install GitPython[/red]")
            return None

        repo_path = self.repos_dir / config.name

        if repo_path.exists():
            try:
                repo = Repo(repo_path)
                console.print(f"[green]✓ Using existing repository: {config.name}[/green]")
                return repo
            except InvalidGitRepositoryError:
                shutil.rmtree(repo_path)

        console.print(f"[cyan]Cloning {config.name}...[/cyan]")
        try:
            # Prepare authentication
            prepared_url, git_kwargs = self._prepare_auth(config.url)

            # Check if we should do sparse checkout
            sparse_paths = getattr(config, 'path', None) or getattr(config, 'paths', None)
            if sparse_paths:
                if isinstance(sparse_paths, str):
                    sparse_paths = [sparse_paths]

                console.print(f"[cyan]Sparse checkout: {', '.join(sparse_paths)}[/cyan]")

                # Clone without checkout
                repo = Repo.clone_from(prepared_url, repo_path, branch=config.branch,
                                     no_checkout=True, **git_kwargs)

                # Configure sparse checkout
                with repo.config_writer() as git_config:
                    git_config.set_value('core', 'sparseCheckout', True)

                # Set sparse checkout paths
                sparse_checkout_path = repo_path / '.git' / 'info' / 'sparse-checkout'
                sparse_checkout_path.parent.mkdir(parents=True, exist_ok=True)

                with open(sparse_checkout_path, 'w') as f:
                    for path in sparse_paths:
                        f.write(f"{path}\n")
                        f.write(f"{path}/**\n")  # Include subdirectories

                # Checkout sparse paths
                repo.git.checkout()
            else:
                # Normal clone
                repo = Repo.clone_from(prepared_url, repo_path, branch=config.branch, **git_kwargs)

            console.print(f"[green]✓ Cloned: {config.name}[/green]")
            return repo
        except Exception as e:
            console.print(f"[red]✗ Failed: {e}[/red]")
            return None

    def pull_repository(self, repo_name: str) -> bool:
        """Pull latest changes."""
        if Repo is None:
            return False

        repo_path = self.repos_dir / repo_name
        if not repo_path.exists():
            return False

        try:
            repo = Repo(repo_path)
            # For sparse checkout repos, we need to be careful with pull
            origin = repo.remotes.origin
            origin.pull()
            console.print(f"[green]✓ Updated: {repo_name}[/green]")
            return True
        except Exception as e:
            console.print(f"[red]✗ Failed: {e}[/red]")
            return False

    def get_status(self, repo_name: str) -> Optional[Dict]:
        """Get repository status."""
        if Repo is None:
            return None

        repo_path = self.repos_dir / repo_name
        if not repo_path.exists():
            return None

        try:
            repo = Repo(repo_path)
            return {
                "name": repo_name,
                "branch": repo.active_branch.name,
                "commit": repo.head.commit.hexsha[:7],
                "commit_message": repo.head.commit.message.strip(),
                "is_dirty": repo.is_dirty(),
            }
        except Exception:
            return None

    def get_all_statuses(self) -> List[Dict]:
        """Get status for all repositories."""
        statuses = []
        for repo_dir in self.repos_dir.iterdir():
            if repo_dir.is_dir() and (repo_dir / ".git").exists():
                status = self.get_status(repo_dir.name)
                if status:
                    statuses.append(status)
        return statuses

    def remove_repository(self, repo_name: str, force: bool = False) -> bool:
        """Remove a repository."""
        repo_path = self.repos_dir / repo_name
        if not repo_path.exists():
            return True

        try:
            shutil.rmtree(repo_path)
            console.print(f"[green]✓ Removed: {repo_name}[/green]")
            return True
        except Exception as e:
            console.print(f"[red]✗ Failed: {e}[/red]")
            return False

    def fetch_all(self, repo_name: str) -> bool:
        """Fetch all remotes."""
        if Repo is None:
            return False

        repo_path = self.repos_dir / repo_name
        if not repo_path.exists():
            return False

        try:
            repo = Repo(repo_path)
            for remote in repo.remotes:
                remote.fetch()
            return True
        except Exception:
            return False
