"""Kubernetes cluster management module - supports both K3s and full Kubernetes."""

import os
import platform
import shutil
import subprocess
import time
from pathlib import Path
from typing import List, Optional, Tuple

from .utils import run_command

try:
    from rich.console import Console

    console = Console()
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    console = MockConsole()  # type: ignore


class K3sManager:
    """Manages Kubernetes cluster lifecycle (K3s or Full K8s for DEV, Full K8s for STAGE/PROD)."""

    def __init__(self, config, cluster_type: Optional[str] = None):
        self.config = config
        self.kubeconfig_path = Path(config.kubeconfig_path).expanduser()
        # Determine cluster type from environment or parameter
        self.environment = os.getenv("ENVIRONMENT", "dev").lower()
        
        if cluster_type:
            # Use provided cluster type
            self.cluster_type = "k3s" if "k3s" in cluster_type.lower() else "k8s"
        else:
            # Fallback to environment-based logic
            self.cluster_type = "k3s" if self.environment == "dev" else "k8s"

    def is_installed(self) -> bool:
        """Check if Kubernetes cluster is installed and accessible."""
        if self.cluster_type == "k3s":
            # For dev environment, be more lenient - if kubectl works, consider cluster accessible
            # Check if cluster is accessible via kubectl (k3s binary not strictly required)
            result = run_command(
                ["kubectl", "get", "nodes", "--request-timeout=10s"],
                capture_output=True,
                check=False,
            )
            return result is not None and "Ready" in result
        else:
            # For full Kubernetes, check kubectl exists and can connect to cluster
            if not shutil.which("kubectl"):
                return False
            # Try to get nodes to verify cluster connectivity
            result = run_command(
                ["kubectl", "get", "nodes", "--request-timeout=10s"],
                capture_output=True,
                check=False,
            )
            return result is not None and "Ready" in result

    def get_version(self) -> Optional[str]:
        if not self.is_installed():
            return None

        if self.cluster_type == "k3s":
            result = run_command(["k3s", "--version"], capture_output=True)
            if result:
                return result.split()[2] if len(result.split()) > 2 else None
        else:
            # For full Kubernetes, get kubectl version
            result = run_command(["kubectl", "version", "--client"], capture_output=True)
            if result:
                # Extract version from output like "Client Version: v1.28.2"
                for line in result.split("\n"):
                    if "Client Version:" in line:
                        return line.split(":")[1].strip().lstrip("v")
        return None

    def install(self) -> bool:
        """Install Kubernetes cluster based on environment."""
        cluster_name = "K3s (Lightweight)" if self.cluster_type == "k3s" else "Full Kubernetes"
        console.print(f"\n[bold cyan]Installing {cluster_name}...[/bold cyan]")
        env_info = f"Environment: {self.environment.upper()}, " f"Type: {self.cluster_type.upper()}"
        console.print(f"[dim]{env_info}[/dim]\n")

        if self.is_installed():
            console.print("[yellow]Kubernetes already installed and running[/yellow]")
            # Ensure kubeconfig is properly set up
            if self.cluster_type == "k3s":
                self._setup_kubeconfig()
            # Fix kubeconfig if it exists and has wrong server address
            if self.cluster_type == "k8s":
                self._fix_kubeconfig_server()
            return True

        # Check if K3s binary exists but cluster is not running
        if self.cluster_type == "k3s" and shutil.which("k3s"):
            console.print("[yellow]K3s binary found but cluster not running, attempting cleanup and restart...[/yellow]")
            
            # Try to start K3s service first
            result = subprocess.run(["sudo", "systemctl", "start", "k3s"], capture_output=True)
            if result.returncode == 0:
                console.print("[green]✓ K3s service started[/green]")
                self._wait_for_ready()
                self._setup_kubeconfig()
                return True
            else:
                console.print("[yellow]⚠️  Could not start K3s service, attempting uninstall and reinstall...[/yellow]")
                # Try to uninstall first
                self.uninstall()
                console.print("[dim]Waiting 5 seconds after uninstall...[/dim]")
                time.sleep(5)

        system = platform.system()
        if system == "Linux":
            if self.cluster_type == "k3s":
                return self._install_k3s_linux()
            else:
                return self._install_k8s_linux()
        elif system == "Darwin":
            return self._install_macos()
        else:
            console.print(f"[red]Unsupported OS: {system}[/red]")
            return False

    def _install_k3s_linux(self) -> bool:
        """Install K3s on Linux (DEV environment ONLY)."""
        # Safety check: K3s should only be installed in dev environment
        if self.environment != "dev":
            console.print(
                f"[red]❌ K3s installation attempted in {self.environment} environment[/red]"
            )
            console.print(
                "[red]K3s is only for development. Use full Kubernetes for stage/prod.[/red]"
            )
            return False

        console.print("[cyan]Installing K3s (Lightweight) on Linux...[/cyan]")
        
        # Build K3s installation command with environment variables for remote access
        env_vars = []
        
        # Use environment variables if set (from GitLab CI)
        install_version = os.getenv("INSTALL_K3S_VERSION", self.config.version)
        tls_san = os.getenv("K3S_TLS_SAN")
        kubeconfig_mode = os.getenv("K3S_KUBECONFIG_MODE", "644")
        
        if install_version:
            env_vars.append(f"INSTALL_K3S_VERSION={install_version}")
        if tls_san:
            env_vars.append(f"K3S_TLS_SAN={tls_san}")
        if kubeconfig_mode:
            env_vars.append(f"K3S_KUBECONFIG_MODE={kubeconfig_mode}")
        
        env_part = " ".join(env_vars) + " " if env_vars else ""
        
        # Build the installation command
        base_cmd = (
            f"curl -sfL https://get.k3s.io | "
            f"{env_part}sh -s - "
            f"--write-kubeconfig-mode {kubeconfig_mode} --disable traefik --disable servicelb"
        )
        
        # Add TLS SAN to command line if specified
        if tls_san:
            base_cmd += f" --tls-san {tls_san}"
            console.print(f"[cyan]Configuring remote access for IP: {tls_san}[/cyan]")
        
        cmd = f"sudo sh -c '{base_cmd}'"
        
        console.print(f"[dim]Running: {base_cmd}[/dim]")
        result = subprocess.run(cmd, shell=True)
        if result.returncode == 0:
            console.print("[green]✓ K3s installed[/green]")
            self._wait_for_ready()
            self._setup_kubeconfig()
            return True
        return False

    def _install_k8s_linux(self) -> bool:
        """Install full Kubernetes on Linux (STAGE/PROD environment)."""
        console.print("[cyan]Installing Full Kubernetes on Linux...[/cyan]")

        try:
            # Step 1: Disable swap
            console.print("[dim]Step 1/10: Disabling swap...[/dim]")
            subprocess.run(["sudo", "swapoff", "-a"], check=True)
            subprocess.run(
                ["sudo", "sed", "-i", "/ swap / s/^\\(.*\\)$/#\\1/g", "/etc/fstab"], check=True
            )
            console.print("[green]✓ Swap disabled[/green]")

            # Step 2: Install containerd
            console.print("[dim]Step 2/10: Installing containerd...[/dim]")
            result = subprocess.run(["sudo", "apt-get", "update"])
            if result.returncode != 0:
                console.print("[red]apt-get update failed. Output:[/red]")
                # Run again with capture to show the error
                result = subprocess.run(["sudo", "apt-get", "update"], capture_output=True, text=True)
                console.print(f"[red]{result.stdout}[/red]")
                console.print(f"[red]{result.stderr}[/red]")
                raise subprocess.CalledProcessError(result.returncode, result.args)
            subprocess.run(["sudo", "apt-get", "install", "-y", "containerd"], check=True)

            # Configure containerd
            subprocess.run(["sudo", "mkdir", "-p", "/etc/containerd"], check=True)
            result = subprocess.run(
                ["containerd", "config", "default"], capture_output=True, text=True
            )
            with open("/tmp/config.toml", "w") as f:
                f.write(result.stdout)
            subprocess.run(
                ["sudo", "mv", "/tmp/config.toml", "/etc/containerd/config.toml"], check=True
            )
            subprocess.run(
                [
                    "sudo",
                    "sed",
                    "-i",
                    "s/SystemdCgroup = false/SystemdCgroup = true/",
                    "/etc/containerd/config.toml",
                ],
                check=True,
            )
            subprocess.run(["sudo", "systemctl", "restart", "containerd"], check=True)
            subprocess.run(["sudo", "systemctl", "enable", "containerd"], check=True)
            console.print("[green]✓ containerd installed[/green]")

            # Step 3: Load kernel modules
            console.print("[dim]Step 3/10: Loading kernel modules...[/dim]")
            modules_content = "overlay\nbr_netfilter\n"
            subprocess.run(
                ["sudo", "tee", "/etc/modules-load.d/k8s.conf"],
                input=modules_content.encode(),
                check=True,
                capture_output=True,
            )
            subprocess.run(["sudo", "modprobe", "overlay"], check=True)
            subprocess.run(["sudo", "modprobe", "br_netfilter"], check=True)
            console.print("[green]✓ Kernel modules loaded[/green]")

            # Step 4: Configure sysctl
            console.print("[dim]Step 4/10: Configuring sysctl...[/dim]")
            sysctl_content = (
                "net.bridge.bridge-nf-call-iptables  = 1\n"
                "net.bridge.bridge-nf-call-ip6tables = 1\n"
                "net.ipv4.ip_forward                 = 1\n"
            )
            subprocess.run(
                ["sudo", "tee", "/etc/sysctl.d/k8s.conf"],
                input=sysctl_content.encode(),
                check=True,
                capture_output=True,
            )
            subprocess.run(["sudo", "sysctl", "--system"], check=True, capture_output=True)
            console.print("[green]✓ sysctl configured[/green]")

            # Step 5: Install Kubernetes packages
            console.print("[dim]Step 5/10: Installing Kubernetes packages...[/dim]")
            subprocess.run(
                [
                    "sudo",
                    "apt-get",
                    "install",
                    "-y",
                    "apt-transport-https",
                    "ca-certificates",
                    "curl",
                ],
                check=True,
            )
            subprocess.run(["sudo", "mkdir", "-p", "/etc/apt/keyrings"], check=True)
            # Download GPG key
            subprocess.run(
                [
                    "curl",
                    "-fsSL",
                    "https://pkgs.k8s.io/core:/stable:/v1.28/deb/Release.key",
                    "-o",
                    "/tmp/k8s-key",
                ],
                check=True,
            )
            # Dearmor the key
            with open("/tmp/k8s-key", "rb") as key_file:
                subprocess.run(
                    ["sudo", "gpg", "--batch", "--yes", "--dearmor"],
                    input=key_file.read(),
                    stdout=open("/tmp/k8s-key.gpg", "wb"),
                    check=True,
                )
            subprocess.run(
                ["sudo", "mv", "/tmp/k8s-key.gpg", "/etc/apt/keyrings/kubernetes-apt-keyring.gpg"],
                check=True,
            )
            # Clean up
            subprocess.run(["rm", "-f", "/tmp/k8s-key"], check=False)
            sources_cmd = " ".join(
                [
                    "echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg]",
                    "https://pkgs.k8s.io/core:/stable:/v1.28/deb/ /' |",
                    "sudo tee /etc/apt/sources.list.d/kubernetes.list",
                ]
            )
            subprocess.run(
                sources_cmd,
                shell=True,
                check=True,
            )
            result = subprocess.run(["sudo", "apt-get", "update"])
            if result.returncode != 0:
                console.print("[red]apt-get update failed after adding Kubernetes repo. Output:[/red]")
                # Run again with capture to show the error
                result = subprocess.run(["sudo", "apt-get", "update"], capture_output=True, text=True)
                console.print(f"[red]{result.stdout}[/red]")
                console.print(f"[red]{result.stderr}[/red]")
                raise subprocess.CalledProcessError(result.returncode, result.args)
            subprocess.run(
                ["sudo", "apt-get", "install", "-y", "kubelet", "kubeadm", "kubectl"],
                check=True,
            )
            subprocess.run(
                ["sudo", "apt-mark", "hold", "kubelet", "kubeadm", "kubectl"],
                check=True,
            )

            # Create symlink for kubectl in /usr/local/bin (user preference)
            if not Path("/usr/local/bin/kubectl").exists():
                subprocess.run(
                    ["sudo", "ln", "-sf", "/usr/bin/kubectl", "/usr/local/bin/kubectl"],
                    check=False,
                )

            console.print("[green]✓ Kubernetes packages installed[/green]")

            # Step 5.5: Install Helm
            console.print("[dim]Step 5.5/10: Installing Helm...[/dim]")
            helm_installed = (
                subprocess.run(["which", "helm"], capture_output=True, check=False).returncode == 0
            )

            if not helm_installed:
                helm_script = (
                    "curl -fsSL https://raw.githubusercontent.com/helm/helm/"
                    "main/scripts/get-helm-3 | bash"
                )
                subprocess.run(helm_script, shell=True, check=True)
                console.print("[green]✓ Helm installed[/green]")
            else:
                console.print("[green]✓ Helm already installed[/green]")

            # Step 6: Initialize cluster
            init_msg = (
                "Step 6/10: Initializing Kubernetes cluster " "(this may take a few minutes)..."
            )
            console.print(f"[dim]{init_msg}[/dim]")
            subprocess.run(
                ["sudo", "kubeadm", "init", "--pod-network-cidr=10.244.0.0/16"], check=True
            )
            console.print("[green]✓ Cluster initialized[/green]")

            # Step 7: Setup kubeconfig
            console.print("[dim]Step 7/10: Setting up kubeconfig...[/dim]")
            home = Path.home()
            kube_dir = home / ".kube"
            kube_dir.mkdir(parents=True, exist_ok=True)
            subprocess.run(
                [
                    "sudo",
                    "cp",
                    "/etc/kubernetes/admin.conf",
                    str(kube_dir / "config"),
                ],
                check=True,
            )
            subprocess.run(
                [
                    "sudo",
                    "chown",
                    f"{os.getuid()}:{os.getgid()}",
                    str(kube_dir / "config"),
                ],
                check=True,
            )

            # Fix kubeconfig to use actual server IP instead of 127.0.0.1
            # This is critical for remote servers where certificate validation fails
            console.print("[dim]Fixing kubeconfig server address...[/dim]")

            # Get the actual node IP
            result = subprocess.run(
                ["hostname", "-I"],
                capture_output=True,
                text=True,
            )
            server_ip = result.stdout.split()[0] if result.stdout else None

            if server_ip and server_ip != "127.0.0.1":
                # Use sed to replace ALL occurrences of 127.0.0.1 (more reliable)
                kubeconfig_file = str(kube_dir / "config")
                admin_conf = "/etc/kubernetes/admin.conf"

                # Fix user's kubeconfig
                sed_cmd = (
                    f"sed -i 's|https://127.0.0.1:6443|"
                    f"https://{server_ip}:6443|g' {kubeconfig_file}"
                )
                subprocess.run(sed_cmd, shell=True, check=True)

                # Fix admin.conf (source file)
                sudo_sed_cmd = (
                    f"sudo sed -i 's|https://127.0.0.1:6443|"
                    f"https://{server_ip}:6443|g' {admin_conf}"
                )
                subprocess.run(sudo_sed_cmd, shell=True, check=True)

                # Enable insecure-skip-tls-verify for DEV environment only
                if self.environment == "dev":
                    subprocess.run(
                        [
                            "kubectl",
                            "config",
                            "set-cluster",
                            "kubernetes",
                            "--insecure-skip-tls-verify=true",
                        ],
                        check=True,
                    )

                console.print(f"[green]✓ Kubeconfig fixed (server: {server_ip})[/green]")
            else:
                console.print("[yellow]⚠️  Could not determine server IP, using default[/yellow]")

            console.print("[green]✓ Kubeconfig configured[/green]")

            # Step 8: Install Flannel network plugin
            console.print("[dim]Step 8/10: Installing Flannel network plugin...[/dim]")
            subprocess.run(
                [
                    "kubectl",
                    "apply",
                    "-f",
                    "https://github.com/flannel-io/flannel/releases/latest/"
                    "download/kube-flannel.yml",
                ],
                check=True,
            )
            console.print("[green]✓ Flannel installed[/green]")

            # Step 9: Remove control-plane taint (single-node cluster)
            console.print("[dim]Step 9/10: Configuring single-node cluster...[/dim]")
            subprocess.run(
                ["kubectl", "taint", "nodes", "--all", "node-role.kubernetes.io/control-plane-"],
                check=False,
            )  # May not exist, so don't fail
            console.print("[green]✓ Single-node configuration applied[/green]")

            # Step 10: Wait for cluster to be ready
            console.print("[dim]Step 10/10: Waiting for cluster to be ready...[/dim]")
            self._wait_for_ready(timeout=300)  # 5 minutes timeout for full K8s

            console.print("\n[bold green]✅ Full Kubernetes installation complete![/bold green]")
            return True

        except subprocess.CalledProcessError as e:
            console.print(f"[red]✗ Installation failed: {e}[/red]")
            return False
        except Exception as e:
            console.print(f"[red]✗ Unexpected error: {e}[/red]")
            return False

    def _install_macos(self) -> bool:
        console.print("[yellow]macOS requires Docker Desktop or Rancher Desktop[/yellow]")
        console.print("Please install manually from: https://rancherdesktop.io/")
        return False

    def _wait_for_ready(self, timeout: int = 120) -> bool:
        console.print("[cyan]Waiting for K3s...[/cyan]")
        start = time.time()
        while time.time() - start < timeout:
            result = run_command(["kubectl", "get", "nodes"], capture_output=True, check=False)
            if result and "Ready" in result:
                console.print("[green]✓ K3s ready[/green]")
                return True
            time.sleep(5)
        return False

    def _fix_kubeconfig_server(self) -> None:
        """Fix kubeconfig server address to use actual IP instead of 127.0.0.1."""
        try:
            kubeconfig = Path.home() / ".kube" / "config"
            if not kubeconfig.exists():
                console.print("[yellow]⚠️  Kubeconfig not found at ~/.kube/config[/yellow]")
                return

            console.print("[cyan]🔧 Checking kubeconfig server address...[/cyan]")

            # Get current server address
            result = subprocess.run(
                ["kubectl", "config", "view", "-o", "jsonpath='{.clusters[0].cluster.server}'"],
                capture_output=True,
                text=True,
                check=False,
            )
            current_server = result.stdout.strip("'")

            if "127.0.0.1" in current_server:
                # Get actual server IP
                result = subprocess.run(
                    ["hostname", "-I"], capture_output=True, text=True, check=False
                )
                server_ip = result.stdout.split()[0] if result.stdout else None

                if server_ip and server_ip != "127.0.0.1":
                    new_server = f"https://{server_ip}:6443"
                    console.print(
                        f"[yellow]Fixing kubeconfig: {current_server} → {new_server}[/yellow]"
                    )

                    # Update server address
                    subprocess.run(
                        [
                            "kubectl",
                            "config",
                            "set-cluster",
                            "kubernetes",
                            f"--server={new_server}",
                        ],
                        check=True,
                    )

                    # Set insecure-skip-tls-verify temporarily
                    subprocess.run(
                        [
                            "kubectl",
                            "config",
                            "set-cluster",
                            "kubernetes",
                            "--insecure-skip-tls-verify=true",
                        ],
                        check=True,
                    )

                    console.print(f"[green]✓ Kubeconfig server updated to {server_ip}[/green]")
                    console.print(
                        "[yellow]⚠️  Using insecure-skip-tls-verify "
                        "(certificate will be regenerated)[/yellow]"
                    )

                    # Try to regenerate the API server certificate
                    try:
                        console.print("[dim]Regenerating API server certificate...[/dim]")
                        # Force regenerate by removing old cert first
                        subprocess.run(
                            [
                                "sudo",
                                "rm",
                                "-f",
                                "/etc/kubernetes/pki/apiserver.crt",
                                "/etc/kubernetes/pki/apiserver.key",
                            ],
                            check=False,
                        )
                        # Regenerate certificate with correct IP
                        subprocess.run(
                            [
                                "sudo",
                                "kubeadm",
                                "init",
                                "phase",
                                "certs",
                                "apiserver",
                                f"--apiserver-cert-extra-sans={server_ip}",
                            ],
                            check=True,
                        )
                        console.print("[green]✓ Certificate regenerated[/green]")

                        # Try multiple restart methods for API server
                        console.print("[dim]Restarting API server (multiple methods)...[/dim]")

                        # Method 1: Kill API server container (most reliable)
                        result = subprocess.run(
                            ["sudo", "crictl", "ps", "--name=kube-apiserver", "-q"],
                            capture_output=True,
                            text=True,
                            check=False,
                        )
                        api_container = result.stdout.strip()
                        if api_container:
                            console.print(f"[dim]Found API container: {api_container}[/dim]")
                            subprocess.run(
                                ["sudo", "crictl", "stop", api_container],
                                check=False,
                                capture_output=True,
                            )
                            subprocess.run(
                                ["sudo", "crictl", "rm", api_container],
                                check=False,
                                capture_output=True,
                            )
                            console.print("[green]✓ Container stopped[/green]")

                        # Method 2: Manifest manipulation
                        subprocess.run(
                            [
                                "sudo",
                                "mv",
                                "/etc/kubernetes/manifests/kube-apiserver.yaml",
                                "/tmp/kube-apiserver.yaml.tmp",
                            ],
                            check=False,
                        )
                        time.sleep(3)
                        subprocess.run(
                            [
                                "sudo",
                                "mv",
                                "/tmp/kube-apiserver.yaml.tmp",
                                "/etc/kubernetes/manifests/kube-apiserver.yaml",
                            ],
                            check=False,
                        )

                        # Method 3: Restart kubelet
                        subprocess.run(["sudo", "systemctl", "restart", "kubelet"], check=False)

                        # Wait for API server (90 seconds max)
                        console.print("[dim]Waiting for API server (max 90s)...[/dim]")
                        api_online = False
                        for i in range(18):  # 18 x 5 = 90 seconds
                            time.sleep(5)
                            result = subprocess.run(  # type: ignore
                                [
                                    "kubectl",
                                    "--insecure-skip-tls-verify",
                                    "get",
                                    "--raw",
                                    "/healthz",
                                ],
                                capture_output=True,
                                check=False,
                            )
                            if result.returncode == 0:
                                console.print(f"[green]✓ API server online ({(i+1)*5}s)[/green]")
                                api_online = True
                                break
                            console.print(f"[dim]Waiting... ({(i+1)*5}s)[/dim]")

                        if not api_online:
                            console.print(
                                "[yellow]⚠️  API server didn't restart, "
                                "keeping insecure-skip-tls-verify[/yellow]"
                            )
                            subprocess.run(
                                [
                                    "kubectl",
                                    "config",
                                    "set-cluster",
                                    "kubernetes",
                                    "--insecure-skip-tls-verify=true",
                                ],
                                check=False,
                            )
                            return  # Exit the cert regeneration attempt

                        # Remove insecure flag and test
                        subprocess.run(
                            [
                                "kubectl",
                                "config",
                                "unset",
                                "clusters.kubernetes.insecure-skip-tls-verify",
                            ],
                            check=False,
                        )

                        # Test with proper certificate validation
                        result = subprocess.run(  # type: ignore
                            ["kubectl", "get", "nodes"], capture_output=True, check=False
                        )
                        if result.returncode == 0:
                            console.print("[green]✓ Certificate validation successful![/green]")
                        else:
                            console.print("[yellow]⚠️  Keeping insecure-skip-tls-verify[/yellow]")
                            subprocess.run(
                                [
                                    "kubectl",
                                    "config",
                                    "set-cluster",
                                    "kubernetes",
                                    "--insecure-skip-tls-verify=true",
                                ],
                                check=False,
                            )
                    except Exception as cert_error:
                        console.print(
                            f"[yellow]⚠️  Could not regenerate certificate: {cert_error}[/yellow]"
                        )
                        console.print("[yellow]Continuing with insecure-skip-tls-verify[/yellow]")
                else:
                    console.print("[red]❌ Could not determine server IP[/red]")
            else:
                console.print(
                    f"[green]✓ Kubeconfig server already correct: {current_server}[/green]"
                )

        except Exception as e:
            console.print(f"[yellow]⚠️  Could not fix kubeconfig: {e}[/yellow]")

    def _setup_kubeconfig(self) -> None:
        """Setup kubeconfig for K3s."""
        default_kubeconfig = Path("/etc/rancher/k3s/k3s.yaml")
        if default_kubeconfig.exists():
            self.kubeconfig_path.parent.mkdir(parents=True, exist_ok=True)
            if str(self.kubeconfig_path) != str(default_kubeconfig):
                import shutil
                shutil.copy(default_kubeconfig, self.kubeconfig_path)
            os.environ["KUBECONFIG"] = str(self.kubeconfig_path)
            console.print(f"[green]✓ Kubeconfig set up at {self.kubeconfig_path}[/green]")
        else:
            console.print("[yellow]⚠️  K3s kubeconfig not found at /etc/rancher/k3s/k3s.yaml[/yellow]")

    def create_namespace(self, namespace: str) -> bool:
        result = run_command(
            ["kubectl", "get", "namespace", namespace], capture_output=True, check=False
        )
        if result and namespace in result:
            return True
        return run_command(["kubectl", "create", "namespace", namespace]) is not None

    def setup_storage(self) -> bool:
        console.print("\n[bold cyan]Setting up storage...[/bold cyan]")

        if self.cluster_type == "k3s":
            # K3s has local-path storage class by default
            result = run_command(
                ["kubectl", "get", "storageclass", "local-path"], capture_output=True
            )
            if result and "local-path" in result:
                console.print("[green]✓ K3s storage configured (local-path)[/green]")
                return True
            else:
                console.print("[yellow]⚠️  local-path storage class not found[/yellow]")
                return False
        else:
            # Full Kubernetes - check for common storage classes
            storage_classes = ["local-path", "standard", "default"]
            for sc in storage_classes:
                result = run_command(
                    ["kubectl", "get", "storageclass", sc], capture_output=True, check=False
                )
                if result and sc in result:
                    console.print(f"[green]✓ Full Kubernetes storage configured ({sc})[/green]")
                    return True

            # If no known storage classes found, list what's available
            console.print("[yellow]⚠️  No standard storage classes found[/yellow]")
            result = run_command(
                ["kubectl", "get", "storageclass"], capture_output=True, check=False
            )
            if result:
                console.print("[dim]Available storage classes:[/dim]")
                for line in result.split("\n")[1:]:  # Skip header
                    if line.strip():
                        console.print(f"  - {line.split()[0]}")
                console.print(
                    "[green]✓ Storage classes available "
                    "(manual configuration may be needed)[/green]"
                )
                return True
            else:
                console.print("[red]✗ No storage classes available[/red]")
                return False

    def setup_ingress(self) -> bool:
        console.print("\n[bold cyan]Setting up ingress...[/bold cyan]")

        # Clean up existing conflicting resources
        console.print("[yellow]Cleaning up existing nginx-ingress resources...[/yellow]")
        import subprocess

        # Delete conflicting cluster-scoped resources
        cleanup_resources = [
            ("clusterrole", "nginx-ingress-ingress-nginx"),
            ("clusterrolebinding", "nginx-ingress-ingress-nginx"),
            ("ingressclass", "nginx"),
            ("validatingwebhookconfiguration", "nginx-ingress-ingress-nginx-admission"),
            ("mutatingwebhookconfiguration", "nginx-ingress-ingress-nginx-admission"),
        ]

        for resource_type, resource_name in cleanup_resources:
            subprocess.run(
                ["kubectl", "delete", resource_type, resource_name, "--ignore-not-found=true"],
                capture_output=True,
                check=False,
            )

        # Create or clean namespace
        self.create_namespace("ingress-nginx")

        # Uninstall existing release if present (to clean metadata)
        subprocess.run(
            [
                "helm",
                "uninstall",
                "nginx-ingress",
                "--namespace",
                "ingress-nginx",
                "--ignore-not-found",
            ],
            capture_output=True,
            check=False,
        )

        # Add Helm repo
        subprocess.run(
            [
                "helm",
                "repo",
                "add",
                "ingress-nginx",
                "https://kubernetes.github.io/ingress-nginx",
                "--force-update",
            ],
            capture_output=True,
            check=False,
        )
        subprocess.run(["helm", "repo", "update"], capture_output=True, check=False)

        # Install nginx-ingress
        cmd = (
            "helm install nginx-ingress ingress-nginx/ingress-nginx "
            "--namespace ingress-nginx "
            "--set controller.service.type=NodePort --wait"
        )
        result = subprocess.run(cmd, shell=True)
        if result.returncode == 0:
            console.print("[green]✓ Ingress installed[/green]")
            return True
        else:
            console.print("[red]✗ Ingress installation failed[/red]")
            return False

    def uninstall(self) -> bool:
        console.print("\n[bold red]Uninstalling K3s...[/bold red]")
        system = platform.system()
        if system == "Linux":
            uninstall_script = Path("/usr/local/bin/k3s-uninstall.sh")
            if uninstall_script.exists():
                return run_command([str(uninstall_script)]) is not None
        return False

    def doctor(self) -> List[Tuple[str, bool, str]]:
        checks = []
        is_installed = self.is_installed()
        checks.append(
            ("K3s Installation", is_installed, "Installed" if is_installed else "Not installed")
        )

        if is_installed:
            result = run_command(["kubectl", "cluster-info"], capture_output=True, check=False)
            cluster_up = result is not None and "Kubernetes control plane" in result
            checks.append(
                ("Cluster Status", cluster_up, "Running" if cluster_up else "Not responding")
            )

        return checks

    def check_environment_readiness(self) -> Tuple[bool, List[str]]:
        """Check if environment is ready for K3s installation."""
        issues = []

        console.print("[cyan]🔍 Checking environment readiness for K3s installation...[/cyan]")

        # Check 1: Existing Kubernetes cluster
        if self.is_installed():
            issues.append("Kubernetes cluster already exists and is running")
            console.print("[yellow]⚠️  Existing Kubernetes cluster detected[/yellow]")

        # Check 2: Conflicting processes
        conflicting_processes = ["k3s", "kubelet", "kube-apiserver", "etcd"]
        running_conflicts = []
        for proc in conflicting_processes:
            result = subprocess.run(["pgrep", "-f", proc], capture_output=True, check=False)
            if result.returncode == 0:
                running_conflicts.append(proc)

        if running_conflicts:
            issues.append(f"Conflicting processes running: {', '.join(running_conflicts)}")
            console.print(f"[yellow]⚠️  Conflicting processes: {', '.join(running_conflicts)}[/yellow]")

        # Check 3: Existing kubeconfig
        kubeconfig_path = Path.home() / ".kube" / "config"
        if kubeconfig_path.exists():
            console.print("[yellow]⚠️  Existing kubeconfig found[/yellow]")
            # Check if it's valid
            result = run_command(["kubectl", "config", "current-context"], capture_output=True, check=False)
            if result:
                issues.append("Existing kubeconfig with active context")
            else:
                console.print("[dim]Existing kubeconfig appears invalid[/dim]")

        # Check 4: Required ports
        required_ports = [6443, 2379, 2380]  # API server, etcd
        occupied_ports = []
        for port in required_ports:
            result = subprocess.run(["ss", "-tln", f"sport = :{port}"], capture_output=True, text=True, check=False)
            if result.returncode == 0 and result.stdout and len(result.stdout.strip().split('\n')) > 1:
                # Check if there's actual data beyond the header
                lines = result.stdout.strip().split('\n')
                if len(lines) > 1:  # More than just header
                    occupied_ports.append(str(port))

        if occupied_ports:
            issues.append(f"Required ports already in use: {', '.join(occupied_ports)}")
            console.print(f"[yellow]⚠️  Ports in use: {', '.join(occupied_ports)}[/yellow]")

        # Check 5: System requirements
        # Memory check (require at least 2GB for K3s)
        try:
            with open("/proc/meminfo", "r") as f:
                for line in f:
                    if line.startswith("MemTotal:"):
                        mem_kb = int(line.split()[1])
                        mem_gb = mem_kb / 1024 / 1024
                        min_mem = 2
                        if mem_gb < min_mem:
                            issues.append(f"Insufficient memory: {mem_gb:.1f}GB available, {min_mem}GB required")
                            console.print(f"[yellow]⚠️  Insufficient memory: {mem_gb:.1f}GB available, {min_mem}GB required[/yellow]")
        except:
            console.print("[dim]Could not check memory[/dim]")

        # Disk space check (require at least 10GB free)
        try:
            result = subprocess.run(["df", "/"], capture_output=True, text=True, check=False)
            if result.returncode == 0:
                lines = result.stdout.split("\n")
                if len(lines) > 1:
                    parts = lines[1].split()
                    if len(parts) > 3:
                        available_kb = int(parts[3])
                        available_gb = available_kb / 1024 / 1024
                        if available_gb < 10:
                            issues.append(f"Insufficient disk space: {available_gb:.1f}GB available, 10GB required")
                            console.print(f"[yellow]⚠️  Insufficient disk space: {available_gb:.1f}GB available, 10GB required[/yellow]")
        except:
            console.print("[dim]Could not check disk space[/dim]")

        if issues:
            console.print(f"[red]❌ Found {len(issues)} environment issues[/red]")
            return False, issues
        else:
            console.print("[green]✅ Environment is ready for K3s installation[/green]")
            return True, []

    def clean_environment(self, force: bool = False) -> bool:
        """Clean up conflicting resources to prepare for fresh K3s installation."""
        console.print("[cyan]🧹 Cleaning environment for K3s installation...[/cyan]")

        cleaned = []

        # First, kill processes using required ports
        required_ports = [6443, 2379, 2380]  # API server, etcd client, etcd peer
        for port in required_ports:
            port_cleaned = self._kill_processes_using_port(port)
            if port_cleaned:
                cleaned.append(f"Killed processes using port {port}")
                console.print(f"[green]✓ Killed processes using port {port}[/green]")

        # Stop conflicting processes
        conflicting_processes = ["k3s", "kubelet", "kube-apiserver", "etcd"]
        for proc in conflicting_processes:
            result = subprocess.run(["pkill", "-f", proc], capture_output=True, check=False)
            if result.returncode == 0:
                cleaned.append(f"Stopped {proc} processes")
                console.print(f"[green]✓ Stopped {proc} processes[/green]")

        # Remove existing K3s installation
        if shutil.which("k3s"):
            console.print("[yellow]Removing existing K3s installation...[/yellow]")
            uninstall_script = Path("/usr/local/bin/k3s-uninstall.sh")
            if uninstall_script.exists():
                result = subprocess.run([str(uninstall_script)], capture_output=True, check=False)
                if result.returncode == 0:
                    cleaned.append("Uninstalled K3s")
                    console.print("[green]✓ K3s uninstalled[/green]")
                else:
                    console.print("[yellow]⚠️  K3s uninstall failed[/yellow]")

        # Clean up Kubernetes directories
        cleanup_dirs = [
            "/etc/rancher/k3s",
            "/var/lib/rancher/k3s",
            "/etc/kubernetes",
            "/var/lib/kubelet",
            "/var/lib/etcd"
        ]
        for dir_path in cleanup_dirs:
            if Path(dir_path).exists():
                try:
                    result = subprocess.run(["sudo", "rm", "-rf", dir_path], capture_output=True, check=False)
                    if result.returncode == 0:
                        cleaned.append(f"Removed {dir_path}")
                        console.print(f"[green]✓ Removed {dir_path}[/green]")
                except:
                    console.print(f"[yellow]⚠️  Could not remove {dir_path}[/yellow]")

        # Clean up kubeconfig
        kubeconfig_path = Path.home() / ".kube" / "config"
        if kubeconfig_path.exists():
            try:
                kubeconfig_path.unlink()
                cleaned.append("Removed existing kubeconfig")
                console.print("[green]✓ Removed existing kubeconfig[/green]")
            except:
                console.print("[yellow]⚠️  Could not remove kubeconfig[/yellow]")

        # Clean up systemd services
        services_to_stop = ["k3s", "kubelet", "docker", "containerd"]
        for service in services_to_stop:
            result = subprocess.run(["sudo", "systemctl", "stop", service], capture_output=True, check=False)
            result2 = subprocess.run(["sudo", "systemctl", "disable", service], capture_output=True, check=False)
            if result.returncode == 0 or result2.returncode == 0:
                cleaned.append(f"Stopped/disabled {service} service")
                console.print(f"[green]✓ Cleaned {service} service[/green]")

        # Clean up network interfaces (careful!)
        # Only clean up flannel/calico interfaces if they exist
        network_cleanups = []
        result = subprocess.run(["ip", "link", "show"], capture_output=True, text=True, check=False)
        if result.returncode == 0:
            for line in result.stdout.split("\n"):
                if "flannel" in line or "calico" in line or "cni" in line:
                    iface = line.split(":")[1].strip().split("@")[0]
                    try:
                        subprocess.run(["sudo", "ip", "link", "delete", iface], capture_output=True, check=False)
                        network_cleanups.append(f"Removed {iface}")
                        console.print(f"[green]✓ Removed network interface {iface}[/green]")
                    except:
                        pass

        if network_cleanups:
            cleaned.extend(network_cleanups)

        # Clean up iptables rules
        try:
            result = subprocess.run(["sudo", "iptables", "-F"], capture_output=True, check=False)
            if result.returncode == 0:
                cleaned.append("Flushed iptables rules")
                console.print("[green]✓ Flushed iptables rules[/green]")
        except:
            console.print("[yellow]⚠️  Could not flush iptables[/yellow]")

        if cleaned:
            console.print(f"[green]✅ Environment cleaned: {len(cleaned)} items removed[/green]")
            return True
        else:
            console.print("[yellow]⚠️  No cleanup actions performed[/yellow]")
            return True

    def _kill_processes_using_port(self, port: int) -> bool:
        """Kill processes using a specific port."""
        try:
            # Use lsof to find processes using the port
            result = subprocess.run(["lsof", "-ti", f":{port}"], capture_output=True, text=True, check=False)
            if result.returncode == 0 and result.stdout.strip():
                pids = result.stdout.strip().split("\n")
                for pid in pids:
                    if pid.strip():
                        try:
                            # Kill the process
                            subprocess.run(["sudo", "kill", "-9", pid.strip()], capture_output=True, check=False)
                            console.print(f"[yellow]Killed process {pid.strip()} using port {port}[/yellow]")
                        except:
                            pass
                return len(pids) > 0
        except:
            # lsof might not be available, try alternative method
            try:
                # Use ss and ps to find processes
                ss_result = subprocess.run(["ss", "-tlnp", f"sport = :{port}"], capture_output=True, text=True, check=False)
                if ss_result.returncode == 0 and "pid=" in ss_result.stdout:
                    # Extract PID from ss output
                    for line in ss_result.stdout.split("\n"):
                        if f":{port}" in line and "pid=" in line:
                            pid_part = line.split("pid=")[1].split(",")[0]
                            try:
                                subprocess.run(["sudo", "kill", "-9", pid_part], capture_output=True, check=False)
                                console.print(f"[yellow]Killed process {pid_part} using port {port}[/yellow]")
                                return True
                            except:
                                pass
            except:
                pass
        return False

    def setup_kubeconfig_path(self) -> bool:
        """Ensure kubeconfig path is properly set up."""
        console.print("[cyan]🔧 Setting up kubeconfig path...[/cyan]")

        # Ensure kubeconfig directory exists
        self.kubeconfig_path.parent.mkdir(parents=True, exist_ok=True)

        # Set KUBECONFIG environment variable
        os.environ["KUBECONFIG"] = str(self.kubeconfig_path)
        console.print(f"[green]✓ KUBECONFIG environment variable set to {self.kubeconfig_path}[/green]")

        # Check if kubeconfig already exists and is valid
        if self.kubeconfig_path.exists():
            result = run_command(["kubectl", "config", "current-context"], capture_output=True, check=False)
            if result:
                console.print(f"[green]✓ Existing kubeconfig is valid (context: {result.strip()})[/green]")
                return True
            else:
                console.print("[yellow]⚠️  Existing kubeconfig appears invalid[/yellow]")

        console.print(f"[green]✓ Kubeconfig path ready at {self.kubeconfig_path}[/green]")
        return True
