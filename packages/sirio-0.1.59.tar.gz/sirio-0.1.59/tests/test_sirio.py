#!/usr/bin/env python

"""Tests for `sirio` package."""


import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
import unittest
import io



from sirio.business_object import BusinessObject, Object

from sirio.service import SirioService

from sirio.sirio_ai import ConfigAi, SirioAi, SirioPayloadAi
from sirio.sirio_batch_ai import SirioAiBatch, RequestAiBatch, Message

pask = Object(key='pask', name='pask', id='1234', extension='.txt' )

pask.setExtendedValue(key='ext3', value='extvalore3')
pask.setExtendedValue(key='ext2', value='extvalore2')
pask.setExtendedValue(key='ext3', value='newEextvalore3')

gptBatch = SirioAiBatch(hostOpenAiBatchRequest='https://openai-batch-request.srv-test.eu-central-1.aws.cervedgroup.com')


req = RequestAiBatch()
req.application = 'test-sirio'
req.sirioDomain = 'test-domain'
msg1 = Message()
msg1.role = 'user'
msg1.content = 'Ciao, come stai?'
req.messages = [msg1]
req.key = '339d9b2cf2e8442d93cc27a138b3f068'
req.idSync = 'sync-12345'

risposta = gptBatch.getResponseBatchAi('691f99c881a532570d386f71')
print(risposta)

idbatch = gptBatch.requestAi(requestAi=req)

config = ConfigAi(url_ai = '', 
                  ai_model = 'Gpt4o-1', 
                  ai_temperature = 0.2,
                  ai_max_tokens = 4000,
                  ai_top_p = 0.95,
                  ai_frequency_penalty = 0,
                  ai_presence_penalty = 0,
                  ai_stop = None,
                  ai_model_rr1 = 'Gpt4o-1',
                  ai_model_rr2 = 'Gpt4o-2',
                  ai_model_rr3 = 'Gpt4o-3',
                  api_key = '',
                  api_version = '2024-02-15-preview')

payload = SirioPayloadAi()
gpt = SirioAi(config)
domanda = "Come sta il pontefice"
esempio = ''
assistente = 'Cerca di essere rassicurante, e di trasmettere speranza.'
bollettino = {'bollettino_medico':'Bollettino medico di sabato 8 marzo 2025: Il pontefice rimane in prognosi riservata. Le sue condizioni sono stabili, ma gravi'}
payload.setContesto(key='bollettino_medico', value=bollettino)
risposta = gpt.invocaGPT(1,domanda=domanda,assistente=assistente, esempio=esempio, dati=payload.getContesto() )
print(gpt.maxTokens)
payload.setProposta(bind='proposte',id='prima', value=risposta)


print(payload.getPayload())



class TestSirio(unittest.TestCase):
    """Tests for `sirio` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""

