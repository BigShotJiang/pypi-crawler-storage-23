# OpenClaw Sandbox

一键启动安装有 [OpenClaw](https://docs.openclaw.ai/) 的云端沙箱环境，基于 [PPIO Agent Sandbox](https://ppio.com/docs/sandbox/overview.md)。

## 安装

```bash
pip install -e .
```

## 配置

### 1. 获取 PPIO API Key

前往 [PPIO Key Management](https://ppio.com/docs/support/api-key) 获取你的 API Key。该 Key 同时用于：
- 创建和管理 PPIO 沙箱实例
- 作为 OpenClaw 的 LLM 推理 API Key

### 2. 设置环境变量

复制 `.env.example` 并填入你的 API Key：

```bash
cp .env.example .env
```

编辑 `.env` 文件：

```
PPIO_API_KEY=sk_your_api_key_here
```

也可以通过 `--api-key` 参数直接传入。

## 使用

### 启动沙箱

```bash
ppclaw-cli launch
```

启动时会自动生成一个随机的 Gateway 密码。**强烈建议**通过 `--gateway-password` 指定一个自定义密码以确保访问安全：

```bash
ppclaw-cli launch --gateway-password <your-password>
```

启动成功后会输出：
- **Sandbox ID** — 用于后续管理
- **Web UI 地址** — 在浏览器中打开即可使用 OpenClaw
- **Gateway WebSocket 地址** — 用于 TUI 或 API 连接
- **Gateway Password** — 连接时需要的认证密码

完整参数：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `--api-key` | PPIO API Key | 读取 `PPIO_API_KEY` 环境变量 |
| `--gateway-password` | Gateway 认证密码 | 自动生成随机密码 |
| `--timeout` | 沙箱创建超时（秒） | 60 |
| `--keep-alive` | 沙箱存活时间（秒） | 3600 |

### 查看沙箱列表

```bash
ppclaw-cli list
```

### 查看沙箱状态

```bash
ppclaw-cli status <sandbox-id>
```

### 通过 TUI 连接

```bash
ppclaw-cli tui <sandbox-id> --password <gateway-password>
```

需要本地安装 OpenClaw CLI：`npm install -g openclaw`

### 停止沙箱

```bash
ppclaw-cli stop <sandbox-id>
```

## 安全说明

Gateway Password 用于保护你的 OpenClaw 实例不被未授权访问。当沙箱绑定到公网地址时：

- **始终设置密码** — 不设置密码将允许任何人通过公网 URL 使用你的 OpenClaw 实例
- **妥善保管密码** — 密码仅在 `launch` 时输出一次，请及时记录
- **及时停止不用的沙箱** — 避免不必要的资源消耗和安全风险

## 相关文档

- [OpenClaw 安装使用文档](https://docs.openclaw.ai/install)
- [PPIO Agent Sandbox 文档](https://ppio.com/docs/sandbox/overview.md)
- [PPIO API Key 获取](https://ppio.com/docs/support/api-key)
