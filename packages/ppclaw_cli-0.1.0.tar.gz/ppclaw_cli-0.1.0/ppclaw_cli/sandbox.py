"""PPIO Sandbox operations wrapper."""

from typing import Optional

from ppio_sandbox.code_interpreter import Sandbox
from ppio_sandbox.core.sandbox.sandbox_api import SandboxQuery

from .utils import print_error, print_info, print_success, print_warning

SANDBOX_METADATA = {"app": "ppclaw"}


class SandboxManager:
    """Manages PPIO sandbox instances for OpenClaw."""

    def __init__(self, template_id: str = None):
        self.template_id = template_id
        self._sandbox: Optional[Sandbox] = None

    def create(self, template_id: str = None, timeout: int = 60) -> Optional[Sandbox]:
        """Create a new sandbox instance with ppclaw metadata."""
        tid = template_id or self.template_id
        if not tid:
            print_error("No template ID provided. Build a template first.")
            return None

        print_info(f"Creating sandbox from template: {tid}")
        try:
            self._sandbox = Sandbox.create(tid, timeout=timeout, metadata=SANDBOX_METADATA)
        except Exception as e:
            print_error(f"Failed to create sandbox: {e}")
            return None

        print_success(f"Sandbox created: {self._sandbox.sandbox_id}")
        return self._sandbox

    def connect(self, sandbox_id: str) -> Optional[Sandbox]:
        """Connect to an existing sandbox."""
        try:
            self._sandbox = Sandbox.connect(sandbox_id)
            return self._sandbox
        except Exception as e:
            print_error(f"Failed to connect to sandbox {sandbox_id}: {e}")
            return None

    def run_command(self, command: str, timeout: int = 30, background: bool = False, envs: dict = None) -> Optional[str]:
        """Execute a command in the sandbox."""
        if not self._sandbox:
            print_error("No active sandbox. Create or connect first.")
            return None
        try:
            result = self._sandbox.commands.run(
                command, timeout=timeout, background=background, envs=envs,
            )
            return result
        except Exception as e:
            print_error(f"Command failed: {e}")
            return None

    def write_file(self, path: str, content: str):
        """Write a file to the sandbox filesystem."""
        if not self._sandbox:
            print_error("No active sandbox.")
            return
        self._sandbox.files.write(path, content)

    def read_file(self, path: str) -> Optional[str]:
        """Read a file from the sandbox filesystem."""
        if not self._sandbox:
            print_error("No active sandbox.")
            return None
        return self._sandbox.files.read(path)

    def upload_file(self, local_path: str, sandbox_path: str):
        """Upload a local file to the sandbox."""
        if not self._sandbox:
            print_error("No active sandbox.")
            return
        with open(local_path, "rb") as f:
            self._sandbox.files.write(sandbox_path, f)
        print_success(f"Uploaded {local_path} -> {sandbox_path}")

    def get_status(self) -> Optional[str]:
        """Check if the sandbox is alive by running a simple command."""
        if not self._sandbox:
            return None
        try:
            result = self._sandbox.commands.run("echo ok", timeout=5)
            return "running" if result else "unknown"
        except Exception:
            return "unreachable"

    def kill(self):
        """Terminate the current sandbox."""
        if not self._sandbox:
            print_error("No active sandbox.")
            return
        sandbox_id = self._sandbox.sandbox_id
        try:
            self._sandbox.kill()
        except Exception as e:
            print_warning(f"Error during sandbox termination: {e}")
        print_success(f"Sandbox terminated: {sandbox_id}")
        self._sandbox = None

    @property
    def sandbox(self) -> Optional[Sandbox]:
        return self._sandbox

    @property
    def sandbox_id(self) -> Optional[str]:
        return self._sandbox.sandbox_id if self._sandbox else None

    @staticmethod
    def list_ppclaw_sandboxes() -> list:
        """List all ppclaw sandboxes via PPIO API, filtered by metadata."""
        query = SandboxQuery(metadata=SANDBOX_METADATA)
        paginator = Sandbox.list(query=query)
        sandboxes = []
        while paginator.has_next:
            sandboxes.extend(paginator.next_items())
        return sandboxes
