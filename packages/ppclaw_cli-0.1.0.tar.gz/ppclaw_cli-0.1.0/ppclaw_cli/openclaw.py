"""OpenClaw configuration and service management."""

import json
import os
import time

from .sandbox import SandboxManager
from .utils import print_error, print_info, print_success

GATEWAY_PORT = 18789
OPENCLAW_CONFIG_PATH = "/home/user/.openclaw/config.json"


def load_openclaw_config_template() -> dict:
    """Load openclaw.example.json as config template."""
    example_path = os.path.join(os.path.dirname(__file__), "openclaw.example.json")
    with open(example_path) as f:
        return json.load(f)


def generate_openclaw_config(api_key: str, gateway_password: str) -> dict:
    """Generate OpenClaw configuration by injecting API key and gateway password."""
    config = load_openclaw_config_template()

    # Replace placeholder API key in all providers
    for provider in config.get("models", {}).get("providers", {}).values():
        if provider.get("apiKey") == "PPIO_API_KEY":
            provider["apiKey"] = api_key

    # Set gateway config
    config.setdefault("gateway", {})
    config["gateway"]["mode"] = "local"
    config["gateway"]["auth"] = {"password": gateway_password}
    # Allow host-header origin fallback for non-loopback binding
    config["gateway"]["controlUi"] = {
        "dangerouslyAllowHostHeaderOriginFallback": True,
    }

    return config


def configure_openclaw(manager: SandboxManager, api_key: str, gateway_password: str):
    """Write OpenClaw configuration to the sandbox."""
    config = generate_openclaw_config(api_key, gateway_password)
    config_content = json.dumps(config, indent=2)

    # Ensure config directory exists
    manager.run_command("mkdir -p /home/user/.openclaw", timeout=10)

    print_info("Writing OpenClaw configuration to sandbox...")
    manager.write_file(OPENCLAW_CONFIG_PATH, config_content)
    print_success("OpenClaw configuration written")

    # Start gateway in background via nohup so process persists
    print_info("Starting OpenClaw Gateway...")
    manager.run_command(
        "nohup bash -c 'OPENCLAW_CONFIG_PATH={config} openclaw gateway --port {port} --bind lan'"
        " > /tmp/gateway.log 2>&1 &".format(config=OPENCLAW_CONFIG_PATH, port=GATEWAY_PORT),
        timeout=10,
    )

    # Wait for gateway to be ready (may take up to ~60s for Node.js initialization)
    for i in range(20):
        time.sleep(3)
        result = manager.run_command(
            'curl -s --max-time 2 -o /dev/null -w "%{{http_code}}" http://localhost:{port}/ 2>/dev/null; echo'.format(
                port=GATEWAY_PORT
            ),
            timeout=10,
        )
        if result and result.stdout and result.stdout.strip() == "200":
            print_success("OpenClaw Gateway is listening on port {port}".format(port=GATEWAY_PORT))
            return
        print_info("  Waiting for Gateway to start ({i}/20)...".format(i=i + 1))

    # Print gateway log on failure for debugging
    log_result = manager.run_command("tail -30 /tmp/gateway.log 2>&1 || true", timeout=5)
    if log_result and log_result.stdout and log_result.stdout.strip():
        print_error("Gateway log:\n{log}".format(log=log_result.stdout.strip()))
    print_error("Gateway did not start in time. Check sandbox logs.")


def get_public_urls(manager: SandboxManager) -> dict:
    """Get public access URLs for Gateway and Web UI."""
    host = manager.sandbox.get_host(GATEWAY_PORT)
    return {
        "gateway_ws": "ws://{host}".format(host=host),
        "webui": "http://{host}".format(host=host),
    }
