"""Configuration management for OpenClaw Sandbox CLI."""

import json
import os
from pathlib import Path

import yaml

CONFIG_DIR = Path.home() / ".ppclaw-cli"
CONFIG_FILE = CONFIG_DIR / "config.yaml"
SANDBOXES_FILE = CONFIG_DIR / "sandboxes.json"

DEFAULT_CONFIG = {
    "ppio": {
        "api_key": "",
        "template_id": "",
    },
}


def ensure_config_dir():
    """Ensure the configuration directory exists."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load configuration from YAML file, merging with defaults."""
    ensure_config_dir()
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE) as f:
            user_config = yaml.safe_load(f) or {}
        config = _deep_merge(DEFAULT_CONFIG, user_config)
    else:
        config = DEFAULT_CONFIG.copy()
    # Override with environment variables
    _apply_env_overrides(config)
    return config


def save_config(config: dict):
    """Save configuration to YAML file."""
    ensure_config_dir()
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(config, f, default_flow_style=False, allow_unicode=True)


def load_sandboxes() -> dict:
    """Load sandbox records from JSON file."""
    ensure_config_dir()
    if SANDBOXES_FILE.exists():
        with open(SANDBOXES_FILE) as f:
            return json.load(f)
    return {"sandboxes": []}


def save_sandboxes(data: dict):
    """Save sandbox records to JSON file."""
    ensure_config_dir()
    with open(SANDBOXES_FILE, "w") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep merge two dictionaries."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _apply_env_overrides(config: dict):
    """Apply environment variable overrides to config."""
    env_map = {
        "PPIO_API_KEY": ("ppio", "api_key"),
    }
    for env_var, path in env_map.items():
        value = os.environ.get(env_var)
        if value:
            section, key = path
            config[section][key] = value
