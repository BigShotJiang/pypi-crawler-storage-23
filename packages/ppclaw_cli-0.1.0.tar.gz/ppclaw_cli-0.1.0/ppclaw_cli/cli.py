"""CLI entry point for OpenClaw Sandbox."""

import os
import secrets
import subprocess
import sys

import click
from dotenv import load_dotenv
from rich.panel import Panel
from rich.table import Table

from .config import load_config
from .openclaw import configure_openclaw, get_public_urls
from .sandbox import SandboxManager
from .utils import console, print_error, print_info, print_success

load_dotenv()

# Template Name：PPClaw
# Defined in directory ./template/
TEMPLATE_ID = "iplg49g7krvfhwhffxx8"


@click.group()
@click.version_option()
def cli():
    """OpenClaw Sandbox - One-click launch of OpenClaw on PPIO Agent Sandbox."""
    pass


# --- Sandbox lifecycle commands ---


@cli.command()
@click.option("--api-key", default=None, help="PPIO API key (also used for OpenClaw LLM)")
@click.option("--gateway-password", default=None, help="Gateway auth password (auto-generated if not set)")
@click.option("--timeout", default=60, help="Sandbox creation timeout in seconds")
@click.option("--keep-alive", default=3600, help="Sandbox keep-alive duration in seconds (default: 1 hour)")
def launch(api_key, gateway_password, timeout, keep_alive):
    """Launch a new OpenClaw sandbox environment."""
    config = load_config()

    key = api_key or config["ppio"].get("api_key")
    if not key:
        print_error("PPIO API key is required. Set PPIO_API_KEY or pass --api-key.")
        raise SystemExit(1)

    gw_password = gateway_password or os.environ.get("OPENCLAW_GATEWAY_PASSWORD") or secrets.token_urlsafe(16)

    # Step 1: Create sandbox (services already running from template snapshot)
    with console.status("[bold blue]Creating sandbox..."):
        manager = SandboxManager(TEMPLATE_ID)
        sandbox = manager.create(timeout=timeout)
        if not sandbox:
            raise SystemExit(1)

    # Step 2: Extend sandbox lifetime
    with console.status("[bold blue]Setting sandbox keep-alive..."):
        sandbox.set_timeout(keep_alive)

    # Step 3: Configure OpenClaw (models + agents + gateway auth)
    with console.status("[bold blue]Configuring OpenClaw..."):
        configure_openclaw(manager, key, gw_password)

    # Step 4: Get public URLs
    with console.status("[bold blue]Fetching public URLs..."):
        urls = get_public_urls(manager)

    # Display summary
    _print_sandbox_info(sandbox.sandbox_id, gw_password, urls, keep_alive)


@cli.command()
@click.argument("sandbox_id")
def stop(sandbox_id):
    """Stop and terminate a sandbox."""
    manager = SandboxManager()
    if not manager.connect(sandbox_id):
        raise SystemExit(1)

    with console.status("[bold red]Stopping sandbox..."):
        manager.kill()


@cli.command("list")
def list_sandboxes():
    """List all active OpenClaw sandboxes."""
    with console.status("[bold blue]Fetching sandboxes..."):
        sandboxes = SandboxManager.list_ppclaw_sandboxes()

    if not sandboxes:
        print_info("No OpenClaw sandboxes found.")
        return

    table = Table(title="OpenClaw Sandboxes")
    table.add_column("Sandbox ID", style="cyan")
    table.add_column("State", style="bold")
    table.add_column("CPU", justify="right")
    table.add_column("Memory (MB)", justify="right")
    table.add_column("Started At", style="yellow")

    for sbx in sandboxes:
        table.add_row(
            sbx.sandbox_id,
            str(sbx.state.value) if hasattr(sbx.state, "value") else str(sbx.state),
            str(sbx.cpu_count),
            str(sbx.memory_mb),
            sbx.started_at.strftime("%Y-%m-%d %H:%M:%S"),
        )

    console.print(table)


@cli.command()
@click.argument("sandbox_id")
def status(sandbox_id):
    """Check sandbox status and show access URLs."""
    manager = SandboxManager()
    if not manager.connect(sandbox_id):
        raise SystemExit(1)

    sandbox_status = manager.get_status()
    urls = get_public_urls(manager)

    summary = (
        "[cyan]Sandbox ID:[/cyan]  {sandbox_id}\n"
        "[cyan]Status:[/cyan]      {status}\n"
        "[cyan]Web UI:[/cyan]      {webui}\n"
        "[cyan]Gateway WS:[/cyan]  {gateway_ws}"
    ).format(
        sandbox_id=sandbox_id,
        status=sandbox_status,
        webui=urls["webui"],
        gateway_ws=urls["gateway_ws"],
    )
    console.print(Panel(summary, title="Status", border_style="blue"))
    print_info("Use 'ppclaw-cli tui <sandbox_id> --password <gateway-password>' to connect via TUI")


# --- TUI command ---


@cli.command()
@click.argument("sandbox_id")
@click.option("--password", required=True, help="Gateway auth password")
def tui(sandbox_id, password):
    """Connect to an OpenClaw sandbox via TUI."""
    manager = SandboxManager()
    if not manager.connect(sandbox_id):
        raise SystemExit(1)

    urls = get_public_urls(manager)
    ws_url = urls["gateway_ws"]

    cmd = ["openclaw", "tui", "--url", ws_url, "--password", password]
    print_info("Connecting to OpenClaw TUI...")
    print_info("  {cmd}".format(cmd=" ".join(cmd)))

    try:
        subprocess.run(cmd, check=True)
    except FileNotFoundError:
        print_error("'openclaw' CLI not found. Install it with: npm install -g openclaw")
        raise SystemExit(1)
    except subprocess.CalledProcessError as e:
        print_error("TUI exited with code {code}".format(code=e.returncode))
        raise SystemExit(e.returncode)


# --- Helpers ---


def _print_sandbox_info(sandbox_id, gateway_password, urls, keep_alive):
    """Print sandbox launch summary."""
    summary = (
        "[cyan]Sandbox ID:[/cyan]         {sandbox_id}\n"
        "[cyan]Keep Alive:[/cyan]         {keep_alive}s\n"
        "\n"
        "[cyan]Web UI:[/cyan]             {webui}\n"
        "[cyan]Gateway WebSocket:[/cyan]  {gateway_ws}\n"
        "[cyan]Gateway Password:[/cyan]   {gateway_password}"
    ).format(
        sandbox_id=sandbox_id,
        keep_alive=keep_alive,
        webui=urls["webui"],
        gateway_ws=urls["gateway_ws"],
        gateway_password=gateway_password,
    )
    console.print(Panel(summary, title="[green]OpenClaw Sandbox Ready[/green]", border_style="green"))

    print_info("")
    print_info("Open Web UI in browser:")
    print_info("  {webui}".format(webui=urls["webui"]))
    print_info("")
    print_info("Connect via TUI:")
    print_info("  ppclaw-cli tui {sandbox_id} --password {pw}".format(
        sandbox_id=sandbox_id, pw=gateway_password,
    ))
    print_info("")
    print_info("Or use openclaw CLI directly:")
    print_info("  openclaw tui --url {ws} --password {pw}".format(
        ws=urls["gateway_ws"], pw=gateway_password,
    ))


if __name__ == "__main__":
    cli()
