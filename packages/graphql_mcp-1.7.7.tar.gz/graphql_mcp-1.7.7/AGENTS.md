# GraphQL-MCP

> Compatibility note: `AGENTS.md` and `CLAUDE.md` are both supported in this repo.
> Keep these files identical. Any change in one must be mirrored in the other.


MCP server framework built on GraphQL — automatically exposes GraphQL operations as MCP tools.
