""":ref:`SecuredDataTransmission (SID 0x84) <knowledge-base-service-secured-data-transmission>` translation."""

__all__ = ["SECURED_DATA_TRANSMISSION", "SECURED_DATA_TRANSMISSION_2020", "SECURED_DATA_TRANSMISSION_2013"]

from uds.message import RequestSID

from ..data_record_definitions import (
    ADMINISTRATIVE_PARAMETER,
    CONDITIONAL_SECURED_DATA_TRANSMISSION_REQUEST,
    CONDITIONAL_SECURED_DATA_TRANSMISSION_RESPONSE,
    SECURITY_DATA_REQUEST_RECORD_2013,
    SECURITY_DATA_RESPONSE_RECORD_2013,
    SIGNATURE_ENCRYPTION_CALCULATION,
    SIGNATURE_LENGTH,
)
from ..service import Service

SECURED_DATA_TRANSMISSION_2020 = Service(request_sid=RequestSID.SecuredDataTransmission,
                                         request_structure=(ADMINISTRATIVE_PARAMETER,
                                                            SIGNATURE_ENCRYPTION_CALCULATION,
                                                            SIGNATURE_LENGTH,
                                                            CONDITIONAL_SECURED_DATA_TRANSMISSION_REQUEST),
                                         response_structure=(ADMINISTRATIVE_PARAMETER,
                                                             SIGNATURE_ENCRYPTION_CALCULATION,
                                                             SIGNATURE_LENGTH,
                                                             CONDITIONAL_SECURED_DATA_TRANSMISSION_RESPONSE))
"""Translator for :ref:`SecuredDataTransmission <knowledge-base-service-secured-data-transmission>` service
compatible with ISO 14229-1:2020."""

SECURED_DATA_TRANSMISSION_2013 = Service(request_sid=RequestSID.SecuredDataTransmission,
                                         request_structure=(SECURITY_DATA_REQUEST_RECORD_2013,),
                                         response_structure=(SECURITY_DATA_RESPONSE_RECORD_2013,))
"""Translator for :ref:`SecuredDataTransmission <knowledge-base-service-secured-data-transmission>` service
compatible with ISO 14229-1:2013."""

SECURED_DATA_TRANSMISSION = SECURED_DATA_TRANSMISSION_2020
"""Default translator for :ref:`SecuredDataTransmission <knowledge-base-service-secured-data-transmission>`
service."""
