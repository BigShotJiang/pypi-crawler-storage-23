"""Conditional Data Records implementation."""

__all__ = ["DEFAULT_DIAGNOSTIC_MESSAGE_CONTINUATION", "AliasMessageStructure",
           "AbstractConditionalDataRecord", "ConditionalMappingDataRecord", "ConditionalFormulaDataRecord"]

from abc import ABC, abstractmethod
from inspect import signature
from operator import getitem
from types import MappingProxyType
from typing import Callable, Mapping, Optional, Sequence, Union

from uds.utilities import InconsistencyError

from .abstract_data_record import AbstractDataRecord
from .raw_data_record import RawDataRecord

AliasMessageStructure = Sequence[Union[AbstractDataRecord, "AbstractConditionalDataRecord"]]
"""Alias of Diagnostic Message Structure used by databases to interpret Diagnostic Messages parameters.
The sequence contains `AbstractDataRecord` instances and may include conditional records.
The total length (min/max) must always be divisible by 8."""

DEFAULT_DIAGNOSTIC_MESSAGE_CONTINUATION: AliasMessageStructure = (
    RawDataRecord(name="Generic Diagnostic Message Continuation",
                  length=8,
                  min_occurrences=0,
                  max_occurrences=None),)
"""Generic Diagnostic Message Continuation that can be used when specific information are not available."""


class AbstractConditionalDataRecord(ABC):
    """
    API definition of conditional Data Records.

    Features:
     - Conditional Data Records are placeholders that would be replaced with other Data Records the value of
       the previous Data Record is revealed.
     - Contains logic of diagnostic message continuation building.
    """

    def __init__(self, default_message_continuation: Optional[AliasMessageStructure]) -> None:
        """
        Initialize the common part for all Conditional Data Records.

        :param default_message_continuation: Value of default message continuation.
            Leave None if you do not wish to use default message continuation.
        """
        self.default_message_continuation = default_message_continuation

    @abstractmethod
    def __getitem__(self, raw_value: int) -> AliasMessageStructure:
        """
        Get Data Record with diagnostic message continuation.

        :param raw_value: Raw value of the proceeding Data Record.

        :raise KeyError: Provided raw value cannot be handled.

        :return: Following Data Records for the revealed value of the proceeding Data Record.
        """

    @property
    def default_message_continuation(self) -> Optional[AliasMessageStructure]:
        """
        Get default diagnostic message continuation.

        The default diagnostic message continuation would be used when specific diagnostic message continuation is not
        defined.

        .. note:: None value of default_message_continuation means the default value behavior is turned off.
        """
        return self.__default_message_continuation

    @default_message_continuation.setter
    def default_message_continuation(self, value: Optional[AliasMessageStructure]) -> None:
        """
        Set default diagnostic message continuation.

        :param value: Value to set.

        :return: Value to be used as default diagnostic message continuation when no specific
        """
        if value is None:
            self.__default_message_continuation = None
        else:
            self.validate_message_continuation(value)
            self.__default_message_continuation = tuple(value)

    @staticmethod
    def validate_message_continuation(value: AliasMessageStructure) -> None:
        """
        Validate whether the provided value is structure of diagnostic message continuation.

        :param value: Value to check

        :raise TypeError: Provided value is not a sequence.
        :raise ValueError: Provided sequence does not contain Data Records.
        :raise InconsistencyError: Contained Data Records cannot be used together.
        """
        if not isinstance(value, Sequence):
            raise TypeError(f"Provided value is not a sequence. Actual type: {type(value)}.")
        names = set()
        min_total_length = 0
        max_total_length = 0
        for i, data_record in enumerate(value):
            if isinstance(data_record, AbstractDataRecord):
                if data_record.name in names:
                    raise InconsistencyError("Data Records within one message have to have unique names. "
                                             f"Multiple {data_record.name!r} found.")
                names.add(data_record.name)
                min_total_length += data_record.length * data_record.min_occurrences
                # handle data_record.max_occurrences == None
                max_total_length += data_record.length * (data_record.max_occurrences or data_record.min_occurrences)
            elif isinstance(data_record, AbstractConditionalDataRecord):
                if i == 0:
                    raise ValueError("Conditional Data Record cannot be the first part of the message structure.")
            else:
                raise ValueError("Provided sequence contains an element which is not a Data Record.")
        if min_total_length % 8 != 0 or max_total_length % 8:
            raise InconsistencyError("Total length of diagnostic message continuation must always be divisible by 8. "
                                     f"Min length: {min_total_length}. Max length: {max_total_length}.")

    def get_message_continuation(self, raw_value: int) -> AliasMessageStructure:
        """
        Get Data Record with diagnostic message continuation.

        :param raw_value: Raw value of the proceeding Data Record.

        :raise ValueError: Diagnostic message continuation could not be assessed for the provided raw value.

        :return: Following Data Records for the revealed value of the proceeding Data Record.
        """
        try:
            return getitem(self, raw_value)
        except (KeyError, ValueError) as error:
            if self.default_message_continuation is None:
                raise ValueError("No handler for the provided raw value.") from error
            return self.default_message_continuation


class ConditionalMappingDataRecord(AbstractConditionalDataRecord):
    """
    Conditional Data Records that uses mapping to select diagnostic message continuation.

    Common Use Cases:
     - DID structure selection after DID value was provided
     - selection of diagnostic service format after sub-function value was provided
    """

    def __init__(self,
                 mapping: Mapping[int, AliasMessageStructure],
                 default_message_continuation: Optional[AliasMessageStructure] = None,
                 value_mask: Optional[int] = None) -> None:
        """
        Define logic for this Conditional Data Record.

        :param mapping: Mapping from raw values of the proceeding Data Record to structures of the diagnostic message
            continuation.
        :param default_message_continuation: Value of default message continuation.
            Leave None if you do not wish to use default message continuation.
        :param value_mask: Value mask to apply on a raw value of the proceeding Data Record.
        """
        self.mapping = mapping
        self.value_mask = value_mask
        super().__init__(default_message_continuation=default_message_continuation)

    def __getitem__(self, raw_value: int) -> AliasMessageStructure:
        """
        Get diagnostic message continuation for given raw value based on mapping only.

        :param raw_value: Raw value of the proceeding Data Record.

        :raise TypeError: Provided value is not int type.
        :raise ValueError: Provided value is less than 0.

        :return: Diagnostic message continuation assessed based on mapping only.
        """
        if not isinstance(raw_value, int):
            raise TypeError(f"Provided value is not int type. Actual type: {type(raw_value)}.")
        if raw_value < 0:
            raise ValueError(f"Provided value is not a raw value as it is less than 0. Actual value: {raw_value}")
        return self.mapping[raw_value if self.value_mask is None else raw_value & self.value_mask]

    @property
    def mapping(self) -> Mapping[int, AliasMessageStructure]:
        """Get the mapping with diagnostic message continuation selection."""
        return self.__mapping

    @mapping.setter
    def mapping(self, mapping: Mapping[int, AliasMessageStructure]) -> None:
        """
        Set the mapping for diagnostic message continuation selection.

        :param mapping: Mapping from raw values of the proceeding Data Record to structures with the diagnostic message
            continuation.

        :raise TypeError: Provided value is not a Mapping type.
        :raise ValueError: Keys in the provided mapping are not raw values only.
        """
        if not isinstance(mapping, Mapping):
            raise TypeError(f"Provided value is not a mapping type. Actual type: {type(mapping)}.")
        keys = set(mapping.keys())
        if not all(isinstance(key, int) and key >= 0 for key in keys):
            raise ValueError(f"At least one key in the provided mapping is not a raw value. Actual value: {keys}")
        for value in mapping.values():
            self.validate_message_continuation(value)
        self.__mapping = MappingProxyType(mapping)

    @property
    def value_mask(self) -> Optional[int]:
        """Get the mask to apply on a raw value of the proceeding Data Record."""
        return self.__value_mask

    @value_mask.setter
    def value_mask(self, value: Optional[int]) -> None:
        """
        Set the mask to apply on a raw value of the proceeding Data Record.

        :param value: Mask value to set.
            Set None to not use masking.
        """
        if value is not None:
            if not isinstance(value, int):
                raise TypeError(f"Provided time parameter value must be None or int type. Actual type: {type(value)}.")
            if value <= 0:
                raise ValueError(f"Mask must be a positive value. Actual value: {value}")
        self.__value_mask = value


class ConditionalFormulaDataRecord(AbstractConditionalDataRecord):
    """
    Conditional Data Records that uses formula to generate diagnostic message continuation.

    Common Use Cases:
     - Extracting length value for following parameters (e.g. from addressAndLengthFormatIdentifier)
    """

    def __init__(self,
                 formula: Callable[[int], AliasMessageStructure],
                 default_message_continuation: Optional[AliasMessageStructure] = None) -> None:
        """
        Define logic for this Conditional Data Record.

        :param formula: Formula to use for assessing the structure of a diagnostic message continuation.
        :param default_message_continuation: Value of default message continuation.
            Leave None if you do not wish to use default message continuation.
        """
        self.formula = formula
        super().__init__(default_message_continuation=default_message_continuation)

    def __getitem__(self, raw_value: int) -> AliasMessageStructure:
        """
        Get diagnostic message continuation for given raw value based on formula only.

        :param raw_value: Raw value of the proceeding Data Record.

        :raise TypeError: Provided value is not int type.
        :raise ValueError: Provided value is less than 0.

        :return: Diagnostic message continuation assessed based on formula only.
        """
        if not isinstance(raw_value, int):
            raise TypeError(f"Provided value is not int type. Actual type: {type(raw_value)}.")
        if raw_value < 0:
            raise ValueError(f"Provided value is not a raw value as it is lower than 0. Actual value: {raw_value}")
        return self.formula(raw_value)

    @property
    def formula(self) -> Callable[[int], AliasMessageStructure]:
        """Get the formula for assessing the structure of diagnostic message continuation."""
        return self.__formula

    @formula.setter
    def formula(self, formula: Callable[[int], AliasMessageStructure]) -> None:
        """
        Set the formula for assessing the structure of diagnostic message continuation.

        :param formula: Formula to use for assessing the structure of a diagnostic message continuation.

        :raise TypeError: Provided value is not callable.
        :raise ValueError: Provided formula's signature or annotation does not match the required format.
        """
        if not callable(formula):
            raise TypeError(f"Provided value is not callable. Actual type: {type(formula)}.")
        formula_signature = signature(formula)
        if len(formula_signature.parameters) != 1:
            raise ValueError("Provided formula does not take exactly one parameter.")
        param_annotation = list(formula_signature.parameters.items())[0][-1].annotation
        if param_annotation != formula_signature.empty and not issubclass(param_annotation, int):
            raise ValueError("Formula's annotation suggests the formula does not take raw value as an argument.")
        self.__formula = formula
