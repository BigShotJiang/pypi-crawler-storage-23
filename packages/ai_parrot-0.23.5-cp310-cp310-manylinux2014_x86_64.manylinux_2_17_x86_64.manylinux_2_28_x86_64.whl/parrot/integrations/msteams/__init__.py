"""MS Teams integration module."""

from .models import MSTeamsAgentConfig

__all__ = ["MSTeamsAgentConfig"]
