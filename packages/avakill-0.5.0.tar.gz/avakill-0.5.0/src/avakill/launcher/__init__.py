"""Process launcher for OS-level sandboxing of child processes."""
