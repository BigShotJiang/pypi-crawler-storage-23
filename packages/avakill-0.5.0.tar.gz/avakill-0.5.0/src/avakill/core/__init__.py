"""Core engine, policy parsing, and data models."""
