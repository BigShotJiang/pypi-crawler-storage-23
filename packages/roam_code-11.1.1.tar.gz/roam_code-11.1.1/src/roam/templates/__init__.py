"""Bundled templates for CI/CD pipelines and other integrations."""
