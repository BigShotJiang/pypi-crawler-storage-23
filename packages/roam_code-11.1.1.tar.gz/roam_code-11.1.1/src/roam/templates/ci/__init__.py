"""CI/CD pipeline templates for roam-code integration."""
