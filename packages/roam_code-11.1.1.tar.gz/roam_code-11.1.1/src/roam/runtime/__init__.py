"""Runtime trace ingestion and hotspot analysis."""

from __future__ import annotations
