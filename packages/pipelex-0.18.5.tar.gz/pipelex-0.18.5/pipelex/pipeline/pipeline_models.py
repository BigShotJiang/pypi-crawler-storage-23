from pipelex.types import StrEnum


class SpecialPipelineId(StrEnum):
    UNTITLED = "untitled"
    DRY_RUN_UNTITLED = "dry_run_untitled"
