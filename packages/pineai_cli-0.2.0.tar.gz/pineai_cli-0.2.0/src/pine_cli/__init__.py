"""Pine CLI — unified command-line interface for Pine AI."""

__version__ = "0.2.0"
