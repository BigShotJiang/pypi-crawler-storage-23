from django_object_detail.config import BadgeConfig, LinkConfig, PropertyConfig, PropertyGroupConfig, x

__version__ = "0.1.9"
__all__ = ["BadgeConfig", "LinkConfig", "PropertyConfig", "PropertyGroupConfig", "x"]
