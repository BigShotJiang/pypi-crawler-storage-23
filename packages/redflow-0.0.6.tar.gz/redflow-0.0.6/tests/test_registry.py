"""Test workflow registry and define_workflow."""

from redflow.registry import (
    WorkflowDefinition,
    WorkflowHandlerContext,
    WorkflowRegistry,
    define_workflow,
    workflow,
)


async def _noop_handler(ctx: WorkflowHandlerContext) -> dict:
    return {"done": True}


def test_register_and_get() -> None:
    reg = WorkflowRegistry()
    defn = define_workflow("test-wf", handler=_noop_handler, registry=reg)
    assert reg.get("test-wf") is defn
    assert reg.get("nonexistent") is None


def test_list() -> None:
    reg = WorkflowRegistry()
    define_workflow("wf-1", handler=_noop_handler, registry=reg)
    define_workflow("wf-2", handler=_noop_handler, registry=reg)
    names = [d.options.name for d in reg.list()]
    assert "wf-1" in names
    assert "wf-2" in names


def test_last_registration_wins() -> None:
    reg = WorkflowRegistry()

    async def handler_a(ctx: WorkflowHandlerContext) -> str:
        return "a"

    async def handler_b(ctx: WorkflowHandlerContext) -> str:
        return "b"

    define_workflow("same-name", handler=handler_a, registry=reg)
    define_workflow("same-name", handler=handler_b, registry=reg)
    assert reg.get("same-name") is not None
    assert reg.get("same-name").handler is handler_b  # type: ignore[union-attr]


def test_clear() -> None:
    reg = WorkflowRegistry()
    define_workflow("wf", handler=_noop_handler, registry=reg)
    reg.clear()
    assert reg.list() == []


def test_decorator_api() -> None:
    reg = WorkflowRegistry()

    @workflow("decorated-wf", queue="fast", registry=reg)
    async def my_handler(ctx: WorkflowHandlerContext) -> dict:
        return {"ok": True}

    assert isinstance(my_handler, WorkflowDefinition)
    assert my_handler.options.name == "decorated-wf"
    assert my_handler.options.queue == "fast"
    assert reg.get("decorated-wf") is my_handler


def test_default_options() -> None:
    reg = WorkflowRegistry()
    defn = define_workflow("defaults", handler=_noop_handler, registry=reg)
    assert defn.options.queue == "default"
    assert defn.options.max_concurrency == 1
    assert defn.options.max_attempts is None
    assert defn.options.cron == []
