"""Test run_inline testing utility."""

import pytest

from redflow.errors import NonRetriableError, RedflowError
from redflow.registry import WorkflowHandlerContext, WorkflowRegistry, define_workflow
from redflow.testing import run_inline


@pytest.fixture
def registry() -> WorkflowRegistry:
    return WorkflowRegistry()


async def test_simple_handler(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> dict:
        return {"count": 42}

    defn = define_workflow("simple", handler=handler, registry=registry)
    result = await run_inline(defn, input={"x": 1})
    assert result.succeeded
    assert result.output == {"count": 42}
    assert result.steps == []


async def test_handler_with_steps(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> dict:
        a = await ctx.step.run("step-a", lambda: _compute_a())
        b = await ctx.step.run("step-b", lambda: _compute_b(a))
        return {"a": a, "b": b}

    async def _compute_a() -> int:
        return 10

    async def _compute_b(val: int) -> int:
        return val * 2

    defn = define_workflow("with-steps", handler=handler, registry=registry)
    result = await run_inline(defn)
    assert result.succeeded
    assert result.output == {"a": 10, "b": 20}
    assert len(result.steps) == 2
    assert result.steps[0].name == "step-a"
    assert result.steps[1].name == "step-b"


async def test_step_override(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> dict:
        val = await ctx.step.run("external-api", lambda: _call_api())
        return {"data": val}

    async def _call_api() -> str:
        raise RuntimeError("should not be called")

    defn = define_workflow("overridden", handler=handler, registry=registry)
    result = await run_inline(defn, step_overrides={"external-api": "mocked"})
    assert result.succeeded
    assert result.output == {"data": "mocked"}


async def test_handler_error(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> None:
        raise NonRetriableError("permanent failure")

    defn = define_workflow("failing", handler=handler, registry=registry)
    result = await run_inline(defn)
    assert not result.succeeded
    assert isinstance(result.error, NonRetriableError)


async def test_duplicate_step_name(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> None:
        await ctx.step.run("same-name", lambda: _noop())
        await ctx.step.run("same-name", lambda: _noop())

    async def _noop() -> None:
        pass

    defn = define_workflow("dup-steps", handler=handler, registry=registry)
    result = await run_inline(defn)
    assert not result.succeeded
    assert isinstance(result.error, RedflowError)
    assert "Duplicate step name" in str(result.error)


async def test_emit_workflow_step(registry: WorkflowRegistry) -> None:
    async def handler(ctx: WorkflowHandlerContext) -> dict:
        child_id = await ctx.step.emit_workflow("emit-child", "child-wf", {"x": 1})
        return {"child": child_id}

    defn = define_workflow("emitter", handler=handler, registry=registry)
    result = await run_inline(defn)
    assert result.succeeded
    assert "child-wf" in result.output["child"]
