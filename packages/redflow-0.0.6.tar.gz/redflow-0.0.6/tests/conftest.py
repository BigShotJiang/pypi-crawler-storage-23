"""Shared fixtures for redflow tests."""

from __future__ import annotations

import asyncio
import os
import shutil
import socket
import subprocess
import uuid
from collections.abc import AsyncGenerator

import pytest
import redis.asyncio as aioredis


def _get_free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
async def redis_url() -> AsyncGenerator[str]:
    """Provide a Redis URL — reuse REDIS_URL env or spawn a local server."""
    env_url = os.environ.get("REDIS_URL")
    if env_url:
        r = aioredis.from_url(env_url)
        try:
            pong = await r.ping()
            assert pong is True
        finally:
            await r.aclose()
        yield env_url
        return

    if not shutil.which("redis-server"):
        pytest.skip("redis-server not found and REDIS_URL not set")

    port = _get_free_port()
    url = f"redis://127.0.0.1:{port}"
    proc = subprocess.Popen(
        ["redis-server", "--port", str(port), "--bind", "127.0.0.1", "--save", "", "--appendonly", "no"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.PIPE,
    )

    r = aioredis.from_url(url)
    for _ in range(100):
        try:
            if await r.ping():
                break
        except Exception:
            pass
        await asyncio.sleep(0.05)
    else:
        proc.kill()
        await r.aclose()
        pytest.fail("redis-server did not start in time")
    await r.aclose()

    yield url

    proc.terminate()
    proc.wait(timeout=5)


@pytest.fixture()
async def redis_client(redis_url: str) -> AsyncGenerator[aioredis.Redis]:
    r = aioredis.from_url(redis_url)
    yield r
    await r.aclose()


@pytest.fixture()
def test_prefix() -> str:
    return f"redflow:test:{uuid.uuid4().hex[:12]}"
