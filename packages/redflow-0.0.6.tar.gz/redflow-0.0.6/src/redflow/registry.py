"""Workflow registry and ``define_workflow`` helpers.

Provides both a functional API (``define_workflow``) and a decorator API
(``@workflow``) for registering workflow handlers.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Generic, TypeVar, overload

from .types import CronTrigger, DefineWorkflowOptions

T_Input = TypeVar("T_Input")
T_Output = TypeVar("T_Output")


# ---------- handler context ----------


@dataclass(slots=True)
class WorkflowHandlerContext(Generic[T_Input]):
    """Context object passed to every workflow handler."""

    input: T_Input
    run: _RunInfo
    step: Any  # StepApi — forward reference to avoid circular import
    signal: asyncio.Event  # set when cancellation is requested


@dataclass(frozen=True, slots=True)
class _RunInfo:
    id: str
    workflow: str
    queue: str
    attempt: int
    max_attempts: int


# ---------- definition ----------


HandlerFn = Callable[..., Any]


@dataclass(slots=True)
class WorkflowDefinition:
    """A registered workflow with its options and handler."""

    options: DefineWorkflowOptions
    handler: HandlerFn


# ---------- registry ----------


class WorkflowRegistry:
    """In-memory store of workflow definitions.

    Thread-safe for reads; writes are expected during startup only.
    Last registration wins (useful for dev/HMR and test isolation).
    """

    def __init__(self) -> None:
        self._workflows: dict[str, WorkflowDefinition] = {}

    def register(self, definition: WorkflowDefinition) -> None:
        self._workflows[definition.options.name] = definition

    def get(self, name: str) -> WorkflowDefinition | None:
        return self._workflows.get(name)

    def list(self) -> list[WorkflowDefinition]:
        return list(self._workflows.values())

    def clear(self) -> None:
        self._workflows.clear()


_default_registry: WorkflowRegistry | None = None


def get_default_registry() -> WorkflowRegistry:
    global _default_registry
    if _default_registry is None:
        _default_registry = WorkflowRegistry()
    return _default_registry


def __unstable_reset_default_registry_for_tests() -> None:
    """Reset the default registry. Internal — for test isolation only."""
    global _default_registry
    if _default_registry is not None:
        _default_registry.clear()


# ---------- define_workflow (functional API) ----------


def define_workflow(
    name: str,
    *,
    handler: HandlerFn,
    queue: str = "default",
    max_concurrency: int = 1,
    max_attempts: int | None = None,
    cron: list[CronTrigger] | None = None,
    on_failure: Any | None = None,
    input_schema: Any | None = None,
    registry: WorkflowRegistry | None = None,
) -> WorkflowDefinition:
    """Register a workflow and return its definition.

    >>> async def my_handler(ctx: WorkflowHandlerContext) -> dict:
    ...     result = await ctx.step.run("do-work", some_fn)
    ...     return {"ok": True}
    >>> wf = define_workflow("my-workflow", handler=my_handler)
    """
    opts = DefineWorkflowOptions(
        name=name,
        queue=queue,
        max_concurrency=max_concurrency,
        max_attempts=max_attempts,
        cron=cron or [],
        on_failure=on_failure,
        input_schema=input_schema,
    )
    defn = WorkflowDefinition(options=opts, handler=handler)
    (registry or get_default_registry()).register(defn)
    return defn


# ---------- @workflow decorator API ----------


@overload
def workflow(
    name: str,
    *,
    queue: str = ...,
    max_concurrency: int = ...,
    max_attempts: int | None = ...,
    cron: list[CronTrigger] | None = ...,
    on_failure: Any | None = ...,
    input_schema: Any | None = ...,
    registry: WorkflowRegistry | None = ...,
) -> Callable[[HandlerFn], WorkflowDefinition]: ...


@overload
def workflow(
    name: str,
) -> Callable[[HandlerFn], WorkflowDefinition]: ...


def workflow(
    name: str,
    **kwargs: Any,
) -> Callable[[HandlerFn], WorkflowDefinition]:
    """Decorator that registers a workflow handler.

    >>> @workflow("my-workflow", queue="critical")
    ... async def handle(ctx: WorkflowHandlerContext) -> dict:
    ...     return {"done": True}
    """

    def decorator(fn: HandlerFn) -> WorkflowDefinition:
        return define_workflow(name, handler=fn, **kwargs)

    return decorator
