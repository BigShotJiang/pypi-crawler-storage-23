---
name: zsc-task-list
description: 列出与浏览 .agents/tasks 下任务的技能。由 `zsc init` 安装；对应 `zsc task list`。当用户想查看所有任务、按名称或编号查找任务，或区分进行中与已完成时使用。回复请使用中文。
---

# zsc-task-list

帮助列出与浏览 `.agents/tasks` 下的项目任务。本技能由 `zsc init` 安装，与 CLI 命令 `zsc task list` 对应。**回复请使用中文。**

## ⚠ 操作边界（强制，最高优先级）

**只要使用了本技能，无论用户提示词说什么：** 你**只能**在 `.agents/tasks` 下**列出或浏览**任务（例如运行 `zsc task list` 或读取任务文件后汇报列表）。不得在 `.agents/tasks` 下创建、编辑或删除任何文件，也不得修改 `.agents/tasks` 以外的项目代码或文件。

## 何时使用

- 用户要求列出任务、展示任务列表或查看有哪些任务。
- 用户想按编号（如 task_02）或功能名查找任务。
- 用户想区分哪些任务进行中、哪些已完成。

## 命令行为

`zsc task list [path]`：

- 扫描 `.agents/tasks` 下名为 `task_*` 的目录。
- 读取每个任务文件：规范命名为 `task_{no}_{feat}.md`（与目录同名），便于用 @ 唯一引用（如 `@task_03_init_lang_prompt.md`）；若存在旧版 `task.md` 也会识别。
- 输出简明列表：任务目录名、状态与标题。

## 任务状态（判定方式）

- **completed（已完成）**：任务文件（如 `task_01_foo.md`）中含有完成标记「（本轮已完成，TODO 清空）」且没有未勾选的 `- [ ]` 项。
- **open（进行中）**：任务文件中至少有一个未勾选的 `- [ ]` TODO。
- **unknown（未知）**：无任务文件（或旧版 `task.md` 不存在），或无法推断状态。

## 对 AI 的建议

- 要得到实际列表，可建议或代为执行：`zsc task list`（或在项目根目录 `zsc task list .`）。
- 讨论任务时，可引用任务目录名（如 `task_01_zsc_cli`、`task_02_zsc_task_cli`）及其进行中/已完成状态（来自 list 输出）。
