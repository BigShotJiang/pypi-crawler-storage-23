---
name: zsc-task-list
description: Skill for listing and browsing tasks under .agents/tasks. Installed by `zsc init`; corresponds to `zsc task list`. Use when the user wants to see all tasks, find a task by name or number, or understand which tasks are open vs completed.
---

# zsc-task-list

Helps list and browse project tasks under `.agents/tasks`. This skill is installed by `zsc init` and aligns with the CLI command `zsc task list`.

## ⚠ Scope boundary (mandatory, highest priority)

**Whenever this skill is used, regardless of the user's prompt:** You may only **list or browse** tasks under `.agents/tasks` (e.g. run `zsc task list` or read task files there to report the list). Do not create, edit, or delete any files under `.agents/tasks`, and do not modify any project code or files outside `.agents/tasks`.

## When to use

- User asks to list tasks, show task list, or see what tasks exist.
- User wants to find a task by number (e.g. task_02) or feature name.
- User wants to know which tasks are open vs completed.

## What the command does

`zsc task list [path]`:

- Scans `.agents/tasks` for directories named `task_*`.
- Reads each task file: canonical name is `task_{no}_{feat}.md` (same as directory), so tasks can be referenced uniquely (e.g. `@task_03_init_lang_prompt.md`); legacy `task.md` is also supported when present.
- Prints a concise list: task directory name, status, and title.

## Task status (how it is determined)

- **completed**: The task file (e.g. `task_01_foo.md`) contains the completion marker "（本轮已完成，TODO 清空）" and no unchecked `- [ ]` items.
- **open**: The task file contains at least one unchecked `- [ ]` TODO.
- **unknown**: No task file (or legacy `task.md` missing), or status cannot be inferred.

## Suggestions for the AI

- To get the actual list, suggest or run: `zsc task list` (or `zsc task list .` from project root).
- When discussing tasks, you can refer to task directory names (e.g. `task_01_zsc_cli`, `task_02_zsc_task_cli`) and their open/completed state from the list output.
