"""CLI module for sagecoffee."""
