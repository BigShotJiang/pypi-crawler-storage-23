"""Prosaic - A writer-first terminal writing app."""

__version__ = "0.1.0"
