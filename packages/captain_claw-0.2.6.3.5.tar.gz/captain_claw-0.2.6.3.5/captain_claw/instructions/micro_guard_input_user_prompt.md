Label: {interaction_label}

Content:
{content}

Classify by safety risk.