# nw-data-engineer-reviewer

Use for review and critique tasks - Data architecture and pipeline review specialist. Runs on Haiku for cost efficiency.

**Wave:** Other
**Model:** haiku
**Max turns:** 30
**Tools:** Read, Glob, Grep, Task

## Skills

- [review-criteria](../../../nWave/skills/data-engineer-reviewer/review-criteria.md) — Evaluation criteria and scoring for data engineering artifact reviews
