from plain.signals.dispatch import Signal

request_started = Signal()
request_finished = Signal()
