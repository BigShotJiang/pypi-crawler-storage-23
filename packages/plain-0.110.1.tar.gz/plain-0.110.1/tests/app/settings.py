SECRET_KEY = "secret"
DEBUG = True

URLS_ROUTER = "app.urls.AppRouter"

INSTALLED_PACKAGES = [
    "app.test",
]

EXPLICIT_SETTING = "explicitly changed"
EXPLICIT_OVERRIDDEN_SETTING = "explicit value"
