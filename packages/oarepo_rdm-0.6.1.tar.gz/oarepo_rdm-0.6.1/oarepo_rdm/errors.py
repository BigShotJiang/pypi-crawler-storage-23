class UndefinedModelError(ValueError):
    """"""
