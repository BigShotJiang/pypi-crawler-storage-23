from invenio_rdm_records.services.config import RDMRecordServiceConfig


class OARepoRDMServiceConfig(RDMRecordServiceConfig):
    """"""

    # PERMISSIONS_PRESETS = ["everyone"]
    # result_item_cls = RecordItem
    # result_list_cls = RecordList
