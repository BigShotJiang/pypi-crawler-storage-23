"""signate-wandb-sync: Record SIGNATE competition scores to W&B."""

__version__ = "0.1.0"
