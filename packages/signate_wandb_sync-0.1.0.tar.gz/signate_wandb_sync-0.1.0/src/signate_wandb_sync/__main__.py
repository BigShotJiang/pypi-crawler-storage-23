"""Allow running as: python -m signate_wandb_sync"""

from signate_wandb_sync.cli import main

if __name__ == "__main__":
    main()
