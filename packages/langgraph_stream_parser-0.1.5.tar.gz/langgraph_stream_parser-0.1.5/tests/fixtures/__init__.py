"""Test fixtures for langgraph-stream-parser."""
