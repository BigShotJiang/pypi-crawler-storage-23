"""Tests for langgraph-stream-parser."""
