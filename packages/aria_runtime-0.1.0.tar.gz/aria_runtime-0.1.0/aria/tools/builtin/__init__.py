from aria.tools.builtin.read_file import ToolPlugin as ReadFileTool
from aria.tools.builtin.write_file import ToolPlugin as WriteFileTool

BUILTIN_TOOLS = [ReadFileTool, WriteFileTool]
