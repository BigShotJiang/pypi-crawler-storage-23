"""Automated exploratory data analysis."""

from timesage.eda.profiler import profile

__all__ = ["profile"]
