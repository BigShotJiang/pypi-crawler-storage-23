# Benchmarks

## Results

### Single Image

| Benchmark | aef-loader | rioxarray | Xee | rasteret (0.3.0) |
|---|---|---|---|---|
| Single tile load + write to zarr | 115.9s | 249.2s | TBD | TBD |
| Multi-tile reproject + composite | | | TBD | TBD |

### Multi-temporal
TBD

### Composite
TBD

## Benchmark environment
- Google Cloud Compute Engine
- VM was an n4-standard-4 (4vCPU, 2 Core, 16GB memory)
- Hosted in US-Central-1
- $0.20 hourly VM