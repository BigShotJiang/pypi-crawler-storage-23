"""Tests for aef-loader package."""
