"""Convexity SDK - Python client for the Convexity platform."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _v

try:
    __version__ = _v("convexity-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from .client import AsyncConvexityClient, ConvexityClient
from .exceptions import (
    AuthenticationError,
    ConflictError,
    ConvexityError,
    NotFoundError,
    PermissionError,
    RateLimitError,
    ServerError,
    ValidationError,
)

__all__ = [
    "AsyncConvexityClient",
    "AuthenticationError",
    "ConflictError",
    "ConvexityClient",
    "ConvexityError",
    "NotFoundError",
    "PermissionError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
]
