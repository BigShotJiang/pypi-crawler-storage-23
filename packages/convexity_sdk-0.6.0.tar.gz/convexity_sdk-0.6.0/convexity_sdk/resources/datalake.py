"""Datalake resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    get_or_create_datalake_connection_info_v1_datalake_connection_get as _get_datalake_info,
)
from convexity_api_client.models.datalake_connection_response import DatalakeConnectionResponse


class Datalake:
    """Synchronous sub-client for datalake operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def get_info(self, project_id: str) -> DatalakeConnectionResponse:
        """Get (or create) DuckLake connection info for a project."""
        result = _get_datalake_info.sync(client=self._client, project_id=project_id)
        if not isinstance(result, DatalakeConnectionResponse):
            return DatalakeConnectionResponse()
        return result
