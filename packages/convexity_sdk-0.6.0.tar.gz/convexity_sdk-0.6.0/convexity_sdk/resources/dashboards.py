"""Dashboard resource client."""

from __future__ import annotations

from convexity_api_client import AuthenticatedClient, Client
from convexity_api_client.api.v1 import (
    create_dashboard_v1_dashboards_post as _create_dashboard,
)
from convexity_api_client.api.v1 import (
    create_share_v1_dashboards_dashboard_id_share_post as _create_share,
)
from convexity_api_client.api.v1 import (
    get_dashboard_v1_dashboards_dashboard_id_get as _get_dashboard,
)
from convexity_api_client.api.v1 import (
    list_dashboards_v1_dashboards_get as _list_dashboards,
)
from convexity_api_client.models.create_dashboard_request import CreateDashboardRequest
from convexity_api_client.models.create_share_request import CreateShareRequest
from convexity_api_client.models.dashboard_definition import DashboardDefinition
from convexity_api_client.models.dashboard_list_response import DashboardListResponse
from convexity_api_client.models.dashboard_share_response import DashboardShareResponse


class Dashboards:
    """Synchronous sub-client for dashboard operations."""

    def __init__(self, api_client: AuthenticatedClient | Client) -> None:
        self._client = api_client

    def list(self, project_id: str) -> DashboardListResponse:
        """List dashboards for a project."""
        result = _list_dashboards.sync(client=self._client, project_id=project_id)
        if result is None or not isinstance(result, DashboardListResponse):
            return DashboardListResponse(dashboards=[])
        return result

    def get(self, dashboard_id: str) -> DashboardDefinition | None:
        """Get a single dashboard by ID."""
        result = _get_dashboard.sync(dashboard_id, client=self._client)
        if isinstance(result, DashboardDefinition):
            return result
        return None

    def create(
        self,
        *,
        project_id: str,
        body: CreateDashboardRequest,
    ) -> DashboardDefinition:
        """Create a new dashboard."""
        result = _create_dashboard.sync(client=self._client, body=body, project_id=project_id)
        if not isinstance(result, DashboardDefinition):
            raise ValueError(f"Unexpected response when creating dashboard: {result}")
        return result

    def create_share(
        self,
        *,
        dashboard_id: str,
        body: CreateShareRequest,
    ) -> DashboardShareResponse:
        """Create or update a share for a dashboard."""
        result = _create_share.sync(dashboard_id, client=self._client, body=body)
        if not isinstance(result, DashboardShareResponse):
            raise ValueError(f"Unexpected response when creating dashboard share: {result}")
        return result
