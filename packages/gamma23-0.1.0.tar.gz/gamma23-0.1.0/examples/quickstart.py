"""Gamma23 Python SDK — Quick Start Example

Demonstrates the core flow: create a spend intent, check policy approval,
and execute the spend.

Set GAMMA23_API_KEY in your environment before running:

    export GAMMA23_API_KEY=gm23_your_api_key
    python examples/quickstart.py
"""

from gamma23 import Gamma23, Gamma23Error

def main() -> None:
    client = Gamma23()

    # 1. Check the agent's remaining budget
    budget = client.agents.get_budget("agent_main")
    print(f"Agent budget: {budget.remaining}/{budget.total_budget} {budget.currency}")

    # 2. Create a spend intent
    intent = client.spend_intents.create(
        goal="Purchase Figma Pro annual license",
        budget=144.00,
        currency="USD",
        merchant="Figma",
        category="software",
        domain="figma.com",
        metadata={"team": "design", "requested_by": "agent_main"},
    )
    print(f"\nSpend intent created: {intent.id}")
    print(f"  Status:  {intent.status}")
    print(f"  Budget:  {intent.budget} {intent.currency}")

    if intent.policy_decision:
        pd = intent.policy_decision
        print(f"  Policy:  {'APPROVED' if pd.allowed else 'DENIED'}")
        if pd.reason:
            print(f"  Reason:  {pd.reason}")

    # 3. Execute if approved
    if intent.spend_token:
        print("\nExecuting spend...")
        result = client.spend_intents.execute(
            intent.id,
            spend_token=intent.spend_token,
        )
        print(f"  Transaction: {result.transaction_id}")
        print(f"  Status:      {result.status}")
        print(f"  Amount:      {result.amount} {result.currency}")
    else:
        print("\nSpend was not approved — no spend token issued.")


if __name__ == "__main__":
    try:
        main()
    except Gamma23Error as e:
        print(f"Gamma23 API error: {e}")
        raise SystemExit(1)
