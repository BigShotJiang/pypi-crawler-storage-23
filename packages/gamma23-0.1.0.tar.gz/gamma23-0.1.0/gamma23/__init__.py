"""Gamma23 — Financial infrastructure for AI agents.

Usage::

    from gamma23 import Gamma23

    client = Gamma23(api_key="gm23_...")
    intent = client.spend_intents.create(goal="Buy SaaS license", budget=50.0)
"""

from gamma23.client import Gamma23
from gamma23.errors import (
    AuthenticationError,
    Gamma23Error,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from gamma23.types import (
    AgentBudget,
    ExecuteResult,
    PaymentRequest,
    PolicyDecision,
    SpendIntent,
)

__all__ = [
    "Gamma23",
    "AgentBudget",
    "AuthenticationError",
    "ExecuteResult",
    "Gamma23Error",
    "NotFoundError",
    "PaymentRequest",
    "PolicyDecision",
    "RateLimitError",
    "SpendIntent",
    "ValidationError",
]

__version__ = "0.1.0"
