# JSON Schema Utils Backlog

## JSU schema compilation with JMC backend

- [ ] move typing out to simplify the generated code
- [ ] be listed on [bowtie](https://bowtie.report/)
- [ ] get 100% on _draft2019-09_
- [ ] get 100% on _draft2020-12_
- [ ] add `.in` support with constraints
- [ ] tests with all languages, not just Python
- [ ] list compiler current limitations
- [ ] run some optional tests, eg _format_
- [ ] put typing result in "$type" instead of "type" to help with fixing?

## Dones

- [x] improve _merge_ to reject some cases
- [x] add `.in` extension support to JMC
- [x] get 100% on _draft7_
- [x] get 100% on _draft6_
- [x] get 100% on _draft4_
- [x] get 100% on _draft3_
- [x] add implementation to [bowtie](https://docs.bowtie.report/en/stable/)
- [x] improve `propertyNames` handling with defs, requires some refactoring
- [x] cleanup direct uses of quote/unquote in simplify
- [x] add `--loose` option for numbers
- [x] add `--out file` option to `jsu-model`
