"""Allow running as `python -m guten_morgen`."""  # pragma: no cover

from __future__ import annotations  # pragma: no cover

from guten_morgen.cli import cli  # pragma: no cover

cli()  # pragma: no cover
