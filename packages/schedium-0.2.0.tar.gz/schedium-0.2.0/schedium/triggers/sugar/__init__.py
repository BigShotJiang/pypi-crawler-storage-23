from __future__ import annotations

from schedium.triggers.sugar.daily import Daily
from schedium.triggers.sugar.weekly import Weekly

__all__ = [
    "Daily",
    "Weekly",
]
