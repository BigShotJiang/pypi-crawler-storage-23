from .cancel_on_failure import cancel_job_on_failure

__all__ = [
    "cancel_job_on_failure",
]
