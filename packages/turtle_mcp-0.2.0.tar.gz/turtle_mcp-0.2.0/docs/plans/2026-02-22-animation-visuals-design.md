# Animation & Visual Enhancement Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Make turtle drawings visibly animate (pen moves on screen) with dark theme, neon glow effects, and a visible turtle cursor.

**Architecture:** All changes are in `turtle_mcp/utils.py`. We modify the Tk thread setup and `execute_drawing` bridge to enable turtle-native animation (tracer/speed), dark background, a visible cursor, and canvas-level neon glow post-processing. No drawing functions change.

**Tech Stack:** Python 3.13, tkinter, turtle (stdlib)

---

### Task 1: Dark Canvas Background

**Files:**
- Modify: `turtle_mcp/utils.py:56-66` (`_run_tk`) and `turtle_mcp/utils.py:106-116` (`_on_tk_thread` inside `execute_drawing`)

**Step 1: Change background color in `_run_tk`**

In `_run_tk()`, change line 65:
```python
# Before:
_screen.bgcolor("white")
# After:
_screen.bgcolor("#1a1a2e")
```

Also set the canvas background to match (for the window frame area):
```python
_canvas = tk.Canvas(_root, width=800, height=800, bg="#1a1a2e", highlightthickness=0)
```

**Step 2: Change background color in `execute_drawing`**

In `_on_tk_thread()` inside `execute_drawing`, change line 110:
```python
# Before:
_screen.bgcolor("white")
# After:
_screen.bgcolor("#1a1a2e")
```

**Step 3: Update window title**

Change the window title from "Turtle MCP" to "Turtle MCP - Drawing..." for visual flair:
```python
_root.title("Turtle MCP")
```
Keep as-is (no change needed here).

**Step 4: Run and verify visually**

Run: `cd /c/Users/pouri/Python/AI/Test/turtle-mcp && uv run python -c "import turtle_mcp.utils; import asyncio; asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: t.forward(100)))"`
Expected: Dark blue-black window appears with a line drawn on it.

**Step 5: Commit**

```bash
git add turtle_mcp/utils.py
git commit -m "feat: dark canvas background for enhanced visuals"
```

---

### Task 2: Enable Animation (Tracer & Speed)

**Files:**
- Modify: `turtle_mcp/utils.py:106-116` (`_on_tk_thread` inside `execute_drawing`)

**Step 1: Change tracer settings**

In `_on_tk_thread()`, replace:
```python
# Before:
_screen.tracer(0)
t = turtle.RawTurtle(_screen)
t.speed(0)
t.hideturtle()
# After:
_screen.tracer(1, 10)
t = turtle.RawTurtle(_screen)
t.speed(6)
t.pensize(2)
```

Key changes:
- `tracer(1, 10)` — screen updates after every 1 turtle action with 10ms delay
- `speed(6)` — medium animation speed
- `pensize(2)` — thicker lines visible on dark background
- Remove `t.hideturtle()` (cursor will be shown — handled in Task 3)

**Step 2: Keep the final `_screen.update()` call**

The existing `_screen.update()` after `draw_fn(t, _screen)` stays — it ensures the final frame is fully rendered.

**Step 3: Also update `_run_tk` tracer**

In `_run_tk()`, change:
```python
# Before:
_screen.tracer(0)
# After:
_screen.tracer(1, 10)
```

**Step 4: Run and verify animation**

Run: `cd /c/Users/pouri/Python/AI/Test/turtle-mcp && uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.geometric import draw_star
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_star(t, s, points=5, size=200, palette='neon')))
"`
Expected: See the star being drawn stroke by stroke at medium speed on dark background.

**Step 5: Commit**

```bash
git add turtle_mcp/utils.py
git commit -m "feat: enable visible animation with medium speed drawing"
```

---

### Task 3: Visible Turtle Cursor

**Files:**
- Modify: `turtle_mcp/utils.py:106-120` (`_on_tk_thread` inside `execute_drawing`)

**Step 1: Register custom cursor shape and show turtle**

In `_on_tk_thread()`, after creating the turtle, add:
```python
t = turtle.RawTurtle(_screen)
t.speed(6)
t.pensize(2)
# Visible cursor
t.shape("arrow")
t.shapesize(0.8, 0.8, 1)
t.pencolor("#00FFFF")
t.showturtle()
```

**Step 2: Hide cursor after drawing completes**

After `draw_fn(t, _screen)`, add `t.hideturtle()` so the cursor doesn't remain on the final image:
```python
draw_fn(t, _screen)
t.hideturtle()
_screen.update()
```

**Step 3: Run and verify cursor**

Run: `cd /c/Users/pouri/Python/AI/Test/turtle-mcp && uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.fractals import draw_fractal_tree
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_fractal_tree(t, s, depth=6, season='autumn')))
"`
Expected: See an arrow cursor moving as the fractal tree draws, then cursor disappears when done.

**Step 4: Commit**

```bash
git add turtle_mcp/utils.py
git commit -m "feat: show visible turtle cursor during drawing animation"
```

---

### Task 4: Neon Glow Post-Processing

**Files:**
- Modify: `turtle_mcp/utils.py` — add `_apply_glow()` function and call it in `_on_tk_thread`

**Step 1: Add the `_apply_glow` function**

Add this function after the `execute_drawing` function:

```python
def _apply_glow(canvas: tk.Canvas) -> None:
    """Add neon glow effect by duplicating lines with wider, stippled strokes."""
    line_items = canvas.find_all()
    for item in line_items:
        item_type = canvas.type(item)
        if item_type != "line":
            continue
        coords = canvas.coords(item)
        if len(coords) < 4:
            continue
        fill = canvas.itemcget(item, "fill")
        if not fill:
            continue
        width = float(canvas.itemcget(item, "width"))
        # Create glow line underneath the original
        glow_id = canvas.create_line(
            *coords,
            fill=fill,
            width=width * 3,
            stipple="gray50",
            capstyle=tk.ROUND,
            joinstyle=tk.ROUND,
        )
        canvas.tag_lower(glow_id, item)
```

**Step 2: Call `_apply_glow` in `_on_tk_thread` after drawing**

```python
draw_fn(t, _screen)
t.hideturtle()
_apply_glow(_canvas)
_screen.update()
```

Note: `_canvas` is accessible because `_on_tk_thread` is a closure inside `execute_drawing` which has access to the module-level `_canvas`.

**Step 3: Run and verify glow**

Run: `cd /c/Users/pouri/Python/AI/Test/turtle-mcp && uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.geometric import draw_spiral
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_spiral(t, s, spiral_type='archimedean', turns=10, palette='neon')))
"`
Expected: See neon spiral drawn with visible glow halos around each stroke.

**Step 4: Commit**

```bash
git add turtle_mcp/utils.py
git commit -m "feat: add neon glow post-processing effect"
```

---

### Task 5: Update `make_turtle` Helper

**Files:**
- Modify: `turtle_mcp/utils.py:137-142` (`make_turtle`)

**Step 1: Update `make_turtle` to match new defaults**

This helper is used in some drawing functions. Update it to match:
```python
def make_turtle(screen: turtle.TurtleScreen) -> turtle.RawTurtle:
    """Create a fresh RawTurtle with animation-friendly defaults."""
    t = turtle.RawTurtle(screen)
    t.speed(6)
    t.pensize(2)
    t.hideturtle()
    return t
```

Note: Helper turtles stay hidden (they're secondary turtles used for fills, not the main cursor).

**Step 2: Commit**

```bash
git add turtle_mcp/utils.py
git commit -m "feat: update make_turtle helper with animation defaults"
```

---

### Task 6: Final Integration Verification

**Step 1: Test multiple drawing types**

Run each of these and verify animation + glow + dark theme:

```bash
# Geometric
uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.geometric import draw_mandala
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_mandala(t, s, layers=4, symmetry=8, style='floral', palette='cherry')))
"

# Fractal
uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.fractals import draw_koch_snowflake
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_koch_snowflake(t, s, depth=3, size=250, palette='ocean')))
"

# Nature
uv run python -c "
import turtle_mcp.utils, asyncio
from turtle_mcp.drawings.nature import draw_flower
asyncio.run(turtle_mcp.utils.execute_drawing(lambda t, s: draw_flower(t, s, flower_type='sunflower', palette='sunset')))
"
```

**Step 2: Verify MCP server starts cleanly**

```bash
uv run turtle-mcp
```

Expected: Server starts on stdio without errors. (Ctrl+C to stop.)

**Step 3: Final commit (if any adjustments needed)**

```bash
git add -A
git commit -m "feat: animation and visual enhancements - dark theme, glow, cursor"
```

---

## Summary of All Changes

**Only `turtle_mcp/utils.py` is modified:**

| Line Range | Change |
|---|---|
| `_run_tk` (L52-69) | Dark bgcolor, canvas bg/highlightthickness, tracer(1,10) |
| `execute_drawing._on_tk_thread` (L106-120) | Dark bgcolor, tracer(1,10), speed(6), pensize(2), showturtle, hideturtle after draw, glow call |
| New `_apply_glow()` | Neon glow post-processing function |
| `make_turtle` (L137-142) | speed(6), pensize(2) defaults |

**No other files changed.** All 14 drawing tools work without modification.
