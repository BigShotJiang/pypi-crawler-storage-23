"""Drawing modules for turtle_mcp."""
