"""Turtle MCP Server - Drawing tools for LLMs via Model Context Protocol."""

__version__ = "0.1.0"
