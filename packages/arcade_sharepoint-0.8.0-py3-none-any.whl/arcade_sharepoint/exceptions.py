from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils import exceptions as microsoft_exceptions


class SharePointToolExecutionError(ToolExecutionError):
    pass


class SiteNotFoundError(SharePointToolExecutionError):
    """Raised when a site is not found."""

    def __init__(self, site_identifier: str):
        self.site_identifier = site_identifier
        message = f"Site with identifier '{site_identifier}' was not found."
        super().__init__(message=message, developer_message=message)


UnsupportedFileTypeError = microsoft_exceptions.UnsupportedFileTypeError
SizeLimitExceededError = microsoft_exceptions.SizeLimitExceededError
ConflictError = microsoft_exceptions.ConflictError
ConversionError = microsoft_exceptions.ConversionError
DocumentLockedError = microsoft_exceptions.DocumentLockedError
DownloadSizeLimitExceededError = microsoft_exceptions.DownloadSizeLimitExceededError

__all__ = [
    "ConflictError",
    "ConversionError",
    "DocumentLockedError",
    "DownloadSizeLimitExceededError",
    "SharePointToolExecutionError",
    "SiteNotFoundError",
    "SizeLimitExceededError",
    "UnsupportedFileTypeError",
]
