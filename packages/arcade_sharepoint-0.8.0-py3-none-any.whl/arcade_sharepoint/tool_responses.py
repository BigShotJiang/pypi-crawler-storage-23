"""TypedDict models for SharePoint tool responses."""

from typing import Any

from typing_extensions import TypedDict

# Re-export WhoAmIResponse for consistency
from arcade_sharepoint.who_am_i_util import WhoAmIResponse

__all__ = [
    "CopyItemResponse",
    "CreateFolderResponse",
    "CreatePresentationResponse",
    "CreateShareLinkResponse",
    "CreateSlideResponse",
    "DeleteItemResponse",
    "DocumentMetadataResponse",
    "DriveItemData",
    "DriveItemRemoteItem",
    "DriveItemSize",
    "DriveQuota",
    "DriveQuotaSize",
    "GetAllSlideNotesResponse",
    "GetCopyStatusResponse",
    "GetDrivesFromSiteResponse",
    "GetListItemsResponse",
    "GetListsFromSiteResponse",
    "GetPageResponse",
    "GetPresentationAsMarkdownResponse",
    "GetSlideNotesResponse",
    "GetWordDocumentResponse",
    "ListData",
    "ListDriveItemsResponse",
    "ListItemData",
    "ListPagesResponse",
    "MoveItemResponse",
    "PaginationInfo",
    "SearchSitesResponse",
    "SiteData",
    "SiteDriveData",
    "SitePageData",
    "UserIdentity",
    "WhoAmIResponse",
    # PowerPoint types
    "PresentationItemSize",
    "PresentationItemData",
    "SlideData",
    "GetPresentationAsMarkdownResponse",
    "CreatePresentationResponse",
    "CreateSlideResponse",
    "GetSlideNotesResponse",
    "SetSlideNotesResponse",
    "SlideNotesData",
    "GetAllSlideNotesResponse",
    # Excel types
    "ExcelWorkbookItemSize",
    "ExcelWorkbookItemData",
    "ExcelWorksheetInfo",
    "ExcelRangeInfo",
    "ExcelPaginationRange",
    "ExcelPaginationInfo",
    "CreateWorkbookResponse",
    "GetWorkbookMetadataResponse",
    "GetWorksheetDataResponse",
    "UpdateCellResponse",
    "UpdateRangeResponse",
    "AddWorksheetResponse",
    "RenameWorksheetResponse",
    "DeleteWorksheetResponse",
]


# Common types
class PaginationInfo(TypedDict, total=False):
    """Pagination information for paginated responses."""

    limit: int
    current_offset: int
    next_offset: int | None
    more_items_available: bool


class UserIdentity(TypedDict, total=False):
    """User identity information."""

    user_id: str
    user_display_name: str


# Drive types
class DriveQuotaSize(TypedDict, total=False):
    """Quota size information."""

    bytes: int
    formatted: str
    percentage_used: str


class DriveQuota(TypedDict, total=False):
    """Drive quota information."""

    total: DriveQuotaSize
    used: DriveQuotaSize


class SiteDriveData(TypedDict, total=False):
    """Serialized SharePoint site drive data."""

    object_type: str
    drive_id: str
    name: str
    description: str
    drive_type: str
    web_url: str
    parent_site_id: str
    created_by: UserIdentity
    created_at: str
    drive_size: DriveQuota


class GetDrivesFromSiteResponse(TypedDict):
    """Response from the get_drives_from_site tool."""

    drives: list[SiteDriveData]
    count: int


# DriveItem types
class DriveItemSize(TypedDict, total=False):
    """Size information for a drive item."""

    bytes: int
    formatted: str


class DriveItemRemoteItem(TypedDict, total=False):
    """Remote item information for shared items."""

    info: str
    name: str
    web_url: str
    item_type: str
    file_id_in_the_remote_drive: str
    folder_id: str
    mime_type: str


class DriveItemData(TypedDict, total=False):
    """Serialized SharePoint drive item data."""

    object_type: str
    name: str
    parent_site_id: str
    parent_drive_id: str
    parent_folder_id: str
    size: DriveItemSize
    web_url: str
    item_type: str
    item_id: str
    file_id: str
    folder_id: str
    mime_type: str
    package_type: str
    remote_item: DriveItemRemoteItem
    created_by: UserIdentity
    created_at: str
    children: list[dict[str, Any]]
    malware: dict[str, Any]
    audio: dict[str, Any]
    image: dict[str, Any]
    photo: dict[str, Any]
    video: dict[str, Any]


class ListDriveItemsResponse(TypedDict, total=False):
    """Response from tools that list drive items (list_root_items_in_drive, list_items_in_folder, search_drive_items)."""

    items: list[DriveItemData]
    count: int
    pagination: PaginationInfo


class CreateFolderResponse(TypedDict):
    """Response from the create_folder tool."""

    item: DriveItemData
    message: str


class DeleteItemResponse(TypedDict):
    """Response from the delete_item tool."""

    status: str
    message: str


class MoveItemResponse(TypedDict):
    """Response from the move_item tool."""

    item: DriveItemData
    message: str


class CopyItemResponse(TypedDict, total=False):
    """Response from the copy_item tool.

    Returns either a completed item with status='completed' or operation details
    if the copy is still in progress.
    """

    status: str
    item: DriveItemData
    operation_url: str
    message: str


class GetCopyStatusResponse(TypedDict, total=False):
    """Response from the get_copy_status tool."""

    status: str
    item: DriveItemData
    message: str


class CreateShareLinkResponse(TypedDict, total=False):
    """Response from the create_share_link tool."""

    id: str
    roles: list[str]
    shareId: str
    expirationDateTime: str
    hasPassword: bool
    link: dict[str, Any]
    message: str


# List types
class ListData(TypedDict, total=False):
    """Serialized SharePoint list data."""

    object_type: str
    list_id: str
    name: str
    display_name: str
    description: str
    web_url: str
    parent_site_id: str
    created_at: str


class GetListsFromSiteResponse(TypedDict):
    """Response from the get_lists_from_site tool."""

    site_id: str
    lists: list[ListData]
    count: int


class ListItemParent(TypedDict):
    """Parent information for a list item."""

    site_id: str
    list_id: str


class ListItemData(TypedDict, total=False):
    """Serialized SharePoint list item data."""

    object_type: str
    list_item_id: str
    title: str | None
    created_by: UserIdentity | None
    created_at: str | None
    parent: ListItemParent
    has_attachments: bool


class GetListItemsResponse(TypedDict):
    """Response from the get_items_from_list tool."""

    items: list[ListItemData]
    count: int


# Page types
class SitePageData(TypedDict, total=False):
    """Serialized SharePoint site page data."""

    object_type: str
    page_id: str
    name: str
    title: str
    description: str
    web_url: str
    show_comments: bool
    thumbnail_web_url: str
    comment_count: int
    like_count: int
    view_count: int
    created_by: UserIdentity
    created_at: str
    page_layout: str
    publishing_state: str
    parent_site_id: str
    content: list[dict[str, Any]]


class GetPageResponse(TypedDict, total=False):
    """Response from the get_page tool."""

    object_type: str
    page_id: str
    name: str
    title: str
    description: str
    web_url: str
    show_comments: bool
    thumbnail_web_url: str
    comment_count: int
    like_count: int
    view_count: int
    created_by: UserIdentity
    created_at: str
    page_layout: str
    publishing_state: str
    parent_site_id: str
    content: list[dict[str, Any]]


class ListPagesResponse(TypedDict):
    """Response from the list_pages tool."""

    pages: list[SitePageData]
    count: int


# Site types
class SiteData(TypedDict, total=False):
    """Serialized SharePoint site data."""

    object_type: str
    site_id: str
    name: str
    display_name: str
    description: str
    web_url: str
    created_at: str
    lists: list[ListData]
    drives: list[SiteDriveData]


class SearchSitesResponse(TypedDict, total=False):
    """Response from the search_sites and list_sites tools."""

    sites: list[SiteData]
    count: int
    pagination: PaginationInfo


# Word document types (for SharePoint Word tools)
class DocumentMetadataResponse(TypedDict):
    """Response from Word document tools that return metadata (create_word_document, insert_text_at_end_of_word_document)."""

    item: DriveItemData


class GetWordDocumentResponse(DocumentMetadataResponse, total=False):
    """Response from the get_word_document tool. Always includes item metadata; content and content_format are included only when metadata_only is False."""

    content: str
    content_format: str


# PowerPoint types (for SharePoint PowerPoint tools)
class PresentationItemSize(TypedDict, total=False):
    """Size information for a presentation."""

    bytes: int
    formatted: str


class PresentationItemData(TypedDict, total=False):
    """Serialized PowerPoint presentation metadata for SharePoint."""

    object_type: str  # "presentation"
    item_id: str
    name: str
    parent_drive_id: str
    parent_folder_id: str
    size: PresentationItemSize
    web_url: str
    etag: str
    slide_count: int
    created_datetime: str
    modified_datetime: str


class SlideData(TypedDict, total=False):
    """Serialized slide data."""

    slide_index: int
    slide_id: str
    layout: str
    title: str
    left_body: str  # For TWO_CONTENT layout
    right_body: str  # For TWO_CONTENT layout


class GetPresentationAsMarkdownResponse(TypedDict):
    """Response from get_presentation_as_markdown tool for SharePoint."""

    item_id: str
    name: str
    web_url: str
    etag: str
    slide_count: int
    content: str


class CreatePresentationResponse(TypedDict):
    """Response from create_presentation tool for SharePoint."""

    item: PresentationItemData
    message: str


class CreateSlideResponse(TypedDict):
    """Response from create_slide tool for SharePoint."""

    slide: SlideData
    item: PresentationItemData
    message: str


class GetSlideNotesResponse(TypedDict):
    """Response from get_slide_notes tool for SharePoint."""

    item_id: str
    slide_index: int
    notes: str  # Speaker notes in markdown format
    has_notes: bool


class SetSlideNotesResponse(TypedDict):
    """Response from set_slide_notes tool for SharePoint."""

    item_id: str
    slide_index: int
    message: str


class SlideNotesData(TypedDict):
    """Speaker notes for a single slide."""

    slide_index: int
    has_notes: bool
    notes: str


class GetAllSlideNotesResponse(TypedDict):
    """Response from get_all_slide_notes tool for SharePoint."""

    item_id: str
    slide_count: int
    slides_with_notes: int
    slides: list[SlideNotesData]


# Excel types (for SharePoint Excel tools)
class ExcelWorkbookItemSize(TypedDict, total=False):
    """Size information for a workbook."""

    bytes: int
    formatted: str


class ExcelWorkbookItemData(TypedDict, total=False):
    """Serialized Excel workbook metadata for SharePoint."""

    object_type: str
    item_id: str
    name: str
    parent_folder_id: str
    size: ExcelWorkbookItemSize
    web_url: str
    etag: str


class ExcelWorksheetInfo(TypedDict):
    """Basic worksheet information."""

    id: str
    name: str
    position: int
    visibility: str


class ExcelRangeInfo(TypedDict):
    """Information about the returned range."""

    start_row: int
    start_col: str
    end_row: int
    end_col: str


class ExcelPaginationRange(TypedDict, total=False):
    """Parameters to use for fetching more data."""

    start_row: int
    start_col: str


class ExcelPaginationInfo(TypedDict, total=False):
    """Pagination hints for fetching additional data."""

    next_rows: ExcelPaginationRange
    next_cols: ExcelPaginationRange


class CreateWorkbookResponse(TypedDict):
    """Response from create_workbook tool for SharePoint."""

    item: ExcelWorkbookItemData
    session_id: str
    message: str


class GetWorkbookMetadataResponse(TypedDict):
    """Response from get_workbook_metadata tool for SharePoint."""

    item_id: str
    name: str
    web_url: str
    worksheets: list[ExcelWorksheetInfo]
    worksheet_count: int
    session_id: str


class GetWorksheetDataResponse(TypedDict):
    """Response from get_worksheet_data tool for SharePoint."""

    item_id: str
    worksheet: str
    range: ExcelRangeInfo
    total_rows: int
    total_columns: int
    pagination: ExcelPaginationInfo
    data: dict
    session_id: str


class UpdateCellResponse(TypedDict):
    """Response from update_cell tool for SharePoint."""

    item_id: str
    worksheet: str
    cell: str
    value: str
    session_id: str
    message: str


class UpdateRangeResponse(TypedDict):
    """Response from update_range tool for SharePoint."""

    item_id: str
    worksheet: str
    cells_updated: int
    session_id: str
    message: str


class AddWorksheetResponse(TypedDict):
    """Response from add_worksheet tool for SharePoint."""

    item_id: str
    worksheet: ExcelWorksheetInfo
    session_id: str
    message: str


class RenameWorksheetResponse(TypedDict):
    """Response from rename_worksheet tool for SharePoint."""

    item_id: str
    worksheet: ExcelWorksheetInfo
    previous_name: str
    session_id: str
    message: str


class DeleteWorksheetResponse(TypedDict):
    """Response from delete_worksheet tool for SharePoint."""

    item_id: str
    deleted_worksheet: str
    session_id: str
    message: str
