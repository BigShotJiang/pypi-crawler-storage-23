"""PowerPoint presentation tools for SharePoint."""

from enum import Enum
from typing import Annotated, Any, cast

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.drive_utils import _smart_upload_content
from arcade_microsoft_utils.powerpoint_utils import (
    PPTX_MIME_TYPE,
    SlideLayout,
    _add_slide_to_pptx,
    _add_two_content_slide_to_pptx,
    _build_blank_pptx_bytes,
    _convert_pptx_to_markdown,
    _download_presentation_content,
    _ensure_download_size_under_limit,
    _ensure_pptx_drive_item,
    _get_all_slide_notes_as_markdown,
    _get_presentation_drive_item,
    _get_slide_count,
    _get_slide_notes_as_markdown,
    _normalize_pptx_title,
    _require_non_empty,
    _set_slide_notes_from_markdown,
)
from arcade_microsoft_utils.utils import human_friendly_bytes_size, remove_none_values
from msgraph.generated.models.drive_item import DriveItem

from arcade_sharepoint.tool_responses import (
    CreatePresentationResponse,
    CreateSlideResponse,
    GetAllSlideNotesResponse,
    GetPresentationAsMarkdownResponse,
    GetSlideNotesResponse,
    PresentationItemData,
    SetSlideNotesResponse,
)


class SlideLayoutOption(str, Enum):
    """Available slide layout options for create_slide.

    For TWO_CONTENT layout with left/right content areas, use create_two_content_slide instead.
    """

    TITLE = "TITLE"
    TITLE_AND_CONTENT = "TITLE_AND_CONTENT"
    SECTION_HEADER = "SECTION_HEADER"
    TITLE_ONLY = "TITLE_ONLY"
    BLANK = "BLANK"
    CONTENT_WITH_CAPTION = "CONTENT_WITH_CAPTION"
    PICTURE_WITH_CAPTION = "PICTURE_WITH_CAPTION"
    TITLE_AND_VERTICAL_TEXT = "TITLE_AND_VERTICAL_TEXT"
    VERTICAL_TITLE_AND_TEXT = "VERTICAL_TITLE_AND_TEXT"


def _serialize_presentation_item(
    item: DriveItem, drive_id: str, slide_count: int = 0, parent_folder_id: str | None = None
) -> PresentationItemData:
    """Serialize a DriveItem representing a PowerPoint presentation for SharePoint.

    Args:
        item: The DriveItem from Microsoft Graph API.
        drive_id: The SharePoint drive ID.
        slide_count: Number of slides in the presentation (if known).
        parent_folder_id: Optional parent folder ID.

    Returns:
        Serialized presentation data dictionary.
    """
    size_bytes = item.size if item.size else 0
    size_info = {
        "bytes": size_bytes,
        "formatted": human_friendly_bytes_size(size_bytes),
    }

    folder_id = parent_folder_id
    if not folder_id and item.parent_reference and item.parent_reference.id:
        folder_id = item.parent_reference.id

    data: dict[str, Any] = {
        "object_type": "presentation",
        "item_id": item.id,
        "name": item.name,
        "parent_drive_id": drive_id,
        "parent_folder_id": folder_id,
        "size": size_info,
        "web_url": item.web_url,
        "etag": item.e_tag,
        "slide_count": slide_count,
        "created_datetime": item.created_date_time.isoformat() if item.created_date_time else None,
        "modified_datetime": item.last_modified_date_time.isoformat()
        if item.last_modified_date_time
        else None,
    }

    return cast(PresentationItemData, remove_none_values(data))


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_presentation(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive to create the presentation in."],
    title: Annotated[str, "The title for the new presentation."],
    folder_id: Annotated[
        str | None,
        "The ID of the folder to create the presentation in. If not provided, "
        "the presentation will be created in the root of the drive.",
    ] = None,
) -> Annotated[CreatePresentationResponse, "The created presentation details."]:
    """
    Create a new PowerPoint presentation in a SharePoint drive.

    The presentation will be created with a title slide containing the specified title.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")

    # Normalize title and ensure it has .pptx extension
    filename = _normalize_pptx_title(title)

    if folder_id is not None:
        folder_id = _require_non_empty(folder_id, "folder_id")

    # Build the presentation bytes
    pptx_bytes = _build_blank_pptx_bytes(title=title)

    token = context.get_auth_token_or_empty()

    # Upload (auto-selects simple vs resumable based on size)
    response = await _smart_upload_content(
        token=token,
        content=pptx_bytes,
        content_type=PPTX_MIME_TYPE,
        filename=filename,
        parent_item_id=folder_id,
        drive_id=drive_id,
        conflict_behavior="fail",
    )

    # Get the created item details
    item_id = response.get("id")
    if not item_id:
        raise ToolExecutionError("Failed to create presentation: no item ID returned.")

    # Fetch the drive item to get full metadata
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    slide_count = _get_slide_count(pptx_bytes)

    return cast(
        CreatePresentationResponse,
        {
            "item": _serialize_presentation_item(drive_item, drive_id, slide_count, folder_id),
            "message": f"Successfully created presentation '{filename}'.",
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_slide(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation to add a slide to."],
    slide_title: Annotated[
        str | None,
        "The title for the new slide. Optional for layouts like BLANK.",
    ] = None,
    slide_body: Annotated[
        str | None,
        "The body content for the new slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting). Optional for layouts like TITLE_ONLY or BLANK.",
    ] = None,
    layout: Annotated[
        SlideLayoutOption | None,
        "The layout to use for the slide. For TWO_CONTENT layout, use create_two_content_slide.",
    ] = None,
) -> Annotated[CreateSlideResponse, "The updated presentation details with new slide info."]:
    """
    Append a new slide to the end of an existing PowerPoint presentation in a SharePoint drive.

    The slide will be added at the end of the presentation. Both title and body
    are optional to support layouts like BLANK or TITLE_ONLY.

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")

    # Get the drive item and validate it's a .pptx
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Get the etag for optimistic concurrency
    etag = drive_item.e_tag

    # Download the current presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Parse layout
    slide_layout = _parse_layout(layout)

    # Add the new slide
    updated_bytes = _add_slide_to_pptx(pptx_bytes, slide_title, slide_body, slide_layout)

    # Upload (auto-selects simple vs resumable based on size)
    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=etag,
        drive_id=drive_id,
    )

    # Fetch updated item
    updated_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    new_slide_count = _get_slide_count(updated_bytes)

    # Build slide description
    slide_desc = slide_title or f"{slide_layout.name} slide"

    return cast(
        CreateSlideResponse,
        {
            "slide": {
                "slide_index": new_slide_count,
                "layout": slide_layout.name,
                "title": slide_title or "",
            },
            "item": _serialize_presentation_item(updated_item, drive_id, new_slide_count),
            "message": f"Successfully added '{slide_desc}' to presentation.",
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_two_content_slide(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation to add a slide to."],
    slide_title: Annotated[
        str | None,
        "The title for the new slide.",
    ] = None,
    left_body: Annotated[
        str | None,
        "Content for the left side of the slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting).",
    ] = None,
    right_body: Annotated[
        str | None,
        "Content for the right side of the slide. Supports markdown: **bold**, *italic*, __underline__, and bullet points (- item, indented with spaces for nesting).",
    ] = None,
) -> Annotated[CreateSlideResponse, "The updated presentation details with new slide info."]:
    """
    Append a TWO_CONTENT slide with side-by-side content areas to the end of a SharePoint PowerPoint.

    This layout is useful for comparisons, pros/cons lists, or any content that
    benefits from a two-column layout.

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")

    # Get the drive item and validate it's a .pptx
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Get the etag for optimistic concurrency
    etag = drive_item.e_tag

    # Download the current presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Add the two-content slide
    updated_bytes = _add_two_content_slide_to_pptx(pptx_bytes, slide_title, left_body, right_body)

    # Upload (auto-selects simple vs resumable based on size)
    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=etag,
        drive_id=drive_id,
    )

    # Fetch updated item
    updated_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    new_slide_count = _get_slide_count(updated_bytes)

    # Build slide description
    slide_desc = slide_title or "Two-content slide"

    return cast(
        CreateSlideResponse,
        {
            "slide": {
                "slide_index": new_slide_count,
                "layout": "TWO_CONTENT",
                "title": slide_title or "",
                "left_body": left_body or "",
                "right_body": right_body or "",
            },
            "item": _serialize_presentation_item(updated_item, drive_id, new_slide_count),
            "message": f"Successfully added '{slide_desc}' to presentation.",
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_presentation_as_markdown(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation to read."],
) -> Annotated[GetPresentationAsMarkdownResponse, "The presentation content as markdown."]:
    """
    Get the content of a PowerPoint presentation stored in a SharePoint drive as markdown.

    This tool downloads the presentation and converts it to a markdown representation,
    preserving text content, tables, and chart data. Images and other media are
    represented as placeholders.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")

    # Get the drive item and validate it's a .pptx
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Convert to markdown
    markdown_content = _convert_pptx_to_markdown(pptx_bytes)

    # Get slide count
    slide_count = _get_slide_count(pptx_bytes)

    return cast(
        GetPresentationAsMarkdownResponse,
        {
            "item_id": item_id,
            "name": drive_item.name or "presentation.pptx",
            "web_url": drive_item.web_url or "",
            "etag": drive_item.e_tag or "",
            "slide_count": slide_count,
            "content": markdown_content,
        },
    )


def _parse_layout(layout: SlideLayoutOption | str | None) -> SlideLayout:  # type: ignore[no-any-unimported]
    """Convert SlideLayoutOption enum or string to SlideLayout (IntEnum for python-pptx)."""
    if not layout:
        return SlideLayout.TITLE_AND_CONTENT

    # Get the value - for enum use .value, for str use directly
    if isinstance(layout, SlideLayoutOption):
        layout_str = layout.value.upper()
    else:
        layout_str = layout.strip().upper()

    layout_map: dict[str, SlideLayout] = {  # type: ignore[no-any-unimported]
        "TITLE": SlideLayout.TITLE,
        "TITLE_AND_CONTENT": SlideLayout.TITLE_AND_CONTENT,
        "SECTION_HEADER": SlideLayout.SECTION_HEADER,
        "TWO_CONTENT": SlideLayout.TWO_CONTENT,
        "COMPARISON": SlideLayout.COMPARISON,
        "TITLE_ONLY": SlideLayout.TITLE_ONLY,
        "BLANK": SlideLayout.BLANK,
        "CONTENT_WITH_CAPTION": SlideLayout.CONTENT_WITH_CAPTION,
        "PICTURE_WITH_CAPTION": SlideLayout.PICTURE_WITH_CAPTION,
        "TITLE_AND_VERTICAL_TEXT": SlideLayout.TITLE_AND_VERTICAL_TEXT,
        "VERTICAL_TITLE_AND_TEXT": SlideLayout.VERTICAL_TITLE_AND_TEXT,
    }

    return layout_map.get(layout_str, SlideLayout.TITLE_AND_CONTENT)


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_slide_notes(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
    slide_index: Annotated[int, "The 1-based index of the slide to get notes from."],
) -> Annotated[GetSlideNotesResponse, "The speaker notes for the specified slide."]:
    """
    Get the speaker notes from a specific slide in a SharePoint PowerPoint presentation.

    Speaker notes are returned in markdown format, preserving basic formatting
    like bold, italic, and bullet points.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    if slide_index < 1:
        raise ToolExecutionError("slide_index must be at least 1.")

    # Validate the item is a PowerPoint file
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Get the notes
    notes = _get_slide_notes_as_markdown(pptx_bytes, slide_index)

    return cast(
        GetSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_index": slide_index,
            "notes": notes,
            "has_notes": bool(notes.strip()),
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def set_slide_notes(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
    slide_index: Annotated[int, "The 1-based index of the slide to set notes on."],
    notes: Annotated[
        str,
        "The speaker notes in markdown format. Supports **bold**, *italic*, "
        "__underline__, and bullet points (- or *).",
    ],
) -> Annotated[SetSlideNotesResponse, "Confirmation of the notes update."]:
    """
    Set or update the speaker notes on a specific slide in a SharePoint PowerPoint.

    Notes can be formatted using markdown:
    - **bold** for bold text
    - *italic* for italic text
    - __underline__ for underlined text
    - Lines starting with - or * become bullet points
    - Indent with spaces for nested bullets

    For presentations larger than 4 MB, the upload uses a resumable session.
    Concurrency protection (etag check) is best-effort in that case, since
    Microsoft Graph upload sessions do not support If-Match headers.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    if slide_index < 1:
        raise ToolExecutionError("slide_index must be at least 1.")

    # Validate and get the item
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Set the notes
    updated_bytes = _set_slide_notes_from_markdown(pptx_bytes, slide_index, notes)

    # Upload (auto-selects simple vs resumable based on size)
    token = context.get_auth_token_or_empty()
    await _smart_upload_content(
        token=token,
        content=updated_bytes,
        content_type=PPTX_MIME_TYPE,
        item_id=item_id,
        etag=drive_item.e_tag,
        drive_id=drive_id,
    )

    return cast(
        SetSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_index": slide_index,
            "message": f"Successfully updated speaker notes for slide {slide_index}.",
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_all_slide_notes(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the presentation."],
    item_id: Annotated[str, "The ID of the PowerPoint presentation."],
) -> Annotated[GetAllSlideNotesResponse, "All speaker notes from the presentation."]:
    """
    Get all speaker notes from every slide in a SharePoint PowerPoint presentation.

    Returns notes for all slides in one call, which is more efficient than
    calling get_slide_notes for each slide individually. Notes are returned
    in markdown format.
    """
    # Validate inputs
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")

    # Validate the item is a PowerPoint file
    drive_item = await _get_presentation_drive_item(context, item_id, drive_id=drive_id)
    _ensure_pptx_drive_item(drive_item)
    _ensure_download_size_under_limit(drive_item)

    # Download the presentation
    pptx_bytes = await _download_presentation_content(context, item_id, drive_id=drive_id)

    # Get all notes
    slides_notes = _get_all_slide_notes_as_markdown(pptx_bytes)
    slides_with_notes = sum(1 for s in slides_notes if s["has_notes"])

    return cast(
        GetAllSlideNotesResponse,
        {
            "item_id": item_id,
            "slide_count": len(slides_notes),
            "slides_with_notes": slides_with_notes,
            "slides": slides_notes,
        },
    )
