from typing import Annotated, cast

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.word_utils import (
    _append_text_to_docx,
    _build_docx_bytes,
    _build_item_url,
    _build_upload_url,
    _convert_docx_bytes,
    _download_drive_item_content,
    _ensure_docx_drive_item,
    _ensure_download_size_under_limit,
    _ensure_payload_under_limit,
    _ensure_text_content,
    _get_drive_item,
    _get_user_display_name,
    _normalize_docx_title,
    _require_non_empty,
    _upload_drive_item_content,
)

from arcade_sharepoint.serializers import serialize_drive_item
from arcade_sharepoint.tool_responses import (
    DocumentMetadataResponse,
    DriveItemData,
    GetWordDocumentResponse,
)


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_word_document(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the document."],
    item_id: Annotated[str, "The DriveItem ID of the Word document."],
    metadata_only: Annotated[
        bool,
        "If True, return only the document metadata without downloading the content. "
        "Defaults to False.",
    ] = False,
) -> Annotated[GetWordDocumentResponse, "The Word document metadata and optionally its content."]:
    """Get a Word document's metadata and content from a SharePoint drive (supports only `.docx`). Returns the document content as Markdown by default, or just metadata when metadata_only is True."""
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")

    item = await _get_drive_item(context, item_id=item_id, drive_id=drive_id)
    _ensure_docx_drive_item(item)

    result: GetWordDocumentResponse = {
        "item": cast(DriveItemData, serialize_drive_item(item=item, drive_id=drive_id))
    }

    if not metadata_only:
        _ensure_download_size_under_limit(item)
        doc_bytes = await _download_drive_item_content(context, item_id=item_id, drive_id=drive_id)
        content, content_format = _convert_docx_bytes(doc_bytes)
        result["content"] = content
        result["content_format"] = content_format

    return result


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_word_document(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive to create the document in."],
    title: Annotated[
        str,
        "File name without extension, or with .docx. The .docx extension is normalized.",
    ],
    text_content: Annotated[
        str | None,
        "Optional text content to include in the new document. "
        "If omitted, an empty document is created.",
    ] = None,
    folder_id: Annotated[
        str | None,
        "Optional parent folder DriveItem ID. If omitted, the document is created in the root.",
    ] = None,
    conflict_behavior: Annotated[
        str | None,
        "Optional conflict behavior when a file with the same name exists. "
        "One of: fail, rename, replace.",
    ] = None,
) -> Annotated[DocumentMetadataResponse, "The created Word document metadata."]:
    """Create a new Word document in a SharePoint drive (4MB upload limit). Optionally include text content."""
    drive_id = _require_non_empty(drive_id, "drive_id")
    title = _normalize_docx_title(title)

    if text_content is not None:
        _ensure_text_content(text_content)

    if folder_id is not None:
        folder_id = _require_non_empty(folder_id, "folder_id")

    author_name = await _get_user_display_name(context)
    doc_bytes = _build_docx_bytes(text_content=text_content, author_name=author_name)
    _ensure_payload_under_limit(doc_bytes)

    url = _build_upload_url(
        title=title,
        folder_id=folder_id,
        drive_id=drive_id,
        conflict_behavior=conflict_behavior,
    )
    response = await _upload_drive_item_content(context, url, doc_bytes)
    item_id = response.get("id")
    if not item_id:
        raise ToolExecutionError("Failed to create document. No DriveItem ID returned.")

    item = await _get_drive_item(context, item_id=item_id, drive_id=drive_id)
    return {
        "item": cast(
            DriveItemData,
            serialize_drive_item(item=item, drive_id=drive_id, parent_folder_id=folder_id),
        )
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def insert_text_at_end_of_word_document(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the document."],
    item_id: Annotated[str, "The DriveItem ID of the Word document."],
    text_content: Annotated[str, "The text content to append to the document."],
) -> Annotated[DocumentMetadataResponse, "The updated Word document metadata."]:
    """Append text to the end of an existing Word document.

    This tool only supports files with the `.docx` extension and enforces the 4MB limit.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    _ensure_text_content(text_content)

    item = await _get_drive_item(context, item_id=item_id, drive_id=drive_id)
    _ensure_docx_drive_item(item)
    _ensure_download_size_under_limit(item)

    etag = getattr(item, "e_tag", None)
    if not etag:
        raise ToolExecutionError(
            "Unable to determine document version. Re-fetch and retry your update."
        )

    author_name = await _get_user_display_name(context)
    doc_bytes = await _download_drive_item_content(context, item_id=item_id, drive_id=drive_id)
    updated_doc_bytes = _append_text_to_docx(doc_bytes, text_content, author_name=author_name)
    _ensure_payload_under_limit(updated_doc_bytes)

    url = f"{_build_item_url(item_id=item_id, drive_id=drive_id)}/content"
    response = await _upload_drive_item_content(context, url, updated_doc_bytes, etag=etag)
    updated_item_id = response.get("id", item_id)

    updated_item = await _get_drive_item(context, item_id=updated_item_id, drive_id=drive_id)
    return {"item": cast(DriveItemData, serialize_drive_item(item=updated_item, drive_id=drive_id))}
