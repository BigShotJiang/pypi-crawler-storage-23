from typing import Annotated, Any, cast

import httpx
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_microsoft_utils.drive_utils import (
    _build_copy_payload,
    _get_copy_status_internal,
    _get_drive_item,
    _get_root_item_id,
    _handle_copy_server_error,
    _maybe_raise_locked_error,
    _normalize_copy_name,
    _poll_copy_operation,
)
from arcade_microsoft_utils.word_utils import _get_graph_base_url
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.drives.item.items.item.children.children_request_builder import (
    ChildrenRequestBuilder,
)

# SearchWithQRequestBuilder imports are now done locally to avoid type conflicts
from msgraph.generated.drives.item.root.root_request_builder import RootRequestBuilder
from msgraph.generated.models.drive_item import DriveItem
from msgraph.generated.models.folder import Folder
from msgraph.generated.models.item_reference import ItemReference

import arcade_sharepoint.common as common
from arcade_sharepoint.client import get_client
from arcade_sharepoint.serializers import serialize_drive_item
from arcade_sharepoint.tool_responses import (
    CopyItemResponse,
    CreateFolderResponse,
    CreateShareLinkResponse,
    DeleteItemResponse,
    DriveItemData,
    GetCopyStatusResponse,
    GetDrivesFromSiteResponse,
    ListDriveItemsResponse,
    MoveItemResponse,
)


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_drives_from_site(
    context: Context,
    site: Annotated[
        str,
        "Site ID, SharePoint URL, or site name to get drives from. "
        "Prefer using a site ID whenever available for optimal performance.",
    ],
) -> Annotated[GetDrivesFromSiteResponse, "The drives from the SharePoint site."]:
    """Retrieve drives / document libraries from a SharePoint site.

    If you have a site name, it is not necessary to call Sharepoint.SearchSites first. You can simply
    call this tool with the site name / keywords.
    """
    site_data = await common.get_site(context=context, site=site, include_drives=True)
    drives = site_data.get("drives", [])
    return {"drives": drives, "count": len(drives)}


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def list_root_items_in_drive(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive to get items from."],
    limit: Annotated[int, "The number of items to get. Defaults to 100, max is 500."] = 100,
    offset: Annotated[int, "The number of items to skip."] = 0,
) -> Annotated[ListDriveItemsResponse, "The items from the root of a drive in a SharePoint site."]:
    """Retrieve items from the root of a drive in a SharePoint site.

    Note: Due to how the Microsoft Graph API is designed, we have to retrieve all items, including the ones
    skipped by offset. For this reason, the tool execution time tends to increase with the offset value.
    """
    limit = max(1, min(limit, 500))
    offset = max(0, offset)

    client = get_client(context.get_auth_token_or_empty())

    request_configuration = RequestConfiguration(
        query_parameters=RootRequestBuilder.RootRequestBuilderGetQueryParameters(
            expand=["children"],
        ),
    )

    response = await client.drives.by_drive_id(drive_id).root.get(request_configuration)

    if not response or not response.children:
        return {"items": [], "count": 0}

    items = [
        serialize_drive_item(item=item, drive_id=drive_id)
        for item in response.children[offset : offset + limit]
    ]

    return cast(
        ListDriveItemsResponse,
        {
            "items": items,
            "count": len(items),
            "pagination": {
                "limit": limit,
                "current_offset": offset,
                "next_offset": offset + limit
                if response.children and len(response.children) > offset + limit
                else None,
                "more_items_available": response.children is not None
                and len(response.children) > offset + limit,
            },
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def list_items_in_folder(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive to get items from."],
    folder_id: Annotated[str, "The ID of the folder to get items from."],
    limit: Annotated[int, "The number of items to get. Defaults to 100, max is 500."] = 100,
    offset: Annotated[int, "The number of items to skip."] = 0,
) -> Annotated[ListDriveItemsResponse, "The items from the folder in the drive."]:
    """Retrieve items from a folder in a drive in a SharePoint site.

    Note: Due to how the Microsoft Graph API is designed, we have to retrieve all items, including the ones
    skipped by offset. For this reason, the tool execution time tends to increase with the offset value.
    """
    limit = max(1, min(limit, 500))
    offset = max(0, offset)
    client = get_client(context.get_auth_token_or_empty())

    request_configuration = RequestConfiguration(
        query_parameters=ChildrenRequestBuilder.ChildrenRequestBuilderGetQueryParameters(
            top=limit + offset,
        ),
    )

    response = (
        await client.drives.by_drive_id(drive_id)
        .items.by_drive_item_id(folder_id)
        .children.get(request_configuration)
    )

    if not response or not response.value:
        return {"items": [], "count": 0}

    item_objects = response.value[offset : offset + limit]

    items = [
        serialize_drive_item(item=item, drive_id=drive_id, parent_folder_id=folder_id)
        for item in item_objects
    ]

    return cast(
        ListDriveItemsResponse,
        {
            "items": items,
            "count": len(items),
            "pagination": {
                "limit": limit,
                "current_offset": offset,
                "next_offset": offset + limit
                if response and response.odata_next_link is not None
                else None,
                "more_items_available": response is not None
                and response.odata_next_link is not None,
            },
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def search_drive_items(
    context: Context,
    keywords: Annotated[str, "The keywords to search for files in the drive."],
    drive_id: Annotated[
        str | None,
        "Optionally, the ID of the drive to search items in. "
        "If not provided, the search will be performed in all drives.",
    ] = None,
    folder_id: Annotated[
        str | None,
        "Optionally narrow the search within a specific folder by its ID. "
        "If not provided, the search will be performed in the whole drive. "
        "If a folder_id is provided, it is required to provide a drive_id as well.",
    ] = None,
    limit: Annotated[int, "The number of files to get. Defaults to 50, max is 500."] = 50,
    offset: Annotated[int, "The number of files to skip."] = 0,
) -> Annotated[ListDriveItemsResponse, "The items from the drive(s)."]:
    """Search for items in one or more Sharepoint drives.

    Note: when searching within a single Drive and/or Folder, due to how the Microsoft Graph API is designed,
    we have to retrieve all items, including the ones skipped by offset. For this reason, the tool execution
    time tends to increase with the offset value.
    """
    limit = min(50, max(1, limit))
    offset = max(0, offset)

    if not drive_id:
        if folder_id:
            raise ToolExecutionError(
                "In order to filter by folder_id, it is required to provide a drive_id as well."
            )

        return cast(
            ListDriveItemsResponse,
            await common.search_items_in_all_drives(
                context=context,
                keywords=keywords,
                limit=limit,
                offset=offset,
            ),
        )

    client = get_client(context.get_auth_token_or_empty())

    # Import response types for union typing
    from msgraph.generated.drives.item.items.item.search_with_q.search_with_q_get_response import (
        SearchWithQGetResponse as FolderSearchResponse,
    )
    from msgraph.generated.drives.item.search_with_q.search_with_q_get_response import (
        SearchWithQGetResponse as DriveSearchResponse,
    )

    response: DriveSearchResponse | FolderSearchResponse | None = None

    if folder_id:
        # Use the folder-specific search endpoint
        from msgraph.generated.drives.item.items.item.search_with_q.search_with_q_request_builder import (
            SearchWithQRequestBuilder as FolderSearchBuilder,
        )

        folder_request_configuration = RequestConfiguration(
            query_parameters=FolderSearchBuilder.SearchWithQRequestBuilderGetQueryParameters(
                top=limit + offset,
            ),
        )
        response = (
            await client.drives.by_drive_id(drive_id)
            .items.by_drive_item_id(folder_id)
            .search_with_q(keywords)
            .get(folder_request_configuration)
        )

    else:
        # Use the drive-level search endpoint
        from msgraph.generated.drives.item.search_with_q.search_with_q_request_builder import (
            SearchWithQRequestBuilder as DriveSearchBuilder,
        )

        drive_request_configuration = RequestConfiguration(
            query_parameters=DriveSearchBuilder.SearchWithQRequestBuilderGetQueryParameters(
                top=limit + offset,
            ),
        )
        response = (
            await client.drives.by_drive_id(drive_id)
            .search_with_q(keywords)
            .get(drive_request_configuration)
        )

    if not response or not response.value:
        return {"count": 0, "items": []}

    items = [
        serialize_drive_item(item=item, drive_id=drive_id, parent_folder_id=folder_id)
        for item in response.value[offset : offset + limit]
    ]

    return cast(
        ListDriveItemsResponse,
        {
            "count": len(items),
            "items": items,
            "pagination": {
                "limit": limit,
                "current_offset": offset,
                "next_offset": offset + limit
                if response and response.odata_next_link is not None
                else None,
                "more_items_available": response is not None
                and response.odata_next_link is not None,
            },
        },
    )


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_folder(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the folder will be created."],
    folder_name: Annotated[str, "The name of the new folder."],
    parent_folder_id: Annotated[
        str | None, "Optional parent folder ID. If omitted, creates in the drive root."
    ] = None,
) -> Annotated[CreateFolderResponse, "The created folder metadata."]:
    """Create a new folder in a SharePoint drive."""
    drive_id = drive_id.strip()
    folder_name = folder_name.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not folder_name:
        raise ToolExecutionError("folder_name is required.")

    drive_item = DriveItem()
    drive_item.name = folder_name
    drive_item.folder = Folder()

    client = get_client(context.get_auth_token_or_empty())
    if parent_folder_id:
        parent_folder_id = parent_folder_id.strip()
        if not parent_folder_id:
            raise ToolExecutionError("parent_folder_id must be a non-empty string.")
        destination_id = parent_folder_id
    else:
        destination_id = await _get_root_item_id(client, drive_id)

    response = (
        await client.drives.by_drive_id(drive_id)
        .items.by_drive_item_id(destination_id)
        .children.post(drive_item)
    )
    if not response:
        raise ToolExecutionError("Failed to create folder. No DriveItem returned.")
    return {
        "item": cast(
            DriveItemData,
            serialize_drive_item(response, drive_id=drive_id, parent_folder_id=parent_folder_id),
        ),
        "message": "Folder successfully created.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def delete_item(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the item lives."],
    item_id: Annotated[str, "The ID of the file or folder to delete."],
) -> Annotated[DeleteItemResponse, "Deletion confirmation."]:
    """Delete a file or folder from a SharePoint drive."""
    drive_id = drive_id.strip()
    item_id = item_id.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    client = get_client(context.get_auth_token_or_empty())
    await client.drives.by_drive_id(drive_id).items.by_drive_item_id(item_id).delete()
    return {"status": "deleted", "message": "Item successfully deleted."}


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def move_item(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the item lives."],
    item_id: Annotated[str, "The ID of the item to move."],
    new_parent_id: Annotated[str, "The ID of the destination folder."],
) -> Annotated[MoveItemResponse, "The updated item metadata."]:
    """Move a file or folder to a new location in a SharePoint drive."""
    drive_id = drive_id.strip()
    item_id = item_id.strip()
    new_parent_id = new_parent_id.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not item_id:
        raise ToolExecutionError("item_id is required.")
    if not new_parent_id:
        raise ToolExecutionError("new_parent_id is required.")

    drive_item = DriveItem()
    drive_item.parent_reference = ItemReference()
    drive_item.parent_reference.id = new_parent_id

    client = get_client(context.get_auth_token_or_empty())
    try:
        response = (
            await client.drives.by_drive_id(drive_id)
            .items.by_drive_item_id(item_id)
            .patch(drive_item)
        )
    except Exception as exc:
        _maybe_raise_locked_error(exc)
        raise
    if not response:
        raise ToolExecutionError("Failed to move item. No DriveItem returned.")
    return {
        "item": cast(
            DriveItemData,
            serialize_drive_item(response, drive_id=drive_id, parent_folder_id=new_parent_id),
        ),
        "message": "Item successfully moved.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def copy_item(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the item lives."],
    item_id: Annotated[str, "The ID of the item to copy."],
    destination_folder_id: Annotated[
        str | None,
        "Optional destination folder ID. If omitted, the item is copied to the same folder.",
    ] = None,
    new_name: Annotated[str | None, "Optional new name for the copied item."] = None,
) -> Annotated[CopyItemResponse, "Copy status and result."]:
    """Copy a file or folder. Returns a completed item or an operation id."""
    drive_id = drive_id.strip()
    item_id = item_id.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    client = get_client(context.get_auth_token_or_empty())
    source_item = await _get_drive_item(client, drive_id, item_id)
    normalized_name = _normalize_copy_name(source_item, new_name)
    payload = _build_copy_payload(destination_folder_id, normalized_name)
    url = f"{_get_graph_base_url()}/drives/{drive_id}/items/{item_id}/copy"
    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
                "Content-Type": "application/json",
            },
            json=payload or None,
        )
        if response.status_code >= 500:
            await _handle_copy_server_error(
                client=client,
                drive_id=drive_id,
                source_item=source_item,
                destination_folder_id=destination_folder_id,
                normalized_name=normalized_name,
                response=response,
            )
        if response.status_code not in {202, 200}:
            response.raise_for_status()
        operation_url = response.headers.get("Location") or response.headers.get(
            "Operation-Location"
        )

    if not operation_url:
        raise ToolExecutionError("Copy operation did not return a monitor URL.")

    return cast(
        CopyItemResponse,
        await _poll_copy_operation(
            context=context,
            operation_url=operation_url,
            drive_id=drive_id,
            client=client,
            serialize_item=lambda item: serialize_drive_item(item, drive_id=drive_id),
        ),
    )


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_copy_status(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the copy operation runs."],
    operation_url: Annotated[
        str,
        "The full monitor URL returned by copy_item (Location/Operation-Location header). "
        "DO NOT PROVIDE ONLY THE OPERATION ID, BUT THE FULL URL.",
    ],
) -> Annotated[GetCopyStatusResponse, "Copy operation status."]:
    """Check status of an async copy operation using the full monitor URL."""
    drive_id = drive_id.strip()
    operation_url = operation_url.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not operation_url:
        raise ToolExecutionError("operation_url is required and must be the full monitor URL.")

    status, resource_id, error_message = await _get_copy_status_internal(context, operation_url)
    response: dict[str, Any] = {"status": status}

    if status == "completed" and resource_id:
        client = get_client(context.get_auth_token_or_empty())
        item = await client.drives.by_drive_id(drive_id).items.by_drive_item_id(resource_id).get()
        response["item"] = (
            serialize_drive_item(item, drive_id=drive_id) if item else {"item_id": resource_id}
        )
        response["message"] = "Copy operation completed."
    if status == "failed" and error_message:
        response["message"] = error_message

    return cast(GetCopyStatusResponse, response)


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_share_link(
    context: Context,
    drive_id: Annotated[str, "The ID of the drive where the item lives."],
    item_id: Annotated[str, "The ID of the file or folder to share."],
) -> Annotated[CreateShareLinkResponse, "Sharing link information."]:
    """Create a share link for a SharePoint drive item."""
    drive_id = drive_id.strip()
    item_id = item_id.strip()
    if not drive_id:
        raise ToolExecutionError("drive_id is required.")
    if not item_id:
        raise ToolExecutionError("item_id is required.")

    url = f"{_get_graph_base_url()}/drives/{drive_id}/items/{item_id}/createLink"
    async with httpx.AsyncClient() as http_client:
        response = await http_client.post(
            url,
            headers={
                "Authorization": f"Bearer {context.get_auth_token_or_empty()}",
                "Content-Type": "application/json",
            },
            json={"type": "view", "scope": "anonymous"},
        )
        response.raise_for_status()
    payload = response.json()
    if isinstance(payload, dict):
        payload.setdefault("message", "Share link created.")
        return cast(CreateShareLinkResponse, payload)
    return cast(CreateShareLinkResponse, {"link": payload, "message": "Share link created."})
