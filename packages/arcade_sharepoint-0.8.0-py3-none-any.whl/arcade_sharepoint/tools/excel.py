"""Excel workbook tools for SharePoint drives.

Mirrors the OneDrive Excel tools but requires drive_id and uses SharePoint scopes.
All tools use the same shared utilities from arcade_microsoft_utils.excel_utils.
"""

import logging
from typing import Annotated, Any, cast

import httpx
from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_microsoft_utils.excel_utils import (
    _build_batch_request,
    _build_drive_base_path,
    _build_workbook_worksheets_path,
    _build_xlsx_bytes,
    _cell_address,
    _col_index_to_letter,
    _col_letter_to_index,
    _compute_range_address,
    _create_excel_session,
    _ensure_xlsx_payload_under_limit,
    _execute_batch,
    _execute_with_session_retry,
    _get_batch_response,
    _graph_request,
    _is_last_worksheet_error,
    _list_worksheets,
    _normalize_xlsx_filename,
    _parse_range_address,
    _parse_sparse_dict,
    _range_response_to_sparse_dict,
    _resolve_worksheet_name_and_id,
    _sparse_dict_to_bounding_box_patch,
    _upload_xlsx_content,
)
from arcade_microsoft_utils.exceptions import (
    CannotDeleteLastWorksheetError,
    MicrosoftToolExecutionError,
)
from arcade_microsoft_utils.utils import human_friendly_bytes_size, remove_none_values
from arcade_microsoft_utils.word_utils import _require_non_empty

from arcade_sharepoint.client import get_client
from arcade_sharepoint.tool_responses import (
    AddWorksheetResponse,
    CreateWorkbookResponse,
    DeleteWorksheetResponse,
    ExcelPaginationInfo,
    ExcelRangeInfo,
    ExcelWorkbookItemData,
    ExcelWorksheetInfo,
    GetWorkbookMetadataResponse,
    GetWorksheetDataResponse,
    RenameWorksheetResponse,
    UpdateCellResponse,
    UpdateRangeResponse,
)

logger = logging.getLogger(__name__)


def _serialize_workbook_item(item: dict[str, Any]) -> ExcelWorkbookItemData:
    """Serialize a DriveItem dict into ExcelWorkbookItemData for SharePoint."""

    data: dict[str, Any] = {
        "object_type": "workbook",
        "item_id": item.get("id"),
        "name": item.get("name"),
    }

    parent_ref = item.get("parentReference")
    if parent_ref and parent_ref.get("id"):
        data["parent_folder_id"] = parent_ref["id"]

    size = item.get("size")
    if size is not None:
        data["size"] = {
            "bytes": size,
            "formatted": human_friendly_bytes_size(size),
        }

    if item.get("webUrl"):
        data["web_url"] = item["webUrl"]

    if item.get("eTag"):
        data["etag"] = item["eTag"]

    return cast(ExcelWorkbookItemData, remove_none_values(data))


def _serialize_worksheet(ws: dict[str, Any]) -> ExcelWorksheetInfo:
    """Serialize a worksheet dict from Graph API response."""
    return {
        "id": ws.get("id", ""),
        "name": ws.get("name", ""),
        "position": ws.get("position", 0),
        "visibility": ws.get("visibility", "Visible"),
    }


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def create_workbook(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive to create the workbook in."],
    filename: Annotated[
        str,
        "File name for the new workbook. The .xlsx extension is added automatically if not provided.",
    ],
    parent_folder_id: Annotated[
        str | None,
        "Parent folder ID. If omitted, the workbook is created in the root of the drive.",
    ] = None,
    initial_data: Annotated[
        str | None,
        "Optional JSON string for initial data in the first worksheet. "
        "Format: data[ROW][COL] = VALUE where ROW is a row number as string, "
        "COL is a column letter (uppercase), VALUE is string/number/boolean/null. "
        "Type: dict[str, dict[str, str | int | float | bool | None]].",
    ] = None,
) -> Annotated[CreateWorkbookResponse, "The created Excel workbook metadata with session ID."]:
    """Create a new Excel workbook (.xlsx) in a SharePoint drive.

    Only .xlsx files are supported.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    filename = _normalize_xlsx_filename(filename)
    token = context.get_auth_token_or_empty()

    xlsx_bytes = _build_xlsx_bytes(initial_data)
    _ensure_xlsx_payload_under_limit(xlsx_bytes)

    drive_base = _build_drive_base_path(drive_id)
    if parent_folder_id:
        upload_path = (
            f"{drive_base}/items/{parent_folder_id}:/{filename}:"
            f"/content?@microsoft.graph.conflictBehavior=fail"
        )
    else:
        upload_path = (
            f"{drive_base}/root:/{filename}:/content?@microsoft.graph.conflictBehavior=fail"
        )

    item_response = await _upload_xlsx_content(token, upload_path, xlsx_bytes, filename=filename)
    item_id = item_response.get("id", "")

    client = get_client(token)
    session_id = await _create_excel_session(client, item_id, drive_id)

    return {
        "item": _serialize_workbook_item(item_response),
        "session_id": session_id,
        "message": f"Workbook '{filename}' created successfully.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_workbook_metadata(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[GetWorkbookMetadataResponse, "Workbook metadata including worksheet list."]:
    """Get metadata about an Excel workbook in a SharePoint drive, including worksheet list."""
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    async def _fetch_metadata(sid: str) -> dict:
        drive_base = _build_drive_base_path(drive_id)
        requests = [
            _build_batch_request(
                request_id="drive_item",
                method="GET",
                url=f"{drive_base}/items/{item_id}",
            ),
            _build_batch_request(
                request_id="worksheets",
                method="GET",
                url=f"{drive_base}/items/{item_id}/workbook/worksheets",
                session_id=sid,
            ),
        ]
        responses = await _execute_batch(token, requests)
        drive_item_resp = _get_batch_response(responses, "drive_item")
        worksheets_resp = _get_batch_response(responses, "worksheets")

        if drive_item_resp.get("status") != 200:
            error = drive_item_resp.get("body", {}).get("error", {})
            raise MicrosoftToolExecutionError(
                f"Failed to get workbook metadata: {error.get('message', 'Unknown error')}"
            )
        if worksheets_resp.get("status") != 200:
            error = worksheets_resp.get("body", {}).get("error", {})
            raise MicrosoftToolExecutionError(
                f"Failed to list worksheets: {error.get('message', 'Unknown error')}"
            )
        return {
            "drive_item": drive_item_resp.get("body", {}),
            "worksheets": worksheets_resp.get("body", {}).get("value", []),
        }

    result, sid = await _execute_with_session_retry(
        client, item_id, session_id, drive_id, _fetch_metadata
    )

    drive_item = result["drive_item"]
    worksheets = [_serialize_worksheet(ws) for ws in result["worksheets"]]

    return {
        "item_id": item_id,
        "name": drive_item.get("name", ""),
        "web_url": drive_item.get("webUrl", ""),
        "worksheets": worksheets,
        "worksheet_count": len(worksheets),
        "session_id": sid,
    }


@tool(requires_auth=Microsoft(scopes=["Sites.Read.All"]))
async def get_worksheet_data(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[
        str | None,
        "Worksheet name to read from. If omitted, reads from the first worksheet.",
    ] = None,
    start_row: Annotated[int, "Starting row number (1-indexed). Defaults to 1."] = 1,
    start_col: Annotated[str, "Starting column letter. Defaults to A."] = "A",
    max_rows: Annotated[
        int,
        "Maximum rows to return. Defaults to 1000, maximum allowed is 1000.",
    ] = 1000,
    max_cols: Annotated[
        int,
        "Maximum columns to return. Defaults to 100, maximum allowed is 100.",
    ] = 100,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[GetWorksheetDataResponse, "Worksheet data in sparse dict format with pagination."]:
    """Read cell values from a worksheet in a SharePoint Excel workbook.

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    max_rows = min(max_rows, 1000)
    max_cols = min(max_cols, 100)

    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _fetch_data(sid: str) -> dict:
        drive_base = _build_drive_base_path(drive_id)
        ws_path = f"{drive_base}/items/{item_id}/workbook/worksheets/{ws_id}"
        range_address = _compute_range_address(start_col, start_row, max_cols, max_rows)

        requests = [
            _build_batch_request(
                request_id="range_data",
                method="GET",
                url=f"{ws_path}/range(address='{range_address}')",
                session_id=sid,
            ),
            _build_batch_request(
                request_id="used_range",
                method="GET",
                url=f"{ws_path}/usedRange",
                session_id=sid,
            ),
        ]

        responses = await _execute_batch(token, requests)
        range_resp = _get_batch_response(responses, "range_data")
        used_resp = _get_batch_response(responses, "used_range")

        if range_resp.get("status") != 200:
            error = range_resp.get("body", {}).get("error", {})
            raise MicrosoftToolExecutionError(
                f"Failed to read range data: {error.get('message', 'Unknown error')}"
            )

        # usedRange is best-effort: if it fails, degrade gracefully
        # by returning an empty body (pagination hints will be omitted)
        used_body = used_resp.get("body", {}) if used_resp.get("status") == 200 else {}

        return {
            "range_body": range_resp.get("body", {}),
            "used_body": used_body,
        }

    result, sid = await _execute_with_session_retry(
        client, item_id, session_id, drive_id, _fetch_data
    )

    range_body = result["range_body"]
    used_body = result["used_body"]

    range_address = range_body.get("address", "")
    actual_start_col, actual_start_row, actual_end_col, actual_end_row = _parse_range_address(
        range_address
    )

    data = _range_response_to_sparse_dict(range_body, actual_start_col, actual_start_row)

    used_address = used_body.get("address", "")
    if used_address and "!" in used_address:
        _, _, used_end_col_str, used_end_row = _parse_range_address(used_address)
        total_rows = used_end_row
        total_columns = _col_letter_to_index(used_end_col_str)
    else:
        total_rows = used_body.get("rowCount", 0)
        total_columns = used_body.get("columnCount", 0)

    pagination: ExcelPaginationInfo = {}
    actual_end_row_idx = actual_end_row
    actual_end_col_idx = _col_letter_to_index(actual_end_col)

    if actual_end_row_idx < total_rows:
        pagination["next_rows"] = {
            "start_row": actual_end_row_idx + 1,
            "start_col": start_col,
        }
    if actual_end_col_idx < total_columns:
        pagination["next_cols"] = {
            "start_row": start_row,
            "start_col": _col_index_to_letter(actual_end_col_idx + 1),
        }

    range_info: ExcelRangeInfo = {
        "start_row": actual_start_row,
        "start_col": actual_start_col,
        "end_row": actual_end_row,
        "end_col": actual_end_col,
    }

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "range": range_info,
        "total_rows": total_rows,
        "total_columns": total_columns,
        "pagination": pagination,
        "data": data,
        "session_id": sid,
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def update_cell(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    column: Annotated[str, "Column letter or letters (e.g., 'A', 'BC')."],
    row: Annotated[int, "Row number (1-indexed)."],
    value: Annotated[
        str,
        "The value to set. Supports strings, numbers, booleans, and formulas (e.g., '=SUM(A1:A10)').",
    ],
    worksheet: Annotated[
        str | None,
        "Worksheet name to update. If omitted, updates the first worksheet.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[UpdateCellResponse, "Confirmation of the cell update."]:
    """Update a single cell value in a SharePoint Excel workbook.

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    cell_addr = _cell_address(column, row)
    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_update(sid: str) -> None:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        await _graph_request(
            token,
            method="PATCH",
            path=f"{ws_path}/range(address='{cell_addr}')",
            session_id=sid,
            body={"formulas": [[value]]},
        )

    _, sid = await _execute_with_session_retry(client, item_id, session_id, drive_id, _do_update)

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "cell": cell_addr,
        "value": value,
        "session_id": sid,
        "message": f"Cell {cell_addr} updated to '{value}' in worksheet '{ws_name}'.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def update_range(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    data: Annotated[
        str,
        "JSON string where data[ROW][COL] = VALUE. "
        "ROW is a row number as string, COL is a column letter (uppercase), "
        "VALUE is string/number/boolean/null. "
        "Type: dict[str, dict[str, str | int | float | bool | None]].",
    ],
    worksheet: Annotated[
        str | None,
        "Worksheet name to update. If omitted, updates the first worksheet.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[UpdateRangeResponse, "Confirmation of the range update with cell count."]:
    """Update multiple cells in a SharePoint Excel worksheet using sparse dict format.

    Only specified cells are updated; unspecified cells remain unchanged.

    Internally, a single PATCH request is sent covering the bounding box
    of all specified cells.  Cells within the box that are not in the
    input are sent as ``null``, which the Graph API treats as "skip".

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    parsed_data = _parse_sparse_dict(data)
    if not parsed_data:
        raise MicrosoftToolExecutionError("No data provided to update.")

    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    ws_name, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    # Build a single bounding-box patch (null = skip unchanged cells)
    patch = _sparse_dict_to_bounding_box_patch(parsed_data)

    # Count actual cells being updated (non-null entries)
    cells_updated = sum(len(cols) for cols in parsed_data.values())

    async def _do_update(sid: str) -> None:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        await _graph_request(
            token,
            method="PATCH",
            path=f"{ws_path}/range(address='{patch.address}')",
            session_id=sid,
            body={"formulas": patch.formulas},
        )

    _, sid = await _execute_with_session_retry(client, item_id, session_id, drive_id, _do_update)

    return {
        "item_id": item_id,
        "worksheet": ws_name,
        "cells_updated": cells_updated,
        "session_id": sid,
        "message": f"Updated {cells_updated} cells in worksheet '{ws_name}'.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def add_worksheet(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    name: Annotated[
        str | None,
        "Name for the new worksheet. If omitted, Excel generates a default name.",
    ] = None,
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[AddWorksheetResponse, "The created worksheet info."]:
    """Add a new worksheet to a SharePoint Excel workbook.

    Note: The new worksheet name may not be immediately visible to other
    tools due to a brief Graph API propagation delay (up to ~10 s). Pass
    the returned ``session_id`` to subsequent calls that reference the new
    worksheet to mitigate this.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    async def _do_add(sid: str) -> dict[str, Any]:
        drive_base = _build_drive_base_path(drive_id)
        path = f"{drive_base}/items/{item_id}/workbook/worksheets/add"
        body: dict[str, Any] = {}
        if name:
            body["name"] = name
        resp = await _graph_request(token, "POST", path, session_id=sid, body=body)
        return dict(resp)

    result, sid = await _execute_with_session_retry(client, item_id, session_id, drive_id, _do_add)

    ws_info = _serialize_worksheet(result)

    return {
        "item_id": item_id,
        "worksheet": ws_info,
        "session_id": sid,
        "message": f"Worksheet '{ws_info['name']}' added to the workbook.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def rename_worksheet(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[str, "Current name of the worksheet to rename."],
    new_name: Annotated[str, "New name for the worksheet."],
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[RenameWorksheetResponse, "The renamed worksheet info."]:
    """Rename an existing worksheet in a SharePoint Excel workbook.

    Note: The new name may not be immediately visible to other tools due
    to a brief Graph API propagation delay (up to ~10 s). Pass the returned
    ``session_id`` to subsequent calls that reference the renamed worksheet
    to mitigate this. If referencing a recently added worksheet as the source,
    the same delay applies; retry with the ``session_id`` if a
    WorksheetNotFoundError occurs.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    previous_name = worksheet
    # Resolve worksheet before the session callback for simpler control flow.
    # Session-aware when session_id is provided (the typical agent pattern).
    _, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_rename(sid: str) -> dict[str, Any]:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        resp = await _graph_request(
            token, "PATCH", ws_path, session_id=sid, body={"name": new_name}
        )
        return dict(resp)

    result, sid = await _execute_with_session_retry(
        client, item_id, session_id, drive_id, _do_rename
    )

    ws_info = _serialize_worksheet(result)

    return {
        "item_id": item_id,
        "worksheet": ws_info,
        "previous_name": previous_name,
        "session_id": sid,
        "message": f"Worksheet renamed from '{previous_name}' to '{new_name}'.",
    }


@tool(requires_auth=Microsoft(scopes=["Sites.ReadWrite.All"]))
async def delete_worksheet(
    context: Context,
    drive_id: Annotated[str, "The ID of the SharePoint drive containing the workbook."],
    item_id: Annotated[str, "The ID of the Excel workbook."],
    worksheet: Annotated[str, "Name of the worksheet to delete."],
    session_id: Annotated[
        str | None,
        "Optional session ID from a previous operation for better performance.",
    ] = None,
) -> Annotated[DeleteWorksheetResponse, "Confirmation of the worksheet deletion."]:
    """Delete a worksheet from a SharePoint Excel workbook.

    Cannot delete the last worksheet in a workbook.

    Note: If referencing a recently added or renamed worksheet, pass the
    ``session_id`` from that operation. A brief Graph API propagation delay
    (up to ~10 s) may cause a WorksheetNotFoundError; retry with the
    ``session_id`` if this occurs.
    """
    drive_id = _require_non_empty(drive_id, "drive_id")
    item_id = _require_non_empty(item_id, "item_id")
    token = context.get_auth_token_or_empty()
    client = get_client(token)

    # Session-aware worksheet listing for accurate count check
    ws_items = await _list_worksheets(token, item_id, drive_id, session_id)
    if len(ws_items) <= 1:
        raise CannotDeleteLastWorksheetError()

    _, ws_id = await _resolve_worksheet_name_and_id(
        client, item_id, worksheet, drive_id, token=token, session_id=session_id
    )

    async def _do_delete(sid: str) -> dict[str, Any]:
        ws_path = _build_workbook_worksheets_path(item_id, ws_id, drive_id)
        resp = await _graph_request(token, "DELETE", ws_path, session_id=sid)
        return dict(resp)

    try:
        _, sid = await _execute_with_session_retry(
            client, item_id, session_id, drive_id, _do_delete
        )
    except httpx.HTTPStatusError as exc:
        if _is_last_worksheet_error(exc):
            logger.warning("delete_worksheet got last-worksheet 400: %s", exc.response.text)
            raise CannotDeleteLastWorksheetError() from exc
        raise

    return {
        "item_id": item_id,
        "deleted_worksheet": worksheet,
        "session_id": sid,
        "message": f"Worksheet '{worksheet}' deleted from the workbook.",
    }
