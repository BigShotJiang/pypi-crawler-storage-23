# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from datetime import datetime
from typing_extensions import Literal, TypeAlias

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = [
    "SubscriptionProvisionResponse",
    "Data",
    "DataEntitlement",
    "DataEntitlementUnionObjectVariant0",
    "DataEntitlementUnionObjectVariant0Feature",
    "DataEntitlementUnionObjectVariant1",
    "DataEntitlementUnionObjectVariant1Currency",
    "DataSubscription",
    "DataSubscriptionAddon",
    "DataSubscriptionBudget",
    "DataSubscriptionCoupon",
    "DataSubscriptionCouponAmountsOff",
    "DataSubscriptionFutureUpdate",
    "DataSubscriptionFutureUpdateTargetPackage",
    "DataSubscriptionLatestInvoice",
    "DataSubscriptionMinimumSpend",
    "DataSubscriptionPrice",
    "DataSubscriptionPriceTier",
    "DataSubscriptionPriceTierFlatPrice",
    "DataSubscriptionPriceTierUnitPrice",
    "DataSubscriptionSubscriptionEntitlement",
    "DataSubscriptionTrial",
]


class DataEntitlementUnionObjectVariant0Feature(BaseModel):
    display_name: str = FieldInfo(alias="displayName")
    """The human-readable name of the entitlement, shown in UI elements."""

    feature_status: Literal["NEW", "SUSPENDED", "ACTIVE"] = FieldInfo(alias="featureStatus")
    """The current status of the feature."""

    feature_type: Literal["BOOLEAN", "NUMBER", "ENUM"] = FieldInfo(alias="featureType")
    """The type of feature associated with the entitlement."""

    ref_id: str = FieldInfo(alias="refId")
    """The unique reference ID of the entitlement."""


class DataEntitlementUnionObjectVariant0(BaseModel):
    access_denied_reason: Optional[
        Literal[
            "FeatureNotFound",
            "CustomerNotFound",
            "CustomerIsArchived",
            "CustomerResourceNotFound",
            "NoActiveSubscription",
            "NoFeatureEntitlementInSubscription",
            "RequestedUsageExceedingLimit",
            "RequestedValuesMismatch",
            "BudgetExceeded",
            "Unknown",
            "FeatureTypeMismatch",
            "Revoked",
            "InsufficientCredits",
            "EntitlementNotFound",
        ]
    ] = FieldInfo(alias="accessDeniedReason", default=None)

    is_granted: bool = FieldInfo(alias="isGranted")

    type: Literal["FEATURE"]

    current_usage: Optional[float] = FieldInfo(alias="currentUsage", default=None)

    entitlement_updated_at: Optional[datetime] = FieldInfo(alias="entitlementUpdatedAt", default=None)
    """Timestamp of the last update to the entitlement grant or configuration."""

    feature: Optional[DataEntitlementUnionObjectVariant0Feature] = None

    has_unlimited_usage: Optional[bool] = FieldInfo(alias="hasUnlimitedUsage", default=None)

    reset_period: Optional[Literal["YEAR", "MONTH", "WEEK", "DAY", "HOUR"]] = FieldInfo(
        alias="resetPeriod", default=None
    )

    usage_limit: Optional[float] = FieldInfo(alias="usageLimit", default=None)

    usage_period_anchor: Optional[datetime] = FieldInfo(alias="usagePeriodAnchor", default=None)
    """
    The anchor for calculating the usage period for metered entitlements with a
    reset period configured
    """

    usage_period_end: Optional[datetime] = FieldInfo(alias="usagePeriodEnd", default=None)
    """
    The end date of the usage period for metered entitlements with a reset period
    configured
    """

    usage_period_start: Optional[datetime] = FieldInfo(alias="usagePeriodStart", default=None)
    """
    The start date of the usage period for metered entitlements with a reset period
    configured
    """

    valid_until: Optional[datetime] = FieldInfo(alias="validUntil", default=None)
    """The next time the entitlement should be recalculated"""


class DataEntitlementUnionObjectVariant1Currency(BaseModel):
    """The currency associated with a credit entitlement."""

    currency_id: str = FieldInfo(alias="currencyId")
    """The unique identifier of the custom currency."""

    display_name: str = FieldInfo(alias="displayName")
    """The display name of the currency."""

    additional_meta_data: Optional[object] = FieldInfo(alias="additionalMetaData", default=None)
    """Additional metadata associated with the currency."""

    description: Optional[str] = None
    """A description of the currency."""

    unit_plural: Optional[str] = FieldInfo(alias="unitPlural", default=None)
    """The plural form of the currency unit."""

    unit_singular: Optional[str] = FieldInfo(alias="unitSingular", default=None)
    """The singular form of the currency unit."""


class DataEntitlementUnionObjectVariant1(BaseModel):
    access_denied_reason: Optional[
        Literal[
            "FeatureNotFound",
            "CustomerNotFound",
            "CustomerIsArchived",
            "CustomerResourceNotFound",
            "NoActiveSubscription",
            "NoFeatureEntitlementInSubscription",
            "RequestedUsageExceedingLimit",
            "RequestedValuesMismatch",
            "BudgetExceeded",
            "Unknown",
            "FeatureTypeMismatch",
            "Revoked",
            "InsufficientCredits",
            "EntitlementNotFound",
        ]
    ] = FieldInfo(alias="accessDeniedReason", default=None)

    currency: DataEntitlementUnionObjectVariant1Currency
    """The currency associated with a credit entitlement."""

    current_usage: float = FieldInfo(alias="currentUsage")

    is_granted: bool = FieldInfo(alias="isGranted")

    type: Literal["CREDIT"]

    usage_limit: float = FieldInfo(alias="usageLimit")

    usage_updated_at: datetime = FieldInfo(alias="usageUpdatedAt")
    """Timestamp of the last update to the credit usage."""

    entitlement_updated_at: Optional[datetime] = FieldInfo(alias="entitlementUpdatedAt", default=None)
    """Timestamp of the last update to the entitlement grant or configuration."""

    usage_period_end: Optional[datetime] = FieldInfo(alias="usagePeriodEnd", default=None)
    """The end date of the current billing period for recurring credit grants."""

    valid_until: Optional[datetime] = FieldInfo(alias="validUntil", default=None)
    """The next time the entitlement should be recalculated"""


DataEntitlement: TypeAlias = Union[DataEntitlementUnionObjectVariant0, DataEntitlementUnionObjectVariant1]


class DataSubscriptionAddon(BaseModel):
    """Addon configuration"""

    id: str
    """Addon ID"""

    quantity: int
    """Number of addon instances"""


class DataSubscriptionBudget(BaseModel):
    """Budget configuration"""

    has_soft_limit: bool = FieldInfo(alias="hasSoftLimit")
    """Whether the budget is a soft limit"""

    limit: float
    """Maximum spending limit"""


class DataSubscriptionCouponAmountsOff(BaseModel):
    amount: Optional[float] = None
    """The price amount"""

    currency: Optional[
        Literal[
            "usd",
            "aed",
            "all",
            "amd",
            "ang",
            "aud",
            "awg",
            "azn",
            "bam",
            "bbd",
            "bdt",
            "bgn",
            "bif",
            "bmd",
            "bnd",
            "bsd",
            "bwp",
            "byn",
            "bzd",
            "brl",
            "cad",
            "cdf",
            "chf",
            "cny",
            "czk",
            "dkk",
            "dop",
            "dzd",
            "egp",
            "etb",
            "eur",
            "fjd",
            "gbp",
            "gel",
            "gip",
            "gmd",
            "gyd",
            "hkd",
            "hrk",
            "htg",
            "idr",
            "ils",
            "inr",
            "isk",
            "jmd",
            "jpy",
            "kes",
            "kgs",
            "khr",
            "kmf",
            "krw",
            "kyd",
            "kzt",
            "lbp",
            "lkr",
            "lrd",
            "lsl",
            "mad",
            "mdl",
            "mga",
            "mkd",
            "mmk",
            "mnt",
            "mop",
            "mro",
            "mvr",
            "mwk",
            "mxn",
            "myr",
            "mzn",
            "nad",
            "ngn",
            "nok",
            "npr",
            "nzd",
            "pgk",
            "php",
            "pkr",
            "pln",
            "qar",
            "ron",
            "rsd",
            "rub",
            "rwf",
            "sar",
            "sbd",
            "scr",
            "sek",
            "sgd",
            "sle",
            "sll",
            "sos",
            "szl",
            "thb",
            "tjs",
            "top",
            "try",
            "ttd",
            "tzs",
            "uah",
            "uzs",
            "vnd",
            "vuv",
            "wst",
            "xaf",
            "xcd",
            "yer",
            "zar",
            "zmw",
            "clp",
            "djf",
            "gnf",
            "ugx",
            "pyg",
            "xof",
            "xpf",
        ]
    ] = None
    """The price currency"""


class DataSubscriptionCoupon(BaseModel):
    """Coupon applied to a subscription"""

    id: str
    """Coupon ID"""

    name: str
    """Coupon name"""

    status: Literal["ACTIVE", "EXPIRED", "REMOVED"]
    """Coupon status"""

    amounts_off: Optional[List[DataSubscriptionCouponAmountsOff]] = FieldInfo(alias="amountsOff", default=None)
    """Fixed amount discounts by currency"""

    percent_off: Optional[float] = FieldInfo(alias="percentOff", default=None)
    """Percentage discount"""


class DataSubscriptionFutureUpdateTargetPackage(BaseModel):
    """Target package for the update"""

    id: str
    """Target package for the update"""


class DataSubscriptionFutureUpdate(BaseModel):
    """Scheduled subscription update"""

    scheduled_execution_time: datetime = FieldInfo(alias="scheduledExecutionTime")
    """Scheduled execution time"""

    schedule_status: Literal["PENDING_PAYMENT", "SCHEDULED", "CANCELED", "DONE", "FAILED"] = FieldInfo(
        alias="scheduleStatus"
    )
    """Status of the scheduled update"""

    subscription_schedule_type: Literal[
        "DOWNGRADE",
        "PLAN",
        "BILLING_PERIOD",
        "UNIT_AMOUNT",
        "RECURRING_CREDITS",
        "PRICE_OVERRIDE",
        "ADDON",
        "COUPON",
        "MIGRATE_TO_LATEST",
        "ADDITIONAL_META_DATA",
        "BILLING_INFO_METADATA",
    ] = FieldInfo(alias="subscriptionScheduleType")
    """Type of scheduled change"""

    target_package: Optional[DataSubscriptionFutureUpdateTargetPackage] = FieldInfo(alias="targetPackage", default=None)
    """Target package for the update"""


class DataSubscriptionLatestInvoice(BaseModel):
    """Latest invoice for the subscription"""

    billing_id: str = FieldInfo(alias="billingId")
    """Invoice billing ID"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Invoice creation date"""

    requires_action: bool = FieldInfo(alias="requiresAction")
    """Whether payment requires action"""

    status: Literal["OPEN", "CANCELED", "PAID"]
    """Invoice status"""

    amount_due: Optional[float] = FieldInfo(alias="amountDue", default=None)
    """Amount due"""

    billing_reason: Optional[
        Literal[
            "BILLING_CYCLE",
            "SUBSCRIPTION_CREATION",
            "SUBSCRIPTION_UPDATE",
            "MANUAL",
            "MINIMUM_INVOICE_AMOUNT_EXCEEDED",
            "OTHER",
        ]
    ] = FieldInfo(alias="billingReason", default=None)
    """Billing reason"""

    currency: Optional[str] = None
    """Invoice currency"""

    pdf_url: Optional[str] = FieldInfo(alias="pdfUrl", default=None)
    """Invoice PDF URL"""

    total: Optional[float] = None
    """Total amount"""


class DataSubscriptionMinimumSpend(BaseModel):
    """Minimum spend configuration"""

    amount: Optional[float] = None
    """The price amount"""

    currency: Optional[
        Literal[
            "usd",
            "aed",
            "all",
            "amd",
            "ang",
            "aud",
            "awg",
            "azn",
            "bam",
            "bbd",
            "bdt",
            "bgn",
            "bif",
            "bmd",
            "bnd",
            "bsd",
            "bwp",
            "byn",
            "bzd",
            "brl",
            "cad",
            "cdf",
            "chf",
            "cny",
            "czk",
            "dkk",
            "dop",
            "dzd",
            "egp",
            "etb",
            "eur",
            "fjd",
            "gbp",
            "gel",
            "gip",
            "gmd",
            "gyd",
            "hkd",
            "hrk",
            "htg",
            "idr",
            "ils",
            "inr",
            "isk",
            "jmd",
            "jpy",
            "kes",
            "kgs",
            "khr",
            "kmf",
            "krw",
            "kyd",
            "kzt",
            "lbp",
            "lkr",
            "lrd",
            "lsl",
            "mad",
            "mdl",
            "mga",
            "mkd",
            "mmk",
            "mnt",
            "mop",
            "mro",
            "mvr",
            "mwk",
            "mxn",
            "myr",
            "mzn",
            "nad",
            "ngn",
            "nok",
            "npr",
            "nzd",
            "pgk",
            "php",
            "pkr",
            "pln",
            "qar",
            "ron",
            "rsd",
            "rub",
            "rwf",
            "sar",
            "sbd",
            "scr",
            "sek",
            "sgd",
            "sle",
            "sll",
            "sos",
            "szl",
            "thb",
            "tjs",
            "top",
            "try",
            "ttd",
            "tzs",
            "uah",
            "uzs",
            "vnd",
            "vuv",
            "wst",
            "xaf",
            "xcd",
            "yer",
            "zar",
            "zmw",
            "clp",
            "djf",
            "gnf",
            "ugx",
            "pyg",
            "xof",
            "xpf",
        ]
    ] = None
    """The price currency"""


class DataSubscriptionPriceTierFlatPrice(BaseModel):
    """The flat fee price of the price tier"""

    amount: float
    """The price amount"""

    currency: Literal[
        "usd",
        "aed",
        "all",
        "amd",
        "ang",
        "aud",
        "awg",
        "azn",
        "bam",
        "bbd",
        "bdt",
        "bgn",
        "bif",
        "bmd",
        "bnd",
        "bsd",
        "bwp",
        "byn",
        "bzd",
        "brl",
        "cad",
        "cdf",
        "chf",
        "cny",
        "czk",
        "dkk",
        "dop",
        "dzd",
        "egp",
        "etb",
        "eur",
        "fjd",
        "gbp",
        "gel",
        "gip",
        "gmd",
        "gyd",
        "hkd",
        "hrk",
        "htg",
        "idr",
        "ils",
        "inr",
        "isk",
        "jmd",
        "jpy",
        "kes",
        "kgs",
        "khr",
        "kmf",
        "krw",
        "kyd",
        "kzt",
        "lbp",
        "lkr",
        "lrd",
        "lsl",
        "mad",
        "mdl",
        "mga",
        "mkd",
        "mmk",
        "mnt",
        "mop",
        "mro",
        "mvr",
        "mwk",
        "mxn",
        "myr",
        "mzn",
        "nad",
        "ngn",
        "nok",
        "npr",
        "nzd",
        "pgk",
        "php",
        "pkr",
        "pln",
        "qar",
        "ron",
        "rsd",
        "rub",
        "rwf",
        "sar",
        "sbd",
        "scr",
        "sek",
        "sgd",
        "sle",
        "sll",
        "sos",
        "szl",
        "thb",
        "tjs",
        "top",
        "try",
        "ttd",
        "tzs",
        "uah",
        "uzs",
        "vnd",
        "vuv",
        "wst",
        "xaf",
        "xcd",
        "yer",
        "zar",
        "zmw",
        "clp",
        "djf",
        "gnf",
        "ugx",
        "pyg",
        "xof",
        "xpf",
    ]
    """The price currency"""


class DataSubscriptionPriceTierUnitPrice(BaseModel):
    """The unit price of the price tier"""

    amount: float
    """The price amount"""

    currency: Literal[
        "usd",
        "aed",
        "all",
        "amd",
        "ang",
        "aud",
        "awg",
        "azn",
        "bam",
        "bbd",
        "bdt",
        "bgn",
        "bif",
        "bmd",
        "bnd",
        "bsd",
        "bwp",
        "byn",
        "bzd",
        "brl",
        "cad",
        "cdf",
        "chf",
        "cny",
        "czk",
        "dkk",
        "dop",
        "dzd",
        "egp",
        "etb",
        "eur",
        "fjd",
        "gbp",
        "gel",
        "gip",
        "gmd",
        "gyd",
        "hkd",
        "hrk",
        "htg",
        "idr",
        "ils",
        "inr",
        "isk",
        "jmd",
        "jpy",
        "kes",
        "kgs",
        "khr",
        "kmf",
        "krw",
        "kyd",
        "kzt",
        "lbp",
        "lkr",
        "lrd",
        "lsl",
        "mad",
        "mdl",
        "mga",
        "mkd",
        "mmk",
        "mnt",
        "mop",
        "mro",
        "mvr",
        "mwk",
        "mxn",
        "myr",
        "mzn",
        "nad",
        "ngn",
        "nok",
        "npr",
        "nzd",
        "pgk",
        "php",
        "pkr",
        "pln",
        "qar",
        "ron",
        "rsd",
        "rub",
        "rwf",
        "sar",
        "sbd",
        "scr",
        "sek",
        "sgd",
        "sle",
        "sll",
        "sos",
        "szl",
        "thb",
        "tjs",
        "top",
        "try",
        "ttd",
        "tzs",
        "uah",
        "uzs",
        "vnd",
        "vuv",
        "wst",
        "xaf",
        "xcd",
        "yer",
        "zar",
        "zmw",
        "clp",
        "djf",
        "gnf",
        "ugx",
        "pyg",
        "xof",
        "xpf",
    ]
    """The price currency"""


class DataSubscriptionPriceTier(BaseModel):
    flat_price: Optional[DataSubscriptionPriceTierFlatPrice] = FieldInfo(alias="flatPrice", default=None)
    """The flat fee price of the price tier"""

    unit_price: Optional[DataSubscriptionPriceTierUnitPrice] = FieldInfo(alias="unitPrice", default=None)
    """The unit price of the price tier"""

    up_to: Optional[float] = FieldInfo(alias="upTo", default=None)
    """The up to quantity of the price tier"""


class DataSubscriptionPrice(BaseModel):
    addon_id: Optional[str] = FieldInfo(alias="addonId", default=None)
    """Addon identifier for the price override"""

    amount: Optional[float] = None
    """The price amount"""

    base_charge: Optional[bool] = FieldInfo(alias="baseCharge", default=None)
    """Whether this is a base charge override"""

    billing_country_code: Optional[str] = FieldInfo(alias="billingCountryCode", default=None)
    """The billing country code of the price"""

    block_size: Optional[float] = FieldInfo(alias="blockSize", default=None)
    """Block size for pricing"""

    currency: Optional[
        Literal[
            "usd",
            "aed",
            "all",
            "amd",
            "ang",
            "aud",
            "awg",
            "azn",
            "bam",
            "bbd",
            "bdt",
            "bgn",
            "bif",
            "bmd",
            "bnd",
            "bsd",
            "bwp",
            "byn",
            "bzd",
            "brl",
            "cad",
            "cdf",
            "chf",
            "cny",
            "czk",
            "dkk",
            "dop",
            "dzd",
            "egp",
            "etb",
            "eur",
            "fjd",
            "gbp",
            "gel",
            "gip",
            "gmd",
            "gyd",
            "hkd",
            "hrk",
            "htg",
            "idr",
            "ils",
            "inr",
            "isk",
            "jmd",
            "jpy",
            "kes",
            "kgs",
            "khr",
            "kmf",
            "krw",
            "kyd",
            "kzt",
            "lbp",
            "lkr",
            "lrd",
            "lsl",
            "mad",
            "mdl",
            "mga",
            "mkd",
            "mmk",
            "mnt",
            "mop",
            "mro",
            "mvr",
            "mwk",
            "mxn",
            "myr",
            "mzn",
            "nad",
            "ngn",
            "nok",
            "npr",
            "nzd",
            "pgk",
            "php",
            "pkr",
            "pln",
            "qar",
            "ron",
            "rsd",
            "rub",
            "rwf",
            "sar",
            "sbd",
            "scr",
            "sek",
            "sgd",
            "sle",
            "sll",
            "sos",
            "szl",
            "thb",
            "tjs",
            "top",
            "try",
            "ttd",
            "tzs",
            "uah",
            "uzs",
            "vnd",
            "vuv",
            "wst",
            "xaf",
            "xcd",
            "yer",
            "zar",
            "zmw",
            "clp",
            "djf",
            "gnf",
            "ugx",
            "pyg",
            "xof",
            "xpf",
        ]
    ] = None
    """The price currency"""

    feature_id: Optional[str] = FieldInfo(alias="featureId", default=None)
    """Feature identifier for the price override"""

    tiers: Optional[List[DataSubscriptionPriceTier]] = None
    """Pricing tiers configuration"""


class DataSubscriptionSubscriptionEntitlement(BaseModel):
    """Subscription entitlement reference"""

    id: str
    """Feature ID or currency ID"""

    type: Literal["FEATURE", "CREDIT"]
    """Entitlement type (FEATURE or CREDIT)"""


class DataSubscriptionTrial(BaseModel):
    """Trial configuration"""

    trial_end_behavior: Literal["CONVERT_TO_PAID", "CANCEL_SUBSCRIPTION"] = FieldInfo(alias="trialEndBehavior")
    """Behavior when the trial ends"""


class DataSubscription(BaseModel):
    """Created subscription (when status is SUCCESS)"""

    id: str
    """Subscription ID"""

    billing_id: Optional[str] = FieldInfo(alias="billingId", default=None)
    """Billing ID"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Created at"""

    customer_id: str = FieldInfo(alias="customerId")
    """Customer ID"""

    payment_collection: Literal["NOT_REQUIRED", "PROCESSING", "FAILED", "ACTION_REQUIRED"] = FieldInfo(
        alias="paymentCollection"
    )
    """Payment collection"""

    plan_id: str = FieldInfo(alias="planId")
    """Plan ID"""

    pricing_type: Literal["FREE", "PAID", "CUSTOM"] = FieldInfo(alias="pricingType")
    """Pricing type"""

    start_date: datetime = FieldInfo(alias="startDate")
    """Subscription start date"""

    status: Literal["PAYMENT_PENDING", "ACTIVE", "EXPIRED", "IN_TRIAL", "CANCELED", "NOT_STARTED"]
    """Subscription status"""

    addons: Optional[List[DataSubscriptionAddon]] = None

    billing_cycle_anchor: Optional[datetime] = FieldInfo(alias="billingCycleAnchor", default=None)
    """Billing cycle anchor date"""

    budget: Optional[DataSubscriptionBudget] = None
    """Budget configuration"""

    cancellation_date: Optional[datetime] = FieldInfo(alias="cancellationDate", default=None)
    """Subscription cancellation date"""

    cancel_reason: Optional[
        Literal[
            "UPGRADE_OR_DOWNGRADE",
            "CANCELLED_BY_BILLING",
            "EXPIRED",
            "DETACH_BILLING",
            "TRIAL_ENDED",
            "Immediate",
            "TRIAL_CONVERTED",
            "PENDING_PAYMENT_EXPIRED",
            "ScheduledCancellation",
            "CustomerArchived",
            "AutoCancellationRule",
        ]
    ] = FieldInfo(alias="cancelReason", default=None)
    """Subscription cancel reason"""

    coupons: Optional[List[DataSubscriptionCoupon]] = None
    """Coupons applied to the subscription"""

    current_billing_period_end: Optional[datetime] = FieldInfo(alias="currentBillingPeriodEnd", default=None)
    """End of the current billing period"""

    current_billing_period_start: Optional[datetime] = FieldInfo(alias="currentBillingPeriodStart", default=None)
    """Start of the current billing period"""

    effective_end_date: Optional[datetime] = FieldInfo(alias="effectiveEndDate", default=None)
    """Subscription effective end date"""

    end_date: Optional[datetime] = FieldInfo(alias="endDate", default=None)
    """Subscription end date"""

    future_updates: Optional[List[DataSubscriptionFutureUpdate]] = FieldInfo(alias="futureUpdates", default=None)
    """Scheduled future updates for the subscription"""

    latest_invoice: Optional[DataSubscriptionLatestInvoice] = FieldInfo(alias="latestInvoice", default=None)
    """Latest invoice for the subscription"""

    metadata: Optional[Dict[str, str]] = None
    """Additional metadata for the subscription"""

    minimum_spend: Optional[DataSubscriptionMinimumSpend] = FieldInfo(alias="minimumSpend", default=None)
    """Minimum spend configuration"""

    paying_customer_id: Optional[str] = FieldInfo(alias="payingCustomerId", default=None)
    """Paying customer ID for delegated billing"""

    payment_collection_method: Optional[Literal["CHARGE", "INVOICE", "NONE"]] = FieldInfo(
        alias="paymentCollectionMethod", default=None
    )
    """The method used to collect payments for a subscription"""

    prices: Optional[List[DataSubscriptionPrice]] = None

    resource_id: Optional[str] = FieldInfo(alias="resourceId", default=None)
    """Resource ID"""

    subscription_entitlements: Optional[List[DataSubscriptionSubscriptionEntitlement]] = FieldInfo(
        alias="subscriptionEntitlements", default=None
    )
    """Entitlements associated with the subscription"""

    trial: Optional[DataSubscriptionTrial] = None
    """Trial configuration"""

    trial_end_date: Optional[datetime] = FieldInfo(alias="trialEndDate", default=None)
    """Subscription trial end date"""


class Data(BaseModel):
    """Provisioning result with status and subscription or checkout URL."""

    id: str
    """Unique identifier for the provisioned subscription"""

    entitlements: Optional[List[DataEntitlement]] = None

    status: Literal["SUCCESS", "PAYMENT_REQUIRED"]
    """Provision status: SUCCESS or PAYMENT_REQUIRED"""

    subscription: Optional[DataSubscription] = None
    """Created subscription (when status is SUCCESS)"""

    checkout_billing_id: Optional[str] = FieldInfo(alias="checkoutBillingId", default=None)
    """Checkout billing ID when payment is required"""

    checkout_url: Optional[str] = FieldInfo(alias="checkoutUrl", default=None)
    """URL to complete payment when PAYMENT_REQUIRED"""

    is_scheduled: Optional[bool] = FieldInfo(alias="isScheduled", default=None)
    """Whether the subscription is scheduled for future activation"""


class SubscriptionProvisionResponse(BaseModel):
    """Response object"""

    data: Data
    """Provisioning result with status and subscription or checkout URL."""
