import numpy as np
from scipy.stats import norm as scipy_norm
from mpmath import mp

mp.dps = 500

# Tolerance for near-zero comparisons
NEAR_ZERO_TOL = 1e-14


def compute_a_b(y, etaj):
    sq_norm = np.dot(etaj.T, etaj).item()  # Faster than linalg.norm squared
    # Use outer product directly, avoid intermediate identity matrix
    a = y - (etaj @ (etaj.T @ y)) / sq_norm
    b = etaj / sq_norm
    return a, b


def solve_linear_inequalities(p, q):
    # Solve system of inequalities has the form of p+qz <= 0
    # Vectorized implementation
    p_flat = p.flatten()
    q_flat = q.flatten()

    # Handle near-zero q values
    near_zero_mask = np.abs(q_flat) <= NEAR_ZERO_TOL

    # For q ~= 0: constraint becomes p <= 0
    # If any p > 0 with q ~= 0, system is infeasible
    if np.any(p_flat[near_zero_mask] > NEAR_ZERO_TOL):
        # print('Hello 1')
        return []  # Infeasible

    # For non-zero q
    valid_mask = ~near_zero_mask
    q_valid = q_flat[valid_mask]
    p_valid = p_flat[valid_mask]

    if len(q_valid) == 0:
        return [[-np.inf, np.inf]]

    # z <= -p/q when q > 0, z >= -p/q when q < 0
    ratios = -p_valid / q_valid

    pos_q_mask = q_valid > 0
    neg_q_mask = q_valid < 0

    Z_plus = np.inf
    Z_minus = -np.inf

    if np.any(pos_q_mask):
        Z_plus = np.min(ratios[pos_q_mask])
    if np.any(neg_q_mask):
        Z_minus = np.max(ratios[neg_q_mask])

    if Z_minus > Z_plus:
        # print('Hello 2')
        return []  # Infeasible

    return [[Z_minus, Z_plus]]



def solve_quadratic_inequality_single(a, b, c):
    """Solve a single quadratic inequality ax^2 + bx + c <= 0"""
    # Handle linear case (a ~ 0)
    if abs(a) <= NEAR_ZERO_TOL:
        if abs(b) > NEAR_ZERO_TOL:
            root = -c / b
            if b > 0.0:
                return [[-np.inf, root]]
            else:
                return [[root, np.inf]]
        else:
            # Both a and b are near-zero, constraint becomes c <= 0
            if c > NEAR_ZERO_TOL:
                return None
            else:
                return [[-np.inf, np.inf]]

    delta = b**2 - 4 * a * c

    if delta < 0.0:
        if a > 0.0:
            return None
        else:
            return [[-np.inf, np.inf]]
    else:
        sqrt_delta = np.sqrt(delta)
        # Use numerically stable formula
        if b >= 0:
            root1 = (-b - sqrt_delta) / (2 * a)
        else:
            root1 = (-b + sqrt_delta) / (2 * a)

        # Compute second root using Vieta's formula if root1 is not near-zero
        if abs(root1) > NEAR_ZERO_TOL:
            root2 = c / (a * root1)
        else:
            root2 = (
                (-b + sqrt_delta) / (2 * a)
                if b >= 0
                else (-b - sqrt_delta) / (2 * a)
            )

        roots = sorted([root1, root2])

        if a > 0:
            return [roots]
        else:
            return [[-np.inf, roots[0]], [roots[1], np.inf]]


def solve_quadratic_inequality(a, b, c):
    """
    Solve system of quadratic inequalities a*z^2 + b*z + c <= 0.
    Accepts either scalars or arrays. Returns intersection of all valid intervals.
    """

    # Handle scalar inputs (original behavior)
    if np.isscalar(a) or (isinstance(a, np.ndarray) and a.ndim == 0):
        return solve_quadratic_inequality_single(float(a), float(b), float(c))

    # Vectorized implementation for arrays
    a_flat = np.asarray(a).flatten()
    b_flat = np.asarray(b).flatten()
    c_flat = np.asarray(c).flatten()
    n = len(a_flat)

    if n == 0:
        return [[-np.inf, np.inf]]

    # Initialize global bounds
    global_lower = -np.inf
    global_upper = np.inf

    # Collect holes (from concave parabolas, a < 0)
    holes = []

    for i in range(n):
        ai, bi, ci = a_flat[i], b_flat[i], c_flat[i]

        # Linear case (ai ~ 0)
        if abs(ai) <= NEAR_ZERO_TOL:
            if abs(bi) > NEAR_ZERO_TOL:
                root = -ci / bi
                if bi > 0.0:
                    global_upper = min(global_upper, root)
                else:
                    global_lower = max(global_lower, root)
            else:
                # Both ai and bi are near-zero, constraint becomes ci <= 0
                if ci > NEAR_ZERO_TOL:
                    print(ci)
                    print('Hello 3')
                    return []  # Infeasible
                # else: always true, no constraint
            continue

        delta = bi**2 - 4 * ai * ci

        if delta < 0.0:
            if ai > 0.0:
                print('Hello 4')
                return []  # Infeasible: parabola always positive
            # else: always true (parabola always negative), no constraint
            continue

        sqrt_delta = np.sqrt(delta)

        # Compute roots using numerically stable formula
        if bi >= 0:
            r1 = (-bi - sqrt_delta) / (2 * ai)
        else:
            r1 = (-bi + sqrt_delta) / (2 * ai)

        # Use Vieta's formula for second root if r1 is not near-zero
        if abs(r1) > NEAR_ZERO_TOL:
            r2 = ci / (ai * r1)
        else:
            r2 = (
                (-bi + sqrt_delta) / (2 * ai)
                if bi >= 0
                else (-bi - sqrt_delta) / (2 * ai)
            )

        r_min, r_max = min(r1, r2), max(r1, r2)

        if ai > 0:
            # Convex: solution in [r_min, r_max]
            global_lower = max(global_lower, r_min)
            global_upper = min(global_upper, r_max)
        else:
            # Concave: solution outside (r_min, r_max) -> creates a hole
            holes.append((r_min, r_max))

    # Check if global bounds are feasible
    if global_lower > global_upper:
        print('Hello 5')
        return []

    # Start with the global interval
    result = [[global_lower, global_upper]]

    # Subtract holes
    for hole_left, hole_right in holes:
        new_result = []
        for interval in result:
            left, right = interval
            # No overlap
            if hole_right <= left or hole_left >= right:
                new_result.append([left, right])
            else:
                # Hole overlaps - split the interval
                if left < hole_left:
                    new_result.append([left, hole_left])
                if hole_right < right:
                    new_result.append([hole_right, right])
        result = new_result
        if not result:
            print('Hello 6')
            return []

    return result


def intersect(list_intervals_1, list_intervals_2):
    """
    Compute intersection of two lists of intervals.
    Assumes intervals within each list are sorted and non-overlapping.
    """
    if not list_intervals_1 or not list_intervals_2:
        return []

    results = []
    i, j = 0, 0
    n1, n2 = len(list_intervals_1), len(list_intervals_2)

    while i < n1 and j < n2:
        a1, b1 = list_intervals_1[i]
        a2, b2 = list_intervals_2[j]

        # Find intersection
        start = max(a1, a2)
        end = min(b1, b2)

        if start <= end:
            results.append([start, end])

        # Move the pointer with the smaller endpoint
        if b1 < b2:
            i += 1
        else:
            j += 1

    return results


def _safe_ncdf(x):
    """
    Compute normal CDF. Uses scipy for normal range, falls back to mpmath for extremes.
    """
    if -37 < x < 37:  # scipy.stats.norm.cdf is accurate in this range
        return scipy_norm.cdf(x)
    else:
        return float(mp.ncdf(x))


def pivot(list_itvs, etajTy, tn_mu, tn_sigma):
    if len(list_itvs) == 0:
        return None

    # Convert to numpy array for vectorized operations
    intervals = np.array(list_itvs)
    z_low = (intervals[:, 0] - tn_mu) / tn_sigma
    z_high = (intervals[:, 1] - tn_mu) / tn_sigma

    # Check if we need high precision (extreme values)
    needs_high_precision = np.any(z_low < -37) or np.any(z_high > 37)
    
    if needs_high_precision:
        # Use mpmath for high precision
        numerator = mp.mpf(0)
        denominator = mp.mpf(0)
        for i, interval in enumerate(list_itvs):
            temp = mp.ncdf(z_high[i]) - mp.ncdf(z_low[i])
            denominator += temp
            if etajTy >= interval[1]:
                numerator += temp
            elif etajTy >= interval[0] and etajTy < interval[1]:
                z_eta = (etajTy - tn_mu) / tn_sigma
                numerator += mp.ncdf(z_eta) - mp.ncdf(z_low[i])

        if denominator == 0.0:
            print("Numerical error")
            return None

        tn_cdf = float(numerator / denominator)
    else:
        # Vectorized scipy implementation
        cdf_high = scipy_norm.cdf(z_high)
        cdf_low = scipy_norm.cdf(z_low)
        interval_probs = cdf_high - cdf_low

        denominator = np.sum(interval_probs)

        if denominator == 0.0:
            # Use mpmath for high precision
            numerator = mp.mpf(0)
            denominator = mp.mpf(0)
            for i, interval in enumerate(list_itvs):
                temp = mp.ncdf(z_high[i]) - mp.ncdf(z_low[i])
                denominator += temp
                if etajTy >= interval[1]:
                    numerator += temp
                elif etajTy >= interval[0] and etajTy < interval[1]:
                    z_eta = (etajTy - tn_mu) / tn_sigma
                    numerator += mp.ncdf(z_eta) - mp.ncdf(z_low[i])

            if denominator == 0.0:
                print("Numerical error")
                return None

            tn_cdf = float(numerator / denominator)
        else:
            # Compute numerator based on where etajTy falls
            numerator = 0.0
            for i, interval in enumerate(list_itvs):
                if etajTy >= interval[1]:
                    numerator += interval_probs[i]
                elif etajTy >= interval[0]:
                    z_eta = (etajTy - tn_mu) / tn_sigma
                    numerator += scipy_norm.cdf(z_eta) - cdf_low[i]

            tn_cdf = numerator / denominator

    return tn_cdf


def p_value(list_itvs, etajTy, tn_sigma):
    z = np.abs(etajTy)
    truncated_pos = pivot(list_itvs, z, 0, tn_sigma)
    truncated_neg = pivot(list_itvs, -z, 0, tn_sigma)
    return truncated_neg + (1 - truncated_pos)
