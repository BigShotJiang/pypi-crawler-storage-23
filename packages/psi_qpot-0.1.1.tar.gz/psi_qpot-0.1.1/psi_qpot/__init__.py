import os
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["OPENBLAS_NUM_THREADS"] = "1"
os.environ["MKL_NUM_THREADS"] = "1"
os.environ["VECLIB_MAXIMUM_THREADS"] = "1"
os.environ["NUMEXPR_NUM_THREADS"] = "1"

from .da.otda import OTDA
from .cv.model import HoldOutCV, KFoldCV
from .qp.feature_selector import Lasso, ElasticNet, NNLS, FeatureSelector

import numpy as np
from .utils import intersect

from multiprocessing import Pool

def divide_and_conquer(a, b, gl_ins, cv_ins, da_ins, zmin, zmax):
    if cv_ins is None:
        gl_class = type(gl_ins)
        hyperparams = gl_ins.get_hyperparams()
        da_class = type(da_ins)
        ns, nt = da_ins.ns, da_ins.nt
        Xs, Xt = da_ins.Xs, da_ins.Xt
        X = np.vstack((Xs, Xt))

        # Pre-compute static values (they only depend on ns, nt, Xs, Xt)
        H_static = da_ins.H
        h_static = da_ins.h
        Xs_squared = da_ins.Xs_squared
        Xt_squared = da_ins.Xt_squared
        XsXt = da_ins.XsXt
        row_mass = da_ins.row_mass
        col_mass = da_ins.col_mass

        # Pre-compute identity matrix
        I_nt = np.identity(nt)
        zeros_block = np.zeros((ns + nt, ns))

        list_intervals = []
        list_M = []
        z = zmin
        prev_z = -np.inf
        cnt_eq = 0
        while z < zmax:
            yz = a + b * z
            ys, yt = yz[0:ns, :], yz[ns:, :]
            da_model = da_class(
                np.hstack((Xs, ys)),
                np.hstack((Xt, yt)),
                H=H_static,
                h=h_static,
                Xs_squared=Xs_squared,
                Xt_squared=Xt_squared,
                XsXt=XsXt,
                row_mass=row_mass,
                col_mass=col_mass,
            )
            Tz, _ = da_model.fit()
            interval_da = da_model.get_interval(a, b)

            # Select the interval containing the data point that we are currently condering.
            flag = False
            for i in interval_da:
                if i[0] <= z <= i[1]:
                    flag = True
                    interval_da = [i]
                    break

            if not flag:
                    nearest = [interval_da[0]]
                    min_dist = np.min([np.abs(z - nearest[0][0]), np.abs(z - nearest[0][1])])

                    for itv in interval_da:
                        tmp_dist = np.min([np.abs(z - itv[0]), np.abs(z - itv[1])])
                        if tmp_dist < min_dist:
                            min_dist = tmp_dist
                            nearest = [itv]

                    z = nearest[0][1] - 5e-4

            Omega_z = np.hstack((zeros_block, np.vstack((ns * Tz, I_nt))))
            a_tilde, b_tilde = Omega_z @ a, Omega_z @ b
            Xz_tilde = Omega_z @ X

            # Cache XTX for inner loop (Xz_tilde doesn't change in inner loop)
            XTX_cached = Xz_tilde.T @ Xz_tilde

            while z < interval_da[0][1]:
                if z != prev_z:
                    prev_z = z
                    cnt_eq = 0
                else:
                    cnt_eq += 1
                    z += 5e-4 * cnt_eq
                
                yz = a + b * z
                yz_tilde = Omega_z @ yz
                gl_model = gl_class(Xz_tilde, yz_tilde, XTX=XTX_cached, **hyperparams)
                M_v = gl_model.fit()

                if gl_model.is_empty():
                    z += 5e-4
                    continue

                interval_gl = gl_model.get_interval(a_tilde, b_tilde)
                interval_z = intersect(interval_da, interval_gl)
                
                z = interval_z[0][1] + 5e-4
            
                if z != prev_z:
                    list_intervals += interval_z
                    list_M += [M_v]
            
                if z > zmax:
                    break

        return list_intervals, list_M
    else:
        gl_class = type(gl_ins)
        hyperparams = gl_ins.get_hyperparams()
        cv_class = type(cv_ins)
        da_class = type(da_ins)
        ns, nt = da_ins.ns, da_ins.nt
        Xs, Xt = da_ins.Xs, da_ins.Xt
        X = np.vstack((Xs, Xt))

        # Pre-compute static values (they only depend on ns, nt, Xs, Xt)
        H_static = da_ins.H
        h_static = da_ins.h
        Xs_squared = da_ins.Xs_squared
        Xt_squared = da_ins.Xt_squared
        XsXt = da_ins.XsXt
        row_mass = da_ins.row_mass
        col_mass = da_ins.col_mass

        # Pre-compute identity matrix
        I_nt = np.identity(nt)
        zeros_block = np.zeros((ns + nt, ns))

        list_intervals = []
        list_M = []
        z = zmin
        prev_z = -np.inf
        cnt_eq = 0
        while z < zmax:
            yz = a + b * z
            ys, yt = yz[0:ns, :], yz[ns:, :]
            da_model = da_class(
                np.hstack((Xs, ys)),
                np.hstack((Xt, yt)),
                H=H_static,
                h=h_static,
                Xs_squared=Xs_squared,
                Xt_squared=Xt_squared,
                XsXt=XsXt,
                row_mass=row_mass,
                col_mass=col_mass,
            )
            Tz, _ = da_model.fit()
            da_model.check_KKT()
            interval_da = da_model.get_interval(a, b)

            # Select the interval containing the data point that we are currently considering.
            flag = False
            for i in interval_da:
                if i[0] <= z <= i[1]:
                    flag = True
                    interval_da = [i]
                    break

            if not flag:
                    nearest = [interval_da[0]]
                    min_dist = np.min([np.abs(z - nearest[0][0]), np.abs(z - nearest[0][1])])

                    for itv in interval_da:
                        tmp_dist = np.min([np.abs(z - itv[0]), np.abs(z - itv[1])])
                        if tmp_dist < min_dist:
                            min_dist = tmp_dist
                            nearest = [itv]

                    z = nearest[0][1] - 5e-4

            Omega_z = np.hstack((zeros_block, np.vstack((ns * Tz, I_nt))))
            a_tilde, b_tilde = Omega_z @ a, Omega_z @ b
            Xz_tilde = Omega_z @ X

            # Cache XTX for inner loops (Xz_tilde doesn't change)
            XTX_cached = Xz_tilde.T @ Xz_tilde
            
            while z < interval_da[0][1]:
                yz = a + b * z
                yz_tilde = Omega_z @ yz
                cv_model = cv_class(train_val_pairs=cv_ins.train_val_pairs)
                best_Lambda, _ = cv_model.fit(
                    Xz_tilde, yz_tilde, gl_class, cv_ins.list_lambda
                )
                interval_cv = cv_model.get_interval(a_tilde, b_tilde)
                
                flag = False
                for i in interval_cv:
                    if i[0] <= z <= i[1]:
                        flag = True
                        interval_cv = [i]
                        break
 
                if not flag:
                    nearest = [interval_cv[0]]
                    min_dist = np.min([np.abs(z - nearest[0][0]), np.abs(z - nearest[0][1])])

                    for itv in interval_cv:
                        tmp_dist = np.min([np.abs(z - itv[0]), np.abs(z - itv[1])])
                        if tmp_dist < min_dist:
                            min_dist = tmp_dist
                            nearest = [itv]

                    z = nearest[0][1] - 5e-4

                interval_cv = intersect(interval_da, interval_cv)
                hyperparams["Lambda"] = best_Lambda
                
                while z < interval_cv[0][1]:
                    if z != prev_z:
                        prev_z = z
                        cnt_eq = 0
                    else:
                        cnt_eq += 1
                        z += 5e-4 * cnt_eq

                    yz = a + b * z
                    yz_tilde = Omega_z @ yz

                    gl_model = gl_class(
                        Xz_tilde, yz_tilde, XTX=XTX_cached, **hyperparams
                    )
                    M_v = gl_model.fit()

                    if gl_model.is_empty():
                        z += 5e-4
                        continue

                    interval_gl = gl_model.get_interval(a_tilde, b_tilde)
                    interval_z = intersect(interval_cv, interval_gl)

                    # with open("debug.txt", "a") as f:
                        # f.write(f"{z}\t\t{interval_da}\t\t{interval_cv}\t\t{interval_gl}\t\t{interval_z}\n")

                    z = interval_z[0][1] + 5e-4

                    if z != prev_z:
                        list_intervals += interval_z
                        list_M += [M_v]

                    if z > zmax:
                        break

                if z > zmax:
                    break

        return list_intervals, list_M

def divide_and_conquer_w_mp(a, b, gl_ins, cv_ins, da_ins, zmin, zmax):
    if cv_ins is None:
        gl_class = type(gl_ins)
        hyperparams = gl_ins.get_hyperparams()
        da_class = type(da_ins)
        ns, nt = da_ins.ns, da_ins.nt
        Xs, Xt = da_ins.Xs, da_ins.Xt
        X = np.vstack((Xs, Xt))

        # Pre-compute static values (they only depend on ns, nt, Xs, Xt)
        H_static = da_ins.H
        h_static = da_ins.h
        Xs_squared = da_ins.Xs_squared
        Xt_squared = da_ins.Xt_squared
        XsXt = da_ins.XsXt
        row_mass = da_ins.row_mass
        col_mass = da_ins.col_mass

        # Pre-compute identity matrix
        I_nt = np.identity(nt)
        zeros_block = np.zeros((ns + nt, ns))

        list_intervals = []
        list_M = []

        # Divide search line into multiple segments
        num_segments = os.cpu_count()
        length = (zmax-zmin) / num_segments
        segments = [(zmin + i * length, zmin + (i+1) * length) for i in range(num_segments)]

        # Run divide_and_conquer in parallel
        with Pool(os.cpu_count()) as pool:
            results = pool.starmap(divide_and_conquer, [(a, b, gl_ins, cv_ins, da_ins, sub_zmin, sub_zmax) for sub_zmin, sub_zmax in segments])

        # Combine and filter duplicates
        for result in results:
            if list_intervals:
                last_itv = list_intervals[-1]
                new_itvs = []
                new_M = []
                for i in range(len(result[0])):
                    itv = result[0][i]
                    if itv[0] >= last_itv[1]:
                        new_itvs += [itv]
                        new_M += [result[1][i]]
                list_intervals += new_itvs
                list_M += new_M
            else:
                list_intervals = result[0]
                list_M = result[1]
        return list_intervals, list_M
    
    else:
        gl_class = type(gl_ins)
        hyperparams = gl_ins.get_hyperparams()
        cv_class = type(cv_ins)
        da_class = type(da_ins)
        ns, nt = da_ins.ns, da_ins.nt
        Xs, Xt = da_ins.Xs, da_ins.Xt
        X = np.vstack((Xs, Xt))

        # Pre-compute static values (they only depend on ns, nt, Xs, Xt)
        H_static = da_ins.H
        h_static = da_ins.h
        Xs_squared = da_ins.Xs_squared
        Xt_squared = da_ins.Xt_squared
        XsXt = da_ins.XsXt
        row_mass = da_ins.row_mass
        col_mass = da_ins.col_mass

        # Pre-compute identity matrix
        I_nt = np.identity(nt)
        zeros_block = np.zeros((ns + nt, ns))

        list_intervals = []
        list_M = []
        
        # Divide search line into multiple segments
        length = (zmax-zmin) / os.cpu_count()
        segments = [(zmin + i * length, zmin + (i+1) * length) for i in range(os.cpu_count())]

        # Run divide_and_conquer in parallel
        with Pool(os.cpu_count()) as pool:
            results = pool.starmap(divide_and_conquer, [(a, b, gl_ins, cv_ins, da_ins, sub_zmin, sub_zmax) for sub_zmin, sub_zmax in segments])
    
        # Combine and filter duplicates
        for result in results:
            if list_intervals:
                last_itv = list_intervals[-1]
                new_itvs = []
                new_M = []
                for i in range(len(result[0])):
                    itv = result[0][i]
                    if itv[0] >= last_itv[1]:
                        new_itvs += [itv]
                        new_M += [result[1][i]]
                list_intervals += new_itvs
                list_M += new_M
            else:
                list_intervals = result[0]
                list_M = result[1]
        return list_intervals, list_M
    
def fit(a, b, gl_ins, cv_ins=None, da_ins=None, zmin=-20, zmax=20):
    # list_intervals, list_M = divide_and_conquer(a, b, gl_ins, cv_ins, da_ins, zmin, zmax)
    list_intervals, list_M = divide_and_conquer_w_mp(a, b, gl_ins, cv_ins, da_ins, zmin, zmax)
    Z = []
    M_obs = gl_ins.active_set
    for i in range(len(list_intervals)):
        if np.array_equal(list_M[i], M_obs):
            Z.append(list_intervals[i])
    return Z
