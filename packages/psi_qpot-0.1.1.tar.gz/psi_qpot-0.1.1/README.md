# PSI-QPOT: Post-Selection Inference for Sparse Estimators Cast as Quadratic Programs after Domain Adaptation

<!-- [![PyPI version](https://img.shields.io/pypi/v/psi-qpot)](https://img.shields.io/pypi/v/psi-qpot) -->
<!-- ![License](https://img.shields.io/github/license/DAIR-Group/psi-qpot) -->

**PSI-QPOT** is a Python package that implements a **selective inference (SI) framework** for conducting valid statistical inference after Quadratic Programming (QP)-cast Feature Selection algorithms in the presence of Optimal Transport (OT)-based domain adaptation (DA). The main idea is to leverages the SI framework and employs a divide-and conquer approach to efficiently compute the $p$ -value. Our proposed methods provides valid $p$-value for FS-DA results, by **keeping the false positive rate (FPR) under control**, while also **maximizing the true positive rate (TPR)**, i.e., lowering the false negative rate (FNR).

![PSI-QPOT Illustration](figs/PSI-QPOT_illustration.png)

## Requirements
This package has the following requirements:

    cvxpy
    mpmath
    numpy
    POT
    scikit-learn
    scipy

## Installation

### Package Installation
This package can be installed using pip:
```bash
$ pip install psi_qpot
```

## Usage

We provide several Jupyter notebooks demonstrating how to use the psi_qpot package in action.

- Examples for conducting inference for QP-cast Feature Selection after OT-based DA
```
>> ex1_PSI-QPOT.py
```
- Check the uniformity of the pivot
```
>> ex2_validity_of_p_value.py
```