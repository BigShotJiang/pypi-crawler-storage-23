# CobwebSim

Stock simulation and backtesting API with a Python SDK. Compute 71 technical features from OHLCV data, run backtests with realistic execution modeling, and generate 27 chart types.

**API:** [Live Swagger Docs](https://web-production-83f3e.up.railway.app/docs)
**SDK:** `pip install cobweb-py`

---

## Quickstart

```bash
pip install cobweb-py[viz]
```

```python
from cobweb_py import CobwebSim, to_signals, show_features

sim = CobwebSim(
    base_url="https://web-production-83f3e.up.railway.app",
    api_key="YOUR_API_KEY",
)

# Check connection
print(sim.health())

# Compute features from a CSV file
result = sim.enrich("my_stock_data.csv", feature_ids=[1, 11, 36, 40])
print(result["feature_columns"])  # ['ret_1d', 'sma_20', 'rsi_14', 'atr_14']

# Run a backtest
signals = [0.0] * 20 + [1.0] * 80  # flat then long
bt = sim.backtest("my_stock_data.csv", signals=signals, feature_ids=[1, 36])
print(bt["metrics"])
```

---

## Table of Contents

- [Installation](#installation)
- [SDK Reference](#sdk-reference)
  - [CobwebSim Client](#cobwebsim-client)
  - [BacktestConfig](#backtestconfig)
  - [Scoring](#scoring)
  - [Signals](#signals)
  - [Plots](#plots)
  - [Utilities](#utilities)
  - [Pipeline](#pipeline)
- [API Reference](#api-reference)
  - [GET /health](#get-health)
  - [POST /features](#post-features)
  - [POST /backtest](#post-backtest)
  - [POST /plots](#post-plots)
- [Features Reference](#features-reference)
- [Plots Reference](#plots-reference)
- [Backtest Configuration](#backtest-configuration)
- [Authentication](#authentication)
- [Rate Limiting](#rate-limiting)
- [Examples](#examples)

---

## Installation

```bash
# Base SDK (API calls only, lightweight)
pip install cobweb-py

# With visualization support (adds pandas + plotly)
pip install cobweb-py[viz]
```

**Requirements:** Python 3.9+

---

## SDK Reference

### CobwebSim Client

The main class for interacting with the API.

```python
from cobweb_py import CobwebSim

sim = CobwebSim(
    base_url="https://web-production-83f3e.up.railway.app",
    api_key="YOUR_API_KEY",   # optional if auth is disabled
    timeout=60,               # request timeout in seconds
)
```

#### `sim.health()`

Check API status.

```python
sim.health()
# {'status': 'ok', 'version': '0.1.0'}
```

#### `sim.enrich(data, feature_ids, *, max_rows)`

Compute technical features from OHLCV data. Returns OHLCV + feature columns.

```python
result = sim.enrich(
    data="stock.csv",           # CSV path, DataFrame, list[dict], or {"rows": [...]}
    feature_ids=[1, 36, 40],    # which features to compute (see Features Reference)
    max_rows=500,               # optional: limit rows sent
)

result["rows"]              # list of dicts with OHLCV + features
result["feature_columns"]   # ['ret_1d', 'rsi_14', 'atr_14']
```

`sim.features()` is an alias for `sim.enrich()`.

#### `sim.backtest(data, *, signals, config, ...)`

Run a backtest simulation.

```python
bt = sim.backtest(
    data="stock.csv",
    signals=[0.0, 0.0, 1.0, 1.0, ...],  # one per bar: +1=long, -1=short, 0=flat
    compute_features=True,                 # compute features server-side
    feature_ids=[1, 36],                   # which features
    config={"initial_cash": 50_000, "fee_bps": 2.0},
    plot_ids=[1, 4, 5, 10],               # generate plots inline
    benchmark="spy.csv",                   # optional benchmark data
    max_rows=500,
)

bt["trades"]           # list of trade dicts
bt["equity_curve"]     # list of {equity, cash, pos_units, ...} per bar
bt["metrics"]          # {sharpe_ann, sortino_ann, max_drawdown, total_return, ...}
bt["current_signal"]   # "buy", "sell", or "hold"
bt["current_exposure"]  # float, current position weight
bt["plots"]            # dict of plot payloads (if plot_ids provided)
```

#### `sim.plots(data, backtest_result, *, plot_ids, ...)`

Generate plot payloads separately from a previous backtest.

```python
plots = sim.plots(
    data="stock.csv",
    backtest_result=bt,
    plot_ids=[1, 5, 10, 16],
    benchmark="spy.csv",
)

plots["payloads"]  # dict keyed by plot name
```

---

### BacktestConfig

Dataclass for backtest configuration. All fields have sensible defaults.

```python
from cobweb_py import BacktestConfig

config = BacktestConfig(
    # Capital
    initial_cash=10_000,          # starting portfolio value
    max_leverage=1.0,             # max leverage ratio (1.0 = no leverage)
    allow_margin=False,           # allow short selling

    # Execution
    exec_horizon="swing",         # "intraday" | "swing" | "longterm"
    asset_type="equities",        # "equities" | "crypto"
    max_participation=None,       # max % of daily volume (0.0-1.0)

    # Costs (basis points)
    fee_bps=1.0,                  # commission fee
    half_spread_bps=2.0,          # half bid-ask spread
    base_slippage_bps=1.0,        # base slippage
    impact_coeff=1.0,             # market impact coefficient

    # Rebalancing
    rebalance_mode="on_signal_change",  # "on_signal_change" | "every_bar" | "calendar"
    rebalance_every_n_bars=0,
    min_trade_units=0.0,
    max_order_age_bars=0,

    # Signal thresholds
    buy_threshold=0.10,           # signal above this = buy
    sell_threshold=-0.10,         # signal below this = sell

    # Analytics
    risk_free_annual=0.0,         # annual risk-free rate
    periods_per_year=252,         # trading days per year
)

# Pass to backtest
bt = sim.backtest(data, signals=signals, config=config)

# Or as a dict
bt = sim.backtest(data, signals=signals, config=config.to_dict())
```

---

### Scoring

Compute weighted scores from enriched feature data. Scores are continuous values that get converted to trading signals.

```python
from cobweb_py import score, score_by_id, auto_score

# Score by column name
scores = score(
    enriched_rows,                          # rows from sim.enrich()
    weights={"rsi_14": 0.3, "ret_1d": 0.4, "sma_20": 0.3},
    normalize=True,                         # z-score normalize each feature
    rsi_to_unit=True,                       # scale RSI from 0-100 to 0-1
)

# Score by feature ID
scores = score_by_id(
    enriched_rows,
    weights_by_id={36: 0.3, 1: 0.4, 11: 0.3},  # RSI, ret_1d, SMA-20
)

# Auto-score with default formula (0.3*RSI + 0.3*SMA_signal + 0.4*ret_1d)
scores = auto_score(enriched_rows)
```

#### Explore available features and plots

```python
from cobweb_py import show_features, show_plots, show_categories, list_features, list_plots

# Print all categories
show_categories()

# Print feature reference table (optionally filter by category)
show_features()
show_features("momentum")
show_features("bollinger")

# Print plot reference table
show_plots()
show_plots("risk")

# Get as list of dicts (for programmatic use)
features = list_features("macd")
# [{'id': 30, 'name': 'macd', 'category': 'MACD'}, ...]

plots = list_plots("trades")
# [{'id': 16, 'name': 'trade_return_distribution', 'category': 'Trades'}, ...]
```

---

### Signals

Convert continuous scores to discrete position signals.

```python
from cobweb_py import to_signals

signals = to_signals(
    scores,                # list of floats from scoring
    entry_th=0.20,         # go long when score > 0.20
    exit_th=0.05,          # go flat when score < 0.05
    use_shorts=False,      # True to allow short positions
)
# Returns: [0.0, 0.0, 1.0, 1.0, 0.0, ...]  (0=flat, 1=long, -1=short)
```

#### Extract current signal from backtest results

```python
from cobweb_py import get_signal, print_signal

sig = get_signal(bt)
# {'signal': 'buy', 'exposure': 0.85, 'strength': 0.72}

print_signal(bt)
# Signal: BUY | Exposure: 0.85 | Strength: 0.72
```

---

### Plots

Render API plot payloads as interactive Plotly charts.

```python
from cobweb_py import payload_to_figure, payloads_to_figures
from cobweb_py.plots import (
    save_equity_plot,
    save_score_plot,
    save_price_and_score_plot,
    save_api_payloads_to_html,
    save_features_table,
    save_metrics_table,
    save_trades_table,
)

# Convert a single plot payload to a Plotly figure
fig = payload_to_figure(bt["plots"]["equity_curve_linear"])
fig.show()

# Convert all payloads to figures
figures = payloads_to_figures(bt["plots"])
for name, fig in figures.items():
    fig.write_html(f"{name}.html")

# Save all API plot payloads to HTML files
paths = save_api_payloads_to_html(bt["plots"], out_dir="charts/")

# Save equity curve chart
save_equity_plot(bt, "equity.html")

# Save score time-series
save_score_plot(enriched_rows, scores, "score.html")

# Save dual-axis price + score chart
save_price_and_score_plot(enriched_rows, scores, "price_score.html")

# Save styled HTML tables
save_features_table(enriched_rows, out_html="features.html", out_csv="features.csv")
save_metrics_table(bt, "metrics.html")
save_trades_table(bt, "trades.html")
```

---

### Utilities

```python
from cobweb_py import fix_timestamps, load_csv, align, save_table

# Load and normalize a CSV file
data = load_csv("stock.csv", dayfirst=True)
# Returns: {"rows": [{"timestamp": "2024-01-02 00:00:00", "open": 150.0, ...}, ...]}

# Fix timestamps in existing data
data = fix_timestamps(
    rows,
    dayfirst=True,           # parse DD/MM/YYYY format
    drop_bad=True,            # drop unparseable timestamps
    sort=True,                # sort by timestamp
    out_format="%Y-%m-%d %H:%M:%S",
)

# Align two datasets on common timestamps (e.g., stock + benchmark)
stock, benchmark = align(stock_data, spy_data)

# Save a lightweight HTML table
save_table(rows, "output.html", title="My Data", max_rows=500)
```

---

### Pipeline

Reusable workflow: enrich once, run multiple scoring/backtest variations.

```python
from cobweb_py import Pipeline

pipe = Pipeline(
    base_url="https://web-production-83f3e.up.railway.app",
    data="stock.csv",
    feature_ids=[1, 11, 36, 40],
    benchmark="spy.csv",
    api_key="YOUR_API_KEY",
)

# Enrich once (calls /features, caches result)
pipe.enrich()

# Run with different parameters
result1 = pipe.run(
    weights={36: 0.5, 1: 0.5},
    entry_th=0.20,
    exit_th=0.05,
    plot_ids=[1, 4, 5, 10],
)

result2 = pipe.run(
    weights={36: 0.3, 11: 0.3, 1: 0.4},
    entry_th=0.15,
    exit_th=0.00,
    use_shorts=True,
    config={"initial_cash": 50_000},
)

# Access results
print(result1["metrics"])
print(result2["metrics"])
```

---

## API Reference

Base URL: `https://web-production-83f3e.up.railway.app`

All endpoints except `/health` require authentication (when enabled) and are rate-limited.

### GET /health

Public health check. No authentication required.

```bash
curl https://web-production-83f3e.up.railway.app/health
```

**Response:**
```json
{"status": "ok", "version": "0.1.0"}
```

---

### POST /features

Compute technical features from OHLCV data.

```bash
curl -X POST https://web-production-83f3e.up.railway.app/features \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {
      "rows": [
        {"timestamp": "2024-01-02", "open": 150.0, "high": 152.0, "low": 149.0, "close": 151.0, "volume": 1000000},
        ...
      ]
    },
    "feature_ids": [1, 36, 40]
  }'
```

**Request body:**

| Field | Type | Required | Description |
|---|---|---|---|
| `data.rows` | `OHLCRow[]` | Yes | 20–10,000 OHLCV candles |
| `feature_ids` | `int[]` | No | Feature IDs to compute (1–71). Omit = no features |

**OHLCRow fields:**

| Field | Type | Required | Constraints |
|---|---|---|---|
| `timestamp` | `string` | No | Any parseable date format |
| `open` | `float` | Yes | > 0, finite |
| `high` | `float` | Yes | > 0, finite, >= low |
| `low` | `float` | Yes | > 0, finite |
| `close` | `float` | Yes | > 0, finite |
| `volume` | `float` | No | >= 0, finite |

**Response:**
```json
{
  "rows": [
    {"timestamp": "2024-01-02", "Open": 150.0, "High": 152.0, "Low": 149.0, "Close": 151.0, "Volume": 1000000, "ret_1d": 0.0067, "rsi_14": 55.3, "atr_14": 2.8},
    ...
  ],
  "feature_columns": ["ret_1d", "rsi_14", "atr_14"]
}
```

---

### POST /backtest

Run a full backtest simulation.

```bash
curl -X POST https://web-production-83f3e.up.railway.app/backtest \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {"rows": [...]},
    "signals": [0.0, 0.0, 1.0, 1.0, ...],
    "compute_features": true,
    "feature_ids": [1, 36],
    "config": {
      "initial_cash": 10000,
      "fee_bps": 1.0,
      "exec_horizon": "swing"
    },
    "plot_ids": [1, 5, 10]
  }'
```

**Request body:**

| Field | Type | Required | Description |
|---|---|---|---|
| `data.rows` | `OHLCRow[]` | Yes | 20–10,000 OHLCV candles |
| `signals` | `float[]` | Yes | One per row. +1=long, -1=short, 0=flat |
| `compute_features` | `bool` | No | Default: true |
| `feature_ids` | `int[]` | No | Features to compute |
| `config` | `BacktestConfig` | No | See [Backtest Configuration](#backtest-configuration) |
| `plot_ids` | `int[]` | No | Plot IDs to generate inline (1–27) |
| `plot_params` | `dict` | No | `{"rolling_window": 63, "var_q": 0.05}` |
| `benchmark` | `OHLCRequest` | No | Benchmark OHLCV for comparative plots |

**Validation rules:**
- `len(signals)` must equal `len(data.rows)`
- `buy_threshold` must be > `sell_threshold`
- Minimum 20 rows and 20 signals

**Response:**
```json
{
  "trades": [
    {"bar": 20, "side": "buy", "qty": 66.0, "price": 151.2, "cost": 0.45, ...},
    ...
  ],
  "equity_curve": [
    {"equity": 10000.0, "cash": 10000.0, "pos_units": 0.0, ...},
    ...
  ],
  "metrics": {
    "total_return": 0.127,
    "sharpe_ann": 1.45,
    "sortino_ann": 2.01,
    "max_drawdown": -0.082,
    "max_drawdown_duration_bars": 15,
    "volatility_ann": 0.18,
    "var_bar": -0.021,
    "cvar_bar": -0.031,
    "skew": -0.15,
    "kurtosis": 3.2,
    "final_equity": 11270.0,
    "bars": 252
  },
  "current_signal": "buy",
  "current_exposure": 1.0,
  "signal_strength": 0.85,
  "plots": {"equity_curve_linear": {...}, "rolling_sharpe": {...}, ...}
}
```

---

### POST /plots

Generate chart payloads from OHLCV data and optional backtest results.

```bash
curl -X POST https://web-production-83f3e.up.railway.app/plots \
  -H "Authorization: Bearer YOUR_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{
    "data": {"rows": [...]},
    "backtest_result": {"trades": [...], "equity_curve": [...], "metrics": {...}},
    "plot_ids": [1, 4, 5, 10, 16],
    "compute_features": true,
    "feature_ids": [70, 71]
  }'
```

**Request body:**

| Field | Type | Required | Description |
|---|---|---|---|
| `data.rows` | `OHLCRow[]` | Yes | OHLCV candles |
| `backtest_result` | `dict` | No | Previous backtest output |
| `plot_ids` | `int[]` | No | Plot IDs to generate (1–27) |
| `compute_features` | `bool` | No | Default: true |
| `feature_ids` | `int[]` | No | Features needed for plots |
| `plot_params` | `dict` | No | Plot customization params |
| `benchmark` | `OHLCRequest` | No | For benchmark plots (IDs 3, 8, 9, 22) |

**Response:**
```json
{
  "payloads": {
    "equity_curve_linear": {"data": [...], "layout": {...}},
    "daily_return_ts": {"data": [...], "layout": {...}},
    ...
  }
}
```

---

## Features Reference

71 technical features across 10 categories. Pass `feature_ids` as a list of integers.

| ID | Name | Category |
|---|---|---|
| **1** | `ret_1d` | Returns / Momentum |
| **2** | `logret_1d` | Returns / Momentum |
| **3** | `ret_5d` | Returns / Momentum |
| **4** | `ret_20d` | Returns / Momentum |
| **5** | `ret_60d` | Returns / Momentum |
| **6** | `ret_252d` | Returns / Momentum |
| **7** | `ret_accel_5_20` | Returns / Momentum |
| **8** | `ret_accel_20_60` | Returns / Momentum |
| **9** | `mom_pct_20d_252w` | Returns / Momentum |
| **10** | `sma_10` | Trend / Moving Averages |
| **11** | `sma_20` | Trend / Moving Averages |
| **12** | `sma_50` | Trend / Moving Averages |
| **13** | `sma_200` | Trend / Moving Averages |
| **14** | `ema_12` | Trend / Moving Averages |
| **15** | `ema_26` | Trend / Moving Averages |
| **16** | `sma_20_slope` | Trend / Moving Averages |
| **17** | `sma_50_slope` | Trend / Moving Averages |
| **18** | `dist_sma_20` | Trend / Moving Averages |
| **19** | `dist_sma_20_pct` | Trend / Moving Averages |
| **20** | `dist_sma_50` | Trend / Moving Averages |
| **21** | `dist_sma_50_pct` | Trend / Moving Averages |
| **22** | `dist_sma_200` | Trend / Moving Averages |
| **23** | `dist_sma_200_pct` | Trend / Moving Averages |
| **24** | `dist_ema_12` | Trend / Moving Averages |
| **25** | `dist_ema_12_pct` | Trend / Moving Averages |
| **26** | `dist_ema_26` | Trend / Moving Averages |
| **27** | `dist_ema_26_pct` | Trend / Moving Averages |
| **28** | `ma50_ma200_spread` | Trend / Moving Averages |
| **29** | `ma50_ma200_spread_pct` | Trend / Moving Averages |
| **30** | `macd` | MACD |
| **31** | `macd_signal` | MACD |
| **32** | `macd_hist` | MACD |
| **33** | `macd_slope_9` | MACD |
| **34** | `macd_hist_slope_9` | MACD |
| **35** | `macd_z_252` | MACD |
| **36** | `rsi_14` | RSI |
| **37** | `rsi_pct_252` | RSI |
| **38** | `vol_20` | Volatility / ATR |
| **39** | `vol_60` | Volatility / ATR |
| **40** | `atr_14` | Volatility / ATR |
| **41** | `atr_pct_14` | Volatility / ATR |
| **42** | `vol20_pct_252` | Volatility / ATR |
| **43** | `atrpct14_pct_252` | Volatility / ATR |
| **44** | `vol_of_vol_20_60` | Volatility / ATR |
| **45** | `bb_mid_20` | Bollinger Bands |
| **46** | `bb_upper_20` | Bollinger Bands |
| **47** | `bb_lower_20` | Bollinger Bands |
| **48** | `bb_bw_20` | Bollinger Bands |
| **49** | `bb_pctb_20` | Bollinger Bands |
| **50** | `dist_bb_upper_20` | Bollinger Bands |
| **51** | `dist_bb_lower_20` | Bollinger Bands |
| **52** | `zscore_20` | Mean Reversion |
| **53** | `dev_mean_20` | Mean Reversion |
| **54** | `dev_mean_20_pct` | Mean Reversion |
| **55** | `stoch_k_14` | Stochastic |
| **56** | `stoch_d_14` | Stochastic |
| **57** | `hl_range_ratio_14` | Volume / Range |
| **58** | `adv_20` | Volume / Range |
| **59** | `vol_shock_20` | Volume / Range |
| **60** | `vol_z_20` | Volume / Range |
| **61** | `vol_x_ret` | Volume / Range |
| **62** | `participation_rate` | Volume / Range |
| **63** | `drawdown` | Risk |
| **64** | `drawdown_duration` | Risk |
| **65** | `roll_skew_60` | Risk |
| **66** | `roll_kurt_60` | Risk |
| **67** | `downside_dev_60` | Risk |
| **68** | `beta_252` | Beta / Correlation |
| **69** | `corr_252` | Beta / Correlation |
| **70** | `regime_trend` | Regime |
| **71** | `regime_vol` | Regime |

---

## Plots Reference

27 chart types. Pass `plot_ids` as a list of integers.

| ID | Name | Category | Notes |
|---|---|---|---|
| **1** | `equity_curve_linear` | Performance | |
| **2** | `equity_curve_log` | Performance | |
| **3** | `equity_vs_benchmark` | Performance | Requires `benchmark` |
| **4** | `daily_return_ts` | Performance | |
| **5** | `rolling_sharpe` | Performance | Default window: 63 bars |
| **6** | `rolling_sortino` | Performance | |
| **7** | `rolling_volatility` | Performance | |
| **8** | `rolling_beta` | Performance | Requires `benchmark` |
| **9** | `rolling_alpha` | Performance | Requires `benchmark` |
| **10** | `drawdown_underwater` | Drawdown | |
| **11** | `drawdown_duration` | Drawdown | |
| **12** | `drawdown_distribution` | Drawdown | |
| **13** | `var_over_time` | Risk | Default q: 0.05 |
| **14** | `cvar_over_time` | Risk | |
| **15** | `tail_risk_histogram` | Risk | Default bins: 60 |
| **16** | `trade_return_distribution` | Trades | |
| **17** | `win_loss_overlay` | Trades | |
| **18** | `expectancy_over_time` | Trades | |
| **19** | `trade_duration_vs_return` | Trades | |
| **20** | `performance_by_volatility_regime` | Regime | Requires feature ID 71 |
| **21** | `performance_by_trend_regime` | Regime | Requires feature ID 70 |
| **22** | `performance_bull_vs_bear` | Regime | Requires `benchmark` |
| **23** | `feature_correlation_heatmap` | Features | |
| **24** | `volume_ts` | Volume | |
| **25** | `volume_shock_20` | Volume | Default window: 20 |
| **26** | `trade_participation_ts` | Volume | |
| **27** | `transaction_costs_ts` | Volume | |

---

## Backtest Configuration

All fields are optional with sensible defaults.

| Field | Type | Default | Description |
|---|---|---|---|
| `initial_cash` | float | 10,000 | Starting portfolio value |
| `max_leverage` | float | 1.0 | Maximum leverage ratio |
| `allow_margin` | bool | false | Allow short selling |
| `exec_horizon` | string | "swing" | "intraday", "swing", or "longterm" |
| `asset_type` | string | "equities" | "equities" or "crypto" |
| `max_participation` | float | null | Max % of daily volume (0.0–1.0) |
| `fee_bps` | float | 1.0 | Commission fee in basis points |
| `half_spread_bps` | float | 2.0 | Half bid-ask spread in bps |
| `base_slippage_bps` | float | 1.0 | Base slippage in bps |
| `impact_coeff` | float | 1.0 | Market impact coefficient |
| `rebalance_mode` | string | "on_signal_change" | When to rebalance |
| `buy_threshold` | float | 0.10 | Signal threshold to enter long |
| `sell_threshold` | float | -0.10 | Signal threshold to exit |
| `risk_free_annual` | float | 0.0 | Risk-free rate for Sharpe/Sortino |
| `periods_per_year` | int | 252 | Trading days per year |

### Execution Model

The backtest engine models realistic execution costs:

- **Slippage:** Base slippage + volume-dependent impact
- **Spread:** Half bid-ask spread applied on each trade
- **Fees:** Commission per trade
- **Participation rate:** Limits trade size to a percentage of daily volume
- **Presets** vary by `exec_horizon` and `asset_type` (e.g., crypto has wider spreads)

---

## Authentication

When `API_KEY` is set on the server, all endpoints except `/health` require:

```
Authorization: Bearer YOUR_API_KEY
```

In the SDK:
```python
sim = CobwebSim(base_url="...", api_key="YOUR_API_KEY")
```

When `API_KEY` is not set (dev mode), authentication is disabled.

---

## Rate Limiting

Default: **60 requests per minute** per IP address.

When exceeded, the API returns `429 Too Many Requests` with a `Retry-After` header.

---

## Examples

### Example 1: Compute RSI and Bollinger Bands

```python
from cobweb_py import CobwebSim

sim = CobwebSim(base_url="https://web-production-83f3e.up.railway.app", api_key="YOUR_KEY")

result = sim.enrich("aapl.csv", feature_ids=[36, 37, 45, 46, 47, 48, 49])
# Features: rsi_14, rsi_pct_252, bb_mid_20, bb_upper_20, bb_lower_20, bb_bw_20, bb_pctb_20

for row in result["rows"][-3:]:
    print(f"{row['timestamp']}: RSI={row.get('rsi_14', 'N/A'):.1f}, BB%B={row.get('bb_pctb_20', 'N/A'):.2f}")
```

### Example 2: Score + Backtest + Charts

```python
from cobweb_py import CobwebSim, score_by_id, to_signals, print_signal
from cobweb_py.plots import save_equity_plot, save_api_payloads_to_html

sim = CobwebSim(base_url="https://web-production-83f3e.up.railway.app", api_key="YOUR_KEY")

# 1. Enrich
enriched = sim.enrich("aapl.csv", feature_ids=[1, 36, 40])

# 2. Score
scores = score_by_id(enriched["rows"], {36: 0.4, 1: 0.3, 40: 0.3})

# 3. Convert to signals
signals = to_signals(scores, entry_th=0.15, exit_th=0.05)

# 4. Backtest
bt = sim.backtest("aapl.csv", signals=signals, plot_ids=[1, 4, 5, 10, 16])

# 5. View results
print(f"Return: {bt['metrics']['total_return']:.1%}")
print(f"Sharpe: {bt['metrics']['sharpe_ann']:.2f}")
print(f"Max DD: {bt['metrics']['max_drawdown']:.1%}")
print_signal(bt)

# 6. Save charts
save_equity_plot(bt, "equity.html")
save_api_payloads_to_html(bt["plots"], "charts/")
```

### Example 3: Pipeline with multiple strategies

```python
from cobweb_py import Pipeline

pipe = Pipeline(
    base_url="https://web-production-83f3e.up.railway.app",
    data="aapl.csv",
    feature_ids=[1, 11, 36, 40, 52],
    api_key="YOUR_KEY",
)
pipe.enrich()

# Momentum strategy
r1 = pipe.run(weights={1: 0.6, 36: 0.4}, entry_th=0.2, exit_th=0.05)

# Mean reversion strategy
r2 = pipe.run(weights={52: 0.5, 36: 0.5}, entry_th=0.1, exit_th=-0.1)

# Compare
print(f"Momentum Sharpe:       {r1['metrics']['sharpe_ann']:.2f}")
print(f"Mean Reversion Sharpe: {r2['metrics']['sharpe_ann']:.2f}")
```

---

## Data Format

The API accepts OHLCV data in this format:

```json
{
  "rows": [
    {"timestamp": "2024-01-02", "open": 150.0, "high": 152.0, "low": 149.0, "close": 151.0, "volume": 1000000},
    {"timestamp": "2024-01-03", "open": 151.0, "high": 153.0, "low": 150.0, "close": 152.5, "volume": 1200000},
    ...
  ]
}
```

The SDK accepts: CSV file path, pandas DataFrame, list of dicts, or the above dict format.

**Requirements:**
- Minimum 20 rows, maximum 10,000
- `open`, `high`, `low`, `close` are required (> 0, finite)
- `high` must be >= `low`
- `volume` and `timestamp` are optional

---

## License

MIT
