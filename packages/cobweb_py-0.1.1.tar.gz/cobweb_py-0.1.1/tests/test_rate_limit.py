# tests/test_rate_limit.py

import pytest
from app.rate_limit import RateLimiter
from fastapi import HTTPException


class TestRateLimiter:
    def test_allows_under_limit(self):
        rl = RateLimiter(max_rpm=5)
        for _ in range(5):
            remaining, _ = rl.check("ip1")
        assert remaining == 0  # used all 5

    def test_blocks_over_limit(self):
        rl = RateLimiter(max_rpm=3)
        for _ in range(3):
            rl.check("ip1")
        with pytest.raises(HTTPException) as exc_info:
            rl.check("ip1")
        assert exc_info.value.status_code == 429
        assert "Rate limit exceeded" in exc_info.value.detail

    def test_retry_after_header(self):
        rl = RateLimiter(max_rpm=1)
        rl.check("ip1")
        with pytest.raises(HTTPException) as exc_info:
            rl.check("ip1")
        assert "Retry-After" in exc_info.value.headers

    def test_separate_keys_independent(self):
        rl = RateLimiter(max_rpm=2)
        rl.check("ip1")
        rl.check("ip1")
        # ip1 is at limit, ip2 should be fine
        remaining, _ = rl.check("ip2")
        assert remaining == 1

    def test_disabled_when_zero(self):
        rl = RateLimiter(max_rpm=0)
        # Should never block
        for _ in range(1000):
            rl.check("ip1")

    def test_remaining_decreases(self):
        rl = RateLimiter(max_rpm=5)
        r1, _ = rl.check("ip1")
        r2, _ = rl.check("ip1")
        assert r1 == 4
        assert r2 == 3
