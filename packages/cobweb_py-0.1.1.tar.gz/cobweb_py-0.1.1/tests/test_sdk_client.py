"""Tests for cobweb_py.client — _to_rows, _normalize_ohlcv_keys, BacktestConfig, CobwebError."""

import pytest
import pandas as pd

from cobweb_py.client import _to_rows, _normalize_ohlcv_keys, CobwebError, BacktestConfig


# ─── Helpers ───────────────────────────────────────────────────────────


def _make_rows(n, start_price=100.0):
    """Generate n OHLCV row dicts with lowercase keys."""
    rows = []
    for i in range(n):
        c = start_price + i * 0.1
        rows.append({
            "timestamp": f"2024-01-{(i % 28) + 1:02d}",
            "open": round(c - 0.1, 4),
            "high": round(c + 0.5, 4),
            "low": round(c - 0.5, 4),
            "close": round(c, 4),
            "volume": 1000.0 + i,
        })
    return rows


# ─── _to_rows ──────────────────────────────────────────────────────────


class TestToRows:
    def test_from_list_of_dicts(self):
        rows = _make_rows(25)
        result = _to_rows(rows)
        assert isinstance(result, list)
        assert len(result) == 25
        assert all(isinstance(r, dict) for r in result)

    def test_from_dict_with_rows_key(self):
        rows = _make_rows(25)
        result = _to_rows({"rows": rows})
        assert isinstance(result, list)
        assert len(result) == 25

    def test_from_dataframe(self):
        rows = _make_rows(25)
        df = pd.DataFrame(rows)
        # Capitalize columns to test case normalization
        df = df.rename(columns={
            "open": "Open", "high": "High",
            "low": "Low", "close": "Close",
            "volume": "Volume", "timestamp": "timestamp",
        })
        result = _to_rows(df)
        assert isinstance(result, list)
        assert len(result) == 25
        # All OHLCV keys should be lowercase
        for r in result:
            assert "open" in r
            assert "close" in r

    def test_unsupported_type_raises(self):
        with pytest.raises(CobwebError, match="Unsupported data input"):
            _to_rows(42)

    def test_too_few_rows_list_accepted(self):
        # _to_rows from list does NOT enforce 20-row minimum (only DataFrame path does)
        rows = _make_rows(10)
        result = _to_rows(rows)
        assert len(result) == 10

    def test_exactly_20_rows(self):
        rows = _make_rows(20)
        result = _to_rows(rows)
        assert len(result) == 20

    def test_empty_list_accepted(self):
        # An empty list passes the isinstance check but won't fail on < 20
        # because the normalize path returns early for empty lists
        result = _to_rows([])
        assert result == []

    def test_dataframe_too_few_rows_raises(self):
        rows = _make_rows(10)
        df = pd.DataFrame(rows)
        df = df.rename(columns={
            "open": "Open", "high": "High",
            "low": "Low", "close": "Close",
        })
        with pytest.raises(CobwebError, match="at least 20 rows"):
            _to_rows(df)


# ─── _normalize_ohlcv_keys ────────────────────────────────────────────


class TestNormalizeOhlcvKeys:
    def test_capitalized_keys_lowered(self):
        rows = [{"Open": 1.0, "High": 2.0, "Low": 0.5, "Close": 1.5, "Volume": 100}]
        result = _normalize_ohlcv_keys(rows)
        assert result[0]["open"] == 1.0
        assert result[0]["high"] == 2.0
        assert result[0]["low"] == 0.5
        assert result[0]["close"] == 1.5
        assert result[0]["volume"] == 100

    def test_already_lowercase_fast_path(self):
        rows = [{"open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "volume": 100}]
        result = _normalize_ohlcv_keys(rows)
        # Should return the same list object (fast path, no copy)
        assert result is rows

    def test_empty_list_returns_empty(self):
        result = _normalize_ohlcv_keys([])
        assert result == []

    def test_non_ohlcv_keys_preserved(self):
        rows = [{"Open": 1.0, "High": 2.0, "Low": 0.5, "Close": 1.5, "MyCustom": "abc"}]
        result = _normalize_ohlcv_keys(rows)
        assert result[0]["MyCustom"] == "abc"
        assert result[0]["open"] == 1.0


# ─── BacktestConfig ───────────────────────────────────────────────────


class TestBacktestConfig:
    def test_defaults(self):
        cfg = BacktestConfig()
        assert cfg.initial_cash == 10_000.0
        assert cfg.exec_horizon == "swing"
        assert cfg.asset_type == "equities"
        assert cfg.fee_bps == 1.0

    def test_to_dict_has_initial_cash(self):
        d = BacktestConfig().to_dict()
        assert isinstance(d, dict)
        assert "initial_cash" in d
        assert d["initial_cash"] == 10_000.0

    def test_to_dict_custom_values(self):
        cfg = BacktestConfig(initial_cash=50_000, fee_bps=0.5, exec_horizon="longterm")
        d = cfg.to_dict()
        assert d["initial_cash"] == 50_000
        assert d["fee_bps"] == 0.5
        assert d["exec_horizon"] == "longterm"

    def test_to_dict_excludes_none(self):
        cfg = BacktestConfig()
        d = cfg.to_dict()
        # max_participation defaults to None, should be excluded
        assert "max_participation" not in d


# ─── CobwebError ──────────────────────────────────────────────────────


class TestCobwebError:
    def test_is_runtime_error(self):
        assert issubclass(CobwebError, RuntimeError)

    def test_message_preserved(self):
        err = CobwebError("something failed")
        assert str(err) == "something failed"

    def test_raise_and_catch(self):
        with pytest.raises(CobwebError, match="test error"):
            raise CobwebError("test error")
