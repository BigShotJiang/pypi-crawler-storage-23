"""Tests for cobweb_py.plots — payload_to_figure, _payload_to_df, helpers, and save functions."""

import pytest
import plotly.graph_objects as go
import pandas as pd

from cobweb_py.plots import (
    payload_to_figure,
    _payload_to_df,
    _label,
    _make_title,
    save_equity_plot,
    save_api_payloads_to_html,
)


# ──────────────────────────────────────────────
# payload_to_figure
# ──────────────────────────────────────────────


class TestPayloadToFigureTimeSeries:
    """Time-series payloads (t + value lists) produce a Figure with traces."""

    def test_basic_timeseries(self):
        payload = {"t": [1, 2, 3], "equity": [100, 101, 102]}
        fig = payload_to_figure(payload)
        assert isinstance(fig, go.Figure)
        assert len(fig.data) >= 1

    def test_multiple_series(self):
        payload = {"t": [1, 2, 3], "equity": [100, 101, 102], "cash": [50, 49, 48]}
        fig = payload_to_figure(payload)
        assert isinstance(fig, go.Figure)
        assert len(fig.data) == 2


class TestPayloadToFigureHistogram:
    """Histogram payloads (bins + counts) produce a Figure."""

    def test_basic_histogram(self):
        payload = {"bins": [0.1, 0.2], "counts": [5, 3]}
        fig = payload_to_figure(payload)
        assert isinstance(fig, go.Figure)
        assert len(fig.data) == 1

    def test_histogram_trace_is_bar(self):
        payload = {"bins": [0.1, 0.2, 0.3], "counts": [5, 3, 7]}
        fig = payload_to_figure(payload)
        assert isinstance(fig.data[0], go.Bar)


class TestPayloadToFigureSecondaryY:
    """Payloads with _secondary_y create a dual-axis figure."""

    def test_secondary_y_creates_two_traces(self):
        payload = {
            "t": [1, 2],
            "equity": [100, 101],
            "pos_units": [10, 11],
            "_secondary_y": ["pos_units"],
        }
        fig = payload_to_figure(payload)
        assert isinstance(fig, go.Figure)
        assert len(fig.data) == 2


class TestPayloadToFigureEdgeCases:
    """Edge cases: unrecognised payloads and empty data."""

    def test_unrecognised_payload_returns_none(self):
        payload = {"foo": "bar"}
        fig = payload_to_figure(payload)
        assert fig is None

    def test_empty_t_returns_none(self):
        payload = {"t": []}
        fig = payload_to_figure(payload)
        assert fig is None

    def test_string_payload_returns_none(self):
        fig = payload_to_figure("not a dict")
        assert fig is None

    def test_none_payload_returns_none(self):
        fig = payload_to_figure(None)
        assert fig is None

    def test_empty_histogram_returns_none(self):
        payload = {"bins": [], "counts": []}
        fig = payload_to_figure(payload)
        assert fig is None


# ──────────────────────────────────────────────
# _payload_to_df
# ──────────────────────────────────────────────


class TestPayloadToDfTimeSeries:
    """Time-series payloads produce a DataFrame with t column."""

    def test_timeseries_has_t_column(self):
        payload = {"t": [1, 2, 3], "equity": [100, 101, 102]}
        df = _payload_to_df(payload)
        assert isinstance(df, pd.DataFrame)
        assert "t" in df.columns
        assert "equity" in df.columns
        assert len(df) == 3


class TestPayloadToDfHistogram:
    """Histogram payloads produce a DataFrame with value and count columns."""

    def test_histogram_columns(self):
        payload = {"bins": [0.1, 0.2], "counts": [5, 3]}
        df = _payload_to_df(payload)
        assert isinstance(df, pd.DataFrame)
        assert "value" in df.columns
        assert "count" in df.columns
        assert len(df) == 2


class TestPayloadToDfSkipsPrivateKeys:
    """Keys starting with underscore are excluded from the DataFrame."""

    def test_secondary_y_not_in_columns(self):
        payload = {
            "t": [1, 2],
            "equity": [100, 101],
            "pos_units": [10, 11],
            "_secondary_y": ["pos_units"],
        }
        df = _payload_to_df(payload)
        assert "_secondary_y" not in df.columns
        assert "t" in df.columns
        assert "equity" in df.columns
        assert "pos_units" in df.columns


# ──────────────────────────────────────────────
# _label
# ──────────────────────────────────────────────


class TestLabel:
    """_label returns human-readable axis labels."""

    def test_t_label(self):
        assert _label("t") == "Time"

    def test_equity_label(self):
        assert _label("equity") == "Equity"

    def test_custom_snake_case(self):
        result = _label("some_custom")
        assert result == "Some Custom"

    def test_empty_string(self):
        assert _label("") == ""

    def test_close_label(self):
        assert _label("Close") == "Close"

    def test_volume_label(self):
        assert _label("volume") == "Volume"


# ──────────────────────────────────────────────
# _make_title
# ──────────────────────────────────────────────


class TestMakeTitle:
    """_make_title joins non-empty parts with ' - '."""

    def test_two_parts(self):
        assert _make_title("A", "B") == "A - B"

    def test_empty_parts_fallback(self):
        assert _make_title("", "") == "Plot"

    def test_single_part(self):
        assert _make_title("Only") == "Only"

    def test_three_parts(self):
        assert _make_title("X", "Y", "Z") == "X - Y - Z"

    def test_mixed_empty_and_nonempty(self):
        result = _make_title("", "B", "")
        assert result == "B"

    def test_whitespace_only_parts_skipped(self):
        result = _make_title("  ", "B")
        # " " is truthy and stripped, so may or may not be included
        assert "B" in result


# ──────────────────────────────────────────────
# save_equity_plot (integration with tmp_path)
# ──────────────────────────────────────────────


class TestSaveEquityPlot:
    """save_equity_plot writes an HTML file from a backtest result."""

    def test_creates_file(self, sample_backtest_result, tmp_path):
        out_html = tmp_path / "equity_test.html"
        result_path = save_equity_plot(
            sample_backtest_result, out_html=str(out_html),
        )
        assert result_path == str(out_html)
        assert out_html.exists()
        content = out_html.read_text(encoding="utf-8")
        assert len(content) > 100  # non-trivial HTML content
        assert "<" in content  # valid HTML

    def test_contains_plotly_js(self, sample_backtest_result, tmp_path):
        out_html = tmp_path / "equity_plotly.html"
        save_equity_plot(sample_backtest_result, out_html=str(out_html))
        content = out_html.read_text(encoding="utf-8")
        assert "plotly" in content.lower()


# ──────────────────────────────────────────────
# save_api_payloads_to_html (integration with tmp_path)
# ──────────────────────────────────────────────


class TestSaveApiPayloadsToHtml:
    """save_api_payloads_to_html writes one HTML file per payload."""

    def test_creates_files(self, sample_plot_payloads, tmp_path):
        out_dir = tmp_path / "plots_out"
        written = save_api_payloads_to_html(
            sample_plot_payloads, out_dir=str(out_dir),
        )
        assert isinstance(written, list)
        assert len(written) > 0
        for path_str in written:
            from pathlib import Path
            p = Path(path_str)
            assert p.exists(), f"Expected file to exist: {path_str}"
            assert p.suffix == ".html"

    def test_file_count_matches_payloads(self, sample_plot_payloads, tmp_path):
        out_dir = tmp_path / "plots_count"
        written = save_api_payloads_to_html(
            sample_plot_payloads, out_dir=str(out_dir),
        )
        assert len(written) == len(sample_plot_payloads)

    def test_empty_payloads_returns_empty_list(self, tmp_path):
        out_dir = tmp_path / "empty_plots"
        written = save_api_payloads_to_html({}, out_dir=str(out_dir))
        assert written == []

    def test_title_prefix_applied(self, tmp_path):
        payloads = {"test_ts": {"t": [1, 2, 3], "equity": [100, 101, 102]}}
        out_dir = tmp_path / "prefix_plots"
        written = save_api_payloads_to_html(
            payloads, out_dir=str(out_dir), title_prefix="MyPrefix",
        )
        assert len(written) == 1
        from pathlib import Path
        content = Path(written[0]).read_text(encoding="utf-8")
        assert "MyPrefix" in content
