"""Tests for app.sim.equity — compute_metrics."""

import numpy as np
import pandas as pd
import pytest

from app.sim.equity import compute_metrics


# ─── Helpers ───────────────────────────────────────────────────────────


def _equity_series(values):
    """Build a simple pd.Series from a list of equity values."""
    return pd.Series(values, dtype=float)


# ─── Tests ─────────────────────────────────────────────────────────────


class TestComputeMetrics:
    def test_monotonically_increasing(self):
        # Equity that only goes up: 100, 101, 102, ..., 149
        eq = _equity_series([100.0 + i for i in range(50)])
        m = compute_metrics(eq)
        assert m["total_return"] > 0
        assert m["sharpe_ann"] is not None and m["sharpe_ann"] > 0
        assert m["max_drawdown"] == 0.0  # never declines
        assert m["max_drawdown_duration_bars"] == 0

    def test_flat_equity(self):
        eq = _equity_series([100.0] * 50)
        m = compute_metrics(eq)
        assert m["total_return"] == pytest.approx(0.0)
        assert m["max_drawdown"] == pytest.approx(0.0)
        assert m["max_drawdown_duration_bars"] == 0
        assert m["mean_return_bar"] == pytest.approx(0.0)

    def test_drawdown_approx_50_pct(self):
        # Starts at 100, drops to 50, then stays at 50
        eq = _equity_series([100.0] * 10 + [50.0] * 10)
        m = compute_metrics(eq)
        assert m["max_drawdown"] == pytest.approx(-0.5, abs=0.01)
        assert m["max_drawdown_duration_bars"] > 0

    def test_single_bar(self):
        eq = _equity_series([100.0])
        m = compute_metrics(eq)
        assert m["final_equity"] == 100.0
        assert m["bars"] == 1
        # With only 1 bar, no return computations are possible
        assert "total_return" not in m

    def test_two_bars(self):
        eq = _equity_series([100.0, 110.0])
        m = compute_metrics(eq)
        assert m["final_equity"] == 110.0
        assert m["bars"] == 2
        assert m["total_return"] == pytest.approx(0.1)
        assert m["mean_return_bar"] == pytest.approx(0.1)

    def test_all_expected_keys_present(self):
        eq = _equity_series([100.0 + np.sin(i / 5) * 5 for i in range(100)])
        m = compute_metrics(eq)
        expected_keys = {
            "final_equity", "total_return", "max_drawdown",
            "max_drawdown_duration_bars", "mean_return_bar",
            "volatility_ann", "return_ann", "sharpe_ann",
            "sortino_ann", "var_hist_q", "var_bar", "cvar_bar",
            "skew", "kurtosis", "bars",
        }
        assert expected_keys.issubset(set(m.keys()))

    def test_custom_rf_rate(self):
        eq = _equity_series([100.0 + i * 0.5 for i in range(50)])
        m_zero = compute_metrics(eq, rf_rate=0.0)
        m_high = compute_metrics(eq, rf_rate=0.10)
        # Higher risk-free rate should reduce the Sharpe ratio
        if m_zero["sharpe_ann"] is not None and m_high["sharpe_ann"] is not None:
            assert m_high["sharpe_ann"] < m_zero["sharpe_ann"]

    def test_var_cvar_exist(self):
        np.random.seed(7)
        eq = _equity_series(100.0 + np.cumsum(np.random.randn(200) * 0.5))
        m = compute_metrics(eq, var_q=0.05)
        assert m["var_hist_q"] == 0.05
        assert isinstance(m["var_bar"], float)
        assert isinstance(m["cvar_bar"], float)
        # CVaR should be at least as bad as VaR (more negative)
        assert m["cvar_bar"] <= m["var_bar"]

    def test_negative_total_return(self):
        # Equity drops from 100 to 80
        eq = _equity_series([100.0 - i * 0.5 for i in range(40)])
        m = compute_metrics(eq)
        assert m["total_return"] < 0
        assert m["max_drawdown"] < 0

    def test_final_equity_matches_last_value(self):
        eq = _equity_series([100.0, 105.0, 103.0, 110.0])
        m = compute_metrics(eq)
        assert m["final_equity"] == pytest.approx(110.0)
        assert m["bars"] == 4
