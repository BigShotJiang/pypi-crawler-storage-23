"""Tests for app.features.core — indicators + compute_features engine."""

import numpy as np
import pandas as pd
import pytest

from app.features.core import rsi, atr, stoch_kd, compute_features, FEATURES


# ─── Helper ───

def _make_df(n=50, seed=42, include_volume=True):
    """Minimal OHLCV DataFrame for unit tests."""
    np.random.seed(seed)
    close = 100.0 + np.cumsum(np.random.randn(n) * 0.5)
    high = close + np.abs(np.random.randn(n)) * 0.3
    low = close - np.abs(np.random.randn(n)) * 0.3
    opn = close + np.random.uniform(-0.5, 0.5, n)
    df = pd.DataFrame({
        "Open": opn,
        "High": high,
        "Low": low,
        "Close": close,
    })
    if include_volume:
        df["Volume"] = np.random.randint(1000, 100_000, n).astype(float)
    return df


# ═══════════════════════════════════════════════
# RSI indicator
# ═══════════════════════════════════════════════

class TestRSI:
    def test_rsi_output_range(self):
        close = pd.Series(100.0 + np.cumsum(np.random.randn(100) * 0.5))
        r = rsi(close, period=14)
        valid = r.dropna()
        assert len(valid) > 0
        assert valid.min() >= 0.0
        assert valid.max() <= 100.0

    def test_rsi_constant_series(self):
        close = pd.Series([50.0] * 30)
        r = rsi(close, period=14)
        # Constant price => no gains or losses; RSI is NaN (0/0 case)
        valid = r.dropna()
        # Either all NaN or all ~50 depending on impl; key: no crash, no inf
        assert not np.any(np.isinf(r.values))

    def test_rsi_short_period(self):
        np.random.seed(99)
        close = pd.Series(100 + np.cumsum(np.random.randn(30) * 0.5))
        r = rsi(close, period=5)
        valid = r.dropna()
        assert len(valid) > 0
        assert valid.min() >= 0.0
        assert valid.max() <= 100.0


# ═══════════════════════════════════════════════
# ATR indicator
# ═══════════════════════════════════════════════

class TestATR:
    def test_atr_nonnegative(self):
        df = _make_df(50)
        a = atr(df["High"], df["Low"], df["Close"], period=14)
        valid = a.dropna()
        assert len(valid) > 0
        assert (valid >= 0.0).all()

    def test_atr_zero_range(self):
        """When H==L==C, ATR should be 0 (except for first-bar shift NaN)."""
        n = 30
        s = pd.Series([100.0] * n)
        a = atr(s, s, s, period=14)
        # After the first bar (shift produces NaN), all TR=0 → ATR≈0
        assert a.iloc[-1] == pytest.approx(0.0, abs=1e-10)


# ═══════════════════════════════════════════════
# Stochastic %K / %D
# ═══════════════════════════════════════════════

class TestStochKD:
    def test_stoch_output_range(self):
        df = _make_df(50)
        k, d = stoch_kd(df["High"], df["Low"], df["Close"], k_period=14, d_period=3)
        k_valid = k.dropna()
        d_valid = d.dropna()
        assert len(k_valid) > 0
        assert k_valid.min() >= 0.0
        assert k_valid.max() <= 100.0
        assert len(d_valid) > 0
        assert d_valid.min() >= 0.0
        assert d_valid.max() <= 100.0

    def test_stoch_returns_tuple(self):
        df = _make_df(30)
        result = stoch_kd(df["High"], df["Low"], df["Close"])
        assert isinstance(result, tuple)
        assert len(result) == 2


# ═══════════════════════════════════════════════
# compute_features — basic API
# ═══════════════════════════════════════════════

class TestComputeFeaturesAPI:
    def test_empty_feature_ids_no_extra_columns(self):
        df = _make_df(30)
        original_cols = set(df.columns)
        result = compute_features(df, feature_ids=[])
        # No extra feature columns added
        assert set(result.columns) == original_cols

    def test_none_feature_ids_no_extra_columns(self):
        df = _make_df(30)
        original_cols = set(df.columns)
        result = compute_features(df, feature_ids=None)
        # None defaults to empty list => no extra features
        assert set(result.columns) == original_cols

    def test_single_id_ret_1d(self):
        df = _make_df(30)
        result = compute_features(df, feature_ids=[1])
        assert "ret_1d" in result.columns

    def test_returns_group(self):
        df = _make_df(50)
        result = compute_features(df, feature_ids=[1, 2, 3])
        assert "ret_1d" in result.columns
        assert "logret_1d" in result.columns
        assert "ret_5d" in result.columns

    def test_macd_group(self):
        df = _make_df(50)
        result = compute_features(df, feature_ids=[30, 31, 32])
        assert "macd" in result.columns
        assert "macd_signal" in result.columns
        assert "macd_hist" in result.columns

    def test_unknown_id_raises_valueerror(self):
        df = _make_df(30)
        with pytest.raises(ValueError, match="Unknown feature_ids"):
            compute_features(df, feature_ids=[999])

    def test_missing_close_raises_valueerror(self):
        df = pd.DataFrame({"High": [1, 2], "Low": [0.5, 1.5]})
        with pytest.raises(ValueError, match="missing required columns"):
            compute_features(df, feature_ids=[1])


# ═══════════════════════════════════════════════
# compute_features — data quality
# ═══════════════════════════════════════════════

class TestComputeFeaturesQuality:
    def test_no_inf_in_output(self):
        df = _make_df(50)
        result = compute_features(df, feature_ids=[1, 36, 40, 45, 52])
        for col in result.columns:
            if result[col].dtype in (np.float64, np.float32, float):
                assert not np.any(np.isinf(result[col].values)), (
                    f"Inf found in column {col}"
                )

    def test_volume_features_without_volume_are_nan(self):
        df = _make_df(50, include_volume=False)
        result = compute_features(df, feature_ids=[58, 59, 60])
        # All volume-derived features should be NaN when Volume column missing
        for col in ["adv_20", "vol_shock_20", "vol_z_20"]:
            if col in result.columns:
                assert result[col].isna().all(), f"{col} should be all NaN without Volume"

    def test_beta_corr_without_benchmark_are_nan(self):
        df = _make_df(50)
        result = compute_features(df, feature_ids=[68, 69], benchmark_close=None)
        assert "beta_252" in result.columns
        assert "corr_252" in result.columns
        assert result["beta_252"].isna().all()
        assert result["corr_252"].isna().all()


# ═══════════════════════════════════════════════
# FEATURES registry sanity
# ═══════════════════════════════════════════════

class TestFeaturesRegistry:
    def test_71_features_registered(self):
        assert len(FEATURES) == 71

    def test_ids_are_1_to_71(self):
        assert set(FEATURES.keys()) == set(range(1, 72))

    def test_values_are_unique_strings(self):
        vals = list(FEATURES.values())
        assert len(vals) == len(set(vals))
        assert all(isinstance(v, str) for v in vals)


# ═══════════════════════════════════════════════
# Slow: compute all 71 features on 300-row data
# ═══════════════════════════════════════════════

@pytest.mark.slow
class TestAllFeatures:
    def test_all_71_features(self, ohlcv_df_300):
        all_ids = list(range(1, 72))
        result = compute_features(ohlcv_df_300, feature_ids=all_ids)
        for fid in all_ids:
            col = FEATURES[fid]
            assert col in result.columns, f"Feature {fid} ({col}) not in output"

    def test_all_features_no_inf(self, ohlcv_df_300):
        all_ids = list(range(1, 72))
        result = compute_features(ohlcv_df_300, feature_ids=all_ids)
        for col in result.columns:
            if result[col].dtype in (np.float64, np.float32, float):
                assert not np.any(np.isinf(result[col].values)), (
                    f"Inf found in column {col}"
                )
