"""Tests for enforce_feature_access in app.main."""

import pytest
from fastapi import HTTPException

from app.main import enforce_feature_access, PREMIUM_FEATURE_IDS


# ─── None / empty requested_ids ───


class TestEnforceFeatureAccessNoneOrEmpty:
    """When no features are requested, an empty list is returned."""

    def test_none_returns_empty_list(self):
        result = enforce_feature_access(requested_ids=None, entitlements={"free"})
        assert result == []

    def test_empty_list_returns_empty_list(self):
        result = enforce_feature_access(requested_ids=[], entitlements={"free"})
        assert result == []


# ─── Valid free-tier feature IDs ───


class TestEnforceFeatureAccessFreeTier:
    """Free users can access non-premium features."""

    def test_valid_ids_returned(self):
        result = enforce_feature_access(
            requested_ids=[1, 2, 3], entitlements={"free"},
        )
        assert result == [1, 2, 3]

    def test_single_valid_id(self):
        result = enforce_feature_access(
            requested_ids=[1], entitlements={"free"},
        )
        assert result == [1]

    def test_many_valid_ids(self):
        # IDs 1-9 are returns/momentum and should be valid
        ids = list(range(1, 10))
        result = enforce_feature_access(
            requested_ids=ids, entitlements={"free"},
        )
        assert result == ids


# ─── Unknown feature IDs ───


class TestEnforceFeatureAccessUnknownIds:
    """Unknown feature IDs raise HTTP 422."""

    def test_unknown_id_raises_422(self):
        with pytest.raises(HTTPException) as exc_info:
            enforce_feature_access(
                requested_ids=[999], entitlements={"free"},
            )
        assert exc_info.value.status_code == 422

    def test_unknown_id_detail_contains_id(self):
        with pytest.raises(HTTPException) as exc_info:
            enforce_feature_access(
                requested_ids=[999], entitlements={"free"},
            )
        detail = exc_info.value.detail
        assert 999 in detail["unknown"]

    def test_mix_valid_and_unknown_raises_422(self):
        with pytest.raises(HTTPException) as exc_info:
            enforce_feature_access(
                requested_ids=[1, 2, 888], entitlements={"free"},
            )
        assert exc_info.value.status_code == 422
        assert 888 in exc_info.value.detail["unknown"]


# ─── Premium feature gating ───


@pytest.mark.skipif(
    len(PREMIUM_FEATURE_IDS) == 0,
    reason="No premium features defined (PREMIUM_FEATURE_IDS is empty)",
)
class TestEnforceFeatureAccessPremiumBlocked:
    """Free users are blocked from premium features when they exist."""

    def test_premium_id_blocked_for_free_user(self):
        premium_id = next(iter(PREMIUM_FEATURE_IDS))
        with pytest.raises(HTTPException) as exc_info:
            enforce_feature_access(
                requested_ids=[premium_id], entitlements={"free"},
            )
        assert exc_info.value.status_code == 403

    def test_premium_id_detail_contains_blocked_ids(self):
        premium_id = next(iter(PREMIUM_FEATURE_IDS))
        with pytest.raises(HTTPException) as exc_info:
            enforce_feature_access(
                requested_ids=[premium_id], entitlements={"free"},
            )
        detail = exc_info.value.detail
        assert premium_id in detail["blocked_feature_ids"]


@pytest.mark.skipif(
    len(PREMIUM_FEATURE_IDS) == 0,
    reason="No premium features defined (PREMIUM_FEATURE_IDS is empty)",
)
class TestEnforceFeatureAccessProEntitlement:
    """Pro users can access premium features."""

    def test_pro_user_not_blocked(self):
        premium_id = next(iter(PREMIUM_FEATURE_IDS))
        result = enforce_feature_access(
            requested_ids=[premium_id], entitlements={"pro"},
        )
        assert premium_id in result

    def test_enterprise_user_not_blocked(self):
        premium_id = next(iter(PREMIUM_FEATURE_IDS))
        result = enforce_feature_access(
            requested_ids=[premium_id], entitlements={"enterprise"},
        )
        assert premium_id in result


# ─── String coercion ───


class TestEnforceFeatureAccessStringCoercion:
    """Feature IDs passed as strings are coerced to ints."""

    def test_string_ids_coerced(self):
        result = enforce_feature_access(
            requested_ids=["1", "2", "3"], entitlements={"free"},
        )
        assert result == [1, 2, 3]
