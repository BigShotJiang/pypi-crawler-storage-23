"""Tests for cobweb_py.scoring — zscore, score, auto_score, score_by_id, list helpers."""

import pytest
import numpy as np
import pandas as pd

from cobweb_py.scoring import (
    zscore,
    score,
    auto_score,
    score_by_id,
    list_features,
    list_plots,
    _resolve_category,
    _resolve_plot_id,
    FEATURES,
    FEATURE_CATS,
    PLOT_CATS,
)
from app.features.core import compute_features


# ─── Fixture: DataFrame with feature columns for scoring ───

@pytest.fixture
def scored_df(ohlcv_df_50):
    """ohlcv_df_50 enriched with ret_1d (1), sma_20 (11), and rsi_14 (36)."""
    return compute_features(ohlcv_df_50, [1, 11, 36])


# ═══════════════════════════════════════════════
# zscore
# ═══════════════════════════════════════════════

class TestZscore:
    def test_zscore_mean_approx_zero(self):
        s = pd.Series([1.0, 2.0, 3.0, 4.0, 5.0])
        z = zscore(s)
        assert z.mean() == pytest.approx(0.0, abs=1e-10)

    def test_zscore_constant_all_zero(self):
        s = pd.Series([5.0, 5.0, 5.0])
        z = zscore(s)
        assert (z == 0.0).all()

    def test_zscore_preserves_length(self):
        s = pd.Series(np.random.randn(20))
        z = zscore(s)
        assert len(z) == 20

    def test_zscore_with_nans(self):
        s = pd.Series([1.0, np.nan, 3.0, 4.0])
        z = zscore(s)
        assert len(z) == 4
        # NaN input stays NaN
        assert pd.isna(z.iloc[1])


# ═══════════════════════════════════════════════
# score (column-name weights)
# ═══════════════════════════════════════════════

class TestScore:
    def test_single_weight_correct_length(self, scored_df):
        result = score(scored_df, {"ret_1d": 1.0})
        assert len(result) == len(scored_df)
        assert all(isinstance(x, float) for x in result)

    def test_empty_weights_all_zeros(self, scored_df):
        result = score(scored_df, {})
        assert all(x == 0.0 for x in result)

    def test_multiple_weights(self, scored_df):
        result = score(scored_df, {"ret_1d": 0.5, "rsi_14": 0.5})
        assert len(result) == len(scored_df)

    def test_missing_column_treated_as_zero(self, scored_df):
        # "nonexistent_col" is not in df, should contribute 0
        result = score(scored_df, {"nonexistent_col": 1.0})
        assert len(result) == len(scored_df)


# ═══════════════════════════════════════════════
# auto_score
# ═══════════════════════════════════════════════

class TestAutoScore:
    def test_auto_score_returns_list_of_floats(self, scored_df):
        result = auto_score(scored_df)
        assert isinstance(result, list)
        assert len(result) == len(scored_df)
        assert all(isinstance(x, float) for x in result)


# ═══════════════════════════════════════════════
# score_by_id
# ═══════════════════════════════════════════════

class TestScoreById:
    def test_score_by_id_correct_length(self, scored_df):
        result = score_by_id(scored_df, {1: 0.5, 36: 0.5})
        assert len(result) == len(scored_df)
        assert all(isinstance(x, float) for x in result)

    def test_score_by_id_single_feature(self, scored_df):
        result = score_by_id(scored_df, {1: 1.0})
        assert len(result) == len(scored_df)

    def test_score_by_id_ma_feature_uses_signal(self, scored_df):
        # ID 11 = sma_20, should be converted to sma_signal when
        # ma_ids_use_signal=True (default)
        result = score_by_id(scored_df, {11: 1.0})
        assert len(result) == len(scored_df)


# ═══════════════════════════════════════════════
# list_features
# ═══════════════════════════════════════════════

class TestListFeatures:
    def test_list_features_all_71(self):
        result = list_features()
        assert len(result) == 71

    def test_list_features_returns_dicts(self):
        result = list_features()
        for item in result:
            assert "id" in item
            assert "name" in item
            assert "category" in item

    def test_list_features_rsi_category(self):
        result = list_features("rsi")
        assert len(result) == 2
        names = {r["name"] for r in result}
        assert "rsi_14" in names
        assert "rsi_pct_252" in names

    def test_list_features_no_match(self):
        result = list_features("xyz_nonexistent")
        assert len(result) == 0


# ═══════════════════════════════════════════════
# list_plots
# ═══════════════════════════════════════════════

class TestListPlots:
    def test_list_plots_all_27(self):
        result = list_plots()
        assert len(result) == 27

    def test_list_plots_returns_dicts(self):
        result = list_plots()
        for item in result:
            assert "id" in item
            assert "name" in item
            assert "category" in item


# ═══════════════════════════════════════════════
# _resolve_category
# ═══════════════════════════════════════════════

class TestResolveCategory:
    def test_exact_match(self):
        result = _resolve_category("rsi", FEATURE_CATS)
        assert result == ["rsi"]

    def test_prefix_multiple_matches(self):
        result = _resolve_category("vol", FEATURE_CATS)
        # "vol" is a prefix of both "volatility" and "volume"
        assert len(result) >= 2
        assert "volatility" in result
        assert "volume" in result

    def test_no_match(self):
        result = _resolve_category("xyz", FEATURE_CATS)
        assert result == []

    def test_substring_match(self):
        result = _resolve_category("corr", FEATURE_CATS)
        assert "beta_corr" in result

    def test_normalized_match(self):
        # "betacorr" normalizes to "betacorr"; "beta_corr" normalizes to "betacorr"
        result = _resolve_category("betacorr", FEATURE_CATS)
        assert result == ["beta_corr"]


# ═══════════════════════════════════════════════
# _resolve_plot_id
# ═══════════════════════════════════════════════

class TestResolvePlotId:
    def test_exact_match(self):
        pid = _resolve_plot_id("equity_curve_linear")
        assert pid == 1

    def test_nonexistent_raises_valueerror(self):
        with pytest.raises(ValueError, match="No plot matched"):
            _resolve_plot_id("nonexistent_plot_name_xyz")

    def test_ambiguous_raises_valueerror(self):
        # "equity" matches both "equity_curve_linear" and "equity_curve_log" (and equity_vs_benchmark)
        with pytest.raises(ValueError, match="Ambiguous"):
            _resolve_plot_id("equity")

    def test_unique_prefix(self):
        # "drawdown_under" uniquely matches "drawdown_underwater"
        pid = _resolve_plot_id("drawdown_underwater")
        assert pid == 10

    def test_daily_return(self):
        pid = _resolve_plot_id("daily_return_ts")
        assert pid == 4
