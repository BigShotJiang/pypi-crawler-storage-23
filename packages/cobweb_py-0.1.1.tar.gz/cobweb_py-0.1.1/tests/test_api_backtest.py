import pytest


def _payload(rows, signals, config=None, **kwargs):
    body = {
        "data": {"rows": rows},
        "signals": signals,
    }
    if config:
        body["config"] = config
    body.update(kwargs)
    return body


class TestBacktestEndpoint:
    def test_happy_path(self, client, ohlcv_rows_50):
        signals = [1.0] * 50
        resp = client.post("/backtest", json=_payload(ohlcv_rows_50, signals))
        assert resp.status_code == 200
        data = resp.json()
        assert "trades" in data
        assert "equity_curve" in data
        assert "metrics" in data
        assert "current_exposure" in data
        assert "current_signal" in data

    def test_with_features(self, client, ohlcv_rows_50):
        signals = [1.0] * 50
        resp = client.post("/backtest", json=_payload(
            ohlcv_rows_50, signals,
            compute_features=True, feature_ids=[1, 36],
        ))
        assert resp.status_code == 200

    def test_with_plot_ids(self, client, ohlcv_rows_50):
        signals = [1.0] * 50
        resp = client.post("/backtest", json=_payload(
            ohlcv_rows_50, signals, plot_ids=[1],
        ))
        assert resp.status_code == 200
        assert "plots" in resp.json()

    def test_missing_signals_422(self, client, ohlcv_rows_50):
        body = {"data": {"rows": ohlcv_rows_50}}
        resp = client.post("/backtest", json=body)
        assert resp.status_code == 422

    def test_bad_ohlc_422(self, client):
        rows = [{"open": 100, "high": 102, "low": 99}]
        resp = client.post("/backtest", json=_payload(rows, [1.0]))
        assert resp.status_code == 422

    def test_current_signal_valid(self, client, ohlcv_rows_50):
        signals = [1.0] * 50
        resp = client.post("/backtest", json=_payload(ohlcv_rows_50, signals))
        assert resp.json()["current_signal"] in ("buy", "sell", "hold")

    def test_equity_curve_length(self, client, ohlcv_rows_50):
        signals = [0.0] * 50
        resp = client.post("/backtest", json=_payload(ohlcv_rows_50, signals))
        assert resp.status_code == 200
        assert len(resp.json()["equity_curve"]) == 50

    def test_metrics_keys(self, client, ohlcv_rows_50):
        signals = [1.0] * 50
        resp = client.post("/backtest", json=_payload(ohlcv_rows_50, signals))
        metrics = resp.json()["metrics"]
        assert "final_equity" in metrics
        assert "total_return" in metrics
        assert "sharpe_ann" in metrics
