"""Tests for app.sim.backtest — run_backtest + exposure_to_signal."""

import pytest
import numpy as np

from app.sim.backtest import run_backtest, exposure_to_signal


# ═══════════════════════════════════════════════
# exposure_to_signal
# ═══════════════════════════════════════════════

class TestExposureToSignal:
    def test_positive_exposure_buy(self):
        label, strength = exposure_to_signal(0.5)
        assert label == "buy"
        assert 0.0 <= strength <= 1.0

    def test_negative_exposure_sell(self):
        label, strength = exposure_to_signal(-0.5)
        assert label == "sell"
        assert 0.0 <= strength <= 1.0

    def test_zero_exposure_hold(self):
        label, strength = exposure_to_signal(0.0)
        assert label == "hold"
        assert strength == 0.0

    def test_at_buy_threshold(self):
        label, _ = exposure_to_signal(0.10)
        assert label == "buy"

    def test_just_below_buy_threshold(self):
        label, strength = exposure_to_signal(0.09)
        assert label == "hold"
        assert strength == 0.0

    def test_at_sell_threshold(self):
        label, _ = exposure_to_signal(-0.10)
        assert label == "sell"

    def test_custom_thresholds(self):
        label, _ = exposure_to_signal(0.05, buy_threshold=0.05, sell_threshold=-0.05)
        assert label == "buy"

    def test_full_exposure_buy(self):
        label, strength = exposure_to_signal(1.0)
        assert label == "buy"
        assert strength == pytest.approx(1.0, abs=0.01)

    def test_full_exposure_sell(self):
        label, strength = exposure_to_signal(-1.0)
        assert label == "sell"
        assert strength == pytest.approx(1.0, abs=0.01)


# ═══════════════════════════════════════════════
# run_backtest — error handling
# ═══════════════════════════════════════════════

class TestRunBacktestErrors:
    def test_signals_none_raises_valueerror(self, ohlcv_df_50, default_config):
        with pytest.raises(ValueError, match="signals is required"):
            run_backtest(
                df=ohlcv_df_50,
                features=ohlcv_df_50,
                config=default_config,
                signals=None,
            )


# ═══════════════════════════════════════════════
# run_backtest — basic structure
# ═══════════════════════════════════════════════

class TestRunBacktestStructure:
    def test_long_only_has_required_keys(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert "trades" in result
        assert "equity_curve" in result
        assert "metrics" in result
        assert isinstance(result["trades"], list)
        assert isinstance(result["equity_curve"], list)
        assert isinstance(result["metrics"], dict)

    def test_long_only_has_trades(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        # Long signals should produce at least one trade
        assert len(result["trades"]) >= 1

    def test_equity_curve_length(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert len(result["equity_curve"]) == 50

    def test_current_signal_valid(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert result["current_signal"] in ("buy", "sell", "hold")

    def test_rewards_is_list_of_correct_length(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert isinstance(result["rewards"], list)
        assert len(result["rewards"]) == 50

    def test_signals_exec_shifted(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        # signals_exec is exposure shifted by 1, first value filled with 0.0
        assert result["signals_exec"][0] == pytest.approx(0.0)


# ═══════════════════════════════════════════════
# run_backtest — flat signals
# ═══════════════════════════════════════════════

class TestRunBacktestFlat:
    def test_flat_signals_equity_near_initial(self, ohlcv_df_50, flat_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=flat_signals_50,
        )
        # No exposure => equity stays at initial_cash (10000)
        final_equity = result["equity_curve"][-1]["equity"]
        assert final_equity == pytest.approx(10_000.0, abs=1.0)

    def test_flat_signals_few_or_no_trades(self, ohlcv_df_50, flat_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=flat_signals_50,
        )
        # Zero exposure => no trades should be triggered
        assert len(result["trades"]) == 0


# ═══════════════════════════════════════════════
# run_backtest — alternating signals
# ═══════════════════════════════════════════════

class TestRunBacktestAlternating:
    def test_alternating_signals_multiple_trades(
        self, ohlcv_df_50, alternating_signals_50, default_config
    ):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=alternating_signals_50,
        )
        # Alternating +1/-1 every bar should produce many trades
        assert len(result["trades"]) > 5


# ═══════════════════════════════════════════════
# run_backtest — full result keys
# ═══════════════════════════════════════════════

class TestRunBacktestFullResult:
    def test_all_expected_keys(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        expected_keys = {
            "trades", "equity_curve", "metrics",
            "current_exposure", "current_signal", "signal_strength",
            "rewards", "reward_components", "rebalance",
            "signals", "signals_exec", "tc_series",
        }
        assert expected_keys.issubset(set(result.keys()))

    def test_tc_series_length(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert len(result["tc_series"]) == 50

    def test_signals_length(self, ohlcv_df_50, long_signals_50, default_config):
        result = run_backtest(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            config=default_config,
            signals=long_signals_50,
        )
        assert len(result["signals"]) == 50
        assert len(result["signals_exec"]) == 50
