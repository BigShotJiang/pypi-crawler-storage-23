import pytest


def _payload(rows, feature_ids=None):
    body = {"data": {"rows": rows}}
    if feature_ids is not None:
        body["feature_ids"] = feature_ids
    return body


class TestFeaturesEndpoint:
    def test_happy_path(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50, feature_ids=[1, 10]))
        assert resp.status_code == 200
        data = resp.json()
        assert "rows" in data
        assert "feature_columns" in data
        assert "ret_1d" in data["feature_columns"]
        assert "sma_10" in data["feature_columns"]

    def test_no_feature_ids(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50))
        assert resp.status_code == 200
        assert resp.json()["feature_columns"] == []

    def test_empty_feature_ids(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50, feature_ids=[]))
        assert resp.status_code == 200
        assert resp.json()["feature_columns"] == []

    def test_unknown_feature_id_422(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50, feature_ids=[999]))
        assert resp.status_code == 422

    def test_bad_ohlc_missing_close_422(self, client):
        rows = [{"open": 100, "high": 102, "low": 99}]
        resp = client.post("/features", json=_payload(rows))
        assert resp.status_code == 422

    def test_response_row_count(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50, feature_ids=[1]))
        assert resp.status_code == 200
        assert len(resp.json()["rows"]) == 50

    def test_rows_contain_ohlcv(self, client, ohlcv_rows_50):
        resp = client.post("/features", json=_payload(ohlcv_rows_50, feature_ids=[1]))
        row = resp.json()["rows"][0]
        assert "Open" in row
        assert "Close" in row
