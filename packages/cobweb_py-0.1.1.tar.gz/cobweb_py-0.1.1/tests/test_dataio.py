import pytest
import pandas as pd
from app.schemas import OHLCRow, OHLCRequest
from app.dataio import ohlc_to_df


def _req(rows):
    return OHLCRequest(rows=[OHLCRow(**r) for r in rows])


class TestOhlcToDfHappyPath:
    def test_with_timestamps(self, ohlc_request_50):
        df = ohlc_to_df(ohlc_request_50)
        assert isinstance(df.index, pd.DatetimeIndex)
        assert df.index.name == "timestamp"
        assert list(df.columns[:4]) == ["Open", "High", "Low", "Close"]

    def test_with_volume(self, ohlc_request_50):
        df = ohlc_to_df(ohlc_request_50)
        assert "Volume" in df.columns

    def test_without_timestamps(self):
        rows = [{"open": 100, "high": 102, "low": 99, "close": 101}] * 20
        df = ohlc_to_df(_req(rows))
        assert df.index.name == "bar"
        assert not isinstance(df.index, pd.DatetimeIndex)

    def test_without_volume(self):
        rows = [{"open": 100, "high": 102, "low": 99, "close": 101}] * 20
        df = ohlc_to_df(_req(rows))
        assert "Volume" not in df.columns

    def test_output_dtypes_are_float(self, ohlc_request_50):
        df = ohlc_to_df(ohlc_request_50)
        for col in df.columns:
            assert df[col].dtype == float

    def test_row_count(self, ohlc_request_50):
        df = ohlc_to_df(ohlc_request_50)
        assert len(df) == 50

    def test_sorted_by_timestamp(self):
        rows = [
            {"timestamp": f"2024-01-{d:02d}", "open": 100, "high": 102, "low": 99, "close": 101}
            for d in range(25, 0, -1)
        ]
        df = ohlc_to_df(_req(rows))
        assert list(df.index) == sorted(df.index)


class TestOhlcToDfEdgeCases:
    def test_volume_all_nan_dropped(self):
        rows = [
            {"open": 100, "high": 102, "low": 99, "close": 101, "volume": None}
            for _ in range(20)
        ]
        df = ohlc_to_df(_req(rows))
        assert "Volume" not in df.columns

    def test_all_bad_timestamps_fallback_to_bar(self):
        rows = [
            {"timestamp": "garbage", "open": 100, "high": 102, "low": 99, "close": 101}
            for _ in range(20)
        ]
        df = ohlc_to_df(_req(rows))
        assert df.index.name == "bar"


class TestOhlcToDfErrors:
    def test_partial_bad_timestamps_raises(self):
        rows = [
            {"timestamp": f"2024-01-{d:02d}", "open": 100, "high": 102, "low": 99, "close": 101}
            for d in range(1, 21)
        ]
        rows[10]["timestamp"] = "not-a-date"  # inject one bad timestamp
        with pytest.raises(ValueError, match="Invalid timestamps"):
            ohlc_to_df(_req(rows))
