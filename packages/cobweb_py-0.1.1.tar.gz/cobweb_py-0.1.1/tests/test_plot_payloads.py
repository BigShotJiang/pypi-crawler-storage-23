"""Tests for app.plots.payloads — build_plot_payloads and PLOTS registry."""

import pytest
import pandas as pd
import numpy as np

from app.plots.payloads import build_plot_payloads, PLOTS


# ─── PLOTS registry ───────────────────────────────────────────────────


class TestPlotsRegistry:
    def test_contains_27_entries(self):
        assert len(PLOTS) == 27

    def test_ids_are_1_through_27(self):
        assert set(PLOTS.keys()) == set(range(1, 28))

    def test_all_values_are_strings(self):
        for v in PLOTS.values():
            assert isinstance(v, str)

    def test_known_plot_names(self):
        assert PLOTS[1] == "equity_curve_linear"
        assert PLOTS[4] == "daily_return_ts"
        assert PLOTS[10] == "drawdown_underwater"
        assert PLOTS[16] == "trade_return_distribution"


# ─── build_plot_payloads ───────────────────────────────────────────────


class TestBuildPlotPayloads:
    def test_default_plot_ids(self, ohlcv_df_50, sample_backtest_result):
        """Default (None) should produce plots for IDs [1, 4, 5, 10, 16]."""
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
        )
        expected_names = {PLOTS[i] for i in [1, 4, 5, 10, 16]}
        assert set(payloads.keys()) == expected_names

    def test_single_plot_equity_curve(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[1],
        )
        assert list(payloads.keys()) == ["equity_curve_linear"]

    def test_unknown_plot_id_raises(self, ohlcv_df_50, sample_backtest_result):
        with pytest.raises(ValueError, match="Unknown plot IDs"):
            build_plot_payloads(
                df=ohlcv_df_50,
                features=ohlcv_df_50,
                backtest=sample_backtest_result,
                requested_plot_ids=[999],
            )

    def test_plot_1_payload_keys(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[1],
        )
        p = payloads["equity_curve_linear"]
        assert "t" in p
        assert "equity" in p
        assert "cash" in p
        assert "pos_units" in p
        assert "_secondary_y" in p
        assert isinstance(p["t"], list)
        assert isinstance(p["equity"], list)
        assert len(p["t"]) == len(p["equity"])

    def test_plot_4_daily_return_ts(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[4],
        )
        p = payloads["daily_return_ts"]
        assert "t" in p
        assert "ret" in p
        assert isinstance(p["t"], list)
        assert isinstance(p["ret"], list)

    def test_histogram_plot_16(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[16],
        )
        p = payloads["trade_return_distribution"]
        assert "bins" in p
        assert "counts" in p
        assert isinstance(p["bins"], list)
        assert isinstance(p["counts"], list)
        assert len(p["bins"]) == len(p["counts"])

    def test_backtest_none_returns_empty(self, ohlcv_df_50):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=None,
        )
        assert payloads == {}

    def test_multiple_plot_ids(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[1, 4, 10],
        )
        assert "equity_curve_linear" in payloads
        assert "daily_return_ts" in payloads
        assert "drawdown_underwater" in payloads

    def test_drawdown_plot_10(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[10],
        )
        p = payloads["drawdown_underwater"]
        assert "t" in p
        assert "drawdown" in p
        assert isinstance(p["drawdown"], list)

    def test_rolling_sharpe_plot_5(self, ohlcv_df_50, sample_backtest_result):
        payloads = build_plot_payloads(
            df=ohlcv_df_50,
            features=ohlcv_df_50,
            backtest=sample_backtest_result,
            requested_plot_ids=[5],
        )
        p = payloads["rolling_sharpe"]
        assert "t" in p
        assert "rolling_sharpe" in p
        assert "window" in p
