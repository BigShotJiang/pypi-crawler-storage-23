"""Tests for app.sim.execution — resolve_exec_params and apply_execution_slice."""

import math
import pytest

from app.sim.execution import resolve_exec_params, apply_execution_slice, ExecParams


# ─── resolve_exec_params ───────────────────────────────────────────────


class TestResolveExecParams:
    def test_swing_equities_defaults(self):
        p = resolve_exec_params(horizon="swing", asset_type="equities")
        assert isinstance(p, ExecParams)
        assert p.fee_bps == 1.0
        assert p.half_spread_bps == 2.0
        assert p.base_slippage_bps == 1.0
        assert p.impact_coeff == 1.0
        assert p.max_participation == 0.08
        assert p.fallback_participation == 0.005
        assert p.default_vol_bps == 10.0

    def test_crypto_differs_from_equities(self):
        eq = resolve_exec_params(horizon="swing", asset_type="equities")
        cr = resolve_exec_params(horizon="swing", asset_type="crypto")
        # Crypto should have wider spreads, higher participation caps, etc.
        assert cr.half_spread_bps > eq.half_spread_bps
        assert cr.max_participation > eq.max_participation
        assert cr.impact_coeff > eq.impact_coeff

    def test_custom_fee_bps_override(self):
        p = resolve_exec_params(horizon="swing", asset_type="equities", fee_bps=5.0)
        assert p.fee_bps == 5.0
        # Other fields should remain at defaults
        assert p.half_spread_bps == 2.0

    def test_all_overrides(self):
        p = resolve_exec_params(
            horizon="intraday",
            asset_type="crypto",
            fee_bps=0.5,
            half_spread_bps=10.0,
            base_slippage_bps=3.0,
            impact_coeff=2.0,
            max_participation=0.5,
            fallback_participation=0.1,
            default_vol_bps=20.0,
        )
        assert p.fee_bps == 0.5
        assert p.half_spread_bps == 10.0
        assert p.base_slippage_bps == 3.0
        assert p.impact_coeff == 2.0
        assert p.max_participation == 0.5
        assert p.fallback_participation == 0.1
        assert p.default_vol_bps == 20.0

    def test_invalid_horizon_raises(self):
        with pytest.raises(ValueError, match="Invalid horizon"):
            resolve_exec_params(horizon="weekly", asset_type="equities")

    def test_invalid_asset_type_raises(self):
        with pytest.raises(ValueError, match="asset_type"):
            resolve_exec_params(horizon="swing", asset_type="forex")

    def test_frozen_dataclass(self):
        p = resolve_exec_params(horizon="swing", asset_type="equities")
        with pytest.raises(AttributeError):
            p.fee_bps = 99.0  # type: ignore[misc]

    def test_longterm_equities(self):
        p = resolve_exec_params(horizon="longterm", asset_type="equities")
        assert p.max_participation == 0.15
        assert p.half_spread_bps == 1.5
        assert p.impact_coeff == 0.8

    def test_intraday_equities(self):
        p = resolve_exec_params(horizon="intraday", asset_type="equities")
        assert p.max_participation == 0.02
        assert p.impact_coeff == 1.25


# ─── apply_execution_slice ─────────────────────────────────────────────


class TestApplyExecutionSlice:
    def test_zero_qty_returns_zeros(self):
        res = apply_execution_slice(100.0, 0.0, horizon="swing", asset_type="equities")
        assert res["signed_qty"] == 0.0
        assert res["remaining_qty"] == 0.0
        assert res["total_cost"] == 0.0
        assert res["exec_price"] == 100.0
        assert res["breakdown"]["spread"] == 0.0
        assert res["breakdown"]["slippage"] == 0.0
        assert res["breakdown"]["impact"] == 0.0
        assert res["breakdown"]["fee"] == 0.0

    def test_positive_buy(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=10000.0,
        )
        assert res["signed_qty"] > 0
        # Buy should push exec_price above ref_price (adverse cost)
        assert res["exec_price"] > 100.0
        assert res["total_cost"] > 0.0
        assert res["meta"]["direction"] == 1

    def test_negative_sell(self):
        res = apply_execution_slice(
            100.0, -50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=10000.0,
        )
        assert res["signed_qty"] < 0
        # Sell should push exec_price below ref_price (adverse cost)
        assert res["exec_price"] < 100.0
        assert res["total_cost"] > 0.0
        assert res["meta"]["direction"] == -1

    def test_volume_cap_limits_execution(self):
        # max_participation for swing/equities is 0.08
        # cap_qty = 0.08 * 100 = 8
        res = apply_execution_slice(
            100.0, 1000.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=100.0,
        )
        # Should only execute 8 units (0.08 * 100)
        assert res["signed_qty"] == pytest.approx(8.0)
        assert res["remaining_qty"] == pytest.approx(992.0)

    def test_remaining_qty_when_capped(self):
        res = apply_execution_slice(
            50.0, 500.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=200.0,
        )
        cap = 0.08 * 200  # 16
        assert res["signed_qty"] == pytest.approx(cap)
        assert res["remaining_qty"] == pytest.approx(500.0 - cap)

    def test_adv_fallback_when_bar_volume_missing(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=None,
            adv_qty=1000.0,
            use_adv_when_missing=True,
        )
        assert res["meta"]["liq_source"] == "adv"
        # cap_qty = 0.08 * 1000 = 80, desired=50 < 80 so fully filled
        assert res["signed_qty"] == pytest.approx(50.0)
        assert res["remaining_qty"] == pytest.approx(0.0)

    def test_no_volume_info_uses_fallback_participation(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=None,
            adv_qty=None,
        )
        assert res["meta"]["liq_source"] == "missing"
        # Should execute full desired qty (no cap), use fallback_participation for impact
        assert res["signed_qty"] == pytest.approx(50.0)
        assert res["remaining_qty"] == pytest.approx(0.0)

    def test_negative_ref_price_raises(self):
        with pytest.raises(ValueError, match="ref_price must be positive"):
            apply_execution_slice(-10.0, 100.0, horizon="swing", asset_type="equities")

    def test_zero_ref_price_raises(self):
        with pytest.raises(ValueError, match="ref_price must be positive"):
            apply_execution_slice(0.0, 100.0, horizon="swing", asset_type="equities")

    def test_breakdown_keys_present(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=10000.0,
        )
        assert set(res["breakdown"].keys()) == {"spread", "slippage", "impact", "fee"}
        for v in res["breakdown"].values():
            assert isinstance(v, float)
            assert v >= 0.0

    def test_meta_keys_present(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=10000.0,
        )
        expected_keys = {
            "direction", "participation", "impact_bps",
            "exec_adverse_bps_ex_fee", "cap_qty", "liq_source",
            "preset_horizon", "asset_type",
        }
        assert expected_keys.issubset(set(res["meta"].keys()))

    def test_total_cost_equals_sum_of_breakdown_plus_fee(self):
        res = apply_execution_slice(
            100.0, 50.0,
            horizon="swing", asset_type="equities",
            bar_volume_qty=10000.0,
        )
        bk = res["breakdown"]
        expected = bk["spread"] + bk["slippage"] + bk["impact"] + bk["fee"]
        assert res["total_cost"] == pytest.approx(expected, rel=1e-9)
