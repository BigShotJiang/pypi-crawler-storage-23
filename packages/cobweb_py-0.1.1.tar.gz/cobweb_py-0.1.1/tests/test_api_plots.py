"""Tests for POST /plots endpoint."""

import pytest


# ═══════════════════════════════════════════════
# Helper to build the /plots request body
# ═══════════════════════════════════════════════

def _plots_payload(
    ohlcv_rows,
    *,
    backtest_result=None,
    plot_ids=None,
    compute_features=False,
    feature_ids=None,
):
    body = {
        "data": {"rows": ohlcv_rows},
        "compute_features": compute_features,
    }
    if backtest_result is not None:
        body["backtest_result"] = backtest_result
    if plot_ids is not None:
        body["plot_ids"] = plot_ids
    if feature_ids is not None:
        body["feature_ids"] = feature_ids
    return body


# ═══════════════════════════════════════════════
# Happy path
# ═══════════════════════════════════════════════

class TestPlotsHappyPath:
    def test_plot_ids_1_4_with_backtest_result(
        self, client, ohlcv_rows_50, sample_backtest_result
    ):
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=sample_backtest_result,
            plot_ids=[1, 4],
            compute_features=False,
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 200
        data = resp.json()
        assert "payloads" in data
        payloads = data["payloads"]
        # plot 1 = equity_curve_linear, plot 4 = daily_return_ts
        assert "equity_curve_linear" in payloads
        assert "daily_return_ts" in payloads

    def test_correlation_plot_no_backtest(self, client, ohlcv_rows_50):
        """Plot 23 (correlation heatmap) works without backtest_result."""
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=None,
            plot_ids=[23],
            compute_features=False,
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 200
        data = resp.json()
        assert "payloads" in data


# ═══════════════════════════════════════════════
# Error cases
# ═══════════════════════════════════════════════

class TestPlotsErrors:
    def test_unknown_plot_id_422(self, client, ohlcv_rows_50, sample_backtest_result):
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=sample_backtest_result,
            plot_ids=[999],
            compute_features=False,
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 422

    def test_bad_ohlc_data_422(self, client):
        body = {
            "data": {"rows": [{"open": "bad", "high": "bad", "low": "bad", "close": "bad"}]},
            "compute_features": False,
            "plot_ids": [1],
        }
        resp = client.post("/plots", json=body)
        assert resp.status_code == 422


# ═══════════════════════════════════════════════
# With compute_features enabled
# ═══════════════════════════════════════════════

class TestPlotsWithFeatures:
    def test_regime_plots_with_compute_features(
        self, client, ohlcv_rows_50, sample_backtest_result
    ):
        """
        Plots 20 (vol_regime) and 21 (trend_regime) require feature columns.
        Pass compute_features=True + feature_ids=[70, 71] to produce them.
        """
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=sample_backtest_result,
            plot_ids=[20, 21],
            compute_features=True,
            feature_ids=[70, 71],
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 200
        data = resp.json()
        assert "payloads" in data
        payloads = data["payloads"]
        # Both plots should be present (may have empty data if not enough rows,
        # but the keys should exist)
        assert "performance_by_volatility_regime" in payloads
        assert "performance_by_trend_regime" in payloads


# ═══════════════════════════════════════════════
# Payload shape checks
# ═══════════════════════════════════════════════

class TestPlotsPayloadShape:
    def test_equity_curve_payload_has_t_and_equity(
        self, client, ohlcv_rows_50, sample_backtest_result
    ):
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=sample_backtest_result,
            plot_ids=[1],
            compute_features=False,
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 200
        ec = resp.json()["payloads"]["equity_curve_linear"]
        assert "t" in ec
        assert "equity" in ec
        assert isinstance(ec["t"], list)
        assert isinstance(ec["equity"], list)
        assert len(ec["t"]) == len(ec["equity"])

    def test_daily_return_payload_has_ret(
        self, client, ohlcv_rows_50, sample_backtest_result
    ):
        body = _plots_payload(
            ohlcv_rows_50,
            backtest_result=sample_backtest_result,
            plot_ids=[4],
            compute_features=False,
        )
        resp = client.post("/plots", json=body)
        assert resp.status_code == 200
        dr = resp.json()["payloads"]["daily_return_ts"]
        assert "t" in dr
        assert "ret" in dr
