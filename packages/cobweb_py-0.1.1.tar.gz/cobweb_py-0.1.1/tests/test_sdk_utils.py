"""Tests for cobweb_py.utils — to_signals, get_signal, fix_timestamps, align."""

import pytest

from cobweb_py.utils import to_signals, get_signal, fix_timestamps, align


# ─── to_signals ────────────────────────────────────────────────────────


class TestToSignals:
    def test_scores_above_entry_go_long(self):
        scores = [0.0, 0.0, 0.8, 0.9, 0.7]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2)
        # First two below threshold -> 0, third crosses -> 1, stays 1
        assert signals == [0.0, 0.0, 1.0, 1.0, 1.0]

    def test_scores_below_exit_go_flat(self):
        scores = [0.8, 0.6, 0.1, 0.0]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2)
        # Enters on first, stays in, exits on third (0.1 <= 0.2)
        assert signals == [1.0, 1.0, 0.0, 0.0]

    def test_hysteresis_stays_long_between_thresholds(self):
        scores = [0.6, 0.3, 0.3, 0.3, 0.1]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2)
        # Enters on 0.6, 0.3 is between thresholds so stays, exits at 0.1
        assert signals == [1.0, 1.0, 1.0, 1.0, 0.0]

    def test_with_shorts(self):
        scores = [0.0, -0.8, -0.6, -0.3, 0.0]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2, use_shorts=True)
        # 0.0 -> flat, -0.8 <= -0.5 -> short (-1), stays short, -0.3 stays,
        # 0.0 >= -0.2 -> exit short
        assert signals == [0.0, -1.0, -1.0, -1.0, 0.0]

    def test_shorts_negative_scores(self):
        scores = [-0.6, -0.7, 0.1, 0.6]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2, use_shorts=True)
        # -0.6 <= -0.5 -> short, stays short, 0.1 >= -0.2 -> exit,
        # 0.6 >= 0.5 -> long
        assert signals == [-1.0, -1.0, 0.0, 1.0]

    def test_empty_returns_empty(self):
        assert to_signals([], entry_th=0.5, exit_th=0.2) == []

    def test_all_below_threshold(self):
        scores = [0.1, 0.2, 0.3, 0.1]
        signals = to_signals(scores, entry_th=0.5, exit_th=0.2)
        assert signals == [0.0, 0.0, 0.0, 0.0]

    def test_single_score(self):
        signals = to_signals([0.9], entry_th=0.5, exit_th=0.2)
        assert signals == [1.0]


# ─── get_signal ────────────────────────────────────────────────────────


class TestGetSignal:
    def test_full_dict(self):
        bt = {
            "current_signal": "buy",
            "current_exposure": 0.87,
            "signal_strength": 0.72,
        }
        s = get_signal(bt)
        assert s["signal"] == "buy"
        assert s["exposure"] == pytest.approx(0.87)
        assert s["strength"] == pytest.approx(0.72)

    def test_empty_dict_defaults(self):
        s = get_signal({})
        assert s["signal"] == "hold"
        assert s["exposure"] == pytest.approx(0.0)
        assert s["strength"] == pytest.approx(0.0)

    def test_sell_signal(self):
        bt = {"current_signal": "sell", "current_exposure": -0.5, "signal_strength": 0.3}
        s = get_signal(bt)
        assert s["signal"] == "sell"
        assert s["exposure"] == pytest.approx(-0.5)

    def test_partial_dict_uses_defaults(self):
        bt = {"current_signal": "buy"}
        s = get_signal(bt)
        assert s["signal"] == "buy"
        assert s["exposure"] == 0.0
        assert s["strength"] == 0.0


# ─── fix_timestamps ───────────────────────────────────────────────────


class TestFixTimestamps:
    def test_dayfirst_format(self):
        rows = [
            {"timestamp": "14/09/2020", "close": 100.0},
            {"timestamp": "15/09/2020", "close": 101.0},
        ]
        result = fix_timestamps(rows, dayfirst=True)
        assert "rows" in result
        assert len(result["rows"]) == 2
        assert result["rows"][0]["timestamp"] == "2020-09-14 00:00:00"
        assert result["rows"][1]["timestamp"] == "2020-09-15 00:00:00"

    def test_drop_bad_removes_unparseable(self):
        rows = [
            {"timestamp": "2020-01-01", "close": 100.0},
            {"timestamp": "not-a-date", "close": 101.0},
            {"timestamp": "2020-01-03", "close": 102.0},
        ]
        result = fix_timestamps(rows, drop_bad=True)
        assert len(result["rows"]) == 2

    def test_sort_by_timestamp(self):
        rows = [
            {"timestamp": "15/03/2020", "close": 103.0},
            {"timestamp": "15/01/2020", "close": 100.0},
            {"timestamp": "15/02/2020", "close": 102.0},
        ]
        result = fix_timestamps(rows, sort=True, dayfirst=True)
        assert result["rows"][0]["timestamp"].startswith("2020-01-15")
        assert result["rows"][1]["timestamp"].startswith("2020-02-15")
        assert result["rows"][2]["timestamp"].startswith("2020-03-15")

    def test_custom_out_format(self):
        rows = [{"timestamp": "2020-01-15", "close": 100.0}]
        result = fix_timestamps(rows, out_format="%Y/%m/%d")
        assert result["rows"][0]["timestamp"] == "2020/01/15"

    def test_missing_timestamp_col_raises(self):
        rows = [{"date": "2020-01-01", "close": 100.0}]
        with pytest.raises(RuntimeError, match="missing 'timestamp' column"):
            fix_timestamps(rows, timestamp_col="timestamp")

    def test_iso_format_passthrough(self):
        rows = [
            {"timestamp": "2020-06-15 10:30:00", "close": 100.0},
        ]
        result = fix_timestamps(rows, dayfirst=False)
        assert result["rows"][0]["timestamp"] == "2020-06-15 10:30:00"


# ─── align ─────────────────────────────────────────────────────────────


class TestAlign:
    def test_overlapping_timestamps(self):
        a = {"rows": [
            {"timestamp": "2020-01-01 00:00:00", "close": 100.0},
            {"timestamp": "2020-01-02 00:00:00", "close": 101.0},
            {"timestamp": "2020-01-03 00:00:00", "close": 102.0},
        ]}
        b = {"rows": [
            {"timestamp": "2020-01-02 00:00:00", "close": 200.0},
            {"timestamp": "2020-01-03 00:00:00", "close": 201.0},
            {"timestamp": "2020-01-04 00:00:00", "close": 202.0},
        ]}
        a_out, b_out = align(a, b)
        assert len(a_out["rows"]) == 2
        assert len(b_out["rows"]) == 2
        # Both should have the same timestamps
        a_ts = [r["timestamp"] for r in a_out["rows"]]
        b_ts = [r["timestamp"] for r in b_out["rows"]]
        assert a_ts == b_ts

    def test_no_overlap_raises(self):
        a = {"rows": [
            {"timestamp": "2020-01-01 00:00:00", "close": 100.0},
        ]}
        b = {"rows": [
            {"timestamp": "2021-06-01 00:00:00", "close": 200.0},
        ]}
        with pytest.raises(RuntimeError, match="no overlapping timestamps"):
            align(a, b)

    def test_exact_overlap(self):
        rows = [
            {"timestamp": "2020-01-01 00:00:00", "close": 100.0},
            {"timestamp": "2020-01-02 00:00:00", "close": 101.0},
        ]
        a = {"rows": rows.copy()}
        b = {"rows": rows.copy()}
        a_out, b_out = align(a, b)
        assert len(a_out["rows"]) == 2
        assert len(b_out["rows"]) == 2

    def test_missing_timestamp_col_raises(self):
        a = {"rows": [{"date": "2020-01-01", "close": 100.0}]}
        b = {"rows": [{"timestamp": "2020-01-01", "close": 200.0}]}
        with pytest.raises(RuntimeError, match="Missing 'timestamp'"):
            align(a, b)

    def test_preserves_non_timestamp_columns(self):
        a = {"rows": [
            {"timestamp": "2020-01-01 00:00:00", "close": 100.0, "extra": "a"},
            {"timestamp": "2020-01-02 00:00:00", "close": 101.0, "extra": "b"},
        ]}
        b = {"rows": [
            {"timestamp": "2020-01-01 00:00:00", "close": 200.0},
            {"timestamp": "2020-01-02 00:00:00", "close": 201.0},
        ]}
        a_out, b_out = align(a, b)
        assert a_out["rows"][0]["extra"] == "a"
        assert a_out["rows"][1]["extra"] == "b"
