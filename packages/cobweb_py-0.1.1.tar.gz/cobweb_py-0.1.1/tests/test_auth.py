# tests/test_auth.py

import pytest
from unittest.mock import patch
from fastapi.testclient import TestClient
from app.main import app

# Minimal valid payload for POST endpoints
_FEATURES_BODY = {
    "data": {
        "rows": [
            {"timestamp": f"2024-01-{d:02d}", "open": 100, "high": 105,
             "low": 95, "close": 100 + i * 0.1, "volume": 10000}
            for d, i in zip(range(1, 26), range(25))
        ]
    },
    "feature_ids": [1],
}

_BACKTEST_BODY = {
    "data": {
        "rows": [
            {"timestamp": f"2024-01-{d:02d}", "open": 100, "high": 105,
             "low": 95, "close": 100 + i * 0.1, "volume": 10000}
            for d, i in zip(range(1, 26), range(25))
        ]
    },
    "signals": [1.0] * 25,
    "config": {},
}

TEST_KEY = "sk_test_secret_123"


@pytest.fixture
def open_client():
    """Client with auth disabled (no API_KEY configured)."""
    with patch("app.auth.settings") as mock_settings:
        mock_settings.api_key = None
        yield TestClient(app)


@pytest.fixture
def secured_client():
    """Client with auth enabled."""
    with patch("app.auth.settings") as mock_settings:
        mock_settings.api_key = TEST_KEY
        yield TestClient(app)


# ─── Auth Disabled (dev mode) ───

class TestAuthDisabled:
    def test_health_returns_200(self, open_client):
        r = open_client.get("/health")
        assert r.status_code == 200

    def test_features_no_key_returns_200(self, open_client):
        r = open_client.post("/features", json=_FEATURES_BODY)
        assert r.status_code == 200

    def test_backtest_no_key_returns_200(self, open_client):
        r = open_client.post("/backtest", json=_BACKTEST_BODY)
        assert r.status_code == 200


# ─── Auth Enabled ───

class TestAuthEnabled:
    def test_health_always_public(self, secured_client):
        r = secured_client.get("/health")
        assert r.status_code == 200

    def test_features_no_key_returns_401(self, secured_client):
        r = secured_client.post("/features", json=_FEATURES_BODY)
        assert r.status_code == 401
        assert "Missing API key" in r.json()["detail"]

    def test_backtest_no_key_returns_401(self, secured_client):
        r = secured_client.post("/backtest", json=_BACKTEST_BODY)
        assert r.status_code == 401

    def test_plots_no_key_returns_401(self, secured_client):
        r = secured_client.post("/plots", json={"data": _BACKTEST_BODY["data"], "backtest_result": {}})
        assert r.status_code == 401

    def test_wrong_key_returns_401(self, secured_client):
        r = secured_client.post(
            "/features", json=_FEATURES_BODY,
            headers={"Authorization": "Bearer wrong_key"},
        )
        assert r.status_code == 401
        assert "Invalid API key" in r.json()["detail"]

    def test_bad_header_format_returns_401(self, secured_client):
        r = secured_client.post(
            "/features", json=_FEATURES_BODY,
            headers={"Authorization": "Token sk_test_secret_123"},
        )
        assert r.status_code == 401

    def test_correct_key_returns_200(self, secured_client):
        r = secured_client.post(
            "/features", json=_FEATURES_BODY,
            headers={"Authorization": f"Bearer {TEST_KEY}"},
        )
        assert r.status_code == 200

    def test_correct_key_backtest_returns_200(self, secured_client):
        r = secured_client.post(
            "/backtest", json=_BACKTEST_BODY,
            headers={"Authorization": f"Bearer {TEST_KEY}"},
        )
        assert r.status_code == 200
