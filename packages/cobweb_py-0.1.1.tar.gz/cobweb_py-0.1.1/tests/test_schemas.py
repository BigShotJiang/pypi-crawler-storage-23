"""Tests for app.schemas Pydantic models."""

import pytest
from pydantic import ValidationError

from app.schemas import (
    OHLCRow,
    OHLCRequest,
    BacktestConfig,
    BacktestRequest,
    BacktestResponse,
)


# ─── OHLCRow ───


class TestOHLCRowValid:
    """OHLCRow accepts valid OHLC data."""

    def test_valid_row(self):
        row = OHLCRow(open=1.0, high=2.0, low=0.5, close=1.5)
        assert row.open == 1.0
        assert row.high == 2.0
        assert row.low == 0.5
        assert row.close == 1.5

    def test_valid_row_with_volume_and_timestamp(self):
        row = OHLCRow(
            open=1.0, high=2.0, low=0.5, close=1.5,
            volume=10000.0, timestamp="2024-01-01",
        )
        assert row.volume == 10000.0
        assert row.timestamp == "2024-01-01"


class TestOHLCRowMissingRequired:
    """OHLCRow rejects rows missing required fields."""

    def test_missing_close(self):
        with pytest.raises(ValidationError) as exc_info:
            OHLCRow(open=1.0, high=2.0, low=0.5)
        # Ensure the error mentions the 'close' field
        errors = exc_info.value.errors()
        field_names = [e["loc"][-1] for e in errors]
        assert "close" in field_names

    def test_missing_open(self):
        with pytest.raises(ValidationError):
            OHLCRow(high=2.0, low=0.5, close=1.5)

    def test_missing_all_required(self):
        with pytest.raises(ValidationError):
            OHLCRow()


class TestOHLCRowOptionalFields:
    """Optional fields default to None when omitted."""

    def test_volume_defaults_to_none(self):
        row = OHLCRow(open=1.0, high=2.0, low=0.5, close=1.5)
        assert row.volume is None

    def test_timestamp_defaults_to_none(self):
        row = OHLCRow(open=1.0, high=2.0, low=0.5, close=1.5)
        assert row.timestamp is None

    def test_both_optional_fields_none(self):
        row = OHLCRow(open=1.0, high=2.0, low=0.5, close=1.5)
        assert row.volume is None
        assert row.timestamp is None


# ─── BacktestConfig ───


class TestBacktestConfigDefaults:
    """BacktestConfig has expected default values."""

    def test_initial_cash_default(self):
        config = BacktestConfig()
        assert config.initial_cash == 10_000

    def test_max_leverage_default(self):
        config = BacktestConfig()
        assert config.max_leverage == 1.0

    def test_allow_margin_default(self):
        config = BacktestConfig()
        assert config.allow_margin is False

    def test_exec_horizon_default(self):
        config = BacktestConfig()
        assert config.exec_horizon == "swing"

    def test_asset_type_default(self):
        config = BacktestConfig()
        assert config.asset_type == "equities"

    def test_fee_bps_default(self):
        config = BacktestConfig()
        assert config.fee_bps == 1.0

    def test_custom_overrides(self):
        config = BacktestConfig(initial_cash=50_000, max_leverage=2.0)
        assert config.initial_cash == 50_000
        assert config.max_leverage == 2.0


# ─── BacktestRequest ───


class TestBacktestRequestValidation:
    """BacktestRequest requires data and signals."""

    def test_missing_signals_raises(self):
        """signals is a required field."""
        rows = [OHLCRow(open=1, high=2, low=0.5, close=1.5)] * 20
        with pytest.raises(ValidationError) as exc_info:
            BacktestRequest(data=OHLCRequest(rows=rows))
        errors = exc_info.value.errors()
        field_names = [e["loc"][-1] for e in errors]
        assert "signals" in field_names

    def test_valid_request(self):
        rows = [OHLCRow(open=1, high=2, low=0.5, close=1.5)] * 20
        req = BacktestRequest(
            data=OHLCRequest(rows=rows),
            signals=[1.0] * 20,
        )
        assert len(req.signals) == 20
        assert req.config.initial_cash == 10_000  # default config applied

    def test_config_defaults_applied(self):
        """When config is omitted, BacktestConfig defaults are used."""
        rows = [OHLCRow(open=1, high=2, low=0.5, close=1.5)] * 20
        req = BacktestRequest(
            data=OHLCRequest(rows=rows),
            signals=[0.0] * 20,
        )
        assert req.config.max_leverage == 1.0
        assert req.compute_features is True


# ─── BacktestResponse ───


class TestBacktestResponse:
    """BacktestResponse with all required fields is valid."""

    def test_valid_response(self):
        resp = BacktestResponse(
            trades=[{"t": 0, "side": 1, "fill": 100.0, "units": 10}],
            equity_curve=[{"bar": 0, "equity": 10000.0}],
            metrics={"sharpe_ann": 1.5, "total_return": 0.05},
            current_exposure=1.0,
            current_signal="buy",
        )
        assert resp.current_signal == "buy"
        assert resp.current_exposure == 1.0
        assert len(resp.trades) == 1
        assert len(resp.equity_curve) == 1

    def test_optional_fields_default_to_none(self):
        resp = BacktestResponse(
            trades=[],
            equity_curve=[],
            metrics={},
            current_exposure=0.0,
            current_signal="hold",
        )
        assert resp.plots is None
        assert resp.rewards is None
        assert resp.reward_components is None
        assert resp.rebalance is None
        assert resp.signals is None
        assert resp.signals_exec is None
        assert resp.tc_series is None
        assert resp.signal_strength is None

    def test_missing_required_field_raises(self):
        with pytest.raises(ValidationError):
            BacktestResponse(
                trades=[],
                equity_curve=[],
                metrics={},
                # missing current_exposure and current_signal
            )

    def test_current_signal_literal_values(self):
        """current_signal must be one of buy, sell, hold."""
        for signal in ("buy", "sell", "hold"):
            resp = BacktestResponse(
                trades=[], equity_curve=[], metrics={},
                current_exposure=0.0, current_signal=signal,
            )
            assert resp.current_signal == signal

    def test_invalid_current_signal_raises(self):
        with pytest.raises(ValidationError):
            BacktestResponse(
                trades=[], equity_curve=[], metrics={},
                current_exposure=0.0, current_signal="invalid",
            )
