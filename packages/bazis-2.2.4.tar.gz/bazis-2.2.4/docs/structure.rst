Framework structure
==========================

.. autosummary::
   :toctree: _autosummary
   :recursive:
   :template: custom-module-template.rst

   bazis.core

