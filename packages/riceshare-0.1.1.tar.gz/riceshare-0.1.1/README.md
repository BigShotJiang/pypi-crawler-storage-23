# RiceShare CLI

> Discover and install Linux rice profiles with ease.

RiceShare is a production-grade CLI tool for discovering, installing, and managing Linux rice profiles (desktop environment configurations). Built with modern Python tooling, it provides a clean interface for browsing available profiles and safely installing them with automatic backups.

## Features

- **Search profiles**: Browse available rice profiles from the community index
- **Profile info**: View detailed information about any profile
- **Safe installation**: Install profiles with automatic backups and dry-run support
- **Rollback support**: Easily restore previous configurations from backups
- **Distro detection**: Automatically selects the right package manager and packages for your system
- **Production-ready**: Full type hints, comprehensive tests, and CI/CD workflow

## Installation

Install from source:

```bash
git clone https://github.com/AxonInnova/RiceShare.git
cd RiceShare
pip install -e .
```

Or install from PyPI (recomended):

```bash
pip install riceshare
```

## Usage

### Search for profiles

```bash
riceshare search
```

Displays all available profiles in a formatted table with ID, name, author, description, and supported distributions.

### View profile details

```bash
riceshare info <profile-id>
```

Shows detailed information about a specific profile including description, author, supported distributions, and preview URL (if available).

### Install a profile

```bash
riceshare install <profile-id> [--dry-run] [--yes]
```

Installs a profile:
- `--dry-run`: Preview changes without applying them
- `--yes`: Skip confirmation prompts

The tool automatically:
- Detects your Linux distribution
- Selects appropriate packages
- Backs up affected files
- Displays package installation commands for you to run manually
- Creates a timestamped backup for easy rollback

### Restore from backup

```bash
riceshare rollback [backup-id]
```

Restores files from a previous backup. Run without a backup ID to list all available backups.

## Development

### Setup

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate

# Install in editable mode with dev dependencies
pip install -e ".[dev]"
```

### Testing

```bash
pytest -q
pytest --cov=riceshare           # with coverage
```

### Code quality

```bash
ruff check riceshare tests       # linting
black riceshare tests            # formatting
mypy riceshare                   # type checking
```

### Build

```bash
python -m build
```

## Project Structure

- `riceshare/` — Main package
  - `cli.py` — Typer CLI application
  - `github.py` — GitHub integration for fetching profiles
  - `installer.py` — Installation logic and YAML validation
  - `backup.py` — Backup creation and rollback functionality
  - `packages.py` — Package manager integration
  - `config.py` — Configuration and constants
  - `utils.py` — HTTP, file, and error utilities
- `tests/` — Unit and integration tests
- `.github/workflows/ci.yaml` — GitHub Actions CI pipeline

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for release notes.
