"""Home of all warnings used by gypt_matplotlib."""

# standard library
from hashlib import md5
from pathlib import Path
from warnings import warn

__all__ = (
    "GYPTWarning",
    "TamperedStylesheetWarning",
    "warn_if_modified_stylesheet",
)


class GYPTWarning(UserWarning):
    """Base for all custom warnings warned by this library."""


class TamperedStylesheetWarning(GYPTWarning):
    """Warning for modified ``gypt.mplstyle``-file."""


def warn_if_modified_stylesheet(stylesheet_path: Path, original_md5_hash: str):
    """Warns if the stylesheet has been modified."""
    if (computed_md5_hash := md5(stylesheet_path.read_bytes(), usedforsecurity=False).hexdigest()) != original_md5_hash:
        warn(
            message=(
                f"**The stylesheet ``{stylesheet_path.name}`` (full path: {stylesheet_path.absolute()}) doesn't match"
                f" the original MD5-hash.**\n*Ignore this warning if this is intentional.*\n"
                f"Debug: {original_md5_hash=}, {computed_md5_hash=}"
            ),
            category=TamperedStylesheetWarning,
            stacklevel=2,
        )
