"""A small addon for matplotlib that can be used for the GYPT."""

__version__ = "0.6.3"
__description__ = __doc__
__license__ = "MIT"
__authors__ = [
    "Keenan Noack <gypt-matplotlib@albertunruh.de>",
]
__repository__ = "https://codeberg.org/AlbertUnruh/gypt-matplotlib/"


# local
from . import constants, context_managers, debug, errors, utils, warning
from .context_managers import au_plot, auto_close, auto_save, auto_save_and_show, auto_show
from .debug import print_debug
from .utils import apply_gypt_style, axes_label, tex

__all__ = (
    "au_plot",
    "auto_close",
    "auto_save",
    "auto_save_and_show",
    "auto_show",
    "axes_label",
    "constants",
    "context_managers",
    "debug",
    "errors",
    "print_debug",
    "tex",
    "utils",
)


warning.warn_if_modified_stylesheet(constants.STYLE_PATH, constants._STYLE_MD5)  # noqa: SLF001

# automatically apply the GYPT style
apply_gypt_style()
