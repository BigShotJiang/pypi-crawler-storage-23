## Kinpy2

Excel-based setup for reaction kinetics integrator


### Install

```
pip install kinpy2
```

### Use

1. Generate *.k file with reaction equations and run

```
python -m kinpy2 parse equations.k
```

2. Input energies of intermediates and TSs into `mytable.xlsx` file. Optionally, to obtain energies one can use

```
python -m kinpy2 energy
```

this runs GoodVibes and creates an `energies.xlsx` table. One can copy-paste these energies into `mytable.xlsx`

3. Generate kinetics integration script `calc_kinetics.py` by running

```
python -m kinpy2 gen mytable.xlsx
```

One can tweak the energy barriers in the generated file `mytable_new.xlsx` and re-run script generation via

```
python -m kinpy2 gen mytable.xlsx --noprep
```

4. Execute the integration script by running

```
python calc_kinetics.py
```

Kinetics trajectories are stored at `res.csv`.




All file names can be set using CLI flags. See help messages

```
python -m kinpy2 gen --help
```
