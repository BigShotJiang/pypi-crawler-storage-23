"""ShinnyQuant - ShinnyTech 期货行情数据服务 Python SDK"""

from .client import ShinnyQuantClient
from .models import KlineData, Period
from .exceptions import ShinnyQuantError, AuthenticationError, ApiError

__version__ = "0.1.0"
__all__ = [
    "ShinnyQuantClient",
    "KlineData",
    "Period",
    "ShinnyQuantError",
    "AuthenticationError",
    "ApiError",
]
