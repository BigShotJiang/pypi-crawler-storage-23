"""ShinnyQuant SDK 异常定义"""


class ShinnyQuantError(Exception):
    """SDK 基础异常"""

    pass


class AuthenticationError(ShinnyQuantError):
    """认证错误"""

    pass


class ApiError(ShinnyQuantError):
    """API 调用错误"""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"{status_code},{message}")
