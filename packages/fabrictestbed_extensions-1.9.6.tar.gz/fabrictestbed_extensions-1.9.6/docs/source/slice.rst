slice
=====

.. automodule:: fabrictestbed_extensions.fablib.slice
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.slice.Slice
   :members:
   :special-members: __str__
