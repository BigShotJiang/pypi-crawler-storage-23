switch
======

.. automodule:: fabrictestbed_extensions.fablib.switch
   :members:

.. autoclass:: fabrictestbed_extensions.fablib.switch.Switch
   :members:
   :no-index:
   :special-members: __str__
