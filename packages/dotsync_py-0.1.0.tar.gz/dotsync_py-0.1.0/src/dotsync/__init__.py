"""dotsync — Fleet-style dotfiles manager."""

__version__ = "0.1.0"
