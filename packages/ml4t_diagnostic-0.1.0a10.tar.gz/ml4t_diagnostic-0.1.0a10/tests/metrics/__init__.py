"""Tests for metrics module."""
