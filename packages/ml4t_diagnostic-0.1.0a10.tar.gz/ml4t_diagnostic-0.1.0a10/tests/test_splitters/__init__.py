"""Tests for splitter functionality."""
