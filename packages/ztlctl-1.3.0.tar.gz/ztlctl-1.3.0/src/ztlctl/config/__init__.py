"""Configuration loading and models for ztlctl."""
