"""Output formatting — Rich for humans, JSON for machines."""
