"""MCP adapter layer — optional extra (pip install ztlctl[mcp]).

Thin adapter over the service layer providing Tools, Resources, and Prompts.
Transport: stdio default, streamable HTTP optional.
"""
