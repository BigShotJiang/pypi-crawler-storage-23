"""NetworkX graph engine for in-memory graph algorithms."""
