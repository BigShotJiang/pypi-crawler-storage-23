"""InitService — vault initialization and self-generation.

Unlike other services, InitService does NOT extend BaseService because it
operates *before* a Vault exists.  All public methods are @staticmethod
(init_vault) or take a Vault parameter (regenerate_self, check_staleness).
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

from ztlctl.infrastructure.templates import build_template_environment
from ztlctl.services._helpers import today_iso
from ztlctl.services.result import ServiceError, ServiceResult
from ztlctl.services.telemetry import traced

if TYPE_CHECKING:
    from ztlctl.infrastructure.vault import Vault

# ── Constants ─────────────────────────────────────────────────────────

_OBSIDIAN_CSS = """\
/* ztlctl vault styling for Obsidian */
.ztlctl-seed { color: var(--text-muted); }
.ztlctl-sapling { color: var(--text-normal); }
.ztlctl-evergreen { color: var(--text-accent); font-weight: bold; }
"""

# ── Template rendering ────────────────────────────────────────────────


def _render_self_files(
    *,
    vault_name: str,
    tone: str,
    client: str,
    topics: list[str],
    created: str,
    vault_root: Path | None = None,
) -> dict[str, str]:
    """Render identity.md and methodology.md from Jinja2 templates.

    Returns a dict mapping filename -> rendered content.
    """
    env = build_template_environment("self", vault_root=vault_root)
    context = {
        "vault_name": vault_name,
        "tone": tone,
        "client": client,
        "topics": topics,
        "created": created,
    }
    return {
        "identity.md": env.get_template("identity.md.j2").render(context),
        "methodology.md": env.get_template("methodology.md.j2").render(context),
    }


def _dispatch_post_init(*, vault_path: Path, name: str, client: str, tone: str) -> list[str]:
    """Dispatch post-init hooks against the freshly created vault."""
    warnings: list[str] = []

    try:
        from ztlctl.config.settings import ZtlSettings
        from ztlctl.infrastructure.vault import Vault

        settings = ZtlSettings.from_cli(vault_root=vault_path)
        vault = Vault(settings)
        try:
            vault.init_event_bus(sync=True)
            bus = vault.event_bus
            if bus is not None:
                bus.dispatch(
                    "post_init",
                    {
                        "vault_name": name,
                        "client": client,
                        "tone": tone,
                    },
                )
        finally:
            vault.close(wait_for_events=True)
    except Exception as exc:
        warnings.append(f"post_init hooks skipped ({exc})")

    return warnings


# ── TOML generation ──────────────────────────────────────────────────


def _generate_toml(*, name: str, client: str, tone: str) -> str:
    """Generate a sparse ztlctl.toml with only the user-chosen overrides."""
    return f'[vault]\nname = "{name}"\nclient = "{client}"\n\n[agent]\ntone = "{tone}"\n'


# ── Public API ────────────────────────────────────────────────────────


class InitService:
    """Vault initialization and self-generation (all static methods)."""

    @staticmethod
    @traced
    def init_vault(
        path: Path,
        *,
        name: str,
        client: str = "obsidian",
        tone: str = "research-partner",
        topics: list[str] | None = None,
        no_workflow: bool = False,
    ) -> ServiceResult:
        """Create a new ztlctl vault at *path*.

        Pipeline:
        1. VALIDATE — reject if ztlctl.toml already exists
        2. CREATE STRUCTURE — dirs from DESIGN.md Section 11
        3. GENERATE CONFIG — sparse ztlctl.toml
        4. INITIALIZE DB — SQLite + FTS5
        5. RENDER SELF — identity.md + methodology.md via Jinja2
        6. SETUP OBSIDIAN — .obsidian/snippets/ztlctl.css (if client=obsidian)
        7. WORKFLOW — .ztlctl/workflow-answers.yml (unless --no-workflow)
        8. RESPOND — ServiceResult with created file manifest
        """
        vault_path = path.resolve()
        topics = topics or []

        # 1. VALIDATE
        toml_path = vault_path / "ztlctl.toml"
        if toml_path.exists():
            return ServiceResult(
                ok=False,
                op="init_vault",
                error=ServiceError(
                    code="VAULT_EXISTS",
                    message=f"Vault already exists at {vault_path}",
                    detail={"path": str(vault_path)},
                ),
            )

        files_created: list[str] = []
        warnings: list[str] = []

        # 2. CREATE STRUCTURE
        dirs = [
            vault_path / ".ztlctl",
            vault_path / "self",
            vault_path / "notes",
            vault_path / "ops" / "logs",
            vault_path / "ops" / "tasks",
        ]
        for topic in topics:
            dirs.append(vault_path / "notes" / topic)
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)

        # 3. GENERATE CONFIG
        toml_content = _generate_toml(name=name, client=client, tone=tone)
        toml_path.write_text(toml_content, encoding="utf-8")
        files_created.append("ztlctl.toml")

        # 4. INITIALIZE DB
        from ztlctl.infrastructure.database.engine import init_database

        init_database(vault_path)
        files_created.append(".ztlctl/ztlctl.db")

        # 4b. STAMP ALEMBIC VERSION
        try:
            from ztlctl.infrastructure.database.migrations import stamp_head

            stamp_head(vault_path)
        except Exception as exc:
            warnings.append(f"Alembic stamp failed ({exc}); run 'ztlctl upgrade' to fix")

        # 5. RENDER SELF
        created = today_iso()
        rendered = _render_self_files(
            vault_name=name,
            tone=tone,
            client=client,
            topics=topics,
            created=created,
            vault_root=vault_path,
        )
        self_dir = vault_path / "self"
        for filename, content in rendered.items():
            (self_dir / filename).write_text(content, encoding="utf-8")
            files_created.append(f"self/{filename}")

        # 6. SETUP OBSIDIAN
        if client == "obsidian":
            snippets_dir = vault_path / ".obsidian" / "snippets"
            snippets_dir.mkdir(parents=True, exist_ok=True)
            (snippets_dir / "ztlctl.css").write_text(_OBSIDIAN_CSS, encoding="utf-8")
            files_created.append(".obsidian/snippets/ztlctl.css")

        # 7. WORKFLOW
        if not no_workflow:
            from ztlctl.services.workflow import WorkflowService

            workflow_result = WorkflowService.init_workflow(
                vault_path,
                WorkflowService.default_choices(
                    viewer="obsidian" if client == "obsidian" else "vanilla"
                ),
            )
            if workflow_result.ok:
                files_created.extend(
                    [
                        path
                        for path in workflow_result.data.get("files_written", [])
                        if path not in files_created
                    ]
                )
            elif workflow_result.error is not None:
                warnings.append(
                    f"Workflow scaffolding skipped ({workflow_result.error.message}); "
                    "run 'ztlctl workflow init' to retry"
                )

        warnings.extend(
            _dispatch_post_init(vault_path=vault_path, name=name, client=client, tone=tone)
        )

        return ServiceResult(
            ok=True,
            op="init_vault",
            data={
                "vault_path": str(vault_path),
                "name": name,
                "client": client,
                "tone": tone,
                "topics": topics,
                "files_created": files_created,
            },
            warnings=warnings,
        )

    @staticmethod
    @traced
    def regenerate_self(vault: Vault) -> ServiceResult:
        """Re-render self/ files from current vault settings.

        Reads config from the vault's ZtlSettings and overwrites
        self/identity.md and self/methodology.md with fresh renders.
        """
        config_path = vault.settings.config_path
        if config_path is None or not config_path.exists():
            return ServiceResult(
                ok=False,
                op="regenerate_self",
                error=ServiceError(
                    code="NO_CONFIG",
                    message="No ztlctl.toml found",
                ),
            )

        settings = vault.settings
        self_dir = vault.root / "self"
        self_dir.mkdir(exist_ok=True)

        rendered = _render_self_files(
            vault_name=settings.vault.name,
            tone=settings.agent.tone,
            client=settings.vault.client,
            topics=[],  # topics are directory-based, not in config
            created=today_iso(),
            vault_root=vault.root,
        )

        files_written: list[str] = []
        changed: list[str] = []
        for filename, content in rendered.items():
            target = self_dir / filename
            old_content = target.read_text(encoding="utf-8") if target.exists() else ""
            target.write_text(content, encoding="utf-8")
            files_written.append(f"self/{filename}")
            if content != old_content:
                changed.append(filename)

        return ServiceResult(
            ok=True,
            op="regenerate_self",
            data={
                "files_written": files_written,
                "changed": changed,
                "vault_path": str(vault.root),
            },
        )

    @staticmethod
    @traced
    def check_staleness(vault: Vault) -> ServiceResult:
        """Compare ztlctl.toml mtime vs self/*.md mtimes.

        Returns stale=True if any self/ file is older than the config.
        """
        config_path = vault.root / "ztlctl.toml"
        self_dir = vault.root / "self"

        if not config_path.exists():
            return ServiceResult(
                ok=False,
                op="check_staleness",
                error=ServiceError(
                    code="NO_CONFIG",
                    message="No ztlctl.toml found",
                ),
            )

        config_mtime = os.path.getmtime(config_path)
        stale_files: list[str] = []

        for md_file in sorted(self_dir.glob("*.md")):
            if os.path.getmtime(md_file) < config_mtime:
                stale_files.append(md_file.name)

        return ServiceResult(
            ok=True,
            op="check_staleness",
            data={
                "stale": len(stale_files) > 0,
                "stale_files": stale_files,
                "config_mtime": config_mtime,
            },
        )
