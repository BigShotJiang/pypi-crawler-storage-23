"""Tests for the ztlctl plugin system."""
