"""Tests for the ztlctl MCP adapter layer."""
