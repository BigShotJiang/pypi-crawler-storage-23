"""Tests for marty-cli."""


def test_placeholder():
    """Placeholder test."""
    assert True
