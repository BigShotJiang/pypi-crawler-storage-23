import torch

# This dictionary now holds the dataset lists for ALL supported benchmarks.
BENCHMARK_DATASETS = {
    
    "openml-cc18": [3, 6, 11, 12, 14, 15, 16, 18, 22, 23, 28, 29,
        31, 32, 37, 38, 44, 46, 50, 54, 151, 182, 188, 300,
        307, 458, 469, 554, 1049, 1050, 1053, 1063, 1067, 1068, 1461, 1462,
        1464, 1468, 1475, 1478, 1480, 1485, 1486, 1487, 1489, 1494, 1497, 1501,
        1510, 1590, 4134, 4534, 4538, 6332, 23381, 23517, 40499, 40668, 40670, 40701,
        40923, 40927, 40966, 40975, 40978, 40979, 40982, 40983, 40984, 40994, 40996, 41027],
    
    "tabzilla": [999,10,11,14,22,29,27,31,46,54,333,1067,1468,1494,43973,1043,43945,1486,42825,
                 4538,23512,4134,470,1493,1459,41027,40981,934,1565,41150,41159,846,1169,41147,41143,1567],

    "tabred": [
        "albert", "california_housing", "covtype", "credit", "default", 
        "electricity", "eye_movements", "road_safety",
    ],

    "tabarena": None,
    
    "openml-ctr23": [
        41021, 44956, 44957, 44958, 44959, 44960, 44962, 44963, 44964, 44965,
        44966, 44967, 44969, 44970, 44971, 44972, 44973, 44974, 44975, 44976,
        44977, 44978, 44979, 44980, 44981, 44983, 44984, 44987, 44989, 44990,
        44992, 44993, 44994, 45012, 45402,
    ],  # OpenML-CTR23 Primary Curated Regression Standard (35 datasets) - Dataset IDs fetched from suite 353
    
    "automl-reg-suite": [
        359944, 359929, 233212, 359937, 359950, 359938, 233213, 359942, 233211, 359936,
        359952, 359951, 359949, 233215, 360945, 167210, 359943, 359941, 359946, 360933,
        360932, 359930, 233214, 359948, 359931, 359932, 359933, 359934, 359939, 359945,
        359935, 317614, 359940
    ],  # AutoML Regression Suite (33 datasets)
    
    "grinsztajn-tabular-benchmark": [
        197,      # cpu_act regression
        201,      # pol regression
        216,      # elevators regression
        287,      # wine_quality regression
        296,      # Ailerons regression
        537,      # houses regression
        574,      # house_16H regression
        42225,    # diamonds regression
        42688,    # Brazilian_houses regression
        42712,    # Bike_Sharing_Demand regression
        42208,    # nyc-taxi-green-dec-2016 regression
        42079,    # house_sales regression
        23515,    # sulfur regression
        42130,    # medical_charges regression
        43093,    # MiamiHousing2016 regression
        43174,    # superconduct regression
        416,      # yprop_4_1 regression
        183,      # abalone regression
        40753     # delays_zurich_transport regression
    ],  # Grinsztajn Tabular Benchmark (19 datasets) - Updated with correct dataset IDs
    
    "tabarena-study-regression": [
        363612,  # airfoil_self_noise
        363615,  # Another-Dataset-on-used-Fiat-500
        363625,  # concrete_compressive_strength
        363631,  # diamonds
        363675,  # healthcare_insurance_expenses
        363672,  # Food_Delivery_Time
        363678,  # houses
        363686,  # miami_housing
        363693,  # physiochemical_protein
        363697,  # QSAR-TID-11
        363698,  # QSAR_fish_toxicity
        363705,  # superconductivity
        363708,  # wine_quality
    ]  # TabArena Study Regression (13 datasets)

#     "talent": ['dry_bean_dataset', 'satellite_image', 'Bank_Customer_Churn_Dataset',  
#                              'eeg-eye-state', 'compass_reg', 'healthcare_insurance_expenses', 'spambase', 'BNG(tic-tac-toe)', 'estimation_of_obesity_levels', 'Large-scale_Wave_Energy_Farm_Sydney_49', 'Insurance', 'BNG(mv)', 'ada_prior',       
#                              'mfeat-fourier', 'analcatdata_authorship', 'customer_satisfaction_in_airline', 'KDD', 'Bias_correction_r',    'okcupid_stem', 'weather_izmir', 'sylvine', 'MIC', 'analcatdata_supreme', 'kdd_ipums_la_97-small',                   
#                              'gas_turbine_CO_and_NOx_emission', 'FOREX_audjpy-day-High', 'turiye_student_evaluation', 'website_phishing',  'CPS1988', 'blogfeedback', 'avocado_sales', 'texture', 'Bias_correction_r_2', 'dna', 'maternal_health_risk',         
#                              'Click_prediction_small', 'BNG(cmc)', 'kc1', 'PieChart3', 'mfeat-karhunen', 'default_of_credit_card_clients',  'eye_movements_bin', 'shill-bidding', 'ada', 'qsar', 'FOREX_audcad-day-High', 'telco-customer-churn', 'segment',     
#                              'satimage', 'E-CommereShippingData', 'Amazon_employee_access', 'banknote_authentication',                            
#                              'naticusdroid+android+permissions+dataset', 'MiamiHousing2016', 'INNHotelsGroup',                                    
#                              'Large-scale_Wave_Energy_Farm_Sydney_100', 'electricity', 'eye_movements', 'internet_firewall',                      
#                              'steel_industry_energy_consumption', 'taiwanese_bankruptcy_prediction', 'Parkinsons_Telemonitoring', 'cpu_small',    
#                              'madeline', 'NHANES_age_prediction', 'BNG(lowbwt)', 'Job_Profitability', 'KDDCup09_upselling', 'kin8nm',             
#                              'golf_play_dataset_extended', 'pc1', 'mobile_c36_oversampling', 'allrep', 'cmc', 'Mobile_Price_Classification',      
#                              'Cardiovascular-Disease-dataset', 'wine', 'Kaggle_bike_sharing_demand_challange', 'one-hundred-plants-margin',       
#                              'archive_r56_Portuguese', 'Credit_c', 'archive_r56_Maths', 'concrete_compressive_strength',                          
#                              'combined_cycle_power_plant', 'California-Housing-Classification', 'one-hundred-plants-shape', '2dplanes',           
#                              'credit_reg', 'MagicTelescope', 'predict_students_dropout_and_academic_success',                                     
#                              'HR_Analytics_Job_Change_of_Data_Scientists', 'IBM_HR_Analytics_Employee_Attrition_and_Performance',                 
#                              'UJI_Pen_Characters', 'Data_Science_Salaries', 'qsar_aquatic_toxicity', 'htru', 'BNG(stock)',                        
#                              '3D_Estimation_using_RSSI_of_WLAN_dataset', 'cpu_act', 'Mobile_Phone_Market_in_Ghana',                               
#                              'Another-Dataset-on-used-Fiat-500-(1538-rows)', 'airfoil_self_noise', 'pc4', 'bank32nh', 'abalone',                  
#                              'CookbookReviews', 'Heart-Disease-Dataset-(Comprehensive)', 'wine-quality-red', 'steel_plates_faults', 'puma8NH',    
#                              'dis', 'Fitness_Club_c', 'Employee', 'Laptop_Prices_Dataset', 'allbp', 'ibm-employee-performance',                   
#                              'house_sales_reduced', 'pendigits', 'Large-scale_Wave_Energy_Farm_Perth_49',                                         
#                              'GAMETES_Epistasis_2-Way_20atts_0.1H_EDM-1_1', 'Wine_Quality_red', 'Facebook_Comment_Volume', 'jm1',                 
#                              'Customer_Personality_Analysis', 'space_ga', 'drug_consumption', 'car-evaluation',                                   
#                              'Large-scale_Wave_Energy_Farm_Perth_100', 'ada_agnostic', 'pol', 'Food_Delivery_Time', 'online_shoppers', 'pole',    
#                              'sensory', 'QSAR_biodegradation', 'CDC_Diabetes_Health_Indicators', 'dabetes_130-us_hospitals', 'mfeat-factors',     
#                              'company_bankruptcy_prediction', 'archive2', 'waveform_database_generator_version_1', 'law-school-admission-bianry', 
#                              'water_quality', 'microaggregation2', 'FOREX_audjpy-hour-High', 'Long', 'bank', 'letter', 'Superconductivty',        
#                              'housing_price_prediction', 'kr-vs-k', 'fried', 'walking-activity', 'Physicochemical_r', 'Marketing_Campaign',       
#                              'Basketball_c', 'mice_protein_expression', 'thyroid', 'waveform_database_generator', 'shuttle',                      
#                              'contraceptive_method_choice', 'FOREX_audchf-day-High', 'Abalone_reg', 'page-blocks', 'house_8L',                    
#                              'autoUniv-au4-2500',
# 'Contaminant-detection-in-packaged-cocoa-hazelnut-spread-jars-using-Microwaves-Sensing-and-Machine-Learning 11.0GHz(Urbinati)', 'houses', 'mauna-loa-atmospheric-co2', 'mfeat-morphological', 'sulfur', 'FOREX_cadjpy-hour-High',         
#                              'Student_Alcohol_Consumption', 'ASP-POTASSCO-classification', 'BNG(echoMonths)', 'SDSS17', 'rl', 'twonorm',          
#     'Contaminant-detection-in-packaged-cocoa-hazelnut-spread-jars-using-Microwaves-Sensing-and-Machine-Learning-10.5GHz(Urbinati)', 'thyroid-ann', 'IEEE80211aa-GATS', 'stock_fardamento02', 'wine+quality', 'FOREX_audusd-hour-High',        
#                              'Student_Performance_Portuguese', 'gas-drift', 'Parkinson_Multiple_Sound_Recording', 'communities_and_crime',        
#                              'debutanizer', '3D_Estimation_using_RSSI_of_WLAN_dataset_complete_1_target', 'Diamonds',                             
#                              'Intersectional-Bias-Assessment', 'qsar_fish_toxicity', 'thyroid-dis', 'PizzaCutter3', 'delta_elevators',            
#                              'garments_worker_productivity', 'Brazilian_houses_reproduced', 'delta_ailerons', 'wine-quality-white', 'VulNoneVul', 
#                              'ozone_level', 'volkert', 'Pima_Indians_Diabetes_Database', 'FOREX_audsgd-hour-High', 'optdigits',                   
#                              'PhishingWebsites', 'kropt', 'in_vehicle_coupon_recommendation', 'Telecom_Churn_Dataset', 'shrutime',                
#                              'one-hundred-plants-texture', 'socmob', 'autoUniv-au7-1100', 'compass', 'splice', 'Satellite', 'volume', 'puma32H',  
#                              'Data_Science_for_Good_Kiva_Crowdfunding', 'jungle_chess_2pcs_raw_endgame_complete',                                 
#                              'national-longitudinal-survey-binary', '1000-Cameras-Dataset', 'Performance-Prediction', 'churn',                    
#                              'Smoking_and_Drinking_Dataset_with_body_signal', 
#              'GAMETES_Heterogeneity_20atts_1600_Het_0.4_0.2_50_EDM-2_001',       
#                              'stock', 'CPMP-2015-runtime-regression', 'waveform-5000', 'pol_reg', 'Gender_Gap_in_Spanish_WP', 'led24',            
#                              'mammography', 'BNG(breast-w)', 'UJIndoorLoc', 'Diabetic_Retinopathy_Debrecen', 'auction_verification',              
#                              'Waterstress', 'Firm-Teacher_Clave-Direction_Classification', 'Is-this-a-good-customer', 'statlog',           'Contaminant-detection-in-packaged-cocoa-hazelnut-spread-jars-using-Microwaves-Sensing-and-Machine-Learning-9.0GHz(Ur binati)', 'Water_Quality_and_Potability', 'Shipping', 'house_16H_reg', 'FICO-HELOC-cleaned', 'topo_2_1',             
#                              'National_Health_and_Nutrition_Health_Survey', 'svmguide3', 'fifa', 'artificial-characters',                         
#                              'Goodreads-Computer-Books', 'accelerometer', 'vehicle', 'led7', 'heloc', 'ringnorm', 'Pumpkin_Seeds',                
#                              'mfeat-zernike', 'phoneme', 'seismic+bumps', 'gina_agnostic', 'sports_articles_for_objectivity_analysis', 'Wilt',    
#                              'elevators', 'bank8FM', 'JapaneseVowels', 'pc3', 'credit', 'GesturePhaseSegmentationProcessed', 'baseball',          
#                              'CPMP-2015-regression', 'mv', 'Indian_pines', 'Wine_Quality_white', 'hill-valley', 'treasury', 'semeion',            
#                              'NASA_PHM2008', 'house_16H', 'airlines_seed_0_nrows_2000_nclasses_10_ncols_100_stratify_True', 'Shop_Customer_Data', 
#                              'BLE_RSSI_dataset_for_Indoor_localization', 'mfeat-pixel', 'rice_cammeo_and_osmancik', 'wind', 'internet_usage',     
#                              'yeast', 'Ailerons', 'FOREX_cadjpy-day-High', 'first-order-theorem-proving', 'wall-robot-navigation',          'Contaminant-detection-in-packaged-cocoa-hazelnut-spread-jars-using-Microwaves-Sensing-and-Machine-Learning-10.0GHz(Urbinati)',             'Contaminant-detection-in-packaged-cocoa-hazelnut-spread-jars-using-Microwaves-Sensing-and-Machine-Learning-9.5GHz(Urbinati)', 'FOREX_audcad-hour-High', 'mozilla4', 'dataset_sales', 'ozone-level-8hr', 'Rain_in_Australia'] 
}


