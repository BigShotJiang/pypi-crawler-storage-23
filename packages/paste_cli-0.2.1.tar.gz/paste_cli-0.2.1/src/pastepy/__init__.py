"""pastepy - A lightweight macOS clipboard manager."""

__version__ = "0.2.1"
