from pastepy.cli import app

app()
