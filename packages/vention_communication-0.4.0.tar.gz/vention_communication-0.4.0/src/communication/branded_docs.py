"""Vention-branded Swagger UI for VentionApp.

Provides a dark-themed, corporate-branded Swagger UI that is automatically
served at ``/docs`` when ``VentionApp.finalize()`` is called.

Consuming apps get the branded experience for free — just pass ``title``,
``description``, and ``version`` to the VentionApp constructor.
"""

from __future__ import annotations

from fastapi import FastAPI
from fastapi.responses import HTMLResponse

# Vention logo (white on transparent), 288×33 px, base64-encoded PNG (~5 KB).
# Source: mm-pendant/src/images/white_logo.png, resized with Lanczos.
_VENTION_LOGO_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAASAAAAAhCAYAAAB5qHaRAAATE0lEQVR42u1da7RdVXX+5tr73oSb"
    "hwEaWiSpqCAVeQ0swwgKCGMUkFKEhgAKAcFHbWFQsVVqKwSGCpaAttU6KBbCKyBBXpICY9SCyKsE"
    "hGIFEx420vCIIQk3kOTcvdf8+uPOFVY2+5x7HntfAj1rjD32Pefux1yvOb/5zbnWAckEADZs2LAT"
    "ycu89y+Q9CRXee8XkdwbAMJ1dReSDgBee+21HUh+j+RzJL33fq33/jaSB8TX9Uu/9MtbvJA8kOSL"
    "fL2oHfTeD5OcMx5KKDyf5F7e+2fL5CG5keRpfSXUL/3y9lA+O5FcbZM7Y0nx3ucjIyP716mEIuTz"
    "TpLL7dU5m5Qsyz4+nsisX/qlX+qZ+FfEysd7f/HIyMj+JE81VOQNfawg+a46kAdJIelIDnrv74nk"
    "aZCcR/KjJE8nuda+V5IPkUz6KKjy8SAkpd8S497mzsZzaufEvpPxkuFNqbz3fqUpGZK8pCDUIfa/"
    "gIweJDmx6oYhmdr50sjNIsl58XV5ns+NXLIGyZ17UYhhshWOpIuBs9kzqlAAnR5VK55O2rQqWbqt"
    "e9XtUUf7NqMc2hlvppRcXcYm1K+TunbTRpFiTTZ5LwVX53CSgyS3svMQyeftfyN2vipqFKlQ+Xwx"
    "Qj6B79mnIM/2kXIiyX27dcPq1vhvZWQWZO8jofrat6DsJ5PcM8uyj+d5fnye53OyLDuI5E4lE7gu"
    "ZZi+GWgoBTAMYLJ93kdEFkeCvB/AtgBo1+YATsjz/EkR+SbJAQBZLxZARHKShwGYD8ADSAConT8o"
    "IktIioiQ5G4ABk0emuywvzt5pwewP8kLTH5n7xQA/w7g6wBURDiG8tpaVb/jnHtPQYZhAJ8E8EqQ"
    "vR2ZSJ4K4BRr53aVqre++aqI/JSkExFtdyKIiJprfaXVf0hVk0ajMVdEfhG1V7N79wPw9wWZPy0i"
    "T7UrS9S//wjggx3Wv6wtfi4ip7fT9sU+yLJsdpqmX4xkyAEMeO8XpGl6abP26GL8geRBqnoSgAMA"
    "zEzTtGi0NpJ8EsCPASwQkV/H7dUt6rG2TgFcAWBHACOq+nskH1m0aNFJdt0bxn/U59NV9Rrn3JCq"
    "0jkX5sPJIvJ03O/R+yZ5709JkmQjgDUicgPJo0Dy3yIUtC7P85NJ/i7JWSQfDjx05PoEd+yoXkjg"
    "yMruQvJle7aP3qckV5E8muR2JA8iucz+5+3viZ1q7AhubktyTROO+49auWMRaruwCWl/YydtEz3v"
    "fHZfOo5URn2wa8nzlq5du3Ybku6cc85xLSKWR5Xcu3cnKDDqkwdYQfHe/2cX4yI1N//MJo+9oIgU"
    "eojy7kLy1jLRbR7mkRcQypo8z88xo98T7WDnAe/98pK2+1azeoZ3rl+/fqb33pfIv1eZbJHrdR7J"
    "M7z3t+d5/jWSyxyAb5iWB4DJSZJcrqpLATxg1oiGEGAW0tl3CxqNxu5muZMulA9Xr179DlX9EYBt"
    "DIGE9zh717YAfmTy/ATAzuE67/1FIrLRLErb1iBofxF5WVUvteeNmPVsAPCq+qlW6MdQ25Cqzrb7"
    "MjvnALxz7ttdjtFGLEd0ZCZj2bEh+rvbooV3ZgDeN2XKlMtEROfNm9eK8wt1HynI3E1ZV1Knkegd"
    "ZUdZW6zroS1GCvWJ+wS9Ih+Sh9vcOsLa3dtZI2TP6LPauJqWJMk8AHcMDw9PNyTSq5v/amH8Zs65"
    "L5OcY2O8mQEO3odX1TzqC20x7zyAJwCs8N7fKSIpgNtR0PojEQph4W+WfL90eHj4dwIZ2wF5lQIQ"
    "kjePEW7XgiUIPNTCitDXHhHnFOc+rVy7du02ZVY0smKHFtrC272PdcqPRQjo3FbpEGOUY3tAQH8Q"
    "vVMLMpxTZhGjdjiipA/36hIBPVgRAlrSAwI6vVCf0A7ndYuAonY+JBrDcXvnLaqTR9eFex8iObWb"
    "YFABAT1Z4uF4kq+Q3LU4nqJUmRmWH0jvfTw/92jV7ySnrVmzZhrJaeFzamjgYuNXPm3aViIkUlac"
    "abz3TZky5SoAh5tCacc3DbzP+QCONO070ExxRhyP2nVLAJxqDandKCCzHiIij5P8GYCPRfyTd85N"
    "nzx58qEkr414gGI5NpIrcEiO5BWR9fA9WihaGzwB4GmrP0vQywQAz3XKh43VT1bveSQfFZFbe+U/"
    "2ih3m2VtBBSsquqcmwzgo9F4DO3yiqre55zbrC2cc49uYYQ+Sc4EcLX1YeCqwhhPAKwE8DCAFcZz"
    "7gJgn4gTdXZvZt9/V0TmVjTO4vmmAKaq6g8tyPNaL5xTYd6tLfBJa+NQ8gSS946VAFjMBzQt+J12"
    "rENkZeaWRLxaGjU7v0Dy3VVEmSJZTiixeEryluJ7IuuxDcmVJSjtFZI7dBHGboaAwvnPao52lSGg"
    "mIt7uZjyUCUCakPOGSQ3FKw0ST5UdRSoagQUtdc1JchHvfc5ybNJbvcGf7zR2Ivk4hJvJDzj0C5Q"
    "bysEVERd10Z1lgoQ0BvC/i5oNhFpmFV/LtK67UTRcufcGSQ/a5Y/HSPiNStJkkuiSJe0gQJomv94"
    "Efm1PUt7HHMeAJIkuRXA8yYLg0yqejDJmQVfOyEp3vtDAEy3Z0hkgX4sIisqki8uE4zEGzRj4aLE"
    "NVdjwlpAdtsAuI7kUJ1h2kLdXMh/aTQak5qMk2Zt4bYU9GPjZzcAc6IxvwmpOudOEZHzRGRlVOeE"
    "pEyYMOEx44pujvoiIBWq6t9YX7Bi0QP6PS7P879qxQd1iIAYjvDZRS5JIiIrTAk1OoDzAQJ+L8uy"
    "A8uEtY7whg6uBzCx4GKNpSgSAKeLyN3mMvoqGsPqPKyq10cQXswNm+S9P7LgiqqIMEmSYyPFGP//"
    "srrGcglJuek7EdEqIPIYg3FvVf2+Kdakzb7r2DWOD2tvHYPc3Oza6POWUMK4OMGMtUYGy6nqDSJy"
    "JcmBoKxEJBcRHwVLFMAXVHV1UDxBiTnn9gOwe0WENApzPgHgkyS5gOTBItJtakRbDQRTEKmIPADg"
    "cxHPwzb8RgEw4JxbSHJHe5YrQL5BVb0OwMzQAW3Il1vH/YOIXGLy5RVPbDjnrohk2lTfJEnmBCUY"
    "WbMZAA6KfPfgnz8O4J5euKlWUSpTMHlsRWJrgvrzxXLn3Nw8z8+oazC+DYu38XBgweCKjbvv2jwp"
    "VZrBoxCRF51zNxTQdjDMB43B13bDAzGa1wmAq8wbyGpTQIUKXwngW1HyYTvP8c657QFcT3KryBcM"
    "7sj3nXMf6SDJLBB1dwL4UsVkW5GMfgzAzyIUFBTRLJK72iQPruWfAJgSuV9h4FwZJmaFSiG005dI"
    "3gvgfsuVeYDkfSQf9N5fWVMG64bRaOum+gWLON+QbqOvX8ZO+AOwjaruHM0TGvp5CcB/jYXwon79"
    "jyZew54VBh+8qq6MlFAAIdsDuDogtaGhIalFAUVaOxGRs1T11oi1bxeq7wPgUmvYAVNqZ+L1DN+0"
    "zbyUBMBTBl+Dq8GaXAwAWFCwUN7qPrvQwXMKCCoFsG79+vU/jGRHhdYIGM1W3Q/ArOjYF8CHnHP7"
    "1ODuQVVX2rIbFylbAZCmaXq1RXXQR0Jj9t12zrmphbEN59xyEXkl0AGt+kNEmGXZ8sKcFeunmRUp"
    "IB0Vy50N4MnIuIZ5vT+Ab9u8drUpIGsMkhTn3EkAfhnxPG1BdQCfyvP8bBFpkDwCwIUdIB81Engd"
    "gNkisgqAq9GvD/W6RVVfjMjo0DazSQ6KSGZLUz5cSEUAgNsmTZr0vzWQz7GMxQTEjXYeroW8cG47"
    "59zZqnpH1P+hzjsAWGhRo6yva1qWiU2M7sY2USsBYGBgYL0h0iLpPFSRAgpu13KMLiPKI64xzOu/"
    "yPP8OACrnHNpXQgINonE4vazAawpsPBjIQpNkuRckmcBuMTudW1GvBSAOOdOtjydWnNPIjJ6rXNu"
    "UTThA1zezVwx8d4fg9EcjTzKCgfqI5/jNh0sHBPtvHWNBGpmRuiFwhq9HMBHSJ6dpqnv6xi0k92+"
    "uZVVHTRF3w7HiizLJopIrCg2U2RVBQW899uKyGPe+68UgEeY15cYGlrdpvxjIpZW/EgiIr8ieSKA"
    "WyMWX9ogpQHg/EixuHZ5H+/936VpemMNpPNYZQGAP49QUOCh/lRE7iE5uxCedoYQf1oT+RwG2+MA"
    "ltmgDcS52uenC+i1qqIAJonIsizLTkzT9M6C26kAvqaqj1kiYH9fphLk8uqrr64aGhpa55ybViCg"
    "Z5CcJCJjJvrZ2JpRoCfCOFhRpQJKkiSzgMvFJPcEMLdAnUxV1X9xzk2s4r1uDHQQImOLvfdfNiE6"
    "sXi+RGOjVcRLVRemafoNyycaF+tq9RQR+bmq3h/5v6F9PkZyFoAPFDJG4b2/0qIDSQ0cVaj/P4vI"
    "MUmSHJkkySeSJPmEiBydJMkfJ0nylzU2TU5SBgYGflJiER2A1Dn3h31d07zMnz9/FYBnC4aYAN4J"
    "4AMWqHGth6dQVfdv4mr9okoFFIGPFMAXADwazXsBQOfcDIyu06xXAcWRsTRNLzJXo93IGDsQzpvy"
    "WeKc+4x1ih+nEPNmZLRz7rKS9nkvRhftxmH6FMCrSZJcVwP5/AYeoUkiYu1Jd+aiDqRpepGlUcSG"
    "gTXX+y1bQh7Pueeeq865ewpjJLj4nw15VWVckEV+leQ7nHNzzHVLovHKLMvurmn8ORFZ32g0jitQ"
    "MFLIgUOtCijOgzGNeG8bSEgjjmQs1yRAyhdGRkbmiMiGGtyJTtDGzQBeimGuEX0HFSJkALBYRH5T"
    "I/lcliA25gZXNRQl6VavXv05AP8d8UHSd73a6rOFBRoiuLAnkTxMREaCwoqOxBISFcBFGA2Fe9t7"
    "J4y/RwYGBh4x9K415DAlEydOXIbRCLZEybBj0TDVKqAodXoEwHEAftNsuYYx9U5Vvao+Y2jJNZlA"
    "my2z2Gqrrf5nnCZzSzJaVW8oKKWiAnAWAbp8nHaPyyxLdqSYLRwdrHsiTZ8+fZ31/7qKF76+XVFQ"
    "SGBdAuA2Gzd5ZMgGVPV6kp8hOcGyoMPhSc703i8AcGrJMg4BcKEFaFyN8qcicrOqfr0LCqYyBNTu"
    "co0wEX7lvf+wc253AB/CKFFbBhM9gMR7f5rt5pfWvNq63RD0gkKHx75u4IaeWLp06V01u1+bcklI"
    "ziS504YNG94dHyR3JPlekpNqnkyh/3/pvf98B5nyfRhESqPR+Gvbf2czV8ZW+l8K4DGSP/Def9N7"
    "f6H3/iZVfdyikDEfmZkiuB3AorDMqeZs7jRJkrNVdXEdSqjbPZxPLFnRHlbVHlG49pBmK3rbXUk/"
    "3r8KYTsDlO3VElYin1WV3G3sB9QguY7ka977zQ6Sw7ZP9pEV7QcU+mg9yfeU7AgQZJ1fsrq70tXw"
    "4f6NGzfuHO0FHq+Gf7iqLPCa9wNK7NnHl+wBpC323SruMhD2A3rK9keXTtu4xWr4vNnOmsHFHx4e"
    "nk7ymRZ7he3Rab+7LixhWK5xlarGyzViH/cZ2zpywM7PFpY4hPD2Hc65M+tYZtELGS0iNOgrJa5I"
    "CuA1ANeOA/kcyiBG9+0ecs5tdmB0WciENjPMK+MGAHwFwF1vukV867hiSZqm15o7lUURRY34lTw6"
    "fDRnwvwaMA7uMBF5wSJkOg7yKwA3derU32ZZdnzk/ei4uWBNYNlZqnpLtFwjDMTjRCQTkQ0iknnv"
    "j40ge3BtlmF0mQVR3zKLXrbpuBGjm0QFjiqHbdOpqneIyPJONoDvIPcmb3JkTY6NdtYeOZ6ydzbj"
    "A2mw/wRVDVuZZNF9rBiVNpOvDsXXrA+0CiUkIpcBOFhVl1i7JcVFqiU5dSlJUdXLARxQ3Pi9x7Fe"
    "rCdb8UGDg4MPATgtciV76ve0B8JWDc6dBOA+jObIBE7gq977rVX1Lufc/s650wrs+TCAY0Tk5XHY"
    "Za9bMno1yZsAfL7YXqr6r1b3qgnoIXtHJ/0yEKEk9JCQOrHw3ZRWmfLWRs+T/KSqLnbOTep1XLXo"
    "kwRAGcc1rYYhsFWhD8J5UlVISETutd0Gj1PVk51zs5o9X1VXOOfuzPP80sHBwQcR7TNUQV23Lumr"
    "CW14Pz/w3u/mnDujV30iFW24tAuA+61CzbKeY9fraBG5aUtTPsVtNDG6CPTIKAnLYXTj88stIlj1"
    "xlWzMLrWLO8AnYb2vs0sYyc/RRN+MmVrACcWtmLIAVwtIk1/WiiSe1eMpikE3mChiPy21608I/mm"
    "GVpOCnV+SUSurbgP9sLrW/QG1ygF8KCIPFDF5C8+g+TvA3i/jbfJ3nsmSbIKo4uxnwiLVsO4rMJb"
    "sGedgNd/ECJ4RIvtJ5Wa9blEhvowjG4dG9zIa0RkVVVbuHZEsGVZdniBOMsK50By/e2WRDr3y//f"
    "H2DcAoIdSQe/KOq2NPmrDPP2HMURkTzP81OTJPkng7Fl5WIRCXv76BbE+7Rq5KRkewRf42Tumpfr"
    "5cfqynYqaHcdXonclWaxN5Ovjr5o0Qe17bRo7yy69CykttQFHqTbcVRyv3/T5nS0Sfm+9nM7q23T"
    "7fUW0j52nLJ2+6Vf+uUtUv4PXRJc6JvNjZ8AAAAASUVORK5CYII="
)

_DOCS_TEMPLATE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{title} | Vention API</title>
<link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"/>
<style>
  :root {{
    /* Background layers (darkest → lightest) */
    --bg-base: #0B1120;
    --bg-main: #0F172A;
    --bg-card: #1E293B;
    --bg-code: #0B1120;

    /* Borders */
    --border-subtle: #1E293B;
    --border-default: #334155;

    /* Text (brightest → dimmest) */
    --text-primary: #F1F5F9;
    --text-secondary: #E2E8F0;
    --text-tertiary: #CBD5E1;
    --text-muted: #94A3B8;
    --text-faint: #64748B;
    --text-dim: #475569;

    /* Accent */
    --accent-blue: #3B82F6;
    --accent-blue-hover: #2563EB;
    --accent-blue-dark: #1E40AF;
    --accent-link: #60A5FA;
  }}

  * {{ font-family: Inter, system-ui, -apple-system, sans-serif; }}
  body {{ margin: 0; background: var(--bg-base); }}

  /* --- Header bar --- */
  .swagger-ui .topbar {{ display: none; }}
  .vention-header {{
    background: var(--bg-base);
    padding: 20px 32px;
    display: flex; align-items: center; gap: 20px;
    border-bottom: 1px solid var(--border-subtle);
  }}
  .vention-header img {{ height: 31px; }}
  .vention-header .divider {{
    width: 1px; height: 28px; background: var(--border-default);
  }}
  .vention-header .subtitle {{
    font-size: 15px; font-weight: 500; color: var(--text-muted);
    letter-spacing: 0.3px;
  }}
  .vention-header .version {{
    margin-left: auto;
    font-size: 12px; font-weight: 500; color: var(--text-dim);
    background: var(--bg-card); padding: 4px 10px; border-radius: 12px;
  }}

  /* --- Main content area --- */
  .swagger-ui {{ background: var(--bg-main); }}
  .swagger-ui .wrapper {{ padding: 0 32px; max-width: 1400px; }}

  /* --- Info section --- */
  .swagger-ui .info {{ margin: 28px 0 20px; }}
  .swagger-ui .info hgroup.main {{ margin: 0; }}
  .swagger-ui .info .title {{ color: var(--text-primary); font-weight: 700; font-size: 24px; }}
  .swagger-ui .info .title small {{ background: var(--accent-blue); color: white; padding: 2px 8px; border-radius: 4px; font-size: 12px; }}
  .swagger-ui .info .description, .swagger-ui .info .description p {{ color: var(--text-muted); font-size: 14px; }}
  .swagger-ui .info a {{ color: var(--accent-link); }}

  /* --- Tag sections --- */
  .swagger-ui .opblock-tag-section {{ margin-bottom: 8px; }}
  .swagger-ui .opblock-tag {{
    color: var(--text-secondary); font-weight: 600; font-size: 18px;
    border-bottom: 1px solid var(--border-subtle); padding: 14px 0;
  }}
  .swagger-ui .opblock-tag:hover {{ background: rgba(59, 130, 246, 0.05); }}
  .swagger-ui .opblock-tag small {{ color: var(--text-muted); }}

  /* --- Endpoint blocks --- */
  .swagger-ui .opblock {{ background: var(--bg-card); border-radius: 8px; margin-bottom: 6px; border: 1px solid var(--border-default); }}
  .swagger-ui .opblock .opblock-summary {{ border: none; padding: 10px 16px; }}
  .swagger-ui .opblock.opblock-post {{ border-color: var(--accent-blue-dark); }}
  .swagger-ui .opblock.opblock-post .opblock-summary-method {{
    background: var(--accent-blue); font-weight: 700; font-size: 13px;
    border-radius: 4px; min-width: 60px; text-align: center;
  }}
  .swagger-ui .opblock.opblock-post .opblock-summary-path {{ color: var(--text-secondary); font-weight: 500; }}
  .swagger-ui .opblock.opblock-post .opblock-summary-description {{ color: var(--text-muted); }}

  /* --- Deprecated --- */
  .swagger-ui .opblock.opblock-deprecated {{ border-color: var(--border-default); opacity: 0.5; }}
  .swagger-ui .opblock.opblock-deprecated .opblock-summary-method {{ background: var(--text-dim); }}

  /* --- Expanded content --- */
  .swagger-ui .opblock-body {{ background: var(--bg-main); }}
  .swagger-ui .opblock-body pre.microlight {{ background: var(--bg-code) !important; border: 1px solid var(--border-subtle); border-radius: 6px; }}
  .swagger-ui .opblock-description-wrapper,
  .swagger-ui .opblock-external-docs-wrapper,
  .swagger-ui .opblock-description-wrapper p,
  .swagger-ui .opblock-description-wrapper .markdown,
  .swagger-ui .opblock-description-wrapper .renderedMarkdown,
  .swagger-ui .opblock-description-wrapper .renderedMarkdown p,
  .swagger-ui .opblock-description,
  .swagger-ui .opblock-body .opblock-description {{ color: var(--text-muted) !important; }}
  .swagger-ui .opblock-section-header {{ background: var(--bg-card); border-bottom: 1px solid var(--border-default); }}
  .swagger-ui .opblock-section-header h4 {{ color: var(--text-secondary); }}
  .swagger-ui table thead tr th {{ color: var(--text-muted); border-bottom: 1px solid var(--border-default); }}
  .swagger-ui table tbody tr td {{ color: var(--text-tertiary); border-bottom: 1px solid var(--border-subtle); }}
  .swagger-ui .parameter__name {{ color: var(--text-secondary); }}
  .swagger-ui .parameter__type {{ color: var(--accent-link); }}

  /* --- Tabs and labels (Edit Value / Schema) --- */
  .swagger-ui .tab li {{ color: var(--text-muted); }}
  .swagger-ui .tab li.active {{ color: var(--text-secondary); }}
  .swagger-ui .opblock-section-header label {{ color: var(--text-tertiary); }}

  /* --- Execute button --- */
  .swagger-ui .btn.execute {{
    background: var(--accent-blue); border: none; border-radius: 6px;
    font-weight: 600; padding: 8px 24px;
  }}
  .swagger-ui .btn.execute:hover {{ background: var(--accent-blue-hover); }}
  .swagger-ui .btn.cancel {{ border-color: var(--text-dim); color: var(--text-muted); border-radius: 6px; }}

  /* --- Response section --- */
  .swagger-ui .responses-wrapper {{ background: var(--bg-main); }}
  .swagger-ui .response-col_status {{ color: var(--text-secondary); }}
  .swagger-ui .response-col_description {{ color: var(--text-tertiary); }}
  .swagger-ui .responses-inner h4, .swagger-ui .responses-inner h5 {{ color: var(--text-secondary); }}
  .swagger-ui .response-control-media-type__accept-message {{ color: var(--text-muted); }}

  /* --- Models section --- */
  .swagger-ui section.models {{ background: var(--bg-card); border: 1px solid var(--border-default); border-radius: 8px; }}
  .swagger-ui section.models h4 {{ color: var(--text-secondary); border-bottom: 1px solid var(--border-default); }}
  .swagger-ui .model-title {{ color: var(--text-secondary); }}
  .swagger-ui .model {{ color: var(--text-tertiary); }}
  .swagger-ui .model .property {{ color: var(--text-muted); }}
  .swagger-ui .model .property.primitive {{ color: var(--accent-link); }}
  .swagger-ui section.models .model-container {{ background: var(--bg-main); border-radius: 4px; margin: 4px 0; }}

  /* --- Scrollbar --- */
  ::-webkit-scrollbar {{ width: 8px; }}
  ::-webkit-scrollbar-track {{ background: var(--bg-main); }}
  ::-webkit-scrollbar-thumb {{ background: var(--border-default); border-radius: 4px; }}
  ::-webkit-scrollbar-thumb:hover {{ background: var(--text-dim); }}

  /* --- Misc overrides --- */
  .swagger-ui .scheme-container {{ background: var(--bg-card); border-bottom: 1px solid var(--border-default); }}
  .swagger-ui select {{ background: var(--bg-card); color: var(--text-secondary); border: 1px solid var(--border-default); border-radius: 4px; }}
  .swagger-ui input[type=text] {{ background: var(--bg-card); color: var(--text-secondary); border: 1px solid var(--border-default); border-radius: 4px; }}
  .swagger-ui textarea {{ background: var(--bg-code); color: var(--text-secondary); border: 1px solid var(--border-default); border-radius: 4px; }}
  .swagger-ui .loading-container .loading::after {{ color: var(--accent-blue); }}

  /* --- Catch-all: force minimum text brightness across all Swagger elements --- */
  .swagger-ui {{ color: var(--text-muted); }}
  .swagger-ui label {{ color: var(--text-tertiary); }}
  .swagger-ui .btn {{ color: var(--text-secondary); }}
  .swagger-ui p {{ color: var(--text-tertiary); }}
  .swagger-ui span {{ color: var(--text-muted); }}
  .swagger-ui li {{ color: var(--text-muted); }}
  .swagger-ui .markdown p, .swagger-ui .renderedMarkdown p {{ color: var(--text-tertiary); }}
</style>
</head>
<body>
<div class="vention-header">
  <img src="data:image/png;base64,{logo_b64}" alt="Vention"/>
  <div class="divider"></div>
  <span class="subtitle">{subtitle}</span>
  <span class="version">{version_badge}</span>
</div>
<div id="swagger-ui"></div>
<script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
<script>
SwaggerUIBundle({{
  url: "/openapi.json",
  dom_id: "#swagger-ui",
  deepLinking: true,
  docExpansion: "list",
  defaultModelsExpandDepth: 1,
  persistAuthorization: true,
  tryItOutEnabled: true,
}})
</script>
</body>
</html>"""


def mount_branded_docs(app: FastAPI) -> None:
    """Mount the Vention-branded Swagger UI at ``/docs``.

    Reads ``title``, ``description``, and ``version`` from the FastAPI app
    instance to populate the header. Disables the default Swagger UI first.

    Args:
        app: The FastAPI (or VentionApp) instance.
    """
    title = getattr(app, "title", "Vention App")
    version = getattr(app, "version", "")
    version_badge = f"v{version}" if version else ""
    subtitle = title

    html = _DOCS_TEMPLATE.format(
        title=title,
        subtitle=subtitle,
        version_badge=version_badge,
        logo_b64=_VENTION_LOGO_B64,
    )

    @app.get("/docs", include_in_schema=False)
    async def _branded_docs() -> HTMLResponse:
        return HTMLResponse(html)
