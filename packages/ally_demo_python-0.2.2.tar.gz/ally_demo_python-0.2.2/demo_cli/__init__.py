"""Demo CLI that emits cli.error.v0.1 for Ally integration."""

__version__ = "0.1.0"
