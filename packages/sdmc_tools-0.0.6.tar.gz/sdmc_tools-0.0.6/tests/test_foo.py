import os
import pandas as pd
import sdmc_tools.process as sdmc
import sdmc_tools.constants as constants
import pytest

def test_pass():
	assert True

def test_again_pass():
	assert 1 > 0

# def test_fail():
# 	assert False

DATASET_BASIC = pd.DataFrame(data={
	'sample_id':[1,2,3],
	'result':[10,100,1000],
})

DATASET_WITH_NONEXISTANT_GUSPECS = pd.DataFrame(data={
	'guspec':['a','b','c'],
	'result':[10,100,1000],
})

DATASET_WITH_GUSPECS = pd.DataFrame(data={
	'guspec':['0177-02ZNQF00-011', '0378-00Z5SH00-025', '0373-01L2KA00-002',
       '0169-02B5SJ00-003', '0012-01DB1E00-004'],
	'reading':[1,2,3,4,5],
})

ldms = pd.DataFrame({
    'guspec':['0012-01DB1E00-004',
             '0169-02B5SJ00-003',
             '0169-02B5SJ00-003',
             '0177-02ZNQF00-011',
             '0373-01L2KA00-002',
             '0378-00Z5SH00-025'],
    'txtpid':['1',
			'2',
			'3',
			'4',
			'5',
			'6'],
    'drawdm':[9, 11, 11, 8, 6, 5],
    'drawdd':[7, 11, 11, 8, 28, 2],
    'drawdy':[2022, 2022, 2022, 2022, 2022, 2022],
    'vidval':[12.0, 14.0, 14.0, 8.0, 7.0, 8.0],
    'lstudy':[302.0, 302.0, 302.0, 302.0, 302.0, 302.0],
    'primstr':['LPK', 'BLD', 'BLD', 'BLD', 'BLD', 'LPK'],
    'addstr':['ACD', 'EDT', 'EDT', 'ACD', 'SST', 'ACD'],
    'dervstr':['CEL', 'PLA', 'PLA', 'CEL', 'SER', 'CEL'],
})

def test_correct_gusepcs():
	outputs = sdmc.standard_processing(
    input_data=DATASET_WITH_GUSPECS,
    input_data_path="/path/to/data.xlsx",
    guspec_col='guspec',
    network='HVTN',
    metadata_dict={'col_a':'some val', 'col_b':'some other val'},
    ldms=ldms
	)
	assert outputs.loc[outputs.guspec=="0177-02ZNQF00-011"].drawdt.iloc[0]=="2022-08-08"
	assert outputs.loc[outputs.guspec=="0169-02B5SJ00-003"].input_file_name.iloc[0]=="data.xlsx"
	assert outputs.loc[outputs.guspec=="0373-01L2KA00-002"].spec_primary.iloc[0]=="BLD"

def test_incorrect_guspecs():
	pass

def test_no_change_in_size():
	pass
