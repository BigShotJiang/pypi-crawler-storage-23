---
# @TITLE
## Author: Beatrix Haddock and Sara Thiebaud
## sdmc.lab@hvtn.org
## Date: @DATE
---

## Data Request

Ad hoc data processing is required to add merge on LDMS specimen metadata based on guspec, in addition to misc. metadata from the LUT and other study materials.

## Source Data

The script uses:

* Input data saved at @INPUT-DATA-PATH
* inputs from LDMS pulled from Delphi
* human-entered inputs from misc sources (LSP, LUT, etc.)

## Output Data

Processed output data is saved to:

* @OUTPUT-SAVEPATH
* @QDATA-SAVEPATH

@PIVOT-SAVEPATH
@DRAFT-DESIGNATION-NOTE
## Data Dictionary

@DATA-DICTIONARY

## Things to note

Add here details on anything we calculated, or any red flags about the data

* Eg xyz column calculated by us as log(a-b)
* Eg we found blah blah discrepancy

## Processing

The processing was done in a python notebook, and the code was resaved to the following file:

* @CODE-SAVEPATH

If applicable, include info here on decisions we made or other abnormalities

## Background

* If there was any sort of history or back and forth with the lab
* Other context that might be relevant for how data came to be
* Change log including all changes to outputs

## Checks

* TODO: Checked for completeness against shipping manifest

TODO: Reviewed on XXXX-XX-XX by Sara Thiebaud:

* Reviewed code for logical consistency
* Reviewed documentation for accuracy against outputs and standard SDMC processes
* Reviewed data for consistency with assay materials and expected values
* Spot-checked a subset of records for result and metadata values matching input data
