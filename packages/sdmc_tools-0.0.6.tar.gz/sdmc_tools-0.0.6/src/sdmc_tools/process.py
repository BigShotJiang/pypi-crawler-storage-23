import pandas as pd
import numpy as np
import os
from typing import List, Union
import datetime
import warnings
from sdmc_tools import constants

## IF YOU REFACTOR, THESE ARE THE ONES YOU HAVE TO POTENTIALLY EDIT:

#   - HVTN128/PKSMC
#   - HVTN303/VRC_NAb
#   - HVTN703_704/Geraghty_genotyping
#   - HVTN805_093/Geraghty_genotyping

def standard_processing(
    input_data: pd.DataFrame,
    input_data_path: Union[str, List[str]],
    guspec_col: str,
    network: str,
    metadata_dict: dict,
    ldms: pd.DataFrame,
    ldms_usecols: List[str] = constants.STANDARD_COLS,
    cols_to_lower: bool = True,
    additional_input_paths: dict = {},
    ) -> pd.DataFrame:

    data = add_ldms(ldms, input_data, guspec_col)
    data = processing_minus_ldms(data,
                                 metadata_dict,
                                 input_data_path,
                                 additional_input_paths,
                                 cols_to_lower)
    return data

def processing_minus_ldms(
    input_data: pd.DataFrame,
    metadata_dict: dict,
    input_data_path: Union[str, List[str]],
    additional_input_paths: dict = {},
    cols_to_lower: bool = True,
    ) -> pd.DataFrame:
    """
    add metadata, sdmc processing info,
    standardize column order and format,
    checks for the above
    """
    data = add_metadata(input_data, metadata_dict)
    data = add_sdmc_processing_info(data,
                                    input_data_path,
                                    additional_input_paths)
    reorder = reorder_cols(data.columns)
    data = data[reorder]

    if cols_to_lower:
        data.columns = [i.lower().strip().replace(" ","_") for i in data.columns]

    if len(data.columns)!=len(np.unique(data.columns)):
        raise Warning("Column names aren't unique!")

    return data

def add_ldms(
    ldms: pd.DataFrame,
    data: pd.DataFrame,
    guspec_col: str='guspec',
    incl_spec_type: bool=True,
    map_drawdt: bool=True,
    relabel: bool=True,
    enforce_typing=True):
    """
    Merge ldms onto data
    Optionally add spec_type and drawdt columns
    Optionally relabel with standard relabelling names
    """
    # check for standard LDMS cols
    missing_from_standard = set(constants.STANDARD_COLS).difference(ldms.columns)
    if len(missing_from_standard) > 0:
        warnings.warn(f"The following columns aren't in ldms: {missing_from_standard}")

    if guspec_col not in data.columns:
        raise Exception(f"{guspec_col} must be a column in data")

    if 'guspec' not in ldms.columns:
        raise Exception(f"'guspec' must be a column in ldms")

    # ensure ldms deduped
    use_ldms = ldms.drop_duplicates().reset_index(drop=True)

    # subset down to only the LDMS rows that are applicable
    use_ldms = use_ldms.loc[use_ldms.guspec.isin(data[guspec_col])]

    if incl_spec_type:
        if set(['primstr', 'dervstr']).issubset(use_ldms.columns):
            use_ldms.loc[use_ldms.dervstr.isna(), "dervstr"] = "N/A"
            use_ldms["spectype"] = use_ldms.apply(lambda x: _map_spectype(x), axis=1)
        else:
            raise Exception("Need to pull primstr and dervstr for spectype")

    if map_drawdt:
        if not set(['drawdy', 'drawdm', 'drawdd']).issubset(use_ldms.columns):
            raise Exception("Need ['drawdy', 'drawdm', 'drawdd'] in ldms columns for drawdt")
        use_ldms["drawdy"] = use_ldms["drawdy"].astype(int)
        use_ldms["drawdm"] = use_ldms["drawdm"].astype(int)
        use_ldms["drawdd"] = use_ldms["drawdd"].astype(int)
        use_ldms["drawdt"] = use_ldms.apply(
            lambda x: datetime.date(x.drawdy, x.drawdm, x.drawdd).isoformat(), axis=1
        )
        use_ldms = use_ldms.drop(columns=["drawdy", "drawdm", "drawdd"])

    if enforce_typing:
        for col in ['txtpid', 'lstudy']:
            if col in use_ldms.columns:
                use_ldms[col] = use_ldms[col].astype(str).astype(float).astype(int).astype("string")
        if 'vidval' in use_ldms.columns:
            use_ldms.vidval = use_ldms.vidval.astype("string")

    if relabel:
        use_ldms = use_ldms.rename(columns=constants.LDMS_RELABEL_DICT)

    ## CHECKS ---------------------- ##
    # ensure guspec_col non-NA
    n_missing_guspecs = data[guspec_col].isna().sum()
    if n_missing_guspecs > 0:
        warnings.warn(f"Data has {n_missing_guspecs} without guspecs")

    # ensure all data guspecs in ldms
    guspec_diff = set(data[guspec_col]).difference(ldms.guspec)
    if len(guspec_diff) > 0:
        warnings.warn(f"The following guspecs not in ldms: {guspec_diff}")

    # merge ldms on
    with_ldms = data.merge(
        use_ldms,
        left_on=guspec_col,
        right_on="guspec",
        how="left"
    )

    # check that the nrows didn't change
    row_diff = len(with_ldms) - len(data)
    if row_diff != 0:
        warnings.warn(f"ldms merge resulted in {row_diff} additional rows")

    return with_ldms

def _map_spectype(x):
    """
    Add a spectype column
    """
    try:
        return constants.SPEC_TYPE_DEFN_MAP[x.primstr, x.dervstr]
    except:
        print(f"{x.primstr}, {x.dervstr} missing from spec map!")
        return "MISSING FROM MAP"

def add_metadata(
    data: pd.DataFrame,
    metadata: dict):
    """
    INPUT: dictionary of column names and values.
    INPUT EXAMPLE: {"upload_lab_id": "DG",
                    "assay_lab_name": "Geraghty Lab (FHCRC)",
                    "instrument": "Illumina NGS"}
    FUNCTION: adds corresponding columns to self.processed_data
    """
    already_exists = set(metadata.keys()).intersection(data.columns)
    if already_exists:
        print(f"The following cols are already in processed_data: {already_exists}; replacing")
        data = data.drop(columns=already_exists)
    metadata = pd.DataFrame({i: [metadata[i]] for i in metadata.keys()})
    data = data.merge(metadata, how = 'cross')
    return data

def add_sdmc_processing_info(
    data: pd.DataFrame,
    input_data_path: Union[str, list],
    additional_input_paths: dict = {}):
    """
    Adds sdmc_processing_datetime, sdmc_data_receipt_datetime, and
    input_file_name cols to data
    - sdmc_processing_datetime: current time
    - sdmc_data_receipt_datetime: read from input_data_path timestamp
    - input_file_name: read from input_data_path
    """
    if isinstance(input_data_path, list):
        warnings.warn("Using timestamp from first input_data_path provided. This functionality is deprecated, please use additional_inputs for additional input file columns")
        fname = ", ".join(np.unique([i.split("/")[-1] for i in input_data_path]))
        input_data_path = input_data_path[0]
    else:
        fname = input_data_path.split("/")[-1]

    # check if input data path exists
    if os.path.exists(input_data_path):
        data_receipt_datetime = datetime.datetime.fromtimestamp(os.path.getmtime(input_data_path)).replace(microsecond=0).isoformat()
    else:
        stem = input_data_path.rpartition("/")[0]
        data_receipt_datetime = "ERROR"
        if os.path.exists(stem):
            alternates = os.listdir(stem)
            warnings.warn("Caution: input path doesn't exist. The directory does exist; did you mean any of these? {alternates}")
        else:
            warnings.warn("Caution: directory of input path doesn't exist")

    sdmc_processing_datetime = datetime.datetime.now().replace(microsecond=0).isoformat()
    sdmc_metadata = pd.DataFrame({
        "sdmc_processing_datetime": [sdmc_processing_datetime],
        # "sdmc_processing_version": [1.0],
        "sdmc_data_receipt_datetime": [data_receipt_datetime],
        "input_file_name": [fname],
    })

    if len(additional_input_paths) > 0:
        for key, value in additional_input_paths.items():
            if not os.path.exists(value):
                warnings.warn(f"Caution: input path {value} doesn't exist.")
            sdmc_metadata[key] = value.split("/")[-1]

    # if these columns are already in processed_data, drop and replace
    already_exists = set(sdmc_metadata.columns).intersection(data.columns)
    if len(already_exists)>0:
        warnings.warn(f"These columns were already in data; replacing: {already_exists}")
    data = data.drop(columns=already_exists)

    # add processing metadata columns
    return data.merge(sdmc_metadata, how="cross")

def reorder_cols(input_cols: List[str]) -> List[str]:
    """
    Given a list of columns, returns a reordered list.
    """
    usecols = []
    for col in constants.STD_PREFACE_COLS:
        if col in input_cols:
            usecols += [col]
    for col in np.sort(list(set(input_cols).difference(
    constants.STD_PREFACE_COLS + constants.STD_POSTFACE_COLS
    ))):
        usecols += [col]

    for col in constants.STD_POSTFACE_COLS:
        if col in input_cols:
            usecols += [col]

    return usecols

# def _pull_ldms(network, protocol):
    """
    i think this shouldn't exist; it's already quite straightforward
    and very readable to pull using the constants
    """
#     try:
#         protocol = int(protocol)
#     except:
#         print(f"Wasn't able to convert {protocol} to int!")
#     if network.upper()=="HVTN":
#         ldms = pd.read_csv(
#             constants.LDMS_PATH_HVTN,
#             usecols=constants.STANDARD_COLS,
#             dtype=constants.LDMS_DTYPE_MAP
#             )
#     elif network.upper()=="COVPN":
#         ldms = pd.read_csv(
#             constants.LDMS_PATH_COVPN,
#             usecols=constants.STANDARD_COLS,
#             dtype=constants.LDMS_DTYPE_MAP
#             )
#     else:
#         raise Exception(f"Network {network} not valid; need HVTN or CoVPN")
#
#     ldms = ldms.loc[ldms.lstudy==protocol]
#     return ldms
