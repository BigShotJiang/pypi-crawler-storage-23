## ---------------------------------------------------------------------------##
# Author: Beatrix Haddock
# Date: 06/05/2024
# Purpose:  Auto generate a README for ad hoc processed data.
# INPUTS:   - /path/to/yaml
#
# OUTPUTS:  - README.html
#           - README.md
## ---------------------------------------------------------------------------##
import markdown
import datetime
import pandas as pd
import numpy as np
import yaml
import os
import sys
import sdmc_tools.constants as constants
## ---------------------------------------------------------------------------##

#TODO: CONSIDER WRAPPING EACH CALL IN A FUNCTION
#TODO: TEST THIS OUT, MAKE SURE IT WORKS FOR SIMPLEST CASE
#TODO: TEST THIS OUT FOR CASES WITH MULTIPLE INPUTS
#TODO: TEST THIS OUT FOR CASES WITH MULTIPLE OUTPUTS
#TODO: WRAP IN COMMAND LINE FN AND REBUILD

YAML_PATH = sys.argv[1]

with open(YAML_PATH, 'r') as file:
    yamldict = yaml.safe_load(file)


def gen_README():
    VAR_DICT = {}

    ## TITLE ---------------------------------------------------------------- ##
    if isinstance(yamldict["output_prefix"], list):
        title = yamldict["output_prefix"][0]
    else:
        title = yamldict["output_prefix"]

    start = 0
    if "draft_" in title.lower():
        start = title.lower().find("draft_")
    stop = -1
    if "_process" in title.lower():
        stop = title.lower().find("_process")
    title = title[start:stop].replace("_", " ").replace("-"," ") + " Data Processing"
    VAR_DICT["@TITLE"] = title

    ## DATE ----------------------------------------------------------------- ##
    VAR_DICT["@DATE"] = datetime.date.today().isoformat()

    ## INPUT DATA PATH ------------------------------------------------------ ##
    input_data_path = yamldict["input_data_path"]
    if isinstance(input_data_path, list):
        if len(input_data_path)==1:
            input_data_path_string = input_data_path[0]
        elif len(input_data_path)>1:
            input_data_path_string = ", ".join(input_data_path)
        elif len(input_data_path)==0:
            input_data_path_string = "@INPUT-DATA-PATH"
    else:
        input_data_path_string = input_data_path

    VAR_DICT["@INPUT-DATA-PATH"] = input_data_path_string

    ## OUTPUT-SAVEPATH ------------------------------------------------------ ##
    OUTPUT_DIR = yamldict["savedir"]
    if OUTPUT_DIR[-1]!="/":
        OUTPUT_DIR += "/"
    OUTPUT_DIR_FILES = os.listdir(OUTPUT_DIR)
    #filter out weird things saved by excel
    OUTPUT_DIR_FILES = list(np.unique([
        f[2:] if f[:2]=="~$" else f for f in OUTPUT_DIR_FILES
    ]))
    output_savepath = [o for o in OUTPUT_DIR_FILES if "process" in o.lower() and ".txt" in o]
    if len(output_savepath)>0:
        if len(output_savepath)>1:
            tmp = output_savepath[0]
            for o in output_savepath[1:]:
                tmp += f"\n* {OUTPUT_DIR + o}"
            output_savepath = tmp
        elif len(output_savepath)==1:
            output_savepath = OUTPUT_DIR + output_savepath[0]

        VAR_DICT["@OUTPUT-SAVEPATH"] = output_savepath
    elif len(output_savepath)==0:
        print(f"/studies folder missing outputs: {OUTPUT_DIR}, {yamldict['output_prefix']}")

    ## LDMS-PATH ------------------------------------------------------------ ##
    if isinstance(output_savepath, list):
        output_savepath = output_savepath[0]

    if "hvtn" in output_savepath.lower() and "covpn" not in output_savepath.lower():
        NETWORK = "HVTN"
        VAR_DICT["@LDMS-PATH"] = constants.LDMS_PATH_HVTN
    elif "covpn" in output_savepath.lower() and "hvtn" not in output_savepath.lower():
        NETWORK = "CoVPN"
        VAR_DICT["@LDMS-PATH"] = constants.LDMS_PATH_COVPN

    ## QDATA-SAVEPATH ------------------------------------------------------- ##
    if isinstance(input_data_path, list):
        input_data_path = input_data_path[0]
    qdata_dir = input_data_path.rpartition("/")[0]
    VAR_DICT["@QDATA-SAVEPATH"] = qdata_dir + '/processed_by_sdmc'

    ## PIVOT-SAVEPATH, PIVOT-WRITING ---------------------------------------- ##
    pivots = [p for p in OUTPUT_DIR_FILES if "summary" in p]
    if len(pivots)>0:
        VAR_DICT["@PIVOT-WRITING"] = "* Generate a pivot summary."
        if len(pivots)==1:
            VAR_DICT["@PIVOT-SAVEPATH"] = f'\nA pivot summary is saved to:\n\n* {OUTPUT_DIR + pivots[0]}'
        elif len(pivots)>1:
            VAR_DICT["@PIVOT-SAVEPATH"] = '\nPivot summaries have been saved to:\n'
            for p in pivots:
                VAR_DICT["@PIVOT-SAVEPATH"] += f"\n* {OUTPUT_DIR + p}"
    elif len(pivots)==0:
        VAR_DICT["@PIVOT-SAVEPATH"] = ""
        VAR_DICT["@PIVOT-WRITING"] = ""

    ## DRAFT-DESIGNATION-NTE ------------------------------------------------ ##
    if "@OUTPUT-SAVEPATH" in VAR_DICT:
        if "DRAFT" in VAR_DICT["@OUTPUT-SAVEPATH"]:
            VAR_DICT['@DRAFT-DESIGNATION-NOTE'] = '\nNote the "DRAFT_" designation will be removed after review from stats.\n'
        else:
            VAR_DICT['@DRAFT-DESIGNATION-NOTE'] = ""

    ## CODE-SAVEPATH -------------------------------------------------------- ##
    if "/" in YAML_PATH:
        CODE_DIR = YAML_PATH.rpartition("/")[0]
    else:
        CODE_DIR = os.getcwd()
    if "process_data.py" in os.listdir(CODE_DIR):
        stem = CODE_DIR.partition("processing_scripts")[-1]
        link = "https://github.com/beatrixh/sdmc_adhoc/blob/main/processing_scripts" + stem + "/process_data.py"
        VAR_DICT["@CODE-SAVEPATH"] = link
    else:
        print(f"CODE (process_data.py) NOT FOUND IN {CODE_DIR}")

    ## DATA-DICTIONARY ------------------------------------------------------ ##
    dict_path = [d for d in OUTPUT_DIR_FILES if "dict" in d and ".xlsx" in d]
    if len(dict_path)==0:
        print("NO DATA DICTIONARY FOUND")
    else:
        if len(dict_path)>1:
            dict_path = np.sort(dict_path)[-1]
            print(f"WARNING: MULTIPLE DICTS. JUST TAKING MOST RECENT: {dict_path}")
        elif len(dict_path)==1:
            dict_path = dict_path[0]
        datadict = pd.read_excel(OUTPUT_DIR + dict_path)
        datadict = datadict.fillna("")

    ## read in template, replace vals ----------------------------------------##
    template_path = os.path.dirname(__file__) + "/readme_template.md"
    with open(template_path, 'r') as f:
        template_text = f.read()

    print("Making the following assignments:")
    for key in VAR_DICT.keys():
        print(f"{key}: {VAR_DICT[key]}")
        template_text = template_text.replace(key, VAR_DICT[key])

    name = VAR_DICT["@TITLE"].split(" Data Processing")[0].replace(" ","_")
    today = datetime.date.today().isoformat()
    with open(f"{OUTPUT_DIR}{name}_Processing_Notes_{today}.md", 'w') as f:
        f.write(template_text)

    html = markdown.markdown(template_text)

    # create data dict table
    if len(dict_path)>0:
        html = html.replace("@DATA-DICTIONARY", format_table_in_html(datadict))

    # compile any remaining tables
    while "@TABLE-START" in html:
        a = html.find("@TABLE-START")
        b = html.find("@TABLE-STOP")

        table = html[a + len("@TABLE-START\n"):b]
        table = [i.split(",") for i in table.split("\n")]
        table = pd.DataFrame(columns=table[0], data=table[1:-1])

        html = html[:a] + "\n" + format_table_in_html(table) + "\n" + html[b + len("@TABLE-STOP"):]

    # html = "<style>\n*{font-family: sans-serif;}\n</style>\n" + html
    html = headertext + "<body>\n" + html + "</body></html>"

    print(f"this is the supposed name: {OUTPUT_DIR}{name}_Processing_Notes.html")
    with open(f"{OUTPUT_DIR}{name}_Processing_Notes.html", 'w') as f:
        f.write(html)

def format_table_in_html(mydict):
    table_html = "<table>\n"
    table_html += "<tr>\n"
    for col in mydict.columns:
        table_html += f"<th>{col}</th>\n"
    table_html += "</tr>"
    for row in range(len(mydict)):
        table_html += "<tr>\n"
        for col in range(mydict.shape[1]):
            table_html += f"<td>{mydict.iloc[row, col]}</td>\n"
        table_html += "</tr>\n"
    table_html += "</table>\n"
    return table_html

headertext = '<!DOCTYPE html>\n<html>\n<head>\n<style>\n*{font-family: sans-serif;}\ntable {\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  width: 40%;\n}\n\ntd, th {\n  border: 1px solid #dddddd;\n  text-align: left;\n  padding: 8px;\n}\n\ntr:nth-child(even) {\n  background-color: #dddddd;\n}\n</style>\n</head>\n\n\n'

if __name__=="__main__":
    gen_README()
