"""Tests for auto_build package."""
