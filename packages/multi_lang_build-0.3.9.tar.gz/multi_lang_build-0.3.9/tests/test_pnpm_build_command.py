"""测试 PNPM 编译器的自定义构建命令功能。"""

from pathlib import Path
from unittest.mock import patch

import pytest

from multi_lang_build.compiler.pnpm import PnpmCompiler


class TestPnpmPrepareCommand:
    """测试 _prepare_command 方法。"""

    def test_default_command(self):
        """测试默认命令。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command=None, default_cmd=["pnpm", "build"]
        )
        assert cmd == ["pnpm", "build"]

    def test_string_command(self):
        """测试字符串命令。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command="vite build --mode production",
            default_cmd=["pnpm", "build"],
        )
        assert cmd == ["vite", "build", "--mode", "production"]

    def test_list_command(self):
        """测试列表命令。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command=["vite", "build", "--mode", "production"],
            default_cmd=["pnpm", "build"],
        )
        assert cmd == ["vite", "build", "--mode", "production"]

    def test_string_command_with_quotes(self):
        """测试带引号的字符串命令。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command='npm run build -- --foo="bar baz"',
            default_cmd=["pnpm", "build"],
        )
        assert cmd == ["npm", "run", "build", "--", "--foo=bar baz"]

    def test_default_command_with_extra_args(self):
        """测试默认命令带额外参数。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command=None,
            default_cmd=["pnpm", "build"],
            extra_args=["--mode", "production"],
        )
        assert cmd == ["pnpm", "build", "--mode", "production"]

    def test_custom_command_with_extra_args(self):
        """测试自定义命令带额外参数。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command="vite build",
            default_cmd=["pnpm", "build"],
            extra_args=["--mode", "production"],
        )
        assert cmd == ["vite", "build", "--mode", "production"]

    def test_empty_string_command(self):
        """测试空字符串命令。"""
        compiler = PnpmCompiler()
        cmd = compiler._prepare_command(
            custom_command="", default_cmd=["pnpm", "build"]
        )
        assert cmd == []


class TestPnpmBuildCommand:
    """测试 build 方法的自定义命令功能。"""

    def test_build_with_default_command(self, tmp_path: Path):
        """测试默认构建命令。"""
        # Create mock project structure
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        package_json = project_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        compiler = PnpmCompiler()

        with patch.object(
            PnpmCompiler, "_get_executable_path", return_value="/usr/bin/pnpm"
        ):
            with patch(
                "multi_lang_build.compiler.pnpm_support.executor.PnpmExecutor.execute"
            ) as mock_execute:
                mock_execute.return_value = {
                    "success": True,
                    "return_code": 0,
                    "stdout": "Build complete",
                    "stderr": "",
                    "output_path": project_dir / "dist",
                    "duration_seconds": 1.0,
                }

                compiler.build(
                    source_dir=project_dir,
                    output_dir=tmp_path / "dist",
                    build_command=None,
                )

                # Check that install command uses pnpm install
                install_call = mock_execute.call_args_list[0]
                install_cmd = install_call[0][0]
                assert "install" in install_cmd

                # Check that build command uses default pnpm build (with full path)
                build_call = mock_execute.call_args_list[1]
                build_cmd = build_call[0][0]
                assert build_cmd[-1] == "build"  # Last element should be "build"

    def test_build_with_custom_string_command(self, tmp_path: Path):
        """测试自定义字符串构建命令。"""
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        package_json = project_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        compiler = PnpmCompiler()

        with patch.object(
            PnpmCompiler, "_get_executable_path", return_value="/usr/bin/pnpm"
        ):
            with patch(
                "multi_lang_build.compiler.pnpm_support.executor.PnpmExecutor.execute"
            ) as mock_execute:
                mock_execute.return_value = {
                    "success": True,
                    "return_code": 0,
                    "stdout": "Build complete",
                    "stderr": "",
                    "output_path": project_dir / "dist",
                    "duration_seconds": 1.0,
                }

                compiler.build(
                    source_dir=project_dir,
                    output_dir=tmp_path / "dist",
                    build_command="vite build",
                )

                build_call = mock_execute.call_args_list[1]
                build_cmd = build_call[0][0]
                assert build_cmd == ["vite", "build"]

    def test_build_with_custom_list_command(self, tmp_path: Path):
        """测试自定义列表构建命令。"""
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        package_json = project_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        compiler = PnpmCompiler()

        with patch.object(
            PnpmCompiler, "_get_executable_path", return_value="/usr/bin/pnpm"
        ):
            with patch(
                "multi_lang_build.compiler.pnpm_support.executor.PnpmExecutor.execute"
            ) as mock_execute:
                mock_execute.return_value = {
                    "success": True,
                    "return_code": 0,
                    "stdout": "Build complete",
                    "stderr": "",
                    "output_path": project_dir / "dist",
                    "duration_seconds": 1.0,
                }

                compiler.build(
                    source_dir=project_dir,
                    output_dir=tmp_path / "dist",
                    build_command=["vite", "build", "--mode", "production"],
                )

                build_call = mock_execute.call_args_list[1]
                build_cmd = build_call[0][0]
                assert build_cmd == ["vite", "build", "--mode", "production"]

    def test_build_with_custom_install_command(self, tmp_path: Path):
        """测试自定义安装命令。"""
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        package_json = project_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        compiler = PnpmCompiler()

        with patch.object(
            PnpmCompiler, "_get_executable_path", return_value="/usr/bin/pnpm"
        ):
            with patch(
                "multi_lang_build.compiler.pnpm_support.executor.PnpmExecutor.execute"
            ) as mock_execute:
                mock_execute.return_value = {
                    "success": True,
                    "return_code": 0,
                    "stdout": "Build complete",
                    "stderr": "",
                    "output_path": project_dir / "dist",
                    "duration_seconds": 1.0,
                }

                compiler.build(
                    source_dir=project_dir,
                    output_dir=tmp_path / "dist",
                    install_command="pnpm install --frozen-lockfile",
                )

                install_call = mock_execute.call_args_list[0]
                install_cmd = install_call[0][0]
                assert install_cmd == ["pnpm", "install", "--frozen-lockfile"]

    def test_build_with_extra_args(self, tmp_path: Path):
        """测试额外参数。"""
        project_dir = tmp_path / "project"
        project_dir.mkdir()
        package_json = project_dir / "package.json"
        package_json.write_text('{"name": "test"}')

        compiler = PnpmCompiler()

        with patch.object(
            PnpmCompiler, "_get_executable_path", return_value="/usr/bin/pnpm"
        ):
            with patch(
                "multi_lang_build.compiler.pnpm_support.executor.PnpmExecutor.execute"
            ) as mock_execute:
                mock_execute.return_value = {
                    "success": True,
                    "return_code": 0,
                    "stdout": "Build complete",
                    "stderr": "",
                    "output_path": project_dir / "dist",
                    "duration_seconds": 1.0,
                }

                compiler.build(
                    source_dir=project_dir,
                    output_dir=tmp_path / "dist",
                    build_command="vite build",
                    extra_args=["--mode", "production"],
                )

                build_call = mock_execute.call_args_list[1]
                build_cmd = build_call[0][0]
                assert build_cmd == ["vite", "build", "--mode", "production"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
