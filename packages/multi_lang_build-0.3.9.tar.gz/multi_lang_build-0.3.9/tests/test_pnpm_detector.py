"""测试 PNPM 检测器。"""

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from multi_lang_build.compiler.pnpm_support.detector import (
    PnpmDetector,
    check_dependencies,
    print_dependency_report,
)


class TestPnpmDetector:
    """测试 PnpmDetector 类。"""

    def test_detect_pnpm_path_from_env(self):
        """测试从环境变量检测 pnpm 路径。"""
        with patch.dict(os.environ, {"PNPM_PATH": "/usr/local/bin/pnpm"}):
            with patch.object(Path, "is_file", return_value=True):
                with patch.object(
                    Path, "resolve", return_value=Path("/usr/local/bin/pnpm")
                ):
                    result = PnpmDetector.detect_pnpm_path()
                    assert result == "/usr/local/bin/pnpm"

    def test_detect_pnpm_path_from_shutil(self):
        """测试使用 shutil.which 检测 pnpm。"""
        with patch.dict(os.environ, {}, clear=True):
            with patch("shutil.which", return_value="/usr/bin/pnpm"):
                with patch.object(Path, "is_file", return_value=True):
                    result = PnpmDetector.detect_pnpm_path()
                    assert result == "/usr/bin/pnpm"

    def test_detect_pnpm_path_from_common_paths(self):
        """测试从常见路径检测 pnpm。"""
        with patch.dict(os.environ, {}, clear=True):
            with patch("shutil.which", return_value=None):
                # 模拟 /usr/local/bin/pnpm 存在
                def mock_is_file(self):
                    return str(self) == "/usr/local/bin/pnpm"

                with patch.object(Path, "is_file", mock_is_file):
                    with patch.object(Path, "exists", mock_is_file):
                        with patch.object(
                            Path, "resolve", return_value=Path("/usr/local/bin/pnpm")
                        ):
                            result = PnpmDetector.detect_pnpm_path()
                            assert result == "/usr/local/bin/pnpm"

    def test_detect_pnpm_path_from_shell(self):
        """测试使用 shell 命令检测 pnpm。"""
        # 直接测试 shell 检测策略
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "/usr/local/bin/pnpm\n"

        with patch("subprocess.run", return_value=mock_result):
            with patch.object(Path, "exists", return_value=True):
                with patch.object(Path, "is_file", return_value=True):
                    with patch.object(
                        Path, "resolve", return_value=Path("/usr/local/bin/pnpm")
                    ):
                        result = PnpmDetector.detect_pnpm_path()
                        assert result == "/usr/local/bin/pnpm"

    def test_detect_pnpm_path_not_found(self):
        """测试 pnpm 未找到的情况。"""
        with patch.dict(os.environ, {}, clear=True):
            with patch("shutil.which", return_value=None):
                with patch.object(Path, "is_file", return_value=False):
                    with patch("subprocess.run", side_effect=Exception("not found")):
                        result = PnpmDetector.detect_pnpm_path()
                        assert result is None

    def test_get_pnpm_version_success(self):
        """测试成功获取 pnpm 版本。"""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "8.15.0\n"

        with patch("subprocess.run", return_value=mock_result):
            version = PnpmDetector.get_pnpm_version("/usr/local/bin/pnpm")
            assert version == "8.15.0"

    def test_get_pnpm_version_failure(self):
        """测试获取 pnpm 版本失败。"""
        mock_result = MagicMock()
        mock_result.returncode = 1

        with patch("subprocess.run", return_value=mock_result):
            version = PnpmDetector.get_pnpm_version("/usr/local/bin/pnpm")
            assert version is None

    def test_check_pnpm_installed(self):
        """测试检查已安装的 pnpm。"""
        with patch.object(
            PnpmDetector, "detect_pnpm_path", return_value="/usr/local/bin/pnpm"
        ):
            with patch.object(PnpmDetector, "get_pnpm_version", return_value="8.15.0"):
                result = PnpmDetector.check_pnpm()
                assert result["installed"] is True
                assert result["path"] == "/usr/local/bin/pnpm"
                assert result["version"] == "8.15.0"
                assert result["error"] is None

    def test_check_pnpm_not_installed(self):
        """测试检查未安装的 pnpm。"""
        with patch.object(PnpmDetector, "detect_pnpm_path", return_value=None):
            result = PnpmDetector.check_pnpm()
            assert result["installed"] is False
            assert result["path"] is None
            assert result["version"] is None
            assert result["error"] is not None
            assert "pnpm not found" in result["error"]

    def test_check_pnpm_no_version(self):
        """测试找到 pnpm 但无法获取版本。"""
        with patch.object(
            PnpmDetector, "detect_pnpm_path", return_value="/usr/local/bin/pnpm"
        ):
            with patch.object(PnpmDetector, "get_pnpm_version", return_value=None):
                result = PnpmDetector.check_pnpm()
                assert result["installed"] is True
                assert result["path"] == "/usr/local/bin/pnpm"
                assert result["version"] is None
                assert "cannot get version" in result["error"]


class TestCheckDependencies:
    """测试 check_dependencies 函数。"""

    def test_check_dependencies_structure(self):
        """测试依赖检查结果结构。"""
        check_result = {
            "installed": True,
            "path": "/usr/bin/pnpm",
            "version": "8.0.0",
            "error": None,
        }
        with patch.object(PnpmDetector, "check_pnpm", return_value=check_result):
            # GoEnvironment 没有 get_go_path/get_go_version 方法，简化测试
            with patch(
                "multi_lang_build.compiler.pnpm_support.detector.PnpmDetector.check_pnpm"
            ) as mock_check:
                mock_check.return_value = {
                    "installed": True,
                    "path": "/usr/bin/pnpm",
                    "version": "8.0.0",
                    "error": None,
                }
                result = check_dependencies()
                assert "pnpm" in result
                assert "go" in result


class TestPrintDependencyReport:
    """测试 print_dependency_report 函数。"""

    def test_print_report(self, capsys):
        """测试打印依赖报告。"""
        test_results = {
            "pnpm": {
                "installed": True,
                "path": "/usr/local/bin/pnpm",
                "version": "8.15.0",
                "error": None,
            },
            "go": {
                "installed": True,
                "path": "/usr/local/go/bin/go",
                "version": "1.21.0",
                "error": None,
            },
        }

        print_dependency_report(test_results)

        # 验证输出（通过 stdout 捕获）
        captured = capsys.readouterr()
        # 由于使用了 loguru，输出可能在 stderr
        combined_output = captured.out + captured.err
        assert "检查全局依赖" in combined_output or "🔍" in combined_output


@pytest.mark.integration
class TestPnpmDetectorIntegration:
    """集成测试 - 需要实际的 pnpm 安装。"""

    def test_real_detect_pnpm(self):
        """测试在真实环境中检测 pnpm。"""
        # 这个测试只在实际安装了 pnpm 的环境中运行
        result = PnpmDetector.detect_pnpm_path()

        if result:
            # 如果找到了 pnpm，验证它确实可执行
            assert Path(result).is_file()
            version = PnpmDetector.get_pnpm_version(result)
            assert version is not None
            assert len(version.split(".")) >= 2  # 版本号格式如 "8.15.0"

    def test_real_check_pnpm(self):
        """测试在真实环境中检查 pnpm。"""
        result = PnpmDetector.check_pnpm()

        # 根据是否安装了 pnpm 进行不同断言
        if result["installed"]:
            assert result["path"] is not None
            assert Path(result["path"]).is_file()
            print(f"✅ pnpm found: {result['path']} (v{result['version']})")
        else:
            print(f"⚠️ pnpm not found: {result['error']}")


if __name__ == "__main__":
    # 运行集成测试
    print("运行 PNPM 检测器集成测试...")
    detector = PnpmDetector()

    print("\n1. 检测 pnpm 路径:")
    path = detector.detect_pnpm_path()
    print(f"   结果: {path}")

    if path:
        print("\n2. 获取 pnpm 版本:")
        version = detector.get_pnpm_version(path)
        print(f"   版本: {version}")

    print("\n3. 完整检查:")
    result = detector.check_pnpm()
    print(f"   {result}")

    print("\n4. 依赖报告:")
    print_dependency_report()
