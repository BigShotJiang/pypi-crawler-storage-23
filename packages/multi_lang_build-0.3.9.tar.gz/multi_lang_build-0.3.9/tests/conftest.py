"""Pytest configuration for auto-build tests."""

from collections.abc import Generator
from pathlib import Path

import pytest


@pytest.fixture
def sample_source_dir(tmp_path: Path) -> Generator[Path, None, None]:
    """Create a sample source directory for testing."""
    src_dir = tmp_path / "sample_project"
    src_dir.mkdir()
    yield src_dir


@pytest.fixture
def sample_pnpm_project(tmp_path: Path) -> Path:
    """Create a sample pnpm project structure."""
    project_dir = tmp_path / "pnpm_project"
    project_dir.mkdir()

    package_json = project_dir / "package.json"
    package_json.write_text(
        '{"name": "test-project", "version": "1.0.0", "scripts": {"build": "echo build"}}'
    )

    return project_dir


@pytest.fixture
def sample_go_project(tmp_path: Path) -> Path:
    """Create a sample Go project structure."""
    project_dir = tmp_path / "go_project"
    project_dir.mkdir()

    go_mod = project_dir / "go.mod"
    go_mod.write_text("module github.com/test/project\n\ngo 1.21\n")

    main_go = project_dir / "main.go"
    main_go.write_text("package main\n\nfunc main() {}\n")

    return project_dir


@pytest.fixture
def sample_python_project(tmp_path: Path) -> Path:
    """Create a sample Python project structure."""
    project_dir = tmp_path / "python_project"
    project_dir.mkdir()

    pyproject = project_dir / "pyproject.toml"
    pyproject.write_text('[project]\nname = "test-project"\nversion = "1.0.0"\n')

    return project_dir
