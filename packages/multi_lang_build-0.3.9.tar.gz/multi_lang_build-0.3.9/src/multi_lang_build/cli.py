"""AutoBuild 工具的命令行接口。"""

from collections.abc import Sequence
from pathlib import Path
from typing import TypedDict


class BuildResult(TypedDict):
    """构建操作的结果。"""

    success: bool
    return_code: int
    stdout: str
    stderr: str
    output_path: Path | None
    duration_seconds: float


def run_cli(args: Sequence[str]) -> None:
    """使用给定的参数运行命令行接口。

    Args:
        args: 命令行参数（不包括程序名）
    """
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        description="AutoBuild - 多语言自动化构建工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s pnpm ./src --output ./dist --mirror
  %(prog)s go ./src --output ./bin/app --mirror
  %(prog)s python ./src --output ./dist --mirror --poetry

支持的语言:
  pnpm    - 前端 JavaScript/TypeScript 项目
  go      - Go 模块项目
  python  - Python pip/poetry/pdm 项目
        """,
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__import__('multi_lang_build').__version__}",
    )

    subparsers = parser.add_subparsers(
        dest="language",
        title="语言",
        description="特定语言的构建工具",
    )

    pnpm_parser = subparsers.add_parser(
        "pnpm",
        help="构建基于 pnpm 的前端项目",
        description="使用镜像加速构建基于 pnpm 的前端项目",
    )
    pnpm_parser.add_argument("source_dir", type=Path, help="源码目录")
    pnpm_parser.add_argument(
        "-o", "--output", type=Path, required=True, help="输出目录"
    )
    pnpm_parser.add_argument(
        "--mirror/--no-mirror", default=True, help="启用/禁用镜像加速"
    )
    pnpm_parser.add_argument("--script", type=str, help="运行指定的 npm 脚本")
    pnpm_parser.add_argument("--install", action="store_true", help="仅安装依赖")
    pnpm_parser.add_argument(
        "--stream/--no-stream",
        dest="stream_output",
        default=True,
        help="启用/禁用实时输出流（默认：启用）",
    )

    go_parser = subparsers.add_parser(
        "go",
        help="构建 Go 项目",
        description="使用模块支持和镜像加速构建 Go 项目",
    )
    go_parser.add_argument("source_dir", type=Path, help="源码目录")
    go_parser.add_argument(
        "-o", "--output", type=Path, required=True, help="输出文件或目录"
    )
    go_parser.add_argument(
        "--mirror",
        dest="mirror",
        action="store_true",
        default=True,
        help="启用 Go 代理镜像",
    )
    go_parser.add_argument(
        "--no-mirror", dest="mirror", action="store_false", help="禁用 Go 代理镜像"
    )
    go_parser.add_argument("--ldflags", type=str, help="链接器标志")
    go_parser.add_argument("--tags", type=str, help="构建标签（逗号分隔）")
    go_parser.add_argument(
        "--target", type=str, help="构建目标包（例如：./cmd/server）"
    )
    go_parser.add_argument("--test", action="store_true", help="运行测试而不是构建")
    go_parser.add_argument("--tidy", action="store_true", help="运行 go mod tidy")
    go_parser.add_argument("--all", action="store_true", help="构建所有包")
    go_parser.add_argument(
        "--stream/--no-stream",
        dest="stream_output",
        default=True,
        help="启用/禁用实时输出流（默认：启用）",
    )

    python_parser = subparsers.add_parser(
        "python",
        help="构建 Python 项目",
        description="使用 pip/poetry/pdm 和镜像加速构建 Python 项目",
    )
    python_parser.add_argument("source_dir", type=Path, help="源码目录")
    python_parser.add_argument(
        "-o", "--output", type=Path, required=True, help="输出目录"
    )
    python_parser.add_argument(
        "--mirror/--no-mirror", default=True, help="启用/禁用 PyPI 镜像"
    )
    python_parser.add_argument("--install", action="store_true", help="仅安装依赖")
    python_parser.add_argument("--dev", action="store_true", help="包含开发依赖")
    python_parser.add_argument("--poetry", action="store_true", help="强制使用 poetry")
    python_parser.add_argument(
        "--create-venv", type=Path, help="在指定路径创建虚拟环境"
    )
    python_parser.add_argument(
        "--stream/--no-stream",
        dest="stream_output",
        default=True,
        help="启用/禁用实时输出流（默认：启用）",
    )

    mirror_parser = subparsers.add_parser(
        "mirror",
        help="管理镜像配置",
        description="列出或配置国内镜像加速设置",
        epilog="""
示例:
  %(prog)s mirror list              列出所有可用镜像
  %(prog)s mirror set pip           配置 pip 镜像（默认）
  %(prog)s mirror set go            配置 go 代理镜像
  %(prog)s mirror set pnpm          配置 pnpm 仓库镜像
  %(prog)s mirror show              显示当前配置
  %(prog)s mirror reset             重置配置
        """,
    )
    mirror_subparsers = mirror_parser.add_subparsers(dest="mirror_action")

    list_parser = mirror_subparsers.add_parser("list", help="列出可用镜像")
    list_parser.add_argument("--json", action="store_true", help="以 JSON 格式输出")

    set_parser = mirror_subparsers.add_parser("set", help="设置镜像配置")
    set_parser.add_argument(
        "type",
        type=str,
        default="pip",
        nargs="?",
        choices=["pip", "go", "npm", "pnpm"],
        help="包管理器类型（默认：pip）",
    )
    set_parser.add_argument(
        "mirror",
        type=str,
        nargs="?",
        default="pip",
        help="要使用的镜像",
    )

    show_parser = mirror_subparsers.add_parser("show", help="显示当前配置")
    show_parser.add_argument(
        "--global",
        dest="global_level",
        action="store_true",
        help="显示全局配置而不是项目级配置",
    )

    reset_parser = mirror_subparsers.add_parser("reset", help="重置配置")
    reset_parser.add_argument(
        "--global",
        dest="global_level",
        action="store_true",
        help="重置全局配置而不是项目级配置",
    )

    # IDE 集成注册子命令
    register_parser = subparsers.add_parser(
        "register",
        help="注册为 IDE 技能（Claude Code、OpenCode、Trae、CodeBuddy）",
        description="将 multi-lang-build 注册为各种 AI 编程助手和 IDE 的技能",
        epilog="""
示例:
  %(prog)s register              # 注册到 Claude Code（默认）
  %(prog)s register claude       # 注册到 Claude Code
  %(prog)s register opencode     # 注册到 OpenCode
  %(prog)s register trae         # 注册到 Trae
  %(prog)s register codebuddy    # 注册到 CodeBuddy
  %(prog)s register all          # 注册到所有支持的 IDE
        """,
    )
    register_parser.add_argument(
        "ide",
        nargs="?",
        default="claude",
        choices=["claude", "opencode", "trae", "codebuddy", "all"],
        help="要注册的 IDE（默认：claude）",
    )

    parsed_args = parser.parse_args(args)

    if parsed_args.language is None:
        parser.print_help()
        sys.exit(1)

    result: BuildResult | None = None

    try:
        if parsed_args.language == "pnpm":
            from multi_lang_build.compiler.pnpm import PnpmCompiler

            compiler = PnpmCompiler()

            if parsed_args.script:
                result = compiler.run_script(
                    parsed_args.source_dir,
                    parsed_args.script,
                    mirror_enabled=parsed_args.mirror,
                )
            elif parsed_args.install:
                result = compiler.install_dependencies(
                    parsed_args.source_dir,
                    mirror_enabled=parsed_args.mirror,
                )
            else:
                result = compiler.build(
                    parsed_args.source_dir,
                    parsed_args.output,
                    mirror_enabled=parsed_args.mirror,
                    stream_output=parsed_args.stream_output,
                )

        elif parsed_args.language == "go":
            from multi_lang_build.compiler.go_compiler import GoCompiler

            compiler = GoCompiler()

            if parsed_args.test:
                result = compiler.run_tests(
                    parsed_args.source_dir,
                    mirror_enabled=parsed_args.mirror,
                )
            elif parsed_args.tidy:
                result = compiler.tidy_modules(
                    parsed_args.source_dir,
                    mirror_enabled=parsed_args.mirror,
                )
            elif parsed_args.all:
                result = compiler.build_all(
                    parsed_args.source_dir,
                    parsed_args.output,
                    mirror_enabled=parsed_args.mirror,
                    stream_output=parsed_args.stream_output,
                )
            else:
                tags = parsed_args.tags.split(",") if parsed_args.tags else None
                result = compiler.build_binary(
                    parsed_args.source_dir,
                    parsed_args.output,
                    target=parsed_args.target,
                    mirror_enabled=parsed_args.mirror,
                    ldflags=parsed_args.ldflags,
                    tags=tags,
                    stream_output=parsed_args.stream_output,
                )

        elif parsed_args.language == "python":
            from multi_lang_build.compiler.python import PythonCompiler

            compiler = PythonCompiler()

            if parsed_args.create_venv:
                result = compiler.create_venv(
                    parsed_args.create_venv,
                    mirror_enabled=parsed_args.mirror,
                )
            elif parsed_args.install:
                result = compiler.install_dependencies(
                    parsed_args.source_dir,
                    mirror_enabled=parsed_args.mirror,
                    dev=parsed_args.dev,
                    poetry=parsed_args.poetry,
                )
            else:
                result = compiler.build(
                    parsed_args.source_dir,
                    parsed_args.output,
                    mirror_enabled=parsed_args.mirror,
                    stream_output=parsed_args.stream_output,
                )

        elif parsed_args.language == "mirror":
            from multi_lang_build.mirror.cli import (
                configure_mirror,
                get_current_config,
                print_mirrors,
            )

            if parsed_args.mirror_action == "list":
                if getattr(parsed_args, "json", False):
                    import json

                    from multi_lang_build.mirror.cli import get_all_mirrors

                    print(json.dumps(get_all_mirrors(), indent=2, ensure_ascii=False))
                else:
                    print_mirrors()
            elif parsed_args.mirror_action == "set":
                mirror_type = getattr(parsed_args, "type", "pip")
                mirror_key = getattr(parsed_args, "mirror", "pip")
                success = configure_mirror(mirror_type, mirror_key)
                sys.exit(0 if success else 1)
            elif parsed_args.mirror_action == "show":
                config = get_current_config()
                if config:
                    print("\n📦 Current Mirror Configuration:")
                    print("-" * 40)
                    for key, value in config.items():
                        print(f"  • {key}: {value}")
                    print()
                else:
                    print("\n📦 No mirror configured")
                    print(
                        "   Run 'multi-lang-build mirror set <type> <mirror>' to configure"
                    )
                    print()
                    print_mirrors()
            else:
                mirror_parser.print_help()

        elif parsed_args.language == "register":
            from multi_lang_build.register import register_skill

            success = register_skill(parsed_args.ide)
            if success:
                print("\n✅ Registration completed successfully!")
                print(
                    f"\nYou can now use 'multi-lang-build' commands in {parsed_args.ide}"
                )
            else:
                print("\n❌ Registration failed for some IDEs.")
            sys.exit(0 if success else 1)

        else:
            parser.print_help()
            sys.exit(1)

        if result is not None and result["success"]:
            print(f"Build completed successfully in {result['duration_seconds']:.2f}s")
            if result["output_path"]:
                print(f"Output: {result['output_path']}")
            sys.exit(0)
        elif result is not None:
            print(f"Build failed with code {result['return_code']}")
            if result["stderr"]:
                print(f"Error: {result['stderr']}")
            sys.exit(1)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(2)
