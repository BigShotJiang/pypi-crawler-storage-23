"""PNPM 依赖检测模块 - 优化版本。

解决常见问题：
1. pnpm 已安装但不在标准 PATH 中
2. shell 配置不同导致 which 命令失效
3. 使用绝对路径调用时环境变量缺失
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Final


class PnpmDetector:
    """优化的 PNPM 检测器，支持多种检测策略。"""

    # 常见的 pnpm 安装路径
    COMMON_PATHS: Final[list[str]] = [
        "/usr/local/bin/pnpm",
        "/usr/bin/pnpm",
        "/opt/homebrew/bin/pnpm",  # macOS Homebrew (Apple Silicon)
        "/usr/local/homebrew/bin/pnpm",  # macOS Homebrew (Intel)
        "~/.local/bin/pnpm",
        "~/.npm-global/bin/pnpm",
        "~/.nvm/versions/node/*/bin/pnpm",  # NVM
        "~/.volta/bin/pnpm",  # Volta
        "~/AppData/Roaming/npm/pnpm.cmd",  # Windows
        "~/AppData/Local/pnpm/pnpm.exe",  # Windows
    ]

    @staticmethod
    def detect_pnpm_path() -> str | None:
        """检测 pnpm 可执行文件路径。

        使用多种策略按优先级检测：
        1. 环境变量 PNPM_PATH
        2. shutil.which (标准 PATH 检测)
        3. 常见安装路径检查
        4. 使用 shell 命令检测

        Returns:
            pnpm 可执行文件的绝对路径，如果未找到则返回 None
        """
        # 策略 1: 检查环境变量
        env_path = os.environ.get("PNPM_PATH")
        if env_path and Path(env_path).is_file():
            return str(Path(env_path).resolve())

        # 策略 2: 标准 PATH 检测
        which_path = shutil.which("pnpm")
        if which_path:
            return str(Path(which_path).resolve())

        # 策略 3: 检查常见路径
        for path_template in PnpmDetector.COMMON_PATHS:
            expanded_path = Path(path_template).expanduser()
            # 支持通配符路径 (如 NVM)
            if "*" in str(expanded_path):
                import glob

                matches = glob.glob(str(expanded_path))
                if matches:
                    # 返回第一个匹配
                    return str(Path(matches[0]).resolve())
            elif expanded_path.is_file():
                return str(expanded_path.resolve())

        # 策略 4: 使用 shell 命令检测（处理某些 shell 配置问题）
        try:
            result = subprocess.run(
                ["bash", "-c", "which pnpm || command -v pnpm"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                path = result.stdout.strip()
                if path and Path(path).is_file():
                    return str(Path(path).resolve())
        except Exception:
            pass

        return None

    @staticmethod
    def get_pnpm_version(pnpm_path: str) -> str | None:
        """获取 pnpm 版本。

        Args:
            pnpm_path: pnpm 可执行文件路径

        Returns:
            版本字符串，如果获取失败则返回 None
        """
        try:
            result = subprocess.run(
                [pnpm_path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass
        return None

    @staticmethod
    def check_pnpm() -> dict:
        """全面检查 pnpm 安装状态。

        Returns:
            包含检测结果的详细信息字典
        """
        result = {
            "installed": False,
            "path": None,
            "version": None,
            "error": None,
        }

        pnpm_path = PnpmDetector.detect_pnpm_path()

        if pnpm_path is None:
            result["error"] = (
                "pnpm not found. Please install pnpm:\n"
                "  npm install -g pnpm\n"
                "Or set PNPM_PATH environment variable:\n"
                "  export PNPM_PATH=/path/to/pnpm"
            )
            return result

        result["path"] = pnpm_path
        result["installed"] = True

        version = PnpmDetector.get_pnpm_version(pnpm_path)
        if version:
            result["version"] = version
        else:
            result["error"] = f"Found pnpm at {pnpm_path} but cannot get version"

        return result


def check_dependencies() -> dict:
    """检查所有相关依赖。

    Returns:
        包含所有依赖检查结果的字典
    """
    import shutil
    import subprocess

    results = {
        "pnpm": PnpmDetector.check_pnpm(),
        "go": {"installed": False, "path": None, "version": None},
    }

    # 检查 Go
    try:
        go_path = shutil.which("go")
        if go_path:
            results["go"]["installed"] = True
            results["go"]["path"] = go_path
            # 获取 Go 版本
            try:
                version_result = subprocess.run(
                    [go_path, "version"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if version_result.returncode == 0:
                    # 输出格式: "go version go1.21.0 linux/amd64"
                    version_line = version_result.stdout.strip()
                    parts = version_line.split()
                    if len(parts) >= 3:
                        results["go"]["version"] = parts[2].replace("go", "")
            except Exception:
                pass
    except Exception as e:
        results["go"]["error"] = str(e)

    return results


def print_dependency_report(results: dict | None = None) -> None:
    """打印依赖检查报告。

    Args:
        results: 依赖检查结果，如果为 None 则自动执行检查
    """
    from multi_lang_build.log import logger

    if results is None:
        results = check_dependencies()

    logger.info("🔍 检查全局依赖...")

    # PNPM 检查
    pnpm_result = results.get("pnpm", {})
    if pnpm_result.get("installed"):
        version = pnpm_result.get("version", "unknown")
        path = pnpm_result.get("path", "unknown")
        logger.success(f"✅ pnpm 已安装: {version} ({path})")
    else:
        error = pnpm_result.get("error", "未知错误")
        logger.error("❌ pnpm 未安装或不在 PATH 中")
        logger.info(f"💡 {error}")

    # Go 检查
    go_result = results.get("go", {})
    if go_result.get("installed"):
        version = go_result.get("version", "unknown")
        logger.success(f"✅ Go 已安装: {version}")
    else:
        logger.error("❌ Go 未安装或不在 PATH 中")
        logger.info("💡 请安装 Go: https://golang.org/dl/")


if __name__ == "__main__":
    print_dependency_report()
