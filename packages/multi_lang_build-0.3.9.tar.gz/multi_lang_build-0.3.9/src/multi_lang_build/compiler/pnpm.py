"""支持镜像加速的 PNPM 编译器。"""

from pathlib import Path
from typing import Final

from multi_lang_build.compiler.base import BuildResult, CompilerBase, CompilerInfo
from multi_lang_build.compiler.pnpm_support import PnpmExecutor, PnpmProject
from multi_lang_build.compiler.pnpm_support.detector import PnpmDetector
from multi_lang_build.mirror.config import apply_mirror_environment
from multi_lang_build.types import CommandCategory, CommandConfig, ProjectCommands


class PnpmCompiler(CompilerBase):
    """用于基于 pnpm 的前端项目的编译器。"""

    NAME: Final[str] = "pnpm"
    DEFAULT_MIRROR: Final[str] = "https://registry.npmmirror.com"

    def __init__(self, pnpm_path: str | None = None) -> None:
        """初始化 PNPM 编译器。

        Args:
            pnpm_path: 可选的 pnpm 可执行文件路径。如果为 None，则使用系统 PATH。
        """
        self._pnpm_path = pnpm_path
        self._version_cache: str | None = None

    @property
    def name(self) -> str:
        """Get the compiler name."""
        return self.NAME

    @property
    def version(self) -> str:
        """Get the pnpm version."""
        if self._version_cache:
            return self._version_cache

        pnpm_executable = self._get_executable_path()
        import subprocess

        try:
            result = subprocess.run(
                [pnpm_executable, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            self._version_cache = result.stdout.strip()
        except Exception:
            self._version_cache = "unknown"

        return self._version_cache

    @property
    def supported_mirrors(self) -> list[str]:
        """Get list of supported mirror configurations."""
        return ["npm", "pnpm", "yarn"]

    def get_info(self) -> CompilerInfo:
        """Get compiler information."""
        return {
            "name": self.name,
            "version": self.version,
            "supported_mirrors": self.supported_mirrors,
            "default_mirror": self.DEFAULT_MIRROR,
            "executable": self._get_executable_path(),
        }

    def find_project_root(self, start_path: Path) -> Path | None:
        """Find the frontend project root directory containing package.json."""
        return PnpmProject.find_root(start_path)

    def build(
        self,
        source_dir: Path,
        output_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        extra_args: list[str] | None = None,
        stream_output: bool = True,
        build_command: str | list[str] | None = None,
        install_command: str | list[str] | None = None,
    ) -> BuildResult:
        """Execute the pnpm build process with auto-detection of project root.

        Args:
            source_dir: Source code directory or subdirectory
            output_dir: Build output directory
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration
            extra_args: Additional arguments to pass to pnpm build
            stream_output: Whether to stream output in real-time (default: True)
            build_command: Custom build command. Can be a string (e.g., "vite build")
                or a list of arguments (e.g., ["vite", "build", "--mode", "production"]).
                Defaults to "pnpm build" if not specified.
            install_command: Custom install command. Can be a string
                (e.g., "pnpm install --frozen-lockfile")
                or a list of arguments (e.g., ["pnpm", "install", "--frozen-lockfile"]).
                Defaults to "pnpm install" if not specified.

        Returns:
            BuildResult containing success status and output information.
        """
        pnpm_executable = self._get_executable_path()

        # Auto-detect project root
        project_root = self.find_project_root(source_dir)

        if project_root is None:
            return BuildResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=f"package.json not found in {source_dir} or its parent/sub directories",
                output_path=None,
                duration_seconds=0.0,
            )

        # Validate directories
        output_dir = self._validate_directory(output_dir, create_if_not_exists=True)

        # Prepare environment
        env = environment.copy() if environment else {}

        if mirror_enabled:
            env = apply_mirror_environment("pnpm", env)
            env = apply_mirror_environment("npm", env)

        # Prepare install command
        install_cmd = self._prepare_command(
            install_command, default_cmd=[pnpm_executable, "install"]
        )

        # Install dependencies in project root
        install_result = PnpmExecutor.execute(
            install_cmd,
            project_root,
            env,
            stream_output=stream_output,
        )

        if not install_result["success"]:
            return install_result

        # Prepare build command
        build_cmd = self._prepare_command(
            build_command, default_cmd=[pnpm_executable, "build"], extra_args=extra_args
        )

        return PnpmExecutor.execute(
            build_cmd,
            project_root,
            env,
            stream_output=stream_output,
        )

    def _prepare_command(
        self,
        custom_command: str | list[str] | None,
        default_cmd: list[str] | None = None,
        extra_args: list[str] | None = None,
    ) -> list[str]:
        """Prepare command from custom command or default.

        Args:
            custom_command: Custom command as string or list
            default_cmd: Default command as list (used when custom_command is None)
            extra_args: Extra arguments to append

        Returns:
            Command as list of strings
        """
        if custom_command is None:
            if default_cmd is None:
                return []
            cmd = default_cmd.copy()
        elif isinstance(custom_command, str):
            import shlex

            cmd = shlex.split(custom_command)
        else:
            cmd = list(custom_command)

        # Add extra args if provided
        if extra_args:
            cmd.extend(extra_args)

        return cmd

    def install_dependencies(
        self,
        source_dir: Path,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
        production: bool = False,
    ) -> BuildResult:
        """Install dependencies using pnpm with auto-detection of project root.

        Args:
            source_dir: Source code directory or subdirectory
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration
            production: Install only production dependencies

        Returns:
            BuildResult containing success status and output information.
        """
        pnpm_executable = self._get_executable_path()

        project_root = self.find_project_root(source_dir)

        if project_root is None:
            return BuildResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=f"package.json not found in {source_dir} or its parent/sub directories",
                output_path=None,
                duration_seconds=0.0,
            )

        env = environment.copy() if environment else {}

        if mirror_enabled:
            env = apply_mirror_environment("pnpm", env)

        command = [pnpm_executable, "install"]
        if production:
            command.append("--prod")

        return PnpmExecutor.execute(
            command,
            project_root,
            env,
            stream_output=True,
        )

    def run_command(
        self,
        source_dir: Path,
        command_config: CommandConfig,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> BuildResult:
        """Run a custom command with configuration.

        Args:
            source_dir: Source code directory or subdirectory
            command_config: Command configuration including name, command, stream_output, log_output
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration

        Returns:
            BuildResult containing success status and output information.
        """
        project_root = self.find_project_root(source_dir)

        if project_root is None:
            return BuildResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=f"package.json not found in {source_dir} or its parent/sub directories",
                output_path=None,
                duration_seconds=0.0,
            )

        env = environment.copy() if environment else {}

        if mirror_enabled:
            env = apply_mirror_environment("pnpm", env)

        cmd = self._prepare_command(command_config.get("command"))

        stream = command_config.get("stream_output", True)

        return PnpmExecutor.execute(cmd, project_root, env, stream_output=stream)

    def format(
        self,
        source_dir: Path,
        *,
        command_config: CommandConfig | None = None,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> BuildResult:
        """Run code formatting command.

        Args:
            source_dir: Source code directory or subdirectory
            command_config: Optional custom format command configuration
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration

        Returns:
            BuildResult containing success status and output information.
        """
        default_config: CommandConfig = {
            "name": "format",
            "command": ["pnpm", "run", "format"],
            "stream_output": True,
            "log_output": True,
        }

        config = command_config or default_config
        return self.run_command(
            source_dir, config, environment=environment, mirror_enabled=mirror_enabled
        )

    def lint(
        self,
        source_dir: Path,
        *,
        command_config: CommandConfig | None = None,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> BuildResult:
        """Run code quality check (lint) command.

        Args:
            source_dir: Source code directory or subdirectory
            command_config: Optional custom lint command configuration
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration

        Returns:
            BuildResult containing success status and output information.
        """
        default_config: CommandConfig = {
            "name": "lint",
            "command": ["pnpm", "run", "lint"],
            "stream_output": True,
            "log_output": True,
        }

        config = command_config or default_config
        return self.run_command(
            source_dir, config, environment=environment, mirror_enabled=mirror_enabled
        )

    def run_all_commands(
        self,
        source_dir: Path,
        commands: ProjectCommands,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> dict[CommandCategory, BuildResult]:
        """Run all configured commands in order (install -> format -> lint -> build).

        Args:
            source_dir: Source code directory or subdirectory
            commands: Complete project commands configuration
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration

        Returns:
            Dictionary mapping command category to BuildResult
        """
        results: dict[CommandCategory, BuildResult] = {}

        if commands.get("install"):
            result = self.run_command(
                source_dir,
                commands["install"],
                environment=environment,
                mirror_enabled=mirror_enabled,
            )
            results["install"] = result
            if not result["success"]:
                return results

        if commands.get("format"):
            result = self.run_command(
                source_dir,
                commands["format"],
                environment=environment,
                mirror_enabled=mirror_enabled,
            )
            results["format"] = result
            if not result["success"]:
                return results

        if commands.get("lint"):
            result = self.run_command(
                source_dir,
                commands["lint"],
                environment=environment,
                mirror_enabled=mirror_enabled,
            )
            results["lint"] = result
            if not result["success"]:
                return results

        if commands.get("build"):
            result = self.run_command(
                source_dir,
                commands["build"],
                environment=environment,
                mirror_enabled=mirror_enabled,
            )
            results["build"] = result

        return results

    def run_script(
        self,
        source_dir: Path,
        script_name: str,
        *,
        environment: dict[str, str] | None = None,
        mirror_enabled: bool = True,
    ) -> BuildResult:
        """Run a specific npm script with auto-detection of project root.

        Args:
            source_dir: Source code directory or subdirectory
            script_name: Name of the script to run
            environment: Additional environment variables
            mirror_enabled: Whether to use mirror acceleration

        Returns:
            BuildResult containing success status and output information.
        """
        pnpm_executable = self._get_executable_path()

        project_root = self.find_project_root(source_dir)

        if project_root is None:
            return BuildResult(
                success=False,
                return_code=-1,
                stdout="",
                stderr=f"package.json not found in {source_dir} or its parent/sub directories",
                output_path=None,
                duration_seconds=0.0,
            )

        env = environment.copy() if environment else {}

        if mirror_enabled:
            env = apply_mirror_environment("pnpm", env)

        return PnpmExecutor.execute(
            [pnpm_executable, "run", script_name],
            project_root,
            env,
        )

    def clean(self, directory: Path) -> bool:
        """Clean pnpm artifacts in the specified directory.

        Args:
            directory: Directory to clean

        Returns:
            True if successful, False otherwise.
        """
        import shutil

        try:
            directory = self._validate_directory(directory, create_if_not_exists=False)

            # Remove node_modules
            node_modules = directory / "node_modules"
            if node_modules.exists():
                shutil.rmtree(node_modules)

            # Remove pnpm-lock.yaml
            lock_file = directory / "pnpm-lock.yaml"
            if lock_file.exists():
                lock_file.unlink()

            # Remove .pnpm-store if exists
            pnpm_store = directory / ".pnpm-store"
            if pnpm_store.exists():
                shutil.rmtree(pnpm_store)

            return True

        except Exception:
            return False

    def _get_executable_path(self) -> str:
        """Get the pnpm executable path.

        Uses PnpmDetector for robust detection across different environments.
        """
        if self._pnpm_path:
            return self._pnpm_path

        pnpm_path = PnpmDetector.detect_pnpm_path()
        if pnpm_path is None:
            raise RuntimeError(
                "pnpm not found. Please install pnpm: npm install -g pnpm "
                "or set PNPM_PATH environment variable."
            )

        return pnpm_path

    @staticmethod
    def create(source_dir: Path, *, mirror_enabled: bool = True) -> "PnpmCompiler":
        """Factory method to create a PnpmCompiler instance.

        Args:
            source_dir: Source directory for the project
            mirror_enabled: Whether to enable mirror acceleration by default

        Returns:
            Configured PnpmCompiler instance
        """
        compiler = PnpmCompiler()
        return compiler


def main() -> None:
    """PNPM 编译器命令行入口点。"""
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="PNPM 构建编译器")
    parser.add_argument("source_dir", type=Path, help="源码目录")
    parser.add_argument("-o", "--output", type=Path, required=True, help="输出目录")
    parser.add_argument(
        "--mirror", action="store_true", default=True, help="启用镜像加速"
    )
    parser.add_argument(
        "--no-mirror", dest="mirror", action="store_false", help="禁用镜像加速"
    )
    parser.add_argument("--script", type=str, help="运行特定的 npm 脚本而不是构建")
    parser.add_argument("--install", action="store_true", help="仅安装依赖")
    parser.add_argument(
        "--build-command",
        type=str,
        default=None,
        help="自定义构建命令 (例如: vite build, rollup -c, npm run build)",
    )
    parser.add_argument(
        "--install-command",
        type=str,
        default=None,
        help="自定义安装命令 (例如: pnpm install --frozen-lockfile, npm ci)",
    )
    parser.add_argument(
        "--build-args",
        type=str,
        default=None,
        help="额外的构建参数 (会追加到构建命令后)",
    )

    args = parser.parse_args()

    compiler = PnpmCompiler()

    # Parse extra args
    extra_args = None
    if args.build_args:
        import shlex

        extra_args = shlex.split(args.build_args)

    if args.script:
        result = compiler.run_script(
            args.source_dir,
            args.script,
            mirror_enabled=args.mirror,
        )
    elif args.install:
        result = compiler.install_dependencies(
            args.source_dir,
            mirror_enabled=args.mirror,
        )
    else:
        result = compiler.build(
            args.source_dir,
            args.output,
            mirror_enabled=args.mirror,
            build_command=args.build_command,
            install_command=args.install_command,
            extra_args=extra_args,
        )

    sys.exit(0 if result["success"] else 1)
