"""Python build artifact cleaning utilities."""

import shutil
from pathlib import Path


class PythonCleaner:
    """Clean Python build artifacts."""

    @staticmethod
    def clean(directory: Path) -> bool:
        """Clean Python build artifacts in the specified directory.

        Args:
            directory: Directory to clean

        Returns:
            True if successful, False otherwise.
        """
        try:
            # Remove __pycache__ directories
            for pycache in directory.rglob("__pycache__"):
                shutil.rmtree(pycache)

            # Remove .pyc files
            for pyc in directory.rglob("*.pyc"):
                pyc.unlink()

            # Remove .pytest_cache
            pytest_cache = directory / ".pytest_cache"
            if pytest_cache.exists():
                shutil.rmtree(pytest_cache)

            # Remove .tox
            tox_dir = directory / ".tox"
            if tox_dir.exists():
                shutil.rmtree(tox_dir)

            # Remove dist directory
            dist_dir = directory / "dist"
            if dist_dir.exists():
                shutil.rmtree(dist_dir)

            # Remove build directory
            build_dir = directory / "build"
            if build_dir.exists():
                shutil.rmtree(build_dir)

            # Remove *.egg-info directories
            for egg_info in directory.rglob("*.egg-info"):
                shutil.rmtree(egg_info)

            return True

        except Exception:
            return False
