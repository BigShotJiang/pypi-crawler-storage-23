"""Python 编译器命令行入口。"""

from pathlib import Path


def main() -> None:
    """Python 编译器命令行入口点。"""
    import argparse
    import sys

    parser = argparse.ArgumentParser(description="Python 构建编译器")
    parser.add_argument("source_dir", type=Path, help="源码目录")
    parser.add_argument("-o", "--output", type=Path, required=True, help="输出目录")
    parser.add_argument(
        "--mirror", action="store_true", default=True, help="启用 PyPI 镜像"
    )
    parser.add_argument(
        "--no-mirror", dest="mirror", action="store_false", help="禁用 PyPI 镜像"
    )
    parser.add_argument("--install", action="store_true", help="仅安装依赖")
    parser.add_argument("--dev", action="store_true", help="包含开发依赖")
    parser.add_argument("--poetry", action="store_true", help="强制使用 poetry")
    parser.add_argument("--create-venv", type=Path, help="在指定路径创建虚拟环境")

    args = parser.parse_args()

    from multi_lang_build.compiler.python import PythonCompiler

    compiler = PythonCompiler()

    if args.create_venv:
        result = compiler.create_venv(
            args.create_venv,
            mirror_enabled=args.mirror,
        )
    elif args.install:
        result = compiler.install_dependencies(
            args.source_dir,
            mirror_enabled=args.mirror,
            dev=args.dev,
            poetry=args.poetry,
        )
    else:
        result = compiler.build(
            args.source_dir,
            args.output,
            mirror_enabled=args.mirror,
        )

    sys.exit(0 if result["success"] else 1)
