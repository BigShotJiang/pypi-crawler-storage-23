"""Python build system detection."""

from pathlib import Path


class BuildSystemDetector:
    """Detect Python build systems (Poetry, setuptools, PDM)."""

    @staticmethod
    def detect(source_dir: Path) -> str:
        """Detect the build system used by the project.

        Args:
            source_dir: Source directory to check

        Returns:
            Build system name: "poetry", "setuptools", "pdm", or "none"
        """
        pyproject = source_dir / "pyproject.toml"
        setup_py = source_dir / "setup.py"
        setup_cfg = source_dir / "setup.cfg"

        # Check for poetry
        if pyproject.exists():
            try:
                content = pyproject.read_text()
                if "[tool.poetry]" in content:
                    return "poetry"
                if "[tool.pdm]" in content:
                    return "pdm"
            except Exception:
                pass

        # Check for setuptools
        if setup_py.exists() or setup_cfg.exists():
            return "setuptools"

        # Check pdm
        if pyproject.exists():
            return "pdm"

        return "none"

    @staticmethod
    def is_poetry(source_dir: Path) -> bool:
        """Check if project uses Poetry."""
        pyproject = source_dir / "pyproject.toml"
        if not pyproject.exists():
            return False
        try:
            return "[tool.poetry]" in pyproject.read_text()
        except Exception:
            return False

    @staticmethod
    def is_pdm(source_dir: Path) -> bool:
        """Check if project uses PDM."""
        pyproject = source_dir / "pyproject.toml"
        if not pyproject.exists():
            return False
        try:
            return "[tool.pdm]" in pyproject.read_text()
        except Exception:
            return False
