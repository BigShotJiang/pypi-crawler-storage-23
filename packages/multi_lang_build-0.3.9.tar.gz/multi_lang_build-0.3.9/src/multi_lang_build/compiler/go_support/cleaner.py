"""Go build artifact cleaning utilities."""

import shutil
from pathlib import Path


class GoCleaner:
    """Clean Go build artifacts."""

    @staticmethod
    def clean(directory: Path) -> bool:
        """Clean Go build artifacts in the specified directory.

        Args:
            directory: Directory to clean

        Returns:
            True if successful, False otherwise.
        """
        try:
            # Remove go.sum
            go_sum = directory / "go.sum"
            if go_sum.exists():
                go_sum.unlink()

            # Remove vendor directory
            vendor_dir = directory / "vendor"
            if vendor_dir.exists() and vendor_dir.is_dir():
                shutil.rmtree(vendor_dir)

            # Remove build artifacts
            for pattern in ["*.exe", "*.exe~", "*.test", "*.test~"]:
                for file in directory.glob(pattern):
                    if file.is_file():
                        file.unlink()

            return True

        except Exception:
            return False
