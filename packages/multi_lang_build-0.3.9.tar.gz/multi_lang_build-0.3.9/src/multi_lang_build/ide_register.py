"""Register multi-lang-build as a skill for various IDEs."""

from __future__ import annotations

import subprocess
import sys
from typing import Literal

from multi_lang_build.register.support import (
    register_claude_code,
    register_codebuddy,
    register_opencode,
    register_trae,
)


def get_cli_path() -> str:
    """Get the path to the multi-lang-build CLI."""
    result = subprocess.run(
        ["which", "multi-lang-build"],
        capture_output=True,
        text=True,
    )
    if result.returncode == 0:
        return result.stdout.strip()
    return f"{sys.executable} -m multi_lang_build"


def register_skill(
    ide: Literal["claude", "opencode", "trae", "codebuddy", "all"] = "claude",
    global_level: bool = False,
) -> bool:
    """Register multi-lang-build as a skill for the specified IDE.

    Args:
        ide: The IDE to register with. Options: "claude", "opencode", "trae", "codebuddy", "all"
             Default is "claude".
        global_level: If True, register to global config. If False (default), register to project-level.

    Returns:
        True if registration succeeded, False otherwise.
    """
    print(f"📝 Registering multi-lang-build for {ide}...\n")

    if ide == "all":
        results = [
            ("Claude Code", register_claude_code(project_level=not global_level)),
            ("OpenCode", register_opencode(project_level=not global_level)),
            ("Trae", register_trae(project_level=not global_level)),
            ("CodeBuddy", register_codebuddy(project_level=not global_level)),
        ]

        print("\n" + "=" * 50)
        print("Registration Summary:")
        for name, success in results:
            status = "✅" if success else "❌"
            print(f"  {status} {name}")

        return all(success for _, success in results)

    elif ide == "claude":
        return register_claude_code(project_level=not global_level)
    elif ide == "opencode":
        return register_opencode(project_level=not global_level)
    elif ide == "trae":
        return register_trae(project_level=not global_level)
    elif ide == "codebuddy":
        return register_codebuddy(project_level=not global_level)
    else:
        print(f"❌ Unknown IDE: {ide}")
        print("Supported IDEs: claude, opencode, trae, codebuddy, all")
        return False


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Register multi-lang-build as an IDE skill"
    )
    parser.add_argument(
        "ide",
        nargs="?",
        default="claude",
        choices=["claude", "opencode", "trae", "codebuddy", "all"],
        help="IDE to register with (default: claude)",
    )
    parser.add_argument(
        "--global",
        dest="global_level",
        action="store_true",
        help="Register to global config instead of project-level",
    )

    args = parser.parse_args()
    success = register_skill(args.ide, global_level=args.global_level)
    sys.exit(0 if success else 1)
