"""IDE registration support modules."""

from multi_lang_build.register.support.claude import register_claude_code
from multi_lang_build.register.support.codebuddy import register_codebuddy
from multi_lang_build.register.support.opencode import register_opencode
from multi_lang_build.register.support.trae import register_trae

__all__ = [
    "register_claude_code",
    "register_opencode",
    "register_trae",
    "register_codebuddy",
]
