"""Register with CodeBuddy."""

from pathlib import Path


def register_codebuddy(project_level: bool = True) -> bool:
    """Register as CodeBuddy skill.

    Args:
        project_level: If True (default), register to project-level .codebuddy/skills.yaml.
                      If False, register to global ~/.codebuddy/skills.yaml.
    """
    try:
        # Determine registration path
        if project_level:
            # Project-level: .codebuddy/skills.yaml in current directory
            base_dir = Path.cwd()
            config_dir = base_dir / ".codebuddy"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.yaml"
            level_name = "project-level"
        else:
            # Global-level: ~/.codebuddy/skills.yaml
            config_dir = Path.home() / ".codebuddy"
            config_dir.mkdir(exist_ok=True)
            skills_file = config_dir / "skills.yaml"
            level_name = "global"

        skill_config = """# Multi-Lang Build Skill
skills:
  multi-lang-build:
    name: "Multi-Lang Build"
    description: "Multi-language automated build tool with mirror acceleration"
    version: "0.3.0"

    commands:
      build-go:
        description: "Build Go project"
        command: "multi-lang-build go {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output path"
            required: true
          - name: target
            description: "Build target (file or directory)"
            required: false
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag

      build-python:
        description: "Build Python project"
        command: "multi-lang-build python {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output directory"
            required: true
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag

      build-pnpm:
        description: "Build pnpm project"
        command: "multi-lang-build pnpm {source} --output {output}"
        args:
          - name: source
            description: "Source directory"
            required: true
          - name: output
            description: "Output directory"
            required: true
          - name: mirror
            description: "Enable mirror acceleration"
            type: flag
"""

        # Append or create
        if skills_file.exists():
            content = skills_file.read_text()
            if "multi-lang-build" not in content:
                with open(skills_file, "a") as f:
                    f.write("\n" + skill_config)
                print(
                    f"✅ Registered with CodeBuddy ({level_name}, updated {skills_file})"
                )
            else:
                print(
                    f"ℹ️ Already registered with CodeBuddy ({level_name}, {skills_file})"
                )
        else:
            skills_file.write_text(skill_config)
            print(f"✅ Registered with CodeBuddy ({level_name}, created {skills_file})")

        return True

    except Exception as e:
        print(f"❌ Failed to register with CodeBuddy: {e}")
        return False
