"""国内镜像加速配置命令行工具。"""

from __future__ import annotations

import json
import subprocess
import sys


def get_all_mirrors() -> dict:
    """获取所有可用镜像及其配置。"""
    from multi_lang_build.mirror.config import MIRROR_CONFIGS

    mirrors = {}
    for key, config in MIRROR_CONFIGS.items():
        mirrors[key] = {
            "name": config["name"],
            "url": config["url"],
        }
    return mirrors


def print_mirrors() -> None:
    """打印所有可用镜像。"""
    mirrors = get_all_mirrors()

    print("\n📦 可用镜像：")
    print("-" * 60)

    # 按类别分组
    categories = {
        "js": ["npm", "pnpm", "yarn"],
        "go": ["go", "go_qiniu", "go_vip"],
        "python": ["pip", "pip_aliyun", "pip_douban", "pip_huawei", "python", "poetry"],
    }

    category_names = {
        "js": "🌐 JavaScript (npm/pnpm/yarn)",
        "go": "🔷 Go",
        "python": "🐍 Python (pip/PyPI)",
    }

    for cat_key, cat_mirrors in categories.items():
        print(f"\n{category_names.get(cat_key, cat_key)}")
        for mirror_key in cat_mirrors:
            if mirror_key in mirrors:
                config = mirrors[mirror_key]
                print(f"  • {mirror_key:12} - {config['name']}")
                print(f"               {config['url']}")

    print()


def configure_pip(mirror_key: str) -> bool:
    """使用 pip config 命令配置 pip 镜像。"""
    from multi_lang_build.mirror.config import get_mirror_config

    config = get_mirror_config(mirror_key)
    if config is None:
        print(f"❌ 未知的 pip 镜像：{mirror_key}")
        return False

    url = config["url"]
    if not url.endswith("/simple") and not url.endswith("/simple/"):
        url = f"{url}/simple"

    # 优先使用 pip3，回退到 pip
    pip_cmd = "pip3" if sys.platform != "win32" else "pip"

    try:
        subprocess.run(
            [pip_cmd, "config", "set", "global.index-url", url],
            check=True,
        )
        print(f"✅ pip 镜像已设置为：{url}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 设置 pip 镜像失败：{e}")
        return False
    except FileNotFoundError:
        # 尝试替代方案
        try:
            alternative = "pip" if pip_cmd == "pip3" else "pip3"
            subprocess.run(
                [alternative, "config", "set", "global.index-url", url],
                check=True,
            )
            print(f"✅ pip 镜像已设置为：{url}")
            return True
        except Exception:
            print("❌ 未找到 pip/pip3")
            return False


def configure_go(mirror_key: str) -> bool:
    """使用 go env -w 配置 Go 代理。"""
    from multi_lang_build.mirror.config import get_mirror_config

    config = get_mirror_config(mirror_key)
    if config is None:
        print(f"❌ 未知的 Go 镜像：{mirror_key}")
        return False

    # 从环境变量中获取 GOPROXY 值
    proxy_value = config["environment_variables"].get(
        "GOPROXY", f"{config['url']},direct"
    )

    try:
        subprocess.run(
            ["go", "env", "-w", f"GOPROXY={proxy_value}"],
            check=True,
        )
        print(f"✅ Go GOPROXY 已设置为：{proxy_value}")

        # 如果存在也设置 GOSUMDB
        gosumdb = config["environment_variables"].get("GOSUMDB")
        if gosumdb:
            subprocess.run(
                ["go", "env", "-w", f"GOSUMDB={gosumdb}"],
                check=True,
            )
            print(f"✅ Go GOSUMDB 已设置为：{gosumdb}")

        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 设置 Go 镜像失败：{e}")
        return False
    except FileNotFoundError:
        print("❌ 未找到 go")
        return False


def configure_npm(mirror_key: str) -> bool:
    """配置 npm/pnpm 仓库。"""
    from multi_lang_build.mirror.config import get_mirror_config

    config = get_mirror_config(mirror_key)
    if config is None:
        print(f"❌ 未知的 npm 镜像：{mirror_key}")
        return False

    url = config["url"]

    try:
        subprocess.run(
            ["npm", "config", "set", "registry", url],
            check=True,
        )
        print(f"✅ npm 仓库已设置为：{url}")

        # 如果可用也为 pnpm 设置
        try:
            subprocess.run(
                ["pnpm", "config", "set", "registry", url],
                check=True,
            )
            print(f"✅ pnpm 仓库已设置为：{url}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 设置 npm 仓库失败：{e}")
        return False
    except FileNotFoundError:
        print("❌ 未找到 npm")
        return False


def get_current_config() -> dict:
    """获取当前镜像配置。"""
    config = {}

    # 优先使用 pip3，回退到 pip
    pip_cmd = "pip3" if sys.platform != "win32" else "pip"

    try:
        result = subprocess.run(
            [pip_cmd, "config", "get", "global.index-url"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0 and result.stdout.strip():
            config["pip"] = result.stdout.strip()
    except Exception:
        pass

    # 检查 Go
    try:
        result = subprocess.run(
            ["go", "env", "GOPROXY"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            config["go"] = result.stdout.strip()
    except Exception:
        pass

    # 检查 npm
    try:
        result = subprocess.run(
            ["npm", "config", "get", "registry"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            config["npm"] = result.stdout.strip()
    except Exception:
        pass

    return config


def configure_mirror(mirror_type: str, mirror_key: str) -> bool:
    """为特定的包管理器配置镜像。

    Args:
        mirror_type: 包管理器类型（pip、go、npm）
        mirror_key: 要使用的镜像键

    Returns:
        成功返回 True，失败返回 False
    """
    if mirror_type == "pip":
        return configure_pip(mirror_key)
    elif mirror_type == "go":
        return configure_go(mirror_key)
    elif mirror_type in ["npm", "pnpm"]:
        return configure_npm(mirror_key)
    else:
        print(f"❌ 未知的包管理器：{mirror_type}")
        return False


def mirror_main():
    """镜像命令的主入口点。"""
    import argparse

    parser = argparse.ArgumentParser(
        description="配置国内镜像加速",
        epilog="""
示例:
  %(prog)s list                    列出所有可用镜像
  %(prog)s set pip                 配置 pip 镜像（默认）
  %(prog)s set go                  配置 Go 代理
  %(prog)s set npm                 配置 npm 仓库
  %(prog)s show                    显示当前配置
        """,
    )
    parser.add_argument(
        "--version",
        action="version",
        version="%(prog)s 0.3.4",
    )

    subparsers = parser.add_subparsers(dest="command", help="命令")

    # list 命令
    list_parser = subparsers.add_parser("list", help="列出可用镜像")
    list_parser.add_argument(
        "--json",
        action="store_true",
        help="以 JSON 格式输出",
    )
    list_parser.add_argument(
        "--type",
        type=str,
        choices=["pip", "go", "npm"],
        help="按类型筛选",
    )

    # set 命令
    set_parser = subparsers.add_parser("set", help="配置镜像")
    set_parser.add_argument(
        "type",
        type=str,
        default="pip",
        nargs="?",
        choices=["pip", "go", "npm", "pnpm"],
        help="包管理器类型（默认：pip）",
    )
    set_parser.add_argument(
        "mirror",
        type=str,
        nargs="?",
        default="pip",
        help="要使用的镜像",
    )

    # show 命令
    subparsers.add_parser("show", help="显示当前镜像配置")

    args = parser.parse_args()

    if args.command == "list":
        mirrors = get_all_mirrors()
        if getattr(args, "json", False):
            print(json.dumps(mirrors, indent=2, ensure_ascii=False))
        else:
            print_mirrors()

    elif args.command == "set":
        mirror_type = args.type
        mirror_key = args.mirror
        success = configure_mirror(mirror_type, mirror_key)
        sys.exit(0 if success else 1)

    elif args.command == "show":
        config = get_current_config()
        if config:
            print("\n📦 当前镜像配置：")
            print("-" * 40)
            for key, value in config.items():
                print(f"  • {key}: {value}")
            print()
        else:
            print("\n📦 未配置镜像")
            print("   运行 'multi-lang-build mirror set <type> <mirror>' 进行配置")
            print()
            print_mirrors()

    else:
        # 无子命令，显示帮助
        parser.print_help()
        print("\n📋 命令：")
        print("  list              列出所有可用镜像")
        print("  set <type> <name> 配置镜像（类型：pip/go/npm）")
        print("  show              显示当前配置")
        print("\n📋 示例：")
        print("  multi-lang-build mirror list")
        print("  multi-lang-build mirror set pip")
        print("  multi-lang-build mirror set go")
        print("  multi-lang-build mirror set npm")


if __name__ == "__main__":
    mirror_main()
