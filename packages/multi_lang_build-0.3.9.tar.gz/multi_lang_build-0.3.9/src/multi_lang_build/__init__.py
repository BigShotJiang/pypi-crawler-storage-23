"""Multi-Lang Build - Multi-language automated build tool with domestic mirror acceleration."""

from multi_lang_build.compiler.base import BuildConfig, BuildResult, CompilerBase
from multi_lang_build.compiler.go_compiler import GoCompiler
from multi_lang_build.compiler.pnpm import PnpmCompiler
from multi_lang_build.compiler.python import PythonCompiler
from multi_lang_build.ide_register import register_skill
from multi_lang_build.mirror.config import MirrorConfig, get_mirror_config

__version__ = "0.3.5"
__all__ = [
    "BuildConfig",
    "BuildResult",
    "CompilerBase",
    "PnpmCompiler",
    "GoCompiler",
    "PythonCompiler",
    "MirrorConfig",
    "get_mirror_config",
    "register_skill",
]


def main() -> None:
    """Main entry point for the multi-lang-build CLI tool."""
    import sys

    from multi_lang_build.cli import run_cli

    run_cli(sys.argv[1:])


def main_register() -> None:
    """Entry point for the register CLI tool."""
    import argparse
    import sys

    from multi_lang_build.ide_register import register_skill

    parser = argparse.ArgumentParser(
        description="将 multi-lang-build 注册为 IDE 技能",
        prog="multi-lang-skill",
    )
    parser.add_argument(
        "ide",
        nargs="?",
        default="claude",
        choices=["claude", "opencode", "trae", "codebuddy", "all"],
        help="要注册的 IDE（默认：claude）",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    args = parser.parse_args()
    success = register_skill(args.ide)
    sys.exit(0 if success else 1)


def main_mirror() -> None:
    """Entry point for the mirror CLI tool."""
    from multi_lang_build.mirror.cli import mirror_main

    mirror_main()
