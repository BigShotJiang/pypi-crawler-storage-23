"""Type definitions for auto-build project."""

from pathlib import Path
from typing import Literal, TypeAlias, TypedDict


class BuildConfig(TypedDict, total=False):
    """Build configuration for compiler."""

    source_dir: Path
    output_dir: Path
    environment: dict[str, str]
    mirror_enabled: bool
    mirror_region: Literal["china", "global"]
    extra_args: list[str]


class BuildResult(TypedDict):
    """Result of a build operation."""

    success: bool
    return_code: int
    stdout: str
    stderr: str
    output_path: Path | None
    duration_seconds: float


class MirrorConfig(TypedDict, total=False):
    """Mirror configuration for package managers."""

    name: str
    url: str
    environment_prefix: str
    environment_variables: dict[str, str]


LanguageType: TypeAlias = Literal[
    "pnpm", "npm", "yarn", "go", "python", "pip", "poetry"
]


class CompilerInfo(TypedDict):
    """Information about a compiler."""

    name: str
    version: str
    supported_mirrors: list[str]
    default_mirror: str


class CommandConfig(TypedDict, total=False):
    """Command configuration for a single command."""

    name: str
    command: str | list[str]
    stream_output: bool
    log_output: bool


class ProjectCommands(TypedDict, total=False):
    """Complete command configuration for a frontend project.

    Contains four categories of commands:
    - install: Dependency installation commands
    - format: Code formatting commands
    - lint: Code quality check commands
    - build: Build commands
    """

    install: CommandConfig | None
    format: CommandConfig | None
    lint: CommandConfig | None
    build: CommandConfig | None


CommandCategory: TypeAlias = Literal["install", "format", "lint", "build"]
