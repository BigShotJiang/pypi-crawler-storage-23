# 🚀 AutoBuild

<p align="center">
  <strong>多语言自动化构建工具</strong><br>
  支持前端 pnpm、后端 Go、Python，一键加速国内镜像
</p>

<p align="center">
  <a href="https://pypi.org/project/multi-lang-build/">
    <img src="https://img.shields.io/pypi/v/multi-lang-build.svg" alt="PyPI version">
  </a>
  <a href="https://pypi.org/project/multi-lang-build/">
    <img src="https://img.shields.io/pypi/pyversions/multi-lang-build.svg" alt="Python versions">
  </a>
  <a href="https://github.com/yourusername/multi-lang-build/blob/main/LICENSE">
    <img src="https://img.shields.io/badge/license-MIT-blue.svg" alt="License">
  </a>
  <a href="https://github.com/yourusername/multi-lang-build/actions">
    <img src="https://img.shields.io/badge/build-passing-brightgreen.svg" alt="Build Status">
  </a>
</p>

<p align="center">
  <a href="#特性">特性</a> •
  <a href="#快速开始">快速开始</a> •
  <a href="#ide-集成">IDE 集成</a> •
  <a href="#安装">安装</a> •
  <a href="#详细文档">详细文档</a> •
  <a href="#许可证">许可证</a>
</p>

---

## ✨ 特性

<table>
<tr>
<td width="33%" valign="top">

### 🎯 多语言支持
- **Go** - 支持多入口编译、交叉编译
- **Python** - 自动检测 Poetry/Setuptools/PDM
- **PNPM** - 自动检测项目根目录

</td>
<td width="33%" valign="top">

### ⚡ 镜像加速
- 自动配置国内镜像源
- 提升依赖下载速度
- 支持切换多种镜像

</td>
<td width="33%" valign="top">

### 🔧 开发者友好
- 完整的类型注解
- 统一的 API 接口
- CLI 命令行支持

</td>
</tr>
</table>

## 🚀 快速开始

### 安装

```bash
pip install multi-lang-build

# 升级到最新版本
pip install --upgrade multi-lang-build

# 配置国内镜像（可选）
multi-lang-build mirror set pip          # pip 使用清华镜像
multi-lang-build mirror set go           # Go 使用 goproxy.cn
multi-lang-build mirror set npm          # npm/pnpm 使用 npmmirror
```

### 1. 构建 Go 项目（支持多入口）

```python
from multi_lang_build import GoCompiler
from pathlib import Path

compiler = GoCompiler()

# 指定入口文件编译（同一目录多 main 文件）
compiler.build_binary(
    source_dir=Path("./myproject"),
    output_path=Path("./bin/server"),
    target="server.go",  # 🎯 指定入口文件
    mirror_enabled=True
)

# 指定子目录编译（cmd 结构）
compiler.build_binary(
    source_dir=Path("./myproject"),
    output_path=Path("./bin/client"),
    target="./cmd/client",  # 📁 指定包路径
    mirror_enabled=True
)
```

### 2. 构建 Python 项目

```python
from multi_lang_build import PythonCompiler

compiler = PythonCompiler()

# 自动检测并安装依赖（支持 Poetry/Setuptools/PDM）
compiler.install_dependencies(
    source_dir=Path("./myproject"),
    mirror_enabled=True,
    dev=True
)

# 构建项目
compiler.build(
    source_dir=Path("./myproject"),
    output_dir=Path("./dist"),
    mirror_enabled=True
)
```

### 3. 构建前端项目

```python
from multi_lang_build import PnpmCompiler

compiler = PnpmCompiler()

# 自动检测项目根目录（支持子目录调用）
compiler.build(
    source_dir=Path("./packages/ui/src"),  # 即使在子目录也能正确构建
    output_dir=Path("./dist"),
    mirror_enabled=True
)
```

## 🎯 IDE 集成

将 multi-lang-build 注册为 IDE 技能，获得更智能的构建体验。

### 支持的 IDE

| IDE | 命令 | 说明 |
|-----|------|------|
| 🤖 **Claude Code** | `multi-lang-skill claude` | 默认，AI 助手原生支持 |
| 💠 **OpenCode** | `multi-lang-skill opencode` | 智能代码助手集成 |
| 🔷 **Trae** | `multi-lang-skill trae` | 字节跳动 AI IDE |
| 🎯 **CodeBuddy** | `multi-lang-skill codebuddy` | 代码伙伴插件 |

### 注册 Claude Code（默认）

```bash
# 使用独立命令
multi-lang-skill

# 或指定 IDE
multi-lang-skill claude
multi-lang-skill opencode
multi-lang-skill trae
multi-lang-skill codebuddy

# 注册到全局配置
multi-lang-skill claude --global
```

### 注册其他 IDE

```bash
# 注册到 OpenCode
multi-lang-skill opencode

# 注册到 Trae
multi-lang-skill trae

# 注册到 CodeBuddy
multi-lang-skill codebuddy

# 注册所有 IDE
multi-lang-skill all
```

### 注册功能说明

注册命令会将 skill 配置添加到指定 IDE 的配置目录：

| IDE | 命令 | 项目级配置 | 全局配置 |
|-----|------|-----------|---------|
| 🤖 **Claude Code** | `multi-lang-skill claude` | `.claude/multi-lang-build.md` | `~/.claude/multi-lang-build.md` |
| 💠 **OpenCode** | `multi-lang-skill opencode` | `.opencode/skills.json` | `~/.config/opencode/skills.json` |
| 🔷 **Trae** | `multi-lang-skill trae` | `.trae/skills.json` | `~/.trae/skills.json` |
| 🎯 **CodeBuddy** | `multi-lang-skill codebuddy` | `.codebuddy/skills.yaml` | `~/.codebuddy/skills.yaml` |

注册后，IDE 将自动识别项目类型并提供智能构建建议。

## 📦 安装

### 使用 pip 安装

```bash
# 基础安装
pip install multi-lang-build

# 开发环境（包含测试工具）
pip install multi-lang-build[dev]
```

### 系统要求

- Python 3.11+
- 对应语言的构建工具：
  - **Go**: `go` 命令
  - **Python**: `python3` 和 `pip`
  - **PNPM**: `pnpm` 和 `node`

## 📚 详细文档

| 语言 | 文档 | 说明 |
|------|------|------|
| 🐹 **Go** | [go.md](go.md) | 多入口编译、交叉编译、target 参数详解 |
| 🐍 **Python** | [python.md](python.md) | 依赖管理、虚拟环境、构建系统检测 |
| 📦 **PNPM** | [pnpm.md](pnpm.md) | 项目根目录检测、Monorepo 支持、镜像配置 |

## 🛠️ CLI 命令行

```bash
# Go 项目构建（默认实时输出日志）
multi-lang-build go ./myproject --output ./bin/app --mirror

# 指定入口文件编译（cmd 结构）
multi-lang-build go ./myproject --output ./bin/server --target ./cmd/server

# 禁用实时输出
multi-lang-build go ./myproject --output ./bin/app --no-stream

# Python 项目构建
multi-lang-build python ./myproject --output ./dist --mirror

# PNPM 项目构建
multi-lang-build pnpm ./myproject --output ./dist --mirror

# 注册到 IDE（独立命令）
multi-lang-skill                    # 默认 Claude Code
multi-lang-skill opencode
multi-lang-skill trae
multi-lang-skill codebuddy
multi-lang-skill all                # 注册所有 IDE

# 镜像配置
multi-lang-build mirror list              # 列出可用镜像
multi-lang-build mirror set pip           # 配置 pip 镜像
multi-lang-build mirror set go            # 配置 Go 代理
multi-lang-build mirror show              # 查看当前配置
```

## 🌟 核心特性对比

<table>
<thead>
<tr>
<th>特性</th>
<th>GoCompiler</th>
<th>PythonCompiler</th>
<th>PnpmCompiler</th>
</tr>
</thead>
<tbody>
<tr>
<td>自动检测项目</td>
<td>✅ go.mod</td>
<td>✅ pyproject.toml/setup.py</td>
<td>✅ package.json</td>
</tr>
<tr>
<td>多入口支持</td>
<td>✅ <code>target</code> 参数</td>
<td>❌</td>
<td>✅ 自动检测</td>
</tr>
<tr>
<td>镜像加速</td>
<td>✅ goproxy.cn</td>
<td>✅ 清华/阿里云等</td>
<td>✅ npmmirror</td>
</tr>
<tr>
<td>CLI 支持</td>
<td>✅ go-build</td>
<td>✅ python-build</td>
<td>✅ pnpm-build</td>
</tr>
<tr>
<td>类型安全</td>
<td>✅ Type Hints</td>
<td>✅ Type Hints</td>
<td>✅ Type Hints</td>
</tr>
</tbody>
</table>

## 📝 示例项目

### Go 多入口项目

```
myproject/
├── go.mod
├── server.go          # package main - API 服务
├── client.go          # package main - CLI 工具
└── worker.go          # package main - 后台任务
```

```python
# 构建所有入口
compiler = GoCompiler()

entries = ["server.go", "client.go", "worker.go"]
for entry in entries:
    name = entry.replace(".go", "")
    compiler.build_binary(
        source_dir=Path("./myproject"),
        output_path=Path(f"./bin/{name}"),
        target=entry
    )
```

### Python Poetry 项目

```
myproject/
├── pyproject.toml     # Poetry 配置
├── poetry.lock
└── src/
    └── mypackage/
```

```python
# 一键安装依赖并构建
compiler = PythonCompiler()
compiler.install_dependencies(source_dir=Path("./myproject"), dev=True)
compiler.build(source_dir=Path("./myproject"), output_dir=Path("./dist"))
```

### 前端 Monorepo

```
monorepo/
├── package.json
├── pnpm-workspace.yaml
└── packages/
    ├── ui/
    ├── utils/
    └── app/
```

```python
# 批量构建所有包
compiler = PnpmCompiler()

for pkg in ["ui", "utils", "app"]:
    compiler.build(
        source_dir=Path(f"./packages/{pkg}"),
        output_dir=Path(f"./packages/{pkg}/dist")
    )
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 📄 许可证

[MIT](LICENSE) © Multi-Lang Build Team

---

## 📋 更新日志

### v0.3.8 (2026-02-25)

**✨ 新功能**
- 添加命令数据类型支持，支持四大类命令配置（install/format/lint/build）
- `CommandConfig` 类型包含：name, command, stream_output, log_output
- `ProjectCommands` 类型支持完整的项目命令配置
- 新增 `run_command()`, `format()`, `lint()`, `run_all_commands()` 方法
- 支持直接传入命令配置数据类型进行构建

**🔧 优化**
- 添加 pre-commit 钩子，提交前自动格式化代码
- 自动修复未使用的导入问题
- 导入排序和组织优化

### v0.3.5 (2026-02-03)

**🔧 优化**
- 汉化 `multi-lang-skill` 命令的帮助信息
- 统一中文本地化体验

### v0.3.1 (2026-02-03)

**🔧 重构**
- 使用 loguru 替换 ColorInfo 实现结构化日志
- 日志格式: `[file:line function] message key=value`
- 支持调用者位置追踪

### v0.3.0 (2026-02-03)

**✨ 新功能**
- 添加 `--target` CLI 参数，支持指定入口文件编译
- 构建时自动打印完整构建命令，方便排查问题
- 下载依赖时显示当前镜像配置信息
- `go mod tidy` 命令日志输出

**🔧 优化**
- 镜像故障转移机制改进
- 日志输出更加清晰

### v0.2.9 (2026-01-XX)

**✨ 新功能**
- Go 镜像自动故障转移（goproxy.io → goproxy.cn → goproxy.vip.cn）
- Go 编译器模块化重构
- 添加进度日志

### v0.2.0 (2025-09-XX)

**✨ 首次发布**
- 支持 Go、Python、PNPM 多语言构建
- 镜像加速功能
- IDE 集成注册

---

<p align="center">
  用 ❤️ 构建 | 让多语言开发更简单
</p>
