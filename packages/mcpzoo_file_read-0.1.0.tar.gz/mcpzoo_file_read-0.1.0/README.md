# mcpzoo-file-read

> 文件读取 — 读取指定路径的文本文件内容

## Installation

```bash
uvx mcpzoo-file-read
```

## uvx JSON

```json
{
  "mcpServers": {
    "file-read": {
      "args": ["mcpzoo-file-read"],
      "command": "uvx"
    }
  }
}
```
