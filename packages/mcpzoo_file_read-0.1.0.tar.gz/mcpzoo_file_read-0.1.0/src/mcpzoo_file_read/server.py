import os
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("file-read")

@mcp.tool()
def read_file(path: str, encoding: str = "utf-8", max_bytes: int = 1024 * 1024) -> str:
    """读取指定路径的文本文件内容（最大支持1MB）。"""
    if not os.path.exists(path):
        return f"文件不存在: {path}"
        
    if not os.path.isfile(path):
        return f"非普通文件: {path}"
        
    size = os.path.getsize(path)
    if size > max_bytes:
        return f"文件过大 ({size} 字节)，超过限制 ({max_bytes} 字节)"
        
    try:
        with open(path, 'r', encoding=encoding) as f:
            return f.read()
    except Exception as e:
        return f"读取失败: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
