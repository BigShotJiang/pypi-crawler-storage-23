import argparse
import http.client
import json
from pathlib import Path
import select
import sys
import textwrap
import time
import tomllib
import smtplib
from email.message import EmailMessage
from functools import cached_property
from typing import Annotated, Literal, Self
from pydantic import BaseModel, Field, model_validator
from systemd import journal
import jinja2


class Reader(BaseModel):
    log_level: str = "error"
    match_dict: Annotated[dict[str, str], Field(alias="match", default_factory=dict)]

    def make_reader(self) -> journal.Reader:
        j = journal.Reader()
        match self.log_level:
            case "info":
                ll = journal.LOG_INFO
            case "warning":
                ll = journal.LOG_WARNING
            case "error":
                ll = journal.LOG_ERR
            case "alert":
                ll = journal.LOG_ALERT
            case _:
                raise ValueError(f"{self.log_level} is not a supported log level value")
        j.log_level(ll)
        j.add_match(**self.match_dict)
        return j


class BaseSink(BaseModel):
    template: str | None = None

    def send(self, event: dict[str, str]) -> None:
        raise NotImplementedError

    def render(self, event: dict[str, str]) -> str:
        environment = jinja2.Environment()
        assert self.template is not None
        template = environment.from_string(self.template)
        return template.render({
            **event,
            "_event": event,
        })


class StderrSink(BaseSink):
    type_str: Annotated[Literal["stderr"], Field(alias="type")]

    def send(self, event: dict[str, str]) -> None:
        print(self.render(event), file=sys.stderr)


class SmtpSink(BaseSink):
    type_str: Annotated[Literal["smtp"], Field(alias="type")]
    host: str
    username: str
    password: str
    from_addr: str | None
    to_addrs: list[str]
    port: int = 587

    @cached_property
    def effective_from_addr(self) -> str:
        return self.from_addr or self.username

    def send(self, event: dict[str, str]) -> None:
        rendered_event = self.render(event)[:4096]
        emailmessage = EmailMessage()
        emailmessage.set_content(rendered_event)
        emailmessage["Subject"] = textwrap.shorten(rendered_event.splitlines()[0], width=32)
        emailmessage["From"] = self.effective_from_addr
        emailmessage["To"] = ", ".join(self.to_addrs)
        with smtplib.SMTP(
            host=self.host,
            port=self.port,
        ) as smtp:
            smtp.starttls()
            smtp.login(
                user=self.username,
                password=self.password,
            )
            smtp.auth_plain()
            smtp.send_message(
                emailmessage,
                self.effective_from_addr,
                self.to_addrs,
            )


class TgSink(BaseSink):
    type_str: Annotated[Literal["tg"], Field(alias="type")]
    token: str
    chat_id: int
    timeout: float = 30.0

    def send(self, event: dict[str, str]) -> None:
        renderedevent = self.render(event)

        httpsconnection = http.client.HTTPSConnection(
            host="api.telegram.org",
            port=443,
            timeout=self.timeout,
        )
        httpsconnection.request(
            method="POST",
            url=f"/bot{self.token}/sendMessage",
            body=json.dumps({
                "chat_id": self.chat_id,
                "text": renderedevent,
            }),
            headers={
                "Content-Type": "application/json",
            },
        )
        response = httpsconnection.getresponse()
        if response.status >= 400:
            raise Exception(f"Response {response.status}: {response.read().decode()}")


class Jourlandalert(BaseModel):
    readers: list[Reader]
    sinks: list[Annotated[
        StderrSink | SmtpSink | TgSink,
        Field(discriminator="type_str"),
    ]]
    template: str = textwrap.dedent("""
    Use template to convey the message. Available Variables:
    {% for k, v in _event.items() | sort %}{{ k }}={{ v }}
    {% endfor %}
    """)
    
    @model_validator(mode="after")
    def validate_template(self) -> Self:
        for sink in self.sinks:
            if sink.template is None:
                sink.template = self.template
        return self

    def send(self, event: dict[str, str]) -> None:
        for isink, sink in enumerate(self.sinks):
            try:
                sink.send(event=event)
            except Exception as e:
                print(f"Error sending to sink#{isink}: {e}")
                raise

    # TODO: Refactor to simplify
    def run(self, test: bool) -> None:
        readers: dict[int, journal.Reader] = {}
        for reader in self.readers:
            j = reader.make_reader()
            if test:
                j.seek_tail()
            else:
                now = int(time.time() * 1000000)
                j.seek_realtime(now)
            readers[j.fileno()] = j
        if test:
            for j in readers.values():
                self.send(j.get_previous())
        else:
            p = select.poll()
            for fd, j in readers.items():
                p.register(fd, select.POLLIN)

            while True:
                for fd, _ in p.poll(1000):
                    j = readers[fd]
                    if j.process() & (journal.APPEND | journal.INVALIDATE):
                        for e in j:
                            self.send(e)
                    p.modify(fd, j.get_events())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-c",
        "--config",
        type=Path,
        default=Path("/etc/journaldalert.toml")
    )
    parser.add_argument(
        "-t",
        "--test",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    parser.add_argument(
        "-s",
        "--schema",
        action=argparse.BooleanOptionalAction,
        default=False,
    )
    args = parser.parse_args()

    if args.schema:
        print(json.dumps(Jourlandalert.model_json_schema(), indent=2, ensure_ascii=False, default=str))
        return
    journaldalert = Jourlandalert.model_validate(
        tomllib.loads(args.config.read_text()),
    )
    journaldalert.run(test=args.test)


if __name__ == "__main__":
    main()
