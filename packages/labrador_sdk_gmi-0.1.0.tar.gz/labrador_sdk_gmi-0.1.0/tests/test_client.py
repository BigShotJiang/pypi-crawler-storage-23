import json
import logging

import pytest
import responses as resp_lib

import labrador
from labrador._handler import LabradorHandler


BASE = "http://labrador-test.local"
ENDPOINT = BASE + "/submit-logs"


@pytest.fixture(autouse=True)
def reset_module():
    labrador._client = None
    yield
    if labrador._client is not None:
        labrador._client.shutdown(timeout=2.0)
    labrador._client = None


# ------------------------------------------------------------------
# init / capture / flush
# ------------------------------------------------------------------


@resp_lib.activate
def test_capture_and_flush():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})

    labrador.init(BASE, user_id="test-user")
    labrador.capture("hello from test")
    labrador.flush(timeout=5.0)

    assert len(resp_lib.calls) == 1
    body = json.loads(resp_lib.calls[0].request.body)
    assert body["logs"][0]["raw_data"] == "hello from test"
    assert body["logs"][0]["action_user_id"] == "test-user"


def test_capture_before_init_is_noop():
    labrador.capture("silent")


def test_flush_before_init_is_noop():
    labrador.flush()


def test_shutdown_before_init_is_noop():
    labrador.shutdown()


# ------------------------------------------------------------------
# Multiple captures → batched
# ------------------------------------------------------------------


@resp_lib.activate
def test_multiple_captures_batched():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})

    labrador.init(BASE, user_id="u1", batch_size=10)
    for i in range(3):
        labrador.capture(f"event {i}")
    labrador.flush(timeout=5.0)

    # With batching, 3 events should be sent in a single POST (batch_size=10)
    assert len(resp_lib.calls) >= 1
    all_events = []
    for call in resp_lib.calls:
        body = json.loads(call.request.body)
        all_events.extend(entry["raw_data"] for entry in body["logs"])
    assert set(all_events) == {"event 0", "event 1", "event 2"}


# ------------------------------------------------------------------
# get_handler
# ------------------------------------------------------------------


def test_get_handler_before_init_raises():
    with pytest.raises(RuntimeError, match="labrador.init()"):
        labrador.get_handler()


@resp_lib.activate
def test_get_handler_after_init():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})

    labrador.init(BASE, user_id="u1")
    handler = labrador.get_handler(level=logging.ERROR)
    assert isinstance(handler, LabradorHandler)


# ------------------------------------------------------------------
# LabradorHandler.emit
# ------------------------------------------------------------------


@resp_lib.activate
def test_handler_emits_log_records():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})

    labrador.init(BASE, user_id="u1")
    handler = labrador.get_handler(level=logging.WARNING)

    logger = logging.getLogger("labrador.test.handler_emit")
    logger.addHandler(handler)
    logger.setLevel(logging.WARNING)

    logger.warning("something went wrong")
    labrador.flush(timeout=5.0)

    assert len(resp_lib.calls) >= 1
    body = json.loads(resp_lib.calls[0].request.body)
    assert "something went wrong" in body["logs"][0]["raw_data"]

    logger.removeHandler(handler)


# ------------------------------------------------------------------
# Re-init cleans up previous client
# ------------------------------------------------------------------


@resp_lib.activate
def test_reinit_cleans_up_previous_client():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})

    labrador.init(BASE, user_id="u1")
    first_client = labrador._client

    labrador.init(BASE, user_id="u2")
    second_client = labrador._client

    assert first_client is not second_client
    # First client should have been shut down
    assert first_client._shutdown_event.is_set()


# ------------------------------------------------------------------
# flush timeout doesn't hang forever
# ------------------------------------------------------------------


def test_flush_timeout_does_not_hang():
    """flush() should return within its timeout even if events can't be sent."""
    import time

    # Init with a server that doesn't exist — sends will fail
    labrador.init("http://127.0.0.1:1", user_id="u1", max_retries=0, timeout=0.5)
    labrador.capture("this will fail")

    start = time.monotonic()
    labrador.flush(timeout=2.0)
    elapsed = time.monotonic() - start

    assert elapsed < 5.0, f"flush() took {elapsed:.1f}s — should timeout sooner"
