import json

import pytest
import requests
import responses as resp_lib

from labrador._transport import HttpTransport
from labrador._types import LogEntry


BASE = "http://labrador-test.local"
ENDPOINT = BASE + "/submit-logs"


def _entry(msg: str = "msg") -> LogEntry:
    return LogEntry(raw_data=msg, action_user_id="u1")


# ------------------------------------------------------------------
# Basic send
# ------------------------------------------------------------------


@resp_lib.activate
def test_send_success():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})
    t = HttpTransport(BASE, max_retries=0)
    assert t.send(_entry()) is True
    assert len(resp_lib.calls) == 1


@resp_lib.activate
def test_send_payload_shape():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})
    t = HttpTransport(BASE, max_retries=0)
    t.send(LogEntry(raw_data="hello", action_user_id="user-42"))
    body = json.loads(resp_lib.calls[0].request.body)
    assert "logs" in body
    assert len(body["logs"]) == 1
    assert body["logs"][0]["raw_data"] == "hello"
    assert body["logs"][0]["action_user_id"] == "user-42"
    assert "created_at" in body["logs"][0]


# ------------------------------------------------------------------
# Batch send
# ------------------------------------------------------------------


@resp_lib.activate
def test_send_batch_multiple_entries():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})
    t = HttpTransport(BASE, max_retries=0)
    entries = [_entry(f"msg-{i}") for i in range(5)]
    assert t.send_batch(entries) is True
    assert len(resp_lib.calls) == 1

    body = json.loads(resp_lib.calls[0].request.body)
    assert len(body["logs"]) == 5
    assert body["logs"][0]["raw_data"] == "msg-0"
    assert body["logs"][4]["raw_data"] == "msg-4"


def test_send_batch_empty_is_noop():
    t = HttpTransport(BASE, max_retries=0)
    assert t.send_batch([]) is True


# ------------------------------------------------------------------
# Error handling
# ------------------------------------------------------------------


@resp_lib.activate
def test_send_4xx_drops_no_retry():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=400)
    t = HttpTransport(BASE, max_retries=3)
    assert t.send(_entry()) is False
    assert len(resp_lib.calls) == 1  # no retries


@resp_lib.activate
def test_send_5xx_retries_then_gives_up():
    for _ in range(2):  # max_retries=1, so 2 total attempts
        resp_lib.add(resp_lib.POST, ENDPOINT, status=503)
    t = HttpTransport(BASE, max_retries=1, timeout=1.0)
    assert t.send(_entry()) is False
    assert len(resp_lib.calls) == 2


@resp_lib.activate
def test_send_5xx_succeeds_on_retry():
    resp_lib.add(resp_lib.POST, ENDPOINT, status=503)
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})
    t = HttpTransport(BASE, max_retries=2, timeout=1.0)
    assert t.send(_entry()) is True
    assert len(resp_lib.calls) == 2


@resp_lib.activate
def test_connection_error_retries():
    resp_lib.add(resp_lib.POST, ENDPOINT, body=requests.exceptions.ConnectionError("refused"))
    resp_lib.add(resp_lib.POST, ENDPOINT, status=202, json={"message": "Accepted"})
    t = HttpTransport(BASE, max_retries=1, timeout=1.0)
    assert t.send(_entry()) is True
    assert len(resp_lib.calls) == 2


# ------------------------------------------------------------------
# URL validation
# ------------------------------------------------------------------


def test_invalid_base_url_raises():
    with pytest.raises(ValueError, match="valid HTTP"):
        HttpTransport("", max_retries=0)

    with pytest.raises(ValueError, match="valid HTTP"):
        HttpTransport("ftp://example.com", max_retries=0)


# ------------------------------------------------------------------
# LogEntry
# ------------------------------------------------------------------


def test_log_entry_to_dict():
    entry = LogEntry(raw_data="hello", action_user_id="u1")
    d = entry.to_dict()
    assert d["raw_data"] == "hello"
    assert d["action_user_id"] == "u1"
    assert "created_at" in d
    # Timestamp should be ISO format
    assert "T" in d["created_at"]


# ------------------------------------------------------------------
# Session lifecycle
# ------------------------------------------------------------------


def test_close_session():
    t = HttpTransport(BASE, max_retries=0)
    t.close()  # should not raise
