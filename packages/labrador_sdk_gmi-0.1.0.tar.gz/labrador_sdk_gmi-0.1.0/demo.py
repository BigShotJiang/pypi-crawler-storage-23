"""
Interactive Labrador demo — type messages, watch them ship to the server.

Usage:
    uv run --with-editable . demo.py
    uv run --with-editable . demo.py --url http://localhost:8080 --user alice
"""

import argparse
import sys
import logging
import labrador

# Show debug logs from the SDK so we can see what's happening
logging.basicConfig(level=logging.DEBUG, format="[%(levelname)s] %(name)s: %(message)s")


def parse_args():
    p = argparse.ArgumentParser(description="Labrador interactive demo")
    p.add_argument("--url", default="http://localhost:8080", help="Labrador server URL")
    p.add_argument("--user", default="demo-user", help="User ID to attach to logs")
    return p.parse_args()


def main():
    args = parse_args()

    print(f"\n  Labrador Demo")
    print(f"  Server : {args.url}")
    print(f"  User   : {args.user}")
    print(f"  Type a message and press Enter to send it.")
    print(f"  Type 'quit' or press Ctrl+C to exit.\n")

    labrador.init(
        base_url=args.url,
        user_id=args.user,
        batch_size=10,
        flush_interval=2.0,
        max_retries=1,
        timeout=5.0,
    )

    try:
        while True:
            try:
                msg = input("  > ").strip()
            except EOFError:
                break

            if not msg:
                continue

            if msg.lower() in ("quit", "exit", "q"):
                break

            labrador.capture(msg)
            print(f"  ✓ captured — sending in background...\n")

    except KeyboardInterrupt:
        pass

    print("\n  Flushing remaining logs...")
    labrador.shutdown(timeout=10.0)
    print("  Done. Bye!\n")


if __name__ == "__main__":
    main()
