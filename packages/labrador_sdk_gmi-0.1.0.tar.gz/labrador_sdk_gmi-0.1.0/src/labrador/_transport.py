from __future__ import annotations

import logging
import time
from typing import Sequence

import requests

from ._types import LogEntry

logger = logging.getLogger(__name__)


class HttpTransport:
    """Sends log entries to the Labrador server with exponential backoff."""

    def __init__(
        self, base_url: str, timeout: float = 10.0, max_retries: int = 3
    ) -> None:
        if not base_url or not base_url.startswith(("http://", "https://")):
            raise ValueError(
                f"base_url must be a valid HTTP(S) URL, got: {base_url!r}"
            )
        self._endpoint = base_url.rstrip("/") + "/submit-logs"
        self._timeout = timeout
        self._max_retries = max_retries
        self._session = requests.Session()
        self._session.headers["Content-Type"] = "application/json"

    # ------------------------------------------------------------------
    # Public
    # ------------------------------------------------------------------

    def send_batch(self, entries: Sequence[LogEntry]) -> bool:
        """Send a batch of log entries. Returns True on success."""
        if not entries:
            return True
        payload = {"logs": [e.to_dict() for e in entries]}
        return self._post(payload)

    def send(self, entry: LogEntry) -> bool:
        """Send a single log entry (convenience wrapper). Returns True on success."""
        return self.send_batch([entry])

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _post(self, payload: dict) -> bool:
        delay = 1.0

        for attempt in range(self._max_retries + 1):
            try:
                resp = self._session.post(
                    self._endpoint, json=payload, timeout=self._timeout
                )
                if resp.status_code == 202:
                    return True
                if 400 <= resp.status_code < 500:
                    logger.warning(
                        "Labrador: server rejected payload (HTTP %s). Dropping.",
                        resp.status_code,
                    )
                    return False
                # 5xx — retry
                logger.debug(
                    "Labrador: server error %s, attempt %d/%d",
                    resp.status_code,
                    attempt + 1,
                    self._max_retries + 1,
                )
            except requests.exceptions.RequestException as exc:
                logger.debug(
                    "Labrador: %s, attempt %d/%d",
                    exc,
                    attempt + 1,
                    self._max_retries + 1,
                )

            if attempt < self._max_retries:
                time.sleep(delay)
                delay = min(delay * 2, 30.0)

        logger.warning(
            "Labrador: gave up after %d attempts. Dropping payload.",
            self._max_retries + 1,
        )
        return False
