from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class LogEntry:
    raw_data: str
    action_user_id: str
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def to_dict(self) -> dict:
        return {
            "raw_data": self.raw_data,
            "action_user_id": self.action_user_id,
            "created_at": self.created_at,
        }
