from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ._client import LabradorClient


class LabradorHandler(logging.Handler):
    """Standard logging.Handler that forwards records to a LabradorClient."""

    def __init__(self, client: "LabradorClient", level: int = logging.WARNING) -> None:
        super().__init__(level)
        self._client = client

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._client.capture(msg)
        except Exception:
            self.handleError(record)
