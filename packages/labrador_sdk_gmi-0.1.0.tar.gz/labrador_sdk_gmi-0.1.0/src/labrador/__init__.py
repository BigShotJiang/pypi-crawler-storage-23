"""
Labrador SDK — drop-in activity logging for Python applications.

Usage::

    import labrador

    labrador.init("http://localhost:8080", user_id="user-123")
    labrador.capture("user uploaded a file")
    labrador.flush()

    # Optional: route standard-library logging into Labrador
    import logging
    logging.getLogger().addHandler(labrador.get_handler(level=logging.WARNING))
"""

from __future__ import annotations

import logging
from typing import Optional

from ._client import LabradorClient
from ._handler import LabradorHandler

__all__ = ["init", "capture", "flush", "shutdown", "get_handler", "LabradorHandler"]
__version__ = "0.1.0"

_client: Optional[LabradorClient] = None


def init(
    base_url: str,
    user_id: str,
    *,
    batch_size: int = 20,
    flush_interval: float = 5.0,
    max_retries: int = 3,
    timeout: float = 10.0,
) -> None:
    """Initialise the Labrador client. Call once at application startup.

    Args:
        base_url: Root URL of the Labrador server (e.g. ``"http://localhost:8080"``).
        user_id:  Identifier attached to every log entry (e.g. a user UUID).
        batch_size: Maximum entries sent per HTTP request (default 20).
        flush_interval: Seconds between automatic background flushes (default 5.0).
        max_retries: Retry attempts on transient server errors (default 3).
        timeout: HTTP request timeout in seconds (default 10.0).
    """
    global _client

    # Clean up any previous client to avoid leaking threads / connections
    if _client is not None:
        _client.shutdown(timeout=2.0)

    _client = LabradorClient(
        base_url=base_url,
        user_id=user_id,
        batch_size=batch_size,
        flush_interval=flush_interval,
        max_retries=max_retries,
        timeout=timeout,
    )


def capture(message: str) -> None:
    """Record an activity log entry. Non-blocking; safe to call from any thread.

    Silently no-ops if :func:`init` has not been called.
    """
    if _client is None:
        return
    _client.capture(message)


def flush(timeout: float = 5.0) -> None:
    """Block until all buffered entries have been shipped (or *timeout* elapses).

    Silently no-ops if :func:`init` has not been called.
    """
    if _client is None:
        return
    _client.flush(timeout=timeout)


def shutdown(timeout: float = 5.0) -> None:
    """Drain remaining entries, close the HTTP session, and stop the worker.

    Silently no-ops if :func:`init` has not been called.
    """
    global _client
    if _client is None:
        return
    _client.shutdown(timeout=timeout)
    _client = None


def get_handler(level: int = logging.WARNING) -> LabradorHandler:
    """Return a ``logging.Handler`` that forwards records to Labrador.

    Attach it to any logger::

        import logging
        logging.getLogger("myapp").addHandler(labrador.get_handler())

    Raises:
        RuntimeError: if :func:`init` has not been called yet.
    """
    if _client is None:
        raise RuntimeError("labrador.init() must be called before get_handler()")
    return LabradorHandler(_client, level=level)
