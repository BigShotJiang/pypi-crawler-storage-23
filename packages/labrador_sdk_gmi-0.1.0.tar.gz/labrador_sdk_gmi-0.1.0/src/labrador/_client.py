from __future__ import annotations

import atexit
import threading
import time
from collections import deque

from ._transport import HttpTransport
from ._types import LogEntry


class LabradorClient:
    """Core SDK client — buffers log entries and ships them in the background."""

    def __init__(
        self,
        base_url: str,
        user_id: str,
        *,
        batch_size: int = 20,
        flush_interval: float = 5.0,
        max_retries: int = 3,
        timeout: float = 10.0,
    ) -> None:
        self._user_id = user_id
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._transport = HttpTransport(
            base_url, timeout=timeout, max_retries=max_retries
        )

        self._buffer: deque[LogEntry] = deque(maxlen=500)
        self._lock = threading.Lock()
        self._has_data = threading.Event()
        self._shutdown_event = threading.Event()
        self._idle = threading.Condition()
        self._in_flight: int = 0

        self._worker = threading.Thread(target=self._run, daemon=True)
        self._worker.start()

        atexit.register(self.shutdown)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def capture(self, message: str) -> None:
        """Append a log entry to the buffer. Non-blocking, never raises."""
        entry = LogEntry(raw_data=message, action_user_id=self._user_id)
        with self._lock:
            self._buffer.append(entry)  # oldest dropped when full (maxlen)
        self._has_data.set()

    def flush(self, timeout: float = 5.0) -> None:
        """Block until every buffered + in-flight entry is shipped (or *timeout* elapses)."""
        # Wake the worker so it drains immediately
        self._has_data.set()

        deadline = time.monotonic() + timeout
        with self._idle:
            while True:
                with self._lock:
                    buf_empty = len(self._buffer) == 0
                if buf_empty and self._in_flight == 0:
                    break
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                self._idle.wait(timeout=min(remaining, 0.1))

    def shutdown(self, timeout: float = 5.0) -> None:
        """Drain remaining entries and close the transport."""
        if self._shutdown_event.is_set():
            return
        self._shutdown_event.set()
        self._has_data.set()  # wake the worker
        self._worker.join(timeout=timeout)
        self._transport.close()

    # ------------------------------------------------------------------
    # Background worker
    # ------------------------------------------------------------------

    def _run(self) -> None:
        """Daemon loop: wait for data, drain in batches, repeat."""
        while not self._shutdown_event.is_set():
            # Wait until there's data or shutdown is requested
            self._has_data.wait(timeout=self._flush_interval)
            self._has_data.clear()
            self._drain()

        # Final drain after shutdown signal
        self._drain()

    def _drain(self) -> None:
        """Send all buffered entries in batch_size chunks."""
        while True:
            batch: list[LogEntry] = []
            with self._lock:
                while self._buffer and len(batch) < self._batch_size:
                    batch.append(self._buffer.popleft())

            if not batch:
                break

            with self._idle:
                self._in_flight += len(batch)

            try:
                self._transport.send_batch(batch)
            finally:
                with self._idle:
                    self._in_flight -= len(batch)
                    if self._in_flight == 0:
                        self._idle.notify_all()
