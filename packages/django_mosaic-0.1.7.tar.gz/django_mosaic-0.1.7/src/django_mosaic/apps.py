from django.apps import AppConfig


class BlogConfig(AppConfig):
    name = "django_mosaic"
    verbose_name = "Mosaic"
