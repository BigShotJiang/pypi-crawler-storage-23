"""kwasm CLI — bundle and view GDS layouts."""

import tempfile
import webbrowser
from pathlib import Path

import typer

from kwasm.embed import bundle as _bundle
from kwasm.embed_3d import bundle_3d as _bundle_3d

app = typer.Typer()


@app.command()
def bundle(
    gds: str,
    output: str | None = None,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout into a self-contained HTML file."""
    _bundle(gds, output=output, lyp=lyp, lyrdb=lyrdb, netlist=netlist)


@app.command()
def view(
    gds: str,
    lyp: str | None = None,
    lyrdb: str | None = None,
    netlist: str | None = None,
) -> None:
    """Bundle a GDS layout and open it in the default browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="kwasm_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle(gds, output=tmp_path, lyp=lyp, lyrdb=lyrdb, netlist=netlist)
        webbrowser.open(tmp_path.as_uri())


@app.command("bundle-3d")
def bundle_3d(
    gds: str,
    layerstack: str = typer.Option(..., help="Path to layerstack JSON file."),
    output: str | None = None,
    lyp: str | None = None,
) -> None:
    """Bundle a GDS layout + layerstack into a self-contained 3D HTML file."""
    _bundle_3d(gds, layerstack=layerstack, output=output, lyp=lyp)


@app.command("view-3d")
def view_3d(
    gds: str,
    layerstack: str = typer.Option(..., help="Path to layerstack JSON file."),
    lyp: str | None = None,
) -> None:
    """Bundle a GDS layout + layerstack and open the 3D viewer in the browser."""
    with tempfile.NamedTemporaryFile(
        suffix=".html", prefix="threegds_", delete=False
    ) as tmp:
        tmp_path = Path(tmp.name).resolve()
        _bundle_3d(gds, layerstack=layerstack, output=tmp_path, lyp=lyp)
        webbrowser.open(tmp_path.as_uri())


if __name__ == "__main__":
    app()
