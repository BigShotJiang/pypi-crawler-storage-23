from __future__ import annotations

import math
from pathlib import Path


def bytes_to_size_1024(num_bytes: int, precision: int = 2) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    if num_bytes <= 0:
        return "0 B"
    idx = min(int(math.log(num_bytes, 1024)), len(units) - 1)
    val = num_bytes / (1024**idx)
    return f"{round(val, precision)} {units[idx]}"


def ensure_directory(path: str) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p
