from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from Mama.models import ExecutionContext


class VectorStorePort(Protocol):
    def add_documents(self, documents: list[Any]) -> int:
        ...

    def similarity_search(
        self,
        query: str,
        *,
        k: int,
        search_type: str,
        filters: dict[str, Any] | None = None,
    ) -> list[Any]:
        ...

    def list_documents(self, limit: int | None = None) -> list[dict[str, Any]]:
        ...

    def delete_documents(self, filters: dict[str, Any]) -> int:
        ...

    def stats(self) -> dict[str, Any]:
        ...

    def identifier(self) -> str:
        ...


class VectorStoreFactoryPort(Protocol):
    def get_store(self, ctx: ExecutionContext, embeddings: Any) -> VectorStorePort:
        ...


class EmbeddingsProviderPort(Protocol):
    def get_embeddings(self, ctx: ExecutionContext) -> Any:
        ...


class LlmProviderPort(Protocol):
    def build_llm(self, ctx: ExecutionContext) -> Any:
        ...


@dataclass
class RuntimePorts:
    llm_provider: LlmProviderPort
    embeddings_provider: EmbeddingsProviderPort
    vector_store_factory: VectorStoreFactoryPort
