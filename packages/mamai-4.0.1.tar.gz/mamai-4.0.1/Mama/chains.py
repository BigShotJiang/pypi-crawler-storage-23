from __future__ import annotations

from Mama.models import ExecutionContext, QueryResult
from Mama.ports import RuntimePorts
from Mama.query import query
from Mama.runtime import default_runtime


def get_response(
    ctx: ExecutionContext,
    input_text: str,
    runtime: RuntimePorts | None = None,
    *,
    system_prompt: str,
    dynamic_prompt: str,
) -> QueryResult:
    """Execute a stateless RAG query using explicit execution context."""
    active_runtime = runtime or default_runtime()
    return query(
        ctx,
        input_text,
        active_runtime,
        system_prompt=system_prompt,
        dynamic_prompt=dynamic_prompt,
    )


def format_docs(docs) -> str:
    return "\n\n".join(doc.page_content for doc in docs)
