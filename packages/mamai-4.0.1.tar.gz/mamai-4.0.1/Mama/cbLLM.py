from __future__ import annotations

from Mama.models import ExecutionContext
from Mama.runtime import DefaultLlmProvider


class cbLLM:
    """Stateless LLM builder bound to an execution context."""

    def __init__(self, ctx: ExecutionContext):
        self._ctx = ctx
        self._provider = DefaultLlmProvider()

    def get_llm(self):
        return self._provider.build_llm(self._ctx)
