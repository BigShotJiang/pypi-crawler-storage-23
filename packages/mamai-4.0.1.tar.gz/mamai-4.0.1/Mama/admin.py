from __future__ import annotations

from Mama.models import ExecutionContext
from Mama.ports import RuntimePorts


def list_documents(ctx: ExecutionContext, runtime: RuntimePorts, limit: int | None = None):
    embeddings = runtime.embeddings_provider.get_embeddings(ctx)
    store = runtime.vector_store_factory.get_store(ctx, embeddings)
    return store.list_documents(limit=limit)


def get_vector_store_stats(ctx: ExecutionContext, runtime: RuntimePorts):
    embeddings = runtime.embeddings_provider.get_embeddings(ctx)
    store = runtime.vector_store_factory.get_store(ctx, embeddings)
    stats = store.stats()
    stats["index_identifier"] = store.identifier()
    return stats
