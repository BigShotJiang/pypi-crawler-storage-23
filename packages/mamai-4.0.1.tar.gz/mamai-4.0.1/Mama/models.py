from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class LlmConfig:
    provider: str = "dummy"
    model: str = "dummy"
    parameters: dict[str, Any] = field(default_factory=dict)


@dataclass
class RetrievalConfig:
    search_type: str = "similarity"
    k: int = 4
    filters: dict[str, Any] = field(default_factory=dict)


@dataclass
class StorageConfig:
    backend: str = "faiss_local"
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class ConversationState:
    messages: list[dict[str, Any]] = field(default_factory=list)
    max_messages: int = 20


@dataclass
class ExecutionContext:
    tenant_id: str
    user_id: str
    session_id: str
    kb_id: str
    llm: LlmConfig = field(default_factory=LlmConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)
    storage: StorageConfig = field(default_factory=StorageConfig)
    conversation: ConversationState = field(default_factory=ConversationState)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class QueryResult:
    answer: str
    documents: list[dict[str, Any]]
    updated_conversation_state: ConversationState
    usage: dict[str, Any] = field(default_factory=dict)


@dataclass
class IngestResult:
    kb_id: str
    backend: str
    chunks_added: int
    index_identifier: str
    metadata: dict[str, Any] = field(default_factory=dict)
