Exceptions
==========

.. automodule:: esmvalcore.exceptions
    :no-inherited-members:
