.. _api_recipe_metadata:

Recipe Metadata
===============

This section describes the :py:mod:`~esmvalcore.experimental.recipe_metadata` submodule of the API (:py:mod:`esmvalcore.experimental`).

API reference
*************

.. automodule:: esmvalcore.experimental.recipe_metadata
