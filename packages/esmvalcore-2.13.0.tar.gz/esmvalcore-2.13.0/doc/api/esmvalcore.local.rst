Find files on the local filesystem
==================================

.. automodule:: esmvalcore.local
    :no-inherited-members:
