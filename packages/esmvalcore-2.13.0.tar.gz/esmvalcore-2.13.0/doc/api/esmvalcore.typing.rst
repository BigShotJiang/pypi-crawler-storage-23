Type hints
==========

.. automodule:: esmvalcore.typing
    :no-inherited-members:
    :no-special-members:
