.. _recipe:

The recipe format
*****************

.. toctree::
   :maxdepth: 1

    Overview <overview>
    Preprocessor <preprocessor>
