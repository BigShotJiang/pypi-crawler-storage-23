Example notebooks
*****************

Example notebooks are available in the
`notebooks <https://github.com/ESMValGroup/ESMValCore/tree/main/notebooks>`__
folder and can also be viewed here.
These notebooks demonstrate the use of the :ref:`Python API <api>`.

.. toctree::
    :maxdepth: 1
    :glob:

    notebooks/*
