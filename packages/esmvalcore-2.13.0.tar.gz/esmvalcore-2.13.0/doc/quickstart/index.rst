Getting started
***************

.. toctree::
   :maxdepth: 1

    Installation <install>
    Configuration <configure>
    Input data <find_data>
    Running <run>
    Output <output>
