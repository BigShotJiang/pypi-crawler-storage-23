"""CMOR module."""
