"""
Automatic fixes for input data.

Module to apply automatic fixes at different levels to input data for known
errors.
"""
