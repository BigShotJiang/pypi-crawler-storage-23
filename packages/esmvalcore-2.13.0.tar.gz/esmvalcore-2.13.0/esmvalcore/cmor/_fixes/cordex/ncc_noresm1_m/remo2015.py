"""Fixes for rcm REMO2015 driven by NCC-NorESM1-M."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix
