"""Fixes for rcm RACMO22E driven by NCC-NorESM1-M."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix
