"""Fixes for rcm RCA4 driven by NCC-NorESM1-M."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix

Tas = BaseFix
