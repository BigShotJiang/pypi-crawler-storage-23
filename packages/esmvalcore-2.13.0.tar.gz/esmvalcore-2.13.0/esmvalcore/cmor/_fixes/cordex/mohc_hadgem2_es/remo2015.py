"""Fixes for rcm REMO2015 driven by MOHC-HadGEM2."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix

Tas = BaseFix
