"""Fixes for rcm RCA4 driven by MOHC-HadGEM2-ES."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix

Tas = BaseFix
