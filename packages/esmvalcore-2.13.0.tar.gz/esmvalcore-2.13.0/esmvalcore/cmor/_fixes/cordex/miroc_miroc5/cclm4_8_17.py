"""Fixes for rcm CCLM4-8-17 driven by MIROC-MIROC5."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import (
    CLMcomCCLM4817 as BaseFix,
)

AllVars = BaseFix
