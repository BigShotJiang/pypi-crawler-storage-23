"""Fixes for rcm RACMO22E driven by ICHEC-EC-EARTH."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix
