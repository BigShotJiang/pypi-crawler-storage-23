"""Fixes for rcm CCLM4-8-17 driven by ICHEC-EC-EARTH."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import (
    CLMcomCCLM4817 as BaseFix,
)

AllVars = BaseFix
