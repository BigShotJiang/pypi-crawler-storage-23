"""Fixes for rcm REMO2015 driven by ICHEC-EC-EARTH."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix
