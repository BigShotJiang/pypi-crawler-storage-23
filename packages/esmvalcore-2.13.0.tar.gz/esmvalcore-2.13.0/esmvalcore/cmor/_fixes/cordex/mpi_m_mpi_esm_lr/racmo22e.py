"""Fixes for rcm RACMO22E driven by MPI-M-MPI-ESM-LR."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix
