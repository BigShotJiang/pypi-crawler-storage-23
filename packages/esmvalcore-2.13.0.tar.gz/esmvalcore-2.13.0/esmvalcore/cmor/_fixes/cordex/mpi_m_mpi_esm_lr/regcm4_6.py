"""Fixes for rcm RegCM4-6 driven by MPI-M-MPI-ESM-LR."""

from esmvalcore.cmor._fixes.cordex.cordex_fixes import TimeLongName as BaseFix

Pr = BaseFix

Tas = BaseFix
