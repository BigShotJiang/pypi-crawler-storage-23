"""Fixes for MPI-ESM1-2-LR model."""

from esmvalcore.cmor._fixes.common import ClFixHybridPressureCoord

Cl = ClFixHybridPressureCoord


Cli = ClFixHybridPressureCoord


Clw = ClFixHybridPressureCoord
