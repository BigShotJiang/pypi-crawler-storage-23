"""Fixes for CAS-ESM2-0 model."""

from .ciesm import Cl as BaseCl

Cl = BaseCl
