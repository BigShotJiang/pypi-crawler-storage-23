"""Fixes for E3SM-1-0 model."""

from esmvalcore.cmor._fixes.common import ClFixHybridPressureCoord

Cl = ClFixHybridPressureCoord
