"""Fixes for CESM1-WACCM model."""

from .cesm1_cam5 import Cl as BaseCl

Cl = BaseCl
