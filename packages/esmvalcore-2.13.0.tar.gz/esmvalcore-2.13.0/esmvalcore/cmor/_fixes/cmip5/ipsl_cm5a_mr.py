"""Fixes for IPSL-CM5A-MR model."""

from esmvalcore.cmor._fixes.common import ClFixHybridPressureCoord

Cl = ClFixHybridPressureCoord
