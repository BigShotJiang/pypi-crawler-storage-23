"""Fixes for NorESM1-M."""

from esmvalcore.cmor._fixes.common import ClFixHybridPressureCoord

Cl = ClFixHybridPressureCoord
