"""Fixes for GISS-E2-R."""

from esmvalcore.cmor._fixes.common import ClFixHybridPressureCoord

Cl = ClFixHybridPressureCoord
