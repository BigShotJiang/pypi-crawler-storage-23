# cmip3-cmor-tables
Text Tables for CMOR1 to create a CMIP3 dataset
