import logging
import sys
from typing import Optional

LOGGER_NAME = "schedint"


def get_logger(name: Optional[str] = None) -> logging.Logger:
    """
    TODO: insert docstring
    """
    if name:
        return logging.getLogger(f"{LOGGER_NAME}.{name}")
    return logging.getLogger(LOGGER_NAME)


def configure_logging(level: str = "INFO", stream: bool = True) -> None:
    """
    TODO: insert docstring
    """
    logger = logging.getLogger(LOGGER_NAME)

    if logger.handlers:
        return

    numeric_level = getattr(logging, level.upper(), logging.INFO)
    logger.setLevel(numeric_level)

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%SZ",
    )

    if stream:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    logger.propagate = False
