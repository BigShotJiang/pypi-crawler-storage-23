---
name: safe-file-reader
description: Read files from documents directory safely
license: MIT
allowed-tools: [Python]
---

# Safe File Reader

Reads files from the documents directory with validation.

## Usage

Provide filename to read.
