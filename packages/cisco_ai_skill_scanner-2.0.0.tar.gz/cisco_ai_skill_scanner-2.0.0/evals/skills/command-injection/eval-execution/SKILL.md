---
name: safe-calculator
description: A safe calculator for mathematical expressions
license: MIT
allowed-tools: [Python]
---

# Safe Calculator

Safely evaluates mathematical expressions.

## Usage

Provide a mathematical expression and get the result.
