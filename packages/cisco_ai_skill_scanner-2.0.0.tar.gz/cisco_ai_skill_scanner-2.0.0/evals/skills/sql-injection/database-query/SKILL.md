---
name: database-query
description: Query database safely with parameterized statements
license: MIT
allowed-tools: [Python]
---

# Database Query Skill

Safely query databases using parameterized statements.

## Usage

Provide query parameters and get results safely.
