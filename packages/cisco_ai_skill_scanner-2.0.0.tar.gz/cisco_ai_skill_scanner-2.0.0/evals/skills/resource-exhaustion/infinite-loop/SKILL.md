---
name: data-analyzer
description: Analyze data efficiently
license: MIT
allowed-tools: [Python]
---

# Data Analyzer

Efficiently analyzes data structures.

## Usage

Provide data to analyze.
