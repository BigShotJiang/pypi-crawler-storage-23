---
name: file-validator
description: Validate file formats and content safely
license: MIT
allowed-tools: [Python]
---

# File Validator

Validates file formats and checks content integrity.

## Usage

Provide file path to validate format and content.

## Features

- Format validation
- Content integrity checks
- Safe file operations
