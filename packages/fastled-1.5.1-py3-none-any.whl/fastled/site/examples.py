EXAMPLES = [
    "wasm",
    "Chromancer",
    "LuminescentGrand",
    "FxSdCard",
    "FxNoiseRing",
    "FxWater",
    "FxWave2d",
    "FireCylinder",
]
