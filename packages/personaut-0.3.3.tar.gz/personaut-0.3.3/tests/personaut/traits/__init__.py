"""Tests for Personaut traits module."""
