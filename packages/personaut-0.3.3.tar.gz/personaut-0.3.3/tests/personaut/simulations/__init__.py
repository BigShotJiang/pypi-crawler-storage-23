"""Tests for Personaut simulations module."""
