"""Tests for Flask UI view modules."""
