## Description

<!-- What does this PR do? Why is it needed? -->

## Checklist

- [ ] Tests added / updated
- [ ] `ruff check` passing
- [ ] `ruff format` passing
- [ ] `ty check` passing
- [ ] Docs updated (if applicable)
- [ ] If new tool: uses `@register_tool` pattern
