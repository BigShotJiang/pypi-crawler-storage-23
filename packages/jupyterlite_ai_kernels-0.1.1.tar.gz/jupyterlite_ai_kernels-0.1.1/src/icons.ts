// Copyright (c) JupyterLite Contributors
// Distributed under the terms of the Modified BSD License.

export { AI_AVATAR } from '@jupyterlite/ai';
