# JupyterLite AI Kernels Demo

This demo site is built and deployed to GitHub Pages from `.github/workflows/deploy.yml`.
