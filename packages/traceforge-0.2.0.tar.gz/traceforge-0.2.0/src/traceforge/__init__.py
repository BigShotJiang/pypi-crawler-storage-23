"""TraceForge: Deterministic replay, fuzzing & failure minimization for local AI agents."""

__version__ = "0.2.0"
