import shutil
import tempfile

import pytest
from iker.common.utils.dtutils import dt_to_ts_us, dt_utc_now
from iker.common.utils.randutils import randomizer

from plexus.common.utils.bagutils import bag_reader, bag_writer


@pytest.fixture
def fixture_temp_bag_dir():
    d = tempfile.mkdtemp()
    yield d
    shutil.rmtree(d)


def test_bag_writer_and_bag_reader_roundtrip(fixture_temp_bag_dir):
    message_type = "std_msgs/msg/String"
    name = "/test_topic"
    ts_now = dt_to_ts_us(dt_utc_now()) * 1000
    records = [randomizer().random_alphanumeric(32).encode() for _ in range(1000)]

    with bag_writer.open_ros2(fixture_temp_bag_dir) as writer:
        with pytest.raises(ValueError):
            writer.write_message(name, ts_now, b"invalid message without topic")

        db_message_definition = writer.add_message_definition(message_type)
        assert db_message_definition.message_type == message_type
        assert db_message_definition.topics == []

        db_topic = writer.add_topic(name, message_type)
        assert db_topic.name == name
        assert db_topic.message_definition.message_type == message_type
        assert db_topic.messages == []

        for i, data in enumerate(records):
            db_message = writer.write_message(name, ts_now + i * 1000, data)
            assert db_message.topic.name == name
            assert db_message.topic.message_definition.message_type == message_type
            assert db_message.data == data

    with bag_reader.open_ros2(fixture_temp_bag_dir) as reader:
        assert len(reader.message_definitions()) == 1
        assert len(reader.topics()) == 1
        assert len(list(reader.iter_messages())) == len(records)

        for data, db_message in zip(records, reader.iter_messages()):
            assert db_message.topic.name == name
            assert db_message.topic.message_definition.message_type == message_type
            assert db_message.data == data

    with bag_writer.open_ros2(fixture_temp_bag_dir, overwrite=False, exist_ok=True) as writer:
        with pytest.raises(ValueError):
            writer.add_message_definition(message_type)
        with pytest.raises(ValueError):
            writer.add_topic(name, message_type)

        db_message_definition = writer.add_message_definition(message_type, return_existing=True)
        assert db_message_definition.message_type == message_type
        assert len(db_message_definition.topics) == 1

        db_topic = writer.add_topic(name, message_type, return_existing=True)
        assert db_topic.name == name
        assert db_topic.message_definition.message_type == message_type
        assert len(db_topic.messages) == len(records)

        for i, data in enumerate(records):
            db_message = writer.write_message(name, ts_now + (i + len(records)) * 1000, data)
            assert db_message.topic.name == name
            assert db_message.topic.message_definition.message_type == message_type
            assert db_message.data == data

    with bag_reader.open_ros2(fixture_temp_bag_dir) as reader:
        assert len(reader.message_definitions()) == 1
        assert len(reader.topics()) == 1
        assert len(list(reader.iter_messages())) == len(records) * 2

        for data, db_message in zip(records * 2, reader.iter_messages()):
            assert db_message.topic.name == name
            assert db_message.topic.message_definition.message_type == message_type
            assert db_message.data == data
