import datetime
import pathlib
import tempfile
import threading
import unittest

import ddt
from iker.common.utils.dtutils import dt_parse_iso

from plexus.common.utils.tagutils import MutableTagset, Tag, TagCache, Tagset
from plexus.common.utils.tagutils import predefined_tagsets, render_tagset_markdown_readme
from plexus.common.utils.tagutils import tag_cache_file_path


@ddt.ddt
class TagUtilsTest(unittest.TestCase):

    def test_predefined_tagsets(self):
        tagsets = predefined_tagsets()
        for _, tagset in tagsets.items():
            self.assertIsInstance(tagset, Tagset)
            self.assertNotIsInstance(tagset, MutableTagset)

            for tag in tagset:
                self.assertIn(tag, tagset)
                self.assertIn(tag.name, tagset)
                self.assertEqual(tag, tagset.get(tag))
                self.assertEqual(tag, tagset.get(tag.name))

            markdown = render_tagset_markdown_readme(tagset)
            self.assertIsInstance(markdown, str)

            print(markdown)

    def test_tag_cache(self):
        tagset = MutableTagset(namespace="tagset", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        cache = TagCache()

        self.assertEqual(cache.file_path, tag_cache_file_path())
        self.assertTrue(cache.file_path.exists())

        cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                         "awesome_tagger",
                         "1.0.0",
                         "dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00+00:00"),
                         dt_parse_iso("2020-01-01T01:00:00+00:00"))

        target_cache = cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

        tags_count = 1000

        for i in range(tags_count):
            target_cache.add_ranged_tag(
                dt_parse_iso("2020-01-01T00:00:00+00:00") + datetime.timedelta(seconds=i),
                dt_parse_iso("2020-01-02T00:00:00+00:00") + datetime.timedelta(seconds=i + 1),
                tags[i % len(tags)],
            )

        self.assertEqual(len(list(target_cache.iter_tags())), tags_count)
        self.assertEqual(len(list(target_cache.iter_tags(tagsets=[tagset]))), tags_count // 2)
        self.assertEqual(len(list(target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))), tags_count // 2)
        self.assertEqual(len(list(target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))), tags_count // 2)
        self.assertEqual(len(list(target_cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                         dt_parse_iso("2020-01-01T00:01:00+00:00")))),
                         60 + 1)
        self.assertEqual(len(list(target_cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                         dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                         tag_pattern="dummy:foo"))),
                         60 // len(tags) + 1)
        self.assertEqual(len(list(target_cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                         dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                         tag_pattern="dummy:bar"))),
                         60 // len(tags))
        self.assertEqual(len(list(target_cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                         dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                         tag_pattern="dummy"))),
                         60 + 1)
        self.assertEqual(len(list(target_cache.iter_tags(tag_pattern="dummy:foo"))),
                         tags_count // len(tags))
        self.assertEqual(len(list(target_cache.iter_tags(tag_pattern="dummy:bar"))),
                         tags_count // len(tags))
        self.assertEqual(len(list(target_cache.iter_tags(tag_pattern="dummy"))), tags_count)

        self.assertEqual(len(list(cache.iter_tags())), tags_count)
        self.assertEqual(len(list(cache.iter_tags(tagsets=[tagset]))), tags_count // 2)
        self.assertEqual(len(list(cache.iter_tags(tagsets=[tagset], tagset_inverted=True))), tags_count // 2)
        self.assertEqual(len(list(cache.iter_tags(tagsets=[tagset], tagset_inverted=False))), tags_count // 2)
        self.assertEqual(len(list(cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                  dt_parse_iso("2020-01-01T00:01:00+00:00")))),
                         60 + 1)
        self.assertEqual(len(list(cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                  dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                  tag_pattern="dummy:foo"))),
                         60 // len(tags) + 1)
        self.assertEqual(len(list(cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                  dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                  tag_pattern="dummy:bar"))),
                         60 // len(tags))
        self.assertEqual(len(list(cache.iter_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                                  dt_parse_iso("2020-01-01T00:01:00+00:00"),
                                                  tag_pattern="dummy"))),
                         60 + 1)
        self.assertEqual(len(list(cache.iter_tags(tag_pattern="dummy:foo"))), tags_count // len(tags))
        self.assertEqual(len(list(cache.iter_tags(tag_pattern="dummy:bar"))), tags_count // len(tags))
        self.assertEqual(len(list(cache.iter_tags(tag_pattern="dummy"))), tags_count)

        target_cache.remove_tags(dt_parse_iso("2020-01-01T00:00:00+00:00"), dt_parse_iso("2020-01-01T00:01:00+00:00"))

        self.assertEqual(len(list(target_cache.iter_tags())), tags_count - (60 + 1))
        self.assertEqual(len(list(cache.iter_tags())), tags_count - (60 + 1))

        target_cache.remove_tags(tagsets=[tagset], tagset_inverted=True)

        self.assertEqual(len(list(target_cache.iter_tags())), tags_count // 2 - (60 // 2 + 1))
        self.assertEqual(len(list(cache.iter_tags())), tags_count // 2 - (60 // 2 + 1))

        target_cache.remove_tags()

        self.assertEqual(len(list(target_cache.iter_tags())), 0)
        self.assertEqual(len(list(cache.iter_tags())), 0)

    def test_tag_cache__multithread(self):
        tagset = MutableTagset(namespace="tagset", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            cache = TagCache(file_path=temp_directory / "tag_cache.db")

            self.assertEqual(cache.file_path, temp_directory / "tag_cache.db")
            self.assertTrue(cache.file_path.exists())

            target_caches_count = 10

            for i in range(target_caches_count):
                cache.add_target(f"concurrent_tagger/20200101_000000/dummy_vehicle/{i}",
                                 "concurrent_tagger",
                                 f"1.0.{i}",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            target_caches = [cache.with_target(f"concurrent_tagger/20200101_000000/dummy_vehicle/{i}")
                             for i in range(target_caches_count)]

            threads_count_per_target_cache = 10
            tasks_count_per_thread = 100
            tasks_count_per_target_cache = threads_count_per_target_cache * tasks_count_per_thread
            total_threads_count = target_caches_count * threads_count_per_target_cache
            total_tasks_count = total_threads_count * tasks_count_per_thread

            start_barrier = threading.Barrier(total_threads_count)

            def worker(tid):
                tag_cache = target_caches[tid % target_caches_count]

                start_barrier.wait()
                for i in range(tasks_count_per_thread):
                    tag_cache.add_ranged_tag(
                        dt_parse_iso("2020-01-01T00:00:00+00:00") + datetime.timedelta(seconds=i),
                        dt_parse_iso("2020-01-02T00:00:00+00:00") + datetime.timedelta(seconds=i + 1),
                        tags[i % len(tags)],
                    )

            threads = [threading.Thread(target=worker, args=(tid,)) for tid in range(total_threads_count)]
            for thread in threads:
                thread.start()
            for thread in threads:
                thread.join()

            for target_cache in target_caches:
                self.assertEqual(len(list(target_cache.iter_tags())), tasks_count_per_target_cache)
                self.assertEqual(len(list(target_cache.iter_tags(tag_pattern="dummy:bar"))),
                                 tasks_count_per_target_cache // len(tags))

            self.assertEqual(len(list(cache.iter_tag_and_targets())), total_tasks_count)
            self.assertEqual(len(list(cache.iter_tag_and_targets(tag_pattern="dummy:bar"))),
                             total_tasks_count // len(tags))

    def test_tag_cache__clone(self):
        tagset = MutableTagset(namespace="tagset", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "src_tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tags_count = 1000

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_cache = TagCache(file_path=temp_directory / "dst_tag_cache.db")

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(len(list(src_target_cache.iter_tags())), tags_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset]))), tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count * 2 // 2)

            self.assertEqual(len(list(dst_target_cache.iter_tags())), tags_count)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset]))), tags_count // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count // 2)

    def test_tag_cache__clone_same_file(self):
        tagset = MutableTagset(namespace="tagset", desc="A dummy tagset for testing")
        tagset.add(Tag(name="dummy:foo", desc="A dummy tag for testing"))
        tagset.add(Tag(name="dummy:bar", desc="Another dummy tag for testing"))

        tags = [
            "dummy:foo",
            "dummy:bar",
            "dummy:baz",
            "dummy:qux",
        ]

        # Clone to the same file path should not cause any issue, and the cloned cache should be able to read
        # the tags added to the source cache after cloning.
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tags_count = 1000

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(len(list(src_target_cache.iter_tags())), tags_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset]))), tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count * 2 // 2)

            self.assertEqual(len(list(dst_target_cache.iter_tags())), tags_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset]))), tags_count * 2 // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count * 2 // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count * 2 // 2)

        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)

            src_cache = TagCache(file_path=temp_directory / "tag_cache.db")

            src_cache.add_target("awesome_tagger/20200101_000000/dummy_vehicle/0",
                                 "awesome_tagger",
                                 "1.0.0",
                                 "dummy_vehicle",
                                 dt_parse_iso("2020-01-01T00:00:00+00:00"),
                                 dt_parse_iso("2020-01-01T01:00:00+00:00"))

            src_target_cache = src_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            tags_count = 1000

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_cache = src_cache

            TagCache.copy_to(src_cache, dst_cache)

            for i in range(tags_count):
                src_target_cache.add_tag(tags[i % len(tags)])

            dst_target_cache = dst_cache.with_target("awesome_tagger/20200101_000000/dummy_vehicle/0")

            self.assertEqual(len(list(src_target_cache.iter_tags())), tags_count * 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset]))), tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count * 2 // 2)
            self.assertEqual(len(list(src_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count * 2 // 2)

            self.assertEqual(len(list(dst_target_cache.iter_tags())), tags_count * 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset]))), tags_count * 2 // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=True))),
                             tags_count * 2 // 2)
            self.assertEqual(len(list(dst_target_cache.iter_tags(tagsets=[tagset], tagset_inverted=False))),
                             tags_count * 2 // 2)
