import contextlib
import dataclasses
import datetime
import os
import pathlib
import textwrap
import threading
import typing
from collections.abc import Generator, Mapping, Sequence
from typing import Self

import jinja2
import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.sqlite as sa_sqlite
import sqlalchemy.orm as sa_orm
from iker.common.utils.dbutils import ConnectionMaker
from iker.common.utils.funcutils import memorized, singleton
from iker.common.utils.iterutils import batched, head_or_none
from iker.common.utils.iterutils import dicttree
from iker.common.utils.iterutils import dicttree_add, dicttree_remove
from iker.common.utils.iterutils import dicttree_children, dicttree_lineage, dicttree_subtree
from iker.common.utils.jsonutils import JsonObject, JsonType
from iker.common.utils.randutils import randomizer
from iker.common.utils.strutils import is_blank
from sqlmodel import Field, SQLModel

from plexus.common.resources.tags import predefined_tagset_specs
from plexus.common.utils.datautils import validate_colon_tag, validate_snake_case, validate_vehicle_name
from plexus.common.utils.datautils import validate_dt_timezone, validate_semver, validate_slash_tag
from plexus.common.utils.ormutils import SequenceModelMixinProtocol
from plexus.common.utils.ormutils import clone_sequence_model_instance, make_base_model, make_sequence_model_mixin
from plexus.common.utils.sqlutils import escape_sql_like

__all__ = [
    "RichDesc",
    "Tag",
    "Tagset",
    "MutableTagset",
    "populate_tagset",
    "predefined_tagsets",
    "render_tagset_markdown_readme",
    "TagTargetInfo",
    "TagRecord",
    "TagTargetInfoTable",
    "TagRecordTable",
    "tag_cache_file_path",
    "TagCache",
    "tag_cache",
]


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class RichDesc(object):
    type: str
    text: str


@dataclasses.dataclass(frozen=True, eq=True, order=True)
class Tag(object):
    name: str
    desc: str | RichDesc | None

    @property
    def tag_parts(self) -> list[str]:
        return self.name.rsplit(":")

    @property
    def parent_tag_name(self) -> str | None:
        return head_or_none(self.name.rsplit(":", 1))


class Tagset(Sequence[Tag], Mapping[str, Tag]):
    def __init__(self, namespace: str, desc: str | RichDesc) -> None:
        super().__init__()
        self.namespace = namespace
        self.desc = desc
        self.tags: list[Tag] = []
        self.tags_dict: dict[str, Tag] = {}
        self.tags_tree: dicttree[str, Tag] = {}

    def __contains__(self, item: str | Tag) -> bool:
        tag_name = item.name if isinstance(item, Tag) else item
        return tag_name in self.tags_dict

    def __len__(self) -> int:
        return len(self.tags)

    def __getitem__(self, index: int) -> Tag:
        return self.tags[index]

    def keys(self):
        return self.tags_dict.keys()

    def values(self):
        return self.tags_dict.values()

    def items(self):
        return self.tags_dict.items()

    def get(self, item: str | Tag) -> Tag | None:
        tag_name = item.name if isinstance(item, Tag) else item
        return self.tags_dict.get(tag_name)

    def clone(self) -> Self:
        return clone_tagset(self)

    def mutable(self):
        return clone_mutable_tagset(self)

    def frozen(self):
        return self.clone()

    @property
    def tag_names(self) -> list[str]:
        return list(self.tags_dict.keys())

    def child_tags(self, parent: str | Tag) -> list[Tag]:
        if parent is None:
            return []
        if isinstance(parent, str):
            return self.child_tags(self.get(parent))

        subtree = dicttree_subtree(self.tags_tree, parent.tag_parts)
        return list(dicttree_children(subtree)) if subtree else []

    def parent_tags(self, child: str | Tag) -> list[Tag]:
        if child is None:
            return []
        if isinstance(child, str):
            return self.parent_tags(self.get(child))

        return list(dicttree_lineage(self.tags_tree, child.tag_parts[:-1]))


class MutableTagset(Tagset):

    def clone(self) -> Self:
        return clone_mutable_tagset(self)

    def mutable(self):
        return self.clone()

    def frozen(self):
        return clone_tagset(self)

    def add(self, tag: Tag) -> Self:
        if tag.name in self.tags_dict:
            raise ValueError(f"duplicate tag name '{tag.name}'")

        self.tags.append(tag)
        self.tags_dict[tag.name] = tag

        dicttree_add(self.tags_tree, tag.tag_parts, tag, create_prefix=True)

        return self

    def remove(self, tag_name: str) -> Self:
        tag = self.get(tag_name)
        if tag is None:
            raise ValueError(f"tag '{tag_name}' not found")

        self.tags.remove(tag)
        del self.tags_dict[tag_name]

        dicttree_remove(self.tags_tree, tag.tag_parts, recursive=True)

        return self


def clone_tagset(tagset: Tagset) -> Tagset:
    tagset = clone_mutable_tagset(tagset)
    new_tagset = Tagset(namespace=tagset.namespace, desc=tagset.desc)
    new_tagset.tags = tagset.tags
    new_tagset.tags_dict = tagset.tags_dict
    new_tagset.tags_tree = tagset.tags_tree
    return new_tagset


def clone_mutable_tagset(tagset: Tagset) -> MutableTagset:
    new_tagset = MutableTagset(namespace=tagset.namespace, desc=tagset.desc)
    for tag in tagset.tags:
        new_tagset.add(tag)
    return new_tagset


def populate_tagset(tagset_spec: JsonObject) -> Tagset:
    """
    Collect tags from tagset spec JSON object, validate the format along the way.

    :param tagset_spec: JSON object of tagset spec
    :return: Populated Tagset instance
    """

    def validate_and_collect(name: str, tag_def: JsonObject) -> Generator[Tag, None, None]:
        if not isinstance(tag_def, dict):
            raise ValueError(f"tag '{name}' definition is not a dict")

        if not is_blank(name):
            desc = tag_def.get("$desc")
            if isinstance(desc, dict):
                desc = RichDesc(**desc)

            yield Tag(name=name, desc=desc)

        for child_name, child_tag_def in tag_def.items():
            if child_name == "$desc":
                continue

            if not isinstance(child_name, str):
                raise ValueError(f"child '{child_name}' of tag '{name}' is not a string")
            try:
                validate_snake_case(child_name)
            except ValueError as e:
                raise ValueError(f"child '{child_name}' of tag '{name}' is not in snake case") from e

            child_name = name + ":" + child_name if name else child_name

            yield from validate_and_collect(child_name, child_tag_def)

    namespace = tagset_spec.get("$namespace")
    if namespace is None:
        raise ValueError("missing '$namespace' in tagset spec")
    try:
        validate_snake_case(namespace)
    except ValueError as e:
        raise ValueError(f"tagset namespace '{namespace}' is not in snake case") from e

    desc = tagset_spec.get("$desc")
    if desc is None:
        raise ValueError("missing '$desc' in tagset spec")
    if isinstance(desc, dict):
        desc = RichDesc(**desc)

    tags = tagset_spec.get("$tags")
    if tags is None:
        raise ValueError("missing '$tags' in tagset spec")

    tagset = MutableTagset(namespace=namespace, desc=desc)

    for tag in validate_and_collect("", tags):
        tagset.add(tag)

    return tagset.frozen()


@singleton
def predefined_tagsets() -> dict[str, Tagset]:
    tagsets: dict[str, Tagset] = {}
    for _, tagset_spec in predefined_tagset_specs():
        tagset = populate_tagset(tagset_spec)
        tagsets[tagset.namespace] = tagset
    return tagsets


def render_tagset_markdown_readme(tagset: Tagset) -> str:
    def render_desc(desc: str | RichDesc | None) -> str:
        if desc is None:
            return ""
        if isinstance(desc, str):
            return desc
        if isinstance(desc, RichDesc):
            return desc.text
        raise ValueError(f"unsupported desc type '{type(desc)}'")

    template_str = textwrap.dedent(
        """
        # Tagset {{ tagset.namespace }}

        {{ tagset.desc | render_desc }}

        ## Contents

        {% for tag in tagset.tags %}
        - {{ tag.name }}
        {% endfor %}

        ## Tags

        {% for tag in tagset.tags %}
        ### {{ tag.name }}

        {{ tag.desc | render_desc }}

        {% endfor %}
        """
    )

    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters["render_desc"] = render_desc

    return env.from_string(template_str).render(tagset=tagset)


BaseModel = make_base_model()


class TagTargetInfo(BaseModel):
    name: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(256), nullable=False, unique=True),
        description="Name of the tag target",
    )
    tagger_name: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(128), nullable=False),
        description="Name of the tagger that generates the tag records for the target",
    )
    tagger_version: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(64), nullable=False),
        description="Version of the tagger that generates the tag records for the target",
    )
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=False),
        description="Vehicle name associated with the tag record",
    )
    begin_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="Begin datetime of the target range associated with the tag record",
    )
    end_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="End datetime of the target range associated with the tag record",
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("tagger_name", mode="after")
    @classmethod
    def validate_tagger_name(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("tagger_version", mode="after")
    @classmethod
    def validate_tagger_version(cls, v: str) -> str:
        validate_semver(v)
        return v

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_dt", mode="after")
    @classmethod
    def validate_begin_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v, allow_naive=True)
        return v

    @pdt.field_validator("end_dt", mode="after")
    @classmethod
    def validate_end_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v, allow_naive=True)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_dt_end_dt(self) -> Self:
        if self.begin_dt > self.end_dt:
            raise ValueError(f"begin_dt '{self.begin_dt}' is greater than end_dt '{self.end_dt}'")
        return self


class TagRecord(BaseModel):
    target_sqn: int = Field(
        sa_column=sa.Column(sa_sqlite.INTEGER, nullable=False),
        description="Sequence number of the tag record's target",
    )
    begin_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="Begin datetime of the tag record",
    )
    end_dt: datetime.datetime = Field(
        sa_column=sa.Column(sa_sqlite.TIMESTAMP, nullable=False),
        description="End datetime of the tag record",
    )
    tag: str = Field(
        sa_column=sa.Column(sa_sqlite.VARCHAR(256), nullable=False),
        description="Tag name",
    )
    props: JsonType | None = Field(
        sa_column=sa.Column(sa_sqlite.TEXT, nullable=True),
        default=None,
        description="Additional properties of the tag record in JSON format",
    )

    @pdt.field_validator("begin_dt", mode="after")
    @classmethod
    def validate_begin_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v, allow_naive=True)
        return v

    @pdt.field_validator("end_dt", mode="after")
    @classmethod
    def validate_end_dt(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v, allow_naive=True)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_dt_end_dt(self) -> Self:
        if self.begin_dt > self.end_dt:
            raise ValueError(f"begin_dt '{self.begin_dt}' is greater than end_dt '{self.end_dt}'")
        return self

    @pdt.field_validator("tag", mode="after")
    @classmethod
    def validate_tag(cls, v: str) -> str:
        validate_colon_tag(v)
        return v


class TagTargetInfoTable(TagTargetInfo, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "tag_target_info"


class TagRecordTable(TagRecord, make_sequence_model_mixin("sqlite"), table=True):
    __tablename__ = "tag_record"


if typing.TYPE_CHECKING:
    class TagTargetInfoTable(SQLModel, SequenceModelMixinProtocol):
        name: sa_orm.Mapped[str] = ...
        tagger_name: sa_orm.Mapped[str] = ...
        tagger_version: sa_orm.Mapped[str] = ...
        vehicle_name: sa_orm.Mapped[str] = ...
        begin_dt: sa_orm.Mapped[datetime.datetime] = ...
        end_dt: sa_orm.Mapped[datetime.datetime] = ...


    class TagRecordTable(SQLModel, SequenceModelMixinProtocol):
        target_sqn: sa_orm.Mapped[int] = ...
        begin_dt: sa_orm.Mapped[datetime.datetime] = ...
        end_dt: sa_orm.Mapped[datetime.datetime] = ...
        tag: sa_orm.Mapped[str] = ...
        props: sa_orm.Mapped[JsonType | None] = ...


@singleton
def tag_cache_file_path() -> pathlib.Path:
    return pathlib.Path.home() / ".local" / "plus" / "datahub" / "tag_cache" / f"{randomizer().random_alphanumeric(7)}.db"


class TagCache(object):
    def __init__(
        self,
        *,
        file_path: str | os.PathLike[str] | None = None,
        fail_if_exists: bool = False,
    ):
        self.file_path = pathlib.Path(file_path or tag_cache_file_path())
        if fail_if_exists and self.file_path.exists():
            raise FileExistsError(f"tag cache file '{str(self.file_path)}' already exists")
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

        self.conn_maker = ConnectionMaker.from_url(f"sqlite:///{str(self.file_path.absolute())}",
                                                   engine_opts=dict(connect_args={"check_same_thread": False}))

        self.thread_lock = threading.Lock()

        BaseModel.metadata.create_all(self.conn_maker.engine)

    @contextlib.contextmanager
    def make_session(self) -> Generator[sa_orm.Session, None, None]:
        with self.thread_lock:
            with self.conn_maker.make_session() as session:
                yield session

    def get_target(self, name: str) -> TagTargetInfoTable | None:
        with self.make_session() as session:
            return session.query(TagTargetInfoTable).filter(TagTargetInfoTable.name == name).one_or_none()

    def query_targets(
        self,
        name: str | None = None,
        tagger_name: str | None = None,
        tagger_version: str | None = None,
        vehicle_name: str | None = None,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
    ) -> list[TagTargetInfoTable]:
        with self.make_session() as session:
            query = session.query(TagTargetInfoTable)
            if name:
                query = query.filter(TagTargetInfoTable.name == name)
            if tagger_name:
                query = query.filter(TagTargetInfoTable.tagger_name == tagger_name)
            if tagger_version:
                query = query.filter(TagTargetInfoTable.tagger_version == tagger_version)
            if vehicle_name:
                query = query.filter(TagTargetInfoTable.vehicle_name == vehicle_name)
            if begin_dt:
                query = query.filter(TagTargetInfoTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagTargetInfoTable.begin_dt <= end_dt)

            return query.all()

    def add_target(
        self,
        name: str,
        tagger_name: str,
        tagger_version: str,
        vehicle_name: str,
        begin_dt: datetime.datetime,
        end_dt: datetime.datetime,
    ) -> TagTargetInfoTable:
        with self.make_session() as session:
            target_info = TagTargetInfo(
                name=name,
                tagger_name=tagger_name,
                tagger_version=tagger_version,
                vehicle_name=vehicle_name,
                begin_dt=begin_dt,
                end_dt=end_dt,
            )
            db_target_info = clone_sequence_model_instance(TagTargetInfoTable, target_info)
            session.add(db_target_info)
            session.commit()

        return self.get_target(name)

    def remove_targets(
        self,
        name: str | None = None,
        tagger_name: str | None = None,
        tagger_version: str | None = None,
        vehicle_name: str | None = None,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
    ):
        with self.make_session() as session:
            query = session.query(TagTargetInfoTable)
            if name:
                query = query.filter(TagTargetInfoTable.name == name)
            if tagger_name:
                query = query.filter(TagTargetInfoTable.tagger_name == tagger_name)
            if tagger_version:
                query = query.filter(TagTargetInfoTable.tagger_version == tagger_version)
            if vehicle_name:
                query = query.filter(TagTargetInfoTable.vehicle_name == vehicle_name)
            if begin_dt:
                query = query.filter(TagTargetInfoTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagTargetInfoTable.begin_dt <= end_dt)

            query.delete()
            session.commit()

            (
                session
                .query(TagRecordTable)
                .filter(TagRecordTable.target_sqn.notin_(session.query(TagTargetInfoTable.sqn)))
                .delete()
            )
            session.commit()

    def with_target(self, name: str) -> "TargetedTagCache":
        target_info = self.get_target(name)
        if target_info is None:
            raise ValueError(f"target with name '{name}' not found in cache")
        return TargetedTagCache(cache=self, target_info=target_info)

    def iter_tags(
        self,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
        batch_size: int = 1000,
    ) -> Generator[TagRecordTable, None, None]:
        """
        Query tag records in the cache with optional filters.

        :param begin_dt: Filter by begin time (inclusive)
        :param end_dt: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :param batch_size: Number of records to fetch per batch from the database (for memory efficiency)
        :return: Generator of ``TagRecordTable`` instances that match the filters
        """
        with self.make_session() as session:
            query = session.query(TagRecordTable)
            if begin_dt:
                query = query.filter(TagRecordTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagRecordTable.begin_dt <= end_dt)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            for result in query.yield_per(batch_size):
                yield result

    def iter_tag_and_targets(
        self,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        target_name: str | None = None,
        target_tagger_name: str | None = None,
        target_tagger_version: str | None = None,
        target_vehicle_name: str | None = None,
        target_begin_dt: datetime.datetime | None = None,
        target_end_dt: datetime.datetime | None = None,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
        batch_size: int = 1000,
    ) -> Generator[tuple[TagRecordTable, TagTargetInfoTable], None, None]:
        """
        Query tag records along with their target info in the cache with optional filters.

        :param begin_dt: Filter by begin time (inclusive)
        :param end_dt: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param target_name: Filter by target name (exact match)
        :param target_tagger_name: Filter by target tagger name (exact match)
        :param target_tagger_version: Filter by target tagger version (exact match)
        :param target_vehicle_name: Filter by target vehicle name (exact match)
        :param target_begin_dt: Filter by target begin time (inclusive)
        :param target_end_dt: Filter by target end time (inclusive)
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :param batch_size: Number of records to fetch per batch from the database (for memory efficiency)
        :return: Generator of ``TagRecordTable`` instances that match the filters
        """
        with self.make_session() as session:
            query = (
                session
                .query(TagRecordTable, TagTargetInfoTable)
                .join(TagTargetInfoTable, TagRecordTable.target_sqn == TagTargetInfoTable.sqn)
            )
            if begin_dt:
                query = query.filter(TagRecordTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagRecordTable.begin_dt <= end_dt)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if target_name:
                query = query.filter(TagTargetInfoTable.name == target_name)
            if target_tagger_name:
                query = query.filter(TagTargetInfoTable.tagger_name == target_tagger_name)
            if target_tagger_version:
                query = query.filter(TagTargetInfoTable.tagger_version == target_tagger_version)
            if target_vehicle_name:
                query = query.filter(TagTargetInfoTable.vehicle_name == target_vehicle_name)
            if target_begin_dt:
                query = query.filter(TagTargetInfoTable.end_dt >= target_begin_dt)
            if target_end_dt:
                query = query.filter(TagTargetInfoTable.begin_dt <= target_end_dt)
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            for result in query.yield_per(batch_size):
                yield result

    def remove_tags(
        self,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ):
        """
        Remove tag records from the cache that match the specified filters.

        :param begin_dt: Filter by begin time (inclusive)
        :param end_dt: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        """
        with self.make_session() as session:
            query = session.query(TagRecordTable)
            if begin_dt:
                query = query.filter(TagRecordTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagRecordTable.begin_dt <= end_dt)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            query.delete()
            session.commit()

    def clear(self):
        with self.make_session() as session:
            session.execute(sa.delete(TagRecordTable))
            session.execute(sa.delete(TagTargetInfoTable))
            session.commit()

    def append_to(self, target_file_path: str, *, overwrite: bool = False):
        target_tag_cache = TagCache(file_path=target_file_path)
        if overwrite:
            target_tag_cache.clear()
        TagCache.copy_to(self, target_tag_cache)

    def merge_from(self, source_file_path: str, *, overwrite: bool = False):
        source_tag_cache = TagCache(file_path=source_file_path)
        if overwrite:
            self.clear()
        TagCache.copy_to(source_tag_cache, self)

    @staticmethod
    def copy_to(src: "TagCache", dst: "TagCache"):
        # If src and dst are the same instance or point to the same file path,
        # do nothing to avoid accidentally clearing the cache
        if src == dst or src.file_path == dst.file_path:
            return

        with src.make_session() as src_session, dst.make_session() as dst_session:
            src_targets = src_session.query(TagTargetInfoTable).all()
            dst_targets = [
                clone_sequence_model_instance(TagTargetInfoTable, db_tag_target_info, clear_meta_fields=True)
                for db_tag_target_info in src_targets
            ]
            dst_session.add_all(dst_targets)
            dst_session.flush()  # ensure new sqn values are assigned

            sqn_map = {src_target.sqn: dst_target.sqn for src_target, dst_target in zip(src_targets, dst_targets)}

            for results in batched(src_session.query(TagRecordTable).yield_per(1000), 1000):
                clones = []
                for db_tag_record in results:
                    cloned = clone_sequence_model_instance(TagRecordTable, db_tag_record, clear_meta_fields=True)
                    try:
                        cloned.target_sqn = sqn_map[db_tag_record.target_sqn]
                    except KeyError as e:
                        raise ValueError(f"no cloned target for target_sqn '{db_tag_record.target_sqn}'") from e
                    clones.append(cloned)
                dst_session.add_all(clones)
            dst_session.commit()


class TargetedTagCache(object):
    def __init__(self, cache: TagCache, target_info: TagTargetInfoTable):
        self.target_info = target_info
        self.cache = cache

    @contextlib.contextmanager
    def make_session(self) -> Generator[sa_orm.Session, None, None]:
        with self.cache.make_session() as session:
            if not session.query(TagTargetInfoTable).filter(TagTargetInfoTable.sqn == self.target_info.sqn).first():
                raise ValueError(f"target info with sqn '{self.target_info.sqn}' is no longer present in cache")
            yield session

    def iter_tags(
        self,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
        batch_size: int = 1000,
    ) -> Generator[TagRecordTable, None, None]:
        """
        Query tag records in the cache with optional filters.

        :param begin_dt: Filter by begin time (inclusive)
        :param end_dt: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :param batch_size: Number of records to fetch per batch from the database (for memory efficiency)
        :return: Generator of ``TagRecordTable`` instances that match the filters
        """

        with self.make_session() as session:
            query = session.query(TagRecordTable).filter(TagRecordTable.target_sqn == self.target_info.sqn)
            if begin_dt:
                query = query.filter(TagRecordTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagRecordTable.begin_dt <= end_dt)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            for result in query.yield_per(batch_size):
                yield result

    def add_ranged_tag(
        self,
        begin_dt: datetime.datetime | None,
        end_dt: datetime.datetime | None,
        tag: str | Tag,
        props: JsonType | None = None,
    ) -> Self:
        """
        Add a tag record to the cache for the specified time range. If begin_dt or end_dt is None, it will default to
        the target's begin_dt or end_dt respectively.

        :param begin_dt: Begin datetime of the tag record
        :param end_dt: End datetime of the tag record
        :param tag: Tag name or Tag instance to be added (if Tag instance is provided, its name will be used)
        :param props: Additional properties of the tag record in JSON format (optional)
        :return: Self instance for chaining
        """
        with self.make_session() as session:
            tag_record = TagRecord(
                target_sqn=self.target_info.sqn,
                begin_dt=begin_dt or self.target_info.begin_dt,
                end_dt=end_dt or self.target_info.end_dt,
                tag=tag.name if isinstance(tag, Tag) else tag,
                props=props,
            )
            session.add(clone_sequence_model_instance(TagRecordTable, tag_record))
            session.commit()

        return self

    def add_tag(self, tag: str | Tag, props: JsonType | None = None) -> Self:
        """
        Add a tag record to the cache for the entire target range.

        :param tag: Tag name or Tag instance to be added (if Tag instance is provided, its name will be used)
        :param props: Additional properties of the tag record in JSON format (optional)
        :return: Self instance for chaining
        """
        return self.add_ranged_tag(
            begin_dt=self.target_info.begin_dt,
            end_dt=self.target_info.end_dt,
            tag=tag,
            props=props,
        )

    def remove_tags(
        self,
        begin_dt: datetime.datetime | None = None,
        end_dt: datetime.datetime | None = None,
        tag_pattern: str | None = None,
        *,
        tagsets: Sequence[Tagset] | None = None,
        tagset_inverted: bool = False,
    ) -> Self:
        """
        Remove tag records from the cache that match the specified filters.

        :param begin_dt: Filter by begin time (inclusive)
        :param end_dt: Filter by end time (inclusive)
        :param tag_pattern: Filter by tag name pattern (SQL LIKE syntax, e.g. "dummy_tag:%" to match all tags starting
        with "dummy_tag:")
        :param tagsets: Filter by tagsets (match tags that are in any of the specified tagsets)
        :param tagset_inverted: Whether to invert the tagset filter (match tags that are NOT in any of the specified
        tagsets)
        :return: Self instance for chaining
        """
        with self.make_session() as session:
            query = session.query(TagRecordTable).filter(TagRecordTable.target_sqn == self.target_info.sqn)
            if begin_dt:
                query = query.filter(TagRecordTable.end_dt >= begin_dt)
            if end_dt:
                query = query.filter(TagRecordTable.begin_dt <= end_dt)
            if tag_pattern:
                query = query.filter(TagRecordTable.tag.like(f"{escape_sql_like(tag_pattern)}%", escape="\\"))
            if tagsets:
                if tagset_inverted:
                    query = query.filter(
                        TagRecordTable.tag.notin_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))
                else:
                    query = query.filter(
                        TagRecordTable.tag.in_([tag_name for tagset in tagsets for tag_name in tagset.tag_names]))

            query.delete()
            session.commit()

        return self


@memorized
def tag_cache(*, identifier: str | None = None, file_path: str | None = None) -> TagCache:
    """
    Get a ``TagCache`` instance associated with the given identifier. If the identifier is ``None``, return a
    ``TagCache`` instance associated with a default file path. Otherwise, validate the identifier as a snake case
    string and return a ``TagCache`` instance associated with a file path derived from the identifier.

    :param identifier: An optional string identifier for the tag cache. If provided, it must be in snake case format
    and will be used to derive the file path for the tag cache. If not provided, a default file path will be used.
    :param file_path: An optional file path for the tag cache. If provided, it will be used directly. If not provided,
    the file path will be derived from the identifier if it is provided, or a default file path will be used if the
    identifier is not provided. Note that both 'identifier' and 'file_path' cannot be specified at the same time.
    :return: A ``TagCache`` instance associated with the specified or default file path.
    """
    if identifier is not None and file_path is not None:
        raise ValueError("cannot specify both 'identifier' and 'file_path'")
    if identifier is not None:
        validate_snake_case(identifier)
        return TagCache(file_path=tag_cache_file_path().parent / f"{identifier}.db")
    if file_path is not None:
        return TagCache(file_path=file_path)
    return TagCache(file_path=tag_cache_file_path())
