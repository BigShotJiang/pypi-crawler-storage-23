Differential Geometry of Curves and Surfaces
============================================

.. toctree::
   :maxdepth: 1

   sage/geometry/riemannian_manifolds/parametrized_surface3d
   sage/geometry/riemannian_manifolds/surface3d_generators

.. include:: ../footer.txt
