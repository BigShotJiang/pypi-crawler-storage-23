"""
Binary vocabulary data package.
"""
