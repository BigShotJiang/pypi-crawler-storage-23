"""
SES Intelligence Web Module

Embedded web dashboard for the SES Intelligence platform.
"""

__version__ = "1.0.0b2"
