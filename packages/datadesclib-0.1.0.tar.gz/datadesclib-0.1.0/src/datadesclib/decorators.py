from typing import TypeVar, Any

T = TypeVar('T')


def meta(**kwargs: Any):
    def decorator(obj: T) -> T:
        if not hasattr(obj, "_meta"):
            setattr(obj, "_meta", {})

        getattr(obj, "_meta").update(kwargs)
        return obj

    return decorator