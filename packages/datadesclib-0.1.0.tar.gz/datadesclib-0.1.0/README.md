# datadesclib 📊

A lightweight Python library to attach metadata to classes and functions using decorators and extract them into structured JSON/dictionary formats.

## Installation

```bash
pip install datadesclib
```

## Quick Start
### 1. Annotate your code
Use the @meta decorator to attach any custom information to your classes or functions.

```Python
from datadesclib import meta

@meta(author="Lukas", version="1.0", tags=["internal", "database"])
class UserData:
    name: str
    age: int = 25

    @meta(description="Saves the user to the DB")
    def save(self):
        pass
```

### 2. Extract Metadata
You can extract information from a single object or parse an entire Python file.

Extract from object:
```Python
from datadesclib import extract

info = extract(UserData)
print(info)
```
Parse a whole file to JSON:
```Python
from datadesclib import parser

json_data = parser("my_script.py")
print(json_data)
```

## Features
**Zero Dependencies:** Uses only Python standard library (inspect, json, etc.).

**Type Hint Support:** Automatically detects type annotations.

**Docstring Fallback:** Uses docstrings as descriptions if no explicit metadata is provided.

**Flexible:** Works with classes, methods, and global functions.

## License
[CC0 1.0 Universal (Public Domain)](LICENSE)