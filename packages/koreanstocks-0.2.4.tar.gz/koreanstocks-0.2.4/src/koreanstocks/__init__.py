VERSION = "0.2.4"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
