from setuptools import setup, find_packages

setup(
    name="next-django",
    version="0.6.0",
    description="File-system routing para Django, inspirado no Next.js App Router.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Guilherme Santos",
    author_email="guilhermedevasantos2004@gmail.com",
    url="https://github.com/guizeroum/next-django",
    packages=find_packages(include=['next_django', 'next_django.*']),
    install_requires=[
        "Django>=5.2.11",
        "django-cotton>=2.6.1",
        "django-ninja>=1.5.3",
        "pytest>=9.0.2",
        "pytest-django>=4.12.0",
    ],
    entry_points={
        'console_scripts': [
            'next-django=next_django.cli:main',
        ],
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Environment :: Web Environment",
        "Framework :: Django",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
    ],
    python_requires=">=3.10.11",
)