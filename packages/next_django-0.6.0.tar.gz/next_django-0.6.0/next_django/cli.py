# next_django/cli.py
import argparse
import re
import subprocess
import sys
from pathlib import Path

def patch_django_files(base_dir):
    settings_files = list(base_dir.glob('*/settings.py'))
    if not settings_files:
        print("⚠️ Aviso: Não encontrei o arquivo 'settings.py'.")
        return False
        
    settings_path = settings_files[0]
    urls_path = settings_path.parent / 'urls.py'

    # Modificando o SETTINGS.PY
    settings_content = settings_path.read_text(encoding='utf-8')
    
    if "'django_cotton'" not in settings_content:
        settings_content = re.sub(
            r'INSTALLED_APPS = \[',
            "INSTALLED_APPS = [\n    'django_cotton',\n    'models',",
            settings_content
        )
        
    if "BASE_DIR / 'app'" not in settings_content:
        settings_content = re.sub(
            r"'DIRS': \[\]",
            "'DIRS': [BASE_DIR / 'app', BASE_DIR]",
            settings_content
        )

    if "'next_django.context_processors.htmx'" not in settings_content:
        settings_content = re.sub(
            r"'django\.template\.context_processors\.request',",
            "'django.template.context_processors.request',\n                'next_django.context_processors.htmx',",
            settings_content
        )
        
    if "COTTON_DIR" not in settings_content:
        settings_content += "\n# Configuração de Componentes do Next-Django\nCOTTON_DIR = 'components'\n"
        
    settings_path.write_text(settings_content, encoding='utf-8')
    print(f"⚙️  {settings_path.name} atualizado: HTMX, Cotton e Rotas configurados!")

    # Modificando o URLS.PY
    if urls_path.exists():
        urls_content = urls_path.read_text(encoding='utf-8')
        if "generate_urlpatterns" not in urls_content:
            imports = "from next_django.router import generate_urlpatterns\nfrom django.conf import settings\n"
            urls_content = imports + urls_content + "\n# Roteamento Mágico do Next-Django\nurlpatterns += generate_urlpatterns(settings.BASE_DIR)\n"
            urls_path.write_text(urls_content, encoding='utf-8')
            print(f"🔗 {urls_path.name} atualizado: Auto-Router ativado!")

    return True

def run_initial_migrations(base_dir):
    """Executa python manage.py migrate para garantir que a Sessão do Django funcione logo de cara"""
    manage_py_path = base_dir / 'manage.py'
    
    if not manage_py_path.exists():
        print("⚠️ Aviso: 'manage.py' não encontrado. Pulei as migrações automáticas.")
        return

    print("🗄️  Executando migrações iniciais do banco de dados...")
    try:
        # Usa sys.executable para garantir que está rodando no mesmo ambiente virtual (venv)
        result = subprocess.run(
            [sys.executable, str(manage_py_path), "migrate"],
            capture_output=True,
            text=True,
            check=True
        )
        print("✅ Banco de dados configurado com sucesso!")
    except subprocess.CalledProcessError as e:
        print("❌ Erro ao executar migrações:")
        print(e.stderr)
        print("💡 Dica: Rode 'python manage.py migrate' manualmente depois.")

def create_boilerplate():
    base_dir = Path.cwd()
    print("🚀 Inicializando o Next-Django com Dashboard SPA e Alpine.js...")

    if not patch_django_files(base_dir):
        return

    pastas = ["app", "components/ui", "models", "api"]
    for pasta in pastas:
        (base_dir / pasta).mkdir(parents=True, exist_ok=True)

    # ==========================================
    # 1. LAYOUT GLOBAL (COM ALPINE.JS)
    # ==========================================
    layout_content = """{% if not is_htmx %}
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Next-Django App</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/htmx.org@1.9.10"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        .htmx-indicator { opacity: 0; transition: opacity 200ms ease-in; height: 3px; background: #10b981; position: fixed; top: 0; left: 0; width: 100%; z-index: 50; }
        .htmx-request .htmx-indicator { opacity: 1; }
        .htmx-request.htmx-indicator { opacity: 1; }
    </style>
</head>
<body class="bg-slate-900 text-slate-100 min-h-screen font-sans antialiased flex" hx-ext="preload">
    <div id="loading-bar" class="htmx-indicator"></div>

    <aside class="w-64 bg-slate-800 border-r border-slate-700 h-screen fixed flex flex-col p-6 shadow-xl z-10">
        <h2 class="text-2xl font-black mb-10 text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-blue-500">
            Next-Django
        </h2>
        <nav class="flex flex-col space-y-2">
            <c-ui.link href="/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">🏠 Home</c-ui.link>
            <c-ui.link href="/sobre/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">ℹ️ Sobre Nós</c-ui.link>
            <c-ui.link href="/formulario/" class="p-3 rounded-lg hover:bg-slate-700 transition flex items-center font-medium">📝 Formulário</c-ui.link>
        </nav>
        <div class="mt-auto pt-6 border-t border-slate-700 text-xs text-slate-500 text-center">
            v0.6.0 (Alpine + Otimista)
        </div>
    </aside>

    <main class="ml-64 flex-1 min-h-screen relative">
        <div id="next-root" class="p-10 max-w-5xl mx-auto">
{% endif %}

            {% block content %}
            {% endblock %}

{% if not is_htmx %}
        </div>
    </main>
</body>
</html>
{% endif %}"""
    (base_dir / "app/layout.html").write_text(layout_content, encoding='utf-8')

    # ==========================================
    # 2 e 3. PÁGINAS BÁSICAS
    # ==========================================
    page_py = "from django.shortcuts import render\n\ndef page(request):\n    return render(request, 'page.html')\n"
    (base_dir / "app/page.py").write_text(page_py, encoding='utf-8')
    page_html = """{% extends "layout.html" %}\n{% block content %}\n<div class="bg-slate-800 p-8 rounded-2xl"><h1>Bem-vindo!</h1></div>\n{% endblock %}"""
    (base_dir / "app/page.html").write_text(page_html, encoding='utf-8')

    (base_dir / "app/sobre").mkdir(parents=True, exist_ok=True)
    page_py_sobre = "from django.shortcuts import render\n\ndef page(request):\n    return render(request, 'sobre/page.html')\n"
    (base_dir / "app/sobre/page.py").write_text(page_py_sobre, encoding='utf-8')
    sobre_html = """{% extends "layout.html" %}\n{% block content %}\n<div class="bg-slate-800 p-8 rounded-2xl"><h1>Sobre Nós</h1></div>\n{% endblock %}"""
    (base_dir / "app/sobre/page.html").write_text(sobre_html, encoding='utf-8')

    # ==========================================
    # 4. PÁGINA FORMULÁRIO (COM DELAY NA VIEW)
    # ==========================================
    (base_dir / "app/formulario").mkdir(parents=True, exist_ok=True)
    
    page_py_form = """from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse
import math
import time

def page(request):
    if 'itens' not in request.session:
        request.session['itens'] = [{'id': i, 'nome': f'Usuário Teste {i}'} for i in range(1, 13)]

    if request.method == 'POST':
        # TIMEOUT DE 2 SEGUNDOS PARA VERMOS A MÁGICA OTIMISTA
        time.sleep(2)
        
        nome = request.POST.get('nome', 'Visitante')
        novo_id = len(request.session['itens']) + 1
        
        request.session['itens'].insert(0, {'id': novo_id, 'nome': nome})
        request.session.modified = True
        
        messages.success(request, f"Usuário {nome} adicionado com sucesso!")
        
        # Retorna apenas a linha renderizada via Out of Bounds para a tabela
        if request.headers.get('HX-Request') == 'true':
            html_linha = f'''
            <tr class="border-b border-emerald-900 bg-emerald-900/20 transition-colors animate-fade-in" x-data x-init="setTimeout(() => $el.classList.remove('bg-emerald-900/20'), 2000)">
                <td class="px-6 py-4 font-bold text-emerald-500">#{novo_id}</td>
                <td class="px-6 py-4 text-white">{nome} <span class="text-xs text-emerald-400 ml-2">✓ Novo</span></td>
                <td class="px-6 py-4 text-right"></td>
            </tr>
            '''
            return HttpResponse(html_linha)

    page_num = int(request.GET.get('page', 1))
    items_per_page = 5
    
    todos_itens = request.session['itens']
    total_items = len(todos_itens)
    total_pages = math.ceil(total_items / items_per_page) if total_items > 0 else 1
    
    start = (page_num - 1) * items_per_page
    end = start + items_per_page
    itens_paginados = todos_itens[start:end]

    max_pages_to_show = 5
    half_range = max_pages_to_show // 2
    start_page = max(1, page_num - half_range)
    end_page = min(total_pages, start_page + max_pages_to_show - 1)

    context = {
        'itens': itens_paginados,
        'total_pages': total_pages,
        'current_page': page_num,
        'items_per_page': items_per_page,
        'page_range': range(start_page, end_page + 1),
        'querystring': '',
    }

    return render(request, 'formulario/page.html', context)
"""
    (base_dir / "app/formulario/page.py").write_text(page_py_form, encoding='utf-8')

    form_html = """{% extends "layout.html" %}
{% block content %}
    <div class="max-w-4xl mx-auto space-y-8 animate-fade-in">
        
        <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700">
            <h1 class="text-3xl font-bold mb-6">Adicionar Usuário</h1>
            
            {% if messages %}
                <div class="mb-6 space-y-2">
                    {% for message in messages %}
                        <div class="p-4 bg-emerald-500/20 border border-emerald-500 text-emerald-400 rounded-xl font-medium flex items-center">
                            ✅ {{ message }}
                        </div>
                    {% endfor %}
                </div>
            {% endif %}

            <c-ui.optimistic_form action="/formulario/" />
        </div>

        <div class="bg-slate-800 p-8 rounded-2xl shadow-lg border border-slate-700">
            <h2 class="text-2xl font-bold mb-6">Usuários Cadastrados</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-slate-300 mb-4">
                    <thead class="text-xs text-slate-400 uppercase bg-slate-900/80 rounded-t-lg">
                        <tr>
                            <th class="px-6 py-4 rounded-tl-lg w-20">ID</th>
                            <th class="px-6 py-4">Nome</th>
                            <th class="px-6 py-4 rounded-tr-lg text-right">Ação</th>
                        </tr>
                    </thead>
                    <tbody id="tabela-usuarios" 
                           x-data="{ skeletonAtivo: false }" 
                           @formulario-enviado.window="skeletonAtivo = true"
                           @htmx:after-on-load.window="skeletonAtivo = false">
                        
                        <tr x-show="skeletonAtivo" style="display: none;" class="border-b border-slate-700/50 bg-slate-800/50 animate-pulse">
                            <td class="px-6 py-4"><div class="h-4 bg-slate-700 rounded w-8"></div></td>
                            <td class="px-6 py-4"><div class="h-4 bg-slate-700 rounded w-48"></div></td>
                            <td class="px-6 py-4 text-right"><div class="h-4 bg-slate-700 rounded w-16 ml-auto"></div></td>
                        </tr>

                        {% for item in itens %}
                            <c-ui.table_row item_id="{{ item.id }}" item_nome="{{ item.nome }}" />
                        {% empty %}
                            <tr><td colspan="3" class="px-6 py-8 text-center text-slate-500 italic">Nenhum usuário encontrado.</td></tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>

            <c-ui.pagination />

        </div>
    </div>
{% endblock %}"""
    (base_dir / "app/formulario/page.html").write_text(form_html, encoding='utf-8')

    # ==========================================
    # 5. COMPONENTES: BUTTON, LINK, PAGINATION, FORM, TABLE_ROW
    # ==========================================
    button_html = """<button class="bg-blue-600 hover:bg-blue-500 text-white font-semibold py-2 px-6 rounded-lg shadow-md transition-all duration-200">{{ slot }}</button>"""
    (base_dir / "components/ui/button.html").write_text(button_html, encoding='utf-8')

    link_html = """<a href="{{ href }}" hx-get="{{ href }}" hx-push-url="true" hx-target="#next-root" hx-swap="innerHTML" hx-indicator="#loading-bar" class="cursor-pointer {{ class|default:'text-blue-500 hover:text-blue-400 underline transition-colors' }}">{{ slot }}</a>"""
    (base_dir / "components/ui/link.html").write_text(link_html, encoding='utf-8')
    
    # NOVO: Formulário Otimista
    form_html = """
    <form hx-post="{{ action }}" 
          hx-target="#tabela-usuarios" 
          hx-swap="afterbegin" 
          x-data="{ 
              nomeInput: '',
              enviar() {
                  // Dispara um evento customizado para o Alpine escutar na tabela
                  $dispatch('formulario-enviado');
                  // Limpa o form dando a sensação de instantâneo
                  setTimeout(() => { this.nomeInput = ''; }, 50);
              }
          }"
          @submit="enviar()"
          class="space-y-4">
        
        <div class="flex gap-4">
            <div class="flex-1">
                <input type="text" name="nome" x-model="nomeInput" required placeholder="Digite o nome..." 
                    class="w-full bg-slate-900 border border-slate-700 rounded-xl p-3 text-white focus:border-blue-500 focus:ring-1 focus:ring-blue-500 outline-none transition">
            </div>
            <button type="submit" class="bg-blue-600 hover:bg-blue-500 text-white font-bold py-3 px-8 rounded-xl transition-colors shadow-md transform hover:-translate-y-0.5 whitespace-nowrap">
                Adicionar
            </button>
        </div>
    </form>
    """
    (base_dir / "components/ui/optimistic_form.html").write_text(form_html, encoding='utf-8')

    # NOVO: Table Row Isolado
    row_html = """
    <tr x-data="{ deletando: false }" 
        x-show="!deletando" 
        x-transition.opacity.duration.300ms
        :class="{ 'bg-red-900/20 opacity-50': deletando, 'hover:bg-slate-700': !deletando }"
        class="border-b border-slate-700/50 transition-all">
        
        <td class="px-6 py-4 font-bold text-slate-500">#{{ item_id }}</td>
        <td class="px-6 py-4 text-white">{{ item_nome }}</td>
        <td class="px-6 py-4 text-right">
            <button 
                type="button"
                hx-delete="/api/usuarios/{{ item_id }}" 
                hx-swap="none"
                hx-on::before-request="deletando = true"
                hx-on::response-error="deletando = false; alert('Erro ao excluir!')"
                class="text-red-400 hover:text-red-300 font-medium transition-colors focus:outline-none"
            >
                Excluir
            </button>
        </td>
    </tr>
    """
    (base_dir / "components/ui/table_row.html").write_text(row_html, encoding='utf-8')

    # Paginação Simplificada no Código Final
    pagination_html = """<div class="flex flex-col-reverse md:flex-row justify-between items-center gap-4 py-6 border-t border-slate-700/50 mt-6"><span class="text-sm text-slate-400 font-medium">{% if total_pages <= 0 %}Mostrando a página 1 de 1{% else %}Mostrando a página {{ current_page }} de {{ total_pages }}{% endif %}</span><nav><ul class="inline-flex items-center -space-x-px text-sm shadow-sm rounded-lg overflow-hidden">{% if current_page > 1 %}<li><a hx-get="?page={{ current_page|add:-1 }}" hx-target="#next-root" hx-push-url="true" class="cursor-pointer flex items-center px-3 h-9 bg-slate-800 border-slate-700 hover:bg-slate-700 text-white">&lsaquo; Anterior</a></li>{% endif %}{% for num in page_range %}{% if num == current_page %}<li><span class="flex items-center px-4 h-9 bg-blue-600 text-white font-bold">{{ num }}</span></li>{% else %}<li><a hx-get="?page={{ num }}" hx-target="#next-root" hx-push-url="true" class="cursor-pointer flex items-center px-4 h-9 bg-slate-800 hover:bg-slate-700 text-slate-300">{{ num }}</a></li>{% endif %}{% endfor %}{% if current_page < total_pages %}<li><a hx-get="?page={{ current_page|add:1 }}" hx-target="#next-root" hx-push-url="true" class="cursor-pointer flex items-center px-3 h-9 bg-slate-800 border-slate-700 hover:bg-slate-700 text-white">Próximo &rsaquo;</a></li>{% endif %}</ul></nav></div>"""
    (base_dir / "components/ui/pagination.html").write_text(pagination_html, encoding='utf-8') 

    (base_dir / "models/__init__.py").write_text("# Registre seus modelos aqui\n", encoding='utf-8')
    apps_py = "from django.apps import AppConfig\n\nclass ModelsConfig(AppConfig):\n    default_auto_field = 'django.db.models.BigAutoField'\n    name = 'models'\n"
    (base_dir / "models/apps.py").write_text(apps_py, encoding='utf-8')
    api_py = "from ninja import Router\n\nrouter = Router()\n\n@router.get('/')\ndef hello(request):\n    return {'mensagem': 'API rodando!'}\n"
    (base_dir / "api/hello.py").write_text(api_py, encoding='utf-8')

    run_initial_migrations(base_dir)
    print("✅ Dashboard gerado com sucesso!")

def main():
    parser = argparse.ArgumentParser(description="CLI do Next-Django")
    parser.add_argument("command", choices=["init"], help="Inicializa a estrutura do projeto")
    args = parser.parse_args()
    if args.command == "init": create_boilerplate()

if __name__ == "__main__":
    main()