# next_django/context_processors.py

def htmx(request):
    """
    Detecta automaticamente se a requisição foi feita pelo HTMX.
    Disponibiliza a variável global {{ is_htmx }} em todos os templates.
    """
    return {
        'is_htmx': request.headers.get('HX-Request') == 'true'
    }