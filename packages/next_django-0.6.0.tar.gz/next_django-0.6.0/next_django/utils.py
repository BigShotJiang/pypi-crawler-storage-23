import datetime as dt
from typing import List, Dict, Any
from django.db import connection

def paginate_query(query: str, page: int, items_per_page: int, order_by: str = 'ID') -> dict:
    start_row = (page - 1) * items_per_page + 1
    end_row = page * items_per_page

    if '.' in order_by:
        order_by_column = order_by.split('.')[-1]
        order_by_final = f'a.{order_by_column}'
    else:
        order_by_final = f'a.{order_by}'

    def _normalize_value(val: Any) -> Any:
        if isinstance(val, dt.datetime) and val.tzinfo is not None:
            try:
                return val.astimezone(dt.timezone.utc).replace(tzinfo=None)
            except Exception:
                return val.replace(tzinfo=None)
        return val

    # Usando a conexão nativa do Django (agnóstico a banco)
    with connection.cursor() as cursor:
        paginated_query = f'''
            SELECT * FROM (
                SELECT
                    a.*,
                    ROW_NUMBER() OVER (ORDER BY {order_by_final}) as rn
                FROM ({query}) a
            ) paginated_subquery
            WHERE rn BETWEEN {start_row} AND {end_row}
        '''
        cursor.execute(paginated_query)
        items = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]

        item_list: List[Dict[str, Any]] = []
        for row in items:
            record = {col: _normalize_value(val) for col, val in zip(columns, row)}
            item_list.append(record)

        count_query = f'SELECT COUNT(*) FROM ({query}) count_subquery'
        cursor.execute(count_query)
        total_items = cursor.fetchone()[0]

    total_pages = (total_items + items_per_page - 1) // items_per_page
    max_pages_to_show = 5
    half_range = max_pages_to_show // 2
    start_page = max(1, page - half_range)
    end_page = min(total_pages, start_page + max_pages_to_show - 1)

    return {
        'items': item_list,
        'total_pages': total_pages,
        'current_page': page,
        'items_per_page': items_per_page,
        'page_range': range(start_page, end_page + 1)
    }


def build_querystring(request, exclude_params: List[str] = None) -> str:
    """
    Constrói querystring a partir dos parâmetros GET da requisição.
    Excelente para manter filtros ativos ao mudar de página.
    """
    if exclude_params is None:
        exclude_params = []

    params = request.GET.copy()
    for param in exclude_params:
        params.pop(param, None)

    query_parts: List[str] = []
    for key in params.keys():
        values = request.GET.getlist(key)
        for value in values:
            if value not in [None, '']:
                query_parts.append(f'{key}={value}')

    return '&'.join(query_parts)