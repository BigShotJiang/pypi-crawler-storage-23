# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Project Navi

"""navi-bootstrap: Jinja2 rendering engine and template packs."""

__version__ = "0.1.0"
