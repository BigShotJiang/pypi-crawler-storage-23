import tomllib
from pathlib import Path

def get_version() -> str:
    """
    获取 pyproject.toml 中的版本号
    
    Returns:
        版本号字符串，如果获取失败则返回 '0.0.0'
    """
    try:
        # 获取当前脚本所在目录
        current_file = Path(__file__).resolve()
        module_dir = current_file.parent
        
        # 构建 pyproject.toml 路径 (向上两级目录)
        pyproject_path = module_dir.parent.parent / "pyproject.toml"
        pyproject_path = pyproject_path.resolve()
        
        # 读取 pyproject.toml 文件
        import tomllib
        with open(pyproject_path, 'rb') as f:
            pyproject = tomllib.load(f)
        
        # 获取版本号
        version = pyproject.get('project', {}).get('version', '0.0.0')
        return version
        
    except Exception as error:
        return '0.0.0'

# 使用示例
if __name__ == "__main__":
    version = get_version()
    print(f"版本号: {version}")