# Skills 汇总

本文件作为技能索引，记录项目中所有可用的技能，由系统自动维护。
通过索引机制实现技能的快速定位和高效执行。

## 技能列表

### Java REST API 生成器|java-rest-api-generator
**来源**: project
Spring Boot Controller 生成规范，对齐项目既有响应、异常、UMP 等约定

### Java 数据模型生成器|java-data-model-generator
**来源**: project
快速生成数据传输对象（DTO），包括请求/响应对象、参数验证、序列化配置等

### Java RPC 服务生成器|java-rpc-service-generator
**来源**: project
通用的 JSF/DongBoot RPC 导入步骤与规范，适用于使用该类框架的 Java 项目

### Java 业务服务生成器|java-business-service-generator
**来源**: project
Spring Boot Service 层生成规范，对齐项目分层（app/domain）、事务、异常与命名约定