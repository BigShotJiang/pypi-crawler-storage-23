from __future__ import annotations

import argparse

from .reader import read_captcha_from_url


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Read CAPTCHA text from an image URL")
    parser.add_argument("image_url", help="Captcha image URL")
    parser.add_argument("--cpu-only", action="store_true", help="Disable GPU and force CPU OCR")
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    text = read_captcha_from_url(args.image_url, prefer_gpu=not args.cpu_only)
    if text:
        print(text)
    else:
        print("No text extracted")


if __name__ == "__main__":
    main()
