# captcha-url-reader

Simple package: user passes captcha image URL, package reads and returns text.

## Install

```bash
pip install -e .
```

## Usage

```python
from captcha_image_reader import read_captcha_from_url

# Default mode (recommended for Amazon-style captchas)
captcha_text = read_captcha_from_url("https://images-na.ssl-images-amazon.com/captcha/sgkknrsj/Captcha_iwrdailhkf.jpg")
if captcha_text:
    print(f"CAPTCHA text extracted: {captcha_text}")
else:
    print("No text extracted from image URL.")
```

## Overlap-heavy captcha mode

Use forced overlap mode only when text is merged/overlapping and default mode is not accurate.

```python
from captcha_image_reader import read_captcha_from_url

captcha_text = read_captcha_from_url(
    "https://2captcha.com/dist/web/assets/captcha-rn1S3orp.jpg",
    force_overlap_risk=True,
)
```

## When to use which mode

- Use default mode for clean or mostly non-overlapping text (for example, most Amazon captchas).
- Use `force_overlap_risk=True` only when characters are merged and default extraction is wrong.

## Example scripts

- Default/Amazon style: `examples/read_amazon_default.py`
- Overlap-heavy style: `examples/read_overlap_captcha.py`

Run them directly:

```bash
./.venv/bin/python examples/read_amazon_default.py
./.venv/bin/python examples/read_overlap_captcha.py
```

## GPU behavior

- Uses GPU first by default.
- If GPU is not available or fails, automatically falls back to CPU.
