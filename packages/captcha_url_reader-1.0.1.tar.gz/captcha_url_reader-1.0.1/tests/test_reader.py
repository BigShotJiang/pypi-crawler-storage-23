from captcha_image_reader import read_captcha_from_url
from captcha_image_reader import reader as reader_module
import numpy as np


class FakeResponse:
    def __init__(self, content: bytes):
        self.content = content

    def raise_for_status(self) -> None:
        return None


def test_reader_returns_none_on_invalid_url(monkeypatch):
    def fake_get(url, timeout):
        raise Exception("network")

    monkeypatch.setattr("captcha_image_reader.reader.requests.get", fake_get)

    assert read_captcha_from_url("https://example.com/captcha.jpg") is None


def test_import_works():
    assert callable(read_captcha_from_url)


def test_gpu_first_then_cpu_fallback(monkeypatch):
    class FakeReader:
        def __init__(self, gpu):
            self.gpu = gpu

        def readtext(self, arr, detail):
            return []

    created = []

    def fake_easyocr_reader(langs, gpu):
        created.append(gpu)
        if gpu:
            raise RuntimeError("gpu unavailable")
        return FakeReader(gpu=False)

    monkeypatch.setattr(reader_module.easyocr, "Reader", fake_easyocr_reader)
    reader_module._READER_CACHE.clear()
    r = reader_module._get_reader(prefer_gpu=True)
    assert created == [True, False]
    assert r.gpu is False


def test_overlap_ambiguity_prefers_digit_text_when_supported():
    class FakeReader:
        def __init__(self):
            self.calls = 0

        def readtext(self, arr, detail=1, **kwargs):
            self.calls += 1
            if self.calls == 1:
                return [([[10, 0], [20, 0], [20, 10], [10, 10]], "WOHSK", 0.92)]
            return [([[10, 0], [20, 0], [20, 10], [10, 10]], "W9H5K", 0.45)]

    variants = [np.zeros((20, 60), dtype=np.uint8)]
    text = reader_module._extract_best_text(FakeReader(), variants, overlap_risk=True)
    assert text == "W9H5K"


def test_no_digit_evidence_does_not_force_digit_substitution():
    class FakeReader:
        def readtext(self, arr, detail=1, **kwargs):
            return [([[10, 0], [20, 0], [20, 10], [10, 10]], "WOHSK", 0.9)]

    variants = [np.zeros((20, 60), dtype=np.uint8)]
    text = reader_module._extract_best_text(FakeReader(), variants)
    assert text == "WOHSK"


def test_overlap_risk_can_recover_digits_without_prior_digit_evidence():
    class FakeReader:
        def readtext(self, arr, detail=1, **kwargs):
            return [([[10, 0], [20, 0], [20, 10], [10, 10]], "WOHSK", 0.9)]

    variants = [np.zeros((20, 60), dtype=np.uint8)]
    text = reader_module._extract_best_text(FakeReader(), variants, overlap_risk=True)
    assert text == "W9H5K"


def test_default_mode_keeps_all_letter_captcha():
    class FakeReader:
        def __init__(self):
            self.calls = 0

        def readtext(self, arr, detail=1, **kwargs):
            self.calls += 1
            if self.calls == 1:
                return [([[10, 0], [20, 0], [20, 10], [10, 10]], "CLBHUF", 0.88)]
            return [([[10, 0], [20, 0], [20, 10], [10, 10]], "C18HUF", 0.42)]

    variants = [np.zeros((20, 60), dtype=np.uint8)]
    text = reader_module._extract_best_text(FakeReader(), variants, overlap_risk=False)
    assert text == "CLBHUF"
