def main():
    print("sdepack v0.0.1")
    print("Runge-Kutta Numerical Integration Stochastic Differential Equations for Python")


if __name__ == "__main__":
    main()
