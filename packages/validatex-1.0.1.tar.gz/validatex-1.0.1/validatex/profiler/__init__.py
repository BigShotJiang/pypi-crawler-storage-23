"""Profiler module — automatic data profiling and expectation suggestion."""
