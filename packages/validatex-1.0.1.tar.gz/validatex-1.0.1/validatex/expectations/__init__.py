"""Built-in expectations for ValidateX."""

# Import submodules so that expectations are registered on import.
import validatex.expectations.column_expectations  # noqa: F401
import validatex.expectations.table_expectations  # noqa: F401
import validatex.expectations.aggregate_expectations  # noqa: F401
