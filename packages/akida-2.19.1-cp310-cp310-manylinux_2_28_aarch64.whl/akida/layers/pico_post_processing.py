from akida.core import Layer, LayerType, LayerParams


class PicoPostProcessing(Layer):
    """Implementation of post-processing layer for Akida neural processing units.

    This layer implements of the PicoPostProcessing operation, which computes mean absolute
    difference between predictions and targets, then applies binarization using a threshold.

    The layer performs:

    0. Downscale y_pred towards y_true bitwidth and scale
    1. Mean absolute difference: mean(abs(y_pred - y_true), axis)
    2. Binarization: output = 1.0 if difference >= threshold else 0.0

    This is commonly used for lightweight evaluation tasks such as anomaly detection
    or pass/fail classification where continuous error metrics are converted to
    binary decisions.

    Args:
        buffer_bits (int, optional): number of bits for internal buffer computations.
            Defaults to 44 for high precision intermediate calculations.
        name (str, optional): name of the layer. Defaults to empty string.
    """

    def __init__(self, buffer_bits=44, name=""):
        try:
            params = LayerParams(
                LayerType.PicoPostProcessing, {"buffer_bits": buffer_bits}
            )
            # Call parent constructor to initialize C++ bindings
            # Note that we invoke directly __init__ instead of using super, as
            # specified in pybind documentation
            Layer.__init__(self, params, name)
        except BaseException:
            self = None
            raise
