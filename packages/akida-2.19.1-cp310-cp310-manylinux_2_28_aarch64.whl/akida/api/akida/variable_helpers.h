#pragma once

#include "akida/dense.h"
#include "core/mapping_status.h"

namespace akida {

int evaluate_bitwidth(const Dense& dense);

MappingStatus check_bitwidth(const Layer& layer, int max_bitwidth,
                             const std::string& name, bool strict);
}  // namespace akida
