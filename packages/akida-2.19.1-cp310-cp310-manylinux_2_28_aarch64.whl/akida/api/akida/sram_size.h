#pragma once

#include <cstdint>

#include "infra/exports.h"

namespace akida {
/**
 * Size of shared SRAM
 */
struct AKIDASHAREDLIB_EXPORT SramSize final {
  bool operator==(const SramSize&) const = default;

  /**
   * Size of shared input packet SRAM in bytes available inside the mesh
   * for each two NPs.
   */
  uint32_t input_bytes{};
  /**
   * Size of shared filter SRAM in bytes available inside the mesh for each two
   * NPs.
   */
  uint32_t weight_bytes{};
  /**
   * Size of STSRAM in 32-bit words (Pico only).
   */
  uint32_t stsram_32b_size{};
  /**
   * Size of FSRAM in 64-bit words (Pico only).
   */
  uint32_t fsram_64b_size{};
  /**
   * Size of TSRAM in 51-bit words (Pico only).
   */
  uint32_t tsram_51b_size{};
  /**
   * Size of EVSRAM in 32-bit words (Pico only).
   */
  uint32_t evsram_32b_size{};
};
}  // namespace akida
