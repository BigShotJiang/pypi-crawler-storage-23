# Allow running as python -m aiolocust ...
from aiolocust.main import app

if __name__ == "__main__":
    app()
