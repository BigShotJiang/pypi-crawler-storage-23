"""grip - Async-first agentic AI platform."""

__version__ = "0.4.2"
