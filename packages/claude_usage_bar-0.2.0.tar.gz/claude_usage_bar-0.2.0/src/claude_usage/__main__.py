"""Entry point for `python -m claude_usage`."""

from claude_usage.app import main

if __name__ == "__main__":
    main()
