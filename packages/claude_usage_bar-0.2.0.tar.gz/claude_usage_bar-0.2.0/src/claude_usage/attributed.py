"""NSAttributedString helpers for styled menu bar text.

Uses AppKit via PyObjC (bundled with rumps).
"""

from AppKit import (
    NSAttributedString,
    NSColor,
    NSFont,
    NSForegroundColorAttributeName,
    NSFontAttributeName,
    NSMutableAttributedString,
    NSTextField,
    NSView,
)


def hex_to_nscolor(hex_str):
    """Convert a hex color string like '#FF4444' to an NSColor."""
    h = hex_str.lstrip("#")
    r = int(h[0:2], 16) / 255.0
    g = int(h[2:4], 16) / 255.0
    b = int(h[4:6], 16) / 255.0
    return NSColor.colorWithCalibratedRed_green_blue_alpha_(r, g, b, 1.0)


def styled_string(text, color=None, font_name="Menlo", font_size=13.0):
    """Return an NSAttributedString with the given font and optional color.

    Args:
        text: The string to style.
        color: A hex color string (e.g. '#FF4444') or None for default.
        font_name: Font family name.
        font_size: Font size in points.

    Returns:
        An NSAttributedString.
    """
    attrs = {}
    font = NSFont.fontWithName_size_(font_name, font_size)
    if font:
        attrs[NSFontAttributeName] = font
    if color:
        attrs[NSForegroundColorAttributeName] = hex_to_nscolor(color)
    return NSAttributedString.alloc().initWithString_attributes_(text, attrs)


def styled_segments(segments, font_name="Menlo", font_size=13.0):
    """Build an NSMutableAttributedString from colored segments.

    Args:
        segments: List of (text, color_hex_or_None) or
                  (text, color_hex_or_None, font_name_override) tuples.
        font_name: Default font family name.
        font_size: Font size in points.

    Returns:
        An NSMutableAttributedString with per-segment coloring and fonts.
    """
    result = NSMutableAttributedString.alloc().init()
    for seg in segments:
        text, color = seg[0], seg[1]
        seg_font = seg[2] if len(seg) > 2 else font_name
        part = styled_string(text, color=color, font_name=seg_font, font_size=font_size)
        result.appendAttributedString_(part)
    return result


def set_inert_title(ns_menu_item, attributed_string, height=22.0,
                    padding_left=20.0):
    """Set a menu item's display via a custom NSView.

    The item renders at full opacity with no hover highlight —
    the standard macOS pattern for informational (non-interactive) rows.
    """
    label = NSTextField.alloc().init()
    label.setAttributedStringValue_(attributed_string)
    label.setEditable_(False)
    label.setSelectable_(False)
    label.setBezeled_(False)
    label.setDrawsBackground_(False)
    label.sizeToFit()

    frame = label.frame()
    label.setFrameOrigin_((padding_left, (height - frame.size.height) / 2))

    view_width = max(frame.size.width + padding_left + 10, 250)
    view = NSView.alloc().initWithFrame_(((0, 0), (view_width, height)))
    view.addSubview_(label)

    ns_menu_item.setView_(view)
