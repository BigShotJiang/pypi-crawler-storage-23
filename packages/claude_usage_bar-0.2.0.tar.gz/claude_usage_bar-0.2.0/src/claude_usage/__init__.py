"""Claude Usage Bar — macOS menu bar app for Claude API usage."""

__version__ = "0.2.0"
