"""Constants specific to the ESF-24 model (experimental)."""

CMD_SET_DISPLAY_UNIT = bytearray.fromhex("1309150010283700a0")
CMD_END_MEASUREMENT = bytearray.fromhex("1f05151049")
