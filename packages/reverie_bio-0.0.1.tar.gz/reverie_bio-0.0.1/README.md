# Reverie

A training and fine-tuning tool for bio foundation models.


## Installation

```bash
pip install reverie-bio[all]
```

For Standard Model Bio support, also install `smb-utils`:

```bash
pip install git+https://github.com/standardmodelbio/smb-utils.git
```

For development:

```bash
git clone https://github.com/zaaisvanzyl/reverie.git
cd reverie
pip install -e ".[all,dev]"
```

## Quick Start

### Option 1: Web UI (Recommended)

A browser-based interface for uploading data, configuring training, and viewing results.

```bash
# Launch the UI
reverie ui
```

This starts a local server at `http://127.0.0.1:7860`. You can customize host and port:

```bash
reverie ui --host 0.0.0.0 --port 8000
```

### Option 2: CLI

```bash
reverie train \
    --model standard-model \
    --data ./data/synthetic_data.parquet \
    --labels ./data/synthetic_labels.csv \
    --label-column label \
    --output ./results
```

## Foundation Models

### Standard Model Bio

| Column | Type | Description |
|--------|------|-------------|
| `subject_id` | string/int | Patient identifier |
| `time` | datetime | Event timestamp |
| `code` | string | Clinical code (ICD-10, RxNorm, LOINC, etc.) |

Example:
```csv
subject_id,time,code
patient_001,2023-01-15,ICD10:E11.9
patient_001,2023-01-15,RxNorm:860975
patient_002,2023-03-10,ICD10:I10
```

### Labels

One row per patient:
```csv
subject_id,label
patient_001,0
patient_002,1
```

Reference: [standardmodel.bio](https://standardmodel.bio)


## Development

```bash
# Install dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Run tests with coverage
pytest --cov=reverie
```
