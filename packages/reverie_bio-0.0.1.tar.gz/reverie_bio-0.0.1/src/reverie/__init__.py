"""Reverie: Fine-tune foundation models for life sciences."""

import logging

__version__ = "0.1.0"

logging.getLogger(__name__).addHandler(logging.NullHandler())
