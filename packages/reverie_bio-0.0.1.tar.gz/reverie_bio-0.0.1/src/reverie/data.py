"""Data loading and preprocessing utilities."""

import logging
from pathlib import Path
from typing import Any, Dict, Optional, Tuple, Union

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)


def load_data(path: Union[str, Path]) -> pd.DataFrame:
    """
    Load data from CSV or Parquet file.
    
    Args:
        path: Path to data file. Supports .csv, .parquet, .pq extensions.
        
    Returns:
        DataFrame with loaded data.
        
    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If file extension is not supported.
    """
    path = Path(path)
    
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")
    
    suffix = path.suffix.lower()
    
    if suffix == ".csv":
        logger.info("Loading CSV file: %s", path)
        return pd.read_csv(path)
    elif suffix in (".parquet", ".pq"):
        logger.info("Loading Parquet file: %s", path)
        return pd.read_parquet(path)
    else:
        raise ValueError(
            f"Unsupported file format: {suffix}. "
            f"Supported formats: .csv, .parquet, .pq"
        )


def load_labels(
    path: Union[str, Path],
    id_column: str,
    label_column: str,
) -> Dict[Any, Any]:
    """
    Load labels from a file.
    
    The file should have at least two columns:
    - An ID column matching sample IDs in the data
    - A label column with the target values
    
    Args:
        path: Path to labels file (CSV or Parquet).
        id_column: Name of the column containing sample IDs.
        label_column: Name of the column containing labels.
        
    Returns:
        Dictionary mapping sample_id -> label.
        
    Raises:
        FileNotFoundError: If file doesn't exist.
        ValueError: If required columns are missing.
        
    Example:
        >>> labels = load_labels("labels.csv", id_column="subject_id", label_column="outcome")
        >>> labels["patient_1"]
        1
    """
    df = load_data(path)
    
    # Validate columns exist
    missing = set()
    if id_column not in df.columns:
        missing.add(id_column)
    if label_column not in df.columns:
        missing.add(label_column)
    
    if missing:
        raise ValueError(
            f"Missing columns in labels file: {missing}. "
            f"Available columns: {list(df.columns)}"
        )
    
    # Check for duplicate IDs
    if df[id_column].duplicated().any():
        duplicates = df[id_column][df[id_column].duplicated()].unique()
        raise ValueError(
            f"Duplicate IDs found in labels file: {list(duplicates)[:5]}... "
            f"Each sample should have exactly one label."
        )
    
    # Build dictionary
    return dict(zip(df[id_column], df[label_column]))


def extract_labels_from_data(
    df: pd.DataFrame,
    id_column: str,
    label_column: str,
) -> Dict[Any, Any]:
    """
    Extract labels from a column in the data file.
    
    Useful when labels are stored alongside the data. For datasets
    with multiple rows per sample (like MEDS format), this takes
    the first label value for each sample ID.
    
    Args:
        df: DataFrame containing both data and labels.
        id_column: Name of the column containing sample IDs.
        label_column: Name of the column containing labels.
        
    Returns:
        Dictionary mapping sample_id -> label.
        
    Raises:
        ValueError: If required columns are missing or labels are inconsistent.
    """
    # Validate columns exist
    missing = set()
    if id_column not in df.columns:
        missing.add(id_column)
    if label_column not in df.columns:
        missing.add(label_column)
    
    if missing:
        raise ValueError(
            f"Missing columns: {missing}. "
            f"Available columns: {list(df.columns)}"
        )
    
    # Check that labels are consistent per ID
    # (all rows for same ID should have same label)
    labels_per_id = df.groupby(id_column)[label_column].nunique()
    inconsistent = labels_per_id[labels_per_id > 1]
    
    if len(inconsistent) > 0:
        raise ValueError(
            f"Inconsistent labels for sample IDs: {list(inconsistent.index)[:5]}... "
            f"Each sample ID should have the same label across all rows."
        )
    
    label_df = df.groupby(id_column)[label_column].first()
    logger.info("Extracted labels for %d samples", len(label_df))
    return label_df.to_dict()


def align_labels(
    sample_ids: np.ndarray,
    labels: Dict[Any, Any],
) -> np.ndarray:
    """
    Align labels with sample IDs.
    
    Given sample IDs (in the order embeddings are returned) and a
    label dictionary, return labels in the same order.
    
    Args:
        sample_ids: Array of sample IDs from model.get_sample_ids().
        labels: Dictionary mapping sample_id -> label.
        
    Returns:
        Array of labels in the same order as sample_ids.
        
    Raises:
        ValueError: If any sample IDs are missing from labels.
    """
    # Check for missing labels
    missing = set(sample_ids) - set(labels.keys())
    if missing:
        raise ValueError(
            f"Missing labels for {len(missing)} samples: {list(missing)[:5]}..."
        )
    
    # Align labels
    aligned = np.array([labels[sid] for sid in sample_ids])
    return aligned


def split_data(
    X: np.ndarray,
    y: np.ndarray,
    val_size: float = 0.2,
    random_state: Optional[int] = None,
    stratify: bool = True,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Split data into training and validation sets.
    
    Args:
        X: Feature matrix, shape (n_samples, n_features).
        y: Labels, shape (n_samples,).
        val_size: Fraction of data to use for validation (0 to 1).
        random_state: Random seed for reproducibility.
        stratify: Whether to stratify split by labels (for classification).
                  Set to False for regression tasks.
        
    Returns:
        Tuple of (X_train, X_val, y_train, y_val).
        
    Raises:
        ValueError: If X and y have different lengths.
    """
    if len(X) != len(y):
        raise ValueError(
            f"X and y must have same length. Got X: {len(X)}, y: {len(y)}"
        )
    
    if not 0 < val_size < 1:
        raise ValueError(f"val_size must be between 0 and 1, got {val_size}")
    
    from sklearn.model_selection import train_test_split
    
    stratify_arg = y if stratify else None
    
    try:
        X_train, X_val, y_train, y_val = train_test_split(
            X, y,
            test_size=val_size,
            random_state=random_state,
            stratify=stratify_arg,
        )
    except ValueError as e:
        if stratify and "least populated class" in str(e):
            logger.warning("Stratified split failed, falling back to random split: %s", e)
            X_train, X_val, y_train, y_val = train_test_split(
                X, y,
                test_size=val_size,
                random_state=random_state,
                stratify=None,
            )
        else:
            raise
    
    logger.info("Split data: train=%d, val=%d", len(X_train), len(X_val))
    return X_train, X_val, y_train, y_val
