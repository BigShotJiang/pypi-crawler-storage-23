"""UI components — now handled by static HTML."""
