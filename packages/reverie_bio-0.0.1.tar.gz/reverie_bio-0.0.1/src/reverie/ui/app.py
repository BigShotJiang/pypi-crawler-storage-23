"""Reverie UI — FastAPI backend serving the static HTML interface."""

import asyncio
import json
import logging
import tempfile
from pathlib import Path
from typing import Any, Dict

from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, StreamingResponse

from reverie.ui.utils.validation import validate_data_file, get_data_summary

logger = logging.getLogger(__name__)

STATIC_DIR = Path(__file__).parent / "static"

app = FastAPI(title="Reverie", docs_url=None, redoc_url=None)

_state: Dict[str, Any] = {
    "data_df": None,
    "labels_df": None,
    "model_path": None,
    "results_path": None,
}


@app.get("/", response_class=HTMLResponse)
async def index():
    return HTMLResponse((STATIC_DIR / "app.html").read_text())


def _save_upload(upload: UploadFile) -> str:
    """Write an uploaded file to a temporary path and return that path."""
    try:
        suffix = Path(upload.filename).suffix
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as f:
            f.write(upload.file.read())
            return f.name
    except OSError as e:
        logger.error("Failed to save uploaded file %s: %s", upload.filename, e)
        raise HTTPException(500, f"Failed to save uploaded file: {e}") from e


@app.post("/api/upload/data")
async def upload_data(file: UploadFile = File(...)):
    try:
        path = _save_upload(file)
        is_valid, message, df = validate_data_file(path)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected error processing data upload")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

    if not is_valid or df is None:
        return JSONResponse({"ok": False, "error": message}, status_code=400)

    _state["data_df"] = df
    columns = list(df.columns)

    id_guess = next(
        (c for c in ["subject_id", "patient_id", "id", "sample_id"] if c in columns),
        columns[0] if columns else None,
    )
    label_guess = next(
        (c for c in ["label", "target", "outcome", "y", "class"] if c in columns),
        None,
    )

    preview_rows = df.head(5).fillna("").astype(str).values.tolist()
    summary = get_data_summary(df, id_guess, label_guess) if id_guess else {}

    logger.info("Data uploaded: %s (%d rows, %d cols)", file.filename, len(df), len(columns))

    return {
        "ok": True,
        "filename": file.filename,
        "columns": columns,
        "id_guess": id_guess,
        "label_guess": label_guess,
        "preview": {"headers": columns, "rows": preview_rows},
        "n_rows": len(df),
        "n_cols": len(columns),
        "summary": {
            "n_samples": summary.get("n_samples", len(df)),
            "n_events": summary.get("n_events", len(df)),
            "n_classes": summary.get("n_classes"),
            "balance": summary.get("balance"),
        },
    }


@app.post("/api/upload/labels")
async def upload_labels(file: UploadFile = File(...)):
    try:
        path = _save_upload(file)
        is_valid, message, df = validate_data_file(path)
    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected error processing labels upload")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)

    if not is_valid or df is None:
        return JSONResponse({"ok": False, "error": message}, status_code=400)

    _state["labels_df"] = df
    logger.info("Labels uploaded: %s (%d rows)", file.filename, len(df))

    return {
        "ok": True,
        "filename": file.filename,
        "columns": list(df.columns),
        "n_rows": len(df),
    }


@app.post("/api/summary")
async def recompute_summary(body: dict):
    df = _state.get("data_df")
    if df is None:
        return JSONResponse({"ok": False, "error": "No data uploaded"}, status_code=400)
    id_col = body.get("id_column")
    label_col = body.get("label_column")
    if not id_col or not label_col:
        return JSONResponse(
            {"ok": False, "error": "Both id_column and label_column are required"},
            status_code=400,
        )
    try:
        summary = get_data_summary(df, id_col, label_col)
    except Exception as e:
        logger.exception("Failed to compute summary")
        return JSONResponse({"ok": False, "error": str(e)}, status_code=500)
    return {
        "ok": True,
        "n_samples": summary.get("n_samples", len(df)),
        "n_events": summary.get("n_events", len(df)),
        "n_classes": summary.get("n_classes"),
        "balance": summary.get("balance"),
    }


def _get_classifier_instance(classifier_type: str, task_type: str) -> Any:
    """Return an sklearn-compatible estimator for the given classifier/task type."""
    if task_type == "regression":
        from sklearn.linear_model import Ridge
        return Ridge(alpha=1.0)
    if classifier_type == "logistic_regression":
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression(max_iter=1000)
    elif classifier_type == "random_forest":
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(n_estimators=100, random_state=42)
    elif classifier_type == "svm":
        from sklearn.svm import SVC
        return SVC(probability=True)
    elif classifier_type == "xgboost":
        try:
            from xgboost import XGBClassifier
            return XGBClassifier(n_estimators=100, random_state=42)
        except ImportError:
            logger.warning("xgboost not installed, falling back to GradientBoostingClassifier")
            from sklearn.ensemble import GradientBoostingClassifier
            return GradientBoostingClassifier(n_estimators=100, random_state=42)
    else:
        logger.warning("Unknown classifier type '%s', defaulting to LogisticRegression", classifier_type)
        from sklearn.linear_model import LogisticRegression
        return LogisticRegression(max_iter=1000)


@app.post("/api/train")
async def train(body: dict):
    data_df = _state.get("data_df")
    if data_df is None:
        return JSONResponse({"ok": False, "error": "No data uploaded"}, status_code=400)

    model_id = body.get("model_id", "standard-model")
    id_column = body.get("id_column")
    label_column = body.get("label_column")
    label_source = body.get("label_source", "column")
    task_type = body.get("task_type", "classification")
    val_split = body.get("val_split", 0.2)
    random_seed = int(body.get("random_seed", 42))
    classifier_type = body.get("classifier_type", "logistic_regression")
    stratified = body.get("stratified", True)
    labels_df = _state.get("labels_df")

    q: asyncio.Queue = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def _run():
        def emit(pct, msg, **kw):
            asyncio.run_coroutine_threadsafe(
                q.put({"progress": pct, "message": msg, **kw}), loop,
            )

        try:
            from reverie.data import extract_labels_from_data, align_labels, split_data
            from reverie.train import train_classifier, train_regressor
            from reverie.evaluate import evaluate_classifier, evaluate_regressor

            emit(5, "Validating inputs\u2026")

            if not id_column:
                emit(0, "No ID column selected", error=True)
                return
            if not label_column:
                emit(0, "No label column selected", error=True)
                return

            emit(10, "Preparing data\u2026")

            if label_source == "column":
                labels = extract_labels_from_data(data_df, id_column, label_column)
            else:
                if labels_df is None:
                    emit(0, "No labels file uploaded", error=True)
                    return
                labels = dict(zip(labels_df[id_column], labels_df[label_column]))

            emit(15, "Loading model\u2026")

            if model_id == "standard-model":
                from reverie.models import StandardModel
                model = StandardModel()
            else:
                emit(0, f"Unknown model: {model_id}", error=True)
                return

            model.load()

            emit(20, "Validating data format\u2026")

            try:
                model.validate_data(data_df)
            except ValueError as e:
                emit(0, f"Data validation failed: {e}", error=True)
                return

            sample_ids = model.get_sample_ids(data_df)
            n_samples = len(sample_ids)
            emit(25, f"Generating embeddings (0/{n_samples:,})\u2026")

            X = model.embed(data_df, show_progress=False)

            emit(75, "Aligning labels\u2026")
            y = align_labels(sample_ids, labels)

            emit(80, "Splitting data\u2026")
            use_stratify = stratified and task_type == "classification"
            X_train, X_val, y_train, y_val = split_data(
                X, y,
                val_size=val_split,
                random_state=random_seed,
                stratify=use_stratify,
            )

            emit(85, "Training classifier\u2026")
            clf = _get_classifier_instance(classifier_type, task_type)

            if task_type == "classification":
                trained = train_classifier(X_train, y_train, model=clf)
                train_metrics = evaluate_classifier(trained, X_train, y_train)
                val_metrics = evaluate_classifier(trained, X_val, y_val)
            else:
                trained = train_regressor(X_train, y_train, model=clf)
                train_metrics = evaluate_regressor(trained, X_train, y_train)
                val_metrics = evaluate_regressor(trained, X_val, y_val)

            emit(95, "Saving artifacts\u2026")

            import joblib
            with tempfile.NamedTemporaryFile(delete=False, suffix=".joblib") as f:
                joblib.dump(trained, f)
                _state["model_path"] = f.name

            results_export = {
                "train_metrics": train_metrics,
                "val_metrics": val_metrics,
                "task_type": task_type,
                "n_train_samples": len(y_train),
                "n_val_samples": len(y_val),
            }
            with tempfile.NamedTemporaryFile(delete=False, suffix=".json", mode="w") as f:
                json.dump(results_export, f, indent=2)
                _state["results_path"] = f.name

            emit(
                100, "Complete!",
                done=True,
                train_metrics=train_metrics,
                val_metrics=val_metrics,
            )

        except Exception as e:
            logger.exception("Training failed")
            emit(0, str(e), error=True)

    loop.run_in_executor(None, _run)

    async def generate():
        while True:
            msg = await q.get()
            yield f"data: {json.dumps(msg)}\n\n"
            if msg.get("done") or msg.get("error"):
                break

    return StreamingResponse(generate(), media_type="text/event-stream")


@app.get("/api/download/model")
async def download_model():
    path = _state.get("model_path")
    if not path or not Path(path).exists():
        raise HTTPException(404, "No trained model available")
    return FileResponse(path, filename="reverie_model.joblib")


@app.get("/api/download/results")
async def download_results():
    path = _state.get("results_path")
    if not path or not Path(path).exists():
        raise HTTPException(404, "No results available")
    return FileResponse(path, filename="reverie_results.json")


def create_app() -> FastAPI:
    return app


def launch(
    server_name: str = "127.0.0.1",
    server_port: int = 7860,
    share: bool = False,
    **kwargs,
) -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    if share:
        logger.warning("--share requires Gradio and is not supported. Ignoring.")
    import uvicorn
    uvicorn.run(app, host=server_name, port=server_port)


if __name__ == "__main__":
    launch()
