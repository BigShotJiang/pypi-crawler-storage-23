"""Data validation utilities for the UI."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd


def validate_data_file(
    file_path: str,
    required_columns: Optional[List[str]] = None,
) -> Tuple[bool, str, Optional[pd.DataFrame]]:
    """
    Validate an uploaded data file.
    
    Args:
        file_path: Path to the uploaded file.
        required_columns: List of required column names.
        
    Returns:
        Tuple of (is_valid, message, dataframe or None).
    """
    if not file_path:
        return False, "No file uploaded", None
    
    path = Path(file_path)
    
    # Check file exists
    if not path.exists():
        return False, f"File not found: {path.name}", None
    
    # Check file extension
    suffix = path.suffix.lower()
    if suffix not in (".csv", ".parquet", ".pq", ".tsv"):
        return False, f"Unsupported format: {suffix}. Please upload CSV, TSV, or Parquet.", None
    
    # Try to load the file
    try:
        if suffix == ".csv":
            df = pd.read_csv(path)
        elif suffix == ".tsv":
            df = pd.read_csv(path, sep="\t")
        elif suffix in (".parquet", ".pq"):
            df = pd.read_parquet(path)
        else:
            return False, f"Unsupported format: {suffix}", None
    except Exception as e:
        return False, f"Error reading file: {str(e)}", None
    
    # Check for empty file
    if len(df) == 0:
        return False, "File is empty (no rows)", None
    
    if len(df.columns) == 0:
        return False, "File has no columns", None
    
    # Check required columns
    if required_columns:
        missing = set(required_columns) - set(df.columns)
        if missing:
            return False, f"Missing required columns: {', '.join(sorted(missing))}", df
    
    return True, "File loaded successfully", df


def validate_labels_file(
    file_path: str,
    id_column: Optional[str] = None,
    label_column: Optional[str] = None,
) -> Tuple[bool, str, Optional[pd.DataFrame]]:
    """
    Validate an uploaded labels file.
    
    Args:
        file_path: Path to the uploaded file.
        id_column: Expected ID column name.
        label_column: Expected label column name.
        
    Returns:
        Tuple of (is_valid, message, dataframe or None).
    """
    is_valid, message, df = validate_data_file(file_path)
    
    if not is_valid:
        return is_valid, message, df
    
    if df is None:
        return False, "Failed to load file", None
    
    # Check for ID and label columns if specified
    errors = []
    
    if id_column and id_column not in df.columns:
        errors.append(f"ID column '{id_column}' not found")
    
    if label_column and label_column not in df.columns:
        errors.append(f"Label column '{label_column}' not found")
    
    if errors:
        return False, "; ".join(errors), df
    
    # Check for duplicates in ID column
    if id_column and id_column in df.columns:
        if df[id_column].duplicated().any():
            n_dups = df[id_column].duplicated().sum()
            return False, f"Found {n_dups} duplicate IDs in '{id_column}'", df
    
    # Check for nulls in label column
    if label_column and label_column in df.columns:
        n_nulls = df[label_column].isna().sum()
        if n_nulls > 0:
            return True, f"Warning: {n_nulls} rows have missing labels", df
    
    return True, "Labels file is valid", df


def get_data_summary(
    df: pd.DataFrame,
    id_column: Optional[str] = None,
    label_column: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Generate a summary of the data.
    
    Args:
        df: DataFrame to summarize.
        id_column: Column containing sample IDs.
        label_column: Column containing labels.
        
    Returns:
        Dictionary with summary statistics.
    """
    summary = {
        "n_rows": len(df),
        "n_columns": len(df.columns),
        "columns": list(df.columns),
    }
    
    # Count unique samples if ID column specified
    if id_column and id_column in df.columns:
        summary["n_samples"] = df[id_column].nunique()
        summary["n_events"] = len(df)
    else:
        summary["n_samples"] = len(df)
        summary["n_events"] = len(df)
    
    # Analyze labels if specified
    if label_column and label_column in df.columns:
        labels = df[label_column].dropna()
        unique_labels = labels.unique()
        summary["n_classes"] = len(unique_labels)
        summary["class_labels"] = list(unique_labels)
        
        # Calculate class distribution
        value_counts = labels.value_counts()
        summary["class_distribution"] = value_counts.to_dict()
        
        # Check balance
        if len(unique_labels) > 1:
            min_count = value_counts.min()
            max_count = value_counts.max()
            ratio = min_count / max_count if max_count > 0 else 0
            
            if ratio > 0.8:
                summary["balance"] = "balanced"
            elif ratio > 0.5:
                summary["balance"] = "slightly imbalanced"
            else:
                summary["balance"] = "imbalanced"
        else:
            summary["balance"] = "single class"
    
    return summary


def check_data_label_alignment(
    data_df: pd.DataFrame,
    labels_df: pd.DataFrame,
    data_id_column: str,
    label_id_column: str,
) -> Tuple[int, int, int]:
    """
    Check alignment between data and labels.
    
    Args:
        data_df: Data DataFrame.
        labels_df: Labels DataFrame.
        data_id_column: ID column in data.
        label_id_column: ID column in labels.
        
    Returns:
        Tuple of (matched, data_only, labels_only) counts.
    """
    data_ids = set(data_df[data_id_column].unique())
    label_ids = set(labels_df[label_id_column].unique())
    
    matched = len(data_ids & label_ids)
    data_only = len(data_ids - label_ids)
    labels_only = len(label_ids - data_ids)
    
    return matched, data_only, labels_only

