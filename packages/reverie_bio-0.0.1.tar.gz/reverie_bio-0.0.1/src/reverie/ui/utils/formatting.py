"""Formatting utilities for the UI."""

from typing import Dict, Any


def format_metrics(metrics: Dict[str, float], precision: int = 3) -> str:
    """
    Format metrics dictionary as a readable string.
    
    Args:
        metrics: Dictionary of metric names to values.
        precision: Number of decimal places.
        
    Returns:
        Formatted string.
    """
    lines = []
    for name, value in metrics.items():
        formatted_name = name.replace("_", " ").title()
        lines.append(f"**{formatted_name}:** {value:.{precision}f}")
    return "\n".join(lines)


def format_number(n: int) -> str:
    """
    Format a number with commas for readability.
    
    Args:
        n: Integer to format.
        
    Returns:
        Formatted string (e.g., "1,234,567").
    """
    return f"{n:,}"


def format_duration(seconds: float) -> str:
    """
    Format a duration in seconds to a human-readable string.
    
    Args:
        seconds: Duration in seconds.
        
    Returns:
        Formatted string (e.g., "2m 30s" or "1.5s").
    """
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{minutes}m {secs}s"
    else:
        hours = int(seconds // 3600)
        minutes = int((seconds % 3600) // 60)
        return f"{hours}h {minutes}m"


def format_class_distribution(distribution: Dict[Any, int]) -> str:
    """
    Format class distribution as a readable string.
    
    Args:
        distribution: Dictionary of class labels to counts.
        
    Returns:
        Formatted string with percentages.
    """
    total = sum(distribution.values())
    if total == 0:
        return "No samples"
    
    parts = []
    for label, count in sorted(distribution.items(), key=lambda x: -x[1]):
        pct = (count / total) * 100
        parts.append(f"Class {label}: {count:,} ({pct:.1f}%)")
    
    return " | ".join(parts)


def create_progress_message(step: str, current: int = 0, total: int = 0) -> str:
    """
    Create a progress message for the UI.
    
    Args:
        step: Current step description.
        current: Current progress count.
        total: Total count.
        
    Returns:
        Formatted progress message.
    """
    if total > 0:
        pct = (current / total) * 100
        return f"⏳ {step}... ({current}/{total}, {pct:.0f}%)"
    return f"⏳ {step}..."

