"""Train classifiers and regressors on embeddings."""

import logging
from typing import Any, Optional

import numpy as np

logger = logging.getLogger(__name__)


def train_classifier(
    X: np.ndarray,
    y: np.ndarray,
    model: Optional[Any] = None,
) -> Any:
    """
    Train a classifier on embeddings.
    
    Args:
        X: Feature matrix (embeddings), shape (n_samples, n_features).
        y: Labels, shape (n_samples,).
        model: sklearn-compatible classifier. If None, uses LogisticRegression.
        
    Returns:
        Trained classifier.
        
    Example:
        >>> model = train_classifier(X_train, y_train)
        >>> predictions = model.predict(X_test)
        
        >>> # With custom model
        >>> from sklearn.ensemble import RandomForestClassifier
        >>> model = train_classifier(X_train, y_train, model=RandomForestClassifier())
    """
    if model is None:
        from sklearn.linear_model import LogisticRegression
        model = LogisticRegression(max_iter=1000)
    
    _validate_training_inputs(X, y)
    logger.info("Training classifier %s on %d samples", type(model).__name__, len(X))
    model.fit(X, y)
    return model


def train_regressor(
    X: np.ndarray,
    y: np.ndarray,
    model: Optional[Any] = None,
) -> Any:
    """
    Train a regressor on embeddings.
    
    Args:
        X: Feature matrix (embeddings), shape (n_samples, n_features).
        y: Target values, shape (n_samples,).
        model: sklearn-compatible regressor. If None, uses Ridge.
        
    Returns:
        Trained regressor.
        
    Example:
        >>> model = train_regressor(X_train, y_train)
        >>> predictions = model.predict(X_test)
    """
    if model is None:
        from sklearn.linear_model import Ridge
        model = Ridge(alpha=1.0)
    
    _validate_training_inputs(X, y)
    logger.info("Training regressor %s on %d samples", type(model).__name__, len(X))
    model.fit(X, y)
    return model


def _validate_training_inputs(X: np.ndarray, y: np.ndarray) -> None:
    """
    Validate training inputs.
    
    Args:
        X: Feature matrix.
        y: Labels/targets.
        
    Raises:
        ValueError: If inputs are invalid.
    """
    if not isinstance(X, np.ndarray):
        raise ValueError(f"X must be numpy array, got {type(X).__name__}")
    
    if not isinstance(y, np.ndarray):
        raise ValueError(f"y must be numpy array, got {type(y).__name__}")
    
    if X.ndim != 2:
        raise ValueError(f"X must be 2D array, got {X.ndim}D")
    
    if y.ndim != 1:
        raise ValueError(f"y must be 1D array, got {y.ndim}D")
    
    if len(X) != len(y):
        raise ValueError(
            f"X and y must have same number of samples. "
            f"Got X: {len(X)}, y: {len(y)}"
        )
    
    if len(X) == 0:
        raise ValueError("Cannot train on empty data")
