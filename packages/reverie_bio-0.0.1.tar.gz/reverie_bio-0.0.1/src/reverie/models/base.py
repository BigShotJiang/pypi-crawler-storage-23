"""Abstract base class for foundation models."""

from abc import ABC, abstractmethod

import numpy as np
import pandas as pd


class BaseModel(ABC):
    """
    Abstract base class that all foundation models must implement.
    
    The workflow is:
        1. model.load() - load weights into memory
        2. model.validate_data(df) - check data format
        3. sample_ids = model.get_sample_ids(df) - get sample identifiers
        4. embeddings = model.embed(df) - generate embeddings
    
    Embeddings are returned in the same order as sample_ids, allowing
    the caller to join embeddings with labels.
    """

    @abstractmethod
    def load(self) -> None:
        """
        Load model weights into memory.
        
        This is separated from __init__ so users can instantiate
        the model class without immediately loading heavy weights.
        
        Raises:
            RuntimeError: If model fails to load.
        """
        pass

    @abstractmethod
    def validate_data(self, df: pd.DataFrame) -> None:
        """
        Validate that the dataframe has the required format.
        
        Each model has different requirements:
            - Standard Model: requires 'subject_id', 'time', 'code' columns
            - ESM: requires 'sequence' column
        
        Args:
            df: Input dataframe to validate.
            
        Raises:
            ValueError: If required columns are missing or data is invalid.
        """
        pass

    @abstractmethod
    def get_sample_ids(self, df: pd.DataFrame) -> np.ndarray:
        """
        Return unique sample identifiers.
        
        The returned IDs correspond to the rows of the embedding matrix
        that embed() will return. This allows callers to join embeddings
        with labels.
        
        For Standard Model: returns unique subject_ids
        For ESM: returns row indices or sequence_id column
        
        Args:
            df: Input dataframe.
            
        Returns:
            Array of sample identifiers, shape (n_samples,).
        """
        pass

    @abstractmethod
    def embed(self, df: pd.DataFrame) -> np.ndarray:
        """
        Generate embeddings for all samples in the dataframe.
        
        Args:
            df: Input dataframe (must pass validate_data first).
            
        Returns:
            Embedding matrix, shape (n_samples, embedding_dim).
            Rows correspond to sample IDs from get_sample_ids().
            
        Raises:
            RuntimeError: If model hasn't been loaded yet.
        """
        pass

    @property
    @abstractmethod
    def embedding_dim(self) -> int:
        """
        Dimension of the embedding vectors.
        
        Returns:
            Integer dimension (e.g., 1536 for Standard Model).
        """
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """
        Human-readable name of the model.
        
        Returns:
            Model name (e.g., "Standard Model", "ESM-2").
        """
        pass

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(name='{self.name}')"
