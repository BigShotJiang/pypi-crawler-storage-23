"""Standard Model Bio foundation model wrapper."""

import logging
from datetime import datetime
from typing import Any, Optional

import numpy as np
import pandas as pd

from reverie.models.base import BaseModel

logger = logging.getLogger(__name__)


class StandardModel(BaseModel):
    """
    Wrapper for Standard Model Bio (smb-v1-1.7b).
    
    Standard Model is a foundation model for electronic health records (EHR).
    It takes MEDS-formatted patient data and produces embeddings that capture
    the patient's clinical trajectory.
    
    Expected data format (MEDS):
        - subject_id: Patient identifier
        - time: Timestamp of clinical event
        - code: Clinical code (ICD-10, RxNorm, LOINC, etc.)
    
    Example:
        >>> model = StandardModel()
        >>> model.load()
        >>> embeddings = model.embed(df)
    
    Reference:
        https://docs.standardmodel.bio/
    """

    MODEL_ID = "standardmodelbio/smb-v1-1.7b"
    EMBEDDING_DIM = 1536
    REQUIRED_COLUMNS = {"subject_id", "time", "code"}

    def __init__(
        self,
        device: Optional[str] = None,
        torch_dtype: Optional[Any] = None,
        max_length: int = 4096,
    ):
        """
        Initialize Standard Model wrapper.
        
        Args:
            device: Device to load model on. None for auto-detect.
            torch_dtype: Data type for model weights. Can be:
                         - None: auto-detect
                         - torch.float16 or torch.float32
                         - "float16", "float32", "auto"
            max_length: Maximum sequence length for tokenization.
        """
        self.device = device
        self.torch_dtype = torch_dtype
        self._torch_dtype_input = torch_dtype
        self.max_length = max_length
        
        self._model = None
        self._tokenizer = None
        self._process_ehr_info = None

    def load(self) -> None:
        """
        Load model weights and tokenizer.
        
        Raises:
            RuntimeError: If model fails to load.
            ImportError: If required dependencies are not installed.
        """
        try:
            from transformers import AutoModelForCausalLM, AutoTokenizer
        except ImportError as e:
            raise ImportError(
                "transformers is required for Standard Model. "
                "Install with: pip install transformers"
            ) from e

        try:
            from smb_utils import process_ehr_info
            self._process_ehr_info = process_ehr_info
        except ImportError as e:
            raise ImportError(
                "smb-utils is required for Standard Model. "
                "Install with: pip install git+https://github.com/standardmodelbio/smb-utils.git"
            ) from e

        # Load tokenizer
        self._tokenizer = AutoTokenizer.from_pretrained(self.MODEL_ID)

        # Handle torch_dtype conversion
        import torch
        torch_dtype = None
        if self._torch_dtype_input is not None:
            if isinstance(self._torch_dtype_input, str):
                dtype_map = {
                    "float16": torch.float16,
                    "float32": torch.float32,
                    "bfloat16": torch.bfloat16,
                    "auto": "auto",
                }
                torch_dtype = dtype_map.get(self._torch_dtype_input, self._torch_dtype_input)
            else:
                torch_dtype = self._torch_dtype_input

        # Build model loading kwargs
        model_kwargs = {
            "trust_remote_code": True,
            "device_map": "auto" if self.device is None else None,
        }
        if torch_dtype is not None:
            model_kwargs["torch_dtype"] = torch_dtype
        
        logger.info("Loading model %s", self.MODEL_ID)
        self._model = AutoModelForCausalLM.from_pretrained(
            self.MODEL_ID,
            **model_kwargs,
        )
        
        if self.device is not None:
            self._model = self._model.to(self.device)
        
        self._model.eval()
        logger.info("Model loaded successfully")

    def validate_data(self, df: pd.DataFrame) -> None:
        """
        Validate that dataframe has required MEDS columns.
        
        Args:
            df: Input dataframe.
            
        Raises:
            ValueError: If required columns are missing or data is invalid.
        """
        if not isinstance(df, pd.DataFrame):
            raise ValueError(f"Expected pandas DataFrame, got {type(df).__name__}")
        
        missing = self.REQUIRED_COLUMNS - set(df.columns)
        if missing:
            raise ValueError(
                f"Missing required columns: {missing}. "
                f"Expected MEDS format with columns: {self.REQUIRED_COLUMNS}"
            )
        
        # Check for empty dataframe
        if len(df) == 0:
            raise ValueError("DataFrame is empty")
        
        # Check subject_id is not all null
        if df["subject_id"].isna().all():
            raise ValueError("All subject_id values are null")
        
        # Check time column is datetime-like
        if not pd.api.types.is_datetime64_any_dtype(df["time"]):
            # Try to convert
            try:
                pd.to_datetime(df["time"])
            except Exception:
                raise ValueError(
                    "Column 'time' must be datetime or convertible to datetime"
                )

    def get_sample_ids(self, df: pd.DataFrame) -> np.ndarray:
        """
        Return unique patient IDs.
        
        Args:
            df: Input dataframe with 'subject_id' column.
            
        Returns:
            Array of unique subject IDs in sorted order.
        """
        # Get unique subject IDs, excluding nulls
        unique_ids = df["subject_id"].dropna().unique()
        # Sort for deterministic ordering
        return np.sort(unique_ids)

    def embed(
        self,
        df: pd.DataFrame,
        end_time: Optional[datetime] = None,
        show_progress: bool = True,
    ) -> np.ndarray:
        """
        Generate embeddings for all patients in the dataframe.
        
        Args:
            df: Input dataframe in MEDS format.
            end_time: Cutoff time for causal masking. Events after this
                      time are not visible to the model. If None, uses
                      each patient's maximum timestamp.
            show_progress: Whether to show progress bar.
            
        Returns:
            Embedding matrix, shape (n_patients, 1536).
            Rows correspond to patient IDs from get_sample_ids().
            
        Raises:
            RuntimeError: If model hasn't been loaded.
        """
        if self._model is None:
            raise RuntimeError(
                "Model not loaded. Call load() before embed()."
            )
        
        # Validate data
        self.validate_data(df)
        
        # Ensure time column is datetime
        df = df.copy()
        if not pd.api.types.is_datetime64_any_dtype(df["time"]):
            df["time"] = pd.to_datetime(df["time"])
        
        patient_ids = self.get_sample_ids(df)
        logger.info("Embedding %d patients", len(patient_ids))
        
        # Set up progress bar if requested
        if show_progress:
            try:
                from tqdm import tqdm
                iterator = tqdm(patient_ids, desc="Embedding patients")
            except ImportError:
                iterator = patient_ids
        else:
            iterator = patient_ids
        
        embeddings = []
        
        import torch
        
        for pid in iterator:
            # Determine end_time for this patient
            if end_time is not None:
                patient_end_time = end_time
            else:
                # Use patient's max timestamp
                patient_data = df[df["subject_id"] == pid]
                patient_end_time = patient_data["time"].max()
            
            # Serialize patient history to text
            text = self._process_ehr_info(
                df,
                subject_id=pid,
                end_time=patient_end_time,
            )
            
            # Tokenize
            inputs = self._tokenizer(
                text,
                return_tensors="pt",
                truncation=True,
                max_length=self.max_length,
            ).to(self._model.device)
            
            # Get embeddings via last token pooling
            with torch.no_grad():
                outputs = self._model(
                    inputs.input_ids,
                    output_hidden_states=True,
                )
                # Extract last token from last hidden layer
                last_hidden = outputs.hidden_states[-1]  # (1, seq_len, hidden_dim)
                embedding = last_hidden[:, -1, :]  # (1, hidden_dim)
                embeddings.append(embedding.cpu())
        
        # Stack into matrix and convert to float32 (NumPy doesn't support BFloat16)
        embeddings = torch.cat(embeddings, dim=0).float().numpy()
        
        return embeddings

    @property
    def embedding_dim(self) -> int:
        """Return embedding dimension (1536 for Standard Model)."""
        return self.EMBEDDING_DIM

    @property
    def name(self) -> str:
        """Return model name."""
        return "Standard Model"
    
    @property
    def is_loaded(self) -> bool:
        """Check if model weights are loaded."""
        return self._model is not None
