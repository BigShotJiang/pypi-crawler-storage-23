"""Command-line interface for Reverie."""

import argparse
import logging
import sys
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def main(args: Optional[list] = None) -> int:
    """
    Main entry point for the CLI.
    
    Args:
        args: Command-line arguments (defaults to sys.argv[1:]).
        
    Returns:
        Exit code (0 for success, non-zero for failure).
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    parser = create_parser()
    parsed = parser.parse_args(args)
    
    if not hasattr(parsed, "func"):
        parser.print_help()
        return 1
    
    try:
        return parsed.func(parsed)
    except Exception as e:
        logger.error("%s", e)
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create the argument parser."""
    parser = argparse.ArgumentParser(
        prog="reverie",
        description="Fine-tune foundation models for life sciences.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {_get_version()}",
    )
    
    subparsers = parser.add_subparsers(title="commands")
    
    # Train command
    train_parser = subparsers.add_parser(
        "train",
        help="Train a classifier on foundation model embeddings.",
    )
    train_parser.add_argument(
        "--model",
        type=str,
        default="standard-model",
        choices=["standard-model"],
        help="Foundation model to use (default: standard-model).",
    )
    train_parser.add_argument(
        "--data",
        type=str,
        required=True,
        help="Path to data file (CSV or Parquet).",
    )
    train_parser.add_argument(
        "--labels",
        type=str,
        required=True,
        help="Path to labels file (CSV or Parquet).",
    )
    train_parser.add_argument(
        "--id-column",
        type=str,
        default="subject_id",
        help="Column name for sample IDs (default: subject_id).",
    )
    train_parser.add_argument(
        "--label-column",
        type=str,
        default="label",
        help="Column name for labels (default: label).",
    )
    train_parser.add_argument(
        "--task",
        type=str,
        default="classification",
        choices=["classification", "regression"],
        help="Task type (default: classification).",
    )
    train_parser.add_argument(
        "--val-size",
        type=float,
        default=0.2,
        help="Fraction of data for validation (default: 0.2).",
    )
    train_parser.add_argument(
        "--output",
        type=str,
        default="./output",
        help="Output directory for results (default: ./output).",
    )
    train_parser.add_argument(
        "--seed",
        type=int,
        default=42,
        help="Random seed (default: 42).",
    )
    train_parser.set_defaults(func=cmd_train)
    
    # UI command
    ui_parser = subparsers.add_parser(
        "ui",
        help="Launch the web UI for fine-tuning models.",
    )
    ui_parser.add_argument(
        "--port",
        type=int,
        default=7860,
        help="Port to run the server on (default: 7860).",
    )
    ui_parser.add_argument(
        "--share",
        action="store_true",
        help="Create a public share link.",
    )
    ui_parser.add_argument(
        "--host",
        type=str,
        default="127.0.0.1",
        help="Host to bind to (default: 127.0.0.1).",
    )
    ui_parser.set_defaults(func=cmd_ui)
    
    return parser


def cmd_train(args: argparse.Namespace) -> int:
    """
    Execute the train command.
    
    Args:
        args: Parsed command-line arguments.
        
    Returns:
        Exit code.
    """
    import numpy as np
    
    from reverie.data import load_data, load_labels, align_labels, split_data
    from reverie.train import train_classifier, train_regressor
    from reverie.evaluate import evaluate_classifier, evaluate_regressor, print_metrics
    
    # Set random seed
    np.random.seed(args.seed)
    
    # Create output directory
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Loading data from {args.data}...")
    data = load_data(args.data)
    
    print(f"Loading labels from {args.labels}...")
    labels = load_labels(
        args.labels,
        id_column=args.id_column,
        label_column=args.label_column,
    )
    
    print(f"Loading {args.model}...")
    model = _get_model(args.model)
    model.load()
    
    print(f"Generating embeddings for {len(model.get_sample_ids(data))} samples...")
    X = model.embed(data)
    
    sample_ids = model.get_sample_ids(data)
    y = align_labels(sample_ids, labels)
    
    print(f"Splitting data (val_size={args.val_size})...")
    stratify = args.task == "classification"
    X_train, X_val, y_train, y_val = split_data(
        X, y,
        val_size=args.val_size,
        random_state=args.seed,
        stratify=stratify,
    )
    
    print(f"Training {args.task} model...")
    if args.task == "classification":
        classifier = train_classifier(X_train, y_train)
        
        print()
        print_metrics(
            evaluate_classifier(classifier, X_train, y_train),
            title="Training Metrics",
        )
        print()
        print_metrics(
            evaluate_classifier(classifier, X_val, y_val),
            title="Validation Metrics",
        )
    else:
        regressor = train_regressor(X_train, y_train)
        
        print()
        print_metrics(
            evaluate_regressor(regressor, X_train, y_train),
            title="Training Metrics",
        )
        print()
        print_metrics(
            evaluate_regressor(regressor, X_val, y_val),
            title="Validation Metrics",
        )
    
    # Save embeddings
    embeddings_path = output_dir / "embeddings.npy"
    np.save(embeddings_path, X)
    print(f"\nEmbeddings saved to {embeddings_path}")
    
    print("\nDone!")
    return 0


def cmd_ui(args: argparse.Namespace) -> int:
    """
    Execute the ui command.
    
    Args:
        args: Parsed command-line arguments.
        
    Returns:
        Exit code.
    """
    try:
        from reverie.ui import launch
    except ImportError:
        print(
            "UI dependencies not installed. Install with:\n"
            "  pip install reverie[ui]",
            file=sys.stderr,
        )
        return 1
    
    print(f"🌙 Launching Reverie UI at http://{args.host}:{args.port}")
    launch(
        server_name=args.host,
        server_port=args.port,
        share=args.share,
    )
    return 0


def _get_model(name: str):
    """Get a model instance by name."""
    if name == "standard-model":
        from reverie.models import StandardModel
        return StandardModel()
    else:
        raise ValueError(f"Unknown model: {name}")


def _get_version() -> str:
    """Get the package version."""
    try:
        from reverie import __version__
        return __version__
    except ImportError:
        return "unknown"


if __name__ == "__main__":
    sys.exit(main())
