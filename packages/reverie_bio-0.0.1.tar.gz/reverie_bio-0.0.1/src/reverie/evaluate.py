"""Evaluation metrics for classification and regression."""

import logging
from typing import Any, Dict, Optional

import numpy as np

logger = logging.getLogger(__name__)


def evaluate_classifier(
    model: Any,
    X: np.ndarray,
    y: np.ndarray,
) -> Dict[str, float]:
    """
    Evaluate a classifier and return metrics.
    
    Args:
        model: Trained classifier with predict() and optionally predict_proba().
        X: Feature matrix, shape (n_samples, n_features).
        y: True labels, shape (n_samples,).
        
    Returns:
        Dictionary of metrics:
            - accuracy: Overall accuracy
            - f1_macro: Macro-averaged F1 score
            - f1_weighted: Weighted F1 score
            - roc_auc: ROC AUC (only for binary classification with predict_proba)
            
    Example:
        >>> metrics = evaluate_classifier(model, X_test, y_test)
        >>> print(f"Accuracy: {metrics['accuracy']:.3f}")
    """
    from sklearn.metrics import (
        accuracy_score,
        f1_score,
        roc_auc_score,
    )
    
    y_pred = model.predict(X)
    
    metrics = {
        "accuracy": accuracy_score(y, y_pred),
        "f1_macro": f1_score(y, y_pred, average="macro", zero_division=0),
        "f1_weighted": f1_score(y, y_pred, average="weighted", zero_division=0),
    }
    
    # ROC AUC for binary classification
    n_classes = len(np.unique(y))
    if n_classes == 2 and hasattr(model, "predict_proba"):
        try:
            y_prob = model.predict_proba(X)[:, 1]
            metrics["roc_auc"] = roc_auc_score(y, y_prob)
        except Exception:
            logger.debug("Could not compute ROC AUC (predict_proba unavailable or failed)")
    
    return metrics


def evaluate_regressor(
    model: Any,
    X: np.ndarray,
    y: np.ndarray,
) -> Dict[str, float]:
    """
    Evaluate a regressor and return metrics.
    
    Args:
        model: Trained regressor with predict().
        X: Feature matrix, shape (n_samples, n_features).
        y: True target values, shape (n_samples,).
        
    Returns:
        Dictionary of metrics:
            - mse: Mean squared error
            - rmse: Root mean squared error
            - mae: Mean absolute error
            - r2: R-squared (coefficient of determination)
            
    Example:
        >>> metrics = evaluate_regressor(model, X_test, y_test)
        >>> print(f"MAE: {metrics['mae']:.3f}")
    """
    from sklearn.metrics import (
        mean_squared_error,
        mean_absolute_error,
        r2_score,
    )
    
    y_pred = model.predict(X)
    
    mse = mean_squared_error(y, y_pred)
    
    metrics = {
        "mse": mse,
        "rmse": np.sqrt(mse),
        "mae": mean_absolute_error(y, y_pred),
        "r2": r2_score(y, y_pred),
    }
    
    return metrics


def print_metrics(
    metrics: Dict[str, float],
    title: Optional[str] = None,
) -> None:
    """
    Print metrics in a formatted way.
    
    Args:
        metrics: Dictionary of metric names to values.
        title: Optional title to print above metrics.
        
    Example:
        >>> print_metrics(metrics, title="Validation Results")
        Validation Results
        ------------------
        accuracy: 0.850
        f1_macro: 0.842
    """
    if title:
        print(title)
        print("-" * len(title))
    
    for name, value in metrics.items():
        print(f"{name}: {value:.4f}")
