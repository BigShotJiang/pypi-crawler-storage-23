"""Tests for CLI."""

import pytest

from reverie.cli import main, create_parser


class TestParser:
    """Tests for argument parsing."""

    def test_train_required_args(self):
        """Train requires --data and --labels."""
        parser = create_parser()
        
        with pytest.raises(SystemExit):
            parser.parse_args(["train"])

    def test_train_with_required_args(self):
        """Train parses with required args."""
        parser = create_parser()
        args = parser.parse_args([
            "train",
            "--data", "data.csv",
            "--labels", "labels.csv",
        ])
        
        assert args.data == "data.csv"
        assert args.labels == "labels.csv"

    def test_train_defaults(self):
        """Train has correct defaults."""
        parser = create_parser()
        args = parser.parse_args([
            "train",
            "--data", "data.csv",
            "--labels", "labels.csv",
        ])
        
        assert args.model == "standard-model"
        assert args.task == "classification"
        assert args.val_size == 0.2
        assert args.id_column == "subject_id"
        assert args.label_column == "label"
        assert args.seed == 42

    def test_train_custom_args(self):
        """Train accepts custom args."""
        parser = create_parser()
        args = parser.parse_args([
            "train",
            "--data", "patients.parquet",
            "--labels", "outcomes.csv",
            "--task", "regression",
            "--val-size", "0.3",
            "--id-column", "patient_id",
            "--label-column", "outcome",
            "--seed", "123",
        ])
        
        assert args.data == "patients.parquet"
        assert args.task == "regression"
        assert args.val_size == 0.3
        assert args.id_column == "patient_id"
        assert args.label_column == "outcome"
        assert args.seed == 123


class TestMain:
    """Tests for main function."""

    def test_no_args_returns_1(self):
        """No arguments returns exit code 1."""
        result = main([])
        assert result == 1

    def test_help_exits_0(self):
        """--help exits with code 0."""
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0
