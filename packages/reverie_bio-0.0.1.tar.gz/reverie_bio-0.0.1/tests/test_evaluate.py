"""Tests for evaluation module."""

import numpy as np
import pytest

from reverie.evaluate import evaluate_classifier, evaluate_regressor, print_metrics


class TestEvaluateClassifier:
    """Tests for evaluate_classifier function."""

    def test_binary_classification_metrics(self):
        """Returns correct metrics for binary classification."""
        from sklearn.linear_model import LogisticRegression
        
        # Create simple separable data
        np.random.seed(42)
        X = np.vstack([
            np.random.randn(50, 10) + 2,
            np.random.randn(50, 10) - 2,
        ])
        y = np.array([0] * 50 + [1] * 50)
        
        model = LogisticRegression()
        model.fit(X, y)
        
        metrics = evaluate_classifier(model, X, y)
        
        assert "accuracy" in metrics
        assert "f1_macro" in metrics
        assert "f1_weighted" in metrics
        assert "roc_auc" in metrics
        
        # Should have near-perfect performance on separable data
        assert metrics["accuracy"] > 0.9
        assert metrics["roc_auc"] > 0.9

    def test_multiclass_classification_metrics(self):
        """Returns correct metrics for multiclass classification."""
        from sklearn.linear_model import LogisticRegression
        
        np.random.seed(42)
        X = np.vstack([
            np.random.randn(50, 10) + np.array([2, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
            np.random.randn(50, 10) + np.array([0, 2, 0, 0, 0, 0, 0, 0, 0, 0]),
            np.random.randn(50, 10) + np.array([0, 0, 2, 0, 0, 0, 0, 0, 0, 0]),
        ])
        y = np.array([0] * 50 + [1] * 50 + [2] * 50)
        
        model = LogisticRegression(max_iter=1000)
        model.fit(X, y)
        
        metrics = evaluate_classifier(model, X, y)
        
        assert "accuracy" in metrics
        assert "f1_macro" in metrics
        assert "f1_weighted" in metrics
        # ROC AUC not computed for multiclass
        assert "roc_auc" not in metrics

    def test_metrics_values_in_range(self):
        """Metrics are in valid ranges."""
        from sklearn.linear_model import LogisticRegression
        
        np.random.seed(42)
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        model = LogisticRegression()
        model.fit(X, y)
        
        metrics = evaluate_classifier(model, X, y)
        
        assert 0 <= metrics["accuracy"] <= 1
        assert 0 <= metrics["f1_macro"] <= 1
        assert 0 <= metrics["f1_weighted"] <= 1


class TestEvaluateRegressor:
    """Tests for evaluate_regressor function."""

    def test_regression_metrics(self):
        """Returns correct metrics for regression."""
        from sklearn.linear_model import Ridge
        
        np.random.seed(42)
        X = np.random.randn(100, 10)
        y = X[:, 0] * 2 + X[:, 1] * 3 + np.random.randn(100) * 0.1
        
        model = Ridge()
        model.fit(X, y)
        
        metrics = evaluate_regressor(model, X, y)
        
        assert "mse" in metrics
        assert "rmse" in metrics
        assert "mae" in metrics
        assert "r2" in metrics
        
        # RMSE should be sqrt of MSE
        assert np.isclose(metrics["rmse"], np.sqrt(metrics["mse"]))
        
        # Should have good fit on this data
        assert metrics["r2"] > 0.9

    def test_metrics_values_valid(self):
        """Metrics have valid values."""
        from sklearn.linear_model import Ridge
        
        np.random.seed(42)
        X = np.random.randn(100, 10)
        y = np.random.randn(100)
        
        model = Ridge()
        model.fit(X, y)
        
        metrics = evaluate_regressor(model, X, y)
        
        assert metrics["mse"] >= 0
        assert metrics["rmse"] >= 0
        assert metrics["mae"] >= 0
        # R2 can be negative for bad models


class TestPrintMetrics:
    """Tests for print_metrics function."""

    def test_print_with_title(self, capsys):
        """Prints metrics with title."""
        metrics = {"accuracy": 0.85, "f1": 0.82}
        print_metrics(metrics, title="Results")
        
        captured = capsys.readouterr()
        assert "Results" in captured.out
        assert "accuracy" in captured.out
        assert "0.8500" in captured.out

    def test_print_without_title(self, capsys):
        """Prints metrics without title."""
        metrics = {"mae": 1.5}
        print_metrics(metrics)
        
        captured = capsys.readouterr()
        assert "mae" in captured.out
        assert "1.5000" in captured.out
