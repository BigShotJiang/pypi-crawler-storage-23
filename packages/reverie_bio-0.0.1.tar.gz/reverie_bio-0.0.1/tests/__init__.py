"""Tests for reverie."""
