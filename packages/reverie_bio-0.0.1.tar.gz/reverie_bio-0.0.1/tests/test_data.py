"""Tests for data loading and preprocessing."""

from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from reverie.data import (
    load_data,
    load_labels,
    extract_labels_from_data,
    align_labels,
    split_data,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures"


class TestLoadData:
    """Tests for load_data function."""

    def test_load_csv(self):
        """Can load CSV file."""
        df = load_data(FIXTURES_DIR / "sample_data.csv")
        assert isinstance(df, pd.DataFrame)
        assert len(df) == 6
        assert "subject_id" in df.columns

    def test_load_nonexistent_raises(self):
        """Non-existent file raises FileNotFoundError."""
        with pytest.raises(FileNotFoundError):
            load_data(FIXTURES_DIR / "does_not_exist.csv")

    def test_load_unsupported_format_raises(self):
        """Unsupported file format raises ValueError."""
        # Create a temp file with wrong extension
        tmp_file = FIXTURES_DIR / "test.xyz"
        tmp_file.write_text("test")
        try:
            with pytest.raises(ValueError, match="Unsupported"):
                load_data(tmp_file)
        finally:
            tmp_file.unlink()


class TestLoadLabels:
    """Tests for load_labels function."""

    def test_load_labels(self):
        """Can load labels from CSV."""
        labels = load_labels(
            FIXTURES_DIR / "sample_labels.csv",
            id_column="subject_id",
            label_column="outcome",
        )
        assert isinstance(labels, dict)
        assert len(labels) == 3
        assert labels["p1"] == 1
        assert labels["p2"] == 0
        assert labels["p3"] == 1

    def test_missing_id_column_raises(self):
        """Missing ID column raises ValueError."""
        with pytest.raises(ValueError, match="wrong_column"):
            load_labels(
                FIXTURES_DIR / "sample_labels.csv",
                id_column="wrong_column",
                label_column="outcome",
            )

    def test_missing_label_column_raises(self):
        """Missing label column raises ValueError."""
        with pytest.raises(ValueError, match="wrong_column"):
            load_labels(
                FIXTURES_DIR / "sample_labels.csv",
                id_column="subject_id",
                label_column="wrong_column",
            )


class TestExtractLabelsFromData:
    """Tests for extract_labels_from_data function."""

    def test_extract_labels(self):
        """Can extract labels from data file."""
        df = load_data(FIXTURES_DIR / "sample_data_with_labels.csv")
        labels = extract_labels_from_data(
            df,
            id_column="subject_id",
            label_column="label",
        )
        assert isinstance(labels, dict)
        assert len(labels) == 3
        assert labels["p1"] == 1
        assert labels["p2"] == 0
        assert labels["p3"] == 1

    def test_inconsistent_labels_raises(self):
        """Inconsistent labels for same ID raises ValueError."""
        df = pd.DataFrame({
            "subject_id": ["p1", "p1"],
            "label": [0, 1],  # Different labels for same ID
        })
        with pytest.raises(ValueError, match="Inconsistent"):
            extract_labels_from_data(df, id_column="subject_id", label_column="label")

    def test_missing_column_raises(self):
        """Missing column raises ValueError."""
        df = pd.DataFrame({"subject_id": ["p1"], "other": [1]})
        with pytest.raises(ValueError, match="label"):
            extract_labels_from_data(df, id_column="subject_id", label_column="label")


class TestAlignLabels:
    """Tests for align_labels function."""

    def test_align_labels_correct_order(self):
        """Labels are aligned to sample ID order."""
        sample_ids = np.array(["p2", "p1", "p3"])
        labels = {"p1": 1, "p2": 0, "p3": 2}
        
        aligned = align_labels(sample_ids, labels)
        
        assert list(aligned) == [0, 1, 2]  # Order matches sample_ids

    def test_missing_label_raises(self):
        """Missing label raises ValueError."""
        sample_ids = np.array(["p1", "p2", "p_missing"])
        labels = {"p1": 1, "p2": 0}
        
        with pytest.raises(ValueError, match="Missing labels"):
            align_labels(sample_ids, labels)

    def test_extra_labels_ok(self):
        """Extra labels in dict are ignored."""
        sample_ids = np.array(["p1", "p2"])
        labels = {"p1": 1, "p2": 0, "p3": 2, "p4": 3}  # Extra labels
        
        aligned = align_labels(sample_ids, labels)
        assert len(aligned) == 2


class TestSplitData:
    """Tests for split_data function."""

    def test_split_sizes(self):
        """Split produces correct sizes."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        X_train, X_val, y_train, y_val = split_data(
            X, y, val_size=0.2, random_state=42
        )
        
        assert len(X_train) == 80
        assert len(X_val) == 20
        assert len(y_train) == 80
        assert len(y_val) == 20

    def test_split_reproducible(self):
        """Same random_state produces same split."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        X_train1, _, _, _ = split_data(X, y, val_size=0.2, random_state=42)
        X_train2, _, _, _ = split_data(X, y, val_size=0.2, random_state=42)
        
        assert np.array_equal(X_train1, X_train2)

    def test_split_different_without_seed(self):
        """Different random_state produces different split."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        X_train1, _, _, _ = split_data(X, y, val_size=0.2, random_state=42)
        X_train2, _, _, _ = split_data(X, y, val_size=0.2, random_state=123)
        
        assert not np.array_equal(X_train1, X_train2)

    def test_mismatched_lengths_raises(self):
        """Mismatched X and y lengths raise ValueError."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 40)  # Only 80 labels
        
        with pytest.raises(ValueError, match="same length"):
            split_data(X, y, val_size=0.2)

    def test_invalid_val_size_raises(self):
        """Invalid val_size raises ValueError."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        with pytest.raises(ValueError, match="val_size"):
            split_data(X, y, val_size=1.5)

    def test_stratify_false(self):
        """Can disable stratification."""
        X = np.random.randn(100, 10)
        y = np.arange(100)  # Regression-like: all unique values
        
        # This should work with stratify=False
        X_train, X_val, y_train, y_val = split_data(
            X, y, val_size=0.2, stratify=False
        )
        
        assert len(X_train) == 80
