"""Tests for training module."""

import numpy as np
import pytest

from reverie.train import train_classifier, train_regressor, _validate_training_inputs


class TestTrainClassifier:
    """Tests for train_classifier function."""

    def test_train_default_model(self):
        """Can train with default LogisticRegression."""
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        model = train_classifier(X, y)
        
        assert hasattr(model, "predict")
        assert hasattr(model, "predict_proba")
        
        # Should be able to predict
        preds = model.predict(X)
        assert len(preds) == 100

    def test_train_custom_model(self):
        """Can train with custom sklearn model."""
        from sklearn.ensemble import RandomForestClassifier
        
        X = np.random.randn(100, 10)
        y = np.array([0, 1] * 50)
        
        model = train_classifier(X, y, model=RandomForestClassifier(n_estimators=10))
        
        assert isinstance(model, RandomForestClassifier)
        preds = model.predict(X)
        assert len(preds) == 100

    def test_multiclass(self):
        """Can train multiclass classifier."""
        X = np.random.randn(150, 10)
        y = np.array([0, 1, 2] * 50)
        
        model = train_classifier(X, y)
        
        preds = model.predict(X)
        assert set(preds).issubset({0, 1, 2})


class TestTrainRegressor:
    """Tests for train_regressor function."""

    def test_train_default_model(self):
        """Can train with default Ridge."""
        X = np.random.randn(100, 10)
        y = np.random.randn(100)
        
        model = train_regressor(X, y)
        
        assert hasattr(model, "predict")
        
        preds = model.predict(X)
        assert len(preds) == 100
        assert preds.dtype == np.float64

    def test_train_custom_model(self):
        """Can train with custom sklearn model."""
        from sklearn.linear_model import Lasso
        
        X = np.random.randn(100, 10)
        y = np.random.randn(100)
        
        model = train_regressor(X, y, model=Lasso(alpha=0.1))
        
        assert isinstance(model, Lasso)


class TestValidateTrainingInputs:
    """Tests for input validation."""

    def test_valid_inputs(self):
        """Valid inputs pass validation."""
        X = np.random.randn(100, 10)
        y = np.random.randn(100)
        _validate_training_inputs(X, y)  # Should not raise

    def test_x_not_array_raises(self):
        """Non-array X raises ValueError."""
        with pytest.raises(ValueError, match="numpy array"):
            _validate_training_inputs([[1, 2], [3, 4]], np.array([0, 1]))

    def test_y_not_array_raises(self):
        """Non-array y raises ValueError."""
        with pytest.raises(ValueError, match="numpy array"):
            _validate_training_inputs(np.array([[1, 2], [3, 4]]), [0, 1])

    def test_x_not_2d_raises(self):
        """1D X raises ValueError."""
        with pytest.raises(ValueError, match="2D"):
            _validate_training_inputs(np.array([1, 2, 3]), np.array([0, 1, 2]))

    def test_y_not_1d_raises(self):
        """2D y raises ValueError."""
        with pytest.raises(ValueError, match="1D"):
            _validate_training_inputs(
                np.array([[1, 2], [3, 4]]),
                np.array([[0], [1]])
            )

    def test_length_mismatch_raises(self):
        """Mismatched lengths raise ValueError."""
        with pytest.raises(ValueError, match="same number"):
            _validate_training_inputs(
                np.random.randn(100, 10),
                np.random.randn(50)
            )

    def test_empty_data_raises(self):
        """Empty data raises ValueError."""
        with pytest.raises(ValueError, match="empty"):
            _validate_training_inputs(
                np.random.randn(0, 10),
                np.random.randn(0)
            )
