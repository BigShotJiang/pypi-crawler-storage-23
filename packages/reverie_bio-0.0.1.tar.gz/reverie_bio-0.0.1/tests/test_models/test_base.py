"""Tests for the BaseModel abstract class."""

import numpy as np
import pandas as pd
import pytest

from reverie.models.base import BaseModel


class TestBaseModelIsAbstract:
    """Verify BaseModel cannot be instantiated directly."""

    def test_cannot_instantiate_base_model(self):
        """BaseModel should raise TypeError if instantiated directly."""
        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            BaseModel()


class TestBaseModelSubclass:
    """Verify subclasses must implement all abstract methods."""

    def test_incomplete_subclass_raises(self):
        """Subclass missing methods should raise TypeError."""

        class IncompleteModel(BaseModel):
            # Only implement some methods
            def load(self):
                pass

            @property
            def name(self):
                return "Incomplete"

        with pytest.raises(TypeError, match="Can't instantiate abstract class"):
            IncompleteModel()

    def test_complete_subclass_works(self):
        """Subclass implementing all methods should instantiate fine."""

        class CompleteModel(BaseModel):
            def load(self):
                pass

            def validate_data(self, df: pd.DataFrame) -> None:
                pass

            def get_sample_ids(self, df: pd.DataFrame) -> np.ndarray:
                return df.index.values

            def embed(self, df: pd.DataFrame) -> np.ndarray:
                return np.zeros((len(df), 10))

            @property
            def embedding_dim(self) -> int:
                return 10

            @property
            def name(self) -> str:
                return "Complete"

        model = CompleteModel()
        assert model.name == "Complete"
        assert model.embedding_dim == 10
        assert repr(model) == "CompleteModel(name='Complete')"
