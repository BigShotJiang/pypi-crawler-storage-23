"""Tests for Standard Model wrapper."""

import numpy as np
import pandas as pd
import pytest

from reverie.models.standard_model import StandardModel


class TestStandardModelInstantiation:
    """Test model instantiation (without loading weights)."""

    def test_instantiate_default(self):
        """Can instantiate with default settings."""
        model = StandardModel()
        assert model.name == "Standard Model"
        assert model.embedding_dim == 1536
        assert model.is_loaded is False

    def test_instantiate_with_options(self):
        """Can instantiate with custom options."""
        import torch
        
        model = StandardModel(
            device="cpu",
            torch_dtype=torch.float16,
            max_length=2048,
        )
        assert model.device == "cpu"
        assert model.torch_dtype == torch.float16
        assert model.max_length == 2048

    def test_repr(self):
        """repr shows model name."""
        model = StandardModel()
        assert "Standard Model" in repr(model)


class TestValidateData:
    """Test data validation logic."""

    @pytest.fixture
    def model(self):
        """Create model instance (not loaded)."""
        return StandardModel()

    @pytest.fixture
    def valid_df(self):
        """Create valid MEDS-format dataframe."""
        return pd.DataFrame({
            "subject_id": ["patient_1", "patient_1", "patient_2"],
            "time": pd.to_datetime(["2023-01-01", "2023-01-15", "2023-02-01"]),
            "code": ["ICD10:E11", "RxNorm:123", "ICD10:I10"],
        })

    def test_valid_data_passes(self, model, valid_df):
        """Valid MEDS data should pass validation."""
        model.validate_data(valid_df)  # Should not raise

    def test_missing_subject_id_raises(self, model):
        """Missing subject_id column should raise ValueError."""
        df = pd.DataFrame({
            "time": pd.to_datetime(["2023-01-01"]),
            "code": ["ICD10:E11"],
        })
        with pytest.raises(ValueError, match="subject_id"):
            model.validate_data(df)

    def test_missing_time_raises(self, model):
        """Missing time column should raise ValueError."""
        df = pd.DataFrame({
            "subject_id": ["patient_1"],
            "code": ["ICD10:E11"],
        })
        with pytest.raises(ValueError, match="time"):
            model.validate_data(df)

    def test_missing_code_raises(self, model):
        """Missing code column should raise ValueError."""
        df = pd.DataFrame({
            "subject_id": ["patient_1"],
            "time": pd.to_datetime(["2023-01-01"]),
        })
        with pytest.raises(ValueError, match="code"):
            model.validate_data(df)

    def test_empty_dataframe_raises(self, model):
        """Empty dataframe should raise ValueError."""
        df = pd.DataFrame({
            "subject_id": [],
            "time": [],
            "code": [],
        })
        with pytest.raises(ValueError, match="empty"):
            model.validate_data(df)

    def test_non_dataframe_raises(self, model):
        """Non-DataFrame input should raise ValueError."""
        with pytest.raises(ValueError, match="DataFrame"):
            model.validate_data({"subject_id": [1], "time": [1], "code": [1]})

    def test_string_time_column_valid(self, model):
        """String time column that's convertible should pass."""
        df = pd.DataFrame({
            "subject_id": ["patient_1"],
            "time": ["2023-01-01"],  # String, not datetime
            "code": ["ICD10:E11"],
        })
        model.validate_data(df)  # Should not raise

    def test_invalid_time_column_raises(self, model):
        """Non-datetime, non-convertible time column should raise."""
        df = pd.DataFrame({
            "subject_id": ["patient_1"],
            "time": ["not a date"],
            "code": ["ICD10:E11"],
        })
        with pytest.raises(ValueError, match="datetime"):
            model.validate_data(df)

    def test_all_null_subject_ids_raises(self, model):
        """All-null subject_id column should raise ValueError."""
        df = pd.DataFrame({
            "subject_id": [None, None],
            "time": pd.to_datetime(["2023-01-01", "2023-01-02"]),
            "code": ["ICD10:E11", "ICD10:I10"],
        })
        with pytest.raises(ValueError, match="null"):
            model.validate_data(df)


class TestGetSampleIds:
    """Test sample ID extraction."""

    @pytest.fixture
    def model(self):
        return StandardModel()

    def test_unique_ids_returned(self, model):
        """Should return unique subject IDs."""
        df = pd.DataFrame({
            "subject_id": ["p1", "p1", "p2", "p3", "p2"],
            "time": pd.to_datetime(["2023-01-01"] * 5),
            "code": ["A"] * 5,
        })
        ids = model.get_sample_ids(df)
        assert len(ids) == 3
        assert set(ids) == {"p1", "p2", "p3"}

    def test_ids_are_sorted(self, model):
        """IDs should be returned in sorted order for determinism."""
        df = pd.DataFrame({
            "subject_id": ["charlie", "alice", "bob"],
            "time": pd.to_datetime(["2023-01-01"] * 3),
            "code": ["A"] * 3,
        })
        ids = model.get_sample_ids(df)
        assert list(ids) == ["alice", "bob", "charlie"]

    def test_null_ids_excluded(self, model):
        """Null subject IDs should be excluded."""
        df = pd.DataFrame({
            "subject_id": ["p1", None, "p2", None],
            "time": pd.to_datetime(["2023-01-01"] * 4),
            "code": ["A"] * 4,
        })
        ids = model.get_sample_ids(df)
        assert len(ids) == 2
        assert set(ids) == {"p1", "p2"}

    def test_numeric_ids_work(self, model):
        """Numeric subject IDs should work."""
        df = pd.DataFrame({
            "subject_id": [100, 100, 200, 300],
            "time": pd.to_datetime(["2023-01-01"] * 4),
            "code": ["A"] * 4,
        })
        ids = model.get_sample_ids(df)
        assert len(ids) == 3
        assert list(ids) == [100, 200, 300]


class TestEmbedWithoutLoading:
    """Test embed() behavior when model isn't loaded."""

    def test_embed_without_load_raises(self):
        """embed() should raise RuntimeError if model not loaded."""
        model = StandardModel()
        df = pd.DataFrame({
            "subject_id": ["p1"],
            "time": pd.to_datetime(["2023-01-01"]),
            "code": ["ICD10:E11"],
        })
        with pytest.raises(RuntimeError, match="not loaded"):
            model.embed(df)
