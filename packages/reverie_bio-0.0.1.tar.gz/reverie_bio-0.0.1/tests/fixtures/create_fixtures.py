"""Create test fixtures for data module tests."""

import pandas as pd
from pathlib import Path

FIXTURES_DIR = Path(__file__).parent


def create_sample_data_csv():
    """Create sample MEDS-format data."""
    df = pd.DataFrame({
        "subject_id": ["p1", "p1", "p1", "p2", "p2", "p3"],
        "time": [
            "2023-01-01", "2023-01-15", "2023-02-01",
            "2023-03-01", "2023-03-15",
            "2023-04-01",
        ],
        "code": [
            "ICD10:E11", "RxNorm:123", "LOINC:456",
            "ICD10:I10", "RxNorm:789",
            "ICD10:J45",
        ],
    })
    df.to_csv(FIXTURES_DIR / "sample_data.csv", index=False)
    return df


def create_sample_labels_csv():
    """Create sample labels file."""
    df = pd.DataFrame({
        "subject_id": ["p1", "p2", "p3"],
        "outcome": [1, 0, 1],
    })
    df.to_csv(FIXTURES_DIR / "sample_labels.csv", index=False)
    return df


def create_sample_data_with_labels_csv():
    """Create sample data with labels in same file."""
    df = pd.DataFrame({
        "subject_id": ["p1", "p1", "p2", "p2", "p3"],
        "time": [
            "2023-01-01", "2023-01-15",
            "2023-03-01", "2023-03-15",
            "2023-04-01",
        ],
        "code": ["A", "B", "C", "D", "E"],
        "label": [1, 1, 0, 0, 1],  # Same label for same subject
    })
    df.to_csv(FIXTURES_DIR / "sample_data_with_labels.csv", index=False)
    return df


if __name__ == "__main__":
    create_sample_data_csv()
    create_sample_labels_csv()
    create_sample_data_with_labels_csv()
    print("Created test fixtures")
