class ProtocolViolation(RuntimeError):
    """Raised when protocol rules are violated."""
