from painted import show

data = {
    "service": "api-gateway",
    "version": "2.4.1",
    "replicas": {"desired": 3, "ready": 3},
    "endpoints": [
        {"path": "/health", "status": 200},
        {"path": "/api/v1", "status": 200},
    ],
}
show(data)
