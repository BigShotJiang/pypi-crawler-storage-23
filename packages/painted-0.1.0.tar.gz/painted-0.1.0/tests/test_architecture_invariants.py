from __future__ import annotations

import ast
from dataclasses import is_dataclass
from pathlib import Path

import pytest


def test_block_defensively_freezes_rows() -> None:
    from painted.block import Block
    from painted.cell import Cell, Style

    style = Style()
    rows = [[Cell("a", style), Cell("b", style)]]

    block = Block(rows, width=2)

    # Mutate the caller-owned list-of-lists after construction: must not affect Block.
    rows[0][0] = Cell("x", style)
    rows.append([Cell("y", style), Cell("z", style)])

    assert block.height == 1
    assert [c.char for c in block.row(0)] == ["a", "b"]

    assert isinstance(block._rows, tuple)
    assert isinstance(block._rows[0], tuple)
    assert isinstance(block.row(0), tuple)

    with pytest.raises(TypeError):
        block.row(0)[0] = Cell("q", style)  # type: ignore[misc]

    with pytest.raises(AttributeError):
        block.width = 3  # type: ignore[misc]


def _dataclass_frozen_from_decorators(class_def: ast.ClassDef) -> bool | None:
    for decorator in class_def.decorator_list:
        if isinstance(decorator, ast.Name) and decorator.id == "dataclass":
            return False
        if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Name) and decorator.func.id == "dataclass":
            for kw in decorator.keywords:
                if kw.arg == "frozen" and isinstance(kw.value, ast.Constant) and kw.value.value is True:
                    return True
            return False
    return None


def test_state_dataclasses_declared_frozen() -> None:
    painted_root = Path(__file__).resolve().parents[1] / "src" / "painted"

    must_be_frozen = {
        "Region",
        "Cell",
        "Style",
        "Span",
        "Line",
        "BorderChars",
        "Focus",
        "Search",
        "Lens",
        "Cursor",
        "Viewport",
        "CliContext",
        "Palette",
        "IconSet",
    }

    for py_file in painted_root.rglob("*.py"):
        tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
        for node in tree.body:
            if not isinstance(node, ast.ClassDef):
                continue

            if node.name.endswith("State") or node.name in must_be_frozen:
                frozen = _dataclass_frozen_from_decorators(node)
                assert frozen is True, f"{py_file}: class {node.name} must be @dataclass(frozen=True)"


def test_block_rows_private_not_accessed_outside_block() -> None:
    painted_root = Path(__file__).resolve().parents[1] / "src" / "painted"
    block_py = painted_root / "block.py"

    for py_file in painted_root.rglob("*.py"):
        if py_file == block_py:
            continue
        assert "._rows" not in py_file.read_text(encoding="utf-8"), f"{py_file} accesses Block._rows directly"


def test_runtime_state_dataclasses_are_frozen() -> None:
    from painted.borders import BorderChars
    from painted.cell import Cell, Style
    from painted._components.data_explorer import DataExplorerState
    from painted._components.list_view import ListState
    from painted._components.progress import ProgressState
    from painted._components.spinner import SpinnerState
    from painted._components.table import TableState
    from painted._components.text_input import TextInputState
    from painted.cursor import Cursor
    from painted.fidelity import CliContext
    from painted.focus import Focus
    from painted.region import Region
    from painted.search import Search
    from painted.span import Line, Span
    from painted.viewport import Viewport
    from painted.icon_set import IconSet
    from painted.palette import Palette

    for cls in (
        Region,
        Cell,
        Style,
        Span,
        Line,
        BorderChars,
        Focus,
        Search,
        Cursor,
        Viewport,
        CliContext,
        Palette,
        IconSet,
        SpinnerState,
        ProgressState,
        ListState,
        TextInputState,
        TableState,
        DataExplorerState,
    ):
        assert is_dataclass(cls)
        assert cls.__dataclass_params__.frozen is True
