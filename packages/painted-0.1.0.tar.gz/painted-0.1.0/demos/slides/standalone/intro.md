---
id: intro
group:
order: 0
align: center
---

# painted

[spacer:2]

a cell-buffer terminal UI framework

[spacer:2]

use `arrow keys` to navigate

`left` `right` for topics, `up` `down` for depth

[spacer:2]

press `right` to begin
