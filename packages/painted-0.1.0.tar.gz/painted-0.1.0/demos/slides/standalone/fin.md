---
id: fin
group:
order: 0
align: center
---

# fin

[spacer:2]

*that's* `painted`*.*

[spacer:2]

`Cell` -> `Style` -> `Span` -> `Line` -> `Block` -> `Buffer`

[spacer]

compose with `join`, `pad`, `border`

[spacer]

run with `Surface`

[spacer:2]

`go build something.`
