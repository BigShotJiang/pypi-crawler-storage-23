# Guides

These are narrative “learn the mental model” docs (as opposed to quick reference).

Current set:
- `01-primitives-and-blocks.md`
- `02-composition-layout.md`
- `04-cli-harness-fidelity.md`
- `05-tui-core-surface-layers.md`

Notes:
- Code blocks in these guides are synced from `src/painted/` via `tools/docgen.py`.
- `docs/.extract/snippets.v1.json` is the shared artifact for both docs and (later) `demos/tour.py`.

