# Changelog

All notable changes to this project will be documented in this file. See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.1.15](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.14...v0.1.15) (2026-02-27)


### Bug Fixes

* **SPIN:** Try and set SPIN if 404/403 ([75f5d3f](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/75f5d3f929470bd8b9270000bc0527c628765b11))
* Update README ([86623ed](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/86623ede0b559c38c53b3ecf4f507287abff6d59))

## [0.1.15-b.2](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.15-b.1...v0.1.15-b.2) (2026-02-23)


### Bug Fixes

* Update README ([86623ed](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/86623ede0b559c38c53b3ecf4f507287abff6d59))

## [0.1.15-b.1](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.14...v0.1.15-b.1) (2026-02-16)


### Bug Fixes

* **SPIN:** Try and set SPIN if 404/403 ([75f5d3f](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/75f5d3f929470bd8b9270000bc0527c628765b11))

## [0.1.14](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.13...v0.1.14) (2026-02-16)


### Bug Fixes

* **ev:** Fix climate and charge values ([3849e77](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/3849e7738678406dc7fd2c24e609d6888d5ef759))
* **ev:** Fix climate and charge values ([9e3c998](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/9e3c998acc1db020a2f6d6afe9f1949931ee18df))
* **format:** Fix overrides for post, put, delete functions ([962de38](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/962de3874293fe38e98d922c2776e7efbf71c9f0))
* **ci:** Fixup version tags to match PEP 440 format ([91371f0](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/91371f07ef24c65dfeb6b216cd27b490125ac712))
* **ci:** Force new build on main ([72ffb39](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/72ffb39ba6c1c7cc48d54f284def1e1b7729c8bd))
* **ci:** Set python build to exact tag version ([8a3c567](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/8a3c567d109b6217abfd3e1892f52c848de5b9a2))
* **ci:** Trigger a patch build for beta ([0860491](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/0860491427d5b3e546f01529b86cf0e5b21abd23))

## [0.1.14-b.1](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.13...v0.1.14-b.1) (2026-02-16)


### Bug Fixes

* **ev:** Fix climate and charge values ([3849e77](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/3849e7738678406dc7fd2c24e609d6888d5ef759))
* **ev:** Fix climate and charge values ([9e3c998](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/9e3c998acc1db020a2f6d6afe9f1949931ee18df))
* **ci:** Fixup version tags to match PEP 440 format ([91371f0](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/91371f07ef24c65dfeb6b216cd27b490125ac712))
* **ci:** Set python build to exact tag version ([8a3c567](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/8a3c567d109b6217abfd3e1892f52c848de5b9a2))
* **ci:** Trigger a patch build for beta ([0860491](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/0860491427d5b3e546f01529b86cf0e5b21abd23))

## [0.1.14-beta.3](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.14-beta.2...v0.1.14-beta.3) (2026-02-16)


### Bug Fixes

* **ci:** Set python build to exact tag version ([8a3c567](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/8a3c567d109b6217abfd3e1892f52c848de5b9a2))

## [0.1.14-beta.2](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.14-beta.1...v0.1.14-beta.2) (2026-02-16)


### Bug Fixes

* **ev:** Fix climate and charge values ([3849e77](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/3849e7738678406dc7fd2c24e609d6888d5ef759))
* **ev:** Fix climate and charge values ([9e3c998](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/9e3c998acc1db020a2f6d6afe9f1949931ee18df))

## [0.1.14-beta.1](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/compare/v0.1.13...v0.1.14-beta.1) (2026-02-15)


### Bug Fixes

* **ci:** Trigger a patch build for beta ([0860491](https://github.com/zackcornelius/CarConnectivity-connector-volkswagen-na/commit/0860491427d5b3e546f01529b86cf0e5b21abd23))

# Changelog

All notable changes to this project will be documented in this file.

## [Unreleased]
- No unreleased changes so far

## [0.8.2] - 2025-07-22
### Fixed
- Fixes attribute for estimated time reached for charging

## [0.8.1] - 2025-06-27
### Added
- Fix support for adblue range

## [0.8] - 2025-06-26
### Added
- Support for adblue range

## [0.7.3] - 2025-06-20
### Fixed
- Fixes bug that registers hooks several times, causing multiple calls to the servers

### Changed
- Updated dependencies

## [0.7.2] - 2025-04-19
### Fixed
- Fix for problems introduced with PyJWT

## [0.7.1] - 2025-04-19
### Changed
- Use PyJWT instead of jwt

## [0.7] - 2025-04-17
### Changed
- Updated dependencies
- stripping of leading and trailing spaces in commands

### Added
- Precision for all attributes is now used when displaying values

## [0.6] - 2025-04-02
### Fixed
- Made changes to charging settings for older electric vehicles
- Allowes to have multiple instances of this connector running

### Changed
- Updated dependencies

## [0.5] - 2025-03-20
### Added
- Support for window heating attributes
- Support for window heating command
- SUpport for changing charging settings

## [0.4.2] - 2025-03-11
### Fixed
- Fixes bug where no data was shown anymore if the vehicle did not have access capability

## [0.4.1] - 2025-03-04
### Fixed
- Fixed http error when parking position was fetched but due to error not available

## [0.4] - 2025-03-02
### Added
- Added hint to do consent when login is not possible
- Make connection_state public accessible
- Make health state public accessible
- Make interval online changeable
- Threads are now named
- vehcile state is calculated from various states
- Added support for battery temperature
- Check for value range in attributes
- Added support for maintenance attributes
- Added support for plug states
- Added support for connectivity status
- Added position type
- Added better error handling in commands

### Fixed
- Images and capabilities are now only fetched once
- Fix for fetching charging state
- Fix for total range if not a vehicle property
- Fix for older python versions
- Fix for rear seat heating settings

## [0.3] - 2025-02-19
### Added
- Added support for images
- Added tags to attributes
- Added support for webui via carconnectivity-plugin-webui

## [0.2] - 2025-02-02
### Added
- Adds several commands to control the vehicle and charging attributes

## [0.1] - 2025-01-25
Initial release, let's go and give this to the public to try out...
The API is not yet implemented completely! There is no way to control something in the car yet

[unreleased]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/compare/v0.8.2...HEAD
[0.8.2]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.8.2
[0.8.1]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.8.1
[0.8]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.8
[0.7.3]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.7.3
[0.7.2]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.7.2
[0.7.1]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.7.1
[0.7]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.7
[0.6]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.6
[0.5]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.5
[0.4.2]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.4.2
[0.4.1]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.4.1
[0.4]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.4
[0.3]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.3
[0.2]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.2
[0.1]: https://github.com/tillsteinbach/CarConnectivity-connector-volkswagen/releases/tag/v0.1
