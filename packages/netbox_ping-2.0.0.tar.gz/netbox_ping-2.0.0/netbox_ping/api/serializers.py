from netbox.api.serializers import NetBoxModelSerializer
from ..models import PingResult, SubnetScanResult


class PingResultSerializer(NetBoxModelSerializer):
    class Meta:
        model = PingResult
        fields = (
            'id', 'url', 'display', 'ip_address', 'is_reachable',
            'last_seen', 'response_time_ms', 'dns_name', 'last_checked',
            'tags', 'custom_fields', 'created', 'last_updated',
        )
        brief_fields = ('id', 'url', 'display', 'ip_address', 'is_reachable')


class SubnetScanResultSerializer(NetBoxModelSerializer):
    class Meta:
        model = SubnetScanResult
        fields = (
            'id', 'url', 'display', 'prefix', 'total_hosts', 'hosts_up',
            'hosts_down', 'last_scanned',
            'tags', 'custom_fields', 'created', 'last_updated',
        )
        brief_fields = ('id', 'url', 'display', 'prefix', 'hosts_up', 'total_hosts')
