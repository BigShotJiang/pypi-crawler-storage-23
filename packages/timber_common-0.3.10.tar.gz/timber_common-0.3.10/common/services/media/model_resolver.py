# timber/common/services/media/model_resolver.py
"""
Self-Healing Gemini Model Resolver

Intercepts model-not-found errors and automatically discovers the next
available image generation model from the Gemini API. Results are cached
in-process with a configurable TTL so the probe cost is amortised across
thousands of generation calls.

Design goals:
    1. Backwards-compatible — callers pass ANY model string (including
       deprecated ones). If it works, great. If it 404s, the resolver
       finds what replaced it and retries transparently.
    2. Zero config changes — old task configs, env vars, and hardcoded
       strings all continue to work without edits.
    3. Resilient — if the Gemini models.list() endpoint is unreachable,
       falls back to a static priority list updated at release time.
    4. Observable — every fallback decision is logged at WARNING level
       so operators know a config update is overdue.

Usage:
    from common.services.media.model_resolver import GeminiModelResolver

    resolver = GeminiModelResolver(api_key="...")

    # Returns the model string to use — may differ from what you asked for
    model = resolver.resolve("gemini-2.0-flash-preview-image-generation")

    # Or wrap a generation call with automatic retry on 404
    response = resolver.generate_with_fallback(
        requested_model="gemini-2.0-flash-preview-image-generation",
        contents=("A cat in space",),
        config=GenerateContentConfig(...),
    )
"""

import logging
import time
import threading
from typing import Any, Dict, List, Optional, Set, Tuple

from google import genai as genaiClient

logger = logging.getLogger(__name__)


# ============================================================================
# STATIC FALLBACK CHAIN
# ============================================================================
# Ordered by preference: newest/best → oldest still-functional.
# Updated at release time. The dynamic probe supersedes this when the
# Gemini API is reachable, but this list guarantees we never return
# nothing even if the list endpoint is down.
# ============================================================================

IMAGE_MODEL_FALLBACK_CHAIN: List[str] = [
    "gemini-2.5-flash-image",                       # Current stable (Aug 2025)
    "gemini-2.0-flash-image",                        # Alias — may or may not exist
    "gemini-2.0-flash-exp",                          # Early experimental
    "gemini-2.0-flash-preview-image-generation",     # Original preview (deprecated)
]

# Keywords that indicate a model supports native image generation.
# Used when scanning the models.list() response.
_IMAGE_CAPABILITY_HINTS = frozenset({
    "image",
    "imagen",
    "nano-banana",
    "flash-image",
})

# How long (seconds) a resolved model stays cached before we re-probe.
DEFAULT_CACHE_TTL = 3600  # 1 hour


# ============================================================================
# RESOLVER
# ============================================================================

class GeminiModelResolver:
    """
    Resolves and caches the best available Gemini image generation model.

    Thread-safe. A single instance should be shared across the application
    (the ImageGenerationService holds one).

    Resolution strategy (for a given ``requested_model``):

        1. If ``requested_model`` is cached and not expired → return it.
        2. Probe ``requested_model`` with models.get(). If found → cache & return.
        3. Walk the static fallback chain, probing each. First hit → cache & return.
        4. Query models.list() to discover ANY image-capable model. First hit → cache & return.
        5. If everything fails → return ``requested_model`` unchanged (let the
           caller surface the real Gemini error).
    """

    def __init__(
        self,
        api_key: str,
        cache_ttl: int = DEFAULT_CACHE_TTL,
        fallback_chain: Optional[List[str]] = None,
    ):
        self._api_key = api_key
        self._cache_ttl = cache_ttl
        self._fallback_chain = fallback_chain or list(IMAGE_MODEL_FALLBACK_CHAIN)
        self._lock = threading.Lock()

        # Cache: requested_model → (resolved_model, timestamp)
        self._cache: Dict[str, Tuple[str, float]] = {}

        # Global "known good" model — populated on first successful probe.
        # Serves as a shortcut for ANY future request whose specific model
        # is not found, skipping the full probe sequence.
        self._known_good: Optional[str] = None
        self._known_good_ts: float = 0.0

    # ------------------------------------------------------------------
    # PUBLIC API
    # ------------------------------------------------------------------

    def resolve(self, requested_model: str) -> str:
        """
        Resolve ``requested_model`` to a model string the API will accept.

        Returns ``requested_model`` unchanged if it's valid, or the best
        available alternative if it's been deprecated/removed.
        """
        now = time.monotonic()

        # Fast path: cached and fresh
        with self._lock:
            cached = self._cache.get(requested_model)
            if cached and (now - cached[1]) < self._cache_ttl:
                return cached[0]

        # Slow path: probe
        resolved = self._probe_and_resolve(requested_model)

        with self._lock:
            self._cache[requested_model] = (resolved, time.monotonic())

        return resolved

    def generate_with_fallback(
        self,
        requested_model: str,
        contents: Any,
        config: Any,
        *,
        client: Optional[Any] = None,
    ) -> Any:
        """
        Call ``client.models.generate_content`` with automatic model fallback.

        If the initial call raises a 404/NOT_FOUND, resolves the model
        (invalidating cache for this key) and retries exactly once.

        Args:
            requested_model:  The model string the caller wants to use.
            contents:         Prompt / content tuple for generate_content.
            config:           GenerateContentConfig instance.
            client:           Optional genai.Client. Created internally if None.

        Returns:
            The GenerateContentResponse from Gemini.

        Raises:
            google.genai.errors.ClientError: If retry also fails.
        """
        if client is None:
            client = genaiClient.Client(api_key=self._api_key)

        model = self.resolve(requested_model)

        try:
            return client.models.generate_content(
                model=model,
                contents=contents,
                config=config,
            )
        except Exception as exc:
            if not self._is_model_not_found(exc):
                raise

            logger.warning(
                f"[ModelResolver] Model '{model}' returned NOT_FOUND on "
                f"generate_content — invalidating cache and retrying"
            )

            # Invalidate this specific cache entry
            with self._lock:
                self._cache.pop(requested_model, None)
                # Also invalidate known_good if it matches
                if self._known_good == model:
                    self._known_good = None

            # Re-resolve (will skip the dead model)
            fallback_model = self._probe_and_resolve(
                requested_model, skip_models={model},
            )

            with self._lock:
                self._cache[requested_model] = (fallback_model, time.monotonic())

            if fallback_model == model:
                # Nothing better found — re-raise original error
                raise

            logger.info(
                f"[ModelResolver] Retrying with fallback model: {fallback_model}"
            )
            return client.models.generate_content(
                model=fallback_model,
                contents=contents,
                config=config,
            )

    def invalidate(self, model: Optional[str] = None) -> None:
        """
        Clear cache. If ``model`` is given, only that entry; otherwise all.
        """
        with self._lock:
            if model:
                self._cache.pop(model, None)
            else:
                self._cache.clear()
                self._known_good = None

    # ------------------------------------------------------------------
    # PROBING
    # ------------------------------------------------------------------

    def _probe_and_resolve(
        self,
        requested_model: str,
        skip_models: Optional[Set[str]] = None,
    ) -> str:
        """
        Walk the resolution strategy and return the best available model.
        """
        skip = skip_models or set()

        # 1. Check known_good shortcut (if not the model we're skipping)
        with self._lock:
            if (
                self._known_good
                and self._known_good not in skip
                and (time.monotonic() - self._known_good_ts) < self._cache_ttl
            ):
                if self._known_good != requested_model:
                    logger.info(
                        f"[ModelResolver] '{requested_model}' → "
                        f"known-good '{self._known_good}'"
                    )
                return self._known_good

        # 2. Probe the requested model directly
        if requested_model not in skip and self._model_exists(requested_model):
            self._set_known_good(requested_model)
            return requested_model

        logger.warning(
            f"[ModelResolver] Requested model '{requested_model}' not found — "
            f"searching for fallback"
        )

        # 3. Walk static fallback chain
        for candidate in self._fallback_chain:
            if candidate == requested_model or candidate in skip:
                continue
            if self._model_exists(candidate):
                logger.warning(
                    f"[ModelResolver] Fallback: '{requested_model}' → "
                    f"'{candidate}' (from static chain)"
                )
                self._set_known_good(candidate)
                return candidate

        # 4. Dynamic discovery via models.list()
        discovered = self._discover_image_model(skip=skip)
        if discovered:
            logger.warning(
                f"[ModelResolver] Fallback: '{requested_model}' → "
                f"'{discovered}' (from dynamic discovery)"
            )
            self._set_known_good(discovered)
            return discovered

        # 5. Give up — return requested and let the caller deal with the error
        logger.error(
            f"[ModelResolver] No available image generation model found. "
            f"Returning '{requested_model}' unchanged."
        )
        return requested_model

    def _model_exists(self, model_name: str) -> bool:
        """
        Probe a single model via models.get(). Returns True if it exists.

        Handles both bare names ("gemini-2.5-flash-image") and prefixed
        names ("models/gemini-2.5-flash-image").
        """
        try:
            client = genaiClient.Client(api_key=self._api_key)
            client.models.get(model=model_name)
            logger.debug(f"[ModelResolver] Probe OK: {model_name}")
            return True
        except Exception as exc:
            if self._is_model_not_found(exc):
                logger.debug(f"[ModelResolver] Probe 404: {model_name}")
                return False
            # Network error, auth error, etc. — don't assume the model
            # is gone, but don't assume it's there either.
            logger.debug(
                f"[ModelResolver] Probe error for {model_name}: "
                f"{type(exc).__name__}: {exc}"
            )
            return False

    def _discover_image_model(self, skip: Optional[Set[str]] = None) -> Optional[str]:
        """
        Query models.list() and find the first model that looks like it
        supports native image generation.
        """
        skip = skip or set()
        try:
            client = genaiClient.Client(api_key=self._api_key)
            models = client.models.list()

            candidates: List[Tuple[int, str]] = []

            for model in models:
                name = getattr(model, "name", "") or ""
                # Strip "models/" prefix for comparison
                short_name = name.replace("models/", "")

                if short_name in skip:
                    continue

                # Check if model name contains image capability hints
                name_lower = short_name.lower()
                if any(hint in name_lower for hint in _IMAGE_CAPABILITY_HINTS):
                    # Score: prefer "flash-image" family, then anything else
                    if "flash-image" in name_lower:
                        score = 0  # best
                    elif "image" in name_lower and "preview" not in name_lower:
                        score = 1  # stable image model
                    elif "image" in name_lower:
                        score = 2  # preview image model
                    else:
                        score = 3
                    candidates.append((score, short_name))

            if candidates:
                candidates.sort()
                best = candidates[0][1]
                logger.info(
                    f"[ModelResolver] Dynamic discovery found "
                    f"{len(candidates)} image model(s), best: {best}"
                )
                return best

        except Exception as exc:
            logger.warning(
                f"[ModelResolver] models.list() failed: "
                f"{type(exc).__name__}: {exc}"
            )

        return None

    # ------------------------------------------------------------------
    # HELPERS
    # ------------------------------------------------------------------

    def _set_known_good(self, model: str) -> None:
        """Cache a model as the global known-good."""
        with self._lock:
            self._known_good = model
            self._known_good_ts = time.monotonic()

    @staticmethod
    def _is_model_not_found(exc: Exception) -> bool:
        """
        Check if an exception indicates a model-not-found / 404 error.

        Handles both the new ``google.genai.errors.ClientError`` and
        generic HTTP-style exceptions.
        """
        exc_str = str(exc).lower()
        exc_type = type(exc).__name__

        # google.genai.errors.ClientError: 404 NOT_FOUND
        if "not_found" in exc_str or "404" in exc_str:
            return True

        # Some SDK versions raise NotFound directly
        if "notfound" in exc_type.lower():
            return True

        # Check for status_code attribute
        status = getattr(exc, "status_code", None) or getattr(exc, "code", None)
        if status == 404:
            return True

        return False


# ============================================================================
# MODULE-LEVEL SINGLETON
# ============================================================================

_resolver_instance: Optional[GeminiModelResolver] = None
_resolver_lock = threading.Lock()


def get_model_resolver(api_key: Optional[str] = None) -> Optional[GeminiModelResolver]:
    """
    Get or create the singleton GeminiModelResolver.

    Args:
        api_key: Gemini API key. Required on first call, ignored after.

    Returns:
        GeminiModelResolver instance, or None if no API key available.
    """
    global _resolver_instance
    if _resolver_instance is not None:
        return _resolver_instance

    with _resolver_lock:
        # Double-check inside lock
        if _resolver_instance is not None:
            return _resolver_instance

        if not api_key:
            import os
            api_key = os.environ.get("GEMINI_API_KEY", "")

        if not api_key:
            logger.warning(
                "[ModelResolver] No API key available — resolver disabled"
            )
            return None

        _resolver_instance = GeminiModelResolver(api_key=api_key)
        logger.info("[ModelResolver] Singleton created")
        return _resolver_instance


def reset_model_resolver() -> None:
    """Reset singleton (testing)."""
    global _resolver_instance
    with _resolver_lock:
        _resolver_instance = None