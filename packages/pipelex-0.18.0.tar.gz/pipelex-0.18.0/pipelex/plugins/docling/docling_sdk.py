from docling.document_converter import DocumentConverter


class DoclingSdk:
    def __init__(self):
        self.document_converter = DocumentConverter()
