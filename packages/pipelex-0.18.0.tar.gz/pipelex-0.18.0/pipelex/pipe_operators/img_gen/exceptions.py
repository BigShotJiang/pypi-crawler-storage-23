from pipelex.base_exceptions import PipelexError


class PipeImgGenRunError(PipelexError):
    pass


class PipeImgGenFactoryError(PipelexError):
    pass
