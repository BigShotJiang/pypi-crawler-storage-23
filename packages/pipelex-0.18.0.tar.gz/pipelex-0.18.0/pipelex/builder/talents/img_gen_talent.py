from pipelex.types import StrEnum


class ImgGenTalent(StrEnum):
    GEN_IMAGE = "gen-image"
    GEN_IMAGE_FAST = "gen-image-fast"
    GEN_IMAGE_HIGH_QUALITY = "gen-image-high-quality"
