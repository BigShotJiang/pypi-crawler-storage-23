import pytest
import os
import tempfile
from pathlib import Path
import yaml

import sys
sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from config_provider import ConfManProvider, get_provider


class TestConfManProvider:
    """Test ConfManProvider class"""

    @pytest.fixture
    def temp_dir(self):
        """Create temporary directory for testing"""
        with tempfile.TemporaryDirectory() as tmpdir:
            yield Path(tmpdir)

    @pytest.fixture
    def config_file(self, temp_dir):
        """Create test config file"""
        config_dir = temp_dir / "config"
        config_dir.mkdir()
        
        config_data = {
            'version': '1.0',
            'paths': {
                'data_dir': 'mydata',
                'config_dir': 'myconfig',
                'log_dir': 'mylogs',
                'temp_dir': 'mytemp'
            },
            'files': {
                'todo_db': 'mytodos.db',
                'state_file': 'mystate.yaml',
                'agent_status_db': 'myagent.db',
                'opencode_db': '.myopencode/db',
                'pid_file': 'mypid.pid',
                'identity_file': 'myidentity.id',
                'session_dir': 'mysessions',
                'adhoc_todos': 'myadhoc.yaml'
            },
            'configs': {
                'git_sync': 'mygit.yaml',
                'notification': 'mynotify.yaml',
                'skill_index': 'myskills.yaml',
                'agents': 'myagents.yaml',
                'file_owners': 'myowners.yaml'
            },
            'environment': {
                'mode': 'test',
                'allow_override': True
            }
        }
        
        config_path = config_dir / 'default_config.yaml'
        with open(config_path, 'w') as f:
            yaml.dump(config_data, f)
        
        return config_path

    def test_init_with_config(self, config_file):
        """Test initialization with config file"""
        provider = ConfManProvider(config_path=str(config_file))
        assert provider._version == "1.0.0"

    def test_init_without_config(self, temp_dir):
        """Test initialization without config (fallback)"""
        provider = ConfManProvider(base_dir=temp_dir)
        assert provider._version == "1.0.0"

    def test_get_data_dir(self, config_file):
        """Test get_data_dir method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mydata")
        assert provider.get_data_dir() == expected

    def test_get_data_dir_default(self, temp_dir):
        """Test get_data_dir with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "state")
        assert provider.get_data_dir() == expected

    def test_get_config_dir(self, config_file):
        """Test get_config_dir method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "myconfig")
        assert provider.get_config_dir() == expected

    def test_get_config_dir_default(self, temp_dir):
        """Test get_config_dir with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config")
        assert provider.get_config_dir() == expected

    def test_get_log_dir(self, config_file):
        """Test get_log_dir method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mylogs")
        assert provider.get_log_dir() == expected

    def test_get_log_dir_default(self, temp_dir):
        """Test get_log_dir with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "logs")
        assert provider.get_log_dir() == expected

    def test_get_temp_dir(self, config_file):
        """Test get_temp_dir method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mytemp")
        assert provider.get_temp_dir() == expected

    def test_get_temp_dir_default(self, temp_dir):
        """Test get_temp_dir with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "tmp")
        assert provider.get_temp_dir() == expected

    def test_get_todo_db_path(self, config_file):
        """Test get_todo_db_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "state" / "todos.db")
        assert provider.get_todo_db_path() == expected

    def test_get_todo_db_path_default(self, temp_dir):
        """Test get_todo_db_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "state" / "todos.db")
        assert provider.get_todo_db_path() == expected

    def test_get_state_file_path(self, config_file):
        """Test get_state_file_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mystate.yaml")
        assert provider.get_state_file_path() == expected

    def test_get_state_file_path_default(self, temp_dir):
        """Test get_state_file_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "project_state.yaml")
        assert provider.get_state_file_path() == expected

    def test_get_lock_file_path(self, config_file):
        """Test get_lock_file_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(Path(config_file).parent.parent / "mydata" / "test.lock")
        assert provider.get_lock_file_path("test") == expected

    def test_get_lock_file_path_default(self, temp_dir):
        """Test get_lock_file_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "state" / "mylock.lock")
        assert provider.get_lock_file_path("mylock") == expected

    def test_get_agent_status_db_path(self, config_file):
        """Test get_agent_status_db_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "myagent.db")
        assert provider.get_agent_status_db_path() == expected

    def test_get_agent_status_db_path_default(self, temp_dir):
        """Test get_agent_status_db_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "agent_status.db")
        assert provider.get_agent_status_db_path() == expected

    def test_get_session_dir(self, config_file):
        """Test get_session_dir method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mysessions")
        assert provider.get_session_dir() == expected

    def test_get_session_dir_default(self, temp_dir):
        """Test get_session_dir with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "sessions")
        assert provider.get_session_dir() == expected

    def test_get_adhoc_todos_path(self, config_file):
        """Test get_adhoc_todos_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "myadhoc.yaml")
        assert provider.get_adhoc_todos_path() == expected

    def test_get_adhoc_todos_path_default(self, temp_dir):
        """Test get_adhoc_todos_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "agent_adhoc_todos.yaml")
        assert provider.get_adhoc_todos_path() == expected

    def test_get_identity_file_path(self, config_file):
        """Test get_identity_file_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "myidentity.id")
        assert provider.get_identity_file_path() == expected

    def test_get_identity_file_path_default(self, temp_dir):
        """Test get_identity_file_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "agent.identity")
        assert provider.get_identity_file_path() == expected

    def test_get_pid_file_path(self, config_file):
        """Test get_pid_file_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / "mypid.pid")
        assert provider.get_pid_file_path() == expected

    def test_get_pid_file_path_default(self, temp_dir):
        """Test get_pid_file_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "agent.pid")
        assert provider.get_pid_file_path() == expected

    def test_get_opencode_db_path(self, config_file):
        """Test get_opencode_db_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        expected = str(temp_dir := Path(config_file).parent.parent / ".myopencode/db")
        assert provider.get_opencode_db_path() == expected

    def test_get_opencode_db_path_default(self, temp_dir):
        """Test get_opencode_db_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / ".opencode/opencode.db")
        assert provider.get_opencode_db_path() == expected

    def test_get_agents_config_path(self, config_file):
        """Test get_agents_config_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        base = config_file.parent.parent
        expected = str(base / "myconfig" / "myagents.yaml")
        assert provider.get_agents_config_path() == expected

    def test_get_agents_config_path_default(self, temp_dir):
        """Test get_agents_config_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config" / "agents.yaml")
        assert provider.get_agents_config_path() == expected

    def test_get_git_sync_config_path(self, config_file):
        """Test get_git_sync_config_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        base = config_file.parent.parent
        expected = str(base / "myconfig" / "mygit.yaml")
        assert provider.get_git_sync_config_path() == expected

    def test_get_git_sync_config_path_default(self, temp_dir):
        """Test get_git_sync_config_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config" / "git_sync.yaml")
        assert provider.get_git_sync_config_path() == expected

    def test_get_notification_config_path(self, config_file):
        """Test get_notification_config_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        base = config_file.parent.parent
        expected = str(base / "myconfig" / "mynotify.yaml")
        assert provider.get_notification_config_path() == expected

    def test_get_notification_config_path_default(self, temp_dir):
        """Test get_notification_config_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config" / "notification.yaml")
        assert provider.get_notification_config_path() == expected

    def test_get_skill_index_path(self, config_file):
        """Test get_skill_index_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        base = config_file.parent.parent
        expected = str(base / "myconfig" / "myskills.yaml")
        assert provider.get_skill_index_path() == expected

    def test_get_skill_index_path_default(self, temp_dir):
        """Test get_skill_index_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config" / "skill_index.yaml")
        assert provider.get_skill_index_path() == expected

    def test_get_file_owners_path(self, config_file):
        """Test get_file_owners_path method"""
        provider = ConfManProvider(config_path=str(config_file))
        base = config_file.parent.parent
        expected = str(base / "myconfig" / "myowners.yaml")
        assert provider.get_file_owners_path() == expected

    def test_get_file_owners_path_default(self, temp_dir):
        """Test get_file_owners_path with default fallback"""
        provider = ConfManProvider(base_dir=temp_dir)
        expected = str(temp_dir / "config" / "file_owners.yaml")
        assert provider.get_file_owners_path() == expected

    def test_get_full_path_with_base(self, temp_dir):
        """Test get_full_path with custom base"""
        provider = ConfManProvider(base_dir=temp_dir)
        result = provider.get_full_path("subdir/file.txt", Path("/custom/base"))
        assert result == Path("/custom/base/subdir/file.txt")

    def test_get_full_path_without_base(self, temp_dir):
        """Test get_full_path without custom base (uses default base_dir)"""
        provider = ConfManProvider(base_dir=temp_dir)
        result = provider.get_full_path("subdir/file.txt")
        assert result == temp_dir / "subdir/file.txt"

    def test_get_version(self, temp_dir):
        """Test get_version method"""
        provider = ConfManProvider(base_dir=temp_dir)
        assert provider.get_version() == "1.0.0"


class TestGetProvider:
    """Test get_provider singleton function"""

    def test_get_provider_creates_instance(self):
        """Test get_provider creates new instance"""
        from config_provider import _provider_instance
        import config_provider
        
        config_provider._provider_instance = None
        
        provider = get_provider()
        assert provider is not None
        assert isinstance(provider, ConfManProvider)

    def test_get_provider_returns_same_instance(self):
        """Test get_provider returns singleton"""
        import config_provider
        
        config_provider._provider_instance = None
        
        provider1 = get_provider()
        provider2 = get_provider()
        assert provider1 is provider2
