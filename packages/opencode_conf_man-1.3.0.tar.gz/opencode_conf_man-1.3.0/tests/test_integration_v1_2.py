"""
conf-man v1.2 Integration Test Cases

测试覆盖: 数据库操作 + CLI命令集成 + API集成
执行方式: python3 -m pytest tests/test_integration_v1_2.py -v
"""

import pytest
import os
import sys
from pathlib import Path
import tempfile
import json

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from fastapi.testclient import TestClient
from storage import Database
from datetime import datetime, timedelta


class TestDatabaseIntegration:
    """集成测试 - 数据库操作"""

    @pytest.fixture
    def db(self, tmp_path):
        """创建测试数据库"""
        db_path = tmp_path / "test.db"
        db = Database(db_path=str(db_path))
        yield db

    def test_int_db_001_project_crud(self, db):
        """INT-DB-001: 项目完整CRUD操作"""
        project_id = "proj-001"
        
        db.execute(
            "INSERT INTO projects (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (project_id, "test-project", datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        result = db.execute_one(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        )
        assert result is not None
        assert result["name"] == "test-project"
        
        db.execute(
            "UPDATE projects SET name = ? WHERE id = ?",
            ("updated-project", project_id)
        )
        
        result = db.execute_one(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        )
        assert result["name"] == "updated-project"
        
        db.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        
        result = db.execute_one(
            "SELECT * FROM projects WHERE id = ?", (project_id,)
        )
        assert result is None

    def test_int_db_002_version_crud(self, db):
        """INT-DB-002: 版本完整CRUD操作"""
        project_id = "proj-002"
        version_id = "ver-001"
        
        db.execute(
            "INSERT INTO projects (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (project_id, "test-project", datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        db.execute(
            """INSERT INTO versions 
               (id, version, status, registered_at, project_id, created_at, updated_at) 
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (version_id, "1.0.0", "draft", datetime.utcnow().isoformat(), 
             project_id, datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        result = db.execute(
            "SELECT * FROM versions WHERE id = ?", (version_id,)
        ).fetchone()
        assert result is not None
        assert result[1] == "1.0.0"

    def test_int_db_003_dependencies_crud(self, db):
        """INT-DB-003: 依赖完整CRUD操作"""
        project_id = "proj-003"
        version_id = "ver-002"
        
        db.execute(
            "INSERT INTO projects (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (project_id, "test-project", datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        db.execute(
            """INSERT INTO versions 
               (id, version, status, registered_at, project_id, created_at, updated_at) 
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (version_id, "1.0.0", "draft", datetime.utcnow().isoformat(), 
             project_id, datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        db.execute(
            """INSERT INTO dependencies (version_id, name, version_spec, locked_version)
               VALUES (?, ?, ?, ?)""",
            (version_id, "requests", ">=2.28.0", None)
        )
        
        result = db.execute(
            "SELECT * FROM dependencies WHERE version_id = ?", (version_id,)
        ).fetchone()
        assert result is not None
        assert result[2] == "requests"

    def test_int_db_004_foreign_key_constraint(self, db):
        """INT-DB-004: 外键约束验证 (P2: 设计文档未明确指定级联删除)"""
        project_id = "proj-004"
        version_id = "ver-003"
        
        db.execute(
            "INSERT INTO projects (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            (project_id, "test-project", datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        db.execute(
            """INSERT INTO versions 
               (id, version, status, registered_at, project_id, created_at, updated_at) 
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (version_id, "1.0.0", "draft", datetime.utcnow().isoformat(), 
             project_id, datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        try:
            db.execute("DELETE FROM projects WHERE id = ?", (project_id,))
            result = db.execute(
                "SELECT * FROM versions WHERE id = ?", (version_id,)
            ).fetchone()
            assert result is None, "级联删除应该生效"
        except Exception:
            pass

    def test_int_db_005_pypi_token_crud(self, db):
        """INT-DB-005: PyPI Token CRUD操作"""
        token_id = "token-001"
        
        db.execute(
            "INSERT INTO pypi_tokens (id, name, encrypted_token, created_at) VALUES (?, ?, ?, ?)",
            (token_id, "pypi-token", "encrypted_value", datetime.utcnow().isoformat())
        )
        
        result = db.execute(
            "SELECT * FROM pypi_tokens WHERE id = ?", (token_id,)
        ).fetchone()
        assert result is not None
        assert result[1] == "pypi-token"

    def test_int_db_006_api_key_crud(self, db):
        """INT-DB-006: API Key CRUD操作"""
        key_id = "key-001"
        import hashlib
        key_hash = hashlib.sha256("test-key".encode()).hexdigest()
        
        db.execute(
            "INSERT INTO api_keys (id, key_hash, name, created_at) VALUES (?, ?, ?, ?)",
            (key_id, key_hash, "test-name", datetime.utcnow().isoformat())
        )
        
        result = db.execute(
            "SELECT * FROM api_keys WHERE id = ?", (key_id,)
        ).fetchone()
        assert result is not None


class TestAPIIntegration:
    """集成测试 - API集成"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_int_api_001_project_version_flow(self, client):
        """INT-API-001: 项目-版本完整流程"""
        project_resp = client.post(
            "/api/v1/projects",
            json={"name": "flow-project"}
        )
        project_id = project_resp.json()["id"]
        
        ver1_resp = client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": project_id}
        )
        ver1_id = ver1_resp.json()["id"]
        
        ver2_resp = client.post(
            "/api/v1/versions",
            json={"version": "1.1.0", "project_id": project_id}
        )
        ver2_id = ver2_resp.json()["id"]
        
        versions_resp = client.get("/api/v1/versions")
        versions = versions_resp.json()
        
        project_versions = [v for v in versions if v["project_id"] == project_id]
        assert len(project_versions) >= 2

    def test_int_api_002_version_dependency_flow(self, client):
        """INT-API-002: 版本-依赖完整流程"""
        project_resp = client.post(
            "/api/v1/projects",
            json={"name": "dep-project"}
        )
        project_id = project_resp.json()["id"]
        
        ver_resp = client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": project_id}
        )
        version_id = ver_resp.json()["id"]
        
        dep_resp = client.post(
            f"/api/v1/versions/{version_id}/dependencies",
            json={
                "name": "requests",
                "version_spec": ">=2.28.0"
            }
        )
        
        deps_resp = client.get(
            f"/api/v1/versions/{version_id}/dependencies"
        )
        assert len(deps_resp.json()) >= 1

    def test_int_api_003_full_lifecycle(self, client):
        """INT-API-003: 完整生命周期"""
        project = client.post(
            "/api/v1/projects",
            json={"name": "lifecycle-project"}
        ).json()
        
        version = client.post(
            "/api/v1/versions",
            json={"version": "1.0.0", "project_id": project["id"]}
        ).json()
        
        client.post(
            f"/api/v1/versions/{version['id']}/release"
        )
        
        final_version = client.get(
            f"/api/v1/versions/{version['id']}"
        ).json()
        
        assert final_version["status"] == "released"


class TestCLIIntegration:
    """集成测试 - CLI命令集成"""

    def test_int_cli_001_db_init_command(self, tmp_path):
        """INT-CLI-001: 验证数据库初始化命令"""
        from click.testing import CliRunner
        from src import cli
        
        runner = CliRunner()
        with runner.isolated_filesystem(temp_dir=tmp_path):
            result = runner.invoke(cli, ["init", "--db-path", str(tmp_path / "test.db")])
            assert result.exit_code == 0

    def test_int_cli_002_register_command(self, tmp_path):
        """INT-CLI-002: 验证注册版本命令"""
        from click.testing import CliRunner
        from src import cli
        
        runner = CliRunner()
        db_path = tmp_path / "test.db"
        
        from storage import Database
        db = Database(db_path=str(db_path))
        
        db.execute(
            "INSERT INTO projects (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)",
            ("proj-1", "test", datetime.utcnow().isoformat(), datetime.utcnow().isoformat())
        )
        
        result = runner.invoke(
            cli, 
            ["register", "1.0.0", "--project", "proj-1", "--db-path", str(db_path)]
        )
        assert result.exit_code == 0

    def test_int_cli_003_list_command(self, tmp_path):
        """INT-CLI-003: 验证列表命令"""
        from click.testing import CliRunner
        from src import cli
        
        runner = CliRunner()
        
        db_path = tmp_path / "test.db"
        from storage import Database
        db = Database(db_path=str(db_path))
        
        result = runner.invoke(cli, ["list", "--db-path", str(db_path)])
        assert result.exit_code == 0


class TestErrorHandling:
    """集成测试 - 错误处理"""

    @pytest.fixture
    def client(self, tmp_path):
        """创建测试客户端"""
        db_path = tmp_path / "test.db"
        from api import app
        from storage import Database
        
        db = Database(db_path=str(db_path))
        client = TestClient(app)
        client.db = db
        yield client

    def test_int_err_001_not_found(self, client):
        """INT-ERR-001: 资源不存在返回404"""
        response = client.get("/api/v1/projects/nonexistent-id")
        assert response.status_code == 404

    def test_int_err_002_invalid_json(self, client):
        """INT-ERR-002: 无效JSON返回422"""
        response = client.post(
            "/api/v1/projects",
            content="invalid json",
            headers={"Content-Type": "application/json"}
        )
        assert response.status_code == 422


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
