import pytest
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

import __init__ as src_init

cli = src_init.cli
VERSION = src_init.VERSION


class TestCli:
    """Test CLI module"""

    def test_cli_version(self, runner):
        """Test CLI version"""
        result = runner.invoke(cli, ['--version'])
        assert result.exit_code == 0
        assert VERSION in result.output

    def test_cli_help(self, runner):
        """Test CLI help"""
        result = runner.invoke(cli, ['--help'])
        assert result.exit_code == 0
        assert 'conf-man' in result.output

    def test_init_command(self, runner):
        """Test init command"""
        result = runner.invoke(cli, ['init'])
        assert result.exit_code == 0
        assert 'conf-man' in result.output

    def test_list_command(self, runner):
        """Test list command"""
        result = runner.invoke(cli, ['list'])
        assert result.exit_code == 0

    def test_show_command(self, runner):
        """Test show command"""
        result = runner.invoke(cli, ['show', 'v1.0.0'])
        assert result.exit_code == 0
        assert 'v1.0.0' in result.output

    def test_register_command_missing_options(self, runner):
        """Test register command with missing options"""
        result = runner.invoke(cli, ['register', 'v1.0.0'])
        assert result.exit_code != 0

    def test_register_command(self, runner):
        """Test register command"""
        result = runner.invoke(cli, ['register', 'v1.0.0', 
                                      '--manifest', 'manifest.yaml',
                                      '--test-report', 'report.yaml'])
        assert result.exit_code == 0

    def test_release_command(self, runner):
        """Test release command"""
        result = runner.invoke(cli, ['release', 'v1.0.0'])
        assert result.exit_code == 0
        assert 'v1.0.0' in result.output


@pytest.fixture
def runner():
    """Create CLI runner"""
    from click.testing import CliRunner
    return CliRunner()
