import pytest
import sys
from pathlib import Path
import os

sys.path.insert(0, str(Path(__file__).parent.parent / 'src'))

from src.storage import Database


@pytest.fixture
def db():
    db_path = os.path.join(os.getcwd(), "state", "test_webhook.db")
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    
    if os.path.exists(db_path):
        os.remove(db_path)
    
    test_db = Database(db_path)
    yield test_db
    
    if os.path.exists(db_path):
        os.remove(db_path)


class TestWebhookRelease:
    """Test webhook release logic"""

    def test_webhook_release_success(self, db):
        """Test successful webhook release"""
        from src.api.routes import WebhookReleaseRequest, WebhookComponent
        from datetime import datetime
        
        request = WebhookReleaseRequest(
            version="1.3.0",
            components=[
                WebhookComponent(name="oc-collab", version="2.4.0"),
                WebhookComponent(name="conf-man", version="1.3.0")
            ],
            released_at="2026-02-23T10:00:00Z"
        )
        
        from src.api.routes import generate_id
        version_id = generate_id(f"ver-{request.version}")
        now = datetime.now().isoformat()
        
        manifest = {
            "version": request.version,
            "components": [c.model_dump() for c in request.components],
            "released_at": request.released_at or now
        }
        
        db.insert("versions", {
            "id": version_id,
            "version": request.version,
            "status": "registered",
            "registered_at": now,
            "git_commit_hash": "",
            "project_id": "webhook",
            "manifest": str(manifest),
            "created_at": now,
            "updated_at": now
        })
        
        versions = db.list("versions", filters={"version": "1.3.0"})
        assert len(versions) == 1
        assert versions[0]["status"] == "registered"

    def test_webhook_release_minimal(self, db):
        """Test webhook release with minimal data"""
        from src.api.routes import WebhookReleaseRequest, WebhookComponent
        from datetime import datetime
        
        request = WebhookReleaseRequest(
            version="1.3.1",
            components=[
                WebhookComponent(name="conf-man", version="1.3.0")
            ]
        )
        
        from src.api.routes import generate_id
        version_id = generate_id(f"ver-{request.version}")
        now = datetime.now().isoformat()
        
        db.insert("versions", {
            "id": version_id,
            "version": request.version,
            "status": "registered",
            "registered_at": now,
            "git_commit_hash": "",
            "project_id": "webhook",
            "manifest": str({"version": request.version, "components": []}),
            "created_at": now,
            "updated_at": now
        })
        
        versions = db.list("versions", filters={"version": "1.3.1"})
        assert len(versions) == 1

    def test_webhook_model_creation(self, db):
        """Test webhook model can be created"""
        from src.api.routes import WebhookReleaseRequest, WebhookComponent
        
        request = WebhookReleaseRequest(
            version="1.3.0",
            components=[
                WebhookComponent(name="conf-man", version="1.3.0"),
                WebhookComponent(name="oc-collab", version="2.4.0")
            ],
            released_at="2026-02-23T10:00:00Z"
        )
        
        assert request.version == "1.3.0"
        assert len(request.components) == 2
        assert request.components[0].name == "conf-man"

    def test_webhook_component_model(self, db):
        """Test webhook component model"""
        from src.api.routes import WebhookComponent
        
        comp = WebhookComponent(name="test", version="1.0.0")
        assert comp.name == "test"
        assert comp.version == "1.0.0"
