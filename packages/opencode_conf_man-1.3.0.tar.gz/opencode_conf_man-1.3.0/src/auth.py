from cryptography.fernet import Fernet
import base64
import hashlib


class TokenManager:
    def __init__(self, key: str = None):
        if key:
            self.key = key.encode() if isinstance(key, str) else key
        else:
            self.key = Fernet.generate_key()
        
        self.cipher = Fernet(self.key)
    
    def encrypt(self, token: str) -> str:
        return self.cipher.encrypt(token.encode()).decode()
    
    def decrypt(self, encrypted_token: str) -> str:
        return self.cipher.decrypt(encrypted_token.encode()).decode()
    
    def get_key(self) -> str:
        return self.key.decode()


def generate_api_key() -> str:
    return hashlib.sha256(str(Fernet.generate_key()).encode()).hexdigest()[:32]
