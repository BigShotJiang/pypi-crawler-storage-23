import os
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from config_provider import ConfManProvider
else:
    try:
        from config_provider import ConfManProvider
    except ImportError:
        ConfManProvider = None


class EnvironmentConfig:
    """Environment configuration implementation"""

    def __init__(self, config_provider: Optional["ConfManProvider"] = None):
        self._config = config_provider
        self._env = os.getenv("CONF_MAN_ENV", "dev")

    def get_environment(self) -> str:
        """Get current environment (dev/test/prod)"""
        env_from_config = None
        if self._config:
            env_from_config = self._config._config.get('environment', {}).get('mode')
        
        return env_from_config or self._env

    def is_test_mode(self) -> bool:
        """Check if running in test mode"""
        test_env = os.getenv("CONF_MAN_TEST", "")
        if test_env.lower() in ('1', 'true', 'yes'):
            return True
        
        if self._config:
            env_config = self._config._config.get('environment', {})
            if env_config.get('mode') == 'test':
                return True
        
        return self._env == 'test'
