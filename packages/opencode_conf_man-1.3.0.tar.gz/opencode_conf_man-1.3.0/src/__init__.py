#!/usr/bin/env python3
"""conf-man CLI entry point."""

import click
import sys
import json
import yaml
from pathlib import Path
from datetime import datetime

VERSION = "1.3.0"

try:
    from config_provider import ConfManProvider, get_provider
    from environment_config import EnvironmentConfig
    from storage import Database
except ImportError:
    from .config_provider import ConfManProvider, get_provider
    from .environment_config import EnvironmentConfig
    from .storage import Database

__all__ = ['ConfManProvider', 'EnvironmentConfig', 'get_provider', 'VERSION', 'cli', 'main']


@click.group()
@click.version_option(version=VERSION)
def cli():
    """conf-man: 配置管理器 - 版本的"唯一真相来源" """
    pass


def get_db():
    """获取数据库实例"""
    provider = get_provider()
    return Database(config_path=str(provider.get_config_dir()))


def ensure_init():
    """确保conf-man已初始化"""
    provider = get_provider()
    data_dir = provider.get_data_dir()
    if isinstance(data_dir, str):
        data_dir = Path(data_dir)
    versions_dir = data_dir / "versions"
    versions_dir.mkdir(parents=True, exist_ok=True)


@cli.command()
def init():
    """初始化conf-man"""
    ensure_init()
    provider = get_provider()
    click.echo(f"conf-man v{VERSION}")
    click.echo("配置管理器已初始化")
    click.echo(f"\n数据目录: {provider.get_data_dir()}")
    click.echo(f"配置目录: {provider.get_config_dir()}")
    click.echo("\n目录结构:")
    click.echo(f"  {provider.get_data_dir()}/versions/ - 版本记录")
    click.echo(f"  {provider.get_data_dir()}/state/    - 状态文件")
    click.echo(f"  {provider.get_config_dir()}/skills/ - Skill文档")


@cli.command()
@click.argument("version")
@click.option("--manifest", required=True, help="版本清单文件")
@click.option("--test-report", help="测试报告文件")
def register(version, manifest, test_report):
    """登记新版本"""
    ensure_init()
    db = get_db()
    
    version_id = f"v{version}-{datetime.now().isoformat().replace(':', '-')}"
    now = datetime.now().isoformat()
    
    manifest_data = {}
    if Path(manifest).exists():
        with open(manifest) as f:
            manifest_data = yaml.safe_load(f) or {}
    
    test_report_data = {}
    if test_report and Path(test_report).exists():
        with open(test_report) as f:
            test_report_data = yaml.safe_load(f) or {}
    
    db.insert("versions", {
        "id": version_id,
        "version": version,
        "status": "registered",
        "registered_at": now,
        "git_commit_hash": manifest_data.get("commit", ""),
        "project_id": manifest_data.get("project", "default"),
        "manifest": json.dumps(manifest_data),
        "created_at": now,
        "updated_at": now
    })
    
    click.echo(f"✓ 版本 {version} 登记完成 (ID: {version_id})")


@cli.command()
@click.option("--status", help="按状态过滤")
@click.option("--project", help="按项目过滤")
@click.option("--limit", default=100, help="返回数量限制")
def list(status, project, limit):
    """列出所有版本"""
    db = get_db()
    
    filters = {}
    if status:
        filters["status"] = status
    if project:
        filters["project_id"] = project
    
    versions = db.list("versions", filters=filters, limit=limit)
    
    if not versions:
        click.echo("暂无登记版本")
        return
    
    click.echo(f"\n{'版本ID':<35} {'版本':<15} {'状态':<15} {'登记时间':<25}")
    click.echo("-" * 90)
    for v in versions:
        click.echo(f"{v['id']:<35} {v['version']:<15} {v['status']:<15} {v.get('registered_at', '')[:25]}")


@cli.command()
@click.argument("version")
def show(version):
    """显示版本详情"""
    db = get_db()
    
    v = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version))
    
    if not v:
        click.echo(f"错误: 版本 {version} 不存在", err=True)
        return
    
    click.echo(f"\n版本详情: {v['version']}")
    click.echo("=" * 50)
    click.echo(f"  ID: {v['id']}")
    click.echo(f"  状态: {v['status']}")
    click.echo(f"  项目: {v.get('project_id', 'N/A')}")
    click.echo(f"  Git: {v.get('git_commit_hash', 'N/A')}")
    click.echo(f"  登记时间: {v.get('registered_at', 'N/A')}")
    click.echo(f"  发布时间: {v.get('released_at', 'N/A')}")
    
    manifest = v.get('manifest', '{}')
    if manifest:
        click.echo(f"  清单: {manifest[:100]}...")


@cli.command()
@click.argument("version")
def release(version):
    """触发发布"""
    db = get_db()
    now = datetime.now().isoformat()
    
    success = db.update("versions", version, {
        "status": "released",
        "released_at": now,
        "updated_at": now
    })
    
    if success:
        click.echo(f"✓ 版本 {version} 已发布")
    else:
        click.echo(f"错误: 版本 {version} 不存在", err=True)


@cli.command()
@click.argument("version")
def rollback(version):
    """回滚版本"""
    db = get_db()
    now = datetime.now().isoformat()
    
    v = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version))
    if not v:
        click.echo(f"错误: 版本 {version} 不存在", err=True)
        return
    
    success = db.update("versions", v['id'], {
        "status": "rolledback",
        "updated_at": now
    })
    
    if success:
        click.echo(f"✓ 版本 {version} 已回滚")


@cli.command()
@click.argument("version_a")
@click.argument("version_b")
def diff(version_a, version_b):
    """比较两个版本"""
    db = get_db()
    
    v1 = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version_a, version_a))
    v2 = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version_b, version_b))
    
    if not v1:
        click.echo(f"错误: 版本 {version_a} 不存在", err=True)
        return
    if not v2:
        click.echo(f"错误: 版本 {version_b} 不存在", err=True)
        return
    
    click.echo(f"\n版本比较: {v1['version']} vs {v2['version']}")
    click.echo("=" * 50)
    click.echo(f"  状态: {v1['status']} -> {v2['status']}")
    click.echo(f"  Git: {v1.get('git_commit_hash', 'N/A')} -> {v2.get('git_commit_hash', 'N/A')}")
    click.echo(f"  登记时间: {v1.get('registered_at', 'N/A')} -> {v2.get('registered_at', 'N/A')}")


@cli.command()
@click.argument("version")
@click.argument("tag")
def tag(version, tag):
    """为版本添加标签"""
    db = get_db()
    now = datetime.now().isoformat()
    
    v = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version))
    if not v:
        click.echo(f"错误: 版本 {version} 不存在", err=True)
        return
    
    manifest = json.loads(v.get('manifest', '{}'))
    tags = manifest.get('tags', [])
    tags.append(tag)
    manifest['tags'] = tags
    
    db.update("versions", v['id'], {
        "manifest": json.dumps(manifest),
        "updated_at": now
    })
    
    click.echo(f"✓ 为版本 {version} 添加标签 {tag}")


@cli.command()
@click.argument("version")
@click.option("--format", default="yaml", type=click.Choice(["yaml", "json"]))
def export(version, format):
    """导出版本"""
    db = get_db()
    
    v = db.execute_one("SELECT * FROM versions WHERE version = ? OR id = ?", (version, version))
    if not v:
        click.echo(f"错误: 版本 {version} 不存在", err=True)
        return
    
    output_data = {
        "version": v["version"],
        "status": v["status"],
        "project_id": v.get("project_id"),
        "git_commit_hash": v.get("git_commit_hash"),
        "registered_at": v.get("registered_at"),
        "released_at": v.get("released_at"),
    }
    
    if format == "json":
        click.echo(json.dumps(output_data, indent=2))
    else:
        click.echo(yaml.dump(output_data))


@cli.command()
@click.argument("file")
def import_version(file):
    """导入版本"""
    path = Path(file)
    if not path.exists():
        click.echo(f"错误: 文件 {file} 不存在", err=True)
        return
    
    with open(path) as f:
        if path.suffix in ['.yaml', '.yml']:
            data = yaml.safe_load(f)
        else:
            data = json.load(f)
    
    db = get_db()
    now = datetime.now().isoformat()
    version_id = f"v{data.get('version', 'imported')}-{now}"
    
    db.insert("versions", {
        "id": version_id,
        "version": data.get("version", "imported"),
        "status": data.get("status", "imported"),
        "registered_at": data.get("registered_at", now),
        "git_commit_hash": data.get("git_commit_hash", ""),
        "project_id": data.get("project_id", "default"),
        "manifest": json.dumps(data),
        "created_at": now,
        "updated_at": now
    })
    
    click.echo(f"✓ 版本导入成功 (ID: {version_id})")


@cli.command()
@click.option("--host", default="127.0.0.1", help="API服务器主机")
@click.option("--port", default=8000, help="API服务器端口")
def serve(host, port):
    """启动API服务器"""
    click.echo(f"启动API服务器 {host}:{port}...")
    import uvicorn
    from src.api import app
    uvicorn.run(app, host=host, port=port)


def main():
    cli()


if __name__ == "__main__":
    main()
