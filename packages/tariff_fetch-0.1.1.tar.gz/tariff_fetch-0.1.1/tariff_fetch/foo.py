"""Example module."""


def hello_world() -> str:
    """Return a greeting."""
    return "Hello, World!"
