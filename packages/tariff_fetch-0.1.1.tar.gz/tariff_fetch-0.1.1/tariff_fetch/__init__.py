"""This is a repository for modern data science projects.."""

__version__ = "0.1.0"
