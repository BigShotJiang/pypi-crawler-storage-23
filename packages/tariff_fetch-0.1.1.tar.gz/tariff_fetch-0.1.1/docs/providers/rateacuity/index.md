# Rate Acuity

Rate Acuity provides US utility rate data for both electricity and gas through their web portal.

## Overview

- **Product**: Web Portal
- **Energy Types**: Electricity, Gas
- **Coverage**: US utilities
- **Data Format**: CSV
- **Authentication**: Account required

## Data Format

COMING SOON.

## Features

Rate Acuity offers:

- Electricity and gas tariff data (unlike Arcadia/NREL which are electricity-only)
- Web-based interface for browsing rates
- Export functionality for rate data

## Use Cases

Rate Acuity is useful when:

- You need gas tariff data (not available in Arcadia or NREL)
- You want a second source to validate electricity rates
- You want a web portal interface for manual lookups

## Resources

- [Rate Acuity Website](https://www.rateacuity.com/)

## Contributing

If you'd like to help implement Rate Acuity support, see the [contributing guide](../../wiki/index.md#contributing).
