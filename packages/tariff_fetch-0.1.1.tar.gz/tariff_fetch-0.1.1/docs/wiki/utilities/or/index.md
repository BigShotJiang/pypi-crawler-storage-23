# Orange & Rockland Utilities (O&R)

**LSE ID**: 691
**Region**: Rockland County, parts of Orange County, NY; northern New Jersey
**Service Types**: Electricity, Gas

## Overview

Orange & Rockland Utilities, Inc. (O&R) serves Rockland County and parts of Orange County in New York and adjacent areas in northern New Jersey. The default residential electric rate is Rate 1, with **seasonal** delivery (Summer/Winter) and standard NY policy riders.

## Service Territory

Single primary territory (territoryId 760) for default residential; connection type (e.g. secondary) affects applicability.

## Residential Tariffs

| Tariff | Name        | Type    | Key Feature                    | Guide                                |
| ------ | ----------- | ------- | ------------------------------ | ------------------------------------ |
| 1      | Residential | Default | Seasonal delivery; flat supply | [View Guide](residential-1/index.md) |

## Key Characteristics

- **Seasonal delivery**: Summer and Winter volumetric delivery rates; no TOU.
- **Supply**: Market Supply Charge (lookup) and Energy Cost Adjustment.
- **NY riders**: RDM, SBC, DLM, CBC (solar), EV Make-Ready, Energy Storage, Transition, Delivery Revenue Surcharge.
- **Low-income**: Low Income Bill Credit and Enhanced Energy Affordability Credits by tier.

## Regulatory Context

- NY PSC (NY service). Revenue decoupling, Clean Energy Standard, system benefits, and NY-mandated riders apply. O&R also operates in NJ under that state’s regulation where applicable.

## Data Sources

- [Orange & Rockland Rates](https://www.oru.com/)
- [NY PSC](https://www.dps.ny.gov/)
- Arcadia Signal API (LSE ID: 691)
