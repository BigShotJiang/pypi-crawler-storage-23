# PSEG Long Island (PSEG-LI)

**LSE ID**: 200
**Region**: Long Island, NY (Nassau, Suffolk, Rockaway Peninsula)
**Service Types**: Electricity

## Overview

PSEG Long Island operates the electric grid for the Long Island Power Authority (LIPA), serving Nassau County, Suffolk County, and the Rockaway Peninsula in New York City. Approximately 420,000 residential customers are on the default Rate 194 (time-of-use). LIPA owns the assets; PSEG-LI is the contract operator.

## Service Territory

| Territory       | Territory ID | Area              |
| --------------- | ------------ | ----------------- |
| Suffolk         | 3567         | Suffolk County    |
| Outside Suffolk | 3711         | Nassau, Rockaways |

## Residential Tariffs

| Tariff | Name        | Type    | Key Feature                | Guide                                  |
| ------ | ----------- | ------- | -------------------------- | -------------------------------------- |
| 194    | Residential | Default | TOU (peak 3–7 PM weekdays) | [View Guide](residential-194/index.md) |

## Key Characteristics

- **Default is TOU**: Rate 194 has peak/off-peak and summer/winter; optional flat Rate 180 and super off-peak Rate 195 available with bill protection.
- **Deregulated supply**: Customers may choose an ESCO; default supply and delivery from PSEG-LI.
- **Territory**: Suffolk vs outside Suffolk affects Shoreham Property Tax (SPT) and other zone-specific charges.
- **LIPA/PSEG**: Tariffs filed with NY PSC; LIPA sets policy.

## Regulatory Context

- NY PSC regulates rates and tariffs. LIPA is a state authority; PSEG-LI operates under contract.
- NY Clean Energy Standard, revenue decoupling, and demand response (DLM) apply.
- Shoreham-related property tax and securitization charges are Long Island–specific.

## Data Sources

- [PSEG Long Island Rates](https://www.psegliny.com/aboutpseglongisland/ratesandtariffs/rateinformation)
- [LIPA Tariff](https://www.lipower.org/)
- Arcadia Signal API (LSE ID: 200)
