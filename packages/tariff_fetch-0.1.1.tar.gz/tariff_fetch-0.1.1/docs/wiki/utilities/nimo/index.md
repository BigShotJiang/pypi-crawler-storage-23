# National Grid – New York (Niagara Mohawk)

**LSE ID**: 579
**Region**: Upstate New York (Adirondack, Capital, Central, Frontier, Genesee, Utica)
**Service Types**: Electricity, Gas

## Overview

National Grid – New York (formerly Niagara Mohawk) serves a large portion of Upstate New York across six delivery zones. The default residential rate is SC1 (Residential and Farm). Delivery and supply rates are **zone-specific**; the tariff has many rate entries per zone.

## Service Territory

| Zone       | Territory ID | Area           |
| ---------- | ------------ | -------------- |
| Adirondack | 3628         | North          |
| Capital    | 3631         | Albany area    |
| Central    | 3627         | Syracuse area  |
| Frontier   | 3625         | Western NY     |
| Genesee    | 3626         | Rochester area |
| Utica      | 3629         | Utica area     |

## Residential Tariffs

| Tariff | Name                 | Type    | Key Feature                 | Guide                                  |
| ------ | -------------------- | ------- | --------------------------- | -------------------------------------- |
| SC1    | Residential and Farm | Default | Zone-specific; flat, no TOU | [View Guide](residential-sc1/index.md) |

## Key Characteristics

- **Zone-specific**: Six territories; delivery and electricity supply charges vary by zone.
- **Flat, no TOU**: Single energy and supply rate per zone (plus adjustments).
- **Optional**: GreenUp (renewable) and low-income credits are eligibility-based.
- **NY riders**: CBC (solar), EV Make Ready, arrears recovery, RAM, EAM, DLM, SBC, CES.

## Regulatory Context

- NY PSC. Revenue decoupling, Clean Energy Standard, system benefits, and NY-mandated riders apply. GreenUp is an optional renewable product.

## Data Sources

- [National Grid NY Rates](https://www.nationalgridus.com/niagaramohawk)
- [NY PSC](https://www.dps.ny.gov/)
- Arcadia Signal API (LSE ID: 579)
