# Rhode Island Energy (RIE)

**LSE ID**: 507
**Region**: State of Rhode Island
**Service Types**: Electricity, Gas

## Overview

Rhode Island Energy (RIE), formerly National Grid – Rhode Island, is the primary electric and gas utility in Rhode Island. The default residential electric rate is **A-16**, the basic residential rate for most homes (including church and farm). Bills are split into **delivery** (RIE) and **supply** (default Last Resort Service or competitive supplier).

## Service Territory

Statewide Rhode Island (territoryId 545). Connection type and phase affect applicability for some rates.

## Residential Tariffs

| Tariff | Name        | Type    | Key Feature                 | Guide                                  |
| ------ | ----------- | ------- | --------------------------- | -------------------------------------- |
| A-16   | Residential | Default | Flat; many delivery factors | [View Guide](residential-a16/index.md) |

## Key Characteristics

- **Flat, no TOU**: Single delivery and supply rate structure.
- **Delivery**: Customer charge, distribution, O&M, CapEx, RDM, pension, storm, arrearage, LMI, performance, last resort, net metering, long-term contracting, RE distribution, RE growth, LIHEAP, transmission, transition, energy efficiency; many factors are variable (lookups).
- **Supply**: Standard Offer Service (Last Resort Service); variable; customers may shop for competitive supply.
- **Gross Earnings Tax**: Pass-through tax on utility earnings.

## Regulatory Context

- Rhode Island Public Utilities Commission. Last Resort Service and competitive supply are overseen by the state. LIHEAP, energy efficiency, and renewable programs are state-mandated.

## Data Sources

- [Rhode Island Energy Tariffs](https://www.rienergy.com/RI-Home/Rates/Tariff-Provisions)
- [Residential Service Rates](https://www.rienergy.com/site/ways-to-save/rates-and-shopping/service-rates/residential-service-rates)
- Arcadia Signal API (LSE ID: 507)
