class Paint:
    BLACK   = "\033[30m"
    RED     = "\033[31m"
    GREEN   = "\033[32m"
    YELLOW  = "\033[33m"
    BLUE    = "\033[34m"
    MAGENTA = "\033[35m"
    CYAN    = "\033[36m"
    WHITE   = "\033[37m"

    BRIGHT_BLACK   = "\033[90m"
    BRIGHT_RED     = "\033[91m"
    BRIGHT_GREEN   = "\033[92m"
    BRIGHT_YELLOW  = "\033[93m"
    BRIGHT_BLUE    = "\033[94m"
    BRIGHT_MAGENTA = "\033[95m"
    BRIGHT_CYAN    = "\033[96m"
    BRIGHT_WHITE   = "\033[97m"

    BG_BLACK   = "\033[40m"
    BG_RED     = "\033[41m"
    BG_GREEN   = "\033[42m"
    BG_YELLOW  = "\033[43m"
    BG_BLUE    = "\033[44m"
    BG_MAGENTA = "\033[45m"
    BG_CYAN    = "\033[46m" 
    BG_WHITE   = "\033[47m"

    RESET       = "\033[0m" 
    BOLD        = "\033[1m"
    UNDERLINE   = "\033[4m"
    REVERSED    = "\033[7m"

    def __init__(self, texts, sep, end):
        self.texts = texts
        self.sep = sep
        self.end = end
        self.codes = []

    def show(self):
        print(self, end=self.end)

    def black(self) -> Paint:
        self.codes.append(Paint.BLACK)
        return self
        
    def red(self) -> Paint:
        self.codes.append(Paint.RED)
        return self

    def green(self) -> Paint:
        self.codes.append(Paint.GREEN)
        return self

    def yellow(self) -> Paint:
        self.codes.append(Paint.YELLOW)
        return self

    def blue(self) -> Paint:
        self.codes.append(Paint.BLUE)
        return self

    def magenta(self) -> Paint:
        self.codes.append(Paint.MAGENTA)
        return self

    def cyan(self) -> Paint:
        self.codes.append(Paint.CYAN)
        return self

    def white(self) -> Paint:
        self.codes.append(Paint.WHITE)
        return self

    def bright_black(self) -> Paint:
        self.codes.append(Paint.BRIGHT_BLACK)
        return self

    def bright_red(self) -> Paint:
        self.codes.append(Paint.BRIGHT_RED)
        return self

    def bright_green(self) -> Paint:
        self.codes.append(Paint.BRIGHT_GREEN)
        return self

    def bright_yellow(self) -> Paint:
        self.codes.append(Paint.BRIGHT_YELLOW)
        return self

    def bright_blue(self) -> Paint:
        self.codes.append(Paint.BRIGHT_BLUE)
        return self

    def bright_magenta(self) -> Paint:
        self.codes.append(Paint.BRIGHT_MAGENTA)
        return self

    def bright_cyan(self) -> Paint:
        self.codes.append(Paint.BRIGHT_CYAN)
        return self

    def bright_white(self) -> Paint:
        self.codes.append(Paint.BRIGHT_WHITE)
        return self

    def bg_black(self) -> Paint:
        self.codes.append(Paint.BG_BLACK)
        return self

    def bg_red(self) -> Paint:
        self.codes.append(Paint.BG_RED)
        return self

    def bg_green(self) -> Paint:
        self.codes.append(Paint.BG_GREEN)
        return self

    def bg_yellow(self) -> Paint:
        self.codes.append(Paint.BG_YELLOW)
        return self

    def bg_blue(self) -> Paint:
        self.codes.append(Paint.BG_BLUE)
        return self

    def bg_magenta(self) -> Paint:
        self.codes.append(Paint.BG_MAGENTA)
        return self

    def bg_cyan(self) -> Paint:
        self.codes.append(Paint.BG_CYAN)
        return self

    def bg_white(self) -> Paint:
        self.codes.append(Paint.BG_WHITE)
        return self

    def bold(self) -> Paint:
        self.codes.append(Paint.BOLD)
        return self

    def underline(self) -> Paint:
        self.codes.append(Paint.UNDERLINE)
        return self

    def reversed(self) -> Paint:
        self.codes.append(Paint.REVERSED)
        return self

    def __str__(self):
        texts = self.sep.join(str(text) for text in self.texts)
        codes = "".join(self.codes)

        return f"{codes}{texts}{Paint.RESET}"

def paint(*texts, sep = " ", end = "\n") -> Paint:
    return Paint(texts, sep, end)
