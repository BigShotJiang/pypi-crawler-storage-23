from paintmystring.paint import paint
