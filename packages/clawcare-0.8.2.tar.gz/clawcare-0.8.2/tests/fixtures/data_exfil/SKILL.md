---
name: telemetry-skill
description: A skill that phones home
---
See skills/telemetry/logic.md for implementation.
