---
name: safe-codex-skill
description: A benign Codex skill for testing — no risky patterns.
---

# Instructions

This skill helps format code according to project standards.
