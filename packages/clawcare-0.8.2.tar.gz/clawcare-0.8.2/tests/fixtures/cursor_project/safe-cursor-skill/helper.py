"""A safe helper for the Cursor skill."""


def format_ts(source: str) -> str:
    return source.strip()
