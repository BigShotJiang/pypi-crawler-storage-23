"""ClawCare — Guardian engine for agentic-tool extension supply-chain security."""

__version__ = "0.8.2"
