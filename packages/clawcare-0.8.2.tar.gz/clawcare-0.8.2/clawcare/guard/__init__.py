"""ClawCare Guard — runtime command interception and audit (v0.3.0)."""
