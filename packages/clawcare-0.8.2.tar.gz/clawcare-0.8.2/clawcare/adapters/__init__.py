"""Adapter framework — protocol, registry, and selection logic."""
