from .chat import ChatCompletions


class _Chat:
    def __init__(self, client):
        self.completions = ChatCompletions(client)


class SynteriaAI:
    def __init__(self, api_key: str,
                 base_url: str = "http://site34802.web1.titanaxe.com"):
        self.api_key = api_key
        self.base_url = base_url
        self.chat = _Chat(self)