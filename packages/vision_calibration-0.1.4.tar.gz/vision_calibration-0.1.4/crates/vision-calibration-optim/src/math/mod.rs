//! Shared math utilities used by multiple optimization problems.

pub mod projection;
