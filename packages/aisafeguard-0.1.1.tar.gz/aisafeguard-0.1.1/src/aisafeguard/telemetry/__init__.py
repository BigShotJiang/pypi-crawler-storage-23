"""Telemetry and observability for AISafe Guard."""
