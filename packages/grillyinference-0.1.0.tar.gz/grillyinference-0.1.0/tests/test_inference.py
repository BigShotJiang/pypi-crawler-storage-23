"""Tests for the GrillyInference package.

CPU-only tests covering model config, RMSNorm, KV cache, quantization,
layer offloading, and text generation utilities.
"""

import sys
from unittest.mock import MagicMock

import numpy as np
import pytest

# ---------------------------------------------------------------------------
# Seed for reproducibility
# ---------------------------------------------------------------------------
np.random.seed(42)

# ---------------------------------------------------------------------------
# Ensure the package is importable from the repo root.
# ---------------------------------------------------------------------------
sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))

from grillyinference.inference.model_config import LlamaConfig
from grillyinference.inference.rms_norm import RMSNorm
from grillyinference.inference.kv_cache import KVCache
from grillyinference.inference.quantize import (
    BlockQuantizer4Bit,
    SmoothQuantCalibrator,
    SmoothQuantizer,
)
from grillyinference.inference.offload import LayerOffloader
from grillyinference.inference.generate import TextGenerator, _sample_top_k_top_p


# =========================================================================
# 1. TestLlamaConfig
# =========================================================================
class TestLlamaConfig:
    """Tests for LlamaConfig dataclass."""

    def test_default_values(self):
        cfg = LlamaConfig()
        assert cfg.num_layers == 28
        assert cfg.hidden_dim == 3072
        assert cfg.num_heads == 24
        assert cfg.num_kv_heads == 8
        assert cfg.head_dim == 128
        assert cfg.vocab_size == 128256

    def test_default_extra_fields(self):
        cfg = LlamaConfig()
        assert cfg.intermediate_size == 8192
        assert cfg.rope_theta == 500000.0
        assert cfg.rms_norm_eps == 1e-5
        assert cfg.max_seq_len == 4096
        assert cfg.tie_word_embeddings is True
        assert cfg.bos_token_id == 128000
        assert cfg.eos_token_id == 128001
        assert cfg.model_type == "llama"

    def test_from_dict_basic(self):
        d = {
            "num_hidden_layers": 12,
            "hidden_size": 768,
            "num_attention_heads": 12,
            "num_key_value_heads": 4,
            "head_dim": 64,
            "vocab_size": 32000,
        }
        cfg = LlamaConfig.from_dict(d)
        assert cfg.num_layers == 12
        assert cfg.hidden_dim == 768
        assert cfg.num_heads == 12
        assert cfg.num_kv_heads == 4
        assert cfg.head_dim == 64
        assert cfg.vocab_size == 32000

    def test_from_dict_preserves_unmapped_fields(self):
        """from_dict should also pick up fields that share the dataclass name."""
        d = {"rope_theta": 10000.0, "rms_norm_eps": 1e-6}
        cfg = LlamaConfig.from_dict(d)
        assert cfg.rope_theta == 10000.0
        assert cfg.rms_norm_eps == 1e-6

    def test_custom_values_override_defaults(self):
        cfg = LlamaConfig(num_layers=32, hidden_dim=4096, num_heads=32,
                          num_kv_heads=8, head_dim=128, vocab_size=50000)
        assert cfg.num_layers == 32
        assert cfg.hidden_dim == 4096
        assert cfg.num_heads == 32
        assert cfg.num_kv_heads == 8
        assert cfg.head_dim == 128
        assert cfg.vocab_size == 50000

    def test_num_kv_groups_property(self):
        cfg = LlamaConfig(num_heads=24, num_kv_heads=8)
        assert cfg.num_kv_groups == 3

    def test_to_dict_round_trip(self):
        cfg = LlamaConfig()
        d = cfg.to_dict()
        assert d["num_layers"] == 28
        assert d["hidden_dim"] == 3072
        cfg2 = LlamaConfig(**d)
        assert cfg2 == cfg


# =========================================================================
# 2. TestRMSNorm
# =========================================================================
class TestRMSNorm:
    """Tests for the CPU RMSNorm implementation."""

    def test_forward_known_values(self):
        """RMSNorm of a constant vector with unit weight should normalise."""
        norm = RMSNorm(eps=1e-5)
        x = np.array([[2.0, 2.0, 2.0, 2.0]], dtype=np.float32)
        weight = np.ones(4, dtype=np.float32)
        out = norm.forward(x, weight)
        # RMS of [2,2,2,2] = 2, so normalised = [1,1,1,1]
        np.testing.assert_allclose(out, np.ones_like(x), atol=1e-4)

    def test_output_shape_matches_input_2d(self):
        norm = RMSNorm()
        x = np.random.randn(3, 64).astype(np.float32)
        weight = np.ones(64, dtype=np.float32)
        out = norm.forward(x, weight)
        assert out.shape == x.shape

    def test_output_shape_matches_input_3d(self):
        norm = RMSNorm()
        x = np.random.randn(2, 5, 128).astype(np.float32)
        weight = np.ones(128, dtype=np.float32)
        out = norm.forward(x, weight)
        assert out.shape == x.shape

    def test_eps_parameter(self):
        """Different eps values should produce slightly different results for
        near-zero inputs, but converge for normal-magnitude inputs."""
        x = np.array([[1e-6, 1e-6]], dtype=np.float32)
        weight = np.ones(2, dtype=np.float32)
        out_small_eps = RMSNorm(eps=1e-12).forward(x, weight)
        out_large_eps = RMSNorm(eps=1.0).forward(x, weight)
        # With a large eps the denominator is dominated by eps,
        # so the output magnitude should be much smaller.
        assert np.max(np.abs(out_large_eps)) < np.max(np.abs(out_small_eps))

    def test_eps_override_in_forward(self):
        """The forward-level eps kwarg should take precedence."""
        norm = RMSNorm(eps=1e-5)
        x = np.array([[1e-6, 1e-6]], dtype=np.float32)
        weight = np.ones(2, dtype=np.float32)
        out_default = norm.forward(x, weight)
        out_overridden = norm.forward(x, weight, eps=1.0)
        assert not np.allclose(out_default, out_overridden)

    def test_different_feature_dimensions(self):
        norm = RMSNorm()
        for dim in [16, 64, 256, 1024]:
            x = np.random.randn(2, dim).astype(np.float32)
            weight = np.random.randn(dim).astype(np.float32)
            out = norm.forward(x, weight)
            assert out.shape == x.shape
            # Output should be finite
            assert np.all(np.isfinite(out))

    def test_preserves_dtype(self):
        norm = RMSNorm()
        x = np.random.randn(2, 8).astype(np.float16)
        weight = np.ones(8, dtype=np.float16)
        out = norm.forward(x, weight)
        assert out.dtype == np.float16

    def test_weight_scaling(self):
        """Weight of 2.0 everywhere should double the unit-weight output."""
        norm = RMSNorm()
        x = np.random.randn(1, 8).astype(np.float32)
        w1 = np.ones(8, dtype=np.float32)
        w2 = np.full(8, 2.0, dtype=np.float32)
        out1 = norm.forward(x, w1)
        out2 = norm.forward(x, w2)
        np.testing.assert_allclose(out2, 2.0 * out1, atol=1e-5)


# =========================================================================
# 3. TestKVCache (paged)
# =========================================================================
class TestKVCache:
    """Tests for the paged KVCache."""

    @pytest.fixture()
    def small_config(self):
        """A minimal config for fast cache tests."""
        return LlamaConfig(
            num_layers=2,
            hidden_dim=64,
            num_heads=4,
            num_kv_heads=2,
            head_dim=32,
            vocab_size=256,
        )

    def test_initialization(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        assert cache.num_layers == 2
        assert cache.num_kv_heads == 2
        assert cache.head_dim == 32
        assert cache.seq_length == 0
        assert len(cache._k_raw) == 2
        assert len(cache._v_raw) == 2
        for k in cache._k_raw:
            assert k.shape == (1, 2, 16, 32)

    def test_update_adds_kv_entries(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        new_k = np.random.randn(1, 2, 4, 32).astype(np.float32)
        new_v = np.random.randn(1, 2, 4, 32).astype(np.float32)
        k_out, v_out = cache.update(0, new_k, new_v)
        assert k_out.shape == (1, 2, 4, 32)
        assert v_out.shape == (1, 2, 4, 32)

    def test_update_decode_single_token(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        # Prefill 4 tokens on layer 0
        k_pre = np.random.randn(1, 2, 4, 32).astype(np.float32)
        v_pre = np.random.randn(1, 2, 4, 32).astype(np.float32)
        cache.update(0, k_pre, v_pre)
        # Decode 1 token
        k_dec = np.random.randn(1, 2, 1, 32).astype(np.float32)
        v_dec = np.random.randn(1, 2, 1, 32).astype(np.float32)
        k_out, v_out = cache.update(0, k_dec, v_dec)
        # Should now contain 5 tokens
        assert k_out.shape[2] == 5
        assert v_out.shape[2] == 5

    def test_get_retrieves_correct_entries(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        k_in = np.random.randn(1, 2, 3, 32).astype(np.float32)
        v_in = np.random.randn(1, 2, 3, 32).astype(np.float32)
        cache.update(0, k_in, v_in)
        k_got, v_got = cache.get(0)
        assert k_got.shape == (1, 2, 3, 32)
        assert v_got.shape == (1, 2, 3, 32)
        np.testing.assert_allclose(
            k_got.astype(np.float32), k_in.astype(np.float16).astype(np.float32),
            atol=1e-2,
        )

    def test_clear_resets_cache(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        k_in = np.random.randn(1, 2, 5, 32).astype(np.float32)
        v_in = np.random.randn(1, 2, 5, 32).astype(np.float32)
        cache.update(0, k_in, v_in)
        assert cache.seq_length == 5
        cache.clear()
        assert cache.seq_length == 0
        k_got, v_got = cache.get(0)
        assert k_got.shape[2] == 0
        assert v_got.shape[2] == 0

    def test_seq_length_tracks_position(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=64)
        assert cache.seq_length == 0
        # Prefill 10 tokens (layer 0 drives seq_pos)
        cache.update(0, np.zeros((1, 2, 10, 32), dtype=np.float32),
                     np.zeros((1, 2, 10, 32), dtype=np.float32))
        assert cache.seq_length == 10
        # Decode 1 more token
        cache.update(0, np.zeros((1, 2, 1, 32), dtype=np.float32),
                     np.zeros((1, 2, 1, 32), dtype=np.float32))
        assert cache.seq_length == 11

    def test_multiple_layers_independent(self, small_config):
        cache = KVCache(small_config, max_batch=1, raw_window=16)
        k0 = np.random.randn(1, 2, 4, 32).astype(np.float32)
        v0 = np.random.randn(1, 2, 4, 32).astype(np.float32)
        k1 = np.random.randn(1, 2, 4, 32).astype(np.float32)
        v1 = np.random.randn(1, 2, 4, 32).astype(np.float32)
        cache.update(0, k0, v0)
        cache.update(1, k1, v1)
        got_k0, _ = cache.get(0)
        got_k1, _ = cache.get(1)
        # Layer 0 and layer 1 should hold independent data
        assert not np.allclose(got_k0.astype(np.float32),
                               got_k1.astype(np.float32), atol=1e-2)


# =========================================================================
# 4. TestSmoothQuantCalibrator
# =========================================================================
class TestSmoothQuantCalibrator:
    """Tests for SmoothQuantCalibrator (uses mock model/tokenizer)."""

    @pytest.fixture()
    def mock_model_and_tokenizer(self):
        """Create a mock model with a few projection weights."""
        model = MagicMock()
        model._weights = {
            "layers.0.self_attn.q_proj.weight": np.random.randn(64, 64).astype(np.float32),
            "layers.0.self_attn.k_proj.weight": np.random.randn(64, 64).astype(np.float32),
            "layers.0.mlp.gate_proj.weight": np.random.randn(128, 64).astype(np.float32),
            "layers.0.embed_tokens.weight": np.random.randn(256, 64).astype(np.float32),
        }
        model.prefill.return_value = (np.zeros((1, 4, 256)), None)
        tokenizer = MagicMock()
        tokenizer.encode.return_value = [1, 2, 3, 4]
        return model, tokenizer

    def test_calibrate_collects_stats(self, mock_model_and_tokenizer):
        model, tokenizer = mock_model_and_tokenizer
        calibrator = SmoothQuantCalibrator(model, tokenizer, num_samples=4, num_passes=1)
        prompts = ["Hello world"] * 4
        stats = calibrator.calibrate(prompts)
        # Should collect stats for weights containing "proj.weight"
        assert len(stats) > 0
        for name in stats:
            assert "proj.weight" in name
            assert "max_abs" in stats[name]
            assert "percentile_99_9" in stats[name]
            assert "std" in stats[name]
            assert "channel_std" in stats[name]

    def test_calibrate_stat_values_are_positive(self, mock_model_and_tokenizer):
        model, tokenizer = mock_model_and_tokenizer
        calibrator = SmoothQuantCalibrator(model, tokenizer, num_samples=2, num_passes=1)
        stats = calibrator.calibrate(["test"] * 2)
        for name, s in stats.items():
            assert s["max_abs"] >= 0
            assert s["percentile_99_9"] >= 0
            assert s["std"] >= 0

    def test_smooth_weights_produces_correct_shapes(self, mock_model_and_tokenizer):
        """After calibration, a SmoothQuantizer should produce correctly-shaped
        smooth + quantized outputs."""
        model, tokenizer = mock_model_and_tokenizer
        calibrator = SmoothQuantCalibrator(model, tokenizer, num_samples=2, num_passes=1)
        stats = calibrator.calibrate(["test"] * 2)

        quantizer = SmoothQuantizer(group_size=32)
        quantized = quantizer.smooth_and_quantize(model._weights, stats,
                                                  quantize_patterns=["proj.weight"])
        for name, qdata in quantized.items():
            orig_shape = qdata["original_shape"]
            assert qdata["weights_int8"].shape == orig_shape
            assert qdata["smoothing_scales"].shape[0] == orig_shape[1]


# =========================================================================
# 5. TestSmoothQuantizer
# =========================================================================
class TestSmoothQuantizer:
    """Tests for SmoothQuantizer INT8 quantization."""

    @pytest.fixture()
    def sample_weights(self):
        return {
            "gate_proj.weight": np.random.randn(128, 64).astype(np.float32),
            "up_proj.weight": np.random.randn(128, 64).astype(np.float32),
            "down_proj.weight": np.random.randn(64, 128).astype(np.float32),
            "embed.weight": np.random.randn(256, 64).astype(np.float32),
        }

    @pytest.fixture()
    def dummy_stats(self, sample_weights):
        stats = {}
        for name, w in sample_weights.items():
            stats[name] = {
                "max_abs": float(np.max(np.abs(w))),
                "percentile_99_9": float(np.percentile(np.abs(w), 99.9)),
                "std": float(np.std(w)),
                "channel_std": np.std(w, axis=0).astype(np.float32),
            }
        return stats

    def test_quantize_produces_int8_and_fp32_scales(self, sample_weights, dummy_stats):
        q = SmoothQuantizer(group_size=32)
        result = q.smooth_and_quantize(sample_weights, dummy_stats)
        # Only gate_proj, up_proj, down_proj should be quantized (default patterns)
        assert "gate_proj.weight" in result
        assert "up_proj.weight" in result
        assert "down_proj.weight" in result
        assert "embed.weight" not in result
        for name, data in result.items():
            assert data["weights_int8"].dtype == np.int8
            assert data["weight_scales"].dtype == np.float16

    def test_output_shapes_for_given_group_size(self, sample_weights, dummy_stats):
        group_size = 32
        q = SmoothQuantizer(group_size=group_size)
        result = q.smooth_and_quantize(sample_weights, dummy_stats)
        for name, data in result.items():
            orig = sample_weights[name]
            out_features, in_features = orig.shape
            num_groups = (in_features + group_size - 1) // group_size
            assert data["weights_int8"].shape == orig.shape
            assert data["weight_scales"].shape == (out_features, num_groups)
            assert data["smoothing_scales"].shape == (in_features,)

    def test_round_trip_quantize_dequantize(self, sample_weights, dummy_stats):
        """Quantise to INT8 then dequantise; the error should be small."""
        group_size = 32
        q = SmoothQuantizer(group_size=group_size)
        result = q.smooth_and_quantize(sample_weights, dummy_stats)

        for name, data in result.items():
            w_int8 = data["weights_int8"]
            scales = data["weight_scales"].astype(np.float32)
            smooth = data["smoothing_scales"].astype(np.float32)
            orig = sample_weights[name].astype(np.float32)

            # Dequantize
            out_f, in_f = w_int8.shape
            w_deq = np.zeros_like(orig)
            num_groups = scales.shape[1]
            for g in range(num_groups):
                start = g * group_size
                end = min(start + group_size, in_f)
                w_deq[:, start:end] = w_int8[:, start:end].astype(np.float32) * scales[:, g:g+1]

            # Undo smoothing: original ~= w_deq / alpha
            w_reconstructed = w_deq / smooth[np.newaxis, :]

            # Relative error check (allow ~10% for INT8 quantization noise)
            abs_err = np.abs(orig - w_reconstructed)
            scale_ref = np.maximum(np.abs(orig), 1e-6)
            rel_err = np.mean(abs_err / scale_ref)
            assert rel_err < 0.15, f"{name}: mean relative error {rel_err:.3f} too large"

    def test_different_group_sizes(self, sample_weights, dummy_stats):
        for gs in [16, 32, 64, 128]:
            q = SmoothQuantizer(group_size=gs)
            result = q.smooth_and_quantize(sample_weights, dummy_stats)
            for name, data in result.items():
                out_f, in_f = sample_weights[name].shape
                num_groups = (in_f + gs - 1) // gs
                assert data["weight_scales"].shape == (out_f, num_groups)


# =========================================================================
# 6. TestBlockQuantizer4Bit
# =========================================================================
class TestBlockQuantizer4Bit:
    """Tests for 4-bit block quantization."""

    @pytest.fixture()
    def weights_dict(self):
        return {
            "layer.0.mlp.gate_proj.weight": np.random.randn(128, 64).astype(np.float32),
            "layer.0.mlp.up_proj.weight": np.random.randn(128, 64).astype(np.float32),
            "layer.0.bias": np.random.randn(128).astype(np.float32),  # no "weight" -> skipped
        }

    def test_quantize_produces_packed_weights(self, weights_dict):
        bq = BlockQuantizer4Bit(block_size=64)
        result = bq.quantize(weights_dict)
        # Only entries with "weight" in the name should be quantized
        assert "layer.0.mlp.gate_proj.weight" in result
        assert "layer.0.mlp.up_proj.weight" in result
        assert "layer.0.bias" not in result

        for name, data in result.items():
            assert data["weights_4bit"].dtype == np.uint8
            assert data["scales"].dtype == np.float16
            assert data["zeros"].dtype == np.float16

    def test_output_shapes_correct(self, weights_dict):
        block_size = 64
        bq = BlockQuantizer4Bit(block_size=block_size)
        result = bq.quantize(weights_dict)
        for name, data in result.items():
            w = weights_dict[name]
            total_elements = w.size
            num_blocks = (total_elements + block_size - 1) // block_size
            assert data["num_blocks"] == num_blocks
            assert data["weights_4bit"].shape == (num_blocks, block_size // 2)
            assert data["scales"].shape == (num_blocks,)
            assert data["zeros"].shape == (num_blocks,)
            assert data["original_shape"] == w.shape

    def test_dequantize_recovers_approximate_values(self, weights_dict):
        block_size = 64
        bq = BlockQuantizer4Bit(block_size=block_size)
        result = bq.quantize(weights_dict)
        for name, data in result.items():
            orig = weights_dict[name].astype(np.float32).ravel()
            packed = data["weights_4bit"]
            scales = data["scales"]
            zeros = data["zeros"]
            num_blocks = data["num_blocks"]

            reconstructed = []
            for b in range(num_blocks):
                block_vals = bq.dequantize_block(packed, scales, zeros, b)
                reconstructed.append(block_vals.astype(np.float32))
            reconstructed = np.concatenate(reconstructed)[:len(orig)]

            # 4-bit quantization has significant error, but the range should be
            # preserved and the correlation should be high.
            corr = np.corrcoef(orig, reconstructed)[0, 1]
            assert corr > 0.9, f"{name}: correlation {corr:.3f} too low"
            # Max error should be bounded by the quantization step
            max_err = np.max(np.abs(orig - reconstructed))
            value_range = np.max(np.abs(orig)) - np.min(orig)
            # Each quantisation step is roughly range/15
            assert max_err < value_range * 0.5, (
                f"{name}: max error {max_err:.4f} vs range {value_range:.4f}"
            )

    def test_small_block_size(self):
        """4-bit quant with a smaller block size (32)."""
        bq = BlockQuantizer4Bit(block_size=32)
        weights = {"test.weight": np.random.randn(32, 32).astype(np.float32)}
        result = bq.quantize(weights)
        data = result["test.weight"]
        assert data["weights_4bit"].shape[1] == 16  # 32/2


# =========================================================================
# 7. TestLayerOffloader
# =========================================================================
class TestLayerOffloader:
    """Tests for hot/cold layer splitting."""

    @pytest.fixture()
    def weights_20_layers(self):
        """Simulate a 20-layer model's weight dict."""
        weights = {}
        for i in range(20):
            weights[f"model.layers.{i}.self_attn.q_proj.weight"] = np.zeros((8, 8), dtype=np.float16)
            weights[f"model.layers.{i}.mlp.gate_proj.weight"] = np.zeros((16, 8), dtype=np.float16)
        # Non-layer weights
        weights["model.embed_tokens.weight"] = np.zeros((256, 8), dtype=np.float16)
        weights["model.norm.weight"] = np.zeros((8,), dtype=np.float16)
        return weights

    def test_hot_cold_split_default(self, weights_20_layers):
        """Default hot_fraction=0.1 on 20 layers => last 2 hot, first 18 cold."""
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        assert len(offloader.hot_layers) == 2
        assert len(offloader.cold_layers) == 18
        assert offloader.hot_start == 18

    def test_hot_cold_split_custom_fraction(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20, hot_fraction=0.25)
        # 25% of 20 = 5 hot layers (layers 15-19)
        assert len(offloader.hot_layers) == 5
        assert len(offloader.cold_layers) == 15
        assert offloader.hot_start == 15

    def test_layer_classification(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20, hot_fraction=0.1)
        # Layers 0-17 should be cold
        for i in range(18):
            assert offloader.is_hot(i) is False
            assert i in offloader.cold_layers
        # Layers 18-19 should be hot
        for i in range(18, 20):
            assert offloader.is_hot(i) is True
            assert i in offloader.hot_layers

    def test_non_layer_weights_are_hot(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        # Embeddings and final norm should always be in hot weights
        assert "model.embed_tokens.weight" in offloader._hot_weights
        assert "model.norm.weight" in offloader._hot_weights

    def test_get_layer_weights_hot(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        hot_w = offloader.get_layer_weights(19)
        assert len(hot_w) > 0
        for k in hot_w:
            assert "layers.19." in k

    def test_get_layer_weights_cold(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        cold_w = offloader.get_layer_weights(0)
        assert len(cold_w) > 0
        for k in cold_w:
            assert "layers.0." in k

    def test_get_single_weight(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        w = offloader.get_weight("model.embed_tokens.weight")
        assert w.shape == (256, 8)

    def test_get_weight_missing_raises(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        with pytest.raises(KeyError):
            offloader.get_weight("nonexistent.weight")

    def test_stats(self, weights_20_layers):
        offloader = LayerOffloader(weights_20_layers, num_layers=20)
        stats = offloader.get_stats()
        assert stats["num_hot"] == 2
        assert stats["num_cold"] == 18
        assert stats["hot_start"] == 18

    def test_minimum_one_hot_layer(self):
        """Even with hot_fraction=0.01 and 3 layers, at least 1 should be hot."""
        weights = {
            f"model.layers.{i}.weight": np.zeros((4, 4), dtype=np.float16)
            for i in range(3)
        }
        offloader = LayerOffloader(weights, num_layers=3, hot_fraction=0.01)
        assert len(offloader.hot_layers) >= 1


# =========================================================================
# 8. TestTextGenerator
# =========================================================================
class TestTextGenerator:
    """Tests for text generation utilities (sampling, chat template)."""

    # ------------------------------------------------------------------
    # Chat template tests
    # ------------------------------------------------------------------
    def test_chat_template_single_user_message(self):
        model = MagicMock()
        tokenizer = MagicMock()
        gen = TextGenerator(model, tokenizer)
        messages = [{"role": "user", "content": "Hello!"}]
        formatted = gen._format_chat(messages)
        assert formatted.startswith("<|begin_of_text|>")
        assert "<|start_header_id|>user<|end_header_id|>" in formatted
        assert "Hello!" in formatted
        assert "<|eot_id|>" in formatted
        assert formatted.endswith("<|start_header_id|>assistant<|end_header_id|>\n\n")

    def test_chat_template_system_and_user(self):
        model = MagicMock()
        tokenizer = MagicMock()
        gen = TextGenerator(model, tokenizer)
        messages = [
            {"role": "system", "content": "You are helpful."},
            {"role": "user", "content": "Hi"},
        ]
        formatted = gen._format_chat(messages)
        assert "<|start_header_id|>system<|end_header_id|>" in formatted
        assert "You are helpful." in formatted
        assert "<|start_header_id|>user<|end_header_id|>" in formatted
        assert "Hi" in formatted

    def test_chat_template_multi_turn(self):
        model = MagicMock()
        tokenizer = MagicMock()
        gen = TextGenerator(model, tokenizer)
        messages = [
            {"role": "user", "content": "Hi"},
            {"role": "assistant", "content": "Hello!"},
            {"role": "user", "content": "How are you?"},
        ]
        formatted = gen._format_chat(messages)
        # Each message should produce its own header
        assert formatted.count("<|start_header_id|>") == 4  # 3 messages + trailing assistant
        assert formatted.count("<|eot_id|>") == 3

    # ------------------------------------------------------------------
    # Sampling tests (use the module-level _sample_top_k_top_p)
    # ------------------------------------------------------------------
    def test_greedy_sampling(self):
        """temperature=0 should always return argmax."""
        logits = np.array([0.1, 0.3, 0.9, 0.2, 0.05])
        token = _sample_top_k_top_p(logits, temperature=0.0)
        assert token == 2  # index of 0.9

    def test_top_k_restricts_candidates(self):
        """With top_k=1, only the highest-logit token should ever be sampled."""
        np.random.seed(42)
        logits = np.array([1.0, 5.0, 0.5, 0.1, 0.01])
        results = set()
        for _ in range(100):
            results.add(_sample_top_k_top_p(logits, temperature=1.0, top_k=1, top_p=1.0))
        assert results == {1}  # index of 5.0

    def test_top_k_limits_diversity(self):
        """With top_k=2, only the top-2 tokens should appear."""
        np.random.seed(42)
        logits = np.array([0.0, 10.0, 9.0, -5.0, -10.0])
        results = set()
        for _ in range(200):
            results.add(_sample_top_k_top_p(logits, temperature=1.0, top_k=2, top_p=1.0))
        # Only indices 1 and 2 should appear
        assert results.issubset({1, 2})

    def test_top_p_nucleus_sampling(self):
        """With a small top_p, only the most probable tokens should be sampled."""
        np.random.seed(42)
        # Create logits where one token dominates
        logits = np.array([0.0, 0.0, 0.0, 0.0, 100.0])
        results = set()
        for _ in range(50):
            results.add(_sample_top_k_top_p(logits, temperature=1.0,
                                            top_k=len(logits), top_p=0.5))
        # Token 4 has overwhelming probability
        assert 4 in results

    def test_top_p_excludes_low_probability(self):
        """With top_p=0.01 and one dominant token, only that token should appear."""
        np.random.seed(42)
        logits = np.zeros(100, dtype=np.float64)
        logits[42] = 50.0  # make token 42 dominate massively
        results = set()
        for _ in range(50):
            results.add(_sample_top_k_top_p(logits, temperature=0.5,
                                            top_k=100, top_p=0.01))
        assert results == {42}

    def test_temperature_affects_distribution(self):
        """Higher temperature should produce more diverse outputs."""
        np.random.seed(42)
        logits = np.array([2.0, 2.5, 3.0, 2.0, 1.0])
        low_temp_results = set()
        high_temp_results = set()
        for _ in range(300):
            low_temp_results.add(
                _sample_top_k_top_p(logits, temperature=0.01, top_k=5, top_p=1.0)
            )
            high_temp_results.add(
                _sample_top_k_top_p(logits, temperature=5.0, top_k=5, top_p=1.0)
            )
        # Low temperature should converge to argmax (index 2)
        assert low_temp_results == {2}
        # High temperature should explore more tokens
        assert len(high_temp_results) >= 3

    def test_sampling_returns_valid_index(self):
        """Sampled token should always be a valid index into the logits array."""
        np.random.seed(42)
        logits = np.random.randn(128256).astype(np.float64)
        for _ in range(20):
            token = _sample_top_k_top_p(logits, temperature=0.7, top_k=50, top_p=0.9)
            assert 0 <= token < len(logits)

    def test_sampling_deterministic_with_seed(self):
        """Same seed should produce the same token sequence."""
        logits = np.random.randn(1000).astype(np.float64)
        np.random.seed(123)
        tokens_a = [_sample_top_k_top_p(logits, temperature=0.8, top_k=40, top_p=0.95)
                     for _ in range(10)]
        np.random.seed(123)
        tokens_b = [_sample_top_k_top_p(logits, temperature=0.8, top_k=40, top_p=0.95)
                     for _ in range(10)]
        assert tokens_a == tokens_b
