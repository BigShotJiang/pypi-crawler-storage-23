"""GPU integration tests for the GrillyInference package.

These tests exercise the actual Vulkan backend via the grilly Compute class.
They require a GPU with Vulkan support to run. All tests are marked with
@pytest.mark.gpu and will be skipped if Vulkan is not available.

Run with:
    python -m pytest tests/test_inference_gpu.py -v --no-header
"""

import sys
from pathlib import Path

import numpy as np
import pytest

# ---------------------------------------------------------------------------
# Ensure the package is importable from the repo root.
# ---------------------------------------------------------------------------
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# ---------------------------------------------------------------------------
# Vulkan availability check
# ---------------------------------------------------------------------------
try:
    import grilly

    VULKAN_AVAILABLE = True
except Exception:
    VULKAN_AVAILABLE = False

pytestmark = [
    pytest.mark.gpu,
    pytest.mark.skipif(not VULKAN_AVAILABLE, reason="Vulkan not available"),
]

# ---------------------------------------------------------------------------
# Seed for reproducibility
# ---------------------------------------------------------------------------
np.random.seed(42)

# ---------------------------------------------------------------------------
# Shared imports (safe because tests are skipped when grilly is absent)
# ---------------------------------------------------------------------------
from grillyinference.inference.model_config import LlamaConfig
from grillyinference.inference.rms_norm import RMSNorm
from grillyinference.inference.kv_cache import KVCache
from grillyinference.inference.transformer import LlamaForCausalLM


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="module")
def backend():
    """Create a shared Vulkan Compute backend for the entire test module."""
    be = grilly.Compute()
    yield be
    be.cleanup()


@pytest.fixture()
def tiny_config():
    """A minimal LlamaConfig for fast GPU tests."""
    return LlamaConfig(
        num_layers=2,
        hidden_dim=64,
        num_heads=4,
        num_kv_heads=2,
        head_dim=16,
        intermediate_size=128,
        vocab_size=256,
        max_seq_len=64,
        rms_norm_eps=1e-5,
    )


def _build_random_weights(config: LlamaConfig) -> dict[str, np.ndarray]:
    """Generate random fp16 weights matching *config* so that
    LlamaForCausalLM.__init__ won't raise on missing keys.

    Weights are small (Xavier-scale) to keep logits finite.
    """
    h = config.hidden_dim
    inter = config.intermediate_size
    n_q = config.num_heads * config.head_dim
    n_kv = config.num_kv_heads * config.head_dim
    v = config.vocab_size

    weights: dict[str, np.ndarray] = {}
    scale = 0.02

    weights["model.embed_tokens.weight"] = (np.random.randn(v, h) * scale).astype(np.float16)
    weights["model.norm.weight"] = np.ones(h, dtype=np.float16)

    for i in range(config.num_layers):
        pfx = f"model.layers.{i}"
        weights[f"{pfx}.input_layernorm.weight"] = np.ones(h, dtype=np.float16)
        weights[f"{pfx}.self_attn.q_proj.weight"] = (np.random.randn(n_q, h) * scale).astype(np.float16)
        weights[f"{pfx}.self_attn.k_proj.weight"] = (np.random.randn(n_kv, h) * scale).astype(np.float16)
        weights[f"{pfx}.self_attn.v_proj.weight"] = (np.random.randn(n_kv, h) * scale).astype(np.float16)
        weights[f"{pfx}.self_attn.o_proj.weight"] = (np.random.randn(h, n_q) * scale).astype(np.float16)
        weights[f"{pfx}.post_attention_layernorm.weight"] = np.ones(h, dtype=np.float16)
        weights[f"{pfx}.mlp.gate_proj.weight"] = (np.random.randn(inter, h) * scale).astype(np.float16)
        weights[f"{pfx}.mlp.up_proj.weight"] = (np.random.randn(inter, h) * scale).astype(np.float16)
        weights[f"{pfx}.mlp.down_proj.weight"] = (np.random.randn(h, inter) * scale).astype(np.float16)

    return weights


# =========================================================================
# 1. TestRMSNormGPU
# =========================================================================
class TestRMSNormGPU:
    """Test RMSNorm using the actual Vulkan backend."""

    @staticmethod
    def _ref_rms_norm(x, weight, eps):
        """NumPy reference for RMSNorm."""
        x_f32 = x.astype(np.float32)
        variance = np.mean(x_f32 ** 2, axis=-1, keepdims=True)
        x_normed = x_f32 / np.sqrt(variance + eps)
        return (x_normed * weight.astype(np.float32)).astype(np.float32)

    def test_basic_rms_norm(self, backend):
        """backend.fnn.rms_norm() should match numpy reference."""
        x = np.array([[2.0, 2.0, 2.0, 2.0]], dtype=np.float32)
        weight = np.ones(4, dtype=np.float32)
        eps = 1e-5

        gpu_out = backend.fnn.rms_norm(x, weight, eps=eps)
        ref_out = self._ref_rms_norm(x, weight, eps)

        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_1d_input(self, backend):
        """1D input should be handled correctly."""
        x = np.random.randn(32).astype(np.float32)
        weight = np.random.randn(32).astype(np.float32)
        eps = 1e-5

        gpu_out = backend.fnn.rms_norm(x, weight, eps=eps)
        ref_out = self._ref_rms_norm(x, weight, eps)

        np.testing.assert_allclose(gpu_out.ravel(), ref_out.ravel(), atol=1e-3)

    def test_2d_input(self, backend):
        """2D (batch, features) input should produce correct results."""
        x = np.random.randn(8, 64).astype(np.float32)
        weight = np.ones(64, dtype=np.float32)
        eps = 1e-5

        gpu_out = backend.fnn.rms_norm(x, weight, eps=eps)
        ref_out = self._ref_rms_norm(x, weight, eps)

        assert gpu_out.shape == x.shape
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_3d_input(self, backend):
        """3D (batch, seq_len, features) input shape."""
        x = np.random.randn(2, 4, 32).astype(np.float32)
        weight = np.ones(32, dtype=np.float32)
        eps = 1e-5

        gpu_out = backend.fnn.rms_norm(x, weight, eps=eps)
        ref_out = self._ref_rms_norm(x, weight, eps)

        assert gpu_out.shape == x.shape
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_eps_1e6(self, backend):
        """eps=1e-6 should still produce correct results."""
        x = np.random.randn(4, 16).astype(np.float32)
        weight = np.ones(16, dtype=np.float32)
        eps = 1e-6

        gpu_out = backend.fnn.rms_norm(x, weight, eps=eps)
        ref_out = self._ref_rms_norm(x, weight, eps)

        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_large_eps(self, backend):
        """Large eps dominates for near-zero inputs."""
        x = np.array([[1e-6, 1e-6, 1e-6, 1e-6]], dtype=np.float32)
        weight = np.ones(4, dtype=np.float32)

        out_small = backend.fnn.rms_norm(x, weight, eps=1e-12)
        out_large = backend.fnn.rms_norm(x, weight, eps=1.0)

        assert np.max(np.abs(out_large)) < np.max(np.abs(out_small))

    def test_weight_scaling(self, backend):
        """Weight of 2.0 everywhere should double the unit-weight output."""
        x = np.random.randn(2, 16).astype(np.float32)
        w1 = np.ones(16, dtype=np.float32)
        w2 = np.full(16, 2.0, dtype=np.float32)
        eps = 1e-5

        out1 = backend.fnn.rms_norm(x, w1, eps=eps)
        out2 = backend.fnn.rms_norm(x, w2, eps=eps)

        np.testing.assert_allclose(out2, 2.0 * out1, atol=1e-3)

    def test_rmsnorm_class_with_vulkan(self, backend):
        """The RMSNorm class should dispatch to Vulkan when backend is set."""
        norm = RMSNorm(eps=1e-5, vulkan_backend=backend)
        x = np.random.randn(4, 32).astype(np.float32)
        weight = np.ones(32, dtype=np.float32)

        gpu_out = norm.forward(x, weight)
        ref_out = self._ref_rms_norm(x, weight, 1e-5)

        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)


# =========================================================================
# 2. TestKVCacheGPU
# =========================================================================
class TestKVCacheGPU:
    """Test KV cache with Vulkan-backed operations."""

    @pytest.fixture()
    def small_config(self):
        return LlamaConfig(
            num_layers=2,
            hidden_dim=64,
            num_heads=4,
            num_kv_heads=2,
            head_dim=16,
            vocab_size=256,
        )

    def test_prefill_store_and_retrieve(self, small_config):
        """Store multiple tokens during prefill, then retrieve and verify."""
        cache = KVCache(small_config, max_batch=1, raw_window=32)
        k_in = np.random.randn(1, 2, 8, 16).astype(np.float32)
        v_in = np.random.randn(1, 2, 8, 16).astype(np.float32)

        k_out, v_out = cache.update(0, k_in, v_in)
        assert k_out.shape == (1, 2, 8, 16)
        assert v_out.shape == (1, 2, 8, 16)

        k_got, v_got = cache.get(0)
        assert k_got.shape == (1, 2, 8, 16)
        # Values should match within fp16 tolerance
        np.testing.assert_allclose(
            k_got.astype(np.float32),
            k_in.astype(np.float16).astype(np.float32),
            atol=1e-2,
        )

    def test_decode_append_incremental(self, small_config):
        """Append single tokens incrementally during decode."""
        cache = KVCache(small_config, max_batch=1, raw_window=32)

        # Prefill 4 tokens
        k_pre = np.random.randn(1, 2, 4, 16).astype(np.float32)
        v_pre = np.random.randn(1, 2, 4, 16).astype(np.float32)
        cache.update(0, k_pre, v_pre)
        assert cache.seq_length == 4

        # Decode 3 tokens one at a time
        for step in range(3):
            k_dec = np.random.randn(1, 2, 1, 16).astype(np.float32)
            v_dec = np.random.randn(1, 2, 1, 16).astype(np.float32)
            k_out, v_out = cache.update(0, k_dec, v_dec)
            assert k_out.shape[2] == 4 + step + 1
            assert v_out.shape[2] == 4 + step + 1

        assert cache.seq_length == 7

    def test_retrieve_matches_stored(self, small_config):
        """Retrieved values should match what was stored (within fp16 precision)."""
        cache = KVCache(small_config, max_batch=1, raw_window=32)
        k_in = np.random.randn(1, 2, 5, 16).astype(np.float32)
        v_in = np.random.randn(1, 2, 5, 16).astype(np.float32)

        cache.update(0, k_in, v_in)
        k_got, v_got = cache.get(0)

        np.testing.assert_allclose(
            k_got.astype(np.float32),
            k_in.astype(np.float16).astype(np.float32),
            atol=1e-2,
        )
        np.testing.assert_allclose(
            v_got.astype(np.float32),
            v_in.astype(np.float16).astype(np.float32),
            atol=1e-2,
        )

    def test_clear_and_reuse(self, small_config):
        """Clear the cache and verify it can be reused from scratch."""
        cache = KVCache(small_config, max_batch=1, raw_window=32)

        # Fill with data
        k1 = np.random.randn(1, 2, 6, 16).astype(np.float32)
        v1 = np.random.randn(1, 2, 6, 16).astype(np.float32)
        cache.update(0, k1, v1)
        assert cache.seq_length == 6

        # Clear
        cache.clear()
        assert cache.seq_length == 0
        k_empty, v_empty = cache.get(0)
        assert k_empty.shape[2] == 0

        # Reuse with new data
        k2 = np.random.randn(1, 2, 3, 16).astype(np.float32)
        v2 = np.random.randn(1, 2, 3, 16).astype(np.float32)
        cache.update(0, k2, v2)
        assert cache.seq_length == 3

        k_got, _ = cache.get(0)
        assert k_got.shape[2] == 3

    def test_multilayer_independence(self, small_config):
        """Layer 0 and layer 1 should hold independent data."""
        cache = KVCache(small_config, max_batch=1, raw_window=32)

        k0 = np.random.randn(1, 2, 4, 16).astype(np.float32)
        v0 = np.random.randn(1, 2, 4, 16).astype(np.float32)
        k1 = np.random.randn(1, 2, 4, 16).astype(np.float32)
        v1 = np.random.randn(1, 2, 4, 16).astype(np.float32)

        cache.update(0, k0, v0)
        cache.update(1, k1, v1)

        got_k0, _ = cache.get(0)
        got_k1, _ = cache.get(1)

        assert not np.allclose(
            got_k0.astype(np.float32),
            got_k1.astype(np.float32),
            atol=1e-2,
        )


# =========================================================================
# 3. TestSwiGLUFusedGPU
# =========================================================================
class TestSwiGLUFusedGPU:
    """Test fused SwiGLU via the Vulkan backend."""

    @staticmethod
    def _ref_swiglu(x, gate_weights, up_weights):
        """NumPy reference: silu(x @ gate.T) * (x @ up.T)."""
        x_f32 = x.astype(np.float32).reshape(-1, x.shape[-1])
        gate = x_f32 @ gate_weights.astype(np.float32).T
        up = x_f32 @ up_weights.astype(np.float32).T
        silu_gate = gate / (1.0 + np.exp(-np.clip(gate, -88, 88)))
        return (silu_gate * up).astype(np.float32)

    def test_basic_swiglu(self, backend):
        """SwiGLU fused should match numpy reference for small inputs."""
        x = np.random.randn(4, 16).astype(np.float32)
        gate_w = np.random.randn(32, 16).astype(np.float32) * 0.1
        up_w = np.random.randn(32, 16).astype(np.float32) * 0.1

        gpu_out = backend.fnn.swiglu_fused(x, gate_w, up_w)
        ref_out = self._ref_swiglu(x, gate_w, up_w)

        assert gpu_out.shape == ref_out.shape
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_batch_size_1(self, backend):
        """Single-sample input."""
        x = np.random.randn(1, 32).astype(np.float32)
        gate_w = np.random.randn(64, 32).astype(np.float32) * 0.1
        up_w = np.random.randn(64, 32).astype(np.float32) * 0.1

        gpu_out = backend.fnn.swiglu_fused(x, gate_w, up_w)
        ref_out = self._ref_swiglu(x, gate_w, up_w)

        assert gpu_out.shape == (1, 64)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_larger_batch(self, backend):
        """Larger batch dimension."""
        x = np.random.randn(16, 32).astype(np.float32)
        gate_w = np.random.randn(64, 32).astype(np.float32) * 0.1
        up_w = np.random.randn(64, 32).astype(np.float32) * 0.1

        gpu_out = backend.fnn.swiglu_fused(x, gate_w, up_w)
        ref_out = self._ref_swiglu(x, gate_w, up_w)

        assert gpu_out.shape == (16, 64)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_3d_input(self, backend):
        """3D input (batch, seq, dim) should be handled."""
        x = np.random.randn(2, 4, 16).astype(np.float32)
        gate_w = np.random.randn(32, 16).astype(np.float32) * 0.1
        up_w = np.random.randn(32, 16).astype(np.float32) * 0.1

        gpu_out = backend.fnn.swiglu_fused(x, gate_w, up_w)
        ref_out = self._ref_swiglu(x, gate_w, up_w)

        np.testing.assert_allclose(gpu_out.reshape(-1, 32), ref_out, atol=1e-3)

    def test_output_finite(self, backend):
        """All outputs should be finite for moderate inputs."""
        x = np.random.randn(8, 64).astype(np.float32)
        gate_w = np.random.randn(128, 64).astype(np.float32) * 0.1
        up_w = np.random.randn(128, 64).astype(np.float32) * 0.1

        gpu_out = backend.fnn.swiglu_fused(x, gate_w, up_w)
        assert np.all(np.isfinite(gpu_out))


# =========================================================================
# 4. TestINT8GEMMGPU
# =========================================================================
class TestINT8GEMMGPU:
    """Test INT8 quantized GEMM via the Vulkan backend."""

    @staticmethod
    def _ref_gemm_int8(activations, weights_int8, scales, group_size):
        """NumPy reference: dequantize int8 weights then matmul."""
        M, K = activations.shape
        N = weights_int8.shape[0]
        num_groups = (K + group_size - 1) // group_size
        w_fp32 = np.zeros((N, K), dtype=np.float32)
        for g in range(num_groups):
            k_start = g * group_size
            k_end = min(k_start + group_size, K)
            w_fp32[:, k_start:k_end] = (
                weights_int8[:, k_start:k_end].astype(np.float32)
                * scales[:, g : g + 1]
            )
        return activations.astype(np.float32) @ w_fp32.T

    def test_basic_int8_gemm(self, backend):
        """INT8 GEMM should match dequantized reference."""
        M, K, N = 4, 64, 32
        group_size = 64

        activations = np.random.randn(M, K).astype(np.float32) * 0.1
        # Create int8 weights in valid range
        weights_int8 = np.random.randint(-64, 64, (N, K)).astype(np.int8)
        num_groups = (K + group_size - 1) // group_size
        scales = np.random.rand(N, num_groups).astype(np.float32) * 0.01 + 0.001

        gpu_out = backend.fnn.gemm_int8(activations, weights_int8, scales, group_size=group_size)
        ref_out = self._ref_gemm_int8(activations, weights_int8, scales, group_size)

        assert gpu_out.shape == (M, N)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_group_size_64(self, backend):
        """Test with group_size=64."""
        M, K, N = 8, 128, 64
        group_size = 64

        activations = np.random.randn(M, K).astype(np.float32) * 0.1
        weights_int8 = np.random.randint(-64, 64, (N, K)).astype(np.int8)
        num_groups = (K + group_size - 1) // group_size
        scales = np.random.rand(N, num_groups).astype(np.float32) * 0.01 + 0.001

        gpu_out = backend.fnn.gemm_int8(activations, weights_int8, scales, group_size=group_size)
        ref_out = self._ref_gemm_int8(activations, weights_int8, scales, group_size)

        assert gpu_out.shape == (M, N)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_group_size_128(self, backend):
        """Test with group_size=128."""
        M, K, N = 4, 128, 32
        group_size = 128

        activations = np.random.randn(M, K).astype(np.float32) * 0.1
        weights_int8 = np.random.randint(-64, 64, (N, K)).astype(np.int8)
        num_groups = (K + group_size - 1) // group_size
        scales = np.random.rand(N, num_groups).astype(np.float32) * 0.01 + 0.001

        gpu_out = backend.fnn.gemm_int8(activations, weights_int8, scales, group_size=group_size)
        ref_out = self._ref_gemm_int8(activations, weights_int8, scales, group_size)

        assert gpu_out.shape == (M, N)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_single_row(self, backend):
        """Decode-like single-row activation."""
        M, K, N = 1, 64, 32
        group_size = 64

        activations = np.random.randn(M, K).astype(np.float32) * 0.1
        weights_int8 = np.random.randint(-64, 64, (N, K)).astype(np.int8)
        num_groups = (K + group_size - 1) // group_size
        scales = np.random.rand(N, num_groups).astype(np.float32) * 0.01 + 0.001

        gpu_out = backend.fnn.gemm_int8(activations, weights_int8, scales, group_size=group_size)
        ref_out = self._ref_gemm_int8(activations, weights_int8, scales, group_size)

        assert gpu_out.shape == (1, N)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_output_finite(self, backend):
        """All outputs should be finite."""
        M, K, N = 8, 64, 32
        group_size = 64

        activations = np.random.randn(M, K).astype(np.float32) * 0.1
        weights_int8 = np.random.randint(-64, 64, (N, K)).astype(np.int8)
        num_groups = (K + group_size - 1) // group_size
        scales = np.random.rand(N, num_groups).astype(np.float32) * 0.01 + 0.001

        gpu_out = backend.fnn.gemm_int8(activations, weights_int8, scales, group_size=group_size)
        assert np.all(np.isfinite(gpu_out))


# =========================================================================
# 5. TestGQADecodeAttentionGPU
# =========================================================================
class TestGQADecodeAttentionGPU:
    """Test grouped query attention decode via the Vulkan backend."""

    @staticmethod
    def _ref_gqa_decode(query, k_cache, v_cache, num_q_heads, num_kv_heads, head_dim):
        """NumPy reference GQA: expand KV heads and do standard attention."""
        batch = query.shape[0]
        scale = 1.0 / np.sqrt(head_dim)
        kv_group_size = num_q_heads // num_kv_heads
        cache_len = k_cache.shape[1]

        q_2d = query.astype(np.float32).reshape(batch, num_q_heads, head_dim)
        k = k_cache.astype(np.float32)
        v = v_cache.astype(np.float32)
        output = np.zeros((batch, num_q_heads, head_dim), dtype=np.float32)

        for b in range(batch):
            for qh in range(num_q_heads):
                kv_head = qh // kv_group_size
                # scores: (cache_len,)
                scores = np.einsum("d,sd->s", q_2d[b, qh], k[b, :cache_len, kv_head]) * scale
                scores_max = np.max(scores)
                exp_scores = np.exp(scores - scores_max)
                weights = exp_scores / np.sum(exp_scores)
                output[b, qh] = np.einsum("s,sd->d", weights, v[b, :cache_len, kv_head])

        return output.reshape(batch, 1, num_q_heads, head_dim)

    def test_basic_gqa_decode(self, backend):
        """Basic GQA decode with Llama-like config (24 q heads, 8 kv heads)."""
        batch = 1
        num_q_heads = 24
        num_kv_heads = 8
        head_dim = 16
        cache_len = 10

        query = np.random.randn(batch, 1, num_q_heads, head_dim).astype(np.float32) * 0.1
        k_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1
        v_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1

        gpu_out = backend.attention.gqa_decode_attention(
            query, k_cache, v_cache,
            num_q_heads=num_q_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            cache_len=cache_len,
        )
        ref_out = self._ref_gqa_decode(query, k_cache, v_cache, num_q_heads, num_kv_heads, head_dim)

        assert gpu_out.shape == (batch, 1, num_q_heads, head_dim)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_smaller_group_size(self, backend):
        """4 query heads, 2 KV heads (group_size=2)."""
        batch = 1
        num_q_heads = 4
        num_kv_heads = 2
        head_dim = 16
        cache_len = 8

        query = np.random.randn(batch, 1, num_q_heads, head_dim).astype(np.float32) * 0.1
        k_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1
        v_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1

        gpu_out = backend.attention.gqa_decode_attention(
            query, k_cache, v_cache,
            num_q_heads=num_q_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            cache_len=cache_len,
        )
        ref_out = self._ref_gqa_decode(query, k_cache, v_cache, num_q_heads, num_kv_heads, head_dim)

        assert gpu_out.shape == (batch, 1, num_q_heads, head_dim)
        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_longer_cache(self, backend):
        """Test with longer KV cache (32 positions)."""
        batch = 1
        num_q_heads = 8
        num_kv_heads = 4
        head_dim = 16
        cache_len = 32

        query = np.random.randn(batch, 1, num_q_heads, head_dim).astype(np.float32) * 0.1
        k_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1
        v_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1

        gpu_out = backend.attention.gqa_decode_attention(
            query, k_cache, v_cache,
            num_q_heads=num_q_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            cache_len=cache_len,
        )
        ref_out = self._ref_gqa_decode(query, k_cache, v_cache, num_q_heads, num_kv_heads, head_dim)

        np.testing.assert_allclose(gpu_out, ref_out, atol=1e-3)

    def test_output_shape_and_finite(self, backend):
        """Output should have correct shape and be finite."""
        batch = 2
        num_q_heads = 12
        num_kv_heads = 4
        head_dim = 16
        cache_len = 16

        query = np.random.randn(batch, 1, num_q_heads, head_dim).astype(np.float32) * 0.1
        k_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1
        v_cache = np.random.randn(batch, cache_len, num_kv_heads, head_dim).astype(np.float32) * 0.1

        gpu_out = backend.attention.gqa_decode_attention(
            query, k_cache, v_cache,
            num_q_heads=num_q_heads,
            num_kv_heads=num_kv_heads,
            head_dim=head_dim,
            cache_len=cache_len,
        )

        assert gpu_out.shape == (batch, 1, num_q_heads, head_dim)
        assert np.all(np.isfinite(gpu_out))


# =========================================================================
# 6. TestInferenceIntegration
# =========================================================================
class TestInferenceIntegration:
    """End-to-end GPU integration tests with a tiny model."""

    def test_forward_pass_produces_finite_logits(self, tiny_config):
        """Full forward pass with random weights produces finite logits."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        tokens = np.array([[1, 2, 3, 4]], dtype=np.int32)
        logits = model.forward(tokens)

        assert logits.shape == (1, 4, tiny_config.vocab_size)
        assert np.all(np.isfinite(logits))

    def test_forward_logits_correct_shape(self, tiny_config):
        """Logits shape should be (batch, seq_len, vocab_size)."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        batch, seq = 2, 6
        tokens = np.random.randint(0, tiny_config.vocab_size, (batch, seq), dtype=np.int32)
        logits = model.forward(tokens)

        assert logits.shape == (batch, seq, tiny_config.vocab_size)

    def test_prefill_then_decode(self, tiny_config):
        """Prefill should produce different logits than a subsequent decode step."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        tokens = np.array([[1, 2, 3]], dtype=np.int32)
        prefill_logits, kv_cache = model.prefill(tokens)

        assert prefill_logits.shape == (1, 3, tiny_config.vocab_size)
        assert np.all(np.isfinite(prefill_logits))

        # Decode one more token
        next_token = np.array([[4]], dtype=np.int32)
        decode_logits = model.decode_step(next_token, kv_cache)

        assert decode_logits.shape == (1, 1, tiny_config.vocab_size)
        assert np.all(np.isfinite(decode_logits))

        # Prefill last-token logits and decode logits should differ
        assert not np.allclose(prefill_logits[0, -1], decode_logits[0, 0], atol=1e-6)

    def test_kv_cache_grows_across_decode_steps(self, tiny_config):
        """KV cache seq_length should grow by 1 each decode step."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        tokens = np.array([[10, 20, 30]], dtype=np.int32)
        logits, kv_cache = model.prefill(tokens)
        assert kv_cache.seq_length == 3

        for step in range(5):
            next_id = np.array([[step + 40]], dtype=np.int32)
            model.decode_step(next_id, kv_cache)
            assert kv_cache.seq_length == 3 + step + 1

        assert kv_cache.seq_length == 8

    def test_different_sequences_produce_different_logits(self, tiny_config):
        """Two different input sequences should produce different logits."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        tokens_a = np.array([[1, 2, 3]], dtype=np.int32)
        tokens_b = np.array([[4, 5, 6]], dtype=np.int32)

        logits_a = model.forward(tokens_a)
        logits_b = model.forward(tokens_b)

        assert not np.allclose(logits_a, logits_b, atol=1e-6)

    def test_model_with_vulkan_rmsnorm(self, backend, tiny_config):
        """Model with Vulkan backend should produce finite logits."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32", vulkan_backend=backend)

        tokens = np.array([[1, 2, 3, 4]], dtype=np.int32)
        logits = model.forward(tokens)

        assert logits.shape == (1, 4, tiny_config.vocab_size)
        assert np.all(np.isfinite(logits))

    def test_multi_step_decode_consistency(self, tiny_config):
        """Successive decode steps should each produce finite logits."""
        weights = _build_random_weights(tiny_config)
        model = LlamaForCausalLM(tiny_config, weights, dtype="fp32")

        tokens = np.array([[1, 2]], dtype=np.int32)
        logits, kv_cache = model.prefill(tokens)

        all_logits = [logits[0, -1, :]]
        for i in range(8):
            next_token_id = int(np.argmax(all_logits[-1]))
            next_token = np.array([[next_token_id]], dtype=np.int32)
            step_logits = model.decode_step(next_token, kv_cache)
            assert step_logits.shape == (1, 1, tiny_config.vocab_size)
            assert np.all(np.isfinite(step_logits))
            all_logits.append(step_logits[0, 0, :])

        # We should have 9 sets of logits (1 prefill + 8 decode)
        assert len(all_logits) == 9
