"""GrillyInference — native fp16 inference engine for Llama models.

Optional grilly extension providing:
- LlamaConfig: Architecture configuration (auto-detect from HF)
- LlamaForCausalLM: Full transformer forward pass (prefill + decode)
- TextGenerator: Text generation with sampling (temperature, top-k, top-p)
- KVCache: Paged KV-cache with H2O eviction and VSA multi-scale summaries
- RMSNorm: RMSNorm operation (Vulkan + CPU fallback)
- SmoothQuant: INT8 weight-only quantization pipeline
- LayerOffloader: Hot/cold layer split for large models
"""

from .inference.generate import TextGenerator
from .inference.kv_cache import KVCache
from .inference.model_config import LlamaConfig
from .inference.rms_norm import RMSNorm
from .inference.transformer import LlamaForCausalLM
from .inference.weights import load_merged_checkpoint, load_safetensors_fp16, save_fp16_safetensors

__version__ = "0.1.0"

__all__ = [
    "LlamaConfig",
    "LlamaForCausalLM",
    "TextGenerator",
    "KVCache",
    "RMSNorm",
    "load_safetensors_fp16",
    "load_merged_checkpoint",
    "save_fp16_safetensors",
]
