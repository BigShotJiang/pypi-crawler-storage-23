"""Layer offloading for running large models (up to 100B) on 12GB VRAM.

Strategy:
    Hot layers (last 10%): VRAM resident (~5GB)
    Cold layers (first 90%): CPU RAM, async PCIe stream during sampling
    Prefetch: 1 layer per ~10ms, amortized 200ms during sampling

Memory budget (100B target):
    Weights 4-bit:  ~25GB total (offloaded)
    Hot layers:     ~5GB VRAM
    KV Cache:       ~3GB compressed
    Activations:    ~1-2GB
    TOTAL VRAM:     ~11GB peak
"""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor

import numpy as np

logger = logging.getLogger(__name__)


class LayerOffloader:
    """Manage hot/cold layer split for large model inference.

    Args:
        weights: Full model weight dict.
        num_layers: Total transformer layers.
        hot_fraction: Fraction of layers kept in VRAM (default 0.1 = last 10%).
        prefetch_ahead: Number of layers to prefetch ahead (default 2).
    """

    def __init__(
        self,
        weights: dict[str, np.ndarray],
        num_layers: int,
        hot_fraction: float = 0.1,
        prefetch_ahead: int = 2,
    ):
        self.num_layers = num_layers
        self.hot_fraction = hot_fraction
        self.prefetch_ahead = prefetch_ahead

        # Split layers into hot (VRAM) and cold (CPU)
        num_hot = max(1, int(num_layers * hot_fraction))
        self.hot_start = num_layers - num_hot
        self.hot_layers = set(range(self.hot_start, num_layers))
        self.cold_layers = set(range(0, self.hot_start))

        # Organize weights by layer
        self._hot_weights: dict[str, np.ndarray] = {}
        self._cold_weights: dict[str, np.ndarray] = {}
        self._prefetched: dict[int, dict[str, np.ndarray]] = {}

        for name, w in weights.items():
            layer_idx = self._extract_layer_idx(name)
            if layer_idx is not None and layer_idx in self.hot_layers:
                self._hot_weights[name] = w
            elif layer_idx is not None:
                self._cold_weights[name] = w
            else:
                # Non-layer weights (embeddings, final norm) stay hot
                self._hot_weights[name] = w

        self._executor = ThreadPoolExecutor(max_workers=2)
        self._prefetch_futures = {}

        hot_mb = sum(w.nbytes for w in self._hot_weights.values()) / 1e6
        cold_mb = sum(w.nbytes for w in self._cold_weights.values()) / 1e6
        logger.info(
            "LayerOffloader: %d hot layers (%.1f MB VRAM), %d cold layers (%.1f MB CPU)",
            len(self.hot_layers), hot_mb, len(self.cold_layers), cold_mb,
        )

    def _extract_layer_idx(self, name: str) -> int | None:
        """Extract layer index from weight name like 'model.layers.5.mlp.gate_proj.weight'."""
        parts = name.split(".")
        for i, part in enumerate(parts):
            if part == "layers" and i + 1 < len(parts):
                try:
                    return int(parts[i + 1])
                except ValueError:
                    pass
        return None

    def is_hot(self, layer_idx: int) -> bool:
        return layer_idx in self.hot_layers

    def get_layer_weights(self, layer_idx: int) -> dict[str, np.ndarray]:
        """Get weights for a layer, loading from CPU if cold.

        For cold layers, returns prefetched data if available.
        """
        prefix = f"model.layers.{layer_idx}."

        if layer_idx in self.hot_layers:
            return {k: v for k, v in self._hot_weights.items() if k.startswith(prefix)}

        # Check prefetch cache
        if layer_idx in self._prefetched:
            weights = self._prefetched.pop(layer_idx)
            return weights

        # Check in-flight prefetch
        if layer_idx in self._prefetch_futures:
            future = self._prefetch_futures.pop(layer_idx)
            return future.result()

        # Cold load (blocking)
        t0 = time.perf_counter()
        weights = {k: v for k, v in self._cold_weights.items() if k.startswith(prefix)}
        load_ms = (time.perf_counter() - t0) * 1000
        logger.debug("Cold load layer %d: %.1f ms", layer_idx, load_ms)
        return weights

    def get_weight(self, name: str) -> np.ndarray:
        """Get a single weight by name."""
        if name in self._hot_weights:
            return self._hot_weights[name]
        if name in self._cold_weights:
            return self._cold_weights[name]
        raise KeyError(f"Weight not found: {name}")

    def prefetch_layer(self, layer_idx: int):
        """Async prefetch a cold layer into the prefetch cache."""
        if layer_idx in self.hot_layers or layer_idx in self._prefetched:
            return

        if layer_idx in self._prefetch_futures:
            return

        prefix = f"model.layers.{layer_idx}."

        def _load():
            return {k: v for k, v in self._cold_weights.items() if k.startswith(prefix)}

        self._prefetch_futures[layer_idx] = self._executor.submit(_load)

    def prefetch_ahead_of(self, current_layer: int):
        """Prefetch layers ahead of current execution point."""
        for offset in range(1, self.prefetch_ahead + 1):
            next_layer = current_layer + offset
            if next_layer < self.num_layers and next_layer in self.cold_layers:
                self.prefetch_layer(next_layer)

    def evict_prefetched(self, layer_idx: int):
        """Evict a prefetched layer from cache."""
        self._prefetched.pop(layer_idx, None)

    def get_stats(self) -> dict:
        return {
            "num_hot": len(self.hot_layers),
            "num_cold": len(self.cold_layers),
            "hot_start": self.hot_start,
            "prefetched": len(self._prefetched),
            "hot_mb": sum(w.nbytes for w in self._hot_weights.values()) / 1e6,
            "cold_mb": sum(w.nbytes for w in self._cold_weights.values()) / 1e6,
        }

    def __del__(self):
        self._executor.shutdown(wait=False)
