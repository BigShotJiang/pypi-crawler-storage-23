"""Full Llama forward pass for inference.

Implements LlamaForCausalLM with:
- Prefill path: scaled dot-product attention with causal mask
- Decode path: standard attention on KV-cache
- GQA: Grouped Query Attention (3 query heads per KV head for 3B)
- RoPE: Rotary Position Embeddings (theta=500000)
- SwiGLU: Fused gate/up projection with SiLU activation
"""

from __future__ import annotations

import logging
from pathlib import Path

import numpy as np

from .kv_cache import KVCache
from .model_config import LlamaConfig
from .rms_norm import RMSNorm

logger = logging.getLogger(__name__)


def _silu(x: np.ndarray) -> np.ndarray:
    x_f32 = x.astype(np.float32)
    return (x_f32 / (1.0 + np.exp(-x_f32))).astype(x.dtype)


def _repeat_kv(x: np.ndarray, n_rep: int) -> np.ndarray:
    if n_rep == 1:
        return x
    batch, num_kv_heads, seq_len, head_dim = x.shape
    x = x[:, :, np.newaxis, :, :]
    x = np.broadcast_to(x, (batch, num_kv_heads, n_rep, seq_len, head_dim))
    return x.reshape(batch, num_kv_heads * n_rep, seq_len, head_dim)


def _apply_rope_cpu(q_or_k, positions, theta=500000.0):
    _, _, _, head_dim = q_or_k.shape
    half_dim = head_dim // 2
    inv_freq = 1.0 / (theta ** (np.arange(0, head_dim, 2, dtype=np.float32) / head_dim))
    angles = np.einsum("bs,d->bsd", positions.astype(np.float32), inv_freq)
    cos_vals = np.cos(angles)[:, np.newaxis, :, :]
    sin_vals = np.sin(angles)[:, np.newaxis, :, :]
    x = q_or_k.astype(np.float32)
    x1, x2 = x[..., :half_dim], x[..., half_dim:]
    out = np.empty_like(x)
    out[..., :half_dim] = x1 * cos_vals - x2 * sin_vals
    out[..., half_dim:] = x2 * cos_vals + x1 * sin_vals
    return out.astype(q_or_k.dtype)


def _softmax(x, axis=-1):
    x_f32 = x.astype(np.float32)
    x_max = np.max(x_f32, axis=axis, keepdims=True)
    exp_x = np.exp(x_f32 - x_max)
    return (exp_x / np.sum(exp_x, axis=axis, keepdims=True)).astype(x.dtype)


class LlamaForCausalLM:
    """Llama model for causal language modeling.

    Usage:
        model = LlamaForCausalLM.from_pretrained("meta-llama/Llama-3.2-3B-Instruct")
        logits, kv_cache = model.prefill(token_ids)
        next_logits = model.decode_step(next_token, kv_cache)
    """

    def __init__(self, config: LlamaConfig, weights: dict[str, np.ndarray], dtype: str = "fp16", vulkan_backend=None):
        self.config = config
        self.dtype = np.float16 if dtype == "fp16" else np.float32
        self.vulkan = vulkan_backend
        if self.vulkan is None:
            try:
                import grilly
                self.vulkan = grilly.Compute()
                logger.info("Auto-initialized Vulkan backend via grilly.Compute()")
            except Exception as e:
                logger.warning("Vulkan backend unavailable, using CPU: %s", e)
        # Raise weight cache limit for inference (default 32 is too low for full models)
        if self.vulkan is not None:
            fnn = getattr(self.vulkan, 'fnn', None)
            if fnn is not None and hasattr(fnn, '_WEIGHT_CACHE_MAX'):
                fnn._WEIGHT_CACHE_MAX = max(fnn._WEIGHT_CACHE_MAX, 512)
        self._weights = {}
        self._gpu_weights = {}  # name -> VulkanTensor (GPU-resident)
        self._load_weights(weights)
        self._upload_weights_to_gpu()
        self.rms_norm = RMSNorm(eps=config.rms_norm_eps, vulkan_backend=self.vulkan)
        logger.info(
            "LlamaForCausalLM: %d layers, %d params, dtype=%s, backend=%s, gpu_resident=%d",
            config.num_layers, sum(w.size for w in self._weights.values()), dtype,
            "vulkan" if self.vulkan else "cpu", len(self._gpu_weights),
        )

    def _load_weights(self, weights):
        for name, tensor in weights.items():
            self._weights[name] = tensor.astype(self.dtype)
        required = ["model.embed_tokens.weight", "model.norm.weight"]
        for r in required:
            if r not in self._weights:
                raise ValueError(f"Missing required weight: {r}")
        for i in range(self.config.num_layers):
            prefix = f"model.layers.{i}"
            for suffix in [
                ".input_layernorm.weight", ".self_attn.q_proj.weight",
                ".self_attn.k_proj.weight", ".self_attn.v_proj.weight",
                ".self_attn.o_proj.weight", ".post_attention_layernorm.weight",
                ".mlp.gate_proj.weight", ".mlp.up_proj.weight", ".mlp.down_proj.weight",
            ]:
                if prefix + suffix not in self._weights:
                    raise ValueError(f"Missing weight: {prefix + suffix}")

    def _upload_weights_to_gpu(self):
        """Pre-upload projection weights to GPU via grilly's weight pinning cache.

        Grilly's fnn.linear() caches weight buffers keyed by (id, shape, ctypes.data).
        By pre-casting all 2D weights to contiguous float32 and running a dummy forward,
        we populate the cache so subsequent calls are zero-upload cache hits.
        """
        if self.vulkan is None:
            return
        fnn = getattr(self.vulkan, 'fnn', None)
        if fnn is None:
            return

        # First: ensure all 2D weights are contiguous float32 (stored in _weights)
        # so the same object is reused every call -> cache hit
        for name in list(self._weights.keys()):
            w = self._weights[name]
            if w.ndim == 2:
                self._weights[name] = np.ascontiguousarray(w, dtype=np.float32)

        # Warm the GPU weight cache with a dummy forward per weight matrix
        uploaded = 0
        for name, w in self._weights.items():
            if w.ndim != 2:
                continue
            try:
                dummy_in = np.zeros((1, w.shape[1]), dtype=np.float32)
                fnn.linear(dummy_in, w)
                uploaded += 1
            except Exception as e:
                logger.debug("Failed to pre-cache weight %s: %s", name, e)

        logger.info("Pre-uploaded %d weight matrices to GPU (pinned cache)", uploaded)

    def _w(self, name):
        return self._weights[name]

    def _matmul(self, x, weight):
        """Matrix multiply using Vulkan GPU with weight cache, CPU fallback."""
        if self.vulkan is not None:
            try:
                # weight is already contiguous float32 from _upload_weights_to_gpu,
                # so grilly's weight cache will hit (same id + ctypes.data pointer)
                return self.vulkan.fnn.linear(x.astype(np.float32), weight)
            except Exception:
                pass
        return (x.astype(np.float32) @ weight.astype(np.float32).T).astype(self.dtype)

    def forward(self, token_ids, position_ids=None, kv_cache=None):
        batch_size, seq_len = token_ids.shape
        if position_ids is None:
            start = kv_cache.seq_length if kv_cache else 0
            position_ids = np.tile(np.arange(start, start + seq_len, dtype=np.int32), (batch_size, 1))
        hidden = self._w("model.embed_tokens.weight")[token_ids]
        for layer_idx in range(self.config.num_layers):
            hidden = self._transformer_layer(hidden, position_ids, layer_idx, kv_cache)
        hidden = self.rms_norm.forward(hidden, self._w("model.norm.weight"))
        lm_weight = self._w("model.embed_tokens.weight") if self.config.tie_word_embeddings else self._w("lm_head.weight")
        return self._matmul(hidden, lm_weight).astype(np.float32)

    def _transformer_layer(self, hidden, position_ids, layer_idx, kv_cache):
        prefix = f"model.layers.{layer_idx}"
        batch_size, seq_len, _ = hidden.shape
        residual = hidden
        hidden = self.rms_norm.forward(hidden, self._w(f"{prefix}.input_layernorm.weight"))
        Q = self._matmul(hidden, self._w(f"{prefix}.self_attn.q_proj.weight"))
        K = self._matmul(hidden, self._w(f"{prefix}.self_attn.k_proj.weight"))
        V = self._matmul(hidden, self._w(f"{prefix}.self_attn.v_proj.weight"))
        Q = Q.reshape(batch_size, seq_len, self.config.num_heads, self.config.head_dim).transpose(0, 2, 1, 3)
        K = K.reshape(batch_size, seq_len, self.config.num_kv_heads, self.config.head_dim).transpose(0, 2, 1, 3)
        V = V.reshape(batch_size, seq_len, self.config.num_kv_heads, self.config.head_dim).transpose(0, 2, 1, 3)
        Q = _apply_rope_cpu(Q, position_ids, self.config.rope_theta)
        K = _apply_rope_cpu(K, position_ids, self.config.rope_theta)
        if kv_cache is not None:
            K, V = kv_cache.update(layer_idx, K, V)
        K_expanded = _repeat_kv(K, self.config.num_kv_groups)
        V_expanded = _repeat_kv(V, self.config.num_kv_groups)
        scale = 1.0 / np.sqrt(self.config.head_dim).astype(np.float32)
        Q_f32, K_f32, V_f32 = Q.astype(np.float32), K_expanded.astype(np.float32), V_expanded.astype(np.float32)
        scores = np.matmul(Q_f32, K_f32.transpose(0, 1, 3, 2)) * scale
        if seq_len > 1:
            kv_len = K_expanded.shape[2]
            mask = np.triu(np.full((seq_len, kv_len), -np.inf, dtype=np.float32), k=kv_len - seq_len + 1)
            scores = scores + mask[np.newaxis, np.newaxis, :, :]
        weights = _softmax(scores)
        attn_out = np.matmul(weights, V_f32).astype(self.dtype)
        attn_out = attn_out.transpose(0, 2, 1, 3).reshape(batch_size, seq_len, -1)
        hidden = self._matmul(attn_out, self._w(f"{prefix}.self_attn.o_proj.weight"))
        hidden = (residual.astype(np.float32) + hidden.astype(np.float32)).astype(self.dtype)
        residual = hidden
        hidden = self.rms_norm.forward(hidden, self._w(f"{prefix}.post_attention_layernorm.weight"))
        gate = self._matmul(hidden, self._w(f"{prefix}.mlp.gate_proj.weight"))
        up = self._matmul(hidden, self._w(f"{prefix}.mlp.up_proj.weight"))
        hidden = (_silu(gate) * up.astype(np.float32)).astype(self.dtype)
        hidden = self._matmul(hidden, self._w(f"{prefix}.mlp.down_proj.weight"))
        return (residual.astype(np.float32) + hidden.astype(np.float32)).astype(self.dtype)

    def prefill(self, token_ids):
        kv_cache = KVCache(self.config, max_batch=token_ids.shape[0])
        logits = self.forward(token_ids, kv_cache=kv_cache)
        return logits, kv_cache

    def decode_step(self, token_id, kv_cache):
        return self.forward(token_id, kv_cache=kv_cache)

    @classmethod
    def from_pretrained(cls, model_id_or_path, dtype="fp16", vulkan_backend=None):
        from .weights import load_safetensors_fp16
        config = LlamaConfig.from_pretrained(model_id_or_path)
        path = Path(model_id_or_path)
        if path.is_dir():
            weights = load_safetensors_fp16(path)
        else:
            from huggingface_hub import snapshot_download
            weights = load_safetensors_fp16(snapshot_download(model_id_or_path))
        return cls(config, weights, dtype=dtype, vulkan_backend=vulkan_backend)

    def memory_footprint(self):
        weight_bytes = sum(w.nbytes for w in self._weights.values())
        return {"weights_gb": weight_bytes / (1024 ** 3), "dtype": str(self.dtype), "num_params": sum(w.size for w in self._weights.values())}
