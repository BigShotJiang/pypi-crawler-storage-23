"""RMSNorm operation for Llama-family models.

RMSNorm(x) = x * rsqrt(mean(x^2) + eps) * weight
No bias, no mean subtraction (simpler than LayerNorm).
Supports Vulkan GPU acceleration with CPU fallback.
"""

from __future__ import annotations

import logging

import numpy as np

logger = logging.getLogger(__name__)


class RMSNorm:
    """RMSNorm with optional Vulkan GPU acceleration.

    Args:
        eps: Epsilon for numerical stability.
        vulkan_backend: Optional grilly VulkanCompute instance.
    """

    def __init__(self, eps: float = 1e-5, vulkan_backend=None):
        self.eps = eps
        self.vulkan = vulkan_backend

    def forward(self, x: np.ndarray, weight: np.ndarray, eps: float | None = None) -> np.ndarray:
        """Apply RMSNorm.

        Args:
            x: Input tensor, any shape with last dim = hidden_dim.
            weight: Scale weights (hidden_dim,).
            eps: Override default epsilon.

        Returns:
            Normalized tensor, same shape as x.
        """
        if eps is None:
            eps = self.eps

        if self.vulkan is not None and hasattr(self.vulkan, 'fnn') and hasattr(self.vulkan.fnn, 'rms_norm'):
            return self.vulkan.fnn.rms_norm(x, weight, eps)

        return self._forward_cpu(x, weight, eps)

    def _forward_cpu(self, x: np.ndarray, weight: np.ndarray, eps: float) -> np.ndarray:
        """CPU RMSNorm implementation."""
        x_f32 = x.astype(np.float32)
        variance = np.mean(x_f32 ** 2, axis=-1, keepdims=True)
        x_normed = x_f32 * np.reciprocal(np.sqrt(variance + eps))
        result = x_normed * weight.astype(np.float32)
        return result.astype(x.dtype)
