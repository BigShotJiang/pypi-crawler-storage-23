"""Architecture configuration for Llama-family models."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


@dataclass
class LlamaConfig:
    """Llama 3.x architecture configuration.

    Defaults match Llama 3.2 3B Instruct (elephant-3b base).
    """

    num_layers: int = 28
    hidden_dim: int = 3072
    num_heads: int = 24        # query heads
    num_kv_heads: int = 8      # GQA: 3 query heads per KV head
    head_dim: int = 128
    intermediate_size: int = 8192  # FFN
    vocab_size: int = 128256
    rope_theta: float = 500000.0
    rms_norm_eps: float = 1e-5
    max_seq_len: int = 4096
    tie_word_embeddings: bool = True  # lm_head = embed_tokens
    bos_token_id: int = 128000
    eos_token_id: int = 128001
    model_type: str = "llama"

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> LlamaConfig:
        """Create from a dictionary (e.g. HF config.json contents)."""
        field_map = {
            "num_hidden_layers": "num_layers",
            "hidden_size": "hidden_dim",
            "num_attention_heads": "num_heads",
            "num_key_value_heads": "num_kv_heads",
        }
        kwargs = {}
        for json_key, attr in field_map.items():
            if json_key in d:
                kwargs[attr] = d[json_key]
        for f in cls.__dataclass_fields__:
            if f in d and f not in kwargs:
                kwargs[f] = d[f]
        return cls(**kwargs)

    @classmethod
    def from_pretrained(cls, model_id_or_path: str) -> LlamaConfig:
        """Load config from a local path or HF model id."""
        path = Path(model_id_or_path)
        if path.is_dir():
            config_path = path / "config.json"
            if not config_path.exists():
                raise FileNotFoundError(f"No config.json in {path}")
            with open(config_path) as f:
                data = json.load(f)
            return cls.from_dict(data)

        try:
            from huggingface_hub import hf_hub_download
            config_path = hf_hub_download(model_id_or_path, "config.json")
            with open(config_path) as f:
                data = json.load(f)
            return cls.from_dict(data)
        except ImportError:
            raise ImportError(
                "huggingface_hub required for downloading from HF. "
                "Install with: pip install huggingface_hub"
            )

    @property
    def num_kv_groups(self) -> int:
        """Number of query heads per KV head (GQA group size)."""
        return self.num_heads // self.num_kv_heads

    def to_dict(self) -> dict[str, Any]:
        from dataclasses import asdict
        return asdict(self)
