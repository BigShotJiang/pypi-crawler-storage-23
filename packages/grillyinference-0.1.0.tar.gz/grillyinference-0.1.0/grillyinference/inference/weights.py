"""Weight loading utilities for Llama-family models.

Supports safetensors fp16 loading, LoRA merge, and export.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)


def load_safetensors_fp16(model_path: str | Path) -> dict[str, np.ndarray]:
    """Load HF safetensors, cast to fp16 numpy arrays.

    Handles both single-file and sharded safetensors checkpoints.
    """
    from safetensors import safe_open

    model_path = Path(model_path)
    weights: dict[str, np.ndarray] = {}

    if model_path.is_file():
        files = [model_path]
    else:
        index_path = model_path / "model.safetensors.index.json"
        if index_path.exists():
            with open(index_path) as f:
                index = json.load(f)
            shard_files = set(index["weight_map"].values())
            files = [model_path / f for f in sorted(shard_files)]
        else:
            files = sorted(model_path.glob("*.safetensors"))

    if not files:
        raise FileNotFoundError(f"No safetensors files found in {model_path}")

    # Try torch framework first (handles bfloat16), fall back to numpy
    try:
        import torch
        _use_torch = True
    except ImportError:
        _use_torch = False

    for fpath in files:
        logger.info("Loading %s", fpath.name)
        if _use_torch:
            from safetensors.torch import load_file
            state_dict = load_file(str(fpath))
            for key, tensor in state_dict.items():
                weights[key] = tensor.to(torch.float16).numpy()
        else:
            with safe_open(str(fpath), framework="numpy") as f:
                for key in f.keys():
                    tensor = f.get_tensor(key)
                    weights[key] = tensor.astype(np.float16) if tensor.dtype != np.float16 else tensor

    logger.info("Loaded %d weight tensors", len(weights))
    return weights


def to_fp16(weights: dict[str, np.ndarray]) -> dict[str, np.ndarray]:
    """Cast all weight tensors to fp16."""
    return {k: v.astype(np.float16) if v.dtype != np.float16 else v for k, v in weights.items()}


def load_merged_checkpoint(
    base_model_id: str,
    lora_checkpoint: str | Path,
    lora_config: dict | None = None,
) -> dict[str, np.ndarray]:
    """Load base HF weights, merge LoRA checkpoint, return fp16.

    Args:
        base_model_id: HF model id or local path for base weights.
        lora_checkpoint: Path to LoRA checkpoint directory.
        lora_config: Optional dict with rank, alpha, target_modules.
    """
    lora_checkpoint = Path(lora_checkpoint)

    logger.info("Loading base model: %s", base_model_id)
    base_path = Path(base_model_id)
    if base_path.is_dir():
        base_weights = load_safetensors_fp16(base_path)
    else:
        try:
            from huggingface_hub import snapshot_download
            local_dir = snapshot_download(base_model_id)
            base_weights = load_safetensors_fp16(local_dir)
        except ImportError:
            raise ImportError("huggingface_hub required. Install with: pip install huggingface_hub")

    logger.info("Loading LoRA checkpoint: %s", lora_checkpoint)
    lora_weights = {}
    for f in sorted(lora_checkpoint.glob("*.npz")):
        data = np.load(f)
        for key in data.files:
            lora_weights[key] = data[key]
    for f in sorted(lora_checkpoint.glob("*.safetensors")):
        from safetensors import safe_open
        with safe_open(str(f), framework="numpy") as sf:
            for key in sf.keys():
                lora_weights[key] = sf.get_tensor(key)

    if not lora_weights:
        logger.warning("No LoRA weights found in %s, returning base weights", lora_checkpoint)
        return base_weights

    alpha = 1.0
    rank = None
    if lora_config:
        alpha = lora_config.get("alpha", 1.0)
        rank = lora_config.get("rank", None)

    merged_count = 0
    for key in list(base_weights.keys()):
        lora_a_key = key.replace(".weight", ".lora_A")
        lora_b_key = key.replace(".weight", ".lora_B")
        if lora_a_key in lora_weights and lora_b_key in lora_weights:
            A = lora_weights[lora_a_key].astype(np.float32)
            B = lora_weights[lora_b_key].astype(np.float32)
            if rank is None:
                rank = A.shape[0]
            scale = alpha / rank
            delta = (B @ A).astype(np.float32) * scale
            base_w = base_weights[key].astype(np.float32)
            base_weights[key] = (base_w + delta).astype(np.float16)
            merged_count += 1

    logger.info("Merged %d LoRA layers (rank=%s, alpha=%s)", merged_count, rank, alpha)
    return base_weights


def save_fp16_safetensors(weights: dict[str, np.ndarray], output_dir: str | Path) -> Path:
    """Save merged fp16 weights as safetensors for fast reload."""
    from safetensors.numpy import save_file

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    fp16_weights = to_fp16(weights)
    output_path = output_dir / "model.safetensors"
    save_file(fp16_weights, str(output_path))
    logger.info("Saved %d tensors to %s", len(fp16_weights), output_path)
    return output_path


def estimate_model_size(weights: dict[str, np.ndarray]) -> dict[str, float]:
    """Estimate model memory requirements in GB."""
    total_params = sum(w.size for w in weights.values())
    return {
        "total_params": total_params,
        "fp16_gb": total_params * 2 / (1024 ** 3),
        "fp32_gb": total_params * 4 / (1024 ** 3),
        "int8_gb": total_params * 1 / (1024 ** 3),
        "int4_gb": total_params * 0.5 / (1024 ** 3),
    }
