"""Text generation with sampling for Llama models.

Supports temperature, top-k, top-p (nucleus) sampling, and streaming.
Implements Llama 3.2 Instruct chat template.
"""

from __future__ import annotations

import logging
import time
from typing import Generator

import numpy as np

from .kv_cache import KVCache
from .transformer import LlamaForCausalLM

logger = logging.getLogger(__name__)

LLAMA3_STOP_TOKENS = [128001, 128008, 128009]


def _sample_top_k_top_p(logits, temperature=0.7, top_k=50, top_p=0.9):
    if temperature <= 0:
        return int(np.argmax(logits))
    logits = logits.astype(np.float64) / temperature
    if 0 < top_k < len(logits):
        indices = np.argpartition(logits, -top_k)[-top_k:]
        mask = np.full_like(logits, -np.inf)
        mask[indices] = logits[indices]
        logits = mask
    logits_max = np.max(logits)
    exp_logits = np.exp(logits - logits_max)
    probs = exp_logits / np.sum(exp_logits)
    if top_p < 1.0:
        sorted_indices = np.argsort(probs)[::-1]
        sorted_probs = probs[sorted_indices]
        cumulative = np.cumsum(sorted_probs)
        cutoff_idx = min(np.searchsorted(cumulative, top_p) + 1, len(sorted_probs))
        mask = np.zeros_like(probs)
        mask[sorted_indices[:cutoff_idx]] = probs[sorted_indices[:cutoff_idx]]
        probs = mask
        prob_sum = np.sum(probs)
        if prob_sum > 0:
            probs = probs / prob_sum
    try:
        return int(np.random.choice(len(probs), p=probs))
    except ValueError:
        return int(np.argmax(probs))


class TextGenerator:
    """Text generation engine with sampling.

    Args:
        model: LlamaForCausalLM instance.
        tokenizer: HuggingFace tokenizer (or any with encode/decode).
    """

    def __init__(self, model: LlamaForCausalLM, tokenizer):
        self.model = model
        self.tokenizer = tokenizer

    def generate(self, prompt, max_tokens=512, temperature=0.7, top_k=50, top_p=0.9, stop_tokens=None, stream=False):
        if stop_tokens is None:
            stop_tokens = LLAMA3_STOP_TOKENS
        if stream:
            return self._generate_stream(prompt, max_tokens, temperature, top_k, top_p, stop_tokens)
        return "".join(self._generate_stream(prompt, max_tokens, temperature, top_k, top_p, stop_tokens))

    def _generate_stream(self, prompt, max_tokens, temperature, top_k, top_p, stop_tokens):
        input_ids = self.tokenizer.encode(prompt, add_special_tokens=True)
        input_array = np.array([input_ids], dtype=np.int32)
        t_start = time.perf_counter()
        logits, kv_cache = self.model.prefill(input_array)
        last_logits = logits[0, -1, :]
        t_prefill = time.perf_counter()
        logger.info("Prefill: %d tokens in %.1f ms", len(input_ids), (t_prefill - t_start) * 1000)
        generated_ids = []
        decode_times = []
        for step in range(max_tokens):
            t_step = time.perf_counter()
            token_id = _sample_top_k_top_p(last_logits, temperature, top_k, top_p)
            if token_id in stop_tokens:
                break
            generated_ids.append(token_id)
            yield self.tokenizer.decode([token_id], skip_special_tokens=False)
            token_array = np.array([[token_id]], dtype=np.int32)
            logits = self.model.decode_step(token_array, kv_cache)
            last_logits = logits[0, -1, :]
            decode_times.append(time.perf_counter() - t_step)
            if step > 0 and step % 256 == 0:
                kv_cache.compress_cold_pages()
        if generated_ids:
            total = sum(decode_times)
            logger.info("Decode: %d tokens, %.1f ms/tok, %.1f tok/s", len(generated_ids), total / len(generated_ids) * 1000, len(generated_ids) / total if total > 0 else 0)

    def chat(self, messages, **kwargs):
        return self.generate(self._format_chat(messages), **kwargs)

    def _format_chat(self, messages):
        parts = ["<|begin_of_text|>"]
        for msg in messages:
            parts.append(f"<|start_header_id|>{msg['role']}<|end_header_id|>\n\n{msg['content']}<|eot_id|>")
        parts.append("<|start_header_id|>assistant<|end_header_id|>\n\n")
        return "".join(parts)

    def benchmark(self, prompt="The quick brown fox", num_tokens=128, warmup=0):
        input_ids = self.tokenizer.encode(prompt, add_special_tokens=True)
        input_array = np.array([input_ids], dtype=np.int32)
        for _ in range(warmup):
            self.model.prefill(input_array)
        t0 = time.perf_counter()
        logits, kv_cache = self.model.prefill(input_array)
        t_prefill = time.perf_counter() - t0
        last_logits = logits[0, -1, :]
        decode_times = []
        for _ in range(num_tokens):
            token_id = int(np.argmax(last_logits))
            if token_id in LLAMA3_STOP_TOKENS:
                break
            t0 = time.perf_counter()
            logits = self.model.decode_step(np.array([[token_id]], dtype=np.int32), kv_cache)
            decode_times.append(time.perf_counter() - t0)
            last_logits = logits[0, -1, :]
        avg_decode = np.mean(decode_times) if decode_times else 0
        return {
            "prompt_tokens": len(input_ids), "generated_tokens": len(decode_times),
            "prefill_ms": t_prefill * 1000, "prefill_tok_per_sec": len(input_ids) / t_prefill if t_prefill > 0 else 0,
            "decode_ms_per_tok": avg_decode * 1000, "decode_tok_per_sec": 1.0 / avg_decode if avg_decode > 0 else 0,
            "kv_cache_stats": kv_cache.get_stats(),
        }
