from .dispatcher import FunctionCallDispatcher

__all__ = ["FunctionCallDispatcher"]
