# Extract Documentation

Capture patterns for future agents.

<!-- TODO: This document is a skeleton. Fill in the sections below. -->

## Overview

<!-- TODO: What documentation extraction is -->

## The docs/learned/ Directory

<!-- TODO: Agent-generated, agent-consumed documentation -->

## When to Extract Documentation

<!-- TODO: Signs that a pattern should be documented -->

## Creating a Learn Plan

<!-- TODO: /erk:learn command -->

## Documentation Structure

<!-- TODO: How learned docs are organized -->

## How Agents Use Documentation

<!-- TODO: AGENTS.md routing, skill loading -->

## See Also

The `docs/learned/` directory contains agent-generated documentation for AI agents.
