<!-- AUTO-GENERATED FILE - DO NOT EDIT DIRECTLY -->
<!-- Edit source frontmatter, then run 'erk docs sync' to regenerate. -->

# Gateway Documentation

- **[codespace-gateway.md](codespace-gateway.md)** — adding a new codespace SSH operation to the gateway, deciding whether a new gateway needs dry-run and printing implementations, testing code that uses os.execvp or NoReturn methods, choosing between exec_ssh_interactive and run_ssh_command
- **[codespace-registry.md](codespace-registry.md)** — working with GitHub Codespace registration or lookup, adding a gateway that separates read-only ABC from mutation functions, choosing between ABC methods vs standalone functions for gateway operations
