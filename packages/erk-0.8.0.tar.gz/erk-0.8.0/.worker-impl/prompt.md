eliminate erk:prepare and anything it exclusively calls
