#!/bin/bash
echo "fake-driven-testing: If not loaded, load now. Always abide by its rules."
