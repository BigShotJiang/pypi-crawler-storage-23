# Huawei Intel SDK

A  Python SDK for Huawei's Public Threat Intelligence.


## Installation

```bash
pip install huawei-intel-sdk
```

## Usage

### Python API

```python
from huawei_intel import HuaweiIntelClient

client = HuaweiIntelClient()

# Check IP
print(client.get_ip_intel("1.1.1.1"))

# Check URL (Automatically cleans to domain)
print(client.get_domain_intel("https://bad-site.com/path"))

# Check file hash (MD5, SHA1, SHA256, etc.)
print(client.get_file_intel("a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"))

# Check Local File (Auto-hashes)
print(client.check_file("suspicious.exe"))
```

### Command Line Interface

```bash
# Check IP address
huawei-intel check 1.1.1.1

# Check domain
huawei-intel check bad-site.com

# Check file hash
huawei-intel check a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3

# Check local file
huawei-intel check-file suspicious.exe
