import requests
import json
from typing import Optional, Dict, Any
from .utils import extract_domain, calculate_file_hash, validate_ip_address
from .exceptions import APIError, NetworkError, SessionError, ValidationError, FileError

class HuaweiIntelClient:
    """
    Client for interacting with Huawei's Intelligence Service API.

    This class provides methods to query intelligence data for IP addresses,
    domains, and file hashes using Huawei's security intelligence platform.
    It handles session management and authentication automatically.
    """
    BASE_URL = "https://isecurity.huawei.com/public/ui/scp/v1/intelligence"
    SESSION_REFRESH_URL = "https://isecurity.huawei.com/security/service/intelligence/search"

    def __init__(self, user_agent: Optional[str] = None):
        """
        Initialize the HuaweiIntelClient with optional user agent.

        Parameters:
            user_agent (str, optional): User-Agent string for HTTP requests.
                Defaults to a standard browser user agent.
        """
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': user_agent or 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Referer': 'https://isecurity.huawei.com/',
        })

    def _refresh_session(self, target: str) -> None:
        """
        Refresh the session by performing a HEAD request to obtain WAF cookies.

        This method is called internally before each API request to ensure
        valid authentication cookies are present.

        Parameters:
            target (str): The target IP, domain, or hash for the session refresh.

        Returns:
            None

        Raises:
            SessionError: If session refresh fails.
            NetworkError: If network issues occur during refresh.
        """
        try:
            # The 418 status is expected; requests still saves the Set-Cookie headers
            response = self.session.head(
                self.SESSION_REFRESH_URL,
                params={'sv': target},
                timeout=10,
                allow_redirects=True
            )
            # Accept both 200 and 418 as valid responses
            if response.status_code not in [200, 418]:
                raise SessionError(f"Session refresh failed with status {response.status_code}: {response.text}")
        except requests.exceptions.Timeout:
            raise NetworkError("Session refresh timed out")
        except requests.exceptions.ConnectionError:
            raise NetworkError("Connection error during session refresh")
        except requests.exceptions.RequestException as e:
            raise SessionError(f"Session refresh request failed: {str(e)}")

    def _request(self, endpoint: str, key: str, value: str) -> Dict[str, Any]:
        """
        Make an authenticated GET request to the Huawei Intelligence API.

        Parameters:
            endpoint (str): The API endpoint (e.g., 'ip-addresses', 'domains').
            key (str): The query parameter key.
            value (str): The query parameter value.

        Returns:
            dict: Parsed JSON response from the API.

        Raises:
            ValidationError: If parameters are invalid.
            APIError: If the API returns an error.
            NetworkError: If network issues occur.
        """
        if not isinstance(value, str) or not value.strip():
            raise ValidationError(f"Parameter '{key}' must be a non-empty string")

        # Refresh session before every API call to ensure valid cookies
        self._refresh_session(value)

        try:
            response = self.session.get(
                f"{self.BASE_URL}/{endpoint}",
                params={key: value},
                timeout=15
            )

            # Check for HTTP errors
            if response.status_code != 200:
                try:
                    error_data = response.json()
                    error_message = error_data.get('message', error_data.get('error', response.text))
                except (ValueError, json.JSONDecodeError):
                    error_message = response.text or f"HTTP {response.status_code}"

                raise APIError(response.status_code, error_message)

            # Parse JSON response
            try:
                return response.json()
            except json.JSONDecodeError as e:
                raise APIError(response.status_code, f"Invalid JSON response: {str(e)}")

        except requests.exceptions.Timeout:
            raise NetworkError(f"Request timed out after 15 seconds")
        except requests.exceptions.ConnectionError:
            raise NetworkError("Connection error during API request")
        except requests.exceptions.RequestException as e:
            raise NetworkError(f"Request failed: {str(e)}")

    def get_ip_intel(self, ip: str) -> Dict[str, Any]:
        """
        Retrieve intelligence data for the given IP address.

        Parameters:
            ip (str): The IP address to query.

        Returns:
            dict: Intelligence data including threat scores and details.

        Raises:
            ValidationError: If the IP address is invalid.
        """
        if not isinstance(ip, str) or not ip.strip():
            raise ValidationError("IP address must be a non-empty string")

        ip = ip.strip()
        if not validate_ip_address(ip):
            raise ValidationError(f"Invalid IPv4 address format: {ip}")

        return self._request("ip-addresses", "ip", ip)

    def get_domain_intel(self, url_or_domain: str) -> Dict[str, Any]:
        """
        Retrieve intelligence data for the given domain or URL.

        Parameters:
            url_or_domain (str): The domain or URL to query.

        Returns:
            dict: Intelligence data for the extracted domain.

        Raises:
            ValidationError: If the domain/URL is invalid.
        """
        if not isinstance(url_or_domain, str) or not url_or_domain.strip():
            raise ValidationError("Domain/URL must be a non-empty string")

        try:
            domain = extract_domain(url_or_domain)
            return self._request("domains", "domain", domain)
        except ValidationError:
            raise  # Re-raise validation errors from extract_domain
        except Exception as e:
            raise ValidationError(f"Failed to process domain/URL '{url_or_domain}': {str(e)}")

    def get_file_intel(self, file_hash: str) -> Dict[str, Any]:
        """
        Retrieve intelligence data for the given file hash.

        Parameters:
            file_hash (str): The file hash (MD5, SHA1, SHA256, etc.) to query.

        Returns:
            dict: Intelligence data for the file hash.

        Raises:
            ValidationError: If the hash is invalid.
        """
        if not isinstance(file_hash, str) or not file_hash.strip():
            raise ValidationError("File hash must be a non-empty string")

        file_hash = file_hash.strip().lower()

        # Validate hash format (MD5: 32 chars, SHA1: 40 chars, SHA256: 64 chars, etc.)
        valid_lengths = {32, 40, 56, 64, 96, 128}  # MD5, SHA1, SHA224, SHA256, SHA384, SHA512
        if len(file_hash) not in valid_lengths:
            raise ValidationError(f"Invalid hash length {len(file_hash)}. Expected MD5 (32), SHA1 (40), SHA224 (56), SHA256 (64), SHA384 (96), or SHA512 (128) characters")

        # Validate hexadecimal format
        if not all(c in '0123456789abcdefABCDEF' for c in file_hash):
            raise ValidationError("Hash must contain only hexadecimal characters (0-9, a-f, A-F)")

        return self._request("files", "hash", file_hash)

    def check_file(self, filepath: str) -> Dict[str, Any]:
        """
        Calculate the SHA256 hash of the local file and retrieve intelligence data.

        Parameters:
            filepath (str): Path to the local file.

        Returns:
            dict: Intelligence data for the file's hash.

        Raises:
            FileError: If file processing fails.
            ValidationError: If hash calculation fails.
        """
        try:
            file_hash = calculate_file_hash(filepath, 'sha256')
            return self.get_file_intel(file_hash)
        except (ValidationError, FileError):
            raise  # Re-raise our custom exceptions
        except Exception as e:
            raise FileError(f"Failed to process file '{filepath}': {str(e)}")
