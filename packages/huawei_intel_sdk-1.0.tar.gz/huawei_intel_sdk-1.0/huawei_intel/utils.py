import hashlib
import ipaddress
import re
from urllib.parse import urlparse
from pathlib import Path
from typing import Union
from .exceptions import ValidationError, FileError

def extract_domain(url: str) -> str:
    """
    Extract the domain name from a URL, stripping protocols and paths.

    Parameters:
        url (str): The URL to extract the domain from.

    Returns:
        str: The extracted domain in lowercase.

    Raises:
        ValidationError: If the URL is invalid or domain cannot be extracted.
    """
    if not isinstance(url, str) or not url.strip():
        raise ValidationError("URL must be a non-empty string")

    url = url.strip()
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url

    try:
        parsed = urlparse(url)
        if not parsed.netloc and not parsed.path:
            raise ValidationError(f"Invalid URL format: {url}")

        domain = parsed.netloc or parsed.path.split('/')[0]
        # Remove port if present
        domain = domain.split(':')[0] if ':' in domain else domain

        if not domain:
            raise ValidationError(f"Could not extract domain from: {url}")

        # Basic domain validation
        if not re.match(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$', domain):
            raise ValidationError(f"Invalid domain format: {domain}")

        return domain.lower()

    except Exception as e:
        raise ValidationError(f"Failed to parse URL '{url}': {str(e)}")

def validate_ip_address(ip: str) -> bool:
    """
    Validate if the given string is a valid IPv4 address.

    Parameters:
        ip (str): The IP address string to validate.

    Returns:
        bool: True if the string is a valid IPv4 address, False otherwise.
    """
    try:
        ipaddress.IPv4Address(ip)
        return True
    except ipaddress.AddressValueError:
        return False

def is_valid_domain(domain: str) -> bool:
    """
    Check if the given string resembles a valid domain name (not an IP address).

    Parameters:
        domain (str): The domain string to check.

    Returns:
        bool: True if the string looks like a domain, False otherwise.
    """
    if not domain:
        return False

    # Remove protocol if present
    if '://' in domain:
        domain = domain.split('://', 1)[1]

    # Remove path, query, fragment
    domain = domain.split('/', 1)[0].split('?', 1)[0].split('#', 1)[0]

    # Remove port
    domain = domain.split(':', 1)[0]

    # Check if it looks like an IP (basic check)
    parts = domain.split('.')
    if len(parts) == 4 and all(part.isdigit() for part in parts):
        return False

    # Basic domain validation - has at least one dot and contains valid characters
    return '.' in domain and all(c.isalnum() or c in '.-' for c in domain)

def is_valid_hash(hash_str: str) -> bool:
    """
    Check if the given string is a valid file hash.

    Parameters:
        hash_str (str): The hash string to check.

    Returns:
        bool: True if the string is a valid hexadecimal hash of supported length, False otherwise.
    """
    if not isinstance(hash_str, str) or not hash_str.strip():
        return False

    hash_str = hash_str.strip().lower()

    # Validate hash format (MD5: 32 chars, SHA1: 40 chars, SHA256: 64 chars, etc.)
    valid_lengths = {32, 40, 56, 64, 96, 128}  # MD5, SHA1, SHA224, SHA256, SHA384, SHA512
    if len(hash_str) not in valid_lengths:
        return False

    # Validate hexadecimal format
    return all(c in '0123456789abcdef' for c in hash_str)

def calculate_file_hash(filepath: Union[str, Path], algorithm: str = 'sha256') -> str:
    """
    Calculate the hash of a file using the specified algorithm.

    Parameters:
        filepath (Union[str, Path]): Path to the file to hash.
        algorithm (str, optional): Hash algorithm to use. Defaults to 'sha256'.
            Supported: md5, sha1, sha256, sha224, sha384, sha512.

    Returns:
        str: The hexadecimal hash string.

    Raises:
        ValidationError: If filepath is invalid or algorithm unsupported.
        FileError: If file does not exist, is not a file, is empty, or cannot be read.
    """
    if not isinstance(filepath, (str, Path)):
        raise ValidationError("Filepath must be a string or Path object")

    # Validate algorithm
    supported_algorithms = {'md5', 'sha1', 'sha256', 'sha224', 'sha384', 'sha512'}
    if algorithm.lower() not in supported_algorithms:
        raise ValidationError(f"Unsupported hash algorithm: {algorithm}. Supported: {', '.join(supported_algorithms)}")

    path = Path(filepath)

    try:
        if not path.exists():
            raise FileError(f"File not found: {path}")
        if not path.is_file():
            raise FileError(f"Path is not a file: {path}")
        if not path.stat().st_size > 0:
            raise FileError(f"File is empty: {path}")

        hasher = hashlib.new(algorithm.lower())
        with open(path, 'rb') as f:
            for chunk in iter(lambda: f.read(65536), b""):
                hasher.update(chunk)
        return hasher.hexdigest()

    except PermissionError:
        raise FileError(f"Permission denied accessing file: {path}")
    except OSError as e:
        raise FileError(f"Error reading file '{path}': {str(e)}")
    except Exception as e:
        raise FileError(f"Unexpected error processing file '{path}': {str(e)}")
