class HuaweiIntelError(Exception):
    """
    Base exception class for Huawei Intel SDK errors.

    This is the parent class for all custom exceptions raised by the SDK.
    It inherits from the built-in Exception class.
    """
    pass

class APIError(HuaweiIntelError):
    """
    Exception raised when the Huawei Intelligence API returns a non-200 status code.

    Attributes:
        status_code (int): The HTTP status code returned by the API.
    """
    def __init__(self, status_code: int, message: str) -> None:
        """
        Initialize the APIError with status code and message.

        Parameters:
            status_code (int): The HTTP status code.
            message (str): The error message from the API.
        """
        self.status_code = status_code
        super().__init__(f"API Error {status_code}: {message}")

class NetworkError(HuaweiIntelError):
    """
    Exception raised for network-related issues during API requests.

    This includes timeouts, connection errors, and other request exceptions.
    """
    pass

class SessionError(HuaweiIntelError):
    """
    Exception raised for session management or cookie-related failures.

    This occurs when the SDK fails to refresh or obtain necessary cookies
    for authentication with the Huawei Intelligence API.
    """
    pass

class ValidationError(HuaweiIntelError):
    """
    Exception raised when input validation fails.

    This includes invalid IP addresses, domains, file hashes, or other
    parameter validation errors.
    """
    pass

class FileError(HuaweiIntelError):
    """
    Exception raised for file-related issues.

    This includes file not found, permission denied, or other file
    processing errors.
    """
    pass
