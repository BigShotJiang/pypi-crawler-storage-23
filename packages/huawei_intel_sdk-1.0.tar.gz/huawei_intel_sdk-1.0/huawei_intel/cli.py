import argparse
import json
import sys
import os
from pathlib import Path
from .client import HuaweiIntelClient
from .exceptions import HuaweiIntelError, APIError, NetworkError, SessionError, ValidationError, FileError
from .utils import validate_ip_address, is_valid_domain, is_valid_hash

def main() -> None:
    """
    Main entry point for the Huawei Intel SDK Command Line Interface.

    This function sets up argument parsing for the CLI, validates inputs,
    interacts with the HuaweiIntelClient to fetch intelligence data,
    and outputs results in the specified format (text or JSON).

    The CLI supports two commands:
    - check: Retrieves intelligence for a given IP address or domain.
    - check-file: Analyzes a local file for intelligence.

    Parameters:
        None (arguments are parsed from sys.argv)

    Returns:
        None (exits with sys.exit on errors or completion)

    Raises:
        Various exceptions are caught internally and handled by printing
        error messages and exiting with appropriate codes.
    """
    parser = argparse.ArgumentParser(
        description="Huawei Intel SDK - Command Line Interface",
        prog="huawei-intel"
    )

    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # Check command for IP/domain
    check_parser = subparsers.add_parser('check', help='Check IP address, domain, or file hash')
    check_parser.add_argument('target', help='IP address, domain, or file hash to check')
    check_parser.add_argument('--format', choices=['json', 'text'], default='text',
                            help='Output format (default: text)')

    # Check file command
    file_parser = subparsers.add_parser('check-file', help='Check local file')
    file_parser.add_argument('filepath', help='Path to file to check')
    file_parser.add_argument('--format', choices=['json', 'text'], default='text',
                           help='Output format (default: text)')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Validate arguments before creating client
    if args.command == 'check':
        if not args.target or not args.target.strip():
            print("Error: Target cannot be empty", file=sys.stderr)
            sys.exit(1)
        args.target = args.target.strip()

    elif args.command == 'check-file':
        if not args.filepath:
            print("Error: File path cannot be empty", file=sys.stderr)
            sys.exit(1)

        filepath = Path(args.filepath)
        if not filepath.exists():
            print(f"Error: File not found: {filepath}", file=sys.stderr)
            sys.exit(1)
        if not filepath.is_file():
            print(f"Error: Path is not a file: {filepath}", file=sys.stderr)
            sys.exit(1)
        if filepath.stat().st_size == 0:
            print(f"Error: File is empty: {filepath}", file=sys.stderr)
            sys.exit(1)

    client = HuaweiIntelClient()

    try:
        if args.command == 'check':
        # Determine if target is IP, domain, or hash
            target = args.target
            if validate_ip_address(target):
                result = client.get_ip_intel(target)
                target_type = "IP"
            elif is_valid_domain(target):
                result = client.get_domain_intel(target)
                target_type = "Domain"
            elif is_valid_hash(target):
                result = client.get_file_intel(target)
                target_type = "Hash"
            else:
                print(f"Error: '{target}' is not a valid IP address, domain, or file hash", file=sys.stderr)
                sys.exit(1)

            if args.format == 'json':
                try:
                    print(json.dumps(result, indent=2))
                except (TypeError, ValueError) as e:
                    print(f"Error: Failed to serialize result as JSON: {e}", file=sys.stderr)
                    sys.exit(1)
            else:
                try:
                    print(f"{target_type} Intelligence for {target}:")
                    print(json.dumps(result, indent=2))
                except (TypeError, ValueError) as e:
                    print(f"Error: Failed to format result: {e}", file=sys.stderr)
                    print(f"Raw result: {result}", file=sys.stderr)
                    sys.exit(1)

        elif args.command == 'check-file':
            result = client.check_file(args.filepath)

            if args.format == 'json':
                try:
                    print(json.dumps(result, indent=2))
                except (TypeError, ValueError) as e:
                    print(f"Error: Failed to serialize result as JSON: {e}", file=sys.stderr)
                    sys.exit(1)
            else:
                try:
                    print(f"File Intelligence for {args.filepath}:")
                    print(json.dumps(result, indent=2))
                except (TypeError, ValueError) as e:
                    print(f"Error: Failed to format result: {e}", file=sys.stderr)
                    print(f"Raw result: {result}", file=sys.stderr)
                    sys.exit(1)

    except ValidationError as e:
        print(f"Validation Error: {e}", file=sys.stderr)
        sys.exit(1)
    except NetworkError as e:
        print(f"Network Error: {e}", file=sys.stderr)
        print("Check your internet connection and try again.", file=sys.stderr)
        sys.exit(1)
    except SessionError as e:
        print(f"Session Error: {e}", file=sys.stderr)
        print("The service may be temporarily unavailable. Try again later.", file=sys.stderr)
        sys.exit(1)
    except APIError as e:
        print(f"API Error: {e}", file=sys.stderr)
        sys.exit(1)
    except FileError as e:
        print(f"File Error: {e}", file=sys.stderr)
        sys.exit(1)
    except HuaweiIntelError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Failed to parse API response: {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        print("Please report this issue with the full error message.", file=sys.stderr)
        sys.exit(1)

if __name__ == '__main__':
    main()
