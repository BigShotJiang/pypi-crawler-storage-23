import pytest
from unittest.mock import Mock, patch, mock_open
import json
from huawei_intel import HuaweiIntelClient, HuaweiIntelError, APIError, NetworkError, SessionError, ValidationError, FileError
from huawei_intel.utils import extract_domain, calculate_file_hash, validate_ip_address

@pytest.fixture
def client():
    """Fixture to provide a HuaweiIntelClient instance."""
    return HuaweiIntelClient()

def test_client_initialization(client):
    """Test that client initializes with proper headers."""
    assert 'User-Agent' in client.session.headers
    assert 'Accept' in client.session.headers
    assert 'Referer' in client.session.headers

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
def test_get_ip_intel_success(mock_get, mock_head, client):
    """Test successful IP intelligence lookup."""
    # Mock the HEAD request for session refresh
    mock_head.return_value.status_code = 418

    # Mock successful API response
    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"ip": "1.1.1.1", "malicious": False}
    mock_get.return_value = mock_response

    result = client.get_ip_intel("1.1.1.1")
    assert result["ip"] == "1.1.1.1"
    assert not result["malicious"]

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
def test_get_domain_intel_success(mock_get, mock_head, client):
    """Test successful domain intelligence lookup."""
    mock_head.return_value.status_code = 418

    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"domain": "example.com", "reputation": "safe"}
    mock_get.return_value = mock_response

    result = client.get_domain_intel("https://example.com/path")
    assert result["domain"] == "example.com"
    assert result["reputation"] == "safe"

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
def test_get_file_intel_success(mock_get, mock_head, client):
    """Test successful file hash intelligence lookup."""
    mock_head.return_value.status_code = 418

    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"hash": "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3", "malware": True}
    mock_get.return_value = mock_response

    result = client.get_file_intel("a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3")
    assert result["hash"] == "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"
    assert result["malware"]

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
@patch('huawei_intel.utils.calculate_file_hash')
def test_check_file_success(mock_calculate_hash, mock_get, mock_head, client):
    """Test successful file checking."""
    mock_head.return_value.status_code = 418
    mock_calculate_hash.return_value = "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"

    mock_response = Mock()
    mock_response.status_code = 200
    mock_response.json.return_value = {"hash": "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3", "malware": False}
    mock_get.return_value = mock_response

    result = client.check_file("test.txt")
    assert result["hash"] == "a665a45920422f9d417e4867efdc4fb8a04a1f3fff1fa07e998e86f7f7a27ae3"
    assert not result["malware"]

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
def test_api_error_handling(mock_get, mock_head, client):
    """Test API error handling."""
    mock_head.return_value.status_code = 418

    mock_response = Mock()
    mock_response.status_code = 404
    mock_response.text = "Not found"
    mock_response.json.side_effect = json.JSONDecodeError("Invalid JSON", "", 0)
    mock_get.return_value = mock_response

    with pytest.raises(APIError) as exc_info:
        client.get_ip_intel("invalid")

    assert exc_info.value.status_code == 404
    assert "API Error 404" in str(exc_info.value)

@pytest.mark.parametrize("method,invalid_input", [
    ("get_ip_intel", ""),
    ("get_ip_intel", "999.999.999.999"),
    ("get_domain_intel", ""),
    ("get_domain_intel", "invalid..domain"),
    ("get_file_intel", ""),
    ("get_file_intel", "123"),
    ("get_file_intel", "gggggggggggggggggggggggggggggggg"),  # 32 chars invalid hex
])
def test_validation_errors(client, method, invalid_input):
    """Test input validation errors."""
    with pytest.raises(ValidationError):
        getattr(client, method)(invalid_input)

@patch('huawei_intel.client.requests.Session.head')
def test_session_error_handling(mock_head, client):
    """Test session refresh error handling."""
    mock_head.return_value.status_code = 500

    with pytest.raises(SessionError):
        client.get_ip_intel("1.1.1.1")

@patch('huawei_intel.client.requests.Session.head')
@patch('huawei_intel.client.requests.Session.get')
def test_network_error_handling(mock_get, mock_head, client):
    """Test network error handling."""
    mock_head.return_value.status_code = 418
    mock_get.side_effect = Exception("Network error")

    with pytest.raises(NetworkError):
        client.get_ip_intel("1.1.1.1")

@pytest.mark.parametrize("url,expected", [
    ("https://example.com/path", "example.com"),
    ("sub.example.com:8080", "sub.example.com"),
    ("http://test.org", "test.org"),
])
def test_extract_domain_success(url, expected):
    """Test successful domain extraction."""
    assert extract_domain(url) == expected

@pytest.mark.parametrize("invalid_url", ["", "invalid..domain", "://invalid"])
def test_extract_domain_errors(invalid_url):
    """Test domain extraction errors."""
    with pytest.raises(ValidationError):
        extract_domain(invalid_url)

@pytest.mark.parametrize("ip,expected", [
    ("192.168.1.1", True),
    ("1.1.1.1", True),
    ("999.999.999.999", False),
    ("not.an.ip", False),
    ("", False),
])
def test_validate_ip_address(ip, expected):
    """Test IP address validation."""
    assert validate_ip_address(ip) == expected

@patch('builtins.open', new_callable=mock_open, read_data=b"test data")
@patch('pathlib.Path.exists')
@patch('pathlib.Path.is_file')
@patch('pathlib.Path.stat')
def test_calculate_file_hash_success(mock_stat, mock_is_file, mock_exists, mock_file):
    """Test successful file hashing."""
    mock_exists.return_value = True
    mock_is_file.return_value = True
    mock_stat.return_value.st_size = 9

    result = calculate_file_hash("test.txt", "sha256")
    assert isinstance(result, str)
    assert len(result) == 64  # SHA256 hex length

@patch('pathlib.Path.exists')
def test_calculate_file_hash_file_not_found(mock_exists):
    """Test file hashing when file not found."""
    mock_exists.return_value = False

    with pytest.raises(FileError):
        calculate_file_hash("nonexistent.txt")

@pytest.mark.parametrize("algorithm", ["invalid_algorithm", "md6"])
def test_hash_algorithm_validation(algorithm):
    """Test hash algorithm validation."""
    with pytest.raises(ValidationError):
        calculate_file_hash("test.txt", algorithm)
