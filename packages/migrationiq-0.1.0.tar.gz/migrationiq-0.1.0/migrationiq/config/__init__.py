"""Configuration module for MigrationIQ."""
