"""Git integration module for MigrationIQ."""
