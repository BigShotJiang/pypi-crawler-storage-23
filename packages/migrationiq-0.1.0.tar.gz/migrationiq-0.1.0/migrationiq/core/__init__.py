"""Core engine module for MigrationIQ."""
