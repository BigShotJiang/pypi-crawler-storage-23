- Olivier Vitrac (founder/lead) | [olivier.vitrac@gmail.com](mailto:olivier.vitrac@gmail.com), [olivier.vitrac@adservio.fr](olivier.vitrac@adservio.fr) | Adservio Innovation Lab
- Contributors: (add yourself via PR)

