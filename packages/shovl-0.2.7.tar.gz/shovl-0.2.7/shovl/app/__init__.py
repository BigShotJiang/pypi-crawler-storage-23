from .app import ShovlApp

__all__ = ["ShovlApp"]
