Após a instalação do módulo, siga os seguintes passos para configurá-lo
para a empresa desejada:

1.  Definições \> Usuários & Empresas \> Empresas

2.  Selecione a empresa desejada

3.  Na visualização da empresa, clique na aba Fiscal

4.  Na subseção NFS-e, configure os seguintes campos:

    > - **Ambiente NFS-e:** Selecione a opção a ser usada no ambiente
    >   (Produção, Homologação)
    > - **Provedor NFS-e:** Selecione a opção FocusNFE
    > - **FocusNFe Token:** Informe o token de acesso da empresa. Obs.
    >   Este token é obtido através da plataforma da FocusNFE
    > - **Valor Tipo de Serviço:** Se necessário configure o campo que
    >   deve preencher o valor de tipo de serviço
    > - **Valor Código CNAE:** Se necessário configure o campo que deve
    >   preencher o valor do Código CNAE
