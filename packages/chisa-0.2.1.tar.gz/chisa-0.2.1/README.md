# ⚠️ DEPRECATED: RENAMED TO PHAETHON ⚠️
This package has been officially renamed and migrated. 
Please use the new package for all future updates:

**`pip install phaethon`**

GitHub: [rannd1nt/phaethon](https://github.com/rannd1nt/phaethon)