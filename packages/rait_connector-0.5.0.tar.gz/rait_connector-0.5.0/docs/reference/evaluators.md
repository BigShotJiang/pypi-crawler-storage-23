# Evaluators

## Orchestrator

::: rait_connector.evaluators.EvaluatorOrchestrator
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3

## Registry Functions

::: rait_connector.evaluators.create_evaluator
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3

::: rait_connector.evaluators.can_evaluate_metric
    options:
      show_root_heading: true
      show_source: false
      heading_level: 3
