# Client API

::: rait_connector.client.RAITClient
    options:
      show_root_heading: true
      show_source: false
      heading_level: 2
