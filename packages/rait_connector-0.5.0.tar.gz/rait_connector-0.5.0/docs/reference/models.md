# Data Models

::: rait_connector.models.EvaluationInput
    options:
      show_root_heading: true
      show_source: false
      heading_level: 2
