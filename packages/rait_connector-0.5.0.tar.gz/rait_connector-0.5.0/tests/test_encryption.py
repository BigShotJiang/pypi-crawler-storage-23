"""Tests for rait_connector.encryption."""

import pytest
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

from rait_connector.encryption import Encryptor, EncryptorError


@pytest.fixture(scope="module")
def rsa_keypair():
    """Generate a 2048-bit RSA key pair once per test session."""
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend(),
    )
    public_key = private_key.public_key()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem, private_key, public_key


class TestEncryptorRoundtrip:
    def test_bytes_payload(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        assert dec.decrypt(enc.encrypt(b"Hello, World!")) == b"Hello, World!"

    def test_string_payload(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        assert dec.decrypt(enc.encrypt("Hello, World!")) == b"Hello, World!"

    def test_unicode_payload(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        text = "こんにちは 🌏"
        result = dec.decrypt(enc.encrypt(text))
        assert result.decode("utf-8") == text

    def test_empty_bytes(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        assert dec.decrypt(enc.encrypt(b"")) == b""

    def test_large_payload(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        plaintext = b"x" * 100_000
        assert dec.decrypt(enc.encrypt(plaintext)) == plaintext

    def test_json_payload(self, rsa_keypair):
        import json

        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        data = json.dumps({"key": "value", "num": 42})
        result = dec.decrypt(enc.encrypt(data))
        assert json.loads(result) == {"key": "value", "num": 42}


class TestEncryptorKeyFormats:
    def test_pem_bytes_public_key(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)  # bytes
        dec = Encryptor(private_key=private_pem)
        assert dec.decrypt(enc.encrypt(b"test")) == b"test"

    def test_pem_string_public_key(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem.decode())  # str
        dec = Encryptor(private_key=private_pem.decode())
        assert dec.decrypt(enc.encrypt(b"test")) == b"test"

    def test_loaded_key_objects(self, rsa_keypair):
        private_pem, public_pem, private_key, public_key = rsa_keypair
        enc = Encryptor(public_key=public_key)  # loaded RSAPublicKey
        dec = Encryptor(private_key=private_key)  # loaded RSAPrivateKey
        assert dec.decrypt(enc.encrypt(b"test")) == b"test"

    def test_invalid_pem_raises(self):
        with pytest.raises(EncryptorError, match="Failed to load public key"):
            Encryptor(public_key=b"not-a-valid-pem-key")

    def test_invalid_private_pem_raises(self):
        with pytest.raises(EncryptorError, match="Failed to load private key"):
            Encryptor(
                private_key=b"-----BEGIN PRIVATE KEY-----\ngarbage\n-----END PRIVATE KEY-----\n"
            )


class TestEncryptorErrors:
    def test_encrypt_without_public_key_raises(self):
        enc = Encryptor()
        with pytest.raises(EncryptorError, match="Public key not provided"):
            enc.encrypt(b"data")

    def test_decrypt_without_private_key_raises(self):
        dec = Encryptor()
        with pytest.raises(EncryptorError, match="Private key not provided"):
            dec.decrypt(b"\x00" * 100)

    def test_decrypt_too_short_raises(self, rsa_keypair):
        private_pem, _, _, _ = rsa_keypair
        dec = Encryptor(private_key=private_pem)
        with pytest.raises(EncryptorError):
            dec.decrypt(b"\x00\x01\x02")  # less than 4 bytes header

    def test_decrypt_truncated_package_raises(self, rsa_keypair):
        private_pem, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        dec = Encryptor(private_key=private_pem)
        package = enc.encrypt(b"hello")
        # Truncate the package
        with pytest.raises(EncryptorError):
            dec.decrypt(package[:10])


class TestEncryptorRandomness:
    def test_different_package_each_call(self, rsa_keypair):
        _, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        # AES-GCM random nonce means packages are different each time
        assert enc.encrypt(b"same") != enc.encrypt(b"same")

    def test_package_is_bytes(self, rsa_keypair):
        _, public_pem, _, _ = rsa_keypair
        enc = Encryptor(public_key=public_pem)
        result = enc.encrypt(b"data")
        assert isinstance(result, bytes)
