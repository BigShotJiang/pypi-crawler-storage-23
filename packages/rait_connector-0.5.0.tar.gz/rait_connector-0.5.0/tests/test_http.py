"""Tests for rait_connector.http."""

import requests

from rait_connector.http import HttpSessionFactory, RetryConfig, get_retry_session


class TestRetryConfig:
    def test_from_settings_returns_config(self):
        config = RetryConfig.from_settings()
        assert isinstance(config, RetryConfig)

    def test_from_settings_has_total(self):
        config = RetryConfig.from_settings()
        assert config.total is not None

    def test_custom_values(self):
        config = RetryConfig(total=5, backoff_factor=2.0, status_forcelist=[429, 503])
        assert config.total == 5
        assert config.backoff_factor == 2.0


class TestHttpSessionFactory:
    def setup_method(self):
        # Reset cached session before each test
        HttpSessionFactory._default_session = None

    def test_create_session_returns_requests_session(self):
        session = HttpSessionFactory.create_session()
        assert isinstance(session, requests.Session)

    def test_session_has_http_adapter_mounted(self):
        session = HttpSessionFactory.create_session()
        assert "http://" in session.adapters

    def test_session_has_https_adapter_mounted(self):
        session = HttpSessionFactory.create_session()
        assert "https://" in session.adapters

    def test_custom_retry_config_accepted(self):
        config = RetryConfig(total=2, backoff_factor=0.1, status_forcelist=[500])
        session = HttpSessionFactory.create_session(retry_config=config)
        assert isinstance(session, requests.Session)

    def test_default_session_is_cached(self):
        s1 = HttpSessionFactory.get_default_session()
        s2 = HttpSessionFactory.get_default_session()
        assert s1 is s2

    def test_default_session_is_requests_session(self):
        session = HttpSessionFactory.get_default_session()
        assert isinstance(session, requests.Session)

    def test_create_session_returns_new_instance_each_time(self):
        s1 = HttpSessionFactory.create_session()
        s2 = HttpSessionFactory.create_session()
        assert s1 is not s2


class TestGetRetrySession:
    def test_returns_requests_session(self):
        session = get_retry_session()
        assert isinstance(session, requests.Session)
