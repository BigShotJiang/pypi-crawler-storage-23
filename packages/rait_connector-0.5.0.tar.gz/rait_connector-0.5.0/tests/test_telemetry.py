"""Tests for rait_connector.telemetry (TelemetryClient)."""

import pytest
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

from azure.monitor.query import LogsQueryStatus

from rait_connector.telemetry import TelemetryClient
from rait_connector.exceptions import TelemetryError


# ── Helpers ───────────────────────────────────────────────────────────────────


def _make_table(columns, rows):
    """Build a fake LogsQueryResult table object."""
    table = MagicMock()
    table.columns = columns
    table.rows = rows
    return table


def _make_success_response(*tables):
    """Build a successful LogsQueryResult response."""
    resp = MagicMock()
    resp.status = LogsQueryStatus.SUCCESS
    resp.tables = list(tables)
    return resp


def _make_partial_response(*tables, error="partial error"):
    """Build a partial LogsQueryResult response."""
    resp = MagicMock()
    resp.status = LogsQueryStatus.PARTIAL
    resp.partial_data = list(tables)
    resp.partial_error = error
    return resp


def _make_failure_response():
    """Build a failed LogsQueryResult response."""
    resp = MagicMock()
    resp.status = LogsQueryStatus.FAILURE
    return resp


# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def mock_credential():
    return MagicMock()


@pytest.fixture
def client(mock_credential):
    return TelemetryClient(credential=mock_credential, workspace_id="ws-123")


# ── TelemetryClient.fetch ──────────────────────────────────────────────────────


class TestFetch:
    def test_unsupported_table_raises(self, client):
        with pytest.raises(TelemetryError, match="Unsupported table"):
            client.fetch("NonExistentTable")

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_success_returns_rows(self, mock_logs_cls, client):
        table = _make_table(["col1", "col2"], [["a", "b"], ["c", "d"]])
        mock_logs_cls.return_value.query_workspace.return_value = (
            _make_success_response(table)
        )

        rows = client.fetch("AppDependencies")

        assert rows == [{"col1": "a", "col2": "b"}, {"col1": "c", "col2": "d"}]

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_empty_table_returns_empty_list(self, mock_logs_cls, client):
        table = _make_table(["col1"], [])
        mock_logs_cls.return_value.query_workspace.return_value = (
            _make_success_response(table)
        )

        rows = client.fetch("AppExceptions")

        assert rows == []

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_no_tables_in_response_returns_empty_list(self, mock_logs_cls, client):
        resp = MagicMock()
        resp.status = LogsQueryStatus.SUCCESS
        resp.tables = []
        mock_logs_cls.return_value.query_workspace.return_value = resp

        rows = client.fetch("AppDependencies")

        assert rows == []

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_partial_result_returns_rows(self, mock_logs_cls, client):
        table = _make_table(["x"], [["val"]])
        mock_logs_cls.return_value.query_workspace.return_value = (
            _make_partial_response(table)
        )

        rows = client.fetch("AppDependencies")

        assert rows == [{"x": "val"}]

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_failure_status_raises(self, mock_logs_cls, client):
        mock_logs_cls.return_value.query_workspace.return_value = (
            _make_failure_response()
        )

        with pytest.raises(TelemetryError, match="Query failed"):
            client.fetch("AppDependencies")

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_query_exception_wrapped_in_telemetry_error(self, mock_logs_cls, client):
        mock_logs_cls.return_value.query_workspace.side_effect = RuntimeError(
            "network error"
        )

        with pytest.raises(TelemetryError, match="Failed to fetch telemetry"):
            client.fetch("AppDependencies")

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_default_query_uses_limit(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        client.fetch("AppDependencies", limit=42)

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert "AppDependencies | limit 42" in call_kwargs["query"]

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_custom_query_overrides_default(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        client.fetch(
            "AppDependencies", query="AppDependencies | where success == false"
        )

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert call_kwargs["query"] == "AppDependencies | where success == false"

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_timespan_forwarded(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp
        span = timedelta(hours=12)

        client.fetch("AppDependencies", timespan=span)

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert call_kwargs["timespan"] == span

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_workspace_id_forwarded(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        client.fetch("AppDependencies")

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert call_kwargs["workspace_id"] == "ws-123"

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_client_created_lazily(self, mock_logs_cls, client):
        """LogsQueryClient is not created until the first fetch."""
        mock_logs_cls.assert_not_called()

        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp
        client.fetch("AppDependencies")

        mock_logs_cls.assert_called_once()

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_client_reused_across_calls(self, mock_logs_cls, client):
        """LogsQueryClient is instantiated only once for multiple fetches."""
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        client.fetch("AppDependencies")
        client.fetch("AppExceptions")

        mock_logs_cls.assert_called_once()


# ── TelemetryClient._serialize_row ────────────────────────────────────────────


class TestSerializeRow:
    def setup_method(self):
        self.client = TelemetryClient(credential=MagicMock(), workspace_id="ws")

    def test_strings_pass_through(self):
        row = {"key": "value"}
        assert self.client._serialize_row(row) == {"key": "value"}

    def test_int_and_float_pass_through(self):
        row = {"i": 42, "f": 3.14}
        result = self.client._serialize_row(row)
        assert result["i"] == 42
        assert result["f"] == 3.14

    def test_bool_passes_through(self):
        row = {"flag": True}
        assert self.client._serialize_row(row)["flag"] is True

    def test_none_passes_through(self):
        row = {"empty": None}
        assert self.client._serialize_row(row)["empty"] is None

    def test_datetime_serialized_to_isoformat(self):
        dt = datetime(2025, 6, 1, 12, 0, 0)
        row = {"ts": dt}
        result = self.client._serialize_row(row)
        assert result["ts"] == dt.isoformat()

    def test_unknown_type_converted_to_str(self):
        row = {"obj": object()}
        result = self.client._serialize_row(row)
        assert isinstance(result["obj"], str)

    def test_list_passes_through(self):
        row = {"items": [1, 2, 3]}
        result = self.client._serialize_row(row)
        assert result["items"] == [1, 2, 3]

    def test_dict_passes_through(self):
        row = {"nested": {"a": 1}}
        result = self.client._serialize_row(row)
        assert result["nested"] == {"a": 1}


# ── TelemetryClient.fetch_all ─────────────────────────────────────────────────


class TestFetchAll:
    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_defaults_to_all_supported_tables(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        result = client.fetch_all()

        assert set(result.keys()) == set(TelemetryClient.SUPPORTED_TABLES)

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_subset_of_tables(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        result = client.fetch_all(tables=["AppDependencies", "AppExceptions"])

        assert set(result.keys()) == {"AppDependencies", "AppExceptions"}

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_rows_aggregated_per_table(self, mock_logs_cls, client):
        t1 = _make_table(["col"], [["row1"]])
        t2 = _make_table(["col"], [["row2"]])

        call_count = [0]

        def side_effect(**kwargs):
            resp = MagicMock()
            resp.status = LogsQueryStatus.SUCCESS
            resp.tables = [t1 if call_count[0] == 0 else t2]
            call_count[0] += 1
            return resp

        mock_logs_cls.return_value.query_workspace.side_effect = side_effect

        result = client.fetch_all(tables=["AppDependencies", "AppExceptions"])

        assert result["AppDependencies"] == [{"col": "row1"}]
        assert result["AppExceptions"] == [{"col": "row2"}]

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_failed_table_returns_empty_list(self, mock_logs_cls, client):
        mock_logs_cls.return_value.query_workspace.side_effect = RuntimeError("down")

        result = client.fetch_all(tables=["AppDependencies"])

        assert result["AppDependencies"] == []

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_custom_query_per_table(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        custom = {"AppDependencies": "AppDependencies | where success == false"}
        client.fetch_all(tables=["AppDependencies"], custom_queries=custom)

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert call_kwargs["query"] == "AppDependencies | where success == false"

    @patch("rait_connector.telemetry.LogsQueryClient")
    def test_limit_forwarded(self, mock_logs_cls, client):
        resp = _make_success_response(_make_table([], []))
        mock_logs_cls.return_value.query_workspace.return_value = resp

        client.fetch_all(tables=["AppDependencies"], limit=500)

        call_kwargs = mock_logs_cls.return_value.query_workspace.call_args[1]
        assert "limit 500" in call_kwargs["query"]
