"""Tests for rait_connector.evaluators (base, registry, orchestrator)."""

import pytest
from unittest.mock import MagicMock, patch

from rait_connector.constants import Metric
from rait_connector.evaluators.base import BaseEvaluator
from rait_connector.evaluators.registry import (
    EVALUATOR_CONFIG,
    can_evaluate_metric,
    create_evaluator,
)
from rait_connector.evaluators.orchestrator import EvaluatorOrchestrator
from rait_connector.exceptions import EvaluationError


# ── Concrete test implementations of BaseEvaluator ───────────────────────────


class SimpleEvaluator(BaseEvaluator):
    metric_name = Metric.COHERENCE
    requires_context = False
    requires_ground_truth = False

    def evaluate(self, query, response, context=None, ground_truth=None):
        return {"coherence": 5}


class ContextRequiredEvaluator(BaseEvaluator):
    metric_name = Metric.GROUNDEDNESS
    requires_context = True
    requires_ground_truth = False

    def evaluate(self, query, response, context=None, ground_truth=None):
        return {}


class GroundTruthRequiredEvaluator(BaseEvaluator):
    metric_name = Metric.F1_SCORE
    requires_context = False
    requires_ground_truth = True

    def evaluate(self, query, response, context=None, ground_truth=None):
        return {}


class BothRequiredEvaluator(BaseEvaluator):
    metric_name = Metric.QA
    requires_context = True
    requires_ground_truth = True

    def evaluate(self, query, response, context=None, ground_truth=None):
        return {}


# ── BaseEvaluator.can_evaluate ────────────────────────────────────────────────


class TestBaseEvaluatorCanEvaluate:
    def test_no_requirements_always_true(self):
        ev = SimpleEvaluator()
        assert ev.can_evaluate(has_context=False, has_ground_truth=False) is True
        assert ev.can_evaluate(has_context=True, has_ground_truth=True) is True

    def test_context_required_missing_returns_false(self):
        ev = ContextRequiredEvaluator()
        assert ev.can_evaluate(has_context=False, has_ground_truth=False) is False

    def test_context_required_present_returns_true(self):
        ev = ContextRequiredEvaluator()
        assert ev.can_evaluate(has_context=True, has_ground_truth=False) is True

    def test_ground_truth_required_missing_returns_false(self):
        ev = GroundTruthRequiredEvaluator()
        assert ev.can_evaluate(has_context=False, has_ground_truth=False) is False

    def test_ground_truth_required_present_returns_true(self):
        ev = GroundTruthRequiredEvaluator()
        assert ev.can_evaluate(has_context=False, has_ground_truth=True) is True

    def test_both_required_missing_both_returns_false(self):
        ev = BothRequiredEvaluator()
        assert ev.can_evaluate(has_context=False, has_ground_truth=False) is False

    def test_both_required_missing_one_returns_false(self):
        ev = BothRequiredEvaluator()
        assert ev.can_evaluate(has_context=True, has_ground_truth=False) is False
        assert ev.can_evaluate(has_context=False, has_ground_truth=True) is False

    def test_both_required_both_present_returns_true(self):
        ev = BothRequiredEvaluator()
        assert ev.can_evaluate(has_context=True, has_ground_truth=True) is True


# ── EVALUATOR_CONFIG completeness ─────────────────────────────────────────────


class TestEvaluatorConfig:
    def test_all_metrics_have_config(self):
        for metric in Metric:
            assert metric in EVALUATOR_CONFIG, f"Missing config for {metric}"

    def test_each_config_has_required_keys(self):
        required = {
            "class",
            "needs_project",
            "needs_model_config",
            "requires_context",
            "requires_ground_truth",
        }
        for metric, config in EVALUATOR_CONFIG.items():
            missing = required - config.keys()
            assert not missing, f"{metric} config missing keys: {missing}"

    def test_class_is_callable(self):
        for metric, config in EVALUATOR_CONFIG.items():
            assert callable(config["class"]), f"{metric} class is not callable"


# ── can_evaluate_metric ───────────────────────────────────────────────────────


class TestCanEvaluateMetric:
    def test_unknown_metric_returns_false(self):
        assert can_evaluate_metric("NonExistentMetric", True, True) is False

    def test_coherence_no_requirements(self):
        assert can_evaluate_metric("Coherence", False, False) is True

    def test_context_required_groundedness(self):
        assert (
            can_evaluate_metric(
                "Groundedness", has_context=False, has_ground_truth=False
            )
            is False
        )
        assert (
            can_evaluate_metric(
                "Groundedness", has_context=True, has_ground_truth=False
            )
            is True
        )

    def test_ground_truth_required_f1(self):
        assert (
            can_evaluate_metric("F1 Score", has_context=False, has_ground_truth=False)
            is False
        )
        assert (
            can_evaluate_metric("F1 Score", has_context=False, has_ground_truth=True)
            is True
        )

    def test_both_required_qa(self):
        assert (
            can_evaluate_metric("QA", has_context=False, has_ground_truth=True) is False
        )
        assert (
            can_evaluate_metric("QA", has_context=True, has_ground_truth=False) is False
        )
        assert (
            can_evaluate_metric("QA", has_context=True, has_ground_truth=True) is True
        )

    def test_case_insensitive_lower(self):
        assert can_evaluate_metric("coherence", False, False) is True

    def test_case_insensitive_upper(self):
        assert can_evaluate_metric("COHERENCE", False, False) is True

    def test_empty_string_returns_false(self):
        assert can_evaluate_metric("", False, False) is False


# ── create_evaluator ──────────────────────────────────────────────────────────


class TestCreateEvaluator:
    def test_unknown_metric_raises(self):
        with pytest.raises(EvaluationError, match="Unknown metric"):
            create_evaluator("NonExistent")

    def test_empty_metric_name_raises(self):
        with pytest.raises(EvaluationError):
            create_evaluator("")

    def test_creates_evaluator_for_f1(self):
        mock_class = MagicMock()
        with patch.dict(
            EVALUATOR_CONFIG,
            {
                Metric.F1_SCORE: {
                    **EVALUATOR_CONFIG[Metric.F1_SCORE],
                    "class": mock_class,
                }
            },
        ):
            result = create_evaluator("F1 Score")
        mock_class.assert_called_once()
        assert result is mock_class.return_value

    def test_passes_model_config_when_needed(self):
        mock_class = MagicMock()
        model_cfg = MagicMock()
        with patch.dict(
            EVALUATOR_CONFIG,
            {
                Metric.COHERENCE: {
                    **EVALUATOR_CONFIG[Metric.COHERENCE],
                    "class": mock_class,
                }
            },
        ):
            create_evaluator("Coherence", model_config=model_cfg)
        call_kwargs = mock_class.call_args[1]
        assert call_kwargs.get("model_config") is model_cfg

    def test_passes_azure_project_when_needed(self):
        mock_class = MagicMock()
        project = {
            "subscription_id": "sub",
            "resource_group_name": "rg",
            "project_name": "p",
        }
        with patch.dict(
            EVALUATOR_CONFIG,
            {
                Metric.HATE_AND_UNFAIRNESS: {
                    **EVALUATOR_CONFIG[Metric.HATE_AND_UNFAIRNESS],
                    "class": mock_class,
                }
            },
        ):
            create_evaluator("Hate and Unfairness", azure_ai_project=project)
        call_kwargs = mock_class.call_args[1]
        assert call_kwargs.get("azure_ai_project") is project

    def test_rouge_gets_rouge_type(self):
        from azure.ai.evaluation import RougeType

        mock_class = MagicMock()
        with patch.dict(
            EVALUATOR_CONFIG,
            {Metric.ROUGE: {**EVALUATOR_CONFIG[Metric.ROUGE], "class": mock_class}},
        ):
            create_evaluator("ROUGE")
        call_kwargs = mock_class.call_args[1]
        assert call_kwargs.get("rouge_type") == RougeType.ROUGE_L

    def test_evaluator_init_failure_raises_evaluation_error(self):
        failing_class = MagicMock(side_effect=RuntimeError("Azure init failed"))
        with patch.dict(
            EVALUATOR_CONFIG,
            {
                Metric.COHERENCE: {
                    **EVALUATOR_CONFIG[Metric.COHERENCE],
                    "class": failing_class,
                }
            },
        ):
            with pytest.raises(EvaluationError, match="Failed to create evaluator"):
                create_evaluator("Coherence", model_config=MagicMock())


# ── EvaluatorOrchestrator ─────────────────────────────────────────────────────


def _make_dims(*metrics):
    """Build ethical_dimensions from (metric_name, metric_id) pairs."""
    return [
        {
            "dimension_name": "test",
            "dimension_metrics": [
                {"metric_name": name, "metric_id": mid} for name, mid in metrics
            ],
        }
    ]


PROMPT_DATA = {
    "query": "What is 2+2?",
    "response": "4",
    "context": "",
    "ground_truth": "",
}


class TestEvaluatorOrchestrator:
    def test_update_metric_result_by_id(self):
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"), ("Fluency", "m2"))
        orch._update_metric_result(dims, "m1", {"score": 4.5})
        assert dims[0]["dimension_metrics"][0]["metric_metadata"] == {"score": 4.5}
        assert "metric_metadata" not in dims[0]["dimension_metrics"][1]

    def test_update_metric_result_nonexistent_id_no_op(self):
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        orch._update_metric_result(dims, "nonexistent", {"score": 1})
        assert "metric_metadata" not in dims[0]["dimension_metrics"][0]

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=True
    )
    @patch("rait_connector.evaluators.orchestrator.create_evaluator")
    def test_sequential_updates_result(self, mock_create, mock_can):
        mock_create.return_value = MagicMock(return_value={"score": 3})
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        result = orch.evaluate_metrics(PROMPT_DATA, dims, parallel=False)
        assert result[0]["dimension_metrics"][0]["metric_metadata"] == {"score": 3}

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=True
    )
    @patch("rait_connector.evaluators.orchestrator.create_evaluator")
    def test_parallel_updates_all_results(self, mock_create, mock_can):
        mock_create.return_value = MagicMock(return_value={"score": 3})
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"), ("Fluency", "m2"))
        result = orch.evaluate_metrics(PROMPT_DATA, dims, parallel=True, max_workers=2)
        for metric in result[0]["dimension_metrics"]:
            assert metric.get("metric_metadata") == {"score": 3}

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=False
    )
    def test_skips_metric_when_cannot_evaluate(self, mock_can):
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        result = orch.evaluate_metrics(PROMPT_DATA, dims, parallel=False)
        assert "metric_metadata" not in result[0]["dimension_metrics"][0]

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=True
    )
    @patch("rait_connector.evaluators.orchestrator.create_evaluator")
    def test_fail_fast_raises_on_evaluator_error(self, mock_create, mock_can):
        mock_create.side_effect = RuntimeError("evaluator broke")
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        with pytest.raises(EvaluationError, match="evaluator broke"):
            orch.evaluate_metrics(PROMPT_DATA, dims, parallel=False, fail_fast=True)

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=True
    )
    @patch("rait_connector.evaluators.orchestrator.create_evaluator")
    def test_no_fail_fast_continues_after_error(self, mock_create, mock_can):
        mock_create.side_effect = RuntimeError("evaluator broke")
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        result = orch.evaluate_metrics(
            PROMPT_DATA, dims, parallel=False, fail_fast=False
        )
        assert result is not None  # did not raise

    def test_input_dimensions_not_mutated(self):
        """evaluate_metrics deep-copies input; original should be unchanged."""
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        original = _make_dims(("Coherence", "m1"))

        with patch(
            "rait_connector.evaluators.orchestrator.can_evaluate_metric",
            return_value=False,
        ):
            orch.evaluate_metrics(PROMPT_DATA, dims, parallel=False)

        assert dims == original

    @patch(
        "rait_connector.evaluators.orchestrator.can_evaluate_metric", return_value=True
    )
    @patch("rait_connector.evaluators.orchestrator.create_evaluator")
    def test_single_metric_does_not_use_threadpool(self, mock_create, mock_can):
        """When only 1 metric, parallel mode falls back to sequential."""
        mock_create.return_value = MagicMock(return_value={"score": 1})
        orch = EvaluatorOrchestrator()
        dims = _make_dims(("Coherence", "m1"))
        result = orch.evaluate_metrics(PROMPT_DATA, dims, parallel=True)
        assert result[0]["dimension_metrics"][0].get("metric_metadata") == {"score": 1}
