"""Tests for rait_connector.models."""

import pytest
from pydantic import ValidationError

from rait_connector.models import EvaluationInput

VALID = {
    "prompt_id": "p1",
    "prompt_url": "https://example.com/p1",
    "timestamp": "2025-01-01T00:00:00Z",
    "model_name": "gpt-4",
    "model_version": "1.0",
    "query": "What is AI?",
    "response": "AI is artificial intelligence.",
    "environment": "production",
    "purpose": "monitoring",
}


class TestEvaluationInput:
    def test_valid_input_creates_model(self):
        inp = EvaluationInput(**VALID)
        assert inp.prompt_id == "p1"
        assert inp.model_name == "gpt-4"

    def test_optional_fields_default_to_empty(self):
        inp = EvaluationInput(**VALID)
        assert inp.ground_truth == ""
        assert inp.context == ""
        assert inp.custom_fields == {}

    def test_custom_fields_stored(self):
        inp = EvaluationInput(**VALID, custom_fields={"env": "staging", "version": 2})
        assert inp.custom_fields["env"] == "staging"
        assert inp.custom_fields["version"] == 2

    def test_timestamp_with_z_suffix(self):
        inp = EvaluationInput(**VALID)
        assert inp.timestamp == "2025-01-01T00:00:00Z"

    def test_timestamp_with_utc_offset(self):
        data = {**VALID, "timestamp": "2025-06-15T08:30:00+05:30"}
        inp = EvaluationInput(**data)
        assert inp.timestamp == "2025-06-15T08:30:00+05:30"

    def test_timestamp_without_timezone(self):
        data = {**VALID, "timestamp": "2025-06-15T10:00:00"}
        inp = EvaluationInput(**data)
        assert inp.timestamp == "2025-06-15T10:00:00"

    def test_timestamp_date_only_accepted(self):
        # Python 3.11+ datetime.fromisoformat accepts date-only strings
        data = {**VALID, "timestamp": "2025-01-01"}
        inp = EvaluationInput(**data)
        assert inp.timestamp == "2025-01-01"

    def test_timestamp_plaintext_raises(self):
        data = {**VALID, "timestamp": "not-a-timestamp"}
        with pytest.raises(ValidationError):
            EvaluationInput(**data)

    def test_missing_required_query_raises(self):
        data = {k: v for k, v in VALID.items() if k != "query"}
        with pytest.raises(ValidationError):
            EvaluationInput(**data)

    def test_missing_required_response_raises(self):
        data = {k: v for k, v in VALID.items() if k != "response"}
        with pytest.raises(ValidationError):
            EvaluationInput(**data)

    def test_missing_environment_raises(self):
        data = {k: v for k, v in VALID.items() if k != "environment"}
        with pytest.raises(ValidationError):
            EvaluationInput(**data)

    def test_ground_truth_explicit(self):
        inp = EvaluationInput(**VALID, ground_truth="Expected answer")
        assert inp.ground_truth == "Expected answer"

    def test_context_explicit(self):
        inp = EvaluationInput(**VALID, context="Some background context")
        assert inp.context == "Some background context"
