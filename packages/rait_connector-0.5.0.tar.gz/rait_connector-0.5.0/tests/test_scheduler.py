"""Unit tests for rait_connector.scheduler."""

import threading
import time
from datetime import timedelta
from unittest.mock import MagicMock

import pytest
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from rait_connector.exceptions import SchedulerError
from rait_connector.scheduler import Scheduler, _parse_trigger


# ── Fixtures ──────────────────────────────────────────────────────────────────


@pytest.fixture
def mock_client():
    """A mock RAITClient."""
    return MagicMock()


@pytest.fixture
def scheduler(mock_client):
    """A Scheduler backed by a mock client; stopped after each test."""
    s = Scheduler(mock_client)
    yield s
    s.stop()


# ── _parse_trigger ────────────────────────────────────────────────────────────


class TestParseTrigger:
    def test_hourly_alias(self):
        t = _parse_trigger("hourly")
        assert isinstance(t, IntervalTrigger)

    def test_daily_alias(self):
        t = _parse_trigger("daily")
        assert isinstance(t, IntervalTrigger)

    def test_weekly_alias(self):
        t = _parse_trigger("weekly")
        assert isinstance(t, IntervalTrigger)

    def test_alias_case_insensitive(self):
        assert isinstance(_parse_trigger("DAILY"), IntervalTrigger)
        assert isinstance(_parse_trigger("Daily"), IntervalTrigger)

    def test_timedelta(self):
        t = _parse_trigger(timedelta(hours=6))
        assert isinstance(t, IntervalTrigger)

    def test_int_seconds(self):
        t = _parse_trigger(3600)
        assert isinstance(t, IntervalTrigger)

    def test_float_seconds(self):
        t = _parse_trigger(3600.0)
        assert isinstance(t, IntervalTrigger)

    def test_cron_expression(self):
        t = _parse_trigger("0 9 * * MON-FRI")
        assert isinstance(t, CronTrigger)

    def test_cron_every_minute(self):
        t = _parse_trigger("* * * * *")
        assert isinstance(t, CronTrigger)

    def test_invalid_string_raises(self):
        with pytest.raises(SchedulerError, match="Cannot parse interval"):
            _parse_trigger("not-a-valid-interval")

    def test_zero_seconds_raises(self):
        with pytest.raises(SchedulerError):
            _parse_trigger(0)

    def test_negative_seconds_raises(self):
        with pytest.raises(SchedulerError):
            _parse_trigger(-60)

    def test_negative_timedelta_raises(self):
        with pytest.raises(SchedulerError):
            _parse_trigger(timedelta(seconds=-1))

    def test_wrong_type_raises(self):
        with pytest.raises(SchedulerError):
            _parse_trigger([1, 2, 3])  # type: ignore[arg-type]


# ── add_job / decorator ───────────────────────────────────────────────────────


class TestAddJob:
    def test_job_is_registered(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="my_job")
        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert "my_job" in ids

    def test_defaults_to_function_name(self, scheduler):
        def my_named_func():
            pass

        scheduler.add_job(my_named_func, interval=60)
        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert "my_named_func" in ids

    def test_replace_existing(self, scheduler):
        # APScheduler only deduplicates via the job store once running
        scheduler.start()
        scheduler.add_job(lambda: None, interval=60, name="dup")
        scheduler.add_job(lambda: None, interval=120, name="dup")
        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert ids.count("dup") == 1

    def test_invalid_interval_raises(self, scheduler):
        with pytest.raises(SchedulerError):
            scheduler.add_job(lambda: None, interval="bad_interval")

    def test_decorator_registers_job(self, scheduler):
        @scheduler.job(interval=60, name="decorated")
        def my_job():
            pass

        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert "decorated" in ids

    def test_decorator_returns_original_function(self, scheduler):
        @scheduler.job(interval=60)
        def my_job():
            return 42

        assert my_job() == 42


# ── Built-in jobs ─────────────────────────────────────────────────────────────


class TestTelemetryJob:
    def test_registers_rait_telemetry_job(self, scheduler):
        scheduler.add_telemetry_job(
            model_name="gpt-4",
            model_version="1.0",
            model_environment="production",
            model_purpose="monitoring",
            interval="daily",
        )
        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert "rait_telemetry" in ids

    def test_calls_fetch_and_post_telemetry(self, scheduler, mock_client):
        telemetry_data = {"AppDependencies": [{"row": 1}]}
        mock_client.fetch_telemetry.return_value = telemetry_data
        done = threading.Event()

        def on_result(result):
            done.set()

        scheduler.add_telemetry_job(
            model_name="gpt-4",
            model_version="1.0",
            model_environment="production",
            model_purpose="monitoring",
            interval=1,
            on_result=on_result,
            run_immediately=True,
        )
        scheduler.start()
        assert done.wait(timeout=5), "Telemetry job did not fire"
        mock_client.fetch_telemetry.assert_called_once()
        mock_client.post_telemetry.assert_called_once_with(
            model_name="gpt-4",
            model_version="1.0",
            model_environment="production",
            model_purpose="monitoring",
            telemetry_data=telemetry_data,
        )

    def test_on_result_receives_result(self, scheduler, mock_client):
        expected = {"AppExceptions": [{"row": 1}, {"row": 2}]}
        mock_client.fetch_telemetry.return_value = expected
        received = []
        done = threading.Event()

        def on_result(result):
            received.append(result)
            done.set()

        scheduler.add_telemetry_job(
            model_name="gpt-4",
            model_version="1.0",
            model_environment="production",
            model_purpose="monitoring",
            interval=1,
            on_result=on_result,
            run_immediately=True,
        )
        scheduler.start()
        done.wait(timeout=5)
        assert received[0] == expected

    def test_fetch_kwargs_forwarded(self, scheduler, mock_client):
        mock_client.fetch_telemetry.return_value = {}
        done = threading.Event()
        mock_client.fetch_telemetry.side_effect = lambda **kw: done.set() or {}

        scheduler.add_telemetry_job(
            model_name="gpt-4",
            model_version="1.0",
            model_environment="production",
            model_purpose="monitoring",
            interval=1,
            run_immediately=True,
            timespan=timedelta(days=7),
            limit=500,
        )
        scheduler.start()
        done.wait(timeout=5)
        mock_client.fetch_telemetry.assert_called_with(
            timespan=timedelta(days=7), limit=500
        )


class TestCalibrationJob:
    def test_registers_calibration_job(self, scheduler):
        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "response",
            interval="weekly",
        )
        ids = [j.id for j in scheduler._aps.get_jobs()]
        assert any("rait_calibration" in jid for jid in ids)

    def test_flow1_calls_get_prompts_response(self, scheduler, mock_client):
        """Flow 1: get_prompts_response → invoke_model → update_prompts_response."""
        mock_client.get_prompts_response.return_value = []
        mock_client.get_model_calibration_prompts.return_value = []
        done = threading.Event()
        mock_client.get_prompts_response.side_effect = lambda **kw: done.set() or []

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "response",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        assert done.wait(timeout=5), "Calibration job did not fire"
        mock_client.get_prompts_response.assert_called_once()

    def test_flow1_skips_update_when_no_prompts(self, scheduler, mock_client):
        mock_client.get_prompts_response.return_value = []
        mock_client.get_model_calibration_prompts.return_value = []
        done = threading.Event()
        mock_client.get_model_calibration_prompts.side_effect = (
            lambda **kw: done.set() or []
        )

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "response",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        done.wait(timeout=5)
        mock_client.update_prompts_response.assert_not_called()

    def test_flow1_calls_update_prompts_response(self, scheduler, mock_client):
        prompts = [{"prompt_response_id": "pr-1", "prompt_text": "hello"}]
        mock_client.get_prompts_response.return_value = prompts
        mock_client.get_model_calibration_prompts.return_value = []
        done = threading.Event()
        mock_client.update_prompts_response.side_effect = lambda **kw: done.set()

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "model answer",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        assert done.wait(timeout=5), "update_prompts_response was not called"
        mock_client.update_prompts_response.assert_called_once()
        call_kwargs = mock_client.update_prompts_response.call_args.kwargs
        assert call_kwargs["responses"][0]["prompt_response_id"] == "pr-1"
        assert call_kwargs["responses"][0]["model_response"] == "model answer"

    def test_flow2_calls_get_model_calibration_prompts(self, scheduler, mock_client):
        """Flow 2: get_model_calibration_prompts → invoke_model → post_calibration_responses."""
        mock_client.get_prompts_response.return_value = []
        mock_client.get_model_calibration_prompts.return_value = []
        done = threading.Event()
        mock_client.get_model_calibration_prompts.side_effect = (
            lambda **kw: done.set() or []
        )

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "response",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        assert done.wait(timeout=5), "Calibration job did not fire"
        mock_client.get_model_calibration_prompts.assert_called_once()

    def test_flow2_calls_post_calibration_responses(self, scheduler, mock_client):
        cal_prompts = [{"prompt_id": "cp-1", "prompt_text": "calibrate me"}]
        mock_client.get_prompts_response.return_value = []
        mock_client.get_model_calibration_prompts.return_value = cal_prompts
        done = threading.Event()
        mock_client.post_calibration_responses.side_effect = lambda **kw: done.set()

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "cal response",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        assert done.wait(timeout=5), "post_calibration_responses was not called"
        mock_client.post_calibration_responses.assert_called_once()
        call_kwargs = mock_client.post_calibration_responses.call_args.kwargs
        assert call_kwargs["model_purpose"] == "monitoring"
        assert call_kwargs["calibration_responses"][0]["prompt_id"] == "cp-1"
        assert (
            call_kwargs["calibration_responses"][0]["response_text"] == "cal response"
        )

    def test_flow2_skips_post_when_no_cal_prompts(self, scheduler, mock_client):
        mock_client.get_prompts_response.return_value = []
        mock_client.get_model_calibration_prompts.return_value = []
        done = threading.Event()
        mock_client.get_model_calibration_prompts.side_effect = (
            lambda **kw: done.set() or []
        )

        scheduler.add_calibration_job(
            model_name="gpt-4",
            model_version="1.0",
            environment="prod",
            model_purpose="monitoring",
            invoke_model=lambda p: "response",
            interval=1,
            run_immediately=True,
        )
        scheduler.start()
        done.wait(timeout=5)
        mock_client.post_calibration_responses.assert_not_called()


# ── Lifecycle ─────────────────────────────────────────────────────────────────


class TestLifecycle:
    def test_not_running_before_start(self, scheduler):
        assert not scheduler.is_running()

    def test_running_after_start(self, scheduler):
        scheduler.start()
        assert scheduler.is_running()

    def test_not_running_after_stop(self, scheduler):
        scheduler.start()
        scheduler.stop()
        assert not scheduler.is_running()

    def test_start_idempotent(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="j")
        scheduler.start()
        scheduler.start()  # should not raise
        assert scheduler.is_running()

    def test_stop_when_not_running_is_safe(self, scheduler):
        scheduler.stop()  # should not raise


# ── Status ────────────────────────────────────────────────────────────────────


class TestStatus:
    def test_empty_when_no_jobs(self, scheduler):
        assert scheduler.status() == []

    def test_returns_one_entry_per_job(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="j1")
        scheduler.add_job(lambda: None, interval=120, name="j2")
        assert len(scheduler.status()) == 2

    def test_entry_has_required_keys(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="myjob")
        entry = scheduler.status()[0]
        assert "id" in entry
        assert "trigger" in entry
        assert "next_run" in entry
        assert "is_executing" in entry

    def test_is_executing_false_when_not_running(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="j")
        assert scheduler.status()[0]["is_executing"] is False

    def test_is_executing_true_while_running(self, scheduler):
        started = threading.Event()
        finish = threading.Event()

        def slow_job():
            started.set()
            finish.wait()

        scheduler.add_job(slow_job, interval=60, name="slow", run_immediately=True)
        scheduler.start()
        started.wait(timeout=5)
        statuses = {s["id"]: s for s in scheduler.status()}
        assert statuses["slow"]["is_executing"] is True
        finish.set()

    def test_next_run_is_none_without_run_immediately_before_start(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="j")
        # Before start, job is pending — it appears in status() but next_run
        # is None because APScheduler hasn't computed it from the trigger yet.
        entries = scheduler.status()
        assert len(entries) == 1
        assert entries[0]["next_run"] is None

    def test_next_run_set_after_start(self, scheduler):
        scheduler.add_job(lambda: None, interval=60, name="j")
        scheduler.start()
        time.sleep(0.2)  # let APScheduler compute next_run_time from the trigger
        entry = scheduler.status()[0]
        assert entry["next_run"] is not None


# ── running_jobs ──────────────────────────────────────────────────────────────


class TestRunningJobs:
    def test_empty_when_idle(self, scheduler):
        assert scheduler.running_jobs() == []

    def test_shows_job_while_executing(self, scheduler):
        started = threading.Event()
        finish = threading.Event()

        def slow_job():
            started.set()
            finish.wait()

        scheduler.add_job(slow_job, interval=60, name="slow", run_immediately=True)
        scheduler.start()
        started.wait(timeout=5)
        assert "slow" in scheduler.running_jobs()
        finish.set()

    def test_job_removed_after_completion(self, scheduler):
        original = threading.Event()

        def quick_job():
            original.set()

        scheduler.add_job(quick_job, interval=60, name="quick", run_immediately=True)
        scheduler.start()
        original.wait(timeout=5)
        time.sleep(0.2)  # let the finally block in the wrapper run
        assert "quick" not in scheduler.running_jobs()


# ── history ───────────────────────────────────────────────────────────────────


class TestHistory:
    def test_empty_before_any_runs(self, scheduler):
        assert scheduler.history() == []

    def test_records_successful_run(self, scheduler):
        ran = threading.Event()

        def my_job():
            ran.set()

        scheduler.add_job(my_job, interval=60, name="j", run_immediately=True)
        scheduler.start()
        ran.wait(timeout=5)
        time.sleep(0.2)  # let the wrapper's finally block append to history

        records = scheduler.history()
        assert len(records) >= 1
        record = records[0]
        assert record["job_id"] == "j"
        assert record["success"] is True
        assert record["error"] is None
        assert record["started_at"] is not None
        assert record["finished_at"] is not None

    def test_records_failed_run(self, scheduler):
        done = threading.Event()

        def failing_job():
            done.set()
            raise ValueError("boom")

        scheduler.add_job(failing_job, interval=60, name="bad", run_immediately=True)
        scheduler.start()
        done.wait(timeout=5)
        time.sleep(0.2)  # let the event handler record the result

        records = scheduler.history(job_id="bad")
        assert len(records) >= 1
        assert records[0]["success"] is False
        assert "boom" in records[0]["error"]

    def test_filter_by_job_id(self, scheduler):
        done_a = threading.Event()
        done_b = threading.Event()

        scheduler.add_job(
            lambda: done_a.set(), interval=60, name="a", run_immediately=True
        )
        scheduler.add_job(
            lambda: done_b.set(), interval=60, name="b", run_immediately=True
        )
        scheduler.start()
        done_a.wait(timeout=5)
        done_b.wait(timeout=5)
        time.sleep(0.2)

        records_a = scheduler.history(job_id="a")
        records_b = scheduler.history(job_id="b")
        assert all(r["job_id"] == "a" for r in records_a)
        assert all(r["job_id"] == "b" for r in records_b)

    def test_limit_parameter(self, scheduler):
        done = threading.Event()
        call_count = 0

        def counting_job():
            nonlocal call_count
            call_count += 1
            if call_count >= 3:
                done.set()

        scheduler.add_job(counting_job, interval=1, name="c", run_immediately=True)
        scheduler.start()
        done.wait(timeout=10)
        time.sleep(0.2)

        records = scheduler.history(limit=2)
        assert len(records) <= 2

    def test_newest_first_order(self, scheduler):
        done = threading.Event()
        call_count = 0

        def counting_job():
            nonlocal call_count
            call_count += 1
            if call_count >= 2:
                done.set()

        scheduler.add_job(counting_job, interval=1, name="d", run_immediately=True)
        scheduler.start()
        done.wait(timeout=10)
        time.sleep(0.2)

        records = scheduler.history(job_id="d")
        if len(records) >= 2:
            assert records[0]["finished_at"] >= records[1]["finished_at"]

    def test_error_in_job_does_not_crash_scheduler(self, scheduler):
        """A job that raises should be recorded in history but not stop the scheduler."""
        done = threading.Event()

        def bad_job():
            done.set()
            raise RuntimeError("intentional error")

        scheduler.add_job(bad_job, interval=60, name="bad2", run_immediately=True)
        scheduler.start()
        done.wait(timeout=5)
        time.sleep(0.2)

        assert scheduler.is_running()
        records = scheduler.history(job_id="bad2")
        assert records[0]["success"] is False

    def test_max_history_respected(self, mock_client):
        s = Scheduler(mock_client, max_history=3)
        done = threading.Event()
        call_count = 0

        def job():
            nonlocal call_count
            call_count += 1
            if call_count >= 5:
                done.set()

        s.add_job(job, interval=1, name="e", run_immediately=True)
        s.start()
        done.wait(timeout=15)
        time.sleep(0.2)
        s.stop()

        assert len(s.history()) <= 3
