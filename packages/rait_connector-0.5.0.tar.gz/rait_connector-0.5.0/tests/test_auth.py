"""Tests for rait_connector.auth."""

import pytest
import requests
from unittest.mock import MagicMock

from rait_connector.auth import AuthenticationService
from rait_connector.exceptions import AuthenticationError


def _make_session(token_response=None):
    """Return a mock requests.Session whose POST returns token_response."""
    if token_response is None:
        token_response = {"access_token": "tok123", "expires_in": 300}

    mock_response = MagicMock()
    mock_response.json.return_value = token_response
    mock_response.raise_for_status = MagicMock()

    mock_session = MagicMock()
    mock_session.post.return_value = mock_response
    return mock_session


def _make_service(clock=None, session=None, token_response=None):
    """Build a fully-configured AuthenticationService with mocked HTTP."""
    if clock is None:

        def clock():
            return 1000.0

    if session is None:
        session = _make_session(token_response=token_response)
    return AuthenticationService(
        api_url="https://api.example.com",
        client_id="client-id",
        client_secret="client-secret",
        session_factory=lambda: session,
        clock=clock,
    ), session


class TestAuthServiceInit:
    def test_missing_api_url_raises(self):
        with pytest.raises(AuthenticationError, match="API URL"):
            AuthenticationService(api_url=None, client_id="id", client_secret="sec")

    def test_missing_client_id_raises(self):
        with pytest.raises(AuthenticationError, match="client ID"):
            AuthenticationService(
                api_url="https://api.example.com", client_id=None, client_secret="sec"
            )

    def test_missing_client_secret_raises(self):
        with pytest.raises(AuthenticationError, match="client secret"):
            AuthenticationService(
                api_url="https://api.example.com", client_id="id", client_secret=None
            )


class TestGetToken:
    def test_returns_token(self):
        service, _ = _make_service()
        assert service.get_token() == "tok123"

    def test_posts_to_token_endpoint(self):
        service, mock_session = _make_service()
        service.get_token()
        url = mock_session.post.call_args[0][0]
        assert "token" in url

    def test_posts_credentials_in_body(self):
        service, mock_session = _make_service()
        service.get_token()
        body = mock_session.post.call_args[1]["json"]
        assert body["client_id"] == "client-id"
        assert body["client_secret"] == "client-secret"

    def test_token_is_cached_on_second_call(self):
        service, mock_session = _make_service()
        service.get_token()
        service.get_token()
        mock_session.post.assert_called_once()

    def test_expired_token_is_refreshed(self):
        tick = [1000.0]
        service, mock_session = _make_service(clock=lambda: tick[0])
        service.get_token()
        assert mock_session.post.call_count == 1

        # expires_in=300, skew=30 → refresh when clock >= 1270
        tick[0] = 1280.0
        service.get_token()
        assert mock_session.post.call_count == 2

    def test_token_not_refreshed_before_expiry(self):
        tick = [1000.0]
        service, mock_session = _make_service(clock=lambda: tick[0])
        service.get_token()

        tick[0] = 1200.0  # still within valid window (expiry at 1270)
        service.get_token()
        mock_session.post.assert_called_once()

    def test_missing_access_token_in_response_raises(self):
        session = _make_session(token_response={"expires_in": 300})  # no access_token
        service, _ = _make_service(session=session)
        with pytest.raises(AuthenticationError, match="access_token"):
            service.get_token()

    def test_no_expires_in_defaults_to_300(self):
        tick = [1000.0]
        session = _make_session(token_response={"access_token": "tok"})
        service, _ = _make_service(clock=lambda: tick[0], session=session)
        service.get_token()
        # Default 300s: expires at 1300, refresh at 1270
        tick[0] = 1280.0
        assert service._needs_refresh()
        tick[0] = 1200.0
        assert not service._needs_refresh()

    def test_http_error_raises_auth_error(self):
        mock_session = MagicMock()
        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_session.post.side_effect = requests.HTTPError(response=mock_resp)
        service, _ = _make_service(session=mock_session)
        with pytest.raises(AuthenticationError, match="HTTP error"):
            service.get_token()

    def test_network_error_raises_auth_error(self):
        mock_session = MagicMock()
        mock_session.post.side_effect = requests.RequestException(
            "connection timed out"
        )
        service, _ = _make_service(session=mock_session)
        with pytest.raises(AuthenticationError, match="Network error"):
            service.get_token()

    def test_invalid_json_raises_auth_error(self):
        mock_session = MagicMock()
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_response.json.side_effect = ValueError("bad json")
        mock_session.post.return_value = mock_response
        service, _ = _make_service(session=mock_session)
        with pytest.raises(AuthenticationError, match="Invalid JSON"):
            service.get_token()


class TestGetAuthHeaders:
    def test_returns_bearer_header(self):
        service, _ = _make_service()
        headers = service.get_auth_headers()
        assert headers["Authorization"] == "Bearer tok123"

    def test_returns_only_auth_header(self):
        service, _ = _make_service()
        headers = service.get_auth_headers()
        assert set(headers.keys()) == {"Authorization"}
