"""Tests for rait_connector.constants."""

from rait_connector.constants import Metric


class TestMetric:
    def test_is_str_subclass(self):
        assert isinstance(Metric.COHERENCE, str)

    def test_value_matches_human_readable(self):
        assert Metric.COHERENCE.value == "Coherence"
        assert Metric.F1_SCORE.value == "F1 Score"
        assert Metric.SELF_HARM.value == "Self-Harm"
        assert Metric.HATE_AND_UNFAIRNESS.value == "Hate and Unfairness"
        assert Metric.GROUNDEDNESS_PRO.value == "Groundedness Pro"

    def test_total_count_is_22(self):
        assert len(Metric) == 22

    def test_string_equality(self):
        assert Metric.FLUENCY == "Fluency"
        assert Metric.VIOLENCE == "Violence"

    def test_all_expected_metrics_present(self):
        names = {m.value for m in Metric}
        for expected in (
            "Hate and Unfairness",
            "Ungrounded Attributes",
            "Content Safety",
            "Protected Materials",
            "Code Vulnerability",
            "Coherence",
            "Fluency",
            "QA",
            "Similarity",
            "F1 Score",
            "BLEU",
            "GLEU",
            "ROUGE",
            "METEOR",
            "Retrieval",
            "Groundedness",
            "Groundedness Pro",
            "Relevance",
            "Response Completeness",
            "Sexual",
            "Violence",
            "Self-Harm",
        ):
            assert expected in names, f"Missing metric: {expected}"

    def test_can_be_used_as_dict_key(self):
        d = {Metric.COHERENCE: 5.0}
        assert d[Metric.COHERENCE] == 5.0

    def test_iteration(self):
        metrics = list(Metric)
        assert len(metrics) == 22
