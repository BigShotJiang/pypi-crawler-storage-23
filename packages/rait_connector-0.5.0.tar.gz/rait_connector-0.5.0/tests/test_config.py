"""Tests for rait_connector.config."""

import os

import pytest

from rait_connector.config import Settings


class TestSettingsUrlValidation:
    def test_trailing_slash_stripped(self, monkeypatch):
        monkeypatch.setenv("RAIT_API_URL", "https://api.example.com/")
        s = Settings()
        assert s.rait_api_url == "https://api.example.com"

    def test_no_trailing_slash_unchanged(self, monkeypatch):
        monkeypatch.setenv("RAIT_API_URL", "https://api.example.com")
        s = Settings()
        assert s.rait_api_url == "https://api.example.com"

    def test_url_none_stays_none(self, monkeypatch):
        monkeypatch.delenv("RAIT_API_URL", raising=False)
        s = Settings()
        assert s.rait_api_url is None

    def test_openai_endpoint_trailing_slash_stripped(self, monkeypatch):
        monkeypatch.setenv("AZURE_OPENAI_ENDPOINT", "https://openai.example.com/")
        s = Settings()
        assert s.azure_openai_endpoint == "https://openai.example.com"

    def test_azure_ai_project_url_trailing_slash_stripped(self, monkeypatch):
        monkeypatch.setenv("AZURE_AI_PROJECT_URL", "https://project.example.com/")
        s = Settings()
        assert s.azure_ai_project_url == "https://project.example.com"


class TestSettingsSecretValidation:
    def test_empty_secret_raises(self, monkeypatch):
        from pydantic import ValidationError

        monkeypatch.setenv("RAIT_CLIENT_SECRET", "   ")
        with pytest.raises(ValidationError):
            Settings()

    def test_valid_secret_accepted(self, monkeypatch):
        monkeypatch.setenv("RAIT_CLIENT_SECRET", "my-secret-key")
        s = Settings()
        assert s.rait_client_secret == "my-secret-key"

    def test_none_secret_accepted(self, monkeypatch):
        monkeypatch.delenv("RAIT_CLIENT_SECRET", raising=False)
        s = Settings()
        assert s.rait_client_secret is None


class TestSettingsGetAuthHeaders:
    def test_returns_bearer_token(self):
        s = Settings()
        headers = s.get_auth_headers("my-token")
        assert headers["Authorization"] == "Bearer my-token"

    def test_includes_content_type(self):
        s = Settings()
        headers = s.get_auth_headers("tok")
        assert headers["Content-Type"] == "application/json"

    def test_includes_accept(self):
        s = Settings()
        headers = s.get_auth_headers("tok")
        assert headers["Accept"] == "application/json"


class TestSettingsGetAzureAiProjectDict:
    def test_returns_correct_dict(self, monkeypatch):
        monkeypatch.setenv("AZURE_SUBSCRIPTION_ID", "sub-123")
        monkeypatch.setenv("AZURE_RESOURCE_GROUP", "rg-abc")
        monkeypatch.setenv("AZURE_PROJECT_NAME", "my-project")
        s = Settings()
        d = s.get_azure_ai_project_dict()
        assert d["subscription_id"] == "sub-123"
        assert d["resource_group_name"] == "rg-abc"
        assert d["project_name"] == "my-project"

    def test_missing_subscription_id_raises(self, monkeypatch):
        monkeypatch.delenv("AZURE_SUBSCRIPTION_ID", raising=False)
        monkeypatch.setenv("AZURE_RESOURCE_GROUP", "rg-abc")
        monkeypatch.setenv("AZURE_PROJECT_NAME", "proj")
        s = Settings()
        with pytest.raises(ValueError, match="required"):
            s.get_azure_ai_project_dict()

    def test_all_missing_raises(self, monkeypatch):
        for k in (
            "AZURE_SUBSCRIPTION_ID",
            "AZURE_RESOURCE_GROUP",
            "AZURE_PROJECT_NAME",
        ):
            monkeypatch.delenv(k, raising=False)
        s = Settings()
        with pytest.raises(ValueError):
            s.get_azure_ai_project_dict()


class TestSettingsMergeWith:
    def test_override_replaces_value(self, monkeypatch):
        monkeypatch.setenv("RAIT_API_URL", "https://old.example.com")
        s = Settings()
        merged = s.merge_with(rait_api_url="https://new.example.com")
        assert merged.rait_api_url == "https://new.example.com"

    def test_original_is_unchanged(self, monkeypatch):
        monkeypatch.setenv("RAIT_API_URL", "https://original.example.com")
        s = Settings()
        s.merge_with(rait_api_url="https://other.example.com")
        assert s.rait_api_url == "https://original.example.com"

    def test_none_override_is_ignored(self, monkeypatch):
        monkeypatch.setenv("RAIT_API_URL", "https://keep.example.com")
        s = Settings()
        merged = s.merge_with(rait_api_url=None)
        assert merged.rait_api_url == "https://keep.example.com"

    def test_multiple_overrides(self, monkeypatch):
        monkeypatch.delenv("RAIT_CLIENT_ID", raising=False)
        monkeypatch.delenv("RAIT_API_URL", raising=False)
        s = Settings()
        merged = s.merge_with(
            rait_client_id="new-id", rait_api_url="https://api.example.com"
        )
        assert merged.rait_client_id == "new-id"
        assert merged.rait_api_url == "https://api.example.com"


class TestSettingsAzureEnvVars:
    def test_sets_azure_client_id_env_var(self, monkeypatch):
        monkeypatch.setenv("AZURE_CLIENT_ID", "client-xyz")
        Settings()
        assert os.environ.get("AZURE_CLIENT_ID") == "client-xyz"

    def test_sets_azure_tenant_id_env_var(self, monkeypatch):
        monkeypatch.setenv("AZURE_TENANT_ID", "tenant-abc")
        Settings()
        assert os.environ.get("AZURE_TENANT_ID") == "tenant-abc"


class TestSettingsDefaults:
    def test_default_openai_api_version(self):
        s = Settings()
        assert s.azure_openai_api_version == "2024-12-01-preview"

    def test_all_optional_fields_default_none(self, monkeypatch):
        # Clear all relevant env vars
        for key in (
            "RAIT_API_URL",
            "RAIT_CLIENT_ID",
            "RAIT_CLIENT_SECRET",
            "AZURE_CLIENT_ID",
            "AZURE_TENANT_ID",
            "AZURE_CLIENT_SECRET",
            "AZURE_OPENAI_ENDPOINT",
            "AZURE_OPENAI_API_KEY",
            "AZURE_OPENAI_DEPLOYMENT",
        ):
            monkeypatch.delenv(key, raising=False)
        s = Settings()
        assert s.rait_api_url is None
        assert s.rait_client_id is None
        assert s.azure_client_id is None
