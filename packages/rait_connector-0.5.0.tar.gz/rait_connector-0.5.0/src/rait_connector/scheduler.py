"""Scheduler for running RAIT tasks at regular intervals.

Wraps APScheduler 3.x to provide a simple interface for scheduling
recurring RAIT operations such as telemetry fetching and calibration runs.

Example:
    >>> from rait_connector import RAITClient, Scheduler
    >>>
    >>> client = RAITClient()
    >>> scheduler = Scheduler(client)
    >>>
    >>> scheduler.add_telemetry_job(interval="daily")
    >>> scheduler.add_calibration_job(
    ...     model_name="gpt-4",
    ...     model_version="1.0",
    ...     environment="production",
    ...     model_purpose="monitoring",
    ...     invoke_model=lambda prompt: my_llm(prompt),
    ...     interval="weekly",
    ... )
    >>>
    >>> scheduler.start()          # runs in background; program continues
    >>> print(scheduler.status())  # see all jobs and their state
    >>> print(scheduler.history()) # see past execution records
"""

import logging
import threading
import time
from collections import deque
from datetime import datetime, timedelta
from typing import Any, Callable, Deque, Dict, List, Optional, Union

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from .exceptions import SchedulerError

logger = logging.getLogger(__name__)

# ── Interval aliases ──────────────────────────────────────────────────────────

_INTERVAL_ALIASES: Dict[str, Dict[str, int]] = {
    "hourly": {"hours": 1},
    "daily": {"days": 1},
    "weekly": {"weeks": 1},
}

_DEFAULT_HISTORY_SIZE = 100  # max execution records kept in memory


def _parse_trigger(
    interval: Union[str, timedelta, int, float],
) -> Union[IntervalTrigger, CronTrigger]:
    """Parse an interval specification into an APScheduler trigger.

    Args:
        interval: One of:
            - ``"hourly"``, ``"daily"``, ``"weekly"`` shorthand strings
            - A cron expression string (e.g. ``"0 9 * * MON-FRI"``)
            - A :class:`datetime.timedelta` object
            - An ``int`` or ``float`` representing seconds

    Returns:
        An APScheduler trigger instance.

    Raises:
        SchedulerError: If the interval cannot be parsed.
    """
    if isinstance(interval, (int, float)):
        if interval <= 0:
            raise SchedulerError("Interval in seconds must be a positive number")
        return IntervalTrigger(seconds=int(interval))

    if isinstance(interval, timedelta):
        seconds = int(interval.total_seconds())
        if seconds <= 0:
            raise SchedulerError("Interval timedelta must be positive")
        return IntervalTrigger(seconds=seconds)

    if isinstance(interval, str):
        lower = interval.strip().lower()
        if lower in _INTERVAL_ALIASES:
            return IntervalTrigger(**_INTERVAL_ALIASES[lower])
        # Treat as a cron expression
        try:
            return CronTrigger.from_crontab(interval)
        except Exception as exc:
            raise SchedulerError(
                f"Cannot parse interval '{interval}'. "
                f"Use 'hourly', 'daily', 'weekly', a cron expression, "
                f"a timedelta, or a number of seconds."
            ) from exc

    raise SchedulerError(
        f"interval must be str, timedelta, int, or float — got {type(interval).__name__}"
    )


# ── Scheduler ────────────────────────────────────────────────────────────────


class Scheduler:
    """Runs registered jobs at configured intervals using APScheduler.

    Supports:

    * Named shortcuts: ``"hourly"``, ``"daily"``, ``"weekly"``
    * Cron expressions: ``"0 9 * * MON-FRI"``
    * :class:`datetime.timedelta` objects
    * Integer / float seconds

    Built-in RAIT jobs:

    * :meth:`add_telemetry_job` — calls :meth:`~rait_connector.RAITClient.fetch_telemetry`
    * :meth:`add_calibration_job` — runs calibration prompt evaluation

    Multiple :class:`Scheduler` instances can run simultaneously.

    Tracking:

    * :meth:`status` — all registered jobs with next run time and live
      ``is_executing`` flag
    * :meth:`running_jobs` — IDs of jobs currently executing
    * :meth:`history` — past execution records (timestamp, success/error)

    Example:
        >>> scheduler = Scheduler(client)
        >>> scheduler.add_telemetry_job(interval="daily")
        >>> scheduler.add_calibration_job(
        ...     model_name="gpt-4", model_version="1.0",
        ...     environment="production", model_purpose="monitoring",
        ...     invoke_model=lambda p: my_llm(p), interval="weekly",
        ... )
        >>> scheduler.start()
        >>> scheduler.status()
        [{'id': 'rait_telemetry', 'trigger': '...', 'next_run': '...', 'is_executing': False}]

    Decorator style:
        >>> @scheduler.job(interval="daily")
        ... def nightly_eval():
        ...     client.evaluate_batch(fetch_prompts())
        >>> scheduler.start()
    """

    def __init__(self, client: Any, max_history: int = _DEFAULT_HISTORY_SIZE) -> None:
        """Initialize the scheduler.

        Args:
            client: A :class:`~rait_connector.RAITClient` instance used by
                the built-in RAIT jobs.
            max_history: Maximum number of execution records to keep in memory.
                Older records are discarded automatically. Defaults to 100.
        """
        self._client = client
        self._aps = BackgroundScheduler()

        # Running-job tracking — updated inside the job wrapper, not via events,
        # to avoid the APScheduler race where EVENT_JOB_SUBMITTED fires AFTER
        # the job is already submitted to the threadpool (and may already be done).
        self._executing: Dict[str, datetime] = {}  # job_id -> started_at
        self._lock = threading.Lock()

        # Execution history (ring buffer)
        self._history: Deque[Dict[str, Any]] = deque(maxlen=max_history)

    # ── Job wrapper ───────────────────────────────────────────────────────────

    def _wrap(self, func: Callable, job_id: str) -> Callable:
        """Return a wrapper that tracks execution state and history."""

        def wrapper() -> None:
            started_at = datetime.now()
            with self._lock:
                self._executing[job_id] = started_at
            error: Optional[str] = None
            try:
                func()
            except Exception as exc:
                error = str(exc)
                raise
            finally:
                finished_at = datetime.now()
                with self._lock:
                    self._executing.pop(job_id, None)
                    self._history.append(
                        {
                            "job_id": job_id,
                            "started_at": started_at.isoformat(),
                            "finished_at": finished_at.isoformat(),
                            "success": error is None,
                            "error": error,
                        }
                    )

        wrapper.__name__ = func.__name__
        return wrapper

    # ── Generic job registration ──────────────────────────────────────────────

    def add_job(
        self,
        func: Callable,
        interval: Union[str, timedelta, int, float],
        name: Optional[str] = None,
        run_immediately: bool = False,
    ) -> None:
        """Register a callable to run at a given interval.

        Args:
            func: The callable to execute on each run.
            interval: How often to run. Accepts ``"hourly"``, ``"daily"``,
                ``"weekly"``, a cron expression, a :class:`datetime.timedelta`,
                or a number of seconds.
            name: Optional display name / job ID. Defaults to
                ``func.__name__``. Must be unique per scheduler instance;
                re-registering with the same name replaces the previous job.
            run_immediately: If ``True`` the job runs once as soon as the
                scheduler starts; otherwise it waits for the first interval
                to elapse.

        Raises:
            SchedulerError: If the interval cannot be parsed.
        """
        trigger = _parse_trigger(interval)
        job_id = name or func.__name__

        # Only pass next_run_time when we explicitly want immediate execution.
        # Passing next_run_time=None tells APScheduler to create the job in a
        # *paused* state, so we omit the kwarg entirely for the normal case.
        extra: Dict[str, Any] = {}
        if run_immediately:
            extra["next_run_time"] = datetime.now()

        try:
            self._aps.add_job(
                self._wrap(func, job_id),
                trigger=trigger,
                id=job_id,
                name=job_id,
                max_instances=1,
                replace_existing=True,
                misfire_grace_time=3600,
                **extra,
            )
        except Exception as exc:
            raise SchedulerError(f"Failed to register job '{job_id}': {exc}") from exc

        logger.info("Registered job '%s' (interval=%s)", job_id, interval)

    def job(
        self,
        interval: Union[str, timedelta, int, float],
        name: Optional[str] = None,
        run_immediately: bool = False,
    ) -> Callable:
        """Decorator to register a function as a scheduled job.

        Args:
            interval: How often to run (same as :meth:`add_job`).
            name: Optional job name. Defaults to the decorated function name.
            run_immediately: Whether to run once when the scheduler starts.

        Returns:
            The original function, unchanged.

        Example:
            >>> @scheduler.job(interval="daily")
            ... def my_job():
            ...     pass
        """

        def decorator(func: Callable) -> Callable:
            self.add_job(
                func, interval=interval, name=name, run_immediately=run_immediately
            )
            return func

        return decorator

    # ── Built-in RAIT jobs ────────────────────────────────────────────────────

    def add_telemetry_job(
        self,
        model_name: str,
        model_version: str,
        model_environment: str,
        model_purpose: str,
        interval: Union[str, timedelta, int, float] = "daily",
        on_result: Optional[Callable[[Dict[str, Any]], None]] = None,
        run_immediately: bool = False,
        **fetch_kwargs: Any,
    ) -> None:
        """Schedule automatic telemetry fetching and posting.

        Calls :meth:`~rait_connector.RAITClient.fetch_telemetry` on the
        configured interval, posts the results to the RAIT model-data-logs
        API via :meth:`~rait_connector.RAITClient.post_telemetry`, and
        optionally passes the result to a callback.

        Args:
            model_name: Name of the LLM model.
            model_version: Version of the LLM model.
            model_environment: Execution environment (e.g. ``"production"``).
            model_purpose: Evaluation purpose label.
            interval: How often to fetch telemetry. Defaults to ``"daily"``.
            on_result: Optional callback invoked with the telemetry result
                dict after each successful fetch. Signature:
                ``on_result(result: Dict[str, List[Dict]])``.
            run_immediately: Run once when the scheduler starts.
            **fetch_kwargs: Additional keyword arguments forwarded to
                :meth:`~rait_connector.RAITClient.fetch_telemetry`
                (e.g. ``timespan``, ``tables``, ``limit``).

        Example:
            >>> scheduler.add_telemetry_job(
            ...     model_name="gpt-4",
            ...     model_version="1.0",
            ...     model_environment="production",
            ...     model_purpose="monitoring",
            ...     interval="daily",
            ...     on_result=lambda r: print(r.keys()),
            ...     timespan=timedelta(days=7),
            ... )
        """

        def _telemetry_task() -> None:
            logger.info("Running scheduled telemetry fetch")
            result = self._client.fetch_telemetry(**fetch_kwargs)
            summary = {table: len(rows) for table, rows in result.items()}
            logger.info("Telemetry fetched: %s", summary)
            self._client.post_telemetry(
                model_name=model_name,
                model_version=model_version,
                model_environment=model_environment,
                model_purpose=model_purpose,
                telemetry_data=result,
            )
            if on_result is not None:
                on_result(result)

        self.add_job(
            _telemetry_task,
            interval=interval,
            name="rait_telemetry",
            run_immediately=run_immediately,
        )

    def add_calibration_job(
        self,
        model_name: str,
        model_version: str,
        environment: str,
        model_purpose: str,
        invoke_model: Callable[[str], str],
        interval: Union[str, timedelta, int, float] = "weekly",
        run_immediately: bool = False,
    ) -> None:
        """Schedule automatic calibration response collection.

        On each run two calibration flows are executed:

        **Flow 1 — Calibrator prompt responses:**

        1. Fetches prompts that need model responses via
           :meth:`~rait_connector.RAITClient.get_prompts_response`.
        2. Invokes ``invoke_model`` for each prompt to collect responses.
        3. Submits the responses back via
           :meth:`~rait_connector.RAITClient.update_prompts_response`.

        **Flow 2 — Model-registry calibration prompts:**

        1. Fetches calibration prompts from the model registry via
           :meth:`~rait_connector.RAITClient.get_model_calibration_prompts`.
        2. Invokes ``invoke_model`` for each prompt to collect responses.
        3. Posts the responses to the model-data-logs API with
           ``log_type="calibration"`` via
           :meth:`~rait_connector.RAITClient.post_calibration_responses`.

        Args:
            model_name: Name of the LLM model to calibrate.
            model_version: Version of the LLM model.
            environment: Execution environment (e.g. ``"production"``).
            model_purpose: Evaluation purpose label.
            invoke_model: Callback that takes a prompt text string and returns
                the model's response string.
            interval: How often to run. Defaults to ``"weekly"``.
            run_immediately: Run once when the scheduler starts.

        Example:
            >>> scheduler.add_calibration_job(
            ...     model_name="gpt-4",
            ...     model_version="1.0",
            ...     environment="production",
            ...     model_purpose="monitoring",
            ...     invoke_model=lambda prompt: openai_client.complete(prompt),
            ...     interval="weekly",
            ... )
        """

        def _calibration_task() -> None:
            logger.info(
                "Running scheduled calibration for %s %s (%s)",
                model_name,
                model_version,
                environment,
            )

            # ── Flow 1: calibrator prompt responses ───────────────────────────
            prompts = self._client.get_prompts_response(
                model_name=model_name,
                model_version=model_version,
                model_environment=environment,
            )
            if prompts:
                logger.info(
                    "Flow 1: collecting responses for %d calibrator prompt(s)",
                    len(prompts),
                )
                collected = []
                for prompt in prompts:
                    prompt_response_id = prompt.get("prompt_response_id", "")
                    prompt_text = prompt.get("prompt_text", "")
                    try:
                        model_response = invoke_model(prompt_text)
                        collected.append(
                            {
                                "prompt_response_id": prompt_response_id,
                                "prompt_text": prompt_text,
                                "model_response": model_response,
                            }
                        )
                    except Exception as exc:
                        logger.error(
                            "Flow 1: failed to invoke model for prompt_response_id %s: %s",
                            prompt_response_id,
                            exc,
                        )

                if collected:
                    self._client.update_prompts_response(
                        responses=collected,
                        model_name=model_name,
                        model_version=model_version,
                        model_environment=environment,
                    )
                    logger.info("Flow 1: submitted %d response(s)", len(collected))
            else:
                logger.info(
                    "Flow 1: no calibrator prompts awaiting responses — skipping"
                )

            # ── Flow 2: model-registry calibration prompts ────────────────────
            cal_prompts = self._client.get_model_calibration_prompts(
                model_name=model_name,
                model_version=model_version,
                model_environment=environment,
            )
            if cal_prompts:
                logger.info(
                    "Flow 2: collecting responses for %d model calibration prompt(s)",
                    len(cal_prompts),
                )
                calibration_responses = []
                for cp in cal_prompts:
                    prompt_id = cp.get("prompt_id", "")
                    prompt_text = cp.get("prompt_text", "")
                    try:
                        response_text = invoke_model(prompt_text)
                        calibration_responses.append(
                            {
                                "prompt_id": prompt_id,
                                "response_text": response_text,
                            }
                        )
                    except Exception as exc:
                        logger.error(
                            "Flow 2: failed to invoke model for prompt_id %s: %s",
                            prompt_id,
                            exc,
                        )

                if calibration_responses:
                    self._client.post_calibration_responses(
                        model_name=model_name,
                        model_version=model_version,
                        model_environment=environment,
                        model_purpose=model_purpose,
                        calibration_responses=calibration_responses,
                    )
                    logger.info(
                        "Flow 2: posted %d calibration response(s)",
                        len(calibration_responses),
                    )
            else:
                logger.info("Flow 2: no model calibration prompts available — skipping")

        job_name = f"rait_calibration_{model_name}_{model_version}_{environment}"
        self.add_job(
            _calibration_task,
            interval=interval,
            name=job_name,
            run_immediately=run_immediately,
        )

    # ── Lifecycle ─────────────────────────────────────────────────────────────

    def start(self, blocking: bool = False) -> None:
        """Start the scheduler.

        Args:
            blocking: If ``True`` the calling thread blocks until the
                scheduler is stopped (e.g. via ``KeyboardInterrupt``).
                Useful for standalone scripts. Defaults to ``False`` which
                runs the scheduler in a background daemon thread so the
                program can continue.

        Raises:
            SchedulerError: If the underlying APScheduler fails to start.
        """
        if not self._aps.running:
            try:
                self._aps.start(paused=False)
            except Exception as exc:
                raise SchedulerError(f"Failed to start scheduler: {exc}") from exc
            logger.info("Scheduler started with %d job(s)", len(self._aps.get_jobs()))

        if blocking:
            logger.info("Scheduler running in blocking mode — press Ctrl+C to stop")
            try:
                while True:
                    time.sleep(1)
            except (KeyboardInterrupt, SystemExit):
                self.stop()

    def stop(self) -> None:
        """Stop the scheduler gracefully.

        Waits for any currently executing jobs to finish before returning.
        Safe to call even if the scheduler is not running.
        """
        if self._aps.running:
            self._aps.shutdown(wait=True)
            logger.info("Scheduler stopped")

    # ── Introspection ─────────────────────────────────────────────────────────

    def is_running(self) -> bool:
        """Return ``True`` if the scheduler is currently running."""
        return self._aps.running

    def running_jobs(self) -> List[str]:
        """Return the IDs of jobs that are currently executing.

        A job appears here from the moment its function starts until it
        returns (or raises). Useful for checking whether a long-running
        job is still in progress.

        Returns:
            List of job ID strings.
        """
        with self._lock:
            return list(self._executing.keys())

    def status(self) -> List[Dict[str, Any]]:
        """Return a snapshot of all registered jobs.

        Each dict contains:

        * ``id`` — job ID / name
        * ``trigger`` — human-readable trigger description
        * ``next_run`` — ISO 8601 timestamp of next scheduled run, or ``None``
        * ``is_executing`` — ``True`` if the job is currently running

        Returns:
            List of job status dictionaries.
        """
        with self._lock:
            currently_executing = set(self._executing.keys())

        result = []
        for job in self._aps.get_jobs():
            # next_run_time is unset on pending jobs (slot not yet assigned)
            nrt = getattr(job, "next_run_time", None)
            result.append(
                {
                    "id": job.id,
                    "trigger": str(job.trigger),
                    "next_run": nrt.isoformat() if nrt else None,
                    "is_executing": job.id in currently_executing,
                }
            )
        return result

    def history(
        self,
        job_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Return past execution records, most recent first.

        Each record contains:

        * ``job_id`` — which job ran
        * ``started_at`` — ISO 8601 start timestamp
        * ``finished_at`` — ISO 8601 finish timestamp
        * ``success`` — ``True`` if the job completed without raising
        * ``error`` — error message string if ``success`` is ``False``, else ``None``

        Args:
            job_id: Filter records to a specific job. Returns all jobs if
                omitted.
            limit: Cap the number of records returned. Returns all available
                records if omitted.

        Returns:
            List of execution record dicts, newest first.
        """
        with self._lock:
            records = list(self._history)

        # Newest first
        records = list(reversed(records))

        if job_id is not None:
            records = [r for r in records if r["job_id"] == job_id]

        if limit is not None:
            records = records[:limit]

        return records


__all__ = ["Scheduler"]
