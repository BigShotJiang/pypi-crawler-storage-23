"""Constants used throughout the RAIT Connector library."""

from enum import Enum


class Metric(str, Enum):
    """Enumeration of metric names used for model evaluation.

    Each value corresponds to a specific scoring category used
    to assess model behavior, safety, quality, robustness, or
    task performance.
    """

    HATE_AND_UNFAIRNESS_AZURE = "Hate and Unfairness (Azure)"
    UNGROUNDED_ATTRIBUTES_AZURE = "Ungrounded Attributes (Azure)"
    CONTENT_SAFETY_AZURE = "Content Safety (Azure)"
    PROTECTED_MATERIALS_AZURE = "Protected Materials (Azure)"
    CODE_VULNERABILITY_AZURE = "Code Vulnerability (Azure)"
    COHERENCE_AZURE = "Coherence (Azure)"
    FLUENCY_AZURE = "Fluency (Azure)"
    QA_AZURE = "QA (Azure)"
    SIMILARITY_AZURE = "Similarity (Azure)"
    F1_SCORE_AZURE = "F1 Score (Azure)"
    BLEU_AZURE = "BLEU (Azure)"
    GLEU_AZURE = "GLEU (Azure)"
    ROUGE_AZURE = "ROUGE (Azure)"
    METEOR_AZURE = "METEOR (Azure)"
    RETRIEVAL_AZURE = "Retrieval (Azure)"
    GROUNDEDNESS_AZURE = "Groundedness (Azure)"
    GROUNDEDNESS_PRO_AZURE = "Groundedness Pro (Azure)"
    RELEVANCE_AZURE = "Relevance (Azure)"
    RESPONSE_COMPLETENESS_AZURE = "Response Completeness (Azure)"
    SEXUAL_AZURE = "Sexual (Azure)"
    VIOLENCE_AZURE = "Violence (Azure)"
    SELF_HARM_AZURE = "Self-Harm (Azure)"


__all__ = ["Metric"]
