# -*- coding: utf-8 -*-
from responses import matchers


def test_login(responses, dummy_client):
    responses.add(
        responses.POST,
        "https://dummy.test/api/v1/user/login/",
        json={"auth_token": "tolkien"},
    )

    assert dummy_client.session.auth.token is None
    dummy_client.session.auth.scheme = "Beer"

    assert dummy_client.login("user@user.user", "Pa$$w0rd") == {"auth_token": "tolkien"}

    assert dummy_client.session.auth.token == "tolkien"
    assert dummy_client.session.auth.scheme == "Token"


def test_default_auth_scheme(responses, dummy_client):
    responses.add(
        responses.GET,
        "https://dummy.test/api/v1/elements/",
        match=[matchers.header_matcher({"Authorization": "Token ofgratitude"})],
        json={"count": 0, "previous": None, "next": None, "results": []},
    )

    dummy_client.configure(token="ofgratitude")

    assert dummy_client.request("ListElements") == {
        "count": 0,
        "previous": None,
        "next": None,
        "results": [],
    }


def test_custom_auth_scheme(responses, dummy_client):
    responses.add(
        responses.GET,
        "https://dummy.test/api/v1/elements/",
        match=[matchers.header_matcher({"Authorization": "Digest Food"})],
        json={"count": 0, "previous": None, "next": None, "results": []},
    )

    dummy_client.configure(token="Food", auth_scheme="Digest")

    assert dummy_client.request("ListElements") == {
        "count": 0,
        "previous": None,
        "next": None,
        "results": [],
    }
