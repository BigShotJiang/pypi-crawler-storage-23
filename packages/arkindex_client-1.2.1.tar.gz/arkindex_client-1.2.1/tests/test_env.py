# -*- coding: utf-8 -*-
import os

import pytest

from arkindex import options_from_env


@pytest.mark.parametrize(
    "env,expected",
    [
        ({}, {}),
        ({"ARKINDEX_API_URL": "http://lol"}, {"base_url": "http://lol"}),
        ({"ARKINDEX_API_SCHEMA_URL": "http://lol"}, {"schema_url": "http://lol"}),
        ({"ARKINDEX_API_AUTH_SCHEME": "Bribe"}, {"auth_scheme": "Bribe"}),
        (
            {"ARKINDEX_API_CSRF_COOKIE": "raisin-oatmeal"},
            {"csrf_cookie": "raisin-oatmeal"},
        ),
        (
            {"ARKINDEX_API_TOKEN": "ofGoodWill"},
            {"auth_scheme": "Token", "token": "ofGoodWill"},
        ),
        (
            {"ARKINDEX_TASK_TOKEN": "Kimonos"},
            {"auth_scheme": "Ponos", "token": "Kimonos"},
        ),
        # The task token should override the API token
        (
            {"ARKINDEX_API_TOKEN": "ofGoodWill", "ARKINDEX_TASK_TOKEN": "Kimonos"},
            {"auth_scheme": "Ponos", "token": "Kimonos"},
        ),
        # The auth scheme can override the scheme set by the API token
        (
            {"ARKINDEX_API_TOKEN": "Bad", "ARKINDEX_API_AUTH_SCHEME": "Breaking"},
            {"auth_scheme": "Breaking", "token": "Bad"},
        ),
        # The auth scheme can override the scheme set by the task token
        (
            {"ARKINDEX_TASK_TOKEN": "Bad", "ARKINDEX_API_AUTH_SCHEME": "Breaking"},
            {"auth_scheme": "Breaking", "token": "Bad"},
        ),
        # Also try with both tokens set
        (
            {
                "ARKINDEX_API_AUTH_SCHEME": "It",
                "ARKINDEX_API_TOKEN": "Fails",
                "ARKINDEX_TASK_TOKEN": "Works",
            },
            {"auth_scheme": "It", "token": "Works"},
        ),
        # Set everything at once
        (
            {
                "ARKINDEX_API_URL": "http://lol",
                "ARKINDEX_API_SCHEMA_URL": "http://lul",
                "ARKINDEX_API_AUTH_SCHEME": "Roll",
                "ARKINDEX_API_TOKEN": "d6",
                "ARKINDEX_TASK_TOKEN": "d20",
                "ARKINDEX_API_CSRF_COOKIE": "thin-mint",
            },
            {
                "base_url": "http://lol",
                "schema_url": "http://lul",
                "auth_scheme": "Roll",
                "token": "d20",
                "csrf_cookie": "thin-mint",
            },
        ),
    ],
)
def test_options_from_env(mocker, env, expected):
    mocker.patch.dict(os.environ, env, clear=True)
    assert options_from_env() == expected
