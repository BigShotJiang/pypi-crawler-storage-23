# -*- coding: utf-8 -*-
import pytest

from arkindex.exceptions import ErrorResponse


def test_request_no_more_retries(responses, dummy_client):
    # First call is an error
    responses.add(
        responses.POST,
        "https://dummy.test/api/v1/user/login/",
        status=502,
    )

    dummy_client.request.retry.wait = 0

    # There should be 5 retries
    max_retries = 5

    with pytest.raises(ErrorResponse):
        dummy_client.login("user@user.user", "Pa$$w0rd")

    assert len(responses.calls) == max_retries
    assert [call.request.url for call in responses.calls] == [
        "https://dummy.test/api/v1/user/login/",
    ] * max_retries
