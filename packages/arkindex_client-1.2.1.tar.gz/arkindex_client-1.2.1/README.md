# Arkindex API Client


`arkindex-client` provides an API client to interact with Arkindex servers.

To learn more about the developer setup, please read the [official documentation](https://api.arkindex.org/develop).
