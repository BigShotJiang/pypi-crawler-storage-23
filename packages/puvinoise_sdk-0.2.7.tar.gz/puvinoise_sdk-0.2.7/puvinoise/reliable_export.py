"""
Reliable span exporter: wraps any SpanExporter with retry (exponential backoff)
and offline persistence. If export fails after retries, the batch is stored locally
and replayed on the next flush or startup so telemetry is never lost.
"""

from __future__ import annotations

import logging
import os
import pickle
import threading
import time
import uuid
from pathlib import Path
from typing import Sequence

from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult

logger = logging.getLogger(__name__)

_DEFAULT_PERSIST_DIR = os.environ.get("PUVINOISE_SPAN_PERSIST_DIR") or os.path.join(
    os.path.expanduser("~"), ".puvinoise", "span_queue"
)
_DEFAULT_MAX_RETRIES = int(os.environ.get("PUVINOISE_SPAN_EXPORT_MAX_RETRIES", "5"))
_DEFAULT_BASE_DELAY_SEC = float(os.environ.get("PUVINOISE_SPAN_EXPORT_BASE_DELAY_SEC", "1.0"))
_DEFAULT_MAX_DELAY_SEC = float(os.environ.get("PUVINOISE_SPAN_EXPORT_MAX_DELAY_SEC", "60.0"))


def _exponential_backoff(attempt: int, base: float, cap: float) -> float:
    delay = base * (2.0 ** attempt)
    return min(cap, max(0, delay))


class ReliableSpanExporter(SpanExporter):
    """
    Wraps a SpanExporter and adds:
    - Retry with exponential backoff on export failure.
    - Persistence of failed batches to disk; they are re-exported on force_flush or replay.
    """

    def __init__(
        self,
        wrapped: SpanExporter,
        *,
        persist_dir: str | None = None,
        max_retries: int = _DEFAULT_MAX_RETRIES,
        base_delay_sec: float = _DEFAULT_BASE_DELAY_SEC,
        max_delay_sec: float = _DEFAULT_MAX_DELAY_SEC,
    ):
        self._wrapped = wrapped
        self._persist_dir = Path(persist_dir or _DEFAULT_PERSIST_DIR)
        self._max_retries = max(0, max_retries)
        self._base_delay_sec = base_delay_sec
        self._max_delay_sec = max_delay_sec
        self._lock = threading.Lock()

    def export(self, spans: Sequence) -> SpanExportResult:
        for attempt in range(self._max_retries + 1):
            try:
                result = self._wrapped.export(spans)
                if result == SpanExportResult.SUCCESS:
                    return SpanExportResult.SUCCESS
                if attempt < self._max_retries:
                    delay = _exponential_backoff(attempt, self._base_delay_sec, self._max_delay_sec)
                    logger.debug("Span export returned FAILURE (attempt %s), retry in %.1fs", attempt + 1, delay)
                    time.sleep(delay)
            except Exception as e:
                if attempt < self._max_retries:
                    delay = _exponential_backoff(attempt, self._base_delay_sec, self._max_delay_sec)
                    logger.debug("Span export failed (attempt %s), retry in %.1fs: %s", attempt + 1, delay, e)
                    time.sleep(delay)
                else:
                    logger.warning("Span export failed after %s retries, persisting batch: %s", self._max_retries, e)
                    self._persist_spans(spans)
                    return SpanExportResult.FAILURE
        self._persist_spans(spans)
        return SpanExportResult.FAILURE

    def _persist_spans(self, spans: Sequence) -> None:
        if not spans:
            return
        self._persist_dir.mkdir(parents=True, exist_ok=True)
        path = self._persist_dir / f"spans_{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}.pkl"
        try:
            with open(path, "wb") as f:
                pickle.dump(list(spans), f, protocol=pickle.HIGHEST_PROTOCOL)
            logger.debug("Persisted span batch to %s (%s spans)", path, len(spans))
        except Exception as e:
            logger.error("Failed to persist span batch: %s", e)

    def flush_persisted(self) -> int:
        """
        Try to re-export all persisted span batches. Returns number of spans successfully re-exported.
        """
        if not self._persist_dir.exists():
            return 0
        total = 0
        for path in sorted(self._persist_dir.glob("spans_*.pkl")):
            try:
                with open(path, "rb") as f:
                    spans = pickle.load(f)
                if not spans:
                    path.unlink(missing_ok=True)
                    continue
                result = SpanExportResult.FAILURE
                for attempt in range(self._max_retries + 1):
                    try:
                        result = self._wrapped.export(spans)
                        if result == SpanExportResult.SUCCESS:
                            break
                    except Exception as e:
                        if attempt < self._max_retries:
                            time.sleep(_exponential_backoff(attempt, self._base_delay_sec, self._max_delay_sec))
                        else:
                            logger.warning("Replay export failed for %s: %s", path, e)
                if result == SpanExportResult.SUCCESS:
                    path.unlink(missing_ok=True)
                    total += len(spans)
            except Exception as e:
                logger.warning("Failed to load/replay %s: %s", path, e)
        return total

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        ok = getattr(self._wrapped, "force_flush", lambda **kw: True)(timeout_millis=timeout_millis)
        self.flush_persisted()
        return ok

    def shutdown(self) -> None:
        self.flush_persisted()
        if hasattr(self._wrapped, "shutdown"):
            self._wrapped.shutdown()
