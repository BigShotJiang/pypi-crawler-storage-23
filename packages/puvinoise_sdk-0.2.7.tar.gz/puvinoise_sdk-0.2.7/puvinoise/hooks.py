"""
Multi-provider instrumentation hooks for puvinoise SDK.
Supports Anthropic, OpenAI, Ollama, and generic LLM providers.
"""

from opentelemetry import trace
from opentelemetry.trace import Status, StatusCode
from puvinoise.context import AgentContext
import functools

_tracer = trace.get_tracer("agent.hooks")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _attach_agent_context(span):
    """Attach run_id, agent_name, and optional goal/task_type/intent from AgentContext to span."""
    run_id = AgentContext.get_run_id()
    agent_name = AgentContext.get_agent_name()
    if run_id:
        span.set_attribute("agent.run_id", run_id)
    if agent_name:
        span.set_attribute("agent.name", agent_name)
    goal = AgentContext.get_goal()
    if goal:
        span.set_attribute("agent.goal", str(goal)[:500])
    task_type = AgentContext.get_task_type()
    if task_type:
        span.set_attribute("agent.task_type", str(task_type)[:200])
        span.set_attribute("agent.task", str(task_type)[:200])
    intent = AgentContext.get_intent()
    if intent:
        span.set_attribute("agent.intent", str(intent)[:200])


def _extract_openai_response(result, span):
    """
    Parse an OpenAI ChatCompletion response object and record span attributes.
    Works for openai>=1.0 (the openai.types.chat.ChatCompletion object).
    """
    try:
        # Model actually used (may differ from requested)
        if hasattr(result, "model"):
            span.set_attribute("llm.response_model", result.model)

        choices = getattr(result, "choices", None)
        if choices:
            first = choices[0]
            # finish_reason
            finish_reason = getattr(first, "finish_reason", None)
            if finish_reason:
                span.set_attribute("llm.stop_reason", finish_reason)
            # message content
            message = getattr(first, "message", None)
            if message:
                content = getattr(message, "content", None) or ""
                span.set_attribute("llm.response", content[:500])
                span.set_attribute("llm.response_length", len(content))

        # Token usage
        usage = getattr(result, "usage", None)
        if usage:
            if hasattr(usage, "prompt_tokens"):
                span.set_attribute("llm.input_tokens", usage.prompt_tokens)
            if hasattr(usage, "completion_tokens"):
                span.set_attribute("llm.output_tokens", usage.completion_tokens)
    except Exception:
        pass  # Never let telemetry crash the caller


def _extract_anthropic_response(result, span):
    """Parse an Anthropic MessageResponse and record span attributes."""
    try:
        if hasattr(result, "model"):
            span.set_attribute("llm.response_model", result.model)

        if hasattr(result, "content") and result.content:
            if isinstance(result.content, list):
                text_blocks = [b.text for b in result.content if hasattr(b, "text")]
                response_text = " ".join(text_blocks)
            else:
                response_text = str(result.content)
            span.set_attribute("llm.response", response_text[:500])
            span.set_attribute("llm.response_length", len(response_text))

        if hasattr(result, "stop_reason"):
            span.set_attribute("llm.stop_reason", result.stop_reason)

        usage = getattr(result, "usage", None)
        if usage:
            if hasattr(usage, "input_tokens"):
                span.set_attribute("llm.input_tokens", usage.input_tokens)
            if hasattr(usage, "output_tokens"):
                span.set_attribute("llm.output_tokens", usage.output_tokens)
    except Exception:
        pass


def _extract_openai_messages(kwargs, span):
    """Extract prompt info from OpenAI-style messages kwarg."""
    messages = kwargs.get("messages")
    if not messages:
        return
    span.set_attribute("llm.message_count", len(messages))
    user_msgs = [m for m in messages if m.get("role") == "user"]
    if user_msgs:
        content = user_msgs[0].get("content", "")
        if isinstance(content, str):
            span.set_attribute("llm.prompt", content[:500])
        elif isinstance(content, list):
            texts = [b.get("text", "") for b in content if b.get("type") == "text"]
            if texts:
                span.set_attribute("llm.prompt", texts[0][:500])


# ---------------------------------------------------------------------------
# Anthropic hooks
# ---------------------------------------------------------------------------

def instrument_anthropic_call(func):
    """
    Decorator to automatically trace synchronous Anthropic API calls.

    Usage::

        @instrument_anthropic_call
        def call_claude(prompt, model="claude-sonnet-4-5-20250929"):
            response = client.messages.create(...)
            return response
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with _tracer.start_as_current_span("llm.anthropic") as span:
            _attach_agent_context(span)
            span.set_attribute("llm.provider", "anthropic")

            model = kwargs.get("model")
            if model:
                span.set_attribute("llm.model", model)

            _extract_openai_messages(kwargs, span)  # same shape for Anthropic

            if "temperature" in kwargs:
                span.set_attribute("llm.temperature", float(kwargs["temperature"]))
            if "max_tokens" in kwargs:
                span.set_attribute("llm.max_tokens", int(kwargs["max_tokens"]))

            try:
                result = func(*args, **kwargs)
                _extract_anthropic_response(result, span)
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                span.set_attribute("error.type", type(e).__name__)
                raise

    return wrapper


def instrument_anthropic_stream(func):
    """
    Decorator for *generator* streaming Anthropic API calls.

    The span stays open for the entire stream duration (bug fix: previously
    the span closed before iteration completed).

    Usage::

        @instrument_anthropic_stream
        def stream_claude(prompt):
            with client.messages.stream(...) as stream:
                for text in stream.text_stream:
                    yield text
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        span = _tracer.start_span("llm.anthropic.stream")
        ctx = trace.use_span(span, end_on_exit=False)
        ctx.__enter__()

        _attach_agent_context(span)
        span.set_attribute("llm.provider", "anthropic")
        span.set_attribute("llm.streaming", True)

        model = kwargs.get("model")
        if model:
            span.set_attribute("llm.model", model)

        chunk_count = 0
        total_length = 0

        try:
            for chunk in func(*args, **kwargs):
                chunk_count += 1
                if isinstance(chunk, str):
                    total_length += len(chunk)
                yield chunk

            span.set_attribute("llm.chunks_received", chunk_count)
            span.set_attribute("llm.total_length", total_length)
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise
        finally:
            ctx.__exit__(None, None, None)
            span.end()

    return wrapper


# ---------------------------------------------------------------------------
# OpenAI hook
# ---------------------------------------------------------------------------

def instrument_openai_call(func):
    """
    Decorator to automatically trace OpenAI API calls (openai>=1.0).

    API keys are read by the openai library itself (``OPENAI_API_KEY`` env var
    or ``openai.api_key``).  The SDK never touches credentials.

    Usage::

        @instrument_openai_call
        def call_gpt(prompt, model="gpt-4o"):
            response = client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
            )
            return response
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        with _tracer.start_as_current_span("llm.openai") as span:
            _attach_agent_context(span)
            span.set_attribute("llm.provider", "openai")

            model = kwargs.get("model")
            if model:
                span.set_attribute("llm.model", model)

            _extract_openai_messages(kwargs, span)

            if "temperature" in kwargs:
                span.set_attribute("llm.temperature", float(kwargs["temperature"]))
            if "max_tokens" in kwargs:
                span.set_attribute("llm.max_tokens", int(kwargs["max_tokens"]))

            try:
                result = func(*args, **kwargs)
                _extract_openai_response(result, span)
                span.set_status(Status(StatusCode.OK))
                return result
            except Exception as e:
                span.set_status(Status(StatusCode.ERROR, str(e)))
                span.record_exception(e)
                span.set_attribute("error.type", type(e).__name__)
                raise

    return wrapper


def instrument_openai_stream(func):
    """
    Decorator for streaming OpenAI calls using ``stream=True``.

    Usage::

        @instrument_openai_stream
        def stream_gpt(prompt, model="gpt-4o"):
            for chunk in client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                stream=True,
            ):
                delta = chunk.choices[0].delta.content or ""
                yield delta
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        span = _tracer.start_span("llm.openai.stream")
        ctx = trace.use_span(span, end_on_exit=False)
        ctx.__enter__()

        _attach_agent_context(span)
        span.set_attribute("llm.provider", "openai")
        span.set_attribute("llm.streaming", True)

        model = kwargs.get("model")
        if model:
            span.set_attribute("llm.model", model)

        chunk_count = 0
        total_length = 0

        try:
            for chunk in func(*args, **kwargs):
                chunk_count += 1
                if isinstance(chunk, str):
                    total_length += len(chunk)
                yield chunk

            span.set_attribute("llm.chunks_received", chunk_count)
            span.set_attribute("llm.total_length", total_length)
            span.set_status(Status(StatusCode.OK))
        except Exception as e:
            span.set_status(Status(StatusCode.ERROR, str(e)))
            span.record_exception(e)
            raise
        finally:
            ctx.__exit__(None, None, None)
            span.end()

    return wrapper


# ---------------------------------------------------------------------------
# Generic / Ollama hook
# ---------------------------------------------------------------------------

def instrument_llm_call(provider="unknown"):
    """
    Generic LLM call instrumentation (works with any provider: Ollama, Cohere, etc.).

    Unlike the old version this is now a *parameterised* decorator so you can
    tag the provider name cleanly::

        @instrument_llm_call(provider="ollama")
        def call_ollama(prompt, model="llama3"):
            ...

    For backward-compat, calling without parentheses still works (provider="unknown").
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _tracer.start_as_current_span("llm.call") as span:
                _attach_agent_context(span)
                span.set_attribute("llm.provider", provider)

                model = kwargs.get("model", "unknown")
                span.set_attribute("llm.model", model)

                # Accept a plain prompt string as first positional arg or kwarg
                prompt = kwargs.get("prompt") or (
                    args[0] if args and isinstance(args[0], str) else None
                )
                if prompt:
                    span.set_attribute("llm.prompt", prompt[:500])

                if "temperature" in kwargs:
                    span.set_attribute("llm.temperature", float(kwargs["temperature"]))

                try:
                    result = func(*args, **kwargs)

                    if isinstance(result, str):
                        span.set_attribute("llm.response", result[:500])
                        span.set_attribute("llm.response_length", len(result))
                    elif isinstance(result, dict):
                        # Ollama /api/chat returns a dict
                        msg = (
                            result.get("message", {}).get("content")
                            or result.get("response", "")
                        )
                        if msg:
                            span.set_attribute("llm.response", msg[:500])
                            span.set_attribute("llm.response_length", len(msg))
                        # Ollama token counts
                        if "prompt_eval_count" in result:
                            span.set_attribute("llm.input_tokens", result["prompt_eval_count"])
                        if "eval_count" in result:
                            span.set_attribute("llm.output_tokens", result["eval_count"])

                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    span.set_attribute("error.type", type(e).__name__)
                    raise

        return wrapper

    # Allow @instrument_llm_call (no parens) for backward compat
    if callable(provider):
        func, provider = provider, "unknown"
        return decorator(func)

    return decorator


# ---------------------------------------------------------------------------
# Memory & tool hooks (unchanged API, small robustness improvements)
# ---------------------------------------------------------------------------

def instrument_memory_operation(operation_type="query"):
    """
    Decorator to trace memory operations (retrieval, storage, delete, etc.).

    Usage::

        @instrument_memory_operation("retrieve")
        def retrieve_memory(query):
            ...
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            with _tracer.start_as_current_span(f"memory.{operation_type}") as span:
                _attach_agent_context(span)
                span.set_attribute("memory.operation", operation_type)

                try:
                    result = func(*args, **kwargs)
                    if isinstance(result, (list, tuple)):
                        span.set_attribute("memory.result_count", len(result))
                    span.set_status(Status(StatusCode.OK))
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    raise

        return wrapper
    return decorator


def instrument_tool_call(tool_name=None, tool_candidates=None, selection_reasoning=None, selection_confidence=None):
    """
    Decorator to trace agent tool usage.
    Optionally records decision telemetry: tool candidates considered and selection reasoning.

    Usage::

        @instrument_tool_call("web_search")
        def search_web(query):
            ...

        @instrument_tool_call("web_search", tool_candidates=["web_search", "calculator"],
                             selection_reasoning="need current info", selection_confidence=0.9)
        def search_web(query):
            ...
    """
    # Backward compat: @instrument_tool_call without parens
    if callable(tool_name):
        func, tool_name = tool_name, None
        return instrument_tool_call(None, None, None, None)(func)

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            name = tool_name or func.__name__
            with _tracer.start_as_current_span(f"tool.{name}") as span:
                _attach_agent_context(span)
                span.set_attribute("tool.name", name)
                if tool_candidates is not None:
                    from puvinoise.decision_telemetry import record_tool_candidates, record_tool_selection_reasoning
                    record_tool_candidates(
                        candidates=tool_candidates,
                        selected_name=name,
                        reasoning=selection_reasoning,
                        confidence=selection_confidence,
                    )
                    if selection_reasoning is not None:
                        record_tool_selection_reasoning(
                            tool_name=name,
                            reasoning=selection_reasoning,
                            confidence=selection_confidence,
                        )
                try:
                    result = func(*args, **kwargs)
                    span.set_status(Status(StatusCode.OK))
                    # Behaviour signals: count successful tool call
                    AgentContext.increment_tool_call(name, success=True)
                    return result
                except Exception as e:
                    span.set_status(Status(StatusCode.ERROR, str(e)))
                    span.record_exception(e)
                    # Behaviour signals: count failed tool call
                    AgentContext.increment_tool_call(name, success=False)
                    raise

        return wrapper
    return decorator


# ---------------------------------------------------------------------------
# Span utilities
# ---------------------------------------------------------------------------

def add_span_attribute(key: str, value):
    """Add a custom attribute to the current active span."""
    span = trace.get_current_span()
    if span and span.is_recording():
        span.set_attribute(key, value)


def add_span_event(name: str, attributes: dict = None):
    """Add an event to the current active span."""
    span = trace.get_current_span()
    if span and span.is_recording():
        span.add_event(name, attributes or {})