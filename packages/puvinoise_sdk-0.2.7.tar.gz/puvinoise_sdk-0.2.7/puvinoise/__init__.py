"""
Puvinoise - Independent OpenTelemetry SDK for AI agents
Supports Anthropic Claude, OpenAI, Ollama, and other LLM providers.
"""

from importlib.metadata import version as _version, PackageNotFoundError

try:
    __version__ = _version("puvinoise-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0.dev0"  # editable install before first build

from puvinoise.bootstrap import bootstrap, init, shutdown, force_flush, is_initialized
from puvinoise.tracer import run_with_trace
from puvinoise.agent_lifecycle import (
    agent_start,
    agent_step,
    tool_call,
    tool_result,
    reasoning_complete,
    task_complete,
)
from puvinoise.agent_wrapper import wrapAgent
from puvinoise.telemetry_buffer import (
    ReliableTelemetryBuffer,
    get_decision_buffer,
    set_decision_buffer,
    init_decision_buffer_from_env,
)
from puvinoise.hooks import (
    # Anthropic
    instrument_anthropic_call,
    instrument_anthropic_stream,
    # OpenAI
    instrument_openai_call,
    instrument_openai_stream,
    # Generic / Ollama
    instrument_llm_call,
    # Agent internals
    instrument_memory_operation,
    instrument_tool_call,
    # Span utilities
    add_span_attribute,
    add_span_event,
)
from puvinoise.decision_telemetry import (
    record_intent_classification,
    record_tool_candidates,
    record_reasoning_checkpoint,
    record_decision_confidence,
    record_tool_selection,
    record_tool_selection_reasoning,
    record_agent_state_transition,
    record_llm_reasoning_finished,
    record_plan_step,
    record_tool_decision_checkpoint,
    record_retry_checkpoint,
    record_fallback_checkpoint,
    record_retrieval_ranking,
    record_tool_execution_result,
    record_failure,
    set_trace_outcome,
    set_retry_attempt,
    record_outcome,
    record_task_completed,
    record_guardrail_triggered,
    flush_decision_events,
    get_dropped_event_count,
    get_telemetry_stats,
    recordIntentClassification,
    recordToolCandidates,
    recordReasoningCheckpoint,
    recordToolSelection,
    recordDecisionConfidence,
    recordAgentStateTransition,
    recordTaskCompleted,
)

__all__ = [
    "__version__",
    # Bootstrap & lifecycle
    "bootstrap",
    "init",
    "shutdown",
    "force_flush",
    "is_initialized",

    # Core tracing
    "run_with_trace",

    # Auto-instrumentation (lifecycle + wrapAgent)
    "agent_start",
    "agent_step",
    "tool_call",
    "tool_result",
    "reasoning_complete",
    "task_complete",
    "wrapAgent",

    # Reliable telemetry (buffer, retry, persistence)
    "ReliableTelemetryBuffer",
    "get_decision_buffer",
    "set_decision_buffer",
    "init_decision_buffer_from_env",

    # Anthropic hooks
    "instrument_anthropic_call",
    "instrument_anthropic_stream",

    # OpenAI hooks
    "instrument_openai_call",
    "instrument_openai_stream",

    # Generic / Ollama hooks
    "instrument_llm_call",

    # Agent internals
    "instrument_memory_operation",
    "instrument_tool_call",

    # Span utilities
    "add_span_attribute",
    "add_span_event",

    # Decision telemetry (agent decision-stage instrumentation)
    "record_intent_classification",
    "record_tool_candidates",
    "record_reasoning_checkpoint",
    "record_decision_confidence",
    "record_tool_selection",
    "record_tool_selection_reasoning",
    "record_agent_state_transition",
    "record_llm_reasoning_finished",
    "record_plan_step",
    "record_tool_decision_checkpoint",
    "record_retry_checkpoint",
    "record_fallback_checkpoint",
    "record_retrieval_ranking",
    "record_tool_execution_result",
    "record_failure",
    "set_trace_outcome",
    "set_retry_attempt",
    "record_outcome",
    "record_task_completed",
    "record_guardrail_triggered",
    "flush_decision_events",
    "get_dropped_event_count",
    "get_telemetry_stats",
    "recordIntentClassification",
    "recordToolCandidates",
    "recordReasoningCheckpoint",
    "recordToolSelection",
    "recordDecisionConfidence",
    "recordAgentStateTransition",
    "recordTaskCompleted",
]