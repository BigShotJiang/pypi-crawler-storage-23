"""Waylay Query: timeseries queries (v1 protocol) query parameters.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.
"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel


def _get_query_alias_for(field_name: str) -> str:
    return field_name


class GetQuery(WaylayBaseModel):
    """Model for `get` query parameters."""

    model_config = ConfigDict(
        protected_namespaces=(),
        extra="allow",
        alias_generator=_get_query_alias_for,
        populate_by_name=True,
    )
