"""Waylay Query: timeseries queries (v1 protocol) query parameters.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.
"""

from __future__ import annotations

from typing import Annotated

from pydantic import (
    ConfigDict,
    Field,
    StrictInt,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.execute_query_queries_v1_data_post_interpolation_parameter import (
    ExecuteQueryQueriesV1DataPostInterpolationParameter,
)
from ..models.execute_query_queries_v1_data_post_render_parameter import (
    ExecuteQueryQueriesV1DataPostRenderParameter,
)


def _execute_by_name_query_alias_for(field_name: str) -> str:
    if field_name == "resource":
        return "resource"
    if field_name == "metric":
        return "metric"
    if field_name == "aggregation":
        return "aggregation"
    if field_name == "interpolation":
        return "interpolation"
    if field_name == "freq":
        return "freq"
    if field_name == "var_from":
        return "from"
    if field_name == "until":
        return "until"
    if field_name == "window":
        return "window"
    if field_name == "periods":
        return "periods"
    if field_name == "render":
        return "render"
    return field_name


class ExecuteByNameQuery(WaylayBaseModel):
    """Model for `execute_by_name` query parameters."""

    resource: Annotated[
        StrictStr | None, Field(description="Default Resource Override.")
    ] = None
    metric: Annotated[
        StrictStr | None, Field(description="Default Metric Override.")
    ] = None
    aggregation: StrictStr | None = None
    interpolation: ExecuteQueryQueriesV1DataPostInterpolationParameter | None = None
    freq: Annotated[
        StrictStr | None,
        Field(description="Override for the `freq` query attribute."),
    ] = None
    var_from: StrictStr | None = None
    until: StrictStr | None = None
    window: StrictStr | None = None
    periods: StrictInt | None = None
    render: ExecuteQueryQueriesV1DataPostRenderParameter | None = None

    model_config = ConfigDict(
        protected_namespaces=(),
        extra="allow",
        alias_generator=_execute_by_name_query_alias_for,
        populate_by_name=True,
    )


def _execute_query_alias_for(field_name: str) -> str:
    if field_name == "resource":
        return "resource"
    if field_name == "metric":
        return "metric"
    if field_name == "aggregation":
        return "aggregation"
    if field_name == "interpolation":
        return "interpolation"
    if field_name == "freq":
        return "freq"
    if field_name == "var_from":
        return "from"
    if field_name == "until":
        return "until"
    if field_name == "window":
        return "window"
    if field_name == "periods":
        return "periods"
    if field_name == "render":
        return "render"
    return field_name


class ExecuteQuery(WaylayBaseModel):
    """Model for `execute` query parameters."""

    resource: Annotated[
        StrictStr | None, Field(description="Default Resource Override.")
    ] = None
    metric: Annotated[
        StrictStr | None, Field(description="Default Metric Override.")
    ] = None
    aggregation: StrictStr | None = None
    interpolation: ExecuteQueryQueriesV1DataPostInterpolationParameter | None = None
    freq: Annotated[
        StrictStr | None,
        Field(description="Override for the `freq` query attribute."),
    ] = None
    var_from: StrictStr | None = None
    until: StrictStr | None = None
    window: StrictStr | None = None
    periods: StrictInt | None = None
    render: ExecuteQueryQueriesV1DataPostRenderParameter | None = None

    model_config = ConfigDict(
        protected_namespaces=(),
        extra="allow",
        alias_generator=_execute_query_alias_for,
        populate_by_name=True,
    )
