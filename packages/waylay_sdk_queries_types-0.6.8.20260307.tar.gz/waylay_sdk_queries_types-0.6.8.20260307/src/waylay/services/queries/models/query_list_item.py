"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from typing import Any

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.query_hal_links import QueryHALLinks


class QueryListItem(WaylayBaseModel):
    """Listing of a query definition item.."""

    links: QueryHALLinks = Field(alias="_links")
    attrs: dict[str, Any] = Field(
        description="System provided metadata for the query definition."
    )
    name: StrictStr = Field(description="Name of the stored query definition.")
    meta: dict[str, Any] | None = Field(
        default=None, description="User metadata for the query definition."
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
