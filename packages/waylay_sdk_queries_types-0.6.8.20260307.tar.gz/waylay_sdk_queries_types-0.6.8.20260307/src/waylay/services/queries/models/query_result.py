"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.query_execution_message import QueryExecutionMessage
from ..models.query_output import QueryOutput
from ..models.response_data_set import ResponseDataSet


class QueryResult(WaylayBaseModel):
    """A json data response.  Uses the format as specified by the `render` options of the request (defaults to `COMPACT_WS`). '."""

    data: list[ResponseDataSet] = Field(
        description="A list of data sets, each with their own time axis. There will be one dataset for each `role` specified in the query (by default a single `input` role).  The data is represented according to the `render`  options in the query (default `COMPACT_WS`)."
    )
    query: QueryOutput
    messages: list[QueryExecutionMessage]

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
