"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictBool,
    StrictInt,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.alignment import Alignment
from ..models.default_aggregation1 import DefaultAggregation1
from ..models.default_interpolation1 import DefaultInterpolation1
from ..models.grouping_interval1 import GroupingInterval1
from ..models.render import Render
from ..models.series_spec import SeriesSpec
from ..models.time_window_from import TimeWindowFrom
from ..models.time_window_until import TimeWindowUntil
from ..models.window import Window


class QueryOutput(WaylayBaseModel):
    """Query definition for a Waylay analytics query.  See also [api docs](https://docs.waylay.io/#/api/query/?id=data-query-json-representation).."""

    resource: StrictStr | None = Field(
        default=None, description="Default resource for the series in the query."
    )
    metric: StrictStr | None = Field(
        default=None, description="Default metric for the series in the query."
    )
    aggregation: DefaultAggregation1 | None = None
    interpolation: DefaultInterpolation1 | None = None
    freq: GroupingInterval1 | None = None
    var_from: TimeWindowFrom | None = Field(default=None, alias="from")
    until: TimeWindowUntil | None = None
    window: Window | None = None
    periods: StrictInt | None = Field(
        default=None,
        description="The size of the time window in number of `freq` units. One of the [time line](https://docs.waylay.io/#/api/query/?id=time-line-properties) specifiers.",
    )
    align: Alignment | None = None
    data: list[SeriesSpec] | None = Field(
        default=None,
        description="List of series specifications. When not specified, a single default series specification is assumed(`[{}]`, using the default `metric`,`resource`, ... ).",
    )
    render: Render | None = None
    lookback: StrictBool | None = Field(
        default=None,
        description="If enabled, the **last-known value** for each of the series will be taken into account in the result.  For **unaggregated** series, that value will be included as is (with a timestamp before the result window). For **aggregated** series, that value will be used at the first timestamp, but only if  * no aggregated value on the first timestamp could be computed  * and the aggregation is compatible with the value, i.e. in mean, min, max, first, last, median",
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
