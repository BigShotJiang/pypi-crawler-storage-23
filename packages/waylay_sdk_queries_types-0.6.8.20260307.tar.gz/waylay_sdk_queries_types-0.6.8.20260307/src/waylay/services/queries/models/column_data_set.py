"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.column_data_set_data_axis import ColumnDataSetDataAxis
from ..models.data_set_attributes import DataSetAttributes
from ..models.data_set_window import DataSetWindow
from ..models.datum import Datum
from ..models.row_headers_inner import RowHeadersInner


class ColumnDataSet(WaylayBaseModel):
    """Column-oriented dataset with rows header.  Timeseries data layout with a rows header containing the index data. The data array contains series data prefixed by series attributes. The `rows` index is prefix by the names of these series attributes. Result for render options `data_axis=row` and `header_array=column`.."""

    attributes: DataSetAttributes | None = None
    window_spec: DataSetWindow | None = None
    data_axis: ColumnDataSetDataAxis | None = ColumnDataSetDataAxis.ROW
    rows: list[RowHeadersInner] = Field(
        description="Header Attributes for the index data.  The initial string-valued headers (normally `resource`, `metric`,`aggregation`) indicate that row to contain series attributes.  The remaining object-valued row headers contain the index data."
    )
    column_names: list[StrictStr] = Field(
        description="Short names for the columns in the data set. These names are the `name` alias if given in the series specification, otherwise is composed of the `resource`, `metric` and `aggregation` attributes, concatenated with the `render.key_separator` (default `.`) as separator."
    )
    data: list[list[Datum]] = Field(
        description="All metric observation values for a single series. Prefixed by the series attributes."
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
