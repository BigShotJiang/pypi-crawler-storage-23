"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictBool,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.data_axis_option import DataAxisOption
from ..models.execute_query_queries_v1_data_post_render_parameter import (
    ExecuteQueryQueriesV1DataPostRenderParameter,
)
from ..models.header_array_option import HeaderArrayOption
from ..models.hierarchical import Hierarchical


class Render(WaylayBaseModel):
    """Configures the representation of data sets returned by the query API.."""

    mode: ExecuteQueryQueriesV1DataPostRenderParameter | None = None
    roll_up: StrictBool | None = Field(
        default=None,
        description="move up attributes on rows (or columns) that are the same for             all rows (or columns) to a table attribute.             Levels enumerated in 'hierarchical' are excluded.",
    )
    hierarchical: Hierarchical | None = None
    value_key: StrictStr | None = Field(
        default=None,
        description="if set, use this key in the value object to report data values",
    )
    show_levels: StrictBool | None = Field(
        default=None,
        description="if set, report the levels used in the data values (either hierarchical or flat)",
    )
    iso_timestamp: StrictBool | None = Field(
        default=None,
        description="if set, render timestamps in a row or column index with both epoch and iso representations",
    )
    row_key: StrictStr | None = Field(
        default=None,
        description="if set, use this key as name of the row-dimension for single-dimensional rows",
    )
    column_key: StrictStr | None = Field(
        default=None,
        description="if set, use this key as name of the column-dimension for single-dimensional columns",
    )
    header_array: HeaderArrayOption | None = None
    data_axis: DataAxisOption | None = None
    key_seperator: StrictStr | None = Field(
        default=None,
        description="character used to concatenate multi-key columns or rows when required",
    )
    key_skip_empty: StrictBool | None = Field(
        default=None,
        description="skip empty values in concatenating multi-key column or row headers",
    )
    include_window_spec: StrictBool | None = Field(
        default=None,
        description="if set, include window specification in render modes that support it",
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
