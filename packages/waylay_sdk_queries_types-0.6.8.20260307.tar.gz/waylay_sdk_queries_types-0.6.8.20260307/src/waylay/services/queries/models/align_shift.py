"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class AlignShift(str, Enum):
    """Possible values for `align.shift`.  * 'backward': keep the window size of the original interval specification,    shifting back. * 'forward': keep the window size of the original interval specification,    shifting forward. * 'wrap': enlarge the window size to include all of the original interval.  When not specified, 'backward' is used.."""

    BACKWARD = "backward"
    FORWARD = "forward"
    WRAP = "wrap"

    def __str__(self) -> str:
        return str(self.value)
