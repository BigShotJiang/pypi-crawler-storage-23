"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel


class DataSetAttributes(WaylayBaseModel):
    """Data Set Attributes.  Data attributes that apply to all data in this set.."""

    role: StrictStr | None = Field(
        default=None,
        description="The role of series specification that was used to compile this data set.",
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
