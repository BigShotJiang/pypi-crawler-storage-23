"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.hal_link_method import HALLinkMethod


class HALLink(WaylayBaseModel):
    """A link target in a HAL response.."""

    href: StrictStr = Field(description="Target url for this link.")
    type: StrictStr | None = Field(
        default=None, description="Type of the resource referenced by this link."
    )
    method: HALLinkMethod | None = None

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
