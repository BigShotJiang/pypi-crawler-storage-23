"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.column_data_set_data_axis import ColumnDataSetDataAxis
from ..models.column_headers_inner import ColumnHeadersInner
from ..models.data_set_attributes import DataSetAttributes
from ..models.data_set_window import DataSetWindow
from ..models.datum import Datum


class SeriesDataSet(WaylayBaseModel):
    """Column-oriented dataset.  Timeseries data layout with a column header and a seperate data array for the time index and each series. Result for render options `data_axis=row` and `header_array=row`.."""

    attributes: DataSetAttributes | None = None
    window_spec: DataSetWindow | None = None
    data_axis: ColumnDataSetDataAxis | None = ColumnDataSetDataAxis.ROW
    columns: list[ColumnHeadersInner] = Field(
        description="Header Attributes for the column data.  The initial string-valued headers (normally a single `timestamp`) indicate that column to contain row index data (i.e. timestamps).  The remaining object-valued column headers identify and describe the actual series data."
    )
    column_names: list[StrictStr] = Field(
        description="Short names for the columns in the data set. These names are the `name` alias if given in the series specification, otherwise is composed of the `resource`, `metric` and `aggregation` attributes, concatenated with the `render.key_separator` (default `.`) as separator."
    )
    data: list[list[Datum]]

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
