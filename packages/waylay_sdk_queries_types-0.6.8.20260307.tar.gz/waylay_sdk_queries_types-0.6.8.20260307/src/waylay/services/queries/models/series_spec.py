"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.aggregration import Aggregration
from ..models.interpolation_specification import InterpolationSpecification


class SeriesSpec(WaylayBaseModel):
    """Query specification for a single series.."""

    name: StrictStr | None = Field(
        default=None,
        description="Optional alias name for the series. This name is used when exporting the dataset to CSV format.",
    )
    resource: StrictStr | None = Field(
        default=None,
        description="Resource id for the series, required unless it is specified as a query default.",
    )
    metric: StrictStr | None = Field(
        default=None,
        description="Metric name for the series, required unless it is specified as a query default.",
    )
    aggregration: Aggregration | None = None
    interpolation: InterpolationSpecification | None = None

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
