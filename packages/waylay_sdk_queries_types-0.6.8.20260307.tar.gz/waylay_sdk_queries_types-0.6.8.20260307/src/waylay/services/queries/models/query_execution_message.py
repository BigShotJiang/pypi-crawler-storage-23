"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from datetime import datetime

from pydantic import (
    ConfigDict,
    Field,
    StrictStr,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.cause_exception import CauseException
from ..models.message_arguments import MessageArguments
from ..models.query_execution_message_level import QueryExecutionMessageLevel


class QueryExecutionMessage(WaylayBaseModel):
    """A message object that informs or warns about a query execution issue.."""

    message: StrictStr = Field(description="A human readable message.")
    level: QueryExecutionMessageLevel
    timestamp: datetime
    action: StrictStr = Field(
        description="The request action that caused this message."
    )
    category: StrictStr = Field(description="The subsystem that issued this message.")
    properties: MessageArguments | None = None
    exception: CauseException | None = None

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
