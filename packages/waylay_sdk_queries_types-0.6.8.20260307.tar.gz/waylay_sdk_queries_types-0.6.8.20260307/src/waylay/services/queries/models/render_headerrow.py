"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class RenderHEADERROW(str, Enum):
    """Render rows of timestamp and values. Show column headers. Includes an iso timestamp.  ###### options - `iso_timestamp`: `True` - `header_array`: `row` - `roll_up`: `False` - `data_axis`: `column`."""

    HEADER_ROW = "HEADER_ROW"

    def __str__(self) -> str:
        return str(self.value)
