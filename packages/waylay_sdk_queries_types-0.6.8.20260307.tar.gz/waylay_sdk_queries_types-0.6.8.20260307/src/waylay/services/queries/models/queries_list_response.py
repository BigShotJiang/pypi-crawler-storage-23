"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
    Field,
    StrictInt,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.message import Message
from ..models.query_list_hal_links import QueryListHALLinks
from ..models.query_list_item import QueryListItem


class QueriesListResponse(WaylayBaseModel):
    """Listing of named queries, with paging links.."""

    messages: list[Message] | None = None
    queries: list[QueryListItem] = Field(
        description="One page of matching query definitions."
    )
    count: StrictInt = Field(
        description="Number of query definitions returned in the current response."
    )
    offset: StrictInt = Field(
        description="Offset in the full listing (skipped definitions)."
    )
    limit: StrictInt = Field(
        description="Maximal number of query definitions returned in one response."
    )
    total_count: StrictInt | None = Field(
        default=None,
        description="Total number of query definitions matching the filter.",
    )
    links: QueryListHALLinks = Field(alias="_links")

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
