"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from pydantic import (
    ConfigDict,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.alignment_at import AlignmentAt
from ..models.alignment_grid_interval import AlignmentGridInterval
from ..models.alignment_shift import AlignmentShift
from ..models.alignment_timezone import AlignmentTimezone


class Alignment(WaylayBaseModel):
    """Aggregation Alignment Options.  Specifies how the aggregation grid is aligned.."""

    at: AlignmentAt | None = None
    shift: AlignmentShift | None = None
    freq: AlignmentGridInterval | None = None
    timezone: AlignmentTimezone | None = None

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
