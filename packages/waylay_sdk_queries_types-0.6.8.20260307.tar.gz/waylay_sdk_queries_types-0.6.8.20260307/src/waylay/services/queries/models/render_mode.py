"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class RenderMode(str, Enum):
    """Render mode configuration keys.."""

    HEADER_ROW = "HEADER_ROW"
    COMPACT = "COMPACT"
    SERIES = "SERIES"
    HEADER_COLUMN = "HEADER_COLUMN"
    FLAT_DICT = "FLAT_DICT"
    HIER_DICT = "HIER_DICT"
    METRIC_FLAT_DICT = "METRIC_FLAT_DICT"
    UPLOAD = "UPLOAD"
    COMPACT_WS = "COMPACT_WS"
    CSV = "CSV"

    def __str__(self) -> str:
        return str(self.value)
