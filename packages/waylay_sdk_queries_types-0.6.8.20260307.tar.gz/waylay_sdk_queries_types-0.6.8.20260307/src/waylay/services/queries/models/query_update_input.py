"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from typing import Any

from pydantic import (
    ConfigDict,
    Field,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel

from ..models.query_input import QueryInput


class QueryUpdateInput(WaylayBaseModel):
    """Input data to update a query definition.."""

    meta: dict[str, Any] | None = Field(
        default=None, description="User metadata for the query definition."
    )
    query: QueryInput | None = None

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
