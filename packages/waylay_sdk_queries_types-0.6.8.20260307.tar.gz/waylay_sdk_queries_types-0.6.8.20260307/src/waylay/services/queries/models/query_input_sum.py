"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class QueryInputSum(str, Enum):
    """The sum of all values summarizes the data for the sample interval.."""

    SUM = "sum"

    def __str__(self) -> str:
        return str(self.value)
