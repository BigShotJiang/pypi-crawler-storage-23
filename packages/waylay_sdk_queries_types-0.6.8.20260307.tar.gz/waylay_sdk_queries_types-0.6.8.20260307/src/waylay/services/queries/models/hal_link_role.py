"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class HALLinkRole(str, Enum):
    """Supported link and embedding roles in HAL representations.."""

    SELF = "self"
    FIRST = "first"
    PREV = "prev"
    NEXT = "next"
    LAST = "last"
    EXECUTE = "execute"

    def __str__(self) -> str:
        return str(self.value)
