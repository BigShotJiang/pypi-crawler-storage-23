"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class ExecuteQueryQueriesV1DataPostRenderCOMPACTWS(str, Enum):
    """Render rows of timestamp and values. Show column headers. Show the time window attributes.  ###### options - `iso_timestamp`: `False` - `header_array`: `row` - `roll_up`: `False` - `data_axis`: `column` - `include_window_spec`: `True`."""

    COMPACT_WS = "COMPACT_WS"

    def __str__(self) -> str:
        return str(self.value)
