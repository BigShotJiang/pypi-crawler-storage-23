"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class QueryInputMean(str, Enum):
    """Aggregate data by the mean value: The sum of values divided by number of observations.."""

    MEAN = "mean"

    def __str__(self) -> str:
        return str(self.value)
