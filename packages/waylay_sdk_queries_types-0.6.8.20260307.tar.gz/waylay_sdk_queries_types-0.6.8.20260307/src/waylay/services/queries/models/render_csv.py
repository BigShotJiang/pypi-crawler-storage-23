"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class RenderCSV(str, Enum):
    """Render in csv format with row headers.  ###### options - `iso_timestamp`: `False`."""

    CSV = "CSV"

    def __str__(self) -> str:
        return str(self.value)
