"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from enum import Enum


class ExecuteQueryQueriesV1DataPostRenderHEADERCOLUMN(str, Enum):
    """Renders row index in `rows`, and each series as a values array.  The series are prefixed by their series attributes.The `rows` index is prefixed by the labels for these attributes.  ###### options - `iso_timestamp`: `True` - `header_array`: `column` - `roll_up`: `False` - `data_axis`: `row`."""

    HEADER_COLUMN = "HEADER_COLUMN"

    def __str__(self) -> str:
        return str(self.value)
