"""Waylay Query: timeseries queries (v1 protocol) models.

This code was generated from the OpenAPI documentation of 'Waylay Query: timeseries queries (v1 protocol)'

Do not edit the class manually.

"""

from __future__ import annotations

from datetime import datetime

from pydantic import (
    ConfigDict,
    Field,
    StrictInt,
)
from waylay.sdk.api._models import BaseModel as WaylayBaseModel


class RowHeader(WaylayBaseModel):
    """Index entry attributes.  Attributes for a timestamp index entry.."""

    timestamp: StrictInt = Field(description="Unix epoch milliseconds timestamp.")
    timestamp_iso: datetime | None = Field(
        default=None,
        description="ISO8601 rendering of the timestamp, present when `render.iso_timestamp=true`",
    )

    model_config = ConfigDict(
        populate_by_name=True, protected_namespaces=(), extra="allow"
    )
