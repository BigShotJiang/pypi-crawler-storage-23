"""Crabukit - Security scanner for OpenClaw skills."""

__version__ = "0.1.1"
