"""
命令行入口：

- sdev shell "cmd"：在串口设备上执行单条命令并回显输出。
"""

from __future__ import annotations

import argparse
import os
import sys

from .device import Demoboard
from . import remote


def _get_default_port() -> str:
    return os.environ.get("SDEV_PORT", "/dev/ttyUSB0")


def _get_default_baudrate() -> int:
    try:
        return int(os.environ.get("SDEV_BAUDRATE", "115200"))
    except ValueError:
        return 115200


def cmd_shell(args: argparse.Namespace) -> int:
    port = args.port or _get_default_port()
    baudrate = args.baudrate or _get_default_baudrate()
    with Demoboard(port, baudrate, check_alive=not args.no_check_alive) as board:
        try:
            board.shell(args.command, prompt_flag=args.flag, timeout=args.timeout)
        except TimeoutError as e:
            print(e, file=sys.stderr)
            return 1
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="sdev",
        description="串口开发板控制器：在串口设备上执行命令。",
    )
    parser.add_argument(
        "-D",
        "--port",
        default=None,
        metavar="PORT",
        help="串口设备路径（默认: SDEV_PORT 或 /dev/ttyUSB0），与 minicom -D 一致",
    )
    parser.add_argument(
        "-b",
        "--baudrate",
        type=int,
        default=None,
        help="波特率（默认: SDEV_BAUDRATE 或 115200）",
    )
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # sdev shell "cmd"
    shell_parser = subparsers.add_parser("shell", help="在板子上执行单条命令并回显输出")
    shell_parser.add_argument(
        "command",
        help='要执行的命令，如: ls 或 "lsmod | grep nnp"',
    )
    shell_parser.add_argument(
        "--flag",
        default=" #",
        help="提示符结束标志（默认: %(default)r）",
    )
    shell_parser.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="等待命令输出的超时秒数",
    )
    shell_parser.add_argument(
        "--no-check-alive",
        action="store_true",
        help="connect 后不执行 check_alive",
    )
    shell_parser.set_defaults(func=cmd_shell)

    # sdev remote <listen|add|list|get|restart|remove> ...
    remote_parser = subparsers.add_parser(
        "remote",
        help="Demoboard 远程/网络管理：listen、add/list/get、restart/remove",
    )
    remote_sub = remote_parser.add_subparsers(dest="remote_subcommand", required=True)

    listen_p = remote_sub.add_parser("listen", help="本机起 HTTP 服务与可选 mDNS，供局域网发现")
    listen_p.add_argument("--host", default="0.0.0.0", help="监听地址（默认 0.0.0.0）")
    listen_p.add_argument("--port", type=int, default=8000, help="监听端口（默认 8000）")
    listen_p.set_defaults(func=remote.cmd_remote_listen)

    add_p = remote_sub.add_parser("add", help="登记开发板并 check_alive，注入网络并更新 registry")
    add_p.add_argument(
        "port_or_all",
        nargs="?",
        default=None,
        help="串口路径如 /dev/ttyUSB0；或 all 表示扫描本机串口并逐个登记",
    )
    add_p.add_argument(
        "name",
        nargs="?",
        default=None,
        help="可选板子名称（仅单台时有效），不指定则按型号/序列自动命名",
    )
    add_p.set_defaults(func=remote.cmd_remote_add)

    list_p = remote_sub.add_parser("list", help="聚合本机与局域网 registry，列出所有已知板子及 up/down 状态")
    list_p.set_defaults(func=remote.cmd_remote_list)

    get_p = remote_sub.add_parser("get", help="按 name 或型号选一台 up 且未占用的板子，输出连接信息")
    get_p.add_argument("name_or_model", help="板子名称或型号，如 fy13")
    get_p.add_argument("--connect", action="store_true", help="分配后自动 ssh/telnet 连上")
    get_p.set_defaults(func=remote.cmd_remote_get)

    restart_p = remote_sub.add_parser("restart", help="向目标板所在宿主机发重启该板的请求")
    restart_p.add_argument("name_or_target", help="板子名称或 host:name")
    restart_p.set_defaults(func=remote.cmd_remote_restart)

    remove_p = remote_sub.add_parser("remove", help="仅从本机 registry 移除指定板子")
    remove_p.add_argument("name_or_target", nargs="?", default=None, help="板子名称或 host:name，不指定则交互或清空")
    remove_p.set_defaults(func=remote.cmd_remote_remove)

    parsed = parser.parse_args()
    return parsed.func(parsed)


if __name__ == "__main__":
    sys.exit(main())
