"""
Demoboard 顶层导出：

- Demoboard 类；函数式 API：shell, check_alive
"""

from .board import Demoboard
from .functional import check_alive, shell

__all__ = ["Demoboard", "shell", "check_alive"]
