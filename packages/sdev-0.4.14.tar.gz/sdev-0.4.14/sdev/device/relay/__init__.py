"""
Relay 顶层导出：

- Relay 类；占位函数 not_implemented。
"""

from __future__ import annotations

from ...core import SerialDevice
from .functional import not_implemented


class Relay(SerialDevice):
    """
    继电器设备：仅继承基础串口能力，不具备 Demoboard 的显示回显功能。
    """

    def __init__(self, port: str, baudrate: int = 115200, **kwargs):
        kwargs.pop("check_alive", None)
        super().__init__(port, baudrate)


__all__ = ["Relay", "not_implemented"]
