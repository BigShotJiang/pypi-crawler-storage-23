"""
设备类型：Demoboard、Relay 等串口设备封装。
"""

from .demoboard import Demoboard, check_alive, shell
from .relay import Relay, not_implemented

__all__ = ["Demoboard", "Relay", "check_alive", "shell", "not_implemented"]
