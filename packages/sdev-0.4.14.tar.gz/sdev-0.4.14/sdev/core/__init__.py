"""
串口设备核心：连接、后台按行读、发送、按 flag 扫描、清空缓存。
跨进程串口互斥：同一 port 的 connect 通过文件锁阻塞等待，依次执行。
Unix 使用 fcntl.flock，Windows 使用 msvcrt.locking。
底层类，不包含任何 UI/显示逻辑。
"""

import os
import queue
import re
import sys
import threading
import time
from typing import Generator, Iterable, Optional

from loguru import logger
import serial

if sys.platform == "win32":
    import msvcrt
else:
    import fcntl

CTRL_C = "\x03"


def _port_lock_path(port: str) -> str:
    """锁文件路径：XDG_RUNTIME_DIR/sdev 或 ~/.cache/sdev，避免 /tmp。Windows 同用用户目录。"""
    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    lock_dir = os.path.join(base, "sdev")
    os.makedirs(lock_dir, mode=0o700, exist_ok=True)
    safe = re.sub(r"[^a-zA-Z0-9_.-]", "_", os.path.basename(port))
    return os.path.join(lock_dir, f"port_{safe}.lock")


def _acquire_port_lock(port: str):
    """
    对 port 持有跨进程排他锁（阻塞直到拿到），返回打开的 fd，调用方负责 close。
    Unix: fcntl.flock；Windows: msvcrt.locking。
    """
    path = _port_lock_path(port)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    if sys.platform == "win32":
        start = time.monotonic()
        last_log = start
        while True:
            try:
                msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                break
            except OSError:
                now = time.monotonic()
                if now - last_log >= 5.0:
                    waited = now - start
                    logger.warning(
                        f"Waiting for cross-process serial lock on {port} "
                        f"for {waited:.1f} seconds..."
                    )
                    last_log = now
                time.sleep(0.1)
        return fd
    # Unix
    start = time.monotonic()
    last_log = start
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            break
        except BlockingIOError:
            now = time.monotonic()
            if now - last_log >= 5.0:
                waited = now - start
                logger.warning(
                    f"Waiting for cross-process serial lock on {port} "
                    f"for {waited:.1f} seconds..."
                )
                last_log = now
            time.sleep(0.1)
    return fd


def _release_port_lock(fd: Optional[int]) -> None:
    if fd is None:
        return
    try:
        if sys.platform == "win32":
            msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        try:
            os.close(fd)
        except OSError:
            pass


def _content_contains_ctrl_c(text: str) -> bool:
    """是否包含设备回显的 Ctrl+C。"""
    n = text.replace("\x00", "")
    return CTRL_C in n or "^C" in n


class SerialDevice:
    def __init__(self, port: str, baudrate: int = 115200):
        self.port = port
        self.baudrate = baudrate
        self._serial: Optional[serial.Serial] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._lock_fd: Optional[int] = None

        # 扫描相关通用参数
        self._scan_timeout = 0.1
        self._max_lines_per_prompt = 4
        self._silent = False

    def _serial_reader(self) -> None:
        while not self._stop_reading and self._serial is not None and self._serial.is_open:
            raw = self._serial.readline()
            if raw:
                try:
                    line = raw.decode("utf-8")
                    if line:
                        self._buffer.put(line)
                except UnicodeDecodeError:
                    continue

    def connect(self) -> None:
        if self._is_connected:
            return
        self._lock_fd = _acquire_port_lock(self.port)
        try:
            self._serial = serial.Serial(self.port, self.baudrate, timeout=self._scan_timeout)
            if not self._serial.is_open:
                raise RuntimeError(f"无法打开串口 {self.port}")
            self._stop_reading = False
            self._reader_thread = threading.Thread(target=self._serial_reader, daemon=True)
            self._reader_thread.start()
            self._is_connected = True
        except Exception:
            _release_port_lock(self._lock_fd)
            self._lock_fd = None
            raise

    def disconnect(self) -> None:
        if not self._is_connected:
            return
        self._stop_reading = True
        self._buffer.put(None)
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join()
        self._reader_thread = None
        if self._serial is not None and self._serial.is_open:
            self._serial.close()
            self._serial = None
        _release_port_lock(self._lock_fd)
        self._lock_fd = None
        self._is_connected = False

    def send(self, prompt: str) -> None:
        if not self._is_connected or self._serial is None:
            raise RuntimeError("not connected")
        assert prompt is not None
        self._serial.write((prompt + "\n").encode("utf-8"))
        self._serial.flush()

    def _scan_raw(self, timeout: Optional[float] = None) -> Generator[str, None, None]:
        if not self._is_connected:
            raise RuntimeError("not connected")
        last_activity = time.monotonic()
        scan_timeout = self._scan_timeout if timeout is not None else None

        while True:
            try:
                line = self._buffer.get(timeout=scan_timeout) if scan_timeout else self._buffer.get()
            except queue.Empty:
                if timeout is not None and time.monotonic() - last_activity > timeout:
                    raise TimeoutError("scan deadline exceeded (no response)")
                continue
            if line is None:
                return
            last_activity = time.monotonic()
            yield line

    def scan(
        self,
        end_flag: Optional[str],
        timeout: Optional[float] = None,
        replace_with_acc: bool = False,
    ) -> Generator[str, None, None]:
        if end_flag is None:
            # 简单模式：仅根据超时结束扫描，逐行返回。
            try:
                for line in self._scan_raw(timeout):
                    yield line
            except TimeoutError:
                return

        # 有 end_flag 时，根据 replace_with_acc 走两套策略：
        # - replace_with_acc=True：保留原有「多行聚合」语义，适合命令回显等场景；
        # - replace_with_acc=False：流式逐行返回，end_flag 只作「停止条件」，不做多行聚合。
        if replace_with_acc:
            acc_cache = []
            try:
                for line in self._scan_raw(timeout):
                    acc_cache.append(line)
                    if len(acc_cache) > self._max_lines_per_prompt:
                        yield acc_cache.pop(0)

                    acc_line = "".join([x.rstrip("\r\n") for x in acc_cache])
                    found = end_flag in acc_line or (end_flag == CTRL_C and _content_contains_ctrl_c(acc_line))
                    if found:
                        yield acc_line + "\n"
                        break
            except TimeoutError:
                # 超时时先把已缓存的内容输出，再把异常抛给上层做决策。
                for x in acc_cache:
                    yield x
                raise
        else:
            # 流式模式：每读到一行就立刻返回，end_flag 仅用于决定何时停止。
            for line in self._scan_raw(timeout):
                yield line
                line_clean = line.rstrip("\r\n")
                found = end_flag in line_clean or (end_flag == CTRL_C and _content_contains_ctrl_c(line_clean))
                if found:
                    break

    def clear(self) -> None:
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is None:
                    self._buffer.put(None)
                    return
            except queue.Empty:
                return

    # --- 基础日志与输出接口 (供子类扩展或 functional 使用) ---

    def silence(self) -> None:
        """执行后不再输出任何日志（info/success/warning/error 变为空操作）。"""
        self._silent = True

    def _write_raw(self, text: str) -> None:
        """底层默认不向终端输出任何内容。"""
        pass

    def _ensure_newline(self) -> None:
        """底层默认不处理换行。"""
        pass

    def info(self, msg: str) -> None:
        """底层默认仅通过 logger 记录。"""
        if self._silent:
            return
        logger.info(msg)

    def success(self, msg: str) -> None:
        if self._silent:
            return
        logger.success(msg)

    def warning(self, msg: str) -> None:
        if self._silent:
            return
        logger.warning(msg)

    def error(self, msg: str) -> None:
        if self._silent:
            return
        logger.error(msg)

    def display(self, lines: Iterable[str], **kwargs) -> Generator[str, None, None]:
        """底层默认仅 yield 数据，不进行任何回显。"""
        yield from lines

    def __enter__(self) -> "SerialDevice":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.disconnect()


__all__ = ["CTRL_C", "SerialDevice"]
