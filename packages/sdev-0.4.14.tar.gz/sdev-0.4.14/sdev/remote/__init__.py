"""
sdev remote 子命令：针对 Demoboard 的远程/网络管理。

- 所有功能均针对 Demoboard（登记、check_alive、重启、registry 等）
- 复用 sdev.device.demoboard（Demoboard、check_alive）
- 可选依赖：zeroconf（局域网发现）、registry 持久化（如 JSON，路径可配置）
- 实现层次：functional（函数）-> service（Registry、ListenServer）-> CLI（cmd_remote_*）
"""

from __future__ import annotations

import argparse
import getpass
import sys

from . import functional as F
from .service import Registry

# 兼容：顶层仍可 get_registry_path
get_registry_path = F.get_registry_path


def cmd_remote_listen(args: argparse.Namespace) -> int:
    """本机起 HTTP 服务（GET /registry、POST /restart），供局域网访问本机 Demoboard 列表与重启。"""
    host = getattr(args, "host", "0.0.0.0") or "0.0.0.0"
    port = getattr(args, "port", 8000) or 8000
    try:
        F.start_http_server(bind_host=host, bind_port=port)
    except KeyboardInterrupt:
        pass
    return 0


def cmd_remote_add(args: argparse.Namespace) -> int:
    """在本机登记 Demoboard：check_alive -> 可选 inject_network(NotImplemented) -> 更新 registry。"""
    port_or_all = getattr(args, "port_or_all", None)
    name = getattr(args, "name", None)
    registry_path = F.get_registry_path()
    if not port_or_all:
        print("请指定串口路径或 all，如: sdev remote add /dev/ttyUSB0 [name]", file=sys.stderr)
        return 1
    if port_or_all.strip().lower() == "all":
        ports = F.scan_serial_ports()
        if not ports:
            print("未发现串口设备", file=sys.stderr)
            return 1
        added = 0
        for p in ports:
            try:
                F.add_board_to_registry(registry_path, p, name=None, host="localhost")
                print(f"已登记: {p}")
                added += 1
            except RuntimeError as e:
                print(f"跳过 {p}: {e}", file=sys.stderr)
        return 0 if added else 1
    try:
        entry = F.add_board_to_registry(registry_path, port_or_all, name=name, host="localhost")
        print(f"已登记: {entry.get('name')} @ {port_or_all}")
        return 0
    except RuntimeError as e:
        print(e, file=sys.stderr)
        return 1


def cmd_remote_list(args: argparse.Namespace) -> int:
    """聚合本机与远程 Demoboard registry，标记可达性，输出表格。"""
    registry_path = F.get_registry_path()
    entries = F.aggregate_registries(registry_path)
    entries = F.mark_reachability(entries)
    # 表头
    print(f"{'host':<20} {'name':<16} {'port':<14} {'state':<6} {'ip':<16} {'owner':<10}")
    print("-" * 90)
    for e in entries:
        host = (e.get("host") or "")[:18]
        name = (e.get("name") or "")[:14]
        port = (e.get("port") or "")[:12]
        state = (e.get("state") or "?")[:5]
        ip = (e.get("ip") or "-")[:14]
        owner = (e.get("owner") or "-")[:8]
        print(f"{host:<20} {name:<16} {port:<14} {state:<6} {ip:<16} {owner:<10}")
    return 0


def cmd_remote_get(args: argparse.Namespace) -> int:
    """按 name 或型号选一台 up 且未占用的 Demoboard，输出连接信息；--connect 未实现。"""
    name_or_model = getattr(args, "name_or_model", "").strip()
    do_connect = getattr(args, "connect", False)
    registry_path = F.get_registry_path()
    entries = F.aggregate_registries(registry_path)
    entries = F.mark_reachability(entries)
    entry = F.find_available_board(entries, name_or_model)
    if not entry:
        print(f"无可用 Demoboard（name/model 匹配 {name_or_model!r} 且 state=up、owner 为空）", file=sys.stderr)
        return 1
    owner = getpass.getuser()
    # 仅对本机登记的条目写回 owner（远程条目只读，不写回）
    if (entry.get("host") or "").strip() in ("", "localhost"):
        F.mark_owner(registry_path, entry.get("host") or "localhost", entry.get("name") or "", owner)
    print(f"host={entry.get('host')} name={entry.get('name')} ip={entry.get('ip') or '-'} port_telnet={entry.get('port_telnet') or 23} owner={owner}")
    if do_connect:
        # Not implemented: 自动 ssh/telnet 连上
        print("（--connect 未实现，请手动 ssh/telnet）", file=sys.stderr)
    return 0


def cmd_remote_restart(args: argparse.Namespace) -> int:
    """向目标 Demoboard 所在宿主机发重启请求；本机则直接串口 reboot。"""
    name_or_target = getattr(args, "name_or_target", "").strip()
    if not name_or_target:
        print("请指定 name 或 host:name", file=sys.stderr)
        return 1
    registry_path = F.get_registry_path()
    entries = F.aggregate_registries(registry_path)
    # 解析 host:name 或 name
    if ":" in name_or_target:
        host, name = name_or_target.split(":", 1)
        host, name = host.strip(), name.strip()
    else:
        host, name = "localhost", name_or_target
    entry = next(
        (e for e in entries if (e.get("name") or "").strip() == name and (e.get("host") or "").strip() == host),
        None,
    )
    if not entry:
        print(f"未找到: {name_or_target}", file=sys.stderr)
        return 1
    if entry.get("_base_url"):
        ok = F.restart_board_on_host(entry["_base_url"], name)
    else:
        port = entry.get("port") or ""
        if not port:
            print("该条目无串口信息", file=sys.stderr)
            return 1
        ok = F.run_reboot_on_port(port, int(entry.get("baudrate") or 115200))
    if ok:
        print("已发送重启请求")
        return 0
    print("重启请求失败", file=sys.stderr)
    return 1


def cmd_remote_remove(args: argparse.Namespace) -> int:
    """仅改本地 registry：移除指定 Demoboard；不指定则清空本机列表。"""
    name_or_target = getattr(args, "name_or_target", None)
    registry_path = F.get_registry_path()
    if name_or_target is None or (isinstance(name_or_target, str) and not name_or_target.strip()):
        # 交互或清空：此处简化为直接清空本机
        remaining = F.remove_boards_from_registry(registry_path, None)
        print(f"已清空本机登记，剩余 {len(remaining)} 条")
        return 0
    remaining = F.remove_boards_from_registry(registry_path, name_or_target)
    print(f"已移除，当前本机共 {len(remaining)} 条")
    return 0
