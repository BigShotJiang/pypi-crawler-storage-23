"""
remote 服务层（针对 Demoboard）：Registry 类与 ListenServer 聚合。

- Registry：Demoboard 条目的 load/save、增删查；
- ListenServer：GET /registry、POST /restart，供局域网访问本机 Demoboard 列表与重启。
"""

from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any, List, Optional

from . import functional as F


class Registry:
    """本地 Demoboard registry 的封装：路径、加载、保存、增删查。"""

    def __init__(self, path: Optional[str] = None):
        self.path = path or F.get_registry_path()

    def load(self) -> List[dict[str, Any]]:
        return F.load_registry(self.path)

    def save(self, entries: List[dict[str, Any]]) -> None:
        F.save_registry(self.path, entries)

    def add_entry(self, entry: dict[str, Any]) -> None:
        entries = self.load()
        entries.append(entry)
        self.save(entries)

    def remove_by_name_or_target(self, name_or_target: Optional[str]) -> List[dict[str, Any]]:
        return F.remove_boards_from_registry(self.path, name_or_target)

    def find_by_name(self, name: str, host: Optional[str] = None) -> Optional[dict[str, Any]]:
        entries = self.load()
        for e in entries:
            if (e.get("name") or "").strip() != name.strip():
                continue
            if host is not None and (e.get("host") or "").strip() != host.strip():
                continue
            return e
        return None


class _RemoteRequestHandler(BaseHTTPRequestHandler):
    """HTTP 请求处理：GET /registry、POST /restart。"""

    def log_message(self, format: str, *args: Any) -> None:
        pass  # 可改为 loguru 等

    def _registry_path(self) -> str:
        return getattr(self.server, "registry_path", "")

    def do_GET(self) -> None:
        if self.path.rstrip("/") == "/registry":
            entries = F.load_registry(self._registry_path())
            body = json.dumps(entries, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self) -> None:
        if self.path.rstrip("/") == "/restart":
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length).decode("utf-8") if length else "{}"
            try:
                data = json.loads(raw)
                name = (data.get("name") or "").strip()
            except json.JSONDecodeError:
                name = ""
            if not name:
                self.send_response(400)
                self.end_headers()
                return
            entries = F.load_registry(self._registry_path())
            entry = next((e for e in entries if (e.get("name") or "").strip() == name), None)
            if not entry:
                self.send_response(404)
                self.end_headers()
                return
            port = entry.get("port") or ""
            if not port:
                self.send_response(500)
                self.end_headers()
                return
            ok = F.run_reboot_on_port(port, int(entry.get("baudrate") or 115200))
            self.send_response(200 if ok else 500)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.end_headers()
            self.wfile.write(json.dumps({"ok": ok}).encode("utf-8"))
        else:
            self.send_response(404)
            self.end_headers()


class ListenServer(HTTPServer):
    """HTTP 服务：绑定 host:port，提供 GET /registry、POST /restart（针对本机 Demoboard）。"""

    def __init__(
        self,
        registry_path: str,
        host: str = "0.0.0.0",
        port: int = 8000,
    ) -> None:
        super().__init__((host, port), _RemoteRequestHandler)
        self.registry_path = registry_path

    def serve_forever(self, poll_interval: float = 0.5) -> None:
        super().serve_forever(poll_interval)
