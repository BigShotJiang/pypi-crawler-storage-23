"""
remote 高层功能（函数式 API），所有功能均针对 Demoboard：

- registry：load/save、聚合本机与远程；
- 串口扫描（跨平台）、check_alive（Demoboard）、网络注入（NotImplemented）；
- HTTP 拉取远程 registry、可达性检测；
- 供 service 与 CLI 调用。
"""

from __future__ import annotations

import json
import os
import socket
import sys
from datetime import datetime, timezone
from typing import Any, List, Optional
from urllib.error import URLError
from urllib.request import Request, urlopen

# 跨平台串口列举
try:
    import serial.tools.list_ports
except ImportError:
    serial = None  # type: ignore

# Registry 单条记录：host, name, port(串口), model_or_serial, ip, port_telnet, owner, state, updated
BoardEntry = dict[str, Any]


def get_registry_path() -> str:
    """Registry 持久化路径，可通过环境变量 SDEV_REMOTE_REGISTRY 配置。跨平台。"""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    default = os.path.join(base, "sdev", "remote_registry.json")
    return os.environ.get("SDEV_REMOTE_REGISTRY", default)


def load_registry(path: str) -> List[BoardEntry]:
    """从 JSON 文件加载 registry，文件不存在或空则返回 []。"""
    if not os.path.isfile(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return []
    if not isinstance(data, list):
        return []
    return data


def save_registry(path: str, entries: List[BoardEntry]) -> None:
    """将 registry 写入 JSON 文件。"""
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def scan_serial_ports() -> List[str]:
    """跨平台列举串口（Linux /dev/ttyUSB*, ttyACM*；Windows COM*）。返回设备路径列表。"""
    if serial is None:
        return []
    ports = []
    for p in serial.tools.list_ports.comports():
        ports.append(p.device)
    return sorted(ports)


def check_alive_for_port(port: str, baudrate: int = 115200) -> bool:
    """对指定串口上的 Demoboard 执行 check_alive；成功返回 True，失败返回 False。"""
    from ..device.demoboard import Demoboard

    try:
        with Demoboard(port, baudrate, check_alive=False) as board:
            board.check_alive(block=False, timeout=1.5)
        return True
    except Exception:
        return False


def get_board_name_from_serial(port: str, baudrate: int = 115200) -> str:
    """从 Demoboard 串口读取型号/序列等信息用于自动命名。未实现则返回 port basename。"""
    # Not implemented: 从 cpuinfo/serial 解析
    return os.path.basename(port).replace(os.sep, "_")


def inject_network(port: str, name: str, baudrate: int = 115200) -> dict[str, Any]:
    """
    在 Demoboard 上注入网络（MAC + DHCP + telnetd 等），返回 { "ip": str, "port_telnet": int }。
    未实现则返回空 dict。
    """
    # Not implemented
    return {}


def add_board_to_registry(
    registry_path: str,
    port: str,
    name: Optional[str] = None,
    baudrate: int = 115200,
    host: str = "localhost",
) -> BoardEntry:
    """
    在本机登记一块 Demoboard：check_alive -> 可选 inject_network -> 追加 registry。
    返回新加入的 entry；若 check_alive 失败则抛出 RuntimeError。
    """
    if not check_alive_for_port(port, baudrate):
        raise RuntimeError(f"check_alive 失败: {port}")
    display_name = name or get_board_name_from_serial(port, baudrate)
    extra = inject_network(port, display_name, baudrate)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    entry: BoardEntry = {
        "host": host,
        "name": display_name,
        "port": port,
        "baudrate": baudrate,
        "model_or_serial": "",
        "ip": extra.get("ip", ""),
        "port_telnet": int(extra.get("port_telnet", 23)),
        "owner": "",
        "state": "unknown",
        "updated": now,
    }
    entries = load_registry(registry_path)
    entries.append(entry)
    save_registry(registry_path, entries)
    return entry


def get_known_remote_hosts() -> List[str]:
    """从环境变量 SDEV_REMOTE_HOSTS 读取已知远程主机列表，格式 host:port，如 '192.168.1.10:8000,host2:8000'。"""
    raw = os.environ.get("SDEV_REMOTE_HOSTS", "")
    if not raw.strip():
        return []
    return [s.strip() for s in raw.split(",") if s.strip()]


def fetch_remote_registry(base_url: str, timeout: float = 3.0) -> List[BoardEntry]:
    """GET base_url/registry，返回 JSON 列表。base_url 不含路径，如 http://192.168.1.10:8000。"""
    url = base_url.rstrip("/") + "/registry"
    try:
        req = Request(url, method="GET")
        with urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except (URLError, OSError, json.JSONDecodeError):
        return []
    if not isinstance(data, list):
        return []
    return data


def check_reachable(host: str, port: int, timeout: float = 2.0) -> bool:
    """TCP 可达性检测，跨平台。"""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            pass
        return True
    except (OSError, socket.error):
        return False


def aggregate_registries(
    local_path: str,
    remote_base_urls: Optional[List[str]] = None,
    timeout: float = 3.0,
) -> List[BoardEntry]:
    """聚合本机与远程 Demoboard registry；远程未指定时用 SDEV_REMOTE_HOSTS。"""
    remote_base_urls = remote_base_urls or get_known_remote_hosts()
    # 归一化：SDEV_REMOTE_HOSTS 可能是 "host:port"，需加 scheme
    urls = []
    for h in remote_base_urls:
        if "://" in h:
            urls.append(h)
        else:
            urls.append("http://" + h)
    out: List[BoardEntry] = list(load_registry(local_path))
    seen = {(e.get("host"), e.get("name")) for e in out}
    for base_url in urls:
        for e in fetch_remote_registry(base_url, timeout):
            key = (e.get("host"), e.get("name"))
            if key not in seen:
                seen.add(key)
                e["_base_url"] = base_url  # 供 restart 向该主机发请求
                out.append(e)
    return out


def mark_reachability(entries: List[BoardEntry], timeout: float = 2.0) -> List[BoardEntry]:
    """对每条 Demoboard entry 根据 ip + port_telnet 检测可达性，写入 state: up/down。原地修改并返回。"""
    for e in entries:
        ip = e.get("ip") or ""
        port_telnet = int(e.get("port_telnet") or 23)
        if ip and port_telnet:
            e["state"] = "up" if check_reachable(ip, port_telnet, timeout) else "down"
        else:
            e["state"] = "down"
    return entries


def find_available_board(
    entries: List[BoardEntry],
    name_or_model: str,
) -> Optional[BoardEntry]:
    """按 name 或 model_or_serial 匹配 Demoboard，返回 state=up 且 owner 为空的第一个；否则 None。"""
    name_or_model = name_or_model.strip().lower()
    for e in entries:
        if e.get("state") != "up":
            continue
        if e.get("owner"):
            continue
        if name_or_model in (e.get("name") or "").lower():
            return e
        if name_or_model in (e.get("model_or_serial") or "").lower():
            return e
    return None


def mark_owner(registry_path: str, host: str, name: str, owner: str) -> None:
    """在本地 registry 中将 host+name 对应条目的 owner 设为 owner。仅改本地文件。"""
    entries = load_registry(registry_path)
    for e in entries:
        if (e.get("host") or "").strip() == host and (e.get("name") or "").strip() == name:
            e["owner"] = owner
            break
    save_registry(registry_path, entries)


def run_reboot_on_port(port: str, baudrate: int = 115200) -> bool:
    """在指定串口的 Demoboard 上发送 reboot。供本机 listen 服务收到 /restart 时调用。"""
    try:
        from ..device.demoboard import Demoboard

        with Demoboard(port, baudrate, check_alive=False) as board:
            board.send("reboot")
        return True
    except Exception:
        return False


def restart_board_on_host(
    base_url: str,
    target_name: str,
    timeout: float = 5.0,
) -> bool:
    """向宿主机 base_url 发 POST /restart（重启该机上的 Demoboard）。返回是否成功。"""
    url = base_url.rstrip("/") + "/restart"
    try:
        data = json.dumps({"name": target_name}).encode("utf-8")
        req = Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        with urlopen(req, timeout=timeout) as resp:
            return 200 <= getattr(resp, "status", 200) < 300
    except (URLError, OSError):
        return False


def remove_boards_from_registry(
    registry_path: str,
    name_or_target: Optional[str],
) -> List[BoardEntry]:
    """
    从本地 registry 移除匹配的 Demoboard 条目。
    name_or_target 可为 name 或 host:name；None 表示清空本机所有。
    返回删除后的新列表（已写回文件）。
    """
    entries = load_registry(registry_path)
    if not name_or_target or not name_or_target.strip():
        # 清空本机
        new_entries = [e for e in entries if (e.get("host") or "").strip() not in ("", "localhost")]
        save_registry(registry_path, new_entries)
        return new_entries
    target = name_or_target.strip()
    if ":" in target:
        host, name = target.split(":", 1)
        host, name = host.strip(), name.strip()
    else:
        host, name = "localhost", target
    new_entries = [
        e
        for e in entries
        if not (
            ((e.get("host") or "").strip() == host and (e.get("name") or "").strip() == name)
            or (e.get("name") or "").strip() == name and (e.get("host") or "").strip() in ("", "localhost")
        )
    ]
    save_registry(registry_path, new_entries)
    return new_entries


def start_http_server(bind_host: str = "0.0.0.0", bind_port: int = 8000) -> None:
    """
    启动 HTTP 服务（GET /registry、POST /restart），阻塞直到 Ctrl+C。
    跨平台。mDNS 注册未实现。
    """
    from .service import ListenServer

    server = ListenServer(registry_path=get_registry_path(), host=bind_host, port=bind_port)
    server.serve_forever()
