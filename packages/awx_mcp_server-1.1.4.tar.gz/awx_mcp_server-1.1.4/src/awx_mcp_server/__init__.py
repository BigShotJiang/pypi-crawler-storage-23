"""AWX MCP Remote Server."""

__version__ = "1.0.0"
