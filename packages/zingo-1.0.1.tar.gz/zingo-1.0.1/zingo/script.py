import logging
from argparse import ArgumentParser

from . import commands, device_proxy, parse_mysql_date


def main(args=None):
    parser = ArgumentParser(
        description=(
            "Zingo is a commandline program for interacting with a a Tango control system."
        )
    )
    parser.add_argument("-j", "--json", action="store_true", help="Output as JSON")
    parser.add_argument(
        "-r", "--raw", action="store_true", help="No fancy formatting, headers, etc."
    )
    parser.add_argument(
        "--header", "-e", action="store_true", help="Print header in 'raw' mode."
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true", help="Output extra logging info."
    )
    parser.add_argument(
        "--debug", "-d", action="store_true", help="Enable debug logging."
    )

    subparsers = parser.add_subparsers()

    # Servers
    server = subparsers.add_parser("srv", help="List servers")
    server.add_argument("server", nargs="?")
    server.add_argument("-l", "--list", action="store_true")
    server.add_argument("--host", help="Restrict server list to a host")
    server.add_argument(
        "--ping",
        action="store_true",
        help="Exit with error if any matching server is not running",
    )
    server.set_defaults(func=commands.srv)

    # Host
    host = subparsers.add_parser("host", help="List hosts")
    host.add_argument("host", nargs="?", help="Host pattern")
    host.add_argument("-l", "--list", action="store_true", help="Only list host names.")
    host.set_defaults(func=commands.host)

    # Class
    clss = subparsers.add_parser("cls", help="List classes")
    clss.add_argument("clss", nargs="?")
    clss.add_argument(
        "-l", "--list", action="store_true", help="Only list class names."
    )
    clss.set_defaults(func=commands.cls)

    # Device
    device = subparsers.add_parser("dev", help="List devices.")
    device.add_argument("device", nargs="*", type=str, help="Device name or pattern.")
    device.add_argument(
        "-s", "--server", type=str, help="Server instance name or pattern."
    )
    device.add_argument(
        "-c", "--class", dest="clss", type=str, help="Device class name or pattern."
    )
    device.add_argument("-a", "--alias", type=str, help="Device alias")
    device.add_argument("--host", type=str, help="Hostname of the device server")
    device.add_argument(
        "--dservers", action="store_true", help="Include DServer devices"
    )
    device.add_argument(
        "-d",
        "--details",
        action="store_true",
        help="Show further information about each device.",
    )
    device.add_argument(
        "-r", "--read", action="store_true", help="Try to read State of each device."
    )
    grp = device.add_mutually_exclusive_group()
    grp.add_argument(
        "-l", "--list", action="store_true", help="Only list device names."
    )
    grp.add_argument(
        "-b",
        "--db-only",
        action="store_true",
        help="Just list info from DB, don't try to connect to the devices",
    )
    device.set_defaults(func=commands.dev)

    # Subdevices
    subdev = subparsers.add_parser(
        "subdev", help="List subdevices of the given device."
    )
    subdev.add_argument("device", nargs="*", type=str, help="Device name")
    subdev.add_argument(
        "-r",
        "--reverse",
        action="store_true",
        help="Find devices that have the given device as subdevice.",
    )
    subdev.set_defaults(func=commands.subdev)

    # Attributes
    attr = subparsers.add_parser("attr", help="List device attributes.")
    attr.add_argument("device_or_attribute", nargs="+")
    attr.add_argument("-a", "--attribute", action="append", type=str)
    attr.add_argument("-d", "--details", action="store_true")
    attr.add_argument("-c", "--config", action="store_true")
    attr.add_argument("-e", "--event", action="store_true")
    attr.add_argument("-p", "--polling", action="store_true")
    attr.add_argument("-l", "--limits", action="store_true")
    attr.set_defaults(func=commands.attr)

    # Read attributes
    read = subparsers.add_parser("read", help="Read device attributes.")
    read.add_argument(
        "device_or_attribute", nargs="+", help="Device or full attribute name."
    )
    read.add_argument(
        "-a",
        "--attribute",
        action="append",
        type=str,
        default=[],
        help="Attribute name",
    )
    read.add_argument(
        "-c",
        "--continuous",
        action="store_true",
        help="Keep reading periodically until break.",
    )
    read.add_argument(
        "-p",
        "--period",
        type=float,
        default=3.0,
        help=(
            "Period for continous reading, in seconds."
            " Does not apply if the attribute sends change events."
        ),
    )
    read.add_argument(
        "-v", "--value", action="store_true", help="Just print out the value(s)"
    )
    read.add_argument("-f", "--force-polling", action="store_true")
    read.add_argument("-b", "--bypass-cache", action="store_true")
    read.add_argument(
        "-e",
        "--event",
        default="change",
        choices=["change", "archive"],
        help="Configure which event type to subscribe to",
    )
    read.set_defaults(func=commands.read)

    # Commands
    cmd = subparsers.add_parser("cmd", help="Run a command")
    cmd.add_argument("device", nargs="+", type=device_proxy)
    grp = cmd.add_mutually_exclusive_group()
    grp.add_argument(
        "-c",
        "--command",
        type=str,
        help="Name of a command to run on the given devices",
    )
    grp.add_argument(
        "-l", "--list", action="store_true", help="Just list all available commands"
    )
    grp = cmd.add_mutually_exclusive_group()
    grp.add_argument(
        "-a",
        "--argument",
        type=str,
        action="append",
        help=(
            "Argument to the command."
            " Can be given several times for multiple arguments."
        ),
    )
    grp.add_argument(
        "-p",
        "--polling",
        action="store_true",
        help="Show polling information for the command",
    )
    cmd.set_defaults(func=commands.cmd)

    # Properties
    prop = subparsers.add_parser("prop", help="Handle device properties")
    prop.add_argument("device", nargs="*", type=str)
    prop.add_argument("-p", "--property", action="append", type=str)
    prop.add_argument(
        "-i",
        "--history",
        action="store_true",
        help="Show latest changes to the properties.",
    )
    grp = prop.add_mutually_exclusive_group()
    # grp.add_argument("--write", type=str,
    #                  help="Write a value to all the given properties. Use '-' to read from stdin.")
    # grp.add_argument("--delete", action="store_true",
    #                  help="Remove the properties.")
    grp.add_argument(
        "-l",
        "--list",
        action="store_true",
        default=True,
        help="List the names of all existing properties",
    )
    grp.add_argument(
        "-s", "--search", type=str, help="Search property values for a given string."
    )
    prop.add_argument(
        "--before", type=parse_mysql_date, help="Restrict history to earlier times"
    )
    prop.add_argument(
        "--after", type=parse_mysql_date, help="Restrict history to later times"
    )
    prop.set_defaults(func=commands.prop)

    # Attribute properties
    attr_prop = subparsers.add_parser(
        "attrprop", help="Handle device attribute properties"
    )
    attr_prop.add_argument("device", nargs="+", type=str)
    attr_prop.add_argument(
        "-a", "--attribute", action="append", type=str, help="Attribute name"
    )
    attr_prop.add_argument("-p", "--property", action="append", type=str)
    attr_prop.add_argument(
        "-i",
        "--history",
        action="store_true",
        help="Show latest changes to the properties.",
    )
    attr_prop.add_argument(
        "-l",
        "--list",
        action="store_true",
        default=True,
        help="List the names of all existing properties",
    )
    attr_prop.add_argument(
        "-s", "--search", type=str, help="Search property values for a given string."
    )
    attr_prop.add_argument(
        "--before", type=parse_mysql_date, help="Restrict history to earlier times"
    )
    attr_prop.add_argument(
        "--after", type=parse_mysql_date, help="Restrict history to later times"
    )
    attr_prop.set_defaults(func=commands.attr_prop)

    # Logging
    log = subparsers.add_parser(
        "log", help="Read logging from devices (caution, experimental)"
    )
    log.add_argument("device", nargs="+")
    grp = log.add_mutually_exclusive_group()
    grp.add_argument(
        "-s",
        "--show",
        action="store_true",
        help="Just show the current logging settings",
    )
    grp.add_argument(
        "--level",
        "-l",
        type=int,
        default=3,
        help="Log level to use. 1=FATAL, 2=ERROR, 3=WARNING, 4=INFO, 5=DEBUG",
    )
    log.add_argument(
        "--host", type=str, help="Host address to use. If not given, will try to guess."
    )
    log.add_argument(
        "--port",
        type=int,
        help="Port number to use. If not given, will pick a free port.",
    )
    log.set_defaults(func=commands.log)

    # Black box
    bbox = subparsers.add_parser(
        "bbox", help="Read 'black box' information from device(s)"
    )
    bbox.add_argument("device", nargs="+")
    grp = bbox.add_mutually_exclusive_group()
    grp.add_argument(
        "-s",
        "--statistics",
        action="store_true",
        help="Keep querying periodically and present statistics after break",
    )
    grp.add_argument(
        "-t",
        "--tail",
        action="store_true",
        help="Query periodically and print events as they arrive.",
    )
    bbox.add_argument(
        "-p",
        "--period",
        type=float,
        default=1,
        help="Pause between queries, in seconds (for statistics/tail mode)",
    )
    bbox.add_argument(
        "-e",
        "--events",
        type=int,
        default=1000,
        help="Number of black box events to request.",
    )

    bbox.set_defaults(func=commands.bbox)

    args = parser.parse_args(args)

    if args.verbose:
        logging.basicConfig(level=logging.INFO)
    if args.debug:
        logging.basicConfig(level=logging.DEBUG)

    if hasattr(args, "func"):
        args.func(args)
    else:
        print(parser.format_help())
