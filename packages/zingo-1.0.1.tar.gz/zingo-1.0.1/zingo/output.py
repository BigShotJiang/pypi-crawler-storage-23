import json
import sys
from datetime import datetime
from itertools import zip_longest
from numbers import Number

import tango

try:
    import rich
except ImportError:
    rich = None


def format_value(v, rich=False):
    """Format a value for output"""
    if v is None:
        return ""
    elif isinstance(v, tango.TimeVal):
        if rich:
            return v.todatetime()
        return v.isoformat()
    elif isinstance(v, tango.DevFailed):
        v = v.args[0].desc
    elif isinstance(v, tango._tango.DevState):
        # TODO could do fancy things with color here, if rich
        return str(v)
    elif isinstance(v, tango._tango.AttrQuality):
        # TODO same here
        return str(v)
    elif isinstance(v, datetime):
        if not rich:
            return v.isoformat()
    if isinstance(v, str):
        if not rich:
            return v.strip().replace("\n", "\\n")
    if not rich:
        return str(v)
    return v


def pad_list(lst, n, value):
    """Pad the given list to length n, with value"""
    ll = len(lst)
    if ll >= n:
        # List is already long enough
        return lst
    return list(lst) + [value] * (n - ll)


def output(headings, rows, raw=False, as_json=False, always_header=False):
    """Print the given data, formatted depending on the situation"""
    if as_json:
        data = [{key: value for key, value in zip(headings, row)} for row in rows]
        if raw:
            # Print out in NDJSON fashion; one JSON object per line
            for row in data:
                print(json.dumps(row, default=str), flush=True)
        else:
            # Print out as one big JSON array
            print(json.dumps(data, indent=4, default=str), flush=True)
        return

    if sys.stdout.isatty() and not raw:
        # Try to show something more human friendly
        if rich:
            # If "rich" is installed, let's get really friendly!
            formatted_rows = [[format_value(v, rich=True) for v in row] for row in rows]
            rich_output(headings, formatted_rows)
        else:
            # Expand columns with whitespace so that they line up
            formatted_rows = [[format_value(v) for v in row] for row in rows]
            max_widths = [
                max(len(str(x)) + 2 for x in col)
                for col in zip_longest(headings, *formatted_rows, fillvalue="")
            ]
            row_format = "".join(f"{{: <{w}}}" for w in max_widths)
            # if always_header:
            print(row_format.format(*headings))
            nheadings = len(headings)
            for row in formatted_rows:
                print(row_format.format(*pad_list(row, nheadings, "")), flush=True)
        return

    # Output seems to be intended for computers, use simple formatting
    if always_header:
        print("\t".join(headings))

    row_format = "\t".join("{}" for _ in headings)
    nheadings = len(headings)
    for row in rows:
        print(
            row_format.format(*(format_value(v) for v in pad_list(row, nheadings, ""))),
            flush=True,
        )


def rich_format_value(v):
    from rich.pretty import Pretty

    if isinstance(v, str):
        return f"{v}"
    elif isinstance(v, datetime):
        return f"[green]{v.isoformat()}"
    return Pretty(v)


def rich_output(headings, rows):
    from rich.console import Console
    from rich.table import Table

    console = Console()

    table = Table(show_header=True, header_style="bold magenta")
    if rows:
        formatted_rows = [[str(v) for v in row] for row in rows]
        max_widths = [
            max(len(str(x)) for x in col)
            for col in zip_longest(headings, *formatted_rows, fillvalue="")
        ]
        for i, (heading, value) in enumerate(zip_longest(headings, rows[0])):
            justify = "right" if isinstance(value, Number) else "left"
            table.add_column(
                heading, justify=justify, min_width=max_widths[i], overflow="fold"
            )
        for row in formatted_rows:
            table.add_row(*row)
    else:
        for heading in headings:
            table.add_column(heading)

    console.print(table)


def log_line(timestamp, level, device, thread, message, as_json=False, raw=False):
    output(
        ["time", "level", "device", "thread", "message"],
        [(timestamp, level, device, thread, message)],
        as_json=as_json,
        raw=True,
        always_header=False,
    )


def bbox_line(timestamp, device, message, as_json=False, raw=True):
    output(
        ["time", "device", "message"],
        [(timestamp, device, message)],
        as_json=as_json,
        raw=True,
    )


if rich:
    from rich.console import Console
    from rich.text import Text

    console = Console()

    level_style = {
        "DEBUG": "blue",
        "ERROR": "red",
        "WARN": "yellow bold",
        "INFO": "green bold",
    }

    def rich_log_line(
        timestamp, level, device, thread, message, as_json=False, raw=False
    ):
        if as_json or raw:
            _log_line(
                timestamp, level, device, thread, message, as_json=as_json, raw=raw
            )
            return
        console.print(
            Text(timestamp, style="green"),
            Text(level, style=level_style.get(level)),
            Text(device, style="white bold"),
            Text(thread, style="black bold"),
            Text(message),
            soft_wrap=True,
            sep="\t",
        )

    _log_line = log_line
    log_line = rich_log_line

    def rich_bbox_line(timestamp, device, message, as_json=False, raw=False):
        if as_json or raw:
            _bbox_line(timestamp, device, message, as_json=as_json, raw=raw)
            return
        console.print(
            Text(timestamp, style="green"),
            Text(device, style="white bold"),
            message,
            soft_wrap=True,
            sep="\t",
        )

    _bbox_line = bbox_line
    bbox_line = rich_bbox_line
