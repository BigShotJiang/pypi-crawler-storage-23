"""
Implementations of the main commands
"""

import asyncio
import logging
import re
import socket
import struct
import sys
from collections import Counter
from datetime import datetime
from itertools import groupby, product
from operator import itemgetter
from time import monotonic, sleep

import tango
from tango.asyncio import DeviceProxy
from tango.test_context import parse_ior

from . import (
    consume,
    device_proxy,
    format_setting,
    nwise,
    parse_mysql_date,
    parse_polling_status,
    track_attribute,
)
from .log import device_logs, find_free_port
from .output import bbox_line, format_value, log_line, output


def srv(args):
    """Servers"""

    db = tango.Database()

    filters = []
    if args.server:
        filters.append(f"server REGEXP '^{args.server}$'")
    if args.host:
        filters.append(f"host REGEXP '^{args.host}$'")
    filter_ = f"WHERE {' AND '.join(filters)}" if filters else ""

    _, results = db.command_inout(
        "DbMySqlSelect",
        f"""
    SELECT server, host, started, stopped, count(*) FROM device
    {filter_}
    GROUP BY server
    """,
    )

    headers = ["server", "host", "started", "stopped", "n_devices"]
    rows = list(map(tuple, nwise(results, len(headers))))
    if args.list:
        for srv, *_ in rows:
            print(srv)
        return
    if args.ping:
        if not rows:
            logging.warning("No matching servers")
            return
        ping_rows = []
        any_bad_ping = False
        for srv, *_ in rows:
            try:
                result = device_proxy(f"DServer/{srv}").ping()
                ping_rows.append((srv, result))
            except tango.DevFailed:
                ping_rows.append((srv, None))
                any_bad_ping = True
        output(
            ["server", "ping_us"],
            ping_rows,
            raw=args.raw,
            as_json=args.json,
            always_header=args.header,
        )
        if any_bad_ping:
            logging.info("Some servers did not respond.")
            sys.exit(1)
        return
    if not rows:
        logging.info("No matches")
        sys.exit(1)
    output(headers, rows, raw=args.raw, as_json=args.json, always_header=args.header)


def host(args):
    """Hosts"""

    db = tango.Database()

    if args.host:
        _, results = db.command_inout(
            "DbMySqlSelect",
            f"""
        SELECT host, count(server) FROM device
        WHERE host REGEXP '^{args.host}$'
        GROUP BY host
        """,
        )
    else:
        _, results = db.command_inout(
            "DbMySqlSelect",
            """
        SELECT host, count(server) FROM device
        GROUP BY host
        """,
        )

    headers = ["host", "n_servers"]
    rows = [(host, int(n)) for host, n in nwise(results, len(headers))]
    if not rows:
        logging.info("No matches")
        sys.exit(1)
    if args.list:
        for host, *_ in rows:
            print(host)
        return
    output(headers, rows, raw=args.raw, as_json=args.json, always_header=args.header)


def cls(args):
    """Classes"""

    db = tango.Database()
    if args.clss:
        _, results = db.command_inout(
            "DbMySqlSelect",
            f"""
        SELECT class, count(name) FROM device
        WHERE class REGEXP '^{args.clss}$'
        GROUP BY class
        """,
        )
    else:
        _, results = db.command_inout(
            "DbMySqlSelect",
            """
        SELECT class, count(name) FROM device
        GROUP BY class
        """,
        )
    headers = ["class", "n_devices"]
    rows = [
        (cls, int(n_devices)) for cls, n_devices in zip(results[::2], results[1::2])
    ]
    if not rows:
        logging.info("No matches")
        sys.exit(1)
    if args.list:
        for clss, *_ in rows:
            print(clss)
        return
    output(headers, rows, raw=args.raw, as_json=args.json, always_header=args.header)


def _expand_devices(
    patterns, clss=None, server=None, host=None, alias=None, include_dservers=False
):
    """
    Take a list of regex patterns, and return a list of device
    names matching any of the patterns.
    Note that an empty list of patterns matches everything!
    """
    # assert patterns, "You give at least one device pattern!"
    db = tango.Database()
    # TODO limit number of patterns? Maybe split across several queries if
    # the list becomes too long?
    patterned = []
    unpatterned = []
    for p in patterns:
        if re.escape(p) != p:
            patterned.append(p)
        else:
            unpatterned.append(p)
    logging.debug(
        "all: %r, patterns: %r, non-patterns: %r", patterns, patterned, unpatterned
    )
    # Build a single query to find all matching devices and get all available
    # info about them. This should be a lot more efficient than doing lots of
    # small queries... I hope.
    # TODO benchmark?
    query = """
    SELECT name, alias, class, server, host, exported, ior, pid, started, stopped
    FROM device
    WHERE """
    if patterned or unpatterned:
        query += "("
        if patterned:
            regexes = "$|^".join(f"{d}" for d in patterned)
            query += f"name REGEXP '^{regexes}$' OR alias REGEXP '^{regexes}$'"
        if unpatterned:
            if patterned:
                query += " OR "
            tmp = ", ".join(f"'{d}'" for d in unpatterned)
            query += f"name in ({tmp}) or alias in ({tmp})"
        query += ")\n"
    qualifiers = []
    if server:
        qualifiers.append(f"server REGEXP '^{server}$'")
    if clss:
        qualifiers.append(f"class REGEXP '^{clss}$'")
    if host:
        qualifiers.append(f"host REGEXP '^{host}$'\n")
    if alias:
        qualifiers.append(f"alias REGEXP '^{alias}$'")
    if not include_dservers:
        qualifiers.append("class != 'DServer'")
    if qualifiers:
        if patterned or unpatterned:
            query += " AND "
        query += " AND ".join(qualifiers)
    query += "\n ORDER BY name, class, server"
    logging.debug("Query: %s", query)
    t0 = monotonic()
    _, matches = db.command_inout("DbMySqlSelect", query)
    logging.debug("Query took %f s", monotonic() - t0)
    # The result comes as one big flat list of strings, here we fold it back
    # into a list of lists, each corresponding to one row.
    return list(nwise(matches, 10))


async def _make_proxy_and_read(device, attributes):
    logging.debug("reading attributes %r on %r", attributes, device)
    p = await DeviceProxy(device)
    p.set_timeout_millis(1000)
    try:
        result = await p.read_attributes(attributes)
    except tango.DevFailed:
        logging.exception("Failed to read attributes %r on %r", attributes, device)
        raise
    return result


def _read_attributes(devices, attributes):
    group = tango.Group("read")
    for dev in devices:
        group.add(dev)
    replies = group.read_attributes(attributes)
    for device, reply in zip(devices, replies):
        if reply.has_failed():
            errors = reply.get_err_stack()
            logging.info(
                "Failed to read %r on %r: %s", attributes, device, errors[0].desc
            )
            yield tango.DevFailed(*errors)
        else:
            yield reply.get_data()


def dev(args):
    """Devices"""

    devices = _expand_devices(
        args.device,
        server=args.server,
        clss=args.clss,
        host=args.host,
        alias=args.alias,
        include_dservers=args.dservers,
    )
    if not devices:
        sys.exit("Sorry, no matching devices were found!")
    if args.list:
        for device, *_ in devices:
            print(device)
        return
    if not args.read:
        states = (None for dev in devices)
    else:
        devnames = [d[0] for d in devices]
        states = _read_attributes(devnames, ["State"])
    rows = []
    for result, reply in zip(devices, states):
        read_error = None
        if isinstance(reply, tango.DevFailed):
            state = ""
            read_error = reply
        elif reply is None:
            state = ""
        else:
            state = reply.value
        name, alias, clss, server, host, exported, ior, pid, started, stopped = result
        row = [
            name,
            clss,
            server,
            host if host != "nada" else "",
            alias or "",
        ]
        if args.read:
            row.append(state)

        if args.details:
            try:
                ior = parse_ior(ior)
                port = ior.port
            except (AssertionError, struct.error):
                port = ""
            except tango.DevFailed:
                port = None
            row.extend(
                [
                    port,
                    parse_mysql_date(started) if started else "",
                    parse_mysql_date(stopped) if stopped else "",
                    read_error if read_error else "",
                ]
            )
        rows.append(row)
    headings = ["name", "class", "instance", "host", "alias"]
    if args.read:
        headings.append("state")
    if args.details:
        headings.extend(["port", "started", "stopped", "error"])
    output(headings, rows, raw=args.raw, as_json=args.json, always_header=args.header)


SUBDEV_QUERY = """
SELECT device, value, updated FROM property_device
WHERE name = '__SubDevices' AND device REGEXP '^{}$'
ORDER BY updated
"""

SUBDEV_REVERSE_QUERY = """
SELECT device, value, updated FROM property_device
WHERE name = '__SubDevices' AND value REGEXP '^{}$'
ORDER BY updated
"""


def subdev(args):
    """Subdevices"""
    db = tango.Database()
    rows = []
    for device in args.device:
        # The __SubDevice property should tell us what other devices a device has talked to
        if args.reverse:
            # Do a backwards check; find devices that have talked to the given device
            query = SUBDEV_REVERSE_QUERY.format(device)
            logging.debug("Query: %r", query)
            result = db.command_inout("DbMySqlSelect", query)[1]
            for dev, subdev, updated in nwise(result, 3):
                rows.append(
                    (dev, subdev, datetime.strptime(updated, "%Y-%m-%d %H:%M:%S"))
                )
        else:
            query = SUBDEV_QUERY.format(device)
            logging.debug("Query: %r", query)
            result = db.command_inout("DbMySqlSelect", query)[1]
            for dev, subdev, updated in nwise(result, 3):
                rows.append(
                    (dev, subdev, datetime.strptime(updated, "%Y-%m-%d %H:%M:%S"))
                )
        headings = ["device", "subdevice", "updated"]
    if not rows:
        logging.info("No matching (sub)devices found")
        sys.exit(1)
    output(headings, rows, raw=args.raw, as_json=args.json, always_header=args.header)


_DEVICE_PATTERN = "(tango://.*/)?[^/]+/[^/]+/[^/]+$"
_ATTRIBUTE_PATTERN = "(tango://.*)?[^/]+/[^/]+/[^/]+/[^/]+$"


def _collect_attributes(devices_or_attributes, attributes):
    # TODO too clever? I feel maybe it's better to not allow patterns
    # for these functions, and instead encourage using "dev" to do the
    # filtering, and piping to xargs for the rest? Easier to inspect what
    # the result will be that way, especially important for commands.

    # The user may give any combination of device names, "full" attribute names
    # (e.g. sys/tg_test/1/ampli) or loose attribute names (-a ampli) which will
    # apply to device names. Here we try to untangle...
    devices = []
    full_attrs = []
    for da in devices_or_attributes:
        if len(da.split("/")) in {1, 3}:  # Device names and aliases
            devices.append(da.lower())
        elif len(da.split("/")) in {2, 4}:
            full_attrs.append(da.lower())
        else:
            raise RuntimeError(
                f"Sorry, {da} looks like neither a device/alias name or a full attribute."
            )
    attrs = [tuple(a.rsplit("/", 1)) for a in full_attrs]
    if attributes:
        attrs += [
            tuple(a)
            for a in product((d for d, *_ in _expand_devices(devices)), attributes)
        ]
    attrs = set(attrs)
    # attrs should now be a bunch of unique device, attribute pairs
    return devices, attrs


def attr(args):
    """Attributes"""

    # It's possible to give any combination of stuff here, e.g.
    # - sys/tg_test/1 -a ampli
    # - sys/tg_test/1/ampli
    # - myalias -a state
    # - myalias/state
    # Etc, and several of these.
    # Attribute names given with -a apply to all devices given
    attrs_per_dev = {}
    for dev_or_attr in args.device_or_attribute:
        # TODO use _collect_attributes
        n_parts = len(dev_or_attr.split("/"))
        if n_parts in {1, 3}:  # Plain name or alias
            for device, *_ in _expand_devices([dev_or_attr]):
                attrs_per_dev[device] = set()
        elif n_parts in {2, 4}:  # (device or alias)/attribute
            device, attribute = dev_or_attr.rsplit("/", 1)
            attrs_per_dev.setdefault(device, set()).add(attribute)
        else:
            sys.exit(
                f"Sorry, {dev_or_attr} looks like neither a device/alias name or a full attribute."
            )

    for dev, attrs in attrs_per_dev.items():
        if args.attribute:
            attrs.update(args.attribute)
        # No attribute names given, assume the user wants to list all attributes
        if not attrs:
            try:
                proxy = device_proxy(dev)
                for attr in proxy.attribute_list_query():
                    attrs_per_dev[dev].add(attr.name)
            except tango.DevFailed as e:
                logging.error(f"Could not list attributes for device {dev}: {str(e)}")

    headers = ["device", "attribute"]
    DETAILS_HEADERS = {
        "data_type": lambda v: tango.CmdArgType.values[v],
        "data_format": str,
        "writable": str,
    }
    CONFIG_HEADERS = ["label", "unit", "description", "format"]
    LIMITS_HEADERS = [
        "max_value",
        "min_value",
        "max_alarm",
        "min_alarm",
        "max_dim_x",
        "max_dim_y",
    ]
    CHANGE_EVENTS_HEADERS = ["rel_change", "abs_change"]
    PERIODIC_EVENTS_HEADERS = ["period"]
    ARCHIVE_EVENTS_HEADERS = [
        "archive_rel_change",
        "archive_abs_change",
        "archive_period",
    ]
    EVENTS_HEADERS = (
        CHANGE_EVENTS_HEADERS + PERIODIC_EVENTS_HEADERS + ARCHIVE_EVENTS_HEADERS
    )
    POLLING_HEADERS = [
        "polling_period",
        "last_poll_duration",
        "last_poll_delta",
        "last_error",
    ]
    # Build headers
    if args.details:
        headers.extend(DETAILS_HEADERS)
    if args.config:
        headers.extend(CONFIG_HEADERS)
    if args.limits:
        headers.extend(LIMITS_HEADERS)
    if args.event:
        headers.extend(EVENTS_HEADERS)
    if args.polling:
        headers.extend(POLLING_HEADERS)

    rows = []

    for dev, attrs in attrs_per_dev.items():
        try:
            proxy = device_proxy(dev)
            device_name = proxy.name()
            # TODO this will not work at all if it contains attributes that don't
            # exist on the device... maybe OK, as this is a weird case?
            confs = proxy.get_attribute_config_ex(list(attrs))
            columns = [[device_name] * len(attrs), [c.name for c in confs]]
        except tango.DevFailed as e:
            logging.error("Couldn't get attribute info from %r: %s", dev, str(e))
            continue

        # Add columns depending on user flags
        if args.details:
            cols = zip(
                *(
                    [fmt(getattr(conf, hdr)) for hdr, fmt in DETAILS_HEADERS.items()]
                    for attr, conf in zip(attrs, confs)
                )
            )
            columns.extend(cols)

        if args.config:
            columns.extend(
                zip(
                    *(
                        [str(getattr(conf, hdr)) for hdr in CONFIG_HEADERS]
                        for attr, conf in zip(attrs, confs)
                    )
                )
            )
        if args.limits:
            columns.extend(
                zip(
                    *(
                        [format_setting(getattr(conf, hdr)) for hdr in LIMITS_HEADERS]
                        for attr, conf in zip(attrs, confs)
                    )
                )
            )
        if args.event:
            columns.extend(
                zip(
                    *(
                        [
                            format_setting(value)
                            for value in [
                                getattr(conf.events.ch_event, hdr)
                                for hdr in CHANGE_EVENTS_HEADERS
                            ]
                            + [
                                getattr(conf.events.per_event, hdr)
                                for hdr in PERIODIC_EVENTS_HEADERS
                            ]
                            + [
                                getattr(conf.events.arch_event, hdr)
                                for hdr in ARCHIVE_EVENTS_HEADERS
                            ]
                        ]
                        for attr, conf in zip(attrs, confs)
                    )
                )
            )
        if args.polling:
            polling_statuses = {}
            try:
                for s in proxy.polling_status():
                    try:
                        attr, polling_status = parse_polling_status(s)
                        polling_statuses[attr] = polling_status
                    except Exception as e:
                        logging.warning(f"Failed to parse polling status {s}: {e}")
                        continue
            except tango.DevFailed as e:
                logging.error("Couldn't get polling status for %r: %s", dev, str(e))

            empty = [""] * 4
            columns.extend(
                zip(*(polling_statuses.get(attr.lower(), empty) for attr in attrs))
            )

        # Turn columns into rows
        rows.extend(zip(*columns))

    output(
        headers,
        sorted(rows),
        raw=args.raw,
        as_json=args.json,
        always_header=args.header,
    )


def read(args):
    """Reading attributes"""

    try:
        devices, attrs = _collect_attributes(args.device_or_attribute, args.attribute)
    except RuntimeError as e:
        sys.exit(str(e))

    if not attrs:
        if not devices and args.attribute:
            sys.exit("Seems like your regex(es) matched no devices.")
        sys.exit("No attributes given!")

    if args.continuous:
        # Read until interrupted, e.g by Ctrl-c. Uses events if possible, otherwise
        # reads periodically.

        def attr_value_printer(device, source, data):
            # TODO refactor output to consume an async generator?
            flush = True
            if isinstance(data, tango.DeviceAttribute):
                print(
                    "\t".join(
                        format_value(v)
                        for v in [
                            device,
                            data.name,
                            data.time,
                            data.value,
                            data.quality,
                            None,
                        ]
                    ),
                    flush=flush,
                )
            elif isinstance(data, tango.DevError):
                print(
                    "\t".join(
                        format_value(v) for v in [device, None, None, None, None, data]
                    ),
                    flush=flush,
                )
            elif isinstance(data, tango.DevFailed):
                print(
                    "\t".join(
                        format_value(v)
                        for v in [
                            device,
                            None,
                            None,
                            None,
                            None,
                            data.args[-1].desc.splitlines(),
                        ]
                    ),
                    flush=flush,
                )

        event_type = getattr(tango.EventType, f"{args.event.upper()}_EVENT")
        task = consume(
            [
                track_attribute(
                    f"{dev}/{attr}",
                    poll_period=args.period,
                    force_polling=args.force_polling,
                    bypass_cache=args.bypass_cache,
                    event_type=event_type,
                )
                for dev, attr in attrs
            ],
            attr_value_printer,
        )
        try:
            asyncio.run(task)
        except KeyboardInterrupt:
            pass
    else:
        # Just read once
        # For effiency, we read all attributes concurrently, per device

        async def read_attrs(dev, attrs_):
            dev = dev.lower()
            try:
                proxy = await DeviceProxy(dev)
                return (dev, attrs_, await proxy.read_attributes(attrs_))
            except tango.DevFailed as e:
                return dev, attrs_, e

        async def read_all(dev_attrs_):
            return await asyncio.gather(
                *(read_attrs(dev, attrs_) for dev, attrs_ in dev_attrs_)
            )

        # Transform into a seq of devices, with a list of attributes for each
        dev_attrs = (
            (dev, [a for _, a in as_])
            for dev, as_ in groupby(sorted(attrs), itemgetter(0))
        )

        replies = asyncio.run(read_all(dev_attrs))
        rows = []
        for dev, attrs, results in replies:
            if isinstance(results, tango.DevFailed):
                # Entire read failed
                for attr in attrs:
                    rows.append([dev, attr, "", "", results])
                continue
            for attr, result in zip(attrs, results):
                # Try to format various result types... needs work
                if result.has_failed:
                    # This attribute failed to read, show error
                    ex = tango.DevFailed(*result.get_err_stack())
                    rows.append([dev, attr, "", "", ex])
                elif result.data_format == tango.AttrDataFormat.SPECTRUM:
                    for value in result.value or []:  # Handle None
                        rows.append([dev, result.name, value, result.quality])
                elif isinstance(result.value, str):
                    # TODO is this really how we should handle multiline strings?
                    for value in result.value.splitlines():
                        rows.append([dev, result.name, value, result.quality])
                else:
                    rows.append([dev, result.name, result.value, result.quality])
        if args.value:
            for _, result in zip(attr, results):
                print(result.value)
        else:
            headers = ["device", "attribute", "value", "quality", "error"]
            output(
                headers,
                rows,
                raw=args.raw,
                as_json=args.json,
                always_header=args.header,
            )


def cmd(args):
    """Commands"""

    if args.list:
        rows = []
        if args.command:
            for proxy in args.device:
                info = proxy.get_command_config(args.command)
                row = (
                    proxy.name(),
                    info.cmd_name,
                    info.in_type,
                    info.in_type_desc,
                    info.out_type,
                    info.out_type_desc,
                )
                rows.append(row)
        else:
            for proxy, _ in product(args.device, [args.command]):
                cmd_infos = proxy.get_command_config()
                dev = proxy.name()
                for info in cmd_infos:
                    row = (
                        dev,
                        info.cmd_name,
                        info.in_type,
                        info.in_type_desc,
                        info.out_type,
                        info.out_type_desc,
                    )
                    rows.append(row)

        headers = (
            "device",
            "command",
            "in_type",
            "in_type_desc",
            "out_type",
            "out_type_desc",
        )
        output(
            headers, rows, raw=args.raw, as_json=args.json, always_header=args.header
        )
        return

    cmd = args.command
    assert cmd, "You must provide a command name!"
    results = []
    if args.polling:
        results = []
        for proxy in args.device:
            period = proxy.get_command_poll_period(args.command)
            results.append((proxy.name(), args.command, period))
        output(
            ["device", "command", "polling_period"], results, always_header=args.header
        )
    else:
        # TODO make async
        for proxy in args.device:
            dev = proxy.name()
            if args.argument and len(args.argument) == 1:
                arguments = args.argument[0]
            else:
                arguments = args.argument
            try:
                result = proxy.command_inout(cmd, arguments)
            except tango.DevFailed as e:
                results.append([dev, cmd, arguments, None, None, e.args[0].desc])
            else:
                if result is None:
                    results.append([dev, cmd, arguments or None])
                elif isinstance(result, (list, tuple)):
                    for i, value in enumerate(result):
                        results.append([dev, cmd, arguments, i, value])
                elif isinstance(result, str):
                    for i, line in enumerate(result.splitlines()):
                        results.append([dev, cmd, arguments, i, line])
                else:
                    raise NotImplementedError(
                        f"Sorry, no support for results of type {type(result)} yet!"
                    )

        output(
            ["device", "command", "arguments", "line", "value", "error"],
            results,
            raw=args.raw,
            as_json=args.json,
            always_header=args.header,
        )


def prop(args):
    """Properties"""

    db = tango.Database()
    devices = "|".join(f"^{dev}$" for dev in args.device)
    if args.search:
        # Search for the given string (may be a regex) in any property
        # of the given devices (which could also contain regex).
        # Note: we don't support aliases here. We might match them too
        # but I think the risk of false positives might be too high...
        query = f"""
        SELECT device, name, count, value, updated
        FROM property_device
        WHERE device REGEXP '{devices}'
        AND value REGEXP '^{args.search}$'
        """
        if args.property:
            props = "|".join(f"^{prop}$" for prop in args.property)
            query += f"AND name REGEXP '{props}'\n"
        query += "ORDER BY device, name\n"
        logging.debug("Query: %r", query)
        try:
            result = db.command_inout("DbMySqlSelect", query)[1]
        except tango.DevFailed as e:
            sys.exit(e.args[0].desc)
        if not result:
            logging.info("Query returned no matching properties")
            sys.exit(1)
        headers = ["device", "property", "line", "value", "updated"]
        output(
            headers,
            nwise(result, len(headers)),
            as_json=args.json,
            raw=args.raw,
            always_header=args.header,
        )
    else:
        # TODO probably faster to leave out the name match instead of this?
        headers = ["Device", "Property", "Line", "Value", "Timestamp"]
        if args.history:
            query = f"""
            SELECT device, name, count, value, date FROM property_device_hist
            WHERE device REGEXP '^{devices}$'
            """
            if args.property:
                props = "|".join(args.property)
                query += f"AND name REGEXP '^{props}$'\n"
            if args.before:
                query += f"AND date < '{args.before.isoformat()}'\n"
            if args.after:
                query += f"AND date >= '{args.after.isoformat()}'\n"
            query += "ORDER BY date, device, name, count"
        else:
            # Note: we don't support aliases here. We might match them too
            # but I think the risk of false positives might be too high...
            query = f"""
            SELECT device, name, count, value, updated FROM property_device
            WHERE device REGEXP '^{devices}$'
            """
            if args.property:
                props = "|".join(args.property)
                query += f"AND name REGEXP '^{props}$'\n"
            query += "ORDER BY device, name, count"
        try:
            db = tango.Database()
            result = db.command_inout("DbMySqlSelect", query)[1]
        except tango.DevFailed as e:
            logging.exception("Error running query")
            sys.exit(e.args[0].desc)
        rows = (
            (dev, prop, int(line), value, parse_mysql_date(t))
            for dev, prop, line, value, t in nwise(result, len(headers))
        )
        output(
            headers, rows, raw=args.raw, as_json=args.json, always_header=args.header
        )


def attr_prop(args):
    """Attribute properties"""

    db = tango.Database()
    if args.search:
        # Search for the given string (may be a regex) in any property
        # of the given devices (which could also contain regex).
        devices = "|".join(f"^{dev}$" for dev in args.device)
        query = f"""
        SELECT device, attribute, name, count, value, updated
        FROM property_attribute_device
        WHERE device REGEXP '{devices}'
        AND value REGEXP '^{args.search}$'
        """
        if args.attribute:
            attrs = "|".join(f"^{attr}$" for prop in args.attribute)
            query += f"AND attribute REGEXP '{attrs}'"
        if args.property:
            props = "|".join(f"^{prop}$" for prop in args.property)
            query += f"AND property REGEXP '{props}'"
        query += "ORDER BY device, attribute, name"

        logging.debug("Query: %r", query)
        try:
            result = db.command_inout("DbMySqlSelect", query)[1]
        except tango.DevFailed as e:
            sys.exit(e.args[0].desc)
        if not result:
            logging.info("Query returned no matching properties")
            sys.exit(1)
        headers = ["device", "property", "line", "value", "updated"]
        output(
            headers,
            nwise(result, len(headers)),
            as_json=args.json,
            raw=args.raw,
            always_header=args.header,
        )
    else:
        # TODO probably faster to leave out the name match instead of this?
        headers = ["Device", "Attribute", "Property", "Line", "Value", "Timestamp"]
        devices = "|".join(f"^{dev}$" for dev in args.device)
        if args.history:
            query = f"""
            SELECT device, attribute, name, count, value, date FROM property_attribute_device_hist
            WHERE device REGEXP '{devices}'
            """
            if args.attribute:
                attrs = "|".join(args.attribute)
                query += f"AND attribute REGEXP '^{attrs}$'\n"
            if args.property:
                props = "|".join(args.property)
                query += f"AND name REGEXP '^{props}$'\n"
            if args.before:
                query += f"AND date < '{args.before.isoformat()}'\n"
            if args.after:
                query += f"AND date >= '{args.after.isoformat()}'\n"
            query += "ORDER BY date, device, attribute, name, count"
        else:
            query = f"""
            SELECT device, attribute, name, count, value, updated FROM property_attribute_device
            WHERE device REGEXP '{devices}'
            """
            if args.attribute:
                attrs = "|".join(args.attribute)
                query += f"AND attribute REGEXP '^{attrs}$'\n"
            if args.property:
                props = "|".join(args.property)
                query += f"AND name REGEXP '^{props}$'\n"
            query += "ORDER BY device, attribute, name, count"
        try:
            result = db.command_inout("DbMySqlSelect", query)[1]
        except tango.DevFailed as e:
            logging.exception("Error running query")
            sys.exit(e.args[0].desc)
        rows = (
            (dev, attr, prop, int(line), value, parse_mysql_date(t))
            for dev, attr, prop, line, value, t in nwise(result, len(headers))
        )
        output(
            headers, rows, raw=args.raw, as_json=args.json, always_header=args.header
        )


LOGGING_LEVELS = ["OFF", "FATAL", "ERROR", "WARN", "INFO", "DEBUG"]


def log(args):
    """Device logs"""

    devices = [d for d, *_ in _expand_devices(args.device)]
    if args.show:
        results = []
        for device in devices:
            proxy = tango.DeviceProxy(device)
            try:
                logging_level = proxy.get_logging_level()
            except tango.DevFailed as e:
                logging.warning("Could not connect to %d: %s", device, e)
                continue
            logging_targets = proxy.get_logging_target()
            results.append(
                (device, LOGGING_LEVELS[logging_level], ", ".join(logging_targets))
            )
        headers = ["device", "logging_level", "logging_targets"]
        output(
            headers, results, as_json=args.json, raw=args.raw, always_header=args.header
        )
        return
    elif args.level:
        host = args.host or socket.gethostbyname(socket.gethostname())
        port = args.port or find_free_port()
        log_gen = device_logs(devices, args.level, host, port)
        headers = ["time", "level", "device", "thread", "message"]

        for t, level, device, thread, message in log_gen:
            # TODO handle multiline messages; now we truncate at first linebreak
            try:
                log_line(
                    t.isoformat(), level, device, thread, message, as_json=args.json
                )
            except BrokenPipeError:
                break


BBOX_TIMESTAMP = "%d/%m/%Y %H:%M:%S:%f"


def _parse_black_box(line):
    timestamp, rest = line.split(" : ")
    return datetime.strptime(timestamp, BBOX_TIMESTAMP), rest


def bbox(args):
    """
    Black box
    This is a built in feature of Tango, that gives access to a list of client
    actions performed on a given device, such as attribute reads, commands...
    as well as some info about the client.
    Tango only keeps the 50 latest ones.
    """

    proxies = [
        (d.lower(), tango.DeviceProxy(d)) for d, *_ in _expand_devices(args.device)
    ]

    if args.statistics:
        print(
            f"Collecting statistics every {args.period} s, Ctrl-C to stop and print results",
            file=sys.stderr,
            end="",
            flush=True,
        )
        try:
            t0 = datetime.now()
            # Periodically collect black box info and save unique lines
            calls = []
            latest_times = {}
            while True:
                sleep(args.period)
                for devname, proxy in proxies:
                    t1 = latest_times.get(devname, t0)
                    lines = proxy.black_box(args.events)
                    n_new_lines = 0
                    for line in reversed(lines):
                        t, msg = _parse_black_box(line)
                        if t > t1:
                            # We're only interested in new lines
                            calls.append((t, devname, msg))
                            n_new_lines += 1
                    if n_new_lines == len(lines):
                        # All lines were new; maybe we missed some too
                        logging.warning(
                            "Gap in time stamps; you may be missing events! Try decreasing the period?"
                        )
                    latest_times[devname] = t
        except KeyboardInterrupt:
            # Print statistics
            t1 = datetime.now()
            dt = (t1 - t0).total_seconds()
            print()
            counter = Counter((dev, msg) for _, dev, msg in calls)
            headers = ["num", "freq", "device", "message"]
            output(
                headers,
                [(n, n / dt, *args) for args, n in counter.most_common()],
                as_json=args.json,
                raw=args.raw,
                always_header=args.header,
            )

    elif args.tail:
        latest_events = {}
        try:
            headers = ["time", "device", "message"]
            while True:
                events = []
                for dev, proxy in proxies:
                    lines = proxy.black_box(args.events)
                    t0 = latest_events.get(dev)
                    if t0 and lines:
                        t, _ = _parse_black_box(lines[-1])
                        if t > t0:
                            logging.warning(
                                "No overlap; possibly missed some calls! Try shorter period?"
                            )
                    for line in reversed(lines):
                        t, msg = _parse_black_box(line)
                        if t0 is None or t > t0:
                            events.append((t, dev, msg))
                            latest_events[dev] = t
                for t, dev, msg in sorted(events):
                    bbox_line(t.isoformat(), dev, msg, as_json=args.json, raw=args.raw)
                sleep(args.period)
        except KeyboardInterrupt:
            pass

    else:
        events = []
        for dev, proxy in proxies:
            for line in proxy.black_box(args.events):
                t, msg = _parse_black_box(line)
                events.append((t.isoformat(), dev, msg))
        headers = ["time", "device", "message"]
        output(
            headers,
            sorted(events),
            as_json=args.json,
            raw=args.raw,
            always_header=args.header,
        )
