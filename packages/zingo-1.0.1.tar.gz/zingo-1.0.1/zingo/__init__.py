"""
Various things used by other parts.
"""

import asyncio
import logging
import re
from datetime import datetime
from functools import lru_cache
from itertools import islice
from time import time

import tango
from tango.asyncio import AttributeProxy


@lru_cache(1)
def get_database() -> tango.Database:
    return tango.Database()


@lru_cache(None)
def device_proxy(d):
    return tango.DeviceProxy(d)


class merge_async_generators:
    """
    Combine several async generators into one that yields items as they arrive.
    Implementation from https://stackoverflow.com/a/51403277
    """

    def __init__(self, *iterables):
        self._iterables = list(iterables)
        self._wakeup = asyncio.Event()

    def _add_iters(self, next_futs, on_done):
        for it in self._iterables:
            it = it.__aiter__()
            nfut = asyncio.ensure_future(it.__anext__())
            nfut.add_done_callback(on_done)
            next_futs[nfut] = it
        del self._iterables[:]
        return next_futs

    async def __aiter__(self):
        done = {}
        next_futs = {}

        def on_done(nfut):
            done[nfut] = next_futs.pop(nfut)
            self._wakeup.set()

        self._add_iters(next_futs, on_done)
        try:
            while next_futs:
                await self._wakeup.wait()
                self._wakeup.clear()
                for nfut, it in done.items():
                    try:
                        ret = nfut.result()
                    except StopAsyncIteration:
                        continue
                    self._iterables.append(it)
                    yield ret
                done.clear()
                if self._iterables:
                    self._add_iters(next_futs, on_done)
        finally:
            # if the generator exits with an exception, or if the caller stops
            # iterating, make sure our callbacks are removed
            for nfut in next_futs:
                nfut.remove_done_callback(on_done)

    def append_iter(self, new_iter):
        self._iterables.append(new_iter)
        self._wakeup.set()


SOURCE_EVENT = 0
SOURCE_POLL = 1
SOURCE_ERROR = 99


async def subscribe_attribute(attribute_proxy, event_type=tango.EventType.CHANGE_EVENT):
    """
    Async generator.
    Try to subscribe to the attribute and generate attribute values
    as long as we don't get any errors.
    """
    queue = asyncio.Queue()
    loop = asyncio.get_running_loop()

    def on_change(event):
        asyncio.run_coroutine_threadsafe(queue.put(event), loop)

    try:
        sub = await attribute_proxy.subscribe_event(event_type, on_change)
    except tango.DevFailed:
        logging.debug(
            "Failed to subscribe to %s on attribute %r", event_type, attribute_proxy
        )
        return
    logging.debug("Subscribed to %s on attribute %r", event_type, attribute_proxy)
    while True:
        event_data = await queue.get()
        if event_data.err:
            # Guess we're not getting events anymore, maybe polling stopped
            # logging.error("Event error: %s", str(event_data.errors[0].desc))
            yield SOURCE_EVENT, event_data.errors
            await attribute_proxy.unsubscribe_event(sub)
            return
        else:
            yield SOURCE_EVENT, event_data.attr_value


async def poll_attribute(proxy, period, timeout):
    """
    Async generator.
    Periodically polls attribute, generating attribute values,
    until the specified timeout has passed.
    """
    t0 = time()
    logging.debug("Starting to poll attribute %r", proxy)
    while True:
        try:
            attr = await proxy.read()
        except tango.DevFailed as e:
            yield SOURCE_POLL, e
            # logging.error("Error reading attribute %r: %s",
            #               attribute_proxy, e.args[0].desc)
        else:
            yield SOURCE_POLL, attr
        await asyncio.sleep(period)
        if time() - t0 > timeout:
            # Done
            break


async def track_attribute(
    attribute,
    poll_period=3.0,
    sub_retry_period=10,
    force_polling=False,
    bypass_cache=False,
    event_type=tango.EventType.CHANGE_EVENT,
):
    """
    Async generator, tracking an attribute if possible by subscribing,
    or else by polling at the specified period.
    """
    proxy = await AttributeProxy(attribute)
    try:
        dev = proxy.get_device_proxy().name()
    except tango.DevFailed as e:
        logging.error("Could not connect to %s: %s", proxy, e.args[-1].desc)
        return
    if bypass_cache:
        dev.set_source(tango.DevSource.DEV)
    while True:
        if not force_polling:
            async for source, data in subscribe_attribute(proxy, event_type):
                if source == SOURCE_EVENT:
                    yield dev, source, data
        async for source, data in poll_attribute(proxy, poll_period, sub_retry_period):
            yield dev, source, data


async def consume(generators, function=print):
    async for item in merge_async_generators(*generators):
        function(*item)


DATE_RE = r"(\d{1,2})\w\w (\w+) (\d\d\d\d) at (\d\d):(\d\d):(\d\d)"
MONTH_NAMES = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
]


def parse_device_date(s):
    """
    Parse a date on the format Tango uses for server start/stop
    E.g. "11th October 2021 at 20:08:50"
    TODO Not sure how consistent this is.
    """
    m = re.match(DATE_RE, s)
    if m:
        day = int(m.group(1))
        month = MONTH_NAMES.index(m.group(2)) + 1
        year = int(m.group(3))
        hour = int(m.group(4))
        minute = int(m.group(5))
        second = int(m.group(6))
        return datetime(year, month, day, hour, minute, second)


def format_setting(value):
    if value == "Not specified":
        return ""
    return str(value)


def parse_polling_status(value):
    """Parse the string output from polling_status()"""
    polling_status = value.splitlines()
    if len(polling_status) == 4:
        attr, poll_period, ring_buffer, last_error = polling_status
        return (
            attr.rsplit("=", 1)[-1].strip().lower(),
            [
                poll_period.rsplit("=")[-1].strip(),
                last_error.rsplit("=")[-1].rstrip() if last_error else None,
            ],
        )
    else:
        attr, poll_period, _, last_dur, _, last_delta, *last_error = polling_status
        return (
            attr.rsplit("=", 1)[-1].strip().lower(),
            [
                poll_period.rsplit("=")[-1].rstrip(),
                last_dur.rsplit("=")[-1].rstrip(),
                last_delta.rsplit("=")[-1].rstrip(),
                last_error[0].rsplit("=")[-1].rstrip() if last_error else None,
            ],
        )


def parse_mysql_date(d):
    # Date format: "2022-10-23 11:13:29"
    if hasattr(datetime, "fromisoformat"):
        # Python > 3.6 has this built in
        return datetime.fromisoformat(d)
    try:
        return datetime.strptime(d, "%Y-%m-%d %H:%M:%S")
    except ValueError:
        pass
    return datetime.strptime(d, "%Y-%m-%d")


def nwise(it, n):
    # [s_0, s_1, ...] => [(s_0, ..., s_(n-1)), (s_n, ... s_(2n-1)), ...]
    return zip(*[islice(it, i, None, n) for i in range(n)])
