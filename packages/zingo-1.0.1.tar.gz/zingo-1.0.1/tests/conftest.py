import time
from multiprocessing import Process

import pytest
import tango
from tango.server import Device, attribute


class ZingoTest(Device):
    @attribute
    def SomeAttr(self):
        return 17


def make_server_fixture(server, devices):
    """Return a pytest fixture providing a Tango device server."""

    def fixture(session_pytango_db):
        db = tango.Database()
        devinfos = []
        devclasses = set()
        for device, config in devices.items():
            devinfo = tango.DbDevInfo()
            devinfo.name = device
            devinfo._class = config["class"].__name__
            devinfo.server = server
            devinfos.append(devinfo)
            devclasses.add(config["class"])
        db.add_server(devinfo.server, devinfos, with_dserver=True)
        for device, config in devices.items():
            props = config.get("properties")
            if props:
                db.put_device_property(device, props)
        proc = Process(
            target=tango.server.run,
            kwargs={"classes": tuple(devclasses), "args": server.split("/")},
            daemon=False,
        )
        proc.start()
        proxies = [tango.DeviceProxy(device) for device in devices]
        for proxy in proxies:
            while True:
                try:
                    proxy.ping()
                    break
                except tango.DevFailed:
                    time.sleep(0.1)

        yield proxies

        proc.terminate()
        db.delete_server(devinfo.server)

    return pytest.fixture(fixture, scope="session")


device = make_server_fixture(
    "ZingoTest/1",
    {
        "test/zingo/1": {
            "class": ZingoTest,
            "properties": {"SomeProperty": ["apa", "bepa", "cepa"]},
        },
        "test/zingo/2": {
            "class": ZingoTest,
            "properties": {"SomeProperty": ["foo", "bar", "baz"]},
        },
    },
)
