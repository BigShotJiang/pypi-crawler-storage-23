from zingo.script import main


def test_dev_basic(device, capsys):
    devname = "test/zingo/1"
    main(["attr", devname, "-a", "SomeAttr"])
    stdout, stderr = capsys.readouterr()
    expected_stdout = "test/zingo/1\tSomeAttr\n"
    assert expected_stdout == stdout


def test_dev_details(device, capsys):
    devname = "test/zingo/1"
    main(["attr", devname, "-a", "SomeAttr", "-d"])
    stdout, stderr = capsys.readouterr()
    expected_stdout = "test/zingo/1\tSomeAttr\tDevDouble\tSCALAR\tREAD\n"
    assert expected_stdout == stdout
