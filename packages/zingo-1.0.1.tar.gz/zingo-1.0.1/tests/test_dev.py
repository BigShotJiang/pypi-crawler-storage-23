import json

import pytest

from zingo.script import main


def check_output(stdout: str, columns: list[str]):
    pairs = zip(stdout.strip().split("\t"), columns)
    for i, (actual, expected) in enumerate(pairs):
        if expected is None:
            # Ignored column
            continue
        assert actual == expected, f"Column {i} does not match!"


def test_dev_basic(device, capsys):
    devname = "test/zingo/1"
    main(["dev", devname])
    stdout, stderr = capsys.readouterr()
    check_output(
        stdout,
        # Ignore the hostname as it will differ
        ["test/zingo/1", "ZingoTest", "ZingoTest/1", None, ""],
    )


def test_dev_read_state(device, capsys):
    devname = "test/zingo/1"
    main(["dev", devname, "-r"])
    stdout, stderr = capsys.readouterr()
    check_output(
        stdout,
        [
            "test/zingo/1",
            "ZingoTest",
            "ZingoTest/1",
            None,
            "",
            "UNKNOWN",
        ],
    )


def test_dev_json(device, capsys):
    devname = "test/zingo/1"
    main(["--json", "dev", devname])
    stdout, stderr = capsys.readouterr()
    stdout_decoded = json.loads(stdout)
    assert len(stdout_decoded) == 1
    assert stdout_decoded[0]["name"] == devname


def test_dev_missing(device, capsys):
    devname = "test/zingo/i_dont_exist"
    with pytest.raises(SystemExit) as e:
        main(["dev", devname])
    assert e.value.code != 0


def test_dev_class(device, capsys):
    devclass = "ZingoTest"
    main(["dev", "--class", devclass])
    stdout, stderr = capsys.readouterr()
    assert len(stdout.splitlines()) == 2
    assert "test/zingo/1" in stdout
    assert "test/zingo/2" in stdout


def test_dev_server(device, capsys):
    devserver = "ZingoTest/1"
    main(["dev", "--server", devserver])
    stdout, stderr = capsys.readouterr()
    assert len(stdout.splitlines()) == 2
    assert "test/zingo/1" in stdout.lower()
    assert "test/zingo/2" in stdout.lower()


def test_dev_regexp(device, capsys):
    devname = "test/zingo/.*"
    main(["dev", devname])
    stdout, stderr = capsys.readouterr()
    assert len(stdout.splitlines()) == 2
    line1, line2 = stdout.splitlines()
    check_output(line1, ["test/zingo/1", "ZingoTest", "ZingoTest/1", None])
    check_output(line2, ["test/zingo/2", "ZingoTest", "ZingoTest/1", None])
