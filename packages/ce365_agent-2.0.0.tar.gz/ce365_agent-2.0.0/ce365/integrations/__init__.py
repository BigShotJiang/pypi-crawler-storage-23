"""
CE365 Agent - Integrations Package

MCP-Server-Anbindung und externe Tool-Integration.
Pro-Feature: Erfordert "mcp_integration" Feature-Flag.
"""
