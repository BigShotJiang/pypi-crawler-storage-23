"""
CE365 Agent - Version Information

Copyright (c) 2026 Carsten Eckhardt / Eckhardt-Marketing
Licensed under Source Available License with Non-Commercial Restriction
"""

__version__ = "2.0.0"
__version_info__ = (2, 0, 0)
__edition__ = "Community"
__release_date__ = "2026-02-18"
__author__ = "Carsten Eckhardt"
__email__ = "info@eckhardt-marketing.de"
__url__ = "https://ce365.dev"
