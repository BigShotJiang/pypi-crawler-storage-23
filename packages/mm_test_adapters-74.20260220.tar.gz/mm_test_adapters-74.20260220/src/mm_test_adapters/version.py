__version__ = "74.20260220"
GIT_REF = "af0a24a"
URL = "https://github.com/micro-manager/mmCoreAndDevices/tree/af0a24a"