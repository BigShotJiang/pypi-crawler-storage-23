def fib(x):
    return fib(x - 1) + fib(x - 2)
