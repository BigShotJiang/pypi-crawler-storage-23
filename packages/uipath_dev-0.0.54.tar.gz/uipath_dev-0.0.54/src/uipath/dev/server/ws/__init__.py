"""WebSocket handler, manager, and protocol."""
