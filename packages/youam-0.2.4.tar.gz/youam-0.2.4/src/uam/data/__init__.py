"""Bundled data files for the youam package."""
