"""Library for parsing python tzdata."""

__all__ = [
    "timezoneinfo",
]
