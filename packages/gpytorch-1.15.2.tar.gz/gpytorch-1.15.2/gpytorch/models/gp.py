#!/usr/bin/env python3

from __future__ import annotations

from ..module import Module


class GP(Module):
    pass
