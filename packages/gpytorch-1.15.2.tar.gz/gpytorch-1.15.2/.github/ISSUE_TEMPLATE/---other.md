---
name: Other
about: Any other issues
title: ''
labels: ''
assignees: ''

---

:no_entry: **Before you submit** :no_entry:

**Is this a question about using GPyTorch?**
If so, please do not open an issue.
Use the [discussions forum](https://github.com/cornellius-gp/gpytorch/discussions) instead.

**Do you need help debugging personal code?**
If so, please do not open an issue.
Use the [discussions forum](https://github.com/cornellius-gp/gpytorch/discussions) instead.
