---
name: "\U0001F527 Refactor"
about: Propose a refactor/speedup/improvement to GPyTorch's internals
title: ''
labels: ''
assignees: ''

---

<!-- A clear and concise description of what you wish to refactor. Please include the following: -->

- <!-- Modules that will be modified -->
- <!-- Impact on code structure -->
- <!-- Impact on speed -->
- <!-- Will this be a breaking change? -->
