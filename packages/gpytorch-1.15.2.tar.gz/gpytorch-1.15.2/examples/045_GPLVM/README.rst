.. toctree::
   :maxdepth: 1
   :hidden:

   Gaussian_Process_Latent_Variable_Models_with_Stochastic_Variational_Inference.ipynb
