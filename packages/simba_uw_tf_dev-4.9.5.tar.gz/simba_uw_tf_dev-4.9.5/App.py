from simba.SimBA import main as App

if __name__ == '__main__':
    App()

