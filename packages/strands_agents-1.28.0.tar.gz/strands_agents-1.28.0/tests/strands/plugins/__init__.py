"""Tests for the plugins module."""
