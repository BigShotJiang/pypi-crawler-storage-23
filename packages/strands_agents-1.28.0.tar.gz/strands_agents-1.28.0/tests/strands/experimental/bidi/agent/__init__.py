"""Bidirectional streaming agent tests."""
