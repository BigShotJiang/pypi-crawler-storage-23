TOOL_SPEC = {"hello": "world!"}
