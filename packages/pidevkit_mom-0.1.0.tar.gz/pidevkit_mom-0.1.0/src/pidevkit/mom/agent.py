from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .sandbox import SandboxConfig


@dataclass(slots=True)
class AgentRunResult:
    stop_reason: str = "completed"


class AgentRunner:
    def run(self, _context: Any, _store: Any) -> AgentRunResult:
        raise NotImplementedError("LLM runner integration is not implemented in the Python mom scaffold yet")

    def abort(self) -> None:
        raise NotImplementedError("LLM runner integration is not implemented in the Python mom scaffold yet")


def get_or_create_runner(_sandbox: SandboxConfig, _channel_id: str, _channel_dir: str | Path) -> AgentRunner:
    raise NotImplementedError("LLM runner integration is not implemented in the Python mom scaffold yet")
