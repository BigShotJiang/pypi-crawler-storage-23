from __future__ import annotations

import json
import re
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from threading import Lock, Thread
from typing import Any, Callable

from . import log


@dataclass(frozen=True, slots=True)
class Attachment:
    original: str
    local: str


@dataclass(slots=True)
class LoggedMessage:
    date: str
    ts: str
    user: str
    text: str
    attachments: list[Attachment] = field(default_factory=list)
    is_bot: bool = False
    user_name: str | None = None
    display_name: str | None = None

    def to_json_dict(self) -> dict[str, Any]:
        return {
            "date": self.date,
            "ts": self.ts,
            "user": self.user,
            "userName": self.user_name,
            "displayName": self.display_name,
            "text": self.text,
            "attachments": [attachment.__dict__ for attachment in self.attachments],
            "isBot": self.is_bot,
        }


@dataclass(frozen=True, slots=True)
class PendingDownload:
    channel_id: str
    local_path: str
    url: str


class ChannelStore:
    def __init__(
        self,
        working_dir: str | Path,
        bot_token: str,
        *,
        auto_download: bool = True,
        download_func: Callable[[str, str], None] | None = None,
    ) -> None:
        self.working_dir = Path(working_dir)
        self.bot_token = bot_token
        self.auto_download = auto_download
        self._download_func = download_func or self._download_attachment

        self.pending_downloads: list[PendingDownload] = []
        self._recently_logged: dict[str, float] = {}
        self._lock = Lock()
        self._is_downloading = False

        self.working_dir.mkdir(parents=True, exist_ok=True)

    def _cleanup_recent(self) -> None:
        cutoff = time.time() - 60
        stale = [key for key, ts in self._recently_logged.items() if ts < cutoff]
        for key in stale:
            self._recently_logged.pop(key, None)

    def get_channel_dir(self, channel_id: str) -> Path:
        directory = self.working_dir / channel_id
        directory.mkdir(parents=True, exist_ok=True)
        return directory

    def generate_local_filename(self, original_name: str, timestamp: str) -> str:
        millis = int(float(timestamp) * 1000)
        sanitized = re.sub(r"[^a-zA-Z0-9._-]", "_", original_name)
        return f"{millis}_{sanitized}"

    def process_attachments(
        self,
        channel_id: str,
        files: list[dict[str, Any]],
        timestamp: str,
    ) -> list[Attachment]:
        attachments: list[Attachment] = []

        for file in files:
            url = file.get("url_private_download") or file.get("url_private")
            if not isinstance(url, str):
                continue

            name = file.get("name")
            if not isinstance(name, str):
                log.log_warning("Attachment missing name, skipping", url)
                continue

            filename = self.generate_local_filename(name, timestamp)
            local_path = f"{channel_id}/attachments/{filename}"

            attachments.append(Attachment(original=name, local=local_path))
            self.pending_downloads.append(PendingDownload(channel_id=channel_id, local_path=local_path, url=url))

        if self.auto_download:
            self._process_download_queue()

        return attachments

    def log_message(self, channel_id: str, message: LoggedMessage | dict[str, Any]) -> bool:
        with self._lock:
            self._cleanup_recent()
            message_dict = self._as_message_dict(message)
            dedupe_key = f"{channel_id}:{message_dict['ts']}"

            if dedupe_key in self._recently_logged:
                return False

            self._recently_logged[dedupe_key] = time.time()

            if not message_dict.get("date"):
                message_dict["date"] = self._date_from_ts(str(message_dict["ts"]))

            log_path = self.get_channel_dir(channel_id) / "log.jsonl"
            with log_path.open("a", encoding="utf-8") as handle:
                handle.write(f"{json.dumps(message_dict)}\n")

        return True

    def log_bot_response(self, channel_id: str, text: str, ts: str) -> None:
        self.log_message(
            channel_id,
            LoggedMessage(
                date=self._date_from_ts(ts),
                ts=ts,
                user="bot",
                text=text,
                attachments=[],
                is_bot=True,
            ),
        )

    def get_last_timestamp(self, channel_id: str) -> str | None:
        log_path = self.working_dir / channel_id / "log.jsonl"
        if not log_path.exists():
            return None

        try:
            lines = [line for line in log_path.read_text(encoding="utf-8").splitlines() if line.strip()]
            if not lines:
                return None
            last = json.loads(lines[-1])
            ts = last.get("ts")
            return ts if isinstance(ts, str) else None
        except Exception:  # noqa: BLE001
            return None

    def _process_download_queue(self) -> None:
        with self._lock:
            if self._is_downloading or not self.pending_downloads:
                return
            self._is_downloading = True

        def worker() -> None:
            while True:
                with self._lock:
                    item = self.pending_downloads.pop(0) if self.pending_downloads else None
                if item is None:
                    break

                try:
                    self._download_func(item.local_path, item.url)
                except Exception as exc:  # noqa: BLE001
                    log.log_warning("Failed to download attachment", f"{item.local_path}: {exc}")

            with self._lock:
                self._is_downloading = False

        Thread(target=worker, daemon=True).start()

    def _download_attachment(self, local_path: str, url: str) -> None:
        target = self.working_dir / local_path
        target.parent.mkdir(parents=True, exist_ok=True)

        request = urllib.request.Request(url, headers={"Authorization": f"Bearer {self.bot_token}"})
        with urllib.request.urlopen(request) as response:  # noqa: S310
            data = response.read()
        target.write_bytes(data)

    def _as_message_dict(self, message: LoggedMessage | dict[str, Any]) -> dict[str, Any]:
        if isinstance(message, LoggedMessage):
            return message.to_json_dict()

        as_dict = dict(message)
        if "attachments" in as_dict and isinstance(as_dict["attachments"], list):
            attachments = []
            for attachment in as_dict["attachments"]:
                if isinstance(attachment, Attachment):
                    attachments.append(attachment.__dict__)
                elif isinstance(attachment, dict):
                    attachments.append(attachment)
            as_dict["attachments"] = attachments

        return as_dict

    @staticmethod
    def _date_from_ts(ts: str) -> str:
        try:
            if "." in ts:
                timestamp = float(ts)
            else:
                timestamp = int(ts) / 1000
            return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(timestamp)) + ".000Z"
        except Exception:  # noqa: BLE001
            return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()) + ".000Z"
