from __future__ import annotations


def download_channel(_channel_id: str, _bot_token: str) -> None:
    raise NotImplementedError("Slack download integration is not implemented in the Python mom scaffold yet")
