from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol


@dataclass(frozen=True, slots=True)
class SlackEvent:
    type: str
    channel: str
    user: str
    text: str
    ts: str


class MomHandler(Protocol):
    def is_running(self, channel_id: str) -> bool:
        ...

    def handle_stop(self, channel_id: str, slack: "SlackBot") -> None:
        ...

    def handle_event(self, event: SlackEvent, slack: "SlackBot", is_event: bool = False) -> None:
        ...


class SlackBot:
    def __init__(
        self,
        _handler: MomHandler,
        *,
        app_token: str,
        bot_token: str,
        working_dir: str | Path,
        store: Any,
    ) -> None:
        _ = (app_token, bot_token, working_dir, store)

    def start(self) -> None:
        raise NotImplementedError("Slack integration is not implemented in the Python mom scaffold yet")

    def enqueue_event(self, _event: SlackEvent | dict[str, str]) -> bool:
        raise NotImplementedError("Slack integration is not implemented in the Python mom scaffold yet")
