from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any


@dataclass(frozen=True, slots=True)
class LogContext:
    channel_id: str
    user_name: str | None = None
    channel_name: str | None = None


def timestamp(now: datetime | None = None) -> str:
    current = now or datetime.now()
    return current.strftime("[%H:%M:%S]")


def format_context(ctx: LogContext) -> str:
    if ctx.channel_id.startswith("D"):
        return f"[DM:{ctx.user_name or ctx.channel_id}]"

    channel = ctx.channel_name or ctx.channel_id
    user = ctx.user_name or "unknown"
    display_channel = channel if channel.startswith("#") else f"#{channel}"
    return f"[{display_channel}:{user}]"


def truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return f"{text[:max_len]}\n(truncated at {max_len} chars)"


def _indented(text: str) -> str:
    return "\n".join(f"           {line}" for line in text.splitlines())


def format_tool_args(args: dict[str, Any]) -> str:
    lines: list[str] = []

    for key, value in args.items():
        if key == "label":
            continue

        if key == "path" and isinstance(value, str):
            offset = args.get("offset")
            limit = args.get("limit")
            if isinstance(offset, int) and isinstance(limit, int):
                lines.append(f"{value}:{offset}-{offset + limit}")
            else:
                lines.append(value)
            continue

        if key in {"offset", "limit"}:
            continue

        if isinstance(value, str):
            lines.append(value)
        else:
            lines.append(str(value))

    return "\n".join(lines)


def log_user_message(ctx: LogContext, text: str) -> None:
    print(f"{timestamp()} {format_context(ctx)} {text}")


def log_tool_start(ctx: LogContext, tool_name: str, label: str, args: dict[str, Any]) -> None:
    print(f"{timestamp()} {format_context(ctx)} ↳ {tool_name}: {label}")
    formatted = format_tool_args(args)
    if formatted:
        print(_indented(formatted))


def log_tool_success(ctx: LogContext, tool_name: str, duration_ms: float, result: str) -> None:
    duration = f"{duration_ms / 1000:.1f}"
    print(f"{timestamp()} {format_context(ctx)} ✓ {tool_name} ({duration}s)")
    truncated = truncate(result, 1000)
    if truncated:
        print(_indented(truncated))


def log_tool_error(ctx: LogContext, tool_name: str, duration_ms: float, error: str) -> None:
    duration = f"{duration_ms / 1000:.1f}"
    print(f"{timestamp()} {format_context(ctx)} ✗ {tool_name} ({duration}s)")
    print(_indented(truncate(error, 1000)))


def log_response_start(ctx: LogContext) -> None:
    print(f"{timestamp()} {format_context(ctx)} → Streaming response...")


def log_thinking(ctx: LogContext, thinking: str) -> None:
    print(f"{timestamp()} {format_context(ctx)} Thinking")
    print(_indented(truncate(thinking, 1000)))


def log_response(ctx: LogContext, text: str) -> None:
    print(f"{timestamp()} {format_context(ctx)} Response")
    print(_indented(truncate(text, 1000)))


def log_download_start(ctx: LogContext, filename: str, local_path: str) -> None:
    print(f"{timestamp()} {format_context(ctx)} ↓ Downloading attachment")
    print(f"           {filename} → {local_path}")


def log_download_success(ctx: LogContext, size_kb: float) -> None:
    print(f"{timestamp()} {format_context(ctx)} ✓ Downloaded ({size_kb:,.0f} KB)")


def log_download_error(ctx: LogContext, filename: str, error: str) -> None:
    print(f"{timestamp()} {format_context(ctx)} ✗ Download failed")
    print(f"           {filename}: {error}")


def log_stop_request(ctx: LogContext) -> None:
    print(f"{timestamp()} {format_context(ctx)} stop")
    print(f"{timestamp()} {format_context(ctx)} ⊗ Stop requested - aborting")


def log_info(message: str) -> None:
    print(f"{timestamp()} [system] {message}")


def log_warning(message: str, details: str | None = None) -> None:
    print(f"{timestamp()} [system] ⚠ {message}")
    if details:
        print(_indented(details))


def log_agent_error(ctx: LogContext | str, error: str) -> None:
    context = "[system]" if ctx == "system" else format_context(ctx)
    print(f"{timestamp()} {context} ✗ Agent error")
    print(_indented(error))


def _format_tokens(count: int) -> str:
    if count < 1000:
        return str(count)
    if count < 10000:
        return f"{count / 1000:.1f}k"
    if count < 1000000:
        return f"{round(count / 1000)}k"
    return f"{count / 1000000:.1f}M"


def log_usage_summary(
    ctx: LogContext,
    usage: dict[str, Any],
    context_tokens: int | None = None,
    context_window: int | None = None,
) -> str:
    cost = usage.get("cost", {})

    lines: list[str] = []
    lines.append("*Usage Summary*")
    lines.append(f"Tokens: {usage.get('input', 0):,} in, {usage.get('output', 0):,} out")

    cache_read = int(usage.get("cacheRead", 0))
    cache_write = int(usage.get("cacheWrite", 0))
    if cache_read > 0 or cache_write > 0:
        lines.append(f"Cache: {cache_read:,} read, {cache_write:,} write")

    if context_tokens and context_window:
        percent = (context_tokens / context_window) * 100
        lines.append(f"Context: {_format_tokens(context_tokens)} / {_format_tokens(context_window)} ({percent:.1f}%)")

    cost_line = f"Cost: ${float(cost.get('input', 0)):.4f} in, ${float(cost.get('output', 0)):.4f} out"
    if cache_read > 0 or cache_write > 0:
        cost_line += (
            f", ${float(cost.get('cacheRead', 0)):.4f} cache read,"
            f" ${float(cost.get('cacheWrite', 0)):.4f} cache write"
        )
    lines.append(cost_line)
    lines.append(f"*Total: ${float(cost.get('total', 0)):.4f}*")

    summary = "\n".join(lines)

    print(f"{timestamp()} {format_context(ctx)} Usage")
    print(
        "           "
        f"{usage.get('input', 0):,} in + {usage.get('output', 0):,} out"
        + (
            f" ({cache_read:,} cache read, {cache_write:,} cache write)" if cache_read > 0 or cache_write > 0 else ""
        )
        + f" = ${float(cost.get('total', 0)):.4f}"
    )

    return summary


def log_startup(working_dir: str, sandbox: str) -> None:
    print("Starting mom bot...")
    print(f"  Working directory: {working_dir}")
    print(f"  Sandbox: {sandbox}")


def log_connected() -> None:
    print("Mom bot connected and listening!")
    print()


def log_disconnected() -> None:
    print("Mom bot disconnected.")


def log_backfill_start(channel_count: int) -> None:
    print(f"{timestamp()} [system] Backfilling {channel_count} channels...")


def log_backfill_channel(channel_name: str, message_count: int) -> None:
    print(f"{timestamp()} [system]   #{channel_name}: {message_count} messages")


def log_backfill_complete(total_messages: int, duration_ms: float) -> None:
    print(f"{timestamp()} [system] Backfill complete: {total_messages} messages in {duration_ms / 1000:.1f}s")
