"""Python port scaffold for the mom package from pi-mono."""

from .cli import main

__all__ = ["main"]
