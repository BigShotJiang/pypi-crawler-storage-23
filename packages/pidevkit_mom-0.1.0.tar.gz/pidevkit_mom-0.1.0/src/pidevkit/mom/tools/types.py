from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


@dataclass(frozen=True, slots=True)
class ToolResult:
    content: list[dict[str, Any]]
    details: dict[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class Tool:
    name: str
    label: str
    description: str
    execute: Callable[..., ToolResult]
