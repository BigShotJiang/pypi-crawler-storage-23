from __future__ import annotations

import secrets
import tempfile
from dataclasses import asdict
from pathlib import Path

from ..sandbox import Executor
from .truncate import DEFAULT_MAX_BYTES, DEFAULT_MAX_LINES, format_size, truncate_tail
from .types import Tool, ToolResult


def _temp_file_path() -> Path:
    return Path(tempfile.gettempdir()) / f"mom-bash-{secrets.token_hex(8)}.log"


def create_bash_tool(executor: Executor) -> Tool:
    description = (
        "Execute a bash command in the current working directory. "
        f"Output is truncated to last {DEFAULT_MAX_LINES} lines or {DEFAULT_MAX_BYTES / 1024:.0f}KB."
    )

    def execute(*, command: str, timeout: float | None = None, label: str = "") -> ToolResult:
        _ = label
        result = executor.exec(command, timeout=timeout)

        output_parts = []
        if result.stdout:
            output_parts.append(result.stdout)
        if result.stderr:
            output_parts.append(result.stderr)
        output = "\n".join(output_parts)

        temp_file_path: Path | None = None
        if len(output.encode("utf-8")) > DEFAULT_MAX_BYTES:
            temp_file_path = _temp_file_path()
            temp_file_path.write_text(output, encoding="utf-8")

        truncation = truncate_tail(output)
        output_text = truncation.content or "(no output)"
        details: dict[str, object] | None = None

        if truncation.truncated:
            details = {
                "truncation": asdict(truncation),
                "fullOutputPath": str(temp_file_path) if temp_file_path else None,
            }

            start_line = truncation.total_lines - truncation.output_lines + 1
            end_line = truncation.total_lines

            if truncation.last_line_partial:
                last_line = output.split("\n")[-1] if output else ""
                last_line_size = format_size(len(last_line.encode("utf-8")))
                output_text += (
                    f"\n\n[Showing last {format_size(truncation.output_bytes)} of line {end_line} "
                    f"(line is {last_line_size}). Full output: {temp_file_path}]"
                )
            elif truncation.truncated_by == "lines":
                output_text += (
                    f"\n\n[Showing lines {start_line}-{end_line} of {truncation.total_lines}. "
                    f"Full output: {temp_file_path}]"
                )
            else:
                output_text += (
                    f"\n\n[Showing lines {start_line}-{end_line} of {truncation.total_lines} "
                    f"({format_size(DEFAULT_MAX_BYTES)} limit). Full output: {temp_file_path}]"
                )

        if result.code != 0:
            raise RuntimeError(f"{output_text}\n\nCommand exited with code {result.code}".strip())

        return ToolResult(content=[{"type": "text", "text": output_text}], details=details)

    return Tool(name="bash", label="bash", description=description, execute=execute)
