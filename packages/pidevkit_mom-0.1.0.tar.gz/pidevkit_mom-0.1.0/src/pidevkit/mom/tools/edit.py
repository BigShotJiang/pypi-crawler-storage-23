from __future__ import annotations

import difflib

from ..sandbox import Executor
from .types import Tool, ToolResult


def _shell_escape(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def generate_diff_string(old_content: str, new_content: str, context_lines: int = 4) -> str:
    diff = difflib.unified_diff(
        old_content.splitlines(),
        new_content.splitlines(),
        fromfile="before",
        tofile="after",
        n=context_lines,
        lineterm="",
    )
    return "\n".join(diff)


def create_edit_tool(executor: Executor) -> Tool:
    description = "Edit a file by replacing exact text. oldText must match exactly (including whitespace)."

    def execute(*, path: str, old_text: str, new_text: str, label: str = "") -> ToolResult:
        _ = label
        read_result = executor.exec(f"cat {_shell_escape(path)}")
        if read_result.code != 0:
            raise RuntimeError(read_result.stderr or f"File not found: {path}")

        content = read_result.stdout
        if old_text not in content:
            raise RuntimeError(
                f"Could not find the exact text in {path}. The old text must match exactly including whitespace."
            )

        occurrences = content.count(old_text)
        if occurrences > 1:
            raise RuntimeError(
                f"Found {occurrences} occurrences of the text in {path}. Provide more context to make it unique."
            )

        index = content.index(old_text)
        new_content = content[:index] + new_text + content[index + len(old_text) :]

        if content == new_content:
            raise RuntimeError(f"No changes made to {path}. Replacement produced identical content.")

        write_result = executor.exec(f"printf '%s' {_shell_escape(new_content)} > {_shell_escape(path)}")
        if write_result.code != 0:
            raise RuntimeError(write_result.stderr or f"Failed to write file: {path}")

        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": (
                        f"Successfully replaced text in {path}. "
                        f"Changed {len(old_text)} characters to {len(new_text)} characters."
                    ),
                }
            ],
            details={"diff": generate_diff_string(content, new_content)},
        )

    return Tool(name="edit", label="edit", description=description, execute=execute)
