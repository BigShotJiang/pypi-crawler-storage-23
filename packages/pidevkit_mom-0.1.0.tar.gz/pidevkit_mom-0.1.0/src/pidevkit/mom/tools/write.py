from __future__ import annotations

from ..sandbox import Executor
from .types import Tool, ToolResult


def _shell_escape(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def create_write_tool(executor: Executor) -> Tool:
    description = "Write content to a file; create parent directories and overwrite if file already exists."

    def execute(*, path: str, content: str, label: str = "") -> ToolResult:
        _ = label
        parent = path.rsplit("/", 1)[0] if "/" in path else "."
        command = f"mkdir -p {_shell_escape(parent)} && printf '%s' {_shell_escape(content)} > {_shell_escape(path)}"

        result = executor.exec(command)
        if result.code != 0:
            raise RuntimeError(result.stderr or f"Failed to write file: {path}")

        return ToolResult(content=[{"type": "text", "text": f"Successfully wrote {len(content)} bytes to {path}"}])

    return Tool(name="write", label="write", description=description, execute=execute)
