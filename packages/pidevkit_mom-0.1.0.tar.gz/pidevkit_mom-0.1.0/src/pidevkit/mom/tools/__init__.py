from __future__ import annotations

from ..sandbox import Executor
from .attach import attach_tool, set_upload_function
from .bash import create_bash_tool
from .edit import create_edit_tool
from .read import create_read_tool
from .types import Tool
from .write import create_write_tool


def create_mom_tools(executor: Executor) -> list[Tool]:
    return [
        create_read_tool(executor),
        create_bash_tool(executor),
        create_edit_tool(executor),
        create_write_tool(executor),
        attach_tool,
    ]


__all__ = ["Tool", "attach_tool", "create_mom_tools", "set_upload_function"]
