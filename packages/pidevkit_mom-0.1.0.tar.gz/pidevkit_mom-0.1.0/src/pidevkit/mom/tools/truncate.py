from __future__ import annotations

from dataclasses import dataclass

DEFAULT_MAX_LINES = 2000
DEFAULT_MAX_BYTES = 50 * 1024


@dataclass(frozen=True, slots=True)
class TruncationResult:
    content: str
    truncated: bool
    truncated_by: str | None
    total_lines: int
    total_bytes: int
    output_lines: int
    output_bytes: int
    last_line_partial: bool
    first_line_exceeds_limit: bool


@dataclass(frozen=True, slots=True)
class TruncationOptions:
    max_lines: int = DEFAULT_MAX_LINES
    max_bytes: int = DEFAULT_MAX_BYTES


def format_size(bytes_count: int) -> str:
    if bytes_count < 1024:
        return f"{bytes_count}B"
    if bytes_count < 1024 * 1024:
        return f"{bytes_count / 1024:.1f}KB"
    return f"{bytes_count / (1024 * 1024):.1f}MB"


def truncate_head(content: str, options: TruncationOptions | None = None) -> TruncationResult:
    opts = options or TruncationOptions()
    total_bytes = len(content.encode("utf-8"))
    lines = content.split("\n")
    total_lines = len(lines)

    if total_lines <= opts.max_lines and total_bytes <= opts.max_bytes:
        return TruncationResult(
            content=content,
            truncated=False,
            truncated_by=None,
            total_lines=total_lines,
            total_bytes=total_bytes,
            output_lines=total_lines,
            output_bytes=total_bytes,
            last_line_partial=False,
            first_line_exceeds_limit=False,
        )

    first_line_bytes = len(lines[0].encode("utf-8"))
    if first_line_bytes > opts.max_bytes:
        return TruncationResult(
            content="",
            truncated=True,
            truncated_by="bytes",
            total_lines=total_lines,
            total_bytes=total_bytes,
            output_lines=0,
            output_bytes=0,
            last_line_partial=False,
            first_line_exceeds_limit=True,
        )

    output_lines: list[str] = []
    output_bytes = 0
    truncated_by: str = "lines"

    for idx, line in enumerate(lines[: opts.max_lines]):
        line_bytes = len(line.encode("utf-8")) + (1 if idx > 0 else 0)
        if output_bytes + line_bytes > opts.max_bytes:
            truncated_by = "bytes"
            break

        output_lines.append(line)
        output_bytes += line_bytes

    if len(output_lines) >= opts.max_lines and output_bytes <= opts.max_bytes:
        truncated_by = "lines"

    output = "\n".join(output_lines)
    return TruncationResult(
        content=output,
        truncated=True,
        truncated_by=truncated_by,
        total_lines=total_lines,
        total_bytes=total_bytes,
        output_lines=len(output_lines),
        output_bytes=len(output.encode("utf-8")),
        last_line_partial=False,
        first_line_exceeds_limit=False,
    )


def truncate_tail(content: str, options: TruncationOptions | None = None) -> TruncationResult:
    opts = options or TruncationOptions()
    total_bytes = len(content.encode("utf-8"))
    lines = content.split("\n")
    total_lines = len(lines)

    if total_lines <= opts.max_lines and total_bytes <= opts.max_bytes:
        return TruncationResult(
            content=content,
            truncated=False,
            truncated_by=None,
            total_lines=total_lines,
            total_bytes=total_bytes,
            output_lines=total_lines,
            output_bytes=total_bytes,
            last_line_partial=False,
            first_line_exceeds_limit=False,
        )

    output_lines: list[str] = []
    output_bytes = 0
    truncated_by: str = "lines"
    last_line_partial = False

    for idx in range(len(lines) - 1, -1, -1):
        line = lines[idx]
        line_bytes = len(line.encode("utf-8")) + (1 if output_lines else 0)

        if output_bytes + line_bytes > opts.max_bytes:
            truncated_by = "bytes"
            if not output_lines:
                truncated_line = _truncate_string_to_bytes_from_end(line, opts.max_bytes)
                output_lines.insert(0, truncated_line)
                output_bytes = len(truncated_line.encode("utf-8"))
                last_line_partial = True
            break

        output_lines.insert(0, line)
        output_bytes += line_bytes

        if len(output_lines) >= opts.max_lines:
            break

    if len(output_lines) >= opts.max_lines and output_bytes <= opts.max_bytes:
        truncated_by = "lines"

    output = "\n".join(output_lines)
    return TruncationResult(
        content=output,
        truncated=True,
        truncated_by=truncated_by,
        total_lines=total_lines,
        total_bytes=total_bytes,
        output_lines=len(output_lines),
        output_bytes=len(output.encode("utf-8")),
        last_line_partial=last_line_partial,
        first_line_exceeds_limit=False,
    )


def _truncate_string_to_bytes_from_end(value: str, max_bytes: int) -> str:
    encoded = value.encode("utf-8")
    if len(encoded) <= max_bytes:
        return value

    start = len(encoded) - max_bytes
    while start < len(encoded) and (encoded[start] & 0xC0) == 0x80:
        start += 1

    return encoded[start:].decode("utf-8")
