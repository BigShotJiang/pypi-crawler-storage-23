from __future__ import annotations

from pathlib import Path
from typing import Callable

from .types import Tool, ToolResult

_upload_fn: Callable[[str, str | None], None] | None = None


def set_upload_function(fn: Callable[[str, str | None], None]) -> None:
    global _upload_fn
    _upload_fn = fn


def _execute_attach(*, path: str, title: str | None = None, label: str = "") -> ToolResult:
    _ = label
    if _upload_fn is None:
        raise RuntimeError("Upload function not configured")

    absolute_path = str(Path(path).expanduser().resolve())
    file_name = title or Path(absolute_path).name

    _upload_fn(absolute_path, file_name)
    return ToolResult(content=[{"type": "text", "text": f"Attached file: {file_name}"}])


attach_tool = Tool(
    name="attach",
    label="attach",
    description="Attach a file to your response.",
    execute=_execute_attach,
)
