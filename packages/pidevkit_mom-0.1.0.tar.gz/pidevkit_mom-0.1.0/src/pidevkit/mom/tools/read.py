from __future__ import annotations

from dataclasses import asdict
from pathlib import PurePosixPath

from ..sandbox import Executor
from .truncate import DEFAULT_MAX_BYTES, DEFAULT_MAX_LINES, format_size, truncate_head
from .types import Tool, ToolResult

IMAGE_MIME_TYPES: dict[str, str] = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _is_image_file(file_path: str) -> str | None:
    return IMAGE_MIME_TYPES.get(PurePosixPath(file_path).suffix.lower())


def _shell_escape(value: str) -> str:
    return "'" + value.replace("'", "'\\''") + "'"


def create_read_tool(executor: Executor) -> Tool:
    description = (
        "Read the contents of a file. Supports text files and images (jpg, png, gif, webp). "
        f"For text files, output is truncated to {DEFAULT_MAX_LINES} lines or {DEFAULT_MAX_BYTES / 1024:.0f}KB."
    )

    def execute(*, path: str, offset: int | None = None, limit: int | None = None, label: str = "") -> ToolResult:
        _ = label
        mime_type = _is_image_file(path)
        if mime_type:
            result = executor.exec(f"base64 < {_shell_escape(path)}")
            if result.code != 0:
                raise RuntimeError(result.stderr or f"Failed to read file: {path}")

            base64_data = "".join(result.stdout.split())
            return ToolResult(
                content=[
                    {"type": "text", "text": f"Read image file [{mime_type}]"},
                    {"type": "image", "data": base64_data, "mimeType": mime_type},
                ]
            )

        count_result = executor.exec(f"wc -l < {_shell_escape(path)}")
        if count_result.code != 0:
            raise RuntimeError(count_result.stderr or f"Failed to read file: {path}")

        total_file_lines = int(count_result.stdout.strip() or "0") + 1
        start_line = max(1, offset or 1)

        if start_line > total_file_lines:
            raise RuntimeError(f"Offset {offset} is beyond end of file ({total_file_lines} lines total)")

        if start_line == 1:
            command = f"cat {_shell_escape(path)}"
        else:
            command = f"tail -n +{start_line} {_shell_escape(path)}"

        read_result = executor.exec(command)
        if read_result.code != 0:
            raise RuntimeError(read_result.stderr or f"Failed to read file: {path}")

        selected_content = read_result.stdout
        user_limited_lines: int | None = None

        if limit is not None:
            lines = selected_content.split("\n")
            end_line = min(limit, len(lines))
            selected_content = "\n".join(lines[:end_line])
            user_limited_lines = end_line

        truncation = truncate_head(selected_content)

        output_text: str
        details: dict[str, object] | None = None

        if truncation.first_line_exceeds_limit:
            first_line_size = format_size(len(selected_content.split("\n")[0].encode("utf-8")))
            output_text = (
                f"[Line {start_line} is {first_line_size}, exceeds {format_size(DEFAULT_MAX_BYTES)} limit. "
                f"Use bash: sed -n '{start_line}p' {path} | head -c {DEFAULT_MAX_BYTES}]"
            )
            details = {"truncation": asdict(truncation)}
        elif truncation.truncated:
            end_line_display = start_line + truncation.output_lines - 1
            next_offset = end_line_display + 1
            output_text = truncation.content

            if truncation.truncated_by == "lines":
                output_text += (
                    f"\n\n[Showing lines {start_line}-{end_line_display} of {total_file_lines}. "
                    f"Use offset={next_offset} to continue]"
                )
            else:
                output_text += (
                    f"\n\n[Showing lines {start_line}-{end_line_display} of {total_file_lines} "
                    f"({format_size(DEFAULT_MAX_BYTES)} limit). Use offset={next_offset} to continue]"
                )

            details = {"truncation": asdict(truncation)}
        elif user_limited_lines is not None:
            lines_from_start = start_line - 1 + user_limited_lines
            output_text = truncation.content
            if lines_from_start < total_file_lines:
                remaining = total_file_lines - lines_from_start
                next_offset = start_line + user_limited_lines
                output_text += f"\n\n[{remaining} more lines in file. Use offset={next_offset} to continue]"
        else:
            output_text = truncation.content

        return ToolResult(content=[{"type": "text", "text": output_text}], details=details)

    return Tool(name="read", label="read", description=description, execute=execute)
