from __future__ import annotations

import os
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Sequence

from .download import download_channel
from .sandbox import HostSandboxConfig, SandboxConfig, parse_sandbox_arg, validate_sandbox

MOM_SLACK_APP_TOKEN = "MOM_SLACK_APP_TOKEN"
MOM_SLACK_BOT_TOKEN = "MOM_SLACK_BOT_TOKEN"


@dataclass(frozen=True, slots=True)
class ParsedArgs:
    working_dir: Path | None
    sandbox: SandboxConfig
    download_channel: str | None


def parse_args(argv: Sequence[str]) -> ParsedArgs:
    sandbox: SandboxConfig = HostSandboxConfig()
    working_dir: Path | None = None
    download_channel: str | None = None

    args = list(argv)
    index = 0
    while index < len(args):
        arg = args[index]

        if arg.startswith("--sandbox="):
            sandbox = parse_sandbox_arg(arg.split("=", 1)[1])
            index += 1
            continue

        if arg == "--sandbox":
            if index + 1 >= len(args):
                raise ValueError("--sandbox requires a value")
            sandbox = parse_sandbox_arg(args[index + 1])
            index += 2
            continue

        if arg.startswith("--download="):
            download_channel = arg.split("=", 1)[1]
            index += 1
            continue

        if arg == "--download":
            if index + 1 >= len(args):
                raise ValueError("--download requires a channel id")
            download_channel = args[index + 1]
            index += 2
            continue

        if not arg.startswith("-"):
            working_dir = Path(arg).expanduser().resolve()

        index += 1

    return ParsedArgs(working_dir=working_dir, sandbox=sandbox, download_channel=download_channel)


def print_usage() -> None:
    print("Usage: mom [--sandbox=host|docker:<name>] <working-directory>", file=sys.stderr)
    print("       mom --download <channel-id>", file=sys.stderr)


def _start_runtime(*, working_dir: Path, sandbox: SandboxConfig) -> None:
    _ = (working_dir, sandbox)
    raise NotImplementedError("Slack bot runtime is not implemented in the Python mom scaffold yet")


def main(argv: Sequence[str] | None = None) -> int:
    args = list(argv if argv is not None else sys.argv[1:])

    try:
        parsed = parse_args(args)
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        print_usage()
        return 1

    bot_token = os.getenv(MOM_SLACK_BOT_TOKEN)

    if parsed.download_channel:
        if not bot_token:
            print(f"Missing env: {MOM_SLACK_BOT_TOKEN}", file=sys.stderr)
            return 1

        try:
            download_channel(parsed.download_channel, bot_token)
            return 0
        except NotImplementedError as exc:
            print(str(exc), file=sys.stderr)
            return 1

    if parsed.working_dir is None:
        print_usage()
        return 1

    app_token = os.getenv(MOM_SLACK_APP_TOKEN)
    if not app_token or not bot_token:
        print(f"Missing env: {MOM_SLACK_APP_TOKEN}, {MOM_SLACK_BOT_TOKEN}", file=sys.stderr)
        return 1

    try:
        validate_sandbox(parsed.sandbox)
    except RuntimeError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    try:
        _start_runtime(working_dir=parsed.working_dir, sandbox=parsed.sandbox)
    except NotImplementedError as exc:
        print(str(exc), file=sys.stderr)
        return 1

    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
