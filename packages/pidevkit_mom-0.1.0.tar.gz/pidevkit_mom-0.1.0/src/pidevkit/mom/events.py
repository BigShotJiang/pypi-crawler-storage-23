from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Literal
from zoneinfo import ZoneInfo


@dataclass(frozen=True, slots=True)
class ImmediateEvent:
    type: Literal["immediate"]
    channel_id: str
    text: str


@dataclass(frozen=True, slots=True)
class OneShotEvent:
    type: Literal["one-shot"]
    channel_id: str
    text: str
    at: str


@dataclass(frozen=True, slots=True)
class PeriodicEvent:
    type: Literal["periodic"]
    channel_id: str
    text: str
    schedule: str
    timezone: str


MomEvent = ImmediateEvent | OneShotEvent | PeriodicEvent


@dataclass(frozen=True, slots=True)
class EventDecision:
    kind: Literal[
        "execute-immediate",
        "delete-stale-immediate",
        "schedule-one-shot",
        "delete-past-one-shot",
        "schedule-periodic",
    ]
    delay_seconds: float | None = None


_CRON_FIELD_RE = re.compile(r"^[\d*/,-]+$")


def _parse_iso_datetime(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("Timestamp must include timezone information")
    return parsed


def validate_cron_schedule(schedule: str) -> None:
    fields = schedule.split()
    if len(fields) != 5:
        raise ValueError("Cron schedule must contain 5 fields")

    for field in fields:
        if not _CRON_FIELD_RE.match(field):
            raise ValueError(f"Invalid cron field '{field}'")


def validate_timezone_name(value: str) -> None:
    try:
        ZoneInfo(value)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"Invalid timezone '{value}'") from exc


def parse_event(content: str, filename: str = "<memory>") -> MomEvent:
    data = json.loads(content)
    if not isinstance(data, dict):
        raise ValueError(f"Expected object in {filename}")

    event_type = data.get("type")
    channel_id = data.get("channelId")
    text = data.get("text")

    if not isinstance(event_type, str) or not isinstance(channel_id, str) or not isinstance(text, str):
        raise ValueError(f"Missing required fields (type, channelId, text) in {filename}")

    if event_type == "immediate":
        return ImmediateEvent(type="immediate", channel_id=channel_id, text=text)

    if event_type == "one-shot":
        at = data.get("at")
        if not isinstance(at, str):
            raise ValueError(f"Missing 'at' field for one-shot event in {filename}")
        _parse_iso_datetime(at)
        return OneShotEvent(type="one-shot", channel_id=channel_id, text=text, at=at)

    if event_type == "periodic":
        schedule = data.get("schedule")
        timezone = data.get("timezone")

        if not isinstance(schedule, str):
            raise ValueError(f"Missing 'schedule' field for periodic event in {filename}")
        if not isinstance(timezone, str):
            raise ValueError(f"Missing 'timezone' field for periodic event in {filename}")

        validate_cron_schedule(schedule)
        validate_timezone_name(timezone)

        return PeriodicEvent(type="periodic", channel_id=channel_id, text=text, schedule=schedule, timezone=timezone)

    raise ValueError(f"Unknown event type '{event_type}' in {filename}")


def decision_for_event(
    event: MomEvent,
    *,
    now: datetime | None = None,
    start_time: datetime | None = None,
    file_mtime: datetime | None = None,
) -> EventDecision:
    current = now or datetime.now().astimezone()

    if isinstance(event, ImmediateEvent):
        if start_time and file_mtime and file_mtime < start_time:
            return EventDecision(kind="delete-stale-immediate")
        return EventDecision(kind="execute-immediate")

    if isinstance(event, OneShotEvent):
        at_time = _parse_iso_datetime(event.at)
        if at_time <= current:
            return EventDecision(kind="delete-past-one-shot")
        return EventDecision(kind="schedule-one-shot", delay_seconds=(at_time - current).total_seconds())

    validate_cron_schedule(event.schedule)
    validate_timezone_name(event.timezone)
    return EventDecision(kind="schedule-periodic")


def build_event_message(filename: str, event: MomEvent) -> str:
    if isinstance(event, ImmediateEvent):
        schedule_info = "immediate"
    elif isinstance(event, OneShotEvent):
        schedule_info = event.at
    else:
        schedule_info = event.schedule

    return f"[EVENT:{filename}:{event.type}:{schedule_info}] {event.text}"


def build_synthetic_slack_event(filename: str, event: MomEvent, *, now: datetime | None = None) -> dict[str, str]:
    timestamp = str(int((now or datetime.now().astimezone()).timestamp() * 1000))
    return {
        "type": "mention",
        "channel": event.channel_id,
        "user": "EVENT",
        "text": build_event_message(filename, event),
        "ts": timestamp,
    }


class EventsWatcher:
    """Scaffold for filesystem watching and queueing integration."""

    def __init__(self, events_dir: str | Path) -> None:
        self.events_dir = Path(events_dir)
        self.start_time = datetime.now().astimezone()

    def start(self) -> None:
        raise NotImplementedError("Events filesystem watching is not implemented in the Python scaffold yet")

    def stop(self) -> None:
        return None


def create_events_watcher(workspace_dir: str | Path) -> EventsWatcher:
    return EventsWatcher(Path(workspace_dir) / "events")
