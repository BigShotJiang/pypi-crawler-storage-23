from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Protocol

_ATTACHMENT_MARKER = "\n\n<slack_attachments>\n"
_TIMESTAMP_PREFIX_RE = re.compile(r"^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}[+-]\d{2}:\d{2}\] ")


class SessionManagerLike(Protocol):
    def get_entries(self) -> list[Any]:
        ...

    def append_message(self, message: dict[str, Any]) -> None:
        ...


@dataclass(frozen=True, slots=True)
class MomCompactionSettings:
    enabled: bool = True
    reserve_tokens: int = 16384
    keep_recent_tokens: int = 20000


@dataclass(frozen=True, slots=True)
class MomRetrySettings:
    enabled: bool = True
    max_retries: int = 3
    base_delay_ms: int = 2000


def _normalize_text_for_dedupe(text: str) -> str:
    normalized = _TIMESTAMP_PREFIX_RE.sub("", text)
    marker_index = normalized.find(_ATTACHMENT_MARKER)
    if marker_index != -1:
        normalized = normalized[:marker_index]
    return normalized


def _entry_get(entry: Any, key: str) -> Any:
    if isinstance(entry, dict):
        return entry.get(key)
    return getattr(entry, key, None)


def _iter_user_texts_from_session(entry: Any) -> list[str]:
    if _entry_get(entry, "type") != "message":
        return []

    message = _entry_get(entry, "message")
    if not isinstance(message, dict) or message.get("role") != "user":
        return []

    content = message.get("content")
    if isinstance(content, str):
        return [_normalize_text_for_dedupe(content)]

    texts: list[str] = []
    if isinstance(content, list):
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                text = part.get("text")
                if isinstance(text, str):
                    texts.append(_normalize_text_for_dedupe(text))
    return texts


def _parse_iso_ms(value: str) -> int:
    normalized = value.replace("Z", "+00:00")
    return int(datetime.fromisoformat(normalized).timestamp() * 1000)


def sync_log_to_session_manager(
    session_manager: SessionManagerLike,
    channel_dir: str | Path,
    exclude_slack_ts: str | None = None,
) -> int:
    """
    Sync user entries from `<channel_dir>/log.jsonl` into a session manager.

    The sync de-duplicates by normalized `[user]: text` content.
    """
    log_file = Path(channel_dir) / "log.jsonl"
    if not log_file.exists():
        return 0

    existing_messages: set[str] = set()
    for entry in session_manager.get_entries():
        existing_messages.update(_iter_user_texts_from_session(entry))

    new_messages: list[tuple[int, dict[str, Any]]] = []
    for raw_line in log_file.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line:
            continue

        try:
            log_message = json.loads(line)
        except json.JSONDecodeError:
            continue

        slack_ts = log_message.get("ts")
        date = log_message.get("date")
        if not isinstance(slack_ts, str) or not isinstance(date, str):
            continue

        if exclude_slack_ts and slack_ts == exclude_slack_ts:
            continue

        if log_message.get("isBot"):
            continue

        user_name = log_message.get("userName") or log_message.get("user") or "unknown"
        message_text = f"[{user_name}]: {log_message.get('text', '')}"

        if message_text in existing_messages:
            continue

        try:
            timestamp_ms = _parse_iso_ms(date)
        except ValueError:
            timestamp_ms = int(time.time() * 1000)

        message = {
            "role": "user",
            "content": [{"type": "text", "text": message_text}],
            "timestamp": timestamp_ms,
        }

        new_messages.append((timestamp_ms, message))
        existing_messages.add(message_text)

    if not new_messages:
        return 0

    new_messages.sort(key=lambda item: item[0])
    for _, message in new_messages:
        session_manager.append_message(message)

    return len(new_messages)


class MomSettingsManager:
    """File-backed settings for mom (`<workspace>/settings.json`)."""

    def __init__(self, workspace_dir: str | Path) -> None:
        self._settings_path = Path(workspace_dir) / "settings.json"
        self._settings: dict[str, Any] = self._load()

    def _load(self) -> dict[str, Any]:
        if not self._settings_path.exists():
            return {}

        try:
            raw = json.loads(self._settings_path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return {}

        return raw if isinstance(raw, dict) else {}

    def _save(self) -> None:
        try:
            self._settings_path.parent.mkdir(parents=True, exist_ok=True)
            self._settings_path.write_text(json.dumps(self._settings, indent=2), encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            print(f"Warning: Could not save settings file: {exc}")

    def get_compaction_settings(self) -> MomCompactionSettings:
        compaction = self._settings.get("compaction")
        if not isinstance(compaction, dict):
            compaction = {}
        return MomCompactionSettings(
            enabled=bool(compaction.get("enabled", True)),
            reserve_tokens=int(compaction.get("reserveTokens", 16384)),
            keep_recent_tokens=int(compaction.get("keepRecentTokens", 20000)),
        )

    def get_compaction_enabled(self) -> bool:
        compaction = self._settings.get("compaction")
        if isinstance(compaction, dict) and "enabled" in compaction:
            return bool(compaction["enabled"])
        return True

    def set_compaction_enabled(self, enabled: bool) -> None:
        compaction = self._settings.get("compaction")
        next_compaction = dict(compaction) if isinstance(compaction, dict) else {}
        next_compaction["enabled"] = enabled
        self._settings["compaction"] = next_compaction
        self._save()

    def get_retry_settings(self) -> MomRetrySettings:
        retry = self._settings.get("retry")
        if not isinstance(retry, dict):
            retry = {}
        return MomRetrySettings(
            enabled=bool(retry.get("enabled", True)),
            max_retries=int(retry.get("maxRetries", 3)),
            base_delay_ms=int(retry.get("baseDelayMs", 2000)),
        )

    def get_retry_enabled(self) -> bool:
        retry = self._settings.get("retry")
        if isinstance(retry, dict) and "enabled" in retry:
            return bool(retry["enabled"])
        return True

    def set_retry_enabled(self, enabled: bool) -> None:
        retry = self._settings.get("retry")
        next_retry = dict(retry) if isinstance(retry, dict) else {}
        next_retry["enabled"] = enabled
        self._settings["retry"] = next_retry
        self._save()

    def get_default_model(self) -> str | None:
        value = self._settings.get("defaultModel")
        return value if isinstance(value, str) else None

    def get_default_provider(self) -> str | None:
        value = self._settings.get("defaultProvider")
        return value if isinstance(value, str) else None

    def set_default_model_and_provider(self, provider: str, model_id: str) -> None:
        self._settings["defaultProvider"] = provider
        self._settings["defaultModel"] = model_id
        self._save()

    def get_default_thinking_level(self) -> str:
        value = self._settings.get("defaultThinkingLevel")
        return value if isinstance(value, str) else "off"

    def set_default_thinking_level(self, level: str) -> None:
        self._settings["defaultThinkingLevel"] = level
        self._save()

    def get_steering_mode(self) -> str:
        return "one-at-a-time"

    def set_steering_mode(self, _mode: str) -> None:
        return None

    def get_follow_up_mode(self) -> str:
        return "one-at-a-time"

    def set_follow_up_mode(self, _mode: str) -> None:
        return None

    def get_hook_paths(self) -> list[str]:
        return []

    def get_hook_timeout(self) -> int:
        return 30000
