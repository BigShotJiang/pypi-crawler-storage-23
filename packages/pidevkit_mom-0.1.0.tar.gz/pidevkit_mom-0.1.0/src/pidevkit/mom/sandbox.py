from __future__ import annotations

import os
import shlex
import signal
import subprocess
from dataclasses import dataclass
from typing import Literal, Protocol


@dataclass(frozen=True, slots=True)
class HostSandboxConfig:
    type: Literal["host"] = "host"


@dataclass(frozen=True, slots=True)
class DockerSandboxConfig:
    container: str
    type: Literal["docker"] = "docker"


SandboxConfig = HostSandboxConfig | DockerSandboxConfig


@dataclass(frozen=True, slots=True)
class ExecResult:
    stdout: str
    stderr: str
    code: int


class Executor(Protocol):
    def exec(self, command: str, *, timeout: float | None = None) -> ExecResult:
        ...

    def get_workspace_path(self, host_path: str) -> str:
        ...


def parse_sandbox_arg(value: str) -> SandboxConfig:
    if value == "host":
        return HostSandboxConfig()

    if value.startswith("docker:"):
        container = value[len("docker:") :]
        if not container:
            raise ValueError("docker sandbox requires container name (e.g., docker:mom-sandbox)")
        return DockerSandboxConfig(container=container)

    raise ValueError(f"Invalid sandbox type '{value}'. Use 'host' or 'docker:<container-name>'")


def _exec_simple(command: list[str]) -> str:
    completed = subprocess.run(command, capture_output=True, check=True, text=True)
    return completed.stdout


def validate_sandbox(config: SandboxConfig) -> None:
    if isinstance(config, HostSandboxConfig):
        return

    try:
        _exec_simple(["docker", "--version"])
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("Docker is not installed or not in PATH") from exc

    try:
        result = _exec_simple(["docker", "inspect", "-f", "{{.State.Running}}", config.container]).strip()
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(f"Container '{config.container}' does not exist") from exc

    if result != "true":
        raise RuntimeError(f"Container '{config.container}' is not running")


class HostExecutor:
    def exec(self, command: str, *, timeout: float | None = None) -> ExecResult:
        if os.name == "nt":
            process = subprocess.Popen(
                ["cmd", "/c", command],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
        else:
            process = subprocess.Popen(
                ["sh", "-c", command],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                preexec_fn=os.setsid,
            )

        try:
            stdout, stderr = process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired as exc:
            if os.name == "nt":
                process.send_signal(signal.CTRL_BREAK_EVENT)
                process.kill()
            else:
                assert process.pid is not None
                os.killpg(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate()
            raise TimeoutError((stdout + "\n" + stderr + f"\nCommand timed out after {timeout} seconds").strip()) from exc

        max_chars = 10 * 1024 * 1024
        if len(stdout) > max_chars:
            stdout = stdout[:max_chars]
        if len(stderr) > max_chars:
            stderr = stderr[:max_chars]

        return ExecResult(stdout=stdout, stderr=stderr, code=process.returncode or 0)

    def get_workspace_path(self, host_path: str) -> str:
        return host_path


class DockerExecutor:
    def __init__(self, container: str) -> None:
        self.container = container
        self._host = HostExecutor()

    def exec(self, command: str, *, timeout: float | None = None) -> ExecResult:
        wrapped = f"docker exec {shlex.quote(self.container)} sh -c {shlex.quote(command)}"
        return self._host.exec(wrapped, timeout=timeout)

    def get_workspace_path(self, host_path: str) -> str:
        _ = host_path
        return "/workspace"


def create_executor(config: SandboxConfig) -> Executor:
    if isinstance(config, HostSandboxConfig):
        return HostExecutor()
    return DockerExecutor(config.container)
