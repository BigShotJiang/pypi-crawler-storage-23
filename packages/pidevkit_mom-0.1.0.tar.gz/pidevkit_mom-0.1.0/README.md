# pidevkit-mom

MOM subsystem extracted as a standalone package.

## Install

```bash
pip install pidevkit-mom
```

## Import

```python
from pidevkit.mom.main import run
```
