# Test module for coach commands
