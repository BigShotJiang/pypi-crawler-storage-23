"""
MySQL Migration — Staged: progressive tool disclosure via stages + transitions.

The server controls which tools are visible at each phase, making it impossible
for the model to call tools out of order.

Stages:
    preflight → drain → backup → migrate → verify → release → finalize

Run:
    python -m concierge.examples.mysql_migration.staged
"""

from mcp.server.fastmcp import FastMCP

from concierge import Concierge
from concierge.examples.mysql_migration.tools import register_tools

server = Concierge(FastMCP("mysql-migration-staged"))
register_tools(server)

server.stages = {
    "preflight": ["preflight_check"],
    "drain": ["drain_connections"],
    "backup": ["create_backup", "validate_backup"],
    "migrate": ["apply_migration"],
    "verify": ["run_smoke_tests"],
    "release": ["undrain_connections", "notify_stakeholders"],
    "finalize": ["finalize_migration"],
}

server.transitions = {
    "preflight": ["drain"],
    "drain": ["backup"],
    "backup": ["migrate"],
    "migrate": ["verify"],
    "verify": ["release"],
    "release": ["finalize"],
    "finalize": [],
}

if __name__ == "__main__":
    server.run(transport="streamable-http")
