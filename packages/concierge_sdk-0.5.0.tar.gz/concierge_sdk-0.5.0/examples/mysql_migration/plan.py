"""
MySQL Migration — Plan: all tools wrapped into a single execute_plan tool.
"""

from mcp.server.fastmcp import FastMCP

from concierge import Concierge, Config, ProviderType
from concierge.examples.mysql_migration.tools import register_tools

server = Concierge(
    FastMCP("mysql-migration-plan"),
    config=Config(provider_type=ProviderType.PLAN),
)
register_tools(server)

if __name__ == "__main__":
    server.run(transport="streamable-http")
