"""
MySQL Migration — Flat: all 9 tools exposed at once, model picks the order.

Run:
    python -m concierge.examples.mysql_migration.flat
"""

from mcp.server.fastmcp import FastMCP

from concierge import Concierge
from concierge.examples.mysql_migration.tools import register_tools

server = Concierge(FastMCP("mysql-migration-flat"))
register_tools(server)

if __name__ == "__main__":
    server.run(transport="streamable-http")
