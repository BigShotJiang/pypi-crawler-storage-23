import os

# -----------------------------
# NOVA CLI (API-only) Config
# -----------------------------
# This repo MUST NOT store model provider API keys.
# All AI + execution happens via NOVA_API over HTTP.
# Auth happens via nova-web.
# -----------------------------

# Location / display (optional; used only for UX)
LOCATION = os.getenv("NOVA_LOCATION", "India")
USER_NAME = os.getenv("NOVA_USER_NAME", "User")

# Defaults for CLI requests (sent to API)
DEFAULT_PROVIDER = os.getenv("NOVA_DEFAULT_PROVIDER", "groq")
DEFAULT_MODEL = os.getenv("NOVA_DEFAULT_MODEL", "openai/gpt-oss-120b")

# Base URLs
# - NOVA_API_BASE_URL points to the NOVA_API server (local or remote)
# - NOVA_AUTH_BASE_URL points to nova-web (Render)
NOVA_API_BASE_URL = os.getenv("NOVA_API_BASE_URL", "https://api.nova.bridgeye.com")
NOVA_AUTH_BASE_URL = os.getenv("NOVA_AUTH_BASE_URL", "https://nova.bridgeye.com")

# Client identity
NOVA_USER_AGENT = os.getenv("NOVA_USER_AGENT", "NovaCLI/1.0")

# Debug toggles
DEBUG_AUTH = os.getenv("NOVA_DEBUG_AUTH", "").strip() in ("1", "true", "TRUE", "yes", "YES")

# Git behavior (CLI-only UX; file_manager uses these)
GIT_AUTO_COMMIT = os.getenv("NOVA_GIT_AUTO_COMMIT", "").strip() in ("1", "true", "TRUE", "yes", "YES")
GIT_AUTO_PUSH = os.getenv("NOVA_GIT_AUTO_PUSH", "").strip() in ("1", "true", "TRUE", "yes", "YES")

# Context load toggle (CLI-side feature; does not affect API)
AUTO_CONTEXT_LOAD = os.getenv("NOVA_AUTO_CONTEXT_LOAD", "").strip() in ("1", "true", "TRUE", "yes", "YES")
