# NOVA_CLI/nova_cli/cli/commands.py

def register_core_commands(registry, shell):
    
    registry.register("login", shell.cmd_login)
    registry.register("nova login", shell.cmd_login)
    # model / git
    registry.register(":model", shell.cmd_model)
    registry.register(":gitoptions", shell.cmd_gitoptions)

    # reset / unload
    registry.register(":reset", shell.cmd_reset)
    registry.register("reset", shell.cmd_reset)

    registry.register(":unload", shell.cmd_unload)
    registry.register("unload", shell.cmd_unload)

    # map / ls
    registry.register(":map", shell.cmd_map)
    registry.register("ls", shell.cmd_map)

    # wizard / apply / paste
    registry.register(":wizard", shell.cmd_wizard)
    registry.register(":apply", shell.cmd_apply)
    registry.register(":paste", shell.cmd_paste)

    # load / navigation
    registry.register(":load", shell.cmd_load)
    registry.register("cd", shell.cmd_cd)
    registry.register("pwd", shell.cmd_pwd)

    # execution / cleanup
    registry.register("run", shell.cmd_run)
    registry.register("clean", shell.cmd_clean)

    # build command
    registry.register("Build It", shell.cmd_build_it)
    registry.register("build it", shell.cmd_build_it)
    registry.register("Build", shell.cmd_build_it)
    registry.register("build", shell.cmd_build_it)

    # exit / help
    registry.register("exit", shell.cmd_exit)
    registry.register("quit", shell.cmd_exit)

    registry.register("help", shell.cmd_help)
    registry.register(":help", shell.cmd_help)

    #registry.register("logout", shell.cmd_logout)  # optional, future-proof
