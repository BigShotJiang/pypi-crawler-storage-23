# nova_cli/nova_core/ai/utils.py
# CLI-only list for model selector UI.
# The API remains the source of truth for what is actually allowed.

MODELS = {
    "groq": [
        "openai/gpt-oss-120b",
        "openai/gpt-oss-20b",
        "meta-llama/llama-4-scout-17b-16e-instruct",
        "moonshotai/kimi-k2-instruct-0905",
    ],
}