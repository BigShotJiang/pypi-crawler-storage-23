# NOVA CLI

Official CLI for Bridgeye Nova.

## Installation

### Via pip
```bash
pip install bridgeye-nova