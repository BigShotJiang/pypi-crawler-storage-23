# NOVA_CLI\core\state.py

class SessionState:
    def __init__(self) -> None:
        """
        Initializes the SessionState with default values.

        Attributes:
            active_file (str | None): The file currently being focused on/edited (absolute path).
            last_ai_response (str): The last response from the AI.
            last_generated_code (str | None): The last valid code block generated.
            loaded_files (dict[str, str]): Canonical mapping {basename: content} for persistent context.
            loaded_paths (dict[str, str]): Mapping {basename: absolute_path} for writing/applying edits.
            total_tokens_used (int): The total number of tokens used.
        """
        self.active_file: str | None = None
        self.last_ai_response: str = ""
        self.last_generated_code: str | None = None

        # Canonical: basename -> content
        self.loaded_files: dict[str, str] = {}

        # Canonical: basename -> abs path
        self.loaded_paths: dict[str, str] = {}

        self.total_tokens_used: int = 0

    def reset(self) -> None:
        """
        Resets the session state to initial defaults.
        """
        self.active_file = None
        self.last_ai_response = ""
        self.last_generated_code = None
        self.loaded_files = {}
        self.loaded_paths = {}
        self.total_tokens_used = 0
