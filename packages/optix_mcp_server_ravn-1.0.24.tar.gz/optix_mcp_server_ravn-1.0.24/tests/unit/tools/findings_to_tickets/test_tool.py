from unittest.mock import MagicMock

import pytest

from tools.findings_to_tickets.models import Platform
from tools.findings_to_tickets.tool import FindingsToTicketsTool
from tools.history.reader import AuditSummary


@pytest.fixture
def mock_history_reader():
    reader = MagicMock()
    return reader


@pytest.fixture
def tool(mock_history_reader):
    return FindingsToTicketsTool(history_reader=mock_history_reader)


@pytest.fixture
def sample_audit_data():
    return {
        "timestamp": "2026-02-18T14:30:45Z",
        "lens": "security",
        "continuation_id": "abc-123",
        "findings": [
            {
                "id": "f-001",
                "severity": "critical",
                "category": "SQL Injection",
                "description": "SQL injection vulnerability",
                "affected_files": ["src/db.py"],
                "remediation": "Use parameterized queries",
            },
            {
                "id": "f-002",
                "severity": "high",
                "category": "XSS",
                "description": "Cross-site scripting",
                "affected_files": ["src/render.py"],
            },
            {
                "id": "f-003",
                "severity": "medium",
                "category": "Config",
                "description": "Insecure configuration",
            },
        ],
    }


class TestListAudits:
    def test_delegates_to_history_reader(self, tool, mock_history_reader):
        expected_summaries = [
            AuditSummary(
                dir_name="2026-02-18_security",
                timestamp="2026-02-18T14:30:45Z",
                lens="security",
                continuation_id="abc-123",
                project_name="test-project",
                total_findings=5,
                by_severity={"critical": 1, "high": 2, "medium": 2},
                files_examined=10,
                steps_completed=6,
            )
        ]
        mock_history_reader.list_audits.return_value = expected_summaries

        result = tool.list_audits()

        assert result == expected_summaries
        mock_history_reader.list_audits.assert_called_once()

    def test_returns_empty_list_when_no_audits(self, tool, mock_history_reader):
        mock_history_reader.list_audits.return_value = []

        result = tool.list_audits()

        assert result == []


class TestGetAuditFindings:
    def test_returns_findings_from_audit(self, tool, mock_history_reader, sample_audit_data):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.get_audit_findings("2026-02-18_security")

        assert len(result) == 3
        assert result[0]["id"] == "f-001"
        assert result[1]["id"] == "f-002"

    def test_raises_error_for_missing_audit(self, tool, mock_history_reader):
        mock_history_reader.get_audit.return_value = None

        with pytest.raises(ValueError, match="Audit not found"):
            tool.get_audit_findings("nonexistent-audit")

    def test_adds_ids_to_findings_without_ids(self, tool, mock_history_reader):
        audit_data = {
            "findings": [
                {"severity": "low", "category": "Test"},
                {"severity": "info", "category": "Test2"},
            ]
        }
        mock_history_reader.get_audit.return_value = audit_data

        result = tool.get_audit_findings("audit-dir")

        assert result[0]["id"] == "finding-0"
        assert result[1]["id"] == "finding-1"

    def test_handles_empty_findings(self, tool, mock_history_reader):
        mock_history_reader.get_audit.return_value = {"findings": []}

        result = tool.get_audit_findings("audit-dir")

        assert result == []

    def test_handles_missing_findings_key(self, tool, mock_history_reader):
        mock_history_reader.get_audit.return_value = {"timestamp": "2026-02-18"}

        result = tool.get_audit_findings("audit-dir")

        assert result == []


class TestPrepareTicketsSuccess:
    def test_prepares_tickets_for_selected_findings(
        self, tool, mock_history_reader, sample_audit_data
    ):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=["f-001", "f-002"],
            platform=Platform.LINEAR,
        )

        assert result.success is True
        assert result.platform == "linear"
        assert len(result.tickets) == 2
        assert result.total_findings == 3
        assert result.selected_count == 2

    def test_ticket_data_is_formatted_correctly(
        self, tool, mock_history_reader, sample_audit_data
    ):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=["f-001"],
            platform=Platform.LINEAR,
        )

        ticket = result.tickets[0]
        assert ticket.finding_id == "f-001"
        assert "[CRITICAL]" in ticket.title
        assert "SQL Injection" in ticket.title
        assert ticket.priority == "1"
        assert "security" in ticket.labels
        assert "critical" in ticket.labels

    def test_jira_priority_mapping(self, tool, mock_history_reader, sample_audit_data):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=["f-001"],
            platform=Platform.JIRA,
        )

        assert result.tickets[0].priority == "Highest"


class TestPrepareTicketsErrors:
    def test_error_when_no_findings_selected(self, tool, mock_history_reader):
        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=[],
            platform=Platform.LINEAR,
        )

        assert result.success is False
        assert result.error == "No findings selected"
        assert result.tickets == []

    def test_error_when_audit_not_found(self, tool, mock_history_reader):
        mock_history_reader.get_audit.return_value = None

        result = tool.prepare_tickets(
            audit_dir_name="nonexistent",
            finding_ids=["f-001"],
            platform=Platform.LINEAR,
        )

        assert result.success is False
        assert "not found" in result.error.lower()

    def test_error_when_no_matching_findings(
        self, tool, mock_history_reader, sample_audit_data
    ):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=["nonexistent-id"],
            platform=Platform.LINEAR,
        )

        assert result.success is False
        assert "No matching findings" in result.error
        assert result.total_findings == 3
        assert result.selected_count == 0

    def test_partial_match_still_succeeds(
        self, tool, mock_history_reader, sample_audit_data
    ):
        mock_history_reader.get_audit.return_value = sample_audit_data

        result = tool.prepare_tickets(
            audit_dir_name="2026-02-18_security",
            finding_ids=["f-001", "nonexistent"],
            platform=Platform.LINEAR,
        )

        assert result.success is True
        assert len(result.tickets) == 1
        assert result.tickets[0].finding_id == "f-001"
