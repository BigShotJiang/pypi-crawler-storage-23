"""Unit tests for SyncStatus."""

import json
import pytest
from datetime import datetime
from pathlib import Path
from unittest.mock import patch, mock_open

from tools.notion_hub.sync_status import SyncStatus, SYNC_STATUS_DIR


class TestSyncStatus:
    """Tests for SyncStatus."""

    def test_to_dict(self) -> None:
        """Test converting to dictionary."""
        status = SyncStatus(
            audit_id="test_audit_123",
            notion_page_id="page_abc",
            notion_page_url="https://notion.so/page_abc",
            sync_timestamp=datetime(2026, 2, 25, 14, 30, 0),
            status="success",
            steps_completed=["publish", "patterns"],
        )

        result = status.to_dict()

        assert result["audit_id"] == "test_audit_123"
        assert result["notion_page_id"] == "page_abc"
        assert result["notion_page_url"] == "https://notion.so/page_abc"
        assert result["sync_timestamp"] == "2026-02-25T14:30:00"
        assert result["status"] == "success"
        assert result["steps_completed"] == ["publish", "patterns"]

    def test_from_dict(self) -> None:
        """Test creating from dictionary."""
        data = {
            "audit_id": "test_audit_123",
            "notion_page_id": "page_abc",
            "notion_page_url": "https://notion.so/page_abc",
            "sync_timestamp": "2026-02-25T14:30:00",
            "status": "success",
            "steps_completed": ["publish"],
        }

        status = SyncStatus.from_dict(data)

        assert status.audit_id == "test_audit_123"
        assert status.notion_page_id == "page_abc"
        assert status.sync_timestamp == datetime(2026, 2, 25, 14, 30, 0)
        assert status.status == "success"

    def test_from_dict_without_timestamp(self) -> None:
        """Test creating from dictionary without timestamp."""
        data = {
            "audit_id": "test_audit",
            "status": "pending",
        }

        status = SyncStatus.from_dict(data)

        assert status.sync_timestamp is None

    def test_get_status_path(self) -> None:
        """Test status file path generation."""
        path = SyncStatus._get_status_path("my_audit_2026")

        assert path == Path(SYNC_STATUS_DIR) / "my_audit_2026.json"

    @patch("pathlib.Path.mkdir")
    def test_save(self, mock_mkdir: patch, tmp_path: Path) -> None:
        """Test saving status to file."""
        with patch("tools.notion_hub.sync_status.SYNC_STATUS_DIR", str(tmp_path)):
            status = SyncStatus(
                audit_id="test_audit",
                status="success",
            )
            status.save()

            saved_file = tmp_path / "test_audit.json"
            assert saved_file.exists()
            with open(saved_file) as f:
                parsed = json.load(f)
            assert parsed["audit_id"] == "test_audit"
            assert parsed["status"] == "success"

    @patch("builtins.open", new_callable=mock_open)
    @patch("pathlib.Path.exists")
    def test_load(
        self,
        mock_exists: patch,
        mock_file: patch,
    ) -> None:
        """Test loading status from file."""
        mock_exists.return_value = True
        mock_file.return_value.read.return_value = json.dumps({
            "audit_id": "test_audit",
            "status": "success",
        })

        status = SyncStatus.load("test_audit")

        assert status is not None
        assert status.audit_id == "test_audit"
        assert status.status == "success"

    @patch("pathlib.Path.exists")
    def test_load_not_found(self, mock_exists: patch) -> None:
        """Test loading non-existent status returns None."""
        mock_exists.return_value = False

        status = SyncStatus.load("nonexistent")

        assert status is None

    def test_mark_in_progress(self) -> None:
        """Test marking status as in progress."""
        status = SyncStatus(audit_id="test")

        with patch.object(status, "save"):
            status.mark_in_progress()

        assert status.status == "in_progress"
        assert status.sync_timestamp is not None
        assert status.error is None

    def test_mark_success(self) -> None:
        """Test marking status as success."""
        status = SyncStatus(audit_id="test")

        with patch.object(status, "save"):
            status.mark_success(page_id="page123", page_url="https://notion.so/page123")

        assert status.status == "success"
        assert status.notion_page_id == "page123"
        assert status.notion_page_url == "https://notion.so/page123"
        assert status.error is None

    def test_mark_failed(self) -> None:
        """Test marking status as failed."""
        status = SyncStatus(audit_id="test")

        with patch.object(status, "save"):
            status.mark_failed("Connection timeout")

        assert status.status == "failed"
        assert status.error == "Connection timeout"

    def test_add_completed_step(self) -> None:
        """Test adding completed step."""
        status = SyncStatus(audit_id="test")

        with patch.object(status, "save"):
            status.add_completed_step("publish")
            status.add_completed_step("patterns")
            status.add_completed_step("publish")

        assert status.steps_completed == ["publish", "patterns"]

    def test_get_or_create_existing(self) -> None:
        """Test get_or_create returns existing status."""
        existing = SyncStatus(audit_id="test", status="success")

        with patch.object(SyncStatus, "load", return_value=existing):
            result = SyncStatus.get_or_create("test")

        assert result.status == "success"

    def test_get_or_create_new(self) -> None:
        """Test get_or_create creates new status."""
        with patch.object(SyncStatus, "load", return_value=None):
            result = SyncStatus.get_or_create("new_audit")

        assert result.audit_id == "new_audit"
        assert result.status == "pending"


class TestSyncStatusDefaults:
    """Tests for SyncStatus default values."""

    def test_default_status(self) -> None:
        """Test default status is pending."""
        status = SyncStatus(audit_id="test")
        assert status.status == "pending"

    def test_default_steps_completed(self) -> None:
        """Test default steps_completed is empty list."""
        status = SyncStatus(audit_id="test")
        assert status.steps_completed == []

    def test_default_optional_fields(self) -> None:
        """Test default optional fields are None."""
        status = SyncStatus(audit_id="test")

        assert status.notion_page_id is None
        assert status.notion_page_url is None
        assert status.sync_timestamp is None
        assert status.error is None
