"""Tests for the github_upload module."""
