from __future__ import annotations

import pytest
from datetime import datetime, timezone

from tools.team_analytics_audit.models import (
    AreaHealth,
    AuditStepResult,
    CollaborationData,
    ComparisonDelta,
    ContributorProfile,
    QualitySignals,
    SustainabilitySignals,
    TeamAuditResult,
    TeamHealthDiagnostic,
    VelocityTrend,
)
from tools.team_analytics_audit.report import TeamAuditReportGenerator


def _make_quality_signals() -> QualitySignals:
    return QualitySignals(
        conventional_commit_rate=0.8,
        avg_message_length=40.0,
        bulk_commit_count=0,
        trivial_commit_count=0,
        revert_count=0,
        fixup_count=0,
        atomic_commit_rate=1.0,
    )


def _make_collaboration() -> CollaborationData:
    return CollaborationData(
        co_authored_commits=0,
        shared_file_authors={},
        cross_area_commits=0,
        merge_commits=0,
    )


def _make_contributor(name: str, email: str, commit_count: int) -> ContributorProfile:
    return ContributorProfile(
        name=name,
        email=email,
        commit_count=commit_count,
        lines_added=100,
        lines_deleted=20,
        files_touched={"src/main.py", "src/utils.py"},
        directories_touched={"src"},
        areas_of_impact={"src": commit_count},
        commit_sizes=[12] * commit_count,
        avg_commit_size=12.0,
        quality_signals=_make_quality_signals(),
        collaboration=_make_collaboration(),
        weekly_activity={"2026-W03": commit_count},
    )


def _make_silo(path: str, owner: str) -> AreaHealth:
    return AreaHealth(
        path=path,
        bus_factor=1,
        primary_owner=owner,
        owner_percentage=1.0,
        total_commits=10,
        contributors=[owner],
        is_knowledge_silo=True,
    )


def _make_sustainability() -> SustainabilitySignals:
    return SustainabilitySignals(
        weekday_distribution={1: 5, 2: 3},
        hour_distribution={10: 4, 14: 4},
        weekend_commit_rate=0.0,
        late_night_commit_rate=0.0,
    )


@pytest.fixture()
def audit_result() -> TeamAuditResult:
    alice = _make_contributor("Alice", "alice@ex.com", 3)
    bob = _make_contributor("Bob", "bob@ex.com", 2)
    silo = _make_silo("src/auth", "Alice")
    health = TeamHealthDiagnostic(
        overall_bus_factor=1,
        workload_gini_index=0.2,
        knowledge_silos=[silo],
        health_status="Needs Attention",
        sustainability_signals=_make_sustainability(),
    )
    velocity = VelocityTrend(
        weekly_commits={"2026-W03": 5},
        weekly_contributors={"2026-W03": 2},
        trajectory="stable",
        comparison_delta=None,
    )
    step = AuditStepResult(
        name="Collect",
        status="executed",
        skip_reason=None,
        duration_ms=50,
    )
    return TeamAuditResult(
        repository_name="my-repo",
        period_start=datetime(2026, 1, 1, tzinfo=timezone.utc),
        period_end=datetime(2026, 1, 31, tzinfo=timezone.utc),
        generated_at=datetime(2026, 2, 1, 12, 0, 0, tzinfo=timezone.utc),
        steps_executed=[step],
        total_commits=5,
        contributors=[alice, bob],
        area_health=[silo],
        team_health=health,
        velocity=velocity,
        recommendations=["Reduce knowledge silos.", "Keep it up!"],
    )


class TestTeamAuditReportGenerator:
    def test_generate_returns_string(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert isinstance(report, str)

    def test_report_contains_repository_name(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "my-repo" in report

    def test_report_contains_contributor_names(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Alice" in report
        assert "Bob" in report

    def test_report_contains_team_overview_section(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Team Overview" in report

    def test_report_contains_individual_contributor_summaries_section(
        self, audit_result: TeamAuditResult
    ):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Individual Contributor Summaries" in report

    def test_report_contains_collaboration_map_section(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Collaboration Map" in report

    def test_report_contains_risks_and_bottlenecks_section(
        self, audit_result: TeamAuditResult
    ):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Risks & Bottlenecks" in report

    def test_report_contains_velocity_and_trends_section(
        self, audit_result: TeamAuditResult
    ):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Velocity & Trends" in report

    def test_report_contains_recommendations_section(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Recommendations" in report

    def test_author_highlight_adds_star(self, audit_result: TeamAuditResult):
        report = TeamAuditReportGenerator().generate(audit_result, author="Alice")
        assert "⭐" in report

    def test_author_highlight_not_present_without_author(
        self, audit_result: TeamAuditResult
    ):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "⭐" not in report

    def test_comparison_section_appears_when_delta_present(
        self, audit_result: TeamAuditResult
    ):
        audit_result.velocity.comparison_delta = ComparisonDelta(
            commit_count_delta=10.0,
            contributor_count_delta=5.0,
            avg_commit_size_delta=-3.0,
            collaboration_delta=0.0,
        )
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Period Comparison" in report

    def test_comparison_section_absent_without_delta(
        self, audit_result: TeamAuditResult
    ):
        report = TeamAuditReportGenerator().generate(audit_result)
        assert "Period Comparison" not in report
