from datetime import datetime, timezone
import pytest
from tools.team_analytics_audit.period import PeriodParser


class TestPeriodParser:
    def setup_method(self):
        self.parser = PeriodParser()

    def test_default_period_is_last_30_days(self):
        start, end = self.parser.parse(None)
        delta = end - start
        assert delta.days == 29

    def test_last_n_days_format(self):
        start, end = self.parser.parse("last_7_days")
        delta = end - start
        assert delta.days == 6

    def test_last_30_days_explicit(self):
        start, end = self.parser.parse("last_30_days")
        delta = end - start
        assert delta.days == 29

    def test_last_90_days(self):
        start, end = self.parser.parse("last_90_days")
        delta = end - start
        assert delta.days == 89

    def test_date_range_format(self):
        start, end = self.parser.parse("2025-12-01..2025-12-31")
        assert start.year == 2025
        assert start.month == 12
        assert start.day == 1
        assert end.year == 2025
        assert end.month == 12
        assert end.day == 31

    def test_date_range_start_before_end(self):
        start, end = self.parser.parse("2025-01-01..2025-06-30")
        assert start < end

    def test_invalid_period_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid period format"):
            self.parser.parse("last_sprint")

    def test_invalid_date_range_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid period format"):
            self.parser.parse("2025-12-31..2025-01-01")

    def test_malformed_period_raises_value_error(self):
        with pytest.raises(ValueError, match="Invalid period format"):
            self.parser.parse("2025-01-01/2025-12-31")

    def test_result_is_utc_aware(self):
        start, end = self.parser.parse(None)
        assert start.tzinfo == timezone.utc
        assert end.tzinfo == timezone.utc

    def test_date_range_end_has_end_of_day_time(self):
        _, end = self.parser.parse("2025-12-01..2025-12-31")
        assert end.hour == 23
        assert end.minute == 59
        assert end.second == 59

    def test_date_range_start_has_midnight(self):
        start, _ = self.parser.parse("2025-12-01..2025-12-31")
        assert start.hour == 0
        assert start.minute == 0
        assert start.second == 0
