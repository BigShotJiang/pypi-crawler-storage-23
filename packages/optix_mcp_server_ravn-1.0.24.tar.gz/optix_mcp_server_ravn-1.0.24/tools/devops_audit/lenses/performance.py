"""Performance & Cost lens for DevOps audit."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class PerformanceLens(BaseLens):
    """Performance & Cost lens focusing on build times, caching, runner costs."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.PERFORMANCE

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.PERFORMANCE,
            display_name="Performance & Cost",
            description="Focus on build times, caching, and runner costs",
            docker_rules=[
                LensRule(
                    id="PERF-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Layer Cache Invalidation",
                    description="Poor ordering causing cache invalidation",
                    severity_default="medium",
                    check_guidance=[
                        "Check if COPY of package.json before npm install",
                        "Verify frequently changing files copied last",
                        "Look for COPY . before dependency install",
                    ],
                ),
                LensRule(
                    id="PERF-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing Multi-Stage Build",
                    description="Single-stage build with dev dependencies",
                    severity_default="medium",
                    check_guidance=[
                        "Check for multi-stage build pattern",
                        "Verify build tools not in final image",
                        "Look for devDependencies in production image",
                    ],
                ),
                LensRule(
                    id="PERF-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Large Base Image",
                    description="Using full OS image instead of slim/alpine",
                    severity_default="low",
                    check_guidance=[
                        "Check base image for -slim or -alpine variants",
                        "Verify minimal base image where possible",
                        "Look for debian/ubuntu when alpine would work",
                    ],
                ),
                LensRule(
                    id="PERF-D004",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Missing .dockerignore",
                    description="No .dockerignore causing large contexts",
                    severity_default="medium",
                    check_guidance=[
                        "Check for .dockerignore file presence",
                        "Verify node_modules, .git excluded",
                        "Look for unnecessary files in build context",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="PERF-C001",
                    category=DevOpsCategory.CICD,
                    name="Missing Cache Action",
                    description="No dependency caching configured",
                    severity_default="medium",
                    check_guidance=[
                        "Check for actions/cache usage",
                        "Verify npm/yarn cache configured",
                        "Look for cache key based on lockfile hash",
                    ],
                ),
                LensRule(
                    id="PERF-C002",
                    category=DevOpsCategory.CICD,
                    name="Sequential Jobs",
                    description="Jobs that could run in parallel",
                    severity_default="low",
                    check_guidance=[
                        "Check for unnecessary job dependencies",
                        "Verify independent jobs use matrix or parallel",
                        "Look for lint/test/build that could parallelize",
                    ],
                ),
                LensRule(
                    id="PERF-C003",
                    category=DevOpsCategory.CICD,
                    name="No Job Timeout",
                    description="Missing timeout-minutes on jobs",
                    severity_default="medium",
                    check_guidance=[
                        "Check for timeout-minutes on each job",
                        "Verify reasonable timeout values",
                        "Look for hung jobs without limits",
                    ],
                ),
                LensRule(
                    id="PERF-C004",
                    category=DevOpsCategory.CICD,
                    name="Large Artifact Retention",
                    description="Artifacts retained longer than needed",
                    severity_default="low",
                    check_guidance=[
                        "Check upload-artifact retention-days",
                        "Verify only necessary artifacts uploaded",
                        "Look for large files in artifacts",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="PERF-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="npm install vs npm ci",
                    description="Using npm install instead of npm ci in CI",
                    severity_default="medium",
                    check_guidance=[
                        "Check CI scripts for npm install usage",
                        "Verify npm ci used in CI environments",
                        "Look for missing --frozen-lockfile flag",
                    ],
                ),
                LensRule(
                    id="PERF-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Unused Dependencies",
                    description="Dependencies not imported in code",
                    severity_default="low",
                    check_guidance=[
                        "Check for dependencies not in import statements",
                        "Verify peer/optional dependencies are needed",
                        "Look for deprecated or abandoned packages",
                    ],
                ),
                LensRule(
                    id="PERF-P003",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Large Transitive Dependencies",
                    description="Heavy packages bloating bundle size",
                    severity_default="low",
                    check_guidance=[
                        "Check for moment.js, lodash full imports",
                        "Verify tree-shaking friendly packages used",
                        "Look for lighter alternatives available",
                    ],
                ),
                LensRule(
                    id="PERF-P004",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Missing Optional Optimization",
                    description="Not using optional dependency features",
                    severity_default="low",
                    check_guidance=[
                        "Check for optional peer dependencies usage",
                        "Verify build-time only deps are devDependencies",
                        "Look for test deps in production bundle",
                    ],
                ),
            ],
        )
