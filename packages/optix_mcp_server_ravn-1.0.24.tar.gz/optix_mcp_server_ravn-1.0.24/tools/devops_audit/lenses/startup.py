"""Startup/Agile lens for DevOps audit."""

from tools.devops_audit.domains import DevOpsCategory, DevOpsLens
from tools.devops_audit.lenses.base import BaseLens, LensConfig, LensRule


class StartupLens(BaseLens):
    """Startup/Agile lens focusing on quick wins and pragmatic defaults."""

    @property
    def lens_type(self) -> DevOpsLens:
        return DevOpsLens.STARTUP

    def get_config(self) -> LensConfig:
        return LensConfig(
            lens=DevOpsLens.STARTUP,
            display_name="Startup/Agile",
            description="Focus on quick wins and pragmatic defaults",
            docker_rules=[
                LensRule(
                    id="START-D001",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Add USER Directive",
                    description="Quick win: Add non-root USER",
                    severity_default="high",
                    check_guidance=[
                        "Add USER directive with non-root user",
                        "Create user with useradd if needed",
                        "Ensure correct file ownership",
                    ],
                ),
                LensRule(
                    id="START-D002",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Pin Base Image Tag",
                    description="Quick win: Replace :latest with version",
                    severity_default="medium",
                    check_guidance=[
                        "Replace :latest with specific version tag",
                        "Use node:20-alpine instead of node:latest",
                        "Document chosen version in comments",
                    ],
                ),
                LensRule(
                    id="START-D003",
                    category=DevOpsCategory.DOCKERFILE,
                    name="Add HEALTHCHECK",
                    description="Quick win: Add basic health check",
                    severity_default="medium",
                    check_guidance=[
                        "Add HEALTHCHECK with curl or wget",
                        "Point to /health or /healthz endpoint",
                        "Set reasonable interval (30s) and timeout (5s)",
                    ],
                ),
            ],
            cicd_rules=[
                LensRule(
                    id="START-C001",
                    category=DevOpsCategory.CICD,
                    name="Add Permissions Block",
                    description="Quick win: Add minimal permissions",
                    severity_default="medium",
                    check_guidance=[
                        "Add permissions: block at workflow level",
                        "Start with read-only: contents: read",
                        "Add only needed permissions per job",
                    ],
                ),
                LensRule(
                    id="START-C002",
                    category=DevOpsCategory.CICD,
                    name="Pin Action Versions",
                    description="Quick win: Pin to major version tags",
                    severity_default="medium",
                    check_guidance=[
                        "Replace @main/@master with @v4 or similar",
                        "Use specific version tags for stability",
                        "SHA pinning for high-security projects",
                    ],
                ),
                LensRule(
                    id="START-C003",
                    category=DevOpsCategory.CICD,
                    name="Add Basic Caching",
                    description="Quick win: Enable dependency caching",
                    severity_default="low",
                    check_guidance=[
                        "Add actions/cache for node_modules",
                        "Use setup-node cache: npm option",
                        "Key on package-lock.json hash",
                    ],
                ),
            ],
            dependency_rules=[
                LensRule(
                    id="START-P001",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Use Lockfile",
                    description="Quick win: Commit lockfile",
                    severity_default="high",
                    check_guidance=[
                        "Run npm install to generate lockfile",
                        "Commit package-lock.json to repo",
                        "Remove from .gitignore if present",
                    ],
                ),
                LensRule(
                    id="START-P002",
                    category=DevOpsCategory.DEPENDENCY,
                    name="Remove Wildcard Versions",
                    description="Quick win: Replace * with ^version",
                    severity_default="high",
                    check_guidance=[
                        "Replace * with current installed version",
                        "Use ^ for minor version flexibility",
                        "Run npm update to get latest compatible",
                    ],
                ),
            ],
        )
