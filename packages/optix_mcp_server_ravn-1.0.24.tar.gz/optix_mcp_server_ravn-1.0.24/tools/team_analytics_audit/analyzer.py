from __future__ import annotations

import re
import statistics
from datetime import datetime
from pathlib import Path

from tools.team_analytics_audit.models import (
    AreaHealth,
    CollaborationData,
    ComparisonDelta,
    ContributorProfile,
    QualitySignals,
    RawCommit,
    SustainabilitySignals,
    TeamAuditResult,
    TeamHealthDiagnostic,
    VelocityTrend,
    AuditStepResult,
)

CONVENTIONAL_PATTERN = re.compile(
    r"^(feat|fix|docs|style|refactor|perf|test|chore|build|ci|revert)"
    r"(\(.+\))?!?:"
)
BULK_COMMIT_THRESHOLD = 500
TRIVIAL_COMMIT_THRESHOLD = 5
ATOMIC_FILE_THRESHOLD = 3
HEALTHY_GINI_THRESHOLD = 0.5
AT_RISK_GINI_THRESHOLD = 0.75
WEEKEND_DAYS = {5, 6}
LATE_NIGHT_START = 22
LATE_NIGHT_END = 6
ACCELERATING_THRESHOLD = 0.1
DECELERATING_THRESHOLD = -0.1


def _iso_week(dt: datetime) -> str:
    return dt.strftime("%G-W%V")


def _top_dir(file_path: str) -> str:
    parts = Path(file_path).parts
    return parts[0] if parts else "."


def _gini(values: list[int]) -> float:
    if not values or len(values) == 1:
        return 0.0
    n = len(values)
    sorted_vals = sorted(values)
    total = sum(sorted_vals)
    if total == 0:
        return 0.0
    cumulative = sum(
        (i + 1) * v for i, v in enumerate(sorted_vals)
    )
    return (2 * cumulative) / (n * total) - (n + 1) / n


def _measure_contributions(
    commits: list[RawCommit],
) -> list[ContributorProfile]:
    profiles: dict[str, dict] = {}

    for commit in commits:
        key = commit.author_email or commit.author_name
        if key not in profiles:
            profiles[key] = {
                "name": commit.author_name,
                "email": commit.author_email,
                "commits": [],
                "files_touched": set(),
                "dirs_touched": set(),
                "areas": {},
                "weekly": {},
            }
        p = profiles[key]
        p["commits"].append(commit)
        week = _iso_week(commit.timestamp)
        p["weekly"][week] = p["weekly"].get(week, 0) + 1

        for fc in commit.files_changed:
            p["files_touched"].add(fc.file_path)
            top = _top_dir(fc.file_path)
            p["dirs_touched"].add(top)
            p["areas"][top] = p["areas"].get(top, 0) + 1

    result = []
    for data in profiles.values():
        contributor_commits: list[RawCommit] = data["commits"]
        commit_sizes = [
            sum(fc.additions + fc.deletions for fc in c.files_changed)
            for c in contributor_commits
        ]
        avg_size = (
            statistics.mean(commit_sizes) if commit_sizes else 0.0
        )
        quality = _assess_quality(contributor_commits)
        collab = _build_collaboration(
            contributor_commits, data["files_touched"], profiles
        )
        result.append(
            ContributorProfile(
                name=data["name"],
                email=data["email"],
                commit_count=len(contributor_commits),
                lines_added=sum(
                    fc.additions
                    for c in contributor_commits
                    for fc in c.files_changed
                ),
                lines_deleted=sum(
                    fc.deletions
                    for c in contributor_commits
                    for fc in c.files_changed
                ),
                files_touched=data["files_touched"],
                directories_touched=data["dirs_touched"],
                areas_of_impact=data["areas"],
                commit_sizes=commit_sizes,
                avg_commit_size=avg_size,
                quality_signals=quality,
                collaboration=collab,
                weekly_activity=data["weekly"],
            )
        )
    return result


def _assess_quality(commits: list[RawCommit]) -> QualitySignals:
    if not commits:
        return QualitySignals(
            conventional_commit_rate=0.0,
            avg_message_length=0.0,
            bulk_commit_count=0,
            trivial_commit_count=0,
            revert_count=0,
            fixup_count=0,
            atomic_commit_rate=0.0,
        )
    conventional = sum(
        1 for c in commits if CONVENTIONAL_PATTERN.match(c.subject)
    )
    bulk = sum(
        1 for c in commits
        if sum(
            fc.additions + fc.deletions for fc in c.files_changed
        ) > BULK_COMMIT_THRESHOLD
    )
    trivial = sum(
        1 for c in commits
        if sum(
            fc.additions + fc.deletions for fc in c.files_changed
        ) < TRIVIAL_COMMIT_THRESHOLD
    )
    reverts = sum(
        1 for c in commits if "revert" in c.subject.lower()
    )
    fixups = sum(
        1 for c in commits
        if any(
            kw in c.subject.lower()
            for kw in ("fixup", "oops", "fix:")
        )
    )
    atomic = sum(
        1 for c in commits
        if len(c.files_changed) <= ATOMIC_FILE_THRESHOLD
    )
    n = len(commits)
    return QualitySignals(
        conventional_commit_rate=conventional / n,
        avg_message_length=statistics.mean(
            len(c.subject) for c in commits
        ),
        bulk_commit_count=bulk,
        trivial_commit_count=trivial,
        revert_count=reverts,
        fixup_count=fixups,
        atomic_commit_rate=atomic / n,
    )


def _build_collaboration(
    commits: list[RawCommit],
    files_touched: set[str],
    all_profiles: dict[str, dict],
) -> CollaborationData:
    co_authored = sum(1 for c in commits if c.co_authors)
    merges = sum(1 for c in commits if c.is_merge)

    shared: dict[str, int] = {}
    for other_key, other_data in all_profiles.items():
        other_files: set[str] = other_data["files_touched"]
        overlap = len(files_touched & other_files)
        if overlap > 0 and other_data["name"] != (
            commits[0].author_name if commits else ""
        ):
            shared[other_data["name"]] = overlap

    primary_dir = (
        max(
            commits[0].author_email,
            key=lambda k: all_profiles.get(
                commits[0].author_email, {}
            ).get("areas", {}).get(k, 0),
        )
        if commits
        and all_profiles.get(commits[0].author_email, {}).get("areas")
        else None
    )
    cross_area = 0
    if primary_dir:
        cross_area = sum(
            1 for c in commits
            if not any(
                _top_dir(fc.file_path) == primary_dir
                for fc in c.files_changed
            )
        )

    return CollaborationData(
        co_authored_commits=co_authored,
        shared_file_authors=shared,
        cross_area_commits=cross_area,
        merge_commits=merges,
    )


def _map_area_health(
    commits: list[RawCommit],
    contributors: list[ContributorProfile],
) -> list[AreaHealth]:
    area_commits: dict[str, dict[str, int]] = {}

    for commit in commits:
        for fc in commit.files_changed:
            top = _top_dir(fc.file_path)
            if top not in area_commits:
                area_commits[top] = {}
            author = commit.author_name
            area_commits[top][author] = (
                area_commits[top].get(author, 0) + 1
            )

    areas = []
    for path, author_counts in area_commits.items():
        total = sum(author_counts.values())
        primary = max(author_counts, key=lambda k: author_counts[k])
        owner_pct = author_counts[primary] / total if total else 0.0
        bus_factor = len(author_counts)
        areas.append(
            AreaHealth(
                path=path,
                bus_factor=bus_factor,
                primary_owner=primary,
                owner_percentage=owner_pct,
                total_commits=total,
                contributors=list(author_counts.keys()),
                is_knowledge_silo=bus_factor == 1,
            )
        )
    return areas


def _diagnose_health(
    contributors: list[ContributorProfile],
    area_health: list[AreaHealth],
    commits: list[RawCommit],
) -> TeamHealthDiagnostic:
    commit_counts = [c.commit_count for c in contributors]
    gini = _gini(commit_counts)

    silos = [a for a in area_health if a.is_knowledge_silo]
    min_bus_factor = (
        min(a.bus_factor for a in area_health) if area_health else 1
    )

    if gini < HEALTHY_GINI_THRESHOLD and not silos:
        status = "Healthy"
    elif gini >= AT_RISK_GINI_THRESHOLD or min_bus_factor == 1:
        status = "At Risk"
    else:
        status = "Needs Attention"

    sustainability = _compute_sustainability(commits)

    return TeamHealthDiagnostic(
        overall_bus_factor=min_bus_factor,
        workload_gini_index=round(gini, 4),
        knowledge_silos=silos,
        health_status=status,
        sustainability_signals=sustainability,
    )


def _compute_sustainability(
    commits: list[RawCommit],
) -> SustainabilitySignals:
    weekday_dist: dict[int, int] = {}
    hour_dist: dict[int, int] = {}
    weekend_count = 0
    late_night_count = 0
    total = len(commits)

    for commit in commits:
        day = commit.timestamp.isoweekday()
        hour = commit.timestamp.hour
        weekday_dist[day] = weekday_dist.get(day, 0) + 1
        hour_dist[hour] = hour_dist.get(hour, 0) + 1
        if day in WEEKEND_DAYS:
            weekend_count += 1
        if hour >= LATE_NIGHT_START or hour < LATE_NIGHT_END:
            late_night_count += 1

    return SustainabilitySignals(
        weekday_distribution=weekday_dist,
        hour_distribution=hour_dist,
        weekend_commit_rate=weekend_count / total if total else 0.0,
        late_night_commit_rate=late_night_count / total if total else 0.0,
    )


def _analyze_velocity(
    commits: list[RawCommit],
    contributors: list[ContributorProfile],
) -> VelocityTrend:
    weekly_commits: dict[str, int] = {}
    weekly_contributor_sets: dict[str, set[str]] = {}

    for commit in commits:
        week = _iso_week(commit.timestamp)
        weekly_commits[week] = weekly_commits.get(week, 0) + 1
        if week not in weekly_contributor_sets:
            weekly_contributor_sets[week] = set()
        weekly_contributor_sets[week].add(commit.author_name)

    weekly_contributors = {
        week: len(authors)
        for week, authors in weekly_contributor_sets.items()
    }

    trajectory = _compute_trajectory(weekly_commits)

    return VelocityTrend(
        weekly_commits=weekly_commits,
        weekly_contributors=weekly_contributors,
        trajectory=trajectory,
    )


def _compute_trajectory(weekly_commits: dict[str, int]) -> str:
    if len(weekly_commits) < 2:
        return "stable"
    weeks = sorted(weekly_commits.keys())
    half = len(weeks) // 2
    first_half = [weekly_commits[w] for w in weeks[:half]]
    second_half = [weekly_commits[w] for w in weeks[half:]]
    avg_first = statistics.mean(first_half) if first_half else 0
    avg_second = statistics.mean(second_half) if second_half else 0
    if avg_first == 0:
        return "stable"
    change = (avg_second - avg_first) / avg_first
    if change > ACCELERATING_THRESHOLD:
        return "accelerating"
    if change < DECELERATING_THRESHOLD:
        return "decelerating"
    return "stable"


def _generate_recommendations(
    contributors: list[ContributorProfile],
    area_health: list[AreaHealth],
    team_health: TeamHealthDiagnostic,
    velocity: VelocityTrend,
) -> list[str]:
    recs = []

    silos = team_health.knowledge_silos
    if silos:
        silo_paths = ", ".join(a.path for a in silos[:3])
        recs.append(
            f"Reduce knowledge silos in: {silo_paths}. "
            "Schedule pair programming or cross-training sessions."
        )

    if team_health.workload_gini_index >= AT_RISK_GINI_THRESHOLD:
        recs.append(
            "Workload is heavily concentrated. Consider redistributing "
            "tasks to improve team resilience."
        )

    high_bulk = [
        c for c in contributors
        if c.quality_signals.bulk_commit_count > 2
    ]
    if high_bulk:
        names = ", ".join(c.name for c in high_bulk[:3])
        recs.append(
            f"Contributors with frequent large commits ({names}): "
            "encourage smaller, atomic commits."
        )

    if velocity.trajectory == "decelerating":
        recs.append(
            "Velocity is decelerating. Investigate blockers, "
            "tech debt, or team capacity issues."
        )

    high_weekend = (
        team_health.sustainability_signals.weekend_commit_rate > 0.2
    )
    high_late = (
        team_health.sustainability_signals.late_night_commit_rate > 0.2
    )
    if high_weekend or high_late:
        recs.append(
            "Elevated off-hours commit activity detected. "
            "Review team workload and sustainability."
        )

    if not recs:
        recs.append(
            "Team health looks good. Continue current practices."
        )

    return recs


def _compute_comparison_delta(
    base_commits: list[RawCommit],
    compare_commits: list[RawCommit],
) -> ComparisonDelta:
    def pct_change(base: float, compare: float) -> float:
        if base == 0:
            return 0.0
        return round((compare - base) / base * 100, 2)

    base_count = len(base_commits)
    compare_count = len(compare_commits)

    base_authors = {c.author_email for c in base_commits}
    compare_authors = {c.author_email for c in compare_commits}

    base_sizes = [
        sum(fc.additions + fc.deletions for fc in c.files_changed)
        for c in base_commits
    ]
    compare_sizes = [
        sum(fc.additions + fc.deletions for fc in c.files_changed)
        for c in compare_commits
    ]
    base_avg_size = statistics.mean(base_sizes) if base_sizes else 0.0
    compare_avg_size = (
        statistics.mean(compare_sizes) if compare_sizes else 0.0
    )

    base_collab = sum(
        1 for c in base_commits if c.co_authors or c.is_merge
    )
    compare_collab = sum(
        1 for c in compare_commits if c.co_authors or c.is_merge
    )

    return ComparisonDelta(
        commit_count_delta=pct_change(base_count, compare_count),
        contributor_count_delta=pct_change(
            len(base_authors), len(compare_authors)
        ),
        avg_commit_size_delta=pct_change(base_avg_size, compare_avg_size),
        collaboration_delta=pct_change(base_collab, compare_collab),
    )


class TeamAnalyzer:
    def analyze(
        self,
        commits: list[RawCommit],
        repository_name: str,
        period_start: datetime,
        period_end: datetime,
        compare_commits: list[RawCommit] | None = None,
    ) -> TeamAuditResult:
        contributors = _measure_contributions(commits)
        area_health = _map_area_health(commits, contributors)
        team_health = _diagnose_health(contributors, area_health, commits)
        velocity = _analyze_velocity(commits, contributors)
        recommendations = _generate_recommendations(
            contributors, area_health, team_health, velocity
        )

        if compare_commits is not None:
            velocity.comparison_delta = _compute_comparison_delta(
                commits, compare_commits
            )

        return TeamAuditResult(
            repository_name=repository_name,
            period_start=period_start,
            period_end=period_end,
            generated_at=datetime.now(),
            steps_executed=[],
            total_commits=len(commits),
            contributors=contributors,
            area_health=area_health,
            team_health=team_health,
            velocity=velocity,
            recommendations=recommendations,
        )
