import html
from tools.findings_to_tickets.models import Platform

MAX_TITLE_LENGTH = 200


def sanitize_text(text: str) -> str:
    """Sanitize text to prevent injection attacks."""
    if not isinstance(text, str):
        return ""
    sanitized = html.escape(text)
    sanitized = sanitized.replace("\x00", "")
    return sanitized

SEVERITY_PRIORITY_MAP: dict[str, dict[Platform, str]] = {
    "critical": {Platform.LINEAR: "1", Platform.JIRA: "Highest", Platform.NOTION: "1"},
    "high": {Platform.LINEAR: "2", Platform.JIRA: "High", Platform.NOTION: "2"},
    "medium": {Platform.LINEAR: "3", Platform.JIRA: "Medium", Platform.NOTION: "3"},
    "low": {Platform.LINEAR: "4", Platform.JIRA: "Low", Platform.NOTION: "4"},
    "info": {Platform.LINEAR: "0", Platform.JIRA: "Lowest", Platform.NOTION: "0"},
}


def format_finding_title(finding: dict[str, object], max_length: int = MAX_TITLE_LENGTH) -> str:
    severity = sanitize_text(str(finding.get("severity", "info"))).upper()
    category = sanitize_text(str(finding.get("category", "Unknown")))
    description = sanitize_text(str(finding.get("description", "")))

    prefix = f"[{severity}] {category}: "
    available_length = max_length - len(prefix) - 3

    if available_length <= 0:
        return prefix[:max_length]

    first_line = description.split("\n")[0].strip()

    if len(first_line) <= available_length:
        return f"{prefix}{first_line}"

    return f"{prefix}{first_line[:available_length]}..."


def format_finding_description(
    finding: dict[str, object],
    audit_info: dict[str, str],
) -> str:
    severity = sanitize_text(str(finding.get("severity", "info")))
    category = sanitize_text(str(finding.get("category", "Unknown")))
    description = sanitize_text(str(finding.get("description", "No description provided")))
    affected_files = finding.get("affected_files", [])
    remediation = sanitize_text(str(finding.get("remediation", "")))
    lens = sanitize_text(audit_info.get("lens", "security"))
    date = sanitize_text(audit_info.get("date", "unknown date"))

    files_section = ""
    if affected_files:
        sanitized_files = [sanitize_text(str(f)) for f in affected_files]
        files_list = "\n".join(f"- `{f}`" for f in sanitized_files)
        files_section = f"## Affected Files\n\n{files_list}\n\n"

    remediation_section = ""
    if remediation:
        remediation_section = f"## Remediation\n\n{remediation}\n\n"

    return f"""## Finding Details

**Severity**: {severity}
**Category**: {category}

## Description

{description}

{files_section}{remediation_section}---
*Created from Optix {lens} audit on {date}*"""


def severity_to_priority(severity: str, platform: Platform) -> str:
    normalized = severity.lower().strip()
    priority_map = SEVERITY_PRIORITY_MAP.get(normalized)

    if priority_map is None:
        default_map = SEVERITY_PRIORITY_MAP["info"]
        return default_map[platform]

    return priority_map[platform]
