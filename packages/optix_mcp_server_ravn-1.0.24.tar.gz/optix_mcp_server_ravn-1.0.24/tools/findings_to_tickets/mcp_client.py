import json
import logging
import os
import subprocess
import threading
import urllib.request
import urllib.error
from dataclasses import dataclass, field

from tools.findings_to_tickets.mcp_config import MCPServerConfig, get_server_config
from tools.findings_to_tickets.models import TicketData, TicketResult

logger = logging.getLogger(__name__)

LINEAR_GRAPHQL_URL = "https://api.linear.app/graphql"


class MCPSession:
    def __init__(self, config: MCPServerConfig):
        self.config = config
        self.process: subprocess.Popen | None = None
        self.request_id = 0
        self._lock = threading.Lock()
        self._initialized = False
        self._read_buffer = ""

    def start(self) -> bool:
        if self.process is not None:
            return True

        env = os.environ.copy()
        env.update(self.config.env)

        cmd = [self.config.command] + self.config.args

        try:
            self.process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                bufsize=0,
            )
            return self._initialize()
        except FileNotFoundError:
            logger.error(f"MCP server command not found: {self.config.command}")
            return False
        except Exception as e:
            logger.error(f"Failed to start MCP server: {e}")
            return False

    def _initialize(self) -> bool:
        if self._initialized:
            return True

        response = self._send_request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "optix", "version": "1.0.0"},
            },
        )

        if response and not response.get("error"):
            self._initialized = True
            self._send_notification("notifications/initialized", {})
            return True

        return False

    def _send_notification(self, method: str, params: dict) -> None:
        if not self.process or not self.process.stdin:
            return

        notification = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }

        try:
            message = json.dumps(notification) + "\n"
            self.process.stdin.write(message.encode())
            self.process.stdin.flush()
        except Exception as e:
            logger.debug(f"Failed to send notification: {e}")

    def _send_request(self, method: str, params: dict) -> dict:
        if not self.process or not self.process.stdin or not self.process.stdout:
            return {"error": "MCP session not started"}

        with self._lock:
            self.request_id += 1
            request_id = self.request_id

            request = {
                "jsonrpc": "2.0",
                "id": request_id,
                "method": method,
                "params": params,
            }

            try:
                message = json.dumps(request) + "\n"
                self.process.stdin.write(message.encode())
                self.process.stdin.flush()

                return self._read_response(request_id)
            except Exception as e:
                logger.error(f"MCP request failed: {e}")
                return {"error": str(e)}

    def _read_response(self, expected_id: int, timeout: float = 30.0) -> dict:
        if not self.process or not self.process.stdout:
            return {"error": "No stdout available"}

        import select

        start_time = __import__("time").time()

        while True:
            elapsed = __import__("time").time() - start_time
            if elapsed >= timeout:
                logger.error(f"MCP response timeout after {timeout}s for request_id={expected_id}")
                return {"error": "Response timeout"}

            remaining = timeout - elapsed
            ready, _, _ = select.select([self.process.stdout], [], [], min(0.1, remaining))

            if ready:
                try:
                    chunk = self.process.stdout.read(4096)
                    if chunk:
                        with self._lock:
                            self._read_buffer += chunk.decode("utf-8", errors="replace")
                except Exception as e:
                    logger.debug(f"Read error: {e}")
                    continue

            with self._lock:
                while "\n" in self._read_buffer:
                    line, self._read_buffer = self._read_buffer.split("\n", 1)
                    line = line.strip()
                    if not line:
                        continue

                    try:
                        response = json.loads(line)
                        if response.get("id") == expected_id:
                            if "error" in response:
                                error_msg = response["error"].get("message", str(response["error"]))
                                logger.error(f"MCP error response: {error_msg}")
                                return {"error": error_msg}
                            return response.get("result", {})
                    except json.JSONDecodeError as e:
                        logger.debug(f"Failed to parse MCP response: {line[:100]}, error={e}")
                        continue

    def call_tool(self, tool_name: str, arguments: dict) -> dict:
        if not self._initialized:
            return {"error": "MCP session not initialized"}

        return self._send_request("tools/call", {"name": tool_name, "arguments": arguments})

    def close(self) -> None:
        if self.process:
            try:
                if self.process.stdin:
                    self.process.stdin.close()
            except Exception as e:
                logger.debug(f"Error closing stdin: {e}")

            try:
                if self.process.stdout:
                    self.process.stdout.close()
            except Exception as e:
                logger.debug(f"Error closing stdout: {e}")

            try:
                if self.process.stderr:
                    self.process.stderr.close()
            except Exception as e:
                logger.debug(f"Error closing stderr: {e}")

            try:
                self.process.terminate()
                self.process.wait(timeout=5)
                logger.debug("MCP process terminated gracefully")
            except subprocess.TimeoutExpired:
                logger.warning("MCP process did not terminate, killing forcefully")
                try:
                    self.process.kill()
                    self.process.wait(timeout=2)
                except Exception as e:
                    logger.error(f"Failed to kill MCP process: {e}")
            except Exception as e:
                logger.error(f"Error terminating MCP process: {e}")
                try:
                    self.process.kill()
                except Exception as kill_error:
                    logger.error(f"Failed to kill MCP process: {kill_error}")

            self.process = None
            self._initialized = False

    def __enter__(self) -> "MCPSession":
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


@dataclass
class MCPClient:
    platform: str
    config: MCPServerConfig
    _session: MCPSession | None = field(default=None, repr=False)

    @classmethod
    def for_platform(cls, platform: str) -> "MCPClient | None":
        config = get_server_config(platform)
        if not config:
            return None
        return cls(platform=platform, config=config)

    def _get_session(self) -> MCPSession | None:
        if self._session is None:
            self._session = MCPSession(self.config)
            if not self._session.start():
                self._session = None
                return None

        return self._session

    def close(self) -> None:
        if self._session:
            self._session.close()
            self._session = None

    def _get_linear_token(self) -> str:
        return self.config.env.get("LINEAR_ACCESS_TOKEN", "")

    def _linear_graphql(self, query: str, variables: dict | None = None) -> dict:
        token = self._get_linear_token()
        if not token:
            return {"error": "LINEAR_ACCESS_TOKEN not configured"}

        payload = {"query": query}
        if variables:
            payload["variables"] = variables

        req = urllib.request.Request(
            LINEAR_GRAPHQL_URL,
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": token,
            },
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                return json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")[:200]
            return {"error": f"HTTP {e.code}: {error_body}"}
        except Exception as e:
            return {"error": str(e)}

    def get_teams(self) -> list[dict[str, str]]:
        if self.platform == "linear":
            return self._get_linear_teams_direct()
        return []

    def _get_linear_teams_direct(self) -> list[dict[str, str]]:
        query = "{ teams { nodes { id name key } } }"
        result = self._linear_graphql(query)

        if "error" in result:
            logger.error(f"Failed to get teams: {result['error']}")
            return []

        if "errors" in result:
            logger.error(f"GraphQL error: {result['errors']}")
            return []

        teams = result.get("data", {}).get("teams", {}).get("nodes", [])
        return [{"id": t["id"], "name": t["name"], "key": t["key"]} for t in teams]

    def create_issue(self, ticket: TicketData, project_id: str) -> TicketResult:
        if self.platform == "linear":
            return self._create_linear_issue(ticket, project_id)
        elif self.platform == "jira":
            return self._create_jira_issue(ticket, project_id)
        else:
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=f"Unknown platform: {self.platform}",
            )

    def _create_linear_issue(self, ticket: TicketData, team_id: str) -> TicketResult:
        return self._create_linear_issue_direct(ticket, team_id)

    def _create_linear_issue_direct(self, ticket: TicketData, team_id: str) -> TicketResult:
        priority_map = {"1": 1, "2": 2, "3": 3, "4": 4}
        priority = priority_map.get(ticket.priority, 3)

        query = """
        mutation CreateIssue($teamId: String!, $title: String!, $description: String, $priority: Int) {
            issueCreate(input: {teamId: $teamId, title: $title, description: $description, priority: $priority}) {
                success
                issue {
                    id
                    identifier
                    url
                }
            }
        }
        """

        variables = {
            "teamId": team_id,
            "title": ticket.title[:200],
            "description": ticket.description,
            "priority": priority,
        }

        result = self._linear_graphql(query, variables)

        if "error" in result:
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=result["error"],
            )

        if "errors" in result:
            error_msg = result["errors"][0].get("message", str(result["errors"]))
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=error_msg,
            )

        issue_data = result.get("data", {}).get("issueCreate", {})
        if not issue_data.get("success"):
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error="Linear API returned success=false",
            )

        issue = issue_data.get("issue", {})
        return TicketResult(
            finding_id=ticket.finding_id,
            ticket_id=issue.get("identifier", ""),
            ticket_url=issue.get("url", ""),
            success=True,
        )

    def _create_jira_issue(self, ticket: TicketData, project_key: str) -> TicketResult:
        session = self._get_session()
        if not session:
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error="Failed to connect to Jira MCP server",
            )

        result = session.call_tool(
            "create_issue",
            {
                "projectKey": project_key.upper(),
                "summary": ticket.title[:255],
                "description": ticket.description,
                "issueType": "Task",
            },
        )

        if result.get("error"):
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=result["error"],
            )

        content = result.get("content", [])
        if content and isinstance(content, list):
            text = content[0].get("text", "") if content else ""
            try:
                issue_data = json.loads(text)
                issue_key = issue_data.get("key", "")
                instance_url = self.config.env.get("JIRA_INSTANCE_URL", "")
                ticket_url = f"{instance_url}/browse/{issue_key}" if instance_url else ""
                return TicketResult(
                    finding_id=ticket.finding_id,
                    ticket_id=issue_key,
                    ticket_url=ticket_url,
                    success=True,
                )
            except json.JSONDecodeError:
                pass

        return TicketResult(
            finding_id=ticket.finding_id,
            ticket_id="",
            ticket_url="",
            success=True,
            error="Ticket created but could not parse response",
        )
