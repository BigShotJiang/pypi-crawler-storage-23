import base64
import json
import logging
import os
import time
import urllib.request
import urllib.error
from dataclasses import dataclass

from tools.findings_to_tickets.config import JiraConfig
from tools.findings_to_tickets.models import TicketData, TicketResult

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 2
MAX_BACKOFF_SECONDS = 60
REQUEST_TIMEOUT = int(os.environ.get("OPTIX_JIRA_TIMEOUT", "60"))
DEFAULT_ISSUE_TYPE = os.environ.get("OPTIX_JIRA_ISSUE_TYPE", "Task")

PRIORITY_MAP = {
    "Highest": "1",
    "High": "2",
    "Medium": "3",
    "Low": "4",
    "Lowest": "5",
}


@dataclass
class JiraClient:
    config: JiraConfig

    def create_issue(
        self, ticket: TicketData, project_key: str, issue_type: str | None = None
    ) -> TicketResult:
        url = f"{self.config.instance_url}/rest/api/3/issue"

        priority_id = PRIORITY_MAP.get(ticket.priority, "3")
        issue_type_name = issue_type or DEFAULT_ISSUE_TYPE

        payload = {
            "fields": {
                "project": {"key": project_key.upper()},
                "summary": ticket.title[:255],
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {"type": "text", "text": ticket.description}
                            ]
                        }
                    ]
                },
                "issuetype": {"name": issue_type_name},
                "priority": {"id": priority_id},
            }
        }

        try:
            result = self._make_request("POST", url, payload)

            issue_key = result.get("key", "")
            issue_url = f"{self.config.instance_url}/browse/{issue_key}"

            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id=issue_key,
                ticket_url=issue_url,
                success=True,
            )

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            logger.error(
                f"Jira API HTTP error: status={e.code}, "
                f"finding_id={ticket.finding_id}, "
                f"full_response={error_body}"
            )
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=f"HTTP {e.code}: {self._parse_error(error_body)}",
            )
        except Exception as e:
            logger.error(
                f"Jira API error: finding_id={ticket.finding_id}, "
                f"error_type={type(e).__name__}, "
                f"error={e}"
            )
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=str(e),
            )

    def _make_request(self, method: str, url: str, data: dict | None = None) -> dict:
        credentials = f"{self.config.user_email}:{self.config.api_token}"
        auth_header = base64.b64encode(credentials.encode()).decode()

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        }

        body = json.dumps(data).encode("utf-8") if data else None

        request = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method=method,
        )

        last_error = None
        for attempt in range(MAX_RETRIES):
            try:
                with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT) as response:
                    return json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    retry_after = e.headers.get("Retry-After")
                    if retry_after and retry_after.isdigit():
                        wait_time = int(retry_after)
                    else:
                        wait_time = min(RETRY_BACKOFF_BASE ** attempt, MAX_BACKOFF_SECONDS)

                    logger.warning(
                        f"Rate limit hit (429), retrying in {wait_time}s "
                        f"(attempt {attempt + 1}/{MAX_RETRIES})"
                    )
                    time.sleep(wait_time)
                    last_error = e
                    continue
                elif e.code >= 500:
                    if attempt < MAX_RETRIES - 1:
                        wait_time = min(RETRY_BACKOFF_BASE ** attempt, MAX_BACKOFF_SECONDS)
                        logger.warning(
                            f"Server error ({e.code}), retrying in {wait_time}s "
                            f"(attempt {attempt + 1}/{MAX_RETRIES})"
                        )
                        time.sleep(wait_time)
                        last_error = e
                        continue
                raise
            except urllib.error.URLError as e:
                if attempt < MAX_RETRIES - 1:
                    wait_time = min(RETRY_BACKOFF_BASE ** attempt, MAX_BACKOFF_SECONDS)
                    logger.warning(
                        f"Connection error, retrying in {wait_time}s "
                        f"(attempt {attempt + 1}/{MAX_RETRIES}): {e}"
                    )
                    time.sleep(wait_time)
                    last_error = e
                    continue
                raise

        if last_error:
            raise last_error
        raise RuntimeError("Request failed after retries")

    def get_projects(self) -> list[dict[str, str]]:
        url = f"{self.config.instance_url}/rest/api/3/project"

        try:
            result = self._make_request("GET", url)

            projects = []
            for project in result:
                projects.append({
                    "id": project.get("id", ""),
                    "key": project.get("key", ""),
                    "name": project.get("name", ""),
                })

            return projects

        except Exception as e:
            logger.error(f"Failed to fetch Jira projects: {e}")
            return []

    def _parse_error(self, error_body: str) -> str:
        try:
            data = json.loads(error_body)
            errors = data.get("errorMessages", [])
            if errors:
                return errors[0]
            field_errors = data.get("errors", {})
            if field_errors:
                return str(field_errors)
            return data.get("message", error_body[:500])
        except json.JSONDecodeError:
            logger.debug(f"Failed to parse error JSON: {error_body[:500]}")
            return error_body[:500]
