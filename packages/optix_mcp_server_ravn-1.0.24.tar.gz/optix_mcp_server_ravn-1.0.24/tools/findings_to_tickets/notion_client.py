"""Notion client for creating findings as pages."""

import json
import logging
import time
import urllib.request
import urllib.error
from dataclasses import dataclass

from tools.findings_to_tickets.config import NotionTicketConfig
from tools.findings_to_tickets.models import TicketData, TicketResult

logger = logging.getLogger(__name__)

NOTION_API_URL = "https://api.notion.com/v1"
NOTION_VERSION = "2022-06-28"

PRIORITY_COLORS = {
    "1": "red",
    "2": "orange",
    "3": "yellow",
    "4": "green",
    "0": "default",
}


@dataclass
class NotionTicketClient:
    config: NotionTicketConfig

    def create_issue(self, ticket: TicketData, database_id: str) -> TicketResult:
        properties = self._build_properties(ticket)

        payload = {
            "parent": {"database_id": database_id},
            "properties": properties,
        }

        children = self._build_content_blocks(ticket)
        if children:
            payload["children"] = children

        try:
            result = self._make_request("POST", "/pages", payload)

            page_id = result.get("id", "")
            page_url = result.get("url", "")

            logger.info(f"notion_page_created finding_id={ticket.finding_id}")

            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id=page_id,
                ticket_url=page_url,
                success=True,
            )

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8", errors="replace")
            logger.error(f"Notion API error: {e.code} - {error_body}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=f"HTTP {e.code}: {self._parse_error(error_body)}",
            )
        except Exception as e:
            logger.error(f"Notion API error: {e}")
            return TicketResult(
                finding_id=ticket.finding_id,
                ticket_id="",
                ticket_url="",
                success=False,
                error=str(e),
            )

    def get_databases(self) -> list[dict[str, str]]:
        try:
            payload = {
                "filter": {"property": "object", "value": "database"},
                "page_size": 50,
            }
            result = self._make_request("POST", "/search", payload)

            databases = []
            for item in result.get("results", []):
                if item.get("object") == "database":
                    title_arr = item.get("title", [])
                    title = title_arr[0].get("plain_text", "Untitled") if title_arr else "Untitled"
                    databases.append({
                        "id": item["id"],
                        "name": title,
                    })

            return databases
        except Exception as e:
            logger.error(f"Failed to get Notion databases: {e}")
            return []

    def _build_properties(self, ticket: TicketData) -> dict:
        severity_color = PRIORITY_COLORS.get(ticket.priority, "default")

        properties = {
            "Title": {
                "title": [{"text": {"content": ticket.title[:2000]}}]
            },
            "Severity": {
                "select": {"name": ticket.severity.capitalize()}
            },
            "Category": {
                "select": {"name": ticket.category[:100]}
            },
            "Finding ID": {
                "rich_text": [{"text": {"content": ticket.finding_id}}]
            },
            "Status": {
                "select": {"name": "Open"}
            },
        }

        if ticket.labels:
            properties["Labels"] = {
                "multi_select": [{"name": label[:100]} for label in ticket.labels[:5]]
            }

        return properties

    def _build_content_blocks(self, ticket: TicketData) -> list[dict]:
        blocks = []

        blocks.append({
            "object": "block",
            "type": "heading_2",
            "heading_2": {
                "rich_text": [{"text": {"content": "Finding Details"}}]
            }
        })

        severity_icon = {
            "critical": "\U0001F534",
            "high": "\U0001F7E0",
            "medium": "\U0001F7E1",
            "low": "\U0001F7E2",
            "info": "\U0001F535",
        }.get(ticket.severity.lower(), "\u2139\ufe0f")

        blocks.append({
            "object": "block",
            "type": "callout",
            "callout": {
                "rich_text": [{"text": {"content": f"Severity: {ticket.severity.capitalize()}"}}],
                "icon": {"type": "emoji", "emoji": severity_icon},
                "color": PRIORITY_COLORS.get(ticket.priority, "gray") + "_background",
            }
        })

        if ticket.description:
            desc_chunks = self._chunk_text(ticket.description, 2000)
            for chunk in desc_chunks:
                blocks.append({
                    "object": "block",
                    "type": "paragraph",
                    "paragraph": {
                        "rich_text": [{"text": {"content": chunk}}]
                    }
                })

        return blocks[:100]

    def _chunk_text(self, text: str, max_length: int) -> list[str]:
        chunks = []
        while text:
            if len(text) <= max_length:
                chunks.append(text)
                break
            split_point = text.rfind("\n", 0, max_length)
            if split_point == -1:
                split_point = max_length
            chunks.append(text[:split_point])
            text = text[split_point:].lstrip()
        return chunks

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: dict | None = None,
    ) -> dict:
        url = f"{NOTION_API_URL}{endpoint}"

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "Notion-Version": NOTION_VERSION,
            "Content-Type": "application/json",
        }

        body = json.dumps(data).encode("utf-8") if data else None

        request = urllib.request.Request(
            url,
            data=body,
            headers=headers,
            method=method,
        )

        max_retries = 3
        for attempt in range(max_retries):
            try:
                with urllib.request.urlopen(request, timeout=30) as response:
                    return json.loads(response.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                if e.code == 429 and attempt < max_retries - 1:
                    retry_after = int(e.headers.get("Retry-After", 2))
                    time.sleep(min(retry_after, 60))
                    continue
                raise

        return {}

    def _parse_error(self, error_body: str) -> str:
        try:
            data = json.loads(error_body)
            return data.get("message", error_body[:200])
        except json.JSONDecodeError:
            return error_body[:200]
