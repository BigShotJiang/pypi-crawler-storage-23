"""Configuration for Notion Security Intelligence Hub."""

from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

NOTION_CONFIG_FILE = ".optix/notion_config.json"

AGENT_CONFIG_PATHS = [
    (".mcp.json", "mcpServers"),
    (".cursor/mcp.json", "mcpServers"),
    (".vscode/mcp.json", "servers"),
    ("~/.claude.json", "mcpServers"),
    ("~/.cursor/mcp.json", "mcpServers"),
]


def _get_config_path() -> Path:
    """Get the path to the notion config file."""
    project_path = os.environ.get("OPTIX_PROJECT_PATH", os.getcwd())
    return Path(project_path) / NOTION_CONFIG_FILE


def _load_local_config() -> dict[str, Any]:
    """Load configuration from local .optix/notion_config.json."""
    config_path = _get_config_path()
    if config_path.exists():
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load notion config: {e}")
    return {}


def _save_local_config(config: dict[str, Any]) -> bool:
    """Save configuration to local .optix/notion_config.json."""
    config_path = _get_config_path()
    try:
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2)
        return True
    except OSError as e:
        logger.error(f"Failed to save notion config: {e}")
        return False


def _find_agent_config() -> tuple[Path, str] | None:
    """Find the first existing agent config file with 'optix' server.

    Returns tuple of (config_path, key_path) or None if not found.
    """
    project_path = Path(os.environ.get("OPTIX_PROJECT_PATH", os.getcwd()))

    for path_str, key_path in AGENT_CONFIG_PATHS:
        if path_str.startswith("~"):
            config_path = Path(path_str).expanduser()
        else:
            config_path = project_path / path_str

        if not config_path.exists():
            continue

        try:
            with open(config_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            servers = data.get(key_path, {})
            if "optix" in servers:
                logger.debug(f"Found agent config with optix: {config_path}")
                return config_path, key_path
        except (json.JSONDecodeError, OSError):
            continue

    return None


def _update_agent_config_env(
    audit_db_id: str,
    knowledge_db_id: str,
    compliance_db_id: str,
) -> tuple[bool, str]:
    """Update the agent's MCP config file with Notion database IDs.

    Returns tuple of (success, config_path_or_error).
    """
    result = _find_agent_config()
    if not result:
        return False, "No agent config file found"

    config_path, key_path = result

    try:
        with open(config_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        return False, f"Failed to read config: {e}"

    servers = data.get(key_path, {})
    optix_config = servers.get("optix")

    if not optix_config:
        return False, f"No 'optix' server found in {key_path}"

    env_vars = optix_config.get("env", {})
    env_vars["OPTIX_NOTION_AUDIT_DB_ID"] = audit_db_id
    env_vars["OPTIX_NOTION_KNOWLEDGE_DB_ID"] = knowledge_db_id
    env_vars["OPTIX_NOTION_COMPLIANCE_DB_ID"] = compliance_db_id
    optix_config["env"] = env_vars

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        return True, str(config_path)
    except OSError as e:
        return False, f"Failed to write config: {e}"


@dataclass
class NotionConfig:
    """Configuration for Notion API access."""

    api_key: str

    @classmethod
    def from_env(cls) -> NotionConfig | None:
        """Create config from environment variables."""
        api_key = os.environ.get("OPTIX_NOTION_API_KEY", "")
        if not api_key:
            return None
        return cls(api_key=api_key)

    @classmethod
    def is_configured(cls) -> bool:
        """Check if Notion is configured."""
        return bool(os.environ.get("OPTIX_NOTION_API_KEY"))

    def validate(self) -> list[str]:
        """Validate configuration. Returns list of error messages."""
        errors: list[str] = []
        if not self.api_key:
            errors.append("OPTIX_NOTION_API_KEY is required")
        elif not (self.api_key.startswith("ntn_") or self.api_key.startswith("secret_")):
            errors.append("OPTIX_NOTION_API_KEY should start with 'ntn_' or 'secret_'")
        return errors


@dataclass
class NotionHubConfig(NotionConfig):
    """Configuration for the full Intelligence Hub with database IDs."""

    audit_database_id: str
    knowledge_database_id: str
    compliance_database_id: str

    @classmethod
    def from_env(cls) -> NotionHubConfig | None:
        """Create hub config from environment variables and local config file.

        Priority: Environment variables > Local config file (.optix/notion_config.json)
        """
        api_key = os.environ.get("OPTIX_NOTION_API_KEY", "")

        if not api_key:
            return None

        local_config = _load_local_config()

        audit_db = os.environ.get(
            "OPTIX_NOTION_AUDIT_DB_ID",
            local_config.get("audit_database_id", "")
        )
        knowledge_db = os.environ.get(
            "OPTIX_NOTION_KNOWLEDGE_DB_ID",
            local_config.get("knowledge_database_id", "")
        )
        compliance_db = os.environ.get(
            "OPTIX_NOTION_COMPLIANCE_DB_ID",
            local_config.get("compliance_database_id", "")
        )

        return cls(
            api_key=api_key,
            audit_database_id=audit_db,
            knowledge_database_id=knowledge_db,
            compliance_database_id=compliance_db,
        )

    @classmethod
    def is_hub_configured(cls) -> bool:
        """Check if full hub is configured with all database IDs."""
        local_config = _load_local_config()

        has_api_key = bool(os.environ.get("OPTIX_NOTION_API_KEY"))
        has_audit_db = bool(
            os.environ.get("OPTIX_NOTION_AUDIT_DB_ID") or
            local_config.get("audit_database_id")
        )
        has_knowledge_db = bool(
            os.environ.get("OPTIX_NOTION_KNOWLEDGE_DB_ID") or
            local_config.get("knowledge_database_id")
        )
        has_compliance_db = bool(
            os.environ.get("OPTIX_NOTION_COMPLIANCE_DB_ID") or
            local_config.get("compliance_database_id")
        )

        return all([has_api_key, has_audit_db, has_knowledge_db, has_compliance_db])

    @classmethod
    def save_database_ids(
        cls,
        audit_db_id: str,
        knowledge_db_id: str,
        compliance_db_id: str,
    ) -> tuple[bool, str]:
        """Save database IDs to agent MCP config or fallback to local file.

        Tries to update the agent's mcp.json first.
        Falls back to .optix/notion_config.json if no agent config found.

        Returns:
            Tuple of (success, path_or_message)
        """
        success, result = _update_agent_config_env(
            audit_db_id=audit_db_id,
            knowledge_db_id=knowledge_db_id,
            compliance_db_id=compliance_db_id,
        )

        if success:
            logger.info(f"Saved Notion config to agent config: {result}")
            return True, result

        logger.debug(f"Agent config update failed: {result}, using local config")
        config = _load_local_config()
        config["audit_database_id"] = audit_db_id
        config["knowledge_database_id"] = knowledge_db_id
        config["compliance_database_id"] = compliance_db_id

        if _save_local_config(config):
            local_path = str(_get_config_path())
            logger.info(f"Saved Notion config to local file: {local_path}")
            return True, local_path

        return False, "Failed to save configuration"

    def validate(self) -> list[str]:
        """Validate hub configuration. Returns list of error messages."""
        errors = super().validate()

        uuid_pattern = re.compile(r"^[a-f0-9]{32}$|^[a-f0-9-]{36}$")

        if not self.audit_database_id:
            errors.append("OPTIX_NOTION_AUDIT_DB_ID is required for hub operations")
        elif not uuid_pattern.match(self.audit_database_id.replace("-", "")):
            errors.append("OPTIX_NOTION_AUDIT_DB_ID must be a valid Notion database ID")

        if not self.knowledge_database_id:
            errors.append("OPTIX_NOTION_KNOWLEDGE_DB_ID is required for hub operations")
        elif not uuid_pattern.match(self.knowledge_database_id.replace("-", "")):
            errors.append("OPTIX_NOTION_KNOWLEDGE_DB_ID must be a valid Notion database ID")

        if not self.compliance_database_id:
            errors.append("OPTIX_NOTION_COMPLIANCE_DB_ID is required for hub operations")
        elif not uuid_pattern.match(self.compliance_database_id.replace("-", "")):
            errors.append("OPTIX_NOTION_COMPLIANCE_DB_ID must be a valid Notion database ID")

        return errors
