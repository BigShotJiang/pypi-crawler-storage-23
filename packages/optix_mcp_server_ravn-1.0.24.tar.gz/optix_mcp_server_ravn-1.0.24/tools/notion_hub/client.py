"""Notion API client with rate limiting and retry logic."""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from tools.notion_hub.config import NotionConfig

logger = logging.getLogger(__name__)

NOTION_API_BASE = "https://api.notion.com/v1"
NOTION_API_VERSION = "2022-06-28"

MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 2
MAX_BACKOFF_SECONDS = 60
MAX_BLOCKS_PER_REQUEST = 100


class NotionAPIError(Exception):
    """Exception raised for Notion API errors."""

    def __init__(self, status_code: int, code: str, message: str):
        self.status_code = status_code
        self.code = code
        self.message = message
        super().__init__(f"Notion API error {status_code}: {code} - {message}")


class MaxRetriesExceeded(Exception):
    """Exception raised when max retries are exceeded."""

    pass


@dataclass
class NotionClient:
    """Client for Notion API with rate limiting."""

    config: NotionConfig

    def _get_headers(self) -> dict[str, str]:
        """Get headers for Notion API requests."""
        return {
            "Authorization": f"Bearer {self.config.api_key}",
            "Notion-Version": NOTION_API_VERSION,
            "Content-Type": "application/json",
        }

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make a single request to Notion API."""
        url = f"{NOTION_API_BASE}{endpoint}"
        headers = self._get_headers()

        body = json.dumps(data).encode("utf-8") if data else None
        request = Request(url, data=body, headers=headers, method=method)

        try:
            with urlopen(request, timeout=30) as response:
                return json.loads(response.read().decode("utf-8"))
        except HTTPError as e:
            error_body = e.read().decode("utf-8")
            try:
                error_data = json.loads(error_body)
                raise NotionAPIError(
                    status_code=e.code,
                    code=error_data.get("code", "unknown"),
                    message=error_data.get("message", error_body),
                )
            except json.JSONDecodeError:
                raise NotionAPIError(
                    status_code=e.code,
                    code="unknown",
                    message=error_body,
                )

    def _request_with_retry(
        self,
        method: str,
        endpoint: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Make request with exponential backoff retry on rate limits."""
        last_error: Exception | None = None

        for attempt in range(MAX_RETRIES):
            try:
                return self._make_request(method, endpoint, data)
            except NotionAPIError as e:
                last_error = e
                if e.status_code == 429:
                    wait_time = min(RETRY_BACKOFF_BASE ** attempt, MAX_BACKOFF_SECONDS)
                    logger.warning(
                        f"rate_limited attempt={attempt + 1} wait_seconds={wait_time}"
                    )
                    time.sleep(wait_time)
                else:
                    raise

        raise MaxRetriesExceeded(f"Max retries exceeded: {last_error}")

    def create_page(
        self,
        database_id: str,
        properties: dict[str, Any],
        children: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Create a new page in a Notion database."""
        data: dict[str, Any] = {
            "parent": {"type": "database_id", "database_id": database_id},
            "properties": properties,
        }

        if children:
            data["children"] = children[:MAX_BLOCKS_PER_REQUEST]

        result = self._request_with_retry("POST", "/pages", data)

        if children and len(children) > MAX_BLOCKS_PER_REQUEST:
            page_id = result["id"]
            self.append_blocks(page_id, children[MAX_BLOCKS_PER_REQUEST:])

        return result

    def update_page(
        self,
        page_id: str,
        properties: dict[str, Any],
    ) -> dict[str, Any]:
        """Update properties of an existing page."""
        data = {"properties": properties}
        return self._request_with_retry("PATCH", f"/pages/{page_id}", data)

    def append_blocks(
        self,
        block_id: str,
        children: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Append blocks to a page or block."""
        result: dict[str, Any] = {"results": []}

        for i in range(0, len(children), MAX_BLOCKS_PER_REQUEST):
            batch = children[i : i + MAX_BLOCKS_PER_REQUEST]
            batch_result = self._request_with_retry(
                "PATCH",
                f"/blocks/{block_id}/children",
                {"children": batch},
            )
            result["results"].extend(batch_result.get("results", []))

        return result

    def query_database(
        self,
        database_id: str,
        filter_params: dict[str, Any] | None = None,
        sorts: list[dict[str, Any]] | None = None,
        page_size: int = 100,
    ) -> dict[str, Any]:
        """Query a database for pages."""
        data: dict[str, Any] = {"page_size": min(page_size, 100)}

        if filter_params:
            data["filter"] = filter_params
        if sorts:
            data["sorts"] = sorts

        return self._request_with_retry(
            "POST",
            f"/databases/{database_id}/query",
            data,
        )

    def get_database(self, database_id: str) -> dict[str, Any]:
        """Get database schema and metadata."""
        return self._request_with_retry("GET", f"/databases/{database_id}")

    def list_databases(self) -> list[dict[str, Any]]:
        """List all databases accessible to the integration."""
        result = self._request_with_retry(
            "POST",
            "/search",
            {"filter": {"property": "object", "value": "database"}, "page_size": 100},
        )
        return result.get("results", [])

    def create_database(
        self,
        parent_page_id: str,
        title: str,
        properties: dict[str, Any],
        icon: str | None = None,
    ) -> dict[str, Any]:
        """Create a new database in Notion.

        Args:
            parent_page_id: ID of the parent page where database will be created
            title: Database title
            properties: Database property schema
            icon: Optional emoji icon for the database
        """
        data: dict[str, Any] = {
            "parent": {"type": "page_id", "page_id": parent_page_id},
            "title": [{"type": "text", "text": {"content": title}}],
            "properties": properties,
        }

        if icon:
            data["icon"] = {"type": "emoji", "emoji": icon}

        return self._request_with_retry("POST", "/databases", data)

    def search_pages(
        self,
        query: str,
        filter_type: str = "page",
    ) -> list[dict[str, Any]]:
        """Search for pages or databases by title."""
        result = self._request_with_retry(
            "POST",
            "/search",
            {
                "query": query,
                "filter": {"property": "object", "value": filter_type},
                "page_size": 10,
            },
        )
        return result.get("results", [])

    def create_page_in_page(
        self,
        parent_page_id: str,
        title: str,
        icon: str | None = None,
    ) -> dict[str, Any]:
        """Create a new page inside another page.

        Args:
            parent_page_id: ID of the parent page
            title: Page title
            icon: Optional emoji icon
        """
        data: dict[str, Any] = {
            "parent": {"type": "page_id", "page_id": parent_page_id},
            "properties": {
                "title": [{"type": "text", "text": {"content": title}}]
            },
        }

        if icon:
            data["icon"] = {"type": "emoji", "emoji": icon}

        return self._request_with_retry("POST", "/pages", data)

    def list_accessible_pages(self) -> list[dict[str, Any]]:
        """List pages accessible to the integration."""
        result = self._request_with_retry(
            "POST",
            "/search",
            {
                "filter": {"property": "object", "value": "page"},
                "page_size": 20,
            },
        )
        return result.get("results", [])
