(function() {
  function extendDashboard() {
    if (typeof window.dashboard !== 'function') {
      setTimeout(extendDashboard, 10);
      return;
    }

    const originalDashboard = window.dashboard;

    window.dashboard = function() {
      const instance = originalDashboard();

      instance.jiraProjects = [];

      instance.fetchJiraProjects = async function() {
        if (this.jiraProjects.length > 0) return;
        try {
          const response = await fetch('/api/tickets/teams?platform=jira');
          if (response.ok) {
            const data = await response.json();
            this.jiraProjects = data.data || data || [];
          }
        } catch {
          this.jiraProjects = [];
        }
      };

      const originalCheckPlatform = instance.checkPlatformAvailability;
      instance.checkPlatformAvailability = async function() {
        await originalCheckPlatform.call(this);
        if (this.platformsAvailable.jira) {
          this.fetchJiraProjects();
        }
      };

      return instance;
    };
  }

  extendDashboard();
})();
