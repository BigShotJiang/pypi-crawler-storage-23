"""Principal Engineer Audit Tool - Code quality and maintainability analysis.

Supports specialized lens variations:
- frontend: Frontend Developer - UI, state management, rendering
- backend: Backend Developer - API, data access, business logic
- performance: Performance Engineer - algorithms, bottlenecks, resources
- techlead: Tech Lead - architecture, patterns, conventions
- comprehensive: Full code quality review (default)
"""

from tools.principal_audit.category import FindingCategory, PrincipalLens
from tools.principal_audit.finding import (
    AffectedFile,
    ConsolidatedPrincipalFindings,
    CouplingMetrics,
    PrincipalEngineerFinding,
)
from tools.principal_audit.lenses import (
    BaseLens,
    LensConfig,
    LensRule,
    get_lens,
    get_lens_config,
    list_available_lenses,
)
from tools.principal_audit.severity import Severity
from tools.principal_audit.tool import PrincipalAuditTool

__all__ = [
    "AffectedFile",
    "BaseLens",
    "ConsolidatedPrincipalFindings",
    "CouplingMetrics",
    "FindingCategory",
    "LensConfig",
    "LensRule",
    "PrincipalAuditTool",
    "PrincipalEngineerFinding",
    "PrincipalLens",
    "Severity",
    "get_lens",
    "get_lens_config",
    "list_available_lenses",
]
