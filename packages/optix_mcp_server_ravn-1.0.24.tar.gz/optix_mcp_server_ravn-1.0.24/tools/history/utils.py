"""Shared utilities for history tracking."""

import subprocess
from pathlib import Path
from typing import Optional, Union


def get_project_name(project_root: Union[str, Path, None]) -> Optional[str]:
    """Get a project name from a root path.

    Tries to resolve the git repository name first, then falls back to
    the directory basename. Returns ``None`` when *project_root* is falsy.
    """
    if not project_root:
        return None

    root = Path(project_root)

    try:
        result = subprocess.run(
            ["git", "-C", str(root), "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip()).name
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass

    return root.name
