import json
from dataclasses import dataclass
from typing import Any
from urllib.parse import urljoin


@dataclass
class APIError(Exception):
    message: str
    status_code: int | None = None
    suggestion: str | None = None

    def __str__(self) -> str:
        if self.suggestion:
            return f"{self.message} {self.suggestion}"
        return self.message


class APIClient:
    def __init__(self, base_url: str, token: str | None, timeout_seconds: int = 60):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_seconds = timeout_seconds

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        timeout_seconds: int | None = None,
    ) -> Any:
        try:
            import requests
        except ImportError as e:
            raise APIError(
                "Missing dependency 'requests'. Install project dependencies to use CLI API calls."
            ) from e

        if not self.token:
            raise APIError(
                "Not logged in.",
                suggestion="Run `sense-cli login` or set SENSELAB_TOKEN.",
            )

        url = urljoin(f"{self.base_url}/", path.lstrip("/"))
        try:
            response = requests.request(
                method=method,
                url=url,
                headers=self._headers(),
                json=json_body,
                params=params,
                timeout=timeout_seconds or self.timeout_seconds,
            )
        except requests.Timeout as e:
            raise APIError(
                "Request timed out while contacting SenseLab API.",
                suggestion="Try again or check backend availability.",
            ) from e
        except requests.RequestException as e:
            raise APIError(
                f"Failed to reach API: {e}",
                suggestion="Check network connectivity and --base-url.",
            ) from e

        if response.status_code == 401:
            raise APIError(
                "Not logged in.",
                status_code=401,
                suggestion="Run `sense-cli login` or set SENSELAB_TOKEN.",
            )

        if response.status_code >= 400:
            try:
                payload = response.json()
                message = payload.get("message") or json.dumps(payload)
            except Exception:
                message = response.text or "Unexpected API error."
            raise APIError(message, status_code=response.status_code)

        if not response.text:
            return {}
        try:
            return response.json()
        except Exception:
            return response.text

    def _request_basic(
        self,
        method: str,
        path: str,
        *,
        token_name: str,
        token_secret: str,
        json_body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        timeout_seconds: int | None = None,
    ) -> Any:
        try:
            import requests
            from requests.auth import HTTPBasicAuth
        except ImportError as e:
            raise APIError(
                "Missing dependency 'requests'. Install project dependencies to use CLI API calls."
            ) from e

        if not token_name or not token_secret:
            raise APIError("Missing basic-auth credentials.")

        url = urljoin(f"{self.base_url}/", path.lstrip("/"))
        try:
            response = requests.request(
                method=method,
                url=url,
                auth=HTTPBasicAuth(token_name, token_secret),
                headers={"Content-Type": "application/json"},
                json=json_body,
                params=params,
                timeout=timeout_seconds or self.timeout_seconds,
            )
        except requests.Timeout as e:
            raise APIError(
                "Request timed out while contacting SenseLab API.",
                suggestion="Try again or check backend availability.",
            ) from e
        except requests.RequestException as e:
            raise APIError(
                f"Failed to reach API: {e}",
                suggestion="Check network connectivity and BACKEND_URL/SENSELAB_API_URL.",
            ) from e

        if response.status_code >= 400:
            try:
                payload = response.json()
                message = payload.get("message") or json.dumps(payload)
            except Exception:
                message = response.text or "Unexpected API error."
            raise APIError(message, status_code=response.status_code)

        if not response.text:
            return {}
        try:
            return response.json()
        except Exception:
            return response.text

    def whoami(self) -> dict[str, Any]:
        result = self._request("GET", "/api/whoami/")
        return result if isinstance(result, dict) else {"raw": result}

    def get_projects(self) -> list[dict[str, Any]]:
        result = self._request("GET", "/api/projects")
        return result if isinstance(result, list) else []

    def get_specialists(self, project_guid: str) -> list[dict[str, Any]]:
        result = self._request("GET", f"/api/specialists/{project_guid}")
        return result if isinstance(result, list) else []

    def get_functions(
        self, project_guid: str, specialist_guid: str
    ) -> list[dict[str, Any]]:
        result = self._request(
            "GET", f"/api/specialists/{project_guid}/workflows/{specialist_guid}"
        )
        return result if isinstance(result, list) else []

    def generate_functions_for_specialist(
        self,
        project_guid: str,
        specialist_guid: str,
        workflow_prompts: list[dict[str, Any]],
    ) -> dict[str, Any] | list[dict[str, Any]]:
        payload = {"workflow_prompts": workflow_prompts}
        result = self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}/generate",
            json_body=payload,
            timeout_seconds=600,
        )
        if isinstance(result, dict):
            return result
        if isinstance(result, list):
            return result
        return {"raw": result}

    def disable_function_for_specialist(
        self, project_guid: str, specialist_guid: str, workflow_id: str
    ) -> dict[str, Any]:
        result = self._request(
            "DELETE",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}/{workflow_id}",
        )
        return result if isinstance(result, dict) else {"raw": result}

    def run_orchestrator_sync(
        self, project_guid: str, query: str, conversation_guid: str | None = None
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query}
        if conversation_guid:
            payload["conversation_guid"] = conversation_guid
        return self._request(
            "POST",
            f"/api/orchestrator/{project_guid}/run-sync",
            json_body=payload,
            timeout_seconds=600,
        )

    def run_specialist_sync(
        self,
        project_guid: str,
        specialist_guid: str,
        query: str,
        conversation_guid: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"query": query, "specialist_guid": specialist_guid}
        if conversation_guid:
            payload["conversation_guid"] = conversation_guid
        return self._request(
            "POST",
            f"/api/specialist/{project_guid}/run-sync",
            json_body=payload,
            timeout_seconds=600,
        )

    def execute_function(
        self, project_guid: str, specialist_guid: str, workflow_id: str
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}/{workflow_id}",
        )

    def get_execution_status(
        self, project_guid: str, workflow_id: str, execution_guid: str
    ) -> dict[str, Any]:
        result = self._request(
            "GET",
            f"/api/specialists/{project_guid}/workflows/{workflow_id}/{execution_guid}",
        )
        return result if isinstance(result, dict) else {"raw": result}

    def list_connectors(self) -> list[dict[str, Any]]:
        result = self._request("GET", "/api/connectors/list")
        return result if isinstance(result, list) else []

    def list_connector_instances(self, project_guid: str) -> list[dict[str, Any]]:
        result = self._request("GET", f"/api/connectors/{project_guid}")
        return result if isinstance(result, list) else []

    def get_specialist_roles(
        self, project_guid: str, *, is_active: bool | None = True
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {}
        if is_active is not None:
            params["is_active"] = is_active
        result = self._request("GET", f"/api/specialists/{project_guid}/roles", params=params)
        return result if isinstance(result, list) else []

    def list_policies(
        self,
        project_guid: str,
        *,
        active_only: bool | None = True,
        name_filter: str | None = None,
        phase_filter: str | None = None,
        connector_filter: str | None = None,
        repo_id: str | None = None,
        filename_filter: str | None = None,
        policy_guid: str | None = None,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {}
        if active_only is not None:
            params["active_only"] = active_only
        if name_filter:
            params["name_filter"] = name_filter
        if phase_filter:
            params["phase_filter"] = phase_filter
        if connector_filter:
            params["connector_filter"] = connector_filter
        if repo_id:
            params["repo_id"] = repo_id
        if filename_filter:
            params["filename_filter"] = filename_filter
        if policy_guid:
            params["policy_guid"] = policy_guid
        result = self._request("GET", f"/api/rego/policies/{project_guid}", params=params)
        return result if isinstance(result, list) else []

    def sync_policies_basic(
        self,
        *,
        token_name: str,
        token_secret: str,
        repo_info: dict[str, Any],
        files: list[dict[str, Any]],
    ) -> dict[str, Any]:
        payload = {
            "repo_info": repo_info,
            "files": files,
        }
        result = self._request_basic(
            "POST",
            "/api/rego/sync",
            token_name=token_name,
            token_secret=token_secret,
            json_body=payload,
            timeout_seconds=120,
        )
        return result if isinstance(result, dict) else {"raw": result}

    def create_policy_assignment_basic(
        self,
        *,
        token_name: str,
        token_secret: str,
        policy_guid: str,
        tool_cred_guid: str,
        phase: str,
        priority: int = 100,
    ) -> dict[str, Any]:
        payload = {
            "policy_guid": policy_guid,
            "tool_cred_guid": tool_cred_guid,
            "phase": phase,
            "priority": priority,
        }
        result = self._request_basic(
            "POST",
            "/api/policy_assignments",
            token_name=token_name,
            token_secret=token_secret,
            json_body=payload,
            timeout_seconds=30,
        )
        return result if isinstance(result, dict) else {"raw": result}

    def get_specialist_activity(
        self,
        project_guid: str,
        specialist_guid: str,
        *,
        limit: int = 10,
    ) -> list[dict[str, Any]]:
        result = self._request(
            "GET",
            f"/api/specialists/{project_guid}/activity/{specialist_guid}",
            params={"limit": limit},
        )
        return result if isinstance(result, list) else []

    def get_specialist_totals(self, project_guid: str, specialist_guid: str) -> dict[str, Any]:
        result = self._request(
            "GET",
            f"/api/specialists/{project_guid}/activity/{specialist_guid}/totals",
        )
        return result if isinstance(result, dict) else {"raw": result}

    def get_specialist_tool_metrics(
        self, project_guid: str, specialist_guid: str
    ) -> list[dict[str, Any]]:
        result = self._request(
            "GET",
            f"/api/specialists/{project_guid}/activity/{specialist_guid}/tool",
        )
        return result if isinstance(result, list) else []

    def create_specialist(
        self, project_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request("POST", f"/api/specialists/{project_guid}", json_body=payload)

    def update_specialist(
        self, project_guid: str, specialist_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request(
            "PUT",
            f"/api/specialists/{project_guid}/{specialist_guid}",
            json_body=payload,
        )

    def configure_specialist(
        self, project_guid: str, specialist_guid: str, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/{specialist_guid}/config",
            json_body=payload,
        )

    def create_specialist_workflows(
        self,
        project_guid: str,
        specialist_guid: str,
        workflows: list[dict[str, Any]],
    ) -> list[dict[str, Any]] | dict[str, Any]:
        return self._request(
            "POST",
            f"/api/specialists/{project_guid}/workflows/{specialist_guid}",
            json_body={"workflows": workflows},
        )

    def ingest_cli_lineage_events(
        self,
        *,
        events: list[dict[str, Any]],
        project_guid: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"events": events}
        if project_guid:
            payload["project_guid"] = project_guid
        result = self._request("POST", "/api/cli/lineage/events", json_body=payload)
        return result if isinstance(result, dict) else {"raw": result}

    def ingest_cli_lineage_sessions(
        self,
        *,
        sessions: list[dict[str, Any]],
        project_guid: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"sessions": sessions}
        if project_guid:
            payload["project_guid"] = project_guid
        result = self._request("POST", "/api/cli/lineage/sessions", json_body=payload)
        return result if isinstance(result, dict) else {"raw": result}

    def ingest_cli_lineage_checkpoints(
        self,
        *,
        checkpoints: list[dict[str, Any]],
        project_guid: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"checkpoints": checkpoints}
        if project_guid:
            payload["project_guid"] = project_guid
        result = self._request("POST", "/api/cli/lineage/checkpoints", json_body=payload)
        return result if isinstance(result, dict) else {"raw": result}

