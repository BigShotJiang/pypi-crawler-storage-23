"""Compat module for pytola_core."""

import sys

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib  # noqa: F401
