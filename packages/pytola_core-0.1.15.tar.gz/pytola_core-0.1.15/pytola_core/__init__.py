"""Pytola Core - Essential utilities and components for Pytola applications.

This package provides core functionality including:
- Advanced logging system with colored output
- High DPI scaling support for Qt applications
- Security utilities for input validation
- Theme management system
- Environment configuration helpers.
"""

__version__ = "0.1.15"
