(function loadDrawioViewer() {
  var script = document.createElement("script");
  script.async = true;
  script.src = "https://viewer.diagrams.net/js/viewer-static.min.js";
  document.head.appendChild(script);
})();
