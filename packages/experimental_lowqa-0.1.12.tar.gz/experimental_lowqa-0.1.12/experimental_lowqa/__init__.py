# =====================================
# generator=datazen
# version=3.2.3
# hash=903373b59acb5d2a761ec71095af102a
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Read the sign."
PKG_NAME = "experimental-lowqa"
VERSION = "0.1.12"
