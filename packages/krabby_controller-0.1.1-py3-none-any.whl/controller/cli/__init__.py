"""CLI entry points for krabby-uno and krabby-uno-sim."""
