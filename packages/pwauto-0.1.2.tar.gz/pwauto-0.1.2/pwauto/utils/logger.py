import sys
from loguru import logger
from .paths import LOGS_DIR


# 1. 移除 loguru 默认的控制台处理器 (为了避免重复输出)
logger.remove()

# 2. 配置控制台日志 (屏幕上看到的)
logger.add(
    sys.stdout, 
    level="INFO", 
    format="<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>"
)

# 3. 配置日志文件保存 (存入硬盘的)
logger.add(
    LOGS_DIR / "runtime_{time:YYYY-MM-DD}.log", # 文件名按日期命名
    rotation="10 MB",              # 文件满了 10MB 就自动切分新文件
    retention="7 days",            # 只保留最近 7 天的日志
    compression="zip",             # 旧日志自动压缩成 zip 节省空间
    level="DEBUG",                 # 文件里记录更详细的 DEBUG 信息
    encoding="utf-8",
    enqueue=True                   # 异步写入，防止影响自动化脚本性能
)

# 导出这个配置好的 logger
__all__ = ["logger"]