from pathlib import Path

# 统一确定项目根目录
# 路径：pwauto/utils/paths.py -> utils -> pwauto -> 根目录
ROOT_DIR = Path(__file__).parent.parent.parent

# 预定义常用目录，其他地方直接用，不用再拼路径
LOGS_DIR = ROOT_DIR / "logs"
DATA_DIR = ROOT_DIR / "data"
REPORTS_DIR = ROOT_DIR / "reports"

# 报告及附带的 Trace 录像目录
ALLURE_RESULTS_DIR = REPORTS_DIR / "allure-results"
TRACES_DIR = REPORTS_DIR / "traces"

# 身份状态凭证文件
AUTH_STATE_FILE = DATA_DIR / "state.json"

# 自动化基建函数
def _init_project_dirs():
    """
    项目启动初始化：自动创建所有必须的目录
    """
    # 将需要自动创建的目录放进一个列表里
    dirs_to_create = [
        DATA_DIR,
        LOGS_DIR,
        ALLURE_RESULTS_DIR,
        TRACES_DIR
    ]
    
    for d in dirs_to_create:
        # parents=True: 连同父目录一起建 (比如 reports 没建，会连着 traces 一起建)
        # exist_ok=True: 如果文件夹已经存在了，绝对不报错
        d.mkdir(parents=True, exist_ok=True)

# 模块被导入时自动执行
_init_project_dirs()