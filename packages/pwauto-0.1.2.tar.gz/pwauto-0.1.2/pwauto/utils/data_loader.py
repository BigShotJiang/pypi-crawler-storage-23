import json
from pwauto.utils.paths import ROOT_DIR

def load_json_data(file_name: str):
    """
    读取 data 文件夹下的 json 文件
    """
    file_path = ROOT_DIR / "data" / file_name
    with open(file_path, "r", encoding="utf-8") as f:
        return json.load(f)

