from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    from langgraph.graph import StateGraph, START, END  # type: ignore
    try:
        from langgraph.graph import MessagesState  # type: ignore
    except Exception:
        MessagesState = None  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("langgraph", "pip install 'aiel-sdk[langgraph]'") from e

__all__ = ["StateGraph", "START", "END", "MessagesState"]
