from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    # placeholder; you can wrap LangChain agents properly later
    from langchain_core.runnables import Runnable  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("langchain-core", "pip install 'aiel-sdk[langchain]'") from e

def create_agent(*args, **kwargs):
    # In v1 keep it explicit; later implement a real wrapper
    return {"type": "agent_stub", "args": args, "kwargs": kwargs}

__all__ = ["create_agent"]
