./genca.sh
./gensrv.sh
./genclient.sh
