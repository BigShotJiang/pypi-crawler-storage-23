#pdf_tools.py
import subprocess
from rich.console import Console
from tqdm import tqdm
import os
from .utils import print_size_report

console = Console()

def compress_pdf(input_path: str, quality: str = "ebook"):
    import os
    import subprocess

    output = "compressed_" + os.path.basename(input_path)

    original_size = os.path.getsize(input_path)

    result = subprocess.run([
        "gs",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        f"-dPDFSETTINGS=/{quality}",
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        f"-sOutputFile={output}",
        input_path
    ])

    if result.returncode != 0:
        print("❌ Ghostscript failed")
        return

    new_size = os.path.getsize(output)

    print_size_report(original_size, new_size)

def compress_pdf_to_target_size(input_path: str, target_kb: int):
    import os
    import subprocess

    target_bytes = target_kb * 1024
    output = "target_" + os.path.basename(input_path)

    original_size = os.path.getsize(input_path)

    low = 50      # minimum DPI
    high = 300    # maximum DPI
    best_dpi = None

    while low <= high:
        mid = (low + high) // 2

        subprocess.run([
            "gs",
            "-sDEVICE=pdfwrite",
            "-dCompatibilityLevel=1.4",
            "-dDownsampleColorImages=true",
            "-dColorImageResolution=" + str(mid),
            "-dDownsampleGrayImages=true",
            "-dGrayImageResolution=" + str(mid),
            "-dDownsampleMonoImages=true",
            "-dMonoImageResolution=" + str(mid),
            "-dNOPAUSE",
            "-dQUIET",
            "-dBATCH",
            "-sOutputFile=" + output,
            input_path
        ], check=True)

        new_size = os.path.getsize(output)

        if new_size > target_bytes:
            high = mid - 1
        else:
            best_dpi = mid
            low = mid + 1

    if best_dpi is None:
        print("❌ Could not reach target size")
        return

    # Final save using best DPI
    subprocess.run([
        "gs",
        "-sDEVICE=pdfwrite",
        "-dCompatibilityLevel=1.4",
        "-dDownsampleColorImages=true",
        "-dColorImageResolution=" + str(best_dpi),
        "-dDownsampleGrayImages=true",
        "-dGrayImageResolution=" + str(best_dpi),
        "-dDownsampleMonoImages=true",
        "-dMonoImageResolution=" + str(best_dpi),
        "-dNOPAUSE",
        "-dQUIET",
        "-dBATCH",
        "-sOutputFile=" + output,
        input_path
    ], check=True)

    final_size_kb = round(os.path.getsize(output) / 1024, 2)

    print(f"✅ Saved as {output}")
    print(f"📦 Final Size: {final_size_kb} KB")
    print(f"🎯 DPI Used: {best_dpi}")