import typer
from ilovecli import compress_pdf_to_target_size
from pathlib import Path
from rich.console import Console
from rich.progress import Spinner
from ilovecli import (
    compress_image,
    compress_folder_parallel,
    compress_pdf,
    compress_video,
    convert_image,
    compress_to_target_size,
    __version__,
)
from ilovecli.logger import logger
console = Console()

def show_banner():
    banner = r"""
 _ _                 _      _ _
(_) | _____   _____ | | ___| (_)
| | |/ _ \ \ / / _ \| |/ _ \ | |
| | | (_) \ V / (_) | |  __/ | |
|_|_|\___/ \_/ \___/|_|\___|_|_|

    """
    console.print(banner, style="bold cyan")

app = typer.Typer(
    help="🚀 ilovecli - Image, PDF & Video Compressor",
    add_completion=False

)

@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        help="Show version and exit",
        is_eager=True,
    ),
    author: bool = typer.Option(
        False,
        "--author",
        help="Show author information and exit",
        is_eager=True,
    ),
    info: bool = typer.Option(
        False,
        "--info",
        help="Show full project information",
        is_eager=True,
    ),
):
    """
    ilovecli - Professional Media Compression CLI
    """

    if version:
        console.print(f"[bold cyan]ilovecli[/bold cyan] v{__version__}")
        raise typer.Exit()

    if author:
        console.print("👨‍💻 Author: Deep Dhabal")
        console.print("🎓 Computer Science Student")
        console.print("☁️ Cloud & Dev Enthusiast")
        raise typer.Exit()

    if info:
        show_banner()
        console.print("[bold cyan]ilovecli[/bold cyan]")
        console.print("A powerful CLI tool to compress images, PDFs, and videos.")
        console.print("\n👨‍💻 Author: Deep Dhabal")
        console.print(f"📦 Version: {__version__}")
        console.print("⚡ Built with Typer & Rich")
        raise typer.Exit()

    # Show landing screen if no command is provided
    if ctx.invoked_subcommand is None:
        show_banner()
        console.print("Use [bold]ilovecli --help[/bold] to see available commands.")



@app.command()
def compress(
    file: Path,
    quality: int = typer.Option(60, help="Image quality (10-95)"),
    pdf_quality: str = typer.Option(
        "ebook",
        help="PDF quality: screen, ebook, printer, prepress",
        case_sensitive=False,
        show_choices=True,
    ),
    crf: int = typer.Option(28, help="Video CRF (18-35)")
):
    """
    Auto-detect and compress file
    """
    if not file.exists():
        # logger.error("File not found")
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    ext = file.suffix.lower()

    try:
        logger.info(f"Starting compression for {file.name}")

        if ext in [".jpg", ".jpeg", ".png", ".webp"]:
            with console.status("Compressing...", spinner="dots"):
                compress_image(str(file), quality)

        elif ext == ".pdf":
            with console.status("Compressing...", spinner="dots"):
                compress_pdf(str(file), pdf_quality)

        elif ext in [".mp4", ".mkv", ".mov"]:
            with console.status("Compressing...", spinner="dots"):
                compress_video(str(file),crf)

        else:
            # logger.warning("Unsupported file type")
            console.print("❌ Unsupported file type", style="red")
            raise typer.Exit()

        logger.info("Compression completed successfully")

    except Exception as e:
        # logger.exception("Unexpected error during compression")
        console.print(f"❌ Error: {e}", style="red")


@app.command()
def folder(
    path: Path,
    quality: int = typer.Option(60, help="Image quality (10-95)")
):
    """
    Compress all images inside folder using parallel processing
    """
    if not path.exists():
        logger.error("Folder not found")
        console.print("❌ Folder not found", style="red")
        raise typer.Exit()

    logger.info(f"Starting folder compression: {path}")
    compress_folder_parallel(str(path), quality)
    logger.info("Folder compression complete")


@app.command()
def convert(input: Path, output: Path):
    """
    Convert image format
    """
    logger.info(f"Converting {input.name} to {output.name}")
    convert_image(str(input), str(output))
    logger.info("Conversion complete")


@app.command()
def target(
    file: Path,
    size_kb: int = typer.Argument(..., help="Target size in KB"),
):
    """
    Compress file to target size in KB
    Works for images and PDFs
    Example:
        ilovecli target image.jpg 300
        ilovecli target file.pdf 500
    """
    if not file.exists():
        logger.error("File not found for target compression")
        console.print("❌ File not found", style="red")
        raise typer.Exit()

    ext = file.suffix.lower()

    logger.info(f"Starting target compression for {file.name} to {size_kb} KB")

    try:
        if ext in [".jpg", ".jpeg", ".png", ".webp"]:
            compress_to_target_size(str(file), size_kb)

        elif ext == ".pdf":
            compress_pdf_to_target_size(str(file), size_kb)

        else:
            logger.warning("Target compression not supported for this file type")
            console.print("❌ Target compression only supported for images and PDFs", style="red")
            raise typer.Exit()

        logger.info("Target compression completed successfully")

    except Exception:
        logger.exception("Error during target compression")
        console.print("❌ Target compression failed", style="red")



@app.command()
def about():
    """
    Show author and project information
    """
    from rich.panel import Panel

    content = (
        "[bold cyan]ilovecli[/bold cyan]\n\n"
        "A powerful CLI tool to compress images, PDFs, and videos.\n\n"
        "👨‍💻 Author: Deep Dhabal\n"
        "🎓 Computer Science Student | Cloud & Dev Enthusiast\n"
        "📦 Version: " + __version__
    )

    console.print(Panel(content, title="About", expand=False))
    # logger.info("About command displayed")


if __name__ == "__main__":
    app()