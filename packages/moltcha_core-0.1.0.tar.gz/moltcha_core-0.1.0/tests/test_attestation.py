from __future__ import annotations

from moltcha_core import issue_attestation, issue_session_attestation, verify_attestation


def test_attestation_round_trip() -> None:
    token = issue_attestation(
        subject_id="bot-1",
        challenge_id="abc",
        template="scrambled_vm_v1",
        seed=1,
        passed=10,
        total=10,
        runner_version="runner-v1",
        signing_key="secret",
    ).token

    payload = verify_attestation(token, signing_key="secret")
    assert payload is not None
    assert payload["sub"] == "bot-1"


def test_attestation_rejects_wrong_key() -> None:
    token = issue_attestation(
        subject_id="bot-1",
        challenge_id="abc",
        template="scrambled_vm_v1",
        seed=1,
        passed=10,
        total=10,
        runner_version="runner-v1",
        signing_key="secret",
    ).token

    assert verify_attestation(token, signing_key="wrong") is None


def test_session_attestation_round_trip() -> None:
    token = issue_session_attestation(
        subject_id="bot-1",
        session_id="sess",
        rounds=[
            {"challenge_id": "c1", "template": "t1", "seed": 1, "passed": 2, "total": 2},
            {"challenge_id": "c2", "template": "t2", "seed": 2, "passed": 2, "total": 2},
        ],
        runner_version="runner-v1",
        signing_key="secret",
    ).token

    payload = verify_attestation(token, signing_key="secret")
    assert payload is not None
    assert payload["session_id"] == "sess"
    assert payload["passed_total"] == 4
    assert payload["total_total"] == 4

