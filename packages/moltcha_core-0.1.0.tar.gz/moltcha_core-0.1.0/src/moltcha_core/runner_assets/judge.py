from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import os

CHALLENGE_FILE = Path(os.environ.get("CHALLENGE_FILE", "/pack.json"))
SUBMISSION_FILE = Path(os.environ.get("SUBMISSION_FILE", "/solution.c"))
WASM_OUT = Path("/tmp/submission.wasm")
WASM_CLANG = os.environ.get("WASM_CLANG", "clang")
WASI_SYSROOT = os.environ.get("WASI_SYSROOT", "/wasi-sysroot")


def _normalize(output: str) -> str:
    return "\n".join(line.rstrip() for line in output.strip().splitlines()) + "\n"


def _compile_solution() -> tuple[bool, str]:
    source = SUBMISSION_FILE
    if not source.exists():
        return False, f"missing {source}"

    compile_cmd = [
        WASM_CLANG,
        "--target=wasm32-wasi",
        f"--sysroot={WASI_SYSROOT}",
        "-O2",
        "-std=c11",
        "-Wl,--strip-all",
        "-Wl,--export=main",
        str(source),
        "-o",
        str(WASM_OUT),
    ]

    proc = subprocess.run(compile_cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        return False, f"compile failed\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}"
    return True, ""


def _run_one(wasm_path: Path, payload: str, timeout_ms: int) -> tuple[bool, str, str]:
    cmd = ["wasmtime", "run", str(wasm_path)]
    try:
        proc = subprocess.run(
            cmd,
            input=payload,
            capture_output=True,
            text=True,
            timeout=max(timeout_ms / 1000.0, 0.05),
        )
    except subprocess.TimeoutExpired:
        return False, "", "timeout"

    if proc.returncode != 0:
        return False, proc.stdout, f"runtime non-zero\n{proc.stderr}"

    return True, proc.stdout, proc.stderr


def main() -> int:
    pack_path = CHALLENGE_FILE
    if not pack_path.exists():
        print("missing /challenge/pack.json", file=sys.stderr)
        return 2

    pack = json.loads(pack_path.read_text())
    hidden_tests = pack["hidden_tests"]
    limits = pack["limits"]
    timeout_ms = int(limits["timeout_ms"])
    max_stdout_bytes = int(limits["max_stdout_bytes"])

    ok, compile_err = _compile_solution()
    if not ok:
        print(compile_err, file=sys.stderr)
        return 1

    passed = 0
    for index, test in enumerate(hidden_tests):
        run_ok, stdout, reason = _run_one(WASM_OUT, test["input"], timeout_ms)
        if not run_ok:
            print(f"hidden test {index} failed: {reason}", file=sys.stderr)
            return 1

        if len(stdout.encode("utf-8", errors="ignore")) > max_stdout_bytes:
            print(f"hidden test {index} failed: stdout too large", file=sys.stderr)
            return 1

        if _normalize(stdout) != _normalize(test["output"]):
            print(f"hidden test {index} wrong answer", file=sys.stderr)
            print("expected:", file=sys.stderr)
            print(test["output"], file=sys.stderr)
            print("got:", file=sys.stderr)
            print(stdout, file=sys.stderr)
            return 1
        passed += 1

    print(json.dumps({"ok": True, "passed": passed, "total": len(hidden_tests)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
