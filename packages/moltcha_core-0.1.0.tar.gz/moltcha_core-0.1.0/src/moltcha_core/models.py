from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any


@dataclass(frozen=True)
class TestCase:
    input: str
    output: str

    def to_dict(self) -> dict[str, str]:
        return {"input": self.input, "output": self.output}


@dataclass(frozen=True)
class Limits:
    timeout_ms: int
    cpu_shares: int
    memory_mb: int
    pids_limit: int
    max_stdout_bytes: int
    max_steps: int

    def to_dict(self) -> dict[str, int]:
        return asdict(self)


@dataclass(frozen=True)
class ChallengePack:
    challenge_id: str
    seed: int
    template: str
    prompt_md: str
    public_tests: list[TestCase]
    hidden_tests: list[TestCase]
    limits: Limits
    private_spec: dict[str, Any]
    created_unix_ms: int

    def public_view(self) -> dict[str, Any]:
        return {
            "challenge_id": self.challenge_id,
            "seed": self.seed,
            "template": self.template,
            "prompt_md": self.prompt_md,
            "public_tests": [test.to_dict() for test in self.public_tests],
            "limits": self.limits.to_dict(),
            "created_unix_ms": self.created_unix_ms,
        }

    def to_dict(self) -> dict[str, Any]:
        return {
            "challenge_id": self.challenge_id,
            "seed": self.seed,
            "template": self.template,
            "prompt_md": self.prompt_md,
            "public_tests": [test.to_dict() for test in self.public_tests],
            "hidden_tests": [test.to_dict() for test in self.hidden_tests],
            "limits": self.limits.to_dict(),
            "private_spec": self.private_spec,
            "created_unix_ms": self.created_unix_ms,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "ChallengePack":
        return cls(
            challenge_id=payload["challenge_id"],
            seed=int(payload["seed"]),
            template=payload["template"],
            prompt_md=payload["prompt_md"],
            public_tests=[TestCase(**test) for test in payload["public_tests"]],
            hidden_tests=[TestCase(**test) for test in payload["hidden_tests"]],
            limits=Limits(**payload["limits"]),
            private_spec=payload["private_spec"],
            created_unix_ms=int(payload["created_unix_ms"]),
        )


@dataclass(frozen=True)
class JudgeResult:
    ok: bool
    passed: int
    total: int
    stdout: str
    stderr: str


@dataclass(frozen=True)
class Attestation:
    token: str
    payload: dict[str, Any]


@dataclass(frozen=True)
class ChallengeSession:
    session_id: str
    seed: int
    rounds: list[ChallengePack]
    created_unix_ms: int

    def rounds_public_view(self) -> list[dict[str, Any]]:
        return [pack.public_view() for pack in self.rounds]
