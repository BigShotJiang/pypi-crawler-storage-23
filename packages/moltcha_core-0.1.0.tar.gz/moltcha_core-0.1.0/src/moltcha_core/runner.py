from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from importlib import resources
from pathlib import Path

from moltcha_core.models import ChallengePack, JudgeResult

DEFAULT_IMAGE = "moltcha-judge:latest"
RUNNER_VERSION = "runner-v1"
_ENSURED_IMAGES: set[str] = set()


def _ensure_docker() -> None:
    if shutil.which("docker") is None:
        raise RuntimeError("docker is required but was not found in PATH")
    proc = subprocess.run(["docker", "info"], capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError("docker is installed but the daemon is not reachable (is it running?)")


def build_judge_image(image: str = DEFAULT_IMAGE) -> None:
    _ensure_docker()
    with tempfile.TemporaryDirectory(prefix="moltcha_runner_") as tmp:
        tmp_path = Path(tmp)
        dockerfile = resources.files("moltcha_core.runner_assets").joinpath("Dockerfile").read_text()
        judge_py = resources.files("moltcha_core.runner_assets").joinpath("judge.py").read_text()
        (tmp_path / "Dockerfile").write_text(dockerfile)
        (tmp_path / "judge.py").write_text(judge_py)

        proc = subprocess.run(
            ["docker", "build", "-t", image, str(tmp_path)],
            capture_output=True,
            text=True,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"failed to build judge image\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}")


def _image_exists(image: str) -> bool:
    proc = subprocess.run(["docker", "image", "inspect", image], capture_output=True, text=True)
    return proc.returncode == 0


def ensure_judge_image(image: str = DEFAULT_IMAGE) -> None:
    # Best-effort: build the image if it doesn't exist. This makes local dev and
    # new environments much smoother (at the cost of a one-time build).
    if image in _ENSURED_IMAGES:
        return
    _ensure_docker()
    if not _image_exists(image):
        build_judge_image(image=image)
    _ENSURED_IMAGES.add(image)


def _docker_cp(local_path: Path, container_id: str, target_path: str) -> None:
    proc = subprocess.run(
        ["docker", "cp", str(local_path), f"{container_id}:{target_path}"],
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"docker cp failed\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}")


def _create_container(pack: ChallengePack, image: str) -> str:
    limits = pack.limits
    cmd = [
        "docker",
        "create",
        "--network=none",
        "--cap-drop=ALL",
        "--security-opt=no-new-privileges",
        "--pids-limit",
        str(limits.pids_limit),
        "--cpus",
        "1.0",
        "--memory",
        f"{limits.memory_mb}m",
        "--memory-swap",
        f"{limits.memory_mb}m",
        "--tmpfs",
        "/tmp:rw,noexec,nosuid,nodev,size=64m",
        "--env",
        "CHALLENGE_FILE=/pack.json",
        "--env",
        "SUBMISSION_FILE=/solution.c",
        image,
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError(f"docker create failed\nstdout:\n{proc.stdout}\nstderr:\n{proc.stderr}")

    container_id = proc.stdout.strip()
    if not container_id:
        raise RuntimeError("docker create returned empty container id")
    return container_id


def _run_container(container_id: str) -> tuple[int, str, str]:
    proc = subprocess.run(["docker", "start", "-a", container_id], capture_output=True, text=True)
    return proc.returncode, proc.stdout, proc.stderr


def _remove_container(container_id: str) -> None:
    subprocess.run(["docker", "rm", "-f", container_id], capture_output=True, text=True)


def judge_submission(
    *,
    pack: ChallengePack,
    solution_c_path: str | Path,
    image: str = DEFAULT_IMAGE,
) -> JudgeResult:
    _ensure_docker()
    ensure_judge_image(image=image)

    solution = Path(solution_c_path)
    if not solution.exists():
        raise FileNotFoundError(f"solution file not found: {solution}")

    with tempfile.TemporaryDirectory(prefix="moltcha_eval_") as tmp:
        root = Path(tmp)
        pack_path = root / "pack.json"
        solution_path = root / "solution.c"
        pack_path.write_text(json.dumps(pack.to_dict(), indent=2))
        solution_path.write_text(solution.read_text())

        container_id = _create_container(pack, image)
        try:
            _docker_cp(pack_path, container_id, "/pack.json")
            _docker_cp(solution_path, container_id, "/solution.c")
            code, stdout, stderr = _run_container(container_id)
        finally:
            _remove_container(container_id)

    if code == 0:
        payload = json.loads(stdout.strip() or "{}")
        return JudgeResult(
            ok=True,
            passed=int(payload.get("passed", 0)),
            total=int(payload.get("total", len(pack.hidden_tests))),
            stdout=stdout,
            stderr=stderr,
        )

    return JudgeResult(
        ok=False,
        passed=0,
        total=len(pack.hidden_tests),
        stdout=stdout,
        stderr=stderr,
    )
