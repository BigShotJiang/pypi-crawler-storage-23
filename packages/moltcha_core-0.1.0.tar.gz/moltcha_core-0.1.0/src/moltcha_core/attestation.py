from __future__ import annotations

import base64
import hashlib
import hmac
import json
import time
from typing import Any

from moltcha_core.models import Attestation


def _b64url(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _canonical_json(payload: dict[str, Any]) -> bytes:
    return json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8")


def issue_attestation(
    *,
    subject_id: str,
    challenge_id: str,
    template: str,
    seed: int,
    passed: int,
    total: int,
    runner_version: str,
    signing_key: str,
) -> Attestation:
    payload = {
        "sub": subject_id,
        "challenge_id": challenge_id,
        "template": template,
        "seed": seed,
        "passed": passed,
        "total": total,
        "runner_version": runner_version,
        "iat": int(time.time()),
    }
    payload_bytes = _canonical_json(payload)
    sig = hmac.new(signing_key.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
    token = f"{_b64url(payload_bytes)}.{_b64url(sig)}"
    return Attestation(token=token, payload=payload)


def issue_session_attestation(
    *,
    subject_id: str,
    session_id: str,
    rounds: list[dict[str, Any]],
    runner_version: str,
    signing_key: str,
) -> Attestation:
    passed_total = sum(int(r.get("passed", 0)) for r in rounds)
    total_total = sum(int(r.get("total", 0)) for r in rounds)
    payload = {
        "sub": subject_id,
        "session_id": session_id,
        "rounds": rounds,
        "passed_total": passed_total,
        "total_total": total_total,
        "runner_version": runner_version,
        "iat": int(time.time()),
    }
    payload_bytes = _canonical_json(payload)
    sig = hmac.new(signing_key.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
    token = f"{_b64url(payload_bytes)}.{_b64url(sig)}"
    return Attestation(token=token, payload=payload)


def verify_attestation(token: str, signing_key: str) -> dict[str, Any] | None:
    try:
        payload_b64, sig_b64 = token.split(".", 1)
        payload_bytes = base64.urlsafe_b64decode(payload_b64 + "==")
        expected_sig = hmac.new(signing_key.encode("utf-8"), payload_bytes, hashlib.sha256).digest()
        given_sig = base64.urlsafe_b64decode(sig_b64 + "==")
        if not hmac.compare_digest(expected_sig, given_sig):
            return None
        return json.loads(payload_bytes.decode("utf-8"))
    except Exception:
        return None
