from __future__ import annotations

import json
from pathlib import Path

from moltcha_core.models import ChallengePack


def write_pack(pack: ChallengePack, out_dir: str | Path) -> Path:
    out_path = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)
    (out_path / "pack.json").write_text(json.dumps(pack.to_dict(), indent=2))
    (out_path / "prompt.md").write_text(pack.prompt_md)
    return out_path


def read_pack(pack_dir: str | Path) -> ChallengePack:
    payload = json.loads((Path(pack_dir) / "pack.json").read_text())
    return ChallengePack.from_dict(payload)
