def func3(): pass
