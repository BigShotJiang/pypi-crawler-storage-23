def func4(): pass
