"""Backward-compatible re-export — canonical location is rivet_core.glue_utils."""

from rivet_core.glue_utils import matches_partition_filter, resolve_glue_table  # noqa: F401

__all__ = ["matches_partition_filter", "resolve_glue_table"]
