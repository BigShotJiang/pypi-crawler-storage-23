import numpy as np
from numpy.testing import assert_array_almost_equal, assert_array_equal

from .classifier import (
    classifier,
    find_parameters,
    gaussian_mixture_logpdf,
    gaussian_mixture_pdf,
    likelihood,
)


def generate_test_data(
    size: int,
    means: np.typing.NDArray[np.float64],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> list[np.typing.NDArray[np.int32]]:
    sizes = np.zeros(size)
    start = 0
    groups = np.zeros(size)
    for i in range(len(means)):
        n_elements = int(size * proportions[i])
        sizes[start : start + n_elements] = np.random.normal(
            means[i], standard_deviations[i], n_elements
        )
        groups[start : start + n_elements] = i
        start = start + n_elements
    return [groups.astype(np.int32), sizes.astype(np.int32)]


def test_gaussian_mixture_pdf():
    sizes = np.array([1, 2, 3])
    pdf = gaussian_mixture_pdf(
        sizes.astype(np.float64),
        np.array([10, 20, 30]),
        np.array([1, 1, 1]),
        np.array([0.3, 0.4, 0.3]),
    )
    assert_array_almost_equal(
        pdf,
        np.array(
            [
                3.083932e-19,
                1.515681e-15,
                2.740416e-12,
            ]
        ),
    )


def test_gaussian_mixture_logpdf():
    sizes = np.array([1, 2, 3])
    pdf = gaussian_mixture_logpdf(
        sizes.astype(np.float64),
        np.array([10, 20, 30]),
        np.array([1, 1, 1]),
        np.array([0.3, 0.4, 0.3]),
    )
    assert_array_almost_equal(
        pdf,
        np.array([-42.622911, -34.122911, -26.622911]),
    )


def test_likelihood():
    sizes = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert np.float64(-163.7291133753061) == likelihood(
        sizes, np.array([10, 20, 30]), np.array([1, 1, 1]), np.array([0.3, 0.4, 0.3])
    )

    sizes = np.array([1, 2, 3])
    ll = likelihood(
        sizes.astype(np.float64),
        np.array([10, 20, 30]),
        np.array([1, 1, 1]),
        np.array([0.3, 0.4, 0.3]),
    )
    assert_array_almost_equal(
        ll,
        np.array([-103.368734012591831]),
    )
    ll = likelihood(
        sizes.astype(np.float64),
        np.array([10, 20, 30]),
        np.array([-1, 1, 1]),
        np.array([0.3, 0.4, 0.3]),
    )
    assert np.isnan(ll)


def test_find_parameters():
    _, sizes = generate_test_data(
        size=1000,
        means=np.array([10, 20, 30]),
        standard_deviations=np.array([1.1, 1.4, 2.0]),
        proportions=np.array([0.3, 0.4, 0.3]),
    )
    (proportion, standard_deviation) = find_parameters(
        sizes, expected_means=np.array([10, 20, 30])
    )
    print(proportion, standard_deviation)
    assert_array_almost_equal(proportion, np.array([0.3, 0.4, 0.3]), decimal=1)
    assert_array_almost_equal(standard_deviation, np.array([1.2, 1.5, 2.0]), decimal=1)


def test_classifier():
    groups, sizes = generate_test_data(
        size=50,
        means=np.array([10, 100, 200]),
        standard_deviations=np.array([2, 2, 2]),
        proportions=np.array([0.3, 0.4, 0.3]),
    )
    proportions, standard_deviations = find_parameters(
        sizes, expected_means=np.array([10, 100, 200])
    )
    estimated_groups = classifier(
        sizes, np.array([10, 100, 200]), proportions, standard_deviations
    )
    print(groups)
    print(estimated_groups)
    print(np.sum(groups == estimated_groups) / len(groups))
    assert_array_equal(groups, estimated_groups)
