# SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# This part of the code compute the minimum and maximum size for each of the
# groups of pairs of reads sizes from an array of pairs sizes sampled from the
# input bam file.
# The computed array of minimum and maximum size (which are not overlapping
# between groups) is then used to write a different bam for each group of size.
# The last function take an iterator on an input bam file, the array of minimum
# and maximum size and write the pairs of reads falling into the different
# group of size in different bam files


import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp
from scipy.stats import norm
import logging

logger = logging.getLogger(__name__)


def classifier(
    sizes: np.typing.NDArray[np.int32],
    means: np.typing.NDArray[np.int32],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> np.typing.NDArray[np.int32]:
    logger.info(
        "Classifying %d samples into %d groups (means=%s)",
        len(sizes),
        len(means),
        means.tolist(),
    )
    logger.debug(
        "Parameters: std=%s, proportions=%s",
        standard_deviations.tolist(),
        proportions.tolist(),
    )
    group_proba = gaussian_group_logpdf(
        sizes.astype(np.float64),
        proportions,
        means.astype(np.float64),
        standard_deviations,
    )
    group_proba -= logsumexp(group_proba, axis=1).reshape(-1, 1)  # type: ignore
    classifications = np.argmax(group_proba, axis=1)

    return classifications


def find_parameters(
    sizes: np.typing.NDArray[np.int32],
    expected_means: np.typing.NDArray[np.int32] = np.array(
        [110, 150, 250, 300]
    ),
) -> tuple[np.typing.NDArray[np.float64], np.typing.NDArray[np.float64]]:
    means = expected_means.astype(np.float64)
    proportions = np.ones_like(means) / len(means)
    standard_deviations = np.ones_like(means) * 1.0

    res = minimize(
        objective_function,
        x0=params_transform(
            np.concatenate((proportions, standard_deviations))
        ),
        args=(sizes, means),
    )
    proportions, standard_deviations = np.array_split(
        params_transform_inv(res.x), 2
    )
    return (proportions, standard_deviations)


def objective_function(params, sizes, expected_means):
    proportions, standard_deviations = np.array_split(
        params_transform_inv(params), 2
    )
    return -likelihood(sizes, expected_means, standard_deviations, proportions)


def softmax(x):
    e_x = np.exp(x)
    return e_x / e_x.sum()


def clr_transform(x):
    geometric_mean = np.exp(np.mean(np.log(x)))
    clr = np.log(x) - np.log(geometric_mean)
    return clr


def params_transform(params):
    proportions, standard_deviations = np.array_split(params, 2)
    proportions = clr_transform(proportions)
    standard_deviations = np.abs(standard_deviations)
    return np.concatenate((proportions, standard_deviations))


def params_transform_inv(params):
    proportions, standard_deviations = np.array_split(params, 2)
    proportions = softmax(proportions)
    standard_deviations = np.abs(standard_deviations)
    return np.concatenate((proportions, standard_deviations))


def gaussian_mixture_pdf(
    x: np.typing.NDArray[np.float64],
    means: np.typing.NDArray[np.float64],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> np.typing.NDArray[np.float64]:
    pdf = np.zeros_like(x)
    for group in range(len(means)):
        pdf += proportions[group] * norm.pdf(
            x, loc=means[group], scale=standard_deviations[group]
        )
    return pdf


def gaussian_mixture_logpdf(
    x: np.typing.NDArray[np.float64],
    means: np.typing.NDArray[np.float64],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> np.typing.NDArray[np.float64]:
    log_pdf: np.typing.NDArray[np.float64] = gaussian_group_logpdf(
        x, means, standard_deviations, proportions
    )
    return logsumexp(log_pdf, axis=1)  # type: ignore


def gaussian_group_logpdf(
    x: np.typing.NDArray[np.float64],
    means: np.typing.NDArray[np.float64],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> np.typing.NDArray[np.float64]:
    log_pdf = np.zeros((len(x), len(means)))
    for group in range(len(means)):
        log_pdf[:, group] = np.log(proportions[group]) + norm.logpdf(
            x, loc=means[group], scale=standard_deviations[group]
        )
    return log_pdf


def likelihood(
    sizes: np.typing.NDArray[np.float64],
    expected_means: np.typing.NDArray[np.float64],
    standard_deviations: np.typing.NDArray[np.float64],
    proportions: np.typing.NDArray[np.float64],
) -> float:
    loglikelihood = np.sum(
        gaussian_mixture_logpdf(
            sizes,
            expected_means,
            standard_deviations,
            proportions,
        )
    )
    if np.isnan(loglikelihood) or np.isinf(loglikelihood):
        print(f"Error in likelihood calculation: {loglikelihood}")
        print((expected_means, standard_deviations, proportions))
    return loglikelihood
