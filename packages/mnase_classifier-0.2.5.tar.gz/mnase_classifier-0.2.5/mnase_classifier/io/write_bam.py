# SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# function that write a bam file from an iterator on pairs of reads
from .read_bam import read_pair
import os
import pysam
import numpy as np
import logging

logger = logging.getLogger(__name__)


def write_bam(
    classifier_group: np.typing.NDArray[np.int32],
    means: np.typing.NDArray[np.int32],
    outdir_path: str,
    bam_file_path: str,
) -> None:
    """Filter BAM reads by group
    The groups are provided by the list ``classifier_group`` and for each group
    a new BAM files is created

    Parameters
    ----------
    classifier_group : list
        A list of group emit by the classifier function
    outdir_path : str
        Path to the output directory
    bam_file_path : str
        Path to the input BAM file
    """
    logger.info("Writing classified reads to %s", outdir_path)
    logger.debug("Input BAM: %s, %d groups", bam_file_path, len(means))

    bam_files = {}
    os.makedirs(outdir_path, exist_ok=True)

    with pysam.AlignmentFile(bam_file_path, "rb") as bam_in:
        bam_header = bam_in.header

    for i in range(len(means)):
        input_name = os.path.basename(bam_file_path)[:-4]
        output_filename = os.path.join(
            outdir_path, f"{input_name}_{means[i]}.bam"
        )
        bam_files[i] = pysam.AlignmentFile(
            output_filename, "wb", header=bam_header
        )
        logger.debug("Created output file: %s", output_filename)
    logger.info(
        "Classifying samples into %d groups (means=%s)",
        len(means),
        means.tolist(),
    )
    counts = {}
    for i in range(len(means)):
        counts[i] = 0

    for i, (r1, r2) in enumerate(read_pair(bam_file_path)):
        # The classifier_group list is in the same order as the reads in the
        # input file.
        group = classifier_group[i]
        mean = means[group]
        counts[group] += 1
        bam_header = r1.header

        input_name = os.path.basename(bam_file_path)[:-4]
        output_filename = os.path.join(outdir_path, f"{input_name}_{mean}.bam")

        bam_files[group].write(r1)
        bam_files[group].write(r2)

    for f in bam_files.values():
        f.close()
    for group, count in counts.items():
        logger.info(
            "Group %d (mean=%d): %d pairs written", group, means[group], count
        )
    logger.info(
        "Finished writting %d pairs to %d BAM files",
        sum(counts.values()),
        len(means),
    )
