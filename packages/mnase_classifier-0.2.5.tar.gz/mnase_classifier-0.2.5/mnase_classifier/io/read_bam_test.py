from .read_bam import read_bam, sample_size
import os


def test_read_bam():
    """Test the read_bam function.

    The test_paired.bam file consists of 22 pairs of reads.
    We expect the length of the result to be 22.
    """

    bamfile = os.path.join(
        os.path.dirname(__file__), "test_data", "test_paired.bam"
    )
    result = read_bam(bamfile, None)
    assert len(result) == 22


def test_sample_size():
    """Test the sample_size function.

    The test_paired.bam file contains 22 pairs of reads. We analyze only the
    first 3 pairs of reads and check whether the sizes given by the sample_size
    function correspond to the expected sizes
    """

    bamfile = os.path.join(
        os.path.dirname(__file__), "test_data", "test_paired.bam"
    )
    result = sample_size(bamfile, 3)
    expected_size = [364, 147, 147]

    assert all(result == expected_size)
