from .write_bam import write_bam
from .read_bam import read_bam
import numpy as np
import os

# example of output from the classifier function
test_groups = np.array(
    [0, 1, 2, 0, 1, 1, 0, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 2, 0]
)
means = np.array([100, 150, 200])


def test_write_bam():
    """Test the write_bam function

    After providing a list of potential groups, the write_bam function
    separates the reads into three populations. The test_write_bam function
    verifies that the files created contain the expected number of reads.
    """

    bamfile = os.path.join(
        os.path.dirname(__file__), "test_data", "test_paired.bam"
    )
    output_folder_test = os.path.join(
        os.path.dirname(__file__), "test_data", "test_results"
    )

    if not os.path.exists(output_folder_test):
        os.mkdir(output_folder_test)

    write_bam(test_groups, means, output_folder_test, bamfile)

    nb_reads = []
    expected_nb = [8, 7, 7]

    files = []
    for i in means:
        files.append(os.path.join(output_folder_test, f"test_paired_{i}.bam"))

    for file in files:
        nb_reads.append(len(read_bam(file, None)))

    assert nb_reads == expected_nb
