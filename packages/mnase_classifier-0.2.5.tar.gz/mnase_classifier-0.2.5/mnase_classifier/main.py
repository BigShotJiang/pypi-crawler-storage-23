# SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>
#
# SPDX-License-Identifier: AGPL-3.0-or-later

# This is the main script of the programm that parse the command line argument
# and execute the function from classifier.py

import logging

import numpy as np
import rich_click as click

from . import classifier, find_parameters, read_bam, sample_size, write_bam


@click.command()
@click.option(
    "--bam_input",
    "-i",
    help="Path to the BAM file. Uses less memory if it's sorted",
    required=True,
)
@click.option(
    "--outdir",
    "-o",
    help="Path to the directory where the outputs will be stored",
    required=True,
)
@click.option(
    "--n_pairs",
    help="Number of pairs used to define the classifier parameters",
    required=True,
    type=int,
)
@click.option(
    "--means",
    "'m",
    help="A list of expected means (space-separated, e.g. '110 150 250 300')",
    required=True,
    type=str,
)
@click.option(
    "--verbose",
    "-v",
    help="Increase verbosity level, accumulate v to increase verbosity levels",
    count=True,
)
def main(bam_input: str, outdir: str, n_pairs: int, means: str, verbose: int):
    """mnase_classifier segments paired-end sequencing data from MNase
    experiments into distinct groups based on insert size distributions.

    It estimates parameters for a Gaussian mixture model, classifies read
    pairs, and writes grouped BAM files for downstream chromatin analysis.
    """
    """
    Parameters
    ----------
    bam_input : str
        Path to the input file
    outdir : str
        Path to the output directory
    n_pairs : int
        Number of pairs reads for `sample_size` function
    means : np.typing.NDArray[np.int32]
        An array of expected means
    """
    if verbose == 0:
        level = logging.WARNING
    elif verbose == 1:
        level = logging.INFO
    else:
        level = logging.DEBUG

    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%H:%M:%S",
    )

    print("Hello from mnase-classifier!")
    means_np = np.array([int(x) for x in means.split()], dtype=np.int32)
    size_np = sample_size(bam_input, n_pairs)
    proportions, standard_deviations = find_parameters(size_np, means_np)
    all_size_np = read_bam(bam_input, None)
    classification_group = classifier(
        all_size_np, means_np, standard_deviations, proportions
    )
    write_bam(classification_group, means_np, outdir, bam_input)


if __name__ == "__main__":
    main()
