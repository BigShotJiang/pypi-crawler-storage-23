<!--
SPDX-FileCopyrightText: 2026 Laurent Modolo <laurent.modolo@cnrs.fr>, Lauryn Trouillot <lauryn.trouillot@ens-lyon.fr>

SPDX-License-Identifier: AGPL-3.0-or-later
-->

[![pipeline status](http://gitbio.ens-lyon.fr/LBMC/Bernard/mnase_classifier/badges/main/pipeline.svg)](http://gitbio.ens-lyon.fr/LBMC/Bernard/mnase_classifier/-/commits/main)
[![coverage report](http://gitbio.ens-lyon.fr/LBMC/Bernard/mnase_classifier/badges/main/coverage.svg)](http://gitbio.ens-lyon.fr/LBMC/Bernard/mnase_classifier/-/commits/main)



# mnase_classifier

A detailed description of this project can be found [here](https://lbmc.gitbiopages.ens-lyon.fr/biocomp/projects/2025/2025_12_19_bernard/)


## Getting started

Getting the project up and running is as simple as:

### Install from pypi

```bash
pipx install mnase-classifier
```

### Install from source

if you want to install it from source you will need [uv](https://github.com/astral-sh/uv) installed

clone the repository

```bash
git clone git@gitbio.ens-lyon.fr:LBMC/Bernard/mnase_classifier.git
cd mnase_classifier
```

Initialize the **uv** environment:

```bash
uv sync
```

Print help:

```bash
uv run mnase_classifier --help
```

### Usage example

Classify paired reads from a BAM file into groups based on insert size:

```bash
uv run mnase_classifier --bam_input path/to/file.bam --outdir outdir --means "110 150 250 300" -v
```

The `-v` flag enables verbose output for debugging.
