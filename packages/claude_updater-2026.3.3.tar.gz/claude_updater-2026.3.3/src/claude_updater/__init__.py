"""Multi-tool update checker for the Claude Code ecosystem."""

__version__ = "2026.03.3"
