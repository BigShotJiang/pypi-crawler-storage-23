from __future__ import annotations

from typing import List

import numpy as np
from scipy.ndimage import rotate
from tqdm.contrib.concurrent import thread_map

from napari_yolopt._predict import _to_uint8, run_multiscale_prediction_uint8


def _rotate_with_padding(
    img: np.ndarray, angle_deg: float
) -> tuple[np.ndarray, tuple[float, float], tuple[float, float]]:
    h, w = img.shape[:2]
    rotated = rotate(
        img, angle=angle_deg, reshape=True, order=1, mode="constant", cval=0.0
    )
    h_rot, w_rot = rotated.shape[:2]
    center_in = ((w - 1) / 2.0, (h - 1) / 2.0)
    center_out = ((w_rot - 1) / 2.0, (h_rot - 1) / 2.0)
    return rotated, center_in, center_out


def _inverse_rotate_points(
    points_xy: np.ndarray,
    angle_deg: float,
    center_in: tuple[float, float],
    center_out: tuple[float, float],
) -> np.ndarray:
    angle_rad = np.deg2rad(angle_deg)
    cos_a = np.cos(angle_rad)
    sin_a = np.sin(angle_rad)

    x = points_xy[:, 0] - center_out[0]
    y = points_xy[:, 1] - center_out[1]

    x_in = x * cos_a - y * sin_a + center_in[0]
    y_in = x * sin_a + y * cos_a + center_in[1]
    return np.stack([x_in, y_in], axis=1)


def run_multiscale_prediction_rotated(
    image: np.ndarray,
    model,
    angles_deg: List[float],
    scale_min: float,
    scale_max: float,
    num_scales: int,
    iou_thresh: float,
    *,
    model_path: str | None = None,
    n_jobs: int = 1,
) -> tuple[List[np.ndarray], List[np.ndarray]]:
    img_uint8 = _to_uint8(image)

    if n_jobs > 1:
        results = thread_map(
            _predict_for_angle_thread,
            [
                (
                    angle,
                    img_uint8,
                    model,
                    scale_min,
                    scale_max,
                    num_scales,
                    iou_thresh,
                )
                for angle in angles_deg
            ],
            desc="Predicting angles",
            max_workers=n_jobs,
        )
        polygons_by_angle = [polys for polys, _scores in results]
        scores_by_angle = [scores for _polys, scores in results]
        return polygons_by_angle, scores_by_angle

    polygons_by_angle: List[np.ndarray] = []
    scores_by_angle: List[np.ndarray] = []

    for angle in angles_deg:
        polygons, scores = _predict_for_angle_serial(
            angle,
            img_uint8,
            model,
            scale_min,
            scale_max,
            num_scales,
            iou_thresh,
        )
        polygons_by_angle.append(polygons)
        scores_by_angle.append(scores)

    return polygons_by_angle, scores_by_angle


def _predict_for_angle_serial(
    angle: float,
    img_uint8: np.ndarray,
    model,
    scale_min: float,
    scale_max: float,
    num_scales: int,
    iou_thresh: float,
) -> tuple[np.ndarray, np.ndarray]:
    if abs(angle) < 1e-6:
        rotated = img_uint8
        center_in = (
            (img_uint8.shape[1] - 1) / 2.0,
            (img_uint8.shape[0] - 1) / 2.0,
        )
        center_out = center_in
    else:
        rotated, center_in, center_out = _rotate_with_padding(img_uint8, angle)

    boxes, scores = run_multiscale_prediction_uint8(
        rotated,
        model,
        scale_min=scale_min,
        scale_max=scale_max,
        num_scales=num_scales,
        iou_thresh=iou_thresh,
    )

    if boxes.size == 0:
        return np.zeros((0, 4, 2), dtype=np.float32), np.zeros(
            (0,), dtype=np.float32
        )

    polygons = np.zeros((boxes.shape[0], 4, 2), dtype=np.float32)
    polygons[:, 0, 0] = boxes[:, 1]
    polygons[:, 0, 1] = boxes[:, 0]
    polygons[:, 1, 0] = boxes[:, 1]
    polygons[:, 1, 1] = boxes[:, 2]
    polygons[:, 2, 0] = boxes[:, 3]
    polygons[:, 2, 1] = boxes[:, 2]
    polygons[:, 3, 0] = boxes[:, 3]
    polygons[:, 3, 1] = boxes[:, 0]

    if abs(angle) > 1e-6:
        points_xy = polygons[:, :, [1, 0]].reshape(-1, 2)
        points_xy = _inverse_rotate_points(
            points_xy, angle, center_in, center_out
        )
        polygons = points_xy.reshape(-1, 4, 2)[:, :, [1, 0]]

    return polygons, scores.astype(np.float32)


def _predict_for_angle_thread(args):
    (
        angle,
        img_uint8,
        model,
        scale_min,
        scale_max,
        num_scales,
        iou_thresh,
    ) = args
    return _predict_for_angle_serial(
        angle,
        img_uint8,
        model,
        scale_min,
        scale_max,
        num_scales,
        iou_thresh,
    )
