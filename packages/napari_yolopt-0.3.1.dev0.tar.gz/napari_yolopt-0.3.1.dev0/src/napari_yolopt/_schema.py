from __future__ import annotations

BOXES_SUFFIX = "__boxes.csv"
POLYGONS_SUFFIX = "__polygons.csv"
DETECTIONS_POLYGONS_SUFFIX = "__detections_polygons.csv"
PARAMS_SUFFIX = "__params.json"
MASTER_CSV = "all_areas.csv"
PIXELSIZE_UNITS = "nm"
ANALYSIS_FOLDER_NAME = "analysis_folder"

SHAPES_HEADER = ["index", "shape-type", "vertex-index", "axis-0", "axis-1"]
PARAMS_VERSION = 1
