from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Tuple

import numpy as np
from shapely.geometry import Polygon
from shapely.strtree import STRtree


@dataclass(frozen=True)
class FlatIndex:
    angle: int
    local: int


def _validate_L(L: List[np.ndarray]) -> None:
    if not isinstance(L, list) or len(L) == 0:
        raise ValueError(
            "L must be a non-empty list of arrays with shape (Ni,4,2)."
        )
    for k, arr in enumerate(L):
        if not isinstance(arr, np.ndarray):
            raise ValueError(f"L[{k}] is not a numpy array.")
        if arr.ndim != 3 or arr.shape[1:] != (4, 2):
            raise ValueError(
                f"L[{k}] must have shape (Ni,4,2); got {arr.shape}."
            )


def flatten_boxes(
    L: List[np.ndarray],
) -> Tuple[List[Polygon], np.ndarray, np.ndarray, List[FlatIndex]]:
    _validate_L(L)

    polys: List[Polygon] = []
    centroids: List[Tuple[float, float]] = []
    areas: List[float] = []
    idx_map: List[FlatIndex] = []

    for a, arr in enumerate(L):
        for j in range(arr.shape[0]):
            pts = arr[j]
            poly = Polygon(pts[:, [1, 0]])
            if not poly.is_valid:
                poly = poly.buffer(0)
            if poly.is_empty or poly.area <= 0:
                continue
            c = poly.centroid
            polys.append(poly)
            centroids.append((c.x, c.y))
            areas.append(poly.area)
            idx_map.append(FlatIndex(angle=a, local=j))

    if len(polys) == 0:
        return (
            [],
            np.zeros((0, 2), dtype=float),
            np.zeros((0,), dtype=float),
            [],
        )

    return (
        polys,
        np.array(centroids, dtype=float),
        np.array(areas, dtype=float),
        idx_map,
    )


def build_sparse_pair_data(
    polys: List[Polygon],
    centroids: np.ndarray,
    idx_map: List[FlatIndex],
) -> Tuple[Dict[Tuple[int, int], float], Dict[int, List[Tuple[int, float]]]]:
    N = len(polys)
    if N == 0:
        return {}, {}

    angles = sorted({m.angle for m in idx_map})

    polys_by_angle: Dict[int, List[Polygon]] = {a: [] for a in angles}
    glob_by_angle: Dict[int, List[int]] = {a: [] for a in angles}

    for gi, meta in enumerate(idx_map):
        polys_by_angle[meta.angle].append(polys[gi])
        glob_by_angle[meta.angle].append(gi)

    trees: Dict[int, STRtree] = {}
    for a in angles:
        if len(polys_by_angle[a]) > 0:
            trees[a] = STRtree(polys_by_angle[a])

    inter_area: Dict[Tuple[int, int], float] = {}
    neigh: Dict[int, List[Tuple[int, float]]] = {i: [] for i in range(N)}

    for i in range(N):
        ai = idx_map[i].angle
        pi = polys[i]
        ci = centroids[i]

        for a in angles:
            if a == ai:
                continue
            tree = trees.get(a, None)
            if tree is None:
                continue
            cand_local_idxs = tree.query(pi)
            if len(cand_local_idxs) == 0:
                continue

            glob_list = glob_by_angle[a]

            for k in cand_local_idxs:
                j = glob_list[int(k)]
                ia = pi.intersection(polys[j]).area
                if ia <= 0.0:
                    continue
                u, v = (i, j) if i < j else (j, i)
                if (u, v) not in inter_area:
                    inter_area[(u, v)] = float(ia)
                d = float(np.hypot(*(ci - centroids[j])))
                neigh[i].append((j, d))

    for i in range(N):
        neigh[i].sort(key=lambda t: t[1])

    return inter_area, neigh


def apply_hypotenuse_gate(
    neigh: Dict[int, List[Tuple[int, float]]],
    idx_map: List[FlatIndex],
    L: List[np.ndarray],
    tau: float = 1.10,
) -> Dict[int, List[Tuple[int, float]]]:
    N = len(idx_map)
    long_side = np.zeros((N,), dtype=float)
    diag = np.zeros((N,), dtype=float)

    for gi, meta in enumerate(idx_map):
        pts = L[meta.angle][meta.local]
        s0 = np.hypot(*(pts[1] - pts[0]))
        s1 = np.hypot(*(pts[2] - pts[1]))
        w, h = (s0, s1)
        long_side[gi] = max(w, h)
        diag[gi] = float(np.hypot(w, h))

    gated: Dict[int, List[Tuple[int, float]]] = {}
    for i, nbrs in neigh.items():
        out = []
        for j, d in nbrs:
            if long_side[j] <= tau * diag[i] and long_side[i] <= tau * diag[j]:
                out.append((j, d))
        gated[i] = out
    return gated


def build_Z_nearest_per_angle(
    neigh: Dict[int, List[Tuple[int, float]]],
    idx_map: List[FlatIndex],
    N_angles: int,
    max_dist: float,
) -> np.ndarray:
    N = len(idx_map)
    Z = np.full((N, N_angles), -1, dtype=int)

    for i, meta in enumerate(idx_map):
        Z[i, meta.angle] = i

    for i in range(N):
        best_dist = np.full((N_angles,), np.inf, dtype=float)
        best_idx = np.full((N_angles,), -1, dtype=int)

        for j, d in neigh.get(i, []):
            if d > max_dist:
                break
            a = idx_map[j].angle
            if a == idx_map[i].angle:
                continue
            if d < best_dist[a]:
                best_dist[a] = d
                best_idx[a] = j

        for a in range(N_angles):
            if a == idx_map[i].angle:
                continue
            Z[i, a] = best_idx[a]

    return Z


def _tuple_pattern_key(row: np.ndarray) -> Tuple[int, Tuple[int, ...]]:
    mask = 0
    vals = []
    for k, v in enumerate(row.tolist()):
        if v != -1:
            mask |= 1 << k
            vals.append(v)
    return mask, tuple(vals)


def _tuple_support(row: np.ndarray) -> int:
    return int(np.sum(row != -1))


def score_tuple_sum_intersections(
    row: np.ndarray, inter_area: Dict[Tuple[int, int], float]
) -> float:
    idxs = row[row != -1].tolist()
    s = 0.0
    for k in range(len(idxs)):
        for l in range(k + 1, len(idxs)):
            i, j = idxs[k], idxs[l]
            u, v = (i, j) if i < j else (j, i)
            s += inter_area.get((u, v), 0.0)
    return s


def canonicalize_Z_by_supersets(
    Z: np.ndarray,
    inter_area: Dict[Tuple[int, int], float],
) -> np.ndarray:
    Z_rows = [tuple(row.tolist()) for row in Z]
    unique = list(dict.fromkeys(Z_rows))
    A = Z.shape[1]

    sup = {}
    agr = {}
    for t in unique:
        row = np.array(t, dtype=int)
        sup[t] = _tuple_support(row)
        agr[t] = score_tuple_sum_intersections(row, inter_area)

    best_for_pattern: Dict[Tuple[int, Tuple[int, ...]], Tuple[int, ...]] = {}

    def better(
        t1: Tuple[int, ...], t2: Tuple[int, ...] | None
    ) -> Tuple[int, ...]:
        if t2 is None:
            return t1
        if sup[t1] != sup[t2]:
            return t1 if sup[t1] > sup[t2] else t2
        return t1 if agr[t1] >= agr[t2] else t2

    for t in unique:
        row = np.array(t, dtype=int)
        present_positions = np.where(row != -1)[0].tolist()
        m = len(present_positions)
        if m == 0:
            continue

        for subset_mask in range(1, 1 << m):
            mask = 0
            vals = []
            for bit, pos in enumerate(present_positions):
                if (subset_mask >> bit) & 1:
                    mask |= 1 << pos
                    vals.append(int(row[pos]))
            key = (mask, tuple(vals))
            prev = best_for_pattern.get(key, None)
            best_for_pattern[key] = better(t, prev)

    Z_can = Z.copy()
    for i in range(Z.shape[0]):
        row = Z[i]
        key = _tuple_pattern_key(row)
        best = best_for_pattern.get(key, None)
        if best is not None:
            Z_can[i] = np.array(best, dtype=int)

    return Z_can


def filter_Z_min_support(Z: np.ndarray, min_support: int = 3) -> np.ndarray:
    keep = np.sum(Z != -1, axis=1) >= min_support
    return Z[keep]


def fused_polygons_from_Z(
    Z: np.ndarray,
    polys: List[Polygon],
) -> List[Tuple[Tuple[int, ...], Polygon]]:
    unique = list(dict.fromkeys(tuple(row.tolist()) for row in Z))
    out: List[Tuple[Tuple[int, ...], Polygon]] = []

    for t in unique:
        idxs = [i for i in t if i != -1]
        if len(idxs) == 0:
            continue
        inter = polys[idxs[0]]
        for k in idxs[1:]:
            inter = inter.intersection(polys[k])
            if inter.is_empty:
                break
        if not inter.is_empty:
            out.append((t, inter))

    return out


def nms_polygons(
    fused: List[Tuple[Tuple[int, ...], Polygon]],
    iou_thresh: float,
) -> List[Tuple[Tuple[int, ...], Polygon]]:
    if not fused:
        return []

    areas = np.array([poly.area for _, poly in fused], dtype=float)
    order = areas.argsort()[::-1]
    keep: List[int] = []

    while order.size > 0:
        i = int(order[0])
        keep.append(i)
        if order.size == 1:
            break

        rest = order[1:]
        pi = fused[i][1]
        ious = []
        for j in rest:
            pj = fused[int(j)][1]
            inter = pi.intersection(pj).area
            if inter <= 0.0:
                ious.append(0.0)
                continue
            union = pi.area + pj.area - inter
            ious.append(inter / union if union > 0 else 0.0)

        ious = np.array(ious, dtype=float)
        order = rest[ious <= iou_thresh]

    return [fused[i] for i in keep]


def fuse_rotated_polygons(
    polygons_by_angle: List[np.ndarray],
    max_dist: float,
    hyp_tau: float,
    min_support: int,
    nms_iou: float,
) -> Tuple[List[np.ndarray], np.ndarray]:
    polys, centroids, areas, idx_map = flatten_boxes(polygons_by_angle)
    if len(polys) == 0:
        return [], np.zeros((0,), dtype=float)

    inter_area, neigh = build_sparse_pair_data(polys, centroids, idx_map)
    neigh = apply_hypotenuse_gate(
        neigh, idx_map, polygons_by_angle, tau=hyp_tau
    )
    Z_raw = build_Z_nearest_per_angle(
        neigh,
        idx_map,
        N_angles=len(polygons_by_angle),
        max_dist=max_dist,
    )
    Z_can = canonicalize_Z_by_supersets(Z_raw, inter_area)
    Z_filt = filter_Z_min_support(Z_can, min_support=min_support)
    fused = fused_polygons_from_Z(Z_filt, polys)
    fused = nms_polygons(fused, iou_thresh=nms_iou)

    out_polys: List[np.ndarray] = []
    out_areas: List[float] = []
    for _, poly in fused:
        if poly.geom_type != "Polygon":
            continue
        coords = np.array(poly.exterior.coords, dtype=float)
        out_polys.append(coords[:, [1, 0]])
        out_areas.append(float(poly.area))

    return out_polys, np.array(out_areas, dtype=float)
