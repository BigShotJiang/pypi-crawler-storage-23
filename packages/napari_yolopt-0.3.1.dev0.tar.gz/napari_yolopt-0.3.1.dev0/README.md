# napari-yolopt

[![License BSD-3](https://img.shields.io/pypi/l/napari-yolopt.svg?color=green)](https://github.com/jules-vanaret/napari-yolopt/raw/main/LICENSE)
[![PyPI](https://img.shields.io/pypi/v/napari-yolopt.svg?color=green)](https://pypi.org/project/napari-yolopt)
[![Python Version](https://img.shields.io/pypi/pyversions/napari-yolopt.svg?color=green)](https://python.org)
[![tests](https://github.com/jules-vanaret/napari-yolopt/workflows/tests/badge.svg)](https://github.com/jules-vanaret/napari-yolopt/actions)
[![codecov](https://codecov.io/gh/jules-vanaret/napari-yolopt/branch/main/graph/badge.svg)](https://codecov.io/gh/jules-vanaret/napari-yolopt)
[![napari hub](https://img.shields.io/endpoint?url=https://api.napari-hub.org/shields/napari-yolopt)](https://napari-hub.org/plugins/napari-yolopt)
[![npe2](https://img.shields.io/badge/plugin-npe2-blue?link=https://napari.org/stable/plugins/index.html)](https://napari.org/stable/plugins/index.html)
[![Copier](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/copier-org/copier/master/img/badge/badge-grayscale-inverted-border-purple.json)](https://github.com/copier-org/copier)

Detect overlapping Pt particles using Yolo

----------------------------------

This [napari] plugin was generated with [copier] using the [napari-plugin-template] (None).

<!--
Don't miss the full getting started guide to set up your new package:
https://github.com/napari/napari-plugin-template#getting-started

and review the napari docs for plugin developers:
https://napari.org/stable/plugins/index.html
-->

## Installation

You can install `napari-yolopt` via [pip]:

```
pip install napari-yolopt
```

If napari is not already installed, you can install `napari-yolopt` with napari and Qt via:

```
pip install "napari-yolopt[all]"
```


To install latest development version :

```
pip install git+https://github.com/jules-vanaret/napari-yolopt.git
```



## Contributing

Contributions are very welcome. Tests can be run with [tox], please ensure
the coverage at least stays the same before you submit a pull request.

## License

Distributed under the terms of the [BSD-3] license,
"napari-yolopt" is free and open source software

## Issues

If you encounter any problems, please [file an issue] along with a detailed description.

[napari]: https://github.com/napari/napari
[copier]: https://copier.readthedocs.io/en/stable/
[@napari]: https://github.com/napari
[MIT]: http://opensource.org/licenses/MIT
[BSD-3]: http://opensource.org/licenses/BSD-3-Clause
[GNU GPL v3.0]: http://www.gnu.org/licenses/gpl-3.0.txt
[GNU LGPL v3.0]: http://www.gnu.org/licenses/lgpl-3.0.txt
[Apache Software License 2.0]: http://www.apache.org/licenses/LICENSE-2.0
[Mozilla Public License 2.0]: https://www.mozilla.org/media/MPL/2.0/index.txt
[napari-plugin-template]: https://github.com/napari/napari-plugin-template

[file an issue]: https://github.com/jules-vanaret/napari-yolopt/issues

[napari]: https://github.com/napari/napari
[tox]: https://tox.readthedocs.io/en/latest/
[pip]: https://pypi.org/project/pip/
[PyPI]: https://pypi.org/
