from dataclasses import dataclass, field
from typing import Dict, Any
from saviialib.general_types.api.saviia_tasks_api_types import SaviiaTasksConfig


@dataclass
class UpdateTaskControllerInput:
    task: Dict[str, Any]
    completed: bool
    config: SaviiaTasksConfig


@dataclass
class UpdateTaskControllerOutput:
    message: str
    status: int
    metadata: Dict[str, str] = field(default_factory=dict)
