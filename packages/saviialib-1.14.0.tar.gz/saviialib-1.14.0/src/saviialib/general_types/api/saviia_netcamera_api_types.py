from dataclasses import dataclass


@dataclass
class SaviiaNetcameraConfig:
    latitude: float = -91
    longitude: float = -181
