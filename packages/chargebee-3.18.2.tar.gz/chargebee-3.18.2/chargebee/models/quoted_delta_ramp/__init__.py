from .operations import QuotedDeltaRamp
from .responses import QuotedDeltaRampResponse
