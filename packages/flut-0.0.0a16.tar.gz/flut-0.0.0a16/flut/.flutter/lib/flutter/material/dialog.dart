import 'package:flutter/material.dart';
import 'package:flut/flut/runtime.dart';

class FlutAlertDialog {
  FlutAlertDialog._();

  static Widget? flutDecode(FlutRuntime runtime, Map<String, dynamic> data) {
    return AlertDialog(
      key: runtime.decodeKey(data),
      icon: runtime.unpackOptionalField<Widget>(data, 'icon'),
      iconPadding: runtime.unpackOptionalField<EdgeInsets>(data, 'iconPadding'),
      iconColor: runtime.unpackOptionalField<Color>(data, 'iconColor'),
      title: runtime.unpackOptionalField<Widget>(data, 'title'),
      titlePadding: runtime.unpackOptionalField<EdgeInsets>(
        data,
        'titlePadding',
      ),
      titleTextStyle: runtime.unpackOptionalField<TextStyle>(
        data,
        'titleTextStyle',
      ),
      content: runtime.unpackOptionalField<Widget>(data, 'content'),
      contentPadding: runtime.unpackOptionalField<EdgeInsets>(
        data,
        'contentPadding',
      ),
      contentTextStyle: runtime.unpackOptionalField<TextStyle>(
        data,
        'contentTextStyle',
      ),
      actions: runtime.unpackOptionalField<List<Widget>>(data, 'actions'),
      actionsPadding: runtime.unpackOptionalField<EdgeInsets>(
        data,
        'actionsPadding',
      ),
      actionsAlignment: runtime.unpackOptionalField<MainAxisAlignment>(
        data,
        'actionsAlignment',
      ),
      actionsOverflowAlignment: runtime
          .unpackOptionalField<OverflowBarAlignment>(
            data,
            'actionsOverflowAlignment',
          ),
      actionsOverflowDirection: runtime.unpackOptionalField<VerticalDirection>(
        data,
        'actionsOverflowDirection',
      ),
      actionsOverflowButtonSpacing: runtime.unpackOptionalField<double>(
        data,
        'actionsOverflowButtonSpacing',
      ),
      buttonPadding: runtime.unpackOptionalField<EdgeInsets>(
        data,
        'buttonPadding',
      ),
      backgroundColor: runtime.unpackOptionalField<Color>(
        data,
        'backgroundColor',
      ),
      elevation: runtime.unpackOptionalField<double>(data, 'elevation'),
      shadowColor: runtime.unpackOptionalField<Color>(data, 'shadowColor'),
      surfaceTintColor: runtime.unpackOptionalField<Color>(
        data,
        'surfaceTintColor',
      ),
      semanticLabel: runtime.unpackOptionalField<String>(data, 'semanticLabel'),
      insetPadding: runtime.unpackOptionalField<EdgeInsets>(
        data,
        'insetPadding',
      ),
      clipBehavior: runtime.unpackOptionalField<Clip>(data, 'clipBehavior'),
      shape: runtime.unpackOptionalField<ShapeBorder>(data, 'shape'),
      alignment: runtime.unpackOptionalField<AlignmentGeometry>(
        data,
        'alignment',
      ),
      constraints: runtime.unpackOptionalField<BoxConstraints>(
        data,
        'constraints',
      ),
      scrollable: runtime.unpackRequiredField<bool>(data, 'scrollable'),
    );
  }
}
