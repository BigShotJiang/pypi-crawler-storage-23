from typing import Optional, override
from flut._flut.engine import FlutValueObject, _flut_pack_value
from flut._flut.runtime import _flut_unpack_required_field

_planeMask = 0x0FF00000000

_keyLabels = {
    0x00100000008: "Backspace",
    0x00100000009: "Tab",
    0x0010000000D: "Enter",
    0x0010000001B: "Escape",
    0x0010000007F: "Delete",
    0x00100000301: "Arrow Down",
    0x00100000302: "Arrow Left",
    0x00100000303: "Arrow Right",
    0x00100000304: "Arrow Up",
    0x00100000305: "End",
    0x00100000306: "Home",
    0x00100000307: "Page Down",
    0x00100000308: "Page Up",
    0x00100000407: "Insert",
    0x00200000102: "Alt Left",
    0x00200000103: "Alt Right",
    0x00200000100: "Control Left",
    0x00200000101: "Control Right",
    0x00200000106: "Meta Left",
    0x00200000107: "Meta Right",
    0x00200000104: "Shift Left",
    0x00200000105: "Shift Right",
    0x00100000801: "F1",
    0x00100000802: "F2",
    0x00100000803: "F3",
    0x00100000804: "F4",
    0x00100000805: "F5",
    0x00100000806: "F6",
    0x00100000807: "F7",
    0x00100000808: "F8",
    0x00100000809: "F9",
    0x0010000080A: "F10",
    0x0010000080B: "F11",
    0x0010000080C: "F12",
    0x00100000104: "Caps Lock",
    0x0010000010A: "Num Lock",
    0x0010000010C: "Scroll Lock",
}


class _LogicalKeyboardKey(FlutValueObject):
    _flut_type = "LogicalKeyboardKey"

    def __init__(self, keyId: int):
        super().__init__()
        self.keyId = keyId

    @staticmethod
    def _flut_unpack(data: dict) -> "_LogicalKeyboardKey":
        return _LogicalKeyboardKey(
            keyId=_flut_unpack_required_field(data, "keyId"),
        )

    @override
    def _flut_pack(self) -> dict:
        result = self._flut_base_props()
        result["keyId"] = _flut_pack_value(self.keyId)
        return result

    @property
    def keyLabel(self) -> str:
        if self.keyId & _planeMask == 0 and self.keyId >= 0x20:
            return chr(self.keyId)
        return ""

    @property
    def debugName(self) -> Optional[str]:
        return _keyLabels.get(self.keyId)

    def __eq__(self, other):
        if isinstance(other, _LogicalKeyboardKey):
            return self.keyId == other.keyId
        return False

    def __hash__(self):
        return hash(self.keyId)

    def __repr__(self):
        name = self.debugName or f"0x{self.keyId:08x}"
        return f"LogicalKeyboardKey({name})"


class LogicalKeyboardKey(_LogicalKeyboardKey):
    space = _LogicalKeyboardKey(0x00000000020)
    exclamation = _LogicalKeyboardKey(0x00000000021)
    quote = _LogicalKeyboardKey(0x00000000022)
    numberSign = _LogicalKeyboardKey(0x00000000023)
    dollar = _LogicalKeyboardKey(0x00000000024)
    percent = _LogicalKeyboardKey(0x00000000025)
    ampersand = _LogicalKeyboardKey(0x00000000026)
    quoteSingle = _LogicalKeyboardKey(0x00000000027)
    parenthesisLeft = _LogicalKeyboardKey(0x00000000028)
    parenthesisRight = _LogicalKeyboardKey(0x00000000029)
    asterisk = _LogicalKeyboardKey(0x0000000002A)
    add = _LogicalKeyboardKey(0x0000000002B)
    comma = _LogicalKeyboardKey(0x0000000002C)
    minus = _LogicalKeyboardKey(0x0000000002D)
    period = _LogicalKeyboardKey(0x0000000002E)
    slash = _LogicalKeyboardKey(0x0000000002F)

    digit0 = _LogicalKeyboardKey(0x00000000030)
    digit1 = _LogicalKeyboardKey(0x00000000031)
    digit2 = _LogicalKeyboardKey(0x00000000032)
    digit3 = _LogicalKeyboardKey(0x00000000033)
    digit4 = _LogicalKeyboardKey(0x00000000034)
    digit5 = _LogicalKeyboardKey(0x00000000035)
    digit6 = _LogicalKeyboardKey(0x00000000036)
    digit7 = _LogicalKeyboardKey(0x00000000037)
    digit8 = _LogicalKeyboardKey(0x00000000038)
    digit9 = _LogicalKeyboardKey(0x00000000039)

    keyA = _LogicalKeyboardKey(0x00000000061)
    keyB = _LogicalKeyboardKey(0x00000000062)
    keyC = _LogicalKeyboardKey(0x00000000063)
    keyD = _LogicalKeyboardKey(0x00000000064)
    keyE = _LogicalKeyboardKey(0x00000000065)
    keyF = _LogicalKeyboardKey(0x00000000066)
    keyG = _LogicalKeyboardKey(0x00000000067)
    keyH = _LogicalKeyboardKey(0x00000000068)
    keyI = _LogicalKeyboardKey(0x00000000069)
    keyJ = _LogicalKeyboardKey(0x0000000006A)
    keyK = _LogicalKeyboardKey(0x0000000006B)
    keyL = _LogicalKeyboardKey(0x0000000006C)
    keyM = _LogicalKeyboardKey(0x0000000006D)
    keyN = _LogicalKeyboardKey(0x0000000006E)
    keyO = _LogicalKeyboardKey(0x0000000006F)
    keyP = _LogicalKeyboardKey(0x00000000070)
    keyQ = _LogicalKeyboardKey(0x00000000071)
    keyR = _LogicalKeyboardKey(0x00000000072)
    keyS = _LogicalKeyboardKey(0x00000000073)
    keyT = _LogicalKeyboardKey(0x00000000074)
    keyU = _LogicalKeyboardKey(0x00000000075)
    keyV = _LogicalKeyboardKey(0x00000000076)
    keyW = _LogicalKeyboardKey(0x00000000077)
    keyX = _LogicalKeyboardKey(0x00000000078)
    keyY = _LogicalKeyboardKey(0x00000000079)
    keyZ = _LogicalKeyboardKey(0x0000000007A)

    backspace = _LogicalKeyboardKey(0x00100000008)
    tab = _LogicalKeyboardKey(0x00100000009)
    enter = _LogicalKeyboardKey(0x0010000000D)
    escape = _LogicalKeyboardKey(0x0010000001B)
    delete = _LogicalKeyboardKey(0x0010000007F)

    arrowDown = _LogicalKeyboardKey(0x00100000301)
    arrowLeft = _LogicalKeyboardKey(0x00100000302)
    arrowRight = _LogicalKeyboardKey(0x00100000303)
    arrowUp = _LogicalKeyboardKey(0x00100000304)

    end = _LogicalKeyboardKey(0x00100000305)
    home = _LogicalKeyboardKey(0x00100000306)
    pageDown = _LogicalKeyboardKey(0x00100000307)
    pageUp = _LogicalKeyboardKey(0x00100000308)
    insert = _LogicalKeyboardKey(0x00100000407)

    altLeft = _LogicalKeyboardKey(0x00200000102)
    altRight = _LogicalKeyboardKey(0x00200000103)
    controlLeft = _LogicalKeyboardKey(0x00200000100)
    controlRight = _LogicalKeyboardKey(0x00200000101)
    metaLeft = _LogicalKeyboardKey(0x00200000106)
    metaRight = _LogicalKeyboardKey(0x00200000107)
    shiftLeft = _LogicalKeyboardKey(0x00200000104)
    shiftRight = _LogicalKeyboardKey(0x00200000105)

    f1 = _LogicalKeyboardKey(0x00100000801)
    f2 = _LogicalKeyboardKey(0x00100000802)
    f3 = _LogicalKeyboardKey(0x00100000803)
    f4 = _LogicalKeyboardKey(0x00100000804)
    f5 = _LogicalKeyboardKey(0x00100000805)
    f6 = _LogicalKeyboardKey(0x00100000806)
    f7 = _LogicalKeyboardKey(0x00100000807)
    f8 = _LogicalKeyboardKey(0x00100000808)
    f9 = _LogicalKeyboardKey(0x00100000809)
    f10 = _LogicalKeyboardKey(0x0010000080A)
    f11 = _LogicalKeyboardKey(0x0010000080B)
    f12 = _LogicalKeyboardKey(0x0010000080C)

    capsLock = _LogicalKeyboardKey(0x00100000104)
    numLock = _LogicalKeyboardKey(0x0010000010A)
    scrollLock = _LogicalKeyboardKey(0x0010000010C)


_physicalKeyLabels = {
    0x00070004: "Key A",
    0x00070005: "Key B",
    0x00070006: "Key C",
    0x00070007: "Key D",
    0x00070008: "Key E",
    0x00070009: "Key F",
    0x0007000A: "Key G",
    0x0007000B: "Key H",
    0x0007000C: "Key I",
    0x0007000D: "Key J",
    0x0007000E: "Key K",
    0x0007000F: "Key L",
    0x00070010: "Key M",
    0x00070011: "Key N",
    0x00070012: "Key O",
    0x00070013: "Key P",
    0x00070014: "Key Q",
    0x00070015: "Key R",
    0x00070016: "Key S",
    0x00070017: "Key T",
    0x00070018: "Key U",
    0x00070019: "Key V",
    0x0007001A: "Key W",
    0x0007001B: "Key X",
    0x0007001C: "Key Y",
    0x0007001D: "Key Z",
    0x0007001E: "Digit 1",
    0x0007001F: "Digit 2",
    0x00070020: "Digit 3",
    0x00070021: "Digit 4",
    0x00070022: "Digit 5",
    0x00070023: "Digit 6",
    0x00070024: "Digit 7",
    0x00070025: "Digit 8",
    0x00070026: "Digit 9",
    0x00070027: "Digit 0",
    0x00070028: "Enter",
    0x00070029: "Escape",
    0x0007002A: "Backspace",
    0x0007002B: "Tab",
    0x0007002C: "Space",
    0x0007004F: "Arrow Right",
    0x00070050: "Arrow Left",
    0x00070051: "Arrow Down",
    0x00070052: "Arrow Up",
}


class _PhysicalKeyboardKey(FlutValueObject):
    _flut_type = "PhysicalKeyboardKey"

    def __init__(self, usbHidUsage: int):
        super().__init__()
        self.usbHidUsage = usbHidUsage

    @staticmethod
    def _flut_unpack(data: dict) -> "_PhysicalKeyboardKey":
        return _PhysicalKeyboardKey(
            usbHidUsage=_flut_unpack_required_field(data, "usbHidUsage"),
        )

    @override
    def _flut_pack(self) -> dict:
        result = self._flut_base_props()
        result["usbHidUsage"] = _flut_pack_value(self.usbHidUsage)
        return result

    @property
    def debugName(self) -> Optional[str]:
        return _physicalKeyLabels.get(self.usbHidUsage)

    def __eq__(self, other):
        if isinstance(other, _PhysicalKeyboardKey):
            return self.usbHidUsage == other.usbHidUsage
        return False

    def __hash__(self):
        return hash(self.usbHidUsage)

    def __repr__(self):
        name = self.debugName or f"0x{self.usbHidUsage:08x}"
        return f"PhysicalKeyboardKey({name})"


class PhysicalKeyboardKey(_PhysicalKeyboardKey):
    keyA = _PhysicalKeyboardKey(0x00070004)
    keyB = _PhysicalKeyboardKey(0x00070005)
    keyC = _PhysicalKeyboardKey(0x00070006)
    keyD = _PhysicalKeyboardKey(0x00070007)
    keyE = _PhysicalKeyboardKey(0x00070008)
    keyF = _PhysicalKeyboardKey(0x00070009)
    keyG = _PhysicalKeyboardKey(0x0007000A)
    keyH = _PhysicalKeyboardKey(0x0007000B)
    keyI = _PhysicalKeyboardKey(0x0007000C)
    keyJ = _PhysicalKeyboardKey(0x0007000D)
    keyK = _PhysicalKeyboardKey(0x0007000E)
    keyL = _PhysicalKeyboardKey(0x0007000F)
    keyM = _PhysicalKeyboardKey(0x00070010)
    keyN = _PhysicalKeyboardKey(0x00070011)
    keyO = _PhysicalKeyboardKey(0x00070012)
    keyP = _PhysicalKeyboardKey(0x00070013)
    keyQ = _PhysicalKeyboardKey(0x00070014)
    keyR = _PhysicalKeyboardKey(0x00070015)
    keyS = _PhysicalKeyboardKey(0x00070016)
    keyT = _PhysicalKeyboardKey(0x00070017)
    keyU = _PhysicalKeyboardKey(0x00070018)
    keyV = _PhysicalKeyboardKey(0x00070019)
    keyW = _PhysicalKeyboardKey(0x0007001A)
    keyX = _PhysicalKeyboardKey(0x0007001B)
    keyY = _PhysicalKeyboardKey(0x0007001C)
    keyZ = _PhysicalKeyboardKey(0x0007001D)

    digit1 = _PhysicalKeyboardKey(0x0007001E)
    digit2 = _PhysicalKeyboardKey(0x0007001F)
    digit3 = _PhysicalKeyboardKey(0x00070020)
    digit4 = _PhysicalKeyboardKey(0x00070021)
    digit5 = _PhysicalKeyboardKey(0x00070022)
    digit6 = _PhysicalKeyboardKey(0x00070023)
    digit7 = _PhysicalKeyboardKey(0x00070024)
    digit8 = _PhysicalKeyboardKey(0x00070025)
    digit9 = _PhysicalKeyboardKey(0x00070026)
    digit0 = _PhysicalKeyboardKey(0x00070027)

    enter = _PhysicalKeyboardKey(0x00070028)
    escape = _PhysicalKeyboardKey(0x00070029)
    backspace = _PhysicalKeyboardKey(0x0007002A)
    tab = _PhysicalKeyboardKey(0x0007002B)
    space = _PhysicalKeyboardKey(0x0007002C)

    arrowRight = _PhysicalKeyboardKey(0x0007004F)
    arrowLeft = _PhysicalKeyboardKey(0x00070050)
    arrowDown = _PhysicalKeyboardKey(0x00070051)
    arrowUp = _PhysicalKeyboardKey(0x00070052)
