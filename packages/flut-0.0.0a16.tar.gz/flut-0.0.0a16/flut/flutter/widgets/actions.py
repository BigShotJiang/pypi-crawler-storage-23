from typing import Callable, Optional, override

from flut._flut.engine import FlutValueObject, FlutRealtimeObject, _flut_pack_value
from flut.flutter.widgets.framework import Widget


class Intent(FlutValueObject):
    """Base class for intents. Users subclass to define intent types.

    Subclasses can carry data fields that are passed to onInvoke:

        class DeleteIntent(Intent):
            def __init__(self, itemId):
                super().__init__()
                self.itemId = itemId

        CallbackAction(onInvoke=lambda intent: delete(intent.itemId))
    """

    _flut_type = "Intent"

    def __init__(self):
        super().__init__()

    @staticmethod
    def _flut_unpack(data: dict) -> "Intent":
        return Intent()

    @override
    def _flut_pack(self) -> dict:
        result = self._flut_base_props()
        result["intentName"] = type(self).__name__
        # Serialize user fields
        data = {}
        for k, v in self.__dict__.items():
            if not k.startswith("_"):
                data[k] = _flut_pack_value(v)
        if data:
            result["data"] = data
        return result


def _reconstruct_intent(intent_class, intent_data):
    """Reconstruct an Intent subclass instance from wire data dict."""
    intent = intent_class.__new__(intent_class)
    Intent.__init__(intent)
    if intent_data and isinstance(intent_data, dict):
        for k, v in intent_data.items():
            setattr(intent, k, v)
    return intent


class CallbackAction:
    """Wraps a callback as an Action for use with the Actions widget.

    Mirrors Flutter's CallbackAction<T extends Intent>.
    onInvoke receives the Intent instance, matching Flutter's API.
    """

    def __init__(self, *, onInvoke: Callable):
        self.onInvoke = onInvoke


class ActionDispatcher(FlutRealtimeObject):
    """Intercepts action dispatch for logging, analytics, or custom behavior.

    Default implementation calls action.onInvoke(intent).
    Override invokeAction to intercept:

        class LoggingDispatcher(ActionDispatcher):
            def invokeAction(self, action, intent, context=None):
                print(f"Dispatching {type(intent).__name__}")
                return super().invokeAction(action, intent, context)
    """

    _flut_type = "ActionDispatcher"

    def __init__(self):
        super().__init__()
        self._flut_create()

    def invokeAction(self, action, intent, context=None):
        """Invoke the action for the given intent.

        Override in subclasses to add pre/post processing.
        Call super().invokeAction(action, intent, context) to execute
        the default behavior.
        """
        return action.onInvoke(intent)


class Actions(Widget):
    """Maps Intent types to Action callbacks.

    Uses FlutActionScope InheritedWidget with name-based dispatch
    via visitAncestorElements, bypassing Dart's type-based lookup.
    """

    _flut_type = "Actions"

    def __init__(
        self,
        *,
        key=None,
        dispatcher: "ActionDispatcher | None" = None,
        actions: dict,
        child: Widget,
    ):
        super().__init__(key=key)
        self.dispatcher = dispatcher
        self.actions = actions
        self.child = child

    @override
    def _flut_pack(self) -> dict:
        result = self._flut_base_props()
        actions_map = {}
        for intent_class, action in self.actions.items():
            intent_name = intent_class.__name__
            # Wrap onInvoke to reconstruct the Intent from wire data
            user_fn = action.onInvoke
            cls = intent_class

            def _make_wrapper(c, f, action_obj, disp):
                def _wrapper(intent_data=None):
                    intent = _reconstruct_intent(c, intent_data)
                    if disp is not None:
                        return disp.invokeAction(action_obj, intent)
                    return f(intent)

                return _wrapper

            wrapper = _make_wrapper(cls, user_fn, action, self.dispatcher)
            action_cb = self._register_action(wrapper, "VoidCallback")
            actions_map[intent_name] = action_cb._flut_pack()
        result["actions"] = actions_map
        if self.dispatcher is not None:
            result["dispatcher"] = _flut_pack_value(self.dispatcher)
        result["child"] = _flut_pack_value(self.child)
        return result

    @staticmethod
    def invoke(context, intent):
        """Invoke the action for the given intent type.

        Asserts if no matching action is found.
        """
        from flut._flut.engine import call_dart_static

        return call_dart_static(
            "Actions", "invoke", context._flut_pack(), intent._flut_pack()
        )

    @staticmethod
    def maybeInvoke(context, intent):
        """Invoke the action for the given intent, or return None if not found."""
        from flut._flut.engine import call_dart_static

        return call_dart_static(
            "Actions", "maybeInvoke", context._flut_pack(), intent._flut_pack()
        )
