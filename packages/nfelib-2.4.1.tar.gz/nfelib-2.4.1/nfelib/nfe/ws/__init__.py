from . import edoc_legacy  # noqa: F401
