"""Difflicious - A sleek web-based git diff visualization tool."""

__version__ = "0.11.0"
__author__ = "Drew"
__description__ = "A sleek web-based git diff visualization tool for developers"
