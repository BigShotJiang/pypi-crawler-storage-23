from torchbayesian.bnn.priors.base import Prior
from torchbayesian.bnn.priors.gaussian_prior import GaussianPrior, NormalPrior
