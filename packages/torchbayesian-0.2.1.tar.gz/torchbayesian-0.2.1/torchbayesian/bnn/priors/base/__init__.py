from torchbayesian.bnn.priors.base.prior import Prior
