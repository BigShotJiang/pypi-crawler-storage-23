#! /usr/bin/env python3
"""
meshcutter - Gridfinity mesh profile cutter.

Cut gridfinity micro-division profiles into existing STL/3MF models
using mesh boolean operations.

Part of the microfinity package - shares version with microfinity.

Note: This package requires numpy and trimesh. Import individual modules
for lighter-weight usage when possible.
"""

from typing import Any

from microfinity import __version__

__all__ = [
    "__version__",
    "detect_bottom_frame",
    "extract_footprint",
    "generate_grid_mask",
    "compute_grid_positions",
    "generate_cutter",
    "boolean_difference",
    "repair_mesh",
    "load_mesh",
    "export_stl",
]


def __getattr__(name: str) -> Any:
    """Lazy-load meshcutter symbols to avoid requiring numpy/trimesh at import time."""
    # Detection module
    if name in ("detect_bottom_frame", "extract_footprint"):
        from meshcutter import detection

        return getattr(detection, name)

    # Mesh operations
    if name in ("generate_grid_mask", "compute_grid_positions", "boolean_difference", "repair_mesh"):
        from meshcutter import mesh

        return getattr(mesh, name)

    # Cutter generation
    if name == "generate_cutter":
        from meshcutter import cutter

        return getattr(cutter, name)

    # IO
    if name == "load_mesh":
        from meshcutter.io import loader

        return loader.load_mesh
    if name == "export_stl":
        from meshcutter.io import exporter

        return exporter.export_stl

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
