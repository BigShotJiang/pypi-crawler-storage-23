#! /usr/bin/env python3
"""
meshcutter.detection - Mesh analysis and footprint detection.

Provides functions for detecting bottom frames and extracting footprints
from Gridfinity mesh models.
"""

from meshcutter.detection.footprint import detect_bottom_frame, extract_footprint
from meshcutter.detection.validation import validate_mesh_quality, validate_cutter_geometry

__all__ = [
    "detect_bottom_frame",
    "extract_footprint",
    "validate_mesh_quality",
    "validate_cutter_geometry",
]
