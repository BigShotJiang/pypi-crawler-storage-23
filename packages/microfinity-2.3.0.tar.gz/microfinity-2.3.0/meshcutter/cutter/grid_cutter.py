#! /usr/bin/env python3
#
# meshcutter.cutter.grid_cutter - Grid cutter generation and mesh conversion
#
# Handles full grid cutter assembly, boundary fill, and mesh output generation.
# Extracted from cq.py as part of Cutter bloat refactoring Phase 2d.
#

from __future__ import annotations

import os
import tempfile
import warnings
from typing import List, Optional, Sequence, Tuple

import cadquery as cq
import trimesh

from meshcutter.constants import GR_BASE_CLR, GR_BASE_HEIGHT, GR_TOL, GRU
from meshcutter.cutter.seams import generate_intercell_channels


def generate_boundary_fill(
    cell_centers: Sequence[Tuple[float, float]],
    pitch: float = GRU,
    epsilon: float = 0.02,
    footprint_bounds: Optional[Tuple[float, float, float, float]] = None,
) -> Optional[cq.Workplane]:
    """Generate boundary fill to cover outer chamfer regions of edge cells.

    The cell cutter is based on the cropped F1 envelope (41.5mm), but the input
    mesh's 1U feet have chamfers that extend slightly beyond this boundary at
    the outer perimeter. This creates thin residual strips at the outer edges.

    IMPORTANT: Unlike inter-cell channels, the boundary fill should NOT extend
    inward into the micro-feet region. At the outer perimeter:
    - The outermost micro-foot edge is at the grid boundary (cell_center ± 20.75)
    - We only need to cut the tiny sliver of 1U foot material OUTSIDE this boundary
    - This is just the GR_TOL/2 = 0.25mm that extends beyond the cropped envelope

    The boundary fill is a thin ring that extends OUTWARD from the grid boundary,
    not inward. This prevents cutting into the outer micro-feet.

    Args:
        cell_centers: List of (x, y) cell center coordinates
        pitch: 1U pitch (default 42mm)
        epsilon: Extension below z=0 (mm)
        footprint_bounds: Optional (x_min, y_min, x_max, y_max) to constrain the
                         outer extent of the boundary fill to the model footprint.
                         If None, extends slightly beyond grid boundary.

    Returns:
        CadQuery Workplane with boundary fill, or None if not needed
    """
    if not cell_centers:
        return None

    # Find grid extents
    xs = sorted(set(cx for cx, cy in cell_centers))
    ys = sorted(set(cy for cx, cy in cell_centers))

    x_min_cell = min(xs)
    x_max_cell = max(xs)
    y_min_cell = min(ys)
    y_max_cell = max(ys)

    # Grid outer boundary (center of outer cells ± half of cropped F1 envelope)
    # This is where the outermost micro-feet edges are
    # Cropped F1 envelope = pitch - GR_TOL = 41.5mm, so half = 20.75mm
    grid_x_min = x_min_cell - (pitch - GR_TOL) / 2
    grid_x_max = x_max_cell + (pitch - GR_TOL) / 2
    grid_y_min = y_min_cell - (pitch - GR_TOL) / 2
    grid_y_max = y_max_cell + (pitch - GR_TOL) / 2

    # The boundary fill should only extend OUTWARD from the grid boundary
    # to cut the small amount of 1U material beyond the micro-feet.
    # This is approximately GR_TOL/2 = 0.25mm plus a small margin.
    eps_xy = 0.05
    outward_extend = GR_TOL / 2.0 + eps_xy  # ~0.3mm outward only

    # Z range matches the cell cutter
    z_min_foot = -GR_BASE_HEIGHT  # -4.75mm
    z_max_foot = GR_BASE_CLR  # 0.25mm exactly (no epsilon on top)
    fill_height = z_max_foot - z_min_foot
    z_center = (z_min_foot + z_max_foot) / 2.0

    # Outer boundary: extend outward from grid boundary, but clip to footprint
    outer_x_min = grid_x_min - outward_extend
    outer_x_max = grid_x_max + outward_extend
    outer_y_min = grid_y_min - outward_extend
    outer_y_max = grid_y_max + outward_extend

    # Clip outer boundary to footprint bounds if provided
    if footprint_bounds is not None:
        outer_x_min = max(outer_x_min, footprint_bounds[0])
        outer_x_max = min(outer_x_max, footprint_bounds[2])
        outer_y_min = max(outer_y_min, footprint_bounds[1])
        outer_y_max = min(outer_y_max, footprint_bounds[3])

    # Inner boundary: exactly at the grid boundary (micro-feet edge)
    # This means the ring only covers the area OUTSIDE the micro-feet
    inner_x_min = grid_x_min
    inner_x_max = grid_x_max
    inner_y_min = grid_y_min
    inner_y_max = grid_y_max

    # Grid center for positioning
    grid_center_x = (x_min_cell + x_max_cell) / 2.0
    grid_center_y = (y_min_cell + y_max_cell) / 2.0

    # Create outer box
    outer_width = outer_x_max - outer_x_min
    outer_height = outer_y_max - outer_y_min
    outer_box = (
        cq.Workplane("XY")
        .box(outer_width, outer_height, fill_height)
        .translate(cq.Vector(grid_center_x, grid_center_y, z_center))
    )

    # Create inner cutout at the grid boundary
    inner_width = inner_x_max - inner_x_min
    inner_height = inner_y_max - inner_y_min
    if inner_width > 0 and inner_height > 0:
        inner_box = (
            cq.Workplane("XY")
            .box(inner_width, inner_height, fill_height + 1)  # slightly taller for clean cut
            .translate(cq.Vector(grid_center_x, grid_center_y, z_center))
        )
        frame = outer_box.cut(inner_box)
    else:
        # Grid too small for ring, use solid rect
        frame = outer_box

    return frame


def generate_grid_cutter_cq(
    cell_centers: Sequence[Tuple[float, float]],
    generate_cell_cutter_cq_fn,
    micro_divisions: int = 4,
    epsilon: float = 0.02,
    overshoot: float = 0.0,
    wall_cut: float = 0.0,
    add_channels: bool = False,
    footprint_bounds: Optional[Tuple[float, float, float, float]] = None,
) -> cq.Workplane:
    """Generate full grid cutter in CadQuery (one export, one subtract).

    Instances the cell cutter at each detected cell center and unions them
    all in CadQuery before export. This minimizes triangle boolean operations.

    Args:
        cell_centers: List of (x, y) cell center coordinates
        generate_cell_cutter_cq_fn: Function to generate cell cutter (injected dependency)
        micro_divisions: Number of divisions (2 or 4)
        epsilon: Extension below z=0 (mm)
        overshoot: Extension beyond F1 boundary to cut outer walls (mm)
        wall_cut: Shrink micro-feet to cut outer walls (mm)
        add_channels: If True, add inter-cell channel cutters
        footprint_bounds: Optional (x_min, y_min, x_max, y_max) to clip channels
                         and boundary fill to model footprint. Prevents corner
                         clipping artifacts when cutter extends beyond model.

    Returns:
        CadQuery Workplane with complete grid cutter solid
    """
    if not cell_centers:
        raise ValueError("No cell centers provided")

    # Get the cached cell cutter
    cell_cutter = generate_cell_cutter_cq_fn(micro_divisions, epsilon, overshoot, wall_cut)
    cell_solid = cell_cutter.val()

    # Instance at each cell center
    grid_cutter = None
    for cx, cy in cell_centers:
        instance = cell_solid.translate(cq.Vector(cx, cy, 0))
        if grid_cutter is None:
            grid_cutter = instance
        else:
            grid_cutter = grid_cutter.fuse(instance)

    # Add inter-cell channels if requested
    if add_channels and len(cell_centers) > 1:
        channels_cq = generate_intercell_channels(cell_centers, GRU, epsilon, footprint_bounds)
        if channels_cq is not None:
            grid_cutter = grid_cutter.fuse(channels_cq.val())

    # Add boundary fill to cover outer chamfer regions
    if add_channels:
        boundary_fill = generate_boundary_fill(cell_centers, GRU, epsilon, footprint_bounds)
        if boundary_fill is not None:
            grid_cutter = grid_cutter.fuse(boundary_fill.val())

    # Z-clipping safeguard: Intersect with half-space to enforce Z <= GR_BASE_CLR
    # This catches any epsilon/rounding drift from channels or boundary fill.
    # Creates a large bounding box that ends exactly at z=GR_BASE_CLR (foot base plane).
    bb = grid_cutter.BoundingBox()
    clip_margin = 10.0  # Extra margin in XY to ensure full coverage
    clip_box = (
        cq.Workplane("XY")
        .box(
            bb.xmax - bb.xmin + 2 * clip_margin,
            bb.ymax - bb.ymin + 2 * clip_margin,
            GR_BASE_CLR - bb.zmin + clip_margin,  # From below cutter to exactly GR_BASE_CLR
        )
        .translate(
            cq.Vector(
                (bb.xmin + bb.xmax) / 2,
                (bb.ymin + bb.ymax) / 2,
                (bb.zmin - clip_margin + GR_BASE_CLR) / 2,  # Center the box vertically
            )
        )
    )
    grid_cutter = grid_cutter.intersect(clip_box.val())

    # Assert that Z max is within tolerance of GR_BASE_CLR
    final_bb = grid_cutter.BoundingBox()
    assert (
        final_bb.zmax <= GR_BASE_CLR + 1e-6
    ), f"Cutter Z max ({final_bb.zmax:.6f}) exceeds GR_BASE_CLR ({GR_BASE_CLR})"

    return cq.Workplane("XY").newObject([grid_cutter])


def cq_to_trimesh(
    cq_obj: cq.Workplane,
    tol: float = 0.01,
    ang_tol: float = 0.1,
) -> trimesh.Trimesh:
    """Convert CadQuery Workplane to trimesh with proper cleanup.

    Exports to STL via temp file, then loads with trimesh.
    Temp file is automatically cleaned up.

    Args:
        cq_obj: CadQuery Workplane to convert
        tol: Linear mesh tolerance (mm)
        ang_tol: Angular mesh tolerance (radians)

    Returns:
        trimesh.Trimesh mesh
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        stl_path = os.path.join(tmpdir, "cutter.stl")
        cq.exporters.export(
            cq_obj,
            stl_path,
            exportType="STL",
            tolerance=tol,
            angularTolerance=ang_tol,
        )
        mesh = trimesh.load(stl_path)

    return mesh


def apply_bottom_epsilon_preserve_top(mesh: trimesh.Trimesh, epsilon: float) -> None:
    """Apply coplanar avoidance by pushing bottom down while preserving top.

    Maps Z range [zmin, zmax] -> [zmin - epsilon, zmax] using affine transform.
    This cannot create internal faces because it only moves vertices.

    The transform is:
        z_new = -epsilon + (z - zmin) * (h + epsilon) / h

    Where h = zmax - zmin. This keeps:
        - z=zmin -> -epsilon (bottom gets pushed down)
        - z=zmax -> h (top stays exactly where it was after normalization)

    Args:
        mesh: Trimesh to modify in-place
        epsilon: Amount to push bottom below Z=0
    """
    if epsilon <= 0:
        return

    zmin = float(mesh.vertices[:, 2].min())
    zmax = float(mesh.vertices[:, 2].max())
    h = zmax - zmin

    if h <= 1e-9:
        raise ValueError(f"Degenerate cutter height: h={h}")

    # Normalize so bottom is at 0, top at h
    mesh.vertices[:, 2] -= zmin

    # Affine map [0, h] -> [-epsilon, h]
    # z_new = -epsilon + z * (h + epsilon) / h
    scale = (h + epsilon) / h
    mesh.vertices[:, 2] = -epsilon + mesh.vertices[:, 2] * scale


def generate_grid_cutter_meshes(
    cell_centers: Sequence[Tuple[float, float]],
    generate_cell_cutter_cq_fn,
    micro_divisions: int = 4,
    epsilon: float = 0.02,
    tol: float = 0.01,
    ang_tol: float = 0.1,
    flip_z: bool = True,
    overshoot: float = 0.0,
    wall_cut: float = 0.0,
    add_channels: bool = False,
) -> List[trimesh.Trimesh]:
    """Generate grid cutter as list of individual cell cutter meshes.

    This approach keeps each cell cutter as a separate watertight mesh,
    which works better with manifold boolean operations that can handle
    multiple tool meshes.

    Args:
        cell_centers: List of (x, y) cell center coordinates
        generate_cell_cutter_cq_fn: Function to generate cell cutter (injected dependency)
        micro_divisions: Number of divisions (2 or 4)
        epsilon: Extension below z=0 (mm)
        tol: STL export tolerance
        ang_tol: STL export angular tolerance
        flip_z: If True, flip Z coordinates so foot points upward (z=0 to z~5)
                matching typical STL exports. Default True.
        overshoot: Extension beyond F1 boundary to cut outer walls (mm)
        wall_cut: Shrink micro-feet to cut outer walls (mm)
        add_channels: If True, add inter-cell channel cutters to cut material
                      between adjacent cells. Only needed for solid-walled 1U
                      boxes. Default False.

    Returns:
        List of trimesh.Trimesh meshes, one per cell
    """
    if not cell_centers:
        raise ValueError("No cell centers provided")

    # Generate the template cell cutter mesh (watertight)
    cell_cutter_cq = generate_cell_cutter_cq_fn(micro_divisions, epsilon, overshoot, wall_cut)
    cell_mesh = cq_to_trimesh(cell_cutter_cq, tol=tol, ang_tol=ang_tol)

    # Align Z if requested (default) to match typical STL orientation
    # The CQ cutter has foot tip at z≈-4.75, base at z≈0.25 (after mirror in CQ)
    # STL exports typically have foot tip at z=0, base at z≈5
    # We just need to TRANSLATE upward, NOT negate/reflect Z
    # This preserves the correct taper direction (narrow at bottom, wide at top)
    cell_z_min = None
    if flip_z:
        # Shift so the minimum Z (foot tip) is at z=-epsilon
        # This ensures the cutter extends BELOW the model's z=0 bottom plane,
        # avoiding coplanar faces that cause non-manifold edges
        cell_z_min = cell_mesh.vertices[:, 2].min()
        cell_mesh.vertices[:, 2] -= cell_z_min  # Now tip is at z=0
        cell_mesh.vertices[:, 2] -= epsilon  # Now tip is at z=-epsilon
        # No invert() needed since we didn't negate/reflect

    # Instance at each cell center
    meshes = []
    for cx, cy in cell_centers:
        instance = cell_mesh.copy()
        instance.apply_translation([cx, cy, 0])
        meshes.append(instance)

    # Add inter-cell channel cutters if requested and there are multiple cells
    # These cut away the remaining 1U foot wall material between adjacent cells
    # Only needed for solid-walled 1U boxes, not for natively-generated microfinity boxes
    if add_channels and len(cell_centers) > 1:
        channels_cq = generate_intercell_channels(cell_centers, GRU, epsilon)
        if channels_cq is not None:
            channels_mesh = cq_to_trimesh(channels_cq, tol=tol, ang_tol=ang_tol)
            if flip_z:
                # Use the SAME z_min as cell cutters for consistent Z alignment
                # This ensures channels end at the same Z level as the cell cutters
                # (i.e., at Z=5.0 in world coordinates, matching the foot base)
                if cell_z_min is not None:
                    channels_mesh.vertices[:, 2] -= cell_z_min
                    channels_mesh.vertices[:, 2] -= epsilon
            meshes.append(channels_mesh)

    return meshes


def generate_grid_cutter_mesh(
    cell_centers: Sequence[Tuple[float, float]],
    generate_cell_cutter_cq_fn,
    generate_grid_cutter_cq_fn,
    micro_divisions: int = 4,
    epsilon: float = 0.02,
    tol: float = 0.01,
    ang_tol: float = 0.1,
    flip_z: bool = True,
    overshoot: float = 0.0,
    wall_cut: float = 0.0,
    add_channels: bool = False,
    fast_mode: bool = False,
    footprint_bounds: Optional[Tuple[float, float, float, float]] = None,
) -> trimesh.Trimesh:
    """Generate grid cutter as a single mesh.

    ALWAYS uses CadQuery fusion for robustness (eliminates boolean slivers).
    The fast_mode option exists for debugging but is not recommended for
    production use as it may leave slivers or asymmetric artifacts.

    The top of the cutter is extended by epsilon before the Z-shift, ensuring
    the final cutter top is at exactly Z=5.0 (not truncated by epsilon).

    Args:
        cell_centers: List of (x, y) cell center coordinates
        generate_cell_cutter_cq_fn: Function to generate cell cutter
        generate_grid_cutter_cq_fn: Function to generate full grid cutter
        micro_divisions: Number of divisions (2 or 4)
        epsilon: Extension below z=0 (mm)
        tol: STL export tolerance
        ang_tol: STL export angular tolerance
        flip_z: If True, flip Z so foot points upward (z=0 to z~5). Default True.
        overshoot: Extension beyond F1 boundary to cut outer walls (mm)
        wall_cut: Shrink micro-feet to cut outer walls (mm)
        add_channels: If True, add inter-cell channel cutters. Default False.
        fast_mode: If True, use mesh concatenation instead of CQ fusion (debug only).
                   WARNING: May leave slivers/asymmetry due to non-fused shells.
        footprint_bounds: Optional (x_min, y_min, x_max, y_max) to clip channels
                         and boundary fill to model footprint.

    Returns:
        trimesh.Trimesh with all cell cutters
    """
    # Fast mode: use mesh concatenation (debug only, may have slivers)
    if fast_mode:
        warnings.warn(
            "fast_mode=True may leave slivers/asymmetry due to non-fused shells. " "Use only for debugging.",
            UserWarning,
        )
        meshes = generate_grid_cutter_meshes(
            cell_centers,
            generate_cell_cutter_cq_fn,
            micro_divisions,
            epsilon,
            tol,
            ang_tol,
            flip_z,
            overshoot,
            wall_cut,
            add_channels=add_channels,
        )
        if len(meshes) == 1:
            return meshes[0]
        return trimesh.util.concatenate(meshes)

    # Default: Always use CadQuery fusion for robustness
    # This eliminates boolean slivers from overlapping mesh shells
    cq_cutter = generate_grid_cutter_cq_fn(
        cell_centers,
        generate_cell_cutter_cq_fn,
        micro_divisions,
        epsilon,
        overshoot,
        wall_cut,
        add_channels=add_channels,
        footprint_bounds=footprint_bounds,
    )

    # Convert to trimesh (no box-fusing operations that create internal faces)
    mesh = cq_to_trimesh(cq_cutter, tol=tol, ang_tol=ang_tol)

    if flip_z:
        # Apply coplanar avoidance as a pure affine transform.
        # This pushes the bottom down by epsilon while preserving the top,
        # WITHOUT creating internal coincident faces (which caused "stacked
        # Z sheets" artifacts like 4.98/5.00/5.02).
        apply_bottom_epsilon_preserve_top(mesh, epsilon)

    return mesh
