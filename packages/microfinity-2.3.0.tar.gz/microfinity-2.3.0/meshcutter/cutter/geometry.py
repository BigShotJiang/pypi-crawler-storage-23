"""meshcutter.cutter.geometry - Geometry utilities for cutter operations.

This module provides low-level geometry utilities used by the cutter system,
including quantization for float comparison, coordinate transformations,
and geometric calculations.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import numpy as np


def quantize(v: float, precision: float = 0.1) -> float:
    """Quantize a float value to avoid comparison issues.

    Uses half-away-from-zero rounding to ensure deterministic behavior
    for both positive and negative values.

    Args:
        v: Value to quantize
        precision: Quantization precision (default: 0.1)

    Returns:
        Quantized value

    Example:
        >>> quantize(10.05, 0.1)
        10.1
        >>> quantize(10.04, 0.1)
        10.0
        >>> quantize(-10.05, 0.1)
        -10.1
    """
    # Use half-away-from-zero rounding for deterministic behavior
    scaled = v / precision
    if scaled >= 0:
        return int(scaled + 0.5) * precision
    else:
        return int(scaled - 0.5) * precision


def quantize_point(x: float, y: float, precision: float = 0.1) -> Tuple[float, float]:
    """Quantize a 2D point.

    Args:
        x: X coordinate
        y: Y coordinate
        precision: Quantization precision (default: 0.1)

    Returns:
        Quantized (x, y) tuple
    """
    return (quantize(x, precision), quantize(y, precision))


def uniquify_points(points: Sequence[Tuple[float, float]], precision: float = 0.1) -> List[Tuple[float, float]]:
    """Remove duplicate points using quantization.

    Args:
        points: List of (x, y) points
        precision: Quantization precision (default: 0.1)

    Returns:
        List of unique points
    """
    seen = set()
    unique = []
    for x, y in points:
        key = (quantize(x, precision), quantize(y, precision))
        if key not in seen:
            seen.add(key)
            unique.append((x, y))
    return unique


def get_grid_lines(points: Sequence[Tuple[float, float]], precision: float = 0.1) -> Tuple[List[float], List[float]]:
    """Extract unique X and Y grid lines from points.

    Args:
        points: List of (x, y) points
        precision: Quantization precision (default: 0.1)

    Returns:
        Tuple of (sorted unique X coordinates, sorted unique Y coordinates)
    """
    xs = sorted(set(quantize(x, precision) for x, y in points))
    ys = sorted(set(quantize(y, precision) for x, y in points))
    return xs, ys


def compute_midpoints(coords: Sequence[float]) -> List[float]:
    """Compute midpoints between consecutive coordinates.

    Args:
        coords: Sorted list of coordinates

    Returns:
        List of midpoints

    Example:
        >>> compute_midpoints([0.0, 10.0, 20.0])
        [5.0, 15.0]
    """
    return [(coords[i] + coords[i + 1]) / 2.0 for i in range(len(coords) - 1)]


def is_point_in_bounds(x: float, y: float, bounds: Tuple[float, float, float, float]) -> bool:
    """Check if a point is within bounds.

    Args:
        x: X coordinate
        y: Y coordinate
        bounds: (min_x, min_y, max_x, max_y) tuple

    Returns:
        True if point is within bounds
    """
    min_x, min_y, max_x, max_y = bounds
    return min_x <= x <= max_x and min_y <= y <= max_y


def offset_point(x: float, y: float, dx: float, dy: float) -> Tuple[float, float]:
    """Offset a point by (dx, dy).

    Args:
        x: X coordinate
        y: Y coordinate
        dx: X offset
        dy: Y offset

    Returns:
        Offset (x, y) tuple
    """
    return (x + dx, y + dy)


def compute_distance(p1: Tuple[float, float], p2: Tuple[float, float]) -> float:
    """Compute Euclidean distance between two points.

    Args:
        p1: First point (x, y)
        p2: Second point (x, y)

    Returns:
        Euclidean distance
    """
    return np.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)


def snap_to_grid(value: float, grid_size: float) -> float:
    """Snap a value to the nearest grid point.

    Args:
        value: Value to snap
        grid_size: Grid size

    Returns:
        Snapped value
    """
    return round(value / grid_size) * grid_size


__all__ = [
    "quantize",
    "quantize_point",
    "uniquify_points",
    "get_grid_lines",
    "compute_midpoints",
    "is_point_in_bounds",
    "offset_point",
    "compute_distance",
    "snap_to_grid",
]
