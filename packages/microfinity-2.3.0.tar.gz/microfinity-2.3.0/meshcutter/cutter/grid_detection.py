"""meshcutter.cutter.grid_detection - Grid and cell intersection detection.

This module provides utilities for detecting grid structures and cell intersections
in mesh cutter operations, including 4-cell meeting points and seam networks.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

from meshcutter.constants import GRU
from meshcutter.cutter.geometry import quantize


def detect_four_cell_intersections(
    cell_centers: Sequence[Tuple[float, float]],
    pitch: float = GRU,
) -> List[Tuple[float, float]]:
    """Detect points where exactly 4 cells meet.

    A 4-cell intersection exists at (xb, yb) if and only if all four adjacent
    cells exist: (x_left, y_down), (x_left, y_up), (x_right, y_down), (x_right, y_up)

    This is robust for arbitrary grids including ragged/non-rectangular layouts.

    Args:
        cell_centers: List of (x, y) cell center coordinates
        pitch: 1U pitch (default 42mm)

    Returns:
        List of (x, y) coordinates where 4 cells meet
    """
    if len(cell_centers) < 4:
        return []

    # Create a set for fast lookup (quantize to avoid float comparison issues)
    cell_set = {(quantize(cx), quantize(cy)) for cx, cy in cell_centers}

    # Find unique X and Y coordinates
    xs = sorted(set(quantize(cx) for cx, cy in cell_centers))
    ys = sorted(set(quantize(cy) for cx, cy in cell_centers))

    # Find all valid 4-cell intersections
    intersections = []

    for i in range(len(xs) - 1):
        x_left = xs[i]
        x_right = xs[i + 1]
        x_boundary = (x_left + x_right) / 2.0

        for j in range(len(ys) - 1):
            y_down = ys[j]
            y_up = ys[j + 1]
            y_boundary = (y_down + y_up) / 2.0

            # Check if all 4 adjacent cells exist
            has_all_four = (
                (quantize(x_left), quantize(y_down)) in cell_set
                and (quantize(x_left), quantize(y_up)) in cell_set
                and (quantize(x_right), quantize(y_down)) in cell_set
                and (quantize(x_right), quantize(y_up)) in cell_set
            )

            if has_all_four:
                intersections.append((x_boundary, y_boundary))

    return intersections


def detect_seam_network(
    cell_centers: Sequence[Tuple[float, float]],
    pitch: float = GRU,
    footprint_bounds: Optional[Tuple[float, float, float, float]] = None,
) -> List[Tuple[float, float, List[str]]]:
    """Detect all seam nodes in the inter-cell channel network.

    A seam node is any point where channels meet or terminate. This includes:
    - Degree 4: Internal 4-cell crossings (4 incident channels)
    - Degree 3: T-junctions at boundaries or cutouts (3 incident channels)
    - Degree 2: Edge terminations where channels meet boundary (2 incident channels)

    Each node is returned with its incident channel directions.

    Args:
        cell_centers: List of (x, y) cell center coordinates
        pitch: 1U pitch (default 42mm)
        footprint_bounds: Optional (x_min, y_min, x_max, y_max) clipping bounds

    Returns:
        List of (node_x, node_y, incident_directions) tuples where
        incident_directions is a list of 'N', 'S', 'E', 'W' indicating
        which channel directions are present at this node.
    """
    if len(cell_centers) < 2:
        return []

    # Quantize for float comparison
    cell_set = {(quantize(cx), quantize(cy)) for cx, cy in cell_centers}

    # Find unique X and Y coordinates (grid lines)
    xs = sorted(set(quantize(cx) for cx, cy in cell_centers))
    ys = sorted(set(quantize(cy) for cx, cy in cell_centers))

    # Channel seam locations:
    # - Vertical seams (between X columns): at X = (xs[i] + xs[i+1]) / 2
    # - Horizontal seams (between Y rows): at Y = (ys[j] + ys[j+1]) / 2
    x_seams = [(xs[i] + xs[i + 1]) / 2.0 for i in range(len(xs) - 1)]
    y_seams = [(ys[j] + ys[j + 1]) / 2.0 for j in range(len(ys) - 1)]

    seam_nodes = []

    # Internal nodes: where vertical and horizontal seams cross
    for x_seam in x_seams:
        for y_seam in y_seams:
            # Check which cells exist around this crossing
            # A channel exists in a direction if both cells along it exist

            # Find the two X columns this seam is between
            x_left = None
            x_right = None
            for i in range(len(xs) - 1):
                if abs((xs[i] + xs[i + 1]) / 2.0 - x_seam) < 0.01:
                    x_left = xs[i]
                    x_right = xs[i + 1]
                    break

            # Find the two Y rows this seam is between
            y_down = None
            y_up = None
            for j in range(len(ys) - 1):
                if abs((ys[j] + ys[j + 1]) / 2.0 - y_seam) < 0.01:
                    y_down = ys[j]
                    y_up = ys[j + 1]
                    break

            if x_left is None or x_right is None or y_up is None or y_down is None:
                continue

            # Determine incident directions based on adjacent cell existence
            incident = []

            # North: vertical channel continues north if cells at (x_left, y_up) and (x_right, y_up) exist
            if (quantize(x_left), quantize(y_up)) in cell_set and (quantize(x_right), quantize(y_up)) in cell_set:
                incident.append("N")

            # South: vertical channel continues south if cells at (x_left, y_down) and (x_right, y_down) exist
            if (quantize(x_left), quantize(y_down)) in cell_set and (quantize(x_right), quantize(y_down)) in cell_set:
                incident.append("S")

            # East: horizontal channel continues east if cells at (x_right, y_up) and (x_right, y_down) exist
            if (quantize(x_right), quantize(y_up)) in cell_set and (quantize(x_right), quantize(y_down)) in cell_set:
                incident.append("E")

            # West: horizontal channel continues west if cells at (x_left, y_up) and (x_left, y_down) exist
            if (quantize(x_left), quantize(y_up)) in cell_set and (quantize(x_left), quantize(y_down)) in cell_set:
                incident.append("W")

            if len(incident) >= 2:  # Only nodes with at least 2 incident channels
                seam_nodes.append((x_seam, y_seam, incident))

    # Boundary nodes: where channels meet the outer edge of the footprint
    if footprint_bounds is not None:
        fb_xmin, fb_ymin, fb_xmax, fb_ymax = footprint_bounds

        # Vertical channels at X seams meeting Y boundaries
        for x_seam in x_seams:
            # Find which Y rows have cells on both sides of this X seam
            for j in range(len(ys)):
                y_row = ys[j]
                # Check if cells on both sides of x_seam at this y_row
                x_left = None
                x_right = None
                for i in range(len(xs) - 1):
                    if abs((xs[i] + xs[i + 1]) / 2.0 - x_seam) < 0.01:
                        x_left = xs[i]
                        x_right = xs[i + 1]
                        break
                if x_left is None:
                    continue
                # Assert for type checker - we know these are not None here
                assert x_left is not None and x_right is not None

                has_left = (quantize(x_left), quantize(y_row)) in cell_set
                has_right = (quantize(x_right), quantize(y_row)) in cell_set

                if has_left and has_right:
                    # Channel exists at this x_seam, y_row
                    # Check if this is at a Y boundary
                    if j == 0:
                        # Bottom boundary
                        y_node = y_row - pitch / 2.0
                        if y_node >= fb_ymin - 1:
                            seam_nodes.append((x_seam, y_node, ["N"]))
                    if j == len(ys) - 1:
                        # Top boundary
                        y_node = y_row + pitch / 2.0
                        if y_node <= fb_ymax + 1:
                            seam_nodes.append((x_seam, y_node, ["S"]))

        # Horizontal channels at Y seams meeting X boundaries
        for y_seam in y_seams:
            # Find which X columns have cells on both sides of this Y seam
            for i in range(len(xs)):
                x_col = xs[i]
                y_down = None
                y_up = None
                for j in range(len(ys) - 1):
                    if abs((ys[j] + ys[j + 1]) / 2.0 - y_seam) < 0.01:
                        y_down = ys[j]
                        y_up = ys[j + 1]
                        break
                if y_down is None:
                    continue
                # Assert for type checker - we know these are not None here
                assert y_down is not None and y_up is not None

                has_down = (quantize(x_col), quantize(y_down)) in cell_set
                has_up = (quantize(x_col), quantize(y_up)) in cell_set

                if has_down and has_up:
                    # Channel exists at this x_col, y_seam
                    # Check if this is at an X boundary
                    if i == 0:
                        # Left boundary
                        x_node = x_col - pitch / 2.0
                        if x_node >= fb_xmin - 1:
                            seam_nodes.append((x_node, y_seam, ["E"]))
                    if i == len(xs) - 1:
                        # Right boundary
                        x_node = x_col + pitch / 2.0
                        if x_node <= fb_xmax + 1:
                            seam_nodes.append((x_node, y_seam, ["W"]))

    return seam_nodes


__all__ = [
    "detect_four_cell_intersections",
    "detect_seam_network",
]
