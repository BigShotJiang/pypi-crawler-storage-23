"""meshcutter.cutter.seams - Seam, corner, and channel generation for cutters.

This module provides functions for generating seam plugs, corner fillets,
and inter-cell channels used in the mesh cutter system.
"""

from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

import cadquery as cq
import numpy as np

from meshcutter.constants import GR_TOL, GR_BASE_HEIGHT, GR_BOX_PROFILE, GR_RAD, GRU, SQRT2


def generate_corner_plug(
    x_pos: float,
    y_pos: float,
    z0: float,
    z1: float,
    z2: float,
    z3: float,
    top_chamf_vert: float,
    bot_chamf_vert: float,
    straight_vert: float,
    epsilon: float = 0.02,
) -> cq.Workplane:
    """Generate a diamond-shaped corner plug at a 4-cell intersection.

    The plug fills the diagonal gap between perpendicular channels at the
    intersection point. It uses a diamond (45° rotated square) cross-section
    that follows the same taper profile as the channels.

    Args:
        x_pos: X position of the intersection
        y_pos: Y position of the intersection
        z0, z1, z2, z3: Z breakpoints (same as channel profile)
        top_chamf_vert: Vertical height of top chamfer
        bot_chamf_vert: Vertical height of bottom chamfer
        straight_vert: Vertical height of straight section
        epsilon: Small margin to add to inradius for tolerance

    Returns:
        CadQuery Workplane with diamond-shaped plug
    """
    # Calculate inradius at each Z level (with epsilon margin)
    r0 = (GR_TOL + 2.0 * (top_chamf_vert + bot_chamf_vert)) / 2.0 + epsilon
    r1 = (GR_TOL + 2.0 * top_chamf_vert) / 2.0 + epsilon
    r2 = r1
    r3 = GR_TOL / 2.0 + epsilon

    def diamond_points(r: float) -> List[Tuple[float, float]]:
        """Create diamond (45° square) vertices with given inradius."""
        return [(r, 0), (0, r), (-r, 0), (0, -r)]

    # Build plug as three segments using loft/extrude
    segment1 = (
        cq.Workplane("XY", origin=(x_pos, y_pos, z0))
        .polyline(diamond_points(r0))
        .close()
        .workplane(offset=(z1 - z0))
        .polyline(diamond_points(r1))
        .close()
        .loft()
    )

    segment2 = cq.Workplane("XY", origin=(x_pos, y_pos, z1)).polyline(diamond_points(r1)).close().extrude(z2 - z1)

    segment3 = (
        cq.Workplane("XY", origin=(x_pos, y_pos, z2))
        .polyline(diamond_points(r2))
        .close()
        .workplane(offset=(z3 - z2))
        .polyline(diamond_points(r3))
        .close()
        .loft()
    )

    plug = segment1.union(segment2).union(segment3)
    return plug


def generate_inner_corner_fillet(
    corner_x: float,
    corner_y: float,
    arc_center_x: float,
    arc_center_y: float,
    z0: float,
    z1: float,
    z2: float,
    z3: float,
    base_radius: float = 4.0,
    n_arc_points: int = 12,
) -> cq.Workplane:
    """Generate a fillet plug to fill the gap at inner micro-foot corners.

    At 4-cell meeting points, the cell cutter has a curved boundary where the
    micro-foot's inner corner arc is. The channel has straight edges. This
    creates a gap between the curved cell cutter edge and the straight channel
    edge that needs to be filled.

    Args:
        corner_x, corner_y: Position of the inner corner (gap center)
        arc_center_x, arc_center_y: Center of the foot's corner arc
        z0, z1, z2, z3: Z breakpoints
        base_radius: Corner arc radius at base (default 4.0mm)
        n_arc_points: Number of points for arc approximation

    Returns:
        CadQuery Workplane with fillet plug solid
    """
    # Vector from arc center to corner
    dx = corner_x - arc_center_x
    dy = corner_y - arc_center_y
    corner_angle = np.arctan2(dy, dx)

    # The gap exists between the foot's corner arc and the tangent channel edge
    # The fillet fills this circular segment

    # At each Z level, the foot corner radius changes
    # z3: full radius (base_radius)
    # z2 to z0: radius shrinks linearly to 0

    def corner_radius_at_z(z: float) -> float:
        """Compute corner radius at given Z level."""
        if z >= z3:
            return base_radius
        else:
            return max(0.0, base_radius * (z - z0) / (z3 - z0))

    def channel_half_width_at_z(z: float) -> float:
        """Compute channel half-width at given Z level."""
        # Gap at foot tip = GR_TOL + 2*(top_chamf + bot_chamf)
        top_chamf_vert = z3 - z2
        bot_chamf_vert = z2 - z1
        if z >= z3:
            return GR_TOL / 2.0
        elif z >= z2:
            return GR_TOL / 2.0 + (z3 - z)
        elif z >= z1:
            return GR_TOL / 2.0 + top_chamf_vert
        else:
            return GR_TOL / 2.0 + top_chamf_vert + bot_chamf_vert

    # Build fillet as lofted profile
    fillet_solids = []

    z_levels = np.linspace(z0, z3, n_arc_points)
    for i in range(len(z_levels) - 1):
        z_bottom = z_levels[i]
        z_top = z_levels[i + 1]

        r_bottom = corner_radius_at_z(z_bottom)
        r_top = corner_radius_at_z(z_top)
        w_bottom = channel_half_width_at_z(z_bottom)
        w_top = channel_half_width_at_z(z_top)

        if r_bottom <= 0.01 or r_top <= 0.01:
            continue

        # Build cross-section at this Z level
        # The fillet fills the area between the arc and the channel edge
        theta = np.pi / 4  # 45 degree sector

        def fillet_section(r: float, w: float, z: float):
            """Create fillet cross-section at given Z."""
            if r <= 0.01:
                return None

            # Points on the arc
            angles = np.linspace(corner_angle - theta / 2, corner_angle + theta / 2, 8)
            arc_points = [(arc_center_x + r * np.cos(a), arc_center_y + r * np.sin(a)) for a in angles]

            # Points on the channel edge (tangent line)
            # The channel edge is tangent to the arc at the corner angle
            tangent_x = corner_x + w * np.cos(corner_angle)
            tangent_y = corner_y + w * np.sin(corner_angle)

            # Build polygon: arc points then back along tangent
            edge_points = [
                (corner_x - w * np.sin(corner_angle), corner_y + w * np.cos(corner_angle)),
                (tangent_x, tangent_y),
                (corner_x + w * np.sin(corner_angle), corner_y - w * np.cos(corner_angle)),
            ]

            all_points = arc_points + edge_points[::-1]
            return [(p[0], p[1]) for p in all_points]

        section_bottom = fillet_section(r_bottom, w_bottom, z_bottom)
        section_top = fillet_section(r_top, w_top, z_top)

        if section_bottom and section_top:
            try:
                layer = (
                    cq.Workplane("XY", origin=(0, 0, z_bottom))
                    .polyline(section_bottom)
                    .close()
                    .workplane(offset=(z_top - z_bottom))
                    .polyline(section_top)
                    .close()
                    .loft()
                )
                fillet_solids.append(layer)
            except Exception:
                # Skip layers that fail to loft
                pass

    if not fillet_solids:
        return cq.Workplane("XY")  # Return empty workplane

    # Union all layers
    result = fillet_solids[0]
    for solid in fillet_solids[1:]:
        result = result.union(solid)

    return result


def generate_intercell_channels(
    cell_centers: Sequence[Tuple[float, float]],
    pitch: float = GRU,
    epsilon: float = 0.02,
    footprint_bounds: Optional[Tuple[float, float, float, float]] = None,
) -> Optional[cq.Workplane]:
    """Generate tapered channel cutters between adjacent 1U cells.

    Creates TAPERED channels that match the foot profile exactly:
    - Narrow (GR_TOL) at foot base
    - Wide at foot tip

    Args:
        cell_centers: List of (x, y) cell center coordinates
        pitch: 1U pitch (default 42mm)
        epsilon: Extension below z=0 (mm)
        footprint_bounds: Optional (x_min, y_min, x_max, y_max) to clip channels

    Returns:
        CadQuery Workplane with channel cutters, or None if no channels needed
    """
    if len(cell_centers) < 2:
        return None

    # Find unique X and Y coordinates
    xs = sorted(set(cx for cx, cy in cell_centers))
    ys = sorted(set(cy for cx, cy in cell_centers))

    # Channel profile segments
    top_chamf_diag = GR_BOX_PROFILE[0][0]
    top_chamf_vert = top_chamf_diag / SQRT2
    straight_vert = GR_BOX_PROFILE[1]
    bot_chamf_diag = GR_BOX_PROFILE[2][0]
    bot_chamf_vert = bot_chamf_diag / SQRT2

    # Z levels in CQ space
    z0 = -GR_BASE_HEIGHT
    z1 = z0 + top_chamf_vert
    z2 = z1 + straight_vert
    z3 = z2 + bot_chamf_vert

    base_width = GR_TOL
    eps_xy = 0.05

    channels = None

    def _create_tapered_channel(
        width: float, length: float, x_pos: float, y_pos: float, rotated: bool = False
    ) -> cq.Workplane:
        """Create a single tapered channel matching foot profile."""
        wide_width = GR_TOL + 2.0 * (top_chamf_vert + bot_chamf_vert)

        if rotated:
            wp = cq.Workplane("XY", origin=(x_pos, y_pos, z0))
            wp = wp.transformed(rotate=(0, 0, 90))
        else:
            wp = cq.Workplane("XY", origin=(x_pos, y_pos, z0))

        # Bottom: wide rectangle
        channel = wp.box(wide_width, length + eps_xy, z1 - z0, centered=True)

        # Middle: straight section
        mid = wp.workplane(offset=z1 - z0).box(wide_width, length + eps_xy, z2 - z1, centered=True)
        channel = channel.union(mid)

        # Top: narrow rectangle
        top = wp.workplane(offset=z2 - z0).box(width, length + eps_xy, z3 - z2, centered=True)
        channel = channel.union(top)

        return channel

    # Create vertical channels (along X seams)
    for i in range(len(xs) - 1):
        x_seam = (xs[i] + xs[i + 1]) / 2.0
        for j in range(len(ys)):
            y_row = ys[j]

            # Check if cells exist on both sides
            has_left = any(abs(cx - xs[i]) < 0.01 and abs(cy - y_row) < 0.01 for cx, cy in cell_centers)
            has_right = any(abs(cx - xs[i + 1]) < 0.01 and abs(cy - y_row) < 0.01 for cx, cy in cell_centers)

            if has_left and has_right:
                length = pitch
                if footprint_bounds:
                    fb_xmin, fb_ymin, fb_xmax, fb_ymax = footprint_bounds
                    y_start = max(y_row - length / 2, fb_ymin)
                    y_end = min(y_row + length / 2, fb_ymax)
                    actual_length = y_end - y_start
                    if actual_length < 1.0:
                        continue
                    y_center = (y_start + y_end) / 2.0
                else:
                    y_center = y_row
                    actual_length = length

                channel = _create_tapered_channel(base_width, actual_length, x_seam, y_center, rotated=True)
                if channels is None:
                    channels = channel
                else:
                    channels = channels.union(channel)

    # Create horizontal channels (along Y seams)
    for j in range(len(ys) - 1):
        y_seam = (ys[j] + ys[j + 1]) / 2.0
        for i in range(len(xs)):
            x_col = xs[i]

            # Check if cells exist on both sides
            has_down = any(abs(cx - x_col) < 0.01 and abs(cy - ys[j]) < 0.01 for cx, cy in cell_centers)
            has_up = any(abs(cx - x_col) < 0.01 and abs(cy - ys[j + 1]) < 0.01 for cx, cy in cell_centers)

            if has_down and has_up:
                length = pitch
                if footprint_bounds:
                    fb_xmin, fb_ymin, fb_xmax, fb_ymax = footprint_bounds
                    x_start = max(x_col - length / 2, fb_xmin)
                    x_end = min(x_col + length / 2, fb_xmax)
                    actual_length = x_end - x_start
                    if actual_length < 1.0:
                        continue
                    x_center = (x_start + x_end) / 2.0
                else:
                    x_center = x_col
                    actual_length = length

                channel = _create_tapered_channel(base_width, actual_length, x_center, y_seam, rotated=False)
                if channels is None:
                    channels = channel
                else:
                    channels = channels.union(channel)

    return channels


__all__ = [
    "generate_corner_plug",
    "generate_inner_corner_fillet",
    "generate_intercell_channels",
]
