#! /usr/bin/env python3
"""
meshcutter.cutter - Cutter geometry generation.

Provides functions for generating micro-foot cutters using CadQuery.
"""

from meshcutter.cutter.base import generate_cutter
from meshcutter.cutter.grid import micro_foot_offsets_single_cell, micro_foot_offsets_grid, detect_cell_centers

__all__ = [
    "generate_cutter",
    "micro_foot_offsets_single_cell",
    "micro_foot_offsets_grid",
    "detect_cell_centers",
]
