"""meshcutter.cutter.foot_generator - Foot generation for cutter operations.

This module provides functions for generating Gridfinity foot solids using CadQuery,
including 1U feet, micro-feet, and extended feet for cutter generation.
"""

from __future__ import annotations

from functools import lru_cache
from typing import List, Tuple

import cadquery as cq
from cqkit.cq_helpers import rounded_rect_sketch

from meshcutter.constants import GRU, GR_TOL, GR_BASE_CLR, GR_BASE_HEIGHT, GR_BOX_PROFILE


def _get_outer_rad() -> float:
    """Get the outer radius for foot generation (internal helper)."""
    # GR_RAD - GR_TOL/2 = 4.0 - 0.25 = 3.75mm
    # This matches the envelope radius used in microfinity
    from meshcutter.constants import GR_RAD

    return GR_RAD - GR_TOL / 2


def _get_foot_rad() -> float:
    """Get the foot radius for generation (internal helper)."""
    # GR_RAD + GR_BASE_CLR = 4.0 + 0.25 = 4.25mm (raw foot radius)
    from meshcutter.constants import GR_RAD

    return GR_RAD + GR_BASE_CLR


def _extrude_profile(sketch, profile, workplane="XY", angle=None) -> cq.Workplane:
    """Extrude a sketch through a multi-segment profile with optional tapers.

    This is a standalone helper to avoid dependency on full GridfinityObject.

    Args:
        sketch: CadQuery Sketch to extrude
        profile: Tuple of profile segments
        workplane: Workplane to start from
        angle: Optional angle for ZLEN correction

    Returns:
        CadQuery Workplane with extruded solid
    """
    result = cq.Workplane(workplane).placeSketch(sketch)

    for i, segment in enumerate(profile):
        if isinstance(segment, (list, tuple)) and len(segment) == 2:
            height, taper = segment
        else:
            height = segment
            taper = None

        if taper is not None:
            result = result.extrude(height, taper=taper)
        else:
            result = result.extrude(height)

    return result


def generate_1u_foot_cq(cropped: bool = True) -> cq.Workplane:
    """Generate a 1U foot solid using CadQuery.

    Mirrors microfinity box.py render_shell() for macro feet.

    Args:
        cropped: If True, apply envelope cropping to match actual model.

    Returns:
        CadQuery Workplane with 1U foot solid
    """
    rad = _get_foot_rad()

    # Generate raw foot at GRU (42mm)
    foot = _extrude_profile(rounded_rect_sketch(GRU, GRU, rad), GR_BOX_PROFILE)
    foot = foot.translate((0, 0, -GR_BASE_CLR))
    foot = foot.mirror(mirrorPlane="XY")

    if cropped:
        # Apply cropping envelope
        outer_size = GRU - GR_TOL
        outer_rad = _get_outer_rad()
        crop_env = (
            cq.Workplane("XY")
            .placeSketch(rounded_rect_sketch(outer_size, outer_size, outer_rad))
            .extrude(-GR_BASE_HEIGHT - 1)
            .translate(cq.Vector(0, 0, 0.5))
        )
        foot = crop_env.intersect(foot)

    return foot


def generate_micro_foot_cq(micro_divisions: int = 4, size_reduction: float = 0.0) -> cq.Workplane:
    """Generate a micro foot solid using CadQuery.

    Creates a micro-foot with correct dimensions to match microfinity output.

    Args:
        micro_divisions: Number of divisions (2 or 4)
        size_reduction: Amount to shrink foot size (mm)

    Returns:
        CadQuery Workplane with micro foot solid
    """
    outer_rad = _get_outer_rad()
    rad_1u = _get_foot_rad()

    micro_pitch = GRU / micro_divisions
    foot_size = micro_pitch - GR_TOL - size_reduction

    # Ensure minimum viable size
    foot_size = max(foot_size, 2.0)

    # Clamp radius to valid range
    rad = min(rad_1u, foot_size / 2 - 0.05)
    rad = max(rad, 0.2)

    foot = _extrude_profile(rounded_rect_sketch(foot_size, foot_size, rad), GR_BOX_PROFILE)
    foot = foot.translate((0, 0, -GR_BASE_CLR))
    foot = foot.mirror(mirrorPlane="XY")

    return foot


def micro_foot_offsets(micro_divisions: int, pitch: float = GRU) -> List[Tuple[float, float]]:
    """Return micro-foot center offsets relative to 1U cell center.

    Matches microfinity reference implementation exactly.

    Args:
        micro_divisions: Number of divisions (1, 2, or 4)
        pitch: 1U pitch (default 42mm)

    Returns:
        List of (x, y) offset tuples
    """
    if micro_divisions <= 1:
        return [(0.0, 0.0)]

    micro_pitch = pitch / micro_divisions

    offsets = []
    for i in range(micro_divisions):
        for j in range(micro_divisions):
            x = (micro_pitch / 2) * (2 * i - (micro_divisions - 1))
            y = (micro_pitch / 2) * (2 * j - (micro_divisions - 1))
            offsets.append((x, y))
    return offsets


@lru_cache(maxsize=8)
def generate_extended_foot_cq(overshoot: float = 0.0, cropped: bool = True) -> cq.Workplane:
    """Generate an extended 1U foot solid for cutter envelope.

    Creates a foot that extends beyond normal 1U foot boundary by overshoot.

    Args:
        overshoot: Extension beyond normal foot size (mm)
        cropped: If True, apply envelope cropping

    Returns:
        CadQuery Workplane with extended foot solid
    """
    rad = _get_foot_rad()
    size = GRU + 2 * overshoot

    foot = _extrude_profile(rounded_rect_sketch(size, size, rad), GR_BOX_PROFILE)
    foot = foot.translate((0, 0, -GR_BASE_CLR))
    foot = foot.mirror(mirrorPlane="XY")

    if cropped:
        outer_size = size - GR_TOL
        outer_rad = _get_outer_rad()
        crop_env = (
            cq.Workplane("XY")
            .placeSketch(rounded_rect_sketch(outer_size, outer_size, outer_rad))
            .extrude(-GR_BASE_HEIGHT - 1)
            .translate(cq.Vector(0, 0, 0.5))
        )
        foot = crop_env.intersect(foot)

    return foot


__all__ = [
    "generate_1u_foot_cq",
    "generate_micro_foot_cq",
    "micro_foot_offsets",
    "generate_extended_foot_cq",
]
