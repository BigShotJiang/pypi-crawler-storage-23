"""
meshcutter.exceptions - Unified exception hierarchy for meshcutter.

All meshcutter exceptions inherit from MeshCutterError for easy catching.

Usage:
    from meshcutter.exceptions import MeshCutterError

    try:
        risky_operation()
    except MeshCutterError as e:
        # Handle any meshcutter-related error
        print(f"Error: {e}")
"""

from __future__ import annotations

from typing import Any, Dict, Optional


class MeshCutterError(Exception):
    """Base exception for all meshcutter errors."""

    pass


class BooleanError(MeshCutterError):
    """Exception raised when boolean operations fail."""

    def __init__(self, message: str, diagnostics: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.diagnostics = diagnostics or {}


class LoaderError(MeshCutterError):
    """Exception raised when mesh loading fails."""

    pass


class ExporterError(MeshCutterError):
    """Exception raised when mesh export fails."""

    pass


class ValidationError(MeshCutterError):
    """Exception raised when validation fails."""

    pass


class PipelineError(MeshCutterError):
    """Exception raised when pipeline execution fails."""

    pass
