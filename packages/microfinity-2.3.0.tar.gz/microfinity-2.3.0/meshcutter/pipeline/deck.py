# meshcutter.pipeline.deck - Deck/slab generation for solid base preservation
#
# Provides deck detection and generation for preserving solid floors
# during base replacement operations.
#

from __future__ import annotations

from typing import List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    from shapely.geometry import Polygon
    import trimesh


# Deck preservation parameters (for solid base models)
# When a model has a solid floor/deck inside the replaced band, we add a deck
# slab to cap the void between micro-feet
DECK_THICKNESS = 0.8  # mm - thickness of deck slab (0.8 = 4 layers at 0.2mm)
DECK_OVERLAP = 0.05  # mm - Z-overlap at seams for clean booleans
DECK_COVERAGE_THRESHOLD = 0.90  # Band coverage ratio to trigger deck
DECK_HOLE_FRACTION_THRESHOLD = 0.15  # Max hole fraction (relative to footprint)
# Sample depths below z_join to detect solid base
# Must sample deep into foot region (0-5mm from z_min) where solid base would be
# Depths: 2.0, 3.0, 4.0mm below z_join covers most of the foot region
DECK_SAMPLE_DEPTHS = [2.0, 3.0, 4.0]  # mm below z_join to sample for detection


def compute_band_metrics(
    mesh: "trimesh.Trimesh",
    z_sample: float,
    ref_area: float,
) -> Tuple[float, float]:
    """Compute coverage and hole fraction for a Z-slice.

    Args:
        mesh: Input mesh
        z_sample: Z height to sample
        ref_area: Reference footprint area for normalization

    Returns:
        (coverage, hole_fraction) tuple
        - coverage: area(slice) / ref_area
        - hole_fraction: hole_area / ref_area
    """
    from meshcutter.pipeline.polygons import slice_to_material_polygon
    from shapely.geometry import Polygon

    poly = slice_to_material_polygon(mesh, z_sample)

    if poly is None or poly.is_empty:
        return (0.0, 0.0)

    # Calculate hole area from polygon interiors
    hole_area = 0.0
    if hasattr(poly, "interiors") and poly.interiors:
        for ring in poly.interiors:
            try:
                hole_poly = Polygon(ring)
                if hole_poly.is_valid:
                    hole_area += hole_poly.area
            except Exception:
                pass

    coverage = poly.area / max(ref_area, 1e-9)
    hole_fraction = hole_area / max(ref_area, 1e-9)

    return (coverage, hole_fraction)


def should_add_deck(
    mesh: "trimesh.Trimesh",
    z_join: float,
    z_min: float,
    ref_polygon: Optional["Polygon"],
    coverage_threshold: float = DECK_COVERAGE_THRESHOLD,
    hole_fraction_threshold: float = DECK_HOLE_FRACTION_THRESHOLD,
    sample_depths: Optional[List[float]] = None,
) -> bool:
    """Detect if mesh has a deck/floor in the band being replaced.

    Uses multiple Z samples below z_join and compares coverage against
    the reference footprint polygon. High coverage with low hole fraction
    indicates a solid deck that would be destroyed by replace-base.

    Args:
        mesh: Input mesh
        z_join: Cut plane height
        z_min: Bottom of mesh (for clamping samples)
        ref_polygon: Reference footprint polygon (guard/collar)
        coverage_threshold: Min coverage ratio to trigger deck (default 0.90)
        hole_fraction_threshold: Max hole fraction (default 0.15)
        sample_depths: Depths below z_join to sample (default [2.0, 3.0, 4.0])

    Returns:
        True if deck should be added to preserve solid floor
    """
    if sample_depths is None:
        sample_depths = DECK_SAMPLE_DEPTHS

    # Need reference polygon for comparison
    if ref_polygon is None or ref_polygon.is_empty:
        return False

    ref_area = ref_polygon.area
    if ref_area < 1.0:
        return False

    # Sample multiple depths below z_join
    for depth in sample_depths:
        z_sample = z_join - depth

        # Clamp to valid range (must be above z_min + small epsilon)
        if z_sample <= z_min + 0.1:
            continue

        coverage, hole_fraction = compute_band_metrics(mesh, z_sample, ref_area)

        # Check if this sample indicates a deck
        if coverage > coverage_threshold and hole_fraction < hole_fraction_threshold:
            return True

    return False


def generate_deck_slab(
    deck_polygon: "Polygon",
    z_join: float,
    thickness: float = DECK_THICKNESS,
    overlap: float = DECK_OVERLAP,
) -> "trimesh.Trimesh":
    """Generate a deck slab to cap the void between micro-feet.

    The deck sits just below z_join with overlaps at both ends to avoid
    coplanar boolean seams.

    Placement:
        z_bottom = z_join - thickness - overlap
        z_top = z_join + overlap
        height = thickness + 2*overlap

    Args:
        deck_polygon: 2D boundary polygon (guard or collar)
        z_join: Cut plane height
        thickness: Deck thickness in mm (default 0.8)
        overlap: Z-overlap at seams (default 0.05)

    Returns:
        Deck mesh positioned at correct Z

    Raises:
        ValueError: If deck_polygon is empty or invalid
    """
    import trimesh
    from meshcutter.pipeline.polygons import clean_polygon
    from shapely.geometry import Polygon

    if deck_polygon is None or deck_polygon.is_empty:
        raise ValueError("Cannot generate deck from empty polygon")

    # IMPORTANT: Drop interior holes from the polygon.
    # The guard/collar polygon may have holes from the model's interior cavity,
    # but we want a SOLID deck that fills all gaps between micro-feet.
    if hasattr(deck_polygon, "exterior") and hasattr(deck_polygon, "interiors"):
        if deck_polygon.interiors:
            # Drop holes - use only the exterior boundary
            deck_polygon = Polygon(deck_polygon.exterior)
            deck_polygon = clean_polygon(deck_polygon)
            if deck_polygon is None or deck_polygon.is_empty:
                raise ValueError("Deck polygon became invalid after dropping holes")

    # Total height includes overlaps at both ends
    # z0 = z_join - thickness - overlap (bottom)
    # z1 = z_join + overlap (top)
    total_height = thickness + 2 * overlap
    z_bottom = z_join - thickness - overlap

    try:
        deck_mesh = trimesh.creation.extrude_polygon(deck_polygon, height=total_height)
    except Exception as e:
        raise ValueError(f"Failed to extrude deck polygon: {e}")

    # Position: bottom at z_bottom
    deck_mesh.vertices[:, 2] += z_bottom

    return deck_mesh


def export_debug_svg(
    input_poly: "Polygon", collar_poly: "Polygon", protrusion: "Polygon", z: float, output_path: str = None
):
    """Export debug SVG showing input, collar, and protrusion polygons.

    Args:
        input_poly: Input mesh polygon
        collar_poly: Extracted collar polygon
        protrusion: Detected protrusion polygon (may be None)
        z: Z height for the slice
        output_path: Output file path (default: /tmp/meshcutter_debug_z{z:.2f}.svg)
    """
    import os

    if output_path is None:
        output_path = f"/tmp/meshcutter_debug_z{z:.2f}.svg"

    try:
        # Calculate bounds
        all_bounds = [input_poly.bounds, collar_poly.bounds]
        if protrusion and not protrusion.is_empty:
            all_bounds.append(protrusion.bounds)

        min_x = min(b[0] for b in all_bounds) - 5
        min_y = min(b[1] for b in all_bounds) - 5
        max_x = max(b[2] for b in all_bounds) + 5
        max_y = max(b[3] for b in all_bounds) + 5

        width = max_x - min_x
        height = max_y - min_y

        svg_parts = [
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{min_x} {min_y} {width} {height}" ',
            f'width="{width}mm" height="{height}mm">',
            f"<title>Debug at z={z:.2f}mm</title>",
        ]

        # Input polygon (blue)
        if input_poly and hasattr(input_poly, "exterior"):
            coords = " ".join(f"{x},{y}" for x, y in input_poly.exterior.coords)
            svg_parts.append(f'<polygon points="{coords}" fill="none" stroke="blue" stroke-width="0.5"/>')

        # Collar polygon (green)
        if collar_poly and hasattr(collar_poly, "exterior"):
            coords = " ".join(f"{x},{y}" for x, y in collar_poly.exterior.coords)
            svg_parts.append(f'<polygon points="{coords}" fill="none" stroke="green" stroke-width="0.5"/>')

        # Protrusion (red filled)
        if protrusion and not protrusion.is_empty and hasattr(protrusion, "exterior"):
            coords = " ".join(f"{x},{y}" for x, y in protrusion.exterior.coords)
            svg_parts.append(
                f'<polygon points="{coords}" fill="red" fill-opacity="0.5" stroke="red" stroke-width="0.3"/>'
            )

        svg_parts.append("</svg>")

        with open(output_path, "w") as f:
            f.write("\n".join(svg_parts))

        print(f"  DEBUG: Exported {output_path}")
    except Exception as e:
        print(f"  DEBUG: Failed to export SVG: {e}")


__all__ = [
    # Constants
    "DECK_THICKNESS",
    "DECK_OVERLAP",
    "DECK_COVERAGE_THRESHOLD",
    "DECK_HOLE_FRACTION_THRESHOLD",
    "DECK_SAMPLE_DEPTHS",
    # Functions
    "compute_band_metrics",
    "should_add_deck",
    "generate_deck_slab",
    "export_debug_svg",
]
