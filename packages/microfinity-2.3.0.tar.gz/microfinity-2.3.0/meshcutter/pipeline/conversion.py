# meshcutter.pipeline.conversion - Mesh and geometry conversion utilities
#
# Provides conversion between:
# - trimesh <-> manifold3d
# - CadQuery <-> trimesh
#

from __future__ import annotations

import os
import tempfile
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import cadquery as cq
    import manifold3d
    import trimesh

import numpy as np


def trimesh_to_manifold(mesh: "trimesh.Trimesh") -> "manifold3d.Manifold":
    """Convert trimesh to manifold3d Manifold.

    Args:
        mesh: Input trimesh mesh

    Returns:
        Manifold3d Manifold representation
    """
    import manifold3d

    return manifold3d.Manifold(
        manifold3d.Mesh(
            vert_properties=np.array(mesh.vertices, dtype=np.float32),
            tri_verts=np.array(mesh.faces, dtype=np.uint32),
        )
    )


def manifold_to_trimesh(manifold: "manifold3d.Manifold") -> "trimesh.Trimesh":
    """Convert manifold3d Manifold to trimesh.

    Args:
        manifold: Input Manifold3d manifold

    Returns:
        Trimesh representation
    """
    import trimesh

    mesh_data = manifold.to_mesh()
    return trimesh.Trimesh(
        vertices=np.array(mesh_data.vert_properties, dtype=np.float64),
        faces=np.array(mesh_data.tri_verts, dtype=np.int64),
    )


def manifold_intersection(a: "manifold3d.Manifold", b: "manifold3d.Manifold") -> "manifold3d.Manifold":
    """Compute intersection of two Manifolds.

    Note: In manifold3d, the ^ operator is intersection (verified empirically).

    Args:
        a: First manifold
        b: Second manifold

    Returns:
        Intersection of a and b
    """
    return a ^ b


def cq_to_trimesh(cq_obj: "cq.Workplane", tol: float = 0.01, ang_tol: float = 0.1) -> "trimesh.Trimesh":
    """Convert CadQuery Workplane to trimesh via STL export.

    Uses temporary file for export/import to ensure proper mesh generation
    with specified tolerance parameters.

    Args:
        cq_obj: CadQuery Workplane to convert
        tol: Linear mesh tolerance (mm), default 0.01
        ang_tol: Angular mesh tolerance (radians), default 0.1

    Returns:
        Trimesh representation
    """
    import cadquery as cq
    import trimesh

    with tempfile.TemporaryDirectory() as tmpdir:
        stl_path = os.path.join(tmpdir, "temp.stl")
        cq.exporters.export(
            cq_obj,
            stl_path,
            exportType="STL",
            tolerance=tol,
            angularTolerance=ang_tol,
        )
        mesh = trimesh.load(stl_path)
    return mesh
