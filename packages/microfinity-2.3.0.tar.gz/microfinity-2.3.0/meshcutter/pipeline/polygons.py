# meshcutter.pipeline.polygons - Polygon utilities for pipeline operations
#
# Provides utilities for:
# - Polygon validation and cleaning
# - MultiPolygon extraction to single Polygon
# - Slice-to-polygon conversion
# - Area-based filtering
#

from __future__ import annotations

from typing import List, Optional, TYPE_CHECKING

from shapely.geometry import MultiPolygon, Polygon

if TYPE_CHECKING:
    import trimesh


def ensure_single_polygon(geom) -> Optional[Polygon]:
    """Convert MultiPolygon/GeometryCollection to single Polygon (largest component).

    Args:
        geom: Input geometry (Polygon, MultiPolygon, or GeometryCollection)

    Returns:
        Single largest valid Polygon, or None if no valid polygons found
    """
    from shapely.geometry import GeometryCollection

    if geom is None or geom.is_empty:
        return None

    if isinstance(geom, Polygon):
        return geom
    elif isinstance(geom, MultiPolygon):
        # Take largest by area
        valid_polys = [g for g in geom.geoms if isinstance(g, Polygon) and not g.is_empty]
        if valid_polys:
            return max(valid_polys, key=lambda g: g.area)
        return None
    elif isinstance(geom, GeometryCollection):
        # Extract polygons and take largest
        polys = [g for g in geom.geoms if isinstance(g, Polygon) and not g.is_empty]
        if polys:
            return max(polys, key=lambda g: g.area)
        return None
    else:
        return None


def clean_polygon(poly: Polygon) -> Optional[Polygon]:
    """Clean up a polygon using make_valid, falling back to buffer(0).

    Attempts to repair invalid polygons using Shapely's make_valid,
    with buffer(0) as a fallback.

    Args:
        poly: Input polygon (may be invalid)

    Returns:
        Cleaned valid Polygon, or None if cleaning fails
    """
    from shapely.validation import make_valid

    if poly is None or poly.is_empty:
        return None

    if poly.is_valid:
        return poly

    # Try make_valid first (preferred)
    try:
        cleaned = make_valid(poly)
        cleaned = ensure_single_polygon(cleaned)
        if cleaned is not None and cleaned.is_valid:
            return cleaned
    except Exception:
        pass

    # Fall back to buffer(0)
    try:
        cleaned = poly.buffer(0)
        cleaned = ensure_single_polygon(cleaned)
        if cleaned is not None and cleaned.is_valid:
            return cleaned
    except Exception:
        pass

    return None


def slice_to_material_polygon(mesh: "trimesh.Trimesh", z: float, min_area: float = 10.0) -> Optional[Polygon]:
    """Extract the 2D material region at height z.

    Uses polygons_full from trimesh path (preferred over manual hole inference).
    Returns the largest polygon component in ORIGINAL mesh coordinates.

    Note: trimesh's to_2D() applies a centering transform. We must apply the
    inverse transform to get coordinates back to original mesh space.

    Args:
        mesh: Input mesh
        z: Z height for slice plane
        min_area: Minimum valid polygon area (mm²)

    Returns:
        Material polygon at slice, or None if no valid material found
    """
    from shapely.affinity import translate as shapely_translate
    from shapely.ops import unary_union

    try:
        # Get cross-section
        section = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])

        if section is None:
            return None

        # Convert to 2D using to_2D (not deprecated to_planar)
        # NOTE: to_2D applies a centering transform - we need to reverse it
        path_2d, transform = section.to_2D()

        if path_2d is None:
            return None

        # Extract the translation from the transform matrix
        # The transform is a 4x4 matrix where [0:3, 3] is the translation
        # This is the offset that was SUBTRACTED from original coords
        # We need to ADD it back to restore original coordinates
        tx = transform[0, 3]  # X offset (mesh center X)
        ty = transform[1, 3]  # Y offset (mesh center Y)

        # Get polygons_full - trimesh already handles shell/hole structure
        all_polygons = list(path_2d.polygons_full)

        if not all_polygons:
            return None

        # Filter valid polygons
        valid_polygons = [p for p in all_polygons if p.is_valid and p.area > min_area]

        if not valid_polygons:
            return None

        # Union all polygons (handles multiple disjoint shells)
        if len(valid_polygons) == 1:
            result = valid_polygons[0]
        else:
            result = unary_union(valid_polygons)

        # Ensure single polygon and clean
        result = ensure_single_polygon(result)
        result = clean_polygon(result)

        if result is None:
            return None

        # Apply INVERSE transform to restore original mesh coordinates
        # The polygon was centered at origin by subtracting (tx, ty)
        # We add (tx, ty) to restore original position
        result = shapely_translate(result, xoff=tx, yoff=ty)

        return result

    except Exception:
        return None


def reject_area_outliers(polygons: List[Polygon], threshold: float = 2.0) -> List[Polygon]:
    """Reject polygons that are area outliers.

    Filters out polygons whose area is significantly different from the median.
    Useful for removing spurious small fragments or erroneous large regions.

    Args:
        polygons: List of input polygons
        threshold: Multiplier for median absolute deviation (default 2.0)

    Returns:
        Filtered list of polygons within area bounds
    """
    import numpy as np

    if not polygons:
        return []

    areas = np.array([p.area for p in polygons])
    median_area = np.median(areas)
    mad = np.median(np.abs(areas - median_area))  # Median absolute deviation

    if mad == 0:
        return polygons

    # Keep polygons within threshold * MAD of median
    valid_indices = np.abs(areas - median_area) <= threshold * mad
    return [polygons[i] for i in range(len(polygons)) if valid_indices[i]]
