# meshcutter.pipeline.collar - Collar and base guard extraction
#
# Provides polygon extraction from mesh collar regions for cut-and-graft
# pipeline operations. Extracts conservative polygons guaranteed to be
# inside the original mesh for clean boolean operations.
#

from __future__ import annotations

from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from shapely.geometry import Polygon
    import trimesh


# Default constants for collar extraction
COLLAR_HEIGHT = 0.5  # mm - height of overlap band
SLICE_COUNT = 5  # Number of slices for collar extraction
SLICE_EPSILON = 0.05  # mm - offset from band edges for slicing
MIN_POLYGON_AREA = 10.0  # mm² - minimum valid slice area

# Base guard parameters (for clipping micro-feet to input chamfer profile)
BASE_GUARD_HEIGHT = 0.6  # mm - band height to sample below z_join
BASE_GUARD_SLICE_COUNT = 5  # Number of slices for guard extraction
BASE_GUARD_SLICE_EPS = 0.03  # mm - offset from band edges
BASE_GUARD_MIN_AREA = 50.0  # mm² - minimum valid guard polygon area
BASE_GUARD_BUFFER = 0.02  # mm - small inward shrink for safety margin


def extract_collar_polygon(
    mesh: "trimesh.Trimesh",
    z_join: float,
    collar_height: float = COLLAR_HEIGHT,
    n_slices: int = SLICE_COUNT,
    slice_epsilon: float = SLICE_EPSILON,
    min_area: float = MIN_POLYGON_AREA,
) -> Optional["Polygon"]:
    """Extract a 2D polygon guaranteed to be inside the mesh throughout the collar band.

    Uses intersection of multiple slices (conservative combination) to ensure
    the resulting polygon is strictly inside the mesh material throughout the
    entire collar band height.

    Args:
        mesh: Input mesh
        z_join: Bottom of collar band (z_split)
        collar_height: Height of collar band
        n_slices: Number of slices to take
        slice_epsilon: Offset from band edges
        min_area: Minimum valid polygon area

    Returns:
        Shapely Polygon guaranteed to be inside mesh in collar band,
        or None if extraction fails
    """
    import numpy as np
    from meshcutter.pipeline.polygons import (
        clean_polygon,
        ensure_single_polygon,
        reject_area_outliers,
        slice_to_material_polygon,
    )

    # Generate sample Z heights within the band
    z_lo = z_join + slice_epsilon
    z_hi = z_join + collar_height - slice_epsilon

    if z_hi <= z_lo:
        # Band too narrow, use single slice at midpoint
        z_samples = [z_join + collar_height / 2]
    else:
        z_samples = np.linspace(z_lo, z_hi, n_slices)

    # Extract material polygon at each Z
    polygons = []
    for z in z_samples:
        poly = slice_to_material_polygon(mesh, z)
        if poly is not None and poly.is_valid and poly.area > min_area:
            polygons.append(poly)

    if len(polygons) == 0:
        return None

    # Reject area outliers (>2σ from median)
    polygons = reject_area_outliers(polygons)

    if len(polygons) == 0:
        return None

    # Combine via intersection (conservative - guaranteed inside all slices)
    result = polygons[0]
    for p in polygons[1:]:
        try:
            new_result = result.intersection(p)
        except Exception:
            continue

        if new_result.is_empty:
            # Intersection collapsed - use smallest polygon as fallback
            result = min(polygons, key=lambda p: p.area)
            break

        result = new_result

    # Ensure single polygon and clean
    result = ensure_single_polygon(result)
    result = clean_polygon(result)

    if result is None or result.is_empty or result.area < min_area:
        # Fall back to smallest slice polygon
        valid = [p for p in polygons if p.is_valid and p.area >= min_area]
        if valid:
            result = min(valid, key=lambda p: p.area)
        else:
            return None

    return result


def extract_base_guard_polygon(
    mesh: "trimesh.Trimesh",
    z_join: float,
    guard_height: float = BASE_GUARD_HEIGHT,
    n_slices: int = BASE_GUARD_SLICE_COUNT,
    slice_epsilon: float = BASE_GUARD_SLICE_EPS,
    min_area: float = BASE_GUARD_MIN_AREA,
    safety_buffer: float = BASE_GUARD_BUFFER,
) -> Optional["Polygon"]:
    """Extract a conservative 2D polygon from the wall transition region.

    The wall transition (z ≈ 4.94-5.0 for standard Gridfinity) is where the
    wall connects to the foot top. This region may be slightly tighter than
    the wall above due to chamfers/clearances.

    We sample the wall region just above z_join where the wall is continuous,
    NOT the feet themselves (which are disjoint polygons).

    Args:
        mesh: Input mesh
        z_join: The z_split plane (typically 5.0mm)
        guard_height: Height of band to sample
        n_slices: Number of slices to take
        slice_epsilon: Offset from band edges
        min_area: Minimum valid polygon area
        safety_buffer: Small inward shrink for margin

    Returns:
        Shapely Polygon representing the tightest wall boundary, or None
    """
    import numpy as np
    from meshcutter.pipeline.polygons import (
        clean_polygon,
        ensure_single_polygon,
        slice_to_material_polygon,
    )

    # Sample the wall region ABOVE z_join only.
    # IMPORTANT: Below z_join we have individual feet (disjoint polygons), not
    # a continuous wall. Sampling below z_join would return only partial coverage
    # and the intersection would clip to just one cell.
    z_sample_start = z_join + slice_epsilon  # Start just above z_join (in wall)
    z_sample_end = z_join + guard_height  # End in wall region

    z_samples = np.linspace(z_sample_start, z_sample_end - slice_epsilon, n_slices)

    # Collect valid wall slices (area > 1000mm² indicates continuous wall)
    wall_polygons = []
    for z in z_samples:
        poly = slice_to_material_polygon(mesh, z)
        if poly is not None and poly.is_valid and poly.area > 1000:  # Wall threshold
            wall_polygons.append(poly)

    if len(wall_polygons) == 0:
        return None

    # Take intersection of wall slices (conservative - tightest boundary)
    result = wall_polygons[0]
    for p in wall_polygons[1:]:
        try:
            new_result = result.intersection(p)
        except Exception:
            continue

        if new_result.is_empty:
            # Intersection collapsed - use smallest valid polygon
            result = min(wall_polygons, key=lambda p: p.area)
            break

        result = new_result

    # Ensure single polygon and clean
    result = ensure_single_polygon(result)
    result = clean_polygon(result)

    if result is None or result.is_empty or result.area < min_area:
        # Fall back to smallest wall polygon
        valid = [p for p in wall_polygons if p.is_valid and p.area >= min_area]
        if valid:
            result = min(valid, key=lambda p: p.area)
        else:
            return None

    # Apply small inward buffer for safety margin
    if safety_buffer > 0:
        try:
            buffered = result.buffer(-safety_buffer)
            buffered = ensure_single_polygon(buffered)
            if buffered is not None and not buffered.is_empty and buffered.area > min_area:
                result = buffered
        except Exception:
            pass  # Keep original if buffering fails

    return clean_polygon(result)


def extract_base_guard_fallback(
    mesh: "trimesh.Trimesh",
    z_join: float,
    guard_height: float = BASE_GUARD_HEIGHT,
    safety_buffer: float = BASE_GUARD_BUFFER,
    min_area: float = BASE_GUARD_MIN_AREA,
) -> Optional["Polygon"]:
    """Fallback guard extraction using single slice at mid-band.

    Used when multi-slice extraction fails.

    Args:
        mesh: Input mesh
        z_join: The z_split plane
        guard_height: Height of band
        safety_buffer: Small inward shrink for margin
        min_area: Minimum valid polygon area

    Returns:
        Shapely Polygon or None
    """
    from meshcutter.pipeline.polygons import (
        clean_polygon,
        ensure_single_polygon,
        slice_to_material_polygon,
    )

    z_mid = z_join - guard_height / 2
    poly = slice_to_material_polygon(mesh, z_mid)

    if poly is None or poly.area < min_area:
        return None

    # Apply safety buffer
    if safety_buffer > 0:
        try:
            buffered = poly.buffer(-safety_buffer)
            buffered = ensure_single_polygon(buffered)
            if buffered is not None and not buffered.is_empty:
                poly = buffered
        except Exception:
            pass

    return clean_polygon(poly)


def get_reference_polygon(
    guard_polygon: Optional["Polygon"],
    collar_polygon: Optional["Polygon"],
    mesh: "trimesh.Trimesh",
    z_join: float,
    delta: float = 0.25,
) -> Optional["Polygon"]:
    """Get the reference footprint polygon for deck detection.

    Returns the best available polygon in order of preference:
    1. Guard polygon (most conservative)
    2. Collar polygon (good fallback)
    3. Single slice at z_join + delta

    Args:
        guard_polygon: Extracted guard polygon (optional)
        collar_polygon: Extracted collar polygon (optional)
        mesh: Input mesh
        z_join: The z_split plane
        delta: Offset above z_join for slice fallback

    Returns:
        Reference polygon or None
    """
    from meshcutter.pipeline.polygons import slice_to_material_polygon

    if guard_polygon is not None and guard_polygon.is_valid and guard_polygon.area > 0:
        return guard_polygon

    if collar_polygon is not None and collar_polygon.is_valid and collar_polygon.area > 0:
        return collar_polygon

    # Fallback: single slice
    return slice_to_material_polygon(mesh, z_join + delta)


__all__ = [
    # Constants
    "COLLAR_HEIGHT",
    "SLICE_COUNT",
    "SLICE_EPSILON",
    "MIN_POLYGON_AREA",
    "BASE_GUARD_HEIGHT",
    "BASE_GUARD_SLICE_COUNT",
    "BASE_GUARD_SLICE_EPS",
    "BASE_GUARD_MIN_AREA",
    "BASE_GUARD_BUFFER",
    # Functions
    "extract_collar_polygon",
    "extract_base_guard_polygon",
    "extract_base_guard_fallback",
    "get_reference_polygon",
]
