#! /usr/bin/env python3
#
# meshcutter.pipeline.run - Main orchestration for mesh cutting operations
#
# This module contains the run_meshcut() function that orchestrates the
# entire mesh cutting pipeline, including loading, detection, conversion,
# and export.

from __future__ import annotations

import argparse
import time
from pathlib import Path

from meshcutter import __version__
from meshcutter.constants import (
    GR_BASE_HEIGHT,
    COPLANAR_EPSILON,
    GRU,
)
from meshcutter.cutter.foot import convert_to_micro_feet
from meshcutter.mesh.boolean import (
    check_manifold3d_available,
    check_pymeshlab_available,
)
from meshcutter.io.loader import load_mesh, validate_mesh, LoaderError
from meshcutter.io.exporter import export_stl, get_export_info, ExporterError

# Mesh cleanup thresholds (re-exported from constants for internal use)
MIN_COMPONENT_FACES = 100
MIN_SLIVER_SIZE = 0.001  # 1 micron
MIN_SLIVER_VOLUME = 1e-12  # mm^3


def _repair_mesh_manifold(mesh):
    """Repair mesh by passing through manifold3d.

    This eliminates floating-point artifacts and non-manifold geometry
    that can occur during boolean operations or STL export/import.

    Args:
        mesh: trimesh.Trimesh to repair

    Returns:
        Repaired trimesh.Trimesh (or original if manifold3d unavailable)
    """
    try:
        import numpy as np
        import manifold3d

        # Convert to manifold (auto-repairs)
        m = manifold3d.Manifold(
            manifold3d.Mesh(
                vert_properties=np.array(mesh.vertices, dtype=np.float32),
                tri_verts=np.array(mesh.faces, dtype=np.uint32),
            )
        )

        # Convert back to trimesh
        import trimesh

        mesh_data = m.to_mesh()
        return trimesh.Trimesh(vertices=mesh_data.vert_properties[:, :3], faces=mesh_data.tri_verts)
    except ImportError:
        return mesh  # manifold3d not available


def _is_degenerate_sliver(component, min_size=MIN_SLIVER_SIZE, min_volume=MIN_SLIVER_VOLUME):
    """Check if a component is a degenerate sliver (boolean artifact).

    A sliver is identified by:
    - All bounding box dimensions being very small (< min_size), OR
    - Having an extremely small volume (< min_volume), OR
    - Having fewer than 4 faces (can't form a valid solid)

    Args:
        component: trimesh.Trimesh component to check
        min_size: Minimum acceptable size in any dimension (mm)
        min_volume: Minimum acceptable volume (mm^3)

    Returns:
        True if the component is a degenerate sliver that should be removed
    """
    import numpy as np

    # Check face count - need at least 4 faces for a tetrahedron
    if len(component.faces) < 4:
        return True

    # Check if all dimensions are tiny (nanometer-scale artifact)
    size = component.bounds[1] - component.bounds[0]
    if (size < min_size).all():
        return True

    # Check volume - if it's effectively zero, it's degenerate
    # Use absolute value since non-watertight meshes can have negative volume
    if abs(component.volume) < min_volume:
        return True

    return False


def _clean_mesh_components(mesh):
    """Remove floating/degenerate components from mesh.

    Keeps only the largest component(s) that have significant geometry.
    Small floating triangles and nanometer-scale slivers (common boolean
    artifacts) are removed.

    Args:
        mesh: trimesh.Trimesh input mesh

    Returns:
        Tuple of (cleaned mesh, number of components removed)
    """
    import trimesh

    components = mesh.split(only_watertight=False)

    if len(components) <= 1:
        return mesh, 0

    # Find the main component (largest by face count)
    main_component = max(components, key=lambda c: len(c.faces))
    main_face_count = len(main_component.faces)

    # Keep components that:
    # 1. Have at least MIN_COMPONENT_FACES faces OR 1% of main component, AND
    # 2. Are NOT degenerate slivers (size/volume check)
    threshold = max(MIN_COMPONENT_FACES, main_face_count * 0.01)
    kept = [c for c in components if len(c.faces) >= threshold and not _is_degenerate_sliver(c)]
    removed_count = len(components) - len(kept)

    if len(kept) == 1:
        return kept[0], removed_count
    elif len(kept) > 1:
        # Concatenate kept components
        return trimesh.util.concatenate(kept), removed_count
    else:
        # Shouldn't happen, but return original if no components kept
        return mesh, 0


def run_meshcut(args: argparse.Namespace) -> None:
    """Run the mesh cutting operation using replace-base approach.

    This is the main orchestration function that:
    1. Loads the input mesh
    2. Converts to micro-feet using the replace-base approach
    3. Exports the result

    The replace-base approach replaces everything below z=5mm with freshly
    generated micro-divided feet, producing geometry identical to natively
    generated micro boxes.

    Args:
        args: Parsed command-line arguments with the following attributes:
            - input: Path to input STL/3MF file
            - output: Path to output STL file
            - micro_divisions: Number of micro-divisions (1, 2, or 4)
            - verbose: Enable verbose output
            - deck: Deck preservation mode ("auto", "always", "never")
            - deck_thickness: Deck thickness in mm
            - no_clean: Disable cleanup
            - repair: Attempt mesh repair
            - no_validate: Skip validation

        Deprecated/ignored:
            - use_boolean: Ignored (legacy option removed in v2.0.0)
            - force_z_up, z_tolerance, epsilon, overshoot, auto_overshoot,
              wall_cut, add_channels: Only used by legacy boolean path
    """
    start_time = time.time()

    micro_pitch = GRU / args.micro_divisions
    micro_foot_size = micro_pitch - 0.5  # GR_TOL = 0.5

    if args.verbose:
        print(f"microfinity meshcut v{__version__}")
        print(f"Input: {args.input}")
        print(f"Output: {args.output}")
        print(f"Micro-divisions: {args.micro_divisions}")
        print(f"  Micro-pitch: {micro_pitch:.1f}mm")
        print(f"  Micro-foot size: {micro_foot_size:.1f}mm")
        print(f"  Feet per 1U cell: {args.micro_divisions ** 2}")
        print("  Method: replace-base (exact geometry)")
        print()

        # Check available engines
        engines = []
        if check_manifold3d_available():
            engines.append("manifold3d")
        if check_pymeshlab_available():
            engines.append("pymeshlab")
        if engines:
            print(f"Available boolean engines: {', '.join(engines)}")
        else:
            print("Warning: No optimized boolean engines found. Install manifold3d:")
            print("  pip install manifold3d")
        print()

    # Handle no-op case (micro_divisions=1)
    if args.micro_divisions == 1:
        if args.verbose:
            print("micro-divisions=1: no changes will be made (pass-through mode)")
            print()

        # Load and immediately export (useful for testing pipeline)
        try:
            mesh = load_mesh(args.input)
        except LoaderError as e:
            raise RuntimeError(f"Failed to load mesh: {e}")

        try:
            export_stl(mesh, args.output)
        except ExporterError as e:
            raise RuntimeError(f"Failed to export: {e}")

        elapsed = time.time() - start_time
        if args.verbose:
            print(f"Completed in {elapsed:.2f}s (no changes)")
        else:
            print(f"Wrote {args.output} (unchanged)")
        return

    # Step 1: Load mesh
    if args.verbose:
        print("Loading mesh...", end=" ", flush=True)

    try:
        mesh = load_mesh(args.input)
    except LoaderError as e:
        raise RuntimeError(f"Failed to load mesh: {e}")

    # Clean up floating/degenerate components if enabled (default)
    if not args.no_clean:
        mesh, cleaned_count = _clean_mesh_components(mesh)
        if args.verbose and cleaned_count > 0:
            print(f"(removed {cleaned_count} floating components) ", end="")

    if args.verbose:
        info = validate_mesh(mesh)
        print("done")
        print(f"  Triangles: {info['face_count']}")
        print(f"  Vertices: {info['vertex_count']}")
        print(
            f"  Dimensions: {info['dimensions'][0]:.1f} x {info['dimensions'][1]:.1f} x {info['dimensions'][2]:.1f} mm"
        )
        print(f"  Watertight: {info['is_watertight']}")
        if not info["is_watertight"]:
            print("  Warning: Mesh is not watertight. Consider using --repair")
        print()

    # Step 2: Convert to micro-feet using replace-base approach
    if args.verbose:
        print("Converting to micro-feet using replace-base approach...")
        print("  NOTE: This replaces everything below z=5mm (magnet holes, etc. will be lost)")
        print()

    # Get deck options with defaults
    deck_mode = getattr(args, "deck", "auto")
    deck_thickness = getattr(args, "deck_thickness", None)

    try:
        result_mesh = convert_to_micro_feet(
            mesh,
            micro_divisions=args.micro_divisions,
            pitch=GRU,
            use_replace_base=True,
            deck_mode=deck_mode,
            deck_thickness=deck_thickness,
        )
    except Exception as e:
        raise RuntimeError(f"Failed to convert to micro-feet: {e}")

    if result_mesh is None:
        raise RuntimeError("Conversion returned None")

    # Clean up floating/degenerate components from result
    if not args.no_clean:
        result_mesh, cleaned_count = _clean_mesh_components(result_mesh)
        if args.verbose and cleaned_count > 0:
            print(f"Cleaned up {cleaned_count} floating components from result")
            print()

    # Step 3: Export result
    if args.verbose:
        print(f"Exporting to {args.output}...", end=" ", flush=True)

    try:
        export_stl(result_mesh, args.output)
    except ExporterError as e:
        raise RuntimeError(f"Failed to export: {e}")

    if args.verbose:
        export_info = get_export_info(result_mesh)
        print("done")
        print(f"  Output triangles: {export_info['face_count']}")
        print(f"  Output watertight: {export_info['is_watertight']}")
        dims = export_info["dimensions"]
        print(f"  Output dimensions: {dims[0]:.1f} x {dims[1]:.1f} x {dims[2]:.1f} mm")
        print()

    elapsed = time.time() - start_time

    if args.verbose:
        print(f"Completed in {elapsed:.2f}s")
    else:
        print(f"Wrote {args.output}")
