#! /usr/bin/env python3
#
# meshcutter.pipeline.replace_base - Replace Base Pipeline for micro-foot conversion
#
# Architecture: Cut-and-Graft with Conservative Collar
#   1. Trim input mesh above z_join to keep walls + top
#   2. Generate fresh micro-feet base ending at z_join
#   3. Extract conservative collar from input mesh (guaranteed inside original)
#   4. Union all three with Z-overlaps to avoid coplanar boolean degeneracy
#
# The collar is derived from the INPUT mesh via intersection of multiple slices,
# NOT from an idealized envelope. This prevents corner protrusions.

from __future__ import annotations

import os
import tempfile
from typing import List, Optional, Tuple, Union

import cadquery as cq
import manifold3d
import numpy as np
import trimesh
from cqkit.cq_helpers import composite_from_pts, rounded_rect_sketch
from shapely.geometry import GeometryCollection, MultiPolygon, Point, Polygon
from shapely.ops import unary_union
from shapely.validation import make_valid

from meshcutter.detection.footprint import BottomFrame

# Phase P1: Extracted utilities (backward compatibility via re-exports)
from meshcutter.pipeline.conversion import (
    cq_to_trimesh as _cq_to_trimesh_impl,
    manifold_intersection as _manifold_intersection_impl,
    manifold_to_trimesh as _manifold_to_trimesh_impl,
    trimesh_to_manifold as _trimesh_to_manifold_impl,
)
from meshcutter.pipeline.polygons import (
    clean_polygon as _clean_polygon_impl,
    ensure_single_polygon as _ensure_single_polygon_impl,
    reject_area_outliers as _reject_area_outliers_impl,
    slice_to_material_polygon as _slice_to_material_polygon_impl,
)
from meshcutter.pipeline.collar import (
    extract_base_guard_fallback as _extract_base_guard_fallback_impl,
    extract_base_guard_polygon as _extract_base_guard_polygon_impl,
    extract_collar_polygon as _extract_collar_polygon_impl,
    get_reference_polygon as _get_reference_polygon_impl,
)
from meshcutter.pipeline.deck import (
    compute_band_metrics as _compute_band_metrics_impl,
    export_debug_svg as _export_debug_svg_impl,
    generate_deck_slab as _generate_deck_slab_impl,
    should_add_deck as _should_add_deck_impl,
)
from meshcutter.pipeline.protrusions import (
    apply_adaptive_buffer as _apply_adaptive_buffer_impl,
    create_idealized_envelope as _create_idealized_envelope_impl,
    extract_collar_fallback_shadow as _extract_collar_fallback_shadow_impl,
    has_protrusions as _has_protrusions_impl,
)
from meshcutter.pipeline.basegen import (
    clip_base_top_band as _clip_base_top_band_impl,
    generate_collar_mesh as _generate_collar_mesh_impl,
    generate_micro_base as _generate_micro_base_impl,
    generate_micro_base_with_sleeve as _generate_micro_base_with_sleeve_impl,
    generate_micro_foot_cq as _generate_micro_foot_cq_impl,
    micro_foot_offsets as _micro_foot_offsets_impl,
    trim_mesh_above_z as _trim_mesh_above_z_impl,
)

from meshcutter.constants import (
    GR_BASE_CLR,
    GR_BASE_HEIGHT,
    GR_BOX_PROFILE,
    GR_RAD,
    GR_TOL,
    GRU,
    SQRT2,
)

# -----------------------------------------------------------------------------
# Constants
# -----------------------------------------------------------------------------
# Z_join is the plane where we cut between top (kept) and bottom (replaced)
Z_SPLIT_HEIGHT = GR_BASE_HEIGHT + GR_BASE_CLR  # 4.75 + 0.25 = 5.0mm

# Collar parameters
COLLAR_HEIGHT = 0.5  # mm - height of overlap band
Z_OVERLAP_EPSILON = 0.08  # mm - overlap at seams to avoid coplanar booleans
SLICE_COUNT = 5  # Number of slices for collar extraction
SLICE_EPSILON = 0.05  # mm - offset from band edges for slicing
MIN_POLYGON_AREA = 10.0  # mm² - minimum valid slice area
INITIAL_SAFETY_BUFFER = 0.02  # mm - starting inward shrink
MAX_SAFETY_BUFFER = 0.10  # mm - maximum inward shrink

# Base guard parameters (for clipping micro-feet to input chamfer profile)
# The guard is extracted from the band just below z_join where foot chamfer is tightest
BASE_GUARD_HEIGHT = 0.6  # mm - band height to sample below z_join
BASE_GUARD_SLICE_COUNT = 5  # Number of slices for guard extraction
BASE_GUARD_SLICE_EPS = 0.03  # mm - offset from band edges
BASE_GUARD_MIN_AREA = 50.0  # mm² - minimum valid guard polygon area
BASE_GUARD_BUFFER = 0.02  # mm - small inward shrink for safety margin

# Deck preservation parameters (for solid base models)
# When a model has a solid floor/deck inside the replaced band, we add a deck
# slab to cap the void between micro-feet
DECK_THICKNESS = 0.8  # mm - thickness of deck slab (0.8 = 4 layers at 0.2mm)
DECK_OVERLAP = 0.05  # mm - Z-overlap at seams for clean booleans
DECK_COVERAGE_THRESHOLD = 0.90  # Band coverage ratio to trigger deck
DECK_HOLE_FRACTION_THRESHOLD = 0.15  # Max hole fraction (relative to footprint)
# Sample depths below z_join to detect solid base
# Must sample deep into foot region (0-5mm from z_min) where solid base would be
# Depths: 2.0, 3.0, 4.0mm below z_join covers most of the foot region
DECK_SAMPLE_DEPTHS = [2.0, 3.0, 4.0]  # mm below z_join to sample for detection

# Debug mode from environment
DEBUG_MODE = os.environ.get("MESHCUTTER_DEBUG", "").lower() in ("1", "true", "yes")

# Legacy constant for backward compatibility
SLEEVE_HEIGHT = COLLAR_HEIGHT


# -----------------------------------------------------------------------------
# CadQuery version detection
# -----------------------------------------------------------------------------
ZLEN_FIX = True
_r = cq.Workplane("XY").rect(2, 2).extrude(1, taper=45)
_bb = _r.vals()[0].BoundingBox()
if abs(_bb.zlen - 1.0) < 1e-3:
    ZLEN_FIX = False


def extrude_profile(sketch, profile, workplane="XY", angle=None) -> cq.Workplane:
    """Extrude a sketch through a multi-segment profile with optional tapers."""
    import math

    taper = profile[0][1] if isinstance(profile[0], (list, tuple)) else 0
    zlen = profile[0][0] if isinstance(profile[0], (list, tuple)) else profile[0]

    if abs(taper) > 0:
        if angle is None:
            zlen = zlen if ZLEN_FIX else zlen / SQRT2
        else:
            zlen = zlen / math.cos(math.radians(taper)) if ZLEN_FIX else zlen

    r = cq.Workplane(workplane).placeSketch(sketch).extrude(zlen, taper=taper)

    for level in profile[1:]:
        if isinstance(level, (tuple, list)):
            if angle is None:
                zlen = level[0] if ZLEN_FIX else level[0] / SQRT2
            else:
                zlen = level[0] / math.cos(math.radians(level[1])) if ZLEN_FIX else level[0]
            r = r.faces(">Z").wires().toPending().extrude(zlen, taper=level[1])
        else:
            r = r.faces(">Z").wires().toPending().extrude(level)

    return r


# -----------------------------------------------------------------------------
# Trimesh <-> Manifold conversion helpers (delegated to conversion module)
# -----------------------------------------------------------------------------
def trimesh_to_manifold(mesh: trimesh.Trimesh) -> manifold3d.Manifold:
    """Convert trimesh to manifold3d Manifold."""
    return _trimesh_to_manifold_impl(mesh)


def manifold_to_trimesh(manifold: manifold3d.Manifold) -> trimesh.Trimesh:
    """Convert manifold3d Manifold to trimesh."""
    return _manifold_to_trimesh_impl(manifold)


def manifold_intersection(a: manifold3d.Manifold, b: manifold3d.Manifold) -> manifold3d.Manifold:
    """
    Compute intersection of two Manifolds.

    Note: In manifold3d, the ^ operator is intersection (verified empirically).
    """
    return _manifold_intersection_impl(a, b)


def cq_to_trimesh(cq_obj: cq.Workplane, tol: float = 0.01, ang_tol: float = 0.1) -> trimesh.Trimesh:
    """Convert CadQuery Workplane to trimesh."""
    return _cq_to_trimesh_impl(cq_obj, tol, ang_tol)


# -----------------------------------------------------------------------------
# Polygon utilities (delegated to polygons module)
# -----------------------------------------------------------------------------
def ensure_single_polygon(geom) -> Optional[Polygon]:
    """Convert MultiPolygon/GeometryCollection to single Polygon (largest component)."""
    return _ensure_single_polygon_impl(geom)


def clean_polygon(poly: Polygon) -> Optional[Polygon]:
    """Clean up a polygon using make_valid, falling back to buffer(0)."""
    return _clean_polygon_impl(poly)


def slice_to_material_polygon(mesh: trimesh.Trimesh, z: float) -> Optional[Polygon]:
    """
    Extract the 2D material region at height z.

    Uses polygons_full from trimesh path (preferred over manual hole inference).
    Returns the largest polygon component in ORIGINAL mesh coordinates.

    Note: trimesh's to_2D() applies a centering transform. We must apply the
    inverse transform to get coordinates back to original mesh space.
    """
    return _slice_to_material_polygon_impl(mesh, z)


def reject_area_outliers(polygons: List[Polygon], threshold: float = 2.0) -> List[Polygon]:
    """Reject polygons with areas > threshold standard deviations from median."""
    return _reject_area_outliers_impl(polygons, threshold)


# -----------------------------------------------------------------------------
# Collar and base guard extraction (delegated to collar module)
# -----------------------------------------------------------------------------
def extract_collar_polygon(
    mesh: trimesh.Trimesh,
    z_join: float,
    collar_height: float = COLLAR_HEIGHT,
    n_slices: int = SLICE_COUNT,
    slice_epsilon: float = SLICE_EPSILON,
    min_area: float = MIN_POLYGON_AREA,
) -> Optional[Polygon]:
    """Extract a 2D polygon guaranteed to be inside the mesh throughout the collar band."""
    return _extract_collar_polygon_impl(mesh, z_join, collar_height, n_slices, slice_epsilon, min_area)


def extract_base_guard_polygon(
    mesh: trimesh.Trimesh,
    z_join: float,
    guard_height: float = BASE_GUARD_HEIGHT,
    n_slices: int = BASE_GUARD_SLICE_COUNT,
    slice_epsilon: float = BASE_GUARD_SLICE_EPS,
    min_area: float = BASE_GUARD_MIN_AREA,
    safety_buffer: float = BASE_GUARD_BUFFER,
) -> Optional[Polygon]:
    """Extract a conservative 2D polygon from the wall transition region."""
    return _extract_base_guard_polygon_impl(
        mesh, z_join, guard_height, n_slices, slice_epsilon, min_area, safety_buffer
    )


def extract_base_guard_fallback(
    mesh: trimesh.Trimesh,
    z_join: float,
    guard_height: float = BASE_GUARD_HEIGHT,
    safety_buffer: float = BASE_GUARD_BUFFER,
    min_area: float = BASE_GUARD_MIN_AREA,
) -> Optional[Polygon]:
    """Fallback guard extraction using single slice at mid-band."""
    return _extract_base_guard_fallback_impl(mesh, z_join, guard_height, safety_buffer, min_area)


# -----------------------------------------------------------------------------
# Deck preservation detection (for solid base models)
# -----------------------------------------------------------------------------
def get_reference_polygon(
    guard_polygon: Optional[Polygon],
    collar_polygon: Optional[Polygon],
    mesh: trimesh.Trimesh,
    z_join: float,
    delta: float = 0.25,
) -> Optional[Polygon]:
    """Get the reference footprint polygon for deck detection."""
    return _get_reference_polygon_impl(guard_polygon, collar_polygon, mesh, z_join, delta)


# -----------------------------------------------------------------------------
# Deck detection and generation (delegated to deck module)
# -----------------------------------------------------------------------------
def compute_band_metrics(
    mesh: trimesh.Trimesh,
    z_sample: float,
    ref_area: float,
) -> Tuple[float, float]:
    """Compute coverage and hole fraction for a Z-slice."""
    return _compute_band_metrics_impl(mesh, z_sample, ref_area)


def should_add_deck(
    mesh: trimesh.Trimesh,
    z_join: float,
    z_min: float,
    ref_polygon: Optional[Polygon],
    coverage_threshold: float = DECK_COVERAGE_THRESHOLD,
    hole_fraction_threshold: float = DECK_HOLE_FRACTION_THRESHOLD,
    sample_depths: Optional[List[float]] = None,
) -> bool:
    """Detect if mesh has a deck/floor in the band being replaced."""
    return _should_add_deck_impl(
        mesh, z_join, z_min, ref_polygon, coverage_threshold, hole_fraction_threshold, sample_depths
    )


def generate_deck_slab(
    deck_polygon: Polygon,
    z_join: float,
    thickness: float = DECK_THICKNESS,
    overlap: float = DECK_OVERLAP,
) -> trimesh.Trimesh:
    """Generate a deck slab to cap the void between micro-feet."""
    return _generate_deck_slab_impl(deck_polygon, z_join, thickness, overlap)


def export_debug_svg(input_poly: Polygon, collar_poly: Polygon, protrusion: Polygon, z: float, output_path: str = None):
    """Export debug SVG showing input, collar, and protrusion polygons."""
    return _export_debug_svg_impl(input_poly, collar_poly, protrusion, z, output_path)


# -----------------------------------------------------------------------------
# Protrusion detection and correction (delegated to protrusions module)
# -----------------------------------------------------------------------------
def has_protrusions(
    collar_polygon: Polygon,
    input_mesh: trimesh.Trimesh,
    z_join: float,
    collar_height: float,
    threshold_area: float = 0.01,
    threshold_dist: float = 0.01,
) -> bool:
    """Check if collar would protrude beyond input mesh."""
    return _has_protrusions_impl(collar_polygon, input_mesh, z_join, collar_height, threshold_area, threshold_dist)


def apply_adaptive_buffer(
    collar_polygon: Polygon,
    input_mesh: trimesh.Trimesh,
    z_join: float,
    collar_height: float,
    initial_delta: float = INITIAL_SAFETY_BUFFER,
    max_delta: float = MAX_SAFETY_BUFFER,
    step: float = 0.02,
) -> Polygon:
    """Apply minimal inward buffer that eliminates protrusions."""
    return _apply_adaptive_buffer_impl(
        collar_polygon, input_mesh, z_join, collar_height, initial_delta, max_delta, step
    )


def extract_collar_fallback_shadow(
    mesh: trimesh.Trimesh,
    z_join: float,
    collar_height: float,
    z_epsilon: float = Z_OVERLAP_EPSILON,
) -> Optional[Polygon]:
    """Fallback when slice-based extraction fails."""
    return _extract_collar_fallback_shadow_impl(mesh, z_join, collar_height, z_epsilon)


def create_idealized_envelope(cells_x: int, cells_y: int, pitch: float = GRU) -> Polygon:
    """Create idealized envelope polygon (fallback of last resort)."""
    return _create_idealized_envelope_impl(cells_x, cells_y, pitch, GR_TOL, GR_RAD)


# -----------------------------------------------------------------------------
# Generate collar mesh
# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# Base generation (delegated to basegen module)
# -----------------------------------------------------------------------------
def generate_collar_mesh(
    collar_polygon: Polygon,
    z_join: float,
    collar_height: float = COLLAR_HEIGHT,
    z_epsilon: float = Z_OVERLAP_EPSILON,
) -> trimesh.Trimesh:
    """Extrude collar polygon with Z-overlap at both ends."""
    return _generate_collar_mesh_impl(collar_polygon, z_join, collar_height, z_epsilon)


def clip_base_top_band(
    micro_base: trimesh.Trimesh,
    guard_polygon: Polygon,
    z_min: float,
    z_join: float,
    guard_height: float = BASE_GUARD_HEIGHT,
    z_epsilon: float = 0.1,
) -> trimesh.Trimesh:
    """Clip the top band of the micro-feet base to the guard polygon."""
    return _clip_base_top_band_impl(micro_base, guard_polygon, z_min, z_join, guard_height, z_epsilon)


def trim_mesh_above_z(mesh: trimesh.Trimesh, z_cut: float) -> trimesh.Trimesh:
    """Trim mesh to keep only the portion above z_cut."""
    return _trim_mesh_above_z_impl(mesh, z_cut)


def generate_micro_foot_cq(micro_divisions: int = 4) -> cq.Workplane:
    """Generate a single micro-foot solid using CadQuery."""
    return _generate_micro_foot_cq_impl(micro_divisions)


def micro_foot_offsets(
    cells_x: int, cells_y: int, micro_divisions: int = 4, pitch: float = GRU
) -> List[Tuple[float, float]]:
    """Return micro-foot center offsets for a grid of cells."""
    return _micro_foot_offsets_impl(cells_x, cells_y, micro_divisions, pitch)


def generate_micro_base(
    cells_x: int,
    cells_y: int,
    micro_divisions: int = 4,
    z_base: float = 0.0,
    pitch: float = GRU,
) -> trimesh.Trimesh:
    """Generate micro-feet base ending at z_join (no sleeve)."""
    return _generate_micro_base_impl(cells_x, cells_y, micro_divisions, z_base, pitch)


def generate_micro_base_with_sleeve(
    cells_x: int,
    cells_y: int,
    micro_divisions: int = 4,
    z_base: float = 0.0,
    sleeve_height: float = SLEEVE_HEIGHT,
    pitch: float = GRU,
) -> trimesh.Trimesh:
    """Legacy wrapper - generates base without sleeve."""
    return _generate_micro_base_with_sleeve_impl(cells_x, cells_y, micro_divisions, z_base, sleeve_height, pitch)


# -----------------------------------------------------------------------------
# Main pipeline
# -----------------------------------------------------------------------------
def replace_base_pipeline(
    input_mesh: trimesh.Trimesh,
    footprint: Union[Polygon, MultiPolygon],
    frame: BottomFrame,
    micro_divisions: int = 4,
    pitch: float = GRU,
    sleeve_height: float = SLEEVE_HEIGHT,  # Legacy parameter, now controls collar_height
    mesh_bounds: Optional[np.ndarray] = None,
    deck_mode: str = "auto",
    deck_thickness: float = DECK_THICKNESS,
) -> trimesh.Trimesh:
    """
    Replace the foot region of input mesh with fresh micro-feet.

    Uses conservative collar derived from input mesh to avoid protrusions.

    Architecture:
        1. Extract conservative collar polygon from input mesh
        2. Generate micro-feet base (ending at z_join)
        3. Generate collar mesh (overlaps both base and trimmed top)
        4. Optionally generate deck slab (if solid base detected)
        5. Trim input mesh above z_join
        6. Union all components

    Args:
        input_mesh: Input mesh with 1U feet
        footprint: Shapely polygon of detected footprint (local coords)
        frame: BottomFrame for coordinate transform
        micro_divisions: Number of divisions per 1U (2 or 4)
        pitch: 1U pitch (42mm)
        sleeve_height: Collar height for overlap (default 0.5mm)
        mesh_bounds: Optional mesh bounds for accurate cell detection
        deck_mode: Deck preservation mode - "auto", "always", or "never"
        deck_thickness: Deck thickness in mm (default 0.8)

    Returns:
        Output mesh with micro-feet
    """
    collar_height = sleeve_height  # Use sleeve_height as collar_height for compatibility

    # Get mesh bounds
    if mesh_bounds is None:
        mesh_bounds = input_mesh.bounds

    z_min = float(mesh_bounds[0, 2])
    z_join = z_min + Z_SPLIT_HEIGHT

    # Detect cell count from bounds
    width = mesh_bounds[1, 0] - mesh_bounds[0, 0]
    height = mesh_bounds[1, 1] - mesh_bounds[0, 1]

    cells_x = int(round((width + GR_TOL) / pitch))
    cells_y = int(round((height + GR_TOL) / pitch))
    cells_x = max(1, cells_x)
    cells_y = max(1, cells_y)

    # Mesh center for positioning
    mesh_center_x = (mesh_bounds[0, 0] + mesh_bounds[1, 0]) / 2
    mesh_center_y = (mesh_bounds[0, 1] + mesh_bounds[1, 1]) / 2

    print("Replace base pipeline (conservative collar):")
    print(f"  Input z_min: {z_min:.3f}mm, z_join: {z_join:.3f}mm")
    print(f"  Detected grid: {cells_x}x{cells_y} cells")
    print(f"  Micro divisions: {micro_divisions}")
    print(f"  Collar height: {collar_height:.2f}mm, Z-overlap: {Z_OVERLAP_EPSILON:.2f}mm")

    # === STEP 1: Extract conservative collar polygon ===
    print("  Extracting collar from input mesh...")
    collar_polygon = extract_collar_polygon(input_mesh, z_join, collar_height)

    if collar_polygon is None:
        print("  WARNING: Slice extraction failed, trying triangle shadow fallback")
        collar_polygon = extract_collar_fallback_shadow(input_mesh, z_join, collar_height)

    if collar_polygon is None:
        print("  WARNING: All extraction failed, using idealized envelope")
        collar_polygon = create_idealized_envelope(cells_x, cells_y, pitch)
        # Translate to mesh center if not at origin
        if abs(mesh_center_x) > 0.01 or abs(mesh_center_y) > 0.01:
            from shapely.affinity import translate

            collar_polygon = translate(collar_polygon, mesh_center_x, mesh_center_y)

    print(f"    Collar polygon area: {collar_polygon.area:.2f}mm²")

    # === STEP 2: Apply adaptive safety buffer ===
    print("  Applying adaptive safety buffer...")
    collar_polygon = apply_adaptive_buffer(collar_polygon, input_mesh, z_join, collar_height)
    print(f"    Final collar area: {collar_polygon.area:.2f}mm²")

    # === STEP 3: Generate collar mesh ===
    print("  Generating collar mesh...")
    collar_mesh = generate_collar_mesh(collar_polygon, z_join, collar_height, Z_OVERLAP_EPSILON)
    print(f"    Collar mesh: {len(collar_mesh.vertices)} vertices, {len(collar_mesh.faces)} faces")
    print(f"    Collar z range: [{collar_mesh.vertices[:, 2].min():.3f}, {collar_mesh.vertices[:, 2].max():.3f}]")

    # === STEP 4: Generate micro-feet base ===
    print("  Generating micro-feet base...")
    micro_base = generate_micro_base(
        cells_x=cells_x,
        cells_y=cells_y,
        micro_divisions=micro_divisions,
        z_base=z_min,
        pitch=pitch,
    )

    # Shift to mesh center if needed
    if abs(mesh_center_x) > 0.01 or abs(mesh_center_y) > 0.01:
        micro_base.vertices[:, 0] += mesh_center_x
        micro_base.vertices[:, 1] += mesh_center_y

    print(f"    Micro-base: {len(micro_base.vertices)} vertices, {len(micro_base.faces)} faces")
    print(f"    Base z range: [{micro_base.vertices[:, 2].min():.3f}, {micro_base.vertices[:, 2].max():.3f}]")

    # === STEP 4b: Clip micro-base top band to input chamfer profile ===
    # This prevents the micro-feet from extending past the original foot boundary
    # at the top of the base where the foot chamfer tapers inward
    print("  Extracting base guard from input mesh...")
    guard_polygon = extract_base_guard_polygon(input_mesh, z_join)

    if guard_polygon is None:
        print("    Primary extraction failed, trying fallback...")
        guard_polygon = extract_base_guard_fallback(input_mesh, z_join)

    if guard_polygon is None:
        print("    WARNING: Base guard extraction failed, using collar polygon as fallback")
        # Use collar polygon with extra buffer as last resort
        if collar_polygon is not None:
            try:
                guard_polygon = collar_polygon.buffer(-0.05)
                guard_polygon = ensure_single_polygon(guard_polygon)
                guard_polygon = clean_polygon(guard_polygon)
            except Exception:
                guard_polygon = None

    if guard_polygon is not None and not guard_polygon.is_empty:
        print(f"    Guard polygon area: {guard_polygon.area:.2f}mm²")
        print(f"    Clipping micro-base top band (z={z_join - BASE_GUARD_HEIGHT:.2f} to {z_join:.2f})...")

        micro_base_before = len(micro_base.vertices)
        micro_base = clip_base_top_band(
            micro_base,
            guard_polygon,
            z_min=z_min,
            z_join=z_join,
            guard_height=BASE_GUARD_HEIGHT,
        )
        print(f"    Clipped base: {len(micro_base.vertices)} vertices (was {micro_base_before})")
    else:
        print("    WARNING: No base guard available, skipping clip (corner protrusions may occur)")

    # === STEP 4c: Check if deck needed (solid base preservation) ===
    deck_mesh = None
    if deck_mode == "always":
        needs_deck = True
        print("  Deck mode: always (forced)")
    elif deck_mode == "never":
        needs_deck = False
        print("  Deck mode: never (skipped)")
    else:  # "auto"
        print("  Checking for solid base (deck preservation)...")
        # Get reference polygon for detection (same as deck boundary)
        ref_polygon = get_reference_polygon(guard_polygon, collar_polygon, input_mesh, z_join)
        needs_deck = should_add_deck(input_mesh, z_join, z_min, ref_polygon)
        if needs_deck:
            print("    Detected solid base - will add deck slab")
        else:
            print("    Standard feet detected - no deck needed")

    # Generate deck if needed
    if needs_deck:
        deck_poly = guard_polygon if guard_polygon is not None else collar_polygon
        if deck_poly is not None and not deck_poly.is_empty:
            print(f"  Generating deck slab (thickness={deck_thickness}mm)...")
            try:
                deck_mesh = generate_deck_slab(deck_poly, z_join, thickness=deck_thickness)
                # Shift to mesh center if needed (same as micro_base)
                if abs(mesh_center_x) > 0.01 or abs(mesh_center_y) > 0.01:
                    deck_mesh.vertices[:, 0] += mesh_center_x
                    deck_mesh.vertices[:, 1] += mesh_center_y
                print(f"    Deck mesh: {len(deck_mesh.vertices)} vertices, {len(deck_mesh.faces)} faces")
                print(f"    Deck z range: [{deck_mesh.vertices[:, 2].min():.3f}, {deck_mesh.vertices[:, 2].max():.3f}]")
            except Exception as e:
                print(f"    WARNING: Failed to generate deck: {e}")
                deck_mesh = None
        else:
            print("    WARNING: No polygon available for deck generation")

    # === STEP 5: Trim input mesh ===
    # Trim at z_join (collar overlaps upward by collar_height + z_epsilon)
    print(f"  Trimming input above z={z_join:.3f}...")
    trimmed_top = trim_mesh_above_z(input_mesh, z_join)
    print(f"    Trimmed top: {len(trimmed_top.vertices)} vertices, {len(trimmed_top.faces)} faces")

    if len(trimmed_top.faces) < 10:
        raise ValueError(f"Trimmed top has too few faces ({len(trimmed_top.faces)}). Check z_join={z_join:.3f}.")

    # === STEP 6: Debug validation ===
    if DEBUG_MODE:
        print("  Running protrusion validation...")
        if has_protrusions(collar_polygon, input_mesh, z_join, collar_height):
            print("  WARNING: Protrusion detected after processing! Check debug SVGs.")

    # === STEP 7: Union all components ===
    print("  Performing union...")

    manifold_base = trimesh_to_manifold(micro_base)
    manifold_collar = trimesh_to_manifold(collar_mesh)
    manifold_top = trimesh_to_manifold(trimmed_top)

    # Union: base + deck (if present) + collar + top
    if deck_mesh is not None:
        manifold_deck = trimesh_to_manifold(deck_mesh)
        result_manifold = manifold_base + manifold_deck + manifold_collar + manifold_top
        print("    Including deck slab in union")
    else:
        result_manifold = manifold_base + manifold_collar + manifold_top

    result = manifold_to_trimesh(result_manifold)

    print(f"    Result: {len(result.vertices)} vertices, {len(result.faces)} faces")

    # === STEP 8: Validate result ===
    print("  Validating result...")

    if not result.is_watertight:
        print("    WARNING: Result is not watertight!")

    if result.volume <= 0:
        raise ValueError("Result has non-positive volume")

    # Check for disconnected components
    components = result.split(only_watertight=False)
    if len(components) > 1:
        print(f"    WARNING: Result has {len(components)} disconnected components")
        largest = max(components, key=lambda m: m.volume if m.is_watertight else 0)
        if largest.volume > result.volume * 0.9:
            print(f"    Keeping largest component (volume={largest.volume:.2f}mm³)")
            result = largest
        else:
            print(f"    WARNING: Largest component is only {largest.volume / result.volume * 100:.1f}% of total")

    print(f"  Done. Output volume: {result.volume:.2f}mm³")

    return result


# -----------------------------------------------------------------------------
# High-level API
# -----------------------------------------------------------------------------
def convert_to_micro(
    input_mesh: trimesh.Trimesh,
    micro_divisions: int = 4,
) -> trimesh.Trimesh:
    """
    Convert a 1U Gridfinity box to micro-divided feet.

    This is a convenience wrapper that handles footprint detection
    and calls the replace_base_pipeline.

    Args:
        input_mesh: Input mesh with standard 1U feet
        micro_divisions: Number of divisions (2 or 4)

    Returns:
        Output mesh with micro-feet
    """
    from meshcutter.detection.footprint import detect_aligned_frame

    frame, footprint = detect_aligned_frame(input_mesh, force_z_up=True)

    return replace_base_pipeline(
        input_mesh=input_mesh,
        footprint=footprint,
        frame=frame,
        micro_divisions=micro_divisions,
        mesh_bounds=input_mesh.bounds,
    )
