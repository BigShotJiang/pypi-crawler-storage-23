# meshcutter.pipeline.protrusions - Protrusion detection and correction
#
# Provides utilities for detecting and correcting collar protrusions
# beyond the input mesh boundary.
#

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from shapely.geometry import Polygon
    import trimesh


# Protrusion correction parameters
INITIAL_SAFETY_BUFFER = 0.02  # mm - starting inward shrink
MAX_SAFETY_BUFFER = 0.10  # mm - maximum inward shrink
Z_OVERLAP_EPSILON = 0.08  # mm - overlap at seams to avoid coplanar booleans

# Debug mode from environment
DEBUG_MODE = os.environ.get("MESHCUTTER_DEBUG", "").lower() in ("1", "true", "yes")


def has_protrusions(
    collar_polygon: "Polygon",
    input_mesh: "trimesh.Trimesh",
    z_join: float,
    collar_height: float,
    threshold_area: float = 0.01,
    threshold_dist: float = 0.01,
) -> bool:
    """Check if collar would protrude beyond input mesh.

    Tests at multiple Z levels in the band (10%, 50%, 90% of collar height).

    Args:
        collar_polygon: Extracted collar polygon
        input_mesh: Original input mesh
        z_join: Cut plane height
        collar_height: Height of collar band
        threshold_area: Minimum protrusion area to trigger detection
        threshold_dist: Maximum distance for thin sliver detection

    Returns:
        True if protrusion detected
    """
    from shapely.geometry import Point
    from meshcutter.pipeline.deck import export_debug_svg
    from meshcutter.pipeline.polygons import slice_to_material_polygon

    # Test at 10%, 50%, 90% of collar height
    test_zs = [z_join + collar_height * f for f in [0.1, 0.5, 0.9]]

    for z in test_zs:
        input_poly = slice_to_material_polygon(input_mesh, z)
        if input_poly is None:
            continue

        # Compute protrusion: collar - input
        try:
            protrusion = collar_polygon.difference(input_poly)
        except Exception:
            continue

        if protrusion.is_empty:
            continue

        # Check by area
        protrusion_area = protrusion.area if hasattr(protrusion, "area") else 0
        if protrusion_area > threshold_area:
            if DEBUG_MODE:
                export_debug_svg(input_poly, collar_polygon, protrusion, z)
            return True

        # Check by max distance (catches thin slivers)
        if hasattr(protrusion, "exterior"):
            for point in list(protrusion.exterior.coords)[:20]:  # Sample points
                try:
                    dist = input_poly.exterior.distance(Point(point))
                    if dist > threshold_dist:
                        if DEBUG_MODE:
                            export_debug_svg(input_poly, collar_polygon, protrusion, z)
                        return True
                except Exception:
                    pass

    return False


def apply_adaptive_buffer(
    collar_polygon: "Polygon",
    input_mesh: "trimesh.Trimesh",
    z_join: float,
    collar_height: float,
    initial_delta: float = INITIAL_SAFETY_BUFFER,
    max_delta: float = MAX_SAFETY_BUFFER,
    step: float = 0.02,
) -> "Polygon":
    """Apply minimal inward buffer that eliminates protrusions.

    Starts with initial_delta and increases until no protrusions or max reached.

    Args:
        collar_polygon: Extracted collar polygon
        input_mesh: Original input mesh
        z_join: Cut plane height
        collar_height: Height of collar band
        initial_delta: Starting buffer amount
        max_delta: Maximum buffer amount
        step: Buffer increment step

    Returns:
        Buffered polygon with protrusions eliminated (or original if none)
    """
    from meshcutter.pipeline.polygons import (
        clean_polygon,
        ensure_single_polygon,
    )

    # First check if we even need buffering
    if not has_protrusions(collar_polygon, input_mesh, z_join, collar_height):
        return collar_polygon

    delta = initial_delta
    previous_valid = collar_polygon

    while delta <= max_delta:
        try:
            buffered = collar_polygon.buffer(-delta)
        except Exception:
            break

        # Guard against empty/invalid result
        if buffered.is_empty:
            # Buffer collapsed the polygon - return previous valid
            return previous_valid

        # Handle MultiPolygon from buffer
        buffered = ensure_single_polygon(buffered)
        if buffered is None or buffered.is_empty:
            return previous_valid

        # Clean if needed
        buffered = clean_polygon(buffered)
        if buffered is None or buffered.is_empty:
            return previous_valid

        previous_valid = buffered

        # Check for protrusions
        if not has_protrusions(buffered, input_mesh, z_join, collar_height):
            return buffered

        delta += step

    # Max buffer reached
    print(f"  WARNING: Max safety buffer {max_delta}mm applied")
    return previous_valid


def extract_collar_fallback_shadow(
    mesh: "trimesh.Trimesh",
    z_join: float,
    collar_height: float,
    z_epsilon: float = Z_OVERLAP_EPSILON,
) -> Optional["Polygon"]:
    """Fallback when slice-based extraction fails.

    Projects triangles in the band to XY and unions them.

    Args:
        mesh: Input mesh
        z_join: Cut plane height
        collar_height: Height of collar band
        z_epsilon: Z band expansion for triangle selection

    Returns:
        Shadow polygon or None if extraction fails
    """
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    from meshcutter.pipeline.polygons import ensure_single_polygon

    z_lo = z_join - z_epsilon
    z_hi = z_join + collar_height + z_epsilon

    # Find triangles that intersect the Z band
    tri_z_min = mesh.triangles[:, :, 2].min(axis=1)
    tri_z_max = mesh.triangles[:, :, 2].max(axis=1)

    in_band = (tri_z_max >= z_lo) & (tri_z_min <= z_hi)
    band_triangles = mesh.triangles[in_band]

    if len(band_triangles) == 0:
        return None

    # Project to XY and create 2D polygons
    projected = []
    for tri in band_triangles:
        xy = tri[:, :2]  # Drop Z
        try:
            poly = Polygon(xy)
            if poly.is_valid and poly.area > 1e-9:
                projected.append(poly)
        except Exception:
            pass

    if not projected:
        return None

    # Union all projections
    try:
        shadow = unary_union(projected)
    except Exception:
        return None

    # Clean up and shrink for safety
    shadow = ensure_single_polygon(shadow)
    if shadow is None:
        return None

    # Apply small erosion for safety
    try:
        shadow = shadow.buffer(-0.05)
        shadow = ensure_single_polygon(shadow)
    except Exception:
        pass

    return shadow


def create_idealized_envelope(
    cells_x: int,
    cells_y: int,
    pitch: float,
    gr_tol: float,
    gr_rad: float,
) -> "Polygon":
    """Create idealized envelope polygon (fallback of last resort).

    This is the rounded rectangle that SHOULD match the wall outline,
    but may not match third-party models exactly.

    Args:
        cells_x: Number of cells in X direction
        cells_y: Number of cells in Y direction
        pitch: Grid pitch (typically 42mm)
        gr_tol: Grid tolerance
        gr_rad: Corner radius

    Returns:
        Rounded rectangle polygon
    """
    from shapely.geometry import box as shapely_box
    from meshcutter.pipeline.polygons import ensure_single_polygon

    outer_l = cells_x * pitch - gr_tol
    outer_w = cells_y * pitch - gr_tol
    outer_rad = gr_rad - gr_tol / 2

    # Create rounded rectangle using Shapely
    # Start with rectangle, buffer inward, then outward to round corners
    rect = shapely_box(-outer_l / 2, -outer_w / 2, outer_l / 2, outer_w / 2)
    rounded = rect.buffer(-outer_rad).buffer(outer_rad)

    return ensure_single_polygon(rounded)


__all__ = [
    # Constants
    "INITIAL_SAFETY_BUFFER",
    "MAX_SAFETY_BUFFER",
    "Z_OVERLAP_EPSILON",
    "DEBUG_MODE",
    # Functions
    "has_protrusions",
    "apply_adaptive_buffer",
    "extract_collar_fallback_shadow",
    "create_idealized_envelope",
]
