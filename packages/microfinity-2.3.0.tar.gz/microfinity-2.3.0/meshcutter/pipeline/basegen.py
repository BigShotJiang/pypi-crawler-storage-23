# meshcutter.pipeline.basegen - Base generation utilities
#
# Provides mesh generation for micro-feet bases, collar meshes,
# and mesh trimming operations.
#

from __future__ import annotations

from typing import List, Optional, Tuple, TYPE_CHECKING

if TYPE_CHECKING:
    import cadquery as cq
    from shapely.geometry import Polygon
    import trimesh


# Collar height (for backward compatibility with sleeve_height parameter)
COLLAR_HEIGHT = 0.5  # mm - height of overlap band
SLEEVE_HEIGHT = COLLAR_HEIGHT  # Legacy alias
# Z split is where we cut between top (kept) and bottom (replaced)
Z_SPLIT_HEIGHT = 5.0  # mm - GR_BASE_HEIGHT + GR_BASE_CLR = 4.75 + 0.25


def generate_collar_mesh(
    collar_polygon: "Polygon",
    z_join: float,
    collar_height: float = COLLAR_HEIGHT,
    z_epsilon: float = 0.08,
) -> "trimesh.Trimesh":
    """Extrude collar polygon with Z-overlap at both ends.

    Collar spans [z_join - z_epsilon, z_join + collar_height + z_epsilon]

    Args:
        collar_polygon: 2D collar boundary polygon
        z_join: Cut plane height
        collar_height: Height of collar band
        z_epsilon: Overlap at seams to avoid coplanar booleans

    Returns:
        Collar mesh positioned correctly

    Raises:
        ValueError: If collar_polygon is empty or invalid
    """
    import trimesh

    if collar_polygon is None or collar_polygon.is_empty:
        raise ValueError("Cannot generate collar from empty polygon")

    # Total collar height including overlaps
    total_height = collar_height + 2 * z_epsilon

    # Extrude from z=0, then translate
    try:
        collar_mesh = trimesh.creation.extrude_polygon(collar_polygon, height=total_height)
    except Exception as e:
        raise ValueError(f"Failed to extrude collar polygon: {e}")

    # Position: bottom at z_join - z_epsilon
    collar_mesh.vertices[:, 2] += z_join - z_epsilon

    return collar_mesh


def clip_base_top_band(
    micro_base: "trimesh.Trimesh",
    guard_polygon: "Polygon",
    z_min: float,
    z_join: float,
    guard_height: float = 0.6,
    z_epsilon: float = 0.1,
) -> "trimesh.Trimesh":
    """Clip the top band of the micro-feet base to the guard polygon.

    Only affects the region from (z_join - guard_height) to z_join.
    The lower portion of the base is unaffected.

    Args:
        micro_base: Micro-feet base mesh to clip
        guard_polygon: 2D polygon from input mesh chamfer region
        z_min: Bottom of base
        z_join: Top of base (z_split plane)
        guard_height: Height of band to clip
        z_epsilon: Extra Z overlap for clean boolean

    Returns:
        Clipped micro-feet base mesh
    """
    import cadquery as cq
    from meshcutter.pipeline.conversion import (
        manifold_to_trimesh,
        trimesh_to_manifold,
    )
    from meshcutter.pipeline.collar import BASE_GUARD_HEIGHT

    if guard_polygon is None or guard_polygon.is_empty:
        return micro_base

    # Use default guard height if not specified
    if guard_height is None:
        guard_height = BASE_GUARD_HEIGHT

    # The band we want to clip is [z_join - guard_height, z_join]
    z_band_bottom = z_join - guard_height
    z_band_top = z_join

    # Split micro_base into:
    # - lower part: below z_band_bottom (unchanged)
    # - upper band: z_band_bottom to z_join (to be clipped)

    m_base = trimesh_to_manifold(micro_base)

    # Trim to get lower part only (below band)
    # Keep material where z < z_band_bottom
    m_lower = m_base.trim_by_plane(normal=(0.0, 0.0, -1.0), origin_offset=-z_band_bottom)

    # Trim to get upper band only
    # Keep material where z >= z_band_bottom AND z <= z_join
    m_upper = m_base.trim_by_plane(normal=(0.0, 0.0, 1.0), origin_offset=z_band_bottom)
    # The upper should already be <= z_join from base generation

    # Create guard prism for clipping the upper band
    # Extrude the guard polygon from z_band_bottom - epsilon to z_join + epsilon
    guard_thickness = guard_height + 2 * z_epsilon

    try:
        guard_mesh = trimesh.creation.extrude_polygon(guard_polygon, height=guard_thickness)
        guard_mesh.vertices[:, 2] += z_band_bottom - z_epsilon
    except Exception:
        # Failed to create guard - return unclipped
        return micro_base

    # Convert guard to manifold and intersect with upper band
    m_guard = trimesh_to_manifold(guard_mesh)
    m_upper_clipped = m_upper ^ m_guard  # Intersection

    # Union lower part with clipped upper band
    if m_lower is not None and not m_lower.is_empty():
        m_result = m_lower + m_upper_clipped  # Union
    else:
        m_result = m_upper_clipped

    # Convert back to trimesh
    return manifold_to_trimesh(m_result)


def trim_mesh_above_z(mesh: "trimesh.Trimesh", z_cut: float) -> "trimesh.Trimesh":
    """Trim mesh to keep only the portion above z_cut.

    Uses Manifold's trim_by_plane for a clean geometric cut.

    Args:
        mesh: Input mesh
        z_cut: Z height to trim at

    Returns:
        Trimmed mesh (portion above z_cut)
    """
    from meshcutter.pipeline.conversion import (
        manifold_to_trimesh,
        trimesh_to_manifold,
    )

    manifold = trimesh_to_manifold(mesh)

    # trim_by_plane keeps material where dot(v, normal) >= origin_offset
    # To keep v.z >= z_cut: use normal=(0,0,1), origin_offset=z_cut
    trimmed = manifold.trim_by_plane(normal=(0.0, 0.0, 1.0), origin_offset=z_cut)

    return manifold_to_trimesh(trimmed)


def generate_micro_foot_cq(
    micro_divisions: int = 4,
    gru: float = 42.0,
    gr_tol: float = 0.5,
    gr_rad: float = 4.0,
    gr_base_clr: float = 0.25,
    gr_box_profile: list = None,
) -> "cq.Workplane":
    """Generate a single micro-foot solid using CadQuery.

    Args:
        micro_divisions: Number of divisions per 1U (2 or 4)
        gru: 1U pitch (typically 42mm)
        gr_tol: Grid tolerance
        gr_rad: Corner radius
        gr_base_clr: Base clearance
        gr_box_profile: Box profile for extrusion

    Returns:
        CadQuery Workplane with micro-foot solid
    """
    import cadquery as cq
    from cqkit.cq_helpers import rounded_rect_sketch

    if gr_box_profile is None:
        # Default profile: [(z_len, taper_deg), ...]
        gr_box_profile = [(0.55, -45), (0.8, 0), (3.4, 0)]

    micro_pitch = gru / micro_divisions
    foot_size = micro_pitch - gr_tol

    outer_rad = gr_rad - gr_tol / 2
    rad = min(outer_rad + gr_base_clr, foot_size / 2 - 0.05)
    rad = max(rad, 0.2)

    foot = extrude_profile(rounded_rect_sketch(foot_size, foot_size, rad), gr_box_profile)
    foot = foot.translate((0, 0, -gr_base_clr))
    foot = foot.mirror(mirrorPlane="XY")

    return foot


def micro_foot_offsets(
    cells_x: int,
    cells_y: int,
    micro_divisions: int = 4,
    pitch: float = 42.0,
) -> List[Tuple[float, float]]:
    """Return micro-foot center offsets for a grid of cells.

    Args:
        cells_x: Number of cells in X
        cells_y: Number of cells in Y
        micro_divisions: Number of divisions per 1U (2 or 4)
        pitch: 1U pitch (typically 42mm)

    Returns:
        List of (x, y) offset tuples for each micro-foot
    """
    if micro_divisions <= 1:
        return [(x * pitch, y * pitch) for x in range(cells_x) for y in range(cells_y)]

    micro_pitch = pitch / micro_divisions
    micro_count_x = cells_x * micro_divisions
    micro_count_y = cells_y * micro_divisions

    half_l = (cells_x - 1) * pitch / 2
    half_w = (cells_y - 1) * pitch / 2
    micro_half_l = (micro_count_x - 1) * micro_pitch / 2
    micro_half_w = (micro_count_y - 1) * micro_pitch / 2

    offsets = [
        (x * micro_pitch - micro_half_l + half_l, y * micro_pitch - micro_half_w + half_w)
        for x in range(micro_count_x)
        for y in range(micro_count_y)
    ]
    return offsets


def generate_micro_base(
    cells_x: int,
    cells_y: int,
    micro_divisions: int = 4,
    z_base: float = 0.0,
    pitch: float = 42.0,
    gru: float = 42.0,
    gr_tol: float = 0.5,
    gr_rad: float = 4.0,
    gr_base_clr: float = 0.25,
    gr_box_profile: list = None,
    gr_base_height: float = 4.75,
) -> "trimesh.Trimesh":
    """Generate micro-feet base ending at z_join (no sleeve).

    The base top is at z_base + GR_BASE_HEIGHT + GR_BASE_CLR = z_base + 5.0mm

    Args:
        cells_x: Number of cells in X
        cells_y: Number of cells in Y
        micro_divisions: Number of divisions per 1U (2 or 4)
        z_base: Bottom Z position
        pitch: 1U pitch
        gru: 1U pitch (alias)
        gr_tol: Grid tolerance
        gr_rad: Corner radius
        gr_base_clr: Base clearance
        gr_box_profile: Box profile for extrusion
        gr_base_height: Base height

    Returns:
        Micro-feet base mesh
    """
    import cadquery as cq
    import trimesh
    from cqkit.cq_helpers import rounded_rect_sketch
    from meshcutter.pipeline.conversion import cq_to_trimesh

    outer_l = cells_x * pitch - gr_tol
    outer_w = cells_y * pitch - gr_tol
    outer_rad = gr_rad - gr_tol / 2

    half_l = (cells_x - 1) * pitch / 2
    half_w = (cells_y - 1) * pitch / 2

    # Generate micro-foot template
    micro_foot = generate_micro_foot_cq(micro_divisions, gru, gr_tol, gr_rad, gr_base_clr, gr_box_profile)
    micro_foot_solid = micro_foot.val()

    # Replicate micro-feet at all positions
    offsets = micro_foot_offsets(cells_x, cells_y, micro_divisions, pitch)

    feet_union = None
    for ox, oy in offsets:
        instance = micro_foot_solid.translate(cq.Vector(ox, oy, 0))
        if feet_union is None:
            feet_union = instance
        else:
            feet_union = feet_union.fuse(instance)

    # Create outer envelope to crop feet
    crop_env = (
        cq.Workplane("XY")
        .placeSketch(rounded_rect_sketch(outer_l, outer_w, outer_rad))
        .extrude(-gr_base_height - 1)
        .translate(cq.Vector(half_l, half_w, 0.5))
    )

    # Intersect feet with envelope (no sleeve!)
    base_solid = crop_env.val().intersect(feet_union)

    # Translate to center at origin in XY
    base_solid = base_solid.translate(cq.Vector(-half_l, -half_w, 0))

    base_cq = cq.Workplane("XY").newObject([base_solid])

    # Convert to trimesh
    mesh = cq_to_trimesh(base_cq, tol=0.01, ang_tol=0.1)

    # Adjust Z position: foot tip at z_base
    z_min_mesh = mesh.vertices[:, 2].min()
    z_shift = z_base - z_min_mesh
    mesh.vertices[:, 2] += z_shift

    return mesh


def generate_micro_base_with_sleeve(
    cells_x: int,
    cells_y: int,
    micro_divisions: int = 4,
    z_base: float = 0.0,
    sleeve_height: float = COLLAR_HEIGHT,
    pitch: float = 42.0,
) -> "trimesh.Trimesh":
    """Legacy wrapper - generates base without sleeve.

    The collar is now generated separately from the input mesh.

    Args:
        cells_x: Number of cells in X
        cells_y: Number of cells in Y
        micro_divisions: Number of divisions per 1U (2 or 4)
        z_base: Bottom Z position
        sleeve_height: Legacy parameter (now ignored)
        pitch: 1U pitch

    Returns:
        Micro-feet base mesh
    """
    return generate_micro_base(
        cells_x=cells_x,
        cells_y=cells_y,
        micro_divisions=micro_divisions,
        z_base=z_base,
        pitch=pitch,
    )


# Import extrude_profile locally to avoid circular imports
def extrude_profile(sketch, profile, workplane="XY", angle=None):
    """Extrude a sketch through a multi-segment profile with optional tapers."""
    import cadquery as cq
    import math

    taper = profile[0][1] if isinstance(profile[0], (list, tuple)) else 0
    zlen = profile[0][0] if isinstance(profile[0], (list, tuple)) else profile[0]

    if abs(taper) > 0:
        if angle is None:
            # Use taper directly
            r = cq.Workplane(workplane).placeSketch(sketch).extrude(zlen, taper=taper)
        else:
            # Calculate taper from angle
            taper_angle = angle if isinstance(angle, (int, float)) else profile[0][1]
            r = cq.Workplane(workplane).placeSketch(sketch).extrude(zlen, taper=taper_angle)
    else:
        r = cq.Workplane(workplane).placeSketch(sketch).extrude(zlen)

    for level in profile[1:]:
        if isinstance(level, (tuple, list)):
            zlen = level[0]
            taper = level[1] if len(level) > 1 else 0
            if abs(taper) > 0:
                r = r.faces(">Z").wires().toPending().extrude(zlen, taper=taper)
            else:
                r = r.faces(">Z").wires().toPending().extrude(zlen)
        else:
            r = r.faces(">Z").wires().toPending().extrude(level)

    return r


__all__ = [
    # Constants
    "COLLAR_HEIGHT",
    "SLEEVE_HEIGHT",
    "Z_SPLIT_HEIGHT",
    # Functions
    "generate_collar_mesh",
    "clip_base_top_band",
    "trim_mesh_above_z",
    "generate_micro_foot_cq",
    "micro_foot_offsets",
    "generate_micro_base",
    "generate_micro_base_with_sleeve",
]
