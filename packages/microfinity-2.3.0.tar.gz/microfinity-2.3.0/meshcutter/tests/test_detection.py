#! /usr/bin/env python3
#
# Tests for meshcutter.core.detection
#

import pytest
import numpy as np

# Skip if trimesh not available
trimesh = pytest.importorskip("trimesh")

from meshcutter.detection.footprint import (
    BottomFrame,
    detect_bottom_frame,
    extract_footprint,
    get_mesh_diagnostics,
)


def create_test_box(
    size_x: float = 42.0,
    size_y: float = 42.0,
    size_z: float = 20.0,
    origin: tuple = (0, 0, 0),
) -> trimesh.Trimesh:
    """Create a test box mesh."""
    box = trimesh.creation.box(extents=[size_x, size_y, size_z])
    # Move so bottom is at origin[2]
    box.apply_translation(
        [
            origin[0] + size_x / 2,
            origin[1] + size_y / 2,
            origin[2] + size_z / 2,
        ]
    )
    return box


class TestBottomFrame:
    """Tests for BottomFrame dataclass."""

    def test_world_to_local_identity(self):
        """Identity rotation should not change coordinates (except origin offset)."""
        frame = BottomFrame(
            origin=np.array([10.0, 20.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )

        points = np.array([[15.0, 25.0, 5.0]])
        local = frame.world_to_local(points)

        # Should be offset by origin
        expected = np.array([[5.0, 5.0, 5.0]])
        np.testing.assert_array_almost_equal(local, expected)

    def test_local_to_world_identity(self):
        """Identity rotation round-trip."""
        frame = BottomFrame(
            origin=np.array([10.0, 20.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )

        local = np.array([[5.0, 5.0, 5.0]])
        world = frame.local_to_world(local)

        expected = np.array([[15.0, 25.0, 5.0]])
        np.testing.assert_array_almost_equal(world, expected)

    def test_round_trip(self):
        """world_to_local followed by local_to_world should be identity."""
        # Random rotation matrix
        angle = np.pi / 6
        rotation = np.array(
            [
                [np.cos(angle), -np.sin(angle), 0],
                [np.sin(angle), np.cos(angle), 0],
                [0, 0, 1],
            ]
        )

        frame = BottomFrame(
            origin=np.array([100.0, 200.0, 5.0]),
            rotation=rotation,
            z_min=5.0,
        )

        original = np.array([[150.0, 250.0, 10.0], [110.0, 210.0, 7.0]])
        local = frame.world_to_local(original)
        recovered = frame.local_to_world(local)

        np.testing.assert_array_almost_equal(recovered, original)

    def test_to_transform_matrix(self):
        """Transform matrix should be valid 4x4."""
        frame = BottomFrame(
            origin=np.array([10.0, 20.0, 5.0]),
            rotation=np.eye(3),
            z_min=5.0,
        )

        T = frame.to_transform_matrix()

        assert T.shape == (4, 4)
        assert T[3, 3] == 1.0
        np.testing.assert_array_equal(T[3, :3], [0, 0, 0])


class TestDetectBottomFrame:
    """Tests for detect_bottom_frame function."""

    def test_simple_box_z_aligned(self):
        """Simple box should detect bottom at z=0."""
        box = create_test_box(size_x=42, size_y=42, size_z=20, origin=(0, 0, 0))

        frame = detect_bottom_frame(box, force_z_up=True)

        assert frame.z_min == pytest.approx(0.0, abs=0.01)
        # Up normal should be +Z
        np.testing.assert_array_almost_equal(frame.up_normal, [0, 0, 1], decimal=5)

    def test_offset_box(self):
        """Box at non-zero origin should detect correct z_min."""
        box = create_test_box(size_x=42, size_y=42, size_z=20, origin=(50, 100, 10))

        frame = detect_bottom_frame(box, force_z_up=True)

        assert frame.z_min == pytest.approx(10.0, abs=0.01)

    def test_auto_detect(self):
        """Auto-detection should work for aligned box."""
        box = create_test_box(size_x=42, size_y=42, size_z=20, origin=(0, 0, 0))

        frame = detect_bottom_frame(box, force_z_up=False)

        assert frame.z_min == pytest.approx(0.0, abs=0.01)
        # Up normal should be close to +Z
        assert frame.up_normal[2] > 0.9

    def test_no_bottom_faces_error(self):
        """Should raise ValueError if no bottom faces found."""
        # Create a mesh with all normals pointing up (impossible in practice
        # but simulates edge case)
        box = create_test_box()

        # This should work normally
        frame = detect_bottom_frame(box, force_z_up=True)
        assert frame is not None

    def test_frame_is_right_handed(self):
        """Frame should be right-handed (x cross y = z)."""
        box = create_test_box()

        frame = detect_bottom_frame(box, force_z_up=True)

        cross = np.cross(frame.x_axis, frame.y_axis)
        dot = np.dot(cross, frame.up_normal)

        assert dot > 0.99  # Should be close to 1


class TestExtractFootprint:
    """Tests for extract_footprint function."""

    def test_simple_box_footprint(self):
        """Simple box should have rectangular footprint."""
        box = create_test_box(size_x=42, size_y=42, size_z=20, origin=(0, 0, 0))
        frame = detect_bottom_frame(box, force_z_up=True)

        footprint = extract_footprint(box, frame)

        assert footprint is not None
        assert footprint.is_valid
        # Area should be close to 42 * 42 = 1764
        assert footprint.area == pytest.approx(1764, rel=0.01)

    def test_footprint_bounds(self):
        """Footprint bounds should match box base dimensions."""
        box = create_test_box(size_x=84, size_y=42, size_z=20, origin=(0, 0, 0))
        frame = detect_bottom_frame(box, force_z_up=True)

        footprint = extract_footprint(box, frame)
        bounds = footprint.bounds  # (minx, miny, maxx, maxy)

        # Width and height
        width = bounds[2] - bounds[0]
        height = bounds[3] - bounds[1]

        assert width == pytest.approx(84, rel=0.01)
        assert height == pytest.approx(42, rel=0.01)


class TestGetMeshDiagnostics:
    """Tests for get_mesh_diagnostics function."""

    def test_returns_expected_keys(self):
        """Should return dict with expected diagnostic keys."""
        box = create_test_box()

        diag = get_mesh_diagnostics(box)

        assert "is_watertight" in diag
        assert "is_winding_consistent" in diag
        assert "euler_number" in diag
        assert "bounds_min" in diag
        assert "bounds_max" in diag
        assert "triangle_count" in diag
        assert "vertex_count" in diag
        assert "volume" in diag
        assert "area" in diag

    def test_watertight_box(self):
        """Box should be watertight."""
        box = create_test_box()

        diag = get_mesh_diagnostics(box)

        assert diag["is_watertight"] is True
        assert diag["volume"] is not None
        assert diag["volume"] > 0
