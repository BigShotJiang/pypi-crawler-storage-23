#! /usr/bin/env python3
#
# Tests for meshcutter.core.grid
#

import pytest
import numpy as np
from shapely.geometry import Polygon, MultiPolygon, box

from meshcutter.mesh.grid import (
    compute_grid_positions,
    generate_grid_mask,
    compute_pitch,
    get_grid_info,
    GRU,
    DEFAULT_SLOT_WIDTH,
)


class TestComputePitch:
    """Tests for compute_pitch function."""

    def test_quarter_grid(self):
        """4 divisions = 10.5mm pitch."""
        assert compute_pitch(4) == 10.5

    def test_half_grid(self):
        """2 divisions = 21mm pitch."""
        assert compute_pitch(2) == 21.0

    def test_full_grid(self):
        """1 division = 42mm pitch."""
        assert compute_pitch(1) == 42.0

    def test_invalid_divisions(self):
        """Invalid divisions should raise ValueError."""
        with pytest.raises(ValueError):
            compute_pitch(3)
        with pytest.raises(ValueError):
            compute_pitch(0)
        with pytest.raises(ValueError):
            compute_pitch(-1)


class TestComputeGridPositions:
    """Tests for compute_grid_positions function."""

    def test_centered_grid(self):
        """Grid should be centered on bbox centroid."""
        bbox = (0, 0, 42, 42)  # 1x1 grid unit
        pitch = 10.5  # quarter-grid

        x_pos, y_pos = compute_grid_positions(bbox, pitch)

        # Centroid is at (21, 21)
        # Grid lines at 21 + k*10.5 for k = -2, -1, 0, 1, 2
        expected_x = [0.0, 10.5, 21.0, 31.5, 42.0]
        expected_y = [0.0, 10.5, 21.0, 31.5, 42.0]

        assert len(x_pos) == len(expected_x)
        assert len(y_pos) == len(expected_y)

        for x, ex in zip(sorted(x_pos), expected_x):
            assert abs(x - ex) < 0.001

    def test_phase_offset(self):
        """Phase offset should shift grid reference point."""
        bbox = (0, 0, 42, 42)
        pitch = 21.0  # half-grid

        # Use get_grid_info to verify grid reference shifts by phase amount
        info_no_phase = get_grid_info(box(0, 0, 42, 42), pitch, phase_x=0.0)
        info_with_phase = get_grid_info(box(0, 0, 42, 42), pitch, phase_x=5.0)

        # Grid reference should shift by phase amount
        ref_no_phase = info_no_phase["grid_reference"]
        ref_with_phase = info_with_phase["grid_reference"]

        # X component of reference should differ by 5.0
        assert abs(ref_with_phase[0] - ref_no_phase[0] - 5.0) < 0.001
        # Y component should be unchanged (no phase_y offset)
        assert abs(ref_with_phase[1] - ref_no_phase[1]) < 0.001

    def test_deterministic(self):
        """Same inputs should produce same outputs."""
        bbox = (10, 20, 100, 80)
        pitch = 10.5

        x1, y1 = compute_grid_positions(bbox, pitch, phase_x=1.0, phase_y=2.0)
        x2, y2 = compute_grid_positions(bbox, pitch, phase_x=1.0, phase_y=2.0)

        assert x1 == x2
        assert y1 == y2


class TestGenerateGridMask:
    """Tests for generate_grid_mask function."""

    def test_basic_mask(self):
        """Basic grid mask generation."""
        footprint = box(0, 0, 42, 42)  # 1x1 grid unit
        pitch = 21.0  # half-grid

        mask = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=2.0,
            clearance=0.0,
        )

        assert mask is not None
        assert mask.area > 0
        # Mask area should be less than footprint area
        assert mask.area < footprint.area

    def test_clearance_expands_slots(self):
        """Clearance should expand slot width."""
        footprint = box(0, 0, 42, 42)
        pitch = 21.0

        mask_no_clearance = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=2.0,
            clearance=0.0,
        )

        mask_with_clearance = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=2.0,
            clearance=0.5,
        )

        # More clearance = larger cut area
        assert mask_with_clearance.area > mask_no_clearance.area

    def test_clips_to_footprint(self):
        """Mask clips to footprint when clip_to_footprint=True."""
        footprint = box(5, 5, 37, 37)  # Smaller than grid
        pitch = 10.5

        mask = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=2.0,
            clip_to_footprint=True,  # Enable clipping to test clipping behavior
        )

        # Mask bounds should not exceed footprint bounds when clipped
        mask_bounds = mask.bounds
        foot_bounds = footprint.bounds

        assert mask_bounds[0] >= foot_bounds[0] - 0.001
        assert mask_bounds[1] >= foot_bounds[1] - 0.001
        assert mask_bounds[2] <= foot_bounds[2] + 0.001
        assert mask_bounds[3] <= foot_bounds[3] + 0.001

    def test_invalid_pitch(self):
        """Invalid pitch should raise ValueError."""
        footprint = box(0, 0, 42, 42)

        with pytest.raises(ValueError):
            generate_grid_mask(footprint, pitch=0)

        with pytest.raises(ValueError):
            generate_grid_mask(footprint, pitch=-10)

    def test_invalid_slot_width(self):
        """Invalid slot width should raise ValueError."""
        footprint = box(0, 0, 42, 42)

        with pytest.raises(ValueError):
            generate_grid_mask(footprint, pitch=10.5, slot_width=0)

        with pytest.raises(ValueError):
            generate_grid_mask(footprint, pitch=10.5, slot_width=-1)

    def test_multipolygon_footprint(self):
        """Should handle MultiPolygon footprints."""
        # Two separate squares
        poly1 = box(0, 0, 20, 20)
        poly2 = box(30, 30, 50, 50)
        footprint = MultiPolygon([poly1, poly2])

        mask = generate_grid_mask(
            footprint=footprint,
            pitch=10.5,
            slot_width=2.0,
        )

        assert mask is not None
        assert mask.area > 0


class TestGetGridInfo:
    """Tests for get_grid_info function."""

    def test_returns_expected_keys(self):
        """Should return dict with expected keys."""
        footprint = box(0, 0, 42, 42)
        pitch = 10.5

        info = get_grid_info(footprint, pitch)

        assert "footprint_bounds" in info
        assert "footprint_area" in info
        assert "footprint_centroid" in info
        assert "pitch" in info
        assert "phase" in info
        assert "grid_reference" in info
        assert "x_cut_positions" in info
        assert "y_cut_positions" in info
        assert "num_x_cuts" in info
        assert "num_y_cuts" in info
        assert "total_cuts" in info

    def test_cut_counts(self):
        """Cut counts should match position list lengths."""
        footprint = box(0, 0, 42, 42)
        pitch = 10.5

        info = get_grid_info(footprint, pitch)

        assert info["num_x_cuts"] == len(info["x_cut_positions"])
        assert info["num_y_cuts"] == len(info["y_cut_positions"])
        assert info["total_cuts"] == info["num_x_cuts"] + info["num_y_cuts"]
