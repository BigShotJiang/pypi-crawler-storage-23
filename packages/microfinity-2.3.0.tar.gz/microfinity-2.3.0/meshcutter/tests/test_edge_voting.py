#! /usr/bin/env python3
"""Tests for edge-direction voting alignment."""

import numpy as np
import pytest
from shapely.geometry import Polygon, box
from shapely.affinity import rotate

from meshcutter.detection.footprint import (
    compute_dominant_edge_angle,
    apply_yaw_to_frame,
    BottomFrame,
)


class TestComputeDominantEdgeAngle:
    """Tests for compute_dominant_edge_angle()."""

    def test_axis_aligned_rectangle(self):
        """Axis-aligned rectangle should have dominant angle near 0 or 90 degrees."""
        poly = box(0, 0, 42, 21)  # 42x21 rectangle, long edge along X
        angle = compute_dominant_edge_angle(poly)
        assert angle is not None
        # Dominant angle should be near 0 (horizontal) or pi/2 (vertical)
        # Since long edge is along X, expect near 0
        assert angle < np.radians(5) or angle > np.radians(85)

    def test_rotated_rectangle(self):
        """Rotated rectangle should detect the rotation angle."""
        poly = box(0, 0, 42, 21)
        rotated = rotate(poly, 30, origin="centroid")  # 30 degree rotation
        angle = compute_dominant_edge_angle(rotated)
        assert angle is not None
        # Should be near 30 degrees or 120 degrees (perpendicular edge)
        angle_deg = np.degrees(angle)
        assert (25 < angle_deg < 35) or (115 < angle_deg < 125)

    def test_square_has_dominant_angle(self):
        """Square should still find a dominant angle (from one pair of edges)."""
        poly = box(0, 0, 42, 42)
        angle = compute_dominant_edge_angle(poly)
        assert angle is not None
        # Should be near 0 or 90 degrees
        angle_deg = np.degrees(angle)
        assert angle_deg < 5 or (85 < angle_deg < 95)

    def test_rectangle_with_small_fillets(self):
        """Rectangle with small fillets should still detect correct angle."""
        # Create a rectangle with chamfered corners (simulating fillets)
        # Original rectangle: 42x21
        coords = [
            (2, 0),
            (40, 0),  # bottom edge
            (42, 2),
            (42, 19),  # right edge
            (40, 21),
            (2, 21),  # top edge
            (0, 19),
            (0, 2),  # left edge
            (2, 0),  # close
        ]
        poly = Polygon(coords)
        angle = compute_dominant_edge_angle(poly)
        assert angle is not None
        # Long edges dominate, should be near 0
        angle_deg = np.degrees(angle)
        assert angle_deg < 10 or angle_deg > 80

    def test_no_dominant_angle_for_circle(self):
        """Circle-like polygon has no dominant edge direction."""
        # Create a circle approximation with many edges
        n_points = 64
        angles = np.linspace(0, 2 * np.pi, n_points, endpoint=False)
        coords = [(20 * np.cos(a), 20 * np.sin(a)) for a in angles]
        poly = Polygon(coords)

        # Should return None (no dominant direction)
        # or the dominance threshold may not be met
        angle = compute_dominant_edge_angle(poly, min_dominance=0.35)
        # For a circle, no bin should have > 35% of the weight
        # This may or may not return None depending on binning
        # Just verify it doesn't crash

    def test_recovers_angle_within_tolerance(self):
        """Slightly filleted rectangle should recover angle within 0.5 degrees."""
        # Create a clean rectangle with very small corner fillets
        coords = [
            (1, 0),
            (41, 0),  # bottom (40mm)
            (42, 1),
            (42, 20),  # right (19mm)
            (41, 21),
            (1, 21),  # top (40mm)
            (0, 20),
            (0, 1),  # left (19mm)
            (1, 0),
        ]
        poly = Polygon(coords)
        angle = compute_dominant_edge_angle(poly)
        assert angle is not None
        # Should be very close to 0 (horizontal dominates)
        assert abs(angle) < np.radians(0.5) or abs(angle - np.pi / 2) < np.radians(0.5)


class TestApplyYawToFrame:
    """Tests for apply_yaw_to_frame()."""

    def test_identity_rotation(self):
        """Zero yaw should not change frame."""
        frame = BottomFrame(
            origin=np.array([0.0, 0.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )
        rotated = apply_yaw_to_frame(frame, 0.0)
        np.testing.assert_array_almost_equal(rotated.x_axis, frame.x_axis)
        np.testing.assert_array_almost_equal(rotated.y_axis, frame.y_axis)

    def test_90_degree_rotation(self):
        """90 degree yaw should swap X and Y axes."""
        frame = BottomFrame(
            origin=np.array([0.0, 0.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )
        rotated = apply_yaw_to_frame(frame, np.pi / 2)
        # After 90 deg rotation: new_x = old_y, new_y = -old_x
        np.testing.assert_array_almost_equal(rotated.x_axis, [0, 1, 0])
        np.testing.assert_array_almost_equal(rotated.y_axis, [-1, 0, 0])

    def test_preserves_up_normal(self):
        """Yaw rotation should not change the up normal."""
        frame = BottomFrame(
            origin=np.array([10.0, 20.0, 5.0]),
            rotation=np.eye(3),
            z_min=5.0,
        )
        rotated = apply_yaw_to_frame(frame, np.radians(45))
        np.testing.assert_array_almost_equal(rotated.up_normal, frame.up_normal)

    def test_preserves_origin(self):
        """Yaw rotation should not change the origin."""
        origin = np.array([10.0, 20.0, 5.0])
        frame = BottomFrame(
            origin=origin.copy(),
            rotation=np.eye(3),
            z_min=5.0,
        )
        rotated = apply_yaw_to_frame(frame, np.radians(30))
        np.testing.assert_array_almost_equal(rotated.origin, origin)

    def test_right_handed_after_rotation(self):
        """Frame should remain right-handed after rotation."""
        frame = BottomFrame(
            origin=np.array([0.0, 0.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )
        for angle in [30, 45, 60, 90, 120, 180, 270]:
            rotated = apply_yaw_to_frame(frame, np.radians(angle))
            # Check right-handedness: x cross y should equal z
            cross = np.cross(rotated.x_axis, rotated.y_axis)
            np.testing.assert_array_almost_equal(cross, rotated.up_normal)
