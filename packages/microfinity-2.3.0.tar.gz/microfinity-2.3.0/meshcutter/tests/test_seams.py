"""Tests for meshcutter.cutter.seams module."""

import pytest

try:
    import cadquery as cq
    from meshcutter.cutter.seams import (
        generate_corner_plug,
        generate_inner_corner_fillet,
        generate_intercell_channels,
    )

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False
    pytest.skip("CadQuery not available", allow_module_level=True)


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerateCornerPlug:
    """Test generate_corner_plug function."""

    def test_basic_generation(self):
        """Basic corner plug generation."""
        # Z levels for channel profile
        z0, z1, z2, z3 = -4.75, -2.35, -0.55, 0.25
        top_chamf = 2.4
        bot_chamf = 0.8
        straight = 1.8

        plug = generate_corner_plug(
            x_pos=0.0,
            y_pos=0.0,
            z0=z0,
            z1=z1,
            z2=z2,
            z3=z3,
            top_chamf_vert=top_chamf,
            bot_chamf_vert=bot_chamf,
            straight_vert=straight,
        )
        assert plug is not None
        assert isinstance(plug, cq.Workplane)

    def test_different_positions(self):
        """Corner plug at different positions."""
        z0, z1, z2, z3 = -4.75, -2.35, -0.55, 0.25

        plug1 = generate_corner_plug(0, 0, z0, z1, z2, z3, 2.4, 0.8, 1.8)
        plug2 = generate_corner_plug(10, 20, z0, z1, z2, z3, 2.4, 0.8, 1.8)

        assert plug1 is not None
        assert plug2 is not None


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerateInnerCornerFillet:
    """Test generate_inner_corner_fillet function."""

    def test_basic_generation(self):
        """Basic inner corner fillet generation."""
        z0, z1, z2, z3 = -4.75, -2.35, -0.55, 0.25

        fillet = generate_inner_corner_fillet(
            corner_x=10.0,
            corner_y=10.0,
            arc_center_x=6.0,
            arc_center_y=6.0,
            z0=z0,
            z1=z1,
            z2=z2,
            z3=z3,
            base_radius=4.0,
            n_arc_points=8,
        )
        assert fillet is not None
        assert isinstance(fillet, cq.Workplane)

    def test_different_arc_centers(self):
        """Fillet with different arc center positions."""
        z0, z1, z2, z3 = -4.75, -2.35, -0.55, 0.25

        # Arc center to the right of corner
        fillet1 = generate_inner_corner_fillet(10, 10, 14, 10, z0, z1, z2, z3)
        # Arc center above corner
        fillet2 = generate_inner_corner_fillet(10, 10, 10, 14, z0, z1, z2, z3)

        assert fillet1 is not None
        assert fillet2 is not None


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerateIntercellChannels:
    """Test generate_intercell_channels function."""

    def test_empty_list(self):
        """Empty list returns None."""
        result = generate_intercell_channels([])
        assert result is None

    def test_single_cell(self):
        """Single cell returns None."""
        result = generate_intercell_channels([(0, 0)])
        assert result is None

    def test_two_cells_horizontal(self):
        """Two cells side by side creates channel."""
        cell_centers = [(0, 0), (42, 0)]
        channels = generate_intercell_channels(cell_centers, pitch=42)
        assert channels is not None
        assert isinstance(channels, cq.Workplane)

    def test_two_cells_vertical(self):
        """Two cells stacked creates channel."""
        cell_centers = [(0, 0), (0, 42)]
        channels = generate_intercell_channels(cell_centers, pitch=42)
        assert channels is not None

    def test_2x2_grid(self):
        """2x2 grid creates intersecting channels."""
        cell_centers = [(0, 0), (42, 0), (0, 42), (42, 42)]
        channels = generate_intercell_channels(cell_centers, pitch=42)
        assert channels is not None

    def test_with_footprint_bounds(self):
        """Channels clipped to footprint bounds."""
        cell_centers = [(0, 0), (42, 0), (0, 42), (42, 42)]
        bounds = (-10, -10, 52, 52)  # Slightly larger than cells
        channels = generate_intercell_channels(cell_centers, pitch=42, footprint_bounds=bounds)
        assert channels is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
