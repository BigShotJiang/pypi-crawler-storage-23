"""Integration smoke tests for replace-base pipeline.

Minimal E2E tests to verify pipeline works end-to-end.
Run in CAD lane only (requires full dependency stack).
"""

import pytest
import numpy as np

# Skip entire module if CAD dependencies not available
# Use exc_type so broken installs fail instead of silently skip
pytest.importorskip("trimesh", exc_type=ModuleNotFoundError)
pytest.importorskip("shapely", exc_type=ModuleNotFoundError)
pytest.importorskip("cadquery", exc_type=ModuleNotFoundError)

import trimesh
import cadquery as cq
from meshcutter.detection.footprint import BottomFrame, detect_bottom_frame
from meshcutter.pipeline import replace_base_pipeline


def create_hollow_box_cadquery(
    outer_size: float = 42.0,
    outer_height: float = 50.0,
    wall_thickness: float = 2.0,
    floor_thickness: float = 5.0,
) -> trimesh.Trimesh:
    """Create a hollow box using CadQuery for deterministic results.

    Uses CadQuery boolean operations (OCP backend) instead of trimesh booleans
    to avoid backend variability issues.

    Args:
        outer_size: Outer X/Y dimension (square footprint)
        outer_height: Total outer height
        wall_thickness: Thickness of walls
        floor_thickness: Thickness of floor (from bottom)

    Returns:
        Trimesh object representing the hollow box
    """
    import tempfile
    import os

    inner_size = outer_size - 2 * wall_thickness
    inner_height = outer_height - floor_thickness

    # Create outer box
    outer = cq.Workplane("XY").box(outer_size, outer_size, outer_height)

    # Create inner void (positioned to leave floor_thickness at bottom)
    inner = cq.Workplane("XY").box(inner_size, inner_size, inner_height).translate((0, 0, floor_thickness))

    # Subtract to create hollow box
    hollow_cq = outer.cut(inner)

    # Convert to trimesh via temporary STL file (OCP doesn't support BytesIO)
    with tempfile.NamedTemporaryFile(suffix=".stl", delete=False) as tmp:
        tmp_path = tmp.name

    try:
        hollow_cq.val().exportStl(tmp_path, tolerance=0.01, angularTolerance=0.1)
        mesh = trimesh.load(tmp_path, file_type="stl")
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)

    return mesh


class TestPipelineSmokeSolidBox:
    """Smoke test: Solid box mesh (no interior void)."""

    def test_solid_box_pipeline_does_not_crash(self):
        """Pipeline runs without error on solid box."""
        # Create solid box
        box = trimesh.creation.box(extents=[42, 42, 50])  # 1U footprint

        # Detect frame
        frame = detect_bottom_frame(box)
        assert frame is not None

        # Extract footprint
        from meshcutter.detection.footprint import extract_footprint

        footprint = extract_footprint(box, frame)
        assert footprint is not None

        # Run pipeline (this should not crash)
        result = replace_base_pipeline(
            input_mesh=box,
            footprint=footprint,
            frame=frame,
            micro_divisions=4,
            deck_mode="auto",  # Should detect no deck needed (no interior void)
        )

        # Assert basics
        assert result is not None
        assert isinstance(result, trimesh.Trimesh)
        assert len(result.vertices) > 0
        assert len(result.faces) > 0

    def test_solid_box_output_has_reasonable_bounds(self):
        """Output mesh has sane bounds."""
        box = trimesh.creation.box(extents=[42, 42, 50])

        frame = detect_bottom_frame(box)
        from meshcutter.detection.footprint import extract_footprint

        footprint = extract_footprint(box, frame)

        result = replace_base_pipeline(
            input_mesh=box,
            footprint=footprint,
            frame=frame,
            micro_divisions=4,
            deck_mode="auto",
        )

        # Bounds should be similar to input (not wildly different)
        bounds = result.bounds
        assert bounds[0][0] < bounds[1][0]  # x_min < x_max
        assert bounds[0][1] < bounds[1][1]  # y_min < y_max
        assert bounds[0][2] < bounds[1][2]  # z_min < z_max

        # Roughly 1U footprint
        x_size = bounds[1][0] - bounds[0][0]
        y_size = bounds[1][1] - bounds[0][1]
        assert 40 < x_size < 50, f"X size {x_size} not in reasonable range"
        assert 40 < y_size < 50, f"Y size {y_size} not in reasonable range"


class TestPipelineSmokeHollowBox:
    """Smoke test: Hollow box mesh (interior void - should trigger deck)."""

    def test_hollow_box_pipeline_does_not_crash(self):
        """Pipeline runs without error on hollow box."""
        # Create hollow box using CadQuery for deterministic results
        hollow = create_hollow_box_cadquery(
            outer_size=42.0,
            outer_height=50.0,
            wall_thickness=2.0,
            floor_thickness=4.0,
        )

        # Detect frame
        frame = detect_bottom_frame(hollow)
        assert frame is not None

        # Extract footprint
        from meshcutter.detection.footprint import extract_footprint

        footprint = extract_footprint(hollow, frame)
        assert footprint is not None

        # Run pipeline
        result = replace_base_pipeline(
            input_mesh=hollow,
            footprint=footprint,
            frame=frame,
            micro_divisions=4,
            deck_mode="auto",  # Should detect deck needed
        )

        # Assert basics
        assert result is not None
        assert isinstance(result, trimesh.Trimesh)
        assert len(result.vertices) > 0
        assert len(result.faces) > 0

    def test_hollow_box_has_deck_if_solid_below(self):
        """Hollow box with solid floor gets deck slab."""
        # Create box with bottom floor but hollow above
        hollow = create_hollow_box_cadquery(
            outer_size=42.0,
            outer_height=50.0,
            wall_thickness=2.0,
            floor_thickness=5.0,
        )

        frame = detect_bottom_frame(hollow)
        from meshcutter.detection.footprint import extract_footprint

        footprint = extract_footprint(hollow, frame)

        result = replace_base_pipeline(
            input_mesh=hollow,
            footprint=footprint,
            frame=frame,
            micro_divisions=4,
            deck_mode="auto",
        )

        # Output should exist and have volume
        assert result is not None
        assert result.volume > 0

        # Should have reasonable height
        z_min = result.vertices[:, 2].min()
        z_max = result.vertices[:, 2].max()
        height = z_max - z_min
        assert 40 < height < 60, f"Height {height} not in reasonable range"


@pytest.mark.skip(reason="Manual verification only - expensive")
def test_manual_visualization_smoke():
    """Manual test for visualization - not run in CI.

    Uncomment and run locally to visually verify output.
    """
    box = trimesh.creation.box(extents=[42, 42, 50])
    frame = detect_bottom_frame(box)
    from meshcutter.detection.footprint import extract_footprint

    footprint = extract_footprint(box, frame)

    result = replace_base_pipeline(
        input_mesh=box,
        footprint=footprint,
        frame=frame,
        micro_divisions=4,
        deck_mode="auto",
    )

    # Export for manual inspection
    result.export("/tmp/smoke_test_output.stl")
    print("Exported to /tmp/smoke_test_output.stl")
