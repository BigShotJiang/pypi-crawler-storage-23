#! /usr/bin/env python3
#
# Integration tests for meshcutter
#
# These tests exercise the full pipeline from mesh loading to boolean operations.
#

import pytest

# Mark all tests in this module as integration tests
pytestmark = pytest.mark.integration
import numpy as np
import trimesh
import tempfile
from pathlib import Path

from meshcutter.detection.footprint import detect_bottom_frame, extract_footprint
from meshcutter.mesh.grid import generate_grid_mask, compute_pitch
from meshcutter.cutter.base import generate_cutter
from meshcutter.mesh.boolean import (
    boolean_difference,
    check_manifold3d_available,
    BooleanError,
)
from meshcutter.io.loader import load_mesh
from meshcutter.io.exporter import export_stl


def create_gridfinity_box(
    units_x: int = 1,
    units_y: int = 1,
    height: float = 20.0,
) -> trimesh.Trimesh:
    """
    Create a simplified gridfinity-like box for testing.

    Args:
        units_x: Grid units in X
        units_y: Grid units in Y
        height: Height of box in mm

    Returns:
        Trimesh box with dimensions matching gridfinity grid
    """
    size_x = units_x * 42.0
    size_y = units_y * 42.0

    box = trimesh.creation.box(extents=[size_x, size_y, height])
    # Position so bottom is at z=0
    box.apply_translation([size_x / 2, size_y / 2, height / 2])

    return box


class TestFullPipeline:
    """Integration tests for the full meshcut pipeline."""

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_1x1_quarter_grid(self):
        """Test full pipeline on 1x1 box with quarter-grid divisions."""
        # Create test mesh
        mesh = create_gridfinity_box(units_x=1, units_y=1, height=20.0)
        original_volume = mesh.volume

        # Detect bottom
        frame = detect_bottom_frame(mesh, force_z_up=True)
        assert frame.z_min == pytest.approx(0.0, abs=0.1)

        # Extract footprint
        footprint = extract_footprint(mesh, frame)
        assert footprint.area > 0

        # Generate grid mask
        pitch = compute_pitch(4)  # Quarter-grid
        grid_mask = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=1.8,
            clearance=0.15,
        )
        assert grid_mask.area > 0

        # Generate cutter
        cutter = generate_cutter(
            grid_mask=grid_mask,
            frame=frame,
            depth=4.75,
        )
        assert len(cutter.faces) > 0

        # Boolean difference
        result = boolean_difference(mesh, cutter, repair=False)

        # Verify result
        assert result.mesh is not None
        assert len(result.mesh.faces) > 0
        assert result.mesh.is_watertight
        # Volume should decrease (we removed material)
        assert result.mesh.volume < original_volume

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_2x3_half_grid(self):
        """Test full pipeline on 2x3 box with half-grid divisions."""
        mesh = create_gridfinity_box(units_x=2, units_y=3, height=25.0)
        original_volume = mesh.volume

        frame = detect_bottom_frame(mesh, force_z_up=True)
        footprint = extract_footprint(mesh, frame)

        pitch = compute_pitch(2)  # Half-grid
        grid_mask = generate_grid_mask(
            footprint=footprint,
            pitch=pitch,
            slot_width=1.8,
            clearance=0.15,
        )

        cutter = generate_cutter(
            grid_mask=grid_mask,
            frame=frame,
            depth=4.75,
        )

        result = boolean_difference(mesh, cutter, repair=False)

        assert result.mesh.is_watertight
        assert result.mesh.volume < original_volume

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_stl_round_trip(self):
        """Test saving and loading STL files."""
        mesh = create_gridfinity_box(units_x=1, units_y=1, height=15.0)

        with tempfile.TemporaryDirectory() as tmpdir:
            stl_path = Path(tmpdir) / "test.stl"

            # Export
            export_stl(mesh, stl_path)
            assert stl_path.exists()

            # Load
            loaded = load_mesh(stl_path)

            # Verify
            assert len(loaded.faces) == len(mesh.faces)
            assert loaded.volume == pytest.approx(mesh.volume, rel=0.01)

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_phase_determinism(self):
        """Grid cuts should be deterministic with same phase."""
        mesh = create_gridfinity_box(units_x=2, units_y=2, height=20.0)

        def run_pipeline(phase_x, phase_y):
            frame = detect_bottom_frame(mesh, force_z_up=True)
            footprint = extract_footprint(mesh, frame)
            grid_mask = generate_grid_mask(
                footprint=footprint,
                pitch=compute_pitch(4),
                slot_width=1.8,
                clearance=0.15,
                phase_x=phase_x,
                phase_y=phase_y,
            )
            cutter = generate_cutter(grid_mask, frame, depth=4.75)
            result = boolean_difference(mesh, cutter, repair=False)
            return result.mesh.volume

        # Run twice with same phase
        vol1 = run_pipeline(0.0, 0.0)
        vol2 = run_pipeline(0.0, 0.0)

        assert vol1 == pytest.approx(vol2, rel=0.001)

        # Different phase should give different result
        vol3 = run_pipeline(5.0, 5.0)
        # Could be same or different depending on mesh, but pipeline should work
        assert vol3 > 0


class TestInvariants:
    """Tests for geometric invariants."""

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_volume_decreases(self):
        """Boolean difference should decrease volume."""
        mesh = create_gridfinity_box(units_x=1, units_y=1, height=20.0)
        original_volume = mesh.volume

        frame = detect_bottom_frame(mesh, force_z_up=True)
        footprint = extract_footprint(mesh, frame)
        grid_mask = generate_grid_mask(
            footprint=footprint,
            pitch=compute_pitch(4),
            slot_width=1.8,
        )
        cutter = generate_cutter(grid_mask, frame, depth=4.75)
        result = boolean_difference(mesh, cutter, repair=False)

        assert result.mesh.volume < original_volume

    @pytest.mark.skipif(
        not check_manifold3d_available(),
        reason="manifold3d not installed",
    )
    def test_result_is_watertight(self):
        """Result mesh should be watertight if input was."""
        mesh = create_gridfinity_box(units_x=1, units_y=1, height=20.0)
        assert mesh.is_watertight

        frame = detect_bottom_frame(mesh, force_z_up=True)
        footprint = extract_footprint(mesh, frame)
        grid_mask = generate_grid_mask(
            footprint=footprint,
            pitch=compute_pitch(4),
            slot_width=1.8,
        )
        cutter = generate_cutter(grid_mask, frame, depth=4.75)
        result = boolean_difference(mesh, cutter, repair=False)

        assert result.mesh.is_watertight
