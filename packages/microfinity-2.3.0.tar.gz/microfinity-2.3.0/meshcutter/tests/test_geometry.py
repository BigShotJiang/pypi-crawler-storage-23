"""Tests for meshcutter.cutter.geometry module."""

import pytest

from meshcutter.cutter.geometry import (
    quantize,
    quantize_point,
    uniquify_points,
    get_grid_lines,
    compute_midpoints,
    is_point_in_bounds,
    offset_point,
    compute_distance,
    snap_to_grid,
)


class TestQuantize:
    """Test quantize function."""

    def test_quantize_basic(self):
        """Basic quantization."""
        assert quantize(10.05, 0.1) == pytest.approx(10.1, abs=1e-9)
        assert quantize(10.04, 0.1) == pytest.approx(10.0, abs=1e-9)

    def test_quantize_default_precision(self):
        """Default precision of 0.1."""
        # Use values that don't suffer from floating point precision issues
        assert quantize(5.15) == pytest.approx(5.2, abs=1e-9)
        assert quantize(5.14) == pytest.approx(5.1, abs=1e-9)

    def test_quantize_negative(self):
        """Quantize negative values with half-away-from-zero."""
        assert quantize(-10.05, 0.1) == pytest.approx(-10.1, abs=1e-9)
        assert quantize(-10.04, 0.1) == pytest.approx(-10.0, abs=1e-9)

    def test_quantize_zero(self):
        """Quantize zero."""
        assert quantize(0.0, 0.1) == 0.0

    def test_quantize_different_precision(self):
        """Different precision values."""
        assert quantize(10.05, 1.0) == 10.0
        assert quantize(10.5, 1.0) == 11.0
        assert quantize(10.05, 0.01) == 10.05

    def test_quantize_half_boundary(self):
        """Test half-away-from-zero at boundary."""
        assert quantize(0.05, 0.1) == 0.1  # Positive rounds up
        assert quantize(-0.05, 0.1) == -0.1  # Negative rounds away from zero


class TestQuantizePoint:
    """Test quantize_point function."""

    def test_quantize_point_basic(self):
        """Basic point quantization."""
        result = quantize_point(10.05, 20.04)
        assert result[0] == pytest.approx(10.1, abs=1e-9)
        assert result[1] == pytest.approx(20.0, abs=1e-9)


class TestUniquifyPoints:
    """Test uniquify_points function."""

    def test_remove_duplicates(self):
        """Remove duplicate points."""
        points = [(0.0, 0.0), (0.0, 0.0), (10.0, 10.0)]
        result = uniquify_points(points)
        assert len(result) == 2
        assert (0.0, 0.0) in result
        assert (10.0, 10.0) in result

    def test_no_duplicates(self):
        """Handle points with no duplicates."""
        points = [(0.0, 0.0), (10.0, 10.0), (20.0, 20.0)]
        result = uniquify_points(points)
        assert len(result) == 3

    def test_empty_list(self):
        """Handle empty list."""
        result = uniquify_points([])
        assert result == []


class TestGetGridLines:
    """Test get_grid_lines function."""

    def test_basic_grid(self):
        """Extract grid lines from points."""
        points = [(0.0, 0.0), (10.0, 0.0), (0.0, 10.0), (10.0, 10.0)]
        xs, ys = get_grid_lines(points)
        assert xs == [0.0, 10.0]
        assert ys == [0.0, 10.0]

    def test_unsorted_points(self):
        """Handle unsorted points."""
        points = [(10.0, 10.0), (0.0, 0.0), (10.0, 0.0), (0.0, 10.0)]
        xs, ys = get_grid_lines(points)
        assert xs == [0.0, 10.0]
        assert ys == [0.0, 10.0]


class TestComputeMidpoints:
    """Test compute_midpoints function."""

    def test_basic_midpoints(self):
        """Compute midpoints."""
        coords = [0.0, 10.0, 20.0]
        result = compute_midpoints(coords)
        assert result == [5.0, 15.0]

    def test_single_midpoint(self):
        """Single midpoint."""
        coords = [0.0, 10.0]
        result = compute_midpoints(coords)
        assert result == [5.0]

    def test_empty_list(self):
        """Empty list returns empty."""
        result = compute_midpoints([])
        assert result == []

    def test_single_element(self):
        """Single element returns empty."""
        result = compute_midpoints([5.0])
        assert result == []


class TestIsPointInBounds:
    """Test is_point_in_bounds function."""

    def test_inside(self):
        """Point inside bounds."""
        assert is_point_in_bounds(5.0, 5.0, (0.0, 0.0, 10.0, 10.0))

    def test_on_boundary(self):
        """Point on boundary."""
        assert is_point_in_bounds(0.0, 5.0, (0.0, 0.0, 10.0, 10.0))
        assert is_point_in_bounds(10.0, 5.0, (0.0, 0.0, 10.0, 10.0))

    def test_outside(self):
        """Point outside bounds."""
        assert not is_point_in_bounds(15.0, 5.0, (0.0, 0.0, 10.0, 10.0))
        assert not is_point_in_bounds(5.0, 15.0, (0.0, 0.0, 10.0, 10.0))


class TestOffsetPoint:
    """Test offset_point function."""

    def test_basic_offset(self):
        """Basic offset."""
        result = offset_point(0.0, 0.0, 5.0, 10.0)
        assert result == (5.0, 10.0)

    def test_negative_offset(self):
        """Negative offset."""
        result = offset_point(10.0, 10.0, -5.0, -5.0)
        assert result == (5.0, 5.0)


class TestComputeDistance:
    """Test compute_distance function."""

    def test_basic_distance(self):
        """Basic distance calculation."""
        result = compute_distance((0.0, 0.0), (3.0, 4.0))
        assert result == 5.0

    def test_same_point(self):
        """Distance to same point is zero."""
        result = compute_distance((5.0, 5.0), (5.0, 5.0))
        assert result == 0.0


class TestSnapToGrid:
    """Test snap_to_grid function."""

    def test_basic_snap(self):
        """Basic snapping."""
        assert snap_to_grid(10.4, 1.0) == 10.0
        assert snap_to_grid(10.6, 1.0) == 11.0

    def test_already_on_grid(self):
        """Value already on grid."""
        assert snap_to_grid(10.0, 1.0) == 10.0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
