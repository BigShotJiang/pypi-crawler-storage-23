"""Geometry sanity tests for pipeline operations.

Tests core geometry operations with real data to ensure correctness.
"""

import pytest
import numpy as np

# Skip if dependencies not available
trimesh = pytest.importorskip("trimesh")
shapely = pytest.importorskip("shapely")
from shapely.geometry import Polygon

from meshcutter.pipeline.polygons import (
    ensure_single_polygon,
    clean_polygon,
    slice_to_material_polygon,
)
from meshcutter.pipeline.deck import generate_deck_slab


class TestSliceToMaterialPolygon:
    """Test slice extraction returns polygons in correct coordinate frame."""

    def test_slice_box_at_mid_height(self):
        """Slice a box at mid-height returns correct polygon bounds."""
        # Create a box centered at origin, 10x10x10
        box = trimesh.creation.box(extents=[10, 10, 10])

        # Slice at z=0 (mid-height)
        poly = slice_to_material_polygon(box, z=0.0, min_area=1.0)

        assert poly is not None
        assert poly.is_valid

        # Should be approximately 10x10 square
        bounds = poly.bounds
        width = bounds[2] - bounds[0]
        height = bounds[3] - bounds[1]

        assert 9.5 < width < 10.5, f"Expected width ~10, got {width}"
        assert 9.5 < height < 10.5, f"Expected height ~10, got {height}"

    def test_slice_preserves_coordinates(self):
        """Slice returns polygon in original mesh coordinates (not centered)."""
        # Create box offset from origin
        box = trimesh.creation.box(extents=[10, 10, 10])
        box.apply_translation([20, 30, 0])  # Offset by (20, 30)

        # Slice at z=0
        poly = slice_to_material_polygon(box, z=0.0, min_area=1.0)

        assert poly is not None
        bounds = poly.bounds

        # Bounds should be centered around (20, 30), not (0, 0)
        center_x = (bounds[0] + bounds[2]) / 2
        center_y = (bounds[1] + bounds[3]) / 2

        assert 19 < center_x < 21, f"Expected center x ~20, got {center_x}"
        assert 29 < center_y < 31, f"Expected center y ~30, got {center_y}"

    def test_slice_empty_returns_none(self):
        """Slicing empty space returns None."""
        box = trimesh.creation.box(extents=[10, 10, 10])

        # Slice well above the box
        poly = slice_to_material_polygon(box, z=100.0)

        assert poly is None


class TestEnsureSinglePolygon:
    """Test MultiPolygon/GeometryCollection handling."""

    def test_polygon_passthrough(self):
        """Valid Polygon passes through unchanged."""
        poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])

        result = ensure_single_polygon(poly)

        assert result is poly

    def test_multipolygon_returns_largest(self):
        """MultiPolygon returns largest component."""
        from shapely.geometry import MultiPolygon

        # Two disjoint squares
        small = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
        large = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])

        multi = MultiPolygon([small, large])

        result = ensure_single_polygon(multi)

        assert result == large  # Should return the larger one

    def test_geometry_collection_extracts_polygons(self):
        """GeometryCollection extracts polygon components."""
        from shapely.geometry import GeometryCollection, LineString

        poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])
        line = LineString([(0, 0), (5, 5)])

        collection = GeometryCollection([line, poly])

        result = ensure_single_polygon(collection)

        assert result == poly

    def test_empty_returns_none(self):
        """Empty geometry returns None."""
        empty = Polygon([])

        result = ensure_single_polygon(empty)

        assert result is None


class TestCleanPolygon:
    """Test polygon cleaning with make_valid and buffer(0)."""

    def test_valid_polygon_unchanged(self):
        """Valid polygon passes through."""
        poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])
        assert poly.is_valid

        result = clean_polygon(poly)

        assert result == poly

    def test_self_intersecting_gets_cleaned(self):
        """Self-intersecting polygon gets repaired."""
        # Self-intersecting bowtie shape
        bowtie = Polygon([(0, 0), (10, 10), (10, 0), (0, 10)])
        assert not bowtie.is_valid

        # Cast to Any to bypass type checker - we know this is the test intent
        from typing import Any

        result = clean_polygon(bowtie)  # type: ignore

        assert result is not None
        assert result.is_valid

    def test_none_returns_none(self):
        """None input returns None."""
        result = clean_polygon(None)  # type: ignore
        assert result is None


class TestGenerateDeckSlab:
    """Test deck slab generation."""

    def test_deck_drops_holes(self):
        """Deck slab uses exterior only, drops holes."""
        # Polygon with hole (donut shape)
        exterior = [(0, 0), (10, 0), (10, 10), (0, 10)]
        hole = [(3, 3), (3, 7), (7, 7), (7, 3)]
        poly_with_hole = Polygon(exterior, [hole])

        assert len(poly_with_hole.interiors) == 1  # Has one hole

        deck = generate_deck_slab(
            poly_with_hole,
            z_join=5.0,
            thickness=0.8,
            overlap=0.05,
        )

        # Deck should be solid (no holes)
        # Check it's valid and has volume
        assert deck is not None
        assert deck.volume > 0

        # The deck bounds should match the exterior, not have interior void
        # Rough check: deck area at slice should be ~100 (10x10), not ~64 (100-36)
        deck_poly = slice_to_material_polygon(deck, z=5.0)
        if deck_poly is not None:
            assert deck_poly.area > 90  # Should be close to 100, not 64

    def test_deck_positioning(self):
        """Deck is positioned correctly relative to z_join."""
        poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])

        deck = generate_deck_slab(
            poly,
            z_join=5.0,
            thickness=0.8,
            overlap=0.05,
        )

        # Deck should span [z_join - thickness - overlap, z_join + overlap]
        # = [5.0 - 0.8 - 0.05, 5.0 + 0.05] = [4.15, 5.05]
        z_min = deck.vertices[:, 2].min()
        z_max = deck.vertices[:, 2].max()

        assert 4.1 < z_min < 4.2, f"Expected z_min ~4.15, got {z_min}"
        assert 5.0 < z_max < 5.1, f"Expected z_max ~5.05, got {z_max}"

    def test_empty_polygon_raises(self):
        """Empty polygon raises ValueError."""
        empty = Polygon([])

        with pytest.raises(ValueError):
            generate_deck_slab(empty, z_join=5.0)


class TestPolygonCleaningPipeline:
    """Integration test: full cleaning pipeline with edge cases."""

    def test_complex_invalid_geometry(self):
        """Complex invalid geometry gets cleaned properly."""
        # Create a polygon with various issues
        from shapely.geometry import MultiPolygon

        # Overlapping polygons that create invalid union
        p1 = Polygon([(0, 0), (5, 0), (5, 5), (0, 5)])
        p2 = Polygon([(3, 3), (8, 3), (8, 8), (3, 8)])  # Overlaps with p1

        # Union should be valid
        union = p1.union(p2)
        assert union.is_valid

        # Clean should return the same valid polygon
        cleaned = clean_polygon(union)  # type: ignore
        assert cleaned is not None
        assert cleaned.is_valid
        assert cleaned.area > p1.area  # Should be larger than single square
        assert cleaned.area > p2.area
