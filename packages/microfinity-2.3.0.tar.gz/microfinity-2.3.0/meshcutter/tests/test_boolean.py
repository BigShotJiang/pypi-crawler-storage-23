#! /usr/bin/env python3
#
# Tests for meshcutter.core.boolean
#

import pytest
import numpy as np

# Skip if trimesh not available
trimesh = pytest.importorskip("trimesh")

from meshcutter.mesh.boolean import (
    repair_mesh,
    validate_boolean_inputs,
    check_manifold3d_available,
    check_pymeshlab_available,
    get_available_engines,
    BooleanError,
)
from meshcutter.mesh.diagnostics import get_mesh_diagnostics


def create_test_box(
    size: float = 20.0,
    center: tuple = (0, 0, 0),
) -> trimesh.Trimesh:
    """Create a test box mesh."""
    box = trimesh.creation.box(extents=[size, size, size])
    box.apply_translation(center)
    return box


class TestRepairMesh:
    """Tests for repair_mesh function."""

    def test_clean_mesh_unchanged(self):
        """Clean mesh should remain valid after repair."""
        box = create_test_box()
        original_face_count = len(box.faces)

        repaired = repair_mesh(box)

        assert repaired.is_watertight
        assert len(repaired.faces) == original_face_count

    def test_returns_copy(self):
        """Should return a new mesh, not modify original."""
        box = create_test_box()
        original_vertices = box.vertices.copy()

        repaired = repair_mesh(box)

        # Original should be unchanged
        np.testing.assert_array_equal(box.vertices, original_vertices)
        # Should be different object
        assert repaired is not box


class TestGetMeshDiagnostics:
    """Tests for get_mesh_diagnostics function."""

    def test_returns_expected_keys(self):
        """Should return dict with expected keys."""
        box = create_test_box()

        diag = get_mesh_diagnostics(box)

        assert "is_watertight" in diag
        assert "is_winding_consistent" in diag
        assert "euler_number" in diag
        assert "face_count" in diag
        assert "vertex_count" in diag
        assert "bounds_min" in diag
        assert "bounds_max" in diag
        assert "area" in diag

    def test_watertight_has_volume(self):
        """Watertight mesh should have volume."""
        box = create_test_box()

        diag = get_mesh_diagnostics(box)

        assert diag["is_watertight"] is True
        assert diag["volume"] is not None
        assert diag["volume"] > 0


class TestValidateBooleanInputs:
    """Tests for validate_boolean_inputs function."""

    def test_valid_inputs_no_warnings(self):
        """Valid watertight meshes should produce minimal warnings."""
        part = create_test_box(size=30, center=(0, 0, 0))
        cutter = create_test_box(size=10, center=(0, 0, 0))

        warnings = validate_boolean_inputs(part, cutter)

        # Should not warn about watertight or winding
        watertight_warnings = [w for w in warnings if "watertight" in w.lower()]
        assert len(watertight_warnings) == 0

    def test_non_intersecting_warning(self):
        """Non-intersecting meshes should produce warning."""
        part = create_test_box(size=10, center=(0, 0, 0))
        cutter = create_test_box(size=10, center=(100, 100, 100))

        warnings = validate_boolean_inputs(part, cutter)

        # Should warn about non-intersection
        intersect_warnings = [w for w in warnings if "intersect" in w.lower()]
        assert len(intersect_warnings) > 0


class TestEngineChecks:
    """Tests for engine availability checks."""

    def test_check_manifold3d_returns_bool(self):
        """check_manifold3d_available should return bool."""
        result = check_manifold3d_available()
        assert isinstance(result, bool)

    def test_check_pymeshlab_returns_bool(self):
        """check_pymeshlab_available should return bool."""
        result = check_pymeshlab_available()
        assert isinstance(result, bool)

    def test_get_available_engines_returns_list(self):
        """get_available_engines should return list."""
        engines = get_available_engines()
        assert isinstance(engines, list)
        # Should at least contain "blender" as fallback
        assert "blender" in engines


class TestBooleanError:
    """Tests for BooleanError exception."""

    def test_basic_error(self):
        """BooleanError should be raisable with message."""
        with pytest.raises(BooleanError) as exc_info:
            raise BooleanError("Test error")

        assert "Test error" in str(exc_info.value)

    def test_error_with_diagnostics(self):
        """BooleanError should store diagnostics."""
        diagnostics = {"key": "value"}

        try:
            raise BooleanError("Test", diagnostics=diagnostics)
        except BooleanError as e:
            assert e.diagnostics == diagnostics


class TestDiagnosticsImport:
    """Import sanity tests for diagnostics module."""

    def test_import_from_package(self):
        """get_mesh_diagnostics should be importable from meshcutter.mesh"""
        from meshcutter.mesh import get_mesh_diagnostics

        assert callable(get_mesh_diagnostics)

    def test_import_from_leaf(self):
        """get_mesh_diagnostics should be importable from leaf module"""
        from meshcutter.mesh.diagnostics import get_mesh_diagnostics

        assert callable(get_mesh_diagnostics)

    def test_functionality_via_package_import(self):
        """Function should work when imported from package"""
        from meshcutter.mesh import get_mesh_diagnostics

        box = trimesh.creation.box(extents=[10, 10, 10])
        diag = get_mesh_diagnostics(box)
        assert diag["is_watertight"] is True
        assert diag["volume"] is not None
