#! /usr/bin/env python3
#
# Tests for meshcutter.core.cutter
#

import pytest
import numpy as np

# Skip if dependencies not available
trimesh = pytest.importorskip("trimesh")
pytest.importorskip("shapely")
from shapely.geometry import box, Polygon, MultiPolygon

from meshcutter.detection.footprint import BottomFrame
from meshcutter.cutter.base import (
    generate_cutter,
    validate_cutter,
    estimate_cutter_bounds,
    COPLANAR_EPSILON,
)


def create_identity_frame(z_min: float = 0.0) -> BottomFrame:
    """Create a frame at origin with identity rotation."""
    return BottomFrame(
        origin=np.array([0.0, 0.0, z_min]),
        rotation=np.eye(3),
        z_min=z_min,
    )


class TestGenerateCutter:
    """Tests for generate_cutter function."""

    def test_simple_rectangle(self):
        """Simple rectangle should produce valid cutter mesh."""
        grid_mask = box(-10, -10, 10, 10)  # 20x20 square
        frame = create_identity_frame()
        depth = 5.0

        cutter = generate_cutter(grid_mask, frame, depth)

        assert cutter is not None
        assert len(cutter.faces) > 0
        assert len(cutter.vertices) > 0

    def test_cutter_z_extent(self):
        """Cutter should extend from z_min to z_min + depth (with epsilon=0)."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame(z_min=0.0)
        depth = 4.75

        cutter = generate_cutter(grid_mask, frame, depth, epsilon=0)

        bounds = cutter.bounds
        z_extent = bounds[1, 2] - bounds[0, 2]

        # Z extent should be approximately equal to depth
        assert z_extent == pytest.approx(depth, rel=0.01)
        # Bottom should be at z_min (0.0)
        assert bounds[0, 2] == pytest.approx(0.0, abs=0.01)
        # Top should be at z_min + depth
        assert bounds[1, 2] == pytest.approx(depth, abs=0.01)

    def test_cutter_bottom_at_frame_origin(self):
        """Cutter bottom should be at frame origin Z (with epsilon=0)."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame(z_min=5.0)
        depth = 4.75

        cutter = generate_cutter(grid_mask, frame, depth, epsilon=0)

        bounds = cutter.bounds
        # Bottom of cutter should be at z=5.0 (frame origin z / z_min)
        assert bounds[0, 2] == pytest.approx(5.0, abs=0.1)
        # Top should be at z_min + depth = 9.75
        assert bounds[1, 2] == pytest.approx(5.0 + depth, abs=0.1)

    def test_epsilon_extends_below_bottom(self):
        """Epsilon should extend cutter below the bottom plane."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame(z_min=0.0)
        depth = 4.75
        epsilon = 0.5

        cutter = generate_cutter(grid_mask, frame, depth, epsilon=epsilon)

        bounds = cutter.bounds
        # Bottom should be at z_min - epsilon = -0.5
        assert bounds[0, 2] == pytest.approx(-epsilon, abs=0.01)
        # Top should be at z_min + depth = 4.75
        assert bounds[1, 2] == pytest.approx(depth, abs=0.01)
        # Total extent should be depth + epsilon
        z_extent = bounds[1, 2] - bounds[0, 2]
        assert z_extent == pytest.approx(depth + epsilon, rel=0.01)

    def test_invalid_depth(self):
        """Zero or negative depth should raise ValueError."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame()

        with pytest.raises(ValueError):
            generate_cutter(grid_mask, frame, depth=0)

        with pytest.raises(ValueError):
            generate_cutter(grid_mask, frame, depth=-5)

    def test_invalid_epsilon(self):
        """Negative epsilon should raise ValueError."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame()

        with pytest.raises(ValueError):
            generate_cutter(grid_mask, frame, depth=5.0, epsilon=-0.1)

    def test_multipolygon_input(self):
        """Should handle MultiPolygon inputs."""
        poly1 = box(-20, -20, -5, 20)
        poly2 = box(5, -20, 20, 20)
        grid_mask = MultiPolygon([poly1, poly2])

        frame = create_identity_frame()
        depth = 4.75

        cutter = generate_cutter(grid_mask, frame, depth)

        assert cutter is not None
        assert len(cutter.faces) > 0

    def test_complex_polygon(self):
        """Should handle polygon with hole."""
        outer = [(-20, -20), (20, -20), (20, 20), (-20, 20)]
        inner = [(-5, -5), (-5, 5), (5, 5), (5, -5)]  # Hole (CCW)
        grid_mask = Polygon(outer, [inner])

        frame = create_identity_frame()
        depth = 4.75

        cutter = generate_cutter(grid_mask, frame, depth)

        assert cutter is not None
        assert len(cutter.faces) > 0


class TestValidateCutter:
    """Tests for validate_cutter function."""

    def test_returns_expected_keys(self):
        """Should return dict with expected keys."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame()
        cutter = generate_cutter(grid_mask, frame, depth=5.0)

        result = validate_cutter(cutter)

        assert "is_watertight" in result
        assert "is_winding_consistent" in result
        assert "face_count" in result
        assert "vertex_count" in result
        assert "bounds_min" in result
        assert "bounds_max" in result
        assert "volume" in result


class TestEstimateCutterBounds:
    """Tests for estimate_cutter_bounds function."""

    def test_estimates_bounds(self):
        """Should estimate reasonable bounds."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame()
        depth = 5.0

        estimate = estimate_cutter_bounds(grid_mask, frame, depth)

        assert "local_bounds_2d" in estimate
        assert "local_z_range" in estimate
        assert "world_min" in estimate
        assert "world_max" in estimate
        assert "grid_mask_area" in estimate
        assert "estimated_volume" in estimate

    def test_estimated_volume(self):
        """Estimated volume should be area * (depth + epsilon)."""
        grid_mask = box(-10, -10, 10, 10)  # Area = 400
        frame = create_identity_frame()
        depth = 5.0
        epsilon = COPLANAR_EPSILON

        estimate = estimate_cutter_bounds(grid_mask, frame, depth, epsilon=epsilon)

        expected_volume = 400.0 * (depth + epsilon)
        assert estimate["estimated_volume"] == pytest.approx(expected_volume, rel=0.01)

    def test_local_z_range(self):
        """Local Z range should be (-epsilon, depth)."""
        grid_mask = box(-10, -10, 10, 10)
        frame = create_identity_frame()
        depth = 5.0
        epsilon = 0.1

        estimate = estimate_cutter_bounds(grid_mask, frame, depth, epsilon=epsilon)

        assert estimate["local_z_range"] == (-epsilon, depth)
