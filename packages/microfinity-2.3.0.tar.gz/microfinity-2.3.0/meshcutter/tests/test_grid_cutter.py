"""Tests for meshcutter.cutter.grid_cutter module.

Phase 2d extraction tests for boundary fill and grid cutter generation functions.
Note: These tests mock CadQuery/trimesh but the module under test imports them
at the module level, so they must be installed to run these tests.
"""

from __future__ import annotations

import unittest
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

import pytest

# Skip entire module if CadQuery/trimesh are not available
try:
    import cadquery as cq
    import trimesh

    HAS_CADQUERY = True
except ImportError:
    HAS_CADQUERY = False

if not HAS_CADQUERY:
    pytest.skip(
        "CadQuery/trimesh not installed - skipping grid_cutter tests",
        allow_module_level=True,
    )


class TestGenerateBoundaryFill(unittest.TestCase):
    """Tests for generate_boundary_fill function."""

    @patch("meshcutter.cutter.grid_detection.cq")
    def test_empty_cell_centers_returns_none(self, mock_cq):
        """Boundary fill should return None for empty cell centers."""
        from meshcutter.cutter.grid_cutter import generate_boundary_fill

        result = generate_boundary_fill([])
        self.assertIsNone(result)

    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_single_cell_boundary_fill(self, mock_cq):
        """Boundary fill should create frame for single cell."""
        from meshcutter.cutter.grid_cutter import generate_boundary_fill

        # Mock the Workplane chain
        mock_box = MagicMock()
        mock_workplane = MagicMock()
        mock_workplane.box.return_value = mock_box
        mock_box.translate.return_value = mock_box
        mock_cq.Workplane.return_value = mock_workplane

        cell_centers = [(0, 0)]
        result = generate_boundary_fill(cell_centers)

        # Should create workplane and box
        mock_cq.Workplane.assert_called_with("XY")
        self.assertIsNotNone(result)

    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_boundary_fill_with_footprint_bounds(self, mock_cq):
        """Boundary fill should respect footprint bounds."""
        from meshcutter.cutter.grid_cutter import generate_boundary_fill

        mock_box = MagicMock()
        mock_workplane = MagicMock()
        mock_workplane.box.return_value = mock_box
        mock_box.translate.return_value = mock_box
        mock_cq.Workplane.return_value = mock_workplane

        cell_centers = [(0, 0), (42, 0)]
        footprint_bounds = (-50, -25, 50, 25)
        result = generate_boundary_fill(cell_centers, footprint_bounds=footprint_bounds)

        self.assertIsNotNone(result)


class TestApplyBottomEpsilonPreserveTop(unittest.TestCase):
    """Tests for apply_bottom_epsilon_preserve_top function."""

    def test_zero_epsilon_returns_early(self):
        """Function should return early for epsilon <= 0."""
        from meshcutter.cutter.grid_cutter import apply_bottom_epsilon_preserve_top

        mock_mesh = MagicMock()
        mock_mesh.vertices = [[0, 0, 0], [0, 0, 5]]

        # Should not raise or modify mesh when epsilon is 0
        apply_bottom_epsilon_preserve_top(mock_mesh, 0)
        # No assertions needed - just checking it doesn't crash

    def test_negative_epsilon_returns_early(self):
        """Function should return early for negative epsilon."""
        from meshcutter.cutter.grid_cutter import apply_bottom_epsilon_preserve_top

        mock_mesh = MagicMock()
        mock_mesh.vertices = [[0, 0, 0], [0, 0, 5]]

        # Should not raise or modify mesh when epsilon is negative
        apply_bottom_epsilon_preserve_top(mock_mesh, -0.1)
        # No assertions needed - just checking it doesn't crash

    def test_degenerate_height_raises(self):
        """Function should raise ValueError for degenerate mesh."""
        from meshcutter.cutter.grid_cutter import apply_bottom_epsilon_preserve_top

        mock_mesh = MagicMock()
        # All vertices at same Z - degenerate height
        mock_mesh.vertices = [[0, 0, 1.0], [0, 0, 1.0], [0, 0, 1.0]]

        with self.assertRaises(ValueError) as ctx:
            apply_bottom_epsilon_preserve_top(mock_mesh, 0.02)

        self.assertIn("Degenerate cutter height", str(ctx.exception))


class TestGenerateGridCutterCQ(unittest.TestCase):
    """Tests for generate_grid_cutter_cq function."""

    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_empty_cell_centers_raises(self, mock_cq):
        """Empty cell centers should raise ValueError."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_cq

        with self.assertRaises(ValueError) as ctx:
            generate_grid_cutter_cq([], MagicMock())

        self.assertIn("No cell centers provided", str(ctx.exception))

    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_single_cell_grid(self, mock_cq):
        """Should generate cutter for single cell."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_cq

        # Mock the cell cutter
        mock_cell_cutter = MagicMock()
        mock_solid = MagicMock()
        mock_cell_cutter.val.return_value = mock_solid
        mock_generate_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0)]
        result = generate_grid_cutter_cq(cell_centers, mock_generate_fn)

        mock_generate_fn.assert_called_once()
        self.assertIsNotNone(result)

    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_multiple_cells_fuse(self, mock_cq):
        """Should fuse multiple cell cutters."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_cq

        mock_cell_cutter = MagicMock()
        mock_solid = MagicMock()
        mock_solid.translate.return_value = mock_solid
        mock_solid.fuse.return_value = mock_solid
        mock_cell_cutter.val.return_value = mock_solid
        mock_generate_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0), (42, 0)]
        result = generate_grid_cutter_cq(cell_centers, mock_generate_fn)

        # Should translate twice (once per cell)
        self.assertEqual(mock_solid.translate.call_count, 2)


class TestGenerateGridCutterMeshes(unittest.TestCase):
    """Tests for generate_grid_cutter_meshes function."""

    @patch("meshcutter.cutter.grid_cutter.generate_intercell_channels")
    @patch("meshcutter.cutter.grid_cutter.cq_to_trimesh")
    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_empty_cell_centers_raises(self, mock_cq, mock_to_trimesh, mock_channels):
        """Empty cell centers should raise ValueError."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_meshes

        with self.assertRaises(ValueError) as ctx:
            generate_grid_cutter_meshes([], MagicMock())

        self.assertIn("No cell centers provided", str(ctx.exception))

    @patch("meshcutter.cutter.grid_cutter.generate_intercell_channels")
    @patch("meshcutter.cutter.grid_cutter.cq_to_trimesh")
    def test_single_cell_returns_list(self, mock_to_trimesh, mock_channels):
        """Should return list with single mesh for single cell."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_meshes

        mock_cell_cutter = MagicMock()
        mock_mesh = MagicMock()
        mock_mesh.vertices = [[0, 0, -5], [0, 0, 0]]
        mock_mesh.copy.return_value = mock_mesh
        mock_to_trimesh.return_value = mock_mesh
        mock_generate_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0)]
        result = generate_grid_cutter_meshes(cell_centers, mock_generate_fn, flip_z=False)

        self.assertEqual(len(result), 1)
        self.assertEqual(result[0], mock_mesh)

    @patch("meshcutter.cutter.grid_cutter.generate_intercell_channels")
    @patch("meshcutter.cutter.grid_cutter.cq_to_trimesh")
    def test_flip_z_transforms_vertices(self, mock_to_trimesh, mock_channels):
        """flip_z=True should transform vertices to positive Z."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_meshes
        import numpy as np

        mock_cell_cutter = MagicMock()
        # Create vertices with negative Z (typical CQ cutter orientation)
        vertices = np.array([[0, 0, -5.0], [0, 0, 0.25]])
        mock_mesh = MagicMock()
        mock_mesh.vertices = vertices
        mock_mesh.copy.return_value = mock_mesh
        mock_to_trimesh.return_value = mock_mesh
        mock_generate_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0)]
        result = generate_grid_cutter_meshes(cell_centers, mock_generate_fn, flip_z=True, epsilon=0.02)

        # Vertices should have been shifted
        self.assertTrue(np.any(vertices != [[0, 0, -5.0], [0, 0, 0.25]]))


class TestGenerateGridCutterMesh(unittest.TestCase):
    """Tests for generate_grid_cutter_mesh function."""

    @patch("meshcutter.cutter.grid_cutter.generate_grid_cutter_meshes")
    @patch("meshcutter.cutter.grid_cutter.cq_to_trimesh")
    @patch("meshcutter.cutter.grid_cutter.apply_bottom_epsilon_preserve_top")
    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_fast_mode_warning(self, mock_cq, mock_apply, mock_to_trimesh, mock_meshes):
        """fast_mode=True should emit UserWarning."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_mesh
        import warnings

        mock_cell_cutter = MagicMock()
        mock_mesh = MagicMock()
        mock_to_trimesh.return_value = mock_mesh
        mock_generate_cell_fn = MagicMock(return_value=mock_cell_cutter)
        mock_generate_grid_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0)]

        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            result = generate_grid_cutter_mesh(
                cell_centers,
                mock_generate_cell_fn,
                mock_generate_grid_fn,
                fast_mode=True,
            )
            self.assertEqual(len(w), 1)
            self.assertTrue(issubclass(w[0].category, UserWarning))
            self.assertIn("fast_mode", str(w[0].message))

    @patch("meshcutter.cutter.grid_cutter.cq_to_trimesh")
    @patch("meshcutter.cutter.grid_cutter.apply_bottom_epsilon_preserve_top")
    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_default_mode_uses_fusion(self, mock_cq, mock_apply, mock_to_trimesh):
        """Default mode should use CQ fusion path."""
        from meshcutter.cutter.grid_cutter import generate_grid_cutter_mesh

        mock_cell_cutter = MagicMock()
        mock_mesh = MagicMock()
        mock_to_trimesh.return_value = mock_mesh
        mock_generate_cell_fn = MagicMock(return_value=mock_cell_cutter)
        mock_generate_grid_fn = MagicMock(return_value=mock_cell_cutter)

        cell_centers = [(0, 0)]
        result = generate_grid_cutter_mesh(
            cell_centers,
            mock_generate_cell_fn,
            mock_generate_grid_fn,
            flip_z=True,
        )

        # Should call the grid cutter function
        mock_generate_grid_fn.assert_called_once()
        # Should apply epsilon transform
        mock_apply.assert_called_once()


class TestCqToTrimesh(unittest.TestCase):
    """Tests for cq_to_trimesh function."""

    @patch("meshcutter.cutter.grid_cutter.trimesh")
    @patch("meshcutter.cutter.grid_cutter.cq")
    def test_cq_to_trimesh_export(self, mock_cq, mock_trimesh):
        """Should export CQ object to STL and load with trimesh."""
        from meshcutter.cutter.grid_cutter import cq_to_trimesh

        mock_workplane = MagicMock()
        mock_mesh = MagicMock()
        mock_trimesh.load.return_value = mock_mesh

        result = cq_to_trimesh(mock_workplane, tol=0.01, ang_tol=0.1)

        # Should call CQ exporter
        mock_cq.exporters.export.assert_called_once()
        # Should load with trimesh
        mock_trimesh.load.assert_called_once()
        self.assertEqual(result, mock_mesh)


if __name__ == "__main__":
    unittest.main()
