"""Tests for meshcutter.cutter.foot_generator module."""

import pytest
import sys
from pathlib import Path

# Add parent to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

try:
    import cadquery as cq
    from meshcutter.cutter.foot_generator import (
        generate_1u_foot_cq,
        generate_micro_foot_cq,
        micro_foot_offsets,
        generate_extended_foot_cq,
    )

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False
    pytest.skip("CadQuery not available", allow_module_level=True)


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerate1uFoot:
    """Test generate_1u_foot_cq function."""

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_basic_generation(self):
        """Basic foot generation."""
        foot = generate_1u_foot_cq()
        assert foot is not None
        # Check that we got a Workplane back
        assert isinstance(foot, cq.Workplane)

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_cropped_vs_uncropped(self):
        """Cropped and uncropped versions."""
        cropped = generate_1u_foot_cq(cropped=True)
        uncropped = generate_1u_foot_cq(cropped=False)
        assert cropped is not None
        assert uncropped is not None


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerateMicroFoot:
    """Test generate_micro_foot_cq function."""

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_div2(self):
        """Micro foot with 2 divisions."""
        foot = generate_micro_foot_cq(micro_divisions=2)
        assert foot is not None
        assert isinstance(foot, cq.Workplane)

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_div4(self):
        """Micro foot with 4 divisions."""
        foot = generate_micro_foot_cq(micro_divisions=4)
        assert foot is not None
        assert isinstance(foot, cq.Workplane)

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_size_reduction(self):
        """Micro foot with size reduction."""
        foot = generate_micro_foot_cq(micro_divisions=4, size_reduction=0.5)
        assert foot is not None


class TestMicroFootOffsets:
    """Test micro_foot_offsets function (no CadQuery needed)."""

    def test_div1(self):
        """Single division returns single offset."""
        offsets = micro_foot_offsets(1)
        assert len(offsets) == 1
        assert offsets[0] == (0.0, 0.0)

    def test_div2(self):
        """2 divisions returns 4 offsets."""
        offsets = micro_foot_offsets(2)
        assert len(offsets) == 4
        # Check symmetry
        xs = [o[0] for o in offsets]
        ys = [o[1] for o in offsets]
        assert 10.5 in xs or -10.5 in xs  # 42/2 * 0.5

    def test_div4(self):
        """4 divisions returns 16 offsets."""
        offsets = micro_foot_offsets(4)
        assert len(offsets) == 16

    def test_custom_pitch(self):
        """Custom pitch value."""
        offsets = micro_foot_offsets(2, pitch=84.0)
        assert len(offsets) == 4
        # With 84mm pitch, offsets should be larger
        xs = [abs(o[0]) for o in offsets]
        assert max(xs) > 20  # Should be around 21


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGenerateExtendedFoot:
    """Test generate_extended_foot_cq function."""

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_basic_generation(self):
        """Basic extended foot generation."""
        foot = generate_extended_foot_cq()
        assert foot is not None
        assert isinstance(foot, cq.Workplane)

    @pytest.mark.xfail(reason="CQ sketch compatibility issue - needs refactor", strict=False)
    def test_with_overshoot(self):
        """Extended foot with overshoot."""
        foot = generate_extended_foot_cq(overshoot=2.0)
        assert foot is not None

    def test_cached(self):
        """Function is cached."""
        foot1 = generate_extended_foot_cq(overshoot=1.0)
        foot2 = generate_extended_foot_cq(overshoot=1.0)
        # Should return same object due to lru_cache
        assert foot1 is foot2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
