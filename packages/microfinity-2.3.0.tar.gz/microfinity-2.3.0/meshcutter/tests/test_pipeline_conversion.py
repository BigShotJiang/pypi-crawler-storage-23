"""Tests for meshcutter.pipeline.conversion module."""

import pytest
import numpy as np

# Skip if dependencies not available
trimesh = pytest.importorskip("trimesh")
pytest.importorskip("manifold3d")
pytest.importorskip("cadquery")

from meshcutter.pipeline.conversion import (
    trimesh_to_manifold,
    manifold_to_trimesh,
    manifold_intersection,
    cq_to_trimesh,
)


def test_trimesh_to_manifold_roundtrip():
    """Test trimesh -> manifold -> trimesh roundtrip preserves geometry."""
    # Create a simple box
    box = trimesh.creation.box(extents=[10, 10, 10])

    # Convert to manifold
    manifold = trimesh_to_manifold(box)
    assert manifold is not None

    # Convert back to trimesh
    result = manifold_to_trimesh(manifold)
    assert result is not None

    # Check vertex count preserved (approximately)
    assert len(result.vertices) == len(box.vertices)
    assert len(result.faces) == len(box.faces)


def test_manifold_intersection():
    """Test manifold intersection operation."""
    pytest.importorskip("manifold3d")
    import manifold3d

    # Create two overlapping boxes
    box1 = trimesh.creation.box(extents=[10, 10, 10])
    box2 = trimesh.creation.box(extents=[10, 10, 10])
    box2.apply_translation([5, 0, 0])  # Offset by 5 in X

    # Convert to manifolds
    m1 = trimesh_to_manifold(box1)
    m2 = trimesh_to_manifold(box2)

    # Compute intersection
    intersection = manifold_intersection(m1, m2)
    assert intersection is not None

    # Convert back and check
    result = manifold_to_trimesh(intersection)
    assert result.volume > 0  # Should have some volume


def test_cq_to_trimesh():
    """Test CadQuery to trimesh conversion."""
    import cadquery as cq

    # Create a simple CQ box
    cq_box = cq.Workplane("XY").box(10, 10, 10)

    # Convert to trimesh
    mesh = cq_to_trimesh(cq_box, tol=0.01, ang_tol=0.1)
    assert mesh is not None
    assert mesh.volume > 0

    # Check bounding box approximately correct
    bounds = mesh.bounds
    size = bounds[1] - bounds[0]
    assert 9 < size[0] < 11  # X dimension ~10
    assert 9 < size[1] < 11  # Y dimension ~10
    assert 9 < size[2] < 11  # Z dimension ~10
