#! /usr/bin/env python3
"""Tests for cutter profiles and profiled cutter generation."""

import numpy as np
import pytest
from shapely.geometry import box

from meshcutter.mesh.profile import (
    CutterProfile,
    ProfileSegment,
    create_rectangular_profile,
    create_gridfinity_baseplate_profile,
    create_gridfinity_box_profile,
    get_profile,
    GR_BASE_HEIGHT,
    PROFILE_RECTANGULAR,
    PROFILE_GRIDFINITY,
)
from meshcutter.cutter.base import generate_profiled_cutter
from meshcutter.detection.footprint import BottomFrame


class TestProfileSegment:
    """Tests for ProfileSegment."""

    def test_height(self):
        """Height should be z_end - z_start."""
        seg = ProfileSegment(z_start=1.0, z_end=3.0, inset_start=0.0, inset_end=1.0)
        assert seg.height == 2.0

    def test_inset_at_start(self):
        """Inset at z_start should equal inset_start."""
        seg = ProfileSegment(z_start=0.0, z_end=1.0, inset_start=0.5, inset_end=1.5)
        assert seg.inset_at(0.0) == pytest.approx(0.5)

    def test_inset_at_end(self):
        """Inset at z_end should equal inset_end."""
        seg = ProfileSegment(z_start=0.0, z_end=1.0, inset_start=0.5, inset_end=1.5)
        assert seg.inset_at(1.0) == pytest.approx(1.5)

    def test_inset_at_midpoint(self):
        """Inset at midpoint should be average of start and end."""
        seg = ProfileSegment(z_start=0.0, z_end=2.0, inset_start=0.0, inset_end=2.0)
        assert seg.inset_at(1.0) == pytest.approx(1.0)

    def test_inset_at_clamped(self):
        """Inset should be clamped to segment bounds."""
        seg = ProfileSegment(z_start=1.0, z_end=2.0, inset_start=0.0, inset_end=1.0)
        # Below segment
        assert seg.inset_at(0.5) == pytest.approx(0.0)
        # Above segment
        assert seg.inset_at(2.5) == pytest.approx(1.0)


class TestCutterProfile:
    """Tests for CutterProfile."""

    def test_total_height(self):
        """Total height should be z_end of last segment."""
        profile = CutterProfile(
            name="test",
            segments=[
                ProfileSegment(z_start=0.0, z_end=1.0, inset_start=0.0, inset_end=0.5),
                ProfileSegment(z_start=1.0, z_end=3.0, inset_start=0.5, inset_end=0.5),
            ],
        )
        assert profile.total_height == 3.0

    def test_max_inset(self):
        """Max inset should be maximum across all segments."""
        profile = CutterProfile(
            name="test",
            segments=[
                ProfileSegment(z_start=0.0, z_end=1.0, inset_start=0.0, inset_end=1.0),
                ProfileSegment(z_start=1.0, z_end=2.0, inset_start=1.0, inset_end=0.5),
            ],
        )
        assert profile.max_inset == 1.0

    def test_inset_at_finds_correct_segment(self):
        """inset_at should find the correct segment for a given Z."""
        profile = CutterProfile(
            name="test",
            segments=[
                ProfileSegment(z_start=0.0, z_end=1.0, inset_start=0.0, inset_end=1.0),
                ProfileSegment(z_start=1.0, z_end=2.0, inset_start=1.0, inset_end=1.0),
                ProfileSegment(z_start=2.0, z_end=3.0, inset_start=1.0, inset_end=2.0),
            ],
        )
        # In first segment
        assert profile.inset_at(0.5) == pytest.approx(0.5)
        # In second segment
        assert profile.inset_at(1.5) == pytest.approx(1.0)
        # In third segment
        assert profile.inset_at(2.5) == pytest.approx(1.5)

    def test_sample_z_levels_includes_boundaries(self):
        """Z levels should include all segment boundaries."""
        profile = create_gridfinity_baseplate_profile()
        z_levels = profile.sample_z_levels(n_slices=5)
        # Should include -epsilon, 0, and all segment boundaries
        assert z_levels[0] < 0  # epsilon
        assert 0.0 in z_levels or any(abs(z) < 0.001 for z in z_levels)


class TestRectangularProfile:
    """Tests for rectangular profile."""

    def test_constant_zero_inset(self):
        """Rectangular profile should have zero inset throughout."""
        profile = create_rectangular_profile(depth=5.0)
        for z in [0.0, 1.0, 2.5, 5.0]:
            assert profile.inset_at(z) == 0.0

    def test_total_height_matches_depth(self):
        """Total height should match specified depth."""
        profile = create_rectangular_profile(depth=3.5)
        assert profile.total_height == 3.5


class TestGridfinityBaseplateProfile:
    """Tests for Gridfinity baseplate profile."""

    def test_standard_height(self):
        """Standard profile should have height of 4.75mm."""
        profile = create_gridfinity_baseplate_profile()
        assert profile.total_height == pytest.approx(GR_BASE_HEIGHT, rel=0.01)

    def test_three_segments(self):
        """Profile should have 3 segments: bottom chamfer, straight, top chamfer."""
        profile = create_gridfinity_baseplate_profile()
        assert len(profile.segments) == 3

    def test_bottom_chamfer_starts_at_zero(self):
        """Bottom chamfer should start with zero inset."""
        profile = create_gridfinity_baseplate_profile()
        assert profile.inset_at(0.0) == pytest.approx(0.0)

    def test_inset_increases_with_height(self):
        """Inset should generally increase with height (chamfers)."""
        profile = create_gridfinity_baseplate_profile()
        insets = [profile.inset_at(z) for z in [0.0, 1.0, 2.0, 3.0, 4.0]]
        # Should be non-decreasing
        for i in range(1, len(insets)):
            assert insets[i] >= insets[i - 1] - 0.01  # Allow small tolerance


class TestGetProfile:
    """Tests for get_profile()."""

    def test_get_rectangular(self):
        """Should return rectangular profile."""
        profile = get_profile(PROFILE_RECTANGULAR, depth=5.0)
        assert profile.name == "rectangular"
        assert profile.max_inset == 0.0

    def test_get_gridfinity(self):
        """Should return gridfinity baseplate profile."""
        profile = get_profile(PROFILE_GRIDFINITY)
        assert profile.name == "gridfinity_baseplate"
        assert profile.max_inset > 0

    def test_unknown_profile_raises(self):
        """Unknown profile name should raise ValueError."""
        with pytest.raises(ValueError, match="Unknown profile"):
            get_profile("unknown_profile")


class TestGenerateProfiledCutter:
    """Tests for generate_profiled_cutter()."""

    @pytest.fixture
    def simple_setup(self):
        """Create a simple test setup."""
        poly = box(0, 0, 42, 42)
        frame = BottomFrame(
            origin=np.array([21.0, 21.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )
        return poly, frame

    def test_rectangular_profile_creates_mesh(self, simple_setup):
        """Rectangular profile should create a valid mesh."""
        poly, frame = simple_setup
        cutter = generate_profiled_cutter(poly, frame, profile="rect", depth=4.0)
        assert len(cutter.faces) > 0
        assert len(cutter.vertices) > 0

    def test_gridfinity_profile_creates_mesh(self, simple_setup):
        """Gridfinity profile should create a valid mesh."""
        poly, frame = simple_setup
        cutter = generate_profiled_cutter(poly, frame, profile="gridfinity")
        assert len(cutter.faces) > 0
        assert len(cutter.vertices) > 0

    def test_gridfinity_has_different_geometry(self, simple_setup):
        """Gridfinity profile should have different vertex count than rectangular."""
        poly, frame = simple_setup
        rect_cutter = generate_profiled_cutter(poly, frame, profile="rect", depth=4.0)
        gf_cutter = generate_profiled_cutter(poly, frame, profile="gridfinity")
        # Gridfinity has multiple slabs with different insets, so different vertices
        # Even if face count is same (due to merging), vertex count differs
        assert len(gf_cutter.vertices) != len(rect_cutter.vertices)

    def test_cutter_z_extent(self, simple_setup):
        """Cutter should extend from -epsilon to +depth."""
        poly, frame = simple_setup
        depth = 4.75
        epsilon = 0.02
        cutter = generate_profiled_cutter(poly, frame, profile="gridfinity", depth=depth, epsilon=epsilon)
        bounds = cutter.bounds
        # Z should start near -epsilon (with frame at z=0)
        assert bounds[0, 2] <= epsilon
        # Z should end near depth
        assert bounds[1, 2] >= depth - 0.1

    def test_more_slices_more_faces(self, simple_setup):
        """More slices should produce more faces."""
        poly, frame = simple_setup
        cutter_5 = generate_profiled_cutter(poly, frame, profile="gridfinity", n_slices=5)
        cutter_20 = generate_profiled_cutter(poly, frame, profile="gridfinity", n_slices=20)
        assert len(cutter_20.faces) > len(cutter_5.faces)

    def test_transforms_to_world_coords(self, simple_setup):
        """Cutter should be transformed to world coordinates."""
        poly, frame = simple_setup
        # Move frame origin
        frame_offset = BottomFrame(
            origin=np.array([100.0, 200.0, 50.0]),
            rotation=np.eye(3),
            z_min=50.0,
        )
        cutter = generate_profiled_cutter(poly, frame_offset, profile="rect", depth=4.0)
        # Bounds should be near the offset origin
        bounds = cutter.bounds
        assert bounds[0, 0] > 50  # X offset
        assert bounds[0, 1] > 150  # Y offset
        assert bounds[0, 2] > 45  # Z offset (50 - epsilon)

    def test_handles_multipolygon(self):
        """Should handle MultiPolygon input."""
        from shapely.geometry import MultiPolygon

        poly1 = box(0, 0, 10, 10)
        poly2 = box(20, 20, 30, 30)
        multi = MultiPolygon([poly1, poly2])
        frame = BottomFrame(
            origin=np.array([15.0, 15.0, 0.0]),
            rotation=np.eye(3),
            z_min=0.0,
        )
        cutter = generate_profiled_cutter(multi, frame, profile="rect", depth=2.0)
        assert len(cutter.faces) > 0
