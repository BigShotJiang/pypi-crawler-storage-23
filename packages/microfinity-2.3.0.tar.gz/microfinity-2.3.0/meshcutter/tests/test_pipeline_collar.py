"""Tests for meshcutter.pipeline.collar module."""

import pytest
import numpy as np

# Skip if dependencies not available
# Use exc_type so broken installs (not just missing) fail in CAD lane
pytest.importorskip("trimesh", exc_type=ModuleNotFoundError)
pytest.importorskip("shapely", exc_type=ModuleNotFoundError)

from unittest.mock import MagicMock, patch
from shapely.geometry import Polygon


class TestExtractCollarPolygon:
    """Tests for extract_collar_polygon function."""

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    @patch("meshcutter.pipeline.polygons.reject_area_outliers")
    @patch("meshcutter.pipeline.polygons.clean_polygon")
    @patch("meshcutter.pipeline.polygons.ensure_single_polygon")
    def test_basic_extraction(self, mock_ensure, mock_clean, mock_reject, mock_slice):
        """Basic collar extraction with valid polygons."""
        from meshcutter.pipeline.collar import extract_collar_polygon

        # Create mock polygons
        poly1 = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])
        poly2 = Polygon([(1, 1), (9, 1), (9, 9), (1, 9)])

        mock_slice.return_value = poly1
        mock_reject.return_value = [poly1, poly2]
        mock_ensure.return_value = poly2
        mock_clean.return_value = poly2

        # Mock mesh
        mesh = MagicMock()

        result = extract_collar_polygon(mesh, z_join=5.0)

        assert result is not None
        mock_slice.assert_called()
        mock_reject.assert_called_once()

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    def test_no_valid_polygons(self, mock_slice):
        """Return None when no valid polygons extracted."""
        from meshcutter.pipeline.collar import extract_collar_polygon

        mock_slice.return_value = None

        mesh = MagicMock()
        result = extract_collar_polygon(mesh, z_join=5.0)

        assert result is None

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    @patch("meshcutter.pipeline.polygons.reject_area_outliers")
    def test_intersection_fallback(self, mock_reject, mock_slice):
        """Fallback to smallest polygon when intersection collapses."""
        from meshcutter.pipeline.collar import extract_collar_polygon

        # Create polygons where intersection would be empty
        poly1 = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])  # area = 100
        poly2 = Polygon([(100, 100), (105, 100), (105, 105), (100, 105)])  # area = 25, far away

        mock_slice.side_effect = [poly1, poly2]
        mock_reject.return_value = [poly1, poly2]

        mesh = MagicMock()
        result = extract_collar_polygon(mesh, z_join=5.0, n_slices=2)

        # Should fallback to smallest polygon
        assert result == poly2  # poly2 has smaller area (25 vs 100)


class TestExtractBaseGuardPolygon:
    """Tests for extract_base_guard_polygon function."""

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    @patch("meshcutter.pipeline.polygons.clean_polygon")
    @patch("meshcutter.pipeline.polygons.ensure_single_polygon")
    def test_wall_region_sampling(self, mock_ensure, mock_clean, mock_slice):
        """Sample wall region above z_join, not feet."""
        from meshcutter.pipeline.collar import extract_base_guard_polygon

        # Large polygon simulating continuous wall (>1000 threshold)
        wall_poly = Polygon([(0, 0), (50, 0), (50, 50), (0, 50)])  # area = 2500

        mock_slice.return_value = wall_poly
        mock_ensure.return_value = wall_poly
        mock_clean.return_value = wall_poly

        mesh = MagicMock()
        result = extract_base_guard_polygon(mesh, z_join=5.0)

        assert result is not None
        # Verify sampling above z_join (wall region)
        calls = mock_slice.call_args_list
        for call in calls:
            z = call[0][1]  # First positional arg after mesh
            assert z > 5.0  # Above z_join

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    def test_small_polygons_filtered(self, mock_slice):
        """Filter out small polygons (feet, not wall)."""
        from meshcutter.pipeline.collar import extract_base_guard_polygon

        # Small polygon (would be a single foot, not wall)
        # 10x10 box = area 100, less than 1000 threshold
        foot_poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])

        mock_slice.return_value = foot_poly

        mesh = MagicMock()
        result = extract_base_guard_polygon(mesh, z_join=5.0)

        assert result is None  # Filtered out as too small


class TestGetReferencePolygon:
    """Tests for get_reference_polygon function."""

    def test_guard_polygon_priority(self):
        """Use guard polygon when available."""
        from meshcutter.pipeline.collar import get_reference_polygon

        guard = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])
        collar = Polygon([(1, 1), (9, 1), (9, 9), (1, 9)])
        mesh = MagicMock()

        result = get_reference_polygon(guard, collar, mesh, z_join=5.0)

        assert result == guard

    def test_collar_polygon_fallback(self):
        """Use collar polygon when guard not available."""
        from meshcutter.pipeline.collar import get_reference_polygon

        collar = Polygon([(1, 1), (9, 1), (9, 9), (1, 9)])
        mesh = MagicMock()

        result = get_reference_polygon(None, collar, mesh, z_join=5.0)

        assert result == collar

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    def test_slice_fallback(self, mock_slice):
        """Fallback to slicing when neither polygon available."""
        from meshcutter.pipeline.collar import get_reference_polygon

        slice_poly = Polygon([(2, 2), (8, 2), (8, 8), (2, 8)])
        mock_slice.return_value = slice_poly

        mesh = MagicMock()
        result = get_reference_polygon(None, None, mesh, z_join=5.0, delta=0.5)

        assert result == slice_poly
        # Verify it sampled at z_join + delta
        mock_slice.assert_called_once_with(mesh, 5.5)


class TestExtractBaseGuardFallback:
    """Tests for extract_base_guard_fallback function."""

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    @patch("meshcutter.pipeline.polygons.clean_polygon")
    def test_single_slice_extraction(self, mock_clean, mock_slice):
        """Extract from single slice at mid-band."""
        from meshcutter.pipeline.collar import extract_base_guard_fallback

        poly = Polygon([(0, 0), (10, 0), (10, 10), (0, 10)])
        mock_slice.return_value = poly
        mock_clean.return_value = poly

        mesh = MagicMock()
        result = extract_base_guard_fallback(mesh, z_join=5.0, guard_height=0.6)

        # Should sample at z_join - guard_height/2 = 5.0 - 0.3 = 4.7
        mock_slice.assert_called_once_with(mesh, 4.7)
        assert result is not None

    @patch("meshcutter.pipeline.polygons.slice_to_material_polygon")
    def test_too_small_filtered(self, mock_slice):
        """Return None if polygon too small."""
        from meshcutter.pipeline.collar import extract_base_guard_fallback

        poly = Polygon([(0, 0), (1, 0), (1, 1), (0, 1)])
        mock_slice.return_value = poly

        mesh = MagicMock()
        result = extract_base_guard_fallback(mesh, z_join=5.0, min_area=100.0)

        assert result is None
