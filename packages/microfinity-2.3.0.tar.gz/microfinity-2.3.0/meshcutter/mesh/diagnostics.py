#! /usr/bin/env python3
"""
meshcutter.mesh.diagnostics - Mesh diagnostic utilities.

Provides a centralized function for getting diagnostic information about meshes.
"""

from __future__ import annotations

from typing import Any, Dict

import trimesh


def get_mesh_diagnostics(mesh: trimesh.Trimesh) -> Dict[str, Any]:
    """
    Get diagnostic information about a mesh.

    Useful for debugging boolean failures and mesh issues.

    Args:
        mesh: Input mesh

    Returns:
        Dictionary with diagnostic info
    """
    bounds = mesh.bounds
    diagnostics: Dict[str, Any] = {
        "is_watertight": mesh.is_watertight,
        "is_winding_consistent": mesh.is_winding_consistent,
        "euler_number": mesh.euler_number,
        "face_count": len(mesh.faces),
        "triangle_count": len(mesh.faces),  # Alias for backward compatibility
        "vertex_count": len(mesh.vertices),
        "bounds_min": bounds[0].tolist(),
        "bounds_max": bounds[1].tolist(),
        "area": mesh.area,
    }

    if mesh.is_watertight:
        diagnostics["volume"] = mesh.volume
    else:
        diagnostics["volume"] = None

    try:
        edges = mesh.edges_unique
        diagnostics["edge_count"] = len(edges)
    except Exception:
        diagnostics["edge_count"] = None

    return diagnostics
