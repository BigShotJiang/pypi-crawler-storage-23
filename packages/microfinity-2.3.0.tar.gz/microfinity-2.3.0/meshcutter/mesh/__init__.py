#! /usr/bin/env python3
"""
meshcutter.mesh - Mesh operations and conversions.

Provides utilities for mesh format conversions, boolean operations,
and 2D geometry helpers.
"""

from meshcutter.mesh.convert import cq_to_trimesh, trimesh_to_manifold, manifold_to_trimesh
from meshcutter.mesh.boolean import boolean_difference, repair_mesh
from meshcutter.mesh.grid import generate_grid_mask, compute_grid_positions
from meshcutter.mesh.diagnostics import get_mesh_diagnostics

__all__ = [
    "cq_to_trimesh",
    "trimesh_to_manifold",
    "manifold_to_trimesh",
    "boolean_difference",
    "repair_mesh",
    "generate_grid_mask",
    "compute_grid_positions",
    "get_mesh_diagnostics",
]
