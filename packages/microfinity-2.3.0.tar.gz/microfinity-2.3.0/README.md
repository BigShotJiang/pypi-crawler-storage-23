# Microfinity

[![PyPI](https://img.shields.io/pypi/v/microfinity.svg)](https://pypi.org/project/microfinity/)
[![Python](https://img.shields.io/pypi/pyversions/microfinity.svg)](https://pypi.org/project/microfinity/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![CadQuery](https://img.shields.io/badge/CadQuery-2.0%2B-green.svg)](https://github.com/CadQuery/cadquery)

**Parametric Gridfinity generator with fractional sizing support.**

Create bins in **0.25U increments** that fit perfectly on standard Gridfinity baseplates.

```
Standard Gridfinity (42mm grid)     Microfinity (10.5mm micro-grid)
┌──────────────────────────────┐    ┌──────────────────────────────┐
│                              │    │  ┌──┐┌──┐┌──┐┌──┐           │
│         1U x 1U bin          │    │  │  ││  ││  ││  │  0.25U    │
│         (42 x 42mm)          │    │  └──┘└──┘└──┘└──┘  bins     │
│                              │    │  ┌──┐┌──┐┌─────────┐        │
│                              │    │  │  ││  ││         │  Mixed │
│                              │    │  └──┘└──┘│  0.5U   │  sizes │
│                              │    │  ┌──────┐│   bin   │        │
│                              │    │  │      │└─────────┘        │
│                              │    │  │ 0.5U │                   │
└──────────────────────────────┘    └──┴──────┴───────────────────┘
```

## Features

- **100% Gridfinity Compatible** - Works on any standard baseplate
- **Fractional Sizing** - 0.25U (10.5mm) and 0.5U (21mm) increments
- **Automatic Drawer Layouts** - Tile baseplates for any drawer size
- **Multi-Piece Support** - Connection clips for pieces larger than your build plate
- **Parametric** - Magnets, scoops, labels, dividers, and more
- **Multiple Formats** - Export to STL, STEP, or SVG

## Quick Start

**Install:**
```bash
pip install microfinity
```

**Create your first box:**
```python
from microfinity import GridfinityBox

box = GridfinityBox(2, 3, 4, holes=True, scoops=True)
box.save_stl_file()  # -> gf_box_2x3x4_holes_scoops.stl
```

**Or use the CLI:**
```bash
microfinity box 2 3 4 --magnets --scoops -f stl
```

## Why Fractional Sizes?

Standard Gridfinity bins come in whole-unit sizes (1U = 42mm). But what if your screwdriver is 35mm wide? You'd need a 1U bin with wasted space, or it won't fit at all.

With Microfinity, create a **0.75U bin (31.5mm)** or **1.25U bin (52.5mm)** - whatever fits your items best:

```python
from microfinity import GridfinityBox

# Perfect fit for narrow items
narrow_bin = GridfinityBox(0.5, 2, 3, micro_divisions=4)

# Slightly wider than 1U
wide_bin = GridfinityBox(1.25, 1, 3, micro_divisions=4)
```

Fractional bins use smaller "micro-feet" that still index correctly on standard baseplates.

## Examples

### Boxes

```python
from microfinity import GridfinityBox

# Standard box with all features
box = GridfinityBox(2, 3, 4, holes=True, scoops=True, labels=True)

# Fractional box (quarter-grid)
small_box = GridfinityBox(1.25, 0.5, 3, micro_divisions=4)

# Box with dividers
divided_box = GridfinityBox(4, 2, 3, length_div=3, width_div=1)
```

### Baseplates

```python
from microfinity import GridfinityBaseplate

# Simple baseplate
plate = GridfinityBaseplate(4, 4)

# With corner screws for mounting
mounted = GridfinityBaseplate(6, 4, corner_screws=True)
```

### Drawer Layouts

```python
from microfinity import GridfinityBaseplateLayout

# Automatically tile a drawer larger than your build plate
layout = GridfinityBaseplateLayout(
    drawer_x_mm=450,      # Drawer width
    drawer_y_mm=380,      # Drawer depth
    build_plate_x_mm=220, # Printer bed X
    build_plate_y_mm=220, # Printer bed Y
)

layout.print_summary()    # See the breakdown
layout.export_all("./drawer", file_format="stl")
```

## CLI Commands

```bash
# Generate boxes
microfinity box 2 3 4 -f stl                    # Basic 2x3x4 box
microfinity box 2 3 4 --magnets --scoops -f stl # With features
microfinity box 1.25 2 3 -m 4 -f stl            # Fractional (quarter-grid)

# Generate baseplates
microfinity baseplate 4 4 -f stl                # 4x4 baseplate
microfinity baseplate 6 4 --corner-screws -f stl

# Generate drawer layouts
microfinity layout 450 380 --build-plate 220 220 -o ./drawer -f stl

# Convert existing STL to micro-feet
microfinity meshcut input.stl -o output.stl -m 4

# Show help
microfinity --help
microfinity box --help
```

## The Micro-Grid System

| Divisions | Pitch  | Increment | Example Sizes |
|-----------|--------|-----------|---------------|
| 1         | 42.0mm | 1U        | 1, 2, 3, 4... |
| 2         | 21.0mm | 0.5U      | 0.5, 1, 1.5, 2... |
| 4         | 10.5mm | 0.25U     | 0.25, 0.5, 0.75, 1, 1.25... |

See [The Microgrid System](docs/microgrid-system.md) for technical details.

## Documentation

- [Getting Started](docs/getting-started.md)
- [The Microgrid System](docs/microgrid-system.md)
- **Components:**
  - [Boxes](docs/components/boxes.md)
  - [Baseplates](docs/components/baseplates.md)
  - [Layouts](docs/components/layouts.md)
  - [Spacers](docs/components/spacers.md)
- [CLI Reference](docs/cli-reference.md)
- [Calibration](docs/calibration.md)
- [Export Options](docs/export.md)
- [Python API](docs/python-api.md)

## Example Scripts

See the [examples/](examples/) directory:

| Script | Description |
|--------|-------------|
| `basic_box.py` | Simple box with common features |
| `fractional_bins.py` | Various fractional sizes |
| `drawer_layout.py` | Complete drawer layout workflow |
| `custom_baseplate.py` | Baseplates with edge configurations |
| `batch_export.py` | Generate families of parts |

## Requirements

- Python 3.9+
- [CadQuery](https://github.com/CadQuery/cadquery) >= 2.0
- [cq-kit](https://github.com/michaelgale/cq-kit) >= 0.5.6

## Contributing

Contributions are welcome! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## Acknowledgments

- **[Zack Freedman](https://www.youtube.com/c/ZackFreedman)** - Creator of the Gridfinity system
- **[Michael Gale](https://github.com/michaelgale)** - Original [cq-gridfinity](https://github.com/michaelgale/cq-gridfinity) author
- **[CadQuery Team](https://github.com/CadQuery/cadquery)** - The amazing parametric CAD library

## License

MIT License - See [LICENSE](LICENSE) for details.
