"""Tests for stackable-only boxes (no baseplate feet)."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestStackableOnlyBoxes:
    """Test stackable-only boxes with flat bottoms (no feet)."""

    def test_stackable_only_basic(self):
        """Test basic stackable-only box renders."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
        )
        result = box.render()
        assert result is not None
        assert box.stackable_only is True

    def test_stackable_only_no_feet(self):
        """Test stackable-only box has no feet indentations."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_stackable = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
        )

        result_normal = box_normal.render()
        result_stackable = box_stackable.render()

        volume_normal = result_normal.val().Volume()
        volume_stackable = result_stackable.val().Volume()

        # Stackable box should have more volume (no foot cavities)
        assert volume_stackable > volume_normal

    def test_stackable_with_holes(self):
        """Test stackable-only works with magnet holes."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
            holes=True,
        )
        result = box.render()
        assert result is not None

    def test_stackable_with_scoops(self):
        """Test stackable-only works with scoops."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
            scoops=True,
        )
        result = box.render()
        assert result is not None

    def test_stackable_with_labels(self):
        """Test stackable-only works with labels."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
            labels=True,
        )
        result = box.render()
        assert result is not None

    def test_stackable_with_dividers(self):
        """Test stackable-only works with dividers."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            stackable_only=True,
            length_div=1,
            width_div=1,
        )
        result = box.render()
        assert result is not None

    def test_stackable_str_description(self):
        """Test stackable-only info appears in box description."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            stackable_only=True,
        )
        desc = str(box)
        assert "Stackable only" in desc
        assert "no baseplate feet" in desc

    def test_stackable_different_sizes(self):
        """Test stackable-only works with various sizes."""
        for length, width, height in [
            (1, 1, 2),
            (2, 3, 4),
            (4, 4, 6),
        ]:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=height,
                stackable_only=True,
            )
            result = box.render()
            assert result is not None, f"Failed for {length}x{width}x{height}"
