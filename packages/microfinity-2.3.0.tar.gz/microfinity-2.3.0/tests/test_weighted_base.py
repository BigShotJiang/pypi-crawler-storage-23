"""Tests for weighted base boxes."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestWeightedBaseBoxes:
    """Test weighted base boxes with thicker floors."""

    def test_weighted_base_default(self):
        """Test weighted base with default extra thickness (50%)."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_weighted = GridfinityBox(length_u=2, width_u=2, height_u=3, weighted_base=True)

        # Weighted box should have thicker floor
        assert box_weighted.floor_h > box_normal.floor_h
        assert box_weighted.weighted_base is True

        # Render should succeed
        result = box_weighted.render()
        assert result is not None

    def test_weighted_base_custom_extra(self):
        """Test weighted base with custom extra thickness."""
        # Get baseline floor height
        box_baseline = GridfinityBox(length_u=2, width_u=2, height_u=3)
        baseline_floor = box_baseline.floor_h

        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
            base_extra_mm=5,
        )

        # Floor height should be baseline + 5mm
        expected_floor = baseline_floor + 5
        assert abs(box.floor_h - expected_floor) < 0.1
        assert box.base_extra_mm == 5

        result = box.render()
        assert result is not None

    def test_weighted_base_increases_volume(self):
        """Test that weighted base increases box volume."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result_normal = box_normal.render()
        volume_normal = result_normal.val().Volume()

        box_weighted = GridfinityBox(length_u=2, width_u=2, height_u=3, weighted_base=True)
        result_weighted = box_weighted.render()
        volume_weighted = result_weighted.val().Volume()

        # Weighted box should have more volume
        assert volume_weighted > volume_normal

    def test_weighted_base_with_holes(self):
        """Test weighted base works with magnet holes."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
            holes=True,
        )
        result = box.render()
        assert result is not None

    def test_weighted_base_with_scoops(self):
        """Test weighted base works with scoops."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
            scoops=True,
        )
        result = box.render()
        assert result is not None

    def test_weighted_base_with_labels(self):
        """Test weighted base works with labels."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
            labels=True,
        )
        result = box.render()
        assert result is not None

    def test_weighted_base_with_dividers(self):
        """Test weighted base works with internal dividers."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            weighted_base=True,
            length_div=1,
            width_div=1,
        )
        result = box.render()
        assert result is not None

    def test_weighted_base_str_description(self):
        """Test weighted base info appears in box description."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
        )
        desc = str(box)
        assert "Weighted base" in desc

    def test_weighted_base_zero_extra_uses_default(self):
        """Test that base_extra_mm=0 uses default 2mm increase."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_weighted = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            weighted_base=True,
            base_extra_mm=0,  # Should use default calculation
        )

        # Should have 2mm more floor height than baseline
        assert box_weighted.floor_h == box_normal.floor_h + 2.0
