"""Tests for drawer-style boxes with finger pull cutouts."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestDrawerStyleBoxes:
    """Test drawer-style boxes with finger pull cutouts."""

    def test_drawer_style_basic(self):
        """Test basic drawer style box."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
        )
        result = box.render()
        assert result is not None
        assert box.drawer_style is True
        assert box.no_lip is True  # Drawer style implies no_lip

    def test_drawer_style_arc_finger_pull(self):
        """Test drawer with arc finger pull."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="arc",
        )
        result = box.render()
        assert result is not None
        assert box.finger_pull_style == "arc"

    def test_drawer_style_slot_finger_pull(self):
        """Test drawer with slot finger pull."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="slot",
        )
        result = box.render()
        assert result is not None
        assert box.finger_pull_style == "slot"

    def test_drawer_style_no_finger_pull(self):
        """Test drawer with no finger pull (just no lip)."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="none",
        )
        result = box.render()
        assert result is not None

    def test_drawer_with_labels(self):
        """Test drawer works with labels."""
        box = GridfinityBox(
            length_u=3,
            width_u=2,
            height_u=3,
            drawer_style=True,
            labels=True,
            label_style="flat",
        )
        result = box.render()
        assert result is not None

    def test_drawer_with_scoops(self):
        """Test drawer works with scoops."""
        box = GridfinityBox(
            length_u=2,
            width_u=3,
            height_u=3,
            drawer_style=True,
            scoops=True,
        )
        result = box.render()
        assert result is not None

    def test_drawer_with_dividers(self):
        """Test drawer works with internal dividers."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            drawer_style=True,
            length_div=1,
            width_div=1,
        )
        result = box.render()
        assert result is not None

    def test_drawer_micro_divisions(self):
        """Test drawer works with micro-divisions."""
        for micro_div in [1, 2, 4]:
            box = GridfinityBox(
                length_u=1.5,
                width_u=1.5,
                height_u=2,
                drawer_style=True,
                micro_divisions=micro_div,
            )
            result = box.render()
            assert result is not None, f"Failed for micro_div={micro_div}"

    def test_finger_pull_custom_dimensions(self):
        """Test drawer with custom finger pull dimensions."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_depth=15,
            finger_pull_height=15,
            finger_pull_width=30,
            finger_pull_z_offset=5,
        )
        result = box.render()
        assert result is not None
        assert box.finger_pull_depth == 15
        assert box.finger_pull_height == 15
        assert box.finger_pull_width == 30
        assert box.finger_pull_z_offset == 5

    def test_finger_pull_depth_validation(self):
        """Test that excessive finger pull depth raises error."""
        # With 2U width (~84mm interior), max depth is 50% of that = ~42mm or 20mm cap
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_depth=50,  # Too deep
        )
        with pytest.raises(ValueError, match="finger_pull_depth"):
            box.render()

    def test_finger_pull_reduces_volume(self):
        """Test that finger pull actually removes material (cuts, not adds)."""
        # Create box without finger pull
        box_no_fp = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="none",
        )
        result_no_fp = box_no_fp.render()
        volume_no_fp = result_no_fp.val().Volume()

        # Create box with finger pull
        box_with_fp = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="arc",
            finger_pull_depth=10,
            finger_pull_height=10,
            finger_pull_width=25,
        )
        result_with_fp = box_with_fp.render()
        volume_with_fp = result_with_fp.val().Volume()

        # Volume with finger pull should be less than without
        assert volume_with_fp < volume_no_fp, f"Expected volume reduction: {volume_no_fp} -> {volume_with_fp}"

    def test_drawer_str_description(self):
        """Test drawer info appears in box description."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            drawer_style=True,
            finger_pull_style="arc",
        )
        desc = str(box)
        assert "Drawer style" in desc
        assert "arc" in desc.lower()
