"""End-to-end CLI tests.

These tests invoke the CLI commands and verify they work correctly.
"""

import pytest
import subprocess
import sys
import tempfile
from pathlib import Path


def run_cli(*args, check=True):
    """Run the microfinity CLI with given arguments.

    Args:
        *args: CLI arguments
        check: Whether to check return code

    Returns:
        subprocess.CompletedProcess result
    """
    cmd = [sys.executable, "-m", "microfinity.cli.main"] + list(args)
    result = subprocess.run(cmd, capture_output=True, text=True)
    if check and result.returncode != 0:
        print(f"STDOUT: {result.stdout}")
        print(f"STDERR: {result.stderr}")
    return result


class TestCLIInfo:
    """Test 'microfinity info' command."""

    def test_info_runs(self):
        """Info command should run without error."""
        result = run_cli("info")
        assert result.returncode == 0
        assert "microfinity" in result.stdout

    def test_info_shows_version(self):
        """Info should show version."""
        import re

        result = run_cli("info")
        # Check for semver pattern (e.g., 1.3.0, 2.0.0)
        assert re.search(r"\d+\.\d+\.\d+", result.stdout), "Version number not found in output"

    def test_info_shows_specs(self):
        """Info should show spec information."""
        result = run_cli("info")
        assert "Gridfinity spec" in result.stdout
        assert "42.0" in result.stdout  # pitch


class TestCLIVersion:
    """Test version flag."""

    def test_version_flag(self):
        """--version should show version."""
        result = run_cli("--version")
        assert result.returncode == 0
        assert "microfinity" in result.stdout


class TestCLIHelp:
    """Test help output."""

    def test_help_flag(self):
        """--help should show help."""
        result = run_cli("--help")
        assert result.returncode == 0
        assert "box" in result.stdout
        assert "baseplate" in result.stdout
        assert "layout" in result.stdout  # New command
        assert "meshcut" in result.stdout
        assert "debug" in result.stdout
        assert "config" in result.stdout  # New subcommand

    def test_box_help(self):
        """Box subcommand help."""
        result = run_cli("box", "--help")
        assert result.returncode == 0
        assert "length" in result.stdout
        assert "width" in result.stdout
        assert "height" in result.stdout
        # New flag naming (v2.0.0)
        assert "--magnets" in result.stdout
        assert "--scoops" in result.stdout
        assert "--lip" in result.stdout
        assert "--dividers-x" in result.stdout
        assert "--dividers-y" in result.stdout
        # Removed flags
        assert "-M" not in result.stdout  # Was --micro short flag
        assert "--magnetholes" not in result.stdout  # Renamed to --magnets

    def test_baseplate_help(self):
        """Baseplate subcommand help."""
        result = run_cli("baseplate", "--help")
        assert result.returncode == 0
        assert "--micro" in result.stdout
        assert "--units" in result.stdout
        assert "--ext-depth" in result.stdout
        assert "--straight-bottom" in result.stdout
        assert "--corner-fillet" in result.stdout

    def test_layout_help(self):
        """Layout subcommand help (new command)."""
        result = run_cli("layout", "--help")
        assert result.returncode == 0
        assert "drawer_x" in result.stdout.lower()
        assert "drawer_y" in result.stdout.lower()
        assert "--build-x" in result.stdout
        assert "--build-y" in result.stdout
        assert "--micro" in result.stdout
        assert "--tolerance" in result.stdout
        assert "--summary" in result.stdout

    def test_meshcut_help(self):
        """Meshcut subcommand help."""
        result = run_cli("meshcut", "--help")
        assert result.returncode == 0
        assert "--micro" in result.stdout  # Renamed from --micro-divisions
        assert "--skip-clean" in result.stdout  # Renamed from --no-clean
        assert "--skip-validate" in result.stdout  # Renamed from --no-validate
        assert "--channels" in result.stdout  # Renamed from --add-channels
        # Removed flags
        assert "--use-boolean" not in result.stdout
        assert "--no-clean" not in result.stdout  # Changed to --skip-clean

    def test_config_help(self):
        """Config subcommand help."""
        result = run_cli("config", "--help")
        assert result.returncode == 0
        assert "show" in result.stdout
        assert "validate" in result.stdout

    def test_debug_help(self):
        """Debug subcommand help."""
        result = run_cli("debug", "--help")
        assert result.returncode == 0
        assert "analyze" in result.stdout
        assert "slice" in result.stdout


class TestCLIDebugAnalyze:
    """Test 'microfinity debug analyze' command."""

    @pytest.fixture
    def sample_stl(self):
        """Create a sample STL file for testing."""
        # Use existing STL in the repo
        stl_path = Path(__file__).parent.parent / "microfinity" / "scripts" / "gf_box_2x1_micro4x15.stl"
        if stl_path.exists():
            return stl_path
        pytest.skip("Sample STL not found")

    def test_analyze_runs(self, sample_stl):
        """Analyze should run on valid STL."""
        result = run_cli("debug", "analyze", str(sample_stl))
        assert result.returncode == 0
        assert "Geometry:" in result.stdout
        assert "Vertices:" in result.stdout
        assert "Faces:" in result.stdout

    def test_analyze_shows_dimensions(self, sample_stl):
        """Analyze should show dimensions."""
        result = run_cli("debug", "analyze", str(sample_stl))
        assert "Dimensions:" in result.stdout
        assert "mm" in result.stdout

    def test_analyze_shows_watertight(self, sample_stl):
        """Analyze should show watertight status."""
        result = run_cli("debug", "analyze", str(sample_stl))
        assert "Watertight:" in result.stdout

    def test_analyze_json_output(self, sample_stl):
        """Analyze should support JSON output."""
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            output_path = Path(f.name)

        try:
            result = run_cli("debug", "analyze", str(sample_stl), "-o", str(output_path))
            assert result.returncode == 0
            assert output_path.exists()

            import json

            with open(output_path) as f:
                data = json.load(f)

            assert "geometry" in data
            assert "vertices" in data["geometry"]
            assert "faces" in data["geometry"]
        finally:
            output_path.unlink(missing_ok=True)

    def test_analyze_missing_file(self):
        """Analyze should error on missing file."""
        result = run_cli("debug", "analyze", "/nonexistent/file.stl", check=False)
        assert result.returncode != 0
        assert "not found" in result.stderr.lower() or "error" in result.stderr.lower()


class TestCLIDebugSlice:
    """Test 'microfinity debug slice' command."""

    @pytest.fixture
    def sample_stl(self):
        """Create a sample STL file for testing."""
        stl_path = Path(__file__).parent.parent / "microfinity" / "scripts" / "gf_box_2x1_micro4x15.stl"
        if stl_path.exists():
            return stl_path
        pytest.skip("Sample STL not found")

    def test_slice_creates_svg(self, sample_stl):
        """Slice should create SVG output."""
        with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as f:
            output_path = Path(f.name)

        try:
            result = run_cli("debug", "slice", str(sample_stl), "-z", "5.0", "-o", str(output_path))
            assert result.returncode == 0
            assert output_path.exists()

            content = output_path.read_text()
            assert "<svg" in content.lower() or "<?xml" in content.lower()
        finally:
            output_path.unlink(missing_ok=True)


class TestCLIDebugCompare:
    """Test 'microfinity debug compare' command."""

    @pytest.fixture
    def sample_stls(self):
        """Get sample STL files for comparison."""
        base_path = Path(__file__).parent.parent / "microfinity" / "scripts"
        stl1 = base_path / "gf_box_2x1_micro4x15.stl"
        stl2 = base_path / "gf_box_2x1_micro2x15.stl"

        if stl1.exists() and stl2.exists():
            return stl1, stl2
        pytest.skip("Sample STLs not found")

    def test_compare_runs(self, sample_stls):
        """Compare should run on valid STLs."""
        stl1, stl2 = sample_stls
        result = run_cli("debug", "compare", str(stl1), str(stl2))
        assert result.returncode == 0
        assert "Comparing:" in result.stdout
        assert "Vertices:" in result.stdout


class TestCLIErrorHandling:
    """Test CLI error handling."""

    def test_unknown_command(self):
        """Unknown command should show help."""
        result = run_cli("unknowncommand", check=False)
        assert result.returncode != 0

    def test_missing_required_args(self):
        """Missing required args should error."""
        result = run_cli("box", check=False)  # Missing length, width, height
        assert result.returncode != 0
