"""Tests for grid divisions (parametric internal dividers)."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGridDivisions:
    """Test grid-style internal dividers."""

    def test_grid_2x2(self):
        """Test 2x2 grid divisions."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
        )
        result = box.render()
        assert result is not None
        assert box.grid_divisions == 2

    def test_grid_3x3(self):
        """Test 3x3 grid divisions."""
        box = GridfinityBox(
            length_u=4,
            width_u=4,
            height_u=3,
            grid_divisions=3,
        )
        result = box.render()
        assert result is not None

    def test_grid_4x4(self):
        """Test 4x4 grid divisions."""
        box = GridfinityBox(
            length_u=4,
            width_u=4,
            height_u=3,
            grid_divisions=4,
        )
        result = box.render()
        assert result is not None

    def test_grid_with_holes(self):
        """Test grid divisions work with magnet holes."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
            holes=True,
        )
        result = box.render()
        assert result is not None

    def test_grid_with_labels(self):
        """Test grid divisions work with labels."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
            labels=True,
        )
        result = box.render()
        assert result is not None

    def test_grid_with_scoops(self):
        """Test grid divisions work with scoops."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
            scoops=True,
        )
        result = box.render()
        assert result is not None

    def test_grid_str_description(self):
        """Test grid info appears in box description."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
        )
        desc = str(box)
        assert "2x2 grid" in desc
        assert "grid divisions" in desc

    def test_grid_no_divisions(self):
        """Test grid_divisions=0 creates no grid."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=0,
        )
        result = box.render()
        assert result is not None
        # No grid divisions text in description
        desc = str(box)
        assert "grid" not in desc.lower()

    def test_grid_creates_square_compartments(self):
        """Test that grid creates approximately square compartments."""
        # For a square box, grid should create square cells
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=3,
        )

        # Cell size should be roughly equal in both directions
        cell_size = min(box.inner_l, box.inner_w) / box.grid_divisions
        # For square box, this creates square compartments
        assert cell_size > 0

    def test_grid_rectangular_box(self):
        """Test grid on rectangular box uses smaller dimension."""
        box = GridfinityBox(
            length_u=4,  # Longer
            width_u=2,  # Shorter
            height_u=3,
            grid_divisions=2,
        )
        result = box.render()
        assert result is not None
        # Should still create a valid grid

    def test_grid_different_sizes(self):
        """Test grid works with various box sizes."""
        for length, width, grid in [
            (2, 2, 2),
            (3, 3, 3),
            (4, 4, 2),
            (4, 4, 4),
        ]:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=3,
                grid_divisions=grid,
            )
            result = box.render()
            assert result is not None, f"Failed for {length}x{width} with grid={grid}"

    def test_grid_not_compatible_with_linear_divs(self):
        """Test that grid_divisions takes priority over length_div/width_div."""
        box = GridfinityBox(
            length_u=3,
            width_u=3,
            height_u=3,
            grid_divisions=2,
            length_div=1,  # Should be ignored
            width_div=1,  # Should be ignored
        )
        result = box.render()
        assert result is not None
        # Grid should be used, not linear dividers
        desc = str(box)
        assert "2x2 grid" in desc
