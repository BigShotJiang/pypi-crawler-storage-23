"""Fuzz testing for CLI argument parsing.

Generates random valid and invalid CLI arguments to ensure robust parsing
and appropriate error handling.
"""

import pytest
import subprocess
import sys
from hypothesis import given, strategies as st, settings, assume
from pathlib import Path


class TestCLIFuzz:
    """Fuzz tests for CLI argument parsing."""

    @given(
        length=st.floats(min_value=0.5, max_value=10.0),
        width=st.floats(min_value=0.5, max_value=10.0),
        height=st.integers(min_value=1, max_value=10),
    )
    @settings(max_examples=30, deadline=10000)
    def test_box_command_valid_dimensions(self, length, width, height):
        """CLI should handle various dimension inputs."""
        # Skip invalid micro-grid combinations
        assume(length >= 1.0)
        assume(width >= 1.0)

        cmd = [
            sys.executable,
            "-m",
            "microfinity",
            "box",
            str(length),
            str(width),
            str(height),
            "--dry-run",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)

        # Should either succeed or fail with clear error
        assert result.returncode in [0, 1]
        if result.returncode == 1:
            # Error should be descriptive
            assert len(result.stderr) > 0 or len(result.stdout) > 0

    @given(
        wall=st.floats(min_value=0.1, max_value=5.0),
    )
    @settings(max_examples=20, deadline=10000)
    def test_box_command_wall_thickness(self, wall):
        """CLI should handle various wall thickness values."""
        cmd = [
            sys.executable,
            "-m",
            "microfinity",
            "box",
            "2",
            "2",
            "3",
            "--wall",
            str(wall),
            "--dry-run",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode in [0, 1]

    @given(
        length_div=st.integers(min_value=0, max_value=5),
        width_div=st.integers(min_value=0, max_value=5),
    )
    @settings(max_examples=30, deadline=10000)
    def test_box_command_dividers(self, length_div, width_div):
        """CLI should handle various divider configurations."""
        # Ensure dividers fit in box
        assume(length_div < 3)
        assume(width_div < 3)

        cmd = [sys.executable, "-m", "microfinity", "box", "3", "3", "3"]

        if length_div > 0:
            cmd.extend(["--length-div", str(length_div)])
        if width_div > 0:
            cmd.extend(["--width-div", str(width_div)])

        cmd.append("--dry-run")

        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode in [0, 1]

    @given(
        grid_div=st.integers(min_value=0, max_value=6),
    )
    @settings(max_examples=15, deadline=10000)
    def test_box_command_grid_divisions(self, grid_div):
        """CLI should handle various grid division values."""
        assume(grid_div <= 4)  # Reasonable limit

        cmd = [
            sys.executable,
            "-m",
            "microfinity",
            "box",
            "4",
            "4",
            "3",
            "--grid-div",
            str(grid_div),
            "--dry-run",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode in [0, 1]

    @given(
        scoop_depth=st.floats(min_value=1.0, max_value=30.0),
        scoop_offset=st.floats(min_value=-10.0, max_value=10.0),
    )
    @settings(max_examples=20, deadline=10000)
    def test_box_command_scoop_params(self, scoop_depth, scoop_offset):
        """CLI should handle various scoop parameter combinations."""
        cmd = [
            sys.executable,
            "-m",
            "microfinity",
            "box",
            "2",
            "2",
            "3",
            "--scoops",
            "--scoop-depth",
            str(scoop_depth),
            "--scoop-offset",
            str(scoop_offset),
            "--dry-run",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode in [0, 1]

    @given(
        fp_depth=st.floats(min_value=1.0, max_value=20.0),
        fp_height=st.floats(min_value=5.0, max_value=25.0),
    )
    @settings(max_examples=20, deadline=10000)
    def test_box_command_finger_pull_params(self, fp_depth, fp_height):
        """CLI should handle various finger pull parameter combinations."""
        cmd = [
            sys.executable,
            "-m",
            "microfinity",
            "box",
            "2",
            "2",
            "3",
            "--drawer",
            "--finger-pull-depth",
            str(fp_depth),
            "--finger-pull-height",
            str(fp_height),
            "--dry-run",
        ]

        result = subprocess.run(cmd, capture_output=True, text=True)
        assert result.returncode in [0, 1]

    def test_cli_help_shows_all_options(self):
        """Help output should list all available options."""
        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "box", "--help"],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0
        help_text = result.stdout

        # Should show common options
        assert "--labels" in help_text
        assert "--scoops" in help_text
        assert "--drawer" in help_text
        assert "--grid-div" in help_text

    def test_cli_rejects_invalid_micro_divisions(self):
        """CLI should reject invalid micro-division values."""
        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "box", "2", "2", "3", "-M", "3"],
            capture_output=True,
            text=True,
        )

        # Should fail (3 is not a valid choice)
        assert result.returncode != 0

    def test_cli_rejects_negative_dimensions(self):
        """CLI should reject negative dimensions."""
        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "box", "-1", "2", "3"],
            capture_output=True,
            text=True,
        )

        # Should fail or handle gracefully
        assert result.returncode != 0 or "error" in result.stderr.lower()

    @given(
        feature_combo=st.lists(
            st.sampled_from(
                [
                    "--labels",
                    "--scoops",
                    "--holes",
                    "--drawer",
                    "--weighted",
                    "--stackable",
                ]
            ),
            min_size=1,
            max_size=4,
            unique=True,
        )
    )
    @settings(max_examples=20, deadline=15000)
    def test_feature_combinations(self, feature_combo):
        """CLI should handle various feature flag combinations."""
        cmd = [sys.executable, "-m", "microfinity", "box", "2", "2", "3"]
        cmd.extend(feature_combo)
        cmd.append("--dry-run")

        result = subprocess.run(cmd, capture_output=True, text=True)
        # Should either succeed or fail gracefully
        assert result.returncode in [0, 1]


class TestCLIBoundaryCases:
    """Test boundary and edge cases for CLI."""

    def test_very_small_box(self):
        """CLI should handle minimum size box."""
        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "box", "1", "1", "1", "--dry-run"],
            capture_output=True,
            text=True,
        )
        assert result.returncode in [0, 1]

    def test_very_large_box(self):
        """CLI should handle large box dimensions."""
        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "box", "6", "6", "10", "--dry-run"],
            capture_output=True,
            text=True,
        )
        assert result.returncode in [0, 1]

    def test_fractional_dimensions(self):
        """CLI should handle fractional U dimensions."""
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "microfinity",
                "box",
                "1.5",
                "2.5",
                "3",
                "--dry-run",
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode in [0, 1]

    def test_zero_dividers(self):
        """CLI should handle zero divider values."""
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "microfinity",
                "box",
                "2",
                "2",
                "3",
                "--length-div",
                "0",
                "--width-div",
                "0",
                "--dry-run",
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode in [0, 1]
