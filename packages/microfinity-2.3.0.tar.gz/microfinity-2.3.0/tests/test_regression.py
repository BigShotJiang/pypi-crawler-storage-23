"""Regression tests for geometry changes.

These tests capture specific geometric behaviors that should remain stable
across code changes. They detect unintended modifications to output geometry.
"""

import pytest
import hashlib
from pathlib import Path

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestGeometryRegression:
    """Regression tests to catch unintended geometry changes."""

    def test_standard_box_volume_regression(self):
        """Standard 2x2x3 box should have consistent volume."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()
        volume = result.val().Volume()

        # Volume should be within expected range (allows for minor floating point differences)
        # A 2x2x3 box is approximately 84x84x21mm exterior
        # Volume should be around ~60,000-70,000 mm³
        assert 55000 < volume < 75000, f"Volume {volume} outside expected range"

    def test_box_with_holes_volume_regression(self):
        """Box with holes should have consistent volume reduction."""
        box_no_holes = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_with_holes = GridfinityBox(length_u=2, width_u=2, height_u=3, holes=True)

        vol_no_holes = box_no_holes.render().val().Volume()
        vol_with_holes = box_with_holes.render().val().Volume()

        # Holes should reduce volume by approximately 1000-2000 mm³ (4 holes)
        volume_reduction = vol_no_holes - vol_with_holes
        assert 500 < volume_reduction < 3000, f"Hole volume reduction {volume_reduction} unexpected"

    def test_dividers_create_volume_reduction(self):
        """Dividers should add material and increase volume."""
        box_no_divs = GridfinityBox(length_u=3, width_u=3, height_u=3)
        box_with_divs = GridfinityBox(length_u=3, width_u=3, height_u=3, length_div=1, width_div=1)

        vol_no_divs = box_no_divs.render().val().Volume()
        vol_with_divs = box_with_divs.render().val().Volume()

        # Dividers add material, so volume should increase
        assert vol_with_divs > vol_no_divs

    def test_grid_divisions_vs_linear_divs(self):
        """2x2 grid should produce similar geometry to length_div=1, width_div=1."""
        box_grid = GridfinityBox(length_u=3, width_u=3, height_u=3, grid_divisions=2)
        box_linear = GridfinityBox(length_u=3, width_u=3, height_u=3, length_div=1, width_div=1)

        vol_grid = box_grid.render().val().Volume()
        vol_linear = box_linear.render().val().Volume()

        # Volumes should be very close (within 1%)
        ratio = vol_grid / vol_linear
        assert 0.99 < ratio < 1.01, f"Grid vs linear volume ratio {ratio} differs significantly"

    def test_wall_thickness_affects_interior(self):
        """Thicker walls should reduce interior dimensions."""
        box_thin = GridfinityBox(length_u=2, width_u=2, height_u=3, wall_th=0.8)
        box_thick = GridfinityBox(length_u=2, width_u=2, height_u=3, wall_th=1.5)

        # Thicker walls = smaller interior
        assert box_thick.inner_l < box_thin.inner_l
        assert box_thick.inner_w < box_thin.inner_w

    def test_micro_divisions_affect_pitch(self):
        """Micro divisions should create correct pitch."""
        box_micro2 = GridfinityBox(length_u=2, width_u=2, height_u=3, micro_divisions=2)
        box_micro4 = GridfinityBox(length_u=2, width_u=2, height_u=3, micro_divisions=4)

        # Micro pitch should be correct
        assert abs(box_micro2.micro_pitch - 21.0) < 0.1  # 42/2
        assert abs(box_micro4.micro_pitch - 10.5) < 0.1  # 42/4

    def test_weighted_base_increases_floor(self):
        """Weighted base should consistently increase floor height by 2mm."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_weighted = GridfinityBox(length_u=2, width_u=2, height_u=3, weighted_base=True)

        floor_increase = box_weighted.floor_h - box_normal.floor_h
        assert abs(floor_increase - 2.0) < 0.01

    def test_drawer_cutout_reduces_volume(self):
        """Drawer finger pull should reduce volume."""
        box_normal = GridfinityBox(length_u=2, width_u=2, height_u=3, no_lip=True)
        box_drawer = GridfinityBox(length_u=2, width_u=2, height_u=3, drawer_style=True)

        vol_normal = box_normal.render().val().Volume()
        vol_drawer = box_drawer.render().val().Volume()

        # Finger pull should remove material
        assert vol_drawer < vol_normal

    def test_stackable_increases_volume(self):
        """Stackable-only (no feet) should have more volume than standard."""
        box_standard = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box_stackable = GridfinityBox(length_u=2, width_u=2, height_u=3, stackable_only=True)

        vol_standard = box_standard.render().val().Volume()
        vol_stackable = box_stackable.render().val().Volume()

        # No foot cavities = more material
        assert vol_stackable > vol_standard

    def test_label_style_consistency(self):
        """Different label styles should produce different volumes."""
        volumes = {}
        for style in ["flat", "angled", "recessed"]:
            box = GridfinityBox(length_u=2, width_u=2, height_u=3, labels=True, label_style=style)
            volumes[style] = box.render().val().Volume()

        # Each style should have slightly different volume
        # (they add different amounts of material)
        assert len(set(volumes.values())) >= 2  # At least 2 different volumes


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestExportRegression:
    """Regression tests for export functionality."""

    def test_step_export_creates_valid_file(self, tmp_path):
        """STEP export should create valid file."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box.render()

        output_file = tmp_path / "test.step"
        box.save_step_file(str(output_file))

        assert output_file.exists()
        assert output_file.stat().st_size > 1000  # Should have content

    def test_stl_export_creates_valid_file(self, tmp_path):
        """STL export should create valid file."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        box.render()

        output_file = tmp_path / "test.stl"
        box.save_stl_file(str(output_file))

        assert output_file.exists()
        assert output_file.stat().st_size > 1000

        # Check STL header
        with open(output_file, "rb") as f:
            header = f.read(80)
            assert len(header) == 80  # STL header is 80 bytes

    def test_filename_format_regression(self):
        """Filename format should be consistent."""
        box = GridfinityBox(length_u=2, width_u=3, height_u=4, holes=True, scoops=True)
        filename = box.filename()

        # Should contain dimensions
        assert "2" in filename
        assert "3" in filename
        assert "4" in filename

        # Should contain features
        assert "holes" in filename
        assert "scoops" in filename

        # Should have correct extension format
        assert filename.endswith(".step") or filename.endswith(".stl")
