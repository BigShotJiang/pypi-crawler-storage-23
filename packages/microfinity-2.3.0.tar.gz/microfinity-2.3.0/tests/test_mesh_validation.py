"""Mesh validation tests for generated geometry.

These tests verify that all generated meshes are:
- Watertight (no holes)
- Manifold (valid topology)
- Have correct dimensions
"""

import pytest
import tempfile
from pathlib import Path

from microfinity import (
    GridfinityBox,
    GridfinitySolidBox,
    GridfinityBaseplate,
    GridfinityDrawerSpacer,
)
from microfinity.spec.constants import GRU, GRHU


def export_and_validate_stl(workplane, name: str):
    """Export geometry to STL and validate with trimesh.

    Args:
        workplane: CadQuery workplane
        name: Name for error messages

    Returns:
        trimesh.Trimesh mesh object
    """
    import trimesh

    with tempfile.NamedTemporaryFile(suffix=".stl", delete=False) as f:
        stl_path = Path(f.name)

    try:
        # Export to STL
        solid = workplane.val()
        solid.exportStl(str(stl_path))

        # Load with trimesh
        mesh = trimesh.load(str(stl_path))

        return mesh
    finally:
        stl_path.unlink(missing_ok=True)


class TestBoxMeshValidation:
    """Mesh validation for GridfinityBox."""

    def test_box_1x1x3_watertight(self):
        """1x1x3 box should be watertight."""
        box = GridfinityBox(1, 1, 3)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_1x1x3")

        assert mesh.is_watertight, "Box mesh should be watertight"
        assert mesh.is_winding_consistent, "Box mesh should have consistent winding"

    def test_box_2x2x4_watertight(self):
        """2x2x4 box should be watertight."""
        box = GridfinityBox(2, 2, 4)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_2x2x4")

        assert mesh.is_watertight, "Box mesh should be watertight"

    def test_box_with_holes_watertight(self):
        """Box with magnet holes should be watertight."""
        box = GridfinityBox(2, 2, 3, holes=True)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_2x2x3_holes")

        assert mesh.is_watertight, "Box with holes should be watertight"

    def test_box_lite_watertight(self):
        """Lite style box should be watertight."""
        box = GridfinityBox(2, 2, 4, lite_style=True)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_2x2x4_lite")

        assert mesh.is_watertight, "Lite box should be watertight"


class TestBaseplateMeshValidation:
    """Mesh validation for GridfinityBaseplate."""

    def test_baseplate_2x2_watertight(self):
        """2x2 baseplate should be watertight."""
        bp = GridfinityBaseplate(2, 2)
        geom = bp.render()
        mesh = export_and_validate_stl(geom, "baseplate_2x2")

        assert mesh.is_watertight, "Baseplate mesh should be watertight"

    def test_baseplate_4x3_watertight(self):
        """4x3 baseplate should be watertight."""
        bp = GridfinityBaseplate(4, 3)
        geom = bp.render()
        mesh = export_and_validate_stl(geom, "baseplate_4x3")

        assert mesh.is_watertight, "Baseplate mesh should be watertight"


class TestDimensionValidation:
    """Dimension validation for generated geometry."""

    def test_box_1x1_footprint(self):
        """1x1 box should have correct XY footprint."""
        box = GridfinityBox(1, 1, 3)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_1x1x3")

        dims = mesh.bounds[1] - mesh.bounds[0]
        expected_xy = GRU - 0.5  # 42 - 0.5 = 41.5mm

        assert abs(dims[0] - expected_xy) < 0.1, f"X dimension should be ~{expected_xy}mm, got {dims[0]:.2f}mm"
        assert abs(dims[1] - expected_xy) < 0.1, f"Y dimension should be ~{expected_xy}mm, got {dims[1]:.2f}mm"

    def test_box_2x3_footprint(self):
        """2x3 box should have correct XY footprint."""
        box = GridfinityBox(2, 3, 4)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_2x3x4")

        dims = mesh.bounds[1] - mesh.bounds[0]
        expected_x = 2 * GRU - 0.5  # 83.5mm
        expected_y = 3 * GRU - 0.5  # 125.5mm

        assert abs(dims[0] - expected_x) < 0.1, f"X dimension should be ~{expected_x}mm, got {dims[0]:.2f}mm"
        assert abs(dims[1] - expected_y) < 0.1, f"Y dimension should be ~{expected_y}mm, got {dims[1]:.2f}mm"

    def test_box_height_units(self):
        """Box height should match height units (with lip and base)."""
        for height_u in [2, 3, 5]:
            box = GridfinityBox(1, 1, height_u)
            geom = box.render()
            mesh = export_and_validate_stl(geom, f"box_1x1x{height_u}")

            dims = mesh.bounds[1] - mesh.bounds[0]
            # Box height includes: base (4.75mm) + lip (~4.4mm) + interior height
            # The total is roughly height_u * 7mm + some overhead for lip
            expected_z_min = height_u * GRHU  # 7mm per height unit
            expected_z_max = height_u * GRHU + 5.0  # Allow for lip/base features

            assert (
                dims[2] >= expected_z_min
            ), f"Z dimension for {height_u}U should be >= {expected_z_min}mm, got {dims[2]:.2f}mm"
            assert (
                dims[2] <= expected_z_max
            ), f"Z dimension for {height_u}U should be <= {expected_z_max}mm, got {dims[2]:.2f}mm"

    def test_baseplate_dimensions(self):
        """Baseplate should have correct XY dimensions."""
        bp = GridfinityBaseplate(3, 4)
        geom = bp.render()
        mesh = export_and_validate_stl(geom, "baseplate_3x4")

        dims = mesh.bounds[1] - mesh.bounds[0]
        expected_x = 3 * GRU  # 126mm
        expected_y = 4 * GRU  # 168mm

        assert abs(dims[0] - expected_x) < 0.1, f"X dimension should be ~{expected_x}mm, got {dims[0]:.2f}mm"
        assert abs(dims[1] - expected_y) < 0.1, f"Y dimension should be ~{expected_y}mm, got {dims[1]:.2f}mm"


class TestMeshTopology:
    """Test mesh topology properties."""

    def test_box_valid_topology(self):
        """Box should have valid mesh topology."""
        box = GridfinityBox(2, 2, 3)
        geom = box.render()
        mesh = export_and_validate_stl(geom, "box_2x2x3")

        # Check euler number (should be 2 for a single solid without holes)
        # Complex geometry may have different euler numbers
        assert mesh.euler_number == 2, f"Euler number should be 2, got {mesh.euler_number}"

    def test_baseplate_topology(self):
        """Baseplate mesh topology check."""
        bp = GridfinityBaseplate(2, 2)
        geom = bp.render()
        mesh = export_and_validate_stl(geom, "baseplate_2x2")

        # Baseplate has internal sockets so euler number may differ
        # Just verify it's watertight and has consistent winding
        assert mesh.is_watertight, "Baseplate should be watertight"
        assert mesh.is_winding_consistent, "Baseplate should have consistent winding"
