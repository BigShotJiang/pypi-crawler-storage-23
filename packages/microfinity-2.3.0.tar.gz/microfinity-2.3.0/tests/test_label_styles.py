"""Tests for box label styles."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestLabelStyles:
    """Test different label holder styles."""

    def test_flat_label_style(self):
        """Test default flat label style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            labels=True,
            label_style="flat",
        )
        result = box.render()
        assert result is not None
        assert box.label_style == "flat"

    def test_angled_label_style(self):
        """Test angled label style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            labels=True,
            label_style="angled",
        )
        result = box.render()
        assert result is not None
        assert box.label_style == "angled"

    def test_recessed_label_style(self):
        """Test recessed label style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            labels=True,
            label_style="recessed",
        )
        result = box.render()
        assert result is not None
        assert box.label_style == "recessed"

    def test_label_style_with_dividers(self):
        """Test label styles work with internal dividers."""
        for style in ["flat", "angled", "recessed"]:
            box = GridfinityBox(
                length_u=3,
                width_u=3,
                height_u=3,
                labels=True,
                label_style=style,
                length_div=1,
                width_div=1,
            )
            result = box.render()
            assert result is not None, f"Failed for style: {style}"

    def test_invalid_label_style_raises_error(self):
        """Test that invalid label style raises ValueError."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            labels=True,
            label_style="invalid",
        )
        with pytest.raises(ValueError, match="Unknown label_style"):
            box.render()

    def test_label_style_default(self):
        """Test that default label style is 'flat'."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            labels=True,
        )
        assert box.label_style == "flat"
