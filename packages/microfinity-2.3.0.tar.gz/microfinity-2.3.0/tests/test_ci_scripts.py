"""Tests for CI helper scripts under scripts/."""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent


def _run_script(
    script: str, *args: str, env: dict[str, str] | None = None
) -> subprocess.CompletedProcess[str]:
    """Run a repo script as a subprocess."""
    cmd = [sys.executable, str(ROOT / "scripts" / script), *args]
    return subprocess.run(cmd, capture_output=True, text=True, env=env)


def _write_bench(path: Path, values: dict[str, float]) -> None:
    payload = {
        "benchmarks": [
            {
                "name": name,
                "stats": {"median": median},
            }
            for name, median in values.items()
        ]
    }
    path.write_text(json.dumps(payload), encoding="utf-8")


def test_compare_benchmarks_passes_under_threshold(tmp_path: Path) -> None:
    base = tmp_path / "base.json"
    head = tmp_path / "head.json"

    _write_bench(base, {"bench_a": 1.0, "bench_b": 2.0})
    _write_bench(head, {"bench_a": 1.05, "bench_b": 2.1})

    result = _run_script(
        "compare_benchmarks.py",
        "--base",
        str(base),
        "--head",
        str(head),
        "--threshold",
        "0.15",
    )

    assert result.returncode == 0, result.stderr
    assert "No regressions above threshold detected" in result.stdout


def test_compare_benchmarks_fails_on_regression(tmp_path: Path) -> None:
    base = tmp_path / "base.json"
    head = tmp_path / "head.json"

    _write_bench(base, {"bench_a": 1.0})
    _write_bench(head, {"bench_a": 1.3})

    result = _run_script(
        "compare_benchmarks.py",
        "--base",
        str(base),
        "--head",
        str(head),
        "--threshold",
        "0.15",
    )

    assert result.returncode == 1
    assert "Performance regressions detected" in result.stdout


def test_report_dist_sizes_json_output(tmp_path: Path) -> None:
    dist = tmp_path / "dist"
    dist.mkdir()
    (dist / "a.whl").write_bytes(b"a" * 100)
    (dist / "b.tar.gz").write_bytes(b"b" * 200)

    out = tmp_path / "report.json"
    result = _run_script(
        "report_dist_sizes.py",
        "--dist-dir",
        str(dist),
        "--json-out",
        str(out),
    )

    assert result.returncode == 0, result.stderr
    data = json.loads(out.read_text(encoding="utf-8"))
    assert data["count"] == 2
    assert data["total_bytes"] == 300
    assert {f["name"] for f in data["files"]} == {"a.whl", "b.tar.gz"}


def test_report_dist_sizes_writes_summary(tmp_path: Path) -> None:
    dist = tmp_path / "dist"
    dist.mkdir()
    (dist / "pkg.whl").write_bytes(b"x" * 64)

    out = tmp_path / "report.json"
    summary = tmp_path / "summary.md"

    env = os.environ.copy()
    env["GITHUB_STEP_SUMMARY"] = str(summary)

    result = _run_script(
        "report_dist_sizes.py",
        "--dist-dir",
        str(dist),
        "--json-out",
        str(out),
        "--summary",
        env=env,
    )

    assert result.returncode == 0, result.stderr
    text = summary.read_text(encoding="utf-8")
    assert "Distribution Size Report" in text
    assert "pkg.whl" in text
