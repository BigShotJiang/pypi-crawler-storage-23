"""Tests for box scoop variations."""

import pytest

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestScoopVariations:
    """Test different scoop styles and parameters."""

    def test_arc_scoop_style(self):
        """Test default arc scoop style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="arc",
        )
        result = box.render()
        assert result is not None
        assert box.scoop_style == "arc"

    def test_ellipse_scoop_style(self):
        """Test elliptical scoop style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="ellipse",
        )
        result = box.render()
        assert result is not None
        assert box.scoop_style == "ellipse"

    def test_slot_scoop_style(self):
        """Test slot scoop style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="slot",
        )
        result = box.render()
        assert result is not None
        assert box.scoop_style == "slot"

    def test_scoop_depth(self):
        """Test custom scoop depth."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_depth=10.0,
        )
        result = box.render()
        assert result is not None
        assert box.scoop_depth == 10.0

    def test_scoop_z_offset(self):
        """Test scoop vertical offset."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_z_offset=5.0,
        )
        result = box.render()
        assert result is not None
        assert box.scoop_z_offset == 5.0

    def test_scoop_with_dividers(self):
        """Test scoops work with internal dividers."""
        for style in ["arc", "ellipse", "slot"]:
            box = GridfinityBox(
                length_u=3,
                width_u=3,
                height_u=3,
                scoops=True,
                scoop_style=style,
                width_div=2,
            )
            result = box.render()
            assert result is not None, f"Failed for style: {style}"

    def test_scoop_depth_validation(self):
        """Test that invalid scoop depth raises error."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_depth=-1.0,
        )
        with pytest.raises(ValueError, match="Invalid scoop_depth"):
            box.render()

    def test_invalid_scoop_style_raises_error(self):
        """Test that invalid scoop style raises ValueError."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="invalid",
        )
        with pytest.raises(ValueError, match="Unknown scoop_style"):
            box.render()

    def test_scoop_micro_divisions(self):
        """Test scoops work with different micro-division levels."""
        for micro_div in [1, 2, 4]:
            for style in ["arc", "ellipse", "slot"]:
                box = GridfinityBox(
                    length_u=1.5,
                    width_u=1.5,
                    height_u=2,
                    scoops=True,
                    scoop_style=style,
                    micro_divisions=micro_div,
                )
                result = box.render()
                assert result is not None, f"Failed for micro_div={micro_div}, style={style}"

    def test_scoop_default_style(self):
        """Test that default scoop style is 'arc'."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
        )
        assert box.scoop_style == "arc"

    def test_scoop_with_labels(self):
        """Test scoops work with labels enabled."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="arc",
            labels=True,
            label_style="flat",
        )
        result = box.render()
        assert result is not None

    def test_scoop_no_lip(self):
        """Test scoops work with no stacking lip."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="slot",
            no_lip=True,
        )
        result = box.render()
        assert result is not None

    def test_scoop_lite_style(self):
        """Test scoops work with lite style."""
        box = GridfinityBox(
            length_u=2,
            width_u=2,
            height_u=3,
            scoops=True,
            scoop_style="ellipse",
            lite_style=True,
        )
        result = box.render()
        assert result is not None
