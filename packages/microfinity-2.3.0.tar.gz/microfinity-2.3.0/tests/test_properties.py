"""Property-based tests for Microfinity using Hypothesis.

These tests generate random valid inputs to catch edge cases and ensure
robustness across the parameter space.
"""

import pytest
from hypothesis import given, strategies as st, settings, assume

try:
    from microfinity import GridfinityBox

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


# Strategies for valid box parameters
length_u_strategy = st.floats(min_value=1.0, max_value=6.0).filter(lambda x: x >= 1)
width_u_strategy = st.floats(min_value=1.0, max_value=6.0).filter(lambda x: x >= 1)
height_u_strategy = st.integers(min_value=1, max_value=10)
micro_div_strategy = st.sampled_from([1, 2, 4])
wall_th_strategy = st.floats(min_value=0.5, max_value=2.5)


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestBoxProperties:
    """Property-based tests for GridfinityBox."""

    @given(
        length=length_u_strategy,
        width=width_u_strategy,
        height=height_u_strategy,
    )
    @settings(max_examples=20, deadline=30000)  # 30s per test max
    def test_box_renders_or_raises_clearly(self, length, width, height):
        """Box either renders successfully or raises ValueError with clear message."""
        try:
            box = GridfinityBox(length_u=length, width_u=width, height_u=height)
            result = box.render()
            # Should get a valid workplane back
            assert result is not None
            # Should have positive volume
            volume = result.val().Volume()
            assert volume > 0
        except ValueError as e:
            # ValueErrors should have descriptive messages
            assert len(str(e)) > 10  # Not just "error"
        except Exception as e:
            # Other exceptions are unexpected - fail the test
            pytest.fail(f"Unexpected exception: {type(e).__name__}: {e}")

    @given(
        length=length_u_strategy,
        width=width_u_strategy,
        height=height_u_strategy,
        micro=micro_div_strategy,
    )
    @settings(max_examples=15, deadline=30000)
    def test_micro_divisions_valid_or_error(self, length, width, height, micro):
        """Micro-divisions either work or raise clear error."""
        try:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=height,
                micro_divisions=micro,
            )
            result = box.render()
            assert result is not None
        except ValueError as e:
            # Should explain the constraint violation
            error_msg = str(e).lower()
            assert any(keyword in error_msg for keyword in ["micro", "multiple", "grid", "must be"])

    @given(
        length=length_u_strategy,
        width=width_u_strategy,
        height=height_u_strategy,
        wall=wall_th_strategy,
    )
    @settings(max_examples=15, deadline=30000)
    def test_wall_thickness_valid_or_error(self, length, width, height, wall):
        """Wall thickness either works or raises clear error."""
        try:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=height,
                wall_th=wall,
            )
            result = box.render()
            assert result is not None
        except ValueError as e:
            # Should explain wall thickness constraint
            error_msg = str(e).lower()
            assert "wall" in error_msg or "thickness" in error_msg


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestBoxFeatureCombos:
    """Test combinations of features work together."""

    @given(
        length=st.sampled_from([1, 2, 3]),
        width=st.sampled_from([1, 2, 3]),
        height=st.sampled_from([2, 3, 4]),
        holes=st.booleans(),
        scoops=st.booleans(),
        labels=st.booleans(),
    )
    @settings(max_examples=30, deadline=30000)
    def test_feature_combinations_render(self, length, width, height, holes, scoops, labels):
        """Common feature combinations should always render."""
        box = GridfinityBox(
            length_u=length,
            width_u=width,
            height_u=height,
            holes=holes,
            scoops=scoops,
            labels=labels,
        )
        result = box.render()
        assert result is not None
        assert result.val().Volume() > 0

    @given(
        length=st.sampled_from([2, 3, 4]),
        width=st.sampled_from([2, 3]),
        height=st.sampled_from([2, 3, 4]),
        length_div=st.integers(min_value=0, max_value=3),
        width_div=st.integers(min_value=0, max_value=3),
    )
    @settings(max_examples=20, deadline=30000)
    def test_dividers_valid_or_error(self, length, width, height, length_div, width_div):
        """Dividers either work or raise clear error."""
        assume(length > length_div)  # Must have space for dividers
        assume(width > width_div)

        try:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=height,
                length_div=length_div,
                width_div=width_div,
            )
            result = box.render()
            assert result is not None
        except ValueError as e:
            error_msg = str(e).lower()
            # Should explain divider constraint
            assert any(keyword in error_msg for keyword in ["divider", "division", "compartment", "cannot"])


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestBoxInvariants:
    """Test invariants that should always hold."""

    @given(
        length=length_u_strategy,
        width=width_u_strategy,
        height=height_u_strategy,
    )
    @settings(max_examples=15, deadline=30000)
    def test_interior_smaller_than_exterior(self, length, width, height):
        """Interior dimensions should always be smaller than exterior."""
        try:
            box = GridfinityBox(length_u=length, width_u=width, height_u=height)

            # Interior should be smaller than exterior
            assert box.inner_l < box.outer_l
            assert box.inner_w < box.outer_w

            # Interior height should be less than total height
            assert box.int_height < box.height
        except ValueError:
            # Invalid parameter combo - skip
            assume(False)

    @given(
        length=st.sampled_from([1, 2, 3]),
        width=st.sampled_from([1, 2, 3]),
        height=st.sampled_from([2, 3, 4]),
    )
    @settings(max_examples=10, deadline=30000)
    def test_filename_contains_dimensions(self, length, width, height):
        """Filename should reflect box dimensions."""
        box = GridfinityBox(length_u=length, width_u=width, height_u=height)
        filename = box.filename()

        # Filename should contain dimensions
        assert str(int(length)) in filename or str(length) in filename
        assert str(int(width)) in filename or str(width) in filename
        assert str(height) in filename


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestDrawerStyleProperties:
    """Property-based tests for drawer-style boxes."""

    @given(
        length=st.sampled_from([2, 3]),
        width=st.sampled_from([2, 3]),
        height=st.sampled_from([3, 4, 5]),
        fp_depth=st.floats(min_value=5.0, max_value=15.0),
        fp_height=st.floats(min_value=8.0, max_value=20.0),
    )
    @settings(max_examples=15, deadline=30000)
    def test_drawer_with_finger_pull_renders(self, length, width, height, fp_depth, fp_height):
        """Drawer boxes with various finger pull sizes should render."""
        try:
            box = GridfinityBox(
                length_u=length,
                width_u=width,
                height_u=height,
                drawer_style=True,
                finger_pull_depth=fp_depth,
                finger_pull_height=fp_height,
            )
            result = box.render()
            assert result is not None
            # Drawer implies no_lip
            assert box.no_lip is True
        except ValueError as e:
            # Should explain constraint violation (e.g., depth too large)
            error_msg = str(e).lower()
            assert "finger" in error_msg or "depth" in error_msg or "cannot" in error_msg


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestWeightedBaseProperties:
    """Property-based tests for weighted base boxes."""

    @given(
        length=st.sampled_from([1, 2, 3]),
        width=st.sampled_from([1, 2, 3]),
        height=st.sampled_from([2, 3, 4]),
        extra=st.floats(min_value=0.0, max_value=10.0),
    )
    @settings(max_examples=15, deadline=30000)
    def test_weighted_base_increases_floor(self, length, width, height, extra):
        """Weighted base should always increase floor height."""
        box_normal = GridfinityBox(length_u=length, width_u=width, height_u=height)
        box_weighted = GridfinityBox(
            length_u=length,
            width_u=width,
            height_u=height,
            weighted_base=True,
            base_extra_mm=extra,
        )

        # Weighted should have higher floor
        assert box_weighted.floor_h >= box_normal.floor_h
        # Should be at least 2mm more (default) or explicit extra
        if extra > 0:
            assert box_weighted.floor_h == box_normal.floor_h + extra
        else:
            assert box_weighted.floor_h == box_normal.floor_h + 2.0
