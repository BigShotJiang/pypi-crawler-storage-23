"""Tests for debug visualization utilities."""

import pytest
import tempfile
from pathlib import Path

try:
    from microfinity import GridfinityBox
    from microfinity.debug.visualization import (
        export_wireframe_svg,
        extract_wireframe_from_workplane,
        create_exploded_view,
    )

    CADQUERY_AVAILABLE = True
except ImportError:
    CADQUERY_AVAILABLE = False


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestDebugVisualization:
    """Test debug visualization utilities."""

    def test_wireframe_svg_export(self):
        """Test wireframe SVG export creates valid file."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        vertices, edges = extract_wireframe_from_workplane(result)

        with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            export_wireframe_svg(
                vertices=vertices,
                edges=edges,
                output_path=tmp_path,
                view="front",
            )

            # Check file exists and has content
            assert Path(tmp_path).exists()
            content = Path(tmp_path).read_text()
            assert "svg" in content.lower()
            assert "wireframe" in content.lower()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def test_wireframe_extraction_returns_data(self):
        """Test wireframe extraction returns vertices and edges."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        vertices, edges = extract_wireframe_from_workplane(result)

        # Should have some vertices and edges
        assert len(vertices) > 0
        assert len(edges) > 0

        # Vertices should be 3D
        for v in vertices:
            assert len(v) == 3

        # Edges should reference valid vertices
        for e in edges:
            assert len(e) == 2
            assert 0 <= e[0] < len(vertices)
            assert 0 <= e[1] < len(vertices)

    def test_wireframe_different_views(self):
        """Test wireframe export with different views."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        vertices, edges = extract_wireframe_from_workplane(result)

        for view in ["front", "top", "side", "iso"]:
            with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
                tmp_path = tmp.name

            try:
                export_wireframe_svg(
                    vertices=vertices,
                    edges=edges,
                    output_path=tmp_path,
                    view=view,
                )

                assert Path(tmp_path).exists()
                content = Path(tmp_path).read_text()
                assert view.lower() in content.lower()
            finally:
                Path(tmp_path).unlink(missing_ok=True)

    def test_exploded_view_creation(self):
        """Test exploded view creation."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3)

        # Get components
        components = []
        shell = box.render_shell()
        if shell is not None:
            components.append(shell)

        dividers = box.render_dividers()
        if dividers is not None:
            components.append(dividers)

        if len(components) >= 2:
            exploded = create_exploded_view(components, explode_distance=10.0)
            assert len(exploded) == len(components)

    def test_exploded_view_different_directions(self):
        """Test exploded view in different directions."""
        box = GridfinityBox(length_u=2, width_u=2, height_u=3, length_div=1)

        components = [box.render_shell(), box.render_dividers()]
        components = [c for c in components if c is not None]

        if len(components) >= 2:
            for direction in ["x", "y", "z"]:
                exploded = create_exploded_view(
                    components, explode_distance=5.0, direction=direction
                )
                assert len(exploded) == len(components)


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestSliceInspector:
    """Test slice inspector functionality."""

    def test_generate_cross_section_svg(self):
        """Test cross-section SVG generation."""
        from microfinity.debug.visualization import generate_cross_section_svg

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            generate_cross_section_svg(
                workplane=result,
                z_level=5.0,
                output_path=tmp_path,
            )

            assert Path(tmp_path).exists()
            content = Path(tmp_path).read_text()
            assert "svg" in content.lower()
            assert "cross" in content.lower() or "slice" in content.lower()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def test_cross_section_different_z_levels(self):
        """Test cross-section at different Z levels."""
        from microfinity.debug.visualization import generate_cross_section_svg

        box = GridfinityBox(length_u=2, width_u=2, height_u=4)
        result = box.render()

        for z_level in [1.0, 5.0, 10.0, 15.0]:
            with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
                tmp_path = tmp.name

            try:
                generate_cross_section_svg(
                    workplane=result,
                    z_level=z_level,
                    output_path=tmp_path,
                )

                assert Path(tmp_path).exists()
                content = Path(tmp_path).read_text()
                assert str(z_level) in content or f"{z_level:.1f}" in content
            finally:
                Path(tmp_path).unlink(missing_ok=True)

    def test_cross_section_options(self):
        """Test cross-section with different options."""
        from microfinity.debug.visualization import generate_cross_section_svg

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        with tempfile.NamedTemporaryFile(suffix=".svg", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            generate_cross_section_svg(
                workplane=result,
                z_level=5.0,
                output_path=tmp_path,
                show_grid=False,
                show_dimensions=False,
            )

            assert Path(tmp_path).exists()
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def test_inspect_slices_multiple(self):
        """Test multiple slice generation."""
        from microfinity.debug.visualization import inspect_slices

        box = GridfinityBox(length_u=2, width_u=2, height_u=4)
        result = box.render()

        with tempfile.TemporaryDirectory() as tmp_dir:
            slices = inspect_slices(
                workplane=result,
                z_start=0.0,
                z_end=20.0,
                num_slices=3,
                output_dir=tmp_dir,
            )

            assert len(slices) == 3
            for s in slices:
                assert Path(s).exists()

    def test_debug_stl_export(self):
        """Test debug STL export with bounding box and axes."""
        from microfinity.debug.visualization import export_debug_stl

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        with tempfile.NamedTemporaryFile(suffix=".stl", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            export_debug_stl(
                workplane=result,
                output_path=tmp_path,
                include_bounding_box=True,
                include_axes=True,
                include_grid=False,
            )

            assert Path(tmp_path).exists()
            assert Path(tmp_path).stat().st_size > 0
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def test_debug_stl_with_grid(self):
        """Test debug STL export with grid overlay."""
        from microfinity.debug.visualization import export_debug_stl

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)
        result = box.render()

        with tempfile.NamedTemporaryFile(suffix=".stl", delete=False) as tmp:
            tmp_path = tmp.name

        try:
            export_debug_stl(
                workplane=result,
                output_path=tmp_path,
                include_bounding_box=False,
                include_axes=False,
                include_grid=True,
                grid_spacing=10.0,
            )

            assert Path(tmp_path).exists()
            assert Path(tmp_path).stat().st_size > 0
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    def test_intermediate_mesh_export(self):
        """Test intermediate mesh export."""
        from microfinity.debug.visualization import export_intermediate_meshes

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)

        with tempfile.TemporaryDirectory() as tmp_dir:
            paths = export_intermediate_meshes(
                box=box,
                output_dir=tmp_dir,
                base_name="test",
                formats=["stl"],
            )

            assert len(paths) > 0
            for stage, path in paths.items():
                assert Path(path).exists()

    def test_diagnostic_dump(self):
        """Test diagnostic dump generation."""
        from microfinity.debug.visualization import generate_diagnostic_dump
        import json

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)

        diagnostic = generate_diagnostic_dump(box=box, include_timing=True)

        assert "version" in diagnostic
        assert "box_configuration" in diagnostic
        assert "dimensions" in diagnostic["box_configuration"]
        assert "features" in diagnostic
        assert "timing" in diagnostic

    def test_diagnostic_dump_no_timing(self):
        """Test diagnostic dump without timing."""
        from microfinity.debug.visualization import generate_diagnostic_dump

        box = GridfinityBox(length_u=2, width_u=2, height_u=3)

        diagnostic = generate_diagnostic_dump(box=box, include_timing=False)

        assert "timing" not in diagnostic


@pytest.mark.skipif(not CADQUERY_AVAILABLE, reason="CadQuery not installed")
class TestDebugCLI:
    """Test debug CLI commands."""

    def test_debug_measure_command(self):
        """Test debug measure command."""
        import subprocess
        import sys

        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "debug", "measure", "2", "2", "3"],
            capture_output=True,
            text=True,
        )

        # Should succeed and show measurements
        assert result.returncode == 0
        assert "Box:" in result.stdout or "dimensions" in result.stdout.lower()

    def test_debug_measure_json_output(self):
        """Test debug measure command with JSON output."""
        import subprocess
        import sys
        import json

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "microfinity",
                "debug",
                "measure",
                "2",
                "2",
                "3",
                "--json",
            ],
            capture_output=True,
            text=True,
        )

        assert result.returncode == 0
        # Should be valid JSON
        data = json.loads(result.stdout)
        assert "dimensions" in data
        assert "outer" in data
        assert "inner" in data

    def test_debug_wireframe_command(self, tmp_path):
        """Test debug wireframe command."""
        import subprocess
        import sys

        output_file = tmp_path / "test_wireframe.svg"

        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "microfinity",
                "debug",
                "wireframe",
                "2",
                "2",
                "3",
                "-o",
                str(output_file),
            ],
            capture_output=True,
            text=True,
        )

        # May succeed or fail depending on wireframe extraction
        # but should not crash
        assert result.returncode in [0, 1]

    def test_debug_no_subcommand_shows_help(self):
        """Test debug without subcommand shows help."""
        import subprocess
        import sys

        result = subprocess.run(
            [sys.executable, "-m", "microfinity", "debug"],
            capture_output=True,
            text=True,
        )

        # Should show help (return code may vary)
        assert (
            "wireframe" in result.stdout.lower() or "measure" in result.stdout.lower()
        )
