#! /usr/bin/env python3
"""
microfinity.cq.extrude - Multi-segment profile extrusion.

Provides extrude_profile() for extruding sketches through multi-segment
profiles with optional tapers. Used for generating Gridfinity foot geometry.
"""

from __future__ import annotations

import math
from math import sqrt
from typing import List, Optional, Tuple, Union

import cadquery as cq

from microfinity.cq.compat import ZLEN_FIX

SQRT2 = sqrt(2)


def extrude_profile(
    sketch,
    profile: List[Union[float, Tuple[float, float]]],
    workplane: str = "XY",
    angle: Optional[float] = None,
) -> cq.Workplane:
    """Extrude a sketch through a multi-segment profile with optional tapers.

    The profile is a list of segments, where each segment is either:
    - A float: straight extrusion of that height
    - A tuple (height, taper_angle): tapered extrusion

    Args:
        sketch: CadQuery sketch to extrude
        profile: List of profile segments
        workplane: Workplane orientation (default "XY")
        angle: Override angle for taper calculations

    Returns:
        CadQuery Workplane with the extruded geometry
    """
    taper = profile[0][1] if isinstance(profile[0], (list, tuple)) else 0
    zlen = profile[0][0] if isinstance(profile[0], (list, tuple)) else profile[0]

    if abs(taper) > 0:
        if angle is None:
            zlen = zlen if ZLEN_FIX else zlen / SQRT2
        else:
            zlen = zlen / math.cos(math.radians(taper)) if ZLEN_FIX else zlen

    r = cq.Workplane(workplane).placeSketch(sketch).extrude(zlen, taper=taper)

    for level in profile[1:]:
        if isinstance(level, (tuple, list)):
            if angle is None:
                zlen = level[0] if ZLEN_FIX else level[0] / SQRT2
            else:
                zlen = level[0] / math.cos(math.radians(level[1])) if ZLEN_FIX else level[0]
            r = r.faces(">Z").wires().toPending().extrude(zlen, taper=level[1])
        else:
            r = r.faces(">Z").wires().toPending().extrude(level)

    return r
