#! /usr/bin/env python3
"""
microfinity.cq - CadQuery utilities and compatibility layer.

This module provides CadQuery-specific utilities including version detection,
profile extrusion, geometry helpers, and file export.

Shared by both microfinity and meshcutter.
"""

from microfinity.cq.compat import ZLEN_FIX
from microfinity.cq.extrude import extrude_profile
from microfinity.cq.helpers import union_all, quarter_circle, chamf_cyl, chamf_rect
from microfinity.cq.export import GridfinityExporter, SVGView

__all__ = [
    "ZLEN_FIX",
    "extrude_profile",
    "union_all",
    "quarter_circle",
    "chamf_cyl",
    "chamf_rect",
    "GridfinityExporter",
    "SVGView",
]
