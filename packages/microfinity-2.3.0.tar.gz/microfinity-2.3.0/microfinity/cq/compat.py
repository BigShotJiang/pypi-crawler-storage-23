#! /usr/bin/env python3
"""
microfinity.cq.compat - CadQuery version detection and compatibility.

CQ versions < 2.4.0 typically require zlen correction for tapered extrusions,
i.e., scaling the vertical extrusion extent by 1/cos(taper).
"""

from __future__ import annotations

import cadquery as cq

# Test which version of CadQuery is installed and whether compensation
# is required for extruded zlen.
ZLEN_FIX: bool = True
_test_result = cq.Workplane("XY").rect(2, 2).extrude(1, taper=45)
_test_bb = _test_result.vals()[0].BoundingBox()
if abs(_test_bb.zlen - 1.0) < 1e-3:
    ZLEN_FIX = False
