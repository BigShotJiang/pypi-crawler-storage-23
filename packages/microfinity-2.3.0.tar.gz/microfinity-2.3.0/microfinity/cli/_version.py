"""Standalone CLI modules that don't depend on cadquery.

These modules are designed to be imported without triggering the full
microfinity module load (which requires cadquery).
"""

# Version info (duplicated here to avoid importing microfinity)
__version__ = "2.1.0"
