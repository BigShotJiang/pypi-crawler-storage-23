"""
Base types for CLI configuration.
"""

from enum import Enum


class LogLevel(str, Enum):
    """Logging verbosity levels."""

    DEBUG = "debug"
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    CRITICAL = "critical"


class OutputFormat(str, Enum):
    """Output file formats."""

    STL = "stl"
    STEP = "step"
    SVG = "svg"
