"""
Custom settings sources for pydantic-settings.

Implements YAML config file loading with proper precedence.
"""

import contextvars
import os
from pathlib import Path
from typing import Any, Tuple, Type

import yaml
from pydantic.fields import FieldInfo
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource


# Context variable to pass yaml path from load_settings to YamlConfigSource
_yaml_path_context: contextvars.ContextVar[Path | None] = contextvars.ContextVar("_yaml_path_context", default=None)


def set_yaml_path(path: Path | None) -> contextvars.Token:
    """Set the YAML config path for the current context."""
    return _yaml_path_context.set(path)


def reset_yaml_path(token: contextvars.Token) -> None:
    """Reset the YAML config path to its previous value."""
    _yaml_path_context.reset(token)


class YamlConfigSource(PydanticBaseSettingsSource):
    """
    Load settings from a YAML configuration file.

    Path resolution order:
    1. Context variable (set by load_settings)
    2. MICROFINITY_CONFIG environment variable
    3. Default: ./microfinity.yaml
    """

    def __init__(self, settings_cls: Type[BaseSettings]):
        super().__init__(settings_cls)
        self._data = self._load_yaml()

    def _get_yaml_path(self) -> Path | None:
        """Get the YAML config path from context, env, or default."""
        # 1. Check context variable (set by load_settings)
        context_path = _yaml_path_context.get()
        if context_path is not None:
            return context_path

        # 2. Check environment variable
        env_path = os.environ.get("MICROFINITY_CONFIG")
        if env_path:
            return Path(env_path)

        # 3. Default path
        default_path = Path("microfinity.yaml")
        if default_path.exists():
            return default_path

        return None

    def _load_yaml(self) -> dict[str, Any]:
        """Load YAML config file if it exists."""
        yaml_path = self._get_yaml_path()

        if yaml_path is None:
            return {}

        if not yaml_path.exists():
            return {}

        with open(yaml_path) as f:
            return yaml.safe_load(f) or {}

    def get_field_value(self, field: FieldInfo, field_name: str) -> Tuple[Any, str, bool]:
        """Get a field value from the YAML data."""
        value = self._data.get(field_name)
        return value, field_name, value is not None

    def __call__(self) -> dict[str, Any]:
        """Return all settings from YAML."""
        return self._data
