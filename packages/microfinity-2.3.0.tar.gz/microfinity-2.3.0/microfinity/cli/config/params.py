"""
Parameter models for CLI commands.

These represent the complete set of parameters for each command,
combining required positional args with optional settings.
"""

from pathlib import Path

from pydantic import BaseModel, Field

from .base import OutputFormat


class BoxParams(BaseModel):
    """Complete parameters for box generation."""

    # Required positional arguments
    length_u: float = Field(..., description="Box length in U (1U = 42mm)")
    width_u: float = Field(..., description="Box width in U")
    height_u: int = Field(..., description="Box height in U (1U = 7mm)")

    # Options with defaults
    micro: int = Field(default=4, ge=1, le=4, description="Micro-grid divisions")
    format: OutputFormat = Field(default=OutputFormat.STEP, description="Output format")
    output: Path | None = Field(default=None, description="Output file path")
    output_dir: Path | None = Field(default=None, description="Output directory")

    # Boolean options
    magnets: bool = Field(default=True, description="Add magnet holes")
    unsupported: bool = Field(default=False, description="Unsupported magnet holes")
    solid: bool = Field(default=False, description="Solid infill")
    lite: bool = Field(default=False, description="Lite style (thin walls)")
    scoops: bool = Field(default=True, description="Add finger scoops")
    labels: bool = Field(default=False, description="Add label strip")
    lip: bool = Field(default=True, description="Stacking lip")

    # Optional numeric values
    solid_ratio: float | None = Field(default=None, ge=0, le=1, description="Solid fill ratio")
    label_height: float | None = Field(default=None, gt=0, description="Label height in mm")
    dividers_x: int | None = Field(default=None, ge=0, description="Dividers along length")
    dividers_y: int | None = Field(default=None, ge=0, description="Dividers along width")
    wall: float | None = Field(default=None, gt=0, description="Wall thickness in mm")
    floor: float | None = Field(default=None, gt=0, description="Floor thickness in mm")

    def to_gridfinity_kwargs(self) -> dict:
        """Convert to kwargs for GridfinityBox constructor."""
        kwargs = {
            "length_u": self.length_u,
            "width_u": self.width_u,
            "height_u": self.height_u,
            "micro_divisions": self.micro,
            "holes": self.magnets,
            "unsupported_holes": self.unsupported,
            "solid": self.solid,
            "lite_style": self.lite,
            "scoops": self.scoops,
            "labels": self.labels,
            "no_lip": not self.lip,  # Invert: lip=True means no_lip=False
        }

        # Only include optional values if set
        if self.solid_ratio is not None:
            kwargs["solid_ratio"] = self.solid_ratio
        if self.label_height is not None:
            kwargs["label_height"] = self.label_height
        if self.dividers_x is not None:
            kwargs["length_div"] = self.dividers_x
        if self.dividers_y is not None:
            kwargs["width_div"] = self.dividers_y
        if self.wall is not None:
            kwargs["wall_th"] = self.wall
        if self.floor is not None:
            kwargs["floor_th"] = self.floor

        return kwargs


class BaseplateParams(BaseModel):
    """Complete parameters for baseplate generation."""

    # Required positional arguments (float to support fractional U and mm)
    length: float = Field(..., description="Baseplate length")
    width: float = Field(..., description="Baseplate width")

    # Units specification
    units: str = Field(default="u", description="Input units: u or mm")

    # Options
    micro: int = Field(default=4, ge=1, le=4, description="Micro-grid divisions")
    format: OutputFormat = Field(default=OutputFormat.STEP, description="Output format")
    output: Path | None = Field(default=None, description="Output file path")
    output_dir: Path | None = Field(default=None, description="Output directory")

    # Construction options
    ext_depth: float = Field(default=0.0, ge=0, description="Extra bottom extrusion in mm")
    straight_bottom: bool = Field(default=False, description="Remove bottom chamfer")
    corner_fillet: float = Field(default=3.75, ge=0, description="Corner radius in mm")

    def to_gridfinity_kwargs(self) -> dict:
        """Convert to kwargs for GridfinityBaseplate constructor.

        When units='mm', calculates micro-cells and fill amounts.
        """
        from microfinity.spec.constants import GRU

        micro_pitch = GRU / self.micro

        if self.units == "mm":
            # Calculate micro-cells that fit
            cells_x = int(self.length // micro_pitch)
            cells_y = int(self.width // micro_pitch)

            # Calculate fill for edges
            fill_x = self.length - (cells_x * micro_pitch)
            fill_y = self.width - (cells_y * micro_pitch)

            # Convert cells to U (fractional)
            length_u = cells_x / self.micro
            width_u = cells_y / self.micro

            return {
                "length_u": length_u,
                "width_u": width_u,
                "micro_divisions": self.micro,
                "ext_depth": self.ext_depth,
                "straight_bottom": self.straight_bottom,
                "corner_fillet": self.corner_fillet,
                # Fill on +X and +Y edges
                "solid_fill": {
                    "right": fill_x / 2,
                    "left": fill_x / 2,
                    "back": fill_y / 2,
                    "front": fill_y / 2,
                },
            }
        else:
            # Units = 'u' - direct U specification
            return {
                "length_u": self.length,
                "width_u": self.width,
                "micro_divisions": self.micro,
                "ext_depth": self.ext_depth,
                "straight_bottom": self.straight_bottom,
                "corner_fillet": self.corner_fillet,
            }


class MeshcutParams(BaseModel):
    """Complete parameters for meshcut operation."""

    # Required arguments
    input: Path = Field(..., description="Input STL or 3MF file")
    output: Path = Field(..., description="Output STL file")

    # Options
    micro: int = Field(default=4, ge=1, le=4, description="Micro-divisions per unit")

    # Boolean options
    auto_overshoot: bool = Field(default=True, description="Auto 0.35mm overshoot for multi-cell")
    channels: bool = Field(default=True, description="Add inter-cell channels")
    force_z_up: bool = Field(default=False, description="Assume Z-up orientation")
    repair: bool = Field(default=False, description="Attempt mesh repair")
    skip_clean: bool = Field(default=False, description="Skip post-processing cleanup")
    skip_validate: bool = Field(default=False, description="Skip validation checks")

    # Numeric options
    depth: float | None = Field(default=None, gt=0, description="Cut depth in mm")
    epsilon: float | None = Field(default=None, gt=0, description="Coplanar offset in mm")
    overshoot: float = Field(default=0.0, ge=0, description="Cutter overshoot in mm")
    wall_cut: float = Field(default=0.0, ge=0, description="Wall cut amount in mm")
    z_tolerance: float = Field(default=0.1, gt=0, description="Z detection tolerance in mm")


class LayoutParams(BaseModel):
    """Complete parameters for layout generation."""

    # Required arguments (drawer dimensions in mm)
    drawer_x: float = Field(..., gt=0, description="Drawer interior width in mm")
    drawer_y: float = Field(..., gt=0, description="Drawer interior depth in mm")

    # Build plate
    build_x: float = Field(default=220.0, gt=0, description="Build plate X dimension in mm")
    build_y: float = Field(default=220.0, gt=0, description="Build plate Y dimension in mm")
    margin: float = Field(default=5.0, ge=0, description="Safety margin from build plate edge")

    # Grid
    micro: int = Field(default=4, ge=1, le=4, description="Micro-divisions")
    tolerance: float = Field(default=0.5, ge=0, description="Clearance gap in mm")

    # Output
    output_dir: Path = Field(default=Path("./layout"), description="Output directory")
    format: OutputFormat = Field(default=OutputFormat.STL, description="Output format")
    summary: bool = Field(default=False, description="Print summary only, no files")
