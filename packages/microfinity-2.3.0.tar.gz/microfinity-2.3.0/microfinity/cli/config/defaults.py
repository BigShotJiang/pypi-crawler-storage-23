"""
Default configuration models for each command.

These are loaded from YAML/env and provide defaults for CLI options.
Only include options that make sense as persistent defaults (not positional args).
"""

from pydantic import BaseModel, Field

from .base import OutputFormat


class BoxDefaults(BaseModel):
    """Default values for box command options."""

    micro: int = Field(default=4, ge=1, le=4, description="Micro-grid divisions per unit")
    format: OutputFormat = Field(default=OutputFormat.STEP, description="Output file format")

    # Boolean options - defaults per v2.0.0 spec
    magnets: bool = Field(default=True, description="Add magnet holes")
    unsupported: bool = Field(default=False, description="Unsupported magnet holes")
    solid: bool = Field(default=False, description="Solid infill")
    lite: bool = Field(default=False, description="Lite style (thin walls)")
    scoops: bool = Field(default=True, description="Add finger scoops")
    labels: bool = Field(default=False, description="Add label strip")
    lip: bool = Field(default=True, description="Stacking lip")

    # Optional numeric values (None = use GridfinityBox defaults)
    solid_ratio: float | None = Field(default=None, ge=0, le=1, description="Solid fill ratio")
    label_height: float | None = Field(default=None, gt=0, description="Label height in mm")
    dividers_x: int | None = Field(default=None, ge=0, description="Dividers along length")
    dividers_y: int | None = Field(default=None, ge=0, description="Dividers along width")
    wall: float | None = Field(default=None, gt=0, description="Wall thickness in mm")
    floor: float | None = Field(default=None, gt=0, description="Floor thickness in mm")


class BaseplateDefaults(BaseModel):
    """Default values for baseplate command options."""

    micro: int = Field(default=4, ge=1, le=4, description="Micro-grid divisions per unit")
    format: OutputFormat = Field(default=OutputFormat.STEP, description="Output file format")

    # Construction options
    ext_depth: float = Field(default=0.0, ge=0, description="Extra bottom extrusion in mm")
    straight_bottom: bool = Field(default=False, description="Remove bottom chamfer")
    corner_fillet: float = Field(default=3.75, ge=0, description="Corner radius in mm")


class MeshcutDefaults(BaseModel):
    """Default values for meshcut command options."""

    micro: int = Field(default=4, ge=1, le=4, description="Micro-divisions per unit")

    # Boolean options
    auto_overshoot: bool = Field(default=True, description="Auto 0.35mm overshoot for multi-cell")
    channels: bool = Field(default=True, description="Add inter-cell channels")
    force_z_up: bool = Field(default=False, description="Assume Z-up orientation")
    repair: bool = Field(default=False, description="Attempt mesh repair")
    skip_clean: bool = Field(default=False, description="Skip post-processing cleanup")
    skip_validate: bool = Field(default=False, description="Skip validation checks")

    # Numeric options with defaults
    depth: float | None = Field(default=None, gt=0, description="Cut depth in mm")
    epsilon: float | None = Field(default=None, gt=0, description="Coplanar offset in mm")
    overshoot: float = Field(default=0.0, ge=0, description="Cutter overshoot in mm")
    wall_cut: float = Field(default=0.0, ge=0, description="Wall cut amount in mm")
    z_tolerance: float = Field(default=0.1, gt=0, description="Z detection tolerance in mm")


class LayoutDefaults(BaseModel):
    """Default values for layout command options."""

    micro: int = Field(default=4, ge=1, le=4, description="Micro-divisions per unit")
    format: OutputFormat = Field(default=OutputFormat.STL, description="Output file format")

    # Build plate defaults
    build_x: float = Field(default=220.0, gt=0, description="Build plate X dimension in mm")
    build_y: float = Field(default=220.0, gt=0, description="Build plate Y dimension in mm")
    margin: float = Field(default=5.0, ge=0, description="Safety margin from build plate edge")

    # Grid options
    tolerance: float = Field(default=0.5, ge=0, description="Clearance gap in mm")


class DebugDefaults(BaseModel):
    """Default values for debug subcommands."""

    format: OutputFormat = Field(default=OutputFormat.STEP, description="Output file format")
