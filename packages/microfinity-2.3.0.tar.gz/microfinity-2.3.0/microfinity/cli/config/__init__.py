"""
Configuration module for microfinity CLI.

Provides typed configuration models with Viper-like precedence:
CLI > Environment > YAML > Defaults
"""

from .base import LogLevel, OutputFormat
from .defaults import BaseplateDefaults, BoxDefaults, DebugDefaults, LayoutDefaults, MeshcutDefaults
from .settings import MicrofinitySettings, load_settings

__all__ = [
    # Enums
    "LogLevel",
    "OutputFormat",
    # Default models
    "BoxDefaults",
    "BaseplateDefaults",
    "MeshcutDefaults",
    "LayoutDefaults",
    "DebugDefaults",
    # Settings
    "MicrofinitySettings",
    "load_settings",
]
