"""
Root settings model with Viper-like precedence.

Precedence (first wins):
1. CLI kwargs passed to __init__
2. Environment variables (MICROFINITY_*)
3. YAML config file (./microfinity.yaml or --config PATH)
4. Model defaults
"""

from pathlib import Path
from typing import Any, Tuple, Type

from pydantic_settings import BaseSettings, PydanticBaseSettingsSource, SettingsConfigDict

from .base import LogLevel
from .defaults import BaseplateDefaults, BoxDefaults, DebugDefaults, LayoutDefaults, MeshcutDefaults
from .sources import YamlConfigSource, reset_yaml_path, set_yaml_path


class MicrofinitySettings(BaseSettings):
    """
    Root configuration for microfinity CLI.

    Load order (later overrides earlier):
    1. Model defaults
    2. YAML config file
    3. Environment variables
    4. Constructor kwargs (CLI overrides)
    """

    model_config = SettingsConfigDict(
        env_prefix="MICROFINITY_",
        env_nested_delimiter="__",
        extra="ignore",  # Unknown keys in YAML/env are ignored
    )

    # Global settings
    log_level: LogLevel = LogLevel.INFO

    # Per-command defaults (nested)
    box: BoxDefaults = BoxDefaults()
    baseplate: BaseplateDefaults = BaseplateDefaults()
    meshcut: MeshcutDefaults = MeshcutDefaults()
    layout: LayoutDefaults = LayoutDefaults()
    debug: DebugDefaults = DebugDefaults()

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls: Type[BaseSettings],
        init_settings: PydanticBaseSettingsSource,
        env_settings: PydanticBaseSettingsSource,
        dotenv_settings: PydanticBaseSettingsSource,
        file_secret_settings: PydanticBaseSettingsSource,
    ) -> Tuple[PydanticBaseSettingsSource, ...]:
        """
        Customize settings source precedence.

        Order (first has highest priority):
        1. init_settings - kwargs passed to __init__ (CLI overrides)
        2. env_settings - MICROFINITY_* environment variables
        3. YamlConfigSource - ./microfinity.yaml or explicit path

        Defaults are implicit (lowest priority).
        """
        return (
            init_settings,
            env_settings,
            YamlConfigSource(settings_cls),
        )


def load_settings(
    config_path: Path | None = None,
    ignore_invalid: bool = False,
    **cli_overrides: Any,
) -> MicrofinitySettings:
    """
    Load settings with full precedence chain.

    Args:
        config_path: Explicit path to YAML config file
        ignore_invalid: If True, log warning and use defaults on validation errors.
                       If False (default), raise ValidationError.
        **cli_overrides: CLI option overrides (highest precedence)

    Returns:
        Resolved MicrofinitySettings

    Raises:
        pydantic.ValidationError: If config is invalid and ignore_invalid=False
    """
    import logging

    from pydantic import ValidationError

    logger = logging.getLogger(__name__)

    # Set the yaml path in context for YamlConfigSource to pick up
    token = set_yaml_path(config_path)
    try:
        return MicrofinitySettings(**cli_overrides)
    except ValidationError as e:
        if ignore_invalid:
            logger.warning("Config validation error, using defaults: %s", e)
            # Clear overrides and create with just defaults
            # Also need to temporarily clear env vars that caused the error
            # This is tricky - for now just return raw defaults
            return MicrofinitySettings.model_construct(
                log_level=LogLevel.INFO,
                box=BoxDefaults(),
                baseplate=BaseplateDefaults(),
                meshcut=MeshcutDefaults(),
                layout=LayoutDefaults(),
                debug=DebugDefaults(),
            )
        raise
    finally:
        reset_yaml_path(token)
