"""Legacy entry point for backward compatibility with tests.

Use `from microfinity.cli import cli` or the `microfinity` console script instead.
"""

from .app import cli

if __name__ == "__main__":
    cli()
