"""Configuration loading and validation for microfinity CLI.

Supports XDG-compliant config discovery and layered configuration:
CLI args > config file > XDG user config > defaults
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import yaml

# XDG Base Directory paths
XDG_CONFIG_HOME = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
XDG_CONFIG_DIRS = [Path(p) for p in os.environ.get("XDG_CONFIG_DIRS", "/etc/xdg").split(":")]

# Config file names (in order of preference)
CONFIG_NAMES = ["microfinity.yml", ".microfinity.yml"]


def find_config_file(explicit_path: Optional[Path] = None) -> Optional[Path]:
    """Find config file using XDG-compliant discovery.

    Search order:
    1. Explicit --config path
    2. Project-local ./microfinity.yml or ./.microfinity.yml
    3. XDG user config: $XDG_CONFIG_HOME/microfinity/config.yml
    4. System configs in $XDG_CONFIG_DIRS

    Args:
        explicit_path: Path from --config flag

    Returns:
        Path to config file or None if not found
    """
    # 1. Explicit path
    if explicit_path is not None:
        if explicit_path.exists():
            return explicit_path
        raise FileNotFoundError(f"Config file not found: {explicit_path}")

    # 2. Project-local configs
    cwd = Path.cwd()
    for name in CONFIG_NAMES:
        local_path = cwd / name
        if local_path.exists():
            return local_path

    # 3. XDG user config
    user_config_dir = XDG_CONFIG_HOME / "microfinity"
    user_config = user_config_dir / "config.yml"
    if user_config.exists():
        return user_config

    # 4. System configs
    for config_dir in XDG_CONFIG_DIRS:
        system_config = config_dir / "microfinity" / "config.yml"
        if system_config.exists():
            return system_config

    return None


def load_yaml_config(path: Path) -> Dict[str, Any]:
    """Load YAML config file.

    Args:
        path: Path to YAML file

    Returns:
        Dictionary of config values

    Raises:
        FileNotFoundError: If file doesn't exist
        yaml.YAMLError: If YAML is invalid
    """
    with open(path, "r") as f:
        content = yaml.safe_load(f)

    if content is None:
        return {}

    if not isinstance(content, dict):
        raise ValueError(f"Config file must contain a YAML mapping, got {type(content).__name__}")

    return content


def merge_configs(base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
    """Deep merge two config dictionaries.

    Override values take precedence. Nested dicts are merged recursively.

    Args:
        base: Base configuration
        override: Override configuration

    Returns:
        Merged configuration
    """
    result = base.copy()

    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = merge_configs(result[key], value)
        else:
            result[key] = value

    return result


def load_config(explicit_path: Optional[Path] = None, defaults: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Load and merge configuration from all sources.

    Precedence (highest to lowest):
    1. Explicit path (--config)
    2. Project-local config
    3. XDG user config
    4. Defaults

    Args:
        explicit_path: Path from --config flag
        defaults: Default configuration values

    Returns:
        Merged configuration dictionary
    """
    config = defaults or {}

    # Find config file
    config_path = find_config_file(explicit_path)

    if config_path is not None:
        loaded = load_yaml_config(config_path)
        config = merge_configs(config, loaded)

    return config


def get_default_config() -> Dict[str, Any]:
    """Get default configuration values.

    Returns:
        Dictionary of default config values
    """
    return {
        "output": {
            "dir": None,
            "format": "step",
        },
        "defaults": {
            "box": {
                "micro_divisions": 4,
                "wall_thickness": 1.0,
                "floor_thickness": 1.0,
                "magnet_holes": False,
                "unsupported_holes": False,
                "solid": False,
                "solid_ratio": None,
                "lite_style": False,
                "scoops": False,
                "scoop_depth": None,
                "scoop_z_offset": 0,
                "scoop_style": "arc",
                "labels": False,
                "label_style": "flat",
                "label_height": None,
                "no_lip": False,
                "drawer_style": False,
                "finger_pull_style": "arc",
                "finger_pull_depth": 8,
                "finger_pull_height": 12,
                "finger_pull_width": 25,
                "finger_pull_z_offset": 0,
                "weighted_base": False,
                "base_extra_mm": 0,
                "stackable_only": False,
                "grid_divisions": 0,
                "length_div": None,
                "width_div": None,
            },
            "baseplate": {
                "format": "step",
            },
            "meshcut": {
                "micro_divisions": 4,
                "repair": False,
                "no_clean": False,
                "no_validate": False,
            },
        },
    }


def apply_config_to_args(args: Any, config: Dict[str, Any]) -> Any:
    """Apply config values to argparse args where not already set.

    This modifies the args object in place.

    Args:
        args: Parsed argparse namespace
        config: Loaded configuration

    Returns:
        Modified args object
    """
    # Apply output settings
    if "output" in config:
        output_config = config["output"]

        # output_dir
        if hasattr(args, "output_dir") and args.output_dir is None:
            if output_config.get("dir"):
                args.output_dir = output_config["dir"]

        # format (if not explicitly set)
        if hasattr(args, "format") and args.format is None:
            if output_config.get("format"):
                args.format = output_config["format"]

    # Apply command-specific defaults
    if "defaults" in config and hasattr(args, "command"):
        defaults = config["defaults"]
        command = args.command

        if command in defaults:
            cmd_defaults = defaults[command]

            # Handle backwards-compat aliases
            # scoop_offset (old) -> scoop_z_offset (new)
            if "scoop_offset" in cmd_defaults and "scoop_z_offset" not in cmd_defaults:
                cmd_defaults["scoop_z_offset"] = cmd_defaults.pop("scoop_offset")
                import warnings

                warnings.warn(
                    "Config key 'scoop_offset' is deprecated, use 'scoop_z_offset' instead",
                    DeprecationWarning,
                    stacklevel=2,
                )

            for key, value in cmd_defaults.items():
                # Only apply if arg not explicitly set (None or default value)
                attr_name = key.replace("-", "_")
                if hasattr(args, attr_name):
                    current = getattr(args, attr_name)
                    # Apply if None or if it's a boolean defaulting to False
                    if current is None or (isinstance(current, bool) and not current):
                        setattr(args, attr_name, value)

    return args


class ConfigValidator:
    """Validate configuration against schema.

    Provides helpful error messages for config issues.
    """

    # Known config sections and their types
    SCHEMA = {
        "output": {
            "type": dict,
            "keys": {
                "dir": {"type": (str, type(None))},
                "format": {"type": str, "enum": ["stl", "step", "svg"]},
            },
        },
        "defaults": {
            "type": dict,
            "keys": {
                "box": {"type": dict},
                "baseplate": {"type": dict},
                "meshcut": {"type": dict},
            },
        },
    }

    def __init__(self):
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def validate(self, config: Dict[str, Any], path: str = "") -> bool:
        """Validate config against schema.

        Args:
            config: Configuration dictionary
            path: Current path for error messages

        Returns:
            True if valid, False if errors found
        """
        self.errors = []
        self.warnings = []

        self._validate_dict(config, self.SCHEMA, path)

        return len(self.errors) == 0

    def _validate_dict(self, config: Dict[str, Any], schema: Dict[str, Any], path: str) -> None:
        """Recursively validate dictionary against schema."""
        for key, value in config.items():
            current_path = f"{path}.{key}" if path else key

            if key not in schema:
                self.warnings.append(f"Unknown key: {current_path}")
                continue

            key_schema = schema[key]
            self._validate_value(value, key_schema, current_path)

    def _validate_value(self, value: Any, schema: Dict[str, Any], path: str) -> None:
        """Validate a single value against schema."""
        expected_type = schema.get("type")

        if expected_type is not None:
            if not isinstance(value, expected_type):
                self.errors.append(
                    f"Type error at {path}: expected {expected_type.__name__}, " f"got {type(value).__name__}"
                )
                return

        # Check enum values
        if "enum" in schema and value not in schema["enum"]:
            self.errors.append(f"Value error at {path}: expected one of {schema['enum']}, " f"got {value!r}")

        # Recurse into nested dicts
        if isinstance(value, dict) and "keys" in schema:
            self._validate_dict(value, schema["keys"], path)


def validate_config(config: Dict[str, Any]) -> tuple[bool, List[str], List[str]]:
    """Validate configuration and return results.

    Args:
        config: Configuration dictionary

    Returns:
        Tuple of (is_valid, errors, warnings)
    """
    validator = ConfigValidator()
    is_valid = validator.validate(config)
    return is_valid, validator.errors, validator.warnings
