"""
Logging configuration for microfinity CLI.
"""

import logging
import sys

from .config.base import LogLevel


def configure_logging(level: LogLevel) -> None:
    """
    Configure Python logging from LogLevel enum.

    Args:
        level: The desired log level
    """
    level_map = {
        LogLevel.DEBUG: logging.DEBUG,
        LogLevel.INFO: logging.INFO,
        LogLevel.WARNING: logging.WARNING,
        LogLevel.ERROR: logging.ERROR,
        LogLevel.CRITICAL: logging.CRITICAL,
    }

    # Simple format - no timestamps for CLI output
    logging.basicConfig(
        level=level_map[level],
        format="%(message)s",
        stream=sys.stderr,
        force=True,  # Override any existing config
    )

    # Also configure the root microfinity logger
    logger = logging.getLogger("microfinity")
    logger.setLevel(level_map[level])

    # Configure meshcutter logger too
    meshcutter_logger = logging.getLogger("meshcutter")
    meshcutter_logger.setLevel(level_map[level])


def get_logger(name: str) -> logging.Logger:
    """
    Get a logger with the given name.

    Args:
        name: Logger name (typically __name__)

    Returns:
        Configured logger instance
    """
    return logging.getLogger(name)
