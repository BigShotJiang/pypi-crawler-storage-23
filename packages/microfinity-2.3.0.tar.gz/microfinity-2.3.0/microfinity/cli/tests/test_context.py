"""Unit tests for CLI context module.

Tests CLIContext, CommandResult, and related utilities.
"""

import argparse
import json
import sys
from pathlib import Path
from unittest.mock import patch

import pytest

from microfinity.cli.context import CLIContext, CommandResult, create_context


class TestCommandResult:
    """Test CommandResult dataclass."""

    def test_basic_creation(self):
        """Test creating a basic CommandResult."""
        result = CommandResult(ok=True)
        assert result.ok is True
        assert result.artifacts == []
        assert result.params == {}
        assert result.warnings == []
        assert result.errors == []
        assert result.dry_run is False

    def test_full_creation(self):
        """Test creating a CommandResult with all fields."""
        artifacts = [Path("test.stl"), Path("test.step")]
        params = {"length": 2, "width": 3}
        warnings = ["Warning 1"]
        errors = ["Error 1"]
        timing = {"duration": 1.5}

        result = CommandResult(
            ok=True,
            artifacts=artifacts,
            params=params,
            warnings=warnings,
            errors=errors,
            timing=timing,
            dry_run=True,
        )

        assert result.ok is True
        assert result.artifacts == artifacts
        assert result.params == params
        assert result.warnings == warnings
        assert result.errors == errors
        assert result.timing == timing
        assert result.dry_run is True

    def test_to_dict_basic(self):
        """Test converting to dictionary."""
        result = CommandResult(ok=True)
        d = result.to_dict()

        assert d["ok"] is True
        assert d["artifacts"] == []
        assert d["params"] == {}
        assert d["warnings"] == []
        assert d["errors"] == []
        assert d["dry_run"] is False

    def test_to_dict_with_paths(self):
        """Test converting to dictionary with Path objects."""
        result = CommandResult(
            ok=True,
            artifacts=[Path("/tmp/test.stl")],
            params={"output": Path("/tmp")},
        )
        d = result.to_dict()

        assert d["artifacts"] == ["/tmp/test.stl"]
        assert d["params"] == {"output": "/tmp"}


class TestCLIContext:
    """Test CLIContext class."""

    def test_default_creation(self):
        """Test creating CLIContext with defaults."""
        ctx = CLIContext()

        assert ctx.verbosity == 0
        assert ctx.output_format == "text"
        assert ctx.output_dir is None
        assert ctx.dry_run is False
        assert ctx.config_path is None

    def test_quiet_mode(self):
        """Test quiet mode detection."""
        ctx = CLIContext(verbosity=-2)
        assert ctx.is_quiet() is True
        assert ctx.is_verbose() is False
        assert ctx.is_trace() is False

    def test_verbose_mode(self):
        """Test verbose mode detection."""
        ctx = CLIContext(verbosity=1)
        assert ctx.is_quiet() is False
        assert ctx.is_verbose() is True
        assert ctx.is_trace() is False

    def test_trace_mode(self):
        """Test trace mode detection."""
        ctx = CLIContext(verbosity=2)
        assert ctx.is_quiet() is False
        assert ctx.is_verbose() is True
        assert ctx.is_trace() is True

    def test_resolve_output_path_explicit(self):
        """Test resolving explicit output path."""
        ctx = CLIContext()
        path = ctx.resolve_output_path(Path("/explicit/path.stl"), "default.stl")
        assert path == Path("/explicit/path.stl")

    def test_resolve_output_path_with_output_dir(self):
        """Test resolving path with output_dir set."""
        ctx = CLIContext(output_dir=Path("/output"))
        path = ctx.resolve_output_path(None, "default.stl")
        assert path == Path("/output/default.stl")

    def test_resolve_output_path_default(self):
        """Test resolving path with defaults."""
        ctx = CLIContext()
        path = ctx.resolve_output_path(None, "default.stl")
        assert path == Path("default.stl")

    def test_resolve_output_path_relative_with_output_dir(self):
        """Test resolving relative path with output_dir."""
        ctx = CLIContext(output_dir=Path("/output"))
        path = ctx.resolve_output_path(Path("subdir/file.stl"), "default.stl")
        assert path == Path("/output/subdir/file.stl")

    def test_resolve_output_path_absolute_with_output_dir(self):
        """Test that absolute paths ignore output_dir."""
        ctx = CLIContext(output_dir=Path("/output"))
        path = ctx.resolve_output_path(Path("/absolute/path.stl"), "default.stl")
        assert path == Path("/absolute/path.stl")

    def test_emit_result_text_success(self, capsys):
        """Test emitting text result for success."""
        ctx = CLIContext(output_format="text")
        result = CommandResult(
            ok=True,
            artifacts=[Path("test.stl")],
        )

        exit_code = ctx.emit_result(result)

        assert exit_code == 0
        captured = capsys.readouterr()
        assert "test.stl" in captured.out

    def test_emit_result_text_dry_run(self, capsys):
        """Test emitting text result for dry run."""
        ctx = CLIContext(output_format="text")
        result = CommandResult(
            ok=True,
            artifacts=[Path("test.stl")],
            dry_run=True,
        )

        ctx.emit_result(result)

        captured = capsys.readouterr()
        assert "DRY RUN" in captured.out
        assert "test.stl" in captured.out

    def test_emit_result_json(self, capsys):
        """Test emitting JSON result."""
        ctx = CLIContext(output_format="json")
        result = CommandResult(
            ok=True,
            artifacts=[Path("test.stl")],
            params={"length": 2},
        )

        exit_code = ctx.emit_result(result)

        assert exit_code == 0
        captured = capsys.readouterr()
        data = json.loads(captured.out)
        assert data["ok"] is True
        assert data["artifacts"] == ["test.stl"]
        assert data["params"] == {"length": 2}

    def test_emit_result_yaml(self, capsys):
        """Test emitting YAML result."""
        ctx = CLIContext(output_format="yaml")
        result = CommandResult(ok=True)

        exit_code = ctx.emit_result(result)

        assert exit_code == 0
        captured = capsys.readouterr()
        assert "ok: true" in captured.out

    def test_emit_result_failure(self, capsys):
        """Test emitting result for failure."""
        ctx = CLIContext(output_format="text")
        result = CommandResult(
            ok=False,
            errors=["Something went wrong"],
        )

        exit_code = ctx.emit_result(result)

        assert exit_code == 1


class TestCreateContext:
    """Test create_context function."""

    def test_default_args(self):
        """Test creating context from default args."""
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=False,
            yaml=False,
            output_dir=None,
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.verbosity == 0
        assert ctx.output_format == "text"
        assert ctx.output_dir is None
        assert ctx.dry_run is False

    def test_quiet_flag(self):
        """Test quiet flag sets verbosity to -2."""
        args = argparse.Namespace(
            quiet=True,
            verbose=0,
            json=False,
            yaml=False,
            output_dir=None,
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.verbosity == -2

    def test_verbose_flag(self):
        """Test verbose flag."""
        args = argparse.Namespace(
            quiet=False,
            verbose=2,
            json=False,
            yaml=False,
            output_dir=None,
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.verbosity == 2

    def test_json_flag(self):
        """Test JSON output flag."""
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=True,
            yaml=False,
            output_dir=None,
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.output_format == "json"

    def test_yaml_flag(self):
        """Test YAML output flag."""
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=False,
            yaml=True,
            output_dir=None,
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.output_format == "yaml"

    def test_output_dir_creation(self, tmp_path):
        """Test that output_dir is created if it doesn't exist."""
        output_dir = tmp_path / "new_output"
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=False,
            yaml=False,
            output_dir=str(output_dir),
            dry_run=False,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.output_dir == output_dir
        assert output_dir.exists()

    def test_dry_run_flag(self):
        """Test dry run flag."""
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=False,
            yaml=False,
            output_dir=None,
            dry_run=True,
            config=None,
        )

        ctx = create_context(args)

        assert ctx.dry_run is True

    def test_config_path(self):
        """Test config path is set."""
        args = argparse.Namespace(
            quiet=False,
            verbose=0,
            json=False,
            yaml=False,
            output_dir=None,
            dry_run=False,
            config=Path("/path/to/config.yml"),
        )

        ctx = create_context(args)

        assert ctx.config_path == Path("/path/to/config.yml")
