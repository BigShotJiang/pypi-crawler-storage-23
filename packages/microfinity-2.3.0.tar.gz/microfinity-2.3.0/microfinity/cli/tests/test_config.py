"""Unit tests for CLI config module.

Tests config loading, merging, validation, and XDG path discovery.
"""

import os
from pathlib import Path
from unittest.mock import patch

import pytest
import yaml

from microfinity.cli.config import (
    apply_config_to_args,
    find_config_file,
    get_default_config,
    load_config,
    load_yaml_config,
    merge_configs,
    validate_config,
)


class TestLoadYamlConfig:
    """Test load_yaml_config function."""

    def test_load_valid_yaml(self, tmp_path):
        """Test loading valid YAML file."""
        config_file = tmp_path / "test.yml"
        config_file.write_text("key: value\nnested:\n  subkey: subvalue")

        result = load_yaml_config(config_file)

        assert result == {"key": "value", "nested": {"subkey": "subvalue"}}

    def test_load_empty_yaml(self, tmp_path):
        """Test loading empty YAML file."""
        config_file = tmp_path / "empty.yml"
        config_file.write_text("")

        result = load_yaml_config(config_file)

        assert result == {}

    def test_load_nonexistent_file(self, tmp_path):
        """Test loading non-existent file raises error."""
        config_file = tmp_path / "nonexistent.yml"

        with pytest.raises(FileNotFoundError):
            load_yaml_config(config_file)

    def test_load_invalid_yaml(self, tmp_path):
        """Test loading invalid YAML raises error."""
        config_file = tmp_path / "invalid.yml"
        config_file.write_text("key: : invalid yaml : :")

        with pytest.raises(yaml.YAMLError):
            load_yaml_config(config_file)

    def test_load_non_dict_yaml(self, tmp_path):
        """Test loading YAML that isn't a dict raises error."""
        config_file = tmp_path / "list.yml"
        config_file.write_text("- item1\n- item2")

        with pytest.raises(ValueError, match="must contain a YAML mapping"):
            load_yaml_config(config_file)


class TestMergeConfigs:
    """Test merge_configs function."""

    def test_simple_merge(self):
        """Test simple key merging."""
        base = {"a": 1, "b": 2}
        override = {"b": 3, "c": 4}

        result = merge_configs(base, override)

        assert result == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self):
        """Test nested dictionary merging."""
        base = {"outer": {"inner1": 1, "inner2": 2}}
        override = {"outer": {"inner2": 3, "inner3": 4}}

        result = merge_configs(base, override)

        assert result == {"outer": {"inner1": 1, "inner2": 3, "inner3": 4}}

    def test_deep_merge(self):
        """Test deeply nested merging."""
        base = {"level1": {"level2": {"level3": {"key": "value"}}}}
        override = {"level1": {"level2": {"level3": {"new_key": "new_value"}}}}

        result = merge_configs(base, override)

        assert result["level1"]["level2"]["level3"]["key"] == "value"
        assert result["level1"]["level2"]["level3"]["new_key"] == "new_value"

    def test_override_replaces_nested_dict(self):
        """Test that override completely replaces when not merging dicts."""
        base = {"key": {"nested": "value"}}
        override = {"key": "simple_value"}

        result = merge_configs(base, override)

        assert result == {"key": "simple_value"}


class TestFindConfigFile:
    """Test find_config_file function with XDG paths."""

    def test_explicit_path(self, tmp_path):
        """Test explicit path is used if provided."""
        config_file = tmp_path / "explicit.yml"
        config_file.write_text("key: value")

        result = find_config_file(config_file)

        assert result == config_file

    def test_explicit_path_not_found(self, tmp_path):
        """Test explicit path raises error if not found."""
        config_file = tmp_path / "nonexistent.yml"

        with pytest.raises(FileNotFoundError):
            find_config_file(config_file)

    def test_local_config_microfinity_yml(self, tmp_path, monkeypatch):
        """Test finding ./microfinity.yml."""
        monkeypatch.chdir(tmp_path)
        config_file = tmp_path / "microfinity.yml"
        config_file.write_text("key: value")

        result = find_config_file()

        assert result == config_file

    def test_local_config_dot_microfinity_yml(self, tmp_path, monkeypatch):
        """Test finding ./.microfinity.yml."""
        monkeypatch.chdir(tmp_path)
        config_file = tmp_path / ".microfinity.yml"
        config_file.write_text("key: value")

        result = find_config_file()

        assert result == config_file

    def test_xdg_config_home(self, tmp_path, monkeypatch):
        """Test finding $XDG_CONFIG_HOME/microfinity/config.yml."""
        xdg_config = tmp_path / "xdg_config"
        microfinity_dir = xdg_config / "microfinity"
        microfinity_dir.mkdir(parents=True)
        config_file = microfinity_dir / "config.yml"
        config_file.write_text("key: value")

        monkeypatch.setenv("XDG_CONFIG_HOME", str(xdg_config))
        monkeypatch.chdir(tmp_path)  # No local config

        result = find_config_file()

        assert result == config_file

    def test_no_config_found(self, tmp_path, monkeypatch):
        """Test returns None when no config found."""
        monkeypatch.chdir(tmp_path)
        # Ensure no XDG config
        monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "nonexistent"))

        result = find_config_file()

        assert result is None


class TestLoadConfig:
    """Test load_config function."""

    def test_load_with_explicit_path(self, tmp_path):
        """Test loading with explicit path."""
        config_file = tmp_path / "config.yml"
        config_file.write_text("output:\n  format: stl")

        result = load_config(explicit_path=config_file)

        assert result["output"]["format"] == "stl"

    def test_load_with_defaults(self, tmp_path):
        """Test loading merges with defaults."""
        config_file = tmp_path / "config.yml"
        config_file.write_text("output:\n  format: stl")

        defaults = {"output": {"dir": "/default", "format": "step"}}
        result = load_config(explicit_path=config_file, defaults=defaults)

        assert result["output"]["format"] == "stl"  # Overridden
        assert result["output"]["dir"] == "/default"  # From defaults

    def test_load_no_config(self):
        """Test loading with no config file returns defaults."""
        defaults = {"key": "value"}
        result = load_config(defaults=defaults)

        assert result == defaults


class TestGetDefaultConfig:
    """Test get_default_config function."""

    def test_has_required_sections(self):
        """Test default config has required sections."""
        config = get_default_config()

        assert "output" in config
        assert "defaults" in config

    def test_output_section(self):
        """Test output section has expected keys."""
        config = get_default_config()

        assert "dir" in config["output"]
        assert "format" in config["output"]
        assert config["output"]["format"] == "step"

    def test_defaults_section(self):
        """Test defaults section has command defaults."""
        config = get_default_config()

        assert "box" in config["defaults"]
        assert "baseplate" in config["defaults"]
        assert "meshcut" in config["defaults"]

    def test_box_defaults(self):
        """Test box defaults are reasonable."""
        config = get_default_config()
        box = config["defaults"]["box"]

        assert box["micro_divisions"] in [1, 2, 4]
        assert box["wall_thickness"] > 0
        assert box["magnet_holes"] in [True, False]


class TestApplyConfigToArgs:
    """Test apply_config_to_args function."""

    def test_apply_output_dir(self):
        """Test applying output_dir from config."""
        import argparse

        args = argparse.Namespace(
            command="box",
            output_dir=None,
            format=None,
        )
        config = {"output": {"dir": "/output", "format": "stl"}}

        result = apply_config_to_args(args, config)

        assert result.output_dir == "/output"

    def test_cli_args_take_precedence(self):
        """Test CLI args take precedence over config."""
        import argparse

        args = argparse.Namespace(
            command="box",
            output_dir="/cli_output",
            format=None,
        )
        config = {"output": {"dir": "/config_output", "format": "stl"}}

        result = apply_config_to_args(args, config)

        assert result.output_dir == "/cli_output"  # CLI wins

    def test_apply_command_defaults(self):
        """Test applying command-specific defaults."""
        import argparse

        args = argparse.Namespace(
            command="box",
            micro=None,
            magnetholes=False,
        )
        config = {"defaults": {"box": {"micro_divisions": 2, "magnet_holes": True}}}

        result = apply_config_to_args(args, config)

        assert result.micro == 2
        assert result.magnetholes is True


class TestValidateConfig:
    """Test validate_config function."""

    def test_valid_config(self):
        """Test validating a valid config."""
        config = {
            "output": {"dir": "/output", "format": "stl"},
            "defaults": {"box": {"micro_divisions": 4}},
        }

        is_valid, errors, warnings = validate_config(config)

        assert is_valid is True
        assert errors == []

    def test_invalid_format_value(self):
        """Test validating config with invalid format."""
        config = {"output": {"format": "invalid_format"}}

        is_valid, errors, warnings = validate_config(config)

        assert is_valid is False
        assert any("format" in error.lower() for error in errors)

    def test_unknown_key_warning(self):
        """Test that unknown keys generate warnings."""
        config = {"unknown_section": {"key": "value"}}

        is_valid, errors, warnings = validate_config(config)

        assert is_valid is True  # Still valid
        assert len(warnings) > 0
        assert any("unknown" in w.lower() for w in warnings)

    def test_type_error(self):
        """Test validating config with wrong types."""
        config = {"output": {"format": 123}}  # Should be string

        is_valid, errors, warnings = validate_config(config)

        assert is_valid is False
        assert any("type" in error.lower() for error in errors)
