"""
Info command implementation.
"""

import sys

import typer


def info(ctx: typer.Context) -> None:
    """Show version and system information."""
    from microfinity import __version__

    print(f"microfinity {__version__}")
    print()

    # Python info
    print(f"Python: {sys.version}")
    print(f"Platform: {sys.platform}")
    print()

    # Dependencies
    print("Dependencies:")
    deps = [
        ("cadquery", "cadquery"),
        ("cqkit", "cqkit"),
        ("trimesh", "trimesh"),
        ("numpy", "numpy"),
        ("shapely", "shapely"),
        ("pyyaml", "yaml"),
        ("typer", "typer"),
        ("pydantic", "pydantic"),
    ]

    for name, module in deps:
        try:
            mod = __import__(module)
            ver = getattr(mod, "__version__", "(unknown)")
            print(f"  {name}: {ver}")
        except ImportError:
            print(f"  {name}: NOT INSTALLED")

    # Optional deps
    print()
    print("Optional dependencies:")
    optional = [
        ("manifold3d", "manifold3d"),
        ("pymeshlab", "pymeshlab"),
    ]

    for name, module in optional:
        try:
            mod = __import__(module)
            ver = getattr(mod, "__version__", "(installed)")
            print(f"  {name}: {ver}")
        except ImportError:
            print(f"  {name}: not installed")

    # Spec info
    print()
    print("Specifications:")
    try:
        from microfinity.spec.loader import GRIDFINITY, MICROFINITY

        print(f"  Gridfinity spec: v{GRIDFINITY.version}")
        print(f"    Pitch: {GRIDFINITY.pitch}mm")
        print(f"    Height unit: {GRIDFINITY.height_unit}mm")
        print(f"    Foot height: {GRIDFINITY.foot_height}mm")
        print(f"  Microfinity spec: v{MICROFINITY.version}")
        print(f"    Supported divisions: {MICROFINITY.supported_divisions}")
    except Exception as e:
        print(f"  (spec not loaded: {e})")
