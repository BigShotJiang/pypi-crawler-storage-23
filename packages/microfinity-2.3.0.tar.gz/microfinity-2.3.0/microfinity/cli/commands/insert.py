"""CLI command: insert - Generate tool-specific inserts."""

from __future__ import annotations

import argparse
from pathlib import Path

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class InsertCommand:
    """Generate inserts for specific tool categories."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("length", type=float, help="Insert footprint length in U")
        parser.add_argument("width", type=float, help="Insert footprint width in U")
        parser.add_argument(
            "--preset",
            choices=["hex-bits", "screwdriver"],
            default="hex-bits",
            help="Insert preset",
        )
        parser.add_argument("-M", "--micro", type=int, choices=[1, 2, 3, 4], default=4)
        parser.add_argument(
            "--height", type=float, default=8.0, help="Insert height in mm"
        )
        parser.add_argument(
            "--clearance", type=float, default=0.5, help="Per-side clearance in mm"
        )
        parser.add_argument(
            "--floor", type=float, default=1.2, help="Bottom floor thickness in mm"
        )
        parser.add_argument(
            "--hex-diameter",
            type=float,
            default=6.4,
            help="Hex bit hole diameter in mm",
        )
        parser.add_argument(
            "--slot-width", type=float, default=8.0, help="Screwdriver slot width in mm"
        )
        parser.add_argument(
            "--slot-length",
            type=float,
            default=24.0,
            help="Screwdriver slot length in mm",
        )
        parser.add_argument("-o", "--output", type=Path, help="Output file path")
        parser.add_argument(
            "-f",
            "--format",
            choices=["stl", "step"],
            default="stl",
            help="Output format",
        )

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        params = {
            "length_u": args.length,
            "width_u": args.width,
            "micro_divisions": args.micro,
            "preset": args.preset,
            "insert_height": args.height,
            "clearance": args.clearance,
            "floor": args.floor,
            "hex_diameter": args.hex_diameter,
            "screwdriver_slot_w": args.slot_width,
            "screwdriver_slot_l": args.slot_length,
        }

        if args.output and args.output.suffix:
            export_format = "stl" if args.output.suffix.lower() == ".stl" else "step"
            output_path = ctx.resolve_output_path(args.output, "")
        else:
            export_format = args.format
            suffix = ".stl" if export_format == "stl" else ".step"
            output_path = ctx.resolve_output_path(
                args.output, f"insert_{args.preset}_{args.length}x{args.width}{suffix}"
            )

        if ctx.dry_run:
            return CommandResult(
                ok=True, artifacts=[output_path], params=params, dry_run=True
            )

        try:
            from microfinity.parts.inserts import GridfinityToolInsert

            ins = GridfinityToolInsert(**params)
            ins.render()
            if export_format == "stl":
                ins.save_stl_file(str(output_path))
            else:
                ins.save_step_file(str(output_path))
            return CommandResult(ok=True, artifacts=[output_path], params=params)
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)], params=params)


register_command("insert", InsertCommand())
