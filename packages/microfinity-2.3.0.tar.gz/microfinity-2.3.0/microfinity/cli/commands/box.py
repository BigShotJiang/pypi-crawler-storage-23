"""
Box command implementation.
"""

import logging
from pathlib import Path
from typing import Annotated, Optional

import typer

from ..config import LogLevel, OutputFormat, load_settings
from ..config.defaults import BoxDefaults
from ..config.params import BoxParams
from ..logging import configure_logging

logger = logging.getLogger(__name__)


def box(
    ctx: typer.Context,
    # Positional arguments
    length: Annotated[float, typer.Argument(help="Box length in U (supports fractional: 1.5, 2.25, etc.)")],
    width: Annotated[float, typer.Argument(help="Box width in U")],
    height: Annotated[int, typer.Argument(help="Box height in U (integer, 7mm increments)")],
    # Dimensions
    micro: Annotated[
        Optional[int],
        typer.Option("-m", "--micro", help="Micro-divisions (1, 2, or 4)"),
    ] = None,
    # Features - boolean pairs with positive first
    magnets: Annotated[
        Optional[bool],
        typer.Option("--magnets/--no-magnets", help="Add magnet holes [default: --magnets]"),
    ] = None,
    unsupported: Annotated[
        Optional[bool],
        typer.Option("--unsupported/--no-unsupported", help="Unsupported (printable) magnet holes"),
    ] = None,
    scoops: Annotated[
        Optional[bool],
        typer.Option("--scoops/--no-scoops", help="Finger scoops [default: --scoops]"),
    ] = None,
    labels: Annotated[
        Optional[bool],
        typer.Option("--labels/--no-labels", help="Label strip [default: --no-labels]"),
    ] = None,
    label_height: Annotated[
        Optional[float],
        typer.Option("--label-height", help="Label height in mm [default: 12]"),
    ] = None,
    lip: Annotated[
        Optional[bool],
        typer.Option("--lip/--no-lip", help="Stacking lip [default: --lip]"),
    ] = None,
    # Construction
    solid: Annotated[
        Optional[bool],
        typer.Option("--solid/--no-solid", help="Solid base fill [default: --no-solid]"),
    ] = None,
    solid_ratio: Annotated[
        Optional[float],
        typer.Option("--solid-ratio", help="Solid fill ratio 0-1 [default: 0.5]"),
    ] = None,
    lite: Annotated[
        Optional[bool],
        typer.Option("--lite/--no-lite", help="Lite style (thin walls) [default: --no-lite]"),
    ] = None,
    wall: Annotated[
        Optional[float],
        typer.Option("--wall", help="Wall thickness in mm"),
    ] = None,
    floor: Annotated[
        Optional[float],
        typer.Option("--floor", help="Floor thickness in mm"),
    ] = None,
    # Dividers
    dividers_x: Annotated[
        Optional[int],
        typer.Option("--dividers-x", help="Dividers along length"),
    ] = None,
    dividers_y: Annotated[
        Optional[int],
        typer.Option("--dividers-y", help="Dividers along width"),
    ] = None,
    # Output
    output: Annotated[
        Optional[Path],
        typer.Option("-o", "--output", help="Output file path [default: auto-named]"),
    ] = None,
    format: Annotated[
        Optional[str],
        typer.Option("-f", "--format", help="Output format: stl, step [default: stl]"),
    ] = None,
) -> None:
    """Generate a Gridfinity box."""
    # Get context object (set by main callback)
    ctx_obj = ctx.obj or {}

    # Build CLI overrides for settings
    cli_overrides = {}
    if ctx_obj.get("log_level"):
        cli_overrides["log_level"] = ctx_obj["log_level"]

    # Build box-specific overrides
    box_overrides = {}
    if micro is not None:
        box_overrides["micro"] = micro
    if magnets is not None:
        box_overrides["magnets"] = magnets
    if unsupported is not None:
        box_overrides["unsupported"] = unsupported
    if solid is not None:
        box_overrides["solid"] = solid
    if lite is not None:
        box_overrides["lite"] = lite
    if scoops is not None:
        box_overrides["scoops"] = scoops
    if labels is not None:
        box_overrides["labels"] = labels
    if lip is not None:
        box_overrides["lip"] = lip
    if format is not None:
        box_overrides["format"] = OutputFormat(format)

    if box_overrides:
        # Merge with existing defaults
        cli_overrides["box"] = BoxDefaults(**box_overrides)

    # Load settings with full precedence
    config_path = ctx_obj.get("config_path")
    settings = load_settings(config_path=config_path, **cli_overrides)

    # Configure logging
    configure_logging(settings.log_level)

    # Build final params by merging settings.box defaults with explicit CLI values
    params = BoxParams(
        length_u=length,
        width_u=width,
        height_u=height,
        micro=micro if micro is not None else settings.box.micro,
        format=OutputFormat(format) if format is not None else settings.box.format,
        output=output,
        magnets=magnets if magnets is not None else settings.box.magnets,
        unsupported=unsupported if unsupported is not None else settings.box.unsupported,
        solid=solid if solid is not None else settings.box.solid,
        solid_ratio=solid_ratio if solid_ratio is not None else settings.box.solid_ratio,
        lite=lite if lite is not None else settings.box.lite,
        scoops=scoops if scoops is not None else settings.box.scoops,
        labels=labels if labels is not None else settings.box.labels,
        label_height=label_height if label_height is not None else settings.box.label_height,
        lip=lip if lip is not None else settings.box.lip,
        dividers_x=dividers_x if dividers_x is not None else settings.box.dividers_x,
        dividers_y=dividers_y if dividers_y is not None else settings.box.dividers_y,
        wall=wall if wall is not None else settings.box.wall,
        floor=floor if floor is not None else settings.box.floor,
    )

    logger.debug("Box params: %s", params.model_dump(exclude_none=True))

    # Execute
    run_box(params)


def run_box(params: BoxParams) -> None:
    """Execute box generation with typed params."""
    from microfinity import GridfinityBox

    logger.debug(
        "Generating box: %sx%sx%sU",
        params.length_u,
        params.width_u,
        params.height_u,
    )

    # Build box
    box = GridfinityBox(**params.to_gridfinity_kwargs())
    box.render()

    # Determine output path
    output_path = params.output
    if output_path is None:
        suffix = f".{params.format.value}"
        output_path = Path(f"box_{params.length_u}x{params.width_u}x{params.height_u}{suffix}")

    # Export
    if params.format == OutputFormat.STL:
        box.save_stl_file(str(output_path))
    elif params.format == OutputFormat.STEP:
        box.save_step_file(str(output_path))
    elif params.format == OutputFormat.SVG:
        box.save_svg_file(str(output_path))

    # Use print for user-facing output (logger.info goes to stderr)
    print(f"Wrote {output_path}")
