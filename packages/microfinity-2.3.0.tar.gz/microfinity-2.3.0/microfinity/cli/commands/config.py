"""
Config command implementation - shows and validates configuration.
"""

from pathlib import Path
from typing import Annotated, Optional

import typer
import yaml

from ..config import MicrofinitySettings, load_settings
from ..logging import configure_logging

config_app = typer.Typer(name="config", help="Configuration management")


@config_app.command("show")
def show(ctx: typer.Context) -> None:
    """Show resolved configuration.

    Displays the final configuration after merging:
    1. CLI flags (highest priority)
    2. Environment variables
    3. YAML config file
    4. Defaults (lowest priority)
    """
    ctx_obj = ctx.obj or {}
    config_path = ctx_obj.get("config_path")
    log_level_override = ctx_obj.get("log_level")

    # Build overrides
    overrides = {}
    if log_level_override:
        overrides["log_level"] = log_level_override

    # Load settings
    settings = load_settings(config_path=config_path, **overrides)

    # Configure logging (for any warnings)
    configure_logging(settings.log_level)

    # Output as YAML
    config_dict = settings.model_dump(mode="json")
    print(yaml.dump(config_dict, default_flow_style=False, sort_keys=False))


@config_app.command("validate")
def validate(
    ctx: typer.Context,
    config: Annotated[
        Optional[Path],
        typer.Option("--config", help="Config file to validate [default: ./microfinity.yaml]"),
    ] = None,
    strict: Annotated[
        bool,
        typer.Option("--strict", help="Fail on warnings (not just errors)"),
    ] = False,
) -> None:
    """Validate a configuration file.

    Checks that the config file:
    - Is valid YAML
    - Has valid field names and types
    - Contains valid values for all options

    Examples:
      microfinity config validate
      microfinity config validate --config my-config.yaml
      microfinity config validate --strict
    """
    from pydantic import ValidationError

    ctx_obj = ctx.obj or {}

    # Determine config path
    config_path = config or ctx_obj.get("config_path") or Path("./microfinity.yaml")

    if not config_path.exists():
        print(f"Config file not found: {config_path}")
        print("Use default configuration by omitting --config, or create a config file.")
        raise typer.Exit(1)

    print(f"Validating: {config_path}")

    # Try to load and parse YAML
    try:
        with open(config_path) as f:
            raw_config = yaml.safe_load(f)
    except yaml.YAMLError as e:
        print(f"\nYAML parse error:\n{e}")
        raise typer.Exit(1)

    if raw_config is None:
        print("\nConfig file is empty (valid but no settings)")
        raise typer.Exit(0)

    if not isinstance(raw_config, dict):
        print(f"\nConfig file must be a YAML mapping, got: {type(raw_config).__name__}")
        raise typer.Exit(1)

    # Check for unknown keys (warnings)
    warnings = []
    valid_top_level = {"log_level", "box", "baseplate", "meshcut", "layout", "debug"}
    unknown_keys = set(raw_config.keys()) - valid_top_level
    if unknown_keys:
        warnings.append(f"Unknown top-level keys (will be ignored): {sorted(unknown_keys)}")

    # Validate against Pydantic schema
    try:
        settings = load_settings(config_path=config_path)
        print("\nConfiguration is valid!")

        if warnings:
            print(f"\nWarnings ({len(warnings)}):")
            for w in warnings:
                print(f"  - {w}")
            if strict:
                print("\nFailed due to --strict flag")
                raise typer.Exit(1)

        # Show summary
        print("\nResolved settings summary:")
        print(f"  log_level: {settings.log_level.value}")
        print(f"  box.micro: {settings.box.micro}")
        print(f"  box.magnets: {settings.box.magnets}")
        print(f"  baseplate.micro: {settings.baseplate.micro}")
        print(f"  meshcut.micro: {settings.meshcut.micro}")
        print(f"  layout.build_x: {settings.layout.build_x}")

    except ValidationError as e:
        print(f"\nValidation errors ({e.error_count()}):")
        for err in e.errors():
            loc = ".".join(str(x) for x in err["loc"])
            print(f"  - {loc}: {err['msg']}")
        raise typer.Exit(1)
