"""CLI command: debug - Debug utilities for Gridfinity boxes."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any, Dict

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class DebugCommand:
    """Debug and visualization utilities."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        """Add debug subcommand arguments."""
        subparsers = parser.add_subparsers(dest="debug_command", help="Debug commands")

        # Wireframe command
        wireframe_parser = subparsers.add_parser(
            "wireframe", help="Export wireframe SVG visualization"
        )
        wireframe_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        wireframe_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        wireframe_parser.add_argument(
            "height", type=int, help="Box height in U (1U = 7mm)"
        )
        wireframe_parser.add_argument(
            "--view",
            choices=["front", "top", "side", "iso"],
            default="front",
            help="View direction (default: front)",
        )
        wireframe_parser.add_argument(
            "-o", "--output", type=Path, required=True, help="Output SVG file path"
        )

        # Explode command
        explode_parser = subparsers.add_parser(
            "explode", help="Generate exploded view of box components"
        )
        explode_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        explode_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        explode_parser.add_argument(
            "height", type=int, help="Box height in U (1U = 7mm)"
        )
        explode_parser.add_argument(
            "--distance", type=float, default=10.0, help="Explosion distance (mm)"
        )
        explode_parser.add_argument(
            "-o", "--output", type=Path, required=True, help="Output file path"
        )

        # Measure command
        measure_parser = subparsers.add_parser(
            "measure", help="Measure and display box dimensions"
        )
        measure_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        measure_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        measure_parser.add_argument(
            "height", type=int, help="Box height in U (1U = 7mm)"
        )
        measure_parser.add_argument(
            "--json", action="store_true", help="Output as JSON"
        )

        # Slice command
        slice_parser = subparsers.add_parser(
            "slice", help="Generate cross-section views at Z levels"
        )
        slice_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        slice_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        slice_parser.add_argument("height", type=int, help="Box height in U (1U = 7mm)")
        slice_parser.add_argument("--z-level", type=float, help="Specific Z level (mm)")
        slice_parser.add_argument(
            "--z-start", type=float, help="Start Z level for range"
        )
        slice_parser.add_argument("--z-end", type=float, help="End Z level for range")
        slice_parser.add_argument(
            "--num-slices", type=int, default=5, help="Number of slices (default: 5)"
        )
        slice_parser.add_argument(
            "--no-grid", action="store_true", help="Hide background grid"
        )
        slice_parser.add_argument(
            "--no-dims", action="store_true", help="Hide dimension annotations"
        )
        slice_parser.add_argument(
            "-o", "--output", type=Path, help="Output file or directory"
        )

        # STL command with debug geometry
        stl_parser = subparsers.add_parser(
            "stl", help="Export STL with debug geometry overlays"
        )
        stl_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        stl_parser.add_argument("width", type=float, help="Box width in U (1U = 42mm)")
        stl_parser.add_argument("height", type=int, help="Box height in U (1U = 7mm)")
        stl_parser.add_argument(
            "-o", "--output", type=Path, required=True, help="Output STL file path"
        )
        stl_parser.add_argument(
            "--no-bbox", action="store_true", help="Exclude bounding box"
        )
        stl_parser.add_argument(
            "--no-axes", action="store_true", help="Exclude coordinate axes"
        )
        stl_parser.add_argument(
            "--grid", action="store_true", help="Include grid overlay"
        )
        stl_parser.add_argument(
            "--grid-spacing", type=float, default=10.0, help="Grid spacing (mm)"
        )

        # Intermediates command
        intermediates_parser = subparsers.add_parser(
            "intermediates", help="Export intermediate mesh pipeline stages"
        )
        intermediates_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        intermediates_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        intermediates_parser.add_argument(
            "height", type=int, help="Box height in U (1U = 7mm)"
        )
        intermediates_parser.add_argument(
            "-o", "--output", type=Path, required=True, help="Output directory"
        )
        intermediates_parser.add_argument(
            "--name", type=str, default="mesh", help="Base filename"
        )
        intermediates_parser.add_argument(
            "--format",
            type=str,
            default="stl",
            choices=["stl", "step", "obj"],
            help="Export format",
        )

        # Diagnose command
        diagnose_parser = subparsers.add_parser(
            "diagnose", help="Generate JSON diagnostic dump of box configuration"
        )
        diagnose_parser.add_argument(
            "length", type=float, help="Box length in U (1U = 42mm)"
        )
        diagnose_parser.add_argument(
            "width", type=float, help="Box width in U (1U = 42mm)"
        )
        diagnose_parser.add_argument(
            "height", type=int, help="Box height in U (1U = 7mm)"
        )
        diagnose_parser.add_argument(
            "-o", "--output", type=Path, help="Output JSON file (default: stdout)"
        )
        diagnose_parser.add_argument(
            "--no-timing", action="store_true", help="Exclude timing information"
        )

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Execute the debug command."""
        from microfinity import GridfinityBox
        from microfinity.debug.visualization import (
            export_wireframe_svg,
            extract_wireframe_from_workplane,
            create_exploded_view,
            generate_cross_section_svg,
            inspect_slices,
            export_debug_stl,
            export_intermediate_meshes,
            generate_diagnostic_dump,
        )

        logger = ctx.logger

        if not args.debug_command:
            ctx.parser.print_help()
            return CommandResult(ok=False, errors=["No debug command specified"])

        # Build base box
        box = GridfinityBox(
            length_u=args.length, width_u=args.width, height_u=args.height
        )
        result = box.render()

        if args.debug_command == "wireframe":
            return self._handle_wireframe(
                box,
                result,
                args,
                logger,
                export_wireframe_svg,
                extract_wireframe_from_workplane,
            )

        elif args.debug_command == "explode":
            return self._handle_explode(box, result, args, logger, create_exploded_view)

        elif args.debug_command == "measure":
            return self._handle_measure(box, args, logger)

        elif args.debug_command == "slice":
            return self._handle_slice(
                box, result, args, logger, generate_cross_section_svg, inspect_slices
            )

        elif args.debug_command == "stl":
            return self._handle_stl(box, result, args, logger, export_debug_stl)

        elif args.debug_command == "intermediates":
            return self._handle_intermediates(
                box, args, logger, export_intermediate_meshes
            )

        elif args.debug_command == "diagnose":
            return self._handle_diagnose(box, args, logger, generate_diagnostic_dump)

        return CommandResult(
            ok=False, errors=[f"Unknown debug command: {args.debug_command}"]
        )

    def _handle_wireframe(
        self,
        box,
        result,
        args,
        logger,
        export_wireframe_svg,
        extract_wireframe_from_workplane,
    ) -> CommandResult:
        """Handle wireframe export."""
        try:
            vertices, edges = extract_wireframe_from_workplane(result)

            if not vertices or not edges:
                return CommandResult(
                    ok=False, errors=["No wireframe data could be extracted"]
                )

            export_wireframe_svg(
                vertices=vertices,
                edges=edges,
                output_path=str(args.output),
                view=args.view,
            )

            logger.info(f"Wireframe exported to {args.output}")
            return CommandResult(ok=True, artifacts=[args.output])

        except Exception as e:
            logger.error(f"Wireframe export failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_explode(
        self, box, result, args, logger, create_exploded_view
    ) -> CommandResult:
        """Handle exploded view."""
        try:
            # Get individual components
            components = []
            shell = box.render_shell()
            if shell is not None:
                components.append(shell)

            dividers = box.render_dividers()
            if dividers is not None:
                components.append(dividers)

            scoops = box.render_scoops()
            if scoops is not None:
                components.append(scoops)

            labels = box.render_labels()
            if labels is not None:
                components.append(labels)

            if len(components) < 2:
                return CommandResult(
                    ok=False, errors=["Box has no separable components"]
                )

            # Create exploded view
            exploded = create_exploded_view(components, args.distance)

            # Export (just the shell for now)
            if args.output.suffix.lower() == ".stl":
                # For exploded view, we'd need to union all parts
                # For now, export just the shell
                import cadquery as cq

                cq.exporters.export(exploded[0], str(args.output))
            else:
                import cadquery as cq

                cq.exporters.export(exploded[0], str(args.output))

            logger.info(f"Exploded view exported to {args.output}")
            return CommandResult(ok=True, artifacts=[args.output])

        except Exception as e:
            logger.error(f"Exploded view failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_measure(self, box, args, logger) -> CommandResult:
        """Handle measurement output."""
        try:
            measurements = {
                "dimensions": {
                    "length_u": box.length_u,
                    "width_u": box.width_u,
                    "height_u": box.height_u,
                },
                "outer": {
                    "length": box.outer_l,
                    "width": box.outer_w,
                    "height": box.height,
                },
                "inner": {
                    "length": box.inner_l,
                    "width": box.inner_w,
                    "height": box.int_height,
                },
                "floor": {
                    "height": box.floor_h,
                    "thickness": box.floor_h + 7.0,  # Approximate
                },
                "volume": {
                    "outer": box.outer_l * box.outer_w * box.height,
                    "inner": box.inner_l * box.inner_w * box.int_height,
                },
            }

            if args.json:
                import json

                print(json.dumps(measurements, indent=2))
            else:
                print(f"\nBox: {box.length_u}U x {box.width_u}U x {box.height_u}U")
                print(f"\nOuter Dimensions:")
                print(f"  Length: {box.outer_l:.2f} mm")
                print(f"  Width:  {box.outer_w:.2f} mm")
                print(f"  Height: {box.height:.2f} mm")
                print(f"\nInner Dimensions:")
                print(f"  Length: {box.inner_l:.2f} mm")
                print(f"  Width:  {box.inner_w:.2f} mm")
                print(f"  Height: {box.int_height:.2f} mm")
                print(f"\nFloor:")
                print(f"  Height above base: {box.floor_h:.2f} mm")

            return CommandResult(ok=True, params=measurements)

        except Exception as e:
            logger.error(f"Measurement failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_slice(
        self,
        box,
        result,
        args,
        logger,
        generate_cross_section_svg,
        inspect_slices,
    ) -> CommandResult:
        """Handle slice/cross-section generation."""
        try:
            output_path = args.output

            if args.z_level is not None:
                if output_path is None:
                    return CommandResult(
                        ok=False, errors=["Output path required for single slice"]
                    )

                generate_cross_section_svg(
                    workplane=result,
                    z_level=args.z_level,
                    output_path=str(output_path),
                    show_grid=not args.no_grid,
                    show_dimensions=not args.no_dims,
                )

                logger.info(
                    f"Slice at Z={args.z_level:.2f}mm exported to {output_path}"
                )
                return CommandResult(ok=True, artifacts=[output_path])

            elif args.z_start is not None and args.z_end is not None:
                if output_path is None:
                    output_path = Path("slices")
                elif output_path.is_file():
                    output_path = output_path.parent

                output_path.mkdir(parents=True, exist_ok=True)

                slices = inspect_slices(
                    workplane=result,
                    z_start=args.z_start,
                    z_end=args.z_end,
                    num_slices=args.num_slices,
                    output_dir=str(output_path),
                )

                logger.info(f"Generated {len(slices)} slices in {output_path}")
                return CommandResult(ok=True, artifacts=slices)

            else:
                return CommandResult(
                    ok=False,
                    errors=["Specify either --z-level or --z-start/--z-end"],
                )

        except Exception as e:
            logger.error(f"Slice generation failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_stl(
        self,
        box,
        result,
        args,
        logger,
        export_debug_stl,
    ) -> CommandResult:
        """Handle debug STL export."""
        try:
            export_debug_stl(
                workplane=result,
                output_path=str(args.output),
                include_bounding_box=not args.no_bbox,
                include_axes=not args.no_axes,
                include_grid=args.grid,
                grid_spacing=args.grid_spacing,
            )

            logger.info(f"Debug STL exported to {args.output}")
            return CommandResult(ok=True, artifacts=[args.output])

        except Exception as e:
            logger.error(f"Debug STL export failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_intermediates(
        self,
        box,
        args,
        logger,
        export_intermediate_meshes,
    ) -> CommandResult:
        """Handle intermediate mesh export."""
        try:
            output_dir = args.output
            output_dir.mkdir(parents=True, exist_ok=True)

            paths = export_intermediate_meshes(
                box=box,
                output_dir=str(output_dir),
                base_name=args.name,
                formats=[args.format],
            )

            logger.info(f"Exported {len(paths)} intermediate meshes to {output_dir}")
            for stage, path in paths.items():
                logger.info(f"  - {stage}: {path}")

            return CommandResult(ok=True, artifacts=list(paths.values()))

        except Exception as e:
            logger.error(f"Intermediate mesh export failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_diagnose(
        self,
        box,
        args,
        logger,
        generate_diagnostic_dump,
    ) -> CommandResult:
        """Handle diagnostic dump generation."""
        try:
            import json

            diagnostic = generate_diagnostic_dump(
                box=box,
                include_timing=not args.no_timing,
            )

            output = json.dumps(diagnostic, indent=2)

            if args.output:
                args.output.write_text(output)
                logger.info(f"Diagnostic dump written to {args.output}")
            else:
                print(output)

            return CommandResult(ok=True, params=diagnostic)

        except Exception as e:
            logger.error(f"Diagnostic dump failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])


# Register the command
register_command("debug", DebugCommand())
