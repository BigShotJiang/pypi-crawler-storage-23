"""
Baseplate command implementation.
"""

import logging
from pathlib import Path
from typing import Annotated, Optional

import typer

from ..config import OutputFormat, load_settings
from ..config.params import BaseplateParams
from ..logging import configure_logging

logger = logging.getLogger(__name__)


def baseplate(
    ctx: typer.Context,
    # Positional arguments (float to support fractional U and mm mode)
    length: Annotated[float, typer.Argument(help="Baseplate length (in U or mm, see --units)")],
    width: Annotated[float, typer.Argument(help="Baseplate width (in U or mm, see --units)")],
    # Size specification
    units: Annotated[
        str,
        typer.Option("--units", help="Input units: u, mm [default: u]"),
    ] = "u",
    micro: Annotated[
        Optional[int],
        typer.Option("-m", "--micro", help="Micro-divisions (1, 2, or 4) [default: auto]"),
    ] = None,
    # Construction options
    ext_depth: Annotated[
        Optional[float],
        typer.Option("--ext-depth", help="Extra bottom extrusion in mm [default: 0]"),
    ] = None,
    straight_bottom: Annotated[
        bool,
        typer.Option("--straight-bottom/--no-straight-bottom", help="Remove bottom chamfer"),
    ] = False,
    corner_fillet: Annotated[
        Optional[float],
        typer.Option("--corner-fillet", help="Corner radius in mm [default: 3.75]"),
    ] = None,
    # Output options
    output: Annotated[
        Optional[Path],
        typer.Option("-o", "--output", help="Output file path [default: auto-named]"),
    ] = None,
    format: Annotated[
        Optional[str],
        typer.Option("-f", "--format", help="Output format: stl, step [default: stl]"),
    ] = None,
) -> None:
    """Generate a Gridfinity baseplate.

    Examples:
      microfinity baseplate 3 4                    # 3x4 U baseplate
      microfinity baseplate 1.5 2.25 -m 4          # Fractional U with micro-4
      microfinity baseplate 150 200 --units mm     # By mm dimensions (with fill)
    """
    ctx_obj = ctx.obj or {}

    # Load settings
    config_path = ctx_obj.get("config_path")
    overrides = {}
    if ctx_obj.get("log_level"):
        overrides["log_level"] = ctx_obj["log_level"]

    settings = load_settings(config_path=config_path, **overrides)
    configure_logging(settings.log_level)

    # Build params
    bp_defaults = settings.baseplate
    params = BaseplateParams(
        length=length,
        width=width,
        units=units,
        micro=micro if micro is not None else bp_defaults.micro,
        format=OutputFormat(format) if format else bp_defaults.format,
        output=output,
        ext_depth=ext_depth if ext_depth is not None else bp_defaults.ext_depth,
        straight_bottom=straight_bottom if straight_bottom else bp_defaults.straight_bottom,
        corner_fillet=corner_fillet if corner_fillet is not None else bp_defaults.corner_fillet,
    )

    logger.debug("Baseplate params: %s", params.model_dump())

    # Execute
    run_baseplate(params)


def run_baseplate(params: BaseplateParams) -> None:
    """Execute baseplate generation."""
    from microfinity import GridfinityBaseplate
    from microfinity.spec.constants import GRU

    # Get kwargs from params (handles units conversion and fill calculation)
    kwargs = params.to_gridfinity_kwargs()

    # Extract dimensions for logging/filename
    length_u = kwargs.get("length_u", params.length)
    width_u = kwargs.get("width_u", params.width)
    micro = kwargs.get("micro_divisions", params.micro)

    if params.units == "mm":
        logger.info(
            "Generating baseplate from %sx%s mm -> %.2fx%.2f U (micro=%d)",
            params.length,
            params.width,
            length_u,
            width_u,
            micro,
        )
        solid_fill = kwargs.get("solid_fill", {})
        total_fill = sum(solid_fill.values())
        if total_fill > 0:
            logger.info(
                "Fill strips: left=%.1fmm, right=%.1fmm, front=%.1fmm, back=%.1fmm",
                solid_fill.get("left", 0),
                solid_fill.get("right", 0),
                solid_fill.get("front", 0),
                solid_fill.get("back", 0),
            )
    else:
        logger.debug("Generating baseplate: %.2fx%.2f U (micro=%d)", length_u, width_u, micro)

    bp = GridfinityBaseplate(**kwargs)
    bp.render()

    # Determine output path
    output_path = params.output
    if output_path is None:
        suffix = f".{params.format.value}"
        if params.units == "mm":
            # Use mm in filename for mm mode
            output_path = Path(f"baseplate_{int(params.length)}x{int(params.width)}mm{suffix}")
        else:
            # Use U dimensions
            output_path = Path(f"baseplate_{length_u}x{width_u}{suffix}")

    # Export
    if params.format == OutputFormat.STL:
        bp.save_stl_file(str(output_path))
    else:
        bp.save_step_file(str(output_path))

    print(f"Wrote {output_path}")
