"""CLI command: calibrate - Generate calibration prints."""

from __future__ import annotations

import argparse
from pathlib import Path

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class CalibrateCommand:
    """Generate calibration prints."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        """Add calibrate subcommand arguments."""
        parser.add_argument(
            "-o", "--output", type=Path, default=Path("test_prints"), help="Output directory (default: test_prints)"
        )
        parser.add_argument(
            "-f", "--format", choices=["stl", "step"], default="step", help="Output format (default: step)"
        )
        parser.add_argument(
            "--no-fractional", dest="fractional", action="store_false", help="Exclude fractional pocket tests"
        )
        parser.add_argument("--no-clips", dest="clips", action="store_false", help="Exclude clip clearance sweeps")

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Execute the calibrate command."""
        from microfinity.calibration import export_test_prints

        logger = ctx.logger

        params = {
            "file_format": args.format,
            "include_fractional": args.fractional,
            "include_clips": args.clips,
        }

        logger.info("Generating calibration prints")

        output_dir = args.output or Path("test_prints")
        output_dir = ctx.resolve_output_path(output_dir, "")

        if ctx.dry_run:
            return CommandResult(
                ok=True,
                artifacts=[output_dir],
                params=params,
                dry_run=True,
            )

        try:
            files = export_test_prints(
                path=str(output_dir),
                file_format=args.format,
                include_fractional=args.fractional,
                include_clip_sweep=args.clips,
            )

            logger.info(f"Wrote {len(files)} calibration files to {output_dir}")

            return CommandResult(
                ok=True,
                artifacts=[Path(f) for f in files],
                params=params,
            )
        except Exception as e:
            logger.error(f"Calibration generation failed: {e}")
            return CommandResult(ok=False, errors=[str(e)])


# Register the command
register_command("calibrate", CalibrateCommand())
