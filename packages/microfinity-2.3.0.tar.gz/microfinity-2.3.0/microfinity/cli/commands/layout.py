"""
Layout command implementation for baseplate layouts.
"""

import json
import logging
from pathlib import Path
from typing import Annotated, Optional

import typer

from ..config import OutputFormat, load_settings
from ..config.params import LayoutParams
from ..logging import configure_logging

logger = logging.getLogger(__name__)


def layout(
    ctx: typer.Context,
    # Required arguments (drawer dimensions in mm)
    drawer_x: Annotated[float, typer.Argument(help="Drawer interior width in mm")],
    drawer_y: Annotated[float, typer.Argument(help="Drawer interior depth in mm")],
    # Build plate options
    build_x: Annotated[
        Optional[float],
        typer.Option("--build-x", help="Build plate X dimension in mm [default: 220]"),
    ] = None,
    build_y: Annotated[
        Optional[float],
        typer.Option("--build-y", help="Build plate Y dimension in mm [default: 220]"),
    ] = None,
    margin: Annotated[
        Optional[float],
        typer.Option("--margin", help="Safety margin from build plate edge [default: 5]"),
    ] = None,
    # Grid options
    micro: Annotated[
        Optional[int],
        typer.Option("-m", "--micro", help="Micro-divisions (1, 2, or 4) [default: 4]"),
    ] = None,
    tolerance: Annotated[
        Optional[float],
        typer.Option("--tolerance", help="Clearance gap in mm [default: 0.5]"),
    ] = None,
    # Output options
    output_dir: Annotated[
        Optional[Path],
        typer.Option("-o", "--output-dir", help="Output directory [default: ./layout]"),
    ] = None,
    format: Annotated[
        Optional[str],
        typer.Option("-f", "--format", help="Output format: stl, step [default: stl]"),
    ] = None,
    summary: Annotated[
        bool,
        typer.Option("--summary", help="Print layout summary only (no files)"),
    ] = False,
) -> None:
    """Generate baseplate layout for drawer dimensions.

    Calculates optimal baseplate segmentation for a drawer, splitting into
    printable pieces with connector notches and edge fill strips.

    Examples:
      microfinity layout 400 300                     # 400x300mm drawer
      microfinity layout 500 350 --build-x 256       # Bambu X1 build plate
      microfinity layout 400 300 --summary           # Just show piece count
    """
    ctx_obj = ctx.obj or {}

    # Load settings
    config_path = ctx_obj.get("config_path")
    overrides = {}
    if ctx_obj.get("log_level"):
        overrides["log_level"] = ctx_obj["log_level"]

    settings = load_settings(config_path=config_path, **overrides)
    configure_logging(settings.log_level)

    # Build params from CLI + config defaults
    layout_defaults = settings.layout
    params = LayoutParams(
        drawer_x=drawer_x,
        drawer_y=drawer_y,
        build_x=build_x if build_x is not None else layout_defaults.build_x,
        build_y=build_y if build_y is not None else layout_defaults.build_y,
        margin=margin if margin is not None else layout_defaults.margin,
        micro=micro if micro is not None else layout_defaults.micro,
        tolerance=tolerance if tolerance is not None else layout_defaults.tolerance,
        output_dir=output_dir if output_dir is not None else Path("./layout"),
        format=OutputFormat(format) if format else layout_defaults.format,
        summary=summary,
    )

    logger.debug("Layout params: %s", params.model_dump())

    # Execute
    run_layout(params)


def run_layout(params: LayoutParams) -> None:
    """Execute layout generation."""
    from microfinity.parts.baseplate_layout import GridfinityBaseplateLayout

    logger.info(
        "Calculating layout for %sx%s mm drawer (build plate: %sx%s mm)",
        params.drawer_x,
        params.drawer_y,
        params.build_x,
        params.build_y,
    )

    # Create layout calculator
    layout_calc = GridfinityBaseplateLayout(
        drawer_x_mm=params.drawer_x,
        drawer_y_mm=params.drawer_y,
        build_plate_x_mm=params.build_x - params.margin * 2,
        build_plate_y_mm=params.build_y - params.margin * 2,
        micro_divisions=params.micro,
        tolerance_mm=params.tolerance,
    )

    # Get the calculated layout
    result = layout_calc.get_layout()

    # Print summary
    print(result.summary())

    if params.summary:
        # Summary mode - don't generate files
        return

    # Create output directory
    params.output_dir.mkdir(parents=True, exist_ok=True)

    # Generate all pieces
    manifest = {
        "drawer_dimensions": {
            "x_mm": params.drawer_x,
            "y_mm": params.drawer_y,
        },
        "grid_config": {
            "micro_divisions": params.micro,
            "tolerance_mm": params.tolerance,
        },
        "build_plate": {
            "x_mm": params.build_x,
            "y_mm": params.build_y,
            "margin_mm": params.margin,
        },
        "grid_info": {
            "total_micro_x": result.total_micro_x,
            "total_micro_y": result.total_micro_y,
            "total_u_x": result.total_micro_x / params.micro,
            "total_u_y": result.total_micro_y / params.micro,
            "fill_x_mm": result.fill_x_mm,
            "fill_y_mm": result.fill_y_mm,
        },
        "pieces": [],
        "summary": {
            "total_pieces": len(result.pieces),
            "segments_x": len(result.segments_x),
            "segments_y": len(result.segments_y),
            "clip_count": result.clip_count,
        },
    }

    print(f"\nGenerating {len(result.pieces)} baseplate pieces...")

    for piece in result.pieces:
        # Render the piece
        bp = layout_calc._create_baseplate_from_spec(piece)
        bp.render()

        # Generate filename
        suffix = f".{params.format.value}"
        filename = f"{piece.id}{suffix}"
        output_path = params.output_dir / filename

        # Export
        if params.format == OutputFormat.STL:
            bp.save_stl_file(str(output_path))
        else:
            bp.save_step_file(str(output_path))

        logger.debug("Wrote %s", output_path)

        # Add to manifest
        size_u = piece.size_u(params.micro)
        piece_info = {
            "filename": filename,
            "id": piece.id,
            "position": {
                "grid_x": piece.grid_x,
                "grid_y": piece.grid_y,
                "origin_x_mm": piece.origin_x_mm,
                "origin_y_mm": piece.origin_y_mm,
            },
            "dimensions": {
                "size_mx": piece.size_mx,
                "size_my": piece.size_my,
                "length_u": size_u[0],
                "width_u": size_u[1],
            },
            "fill": piece.solid_fill,
            "edge_roles": {k: v.value for k, v in piece.edge_roles.items()},
        }
        manifest["pieces"].append(piece_info)

    # Write manifest
    manifest_path = params.output_dir / "manifest.json"
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)

    print(f"\nWrote {len(result.pieces)} pieces to {params.output_dir}/")
    print(f"Manifest: {manifest_path}")
