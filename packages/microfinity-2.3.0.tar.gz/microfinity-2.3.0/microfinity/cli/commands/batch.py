"""
Batch command for generating multiple models from config file.

Supports parallel generation with caching and progress tracking.
"""

import hashlib
import json
import logging
import os
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Annotated, Any, Optional

import typer
import yaml

from ..config import LogLevel, OutputFormat, load_settings
from ..config.params import BoxParams, BaseplateParams
from ..logging import configure_logging

logger = logging.getLogger(__name__)


def compute_config_hash(config: dict) -> str:
    """Compute a hash of the config for cache validation."""
    config_str = json.dumps(config, sort_keys=True, default=str)
    return hashlib.sha256(config_str.encode()).hexdigest()[:16]


def load_models_config(config_path: Path) -> dict:
    """Load and validate the models.yaml config file."""
    with open(config_path, "r") as f:
        config = yaml.safe_load(f)

    if not config:
        raise ValueError(f"Empty config file: {config_path}")

    if "models" not in config:
        raise ValueError(f"Config missing 'models' section: {config_path}")

    return config


def get_cache_dir(working_dir: Path) -> Path:
    """Get the cache directory (project-relative)."""
    return working_dir / ".cache" / "microfinity" / "batch"


def get_cached_model_path(cache_dir: Path, model_key: str) -> Path:
    """Get the path to a cached model file."""
    return cache_dir / "models" / model_key / "model.stl"


def get_cached_hash_path(cache_dir: Path, model_key: str) -> Path:
    """Get the path to a cached hash file."""
    return cache_dir / "models" / model_key / "config.hash"


def is_model_cached(cache_dir: Path, model_key: str, config_hash: str) -> bool:
    """Check if a model is cached and up to date."""
    hash_path = get_cached_hash_path(cache_dir, model_key)
    model_path = get_cached_model_path(cache_dir, model_key)

    if not hash_path.exists() or not model_path.exists():
        return False

    cached_hash = hash_path.read_text().strip()
    return cached_hash == config_hash


def save_model_to_cache(cache_dir: Path, model_key: str, config_hash: str, model_path: Path) -> None:
    """Save a model and its hash to the cache."""
    model_cache_dir = cache_dir / "models" / model_key
    model_cache_dir.mkdir(parents=True, exist_ok=True)

    # Copy model to cache
    cached_model_path = model_cache_dir / "model.stl"
    import shutil

    shutil.copy2(model_path, cached_model_path)

    # Save hash
    hash_path = model_cache_dir / "config.hash"
    hash_path.write_text(config_hash)


def generate_box_model(
    model_key: str,
    model_config: dict,
    output_dir: Path,
    cache_dir: Path,
    settings: Any,
) -> tuple[str, bool, Optional[str]]:
    """Generate a single box model.

    Returns: (model_key, success, error_message)
    """
    try:
        from microfinity import GridfinityBox

        args = model_config.get("args", {})
        config_hash = compute_config_hash(model_config)

        # Check cache
        if is_model_cached(cache_dir, model_key, config_hash):
            cached_path = get_cached_model_path(cache_dir, model_key)
            output_path = output_dir / model_config.get("output", f"{model_key}.stl")
            import shutil

            shutil.copy2(cached_path, output_path)
            logger.info(f"[CACHED] {model_key} -> {output_path}")
            return (model_key, True, None)

        # Build params
        params = BoxParams(
            length_u=args.get("length", 1),
            width_u=args.get("width", 1),
            height_u=args.get("height", 1),
            micro=args.get("micro", settings.box.micro if hasattr(settings, "box") else 4),
            format=OutputFormat.STL,
            output=None,
            magnets=args.get("magnets", settings.box.magnets if hasattr(settings, "box") else True),
            unsupported=args.get("unsupported", False),
            solid=args.get("solid", False),
            lite=args.get("lite", False),
            scoops=args.get("scoops", settings.box.scoops if hasattr(settings, "box") else True),
            labels=args.get("labels", False),
            lip=args.get("lip", True),
            solid_ratio=args.get("solid_ratio"),
            label_height=args.get("label_height"),
            dividers_x=args.get("dividers_x"),
            dividers_y=args.get("dividers_y"),
            wall=args.get("wall"),
            floor=args.get("floor"),
        )

        # Generate box
        box = GridfinityBox(**params.to_gridfinity_kwargs())
        box.render()

        # Determine output path
        output_filename = model_config.get("output", f"{model_key}.stl")
        output_path = output_dir / output_filename
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Export
        box.save_stl_file(str(output_path))

        # Save to cache
        save_model_to_cache(cache_dir, model_key, config_hash, output_path)

        logger.info(f"[GENERATED] {model_key} -> {output_path}")
        return (model_key, True, None)

    except Exception as e:
        logger.error(f"[FAILED] {model_key}: {e}")
        return (model_key, False, str(e))


def generate_baseplate_model(
    model_key: str,
    model_config: dict,
    output_dir: Path,
    cache_dir: Path,
    settings: Any,
) -> tuple[str, bool, Optional[str]]:
    """Generate a single baseplate model.

    Returns: (model_key, success, error_message)
    """
    try:
        from microfinity import GridfinityBaseplate

        args = model_config.get("args", {})
        config_hash = compute_config_hash(model_config)

        # Check cache
        if is_model_cached(cache_dir, model_key, config_hash):
            cached_path = get_cached_model_path(cache_dir, model_key)
            output_path = output_dir / model_config.get("output", f"{model_key}.stl")
            import shutil

            shutil.copy2(cached_path, output_path)
            logger.info(f"[CACHED] {model_key} -> {output_path}")
            return (model_key, True, None)

        # Build params
        params = BaseplateParams(
            length=args.get("length", 4),
            width=args.get("width", 4),
            units="u",
            micro=args.get("micro", settings.box.micro if hasattr(settings, "box") else 4),
            format=OutputFormat.STL,
            output=None,
        )

        # Generate baseplate
        baseplate = GridfinityBaseplate(**params.to_gridfinity_kwargs())
        baseplate.render()

        # Determine output path
        output_filename = model_config.get("output", f"{model_key}.stl")
        output_path = output_dir / output_filename
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # Export
        baseplate.save_stl_file(str(output_path))

        # Save to cache
        save_model_to_cache(cache_dir, model_key, config_hash, output_path)

        logger.info(f"[GENERATED] {model_key} -> {output_path}")
        return (model_key, True, None)

    except Exception as e:
        logger.error(f"[FAILED] {model_key}: {e}")
        return (model_key, False, str(e))


def batch(
    ctx: typer.Context,
    config: Annotated[
        Path,
        typer.Option(
            "--config",
            "-c",
            help="Path to models.yaml config file",
            exists=True,
            file_okay=True,
            dir_okay=False,
            readable=True,
        ),
    ] = Path("config/models.yaml"),
    output_dir: Annotated[
        Optional[Path],
        typer.Option(
            "--output-dir",
            "-o",
            help="Output directory for generated models",
        ),
    ] = None,
    parallel: Annotated[
        bool,
        typer.Option(
            "--parallel/--no-parallel",
            help="Enable parallel generation",
        ),
    ] = False,
    max_parallel: Annotated[
        int,
        typer.Option(
            "--max-parallel",
            "-j",
            help="Maximum parallel workers",
            min=1,
            max=16,
        ),
    ] = 4,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            "-n",
            help="Show what would be generated without generating",
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Force regeneration (ignore cache)",
        ),
    ] = False,
    clean_cache: Annotated[
        bool,
        typer.Option(
            "--clean-cache",
            help="Clean cache before running",
        ),
    ] = False,
) -> None:
    """Generate multiple models from a config file.

    Reads a models.yaml config file and generates all defined models.
    Supports parallel generation and caching for incremental builds.
    """
    # Get context object
    ctx_obj = ctx.obj or {}

    # Build CLI overrides for settings
    cli_overrides = {}
    if ctx_obj.get("log_level"):
        cli_overrides["log_level"] = ctx_obj["log_level"]

    # Load settings
    settings_config_path = ctx_obj.get("config_path")
    settings = load_settings(config_path=settings_config_path, **cli_overrides)
    configure_logging(settings.log_level)

    # Load models config
    try:
        models_config = load_models_config(config)
    except ValueError as e:
        logger.error(f"Failed to load config: {e}")
        raise typer.Exit(1)

    # Determine working directory (where config is located)
    working_dir = config.parent

    # Determine output directory
    if output_dir is None:
        output_dir = working_dir / models_config.get("settings", {}).get("output_dir", ".models")
    output_dir = output_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    # Determine cache directory
    cache_dir = get_cache_dir(working_dir)

    # Clean cache if requested
    if clean_cache and cache_dir.exists():
        import shutil

        shutil.rmtree(cache_dir)
        logger.info(f"Cleaned cache: {cache_dir}")

    # Override parallel/max_parallel from config if not specified on CLI
    config_settings = models_config.get("settings", {})
    if not parallel and config_settings.get("parallel"):
        parallel = True
    if max_parallel == 4 and config_settings.get("max_parallel"):
        max_parallel = config_settings.get("max_parallel")

    # Get models to generate
    models = models_config.get("models", {})

    if not models:
        logger.warning("No models defined in config")
        raise typer.Exit(0)

    # Dry run: just print what would be generated
    if dry_run:
        print(f"Would generate {len(models)} model(s) to {output_dir}:")
        for model_key, model_config in models.items():
            output_file = model_config.get("output", f"{model_key}.stl")
            print(f"  - {model_key}: {output_file}")
        raise typer.Exit(0)

    # Generate models
    logger.info(f"Generating {len(models)} model(s) to {output_dir}")
    logger.info(f"Cache: {cache_dir}")
    logger.info(f"Parallel: {parallel} (max: {max_parallel})")

    start_time = time.time()
    results = []

    if parallel and len(models) > 1:
        # Parallel generation
        # Note: CadQuery is not thread-safe, so we use processes
        # But for now, use ThreadPoolExecutor with careful error handling
        with ThreadPoolExecutor(max_workers=max_parallel) as executor:
            futures = {}
            for model_key, model_config in models.items():
                model_type = model_config.get("type", "box")
                if model_type == "box":
                    future = executor.submit(
                        generate_box_model,
                        model_key,
                        model_config,
                        output_dir,
                        cache_dir,
                        settings,
                    )
                    futures[future] = model_key
                elif model_type == "baseplate":
                    future = executor.submit(
                        generate_baseplate_model,
                        model_key,
                        model_config,
                        output_dir,
                        cache_dir,
                        settings,
                    )
                    futures[future] = model_key

            for future in as_completed(futures):
                model_key = futures[future]
                try:
                    result = future.result()
                    results.append(result)
                except Exception as e:
                    logger.error(f"[ERROR] {model_key}: {e}")
                    results.append((model_key, False, str(e)))
    else:
        # Sequential generation
        for model_key, model_config in models.items():
            model_type = model_config.get("type", "box")
            if model_type == "box":
                result = generate_box_model(
                    model_key,
                    model_config,
                    output_dir,
                    cache_dir,
                    settings,
                )
                results.append(result)
            elif model_type == "baseplate":
                result = generate_baseplate_model(
                    model_key,
                    model_config,
                    output_dir,
                    cache_dir,
                    settings,
                )
                results.append(result)
            else:
                logger.warning(f"[SKIP] {model_key}: Unknown type '{model_config.get('type')}'")
                results.append((model_key, False, f"Unknown type: {model_config.get('type')}"))

    elapsed = time.time() - start_time

    # Summary
    successful = sum(1 for _, success, _ in results if success)
    failed = len(results) - successful

    print(f"\nGenerated {successful}/{len(results)} model(s) in {elapsed:.1f}s")

    if failed > 0:
        print(f"\nFailed models:")
        for model_key, success, error in results:
            if not success:
                print(f"  - {model_key}: {error}")
        raise typer.Exit(1)
