"""CLI command: lid - Generate matching lids for boxes."""

from __future__ import annotations

import argparse
from pathlib import Path

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class LidCommand:
    """Generate matching lids for box footprints."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        parser.add_argument("length", type=float, help="Lid length in U")
        parser.add_argument("width", type=float, help="Lid width in U")
        parser.add_argument("-M", "--micro", type=int, choices=[1, 2, 3, 4], default=4)
        parser.add_argument(
            "--thickness", type=float, default=2.0, help="Top thickness in mm"
        )
        parser.add_argument(
            "--lip-depth", type=float, default=3.0, help="Insert lip depth in mm"
        )
        parser.add_argument(
            "--fit-clearance", type=float, default=0.25, help="Fit clearance in mm"
        )
        parser.add_argument(
            "--top-overhang", type=float, default=0.8, help="Top overhang in mm"
        )
        parser.add_argument("-o", "--output", type=Path, help="Output file path")
        parser.add_argument(
            "-f",
            "--format",
            choices=["stl", "step"],
            default="stl",
            help="Output format",
        )

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        params = {
            "length_u": args.length,
            "width_u": args.width,
            "micro_divisions": args.micro,
            "thickness": args.thickness,
            "lip_depth": args.lip_depth,
            "fit_clearance": args.fit_clearance,
            "top_overhang": args.top_overhang,
        }

        if args.output and args.output.suffix:
            export_format = "stl" if args.output.suffix.lower() == ".stl" else "step"
            output_path = ctx.resolve_output_path(args.output, "")
        else:
            export_format = args.format
            suffix = ".stl" if export_format == "stl" else ".step"
            output_path = ctx.resolve_output_path(
                args.output, f"lid_{args.length}x{args.width}{suffix}"
            )

        if ctx.dry_run:
            return CommandResult(
                ok=True, artifacts=[output_path], params=params, dry_run=True
            )

        try:
            from microfinity.parts.lid import GridfinityLid

            lid = GridfinityLid(**params)
            lid.render()
            if export_format == "stl":
                lid.save_stl_file(str(output_path))
            else:
                lid.save_step_file(str(output_path))
            return CommandResult(ok=True, artifacts=[output_path], params=params)
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)], params=params)


register_command("lid", LidCommand())
