"""CLI command: tolerance - Generate tolerance test fixtures."""

from __future__ import annotations

import argparse
from pathlib import Path

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class ToleranceCommand:
    """Generate tolerance test fixtures for fit verification."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        subparsers = parser.add_subparsers(
            dest="tolerance_action", help="Tolerance test actions"
        )

        # graduated set
        graduated_parser = subparsers.add_parser(
            "graduated", help="Generate graduated tolerance test set"
        )
        graduated_parser.add_argument(
            "--length", type=float, default=2, help="Length in U (default: 2)"
        )
        graduated_parser.add_argument(
            "--width", type=float, default=2, help="Width in U (default: 2)"
        )
        graduated_parser.add_argument(
            "-M",
            "--micro",
            type=int,
            choices=[1, 2, 3, 4],
            default=4,
            help="Micro-divisions (1=1U, 2=0.5U, 3=0.33U, 4=0.25U)",
        )
        graduated_parser.add_argument(
            "-o",
            "--output",
            type=Path,
            default=Path("./tolerance_tests"),
            help="Output directory",
        )
        graduated_parser.add_argument(
            "-f",
            "--format",
            choices=["stl", "step"],
            default="stl",
            help="Output format",
        )
        graduated_parser.add_argument(
            "--mode",
            choices=["orca", "full"],
            default="full",
            help="Tolerance ladder: 'orca' for fast 6-piece, 'full' for complete 9-piece",
        )
        graduated_parser.add_argument(
            "--material",
            choices=["pla", "petg", "abs", "asa", "resin"],
            help="Material type to optimize subset (optional)",
        )

        # spacing jig
        jig_parser = subparsers.add_parser(
            "jig", help="Generate spacing verification jig"
        )
        jig_parser.add_argument(
            "pitch",
            type=float,
            choices=[10.5, 14.0, 21.0],
            help="Pitch to test (10.5mm=0.25U, 14.0mm=0.33U, 21.0mm=0.5U)",
        )
        jig_parser.add_argument(
            "-o",
            "--output",
            type=Path,
            default=Path("./spacing_jigs"),
            help="Output directory",
        )

        # all tests
        all_parser = subparsers.add_parser(
            "all", help="Generate complete tolerance test suite"
        )
        all_parser.add_argument(
            "--length", type=float, default=2, help="Length in U (default: 2)"
        )
        all_parser.add_argument(
            "--width", type=float, default=2, help="Width in U (default: 2)"
        )
        all_parser.add_argument(
            "-M",
            "--micro",
            type=int,
            choices=[1, 2, 3, 4],
            default=4,
            help="Micro-divisions (1=1U, 2=0.5U, 3=0.33U, 4=0.25U)",
        )
        all_parser.add_argument(
            "-o",
            "--output",
            type=Path,
            default=Path("./tolerance_tests"),
            help="Output directory",
        )
        all_parser.add_argument(
            "-f",
            "--format",
            choices=["stl", "step"],
            default="stl",
            help="Output format",
        )
        all_parser.add_argument(
            "--mode",
            choices=["orca", "full"],
            default="full",
            help="Tolerance ladder: 'orca' for fast 6-piece, 'full' for complete 9-piece",
        )
        all_parser.add_argument(
            "--material",
            choices=["pla", "petg", "abs", "asa", "resin"],
            help="Material type to optimize subset (optional)",
        )

        # template
        template_parser = subparsers.add_parser(
            "template", help="Generate measurements template YAML file"
        )
        template_parser.add_argument(
            "-m",
            "--material",
            choices=["pla", "petg", "abs", "asa", "resin"],
            default="pla",
            help="Material type for template context",
        )
        template_parser.add_argument(
            "-o",
            "--output",
            type=Path,
            default=Path("measurements.yml"),
            help="Output file path",
        )

        parser.set_defaults(func=self._print_help)

    def _print_help(self, args: argparse.Namespace) -> int:
        """Print help when no subcommand specified."""
        print("Tolerance test fixture generator")
        print()
        print("All tolerance values are TOTAL clearance (not per-side).")
        print("Example: 0.20mm total = 0.10mm per-side clearance")
        print()
        print("Subcommands:")
        print("  graduated  - Generate graduated tolerance test set")
        print("  jig        - Generate spacing verification jig")
        print("  template   - Generate measurements template YAML file")
        print("  analyze    - Analyze calibration results")
        print("  all        - Generate complete test suite")
        print()
        print("Examples:")
        print("  # Quick OrcaSlicer-style ladder (6 pieces)")
        print("  microfinity tolerance graduated --mode orca -o ./tests")
        print()
        print("  # Full ladder with material-optimized subset")
        print("  microfinity tolerance graduated --material petg -o ./tests")
        print()
        print("  # Complete workflow:")
        print("  microfinity tolerance template -o measurements.yml")
        print("  # Edit measurements.yml, then:")
        print("  microfinity tolerance analyze measurements.yml -o report.md")
        return 0

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Execute tolerance command."""
        if hasattr(args, "func") and args.func != self._print_help:
            return args.func(ctx, args)
        return self._handle_default(ctx, args)

    def _handle_default(
        self, ctx: CLIContext, args: argparse.Namespace
    ) -> CommandResult:
        """Handle default case (show help)."""
        self._print_help(args)
        return CommandResult(ok=True)

    def _handle_graduated(
        self, ctx: argparse.Namespace, args: argparse.Namespace
    ) -> CommandResult:
        """Generate graduated tolerance test set."""
        try:
            from microfinity.calibration.tolerance_tests import (
                GraduatedFitTestSet,
            )
        except ImportError:
            return CommandResult(
                ok=False,
                errors=[
                    "CadQuery not installed. Cannot generate 3D geometry.",
                    "",
                    "Recommended installation (conda):",
                    "  conda install -c conda-forge cadquery",
                    "",
                    "Alternative (pip - may have compatibility issues):",
                    "  pip install cadquery",
                    "",
                    "Or install all extras:",
                    "  pip install microfinity[all]",
                    "",
                    "For dry-run (no geometry generation):",
                    "  microfinity --dry-run tolerance graduated ...",
                ],
            )

        if args.dry_run:
            ladder_desc = "orca (6-piece)" if args.mode == "orca" else "full (9-piece)"
            material_info = f", material={args.material}" if args.material else ""
            return CommandResult(
                ok=True,
                artifacts=[args.output],
                params={
                    "length_u": args.length,
                    "width_u": args.width,
                    "micro_divisions": args.micro,
                    "format": args.format,
                    "mode": args.mode,
                    "ladder": ladder_desc,
                    "material": args.material or "any",
                },
                dry_run=True,
            )

        try:
            files = GraduatedFitTestSet.export_all(
                length_u=args.length,
                width_u=args.width,
                micro_divisions=args.micro,
                output_dir=str(args.output),
                format=args.format,
                mode=args.mode,
                material=args.material,
            )

            return CommandResult(
                ok=True,
                artifacts=files,
                params={
                    "length_u": args.length,
                    "width_u": args.width,
                    "tolerances": GraduatedFitTestSet.TOLERANCES,
                },
            )
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_jig(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Generate spacing jig."""
        try:
            from microfinity.calibration.tolerance_tests import generate_spacing_jig
        except ImportError:
            return CommandResult(
                ok=False,
                errors=[
                    "CadQuery not installed. Cannot generate 3D geometry.",
                    "Options:",
                    "  1. Use --dry-run to see what would be generated",
                    "  2. Install CadQuery: pip install cadquery",
                    "  3. Install all extras: pip install microfinity[all]",
                ],
            )

        if args.dry_run:
            return CommandResult(
                ok=True,
                artifacts=[args.output],
                params={"pitch_mm": args.pitch},
                dry_run=True,
            )

        try:
            filepath = generate_spacing_jig(
                pitch_mm=args.pitch,
                output_dir=str(args.output),
            )
            return CommandResult(
                ok=True,
                artifacts=[filepath],
                params={"pitch_mm": args.pitch},
            )
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_all(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Generate complete test suite."""
        try:
            from microfinity.calibration.tolerance_tests import (
                export_all_tolerance_tests,
            )
        except ImportError:
            return CommandResult(
                ok=False,
                errors=[
                    "CadQuery not installed. Cannot generate 3D geometry.",
                    "Options:",
                    "  1. Use --dry-run to see what would be generated",
                    "  2. Install CadQuery: pip install cadquery",
                    "  3. Install all extras: pip install microfinity[all]",
                ],
            )

        if args.dry_run:
            return CommandResult(
                ok=True,
                artifacts=[args.output],
                params={"suite": "complete"},
                dry_run=True,
            )

        try:
            results = export_all_tolerance_tests(
                output_dir=str(args.output),
            )

            all_files = results.get("tolerance_set", []) + results.get(
                "spacing_jigs", []
            )

            return CommandResult(
                ok=True,
                artifacts=all_files,
                params={
                    "tolerance_count": len(results.get("tolerance_set", [])),
                    "jig_count": len(results.get("spacing_jigs", [])),
                },
            )
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_analyze(
        self, ctx: CLIContext, args: argparse.Namespace
    ) -> CommandResult:
        """Analyze calibration results."""
        try:
            from microfinity.calibration.tolerance_tests import (
                analyze_tolerance_results,
                export_calibration_report,
            )
        except ImportError as e:
            return CommandResult(ok=False, errors=[f"Missing dependency: {e}"])

        # Load measurements from YAML
        import yaml

        try:
            with open(args.input) as f:
                measurements = yaml.safe_load(f)
        except Exception as e:
            return CommandResult(ok=False, errors=[f"Failed to load measurements: {e}"])

        # Analyze results
        analysis = analyze_tolerance_results(measurements, material=args.material)

        # Export report
        try:
            report_path = export_calibration_report(
                measurements, str(args.output), material=args.material
            )
            return CommandResult(
                ok=True,
                artifacts=[Path(report_path)],
                params={
                    "recommended_tolerance": analysis.get("recommended_tolerance"),
                    "xy_compensation": analysis.get("suggested_xy_compensation"),
                    "warnings": len(analysis.get("warnings", [])),
                },
            )
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)])

    def _handle_template(
        self, ctx: CLIContext, args: argparse.Namespace
    ) -> CommandResult:
        """Generate measurements template."""
        try:
            from microfinity.calibration.tolerance_tests import (
                generate_measurement_template,
            )
        except ImportError as e:
            return CommandResult(ok=False, errors=[f"Missing dependency: {e}"])

        try:
            template_path = generate_measurement_template(
                material=args.material,
                output_path=str(args.output),
            )
            return CommandResult(
                ok=True,
                artifacts=[Path(template_path)],
                params={
                    "material": args.material,
                    "template": str(args.output),
                },
            )
        except Exception as e:
            return CommandResult(ok=False, errors=[str(e)])


# Wire up subcommand handlers
original_add_args = ToleranceCommand.add_args.__get__(None, ToleranceCommand)


def patched_add_args(self, parser):
    """Add args with properly wired subcommands."""
    subparsers = parser.add_subparsers(dest="tolerance_action")

    # graduated
    grad = subparsers.add_parser("graduated", help="Graduated tolerance test set")
    grad.add_argument("--length", type=float, default=2)
    grad.add_argument("--width", type=float, default=2)
    grad.add_argument("-M", "--micro", type=int, choices=[1, 2, 3, 4], default=4)
    grad.add_argument("-o", "--output", type=Path, default=Path("./tolerance_tests"))
    grad.add_argument("-f", "--format", choices=["stl", "step"], default="stl")
    grad.add_argument(
        "--mode",
        choices=["orca", "full"],
        default="full",
        help="Tolerance ladder: 'orca' for 6-piece, 'full' for 9-piece",
    )
    grad.add_argument(
        "--material",
        choices=["pla", "petg", "abs", "asa", "resin"],
        help="Material for optimized subset printing",
    )
    grad.set_defaults(handler=self._handle_graduated)

    # jig
    jig = subparsers.add_parser("jig", help="Spacing verification jig")
    jig.add_argument("pitch", type=float, choices=[10.5, 14.0, 21.0])
    jig.add_argument("-o", "--output", type=Path, default=Path("./spacing_jigs"))
    jig.set_defaults(handler=self._handle_jig)

    # template
    template = subparsers.add_parser("template", help="Generate measurements template")
    template.add_argument(
        "-m",
        "--material",
        default="pla",
        choices=["pla", "petg", "abs", "asa", "resin"],
    )
    template.add_argument("-o", "--output", type=Path, default=Path("measurements.yml"))
    template.set_defaults(handler=self._handle_template)

    # analyze
    analyze = subparsers.add_parser("analyze", help="Analyze calibration results")
    analyze.add_argument("input", type=Path, help="Measurements YAML file")
    analyze.add_argument(
        "-m", "--material", default="pla", help="Material type (pla/petg/abs/asa/resin)"
    )
    analyze.add_argument(
        "-o",
        "--output",
        type=Path,
        default=Path("calibration_report.md"),
        help="Output report path",
    )
    analyze.set_defaults(handler=self._handle_analyze)

    # all
    all_p = subparsers.add_parser("all", help="Complete test suite")
    all_p.add_argument("--length", type=float, default=2)
    all_p.add_argument("--width", type=float, default=2)
    all_p.add_argument("-M", "--micro", type=int, choices=[1, 2, 3, 4], default=4)
    all_p.add_argument("-o", "--output", type=Path, default=Path("./tolerance_tests"))
    all_p.add_argument("-f", "--format", choices=["stl", "step"], default="stl")
    all_p.add_argument("--mode", choices=["orca", "full"], default="full")
    all_p.add_argument("--material", choices=["pla", "petg", "abs", "asa", "resin"])
    all_p.set_defaults(handler=self._handle_all)

    parser.set_defaults(handler=self._print_help)


ToleranceCommand.add_args = patched_add_args


def patched_execute(self, ctx, args):
    """Execute with handler dispatch."""
    handler = getattr(args, "handler", self._print_help)
    if handler == self._print_help:
        return CommandResult(ok=True)
    return handler(ctx, args)


ToleranceCommand.execute = patched_execute

register_command("tolerance", ToleranceCommand())
