"""
Meshcut command implementation.
"""

import logging
from pathlib import Path
from typing import Annotated, Optional

import typer

from ..config import load_settings
from ..config.params import MeshcutParams
from ..logging import configure_logging

logger = logging.getLogger(__name__)


def meshcut(
    ctx: typer.Context,
    # Required arguments
    input: Annotated[Path, typer.Argument(help="Input STL or 3MF file")],
    # Required output
    output: Annotated[
        Path,
        typer.Option("-o", "--output", help="Output STL file", show_default=False),
    ] = ...,
    # Micro-divisions
    micro: Annotated[
        Optional[int],
        typer.Option("-m", "--micro", help="Micro-divisions (1, 2, or 4) [default: 4]"),
    ] = None,
    # Geometry options
    depth: Annotated[
        Optional[float],
        typer.Option("--depth", help="Cut depth in mm [default: 5.0]"),
    ] = None,
    epsilon: Annotated[
        Optional[float],
        typer.Option("--epsilon", help="Coplanar offset in mm [default: 0.001]"),
    ] = None,
    overshoot: Annotated[
        Optional[float],
        typer.Option("--overshoot", help="Cutter overshoot in mm [default: 0.5]"),
    ] = None,
    auto_overshoot: Annotated[
        bool,
        typer.Option(
            "--auto-overshoot/--no-auto-overshoot",
            help="Auto-calculate overshoot for multi-cell [default: --auto-overshoot]",
        ),
    ] = True,
    wall_cut: Annotated[
        Optional[float],
        typer.Option("--wall-cut", help="Wall cut amount in mm [default: 0.1]"),
    ] = None,
    channels: Annotated[
        Optional[bool],
        typer.Option("--channels/--no-channels", help="Add inter-cell channels [default: --channels]"),
    ] = None,
    # Processing options
    force_z_up: Annotated[
        bool,
        typer.Option("--force-z-up/--no-force-z-up", help="Assume Z-up orientation [default: auto-detect]"),
    ] = False,
    z_tolerance: Annotated[
        Optional[float],
        typer.Option("--z-tolerance", help="Z detection tolerance in mm [default: 0.1]"),
    ] = None,
    repair: Annotated[
        bool,
        typer.Option("--repair/--no-repair", help="Attempt mesh repair before processing"),
    ] = False,
    skip_clean: Annotated[
        bool,
        typer.Option("--skip-clean", help="Skip post-processing cleanup"),
    ] = False,
    skip_validate: Annotated[
        bool,
        typer.Option("--skip-validate", help="Skip validation checks"),
    ] = False,
) -> None:
    """Convert 1U Gridfinity feet to micro-feet."""
    ctx_obj = ctx.obj or {}

    # Load settings
    config_path = ctx_obj.get("config_path")
    overrides = {}
    if ctx_obj.get("log_level"):
        overrides["log_level"] = ctx_obj["log_level"]

    settings = load_settings(config_path=config_path, **overrides)
    configure_logging(settings.log_level)

    # Build params merging CLI with config defaults
    mc = settings.meshcut
    params = MeshcutParams(
        input=input,
        output=output,
        micro=micro if micro is not None else mc.micro,
        auto_overshoot=auto_overshoot,
        channels=channels if channels is not None else mc.channels,
        force_z_up=force_z_up,
        repair=repair,
        skip_clean=skip_clean,
        skip_validate=skip_validate,
        depth=depth if depth is not None else mc.depth,
        epsilon=epsilon if epsilon is not None else mc.epsilon,
        overshoot=overshoot if overshoot is not None else mc.overshoot,
        wall_cut=wall_cut if wall_cut is not None else mc.wall_cut,
        z_tolerance=z_tolerance if z_tolerance is not None else mc.z_tolerance,
    )

    logger.debug("Meshcut params: %s", params.model_dump())

    # Execute
    run_meshcut(params)


def run_meshcut(params: MeshcutParams) -> None:
    """Execute meshcut operation with typed params."""
    # For now, delegate to the existing implementation
    # This will be refactored in Phase 5 to use params directly
    import argparse

    # Convert params to argparse.Namespace for backwards compatibility
    # TODO: Refactor meshcutter/pipeline/run.py to accept MeshcutParams directly
    args = argparse.Namespace(
        input=params.input,
        output=params.output,
        micro_divisions=params.micro,
        depth=params.depth,
        epsilon=params.epsilon,
        overshoot=params.overshoot,
        auto_overshoot=params.auto_overshoot,
        wall_cut=params.wall_cut,
        add_channels=params.channels,
        use_boolean=False,  # Legacy option removed - always use replace-base
        force_z_up=params.force_z_up,
        z_tolerance=params.z_tolerance,
        repair=params.repair,
        no_clean=params.skip_clean,
        no_validate=params.skip_validate,
        verbose=logger.isEnabledFor(logging.DEBUG),
    )

    from meshcutter.pipeline.run import run_meshcut as _run_meshcut

    _run_meshcut(args)
