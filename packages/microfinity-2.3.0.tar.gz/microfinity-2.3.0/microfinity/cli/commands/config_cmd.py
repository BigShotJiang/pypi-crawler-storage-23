"""CLI command: config - Configuration management."""

from __future__ import annotations

import argparse
from pathlib import Path

from microfinity.cli.commands import register_command
from microfinity.cli.context import CLIContext, CommandResult


class ConfigCommand:
    """Configuration management."""

    def add_args(self, parser: argparse.ArgumentParser) -> None:
        """Add config subcommand arguments."""
        subparsers = parser.add_subparsers(dest="config_command", title="commands")

        # validate
        validate_parser = subparsers.add_parser("validate", help="Validate config file")
        validate_parser.add_argument("file", type=Path, help="Config file to validate")

        # validate-spec
        validate_spec_parser = subparsers.add_parser("validate-spec", help="Validate spec file (YAML)")
        validate_spec_parser.add_argument("file", type=Path, help="Spec file to validate")
        validate_spec_parser.add_argument(
            "--type", choices=["gridfinity", "microfinity"], help="Spec type (auto-detected if not specified)"
        )

    def execute(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Execute the config command."""
        if args.config_command == "validate":
            return self._cmd_config_validate(ctx, args)
        elif args.config_command == "validate-spec":
            return self._cmd_config_validate_spec(ctx, args)
        else:
            return CommandResult(
                ok=False,
                errors=["Usage: microfinity config validate <file> or microfinity config validate-spec <file>"],
            )

    def _cmd_config_validate(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Validate a config file."""
        from microfinity.cli.config import load_config, validate_config

        logger = ctx.logger

        config_path = args.file

        if not config_path.exists():
            error = f"Config file not found: {config_path}"
            logger.error(error)
            return CommandResult(ok=False, errors=[error])

        logger.info(f"Validating {config_path}...")

        try:
            config = load_config(explicit_path=config_path)
            is_valid, errors, warnings = validate_config(config)

            result = {
                "file": str(config_path),
                "valid": is_valid,
                "errors": errors,
                "warnings": warnings,
            }

            if ctx.output_format == "text":
                if is_valid:
                    print(f"OK {config_path} is valid")
                else:
                    print(f"ERROR {config_path} has errors:")
                    for error in errors:
                        print(f"  - {error}")

                if warnings:
                    print("\nWarnings:")
                    for warning in warnings:
                        print(f"  - {warning}")

            return CommandResult(
                ok=is_valid,
                params=result,
                warnings=warnings,
                errors=errors if not is_valid else [],
            )

        except Exception as e:
            error = f"Failed to validate config: {e}"
            logger.error(error)
            return CommandResult(ok=False, errors=[error])

    def _cmd_config_validate_spec(self, ctx: CLIContext, args: argparse.Namespace) -> CommandResult:
        """Validate a spec file (YAML)."""
        from microfinity.spec.schema import validate_spec_file

        logger = ctx.logger
        spec_path = args.file
        spec_type = getattr(args, "type", None)

        if not spec_path.exists():
            error = f"Spec file not found: {spec_path}"
            logger.error(error)
            return CommandResult(ok=False, errors=[error])

        logger.info(f"Validating spec: {spec_path}")

        result = validate_spec_file(spec_path, spec_type)

        if ctx.output_format == "text":
            print(result)

        return CommandResult(
            ok=result.is_valid,
            warnings=result.warnings,
            errors=result.errors,
        )


# Register the command
register_command("config", ConfigCommand())
