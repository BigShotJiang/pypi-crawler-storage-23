#! /usr/bin/env python3
"""
microfinity.cli.debug - Debug tooling for mesh analysis and visualization.

Provides commands for analyzing, comparing, and debugging 3D meshes.
"""

from __future__ import annotations

import argparse
import functools
import json
import shutil
import sys
import time
import webbrowser
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, Dict


def _load_single_mesh(input_path: Path):
    """Load a mesh file and normalize Scene -> Trimesh."""
    import trimesh

    mesh = trimesh.load(str(input_path))
    if isinstance(mesh, trimesh.Scene):
        if len(mesh.geometry) == 0:
            raise ValueError("Scene contains no geometry")
        mesh = trimesh.util.concatenate(list(mesh.geometry.values()))
    return mesh


def cmd_analyze(args: argparse.Namespace) -> int:
    """Analyze a mesh file and report diagnostics."""
    import trimesh

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    print(f"Analyzing: {input_path}")
    print()

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    # Collect diagnostics
    report: Dict[str, Any] = {
        "file": str(input_path),
        "format": input_path.suffix.lower(),
        "geometry": {
            "vertices": len(mesh.vertices),
            "faces": len(mesh.faces),
            "edges": len(mesh.edges_unique),
        },
        "bounds": {
            "min": mesh.bounds[0].tolist(),
            "max": mesh.bounds[1].tolist(),
            "dimensions": (mesh.bounds[1] - mesh.bounds[0]).tolist(),
        },
        "properties": {
            "watertight": mesh.is_watertight,
            "volume": float(mesh.volume) if mesh.is_watertight else None,
            "area": float(mesh.area),
            "center_mass": mesh.center_mass.tolist() if mesh.is_watertight else None,
        },
        "quality": {
            "is_convex": mesh.is_convex,
            "euler_number": mesh.euler_number,
        },
    }

    # Check for issues
    issues = []
    if not mesh.is_watertight:
        issues.append("Mesh is not watertight (has holes)")
    if mesh.euler_number != 2:
        issues.append(
            f"Non-manifold geometry (Euler number: {mesh.euler_number}, expected 2)"
        )

    # Check for degenerate faces
    face_areas = mesh.area_faces
    degenerate_count = (face_areas < 1e-10).sum()
    if degenerate_count > 0:
        issues.append(f"Found {degenerate_count} degenerate (zero-area) faces")

    report["issues"] = issues

    # Output
    if args.output:
        output_path = Path(args.output)
        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"Report written to: {output_path}")
    else:
        # Pretty print to console
        dims = report["bounds"]["dimensions"]
        print("Geometry:")
        print(f"  Vertices: {report['geometry']['vertices']:,}")
        print(f"  Faces: {report['geometry']['faces']:,}")
        print(f"  Edges: {report['geometry']['edges']:,}")
        print()
        print("Dimensions:")
        print(f"  X: {dims[0]:.2f} mm")
        print(f"  Y: {dims[1]:.2f} mm")
        print(f"  Z: {dims[2]:.2f} mm")
        print()
        print("Properties:")
        print(f"  Watertight: {report['properties']['watertight']}")
        if report["properties"]["volume"]:
            print(f"  Volume: {report['properties']['volume']:.2f} mm^3")
        print(f"  Surface area: {report['properties']['area']:.2f} mm^2")
        print()

        if issues:
            print("Issues:")
            for issue in issues:
                print(f"  - {issue}")
        else:
            print("No issues detected.")

    return 0


def cmd_slice(args: argparse.Namespace) -> int:
    """Generate SVG cross-section at specified Z height."""
    import trimesh
    import numpy as np

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    z_height = args.z
    if z_height is None:
        # Default to middle of mesh
        z_height = (mesh.bounds[0][2] + mesh.bounds[1][2]) / 2
        print(f"Using default Z height: {z_height:.2f} mm")

    # Create slice
    try:
        slice_2d = mesh.section(plane_origin=[0, 0, z_height], plane_normal=[0, 0, 1])
    except Exception as e:
        print(f"Error creating slice: {e}", file=sys.stderr)
        return 1

    if slice_2d is None:
        print(f"No intersection at Z={z_height:.2f} mm", file=sys.stderr)
        return 1

    # Convert to 2D path
    try:
        path_2d, _ = slice_2d.to_planar()
    except Exception as e:
        print(f"Error converting to 2D: {e}", file=sys.stderr)
        return 1

    # Export to SVG
    output_path = args.output or Path(input_path.stem + f"_z{z_height:.1f}.svg")

    try:
        # Generate SVG from path polygons
        polygons = path_2d.polygons_full if hasattr(path_2d, "polygons_full") else []
        if not polygons:
            print(f"No polygons in slice at Z={z_height:.2f}", file=sys.stderr)
            return 1

        # Get bounds from all polygons
        all_coords = []
        for poly in polygons:
            if hasattr(poly, "exterior"):
                all_coords.extend(poly.exterior.coords)

        if not all_coords:
            print("No coordinates in slice", file=sys.stderr)
            return 1

        xs, ys = zip(*all_coords)
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        width = max_x - min_x
        height = max_y - min_y

        # Add padding
        padding = max(width, height) * 0.05
        min_x -= padding
        min_y -= padding
        width += 2 * padding
        height += 2 * padding

        # Generate SVG
        svg_lines = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{min_x:.3f} {min_y:.3f} {width:.3f} {height:.3f}">',
            "  <style>polygon, path { fill: none; stroke: black; stroke-width: 0.5; }</style>",
        ]
        for poly in polygons:
            if hasattr(poly, "exterior"):
                coords = " ".join(f"{x:.3f},{y:.3f}" for x, y in poly.exterior.coords)
                svg_lines.append(f'  <polygon points="{coords}"/>')
                # Also add holes
                for interior in poly.interiors:
                    coords = " ".join(f"{x:.3f},{y:.3f}" for x, y in interior.coords)
                    svg_lines.append(f'  <polygon points="{coords}" stroke="gray"/>')
        svg_lines.append("</svg>")
        svg_data = "\n".join(svg_lines)

        with open(output_path, "w") as f:
            f.write(svg_data)
        print(f"Slice exported to: {output_path}")
    except Exception as e:
        print(f"Error exporting SVG: {e}", file=sys.stderr)
        return 1

    return 0


def cmd_compare(args: argparse.Namespace) -> int:
    """Compare two meshes and report differences."""
    import trimesh
    import numpy as np

    path_a = Path(args.file_a)
    path_b = Path(args.file_b)

    for p in [path_a, path_b]:
        if not p.exists():
            print(f"Error: File not found: {p}", file=sys.stderr)
            return 1

    try:
        mesh_a = _load_single_mesh(path_a)
        mesh_b = _load_single_mesh(path_b)
    except Exception as e:
        print(f"Error loading meshes: {e}", file=sys.stderr)
        return 1

    print("Comparing:")
    print(f"  A: {path_a}")
    print(f"  B: {path_b}")
    print()

    # Basic comparison
    print("Geometry comparison:")
    print(f"  Vertices: {len(mesh_a.vertices):,} vs {len(mesh_b.vertices):,}")
    print(f"  Faces: {len(mesh_a.faces):,} vs {len(mesh_b.faces):,}")
    print()

    # Bounds comparison
    dims_a = mesh_a.bounds[1] - mesh_a.bounds[0]
    dims_b = mesh_b.bounds[1] - mesh_b.bounds[0]
    print("Dimensions (mm):")
    print(
        f"  X: {dims_a[0]:.2f} vs {dims_b[0]:.2f} (diff: {abs(dims_a[0] - dims_b[0]):.3f})"
    )
    print(
        f"  Y: {dims_a[1]:.2f} vs {dims_b[1]:.2f} (diff: {abs(dims_a[1] - dims_b[1]):.3f})"
    )
    print(
        f"  Z: {dims_a[2]:.2f} vs {dims_b[2]:.2f} (diff: {abs(dims_a[2] - dims_b[2]):.3f})"
    )
    print()

    # Volume comparison (if both watertight)
    if mesh_a.is_watertight and mesh_b.is_watertight:
        vol_a = mesh_a.volume
        vol_b = mesh_b.volume
        vol_diff = abs(vol_a - vol_b)
        vol_pct = (vol_diff / max(vol_a, vol_b)) * 100 if max(vol_a, vol_b) > 0 else 0

        print("Volume comparison:")
        print(f"  A: {vol_a:.2f} mm^3")
        print(f"  B: {vol_b:.2f} mm^3")
        print(f"  Difference: {vol_diff:.2f} mm^3 ({vol_pct:.2f}%)")

        # Boolean difference if requested
        if args.output:
            try:
                # Try to compute symmetric difference
                diff_mesh = mesh_a.difference(mesh_b)
                if diff_mesh and len(diff_mesh.faces) > 0:
                    output_path = Path(args.output)
                    diff_mesh.export(str(output_path))
                    print(f"\nDifference mesh exported to: {output_path}")
            except Exception as e:
                print(f"\nCould not compute boolean difference: {e}")
    else:
        print("Volume comparison: Skipped (one or both meshes not watertight)")

    return 0


def cmd_footprint(args: argparse.Namespace) -> int:
    """Extract and export 2D footprint of mesh."""
    import trimesh
    import numpy as np

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    # Get bottom Z
    z_min = mesh.bounds[0][2]
    z_slice = z_min + 0.1  # Slice just above bottom

    print(f"Extracting footprint at Z={z_slice:.2f} mm")

    try:
        slice_2d = mesh.section(plane_origin=[0, 0, z_slice], plane_normal=[0, 0, 1])
        if slice_2d is None:
            # Try projection instead
            print("No slice found, using convex hull projection")
            from shapely.geometry import MultiPoint

            bottom_verts = mesh.vertices[mesh.vertices[:, 2] < z_min + 1.0]
            if len(bottom_verts) == 0:
                print("Error: No bottom vertices found", file=sys.stderr)
                return 1
            points = MultiPoint(bottom_verts[:, :2])
            footprint = points.convex_hull

            # Export as SVG manually
            output_path = args.output or Path(input_path.stem + "_footprint.svg")
            bounds = footprint.bounds
            width = bounds[2] - bounds[0]
            height = bounds[3] - bounds[1]
            svg = f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{bounds[0]} {bounds[1]} {width} {height}">\n'
            coords_str = " L ".join(f"{x},{y}" for x, y in footprint.exterior.coords)
            svg += f'  <path d="M {coords_str}" fill="none" stroke="black" stroke-width="0.5"/>\n'
            svg += "</svg>"
            with open(output_path, "w") as f:
                f.write(svg)
            print(f"Footprint exported to: {output_path}")
            return 0

        path_2d, _ = slice_2d.to_planar()
        output_path = args.output or Path(input_path.stem + "_footprint.svg")
        svg_data = path_2d.to_svg()
        with open(output_path, "w") as f:
            f.write(svg_data)
        print(f"Footprint exported to: {output_path}")

    except Exception as e:
        print(f"Error extracting footprint: {e}", file=sys.stderr)
        return 1

    return 0


def add_debug_subparsers(subparsers: argparse._SubParsersAction) -> None:
    """Add debug subcommand parsers."""

    # analyze
    analyze_parser = subparsers.add_parser(
        "analyze", help="Analyze mesh and report diagnostics"
    )
    analyze_parser.add_argument(
        "input", type=Path, help="Input mesh file (STL, 3MF, OBJ)"
    )
    analyze_parser.add_argument(
        "-o", "--output", type=Path, help="Output JSON report file"
    )
    analyze_parser.set_defaults(func=cmd_analyze)

    # slice
    slice_parser = subparsers.add_parser("slice", help="Generate SVG cross-section")
    slice_parser.add_argument("input", type=Path, help="Input mesh file")
    slice_parser.add_argument(
        "-z", type=float, help="Z height for slice (default: middle)"
    )
    slice_parser.add_argument("-o", "--output", type=Path, help="Output SVG file")
    slice_parser.set_defaults(func=cmd_slice)

    # compare
    compare_parser = subparsers.add_parser("compare", help="Compare two meshes")
    compare_parser.add_argument("file_a", type=Path, help="First mesh file")
    compare_parser.add_argument("file_b", type=Path, help="Second mesh file")
    compare_parser.add_argument(
        "-o", "--output", type=Path, help="Output difference mesh"
    )
    compare_parser.set_defaults(func=cmd_compare)

    # footprint
    footprint_parser = subparsers.add_parser("footprint", help="Extract 2D footprint")
    footprint_parser.add_argument("input", type=Path, help="Input mesh file")
    footprint_parser.add_argument("-o", "--output", type=Path, help="Output SVG file")
    footprint_parser.set_defaults(func=cmd_footprint)

    # explode
    explode_parser = subparsers.add_parser(
        "explode", help="Generate exploded mesh view"
    )
    explode_parser.add_argument("input", type=Path, help="Input mesh file")
    explode_parser.add_argument(
        "-o", "--output", type=Path, help="Output exploded mesh file"
    )
    explode_parser.add_argument(
        "--distance",
        type=float,
        default=8.0,
        help="Gap distance between components in mm (default: 8.0)",
    )
    explode_parser.add_argument(
        "--axis",
        choices=["x", "y", "z"],
        default="x",
        help="Explosion axis (default: x)",
    )
    explode_parser.set_defaults(func=cmd_explode)

    # measure
    measure_parser = subparsers.add_parser(
        "measure", help="Measure mesh dimensions and key properties"
    )
    measure_parser.add_argument("input", type=Path, help="Input mesh file")
    measure_parser.add_argument(
        "--json", action="store_true", help="Print report as JSON"
    )
    measure_parser.add_argument(
        "-o", "--output", type=Path, help="Optional JSON output file"
    )
    measure_parser.set_defaults(func=cmd_measure)

    # preview
    preview_parser = subparsers.add_parser(
        "preview", help="Render ASCII art mesh preview in terminal"
    )
    preview_parser.add_argument("input", type=Path, help="Input mesh file")
    preview_parser.add_argument(
        "--view",
        choices=["top", "front", "side"],
        default="top",
        help="Projection view for preview (default: top)",
    )
    preview_parser.add_argument(
        "--width", type=int, default=80, help="Preview width in characters"
    )
    preview_parser.add_argument(
        "--height", type=int, default=30, help="Preview height in characters"
    )
    preview_parser.set_defaults(func=cmd_preview)

    # watch
    watch_parser = subparsers.add_parser(
        "watch", help="Watch mesh file and re-run debug command on changes"
    )
    watch_parser.add_argument("input", type=Path, help="Input mesh file")
    watch_parser.add_argument(
        "--on",
        choices=["analyze", "measure", "preview"],
        default="analyze",
        help="Debug action to run on each change",
    )
    watch_parser.add_argument(
        "--interval",
        type=float,
        default=1.0,
        help="Polling interval in seconds (default: 1.0)",
    )
    watch_parser.add_argument(
        "--max-events",
        type=int,
        default=0,
        help="Stop after N changes (0 = infinite)",
    )
    watch_parser.add_argument(
        "--clear",
        action="store_true",
        help="Clear terminal between reruns",
    )
    watch_parser.add_argument(
        "--json",
        action="store_true",
        help="Use JSON output when --on measure",
    )
    watch_parser.add_argument(
        "--view",
        choices=["top", "front", "side"],
        default="top",
        help="Projection view when --on preview",
    )
    watch_parser.add_argument(
        "--width", type=int, default=80, help="Preview width when --on preview"
    )
    watch_parser.add_argument(
        "--height", type=int, default=30, help="Preview height when --on preview"
    )
    watch_parser.set_defaults(func=cmd_watch)

    # viewer
    viewer_parser = subparsers.add_parser(
        "viewer", help="Launch local web-based STL viewer"
    )
    viewer_parser.add_argument("input", type=Path, help="Input STL file")
    viewer_parser.add_argument(
        "--host", type=str, default="127.0.0.1", help="Bind host"
    )
    viewer_parser.add_argument("--port", type=int, default=8765, help="Bind port")
    viewer_parser.add_argument(
        "--open", action="store_true", help="Open viewer URL in browser"
    )
    viewer_parser.set_defaults(func=cmd_viewer)


def cmd_explode(args: argparse.Namespace) -> int:
    """Generate an exploded view by separating connected components."""
    import numpy as np
    import trimesh

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    try:
        components = list(mesh.split(only_watertight=False))
    except Exception as e:
        print(f"Error splitting mesh components: {e}", file=sys.stderr)
        return 1

    if len(components) <= 1:
        print("Mesh has one component; exporting original mesh")
        components = [mesh]

    axis_index = {"x": 0, "y": 1, "z": 2}[args.axis]
    axis_vector = np.zeros(3)
    axis_vector[axis_index] = 1.0

    # Stable ordering by centroid along explosion axis
    components.sort(key=lambda c: float(c.centroid[axis_index]))

    exploded_parts = []
    running_offset = 0.0
    for idx, comp in enumerate(components):
        part = comp.copy()
        if idx > 0:
            running_offset += args.distance
        part.apply_translation(axis_vector * running_offset)
        exploded_parts.append(part)

    exploded = trimesh.util.concatenate(exploded_parts)
    output_path = args.output or Path(input_path.stem + "_exploded" + input_path.suffix)

    try:
        exploded.export(str(output_path))
    except Exception as e:
        print(f"Error exporting exploded mesh: {e}", file=sys.stderr)
        return 1

    print(f"Exploded mesh exported to: {output_path}")
    print(
        f"Components: {len(components)} | Axis: {args.axis} | Distance: {args.distance} mm"
    )
    return 0


def cmd_measure(args: argparse.Namespace) -> int:
    """Measure mesh dimensions and key geometric properties."""
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    dims = mesh.bounds[1] - mesh.bounds[0]
    report: Dict[str, Any] = {
        "file": str(input_path),
        "dimensions_mm": {
            "x": float(dims[0]),
            "y": float(dims[1]),
            "z": float(dims[2]),
        },
        "bounds_mm": {
            "min": [float(v) for v in mesh.bounds[0]],
            "max": [float(v) for v in mesh.bounds[1]],
        },
        "centroid_mm": [float(v) for v in mesh.centroid],
        "surface_area_mm2": float(mesh.area),
        "volume_mm3": float(mesh.volume) if mesh.is_watertight else None,
        "watertight": bool(mesh.is_watertight),
        "vertices": int(len(mesh.vertices)),
        "faces": int(len(mesh.faces)),
    }

    if args.output:
        with open(args.output, "w") as f:
            json.dump(report, f, indent=2)
        print(f"Measurement report written to: {args.output}")

    if args.json:
        print(json.dumps(report, indent=2))
        return 0

    print(f"File: {input_path}")
    print("Dimensions (mm):")
    print(f"  X: {report['dimensions_mm']['x']:.3f}")
    print(f"  Y: {report['dimensions_mm']['y']:.3f}")
    print(f"  Z: {report['dimensions_mm']['z']:.3f}")
    print(f"Surface Area: {report['surface_area_mm2']:.3f} mm^2")
    if report["volume_mm3"] is not None:
        print(f"Volume: {report['volume_mm3']:.3f} mm^3")
    else:
        print("Volume: N/A (mesh not watertight)")
    print(f"Vertices: {report['vertices']:,} | Faces: {report['faces']:,}")
    return 0


def cmd_preview(args: argparse.Namespace) -> int:
    """Render an ASCII preview of a mesh in terminal."""
    import numpy as np

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    try:
        mesh = _load_single_mesh(input_path)
    except Exception as e:
        print(f"Error loading mesh: {e}", file=sys.stderr)
        return 1

    if len(mesh.vertices) == 0:
        print("Error: Mesh has no vertices", file=sys.stderr)
        return 1

    verts = mesh.vertices

    if args.view == "top":
        x_vals, y_vals = verts[:, 0], verts[:, 1]
    elif args.view == "front":
        x_vals, y_vals = verts[:, 0], verts[:, 2]
    else:
        x_vals, y_vals = verts[:, 1], verts[:, 2]

    min_x, max_x = float(x_vals.min()), float(x_vals.max())
    min_y, max_y = float(y_vals.min()), float(y_vals.max())

    width = max(args.width, 20)
    height = max(args.height, 10)

    dx = max(max_x - min_x, 1e-6)
    dy = max(max_y - min_y, 1e-6)

    grid = np.zeros((height, width), dtype=np.int32)

    sx = (width - 1) / dx
    sy = (height - 1) / dy

    for x, y in zip(x_vals, y_vals):
        gx = int((float(x) - min_x) * sx)
        gy = int((float(y) - min_y) * sy)
        gx = min(max(gx, 0), width - 1)
        gy = min(max(gy, 0), height - 1)
        grid[gy, gx] += 1

    max_count = int(grid.max())
    if max_count <= 0:
        print("No visible points for preview")
        return 0

    ramp = " .:-=+*#%@"
    print(f"ASCII preview: {input_path} [{args.view}] {width}x{height}")
    print()
    for row in range(height - 1, -1, -1):
        chars = []
        for col in range(width):
            count = grid[row, col]
            if count <= 0:
                chars.append(" ")
                continue
            idx = int((count / max_count) * (len(ramp) - 1))
            chars.append(ramp[idx])
        print("".join(chars))

    print()
    print(
        f"Bounds ({args.view}): X[{min_x:.2f}, {max_x:.2f}] Y[{min_y:.2f}, {max_y:.2f}]"
    )
    return 0


def cmd_watch(args: argparse.Namespace) -> int:
    """Watch a mesh file and re-run analysis on change."""
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    def _run_once() -> int:
        if args.on == "analyze":
            return cmd_analyze(argparse.Namespace(input=input_path, output=None))
        if args.on == "measure":
            return cmd_measure(
                argparse.Namespace(input=input_path, json=args.json, output=None)
            )
        return cmd_preview(
            argparse.Namespace(
                input=input_path,
                view=args.view,
                width=args.width,
                height=args.height,
            )
        )

    last_sig = None
    events = 0
    last_rc = 0

    print(
        f"Watching {input_path} (mode={args.on}, interval={args.interval:.2f}s). Press Ctrl+C to stop."
    )

    try:
        while True:
            try:
                stat = input_path.stat()
                sig = (stat.st_mtime_ns, stat.st_size)
            except FileNotFoundError:
                print("File deleted while watching", file=sys.stderr)
                return 1

            if sig != last_sig:
                if args.clear:
                    print("\033[2J\033[H", end="")
                print(f"\n=== Change detected @ {time.strftime('%H:%M:%S')} ===")
                last_sig = sig
                events += 1
                last_rc = _run_once()
                if args.max_events > 0 and events >= args.max_events:
                    return last_rc

            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nStopped watch mode")
        return 0


def cmd_viewer(args: argparse.Namespace) -> int:
    """Serve a local web-based 3D viewer for an STL mesh."""
    from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        return 1

    with TemporaryDirectory(prefix="microfinity-viewer-") as tmp:
        tmp_dir = Path(tmp)
        component_specs = []

        try:
            mesh = _load_single_mesh(input_path)
            parts = list(mesh.split(only_watertight=False))
            if not parts:
                parts = [mesh]

            for idx, part in enumerate(parts, start=1):
                filename = f"component_{idx:03d}.stl"
                filepath = tmp_dir / filename
                part.export(str(filepath))

                part_bounds = part.bounds
                dims = part_bounds[1] - part_bounds[0]
                component_specs.append(
                    {
                        "id": idx,
                        "name": f"Component {idx}",
                        "file": filename,
                        "faces": int(len(part.faces)),
                        "vertices": int(len(part.vertices)),
                        "dims": [float(dims[0]), float(dims[1]), float(dims[2])],
                    }
                )
        except Exception:
            model_name = "component_001.stl"
            model_path = tmp_dir / model_name
            shutil.copy2(input_path, model_path)
            component_specs.append(
                {
                    "id": 1,
                    "name": "Component 1",
                    "file": model_name,
                    "faces": None,
                    "vertices": None,
                    "dims": None,
                }
            )

        component_json = json.dumps(component_specs)

        html = f"""<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>Microfinity Viewer</title>
  <style>
    body {{ margin: 0; font-family: 'IBM Plex Sans', 'Segoe UI', sans-serif; background: radial-gradient(circle at top, #132038, #0c1220 55%, #070b14); color: #e7edf7; }}
    #hud {{ position: fixed; top: 12px; left: 12px; right: 12px; display: flex; gap: 12px; align-items: center; padding: 10px 12px; border-radius: 10px; backdrop-filter: blur(8px); background: rgba(10,15,25,0.7); border: 1px solid rgba(170,200,255,0.24); }}
    #canvas {{ width: 100vw; height: 100vh; display: block; }}
    .tag {{ font-size: 12px; padding: 3px 8px; border-radius: 999px; background: rgba(95,162,255,0.2); border: 1px solid rgba(126,184,255,0.3); }}
    #layers {{ position: fixed; top: 74px; right: 12px; width: 280px; max-height: calc(100vh - 90px); overflow: auto; padding: 10px; border-radius: 10px; backdrop-filter: blur(8px); background: rgba(10,15,25,0.7); border: 1px solid rgba(170,200,255,0.24); }}
    .component {{ display: flex; align-items: flex-start; gap: 8px; font-size: 12px; padding: 6px 2px; border-bottom: 1px solid rgba(126,184,255,0.16); }}
    .swatch {{ width: 10px; height: 10px; border-radius: 999px; margin-top: 3px; flex: 0 0 auto; }}
    .meta {{ opacity: 0.8; font-size: 11px; margin-top: 2px; }}
  </style>
</head>
<body>
  <div id=\"hud\">
    <strong>Microfinity STL Viewer</strong>
    <span class=\"tag\">Orbit: drag</span>
    <span class=\"tag\">Pan: right-drag</span>
    <span class=\"tag\">Zoom: scroll</span>
    <span class=\"tag\">Model: {input_path.name}</span>
    <label class=\"tag\"><input id=\"wireToggle\" type=\"checkbox\" /> Wireframe</label>
    <label class=\"tag\">Clip Z <input id=\"clipRange\" type=\"range\" min=\"0\" max=\"100\" value=\"100\" /></label>
    <span id=\"dims\" class=\"tag\">Dims: ...</span>
    <span class=\"tag\">Parts: {len(component_specs)}</span>
  </div>
  <aside id=\"layers\">
    <strong>Components</strong>
    <div id=\"componentList\"></div>
  </aside>
  <canvas id=\"canvas\"></canvas>
  <script type=\"module\">
    import * as THREE from 'https://unpkg.com/three@0.162.0/build/three.module.js';
    import {{ OrbitControls }} from 'https://unpkg.com/three@0.162.0/examples/jsm/controls/OrbitControls.js';
    import {{ STLLoader }} from 'https://unpkg.com/three@0.162.0/examples/jsm/loaders/STLLoader.js';

    const canvas = document.getElementById('canvas');
    const renderer = new THREE.WebGLRenderer({{ canvas, antialias: true }});
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x070b14);
    const assembly = new THREE.Group();
    scene.add(assembly);

    const componentSpecs = {component_json};

    const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 5000);
    camera.position.set(120, 100, 140);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;

    scene.add(new THREE.AmbientLight(0xffffff, 0.55));
    const keyLight = new THREE.DirectionalLight(0x9ec8ff, 0.85);
    keyLight.position.set(80, 120, 60);
    scene.add(keyLight);
    const fill = new THREE.DirectionalLight(0xffddb5, 0.45);
    fill.position.set(-90, 40, -80);
    scene.add(fill);

    const grid = new THREE.GridHelper(260, 26, 0x4a6da8, 0x23344f);
    scene.add(grid);

    const colors = [0x6eb6ff, 0xffb266, 0x74d89c, 0xf78fb5, 0xdacbff, 0xf5eb7a, 0x8ed1d1, 0xff8b8b];
    const clipPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), -1000);
    renderer.localClippingEnabled = true;

    const loader = new STLLoader();
    const wireToggle = document.getElementById('wireToggle');
    const clipRange = document.getElementById('clipRange');
    const dims = document.getElementById('dims');
    const componentList = document.getElementById('componentList');
    const materials = [];

    function addComponentRow(spec, mesh, colorHex) {{
      const row = document.createElement('label');
      row.className = 'component';

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = true;
      checkbox.addEventListener('change', () => {{
        mesh.visible = checkbox.checked;
      }});

      const swatch = document.createElement('span');
      swatch.className = 'swatch';
      swatch.style.background = '#' + colorHex.toString(16).padStart(6, '0');

      const text = document.createElement('div');
      const dimsText = spec.dims
        ? `${{spec.dims[0].toFixed(2)}} x ${{spec.dims[1].toFixed(2)}} x ${{spec.dims[2].toFixed(2)}} mm`
        : 'dims unavailable';
      const counts = spec.faces && spec.vertices
        ? `${{spec.vertices.toLocaleString()}} v / ${{spec.faces.toLocaleString()}} f`
        : 'counts unavailable';
      text.innerHTML = `<div>${{spec.name}}</div><div class=\"meta\">${{counts}}<br/>${{dimsText}}</div>`;

      row.appendChild(checkbox);
      row.appendChild(swatch);
      row.appendChild(text);
      componentList.appendChild(row);
    }}

    let loaded = 0;
    for (let i = 0; i < componentSpecs.length; i++) {{
      const spec = componentSpecs[i];
      const color = colors[i % colors.length];
      loader.load(spec.file, (geometry) => {{
        geometry.computeVertexNormals();
        const material = new THREE.MeshStandardMaterial({{
          color,
          metalness: 0.08,
          roughness: 0.52,
          side: THREE.DoubleSide,
          clippingPlanes: [clipPlane],
        }});
        materials.push(material);

        const mesh = new THREE.Mesh(geometry, material);
        mesh.castShadow = false;
        mesh.receiveShadow = false;
        assembly.add(mesh);
        addComponentRow(spec, mesh, color);

        loaded += 1;
        if (loaded === componentSpecs.length) {{
          const rawBox = new THREE.Box3().setFromObject(assembly);
          const center = rawBox.getCenter(new THREE.Vector3());
          assembly.position.sub(center);

          const box = new THREE.Box3().setFromObject(assembly);
          const full = box.getSize(new THREE.Vector3());
          const size = full.length();
          dims.textContent = `Dims: ${{full.x.toFixed(2)}} x ${{full.y.toFixed(2)}} x ${{full.z.toFixed(2)}} mm`;

          const zMin = -full.z / 2;
          const zMax = full.z / 2;
          clipRange.addEventListener('input', () => {{
            const t = Number(clipRange.value) / 100;
            const zCurrent = zMin + (zMax - zMin) * t;
            clipPlane.constant = zCurrent;
          }});

          wireToggle.addEventListener('change', () => {{
            const on = Boolean(wireToggle.checked);
            for (const m of materials) m.wireframe = on;
          }});

          const fit = size * 0.9;
          camera.position.set(fit, fit * 0.8, fit);
          controls.update();
        }}
      }});
    }}

    function animate() {{
      controls.update();
      renderer.render(scene, camera);
      requestAnimationFrame(animate);
    }}
    animate();

    window.addEventListener('resize', () => {{
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    }});
  </script>
</body>
</html>
"""

        index_path = tmp_dir / "index.html"
        index_path.write_text(html, encoding="utf-8")

        handler = functools.partial(SimpleHTTPRequestHandler, directory=str(tmp_dir))
        server = ThreadingHTTPServer((args.host, args.port), handler)
        url = f"http://{args.host}:{args.port}/index.html"

        print(f"Serving viewer at {url}")
        if args.open:
            webbrowser.open(url)

        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
            print("Viewer stopped")

    return 0


def cmd_debug(args: argparse.Namespace) -> int:
    """Debug subcommand dispatcher."""
    if hasattr(args, "func"):
        return args.func(args)
    else:
        print("Usage: microfinity debug <command> [options]")
        print()
        print("Commands:")
        print("  analyze   - Analyze mesh and report diagnostics")
        print("  slice     - Generate SVG cross-section at Z height")
        print("  compare   - Compare two meshes")
        print("  footprint - Extract 2D footprint")
        print("  explode   - Split and separate connected components")
        print("  measure   - Report dimensions and geometric properties")
        print("  preview   - Render ASCII terminal mesh preview")
        print("  watch     - Re-run debug command when file changes")
        print("  viewer    - Launch local web-based STL viewer")
        return 0
