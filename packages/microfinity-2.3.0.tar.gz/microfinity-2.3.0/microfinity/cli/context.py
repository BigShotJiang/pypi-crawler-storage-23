"""CLI runtime context and shared services for microfinity commands."""

from __future__ import annotations

import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union


@dataclass
class CommandResult:
    """Result of a CLI command execution.

    This is the standard return type for all CLI commands.
    It supports both human-readable and machine-readable output.
    """

    ok: bool
    artifacts: List[Path] = field(default_factory=list)
    params: Dict[str, Any] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    timing: Dict[str, float] = field(default_factory=dict)
    dry_run: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary for JSON/YAML serialization."""
        return {
            "ok": self.ok,
            "artifacts": [str(p) for p in self.artifacts],
            "params": self.params,
            "warnings": self.warnings,
            "errors": self.errors,
            "timing": self.timing,
            "dry_run": self.dry_run,
        }


@dataclass
class CLIContext:
    """Runtime context for CLI commands.

    Provides common services: logging, output formatting, path resolution.
    """

    verbosity: int = 0  # -2=quiet, -1=error, 0=info, 1=debug, 2=trace
    output_format: str = "text"  # text, json, yaml
    output_dir: Optional[Path] = None
    dry_run: bool = False
    config_path: Optional[Path] = None

    def __post_init__(self):
        self._setup_logging()

    def _setup_logging(self) -> None:
        """Configure logging based on verbosity level."""
        # Map verbosity to logging level
        # -2 (quiet) -> ERROR
        # -1 -> WARNING
        # 0 (default) -> INFO
        # 1 (-v) -> DEBUG
        # 2 (-vv) -> DEBUG (with more trace)
        level_map = {
            -2: logging.ERROR,
            -1: logging.WARNING,
            0: logging.INFO,
            1: logging.DEBUG,
            2: logging.DEBUG,
        }
        level = level_map.get(self.verbosity, logging.INFO)

        # Configure root logger for microfinity
        logger = logging.getLogger("microfinity")
        logger.setLevel(level)

        # Clear existing handlers to avoid duplicates
        logger.handlers.clear()

        # Add stderr handler (CLI logs go to stderr)
        handler = logging.StreamHandler(sys.stderr)
        handler.setLevel(level)

        # Simple format for CLI
        if self.verbosity >= 1:
            formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        else:
            formatter = logging.Formatter("%(levelname)s: %(message)s")

        handler.setFormatter(formatter)
        logger.addHandler(handler)

        # Prevent propagation to avoid duplicate logs
        logger.propagate = False

    @property
    def logger(self) -> logging.Logger:
        """Get the configured logger."""
        return logging.getLogger("microfinity")

    def is_quiet(self) -> bool:
        """Check if running in quiet mode."""
        return self.verbosity <= -2

    def is_verbose(self) -> bool:
        """Check if running in verbose mode."""
        return self.verbosity >= 1

    def is_trace(self) -> bool:
        """Check if running in trace mode."""
        return self.verbosity >= 2

    def resolve_output_path(self, path: Optional[Path], default_name: str) -> Path:
        """Resolve output path considering output_dir.

        Args:
            path: Explicit output path from CLI args
            default_name: Default filename if no path specified

        Returns:
            Resolved Path object
        """
        if path is not None:
            # Explicit path provided
            if self.output_dir is not None and not path.is_absolute():
                # Relative path + output_dir = join them
                return self.output_dir / path
            return path

        # No explicit path, use default name in output_dir
        if self.output_dir is not None:
            return self.output_dir / default_name

        # Default to current directory
        return Path(default_name)

    def emit_result(self, result: CommandResult) -> int:
        """Emit command result in appropriate format.

        Args:
            result: The command result to emit

        Returns:
            Exit code (0 for success, 1 for failure)
        """
        if self.output_format == "json":
            import json

            print(json.dumps(result.to_dict(), indent=2))
        elif self.output_format == "yaml":
            import yaml

            print(yaml.dump(result.to_dict(), default_flow_style=False))
        else:
            # Text format - human readable
            self._emit_text_result(result)

        return 0 if result.ok else 1

    def _emit_text_result(self, result: CommandResult) -> None:
        """Emit result in human-readable text format."""
        if result.dry_run:
            print("DRY RUN - Would generate:")

        if result.artifacts:
            for artifact in result.artifacts:
                if result.dry_run:
                    print(f"  {artifact}")
                else:
                    print(f"Wrote {artifact}")

        if result.warnings and not self.is_quiet():
            for warning in result.warnings:
                self.logger.warning(warning)

        if result.errors:
            for error in result.errors:
                self.logger.error(error)

        if self.is_verbose() and result.params:
            self.logger.debug(f"Parameters: {result.params}")

        if self.is_verbose() and result.timing:
            duration = result.timing.get("duration", 0)
            self.logger.debug(f"Duration: {duration:.2f}s")


def create_context(args: Any) -> CLIContext:
    """Create CLIContext from parsed argparse args.

    Args:
        args: Parsed argparse namespace

    Returns:
        Configured CLIContext
    """
    # Calculate verbosity from -q/-v/-vv flags
    verbosity = 0
    if hasattr(args, "quiet") and args.quiet:
        verbosity = -2
    elif hasattr(args, "verbose"):
        if args.verbose >= 2:
            verbosity = 2
        elif args.verbose == 1:
            verbosity = 1

    # Determine output format
    output_format = "text"
    if hasattr(args, "json") and args.json:
        output_format = "json"
    elif hasattr(args, "yaml") and args.yaml:
        output_format = "yaml"

    # Output directory
    output_dir = None
    if hasattr(args, "output_dir") and args.output_dir:
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

    # Dry run
    dry_run = hasattr(args, "dry_run") and args.dry_run

    # Config path
    config_path = None
    if hasattr(args, "config") and args.config:
        config_path = Path(args.config)

    return CLIContext(
        verbosity=verbosity,
        output_format=output_format,
        output_dir=output_dir,
        dry_run=dry_run,
        config_path=config_path,
    )
