"""
Main Typer application for microfinity CLI.
"""

from pathlib import Path
from typing import Annotated, Optional

import typer

from .config.base import LogLevel

# Banner for --help
BANNER = r"""
           _                __ _       _ _
 _ __ ___ (_) ___ _ __ ___ / _(_)_ __ (_) |_ _   _
| '_ ` _ \| |/ __| '__/ _ \ |_| | '_ \| | __| | | |
| | | | | | | (__| | | (_) |  _| | | | | | |_| |_| |
|_| |_| |_|_|\___|_|  \___/|_| |_|_| |_|_|\__|\__, |
                                              |___/
"""

app = typer.Typer(
    name="microfinity",
    help="Gridfinity-compatible storage system generator",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


def version_callback(value: bool) -> None:
    """Print version and exit."""
    if value:
        from microfinity import __version__

        print(f"microfinity {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    ctx: typer.Context,
    log_level: Annotated[
        Optional[LogLevel],
        typer.Option(
            "--log-level",
            "-L",
            help="Logging level (debug, info, warning, error, critical)",
            envvar="MICROFINITY_LOG_LEVEL",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option(
            "--verbose",
            "-v",
            help="Shorthand for --log-level=debug",
        ),
    ] = False,
    config: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            help="Config file path (default: ./microfinity.yaml)",
            envvar="MICROFINITY_CONFIG",
        ),
    ] = None,
    version: Annotated[
        bool,
        typer.Option(
            "--version",
            help="Show version and exit",
            callback=version_callback,
            is_eager=True,
        ),
    ] = False,
) -> None:
    """
    Microfinity - Gridfinity generator with micro-divisions.

    Generate Gridfinity-compatible boxes, baseplates, and convert existing
    models to use micro-divided feet.
    """
    ctx.ensure_object(dict)

    # Store for subcommands
    if verbose:
        ctx.obj["log_level"] = LogLevel.DEBUG
    elif log_level is not None:
        ctx.obj["log_level"] = log_level

    if config is not None:
        ctx.obj["config_path"] = config


# Register commands
from .commands import baseplate, batch, box, config_app, info, layout, meshcut
from .debug import debug_app

app.command()(box)
app.command()(baseplate)
app.command()(layout)
app.command()(meshcut)
app.command()(info)
app.command()(batch)
app.add_typer(config_app)
app.add_typer(debug_app)


def cli() -> None:
    """Main CLI entry point."""
    app()
