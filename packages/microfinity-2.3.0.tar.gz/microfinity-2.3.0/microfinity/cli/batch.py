"""Batch generation command for microfinity CLI.

Allows generating multiple items from a single config file.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any, Dict, List

from microfinity.cli.context import CLIContext, CommandResult


def run_batch(ctx: CLIContext, config: Dict[str, Any]) -> CommandResult:
    """Run batch generation from config.

    Args:
        ctx: CLI context
        config: Batch configuration with 'items' list

    Returns:
        CommandResult with aggregated results
    """
    logger = ctx.logger

    items = config.get("items", [])
    if not items:
        return CommandResult(
            ok=False,
            errors=["No items in batch config"],
        )

    output_dir = config.get("output_dir")
    if output_dir:
        ctx.output_dir = Path(output_dir)
        ctx.output_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Batch generation: {len(items)} items")

    results: List[CommandResult] = []
    all_artifacts: List[Path] = []
    all_errors: List[str] = []
    all_warnings: List[str] = []

    start_time = time.time()

    for i, item in enumerate(items):
        item_name = item.get("name", f"item_{i}")
        item_type = item.get("type")
        item_params = item.get("params", {})

        logger.info(f"[{i+1}/{len(items)}] Generating {item_name} ({item_type})")

        if ctx.dry_run:
            logger.info(f"  Would generate: {item_type} with params {item_params}")
            continue

        # Dispatch to appropriate generator
        try:
            result = _generate_item(ctx, item_type, item_name, item_params)
            results.append(result)

            if result.ok:
                all_artifacts.extend(result.artifacts)
            else:
                all_errors.extend(result.errors)

            all_warnings.extend(result.warnings)

        except Exception as e:
            error_msg = f"Failed to generate {item_name}: {e}"
            logger.error(error_msg)
            all_errors.append(error_msg)

    duration = time.time() - start_time

    # Aggregate results
    ok = len(all_errors) == 0

    return CommandResult(
        ok=ok,
        artifacts=all_artifacts,
        params={"batch_size": len(items), "results": [r.to_dict() for r in results]},
        warnings=all_warnings,
        errors=all_errors,
        timing={"duration": duration},
        dry_run=ctx.dry_run,
    )


def _generate_item(ctx: CLIContext, item_type: str, name: str, params: Dict[str, Any]) -> CommandResult:
    """Generate a single item.

    Args:
        ctx: CLI context
        item_type: Type of item ('box', 'baseplate', etc.)
        name: Item name
        params: Generation parameters

    Returns:
        CommandResult for this item
    """
    logger = ctx.logger

    if item_type == "box":
        return _generate_box(ctx, name, params)
    elif item_type == "baseplate":
        return _generate_baseplate(ctx, name, params)
    else:
        return CommandResult(
            ok=False,
            errors=[f"Unknown item type: {item_type}"],
        )


def _generate_box(ctx: CLIContext, name: str, params: Dict[str, Any]) -> CommandResult:
    """Generate a box."""
    from microfinity import GridfinityBox

    logger = ctx.logger

    # Set default output name
    length = params.get("length_u", 1)
    width = params.get("width_u", 1)
    height = params.get("height_u", 1)

    suffix = ".step"  # Default
    default_name = f"{name}_box_{length}x{width}x{height}{suffix}"
    output_path = ctx.resolve_output_path(None, default_name)

    if ctx.dry_run:
        return CommandResult(
            ok=True,
            artifacts=[output_path],
            params=params,
            dry_run=True,
        )

    try:
        box = GridfinityBox(**params)
        box.render()
        box.save_step_file(str(output_path))

        logger.info(f"  Wrote {output_path}")

        return CommandResult(
            ok=True,
            artifacts=[output_path],
            params=params,
        )

    except Exception as e:
        logger.error(f"  Failed: {e}")
        return CommandResult(
            ok=False,
            errors=[str(e)],
            params=params,
        )


def _generate_baseplate(ctx: CLIContext, name: str, params: Dict[str, Any]) -> CommandResult:
    """Generate a baseplate."""
    from microfinity import GridfinityBaseplate

    logger = ctx.logger

    length = params.get("length", 1)
    width = params.get("width", 1)

    default_name = f"{name}_baseplate_{length}x{width}.step"
    output_path = ctx.resolve_output_path(None, default_name)

    if ctx.dry_run:
        return CommandResult(
            ok=True,
            artifacts=[output_path],
            params=params,
            dry_run=True,
        )

    try:
        bp = GridfinityBaseplate(length, width)
        bp.render()
        bp.save_step_file(str(output_path))

        logger.info(f"  Wrote {output_path}")

        return CommandResult(
            ok=True,
            artifacts=[output_path],
            params=params,
        )

    except Exception as e:
        logger.error(f"  Failed: {e}")
        return CommandResult(
            ok=False,
            errors=[str(e)],
            params=params,
        )
