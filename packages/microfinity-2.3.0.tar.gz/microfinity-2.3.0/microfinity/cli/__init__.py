"""
Unified CLI entry point for microfinity.
"""

from .app import app, cli

__all__ = ["app", "cli"]


def main() -> None:
    """Main entry point for console script."""
    cli()
