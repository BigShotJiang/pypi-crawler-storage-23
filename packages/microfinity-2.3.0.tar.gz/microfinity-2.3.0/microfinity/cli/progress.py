"""Progress bar utilities for long-running CLI operations.

Provides a unified interface for progress display that:
- Only shows progress in TTY mode (not when piped)
- Respects --json/--yaml output mode (no progress to stdout)
- Can be disabled with --no-progress
"""

from __future__ import annotations

import sys
from contextlib import contextmanager
from typing import Any, Generator, Iterable, Optional, TypeVar

T = TypeVar("T")


class NullProgress:
    """No-op progress bar for when progress is disabled."""

    def __init__(self, *args, **kwargs):
        pass

    def update(self, n: int = 1) -> None:
        pass

    def set_description(self, desc: str) -> None:
        pass

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


class ProgressManager:
    """Manages progress bar creation based on context.

    Usage:
        progress = ProgressManager(enabled=True, use_tty=True)

        for item in progress.iterate(items, desc="Processing"):
            process(item)
    """

    def __init__(
        self,
        enabled: bool = True,
        use_tty: bool = True,
        output_to_stderr: bool = True,
    ):
        """Initialize progress manager.

        Args:
            enabled: Whether progress bars are enabled
            use_tty: Only show progress if stdout is a TTY
            output_to_stderr: Write progress to stderr (keeps stdout clean)
        """
        self.enabled = enabled
        self.use_tty = use_tty
        self.output_to_stderr = output_to_stderr
        self._tqdm_available = self._check_tqdm()

    def _check_tqdm(self) -> bool:
        """Check if tqdm is available."""
        try:
            import tqdm

            return True
        except ImportError:
            return False

    def should_show_progress(self) -> bool:
        """Determine if progress should be shown."""
        if not self.enabled:
            return False

        if self.use_tty and not sys.stdout.isatty():
            return False

        return True

    def iterate(
        self, iterable: Iterable[T], desc: Optional[str] = None, total: Optional[int] = None, unit: str = "it", **kwargs
    ) -> Iterable[T]:
        """Iterate with optional progress bar.

        Args:
            iterable: Items to iterate over
            desc: Description shown on progress bar
            total: Total number of items (inferred if not provided)
            unit: Unit name for progress bar
            **kwargs: Additional arguments for tqdm

        Returns:
            Iterable (with progress bar if enabled)
        """
        if not self.should_show_progress():
            return iterable

        if not self._tqdm_available:
            # Fallback: just iterate
            return iterable

        from tqdm import tqdm

        # Set file to stderr to keep stdout clean
        file = sys.stderr if self.output_to_stderr else None

        return tqdm(iterable, desc=desc, total=total, unit=unit, file=file, **kwargs)

    @contextmanager
    def task(
        self, desc: Optional[str] = None, total: Optional[int] = None, unit: str = "it", **kwargs
    ) -> Generator[Any, None, None]:
        """Context manager for progress bar.

        Args:
            desc: Description shown on progress bar
            total: Total number of items
            unit: Unit name for progress bar
            **kwargs: Additional arguments for tqdm

        Yields:
            Progress bar object (or NullProgress if disabled)
        """
        if not self.should_show_progress() or not self._tqdm_available:
            yield NullProgress()
            return

        from tqdm import tqdm

        file = sys.stderr if self.output_to_stderr else None

        pbar = tqdm(desc=desc, total=total, unit=unit, file=file, **kwargs)
        try:
            yield pbar
        finally:
            pbar.close()

    def write(self, message: str) -> None:
        """Write a message, clearing progress bar if needed.

        Args:
            message: Message to write
        """
        if not self.should_show_progress() or not self._tqdm_available:
            print(message, file=sys.stderr if self.output_to_stderr else sys.stdout)
            return

        from tqdm import tqdm

        file = sys.stderr if self.output_to_stderr else sys.stdout
        tqdm.write(message, file=file)


def create_progress_manager(
    enabled: bool = True,
    json_mode: bool = False,
    yaml_mode: bool = False,
) -> ProgressManager:
    """Create a progress manager with sensible defaults.

    Args:
        enabled: Whether progress is enabled (can be disabled with --no-progress)
        json_mode: If True, disable progress (JSON mode needs clean stdout)
        yaml_mode: If True, disable progress (YAML mode needs clean stdout)

    Returns:
        Configured ProgressManager
    """
    # Disable progress in JSON/YAML mode to keep stdout clean
    if json_mode or yaml_mode:
        enabled = False

    return ProgressManager(
        enabled=enabled,
        use_tty=True,  # Only show in TTY
        output_to_stderr=True,  # Keep stdout clean
    )
