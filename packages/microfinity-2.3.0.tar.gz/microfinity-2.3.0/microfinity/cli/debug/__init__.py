"""
Debug subcommands for mesh analysis and visualization.

Wraps the existing debug functionality with Typer CLI.
"""

import argparse
from pathlib import Path
from typing import Annotated, Optional

import typer

# Import implementations from debug_impl.py (renamed from debug.py)
from microfinity.cli.debug_impl import cmd_analyze, cmd_compare, cmd_footprint, cmd_slice

debug_app = typer.Typer(name="debug", help="Debug and analysis tools")


@debug_app.command("analyze")
def analyze(
    input: Annotated[Path, typer.Argument(help="Input mesh file (STL, 3MF, OBJ)")],
    output: Annotated[Optional[Path], typer.Option("-o", "--output", help="Output JSON report")] = None,
) -> None:
    """Analyze mesh and report diagnostics."""
    args = argparse.Namespace(input=input, output=output)
    raise typer.Exit(cmd_analyze(args))


@debug_app.command("slice")
def slice_cmd(
    input: Annotated[Path, typer.Argument(help="Input mesh file")],
    z: Annotated[Optional[float], typer.Option("-z", help="Z height for slice")] = None,
    output: Annotated[Optional[Path], typer.Option("-o", "--output", help="Output SVG file")] = None,
) -> None:
    """Generate SVG cross-section at specified Z height."""
    args = argparse.Namespace(input=input, z=z, output=output)
    raise typer.Exit(cmd_slice(args))


@debug_app.command("compare")
def compare(
    file_a: Annotated[Path, typer.Argument(help="First mesh file")],
    file_b: Annotated[Path, typer.Argument(help="Second mesh file")],
    output: Annotated[Optional[Path], typer.Option("-o", "--output", help="Output difference mesh")] = None,
) -> None:
    """Compare two meshes and report differences."""
    args = argparse.Namespace(file_a=file_a, file_b=file_b, output=output)
    raise typer.Exit(cmd_compare(args))


@debug_app.command("footprint")
def footprint(
    input: Annotated[Path, typer.Argument(help="Input mesh file")],
    output: Annotated[Optional[Path], typer.Option("-o", "--output", help="Output SVG file")] = None,
) -> None:
    """Extract and export 2D footprint of mesh."""
    args = argparse.Namespace(input=input, output=output)
    raise typer.Exit(cmd_footprint(args))
