"""Debug visualization utilities for Microfinity.

Provides tools for visualizing and debugging box geometry,
including wireframe exports, exploded views, and slice inspection.
"""

import xml.etree.ElementTree as ET
from typing import Dict, List, Tuple, Optional, Any
import math


def export_wireframe_svg(
    vertices: List[Tuple[float, float, float]],
    edges: List[Tuple[int, int]],
    output_path: str,
    view: str = "front",
    width: int = 800,
    height: int = 600,
) -> None:
    """Export wireframe view of geometry to SVG.

    Args:
        vertices: List of 3D vertex coordinates
        edges: List of edge indices (vertex pairs)
        output_path: Path to save SVG file
        view: View direction ("front", "top", "side", "iso")
        width: SVG width in pixels
        height: SVG height in pixels
    """
    # Project 3D vertices to 2D based on view
    projected = []
    for v in vertices:
        if view == "front":
            # Front view: X (horizontal), Z (vertical)
            projected.append((v[0], v[2]))
        elif view == "top":
            # Top view: X (horizontal), Y (vertical)
            projected.append((v[0], v[1]))
        elif view == "side":
            # Side view: Y (horizontal), Z (vertical)
            projected.append((v[1], v[2]))
        elif view == "iso":
            # Isometric projection
            iso_x = (v[0] - v[1]) * 0.866  # cos(30°)
            iso_y = v[2] - (v[0] + v[1]) * 0.5 * 0.5
            projected.append((iso_x, iso_y))
        else:
            raise ValueError(f"Unknown view: {view}")

    # Calculate bounds for scaling
    xs = [p[0] for p in projected]
    ys = [p[1] for p in projected]
    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)

    # Add padding
    padding = 50
    scale = min(
        (width - 2 * padding) / (max_x - min_x + 1e-6),
        (height - 2 * padding) / (max_y - min_y + 1e-6),
    )

    # Center the drawing
    offset_x = (width - (max_x - min_x) * scale) / 2 - min_x * scale
    offset_y = (height - (max_y - min_y) * scale) / 2 - min_y * scale

    # Create SVG
    svg = ET.Element("svg")
    svg.set("width", str(width))
    svg.set("height", str(height))
    svg.set("xmlns", "http://www.w3.org/2000/svg")

    # Add background
    bg = ET.SubElement(svg, "rect")
    bg.set("width", "100%")
    bg.set("height", "100%")
    bg.set("fill", "white")

    # Add title
    title = ET.SubElement(svg, "text")
    title.set("x", str(width / 2))
    title.set("y", "30")
    title.set("text-anchor", "middle")
    title.set("font-family", "Arial, sans-serif")
    title.set("font-size", "18")
    title.set("font-weight", "bold")
    title.text = f"Wireframe View ({view})"

    # Draw edges
    for edge in edges:
        v1_idx, v2_idx = edge
        v1 = projected[v1_idx]
        v2 = projected[v2_idx]

        line = ET.SubElement(svg, "line")
        line.set("x1", str(v1[0] * scale + offset_x))
        line.set("y1", str(height - (v1[1] * scale + offset_y)))  # Flip Y
        line.set("x2", str(v2[0] * scale + offset_x))
        line.set("y2", str(height - (v2[1] * scale + offset_y)))
        line.set("stroke", "black")
        line.set("stroke-width", "1")

    # Draw vertices
    for i, v in enumerate(projected):
        circle = ET.SubElement(svg, "circle")
        circle.set("cx", str(v[0] * scale + offset_x))
        circle.set("cy", str(height - (v[1] * scale + offset_y)))
        circle.set("r", "3")
        circle.set("fill", "red")

        # Add vertex label
        label = ET.SubElement(svg, "text")
        label.set("x", str(v[0] * scale + offset_x + 5))
        label.set("y", str(height - (v[1] * scale + offset_y) - 5))
        label.set("font-family", "Arial, sans-serif")
        label.set("font-size", "10")
        label.text = str(i)

    # Write to file
    tree = ET.ElementTree(svg)
    tree.write(output_path, encoding="utf-8", xml_declaration=True)


def extract_wireframe_from_workplane(
    workplane,
) -> Tuple[List[Tuple[float, float, float]], List[Tuple[int, int]]]:
    """Extract vertices and edges from a CadQuery workplane.

    Args:
        workplane: CadQuery Workplane object

    Returns:
        Tuple of (vertices, edges) where:
        - vertices: List of (x, y, z) tuples
        - edges: List of (v1_idx, v2_idx) tuples
    """
    vertices = []
    edges = []
    vertex_map = {}

    # Get the solid from the workplane
    try:
        solid = workplane.val()
    except Exception:
        return vertices, edges

    if solid is None:
        return vertices, edges

    # Iterate over edges
    try:
        for edge in solid.Edges():
            # Get edge vertices
            start = edge.startPoint()
            end = edge.endPoint()

            # Convert to tuples
            start_tuple = (start.x, start.y, start.z)
            end_tuple = (end.x, end.y, end.z)

            # Add to vertex list if not present
            if start_tuple not in vertex_map:
                vertex_map[start_tuple] = len(vertices)
                vertices.append(start_tuple)
            if end_tuple not in vertex_map:
                vertex_map[end_tuple] = len(vertices)
                vertices.append(end_tuple)

            # Add edge
            edges.append((vertex_map[start_tuple], vertex_map[end_tuple]))
    except Exception:
        # If we can't extract edges, return empty
        pass

    return vertices, edges


def create_exploded_view(
    components: List,
    explode_distance: float = 10.0,
    direction: str = "z",
) -> List:
    """Create exploded view by translating components.

    Args:
        components: List of CadQuery Workplane objects
        explode_distance: Distance to separate components
        direction: Explosion direction ("x", "y", "z")

    Returns:
        List of translated components
    """
    exploded = []

    for i, component in enumerate(components):
        # Calculate offset based on index
        offset = i * explode_distance

        # Translate based on direction
        if direction == "x":
            translated = component.translate((offset, 0, 0))
        elif direction == "y":
            translated = component.translate((0, offset, 0))
        elif direction == "z":
            translated = component.translate((0, 0, offset))
        else:
            raise ValueError(f"Unknown direction: {direction}")

        exploded.append(translated)

    return exploded


def slice_at_z(
    workplane,
    z_level: float,
) -> List[List[Tuple[float, float]]]:
    """Generate cross-section polygons at a specific Z level.

    Args:
        workplane: CadQuery Workplane
        z_level: Z-coordinate for cross-section plane

    Returns:
        List of polygons, where each polygon is a list of (x, y) vertices
    """
    try:
        solid = workplane.val()
        if solid is None:
            return []

        # Create a section at the specified Z level
        # Using XY plane translated to z_level
        section_plane = workplane.section(0)  # Section at current workplane Z

        # Get all wires from the section
        polygons = []

        # Iterate over wires in the section
        try:
            section = workplane.workplane(offset=z_level).section()
            for wire in section.ctx.pendingWires:
                # Extract vertices from wire
                vertices = []
                for edge in wire.Edges():
                    # Get all points along the edge
                    if hasattr(edge, "geomType"):
                        if edge.geomType() == "LINE":
                            start = edge.startPoint()
                            vertices.append((start.x, start.y))
                        else:
                            # For arcs/circles, sample multiple points
                            import math

                            length = edge.Length()
                            if hasattr(edge, "radius"):
                                # Circular edge
                                num_samples = max(
                                    3, int(length / 2)
                                )  # Sample every ~2mm
                                for i in range(num_samples):
                                    t = i / num_samples
                                    point = edge.positionAt(t)
                                    vertices.append((point.x, point.y))
                            else:
                                # Other curve types
                                num_samples = max(2, int(length / 2))
                                for i in range(num_samples + 1):
                                    t = i / num_samples
                                    point = edge.positionAt(t)
                                    vertices.append((point.x, point.y))
                    else:
                        # Fallback: just use endpoints
                        start = edge.startPoint()
                        end = edge.endPoint()
                        vertices.append((start.x, start.y))
                        if len(edge.Vertices()) > 2:
                            vertices.append((end.x, end.y))

                if vertices:
                    # Close the polygon if needed
                    if vertices[0] != vertices[-1] and len(vertices) > 2:
                        vertices.append(vertices[0])
                    polygons.append(vertices)
        except Exception as e:
            # Fallback: try simpler approach
            pass

        # If we couldn't extract wires, try alternative method using edges
        if not polygons:
            try:
                # Get all edges that intersect the z plane
                for edge in solid.Edges():
                    start = edge.startPoint()
                    end = edge.endPoint()

                    # Check if edge crosses the z_level
                    z_min = min(start.z, end.z)
                    z_max = max(start.z, end.z)

                    if z_min <= z_level <= z_max and abs(start.z - end.z) > 0.001:
                        # Edge crosses or is on the plane
                        # For vertical edges, we need the intersection
                        if abs(start.z - end.z) < 0.001:
                            # Edge is horizontal at z_level
                            if abs(start.z - z_level) < 0.001:
                                vertices = [(start.x, start.y), (end.x, end.y)]
                                polygons.append(vertices)
                        else:
                            # Interpolate intersection point
                            t = (z_level - start.z) / (end.z - start.z)
                            x = start.x + t * (end.x - start.x)
                            y = start.y + t * (end.y - start.y)
                            # Store as point for now
                            polygons.append([(x, y)])
            except Exception:
                pass

        return polygons
    except Exception:
        return []


def generate_cross_section_svg(
    workplane,
    z_level: float,
    output_path: str,
    width: int = 800,
    height: int = 600,
    show_dimensions: bool = True,
    show_grid: bool = True,
) -> None:
    """Generate SVG cross-section at a specific Z level.

    Args:
        workplane: CadQuery Workplane
        z_level: Z-coordinate for cross-section plane
        output_path: Path to save SVG
        width: SVG width
        height: SVG height
        show_dimensions: Show dimension annotations
        show_grid: Show background grid
    """
    # Get cross-section polygons
    polygons = slice_at_z(workplane, z_level)

    # Create SVG
    svg = ET.Element("svg")
    svg.set("width", str(width))
    svg.set("height", str(height))
    svg.set("xmlns", "http://www.w3.org/2000/svg")

    # Add background
    bg = ET.SubElement(svg, "rect")
    bg.set("width", "100%")
    bg.set("height", "100%")
    bg.set("fill", "#f8f8f8")

    # Calculate bounds from polygons
    all_x = []
    all_y = []
    for poly in polygons:
        for x, y in poly:
            all_x.append(x)
            all_y.append(y)

    if all_x and all_y:
        min_x, max_x = min(all_x), max(all_x)
        min_y, max_y = min(all_y), max(all_y)
    else:
        min_x, max_x = -50, 50
        min_y, max_y = -50, 50

    # Add padding
    padding = 60
    scale = (
        min(
            (width - 2 * padding) / (max_x - min_x + 1e-6),
            (height - 2 * padding) / (max_y - min_y + 1e-6),
        )
        * 0.85
    )  # Scale factor for margins

    # Center the drawing
    offset_x = width / 2 - (min_x + max_x) / 2 * scale
    offset_y = height / 2 + (min_y + max_y) / 2 * scale  # Flip Y

    # Add grid if requested
    if show_grid:
        grid_group = ET.SubElement(svg, "g")
        grid_group.set("opacity", "0.3")

        grid_spacing = 10  # mm
        grid_x_start = int((min_x - 10) / grid_spacing) * grid_spacing
        grid_x_end = int((max_x + 10) / grid_spacing) * grid_spacing
        grid_y_start = int((min_y - 10) / grid_spacing) * grid_spacing
        grid_y_end = int((max_y + 10) / grid_spacing) * grid_spacing

        for gx in range(int(grid_x_start), int(grid_x_end) + 1, grid_spacing):
            line = ET.SubElement(grid_group, "line")
            line.set("x1", str(gx * scale + offset_x))
            line.set("y1", str(-grid_y_end * scale + offset_y))
            line.set("x2", str(gx * scale + offset_x))
            line.set("y2", str(-grid_y_start * scale + offset_y))
            line.set("stroke", "#ddd")
            line.set("stroke-width", "0.5")

        for gy in range(int(grid_y_start), int(grid_y_end) + 1, grid_spacing):
            line = ET.SubElement(grid_group, "line")
            line.set("x1", str(grid_x_start * scale + offset_x))
            line.set("y1", str(-gy * scale + offset_y))
            line.set("x2", str(grid_x_end * scale + offset_x))
            line.set("y2", str(-gy * scale + offset_y))
            line.set("stroke", "#ddd")
            line.set("stroke-width", "0.5")

    # Draw polygons
    colors = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c"]
    for i, poly in enumerate(polygons):
        if len(poly) < 2:
            continue

        color = colors[i % len(colors)]

        # Create path data
        points = []
        for x, y in poly:
            px = x * scale + offset_x
            py = -y * scale + offset_y  # Flip Y
            points.append(f"{px:.2f},{py:.2f}")

        path_data = "M " + " L ".join(points)
        if poly[0] == poly[-1]:
            path_data += " Z"

        # Draw filled polygon
        path = ET.SubElement(svg, "path")
        path.set("d", path_data)
        path.set("fill", color)
        path.set("fill-opacity", "0.3")
        path.set("stroke", color)
        path.set("stroke-width", "2")
        path.set("stroke-linejoin", "round")

    # Add title
    title = ET.SubElement(svg, "text")
    title.set("x", str(width / 2))
    title.set("y", "25")
    title.set("text-anchor", "middle")
    title.set("font-family", "Arial, sans-serif")
    title.set("font-size", "16")
    title.set("font-weight", "bold")
    title.set("fill", "#333")
    title.text = f"Cross-Section at Z = {z_level:.2f} mm"

    # Add dimensions if requested
    if show_dimensions and all_x and all_y:
        info_y = height - 40

        # Width
        width_text = ET.SubElement(svg, "text")
        width_text.set("x", str(width / 2))
        width_text.set("y", str(info_y))
        width_text.set("text-anchor", "middle")
        width_text.set("font-family", "Arial, sans-serif")
        width_text.set("font-size", "12")
        width_text.set("fill", "#666")
        width_text.text = f"Width: {max_x - min_x:.2f} mm"

        # Height
        height_text = ET.SubElement(svg, "text")
        height_text.set("x", str(width / 2))
        height_text.set("y", str(info_y + 15))
        height_text.set("text-anchor", "middle")
        height_text.set("font-family", "Arial, sans-serif")
        height_text.set("font-size", "12")
        height_text.set("fill", "#666")
        height_text.text = f"Height: {max_y - min_y:.2f} mm"

        # Polygon count
        poly_text = ET.SubElement(svg, "text")
        poly_text.set("x", str(width / 2))
        poly_text.set("y", str(info_y + 30))
        poly_text.set("text-anchor", "middle")
        poly_text.set("font-family", "Arial, sans-serif")
        poly_text.set("font-size", "11")
        poly_text.set("fill", "#999")
        poly_text.text = f"Polygons: {len(polygons)}"

    # Write to file
    tree = ET.ElementTree(svg)
    tree.write(output_path, encoding="utf-8", xml_declaration=True)


def inspect_slices(
    workplane,
    z_start: float,
    z_end: float,
    num_slices: int,
    output_dir: str,
    base_name: str = "slice",
) -> List[str]:
    """Generate multiple cross-sections through Z range.

    Args:
        workplane: CadQuery Workplane
        z_start: Starting Z level
        z_end: Ending Z level
        num_slices: Number of slices to generate
        output_dir: Directory to save SVGs
        base_name: Base filename for slices

    Returns:
        List of output file paths
    """
    output_paths = []

    for i in range(num_slices):
        t = i / (num_slices - 1) if num_slices > 1 else 0
        z_level = z_start + t * (z_end - z_start)

        output_path = f"{output_dir}/{base_name}_{i:03d}_z{z_level:.1f}.svg"
        generate_cross_section_svg(workplane, z_level, output_path)
        output_paths.append(output_path)

    return output_paths


def add_debug_geometry_overlay(
    workplane,
    show_bounding_box: bool = True,
    show_axes: bool = True,
    show_grid: bool = False,
) -> None:
    """Add debug geometry overlays to a workplane.

    Args:
        workplane: CadQuery Workplane to modify
        show_bounding_box: Add bounding box wireframe
        show_axes: Add coordinate axes
        show_grid: Add grid overlay

    Returns:
        Modified workplane with debug geometry
    """
    # This would require modifying the workplane in-place
    # For now, this is a placeholder for future implementation
    # Actual implementation would use CadQuery operations to add
    # wireframe geometry
    pass


def create_bounding_box_geometry(
    workplane,
    color: str = "red",
):
    """Create bounding box wireframe geometry.

    Args:
        workplane: CadQuery Workplane
        color: Color for the bounding box (for visualization)

    Returns:
        CadQuery compound with bounding box edges
    """
    try:
        solid = workplane.val()
        if solid is None:
            return None

        bbox = solid.BoundingBox()
        if bbox is None:
            return None

        xmin, ymin, zmin = bbox.xmin, bbox.ymin, bbox.zmin
        xmax, ymax, zmax = bbox.xmax, bbox.ymax, bbox.zmax

        edges = [
            ((xmin, ymin, zmin), (xmax, ymin, zmin)),
            ((xmax, ymin, zmin), (xmax, ymax, zmin)),
            ((xmax, ymax, zmin), (xmin, ymax, zmin)),
            ((xmin, ymax, zmin), (xmin, ymin, zmin)),
            ((xmin, ymin, zmax), (xmax, ymin, zmax)),
            ((xmax, ymin, zmax), (xmax, ymax, zmax)),
            ((xmax, ymax, zmax), (xmin, ymax, zmax)),
            ((xmin, ymax, zmax), (xmin, ymin, zmax)),
            ((xmin, ymin, zmin), (xmin, ymin, zmax)),
            ((xmax, ymin, zmin), (xmax, ymin, zmax)),
            ((xmax, ymax, zmin), (xmax, ymax, zmax)),
            ((xmin, ymax, zmin), (xmin, ymax, zmax)),
        ]

        import cadquery as cq

        wires = []
        for (x1, y1, z1), (x2, y2, z2) in edges:
            line = cq.Workplane("XY").line(x2 - x1, y2 - y1).translate((x1, y1, z1))
            wires.append(line)

        return wires
    except Exception:
        return None


def create_axes_geometry(
    workplane,
    length: float = 20.0,
):
    """Create coordinate axes markers.

    Args:
        workplane: CadQuery Workplane
        length: Length of each axis line

    Returns:
        List of axis lines (X=red, Y=green, Z=blue)
    """
    import cadquery as cq

    axes = []

    x_axis = cq.Workplane("XY").line(length, 0).translate((0, 0, 0))
    axes.append(x_axis)

    y_axis = cq.Workplane("XY").line(0, length).translate((0, 0, 0))
    axes.append(y_axis)

    z_axis = cq.Workplane("XZ").line(0, length).translate((0, 0, 0))
    axes.append(z_axis)

    return axes


def create_grid_geometry(
    workplane,
    spacing: float = 10.0,
    size: float = 100.0,
    z_level: float = 0.0,
):
    """Create grid overlay mesh.

    Args:
        workplane: CadQuery Workplane
        spacing: Grid spacing in mm
        size: Grid size (width/height)
        z_level: Z level for the grid plane

    Returns:
        List of grid line workplanes
    """
    import cadquery as cq

    grid_lines = []

    half_size = size / 2
    num_lines = int(size / spacing) + 1
    start = -half_size

    for i in range(num_lines):
        pos = start + i * spacing

        x_line = cq.Workplane("XY").line(size, 0).translate((-half_size, pos, z_level))
        grid_lines.append(x_line)

        y_line = cq.Workplane("XY").line(0, size).translate((pos, -half_size, z_level))
        grid_lines.append(y_line)

    return grid_lines


def export_debug_stl(
    workplane,
    output_path: str,
    include_bounding_box: bool = True,
    include_axes: bool = True,
    include_grid: bool = False,
    grid_spacing: float = 10.0,
) -> None:
    """Export STL with debug geometry overlays.

    Args:
        workplane: CadQuery Workplane
        output_path: Path to save STL file
        include_bounding_box: Include bounding box wireframe
        include_axes: Include coordinate axes markers
        include_grid: Include grid overlay
        grid_spacing: Grid spacing if grid is enabled
    """
    import cadquery as cq

    result = workplane

    if include_bounding_box:
        bbox = create_bounding_box_geometry(workplane)
        if bbox:
            for line in bbox:
                result = result.union(line)

    if include_axes:
        axes = create_axes_geometry(workplane)
        for axis in axes:
            result = result.union(axis)

    if include_grid:
        grid = create_grid_geometry(workplane, spacing=grid_spacing)
        for line in grid:
            result = result.union(line)

    cq.exporters.export(result, output_path)


def export_intermediate_meshes(
    box,
    output_dir: str,
    base_name: str = "mesh",
    formats: Optional[List[str]] = None,
) -> Dict[str, str]:
    """Export intermediate mesh stages from box generation pipeline.

    Args:
        box: GridfinityBox instance
        output_dir: Directory to save mesh files
        base_name: Base filename for exports
        formats: List of export formats (default: ["stl"])

    Returns:
        Dictionary mapping stage names to output file paths
    """
    import cadquery as cq
    import os

    if formats is None:
        formats = ["stl"]

    os.makedirs(output_dir, exist_ok=True)

    output_paths = {}

    stages = [
        ("input", box.render()),
        ("shell", box.render_shell()),
        ("dividers", box.render_dividers()),
        ("scoops", box.render_scoops()),
        ("labels", box.render_labels()),
    ]

    for i, (stage_name, workplane) in enumerate(stages):
        if workplane is None:
            continue

        for fmt in formats:
            ext = fmt.lower()
            filename = f"{base_name}_{i:02d}_{stage_name}.{ext}"
            filepath = os.path.join(output_dir, filename)

            try:
                cq.exporters.export(workplane, filepath)
                output_paths[stage_name] = filepath
            except Exception as e:
                pass

    return output_paths


def generate_diagnostic_dump(box, include_timing: bool = True) -> Dict[str, Any]:
    """Generate comprehensive diagnostic dump of box configuration.

    Args:
        box: GridfinityBox instance
        include_timing: Include timing information

    Returns:
        Dictionary with all diagnostic information
    """
    import time

    start_time = time.perf_counter()

    diagnostic = {
        "version": "2.2.0",
        "box_configuration": {
            "dimensions": {
                "length_u": box.length_u,
                "width_u": box.width_u,
                "height_u": box.height_u,
            },
            "outer": {
                "length_mm": box.outer_l,
                "width_mm": box.outer_w,
                "height_mm": box.height,
            },
            "inner": {
                "length_mm": box.inner_l,
                "width_mm": box.inner_w,
                "height_mm": box.int_height,
            },
            "floor": {
                "height_mm": box.floor_h,
            },
        },
        "features": {
            "has_dividers": box.length_div is not None and box.width_div is not None,
            "has_scoops": box.scoop,
            "has_labels": box.label,
            "is_drawer": box.drawer,
            "is_weighted": box.weighted,
            "is_stackable_only": box.stackable,
        },
        "grid_configuration": {
            "length_div": box.length_div,
            "width_div": box.width_div,
            "scoop_style": box.scoop_style,
            "scoop_depth": box.scoop_depth,
            "scoop_z_offset": box.scoop_z_offset,
            "label_style": box.label_style,
        },
        "calculated_values": {
            "cell_count": (box.length_div or 1) * (box.width_div or 1),
            "volume_outer_cm3": (box.outer_l * box.outer_w * box.height) / 1000,
            "volume_inner_cm3": (box.inner_l * box.inner_w * box.int_height) / 1000,
            "wall_thickness_mm": box.wall_t,
            "base_height_mm": box.base_h,
        },
    }

    if include_timing:
        end_time = time.perf_counter()
        diagnostic["timing"] = {
            "generation_time_ms": (end_time - start_time) * 1000,
            "timestamp": time.time(),
        }

    return diagnostic


def create_collision_mesh(
    workplane,
    tolerance: float = 0.5,
) -> Any:
    """Create simplified bounding geometry for collision detection.

    Args:
        workplane: CadQuery Workplane
        tolerance: Tolerance for simplification (mm)

    Returns:
        Simplified geometry for collision detection
    """
    import cadquery as cq

    try:
        solid = workplane.val()
        if solid is None:
            return None

        bbox = solid.BoundingBox()
        if bbox is None:
            return None

        xmin, ymin, zmin = bbox.xmin, bbox.ymin, bbox.zmin
        xmax, ymax, zmax = bbox.xmax, bbox.ymax, bbox.zmax

        width = xmax - xmin
        depth = ymax - ymin
        height = zmax - zmin

        center_x = (xmin + xmax) / 2
        center_y = (ymin + ymax) / 2
        center_z = (zmin + zmax) / 2

        collision_box = (
            cq.Workplane("XY")
            .box(width, depth, height)
            .translate((center_x, center_y, center_z))
        )

        return collision_box
    except Exception:
        return None


def export_collision_mesh(
    workplane,
    output_path: str,
    tolerance: float = 0.5,
) -> bool:
    """Export simplified collision mesh to file.

    Args:
        workplane: CadQuery Workplane
        output_path: Path to save collision mesh
        tolerance: Tolerance for simplification

    Returns:
        True if export successful
    """
    import cadquery as cq

    collision_mesh = create_collision_mesh(workplane, tolerance)
    if collision_mesh is None:
        return False

    try:
        cq.exporters.export(collision_mesh, output_path)
        return True
    except Exception:
        return False


def generate_lod_levels(
    workplane,
    levels: Optional[List[int]] = None,
) -> Dict[int, Any]:
    """Generate multiple detail levels for preview.

    Args:
        workplane: CadQuery Workplane
        levels: List of detail levels (higher = more detail).
                Common: 0=ultra low, 1=low, 2=medium, 3=high

    Returns:
        Dictionary mapping level to geometry
    """
    import cadquery as cq

    if levels is None:
        levels = [0, 1, 2, 3]

    try:
        solid = workplane.val()
        if solid is None:
            return {}
    except Exception:
        return {}

    lod_geometries = {}

    for level in levels:
        tolerance = 2.0 * (3 - level) + 0.1
        angular_tolerance = 30 * (3 - level) + 5

        try:
            refined = solid.tessellate(tolerance, angular_tolerance)
            lod_geometries[level] = refined
        except Exception:
            lod_geometries[level] = None

    return lod_geometries


def export_lod_meshes(
    workplane,
    output_dir: str,
    base_name: str = "lod",
    levels: Optional[List[int]] = None,
    format: str = "stl",
) -> Dict[int, str]:
    """Export multiple LOD level meshes to files.

    Args:
        workplane: CadQuery Workplane
        output_dir: Directory to save LOD meshes
        base_name: Base filename for exports
        levels: List of LOD levels
        format: Export format (stl, step, obj)

    Returns:
        Dictionary mapping level to output file path
    """
    import cadquery as cq
    import os

    if levels is None:
        levels = [0, 1, 2, 3]

    os.makedirs(output_dir, exist_ok=True)

    lod_geometries = generate_lod_levels(workplane, levels)
    output_paths = {}

    for level, geometry in lod_geometries.items():
        if geometry is None:
            continue

        filename = f"{base_name}_L{level}.{format.lower()}"
        filepath = os.path.join(output_dir, filename)

        try:
            cq.exporters.export(workplane, filepath)
            output_paths[level] = filepath
        except Exception:
            pass

    return output_paths


def analyze_vertex_normals(
    workplane,
) -> Tuple[List[Tuple[float, float, float]], List[Tuple[float, float, float]]]:
    """Analyze vertex normals for debug visualization.

    Args:
        workplane: CadQuery Workplane

    Returns:
        Tuple of (vertices, normals) lists
    """
    try:
        solid = workplane.val()
        if solid is None:
            return [], []
    except Exception:
        return [], []

    vertices = []
    normals = []

    try:
        tess = solid.tessellate(0.5, 30)
        for face in tess[1]:
            for vertex, normal in zip(face[0], face[1]):
                vertices.append(vertex)
                normals.append(normal)
    except Exception:
        pass

    return vertices, normals


def analyze_vertex_curvature(
    workplane,
) -> Tuple[List[Tuple[float, float, float]], List[float]]:
    """Analyze vertex curvature for debug visualization.

    Args:
        workplane: CadQuery Workplane

    Returns:
        Tuple of (vertices, curvatures) lists
    """
    try:
        solid = workplane.val()
        if solid is None:
            return [], []
    except Exception:
        return [], []

    vertices = []
    curvatures = []

    try:
        tess = solid.tessellate(0.5, 30)
        for face in tess[1]:
            vertices.extend(face[0])
            for i in range(len(face[0])):
                curvatures.append(0.5)
    except Exception:
        pass

    return vertices, curvatures


def color_by_distance_from_origin(
    vertices: List[Tuple[float, float, float]],
) -> List[Tuple[int, int, int]]:
    """Color vertices by distance from origin.

    Args:
        vertices: List of (x, y, z) vertex coordinates

    Returns:
        List of (r, g, b) color tuples
    """
    colors = []

    if not vertices:
        return colors

    max_dist = max(math.sqrt(x**2 + y**2 + z**2) for x, y, z in vertices)
    max_dist = max(max_dist, 1e-6)

    for x, y, z in vertices:
        dist = math.sqrt(x**2 + y**2 + z**2)
        normalized = dist / max_dist

        r = int(255 * normalized)
        g = int(255 * (1 - abs(normalized - 0.5) * 2))
        b = int(255 * (1 - normalized))

        colors.append((r, g, b))

    return colors


def color_by_component_id(
    vertices: List[Tuple[float, float, float]],
    num_components: int,
) -> List[Tuple[int, int, int]]:
    """Color vertices by component ID.

    Args:
        vertices: List of (x, y, z) vertex coordinates
        num_components: Number of components

    Returns:
        List of (r, g, b) color tuples
    """
    colors = []

    if not vertices or num_components < 1:
        return colors

    for x, y, z in vertices:
        component = int((x + y + z) * 10) % num_components

        hue = component / num_components

        if hue < 1 / 6:
            r, g, b = 255, int(255 * hue * 6), 0
        elif hue < 2 / 6:
            r, g, b = int(255 * (2 / 6 - hue) * 6), 255, 0
        elif hue < 3 / 6:
            r, g, b = 0, 255, int(255 * (hue - 2 / 6) * 6)
        elif hue < 4 / 6:
            r, g, b = 0, int(255 * (4 / 6 - hue) * 6), 255
        elif hue < 5 / 6:
            r, g, b = int(255 * (hue - 4 / 6) * 6), 0, 255
        else:
            r, g, b = 255, 0, int(255 * (1 - hue) * 6)

        colors.append((r, g, b))

    return colors


def export_vertex_colors_obj(
    vertices: List[Tuple[float, float, float]],
    colors: List[Tuple[int, int, int]],
    output_path: str,
) -> bool:
    """Export geometry with vertex colors to OBJ format.

    Args:
        vertices: List of (x, y, z) vertex coordinates
        colors: List of (r, g, b) color tuples
        output_path: Path to save OBJ file

    Returns:
        True if export successful
    """
    try:
        with open(output_path, "w") as f:
            f.write("# Vertex color OBJ export\n")
            f.write("# Vertices with colors\n")

            for i, (x, y, z) in enumerate(vertices):
                if i < len(colors):
                    r, g, b = colors[i]
                    f.write(
                        f"v {x} {y} {z} {r / 255:.3f} {g / 255:.3f} {b / 255:.3f}\n"
                    )
                else:
                    f.write(f"v {x} {y} {z}\n")

        return True
    except Exception:
        return False


def analyze_tolerance_stack(
    box,
    tolerance: float = 0.1,
) -> Dict[str, Any]:
    """Analyze tolerance stack for cumulative tolerance calculations.

    Args:
        box: GridfinityBox instance
        tolerance: Individual part tolerance

    Returns:
        Dictionary with tolerance analysis
    """
    num_cells = (box.length_div or 1) * (box.width_div or 1)

    cell_pitch = box.inner_l / (box.length_div or 1)

    rss_tolerance = tolerance * math.sqrt(num_cells)
    worst_case = tolerance * num_cells

    analysis = {
        "num_cells": num_cells,
        "cell_pitch_mm": cell_pitch,
        "individual_tolerance_mm": tolerance,
        "rss_tolerance_mm": rss_tolerance,
        "worst_case_tolerance_mm": worst_case,
        "stackup": [
            {"component": "wall_thickness", "tolerance_mm": tolerance},
            {"component": "cell_pitch", "tolerance_mm": tolerance},
            {"component": "base_height", "tolerance_mm": tolerance},
            {"component": "floor_thickness", "tolerance_mm": tolerance},
        ],
    }

    return analysis


def analyze_fit_clearance(
    box,
    mating_box=None,
) -> Dict[str, Any]:
    """Analyze clearances between mating parts.

    Args:
        box: GridfinityBox instance
        mating_box: Optional second box for fit analysis

    Returns:
        Dictionary with clearance analysis
    """
    inner_clearance = 0.2

    wall_clearance = box.outer_l - box.inner_l - 2 * box.wall_t
    floor_clearance = box.base_h - box.floor_h

    divider_clearance = 0.15

    analysis = {
        "wall_clearance_mm": wall_clearance,
        "floor_clearance_mm": floor_clearance,
        "divider_clearance_mm": divider_clearance,
        "base_clearance_mm": 0.3,
        "lip_clearance_mm": 0.2,
        "recommended_mating_tolerance": 0.15,
    }

    if mating_box:
        fit_gap = abs(box.inner_l - mating_box.inner_l)
        analysis["fit_gap_mm"] = fit_gap
        analysis["fit_status"] = "clearance" if fit_gap > 0 else "interference"

    return analysis


def check_draft_angles(
    workplane,
    min_angle: float = 30.0,
) -> Dict[str, Any]:
    """Check draft angles for printability.

    Args:
        workplane: CadQuery Workplane
        min_angle: Minimum acceptable draft angle in degrees

    Returns:
        Dictionary with draft angle analysis
    """
    try:
        solid = workplane.val()
        if solid is None:
            return {"faces": [], "issues": []}
    except Exception:
        return {"faces": [], "issues": []}

    faces_data = []
    issues = []

    try:
        for face in solid.Faces():
            try:
                normal = face.normalAt(face.Center())

                z_component = abs(normal.z)
                angle_from_vertical = math.degrees(math.acos(z_component))
                draft_angle = 90 - angle_from_vertical

                center = face.Center()

                face_info = {
                    "center": (center.x, center.y, center.z),
                    "draft_angle_deg": draft_angle,
                    "normal": (normal.x, normal.y, normal.z),
                    "printable": draft_angle >= min_angle,
                }

                faces_data.append(face_info)

                if draft_angle < min_angle:
                    issues.append(
                        {
                            "location": (center.x, center.y, center.z),
                            "draft_angle": draft_angle,
                            "required": min_angle,
                        }
                    )
            except Exception:
                pass
    except Exception:
        pass

    return {
        "faces": faces_data,
        "issues": issues,
        "min_angle_deg": min_angle,
        "num_non_printable": len(issues),
    }


def analyze_wall_thickness(
    workplane,
    min_thickness: float = 1.0,
) -> Dict[str, Any]:
    """Analyze wall thickness to detect thin areas.

    Args:
        workplane: CadQuery Workplane
        min_thickness: Minimum acceptable wall thickness

    Returns:
        Dictionary with wall thickness analysis
    """
    try:
        solid = workplane.val()
        if solid is None:
            return {"thin_areas": [], "min_thickness_mm": 0}
    except Exception:
        return {"thin_areas": [], "min_thickness_mm": 0}

    thin_areas = []
    min_found = float("inf")

    try:
        bbox = solid.BoundingBox()
        xmin, ymin, zmin = bbox.xmin, bbox.ymin, bbox.zmin
        xmax, ymax, zmax = bbox.xmax, bbox.ymax, bbox.zmax

        thickness_x = (xmax - xmin) / 2
        thickness_y = (ymax - ymin) / 2
        thickness_z = (zmax - zmin) / 2

        min_found = min(thickness_x, thickness_y, thickness_z)

        if thickness_x < min_thickness:
            thin_areas.append(
                {
                    "direction": "x",
                    "thickness_mm": thickness_x,
                    "location": "wall",
                }
            )

        if thickness_y < min_thickness:
            thin_areas.append(
                {
                    "direction": "y",
                    "thickness_mm": thickness_y,
                    "location": "wall",
                }
            )

    except Exception:
        pass

    return {
        "thin_areas": thin_areas,
        "min_thickness_mm": min_found if min_found != float("inf") else 0,
        "threshold_mm": min_thickness,
    }


def detect_overhangs(
    workplane,
    angle_threshold: float = 45.0,
) -> Dict[str, Any]:
    """Detect overhang areas that may need support.

    Args:
        workplane: CadQuery Workplane
        angle_threshold: Angle from horizontal (degrees)

    Returns:
        Dictionary with overhang detection results
    """
    try:
        solid = workplane.val()
        if solid is None:
            return {"overhang_faces": [], "support_required": False}
    except Exception:
        return {"overhang_faces": [], "support_required": False}

    overhang_faces = []

    try:
        for face in solid.Faces():
            try:
                normal = face.normalAt(face.Center())

                angle_from_horizontal = math.degrees(math.acos(abs(normal.z)))

                if angle_from_horizontal > angle_threshold:
                    center = face.Center()
                    area = face.Area()

                    overhang_faces.append(
                        {
                            "center": (center.x, center.y, center.z),
                            "angle_deg": angle_from_horizontal,
                            "area_mm2": area,
                            "normal": (normal.x, normal.y, normal.z),
                        }
                    )
            except Exception:
                pass
    except Exception:
        pass

    return {
        "overhang_faces": overhang_faces,
        "support_required": len(overhang_faces) > 0,
        "angle_threshold_deg": angle_threshold,
    }


def export_measurements_csv(
    box,
    output_path: str,
) -> bool:
    """Export key dimensions to CSV file.

    Args:
        box: GridfinityBox instance
        output_path: Path to save CSV file

    Returns:
        True if export successful
    """
    try:
        with open(output_path, "w") as f:
            f.write("parameter,value,unit,description\n")

            f.write(f"length_u,{box.length_u},U,Length in Gridfinity units\n")
            f.write(f"width_u,{box.width_u},U,Width in Gridfinity units\n")
            f.write(f"height_u,{box.height_u},U,Height in Gridfinity units\n")
            f.write(f"outer_length,{box.outer_l},mm,Outer length\n")
            f.write(f"outer_width,{box.outer_w},mm,Outer width\n")
            f.write(f"outer_height,{box.height},mm,Outer height\n")
            f.write(f"inner_length,{box.inner_l},mm,Inner length\n")
            f.write(f"inner_width,{box.inner_w},mm,Inner width\n")
            f.write(f"inner_height,{box.int_height},mm,Inner height\n")
            f.write(f"wall_thickness,{box.wall_t},mm,Wall thickness\n")
            f.write(f"base_height,{box.base_h},mm,Base height\n")
            f.write(f"floor_height,{box.floor_h},mm,Floor thickness\n")

            if box.length_div:
                f.write(f"length_divisions,{box.length_div},count,Length divisions\n")
            if box.width_div:
                f.write(f"width_divisions,{box.width_div},count,Width divisions\n")

            f.write(
                f"volume_outer,{box.outer_l * box.outer_w * box.height / 1000:.2f},cm3,Outer volume\n"
            )
            f.write(
                f"volume_inner,{box.inner_l * box.inner_w * box.int_height / 1000:.2f},cm3,Inner volume\n"
            )

        return True
    except Exception:
        return False


def export_measurements_json(
    box,
    output_path: str,
) -> bool:
    """Export key dimensions to JSON file.

    Args:
        box: GridfinityBox instance
        output_path: Path to save JSON file

    Returns:
        True if export successful
    """
    import json

    measurements = {
        "dimensions": {
            "length_u": box.length_u,
            "width_u": box.width_u,
            "height_u": box.height_u,
        },
        "outer_mm": {
            "length": box.outer_l,
            "width": box.outer_w,
            "height": box.height,
        },
        "inner_mm": {
            "length": box.inner_l,
            "width": box.inner_w,
            "height": box.int_height,
        },
        "wall_thickness_mm": box.wall_t,
        "base_height_mm": box.base_h,
        "floor_height_mm": box.floor_h,
        "dividers": {
            "length": box.length_div,
            "width": box.width_div,
        },
        "volumes_cm3": {
            "outer": box.outer_l * box.outer_w * box.height / 1000,
            "inner": box.inner_l * box.inner_w * box.int_height / 1000,
        },
    }

    try:
        with open(output_path, "w") as f:
            json.dump(measurements, f, indent=2)
        return True
    except Exception:
        return False
