#! /usr/bin/env python3
"""Tool-specific insert presets for Gridfinity boxes."""

from __future__ import annotations

import cadquery as cq
from cqkit.cq_helpers import composite_from_pts, rounded_rect_sketch

from microfinity.parts.base import GridfinityObject


class GridfinityToolInsert(GridfinityObject):
    """Simple insert generator with preset cut patterns."""

    def __init__(self, length_u, width_u, **kwargs):
        self.preset = "hex-bits"
        self.insert_height = 8.0
        self.clearance = 0.5
        self.floor = 1.2
        self.hex_diameter = 6.4
        self.screwdriver_slot_w = 8.0
        self.screwdriver_slot_l = 24.0
        super().__init__(length_u=length_u, width_u=width_u, height_u=1, **kwargs)
        for k, v in kwargs.items():
            if k in self.__dict__:
                self.__dict__[k] = v

    def render(self):
        body_l = max(4.0, self.inner_l - 2 * self.clearance)
        body_w = max(4.0, self.inner_w - 2 * self.clearance)
        body_rad = max(0.8, self.inner_rad - self.clearance)
        body = (
            cq.Workplane("XY")
            .placeSketch(rounded_rect_sketch(body_l, body_w, body_rad))
            .extrude(self.insert_height)
        )

        if self.preset == "hex-bits":
            cutter = self._hex_bit_cutter(body_l, body_w)
            body = body.cut(cutter)
        elif self.preset == "screwdriver":
            cutter = self._screwdriver_cutter(body_l, body_w)
            body = body.cut(cutter)

        return body.translate((-self.half_l, -self.half_w, 0))

    def _hex_bit_cutter(self, l_mm, w_mm):
        pitch = self.hex_diameter + 2.0
        nx = max(1, int((l_mm - 4) // pitch))
        ny = max(1, int((w_mm - 4) // pitch))
        start_x = -((nx - 1) * pitch) / 2
        start_y = -((ny - 1) * pitch) / 2
        pts = [
            (start_x + ix * pitch, start_y + iy * pitch)
            for ix in range(nx)
            for iy in range(ny)
        ]
        hole = (
            cq.Workplane("XY")
            .circle(self.hex_diameter / 2)
            .extrude(self.insert_height - self.floor)
            .translate((0, 0, self.floor))
        )
        return composite_from_pts(hole, pts)

    def _screwdriver_cutter(self, l_mm, w_mm):
        pitch = self.screwdriver_slot_w + 3.0
        n = max(1, int((w_mm - 6) // pitch))
        start_y = -((n - 1) * pitch) / 2
        slot_len = min(self.screwdriver_slot_l, l_mm - 4)
        slot = (
            cq.Workplane("XY")
            .rect(slot_len, self.screwdriver_slot_w)
            .extrude(self.insert_height - self.floor)
            .translate((0, 0, self.floor))
        )
        pts = [(0, start_y + i * pitch) for i in range(n)]
        return composite_from_pts(slot, pts)
