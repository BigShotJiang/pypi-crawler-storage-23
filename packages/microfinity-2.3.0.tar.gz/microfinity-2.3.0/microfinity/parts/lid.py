#! /usr/bin/env python3
"""Gridfinity matching lids."""

from __future__ import annotations

import cadquery as cq
from cqkit.cq_helpers import rounded_rect_sketch

from microfinity.spec.constants import GR_TOL, GR_WALL
from microfinity.parts.base import GridfinityObject


class GridfinityLid(GridfinityObject):
    """Parametric lid that matches box footprints."""

    def __init__(self, length_u, width_u, **kwargs):
        self.thickness = 2.0
        self.lip_depth = 3.0
        self.fit_clearance = 0.25
        self.top_overhang = 0.8
        self.wall_th = GR_WALL
        super().__init__(length_u=length_u, width_u=width_u, height_u=1, **kwargs)
        for k, v in kwargs.items():
            if k in self.__dict__:
                self.__dict__[k] = v

    def render(self):
        top_l = self.outer_l + 2 * self.top_overhang
        top_w = self.outer_w + 2 * self.top_overhang
        top_rad = self.outer_rad + self.top_overhang

        top = (
            cq.Workplane("XY")
            .placeSketch(rounded_rect_sketch(top_l, top_w, top_rad))
            .extrude(self.thickness)
        )

        plug_l = max(2.0, self.inner_l - 2 * self.fit_clearance)
        plug_w = max(2.0, self.inner_w - 2 * self.fit_clearance)
        plug_rad = max(0.2, self.inner_rad - self.fit_clearance)
        plug = (
            cq.Workplane("XY")
            .placeSketch(rounded_rect_sketch(plug_l, plug_w, plug_rad))
            .extrude(-self.lip_depth)
        )

        lid = top.union(plug)
        lid = lid.translate((-self.half_l, -self.half_w, 0))
        return lid
