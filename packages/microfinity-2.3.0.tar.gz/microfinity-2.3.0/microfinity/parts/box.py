#! /usr/bin/env python3
#
# Copyright (C) 2023  Michael Gale
# This file is part of the cq-gridfinity python module.
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
# IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
# CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
# TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
#
# Gridfinity Boxes

import math

import cadquery as cq
from cqkit import HasZCoordinateSelector, VerticalEdgeSelector, FlatEdgeSelector
from cqkit.cq_helpers import rounded_rect_sketch, composite_from_pts
from microfinity.spec.constants import (
    EPS,
    GRHU,
    GRU,
    GR_BASE_CLR,
    GR_BASE_HEIGHT,
    GR_BOLT_D,
    GR_BOLT_H,
    GR_BOT_H,
    GR_BOX_PROFILE,
    GR_DIV_WALL,
    GR_FILLET,
    GR_FLOOR,
    GR_HOLE_D,
    GR_HOLE_H,
    GR_HOLE_SLICE,
    GR_LIP_PROFILE,
    GR_NO_PROFILE,
    GR_TOL,
    GR_TOPSIDE_H,
    GR_UNDER_H,
    GR_WALL,
    SQRT2,
)
from microfinity.parts.base import GridfinityObject


class GridfinityBox(GridfinityObject):
    """Gridfinity Box

    This class represents a Gridfinity compatible box module. As a minimum,
    this class is initialized with basic 3D unit dimensions for length,
    width, and height.  length and width are multiples of 42 mm Gridfinity
    intervals and height represents multiples of 7 mm.

    Many box features can be enabled with attributes provided either as
    keywords or direct dotted access.  These attributes include:
    - solid :   renders the box without an interior, i.e. a solid block. This
                is useful for making custom Gridfinity modules by subtracting
                out shapes from the solid interior. Normally, the box is
                rendered solid up to its maximum size; however, the
                solid_ratio attribute can specify a solid fill of between
                0.0 to 1.0, i.e. 0 to 100% fill.
    - holes : adds bottom mounting holes for magnets or screws
    - scoops : adds a radiused bottom edge to the interior to help fetch
               parts from the box
    - labels : adds a flat flange along each compartment for adding a label
    - no_lip : removes the contoured lip on the top module used for stacking
    - length_div, width_div : subdivides the box into sub-compartments in
                 length and/or width.
    - lite_style : render box as an economical shell without elevated floor
    - unsupported_holes : render bottom holes as 3D printer friendly versions
                          which can be printed without supports
    - label_width : width of top label ledge face overhang
    - label_height : height of label ledge overhang
    - label_style : label holder style ("flat", "angled", "recessed")
    - scoop_rad : radius of the bottom scoop feature
    - scoop_depth : explicit scoop depth in mm (overrides radius calculation)
    - scoop_z_offset : vertical position offset for scoop (default: 0)
    - scoop_style : scoop profile style ("arc", "ellipse", "slot")
    - wall_th : wall thickness
    - hole_diam : magnet/counterbore bolt hole diameter

    Micro-grid support (quarter-pitch positioning):
    - micro_divisions : int (1, 2, or 4) - enables sub-grid positioning
        - 1 = standard Gridfinity (default, no micro-boundaries)
        - 2 = half-grid (21mm pitch)
        - 4 = quarter-grid (10.5mm pitch)
      When micro_divisions > 1:
        - length_u and width_u can be fractional (e.g., 1.25, 0.5)
        - Underside grooves are cut at micro-pitch intervals
        - Bins can be shifted by 1/micro_divisions units on a standard baseplate
        - Outer envelope: (length_u * 42 - 0.5) x (width_u * 42 - 0.5) mm
        - Phase-locked to 42mm macro grid for consistent mating

    """

    def __init__(self, length_u, width_u, height_u, **kwargs):
        # Set default values for box-specific attributes BEFORE calling super().__init__
        self.length_div = 0
        self.width_div = 0
        self.scoops = False
        self.labels = False
        self.solid = False
        self.holes = False
        self.no_lip = False
        self.solid_ratio = 1.0
        self.lite_style = False
        self.unsupported_holes = False
        self.label_width = 12  # width of the label strip
        self.label_height = 10  # thickness of label overhang
        self.label_lip_height = 0.8  # thickness of label vertical lip
        self.label_style = "flat"  # "flat", "angled", "recessed"
        self.scoop_rad = 14  # radius of optional interior scoops
        self.scoop_depth = None  # scoop cut depth (None = auto from radius)
        self.scoop_z_offset = 0  # vertical position offset from default
        self.scoop_style = "arc"  # "arc", "ellipse", "slot"
        self.fillet_interior = True
        self.wall_th = GR_WALL
        self.hole_diam = GR_HOLE_D  # magnet/bolt hole diameter
        # Weighted base options
        self.weighted_base = False  # Thicker floor for stability
        self.base_extra_mm = (
            0  # Extra floor thickness in mm (0 = use default calculation)
        )
        # Stackable-only option (no baseplate feet, flat bottom)
        self.stackable_only = False  # No feet - for stacking without baseplate
        # Hollow/vase-mode option (no floor, just walls for vase printing)
        self.hollow = False  # Hollow box without floor - for vase-mode 3D printing
        # Nesting box option (smaller box that fits inside larger one)
        self.nesting = False  # Nesting box with clearance for inside larger box
        self.nesting_clearance = 0.5  # Clearance in mm for nesting
        # Grid divisions (creates equal-sized compartments in a grid pattern)
        self.grid_divisions = 0  # 0 = off, 2 = 2x2 grid, 3 = 3x3 grid, etc.
        # Interlocking divider option (tab/slot style at wall intersections)
        self.interlocking_dividers = False
        self.interlock_slot_height = 2.0
        self.interlock_slot_width = 1.2
        # Drawer/finger pull options
        self.drawer_style = False  # Enables finger pull cutout on front wall
        self.finger_pull_style = "arc"  # "arc", "slot", "none"
        self.finger_pull_depth = 8  # Depth of finger pull cut (mm into wall, sketch X)
        self.finger_pull_height = (
            12  # Height of finger pull cut (mm vertical, sketch Y)
        )
        self.finger_pull_width = 25  # Width of finger pull cut (mm along box length)
        self.finger_pull_z_offset = 0  # Vertical offset from default position
        # Drawer slide integration
        self.drawer_slides = False  # Add side rail/channel integration features
        self.slide_style = "channel"  # "channel" (cut) or "rail" (add)
        self.slide_width = 2.6  # Slide feature width in mm (Y direction)
        self.slide_height = 2.0  # Slide feature height in mm (Z direction)
        self.slide_z_offset = 6.0  # Slide offset from floor in mm
        # Custom text embossing
        self.text = None  # Text string to emboss on box (None = no text)
        self.text_depth = 0.5  # Emboss depth in mm
        self.text_height = 8  # Text height in mm
        self.text_location = "front"  # Location: "front", "top", "lid"
        self.text_justification = "center"  # "left", "center", "right"
        # QR code embossing
        self.qr_code = None  # QR code data string to emboss
        self.qr_size = 10  # QR code size in mm
        self.qr_depth = 0.3  # QR code emboss depth in mm
        self.qr_location = "front"  # Location: "front", "top", "lid"
        self._int_shell = None
        self._ext_shell = None

        # Call parent init with dimensions and kwargs for validation
        # The parent will handle micro_divisions validation
        super().__init__(
            length_u=length_u, width_u=width_u, height_u=height_u, **kwargs
        )

        # Apply any remaining kwargs that are box-specific
        for k, v in kwargs.items():
            if k in self.__dict__:
                self.__dict__[k] = v

    def __str__(self):
        s = []
        s.append(
            "Gridfinity Box %dU x %dU x %dU (%.2f x %.2f x %.2f mm)"
            % (
                self.length_u,
                self.width_u,
                self.height_u,
                self.length - GR_TOL,
                self.width - GR_TOL,
                self.height,
            )
        )
        sl = "no mating top lip" if self.no_lip else "with mating top lip"
        ss = "Lite style box  " if self.lite_style else ""
        s.append("  %sWall thickness: %.2f mm  %s" % (ss, self.wall_th, sl))
        s.append(
            "  Floor height  : %.2f mm  Inside height: %.2f mm  Top reference height: %.2f mm"
            % (self.floor_h + GR_BASE_HEIGHT, self.int_height, self.top_ref_height)
        )
        if self.solid:
            s.append("  Solid filled box with fill ratio %.2f" % (self.solid_ratio))
        if self.holes:
            s.append("  Bottom mounting holes with %.2f mm diameter" % (self.hole_diam))
            if self.unsupported_holes:
                s.append("  Holes are 3D printer friendly and can be unsupported")
        if self.scoops:
            scoop_info = "  %s scoops" % self.scoop_style.capitalize()
            if self.scoop_depth:
                scoop_info += " with %.2f mm depth" % self.scoop_depth
            else:
                scoop_info += " with %.2f mm radius" % self.scoop_rad
            if self.scoop_z_offset != 0:
                scoop_info += " (offset %.2f mm)" % self.scoop_z_offset
            s.append(scoop_info)
        if self.labels:
            s.append(
                "  %s label shelf %.2f mm wide with %.2f mm overhang"
                % (self.label_style.capitalize(), self.label_width, self.label_height)
            )
        if self.length_div:
            xl = (self.inner_l - GR_DIV_WALL * (self.length_div)) / (
                self.length_div + 1
            )
            s.append(
                "  %dx lengthwise divisions for %.2f mm compartment lengths"
                % (self.length_div, xl)
            )
        if self.width_div:
            yl = (self.inner_w - GR_DIV_WALL * (self.width_div)) / (self.width_div + 1)
            s.append(
                "  %dx widthwise divisions for %.2f mm compartment widths"
                % (self.width_div, yl)
            )
        if self.drawer_style:
            s.append(
                "  Drawer style with %s finger pull (%.1f x %.1f x %.1f mm)"
                % (
                    self.finger_pull_style,
                    self.finger_pull_width,
                    self.finger_pull_height,
                    self.finger_pull_depth,
                )
            )
        if self.weighted_base:
            extra = self.base_extra_mm if self.base_extra_mm > 0 else "default"
            s.append("  Weighted base (+ %s mm floor thickness)" % extra)
        if self.stackable_only:
            s.append("  Stackable only (no baseplate feet)")
        if self.grid_divisions > 0:
            cell_size = min(self.inner_l, self.inner_w) / self.grid_divisions
            s.append(
                "  %dx%d grid divisions (%.2f x %.2f mm cells)"
                % (
                    self.grid_divisions,
                    self.grid_divisions,
                    cell_size,
                    cell_size,
                )
            )
            if self.interlocking_dividers:
                s.append("  Interlocking divider slots enabled")
        if self.drawer_slides:
            s.append(
                "  Drawer slides: %s (w=%.2f, h=%.2f, z=%.2f mm)"
                % (
                    self.slide_style,
                    self.slide_width,
                    self.slide_height,
                    self.slide_z_offset,
                )
            )
        s.append("  Auto filename: %s" % (self.filename()))
        return "\n".join(s)

    def render(self):
        """Returns a CadQuery Workplane object representing this Gridfinity box."""
        self._int_shell = None

        # Validate lite_style + micro_divisions incompatibility
        if self.lite_style and self.micro_divisions > 1:
            raise ValueError(
                "lite_style is not supported with micro_divisions > 1. "
                "Use standard box style for micro-grid bins."
            )

        if self.lite_style:
            # just force the dividers to the desired quantity in both dimensions
            # rather than raise a exception
            if self.length_div:
                self.length_div = self.length_u - 1
            if self.width_div:
                self.width_div = self.width_u - 1
            if self.solid:
                raise ValueError(
                    "Cannot select both solid and lite box styles together"
                )
            if self.holes:
                raise ValueError(
                    "Cannot select both holes and lite box styles together"
                )
            if self.wall_th > 1.5:
                raise ValueError(
                    "Wall thickness cannot exceed 1.5 mm for lite box style"
                )
        if self.wall_th > 2.5:
            raise ValueError("Wall thickness cannot exceed 2.5 mm")
        if self.wall_th < 0.5:
            raise ValueError("Wall thickness must be at least 0.5 mm")

        # Drawer style implies no_lip (no stacking lip for drawer boxes)
        if self.drawer_style:
            self.no_lip = True
            # Validate finger pull parameters - constrained by interior space
            max_depth = min(self.inner_w * 0.5, 20)  # 50% of interior width or 20mm max
            if self.finger_pull_depth > max_depth:
                raise ValueError(
                    f"finger_pull_depth ({self.finger_pull_depth}) cannot exceed {max_depth:.1f} mm "
                    f"(limited by interior space)"
                )
            if self.finger_pull_depth <= 0:
                raise ValueError("finger_pull_depth must be > 0")
            if self.finger_pull_height <= 0:
                raise ValueError("finger_pull_height must be > 0")

        r = self.render_shell()
        rd = self.render_dividers()
        rs = self.render_scoops()
        rl = self.render_labels()
        rt = self.render_text()
        rq = self.render_qr_code()
        # Union non-cutter features
        for e in (rd, rl, rs, rt, rq):
            if e is not None:
                r = r.union(e)
        # Drawer slide integration (rail add or channel cut)
        if self.drawer_slides:
            slide_geom = self.render_drawer_slide_features(r)
            if slide_geom is not None:
                if self.slide_style == "rail":
                    r = r.union(slide_geom)
                else:
                    r = r.cut(slide_geom)
        # Cut finger pull from shell (if drawer style)
        if self.drawer_style and self.finger_pull_style != "none":
            rf_cutter = self.render_finger_pull_cutter(r)
            if rf_cutter is not None:
                r = r.cut(rf_cutter)
        if not self.solid and self.fillet_interior:
            heights = [GR_FLOOR]
            if self.labels:
                heights.append(self.safe_label_height(backwall=True, from_bottom=True))
                heights.append(self.safe_label_height(backwall=False, from_bottom=True))
            bs = (
                HasZCoordinateSelector(heights, min_points=1, tolerance=0.5)
                + VerticalEdgeSelector(">5")
                - HasZCoordinateSelector("<%.2f" % (self.floor_h))
            )
            if self.lite_style and self.scoops:
                bs = bs - HasZCoordinateSelector("<=%.2f" % (self.floor_h))
                bs = bs - VerticalEdgeSelector()
            r = self.safe_fillet(r, bs, self.safe_fillet_rad)

            if self.lite_style and not self.has_dividers:
                bs = FlatEdgeSelector(self.floor_h)
                if self.wall_th < 1.2:
                    r = self.safe_fillet(r, bs, 0.5)
                elif self.wall_th < 1.25:
                    r = self.safe_fillet(r, bs, 0.25)

            if not self.labels and self.has_dividers:
                bs = VerticalEdgeSelector(
                    GR_TOPSIDE_H, tolerance=0.05
                ) & HasZCoordinateSelector(GRHU * self.height_u - GR_BASE_HEIGHT)
                r = self.safe_fillet(r, bs, GR_TOPSIDE_H - EPS)

        if self.holes:
            r = self.render_holes(r)
        r = r.translate((-self.half_l, -self.half_w, GR_BASE_HEIGHT))
        if self.unsupported_holes:
            r = self.render_hole_fillers(r)
        return r

    @property
    def top_ref_height(self):
        """The height of the top surface of a solid box or the floor
        height of an empty box."""
        if self.solid:
            return self.max_height * self.solid_ratio + GR_BOT_H
        if self.lite_style:
            return self.floor_h
        return GR_BOT_H

    @property
    def bin_height(self):
        return self.height - GR_BASE_HEIGHT

    @property
    def floor_h(self):
        """Override floor height for weighted base option."""
        base_floor = super().floor_h
        if self.weighted_base:
            if self.base_extra_mm > 0:
                return base_floor + self.base_extra_mm
            else:
                # Default: add 2mm extra floor thickness
                return base_floor + 2.0
        return base_floor

    @property
    def inner_l(self):
        """Override inner length for nesting option."""
        base_inner = super().inner_l
        if self.nesting:
            return base_inner - 2 * self.nesting_clearance
        return base_inner

    @property
    def inner_w(self):
        """Override inner width for nesting option."""
        base_inner = super().inner_w
        if self.nesting:
            return base_inner - 2 * self.nesting_clearance
        return base_inner

    def safe_label_height(self, backwall=False, from_bottom=False):
        lw = self.label_width
        if backwall:
            lw += self.lip_width
        lh = self.label_height * (lw / self.label_width)
        yl = self.max_height - self.label_height + self.wall_th
        if backwall:
            yl -= self.lip_width
        if yl < 0:
            lh = self.max_height - 1.5 * GR_FILLET - 0.1
        elif yl < 1.5 * GR_FILLET:
            lh -= 1.5 * GR_FILLET - yl + 0.1
        if from_bottom:
            ws = math.sin(math.atan2(self.label_height, self.label_width))
            if backwall:
                lh = self.max_height + GR_FLOOR - lh + ws * self.wall_th
            else:
                lh = self.max_height + GR_FLOOR - lh + ws * GR_DIV_WALL
        return lh

    @property
    def has_dividers(self):
        return self.length_div > 0 or self.width_div > 0

    @property
    def interior_solid(self):
        if self._int_shell is not None:
            return self._int_shell
        self._int_shell = self.render_interior()
        return self._int_shell

    def render_interior(self, force_solid=False):
        """Renders the interior cutting solid of the box."""
        wall_u = self.wall_th - GR_WALL
        wall_h = self.int_height + wall_u
        under_h = ((GR_UNDER_H - wall_u) * SQRT2, 45)
        profile = GR_NO_PROFILE if self.no_lip else [under_h, *GR_LIP_PROFILE[1:]]
        profile = [wall_h, *profile]
        if self.int_height < 0:
            profile = [self.height - GR_BOT_H]
        rci = self.extrude_profile(
            rounded_rect_sketch(*self.inner_dim, self.inner_rad), profile
        )
        rci = rci.translate((*self.half_dim, self.floor_h))
        if self.solid or force_solid:
            hs = self.max_height * self.solid_ratio
            ri = rounded_rect_sketch(*self.inner_dim, self.inner_rad)
            rf = cq.Workplane("XY").placeSketch(ri).extrude(hs)
            rf = rf.translate((*self.half_dim, self.floor_h))
            rci = rci.cut(rf)
        if self.scoops and not self.no_lip and not self.lite_style:
            rf = (
                cq.Workplane("XY")
                .rect(self.inner_l, 2 * self.under_h)
                .extrude(self.max_height)
                .translate((self.half_l, -self.half_in, self.floor_h))
            )
            rci = rci.cut(rf)
        if self.lite_style:
            r = composite_from_pts(self.base_interior(), self.grid_centres)
            rci = rci.union(r)
        return rci

    def solid_shell(self):
        """Returns a completely solid box object useful for intersecting with other solids."""
        if self._ext_shell is not None:
            return self._ext_shell
        r = self.render_shell(as_solid=True)
        self._ext_shell = r.cut(self.render_interior(force_solid=True))
        return self._ext_shell

    def mask_with_obj(self, obj):
        """Intersects a solid object with this box."""
        return obj.intersect(self.solid_shell())

    def base_interior(self):
        profile = [GR_BASE_HEIGHT, *GR_BOX_PROFILE]
        zo = GR_BASE_HEIGHT + GR_BASE_CLR
        if self.int_height < 0:
            h = self.bin_height - GR_BASE_HEIGHT
            profile = [h, *profile]
            zo += h
        r = self.extrude_profile(
            rounded_rect_sketch(GRU - GR_TOL, GRU - GR_TOL, self.outer_rad),
            profile,
        )
        rx = r.faces("<Z").shell(-self.wall_th)
        r = r.cut(rx).mirror(mirrorPlane="XY").translate((0, 0, zo))
        return r

    def micro_foot(self):
        """Creates a single micro-sized foot using GR_BOX_PROFILE.

        The foot size is (micro_pitch - GR_TOL) to create proper gaps between
        adjacent feet, forming the correct divider ridge profile.
        This is the same mechanism used at macro scale.
        """
        foot_size = self.micro_pitch - GR_TOL  # 10.0mm for micro_divisions=4

        # Clamp corner radius to feasible range
        # Must be <= half foot size to avoid self-intersection
        rad = min(self.outer_rad + GR_BASE_CLR, foot_size / 2 - 0.05)
        rad = max(rad, 0.2)  # Minimum radius to avoid degenerate geometry

        r = self.extrude_profile(
            rounded_rect_sketch(foot_size, foot_size, rad), GR_BOX_PROFILE
        )
        r = r.translate((0, 0, -GR_BASE_CLR))
        r = r.mirror(mirrorPlane="XY")
        return r

    def render_shell(self, as_solid=False):
        """Renders the box shell without any added features.

        For micro_divisions > 1, uses micro-foot replication at micro_pitch
        intervals instead of macro feet. The gaps between micro feet naturally
        create the correct divider ridge profile (same mechanism as macro mode).

        When hollow=True, creates a box without floor/feet for vase-mode printing.
        """
        # Handle hollow/vase-mode - just walls, no floor or feet
        if self.hollow:
            # Create just the walls and lip for vase-mode printing
            rs = rounded_rect_sketch(*self.outer_dim, self.outer_rad)
            rw = (
                cq.Workplane("XY")
                .placeSketch(rs)
                .extrude(self.height)
                .translate((*self.half_dim, 0))
            )
            # Cut out interior to make it hollow
            inner_rs = rounded_rect_sketch(
                self.outer_l - 2 * self.wall_th,
                self.outer_w - 2 * self.wall_th,
                self.outer_rad,
            )
            inner = (
                cq.Workplane("XY")
                .placeSketch(inner_rs)
                .extrude(self.height)
                .translate((*self.half_dim, 0))
            )
            rw = rw.cut(inner)

            if not as_solid:
                return rw.cut(self.interior_solid)
            return rw

        # Choose foot solid and grid centres based on mode
        if self.stackable_only:
            # Flat bottom - no feet, just solid base
            r = (
                cq.Workplane("XY")
                .rect(self.outer_l, self.outer_w)
                .extrude(GR_BASE_HEIGHT)
                .translate((*self.half_dim, 0))
            )
        elif self.micro_divisions > 1:
            # Micro mode: use smaller feet at micro pitch
            foot = self.micro_foot()
            centres = self.micro_grid_centres
            r = composite_from_pts(foot, centres)
        else:
            # Macro mode: standard 42mm feet
            foot = self.extrude_profile(
                rounded_rect_sketch(GRU, GRU, self.outer_rad + GR_BASE_CLR),
                GR_BOX_PROFILE,
            )
            foot = foot.translate((0, 0, -GR_BASE_CLR))
            foot = foot.mirror(mirrorPlane="XY")
            centres = self.grid_centres
            r = composite_from_pts(foot, centres)

        # Build outer envelope using fractional dimensions (unchanged)
        rs = rounded_rect_sketch(*self.outer_dim, self.outer_rad)
        rw = (
            cq.Workplane("XY")
            .placeSketch(rs)
            .extrude(self.bin_height - GR_BASE_CLR)
            .translate((*self.half_dim, GR_BASE_CLR))
        )
        rc = (
            cq.Workplane("XY")
            .placeSketch(rs)
            .extrude(-GR_BASE_HEIGHT - 1)
            .translate((*self.half_dim, 0.5))
        )

        # Intersect feet with envelope, union with walls
        rc = rc.intersect(r).union(rw)

        if not as_solid:
            return rc.cut(self.interior_solid)
        return rc

    def render_dividers(self):
        r = None
        # Grid divisions take priority if set
        if self.grid_divisions > 0 and not self.solid:
            # Create a grid with equal divisions in both directions
            # Use the smaller dimension to determine cell size for square compartments
            cell_size = min(self.inner_l, self.inner_w) / self.grid_divisions

            # Create X dividers (walls along Y axis, running along X)
            num_x_walls = self.grid_divisions - 1
            if num_x_walls > 0:
                wall_w = (
                    cq.Workplane("XY")
                    .rect(GR_DIV_WALL, self.inner_w)
                    .extrude(self.max_height)
                    .translate((0, 0, self.floor_h))
                )
                # Position walls to create equal compartments
                start_x = -self.half_in + cell_size
                pts = [(start_x + i * cell_size, 0) for i in range(num_x_walls)]
                r = composite_from_pts(wall_w, pts)

            # Create Y dividers (walls along X axis, running along Y)
            num_y_walls = self.grid_divisions - 1
            if num_y_walls > 0:
                wall_l = (
                    cq.Workplane("XY")
                    .rect(self.inner_l, GR_DIV_WALL)
                    .extrude(self.max_height)
                    .translate((0, 0, self.floor_h))
                )
                # Position walls to create equal compartments
                start_y = -self.half_in + cell_size
                pts = [(0, start_y + i * cell_size) for i in range(num_y_walls)]
                ry = composite_from_pts(wall_l, pts)
                if r is not None:
                    r = r.union(ry)
                else:
                    r = ry
            if (
                self.interlocking_dividers
                and num_x_walls > 0
                and num_y_walls > 0
                and r is not None
            ):
                x_positions = [start_x + i * cell_size for i in range(num_x_walls)]
                y_positions = [start_y + i * cell_size for i in range(num_y_walls)]
                r = self._apply_interlock_slots(r, x_positions, y_positions)
            return r

        # Original length_div/width_div logic
        if self.length_div > 0 and not self.solid:
            wall_w = (
                cq.Workplane("XY")
                .rect(GR_DIV_WALL, self.outer_w)
                .extrude(self.max_height)
                .translate((0, 0, self.floor_h))
            )
            xl = self.inner_l / (self.length_div + 1)
            pts = [
                ((x + 1) * xl - self.half_in, self.half_w)
                for x in range(self.length_div)
            ]
            r = composite_from_pts(wall_w, pts)

        if self.width_div > 0 and not self.solid:
            wall_l = (
                cq.Workplane("XY")
                .rect(self.outer_l, GR_DIV_WALL)
                .extrude(self.max_height)
                .translate((0, 0, self.floor_h))
            )
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (self.half_l, (y + 1) * yl - self.half_in)
                for y in range(self.width_div)
            ]
            rw = composite_from_pts(wall_l, pts)
            if r is not None:
                r = r.union(rw)
            else:
                r = rw
        if (
            self.interlocking_dividers
            and self.length_div > 0
            and self.width_div > 0
            and r is not None
        ):
            xl = self.inner_l / (self.length_div + 1)
            yl = self.inner_w / (self.width_div + 1)
            x_positions = [(x + 1) * xl - self.half_in for x in range(self.length_div)]
            y_positions = [(y + 1) * yl - self.half_in for y in range(self.width_div)]
            r = self._apply_interlock_slots(r, x_positions, y_positions)
        return r

    def render_scoops(self):
        if not self.scoops or self.solid:
            return None

        if self.scoop_style == "arc":
            return self._render_arc_scoops()
        elif self.scoop_style == "ellipse":
            return self._render_ellipse_scoops()
        elif self.scoop_style == "slot":
            return self._render_slot_scoops()
        else:
            raise ValueError(f"Unknown scoop_style: {self.scoop_style}")

    def _get_scoop_geometry(self):
        """Calculate common scoop geometry parameters."""
        # prevent the scoop radius exceeding the internal height
        srad = min(self.scoop_rad, self.int_height - 0.1)

        # calculate depth from radius or use explicit depth
        if self.scoop_depth:
            depth = min(self.scoop_depth, self.int_height * 0.8)
        else:
            depth = srad

        # validate depth doesn't exceed wall constraints
        max_depth = self.int_height - GR_FLOOR - 1.0
        depth = min(depth, max_depth)

        if depth <= 0:
            raise ValueError(
                f"Invalid scoop_depth: {self.scoop_depth}. Must be > 0 and < {max_depth}"
            )

        # calculate base z position
        base_z = srad / 2 + GR_FLOOR + self.scoop_z_offset

        # ensure scoop stays within box (use srad for vertical extent)
        max_z_offset = self.int_height - srad - GR_FLOOR - 1.0
        if self.scoop_z_offset > max_z_offset:
            base_z = srad / 2 + GR_FLOOR + max_z_offset

        # y offset for front wall
        yo = -self.half_in + depth / 2
        if not self.no_lip and not self.lite_style:
            yo += self.under_h

        # z offset for lite_style
        zo = -GR_BOT_H + self.wall_th if self.lite_style else 0

        return srad, depth, base_z, yo, zo

    def _render_arc_scoops(self):
        """Render traditional arc/circular scoops (default)."""
        srad, depth, base_z, yo, zo = self._get_scoop_geometry()

        # front wall scoop - circular arc
        # rect(X=depth into wall, Y=srad vertical height)
        rs = cq.Sketch().rect(depth, srad).vertices(">X and >Y").circle(srad, mode="s")
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        rsc = rsc.translate((0, 0, base_z))
        rs = rsc.translate((-self.half_in, yo, zo))
        r = rs.intersect(self.interior_solid)

        if self.width_div > 0:
            # add scoops along each internal dividing wall
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in)
                for y in range(self.width_div)
            ]
            rs = composite_from_pts(rsc, pts)
            r = r.union(rs.translate((0, GR_DIV_WALL / 2 + depth / 2, zo)))
            r = r.intersect(self.render_shell(as_solid=True))
        return r

    def _render_ellipse_scoops(self):
        """Render elliptical scoops for gentler curve."""
        srad, depth, base_z, yo, zo = self._get_scoop_geometry()

        # Create elliptical scoop (wider, shallower)
        # ellipse_rx = depth (into wall), ellipse_ry = srad (vertical)
        ellipse_rx = depth
        ellipse_ry = srad

        # front wall scoop - elliptical arc using ellipse
        rs = (
            cq.Sketch()
            .rect(ellipse_rx, ellipse_ry)
            .vertices(">X and >Y")
            .ellipse(ellipse_rx, ellipse_ry, mode="s")
        )
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        rsc = rsc.translate((0, 0, base_z))
        rs = rsc.translate((-self.half_in, yo, zo))
        r = rs.intersect(self.interior_solid)

        if self.width_div > 0:
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in)
                for y in range(self.width_div)
            ]
            rs = composite_from_pts(rsc, pts)
            r = r.union(rs.translate((0, GR_DIV_WALL / 2 + depth / 2, zo)))
            r = r.intersect(self.render_shell(as_solid=True))
        return r

    def _render_slot_scoops(self):
        """Render straight slot scoops."""
        srad, depth, base_z, yo, zo = self._get_scoop_geometry()

        # front wall scoop - rectangular slot with rounded bottom
        # slot_width = depth (into wall), slot_height = srad (vertical)
        slot_width = depth
        slot_height = srad

        rs = (
            cq.Sketch()
            .segment((0, 0), (slot_width, 0))
            .segment((slot_width, -slot_height))
            .arc((slot_width / 2, -slot_height), slot_width / 2, 0, 180)
            .close()
            .assemble()
        )
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        rsc = rsc.translate((0, 0, base_z))
        rs = rsc.translate((-self.half_in, yo, zo))
        r = rs.intersect(self.interior_solid)

        if self.width_div > 0:
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in)
                for y in range(self.width_div)
            ]
            rs = composite_from_pts(rsc, pts)
            r = r.union(rs.translate((0, GR_DIV_WALL / 2 + depth / 2, zo)))
            r = r.intersect(self.render_shell(as_solid=True))
        return r

    def render_labels(self):
        if not self.labels or self.solid:
            return None

        if self.label_style == "flat":
            return self._render_flat_labels()
        elif self.label_style == "angled":
            return self._render_angled_labels()
        elif self.label_style == "recessed":
            return self._render_recessed_labels()
        else:
            raise ValueError(f"Unknown label_style: {self.label_style}")

    def _render_flat_labels(self):
        """Render traditional flat label flange (default)."""
        # back wall label flange with compensated width and height
        lw = self.label_width + self.lip_width
        rs = (
            cq.Sketch()
            .segment((0, 0), (lw, 0))
            .segment((lw, -self.safe_label_height(backwall=True)))
            .segment((0, -self.label_lip_height))
            .close()
            .assemble()
            .vertices("<X")
            .vertices("<Y")
            .fillet(self.label_lip_height / 2)
        )
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        yo = -lw + self.outer_w / 2 + self.half_w + self.wall_th / 4
        rs = rsc.translate((-self.half_in, yo, self.floor_h + self.max_height))
        # intersect to prevent solids sticking out of rounded corners
        r = rs.intersect(self.interior_solid)
        if self.width_div > 0:
            # add label flanges along each dividing wall
            rs = (
                cq.Sketch()
                .segment((0, 0), (self.label_width, 0))
                .segment((self.label_width, -self.safe_label_height(backwall=False)))
                .segment((0, -self.label_lip_height))
                .close()
                .assemble()
                .vertices("<X")
                .vertices("<Y")
                .fillet(self.label_lip_height / 2)
            )
            rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
            rsc = rsc.translate((0, -self.label_width, self.floor_h + self.max_height))
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in + GR_DIV_WALL / 2)
                for y in range(self.width_div)
            ]
            r = r.union(composite_from_pts(rsc, pts))
        return r

    def _render_angled_labels(self):
        """Render angled label surface for better readability (45 degree angle)."""
        lw = self.label_width + self.lip_width
        angle_height = self.label_height

        # Create angled profile - sloped surface
        rs = (
            cq.Sketch()
            .segment((0, 0), (lw, 0))  # Top edge
            .segment((lw, -self.safe_label_height(backwall=True)))  # Back vertical
            .segment(
                (
                    lw - angle_height,
                    -self.safe_label_height(backwall=True) - angle_height,
                )
            )  # Angled bottom
            .segment((0, -self.label_lip_height))  # Front lip
            .close()
            .assemble()
            .vertices("<X")
            .vertices("<Y")
            .fillet(self.label_lip_height / 2)
        )
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        yo = -lw + self.outer_w / 2 + self.half_w + self.wall_th / 4
        rs = rsc.translate((-self.half_in, yo, self.floor_h + self.max_height))
        r = rs.intersect(self.interior_solid)

        if self.width_div > 0:
            # Add angled labels on dividers
            rs = (
                cq.Sketch()
                .segment((0, 0), (self.label_width, 0))
                .segment((self.label_width, -self.safe_label_height(backwall=False)))
                .segment(
                    (
                        self.label_width - angle_height / 2,
                        -self.safe_label_height(backwall=False) - angle_height / 2,
                    )
                )
                .segment((0, -self.label_lip_height))
                .close()
                .assemble()
                .vertices("<X")
                .vertices("<Y")
                .fillet(self.label_lip_height / 2)
            )
            rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
            rsc = rsc.translate((0, -self.label_width, self.floor_h + self.max_height))
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in + GR_DIV_WALL / 2)
                for y in range(self.width_div)
            ]
            r = r.union(composite_from_pts(rsc, pts))
        return r

    def _render_recessed_labels(self):
        """Render recessed/protected label area."""
        lw = self.label_width + self.lip_width
        recess_depth = 1.0  # Depth of the recessed area
        wall_thickness = 0.8  # Thickness of surrounding wall

        # Create recessed profile - U-shaped channel
        rs = (
            cq.Sketch()
            .segment((0, 0), (lw, 0))  # Top edge
            .segment((lw, -self.safe_label_height(backwall=True)))  # Outer back
            .segment(
                (lw - wall_thickness, -self.safe_label_height(backwall=True))
            )  # Inner back start
            .segment(
                (
                    lw - wall_thickness,
                    -self.safe_label_height(backwall=True) + recess_depth,
                )
            )  # Recess bottom
            .segment(
                (wall_thickness, -self.safe_label_height(backwall=True) + recess_depth)
            )  # Recess floor
            .segment((wall_thickness, -self.label_lip_height))  # Inner front
            .segment((0, -self.label_lip_height))  # Outer front lip
            .close()
            .assemble()
        )
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
        yo = -lw + self.outer_w / 2 + self.half_w + self.wall_th / 4
        rs = rsc.translate((-self.half_in, yo, self.floor_h + self.max_height))
        r = rs.intersect(self.interior_solid)

        if self.width_div > 0:
            # Add recessed labels on dividers
            rs = (
                cq.Sketch()
                .segment((0, 0), (self.label_width, 0))
                .segment((self.label_width, -self.safe_label_height(backwall=False)))
                .segment(
                    (
                        self.label_width - wall_thickness,
                        -self.safe_label_height(backwall=False),
                    )
                )
                .segment(
                    (
                        self.label_width - wall_thickness,
                        -self.safe_label_height(backwall=False) + recess_depth,
                    )
                )
                .segment(
                    (
                        wall_thickness,
                        -self.safe_label_height(backwall=False) + recess_depth,
                    )
                )
                .segment((wall_thickness, -self.label_lip_height))
                .segment((0, -self.label_lip_height))
                .close()
                .assemble()
            )
            rsc = cq.Workplane("YZ").placeSketch(rs).extrude(self.inner_l)
            rsc = rsc.translate((0, -self.label_width, self.floor_h + self.max_height))
            yl = self.inner_w / (self.width_div + 1)
            pts = [
                (-self.half_in, (y + 1) * yl - self.half_in + GR_DIV_WALL / 2)
                for y in range(self.width_div)
            ]
            r = r.union(composite_from_pts(rsc, pts))
        return r

    def render_text(self):
        """Render custom text embossed on the box."""
        if not self.text:
            return None

        try:
            import ocraf
        except ImportError:
            return None

        text_geometry = None
        try:
            text_geometry = ocraf.TEXT(
                self.text,
                font="Arial",
                size=self.text_height,
                thickness=self.text_depth,
                align=self.text_justification.upper(),
            )
        except Exception:
            try:
                text_geometry = ocraf.TEXT(
                    self.text,
                    font="Helvetica",
                    size=self.text_height,
                    thickness=self.text_depth,
                    align=self.text_justification.upper(),
                )
            except Exception:
                return None

        if text_geometry is None:
            return None

        if self.text_location == "front":
            return self._render_text_front(text_geometry)
        elif self.text_location == "top":
            return self._render_text_top(text_geometry)
        elif self.text_location == "lid":
            return self._render_text_lid(text_geometry)

        return None

    def _render_text_front(self, text_geometry):
        """Render text on front face."""
        bb = text_geometry.BoundingBox()
        text_width = bb.xlen
        text_height = bb.ylen

        x_pos = -self.half_in
        y_pos = 0

        text = text_geometry.translate(
            (x_pos, y_pos, self.floor_h + self.text_height / 2 + 5)
        )
        return text

    def _render_text_top(self, text_geometry):
        """Render text on top surface."""
        text = text_geometry.translate((0, 0, self.height - self.text_depth))
        return text

    def _render_text_lid(self, text_geometry):
        """Render text on lid area (top rim)."""
        text = text_geometry.translate((0, 0, self.height - self.text_depth))
        return text

    def render_qr_code(self):
        """Render QR code embossed on the box."""
        if not self.qr_code:
            return None

        try:
            import qrcode
            import numpy as np
        except ImportError:
            return None

        try:
            qr = qrcode.QRCode(
                version=1,
                error_correction=1,
                box_size=10,
                border=1,
            )
            qr.add_data(self.qr_code)
            qr.make(fit=True)

            img = qr.make_image(fill_color="black", back_color="white")
            img_array = np.array(img)

            pixels = img_array.astype(bool)
            cell_size = self.qr_size / pixels.shape[0]

            qr_geometry = []
            for y in range(pixels.shape[0]):
                for x in range(pixels.shape[1]):
                    if pixels[y, x]:
                        rect = (
                            cq.Workplane("XY")
                            .rect(cell_size, cell_size)
                            .extrude(self.qr_depth)
                            .translate(
                                (
                                    x * cell_size - self.qr_size / 2 + cell_size / 2,
                                    y * cell_size - self.qr_size / 2 + cell_size / 2,
                                    0,
                                )
                            )
                        )
                        qr_geometry.append(rect)

            if not qr_geometry:
                return None

            result = qr_geometry[0]
            for geom in qr_geometry[1:]:
                result = result.union(geom)

            if self.qr_location == "front":
                return self._render_qr_front(result)
            elif self.qr_location == "top":
                return self._render_qr_top(result)
            elif self.qr_location == "lid":
                return self._render_qr_lid(result)

            return None
        except Exception:
            return None

    def _render_qr_front(self, qr_geometry):
        """Render QR code on front face."""
        return qr_geometry.translate(
            (-self.half_in, 0, self.floor_h + self.qr_size / 2 + 5)
        )

    def _render_qr_top(self, qr_geometry):
        """Render QR code on top surface."""
        return qr_geometry.translate((0, 0, self.height - self.qr_depth))

    def _render_qr_lid(self, qr_geometry):
        """Render QR code on lid area."""
        return qr_geometry.translate((0, 0, self.height - self.qr_depth))

    def render_holes(self, obj):
        if not self.holes:
            return obj
        h = GR_HOLE_H
        if self.unsupported_holes:
            h += GR_HOLE_SLICE
        return (
            obj.faces("<Z")
            .workplane()
            .pushPoints(self.hole_centres)
            .cboreHole(GR_BOLT_D, self.hole_diam, h, depth=GR_BOLT_H)
        )

    def render_hole_fillers(self, obj):
        rc = (
            cq.Workplane("XY")
            .rect(self.hole_diam / 2, self.hole_diam)
            .extrude(GR_HOLE_SLICE)
        )
        xo = self.hole_diam / 2
        rs = composite_from_pts(rc, [(-xo, 0, GR_HOLE_H), (xo, 0, GR_HOLE_H)])
        rs = composite_from_pts(rs, self.hole_centres)
        return obj.union(rs.translate((-self.half_l, self.half_w, 0)))

    def _apply_interlock_slots(self, divider_obj, x_positions, y_positions):
        """Cut interlocking slots at divider intersections."""
        if not x_positions or not y_positions:
            return divider_obj

        slot_h = max(0.8, float(self.interlock_slot_height))
        slot_w = max(0.8, float(self.interlock_slot_width))

        z_mid = self.floor_h + self.max_height / 2

        slot_x = cq.Workplane("XY").rect(slot_w, GR_DIV_WALL * 2.6).extrude(slot_h)
        slot_x = slot_x.translate((0, 0, z_mid - slot_h / 2))

        slot_y = cq.Workplane("XY").rect(GR_DIV_WALL * 2.6, slot_w).extrude(slot_h)
        slot_y = slot_y.translate((0, 0, z_mid - slot_h / 2))

        cutters = None
        for x in x_positions:
            for y in y_positions:
                cx = slot_x.translate((x + self.half_l, y + self.half_w, 0))
                cy = slot_y.translate((x + self.half_l, y + self.half_w, 0))
                if cutters is None:
                    cutters = cx.union(cy)
                else:
                    cutters = cutters.union(cx).union(cy)

        if cutters is None:
            return divider_obj
        return divider_obj.cut(cutters)

    def render_drawer_slide_features(self, shell):
        """Render side rail/channel geometry for drawer slide integration."""
        slide_w = max(1.0, float(self.slide_width))
        slide_h = max(0.8, float(self.slide_height))
        z0 = self.floor_h + float(self.slide_z_offset)

        # Keep within safe shell region
        z0 = min(max(z0, 0.8), self.height - slide_h - 0.8)

        profile = (
            cq.Workplane("XY")
            .rect(self.outer_l - 2 * GR_FILLET, slide_w)
            .extrude(slide_h)
            .edges("|X")
            .fillet(min(0.6, slide_h / 2 - 0.05))
        )

        y_pos = self.half_w - slide_w / 2
        left = profile.translate((self.half_l, y_pos, z0))
        right = profile.translate((self.half_l, -y_pos, z0))
        features = left.union(right)

        if self.slide_style == "channel":
            # For channels, ensure cutters only affect existing shell
            features = features.intersect(shell)

        return features

    def render_finger_pull_cutter(self, shell):
        """Render finger pull cutout cutter on front wall for drawer-style boxes.

        Args:
            shell: The shell solid to cut from (passed to avoid re-rendering)

        Returns:
            Cutter solid that can be subtracted from the shell
        """
        if not self.drawer_style or self.finger_pull_style == "none":
            return None

        # Calculate finger pull geometry
        fp_width = self.finger_pull_width
        fp_depth = self.finger_pull_depth
        fp_height = self.finger_pull_height

        # Validate dimensions
        max_width = self.inner_l - 2 * GR_FILLET
        if fp_width > max_width:
            fp_width = max_width

        # Calculate vertical position (centered in available wall height)
        # Position on front wall, about 2/3 up from bottom
        base_z = self.floor_h + (self.max_height * 0.6) + self.finger_pull_z_offset

        # Ensure it stays within wall bounds vertically
        max_z = self.floor_h + self.max_height - fp_height - 1.0
        if base_z > max_z:
            base_z = max_z

        # Front wall position (scoop wall) - offset by depth/2 into the wall
        yo = -self.half_in + fp_depth / 2
        if not self.no_lip and not self.lite_style:
            yo += self.under_h

        zo = -GR_BOT_H + self.wall_th if self.lite_style else 0

        if self.finger_pull_style == "arc":
            # Arc/circular finger pull
            # rect(X=depth into wall, Y=height vertical)
            rs = (
                cq.Sketch()
                .rect(fp_depth, fp_height)
                .vertices(">X and >Y")
                .circle(min(fp_depth, fp_height), mode="s")
            )
        elif self.finger_pull_style == "slot":
            # Straight slot finger pull
            # slot_width = depth (into wall), slot_height = height (vertical)
            rs = (
                cq.Sketch()
                .segment((0, 0), (fp_depth, 0))
                .segment((fp_depth, -fp_height))
                .arc((fp_depth / 2, -fp_height), fp_depth / 2, 0, 180)
                .close()
                .assemble()
            )
        else:
            raise ValueError(f"Unknown finger_pull_style: {self.finger_pull_style}")

        # Extrude along the length of the box
        rsc = cq.Workplane("YZ").placeSketch(rs).extrude(fp_width)
        rsc = rsc.translate((-fp_width / 2, 0, base_z))
        rs = rsc.translate((0, yo, zo))

        # Intersect with shell to ensure we only cut where material exists
        return rs.intersect(shell)


class GridfinitySolidBox(GridfinityBox):
    """Convenience class to represent a solid Gridfinity box."""

    def __init__(self, length_u, width_u, height_u, **kwargs):
        super().__init__(length_u, width_u, height_u, **kwargs, solid=True)
