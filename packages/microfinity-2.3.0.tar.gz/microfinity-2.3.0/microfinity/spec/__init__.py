#! /usr/bin/env python3
"""
microfinity.spec - Gridfinity specification loading and constants.

This module provides the canonical source of truth for all Gridfinity
geometry values, loaded from YAML spec files.
"""

from microfinity.spec.loader import (
    GRIDFINITY,
    MICROFINITY,
    SPEC,
    GridfinitySpec,
    MicrofinitySpec,
    CombinedSpec,
    load_gridfinity_spec,
    load_microfinity_spec,
    get_spec_version,
    validate_spec,
    reload_specs,
)

from microfinity.spec.constants import *

__all__ = [
    # Spec instances
    "GRIDFINITY",
    "MICROFINITY",
    "SPEC",
    # Classes
    "GridfinitySpec",
    "MicrofinitySpec",
    "CombinedSpec",
    # Functions
    "load_gridfinity_spec",
    "load_microfinity_spec",
    "get_spec_version",
    "validate_spec",
    "reload_specs",
]
