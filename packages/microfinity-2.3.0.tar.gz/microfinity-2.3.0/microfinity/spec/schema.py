"""
microfinity.spec.schema - Pydantic models for spec file validation.

Provides schema validation for Gridfinity and Microfinity spec files.
Use these models to validate YAML specs at load time with type checking
and range constraints.

Usage:
    from microfinity.spec.schema import GridfinitySpecModel, MicrofinitySpecModel

    # Validate a loaded YAML dict
    gridfinity = GridfinitySpecModel.model_validate(yaml_dict)
    microfinity = MicrofinitySpecModel.model_validate(yaml_dict)
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional

from pydantic import BaseModel, Field, field_validator, model_validator


# =============================================================================
# Gridfinity Spec Schema
# =============================================================================


class GridMetadata(BaseModel):
    """Metadata section of the Gridfinity spec."""

    spec_version: str = Field(description="Semantic version of the spec")
    name: str = Field(default="Gridfinity")
    description: Optional[str] = None
    reference: Optional[str] = None
    url: Optional[str] = None


class GridSection(BaseModel):
    """Grid system configuration."""

    pitch_xy: float = Field(ge=40.0, le=44.0, description="Grid pitch in mm (must be ~42mm)")
    height_unit: float = Field(ge=6.0, le=8.0, description="Height unit in mm")
    clearance_xy: float = Field(ge=0.1, le=0.5, description="Clearance per side in mm")

    @field_validator("pitch_xy")
    @classmethod
    def validate_pitch(cls, v: float) -> float:
        """Gridfinity pitch should be exactly 42.0mm."""
        if v != 42.0:
            import warnings

            warnings.warn(f"Non-standard pitch: {v}mm (expected 42.0mm)")
        return v


class SocketProfile(BaseModel):
    """Baseplate socket profile definition."""

    bottom_chamfer_height: float = Field(ge=0.0, le=2.0)
    bottom_chamfer_angle: float = Field(ge=0, le=90)
    straight_height: float = Field(ge=0.0, le=5.0)
    top_chamfer_height: float = Field(ge=0.0, le=5.0)
    top_chamfer_angle: float = Field(ge=0, le=90)
    mating_offset: float = Field(ge=0.0, le=1.0)


class BaseplateSection(BaseModel):
    """Baseplate geometry configuration."""

    corner_radius: float = Field(ge=1.0, le=10.0, description="Corner fillet radius in mm")
    thickness: float = Field(ge=2.0, le=10.0, description="Baseplate thickness in mm")
    socket_profile: Optional[SocketProfile] = None


class FootProfile(BaseModel):
    """Bin foot profile definition."""

    bottom_chamfer_height: float = Field(ge=0.0, le=2.0)
    bottom_chamfer_angle: float = Field(ge=0, le=90)
    straight_height: float = Field(ge=0.0, le=5.0)
    top_chamfer_height: float = Field(ge=0.0, le=3.0)
    top_chamfer_angle: float = Field(ge=0, le=90)


class FootSection(BaseModel):
    """Bin foot geometry configuration."""

    height: float = Field(ge=3.0, le=7.0, description="Foot height in mm")
    clearance_above: float = Field(ge=0.0, le=1.0, description="Clearance above foot in mm")
    profile: Optional[FootProfile] = None


class FloorSection(BaseModel):
    """Bin floor geometry configuration."""

    nominal_height: float = Field(ge=5.0, le=10.0)
    offset: float = Field(ge=0.0, le=5.0)


class StackingLipProfile(BaseModel):
    """Stacking lip profile definition."""

    underside_chamfer_height: float = Field(ge=0.0, le=3.0)
    underside_chamfer_angle: float = Field(ge=0, le=90)
    topside_straight_height: float = Field(ge=0.0, le=3.0)
    top_chamfer_height: float = Field(ge=0.0, le=2.0)
    top_chamfer_angle: float  # Can be negative for outward angle
    straight_height: float = Field(ge=0.0, le=3.0)
    bottom_chamfer_height: float = Field(ge=0.0, le=3.0)
    bottom_chamfer_angle: float  # Can be negative for outward angle


class StackingLip(BaseModel):
    """Stacking lip configuration."""

    height: float = Field(ge=2.0, le=7.0)
    profile: Optional[StackingLipProfile] = None


class BinSection(BaseModel):
    """Bin/box geometry configuration."""

    corner_radius: float = Field(ge=1.0, le=6.0, description="Corner fillet radius in mm")
    wall_thickness: float = Field(ge=0.5, le=3.0, description="Wall thickness in mm")
    divider_wall_thickness: float = Field(ge=0.5, le=3.0, description="Divider thickness in mm")
    interior_fillet: float = Field(ge=0.0, le=3.0, description="Interior fillet radius in mm")
    foot: FootSection
    floor: Optional[FloorSection] = None
    stacking_lip: Optional[StackingLip] = None


class MagnetHole(BaseModel):
    """Magnet pocket dimensions."""

    diameter: float = Field(ge=4.0, le=10.0)
    depth: float = Field(ge=1.0, le=5.0)


class ScrewHole(BaseModel):
    """Screw hole dimensions."""

    diameter: float = Field(ge=2.0, le=6.0)
    depth: float = Field(ge=2.0, le=10.0)


class HolePosition(BaseModel):
    """Hole positioning configuration."""

    from_bin_edge: float = Field(ge=5.0, le=15.0)
    from_cell_edge: float = Field(ge=5.0, le=15.0)
    spacing: float = Field(ge=20.0, le=35.0)


class HolesSection(BaseModel):
    """Magnet and screw hole configuration."""

    magnet: MagnetHole
    screw: Optional[ScrewHole] = None
    position: HolePosition


class HardwareSize(BaseModel):
    """Hardware dimensions for a specific size."""

    diameter: float = Field(ge=0.5, le=10.0)
    clearance_diameter: float = Field(ge=1.0, le=15.0)
    counterbore_diameter: Optional[float] = Field(default=None, ge=2.0, le=20.0)
    counterbore_depth: Optional[float] = Field(default=None, ge=1.0, le=10.0)


class HardwareSection(BaseModel):
    """Hardware dimensions (M2, M3, etc.)."""

    m2: Optional[HardwareSize] = None
    m3: Optional[HardwareSize] = None


class FitClasses(BaseModel):
    """Fit class tolerances."""

    tight: float = Field(ge=0.0, le=0.5)
    nominal: float = Field(ge=0.1, le=0.5)
    loose: float = Field(ge=0.2, le=1.0)


class TolerancesSection(BaseModel):
    """Tolerance configuration."""

    nominal: float = Field(ge=0.1, le=1.0, description="General tolerance in mm")
    epsilon: float = Field(ge=1e-9, le=1e-3, description="Floating-point epsilon")
    fit: Optional[FitClasses] = None


class GridfinitySpecModel(BaseModel):
    """Complete Gridfinity specification schema."""

    metadata: GridMetadata
    grid: GridSection
    baseplate: BaseplateSection
    bin: BinSection
    holes: Optional[HolesSection] = None
    hardware: Optional[HardwareSection] = None
    tolerances: Optional[TolerancesSection] = None

    model_config = {"extra": "allow"}  # Allow unknown fields for forward compatibility


# =============================================================================
# Microfinity Spec Schema
# =============================================================================


class MicrofinityMetadata(BaseModel):
    """Metadata section of the Microfinity spec."""

    spec_version: str = Field(description="Semantic version of the spec")
    name: str = Field(default="Microfinity")
    description: Optional[str] = None
    base_spec: Optional[str] = None
    repository: Optional[str] = None


class MicroDivisionsSection(BaseModel):
    """Micro-division system configuration."""

    supported: List[int] = Field(description="List of supported division factors")
    default: int = Field(ge=1, le=4, description="Default division factor")
    future: Optional[List[int]] = None

    @field_validator("supported")
    @classmethod
    def validate_supported(cls, v: List[int]) -> List[int]:
        """Validate supported divisions are in expected range."""
        valid_divisions = {1, 2, 3, 4}
        for div in v:
            if div not in valid_divisions:
                raise ValueError(f"Invalid division: {div}. Must be in {valid_divisions}")
        return v


class MeshCleanup(BaseModel):
    """Mesh cleanup configuration."""

    min_component_faces: int = Field(ge=1, le=10000)
    min_sliver_size: float = Field(ge=0, le=1.0)
    min_sliver_volume: float = Field(ge=0, le=1.0)


class MeshcutterSection(BaseModel):
    """Meshcutter configuration."""

    z_split_height: float = Field(ge=3.0, le=8.0, description="Z split height in mm")
    sleeve_height: float = Field(ge=0.1, le=2.0, description="Sleeve overlap height in mm")
    coplanar_epsilon: float = Field(ge=0.001, le=0.1, description="Coplanar avoidance offset")
    cleanup: Optional[MeshCleanup] = None
    golden_test_threshold: Optional[float] = Field(default=None, ge=0.0, le=10.0)


class ClipSection(BaseModel):
    """Connection clip configuration."""

    default_clearance: float = Field(ge=-0.5, le=1.0, description="Default clip clearance in mm")
    calibration_sweep: Optional[List[float]] = None


class NotchSection(BaseModel):
    """Notch (female slot) dimensions."""

    width: float = Field(ge=2.0, le=15.0)
    depth: float = Field(ge=1.0, le=5.0)
    height: float = Field(ge=1.0, le=10.0)
    chamfer: float = Field(ge=0.0, le=2.0)
    top_margin: float = Field(ge=0.0, le=2.0)
    bottom_margin: float = Field(ge=0.0, le=2.0)


class LayoutSection(BaseModel):
    """Baseplate layout system configuration."""

    clip: Optional[ClipSection] = None
    notch: Optional[NotchSection] = None


class ExportFormats(BaseModel):
    """Default export formats."""

    mesh: str = Field(default="stl")
    cad: str = Field(default="step")
    drawing: str = Field(default="svg")


class StlSettings(BaseModel):
    """STL export settings."""

    tolerance: float = Field(ge=0.001, le=1.0)
    angular_tolerance: float = Field(ge=0.01, le=10.0)


class ExportSection(BaseModel):
    """Export settings configuration."""

    formats: Optional[ExportFormats] = None
    stl: Optional[StlSettings] = None
    naming_pattern: Optional[str] = None


class SvgSettings(BaseModel):
    """SVG debug output settings."""

    stroke_width: float = Field(ge=0.01, le=1.0)
    fill_opacity: float = Field(ge=0.0, le=1.0)
    scale: float = Field(ge=1, le=100)


class IntermediatesSettings(BaseModel):
    """Intermediate mesh export settings."""

    enabled: bool = False
    output_dir: str = "./debug"
    formats: List[str] = ["stl"]


class DiagnosticsSettings(BaseModel):
    """Diagnostic output settings."""

    verbose: bool = False
    timing: bool = False
    memory: bool = False


class DebugSection(BaseModel):
    """Debug settings configuration."""

    svg: Optional[SvgSettings] = None
    intermediates: Optional[IntermediatesSettings] = None
    diagnostics: Optional[DiagnosticsSettings] = None


class PocketTest(BaseModel):
    """Fractional pocket test configuration."""

    fractions: List[float]
    include_reference: bool = True
    include_slots: bool = True


class ToleranceTest(BaseModel):
    """Tolerance graduation test configuration."""

    values: List[float]


class CalibrationCube(BaseModel):
    """Quick calibration cube configuration."""

    size: List[float]
    include_features: List[str]


class CalibrationSection(BaseModel):
    """Calibration test prints configuration."""

    pocket_test: Optional[PocketTest] = None
    tolerance_test: Optional[ToleranceTest] = None
    cube: Optional[CalibrationCube] = None


class MicrofinitySpecModel(BaseModel):
    """Complete Microfinity specification schema."""

    metadata: MicrofinityMetadata
    micro_divisions: MicroDivisionsSection
    meshcutter: MeshcutterSection
    layout: Optional[LayoutSection] = None
    export: Optional[ExportSection] = None
    debug: Optional[DebugSection] = None
    calibration: Optional[CalibrationSection] = None

    model_config = {"extra": "allow"}  # Allow unknown fields for forward compatibility


# =============================================================================
# Validation Functions
# =============================================================================


def validate_gridfinity_spec(spec_dict: Dict[str, Any]) -> GridfinitySpecModel:
    """Validate a Gridfinity spec dictionary using Pydantic.

    Args:
        spec_dict: Dictionary loaded from YAML

    Returns:
        Validated GridfinitySpecModel

    Raises:
        pydantic.ValidationError: If validation fails
    """
    return GridfinitySpecModel.model_validate(spec_dict)


def validate_microfinity_spec(spec_dict: Dict[str, Any]) -> MicrofinitySpecModel:
    """Validate a Microfinity spec dictionary using Pydantic.

    Args:
        spec_dict: Dictionary loaded from YAML

    Returns:
        Validated MicrofinitySpecModel

    Raises:
        pydantic.ValidationError: If validation fails
    """
    return MicrofinitySpecModel.model_validate(spec_dict)
