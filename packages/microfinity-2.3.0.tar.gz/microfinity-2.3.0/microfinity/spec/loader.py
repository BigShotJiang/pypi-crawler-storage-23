#! /usr/bin/env python3
"""
microfinity.spec.loader - Specification loader for Gridfinity dimensions.

Loads canonical dimensions from YAML spec files and provides typed access.
This is the single source of truth for all Gridfinity geometry.

Usage:
    from microfinity.spec.loader import SPEC, GRIDFINITY, MICROFINITY

    pitch = GRIDFINITY['grid']['pitch_xy']  # 42.0
    foot_height = GRIDFINITY['bin']['foot']['height']  # 4.75
    z_split = MICROFINITY['meshcutter']['z_split_height']  # 5.0
"""

from __future__ import annotations

import os
from math import sqrt
from pathlib import Path
from typing import Any, Dict, Optional, Union

import yaml

# =============================================================================
# Spec File Paths
# =============================================================================

# Find the specs directory relative to this module
_MODULE_DIR = Path(__file__).parent
_PACKAGE_DIR = _MODULE_DIR.parent.parent
_SPECS_DIR = _PACKAGE_DIR / "specs"

GRIDFINITY_SPEC_PATH = _SPECS_DIR / "gridfinity_v1.yml"
MICROFINITY_SPEC_PATH = _SPECS_DIR / "microfinity.yml"


# =============================================================================
# YAML Loading
# =============================================================================


def load_yaml(path: Path) -> Dict[str, Any]:
    """Load a YAML file and return its contents as a dictionary.

    Args:
        path: Path to the YAML file

    Returns:
        Dictionary containing the YAML contents

    Raises:
        FileNotFoundError: If the file doesn't exist
        yaml.YAMLError: If the file contains invalid YAML
    """
    if not path.exists():
        raise FileNotFoundError(f"Spec file not found: {path}")

    with open(path, "r") as f:
        return yaml.safe_load(f)


def load_gridfinity_spec(path: Optional[Path] = None) -> Dict[str, Any]:
    """Load the Gridfinity specification.

    Args:
        path: Optional custom path to spec file. Defaults to built-in spec.

    Returns:
        Dictionary containing the Gridfinity specification
    """
    path = path or GRIDFINITY_SPEC_PATH
    return load_yaml(path)


def load_microfinity_spec(path: Optional[Path] = None) -> Dict[str, Any]:
    """Load the Microfinity specification.

    Args:
        path: Optional custom path to spec file. Defaults to built-in spec.

    Returns:
        Dictionary containing the Microfinity specification
    """
    path = path or MICROFINITY_SPEC_PATH
    return load_yaml(path)


# =============================================================================
# Spec Access Classes
# =============================================================================


class DotDict(dict):
    """Dictionary that allows dot notation access to nested keys.

    Example:
        d = DotDict({'a': {'b': 1}})
        d.a.b  # Returns 1
        d['a']['b']  # Also works
    """

    def __getattr__(self, key: str) -> Any:
        try:
            value = self[key]
            if isinstance(value, dict):
                return DotDict(value)
            return value
        except KeyError:
            raise AttributeError(f"No such attribute: {key}")

    def __setattr__(self, key: str, value: Any) -> None:
        self[key] = value

    def __delattr__(self, key: str) -> None:
        try:
            del self[key]
        except KeyError:
            raise AttributeError(f"No such attribute: {key}")


class GridfinitySpec:
    """Typed access to Gridfinity specification values.

    Provides both dictionary-style and attribute-style access to spec values,
    with computed/derived values added automatically.
    """

    def __init__(self, spec: Dict[str, Any]):
        self._spec = DotDict(spec)
        self._add_computed_values()

    @property
    def version(self) -> str:
        """Spec version string."""
        return self._spec.get("metadata", {}).get("spec_version", "unknown")

    @property
    def name(self) -> str:
        """Spec name."""
        return self._spec.get("metadata", {}).get("name", "Gridfinity")

    def _add_computed_values(self) -> None:
        """Add computed/derived values to the spec."""
        # Common constants
        self._sqrt2 = sqrt(2)

        # Grid derived values
        grid = self._spec["grid"]
        grid["bin_size_1x1"] = grid["pitch_xy"] - 2 * grid["clearance_xy"]

        # Hole pattern (cell-local coordinates)
        holes = self._spec.get("holes", {})
        if "position" in holes:
            pos = holes["position"]
            offset = pos.get("from_cell_edge", 8.0)
            spacing = pos.get("spacing", 26.0)
            holes["pattern"] = [
                [offset, offset],
                [offset + spacing, offset],
                [offset, offset + spacing],
                [offset + spacing, offset + spacing],
            ]

    @property
    def raw(self) -> Dict[str, Any]:
        """Get the raw specification dictionary."""
        return self._spec

    def __getitem__(self, key: str) -> Any:
        return self._spec[key]

    def __getattr__(self, key: str) -> Any:
        if key.startswith("_"):
            return object.__getattribute__(self, key)
        return getattr(self._spec, key)

    # Convenience properties for common values
    @property
    def pitch(self) -> float:
        """Grid pitch (42mm)."""
        return self._spec["grid"]["pitch_xy"]

    @property
    def height_unit(self) -> float:
        """Height unit (7mm)."""
        return self._spec["grid"]["height_unit"]

    @property
    def clearance(self) -> float:
        """Clearance per side (0.25mm)."""
        return self._spec["grid"]["clearance_xy"]

    @property
    def foot_height(self) -> float:
        """Bin foot height (4.75mm)."""
        return self._spec["bin"]["foot"]["height"]

    @property
    def corner_radius(self) -> float:
        """Bin corner radius (3.75mm)."""
        return self._spec["bin"]["corner_radius"]

    @property
    def wall_thickness(self) -> float:
        """Bin wall thickness (1.0mm)."""
        return self._spec["bin"]["wall_thickness"]


class MicrofinitySpec:
    """Typed access to Microfinity specification values."""

    def __init__(self, spec: Dict[str, Any]):
        self._spec = DotDict(spec)

    @property
    def version(self) -> str:
        """Spec version string."""
        return self._spec.get("metadata", {}).get("spec_version", "unknown")

    @property
    def raw(self) -> Dict[str, Any]:
        """Get the raw specification dictionary."""
        return self._spec

    def __getitem__(self, key: str) -> Any:
        return self._spec[key]

    def __getattr__(self, key: str) -> Any:
        if key.startswith("_"):
            return object.__getattribute__(self, key)
        return getattr(self._spec, key)

    # Convenience properties
    @property
    def z_split_height(self) -> float:
        """Z height where meshcutter splits base from top (5.0mm)."""
        return self._spec["meshcutter"]["z_split_height"]

    @property
    def sleeve_height(self) -> float:
        """Sleeve overlap height for robust union (0.5mm)."""
        return self._spec["meshcutter"]["sleeve_height"]

    @property
    def supported_divisions(self) -> list:
        """List of supported micro-division factors."""
        return self._spec["micro_divisions"]["supported"]

    def micro_pitch(self, divisions: int = 4) -> float:
        """Calculate micro-pitch for given division factor.

        Args:
            divisions: Number of divisions per grid unit (1, 2, or 4)

        Returns:
            Pitch in mm (42.0, 21.0, or 10.5)
        """
        if divisions not in self.supported_divisions:
            raise ValueError(f"Unsupported division factor: {divisions}. " f"Supported: {self.supported_divisions}")
        # Need access to gridfinity pitch - use global GRIDFINITY
        return 42.0 / divisions


class CombinedSpec:
    """Combined access to both Gridfinity and Microfinity specs."""

    def __init__(
        self,
        gridfinity: GridfinitySpec,
        microfinity: MicrofinitySpec,
    ):
        self.gridfinity = gridfinity
        self.microfinity = microfinity

    # Delegate common properties to gridfinity
    @property
    def pitch(self) -> float:
        return self.gridfinity.pitch

    @property
    def height_unit(self) -> float:
        return self.gridfinity.height_unit

    def micro_pitch(self, divisions: int = 4) -> float:
        return self.microfinity.micro_pitch(divisions)


# =============================================================================
# Utility Functions
# =============================================================================


def get_spec_version() -> Dict[str, str]:
    """Get version information for loaded specs.

    Returns:
        Dictionary with spec versions
    """
    versions = {}
    if GRIDFINITY:
        versions["gridfinity"] = GRIDFINITY.raw.get("metadata", {}).get("spec_version", "unknown")
    if MICROFINITY:
        versions["microfinity"] = MICROFINITY.raw.get("metadata", {}).get("spec_version", "unknown")
    return versions


def validate_spec(spec: Dict[str, Any], spec_type: str = "gridfinity") -> bool:
    """Validate that a spec dictionary has required fields and values in expected ranges.

    This function provides both legacy validation (range checks) and optional
    Pydantic validation (full schema validation with type checking).

    Args:
        spec: Specification dictionary to validate
        spec_type: Type of spec ("gridfinity" or "microfinity")

    Returns:
        True if valid, raises ValueError if invalid
    """
    # Try Pydantic validation first (more comprehensive)
    try:
        from microfinity.spec.schema import (
            validate_gridfinity_spec,
            validate_microfinity_spec,
        )

        if spec_type == "gridfinity":
            validate_gridfinity_spec(spec)
        elif spec_type == "microfinity":
            validate_microfinity_spec(spec)
        return True
    except ImportError:
        # Pydantic not available, fall back to legacy validation
        pass
    except Exception as e:
        # Pydantic validation failed, include error details
        raise ValueError(f"Schema validation failed: {e}")

    # Legacy validation (fallback)
    if spec_type == "gridfinity":
        required = ["grid", "bin", "baseplate"]
        for key in required:
            if key not in spec:
                raise ValueError(f"Missing required section: {key}")

        # Validate grid section
        grid = spec["grid"]
        if "pitch_xy" not in grid:
            raise ValueError("Missing grid.pitch_xy")
        if grid["pitch_xy"] != 42.0:
            raise ValueError(f"Invalid grid.pitch_xy: {grid['pitch_xy']} (expected 42.0)")

        # Validate expected ranges
        _validate_range(grid, "height_unit", 6.0, 8.0, "grid.height_unit")
        _validate_range(grid, "clearance_xy", 0.1, 0.5, "grid.clearance_xy")

        # Validate bin section
        bin_spec = spec["bin"]
        _validate_range(bin_spec, "wall_thickness", 0.5, 2.0, "bin.wall_thickness")
        _validate_range(bin_spec, "corner_radius", 2.0, 5.0, "bin.corner_radius")

        if "foot" in bin_spec:
            foot = bin_spec["foot"]
            _validate_range(foot, "height", 4.0, 6.0, "bin.foot.height")
            _validate_range(foot, "clearance_above", 0.1, 0.5, "bin.foot.clearance_above")

        # Validate holes section
        if "holes" in spec:
            holes = spec["holes"]
            if "magnet" in holes:
                _validate_range(holes["magnet"], "diameter", 5.0, 8.0, "holes.magnet.diameter")
                _validate_range(holes["magnet"], "depth", 1.5, 4.0, "holes.magnet.depth")

    elif spec_type == "microfinity":
        required = ["micro_divisions", "meshcutter"]
        for key in required:
            if key not in spec:
                raise ValueError(f"Missing required section: {key}")

        # Validate micro_divisions
        micro = spec["micro_divisions"]
        if "supported" not in micro:
            raise ValueError("Missing micro_divisions.supported")
        for div in micro["supported"]:
            if div not in [1, 2, 3, 4]:
                raise ValueError(f"Invalid micro_division: {div} (expected 1, 2, 3, or 4)")

        # Validate meshcutter
        meshcutter = spec["meshcutter"]
        _validate_range(meshcutter, "z_split_height", 4.0, 6.0, "meshcutter.z_split_height")
        _validate_range(meshcutter, "sleeve_height", 0.1, 1.0, "meshcutter.sleeve_height")

    return True


def _validate_range(d: Dict[str, Any], key: str, min_val: float, max_val: float, path: str) -> None:
    """Validate that a value exists and is within expected range.

    Args:
        d: Dictionary containing the value
        key: Key to look up
        min_val: Minimum expected value
        max_val: Maximum expected value
        path: Full path for error messages

    Raises:
        ValueError: If value is missing or out of range
    """
    if key not in d:
        raise ValueError(f"Missing required field: {path}")
    val = d[key]
    if not isinstance(val, (int, float)):
        raise ValueError(f"Invalid type for {path}: expected number, got {type(val).__name__}")
    if val < min_val or val > max_val:
        raise ValueError(f"Value out of range for {path}: {val} (expected {min_val}-{max_val})")


def reload_specs() -> None:
    """Reload spec files from disk.

    Useful if spec files have been modified at runtime.
    """
    global GRIDFINITY, MICROFINITY, SPEC, _gridfinity_raw, _microfinity_raw

    _gridfinity_raw = load_gridfinity_spec()
    _microfinity_raw = load_microfinity_spec()

    # Validate reloaded specs
    validate_spec(_gridfinity_raw, "gridfinity")
    validate_spec(_microfinity_raw, "microfinity")

    GRIDFINITY = GridfinitySpec(_gridfinity_raw)
    MICROFINITY = MicrofinitySpec(_microfinity_raw)
    SPEC = CombinedSpec(GRIDFINITY, MICROFINITY)


# =============================================================================
# Global Spec Instances (loaded at module import)
# =============================================================================

# Load specs on module import
try:
    _gridfinity_raw = load_gridfinity_spec()
    _microfinity_raw = load_microfinity_spec()

    # Validate specs at load time
    validate_spec(_gridfinity_raw, "gridfinity")
    validate_spec(_microfinity_raw, "microfinity")
except FileNotFoundError as e:
    # Specs not found - provide empty defaults for now
    import warnings

    warnings.warn(f"Spec files not found: {e}. Using empty defaults.")
    _gridfinity_raw = {}
    _microfinity_raw = {}
except ValueError as e:
    # Spec validation failed
    import warnings

    warnings.warn(f"Spec validation failed: {e}. Using loaded values anyway.")

# Create typed spec instances
GRIDFINITY = GridfinitySpec(_gridfinity_raw) if _gridfinity_raw else None
MICROFINITY = MicrofinitySpec(_microfinity_raw) if _microfinity_raw else None
SPEC = CombinedSpec(GRIDFINITY, MICROFINITY) if GRIDFINITY and MICROFINITY else None
