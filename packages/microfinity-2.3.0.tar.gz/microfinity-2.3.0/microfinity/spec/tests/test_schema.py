"""Unit tests for spec schema validation.

Tests Pydantic schema validation for Gridfinity and Microfinity specs.
"""

from pathlib import Path

import pytest
import yaml

from microfinity.spec.schema import (
    GridfinitySpecSchema,
    MicrofinitySpecSchema,
    ValidationResult,
    validate_gridfinity_spec,
    validate_microfinity_spec,
    validate_spec_file,
)


class TestGridfinitySpecSchema:
    """Test Gridfinity spec Pydantic schema."""

    def test_valid_minimal_spec(self):
        """Test validating a minimal valid Gridfinity spec."""
        spec = {
            "metadata": {
                "spec_version": "1.0.0",
                "name": "Test",
            },
            "grid": {
                "pitch_xy": 42.0,
                "height_unit": 7.0,
                "clearance_xy": 0.25,
            },
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {
                    "nominal_height": 7.0,
                    "offset": 2.25,
                },
            },
        }

        result = GridfinitySpecSchema(**spec)
        assert result.metadata.spec_version == "1.0.0"
        assert result.grid.pitch_xy == 42.0

    def test_invalid_negative_pitch(self):
        """Test that negative pitch raises validation error."""
        spec = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {
                "pitch_xy": -42.0,  # Invalid
                "height_unit": 7.0,
                "clearance_xy": 0.25,
            },
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {
                    "nominal_height": 7.0,
                    "offset": 2.25,
                },
            },
        }

        with pytest.raises(Exception):  # Pydantic validation error
            GridfinitySpecSchema(**spec)

    def test_invalid_angle_greater_than_90(self):
        """Test that angles > 90 raise validation error."""
        spec = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {
                "pitch_xy": 42.0,
                "height_unit": 7.0,
                "clearance_xy": 0.25,
            },
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 100,  # Invalid
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {
                    "nominal_height": 7.0,
                    "offset": 2.25,
                },
            },
        }

        with pytest.raises(Exception):
            GridfinitySpecSchema(**spec)


class TestMicrofinitySpecSchema:
    """Test Microfinity spec Pydantic schema."""

    def test_valid_minimal_spec(self):
        """Test validating a minimal valid Microfinity spec."""
        spec = {
            "metadata": {
                "spec_version": "1.0.0",
                "name": "Microfinity",
                "base_spec": "gridfinity_v1.yml",
            },
            "micro_divisions": {
                "supported": [1, 2, 4],
                "default": 1,
            },
            "meshcutter": {
                "z_split_height": 5.0,
                "sleeve_height": 0.5,
                "coplanar_epsilon": 0.02,
                "cleanup": {
                    "min_component_faces": 100,
                    "min_sliver_size": 0.001,
                    "min_sliver_volume": 1.0e-12,
                },
                "golden_test_threshold": 1.0,
            },
            "layout": {
                "clip": {
                    "default_clearance": 0.20,
                    "calibration_sweep": [-0.10, 0.00, 0.10],
                },
                "notch": {
                    "width": 5.0,
                    "depth": 2.5,
                    "height": 3.0,
                    "chamfer": 0.5,
                    "top_margin": 0.5,
                    "bottom_margin": 0.5,
                },
            },
            "export": {
                "formats": {
                    "mesh": "stl",
                    "cad": "step",
                    "drawing": "svg",
                },
                "stl": {
                    "tolerance": 0.01,
                    "angular_tolerance": 0.1,
                },
                "naming_pattern": "gf_{type}_{size}",
            },
            "debug": {
                "cross_section_z_step": 0.5,
                "footprint_z_offset": 0.1,
            },
        }

        result = MicrofinitySpecSchema(**spec)
        assert result.metadata.spec_version == "1.0.0"
        assert result.micro_divisions.default == 1

    def test_default_must_be_in_supported(self):
        """Test that default division must be in supported list."""
        spec = {
            "metadata": {
                "spec_version": "1.0.0",
                "name": "Microfinity",
                "base_spec": "gridfinity_v1.yml",
            },
            "micro_divisions": {
                "supported": [1, 2, 4],
                "default": 8,  # Not in supported
            },
            "meshcutter": {
                "z_split_height": 5.0,
                "sleeve_height": 0.5,
                "coplanar_epsilon": 0.02,
                "cleanup": {
                    "min_component_faces": 100,
                    "min_sliver_size": 0.001,
                    "min_sliver_volume": 1.0e-12,
                },
                "golden_test_threshold": 1.0,
            },
            "layout": {
                "clip": {
                    "default_clearance": 0.20,
                    "calibration_sweep": [],
                },
                "notch": {
                    "width": 5.0,
                    "depth": 2.5,
                    "height": 3.0,
                    "chamfer": 0.5,
                    "top_margin": 0.5,
                    "bottom_margin": 0.5,
                },
            },
            "export": {
                "formats": {
                    "mesh": "stl",
                    "cad": "step",
                    "drawing": "svg",
                },
                "stl": {
                    "tolerance": 0.01,
                    "angular_tolerance": 0.1,
                },
                "naming_pattern": "gf_{type}_{size}",
            },
            "debug": {
                "cross_section_z_step": 0.5,
                "footprint_z_offset": 0.1,
            },
        }

        with pytest.raises(Exception):
            MicrofinitySpecSchema(**spec)


class TestValidateGridfinitySpec:
    """Test validate_gridfinity_spec function."""

    def test_valid_spec(self):
        """Test validating valid spec returns success."""
        spec = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {"pitch_xy": 42.0, "height_unit": 7.0, "clearance_xy": 0.25},
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {"nominal_height": 7.0, "offset": 2.25},
            },
        }

        result = validate_gridfinity_spec(spec)

        assert result.is_valid is True
        assert result.errors == []

    def test_invalid_spec_returns_errors(self):
        """Test validating invalid spec returns errors."""
        spec = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {"pitch_xy": -42.0},  # Invalid
        }

        result = validate_gridfinity_spec(spec)

        assert result.is_valid is False
        assert len(result.errors) > 0

    def test_unusual_pitch_warning(self):
        """Test that unusual pitch values generate warnings."""
        spec = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {"pitch_xy": 100.0, "height_unit": 7.0, "clearance_xy": 0.25},
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {"nominal_height": 7.0, "offset": 2.25},
            },
        }

        result = validate_gridfinity_spec(spec)

        assert result.is_valid is True
        assert len(result.warnings) > 0
        assert any("unusual" in w.lower() for w in result.warnings)


class TestValidateMicrofinitySpec:
    """Test validate_microfinity_spec function."""

    def test_valid_spec(self):
        """Test validating valid spec returns success."""
        spec = {
            "metadata": {
                "spec_version": "1.0.0",
                "name": "Microfinity",
                "base_spec": "gridfinity_v1.yml",
            },
            "micro_divisions": {"supported": [1, 2, 4], "default": 1},
            "meshcutter": {
                "z_split_height": 5.0,
                "sleeve_height": 0.5,
                "coplanar_epsilon": 0.02,
                "cleanup": {
                    "min_component_faces": 100,
                    "min_sliver_size": 0.001,
                    "min_sliver_volume": 1.0e-12,
                },
                "golden_test_threshold": 1.0,
            },
            "layout": {
                "clip": {"default_clearance": 0.20, "calibration_sweep": []},
                "notch": {
                    "width": 5.0,
                    "depth": 2.5,
                    "height": 3.0,
                    "chamfer": 0.5,
                    "top_margin": 0.5,
                    "bottom_margin": 0.5,
                },
            },
            "export": {
                "formats": {"mesh": "stl", "cad": "step", "drawing": "svg"},
                "stl": {"tolerance": 0.01, "angular_tolerance": 0.1},
                "naming_pattern": "test",
            },
            "debug": {"cross_section_z_step": 0.5, "footprint_z_offset": 0.1},
        }

        result = validate_microfinity_spec(spec)

        assert result.is_valid is True

    def test_non_power_of_2_division_warning(self):
        """Test that non-power-of-2 divisions generate warnings."""
        spec = {
            "metadata": {
                "spec_version": "1.0.0",
                "name": "Microfinity",
                "base_spec": "gridfinity_v1.yml",
            },
            "micro_divisions": {"supported": [1, 3], "default": 1},  # 3 is not power of 2
            "meshcutter": {
                "z_split_height": 5.0,
                "sleeve_height": 0.5,
                "coplanar_epsilon": 0.02,
                "cleanup": {
                    "min_component_faces": 100,
                    "min_sliver_size": 0.001,
                    "min_sliver_volume": 1.0e-12,
                },
                "golden_test_threshold": 1.0,
            },
            "layout": {
                "clip": {"default_clearance": 0.20, "calibration_sweep": []},
                "notch": {
                    "width": 5.0,
                    "depth": 2.5,
                    "height": 3.0,
                    "chamfer": 0.5,
                    "top_margin": 0.5,
                    "bottom_margin": 0.5,
                },
            },
            "export": {
                "formats": {"mesh": "stl", "cad": "step", "drawing": "svg"},
                "stl": {"tolerance": 0.01, "angular_tolerance": 0.1},
                "naming_pattern": "test",
            },
            "debug": {"cross_section_z_step": 0.5, "footprint_z_offset": 0.1},
        }

        result = validate_microfinity_spec(spec)

        assert result.is_valid is True
        assert any("power of 2" in w.lower() for w in result.warnings)


class TestValidateSpecFile:
    """Test validate_spec_file function."""

    def test_file_not_found(self):
        """Test validating non-existent file."""
        result = validate_spec_file(Path("/nonexistent/spec.yml"))

        assert result.is_valid is False
        assert any("not found" in e.lower() for e in result.errors)

    def test_auto_detect_gridfinity(self, tmp_path):
        """Test auto-detection of Gridfinity spec."""
        spec_file = tmp_path / "gridfinity_v1.yml"
        spec_content = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {"pitch_xy": 42.0, "height_unit": 7.0, "clearance_xy": 0.25},
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {"nominal_height": 7.0, "offset": 2.25},
            },
        }
        spec_file.write_text(yaml.dump(spec_content))

        result = validate_spec_file(spec_file)

        assert result.is_valid is True

    def test_explicit_type_override(self, tmp_path):
        """Test explicit type specification."""
        spec_file = tmp_path / "custom.yml"
        spec_content = {
            "metadata": {"spec_version": "1.0.0", "name": "Test"},
            "grid": {"pitch_xy": 42.0, "height_unit": 7.0, "clearance_xy": 0.25},
            "baseplate": {
                "corner_radius": 4.0,
                "thickness": 5.0,
                "socket_profile": {
                    "bottom_chamfer_height": 0.7,
                    "bottom_chamfer_angle": 45,
                    "straight_height": 1.8,
                    "top_chamfer_height": 2.15,
                    "top_chamfer_angle": 45,
                    "mating_offset": 0.25,
                },
            },
            "bin": {
                "corner_radius": 3.75,
                "wall_thickness": 1.0,
                "divider_wall_thickness": 1.2,
                "interior_fillet": 1.1,
                "foot": {
                    "height": 4.75,
                    "clearance_above": 0.25,
                    "profile": {
                        "bottom_chamfer_height": 0.8,
                        "bottom_chamfer_angle": 45,
                        "straight_height": 1.8,
                        "top_chamfer_height": 1.15,
                        "top_chamfer_angle": 45,
                    },
                },
                "floor": {"nominal_height": 7.0, "offset": 2.25},
            },
        }
        spec_file.write_text(yaml.dump(spec_content))

        result = validate_spec_file(spec_file, spec_type="gridfinity")

        assert result.is_valid is True


class TestValidationResult:
    """Test ValidationResult class."""

    def test_bool_conversion_valid(self):
        """Test that valid result is truthy."""
        result = ValidationResult(True, [], [])
        assert bool(result) is True

    def test_bool_conversion_invalid(self):
        """Test that invalid result is falsy."""
        result = ValidationResult(False, ["error"], [])
        assert bool(result) is False

    def test_str_representation_valid(self):
        """Test string representation for valid result."""
        result = ValidationResult(True, [], ["warning"])
        str_repr = str(result)

        assert "valid" in str_repr.lower()
        assert "warning" in str_repr.lower()

    def test_str_representation_invalid(self):
        """Test string representation for invalid result."""
        result = ValidationResult(False, ["error1", "error2"], [])
        str_repr = str(result)

        assert "error" in str_repr.lower()
        assert "error1" in str_repr
        assert "error2" in str_repr
