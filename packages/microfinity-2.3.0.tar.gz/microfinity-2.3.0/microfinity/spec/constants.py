#! /usr/bin/env python3
"""
microfinity.spec.constants - Gridfinity geometry constants.

All values are derived from the spec files (specs/gridfinity_v1.yml).
This module provides the canonical values used throughout microfinity.
"""

from __future__ import annotations

from math import sqrt

from microfinity.spec.loader import GRIDFINITY, MICROFINITY, SPEC

# =============================================================================
# Mathematical Constants
# =============================================================================

SQRT2 = sqrt(2)
EPS = GRIDFINITY.tolerances.epsilon

# =============================================================================
# Hardware Constants (M2, M3 screws)
# =============================================================================

_hw = GRIDFINITY.hardware
M2_DIAM = _hw.m2.diameter
M2_CLR_DIAM = _hw.m2.clearance_diameter
M3_DIAM = _hw.m3.diameter
M3_CLR_DIAM = _hw.m3.clearance_diameter
M3_CB_DIAM = _hw.m3.counterbore_diameter
M3_CB_DEPTH = _hw.m3.counterbore_depth

# =============================================================================
# Grid Constants
# =============================================================================

GRU = GRIDFINITY.pitch  # 42mm - 1 grid unit
GRU2 = GRU / 2  # 21mm - half grid unit
GRHU = GRIDFINITY.height_unit  # 7mm - 1 height unit

# =============================================================================
# Micro-grid Support
# =============================================================================


def micro_pitch(micro_divisions: int = 4) -> float:
    """Returns the micro-pitch for a given division factor.

    Args:
        micro_divisions: Number of divisions per grid unit (1, 2, or 4)

    Returns:
        Pitch in mm (42.0, 21.0, or 10.5)
    """
    return SPEC.micro_pitch(micro_divisions)


# =============================================================================
# Wall and Tolerance Constants
# =============================================================================

GRU_CUT = 42.2  # base extrusion width
GR_WALL = GRIDFINITY.wall_thickness  # nominal exterior wall thickness
GR_DIV_WALL = GRIDFINITY.bin.divider_wall_thickness  # width of dividing walls
GR_TOL = GRIDFINITY.tolerances.nominal  # nominal tolerance (0.5mm)

# =============================================================================
# Base/Foot Constants
# =============================================================================

GR_RAD = GRIDFINITY.baseplate.corner_radius  # nominal exterior filleting radius
GR_BASE_CLR = GRIDFINITY.bin.foot.clearance_above  # clearance above the nominal base height
GR_BASE_HEIGHT = GRIDFINITY.foot_height  # nominal base height

# Foot profile values
_foot = GRIDFINITY.bin.foot.profile
GR_BASE_CHAMF_H = _foot.bottom_chamfer_height / SQRT2
GR_STR_H = _foot.straight_height
GR_BASE_TOP_CHAMF = GR_BASE_HEIGHT - GR_BASE_CHAMF_H - GR_STR_H

# Baseplate extrusion profile
GR_BASE_PROFILE = (
    (GR_BASE_TOP_CHAMF * SQRT2, 45),
    GR_STR_H,
    (GR_BASE_CHAMF_H * SQRT2, 45),
)
GR_STR_BASE_PROFILE = (
    (GR_BASE_TOP_CHAMF * SQRT2, 45),
    GR_STR_H + GR_BASE_CHAMF_H,
)

# =============================================================================
# Box/Bin Constants
# =============================================================================

GR_BOT_H = GRHU  # bin nominal floor height (7mm = 1 height unit)
GR_FILLET = GRIDFINITY.bin.interior_fillet  # inside filleting radius
GR_FLOOR = GR_BOT_H - GR_BASE_HEIGHT  # floor offset

# Box/bin extrusion profile
GR_BOX_CHAMF_H = _foot.bottom_chamfer_height / SQRT2
GR_BOX_TOP_CHAMF = GR_BASE_HEIGHT - GR_BOX_CHAMF_H - GR_STR_H + GR_BASE_CLR

GR_BOX_PROFILE = (
    (GR_BOX_TOP_CHAMF * SQRT2, 45),
    GR_STR_H,
    (GR_BOX_CHAMF_H * SQRT2, 45),
)

# =============================================================================
# Lip Profile Constants
# =============================================================================

_lip = GRIDFINITY.bin.stacking_lip.profile
GR_UNDER_H = _lip.underside_chamfer_height
GR_TOPSIDE_H = _lip.topside_straight_height

GR_LIP_PROFILE = (
    (GR_UNDER_H * SQRT2, 45),
    GR_TOPSIDE_H,
    (_lip.top_chamfer_height * SQRT2, -45),
    _lip.straight_height,
    (_lip.bottom_chamfer_height * SQRT2, -45),
)

# Calculate total lip height
GR_LIP_H = 0.0
for h in GR_LIP_PROFILE:
    if isinstance(h, tuple):
        GR_LIP_H += h[0] / SQRT2
    else:
        GR_LIP_H += h

GR_NO_PROFILE = (GR_LIP_H,)

# =============================================================================
# Hole Constants
# =============================================================================

_holes = GRIDFINITY.holes
GR_HOLE_D = _holes.magnet.diameter
GR_HOLE_H = _holes.magnet.depth
GR_BOLT_D = _holes.screw.diameter
GR_BOLT_H = _holes.screw.depth
GR_HOLE_DIST = _holes.position.spacing / 2
GR_HOLE_SLICE = 0.25  # Support bridge slice height
