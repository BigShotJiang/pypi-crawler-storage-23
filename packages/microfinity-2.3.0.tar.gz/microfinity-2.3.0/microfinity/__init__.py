"""microfinity - A python library to make Gridfinity compatible objects with CadQuery."""

import os
from typing import Any

__project__ = "microfinity"
__version__ = "2.3.0"

VERSION = __project__ + "-" + __version__

script_dir = os.path.dirname(__file__)

# Lazy imports via __getattr__ to avoid requiring CadQuery at package import time.
# This enables: `import microfinity; print(microfinity.__version__)` without CadQuery.
#
# Usage: from microfinity import GridfinityBox  # CadQuery loaded on first use
#
# Heavy CadQuery-dependent modules (cq, parts.*) are only imported when accessed.

__all__ = [
    "__version__",
    "VERSION",
    "GridfinityBaseplateLayout",
    "GridfinityConnectionClip",
    "GridfinityBox",
    "GridfinitySolidBox",
    "GridfinityBaseplate",
    "GridfinityDrawerSpacer",
    "export_test_prints",
    "GridfinityExporter",
    "SVGView",
]


def __getattr__(name: str) -> Any:
    """Lazy-load CadQuery-dependent symbols to avoid import-time dependency."""

    try:
        # CadQuery utilities
        if name in (
            "GridfinityExporter",
            "SVGView",
            "union_all",
            "quarter_circle",
            "chamf_cyl",
            "chamf_rect",
            "ZLEN_FIX",
            "extrude_profile",
        ):
            from microfinity import cq

            return getattr(cq, name)

        # Parts
        if name in ("GridfinityBox", "GridfinitySolidBox"):
            from microfinity.parts import box

            return getattr(box, name)

        if name == "GridfinityObject":
            from microfinity.parts import base

            return getattr(base, name)

        if name == "GridfinityBaseplate":
            from microfinity.parts import baseplate

            return getattr(baseplate, name)

        if name == "GridfinityDrawerSpacer":
            from microfinity.parts import drawer

            return getattr(drawer, name)

        if name in (
            "GridfinityBaseplateLayout",
            "GridfinityConnectionClip",
            "LayoutResult",
            "PieceSpec",
            "SegmentationMode",
            "ToleranceMode",
        ):
            from microfinity.parts import baseplate_layout

            return getattr(baseplate_layout, name)

        # Calibration
        if name in (
            "generate_fractional_pocket_test",
            "generate_fractional_pocket_test_set",
            "generate_clip_clearance_sweep",
            "generate_clip_test_set",
            "export_test_prints",
        ):
            from microfinity.calibration import test_prints

            return getattr(test_prints, name)

        # Spec constants - these are lightweight and always available
        if name in (
            "GRIDFINITY",
            "GRU",
            "GR_TOL",
            "GR_RAD",
            "GR_BASE_HEIGHT",
            "GR_BASE_CLR",
            "GR_BOX_CHAMF_H",
            "GR_STR_H",
            "GR_BOX_PROFILE",
            "SQRT2",
            "NOTCH_WIDTH_MM",
            "NOTCH_DEPTH_MM",
            "NOTCH_HEIGHT_MM",
            "NOTCH_CHAMFER_MM",
            "EdgeMode",
            "EdgeRole",
            "EdgeFrameMode",
            "FillInnerMode",
            "NotchSpec",
        ):
            from microfinity.spec import constants

            return getattr(constants, name)
    except ImportError as e:
        raise AttributeError(f"module {__name__!r} cannot import {name!r} (missing dependency: {e.name})")

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    """List available attributes for tab-completion."""
    return __all__ + ["spec", "parts", "calibration", "cq"]


# Auto-format trigger
