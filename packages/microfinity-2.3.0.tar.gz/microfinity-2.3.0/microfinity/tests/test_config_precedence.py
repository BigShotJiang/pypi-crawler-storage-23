"""
Acceptance tests for config precedence.

These tests verify the Viper-like config precedence:
1. CLI kwargs (highest priority)
2. Environment variables
3. YAML config file
4. Model defaults (lowest priority)

IMPORTANT: These tests must pass before implementing CLI commands.
"""

import os
from pathlib import Path

import pytest

from microfinity.cli.config import LogLevel, MicrofinitySettings, load_settings
from microfinity.cli.config.defaults import BoxDefaults


class TestDefaults:
    """Test that defaults apply when nothing is set."""

    def test_defaults_apply_when_nothing_set(self, tmp_path, monkeypatch):
        """With no yaml/env/cli, defaults are used."""
        # Change to empty directory (no microfinity.yaml)
        monkeypatch.chdir(tmp_path)
        # Clear any env vars
        for key in list(os.environ.keys()):
            if key.startswith("MICROFINITY_"):
                monkeypatch.delenv(key, raising=False)

        settings = MicrofinitySettings()

        assert settings.log_level == LogLevel.INFO
        assert settings.box.micro == 4
        assert settings.box.magnets is True  # Default is True per v2.0.0 spec
        assert settings.box.format.value == "step"
        assert settings.meshcut.auto_overshoot is True  # Default is True

    def test_nested_defaults(self, tmp_path, monkeypatch):
        """Nested defaults are properly initialized."""
        monkeypatch.chdir(tmp_path)

        settings = MicrofinitySettings()

        # All command defaults should be initialized
        assert isinstance(settings.box, BoxDefaults)
        assert settings.box.micro == 4
        assert settings.baseplate.format.value == "step"
        assert settings.meshcut.z_tolerance == 0.1


class TestYamlOverridesDefaults:
    """Test that YAML values override defaults."""

    def test_yaml_overrides_defaults(self, tmp_path, monkeypatch):
        """YAML values override defaults."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("log_level: debug\nbox:\n  micro: 2\n")
        monkeypatch.chdir(tmp_path)

        settings = MicrofinitySettings()

        assert settings.log_level == LogLevel.DEBUG
        assert settings.box.micro == 2

    def test_yaml_partial_override(self, tmp_path, monkeypatch):
        """YAML can override some values while keeping defaults for others."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("box:\n  magnets: false\n")  # Override default True to False
        monkeypatch.chdir(tmp_path)

        settings = MicrofinitySettings()

        # Overridden
        assert settings.box.magnets is False
        # Still defaults
        assert settings.log_level == LogLevel.INFO
        assert settings.box.micro == 4

    def test_yaml_nested_section(self, tmp_path, monkeypatch):
        """YAML nested sections work correctly."""
        config = tmp_path / "microfinity.yaml"
        config.write_text(
            """
log_level: warning
box:
  micro: 2
  format: stl
meshcut:
  auto_overshoot: false
  z_tolerance: 0.05
"""
        )
        monkeypatch.chdir(tmp_path)

        settings = MicrofinitySettings()

        assert settings.log_level == LogLevel.WARNING
        assert settings.box.micro == 2
        assert settings.box.format.value == "stl"
        assert settings.meshcut.auto_overshoot is False  # Overridden from default True
        assert settings.meshcut.z_tolerance == 0.05


class TestEnvOverridesYaml:
    """Test that environment variables override YAML."""

    def test_env_overrides_yaml(self, tmp_path, monkeypatch):
        """Environment variables override YAML."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("log_level: info\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_LOG_LEVEL", "warning")

        settings = MicrofinitySettings()

        assert settings.log_level == LogLevel.WARNING

    def test_env_overrides_yaml_nested(self, tmp_path, monkeypatch):
        """Nested env vars override nested YAML values."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("box:\n  micro: 2\n")
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "1")

        settings = MicrofinitySettings()

        assert settings.box.micro == 1


class TestCliOverridesEnv:
    """Test that CLI kwargs override environment."""

    def test_cli_overrides_env(self, tmp_path, monkeypatch):
        """CLI kwargs override environment."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_LOG_LEVEL", "warning")

        settings = MicrofinitySettings(log_level=LogLevel.ERROR)

        assert settings.log_level == LogLevel.ERROR

    def test_cli_overrides_env_nested(self, tmp_path, monkeypatch):
        """CLI kwargs for nested values override env."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "2")

        settings = MicrofinitySettings(box=BoxDefaults(micro=1))

        assert settings.box.micro == 1


class TestNestedEnvVars:
    """Test that nested environment variables work correctly."""

    def test_nested_env_works(self, tmp_path, monkeypatch):
        """Nested env vars (MICROFINITY_BOX__*) work."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "2")

        settings = MicrofinitySettings()

        assert settings.box.micro == 2

    def test_multiple_nested_env_vars(self, tmp_path, monkeypatch):
        """Multiple nested env vars work together."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "1")
        monkeypatch.setenv("MICROFINITY_BOX__MAGNETS", "false")  # Override default True
        monkeypatch.setenv("MICROFINITY_MESHCUT__AUTO_OVERSHOOT", "false")  # Override default True

        settings = MicrofinitySettings()

        assert settings.box.micro == 1
        assert settings.box.magnets is False
        assert settings.meshcut.auto_overshoot is False


class TestExplicitConfigPath:
    """Test --config PATH / MICROFINITY_CONFIG functionality."""

    def test_explicit_config_path(self, tmp_path, monkeypatch):
        """Explicit config path loads from that path."""
        # Don't use default path
        monkeypatch.chdir(tmp_path)

        # Create config in non-default location
        config = tmp_path / "custom" / "config.yaml"
        config.parent.mkdir()
        config.write_text("log_level: critical\n")

        settings = load_settings(config_path=config)

        assert settings.log_level == LogLevel.CRITICAL

    def test_config_path_via_env(self, tmp_path, monkeypatch):
        """MICROFINITY_CONFIG env var sets config path."""
        monkeypatch.chdir(tmp_path)

        config = tmp_path / "custom.yaml"
        config.write_text("log_level: error\n")
        monkeypatch.setenv("MICROFINITY_CONFIG", str(config))

        settings = load_settings()

        assert settings.log_level == LogLevel.ERROR

    def test_cli_config_path_overrides_env(self, tmp_path, monkeypatch):
        """CLI --config overrides MICROFINITY_CONFIG env var."""
        monkeypatch.chdir(tmp_path)

        env_config = tmp_path / "env.yaml"
        env_config.write_text("log_level: warning\n")

        cli_config = tmp_path / "cli.yaml"
        cli_config.write_text("log_level: error\n")

        monkeypatch.setenv("MICROFINITY_CONFIG", str(env_config))

        settings = load_settings(config_path=cli_config)

        assert settings.log_level == LogLevel.ERROR


class TestUnknownKeys:
    """Test handling of unknown keys in config."""

    def test_unknown_keys_ignored(self, tmp_path, monkeypatch):
        """Unknown keys in YAML don't cause errors."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("log_level: info\nunknown_key: value\nfoo:\n  bar: baz\n")
        monkeypatch.chdir(tmp_path)

        # Should not raise
        settings = MicrofinitySettings()

        assert settings.log_level == LogLevel.INFO


class TestInvalidConfig:
    """Test handling of invalid configuration values."""

    def test_invalid_env_raises_by_default(self, tmp_path, monkeypatch):
        """Invalid env values raise ValidationError by default."""
        from pydantic import ValidationError

        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "abc")

        with pytest.raises(ValidationError):
            MicrofinitySettings()

    def test_invalid_env_with_ignore_flag(self, tmp_path, monkeypatch):
        """Invalid env values use defaults when ignore_invalid=True."""
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("MICROFINITY_BOX__MICRO", "abc")

        settings = load_settings(ignore_invalid=True)

        # Should fall back to defaults
        assert settings.box.micro == 4

    def test_invalid_yaml_raises_by_default(self, tmp_path, monkeypatch):
        """Invalid YAML values raise ValidationError by default."""
        from pydantic import ValidationError

        config = tmp_path / "microfinity.yaml"
        config.write_text("log_level: not_a_valid_level\n")
        monkeypatch.chdir(tmp_path)

        with pytest.raises(ValidationError):
            MicrofinitySettings()


class TestBooleanTriState:
    """Test tri-state boolean override behavior.

    This test verifies that CLI can override YAML booleans in both directions:
    - YAML sets magnetholes=true, CLI --no-magnetholes turns it off
    - YAML sets magnetholes=false, CLI --magnetholes turns it on
    """

    def test_yaml_true_cli_false_override(self, tmp_path, monkeypatch):
        """CLI False can override YAML True for booleans."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("box:\n  magnets: true\n")
        monkeypatch.chdir(tmp_path)

        # Simulate CLI passing explicit False (--no-magnets)
        settings = MicrofinitySettings(box=BoxDefaults(magnets=False))

        assert settings.box.magnets is False

    def test_yaml_false_cli_true_override(self, tmp_path, monkeypatch):
        """CLI True can override YAML False for booleans."""
        config = tmp_path / "microfinity.yaml"
        config.write_text("box:\n  magnets: false\n")
        monkeypatch.chdir(tmp_path)

        # Simulate CLI passing explicit True (--magnets)
        settings = MicrofinitySettings(box=BoxDefaults(magnets=True))

        assert settings.box.magnets is True
