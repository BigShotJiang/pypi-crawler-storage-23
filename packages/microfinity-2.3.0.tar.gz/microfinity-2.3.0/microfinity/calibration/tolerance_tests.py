#!/usr/bin/env python3
"""Tolerance test fixtures for verifying micro-grid accuracy.

This module generates test fixtures for:
- Zero-tolerance baseplate for precise fit verification
- 10.5mm (0.25U) spacing verification jig
- 21mm (0.5U) spacing verification jig
- Graduated fit test set (0.00, 0.05, 0.10, 0.15, 0.20mm tolerances)
"""

from __future__ import annotations

from typing import List, Tuple, TYPE_CHECKING
from pathlib import Path

if TYPE_CHECKING:
    import cadquery as cq


# Delay imports to avoid CadQuery dependency at import time
def _get_cq():
    import cadquery as cq

    return cq


def _get_helpers():
    from cqkit.cq_helpers import rounded_rect_sketch

    return rounded_rect_sketch


def _get_constants():
    from microfinity.spec.constants import GRU, GR_TOL

    return GRU, GR_TOL


def _get_base():
    from microfinity.parts.base import GridfinityObject

    return GridfinityObject


class ToleranceTestBaseplate:
    """Zero-tolerance baseplate for fit verification.

    Creates a baseplate with exact dimensions (no tolerance compensation)
    for testing fit accuracy against nominal 42mm grid.
    """

    def __init__(
        self, length_u: float, width_u: float, tolerance: float = 0.0, **kwargs
    ):
        self.length_u = length_u
        self.width_u = width_u
        self.height_u = 1
        self.test_tolerance = tolerance
        self.micro_divisions = kwargs.get("micro_divisions", 1)
        self.wall_th = kwargs.get("wall_th", 1.0)

        # Get GRU constant
        GRU, _ = _get_constants()
        self._gru = GRU

    @property
    def outer_l(self):
        """Override to apply test tolerance (no standard GR_TOL)."""
        return self.length_u * self._gru - self.test_tolerance

    @property
    def outer_w(self):
        """Override to apply test tolerance (no standard GR_TOL)."""
        return self.width_u * self._gru - self.test_tolerance

    @property
    def outer_rad(self):
        """Corner radius."""
        return 3.75  # Standard Gridfinity corner radius

    @property
    def half_l(self):
        return (self.length_u - 1) * self._gru / 2

    @property
    def half_w(self):
        return (self.width_u - 1) * self._gru / 2

    def render(self):
        """Render a simple flat baseplate with grid markings."""
        cq = _get_cq()
        rounded_rect_sketch = _get_helpers()

        # Create flat base
        base = (
            cq.Workplane("XY")
            .rect(self.outer_l, self.outer_w)
            .extrude(3.0)
            .translate((0, 0, 1.5))
        )

        # Add grid markings at micro-pitch intervals
        if self.micro_divisions > 1:
            micro_pitch = self._gru / self.micro_divisions
            marks = self._render_grid_marks(micro_pitch)
            if marks:
                base = base.union(marks)

        return base

    def _render_grid_marks(self, pitch: float):
        """Render small surface marks at grid intervals."""
        cq = _get_cq()
        marks = None

        # X direction marks
        num_x = int(self.length_u * self.micro_divisions)
        for i in range(num_x + 1):
            x = -self.outer_l / 2 + i * pitch
            mark = (
                cq.Workplane("XY")
                .rect(0.5, self.outer_w)
                .extrude(0.3)
                .translate((x, 0, 3.0))
            )
            marks = mark if marks is None else marks.union(mark)

        # Y direction marks
        num_y = int(self.width_u * self.micro_divisions)
        for i in range(num_y + 1):
            y = -self.outer_w / 2 + i * pitch
            mark = (
                cq.Workplane("XY")
                .rect(self.outer_l, 0.5)
                .extrude(0.3)
                .translate((0, y, 3.0))
            )
            marks = marks.union(mark)

        return marks

    def save_stl_file(self, filename: str, **kwargs) -> str:
        """Save to STL file."""
        from microfinity.cq.export import GridfinityExporter

        obj = self.render()
        return GridfinityExporter.to_stl(obj, filename, **kwargs)

    def save_step_file(self, filename: str) -> str:
        """Save to STEP file."""
        from microfinity.cq.export import GridfinityExporter

        obj = self.render()
        return GridfinityExporter.to_step(obj, filename)


class SpacingTestJig:
    """Test jig for verifying specific pitch spacing.

    Creates a reference block with holes/pins at exact pitch intervals
    for measuring printer accuracy.
    """

    def __init__(self, pitch_mm: float, num_positions: int = 5, **kwargs):
        self.pitch_mm = pitch_mm
        self.num_positions = num_positions
        # Calculate size based on pitch and positions
        GRU, _ = _get_constants()
        total_length = (num_positions - 1) * pitch_mm + 20  # 10mm margin each side
        self.length_u = max(1, total_length / GRU)
        self.width_u = 1
        self.height_u = 1
        self._gru = GRU

    @property
    def outer_l(self):
        return self.length_u * self._gru - 0.5  # Standard tolerance

    @property
    def outer_w(self):
        return 42 - 0.5  # 1U width

    def render(self):
        """Render jig with measurement holes."""
        cq = _get_cq()

        # Base block
        base = (
            cq.Workplane("XY")
            .rect(self.outer_l, 42)
            .extrude(5.0)
            .translate((0, 0, 2.5))
        )

        # Measurement holes
        hole_diam = 3.0
        start_x = -(self.num_positions - 1) * self.pitch_mm / 2

        for i in range(self.num_positions):
            x = start_x + i * self.pitch_mm
            hole = (
                cq.Workplane("XY")
                .circle(hole_diam / 2)
                .extrude(5.5)
                .translate((x, 0, -0.5))
            )
            base = base.cut(hole)

        return base

    def save_stl_file(self, filename: str, **kwargs) -> str:
        """Save to STL file."""
        from microfinity.cq.export import GridfinityExporter

        obj = self.render()
        return GridfinityExporter.to_stl(obj, filename, **kwargs)

    def save_step_file(self, filename: str) -> str:
        """Save to STEP file."""
        from microfinity.cq.export import GridfinityExporter

        obj = self.render()
        return GridfinityExporter.to_step(obj, filename)


class GraduatedFitTestSet:
    """Generate a set of test pieces with graduated tolerances.

    Creates multiple test baseplates with tolerances:
    0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50mm

    Mirrors OrcaSlicer tolerance test pattern (0.0, 0.05, 0.1, 0.2, 0.3, 0.4)
    plus Gridfinity spec 0.5mm total clearance.
    All values are TOTAL clearance (not per-side).
    """

    # Tolerance ladders: total clearance in mm (NOT per-side)
    # All values represent TOTAL dimensional clearance across both sides

    # OrcaSlicer pattern: Fast 6-piece calibration (common slicer workflow)
    ORCA_LADDER = [0.00, 0.05, 0.10, 0.20, 0.30, 0.40]

    # Full ladder: Extended 9-piece including Gridfinity spec 0.50mm
    # 0.50mm total = 0.25mm per-side = matches 41.5mm block on 42mm grid
    FULL_LADDER = [0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50]

    # Default to full ladder for comprehensive calibration
    TOLERANCES = FULL_LADDER

    # Material-specific starting recommendations
    MATERIAL_PRESETS = {
        "pla": {
            "recommended_range": [0.10, 0.20],
            "typical": 0.15,
            "notes": "Minimal shrinkage",
        },
        "petg": {
            "recommended_range": [0.15, 0.25],
            "typical": 0.20,
            "notes": "Moderate shrinkage",
        },
        "abs": {
            "recommended_range": [0.20, 0.35],
            "typical": 0.25,
            "notes": "Higher shrinkage",
        },
        "asa": {
            "recommended_range": [0.20, 0.35],
            "typical": 0.25,
            "notes": "Higher shrinkage",
        },
        "resin": {
            "recommended_range": [0.05, 0.15],
            "typical": 0.10,
            "notes": "Very accurate, minimal shrinkage",
        },
    }

    @classmethod
    def get_ladder(cls, mode: str = "full") -> List[float]:
        """Get tolerance ladder for given mode.

        Args:
            mode: "orca" for OrcaSlicer pattern, "full" for complete set

        Returns:
            List of total clearance values in mm
        """
        if mode == "orca":
            return cls.ORCA_LADDER
        return cls.FULL_LADDER

    @classmethod
    def generate(
        cls,
        length_u: float = 2,
        width_u: float = 2,
        micro_divisions: int = 4,
        output_dir: str = "./tolerance_tests",
        mode: str = "full",
        material: str = None,
    ) -> List[Tuple[str, float, ToleranceTestBaseplate]]:
        """Generate test set.

        Args:
            length_u: Length in U
            width_u: Width in U
            micro_divisions: Micro-divisions (1, 2, 3, or 4)
            output_dir: Output directory
            mode: "orca" for fast 6-piece, "full" for 9-piece
            material: Material type for subset printing (optional)

        Returns:
            List of (filename, tolerance, baseplate) tuples
        """
        results = []

        # Get appropriate ladder
        tolerances = cls.get_ladder(mode)

        # If material specified, optionally filter to recommended range
        if material and material.lower() in cls.MATERIAL_PRESETS:
            preset = cls.MATERIAL_PRESETS[material.lower()]
            rec_range = preset["recommended_range"]
            # Include tolerances within and adjacent to recommended range
            tolerances = [
                t for t in tolerances if rec_range[0] - 0.05 <= t <= rec_range[1] + 0.05
            ]

        for tolerance in tolerances:
            bp = ToleranceTestBaseplate(
                length_u=length_u,
                width_u=width_u,
                tolerance=tolerance,
                micro_divisions=micro_divisions,
            )

            # Filename includes total clearance and per-side equivalent
            per_side = tolerance / 2
            filename = f"tolerance_test_{length_u}x{width_u}U_total_{tolerance:05.2f}mm_per-side_{per_side:05.2f}mm"
            results.append((filename, tolerance, bp))

        return results

    @classmethod
    def export_all(
        cls,
        length_u: float = 2,
        width_u: float = 2,
        micro_divisions: int = 4,
        output_dir: str = "./tolerance_tests",
        format: str = "stl",
        mode: str = "full",
        material: str = None,
    ) -> List[Path]:
        """Generate and export all test pieces.

        Args:
            length_u: Length in U
            width_u: Width in U
            micro_divisions: Micro-divisions
            output_dir: Output directory
            format: Export format (stl or step)
            mode: "orca" or "full"
            material: Material for subset printing

        Returns:
            List of exported file paths
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)

        test_set = cls.generate(
            length_u, width_u, micro_divisions, output_dir, mode, material
        )
        exported = []

        for filename, tolerance, bp in test_set:
            bp.render()

            if format == "stl":
                filepath = output_path / f"{filename}.stl"
                bp.save_stl_file(str(filepath))
            else:
                filepath = output_path / f"{filename}.step"
                bp.save_step_file(str(filepath))

            exported.append(filepath)

        return exported


def analyze_tolerance_results(
    measurements: dict,
    material: str = "pla",
) -> dict:
    """Analyze calibration results and provide recommendations.

    Args:
        measurements: Dict with measured data:
            - best_fit_tolerance: float (total clearance that fit best)
            - measured_pitch_10_5: float (optional, measured 10.5mm pitch)
            - measured_pitch_14_0: float (optional, measured 14.0mm pitch)
            - measured_pitch_21_0: float (optional, measured 21.0mm pitch)
            - elephant_foot_observed: bool (optional)
            - layer_height: float (optional)
            - notes: str (optional)
        material: Material type (pla, petg, abs, asa, resin)

    Returns:
        Dict with analysis and recommendations:
            - recommended_tolerance: float
            - suggested_xy_compensation: float
            - material_preset: dict
            - warnings: list[str]
            - next_steps: list[str]
    """
    results = {
        "recommended_tolerance": None,
        "suggested_xy_compensation": 0.0,
        "material_preset": None,
        "warnings": [],
        "next_steps": [],
    }

    # Get material preset
    material_lower = material.lower()
    if material_lower in GraduatedFitTestSet.MATERIAL_PRESETS:
        results["material_preset"] = GraduatedFitTestSet.MATERIAL_PRESETS[
            material_lower
        ]
    else:
        results["warnings"].append(f"Unknown material '{material}', using PLA defaults")
        results["material_preset"] = GraduatedFitTestSet.MATERIAL_PRESETS["pla"]

    # Analyze best fit tolerance
    best_fit = measurements.get("best_fit_tolerance")
    if best_fit is not None:
        results["recommended_tolerance"] = best_fit

        # Compare to material typical
        typical = results["material_preset"]["typical"]
        if best_fit > typical + 0.15:
            results["warnings"].append(
                f"Best fit tolerance ({best_fit}mm) is much higher than typical for {material} "
                f"({typical}mm). Check for elephant's foot or over-extrusion."
            )
            results["next_steps"].append(
                "Measure first layer width for elephant's foot"
            )
            results["next_steps"].append("Calibrate extrusion multiplier")
        elif best_fit < typical - 0.10:
            results["warnings"].append(
                f"Best fit tolerance ({best_fit}mm) is tighter than typical for {material}. "
                f"Your printer is very accurate or may be under-extruding."
            )

    # Analyze pitch accuracy
    pitch_errors = []
    nominal_pitches = {
        "measured_pitch_10_5": 10.5,
        "measured_pitch_14_0": 14.0,
        "measured_pitch_21_0": 21.0,
    }

    for key, nominal in nominal_pitches.items():
        measured = measurements.get(key)
        if measured is not None:
            error = measured - nominal
            pitch_errors.append(error)
            error_pct = (error / nominal) * 100

            if abs(error) > 0.2:
                results["warnings"].append(
                    f"{nominal}mm pitch error: {error:+.2f}mm ({error_pct:+.1f}%). "
                    f"Consider XY compensation."
                )

    # Calculate suggested XY compensation
    if pitch_errors:
        avg_error = sum(pitch_errors) / len(pitch_errors)
        # Compensation is half the average error (affects both sides)
        results["suggested_xy_compensation"] = -avg_error / 2
        results["next_steps"].append(
            f"Set slicer XY compensation to {results['suggested_xy_compensation']:+.3f}mm"
        )

    # Check for elephant's foot
    if measurements.get("elephant_foot_observed"):
        results["warnings"].append(
            "Elephant's foot detected - this affects first-layer fit"
        )
        results["next_steps"].append(
            "Enable Elephant Foot Compensation in slicer (try 0.2mm)"
        )
        results["next_steps"].append("Or increase first layer Z-offset slightly")

    # Gridfinity spec alignment
    if best_fit is not None:
        if best_fit <= 0.50:
            results["next_steps"].append(
                f"Recommended tolerance ({best_fit}mm) is within Gridfinity spec (0.50mm total)"
            )
        else:
            results["warnings"].append(
                f"Recommended tolerance ({best_fit}mm) exceeds Gridfinity spec (0.50mm). "
                f"Parts may be loose on standard baseplates."
            )

    return results


def export_calibration_report(
    measurements: dict,
    output_path: str,
    material: str = "pla",
) -> str:
    """Export calibration analysis report.

    Args:
        measurements: Measurement data dict (see analyze_tolerance_results)
        output_path: Path to save report
        material: Material type

    Returns:
        Path to saved report file
    """
    analysis = analyze_tolerance_results(measurements, material)

    lines = [
        "# Microfinity Calibration Report",
        "",
        f"Material: {material.upper()}",
        f"Date: {__import__('datetime').datetime.now().isoformat()}",
        "",
        "## Measurements",
        "",
    ]

    # Add measurements
    if "best_fit_tolerance" in measurements:
        lines.append(
            f"- Best fit tolerance: {measurements['best_fit_tolerance']}mm total "
            f"({measurements['best_fit_tolerance'] / 2}mm per-side)"
        )

    for key in ["measured_pitch_10_5", "measured_pitch_14_0", "measured_pitch_21_0"]:
        if key in measurements:
            nominal = {
                "measured_pitch_10_5": 10.5,
                "measured_pitch_14_0": 14.0,
                "measured_pitch_21_0": 21.0,
            }[key]
            measured = measurements[key]
            error = measured - nominal
            lines.append(
                f"- {nominal}mm pitch: {measured}mm measured ({error:+.2f}mm error)"
            )

    if measurements.get("layer_height"):
        lines.append(f"- Layer height: {measurements['layer_height']}mm")

    if measurements.get("elephant_foot_observed"):
        lines.append("- Elephant's foot: Observed")

    if measurements.get("notes"):
        lines.append(f"- Notes: {measurements['notes']}")

    lines.extend(["", "## Recommendations", ""])

    # Add recommendations
    if analysis["recommended_tolerance"] is not None:
        rec = analysis["recommended_tolerance"]
        lines.append(
            f"- **Recommended tolerance: {rec}mm total ({rec / 2}mm per-side)**"
        )

    if analysis["suggested_xy_compensation"] != 0:
        comp = analysis["suggested_xy_compensation"]
        lines.append(f"- **Suggested XY compensation: {comp:+.3f}mm**")

    lines.extend(["", "## Warnings", ""])
    if analysis["warnings"]:
        for warning in analysis["warnings"]:
            lines.append(f"- ⚠️  {warning}")
    else:
        lines.append("- No warnings")

    lines.extend(["", "## Next Steps", ""])
    if analysis["next_steps"]:
        for step in analysis["next_steps"]:
            lines.append(f"- {step}")
    else:
        lines.append("- Your calibration looks good! Print a validation part.")

    lines.extend(
        [
            "",
            "## Configuration",
            "",
            "Add to your `microfinity.yaml`:",
            "",
            "```yaml",
            "box:",
            f"  # Based on calibration with {material.upper()}",
        ]
    )

    if analysis["recommended_tolerance"] is not None:
        lines.append(f"  # Tolerance: {analysis['recommended_tolerance']}mm total")

    lines.extend(["```", ""])

    # Write report
    with open(output_path, "w") as f:
        f.write("\n".join(lines))

    return output_path


def generate_measurement_template(
    material: str = "pla",
    output_path: str = "measurements.yml",
) -> str:
    """Generate a template YAML file for recording measurements.

    Args:
        material: Material type for context
        output_path: Path to save template

    Returns:
        Path to saved template file
    """
    from microfinity.spec.constants import GRU

    template = f"""# Microfinity Calibration Measurements
# Material: {material.upper()}
# Record your measurements after printing tolerance tests

# === TOLERANCE TEST RESULTS ===
# Test which tolerance baseplate fits best
# Options: 0.00, 0.05, 0.10, 0.15, 0.20, 0.25, 0.30, 0.40, 0.50 (all in mm TOTAL clearance)
best_fit_tolerance: 0.00  # Update this with your best fit

# === PITCH ACCURACY ===
# Measure hole-to-hole distance on spacing jigs with calipers
# Nominal values: 10.5mm (0.25U), 14.0mm (0.33U), 21.0mm (0.5U)
measured_pitch_10_5: 10.50  # 0.25U pitch - update after measuring
measured_pitch_14_0: 14.00  # 0.33U (1/3U) pitch - update after measuring
measured_pitch_21_0: 21.00  # 0.5U pitch - update after measuring

# === PRINT SETTINGS ===
# Document what you used for these tests
layer_height: 0.20
line_width: 0.40
elephant_foot_compensation: 0.00  # mm - update if you enabled this
xy_size_compensation: 0.00  # mm - update if you set this in slicer

# === FIRST LAYER CHECK ===
# IMPORTANT: Check this BEFORE interpreting tolerance results
elephant_foot_observed: false  # Set to true if first layer is visibly wider
first_layer_measured: 0.00  # mm - measure first layer width if possible

# === MATERIAL & NOTES ===
material: {material}
printer: "Your printer model"
notes: |
  Add any observations here:
  - First layer quality
  - Fit feel (tight/loose)
  - Any visible artifacts
  - Temperature used
"""

    with open(output_path, "w") as f:
        f.write(template)

    return output_path


def generate_spacing_jig(pitch_mm: float, output_dir: str = "./spacing_jigs") -> Path:
    """Generate a spacing verification jig.

    Args:
        pitch_mm: The pitch to test (e.g., 10.5 for 0.25U, 14.0 for 0.33U, 21.0 for 0.5U)
        output_dir: Directory for output

    Returns:
        Path to exported file
    """
    jig = SpacingTestJig(pitch_mm=pitch_mm)
    jig.render()

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    pitch_name = f"{pitch_mm:04.1f}mm".replace(".", "p")
    filename = f"spacing_jig_{pitch_name}"
    filepath = output_path / f"{filename}.stl"

    jig.save_stl_file(str(filepath))
    return filepath


def export_all_tolerance_tests(output_dir: str = "./tolerance_tests") -> dict:
    """Export complete tolerance test suite.

    Generates:
    - Graduated tolerance test set (0.00-0.50mm total clearance)
    - 10.5mm spacing jig (0.25U)
    - 14.0mm spacing jig (0.33U/1/3U)
    - 21mm spacing jig (0.5U)

    Returns:
        Dict with paths to all generated files
    """
    results = {"tolerance_set": [], "spacing_jigs": []}

    # Graduated tolerance set
    try:
        tolerance_files = GraduatedFitTestSet.export_all(
            length_u=2,
            width_u=2,
            micro_divisions=4,
            output_dir=output_dir,
            format="stl",
        )
        results["tolerance_set"] = tolerance_files
    except Exception:
        pass

    # Spacing jigs
    for pitch in [10.5, 14.0, 21.0]:
        try:
            jig_path = generate_spacing_jig(pitch_mm=pitch, output_dir=output_dir)
            results["spacing_jigs"].append(jig_path)
        except Exception:
            pass

    return results
