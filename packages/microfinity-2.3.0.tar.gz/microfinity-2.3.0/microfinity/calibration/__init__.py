"""Calibration tools for Gridfinity printer fit testing.

This subpackage provides tools for generating test prints to calibrate
your 3D printer settings for optimal Gridfinity fit:

- test_prints: Generate fractional pocket tests and clip clearance sweeps

Note: These modules require CadQuery. Import individually when needed:
    from microfinity.calibration.test_prints import export_test_prints
"""

from typing import Any

__all__ = [
    "export_test_prints",
    "generate_fractional_pocket_test",
    "generate_fractional_pocket_test_set",
    "generate_clip_clearance_sweep",
    "generate_clip_test_set",
    "DEFAULT_CLEARANCE_SWEEP",
    "export_all_tolerance_tests",
    "GraduatedFitTestSet",
    "ToleranceTestBaseplate",
    "SpacingTestJig",
    "analyze_tolerance_results",
    "export_calibration_report",
]


def __getattr__(name: str) -> Any:
    """Lazy-load calibration tools to avoid requiring CadQuery at import time."""

    if name == "export_test_prints":
        from microfinity.calibration import test_prints as tp

        return tp.export_test_prints
    if name == "generate_fractional_pocket_test":
        from microfinity.calibration import test_prints as tp

        return tp.generate_fractional_pocket_test
    if name == "generate_fractional_pocket_test_set":
        from microfinity.calibration import test_prints as tp

        return tp.generate_fractional_pocket_test_set
    if name == "generate_clip_clearance_sweep":
        from microfinity.calibration import test_prints as tp

        return tp.generate_clip_clearance_sweep
    if name == "generate_clip_test_set":
        from microfinity.calibration import test_prints as tp

        return tp.generate_clip_test_set
    if name == "DEFAULT_CLEARANCE_SWEEP":
        from microfinity.calibration import test_prints as tp

        return tp.DEFAULT_CLEARANCE_SWEEP

    if name == "export_all_tolerance_tests":
        from microfinity.calibration import tolerance_tests as tt

        return tt.export_all_tolerance_tests
    if name == "GraduatedFitTestSet":
        from microfinity.calibration import tolerance_tests as tt

        return tt.GraduatedFitTestSet
    if name == "ToleranceTestBaseplate":
        from microfinity.calibration import tolerance_tests as tt

        return tt.ToleranceTestBaseplate
    if name == "SpacingTestJig":
        from microfinity.calibration import tolerance_tests as tt

        return tt.SpacingTestJig
    if name == "analyze_tolerance_results":
        from microfinity.calibration import tolerance_tests as tt

        return tt.analyze_tolerance_results
    if name == "export_calibration_report":
        from microfinity.calibration import tolerance_tests as tt

        return tt.export_calibration_report

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
