# MIDAS2

Implementation of MIDAS in PyTorch. See [Lall and Robinson (2022)](https://doi.org/10.1017/pan.2020.49) for the original paper.

In addition to migrating to `torch`, this new version adds the following functionality:

* Models can be fit on `X` and used to impute on new data `X'`
* Automatic detection of column-types

## Example usage

MIDAS2 follows the sklearn API, with fit and transform methods of an imputer object.

```python
from midas2 import MIDAS

# Create a MIDAS model
mod = MIDAS()

# Fit the model to data
mod.fit(X, epochs = 10)

# Multiply impute missing data
X_imputed = mod.transform(m = 10)
```

## CHANGELOG

* Alpha release including combination rules function (26/06/2025)
* Renamed the main module from 'MIDAS2' to 'model' (19/12/2024)
* Restructured the package for easier install (19/12/2024)
