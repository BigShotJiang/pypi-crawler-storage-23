VERSION = "0.3.1"

import warnings
warnings.filterwarnings("ignore", message="pkg_resources is deprecated")
