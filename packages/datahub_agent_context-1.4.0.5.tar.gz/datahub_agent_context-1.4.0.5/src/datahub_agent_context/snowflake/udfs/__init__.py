"""Snowflake UDF generators for DataHub integration."""
