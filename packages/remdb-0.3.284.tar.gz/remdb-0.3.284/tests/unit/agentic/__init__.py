"""
Unit tests for agentic framework
"""
