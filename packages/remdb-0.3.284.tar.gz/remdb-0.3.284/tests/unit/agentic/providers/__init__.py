"""
Unit tests for agent providers
"""
