"""
Tests for the post-output tool chain feature.

Tests cover:
- _resolve_dot_path: dot-path resolution into nested dicts
- Argument mapping from structured output
- Static args with $input_data references
- PostOutputTool schema model
"""

import pytest
from rem.api.mcp_router.tools import _resolve_dot_path
from rem.agentic.schema import PostOutputTool, AgentSchemaMetadata


# =============================================================================
# _resolve_dot_path tests
# =============================================================================


class TestResolveDotPath:
    def test_simple_key(self):
        data = {"grid_config": {"sections": []}}
        assert _resolve_dot_path(data, "grid_config") == {"sections": []}

    def test_nested_key(self):
        data = {
            "selected_hypothesis": {
                "expected_total_ex_vat": 132790.71
            }
        }
        result = _resolve_dot_path(data, "selected_hypothesis.expected_total_ex_vat")
        assert result == 132790.71

    def test_deeply_nested(self):
        data = {"a": {"b": {"c": {"d": 42}}}}
        assert _resolve_dot_path(data, "a.b.c.d") == 42

    def test_missing_key_raises(self):
        data = {"a": {"b": 1}}
        with pytest.raises(KeyError):
            _resolve_dot_path(data, "a.c")

    def test_missing_nested_key_raises(self):
        data = {"a": {"b": 1}}
        with pytest.raises((KeyError, AttributeError, TypeError)):
            _resolve_dot_path(data, "a.b.c")

    def test_string_value(self):
        data = {"name": "H1"}
        assert _resolve_dot_path(data, "name") == "H1"

    def test_list_value(self):
        data = {"items": [1, 2, 3]}
        assert _resolve_dot_path(data, "items") == [1, 2, 3]

    def test_none_value(self):
        data = {"key": None}
        assert _resolve_dot_path(data, "key") is None


# =============================================================================
# PostOutputTool model tests
# =============================================================================


class TestPostOutputToolModel:
    def test_minimal(self):
        tool = PostOutputTool(tool_name="parse_grid")
        assert tool.tool_name == "parse_grid"
        assert tool.argument_map == {}
        assert tool.static_args == {}

    def test_full_config(self):
        tool = PostOutputTool(
            tool_name="parse_grid",
            argument_map={
                "grid_config": "grid_config",
                "expected_total": "validation_result.expected_total",
            },
            static_args={
                "file_uri": "$input_data.file_uri",
            },
        )
        assert tool.tool_name == "parse_grid"
        assert tool.argument_map["grid_config"] == "grid_config"
        assert tool.static_args["file_uri"] == "$input_data.file_uri"

    def test_model_dump(self):
        tool = PostOutputTool(
            tool_name="parse_blocks",
            argument_map={"extraction_config": "extraction_config"},
        )
        d = tool.model_dump()
        assert d["tool_name"] == "parse_blocks"
        assert d["argument_map"]["extraction_config"] == "extraction_config"
        assert d["static_args"] == {}


class TestAgentSchemaMetadataWithPostTool:
    def test_none_by_default(self):
        meta = AgentSchemaMetadata(name="test-agent")
        assert meta.post_output_tool is None

    def test_with_post_output_tool(self):
        meta = AgentSchemaMetadata(
            name="grid-parser",
            structured_output=True,
            post_output_tool=PostOutputTool(
                tool_name="parse_grid",
                argument_map={"grid_config": "grid_config"},
            ),
        )
        assert meta.post_output_tool is not None
        assert meta.post_output_tool.tool_name == "parse_grid"

    def test_from_dict(self):
        data = {
            "name": "grid-parser",
            "structured_output": True,
            "post_output_tool": {
                "tool_name": "parse_grid",
                "argument_map": {"grid_config": "grid_config"},
                "static_args": {"file_uri": "$input_data.file_uri"},
            },
        }
        meta = AgentSchemaMetadata.model_validate(data)
        assert meta.post_output_tool.tool_name == "parse_grid"
        assert meta.post_output_tool.static_args["file_uri"] == "$input_data.file_uri"

    def test_roundtrip(self):
        meta = AgentSchemaMetadata(
            name="test",
            post_output_tool=PostOutputTool(
                tool_name="parse_grid",
                argument_map={"config": "grid_config"},
                static_args={"uri": "$input_data.file_uri"},
            ),
        )
        d = meta.model_dump(exclude_none=True)
        meta2 = AgentSchemaMetadata.model_validate(d)
        assert meta2.post_output_tool.tool_name == "parse_grid"
        assert meta2.post_output_tool.argument_map == {"config": "grid_config"}


# =============================================================================
# Argument building integration tests
# =============================================================================


class TestArgumentBuilding:
    """Test the argument-building logic used by _execute_post_output_tool."""

    def test_argument_map_resolution(self):
        """Simulate argument_map resolution from structured output."""
        structured_output = {
            "grid_config": {"sections": [{"name": "Detail"}]},
            "validation_result": {"expected_total": 132790.71},
            "selected_hypothesis": "H1",
        }
        argument_map = {
            "grid_config": "grid_config",
            "expected_total": "validation_result.expected_total",
        }

        kwargs = {}
        for tool_kwarg, output_path in argument_map.items():
            kwargs[tool_kwarg] = _resolve_dot_path(structured_output, output_path)

        assert kwargs["grid_config"] == {"sections": [{"name": "Detail"}]}
        assert kwargs["expected_total"] == 132790.71

    def test_static_args_input_data_resolution(self):
        """Simulate $input_data.x resolution."""
        input_data = {
            "file_uri": "/path/to/invoice.txt",
            "options": {"format": "european"},
        }
        static_args = {
            "file_uri": "$input_data.file_uri",
            "format": "$input_data.options.format",
            "debug": "true",
        }

        kwargs = {}
        for tool_kwarg, value in static_args.items():
            if isinstance(value, str) and value.startswith("$input_data."):
                key = value[len("$input_data."):]
                kwargs[tool_kwarg] = _resolve_dot_path(input_data, key)
            else:
                kwargs[tool_kwarg] = value

        assert kwargs["file_uri"] == "/path/to/invoice.txt"
        assert kwargs["format"] == "european"
        assert kwargs["debug"] == "true"
