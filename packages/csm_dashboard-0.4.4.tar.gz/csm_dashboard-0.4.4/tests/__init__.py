"""Tests for CSM Dashboard."""
