# 4sgm

4SGM is a packaged project workspace with Python-based tooling, orchestration assets, and documentation delivery.

## Capabilities

- Python package layout (`pyproject.toml`)
- Task-driven automation (`Taskfile.yml`)
- Docs site and references under `docs/`
- GitHub workflows for QA/coverage/pages

## Quick Start

1. Create virtual environment and install dependencies.
2. Run `task quality`.
3. Run tests and coverage.
4. Build docs site.

## Project Structure

- `4sgm/` core package
- `docs/` documentation and governance
- `scripts/` helper tooling
- `.github/workflows/` CI automation

## Packaging

- Build metadata in `pyproject.toml`
- Lockfile in `uv.lock`

## Governance

- Spec and tracker files are maintained for traceable planning.
