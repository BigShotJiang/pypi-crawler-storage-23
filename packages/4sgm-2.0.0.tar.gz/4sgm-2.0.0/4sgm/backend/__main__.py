"""
4SGM CLI entry point
Run with: python -m backend [command]
"""

from cli_main import app

if __name__ == "__main__":
    app()
