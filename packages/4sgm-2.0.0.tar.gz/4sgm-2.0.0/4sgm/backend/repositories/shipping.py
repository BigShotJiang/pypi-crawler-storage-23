"""Shipping repository module.

Exports ShippingRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import ShippingRepository

__all__ = ["ShippingRepository"]
