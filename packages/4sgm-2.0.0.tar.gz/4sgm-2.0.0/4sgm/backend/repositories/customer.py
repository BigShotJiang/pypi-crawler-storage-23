"""Customer repository module.

Exports CustomerRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import CustomerRepository

__all__ = ["CustomerRepository"]
