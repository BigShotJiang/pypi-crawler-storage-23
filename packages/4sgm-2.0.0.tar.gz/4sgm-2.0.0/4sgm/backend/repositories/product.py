"""Product repository module.

Exports ProductRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import ProductRepository

__all__ = ["ProductRepository"]
