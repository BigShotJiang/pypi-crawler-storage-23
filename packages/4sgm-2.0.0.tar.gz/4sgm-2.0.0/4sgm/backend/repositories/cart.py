"""Cart repository module.

Exports CartRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import CartRepository

__all__ = ["CartRepository"]
