"""Order repository module.

Exports OrderRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import OrderRepository

__all__ = ["OrderRepository"]
