"""RFQ repository module.

Exports RFQRepository protocol and provides factory functions
for creating repository instances.
"""

from .base import RFQRepository

__all__ = ["RFQRepository"]
