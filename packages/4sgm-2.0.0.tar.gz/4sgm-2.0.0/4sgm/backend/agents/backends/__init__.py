"""Backend storage configurations for agent state management."""

from .composite import get_composite_backend

__all__ = ["get_composite_backend"]
