"""4SGM Agent factory and utilities for hybrid DeepAgent architecture."""

from .deep_agent import create_4sgm_agent

__all__ = ["create_4sgm_agent"]
