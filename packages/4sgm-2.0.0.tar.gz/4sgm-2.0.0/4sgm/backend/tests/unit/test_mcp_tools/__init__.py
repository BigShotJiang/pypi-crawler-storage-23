"""MCP tools integration tests."""
