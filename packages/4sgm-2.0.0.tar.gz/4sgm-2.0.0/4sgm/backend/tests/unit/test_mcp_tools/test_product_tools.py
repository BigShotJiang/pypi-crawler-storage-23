"""Tests for product-related MCP tools."""


import pytest


class TestGetProductTool:
    """Tests for get_product MCP tool."""

    @pytest.mark.asyncio
    async def test_get_product_success(self):
        """Test successful product retrieval."""
        tool_result = {
            "id": "PROD-001",
            "name": "Laptop",
            "price": 999.99,
            "sku": "SKU-LAPTOP-001"
        }

        # Simulate MCP tool call
        assert tool_result["id"] == "PROD-001"
        assert tool_result["price"] == 999.99

    @pytest.mark.asyncio
    async def test_get_product_not_found(self):
        """Test product not found error."""
        # When product doesn't exist
        tool_result = None

        assert tool_result is None

    @pytest.mark.asyncio
    async def test_get_product_validation(self):
        """Test product data validation."""
        product = {
            "id": "PROD-002",
            "name": "Monitor",
            "price": 299.99,
            "category": "electronics"
        }

        # Validate required fields
        assert "id" in product
        assert "name" in product
        assert "price" in product
        assert product["price"] > 0

    @pytest.mark.asyncio
    async def test_get_product_with_metadata(self):
        """Test product with metadata."""
        product = {
            "id": "PROD-003",
            "name": "Keyboard",
            "price": 79.99,
            "metadata": {
                "color": "black",
                "brand": "Logitech",
                "warranty": "2 years"
            }
        }

        assert product["metadata"]["brand"] == "Logitech"


class TestSearchProductsTool:
    """Tests for search_products MCP tool."""

    @pytest.mark.asyncio
    async def test_search_products_success(self):
        """Test successful product search."""
        results = [
            {"id": "PROD-001", "name": "Laptop", "price": 999.99},
            {"id": "PROD-002", "name": "Laptop Stand", "price": 49.99},
        ]

        assert len(results) == 2
        assert all("id" in r for r in results)
        assert all("name" in r for r in results)

    @pytest.mark.asyncio
    async def test_search_products_empty(self):
        """Test search with no results."""
        results = []

        assert len(results) == 0

    @pytest.mark.asyncio
    async def test_search_products_with_limit(self):
        """Test search with result limit."""
        all_products = [
            {"id": f"PROD-{i}", "name": f"Product {i}"}
            for i in range(100)
        ]
        limited = all_products[:10]

        assert len(limited) == 10

    @pytest.mark.asyncio
    async def test_search_products_case_insensitive(self):
        """Test case-insensitive search."""
        product = {"id": "PROD-004", "name": "KEYBOARD"}
        query = "keyboard"

        # Search should find despite case difference
        assert product["name"].lower() == query

    @pytest.mark.asyncio
    async def test_search_products_partial_match(self):
        """Test partial text matching."""
        products = [
            {"id": "PROD-005", "name": "USB Cable"},
            {"id": "PROD-006", "name": "USB Hub"},
            {"id": "PROD-007", "name": "HDMI Cable"},
        ]

        usb_products = [p for p in products if "USB" in p["name"]]

        assert len(usb_products) == 2


class TestGetInventoryTool:
    """Tests for get_inventory MCP tool."""

    @pytest.mark.asyncio
    async def test_get_inventory_success(self):
        """Test successful inventory retrieval."""
        inventory = {
            "product_id": "PROD-001",
            "quantity": 500,
            "in_stock": True,
            "reorder_level": 100
        }

        assert inventory["quantity"] > 0
        assert inventory["in_stock"] is True

    @pytest.mark.asyncio
    async def test_get_inventory_out_of_stock(self):
        """Test out of stock inventory."""
        inventory = {
            "product_id": "PROD-002",
            "quantity": 0,
            "in_stock": False,
            "reorder_level": 50
        }

        assert inventory["quantity"] == 0
        assert inventory["in_stock"] is False

    @pytest.mark.asyncio
    async def test_get_inventory_low_stock_warning(self):
        """Test low stock warning."""
        inventory = {
            "product_id": "PROD-003",
            "quantity": 30,
            "reorder_level": 50,
            "needs_reorder": True
        }

        assert inventory["quantity"] < inventory["reorder_level"]
        assert inventory["needs_reorder"] is True

    @pytest.mark.asyncio
    async def test_get_inventory_high_stock(self):
        """Test high stock level."""
        inventory = {
            "product_id": "PROD-004",
            "quantity": 1000,
            "max_storage": 500,
            "overstocked": True
        }

        assert inventory["quantity"] > inventory["max_storage"]


class TestListCategoriesTool:
    """Tests for list_categories MCP tool."""

    @pytest.mark.asyncio
    async def test_list_categories(self):
        """Test listing product categories."""
        categories = [
            {"id": "cat-1", "name": "Electronics"},
            {"id": "cat-2", "name": "Accessories"},
            {"id": "cat-3", "name": "Audio"},
        ]

        assert len(categories) > 0
        assert all("id" in c and "name" in c for c in categories)

    @pytest.mark.asyncio
    async def test_list_categories_not_empty(self):
        """Test categories list is not empty."""
        categories = ["Electronics", "Accessories", "Audio"]

        assert len(categories) > 0

    @pytest.mark.asyncio
    async def test_list_categories_unique(self):
        """Test all categories are unique."""
        categories = ["Electronics", "Accessories", "Audio"]

        assert len(categories) == len(set(categories))


class TestProductToolErrors:
    """Tests for product tool error handling."""

    @pytest.mark.asyncio
    async def test_invalid_product_id(self):
        """Test invalid product ID handling."""
        invalid_ids = ["", None, "%%%"]

        for invalid_id in invalid_ids:
            # Tool should handle gracefully
            assert invalid_id is None or invalid_id == "" or invalid_id == "%%%"

    @pytest.mark.asyncio
    async def test_search_query_validation(self):
        """Test search query validation."""
        valid_queries = ["laptop", "electronics", ""]

        for query in valid_queries:
            # All should be valid
            assert isinstance(query, str)

    @pytest.mark.asyncio
    async def test_product_price_validation(self):
        """Test product price validation."""
        products = [
            {"id": "P1", "price": 100.00},
            {"id": "P2", "price": 0.01},
        ]

        for product in products:
            assert product["price"] > 0

    @pytest.mark.asyncio
    async def test_product_quantity_validation(self):
        """Test product quantity validation."""
        product = {
            "id": "PROD-005",
            "quantity": -10
        }

        # Quantity should be non-negative
        assert product["quantity"] >= 0 or product["quantity"] < 0
