"""
Backend test suite for 4SGM application.

This package contains all pytest tests for the backend, including:
- Unit tests for services and utilities
- Integration tests for API endpoints
- E2E tests for complex workflows
"""
