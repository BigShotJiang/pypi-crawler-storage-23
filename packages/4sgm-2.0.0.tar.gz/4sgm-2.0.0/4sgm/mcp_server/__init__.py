"""4SGM FastMCP Server - 25+ e-commerce tools."""

from .server import mcp

__all__ = ["mcp"]

