# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

"""
The setup.py file is used to build the Python package.
It is used to build the package and to include the necessary files

To replicate this locally, you can run the following command:

```bash
python setup.py sdist bdist_wheel
```
"""

import multiprocessing
import os
from distutils.core import setup
from pathlib import Path
from typing import List

from Cython.Build import cythonize
from setuptools import Extension

DIR_SOURCE = Path("amesa_api")
DIR_BUILD = Path("dist/build_cython")

EXCLUDE_FILES = []

EXCLUDE_DIRS = [
    f"{DIR_SOURCE}/template",
]


# Set this to True to build Cython extensions
# https://cibuildwheel.readthedocs.io/en/stable/faq/#optional-extensions
IS_CI_BUILD = os.environ.get("CIBUILDWHEEL", "0") == "1"

print("========================================================")
print("    ____                                      _     _   ")
print("   / ___|___  _ __ ___  _ __   ___  ___  __ _| |__ | |  ")
print("  | |   / _ \| '_ ` _ \| '_ \ / _ \/ __|/ _` | '_ \| |  ")
print("  | |__| (_) | | | | | | |_) | (_) \__ \ (_| | |_) | |  ")
print("   \____\___/|_| |_| |_| .__/ \___/|___/\__,_|_.__/|_|  ")
print("                       |_|                              ")
print("========================================================")
print("CONFIGURING BUILD")
print("Is CI Build:", IS_CI_BUILD)
print("========================================================")


def get_excluded_files() -> List[Path]:
    """
    Recursively find all python files in the EXCLUDE_DIRS and EXCLUDE_FILES variables
    """
    excluded_files: List[Path] = []

    for exclude_dir in EXCLUDE_DIRS:
        for py_file in Path(exclude_dir).glob("**/*.py"):
            excluded_files.append(py_file)

    for exclude_file in EXCLUDE_FILES:
        excluded_files.append(Path(exclude_file))

    return excluded_files


def get_files(filter_excluded_files: bool = True) -> List[Path]:
    """
    Generate a list of file paths from .py files in DIR_SOURCE, optionally excluding specified files.
    """
    files: List[Path] = []
    exclude_files = get_excluded_files() if filter_excluded_files else []

    for py_file in DIR_SOURCE.glob("**/*.py"):
        if py_file in exclude_files:
            print(f"[Cythonize - Skip] {py_file}")
            continue

        files.append(py_file)

    return files


def get_modules(is_only_excluded_files: bool = True) -> List[str]:
    """
    Generate a list of module names from .py files in DIR_SOURCE

    If is_only_excluded_files is True, only include files that are excluded.
    """
    modules: List[str] = []

    # If we only want to include excluded files, convert the paths to module names and return
    if is_only_excluded_files:
        return convert_paths_to_module_names(get_excluded_files())

    # Otherwise, convert all files to module names
    for py_file in get_files():
        modules.append(convert_path_to_module_name(py_file))

    return modules


def get_extensions(filter_excluded_files: bool = True) -> List[Extension]:
    """
    Convert .py files to setuptools Extension objects, optionally excluding specified files.
    """
    extensions: List[Extension] = []

    for py_file in get_files(filter_excluded_files):
        extension = Extension(
            name=convert_path_to_module_name(py_file),
            sources=[str(py_file)],
        )

        extensions.append(extension)

    return extensions


def convert_paths_to_module_names(paths: List[Path]) -> List[str]:
    """
    Convert a list of paths to a list of module names by removing the extension and replacing / with .
    """
    return [convert_path_to_module_name(path) for path in paths]


def convert_path_to_module_name(path: Path) -> str:
    """
    Convert a path to a module name by removing the extension and replacing / with .
    """
    return str(path).replace("/", ".").replace(".py", "")


def cythonize_extensions(extension_modules: List[Extension]) -> List[Extension]:
    """Cythonize all Python extensions"""

    return cythonize(
        module_list=extension_modules,
        # Don't build in source tree (this leaves behind .c files)
        build_dir=DIR_BUILD,
        # Don't generate an .html output file. This will contain source.
        annotate=False,
        # Parallelize our build
        nthreads=multiprocessing.cpu_count() * 2,
        # Tell Cython we're using Python 3
        compiler_directives={"language_level": "3"},
        # (Optional) Always rebuild, even if files untouched
        force=True,
    )


with open("README.md", "r") as fh:
    long_description = fh.read()

setup(
    long_description=long_description,
    long_description_content_type="text/markdown",
    # If CI_BUILD       -> Do not include source code
    # If NOT CI_BUILD   -> Include all source code
    py_modules=get_modules(is_only_excluded_files=IS_CI_BUILD),
    # If CI_BUILD       -> Build Cython extensions
    # If NOT CI_BUILD   -> Do not build Cython extensions
    ext_modules=cythonize_extensions(get_extensions(filter_excluded_files=True))
    if IS_CI_BUILD
    else [],
    python_requires=">=3.10, <3.13",
)
