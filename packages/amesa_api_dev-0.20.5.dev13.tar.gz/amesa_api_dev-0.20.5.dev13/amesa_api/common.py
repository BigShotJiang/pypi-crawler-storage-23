# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential
from typing import Union

import aiohttp
import json
import os
import ssl


def get_ssl_connector():
    ssl_cert_file = os.getenv("SSL_CERT_FILE")
    ssl_cert_path = os.getenv("SSL_CERT_PATH")
    ssl_ctx = ssl.create_default_context(
        ssl.Purpose.SERVER_AUTH, cafile=ssl_cert_file, capath=ssl_cert_path
    )
    return aiohttp.TCPConnector(ssl_context=ssl_ctx)


class APIBase:
    def __init__(self, base_url):
        self.base_url = base_url
        self.token = None

    def _get_headers(self):
        headers = {"Content-Type": "application/json", "Accept": "application/json"}

        if self.token is not None:
            headers["Authorization"] = f"Bearer {self.token}"

        return headers

    async def get(self, path: str, headers={}):
        """
        Make a GET request to the API
        """
        headers_base = self._get_headers()
        headers_base.update(headers)
        connector = get_ssl_connector()
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.get(
                self.base_url + path, headers=headers_base
            ) as response:
                return await self._process_response(response)

    async def post(self, path: str, data: Union[dict, str], headers={}):
        """
        Make a POST request to the API
        """
        headers_base = self._get_headers()
        headers_base.update(headers)

        if isinstance(data, dict):
            data = json.dumps(data)
        else:
            del headers_base["Content-Type"]

        connector = get_ssl_connector()
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.post(
                self.base_url + path, headers=headers_base, data=data
            ) as response:
                return await self._process_response(response)

    async def put(self, path: str, data: Union[dict, str], headers={}):
        """
        Make a PUT request to the API
        """
        headers_base = self._get_headers()
        headers_base.update(headers)

        if isinstance(data, dict):
            data = json.dumps(data)
        else:
            del headers_base["Content-Type"]

        connector = get_ssl_connector()
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.put(
                self.base_url + path, headers=headers_base, data=data
            ) as response:
                return await self._process_response(response)

    async def delete(self, path: str, headers={}):
        """
        Make a DELETE request to the API
        """
        headers_base = self._get_headers()
        headers_base.update(headers)

        connector = get_ssl_connector()
        async with aiohttp.ClientSession(connector=connector) as session:
            async with session.delete(
                self.base_url + path, headers=headers_base
            ) as response:
                return await self._process_response(response)

    async def _process_response(self, response):
        """
        Process the response from the API
        """
        if response.status >= 200 and response.status < 202:
            try:
                return await response.json()
            except Exception:
                return await response.text()
        elif response.status >= 202 and response.status < 300:
            return None
        else:
            try:
                res_json = await response.json()
                raise Exception(f"Error: {response.status} - {res_json['message']}")
            except Exception:
                txt = await response.text()
                raise Exception(f"Error: {response.status} - {txt}")
