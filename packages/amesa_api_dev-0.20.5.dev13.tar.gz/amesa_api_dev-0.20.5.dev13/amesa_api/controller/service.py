# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import asyncio
import threading
import time
from os import getenv

import amesa_api.util.logger as logger_util
from amesa_api.controller.job_status_enum import JobStatusEnum
from amesa_api.controller.main import APIController

logger = logger_util.get_logger(__name__)


class ControllerService:
    _instance = None
    heartbeat_thread = None
    healthy = True
    job_id: str = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)

        return cls._instance

    def __init__(self, url=None):
        if url is None:
            controller_url = getenv("AMESA_CONTROLLER_URL", None)
        else:
            controller_url = url

        if controller_url is None:
            raise Exception("AMESA_CONTROLLER_URL could not be read!")

        self.client = APIController(controller_url)

    def set_job_id(self, job_id):
        self.job_id = job_id

    async def start_heartbeat_thread(self):
        try:
            await self.client.sdk.heartbeat(self.job_id)
        except Exception as e:
            logger.error(f"Failed to connect to controller: {e}")
            return

        self.heartbeat_thread = run_async_in_daemon_thread(self.send_heartbeat)

    def mark_unhealthy(self):
        self.healthy = False

    async def send_heartbeat(self):
        while self.healthy:
            try:
                await self.client.sdk.heartbeat(self.job_id)
            except Exception as e:
                logger.error(f"Failed to send heartbeat to controller: {e}")

            time.sleep(10)

        logger.info(
            "ControllerService heartbeat task stopped because the job is marked as unhealthy"
        )

    async def send_status(self, status: JobStatusEnum):
        await self.client.sdk.status(status, self.job_id)


def run_async_in_daemon_thread(fn, *args, **kwargs):
    """
    Runs an asynchronous function in a separate daemon thread, and waits for it to complete.
    Returns the result of the asynchronous function.
    """

    def run(loop):
        asyncio.set_event_loop(loop)

        loop.run_until_complete(fn(*args, **kwargs))

    loop = asyncio.new_event_loop()
    t = threading.Thread(target=run, args=(loop,), daemon=True)
    t.start()

    return t
