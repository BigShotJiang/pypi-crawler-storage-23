# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from amesa_api.common import APIBase
from amesa_api.controller.job_status_enum import JobStatusEnum


class APIController(APIBase):
    def __init__(self, base_url):
        super().__init__(base_url)

        self.admin = APIControllerAdmin(self)
        self.sdk = APIControllerSdk(self)
        self.direct_mode = APIControllerDirectMode(self)


class APIControllerDirectMode:
    def __init__(self, api):
        self.api: APIController = api

    async def submit(self, job_id: str, serialized_trainer: str):
        body = {"id": job_id, "json": serialized_trainer}

        await self.api.post("/jobs", body)


class APIControllerAdmin:
    def __init__(self, api):
        self.api: APIController = api

    async def list_jobs(self):
        return await self.api.get("/api/admin/v1/jobs")

    async def get_job(self, job_id: str):
        return await self.api.get(f"/api/admin/v1/jobs/{job_id}")

    async def cancel_job(self, job_id: str):
        return await self.api.delete(f"/api/admin/v1/jobs/{job_id}")


class APIControllerSdk:
    def __init__(self, api):
        self.api: APIController = api

    async def heartbeat(self, job_id: str):
        body = {
            "health": "ok",
        }

        res = await self.api.post(f"/api/sdk/v1/jobs/{job_id}/heartbeat", body)

        return res

    async def status(self, status: JobStatusEnum, job_id: str):
        status = {"status": status}

        res = await self.api.post(f"/api/sdk/v1/jobs/{job_id}/status", status)

        return res
