# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

from threading import Lock


class SingletonMeta(type):
    """
    This is a thread-safe implementation of Singleton.

    Normally, if the program is launched and there is no Singleton instance yet,
    multiple threads can simultaneously pass the previous conditional and reach
    the lock block almost at the same time. The first of them will acquire lock
    and will proceed further, while the rest will wait here.

    Once the first thread leaves the lock block, the next thread will acquire
    and check the condition again to make sure that the Singleton hasn't been
    created yet. Now, since the Singleton field is already initialized, the
    thread won't create a new object.
    """

    # We store the instance reference as a class attribute and return it on
    _instances = {}

    # create a lock to synchronize threads during first access to the Singleton
    _lock: Lock = Lock()

    def __call__(cls, *args, **kwargs):
        """
        Possible changes to the value of the `__init__` argument do not affect
        the returned instance.

        :param args:
        :param kwargs:

        :return: Singleton instance
        """
        with cls._lock:
            if cls not in cls._instances:
                instance = super().__call__(*args, **kwargs)
                cls._instances[cls] = instance

        return cls._instances[cls]

    @classmethod
    def remove_instance(cls, target_cls):
        """
        Remove the instance of the target class from the Singleton

        :param target_cls: class
        """
        with cls._lock:
            if target_cls in cls._instances:
                del cls._instances[target_cls]
