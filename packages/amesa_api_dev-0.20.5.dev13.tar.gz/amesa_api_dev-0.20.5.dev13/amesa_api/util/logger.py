# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import logging
import os
from logging.config import dictConfig

from amesa_api.util.singleton import SingletonMeta


def get_level():
    env_var = os.environ.get("LOGLEVEL", None)

    if env_var is not None:
        return logging.getLevelName(env_var.upper())

    return logging.INFO


def get_log_format():
    return "%(message)s"


dictConfig(
    {
        "version": 1,
        "formatters": {
            "default": {
                "format": get_log_format(),
                "datefmt": "%Y-%m-%d %H:%M:%S",
            },
            "plain": {"format": "%(message)s"},
        },
        # Do NOT disable existing loggers as they will cancel each other out else
        "disable_existing_loggers": False,
        "handlers": {"console": {"class": "logging.StreamHandler"}},
        "root": {"level": get_level(), "handlers": ["console"], "formatter": "default"},
        "loggers": {
            "kubectl": {
                "level": "INFO",
                "handlers": ["console"],
                "propagate": False,
                "formatter": "plain",
            }
        },
    }
)


def get_logger(name) -> logging.Logger:
    mgr_api = LogMgrAPI()
    return mgr_api.get_logger(name)


class LogMgrAPI(metaclass=SingletonMeta):
    def __init__(self):
        self.loggers = {}

    def get_logger(self, name) -> logging.Logger:
        if name not in self.loggers:
            self.loggers[name] = logging.getLogger(name)

        return self.loggers[name]
