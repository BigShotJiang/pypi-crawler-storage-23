# Copyright (C) Amesa, Inc - All Rights Reserved
# Unauthorized copying of this file, via any medium is strictly prohibited
# Proprietary and confidential

import os

import cython


def get_token_path():
    """
    Gets the token path to read from
    """
    dir_home = os.path.expanduser("~")
    os.makedirs(f"{dir_home}/.amesa", exist_ok=True)

    # Check if MODE is set
    mode = os.getenv("AMESA_ENV", "prod" if cython.compiled else "stg")

    if mode == "prod":
        return f"{dir_home}/.amesa/token"
    else:
        mode_str = ""

        if mode == "stg" or mode == "1":
            mode_str = "stg"
        elif mode == "test" or mode == "0":
            mode_str = "dev"
        else:
            mode_str = ""

        return f"{dir_home}/.amesa/token_{mode_str}"
