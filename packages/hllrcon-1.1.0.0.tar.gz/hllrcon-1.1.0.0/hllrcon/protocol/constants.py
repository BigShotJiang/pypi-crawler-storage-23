from typing import Final

REQUEST_HEADER_FORMAT: Final[str] = "<II"
RESPONSE_HEADER_FORMAT: Final[str] = "<II"
