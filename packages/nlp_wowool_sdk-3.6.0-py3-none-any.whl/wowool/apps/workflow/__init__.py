# flake8: noqa: F401
from wowool.workflow.action import *
from wowool.workflow.rule import *
from wowool.workflow.variable import *
from wowool.workflow.workflow import Workflow
from wowool.workflow.app_id import APP_ID

App = Workflow
