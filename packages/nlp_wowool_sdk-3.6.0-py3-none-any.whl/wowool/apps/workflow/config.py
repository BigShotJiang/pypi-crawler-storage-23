CONFIG = {
    "short_description": "The Workflow application enables you to automate your pipelines.",
    "long_description": "The Workflow application enables you to automate your pipelines by triggering actions when certain conditions are met.",
}
