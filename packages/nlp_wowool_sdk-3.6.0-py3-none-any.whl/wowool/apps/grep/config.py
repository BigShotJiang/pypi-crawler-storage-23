CONFIG = {
    "short_description": "The Grep application performs a semantical search in your documents using a Wowool expression.",
    "long_description": "The Grep application can be used to semantically search your documents using a Wowool expression. This means that you can grep for a concept like Person if you have added a domain that contains this concept.",  # noqa: E501
}
