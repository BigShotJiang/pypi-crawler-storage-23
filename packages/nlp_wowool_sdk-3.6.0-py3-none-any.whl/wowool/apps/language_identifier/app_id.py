APP_ID = "wowool_language_identifier"
