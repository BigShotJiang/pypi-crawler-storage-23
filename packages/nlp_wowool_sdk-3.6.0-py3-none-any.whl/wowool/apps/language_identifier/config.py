CONFIG = {
    "name": "Language Identifier",
    "short_description": "The Language Identifier application identifies the language of your documents.",
    "long_description": "The Language Identifier application identifies the language of your documents or the different language sections in your document.",
    "aliases": ["lid"],
}
