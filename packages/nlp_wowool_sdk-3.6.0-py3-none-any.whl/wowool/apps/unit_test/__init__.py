APP_ID = "wowool_unit_test"


class UnitTest: ...  # noqa: E701
