from importlib import import_module
from typing import List
from logging import getLogger

logger = getLogger(__name__)

MODULE_NAMES = ["wowool.workflow.action"]


class UnknownActionError(RuntimeError):
    def __init__(self, name: str):
        super(UnknownActionError, self).__init__()
        self.name = name


class ActionFactory:
    def __init__(self, module_names_extra: List[str] = []):
        super(ActionFactory, self).__init__()
        module_names = module_names_extra
        module_names.extend(MODULE_NAMES)
        self._modules = list(map(import_module, module_names))

    def _load_action_class(self, name: str):
        for module in self._modules:
            try:
                Action = getattr(module, name)
                return Action
            except AttributeError:
                pass
        raise UnknownActionError(name=name)

    def __call__(self, name: str, config: dict):
        Action = self._load_action_class(name)
        return Action(config_template=config)
