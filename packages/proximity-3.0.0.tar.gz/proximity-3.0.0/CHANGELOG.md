# Changelog

## 3.0.0

### Other changes

- Relax NumPy constraint now that NumPy 2 is supported

## 3.0.0a1

### BREAKING CHANGES

- Require Python 3.10+

### New features

- Support NumPy 2 (NumPy 1 is still supported)

### Bug fixes

- Types: Fix one of the overloads.

### Other changes

- Update vendored-in code from Trimesh to support NumPy 2

## 3.0.0a0

### BREAKING CHANGES

- Require Python 3.9+ (with NumPy <2)

### New features

- Provide type annotations.

### Other changes

- Bump rtree to 1.4.1.

## 2.0.1

- Support NumPy 1.24+

## 2.0.0

- Require polliwog 3.0.0 prerelease or higher, and update rtree.


## 1.1.1

- Support polliwog 3.0.0 prereleases.


## 1.1.0

- Upgrade polliwog dependency.


## 1.0.0

- Upgrade polliwog and vg dependencies.


## 0.4.0

- Upgrade polliwog and vg dependencies.


## 0.3.0

- Upgrade polliwog dependency.


## 0.3.0b0

Same as 0.2.0b0.


## 0.2.0b0

- Bump rtree to 0.9.7, which now ships wheels with libspatialindex
  preinstalled. It's no longer necessary to separately install libspatialindex.


## 0.2.0

- Bump polliwog to 1.0.0b10.


## 0.1.0

Initial release.
