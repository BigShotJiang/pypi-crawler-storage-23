# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['proximity', 'proximity.vendor']

package_data = \
{'': ['*']}

install_requires = \
['numpy', 'polliwog>=3.0.0a0,<4.0.0', 'rtree==1.4.1', 'scipy', 'vg>=2.0.0']

extras_require = \
{'doc': ['Sphinx==8.1.3', 'sphinxcontrib-apidoc==0.6.0', 'myst-parser==4.0.1']}

setup_kwargs = {
    'name': 'proximity',
    'version': '3.0.0',
    'description': 'Mesh proximity queries based on libspatialindex and rtree, extracted from Trimesh',
    'long_description': 'None',
    'author': 'Paul Melnikow',
    'author_email': 'github@paulmelnikow.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://proximity.readthedocs.io/en/stable/',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.10,<4',
}


setup(**setup_kwargs)
