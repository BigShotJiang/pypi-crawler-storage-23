from . import mdae

name = "biobb_pytorch"
__all__ = ["mdae"]
__version__ = "5.2.2"
