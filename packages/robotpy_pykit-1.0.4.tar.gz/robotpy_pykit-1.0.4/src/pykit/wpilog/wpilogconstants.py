extraHeader = "PyKit"
entryMetadata = '{"source": "PyKit"}'
entryMetadataUnits = '{"source": "PyKit", "unit": "$UNITSTR"}'
