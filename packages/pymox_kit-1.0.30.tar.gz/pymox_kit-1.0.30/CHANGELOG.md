# CHANGELOG

<!-- version list -->

## v1.0.30 (2026-02-27)


## v1.0.29 (2026-02-26)

### Bug Fixes

- Try dbug
  ([`55091f1`](https://github.com/PyMoX-fr/Kit/commit/55091f11a230fc91e998397175500631f3ae60cf))

- Up core
  ([`ef9d64d`](https://github.com/PyMoX-fr/Kit/commit/ef9d64dbdfdee028e315b6284f70cb7ff2a3fb05))

- ↑ ([`7b355df`](https://github.com/PyMoX-fr/Kit/commit/7b355df29e8f4d5700c63214772b067caa9e0619))


## v1.0.28 (2026-02-26)


## v1.0.27 (2026-02-26)

### Bug Fixes

- Set logos colors of pymox & kit
  ([`8f27391`](https://github.com/PyMoX-fr/Kit/commit/8f273911ed090861325fc938f186abb88051206d))


## v1.0.26 (2026-02-26)

### Bug Fixes

- Add sl
  ([`918a55f`](https://github.com/PyMoX-fr/Kit/commit/918a55f17bb5e0e0623ea170df09f27bbffc3d0d))


## v1.0.25 (2026-02-26)

### Bug Fixes

- Up Doc style
  ([`00a55c0`](https://github.com/PyMoX-fr/Kit/commit/00a55c03f4d4182608b5cf4850f773a944612943))


## v1.0.24 (2026-02-26)

### Bug Fixes

- ↑ mt
  ([`2c55496`](https://github.com/PyMoX-fr/Kit/commit/2c5549649ac086d4ec7719ccfb394af997abf0ac))


## v1.0.23 (2026-02-26)


## v1.0.22 (2026-02-26)


## v1.0.21 (2026-02-26)

### Bug Fixes

- ↑ badges
  ([`2788981`](https://github.com/PyMoX-fr/Kit/commit/27889815946d170347b3b5036ee27844764015c9))


## v1.0.20 (2026-02-26)

### Bug Fixes

- ↑ Doc issues
  ([`2f02b57`](https://github.com/PyMoX-fr/Kit/commit/2f02b57d4dd00097f2992a76f86b8a1310cbdf96))


## v1.0.19 (2026-02-26)

### Bug Fixes

- ↑ Doc contrib
  ([`a8380fb`](https://github.com/PyMoX-fr/Kit/commit/a8380fb06682794c244ee135b0b2b66debdefa84))


## v1.0.18 (2026-02-26)

### Bug Fixes

- ↑ Doc
  ([`40c0530`](https://github.com/PyMoX-fr/Kit/commit/40c0530440b6b3643c14da94c6ddcce2e55426a3))


## v1.0.17 (2026-02-24)

### Bug Fixes

- Add marker for hotreload
  ([`fb0fd1d`](https://github.com/PyMoX-fr/Kit/commit/fb0fd1da912bc81b50c3b0959c77aa15c0f1f27f))


## v1.0.16 (2026-02-24)


## v1.0.15 (2026-02-24)


## v1.0.14 (2026-02-24)

### Bug Fixes

- New pp tk
  ([`ef10cf5`](https://github.com/PyMoX-fr/Kit/commit/ef10cf502de7a48bdb1d10e8ccea2aa74c489ed6))


## v1.0.13 (2026-02-24)

### Bug Fixes

- New folder
  ([`38661c7`](https://github.com/PyMoX-fr/Kit/commit/38661c72ee656a2a29073c23a37eb274fca40046))


## v1.0.1 (2026-02-24)

### Bug Fixes

- Good folder for module
  ([`148c659`](https://github.com/PyMoX-fr/Kit/commit/148c65988f2d75c2e712e57609cdaf731d9324da))


## v1.0.0 (2026-02-24)

- Initial Release
