"""odoodev - Unified CLI tool for native Odoo development environment management."""

__version__ = "0.3.4"
