"""Model pricing database - Updated Feb 2026."""

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class ModelPricing:
    """Pricing information for an LLM model."""

    input_per_million: float
    output_per_million: float
    provider: Literal[
        "openai", "anthropic", "google", "mistral", "deepseek", "xai", "meta", "cohere", "amazon"
    ]
    context_limit: int = 128000
    notes: str = ""


# Comprehensive pricing per 1M tokens - Updated Feb 2026
MODEL_PRICING: dict[str, ModelPricing] = {
    # OpenAI (Feb 2026)
    "gpt-4o": ModelPricing(2.50, 10.00, "openai", 128000, "Legacy compatibility"),
    "gpt-4o-mini": ModelPricing(0.15, 0.60, "openai", 128000, "Legacy compatibility"),
    "gpt-5.2": ModelPricing(1.75, 14.00, "openai"),
    "gpt-5.2-pro": ModelPricing(21.00, 168.00, "openai"),
    "gpt-5-mini": ModelPricing(0.25, 2.00, "openai"),
    "gpt-5.3-codex": ModelPricing(1.75, 14.00, "openai", 400000),
    # Anthropic Claude (Feb 2026)
    "claude-opus-4.6": ModelPricing(5.00, 25.00, "anthropic", 1000000),
    "claude-sonnet-5": ModelPricing(3.00, 15.00, "anthropic", 200000),
    "claude-sonnet-4.5": ModelPricing(3.00, 15.00, "anthropic", 200000),
    "claude-haiku-4.5": ModelPricing(1.00, 5.00, "anthropic", 200000),
    # Google Gemini (Feb 2026)
    "gemini-2.5-pro": ModelPricing(3.50, 10.50, "google", 1000000, "Legacy compatibility"),
    "gemini-3-pro": ModelPricing(2.00, 12.00, "google", 1000000),
    "gemini-3-pro-200k+": ModelPricing(4.00, 18.00, "google", 1000000),
    "gemini-3-flash": ModelPricing(0.50, 3.00, "google", 1000000),
    "gemini-3-deep-think": ModelPricing(2.00, 12.00, "google", 1000000),
    # Mistral
    "mistral-large-3": ModelPricing(0.80, 2.40, "mistral"),
    "mistral-medium-3": ModelPricing(0.40, 2.00, "mistral"),
    # DeepSeek
    "deepseek-v3": ModelPricing(0.27, 1.10, "deepseek"),
    "deepseek-v3-cached": ModelPricing(0.07, 1.10, "deepseek"),
    "deepseek-r1": ModelPricing(0.55, 2.19, "deepseek"),
    # xAI Grok
    "grok-2": ModelPricing(2.00, 10.00, "xai"),
    "grok-2-vision": ModelPricing(2.00, 10.00, "xai"),
    # Meta Llama (via Groq/DeepInfra)
    "llama-3.3-70b": ModelPricing(0.23, 0.40, "meta"),
    "llama-3.1-405b": ModelPricing(1.79, 1.79, "meta"),
    # Cohere
    "command-r-plus": ModelPricing(2.50, 10.00, "cohere"),
}

# Default model for pricing calculations
DEFAULT_TARGET_MODEL = "gpt-5.2"


def get_pricing(model: str) -> ModelPricing:
    """
    Get pricing for a model.

    Args:
        model: Model name

    Returns:
        ModelPricing dataclass with pricing info

    Raises:
        KeyError: If model not found
    """
    if model not in MODEL_PRICING:
        raise KeyError(f"Unknown model: {model}. Available: {list(MODEL_PRICING.keys())}")
    return MODEL_PRICING[model]


def calculate_savings(tokens_saved: int, target_model: str = DEFAULT_TARGET_MODEL) -> float:
    """
    Calculate dollar savings based on tokens saved.

    Args:
        tokens_saved: Number of input tokens saved
        target_model: Target model for pricing

    Returns:
        Estimated savings in dollars
    """
    pricing = MODEL_PRICING.get(target_model, MODEL_PRICING[DEFAULT_TARGET_MODEL])
    return (tokens_saved / 1_000_000) * pricing.input_per_million


def calculate_credit_cost(savings_usd: float, plan_share_pct: float = 0.30) -> float:
    """
    Calculate the cost in credits for a given savings amount.

    Args:
        savings_usd: The amount saved in USD
        plan_share_pct: The percentage taken by the platform (0.0 to 1.0)
                        Default is 30% (Starter Plan)

    Returns:
        The cost in credits (USD value)
    """
    if savings_usd <= 0:
        return 0.0
    return savings_usd * plan_share_pct


def list_models_by_provider(provider: str) -> list[str]:
    """Get all models for a specific provider."""
    return [name for name, pricing in MODEL_PRICING.items() if pricing.provider == provider]
