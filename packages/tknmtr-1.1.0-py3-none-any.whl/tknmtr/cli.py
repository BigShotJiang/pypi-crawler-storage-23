"""TKNMTR Command Line Interface - Premium UI with Rich."""

import argparse
import contextlib
import json
import sys
from datetime import datetime
from pathlib import Path

from rich import box
from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from rich.text import Text

from tknmtr import TKNMTR, __version__
from tknmtr.models.pricing import MODEL_PRICING

# Initialize Rich console
console = Console()

# ASCII Art Banner
BANNER = """
╔╦╗╦╔═╔╗╔╔╦╗╔╦╗╦═╗
 ║ ╠╩╗║║║║║║ ║ ╠╦╝
 ╩ ╩ ╩╝╚╝╩ ╩ ╩ ╩╚═
"""

TAGLINE = "Token Meter • Lossless Prompt Optimizer"


def print_banner() -> None:
    """Print the animated-style startup banner."""
    banner_text = Text(BANNER, style="bold cyan")
    tagline_text = Text(TAGLINE, style="dim white")
    version_text = Text(f"v{__version__}", style="dim cyan")

    content = Text()
    content.append_text(banner_text)
    content.append("\n")
    content.append_text(tagline_text)
    content.append("  ")
    content.append_text(version_text)

    console.print(Align.center(content))
    console.print()


def print_models() -> None:
    """Print available models and their pricing in a beautiful table."""
    table = Table(
        title="[bold cyan]Available Models & Pricing[/]",
        box=box.ROUNDED,
        header_style="bold magenta",
        border_style="dim",
    )

    table.add_column("Model", style="cyan", no_wrap=True)
    table.add_column("Input $/1M", justify="right", style="green")
    table.add_column("Output $/1M", justify="right", style="yellow")
    table.add_column("Provider", justify="center", style="dim")

    for name, pricing in sorted(MODEL_PRICING.items()):
        table.add_row(
            name,
            f"${pricing.input_per_million:.2f}",
            f"${pricing.output_per_million:.2f}",
            pricing.provider,
        )

    console.print()
    console.print(table)
    console.print()


def run_test_suite(client: TKNMTR, loops: int, output_file: str | None, verbose: bool) -> None:
    """Run the built-in test suite with progress indicators."""
    tests_file = Path(__file__).parent.parent.parent.parent / "tests.json"
    if tests_file.exists():
        with open(tests_file, "r", encoding="utf-8") as f:  # noqa: UP015
            test_cases = json.load(f)
    else:
        test_cases = [
            {
                "name": "Code Request",
                "text": "Hello, I need a Python script that reads data.csv and filters prices > 100.",
            },
            {
                "name": "SQL Query",
                "text": "Good morning. I need a query SELECT name, email FROM users WHERE created_at last month.",
            },
            {
                "name": "JSON Format",
                "text": 'Analyze the text. Respond in JSON: {"concepts": [...]}. Don\'t write anything else.',
            },
        ]

    if verbose:
        print_banner()
        console.print(
            Panel(
                f"[bold]Test Suite[/] • {loops} Loop{'s' if loops > 1 else ''} • {len(test_cases) * loops} Tests",
                border_style="cyan",
            )
        )

    results = []
    total_orig = 0
    total_opt = 0
    successful = 0
    failed_fidelity = 0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True,
    ) as progress:
        for loop in range(loops):
            if verbose:
                console.print(f"\n[bold blue]◆ Loop {loop + 1}/{loops}[/]")

            for _, test in enumerate(test_cases):
                task_id = progress.add_task(f"[cyan]Testing: {test['name']}...[/]", total=None)

                try:
                    result = client.optimize(test["text"])
                    progress.remove_task(task_id)

                    status = "[green]✓[/]" if result.fidelity_passed else "[red]✗[/]"
                    if verbose:
                        console.print(
                            f"  {status} [dim]{test['name']}[/] → [cyan]{result.savings_pct:.1f}%[/] saved"
                        )

                    results.append(
                        {
                            "loop": loop + 1,
                            "test_name": test["name"],
                            "tokens_original": result.tokens_original,
                            "tokens_optimized": result.tokens_optimized,
                            "savings_pct": result.savings_pct,
                            "fidelity": result.fidelity,
                            "fidelity_passed": result.fidelity_passed,
                        }
                    )

                    total_orig += result.tokens_original
                    total_opt += result.tokens_optimized
                    successful += 1
                    if not result.fidelity_passed:
                        failed_fidelity += 1

                except Exception as e:
                    progress.remove_task(task_id)
                    if verbose:
                        console.print(f"  [red]✗ {test['name']}[/]: {e}")

    # Summary
    if verbose and total_orig > 0:
        avg_savings = 100 - ((total_opt / total_orig) * 100)

        summary = Table(box=box.SIMPLE, show_header=False, border_style="dim")
        summary.add_column("Metric", style="dim")
        summary.add_column("Value", style="bold")

        summary.add_row("Tests Passed", f"[green]{successful}[/]/{len(test_cases) * loops}")
        summary.add_row(
            "Fidelity Failed", f"[{'red' if failed_fidelity > 0 else 'green'}]{failed_fidelity}[/]"
        )
        summary.add_row("Avg Reduction", f"[cyan]{avg_savings:.1f}%[/]")

        console.print()
        console.print(Panel(summary, title="[bold]Results[/]", border_style="green"))

    # Export
    if output_file:
        output = {
            "timestamp": datetime.now().isoformat(),
            "version": __version__,
            "target_model": client.target_model,
            "loops": loops,
            "successful_tests": successful,
            "failed_fidelity": failed_fidelity,
            "avg_reduction_pct": round(100 - ((total_opt / total_orig) * 100), 1)
            if total_orig > 0
            else 0,
            "results": results,
        }
        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(output, f, indent=2, ensure_ascii=False)
        if verbose:
            console.print(f"\n[dim]📁 Saved to:[/] [cyan]{output_file}[/]")


def run_interactive(client: TKNMTR) -> None:
    """Run interactive REPL mode with premium UI."""
    print_banner()

    console.print(
        Panel(
            "[bold]Interactive Mode[/]\n"
            "[dim]Enter prompts to optimize. Type [cyan]exit[/cyan] or [cyan]quit[/cyan] to leave.[/]",
            border_style="cyan",
        )
    )
    console.print()

    with contextlib.suppress(ImportError):
        __import__("readline")  # Enable arrow keys and history on Unix

    # Session statistics
    session_stats = {
        "optimizations": 0,
        "tokens_original": 0,
        "tokens_optimized": 0,
        "fidelity_passed": 0,
        "fidelity_failed": 0,
    }

    def show_session_summary() -> None:
        """Display session performance summary."""
        if session_stats["optimizations"] == 0:
            console.print("\n[dim cyan]👋 Goodbye! (No optimizations performed)[/]\n")
            return

        tokens_saved = session_stats["tokens_original"] - session_stats["tokens_optimized"]
        avg_savings = (
            (tokens_saved / session_stats["tokens_original"]) * 100
            if session_stats["tokens_original"] > 0
            else 0
        )

        # Calculate money saved based on target model pricing (input tokens)
        from tknmtr.models.pricing import get_pricing

        pricing = get_pricing(client.target_model)
        money_saved = (tokens_saved / 1_000_000) * pricing.input_per_million

        summary = Table(box=box.ROUNDED, show_header=False, border_style="cyan", padding=(0, 2))
        summary.add_column("Metric", style="dim")
        summary.add_column("Value", style="bold cyan", justify="right")

        summary.add_row("Optimizations", str(session_stats["optimizations"]))
        summary.add_row("Tokens Saved", f"[green]{tokens_saved:,}[/]")
        summary.add_row("Avg Savings", f"[green]{avg_savings:.1f}%[/]")
        summary.add_row(f"💰 Saved ({client.target_model})", f"[bold green]${money_saved:.4f}[/]")
        summary.add_row(
            "Fidelity",
            f"[green]{session_stats['fidelity_passed']}[/]/[dim]{session_stats['optimizations']}[/] passed",
        )

        console.print()
        console.print(
            Panel(
                summary,
                title="[bold]📊 Session Summary[/]",
                border_style="cyan",
            )
        )
        console.print("\n[dim cyan]👋 Goodbye![/]\n")

    while True:
        try:
            console.print("[bold yellow]›[/] ", end="")
            prompt = input()

            if not prompt.strip():
                continue

            if prompt.lower() in ("exit", "quit", "q"):
                show_session_summary()
                break

            # Optimize with spinner
            with console.status("[cyan]Optimizing...[/]", spinner="dots"):
                result = client.optimize(prompt)

            # Update session stats
            session_stats["optimizations"] += 1
            session_stats["tokens_original"] += result.tokens_original
            session_stats["tokens_optimized"] += result.tokens_optimized
            if result.fidelity_passed:
                session_stats["fidelity_passed"] += 1
            else:
                session_stats["fidelity_failed"] += 1

            # Display result in a panel
            savings_color = (
                "green"
                if result.savings_pct >= 30
                else "yellow"
                if result.savings_pct >= 15
                else "red"
            )
            fidelity_color = "green" if result.fidelity_passed else "red"

            result_panel = Panel(
                f"[bold white]{result.optimized}[/]",
                title="[bold green]✨ Optimized[/]",
                subtitle=f"[{savings_color}]{result.savings_pct:.1f}% saved[/] • [{fidelity_color}]{result.fidelity}[/]",
                border_style="green",
                padding=(1, 2),
            )
            console.print(result_panel)

            # Stats line
            console.print(f"[dim]Tokens: {result.tokens_original} → {result.tokens_optimized}[/]\n")

        except KeyboardInterrupt:
            show_session_summary()
            break
        except Exception as e:
            console.print(f"[red]✗ Error:[/] {e}\n")


def main() -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="tknmtr",
        description="TKNMTR: Token Meter - Lossless Prompt Optimizer",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  tknmtr --help                        # Show help
  tknmtr --list-models                 # List available models
  tknmtr -p "Your prompt here"         # Optimize a single prompt
  tknmtr -f input.txt                  # Optimize from file
  tknmtr -l 3 -o results.json          # Run test suite 3x, export JSON
  tknmtr -m claude-opus-4 -l 1         # Test with Claude pricing
        """,
    )

    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("-p", "--prompt", type=str, help="Prompt text to optimize")
    parser.add_argument("-f", "--file", type=str, help="File containing prompt")
    parser.add_argument("-i", "--interactive", action="store_true", help="Interactive REPL mode")
    parser.add_argument("-l", "--loop", type=int, default=1, help="Test suite loops")
    parser.add_argument("-o", "--output", type=str, help="Output JSON file")
    parser.add_argument("-q", "--quiet", action="store_true", help="Suppress output")
    parser.add_argument(
        "-m",
        "--model",
        type=str,
        default="gpt-5.2",
        choices=list(MODEL_PRICING.keys()),
        help="Target model for pricing",
    )
    parser.add_argument("--list-models", action="store_true", help="List available models")
    parser.add_argument(
        "--provider",
        type=str,
        choices=["gemini", "openai", "anthropic"],
        help="LLM provider to use",
    )

    args = parser.parse_args()

    # List models
    if args.list_models:
        print_banner()
        print_models()
        return

    # Initialize client
    try:
        with console.status("[cyan]Initializing...[/]", spinner="dots"):
            client = TKNMTR(provider=args.provider, target_model=args.model)
            # Get actual provider being used
            from tknmtr.config import get_settings

            actual_provider = args.provider or get_settings().get_available_provider()
        if not args.quiet:
            if args.provider:
                console.print(f"[dim]Provider:[/] [cyan]{actual_provider}[/]")
            else:
                console.print(
                    f"[dim]Provider:[/] [cyan]{actual_provider}[/] [dim](auto-detected)[/]"
                )
    except ValueError as e:
        console.print(
            Panel(
                f"[bold red]Configuration Error[/]\n\n{e}\n\n[dim]Please set valid API keys in your .env file.[/]",
                border_style="red",
            )
        )
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Initialization Error:[/] {e}")
        sys.exit(1)

    # Interactive mode
    if args.interactive:
        run_interactive(client)
        return

    # Single prompt
    if args.prompt:
        with console.status("[cyan]Optimizing...[/]", spinner="dots"):
            result = client.optimize(args.prompt)

        if not args.quiet:
            savings_color = "green" if result.savings_pct >= 30 else "yellow"
            console.print(
                Panel(
                    f"[bold white]{result.optimized}[/]",
                    title="[bold green]✨ Optimized[/]",
                    subtitle=f"[{savings_color}]{result.savings_pct:.1f}% saved[/] ({result.tokens_original}→{result.tokens_optimized})",
                    border_style="green",
                )
            )
            console.print(f"[dim]Fidelity:[/] {result.fidelity}")

        if args.output:
            with open(args.output, "w") as f:
                json.dump(result.__dict__, f, indent=2)
        return

    # File input
    if args.file:
        try:
            with open(args.file, "r", encoding="utf-8") as f:  # noqa: UP015
                text = f.read().strip()

            with console.status("[cyan]Optimizing...[/]", spinner="dots"):
                result = client.optimize(text)

            if not args.quiet:
                console.print(
                    Panel(
                        f"[bold white]{result.optimized}[/]",
                        title="[bold green]✨ Optimized[/]",
                        subtitle=f"[green]{result.savings_pct:.1f}% saved[/]",
                        border_style="green",
                    )
                )

            if args.output:
                with open(args.output, "w") as f:
                    json.dump(result.__dict__, f, indent=2)
        except FileNotFoundError:
            console.print(f"[red]Error:[/] File not found: {args.file}")
            sys.exit(1)
        return

    # Default: run test suite
    run_test_suite(client, args.loop, args.output, not args.quiet)


if __name__ == "__main__":
    main()
