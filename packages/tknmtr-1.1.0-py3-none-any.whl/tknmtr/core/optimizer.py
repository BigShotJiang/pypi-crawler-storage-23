"""Prompt optimization logic."""

from __future__ import annotations

from tknmtr.core.prompts import AGGRESSIVE_OPTIMIZER_PROMPT, OPTIMIZER_SYSTEM_PROMPT
from tknmtr.core.tokenizer import count_tokens
from tknmtr.providers import get_provider


def optimize_prompt(
    original_text: str,
    provider: str | None = None,
    temperature: float = 0.0,
) -> str:
    """
    Optimize a prompt to use fewer tokens while preserving meaning.

    Args:
        original_text: The original prompt to optimize
        provider: LLM provider to use (gemini, openai, anthropic). Auto-detected if None.
        temperature: Generation temperature (0 = deterministic)

    Returns:
        Optimized prompt text

    Example:
        >>> optimized = optimize_prompt("Hello! Please write me a Python script...")
        >>> print(optimized)
        "Write Python script..."
    """
    # 1. Deterministic Compression (Structure Pruning)
    # This removes fluff *before* the LLM sees it, saving input tokens.
    from tknmtr.core.compressor import DeterministicCompressor

    compressor = DeterministicCompressor()
    semi_compressed = compressor.compress(original_text)

    llm = get_provider(provider)

    # 2. Standard Semantic Optimization (Pass 1)
    standard_optimized = llm.generate(
        system_instruction=OPTIMIZER_SYSTEM_PROMPT,
        user_prompt=semi_compressed,
        temperature=temperature,
    )

    # Check Efficiency
    orig_count = count_tokens(original_text)
    if orig_count == 0:
        return standard_optimized

    std_count = count_tokens(standard_optimized)
    savings_ratio = (orig_count - std_count) / orig_count

    # 3. Aggressive Optimization (Pass 2 - Conditional)
    # Trigger if savings are low (< 20%) and prompt is substantial enough to compress (> 40 tokens)
    if savings_ratio < 0.20 and orig_count > 40:
        aggressive_optimized = llm.generate(
            system_instruction=AGGRESSIVE_OPTIMIZER_PROMPT,
            user_prompt=semi_compressed,
            temperature=temperature,
        )
        agg_count = count_tokens(aggressive_optimized)

        # If aggressive pass saved more tokens, use it
        if agg_count < std_count:
            return aggressive_optimized.strip()

    return standard_optimized.strip()
