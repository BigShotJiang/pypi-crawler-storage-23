"""
Rebill API Client
"""

import logging
import os
from typing import Any, cast

import httpx

REBILL_API_URL = os.getenv("REBILL_API_URL", "https://api.rebill.to/v1")
REBILL_API_KEY = os.getenv("REBILL_API_KEY")
logger = logging.getLogger(__name__)

CHECKOUT_SESSIONS_ENDPOINT = "checkout/sessions"
PORTAL_SESSIONS_ENDPOINT = "billing_portal/sessions"
CUSTOMERS_ENDPOINT = "customers"
PAYMENT_INSTRUMENTS_ENDPOINT = "payment-instruments"


class RebillClient:
    def __init__(self, api_key: str | None = None):
        self.api_key = api_key or REBILL_API_KEY
        if not self.api_key:
            logger.warning("REBILL_API_KEY is not configured")

        self.headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}" if self.api_key else "",
        }

    def _post(self, endpoint: str, data: dict[str, Any]) -> dict[str, Any]:
        url = f"{REBILL_API_URL}/{endpoint.lstrip('/')}"
        try:
            response = httpx.post(url, json=data, headers=self.headers, timeout=10.0)
            response.raise_for_status()
            return cast(dict[str, Any], response.json())
        except httpx.HTTPStatusError as e:
            logger.warning("Rebill API POST failed (%s): %s", endpoint, e.response.status_code)
            raise e

    def _get(self, endpoint: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        url = f"{REBILL_API_URL}/{endpoint.lstrip('/')}"
        try:
            response = httpx.get(url, headers=self.headers, params=params, timeout=10.0)
            response.raise_for_status()
            return cast(dict[str, Any], response.json())
        except httpx.HTTPStatusError as e:
            logger.warning("Rebill API GET failed (%s): %s", endpoint, e.response.status_code)
            raise e

    def _delete(self, endpoint: str) -> dict[str, Any]:
        url = f"{REBILL_API_URL}/{endpoint.lstrip('/')}"
        try:
            response = httpx.delete(url, headers=self.headers, timeout=10.0)
            response.raise_for_status()
            # Rebill might return 204 or empty json
            if response.status_code == 204:
                return {"status": "success"}
            return cast(dict[str, Any], response.json())
        except httpx.HTTPStatusError as e:
            logger.warning("Rebill API DELETE failed (%s): %s", endpoint, e.response.status_code)
            raise e

    def create_checkout_session(
        self,
        price_id: str,
        customer_email: str,
        success_url: str,
        cancel_url: str,
        user_id: str,
        mode: str = "subscription",
    ) -> dict[str, Any]:
        """
        Create a checkout session/link.
        """
        payload = {
            "mode": mode,  # 'subscription' or 'payment'
            "price_id": price_id,
            "customer_email": customer_email,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "metadata": {"user_id": user_id, "type": mode},
        }
        return self._post(CHECKOUT_SESSIONS_ENDPOINT, payload)

    def create_topup_session(
        self, amount: float, customer_email: str, success_url: str, cancel_url: str, user_id: str
    ) -> dict[str, Any]:
        """
        Create a one-off payment session for credits.
        Assumes we have a generic 'credits' price/item or we can pass amount dynamically.
        Since we don't know the exact Rebill API for dynamic price, we'll try to use a 'price_data' structure if possible,
        OR rely on a pre-defined 'flexible' price ID from env or settings.

        For this implementation, we will try to pass a specific Price ID for 1 unit of currency if available, and quantity = amount.
        """
        # Attempt to use a generic 'variable' price or just a standard product.
        # If we have a REBILL_CREDITS_PRICE_ID, we use that.
        credits_price_id = os.getenv("REBILL_CREDITS_PRICE_ID")

        payload: dict[str, Any] = {
            "mode": "payment",
            "customer_email": customer_email,
            "success_url": success_url,
            "cancel_url": cancel_url,
            "metadata": {
                "user_id": user_id,
                "type": "credit_top_up",
                "credits_amount": str(amount),
            },
        }

        if credits_price_id:
            payload["line_items"] = [{"price": credits_price_id, "quantity": int(amount)}]
        else:
            logger.warning(
                "REBILL_CREDITS_PRICE_ID is not configured; using dynamic price_data fallback"
            )
            payload["line_items"] = [
                {
                    "price_data": {
                        "currency": "usd",
                        "product_data": {"name": "Credits Top-up"},
                        "unit_amount": int(amount * 100),
                    },
                    "quantity": 1,
                }
            ]

        return self._post(CHECKOUT_SESSIONS_ENDPOINT, payload)

    def get_subscription(self, subscription_id: str) -> dict[str, Any]:
        return self._get(f"subscriptions/{subscription_id}")

    def create_portal_session(self, customer_email: str, return_url: str) -> dict[str, Any]:
        """
        Create a customer portal session for managing payment methods and invoices.
        """
        payload = {"customer_email": customer_email, "return_url": return_url}
        return self._post(PORTAL_SESSIONS_ENDPOINT, payload)

    def get_customer_by_email(self, email: str) -> dict[str, Any] | None:
        """
        Find a customer by email.
        """
        try:
            data: Any = self._get(CUSTOMERS_ENDPOINT, params={"email": email})
            if isinstance(data, list) and len(data) > 0:
                return cast(dict[str, Any], data[0])
            if isinstance(data, dict):
                content = data.get("content")
                if isinstance(content, list) and len(content) > 0:
                    return cast(dict[str, Any], content[0])
            return None
        except Exception as e:
            logger.warning("Failed to find Rebill customer by email: %s", e)
            return None

    def create_customer(
        self, email: str, first_name: str = "", last_name: str = ""
    ) -> dict[str, Any]:
        """
        Create a new customer in Rebill.
        """
        payload = {"email": email, "firstName": first_name, "lastName": last_name}
        return self._post(CUSTOMERS_ENDPOINT, payload)

    def get_payment_methods(self, customer_id: str) -> list[dict[str, Any]]:
        """
        Fetch authorized payment methods for a customer.
        """
        try:
            data: Any = self._get(PAYMENT_INSTRUMENTS_ENDPOINT, params={"customerId": customer_id})
            if isinstance(data, list):
                return cast(list[dict[str, Any]], data)
            if isinstance(data, dict):
                content = data.get("content", [])
                return cast(list[dict[str, Any]], content)
            return []
        except Exception as e:
            logger.warning("Failed to fetch payment methods for customer %s: %s", customer_id, e)
            return []

    def delete_payment_method(self, payment_method_id: str) -> bool:
        """
        Delete a payment method.
        """
        try:
            self._delete(f"{PAYMENT_INSTRUMENTS_ENDPOINT}/{payment_method_id}")
            return True
        except Exception as e:
            logger.warning("Failed to delete payment method %s: %s", payment_method_id, e)
            return False

    def set_default_payment_method(self, customer_id: str, payment_method_id: str) -> bool:
        """
        Set a payment method as default for a customer.
        """
        try:
            self._post(
                f"customers/{customer_id}/default-payment-instrument", {"id": payment_method_id}
            )
            return True
        except Exception as e:
            logger.warning(
                "Failed to set default payment method %s for customer %s: %s",
                payment_method_id,
                customer_id,
                e,
            )
            return False
