"""
Billing and Pricing Logic Manager.
Handles plan definitions and credit calculations.
"""

from dataclasses import dataclass

from tknmtr.models.pricing import calculate_credit_cost


@dataclass
class PricingPlan:
    """Definition of a user pricing plan."""

    id: str
    name: str
    monthly_fee: float
    savings_share: float
    features: list[str]


# Defined Plans
PLANS = {
    "starter": PricingPlan(
        id="starter",
        name="Starter (Pay-as-you-save)",
        monthly_fee=0.0,
        savings_share=0.30,
        features=["basic_optimization", "community_support"],
    ),
    "growth": PricingPlan(
        id="growth",
        name="Growth",
        monthly_fee=49.0,
        savings_share=0.15,
        features=["team_seats", "priority_support", "analytics"],
    ),
    "enterprise": PricingPlan(
        id="enterprise",
        name="Enterprise",
        monthly_fee=0.0,  # Custom
        savings_share=0.10,  # Variable/Capped
        features=["sso", "sla", "custom_contracts"],
    ),
}


class BillingManager:
    """
    Manages billing operations and credit tracking.
    Reference implementation for integration.
    """

    def __init__(self, user_plan_id: str = "starter"):
        """
        Initialize billing manager.

        Args:
            user_plan_id: ID of the user's plan (default: starter)
        """
        self.plan = PLANS.get(user_plan_id, PLANS["starter"])

    def calculate_transaction_cost(self, savings_usd: float) -> float:
        """
        Calculate how much this transaction costs the user in credits.

        Args:
            savings_usd: The raw savings generated

        Returns:
            Credit cost in USD
        """
        return calculate_credit_cost(savings_usd, self.plan.savings_share)

    def get_plan_details(self) -> dict[str, str | float]:
        """Get details of the current plan."""
        return {
            "name": self.plan.name,
            "share_rate": f"{int(self.plan.savings_share * 100)}%",
            "monthly_fee": self.plan.monthly_fee,
        }

    # Placeholder for future DB integration
    def deduct_credits(self, user_id: str, amount_usd: float) -> bool:
        """
        Deduct credits from user balance.
        (Placeholder)
        """
        # TODO: Implement DB connection
        print(f"Billing: Deducted ${amount_usd:.4f} from user {user_id}")
        return True
