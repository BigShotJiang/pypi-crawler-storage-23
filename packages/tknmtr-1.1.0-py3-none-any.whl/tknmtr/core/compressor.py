import re

import spacy


class DeterministicCompressor:
    """
    Compresses text using deterministic NLP techniques (Spacy).
    Removes stopwords and punctuation while preserving Named Entities.
    """

    def __init__(self, model: str = "en_core_web_sm"):
        try:
            self.nlp = spacy.load(model)
        except OSError:
            # Fallback if model isn't downloaded yet (should be handled by install script)
            from spacy.cli import download  # type: ignore[attr-defined]

            download(model)
            self.nlp = spacy.load(model)

    FLUFF_PHRASES = [
        "i want you to",
        "i need you to",
        "would you please",
        "could you please",
        "please kindly",
        "can you help me",
        "i am looking for",
        "i would like to",
    ]

    def remove_fluff(self, text: str) -> str:
        """Removes common conversational filler phrases."""
        lower_text = text.lower()
        for phrase in self.FLUFF_PHRASES:
            if phrase in lower_text:
                # Case-insensitive replacement is tricky with simple replace.
                # using spacy matching would be better, but simple string replacement
                # for these specific known phrases is faster and safe enough for now.
                # We'll do a primitive case-insensitive remove.
                import re

                pattern = re.compile(re.escape(phrase), re.IGNORECASE)
                text = pattern.sub("", text)
        return text

    def compress(self, text: str) -> str:
        """
        Compresses the input text by removing stopwords, conversational fluff, and irrelevant punctuation.
        Preserves Named Entities, structural tokens, and most importantly: Markdown code blocks and inline code.
        """
        # 1. Extract and protect code blocks
        code_blocks: list[str] = []

        def _replace_code_block(match: re.Match) -> str:
            code_blocks.append(match.group(0))
            return f"TKNMTRCODEBLOCK{len(code_blocks) - 1}"

        # Match markdown code blocks ```...``` and inline code `...`
        # Using non-greedy match .*?
        text = re.sub(r"```.*?```", _replace_code_block, text, flags=re.DOTALL)
        text = re.sub(r"`.*?`", _replace_code_block, text)

        # 2. Remove conversational fluff from the remaining text
        text = self.remove_fluff(text)

        # 3. Process with Spacy
        doc = self.nlp(text)

        compressed_tokens: list[str] = []

        for token in doc:
            # KEEP placeholders
            if token.text.startswith("TKNMTRCODEBLOCK"):
                compressed_tokens.append(token.text)
                continue

            # KEEP if it is a Named Entity (or part of one)
            if token.ent_type_:
                compressed_tokens.append(token.text)
                continue

            # KEEP if it is NOT a stopword AND NOT punctuation
            if (
                not token.is_stop
                and not token.is_punct
                or token.text in ["?", ":", "!", "{", "}", "[", "]", "(", ")", ",", ".", "=", "+", "-", "*", "/", "<", ">"]
            ):
                compressed_tokens.append(token.text)

        # Naive reconstruction
        compressed_text = " ".join(compressed_tokens)

        # 4. Restore code blocks
        for i, code in enumerate(code_blocks):
            compressed_text = compressed_text.replace(f"TKNMTRCODEBLOCK{i}", code)

        return compressed_text
