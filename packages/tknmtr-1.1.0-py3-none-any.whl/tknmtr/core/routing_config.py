"""
Dynamic Routing Configuration Manager.

Loads model routing rules from Supabase with Redis caching.
Falls back to sensible defaults if external services are unavailable.
"""

from __future__ import annotations

import json
import logging
from typing import Any, cast

logger = logging.getLogger(__name__)

# Hardcoded defaults — used as fallback when DB/Redis are unavailable.
DEFAULT_MODEL_MAP: dict[str, str] = {
    "SIMPLE": "gemini/gemini-3-flash",
    "REASONING": "gpt-5.2",
    "CODING": "anthropic/claude-sonnet-5",
    "CREATIVE": "gpt-5.2",
    "COMPLEX": "claude-opus-4.6",
    "DEFAULT": "gpt-5-mini",
}

REDIS_KEY = "routing:model_map"
CACHE_TTL_SECONDS = 300  # 5 minutes


class RoutingConfigManager:
    """Loads routing config from Supabase, cached in Redis."""

    def __init__(self, redis: Any = None, supabase: Any = None):
        self.redis = redis
        self.supabase = supabase

    def get_model_map(self) -> dict[str, str]:
        """
        Return the current model map.

        Resolution order:
        1. Redis cache
        2. Supabase `routing_config` table
        3. Hardcoded defaults
        """
        # 1. Try Redis cache
        if self.redis:
            try:
                cached = self.redis.get(REDIS_KEY)
                if cached:
                    logger.debug("Routing config loaded from Redis cache.")
                    parsed = json.loads(cached) if isinstance(cached, str) else cached
                    return cast(dict[str, str], parsed)
            except Exception as e:
                logger.warning(f"Redis cache read failed: {e}")

        # 2. Try Supabase
        if self.supabase:
            try:
                result = (
                    self.supabase.table("routing_config")
                    .select("category, model")
                    .eq("is_active", True)
                    .execute()
                )
                if result.data:
                    model_map = {row["category"].upper(): row["model"] for row in result.data}
                    # Ensure DEFAULT exists
                    if "DEFAULT" not in model_map:
                        model_map["DEFAULT"] = DEFAULT_MODEL_MAP["DEFAULT"]

                    # Write to Redis cache
                    self._cache_model_map(model_map)
                    logger.info(f"Routing config loaded from Supabase ({len(model_map)} rules).")
                    return model_map
            except Exception as e:
                logger.warning(f"Supabase routing_config read failed: {e}")

        # 3. Fallback to defaults
        logger.info("Using default hardcoded routing config.")
        return DEFAULT_MODEL_MAP.copy()

    def invalidate_cache(self) -> bool:
        """Clear the Redis routing cache. Returns True on success."""
        if self.redis:
            try:
                self.redis.delete(REDIS_KEY)
                logger.info("Routing config cache invalidated.")
                return True
            except Exception as e:
                logger.warning(f"Cache invalidation failed: {e}")
        return False

    def _cache_model_map(self, model_map: dict[str, str]) -> None:
        """Store model map in Redis with TTL."""
        if self.redis:
            try:
                self.redis.set(REDIS_KEY, json.dumps(model_map), ex=CACHE_TTL_SECONDS)
            except Exception as e:
                logger.warning(f"Redis cache write failed: {e}")
