"""Fidelity evaluation for optimized prompts."""

from __future__ import annotations

from tknmtr.providers import get_provider

# System prompt for fidelity evaluation
FIDELITY_JUDGE_PROMPT = """
You are a Semantic Fidelity Judge for LLM Prompts.
You will be given two prompts: ORIGINAL and OPTIMIZED.
Your task is to determine if the OPTIMIZED prompt preserves ALL key instructions, constraints, and intent of the ORIGINAL.

Analyze:
1. Was any technical instruction lost?
2. Was the required output format changed?
3. Was the user's intent altered?
4. Were persona/role instructions preserved?
5. Was the LANGUAGE preserved? (If original is in English, optimized must be in English)

Respond ONLY with 'PASS' if faithful, or 'FAIL: <reason>' if critical information was lost.
"""


def evaluate_fidelity(
    original_prompt: str,
    optimized_prompt: str,
    provider: str | None = None,
) -> str:
    """
    Evaluate if optimized prompt preserves original's intent.

    Args:
        original_prompt: The original prompt
        optimized_prompt: The optimized version
        provider: LLM provider to use. Auto-detected if None.

    Returns:
        'PASS' if faithful, 'FAIL: <reason>' otherwise

    Example:
        >>> result = evaluate_fidelity("Original text...", "Optimized text...")
        >>> print(result)
        "PASS"
    """
    user_content = f"ORIGINAL:\n{original_prompt}\n\nOPTIMIZED:\n{optimized_prompt}"

    try:
        # Default to a fast/cheap model for judging if not specified
        # But for now, rely on get_provider's default or the passed one.
        llm = get_provider(provider)
        response_text = llm.generate(
            system_instruction=FIDELITY_JUDGE_PROMPT, user_prompt=user_content, temperature=0.0
        )
        result = response_text.strip()
        # Fallback if model chats too much
        if "PASS" in result.upper():
            return "PASS"
        return result
    except Exception as e:
        print(f"Fidelity Check Error: {e}")
        return f"FAIL: Evaluation error ({str(e)})"
