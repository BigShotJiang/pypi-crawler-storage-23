"""
Semantic Router Logic.
Analyzes prompts to select the optimal model.

Uses RoutingConfigManager for dynamic model mapping
and Redis for caching routing decisions.
"""

import hashlib
import json
import logging
import re
from dataclasses import dataclass
from typing import Any

from tknmtr.core.prompts import ROUTER_SYSTEM_PROMPT
from tknmtr.core.routing_config import DEFAULT_MODEL_MAP, RoutingConfigManager
from tknmtr.providers import get_provider

logger = logging.getLogger(__name__)

ROUTE_CACHE_PREFIX = "route_cache:"
ROUTE_CACHE_TTL = 1800  # 30 minutes


@dataclass
class CustomRule:
    """A user-defined custom routing rule."""
    name: str
    regex_pattern: str
    target_model: str

    def matches(self, text: str) -> bool:
        """Evaluate if the text matches the rule's regex pattern."""
        try:
            # Case-insensitive search
            return bool(re.search(self.regex_pattern, text, re.IGNORECASE))
        except re.error as e:
            logger.error(f"Invalid regex pattern in rule '{self.name}': {e}")
            return False


class SemanticRouter:
    def __init__(
        self,
        router_model: str = "gpt-4o-mini",
        config_manager: RoutingConfigManager | None = None,
        redis: Any = None,
        supabase: Any = None,
        custom_rules: list[CustomRule] | None = None,
    ):
        """
        Initialize router with a fast model for classification.

        Args:
            router_model: LiteLLM model string for the classifier LLM.
            config_manager: Dynamic routing config. Falls back to defaults if None.
            redis: Upstash Redis client for route caching. Disabled if None.
            custom_rules: List of custom deterministic routing rules to evaluate first.
        """
        self.router_model = router_model
        self.config_manager = config_manager
        self.redis = redis
        self.supabase = supabase
        self.custom_rules = custom_rules or []
        self.llm = get_provider("openai")

    def _get_model_map(self) -> dict[str, str]:
        """Get model map from config manager or use defaults."""
        if self.config_manager:
            return self.config_manager.get_model_map()
        return DEFAULT_MODEL_MAP.copy()

    def _cache_key(self, content: str) -> str:
        """Generate a Redis cache key from prompt content."""
        h = hashlib.sha256(content.encode()).hexdigest()[:16]
        return f"{ROUTE_CACHE_PREFIX}{h}"

    def _get_cached_route(self, user_content: str) -> str | None:
        """Check Redis for a cached routing decision."""
        if not self.redis:
            return None
        try:
            cached = self.redis.get(self._cache_key(user_content))
            if cached:
                logger.info(f"Route cache HIT for '{user_content[:30]}...'")
                return cached if isinstance(cached, str) else cached.decode()
        except Exception as e:
            logger.warning(f"Route cache read failed: {e}")
        return None

    def _set_cached_route(self, user_content: str, model: str) -> None:
        """Store a routing decision in Redis."""
        if not self.redis:
            return
        try:
            self.redis.set(self._cache_key(user_content), model, ex=ROUTE_CACHE_TTL)
        except Exception as e:
            logger.warning(f"Route cache write failed: {e}")

    def _get_user_custom_rules(self, user_id: str) -> list[CustomRule]:
        """Fetch custom rules for a user from Redis or Supabase."""
        if not self.supabase:
            return []

        cache_key = f"routing:custom_rules:{user_id}"
        if self.redis:
            try:
                cached = self.redis.get(cache_key)
                if cached:
                    rules_data = json.loads(cached) if isinstance(cached, str) else json.loads(cached.decode())
                    return [CustomRule(**rd) for rd in rules_data]
            except Exception as e:
                logger.warning(f"Failed to read custom rules cache: {e}")

        # Fallback to Supabase
        try:
            result = (
                self.supabase.table("custom_routing_rules")
                .select("name, regex_pattern, target_model")
                .eq("user_id", user_id)
                .execute()
            )
            rules = [
                CustomRule(
                    name=r["name"],
                    regex_pattern=r["regex_pattern"],
                    target_model=r["target_model"]
                ) for r in (result.data or [])
            ]

            # Cache the result for 5 minutes
            if self.redis:
                self.redis.set(cache_key, json.dumps([r.__dict__ for r in rules]), ex=300)
            return rules
        except Exception as e:
            logger.warning(f"Failed to fetch user custom rules: {e}")
            return []

    def _evaluate_custom_rules(self, text: str, rules_to_eval: list[CustomRule]) -> str | None:
        """
        Evaluate all custom rules against the text.
        Returns the target model of the first matching rule, or None.
        """
        for rule in rules_to_eval:
            if rule.matches(text):
                logger.info(f"Route custom rule HIT: '{rule.name}' -> {rule.target_model}")
                return rule.target_model
        return None

    async def route(self, messages: list[dict[str, str]], user_id: str | None = None) -> str:
        """
        Analyze messages and return the target model ID.
        """
        model_map = self._get_model_map()

        try:
            # Extract the last user message
            user_content = ""
            for m in reversed(messages):
                if m.get("role") == "user":
                    user_content = str(m.get("content", ""))
                    break

            if not user_content:
                return model_map["DEFAULT"]

            # Fast check: if very short, default to simple
            if len(user_content) < 50:
                return model_map["SIMPLE"]

            # Combine global rules with user-specific rules
            all_rules = list(self.custom_rules)
            if user_id:
                all_rules.extend(self._get_user_custom_rules(user_id))

            # Evaluate custom deterministic rules first
            custom_target = self._evaluate_custom_rules(user_content, all_rules)
            if custom_target:
                # Still cache the custom rule evaluation to save CPU cycles
                # resolving regex next time, though regex is fast.
                self._set_cached_route(user_content, custom_target)
                return custom_target

            # Check Redis cache
            cached_model = self._get_cached_route(user_content)
            if cached_model:
                return cached_model

            # Call LLM to classify
            import litellm

            response = await litellm.acompletion(
                model=self.router_model,
                messages=[
                    {"role": "system", "content": ROUTER_SYSTEM_PROMPT},
                    {"role": "user", "content": user_content},
                ],
                temperature=0.0,
                max_tokens=10,
            )

            category = response.choices[0].message.content.strip().upper()

            # Map category to model
            for key in model_map:
                if key in category:
                    target = model_map[key]
                    logger.info(f"Routing '{user_content[:30]}...' -> {category} -> {target}")
                    self._set_cached_route(user_content, target)
                    return target

            logger.warning(f"Router returned unknown category: {category}. Defaulting.")
            default = model_map["DEFAULT"]
            self._set_cached_route(user_content, default)
            return default

        except Exception as e:
            logger.error(f"Routing failed: {e}. Falling back to default.")
            return model_map.get("DEFAULT", "gpt-4o-mini")
