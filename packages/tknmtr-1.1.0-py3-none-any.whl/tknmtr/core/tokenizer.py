"""Token counting utilities using tiktoken."""

import tiktoken

from tknmtr.config import get_settings


def count_tokens(text: str, model: str | None = None) -> int:
    """
    Count tokens in text using tiktoken.

    Args:
        text: The text to count tokens for
        model: The model to use for encoding (defaults to settings.default_target_model)

    Returns:
        Number of tokens in the text

    Example:
        >>> count_tokens("Hello, world!")
        4
    """
    if model is None:
        model = get_settings().default_target_model

    try:
        encoding = tiktoken.encoding_for_model(model)
    except KeyError:
        # Fallback to cl100k_base for unknown models
        encoding = tiktoken.get_encoding("cl100k_base")

    return len(encoding.encode(text))


def estimate_cost(tokens: int, price_per_million: float, is_output: bool = False) -> float:
    """
    Estimate cost for a given number of tokens.

    Args:
        tokens: Number of tokens
        price_per_million: Price per 1M tokens
        is_output: Whether these are output tokens (usually more expensive)

    Returns:
        Estimated cost in dollars
    """
    return (tokens / 1_000_000) * price_per_million
