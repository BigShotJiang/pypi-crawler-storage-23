"""Configuration management using Pydantic Settings."""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # API Keys
    gemini_api_key: str | None = Field(default=None, alias="GEMINI_API_KEY")
    openai_api_key: str | None = Field(default=None, alias="OPENAI_API_KEY")
    anthropic_api_key: str | None = Field(default=None, alias="ANTHROPIC_API_KEY")

    # Integrations
    # Supabase
    supabase_url: str | None = Field(default=None, alias="SUPABASE_URL")
    supabase_key: str | None = Field(default=None, alias="SUPABASE_KEY")
    supabase_service_role_key: str | None = Field(default=None, alias="SUPABASE_SERVICE_ROLE_KEY")

    # Rebill
    rebill_public_key: str | None = Field(default=None, alias="REBILL_PUBLIC_KEY")
    rebill_secret_key: str | None = Field(default=None, alias="REBILL_SECRET_KEY")
    rebill_webhook_secret: str | None = Field(default=None, alias="REBILL_WEBHOOK_SECRET")

    # Stripe (Legacy/Alternative)
    stripe_secret_key: str | None = Field(default=None, alias="STRIPE_SECRET_KEY")
    stripe_webhook_secret: str | None = Field(default=None, alias="STRIPE_WEBHOOK_SECRET")

    # Sentry
    sentry_dsn: str | None = Field(default=None, alias="SENTRY_DSN")

    # Upstash Redis
    upstash_redis_rest_url: str | None = Field(default=None, alias="UPSTASH_REDIS_REST_URL")
    upstash_redis_rest_token: str | None = Field(default=None, alias="UPSTASH_REDIS_REST_TOKEN")

    # Resend
    resend_api_key: str | None = Field(default=None, alias="RESEND_API_KEY")

    # API / CORS
    cors_origins: str | None = Field(default=None, alias="TKNMTR_CORS_ORIGINS")

    # Provider settings
    default_provider: Literal["gemini", "openai", "anthropic"] = Field(
        default="gemini", alias="TKNMTR_PROVIDER"
    )

    # Optimization settings
    default_target_model: str = Field(default="gpt-5.2", alias="TKNMTR_TARGET_MODEL")
    optimization_model: str = Field(
        default="gemini/gemini-3-flash",
        alias="TKNMTR_OPTIMIZATION_MODEL",
        description="LiteLLM model string used for prompt optimization",
    )
    temperature: float = Field(default=0.0, ge=0.0, le=2.0)
    max_retries: int = Field(default=10, ge=1, le=50)
    initial_retry_wait: float = Field(default=5.0, ge=1.0)

    def get_available_provider(self) -> str:
        """Get first available provider based on API keys."""
        if self.gemini_api_key:
            return "gemini"
        if self.openai_api_key:
            return "openai"
        if self.anthropic_api_key:
            return "anthropic"
        raise ValueError(
            "No API key configured. Set GEMINI_API_KEY, OPENAI_API_KEY, or ANTHROPIC_API_KEY"
        )

    def get_cors_origins(self) -> list[str]:
        """Return configured CORS origins (comma-separated env) or sensible defaults."""
        if self.cors_origins:
            return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

        return [
            "http://localhost:5173",
            "http://localhost:3000",
            "http://localhost:8080",
            "https://tknmtr.com",
            "https://www.tknmtr.com",
        ]


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()
