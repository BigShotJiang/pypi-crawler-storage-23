"""Entry point for python -m tknmtr."""

from tknmtr.cli import main

if __name__ == "__main__":
    main()
