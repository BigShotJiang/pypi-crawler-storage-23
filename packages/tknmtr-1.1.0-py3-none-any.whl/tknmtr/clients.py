"""Service clients configuration and initialization."""

from __future__ import annotations

import resend
from supabase import Client, create_client
from upstash_redis import Redis

from tknmtr.config.settings import get_settings

settings = get_settings()

# Stripe removed in favor of Rebill
# if settings.stripe_secret_key:
#     stripe.api_key = settings.stripe_secret_key

# Initialize Resend
if settings.resend_api_key:
    resend.api_key = settings.resend_api_key


def get_supabase() -> Client | None:
    """Get Supabase client instance (Anon/Public)."""
    if settings.supabase_url and settings.supabase_key:
        return create_client(settings.supabase_url, settings.supabase_key)
    return None


def get_supabase_admin() -> Client | None:
    """Get Supabase client instance (Service Role/Admin)."""
    if settings.supabase_url and settings.supabase_service_role_key:
        return create_client(settings.supabase_url, settings.supabase_service_role_key)
    return None


def get_redis() -> Redis | None:
    """Get Upstash Redis client instance."""
    if settings.upstash_redis_rest_url and settings.upstash_redis_rest_token:
        return Redis(url=settings.upstash_redis_rest_url, token=settings.upstash_redis_rest_token)
    return None
