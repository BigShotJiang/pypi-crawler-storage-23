"""
TKNMTR: Token Meter - Lossless Prompt Optimizer

A toolkit to optimize LLM prompts by reducing token count while preserving
semantic fidelity. Supports multiple LLM providers and includes cost estimation.

Usage:
    from tknmtr import TKNMTR

    client = TKNMTR()
    result = client.optimize("Your verbose prompt here...")

    print(result.optimized)     # Compressed prompt
    print(result.savings_pct)   # Percentage saved
    print(result.fidelity)      # Quality check result
"""

from tknmtr.client import TKNMTR, ChatResponse
from tknmtr.core.fidelity import evaluate_fidelity
from tknmtr.core.optimizer import optimize_prompt
from tknmtr.core.tokenizer import count_tokens
from tknmtr.models.pricing import MODEL_PRICING, get_pricing

__version__ = "0.1.0"
__all__ = [
    "TKNMTR",
    "ChatResponse",
    "optimize_prompt",
    "evaluate_fidelity",
    "count_tokens",
    "MODEL_PRICING",
    "get_pricing",
]
