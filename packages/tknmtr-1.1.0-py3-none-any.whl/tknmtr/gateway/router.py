"""FastAPI router for the OpenAI-compatible Gateway proxy.

Provides POST /v1/chat/completions that mimics the OpenAI API format.
Uses LiteLLM under the hood to route to the correct provider.
"""

from __future__ import annotations

import json
import logging
import time
import uuid
from collections.abc import AsyncIterator
from typing import Annotated, Any, cast

import litellm
import sentry_sdk
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from fastapi.responses import StreamingResponse
from supabase import Client

from tknmtr.api.deps import get_db, verify_bearer_token
from tknmtr.clients import get_redis, get_supabase
from tknmtr.core.compressor import DeterministicCompressor
from tknmtr.core.router_logic import CustomRule, SemanticRouter
from tknmtr.core.routing_config import RoutingConfigManager
from tknmtr.gateway.schemas import (
    ChatCompletionChoice,
    ChatCompletionRequest,
    ChatCompletionResponse,
    ChatCompletionResponseMessage,
    ChatCompletionUsage,
    TKNMTRMeta,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["gateway"])

# Initialize routing with dynamic config + Redis cache
_redis = get_redis()
_supabase = get_supabase()
_config_manager = RoutingConfigManager(redis=_redis, supabase=_supabase)

# Define some default custom routing rules as a proof of concept
_default_custom_rules = [
    CustomRule(
        name="email_drafting",
        regex_pattern=r"(write|draft|compose)\s+an?\s+(email|letter)",
        target_model="gpt-4o-mini" # Simple tasks can use cheaper fast models
    ),
    CustomRule(
        name="react_components",
        regex_pattern=r"(write|create)\s+a\s+(react|vue|svelte)\s+component",
        target_model="claude-3-haiku-20240307" # Haiku is fast and good at frontend
    )
]

semantic_router = SemanticRouter(
    config_manager=_config_manager,
    redis=_redis,
    supabase=_supabase,
    custom_rules=_default_custom_rules
)

# Suppress LiteLLM's verbose logging in production
litellm.suppress_debug_info = True


@router.post("/v1/chat/completions", response_model=None)
async def chat_completions(
    request: ChatCompletionRequest,
    key_data: Annotated[dict[str, Any], Depends(verify_bearer_token)],
    db: Annotated[Client, Depends(get_db)],
    background_tasks: BackgroundTasks,
) -> ChatCompletionResponse | StreamingResponse:
    """
    OpenAI-compatible Chat Completions endpoint.

    Drop-in replacement — change your `base_url` to `https://api.tknmtr.com`
    and use your TKNMTR API key as the Bearer token.
    """
    try:
        # Credit Check
        user_id = key_data["user_id"]
        # Use sync execute since we are in async def but supabase-py might be sync?
        # Actually supabase-py 'execute()' is sync usually unless using async client.
        # But 'db' is likely a sync client or we need to await if it's async.
        # Let's assume standard supabase-py usage which is sync blocking (in threadpool via FastAPI default)
        # or we might need to be careful.
        # Given 'db: Client', it is likely the sync client.

        profile_resp = (
            db.table("profiles").select("billing_status, billing_credits").eq("id", user_id).single().execute()
        )
        credits = 0.0
        status = "none"
        if profile_resp.data:
            profile_data = cast(dict[str, Any], profile_resp.data)
            credits = float(profile_data.get("billing_credits", 0.0) or 0.0)
            status = str(profile_data.get("billing_status", "none"))

        if credits <= 0.0 and status != "active":
            raise HTTPException(
                status_code=402,
                detail="Active subscription or credits required. Please upgrade your plan at https://tknmtr.com/pricing",
            )

        # Semantic Routing
        if request.model == "tknmtr-auto":
            # Convert Pydantic messages to dict list for router
            msgs = [{"role": str(m.role), "content": str(m.content or "")} for m in request.messages]
            target_model = await semantic_router.route(msgs, user_id=user_id)
            logger.info(f"Routed request to {target_model}")
            request.model = target_model

        # Prompt Compression
        tokens_original = 0
        tokens_optimized = 0
        last_user_msg_idx = -1

        for i in range(len(request.messages) - 1, -1, -1):
            if request.messages[i].role == "user" and request.messages[i].content:
                last_user_msg_idx = i
                break

        if last_user_msg_idx != -1:
            msg_content = request.messages[last_user_msg_idx].content or ""
            tokens_original = litellm.token_counter(model=request.model, text=msg_content)

            compressor = DeterministicCompressor()
            compressed_content = compressor.compress(msg_content)

            tokens_optimized = litellm.token_counter(model=request.model, text=compressed_content)
            request.messages[last_user_msg_idx].content = compressed_content

        tknmtr_meta = TKNMTRMeta(
            tokens_original=tokens_original,
            tokens_optimized=tokens_optimized,
            tokens_saved=max(0, tokens_original - tokens_optimized),
            savings_pct=round(max(0, tokens_original - tokens_optimized) / tokens_original * 100, 1) if tokens_original > 0 else 0.0,
            model_routed=request.model,
        )

        # Build kwargs for LiteLLM
        completion_kwargs = _build_litellm_kwargs(request)

        if request.stream:
            return await _handle_streaming(
                completion_kwargs, request.model, key_data, db, background_tasks, tknmtr_meta
            )
        else:
            return await _handle_non_streaming(
                completion_kwargs, request.model, key_data, db, background_tasks, tknmtr_meta
            )

    except HTTPException:
        raise
    except litellm.exceptions.AuthenticationError as e:
        raise HTTPException(status_code=401, detail="Provider authentication failed") from e
    except litellm.exceptions.BadRequestError as e:
        raise HTTPException(status_code=400, detail="Invalid request for upstream provider") from e
    except litellm.exceptions.RateLimitError as e:
        raise HTTPException(status_code=429, detail="Rate limited by upstream provider") from e
    except Exception as e:
        logger.exception("Gateway error")
        sentry_sdk.capture_exception(e)
        raise HTTPException(status_code=502, detail="Upstream provider error") from e


def _build_litellm_kwargs(request: ChatCompletionRequest) -> dict[str, Any]:
    """Convert our Pydantic request into kwargs for litellm.acompletion()."""
    messages = [{"role": m.role, "content": m.content} for m in request.messages]

    kwargs: dict[str, Any] = {
        "model": request.model,
        "messages": messages,
    }

    # Only pass optional params if explicitly set
    if request.temperature is not None:
        kwargs["temperature"] = request.temperature
    if request.top_p is not None:
        kwargs["top_p"] = request.top_p
    if request.n is not None:
        kwargs["n"] = request.n
    if request.max_tokens is not None:
        kwargs["max_tokens"] = request.max_tokens
    if request.presence_penalty is not None:
        kwargs["presence_penalty"] = request.presence_penalty
    if request.frequency_penalty is not None:
        kwargs["frequency_penalty"] = request.frequency_penalty
    if request.stop is not None:
        kwargs["stop"] = request.stop
    if request.stream:
        kwargs["stream"] = True

    return kwargs


async def _handle_non_streaming(
    completion_kwargs: dict[str, Any],
    model: str,
    key_data: dict[str, Any],
    db: Client,
    background_tasks: BackgroundTasks,
    tknmtr_meta: TKNMTRMeta,
) -> ChatCompletionResponse:
    """Handle a non-streaming chat completion request."""
    response = await litellm.acompletion(**completion_kwargs)

    # Extract usage
    usage = None
    if hasattr(response, "usage") and response.usage:
        usage = ChatCompletionUsage(
            prompt_tokens=response.usage.prompt_tokens or 0,
            completion_tokens=response.usage.completion_tokens or 0,
            total_tokens=response.usage.total_tokens or 0,
        )

    # Build choices
    choices = []
    for i, choice in enumerate(response.choices):
        choices.append(
            ChatCompletionChoice(
                index=i,
                message=ChatCompletionResponseMessage(
                    content=choice.message.content,
                ),
                finish_reason=choice.finish_reason or "stop",
            )
        )

    result = ChatCompletionResponse(
        id=response.id or f"chatcmpl-{uuid.uuid4().hex[:12]}",
        created=int(time.time()),
        model=model,
        choices=choices,
        usage=usage,
        tknmtr_meta=tknmtr_meta,
    )

    # Log usage in background
    background_tasks.add_task(_log_gateway_usage, db, key_data, model, usage, response, tknmtr_meta)

    return result


async def _handle_streaming(
    completion_kwargs: dict[str, Any],
    model: str,
    key_data: dict[str, Any],
    db: Client,
    background_tasks: BackgroundTasks,
    tknmtr_meta: TKNMTRMeta,
) -> StreamingResponse:
    """Handle a streaming chat completion request via SSE."""
    response = await litellm.acompletion(**completion_kwargs)
    stream_id = f"chatcmpl-{uuid.uuid4().hex[:12]}"

    async def generate_sse() -> AsyncIterator[str]:

        async for chunk in response:
            # Build SSE data
            delta_content = None
            delta_role = None
            finish_reason = None

            if chunk.choices:
                choice = chunk.choices[0]
                if hasattr(choice, "delta"):
                    delta_content = (
                        choice.delta.content if hasattr(choice.delta, "content") else None
                    )
                    delta_role = choice.delta.role if hasattr(choice.delta, "role") else None
                finish_reason = choice.finish_reason

            if delta_content:
                # Accumulate the actual text content to count tokens accurately later
                pass

            sse_data: dict[str, Any] = {
                "id": stream_id,
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
                "choices": [
                    {
                        "index": 0,
                        "delta": {},
                        "finish_reason": finish_reason,
                    }
                ],
            }

            # Populate delta
            delta = {}
            if delta_role:
                delta["role"] = delta_role
            if delta_content:
                delta["content"] = delta_content
            sse_data["choices"][0]["delta"] = delta

            yield f"data: {json.dumps(sse_data)}\n\n"

            if finish_reason == "stop":
                break

        yield "data: [DONE]\n\n"

        # Log usage estimate after stream completes
        try:
            # We don't have prompt tokens here from response, but we could estimate if we saved the compressed prompt.
            # But the requirement says to log the accurate stats. For streaming we might just not have LLM prompt tokens natively if litellm doesn't provide them.
            # Litellm sometimes doesn't provide usage in streaming unless stream_options={"include_usage": True} is passed.
            usage = ChatCompletionUsage(
                prompt_tokens=0,
                completion_tokens=0, # Better to set to 0 than a randomly inaccurate count if we don't have it
                total_tokens=0,
            )
            # Log in background
            background_tasks.add_task(_log_gateway_usage, db, key_data, model, usage, None, tknmtr_meta)
        except Exception as e:
            logger.warning(f"Failed to log streaming usage: {e}")

    return StreamingResponse(
        generate_sse(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
            "X-Tokens-Original": str(tknmtr_meta.tokens_original),
            "X-Tokens-Optimized": str(tknmtr_meta.tokens_optimized),
            "X-Tokens-Saved": str(tknmtr_meta.tokens_saved),
            "X-Model-Routed": tknmtr_meta.model_routed,
        },
    )


def _log_gateway_usage(
    db: Client,
    key_data: dict[str, Any],
    model: str,
    usage: ChatCompletionUsage | None,
    completion_response: object | None,
    tknmtr_meta: TKNMTRMeta,
) -> None:
    """Background task to log gateway usage to Supabase."""
    try:
        # Calculate Cost
        cost = 0.0
        try:
            if completion_response is not None:
                # Prefer full provider response for accurate cost calculation.
                try:
                    cost = float(litellm.completion_cost(completion_response=completion_response))
                except TypeError:
                    cost = float(
                        litellm.completion_cost(
                            completion_response=completion_response, model=model
                        )
                    )
        except Exception:
            pass  # fallback to 0 if model cost unknown

        record = {
            "user_id": key_data["user_id"],
            "api_key_id": key_data["id"],
            "model": model,
            "tokens_original": tknmtr_meta.tokens_original,
            "tokens_optimized": tknmtr_meta.tokens_optimized,
            "tokens_saved": tknmtr_meta.tokens_saved,
            "llm_prompt_tokens": usage.prompt_tokens if usage else 0,
            "llm_completion_tokens": usage.completion_tokens if usage else 0,
            "llm_total_tokens": usage.total_tokens if usage else 0,
            "gross_savings_usd": 0.0,
            "request_count": 1,
            "cost": cost,
            "provider": model.split("/")[0] if "/" in model else "openai",
            "status": "success",
            "endpoint": "chat_completions",
        }
        db.table("request_logs").insert(record).execute()
    except Exception as e:
        logger.warning(f"Failed to log gateway usage: {e}")



