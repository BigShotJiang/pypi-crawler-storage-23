"""OpenAI-compatible Pydantic schemas for the Gateway proxy.

These models match the OpenAI Chat Completions API specification,
allowing tknmtr to act as a drop-in replacement.
"""

from __future__ import annotations

import time
import uuid
from typing import Literal

from pydantic import BaseModel, Field

# --- Request Schemas ---


class ChatMessage(BaseModel):
    """A single message in the conversation."""

    role: Literal["system", "user", "assistant", "tool"] = Field(
        ..., description="The role of the message author."
    )
    content: str | None = Field(None, description="The content of the message.")
    name: str | None = Field(None, description="Optional name for the participant.")


class ChatCompletionRequest(BaseModel):
    """Request body matching OpenAI's POST /v1/chat/completions."""

    model: str = Field(..., description="Model ID to use (e.g. 'gpt-5.2', 'claude-sonnet-5').")
    messages: list[ChatMessage] = Field(
        ..., min_length=1, description="List of messages in the conversation."
    )
    temperature: float | None = Field(None, ge=0.0, le=2.0, description="Sampling temperature.")
    top_p: float | None = Field(None, ge=0.0, le=1.0, description="Nucleus sampling parameter.")
    n: int | None = Field(None, ge=1, le=5, description="Number of completions to generate.")
    stream: bool = Field(False, description="Whether to stream partial responses via SSE.")
    max_tokens: int | None = Field(None, ge=1, description="Maximum number of tokens to generate.")
    presence_penalty: float | None = Field(None, ge=-2.0, le=2.0, description="Presence penalty.")
    frequency_penalty: float | None = Field(None, ge=-2.0, le=2.0, description="Frequency penalty.")
    stop: str | list[str] | None = Field(None, description="Stop sequences.")
    user: str | None = Field(None, description="End-user identifier for abuse monitoring.")


# --- Response Schemas (Non-Streaming) ---


class ChatCompletionResponseMessage(BaseModel):
    """The assistant's response message."""

    role: Literal["assistant"] = "assistant"
    content: str | None = None


class ChatCompletionChoice(BaseModel):
    """One completion choice."""

    index: int = 0
    message: ChatCompletionResponseMessage
    finish_reason: str | None = "stop"


class ChatCompletionUsage(BaseModel):
    """Token usage statistics."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0


class TKNMTRMeta(BaseModel):
    """Metadata detailing prompt compression and routing."""

    tokens_original: int
    tokens_optimized: int
    tokens_saved: int
    savings_pct: float
    model_routed: str


class ChatCompletionResponse(BaseModel):
    """Response body matching OpenAI's Chat Completions response."""

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: Literal["chat.completion"] = "chat.completion"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: list[ChatCompletionChoice]
    usage: ChatCompletionUsage | None = None
    tknmtr_meta: TKNMTRMeta | None = None


# --- Streaming Response Schemas ---


class ChatCompletionChunkDelta(BaseModel):
    """Delta content for a streaming chunk."""

    role: str | None = None
    content: str | None = None


class ChatCompletionChunkChoice(BaseModel):
    """One choice in a streaming chunk."""

    index: int = 0
    delta: ChatCompletionChunkDelta
    finish_reason: str | None = None


class ChatCompletionChunk(BaseModel):
    """A single SSE chunk in the streaming response."""

    id: str = Field(default_factory=lambda: f"chatcmpl-{uuid.uuid4().hex[:12]}")
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    created: int = Field(default_factory=lambda: int(time.time()))
    model: str
    choices: list[ChatCompletionChunkChoice]
