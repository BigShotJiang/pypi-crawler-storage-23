"""Gateway module — OpenAI-compatible proxy powered by LiteLLM."""
