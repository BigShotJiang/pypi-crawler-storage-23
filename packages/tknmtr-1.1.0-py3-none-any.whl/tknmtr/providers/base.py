"""Abstract base class for LLM providers."""

from abc import ABC, abstractmethod


class LLMProvider(ABC):
    """Abstract base class for LLM providers."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Provider name."""
        ...

    @abstractmethod
    def generate(
        self,
        system_instruction: str,
        user_prompt: str,
        temperature: float = 0.0,
    ) -> str:
        """
        Generate text from the LLM.

        Args:
            system_instruction: System prompt
            user_prompt: User input
            temperature: Sampling temperature

        Returns:
            Generated text
        """
        ...

    @abstractmethod
    def is_available(self) -> bool:
        """Check if provider is configured and available."""
        ...
