"""LLM Provider abstraction layer — backed by LiteLLM."""

from tknmtr.config import get_settings
from tknmtr.providers.base import LLMProvider
from tknmtr.providers.litellm_provider import LiteLLMProvider

# Shorthand aliases → LiteLLM model strings
_PROVIDER_ALIASES: dict[str, str] = {
    "gemini": "gemini/gemini-3-flash",
    "openai": "gpt-5-mini",
    "anthropic": "claude-haiku-4.5",
}

_provider_cache: dict[str, LiteLLMProvider] = {}


def get_provider(name: str | None = None) -> LLMProvider:
    """
    Get an LLM provider instance.

    Args:
        name: Provider shorthand (gemini, openai, anthropic),
              a full LiteLLM model string (e.g. "gpt-4o"),
              or None for auto-detect.

    Returns:
        Configured LiteLLMProvider instance
    """
    if name is None:
        settings = get_settings()
        model = settings.optimization_model
    elif name in _PROVIDER_ALIASES:
        model = _PROVIDER_ALIASES[name]
    else:
        # Pass-through: treat as a LiteLLM model string directly
        model = name

    if model not in _provider_cache:
        _provider_cache[model] = LiteLLMProvider(model=model)

    return _provider_cache[model]


def list_providers() -> list[str]:
    """List available provider shorthand names."""
    return list(_PROVIDER_ALIASES.keys())


__all__ = [
    "LLMProvider",
    "LiteLLMProvider",
    "get_provider",
    "list_providers",
]
