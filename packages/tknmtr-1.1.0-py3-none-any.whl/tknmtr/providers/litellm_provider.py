"""LiteLLM-backed provider — unified wrapper for all LLM providers."""

from __future__ import annotations

import litellm

from tknmtr.config import get_settings
from tknmtr.providers.base import LLMProvider

# Suppress LiteLLM noise
litellm.suppress_debug_info = True


class LiteLLMProvider(LLMProvider):
    """
    Unified LLM provider backed by LiteLLM.

    Supports 100+ models via a single interface.  Pass any LiteLLM model
    string (e.g. ``"gemini/gemini-3-flash"``, ``"gpt-5-mini"``,
    ``"claude-3-5-haiku-latest"``).
    """

    def __init__(self, model: str = "gemini/gemini-3-flash") -> None:
        self._model = model

        # Inject API keys so LiteLLM can authenticate
        settings = get_settings()
        if settings.gemini_api_key:
            litellm.api_key = settings.gemini_api_key  # fallback key
        if settings.openai_api_key:
            import os

            os.environ.setdefault("OPENAI_API_KEY", settings.openai_api_key)
        if settings.anthropic_api_key:
            import os

            os.environ.setdefault("ANTHROPIC_API_KEY", settings.anthropic_api_key)
        if settings.gemini_api_key:
            import os

            os.environ.setdefault("GEMINI_API_KEY", settings.gemini_api_key)

    # -- LLMProvider interface ------------------------------------------------

    @property
    def name(self) -> str:
        return f"litellm:{self._model}"

    def is_available(self) -> bool:
        """True if at least one API key is configured."""
        settings = get_settings()
        return any(
            [
                settings.gemini_api_key,
                settings.openai_api_key,
                settings.anthropic_api_key,
            ]
        )

    def generate(
        self,
        system_instruction: str,
        user_prompt: str,
        temperature: float = 0.0,
    ) -> str:
        """Generate text via LiteLLM (synchronous)."""
        response = litellm.completion(
            model=self._model,
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": user_prompt},
            ],
            temperature=temperature,
        )
        return response.choices[0].message.content or ""
