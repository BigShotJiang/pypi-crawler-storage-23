"""TKNMTR SDK Client - Main interface for prompt optimization."""

import logging
import os
from dataclasses import dataclass
from typing import Any, Literal

import httpx
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_exponential

logger = logging.getLogger(__name__)

# Keep these imports for type hinting or fallback if we decide to keep local mode
# from tknmtr.core.optimizer import optimize_prompt
# from tknmtr.core.fidelity import evaluate_fidelity
# from tknmtr.core.tokenizer import count_tokens
# from tknmtr.models.pricing import MODEL_PRICING, calculate_savings, get_pricing, calculate_credit_cost


@dataclass
class OptimizationResult:
    """Result of a prompt optimization."""

    original: str
    optimized: str
    tokens_original: int
    tokens_optimized: int
    tokens_saved: int
    savings_pct: float
    fidelity: str
    fidelity_passed: bool
    estimated_savings_per_million: float
    target_model: str
    credit_cost_starter: float  # 30% cut
    credit_cost_growth: float  # 15% cut
    billable_fee_usd: float = 0.0  # Our fee


@dataclass
class ChatResponse:
    """Result of a chat completion via the TKNMTR Gateway."""

    content: str
    model_used: str
    model_requested: str
    tokens_original: int
    tokens_optimized: int
    tokens_saved: int
    savings_pct: float
    finish_reason: str
    usage: dict[str, int]


class TKNMTR:
    """
    Token Meter - Lossless Prompt Optimizer.

    Main SDK client for optimizing LLM prompts.

    Example:
        >>> from tknmtr import TKNMTR
        >>> client = TKNMTR(api_key="tkn_...")
        >>> result = client.optimize("Hello! Can you please write me a Python script?")
        >>> print(result.optimized)
        "Write Python script."
        >>> print(f"Saved {result.savings_pct:.1f}%")
        "Saved 45.2%"
    """

    DEFAULT_API_URL = "https://api.tknmtr.com"  # Placeholder, user can override or we set via ENV

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        provider: Literal["gemini", "openai", "anthropic"]
        | None = None,  # Deprecated for remote? kept for compatibility
        target_model: str = "gpt-5.2",
    ):
        """
        Initialize the TKNMTR client.

        Args:
            api_key: Your TKNMTR API Key (starts with tkn_). Defaults to TKNMTR_API_KEY env var.
            base_url: URL of the TKNMTR API.
            provider: (Deprecated for remote) LLM provider to use.
            target_model: Model to use for pricing calculations.
        """
        self.api_key = api_key or os.getenv("TKNMTR_API_KEY")
        self.base_url = base_url or os.getenv("TKNMTR_API_URL", self.DEFAULT_API_URL)
        self.provider = provider
        self.target_model = target_model

        # If running locally (dev mode), we might want to warn if no API key
        if not self.api_key:
            # For now, we don't block initialization, but optimize() will fail if remote is needed.
            pass

    def optimize(
        self,
        prompt: str,
        check_fidelity: bool = True,
    ) -> OptimizationResult:
        """
        Optimize a prompt to use fewer tokens.

        Args:
            prompt: The prompt to optimize
            check_fidelity: Whether to verify the optimization preserves meaning

        Returns:
            OptimizationResult with original, optimized, and stats
        """
        if self.api_key:
            return self._optimize_remote(prompt, check_fidelity)
        else:
            raise ValueError(
                "API Key is required for optimization. Set TKNMTR_API_KEY environment variable or pass api_key to constructor."
            )

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.ConnectError, httpx.TimeoutException)),
        reraise=True,
    )
    def _optimize_remote(self, prompt: str, check_fidelity: bool) -> OptimizationResult:
        """Call the hosted API to optimize."""
        logger.debug(f"Optimizing prompt via {self.base_url}")
        url = f"{self.base_url}/v1/optimize"
        headers: dict[str, str] = {
            "x-api-key": self.api_key or "",
            "Content-Type": "application/json",
        }
        payload = {
            "prompt": prompt,
            "check_fidelity": check_fidelity,
            "target_model": self.target_model,
        }

        try:
            response = httpx.post(url, json=payload, headers=headers, timeout=30.0)
            response.raise_for_status()
            data = response.json()

            return OptimizationResult(
                original=data["original"],
                optimized=data["optimized"],
                tokens_original=data["tokens_original"],
                tokens_optimized=data["tokens_optimized"],
                tokens_saved=data["tokens_saved"],
                savings_pct=data["savings_pct"],
                fidelity=data["fidelity"],
                fidelity_passed=data["fidelity_passed"],
                estimated_savings_per_million=data["estimated_savings_per_million"],
                target_model=data["target_model"],
                credit_cost_starter=data["credit_cost_starter"],
                credit_cost_growth=data["credit_cost_growth"],
                billable_fee_usd=data.get("billable_fee_usd", 0.0),
            )
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                logger.error("Authentication failed during optimization.")
                raise ValueError("Invalid API Key or Unauthorized access.") from e
            if e.response.status_code == 402:
                logger.warning("Quota exceeded for optimization.")
                raise ValueError(
                    "Quota exceeded. Please upgrade your plan at https://tknmtr.com/pricing"
                ) from e
            if e.response.status_code >= 500:
                logger.warning(f"Gateway 5XX error, retrying logic may apply upstream: {e}")
                raise
            logger.error(f"HTTP error during optimization: {e.response.status_code}")
            raise Exception(f"API Request failed: {e.response.text}") from e
        except httpx.RequestError as e:
            logger.warning(f"Transient request error during optimization: {e}")
            raise
        except Exception as e:
            logger.exception("Unexpected error during optimization.")
            raise Exception(f"Optimization failed: {str(e)}") from e

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.ConnectError, httpx.TimeoutException)),
        reraise=True,
    )
    def chat(
        self,
        prompt: str,
        model: str = "tknmtr-auto",
        system: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> ChatResponse:
        """
        Send a chat completion request through the TKNMTR Gateway.

        This automatically optimizes the prompt and routes to the best model
        if `model="tknmtr-auto"`.
        """
        if not self.api_key:
            raise ValueError(
                "API Key is required for chat completions. Set TKNMTR_API_KEY environment variable or pass api_key to constructor."
            )

        url = f"{self.base_url}/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        logger.debug(f"Sending chat completion via {model}")
        try:
            with httpx.Client() as client:
                response = client.post(url, json=payload, headers=headers, timeout=60.0)
                response.raise_for_status()
                data = response.json()

            return self._parse_chat_response(data, model)

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                logger.error("Authentication failed during chat.")
                raise ValueError("Invalid API Key or Unauthorized access.") from e
            if e.response.status_code == 402:
                logger.warning("Insufficient credits during chat.")
                raise ValueError("Insufficient credits. Please top up your account.") from e
            if e.response.status_code >= 500:
                logger.warning(f"Gateway 5XX error during chat: {e}")
                raise
            logger.error(f"HTTP error during chat: {e.response.status_code}")
            raise Exception(f"API Request failed: {e.response.text}") from e
        except httpx.RequestError as e:
            logger.warning(f"Transient request error during chat: {e}")
            raise

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((httpx.ConnectError, httpx.TimeoutException)),
        reraise=True,
    )
    async def achat(
        self,
        prompt: str,
        model: str = "tknmtr-auto",
        system: str | None = None,
        temperature: float | None = None,
        max_tokens: int | None = None,
    ) -> ChatResponse:
        """Async version of chat()."""
        if not self.api_key:
            raise ValueError(
                "API Key is required for chat completions. Set TKNMTR_API_KEY environment variable or pass api_key to constructor."
            )

        url = f"{self.base_url}/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        payload: dict[str, Any] = {
            "model": model,
            "messages": messages,
        }
        if temperature is not None:
            payload["temperature"] = temperature
        if max_tokens is not None:
            payload["max_tokens"] = max_tokens

        try:
            async with httpx.AsyncClient() as client:
                response = await client.post(url, json=payload, headers=headers, timeout=60.0)
                response.raise_for_status()
                data = response.json()

            return self._parse_chat_response(data, model)

        except httpx.HTTPStatusError as e:
            if e.response.status_code == 401:
                logger.error("Authentication failed during achat.")
                raise ValueError("Invalid API Key or Unauthorized access.") from e
            if e.response.status_code == 402:
                logger.warning("Insufficient credits during achat.")
                raise ValueError("Insufficient credits. Please top up your account.") from e
            if e.response.status_code >= 500:
                logger.warning(f"Gateway 5XX error during achat: {e}")
                raise
            logger.error(f"HTTP error during achat: {e.response.status_code}")
            raise Exception(f"API Request failed: {e.response.text}") from e
        except httpx.RequestError as e:
            logger.warning(f"Transient request error during achat: {e}")
            raise

    def _parse_chat_response(self, data: dict[str, Any], requested_model: str) -> ChatResponse:
        """Parse raw ChatCompletionResponse dict into ChatResponse dataclass."""
        content = ""
        finish_reason = "stop"
        if data.get("choices") and len(data["choices"]) > 0:
            choice = data["choices"][0]
            content = choice.get("message", {}).get("content", "")
            finish_reason = choice.get("finish_reason", "stop")

        usage = data.get("usage", {})

        meta = data.get("tknmtr_meta")
        if meta:
            return ChatResponse(
                content=content,
                model_used=meta.get("model_routed", data.get("model", requested_model)),
                model_requested=requested_model,
                tokens_original=meta.get("tokens_original", 0),
                tokens_optimized=meta.get("tokens_optimized", 0),
                tokens_saved=meta.get("tokens_saved", 0),
                savings_pct=meta.get("savings_pct", 0.0),
                finish_reason=finish_reason,
                usage=usage,
            )
        else:
            return ChatResponse(
                content=content,
                model_used=data.get("model", requested_model),
                model_requested=requested_model,
                tokens_original=0,
                tokens_optimized=0,
                tokens_saved=0,
                savings_pct=0.0,
                finish_reason=finish_reason,
                usage=usage,
            )

    def batch(
        self,
        prompts: list[str],
        check_fidelity: bool = True,
    ) -> list[OptimizationResult]:
        """
        Optimize multiple prompts.
        """
        return [self.optimize(p, check_fidelity) for p in prompts]

    def list_models(self) -> dict[str, dict[str, Any]]:
        """
        List available models and their pricing.

        Returns:
            Dictionary of model names to pricing info
        """
        if self.api_key:
            try:
                url = f"{self.base_url}/v1/models"
                headers = {"Authorization": f"Bearer {self.api_key}"}
                with httpx.Client() as client:
                    resp = client.get(url, headers=headers, timeout=10.0)
                    resp.raise_for_status()
                    data = resp.json()
                    # Parse the remote response into the desired dict format
                    # Assumes remote returns a list of models in data["data"]
                    if "data" in data and isinstance(data["data"], list):
                        result = {}
                        for m in data["data"]:
                            m_id = m.get("id")
                            if m_id:
                                result[m_id] = {
                                    "name": m.get("name", m_id),
                                    "provider": m.get("provider", "unknown"),
                                    "input_per_million": m.get("input_per_million", 0.0),
                                    "output_per_million": m.get("output_per_million", 0.0),
                                    "context_limit": m.get("context_limit", 8192),
                                    "notes": m.get("description", ""),
                                }
                        if result:
                            return result
            except Exception:
                pass # Fallback to local

        from tknmtr.models.pricing import MODEL_PRICING

        return {
            name: {
                "name": name,
                "provider": p.provider,
                "input_per_million": p.input_per_million,
                "output_per_million": p.output_per_million,
                "context_limit": p.context_limit,
                "notes": p.notes,
            }
            for name, p in MODEL_PRICING.items()
        }

    def get_model_pricing(self, model: str) -> dict[str, Any]:
        """
        Get pricing information for a specific model.

        Args:
            model: Model identifier (e.g. 'gpt-5.2')

        Returns:
            Dictionary with pricing details

        Raises:
            KeyError: If model is not found
        """
        models = self.list_models()
        if model not in models:
            raise KeyError(f"Model '{model}' not found. Available models: {list(models.keys())}")
        return models[model]
