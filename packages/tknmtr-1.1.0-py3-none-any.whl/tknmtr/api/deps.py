import hashlib
import logging
from typing import Annotated, Any, cast

from fastapi import Depends, Header, HTTPException, status
from supabase import Client

from tknmtr.clients import get_supabase, get_supabase_admin
from tknmtr.config.settings import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()


async def get_db() -> Client:
    """Get Supabase client (Anon)."""
    client = get_supabase()
    if not client:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database connection not configured",
        )
    return client


async def get_db_admin() -> Client:
    """Get Supabase client (Admin/Service Role)."""
    client = get_supabase_admin()
    if not client:
        # If service role key is missing, fall back to anon but warn?
        # No, for security/functionality we should fail or make it explicit.
        # But for dev ease, if missing, maybe we just use get_supabase() and hope RLS allows it (dynamic)?
        # Better to fail.
        logger.warning(
            "SUPABASE_SERVICE_ROLE_KEY not set. Operations requiring admin privileges will fail."
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Admin database connection not configured",
        )
    return client

async def verify_api_key(
    x_api_key: Annotated[str, Header()], db: Annotated[Client, Depends(get_db_admin)]
) -> dict[str, Any]:
    """
    Verify API Key and return key data.

    Hashes the input key and checks against the stored hash in Supabase.
    """
    if not x_api_key.startswith("tkn_"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key format"
        )

    # Hash the input key to match what is stored in the DB
    hashed_key = hashlib.sha256(x_api_key.encode()).hexdigest()

    # Query api_keys table
    try:
        # Note: Depending on RLS, we might need a SERVICE_ROLE key to query keys table.
        # The 'get_supabase()' usually uses the key from settings.

        response = db.table("api_keys").select("*").eq("secret_hash", hashed_key).execute()
        rows = cast(list[dict[str, Any]], response.data or [])

        if not rows:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")

        key_data = rows[0]

        if not key_data.get("is_active"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="API Key is inactive"
            )

        return key_data

    except Exception as e:
        logger.warning("Auth error: %s", e)
        # If generic error, assume unauthorized to be safe
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication failed"
        ) from e


async def get_current_user(
    db: Annotated[Client, Depends(get_db)],
    authorization: Annotated[str | None, Header()] = None,
) -> dict[str, Any]:
    """
    Validate Supabase JWT (Bearer token) and return user data.
    Used for frontend-to-backend communication (e.g. Billing).
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header",
        )

    token = authorization.split(" ")[1]

    try:
        # Verify token with Supabase
        user_response = db.auth.get_user(token)
        if not user_response or not user_response.user:
            raise HTTPException(status_code=401, detail="Invalid token")

        user = user_response.user
        return {
            "id": user.id,
            "email": user.email,
            "user_metadata": user.user_metadata,
        }

    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid authentication credentials"
        ) from e


async def verify_bearer_token(
    db: Annotated[Client, Depends(get_db_admin)],
    authorization: Annotated[str | None, Header()] = None,
) -> dict[str, Any]:
    """
    Verify API Key from Authorization: Bearer header (OpenAI-compatible).

    Extracts `tkn_xxx` from `Authorization: Bearer tkn_xxx`, then performs
    the same SHA-256 hash lookup as verify_api_key.

    Used by the Gateway proxy (/v1/chat/completions).
    """
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or invalid Authorization header. Use: Authorization: Bearer tkn_xxx",
        )

    token = authorization.split(" ", 1)[1].strip()

    if not token.startswith("tkn_"):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key format. Keys must start with 'tkn_'",
        )

    # Hash and lookup — same logic as verify_api_key
    hashed_key = hashlib.sha256(token.encode()).hexdigest()

    try:
        response = db.table("api_keys").select("*").eq("secret_hash", hashed_key).execute()
        rows = cast(list[dict[str, Any]], response.data or [])

        if not rows:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API Key")

        key_data = rows[0]

        if not key_data.get("is_active"):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED, detail="API Key is inactive"
            )

        return key_data

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Bearer auth error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication failed"
        ) from e
