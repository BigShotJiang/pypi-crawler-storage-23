"""FastAPI application for TKNMTR REST API."""

import logging
import time
from typing import Annotated, Any

import sentry_sdk
from fastapi import BackgroundTasks, Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from supabase import Client

from tknmtr import __version__
from tknmtr.api.billing import router as billing_router
from tknmtr.api.deps import get_db, verify_api_key
from tknmtr.config.settings import get_settings
from tknmtr.core.fidelity import evaluate_fidelity
from tknmtr.core.optimizer import optimize_prompt
from tknmtr.core.tokenizer import count_tokens
from tknmtr.gateway.router import router as gateway_router
from tknmtr.models.pricing import MODEL_PRICING, calculate_credit_cost, calculate_savings

logger = logging.getLogger(__name__)

# --- Pydantic Schemas ---


class OptimizeRequest(BaseModel):
    """Request body for prompt optimization."""

    prompt: str = Field(..., min_length=1, description="The prompt to optimize")
    check_fidelity: bool = Field(True, description="Whether to verify quality")
    target_model: str = Field("gpt-5.2", description="Model for pricing calculation")


class OptimizeResponse(BaseModel):
    """Response from prompt optimization."""

    original: str
    optimized: str
    tokens_original: int
    tokens_optimized: int
    tokens_saved: int
    savings_pct: float
    fidelity: str
    fidelity_passed: bool
    estimated_savings_per_million: float
    target_model: str
    credit_cost_starter: float
    credit_cost_growth: float
    billable_fee_usd: float  # New field for billing transparency


class CreateKeyRequest(BaseModel):
    name: str


class KeyResponse(BaseModel):
    id: str
    name: str
    prefix: str
    created_at: str
    # We don't return the secret hash, only on creation we might return a one-time secret
    # But for MVP we might just auto-generate and return it once.


class KeyCreateResponse(KeyResponse):
    api_key: str  # Show full key only once


# --- FastAPI App ---

# Initialize Sentry
settings = get_settings()
if settings.sentry_dsn:
    sentry_sdk.init(
        dsn=settings.sentry_dsn,
        traces_sample_rate=1.0,
        profiles_sample_rate=1.0,
        environment="production",
    )

app = FastAPI(
    title="TKNMTR API",
    description="Token Meter - Lossless Prompt Optimizer for LLMs",
    version=__version__,
)

# Configure CORS
origins = settings.get_cors_origins()

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # For strict security, list domains. For dev, ["*"] is ok but risky.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(gateway_router)

app.include_router(billing_router)


@app.get("/health")
async def health_check() -> dict[str, str]:
    return {"status": "healthy", "version": __version__}


@app.get("/")
async def root() -> dict[str, str]:
    """Root endpoint for health checks."""
    return {"status": "ok", "service": "tknmtr"}


# Global Cache (Simple In-Memory) for Subscription Status
# Key: user_id, Value: (is_active, expiry_timestamp)
SUBSCRIPTION_CACHE: dict[str, tuple[bool, float]] = {}
CACHE_TTL = 300  # 5 minutes


def get_cached_subscription_status(user_id: str, db: Client) -> bool:
    """Check subscription status with local caching to reduce DB hits."""
    now = time.time()

    # Check Cache
    if user_id in SUBSCRIPTION_CACHE:
        is_active, expiry = SUBSCRIPTION_CACHE[user_id]
        if now < expiry:
            return is_active

    # Cache Miss - Query DB
    try:
        # Note: In high traffic, we assume "active" status in DB.
        sub_resp = (
            db.table("subscriptions")
            .select("status")
            .eq("user_id", user_id)
            .eq("status", "active")
            .execute()
        )
        is_active = len(sub_resp.data) > 0
    except Exception as e:
        logger.warning("DB error during subscription check: %s", e)
        # Default to False on error to prevent free usage usage loop?
        # Or True to be fail-open?
        # Safer to fail-closed for billing.
        is_active = False

    # Update Cache
    SUBSCRIPTION_CACHE[user_id] = (is_active, now + CACHE_TTL)
    return is_active


@app.post("/v1/optimize", response_model=OptimizeResponse)
async def optimize_endpoint(
    request: OptimizeRequest,
    key_data: Annotated[dict[str, Any], Depends(verify_api_key)],
    db: Annotated[Client, Depends(get_db)],
    background_tasks: BackgroundTasks,
) -> OptimizeResponse:
    """
    Optimize a prompt and log usage for billing.
    Authenticates via x-api-key header.
    """
    try:
        # 1. Quota / Subscription Check
        start_time = time.time()
        user_id = key_data["user_id"]

        # Check for active subscription (Cached)
        has_active_subscription = get_cached_subscription_status(user_id, db)

        if not has_active_subscription:
            raise HTTPException(
                status_code=402,
                detail="Active subscription required. Please upgrade your plan at https://tknmtr.com/pricing"
            )

        # 2. Optimize (Core Logic)
        # We use the 'default' provider configured in backend settings (e.g. Gemini Flash)
        original_tokens = count_tokens(request.prompt)
        optimized_text = optimize_prompt(request.prompt)  # Uses env vars on backend
        optimized_tokens = count_tokens(optimized_text)

        tokens_saved = original_tokens - optimized_tokens
        savings_pct = (tokens_saved / original_tokens) * 100 if original_tokens > 0 else 0

        # 2. Fidelity Check
        fidelity = "SKIPPED"
        fidelity_passed = True
        if request.check_fidelity:
            fidelity = evaluate_fidelity(request.prompt, optimized_text)
            fidelity_passed = "PASS" in fidelity

        # 3. Calculate Financials
        # Savings for THIS SINGLE call (unit savings)
        # Model pricing is per 1M tokens.
        pricing = MODEL_PRICING.get(request.target_model)
        if not pricing:
            # Fallback or error? defaulting to gpt-5.2 price
            pricing = MODEL_PRICING["gpt-5.2"]

        gross_savings_usd = (tokens_saved / 1_000_000) * pricing.input_per_million
        # Our cut is 20% (example)
        billable_fee_usd = gross_savings_usd * 0.20

        # 4. Log to Database (Async via BackgroundTasks)
        # 4. Log to Database (Async via BackgroundTasks)
        end_time = time.time()
        latency_ms = int((end_time - start_time) * 1000)

        usage_record = {
            "user_id": key_data["user_id"],
            "api_key_id": key_data["id"],
            "model": request.target_model,
            "tokens_original": original_tokens,
            "tokens_optimized": optimized_tokens,
            "tokens_saved": tokens_saved,
            "request_count": 1,
            "gross_savings_usd": gross_savings_usd,
            "billable_fee_usd": billable_fee_usd,
            "provider": "litellm",
            "latency_ms": latency_ms,
            "status": "success",
        }

        # Offload DB write to background task for lower latency
        background_tasks.add_task(log_usage_task, db, usage_record)

        # 5. Response
        # Calculate stats for the user response (projection)
        estimated_savings_per_million = calculate_savings(
            tokens_saved * 1_000_000, request.target_model
        )
        credit_cost_starter = calculate_credit_cost(estimated_savings_per_million, 0.30)
        credit_cost_growth = calculate_credit_cost(estimated_savings_per_million, 0.15)

        return OptimizeResponse(
            original=request.prompt,
            optimized=optimized_text,
            tokens_original=original_tokens,
            tokens_optimized=optimized_tokens,
            tokens_saved=tokens_saved,
            savings_pct=round(savings_pct, 1),
            fidelity=fidelity,
            fidelity_passed=fidelity_passed,
            estimated_savings_per_million=estimated_savings_per_million,
            target_model=request.target_model,
            credit_cost_starter=credit_cost_starter,
            credit_cost_growth=credit_cost_growth,
            billable_fee_usd=billable_fee_usd,
        )

    except Exception as e:
        logger.exception("Unhandled error in /v1/optimize")
        raise HTTPException(status_code=500, detail="Internal server error") from e


def log_usage_task(db: Client, record: dict[str, Any]) -> None:
    """Background task to log usage to Supabase."""
    try:
        db.table("usage_logs").insert(record).execute()
    except Exception as log_error:
        logger.warning("Failed to log usage in background: %s", log_error)


@app.get("/v1/models")
async def list_models() -> dict[str, list[dict[str, Any]]]:
    """List supported models and their pricing."""
    return {
        "models": [
            {
                "id": "tknmtr-auto",
                "provider": "tknmtr",
                "input_price_1m": 0.0,
                "output_price_1m": 0.0,
                "context_limit": 128000,
                "notes": "Semantic Routing (Automatic Model Selection)",
            }
        ]
        + [
            {
                "id": model_id,
                "provider": pricing.provider,
                "input_price_1m": pricing.input_per_million,
                "output_price_1m": pricing.output_per_million,
                "context_window": pricing.context_limit,
                "notes": pricing.notes,
            }
            for model_id, pricing in MODEL_PRICING.items()
        ]
    }


# ... API Key Management Endpoints (Requires User Auth, implemented later?) ...
# The implementation plan included them. Let's add a placeholder or simple implementation.
# For now, we assume keys are created via Dashboard (Direct DB access or separate Auth API).
# The user asked about "integration", so the optimization endpoint is the priority.
