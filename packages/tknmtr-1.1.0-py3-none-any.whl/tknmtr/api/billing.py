import hashlib
import hmac
import json
import logging
import os
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from supabase import Client

from tknmtr.api.deps import get_current_user, get_db_admin
from tknmtr.config import get_settings
from tknmtr.core.billing.rebill import RebillClient

router = APIRouter(prefix="/v1/billing", tags=["billing"])
settings = get_settings()
logger = logging.getLogger(__name__)


def _verify_webhook_signature(body: bytes, signature: str, secret: str) -> bool:
    """Verify webhook signature using HMAC-SHA256."""
    expected = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    provided = signature.strip()

    # Accept common formats: "<hex>" and "sha256=<hex>"
    candidates = {provided}
    if provided.startswith("sha256="):
        candidates.add(provided.split("=", 1)[1])

    return any(hmac.compare_digest(expected, c) for c in candidates)


def _normalize_payment_method(method: dict[str, Any]) -> dict[str, Any]:
    """Normalize provider payment-method payload to frontend contract."""
    brand = method.get("brand") or method.get("cardBrand") or method.get("issuer") or "card"
    last4 = method.get("last4") or method.get("last_four") or method.get("lastDigits") or "0000"
    exp_month = method.get("expMonth") or method.get("expiryMonth") or method.get("expirationMonth")
    exp_year = method.get("expYear") or method.get("expiryYear") or method.get("expirationYear")
    is_default = bool(
        method.get("isDefault")
        or method.get("default")
        or method.get("is_default")
        or method.get("primary")
    )

    return {
        "id": method.get("id") or method.get("paymentInstrumentId") or method.get("token"),
        "brand": str(brand).lower(),
        "last4": str(last4),
        "expMonth": int(exp_month) if exp_month is not None else 0,
        "expYear": int(exp_year) if exp_year is not None else 0,
        "isDefault": is_default,
    }


@router.get("/customer")
async def get_rebill_customer(
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, Any]:
    """
    Get or create a Rebill Customer ID for the current user.
    """
    try:
        rebill = RebillClient()
        email = str(current_user.get("email") or "")
        if not email:
            raise HTTPException(status_code=400, detail="User email not found")

        customer = rebill.get_customer_by_email(email)
        if not customer:
            # Create new customer if they don't exist
            # We can use first_name/last_name from user_metadata if available
            metadata = current_user.get("user_metadata", {})
            first_name = (
                metadata.get("full_name", "").split(" ")[0] if metadata.get("full_name") else ""
            )
            customer = rebill.create_customer(email, first_name=first_name)

        return {"customer_id": customer.get("id")}

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Failed to resolve Rebill customer for %s: %s", current_user.get("email"), e)
        # DEV FALLBACK: If Rebill is down/unreachable, return a mock ID for testing UI
        if os.getenv("ENV") != "production":
            user_id = str(current_user.get("id") or "")
            return {"customer_id": f"cus_fallback_{user_id[:8]}"}
        raise HTTPException(status_code=500, detail="Failed to resolve billing customer") from e


@router.post("/top-up")
async def create_top_up_session(
    request: Request,
    payload: dict[str, Any],
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, Any]:
    """
    Create a Top-Up Session for adding credits.
    """
    amount = payload.get("amount_dollars")
    redirect_url = payload.get("redirect_url")

    if not amount or amount < 5:  # Minimum amount check
        raise HTTPException(status_code=400, detail="Amount must be at least $5")

    if not redirect_url:
        raise HTTPException(status_code=400, detail="Redirect URL is required")

    try:
        rebill = RebillClient()
        # Create Session
        # We use a success/cancel URL based on the redirect_url provided by frontend
        success_url = f"{redirect_url}?success=true"
        cancel_url = f"{redirect_url}?canceled=true"

        session_data = rebill.create_topup_session(
            amount=amount,
            customer_email=str(current_user.get("email") or ""),
            success_url=success_url,
            cancel_url=cancel_url,
            user_id=str(current_user.get("id") or ""),
        )

        return {
            "url": session_data.get("url") or session_data.get("checkout_url")
        }  # Adapt to Rebill response

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Top-up creation failed for user %s: %s", current_user.get("id"), e)
        raise HTTPException(status_code=500, detail="Failed to create top-up session") from e


@router.post("/checkout")
async def create_checkout_session_endpoint(
    request: Request,
    payload: dict[str, Any],
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, Any]:
    """
    Create a Checkout Session for a subscription plan.
    """
    plan_id = payload.get("plan_id")
    redirect_url = payload.get("redirect_url")

    if not plan_id:
        raise HTTPException(status_code=400, detail="Plan ID is required")

    # Map plan_id to Rebill Price ID
    # In production, this should be in a config or DB
    price_map = {
        "growth": os.getenv("REBILL_PRICE_ID_GROWTH"),
        "enterprise": os.getenv("REBILL_PRICE_ID_ENTERPRISE"),
    }

    rebill_price_id = price_map.get(plan_id)
    if not rebill_price_id:
        # Fallback or Error
        if plan_id == "starter":
            raise HTTPException(status_code=400, detail="Starter plan is free, no payment needed.")
        raise HTTPException(status_code=400, detail="Invalid Plan ID or configuration missing")

    try:
        rebill = RebillClient()
        success_url = f"{redirect_url}?session_id={{CHECKOUT_SESSION_ID}}&success=true"
        cancel_url = f"{redirect_url}?canceled=true"

        session_data = rebill.create_checkout_session(
            price_id=rebill_price_id,
            customer_email=str(current_user.get("email") or ""),
            success_url=success_url,
            cancel_url=cancel_url,
            user_id=str(current_user.get("id") or ""),
            mode="subscription",
        )

        return {"url": session_data.get("url") or session_data.get("checkout_url")}

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Checkout creation failed for user %s: %s", current_user.get("id"), e)
        raise HTTPException(status_code=500, detail="Failed to create checkout session") from e


@router.post("/portal")
async def create_portal_session_endpoint(
    request: Request,
    payload: dict[str, Any],
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, Any]:
    """
    Create a Customer Portal Session for managing authorized payments and invoices.
    """
    redirect_url = payload.get("redirect_url")
    if not redirect_url:
        raise HTTPException(status_code=400, detail="Redirect URL is required")

    try:
        rebill = RebillClient()
        # We use email to identify the customer for the portal session
        session_data = rebill.create_portal_session(
            customer_email=str(current_user.get("email") or ""), return_url=redirect_url
        )

        # Adjust based on actual Rebill response structure
        url = session_data.get("url") or session_data.get("portal_url")
        if not url:
            # Fallback if specific key is missing but 'link' or similar exists
            url = session_data.get("link")

        return {"url": url}

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Portal session creation failed for user %s: %s", current_user.get("id"), e)
        raise HTTPException(status_code=500, detail="Failed to create portal session") from e


@router.get("/payment-methods")
async def get_payment_methods_endpoint(
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> list[dict[str, Any]]:
    """
    Get authorized payment methods for the current user.
    """
    try:
        rebill = RebillClient()
        customer = rebill.get_customer_by_email(str(current_user.get("email") or ""))
        if not customer:
            return []

        customer_id = str(customer.get("id") or "")
        methods = rebill.get_payment_methods(customer_id)
        normalized = [_normalize_payment_method(m) for m in methods if isinstance(m, dict)]
        # Keep only methods with a stable ID
        return [m for m in normalized if m["id"]]

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Failed to fetch payment methods for user %s: %s", current_user.get("id"), e)
        raise HTTPException(status_code=500, detail="Failed to fetch payment methods") from e


@router.delete("/payment-methods/{payment_method_id}")
async def delete_payment_method_endpoint(
    payment_method_id: str,
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, str]:
    """
    Delete a payment method.
    """
    try:
        rebill = RebillClient()
        # Security: In production, verify the payment method belongs to the user
        success = rebill.delete_payment_method(payment_method_id)
        if not success:
            raise HTTPException(status_code=400, detail="Failed to delete payment method")
        return {"status": "success"}

    except HTTPException:
        raise
    except Exception as e:
        logger.warning("Failed to delete payment method %s: %s", payment_method_id, e)
        raise HTTPException(status_code=500, detail="Failed to delete payment method") from e


@router.post("/payment-methods/{payment_method_id}/default")
async def set_default_payment_method_endpoint(
    payment_method_id: str,
    current_user: Annotated[dict[str, Any], Depends(get_current_user)],
) -> dict[str, str]:
    """
    Set a payment method as default.
    """
    try:
        rebill = RebillClient()
        customer = rebill.get_customer_by_email(str(current_user.get("email") or ""))
        if not customer:
            raise HTTPException(status_code=404, detail="Customer not found")

        customer_id = str(customer.get("id") or "")
        success = rebill.set_default_payment_method(customer_id, payment_method_id)
        if not success:
            raise HTTPException(status_code=400, detail="Failed to set default payment method")
        return {"status": "success"}

    except HTTPException:
        raise
    except Exception as e:
        logger.warning(
            "Failed to set default method %s for user %s: %s",
            payment_method_id,
            current_user.get("id"),
            e,
        )
        raise HTTPException(status_code=500, detail="Failed to set default payment method") from e


@router.post("/webhook")
async def rebill_webhook(
    request: Request,
    db: Annotated[Client, Depends(get_db_admin)],
) -> dict[str, Any]:
    """
    Rebill Webhook to handle successful payments.
    """
    raw_body = await request.body()

    # Secret Verification (active when configured)
    if settings.rebill_webhook_secret:
        signature = (
            request.headers.get("x-rebill-signature")
            or request.headers.get("rebill-signature")
            or request.headers.get("x-signature")
        )
        if not signature:
            raise HTTPException(status_code=401, detail="Missing webhook signature")
        if not _verify_webhook_signature(raw_body, signature, settings.rebill_webhook_secret):
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    try:
        payload = json.loads(raw_body.decode("utf-8"))
    except Exception as e:
        raise HTTPException(status_code=400, detail="Invalid JSON") from e
    logger.info("Rebill webhook received")

    # Extract Status and Event Type
    # Rebill structure: Assuming 'status' at top level or inside 'payment' object
    status = payload.get("status")
    payment_status = payload.get("paymentStatus")  # Alternative

    event_type = payload.get("event", "")
    is_cancellation = "cancel" in event_type.lower() or status == "CANCELED"

    # Check for Success
    # We accept SUCCEEDED or PAID, unless it's a cancellation event
    if status not in ["SUCCEEDED", "COMPLETED", "APPROVED"] and payment_status != "PAID" and not is_cancellation:
        return {"status": "ignored", "reason": f"status is {status}"}

    # Extract Metadata
    # Rebill usually passes metadata at top level or inside 'payment'
    metadata = payload.get("metadata") or payload.get("payment", {}).get("metadata", {})

    # Handle Credit Top-Up
    if metadata.get("type") == "credit_top_up":
        user_id = metadata.get("user_id")
        try:
            credits_amount = float(metadata.get("credits_amount", 0))
        except Exception:
            credits_amount = 0

        if user_id and credits_amount > 0:
            try:
                # Idempotency: Check if transaction exists
                payment_id = payload.get("id")

                logger.info("Processing Rebill top-up %s for user %s", payment_id, user_id)

                existing = (
                    db.table("billing_transactions")
                    .select("id")
                    .eq("stripe_session_id", payment_id)
                    .execute()
                )
                if existing.data and len(existing.data) > 0:
                    logger.info("Webhook transaction already processed: %s", payment_id)
                    return {"status": "ignored", "reason": "already_processed"}

                # RPC to add credits
                # Ensure 'add_credits' RPC exists in DB
                db.rpc("add_credits", {"p_user_id": user_id, "p_amount": credits_amount}).execute()

                # Log Transaction
                transaction_data = {
                    "user_id": user_id,
                    "amount_dollars": credits_amount,
                    "credits_added": credits_amount,
                    "stripe_session_id": payment_id,  # Storing Rebill ID
                    # Add metadata if table supports jsonb
                }
                db.table("billing_transactions").insert(transaction_data).execute()

                logger.info("Successfully credited %s to user %s", credits_amount, user_id)
                return {"status": "success", "credits_added": credits_amount}

            except Exception as e:
                logger.exception("Failed to credit user %s from webhook", user_id)
                # We return 200 to prevent Rebill from retrying indefinitely if it's a logic error we can't fix automatically
                # But for critical errors, 500 might be better to trigger retry.
                # Choosing 500 to ensure we don't miss credits.
                raise HTTPException(status_code=500, detail="Failed to update credits") from e

    # Handle Subscription Creation and Status Updates
    if metadata.get("type") == "subscription":
        user_id = metadata.get("user_id")
        if user_id:
            try:
                if is_cancellation:
                    logger.info("Processing Rebill subscription cancellation for user %s", user_id)
                    db.table("profiles").update({"billing_status": "canceled"}).eq("id", user_id).execute()
                    return {"status": "success", "user_id": user_id, "action": "subscription_canceled"}
                else:
                    logger.info("Processing Rebill subscription for user %s", user_id)
                    db.table("profiles").update({"billing_status": "active"}).eq("id", user_id).execute()
                    return {"status": "success", "user_id": user_id, "action": "subscription_activated"}
            except Exception as e:
                logger.exception("Failed to update subscription status for user %s", user_id)
                raise HTTPException(status_code=500, detail="Failed to update subscription status") from e

    return {"status": "received"}
