"""CLI module for miu_bot."""
