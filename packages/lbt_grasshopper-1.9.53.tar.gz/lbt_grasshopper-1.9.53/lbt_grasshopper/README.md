# lbt-grasshopper

Collection of all Ladybug Tools plugins for Grasshopper.

Note that this repository and corresponding Python package does not contain any
code and it simply exists to provide a shortcut for installing all of the grasshopper
plugin packages together.

It also houses much of the documentation for the plugin, such as the
[installation instructions](https://github.com/ladybug-tools/lbt-grasshopper/wiki).
