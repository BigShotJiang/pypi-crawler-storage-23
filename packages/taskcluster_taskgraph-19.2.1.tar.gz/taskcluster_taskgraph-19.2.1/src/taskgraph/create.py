# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import logging
import sys
from concurrent import futures

from slugid import nice as slugid

from taskgraph.util import json
from taskgraph.util.parameterization import resolve_timestamps
from taskgraph.util.taskcluster import CONCURRENCY, get_session, get_taskcluster_client
from taskgraph.util.time import current_json_time

logger = logging.getLogger(__name__)

# this is set to true for `mach taskgraph action-callback --test`
testing = False


class CreateTasksException(Exception):
    """Exception raised when one or more tasks could not be created."""

    def __init__(self, errors: dict[str, Exception]):
        message = ""
        for label, exc in errors.items():
            message += f"\nERROR: Could not create '{label}':\n\n"
            message += "\n".join(f"    {line}" for line in str(exc).splitlines()) + "\n"

        super().__init__(message)


def create_tasks(graph_config, taskgraph, label_to_taskid, params, decision_task_id):
    taskid_to_label = {t: l for l, t in label_to_taskid.items()}

    # when running as an actual decision task, we use the decision task's
    # taskId as the taskGroupId.  The process that created the decision task
    # helpfully placed it in this same taskGroup.  If there is no $TASK_ID,
    # fall back to a slugid
    scheduler_id = "{}-level-{}".format(graph_config["trust-domain"], params["level"])

    # Add the taskGroupId, schedulerId and optionally the decision task
    # dependency
    for task_id in taskgraph.graph.nodes:
        task_def = taskgraph.tasks[task_id].task

        # if this task has no dependencies *within* this taskgraph, make it
        # depend on this decision task. If it has another dependency within
        # the taskgraph, then it already implicitly depends on the decision
        # task.  The result is that tasks do not start immediately. if this
        # loop fails halfway through, none of the already-created tasks run.
        if not any(t in taskgraph.tasks for t in task_def.get("dependencies", [])):
            task_def.setdefault("dependencies", []).append(decision_task_id)

        task_def["taskGroupId"] = decision_task_id
        task_def["schedulerId"] = scheduler_id

    # If `testing` is True, then run without parallelization
    concurrency = CONCURRENCY if not testing else 1
    session = get_session()
    with futures.ThreadPoolExecutor(concurrency) as e:
        fs = {}
        fs_to_task = {}
        skipped = set()
        errors = {}

        # We can't submit a task until its dependencies have been submitted.
        # So our strategy is to walk the graph and submit tasks once all
        # their dependencies have been submitted.
        tasklist = set(taskgraph.graph.visit_postorder())
        alltasks = tasklist.copy()

        def handle_exception(fut):
            if exc := fut.exception():
                task_id, label = fs_to_task[fut]
                skipped.add(task_id)
                errors[label] = exc

        def schedule_tasks():
            to_remove = set()
            new = set()

            def submit(task_id, label, task_def):
                fut = e.submit(create_task, session, task_id, label, task_def)
                new.add(fut)
                fs[task_id] = fut
                fs_to_task[fut] = (task_id, label)
                fut.add_done_callback(handle_exception)

            for task_id in tasklist:
                task_def = taskgraph.tasks[task_id].task
                # Some dependencies aren't in our graph, so make sure to filter
                # those out
                deps = set(task_def.get("dependencies", [])) & alltasks

                # If one of the dependencies didn't get created, then
                # don't attempt to submit as it would fail.
                if any(d in skipped for d in deps):
                    skipped.add(task_id)
                    to_remove.add(task_id)
                    continue

                # If we haven't finished submitting all our dependencies yet,
                # come back to this later.
                if any((d not in fs or not fs[d].done()) for d in deps):
                    continue

                submit(task_id, taskid_to_label[task_id], task_def)
                to_remove.add(task_id)

                # Schedule tasks as many times as task_duplicates indicates
                attributes = taskgraph.tasks[task_id].attributes
                for i in range(1, attributes.get("task_duplicates", 1)):
                    # We use slugid() since we want a distinct task id
                    submit(slugid(), taskid_to_label[task_id], task_def)
            tasklist.difference_update(to_remove)

            # As each of those futures complete, try to schedule more tasks.
            for f in futures.as_completed(new):
                schedule_tasks()

        # Start scheduling tasks and run until everything is scheduled.
        schedule_tasks()

        # Wait for all futures to complete.
        futures.wait(fs.values())

        if errors:
            raise CreateTasksException(errors)


def create_task(session, task_id, label, task_def):
    # Resolve timestamps
    now = current_json_time(datetime_format=True)
    task_def = resolve_timestamps(now, task_def)

    if testing:
        json.dump(
            [task_id, task_def],
            sys.stdout,
            sort_keys=True,
            indent=2,
        )
        # add a newline
        print("")
        return

    logger.info(f"Creating task with taskId {task_id} for {label}")
    queue = get_taskcluster_client("queue")
    queue.createTask(task_id, task_def)
