# Decision Tasks

The decision image is a "bootstrapping" image for the in tree logic it
deals with cloning gecko and the related utilities for providing an
environment where we can run gecko.
