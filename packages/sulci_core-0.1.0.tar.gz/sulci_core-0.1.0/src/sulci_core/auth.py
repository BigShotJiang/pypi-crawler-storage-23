"""Tier limits for Sulci SaaS quota enforcement."""

# Tier limits — maps tier name to quota overrides
TIER_LIMITS = {
    "free": {
        "max_atoms": 500,
        "max_projects": 3,
        "max_extractions_month": 50,
        "max_context_queries_day": 100,
    },
    "pro": {
        "max_atoms": 25_000,
        "max_projects": 25,
        "max_extractions_month": 10_000,
        "max_context_queries_day": 10_000,
    },
    "team": {
        "max_atoms": 250_000,
        "max_projects": 100,
        "max_extractions_month": 100_000,
        "max_context_queries_day": 100_000,
    },
    "enterprise": {
        "max_atoms": 10_000_000,
        "max_projects": 10_000,
        "max_extractions_month": 10_000_000,
        "max_context_queries_day": 10_000_000,
    },
    "admin": {
        # Unlimited — for the service owner. Quota checks are bypassed entirely.
        "max_atoms": 0,
        "max_projects": 0,
        "max_extractions_month": 0,
        "max_context_queries_day": 0,
        "unlimited": True,
    },
}
