"""Vector backend factory for Sulci."""

from sulci_core.config import SulciConfig


async def create_vector_backend(config: SulciConfig, session_factory=None):
    """Create and initialize the appropriate vector backend.

    Args:
        config: Sulci configuration.
        session_factory: SQLAlchemy async_sessionmaker (required for 'local' backend).

    Returns:
        An initialized VectorBackend instance.
    """
    backend_type = getattr(config, "store_backend", "local")

    if backend_type == "postgres":
        from sulci_core.backends.pgvector import PgVectorBackend

        backend = PgVectorBackend(config)
        await backend.initialize()
        return backend

    if backend_type == "chroma":
        from sulci_core.backends.chroma import ChromaVectorBackend

        backend = ChromaVectorBackend(config)
        await backend.initialize()
        return backend

    # Default: local (sqlite-vec)
    from sulci_core.backends.sqlite_vec import SqliteVecBackend

    if session_factory is None:
        raise ValueError("session_factory is required for local (sqlite-vec) backend")
    backend = SqliteVecBackend(session_factory, config.embedding_dimensions)
    await backend.initialize()
    return backend
