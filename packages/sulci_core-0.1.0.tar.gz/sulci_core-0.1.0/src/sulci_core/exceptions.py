"""Sulci-specific exceptions."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from sulci_core.pii import PIIMatch


class QuotaExceededError(Exception):
    """Raised when a usage quota is exceeded."""

    def __init__(self, resource: str, limit: int, current: int, period: str = "") -> None:
        self.resource = resource
        self.limit = limit
        self.current = current
        self.period = period
        msg = f"Quota exceeded: {resource} ({current}/{limit})"
        if period:
            msg += f" for {period}"
        super().__init__(msg)


class PIIBlockedError(Exception):
    """Raised when PII is detected in a non-private project context."""

    def __init__(
        self,
        pii_matches: list[PIIMatch],
        content_preview: str = "",
    ) -> None:
        self.pii_matches = pii_matches
        self.content_preview = content_preview[:120]
        types = sorted({m.pii_type for m in pii_matches})
        super().__init__(
            f"PII detected ({', '.join(types)}). Use a Private project to store atoms containing personal data."
        )
