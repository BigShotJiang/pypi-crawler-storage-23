# SAR robustness impact report

- Generated UTC: 2026-02-19T13:01:34Z
- Go decision: `True`
- Summary: `go`

## Variants

| Variant | Mean Final Loss | Final Loss Std | Mean Seconds | Guard Breaches |
|---|---:|---:|---:|---:|
| cotta | 0.900000 | 0.000000 | 0.120000 | 0 |
| eata | 0.890000 | 0.000000 | 0.100000 | 0 |
| sar | 0.870000 | 0.000000 | 0.110000 | 0 |

## Side effects

- overhead_vs_best_baseline: `1.100000`
- loss_delta_vs_best_baseline: `-0.020000`
- variance_delta_vs_best_baseline: `0.000000`
- guard_breach_delta_vs_best_baseline: `0`

