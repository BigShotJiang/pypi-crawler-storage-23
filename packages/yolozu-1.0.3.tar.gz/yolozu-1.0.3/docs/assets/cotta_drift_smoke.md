# CoTTA drift validation report (smoke)

- Generated UTC: 2026-02-19T12:23:28Z
- Stabilization pass: `True`
- Unsafe drift detected: `False`

## Baseline vs CoTTA

| Variant | Mean Loss | Mean Final Loss | Max Total Update Norm | Guard Breaches | Stopped Early |
|---|---:|---:|---:|---:|---:|
| baseline | 1.130000 | 1.090000 | 1.150000 | 1 | 1 |
| cotta | 0.966667 | 0.920000 | 0.710000 | 0 | 0 |
