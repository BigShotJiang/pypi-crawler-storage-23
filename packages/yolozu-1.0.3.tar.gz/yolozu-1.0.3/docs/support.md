# Support / legal

## Contact

- Contact: `develop@toppymicros.com`

For security-related reports, see `SECURITY.md`.

## Legal

- © 2026 ToppyMicroServices OÜ
- Legal address: Karamelli tn 2, 11317 Tallinn, Harju County, Estonia
- Registry code: 16551297

