# SynthGen interface contract (moved)

Canonical location:

- `docs/synthgen_contract.md`

This compatibility page is kept to avoid broken historical links.
