"""Visualization utilities."""

from .synthgen_overlay import SYNTHGEN_SKELETONS, render_synthgen_overlay

__all__ = ["SYNTHGEN_SKELETONS", "render_synthgen_overlay"]
