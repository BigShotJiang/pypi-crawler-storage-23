"""Self-contained demos runnable via the `yolozu demo ...` CLI."""

