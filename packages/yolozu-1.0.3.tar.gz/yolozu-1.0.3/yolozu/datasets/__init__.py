"""Dataset helpers (conversion, discovery, manifests)."""

