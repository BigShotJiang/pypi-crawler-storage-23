"""Tests for extradoc package."""
