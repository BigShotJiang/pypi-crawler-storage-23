# pollyweb

A sample Python package for PyPI.

## Usage

```
from pollyweb import hello
print(hello())
```
