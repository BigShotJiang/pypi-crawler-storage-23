from setuptools import setup, find_packages

setup(
    name="pollyweb",
    version="0.1.0",
    description="A sample Python package for PyPI.",
    author="jorgemf",
    license="MIT",
    packages=find_packages(),
    install_requires=[],
    python_requires='>=3.7',
)
