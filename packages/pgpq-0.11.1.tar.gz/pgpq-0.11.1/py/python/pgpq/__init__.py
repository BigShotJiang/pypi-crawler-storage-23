from __future__ import annotations

from pgpq._pgpq import ArrowToPostgresBinaryEncoder

__all__ = [
    "ArrowToPostgresBinaryEncoder",
]
