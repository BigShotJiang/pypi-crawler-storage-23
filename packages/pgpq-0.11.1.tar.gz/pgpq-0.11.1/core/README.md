# pgpq

Convert PyArrow RecordBatches to Postgres' native binary format.

## Usage

```rust
// TODO
```
