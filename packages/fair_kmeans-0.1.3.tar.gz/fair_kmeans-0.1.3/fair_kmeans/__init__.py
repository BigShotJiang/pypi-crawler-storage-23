from fair_kmeans.core import FairKMeans

__all__ = ["FairKMeans"]
