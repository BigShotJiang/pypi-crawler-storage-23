Planning mode ON:
- Plan before solving. Execute step-by-step.
- Complete one task at a time. Use tools for current task.
- Conclude with concise summary.