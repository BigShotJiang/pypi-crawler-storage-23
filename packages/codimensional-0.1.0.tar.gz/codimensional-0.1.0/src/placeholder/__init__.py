"""Reserved package."""


def hello():
    print("hello world")
