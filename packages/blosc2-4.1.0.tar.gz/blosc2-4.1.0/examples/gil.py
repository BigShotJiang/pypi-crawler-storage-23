#######################################################################
# Copyright (c) 2019-present, Blosc Development Team <blosc@blosc.org>
# All rights reserved.
#
# SPDX-License-Identifier: BSD-3-Clause
#######################################################################

import blosc2

print(blosc2.set_releasegil(True))
print(blosc2.set_releasegil(True))
