__name__ = "quality"
from .quality import check_intervals, select_interval_length

__all__ = ["check_intervals", "select_interval_length"]
