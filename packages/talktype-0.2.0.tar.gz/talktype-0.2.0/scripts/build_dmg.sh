#!/usr/bin/env bash
# Build Talk.app, code-sign it, package as DMG, notarize, and staple.
# Prerequisites:
#   uv add --dev pyinstaller
#   xcrun notarytool store-credentials "talk-notarize" --apple-id <email> --team-id 7NV8TSX4VN
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

IDENTITY="Developer ID Application: Powr of You Ltd. (7NV8TSX4VN)"
KEYCHAIN_PROFILE="talk-notarize"
APP_NAME="Talk"
BUNDLE_ID="com.powrofyou.talk"

DIST="$ROOT/dist"
APP="$DIST/$APP_NAME.app"
DMG="$DIST/$APP_NAME.dmg"
ENTITLEMENTS="$ROOT/entitlements.plist"
SPEC="$ROOT/Talk.spec"

# ---- helpers ----------------------------------------------------------------
info()  { printf '\033[1;34m→ %s\033[0m\n' "$*"; }
ok()    { printf '\033[1;32m✓ %s\033[0m\n' "$*"; }
die()   { printf '\033[1;31m✗ %s\033[0m\n' "$*" >&2; exit 1; }

# ---- pre-flight checks -----------------------------------------------------
command -v pyinstaller >/dev/null 2>&1 || command -v uv >/dev/null 2>&1 || die "pyinstaller not found"
command -v hdiutil     >/dev/null 2>&1 || die "hdiutil not found (expected on macOS)"
command -v codesign    >/dev/null 2>&1 || die "codesign not found"
[[ -f "$SPEC" ]]        || die "Talk.spec not found at $SPEC"
[[ -f "$ENTITLEMENTS" ]] || die "entitlements.plist not found at $ENTITLEMENTS"

# ---- 1. build .app ---------------------------------------------------------
info "Building $APP_NAME.app with PyInstaller"
cd "$ROOT"
uv run pyinstaller "$SPEC" --clean --noconfirm
[[ -d "$APP" ]] || die "PyInstaller build did not produce $APP"
ok "Build complete ($(du -sh "$APP" | cut -f1))"

# ---- 2. code-sign (inside-out) ----------------------------------------------
info "Signing binaries inside the bundle"

# Sign all .dylib and .so files first
find "$APP" -type f \( -name "*.dylib" -o -name "*.so" \) -print0 | \
  while IFS= read -r -d '' lib; do
    codesign --sign "$IDENTITY" --timestamp --force --options runtime \
      --entitlements "$ENTITLEMENTS" "$lib" 2>/dev/null || true
  done

# Sign all embedded frameworks
find "$APP/Contents/Frameworks" -type f -perm +111 -print0 2>/dev/null | \
  while IFS= read -r -d '' bin; do
    codesign --sign "$IDENTITY" --timestamp --force --options runtime \
      --entitlements "$ENTITLEMENTS" "$bin" 2>/dev/null || true
  done

# Sign the main executable
codesign --sign "$IDENTITY" --timestamp --force --options runtime \
  --entitlements "$ENTITLEMENTS" "$APP/Contents/MacOS/$APP_NAME"

# Sign the whole .app bundle
codesign --sign "$IDENTITY" --deep --force --options runtime \
  --timestamp --entitlements "$ENTITLEMENTS" "$APP"

ok "Code signing complete"

# Verify
codesign --verify --deep --strict "$APP" || die "Signature verification failed"
ok "Signature verified"

# ---- 3. create DMG ---------------------------------------------------------
info "Creating DMG"
rm -f "$DMG"

STAGING="$(mktemp -d)"
trap 'rm -rf "$STAGING"' EXIT
cp -R "$APP" "$STAGING/"
ln -s /Applications "$STAGING/Applications"

hdiutil create -volname "$APP_NAME" -srcfolder "$STAGING" -ov -format UDZO "$DMG"
rm -rf "$STAGING"
trap - EXIT

ok "DMG created at $DMG ($(du -sh "$DMG" | cut -f1))"

# ---- 4. sign DMG -----------------------------------------------------------
info "Signing DMG"
codesign --sign "$IDENTITY" --timestamp "$DMG"
ok "DMG signed"

# ---- 5. notarize ------------------------------------------------------------
info "Submitting for notarization (this may take a few minutes)"
xcrun notarytool submit "$DMG" \
  --keychain-profile "$KEYCHAIN_PROFILE" \
  --wait

ok "Notarization complete"

# ---- 6. staple --------------------------------------------------------------
info "Stapling notarization ticket"
xcrun stapler staple "$DMG"
ok "Stapled"

# ---- done -------------------------------------------------------------------
echo ""
ok "Done! Distributable DMG: $DMG"
echo "   Size: $(du -sh "$DMG" | cut -f1)"
echo "   Verify: spctl --assess --type open --context context:primary-signature \"$DMG\""
