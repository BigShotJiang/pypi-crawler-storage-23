from __future__ import annotations

import tempfile

import numpy as np

from talk.audio import to_wav_buffer


class ParakeetBackend:
    name = "parakeet"

    def __init__(self, model_id: str) -> None:
        self.model_id = model_id
        print(f"[init] Loading Parakeet model ({model_id})...")
        print("[init] First run downloads ~1.2 GB of weights. Subsequent runs are fast.")

        from parakeet_mlx import from_pretrained

        self._model = from_pretrained(model_id)
        print("[init] Model ready.")

    def transcribe(self, audio: np.ndarray, sample_rate: int) -> str:
        wav_buffer = to_wav_buffer(audio, sample_rate)
        with tempfile.NamedTemporaryFile(suffix=".wav") as tmp:
            tmp.write(wav_buffer.getvalue())
            tmp.flush()
            result = self._model.transcribe(tmp.name)
        return (getattr(result, "text", "") or "").strip()
