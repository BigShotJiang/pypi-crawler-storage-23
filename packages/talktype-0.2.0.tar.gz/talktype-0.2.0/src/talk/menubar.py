"""Menu bar app entry point for Talk.app (macOS)."""

from __future__ import annotations

import os
import sys
from pathlib import Path


def _resource_path(filename: str) -> str:
    """Resolve asset paths for both dev and PyInstaller bundles."""
    if getattr(sys, "_MEIPASS", None):
        return str(Path(sys._MEIPASS) / filename)  # type: ignore[attr-defined]
    return str(Path(__file__).resolve().parent.parent.parent / "assets" / filename)


def main() -> None:
    import rumps

    from talk.app import DictationApp
    from talk.config import load_settings

    ICON_IDLE = _resource_path("mic.png")
    ICON_RECORDING = _resource_path("mic_rec.png")
    ICON_TRANSCRIBING = _resource_path("mic_wait.png")

    class TalkApp(rumps.App):
        def __init__(self) -> None:
            super().__init__(
                "Talk",
                icon=ICON_IDLE if os.path.exists(ICON_IDLE) else None,
                quit_button=None,
            )
            self._status_item = rumps.MenuItem("Starting...")
            self.menu = [
                self._status_item,
                None,
                rumps.MenuItem("Quit Talk", callback=self._quit),
            ]
            self._dictation: DictationApp | None = None

        @rumps.timer(1)
        def _deferred_init(self, timer: rumps.Timer) -> None:
            """Load model after the menu bar icon is visible."""
            timer.stop()
            settings = load_settings()
            self._dictation = DictationApp(
                settings, on_state_change=self._on_state,
            )
            self._dictation.start_hotkey_listener()
            self._status_item.title = f"Ready \u2014 {settings.hotkey} to dictate"

        def _on_state(self, state: str) -> None:
            icons = {
                "idle": ICON_IDLE,
                "recording": ICON_RECORDING,
                "transcribing": ICON_TRANSCRIBING,
            }
            icon_path = icons.get(state, ICON_IDLE)
            if os.path.exists(icon_path):
                self.icon = icon_path

            labels = {
                "idle": "Ready",
                "recording": "Recording...",
                "transcribing": "Transcribing...",
            }
            self._status_item.title = labels.get(state, "Ready")

        def _quit(self, _sender: rumps.MenuItem) -> None:
            if self._dictation is not None:
                self._dictation.stop()
            rumps.quit_application()

    TalkApp().run()


if __name__ == "__main__":
    main()
