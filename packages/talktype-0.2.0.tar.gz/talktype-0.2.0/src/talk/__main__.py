from __future__ import annotations

import argparse
import sys

from talk import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="talk",
        description="Local-first laptop dictation with a global hotkey.",
    )
    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("run", help="Start the live dictation app")
    sub.add_parser("doctor", help="Run setup preflight checks")

    file_parser = sub.add_parser("transcribe-file", help="Transcribe a WAV file")
    file_parser.add_argument("path", help="Path to a 16-bit PCM WAV file")
    file_parser.add_argument(
        "--paste",
        action="store_true",
        help="Paste transcription at cursor after transcription",
    )

    return parser


def _cmd_run() -> None:
    from talk.app import DictationApp
    from talk.config import load_settings

    settings = load_settings()
    app = DictationApp(settings)
    app.run()


def _cmd_doctor() -> None:
    from talk.config import load_settings
    from talk.doctor import run_doctor

    settings = load_settings()
    code = run_doctor(settings)
    if code:
        sys.exit(code)


def _cmd_transcribe_file(path: str, paste: bool) -> None:
    from talk.audio import load_wav_mono
    from talk.backends.factory import build_backend
    from talk.config import load_settings
    from talk.paste import paste_text

    settings = load_settings()
    backend = build_backend(settings)
    chunk = load_wav_mono(path)
    text = backend.transcribe(chunk.samples, chunk.sample_rate).strip()

    if not text:
        print("[warn] No transcription text produced.")
        sys.exit(1)

    print(text)
    if paste:
        paste_text(text)


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "run":
        _cmd_run()
    elif args.command == "doctor":
        _cmd_doctor()
    elif args.command == "transcribe-file":
        _cmd_transcribe_file(args.path, args.paste)


if __name__ == "__main__":
    main()
