from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

_XDG_CONFIG = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
CONFIG_DIR = _XDG_CONFIG / "talk"


_MODIFIER_MAP = {
    "cmd": "<cmd>",
    "command": "<cmd>",
    "shift": "<shift>",
    "ctrl": "<ctrl>",
    "control": "<ctrl>",
    "alt": "<alt>",
    "option": "<alt>",
}

_KEY_MAP = {
    "space": "<space>",
    "enter": "<enter>",
    "return": "<enter>",
    "tab": "<tab>",
    "esc": "<esc>",
    "escape": "<esc>",
}


def _as_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "y", "on"}


def normalize_hotkey(raw_hotkey: str) -> str:
    parts = [part.strip().lower() for part in raw_hotkey.split("+") if part.strip()]
    normalized = []
    for part in parts:
        if part in _MODIFIER_MAP:
            normalized.append(_MODIFIER_MAP[part])
        elif part in _KEY_MAP:
            normalized.append(_KEY_MAP[part])
        elif part.startswith("<") and part.endswith(">"):
            inner = part[1:-1].lower()
            if inner in _KEY_MAP:
                normalized.append(_KEY_MAP[inner])
            else:
                normalized.append(f"<{inner}>")
        else:
            normalized.append(part)
    return "+".join(normalized)


@dataclass(slots=True)
class Settings:
    backend: str
    hotkey: str
    quit_hotkey: str
    autopaste: bool
    sample_rate: int
    channels: int
    min_seconds: float
    parakeet_model: str
    openai_api_key: str | None
    openai_model: str
    openai_language: str | None



def load_settings() -> Settings:
    load_dotenv()
    load_dotenv(CONFIG_DIR / ".env")

    backend = os.getenv("DICTATE_BACKEND", "parakeet").strip().lower()
    hotkey = normalize_hotkey(os.getenv("DICTATE_HOTKEY", "<ctrl>+<alt>+d"))
    quit_hotkey = normalize_hotkey(os.getenv("DICTATE_QUIT_HOTKEY", "<ctrl>+<alt>+q"))

    return Settings(
        backend=backend,
        hotkey=hotkey,
        quit_hotkey=quit_hotkey,
        autopaste=_as_bool(os.getenv("DICTATE_AUTOPASTE"), True),
        sample_rate=int(os.getenv("DICTATE_SAMPLE_RATE", "16000")),
        channels=int(os.getenv("DICTATE_CHANNELS", "1")),
        min_seconds=float(os.getenv("DICTATE_MIN_SECONDS", "0.35")),
        parakeet_model=os.getenv("PARAKEET_MODEL", "mlx-community/parakeet-tdt-0.6b-v3").strip(),
        openai_api_key=os.getenv("OPENAI_API_KEY"),
        openai_model=os.getenv("OPENAI_TRANSCRIBE_MODEL", "gpt-4o-transcribe").strip(),
        openai_language=(os.getenv("OPENAI_TRANSCRIBE_LANGUAGE") or "").strip() or None,
    )
