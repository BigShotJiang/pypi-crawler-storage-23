# Research Notes (February 25, 2026)

## Sources used

- OpenAI blog: [Introducing next-generation audio models](https://openai.com/index/introducing-our-next-generation-audio-models/)
- OpenAI Python SDK README (audio transcription examples): [openai/openai-python](https://github.com/openai/openai-python)
- NVIDIA model card (Parakeet CTC 1.1B): [nvidia/parakeet-ctc-1.1b](https://huggingface.co/nvidia/parakeet-ctc-1.1b)
- NVIDIA model card (Parakeet TDT 0.6B v2): [nvidia/parakeet-tdt-0.6b-v2](https://huggingface.co/nvidia/parakeet-tdt-0.6b-v2)
- Parakeet MLX implementation docs/repo: [Parakeet-MLX](https://github.com/senstella/parakeet-mlx)

## Key decisions

- Use **Parakeet locally by default** for near-zero marginal cost dictation on Apple Silicon.
- Use **OpenAI `gpt-4o-transcribe`** as a switchable fallback backend.
- Keep backend swapping to one env var (`DICTATE_BACKEND`) so the same UX works across engines.
