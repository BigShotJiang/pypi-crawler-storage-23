# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 - 2026 BMO Soluciones, S.A.
"""
Canonical version of coati_payroll.
"""

# 2026-02-19
__version__ = "1.8.1"
