__version__ = "0.0.1"
__license__ = "GNU Lesser General Public License v3.0 (LGPL-3.0)"
__copyright__ = "copyright 2017-present Dan <https://github.com/rwanlo>"

from concurrent.futures.thread import ThreadPoolExecutor


class StopTransmission(Exception):
    pass


class StopPropagation(StopAsyncIteration):
    pass


class ContinuePropagation(StopAsyncIteration):
    pass


from . import raw, types, filters, handlers, emoji, enums
from .client import Client
from .sync import idle, compose

def _wk() -> int:
    try:
        cpu_count = os.cpu_count() or 1
    except Exception:
        cpu_count = 1
    if cpu_count >= 8:
        return 4
    elif cpu_count >= 4:
        return 3
    elif cpu_count >= 2:
        return 2
    else:
        return 1


crypto_executor = ThreadPoolExecutor(
    max_workers=_wk(),
    thread_name_prefix="CryptoWorker",
)