import logging
from binascii import crc32
from struct import pack, unpack

from .tcp import TCP

log = logging.getLogger(__name__)


class TCPFull(TCP):
    def __init__(self, ipv6: bool, proxy: dict | None = None) -> None:
        super().__init__(ipv6, proxy)
        self.seq_no: int = 0

    async def connect(self, address: tuple[str, int]) -> None:
        await super().connect(address)
        self.seq_no = 0

    async def send(self, data: bytes) -> None:
        data = pack("<II", len(data) + 12, self.seq_no) + data
        data += pack("<I", crc32(data))
        self.seq_no += 1

        await super().send(data)

    async def recv(self, length: int = 0) -> bytes | None:
        length_bytes = await super().recv(4)

        if length_bytes is None:
            return None

        packet_length = unpack("<I", length_bytes)[0]
        packet = await super().recv(packet_length - 4)

        if packet is None:
            return None

        packet = length_bytes + packet
        checksum = packet[-4:]
        packet = packet[:-4]

        if crc32(packet) != unpack("<I", checksum)[0]:
            return None

        return packet[8:]
