# CRM CLI

A minimal CLI that reads leads from JSON/CSV files and syncs them to FXiaoke CRM (纷享销客).

## Installation

Requires [UV](https://docs.astral.sh/uv/) (fast Python package manager).

```bash
# Install UV (if not already installed)
brew install uv

# Clone and sync dependencies
git clone https://github.com/thaddeus-git/crm-cli.git
cd crm-cli
uv sync
```

## Quick Start

```bash
# Sync leads from JSON file
uv run crm sync leads.json

# Preview without creating (dry run)
uv run crm sync leads.csv --dry-run

# Assign to specific owner
uv run crm sync leads.json --owner FSUID_xxx

# Override lead pool
uv run crm sync leads.json --pool 643d87b17be47e0a000190a715
```

## Input Format

### JSON

```json
[
  {
    "company": "Acme Corp",
    "email": "contact@acme.com",
    "phone": "+44 123 456 7890",
    "country": "GB",
    "source_id": "optional-external-id"
  }
]
```

### CSV

```
company,email,phone,country,source_id
Acme Corp,contact@acme.com,+44 123 456 7890,GB,optional-external-id
```

### Fields

| Field | Required | Description |
|-------|----------|-------------|
| `company` | Yes | Company name |
| `email` | No | Email address |
| `phone` | No | Phone number (any format, cleaned automatically) |
| `country` | No | ISO 2-letter code (GB, DE, CN, etc.) for region/pool routing |
| `source_id` | No | External reference ID for logging |

## Configuration

Set environment variables:

```bash
export CRM_APP_ID="FSAID_xxx"
export CRM_APP_SECRET="xxx"
export CRM_PERMANENT_CODE="xxx"
export CRM_USER_MOBILE="19957895939"  # Optional, for user ID lookup
```

## Behavior

- **Duplicates**: Skip with warning, continue with remaining leads
- **Output**: Stdout only - progress and summary printed to terminal
- **Region routing**: Automatic based on country code
  - Europe (GB, DE, FR, etc.) → 欧洲线索公海池
  - Asia (CN, JP, KR, etc.) → 亚洲线索公海池

## Development

```bash
# Run tests
uv run python -m unittest discover tests/

# Run CLI
uv run crm sync --help
```

## License

MIT