"""
Unit tests for the CRM client with TokenManager.
"""

import unittest
import os
import sys
from unittest.mock import MagicMock, patch
import json
import time

# Add src directory to path
src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
sys.path.insert(0, src_path)

from fxiaoke_auth import TokenManager
from crm import CRMClient, CreateClientResult, FIELD_MAP


class TestCRMClient(unittest.TestCase):
    """Test CRM client functionality with TokenManager."""

    def setUp(self):
        """Set up test fixtures with mocked TokenManager."""
        self.mock_token_manager = MagicMock(spec=TokenManager)
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": 772631,
            "currentOpenUserId": "FSUID_TEST"
        }
        self.mock_token_manager.session = MagicMock()

        self.client = CRMClient(self.mock_token_manager)

    def test_initialization(self):
        """Test client initializes with TokenManager."""
        self.assertEqual(self.client.token_manager, self.mock_token_manager)
        self.assertEqual(self.client.session, self.mock_token_manager.session)

    def test_build_create_payload_basic(self):
        """Test building basic create payload with new field mappings."""
        lead_data = {
            'id': '123456',
            'full_name': 'Test Company',
            'email': 'test@example.com',
            'created_time': '2026-02-28T10:00:00+0000'
        }

        payload = self.client._build_create_payload(lead_data)

        # Check auth fields
        self.assertEqual(payload['corpId'], 772631)
        self.assertEqual(payload['corpAccessToken'], 'test_token')
        self.assertEqual(payload['currentOpenUserId'], 'FSUID_TEST')

        # Check data object with NEW field mappings
        object_data = payload['data']['object_data']
        self.assertEqual(object_data['dataObjectApiName'], FIELD_MAP['object_api'])
        self.assertEqual(object_data['name'], 'Test Company')
        self.assertEqual(object_data['record_type'], FIELD_MAP['record_type'])
        # NEW: Using field_7dDlL__c instead of field_h5Ezh__c
        self.assertEqual(object_data[FIELD_MAP['follow_status']], FIELD_MAP['follow_status_s1'])

        # Check optional fields
        self.assertEqual(object_data['email'], 'test@example.com')

    def test_build_create_payload_with_phone(self):
        """Test building payload with phone number using NEW field mapping."""
        lead_data = {
            'id': '123456',
            'company_name': 'Test Corp',
            'phone_number': '+44 7462 421289'
        }

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Phone should use NEW field: field_S737R__c (not field_50Fqg__c)
        self.assertIn(FIELD_MAP['phone'], object_data)
        self.assertEqual(object_data[FIELD_MAP['phone']], '447462421289')

    def test_build_create_payload_with_s1_timestamp(self):
        """Test building payload with S1 timestamp using NEW field mapping."""
        lead_data = {
            'id': '123456',
            'full_name': 'Test Company',
            'created_time': '2026-02-28T10:00:00+0000'
        }

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Should use field_aw71X__c (not field_lskUm__c)
        self.assertIn(FIELD_MAP['s1_timestamp'], object_data)

    def test_build_create_payload_creates_leads_obj(self):
        """Test that payload creates LeadsObj (线索) not AccountObj (客户)."""
        lead_data = {
            'id': '123456',
            'company_name': 'Test Company',
            'email': 'test@example.com'
        }

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Should create LeadsObj, not AccountObj
        self.assertEqual(object_data['dataObjectApiName'], 'LeadsObj')
        # Should have S1-待跟进 status
        self.assertEqual(object_data[FIELD_MAP['follow_status']], FIELD_MAP['follow_status_s1'])

    def test_build_create_payload_includes_remark(self):
        """Test payload includes remark for lead pool routing."""
        lead_data = {
            'id': '123456',
            'company_name': 'Test Company',
            'email': 'test@example.com'
        }

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        self.assertEqual(
            object_data['remark'],
            "This should be updated according to the lead generation country"
        )

    def test_clean_phone(self):
        """Test phone number cleaning."""
        self.assertEqual(self.client._clean_phone('+44 7462 421289'), '447462421289')
        self.assertEqual(self.client._clean_phone('123-456-7890'), '1234567890')
        self.assertEqual(self.client._clean_phone('(123) 456-7890'), '1234567890')
        self.assertEqual(self.client._clean_phone(''), '')

    def test_extract_company_name_fallback(self):
        """Test company name extraction with fallback."""
        # Test with full_name
        self.assertEqual(
            self.client._extract_company_name({'full_name': 'Company A'}),
            'Company A'
        )

        # Test with company_name
        self.assertEqual(
            self.client._extract_company_name({'company_name': 'Company B'}),
            'Company B'
        )

        # Test fallback
        self.assertEqual(
            self.client._extract_company_name({}),
            'Unknown Company'
        )

    def test_extract_company_name_prefers_company_over_person(self):
        """Test that company_name is preferred over full_name for B2B CRM."""
        # Lead with both person name and company name
        lead_data = {
            'full_name': 'Patsy Flintoft',
            'company_name': 'Kings Catering Company Ltd',
            'email': 'patsy@example.com'
        }

        company = self.client._extract_company_name(lead_data)
        self.assertEqual(company, 'Kings Catering Company Ltd')

        # Fallback to full_name when company_name missing
        lead_no_company = {'full_name': 'John Doe', 'email': 'john@example.com'}
        company_fallback = self.client._extract_company_name(lead_no_company)
        self.assertEqual(company_fallback, 'John Doe')

    def test_parse_created_time_iso(self):
        """Test parsing ISO format timestamp."""
        result = self.client._parse_created_time('2026-02-28T10:00:00+0000')
        self.assertIsInstance(result, int)
        self.assertGreater(result, 1000000000000)

    def test_parse_created_time_invalid(self):
        """Test parsing invalid timestamp."""
        result = self.client._parse_created_time('invalid')
        self.assertIsNone(result)

        result = self.client._parse_created_time(None)
        self.assertIsNone(result)

    def test_create_client_success(self):
        """Test successful client creation."""
        # Mock response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'data': {'_id': 'crm_client_123'},
            'errorCode': 0
        }
        self.mock_token_manager.session.post.return_value = mock_response

        lead_data = {
            'id': 'fb_lead_123',
            'full_name': 'Test Company',
            'email': 'test@example.com'
        }

        result = self.client.create_client(lead_data)

        self.assertTrue(result.success)
        self.assertEqual(result.crm_client_id, 'crm_client_123')
        self.assertFalse(result.is_duplicate)
        self.assertIsNone(result.error)

    def test_create_client_duplicate_returns_warning(self):
        """Test duplicate detection returns warning (not error)."""
        # Mock duplicate response
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'errorCode': 400,
            'errorDescription': 'Duplicate company found'
        }
        self.mock_token_manager.session.post.return_value = mock_response

        lead_data = {
            'id': 'fb_lead_123',
            'full_name': 'Existing Company'
        }

        result = self.client.create_client(lead_data)

        self.assertFalse(result.success)
        self.assertTrue(result.is_duplicate)
        self.assertIsNotNone(result.warning)  # Warning, not error
        self.assertIsNone(result.error)

    def test_create_client_duplicate_with_allow_update(self):
        """Test duplicate with allow_update=True."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            'errorCode': 400,
            'errorDescription': 'Duplicate company found'
        }
        self.mock_token_manager.session.post.return_value = mock_response

        lead_data = {'id': 'fb_lead_123', 'full_name': 'Existing Company'}

        result = self.client.create_client(lead_data, allow_update=True)

        self.assertFalse(result.success)
        self.assertTrue(result.is_duplicate)
        self.assertEqual(result.warning, "Duplicate found - update not implemented")

    def test_create_client_token_expired_retries(self):
        """Test that 20016 error triggers token refresh and retry."""
        # First response: token expired
        mock_response_1 = MagicMock()
        mock_response_1.status_code = 200
        mock_response_1.json.return_value = {'errorCode': 20016}

        # Second response (after retry): success
        mock_response_2 = MagicMock()
        mock_response_2.status_code = 200
        mock_response_2.json.return_value = {
            'data': {'_id': 'crm_client_123'},
            'errorCode': 0
        }

        # Setup sequential responses
        self.mock_token_manager.session.post.side_effect = [mock_response_1, mock_response_2]

        lead_data = {'id': 'fb_lead_123', 'full_name': 'Test Company'}
        result = self.client.create_client(lead_data)

        # Should have retried
        self.assertEqual(self.mock_token_manager.session.post.call_count, 2)
        # Token refresh should have been called
        self.mock_token_manager.get_corp_access_token.assert_called_with(force_refresh=True)
        # Final result should be success
        self.assertTrue(result.success)

    def test_create_client_auth_failure(self):
        """Test creation fails when auth headers not available."""
        self.mock_token_manager.get_auth_headers.return_value = None

        lead_data = {'id': 'fb_lead_123', 'full_name': 'Test Company'}

        with self.assertRaises(ValueError) as context:
            self.client.create_client(lead_data)

        self.assertIn("Authentication failed", str(context.exception))

    def test_extract_client_id_from_dataId(self):
        """Test extracting client ID from CRM's dataId field (actual API response format)."""
        # Actual CRM response format: {"dataId": "xxx", "errorCode": 0, ...}
        response = {
            'traceId': 'E-O.lhxk2023.1075-20260228120946-884ae5',
            'dataId': '69a26a8bb304970007036569',
            'errorMessage': 'OK',
            'errorCode': 0
        }

        client_id = self.client._extract_client_id(response)
        self.assertEqual(client_id, '69a26a8bb304970007036569')


class TestCreateClientResult(unittest.TestCase):
    """Test CreateClientResult dataclass."""

    def test_success_result(self):
        """Test successful result."""
        result = CreateClientResult(
            success=True,
            crm_client_id='client_123'
        )
        self.assertTrue(result.success)
        self.assertEqual(result.crm_client_id, 'client_123')
        self.assertFalse(result.is_duplicate)
        self.assertIsNone(result.error)

    def test_duplicate_result_with_warning(self):
        """Test duplicate result with warning field."""
        result = CreateClientResult(
            success=False,
            is_duplicate=True,
            warning='Company already exists in CRM'
        )
        self.assertFalse(result.success)
        self.assertTrue(result.is_duplicate)
        self.assertEqual(result.warning, 'Company already exists in CRM')
        self.assertIsNone(result.error)


class TestFieldMappings(unittest.TestCase):
    """Test that field mappings are correct."""

    def test_follow_status_field(self):
        """Test follow status field is correct."""
        self.assertEqual(FIELD_MAP['follow_status'], 'field_7dDlL__c')

    def test_follow_status_s1_value(self):
        """Test S1 follow status value is correct."""
        self.assertEqual(FIELD_MAP['follow_status_s1'], '7e8T541Vr')

    def test_phone_field(self):
        """Test phone field is correct."""
        self.assertEqual(FIELD_MAP['phone'], 'field_S737R__c')

    def test_s1_timestamp_field(self):
        """Test S1 timestamp field is correct."""
        self.assertEqual(FIELD_MAP['s1_timestamp'], 'field_aw71X__c')

    def test_record_type(self):
        """Test record type is correct."""
        self.assertEqual(FIELD_MAP['record_type'], 'default__c')


class TestLeadPoolAssignment(unittest.TestCase):
    """Test lead pool ID assignment."""

    def setUp(self):
        """Set up test fixtures with mocked TokenManager."""
        self.mock_token_manager = MagicMock(spec=TokenManager)
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": 772631,
            "currentOpenUserId": "FSUID_TEST"
        }
        self.mock_token_manager.session = MagicMock()
        self.client = CRMClient(self.mock_token_manager)

    def test_get_leads_pool_id_europe(self):
        """Test Europe country returns Europe pool ID."""
        # GB (UK) should go to Europe pool
        pool_id = self.client._get_leads_pool_id('GB')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')  # 欧洲池

    def test_get_leads_pool_id_germany(self):
        """Test Germany returns Europe pool ID."""
        pool_id = self.client._get_leads_pool_id('DE')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')  # 欧洲池

    def test_get_leads_pool_id_asia(self):
        """Test Asia country returns Asia pool ID."""
        # CN (China) should go to Asia pool
        pool_id = self.client._get_leads_pool_id('CN')
        self.assertEqual(pool_id, '643d87cda34e0a0001336093')  # 亚洲池

    def test_get_leads_pool_id_japan(self):
        """Test Japan returns Asia pool ID."""
        pool_id = self.client._get_leads_pool_id('JP')
        self.assertEqual(pool_id, '643d87cda34e0a0001336093')  # 亚洲池

    def test_get_leads_pool_id_unknown(self):
        """Test unknown country defaults to Europe pool."""
        pool_id = self.client._get_leads_pool_id('US')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')  # 欧洲池

    def test_get_leads_pool_id_empty(self):
        """Test empty country defaults to Europe pool."""
        pool_id = self.client._get_leads_pool_id('')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')  # 欧洲池


class TestOwnerFsuid(unittest.TestCase):
    """Test owner FSUID parameter."""

    def setUp(self):
        """Set up test fixtures with mocked TokenManager."""
        self.mock_token_manager = MagicMock(spec=TokenManager)
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": 772631,
            "currentOpenUserId": "FSUID_TEST"
        }
        self.mock_token_manager.session = MagicMock()

    def test_build_create_payload_with_owner(self):
        """Test building payload with custom owner FSUID."""
        # Create client with custom owner (using 瞿吉笑's FSUID as example)
        owner_fsuid = "FSUID_C3F0FA243B2B385385D570C8968C8AB3"
        client = CRMClient(self.mock_token_manager, owner_fsuid=owner_fsuid)

        lead_data = {
            'id': 'fb_123',
            'company_name': 'Test Company',
            'email': 'test@example.com',
            'country': 'GB'
        }

        payload = client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Should include owner field
        self.assertIn('owner', object_data)
        self.assertEqual(object_data['owner'], [owner_fsuid])

    def test_build_create_payload_without_owner(self):
        """Test building payload without custom owner (default behavior)."""
        # Create client without custom owner
        client = CRMClient(self.mock_token_manager)

        lead_data = {
            'id': 'fb_123',
            'company_name': 'Test Company',
            'email': 'test@example.com'
        }

        payload = client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Should NOT include owner field (uses default)
        self.assertNotIn('owner', object_data)

    def test_owner_fsuid_with_lead_pool_assignment(self):
        """Test owner_fsuid works correctly with leads_pool_id assignment."""
        owner_fsuid = "FSUID_TEST_OWNER_12345"
        client = CRMClient(self.mock_token_manager, owner_fsuid=owner_fsuid)

        lead_data = {
            'id': 'fb_123',
            'company_name': 'Test Company',
            'country': 'GB'  # Europe country
        }

        payload = client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Verify BOTH owner AND leads_pool_id are present
        self.assertIn('owner', object_data)
        self.assertEqual(object_data['owner'], [owner_fsuid])
        self.assertEqual(object_data['leads_pool_id'], '643d87b17be47e0a000190a715')

    def test_build_create_payload_empty_owner_fsuid_treated_as_none(self):
        """Test empty string owner_fsuid is treated as None (no owner field)."""
        client = CRMClient(self.mock_token_manager, owner_fsuid="")

        lead_data = {'id': 'fb_123', 'company_name': 'Test Company'}
        payload = client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Empty string should NOT include owner field
        self.assertNotIn('owner', object_data)


class TestRegionField(unittest.TestCase):
    """Test region field (field_g60ab__c) assignment."""

    def setUp(self):
        self.mock_token_manager = MagicMock(spec=TokenManager)
        self.mock_token_manager.get_auth_headers.return_value = {
            "corpAccessToken": "test_token",
            "corpId": 772631,
            "currentOpenUserId": "FSUID_TEST"
        }
        self.mock_token_manager.session = MagicMock()
        self.client = CRMClient(self.mock_token_manager)

    def test_build_create_payload_includes_region_field_europe(self):
        """Test payload includes region field (field_g60ab__c) for Europe country."""
        lead_data = {'id': 'fb_123', 'company_name': 'Test Company', 'country': 'GB'}

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Verify region field is set
        self.assertIn('field_g60ab__c', object_data)
        self.assertEqual(object_data['field_g60ab__c'], '1dKGudtaC')  # 欧洲

    def test_build_create_payload_asia_region(self):
        """Test payload includes Asia region field."""
        lead_data = {'id': 'fb_123', 'company_name': 'Test Company', 'country': 'CN'}

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        self.assertEqual(object_data['field_g60ab__c'], '5yF9DohVi')  # 亚洲

    def test_build_create_payload_unknown_country_no_region_field(self):
        """Test unknown country does NOT include region field."""
        lead_data = {'id': 'fb_123', 'company_name': 'Test Company', 'country': 'US'}

        payload = self.client._build_create_payload(lead_data)
        object_data = payload['data']['object_data']

        # Unknown country should NOT have region field (returns None)
        self.assertNotIn('field_g60ab__c', object_data)

    def test_get_leads_pool_id_lowercase_country(self):
        """Test lowercase country code is handled correctly."""
        pool_id = self.client._get_leads_pool_id('gb')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')

    def test_get_leads_pool_id_france_europe(self):
        """Test France returns Europe pool ID."""
        pool_id = self.client._get_leads_pool_id('FR')
        self.assertEqual(pool_id, '643d87b17be47e0a000190a715')

    def test_get_leads_pool_id_korea_asia(self):
        """Test South Korea returns Asia pool ID."""
        pool_id = self.client._get_leads_pool_id('KR')
        self.assertEqual(pool_id, '643d87cda34e0a0001336093')


if __name__ == '__main__':
    unittest.main()
