DOWNLOAD_URL = "https://speed.cloudflare.com/__down?bytes=25000000"
UPLOAD_URL = "https://speed.cloudflare.com/__up"
PING_HOST = "1.1.1.1"
PING_PORT = 443
PING_COUNT = 5
TEST_DURATION = 10  # seconds
UPLOAD_CHUNK_SIZE = 256 * 1024  # 256 KB

GREEN = "\033[92m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"
DIM = "\033[2m"
