import time
import socket
import threading
import argparse
import requests
import config


def format_speed(mbps):
    if mbps >= 1000:
        return f"{mbps / 1000:.2f} Gbps"
    if mbps >= 1:
        return f"{mbps:.1f} Mbps"
    return f"{mbps * 1000:.1f} Kbps"


def measure_ping():
    times = []
    for _ in range(config.PING_COUNT):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5)
            start = time.perf_counter()
            s.connect((config.PING_HOST, config.PING_PORT))
            times.append((time.perf_counter() - start) * 1000)
            s.close()
        except Exception:
            pass
    return sum(times) / len(times) if times else None


def measure_download(verbose=False):
    total_bytes = 0
    lock = threading.Lock()
    stop = threading.Event()

    def fetch():
        nonlocal total_bytes
        try:
            with requests.get(config.DOWNLOAD_URL, stream=True, timeout=30) as r:
                for chunk in r.iter_content(chunk_size=64 * 1024):
                    if stop.is_set():
                        break
                    with lock:
                        total_bytes += len(chunk)
        except Exception:
            pass

    threads = [threading.Thread(target=fetch) for _ in range(4)]
    start = time.time()
    for t in threads:
        t.start()

    last = 0
    while time.time() - start < config.TEST_DURATION:
        time.sleep(0.5)
        with lock:
            current = total_bytes
        mbps = (current - last) * 8 / 1e6 / 0.5
        last = current
        if verbose:
            elapsed = time.time() - start
            bar = _bar(elapsed, config.TEST_DURATION)
            print(f"\r{config.DIM}Download {bar}{config.RESET} {config.GREEN}{format_speed(mbps):>12}{config.RESET}", end="", flush=True)

    stop.set()
    for t in threads:
        t.join()
    if verbose:
        print()

    return total_bytes * 8 / 1e6 / (time.time() - start)


def measure_upload(verbose=False):
    total_bytes = 0
    lock = threading.Lock()
    stop = threading.Event()
    payload = b"x" * config.UPLOAD_CHUNK_SIZE

    def push():
        nonlocal total_bytes
        while not stop.is_set():
            try:
                requests.post(config.UPLOAD_URL, data=payload, timeout=15)
                with lock:
                    total_bytes += config.UPLOAD_CHUNK_SIZE
            except Exception:
                break

    threads = [threading.Thread(target=push) for _ in range(4)]
    start = time.time()
    for t in threads:
        t.start()

    last = 0
    while time.time() - start < config.TEST_DURATION:
        time.sleep(0.5)
        with lock:
            current = total_bytes
        mbps = (current - last) * 8 / 1e6 / 0.5
        last = current
        if verbose:
            elapsed = time.time() - start
            bar = _bar(elapsed, config.TEST_DURATION)
            print(f"\r{config.DIM}Upload   {bar}{config.RESET} {config.CYAN}{format_speed(mbps):>12}{config.RESET}", end="", flush=True)

    stop.set()
    for t in threads:
        t.join()
    if verbose:
        print()

    return total_bytes * 8 / 1e6 / (time.time() - start)


def _bar(elapsed, total, width=20):
    filled = int(width * min(elapsed / total, 1))
    return f"[{'#' * filled}{'-' * (width - filled)}]"


def main():
    parser = argparse.ArgumentParser(prog="fast", description="CLI speed test")
    parser.add_argument("-d", "--download", action="store_true")
    parser.add_argument("-u", "--upload", action="store_true")
    parser.add_argument("-v", "--verbose", action="store_true")
    args = parser.parse_args()

    do_download = args.download or not (args.download or args.upload)
    do_upload = args.upload or not (args.download or args.upload)

    print(f"{config.BOLD}fast-cli{config.RESET}\n")

    ping = measure_ping()
    if ping:
        print(f"Ping:     {ping:.1f} ms\n")

    if do_download:
        if not args.verbose:
            print(f"{config.DIM}Testing download...{config.RESET}", end="", flush=True)
        dl = measure_download(verbose=args.verbose)
        label = f"{config.GREEN}{config.BOLD}Download:{config.RESET}"
        print(f"\r{label} {config.GREEN}{format_speed(dl)}{config.RESET}")

    if do_upload:
        if not args.verbose:
            print(f"{config.DIM}Testing upload...{config.RESET}", end="", flush=True)
        ul = measure_upload(verbose=args.verbose)
        label = f"{config.CYAN}{config.BOLD}Upload:  {config.RESET}"
        print(f"\r{label} {config.CYAN}{format_speed(ul)}{config.RESET}")


if __name__ == "__main__":
    main()
