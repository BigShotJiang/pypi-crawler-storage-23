import subprocess
import sys
from pathlib import Path
from .utils import get_binary_path

def decompile(pyc_file: str, output_file: str = None) -> str:
    """
    Decompile a .pyc file and return the source code as a string.
    If output_file is given, write the source to that file.
    """
    pyc_path = Path(pyc_file).resolve()
    if not pyc_path.exists():
        raise FileNotFoundError(f"File not found: {pyc_file}")

    binary = get_binary_path()
    cmd = [str(binary), str(pyc_path)]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        source = result.stdout
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Decompilation failed: {e.stderr}") from e

    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(source)

    return source

def decompile_file(pyc_file: str, output_file: str = None):
    """Convenience alias for decompile()"""
    return decompile(pyc_file, output_file)