"""
danger-decompyler – A Python 3.12 compatible .pyc decompiler wrapper around pycdc.
"""

__version__ = "0.1.0"

from .core import decompile, decompile_file

__all__ = ["decompile", "decompile_file"]