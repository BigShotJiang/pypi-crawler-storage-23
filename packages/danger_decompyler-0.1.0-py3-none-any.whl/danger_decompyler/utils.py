import platform
import sys
from pathlib import Path

def get_binary_path():
    """Return path to the pycdc binary appropriate for the current platform."""
    system = platform.system().lower()
    machine = platform.machine().lower()

    # Map platform to binary filename (adjust according to your bundled binaries)
    if system == "windows":
        binary_name = "pycdc.exe"
    elif system == "darwin":
        binary_name = "pycdc_macos"
    elif system == "linux":
        if "x86_64" in machine:
            binary_name = "pycdc_linux64"
        else:
            raise RuntimeError(f"Unsupported Linux architecture: {machine}")
    else:
        raise RuntimeError(f"Unsupported OS: {system}")

    # Look in the binaries folder next to this file
    binary_path = Path(__file__).parent / "binaries" / binary_name
    if not binary_path.exists():
        raise FileNotFoundError(f"Binary not found: {binary_path}")

    # Ensure executable (Unix)
    if system != "windows":
        binary_path.chmod(0o755)

    return binary_path