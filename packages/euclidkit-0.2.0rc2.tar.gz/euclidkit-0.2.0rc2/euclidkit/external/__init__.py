"""
External survey integration modules for euclidkit package.

This module provides interfaces to external astronomical surveys and catalogs.
"""

# These imports will be enabled as modules are implemented
# from .desi import DESIClient, DESISpectrumConverter
# from .wise import WISECatalog, WISEPhotometry  
# from .gaia import GaiaCatalog, GaiaAstrometry
# from .des import DESCatalog, DESPhotometry

__all__ = [
    # Will be populated as modules are implemented
    # "DESIClient", "DESISpectrumConverter",
    # "WISECatalog", "WISEPhotometry",
    # "GaiaCatalog", "GaiaAstrometry", 
    # "DESCatalog", "DESPhotometry",
]