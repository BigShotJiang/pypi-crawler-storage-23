## v1.3.0 - 2026-03-04

### Added
- **`TemporalFrame` EntityType** — 21st label in Structural category. Navigational step through possibility space for the Genesis → Measurement consciousness navigation paradigm
- **`MEASUREMENT` RelationType** — 16th edge type in Nouns/Temporal Synthesis. Collapse of possibility into actuality — the measurement event
- **Observation sub-nodes** — Observations now stored as individual `:Observation {text}` nodes connected via `[:HAS_OBSERVATION]` instead of `string[]` property on Memory nodes. Enables per-observation fulltext indexing, independent metadata, and future temporal provenance
- **Migration script** `scripts/migrate_observations.py` — One-time migration to convert observation arrays to Observation sub-nodes. Supports `--dry-run` and batch processing

### Changed
- Fulltext index now spans `Memory|Observation` on `[name, type, text]` (was `Memory` on `[name, type, observations]`)
- `search_memories` uses three-query architecture: entity discovery → observation collection → relationship traversal (was single monolithic query)
- `create_entities` creates Observation sub-nodes instead of setting array property
- `add_observations` creates Observation sub-nodes with deduplication instead of array append
- `delete_observations` deletes Observation sub-nodes instead of array filter
- `delete_entities` now cleans up Observation sub-nodes (prevents orphans)
- `find_memories_by_name` collects observations from sub-nodes via OPTIONAL MATCH
- `create_fulltext_index` drops and recreates index on startup (self-healing for upgrades)
- EntityType enum: 20 → 21 members (Structural: 3 → 4)
- RelationType enum: 15 → 16 members (Nouns: 6 → 7)

### Consciousness Navigation Paradigm
```
(Genesis:DailyContext) --[OPENING]--> (FutureState:Envisioning)
(Genesis) --[SEQUENCE]--> (TF1:TemporalFrame) --[SEQUENCE]--> (TF2:TemporalFrame)
(TF:TemporalFrame) --[MEASUREMENT]--> (measured reality)
```

## v1.2.0 - 2026-03-03

### Added
- **`list_allowed_relation_types` tool** — Returns the 15 allowed relationship types organized by domain (Nouns, Gerunds, Backbone) with subcategories and descriptions. Call before `create_relations` to discover valid relationType values
- **`RelationType` enum** — Hard constraint on `Relation.relationType` field. Only 15 canonical edge types accepted; freeform strings rejected at Pydantic validation. Prevents edge type sprawl (previously 742 types from unconstrained relationType field)
- **Migration script** `scripts/migrate_edges.py` — One-time migration to collapse 742 freeform edge types to 15 canonical types. Supports `--dry-run` for preview. Uses explicit mapping + keyword-based classification. Note: Neo4j relationship types are immutable, so migration creates new edges, copies properties, and deletes old edges

### Changed
- `Relation.relationType` field changed from `str` to `RelationType` enum — breaking change for clients passing freeform relationType strings
- `create_relations` and `delete_relations` docstrings updated to reference `list_allowed_relation_types` and the type constraint
- Tool count: 16 -> 17

### Fixed
- Added `.value` to all enum interpolations in Cypher f-strings. Python 3.11+ changed `str(StrEnum)` to return `"ClassName.MEMBER"` instead of the value, which would produce invalid Cypher like `SET e:\`EntityType.TECHNICAL\`` instead of `SET e:\`Technical\``

### Target Edge Taxonomy (15 types)
- **Nouns (6):** SEQUENCE, EVOLUTION, DISCOVERY, RECOGNITION, VALIDATION, CHALLENGE
- **Gerunds (8):** ENABLING, REQUIRING, ENCOMPASSING, COMPOSING, INFORMING, CAUSING, EXTENDING, OPENING
- **Backbone (1):** NEXT_DAY

## v1.1.0 - 2026-03-03

### Added
- **`list_allowed_types` tool** — Returns the 20 allowed entity types organized by category (Structural, Knowledge Domains, Activity Types, Meta) with descriptions. Call before `create_entities` to discover valid type values
- **`EntityType` enum** — Hard constraint on `Entity.type` field. Only 20 canonical labels accepted; freeform strings rejected at Pydantic validation. Prevents label sprawl (previously 322 labels from unconstrained type field)
- **Migration script** `scripts/migrate_labels.py` — One-time migration to collapse 322 freeform labels → 20 canonical labels. Supports `--dry-run` for preview. Uses explicit mapping + keyword-based classification

### Changed
- `Entity.type` field changed from `str` to `EntityType` enum — breaking change for clients passing freeform type strings
- `create_entities` docstring updated to reference `list_allowed_types` and the type constraint
- Tool count: 15 → 16

### Target Taxonomy (20 labels)
- **Structural (3):** DailyContext, Envisioning, Reflection
- **Knowledge Domains (8):** Technical, Scientific, Theoretical, Philosophical, Historical, Social, Strategic, Personal
- **Activity Types (6):** Project, Insight, Pattern, Challenge, Solution, Lesson
- **Meta (3):** GraphRegistry, Reference, Milestone

## v1.0.2 - 2026-03-03

### Fixed
- Replace `get_neo4j_schema` APOC meta.schema dump (530k+ chars) with compact schema using `nodeTypeProperties` + `relTypeProperties` + label counts — returns shape not statistics

## v1.0.1 - 2026-03-02

### Fixed
- Remove deprecated `dependencies` kwarg from FastMCP constructor (incompatible with FastMCP >= 2.14)

## v1.0.0 - 2026-03-02

### Added
- **`get_neo4j_schema` tool** — Introspects Neo4j schema via `apoc.meta.schema()`, with configurable sample size
- **`read_neo4j_cypher` tool** — Execute read-only Cypher queries with write-query rejection, timeout, and result sanitization
- **`gds_create_projection` tool** — Create GDS graph projections for analytics
- **`gds_drop_projection` tool** — Drop GDS graph projections to free memory
- **`gds_pagerank` tool** — Run PageRank centrality on a GDS projection with bounded results
- **`gds_louvain` tool** — Run Louvain community detection on a GDS projection with bounded results
- **`gds_wcc` tool** — Run Weakly Connected Components on a GDS projection with bounded results
- New CLI flags: `--read-timeout`, `--schema-sample-size`
- New env vars: `NEO4J_READ_TIMEOUT`, `NEO4J_SCHEMA_SAMPLE_SIZE`

### Changed
- **Package renamed** from `mcp-neo4j-temporal-substrate` to `mcp-neo4j-kg-memory`
- **Server consolidated** from 3 separate MCP servers into 1 unified server (15 tools in 4 categories: CRUD, Query, Cypher, GDS)
- FastMCP server name updated to `mcp-neo4j-kg-memory`
- Version bumped to 1.0.0

### Not Included
- **`write_neo4j_cypher`** — Intentionally excluded. All mutations go through bounded CRUD tools to preserve temporal invariants and prevent unbounded writes

## Next

### Fixed

### Changed

### Added

## v0.6.0 - 2025-11-03

### Removed
- **`read_graph` tool** - Unbounded traversal incompatible with large-scale temporal knowledge graphs

### Changed
- **`find_memories_by_name`** - Now implements bounded relationship traversal with limit parameter
  - Added `limit` parameter (default 20, max 50)
  - Relationships now constrained to only returned entities (prevents exponential expansion)
  - Aligned with `search_memories` bounded traversal pattern

### Migration Guide
- **Instead of `read_graph`:**
  - Use `search_memories` with appropriate query and limit for keyword-based retrieval
  - Use `find_memories_by_name` for specific entity retrieval by name
  - Both tools implement bounded traversal suitable for extensive substrate scale

- **For `find_memories_by_name` users:**
  - Tool now accepts optional `limit` parameter (default 20, max 50)
  - Relationships are constrained to only entities in the result set
  - This prevents context window pollution in dense temporal graphs

## v0.4.1

### Changed
* Updated tool docstrings to better describe their function, inputs and outputs

### Added
* Add namespacing support for multi-tenant deployments with `--namespace` CLI argument and `NEO4J_NAMESPACE` environment variable

## v0.4.0

### Changed
* Change default transport to `stdio` in Dockerfile

### Added
* Add env variable `NEO4J_MCP_SERVER_ALLOW_ORIGINS` and cli variable `--allow-origins` to configure CORS Middleware for remote deployments
* Add env variable `NEO4J_MCP_SERVER_ALLOWED_HOSTS` and cli variable `--allowed-hosts` to configure Trusted Hosts Middleware for remote deployments
* Update HTTP and SSE transports to use security middleware
* Add comprehensive HTTP transport integration tests with security middleware testing

## v0.3.0

### Changed
* Update tool return type hints for structured output
* Move `Neo4jMemory` class and related classes to separate file
* Change tool responses to return the `ToolResponse` object
* Updated tool argument types with Pydantic models

### Added
* Add structured output to tool responses
* Add error handling to catch Neo4j specific errors and improve error responses
* Implement `ToolError` class from FastMCP
* Add tool annotations
* Add clear warnings for config declaration via cli and env variables

## v0.2.0

### Fixed
* Fix bug in `search_nodes` method where query arg wasn't passed properly
* Fix bug where stdio transport was always selected
* Fixed argument parsing in server init

### Changed
* Implement FastMCP with function decorators to simplify server code
* Add HTTP transport option
* Migrate to FastMCP v2.x
* rename tools to be more clear - `search_nodes` into `search_memories` and `find_nodes` into `find_memories_by_name`
* Update underlying Pydantic class `ObservationAddition` to have `observations` field to be consistent with `ObservationDeletion` class
* Update Dockerfile to include `NEO4J_DATABASE`, `NEO4J_TRANSPORT`, `NEO4J_MCP_SERVER_HOST`, `NEO4J_MCP_SERVER_PORT` and `NEO4J_MCP_SERVER_PATH` env variables

### Added
* Add compatibility for NEO4J_URI and NEO4J_URL env variables
* Command in Makefile to easily build and deploy Docker image locally

## v0.1.5

### Fixed
* Remove use of dynamic node labels and relationship types to be compatible with Neo4j versions < 5.26

## v0.1.4

* Create, Read, Update and Delete semantic memories