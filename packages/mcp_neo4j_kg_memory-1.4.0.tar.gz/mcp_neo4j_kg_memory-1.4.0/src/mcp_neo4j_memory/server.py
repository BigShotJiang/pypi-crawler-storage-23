import json
import logging
from typing import Any, Literal

from neo4j import AsyncGraphDatabase, Query, RoutingControl
from pydantic import Field
from starlette.middleware import Middleware
from starlette.middleware.cors import CORSMiddleware
from starlette.middleware.trustedhost import TrustedHostMiddleware

from fastmcp.server import FastMCP
from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import TextContent
from neo4j.exceptions import Neo4jError, ClientError
from mcp.types import ToolAnnotations

# Monkey patch FastMCP to support full HTTP method suite outside of auth required path
from fastmcp.server import http as fastmcp_http
from starlette.routing import Route

from .neo4j_memory import Neo4jMemory, Entity, EntityType, ENTITY_TYPE_DESCRIPTIONS, Relation, RelationType, RELATION_TYPE_DESCRIPTIONS, ObservationAddition, ObservationDeletion, KnowledgeGraph
from .utils import format_namespace, _is_write_query, _value_sanitize

# Set up logging
logger = logging.getLogger('mcp_neo4j_memory')
logger.setLevel(logging.INFO)

# Monkey-patch the bug in FastMCP 2.13.0.2
_original_create_streamable_http_app = fastmcp_http.create_streamable_http_app


def patched_create_streamable_http_app(*args, **kwargs):
    app = _original_create_streamable_http_app(*args, **kwargs)

    # Fix the missing methods in the Route
    # The streamable HTTP endpoint is at the specified path
    streamable_http_path = kwargs.get('streamable_http_path', '/mcp')

    for i, route in enumerate(app.routes):
        if isinstance(route, Route) and route.path == streamable_http_path:
            # Check if methods are missing (they will be None or empty)
            if not route.methods or route.methods == ['GET']:
                # Recreate the route with correct methods
                app.routes[i] = Route(
                    route.path,
                    endpoint=route.endpoint,
                    methods=["GET", "POST", "DELETE"]
                )
                logger.info(f"Patched route {route.path} to accept GET, POST, DELETE")
                break

    return app


# Apply the monkey patch
fastmcp_http.create_streamable_http_app = patched_create_streamable_http_app

def create_mcp_server(
    memory: Neo4jMemory,
    namespace: str = "",
    read_timeout: int = 30,
    schema_sample_size: int = 1000,
) -> FastMCP:
    """Create an MCP server instance for memory management."""

    namespace_prefix = format_namespace(namespace)
    mcp: FastMCP = FastMCP("mcp-neo4j-kg-memory")

    @mcp.tool(
        name=namespace_prefix + "create_entities",
        annotations=ToolAnnotations(title="Create Entities", 
                                          readOnlyHint=False, 
                                          destructiveHint=False, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def create_entities(entities: list[Entity] = Field(..., description="List of entities to create with name, type, and observations")) -> ToolResult:
        """Create multiple new entities in the knowledge graph.

        Creates new memory entities with their associated observations. If an entity with the same name
        already exists, this operation will merge the observations with existing ones.

        IMPORTANT: The `type` field must be one of the 21 allowed EntityType values.
        Call `list_allowed_types` to see all valid types. Invalid types will be rejected.

        Returns:
            list[Entity]: The created entities with their final state

        Example call:
        {
            "entities": [
                {
                    "name": "Alice Johnson",
                    "type": "Personal",
                    "observations": ["Software engineer", "Lives in Seattle", "Enjoys hiking"]
                },
                {
                    "name": "Microsoft",
                    "type": "Reference",
                    "observations": ["Technology company", "Headquartered in Redmond, WA"]
                }
            ]
        }
        """
        logger.info(f"MCP tool: create_entities ({len(entities)} entities)")
        try:
            entity_objects = [Entity.model_validate(entity) for entity in entities]
            result = await memory.create_entities(entity_objects)
            return ToolResult(content=[TextContent(type="text", text=json.dumps([e.model_dump() for e in result]))],
                          structured_content={"result": result})
        except Neo4jError as e:
            logger.error(f"Neo4j error creating entities: {e}")
            raise ToolError(f"Neo4j error creating entities: {e}")
        except Exception as e:
            logger.error(f"Error creating entities: {e}")
            raise ToolError(f"Error creating entities: {e}")

    @mcp.tool(
        name=namespace_prefix + "create_relations",
        annotations=ToolAnnotations(title="Create Relations", 
                                          readOnlyHint=False, 
                                          destructiveHint=False, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def create_relations(relations: list[Relation] = Field(..., description="List of relations to create between existing entities")) -> ToolResult:
        """Create multiple new relationships between existing entities in the knowledge graph.

        Creates directed relationships between entities that already exist. Both source and target
        entities must already be present in the graph.

        IMPORTANT: The `relationType` field must be one of the 16 allowed RelationType values.
        Call `list_allowed_relation_types` to see all valid types. Invalid types will be rejected.

        Returns:
            list[Relation]: The created relationships

        Example call:
        {
            "relations": [
                {
                    "source": "Alice Johnson",
                    "target": "Microsoft",
                    "relationType": "INFORMING"
                },
                {
                    "source": "Alice Johnson",
                    "target": "Seattle",
                    "relationType": "ENABLING"
                }
            ]
        }
        """
        logger.info(f"MCP tool: create_relations ({len(relations)} relations)")
        try:
            relation_objects = [Relation.model_validate(relation) for relation in relations]
            result = await memory.create_relations(relation_objects)
            return ToolResult(content=[TextContent(type="text", text=json.dumps([r.model_dump() for r in result]))],
                          structured_content={"result": result})
        except Neo4jError as e:
            logger.error(f"Neo4j error creating relations: {e}")
            raise ToolError(f"Neo4j error creating relations: {e}")
        except Exception as e:
            logger.error(f"Error creating relations: {e}")
            raise ToolError(f"Error creating relations: {e}")

    @mcp.tool(
        name=namespace_prefix + "add_observations",
        annotations=ToolAnnotations(title="Add Observations", 
                                          readOnlyHint=False, 
                                          destructiveHint=False, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def add_observations(observations: list[ObservationAddition] = Field(..., description="List of observations to add to existing entities")) -> ToolResult:
        """Add new observations/facts to existing entities in the knowledge graph.
        
        Appends new observations to entities that already exist. The entity must be present
        in the graph before adding observations. Each observation should be a distinct fact.
        
        Returns:
            list[dict]: Details about the added observations including entity name and new facts
            
        Example call:
        {
            "observations": [
                {
                    "entityName": "Alice Johnson",
                    "observations": ["Promoted to Senior Engineer", "Completed AWS certification"]
                },
                {
                    "entityName": "Microsoft",
                    "observations": ["Launched new AI products", "Stock price increased 15%"]
                }
            ]
        }
        """
        logger.info(f"MCP tool: add_observations ({len(observations)} additions)")
        try:
            observation_objects = [ObservationAddition.model_validate(obs) for obs in observations]
            result = await memory.add_observations(observation_objects)
            return ToolResult(content=[TextContent(type="text", text=json.dumps(result))],
                          structured_content={"result": result})
        except Neo4jError as e:
            logger.error(f"Neo4j error adding observations: {e}")
            raise ToolError(f"Neo4j error adding observations: {e}")
        except Exception as e:
            logger.error(f"Error adding observations: {e}")
            raise ToolError(f"Error adding observations: {e}")

    @mcp.tool(
        name=namespace_prefix + "delete_entities",
        annotations=ToolAnnotations(title="Delete Entities", 
                                          readOnlyHint=False, 
                                          destructiveHint=True, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def delete_entities(entityNames: list[str] = Field(..., description="List of exact entity names to delete permanently")) -> ToolResult:
        """Delete entities and all their associated relationships from the knowledge graph.
        
        Permanently removes entities from the graph along with all relationships they participate in.
        This is a destructive operation that cannot be undone. Entity names must match exactly.
        
        Returns:
            str: Success confirmation message
            
        Example call:
        {
            "entityNames": ["Old Company", "Outdated Person"]
        }
        
        Warning: This will delete the entities and ALL relationships they're involved in.
        """
        logger.info(f"MCP tool: delete_entities ({len(entityNames)} entities)")
        try:
            await memory.delete_entities(entityNames)
            return ToolResult(content=[TextContent(type="text", text="Entities deleted successfully")],
                              structured_content={"result": "Entities deleted successfully"})
        except Neo4jError as e:
            logger.error(f"Neo4j error deleting entities: {e}")
            raise ToolError(f"Neo4j error deleting entities: {e}")
        except Exception as e:
            logger.error(f"Error deleting entities: {e}")
            raise ToolError(f"Error deleting entities: {e}")

    @mcp.tool(
        name=namespace_prefix + "delete_observations",
        annotations=ToolAnnotations(title="Delete Observations", 
                                          readOnlyHint=False, 
                                          destructiveHint=True, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def delete_observations(deletions: list[ObservationDeletion] = Field(..., description="List of specific observations to remove from entities")) -> ToolResult:
        """Delete specific observations from existing entities in the knowledge graph.
        
        Removes specific observation texts from entities. The observation text must match exactly
        what is stored. The entity will remain but the specified observations will be deleted.
        
        Returns:
            str: Success confirmation message
            
        Example call:
        {
            "deletions": [
                {
                    "entityName": "Alice Johnson",
                    "observations": ["Old job title", "Outdated phone number"]
                },
                {
                    "entityName": "Microsoft", 
                    "observations": ["Former CEO information"]
                }
            ]
        }
        
        Note: Observation text must match exactly (case-sensitive) to be deleted.
        """
        logger.info(f"MCP tool: delete_observations ({len(deletions)} deletions)")
        try:    
            deletion_objects = [ObservationDeletion.model_validate(deletion) for deletion in deletions]
            await memory.delete_observations(deletion_objects)
            return ToolResult(content=[TextContent(type="text", text="Observations deleted successfully")],
                          structured_content={"result": "Observations deleted successfully"})
        except Neo4jError as e:
            logger.error(f"Neo4j error deleting observations: {e}")
            raise ToolError(f"Neo4j error deleting observations: {e}")
        except Exception as e:
            logger.error(f"Error deleting observations: {e}")
            raise ToolError(f"Error deleting observations: {e}")

    @mcp.tool(
        name=namespace_prefix + "delete_relations",
        annotations=ToolAnnotations(title="Delete Relations", 
                                          readOnlyHint=False, 
                                          destructiveHint=True, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def delete_relations(relations: list[Relation] = Field(..., description="List of specific relationships to delete from the graph")) -> ToolResult:
        """Delete specific relationships between entities in the knowledge graph.

        Removes relationships while keeping the entities themselves. The source, target, and
        relationship type must match exactly for deletion. This only affects the relationships,
        not the entities they connect.

        IMPORTANT: The `relationType` field must be one of the 16 allowed RelationType values.
        Call `list_allowed_relation_types` to see all valid types.

        Returns:
            str: Success confirmation message

        Example call:
        {
            "relations": [
                {
                    "source": "Alice Johnson",
                    "target": "Old Company",
                    "relationType": "INFORMING"
                },
                {
                    "source": "John Smith",
                    "target": "Former City",
                    "relationType": "ENABLING"
                }
            ]
        }

        Note: All fields (source, target, relationType) must match exactly for deletion.
        """
        logger.info(f"MCP tool: delete_relations ({len(relations)} relations)")
        try:
            relation_objects = [Relation.model_validate(relation) for relation in relations]
            await memory.delete_relations(relation_objects)
            return ToolResult(content=[TextContent(type="text", text="Relations deleted successfully")],
                          structured_content={"result": "Relations deleted successfully"})
        except Neo4jError as e:
            logger.error(f"Neo4j error deleting relations: {e}")
            raise ToolError(f"Neo4j error deleting relations: {e}")
        except Exception as e:
            logger.error(f"Error deleting relations: {e}")
            raise ToolError(f"Error deleting relations: {e}")

    @mcp.tool(
        name=namespace_prefix + "search_memories",
        annotations=ToolAnnotations(title="Search Memories", 
                                          readOnlyHint=True, 
                                          destructiveHint=False, 
                                          idempotentHint=True, 
                                          openWorldHint=True))
    async def search_memories(
        query: str = Field(..., description="Fulltext search query to find entities by name, type, or observations"),
        limit: int = Field(10, description="Maximum number of results to return (default 10, max 50)", ge=1, le=50)
    ) -> ToolResult:
        """Search for entities in the knowledge graph using fulltext search.
        
        Searches across entity names, types, and observations using Neo4j's fulltext index.
        Returns matching entities and their related connections. Supports partial matches
        and multiple search terms. Results are ordered by relevance score and limited to
        prevent context window overflow.
        
        Args:
            query: Search terms to find in entities
            limit: Maximum number of entities to return (1-50, default 10)
        
        Returns:
            KnowledgeGraph: Subgraph containing top matching entities and their relationships
            
        Example call:
        {
            "query": "engineer software",
            "limit": 20
        }
        
        This searches for entities containing "engineer" or "software" and returns the top 20 matches
        by relevance score. Each entity includes its score field for interpretation.
        """
        logger.info(f"MCP tool: search_memories ('{query}', limit={limit})")
        try:
            result = await memory.search_memories(query, limit=limit)
            return ToolResult(content=[TextContent(type="text", text=result.model_dump_json())],
                              structured_content=result)
        except Neo4jError as e:
            logger.error(f"Neo4j error searching memories: {e}")
            raise ToolError(f"Neo4j error searching memories: {e}")
        except Exception as e:
            logger.error(f"Error searching memories: {e}")
            raise ToolError(f"Error searching memories: {e}")
        
    @mcp.tool(
        name=namespace_prefix + "find_memories_by_name",
        annotations=ToolAnnotations(title="Find Memories by Name",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def find_memories_by_name(
        names: list[str] = Field(..., description="List of exact entity names to retrieve"),
        limit: int = Field(20, description="Maximum entities to return (default 20, max 50)", ge=1, le=50)
    ) -> ToolResult:
        """Find specific entities by their exact names.

        Retrieves entities that exactly match the provided names, along with relationships
        only between the returned entities. Limit constrains results if many names provided.

        Use search_memories for keyword-based discovery, find_memories_by_name for retrieving
        known entities.

        Returns:
            KnowledgeGraph: Subgraph containing the specified entities and their relationships

        Example call:
        {
            "names": ["Alice Johnson", "Microsoft", "Seattle"],
            "limit": 20
        }

        This retrieves the entities with exactly those names plus relationships between them only.
        """
        logger.info(f"MCP tool: find_memories_by_name ({len(names)} names, limit={limit})")
        try:
            result = await memory.find_memories_by_name(names, limit=limit)
            return ToolResult(content=[TextContent(type="text", text=result.model_dump_json())],
                              structured_content=result)
        except Neo4jError as e:
            logger.error(f"Neo4j error finding memories by name: {e}")
            raise ToolError(f"Neo4j error finding memories by name: {e}")
        except Exception as e:
            logger.error(f"Error finding memories by name: {e}")
            raise ToolError(f"Error finding memories by name: {e}")

    # ── Taxonomy Tool ────────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "list_allowed_types",
        annotations=ToolAnnotations(title="List Allowed Entity Types",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def list_allowed_types() -> ToolResult:
        """List all allowed entity types for the knowledge graph.

        Returns the 21 universal labels organized into 4 categories:
        Structural (4), Knowledge Domains (8), Activity Types (6), Meta (3).

        Use this to discover valid type values before calling create_entities.
        Passing an unlisted type to create_entities will be rejected.

        Returns:
            dict: Allowed types grouped by category with descriptions
        """
        logger.info("MCP tool: list_allowed_types")

        categories = {
            "structural": {
                "description": "Temporal organization",
                "types": {},
            },
            "knowledge_domains": {
                "description": "What kind of knowledge",
                "types": {},
            },
            "activity_types": {
                "description": "What role this knowledge plays",
                "types": {},
            },
            "meta": {
                "description": "About the graph and its context",
                "types": {},
            },
        }

        # Map enum members to their category
        _category_map = {
            "structural": [EntityType.GENESIS, EntityType.ENVISIONING, EntityType.REFLECTION, EntityType.TEMPORAL_FRAME],
            "knowledge_domains": [
                EntityType.TECHNICAL, EntityType.SCIENTIFIC, EntityType.THEORETICAL,
                EntityType.PHILOSOPHICAL, EntityType.HISTORICAL, EntityType.SOCIAL,
                EntityType.STRATEGIC, EntityType.PERSONAL,
            ],
            "activity_types": [
                EntityType.PROJECT, EntityType.INSIGHT, EntityType.PATTERN,
                EntityType.CHALLENGE, EntityType.SOLUTION, EntityType.LESSON,
            ],
            "meta": [EntityType.GRAPH_REGISTRY, EntityType.REFERENCE, EntityType.MILESTONE],
        }

        for category, members in _category_map.items():
            for member in members:
                categories[category]["types"][member.value] = ENTITY_TYPE_DESCRIPTIONS[member]

        result = {
            "total_types": len(EntityType),
            "categories": categories,
        }

        text = json.dumps(result, indent=2)
        return ToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content={"result": result},
        )

    @mcp.tool(
        name=namespace_prefix + "list_allowed_relation_types",
        annotations=ToolAnnotations(title="List Allowed Relation Types",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def list_allowed_relation_types() -> ToolResult:
        """List all allowed relationship types for the knowledge graph.

        Returns the 16 canonical edge types organized into 3 domains:
        Nouns (7) — completed causal events,
        Gerunds (8) — ongoing causal processes,
        Backbone (1) — temporal chain.

        Use this to discover valid relationType values before calling create_relations.
        Passing an unlisted relationType to create_relations will be rejected.

        Returns:
            dict: Allowed relation types grouped by domain with descriptions
        """
        logger.info("MCP tool: list_allowed_relation_types")

        categories = {
            "nouns": {
                "description": "Type of causal relationship (completed events)",
                "subcategories": {
                    "temporal_synthesis": {
                        "description": "Temporal ordering and transformation",
                        "types": {},
                    },
                    "intentionality": {
                        "description": "Consciousness reaching toward knowledge",
                        "types": {},
                    },
                    "fulfillment": {
                        "description": "Theory meeting evidence",
                        "types": {},
                    },
                },
            },
            "gerunds": {
                "description": "Mode of ongoing causal relating (active processes)",
                "subcategories": {
                    "foundation": {
                        "description": "Prerequisite and dependency",
                        "types": {},
                    },
                    "mereology": {
                        "description": "Part-whole relationships",
                        "types": {},
                    },
                    "motivation": {
                        "description": "Knowledge flow and causation",
                        "types": {},
                    },
                    "horizon": {
                        "description": "Trajectory extension and creation",
                        "types": {},
                    },
                },
            },
            "backbone": {
                "description": "Temporal chain",
                "subcategories": {
                    "temporal": {
                        "description": "The ontological heartbeat",
                        "types": {},
                    },
                },
            },
        }

        # Map enum members to their subcategory
        _subcategory_map = {
            ("nouns", "temporal_synthesis"): [RelationType.SEQUENCE, RelationType.EVOLUTION, RelationType.MEASUREMENT],
            ("nouns", "intentionality"): [RelationType.DISCOVERY, RelationType.RECOGNITION],
            ("nouns", "fulfillment"): [RelationType.VALIDATION, RelationType.CHALLENGE],
            ("gerunds", "foundation"): [RelationType.ENABLING, RelationType.REQUIRING],
            ("gerunds", "mereology"): [RelationType.ENCOMPASSING, RelationType.COMPOSING],
            ("gerunds", "motivation"): [RelationType.INFORMING, RelationType.CAUSING],
            ("gerunds", "horizon"): [RelationType.EXTENDING, RelationType.OPENING],
            ("backbone", "temporal"): [RelationType.NEXT_DAY],
        }

        for (domain, subcategory), members in _subcategory_map.items():
            for member in members:
                categories[domain]["subcategories"][subcategory]["types"][member.value] = RELATION_TYPE_DESCRIPTIONS[member]

        result = {
            "total_types": len(RelationType),
            "domains": categories,
        }

        text = json.dumps(result, indent=2)
        return ToolResult(
            content=[TextContent(type="text", text=text)],
            structured_content={"result": result},
        )

    # ── Cypher Tools ──────────────────────────────────────────────

    @mcp.tool(
        name=namespace_prefix + "get_neo4j_schema",
        annotations=ToolAnnotations(title="Get Neo4j Schema",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def get_neo4j_schema() -> ToolResult:
        """List all node labels, their attributes and their relationships to other nodes in the neo4j database.
        This requires that the APOC plugin is installed and enabled."""
        logger.info("MCP tool: get_neo4j_schema")

        try:
            # Compact schema: labels with property keys and counts
            nodes_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL apoc.meta.nodeTypeProperties()
                    YIELD nodeType, propertyName, propertyTypes
                    WITH nodeType,
                         collect({property: propertyName, types: propertyTypes}) AS properties
                    RETURN nodeType AS label, properties
                    ORDER BY label
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            # Compact schema: relationship types with connected labels
            rels_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL apoc.meta.relTypeProperties()
                    YIELD relType, propertyName, propertyTypes
                    WITH relType,
                         collect(CASE WHEN propertyName IS NOT NULL
                                 THEN {property: propertyName, types: propertyTypes}
                                 ELSE null END) AS properties
                    RETURN relType, [p IN properties WHERE p IS NOT NULL] AS properties
                    ORDER BY relType
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            # Node counts per label
            counts_result = await memory.driver.execute_query(
                Query(
                    """
                    CALL db.labels() YIELD label
                    CALL apoc.cypher.run('MATCH (n:`' + label + '`) RETURN count(n) AS count', {})
                    YIELD value
                    RETURN label, value.count AS count
                    ORDER BY count DESC
                    """,
                    timeout=read_timeout,
                ),
                routing_=RoutingControl.READ,
            )

            schema = {
                "node_labels": [dict(record) for record in nodes_result.records],
                "relationship_types": [dict(record) for record in rels_result.records],
                "node_counts": [dict(record) for record in counts_result.records],
            }

            text = json.dumps(schema, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": schema},
            )
        except ClientError as e:
            if "apoc" in str(e).lower():
                raise ToolError(
                    "APOC plugin is not available. get_neo4j_schema requires APOC to be installed and enabled."
                )
            raise ToolError(f"Neo4j client error: {e}")
        except Neo4jError as e:
            logger.error(f"Neo4j error getting schema: {e}")
            raise ToolError(f"Neo4j error getting schema: {e}")
        except Exception as e:
            logger.error(f"Error getting schema: {e}")
            raise ToolError(f"Error getting schema: {e}")

    @mcp.tool(
        name=namespace_prefix + "read_neo4j_cypher",
        annotations=ToolAnnotations(title="Read Neo4j Cypher",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=True))
    async def read_neo4j_cypher(
        query: str = Field(..., description="The Cypher query to execute."),
        params: dict[str, Any] = Field(default_factory=dict, description="The parameters to pass to the Cypher query."),
    ) -> ToolResult:
        """Execute a read Cypher query on the neo4j database."""
        logger.info(f"MCP tool: read_neo4j_cypher")

        # Guard: reject write queries
        if _is_write_query(query):
            raise ToolError(
                "Write queries are not allowed via read_neo4j_cypher. "
                "Use the bounded mutation tools (create_entities, create_relations, etc.) instead."
            )

        try:
            result = await memory.driver.execute_query(
                Query(query, timeout=read_timeout),
                parameters_=params,
                routing_=RoutingControl.READ,
            )
            records = [_value_sanitize(dict(record)) for record in result.records]
            records = [r for r in records if r is not None]
            text = json.dumps(records, indent=2, default=str)

            # Safety truncation to prevent context explosion
            if len(text) > 200_000:
                text = text[:200_000] + "\n... (truncated — add LIMIT to your query)"

            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error executing cypher: {e}")
            raise ToolError(f"Neo4j error executing cypher: {e}")
        except Exception as e:
            logger.error(f"Error executing cypher: {e}")
            raise ToolError(f"Error executing cypher: {e}")

    # ── GDS Analytics Tools ───────────────────────────────────────
    # Uses Aura-compatible inline gds.graph.project() function pattern.
    # Projections are created via MATCH...RETURN gds.graph.project()
    # rather than CALL gds.graph.project() which requires the GDS plugin.

    @mcp.tool(
        name=namespace_prefix + "gds_create_projection",
        annotations=ToolAnnotations(title="GDS Create Projection",
                                          readOnlyHint=False,
                                          destructiveHint=False,
                                          idempotentHint=False,
                                          openWorldHint=False))
    async def gds_create_projection(
        name: str = Field(..., description="Name for the graph projection"),
        rel_types: list[str] = Field(default=None, description="Relationship types to include (defaults to all). E.g. ['INFORMING', 'ENCOMPASSING']"),
        undirected: bool = Field(default=True, description="Whether to treat relationships as undirected (default true)"),
        memory_gb: str = Field(default="2GB", description="Memory allocation for the projection. Must be one of: 2GB, 4GB, 8GB, 16GB, etc."),
    ) -> ToolResult:
        """Create a GDS graph projection for analytics.

        Projects a subgraph into GDS memory for running algorithms like PageRank, Louvain, WCC.
        The projection must be created before running any GDS algorithm.

        Uses the Aura-compatible inline projection pattern (gds.graph.project function).
        These are Cypher projections — the graph is built by executing a MATCH query, not by
        scanning the store directly (Native projections). This means:

        SCALING CONSTRAINT: Cypher projections must traverse every matched relationship through
        the query engine. For large graphs (100K+ nodes, 1M+ edges), scope your projection
        carefully — filter by relationship type, use WHERE clauses, or project a subgraph.
        Projecting millions of relationships through multi-hop patterns WILL timeout.

        Good: Direct single-hop projections (Memory-[r]->Memory, Application-[r]->Host)
        Good: Virtual edges via small intermediaries (App->Host<-App for co-hosting, <10K joins)
        Bad: Virtual edges via massive intermediaries (Host->Flow->Host with 4M+ flows)

        Requires a memory allocation (default 2GB, minimum allowed by Aura).

        Example:
        {
            "name": "myGraph",
            "rel_types": ["INFORMING", "ENCOMPASSING", "ENABLING"],
            "undirected": true,
            "memory_gb": "2GB"
        }
        """
        logger.info(f"MCP tool: gds_create_projection (name={name}, rel_types={rel_types}, undirected={undirected}, memory={memory_gb})")
        try:
            # Build the MATCH clause with optional relationship type filter
            if rel_types:
                rel_filter = "|".join(f"`{rt}`" for rt in rel_types)
                match_clause = f"MATCH (source:Memory)-[r:{rel_filter}]->(target:Memory)"
            else:
                match_clause = "MATCH (source:Memory)-[r]->(target:Memory)"

            # Build the configuration
            config_parts = [f"memory: '{memory_gb}'"]
            if undirected:
                config_parts.append("undirectedRelationshipTypes: ['*']")
            config_str = ", ".join(config_parts)

            query = f"""
                {match_clause}
                RETURN gds.graph.project(
                    $name,
                    source,
                    target,
                    {{}},
                    {{{config_str}}}
                )
            """

            result = await memory.driver.execute_query(
                query,
                name=name,
                routing_=RoutingControl.READ,
            )
            records = [_value_sanitize(dict(record)) for record in result.records]
            records = [r for r in records if r is not None]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error creating GDS projection: {e}")
            raise ToolError(f"Neo4j error creating GDS projection: {e}")
        except Exception as e:
            logger.error(f"Error creating GDS projection: {e}")
            raise ToolError(f"Error creating GDS projection: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_drop_projection",
        annotations=ToolAnnotations(title="GDS Drop Projection",
                                          readOnlyHint=False,
                                          destructiveHint=True,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_drop_projection(
        name: str = Field(..., description="Name of the graph projection to drop"),
    ) -> ToolResult:
        """Drop a GDS graph projection to free memory.

        Removes a previously created graph projection from GDS memory.
        """
        logger.info(f"MCP tool: gds_drop_projection (name={name})")
        try:
            result = await memory.driver.execute_query(
                "CALL gds.graph.drop($name)",
                name=name,
                routing_=RoutingControl.WRITE,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error dropping GDS projection: {e}")
            raise ToolError(f"Neo4j error dropping GDS projection: {e}")
        except Exception as e:
            logger.error(f"Error dropping GDS projection: {e}")
            raise ToolError(f"Error dropping GDS projection: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_pagerank",
        annotations=ToolAnnotations(title="GDS PageRank",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_pagerank(
        projection: str = Field(..., description="Name of the graph projection to run PageRank on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run PageRank on a GDS graph projection.

        Returns nodes ranked by importance/centrality. Higher scores indicate more
        connected/important nodes in the graph. Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_pagerank (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.pageRank.stream($projection)
                YIELD nodeId, score
                RETURN gds.util.asNode(nodeId).name AS node,
                       gds.util.asNode(nodeId).type AS type,
                       score
                ORDER BY score DESC
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running PageRank: {e}")
            raise ToolError(f"Neo4j error running PageRank: {e}")
        except Exception as e:
            logger.error(f"Error running PageRank: {e}")
            raise ToolError(f"Error running PageRank: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_louvain",
        annotations=ToolAnnotations(title="GDS Louvain",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_louvain(
        projection: str = Field(..., description="Name of the graph projection to run Louvain on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run Louvain community detection on a GDS graph projection.

        Identifies communities/clusters in the graph. Nodes with the same communityId
        belong to the same cluster. Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_louvain (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.louvain.stream($projection)
                YIELD nodeId, communityId
                RETURN gds.util.asNode(nodeId).name AS node,
                       gds.util.asNode(nodeId).type AS type,
                       communityId
                ORDER BY communityId, node
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running Louvain: {e}")
            raise ToolError(f"Neo4j error running Louvain: {e}")
        except Exception as e:
            logger.error(f"Error running Louvain: {e}")
            raise ToolError(f"Error running Louvain: {e}")

    @mcp.tool(
        name=namespace_prefix + "gds_wcc",
        annotations=ToolAnnotations(title="GDS Weakly Connected Components",
                                          readOnlyHint=True,
                                          destructiveHint=False,
                                          idempotentHint=True,
                                          openWorldHint=False))
    async def gds_wcc(
        projection: str = Field(..., description="Name of the graph projection to run WCC on"),
        result_limit: int = Field(default=20, ge=1, le=1000, description="Maximum number of results to return (default 20)"),
    ) -> ToolResult:
        """Run Weakly Connected Components on a GDS graph projection.

        Identifies connected components — groups of nodes that are all reachable from each other.
        Nodes with the same componentId are in the same connected component.
        Requires a projection created via gds_create_projection.
        """
        logger.info(f"MCP tool: gds_wcc (projection={projection}, limit={result_limit})")
        try:
            result = await memory.driver.execute_query(
                """
                CALL gds.wcc.stream($projection)
                YIELD nodeId, componentId
                RETURN gds.util.asNode(nodeId).name AS node,
                       gds.util.asNode(nodeId).type AS type,
                       componentId
                ORDER BY componentId, node
                LIMIT $result_limit
                """,
                projection=projection,
                result_limit=result_limit,
                routing_=RoutingControl.READ,
            )
            records = [dict(record) for record in result.records]
            text = json.dumps(records, indent=2, default=str)
            return ToolResult(
                content=[TextContent(type="text", text=text)],
                structured_content={"result": records},
            )
        except Neo4jError as e:
            logger.error(f"Neo4j error running WCC: {e}")
            raise ToolError(f"Neo4j error running WCC: {e}")
        except Exception as e:
            logger.error(f"Error running WCC: {e}")
            raise ToolError(f"Error running WCC: {e}")

    return mcp


async def main(
    neo4j_uri: str,
    neo4j_user: str,
    neo4j_password: str,
    neo4j_database: str,
    transport: Literal["stdio", "sse", "streamable-http"] = "stdio",
    namespace: str = "",
    host: str = "127.0.0.1",
    port: int = 8000,
    path: str = "/mcp/",
    allow_origins: list[str] = [],
    allowed_hosts: list[str] = [],
    read_timeout: int = 30,
    schema_sample_size: int = 1000,
) -> None:
    logger.info(f"Starting Neo4j MCP Memory Server")
    logger.info(f"Connecting to Neo4j with DB URL: {neo4j_uri}")

    # Connect to Neo4j
    neo4j_driver = AsyncGraphDatabase.driver(
        neo4j_uri,
        auth=(neo4j_user, neo4j_password), 
        database=neo4j_database
    )
    
    # Verify connection
    try:
        await neo4j_driver.verify_connectivity()
        logger.info(f"Connected to Neo4j at {neo4j_uri}")
    except Exception as e:
        logger.error(f"Failed to connect to Neo4j: {e}")
        exit(1)

    # Initialize memory
    memory = Neo4jMemory(neo4j_driver)
    logger.info("Neo4jMemory initialized")
    
    # Create fulltext index
    await memory.create_fulltext_index()
    
    # Configure security middleware
    custom_middleware = [
        Middleware(
            CORSMiddleware,
            allow_origins=allow_origins,
            allow_methods=["GET", "POST"],
            allow_headers=["*"],
        ),
        Middleware(TrustedHostMiddleware,
                   allowed_hosts=allowed_hosts)
    ]

    # Create MCP server
    mcp = create_mcp_server(memory, namespace, read_timeout=read_timeout, schema_sample_size=schema_sample_size)
    logger.info("MCP server created")

    # Run the server with the specified transport
    logger.info(f"Starting server with transport: {transport}")
    match transport:
        case "streamable-http":
            logger.info(f"HTTP server starting on {host}:{port}{path}")
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware, transport="streamable-http", stateless_http=True)
        case "stdio":
            logger.info("STDIO server starting")
            await mcp.run_stdio_async()
        case "sse":
            logger.info(f"SSE server starting on {host}:{port}{path}")
            await mcp.run_http_async(host=host, port=port, path=path, middleware=custom_middleware, transport="sse")
        case _:
            raise ValueError(f"Unsupported transport: {transport}")
