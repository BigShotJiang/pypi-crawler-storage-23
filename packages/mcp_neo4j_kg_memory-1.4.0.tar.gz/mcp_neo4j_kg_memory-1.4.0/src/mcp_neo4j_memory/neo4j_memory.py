import logging
from enum import Enum
from typing import Any, Dict, List

from neo4j import AsyncDriver, RoutingControl
from pydantic import BaseModel, Field


# Set up logging
logger = logging.getLogger('mcp_neo4j_memory')
logger.setLevel(logging.INFO)


def _neo4j_datetime_to_str(val) -> str | None:
    """Convert a Neo4j DateTime/Date to ISO string, or return None."""
    if val is None:
        return None
    return val.iso_format()


class EntityType(str, Enum):
    """Allowed entity type labels for the knowledge graph.

    21 universal labels organized as channels, not content-fitted boxes.
    Every entity committed to memory should naturally identify with one channel.
    """

    # Structural (4) — temporal organization
    GENESIS = "Genesis"
    ENVISIONING = "Envisioning"
    REFLECTION = "Reflection"
    TEMPORAL_FRAME = "TemporalFrame"

    # Knowledge Domains (8) — what kind of knowledge
    TECHNICAL = "Technical"
    SCIENTIFIC = "Scientific"
    THEORETICAL = "Theoretical"
    PHILOSOPHICAL = "Philosophical"
    HISTORICAL = "Historical"
    SOCIAL = "Social"
    STRATEGIC = "Strategic"
    PERSONAL = "Personal"

    # Activity Types (6) — what role this knowledge plays
    PROJECT = "Project"
    INSIGHT = "Insight"
    PATTERN = "Pattern"
    CHALLENGE = "Challenge"
    SOLUTION = "Solution"
    LESSON = "Lesson"

    # Meta (3) — about the graph and its context
    GRAPH_REGISTRY = "GraphRegistry"
    REFERENCE = "Reference"
    MILESTONE = "Milestone"


# Descriptions for each type (used by list_allowed_types tool)
ENTITY_TYPE_DESCRIPTIONS: Dict[EntityType, str] = {
    # Structural
    EntityType.GENESIS: "Temporal genesis of conscious experience — the beginning of a day's possibility space",
    EntityType.ENVISIONING: "Forward-looking vision, goals, future state, what we're building toward",
    EntityType.REFLECTION: "Reflective processing, mental clearing, self-examination, affective states",
    EntityType.TEMPORAL_FRAME: "Navigational step through possibility space — a moment of consciousness examining and acting within a temporal sequence",
    # Knowledge Domains
    EntityType.TECHNICAL: "Engineering, code, architecture, debugging, configuration, infrastructure, platforms",
    EntityType.SCIENTIFIC: "Empirical research, data, validation, methodology, experiments, measurements",
    EntityType.THEORETICAL: "Frameworks, models, abstract structures, paradigms, formal theories",
    EntityType.PHILOSOPHICAL: "Consciousness, meaning, ontology, epistemology, ethics, phenomenology",
    EntityType.HISTORICAL: "Events, timelines, crises, what happened, precedents, institutional memory",
    EntityType.SOCIAL: "Society, politics, economics, culture, institutions, organizations, group dynamics",
    EntityType.STRATEGIC: "Planning, business, media, communication, positioning, decision-making",
    EntityType.PERSONAL: "Lived experience, self-knowledge, personality, cognitive patterns, preferences",
    # Activity Types
    EntityType.PROJECT: "Active work items, initiatives, prototypes — things being built",
    EntityType.INSIGHT: "Discoveries, breakthroughs, realizations, 'aha' moments — things learned",
    EntityType.PATTERN: "Recurring patterns, templates, procedures, anti-patterns — things that repeat",
    EntityType.CHALLENGE: "Problems, blockers, bugs, failures, constraints — things that resist",
    EntityType.SOLUTION: "Resolutions, fixes, workarounds, successful implementations — things that worked",
    EntityType.LESSON: "Lessons learned, gotchas, warnings, critical rules — things to remember",
    # Meta
    EntityType.GRAPH_REGISTRY: "Meta-knowledge about the graph itself, tool usage rules, search procedures",
    EntityType.REFERENCE: "External references, data sources, tools, platforms, people, technologies",
    EntityType.MILESTONE: "Historical markers, key events, crises, turning points — temporal landmarks",
}


class RelationType(str, Enum):
    """Allowed relationship types for the knowledge graph.

    16 canonical edge types derived from formal ontology — universal modes of
    causal relating, not content descriptions. Organized as:
    - Nouns (7): type of causal relationship (completed events)
    - Gerunds (8): mode of ongoing causal relating (active processes)
    - Backbone (1): temporal chain
    """

    # Nouns — Temporal Synthesis
    SEQUENCE = "SEQUENCE"
    EVOLUTION = "EVOLUTION"
    MEASUREMENT = "MEASUREMENT"

    # Nouns — Intentionality
    DISCOVERY = "DISCOVERY"
    RECOGNITION = "RECOGNITION"

    # Nouns — Fulfillment
    VALIDATION = "VALIDATION"
    CHALLENGE = "CHALLENGE"

    # Gerunds — Foundation
    ENABLING = "ENABLING"
    REQUIRING = "REQUIRING"

    # Gerunds — Mereology
    ENCOMPASSING = "ENCOMPASSING"
    COMPOSING = "COMPOSING"

    # Gerunds — Motivation
    INFORMING = "INFORMING"
    CAUSING = "CAUSING"

    # Gerunds — Horizon
    EXTENDING = "EXTENDING"
    OPENING = "OPENING"

    # Backbone — Temporal
    NEXT_DAY = "NEXT_DAY"


# Descriptions for each relation type (used by list_allowed_relation_types tool)
RELATION_TYPE_DESCRIPTIONS: Dict[RelationType, str] = {
    # Nouns — Temporal Synthesis
    RelationType.SEQUENCE: "Ordered steps, non-transformative — process flows",
    RelationType.EVOLUTION: "Knowledge transforming through time",
    RelationType.MEASUREMENT: "Possibility collapsing into actuality — the measurement event",
    # Nouns — Intentionality
    RelationType.DISCOVERY: "Consciousness reaching toward the genuinely new",
    RelationType.RECOGNITION: "Pattern recognized in new context — 'we've been here before'",
    # Nouns — Fulfillment
    RelationType.VALIDATION: "Evidence meeting theory — confirmation",
    RelationType.CHALLENGE: "Failed validation demanding theoretical response",
    # Gerunds — Foundation
    RelationType.ENABLING: "Opening a door — generative prerequisite",
    RelationType.REQUIRING: "Needing a door open — dependency constraint",
    # Gerunds — Mereology
    RelationType.ENCOMPASSING: "Many reduced to one — whole contains parts",
    RelationType.COMPOSING: "Few unified into something new — synthesis",
    # Gerunds — Motivation
    RelationType.INFORMING: "Shaping without determining — knowledge flow",
    RelationType.CAUSING: "Direct causal production",
    # Gerunds — Horizon
    RelationType.EXTENDING: "Further along an existing trajectory",
    RelationType.OPENING: "A new trajectory that didn't exist before",
    # Backbone
    RelationType.NEXT_DAY: "The ontological heartbeat — Genesis chain",
}


# Models for our knowledge graph
class Entity(BaseModel):
    """Represents a memory entity in the knowledge graph.

    Example:
    {
        "name": "John Smith",
        "type": "person",
        "observations": ["Works at Neo4j", "Lives in San Francisco", "Expert in graph databases"],
        "score": 5.42
    }
    """
    name: str = Field(
        description="Unique identifier/name for the entity. Should be descriptive and specific.",
        min_length=1,
        examples=["John Smith", "Neo4j Inc", "San Francisco"]
    )
    type: EntityType = Field(
        description="Category label for the entity. Must be one of the 21 allowed EntityType values (e.g. 'Technical', 'Personal', 'Insight'). Use list_allowed_types to see all options.",
        examples=["Technical", "Personal", "Insight", "Reference", "Project"]
    )
    observations: List[str] = Field(
        description="List of facts, observations, or notes about this entity. Each observation should be a complete, standalone fact.",
        examples=[["Works at Neo4j", "Lives in San Francisco"], ["Headquartered in Sweden", "Graph database company"]]
    )
    score: float | None = Field(
        default=None,
        description="Relevance score from fulltext search (higher = better match). Only present when entity comes from search results."
    )
    t_created: str | None = Field(
        default=None,
        description="ISO datetime when this entity was first created in the graph. Auto-set on creation."
    )
    t_valid: str | None = Field(
        default=None,
        description="ISO datetime when this entity became true in reality. Optional, user/LLM-provided."
    )

class Relation(BaseModel):
    """Represents a relationship between two entities in the knowledge graph.

    Example:
    {
        "source": "John Smith",
        "target": "Neo4j Inc",
        "relationType": "INFORMING"
    }
    """
    source: str = Field(
        description="Name of the source entity (must match an existing entity name exactly)",
        min_length=1,
        examples=["John Smith", "Neo4j Inc"]
    )
    target: str = Field(
        description="Name of the target entity (must match an existing entity name exactly)",
        min_length=1,
        examples=["Neo4j Inc", "San Francisco"]
    )
    relationType: RelationType = Field(
        description="Type of relationship between source and target. Must be one of the 16 allowed RelationType values. Call list_allowed_relation_types to see all options.",
        examples=["ENABLING", "INFORMING", "COMPOSING", "EVOLUTION", "NEXT_DAY"]
    )
    t_created: str | None = Field(
        default=None,
        description="ISO datetime when this relation was first created. Auto-set on creation."
    )
    t_valid: str | None = Field(
        default=None,
        description="ISO datetime when this relation became true in reality. Optional, for rare external-referent cases."
    )

class KnowledgeGraph(BaseModel):
    """Complete knowledge graph containing entities and their relationships."""
    entities: List[Entity] = Field(
        description="List of all entities in the knowledge graph",
        default=[]
    )
    relations: List[Relation] = Field(
        description="List of all relationships between entities",
        default=[]
    )

class ObservationAddition(BaseModel):
    """Request to add new observations to an existing entity.
    
    Example:
    {
        "entityName": "John Smith",
        "observations": ["Recently promoted to Senior Engineer", "Speaks fluent German"]
    }
    """
    entityName: str = Field(
        description="Exact name of the existing entity to add observations to",
        min_length=1,
        examples=["John Smith", "Neo4j Inc"]
    )
    observations: List[str] = Field(
        description="New observations/facts to add to the entity. Each should be unique and informative.",
        min_length=1
    )
    source_session: str | None = Field(
        default=None,
        description="Session identifier for provenance tracking. Recorded on each Observation sub-node."
    )

class ObservationDeletion(BaseModel):
    """Request to delete specific observations from an existing entity.
    
    Example:
    {
        "entityName": "John Smith", 
        "observations": ["Old job title", "Outdated contact info"]
    }
    """
    entityName: str = Field(
        description="Exact name of the existing entity to remove observations from",
        min_length=1,
        examples=["John Smith", "Neo4j Inc"]
    )
    observations: List[str] = Field(
        description="Exact observation texts to delete from the entity (must match existing observations exactly)",
        min_length=1
    )

class Neo4jMemory:
    def __init__(self, neo4j_driver: AsyncDriver):
        self.driver = neo4j_driver

    async def create_fulltext_index(self):
        """Create fulltext search index spanning Memory and Observation nodes.

        Memory nodes are indexed on name and type.
        Observation nodes are indexed on text.
        Neo4j gracefully skips missing properties per node.
        """
        try:
            # Drop old single-label index if it exists (self-healing on upgrade)
            try:
                await self.driver.execute_query(
                    "DROP INDEX search IF EXISTS",
                    routing_control=RoutingControl.WRITE
                )
            except Exception:
                pass  # Index may not exist

            query = """
            CREATE FULLTEXT INDEX search IF NOT EXISTS
            FOR (n:Memory|Observation)
            ON EACH [n.name, n.type, n.text]
            """
            await self.driver.execute_query(query, routing_control=RoutingControl.WRITE)
            logger.info("Created fulltext search index (Memory|Observation)")
        except Exception as e:
            # Index might already exist, which is fine
            logger.debug(f"Fulltext index creation: {e}")

    async def load_graph(self, filter_query: str = "*", limit: int | None = None):
        """Load the knowledge graph from Neo4j with optional result limiting.

        INTERNAL USE ONLY. This function is used internally by search_memories.
        For external queries, use search_memories or find_memories_by_name for bounded results.

        Uses three focused queries:
        1. Fulltext search → resolve to distinct Memory entities (handling Observation hits)
        2. Collect observations for those entities from sub-nodes
        3. Get relationships between those entities

        Args:
            filter_query: Fulltext search query
            limit: Maximum number of entities to return (ordered by relevance score)
        """
        logger.info(f"Loading knowledge graph from Neo4j (limit={limit})")

        limit_clause = f"LIMIT {limit}" if limit else ""

        # Query 1: Find matching Memory entities (resolving Observation hits to parents)
        query_entities = f"""
            CALL db.index.fulltext.queryNodes('search', $filter) YIELD node, score
            WITH node, score,
                 CASE
                     WHEN node:Observation THEN head([(node)<-[:HAS_OBSERVATION]-(m:Memory) | m])
                     ELSE node
                 END AS memory
            WHERE memory IS NOT NULL
            WITH DISTINCT memory, max(score) AS score
            ORDER BY score DESC
            {limit_clause}
            RETURN memory.name AS name, memory.type AS type, score,
                   memory.t_created AS t_created, memory.t_valid AS t_valid
        """

        result_entities = await self.driver.execute_query(
            query_entities, {"filter": filter_query}, routing_control=RoutingControl.READ
        )

        if not result_entities.records:
            return KnowledgeGraph(entities=[], relations=[])

        entity_names = [record["name"] for record in result_entities.records]
        entity_scores = {record["name"]: record["score"] for record in result_entities.records}
        entity_types = {record["name"]: record["type"] for record in result_entities.records}
        entity_t_created = {record["name"]: _neo4j_datetime_to_str(record["t_created"]) for record in result_entities.records}
        entity_t_valid = {record["name"]: _neo4j_datetime_to_str(record["t_valid"]) for record in result_entities.records}

        # Query 2: Collect observations for matched entities from sub-nodes
        query_observations = """
            MATCH (e:Memory)-[:HAS_OBSERVATION]->(o:Observation)
            WHERE e.name IN $names
            RETURN e.name AS name, collect(o.text) AS observations
        """

        result_obs = await self.driver.execute_query(
            query_observations, {"names": entity_names}, routing_control=RoutingControl.READ
        )

        obs_map = {record["name"]: record["observations"] for record in result_obs.records}

        # Build Entity objects
        entities = [
            Entity(
                name=name,
                type=entity_types[name],
                observations=obs_map.get(name, []),
                score=entity_scores.get(name),
                t_created=entity_t_created.get(name),
                t_valid=entity_t_valid.get(name),
            )
            for name in entity_names
        ]

        # Query 3: Get relationships between matched entities
        relations: list[Relation] = []
        if entity_names:
            query_relations = """
                MATCH (source:Memory)-[r]->(target:Memory)
                WHERE source.name IN $names AND target.name IN $names
                RETURN source.name AS source, target.name AS target, type(r) AS relationType
            """

            result_rels = await self.driver.execute_query(
                query_relations, {"names": entity_names}, routing_control=RoutingControl.READ
            )

            relations = [
                Relation(
                    source=record["source"],
                    target=record["target"],
                    relationType=record["relationType"]
                )
                for record in result_rels.records
                if record.get("relationType")
            ]

        logger.debug(f"Loaded {len(entities)} entities and {len(relations)} relations")
        return KnowledgeGraph(entities=entities, relations=relations)

    async def create_entities(self, entities: List[Entity]) -> List[Entity]:
        """Create multiple new entities in the knowledge graph.

        Creates Memory nodes and Observation sub-nodes. Observations are stored
        as individual (:Observation) nodes connected via [:HAS_OBSERVATION].
        Temporal metadata (t_created, t_valid, t_observed, source_session) is
        set automatically or from user-provided values.
        """
        logger.info(f"Creating {len(entities)} entities")
        for entity in entities:
            # Build conditional SET clauses for temporal fields
            t_valid_clause = "SET e.t_valid = datetime($t_valid)" if entity.t_valid else ""

            query = f"""
            MERGE (e:Memory {{ name: $name }})
            ON CREATE SET e.t_created = datetime()
            SET e.type = $type
            SET e:`{entity.type.value}`
            {t_valid_clause}
            WITH e
            UNWIND $observations AS obs_text
            MERGE (e)-[:HAS_OBSERVATION]->(o:Observation {{text: obs_text}})
            ON CREATE SET o.t_observed = datetime()
            """
            params: Dict[str, Any] = {
                "name": entity.name,
                "type": entity.type.value,
                "observations": entity.observations,
            }
            if entity.t_valid:
                params["t_valid"] = entity.t_valid

            await self.driver.execute_query(
                query,
                params,
                routing_control=RoutingControl.WRITE,
            )

        return entities

    async def create_relations(self, relations: List[Relation]) -> List[Relation]:
        """Create multiple new relations between entities.

        Temporal metadata (t_created, t_valid) is set automatically or from
        user-provided values.
        """
        logger.info(f"Creating {len(relations)} relations")
        for relation in relations:
            t_valid_clause = "SET r.t_valid = datetime($t_valid)" if relation.t_valid else ""

            query = f"""
            MATCH (from:Memory),(to:Memory)
            WHERE from.name = $source
            AND  to.name = $target
            MERGE (from)-[r:`{relation.relationType.value}`]->(to)
            ON CREATE SET r.t_created = datetime()
            {t_valid_clause}
            """
            params: Dict[str, Any] = {
                "source": relation.source,
                "target": relation.target,
            }
            if relation.t_valid:
                params["t_valid"] = relation.t_valid

            await self.driver.execute_query(
                query,
                params,
                routing_control=RoutingControl.WRITE
            )

        return relations

    async def add_observations(self, observations: List[ObservationAddition]) -> List[Dict[str, Any]]:
        """Add new observations to existing entities as Observation sub-nodes.

        Uses OPTIONAL MATCH to detect existing observations and only creates
        truly new ones, preventing duplicates. Sets t_observed and optional
        source_session on new Observation nodes.
        """
        logger.info(f"Adding observations to {len(observations)} entities")
        query = """
        UNWIND $observations as obs
        MATCH (e:Memory { name: obs.entityName })
        WITH e, obs
        UNWIND obs.observations AS obs_text
        OPTIONAL MATCH (e)-[:HAS_OBSERVATION]->(existing:Observation {text: obs_text})
        WITH e, obs, obs_text, existing
        WHERE existing IS NULL
        CREATE (e)-[:HAS_OBSERVATION]->(o:Observation {text: obs_text})
        SET o.t_observed = datetime()
        FOREACH (_ IN CASE WHEN obs.source_session IS NOT NULL THEN [1] ELSE [] END |
            SET o.source_session = obs.source_session
        )
        RETURN e.name AS name, collect(obs_text) AS new
        """

        result = await self.driver.execute_query(
            query,
            {"observations": [obs.model_dump() for obs in observations]},
            routing_control=RoutingControl.WRITE
        )

        results = [{"entityName": record.get("name"), "addedObservations": record.get("new")} for record in result.records]
        return results

    async def delete_entities(self, entity_names: List[str]) -> None:
        """Delete multiple entities, their Observation sub-nodes, and all relations."""
        logger.info(f"Deleting {len(entity_names)} entities")
        query = """
        UNWIND $entities as name
        MATCH (e:Memory { name: name })
        OPTIONAL MATCH (e)-[:HAS_OBSERVATION]->(o:Observation)
        DETACH DELETE e, o
        """

        await self.driver.execute_query(query, {"entities": entity_names}, routing_control=RoutingControl.WRITE)
        logger.info(f"Successfully deleted {len(entity_names)} entities")

    async def delete_observations(self, deletions: List[ObservationDeletion]) -> None:
        """Delete specific Observation sub-nodes from entities."""
        logger.info(f"Deleting observations from {len(deletions)} entities")
        query = """
        UNWIND $deletions as d
        MATCH (e:Memory { name: d.entityName })-[:HAS_OBSERVATION]->(o:Observation)
        WHERE o.text IN d.observations
        DETACH DELETE o
        """
        await self.driver.execute_query(
            query,
            {"deletions": [deletion.model_dump() for deletion in deletions]},
            routing_control=RoutingControl.WRITE
        )
        logger.info(f"Successfully deleted observations from {len(deletions)} entities")

    async def delete_relations(self, relations: List[Relation]) -> None:
        """Delete multiple relations from the graph."""
        logger.info(f"Deleting {len(relations)} relations")
        for relation in relations:
            query = f"""
            WITH $relation as relation
            MATCH (source:Memory)-[r:`{relation.relationType.value}`]->(target:Memory)
            WHERE source.name = relation.source
            AND target.name = relation.target
            DELETE r
            """
            await self.driver.execute_query(
                query, 
                {"relation": relation.model_dump()},
                routing_control=RoutingControl.WRITE
            )
        logger.info(f"Successfully deleted {len(relations)} relations")

    async def read_graph(self) -> KnowledgeGraph:
        """Read the entire knowledge graph.

        DEPRECATED: This function returns unbounded results and is incompatible with
        large-scale temporal knowledge graphs. Use search_memories or find_memories_by_name
        with appropriate limits instead.

        Kept for internal use only.
        """
        return await self.load_graph()

    async def search_memories(self, query: str, limit: int = 10) -> KnowledgeGraph:
        """Search for memories based on a query with Fulltext Search.
        
        Args:
            query: Search query string
            limit: Maximum number of entities to return (default 10)
        """
        logger.info(f"Searching for memories with query: '{query}' (limit={limit})")
        return await self.load_graph(query, limit=limit)

    async def find_memories_by_name(self, names: List[str], limit: int = 20) -> KnowledgeGraph:
        """Find specific memories by their names with bounded relationship traversal.

        Observations are collected from Observation sub-nodes.

        Args:
            names: List of entity names to retrieve (exact match)
            limit: Maximum entities to return if >limit names provided (default 20)

        Returns:
            KnowledgeGraph with matched entities and relationships only between them
        """
        logger.info(f"Finding {len(names)} memories by name (limit={limit})")

        # Get entities with name match, collecting observations from sub-nodes
        query = """
        MATCH (e:Memory)
        WHERE e.name IN $names
        WITH e
        LIMIT $limit
        OPTIONAL MATCH (e)-[:HAS_OBSERVATION]->(o:Observation)
        RETURN  e.name as name,
                e.type as type,
                collect(o.text) as observations,
                e.t_created as t_created,
                e.t_valid as t_valid
        """
        result_nodes = await self.driver.execute_query(
            query,
            {"names": names, "limit": limit},
            routing_control=RoutingControl.READ
        )

        entities: list[Entity] = list()
        entity_names: list[str] = list()

        for record in result_nodes.records:
            entities.append(Entity(
                name=record['name'],
                type=record['type'],
                observations=record.get('observations', list()),
                t_created=_neo4j_datetime_to_str(record.get('t_created')),
                t_valid=_neo4j_datetime_to_str(record.get('t_valid')),
            ))
            entity_names.append(record['name'])

        # Get relations ONLY between retrieved entities (bounded traversal)
        relations: list[Relation] = list()
        if entity_names:
            query = """
            MATCH (source:Memory)-[r]->(target:Memory)
            WHERE source.name IN $entity_names
              AND target.name IN $entity_names
            RETURN  source.name as source,
                    target.name as target,
                    type(r) as relationType
            """
            result_relations = await self.driver.execute_query(
                query,
                {"entity_names": entity_names},
                routing_control=RoutingControl.READ
            )
            for record in result_relations.records:
                relations.append(Relation(
                    source=record["source"],
                    target=record["target"],
                    relationType=record["relationType"]
                ))

        logger.info(f"Found {len(entities)} entities and {len(relations)} relations")
        return KnowledgeGraph(entities=entities, relations=relations)