import pytest
from unittest.mock import Mock, AsyncMock
from pydantic import ValidationError

from mcp_neo4j_memory.server import format_namespace, create_mcp_server
from mcp_neo4j_memory.neo4j_memory import Neo4jMemory, KnowledgeGraph, Entity, EntityType, Relation, RelationType, ObservationAddition


class TestFormatNamespace:
    """Test the format_namespace function behavior."""

    def testformat_namespace_empty_string(self):
        """Test format_namespace with empty string returns empty string."""
        assert format_namespace("") == ""

    def testformat_namespace_no_hyphen(self):
        """Test format_namespace adds hyphen when not present."""
        assert format_namespace("myapp") == "myapp-"

    def testformat_namespace_with_hyphen(self):
        """Test format_namespace returns string as-is when hyphen already present."""
        assert format_namespace("myapp-") == "myapp-"

    def testformat_namespace_complex_name(self):
        """Test format_namespace with complex namespace names."""
        assert format_namespace("company.product") == "company.product-"
        assert format_namespace("app_v2") == "app_v2-"


class TestNamespacing:
    """Test namespacing functionality."""

    @pytest.fixture
    def mock_memory(self):
        """Create a mock Neo4jMemory for testing."""
        memory = Mock(spec=Neo4jMemory)
        # Mock all the async methods that the tools will call
        knowledge_graph = KnowledgeGraph(entities=[], relations=[])
        memory.create_entities = AsyncMock(return_value=[])
        memory.create_relations = AsyncMock(return_value=[])
        memory.add_observations = AsyncMock(return_value=[])
        memory.delete_entities = AsyncMock(return_value=None)
        memory.delete_observations = AsyncMock(return_value=None)
        memory.delete_relations = AsyncMock(return_value=None)
        memory.search_memories = AsyncMock(return_value=knowledge_graph)
        memory.find_memories_by_name = AsyncMock(return_value=knowledge_graph)
        # Mock the driver for cypher/GDS tools
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_namespace_tool_prefixes(self, mock_memory):
        """Test that tools are correctly prefixed with namespace."""
        # Test with namespace
        namespaced_server = create_mcp_server(mock_memory, namespace="test-ns")
        tools = await namespaced_server.get_tools()
        
        expected_tools = [
            "test-ns-create_entities",
            "test-ns-create_relations",
            "test-ns-add_observations",
            "test-ns-delete_entities",
            "test-ns-delete_observations",
            "test-ns-delete_relations",
            "test-ns-search_memories",
            "test-ns-find_memories_by_name",
            "test-ns-list_allowed_types",
            "test-ns-list_allowed_relation_types",
            "test-ns-get_neo4j_schema",
            "test-ns-read_neo4j_cypher",
            "test-ns-gds_create_projection",
            "test-ns-gds_drop_projection",
            "test-ns-gds_pagerank",
            "test-ns-gds_louvain",
            "test-ns-gds_wcc",
        ]
        
        for expected_tool in expected_tools:
            assert expected_tool in tools.keys(), f"Tool {expected_tool} not found in tools"

        # Test without namespace (default tools)
        default_server = create_mcp_server(mock_memory)
        default_tools = await default_server.get_tools()
        
        expected_default_tools = [
            "create_entities",
            "create_relations",
            "add_observations",
            "delete_entities",
            "delete_observations",
            "delete_relations",
            "search_memories",
            "find_memories_by_name",
            "list_allowed_types",
            "list_allowed_relation_types",
            "get_neo4j_schema",
            "read_neo4j_cypher",
            "gds_create_projection",
            "gds_drop_projection",
            "gds_pagerank",
            "gds_louvain",
            "gds_wcc",
        ]
        
        for expected_tool in expected_default_tools:
            assert expected_tool in default_tools.keys(), f"Default tool {expected_tool} not found"

    @pytest.mark.asyncio
    async def test_namespace_tool_functionality(self, mock_memory):
        """Test that namespaced tools function correctly."""
        namespaced_server = create_mcp_server(mock_memory, namespace="test")
        tools = await namespaced_server.get_tools()

        # Test that a namespaced tool exists and works
        search_tool = tools.get("test-search_memories")
        assert search_tool is not None

        # Call the tool function and verify it works
        result = await search_tool.fn(query="test", limit=10)
        mock_memory.search_memories.assert_called_once()

    @pytest.mark.asyncio
    async def test_multiple_namespace_isolation(self, mock_memory):
        """Test that different namespaces create isolated tool sets."""
        server_a = create_mcp_server(mock_memory, namespace="app-a")
        server_b = create_mcp_server(mock_memory, namespace="app-b")
        
        tools_a = await server_a.get_tools()
        tools_b = await server_b.get_tools()
        
        # Verify app-a tools exist in server_a but not server_b
        assert "app-a-search_memories" in tools_a.keys()
        assert "app-a-search_memories" not in tools_b.keys()

        # Verify app-b tools exist in server_b but not server_a
        assert "app-b-search_memories" in tools_b.keys()
        assert "app-b-search_memories" not in tools_a.keys()
        
        # Verify both servers have the same number of tools
        assert len(tools_a) == len(tools_b)

    @pytest.mark.asyncio
    async def test_namespace_hyphen_handling(self, mock_memory):
        """Test namespace hyphen handling edge cases."""
        # Namespace already ending with hyphen
        server_with_hyphen = create_mcp_server(mock_memory, namespace="myapp-")
        tools_with_hyphen = await server_with_hyphen.get_tools()
        assert "myapp-search_memories" in tools_with_hyphen.keys()

        # Namespace without hyphen
        server_without_hyphen = create_mcp_server(mock_memory, namespace="myapp")
        tools_without_hyphen = await server_without_hyphen.get_tools()
        assert "myapp-search_memories" in tools_without_hyphen.keys()
        
        # Both should result in identical tool names
        assert set(tools_with_hyphen.keys()) == set(tools_without_hyphen.keys())

    @pytest.mark.asyncio
    async def test_complex_namespace_names(self, mock_memory):
        """Test complex namespace naming scenarios."""
        complex_namespaces = [
            "company.product",
            "app_v2", 
            "client-123",
            "test.env.staging"
        ]
        
        for namespace in complex_namespaces:
            server = create_mcp_server(mock_memory, namespace=namespace)
            tools = await server.get_tools()
            
            # Verify tools are properly prefixed
            expected_tool = f"{namespace}-search_memories"
            assert expected_tool in tools.keys(), f"Tool {expected_tool} not found for namespace '{namespace}'"

    @pytest.mark.asyncio
    async def test_namespace_tool_count_consistency(self, mock_memory):
        """Test that namespaced and default servers have the same number of tools."""
        default_server = create_mcp_server(mock_memory)
        namespaced_server = create_mcp_server(mock_memory, namespace="test")
        
        default_tools = await default_server.get_tools()
        namespaced_tools = await namespaced_server.get_tools()
        
        # Should have the same number of tools
        assert len(default_tools) == len(namespaced_tools)
        
        # Verify we have the expected number of tools (17 tools based on the server implementation)
        assert len(default_tools) == 17
        assert len(namespaced_tools) == 17


class TestEntityTypeValidation:
    """Test that the EntityType enum properly constrains entity types."""

    def test_valid_entity_type_accepted(self):
        """Test that a valid EntityType value is accepted by Entity model."""
        entity = Entity(
            name="Test Entity",
            type="Technical",
            observations=["This is a test"],
        )
        assert entity.type == EntityType.TECHNICAL
        assert entity.type.value == "Technical"

    def test_invalid_entity_type_rejected(self):
        """Test that an invalid type string is rejected by Entity model."""
        with pytest.raises(ValidationError) as exc_info:
            Entity(
                name="Bad Entity",
                type="Consciousness_Theory",
                observations=["Should fail"],
            )
        assert "type" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        """Test that every EntityType enum value is accepted."""
        for entity_type in EntityType:
            entity = Entity(
                name=f"Test {entity_type.value}",
                type=entity_type.value,
                observations=["Testing"],
            )
            assert entity.type == entity_type

    def test_entity_type_enum_has_20_members(self):
        """Test that the EntityType enum has exactly 20 members."""
        assert len(EntityType) == 21

    def test_case_sensitive_rejection(self):
        """Test that type matching is case-sensitive (lowercase 'technical' rejected)."""
        with pytest.raises(ValidationError):
            Entity(
                name="Case Test",
                type="technical",
                observations=["Should fail"],
            )


class TestListAllowedTypes:
    """Test the list_allowed_types tool."""

    @pytest.fixture
    def mock_memory(self):
        """Create a mock Neo4jMemory for testing."""
        memory = Mock(spec=Neo4jMemory)
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_list_allowed_types_returns_all_types(self, mock_memory):
        """Test that list_allowed_types returns all 20 types."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")
        assert tool is not None

        result = await tool.fn()
        # ToolResult has .content which is a list of TextContent
        import json
        text = result.content[0].text
        data = json.loads(text)

        assert data["total_types"] == 21

        # Collect all types across categories
        all_types = set()
        for category in data["categories"].values():
            all_types.update(category["types"].keys())

        assert len(all_types) == 21

        # Verify all EntityType values are present
        for entity_type in EntityType:
            assert entity_type.value in all_types, f"{entity_type.value} missing from list_allowed_types"

    @pytest.mark.asyncio
    async def test_list_allowed_types_has_descriptions(self, mock_memory):
        """Test that every type has a non-empty description."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        for category in data["categories"].values():
            for type_name, description in category["types"].items():
                assert isinstance(description, str) and len(description) > 0, \
                    f"Type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_allowed_types_categories(self, mock_memory):
        """Test that types are organized into 4 categories."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        expected_categories = {"structural", "knowledge_domains", "activity_types", "meta"}
        assert set(data["categories"].keys()) == expected_categories

        # Verify category sizes
        assert len(data["categories"]["structural"]["types"]) == 4
        assert len(data["categories"]["knowledge_domains"]["types"]) == 8
        assert len(data["categories"]["activity_types"]["types"]) == 6
        assert len(data["categories"]["meta"]["types"]) == 3


class TestRelationTypeValidation:
    """Test that the RelationType enum properly constrains relation types."""

    def test_valid_relation_type_accepted(self):
        """Test that a valid RelationType value is accepted by Relation model."""
        relation = Relation(
            source="Node A",
            target="Node B",
            relationType="INFORMING",
        )
        assert relation.relationType == RelationType.INFORMING
        assert relation.relationType.value == "INFORMING"

    def test_invalid_relation_type_rejected(self):
        """Test that an invalid type string is rejected by Relation model."""
        with pytest.raises(ValidationError) as exc_info:
            Relation(
                source="Node A",
                target="Node B",
                relationType="WORKS_AT",
            )
        assert "relationType" in str(exc_info.value)

    def test_all_enum_values_accepted(self):
        """Test that every RelationType enum value is accepted."""
        for rel_type in RelationType:
            relation = Relation(
                source=f"Source {rel_type.value}",
                target=f"Target {rel_type.value}",
                relationType=rel_type.value,
            )
            assert relation.relationType == rel_type

    def test_relation_type_enum_has_15_members(self):
        """Test that the RelationType enum has exactly 15 members."""
        assert len(RelationType) == 16

    def test_case_sensitive_rejection(self):
        """Test that type matching is case-sensitive (lowercase 'informing' rejected)."""
        with pytest.raises(ValidationError):
            Relation(
                source="Node A",
                target="Node B",
                relationType="informing",
            )


class TestListAllowedRelationTypes:
    """Test the list_allowed_relation_types tool."""

    @pytest.fixture
    def mock_memory(self):
        """Create a mock Neo4jMemory for testing."""
        memory = Mock(spec=Neo4jMemory)
        memory.driver = AsyncMock()
        memory.driver.execute_query = AsyncMock(return_value=Mock(records=[]))
        return memory

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_returns_all_types(self, mock_memory):
        """Test that list_allowed_relation_types returns all 15 types."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")
        assert tool is not None

        result = await tool.fn()
        import json
        text = result.content[0].text
        data = json.loads(text)

        assert data["total_types"] == 16

        # Collect all types across domains and subcategories
        all_types = set()
        for domain in data["domains"].values():
            for subcategory in domain["subcategories"].values():
                all_types.update(subcategory["types"].keys())

        assert len(all_types) == 16

        # Verify all RelationType values are present
        for rel_type in RelationType:
            assert rel_type.value in all_types, f"{rel_type.value} missing from list_allowed_relation_types"

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_has_descriptions(self, mock_memory):
        """Test that every type has a non-empty description."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        for domain in data["domains"].values():
            for subcategory in domain["subcategories"].values():
                for type_name, description in subcategory["types"].items():
                    assert isinstance(description, str) and len(description) > 0, \
                        f"Relation type {type_name} has empty or missing description"

    @pytest.mark.asyncio
    async def test_list_allowed_relation_types_domains(self, mock_memory):
        """Test that types are organized into 3 domains."""
        server = create_mcp_server(mock_memory)
        tools = await server.get_tools()
        tool = tools.get("list_allowed_relation_types")

        result = await tool.fn()
        import json
        data = json.loads(result.content[0].text)

        expected_domains = {"nouns", "gerunds", "backbone"}
        assert set(data["domains"].keys()) == expected_domains

        # Verify subcategory counts
        assert len(data["domains"]["nouns"]["subcategories"]) == 3
        assert len(data["domains"]["gerunds"]["subcategories"]) == 4
        assert len(data["domains"]["backbone"]["subcategories"]) == 1


class TestTemporalFields:
    """Test that bi-temporal metadata fields work correctly on models."""

    def test_entity_accepts_temporal_fields(self):
        """Test Entity model accepts t_created and t_valid as optional strings."""
        entity = Entity(
            name="Test Entity",
            type="Technical",
            observations=["A fact"],
            t_created="2026-03-04T10:00:00Z",
            t_valid="2026-03-01T00:00:00Z",
        )
        assert entity.t_created == "2026-03-04T10:00:00Z"
        assert entity.t_valid == "2026-03-01T00:00:00Z"

    def test_entity_temporal_fields_default_none(self):
        """Test Entity model works without temporal fields (backward compat)."""
        entity = Entity(
            name="Old Entity",
            type="Personal",
            observations=["Still works"],
        )
        assert entity.t_created is None
        assert entity.t_valid is None

    def test_entity_partial_temporal_fields(self):
        """Test Entity with only t_valid provided (no t_created)."""
        entity = Entity(
            name="Partial",
            type="Insight",
            observations=["Some insight"],
            t_valid="2026-01-15T12:00:00Z",
        )
        assert entity.t_created is None
        assert entity.t_valid == "2026-01-15T12:00:00Z"

    def test_relation_accepts_temporal_fields(self):
        """Test Relation model accepts t_created and t_valid."""
        relation = Relation(
            source="A",
            target="B",
            relationType="INFORMING",
            t_created="2026-03-04T10:00:00Z",
            t_valid="2026-03-01T00:00:00Z",
        )
        assert relation.t_created == "2026-03-04T10:00:00Z"
        assert relation.t_valid == "2026-03-01T00:00:00Z"

    def test_relation_temporal_fields_default_none(self):
        """Test Relation model works without temporal fields (backward compat)."""
        relation = Relation(
            source="A",
            target="B",
            relationType="ENABLING",
        )
        assert relation.t_created is None
        assert relation.t_valid is None

    def test_relation_no_expired_or_invalid_fields(self):
        """Test Relation model does NOT have t_expired/t_invalid.

        Consciousness doesn't invalidate relationships — understanding shifts
        are captured by EVOLUTION edges, not invalidation timestamps.
        """
        relation = Relation(
            source="A",
            target="B",
            relationType="ENABLING",
        )
        assert not hasattr(relation, 't_expired') or 't_expired' not in relation.model_fields
        assert not hasattr(relation, 't_invalid') or 't_invalid' not in relation.model_fields

    def test_observation_addition_accepts_source_session(self):
        """Test ObservationAddition accepts optional source_session field."""
        obs = ObservationAddition(
            entityName="Test Entity",
            observations=["New observation"],
            source_session="session-abc-123",
        )
        assert obs.source_session == "session-abc-123"

    def test_observation_addition_source_session_default_none(self):
        """Test ObservationAddition works without source_session (backward compat)."""
        obs = ObservationAddition(
            entityName="Test Entity",
            observations=["New observation"],
        )
        assert obs.source_session is None

    def test_observation_addition_model_dump_includes_source_session(self):
        """Test that model_dump includes source_session for Cypher parameterization."""
        obs = ObservationAddition(
            entityName="Test",
            observations=["Fact"],
            source_session="sess-001",
        )
        dumped = obs.model_dump()
        assert dumped["source_session"] == "sess-001"
        assert dumped["entityName"] == "Test"

    def test_observation_addition_model_dump_null_source_session(self):
        """Test that model_dump includes null source_session when not provided."""
        obs = ObservationAddition(
            entityName="Test",
            observations=["Fact"],
        )
        dumped = obs.model_dump()
        assert dumped["source_session"] is None
