# mcp-neo4j-kg-memory

Unified Neo4j Knowledge Graph MCP Server — bounded memory CRUD, read-only Cypher, and GDS analytics.

## Overview

A [Model Context Protocol](https://modelcontextprotocol.io/) server that provides persistent knowledge graph memory through Neo4j. Stores entities as graph nodes with observations, connects them via typed relationships, and exposes bounded query tools designed for LLM context windows.

Consolidates three previously separate servers (`mcp-neo4j-temporal-substrate`, `mcp-neo4j-memory-cypher`, `mcp-neo4j-gds`) into one package with **15 tools across 4 categories**.

Works with [Neo4j Aura](https://console.neo4j.io) (free tier available), self-hosted Neo4j, or local Docker instances.

### Graph Schema

- **Memory** — Node with `name`, `type`, and `observations` (list of strings)
- **Relationship** — Directed edge between two Memory nodes with a dynamic type

### Architecture

This server is designed for **knowledge graphs at scale** — hundreds of interconnected entities forming temporal chains and dense relationship networks.

**Bounded traversal by design:**
- `search_memories`: Default 10, max 50 entities
- `find_memories_by_name`: Default 20, max 50 entities
- `read_neo4j_cypher`: Read-only with timeout and 200k char safety truncation
- GDS tools: Default 20, max 1000 result rows
- All relationship queries constrained to only returned entities

**Why no `write_neo4j_cypher`?** All mutations go through bounded CRUD tools. Raw Cypher writes would bypass temporal invariants, skip validation, and risk unbounded side effects. The CRUD tools (create_entities, create_relations, etc.) are the only mutation path.

For toy chatbot memory (dozens of isolated facts), consider the original `mcp-neo4j-memory` package.

## Tools (15)

### CRUD Tools (6)

| Tool | Description |
|------|-------------|
| `create_entities` | Create entities with name, type, and observations. Merges if entity exists. |
| `create_relations` | Create directed relationships between existing entities |
| `add_observations` | Append observations to existing entities (deduplicates) |
| `delete_entities` | Delete entities and all their relationships |
| `delete_observations` | Remove specific observations from entities |
| `delete_relations` | Remove specific relationships |

### Query Tools (2)

| Tool | Description |
|------|-------------|
| `search_memories` | Fulltext search across names, types, observations. Returns top-N by relevance score. `limit` param (default 10, max 50). |
| `find_memories_by_name` | Exact name match retrieval. Returns entities + relationships between them only. `limit` param (default 20, max 50). |

Both tools implement bounded relationship traversal — relationships are constrained to only the entities in the result set.

### Cypher Tools (2)

| Tool | Description |
|------|-------------|
| `get_neo4j_schema` | Introspect database schema via `apoc.meta.schema()`. Requires APOC (available on Aura by default). |
| `read_neo4j_cypher` | Execute read-only Cypher queries. Rejects write operations (MERGE/CREATE/SET/DELETE/etc). Timeout and result sanitization built in. |

### GDS Analytics Tools (5)

| Tool | Description |
|------|-------------|
| `gds_create_projection` | Project a subgraph into GDS memory for algorithm execution |
| `gds_drop_projection` | Drop a projection to free GDS memory |
| `gds_pagerank` | PageRank centrality — find most important/connected nodes. `result_limit` param (default 20). |
| `gds_louvain` | Louvain community detection — identify clusters. `result_limit` param (default 20). |
| `gds_wcc` | Weakly Connected Components — find connected subgraphs. `result_limit` param (default 20). |

GDS tools resolve internal node IDs to actual `name`/`type` properties. Requires GDS-enabled Neo4j instance (Aura Professional/Enterprise, or self-hosted with GDS plugin).

## Installation

```bash
pip install mcp-neo4j-kg-memory
```

## Configuration

### Claude Desktop / Claude Code

Add to your MCP settings:

```json
"mcpServers": {
  "neo4j": {
    "command": "uvx",
    "args": [
      "mcp-neo4j-kg-memory@1.0.0",
      "--db-url", "neo4j+s://xxxx.databases.neo4j.io",
      "--username", "<your-username>",
      "--password", "<your-password>"
    ]
  }
}
```

Or with environment variables:

```json
"mcpServers": {
  "neo4j": {
    "command": "uvx",
    "args": ["mcp-neo4j-kg-memory@1.0.0"],
    "env": {
      "NEO4J_URL": "neo4j+s://xxxx.databases.neo4j.io",
      "NEO4J_USERNAME": "<your-username>",
      "NEO4J_PASSWORD": "<your-password>"
    }
  }
}
```

### Namespacing

For multi-tenant deployments, prefix all tool names:

```json
"args": ["mcp-neo4j-kg-memory@1.0.0", "--namespace", "myapp", "--db-url", "..."]
```

Tools become: `myapp-search_memories`, `myapp-create_entities`, `myapp-read_neo4j_cypher`, etc.

Also available as `NEO4J_NAMESPACE` env var.

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NEO4J_URI` / `NEO4J_URL` | `bolt://localhost:7687` | Neo4j connection URI |
| `NEO4J_USERNAME` | `neo4j` | Neo4j username |
| `NEO4J_PASSWORD` | `password` | Neo4j password |
| `NEO4J_DATABASE` | `neo4j` | Neo4j database name |
| `NEO4J_TRANSPORT` | `stdio` | Transport protocol (`stdio`, `http`, `sse`) |
| `NEO4J_MCP_SERVER_HOST` | `127.0.0.1` | Host to bind to (HTTP/SSE only) |
| `NEO4J_MCP_SERVER_PORT` | `8000` | Port (HTTP/SSE only) |
| `NEO4J_MCP_SERVER_PATH` | `/mcp/` | Path (HTTP/SSE only) |
| `NEO4J_MCP_SERVER_ALLOW_ORIGINS` | _(empty)_ | Comma-separated CORS origins |
| `NEO4J_MCP_SERVER_ALLOWED_HOSTS` | `localhost,127.0.0.1` | Comma-separated allowed hosts (DNS rebinding protection) |
| `NEO4J_NAMESPACE` | _(empty)_ | Tool name prefix |
| `NEO4J_READ_TIMEOUT` | `30` | Cypher read query timeout (seconds) |
| `NEO4J_SCHEMA_SAMPLE_SIZE` | `1000` | Sample size for `apoc.meta.schema()` |

### CLI Flags

All environment variables have corresponding CLI flags:

```bash
mcp-neo4j-kg-memory \
  --db-url "neo4j+s://..." \
  --username neo4j \
  --password secret \
  --database neo4j \
  --transport http \
  --server-host 0.0.0.0 \
  --server-port 8000 \
  --server-path /mcp/ \
  --namespace myapp \
  --read-timeout 60 \
  --schema-sample-size 500 \
  --allow-origins "https://example.com" \
  --allowed-hosts "example.com,www.example.com"
```

## Transport Modes

- **STDIO** (default): Standard input/output for Claude Desktop and local tools
- **HTTP**: Streamable HTTP for web deployments and microservices
- **SSE**: Server-Sent Events for legacy web clients

## Security

### DNS Rebinding Protection

TrustedHost middleware validates Host headers. Only `localhost` and `127.0.0.1` allowed by default.

### CORS Protection

No origins allowed by default (secure). Configure explicitly for web deployments:

```bash
mcp-neo4j-kg-memory --transport http \
  --allowed-hosts "example.com" \
  --allow-origins "https://example.com"
```

## Docker

```bash
docker run --rm -p 8000:8000 \
  -e NEO4J_URI="bolt://host.docker.internal:7687" \
  -e NEO4J_USERNAME="neo4j" \
  -e NEO4J_PASSWORD="password" \
  -e NEO4J_TRANSPORT="http" \
  -e NEO4J_MCP_SERVER_HOST="0.0.0.0" \
  mcp-neo4j-kg-memory:latest
```

## Development

```bash
# Install uv
pip install uv

# Setup
git clone <repo-url>
cd mcp-neo4j-kg-memory
uv venv && source .venv/bin/activate
uv pip install -e ".[dev]"

# Run unit tests
uv run pytest tests/unit/ -v

# Build
uv build
```

## License

MIT License. See LICENSE file.
