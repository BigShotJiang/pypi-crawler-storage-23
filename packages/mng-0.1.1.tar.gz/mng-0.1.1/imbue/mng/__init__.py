import pluggy

hookimpl = pluggy.HookimplMarker("mng")
