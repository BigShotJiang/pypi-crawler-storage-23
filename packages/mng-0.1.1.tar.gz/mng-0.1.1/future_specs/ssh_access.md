sshd is started inside the agent host as soon as it is created, and all access to the host is done via SSH.

Only a single key is made for any given provider right now (ex: Modal), but it may be worthwhile to change to per-host keys instead [future]
