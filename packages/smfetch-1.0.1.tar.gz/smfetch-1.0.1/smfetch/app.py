"""FastAPI web application for smfetch."""

from __future__ import annotations

import argparse
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any

import uvicorn
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from loguru import logger
from pydantic import BaseModel

from smfetch import smonline as smo
from smfetch import zenius as zen
from smfetch.config import config
from smfetch.jobs import jobs

STATIC_DIR = Path(__file__).parent / "static"


# --- Pydantic request models ---


class ConfigUpdate(BaseModel):
    songs_dir: str | None = None
    log_dir: str | None = None
    config_dir: str | None = None


class ZenSongDownload(BaseModel):
    song_name: str
    song_page: str
    pack_name: str
    pack_page: str
    group: str = ""
    sp: str = ""
    dp: str = ""
    artist: str = ""


class ZenCategoryDownload(BaseModel):
    id: str
    title: str = ""


class ZenGroupDownload(BaseModel):
    group: str


class SmoDownload(BaseModel):
    pack_title: str
    download: str


# --- App lifespan ---


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    logger.remove()
    logger.add(str(config.log_file), retention="7 days", rotation="10 MB")
    logger.info("smfetch starting up")
    smo.pack_cache.build_async()
    yield
    logger.info("smfetch shutting down")


app = FastAPI(title="smfetch", version="1.0.0", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# --- UI ---


@app.get("/", response_class=HTMLResponse)
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


# --- Config ---


@app.get("/api/config")
async def get_config() -> dict[str, str]:
    return {
        "songs_dir": config.songs_dir,
        "log_dir": config.log_dir,
        "config_dir": config.config_dir,
    }


@app.put("/api/config")
async def update_config(body: ConfigUpdate) -> dict[str, str]:
    if body.songs_dir is not None:
        config.songs_dir = body.songs_dir
    if body.log_dir is not None:
        config.log_dir = body.log_dir
    if body.config_dir is not None:
        config.config_dir = body.config_dir
    config.ensure_dirs()
    config.save()
    return await get_config()


# --- Jobs ---


@app.get("/api/jobs")
async def list_jobs() -> dict[str, Any]:
    return {
        "jobs": jobs.list_jobs(),
        "active_count": jobs.active_count(),
    }


@app.post("/api/jobs/clear")
async def clear_jobs() -> dict[str, int]:
    return {"cleared": jobs.clear_completed()}


# --- Zenius endpoints ---


@app.get("/api/zenius/search")
async def zenius_search(
    title: str = Query(default=""),
    artist: str = Query(default=""),
) -> list[dict[str, Any]]:
    results = zen.search_songs(title, artist)
    return [r.to_dict() for r in results]


@app.get("/api/zenius/categories")
async def zenius_categories(
    group: str = Query(..., description="ARCADE, SPINOFF, OFFICIAL, or USER"),
) -> list[dict[str, str]]:
    try:
        g = zen.Group[group.upper()]
    except KeyError:
        return []
    return zen.fetch_categories(g)


@app.post("/api/zenius/download/song")
async def zenius_download_song(body: ZenSongDownload) -> dict[str, str]:
    result = zen.SearchResult(
        song_name=body.song_name,
        song_page=body.song_page,
        pack_name=body.pack_name,
        pack_page=body.pack_page,
        group=body.group,
        difficulties=zen.Levels(body.sp, body.dp),
        artist=body.artist,
    )
    job_id = jobs.submit(
        f"Zenius: {result.song_name} by {result.artist}",
        zen.download_song,
        result,
    )
    return {"job_id": job_id}


@app.post("/api/zenius/download/category")
async def zenius_download_category(body: ZenCategoryDownload) -> dict[str, str]:
    title = body.title or f"Category {body.id}"
    job_id = jobs.submit(
        f"Zenius pack: {title}",
        zen.download_category,
        body.id,
    )
    return {"job_id": job_id}


@app.post("/api/zenius/download/group")
async def zenius_download_group(body: ZenGroupDownload) -> dict[str, str]:
    try:
        group = zen.Group[body.group.upper()]
    except KeyError:
        return {"error": f"Invalid group: {body.group}"}
    job_id = jobs.submit(
        f"Zenius bundle: {group.name}",
        zen.download_group,
        group,
    )
    return {"job_id": job_id}


# --- SMOnline endpoints ---


@app.get("/api/smonline/search")
async def smonline_search(
    category: str = Query(..., description="title or artist"),
    query: str = Query(...),
) -> list[dict[str, Any]]:
    if category not in ("title", "artist"):
        return []
    entries = smo.search_songs(category, query)
    return [e.to_dict() for e in entries]


@app.get("/api/smonline/packs")
async def smonline_packs() -> dict[str, Any]:
    return {
        "ready": smo.pack_cache.is_ready,
        "building": smo.pack_cache.is_building,
        "packs": [e.to_dict() for e in smo.pack_cache.entries],
    }


@app.post("/api/smonline/packs/refresh")
async def smonline_refresh_cache() -> dict[str, str]:
    smo.pack_cache.build_async()
    return {"status": "rebuilding"}


@app.post("/api/smonline/download")
async def smonline_download(body: SmoDownload) -> dict[str, str]:
    job_id = jobs.submit(
        f"SMOnline: {body.pack_title}",
        smo.download_pack,
        body.pack_title,
        body.download,
    )
    return {"job_id": job_id}


# --- Entrypoint ---


DEFAULT_PORT = 8095


def main() -> None:
    parser = argparse.ArgumentParser(description="smfetch web interface")
    parser.add_argument(
        "-p",
        "--port",
        type=int,
        default=DEFAULT_PORT,
        help=f"port for the web interface (default: {DEFAULT_PORT})",
    )
    args = parser.parse_args()

    print(f"Starting smfetch on http://localhost:{args.port}")
    uvicorn.run(
        "smfetch.app:app",
        host="127.0.0.1",
        port=args.port,
        log_level="warning",
    )


if __name__ == "__main__":
    main()
