"""Background job management for download tasks."""

from __future__ import annotations

import threading
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from loguru import logger


class JobStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class Job:
    id: str
    name: str
    status: JobStatus
    created_at: datetime
    error: str | None = None
    _thread: threading.Thread | None = field(default=None, repr=False)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "status": self.status.value,
            "created_at": self.created_at.isoformat(),
            "error": self.error,
        }


class JobManager:
    """Thread-safe job manager with automatic status tracking."""

    def __init__(self) -> None:
        self._jobs: dict[str, Job] = {}
        self._lock = threading.Lock()

    def submit(self, name: str, fn: Callable[..., Any], *args: Any, **kwargs: Any) -> str:
        job_id = uuid.uuid4().hex[:8]

        def _wrapper() -> None:
            try:
                with self._lock:
                    self._jobs[job_id].status = JobStatus.RUNNING
                fn(*args, **kwargs)
                with self._lock:
                    self._jobs[job_id].status = JobStatus.COMPLETED
                logger.info(f"Job completed: {name}")
            except Exception as e:
                with self._lock:
                    self._jobs[job_id].status = JobStatus.FAILED
                    self._jobs[job_id].error = str(e)
                logger.error(f"Job failed: {name} - {e}")

        thread = threading.Thread(target=_wrapper, daemon=True)

        job = Job(
            id=job_id,
            name=name,
            status=JobStatus.PENDING,
            created_at=datetime.now(),
            _thread=thread,
        )
        with self._lock:
            self._jobs[job_id] = job
        thread.start()
        logger.info(f"Job started: {name} ({job_id})")
        return job_id

    def list_jobs(self) -> list[dict[str, Any]]:
        with self._lock:
            return [job.to_dict() for job in self._jobs.values()]

    def active_count(self) -> int:
        with self._lock:
            return sum(
                1
                for job in self._jobs.values()
                if job.status in (JobStatus.PENDING, JobStatus.RUNNING)
            )

    def clear_completed(self) -> int:
        with self._lock:
            done = [
                jid
                for jid, job in self._jobs.items()
                if job.status in (JobStatus.COMPLETED, JobStatus.FAILED)
            ]
            for jid in done:
                del self._jobs[jid]
            return len(done)


jobs = JobManager()
