"""Cross-platform configuration with sensible defaults per OS.

Config file location:
  - Windows: %APPDATA%/smfetch/config.json
  - macOS:   ~/Library/Application Support/smfetch/config.json
  - Linux:   $XDG_CONFIG_HOME/smfetch/config.json (default ~/.config/smfetch/)

Songs directory:
  - Windows: %USERPROFILE%/Music/StepMania Songs
  - macOS:   ~/Music/StepMania Songs
  - Linux:   ~/.local/share/smfetch

Log directory:
  - Windows: %LOCALAPPDATA%/smfetch/logs
  - macOS:   ~/Library/Logs/smfetch
  - Linux:   $XDG_STATE_HOME/smfetch/logs (default ~/.local/state/smfetch/logs)
"""

from __future__ import annotations

import json
import os
import platform
from dataclasses import asdict, dataclass, field
from pathlib import Path

from loguru import logger


def _default_config_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        return Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / "smfetch"
    elif system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "smfetch"
    else:
        return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "smfetch"


def _default_songs_dir() -> Path:
    system = platform.system()
    if system in ("Windows", "Darwin"):
        return Path.home() / "Music" / "StepMania Songs"
    else:
        return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "smfetch"


def _default_log_dir() -> Path:
    system = platform.system()
    if system == "Windows":
        return (
            Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
            / "smfetch"
            / "logs"
        )
    elif system == "Darwin":
        return Path.home() / "Library" / "Logs" / "smfetch"
    else:
        return (
            Path(os.environ.get("XDG_STATE_HOME", Path.home() / ".local" / "state"))
            / "smfetch"
            / "logs"
        )


CONFIG_PATH = _default_config_dir() / "config.json"


@dataclass
class AppConfig:
    songs_dir: str = field(default_factory=lambda: str(_default_songs_dir()))
    log_dir: str = field(default_factory=lambda: str(_default_log_dir()))
    config_dir: str = field(default_factory=lambda: str(_default_config_dir()))

    @property
    def songs_path(self) -> Path:
        return Path(self.songs_dir)

    @property
    def log_path(self) -> Path:
        return Path(self.log_dir)

    @property
    def log_file(self) -> Path:
        return self.log_path / "smfetch.log"

    def ensure_dirs(self) -> None:
        self.songs_path.mkdir(parents=True, exist_ok=True)
        self.log_path.mkdir(parents=True, exist_ok=True)
        Path(self.config_dir).mkdir(parents=True, exist_ok=True)

    def save(self) -> None:
        path = Path(self.config_dir) / "config.json"
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self), indent=2))
        logger.info(f"Config saved to {path}")

    @classmethod
    def load(cls) -> AppConfig:
        path = CONFIG_PATH
        if path.exists():
            try:
                data = json.loads(path.read_text())
                return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})
            except (json.JSONDecodeError, TypeError) as e:
                logger.warning(f"Failed to load config from {path}: {e}")
        config = cls()
        config.ensure_dirs()
        config.save()
        return config


# Singleton config loaded at import
config = AppConfig.load()
config.ensure_dirs()
