"""StepManiaOnline scraping and download logic."""

from __future__ import annotations

import shutil
import threading
import zipfile as zf
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any, NamedTuple

import requests
from bs4 import BeautifulSoup as bs
from bs4 import Tag
from loguru import logger

from smfetch.config import config

BASE = "https://stepmaniaonline.net"
SEARCH = f"{BASE}/search"


class PackEntry(NamedTuple):
    pack_title: str
    size: str
    songs: int
    created: date
    download: str
    idx: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "pack_title": self.pack_title,
            "size": self.size,
            "songs": self.songs,
            "created": self.created.isoformat(),
            "download": self.download,
            "idx": self.idx,
        }


class SongEntry(NamedTuple):
    song_title: str
    artist: str
    pack_title: str
    download: str
    idx: int

    def to_dict(self) -> dict[str, Any]:
        return {
            "song_title": self.song_title,
            "artist": self.artist,
            "pack_title": self.pack_title,
            "download": self.download,
            "idx": self.idx,
        }


def _parse_pack_row(row: Tag) -> PackEntry:
    tags = row.select("td")
    title = tags[1].find("a").text  # type: ignore[union-attr]
    size = tags[2].text.replace("\xa0", " ")
    songs = int(tags[3].text)
    created = datetime.strptime(tags[5].text.strip(), "%Y-%m-%d").date()
    download = f"{BASE}{tags[6].find('a').get('href')}"  # type: ignore[union-attr]
    idx = int(download.split("/")[-2])
    return PackEntry(title, size, songs, created, download, idx)


def _parse_search_row(row: Tag) -> SongEntry:
    tags = row.select("td")
    title = tags[1].text
    artist = tags[2].text
    pack = tags[3].text
    download = f"{BASE}/download{tags[3].find('a').get('href')}/"  # type: ignore[union-attr]
    idx = int(download.split("/")[-2])
    return SongEntry(title, artist, pack, download, idx)


# --- Pack cache ---


@dataclass
class PackCache:
    _entries: list[PackEntry] = field(default_factory=list)
    _lock: threading.Lock = field(default_factory=threading.Lock)
    _building: bool = False
    _built: bool = False

    def build(self) -> None:
        """Fetch all packs from the site."""
        with self._lock:
            if self._building:
                return
            self._building = True

        try:
            logger.info("Building SMOnline pack cache...")
            response = requests.get(f"{BASE}/packs").text
            soup = bs(response, "html.parser")
            entries = [_parse_pack_row(row) for row in soup.select("tbody tr")]
            with self._lock:
                self._entries = entries
                self._built = True
            logger.info(f"Pack cache built: {len(entries)} packs")
        finally:
            with self._lock:
                self._building = False

    def build_async(self) -> None:
        """Start cache build in background thread."""
        thread = threading.Thread(target=self.build, daemon=True)
        thread.start()

    @property
    def is_ready(self) -> bool:
        with self._lock:
            return self._built

    @property
    def is_building(self) -> bool:
        with self._lock:
            return self._building

    @property
    def entries(self) -> list[PackEntry]:
        with self._lock:
            return list(self._entries)

    def refresh(self) -> None:
        """Force rebuild the cache."""
        with self._lock:
            self._built = False
            self._entries = []
        self.build()


pack_cache = PackCache()


# --- Search ---


def search_songs(category: str, query: str) -> list[SongEntry]:
    """Search for songs by title or artist on SMOnline."""
    url = f"{SEARCH}/{category}/{query}"
    response = requests.get(url).text
    soup = bs(response, "html.parser")
    rows = soup.select("tbody tr")
    return [_parse_search_row(row) for row in rows]


# --- Download ---


def _pack_exists(title: str) -> bool:
    return (config.songs_path / title).is_dir()


def download_pack(pack_title: str, url: str) -> None:
    """Download and extract a pack zip."""
    if _pack_exists(pack_title):
        logger.warning(f"Pack '{pack_title}' already exists, skipping")
        return

    prefix = config.songs_path
    prefix.mkdir(parents=True, exist_ok=True)
    archive = prefix / f"{pack_title}.zip"

    with requests.get(url, stream=True) as r:
        with open(archive, "wb") as f:
            shutil.copyfileobj(r.raw, f)

    if not zf.is_zipfile(archive):
        logger.error(f"Download is not a valid zip: {pack_title} from {url}")
        archive.unlink(missing_ok=True)
        return

    with zf.ZipFile(archive, "r") as z:
        extracted_name = z.getinfo(z.namelist()[0]).filename.split("/")[0]
        z.extractall(path=prefix)

    extracted_path = prefix / extracted_name
    destination = prefix / pack_title
    if extracted_path != destination:
        if destination.exists():
            shutil.rmtree(destination)
        shutil.move(str(extracted_path), str(destination))

    archive.unlink()
    logger.info(f"Downloaded {pack_title}")
