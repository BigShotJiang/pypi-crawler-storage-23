"""Zenius-i-Vanisher scraping and download logic."""

from __future__ import annotations

import re
import shutil
import tempfile
import zipfile as zf
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from enum import IntEnum, auto
from itertools import repeat
from pathlib import Path
from typing import Any, NamedTuple

import requests
from bs4 import BeautifulSoup as bs
from bs4 import Tag
from loguru import logger

from smfetch.config import config

BASE = "https://zenius-i-vanisher.com/v5.2/"
SEARCH = f"{BASE}simfiles_search_ajax.php"


class Group(IntEnum):
    ARCADE = auto()
    SPINOFF = auto()
    OFFICIAL = auto()
    USER = auto()


class Levels(NamedTuple):
    sp: str
    dp: str


@dataclass
class Sim:
    idx: str
    _title: str = ""
    suffix: str = ""

    @property
    def site(self) -> str:
        raise NotImplementedError

    @property
    def zipfile(self) -> str:
        raise NotImplementedError

    @property
    def title(self) -> str:
        if not self._title:
            html = requests.get(self.site).text
            if match := re.search(r"<h1>\s?(.+?)(?=\s\/\s|<\/h1>)", html):
                self._title = match.group(1)
        return self._title + self.suffix


@dataclass
class Category(Sim):
    @property
    def site(self) -> str:
        return f"{BASE}viewsimfilecategory.php?categoryid={self.idx}"

    @property
    def zipfile(self) -> str:
        return f"{BASE}download.php?type=ddrpack&categoryid={self.idx}"


@dataclass
class Simfile(Sim):
    @property
    def site(self) -> str:
        return f"{BASE}viewsimfile.php?simfileid={self.idx}"

    @property
    def zipfile(self) -> str:
        return f"{BASE}download.php?type=ddrsimfile&simfileid={self.idx}"

    @property
    def zipfile_custom(self) -> str:
        return f"{BASE}download.php?type=ddrsimfilecustom&simfileid={self.idx}"


@dataclass
class SearchResult:
    song_name: str
    song_page: str
    pack_name: str
    pack_page: str
    group: str
    difficulties: Levels
    artist: str = ""

    @property
    def song(self) -> Simfile:
        simfile = Simfile("", self.song_name)
        if match := re.search(r"id=(\d+)", self.song_page):
            simfile.idx = match.group(1)
        return simfile

    @property
    def pack(self) -> Category:
        category = Category("", self.pack_name)
        if match := re.search(r"id=(\d+)", self.pack_page):
            category.idx = match.group(1)
        return category

    def to_dict(self) -> dict[str, Any]:
        return {
            "song_name": self.song_name,
            "artist": self.artist,
            "pack_name": self.pack_name,
            "group": self.group,
            "sp": self.difficulties.sp,
            "dp": self.difficulties.dp,
            "song_page": self.song_page,
            "pack_page": self.pack_page,
        }


# --- Scraping ---


def _get_group(listing: Tag) -> set[Group]:
    groups: set[Group] = set()
    parent = listing.find_parent()
    if parent is None:
        return groups
    sibling = parent.find_previous_sibling()
    if sibling is None:
        return groups
    text = sibling.text
    if text != "User":
        groups.add(Group.OFFICIAL)
        if text == "Arcade":
            groups.add(Group.ARCADE)
        else:
            groups.add(Group.SPINOFF)
    else:
        groups.add(Group.USER)
    return groups


def fetch_categories(group: Group) -> list[dict[str, str]]:
    """Fetch pack categories for a given group, returns list of {id, title}."""
    response = requests.get(f"{BASE}simfiles.php?category=simfiles").content
    soup = bs(response, "html.parser")
    results: list[dict[str, str]] = []
    for listing in soup.select("tr td.border select"):
        if group in _get_group(listing):
            for option in listing.select("option"):
                idx = option.get("value", "0")
                if idx != "0" and isinstance(idx, str):
                    results.append({"id": idx, "title": option.text})
    return results


def search_songs(title: str = "", artist: str = "") -> list[SearchResult]:
    """Search for songs by title and/or artist."""
    params = {"songtitle": title, "songartist": artist}
    r = requests.post(SEARCH, data=params).text
    soup = bs(r, "html.parser")
    results: list[SearchResult] = []

    for group_header in soup.select("thead th[colspan]"):
        current_group = group_header.text
        table = group_header.find_next("tbody")
        if table is None or not hasattr(table, "select"):
            continue
        for row in table.select("tr"):  # type: ignore
            cells = row.find_all("td")
            if len(cells) != 4:
                continue
            song_name, song_artist = cells[0].a["title"].split(" / ", 1)
            results.append(
                SearchResult(
                    song_name=song_name,
                    song_page=f"{BASE}{cells[0].a['href']}",
                    pack_name=cells[3].a.text.strip(),
                    pack_page=f"{BASE}{cells[3].a['href']}",
                    group=current_group,
                    difficulties=Levels(cells[1].text.strip(), cells[2].text.strip()),
                    artist=song_artist,
                )
            )
    return results


# --- Downloading ---


def _extract_zip(archive: Path, prefix: Path, sim: Sim) -> bool:
    if not zf.is_zipfile(archive):
        archive.unlink()
        return False

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_path = Path(tmpdir)
        destination = prefix
        with zf.ZipFile(archive) as z:
            names = z.namelist()
            if not any(sim.title + "/" in name for name in names):
                destination = prefix / sim.title
                tmp_path = tmp_path / sim.title
            z.extractall(path=tmp_path)
        archive.unlink()
        shutil.copytree(tmp_path, destination, dirs_exist_ok=True)
        logger.info(f"Downloaded {sim.title} -> {destination}")
        return True


def _download_custom(simfile: Simfile, prefix: Path) -> bool:
    archive = prefix / f"{simfile.title}.zip"
    try:
        with requests.get(simfile.zipfile_custom, stream=True) as r:
            with open(archive, "wb") as f:
                shutil.copyfileobj(r.raw, f)
    except Exception:
        logger.error(f"No custom zipfile available for {simfile.site}")
        return False
    return _extract_zip(archive, prefix, simfile)


def _download_category_songs(category: Category) -> None:
    """Fall back to downloading individual songs from a category page."""
    html = requests.get(category.site).text
    songs = re.findall(r'viewsimfile\.php\?simfileid=(\d+).*?title="(.*?)\s\/', html)
    simfiles = [Simfile(idx, title) for idx, title in songs]
    with ThreadPoolExecutor(max_workers=8) as pool:
        pool.map(
            download_sim,
            simfiles,
            repeat(False),
            repeat(category.title),
        )


def download_sim(
    sim: Sim,
    dump: bool = False,
    pack: str = "",
    add_title: str = "",
) -> None:
    """Download a Simfile or Category pack."""
    if add_title:
        sim.suffix = add_title
    songs_dir = config.songs_path

    if pack:
        prefix = songs_dir / pack
    elif dump:
        prefix = songs_dir / "dump"
    else:
        prefix = songs_dir
    prefix.mkdir(parents=True, exist_ok=True)

    # Try custom download for individual simfiles first
    if isinstance(sim, Simfile) and _download_custom(sim, prefix):
        return

    archive = prefix / f"{sim.title}.zip"
    with requests.get(sim.zipfile, stream=True) as r:
        with open(archive, "wb") as f:
            shutil.copyfileobj(r.raw, f)

    if _extract_zip(archive, prefix, sim):
        return

    # Category zip failed — download songs individually
    if isinstance(sim, Category):
        logger.info(f"Pack zip unavailable for {sim.title}, downloading songs individually")
        _download_category_songs(sim)


def download_group(group: Group) -> None:
    """Download all packs in a group (ARCADE/SPINOFF/OFFICIAL)."""
    for cat_info in fetch_categories(group):
        category = Category(cat_info["id"], cat_info["title"])
        download_sim(category)


def download_category(category_id: str) -> None:
    """Download a single category by ID."""
    category = Category(category_id)
    download_sim(category)


def download_song(result: SearchResult) -> None:
    """Download a single song from search results."""
    sim = result.song
    sim.suffix = f" [{result.pack_name}]"
    download_sim(sim, dump=True)
