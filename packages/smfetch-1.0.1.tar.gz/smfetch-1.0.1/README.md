# smfetch

Web interface for downloading simfiles from [Zenius-i-Vanisher](https://zenius-i-vanisher.com) and [StepManiaOnline](https://stepmaniaonline.net).

## Usage

```bash
usage: smfetch [-h] [-p PORT]

smfetch web interface

options:
  -h, --help       show this help message and exit
  -p, --port PORT  port for the web interface (default: 8095)
```

Starts a web interface at `http://localhost:<port>`.

## Features

### Zenius-i-Vanisher
- **Song search** — search by song name and/or artist, select and download individual charts
- **Pack search** — filter official or user packs, download selected packs
- **Download bundles** — one-click download of arcade, spinoff, or all official packs

### StepManiaOnline
- **Title search** — search packs that contain chart with song title
- **Artist search** — search packs that contain chart with song artist
- **Pack search** — filter packs by pack name

## Storage Defaults

| | Config | Songs | Logs |
|---|---|---|---|
| **Linux** | `~/.config/smfetch/` | `~/.local/share/smfetch/` | `~/.local/state/smfetch/logs/` |
| **macOS** | `~/Library/Application Support/smfetch/` | `~/Music/StepMania Songs/` | `~/Library/Logs/smfetch/` |
| **Windows** | `%APPDATA%/smfetch/` | `~/Music/StepMania Songs/` | `%LOCALAPPDATA%/smfetch/logs/` |
