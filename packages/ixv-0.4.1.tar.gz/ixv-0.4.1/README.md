# IXV - 日本語文書を活かす開発支援AI

[![PyPI version](https://badge.fury.io/py/ixv.svg)](https://pypi.org/project/ixv/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

IXV は、日本のソフトウェア開発現場向けに特化した開発支援AIです。ローカルLLMを OpenAI API 互換で提供する FastAPI サーバーを含みます。

## インストール

```bash
pip install ixv
```

## クイックスタート

```bash
# サーバーを起動
ixv serve

# ポートを指定して起動
ixv serve --port 9000

# バージョンを確認
ixv version
```

サーバー起動後、`http://localhost:8000/docs` で Swagger UI にアクセスできます。

## 主な機能

- **OpenAI API 互換**: `/v1/chat/completions`, `/v1/models` エンドポイント
- **ローカルLLM推論**: llama.cpp ベースの高速推論（Metal/CUDA対応）
- **スキルシステム**: ファイル操作、コード実行、Git操作、RAG、Web検索
- **設計書-コード突合**: Excel設計書とJavaコードの整合性をAIでレビュー

## 設定

環境変数で設定をカスタマイズできます:

| 環境変数 | デフォルト | 説明 |
|----------|-----------|------|
| `IXV_HOST` | `0.0.0.0` | サーバーのホスト |
| `IXV_PORT` | `8000` | サーバーのポート |
| `IXV_MODEL_PATH` | - | GGUFモデルのパス |
| `IXV_CONTEXT_SIZE` | `2048` | コンテキストウィンドウサイズ |
| `IXV_GPU_LAYERS` | `0` | GPUにオフロードするレイヤー数 |

## パッケージ構成

`ixv` は以下のサブパッケージで構成されています:

- **[ixv-core](https://pypi.org/project/ixv-core/)**: ローカルLLMサーバーのコア実装

## リンク

- [ホームページ](https://ixv.jp)
- [GitHub](https://github.com/elvezjp/ixv)
- [Issues](https://github.com/elvezjp/ixv/issues)

## ライセンス

MIT License
