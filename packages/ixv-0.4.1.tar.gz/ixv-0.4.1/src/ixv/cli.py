"""IXV CLI - ローカルLLMサーバーの起動コマンド"""

import sys
import argparse


def main():
    """ixv コマンドのエントリポイント"""
    parser = argparse.ArgumentParser(
        description="IXV - 日本語文書を活かす開発支援AI",
    )
    subparsers = parser.add_subparsers(dest="command")

    # serve
    serve_parser = subparsers.add_parser("serve", help="サーバーを起動")
    serve_parser.add_argument("--host", default=None, help="バインドするホスト")
    serve_parser.add_argument("--port", type=int, default=None, help="バインドするポート")
    serve_parser.add_argument("--reload", action="store_true", help="自動リロードを有効化")

    # version
    subparsers.add_parser("version", help="バージョンを表示")

    args = parser.parse_args()

    if args.command == "version":
        _show_version()
    elif args.command == "serve" or args.command is None:
        _serve(args)
    else:
        parser.print_help()
        sys.exit(1)


def _show_version():
    from app import __version__
    print(f"ixv {__version__}")


def _serve(args):
    import uvicorn
    from app.config import config

    host = getattr(args, "host", None) or config.host
    port = getattr(args, "port", None) or config.port
    reload = getattr(args, "reload", False)

    uvicorn.run(
        "app.main:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )
