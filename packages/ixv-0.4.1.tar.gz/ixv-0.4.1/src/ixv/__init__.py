"""IXV - 日本語文書を活かす開発支援AI

ラッパーパッケージ。コア実装は ixv-core パッケージ（app モジュール）にあります。
"""

from app import __version__
from app.main import create_app, app

__all__ = ["__version__", "create_app", "app"]
