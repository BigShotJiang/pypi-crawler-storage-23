from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..nested import parse_model_elements
from ..parser import parse_model_element
from ..registry import default_registry


@default_registry.register
@dataclass
class Contact(ModelBase):
    """Override for generated Contact with C#-parity nested parsing.

    Keeps the generated scalar field mapping behavior (via a local mapping),
    and additionally wires nested multiModelFields:
    - AdditionalInfo: list of KeyValueModel -> dict
    - Addresses: list of StreetAddress
    - Entries: list of ContactEntry (special-case UFED subtypes)
    - Photos: list of ContactPhoto
    - Organizations: list of Organization
    """

    Account: Optional[str] = None
    Group: Optional[str] = None
    Id: Optional[str] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    TimeContacted: Optional[str] = None
    TimesContacted: int = 0
    TimeCreated: Optional[str] = None
    TimeModified: Optional[str] = None
    UserMapping: Optional[str] = None
    Type: Optional[str] = None

    InteractionStatuses: List[str] = field(default_factory=list)
    Notes: List[str] = field(default_factory=list)
    UserTags: List[str] = field(default_factory=list)

    AdditionalInfo: Dict[str, str] = field(default_factory=dict)
    Addresses: List[Any] = field(default_factory=list)
    Entries: List[Any] = field(default_factory=list)
    Organizations: List[Any] = field(default_factory=list)
    Photos: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Contact"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Contact":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )

        # Scalar fields (best-effort, keep as strings except TimesContacted)
        for fname, fval in (fields or {}).items():
            if fname == "Account":
                obj.Account = fval
            elif fname == "Group":
                obj.Group = fval
            elif fname == "Id":
                obj.Id = fval
            elif fname == "Name":
                obj.Name = fval
            elif fname == "ServiceIdentifier":
                obj.ServiceIdentifier = fval
            elif fname == "Source":
                obj.Source = fval
            elif fname == "TimeContacted":
                obj.TimeContacted = fval
            elif fname == "TimesContacted":
                try:
                    obj.TimesContacted = int(fval)
                except Exception:
                    obj.TimesContacted = 0
            elif fname == "TimeCreated":
                obj.TimeCreated = fval
            elif fname == "TimeModified":
                obj.TimeModified = fval
            elif fname == "Type":
                obj.Type = fval
            elif fname == "UserMapping":
                obj.UserMapping = fval
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Contact Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval

        # multiFields
        for mname, values in (multi_fields or {}).items():
            if mname == "InteractionStatuses":
                obj.InteractionStatuses = list(values)
            elif mname == "Notes":
                obj.Notes = list(values)
            elif mname == "UserTags":
                obj.UserTags = list(values)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Contact Parser: Unknown multiField: " + str(mname)
                    )
                obj._unknown_multi_fields[mname] = list(values)

        # multiModelFields
        mmf = multi_model_fields or {}

        # AdditionalInfo -> KeyValueModel list -> dict
        if "AdditionalInfo" in mmf:
            kvs = parse_model_elements(
                mmf.get("AdditionalInfo") or [], debug_attributes=debug_attributes
            )
            for kv in kvs:
                k = getattr(kv, "Key", None) or getattr(kv, "key", None)
                v = getattr(kv, "Value", None) or getattr(kv, "value", None)
                if k and v:
                    obj.AdditionalInfo[str(k)] = str(v)

        if "Addresses" in mmf:
            obj.Addresses = parse_model_elements(
                mmf.get("Addresses") or [], debug_attributes=debug_attributes
            )

        # Entries special-case (C# filters nested model types)
        if "Entries" in mmf:
            entries: List[Any] = []
            for el in mmf.get("Entries") or []:
                t = el.get("type")
                if t in {
                    "UserID",
                    "PhoneNumber",
                    "EMailAddress",
                    "WebAddress",
                    "ContactEntry",
                }:
                    parsed = parse_model_element(el, debug_attributes=debug_attributes)
                    if parsed is not None:
                        entries.append(parsed)
            obj.Entries = entries

        if "Photos" in mmf:
            obj.Photos = parse_model_elements(
                mmf.get("Photos") or [], debug_attributes=debug_attributes
            )

        if "Organizations" in mmf:
            obj.Organizations = parse_model_elements(
                mmf.get("Organizations") or [], debug_attributes=debug_attributes
            )

        # Keep the raw/unhandled buckets for debugging parity
        obj._unknown_model_fields.update(model_fields or {})
        for k, v in mmf.items():
            if k not in {
                "AdditionalInfo",
                "Addresses",
                "Entries",
                "Photos",
                "Organizations",
            }:
                obj._unknown_multi_model_fields[k] = list(v)

        return obj
