from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..nested import parse_model_elements
from ..registry import default_registry


@default_registry.register
@dataclass
class Chat(ModelBase):
    Account: Optional[str] = None
    ChatType: Optional[str] = None
    Description: Optional[str] = None
    Id: Optional[str] = None
    LastActivity: Optional[str] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[str] = None
    UserMapping: Optional[str] = None

    Messages: List[Any] = field(default_factory=list)
    Participants: List[Any] = field(default_factory=list)
    Photos: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Chat"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Chat":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )

        for fname, fval in (fields or {}).items():
            if fname == "Account":
                obj.Account = fval
            elif fname == "ChatType":
                obj.ChatType = fval
            elif fname == "Description":
                obj.Description = fval
            elif fname == "Id":
                obj.Id = fval
            elif fname == "LastActivity":
                obj.LastActivity = fval
            elif fname == "Name":
                obj.Name = fval
            elif fname == "ServiceIdentifier":
                obj.ServiceIdentifier = fval
            elif fname == "Source":
                obj.Source = fval
            elif fname == "StartTime":
                obj.StartTime = fval
            elif fname == "UserMapping":
                obj.UserMapping = fval
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Chat Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval

        mmf = multi_model_fields or {}
        if "Messages" in mmf:
            obj.Messages = parse_model_elements(
                mmf.get("Messages") or [], debug_attributes=debug_attributes
            )
        if "Participants" in mmf:
            obj.Participants = parse_model_elements(
                mmf.get("Participants") or [], debug_attributes=debug_attributes
            )
        if "Photos" in mmf:
            obj.Photos = parse_model_elements(
                mmf.get("Photos") or [], debug_attributes=debug_attributes
            )

        obj._unknown_model_fields.update(model_fields or {})
        obj._unknown_multi_fields.update(multi_fields or {})
        for k, v in mmf.items():
            if k not in {"Messages", "Participants", "Photos"}:
                obj._unknown_multi_model_fields[k] = list(v)

        return obj
