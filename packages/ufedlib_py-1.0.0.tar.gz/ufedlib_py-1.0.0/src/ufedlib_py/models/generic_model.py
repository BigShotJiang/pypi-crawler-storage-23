from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..registry import default_registry


@dataclass
class GenericModel(ModelBase):
    """Fallback model used when no specific model class is registered.

    Stores all fields and nested content in generic structures.
    """

    model_type: Optional[str] = None

    fields: Dict[str, str] = field(default_factory=dict)
    model_fields: Dict[str, Any] = field(default_factory=dict)
    multi_fields: Dict[str, List[str]] = field(default_factory=dict)
    multi_model_fields: Dict[str, List[Any]] = field(default_factory=dict)

    @classmethod
    def get_xml_model_type(cls) -> str:
        # Not intended to be used for explicit matching
        return "__generic__"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "GenericModel":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
            model_type=attrs.get("type"),
        )

        obj.fields = dict(fields)
        obj.model_fields = dict(model_fields)
        obj.multi_fields = {k: list(v) for k, v in multi_fields.items()}
        obj.multi_model_fields = {k: list(v) for k, v in multi_model_fields.items()}

        if debug_attributes:
            # This model is generic; no unknowns.
            default_logger.attribute(f"GenericModel: parsed type={obj.model_type}")

        return obj


# Set as the registry fallback.
# Specific models (e.g., Contact) can still be registered and will override for that type.
default_registry.set_default(GenericModel)
