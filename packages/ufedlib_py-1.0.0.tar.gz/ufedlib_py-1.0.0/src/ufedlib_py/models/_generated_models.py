from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..registry import default_registry


def _to_int(v: str) -> int:
    try:
        return int(v)
    except Exception:
        return 0


def _to_float(v: str) -> float:
    try:
        return float((v or "").replace(",", "."))
    except Exception:
        return 0.0


def _to_bool(v: str) -> bool:
    vv = (v or "").strip().lower()
    return vv in ("1", "true", "yes", "y")


def _to_datetime(v: str) -> Optional[datetime]:
    v = (v or "").strip()
    if not v:
        return None
    # UFED timestamps are often ISO 8601; try fromisoformat first
    try:
        return datetime.fromisoformat(v.replace("Z", "+00:00"))
    except Exception:
        return None


@default_registry.register
@dataclass
class ActivitySensorData(ModelBase):
    CreationTime: Optional[datetime] = None
    DeviceName: Optional[str] = None
    DistanceTraveled: float = 0.0
    FlightsClimbed: float = 0.0
    From: Optional[datetime] = None
    Name: Optional[str] = None
    MaxHeartrate: float = 0.0
    MaxSpeed: float = 0.0
    UserMapping: Optional[str] = None
    Source: Optional[str] = None
    SourceDeviceType: Optional[str] = None
    To: Optional[datetime] = None
    TotalSampleCount: int = 0
    Measurements: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ActivitySensorData"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ActivitySensorData":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "CreationTime":
                setattr(obj, "CreationTime", _to_datetime(fval))
            elif fname == "DeviceName":
                setattr(obj, "DeviceName", fval)
            elif fname == "DistanceTraveled":
                setattr(obj, "DistanceTraveled", _to_float(fval))
            elif fname == "FlightsClimbed":
                setattr(obj, "FlightsClimbed", _to_float(fval))
            elif fname == "From":
                setattr(obj, "From", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "MaxHeartrate":
                setattr(obj, "MaxHeartrate", _to_float(fval))
            elif fname == "MaxSpeed":
                setattr(obj, "MaxSpeed", _to_float(fval))
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "SourceDeviceType":
                setattr(obj, "SourceDeviceType", fval)
            elif fname == "To":
                setattr(obj, "To", _to_datetime(fval))
            elif fname == "TotalSampleCount":
                setattr(obj, "TotalSampleCount", _to_int(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Measurements":
                setattr(obj, "Measurements", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ActivitySensorData Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ActivitySensorDataMeasurement(ModelBase):
    AverageValue: float = 0.0
    DeviceName: Optional[str] = None
    MaximumValue: float = 0.0
    MeasuredVariableType: Optional[str] = None
    Source: Optional[str] = None
    TotalValue: float = 0.0
    Unit: Optional[str] = None
    UserMapping: Optional[str] = None
    Samples: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ActivitySensorDataMeasurement"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ActivitySensorDataMeasurement":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "AverageValue":
                setattr(obj, "AverageValue", _to_float(fval))
            elif fname == "DeviceName":
                setattr(obj, "DeviceName", fval)
            elif fname == "MaximumValue":
                setattr(obj, "MaximumValue", _to_float(fval))
            elif fname == "MeasuredVariableType":
                setattr(obj, "MeasuredVariableType", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TotalValue":
                setattr(obj, "TotalValue", _to_float(fval))
            elif fname == "Unit":
                setattr(obj, "Unit", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Samples":
                setattr(obj, "Samples", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ActivitySensorDataMeasurement Parser: Unknown field: "
                        + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ActivitySensorDataSample(ModelBase):
    DateSampled: Optional[datetime] = None
    DateEnded: Optional[datetime] = None
    Quantity: float = 0.0
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ActivitySensorDataSample"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ActivitySensorDataSample":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "DateSampled":
                setattr(obj, "DateSampled", fval)
            elif fname == "DateEnded":
                setattr(obj, "DateEnded", fval)
            elif fname == "Quantity":
                setattr(obj, "Quantity", _to_float(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ActivitySensorDataSample Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ApplicationUsage(ModelBase):
    ActivationCount: int = 0
    ActiveTime: Optional[str] = None
    BackgroundTime: Optional[str] = None
    Date: Optional[datetime] = None
    EndTime: Optional[datetime] = None
    Identifier: Optional[str] = None
    LastLaunch: Optional[datetime] = None
    LastUsageDuration: Optional[str] = None
    LaunchCount: int = 0
    Name: Optional[str] = None
    StartTime: Optional[datetime] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ApplicationUsage"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ApplicationUsage":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "ActivationCount":
                setattr(obj, "ActivationCount", _to_int(fval))
            elif fname == "ActiveTime":
                setattr(obj, "ActiveTime", fval)
            elif fname == "BackgroundTime":
                setattr(obj, "BackgroundTime", fval)
            elif fname == "Date":
                setattr(obj, "Date", _to_datetime(fval))
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "LastLaunch":
                setattr(obj, "LastLaunch", _to_datetime(fval))
            elif fname == "LastUsageDuration":
                setattr(obj, "LastUsageDuration", fval)
            elif fname == "LaunchCount":
                setattr(obj, "LaunchCount", _to_int(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ApplicationUsage Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class AppsUsageLog(ModelBase):
    Action: Optional[str] = None
    ArtifactFamily: Optional[str] = None
    EndTime: Optional[datetime] = None
    Identifier: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    StartTime: Optional[datetime] = None
    Source: Optional[str] = None
    SubModule: Optional[str] = None
    UserMapping: Optional[str] = None
    AdditionalInfo: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "AppsUsageLog"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "AppsUsageLog":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Action":
                setattr(obj, "Action", fval)
            elif fname == "ArtifactFamily":
                setattr(obj, "ArtifactFamily", fval)
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "SubModule":
                setattr(obj, "SubModule", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "AdditionalInfo":
                setattr(obj, "AdditionalInfo", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "AppsUsageLog Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Attachment(ModelBase):
    AttachmentExtractedPath: Optional[str] = None
    Charset: Optional[str] = None
    ContentType: Optional[str] = None
    Filename: Optional[str] = None
    Source: Optional[str] = None
    Title: Optional[str] = None
    URL: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Attachment"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Attachment":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "attachment_extracted_path":
                setattr(obj, "AttachmentExtractedPath", fval)
            elif fname == "Charset":
                setattr(obj, "Charset", fval)
            elif fname == "ContentType":
                setattr(obj, "ContentType", fval)
            elif fname == "Filename":
                setattr(obj, "Filename", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "URL":
                setattr(obj, "URL", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Attachment Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Autofill(ModelBase):
    Account: Optional[str] = None
    Key: Optional[str] = None
    LastUsedDate: Optional[datetime] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Autofill"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Autofill":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Key":
                setattr(obj, "Key", fval)
            elif fname == "LastUsedDate":
                setattr(obj, "LastUsedDate", _to_datetime(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Autofill Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class CalendarEntry(ModelBase):
    Account: Optional[str] = None
    Availability: Optional[str] = None
    Category: Optional[str] = None
    Class: Optional[str] = None
    Details: Optional[str] = None
    EndDate: Optional[datetime] = None
    Location: Optional[str] = None
    Priority: Optional[str] = None
    Reminder: Optional[datetime] = None
    RepeatDay: Optional[str] = None
    RepeatInterval: int = 0
    RepeatRule: Optional[str] = None
    RepeatUntil: Optional[datetime] = None
    StartDate: Optional[datetime] = None
    Status: Optional[str] = None
    Source: Optional[str] = None
    Subject: Optional[str] = None
    UserMapping: Optional[str] = None
    Attachments: List[Any] = field(default_factory=list)
    Attendees: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "CalendarEntry"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "CalendarEntry":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Availability":
                setattr(obj, "Availability", fval)
            elif fname == "Category":
                setattr(obj, "Category", fval)
            elif fname == "Class":
                setattr(obj, "Class", fval)
            elif fname == "Details":
                setattr(obj, "Details", fval)
            elif fname == "EndDate":
                setattr(obj, "EndDate", _to_datetime(fval))
            elif fname == "Location":
                setattr(obj, "Location", fval)
            elif fname == "Priority":
                setattr(obj, "Priority", fval)
            elif fname == "Reminder":
                setattr(obj, "Reminder", _to_datetime(fval))
            elif fname == "RepeatDay":
                setattr(obj, "RepeatDay", fval)
            elif fname == "RepeatInterval":
                setattr(obj, "RepeatInterval", _to_int(fval))
            elif fname == "RepeatRule":
                setattr(obj, "RepeatRule", fval)
            elif fname == "RepeatUntil":
                setattr(obj, "RepeatUntil", _to_datetime(fval))
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartDate":
                setattr(obj, "StartDate", _to_datetime(fval))
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "Subject":
                setattr(obj, "Subject", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "Attendees":
                setattr(obj, "Attendees", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "CalendarEntry Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Call(ModelBase):
    Account: Optional[str] = None
    CountryCode: Optional[str] = None
    Direction: Optional[str] = None
    DisconnectionCause: Optional[str] = None
    Duration: Optional[str] = None
    NetworkCode: Optional[str] = None
    NetworkName: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    VideoCall: Optional[str] = None
    Parties: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Call"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Call":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "CountryCode":
                setattr(obj, "CountryCode", fval)
            elif fname == "DisconnectionCause":
                setattr(obj, "DisconnectionCause", fval)
            elif fname == "Direction":
                setattr(obj, "Direction", fval)
            elif fname == "Duration":
                setattr(obj, "Duration", fval)
            elif fname == "NetworkCode":
                setattr(obj, "NetworkCode", fval)
            elif fname == "NetworkName":
                setattr(obj, "NetworkName", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "VideoCall":
                setattr(obj, "VideoCall", fval)
            elif fname == "Parties":
                setattr(obj, "Parties", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Call Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class CellTower(ModelBase):
    BID: Optional[str] = None
    CID: Optional[str] = None
    LAC: Optional[str] = None
    MCC: Optional[str] = None
    MNC: Optional[str] = None
    NID: Optional[str] = None
    Package: Optional[str] = None
    SID: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    Position: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "CellTower"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "CellTower":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "BID":
                setattr(obj, "BID", fval)
            elif fname == "CID":
                setattr(obj, "CID", fval)
            elif fname == "LAC":
                setattr(obj, "LAC", fval)
            elif fname == "MCC":
                setattr(obj, "MCC", fval)
            elif fname == "MNC":
                setattr(obj, "MNC", fval)
            elif fname == "NID":
                setattr(obj, "NID", fval)
            elif fname == "Package":
                setattr(obj, "Package", fval)
            elif fname == "SID":
                setattr(obj, "SID", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "CellTower Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Chat(ModelBase):
    Account: Optional[str] = None
    ChatType: Optional[str] = None
    Description: Optional[str] = None
    id: Optional[str] = None
    LastActivity: Optional[datetime] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Messages: List[Any] = field(default_factory=list)
    Participants: List[Any] = field(default_factory=list)
    Photos: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Chat"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Chat":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "ChatType":
                setattr(obj, "ChatType", fval)
            elif fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "Id":
                setattr(obj, "Id", fval)
            elif fname == "LastActivity":
                setattr(obj, "LastActivity", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "ActivityLog":
                setattr(obj, "ActivityLog", fval)
            elif fname == "Messages":
                setattr(obj, "Messages", fval)
            elif fname == "Participants":
                setattr(obj, "Participants", fval)
            elif fname == "Photos":
                setattr(obj, "Photos", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Chat Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ChatActivity(ModelBase):
    Action: Optional[str] = None
    Source: Optional[str] = None
    SystemMessageBody: Optional[str] = None
    SystemMessageId: Optional[str] = None
    SystemMessageTimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Participant: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ChatActivity"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ChatActivity":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Action":
                setattr(obj, "Action", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "SystemMessageBody":
                setattr(obj, "SystemMessageBody", fval)
            elif fname == "SystemMessageId":
                setattr(obj, "SystemMessageId", fval)
            elif fname == "SystemMessageTimeStamp":
                setattr(obj, "SystemMessageTimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Participant":
                setattr(obj, "Participant", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ChatActivity Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Contact(ModelBase):
    Account: Optional[str] = None
    Group: Optional[str] = None
    id: Optional[str] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    TimeContacted: Optional[datetime] = None
    TimesContacted: int = 0
    TimeCreated: Optional[datetime] = None
    TimeModified: Optional[datetime] = None
    UserMapping: Optional[str] = None
    type: Optional[str] = None
    InteractionStatuses: List[Any] = field(default_factory=list)
    Notes: List[Any] = field(default_factory=list)
    UserTags: List[Any] = field(default_factory=list)
    Addresses: List[Any] = field(default_factory=list)
    Entries: List[Any] = field(default_factory=list)
    Organizations: List[Any] = field(default_factory=list)
    Photos: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Contact"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Contact":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Group":
                setattr(obj, "Group", fval)
            elif fname == "Id":
                setattr(obj, "Id", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeContacted":
                setattr(obj, "TimeContacted", _to_datetime(fval))
            elif fname == "TimesContacted":
                setattr(obj, "TimesContacted", _to_int(fval))
            elif fname == "TimeCreated":
                setattr(obj, "TimeCreated", _to_datetime(fval))
            elif fname == "TimeModified":
                setattr(obj, "TimeModified", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "InteractionStatuses":
                setattr(obj, "InteractionStatuses", fval)
            elif fname == "Notes":
                setattr(obj, "Notes", fval)
            elif fname == "UserTags":
                setattr(obj, "UserTags", fval)
            elif fname == "Addresses":
                setattr(obj, "Addresses", fval)
            elif fname == "Entries":
                setattr(obj, "Entries", fval)
            elif fname == "Photos":
                setattr(obj, "Photos", fval)
            elif fname == "Organizations":
                setattr(obj, "Organizations", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Contact Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ContactEntry(ModelBase):
    Category: Optional[str] = None
    Domain: Optional[str] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ContactEntry"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ContactEntry":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Category":
                setattr(obj, "Category", fval)
            elif fname == "Domain":
                setattr(obj, "Domain", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ContactEntry Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class ContactPhoto(ModelBase):
    Name: Optional[str] = None
    Url: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "ContactPhoto"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "ContactPhoto":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "ContactPhoto Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Cookie(ModelBase):
    CreationTime: Optional[datetime] = None
    Domain: Optional[str] = None
    Expiry: Optional[datetime] = None
    LastAccessTime: Optional[datetime] = None
    Name: Optional[str] = None
    Path: Optional[str] = None
    RelatedApplication: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Cookie"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Cookie":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "CreationTime":
                setattr(obj, "CreationTime", fval)
            elif fname == "Domain":
                setattr(obj, "Domain", fval)
            elif fname == "Expiry":
                setattr(obj, "Expiry", fval)
            elif fname == "LastAccessTime":
                setattr(obj, "LastAccessTime", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Path":
                setattr(obj, "Path", fval)
            elif fname == "RelatedApplication":
                setattr(obj, "RelatedApplication", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Cookie Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Coordinate(ModelBase):
    Comment: Optional[str] = None
    Elevation: float = 0.0
    Latitude: float = 0.0
    Longitude: float = 0.0
    Map: Optional[str] = None
    PositionAddress: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Coordinate"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Coordinate":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Comment":
                setattr(obj, "Comment", fval)
            elif fname == "Elevation":
                setattr(obj, "Elevation", _to_float(fval))
            elif fname == "Longitude":
                setattr(obj, "Longitude", _to_float(fval))
            elif fname == "Latitude":
                setattr(obj, "Latitude", _to_float(fval))
            elif fname == "Map":
                setattr(obj, "Map", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Coordinate Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class CreditCard(ModelBase):
    Company: Optional[str] = None
    CreditCardNumber: Optional[str] = None
    CVV: Optional[str] = None
    DateLastUsed: Optional[datetime] = None
    ExpirationDate: Optional[datetime] = None
    NameOnCard: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    BillingAddress: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "CreditCard"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "CreditCard":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Company":
                setattr(obj, "Company", fval)
            elif fname == "CreditCardNumber":
                setattr(obj, "CreditCardNumber", fval)
            elif fname == "CVV":
                setattr(obj, "CVV", fval)
            elif fname == "DateLastUsed":
                setattr(obj, "DateLastUsed", _to_datetime(fval))
            elif fname == "ExpirationDate":
                setattr(obj, "ExpirationDate", _to_datetime(fval))
            elif fname == "NameOnCard":
                setattr(obj, "NameOnCard", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "BillingAddress":
                setattr(obj, "BillingAddress", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "CreditCard Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class DeviceConnectivity(ModelBase):
    ConnectivityMethod: Optional[str] = None
    ConnectivityNature: Optional[str] = None
    DeviceName: Optional[str] = None
    DeviceType: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[datetime] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "DeviceConnectivity"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "DeviceConnectivity":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "ConnectivityMethod":
                setattr(obj, "ConnectivityMethod", fval)
            elif fname == "ConnectivityNature":
                setattr(obj, "ConnectivityNature", fval)
            elif fname == "DeviceName":
                setattr(obj, "DeviceName", fval)
            elif fname == "DeviceType":
                setattr(obj, "DeviceType", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "DeviceConnectivity Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class DeviceEvent(ModelBase):
    EndTime: Optional[datetime] = None
    EventType: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "DeviceEvent"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "DeviceEvent":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "EventType":
                setattr(obj, "EventType", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "DeviceEvent Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class DeviceInfoEntry(ModelBase):
    EntryCategory: Optional[str] = None
    EntryName: Optional[str] = None
    EntryValue: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "DeviceInfoEntry"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "DeviceInfoEntry":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "EntryCategory":
                setattr(obj, "EntryCategory", fval)
            elif fname == "EntryName":
                setattr(obj, "EntryName", fval)
            elif fname == "EntryValue":
                setattr(obj, "EntryValue", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "DeviceInfoEntry Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class DictionaryWord(ModelBase):
    Frequency: int = 0
    Locale: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    UsagePattern: Optional[str] = None
    Word: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "DictionaryWord"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "DictionaryWord":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Frequency":
                setattr(obj, "Frequency", _to_int(fval))
            elif fname == "Locale":
                setattr(obj, "Locale", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UsagePattern":
                setattr(obj, "UsagePattern", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Word":
                setattr(obj, "Word", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "DictionaryWord Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Email(ModelBase):
    Account: Optional[str] = None
    Body: Optional[str] = None
    EmailHeader: Optional[str] = None
    Folder: Optional[str] = None
    Priority: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Snippet: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    Subject: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None
    From: Optional[str] = None
    Labels: List[Any] = field(default_factory=list)
    Attachments: List[Any] = field(default_factory=list)
    Bcc: List[Any] = field(default_factory=list)
    Cc: List[Any] = field(default_factory=list)
    To: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Email"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Email":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "EmailHeader":
                setattr(obj, "EmailHeader", fval)
            elif fname == "Folder":
                setattr(obj, "Folder", fval)
            elif fname == "Priority":
                setattr(obj, "Priority", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Snippet":
                setattr(obj, "Snippet", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "Subject":
                setattr(obj, "Subject", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "From":
                setattr(obj, "From", fval)
            elif fname == "Labels":
                setattr(obj, "Labels", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "Bcc":
                setattr(obj, "Bcc", fval)
            elif fname == "Cc":
                setattr(obj, "Cc", fval)
            elif fname == "To":
                setattr(obj, "To", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Email Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class FileDownload(ModelBase):
    BytesReceived: Optional[str] = None
    DownloadState: Optional[str] = None
    EndTime: Optional[datetime] = None
    FileSize: Optional[str] = None
    LastAccessed: Optional[datetime] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[datetime] = None
    TargetPath: Optional[str] = None
    Url: Optional[str] = None
    UserMapping: Optional[str] = None
    DownloadURLChains: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "FileDownload"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "FileDownload":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "BytesReceived":
                setattr(obj, "BytesReceived", fval)
            elif fname == "DownloadState":
                setattr(obj, "DownloadState", fval)
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "FileSize":
                setattr(obj, "FileSize", fval)
            elif fname == "LastAccessed":
                setattr(obj, "LastAccessed", _to_datetime(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "TargetPath":
                setattr(obj, "TargetPath", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "DownloadURLChains":
                setattr(obj, "DownloadURLChains", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "FileDownload Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class FileUpload(ModelBase):
    Account: Optional[str] = None
    DateUploaded: Optional[datetime] = None
    DateLastModified: Optional[datetime] = None
    FileType: Optional[str] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Title: Optional[str] = None
    Url: Optional[str] = None
    UserMapping: Optional[str] = None
    Owner: Optional[str] = None
    Participants: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "FileUpload"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "FileUpload":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "DateUploaded":
                setattr(obj, "DateUploaded", _to_datetime(fval))
            elif fname == "DateLastModified":
                setattr(obj, "DateLastModified", _to_datetime(fval))
            elif fname == "FileType":
                setattr(obj, "FileType", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Owner":
                setattr(obj, "Owner", fval)
            elif fname == "Participants":
                setattr(obj, "Participants", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "FileUpload Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class FinancialAccount(ModelBase):
    AccountID: Optional[str] = None
    DateLastUpdated: Optional[datetime] = None
    FinancialAccountType: Optional[str] = None
    FoundInField: Optional[str] = None
    FoundInModelId: Optional[str] = None
    FoundInModelType: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    Assets: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "FinancialAccount"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "FinancialAccount":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "AccountID":
                setattr(obj, "AccountID", fval)
            elif fname == "DateLastUpdated":
                setattr(obj, "DateLastUpdated", _to_datetime(fval))
            elif fname == "FinancialAccountType":
                setattr(obj, "FinancialAccountType", fval)
            elif fname == "FoundInField":
                setattr(obj, "FoundInField", fval)
            elif fname == "FoundInModelId":
                setattr(obj, "FoundInModelId", fval)
            elif fname == "FoundInModelType":
                setattr(obj, "FoundInModelType", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Assets":
                setattr(obj, "Assets", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "FinancialAccount Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class FinancialAsset(ModelBase):
    Currency: Optional[str] = None
    DateLastUpdated: Optional[datetime] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "FinancialAsset"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "FinancialAsset":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Currency":
                setattr(obj, "Currency", fval)
            elif fname == "DateLastUpdated":
                setattr(obj, "DateLastUpdated", _to_datetime(fval))
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "FinancialAsset Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class InstalledApplication(ModelBase):
    AppGUID: Optional[str] = None
    ArtifactFamily: Optional[str] = None
    Copyright: Optional[str] = None
    DecodingStatus: Optional[str] = None
    DeletedDate: Optional[datetime] = None
    Description: Optional[str] = None
    Identifier: Optional[str] = None
    InstallDate: Optional[datetime] = None
    IsEmulatable: Optional[str] = None
    LastLaunched: Optional[datetime] = None
    Name: Optional[str] = None
    OperationMode: Optional[str] = None
    PurchaseDate: Optional[datetime] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    Version: Optional[str] = None
    AssociatedDirectoryPaths: List[Any] = field(default_factory=list)
    Categories: List[Any] = field(default_factory=list)
    Permissions: List[Any] = field(default_factory=list)
    Users: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "InstalledApplication"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "InstalledApplication":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "AppGUID":
                setattr(obj, "AppGUID", fval)
            elif fname == "ArtifactFamily":
                setattr(obj, "ArtifactFamily", fval)
            elif fname == "Copyright":
                setattr(obj, "Copyright", fval)
            elif fname == "DecodingStatus":
                setattr(obj, "DecodingStatus", fval)
            elif fname == "DeletedDate":
                setattr(obj, "DeletedDate", _to_datetime(fval))
            elif fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "InstallDate":
                setattr(obj, "InstallDate", _to_datetime(fval))
            elif fname == "IsEmulatable":
                setattr(obj, "IsEmulatable", fval)
            elif fname == "LastLaunched":
                setattr(obj, "LastLaunched", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "OperationMode":
                setattr(obj, "OperationMode", fval)
            elif fname == "PurchaseDate":
                setattr(obj, "PurchaseDate", _to_datetime(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Version":
                setattr(obj, "Version", fval)
            elif fname == "AssociatedDirectoryPaths":
                setattr(obj, "AssociatedDirectoryPaths", fval)
            elif fname == "Categories":
                setattr(obj, "Categories", fval)
            elif fname == "Permissions":
                setattr(obj, "Permissions", fval)
            elif fname == "Users":
                setattr(obj, "Users", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "InstalledApplication Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class InstantMessage(ModelBase):
    Body: Optional[str] = None
    ChatId: Optional[str] = None
    DateDeleted: Optional[datetime] = None
    DateDelivered: Optional[datetime] = None
    DateRead: Optional[datetime] = None
    DeletionReason: Optional[str] = None
    Erased: Optional[str] = None
    Folder: Optional[str] = None
    FromIsOwner: Optional[str] = None
    id: Optional[str] = None
    Identifier: Optional[str] = None
    IsLocationSharing: Optional[str] = None
    JumpTargetId: Optional[str] = None
    Label: Optional[str] = None
    Platform: Optional[str] = None
    PositionAddress: Optional[str] = None
    Priority: Optional[str] = None
    SelfDestructDuration: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    SMSC: Optional[str] = None
    Source: Optional[str] = None
    SourceApplication: Optional[str] = None
    Status: Optional[str] = None
    Subject: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    Attachment: Optional[str] = None
    From: Optional[str] = None
    Position: Optional[str] = None
    Attachments: List[Any] = field(default_factory=list)
    ActivityLog: List[Any] = field(default_factory=list)
    SharedContacts: List[Any] = field(default_factory=list)
    To: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "InstantMessage"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "InstantMessage":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "ChatId":
                setattr(obj, "ChatId", fval)
            elif fname == "DateDeleted":
                setattr(obj, "DateDeleted", _to_datetime(fval))
            elif fname == "DateDelivered":
                setattr(obj, "DateDelivered", _to_datetime(fval))
            elif fname == "DateRead":
                setattr(obj, "DateRead", _to_datetime(fval))
            elif fname == "DeletionReason":
                setattr(obj, "DeletionReason", fval)
            elif fname == "Erased":
                setattr(obj, "Erased", fval)
            elif fname == "Folder":
                setattr(obj, "Folder", fval)
            elif fname == "FromIsOwner":
                setattr(obj, "FromIsOwner", fval)
            elif fname == "Id":
                setattr(obj, "Id", fval)
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "IsLocationSharing":
                setattr(obj, "IsLocationSharing", fval)
            elif fname == "Label":
                setattr(obj, "Label", fval)
            elif fname == "Platform":
                setattr(obj, "Platform", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "Priority":
                setattr(obj, "Priority", fval)
            elif fname == "SelfDestructDuration":
                setattr(obj, "SelfDestructDuration", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "SMSC":
                setattr(obj, "SMSC", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "SourceApplication":
                setattr(obj, "SourceApplication", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "Subject":
                setattr(obj, "Subject", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Attachment":
                setattr(obj, "Attachment", fval)
            elif fname == "From":
                setattr(obj, "From", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            elif fname == "JumpTargetId":
                setattr(obj, "JumpTargetId", fval)
            elif fname == "ActivityLog":
                setattr(obj, "ActivityLog", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "MessageExtraData":
                setattr(obj, "MessageExtraData", fval)
            elif fname == "SharedContacts":
                setattr(obj, "SharedContacts", fval)
            elif fname == "To":
                setattr(obj, "To", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "InstantMessage Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Journey(ModelBase):
    Account: Optional[str] = None
    EndTime: Optional[datetime] = None
    Name: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    StartTime: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    FromPoint: Optional[str] = None
    ToPoint: Optional[str] = None
    WayPoints: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Journey"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Journey":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "StartTime":
                setattr(obj, "StartTime", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "FromPoint":
                setattr(obj, "FromPoint", fval)
            elif fname == "ToPoint":
                setattr(obj, "ToPoint", fval)
            elif fname == "WayPoints":
                setattr(obj, "WayPoints", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Journey Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Location(ModelBase):
    Account: Optional[str] = None
    AccountLocationAffiliation: Optional[str] = None
    AggregatedLocationsCount: int = 0
    Category: Optional[str] = None
    Confidence: Optional[str] = None
    Description: Optional[str] = None
    DeviceLocationAffiliation: Optional[str] = None
    EndTime: Optional[datetime] = None
    GpsHorizontalAccuracy: float = 0.0
    LocationOrigin: Optional[str] = None
    Map: Optional[str] = None
    Name: Optional[str] = None
    Origin: Optional[str] = None
    PositionAddress: Optional[str] = None
    Precision: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    ServiceName: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    Address: Optional[str] = None
    Position: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Location"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Location":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "AccountLocationAffiliation":
                setattr(obj, "AccountLocationAffiliation", fval)
            elif fname == "AggregatedLocationsCount":
                setattr(obj, "AggregatedLocationsCount", _to_int(fval))
            elif fname == "Category":
                setattr(obj, "Category", fval)
            elif fname == "Confidence":
                setattr(obj, "Confidence", fval)
            elif fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "DeviceLocationAffiliation":
                setattr(obj, "DeviceLocationAffiliation", fval)
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "GpsHorizontalAccuracy":
                setattr(obj, "GpsHorizontalAccuracy", _to_float(fval))
            elif fname == "LocationOrigin":
                setattr(obj, "LocationOrigin", fval)
            elif fname == "Map":
                setattr(obj, "Map", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Origin":
                setattr(obj, "Origin", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "Precision":
                setattr(obj, "Precision", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "ServiceName":
                setattr(obj, "ServiceName", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Location Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class LogEntry(ModelBase):
    Application: Optional[str] = None
    Body: Optional[str] = None
    EffectiveUID: int = 0
    EndTime: Optional[datetime] = None
    Identifier: Optional[str] = None
    PID: int = 0
    Severity: Optional[str] = None
    Source: Optional[str] = None
    TID: int = 0
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "LogEntry"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "LogEntry":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Application":
                setattr(obj, "Application", fval)
            elif fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "EffectiveUID":
                setattr(obj, "EffectiveUID", _to_int(fval))
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "PID":
                setattr(obj, "PID", _to_int(fval))
            elif fname == "Severity":
                setattr(obj, "Severity", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TID":
                setattr(obj, "TID", _to_int(fval))
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "LogEntry Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class MobileCard(ModelBase):
    ActivationTime: Optional[datetime] = None
    Description: Optional[str] = None
    ExpirationTime: Optional[datetime] = None
    ModifyTime: Optional[datetime] = None
    Name: Optional[str] = None
    PurchaseTime: Optional[datetime] = None
    Source: Optional[str] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    Organization: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "MobileCard"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "MobileCard":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "ActivationTime":
                setattr(obj, "ActivationTime", _to_datetime(fval))
            elif fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "ExpirationTime":
                setattr(obj, "ExpirationTime", _to_datetime(fval))
            elif fname == "ModifyTime":
                setattr(obj, "ModifyTime", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "PurchaseTime":
                setattr(obj, "PurchaseTime", _to_datetime(fval))
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Organization":
                setattr(obj, "Organization", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "MobileCard Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class NetworkUsage(ModelBase):
    ArtifactFamily: Optional[str] = None
    DateEnded: Optional[datetime] = None
    DateStarted: Optional[datetime] = None
    IsRoaming: Optional[str] = None
    NetworkConnectionType: Optional[str] = None
    NumberOfBytesReceived: Optional[str] = None
    NumberOfBytesSent: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    SSId: Optional[str] = None
    UsageMode: Optional[str] = None
    UserMapping: Optional[str] = None
    ApplicationId: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "NetworkUsage"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "NetworkUsage":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "ArtifactFamily":
                setattr(obj, "ArtifactFamily", fval)
            elif fname == "DateEnded":
                setattr(obj, "DateEnded", _to_datetime(fval))
            elif fname == "DateStarted":
                setattr(obj, "DateStarted", _to_datetime(fval))
            elif fname == "IsRoaming":
                setattr(obj, "IsRoaming", fval)
            elif fname == "NetworkConnectionType":
                setattr(obj, "NetworkConnectionType", fval)
            elif fname == "NumberOfBytesReceived":
                setattr(obj, "NumberOfBytesReceived", fval)
            elif fname == "NumberOfBytesSent":
                setattr(obj, "NumberOfBytesSent", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "SSId":
                setattr(obj, "SSId", fval)
            elif fname == "UsageMode":
                setattr(obj, "UsageMode", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "ApplicationId":
                setattr(obj, "ApplicationId", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "NetworkUsage Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Note(ModelBase):
    Account: Optional[str] = None
    Body: Optional[str] = None
    Creation: Optional[datetime] = None
    Folder: Optional[str] = None
    Modification: Optional[datetime] = None
    PositionAddress: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Summary: Optional[str] = None
    Title: Optional[str] = None
    UserMapping: Optional[str] = None
    Address: Optional[str] = None
    Position: Optional[str] = None
    Attachments: List[Any] = field(default_factory=list)
    Participants: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Note"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Note":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "Creation":
                setattr(obj, "Creation", _to_datetime(fval))
            elif fname == "Folder":
                setattr(obj, "Folder", fval)
            elif fname == "Modification":
                setattr(obj, "Modification", _to_datetime(fval))
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Summary":
                setattr(obj, "Summary", fval)
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Address":
                setattr(obj, "Address", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "Participants":
                setattr(obj, "Participants", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Note Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Notification(ModelBase):
    Body: Optional[str] = None
    DateRead: Optional[datetime] = None
    NotificationId: Optional[str] = None
    PositionAddress: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    Subject: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    Position: Optional[str] = None
    To: Optional[str] = None
    Notes: List[Any] = field(default_factory=list)
    Attachments: List[Any] = field(default_factory=list)
    Participants: List[Any] = field(default_factory=list)
    Urls: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Notification"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Notification":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "DateRead":
                setattr(obj, "DateRead", _to_datetime(fval))
            elif fname == "NotificationId":
                setattr(obj, "NotificationId", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "Subject":
                setattr(obj, "Subject", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            elif fname == "To":
                setattr(obj, "To", fval)
            elif fname == "Notes":
                setattr(obj, "Notes", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "Participants":
                setattr(obj, "Participants", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Notification Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Organization(ModelBase):
    Name: Optional[str] = None
    Position: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Organization"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Organization":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Organization Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Party(ModelBase):
    DateDelivered: Optional[datetime] = None
    DatePlayed: Optional[datetime] = None
    DateRead: Optional[datetime] = None
    Distance: Optional[str] = None
    id: Optional[str] = None
    Identifier: Optional[str] = None
    IPAddress: Optional[str] = None
    IsGroupAdmin: Optional[str] = None
    IsPhoneOwner: bool = False
    Name: Optional[str] = None
    Role: Optional[str] = None
    Status: Optional[str] = None
    UserMapping: Optional[str] = None
    IPAddresses: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Party"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Party":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "DateDelivered":
                setattr(obj, "DateDelivered", _to_datetime(fval))
            elif fname == "DatePlayed":
                setattr(obj, "DatePlayed", _to_datetime(fval))
            elif fname == "DateRead":
                setattr(obj, "DateRead", _to_datetime(fval))
            elif fname == "Distance":
                setattr(obj, "Distance", fval)
            elif fname == "Id":
                setattr(obj, "Id", fval)
            elif fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "IPAddress":
                setattr(obj, "IPAddress", fval)
            elif fname == "IsGroupAdmin":
                setattr(obj, "IsGroupAdmin", fval)
            elif fname == "IsPhoneOwner":
                setattr(obj, "IsPhoneOwner", _to_bool(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Role":
                setattr(obj, "Role", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "IPAddresses":
                setattr(obj, "IPAddresses", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Party Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Password(ModelBase):
    AccessGroup: Optional[str] = None
    Account: Optional[str] = None
    Data: Optional[str] = None
    DateCreated: Optional[datetime] = None
    DateModified: Optional[datetime] = None
    GenericAttribute: Optional[str] = None
    Label: Optional[str] = None
    Server: Optional[str] = None
    Service: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Password"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Password":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "AccessGroup":
                setattr(obj, "AccessGroup", fval)
            elif fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Data":
                setattr(obj, "Data", fval)
            elif fname == "DateCreated":
                setattr(obj, "DateCreated", _to_datetime(fval))
            elif fname == "DateModified":
                setattr(obj, "DateModified", _to_datetime(fval))
            elif fname == "GenericAttribute":
                setattr(obj, "GenericAttribute", fval)
            elif fname == "Label":
                setattr(obj, "Label", fval)
            elif fname == "Server":
                setattr(obj, "Server", fval)
            elif fname == "Service":
                setattr(obj, "Service", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Password Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class PoweringEvent(ModelBase):
    Description: Optional[str] = None
    Element: Optional[str] = None
    Event: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "PoweringEvent"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "PoweringEvent":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "Element":
                setattr(obj, "Element", fval)
            elif fname == "Event":
                setattr(obj, "Event", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "PoweringEvent Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Price(ModelBase):
    Amount: float = 0.0
    Currency: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Price"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Price":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Amount":
                setattr(obj, "Amount", _to_float(fval))
            elif fname == "Currency":
                setattr(obj, "Currency", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Price Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class PublicTransportationTicket(ModelBase):
    Account: Optional[str] = None
    ScheduledDepartureTime: Optional[datetime] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    ArrivalAddress: Optional[str] = None
    DepartureAddress: Optional[str] = None
    Passengers: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "PublicTransportationTicket"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "PublicTransportationTicket":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "ScheduledDepartureTime":
                setattr(obj, "ScheduledDepartureTime", _to_datetime(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "ArrivalAddress":
                setattr(obj, "ArrivalAddress", fval)
            elif fname == "DepartureAddress":
                setattr(obj, "DepartureAddress", fval)
            elif fname == "Passengers":
                setattr(obj, "Passengers", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "PublicTransportationTicket Parser: Unknown field: "
                        + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class RecognizedDevice(ModelBase):
    Account: Optional[str] = None
    DeviceModel: Optional[str] = None
    DeviceType: Optional[str] = None
    Name: Optional[str] = None
    SerialNumber: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "RecognizedDevice"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "RecognizedDevice":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "DeviceModel":
                setattr(obj, "DeviceModel", fval)
            elif fname == "DeviceType":
                setattr(obj, "DeviceType", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "SerialNumber":
                setattr(obj, "SerialNumber", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "RecognizedDevice Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Recording(ModelBase):
    Duration: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    Title: Optional[str] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Recording"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Recording":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Duration":
                setattr(obj, "Duration", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Recording Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class SearchedItem(ModelBase):
    Account: Optional[str] = None
    Origin: Optional[str] = None
    OSUserId: Optional[str] = None
    PositionAddress: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None
    Position: Optional[str] = None
    SearchResults: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "SearchedItem"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "SearchedItem":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Origin":
                setattr(obj, "Origin", fval)
            elif fname == "OSUserId":
                setattr(obj, "OSUserId", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            elif fname == "SearchResults":
                setattr(obj, "SearchResults", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "SearchedItem Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class SIMData(ModelBase):
    Category: Optional[str] = None
    Name: Optional[str] = None
    Source: Optional[str] = None
    UserMapping: Optional[str] = None
    Value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "SIMData"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "SIMData":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Category":
                setattr(obj, "Category", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Value":
                setattr(obj, "Value", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "SIMData Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class SocialMediaActivity(ModelBase):
    Account: Optional[str] = None
    Body: Optional[str] = None
    ChannelName: Optional[str] = None
    ChannelType: Optional[str] = None
    CommentCount: int = 0
    DateModified: Optional[datetime] = None
    IsFromActivityLog: Optional[str] = None
    OriginalPostId: Optional[str] = None
    Platform: Optional[str] = None
    PrivacySetting: Optional[str] = None
    ReactionsCount: int = 0
    ServiceIdentifier: Optional[str] = None
    SharesCount: int = 0
    SocialActivityType: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    Title: Optional[str] = None
    Url: Optional[str] = None
    UserMapping: Optional[str] = None
    Author: Optional[str] = None
    ParentPost: Optional[str] = None
    Position: Optional[str] = None
    Attachments: List[Any] = field(default_factory=list)
    TaggedParties: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "SocialMediaActivity"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "SocialMediaActivity":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "Body":
                setattr(obj, "Body", fval)
            elif fname == "ChannelName":
                setattr(obj, "ChannelName", fval)
            elif fname == "ChannelType":
                setattr(obj, "ChannelType", fval)
            elif fname == "CommentCount":
                setattr(obj, "CommentCount", _to_int(fval))
            elif fname == "DateModified":
                setattr(obj, "DateModified", _to_datetime(fval))
            elif fname == "IsFromActivityLog":
                setattr(obj, "IsFromActivityLog", fval)
            elif fname == "OriginalPostId":
                setattr(obj, "OriginalPostId", fval)
            elif fname == "Platform":
                setattr(obj, "Platform", fval)
            elif fname == "PrivacySetting":
                setattr(obj, "PrivacySetting", fval)
            elif fname == "ReactionsCount":
                setattr(obj, "ReactionsCount", _to_int(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "SharesCount":
                setattr(obj, "SharesCount", _to_int(fval))
            elif fname == "SocialActivityType":
                setattr(obj, "SocialActivityType", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Author":
                setattr(obj, "Author", fval)
            elif fname == "ParentPost":
                setattr(obj, "ParentPost", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            elif fname == "Attachments":
                setattr(obj, "Attachments", fval)
            elif fname == "TaggedParties":
                setattr(obj, "TaggedParties", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "SocialMediaActivity Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class StreetAddress(ModelBase):
    Category: Optional[str] = None
    City: Optional[str] = None
    Country: Optional[str] = None
    HouseNumber: Optional[str] = None
    Neighborhood: Optional[str] = None
    POBox: Optional[str] = None
    PostalCode: Optional[str] = None
    State: Optional[str] = None
    Street1: Optional[str] = None
    Street2: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "StreetAddress"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "StreetAddress":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Category":
                setattr(obj, "Category", fval)
            elif fname == "City":
                setattr(obj, "City", fval)
            elif fname == "Country":
                setattr(obj, "Country", fval)
            elif fname == "HouseNumber":
                setattr(obj, "HouseNumber", fval)
            elif fname == "Neighborhood":
                setattr(obj, "Neighborhood", fval)
            elif fname == "POBox":
                setattr(obj, "POBox", fval)
            elif fname == "PostalCode":
                setattr(obj, "PostalCode", fval)
            elif fname == "State":
                setattr(obj, "State", fval)
            elif fname == "Street1":
                setattr(obj, "Street1", fval)
            elif fname == "Street2":
                setattr(obj, "Street2", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "StreetAddress Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class TransferOfFunds(ModelBase):
    DateProcessed: Optional[datetime] = None
    DateSent: Optional[datetime] = None
    Description: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    TransferType: Optional[str] = None
    UserMapping: Optional[str] = None
    Fee: Optional[str] = None
    TransferAmount: Optional[str] = None
    Participants: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "TransferOfFunds"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "TransferOfFunds":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "DateProcessed":
                setattr(obj, "DateProcessed", _to_datetime(fval))
            elif fname == "DateSent":
                setattr(obj, "DateSent", _to_datetime(fval))
            elif fname == "Description":
                setattr(obj, "Description", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Status":
                setattr(obj, "Status", fval)
            elif fname == "TransferType":
                setattr(obj, "TransferType", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Fee":
                setattr(obj, "Fee", fval)
            elif fname == "TransferAmount":
                setattr(obj, "TransferAmount", fval)
            elif fname == "Participants":
                setattr(obj, "Participants", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "TransferOfFunds Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class User(ModelBase):
    Identifier: Optional[str] = None
    Name: Optional[str] = None
    SerialNumber: Optional[str] = None
    TimeLastLoggedIn: Optional[datetime] = None
    UserMapping: Optional[str] = None
    UserType: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "User"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "User":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Identifier":
                setattr(obj, "Identifier", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "SerialNumber":
                setattr(obj, "SerialNumber", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "UserType":
                setattr(obj, "UserType", fval)
            elif fname == "TimeLastLoggedIn":
                setattr(obj, "TimeLastLoggedIn", _to_datetime(fval))
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "User Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class UserAccount(ModelBase):
    id: Optional[str] = None
    Name: Optional[str] = None
    Password: Optional[str] = None
    ServerAddress: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    ServiceType: Optional[str] = None
    Source: Optional[str] = None
    TimeCreated: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Username: Optional[str] = None
    Notes: List[Any] = field(default_factory=list)
    Addresses: List[Any] = field(default_factory=list)
    Entries: List[Any] = field(default_factory=list)
    Organizations: List[Any] = field(default_factory=list)
    Photos: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "UserAccount"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "UserAccount":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Id":
                setattr(obj, "Id", fval)
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Password":
                setattr(obj, "Password", fval)
            elif fname == "ServerAddress":
                setattr(obj, "ServerAddress", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "ServiceType":
                setattr(obj, "ServiceType", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeCreated":
                setattr(obj, "TimeCreated", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Username":
                setattr(obj, "Username", fval)
            elif fname == "Notes":
                setattr(obj, "Notes", fval)
            elif fname == "Addresses":
                setattr(obj, "Addresses", fval)
            elif fname == "Entries":
                setattr(obj, "Entries", fval)
            elif fname == "Photos":
                setattr(obj, "Photos", fval)
            elif fname == "Organizations":
                setattr(obj, "Organizations", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "UserAccount Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class VisitedPage(ModelBase):
    Account: Optional[str] = None
    ArtifactFamily: Optional[str] = None
    CanRebuildCacheFile: Optional[str] = None
    LastVisited: Optional[datetime] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    Title: Optional[str] = None
    Url: Optional[str] = None
    UrlCacheFile: Optional[str] = None
    UserMapping: Optional[str] = None
    VisitCount: int = 0

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "VisitedPage"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "VisitedPage":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Account":
                setattr(obj, "Account", fval)
            elif fname == "ArtifactFamily":
                setattr(obj, "ArtifactFamily", fval)
            elif fname == "CanRebuildCacheFile":
                setattr(obj, "CanRebuildCacheFile", fval)
            elif fname == "LastVisited":
                setattr(obj, "LastVisited", _to_datetime(fval))
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            elif fname == "UrlCacheFile":
                setattr(obj, "UrlCacheFile", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "VisitCount":
                setattr(obj, "VisitCount", _to_int(fval))
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "VisitedPage Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class Voicemail(ModelBase):
    Duration: Optional[str] = None
    LastModified: Optional[datetime] = None
    Name: Optional[str] = None
    Source: Optional[str] = None
    Timestamp: Optional[datetime] = None
    type: Optional[str] = None
    UserMapping: Optional[str] = None
    WasPlayed: Optional[str] = None
    From: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Voicemail"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Voicemail":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "Duration":
                setattr(obj, "Duration", fval)
            elif fname == "LastModified":
                setattr(obj, "LastModified", _to_datetime(fval))
            elif fname == "Name":
                setattr(obj, "Name", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "Timestamp":
                setattr(obj, "Timestamp", _to_datetime(fval))
            elif fname == "Type":
                setattr(obj, "Type", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "WasPlayed":
                setattr(obj, "WasPlayed", fval)
            elif fname == "From":
                setattr(obj, "From", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Voicemail Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class WebBookmark(ModelBase):
    LastVisited: Optional[datetime] = None
    Path: Optional[str] = None
    PositionAddress: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    Title: Optional[str] = None
    Url: Optional[str] = None
    UserMapping: Optional[str] = None
    VisitCount: int = 0
    Position: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "WebBookmark"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "WebBookmark":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "LastVisited":
                setattr(obj, "LastVisited", _to_datetime(fval))
            elif fname == "Path":
                setattr(obj, "Path", fval)
            elif fname == "PositionAddress":
                setattr(obj, "PositionAddress", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "Title":
                setattr(obj, "Title", fval)
            elif fname == "Url":
                setattr(obj, "Url", fval)
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "VisitCount":
                setattr(obj, "VisitCount", _to_int(fval))
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "WebBookmark Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj


@default_registry.register
@dataclass
class WirelessNetwork(ModelBase):
    ArtifactFamily: Optional[str] = None
    BSSId: Optional[str] = None
    EndTime: Optional[datetime] = None
    LastAutoConnection: Optional[datetime] = None
    LastConnection: Optional[datetime] = None
    NWConnectionType: Optional[str] = None
    Package: Optional[str] = None
    Password: Optional[str] = None
    SecurityMode: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Source: Optional[str] = None
    SSId: Optional[str] = None
    TimeStamp: Optional[datetime] = None
    UserMapping: Optional[str] = None
    Position: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "WirelessNetwork"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "WirelessNetwork":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )
        for fname, fval in fields.items():
            if fname is None:
                continue
            if fname == "ArtifactFamily":
                setattr(obj, "ArtifactFamily", fval)
            elif fname == "BSSId":
                setattr(obj, "BSSId", fval)
            elif fname == "EndTime":
                setattr(obj, "EndTime", _to_datetime(fval))
            elif fname == "LastAutoConnection":
                setattr(obj, "LastAutoConnection", _to_datetime(fval))
            elif fname == "LastConnection":
                setattr(obj, "LastConnection", _to_datetime(fval))
            elif fname == "NWConnectionType":
                setattr(obj, "NWConnectionType", fval)
            elif fname == "Package":
                setattr(obj, "Package", fval)
            elif fname == "Password":
                setattr(obj, "Password", fval)
            elif fname == "SecurityMode":
                setattr(obj, "SecurityMode", fval)
            elif fname == "ServiceIdentifier":
                setattr(obj, "ServiceIdentifier", fval)
            elif fname == "Source":
                setattr(obj, "Source", fval)
            elif fname == "SSId":
                setattr(obj, "SSId", fval)
            elif fname == "TimeStamp":
                setattr(obj, "TimeStamp", _to_datetime(fval))
            elif fname == "UserMapping":
                setattr(obj, "UserMapping", fval)
            elif fname == "Position":
                setattr(obj, "Position", fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "WirelessNetwork Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval
        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj
