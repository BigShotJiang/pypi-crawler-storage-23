from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..registry import default_registry


@default_registry.register
@dataclass
class KeyValueModel(ModelBase):
    key: Optional[str] = None
    user_mapping: Optional[str] = None
    value: Optional[str] = None

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "KeyValueModel"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "KeyValueModel":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )

        for name, value in fields.items():
            if name == "Key":
                obj.key = value
            elif name == "UserMapping":
                obj.user_mapping = value
            elif name == "Value":
                obj.value = value
            else:
                if debug_attributes:
                    default_logger.attribute(
                        f"KeyValueModel Parser: Unknown field: {name}"
                    )
                obj._unknown_fields[name] = value

        if debug_attributes:
            for k in model_fields.keys():
                default_logger.attribute(
                    f"KeyValueModel Parser: Unknown modelField: {k}"
                )
            for k in multi_fields.keys():
                default_logger.attribute(
                    f"KeyValueModel Parser: Unknown multiField: {k}"
                )
            for k in multi_model_fields.keys():
                default_logger.attribute(
                    f"KeyValueModel Parser: Unknown multiModelField: {k}"
                )

        obj._unknown_model_fields.update(model_fields)
        obj._unknown_multi_fields.update(multi_fields)
        obj._unknown_multi_model_fields.update(multi_model_fields)
        return obj
