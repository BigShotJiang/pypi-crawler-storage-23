from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..nested import parse_model_elements
from ..parser import parse_model_element
from ..registry import default_registry


def _first_child_model(model_field_el: Any) -> Any:
    # modelField structure: <modelField name="X"><model .../></modelField>
    for child in list(model_field_el):
        if getattr(child, "tag", None) is not None and str(child.tag).endswith("model"):
            return child
    # fallback: any element that localname is model
    for child in list(model_field_el):
        if hasattr(child, "tag") and (
            "}" in child.tag and child.tag.rsplit("}", 1)[1] == "model"
        ):
            return child
    return None


@default_registry.register
@dataclass
class InstantMessage(ModelBase):
    Body: Optional[str] = None
    ChatId: Optional[str] = None
    DateDeleted: Optional[str] = None
    DateDelivered: Optional[str] = None
    DateRead: Optional[str] = None
    DeletionReason: Optional[str] = None
    Erased: Optional[str] = None
    Folder: Optional[str] = None
    FromIsOwner: Optional[str] = None
    Id: Optional[str] = None
    Identifier: Optional[str] = None
    IsLocationSharing: Optional[str] = None
    JumpTargetId: Optional[str] = None
    Label: Optional[str] = None
    Platform: Optional[str] = None
    PositionAddress: Optional[str] = None
    Priority: Optional[str] = None
    SelfDestructDuration: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    SMSC: Optional[str] = None
    Source: Optional[str] = None
    SourceApplication: Optional[str] = None
    Status: Optional[str] = None
    Subject: Optional[str] = None
    TimeStamp: Optional[str] = None
    Type: Optional[str] = None
    UserMapping: Optional[str] = None

    Attachment: Any = None
    From: Any = None
    Position: Any = None

    Attachments: List[Any] = field(default_factory=list)
    ActivityLog: List[Any] = field(default_factory=list)
    SharedContacts: List[Any] = field(default_factory=list)
    To: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "InstantMessage"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "InstantMessage":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )

        for fname, fval in (fields or {}).items():
            if hasattr(obj, fname):
                setattr(obj, fname, fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "InstantMessage Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval

        # modelFields: Attachment / From / Position
        for mname, mfield_el in (model_fields or {}).items():
            child = _first_child_model(mfield_el)
            if child is None:
                continue
            parsed = parse_model_element(child, debug_attributes=debug_attributes)
            if mname == "Attachment":
                obj.Attachment = parsed
            elif mname == "From":
                obj.From = parsed
            elif mname == "Position":
                obj.Position = parsed
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "InstantMessage Parser: Unknown modelField: " + str(mname)
                    )
                obj._unknown_model_fields[mname] = mfield_el

        # multiFields: JumpTargetId is handled in C# under multiFields
        if multi_fields and "JumpTargetId" in multi_fields:
            vals = multi_fields.get("JumpTargetId") or []
            if vals:
                obj.JumpTargetId = vals[-1]

        mmf = multi_model_fields or {}
        if "ActivityLog" in mmf:
            obj.ActivityLog = parse_model_elements(
                mmf.get("ActivityLog") or [], debug_attributes=debug_attributes
            )
        if "Attachments" in mmf:
            obj.Attachments = parse_model_elements(
                mmf.get("Attachments") or [], debug_attributes=debug_attributes
            )
        if "SharedContacts" in mmf:
            obj.SharedContacts = parse_model_elements(
                mmf.get("SharedContacts") or [], debug_attributes=debug_attributes
            )
        if "To" in mmf:
            obj.To = parse_model_elements(
                mmf.get("To") or [], debug_attributes=debug_attributes
            )

        # keep unknown buckets
        for k, v in (multi_fields or {}).items():
            if k != "JumpTargetId":
                obj._unknown_multi_fields[k] = list(v)
        for k, v in mmf.items():
            if k not in {"ActivityLog", "Attachments", "SharedContacts", "To"}:
                obj._unknown_multi_model_fields[k] = list(v)

        return obj
