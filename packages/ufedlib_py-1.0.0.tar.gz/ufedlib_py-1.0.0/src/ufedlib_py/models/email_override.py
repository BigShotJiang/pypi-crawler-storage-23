from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from ..logger import default_logger
from ..model_base import ModelBase
from ..nested import parse_model_elements
from ..parser import parse_model_element
from ..registry import default_registry


def _first_child_model(model_field_el: Any) -> Any:
    for child in list(model_field_el):
        # localname == model
        if hasattr(child, "tag") and (
            "}" in child.tag and child.tag.rsplit("}", 1)[1] == "model"
        ):
            return child
        if getattr(child, "tag", None) == "model":
            return child
    return None


@default_registry.register
@dataclass
class Email(ModelBase):
    Account: Optional[str] = None
    Body: Optional[str] = None
    EmailHeader: Optional[str] = None
    Folder: Optional[str] = None
    Priority: Optional[str] = None
    ServiceIdentifier: Optional[str] = None
    Snippet: Optional[str] = None
    Source: Optional[str] = None
    Status: Optional[str] = None
    Subject: Optional[str] = None
    TimeStamp: Optional[str] = None
    UserMapping: Optional[str] = None

    From: Any = None

    Labels: List[str] = field(default_factory=list)

    Attachments: List[Any] = field(default_factory=list)
    Bcc: List[Any] = field(default_factory=list)
    Cc: List[Any] = field(default_factory=list)
    To: List[Any] = field(default_factory=list)

    @classmethod
    def get_xml_model_type(cls) -> str:
        return "Email"

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> "Email":
        obj = cls(
            id=attrs.get("id"),
            type=attrs.get("type"),
            deleted_state=attrs.get("deleted_state"),
            decoding_confidence=attrs.get("decoding_confidence"),
            isrelated=attrs.get("isrelated"),
            source_index=attrs.get("source_index"),
            extractionId=attrs.get("extractionId"),
        )

        for fname, fval in (fields or {}).items():
            if hasattr(obj, fname):
                setattr(obj, fname, fval)
            else:
                if debug_attributes:
                    default_logger.attribute(
                        "Email Parser: Unknown field: " + str(fname)
                    )
                obj._unknown_fields[fname] = fval

        # modelField: From
        if model_fields and "From" in model_fields:
            child = _first_child_model(model_fields.get("From"))
            if child is not None:
                obj.From = parse_model_element(child, debug_attributes=debug_attributes)

        # multiFields: Labels
        if multi_fields and "Labels" in multi_fields:
            obj.Labels = list(multi_fields.get("Labels") or [])

        mmf = multi_model_fields or {}
        if "Attachments" in mmf:
            obj.Attachments = parse_model_elements(
                mmf.get("Attachments") or [], debug_attributes=debug_attributes
            )
        if "Bcc" in mmf:
            obj.Bcc = parse_model_elements(
                mmf.get("Bcc") or [], debug_attributes=debug_attributes
            )
        if "Cc" in mmf:
            obj.Cc = parse_model_elements(
                mmf.get("Cc") or [], debug_attributes=debug_attributes
            )
        if "To" in mmf:
            obj.To = parse_model_elements(
                mmf.get("To") or [], debug_attributes=debug_attributes
            )

        # keep unknown buckets
        obj._unknown_model_fields.update(
            {k: v for k, v in (model_fields or {}).items() if k != "From"}
        )
        for k, v in (multi_fields or {}).items():
            if k != "Labels":
                obj._unknown_multi_fields[k] = list(v)
        for k, v in mmf.items():
            if k not in {"Attachments", "Bcc", "Cc", "To"}:
                obj._unknown_multi_model_fields[k] = list(v)

        return obj
