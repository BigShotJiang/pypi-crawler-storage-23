from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime
from typing import Any, Dict, Optional
from xml.etree.ElementTree import Element


@dataclass
class ModelBase:
    id: Optional[str] = None
    type: Optional[str] = None
    deleted_state: Optional[str] = None
    decoding_confidence: Optional[str] = None
    isrelated: Optional[str] = None
    source_index: Optional[str] = None
    extractionId: Optional[str] = None

    _unknown_fields: Dict[str, Any] = field(default_factory=dict, repr=False)
    _unknown_model_fields: Dict[str, Any] = field(default_factory=dict, repr=False)
    _unknown_multi_fields: Dict[str, Any] = field(default_factory=dict, repr=False)
    _unknown_multi_model_fields: Dict[str, Any] = field(
        default_factory=dict, repr=False
    )

    def to_dict(self) -> Dict[str, Any]:
        def _coerce(v: Any) -> Any:
            if v is None:
                return None
            if isinstance(v, (str, int, float, bool)):
                return v
            if isinstance(v, datetime):
                return v.isoformat()
            if isinstance(v, dict):
                return {str(k): _coerce(val) for k, val in v.items()}
            if isinstance(v, (list, tuple, set)):
                return [_coerce(x) for x in v]
            if isinstance(v, Element):
                # Unknown raw XML elements shouldn't break JSON output.
                return f"<{v.tag}>"
            if hasattr(v, "to_dict") and callable(getattr(v, "to_dict")):
                return _coerce(v.to_dict())
            return str(v)

        data = asdict(self)
        for key, value in self.__dict__.items():
            if key.startswith("_"):
                continue
            if key in data:
                continue
            data[key] = value

        return _coerce(data)
