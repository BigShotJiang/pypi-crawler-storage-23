from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import zipfile
from typing import Dict, List, Optional, Tuple

from ..input_source import open_report_stream
from ._xml_sections import parse_named_values_from_section
from .project_infos import parse_project_infos


def _can_execute(program: str) -> bool:
    return shutil.which(program) is not None


def parse_device_info(path: str) -> Optional[List[Tuple[str, str]]]:
    """Port of C# DeviceInfo.Parse.

    Notes:
    - For report versions < 8.5, Device Info is present in report.xml metadata.
    - For >= 8.5, C# extracts and restores a PostgreSQL dump using pg_restore.
      Here we attempt the same *only if* pg_restore is available; otherwise we return None.
    """

    infos = parse_project_infos(path)
    version = infos.report_version
    if not version:
        return None

    def _parse_xml() -> List[Tuple[str, str]]:
        with open_report_stream(path) as stream:
            return parse_named_values_from_section(
                stream, section_name="Device Info", element_local_name="metadata"
            )

    # If version parsing fails, fallback to XML section.
    try:
        major_minor = tuple(int(x) for x in version.split(".")[:2])
    except Exception:
        return _parse_xml()

    if major_minor < (8, 5):
        return _parse_xml()

    # >= 8.5 path: attempt DB extraction.
    if not _can_execute("pg_restore"):
        return None

    if not path.lower().endswith(".ufdr"):
        # DB files are inside UFDR.
        return None

    tmp = tempfile.mkdtemp(prefix="ufedlib_")
    project_id = infos.project_id or "project"
    db_file = os.path.join(tmp, f"{project_id}.db")
    db_json = os.path.join(tmp, f"{project_id}.json")
    restore_sql = os.path.join(tmp, f"{project_id}.sql")

    try:
        with zipfile.ZipFile(path, "r") as zf:
            db_entry = "DbData/database.db"
            json_entry = "DbData/database.json"
            if db_entry not in zf.namelist() or json_entry not in zf.namelist():
                return None
            zf.extract(db_entry, tmp)
            zf.extract(json_entry, tmp)

            # extracted paths include folders
            extracted_db = os.path.join(tmp, db_entry)
            extracted_json = os.path.join(tmp, json_entry)

            # run pg_restore -> SQL
            proc = subprocess.run(
                ["pg_restore", "-f", restore_sql, extracted_db],
                capture_output=True,
                text=True,
            )
            if proc.returncode != 0:
                return None

            schema = _get_schema_name(extracted_json)
            return _get_device_info_entries(schema, restore_sql)
    finally:
        try:
            shutil.rmtree(tmp, ignore_errors=True)
        except Exception:
            pass


def parse_device_info_to_json_array(path: str) -> str:
    items = parse_device_info(path) or []
    arr = [{k: v} for k, v in items]
    return json.dumps(arr, ensure_ascii=False, indent=2)


def parse_device_info_to_json_dict(path: str) -> str:
    items = parse_device_info(path) or []
    agg: Dict[str, List[str]] = {}
    for k, v in items:
        agg.setdefault(k, []).append(v)
    d = {k: ", ".join(vs) for k, vs in agg.items()}
    return json.dumps(d, ensure_ascii=False, indent=2)


def _get_schema_name(db_json_file_path: str) -> str:
    with open(db_json_file_path, "r", encoding="utf-8") as f:
        root = json.load(f)
    device_id = root.get("DeviceId")
    return f"device_{device_id}"


def _get_device_info_entries(
    schema_name: str, db_sql_file_path: str
) -> List[Tuple[str, str]]:
    start = f'COPY "{schema_name}"."DeviceInfoEntries"'

    start_line = ""
    data: List[str] = []

    with open(db_sql_file_path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if line.startswith(start):
                start_line = line.strip()
                for line2 in f:
                    if line2.startswith("\\."):
                        break
                    data.append(line2.rstrip("\n"))
                break

    if not start_line:
        return []

    col_part = start_line.split(",")
    col_part = [c.strip() for c in col_part]

    entry_col = '"EntryName"'
    value_col = '"EntryValue"'

    try:
        entry_idx = col_part.index(entry_col)
        value_idx = col_part.index(value_col)
    except ValueError:
        return []

    out: List[Tuple[str, str]] = []
    for row in data:
        parts = row.split("\t")
        if len(parts) <= max(entry_idx, value_idx):
            continue
        out.append((parts[entry_idx], parts[value_idx]))
    return out
