from __future__ import annotations

from dataclasses import dataclass
from typing import Optional
from xml.etree.ElementTree import iterparse

from ..input_source import open_report_stream
from ..xml_utils import localname


@dataclass
class ProjectInfos:
    project_id: str = ""
    name: str = ""
    report_version: str = ""
    license_id: str = ""
    contains_garbage: str = ""
    extraction_type: str = ""
    node_count: str = ""
    model_count: str = ""
    media_results: str = ""
    xmlns: str = ""


def parse_project_infos(path: str) -> ProjectInfos:
    with open_report_stream(path) as stream:
        for event, elem in iterparse(stream, events=("start",)):
            if localname(elem.tag) == "project":
                return ProjectInfos(
                    project_id=elem.get("id") or "",
                    name=elem.get("name") or "",
                    report_version=elem.get("reportVersion") or "",
                    license_id=elem.get("licenseID") or "",
                    contains_garbage=elem.get("containsGarbage") or "",
                    extraction_type=elem.get("extractionType") or "",
                    node_count=elem.get("NodeCount") or "",
                    model_count=elem.get("ModelCount") or "",
                    media_results=elem.get("MediaResults") or "",
                    xmlns=elem.get("xmlns") or "",
                )
        return ProjectInfos()
