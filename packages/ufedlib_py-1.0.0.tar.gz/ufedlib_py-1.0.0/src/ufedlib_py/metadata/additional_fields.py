from __future__ import annotations

import json
from typing import List, Tuple

from ..input_source import open_report_stream
from ._xml_sections import parse_named_values_from_section


def parse_additional_fields(path: str) -> List[Tuple[str, str]]:
    with open_report_stream(path) as stream:
        return parse_named_values_from_section(
            stream, section_name="Additional Fields", element_local_name="metadata"
        )


def parse_additional_fields_to_json(path: str) -> str:
    items = parse_additional_fields(path)
    return json.dumps({k: v for k, v in items}, ensure_ascii=False, indent=2)
