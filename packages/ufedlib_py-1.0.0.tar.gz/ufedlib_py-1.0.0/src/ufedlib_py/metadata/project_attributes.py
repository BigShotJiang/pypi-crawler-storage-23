from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Tuple
from xml.etree.ElementTree import iterparse

from ..input_source import open_report_stream
from ..xml_utils import localname
from .additional_fields import parse_additional_fields
from .case_information import parse_case_information
from .device_info import parse_device_info
from .extraction_data import parse_extraction_data


@dataclass
class ProjectAttributes:
    file_name: Optional[str] = None
    file_size_in_bytes: Optional[int] = None

    project_name: Optional[str] = None
    project_id: Optional[str] = None
    report_version: Optional[str] = None
    node_count: int = 0
    model_count: int = 0

    case_information: List[Tuple[str, str]] = field(default_factory=list)
    additional_fields: List[Tuple[str, str]] = field(default_factory=list)
    extraction_data: List[Tuple[str, str]] = field(default_factory=list)
    device_info: List[Tuple[str, str]] = field(default_factory=list)


def parse_project_attributes(path: str) -> ProjectAttributes:
    pa = ProjectAttributes(file_name=path)

    try:
        import os

        pa.file_size_in_bytes = os.path.getsize(path)
    except OSError:
        pass

    with open_report_stream(path) as stream:
        for event, elem in iterparse(stream, events=("start",)):
            if localname(elem.tag) == "project":
                pa.project_id = elem.get("id")
                pa.project_name = elem.get("name")
                pa.report_version = elem.get("reportVersion")
                try:
                    pa.node_count = int(elem.get("NodeCount") or 0)
                except ValueError:
                    pa.node_count = 0
                try:
                    pa.model_count = int(elem.get("ModelCount") or 0)
                except ValueError:
                    pa.model_count = 0
                break

    # Mirror C# behavior: parse these sections.
    pa.additional_fields = parse_additional_fields(path)
    pa.extraction_data = parse_extraction_data(path)
    pa.case_information = parse_case_information(path)

    # Device Info may depend on report version; we attempt best-effort.
    pa.device_info = parse_device_info(path) or []

    return pa
