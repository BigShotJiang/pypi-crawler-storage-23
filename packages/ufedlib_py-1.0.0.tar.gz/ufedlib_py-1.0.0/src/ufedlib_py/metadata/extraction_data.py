from __future__ import annotations

import json
from typing import Dict, List, Tuple

from ..input_source import open_report_stream
from ._xml_sections import parse_named_values_from_section


def parse_extraction_data(path: str) -> List[Tuple[str, str]]:
    with open_report_stream(path) as stream:
        return parse_named_values_from_section(
            stream, section_name="Extraction Data", element_local_name="metadata"
        )


def parse_extraction_data_to_json(path: str) -> str:
    items = parse_extraction_data(path)

    # Mirror C# behavior: split into blocks each time DeviceInfoExtractionStartDateTime occurs.
    blocks: List[Dict[str, str]] = []
    current: Dict[str, str] = {}
    for k, v in items:
        if k == "DeviceInfoExtractionStartDateTime" and current:
            blocks.append(current)
            current = {}
        current[k] = v
    if current:
        blocks.append(current)

    return json.dumps(blocks, ensure_ascii=False, indent=2)
