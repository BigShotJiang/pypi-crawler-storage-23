from __future__ import annotations

from dataclasses import dataclass
from typing import BinaryIO, Iterable, Iterator, List, Optional, Tuple
from xml.etree.ElementTree import iterparse

from ..xml_utils import localname


def iter_elements(stream: BinaryIO, *, end_tag_local: str) -> Iterator[object]:
    for event, elem in iterparse(stream, events=("end",)):
        if localname(elem.tag) == end_tag_local:
            yield elem
            elem.clear()


def parse_named_values_from_section(
    stream: BinaryIO,
    *,
    section_name: Optional[str] = None,
    element_local_name: str = "metadata",
) -> List[Tuple[str, str]]:
    """Parse list of (name, value) from:

    - <metadata section="X"> ... <field name="...">value</field> ...
    - or <caseInformation> ... <field name="...">value</field> ...

    This mirrors the C# behavior of reading the subtree and collecting all descendants with a 'name' attribute.
    """

    results: List[Tuple[str, str]] = []

    for event, elem in iterparse(stream, events=("end",)):
        if localname(elem.tag) != element_local_name:
            continue

        if section_name is not None:
            if elem.get("section") != section_name:
                elem.clear()
                continue

        for d in elem.iter():
            name = d.get("name")
            if not name:
                continue
            value = (d.text or "").strip()
            results.append((name, value))

        break

    return results
