from __future__ import annotations

import json
from typing import List, Tuple

from ..input_source import open_report_stream
from ._xml_sections import parse_named_values_from_section


def parse_case_information(path: str) -> List[Tuple[str, str]]:
    with open_report_stream(path) as stream:
        return parse_named_values_from_section(
            stream, section_name=None, element_local_name="caseInformation"
        )


def parse_case_information_to_json(path: str) -> str:
    items = parse_case_information(path)
    return json.dumps({k: v for k, v in items}, ensure_ascii=False, indent=2)
