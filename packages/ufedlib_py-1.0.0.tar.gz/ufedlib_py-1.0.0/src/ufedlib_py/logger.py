from __future__ import annotations

import sys
from dataclasses import dataclass


@dataclass(frozen=True)
class Logger:
    debug: bool = False

    def info(self, msg: str) -> None:
        print(msg, file=sys.stderr)

    def warning(self, msg: str) -> None:
        print(f"WARNING: {msg}", file=sys.stderr)

    def error(self, msg: str) -> None:
        print(f"ERROR: {msg}", file=sys.stderr)

    def attribute(self, msg: str) -> None:
        if self.debug:
            print(f"ATTR: {msg}", file=sys.stderr)


default_logger = Logger(debug=False)
