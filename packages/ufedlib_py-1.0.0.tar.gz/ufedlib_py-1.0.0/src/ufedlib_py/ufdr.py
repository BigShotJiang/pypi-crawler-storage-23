from __future__ import annotations

import io
import zipfile
from typing import BinaryIO


def open_report_xml_from_ufdr(path: str) -> BinaryIO:
    zf = zipfile.ZipFile(path, "r")
    try:
        # Keep ZipFile open by returning a file-like object that retains reference.
        # We'll wrap it in a BufferedReader-like object that closes the zip when closed.
        raw = zf.open("report.xml", "r")
    except KeyError:
        zf.close()
        raise FileNotFoundError("report.xml not found inside UFDR")

    class _ZipMemberStream(io.BufferedReader):
        def close(self) -> None:
            try:
                super().close()
            finally:
                zf.close()

    return _ZipMemberStream(raw)
