from __future__ import annotations

from typing import Optional


def localname(tag: str) -> str:
    # '{ns}name' -> 'name'
    if tag is None:
        return ""
    if "}" in tag:
        return tag.rsplit("}", 1)[1]
    return tag


def attr(elem, name: str) -> Optional[str]:
    if elem is None:
        return None
    return elem.get(name)
