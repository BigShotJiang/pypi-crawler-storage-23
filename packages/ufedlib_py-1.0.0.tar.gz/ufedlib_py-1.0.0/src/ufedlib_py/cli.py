from __future__ import annotations

import argparse
import json
import sys
from typing import Any

from .models import (GenericModel,  # noqa: F401  (ensures registration)
                     KeyValueModel)
from .report import (parse_additional_fields, parse_additional_fields_to_json,
                     parse_all, parse_case_information,
                     parse_case_information_to_json, parse_data,
                     parse_device_info, parse_device_info_to_json_array,
                     parse_device_info_to_json_dictionary,
                     parse_extraction_data, parse_extraction_data_to_json,
                     parse_project_attributes, parse_project_infos,
                     scan_models)


def _cmd_scan(args: argparse.Namespace) -> int:
    types = scan_models(args.input)
    for t in types:
        print(t)
    return 0


def _cmd_parse(args: argparse.Namespace) -> int:
    items = parse_data(args.input, args.model, debug_attributes=args.debug_attributes)
    if args.json:
        print(
            json.dumps(
                [getattr(x, "to_dict", lambda: x.__dict__)() for x in items],
                ensure_ascii=False,
            )
        )
    else:
        print(f"{len(items)} item(s)")
    return 0


def _cmd_parse_all(args: argparse.Namespace) -> int:
    report = parse_all(
        args.input,
        debug_attributes=args.debug_attributes,
        include_unknown_models=args.include_unknown_models,
        model_types=args.model,
    )
    if args.json:
        print(json.dumps(report.to_dict(), ensure_ascii=False))
    else:
        total_models = len(report.Models)
        total_items = sum(len(v) for v in report.Models.values())
        print(f"{total_models} model type(s), {total_items} item(s)")
    return 0


def _cmd_metadata_project_infos(args: argparse.Namespace) -> int:
    info = parse_project_infos(args.input)
    print(json.dumps(getattr(info, "__dict__", {}), ensure_ascii=False, indent=2))
    return 0


def _cmd_metadata_project_attributes(args: argparse.Namespace) -> int:
    pa = parse_project_attributes(args.input)
    print(json.dumps(getattr(pa, "__dict__", {}), ensure_ascii=False, indent=2))
    return 0


def _cmd_metadata_additional_fields(args: argparse.Namespace) -> int:
    if args.json:
        print(parse_additional_fields_to_json(args.input))
    else:
        print(
            json.dumps(
                parse_additional_fields(args.input), ensure_ascii=False, indent=2
            )
        )
    return 0


def _cmd_metadata_case_information(args: argparse.Namespace) -> int:
    if args.json:
        print(parse_case_information_to_json(args.input))
    else:
        print(
            json.dumps(parse_case_information(args.input), ensure_ascii=False, indent=2)
        )
    return 0


def _cmd_metadata_extraction_data(args: argparse.Namespace) -> int:
    if args.json:
        print(parse_extraction_data_to_json(args.input))
    else:
        print(
            json.dumps(parse_extraction_data(args.input), ensure_ascii=False, indent=2)
        )
    return 0


def _cmd_metadata_device_info(args: argparse.Namespace) -> int:
    if args.format == "array":
        print(parse_device_info_to_json_array(args.input))
    elif args.format == "dict":
        print(parse_device_info_to_json_dictionary(args.input))
    else:
        print(
            json.dumps(
                parse_device_info(args.input) or [], ensure_ascii=False, indent=2
            )
        )
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="ufedlib-py")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_scan = sub.add_parser("scan", help="List model types present in a UFDR/XML")
    p_scan.add_argument("--input", required=True)
    p_scan.set_defaults(func=_cmd_scan)

    p_parse = sub.add_parser("parse", help="Parse a specific model type")
    p_parse.add_argument("--input", required=True)
    p_parse.add_argument(
        "--model", required=True, help="e.g. Contact, Call, KeyValueModel"
    )
    p_parse.add_argument("--json", action="store_true", help="Output JSON")
    p_parse.add_argument("--debug-attributes", action="store_true")
    p_parse.set_defaults(func=_cmd_parse)

    p_parse_all = sub.add_parser(
        "parse-all", help="Parse all supported models + metadata"
    )
    p_parse_all.add_argument("--input", required=True)
    p_parse_all.add_argument(
        "--model",
        action="append",
        help="Limit to model type(s); repeat for multiple",
    )
    p_parse_all.add_argument("--include-unknown-models", action="store_true")
    p_parse_all.add_argument("--json", action="store_true", help="Output JSON")
    p_parse_all.add_argument("--debug-attributes", action="store_true")
    p_parse_all.set_defaults(func=_cmd_parse_all)

    p_meta = sub.add_parser("metadata", help="Parse UFED metadata sections")
    meta_sub = p_meta.add_subparsers(dest="meta_cmd", required=True)

    p_pi = meta_sub.add_parser("project-infos")
    p_pi.add_argument("--input", required=True)
    p_pi.set_defaults(func=_cmd_metadata_project_infos)

    p_pa = meta_sub.add_parser("project-attributes")
    p_pa.add_argument("--input", required=True)
    p_pa.set_defaults(func=_cmd_metadata_project_attributes)

    p_af = meta_sub.add_parser("additional-fields")
    p_af.add_argument("--input", required=True)
    p_af.add_argument("--json", action="store_true")
    p_af.set_defaults(func=_cmd_metadata_additional_fields)

    p_ci = meta_sub.add_parser("case-information")
    p_ci.add_argument("--input", required=True)
    p_ci.add_argument("--json", action="store_true")
    p_ci.set_defaults(func=_cmd_metadata_case_information)

    p_ed = meta_sub.add_parser("extraction-data")
    p_ed.add_argument("--input", required=True)
    p_ed.add_argument("--json", action="store_true")
    p_ed.set_defaults(func=_cmd_metadata_extraction_data)

    p_di = meta_sub.add_parser("device-info")
    p_di.add_argument("--input", required=True)
    p_di.add_argument("--format", choices=["list", "array", "dict"], default="list")
    p_di.set_defaults(func=_cmd_metadata_device_info)

    ns = p.parse_args(argv)
    return int(ns.func(ns))


if __name__ == "__main__":
    raise SystemExit(main())
