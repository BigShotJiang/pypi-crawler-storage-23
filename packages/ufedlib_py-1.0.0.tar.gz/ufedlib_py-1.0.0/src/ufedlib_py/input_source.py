from __future__ import annotations

from typing import BinaryIO

from .ufdr import open_report_xml_from_ufdr


def open_report_stream(path: str) -> BinaryIO:
    if path.lower().endswith(".ufdr"):
        return open_report_xml_from_ufdr(path)
    if path.lower().endswith(".xml"):
        return open(path, "rb")
    raise ValueError(f"Unsupported file format: {path}")
