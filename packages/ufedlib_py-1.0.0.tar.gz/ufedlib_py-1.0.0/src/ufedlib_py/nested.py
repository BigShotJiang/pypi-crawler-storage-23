from __future__ import annotations

from typing import Any, Dict, List, Optional

from .parser import parse_model_element
from .registry import ModelRegistry, default_registry


def parse_model_elements(
    elements: List[Any],
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
) -> List[Any]:
    out: List[Any] = []
    for el in elements:
        obj = parse_model_element(
            el, registry=registry, debug_attributes=debug_attributes
        )
        if obj is not None:
            out.append(obj)
    return out


def parse_multi_model_fields(
    multi_model_fields: Dict[str, List[Any]],
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
) -> Dict[str, List[Any]]:
    return {
        k: parse_model_elements(v, registry=registry, debug_attributes=debug_attributes)
        for k, v in (multi_model_fields or {}).items()
    }
