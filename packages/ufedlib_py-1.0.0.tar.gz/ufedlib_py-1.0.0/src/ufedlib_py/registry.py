from __future__ import annotations

from dataclasses import dataclass
from typing import (Any, Callable, Dict, Generic, Iterable, List, Optional,
                    Protocol, Type, TypeVar)

from .model_base import ModelBase

T = TypeVar("T", bound=ModelBase)


class ModelParserProtocol(Protocol[T]):
    @classmethod
    def get_xml_model_type(cls) -> str: ...

    @classmethod
    def parse_from_parts(
        cls,
        *,
        attrs: Dict[str, Optional[str]],
        fields: Dict[str, str],
        model_fields: Dict[str, Any],
        multi_fields: Dict[str, List[str]],
        multi_model_fields: Dict[str, List[Any]],
        debug_attributes: bool = False,
    ) -> T: ...


@dataclass
class ModelRegistry:
    _by_type: Dict[str, Type[ModelParserProtocol[Any]]]
    _default: Optional[Type[ModelParserProtocol[Any]]]

    def __init__(self) -> None:
        self._by_type = {}
        self._default = None

    def register(
        self, model_cls: Type[ModelParserProtocol[T]]
    ) -> Type[ModelParserProtocol[T]]:
        model_type = model_cls.get_xml_model_type()
        self._by_type[model_type] = model_cls
        return model_cls

    def get(self, model_type: str) -> Optional[Type[ModelParserProtocol[Any]]]:
        return self._by_type.get(model_type) or self._default

    def set_default(self, model_cls: Type[ModelParserProtocol[Any]]) -> None:
        self._default = model_cls

    def supported_types(self) -> List[str]:
        return sorted(self._by_type.keys())


default_registry = ModelRegistry()
