from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping

from .xml_utils import localname


def _first_typed_model(element: Any) -> Any:
    for child in element.iter() if element is not None else []:
        if child is element:
            continue
        if localname(getattr(child, "tag", "")) == "model" and child.get("type"):
            return child
    return None


def _parse_model_element(element: Any, *, debug_attributes: bool = False) -> Any:
    from .parser import parse_model_element

    if element is None:
        return None
    if not element.get("type"):
        nested = _first_typed_model(element)
        if nested is not None:
            element = nested

    return parse_model_element(element, debug_attributes=debug_attributes)


def _parse_model_elements(
    elements: Iterable[Any], *, debug_attributes: bool = False
) -> List[Any]:
    out: List[Any] = []
    for el in elements or []:
        obj = _parse_model_element(el, debug_attributes=debug_attributes)
        if obj is not None:
            out.append(obj)
    return out


def _first_child_model(model_field_el: Any) -> Any:
    for child in list(model_field_el or []):
        if localname(getattr(child, "tag", "")) == "model":
            return child
    return None


def _parse_model_field(model_field_el: Any, *, debug_attributes: bool = False) -> Any:
    child = _first_child_model(model_field_el)
    if child is None:
        return None
    return _parse_model_element(child, debug_attributes=debug_attributes)


def _key_value_dict(
    elements: Iterable[Any], *, debug_attributes: bool = False
) -> Dict[str, str]:
    out: Dict[str, str] = {}
    for kv in _parse_model_elements(elements, debug_attributes=debug_attributes):
        key = getattr(kv, "Key", None) or getattr(kv, "key", None)
        value = getattr(kv, "Value", None) or getattr(kv, "value", None)
        if key and value:
            out[str(key)] = str(value)
    return out


def _discard_unknown(obj: Any, attr_name: str, handled_keys: Iterable[str]) -> None:
    store = getattr(obj, attr_name, None)
    if isinstance(store, dict):
        for key in handled_keys:
            store.pop(key, None)


def _apply_model_fields(
    obj: Any,
    model_fields: Mapping[str, Any],
    mapping: Mapping[str, str],
    *,
    debug_attributes: bool,
) -> None:
    handled: List[str] = []
    for field_name, attr_name in mapping.items():
        if field_name not in model_fields:
            continue
        parsed = _parse_model_field(
            model_fields.get(field_name), debug_attributes=debug_attributes
        )
        if parsed is not None:
            setattr(obj, attr_name, parsed)
        handled.append(field_name)
    _discard_unknown(obj, "_unknown_model_fields", handled)


def _apply_multi_fields(
    obj: Any,
    multi_fields: Mapping[str, List[str]],
    mapping: Mapping[str, str],
) -> None:
    handled: List[str] = []
    for field_name, attr_name in mapping.items():
        if field_name not in multi_fields:
            continue
        setattr(obj, attr_name, list(multi_fields.get(field_name) or []))
        handled.append(field_name)
    _discard_unknown(obj, "_unknown_multi_fields", handled)


def _apply_multi_model_fields_list(
    obj: Any,
    multi_model_fields: Mapping[str, List[Any]],
    mapping: Mapping[str, str],
    *,
    debug_attributes: bool,
) -> None:
    handled: List[str] = []
    for field_name, attr_name in mapping.items():
        if field_name not in multi_model_fields:
            continue
        parsed = _parse_model_elements(
            multi_model_fields.get(field_name) or [], debug_attributes=debug_attributes
        )
        setattr(obj, attr_name, parsed)
        handled.append(field_name)
    _discard_unknown(obj, "_unknown_multi_model_fields", handled)


def _apply_multi_model_fields_keyvalue(
    obj: Any,
    multi_model_fields: Mapping[str, List[Any]],
    mapping: Mapping[str, str],
    *,
    debug_attributes: bool,
) -> None:
    handled: List[str] = []
    for field_name, attr_name in mapping.items():
        if field_name not in multi_model_fields:
            continue
        setattr(
            obj,
            attr_name,
            _key_value_dict(
                multi_model_fields.get(field_name) or [],
                debug_attributes=debug_attributes,
            ),
        )
        handled.append(field_name)
    _discard_unknown(obj, "_unknown_multi_model_fields", handled)


def _apply_filtered_multi_model_fields(
    obj: Any,
    multi_model_fields: Mapping[str, List[Any]],
    field_name: str,
    attr_name: str,
    allowed_types: Iterable[str],
    *,
    debug_attributes: bool,
) -> None:
    if field_name not in multi_model_fields:
        return
    allowed = set(allowed_types)
    entries: List[Any] = []
    for el in multi_model_fields.get(field_name) or []:
        el_type = el.get("type")
        if el_type not in allowed:
            continue
        parsed = _parse_model_element(el, debug_attributes=debug_attributes)
        if parsed is not None:
            entries.append(parsed)
    setattr(obj, attr_name, entries)
    _discard_unknown(obj, "_unknown_multi_model_fields", [field_name])


MODEL_FIELDS_MAP: Dict[str, Dict[str, str]] = {
    "CellTower": {"Position": "Position"},
    "ChatActivity": {"Participant": "Participant"},
    "CreditCard": {"BillingAddress": "BillingAddress"},
    "FileUpload": {"Owner": "Owner"},
    "Journey": {"FromPoint": "FromPoint", "ToPoint": "ToPoint"},
    "Location": {"Address": "Address", "Position": "Position"},
    "MobileCard": {"Organization": "Organization"},
    "Notification": {"Position": "Position", "To": "To"},
    "Note": {"Address": "Address", "Position": "Position"},
    "PublicTransportationTicket": {
        "ArrivalAddress": "ArrivalAddress",
        "DepartureAddress": "DepartureAddress",
    },
    "SearchedItem": {"Position": "Position"},
    "SocialMediaActivity": {
        "Author": "Author",
        "ParentPost": "ParentPost",
        "Position": "Position",
    },
    "TransferOfFunds": {"Fee": "Fee", "TransferAmount": "TransferAmount"},
    "Voicemail": {"From": "From"},
    "WirelessNetwork": {"Position": "Position"},
}

MULTI_FIELDS_MAP: Dict[str, Dict[str, str]] = {
    "AppsUsageLog": {"AdditionalInfo": "AdditionalInfo"},
    "FileDownload": {"DownloadURLChains": "DownloadURLChains"},
    "InstalledApplication": {
        "AssociatedDirectoryPaths": "AssociatedDirectoryPaths",
        "Categories": "Categories",
        "Permissions": "Permissions",
    },
    "NetworkUsage": {"ApplicationId": "ApplicationId"},
    "Notification": {"Notes": "Notes"},
    "SearchedItem": {"SearchResults": "SearchResults"},
    "UserAccount": {"Notes": "Notes"},
}

MULTI_MODEL_FIELDS_LIST_MAP: Dict[str, Dict[str, str]] = {
    "ActivitySensorData": {"Measurements": "Measurements"},
    "ActivitySensorDataMeasurement": {"Samples": "Samples"},
    "Call": {"Parties": "Parties"},
    "CalendarEntry": {"Attachments": "Attachments", "Attendees": "Attendees"},
    "FileUpload": {"Participants": "Participants"},
    "FinancialAccount": {"Assets": "Assets"},
    "InstalledApplication": {"Users": "Users"},
    "Journey": {"WayPoints": "WayPoints"},
    "Note": {"Attachments": "Attachments", "Participants": "Participants"},
    "Notification": {"Attachments": "Attachments", "Participants": "Participants"},
    "PublicTransportationTicket": {"Passengers": "Passengers"},
    "SocialMediaActivity": {
        "Attachments": "Attachments",
        "TaggedParties": "TaggedParties",
    },
    "TransferOfFunds": {"Participants": "Participants"},
    "UserAccount": {
        "Addresses": "Addresses",
        "Organizations": "Organizations",
        "Photos": "Photos",
    },
}

MULTI_MODEL_FIELDS_KEYVALUE_MAP: Dict[str, Dict[str, str]] = {
    "DeviceConnectivity": {"DeviceIdentifiers": "DeviceIdentifiers"},
    "DeviceEvent": {"Additional_Info": "AdditionalInfo"},
    "FileDownload": {"AdditionalInfo": "AdditionalInfo"},
    "FileUpload": {"AdditionalInfo": "AdditionalInfo"},
    "MobileCard": {"AdditionalInfo": "AdditionalInfo"},
    "NetworkUsage": {"AdditionalInfo": "AdditionalInfo"},
    "RecognizedDevice": {
        "AdditionalInfo": "AdditionalInfo",
        "DeviceIdentifiers": "DeviceIdentifiers",
    },
    "User": {"AdditionalInfo": "AdditionalInfo"},
    "UserAccount": {"AdditionalInfo": "AdditionalInfo"},
}

USER_ACCOUNT_ENTRY_TYPES = {
    "UserID",
    "PhoneNumber",
    "EMailAddress",
    "WebAddress",
    "ContactEntry",
}


def apply_post_process(
    model_type: str,
    obj: Any,
    model_fields: Mapping[str, Any],
    multi_fields: Mapping[str, List[str]],
    multi_model_fields: Mapping[str, List[Any]],
    *,
    debug_attributes: bool = False,
) -> None:
    if not model_type or obj is None:
        return

    model_fields = model_fields or {}
    multi_fields = multi_fields or {}
    multi_model_fields = multi_model_fields or {}

    if model_type in MODEL_FIELDS_MAP:
        _apply_model_fields(
            obj,
            model_fields,
            MODEL_FIELDS_MAP[model_type],
            debug_attributes=debug_attributes,
        )

    if model_type in MULTI_FIELDS_MAP:
        _apply_multi_fields(obj, multi_fields, MULTI_FIELDS_MAP[model_type])

    if model_type in MULTI_MODEL_FIELDS_LIST_MAP:
        _apply_multi_model_fields_list(
            obj,
            multi_model_fields,
            MULTI_MODEL_FIELDS_LIST_MAP[model_type],
            debug_attributes=debug_attributes,
        )

    if model_type in MULTI_MODEL_FIELDS_KEYVALUE_MAP:
        _apply_multi_model_fields_keyvalue(
            obj,
            multi_model_fields,
            MULTI_MODEL_FIELDS_KEYVALUE_MAP[model_type],
            debug_attributes=debug_attributes,
        )

    if model_type == "UserAccount":
        _apply_filtered_multi_model_fields(
            obj,
            multi_model_fields,
            "Entries",
            "Entries",
            USER_ACCOUNT_ENTRY_TYPES,
            debug_attributes=debug_attributes,
        )
