from __future__ import annotations

import copy
import os
from typing import (Any, Callable, Dict, Iterator, List, Optional, Sequence,
                    Tuple, TypeVar)
from xml.etree.ElementTree import iterparse

from .logger import default_logger
from .post_process import apply_post_process
from .registry import ModelParserProtocol, ModelRegistry, default_registry
from .ufdr import open_report_xml_from_ufdr
from .xml_utils import localname

T = TypeVar("T")


def _iter_model_elements(stream) -> Iterator[Any]:
    # Streaming parse; yield only top-level <model> elements and clear them to keep memory low.
    #
    # UFED report.xml contains nested <model> elements inside <modelField> and <multiModelField>.
    # If we yield/clear *all* <model> elements, nested child models get cleared before their
    # parent <model> (e.g. Chat -> Messages -> InstantMessage) is parsed, resulting in empty
    # collections. We therefore track <model> depth and only yield depth==1 models.
    model_depth = 0
    context = iterparse(stream, events=("start", "end"))
    for event, elem in context:
        if localname(elem.tag) != "model":
            continue

        if event == "start":
            model_depth += 1
            continue

        # event == "end"
        if model_depth == 1:
            yield elem
            elem.clear()
        model_depth -= 1


def _iter_descendant_models(model_elem: Any) -> Iterator[Any]:
    # Yield nested <model> elements under a top-level <model> element.
    # We avoid yielding the root itself.
    for child in list(model_elem):
        if localname(getattr(child, "tag", "")) == "model":
            yield child
            yield from _iter_descendant_models(child)
        else:
            # Some UFED variants may nest <model> deeper under wrapper elements.
            yield from _iter_descendant_models(child)


def scan_models(path: str) -> List[str]:
    if path is None:
        raise ValueError("path is required")

    stream = None
    try:
        if path.lower().endswith(".ufdr"):
            stream = open_report_xml_from_ufdr(path)
        elif path.lower().endswith(".xml"):
            stream = open(path, "rb")
        else:
            raise ValueError(f"Unsupported file format: {path}")

        model_types: set[str] = set()
        for model_elem in _iter_model_elements(stream):
            mt = model_elem.get("type")
            if mt:
                model_types.add(mt)

            # Include nested model types (e.g., InstantMessage inside Chat.Messages)
            for sub in _iter_descendant_models(model_elem):
                smt = sub.get("type")
                if smt:
                    model_types.add(smt)
        return sorted(model_types)
    finally:
        if stream is not None:
            stream.close()


def parse_data_multi(
    path: str,
    model_types: Sequence[str],
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
    continue_on_error: bool = True,
    progress_callback: Optional[Callable[[str, int], None]] = None,
    progress_every: int = 0,
) -> Dict[str, List[Any]]:
    if path is None:
        raise ValueError("path is required")
    if not model_types:
        raise ValueError("model_types is required")

    targets = list(dict.fromkeys(model_types))
    targets_set = set(targets)
    model_cls_by_type: Dict[str, Optional[ModelParserProtocol[Any]]] = {
        model_type: registry.get(model_type) for model_type in targets_set
    }
    missing = [mt for mt, cls in model_cls_by_type.items() if cls is None]
    if missing:
        raise ValueError(
            f"Model type not registered: {missing}. Registered: {registry.supported_types()}"
        )

    results: Dict[str, List[Any]] = {mt: [] for mt in targets}
    counts: Dict[str, int] = {mt: 0 for mt in targets}

    def _report(model_type: str) -> None:
        if not progress_callback:
            return
        count = counts.get(model_type, 0)
        if progress_every <= 0:
            if count == 1:
                progress_callback(model_type, count)
            return
        if count == 1 or count % progress_every == 0:
            progress_callback(model_type, count)

    stream = None
    try:
        if path.lower().endswith(".ufdr"):
            stream = open_report_xml_from_ufdr(path)
        elif path.lower().endswith(".xml"):
            stream = open(path, "rb")
        else:
            raise ValueError(f"Unsupported file format: {path}")

        for model_elem in _iter_model_elements(stream):
            mt = model_elem.get("type")
            if mt in targets_set:
                try:
                    model_cls = model_cls_by_type.get(mt)
                    if model_cls is not None:
                        (
                            attrs,
                            fields_map,
                            model_fields,
                            multi_fields,
                            multi_model_fields,
                        ) = _collect_parts(model_elem)
                        obj = model_cls.parse_from_parts(
                            attrs=attrs,
                            fields=fields_map,
                            model_fields=model_fields,
                            multi_fields=multi_fields,
                            multi_model_fields=multi_model_fields,
                            debug_attributes=debug_attributes,
                        )
                        if obj is not None:
                            apply_post_process(
                                mt,
                                obj,
                                model_fields,
                                multi_fields,
                                multi_model_fields,
                                debug_attributes=debug_attributes,
                            )
                            results[mt].append(obj)
                            counts[mt] = counts.get(mt, 0) + 1
                            _report(mt)
                except Exception as exc:
                    if not continue_on_error:
                        raise
                    default_logger.error(f"{mt}: Error parsing model element: {exc}")

            for sub in _iter_descendant_models(model_elem):
                sub_type = sub.get("type")
                if not sub_type or sub_type == mt or sub_type not in targets_set:
                    continue
                try:
                    obj = parse_model_element(
                        sub, registry=registry, debug_attributes=debug_attributes
                    )
                    if obj is not None:
                        results[sub_type].append(obj)
                        counts[sub_type] = counts.get(sub_type, 0) + 1
                        _report(sub_type)
                except Exception as exc:
                    if not continue_on_error:
                        raise
                    default_logger.error(
                        f"{sub_type}: Error parsing nested model element: {exc}"
                    )

        return results
    finally:
        if stream is not None:
            stream.close()


def _collect_parts(
    model_elem: Any,
) -> Tuple[
    Dict[str, Optional[str]],
    Dict[str, str],
    Dict[str, Any],
    Dict[str, List[str]],
    Dict[str, List[Any]],
]:
    attrs: Dict[str, Optional[str]] = {
        "id": model_elem.get("id"),
        "type": model_elem.get("type"),
        "deleted_state": model_elem.get("deleted_state"),
        "decoding_confidence": model_elem.get("decoding_confidence"),
        "isrelated": model_elem.get("isrelated"),
        "source_index": model_elem.get("source_index"),
        "extractionId": model_elem.get("extractionId"),
    }

    fields_map: Dict[str, str] = {}
    model_fields: Dict[str, Any] = {}
    multi_fields: Dict[str, List[str]] = {}
    multi_model_fields: Dict[str, List[Any]] = {}

    for child in list(model_elem):
        tag = localname(child.tag)

        # UFED XML appears in at least two shapes:
        # - Attribute-based: <field name="X" ...>
        # - Element-based:   <field><name>X</name><value>...</value></field>
        name = child.get("name")
        if not name:
            for sub in list(child):
                if localname(getattr(sub, "tag", "")) == "name":
                    name = (sub.text or "").strip()
                    break
        if not name:
            continue

        if tag == "field":
            # UFED often stores scalar values as nested text, e.g.
            #   <field name="X"><value>...</value></field>
            # so child.text is frequently empty/whitespace.
            value = (child.text or "").strip()
            if not value:
                # Prefer explicit <value> element if present.
                sub_elems = list(child)
                for sub in sub_elems:
                    if localname(getattr(sub, "tag", "")) == "value":
                        value = (sub.text or "").strip()
                        break
                # Fallback: first sub-element with text.
                if not value and sub_elems:
                    value = (sub_elems[0].text or "").strip()
            fields_map[name] = value
        elif tag == "modelField":
            # Keep raw element for now (model-by-model ports can decide how to parse)
            # Deep-copy because the parent element will be cleared after parsing.
            model_fields[name] = copy.deepcopy(child)
        elif tag == "multiField":
            # UFED multiField usually contains nested <field> elements.
            values: List[str] = []
            for sub in list(child):
                if localname(sub.tag) == "field":
                    values.append((sub.text or "").strip())
            # Fallback: if no nested fields, keep direct text.
            if not values:
                txt = (child.text or "").strip()
                if txt:
                    values.append(txt)
            multi_fields[name] = values
        elif tag == "multiModelField":
            # UFED multiModelField usually contains nested <model> elements.
            models: List[Any] = []
            for sub in list(child):
                if localname(sub.tag) == "model":
                    # The parent element will be cleared after parsing, so deep-copy.
                    models.append(copy.deepcopy(sub))
            multi_model_fields[name] = models

    return attrs, fields_map, model_fields, multi_fields, multi_model_fields


def parse_model_element(
    model_elem: Any,
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
) -> Any:
    """Parse a single <model> Element into a typed object via registry.

    This is used for nested parsing (multiModelField child models).
    """

    model_type = model_elem.get("type")
    if not model_type:
        return None

    model_cls = registry.get(model_type)
    if model_cls is None:
        return None

    attrs, fields_map, model_fields, multi_fields, multi_model_fields = _collect_parts(
        model_elem
    )
    obj = model_cls.parse_from_parts(
        attrs=attrs,
        fields=fields_map,
        model_fields=model_fields,
        multi_fields=multi_fields,
        multi_model_fields=multi_model_fields,
        debug_attributes=debug_attributes,
    )
    if obj is not None:
        apply_post_process(
            model_type,
            obj,
            model_fields,
            multi_fields,
            multi_model_fields,
            debug_attributes=debug_attributes,
        )
    return obj


def parse_data(
    path: str,
    model_type: str,
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
) -> List[Any]:
    if path is None:
        raise ValueError("path is required")
    if not model_type:
        raise ValueError("model_type is required")

    model_cls = registry.get(model_type)
    if model_cls is None:
        raise ValueError(
            f"Model type not registered: {model_type}. Registered: {registry.supported_types()}"
        )

    stream = None
    results: List[Any] = []
    try:
        if path.lower().endswith(".ufdr"):
            stream = open_report_xml_from_ufdr(path)
        elif path.lower().endswith(".xml"):
            stream = open(path, "rb")
        else:
            raise ValueError(f"Unsupported file format: {path}")

        for model_elem in _iter_model_elements(stream):
            mt = model_elem.get("type")

            # 1) If the top-level model matches, parse it.
            if mt == model_type:
                attrs, fields_map, model_fields, multi_fields, multi_model_fields = (
                    _collect_parts(model_elem)
                )
                obj = model_cls.parse_from_parts(
                    attrs=attrs,
                    fields=fields_map,
                    model_fields=model_fields,
                    multi_fields=multi_fields,
                    multi_model_fields=multi_model_fields,
                    debug_attributes=debug_attributes,
                )
                if obj is not None:
                    apply_post_process(
                        model_type,
                        obj,
                        model_fields,
                        multi_fields,
                        multi_model_fields,
                        debug_attributes=debug_attributes,
                    )
                    results.append(obj)
                continue

            # 2) Otherwise, also search nested models of the requested type.
            for sub in _iter_descendant_models(model_elem):
                if sub.get("type") != model_type:
                    continue
                results.append(
                    parse_model_element(
                        sub, registry=registry, debug_attributes=debug_attributes
                    )
                )

        return results
    finally:
        if stream is not None:
            stream.close()
