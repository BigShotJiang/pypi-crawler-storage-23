from __future__ import annotations

from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple

from .logger import default_logger
from .metadata.additional_fields import \
    parse_additional_fields as _parse_additional_fields
from .metadata.additional_fields import \
    parse_additional_fields_to_json as _parse_additional_fields_to_json
from .metadata.case_information import \
    parse_case_information as _parse_case_information
from .metadata.case_information import \
    parse_case_information_to_json as _parse_case_information_to_json
from .metadata.device_info import parse_device_info as _parse_device_info
from .metadata.device_info import \
    parse_device_info_to_json_array as _parse_device_info_to_json_array
from .metadata.device_info import \
    parse_device_info_to_json_dict as _parse_device_info_to_json_dict
from .metadata.extraction_data import \
    parse_extraction_data as _parse_extraction_data
from .metadata.extraction_data import \
    parse_extraction_data_to_json as _parse_extraction_data_to_json
from .metadata.project_attributes import ProjectAttributes
from .metadata.project_attributes import \
    parse_project_attributes as _parse_project_attributes
from .metadata.project_infos import ProjectInfos
from .metadata.project_infos import parse_project_infos as _parse_project_infos
from .parser import parse_data as _parse_data
from .parser import parse_data_multi as _parse_data_multi
from .parser import scan_models as _scan_models
from .registry import ModelRegistry, default_registry

SUPPORTED_MODELS: List[str] = [
    "ActivitySensorData",
    "ApplicationUsage",
    "AppsUsageLog",
    "Autofill",
    "CalendarEntry",
    "Call",
    "CellTower",
    "Chat",
    "Contact",
    "Cookie",
    "CreditCard",
    "DeviceConnectivity",
    "DeviceEvent",
    "DeviceInfoEntry",
    "DictionaryWord",
    "Email",
    "FileDownload",
    "FileUpload",
    "FinancialAccount",
    "InstalledApplication",
    "InstantMessage",
    "Journey",
    "Location",
    "LogEntry",
    "MobileCard",
    "NetworkUsage",
    "Note",
    "Notification",
    "Password",
    "PoweringEvent",
    "PublicTransportationTicket",
    "RecognizedDevice",
    "Recording",
    "SearchedItem",
    "SIMData",
    "SocialMediaActivity",
    "TransferOfFunds",
    "User",
    "UserAccount",
    "VisitedPage",
    "Voicemail",
    "WebBookmark",
    "WirelessNetwork",
]

MODEL_ATTR_MAP: Dict[str, str] = {
    "ActivitySensorData": "ActivitySensorData",
    "ApplicationUsage": "ApplicationUsages",
    "AppsUsageLog": "AppsUsageLogs",
    "Autofill": "Autofills",
    "CalendarEntry": "CalendarEntries",
    "Call": "Calls",
    "CellTower": "CellTowers",
    "Chat": "Chats",
    "Contact": "Contacts",
    "Cookie": "Cookies",
    "CreditCard": "CreditCards",
    "DeviceConnectivity": "DeviceConnectivities",
    "DeviceEvent": "DeviceEvents",
    "DeviceInfoEntry": "DeviceInfoEntries",
    "DictionaryWord": "DictionaryWords",
    "Email": "Emails",
    "FileDownload": "FileDownloads",
    "FileUpload": "FileUploads",
    "FinancialAccount": "FinancialAccounts",
    "InstalledApplication": "InstalledApplications",
    "InstantMessage": "InstantMessages",
    "Journey": "Journeys",
    "Location": "Locations",
    "LogEntry": "LogEntries",
    "MobileCard": "MobileCards",
    "NetworkUsage": "NetworkUsages",
    "Note": "Notes",
    "Notification": "Notifications",
    "Password": "Passwords",
    "PoweringEvent": "PoweringEvents",
    "PublicTransportationTicket": "PublicTransportationTickets",
    "RecognizedDevice": "RecognizedDevices",
    "Recording": "Recordings",
    "SearchedItem": "SearchedItems",
    "SIMData": "SIMData",
    "SocialMediaActivity": "SocialMediaActivities",
    "TransferOfFunds": "TransferOfFunds",
    "User": "Users",
    "UserAccount": "UserAccounts",
    "VisitedPage": "VisitedPages",
    "Voicemail": "Voicemails",
    "WebBookmark": "WebBookmarks",
    "WirelessNetwork": "WirelessNetworks",
}


@dataclass
class ReportData:
    # Metadata
    CaseInformation: List[Tuple[str, str]] = field(default_factory=list)
    DeviceInfo: List[Tuple[str, str]] = field(default_factory=list)
    ExtractionData: List[Tuple[str, str]] = field(default_factory=list)
    AdditionalFields: List[Tuple[str, str]] = field(default_factory=list)
    ProjectAttributes: Optional[ProjectAttributes] = None
    ProjectInfos: Optional[ProjectInfos] = None

    # Model collections
    ActivitySensorData: List[Any] = field(default_factory=list)
    ApplicationUsages: List[Any] = field(default_factory=list)
    AppsUsageLogs: List[Any] = field(default_factory=list)
    Autofills: List[Any] = field(default_factory=list)
    CalendarEntries: List[Any] = field(default_factory=list)
    Calls: List[Any] = field(default_factory=list)
    CellTowers: List[Any] = field(default_factory=list)
    Chats: List[Any] = field(default_factory=list)
    Contacts: List[Any] = field(default_factory=list)
    Cookies: List[Any] = field(default_factory=list)
    CreditCards: List[Any] = field(default_factory=list)
    DeviceConnectivities: List[Any] = field(default_factory=list)
    DeviceEvents: List[Any] = field(default_factory=list)
    DeviceInfoEntries: List[Any] = field(default_factory=list)
    DictionaryWords: List[Any] = field(default_factory=list)
    Emails: List[Any] = field(default_factory=list)
    FileDownloads: List[Any] = field(default_factory=list)
    FileUploads: List[Any] = field(default_factory=list)
    FinancialAccounts: List[Any] = field(default_factory=list)
    InstalledApplications: List[Any] = field(default_factory=list)
    InstantMessages: List[Any] = field(default_factory=list)
    Journeys: List[Any] = field(default_factory=list)
    Locations: List[Any] = field(default_factory=list)
    LogEntries: List[Any] = field(default_factory=list)
    MobileCards: List[Any] = field(default_factory=list)
    NetworkUsages: List[Any] = field(default_factory=list)
    Notes: List[Any] = field(default_factory=list)
    Notifications: List[Any] = field(default_factory=list)
    Passwords: List[Any] = field(default_factory=list)
    PoweringEvents: List[Any] = field(default_factory=list)
    PublicTransportationTickets: List[Any] = field(default_factory=list)
    RecognizedDevices: List[Any] = field(default_factory=list)
    Recordings: List[Any] = field(default_factory=list)
    SearchedItems: List[Any] = field(default_factory=list)
    SIMData: List[Any] = field(default_factory=list)
    SocialMediaActivities: List[Any] = field(default_factory=list)
    TransferOfFunds: List[Any] = field(default_factory=list)
    Users: List[Any] = field(default_factory=list)
    UserAccounts: List[Any] = field(default_factory=list)
    VisitedPages: List[Any] = field(default_factory=list)
    Voicemails: List[Any] = field(default_factory=list)
    WebBookmarks: List[Any] = field(default_factory=list)
    WirelessNetworks: List[Any] = field(default_factory=list)

    Models: Dict[str, List[Any]] = field(default_factory=dict, repr=False)

    def get_models(self, model_type: str) -> List[Any]:
        if model_type in self.Models:
            return self.Models[model_type]
        attr = MODEL_ATTR_MAP.get(model_type)
        if attr and hasattr(self, attr):
            return getattr(self, attr)
        return []

    def to_dict(self) -> Dict[str, Any]:
        def _coerce(value: Any) -> Any:
            if hasattr(value, "to_dict") and callable(getattr(value, "to_dict")):
                return value.to_dict()
            if is_dataclass(value):
                return asdict(value)
            if isinstance(value, list):
                return [_coerce(v) for v in value]
            if isinstance(value, dict):
                return {k: _coerce(v) for k, v in value.items()}
            return value

        return {
            name: _coerce(getattr(self, name)) for name in self.__dataclass_fields__
        }


def scan_models(path: str) -> List[str]:
    # Ensure generated models + overrides are registered.
    # This import is intentionally here for side effects.
    from . import models  # noqa: F401

    return _scan_models(path)


def parse_data(
    path: str,
    model_type: str,
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
) -> List[Any]:
    # Ensure generated models + overrides are registered.
    # This import is intentionally here for side effects.
    from . import models  # noqa: F401

    return _parse_data(
        path, model_type, registry=registry, debug_attributes=debug_attributes
    )


def get_supported_models() -> List[str]:
    return list(SUPPORTED_MODELS)


def get_unsupported_models(path: str) -> List[str]:
    found = scan_models(path)
    return [model for model in found if model not in SUPPORTED_MODELS]


def parse_all(
    path: str,
    *,
    registry: ModelRegistry = default_registry,
    debug_attributes: bool = False,
    model_types: Optional[Sequence[str]] = None,
    include_unknown_models: bool = False,
    continue_on_error: bool = True,
    progress_callback: Optional[Callable[[str, int], None]] = None,
    progress_every: int = 0,
) -> ReportData:
    """Parse all metadata and supported models (C# Report.ParseAll parity)."""
    # Ensure generated models + overrides are registered.
    from . import models  # noqa: F401

    report = ReportData()

    def _safe(call, default):
        try:
            return call()
        except Exception as exc:
            default_logger.error(f"parse_all: {exc}")
            if not continue_on_error:
                raise
            return default

    report.CaseInformation = _safe(lambda: _parse_case_information(path), [])
    report.DeviceInfo = _safe(lambda: (_parse_device_info(path) or []), [])
    report.ExtractionData = _safe(lambda: _parse_extraction_data(path), [])
    report.AdditionalFields = _safe(lambda: _parse_additional_fields(path), [])
    report.ProjectAttributes = _safe(lambda: _parse_project_attributes(path), None)
    report.ProjectInfos = _safe(lambda: _parse_project_infos(path), None)

    targets = list(model_types) if model_types else list(SUPPORTED_MODELS)
    if include_unknown_models:
        for model in scan_models(path):
            if model not in targets:
                targets.append(model)

    parsed_models = _safe(
        lambda: _parse_data_multi(
            path,
            targets,
            registry=registry,
            debug_attributes=debug_attributes,
            continue_on_error=continue_on_error,
            progress_callback=progress_callback,
            progress_every=progress_every,
        ),
        {},
    )
    for model_type in targets:
        items = parsed_models.get(model_type, [])
        report.Models[model_type] = items
        attr = MODEL_ATTR_MAP.get(model_type)
        if attr and hasattr(report, attr):
            setattr(report, attr, items)

    return report


def parse_project_attributes(path: str):
    return _parse_project_attributes(path)


def parse_additional_fields(path: str):
    return _parse_additional_fields(path)


def parse_additional_fields_to_json(path: str) -> str:
    return _parse_additional_fields_to_json(path)


def parse_case_information(path: str):
    return _parse_case_information(path)


def parse_case_information_to_json(path: str) -> str:
    return _parse_case_information_to_json(path)


def parse_extraction_data(path: str):
    return _parse_extraction_data(path)


def parse_extraction_data_to_json(path: str) -> str:
    return _parse_extraction_data_to_json(path)


def parse_project_infos(path: str):
    return _parse_project_infos(path)


def parse_device_info(path: str):
    return _parse_device_info(path)


def parse_device_info_to_json_array(path: str) -> str:
    return _parse_device_info_to_json_array(path)


def parse_device_info_to_json_dictionary(path: str) -> str:
    return _parse_device_info_to_json_dict(path)
