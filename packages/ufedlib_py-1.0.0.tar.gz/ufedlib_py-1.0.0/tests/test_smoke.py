def test_import():
    import ufedlib_py  # noqa: F401
