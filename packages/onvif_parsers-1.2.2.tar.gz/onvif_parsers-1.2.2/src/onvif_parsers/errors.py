class UnknownTopicError(Exception):
    """Raised when an unknown topic is encountered in an ONVIF event notification."""
