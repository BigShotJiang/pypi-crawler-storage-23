Package API
===========

.. autosummary::
   :toctree: _autosummary
   :recursive:

   ilamb3.analysis
   ilamb3.compare
   ilamb3.dataset
   ilamb3.models
   ilamb3.regions
