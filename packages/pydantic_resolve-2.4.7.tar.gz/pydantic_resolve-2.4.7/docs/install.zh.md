# 安装

```shell
# latest v1
pip install pydantic-resolve==1.13.5

# v2
pip install pydantic-resolve
```

v1 版本从 v1.11.0 开始， 同时支持 Pydantic v1 和 v2

v2 版本开始， 只支持 v2, 并且移除了对 dataclass 的支持， 其他特性都向前兼容。