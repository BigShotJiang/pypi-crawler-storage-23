from .base import BaseEntity

__all__ = ['BaseEntity']
