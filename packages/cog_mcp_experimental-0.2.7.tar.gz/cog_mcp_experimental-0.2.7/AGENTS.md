# AGENTS.md

## Setup

```bash
uv sync --dev
```

## Verify changes

Run lint + tests before considering any change complete (same gate as CI):

```bash
uv run ruff check src/ tests/ && uv run ruff format --check src/ tests/ && uv run pytest
```

## Auto-fix lint/format

```bash
uv run ruff check --fix src/ tests/ && uv run ruff format src/ tests/
```

## Tests

```bash
uv run pytest
```

85% branch coverage minimum (`--cov-fail-under=85`, configured in `pyproject.toml`).

Run a subset of tests:

```bash
uv run pytest -k "<expression>"
```

## Code style

- Ruff for linting and formatting (`line-length = 100`, double quotes)
- Target Python 3.10+
- Lint rules: E, F, I, N, W, UP, B, SIM (configured in `pyproject.toml`)

## Project layout

- Source: `src/cog_mcp/`
- Tests: `tests/`

## CI

Lint and test jobs run on PRs and pushes to `main` (`.github/workflows/tests.yml`).
