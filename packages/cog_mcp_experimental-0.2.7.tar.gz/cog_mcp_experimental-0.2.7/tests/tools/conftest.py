import pytest


class DumpList:
    """SDK-like query result with .dump() and optional cursor."""

    def __init__(self, data: list[dict], cursor: str | None = None) -> None:
        self._data = data
        self.cursor = cursor

    def dump(self, camel_case: bool = True) -> list[dict]:  # noqa: ARG002
        return self._data


VIEW_ARGS: dict[str, str] = {
    "view_space": "my-space",
    "view_external_id": "MyView",
    "view_version": "v1",
}


@pytest.fixture
def view_args() -> dict[str, str]:
    """Standard view coordinate arguments shared across tool tests."""
    return dict(VIEW_ARGS)


@pytest.fixture
def make_dump_list() -> type[DumpList]:
    """Factory for SDK-like query results with .dump() and optional cursor."""
    return DumpList
