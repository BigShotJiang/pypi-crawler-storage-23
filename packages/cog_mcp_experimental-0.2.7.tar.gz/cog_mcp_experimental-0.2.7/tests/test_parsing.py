import pytest
from cognite.client.data_classes.data_modeling.ids import EdgeId, NodeId

from cog_mcp.parsing import (
    parse_edge_id,
    parse_json_param,
    parse_node_id,
    parse_node_ids,
    parse_through,
)


def test_parse_json_param_handles_none_strings_and_passthrough_values() -> None:
    assert parse_json_param(None) is None
    assert parse_json_param({"a": 1}) == {"a": 1}
    assert parse_json_param(["a"]) == ["a"]
    assert parse_json_param('{"k": "v"}') == {"k": "v"}


def test_parse_node_id_accepts_nodeid_and_both_external_id_key_styles() -> None:
    existing = NodeId(space="s", external_id="n1")
    from_camel = parse_node_id({"space": "s", "externalId": "n2"}, "field")
    from_snake = parse_node_id({"space": "s", "external_id": "n3"}, "field")

    assert parse_node_id(existing, "field") is existing
    assert from_camel.space == "s" and from_camel.external_id == "n2"
    assert from_snake.space == "s" and from_snake.external_id == "n3"


@pytest.mark.parametrize(
    "value",
    [
        "not-an-object",
        {"space": "", "externalId": "x"},
        {"space": "s", "externalId": ""},
        {"space": "s"},
    ],
)
def test_parse_node_id_rejects_invalid_inputs(value: object) -> None:
    with pytest.raises(ValueError):
        parse_node_id(value, "instance_id")


def test_parse_edge_id_accepts_edgeid_and_both_key_styles() -> None:
    existing = EdgeId(space="s", external_id="e1")
    from_camel = parse_edge_id({"space": "s", "externalId": "e2"}, "field")
    from_snake = parse_edge_id({"space": "s", "external_id": "e3"}, "field")

    assert parse_edge_id(existing, "field") is existing
    assert from_camel.space == "s" and from_camel.external_id == "e2"
    assert from_snake.space == "s" and from_snake.external_id == "e3"


def test_parse_node_ids_normalizes_single_object_and_limits_size() -> None:
    single = parse_node_ids({"space": "docs", "externalId": "doc-1"})
    assert len(single) == 1
    assert single[0].space == "docs"
    assert single[0].external_id == "doc-1"

    too_many = [{"space": "docs", "externalId": f"doc-{idx}"} for idx in range(3)]
    with pytest.raises(ValueError, match="maximum of 2"):
        parse_node_ids(too_many, max_items=2)


def test_parse_node_ids_requires_non_empty_list() -> None:
    with pytest.raises(ValueError, match="non-empty list"):
        parse_node_ids([])


def test_parse_through_infers_source_type_for_view_and_container() -> None:
    view_through = parse_through(
        {"source": {"space": "s", "externalId": "View", "version": "v1"}, "identifier": "asset"}
    )
    container_through = parse_through(
        {"source": {"space": "s", "externalId": "Container"}, "identifier": "asset"}
    )

    assert view_through is not None
    assert view_through.dump(camel_case=True)["source"]["type"] == "view"
    assert container_through is not None
    assert container_through.dump(camel_case=True)["source"]["type"] == "container"
    assert parse_through(None) is None
