from cognite.client import CogniteClient
from mcp.server.fastmcp import FastMCP

from cog_mcp.config import Config
from cog_mcp.tools.discovery import register_discovery_tools
from cog_mcp.tools.documents import register_document_tools
from cog_mcp.tools.instances import register_instance_tools
from cog_mcp.tools.query import register_query_tools


def register_tools(mcp: FastMCP, client: CogniteClient, config: Config) -> None:
    """Register all MCP tools on the FastMCP server."""
    register_discovery_tools(mcp, client, config)
    register_instance_tools(mcp, client, config)
    register_query_tools(mcp, client, config)
    register_document_tools(mcp, client, config)
