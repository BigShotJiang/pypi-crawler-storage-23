from cognite.client import CogniteClient
from mcp.server.fastmcp import FastMCP

from cog_mcp.config import Config
from cog_mcp.resources import FILTER_DOCS, QUERY_DOCS, fetch_view_schema, fetch_views


def register_discovery_tools(mcp: FastMCP, client: CogniteClient, config: Config) -> None:
    """Register schema/documentation discovery tools."""

    @mcp.tool()
    def list_views() -> str:
        """List all available views with their space, externalId, and version.

        Call this first to discover valid view coordinates before using
        list_instances, search_instances, or other tools.
        """
        return fetch_views(client, config)

    @mcp.tool()
    def get_view_schema(
        view_space: str,
        view_external_id: str,
        view_version: str,
    ) -> str:
        """Get the full schema of a view including all property names, types, and relations.

        Call this before filtering, sorting, or aggregating to get correct property
        names and relation targets. Get the space, externalId, and version from list_views.
        """
        return fetch_view_schema(client, view_space, view_external_id, view_version)

    @mcp.tool()
    def get_filter_docs() -> str:
        """Get reference documentation for CDF instance filter syntax.

        Call this when you need to construct filter expressions for
        list_instances, search_instances, or aggregate_instances.
        """
        return FILTER_DOCS

    @mcp.tool()
    def get_query_docs() -> str:
        """Get reference documentation for the CDF graph query API.

        Call this when you need to construct queries for the
        query_instances tool, including traversals and multi-result-set queries.
        """
        return QUERY_DOCS
