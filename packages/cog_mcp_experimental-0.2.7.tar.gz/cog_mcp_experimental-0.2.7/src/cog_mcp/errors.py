import json


def error_response(message: str) -> str:
    """Return a consistent JSON error payload."""
    return json.dumps({"error": message}, indent=2)
