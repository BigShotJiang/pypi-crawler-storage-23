from .syndata import SynData
