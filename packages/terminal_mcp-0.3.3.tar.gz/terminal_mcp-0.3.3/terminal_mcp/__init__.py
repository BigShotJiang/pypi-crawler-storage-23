"""terminal-mcp: MCP server for interactive terminal sessions."""

__version__ = "0.3.3"
