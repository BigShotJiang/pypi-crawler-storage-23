from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from typing import Union


class BlackAndWhiteNodeProcessor(_NodeProcessor):
    """
    The node to modify the input provided and set
    it as black and white by using CPU or GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.processor.black_and_white import BlackAndWhiteNodeProcessorCPU
        from yta_editor_nodes_gpu.processor.black_and_white import BlackAndWhiteNodeProcessorGPU

        node_cpu = BlackAndWhiteNodeProcessorCPU()
        node_gpu = BlackAndWhiteNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu

    def process(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        do_use_gpu: bool = True,
        # This is to accept 't' even when unneeded
        **kwargs
    ) -> Union['np.ndarray', 'moderngl.Texture']:
        """
        Process the provided `input` with GPU or CPU 
        according to the internal flag.
        """
        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size,
            do_use_gpu = do_use_gpu
        )