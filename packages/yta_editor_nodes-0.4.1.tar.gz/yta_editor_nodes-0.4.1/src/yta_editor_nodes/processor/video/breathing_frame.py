from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from typing import Union


class BreathingFrameVideoNodeProcessor(_VideoNodeProcessor):
    """
    The frame but as if it was breathing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []

    def __init__(
        self,
        opengl_context: 'moderngl.Context'
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_gpu.processor.video.breathing_frame import BreathingFrameVideoNodeProcessorGPU

        node_cpu = None
        node_gpu = BreathingFrameVideoNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu
    
    def process(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None],
        do_use_gpu: bool = True,
        zoom: float = 0.05
    ) -> Union['np.ndarray', 'moderngl.Texture']:
        """
        Process the provided `inputs` with GPU or CPU 
        according to the internal flag.
        """
        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size,
            do_use_gpu = do_use_gpu,
            zoom = zoom
        )