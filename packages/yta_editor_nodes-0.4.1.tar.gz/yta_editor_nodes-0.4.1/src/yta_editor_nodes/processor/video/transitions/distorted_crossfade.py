from yta_editor_nodes.processor.video.transitions.base import _TransitionProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from typing import Union


class DistortedCrossfadeTransitionProcessor(_TransitionProcessor):
    """
    A transition between the frames of 2 videos,
    transforming the first one into the second one
    with a distortion in between.

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU.

    Mandatory inputs:
    - `first_input`
    - `second_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['first_input', 'second_input']
    optional_inputs = []

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU processors and return 
        them in that order.
        """
        from yta_editor_nodes_gpu.processor.video.transitions.distorted_crossfade import DistortedCrossfadeTransitionNodeProcessorGPU

        node_cpu = None
        node_gpu = DistortedCrossfadeTransitionNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu
    
    def process(
        self,
        inputs: dict[str, Union['moderngl.Texture', 'np.ndarray']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None],
        do_use_gpu: bool = True,
        intensity: float = 1.0
    ) -> Union['moderngl.Texture', 'np.ndarray']:
        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size,
            do_use_gpu = do_use_gpu,
            intensity = intensity
        )