from yta_editor_nodes.processor.base import _NodeProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from yta_editor_nodes.utils import get_input_size
from typing import Union
from abc import ABC


# TODO: ABC, do we need it (?)
class _VideoNodeProcessor(_NodeProcessor, ABC):
    """
    *For internal use only*
    
    *Abstract class*

    This class must be inherited by the specific
    implementation of some effect that will be done by
    CPU or GPU (at least one of the options).

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU, but for 
    video frames, including a `t` time moment parameter
    when processing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []

    def process(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None],
        do_use_gpu: bool = True,
        **kwargs
    ) -> Union['np.ndarray', 'moderngl.Texture']:
        """
        Process the provided 'input' with GPU or CPU 
        according to the internal flag.
        """
        self._validate_inputs(inputs)

        base_input = inputs['base_input']

        output_size = (
            get_input_size(base_input)
            if output_size is None else
            output_size
        )

        processor = self._get_processor(
            do_use_gpu = do_use_gpu
        )

        return processor.process(
            inputs = {
                'base_input': self._prepare_input(
                    input = base_input,
                    do_use_gpu = do_use_gpu
                ),
            },
            evaluation_context = evaluation_context,
            output_size = output_size,
            **kwargs
        )