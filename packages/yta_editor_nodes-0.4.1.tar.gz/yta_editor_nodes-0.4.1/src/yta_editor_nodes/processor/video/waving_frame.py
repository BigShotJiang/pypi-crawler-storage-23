from yta_editor_nodes.processor.video.base import _VideoNodeProcessor
from yta_editor_time.evaluation_context import EvaluationContext
from typing import Union


class WavingFrameVideoNodeProcessor(_VideoNodeProcessor):
    """
    The frame but as if it is moving like a wave.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []

    def __init__(
        self,
        opengl_context: 'moderngl.Context'
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.processor.video.waving_frame import WavingFrameVideoNodeProcessorCPU
        from yta_editor_nodes_gpu.processor.video.waving_frame import WavingFrameVideoNodeProcessorGPU

        node_cpu = WavingFrameVideoNodeProcessorCPU()
        node_gpu = WavingFrameVideoNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu
    
    def process(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None],
        do_use_gpu: bool = True,
        amplitude: float = 0.05,
        frequency: float = 10.0,
        speed: float = 2.0,
        do_use_transparent_pixels: bool = False
    ) -> Union['np.ndarray', 'moderngl.Texture']:
        """
        Process the provided `inputs` with GPU or CPU 
        according to the internal flag.
        """
        return super().process(
            inputs = inputs,
            evaluation_context = evaluation_context,
            output_size = output_size,
            do_use_gpu = do_use_gpu,
            amplitude = amplitude,
            frequency = frequency,
            speed = speed,
            do_use_transparent_pixels = do_use_transparent_pixels
        )