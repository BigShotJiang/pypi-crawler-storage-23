from yta_editor_nodes.processor.base import _ProcessorGPUAndCPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_editor_nodes.utils import get_input_size
from typing import Union
from abc import abstractmethod


class _NodeCompositor(_ProcessorGPUAndCPU):
    """
    *For internal use only*

    This class must be inherited by the specific
    implementation of some node that will be positioning
    inputs, done by CPU or GPU (at least one of the
    options)

    A node specifically designed to build a scene by
    positioning inputs in different positions and 
    obtaining a single output by using GPU or CPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None],
        **kwargs
    ):
        node_compositor_cpu, node_compositor_gpu = self._instantiate_cpu_and_gpu_processors(
            opengl_context = opengl_context,
            **kwargs
        )

        super().__init__(
            processor_cpu = node_compositor_cpu,
            processor_gpu = node_compositor_gpu,
            opengl_context = opengl_context
        )

    @abstractmethod
    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None],
        **kwargs
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        pass

    # TODO: Maybe @abstractmethod cause' they are different
    def process(
        self,
        inputs: dict[str, Union['np.ndarray', 'moderngl.Texture']],
        evaluation_context: EvaluationContext,
        output_size: Union[tuple[int, int], None] = None,
        do_use_gpu: bool = True,
        **kwargs
    ) -> Union['np.ndarray', 'moderngl.Texture']:
        """
        Process the provided `input` with GPU or CPU 
        according to the `do_use_gpu` flag provided.
        """
        base_input = inputs['base_input']

        output_size = (
            get_input_size(base_input)
            if output_size is None else
            output_size
        )

        processor = self._get_processor(
            do_use_gpu = do_use_gpu
        )

        return processor.process(
            input = self._prepare_input(
                input = input,
                do_use_gpu = do_use_gpu
            ),
            evaluation_context = evaluation_context,
            output_size = output_size,
            **kwargs
        )