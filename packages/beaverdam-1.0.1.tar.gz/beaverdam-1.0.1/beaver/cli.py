import typer, time, json, base64, requests, qrcode, matplotlib.pyplot as plt
from datetime import datetime
from pathlib import Path
from tinydb import TinyDB, Query
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
import pyttsx3
from web3 import Web3
from eth_account import Account
from mnemonic import Mnemonic
from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

app = typer.Typer(help="🦫 Beaver Wallet — Build your crypto dam", rich_markup_mode="rich", add_completion=False)
console = Console()
engine = pyttsx3.init()

DB_PATH = Path.home() / ".beaver" / "wallet.json"
DB_PATH.parent.mkdir(exist_ok=True)
db = TinyDB(DB_PATH)
Wallet = Query()

w3 = Web3(Web3.HTTPProvider("https://rpc.sepolia.org"))

def speak(text): engine.say(text); engine.runAndWait()

def get_key(password: str):
    salt = b'beaver_wallet_salt_2026'
    kdf = PBKDF2HMAC(algorithm=hashes.SHA256(), length=32, salt=salt, iterations=480000)
    return Fernet(base64.urlsafe_b64encode(kdf.derive(password.encode())))

def _get_den(den_name=None):
    if den_name:
        return db.get(Wallet.name == den_name)
    dens = db.all()
    return dens[0] if dens else None

# ====================== RESTORE ======================
@app.command()
def restore(
    seed: str = typer.Argument(..., help="12-word seed phrase"),
    name: str = "RestoredDen",
    password: str = typer.Option(..., prompt=True, hide_input=True, confirmation_prompt=True)
):
    """Recover a Beaver Den from seed phrase"""
    if db.get(Wallet.name == name):
        console.print("[red]Name already exists[/]")
        raise typer.Exit(1)
    Account.enable_unaudited_hdwallet_features()
    acct = Account.from_mnemonic(seed)
    fernet = get_key(password)
    encrypted = fernet.encrypt(seed.encode()).decode()
    den = {"name": name, "address": acct.address, "encrypted_seed": encrypted, "created": datetime.now().isoformat(), "logs": [], "dam_height": 0}
    db.insert(den)
    console.print(Panel(f"✅ Restored den [bold green]{name}[/]\nAddress: {acct.address}", title="🦫 Beaver Wallet"))
    speak("Wallet restored successfully")

# ====================== MULTI-COIN BALANCE ======================
@app.command()
def balance(
    password: str = typer.Option(..., prompt=True, hide_input=True),
    den_name: str = typer.Option(None, "--den"),
    btc_address: str = typer.Option(None, "--btc"),
    sol_address: str = typer.Option(None, "--sol")
):
    """Show ETH + optional BTC/SOL balances"""
    den = _get_den(den_name)
    if not den: return
    try:
        fernet = get_key(password)
        phrase = fernet.decrypt(den["encrypted_seed"].encode()).decode()
        acct = Account.from_mnemonic(phrase)
        eth = w3.eth.get_balance(acct.address) / 10**18
        usd_eth = round(eth * requests.get("https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=usd").json()["ethereum"]["usd"], 2)
        
        btc_bal = sol_bal = 0
        if btc_address:
            btc_bal = int(requests.get(f"https://blockchain.info/q/addressbalance/{btc_address}").text) / 1e8
        if sol_address:
            resp = requests.post("https://api.mainnet-beta.solana.com", json={"jsonrpc":"2.0","id":1,"method":"getBalance","params":[sol_address]}).json()
            sol_bal = resp["result"]["value"] / 1e9
        
        console.print(Panel(
            f"Den: [bold]{den['name']}[/]\n"
            f"ETH: [bold green]{eth:.6f}[/] (${usd_eth})\n"
            f"BTC: [bold green]{btc_bal:.8f}[/]\n"
            f"SOL: [bold green]{sol_bal:.4f}[/]",
            title="🦫 Pond Level — Multi-Coin"
        ))
        speak(f"Balances loaded. ETH {eth:.4f}")
    except InvalidToken:
        console.print("[red]Wrong password[/]")

# ====================== MAINNET SEND WITH WARNING ======================
@app.command()
def send(
    to: str = typer.Argument(..., help="Destination address"),
    amount: float = typer.Argument(..., help="Amount in ETH"),
    password: str = typer.Option(..., prompt=True, hide_input=True),
    den_name: str = typer.Option(None, "--den"),
    mainnet: bool = typer.Option(False, "--mainnet", help="WARNING: REAL MONEY")
):
    """Send ETH — testnet by default"""
    if mainnet:
        console.print(Panel("[bold red]⚠️  MAINNET ACTIVATED — REAL MONEY WILL BE SENT ⚠️\nType exactly 'I UNDERSTAND THE RISK' to continue[/]", title="DANGER"))
        confirm = typer.prompt("Confirmation")
        if confirm != "I UNDERSTAND THE RISK":
            console.print("[red]Cancelled.[/]")
            return
        rpc = "https://eth.llamarpc.com"  # mainnet RPC
        chain_id = 1
    else:
        rpc = "https://rpc.sepolia.org"
        chain_id = 11155111
    
    w3_main = Web3(Web3.HTTPProvider(rpc))
    den = _get_den(den_name)
    if not den: return
    try:
        fernet = get_key(password)
        phrase = fernet.decrypt(den["encrypted_seed"].encode()).decode()
        acct = Account.from_mnemonic(phrase)
        tx = {
            'nonce': w3_main.eth.get_transaction_count(acct.address),
            'to': to,
            'value': w3_main.to_wei(amount, 'ether'),
            'gas': 21000,
            'gasPrice': w3_main.to_wei('5', 'gwei'),
            'chainId': chain_id
        }
        signed = acct.sign_transaction(tx)
        tx_hash = w3_main.eth.send_raw_transaction(signed.raw_transaction)
        console.print(f"🚀 Sent! Tx: [bold green]{w3_main.to_hex(tx_hash)}[/]")
        speak("Transaction broadcast")
    except Exception as e:
        console.print(f"[red]Error: {e}[/]")

# ====================== GUI (Flet desktop) ======================
# (full code below — run with python beaver-gui.py)

@app.command()
def version():
    console.print(Panel("🦫 Beaver Wallet v1.1.0\nMulti-coin • Restore • Mainnet • GUI", title="Version"))

def main(): app()
if __name__ == "__main__": main()
