from __future__ import annotations

import importlib
import os
from functools import lru_cache
from typing import TYPE_CHECKING, Any
from uuid import UUID

if TYPE_CHECKING:
    from collections.abc import Callable

import contextlib
import json

from lfx.base.models.anthropic_constants import ANTHROPIC_MODELS_DETAILED
from lfx.base.models.google_generative_ai_constants import (
    GOOGLE_GENERATIVE_AI_EMBEDDING_MODELS_DETAILED,
    GOOGLE_GENERATIVE_AI_MODELS_DETAILED,
)
from lfx.base.models.model_metadata import MODEL_PROVIDER_METADATA, get_provider_param_mapping
from lfx.base.models.model_utils import _to_str, replace_with_live_models
from lfx.base.models.ollama_constants import OLLAMA_EMBEDDING_MODELS_DETAILED, OLLAMA_MODELS_DETAILED
from lfx.base.models.openai_constants import OPENAI_EMBEDDING_MODELS_DETAILED, OPENAI_MODELS_DETAILED
from lfx.base.models.watsonx_constants import WATSONX_MODELS_DETAILED
from lfx.log.logger import logger
from lfx.services.deps import get_variable_service, session_scope
from lfx.utils.async_helpers import run_until_complete

# Mapping from class name to (module_path, attribute_name, install_hint | None).
# Only the provider package that is actually needed gets imported at runtime.
# install_hint overrides the auto-derived pip name for internal module paths.
_MODEL_CLASS_IMPORTS: dict[str, tuple[str, str, str | None]] = {
    "ChatOpenAI": ("langchain_openai", "ChatOpenAI", None),
    "ChatAnthropic": ("langchain_anthropic", "ChatAnthropic", None),
    "ChatGoogleGenerativeAIFixed": (
        "lfx.base.models.google_generative_ai_model",
        "ChatGoogleGenerativeAIFixed",
        "langchain-google-genai",
    ),
    "ChatOllama": ("langchain_ollama", "ChatOllama", None),
    "ChatWatsonx": ("langchain_ibm", "ChatWatsonx", None),
}

_EMBEDDING_CLASS_IMPORTS: dict[str, tuple[str, str, str | None]] = {
    "OpenAIEmbeddings": ("langchain_openai", "OpenAIEmbeddings", None),
    "GoogleGenerativeAIEmbeddings": ("langchain_google_genai", "GoogleGenerativeAIEmbeddings", None),
    "OllamaEmbeddings": ("langchain_ollama", "OllamaEmbeddings", None),
    "WatsonxEmbeddings": ("langchain_ibm", "WatsonxEmbeddings", None),
}

# Canonical mapping of provider name → embedding class name.
# Used by EmbeddingModelComponent and by flow_requirements to resolve
# which PyPI package a given embedding provider needs at runtime.
EMBEDDING_PROVIDER_CLASS_MAPPING: dict[str, str] = {
    "OpenAI": "OpenAIEmbeddings",
    "Google Generative AI": "GoogleGenerativeAIEmbeddings",
    "Ollama": "OllamaEmbeddings",
    "IBM WatsonX": "WatsonxEmbeddings",
    "IBM watsonx.ai": "WatsonxEmbeddings",  # Alias used by MODEL_PROVIDERS_DICT
}

_model_class_cache: dict[str, type] = {}
_embedding_class_cache: dict[str, type] = {}


def get_model_class(class_name: str) -> type:
    """Import and return a single model class by name.

    Only imports the provider package that is actually needed.
    """
    if class_name in _model_class_cache:
        return _model_class_cache[class_name]

    import_info = _MODEL_CLASS_IMPORTS.get(class_name)
    if import_info is None:
        msg = f"Unknown model class: {class_name}"
        raise ValueError(msg)

    module_path, attr_name, install_hint = import_info
    pkg_hint = install_hint or module_path.split(".")[0].replace("_", "-")
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        msg = (
            f"Could not import '{module_path}' for model class '{class_name}'. "
            f"Install the missing package (e.g. uv pip install {pkg_hint})."
        )
        raise ImportError(msg) from exc
    try:
        cls = getattr(module, attr_name)
    except AttributeError as exc:
        msg = (
            f"Module '{module_path}' was imported but does not have attribute '{attr_name}'. "
            f"This may indicate a version mismatch. "
        )
        raise AttributeError(msg) from exc
    _model_class_cache[class_name] = cls
    return cls


def get_embedding_class(class_name: str) -> type:
    """Import and return a single embedding class by name.

    Only imports the provider package that is actually needed.
    """
    if class_name in _embedding_class_cache:
        return _embedding_class_cache[class_name]

    import_info = _EMBEDDING_CLASS_IMPORTS.get(class_name)
    if import_info is None:
        msg = f"Unknown embedding class: {class_name}"
        raise ValueError(msg)

    module_path, attr_name, install_hint = import_info
    pkg_hint = install_hint or module_path.split(".")[0].replace("_", "-")
    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        msg = (
            f"Could not import '{module_path}' for embedding class '{class_name}'. "
            f"Install the missing package (e.g. uv pip install {pkg_hint})."
        )
        raise ImportError(msg) from exc
    try:
        cls = getattr(module, attr_name)
    except AttributeError as exc:
        msg = (
            f"Module '{module_path}' was imported but does not have attribute '{attr_name}'. "
            f"This may indicate a version mismatch. "
        )
        raise AttributeError(msg) from exc
    _embedding_class_cache[class_name] = cls
    return cls


def get_model_classes() -> dict[str, type]:
    """Return all model classes, importing every provider package.

    .. deprecated::
        Use :func:`get_model_class` instead to import only the provider you need.
    """
    return {name: get_model_class(name) for name in _MODEL_CLASS_IMPORTS}


def get_embedding_classes() -> dict[str, type]:
    """Return all embedding classes, importing every provider package.

    .. deprecated::
        Use :func:`get_embedding_class` instead to import only the provider you need.
    """
    return {name: get_embedding_class(name) for name in _EMBEDDING_CLASS_IMPORTS}


@lru_cache(maxsize=1)
def get_model_provider_metadata():
    """Return the model provider metadata configuration."""
    return MODEL_PROVIDER_METADATA


model_provider_metadata = get_model_provider_metadata()


@lru_cache(maxsize=1)
def get_models_detailed():
    return [
        ANTHROPIC_MODELS_DETAILED,
        OPENAI_MODELS_DETAILED,
        OPENAI_EMBEDDING_MODELS_DETAILED,
        GOOGLE_GENERATIVE_AI_MODELS_DETAILED,
        GOOGLE_GENERATIVE_AI_EMBEDDING_MODELS_DETAILED,
        OLLAMA_MODELS_DETAILED,
        OLLAMA_EMBEDDING_MODELS_DETAILED,
        WATSONX_MODELS_DETAILED,
    ]


MODELS_DETAILED = get_models_detailed()


@lru_cache(maxsize=1)
def get_model_provider_variable_mapping() -> dict[str, str]:
    """Return primary (first required secret) variable for each provider - backward compatible."""
    result = {}
    for provider, meta in model_provider_metadata.items():
        for var in meta.get("variables", []):
            if var.get("required") and var.get("is_secret"):
                result[provider] = var["variable_key"]
                break
        # Fallback to first variable if no required secret found
        if provider not in result and meta.get("variables"):
            result[provider] = meta["variables"][0]["variable_key"]
    return result


def get_provider_all_variables(provider: str) -> list[dict]:
    """Get all variables for a provider."""
    meta = model_provider_metadata.get(provider, {})
    return meta.get("variables", [])


def get_provider_required_variable_keys(provider: str) -> list[str]:
    """Get all required variable keys for a provider."""
    variables = get_provider_all_variables(provider)
    return [v["variable_key"] for v in variables if v.get("required")]


def apply_provider_variable_config_to_build_config(
    build_config: dict,
    provider: str,
) -> dict:
    """Apply provider variable metadata to component build config fields.

    This function updates the build config fields based on the provider's variable metadata
    stored in the `component_metadata` nested dict:
    - Sets `required` based on `component_metadata.required`
    - Sets `advanced` based on `component_metadata.advanced`
    - Sets `info` based on `component_metadata.info`
    - Sets `show` to True for fields that have a mapping_field for this provider

    Args:
        build_config: The component's build configuration dict
        provider: The selected provider name (e.g., "OpenAI", "IBM WatsonX")

    Returns:
        Updated build_config dict
    """
    import os

    provider_vars = get_provider_all_variables(provider)

    # Build a lookup by component_metadata.mapping_field
    vars_by_field = {}
    for v in provider_vars:
        component_meta = v.get("component_metadata", {})
        mapping_field = component_meta.get("mapping_field")
        if mapping_field:
            vars_by_field[mapping_field] = v

    for field_name, var_info in vars_by_field.items():
        if field_name not in build_config:
            continue

        field_config = build_config[field_name]
        component_meta = var_info.get("component_metadata", {})

        # Apply required from component_metadata
        required = component_meta.get("required", False)
        field_config["required"] = required

        # Apply advanced from component_metadata
        advanced = component_meta.get("advanced", False)
        field_config["advanced"] = advanced

        # Apply info from component_metadata
        info = component_meta.get("info")
        if info:
            field_config["info"] = info

        # Show the field since it's relevant to this provider
        field_config["show"] = True

        # If no value is set, try to get from environment variable
        env_var_key = var_info.get("variable_key")
        if env_var_key:
            current_value = field_config.get("value")
            # Only set from env if field is empty/None
            if not current_value or (isinstance(current_value, str) and not current_value.strip()):
                env_value = os.environ.get(env_var_key)
                if env_value and env_value.strip():
                    field_config["value"] = env_value
                    logger.debug(
                        "Set field %s from environment variable %s",
                        field_name,
                        env_var_key,
                    )

    return build_config


def get_provider_config(provider: str) -> dict:
    """Get complete provider configuration.

    Args:
        provider: Provider name (e.g., "OpenAI", "Anthropic")

    Returns:
        Dict with model_class, api_key_param, icon, variable_name, model_name_param, and extra params

    Raises:
        ValueError: If provider is unknown
    """
    if provider not in model_provider_metadata:
        msg = f"Unknown provider: {provider}"
        raise ValueError(msg)

    return model_provider_metadata[provider].copy()


def get_model_providers() -> list[str]:
    """Return a sorted list of unique provider names."""
    return sorted({md.get("provider", "Unknown") for group in MODELS_DETAILED for md in group})


def get_unified_models_detailed(
    providers: list[str] | None = None,
    model_name: str | None = None,
    model_type: str | None = None,
    *,
    include_unsupported: bool | None = None,
    include_deprecated: bool | None = None,
    only_defaults: bool = False,
    **metadata_filters,
):
    """Return a list of providers and their models, optionally filtered.

    Parameters
    ----------
    providers : list[str] | None
        If given, only models from these providers are returned.
    model_name : str | None
        If given, only the model with this exact name is returned.
    model_type : str | None
        Optional. Restrict to models whose metadata "model_type" matches this value.
    include_unsupported : bool
        When False (default) models whose metadata contains ``not_supported=True``
        are filtered out.
    include_deprecated : bool
        When False (default) models whose metadata contains ``deprecated=True``
        are filtered out.
    only_defaults : bool
        When True, only models marked as default are returned.
        The first 5 models from each provider (in list order) are automatically
        marked as default. Defaults to False to maintain backward compatibility.
    **metadata_filters
        Arbitrary key/value pairs to match against the model's metadata.
        Example: ``get_unified_models_detailed(size="4k", context_window=8192)``

    Notes:
    • Filtering is exact-match on the metadata values.
    • If you *do* want to see unsupported models set ``include_unsupported=True``.
    • If you *do* want to see deprecated models set ``include_deprecated=True``.
    """
    if include_unsupported is None:
        include_unsupported = False
    if include_deprecated is None:
        include_deprecated = False

    # Gather all models from imported *_MODELS_DETAILED lists
    all_models: list[dict] = []
    for models_detailed in MODELS_DETAILED:
        all_models.extend(models_detailed)

    # Apply filters
    filtered_models: list[dict] = []
    for md in all_models:
        # Skip models flagged as not_supported unless explicitly included
        if (not include_unsupported) and md.get("not_supported", False):
            continue

        # Skip models flagged as deprecated unless explicitly included
        if (not include_deprecated) and md.get("deprecated", False):
            continue

        if providers and md.get("provider") not in providers:
            continue
        if model_name and md.get("name") != model_name:
            continue
        if model_type and md.get("model_type") != model_type:
            continue
        # Match arbitrary metadata key/value pairs
        if any(md.get(k) != v for k, v in metadata_filters.items()):
            continue

        filtered_models.append(md)

    # Group by provider
    provider_map: dict[str, list[dict]] = {}
    for metadata in filtered_models:
        prov = metadata.get("provider", "Unknown")
        provider_map.setdefault(prov, []).append(
            {
                "model_name": metadata.get("name"),
                "metadata": {k: v for k, v in metadata.items() if k not in ("provider", "name")},
            }
        )

    # Mark the first 5 models in each provider as default (based on list order)
    # and optionally filter to only defaults
    default_model_count = 5  # Number of default models per provider

    for prov, models in provider_map.items():
        for i, model in enumerate(models):
            if i < default_model_count:
                model["metadata"]["default"] = True
            else:
                model["metadata"]["default"] = False

        # If only_defaults is True, filter to only default models
        if only_defaults:
            provider_map[prov] = [m for m in models if m["metadata"].get("default", False)]

    # Format as requested
    return [
        {
            "provider": prov,
            "models": models,
            "num_models": len(models),
            **model_provider_metadata.get(prov, {}),
        }
        for prov, models in provider_map.items()
    ]


def get_api_key_for_provider(user_id: UUID | str | None, provider: str, api_key: str | None = None) -> str | None:
    """Get API key from self.api_key or global variables.

    Args:
        user_id: The user ID to look up global variables for
        provider: The provider name (e.g., "OpenAI", "Anthropic")
        api_key: An optional API key provided directly

    Returns:
        The API key if found, None otherwise
    """
    # First check if user provided an API key directly
    if api_key:
        return api_key

    # If no user_id or user_id is the string "None", we can't look up global variables
    if user_id is None or (isinstance(user_id, str) and user_id == "None"):
        return None

    # Get primary variable (first required secret) from provider metadata
    provider_variable_map = get_model_provider_variable_mapping()
    variable_name = provider_variable_map.get(provider)
    if not variable_name:
        return None

    # Try to get from global variables
    async def _get_variable():
        async with session_scope() as session:
            variable_service = get_variable_service()
            if variable_service is None:
                return None
            return await variable_service.get_variable(
                user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
                name=variable_name,
                field="",
                session=session,
            )

    return run_until_complete(_get_variable())


def get_all_variables_for_provider(user_id: UUID | str | None, provider: str) -> dict[str, str]:
    """Get all configured variables for a provider from database or environment.

    Args:
        user_id: The user ID to look up global variables for
        provider: The provider name (e.g., "IBM WatsonX", "Ollama")

    Returns:
        Dictionary mapping variable keys to their values
    """
    import os

    result: dict[str, str] = {}

    # Get all variable definitions for this provider
    provider_vars = get_provider_all_variables(provider)
    if not provider_vars:
        return result

    # If no user_id, only check environment variables
    if user_id is None or (isinstance(user_id, str) and user_id == "None"):
        for var_info in provider_vars:
            var_key = var_info.get("variable_key")
            if var_key:
                env_value = os.environ.get(var_key)
                if env_value and env_value.strip():
                    result[var_key] = env_value
        return result

    # Try to get from global variables (database)
    async def _get_all_variables():
        async with session_scope() as session:
            variable_service = get_variable_service()
            if variable_service is None:
                return {}

            values = {}
            user_id_uuid = UUID(user_id) if isinstance(user_id, str) else user_id

            for var_info in provider_vars:
                var_key = var_info.get("variable_key")
                if not var_key:
                    continue

                try:
                    value = await variable_service.get_variable(
                        user_id=user_id_uuid,
                        name=var_key,
                        field="",
                        session=session,
                    )
                    if value and str(value).strip():
                        values[var_key] = str(value)
                except (ValueError, Exception):  # noqa: BLE001
                    # Variable not found - check environment
                    env_value = os.environ.get(var_key)
                    if env_value and env_value.strip():
                        values[var_key] = env_value

            return values

    return run_until_complete(_get_all_variables())


def _validate_and_get_enabled_providers(
    all_variables: dict[str, Any],
    provider_variable_map: dict[str, str],
    *,
    skip_validation: bool = True,
) -> set[str]:
    """Return set of enabled providers based on credential existence.

    This helper function determines which providers have credentials stored and (optionally)
    validates that their API keys are present and valid.
    It is used by get_enabled_providers and model options functions.
    Providers are considered enabled if all required credential variables are set (from DB or environment variables).
    API key validation is performed when credentials are saved, not on every read,
    to avoid latency from external API calls.


    For providers requiring multiple variables (e.g., IBM WatsonX needs API key, project ID, and URL),
    all variables marked as `required: True` must be present (from DB or environment variables)
    for the provider to be considered enabled.

    Variables are collected from:
    1. Database variables (if available)
    2. Environment variables (as fallback)

    Args:
        all_variables: Dictionary mapping variable names to Variable/VariableRead objects
        provider_variable_map: Dictionary mapping provider names to primary variable names
        credential_variables: Dictionary mapping variable names to VariableRead objects
        skip_validation: If True (default), skip API validation and just check existence.
                        If False, validate each API key (slower, makes external calls).

    Returns:
        Set of provider names that have credentials stored
    """
    import os

    from langflow.services.auth import utils as auth_utils
    from langflow.services.deps import get_settings_service

    settings_service = get_settings_service()
    enabled = set()

    for provider in provider_variable_map:
        provider_vars = get_provider_all_variables(provider)

        collected_values: dict[str, str] = {}
        all_required_present = True

        for var_info in provider_vars:
            var_key = var_info.get("variable_key")
            if not var_key:
                continue

            is_required = bool(var_info.get("required", False))
            value = None

            if var_key in all_variables:
                variable = all_variables[var_key]
                if variable.value is not None:
                    try:
                        decrypted_value = auth_utils.decrypt_api_key(variable.value, settings_service=settings_service)
                        if decrypted_value and decrypted_value.strip():
                            value = decrypted_value
                    except Exception as e:  # noqa: BLE001
                        raw_value = variable.value
                        if raw_value is not None and str(raw_value).strip():
                            value = str(raw_value)
                        else:
                            logger.debug(
                                "Failed to decrypt variable %s for provider %s: %s",
                                var_key,
                                provider,
                                e,
                            )

            if value is None:
                env_value = os.environ.get(var_key)
                if env_value and env_value.strip():
                    value = env_value
                    logger.debug(
                        "Using environment variable %s for provider %s",
                        var_key,
                        provider,
                    )

            if value:
                collected_values[var_key] = value
            elif is_required:
                all_required_present = False

        if not provider_vars:
            enabled.add(provider)
        elif all_required_present and collected_values:
            if skip_validation:
                # Just check existence - validation was done on save
                enabled.add(provider)
            else:
                try:
                    validate_model_provider_key(provider, collected_values)
                    enabled.add(provider)
                except (ValueError, Exception) as e:  # noqa: BLE001
                    logger.debug("Provider %s validation failed: %s", provider, e)

    return enabled


def get_provider_from_variable_key(variable_key: str) -> str | None:
    """Get provider name from a variable key.

    Args:
        variable_key: The variable key (e.g., "OPENAI_API_KEY", "WATSONX_APIKEY")

    Returns:
        The provider name or None if not found
    """
    for provider, meta in model_provider_metadata.items():
        for var in meta.get("variables", []):
            if var.get("variable_key") == variable_key:
                return provider
    return None


def validate_model_provider_key(provider: str, variables: dict[str, str], model_name: str | None = None) -> None:
    """Validate a model provider by making a minimal test call.

    Args:
        provider: The provider name (e.g., "OpenAI", "IBM WatsonX")
        model_name: The model name to test (e.g., "gpt-4o", "gpt-4o-mini")
        variables: Dictionary mapping variable keys to their decrypted values
                   (e.g., {"WATSONX_APIKEY": "...", "WATSONX_PROJECT_ID": "...", "WATSONX_URL": "..."})

    Raises:
        ValueError: If the credentials are invalid
    """
    if not provider:
        return

    first_model = None
    try:
        models = get_unified_models_detailed(providers=[provider])
        if models and models[0].get("models"):
            first_model = models[0]["models"][0]["model_name"]
    except Exception as e:  # noqa: BLE001
        logger.error(f"Error getting unified models for provider {provider}: {e}")

    # For providers that need a model to test credentials
    if not first_model and provider in ["OpenAI", "Anthropic", "Google Generative AI", "IBM WatsonX"]:
        return

    try:
        if provider == "OpenAI":
            from langchain_openai import ChatOpenAI  # type: ignore  # noqa: PGH003

            api_key = variables.get("OPENAI_API_KEY")
            if not api_key:
                return
            llm = ChatOpenAI(api_key=api_key, model_name=first_model, max_tokens=1)
            llm.invoke("test")

        elif provider == "Anthropic":
            from langchain_anthropic import ChatAnthropic  # type: ignore  # noqa: PGH003

            api_key = variables.get("ANTHROPIC_API_KEY")
            if not api_key:
                return
            llm = ChatAnthropic(anthropic_api_key=api_key, model=first_model, max_tokens=1)
            llm.invoke("test")

        elif provider == "Google Generative AI":
            from langchain_google_genai import ChatGoogleGenerativeAI  # type: ignore  # noqa: PGH003

            api_key = variables.get("GOOGLE_API_KEY")
            if not api_key:
                return
            llm = ChatGoogleGenerativeAI(google_api_key=api_key, model=first_model, max_tokens=1)
            llm.invoke("test")

        elif provider == "IBM WatsonX":
            from langchain_ibm import ChatWatsonx

            api_key = variables.get("WATSONX_APIKEY")
            project_id = variables.get("WATSONX_PROJECT_ID")
            url = variables.get("WATSONX_URL", "https://us-south.ml.cloud.ibm.com")
            if not api_key or not project_id:
                return
            llm = ChatWatsonx(
                apikey=api_key, url=url, model_id=first_model, project_id=project_id, params={"max_new_tokens": 1}
            )
            llm.invoke("test")

        elif provider == "Ollama":
            import requests

            base_url = variables.get("OLLAMA_BASE_URL")
            if not base_url:
                msg = "Invalid Ollama base URL"
                logger.error(msg)
                raise ValueError(msg)

            base_url = base_url.rstrip("/")
            response = requests.get(f"{base_url}/api/tags", timeout=5)
            response.raise_for_status()

            data = response.json()
            if not isinstance(data, dict) or "models" not in data:
                msg = "Invalid Ollama base URL"
                logger.error(msg)
                raise ValueError(msg)

            if model_name:
                available_models = [m.get("name") for m in data["models"]]
                # Exact match or match with :latest
                if model_name not in available_models and f"{model_name}:latest" not in available_models:
                    # Lenient check for missing tag
                    if ":" not in model_name:
                        if not any(m.startswith(f"{model_name}:") for m in available_models):
                            available_str = ", ".join(available_models[:3])
                            msg = f"Model '{model_name}' not found on Ollama server. Available: {available_str}"
                            logger.error(msg)
                            raise ValueError(msg)
                    else:
                        available_str = ", ".join(available_models[:3])
                        msg = f"Model '{model_name}' not found on Ollama server. Available: {available_str}"
                        logger.error(msg)
                        raise ValueError(msg)

    except ValueError:
        raise
    except Exception as e:
        error_msg = str(e).lower()
        if any(word in error_msg for word in ["401", "authentication", "api key"]):
            msg = f"Invalid API key for {provider}"
            logger.error(f"Invalid API key for {provider}: {e}")
            raise ValueError(msg) from e

        # Rethrow specific Ollama errors with a user-facing message
        if provider == "Ollama":
            msg = "Invalid Ollama base URL"
            logger.error(msg)
            raise ValueError(msg) from e

        # For others, log and return (allow saving despite minor errors)
        return


def get_language_model_options(
    user_id: UUID | str | None = None, *, tool_calling: bool | None = None
) -> list[dict[str, Any]]:
    """Return a list of available language model providers with their configuration.

    This function uses get_unified_models_detailed() which respects the enabled/disabled
    status from the settings page and automatically filters out deprecated/unsupported models.

    Args:
        user_id: Optional user ID to filter by user-specific enabled/disabled models
        tool_calling: If True, only return models that support tool calling.
                     If False, only return models that don't support tool calling.
                     If None (default), return all models regardless of tool calling support.
    """
    # Get all LLM models (excluding embeddings, deprecated, and unsupported by default)
    # Apply tool_calling filter if specified
    if tool_calling is not None:
        all_models = get_unified_models_detailed(
            model_type="llm",
            include_deprecated=False,
            include_unsupported=False,
            tool_calling=tool_calling,
        )
    else:
        all_models = get_unified_models_detailed(
            model_type="llm",
            include_deprecated=False,
            include_unsupported=False,
        )

    # Get disabled and explicitly enabled models for this user if user_id is provided
    disabled_models = set()
    explicitly_enabled_models = set()
    if user_id:
        try:

            async def _get_model_status():
                async with session_scope() as session:
                    variable_service = get_variable_service()
                    if variable_service is None:
                        return set(), set()
                    from langflow.services.variable.service import DatabaseVariableService

                    if not isinstance(variable_service, DatabaseVariableService):
                        return set(), set()
                    all_vars = await variable_service.get_all(
                        user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
                        session=session,
                    )
                    disabled = set()
                    enabled = set()
                    import json

                    for var in all_vars:
                        if var.name == "__disabled_models__" and var.value:
                            with contextlib.suppress(json.JSONDecodeError, TypeError):
                                disabled = set(json.loads(var.value))
                        elif var.name == "__enabled_models__" and var.value:
                            with contextlib.suppress(json.JSONDecodeError, TypeError):
                                enabled = set(json.loads(var.value))
                    return disabled, enabled

            disabled_models, explicitly_enabled_models = run_until_complete(_get_model_status())
        except Exception:  # noqa: BLE001, S110
            # If we can't get model status, continue without filtering
            pass

    # Get enabled providers (those with credentials configured and validated)
    enabled_providers = set()
    if user_id:
        try:

            async def _get_enabled_providers():
                async with session_scope() as session:
                    variable_service = get_variable_service()
                    if variable_service is None:
                        return set()

                    from langflow.services.variable.service import DatabaseVariableService

                    if not isinstance(variable_service, DatabaseVariableService):
                        return set()

                    # Get all variable names (VariableRead has value=None for credentials)
                    all_vars = await variable_service.get_all(
                        user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
                        session=session,
                    )
                    all_var_names = {var.name for var in all_vars}

                    provider_variable_map = get_model_provider_variable_mapping()

                    # Simple wrapper class for passing values to _validate_and_get_enabled_providers
                    class VarWithValue:
                        def __init__(self, value):
                            self.value = value

                    # Build dict with raw Variable values (encrypted for secrets, plaintext for others)
                    # We need to fetch raw Variable objects because VariableRead has value=None for credentials
                    all_provider_variables = {}
                    user_id_uuid = UUID(user_id) if isinstance(user_id, str) else user_id

                    for provider in provider_variable_map:
                        # Get ALL variables for this provider (not just the primary one)
                        provider_vars = get_provider_all_variables(provider)

                        for var_info in provider_vars:
                            var_name = var_info.get("variable_key")
                            if not var_name or var_name not in all_var_names:
                                # Variable not configured by user
                                continue

                            if var_name in all_provider_variables:
                                # Already fetched
                                continue

                            try:
                                # Get the raw Variable object to access the actual value
                                variable_obj = await variable_service.get_variable_object(
                                    user_id=user_id_uuid, name=var_name, session=session
                                )
                                if variable_obj and variable_obj.value:
                                    all_provider_variables[var_name] = VarWithValue(variable_obj.value)
                            except Exception as e:  # noqa: BLE001
                                # Variable not found or error accessing it - skip
                                logger.error(f"Error accessing variable {var_name} for provider {provider}: {e}")
                                continue

                    # Use shared helper to validate and get enabled providers
                    return _validate_and_get_enabled_providers(all_provider_variables, provider_variable_map)

            enabled_providers = run_until_complete(_get_enabled_providers())
        except Exception:  # noqa: BLE001, S110
            # If we can't get enabled providers, show all
            pass

    # Replace static defaults with actual available models from configured instances
    if enabled_providers:
        replace_with_live_models(all_models, user_id, enabled_providers, "llm", model_provider_metadata)

    options = []

    # Track which providers have models
    providers_with_models = set()

    for provider_data in all_models:
        provider = provider_data.get("provider")
        models = provider_data.get("models", [])
        icon = provider_data.get("icon", "Bot")

        # Check if provider is enabled
        is_provider_enabled = not user_id or not enabled_providers or provider in enabled_providers

        # Track this provider
        if is_provider_enabled:
            providers_with_models.add(provider)

        # Skip provider if user_id is provided and provider is not enabled
        if user_id and enabled_providers and provider not in enabled_providers:
            continue

        for model_data in models:
            model_name = model_data.get("model_name")
            metadata = model_data.get("metadata", {})
            is_default = metadata.get("default", False)

            # Determine if model should be shown:
            # - If not default and not explicitly enabled, skip it
            # - If in disabled list, skip it
            # - Otherwise, show it
            if not is_default and model_name not in explicitly_enabled_models:
                continue
            if model_name in disabled_models:
                continue

            # Get parameter mapping for this provider
            param_mapping = get_provider_param_mapping(provider)

            # Build the option dict
            option = {
                "name": model_name,
                "icon": icon,
                "category": provider,
                "provider": provider,
                "metadata": {
                    "context_length": 128000,  # Default, can be overridden
                    "model_class": param_mapping.get("model_class", "ChatOpenAI"),
                    "model_name_param": param_mapping.get("model_param", "model"),
                    "api_key_param": param_mapping.get("api_key_param", "api_key"),
                },
            }

            # Add reasoning models list for OpenAI
            if provider == "OpenAI" and metadata.get("reasoning"):
                if "reasoning_models" not in option["metadata"]:
                    option["metadata"]["reasoning_models"] = []
                option["metadata"]["reasoning_models"].append(model_name)

            # Add provider-specific params from mapping
            if "base_url_param" in param_mapping:
                option["metadata"]["base_url_param"] = param_mapping["base_url_param"]
            if "url_param" in param_mapping:
                option["metadata"]["url_param"] = param_mapping["url_param"]
            if "project_id_param" in param_mapping:
                option["metadata"]["project_id_param"] = param_mapping["project_id_param"]

            options.append(option)

    # Add disabled providers (providers that exist in metadata but have no enabled models)
    if user_id:
        for provider, metadata in model_provider_metadata.items():
            if provider not in providers_with_models:
                # This provider has no enabled models, add it as a disabled provider entry
                options.append(
                    {
                        "name": f"__enable_provider_{provider}__",
                        "icon": metadata.get("icon", "Bot"),
                        "category": provider,
                        "provider": provider,
                        "metadata": {
                            "is_disabled_provider": True,
                            "variable_name": metadata.get("variable_name"),
                        },
                    }
                )

    return options


def get_embedding_model_options(user_id: UUID | str | None = None) -> list[dict[str, Any]]:
    """Return a list of available embedding model providers with their configuration.

    This function uses get_unified_models_detailed() which respects the enabled/disabled
    status from the settings page and automatically filters out deprecated/unsupported models.

    Args:
        user_id: Optional user ID to filter by user-specific enabled/disabled models
    """
    # Get all embedding models (excluding deprecated and unsupported by default)
    all_models = get_unified_models_detailed(
        model_type="embeddings",
        include_deprecated=False,
        include_unsupported=False,
    )

    # Get disabled and explicitly enabled models for this user if user_id is provided
    disabled_models = set()
    explicitly_enabled_models = set()
    if user_id:
        try:

            async def _get_model_status():
                async with session_scope() as session:
                    variable_service = get_variable_service()
                    if variable_service is None:
                        return set(), set()
                    from langflow.services.variable.service import DatabaseVariableService

                    if not isinstance(variable_service, DatabaseVariableService):
                        return set(), set()
                    all_vars = await variable_service.get_all(
                        user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
                        session=session,
                    )
                    disabled = set()
                    enabled = set()
                    import json

                    for var in all_vars:
                        if var.name == "__disabled_models__" and var.value:
                            with contextlib.suppress(json.JSONDecodeError, TypeError):
                                disabled = set(json.loads(var.value))
                        elif var.name == "__enabled_models__" and var.value:
                            with contextlib.suppress(json.JSONDecodeError, TypeError):
                                enabled = set(json.loads(var.value))
                    return disabled, enabled

            disabled_models, explicitly_enabled_models = run_until_complete(_get_model_status())
        except Exception:  # noqa: BLE001, S110
            # If we can't get model status, continue without filtering
            pass

    # Get enabled providers (those with credentials configured and validated)
    enabled_providers = set()
    if user_id:
        try:

            async def _get_enabled_providers():
                async with session_scope() as session:
                    variable_service = get_variable_service()
                    if variable_service is None:
                        return set()

                    from langflow.services.variable.service import DatabaseVariableService

                    if not isinstance(variable_service, DatabaseVariableService):
                        return set()

                    # Get all variable names (VariableRead has value=None for credentials)
                    all_vars = await variable_service.get_all(
                        user_id=UUID(user_id) if isinstance(user_id, str) else user_id,
                        session=session,
                    )
                    all_var_names = {var.name for var in all_vars}

                    provider_variable_map = get_model_provider_variable_mapping()

                    # Simple wrapper class for passing values to _validate_and_get_enabled_providers
                    class VarWithValue:
                        def __init__(self, value):
                            self.value = value

                    # Build dict with raw Variable values (encrypted for secrets, plaintext for others)
                    # We need to fetch raw Variable objects because VariableRead has value=None for credentials
                    all_provider_variables = {}
                    user_id_uuid = UUID(user_id) if isinstance(user_id, str) else user_id

                    for provider in provider_variable_map:
                        # Get ALL variables for this provider (not just the primary one)
                        provider_vars = get_provider_all_variables(provider)

                        for var_info in provider_vars:
                            var_name = var_info.get("variable_key")
                            if not var_name or var_name not in all_var_names:
                                # Variable not configured by user
                                continue

                            if var_name in all_provider_variables:
                                # Already fetched
                                continue

                            try:
                                # Get the raw Variable object to access the actual value
                                variable_obj = await variable_service.get_variable_object(
                                    user_id=user_id_uuid, name=var_name, session=session
                                )
                                if variable_obj and variable_obj.value:
                                    all_provider_variables[var_name] = VarWithValue(variable_obj.value)
                            except Exception as e:  # noqa: BLE001
                                # Variable not found or error accessing it - skip
                                logger.error(f"Error accessing variable {var_name} for provider {provider}: {e}")
                                continue

                    # Use shared helper to validate and get enabled providers
                    return _validate_and_get_enabled_providers(all_provider_variables, provider_variable_map)

            enabled_providers = run_until_complete(_get_enabled_providers())
        except Exception:  # noqa: BLE001, S110
            # If we can't get enabled providers, show all
            pass

    # Replace static defaults with actual available models from configured instances
    if enabled_providers:
        replace_with_live_models(all_models, user_id, enabled_providers, "embeddings", model_provider_metadata)

    options = []

    # Provider-specific param mappings
    param_mappings = {
        "OpenAI": {
            "model": "model",
            "api_key": "api_key",
            "api_base": "base_url",
            "dimensions": "dimensions",
            "chunk_size": "chunk_size",
            "request_timeout": "timeout",
            "max_retries": "max_retries",
            "show_progress_bar": "show_progress_bar",
            "model_kwargs": "model_kwargs",
        },
        "Google Generative AI": {
            "model": "model",
            "api_key": "google_api_key",
            "request_timeout": "request_options",
            "model_kwargs": "client_options",
        },
        "Ollama": {
            "model": "model",
            "base_url": "base_url",
            "num_ctx": "num_ctx",
            "request_timeout": "request_timeout",
            "model_kwargs": "model_kwargs",
        },
        "IBM WatsonX": {
            "model_id": "model_id",
            "url": "url",
            "api_key": "apikey",
            "project_id": "project_id",
            "space_id": "space_id",
            "request_timeout": "request_timeout",
        },
    }

    # Track which providers have models
    providers_with_models = set()

    for provider_data in all_models:
        provider = provider_data.get("provider")
        models = provider_data.get("models", [])
        icon = provider_data.get("icon", "Bot")

        # Check if provider is enabled
        is_provider_enabled = not user_id or not enabled_providers or provider in enabled_providers

        # Track this provider
        if is_provider_enabled:
            providers_with_models.add(provider)

        # Skip provider if user_id is provided and provider is not enabled
        if user_id and enabled_providers and provider not in enabled_providers:
            continue

        for model_data in models:
            model_name = model_data.get("model_name")
            metadata = model_data.get("metadata", {})
            is_default = metadata.get("default", False)

            # Determine if model should be shown:
            # - If not default and not explicitly enabled, skip it
            # - If in disabled list, skip it
            # - Otherwise, show it
            if not is_default and model_name not in explicitly_enabled_models:
                continue
            if model_name in disabled_models:
                continue

            # Build the option dict
            option = {
                "name": model_name,
                "icon": icon,
                "category": provider,
                "provider": provider,
                "metadata": {
                    "embedding_class": EMBEDDING_PROVIDER_CLASS_MAPPING.get(provider, "OpenAIEmbeddings"),
                    "param_mapping": param_mappings.get(provider, param_mappings["OpenAI"]),
                    "model_type": "embeddings",  # Mark as embedding model
                },
            }

            options.append(option)

    # Add disabled providers (providers that exist in metadata but have no enabled models)
    if user_id:
        for provider, metadata in model_provider_metadata.items():
            if provider not in providers_with_models and provider in EMBEDDING_PROVIDER_CLASS_MAPPING:
                # This provider has no enabled models and supports embeddings, add it as a disabled provider entry
                options.append(
                    {
                        "name": f"__enable_provider_{provider}__",
                        "icon": metadata.get("icon", "Bot"),
                        "category": provider,
                        "provider": provider,
                        "metadata": {
                            "is_disabled_provider": True,
                            "variable_name": metadata.get("variable_name"),
                        },
                    }
                )

    return options


def normalize_model_names_to_dicts(model_names: list[str] | str) -> list[dict[str, Any]]:
    """Convert simple model name(s) to list of dicts format.

    Args:
        model_names: A string or list of strings representing model names

    Returns:
        A list of dicts with full model metadata including runtime info

    Examples:
        >>> normalize_model_names_to_dicts('gpt-4o')
        [{'name': 'gpt-4o', 'provider': 'OpenAI', 'metadata': {'model_class': 'ChatOpenAI', ...}}]

        >>> normalize_model_names_to_dicts(['gpt-4o', 'claude-3'])
        [{'name': 'gpt-4o', ...}, {'name': 'claude-3', ...}]
    """
    # Convert single string to list
    if isinstance(model_names, str):
        model_names = [model_names]

    # Get all available models to look up metadata
    try:
        all_models = get_unified_models_detailed()
    except Exception:  # noqa: BLE001
        # If we can't get models, just create basic dicts
        return [{"name": name} for name in model_names]

    # Build a lookup map of model_name -> full model data with runtime metadata
    model_lookup = {}
    for provider_data in all_models:
        provider = provider_data.get("provider")
        icon = provider_data.get("icon", "Bot")
        for model_data in provider_data.get("models", []):
            model_name = model_data.get("model_name")
            base_metadata = model_data.get("metadata", {})

            # Get parameter mapping for this provider
            param_mapping = get_provider_param_mapping(provider)

            # Build runtime metadata similar to get_language_model_options
            runtime_metadata = {
                "context_length": 128000,  # Default
                "model_class": param_mapping.get("model_class", "ChatOpenAI"),
                "model_name_param": param_mapping.get("model_param", "model"),
                "api_key_param": param_mapping.get("api_key_param", "api_key"),
            }

            # Add max_tokens_field_name from provider metadata
            provider_meta = model_provider_metadata.get(provider, {})
            if "max_tokens_field_name" in provider_meta:
                runtime_metadata["max_tokens_field_name"] = provider_meta["max_tokens_field_name"]

            # Add reasoning models list for OpenAI
            if provider == "OpenAI" and base_metadata.get("reasoning"):
                runtime_metadata["reasoning_models"] = [model_name]

            # Add provider-specific params from mapping
            if "base_url_param" in param_mapping:
                runtime_metadata["base_url_param"] = param_mapping["base_url_param"]
            if "url_param" in param_mapping:
                runtime_metadata["url_param"] = param_mapping["url_param"]
            if "project_id_param" in param_mapping:
                runtime_metadata["project_id_param"] = param_mapping["project_id_param"]

            # Merge base metadata with runtime metadata
            full_metadata = {**base_metadata, **runtime_metadata}

            model_lookup[model_name] = {
                "name": model_name,
                "icon": icon,
                "category": provider,
                "provider": provider,
                "metadata": full_metadata,
            }

    # Convert string list to dict list
    result = []
    for name in model_names:
        if name in model_lookup:
            result.append(model_lookup[name])
        else:
            # Model not found in registry, create basic entry with minimal required metadata
            result.append(
                {
                    "name": name,
                    "provider": "Unknown",
                    "metadata": {
                        "model_class": "ChatOpenAI",  # Default fallback
                        "model_name_param": "model",
                        "api_key_param": "api_key",
                    },
                }
            )

    return result


def get_llm(
    model,
    user_id: UUID | str | None,
    api_key=None,
    temperature=None,
    *,
    stream=False,
    max_tokens=None,
    watsonx_url=None,
    watsonx_project_id=None,
    ollama_base_url=None,
) -> Any:
    # Coerce provider-specific string params (Message/Data may leak through StrInput)
    ollama_base_url = _to_str(ollama_base_url)
    watsonx_url = _to_str(watsonx_url)
    watsonx_project_id = _to_str(watsonx_project_id)

    # Check if model is already a BaseLanguageModel instance (from a connection)
    try:
        from langchain_core.language_models import BaseLanguageModel

        if isinstance(model, BaseLanguageModel):
            # Model is already instantiated, return it directly
            return model
    except ImportError:
        pass

    # Safely extract model configuration
    if not model or not isinstance(model, list) or len(model) == 0:
        msg = "A model selection is required"
        raise ValueError(msg)

    # Extract the first model (only one expected)
    model = model[0]

    # Extract model configuration from metadata
    model_name = model.get("name")
    provider = model.get("provider")
    metadata = model.get("metadata", {})

    # Get model class and parameter names from metadata
    api_key_param = metadata.get("api_key_param", "api_key")

    # Get API key from user input or global variables
    api_key = get_api_key_for_provider(user_id, provider, api_key)

    # Validate API key (Ollama doesn't require one)
    if not api_key and provider != "Ollama":
        # Get the correct variable name from the provider variable mapping
        provider_variable_map = get_model_provider_variable_mapping()
        variable_name = provider_variable_map.get(provider, f"{provider.upper().replace(' ', '_')}_API_KEY")
        msg = (
            f"{provider} API key is required when using {provider} provider. "
            f"Please provide it in the component or configure it globally as {variable_name}."
        )
        raise ValueError(msg)

    # Get model class from metadata
    model_class_name = metadata.get("model_class")
    if not model_class_name:
        msg = f"No model class defined for {model_name}"
        raise ValueError(msg)
    model_class = get_model_class(model_class_name)
    model_name_param = metadata.get("model_name_param", "model")

    # Check if this is a reasoning model that doesn't support temperature
    reasoning_models = metadata.get("reasoning_models", [])
    if model_name in reasoning_models:
        temperature = None

    # Build kwargs dynamically
    kwargs = {
        model_name_param: model_name,
        "streaming": stream,
        api_key_param: api_key,
    }

    if temperature is not None:
        kwargs["temperature"] = temperature

    # Add max_tokens with provider-specific field name (only when a valid integer >= 1)
    if max_tokens is not None and max_tokens != "":
        try:
            max_tokens_int = int(max_tokens)
            if max_tokens_int >= 1:
                max_tokens_param = metadata.get("max_tokens_field_name", "max_tokens")
                kwargs[max_tokens_param] = max_tokens_int
        except (TypeError, ValueError):
            pass  # Skip invalid max_tokens (e.g. empty string from form input)

    # Enable streaming usage for providers that support it
    if provider in ["OpenAI", "Anthropic"]:
        kwargs["stream_usage"] = True

    # Add provider-specific parameters
    if provider == "IBM WatsonX":
        # For watsonx, url and project_id are required parameters
        # Try database first, then component values, then environment variables
        url_param = metadata.get("url_param", "url")
        project_id_param = metadata.get("project_id_param", "project_id")

        # Get all provider variables from database
        provider_vars = get_all_variables_for_provider(user_id, provider)

        # Priority: component value > database value > env var
        watsonx_url_value = (
            watsonx_url if watsonx_url else provider_vars.get("WATSONX_URL") or os.environ.get("WATSONX_URL")
        )
        watsonx_project_id_value = (
            watsonx_project_id
            if watsonx_project_id
            else provider_vars.get("WATSONX_PROJECT_ID") or os.environ.get("WATSONX_PROJECT_ID")
        )

        has_url = bool(watsonx_url_value)
        has_project_id = bool(watsonx_project_id_value)

        if has_url and has_project_id:
            # Both provided - add them to kwargs
            kwargs[url_param] = watsonx_url_value
            kwargs[project_id_param] = watsonx_project_id_value
        elif has_url or has_project_id:
            # Only one provided - this is a misconfiguration
            missing = "project ID (WATSONX_PROJECT_ID)" if has_url else "URL (WATSONX_URL)"
            provided = "URL" if has_url else "project ID"
            msg = (
                f"IBM WatsonX requires both a URL and project ID. "
                f"You provided a watsonx {provided} but no {missing}. "
                f"Please configure the missing value in the component or set the environment variable."
            )
            raise ValueError(msg)
        # else: neither provided - let ChatWatsonx handle it (will fail with its own error)
    elif provider == "Ollama":
        # For Ollama, handle custom base_url with database > component > env var fallback
        base_url_param = metadata.get("base_url_param", "base_url")

        # Get all provider variables from database
        provider_vars = get_all_variables_for_provider(user_id, provider)

        # Priority: component value > database value > env var
        ollama_base_url_value = (
            ollama_base_url
            if ollama_base_url
            else provider_vars.get("OLLAMA_BASE_URL") or os.environ.get("OLLAMA_BASE_URL")
        )
        if ollama_base_url_value:
            kwargs[base_url_param] = ollama_base_url_value

    try:
        return model_class(**kwargs)
    except Exception as e:
        # If instantiation fails and it's WatsonX, provide additional context
        if provider == "IBM WatsonX" and ("url" in str(e).lower() or "project" in str(e).lower()):
            msg = (
                f"Failed to initialize IBM WatsonX model: {e}\n\n"
                "IBM WatsonX requires additional configuration parameters (API endpoint URL and project ID). "
                "This component may not support these parameters. "
                "Consider using the 'Language Model' component instead, which fully supports IBM WatsonX."
            )
            raise ValueError(msg) from e
        # Re-raise the original exception for other cases
        raise


def update_model_options_in_build_config(
    component: Any,
    build_config: dict,
    cache_key_prefix: str,
    get_options_func: Callable,
    field_name: str | None = None,
    field_value: Any = None,
    model_field_name: str = "model",
) -> dict:
    """Helper function to update build config with cached model options.

    Uses instance-level caching to avoid expensive database calls on every field change.
    Cache is refreshed when:
    - api_key changes (may enable/disable providers)
    - Initial load (field_name is None)
    - Cache is empty or expired
    - Model field is being refreshed (field_name == model_field_name)

    If the component specifies static options, those are preserved and not refreshed.

    Args:
        component: Component instance with cache, user_id, and log attributes
        build_config: The build configuration dict to update
        cache_key_prefix: Prefix for the cache key (e.g., "language_model_options" or "embedding_model_options")
        get_options_func: Function to call to get model options (e.g., get_language_model_options)
        field_name: The name of the field being changed, if any
        field_value: The current value of the field being changed, if any
        model_field_name: The name of the model field in the build_config (default: "model")

    Returns:
        Updated build_config dict with model options and providers set
    """
    import time

    # Check if component specified static options - if so, preserve them
    # The cache key for static options detection
    static_options_cache_key = f"{cache_key_prefix}_static_options_detected"

    # On initial load, check if the component has static options
    if field_name is None and static_options_cache_key not in component.cache:
        # Check if the model field in build_config already has options set
        existing_options = build_config.get("model", {}).get("options")
        if existing_options:
            # Component specified static options - mark them as static
            component.cache[static_options_cache_key] = True
        else:
            component.cache[static_options_cache_key] = False

    # If component has static options, skip the refresh logic entirely
    if component.cache.get(static_options_cache_key, False):
        # Static options - don't override them
        # Just handle the visibility logic and return
        if field_value == "connect_other_models":
            # User explicitly selected "Connect other models", show the handle
            if cache_key_prefix == "embedding_model_options":
                build_config["model"]["input_types"] = ["Embeddings"]
            else:
                build_config["model"]["input_types"] = ["LanguageModel"]
        else:
            # Default case or model selection: hide the handle
            build_config["model"]["input_types"] = []
        return build_config

    # Cache key based on user_id
    cache_key = f"{cache_key_prefix}_{component.user_id}"
    cache_timestamp_key = f"{cache_key}_timestamp"
    cache_ttl = 30  # 30 seconds TTL to catch global variable changes faster

    # Check if cache is expired
    cache_expired = False
    if cache_timestamp_key in component.cache:
        time_since_cache = time.time() - component.cache[cache_timestamp_key]
        cache_expired = time_since_cache > cache_ttl

    # Check if we need to refresh
    should_refresh = (
        field_name == "api_key"  # API key changed
        or field_name is None  # Initial load
        or field_name == model_field_name  # Model field refresh button clicked
        or cache_key not in component.cache  # Cache miss
        or cache_expired  # Cache expired
    )

    if should_refresh:
        # Fetch options based on user's enabled models
        try:
            options = get_options_func(user_id=component.user_id)
            # Cache the results with timestamp
            component.cache[cache_key] = {"options": options}
            component.cache[cache_timestamp_key] = time.time()
        except KeyError as exc:
            # If we can't get user-specific options, fall back to empty
            component.log("Failed to fetch user-specific model options: %s", exc)
            component.cache[cache_key] = {"options": []}
            component.cache[cache_timestamp_key] = time.time()

    # Use cached results
    cached = component.cache.get(cache_key, {"options": []})
    build_config[model_field_name]["options"] = cached["options"]

    # Set default value on initial load when field is empty
    # Fetch from user's default model setting in the database
    if not field_value or field_value == "":
        options = cached.get("options", [])
        if options:
            # Determine model type based on cache_key_prefix
            model_type = "embeddings" if cache_key_prefix == "embedding_model_options" else "language"

            # Try to get user's default model from the variable service
            default_model_name = None
            default_model_provider = None
            try:

                async def _get_default_model():
                    async with session_scope() as session:
                        variable_service = get_variable_service()
                        if variable_service is None:
                            return None, None
                        from langflow.services.variable.service import DatabaseVariableService

                        if not isinstance(variable_service, DatabaseVariableService):
                            return None, None

                        # Variable names match those in the API
                        var_name = (
                            "__default_embedding_model__"
                            if model_type == "embeddings"
                            else "__default_language_model__"
                        )

                        try:
                            var = await variable_service.get_variable_object(
                                user_id=UUID(component.user_id)
                                if isinstance(component.user_id, str)
                                else component.user_id,
                                name=var_name,
                                session=session,
                            )
                            if var and var.value:
                                parsed_value = json.loads(var.value)
                                if isinstance(parsed_value, dict):
                                    return parsed_value.get("model_name"), parsed_value.get("provider")
                        except (ValueError, json.JSONDecodeError, TypeError):
                            # Variable not found or invalid format
                            logger.info(
                                "Variable not found or invalid format: var_name=%s, user_id=%s, model_type=%s",
                                var_name,
                                component.user_id,
                                model_type,
                                exc_info=True,
                            )
                        return None, None

                default_model_name, default_model_provider = run_until_complete(_get_default_model())
            except Exception:  # noqa: BLE001
                # If we can't get default model, continue without it
                logger.info("Failed to get default model, continue without it", exc_info=True)

            # Find the default model in options
            default_model = None
            if default_model_name and default_model_provider:
                # Look for the user's preferred default model
                for opt in options:
                    if opt.get("name") == default_model_name and opt.get("provider") == default_model_provider:
                        default_model = opt
                        break

            # If user's default not found, fallback to first option
            if not default_model and options:
                default_model = options[0]

            # Set the value
            if default_model:
                build_config[model_field_name]["value"] = [default_model]

    # Handle visibility of the model input handle based on selection
    if cache_key_prefix == "embedding_model_options":
        build_config[model_field_name]["input_types"] = ["Embeddings"]
    else:
        build_config[model_field_name]["input_types"] = ["LanguageModel"]

    return build_config
