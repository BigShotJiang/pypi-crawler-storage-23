"""Configuration for the Blueprint MCP Server.

The VS Code extension handles all Blueprint-specific IBM i configuration
(getConfig / setConfig / loadGraph) by talking to the backend directly.

The MCP server only needs connection credentials and transport settings,
all supplied via environment variables.

Environment variables:
    BLUEPRINT_API_URL:   Base URL for the Blueprint API (required)
    BLUEPRINT_API_KEY:   API key for authenticating with the Blueprint API (optional, hidden from LLM)
    BLUEPRINT_HOST:      Host to bind the HTTP server to (default: 0.0.0.0)
    BLUEPRINT_PORT:      Port to bind the HTTP server to (default: 8000)
"""

from __future__ import annotations

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Server configuration loaded from environment variables."""

    api_base_url: str = Field(
        default="http://MY_IBM_I:60111/services/api",
        alias="BLUEPRINT_API_URL",
        description="Base URL for the Blueprint API",
    )
    api_key: str | None = Field(
        default=None,
        alias="BLUEPRINT_API_KEY",
        description="API key for authenticating with the Blueprint API",
    )
    host: str = Field(
        default="0.0.0.0",
        alias="BLUEPRINT_HOST",
        description="Host to bind the HTTP server to",
    )
    port: int = Field(
        default=8000,
        alias="BLUEPRINT_PORT",
        description="Port to bind the HTTP server to",
    )

    model_config = {"env_prefix": "", "case_sensitive": True}


settings = Settings()
