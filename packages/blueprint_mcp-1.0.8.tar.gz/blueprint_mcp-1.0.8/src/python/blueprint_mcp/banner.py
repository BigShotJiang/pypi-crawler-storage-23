"""Custom startup banner for Sitemule Blueprint MCP Server.

Replaces the default FastMCP banner with Sitemule branding.
Uses the same Rich-based rendering approach.
"""

from importlib.metadata import version as pkg_version

from rich.align import Align
from rich.console import Console, Group
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# ── Block-art for "BLUEPRINT" ─────────────────────────────────────────────
# Uses the box-drawing style from banner.txt

_ART_LINES = [
    "██████╗ ██╗     ██╗   ██╗███████╗██████╗ ██████╗ ██╗███╗   ██╗████████╗",
    "██╔══██╗██║     ██║   ██║██╔════╝██╔══██╗██╔══██╗██║████╗  ██║╚══██╔══╝",
    "██████╔╝██║     ██║   ██║█████╗  ██████╔╝██████╔╝██║██╔██╗ ██║   ██║   ",
    "██╔══██╗██║     ██║   ██║██╔══╝  ██╔═══╝ ██╔══██╗██║██║╚██╗██║   ██║   ",
    "██████╔╝███████╗╚██████╔╝███████╗██║     ██║  ██║██║██║ ╚████║   ██║   ",
    "╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝╚═╝     ╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝   ╚═╝   ",
]


def _blue_gradient(text: str) -> str:
    """Apply a cyan→blue ANSI true-color gradient to visible characters."""
    visible_count = sum(1 for ch in text if ch not in (" ", "\n"))
    if visible_count == 0:
        return text

    parts: list[str] = []
    vi = 0
    for ch in text:
        if ch in (" ", "\n"):
            parts.append(ch)
        else:
            # Green channel sweeps 198 → 100 (bright cyan-blue → deeper blue)
            t = vi / max(visible_count - 1, 1)
            g = int(198 - 98 * t)
            parts.append(f"\x1b[38;2;0;{g};255m{ch}")
            vi += 1
    parts.append("\x1b[39m")
    return "".join(parts)


_LOGO = "\n".join(_blue_gradient(line) for line in _ART_LINES)


def log_banner() -> None:
    """Print the Sitemule Blueprint MCP startup banner to stderr."""
    try:
        ver = pkg_version("blueprint-mcp")
    except Exception:
        ver = "dev"

    logo_text = Text.from_ansi(_LOGO, no_wrap=True)
    title_text = Text("Sitemule Blueprint MCP", style="bold blue")

    info_table = Table.grid(padding=(0, 1))
    info_table.add_column(style="bold", justify="center")
    info_table.add_column(style="cyan", justify="left")
    info_table.add_column(style="dim", justify="left")

    info_table.add_row("🖥", " Server:", f"Blueprint MCP {ver}")
    info_table.add_row("🌐", " Visit:", "https://sitemule.com/blueprint")

    panel_content = Group(
        "",
        Align.center(logo_text),
        "",
        Align.center(title_text),
        "",
        Align.center(info_table),
    )

    panel = Panel(
        panel_content,
        border_style="dim",
        padding=(1, 4),
    )

    console = Console(stderr=True)
    console.print(Group("\n", Align.center(panel), "\n"))
