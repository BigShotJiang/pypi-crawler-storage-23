"""Sitemule Blueprint MCP Server.

Access IBM i program analysis tools via the Model Context Protocol.
"""

from importlib.metadata import version as _v

__version__ = _v("blueprint-mcp")
