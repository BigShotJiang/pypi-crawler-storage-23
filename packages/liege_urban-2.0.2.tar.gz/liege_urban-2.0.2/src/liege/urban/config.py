# -*- coding: utf-8 -*-

PROJECTNAME = "liege.urban"

LICENCE_FINAL_STATES = [
    'accepted',
    'acceptable',
    'acceptable_with_conditions',
    'authorized',
    'inacceptable',
    'refused',
    'suspension',
    'retired',
    'abandoned',
    'filed_away',
    'favorable',
    'defavorable',
]
