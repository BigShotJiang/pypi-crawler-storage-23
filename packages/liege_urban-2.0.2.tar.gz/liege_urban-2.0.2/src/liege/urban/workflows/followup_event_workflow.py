# -*- coding: utf-8 -*-

from liege.urban.workflows.acknowledgment_workflow import StateRolesMapping


# use the same roles mapping than acknowledgment workflow
StateRolesMapping
