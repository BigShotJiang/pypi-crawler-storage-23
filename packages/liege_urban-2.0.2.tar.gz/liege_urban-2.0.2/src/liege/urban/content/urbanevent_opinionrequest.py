# -*- coding: utf-8 -*-

from Products.urban.UrbanEventOpinionRequest import UrbanEventOpinionRequest

UrbanEventOpinionRequest.__ac_local_roles_block__ = True  # disable local roles inheritance and let the workflow handle the permissions.
