# AGENTS.md

Guidance for AI coding agents working in this repository.

## Overview

**steerdev-agent** is a Python CLI that orchestrates AI coding agents via subprocess execution, streaming events to the steerdev.com API. It fetches tasks, builds prompts, launches agents (Claude Code, Codex, Aider), and reports activity.

## Project Structure

```
src/steerdev_agent/
├── cli.py               # Typer CLI commands
├── runner.py             # Main orchestrator
├── daemon.py             # Daemon mode
├── version.py            # Version management
├── integration.py        # Integration utilities
├── api/                  # API clients (tasks, sessions, events, workflows, etc.)
├── config/               # Pydantic config models and settings
├── executor/             # Agent subprocess execution (base, claude, stream)
├── workflow/             # Multi-phase workflow execution and memory
├── prompt/               # Prompt building and templates
├── setup/                # Project setup and templates
├── handlers/             # Task/PRD handlers
└── git/                  # Git utilities
```

## Development

- **Python 3.12+** with **uv** package manager
- `uv sync` — install deps
- `uv run pytest` — run tests
- `uv run ruff check . && uv run ruff format .` — lint and format
- `uv run basedpyright` — type check

## Conventions

- Type hints on all function signatures
- Pydantic v2 for data models and config
- Async/await for I/O (HTTP, subprocess)
- `loguru` for logging
- Specific exception classes (no bare `except`)
- Absolute imports (`from steerdev_agent.config.models import ...`)
- Import order: stdlib, third-party, local

## Key Integration Points

- **steerdev.com API**: Bearer auth via `STEERDEV_API_KEY`. Events POSTed to `/api/v1/sessions/{id}/events`.
- **Executor**: Launches agents as subprocesses with `--output-format stream-json`. Parses newline-delimited JSON events.
- **Config**: YAML config file + environment variable overrides.

## Environment Variables

| Variable | Purpose |
| --- | --- |
| `STEERDEV_API_KEY` | API authentication |
| `STEERDEV_PROJECT_ID` | Default project |
