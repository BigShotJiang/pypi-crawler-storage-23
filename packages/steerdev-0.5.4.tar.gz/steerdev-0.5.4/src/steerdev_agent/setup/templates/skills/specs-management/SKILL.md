# Specs Management Skill

This skill enables interaction with specification documents (PRDs) via the steerdev.com API.

## Spec Lifecycle

Specs follow a workflow from draft to completion:

```
DRAFT -> ANALYZING -> CLARIFYING -> PLANNING -> READY -> COMPLETED
```

| Status | Description |
|--------|-------------|
| `draft` | Initial spec, not yet analyzed |
| `analyzing` | AI is analyzing requirements |
| `clarifying` | Waiting for clarification |
| `planning` | Creating implementation plan |
| `ready` | Ready for task generation |
| `completed` | Spec has been implemented |

## When to Use

- **Reading requirements**: Fetch spec content to understand what to build
- **Updating progress**: Update spec status as work progresses
- **Creating specs**: Document new requirements discovered during work
- **Listing specs**: Find specs in a project to work on

## Available Commands

### List Specs

```bash
steerdev specs list [--project-id PROJECT_ID] [--status STATUS] [--limit N] [--compact]
```

List specification documents with optional filters.

**Options:**
- `--project-id`, `-p`: Filter by project ID (or use `STEERDEV_PROJECT_ID` env var)
- `--status`, `-s`: Filter by status (`draft`, `analyzing`, `clarifying`, `planning`, `ready`, `completed`)
- `--limit`, `-l`: Maximum number of specs to return (default: 20)
- `--compact`, `-c`: Show truncated IDs instead of full UUIDs

**Example:**
```bash
# List all ready specs
steerdev specs list --status ready

# List specs in a specific project
steerdev specs list --project-id abc123...
```

### Get Spec Details

```bash
steerdev specs get SPEC_ID
```

Get full details of a specification document including content.

**Arguments:**
- `SPEC_ID`: Spec ID (UUID) to fetch

**Example:**
```bash
steerdev specs get abc123-def456-...
```

**Returns:**
- Linear ID (if synced)
- Title
- Status
- Content (markdown)
- Project ID
- Source information

### Update Spec

```bash
steerdev specs update SPEC_ID [OPTIONS]
```

Update a spec's content, status, or title.

**Options:**
- `--content`: New content (markdown)
- `--status`, `-s`: New status
- `--title`, `-t`: New title

**Example:**
```bash
# Update status to ready
steerdev specs update abc123... --status ready

# Update content
steerdev specs update abc123... --content "# Updated Requirements

## Overview
..."

# Update title
steerdev specs update abc123... --title "New Feature Spec"
```

### Create Spec

```bash
steerdev specs create --title "..." --content "..." [OPTIONS]
```

Create a new specification document.

**Options:**
- `--title`, `-t`: Spec title (required)
- `--content`: Spec content in markdown (required)
- `--project-id`, `-p`: Project ID (or use `STEERDEV_PROJECT_ID` env var)
- `--source`, `-s`: Source of the spec (default: "agent")

**Example:**
```bash
steerdev specs create \
  --title "User Authentication Feature" \
  --content "# User Authentication

## Overview
Implement JWT-based authentication...

## Requirements
1. Login endpoint
2. Logout endpoint
3. Token refresh
..."
```

## Workflow Example

```bash
# List specs ready for implementation
steerdev specs list --status ready

# Get full spec details
steerdev specs get abc123...

# After reading, create tasks from the spec
steerdev tasks create \
  --title "Implement login endpoint" \
  --prompt "Based on spec abc123, implement..." \
  --spec-id abc123...

# Update spec status when all tasks are done
steerdev specs update abc123... --status completed
```

## Environment

Requires `STEERDEV_API_KEY` environment variable to be set.

**Optional:**
- `STEERDEV_API_ENDPOINT`: Override the API base URL (default: https://platform.steerdev.com/api/v1)
- `STEERDEV_PROJECT_ID`: Default project ID for all commands
