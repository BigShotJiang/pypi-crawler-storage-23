# Project Context Skill

This skill provides access to project context information via the steerdev.com API.

Project context includes tech stack, patterns, conventions, and structure information that helps AI agents understand and work effectively within a codebase.

## When to Use

- **Starting work on a project**: Get context to understand tech stack and conventions
- **Before making architectural decisions**: Check existing patterns
- **After major codebase changes**: Refresh context to update cached information

## Available Commands

### Get Context

```bash
steerdev context get [--project-id PROJECT_ID]
```

Retrieve project context including tech stack, patterns, and structure.

**Options:**
- `--project-id`, `-p`: Project ID (or use `STEERDEV_PROJECT_ID` env var)

**Example:**
```bash
# Get context for the current project
steerdev context get

# Get context for a specific project
steerdev context get --project-id abc123...
```

**Returns:**
- **Tech Stack**: Languages, frameworks, and tools used
- **Patterns**: Common code patterns in the project
- **Conventions**: Coding conventions and style guidelines
- **Structure**: Project directory structure
- **Dependencies**: Key dependencies and versions

### Refresh Context

```bash
steerdev context refresh [--project-id PROJECT_ID]
```

Force a refresh of cached project context.

Use this after making significant changes to the codebase structure or dependencies.

**Options:**
- `--project-id`, `-p`: Project ID (or use `STEERDEV_PROJECT_ID` env var)

**Example:**
```bash
# Refresh context for the current project
steerdev context refresh
```

**Note:** Context refresh happens asynchronously. Run `context get` after a moment to see updated information.

## Workflow Example

```bash
# At the start of a new task, get project context
steerdev context get

# Use the context to understand:
# - What framework to use for new features
# - What coding patterns to follow
# - Where to place new files

# After adding new dependencies or changing structure
steerdev context refresh

# Verify the refresh
steerdev context get
```

## Context Information

The context includes:

### Tech Stack
Languages and frameworks used in the project:
- Programming languages (Python, TypeScript, etc.)
- Web frameworks (FastAPI, Next.js, etc.)
- Database technologies
- Build tools

### Patterns
Common patterns observed in the codebase:
- API patterns (REST, GraphQL)
- State management patterns
- Error handling patterns
- Testing patterns

### Conventions
Project-specific conventions:
- Naming conventions
- File organization
- Import ordering
- Code style preferences

### Structure
Directory structure overview:
- Source directories
- Test directories
- Configuration files
- Key entry points

### Dependencies
Major dependencies and their versions to ensure compatibility.

## Environment

Requires `STEERDEV_API_KEY` environment variable to be set.

**Optional:**
- `STEERDEV_API_ENDPOINT`: Override the API base URL (default: https://platform.steerdev.com/api/v1)
- `STEERDEV_PROJECT_ID`: Default project ID for all commands
