"""Workflow executor for multi-phase task execution."""

from __future__ import annotations

from pathlib import Path
from string import Template
from typing import Any

from loguru import logger
from rich.console import Console

from steerdev_agent.api.events import EventsClient
from steerdev_agent.api.sessions import SessionCreateRequest, SessionsClient
from steerdev_agent.api.workflow_runs import WorkflowRunResponse, WorkflowRunsClient
from steerdev_agent.api.workflows import WorkflowPhaseResponse, WorkflowsClient
from steerdev_agent.config.models import ExecutorConfig
from steerdev_agent.executor import ExecutorFactory
from steerdev_agent.executor.base import EventType, StreamEvent
from steerdev_agent.workflow.memory import PhaseMemory, WorkflowMemoryManager

console = Console()


class WorkflowExecutorError(Exception):
    """Error during workflow execution."""


class WorkflowExecutor:
    """Executes workflow phases sequentially.

    Handles the complete lifecycle of multi-phase workflow execution:
    1. Fetch workflow definition from API
    2. Start workflow run via API
    3. Execute each phase in order
    4. Build prompts with accumulated context
    5. Track phase completion and handle failures
    """

    def __init__(
        self,
        working_directory: str | Path,
        api_key: str | None = None,
        executor_config: ExecutorConfig | None = None,
        model: str | None = None,
        max_turns: int | None = None,
        dry_run: bool = False,
        project_id: str | None = None,
        agent_type: str = "claude",
    ) -> None:
        """Initialize the workflow executor.

        Args:
            working_directory: Directory to run agents in.
            api_key: API key for steerdev.com.
            executor_config: Configuration for the agent executor.
            model: Model override for agents.
            max_turns: Maximum turns per phase.
            dry_run: If True, print commands without executing.
            project_id: Project ID for session tracking.
            agent_type: Agent type for session tracking.
        """
        self.working_directory = Path(working_directory)
        self._api_key = api_key
        self._executor_config = executor_config or ExecutorConfig()
        self.model = model
        self.max_turns = max_turns
        self.dry_run = dry_run
        self.project_id = project_id
        self.agent_type = agent_type

        self._memory_manager = WorkflowMemoryManager(working_directory)
        self._workflows_client: WorkflowsClient | None = None
        self._runs_client: WorkflowRunsClient | None = None
        self._sessions_client: SessionsClient | None = None
        self._events_sent = 0

    async def _get_workflows_client(self) -> WorkflowsClient:
        """Get or create workflows client."""
        if self._workflows_client is None:
            self._workflows_client = WorkflowsClient(api_key=self._api_key)
        return self._workflows_client

    async def _get_runs_client(self) -> WorkflowRunsClient:
        """Get or create workflow runs client."""
        if self._runs_client is None:
            self._runs_client = WorkflowRunsClient(api_key=self._api_key)
        return self._runs_client

    async def _get_sessions_client(self) -> SessionsClient:
        """Get or create sessions client."""
        if self._sessions_client is None:
            self._sessions_client = SessionsClient(api_key=self._api_key)
        return self._sessions_client

    async def close(self) -> None:
        """Close all clients."""
        if self._workflows_client:
            await self._workflows_client.close()
            self._workflows_client = None
        if self._runs_client:
            await self._runs_client.close()
            self._runs_client = None
        if self._sessions_client:
            await self._sessions_client.close()
            self._sessions_client = None

    def _build_phase_prompt(
        self,
        phase: WorkflowPhaseResponse,
        task_context: dict[str, Any],
        accumulated_context: dict[str, Any],
    ) -> str:
        """Build the prompt for a phase.

        Args:
            phase: Phase definition with prompt template.
            task_context: Context from the task being executed.
            accumulated_context: Merged context from previous phases.

        Returns:
            Rendered prompt string.
        """
        # Combine all available context for template substitution
        template_vars = {
            **task_context,
            **accumulated_context,
            "phase_name": phase.name,
            "phase_type": phase.phase_type,
        }

        # Use phase prompt template if available
        if phase.prompt_template:
            try:
                template = Template(phase.prompt_template)
                return template.safe_substitute(template_vars)
            except (KeyError, ValueError) as e:
                logger.warning(f"Template substitution failed: {e}, using raw template")
                return phase.prompt_template

        # Default prompt if no template
        return f"""Execute the '{phase.name}' phase for this task.

Task: {task_context.get("task_title", "Unknown")}

Task Description:
{task_context.get("task_prompt", "No description provided")}

Previous Phase Context:
{accumulated_context if accumulated_context else "No previous context"}

Instructions:
Complete this phase according to its type: {phase.phase_type}
"""

    async def _stream_event_to_api(self, events_client: EventsClient, event: StreamEvent) -> None:
        """Stream an event to the API.

        Args:
            events_client: The events client to use.
            event: The event to stream.
        """
        await events_client.add_event(
            event_type=event.event_type.value,
            data=event.data,
            raw_json=event.raw_json,
            timestamp=event.timestamp,
        )
        self._events_sent += 1

    async def execute_phase(
        self,
        workflow_run: WorkflowRunResponse,
        phase: WorkflowPhaseResponse,
        task_context: dict[str, Any],
        run_id: str,
    ) -> dict[str, Any]:
        """Execute a single phase.

        Args:
            workflow_run: The workflow run being executed.
            phase: Phase to execute.
            task_context: Task context data.
            run_id: Agent run ID for tracking.

        Returns:
            Phase execution result with output_context.
        """
        console.print(f"\n[bold cyan]Phase: {phase.name}[/bold cyan]")
        console.print(f"[dim]Type: {phase.phase_type}[/dim]")

        # Build accumulated context from previous phases
        accumulated_context = self._memory_manager.build_accumulated_context(
            workflow_run.workflow_id, workflow_run.id
        )

        # Build phase prompt
        prompt = self._build_phase_prompt(phase, task_context, accumulated_context)

        if self.dry_run:
            console.print(f"[dim]Would execute with prompt:[/dim]\n{prompt[:200]}...")
            return {"success": True, "output_context": {}}

        # Create session for this phase (for event tracking)
        session_id: str | None = None
        events_client: EventsClient | None = None

        if self.project_id:
            sessions_client = await self._get_sessions_client()
            task_id = task_context.get("task_id")

            request = SessionCreateRequest(
                project_id=self.project_id,
                task_id=task_id,
                agent_type=self.agent_type,
                prompt=prompt,
                working_directory=str(self.working_directory),
                metadata={
                    "workflow_id": workflow_run.workflow_id,
                    "workflow_run_id": workflow_run.id,
                    "phase_id": phase.id,
                    "phase_name": phase.name,
                    "phase_type": phase.phase_type,
                },
            )

            session = await sessions_client.create_session(request)
            if session:
                session_id = session.id
                logger.info(f"Phase session created: {session_id}")

                # Initialize events client
                events_client = EventsClient(
                    session_id=session_id,
                    api_key=self._api_key,
                )
                await events_client.start()

                # Mark session as running
                await sessions_client.mark_running(session_id)
            else:
                logger.warning("Failed to create phase session, events will not be streamed")

        # Create and run executor
        executor = ExecutorFactory.create(
            config=self._executor_config,
            working_directory=str(self.working_directory),
            model=self.model,
            max_turns=self.max_turns,
            dry_run=self.dry_run,
        )

        try:
            await executor.start(prompt)
            console.print("[dim]Agent started, streaming output...[/dim]")

            # Stream and collect events
            result_summary = ""
            async for event in executor.stream_events():
                # Stream event to API if we have an events client
                if events_client:
                    await self._stream_event_to_api(events_client, event)

                if event.event_type == EventType.ASSISTANT:
                    message = event.data.get("message", {})
                    # Handle both dict and string message formats
                    if isinstance(message, dict):
                        content = message.get("content", "")
                    else:
                        content = str(message) if message else ""
                    if isinstance(content, str) and content:
                        # Capture last assistant message as summary
                        result_summary = content[:500]
                        preview = content[:100] + "..." if len(content) > 100 else content
                        console.print(f"[cyan]Assistant:[/cyan] {preview}")

                if event.event_type == EventType.RESULT:
                    result_data = event.data.get("result", {})
                    # Handle both dict and string result formats
                    if isinstance(result_data, dict):
                        result_summary = result_data.get("summary", result_summary)
                    elif isinstance(result_data, str) and result_data:
                        result_summary = result_data[:500]

            # Wait for completion
            exit_code = await executor.wait()

            # Get agent session ID for resume capability
            agent_session_id = executor.session_id

            if exit_code != 0:
                stderr = await executor.get_stderr()
                error_msg = stderr.strip() if stderr else f"Process exited with code {exit_code}"

                # Mark session as failed
                if session_id and self.project_id:
                    sessions_client = await self._get_sessions_client()
                    await sessions_client.mark_failed(
                        session_id,
                        metadata={"error": error_msg, "exit_code": exit_code},
                    )

                return {
                    "success": False,
                    "error": error_msg,
                    "exit_code": exit_code,
                }

            # Mark session as completed
            if session_id and self.project_id:
                sessions_client = await self._get_sessions_client()
                await sessions_client.mark_completed(
                    session_id,
                    agent_session_id=agent_session_id,
                )

            # Build output context from phase execution
            output_context = {
                f"{phase.phase_type}_completed": True,
                f"{phase.phase_type}_summary": result_summary,
            }

            # Save phase memory
            memory = PhaseMemory(
                phase_id=phase.id,
                phase_name=phase.name,
                phase_type=phase.phase_type,
                input_context=accumulated_context,
                output_context=output_context,
                result_summary=result_summary,
            )
            self._memory_manager.save_phase_memory(
                workflow_run.workflow_id, workflow_run.id, memory
            )

            return {
                "success": True,
                "output_context": output_context,
                "result_summary": result_summary,
                "session_id": session_id,
                "events_sent": self._events_sent,
            }

        except Exception as e:
            logger.error(f"Phase execution failed: {e}")

            # Mark session as failed
            if session_id and self.project_id:
                sessions_client = await self._get_sessions_client()
                await sessions_client.mark_failed(
                    session_id,
                    metadata={"error": str(e)},
                )

            return {"success": False, "error": str(e)}

        finally:
            # Close events client (flushes remaining events)
            if events_client:
                await events_client.close()
                logger.info(
                    f"Events flushed for phase {phase.name}, total sent: {self._events_sent}"
                )

            if executor.is_running:
                await executor.stop()

    async def execute_workflow(
        self,
        workflow_id: str,
        task_context: dict[str, Any],
        run_id: str,
    ) -> dict[str, Any]:
        """Execute a complete workflow.

        Args:
            workflow_id: Workflow ID to execute.
            task_context: Context from the task being executed.
            run_id: Agent run ID for tracking.

        Returns:
            Workflow execution result.
        """
        console.print("\n[bold blue]Starting Workflow[/bold blue]")
        console.print(f"[dim]Workflow ID: {workflow_id}[/dim]")

        try:
            # Fetch workflow definition
            workflows_client = await self._get_workflows_client()
            workflow = await workflows_client.get_workflow(workflow_id)

            if not workflow:
                raise WorkflowExecutorError(f"Workflow not found: {workflow_id}")

            console.print(f"[bold]{workflow.name}[/bold]")
            console.print(f"[dim]Phases: {len(workflow.phases)}[/dim]")

            # Sort phases by order
            phases = sorted(workflow.phases, key=lambda p: p.phase_order)

            if not phases:
                raise WorkflowExecutorError("Workflow has no phases defined")

            # Start workflow run via API (skip in dry run)
            runs_client = await self._get_runs_client()
            workflow_run: WorkflowRunResponse | None = None

            if not self.dry_run:
                workflow_run = await runs_client.start_workflow(
                    workflow_id=workflow_id,
                    run_id=run_id,
                    initial_context=task_context,
                )

                if not workflow_run:
                    raise WorkflowExecutorError("Failed to start workflow run")

                console.print(f"[dim]Workflow Run ID: {workflow_run.id}[/dim]")
            else:
                # Create a mock workflow run for dry run
                from datetime import UTC, datetime

                workflow_run = WorkflowRunResponse(
                    id="dry-run-workflow",
                    workflow_id=workflow_id,
                    workflow_name=workflow.name,
                    project_id="dry-run-project",
                    status="running",
                    total_phases=len(phases),
                    created_at=datetime.now(UTC).isoformat(),
                    updated_at=datetime.now(UTC).isoformat(),
                )

            # Execute each phase
            phases_completed = 0
            phases_failed = 0

            for phase in phases:
                result = await self.execute_phase(
                    workflow_run=workflow_run,
                    phase=phase,
                    task_context=task_context,
                    run_id=run_id,
                )

                if result.get("success"):
                    phases_completed += 1
                    console.print(f"[green]Phase '{phase.name}' completed[/green]")

                    # Advance phase via API (skip in dry run)
                    if not self.dry_run:
                        await runs_client.advance_phase(
                            workflow_run_id=workflow_run.id,
                            output_context=result.get("output_context"),
                            result_summary=result.get("result_summary"),
                        )
                else:
                    phases_failed += 1
                    error_msg = result.get("error", "Unknown error")
                    console.print(f"[red]Phase '{phase.name}' failed: {error_msg}[/red]")

                    # Report failure via API (skip in dry run)
                    if not self.dry_run:
                        await runs_client.fail_phase(
                            workflow_run_id=workflow_run.id,
                            error_message=error_msg,
                        )

                    # Check if phase is required
                    if phase.is_required:
                        console.print("[red]Required phase failed, stopping workflow[/red]")
                        break

            # Only cleanup memory on complete success to preserve failed runs for debugging
            workflow_success = phases_failed == 0

            if workflow_success:
                self._memory_manager.cleanup_run(workflow_run.workflow_id, workflow_run.id)
            else:
                run_path = self._memory_manager._get_run_path(
                    workflow_run.workflow_id, workflow_run.id
                )
                logger.info(f"Preserving workflow memory for debugging: {run_path}")

            return {
                "success": workflow_success,
                "workflow_id": workflow_id,
                "workflow_run_id": workflow_run.id,
                "phases_completed": phases_completed,
                "phases_failed": phases_failed,
                "total_phases": len(phases),
            }

        finally:
            await self.close()
