"""Executor module for running AI agents."""

from __future__ import annotations

from typing import TYPE_CHECKING

from steerdev_agent.executor.base import AgentExecutor, StreamEvent
from steerdev_agent.executor.claude import ClaudeExecutor
from steerdev_agent.executor.stream import StreamParser

if TYPE_CHECKING:
    from steerdev_agent.config.models import ExecutorConfig

__all__ = [
    "AgentExecutor",
    "ClaudeExecutor",
    "ExecutorFactory",
    "StreamEvent",
    "StreamParser",
]


class ExecutorFactory:
    """Factory for creating agent executors based on configuration."""

    @staticmethod
    def create(
        config: ExecutorConfig,
        working_directory: str,
        model: str | None = None,
        max_turns: int | None = None,
        dry_run: bool = False,
        worktree_name: str | None = None,
    ) -> AgentExecutor:
        """Create an executor based on the configuration.

        Args:
            config: Executor configuration specifying type and settings.
            working_directory: Directory to run the agent in.
            model: Model override (takes precedence over config).
            max_turns: Maximum number of agent turns.
            dry_run: If True, print command without executing.
            worktree_name: Name for Claude CLI --worktree flag.

        Returns:
            Configured AgentExecutor instance.

        Raises:
            ValueError: If executor type is not supported.
        """
        if config.type == "claude":
            return ClaudeExecutor(
                working_directory=working_directory,
                model=model,
                max_turns=max_turns,
                allowed_tools=config.allowed_tools or None,
                disallowed_tools=config.disallowed_tools or None,
                mcp_config=config.mcp_config,
                permission_mode=config.permission_mode,
                dry_run=dry_run,
                worktree_name=worktree_name,
            )

        raise ValueError(f"Unsupported executor type: {config.type}")
