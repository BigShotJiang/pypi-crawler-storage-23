"""Pydantic models for platform-synced configurations and workflows."""

from typing import Annotated

from pydantic import BaseModel, Field


class SystemPromptConfig(BaseModel):
    """System prompt configuration from platform."""

    id: Annotated[str, Field(description="Config ID")]
    name: Annotated[str, Field(description="Config name")]
    description: Annotated[str | None, Field(default=None, description="Config description")]
    content: Annotated[str, Field(description="System prompt content")]
    version: Annotated[int, Field(default=1, description="Config version")]


class SkillConfig(BaseModel):
    """Skill configuration from platform."""

    id: Annotated[str, Field(description="Config ID")]
    name: Annotated[str, Field(description="Skill name")]
    description: Annotated[str | None, Field(default=None, description="Skill description")]
    content: Annotated[
        dict,
        Field(
            default_factory=dict,
            description="Skill content (tool definitions, instructions, etc.)",
        ),
    ]
    version: Annotated[int, Field(default=1, description="Config version")]


class MCPConfig(BaseModel):
    """MCP server configuration from platform."""

    id: Annotated[str, Field(description="Config ID")]
    name: Annotated[str, Field(description="MCP server name")]
    description: Annotated[str | None, Field(default=None, description="MCP description")]
    content: Annotated[
        dict,
        Field(
            default_factory=dict,
            description="MCP configuration (server_url, tools, auth, etc.)",
        ),
    ]
    version: Annotated[int, Field(default=1, description="Config version")]


class EnvVarsConfig(BaseModel):
    """Environment variables configuration from platform."""

    id: Annotated[str, Field(description="Config ID")]
    name: Annotated[str, Field(description="Config name")]
    description: Annotated[str | None, Field(default=None, description="Config description")]
    variables: Annotated[
        dict[str, str],
        Field(default_factory=dict, description="Environment variables key-value pairs"),
    ]
    version: Annotated[int, Field(default=1, description="Config version")]

    @classmethod
    def from_api_response(cls, data: dict) -> "EnvVarsConfig":
        """Create from API response format."""
        content = data.get("content", {})
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            variables=content.get("variables", {}),
            version=data.get("version", 1),
        )


class PlatformConfig(BaseModel):
    """Aggregated platform configurations synced from API."""

    system_prompts: Annotated[
        list[SystemPromptConfig],
        Field(default_factory=list, description="System prompt configurations"),
    ]
    skills: Annotated[
        list[SkillConfig],
        Field(default_factory=list, description="Skill configurations"),
    ]
    mcps: Annotated[
        list[MCPConfig],
        Field(default_factory=list, description="MCP server configurations"),
    ]
    env_vars: Annotated[
        list[EnvVarsConfig],
        Field(default_factory=list, description="Environment variable configurations"),
    ]
    synced_at: Annotated[str, Field(description="Timestamp of last sync")]

    @classmethod
    def from_api_response(cls, data: dict) -> "PlatformConfig":
        """Create from API sync response."""
        return cls(
            system_prompts=[
                SystemPromptConfig(
                    id=sp["id"],
                    name=sp["name"],
                    description=sp.get("description"),
                    content=sp.get("content", {}).get("prompt", ""),
                    version=sp.get("version", 1),
                )
                for sp in data.get("system_prompts", [])
            ],
            skills=[
                SkillConfig(
                    id=sk["id"],
                    name=sk["name"],
                    description=sk.get("description"),
                    content=sk.get("content", {}),
                    version=sk.get("version", 1),
                )
                for sk in data.get("skills", [])
            ],
            mcps=[
                MCPConfig(
                    id=mcp["id"],
                    name=mcp["name"],
                    description=mcp.get("description"),
                    content=mcp.get("content", {}),
                    version=mcp.get("version", 1),
                )
                for mcp in data.get("mcps", [])
            ],
            env_vars=[EnvVarsConfig.from_api_response(ev) for ev in data.get("env_vars", [])],
            synced_at=data.get("synced_at", ""),
        )

    def get_combined_system_prompt(self) -> str | None:
        """Combine all system prompts into one."""
        if not self.system_prompts:
            return None
        return "\n\n".join(sp.content for sp in self.system_prompts)

    def get_combined_env_vars(self) -> dict[str, str]:
        """Combine all environment variables into one dict."""
        combined: dict[str, str] = {}
        for ev in self.env_vars:
            combined.update(ev.variables)
        return combined


class WorkflowPhaseConfig(BaseModel):
    """Workflow phase configuration from platform."""

    id: Annotated[str, Field(description="Phase ID")]
    name: Annotated[str, Field(description="Phase name")]
    phase_type: Annotated[
        str,
        Field(
            default="custom",
            description="Phase type: plan, implement, test, verify, deploy, custom",
        ),
    ]
    phase_order: Annotated[int, Field(default=0, description="Execution order")]
    prompt_template: Annotated[
        str | None,
        Field(default=None, description="Prompt template with variables"),
    ]
    config_ids: Annotated[
        list[str],
        Field(default_factory=list, description="Config IDs to apply for this phase"),
    ]
    required_for_completion: Annotated[
        bool,
        Field(default=True, description="Whether this phase must complete for workflow success"),
    ]
    can_skip_on_failure: Annotated[
        bool,
        Field(default=False, description="Whether to skip this phase if it fails"),
    ]
    entry_conditions: Annotated[
        dict,
        Field(default_factory=dict, description="Conditions to enter phase"),
    ]
    exit_conditions: Annotated[
        dict,
        Field(default_factory=dict, description="Conditions to exit phase"),
    ]

    def render_prompt(
        self,
        task_title: str = "",
        task_description: str = "",
        context: dict | None = None,
    ) -> str | None:
        """Render prompt template with variables."""
        if not self.prompt_template:
            return None

        prompt = self.prompt_template
        prompt = prompt.replace("{task_title}", task_title)
        prompt = prompt.replace("{task_description}", task_description)

        if context:
            prompt = prompt.replace("{context}", str(context))

        return prompt


class WorkflowConfig(BaseModel):
    """Workflow configuration from platform."""

    id: Annotated[str, Field(description="Workflow ID")]
    name: Annotated[str, Field(description="Workflow name")]
    description: Annotated[str | None, Field(default=None, description="Workflow description")]
    is_default: Annotated[
        bool, Field(default=False, description="Whether this is the default workflow")
    ]
    max_retries_per_phase: Annotated[int, Field(default=3, description="Max retries per phase")]
    phase_timeout_seconds: Annotated[
        int, Field(default=3600, description="Phase timeout in seconds")
    ]
    phases: Annotated[
        list[WorkflowPhaseConfig],
        Field(default_factory=list, description="Ordered list of phases"),
    ]

    @classmethod
    def from_api_response(cls, data: dict) -> "WorkflowConfig":
        """Create from API response."""
        return cls(
            id=data["id"],
            name=data["name"],
            description=data.get("description"),
            is_default=data.get("is_default", False),
            max_retries_per_phase=data.get("max_retries_per_phase", 3),
            phase_timeout_seconds=data.get("phase_timeout_seconds", 3600),
            phases=[
                WorkflowPhaseConfig(
                    id=p["id"],
                    name=p["name"],
                    phase_type=p.get("phase_type", "custom"),
                    phase_order=p.get("phase_order", 0),
                    prompt_template=p.get("prompt_template"),
                    config_ids=p.get("config_ids", []),
                    required_for_completion=p.get("required_for_completion", True),
                    can_skip_on_failure=p.get("can_skip_on_failure", False),
                    entry_conditions=p.get("entry_conditions", {}),
                    exit_conditions=p.get("exit_conditions", {}),
                )
                for p in data.get("phases", [])
            ],
        )

    def get_phase_by_order(self, order: int) -> WorkflowPhaseConfig | None:
        """Get phase by order number."""
        for phase in self.phases:
            if phase.phase_order == order:
                return phase
        return None

    def get_phase_by_id(self, phase_id: str) -> WorkflowPhaseConfig | None:
        """Get phase by ID."""
        for phase in self.phases:
            if phase.id == phase_id:
                return phase
        return None

    def get_next_phase(self, current_phase_id: str) -> WorkflowPhaseConfig | None:
        """Get the next phase after the current one."""
        current_phase = self.get_phase_by_id(current_phase_id)
        if not current_phase:
            return None

        next_order = current_phase.phase_order + 1
        return self.get_phase_by_order(next_order)
