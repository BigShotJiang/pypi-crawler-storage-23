"""Pydantic configuration models for steerdev."""

from pathlib import Path
from typing import Annotated

import yaml
from pydantic import BaseModel, Field


class WorktreeConfig(BaseModel):
    """Git worktree isolation configuration.

    When enabled, the Claude CLI --worktree flag is used to run each task
    in an isolated git worktree. Worktree lifecycle is managed by Claude CLI.
    """

    enabled: Annotated[
        bool,
        Field(default=False, description="Enable Claude CLI --worktree isolation per task"),
    ]


class AgentConfig(BaseModel):
    """Configuration for the CLI coding agent."""

    model: Annotated[
        str | None,
        Field(
            default=None,
            description="Model to use (e.g., claude-sonnet-4-20250514)",
        ),
    ]
    max_turns: Annotated[
        int | None,
        Field(
            default=None,
            description="Maximum number of agent turns",
        ),
    ]
    timeout_seconds: Annotated[
        int,
        Field(default=3600, ge=60, description="Maximum execution time in seconds"),
    ]
    workflow_id: Annotated[
        str | None,
        Field(
            default=None,
            description="Workflow ID for multi-phase task execution",
        ),
    ]


class ExecutorConfig(BaseModel):
    """Configuration for the agent executor."""

    type: Annotated[
        str,
        Field(
            default="claude",
            description="Executor type (claude, codex, aider)",
        ),
    ]
    permission_mode: Annotated[
        str,
        Field(
            default="dangerously-skip-permissions",
            description="Permission mode for the executor",
        ),
    ]
    allowed_tools: Annotated[
        list[str],
        Field(
            default_factory=list,
            description="List of tools to allow (empty = all allowed)",
        ),
    ]
    disallowed_tools: Annotated[
        list[str],
        Field(
            default_factory=list,
            description="List of tools to disallow",
        ),
    ]
    mcp_config: Annotated[
        str | None,
        Field(
            default=None,
            description="Path to MCP config file",
        ),
    ]


class APIConfig(BaseModel):
    """Configuration for steerdev.com API."""

    api_endpoint: Annotated[
        str,
        Field(
            default="https://platform.steerdev.com/api/v1",
            description="API endpoint for steerdev.com",
        ),
    ]
    api_key_env: Annotated[
        str,
        Field(
            default="STEERDEV_API_KEY",
            description="Environment variable name for API key",
        ),
    ]
    project_id_env: Annotated[
        str,
        Field(
            default="STEERDEV_PROJECT_ID",
            description="Environment variable name for project ID",
        ),
    ]


class EventsConfig(BaseModel):
    """Configuration for event streaming to API."""

    batch_size: Annotated[
        int,
        Field(default=10, ge=1, le=100, description="Number of events to batch before sending"),
    ]
    flush_interval_seconds: Annotated[
        float,
        Field(default=5.0, ge=1.0, description="Maximum seconds between flushes"),
    ]


class DaemonConfig(BaseModel):
    """Configuration for daemon (persistent agent) mode.

    When running in daemon mode, the agent polls for commands from the API
    and falls back to the task queue when idle.
    """

    poll_interval_seconds: Annotated[
        float,
        Field(default=5.0, ge=1.0, description="Seconds between command queue polls when busy"),
    ]
    heartbeat_interval_seconds: Annotated[
        float,
        Field(default=30.0, ge=10.0, description="Seconds between heartbeat updates"),
    ]
    idle_poll_interval_seconds: Annotated[
        float,
        Field(default=10.0, ge=1.0, description="Seconds between polls when idle (no commands)"),
    ]
    max_consecutive_errors: Annotated[
        int,
        Field(default=5, ge=1, description="Exit after this many consecutive errors"),
    ]
    command_timeout_seconds: Annotated[
        int,
        Field(default=3600, ge=60, description="Timeout for individual command execution"),
    ]
    auto_fetch_tasks: Annotated[
        bool,
        Field(default=True, description="Fall back to task queue when command queue is empty"),
    ]


class SteerDevConfig(BaseModel):
    """Main configuration for steerdev.

    This config focuses on:
    - Agent runtime settings (timeout, model)
    - API connection settings
    - Event streaming settings
    - Executor settings
    - Daemon mode settings
    """

    agent: Annotated[
        AgentConfig,
        Field(default_factory=AgentConfig, description="Agent configuration"),
    ]
    api: Annotated[
        APIConfig,
        Field(default_factory=APIConfig, description="API configuration"),
    ]
    events: Annotated[
        EventsConfig,
        Field(default_factory=EventsConfig, description="Event streaming configuration"),
    ]
    executor: Annotated[
        ExecutorConfig,
        Field(default_factory=ExecutorConfig, description="Executor configuration"),
    ]
    worktrees: Annotated[
        WorktreeConfig,
        Field(default_factory=WorktreeConfig, description="Git worktree isolation configuration"),
    ]
    daemon: Annotated[
        DaemonConfig,
        Field(
            default_factory=DaemonConfig, description="Daemon (persistent agent) mode configuration"
        ),
    ]

    @classmethod
    def from_yaml(cls, path: str | Path) -> "SteerDevConfig":
        """Load configuration from a YAML file.

        Args:
            path: Path to the YAML configuration file.

        Returns:
            Parsed SteerDevConfig instance.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            yaml.YAMLError: If the YAML is invalid.
            ValidationError: If the configuration is invalid.
        """
        path = Path(path)
        with path.open() as f:
            data = yaml.safe_load(f)
        return cls.model_validate(data or {})

    def to_yaml(self, path: str | Path) -> None:
        """Save configuration to a YAML file.

        Args:
            path: Path to save the YAML configuration file.
        """
        path = Path(path)
        with path.open("w") as f:
            yaml.safe_dump(
                self.model_dump(mode="json"),
                f,
                default_flow_style=False,
                sort_keys=False,
            )
