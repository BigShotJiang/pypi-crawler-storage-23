"""Activity API client for SteerDev Agent.

Provides methods for self-reporting progress/blockers and
querying activity history.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from steerdev_agent.api.client import (
    SteerDevClient,
    get_agent_id,
    get_agent_name,
)

console = Console()


# Valid activity event types for self-reporting
VALID_EVENT_TYPES = [
    "progress",  # Progress update
    "blocker",  # Blocked on something
    "question",  # Need clarification
    "milestone",  # Reached a milestone
    "error",  # Encountered an error
    "warning",  # Warning/heads-up
    "info",  # General information
]


class ActivityEvent(BaseModel):
    """Activity event model."""

    id: str
    event_type: str
    message: str
    timestamp: str
    run_id: str | None = None
    session_name: str | None = None
    agent_id: str | None = None
    agent_name: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ActivityListResponse(BaseModel):
    """Response model for activity list."""

    events: list[ActivityEvent]
    total: int
    limit: int
    offset: int


class ActivityClient(SteerDevClient):
    """Client for activity reporting and querying.

    Provides methods for agents to self-report progress,
    blockers, and other activity events.
    """

    def report(
        self,
        event_type: str,
        message: str,
        metadata: dict[str, Any] | None = None,
        run_id: str | None = None,
        session_name: str | None = None,
    ) -> bool:
        """Report an activity event.

        Args:
            event_type: Type of event (progress, blocker, question, etc.).
            message: Human-readable message describing the event.
            metadata: Additional metadata for the event.
            run_id: Optional run ID to associate with.
            session_name: Optional session name.

        Returns:
            True if the event was reported successfully.
        """
        agent_id = get_agent_id()
        agent_name = get_agent_name() or "SteerDev Agent"

        event = {
            "event_type": event_type,
            "message": message,
            "timestamp": datetime.now(UTC).isoformat(),
            "metadata": metadata or {},
        }

        if run_id:
            event["run_id"] = run_id
        if session_name:
            event["session_name"] = session_name
        if agent_id:
            event["agent_id"] = agent_id

        request_body = {
            "agent_name": agent_name,
            "application": "claude_code",
            "events": [event],
        }

        console.print(f"Reporting activity to {self.api_base}/activity/report")
        response = self.post("/activity/report", json=request_body)

        if response.status_code not in (200, 201, 202):
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return False

        return True

    def query(
        self,
        run_id: str | None = None,
        event_type: str | None = None,
        limit: int = 20,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        """Query activity history.

        Args:
            run_id: Filter by run ID.
            event_type: Filter by event type.
            limit: Maximum number of events to return.
            offset: Offset for pagination.

        Returns:
            List of activity event dicts.
        """
        params: dict[str, str | int] = {"limit": limit, "offset": offset}
        if run_id:
            params["run_id"] = run_id
        if event_type:
            params["event_type"] = event_type

        console.print(f"Querying activity from {self.api_base}/activity")
        response = self.get("/activity", params=params)

        if response.status_code != 200:
            console.print(f"[red]API Error: {response.status_code} - {response.text}[/red]")
            return []

        data = response.json()
        return data.get("events", []) if isinstance(data, dict) else data


def get_event_type_style(event_type: str) -> str:
    """Get Rich style for an event type.

    Args:
        event_type: Activity event type.

    Returns:
        Rich style string.
    """
    return {
        "progress": "green",
        "blocker": "red",
        "question": "yellow",
        "milestone": "bold green",
        "error": "bold red",
        "warning": "yellow",
        "info": "blue",
        "session_start": "cyan",
        "session_end": "dim cyan",
        "agent_stopped": "dim",
        "subagent_stopped": "dim",
    }.get(event_type, "white")


def display_activity_event(event: dict[str, Any]) -> None:
    """Display an activity event in a formatted panel.

    Args:
        event: Activity event dict.
    """
    event_type = event.get("event_type", "unknown")
    type_style = get_event_type_style(event_type)

    info = (
        f"[bold cyan]Type:[/bold cyan] [{type_style}]{event_type}[/{type_style}]\n"
        f"[bold cyan]Message:[/bold cyan] {event.get('message', 'N/A')}\n"
        f"[bold cyan]Timestamp:[/bold cyan] {event.get('timestamp', 'N/A')}"
    )

    if event.get("run_id"):
        info += f"\n[bold cyan]Run ID:[/bold cyan] {event['run_id']}"

    if event.get("session_name"):
        info += f"\n[bold cyan]Session:[/bold cyan] {event['session_name']}"

    if event.get("agent_name"):
        info += f"\n[bold cyan]Agent:[/bold cyan] {event['agent_name']}"

    metadata = event.get("metadata", {})
    if metadata:
        info += "\n\n[bold cyan]Metadata:[/bold cyan]"
        for key, value in metadata.items():
            info += f"\n  • {key}: {value}"

    console.print(Panel(info, title="Activity Event", border_style="blue"))


def display_activity_list(events: list[dict[str, Any]]) -> None:
    """Display a list of activity events in a formatted table.

    Args:
        events: List of activity event dicts.
    """
    if not events:
        console.print("[yellow]No activity events found[/yellow]")
        return

    table = Table(title="Activity History")
    table.add_column("Type", style="magenta", no_wrap=True)
    table.add_column("Message", style="white")
    table.add_column("Timestamp", style="dim")
    table.add_column("Run ID", style="dim")

    for event in events:
        event_type = event.get("event_type", "unknown")
        type_style = get_event_type_style(event_type)
        run_id = event.get("run_id", "")
        if run_id and len(run_id) > 8:
            run_id = run_id[:8] + "..."

        # Truncate message for table display
        message = event.get("message", "")
        if len(message) > 60:
            message = message[:60] + "..."

        # Format timestamp
        timestamp = event.get("timestamp", "")
        if timestamp:
            # Parse and format for display
            try:
                dt = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                timestamp = dt.strftime("%Y-%m-%d %H:%M")
            except (ValueError, AttributeError):
                pass

        table.add_row(
            f"[{type_style}]{event_type}[/{type_style}]",
            message,
            timestamp,
            run_id,
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(events)} events[/dim]")


def display_report_success(event_type: str, message: str) -> None:
    """Display activity report success message.

    Args:
        event_type: Type of event that was reported.
        message: Message that was reported.
    """
    type_style = get_event_type_style(event_type)

    console.print(
        Panel(
            f"[bold green]Activity reported successfully[/bold green]\n\n"
            f"Type: [{type_style}]{event_type}[/{type_style}]\n"
            f"Message: {message[:100]}{'...' if len(message) > 100 else ''}",
            title="Success",
            border_style="green",
        )
    )
