"""Claude Code hooks API client for activity reporting."""

import json
import os
import sys
from datetime import UTC, datetime
from typing import Any

import httpx

from steerdev_agent.api.client import get_agent_name, get_api_key

# Default activity API endpoint
DEFAULT_ACTIVITY_ENDPOINT = "https://platform.steerdev.com/api/v1"


def get_activity_endpoint() -> str:
    """Get activity API endpoint from environment or use default."""
    return os.environ.get("STEERDEV_API_ENDPOINT", DEFAULT_ACTIVITY_ENDPOINT)


class HooksClient:
    """Client for reporting hook events to SteerDev activity API.

    Hooks read JSON input from stdin (provided by Claude Code) and
    report activity events to the SteerDev platform.
    """

    def __init__(self, timeout: float = 5.0) -> None:
        """Initialize the hooks client.

        Args:
            timeout: Request timeout in seconds (short for hooks).
        """
        self.api_key = get_api_key()
        self.api_endpoint = get_activity_endpoint()
        self.timeout = timeout
        self.agent_name = get_agent_name()

    def read_stdin_input(self) -> dict[str, Any] | None:
        """Read JSON input from stdin.

        Returns:
            Parsed JSON dict or None on failure.
        """
        try:
            return json.load(sys.stdin)
        except json.JSONDecodeError:
            return None

    def report_event(
        self,
        event_type: str,
        input_data: dict[str, Any],
        extra_metadata: dict[str, Any] | None = None,
    ) -> bool:
        """Report an activity event to the SteerDev API.

        Args:
            event_type: Type of event (e.g., "session_start", "agent_stopped").
            input_data: Input data from Claude Code hook.
            extra_metadata: Additional metadata to include.

        Returns:
            True if the event was reported successfully.
        """
        if not self.api_key:
            return False

        # Build base metadata
        metadata: dict[str, Any] = {
            "cwd": input_data.get("cwd"),
            "transcript_path": input_data.get("transcript_path"),
            "permission_mode": input_data.get("permission_mode"),
        }

        # Add extra metadata
        if extra_metadata:
            metadata.update(extra_metadata)

        # Build event payload
        event = {
            "event_type": event_type,
            "timestamp": datetime.now(UTC).isoformat(),
            "session_name": input_data.get("session_id"),
            "metadata": metadata,
        }

        # Build request body
        request_body = {
            "agent_name": self.agent_name,
            "application": "claude_code",
            "events": [event],
        }

        # Send to API (non-blocking)
        try:
            httpx.post(
                f"{self.api_endpoint}/activity/report",
                json=request_body,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self.timeout,
            )
            return True
        except Exception:
            return False

    def session_start(self) -> None:
        """Process SessionStart hook event.

        Reads JSON from stdin and reports session_start event.
        """
        input_data = self.read_stdin_input()
        if not input_data:
            sys.exit(0)

        self.report_event(
            event_type="session_start",
            input_data=input_data,
            extra_metadata={
                "source": input_data.get("source"),  # startup, resume, clear, compact
            },
        )
        sys.exit(0)

    def session_end(self) -> None:
        """Process SessionEnd hook event.

        Reads JSON from stdin and reports session_end event.
        """
        input_data = self.read_stdin_input()
        if not input_data:
            sys.exit(0)

        self.report_event(
            event_type="session_end",
            input_data=input_data,
            extra_metadata={
                "reason": input_data.get("reason"),  # clear, logout, prompt_input_exit, other
            },
        )
        sys.exit(0)

    def agent_stop(self) -> None:
        """Process Stop hook event (main agent).

        Reads JSON from stdin and reports agent_stopped event.
        """
        input_data = self.read_stdin_input()
        if not input_data:
            sys.exit(0)

        self.report_event(
            event_type="agent_stopped",
            input_data=input_data,
            extra_metadata={
                "stop_hook_active": input_data.get("stop_hook_active"),
            },
        )
        sys.exit(0)

    def subagent_stop(self) -> None:
        """Process SubagentStop hook event.

        Reads JSON from stdin and reports subagent_stopped event.
        """
        input_data = self.read_stdin_input()
        if not input_data:
            sys.exit(0)

        self.report_event(
            event_type="subagent_stopped",
            input_data=input_data,
            extra_metadata={
                "stop_hook_active": input_data.get("stop_hook_active"),
            },
        )
        sys.exit(0)
