"""Message API client for agent-to-user communication."""

from __future__ import annotations

from typing import Any
from uuid import UUID  # noqa: TC003 - Required at runtime by Pydantic

import httpx
from loguru import logger
from pydantic import BaseModel

from steerdev_agent.api.client import get_api_endpoint, get_api_key


class AgentMessage(BaseModel):
    """Message from user to agent."""

    id: UUID
    content: str
    message_type: str  # inject_stdin, agent_handle
    status: str
    run_id: UUID | None = None
    user_id: str
    created_at: str
    expires_at: str


class MessageClientError(Exception):
    """Error communicating with the messages API."""

    pass


class MessageClient:
    """Async client for polling and acknowledging user messages.

    This client allows agents to:
    - Poll for pending messages from users
    - Acknowledge message receipt
    - Respond to messages (for agent_handle type)
    """

    def __init__(
        self,
        agent_id: str,
        api_key: str | None = None,
        api_endpoint: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the message client.

        Args:
            agent_id: The agent ID to poll messages for.
            api_key: API key for authentication.
            api_endpoint: Base API endpoint.
            timeout: Request timeout in seconds.
        """
        self.agent_id = agent_id
        self._api_key = api_key or get_api_key()
        self._api_endpoint = api_endpoint or get_api_endpoint()
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            headers = {
                "Content-Type": "application/json",
                "User-Agent": "steerdev/0.1.0",
            }
            if self._api_key:
                headers["Authorization"] = f"Bearer {self._api_key}"

            self._client = httpx.AsyncClient(
                headers=headers,
                timeout=httpx.Timeout(self._timeout),
            )
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None

    async def poll_messages(
        self,
        run_id: str | None = None,
        since: str | None = None,
        limit: int = 10,
    ) -> list[AgentMessage]:
        """Poll for pending messages from users.

        Args:
            run_id: Optional run ID to filter messages.
            since: Optional ISO timestamp to get messages after.
            limit: Maximum number of messages to return.

        Returns:
            List of pending messages.
        """
        if not self._api_key:
            logger.warning("No API key configured, skipping message poll")
            return []

        try:
            client = await self._get_client()

            params: dict[str, Any] = {
                "status": "pending",
                "limit": limit,
            }
            if run_id:
                params["run_id"] = run_id
            if since:
                params["since"] = since

            url = f"{self._api_endpoint}/agents/{self.agent_id}/messages"
            response = await client.get(url, params=params)

            if response.status_code == 200:
                data = response.json()
                messages = [AgentMessage(**msg) for msg in data.get("messages", [])]
                if messages:
                    logger.debug(f"Received {len(messages)} pending messages")
                return messages
            elif response.status_code == 404:
                logger.warning(f"Agent {self.agent_id} not found")
                return []
            else:
                logger.error(f"Failed to poll messages: {response.status_code} - {response.text}")
                return []

        except httpx.TimeoutException:
            logger.warning("Timeout polling for messages")
            return []
        except httpx.HTTPError as e:
            logger.error(f"HTTP error polling messages: {e}")
            return []
        except Exception as e:
            logger.exception(f"Unexpected error polling messages: {e}")
            return []

    async def acknowledge_message(
        self,
        message_id: str | UUID,
        status: str = "acknowledged",
        response: str | None = None,
    ) -> bool:
        """Acknowledge receipt of a message.

        Args:
            message_id: The message ID to acknowledge.
            status: The new status ("delivered" or "acknowledged").
            response: Optional response text for agent_handle messages.

        Returns:
            True if acknowledged successfully.
        """
        if not self._api_key:
            logger.warning("No API key configured, skipping message acknowledge")
            return False

        try:
            client = await self._get_client()

            payload: dict[str, Any] = {"status": status}
            if response:
                payload["response"] = response

            url = f"{self._api_endpoint}/agents/{self.agent_id}/messages/{message_id}"
            http_response = await client.patch(url, json=payload)

            if http_response.status_code == 200:
                logger.debug(f"Acknowledged message {message_id}")
                return True
            else:
                logger.error(
                    f"Failed to acknowledge message: {http_response.status_code} - {http_response.text}"
                )
                return False

        except httpx.TimeoutException:
            logger.warning("Timeout acknowledging message")
            return False
        except httpx.HTTPError as e:
            logger.error(f"HTTP error acknowledging message: {e}")
            return False
        except Exception as e:
            logger.exception(f"Unexpected error acknowledging message: {e}")
            return False

    async def mark_delivered(self, message_id: str | UUID) -> bool:
        """Mark a message as delivered (received by agent).

        Args:
            message_id: The message ID.

        Returns:
            True if marked successfully.
        """
        return await self.acknowledge_message(message_id, status="delivered")

    async def mark_acknowledged(
        self,
        message_id: str | UUID,
        response: str | None = None,
    ) -> bool:
        """Mark a message as acknowledged (processed by agent).

        Args:
            message_id: The message ID.
            response: Optional response for agent_handle messages.

        Returns:
            True if marked successfully.
        """
        return await self.acknowledge_message(message_id, status="acknowledged", response=response)

    async def __aenter__(self) -> MessageClient:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: Any,
    ) -> None:
        """Exit async context manager."""
        await self.close()
