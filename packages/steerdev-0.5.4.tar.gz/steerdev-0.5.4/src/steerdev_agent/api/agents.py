"""Agent registration API client."""

from __future__ import annotations

from typing import Any, Self

import httpx
from loguru import logger
from pydantic import BaseModel, Field

from steerdev_agent.api.client import get_api_endpoint, get_api_key


class AgentRegisterRequest(BaseModel):
    """Request model for registering an agent."""

    name: str = Field(description="Agent name for identification")
    application: str | None = Field(
        default=None, description="Application type (e.g., claude_code)"
    )
    hostname: str | None = Field(default=None, description="Hostname where agent is running")


class AgentResponse(BaseModel):
    """Response model for agent data."""

    id: str
    project_id: str
    name: str | None = None
    application: str | None = None
    hostname: str | None = None
    status: str
    last_heartbeat_at: str | None = None
    created_at: str
    updated_at: str


class AgentsClient:
    """Async HTTP client for Agent registration API.

    Allows agents to register themselves and get their agent_id.
    """

    def __init__(self, api_key: str | None = None, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or get_api_key()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        await self.close()

    async def register(self, request: AgentRegisterRequest) -> AgentResponse | None:
        """Register an agent or get existing one.

        This is idempotent - calling with the same name will return the existing agent.

        Args:
            request: Agent registration request with name and optional metadata.

        Returns:
            Agent data including the agent_id, or None on failure.
        """
        client = await self._get_client()
        logger.debug(f"Registering agent '{request.name}' at {self.api_base}/agents")

        try:
            response = await client.post(
                f"{self.api_base}/agents",
                headers=self.headers,
                json=request.model_dump(exclude_none=True),
            )

            if response.status_code in (200, 201):
                data = response.json()
                logger.info(f"Agent registered successfully with ID: {data.get('id')}")
                return AgentResponse(**data)

            logger.error(f"Failed to register agent: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error registering agent: {e}")
            return None

    async def list_agents(self, limit: int = 50, offset: int = 0) -> list[AgentResponse]:
        """List agents for the project.

        Args:
            limit: Maximum number of agents to return.
            offset: Offset for pagination.

        Returns:
            List of agent data.
        """
        client = await self._get_client()

        try:
            response = await client.get(
                f"{self.api_base}/agents",
                headers=self.headers,
                params={"limit": limit, "offset": offset},
            )

            if response.status_code == 200:
                data = response.json()
                return [AgentResponse(**agent) for agent in data.get("agents", [])]

            logger.error(f"Failed to list agents: {response.status_code} - {response.text}")
            return []

        except httpx.RequestError as e:
            logger.error(f"Request error listing agents: {e}")
            return []
