"""Workflows API client for fetching workflow definitions."""

from typing import Any, Self

import httpx
from loguru import logger
from pydantic import BaseModel, Field

from steerdev_agent.api.client import get_api_endpoint, get_api_key


class WorkflowPhaseResponse(BaseModel):
    """Response model for workflow phase data."""

    id: str
    workflow_id: str
    name: str
    phase_type: str
    phase_order: int
    prompt_template: str | None = None
    is_required: bool = True
    max_retries: int = 0
    config_ids: list[str] = Field(default_factory=list)
    created_at: str
    updated_at: str


class WorkflowResponse(BaseModel):
    """Response model for workflow data."""

    id: str
    project_id: str
    name: str
    description: str | None = None
    is_default: bool = False
    max_retries_per_phase: int = 3
    phases: list[WorkflowPhaseResponse] = Field(default_factory=list)
    created_at: str
    updated_at: str


class WorkflowsClient:
    """Async HTTP client for fetching workflow definitions.

    Workflows define multi-phase task execution patterns.
    """

    def __init__(self, api_key: str | None = None, timeout: float = 30.0) -> None:
        """Initialize the client.

        Args:
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY.
            timeout: Request timeout in seconds.
        """
        self.api_key = api_key or get_api_key()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        await self.close()

    async def get_workflow(self, workflow_id: str) -> WorkflowResponse | None:
        """Get a workflow by ID.

        Args:
            workflow_id: Workflow ID to fetch.

        Returns:
            Workflow data or None if not found.
        """
        client = await self._get_client()
        logger.debug(f"Fetching workflow {workflow_id}")

        try:
            response = await client.get(
                f"{self.api_base}/workflows/{workflow_id}",
                headers=self.headers,
            )

            if response.status_code == 200:
                return WorkflowResponse(**response.json())
            if response.status_code == 404:
                logger.warning(f"Workflow not found: {workflow_id}")
                return None

            logger.error(f"Failed to get workflow: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error getting workflow: {e}")
            return None

    async def get_default_workflow(self, project_id: str) -> WorkflowResponse | None:
        """Get the default workflow for a project.

        Args:
            project_id: Project ID to get default workflow for.

        Returns:
            Default workflow or None if not found.
        """
        client = await self._get_client()
        logger.debug(f"Fetching default workflow for project {project_id}")

        try:
            response = await client.get(
                f"{self.api_base}/workflows",
                headers=self.headers,
                params={"project_id": project_id, "is_default": "true"},
            )

            if response.status_code == 200:
                data = response.json()
                workflows = data.get("workflows", [])
                if workflows:
                    return WorkflowResponse(**workflows[0])
                return None

            logger.error(
                f"Failed to get default workflow: {response.status_code} - {response.text}"
            )
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error getting default workflow: {e}")
            return None

    async def list_workflows(
        self,
        project_id: str | None = None,
        limit: int = 50,
    ) -> list[WorkflowResponse]:
        """List workflows with optional filters.

        Args:
            project_id: Filter by project ID.
            limit: Maximum number of workflows to return.

        Returns:
            List of workflows.
        """
        client = await self._get_client()
        logger.debug("Listing workflows")

        params: dict[str, Any] = {"limit": limit}
        if project_id:
            params["project_id"] = project_id

        try:
            response = await client.get(
                f"{self.api_base}/workflows",
                headers=self.headers,
                params=params,
            )

            if response.status_code == 200:
                data = response.json()
                return [WorkflowResponse(**w) for w in data.get("workflows", [])]

            logger.error(f"Failed to list workflows: {response.status_code} - {response.text}")
            return []

        except httpx.RequestError as e:
            logger.error(f"Request error listing workflows: {e}")
            return []
