"""Commands API client for agent daemon mode."""

from typing import Any, Literal, Self

import httpx
from loguru import logger
from pydantic import BaseModel, Field
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from steerdev_agent.api.client import get_agent_id, get_api_endpoint, get_api_key

console = Console()

CommandType = Literal["task", "prompt", "control"]
CommandStatus = Literal[
    "pending", "claimed", "executing", "completed", "failed", "cancelled", "expired"
]

STATUS_STYLES: dict[str, str] = {
    "pending": "dim",
    "claimed": "yellow",
    "executing": "blue",
    "completed": "green",
    "failed": "red",
    "cancelled": "dim",
    "expired": "dim",
}


class CommandResponse(BaseModel):
    """Response model for command data."""

    id: str
    agent_id: str
    project_id: str
    command_type: CommandType
    task_id: str | None = None
    prompt: str | None = None
    control_action: str | None = None
    working_directory: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    status: CommandStatus
    priority: int = 0
    session_id: str | None = None
    result: str | None = None
    error: str | None = None
    claimed_at: str | None = None
    started_at: str | None = None
    completed_at: str | None = None
    expires_at: str | None = None
    submitted_by: str | None = None
    created_at: str
    updated_at: str


class CommandListResponse(BaseModel):
    """Response model for listing commands."""

    commands: list[CommandResponse]
    total: int
    limit: int
    offset: int


class CommandsClient:
    """Async HTTP client for the agent commands API.

    Used by the daemon to poll for commands, claim them, and report results.
    """

    def __init__(
        self,
        agent_id: str | None = None,
        api_key: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the client.

        Args:
            agent_id: Agent ID for API calls. If not provided, reads from STEERDEV_AGENT_ID.
            api_key: API key for authentication. If not provided, reads from STEERDEV_API_KEY.
            timeout: Request timeout in seconds.
        """
        self.agent_id = agent_id or get_agent_id()
        self.api_key = api_key or get_api_key()
        self.api_base = get_api_endpoint()
        self.timeout = timeout
        self._client: httpx.AsyncClient | None = None

    @property
    def _base_url(self) -> str:
        """Get the base URL for commands endpoints."""
        return f"{self.api_base}/agents/{self.agent_id}/commands"

    @property
    def headers(self) -> dict[str, str]:
        """Get request headers with authentication."""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(timeout=self.timeout)
        return self._client

    async def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Exit async context manager."""
        await self.close()

    async def poll_next(self) -> CommandResponse | None:
        """Poll for and atomically claim the next pending command.

        Returns:
            Claimed command or None if queue is empty.
        """
        client = await self._get_client()
        logger.debug(f"Polling for next command at {self._base_url}/next")

        try:
            response = await client.get(
                f"{self._base_url}/next",
                headers=self.headers,
            )

            if response.status_code == 200:
                return CommandResponse(**response.json())
            if response.status_code == 204:
                return None

            logger.error(f"Failed to poll next command: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error polling next command: {e}")
            return None

    async def update_command(
        self,
        command_id: str,
        status: CommandStatus | None = None,
        session_id: str | None = None,
        result: str | None = None,
        error: str | None = None,
        started_at: str | None = None,
        completed_at: str | None = None,
    ) -> CommandResponse | None:
        """Update a command's status and metadata.

        Args:
            command_id: Command ID to update.
            status: New status.
            session_id: Session ID created for this command.
            result: Result summary.
            error: Error message.
            started_at: Execution start timestamp.
            completed_at: Completion timestamp.

        Returns:
            Updated command or None on failure.
        """
        client = await self._get_client()

        payload: dict[str, Any] = {}
        if status is not None:
            payload["status"] = status
        if session_id is not None:
            payload["session_id"] = session_id
        if result is not None:
            payload["result"] = result
        if error is not None:
            payload["error"] = error
        if started_at is not None:
            payload["started_at"] = started_at
        if completed_at is not None:
            payload["completed_at"] = completed_at

        if not payload:
            logger.warning("No fields to update")
            return None

        try:
            response = await client.patch(
                f"{self._base_url}/{command_id}",
                headers=self.headers,
                json=payload,
            )

            if response.status_code == 200:
                return CommandResponse(**response.json())

            logger.error(f"Failed to update command: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error updating command: {e}")
            return None

    async def mark_executing(self, command_id: str, session_id: str) -> CommandResponse | None:
        """Mark a command as executing with its session ID.

        Args:
            command_id: Command ID.
            session_id: Session ID created for execution.

        Returns:
            Updated command or None on failure.
        """
        from datetime import UTC, datetime

        return await self.update_command(
            command_id,
            status="executing",
            session_id=session_id,
            started_at=datetime.now(UTC).isoformat(),
        )

    async def mark_completed(
        self, command_id: str, result: str | None = None
    ) -> CommandResponse | None:
        """Mark a command as completed.

        Args:
            command_id: Command ID.
            result: Result summary.

        Returns:
            Updated command or None on failure.
        """
        from datetime import UTC, datetime

        return await self.update_command(
            command_id,
            status="completed",
            result=result,
            completed_at=datetime.now(UTC).isoformat(),
        )

    async def mark_failed(
        self, command_id: str, error: str | None = None
    ) -> CommandResponse | None:
        """Mark a command as failed.

        Args:
            command_id: Command ID.
            error: Error message.

        Returns:
            Updated command or None on failure.
        """
        from datetime import UTC, datetime

        return await self.update_command(
            command_id,
            status="failed",
            error=error,
            completed_at=datetime.now(UTC).isoformat(),
        )

    async def get_command(self, command_id: str) -> CommandResponse | None:
        """Get a single command by ID.

        Args:
            command_id: Command ID.

        Returns:
            Command data or None if not found.
        """
        client = await self._get_client()

        try:
            response = await client.get(
                f"{self._base_url}/{command_id}",
                headers=self.headers,
            )

            if response.status_code == 200:
                return CommandResponse(**response.json())
            if response.status_code == 404:
                return None

            logger.error(f"Failed to get command: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error getting command: {e}")
            return None

    async def list_commands(
        self,
        status: CommandStatus | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> CommandListResponse | None:
        """List commands for this agent.

        Args:
            status: Filter by status.
            limit: Maximum results.
            offset: Pagination offset.

        Returns:
            Command list response or None on failure.
        """
        client = await self._get_client()
        params: dict[str, str | int] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status

        try:
            response = await client.get(
                self._base_url,
                headers=self.headers,
                params=params,
            )

            if response.status_code == 200:
                return CommandListResponse(**response.json())

            logger.error(f"Failed to list commands: {response.status_code} - {response.text}")
            return None

        except httpx.RequestError as e:
            logger.error(f"Request error listing commands: {e}")
            return None


def display_command(command: CommandResponse, title: str = "Command") -> None:
    """Display a command in a formatted panel."""
    status_style = STATUS_STYLES.get(command.status, "white")

    info = (
        f"[bold cyan]ID:[/bold cyan] {command.id}\n"
        f"[bold cyan]Type:[/bold cyan] {command.command_type}\n"
        f"[bold cyan]Status:[/bold cyan] [{status_style}]{command.status}[/{status_style}]\n"
        f"[bold cyan]Priority:[/bold cyan] {command.priority}\n"
        f"[bold cyan]Created:[/bold cyan] {command.created_at}\n"
    )

    if command.task_id:
        info += f"[bold cyan]Task ID:[/bold cyan] {command.task_id}\n"
    if command.prompt:
        prompt_display = (
            command.prompt[:200] + "..." if len(command.prompt) > 200 else command.prompt
        )
        info += f"[bold cyan]Prompt:[/bold cyan] {prompt_display}\n"
    if command.control_action:
        info += f"[bold cyan]Control Action:[/bold cyan] {command.control_action}\n"
    if command.session_id:
        info += f"[bold cyan]Session ID:[/bold cyan] {command.session_id}\n"
    if command.result:
        info += f"[bold cyan]Result:[/bold cyan] {command.result}\n"
    if command.error:
        info += f"[bold cyan]Error:[/bold cyan] [red]{command.error}[/red]\n"

    console.print(Panel(info, title=title, border_style="green"))


def display_command_list(commands: list[CommandResponse], full_ids: bool = True) -> None:
    """Display a list of commands in a formatted table."""
    if not commands:
        console.print("[yellow]No commands found[/yellow]")
        return

    table = Table(title="Agent Commands")
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Type", style="white")
    table.add_column("Status", style="magenta")
    table.add_column("Priority", style="yellow")
    table.add_column("Created", style="green")

    for cmd in commands:
        status_style = STATUS_STYLES.get(cmd.status, "white")
        cmd_id = cmd.id if full_ids else (cmd.id[:8] + "..." if len(cmd.id) > 8 else cmd.id)

        table.add_row(
            cmd_id,
            cmd.command_type,
            f"[{status_style}]{cmd.status}[/{status_style}]",
            str(cmd.priority),
            cmd.created_at[:19] if cmd.created_at else "-",
        )

    console.print(table)
    console.print(f"\n[dim]Total: {len(commands)} commands[/dim]")
