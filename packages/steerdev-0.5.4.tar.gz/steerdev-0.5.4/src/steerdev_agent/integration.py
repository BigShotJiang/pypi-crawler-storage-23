"""Integration test harness for steerdev.

Creates a fresh Python project and adds tasks for building a todo-list API with SQLite.
"""

import json
import os
import shutil
import subprocess
from pathlib import Path

import httpx
import typer
from rich import print as rprint
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

# Default test tasks for todo-list API
DEFAULT_TASKS = [
    {
        "title": "Set up project with FastAPI and SQLite dependencies",
        "prompt": """Set up the Python project for a todo-list API:
1. Add dependencies to pyproject.toml: fastapi, uvicorn, sqlalchemy, pydantic
2. Run `uv sync` to install them
3. Create a basic src/todo_api/__init__.py file""",
        "priority": 3,
    },
    {
        "title": "Create SQLite database models",
        "prompt": """Create the database layer in src/todo_api/database.py:
1. Set up SQLAlchemy with SQLite (use 'todos.db' as the database file)
2. Create a Todo model with fields: id (int, primary key), title (str), description (str, optional), completed (bool, default False), created_at (datetime)
3. Add a function to initialize the database and create tables""",
        "priority": 2,
    },
    {
        "title": "Create Pydantic schemas",
        "prompt": """Create Pydantic schemas in src/todo_api/schemas.py:
1. TodoCreate schema for creating todos (title required, description optional)
2. TodoUpdate schema for updating todos (all fields optional)
3. TodoResponse schema for API responses (includes id, created_at, completed)""",
        "priority": 2,
    },
    {
        "title": "Implement CRUD API endpoints",
        "prompt": """Create the FastAPI application in src/todo_api/main.py:
1. Initialize FastAPI app with title "Todo API"
2. Add startup event to initialize database
3. Implement endpoints:
   - GET /todos - list all todos
   - POST /todos - create a todo
   - GET /todos/{id} - get a single todo
   - PATCH /todos/{id} - update a todo
   - DELETE /todos/{id} - delete a todo
4. Add proper error handling (404 for not found)""",
        "priority": 2,
    },
    {
        "title": "Add tests for the API",
        "prompt": """Create tests in tests/test_api.py:
1. Add pytest and httpx as dev dependencies
2. Use FastAPI TestClient to test all endpoints
3. Test cases: create todo, list todos, get single todo, update todo, delete todo, 404 handling
4. Make sure tests are isolated (clean database between tests)""",
        "priority": 1,
    },
]


def log_info(msg: str) -> None:
    rprint(f"[blue][INFO][/blue] {msg}")


def log_success(msg: str) -> None:
    rprint(f"[green][OK][/green] {msg}")


def log_warn(msg: str) -> None:
    rprint(f"[yellow][WARN][/yellow] {msg}")


def log_error(msg: str) -> None:
    rprint(f"[red][ERROR][/red] {msg}")


def run_cmd(
    cmd: list[str],
    cwd: Path | None = None,
    check: bool = True,
    capture: bool = True,
) -> subprocess.CompletedProcess:
    """Run a command and return the result."""
    return subprocess.run(
        cmd,
        cwd=cwd,
        check=check,
        capture_output=capture,
        text=True,
    )


def create_project(project_dir: Path) -> None:
    """Create a new Python project using uv init."""
    log_info(f"Creating project at {project_dir}...")

    if project_dir.exists():
        log_warn(f"Directory exists, removing: {project_dir}")
        shutil.rmtree(project_dir)

    # Create with uv init
    project_dir.parent.mkdir(parents=True, exist_ok=True)
    run_cmd(["uv", "init", "--lib", str(project_dir)])

    # Rename the default package to todo_api
    src_dir = project_dir / "src"
    default_pkg = src_dir / project_dir.name.replace("-", "_")
    todo_pkg = src_dir / "todo_api"

    if default_pkg.exists() and default_pkg != todo_pkg:
        default_pkg.rename(todo_pkg)

    # Update pyproject.toml to use todo_api
    pyproject = project_dir / "pyproject.toml"
    content = pyproject.read_text()
    content = content.replace(
        f'"{project_dir.name.replace("-", "_")}"',
        '"todo_api"',
    )
    pyproject.write_text(content)

    # Create tests directory
    (project_dir / "tests").mkdir(exist_ok=True)
    (project_dir / "tests" / "__init__.py").touch()

    # Create .env.example
    env_example = """\
# SteerDev Agent Configuration
# Copy this file to .env and fill in your values

# Required: Your SteerDev API key (get from steerdev.com dashboard)
STEERDEV_API_KEY=

# Required: Project ID to fetch tasks from
STEERDEV_PROJECT_ID=

# Optional: API endpoint (defaults to production)
# STEERDEV_API_ENDPOINT=https://platform.steerdev.com/api/v1

# Optional: Agent identification
# STEERDEV_AGENT_ID=
# STEERDEV_AGENT_NAME=

# Optional: LLM API keys (for Claude Code / other agents)
# ANTHROPIC_API_KEY=
# OPENAI_API_KEY=

# Optional: Notifications
# DISCORD_BOT_TOKEN=
# DISCORD_CHANNEL_ID=
# SLACK_WEBHOOK_URL=
"""
    (project_dir / ".env.steerdev.example").write_text(env_example)

    # Create .gitignore with common patterns
    gitignore = """\
# Python
__pycache__/
*.py[cod]
*$py.class
.venv/
venv/
*.egg-info/
dist/
build/

# Environment
.env
.env.local

# Database
*.db
*.sqlite
*.sqlite3

# IDE
.idea/
.vscode/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Testing
.pytest_cache/
.coverage
htmlcov/
"""
    (project_dir / ".gitignore").write_text(gitignore)

    # Initialize git
    run_cmd(["git", "init"], cwd=project_dir)
    run_cmd(["git", "add", "-A"], cwd=project_dir)
    run_cmd(["git", "commit", "-m", "Initial commit"], cwd=project_dir)

    log_success("Project created")


def add_tasks(
    project_id: str,
    tasks: list[dict],
    api_key: str,
    api_endpoint: str,
) -> list[str]:
    """Add tasks via the SteerDev API. Returns list of created task IDs."""
    log_info(f"Adding {len(tasks)} tasks to project {project_id}...")

    created_ids = []

    for task in tasks:
        title = task["title"]
        prompt = task["prompt"]
        priority = task.get("priority", 1)

        log_info(f"Creating: {title}")

        try:
            response = httpx.post(
                f"{api_endpoint}/tasks",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "project_id": project_id,
                    "title": title,
                    "prompt": prompt,
                    "priority": priority,
                },
                timeout=30,
            )

            if response.status_code == 201:
                data = response.json()
                task_id = data.get("id", "unknown")
                created_ids.append(task_id)
                log_success(f"Created: {task_id[:8]}...")
            else:
                log_error(f"Failed: {response.text}")

        except httpx.RequestError as e:
            log_error(f"Request failed: {e}")

    return created_ids


def start_agent(project_id: str, project_dir: Path) -> None:
    """Start the steerdev."""
    log_info("Starting steerdev...")

    os.chdir(project_dir)
    os.environ["STEERDEV_PROJECT_ID"] = project_id

    subprocess.run(
        ["steerdev", "run", "--project-id", project_id, "--workdir", str(project_dir)],
        check=False,
    )


def run_integration_test(
    project_id: str,
    project_dir: Path,
    tasks_file: Path | None = None,
    skip_tasks: bool = False,
    auto_start: bool = False,
) -> None:
    """Run the full integration test."""
    # Get environment
    api_key = os.environ.get("STEERDEV_API_KEY")
    if not api_key:
        log_error("STEERDEV_API_KEY environment variable is required")
        raise typer.Exit(1)

    api_endpoint = os.environ.get("STEERDEV_API_ENDPOINT", "https://platform.steerdev.com/api/v1")

    # Show config
    rprint("")
    rprint(Panel.fit("SteerDev Integration Test", style="bold blue"))
    rprint("")

    table = Table(show_header=False, box=None)
    table.add_column("Key", style="dim")
    table.add_column("Value")
    table.add_row("Project ID", project_id)
    table.add_row("Project Dir", str(project_dir))
    table.add_row("API Endpoint", api_endpoint)
    console.print(table)
    rprint("")

    # Check uv is installed
    if shutil.which("uv") is None:
        log_error("uv is required but not installed")
        raise typer.Exit(1)

    # Create project
    create_project(project_dir)

    # Add tasks
    if not skip_tasks:
        if tasks_file and tasks_file.exists():
            tasks = json.loads(tasks_file.read_text())
        else:
            tasks = DEFAULT_TASKS

        add_tasks(project_id, tasks, api_key, api_endpoint)
    else:
        log_warn("Skipping task creation (--skip-tasks)")

    log_success("Integration test environment ready!")
    rprint("")
    rprint(f"Project created at: [bold]{project_dir}[/bold]")
    rprint("")

    # Start agent
    if auto_start or typer.confirm("Start the agent now?", default=True):
        start_agent(project_id, project_dir)
    else:
        log_info("Run manually with:")
        rprint(f"  cd {project_dir}")
        rprint(f"  steerdev run --project-id {project_id}")
