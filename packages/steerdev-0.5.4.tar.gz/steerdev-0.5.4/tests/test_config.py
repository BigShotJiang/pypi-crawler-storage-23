"""Tests for configuration models."""

import tempfile

from steerdev_agent.config.models import (
    AgentConfig,
    APIConfig,
    EventsConfig,
    SteerDevConfig,
)


class TestAgentConfig:
    """Tests for AgentConfig."""

    def test_defaults(self):
        """Test default values."""
        config = AgentConfig()
        assert config.model is None
        assert config.max_turns is None
        assert config.timeout_seconds == 3600

    def test_custom_values(self):
        """Test custom values."""
        config = AgentConfig(
            model="claude-sonnet-4-20250514",
            max_turns=10,
            timeout_seconds=7200,
        )
        assert config.model == "claude-sonnet-4-20250514"
        assert config.max_turns == 10
        assert config.timeout_seconds == 7200


class TestAPIConfig:
    """Tests for APIConfig."""

    def test_defaults(self):
        """Test default values."""
        config = APIConfig()
        assert "steerdev.com" in config.api_endpoint
        assert config.api_key_env == "STEERDEV_API_KEY"
        assert config.project_id_env == "STEERDEV_PROJECT_ID"


class TestEventsConfig:
    """Tests for EventsConfig."""

    def test_defaults(self):
        """Test default values."""
        config = EventsConfig()
        assert config.batch_size == 10
        assert config.flush_interval_seconds == 5.0


class TestSteerDevConfig:
    """Tests for SteerDevConfig."""

    def test_defaults(self):
        """Test default values."""
        config = SteerDevConfig()
        assert isinstance(config.agent, AgentConfig)
        assert isinstance(config.api, APIConfig)
        assert isinstance(config.events, EventsConfig)

    def test_from_yaml(self):
        """Test loading from YAML."""
        yaml_content = """
agent:
  model: claude-opus-4-20250514
  timeout_seconds: 1800
events:
  batch_size: 20
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            f.write(yaml_content)
            f.flush()

            config = SteerDevConfig.from_yaml(f.name)
            assert config.agent.model == "claude-opus-4-20250514"
            assert config.agent.timeout_seconds == 1800
            assert config.events.batch_size == 20

    def test_to_yaml(self):
        """Test saving to YAML."""
        config = SteerDevConfig()
        config.agent.model = "claude-sonnet-4-20250514"

        with tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False) as f:
            config.to_yaml(f.name)

            # Read back
            loaded = SteerDevConfig.from_yaml(f.name)
            assert loaded.agent.model == "claude-sonnet-4-20250514"
