"""Version information for anymap-ts."""

__version__ = "0.12.0"
