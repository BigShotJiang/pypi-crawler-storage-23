# This file is kept for backwards compatibility.
# The main dialect is now at the project root: aiolibsql_sqlalchemy.py
# Use: import aiolibsql_sqlalchemy
from aiolibsql_sqlalchemy import *
