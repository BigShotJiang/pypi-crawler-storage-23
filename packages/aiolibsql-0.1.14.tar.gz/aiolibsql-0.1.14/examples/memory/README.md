# In-Memory Database

This example demonstrates using an in-memory SQLite database (`:memory:`).

## Install

```bash
pip install "aiolibsql @ git+https://github.com/fuhnut/aiolibsql"
```

## Running

```bash
python3 main.py
```
