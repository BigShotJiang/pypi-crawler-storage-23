# Encryption

This example demonstrates how to use AES encryption with a local database.

## Install

```bash
pip install "aiolibsql @ git+https://github.com/fuhnut/aiolibsql"
```

## Running

```bash
python3 main.py
```
