# Changelog

The changelog is auto-generated in the [lamin-docs repository](https://github.com/laminlabs/lamin-docs/blob/main/docs/changelog/soon/wetlab.md).

By configuring the `doc-changes` GitHub action, you can auto-generate the changelog in any file in any repository.
