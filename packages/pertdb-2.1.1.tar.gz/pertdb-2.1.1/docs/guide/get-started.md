# Get started

Install all required dependencies:

```bash
pip install pertdb
```

Init your instance

```bash
lamin init --storage ./test-pertdb --modules bionty,pertdb
```

Everything else works exactly as for any other schema module and the core registries.
