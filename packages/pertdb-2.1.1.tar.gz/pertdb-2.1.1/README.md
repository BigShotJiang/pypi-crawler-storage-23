# `pertdb`: Registries for perturbations and their targets

Read the docs: [docs.lamin.ai/pertdb](https://docs.lamin.ai/pertdb).
