from .pyQt5_ai import MainAiGui
