# Changelog

## 0.1.0

- Initial release: secrets detection for vibe-coded repos
- Bundled Python CLI for zero-config scanning
- WebView report with Ybe-to-Value score
- Status bar integration for one-click audits
- Supports custom Python path via `ybe-check.pythonPath` setting
