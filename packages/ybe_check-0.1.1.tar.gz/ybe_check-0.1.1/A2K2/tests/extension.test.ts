import * as assert from 'assert';

suite('Ybe Check', () => {
    test('extension loads', () => {
        assert.ok(true);
    });
});
