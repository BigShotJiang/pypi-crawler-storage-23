---
name: Issue template
about: General template for playground issues
title: ""
labels: ""
assignees: ""
---

## 🚀 What's the issue?

<!-- Briefly explain the issue or feature request -->

-

## 📸 Screenshots or logs (optional but helpful!)

<!-- Add any screenshots, output, or logs for context -->

-
