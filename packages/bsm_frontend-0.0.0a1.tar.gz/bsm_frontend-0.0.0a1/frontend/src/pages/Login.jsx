import React, { useState, useEffect } from "react";
import { useAuth } from "../AuthContext";
import { useNavigate, useLocation } from "react-router-dom";
import RemoteConfigModal from "../components/RemoteConfigModal";
import { getApiBaseUrl } from "../api";
import { Globe } from "lucide-react";

const Login = () => {
  const [showRemoteModal, setShowRemoteModal] = useState(false);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState(null);
  const { login, user } = useAuth();
  const navigate = useNavigate();
  const showConfigButton =
    sessionStorage.getItem("show_remote_config") === "true" ||
    !!getApiBaseUrl();
  const location = useLocation();

  // Where to redirect after login
  const from = location.state?.from?.pathname || "/";

  useEffect(() => {
    // If user is already logged in, redirect them
    if (user) {
      navigate("/", { replace: true });
    }
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    try {
      await login(username, password, rememberMe);
      navigate(from, { replace: true });
    } catch {
      setError("Invalid username or password");
    }
  };

  return (
    <div
      className="container"
      style={{ maxWidth: "400px", marginTop: "100px" }}
    >
      <div className="header" style={{ flexDirection: "column", gap: "10px" }}>
        <h1>Login</h1>
      </div>

      <form
        onSubmit={handleSubmit}
        className="form-group"
        style={{ display: "flex", flexDirection: "column", gap: "15px" }}
      >
        <div>
          <label htmlFor="username" className="form-label">
            Username
          </label>
          <input
            type="text"
            id="username"
            name="username"
            className="form-input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
            autoComplete="username"
          />
        </div>
        <div>
          <label htmlFor="password" className="form-label">
            Password
          </label>
          <input
            type="password"
            id="password"
            name="password"
            className="form-input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            autoComplete="current-password"
          />
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
          <input
            type="checkbox"
            id="rememberMe"
            name="rememberMe"
            checked={rememberMe}
            onChange={(e) => setRememberMe(e.target.checked)}
          />
          <label htmlFor="rememberMe" style={{ cursor: "pointer" }}>
            Remember me
          </label>
        </div>

        {error && <div className="message message-error">{error}</div>}

        <button type="submit" className="button button-primary">
          Sign In
        </button>
      </form>

      {showConfigButton && (
        <div
          style={{
            marginTop: "20px",
            display: "flex",
            justifyContent: "center",
          }}
        >
          <button
            type="button"
            onClick={() => setShowRemoteModal(true)}
            style={{
              background: "transparent",
              border: "none",
              color: "#aaa",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "5px",
              fontSize: "0.9em",
              textDecoration: "underline",
            }}
          >
            <Globe size={16} /> Configure Remote Server
          </button>
        </div>
      )}

      {showRemoteModal && (
        <RemoteConfigModal
          isOpen={showRemoteModal}
          onClose={() => setShowRemoteModal(false)}
        />
      )}
    </div>
  );
};

export default Login;
