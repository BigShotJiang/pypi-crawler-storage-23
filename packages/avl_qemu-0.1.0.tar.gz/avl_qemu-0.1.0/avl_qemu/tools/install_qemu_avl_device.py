#!/usr/bin/env python3
import argparse
import os
import subprocess
import sys


def run_command(command, cwd=None):
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
        bufsize=1, # Line buffered
        cwd=cwd
    )

    # Read output line by line as it arrives
    for line in process.stdout:
        print(line.strip())
        sys.stdout.flush()

    process.wait() # Wait for the process to actually close

    if process.returncode != 0:
        print(f"--- Command Failed (Exit Code: {process.returncode}) ---")
    return process.returncode

def main():
    nproc = os.cpu_count()
    parser = argparse.ArgumentParser(description="Git Clone and configure qemu with the custom avl device")
    parser.add_argument("--path", type=str, required=True, help="Install Path")
    parser.add_argument("--clean", action="store_true", help="Clean existing installation")
    parser.add_argument("--nproc", type=int, help=f"Number of processors to use when building QEMU (default: {nproc})")

    args = parser.parse_args()

    # Check if the path already exists and clean it if --clean is specified
    if os.path.exists(args.path):
        if args.clean:
            print(f"Cleaning existing directory {args.path}...")
            os.system(f"rm -rf {args.path}")
        else:
            print(f"Directory {args.path} already exists. Please choose a different path.")
            return 1

    # Create the directory if it doesn't exist
    print(f"Creating directory {args.path}...")
    os.makedirs(args.path, exist_ok=True)

    # Clone the qemu repository - stream the output to the console in real-time
    print("Cloning qemu repository...")
    repo_url = "https://github.com/qemu/qemu.git"
    version = "v9.2.2"

    command = ["git", "clone", "--depth", "1", "-b", version, "--progress", repo_url, args.path]
    if run_command(command) != 0:
        return 1

    # Copy the custom device files to the qemu source directory
    print("Copying custom device files...")
    custom_device_file = os.path.join(os.path.dirname(__file__), "../device/avl.c")
    qemu_source_dir = os.path.join(args.path, "hw", "misc")
    try:
        os.system(f"cp {custom_device_file} {qemu_source_dir}")
    except Exception as e:
        print(f"Error copying file {custom_device_file} to {qemu_source_dir}: {e}")
        return 1

    print("Registering the custom device in qemu...")
    meson_build_file = os.path.join(args.path, "hw", "misc", "meson.build")
    try:
        with open(meson_build_file, "a") as f:
            f.write("\n# AVL device\n")
            f.write("system_ss.add(when: 'CONFIG_PCI', if_true: files('avl.c'))\n")
    except Exception as e:
        print(f"Error writing to meson.build file: {e}")
        return 1

    print("Configuring and building qemu with the custom device...")
    cmd = ["../configure", "--enable-plugins", "--target-list=x86_64-softmmu", "--disable-werror"]
    cwd = os.path.join(args.path, "build")
    os.makedirs(cwd, exist_ok=True)
    if run_command(cmd, cwd=cwd) != 0:
        return 1

    cmd = ["make", f"-j{args.nproc}"]
    if run_command(cmd, cwd=cwd) != 0:
        return 1

    install_dir = os.path.join(args.path, "build/qemu-bundle/usr/local")
    if not os.path.exists(install_dir):
        print(f"Error creating install directory: {install_dir}")
        return 1

    print(f"Install successful. To use: export QEMU_HOME={install_dir}")
    return 0

if __name__ == "__main__":
  sys.exit(main())
