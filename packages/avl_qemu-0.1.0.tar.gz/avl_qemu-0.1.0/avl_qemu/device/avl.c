#include "qemu/osdep.h"
#include "hw/pci/pci.h"
#include "hw/pci/pci_device.h"
#include "hw/qdev-properties.h"
#include "qapi/error.h"
#include "exec/address-spaces.h"
#include <fcntl.h>
#include <unistd.h>

#define TYPE_AVL_DEVICE "avl-hook"
#define MAX_REGIONS 16

OBJECT_DECLARE_SIMPLE_TYPE(AvlDevice, AVL_DEVICE)

/* * 28-byte packet matching Python: struct.unpack('<QIIQI', data)
 * addr (8), size (4), type (4), data (8), region_id (4)
 */
typedef struct {
    uint64_t addr;
    uint32_t size;
    uint32_t type;      /* 1: Read, 2: Write */
    uint64_t data;
    uint32_t region_id;
} __attribute__((packed)) AccessPacket;

typedef struct {
    uint32_t success;
    uint64_t data;
} __attribute__((packed)) ResponsePacket;

typedef struct AvlRegion {
    MemoryRegion mr;
    uint64_t base_addr;
    uint32_t id;
    struct AvlDevice *parent;
} AvlRegion;

struct AvlDevice {
    PCIDevice parent_obj;
    char *file_path;
    int out_fd;
    int in_fd;
    AvlRegion regions[MAX_REGIONS];
    int num_regions;
};

static uint64_t avl_read(void *opaque, hwaddr addr, unsigned size) {
    AvlRegion *region = (AvlRegion *)opaque;
    AvlDevice *s = region->parent;

    AccessPacket req = {
        .addr = region->base_addr + addr,
        .size = size,
        .type = 1,
        .data = 0,
        .region_id = region->id
    };
    ResponsePacket res = {0};

    if (s->out_fd < 0 || s->in_fd < 0) return 0xFEEDFACE;

    /* Write request and check result to satisfy -Werror */
    if (write(s->out_fd, &req, sizeof(req)) != sizeof(req)) {
        return 0xDEADBEEF;
    }

    /* Synchronous block: Wait for Python to send 12-byte response */
    if (read(s->in_fd, &res, sizeof(res)) == sizeof(res) && res.success) {
        return res.data;
    }

    return 0xFEEDFACE;
}

static void avl_write(void *opaque, hwaddr addr, uint64_t val, unsigned size) {
    AvlRegion *region = (AvlRegion *)opaque;
    AvlDevice *s = region->parent;

    AccessPacket req = {
        .addr = region->base_addr + addr,
        .size = size,
        .type = 2,
        .data = val,
        .region_id = region->id
    };

    if (s->out_fd >= 0) {
        /* Check result to satisfy -Werror=unused-result */
        if (write(s->out_fd, &req, sizeof(req)) != sizeof(req)) {
            /* Silently continue or log if needed */
        }
    }
}

static const MemoryRegionOps avl_ops = {
    .read = avl_read,
    .write = avl_write,
    .endianness = DEVICE_NATIVE_ENDIAN,
    .valid = {
        .min_access_size = 1,
        .max_access_size = 8,
    },
};

static void avl_realize(PCIDevice *pdev, Error **errp) {
    AvlDevice *s = AVL_DEVICE(pdev);
    char out_path[256], in_path[256];
    uint64_t addr, size;

    if (!s->file_path) {
        error_setg(errp, "avl-hook: 'file' property required");
        return;
    }

    FILE *f = fopen(s->file_path, "r");
    if (!f) {
        error_setg(errp, "avl-hook: cannot open %s", s->file_path);
        return;
    }

    /* * Line 1: Header (Pipe Paths)
     * Format: /tmp/pipe_out,/tmp/pipe_in
     */
    if (fscanf(f, "%255[^,],%255s\n", out_path, in_path) != 2) {
        error_setg(errp, "avl-hook: First line must be OUT_PIPE,IN_PIPE");
        fclose(f);
        return;
    }

    /* Open pipes - Note: These will block until Python connects */
    s->out_fd = open(out_path, O_WRONLY);
    s->in_fd = open(in_path, O_RDONLY);

    if (s->out_fd < 0 || s->in_fd < 0) {
        error_setg(errp, "avl-hook: Failed to open pipes: %s, %s", out_path, in_path);
        fclose(f);
        return;
    }

    /* * Lines 2+: Memory Regions
     * Format: 0xADDR,0xSIZE
     */
    s->num_regions = 0;
    while (fscanf(f, "0x%" SCNx64 ",0x%" SCNx64 "\n", &addr, &size) == 2) {
        if (s->num_regions >= MAX_REGIONS) break;

        AvlRegion *r = &s->regions[s->num_regions];
        r->base_addr = addr;
        r->id = s->num_regions;
        r->parent = s;

        char mr_name[32];
        snprintf(mr_name, sizeof(mr_name), "avl-mem-%d", r->id);

        memory_region_init_io(&r->mr, OBJECT(s), &avl_ops, r, mr_name, size);
        memory_region_add_subregion_overlap(get_system_memory(), addr, &r->mr, 10);

        s->num_regions++;
    }

    fclose(f);
}

static Property avl_properties[] = {
    DEFINE_PROP_STRING("file", AvlDevice, file_path),
    DEFINE_PROP_END_OF_LIST(),
};

static void avl_class_init(ObjectClass *klass, void *data) {
    DeviceClass *dc = DEVICE_CLASS(klass);
    PCIDeviceClass *k = PCI_DEVICE_CLASS(klass);
    k->realize = avl_realize;
    k->vendor_id = 0x1234;
    k->device_id = 0x5678;
    k->class_id = PCI_CLASS_OTHERS;
    device_class_set_props(dc, avl_properties);
}

static const TypeInfo avl_info = {
    .name          = TYPE_AVL_DEVICE,
    .parent        = TYPE_PCI_DEVICE,
    .instance_size = sizeof(AvlDevice),
    .class_init    = avl_class_init,
    .interfaces = (InterfaceInfo[]) {
        { INTERFACE_CONVENTIONAL_PCI_DEVICE },
        { },
    },
};

static void avl_register_types(void) {
    type_register_static(&avl_info);
}

type_init(avl_register_types)
