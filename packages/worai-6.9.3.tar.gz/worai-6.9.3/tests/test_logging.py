from __future__ import annotations

import logging

from worai.logging import setup_logging


def test_warning_level_filters_info_even_when_dependency_logger_is_info(capsys) -> None:
    setup_logging(level="warning", fmt="text")
    noisy_logger = logging.getLogger("wordlift_sdk.noisy")
    noisy_logger.setLevel(logging.INFO)

    noisy_logger.info("should be hidden")
    hidden = capsys.readouterr()
    assert "should be hidden" not in hidden.err

    noisy_logger.warning("should be shown")
    shown = capsys.readouterr()
    assert "WARNING wordlift_sdk.noisy: should be shown" in shown.err


def test_quiet_forces_warning_level(capsys) -> None:
    setup_logging(level="debug", fmt="text", quiet=True)
    logger = logging.getLogger("worai.quiet")

    logger.info("info hidden")
    hidden = capsys.readouterr()
    assert "info hidden" not in hidden.err

    logger.warning("warning shown")
    shown = capsys.readouterr()
    assert "WARNING worai.quiet: warning shown" in shown.err
