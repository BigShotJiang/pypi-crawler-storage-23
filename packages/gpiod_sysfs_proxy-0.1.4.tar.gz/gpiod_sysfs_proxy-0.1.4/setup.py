# SPDX-License-Identifier: MIT
# SPDX-FileCopyrightText: 2024 Bartosz Golaszewski <bartosz.golaszewski@linaro.org>

from setuptools import setup

setup(scripts=["gpiod-sysfs-proxy"])
