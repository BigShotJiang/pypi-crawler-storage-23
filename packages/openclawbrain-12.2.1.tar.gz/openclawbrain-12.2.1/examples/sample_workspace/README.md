# Sample Workspace

## Purpose
This workspace demonstrates a small team's deploy, monitoring, and incident operations.

## How to use
Start with `deploy.md` for release procedures, `monitoring.md` for alerts, and `incidents.md` for response playbooks. New team members should begin with `onboarding.md`.
