# hash_embedder

Zero dependencies, works fully offline.

Run:

```bash
python3 examples/hash_embedder/run.py ./workspace
```

This example uses the built-in `HashEmbedder` (hash-v1, 1024-dim) and writes `state.json` in the output.
