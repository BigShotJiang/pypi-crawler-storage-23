# pysvgedit
pysvgedit is a low-level SVG editing library written in native Python. Its
intention is to use vector-editing programs like Inkscape and create scriptable
forms from them.

## License
GNU GPL-3.
