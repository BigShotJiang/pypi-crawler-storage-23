"""Renderers for CLI output."""

from synapse.commands.renderers.rich_renderer import RichRenderer

__all__ = ["RichRenderer"]
