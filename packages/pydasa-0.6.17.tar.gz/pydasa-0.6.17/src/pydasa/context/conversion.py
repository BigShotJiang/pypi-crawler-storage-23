# -*- coding: utf-8 -*-
"""
Configuration module for...

# TODO: Add description of the module.

*IMPORTANT:* Based on the theory from:

    # H.Gorter, *Dimensionalanalyse: Eine Theoririe der physikalischen Dimensionen mit Anwendungen*
"""
# TODO add UnitConverter for one variable/parameter
