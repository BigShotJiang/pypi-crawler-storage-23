"""Service for backing up and restoring collections."""

from datetime import UTC, datetime
from pathlib import Path
from typing import Optional

from vector_inspector.core.logging import log_debug, log_error, log_info

from .backup_helpers import normalize_embeddings, read_backup_zip, write_backup_zip


class BackupRestoreService:
    """Handles backup and restore operations for vector database collections."""

    @staticmethod
    def backup_collection(
        connection,
        collection_name: str,
        backup_dir: str,
        include_embeddings: bool = True,
        profile_name: Optional[str] = None,
    ) -> Optional[str]:
        """
        Backup a collection to a directory.

        Args:
            connection: Vector database connection
            collection_name: Name of collection to backup
            backup_dir: Directory to store backups
            include_embeddings: Whether to include embedding vectors
            connection_id: Optional connection ID for retrieving model config from settings

        Returns:
            Path to backup file or None if failed
        """
        try:
            Path(backup_dir).mkdir(parents=True, exist_ok=True)

            collection_info = connection.get_collection_info(collection_name)
            if not collection_info:
                log_error("Failed to get collection info for %s", collection_name)
                return None

            all_data = connection.get_all_items(collection_name)
            if not all_data or not all_data.get("ids"):
                log_info("No data to backup from collection %s", collection_name)
                return None

            # Normalize embeddings to plain lists
            all_data = normalize_embeddings(all_data)

            if not include_embeddings and "embeddings" in all_data:
                del all_data["embeddings"]

            backup_metadata = {
                "collection_name": collection_name,
                "backup_timestamp": datetime.now(tz=UTC).isoformat(),
                "item_count": len(all_data["ids"]),
                "collection_info": collection_info,
                "include_embeddings": include_embeddings,
            }
            # Include embedding model info when available to assist accurate restores
            try:
                embed_model = None
                embed_model_type = None
                # Prefer explicit collection_info entries
                if collection_info and collection_info.get("embedding_model"):
                    embed_model = collection_info.get("embedding_model")
                    embed_model_type = collection_info.get("embedding_model_type")
                else:
                    # Ask connection for a model hint (may consult settings/service)
                    try:
                        embed_model = connection.get_embedding_model(collection_name)
                    except Exception:
                        embed_model = None

                # If not found yet, check app settings as a fallback
                if not embed_model and profile_name:
                    try:
                        from vector_inspector.services.settings_service import SettingsService

                        settings = SettingsService()
                        model_info = settings.get_embedding_model(
                            profile_name,
                            collection_name,
                        )
                        if model_info:
                            embed_model = model_info.get("model")
                            embed_model_type = model_info.get("type", "sentence-transformer")
                    except Exception:
                        pass

                if embed_model:
                    backup_metadata["embedding_model"] = embed_model
                if embed_model_type:
                    backup_metadata["embedding_model_type"] = embed_model_type
            except Exception as e:
                # Embedding metadata is optional; log failure but do not abort backup.
                log_debug("Failed to populate embedding metadata for %s: %s", collection_name, e)

            timestamp = datetime.now(tz=UTC).strftime("%Y%m%d_%H%M%S")
            backup_filename = f"{collection_name}_backup_{timestamp}.zip"
            backup_path = Path(backup_dir) / backup_filename

            write_backup_zip(backup_path, backup_metadata, all_data)
            log_info("Backup created: %s", backup_path)
            return str(backup_path)
        except Exception as e:
            log_error("Backup failed: %s", e)
            return None

    def restore_collection(
        self,
        connection,
        backup_file: str,
        collection_name: Optional[str] = None,
        overwrite: bool = False,
        recompute_embeddings: Optional[bool] = None,
        profile_name: Optional[str] = None,
    ) -> bool:
        """
        Restore a collection from a backup file.

        Args:
            connection: Vector database connection
            backup_file: Path to backup zip file
            collection_name: Optional new name for restored collection
            overwrite: Whether to overwrite existing collection
            recompute_embeddings: How to handle embeddings during restore:
                - None (default): Use stored embeddings as-is from backup (safest, fastest)
                - True: Force recompute embeddings from documents using model metadata
                - False: Omit embeddings entirely (documents/metadata only)
            connection_id: Optional connection ID for saving model config to app settings

        Returns:
            True if successful, False otherwise
        """
        restore_collection_name = None
        try:
            metadata, data = read_backup_zip(backup_file)
            restore_collection_name = collection_name or metadata.get("collection_name")

            existing_collections = connection.list_collections()
            if restore_collection_name in existing_collections:
                if not overwrite:
                    log_info(
                        "Collection %s already exists. Use overwrite=True to replace it.",
                        restore_collection_name,
                    )
                    return False
                connection.delete_collection(restore_collection_name)
            else:
                # Collection does not exist on target; attempt to create it.
                # Try to infer vector size from metadata or embedded vectors in backup.
                try:
                    inferred_size = None
                    col_info = metadata.get("collection_info") if metadata else None
                    if (
                        col_info
                        and col_info.get("vector_dimension")
                        and isinstance(col_info.get("vector_dimension"), int)
                    ):
                        inferred_size = int(col_info.get("vector_dimension"))

                    # Fallback: inspect embeddings in backup data
                    if inferred_size is None and data and data.get("embeddings"):
                        from vector_inspector.utils import has_embedding

                        first_emb = data.get("embeddings")[0]
                        if has_embedding(first_emb):
                            inferred_size = len(first_emb)

                    # Final fallback: common default
                    if inferred_size is None:
                        log_error(
                            "Unable to infer vector dimension for collection %s from metadata or backup data; restore aborted.",
                            restore_collection_name,
                        )
                        return False

                    created = True
                    if hasattr(connection, "create_collection"):
                        created = connection.create_collection(
                            restore_collection_name, inferred_size
                        )

                    if not created:
                        log_error(
                            "Failed to create collection %s before restore", restore_collection_name
                        )
                        return False
                except Exception as e:
                    log_error("Error while creating collection %s: %s", restore_collection_name, e)
                    return False

            # Provider-specific preparation hook
            if hasattr(connection, "prepare_restore"):
                ok = connection.prepare_restore(metadata, data)
                if not ok:
                    log_error("Provider prepare_restore failed for %s", restore_collection_name)
                    return False

            # Ensure embeddings normalized
            data = normalize_embeddings(data)

            # Decide how to handle embeddings based on user choice
            embeddings_to_use = None
            stored_embeddings = data.get("embeddings")

            if recompute_embeddings is False:
                # User explicitly chose to omit embeddings
                log_info("Restoring without embeddings (user choice)")
                embeddings_to_use = None

            elif recompute_embeddings is True:
                # User explicitly chose to recompute embeddings
                log_info("Recomputing embeddings from documents")
                try:
                    from vector_inspector.core.embedding_utils import (
                        encode_text,
                        load_embedding_model,
                    )

                    model_name = metadata.get("embedding_model") if metadata else None
                    docs = data.get("documents", [])

                    if not model_name:
                        log_error(
                            "Cannot recompute: No embedding model available in backup metadata"
                        )
                        embeddings_to_use = None
                    elif not docs:
                        log_error("Cannot recompute: No documents available in backup")
                        embeddings_to_use = None
                    else:
                        model_type = metadata.get("embedding_model_type", "sentence-transformer")
                        log_info("Loading embedding model: %s (%s)", model_name, model_type)
                        model = load_embedding_model(model_name, model_type)
                        new_embeddings = []
                        if model_type == "clip":
                            # CLIP: encode per-document
                            for d in docs:
                                new_embeddings.append(encode_text(d, model, model_type))
                        else:
                            # sentence-transformer supports batch encode
                            new_embeddings = model.encode(docs, show_progress_bar=False).tolist()

                        embeddings_to_use = new_embeddings
                        log_info("Successfully recomputed %d embeddings", len(new_embeddings))
                except Exception as e:
                    log_error("Failed to recompute embeddings: %s", e)
                    embeddings_to_use = None

            else:
                # Default (None): Use stored embeddings as-is if available
                if stored_embeddings:
                    # Check dimension compatibility with target collection
                    try:
                        if stored_embeddings and len(stored_embeddings) > 0:
                            stored_dim = len(stored_embeddings[0])
                            target_dim = inferred_size  # We already calculated this above

                            if stored_dim == target_dim:
                                log_info(
                                    "Using stored embeddings from backup (dimension: %d)",
                                    stored_dim,
                                )
                                embeddings_to_use = stored_embeddings
                            else:
                                log_error(
                                    "Dimension mismatch: backup has %d, target needs %d. Omitting embeddings.",
                                    stored_dim,
                                    target_dim,
                                )
                                embeddings_to_use = None
                        else:
                            embeddings_to_use = stored_embeddings
                    except Exception as e:
                        log_error("Error checking embedding dimensions: %s", e)
                        # Try to use them anyway
                        embeddings_to_use = stored_embeddings
                else:
                    log_info("No embeddings in backup to restore")
                    embeddings_to_use = None

            success = connection.add_items(
                restore_collection_name,
                documents=data.get("documents", []),
                metadatas=data.get("metadatas"),
                ids=data.get("ids"),
                embeddings=embeddings_to_use,
            )

            if success:
                log_info("Collection '%s' restored from backup", restore_collection_name)
                log_info("Restored %d items", len(data.get("ids", [])))

                # Save model config to app settings if available
                if profile_name and restore_collection_name and metadata:
                    try:
                        embed_model = metadata.get("embedding_model")
                        embed_model_type = metadata.get(
                            "embedding_model_type", "sentence-transformer"
                        )
                        if embed_model:
                            from vector_inspector.services.settings_service import SettingsService

                            settings = SettingsService()
                            settings.save_embedding_model(
                                profile_name,
                                restore_collection_name,
                                embed_model,
                                embed_model_type,
                            )
                            log_info(
                                "Saved model config to settings: %s (%s)",
                                embed_model,
                                embed_model_type,
                            )
                    except Exception as e:
                        log_error("Failed to save model config to settings: %s", e)

                # Clear the cache for this collection so the info panel gets fresh data
                if profile_name and restore_collection_name:
                    try:
                        from vector_inspector.core.cache_manager import get_cache_manager

                        cache = get_cache_manager()
                        # Use profile_name as the database identifier for cache
                        cache.invalidate(profile_name, restore_collection_name)
                        log_info(
                            "Cleared cache for restored collection: %s",
                            restore_collection_name,
                        )
                    except Exception as e:
                        log_error("Failed to clear cache after restore: %s", e)

                return True

            # Failure: attempt cleanup
            log_error("Failed to restore collection %s", restore_collection_name)
            try:
                if restore_collection_name in connection.list_collections():
                    log_info(
                        "Cleaning up failed restore: deleting collection '%s'",
                        restore_collection_name,
                    )
                    connection.delete_collection(restore_collection_name)
            except Exception as cleanup_error:
                log_error("Warning: Failed to clean up collection: %s", cleanup_error)
            return False

        except Exception as e:
            log_error("Restore failed: %s", e)
            try:
                if (
                    restore_collection_name
                    and restore_collection_name in connection.list_collections()
                ):
                    log_info(
                        "Cleaning up failed restore: deleting collection '%s'",
                        restore_collection_name,
                    )
                    connection.delete_collection(restore_collection_name)
            except Exception as cleanup_error:
                log_error("Warning: Failed to clean up collection: %s", cleanup_error)
            return False

    @staticmethod
    def list_backups(backup_dir: str) -> list:
        """
        List all backup files in a directory.

        Args:
            backup_dir: Directory containing backups

        Returns:
            List of backup file information dictionaries
        """
        backup_path = Path(backup_dir)
        if not backup_path.exists():
            return []

        backups = []
        for backup_file in backup_path.glob("*_backup_*.zip"):
            try:
                metadata, _ = read_backup_zip(backup_file)
                backups.append(
                    {
                        "file_path": str(backup_file),
                        "file_name": backup_file.name,
                        "collection_name": metadata.get("collection_name", "Unknown"),
                        "timestamp": metadata.get("backup_timestamp", "Unknown"),
                        "item_count": metadata.get("item_count", 0),
                        "file_size": backup_file.stat().st_size,
                    }
                )
            except Exception:
                continue

        backups.sort(key=lambda x: x["timestamp"], reverse=True)
        return backups

    @staticmethod
    def delete_backup(backup_file: str) -> bool:
        """
        Delete a backup file.

        Args:
            backup_file: Path to backup file to delete

        Returns:
            True if successful, False otherwise
        """
        try:
            Path(backup_file).unlink()
            return True
        except Exception as e:
            log_error("Failed to delete backup: %s", e)
            return False
