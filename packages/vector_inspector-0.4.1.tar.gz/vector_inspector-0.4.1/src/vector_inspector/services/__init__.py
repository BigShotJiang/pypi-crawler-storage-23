"""Services for embeddings, visualization, and data processing."""
