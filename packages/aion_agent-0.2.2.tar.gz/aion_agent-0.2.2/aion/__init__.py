"""Aion — AI calendar scheduling agent for Google Calendar."""

__version__ = "0.2.2"
