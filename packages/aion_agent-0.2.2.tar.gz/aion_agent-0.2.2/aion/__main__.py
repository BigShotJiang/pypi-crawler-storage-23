"""Allow running as `python -m aion`."""

from aion.cli import main

main()
