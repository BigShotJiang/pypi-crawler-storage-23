from datetime import datetime
from typing import Annotated
from sqlalchemy import String, func
from sqlalchemy.orm import Mapped, mapped_column
from .database import Base

# Reusable "types" to keep models DRY
pk_int = Annotated[int, mapped_column(primary_key=True, autoincrement=True)]
timestamp = Annotated[datetime, mapped_column(server_default=func.now())]

class User(Base):
    __tablename__ = "users"

    id: Mapped[pk_int]
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True)
    email: Mapped[str] = mapped_column(String(255), unique=True)
    created_at: Mapped[timestamp]

    def __repr__(self) -> str:
        return f"<User(id={self.id}, username='{self.username}')>"