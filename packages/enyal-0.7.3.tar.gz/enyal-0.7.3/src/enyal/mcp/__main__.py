"""Allow running enyal MCP server as: python -m enyal.mcp"""

from enyal.mcp.server import main

if __name__ == "__main__":
    main()
