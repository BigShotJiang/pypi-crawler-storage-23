# jax2onnx/plugins/flax/linen/__init__.py
