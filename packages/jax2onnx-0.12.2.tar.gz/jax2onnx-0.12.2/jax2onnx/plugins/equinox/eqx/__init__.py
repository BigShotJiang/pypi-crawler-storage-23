# jax2onnx/plugins/equinox/eqx/__init__.py

"""Equinox nn plugin registrations for converter."""
