# jax2onnx/plugins/jax/nn/log_sigmoid.py

from __future__ import annotations

from typing import Callable, ClassVar, Final

import jax
from jax.extend.core import Primitive
import jax.numpy as jnp
from numpy.typing import ArrayLike

from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins._patching import AssignSpec, MonkeyPatchSpec
from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins.jax._autodiff_utils import register_jvp_via_jax_jvp
from jax2onnx.plugins.jax.nn._builder_utils import register_unary_elementwise_batch_rule
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive


_LOG_SIGMOID_PRIM: Final[Primitive] = Primitive("jax.nn.log_sigmoid")
_LOG_SIGMOID_PRIM.multiple_results = False
_JAX_LOG_SIGMOID_ORIG: Final = jax.nn.log_sigmoid


@register_primitive(
    jaxpr_primitive=_LOG_SIGMOID_PRIM.name,
    jax_doc="https://docs.jax.dev/en/latest/_autosummary/jax.nn.log_sigmoid.html",
    onnx=[
        {
            "component": "Sigmoid",
            "doc": "https://onnx.ai/onnx/operators/onnx__Sigmoid.html",
        },
        {"component": "Log", "doc": "https://onnx.ai/onnx/operators/onnx__Log.html"},
    ],
    since="0.12.1",
    context="primitives.nn",
    component="log_sigmoid",
    testcases=[
        {
            "testcase": "jaxnn_log_sigmoid",
            "callable": lambda x: jax.nn.log_sigmoid(x),
            "input_shapes": [(2, 5)],
            "post_check_onnx_graph": EG(
                ["Sigmoid:2x5 -> Log:2x5"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "jaxnn_log_sigmoid_dynamic",
            "callable": lambda x: jax.nn.log_sigmoid(x),
            "input_shapes": [("B", 4)],
            "post_check_onnx_graph": EG(
                ["Sigmoid:Bx4 -> Log:Bx4"],
                symbols={"B": None},
                no_unused_inputs=True,
            ),
        },
    ],
)
class LogSigmoidPlugin(PrimitiveLeafPlugin):
    """Lower ``jax.nn.log_sigmoid`` via ONNX ``Sigmoid`` + ``Log``."""

    _PRIM: ClassVar[Primitive] = _LOG_SIGMOID_PRIM
    _ABSTRACT_EVAL_BOUND: ClassVar[bool] = False

    @staticmethod
    def abstract_eval(x: jax.core.AbstractValue) -> jax.core.ShapedArray:
        return jax.core.ShapedArray(x.shape, x.dtype)

    def lower(self, ctx: LoweringContextProtocol, eqn: jax.core.JaxprEqn) -> None:
        x_var = eqn.invars[0]
        out_var = eqn.outvars[0]

        x_val = ctx.get_value_for_var(
            x_var,
            name_hint=ctx.fresh_name("log_sigmoid_in"),
        )
        out_spec = ctx.get_value_for_var(
            out_var,
            name_hint=ctx.fresh_name("log_sigmoid_out"),
        )

        desired_name = getattr(out_spec, "name", None) or ctx.fresh_name(
            "log_sigmoid_out"
        )
        producer = getattr(out_spec, "producer", None)
        if callable(producer) and producer() is not None:
            desired_name = ctx.fresh_name("log_sigmoid_out")

        out_type = getattr(out_spec, "type", None) or getattr(x_val, "type", None)
        out_shape = getattr(out_spec, "shape", None) or getattr(x_val, "shape", None)

        sig = ctx.builder.Sigmoid(
            x_val,
            _outputs=[ctx.fresh_name("log_sigmoid_sigmoid")],
        )
        if out_type is not None:
            sig.type = out_type
        if out_shape is not None:
            sig.shape = out_shape

        result = ctx.builder.Log(
            sig,
            _outputs=[desired_name],
        )
        if out_type is not None:
            result.type = out_type
        if out_shape is not None:
            result.shape = out_shape
        ctx.bind_value_for_var(out_var, result)

    @classmethod
    def ensure_abstract_eval_bound(cls):
        if not cls._ABSTRACT_EVAL_BOUND:
            cls._PRIM.def_abstract_eval(cls.abstract_eval)
            cls._ABSTRACT_EVAL_BOUND = True

    @classmethod
    def binding_specs(cls) -> list[AssignSpec | MonkeyPatchSpec]:
        def _make_value(
            orig: Callable[..., ArrayLike] | None,
        ) -> Callable[..., ArrayLike]:
            if orig is None:
                raise RuntimeError("Original jax.nn.log_sigmoid not found")

            def _patched(x: ArrayLike) -> ArrayLike:
                x_arr = jnp.asarray(x)
                if not jnp.issubdtype(x_arr.dtype, jnp.floating):
                    return orig(x)
                return cls._PRIM.bind(x_arr)

            return _patched

        return [
            AssignSpec("jax.nn", "log_sigmoid_p", cls._PRIM, delete_if_missing=True),
            MonkeyPatchSpec(
                target="jax.nn",
                attr="log_sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
            MonkeyPatchSpec(
                target="flax.linen.activation",
                attr="log_sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
            MonkeyPatchSpec(
                target="flax.linen",
                attr="log_sigmoid",
                make_value=_make_value,
                delete_if_missing=False,
            ),
        ]


@LogSigmoidPlugin._PRIM.def_impl
def _log_sigmoid_impl(x: ArrayLike) -> ArrayLike:
    return _JAX_LOG_SIGMOID_ORIG(x)


register_unary_elementwise_batch_rule(LogSigmoidPlugin._PRIM)
register_jvp_via_jax_jvp(LogSigmoidPlugin._PRIM, _log_sigmoid_impl)
