"""
Storage layer for AutoRESTify.
"""

from .base import Database

__all__ = ["Database"]
