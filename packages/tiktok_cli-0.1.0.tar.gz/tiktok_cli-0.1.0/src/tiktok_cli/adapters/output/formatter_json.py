from __future__ import annotations

import json
from typing import Any

from pydantic import BaseModel


def format_json(payload: Any, ensure_ascii: bool = False, indent: int = 2) -> str:
    if isinstance(payload, BaseModel):
        data = payload.model_dump(mode="json")
    else:
        data = payload
    return json.dumps(data, ensure_ascii=ensure_ascii, indent=indent)


def format_jsonl(payloads: list[Any], ensure_ascii: bool = False) -> str:
    lines = []
    for item in payloads:
        if isinstance(item, BaseModel):
            item = item.model_dump(mode="json")
        lines.append(json.dumps(item, ensure_ascii=ensure_ascii))
    return "\n".join(lines)
