from __future__ import annotations

import sys

from loguru import logger


def setup_cli_logger(quiet: bool = False) -> None:
    logger.remove()
    level = "ERROR" if quiet else "INFO"
    logger.add(sys.stderr, level=level, colorize=True, backtrace=False, diagnose=False)
