from __future__ import annotations

from dataclasses import dataclass


@dataclass
class CliContext:
    platform_name: str = "Rednote"
    output_format: str = "table"
    out_file: str | None = None
    quiet: bool = False
    trace_id: str | None = None
    timeout: int = 120
