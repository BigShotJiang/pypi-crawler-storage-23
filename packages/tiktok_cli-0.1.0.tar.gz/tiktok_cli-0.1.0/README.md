# tiktok-cli

TikTok 平台专用 CLI 包（独立安装、独立升级）。

## 安装

```bash
pipx install tiktok-cli
```

## 当前状态

命令接口已与 `rednote-cli` 对齐，平台适配器仍在建设中。
当前业务命令会返回：
- 错误码：`DEPENDENCY_MISSING`
- 退出码：`7`

## 文档

完整文档请查看仓库根目录：
- `README.md`
- `DESIGN.md`
- `DEV.md`
- `USER_GUIDE.md`
