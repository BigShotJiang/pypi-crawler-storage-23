"""solidlsp 호환 상수를 제공한다."""

DEFAULT_SOURCE_FILE_ENCODING = "utf-8"
