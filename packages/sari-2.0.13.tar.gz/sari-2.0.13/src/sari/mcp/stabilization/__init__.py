"""MCP stabilization 유틸 모듈을 노출한다."""

