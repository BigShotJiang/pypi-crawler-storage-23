"""LibreLyrics plugin modules package."""
from librelyrics.modules.base import LyricsModule, LyricsType, ModuleMeta

__all__ = ['LyricsModule', 'LyricsType', 'ModuleMeta']
