
from mptt.fields import TreeNodeChoiceField


class CategoryChoiceField(TreeNodeChoiceField):
    pass
