"""Templates package for vectl."""
