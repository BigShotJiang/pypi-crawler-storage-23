from __future__ import annotations

import importlib
import json
import re
from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timedelta
from importlib.metadata import PackageMetadata
from pathlib import Path
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Iterable, Iterator

import numpy as np
import soundfile as sf
from rich.table import Table

from drmeter import __name__ as pkg_name
from drmeter.utils import (
    fmt_dr_score,
    rich_box,
    rich_spinner,
    serialize,
    to_decibels,
)

if TYPE_CHECKING:
    from rich.console import Console, ConsoleOptions, RenderableType

_bitdepth_re = re.compile(r"bit width\s*:\s*(\d+)", re.MULTILINE | re.IGNORECASE)


@dataclass(slots=True, frozen=True)
class AudioData:
    data: sf.SoundFile | np.ndarray
    samplerate: int
    channels: int
    frames: int
    bitdepth: int = -1
    codec: str = ""

    @property
    def duration(self) -> timedelta:
        return timedelta(seconds=round(float(self.frames) / self.samplerate))

    def blocks(self, blocksize: int) -> Iterator[np.ndarray]:
        if isinstance(self.data, sf.SoundFile):
            yield from self.data.blocks(blocksize=blocksize)
            return
        idx = 0
        while len(block := self.data[idx:blocksize]) > 0:
            yield block
            idx += blocksize

    @classmethod
    def from_soundfile(cls, soundfile: sf.SoundFile) -> AudioData:
        extra_info = soundfile.extra_info
        bitdepth = -1
        if match := _bitdepth_re.search(extra_info):
            bitdepth = int(match.group(1))

        return cls(
            data=soundfile,
            channels=soundfile.channels,
            frames=soundfile.frames,
            samplerate=soundfile.samplerate,
            bitdepth=bitdepth,
            codec=soundfile.format,
        )


@dataclass
class DynamicRangeResult:
    dr_score: np.ndarray
    peak_pressure: np.ndarray = field(repr=False)
    rms_pressure: np.ndarray = field(repr=False)

    peak_db: np.ndarray = field(repr=False, init=False)
    rms_db: np.ndarray = field(repr=False, init=False)

    overall_dr_score: float = field(repr=False, init=False)
    overall_peak_pressure: float = field(repr=False, init=False)
    overall_rms_pressure: float = field(repr=False, init=False)

    overall_peak_db: float = field(init=False)
    overall_rms_db: float = field(init=False)

    def __post_init__(self) -> None:
        self.overall_dr_score = self.dr_score.mean() if isinstance(self.dr_score, np.ndarray) else self.dr_score
        self.overall_peak_pressure = (
            self.peak_pressure.max() if isinstance(self.peak_pressure, np.ndarray) else self.peak_pressure
        )
        self.overall_rms_pressure = (
            self.rms_pressure.mean() if isinstance(self.rms_pressure, np.ndarray) else self.rms_pressure
        )
        self.peak_db = to_decibels(self.peak_pressure)  # type: ignore[type-var]
        self.rms_db = to_decibels(self.rms_pressure)  # type: ignore[type-var]
        self.overall_peak_db = to_decibels(self.overall_peak_pressure)
        self.overall_rms_db = to_decibels(self.overall_rms_pressure)


@dataclass(slots=True)
class AnalysisItem:
    path: Path
    data: AudioData | None = None
    result: DynamicRangeResult | None = None

    def analyze(self) -> None:
        from drmeter.algorithm import dynamic_range

        with sf.SoundFile(self.path) as soundfile:
            data = AudioData.from_soundfile(soundfile)
            self.data = data
            self.result = dynamic_range(data)

    def rich_table_render(self) -> tuple[RenderableType, ...]:
        if not self.result:
            return (rich_spinner, rich_spinner, rich_spinner, self.path.name)
        return (
            fmt_dr_score(self.result.overall_dr_score),
            f"{self.result.overall_peak_db:+6.2f} dB",
            f"{self.result.overall_rms_db:+6.2f} dB",
            self.path.name,
        )

    def to_dict(self) -> dict[str, Any]:
        data = {"filename": str(self.path.absolute())}
        if not self.result:
            return data

        obj = asdict(self.result)
        del obj["peak_pressure"]
        del obj["rms_pressure"]
        del obj["overall_peak_pressure"]
        del obj["overall_rms_pressure"]
        data.update(serialize(obj))
        return data


@dataclass(slots=True)
class _ExtraInfo:
    samplerates: list[float] = field(default_factory=list)
    channels: list[int] = field(default_factory=list)
    codecs: list[str] = field(default_factory=list)
    bitdepths: list[int] = field(default_factory=list)
    frames: int = 0

    def add(self, data: AudioData) -> None:
        self.samplerates.append(data.samplerate)
        self.channels.append(data.channels)
        self.codecs.append(data.codec)
        self.bitdepths.append(data.bitdepth)
        self.frames += data.frames

    def summarize(self) -> dict[str, str]:
        def _make_summary(collection: list, unit: str = "") -> str:
            if not collection:
                return ""
            counts = Counter(collection)
            unit = " " + unit if unit else ""
            return (
                ", ".join(f"{val}{unit} ({count}x)" for val, count in counts.items())
                if len(counts) > 1
                else f"{collection[0]}{unit}"
            )

        return {
            "samplerate": _make_summary(self.samplerates, "Hz"),
            "channels": _make_summary(self.channels),
            "bitdepth": _make_summary(self.bitdepths),
            "codecs": _make_summary(self.codecs),
        }


@dataclass
class AnalysisList:
    results: dict[Path, AnalysisItem] = field(default_factory=dict)

    overall_result: DynamicRangeResult | None = None

    _table: Table | None = None
    _directory: Path | None = None
    _overall_count: int = 0

    def __len__(self) -> int:
        return len(self.results)

    @classmethod
    def from_paths(cls, paths: list[Path]) -> AnalysisList:
        return cls(results={path: AnalysisItem(path=path) for path in paths})

    def analyze(self, debug: bool = False, live: bool = False) -> None:
        if debug:
            import click

            for path, result in self.results.items():
                click.echo(f"Analyzing {path} ...")
                result.analyze()
        else:

            def analyze_and_update(result: AnalysisItem) -> None:
                result.analyze()
                if live:
                    self.calculate_overall_result()
                    self.generate_table()

            with ThreadPoolExecutor() as pool:
                for result in self.results.values():
                    pool.submit(analyze_and_update, result)

        self.calculate_overall_result()

    def to_json(self) -> str:
        results = [item.to_dict() for item in self.results.values() if item.result]
        return json.dumps(results, indent=2)

    def to_plain(self, *, source: str = "") -> str:
        metadata: PackageMetadata = importlib.metadata.metadata(pkg_name)
        version = metadata["Version"]
        url = metadata["Project-URL"].split()[-1]
        table = []
        info = _ExtraInfo()
        for filename, item in self.results.items():
            assert item.data
            assert item.result
            info.add(item.data)
            dur = str(item.data.duration).lstrip("0:")
            r = item.result
            table.append(
                f"DR{r.overall_dr_score:<3.0f} {r.overall_peak_db:9.2f} dBFS {r.overall_rms_db:9.2f} dBFS {dur:>9}  {filename.name}"
            )

        assert self.overall_result

        summary = info.summarize()
        div_len = min(max(len(row) for row in table), 120)
        div = "-" * div_len

        header = dedent(f"""\
            drmeter {version} ({url})
            log date: {datetime.now():%Y-%m-%d %H:%M:%S}

            {div}
            Analyzed: {source}
            {div}

            DR         Peak            RMS       Duration  Track
            {div}
            """)

        footer = dedent(f"""\
            {div}

            Number of tracks:  {len(self)}
            Official DR value: DR{self.overall_result.overall_dr_score:.0f}

            Samplerate:        {summary["samplerate"]}
            Channels:          {summary["channels"]}
            Bits per sample:   {summary["bitdepth"]}
            Codec:             {summary["codecs"]}
            """)

        return header + "\n".join(table) + "\n" + footer + "=" * div_len

    def generate_table(self) -> None:
        self._table = Table(show_header=True, header_style="bold magenta", box=rich_box)
        self._table.add_column("DR", width=5)
        self._table.add_column("Peak", justify="right", width=10)
        self._table.add_column("RMS", justify="right", width=10)
        self._table.add_column("Filename")
        for _, result in sorted(self.results.items()):
            self._table.add_row(*result.rich_table_render())

        if len(self.results) < 2:
            return

        self._table.add_section()
        desc = f"Overall ({self._overall_count} file{'s' if self._overall_count != 1 else ''})"
        style = "bold magenta"
        if self.overall_result and self._overall_count:
            self._table.add_row(
                fmt_dr_score(self.overall_result.overall_dr_score),
                f"{self.overall_result.overall_peak_db:+6.2f} dB",
                f"{self.overall_result.overall_rms_db:+6.2f} dB",
                desc,
                style=style,
            )
        else:
            self._table.add_row(rich_spinner, rich_spinner, rich_spinner, desc, style=style)

    def calculate_overall_result(self) -> None:
        result_count = 0

        dr_score = 0.0
        peak_pressure = 0.0
        rms_pressure = 0.0
        for result in self.results.values():
            if not result.result:
                continue

            dr_score += result.result.overall_dr_score
            peak_pressure = max(result.result.overall_peak_pressure, peak_pressure)
            rms_pressure += result.result.overall_rms_pressure
            result_count += 1

        if result_count > 0:
            self.overall_result = DynamicRangeResult(
                dr_score=np.array([dr_score / result_count]),
                peak_pressure=np.array([peak_pressure]),
                rms_pressure=np.array([rms_pressure / result_count]),
            )
            self._overall_count = result_count

    def __rich_console__(self, console: Console, options: ConsoleOptions) -> Iterable[Table]:
        if not self._table:
            self.generate_table()
        assert self._table
        yield self._table
