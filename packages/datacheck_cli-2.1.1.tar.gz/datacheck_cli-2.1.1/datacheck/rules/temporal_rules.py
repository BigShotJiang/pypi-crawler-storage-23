"""Temporal validation rules."""

from datetime import timedelta

import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import FailureDetail, RuleResult
from datacheck.rules.base import Rule


def _to_datetime_fast(series: pd.Series) -> pd.Series:
    """Convert a Series to timestamps.

    Uses PyArrow's vectorized C++-level cast for Arrow-backed string columns,
    avoiding the element-by-element Python iteration that ``pd.to_datetime``
    triggers on Arrow-backed arrays (which can be 10-50x slower on large data).
    Falls back to ``pd.to_datetime`` for all other column types.
    """
    try:
        import pyarrow as pa

        if isinstance(series.dtype, pd.ArrowDtype):
            pa_type = series.dtype.pyarrow_dtype
            if pa.types.is_string(pa_type) or pa.types.is_large_string(pa_type):
                arr = series.array._pa_array
                try:
                    # Vectorized ISO-8601 cast — stays in C++, no Python iteration.
                    # Handles "YYYY-MM-DD", "YYYY-MM-DD HH:MM:SS", and ISO variants.
                    ts_arr = arr.cast(pa.timestamp("us"))
                    # Convert to numpy datetime64 so all .dt accessor operations
                    # (dayofweek, tz, etc.) work without Arrow's tzdata dependency.
                    return pd.Series(
                        ts_arr.to_pandas(),
                        index=series.index,
                        name=series.name,
                    )
                except Exception:
                    pass
    except Exception:
        pass
    return pd.to_datetime(series, errors="coerce", format="mixed")


def _parse_duration(duration: str) -> timedelta:
    """Parse a duration string into a timedelta.

    Supported formats:
        - "24h" -> 24 hours
        - "7d" -> 7 days
        - "1w" -> 1 week
        - "30m" -> 30 minutes

    Args:
        duration: Duration string

    Returns:
        timedelta object

    Raises:
        ValueError: If format is invalid
    """
    duration = duration.strip().lower()
    if not duration:
        raise ValueError("Duration string cannot be empty")

    unit = duration[-1]
    try:
        value = int(duration[:-1])
    except ValueError:
        raise ValueError(f"Invalid duration format: {duration}")

    if unit == "h":
        return timedelta(hours=value)
    elif unit == "d":
        return timedelta(days=value)
    elif unit == "w":
        return timedelta(weeks=value)
    elif unit == "m":
        return timedelta(minutes=value)
    else:
        raise ValueError(f"Unknown duration unit '{unit}'. Use h, d, w, or m.")


class MaxAgeRule(Rule):
    """Rule to validate that data is not older than a specified duration.

    Checks that the maximum timestamp in a column is within the specified
    duration from the current time.
    """

    def __init__(self, name: str, column: str, duration: str) -> None:
        """Initialize MaxAgeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            duration: Maximum age (e.g., "24h", "7d", "1w")

        Raises:
            RuleDefinitionError: If duration format is invalid
        """
        super().__init__(name, column)
        try:
            self.duration = _parse_duration(duration)
        except ValueError as e:
            raise RuleDefinitionError(str(e)) from e
        self.duration_str = duration

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that data is not older than the specified duration.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="max_age",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = _to_datetime_fast(df[self.column])
            valid_timestamps = timestamps.dropna()

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=False,
                    total_rows=total_rows,
                    error="No valid timestamps found in column",
                    rule_type="max_age",
                    check_name=self.name,
                )

            max_timestamp = valid_timestamps.max()
            col_tz = getattr(valid_timestamps.dt, "tz", None)
            now = pd.Timestamp.now(tz=col_tz) if col_tz is not None else pd.Timestamp.now()
            cutoff = now - self.duration

            if max_timestamp >= cutoff:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="max_age",
                    check_name=self.name,
                )

            age = now - max_timestamp
            failure_detail = FailureDetail(
                rule_name=self.name,
                column=self.column,
                failed_count=total_rows,
                total_count=total_rows,
                failure_rate=100.0,
                sample_failures=[],
                sample_values=[str(max_timestamp)],
                sample_reasons=[
                    f"Most recent data ({max_timestamp}) is older than {self.duration_str} (age: {age})"
                ],
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=total_rows,
                failure_details=failure_detail,
                rule_type="max_age",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing max_age rule: {e}",
                rule_type="max_age",
                check_name=self.name,
            )


class TimestampRangeRule(Rule):
    """Rule to validate that all timestamps fall within a specified range.

    All non-null values must be between min_timestamp and max_timestamp (inclusive).
    """

    def __init__(
        self, name: str, column: str, min_timestamp: str, max_timestamp: str
    ) -> None:
        """Initialize TimestampRangeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            min_timestamp: Minimum timestamp (ISO format or parseable string)
            max_timestamp: Maximum timestamp (ISO format or parseable string)

        Raises:
            RuleDefinitionError: If timestamps are invalid or min > max
        """
        super().__init__(name, column)
        try:
            self.min_timestamp = pd.to_datetime(min_timestamp)
            self.max_timestamp = pd.to_datetime(max_timestamp)
        except Exception as e:
            raise RuleDefinitionError(f"Invalid timestamp format: {e}") from e

        if self.min_timestamp > self.max_timestamp:
            raise RuleDefinitionError(
                f"min_timestamp ({min_timestamp}) cannot be after max_timestamp ({max_timestamp})"
            )

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all timestamps are within the specified range.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = _to_datetime_fast(df[self.column])
            non_null_mask = timestamps.notna()
            valid_timestamps = timestamps[non_null_mask]

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            # Ensure comparison timestamps match tz-awareness of the column
            col_tz = getattr(valid_timestamps.dt, "tz", None)
            min_ts = self.min_timestamp
            max_ts = self.max_timestamp
            if col_tz is not None and min_ts.tzinfo is None:
                min_ts = min_ts.tz_localize("UTC").tz_convert(col_tz)
                max_ts = max_ts.tz_localize("UTC").tz_convert(col_tz)

            # Find values outside range
            below_min = valid_timestamps < min_ts
            above_max = valid_timestamps > max_ts
            violation_mask = below_min | above_max
            violation_indices = valid_timestamps.index[violation_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="timestamp_range",
                    check_name=self.name,
                )

            failed_values = valid_timestamps.loc[violation_indices]
            reasons = []
            for ts in failed_values.iloc[:100]:
                if ts < min_ts:
                    reasons.append(f"Timestamp {ts} is before {min_ts}")
                else:
                    reasons.append(f"Timestamp {ts} is after {max_ts}")

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values.astype(str), reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="timestamp_range",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing timestamp_range rule: {e}",
                rule_type="timestamp_range",
                check_name=self.name,
            )


class NoFutureTimestampsRule(Rule):
    """Rule to validate that no timestamps are in the future.

    All non-null values must be less than or equal to the current time.
    """

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that no timestamps are in the future.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            # Convert column to datetime
            timestamps = _to_datetime_fast(df[self.column])
            non_null_mask = timestamps.notna()
            valid_timestamps = timestamps[non_null_mask]

            if len(valid_timestamps) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            col_tz = getattr(valid_timestamps.dt, "tz", None)
            now = pd.Timestamp.now(tz=col_tz) if col_tz is not None else pd.Timestamp.now()
            future_mask = valid_timestamps > now
            future_indices = valid_timestamps.index[future_mask]

            if len(future_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="no_future_timestamps",
                    check_name=self.name,
                )

            failed_values = valid_timestamps.loc[future_indices]
            reasons = [
                f"Timestamp {ts} is in the future (now: {now})"
                for ts in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                future_indices, total_rows, failed_values.astype(str), reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(future_indices),
                failure_details=failure_detail,
                rule_type="no_future_timestamps",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing no_future_timestamps rule: {e}",
                rule_type="no_future_timestamps",
                check_name=self.name,
            )


class DateFormatValidRule(Rule):
    """Rule to validate that all values parse successfully with a given format.

    All non-null values must be parseable as dates using the specified format string.
    """

    def __init__(self, name: str, column: str, format_string: str) -> None:
        """Initialize DateFormatValidRule.

        Args:
            name: Name of the rule
            column: Column to validate
            format_string: Expected date format (e.g., "%Y-%m-%d")
        """
        super().__init__(name, column)
        self.format_string = format_string

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that all values match the expected date format.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            # Detect pre-parsed datetime columns (numpy datetime64 or PyArrow
            # timestamp). The original string representation is lost once
            # pandas has parsed the column, so we use a round-trip check:
            # format the datetime with the user's format, parse it back, and
            # verify the result equals the original value. If the format loses
            # information (e.g. "%d/%m/%Y" drops the time component), the
            # round-trip produces a different timestamp, correctly signalling
            # a format mismatch.
            #
            # Special case: Arrow date32[day] columns.
            # date32 values have no time component, so any date-only format
            # round-trips to the same midnight value — the standard round-trip
            # cannot detect format mismatches. Instead, we convert the dates
            # to ISO strings (their natural representation) and try to parse
            # those strings with the user's format. A wrong format (e.g.
            # "%d/%m/%Y") will fail to parse "2024-01-15", correctly failing.
            import pyarrow as pa  # noqa: PLC0415
            _is_arrow_date = isinstance(data.dtype, pd.ArrowDtype) and pa.types.is_date(
                data.dtype.pyarrow_dtype
            )
            _is_datetime = pd.api.types.is_datetime64_any_dtype(data) or (
                isinstance(data.dtype, pd.ArrowDtype)
                and hasattr(data, "dt")
            )
            if _is_arrow_date:
                # Arrow date32 doesn't support dt.strftime directly.
                # Cast to datetime64[ns] (midnight UTC) first, then format.
                iso_strings = data.astype("datetime64[ns]").dt.strftime("%Y-%m-%d")
                parsed = pd.to_datetime(
                    iso_strings, format=self.format_string, errors="coerce"
                )
                valid_mask = parsed.notna()
            elif _is_datetime:
                dt_series = data.astype("datetime64[ns]")
                str_data = dt_series.dt.strftime(self.format_string)
                parsed = pd.to_datetime(
                    str_data, format=self.format_string, errors="coerce"
                )
                # Round-trip must recover the original timestamp exactly.
                # Formats that discard information (e.g. time-only format on
                # a column with time values) will not match.
                valid_mask = parsed.notna() & (parsed == dt_series)
            else:
                str_data = data.astype(str)
                parsed = pd.to_datetime(
                    str_data, format=self.format_string, errors="coerce"
                )
                valid_mask = parsed.notna()

            invalid_indices = data.index[~valid_mask]

            if len(invalid_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="date_format_valid",
                    check_name=self.name,
                )

            failed_values = data.loc[invalid_indices]
            reasons = [
                f"Value '{v}' does not match format '{self.format_string}'"
                for v in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                invalid_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(invalid_indices),
                failure_details=failure_detail,
                rule_type="date_format_valid",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing date_format_valid rule: {e}",
                rule_type="date_format_valid",
                check_name=self.name,
            )


