"""Composite validation rules."""

import numpy as np
import pandas as pd

from datacheck.exceptions import ColumnNotFoundError, RuleDefinitionError
from datacheck.results import RuleResult
from datacheck.rules.base import Rule


class UniqueRule(Rule):
    """Rule to check for duplicate values."""

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column has no duplicate values.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Find duplicates (excluding nulls)
            duplicated_mask = df[self.column].duplicated(keep=False)
            null_mask = df[self.column].isna()
            # Only count non-null duplicates
            duplicate_indices = df.index[duplicated_mask & ~null_mask]

            if len(duplicate_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="unique",
                    check_name=self.name,
                )

            # Get failed values and create reasons
            failed_values = df[self.column].loc[duplicate_indices]
            reasons = ["Value is duplicated"] * len(duplicate_indices)

            failure_detail = self._create_failure_detail(
                duplicate_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(duplicate_indices),
                failure_details=failure_detail,
                rule_type="unique",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing unique rule: {e}",
                rule_type="unique",
                check_name=self.name,
            )


class DataTypeRule(Rule):
    """Rule to check column values match a declared logical type.

    Validates that non-null values conform to the expected data type.
    No coercion is performed - this is type checking only.

    Supported types:
        - int (or integer): Integer values (no decimal part)
        - float (or numeric): Numeric values (integers also pass)
        - string: String/text values
        - bool: Boolean values (True/False)
        - date (or datetime): Date or datetime values
    """

    VALID_TYPES = {"int", "integer", "float", "numeric", "string", "bool", "date", "datetime"}
    TYPE_ALIASES = {"integer": "int", "numeric": "float", "datetime": "date"}

    def __init__(self, name: str, column: str, expected_type: str) -> None:
        """Initialize DataTypeRule.

        Args:
            name: Name of the rule
            column: Column to validate
            expected_type: Expected data type (int, float, string, bool, date, numeric, integer)

        Raises:
            RuleDefinitionError: If expected_type is not valid
        """
        super().__init__(name, column)
        expected_type_lower = expected_type.lower()
        if expected_type_lower not in self.VALID_TYPES:
            raise RuleDefinitionError(
                f"Invalid type '{expected_type}'. "
                f"Must be one of: {', '.join(sorted(self.VALID_TYPES))}"
            )
        # Normalize aliases
        self.expected_type = self.TYPE_ALIASES.get(expected_type_lower, expected_type_lower)

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column values match expected type.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            total_rows = len(df)

            # Filter out null values
            non_null_mask = df[self.column].notna()
            data = df[self.column][non_null_mask]

            if len(data) == 0:
                # All null - passes (nulls are ignored)
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="type",
                    check_name=self.name,
                )

            # Check type based on expected_type
            violation_mask = self._check_type(data)
            violation_indices = data.index[violation_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="type",
                    check_name=self.name,
                )

            # Get failed values and create reasons
            failed_values = data.loc[violation_indices]
            reasons = [
                f"Value '{v}' is not of type '{self.expected_type}'"
                for v in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="data_type",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing type rule: {e}",
                rule_type="data_type",
                check_name=self.name,
            )

    @staticmethod
    def _all_false(data: pd.Series) -> pd.Series:
        """Return a False Series (no violations) efficiently."""
        return pd.Series(False, index=data.index)

    @staticmethod
    def _all_true(data: pd.Series) -> pd.Series:
        """Return a True Series (all violations) efficiently."""
        return pd.Series(True, index=data.index)

    def _check_type(self, data: pd.Series) -> pd.Series:
        """Check if values match expected type.

        Uses Arrow dtype fast-paths when possible to avoid slow .apply() calls.

        Args:
            data: Series to check (non-null values only)

        Returns:
            Boolean Series where True indicates violation (type mismatch)
        """
        dtype_str = str(data.dtype).lower()

        if self.expected_type == "int":
            # Fast-path: Arrow or NumPy integer dtype
            if pd.api.types.is_integer_dtype(data):
                return self._all_false(data)
            if pd.api.types.is_float_dtype(data) or "double" in dtype_str:
                # Check if floats are actually whole numbers
                return data != data.round(0)
            # For object dtype: coerce to numeric, reject bools and non-whole floats
            coerced = pd.to_numeric(data, errors="coerce")
            bool_mask = data.astype(str).isin({"True", "False"})
            return coerced.isna() | bool_mask | (coerced != coerced.round(0))

        elif self.expected_type == "float":
            # Fast-path: any numeric dtype (Arrow or NumPy) passes
            if pd.api.types.is_numeric_dtype(data) or "double" in dtype_str:
                return self._all_false(data)
            coerced = pd.to_numeric(data, errors="coerce")
            bool_mask = data.astype(str).isin({"True", "False"})
            return coerced.isna() | bool_mask

        elif self.expected_type == "string":
            # Fast-path: Arrow string dtype — all values are strings by definition
            if pd.api.types.is_string_dtype(data) and data.dtype != object:
                return self._all_false(data)
            if pd.api.types.is_string_dtype(data) or data.dtype == object:
                # Object dtype may have mixed types, check each value
                check_fn = np.frompyfunc(lambda v: isinstance(v, str), 1, 1)
                return ~pd.Series(check_fn(data.values).astype(bool), index=data.index)
            return self._all_true(data)

        elif self.expected_type == "bool":
            # Fast-path: Arrow or NumPy bool dtype
            if pd.api.types.is_bool_dtype(data):
                return self._all_false(data)
            return ~data.astype(str).isin({"True", "False"})

        elif self.expected_type == "date":
            # Fast-path: datetime64 or Arrow timestamp dtype
            if pd.api.types.is_datetime64_any_dtype(data) or "timestamp" in dtype_str:
                return self._all_false(data)
            # Check for datetime objects via coercion
            converted = pd.to_datetime(data, errors="coerce", format="mixed")
            return converted.isna()

        # Should not reach here due to validation in __init__
        return self._all_true(data)



class SumEqualsRule(Rule):
    """Rule to validate that sum of two columns equals a target column.

    For each row, validates that column_a + column_b = target_column
    within a specified tolerance.
    """

    def __init__(
        self,
        name: str,
        column: str,
        column_a: str,
        column_b: str,
        tolerance: float = 0.01,
    ) -> None:
        """Initialize SumEqualsRule.

        Args:
            name: Name of the rule
            column: Target column that should equal sum
            column_a: First column to sum
            column_b: Second column to sum
            tolerance: Acceptable difference threshold (default: 0.01)

        Raises:
            RuleDefinitionError: If tolerance is negative
        """
        super().__init__(name, column)
        if tolerance < 0:
            raise RuleDefinitionError("tolerance cannot be negative")
        self.column_a = column_a
        self.column_b = column_b
        self.tolerance = tolerance

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that sum of columns equals target.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            self._check_column_exists(df)

            # Check other columns exist
            for col in [self.column_a, self.column_b]:
                if col not in df.columns:
                    raise ColumnNotFoundError(col, list(df.columns))

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="sum_equals",
                    check_name=self.name,
                )

            # Convert to numeric
            target = pd.to_numeric(df[self.column], errors="coerce")
            col_a = pd.to_numeric(df[self.column_a], errors="coerce")
            col_b = pd.to_numeric(df[self.column_b], errors="coerce")

            # Calculate expected sum
            expected_sum = col_a + col_b

            # Find rows where all values are non-null
            valid_mask = target.notna() & col_a.notna() & col_b.notna()

            if not valid_mask.any():
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="sum_equals",
                    check_name=self.name,
                )

            # Check difference within tolerance
            diff = abs(target - expected_sum)
            violation_mask = valid_mask & (diff > self.tolerance)
            violation_indices = df.index[violation_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="sum_equals",
                    check_name=self.name,
                )

            failed_values = target.loc[violation_indices]
            # Pre-slice all Series once for reason generation (avoid repeated .loc[])
            sample_idx = violation_indices[:100]
            s_col_a = col_a.loc[sample_idx]
            s_col_b = col_b.loc[sample_idx]
            s_expected = expected_sum.loc[sample_idx]
            s_target = target.loc[sample_idx]
            s_diff = diff.loc[sample_idx]
            reasons = [
                f"{self.column_a} ({a}) + {self.column_b} ({b}) = "
                f"{exp:.4f}, but {self.column} = {tgt:.4f} "
                f"(diff: {d:.4f} > tolerance: {self.tolerance})"
                for a, b, exp, tgt, d in zip(
                    s_col_a, s_col_b, s_expected, s_target, s_diff, strict=False
                )
            ]

            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(violation_indices),
                failure_details=failure_detail,
                rule_type="sum_equals",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing sum_equals rule: {e}",
                rule_type="sum_equals",
                check_name=self.name,
            )


class UniqueCombinationRule(Rule):
    """Rule to validate that combination of columns is unique.

    Checks that no duplicate combinations exist across the specified columns.
    """

    def __init__(self, name: str, column: str, columns: list[str]) -> None:
        """Initialize UniqueCombinationRule.

        Args:
            name: Name of the rule
            column: Primary column (used for reporting)
            columns: List of columns that should be unique together

        Raises:
            RuleDefinitionError: If columns list is empty
        """
        super().__init__(name, column)
        if not columns:
            raise RuleDefinitionError("columns list cannot be empty")
        self.columns = columns

    def validate(self, df: pd.DataFrame) -> RuleResult:
        """Validate that column combinations are unique.

        Args:
            df: DataFrame to validate

        Returns:
            RuleResult with validation outcome
        """
        try:
            # Check all columns exist
            for col in self.columns:
                if col not in df.columns:
                    raise ColumnNotFoundError(col, list(df.columns))

            total_rows = len(df)

            if total_rows == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=0,
                    failed_rows=0,
                    rule_type="unique_combination",
                    check_name=self.name,
                )

            # Find duplicate combinations
            duplicate_mask = df[self.columns].duplicated(keep=False)

            # Exclude rows where any column is null
            null_mask = df[self.columns].isna().any(axis=1)
            duplicate_mask = duplicate_mask & ~null_mask

            duplicate_indices = df.index[duplicate_mask]

            if len(duplicate_indices) == 0:
                return RuleResult(
                    rule_name=self.name,
                    column=self.column,
                    passed=True,
                    total_rows=total_rows,
                    failed_rows=0,
                    rule_type="unique_combination",
                    check_name=self.name,
                )

            # Create sample values as tuples of the column combination
            failed_values = df.loc[duplicate_indices, self.columns].apply(
                tuple, axis=1
            )
            columns_str = ", ".join(self.columns)
            reasons = [
                f"Duplicate combination found in columns [{columns_str}]: {v}"
                for v in failed_values.iloc[:100]
            ]

            failure_detail = self._create_failure_detail(
                duplicate_indices, total_rows, failed_values, reasons
            )

            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=total_rows,
                failed_rows=len(duplicate_indices),
                failure_details=failure_detail,
                rule_type="unique_combination",
                check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name,
                column=self.column,
                passed=False,
                total_rows=len(df),
                error=f"Error executing unique_combination rule: {e}",
                rule_type="unique_combination",
                check_name=self.name,
            )


class BooleanRule(Rule):
    """Rule to validate that a column contains only boolean (True/False) values."""

    def validate(self, df: pd.DataFrame) -> RuleResult:
        try:
            self._check_column_exists(df)
            total_rows = len(df)

            # Bool dtype — all values are inherently boolean
            if pd.api.types.is_bool_dtype(df[self.column]):
                return RuleResult(
                    rule_name=self.name, column=self.column, passed=True,
                    total_rows=total_rows, failed_rows=0,
                    rule_type="boolean", check_name=self.name,
                )

            non_null = df[self.column].dropna()
            valid_strs = {"True", "False", "true", "false", "1", "0"}
            violations_mask = ~non_null.astype(str).isin(valid_strs)
            violation_indices = non_null.index[violations_mask]

            if len(violation_indices) == 0:
                return RuleResult(
                    rule_name=self.name, column=self.column, passed=True,
                    total_rows=total_rows, failed_rows=0,
                    rule_type="boolean", check_name=self.name,
                )

            failed_values = non_null.loc[violation_indices]
            reasons = [f"Value '{v}' is not boolean" for v in failed_values.iloc[:100]]
            failure_detail = self._create_failure_detail(
                violation_indices, total_rows, failed_values, reasons
            )
            return RuleResult(
                rule_name=self.name, column=self.column, passed=False,
                total_rows=total_rows, failed_rows=len(violation_indices),
                failure_details=failure_detail, rule_type="boolean", check_name=self.name,
            )

        except ColumnNotFoundError:
            raise
        except Exception as e:
            return RuleResult(
                rule_name=self.name, column=self.column, passed=False,
                total_rows=len(df), rule_type="boolean", check_name=self.name,
                error=f"Error executing boolean rule: {e}",
            )
