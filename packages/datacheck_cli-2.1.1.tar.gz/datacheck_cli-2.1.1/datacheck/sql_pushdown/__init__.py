"""SQL aggregate pushdown for database validation."""

from datacheck.sql_pushdown.dialects import get_dialect, PUSHDOWN_CAPABLE_TYPES

__all__ = ["get_dialect", "PUSHDOWN_CAPABLE_TYPES"]
