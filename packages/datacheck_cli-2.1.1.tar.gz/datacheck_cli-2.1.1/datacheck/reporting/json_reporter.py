"""Enhanced JSON reporter with distribution analysis and suggestions.

Provides comprehensive JSON output including:
- Full validation results
- Distribution statistics for failed values
- Actionable suggestions for fixing issues
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from datacheck.reporting.distribution_analyzer import DistributionAnalyzer
from datacheck.reporting.suggestion_engine import SuggestionEngine
from datacheck.results import ValidationSummary


class JsonReporter:
    """Enhanced JSON reporter with distribution analysis and suggestions.

    Generates comprehensive JSON reports including:
    - Validation summary and statistics
    - Detailed rule results
    - Distribution analysis for numeric failures
    - Actionable suggestions for fixing issues
    """

    def __init__(
        self,
        include_suggestions: bool = True,
        include_distributions: bool = True,
        pretty: bool = True,
    ) -> None:
        """Initialize JSON reporter.

        Args:
            include_suggestions: Whether to include fix suggestions (default: True)
            include_distributions: Whether to include distribution analysis (default: True)
            pretty: Whether to format JSON with indentation (default: True)
        """
        self.include_suggestions = include_suggestions
        self.include_distributions = include_distributions
        self.pretty = pretty

        self._suggestion_engine = SuggestionEngine()
        self._distribution_analyzer = DistributionAnalyzer()

    def generate_report(
        self,
        summary: ValidationSummary,
        df: pd.DataFrame | None = None,
        source_info: str | None = None,
        elapsed: float | None = None,
    ) -> dict[str, Any]:
        """Generate comprehensive JSON report.

        Args:
            summary: ValidationSummary to report
            df: Optional DataFrame for distribution analysis
            source_info: Human-readable description of the data source
            elapsed: Validation elapsed time in seconds

        Returns:
            Dictionary containing full report data
        """
        report: dict[str, Any] = {
            "metadata": self._generate_metadata(source_info, elapsed),
            "summary": self._generate_summary(summary),
            "results": self._generate_results(summary),
        }

        # Add distribution analysis if enabled
        if self.include_distributions:
            distributions = self._distribution_analyzer.analyze_summary(summary, df)
            report["distributions"] = [d.to_dict() for d in distributions]

        # Add suggestions if enabled
        if self.include_suggestions:
            suggestions = self._suggestion_engine.analyze(summary)
            report["suggestions"] = [s.to_dict() for s in suggestions]

        return report

    def export(
        self,
        summary: ValidationSummary,
        output_path: str | Path | None = None,
        df: pd.DataFrame | None = None,
        source_info: str | None = None,
        elapsed: float | None = None,
    ) -> str:
        """Export validation results to JSON format.

        Args:
            summary: ValidationSummary to export
            output_path: Optional file path to write JSON
            df: Optional DataFrame for distribution analysis
            source_info: Human-readable description of the data source
            elapsed: Validation elapsed time in seconds

        Returns:
            JSON string representation of report
        """
        report = self.generate_report(summary, df, source_info=source_info, elapsed=elapsed)

        indent = 2 if self.pretty else None
        json_str = json.dumps(report, indent=indent, default=str)

        if output_path:
            path = Path(output_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json_str, encoding="utf-8")

        return json_str

    def _generate_metadata(
        self,
        source_info: str | None = None,
        elapsed: float | None = None,
    ) -> dict[str, Any]:
        """Generate report metadata."""
        meta: dict[str, Any] = {
            "generated_at": datetime.now(timezone.utc).isoformat(),
            "report_version": "1.0",
            "includes_suggestions": self.include_suggestions,
            "includes_distributions": self.include_distributions,
        }
        if source_info:
            meta["source"] = source_info
        if elapsed is not None:
            meta["elapsed_seconds"] = round(elapsed, 3)
        return meta

    def _generate_summary(self, summary: ValidationSummary) -> dict[str, Any]:
        """Generate summary statistics."""
        if summary.all_passed and summary.has_failures:
            status = "PASSED_WITH_WARNINGS"
        elif summary.all_passed:
            status = "PASSED"
        else:
            status = "FAILED"

        return {
            "status": status,
            "total_rows": summary.total_rows,
            "total_columns": summary.total_columns,
            "total_rules": summary.total_rules,
            "passed_rules": summary.passed_rules,
            "failed_rules": summary.failed_rules,
            "failed_errors": summary.failed_errors,
            "failed_warnings": summary.failed_warnings,
            "failed_info": summary.failed_info,
            "execution_errors": summary.error_rules,
            "pass_rate": round(
                (summary.passed_rules / summary.total_rules * 100)
                if summary.total_rules > 0
                else 0,
                2,
            ),
        }

    def _generate_results(self, summary: ValidationSummary) -> list[dict[str, Any]]:
        """Generate detailed results for each rule.

        Args:
            summary: ValidationSummary containing results

        Returns:
            List of result dictionaries
        """
        results: list[dict[str, Any]] = []

        for result in summary.results:
            if result.has_error:
                status = "ERROR"
            elif result.passed:
                status = "PASS"
            elif result.severity == "warning":
                status = "WARNING"
            elif result.severity == "info":
                status = "INFO"
            else:
                status = "FAIL"

            result_dict: dict[str, Any] = {
                "check_name": result.check_name or result.rule_name,
                "column": result.column,
                "rule_type": result.rule_type or "",
                "severity": result.severity,
                "status": status,
                "total_rows": result.total_rows,
                "failed_rows": result.failed_rows,
                "success_rate": round(result.success_rate, 2),
                "failure_rate": round(
                    (result.failed_rows / result.total_rows * 100)
                    if result.total_rows > 0
                    else 0,
                    2,
                ),
            }

            # Add error message if present
            if result.error:
                result_dict["error"] = result.error

            # Add failure details if present
            if result.failure_details:
                details = result.failure_details
                result_dict["failure_details"] = {
                    "sample_count": len(details.sample_failures),
                    "samples": [
                        {
                            "row_index": details.sample_failures[i],
                            "value": str(details.sample_values[i])
                            if i < len(details.sample_values)
                            else None,
                            "reason": details.sample_reasons[i]
                            if i < len(details.sample_reasons)
                            else "",
                        }
                        for i in range(len(details.sample_failures))
                    ],
                }

            results.append(result_dict)

        return results


__all__ = [
    "JsonReporter",
]
