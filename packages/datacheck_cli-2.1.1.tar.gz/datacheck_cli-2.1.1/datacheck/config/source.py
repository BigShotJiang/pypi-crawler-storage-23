"""Source configuration for DataCheck.

Defines named data sources with environment variable-secured credentials.
Sources are defined in a separate YAML file (e.g., sources.yaml) and
referenced by name in validation configs.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from datacheck.config.parser import ConfigParser
from datacheck.exceptions import ConfigurationError

# Valid source types and their required connection fields
_SOURCE_TYPES: dict[str, list[str]] = {
    # Database connectors
    "postgresql": ["host", "database", "user"],
    "mysql": ["host", "database", "user"],
    "snowflake": ["account", "user"],
    "bigquery": ["project_id"],
    "redshift": ["host", "database", "user"],
    # File loaders
    "csv": ["path"],
    "parquet": ["path"],
    # Cloud storage
    "s3": ["bucket"],
}

# Source types that are database connectors
DATABASE_TYPES = {"postgresql", "mysql", "snowflake", "bigquery", "redshift"}

# Source types that are file-based loaders
FILE_TYPES = {"csv", "parquet"}

# Source types that are cloud storage
CLOUD_TYPES = {"s3"}


@dataclass
class SourceConfig:
    """Configuration for a named data source.

    Attributes:
        name: Unique identifier for this source
        type: Source type (e.g., 'postgresql', 'snowflake', 's3')
        connection: Type-specific connection parameters
    """

    name: str
    type: str
    connection: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Validate source configuration."""
        if not self.name:
            raise ConfigurationError("Source name cannot be empty")
        if not self.type:
            raise ConfigurationError(
                f"Source type cannot be empty for source '{self.name}'"
            )
        if self.type not in _SOURCE_TYPES:
            raise ConfigurationError(
                f"Invalid source type '{self.type}' for source '{self.name}'. "
                f"Valid types: {', '.join(sorted(_SOURCE_TYPES))}"
            )

        # Validate required fields for the source type
        required_fields = _SOURCE_TYPES[self.type]
        missing = [f for f in required_fields if not self.connection.get(f)]
        if missing:
            raise ConfigurationError(
                f"Source '{self.name}' (type={self.type}) missing required fields: "
                f"{', '.join(missing)}"
            )

    @property
    def is_database(self) -> bool:
        """Check if this source is a database connector type."""
        return self.type in DATABASE_TYPES

    @property
    def is_file(self) -> bool:
        """Check if this source is a file-based loader type."""
        return self.type in FILE_TYPES

    @property
    def is_cloud(self) -> bool:
        """Check if this source is a cloud storage type."""
        return self.type in CLOUD_TYPES


def load_sources(sources_path: str | Path) -> dict[str, SourceConfig]:
    """Load source definitions from a YAML file.

    Environment variables in the file are resolved using ${VAR} syntax.
    Supports ${VAR:-default} for default values.

    Args:
        sources_path: Path to the sources YAML file

    Returns:
        Dictionary mapping source names to SourceConfig objects

    Raises:
        ConfigurationError: If file not found, invalid YAML,
            or invalid source definitions
    """
    path = Path(sources_path)

    if not path.exists():
        raise ConfigurationError(f"Sources file not found: {sources_path}")

    # Use ConfigParser to load with env var resolution
    parser = ConfigParser()
    data = parser.load(path, resolve_env=True, resolve_extends=False)

    if not data:
        raise ConfigurationError(f"Sources file is empty: {sources_path}")

    # Sources can be under a 'sources' key or at top level
    sources_data = data.get("sources", data)

    if not isinstance(sources_data, dict):
        raise ConfigurationError(
            "Sources file must contain a dictionary of named sources"
        )

    sources: dict[str, SourceConfig] = {}
    for name, config in sources_data.items():
        if not isinstance(config, dict):
            raise ConfigurationError(
                f"Source '{name}' must be a dictionary, "
                f"got {type(config).__name__}"
            )

        # Copy to avoid mutating parsed data
        config = dict(config)

        source_type = config.pop("type", None)
        if not source_type:
            raise ConfigurationError(
                f"Source '{name}' missing required 'type' field"
            )

        sources[name] = SourceConfig(
            name=name,
            type=source_type,
            connection=config,
        )

    return sources


__all__ = [
    "SourceConfig",
    "load_sources",
    "DATABASE_TYPES",
    "FILE_TYPES",
    "CLOUD_TYPES",
]
