"""Connection string parsing utilities.

Parses connection URIs for various data sources into component parts.
"""

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import parse_qs, urlparse


@dataclass
class ConnectionInfo:
    """Parsed connection information.

    Attributes:
        type: Connection type (snowflake, bigquery, redshift, postgresql, etc.)
        host: Host or account identifier
        port: Port number (if applicable)
        database: Database name
        schema: Schema or dataset name
        username: Username (if provided)
        password: Password (if provided)
        params: Additional query parameters
    """

    type: str
    host: str | None = None
    port: int | None = None
    database: str | None = None
    schema: str | None = None
    username: str | None = None
    password: str | None = None
    params: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary.

        Returns:
            Dictionary representation
        """
        return {
            "type": self.type,
            "host": self.host,
            "port": self.port,
            "database": self.database,
            "schema": self.schema,
            "username": self.username,
            "password": self.password,
            "params": self.params,
        }


def parse_connection_string(connection_string: str) -> ConnectionInfo:
    """Parse connection string into components.

    Args:
        connection_string: Connection URI

    Returns:
        ConnectionInfo with parsed components

    Examples:
        >>> parse_connection_string("snowflake://account.region/database")
        ConnectionInfo(type='snowflake', host='account.region', database='database')

        >>> parse_connection_string("bigquery://project-id/dataset-id")
        ConnectionInfo(type='bigquery', host='project-id', database='dataset-id')

        >>> parse_connection_string("redshift://host:5439/database")
        ConnectionInfo(type='redshift', host='host', port=5439, database='database')

        >>> parse_connection_string("postgresql://user:pass@host:5432/database")
        ConnectionInfo(type='postgresql', host='host', port=5432, ...)
    """
    parsed = urlparse(connection_string)

    conn_type = parsed.scheme.lower()

    # Parse query parameters
    params: dict[str, Any] = {}
    if parsed.query:
        for key, values in parse_qs(parsed.query).items():
            # Take first value for each key
            params[key] = values[0] if len(values) == 1 else values

    # Parse path (database/schema)
    path_parts = parsed.path.lstrip("/").split("/") if parsed.path else []
    database = path_parts[0] if path_parts else None
    schema = path_parts[1] if len(path_parts) > 1 else None

    # Handle different connection types
    if conn_type == "snowflake":
        return _parse_snowflake(parsed, database, schema, params)
    elif conn_type == "bigquery":
        return _parse_bigquery(parsed, database, schema, params)
    elif conn_type == "redshift":
        return _parse_redshift(parsed, database, schema, params)
    else:
        # Generic parsing for postgresql, mysql, etc.
        return ConnectionInfo(
            type=conn_type,
            host=parsed.hostname,
            port=parsed.port,
            database=database,
            schema=schema,
            username=parsed.username,
            password=parsed.password,
            params=params,
        )


def _parse_snowflake(
    parsed: Any,
    database: str | None,
    schema: str | None,
    params: dict[str, Any],
) -> ConnectionInfo:
    """Parse Snowflake connection string.

    Format: snowflake://account.region/database/schema?warehouse=WH&role=ROLE

    Args:
        parsed: Parsed URL object
        database: Database from path
        schema: Schema from path
        params: Query parameters

    Returns:
        ConnectionInfo for Snowflake
    """
    # Host contains the account identifier
    account = parsed.hostname

    # Extract additional params
    warehouse = params.pop("warehouse", None)
    role = params.pop("role", None)

    if warehouse:
        params["warehouse"] = warehouse
    if role:
        params["role"] = role

    return ConnectionInfo(
        type="snowflake",
        host=account,  # Account identifier
        database=database,
        schema=schema or "PUBLIC",
        username=parsed.username,
        password=parsed.password,
        params=params,
    )


def _parse_bigquery(
    parsed: Any,
    database: str | None,
    schema: str | None,
    params: dict[str, Any],
) -> ConnectionInfo:
    """Parse BigQuery connection string.

    Format: bigquery://project-id/dataset-id?location=US

    Args:
        parsed: Parsed URL object
        database: Dataset from path (actually the project for BQ)
        schema: Dataset ID
        params: Query parameters

    Returns:
        ConnectionInfo for BigQuery
    """
    # For BigQuery, hostname is project_id, first path part is dataset
    project_id = parsed.hostname

    # Extract location
    location = params.pop("location", "US")
    params["location"] = location

    return ConnectionInfo(
        type="bigquery",
        host=project_id,  # Project ID
        database=database,  # Dataset ID
        schema=schema,
        params=params,
    )


def _parse_redshift(
    parsed: Any,
    database: str | None,
    schema: str | None,
    params: dict[str, Any],
) -> ConnectionInfo:
    """Parse Redshift connection string.

    Format: redshift://host:5439/database?region=us-east-1&cluster=my-cluster

    Args:
        parsed: Parsed URL object
        database: Database from path
        schema: Schema from path
        params: Query parameters

    Returns:
        ConnectionInfo for Redshift
    """
    # Extract IAM-related params
    region = params.pop("region", None)
    cluster = params.pop("cluster", None)
    iam = params.pop("iam", "false").lower() == "true"

    if region:
        params["region"] = region
    if cluster:
        params["cluster_identifier"] = cluster
    if iam:
        params["iam_auth"] = True

    return ConnectionInfo(
        type="redshift",
        host=parsed.hostname,
        port=parsed.port or 5439,
        database=database,
        schema=schema or "public",
        username=parsed.username,
        password=parsed.password,
        params=params,
    )


__all__ = ["ConnectionInfo", "parse_connection_string"]
