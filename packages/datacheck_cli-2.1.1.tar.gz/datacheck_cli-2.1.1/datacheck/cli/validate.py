"""Validate command for DataCheck CLI."""

from pathlib import Path
from typing import Any

import time

import typer

import pandas as pd

from datacheck.cli import app, console
from datacheck.engine import ValidationEngine
from datacheck.exceptions import ConfigurationError, DataCheckError, DataLoadError, ValidationError
from datacheck.logging import configure_logging, get_logger, set_trace_id, generate_trace_id


def _load_from_warehouse(
    connection_string: str,
    table: str | None = None,
    query: str | None = None,
    where: str | None = None,
    schema: str | None = None,
    warehouse: str | None = None,
    credentials: str | None = None,
    region: str | None = None,
    cluster: str | None = None,
    iam_auth: bool = False,
) -> pd.DataFrame:
    """Load data from a cloud data warehouse.

    Args:
        connection_string: Warehouse connection URI
        table: Table name
        query: Custom SQL query
        where: WHERE clause
        schema: Schema/dataset name
        warehouse: Snowflake warehouse name
        credentials: Path to credentials file
        region: Cloud region
        cluster: Cluster identifier
        iam_auth: Use IAM authentication

    Returns:
        DataFrame with loaded data

    Raises:
        DataLoadError: If loading fails
    """
    from datacheck.utils.connection_parser import parse_connection_string

    conn_info = parse_connection_string(connection_string)

    # Type hint for connector - imported types in each branch
    connector: Any  # Union of connector types

    if conn_info.type == "snowflake":
        from datacheck.connectors.snowflake import SnowflakeConnector

        connector = SnowflakeConnector(
            account=conn_info.host or "",
            user=conn_info.username or "",
            password=conn_info.password,
            database=conn_info.database,
            schema=schema or conn_info.schema,
            warehouse=warehouse or conn_info.params.get("warehouse"),
            role=conn_info.params.get("role"),
        )

    elif conn_info.type == "bigquery":
        from datacheck.connectors.bigquery import BigQueryConnector

        connector = BigQueryConnector(
            project_id=conn_info.host or "",
            dataset_id=schema or conn_info.database,
            credentials_path=credentials,
            location=conn_info.params.get("location", "US"),
        )

    elif conn_info.type == "redshift":
        from datacheck.connectors.redshift import RedshiftConnector

        connector = RedshiftConnector(
            host=conn_info.host or "",
            port=conn_info.port or 5439,
            database=conn_info.database or "",
            user=conn_info.username or "",
            password=conn_info.password,
            schema=schema or conn_info.schema,
            cluster_identifier=cluster or conn_info.params.get("cluster_identifier"),
            region=region or conn_info.params.get("region"),
            iam_auth=iam_auth or conn_info.params.get("iam_auth", False),
        )

    else:
        raise DataLoadError(f"Unsupported warehouse type: {conn_info.type}")

    # Load data
    with connector:
        if query:
            result: pd.DataFrame = connector.execute_query(query)
            return result
        elif table:
            result = connector.load_table(
                table_name=table,
                where=where,
                schema=schema,
            )
            return result
        else:
            raise DataLoadError(
                "Either --table or --query must be specified for warehouse sources"
            )


def _generate_markdown_report(
    summary: Any,
    source_info: str | None = None,
    elapsed: float | None = None,
) -> str:
    """Generate a markdown report from validation summary."""
    lines: list[str] = []
    lines.append("# DataCheck Validation Report\n")

    # Header metadata
    if source_info:
        lines.append(f"**Source:** {source_info}  ")
    if summary.all_passed and not summary.has_failures:
        lines.append("**Status:** ✅ All checks passed  ")
    elif summary.all_passed:
        lines.append("**Status:** ⚠️ Passed with warnings  ")
    else:
        lines.append("**Status:** ❌ Validation failed  ")

    counts_parts = [f"{summary.passed_rules} passed"]
    if summary.failed_errors > 0:
        counts_parts.append(f"{summary.failed_errors} failed")
    if summary.failed_warnings > 0:
        counts_parts.append(f"{summary.failed_warnings} warnings")
    if summary.failed_info > 0:
        counts_parts.append(f"{summary.failed_info} info")
    if summary.error_rules > 0:
        counts_parts.append(f"{summary.error_rules} execution errors")

    run_line = f"**Ran:** {summary.total_rules} checks"
    if summary.total_rows > 0:
        run_line += f" on {summary.total_rows:,} rows"
    run_line += f" — {', '.join(counts_parts)}"
    if elapsed is not None:
        run_line += f". Took {elapsed:.2f}s"
    lines.append(run_line + "  ")
    lines.append("")

    # All rules table
    lines.append("## Results\n")
    lines.append("| Result | Check | Column | Details | Severity |")
    lines.append("|--------|-------|--------|---------|----------|")

    for result in summary.results:
        check_label = result.check_name or result.rule_name
        rule_type = result.rule_type or ""
        check_display = f"{check_label} · {rule_type}" if rule_type else check_label

        if result.has_error:
            result_icon = "❌ error"
            detail = str(result.error)[:80].replace("|", "\\|")
        elif result.passed:
            result_icon = "✅ passed"
            detail = ""
        elif result.severity == "warning":
            result_icon = "⚠️ warning"
            failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0.0
            detail = f"{result.failed_rows:,}/{result.total_rows:,} ({failure_rate:.1f}%)"
        elif result.severity == "info":
            result_icon = "ℹ️ info"
            failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0.0
            detail = f"{result.failed_rows:,}/{result.total_rows:,} ({failure_rate:.1f}%)"
        else:
            result_icon = "❌ failed"
            failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0.0
            detail = f"{result.failed_rows:,}/{result.total_rows:,} ({failure_rate:.1f}%)"

        lines.append(
            f"| {result_icon} | {check_display} | `{result.column}` | {detail} | {result.severity} |"
        )
    lines.append("")

    # Failure details
    failed_results = summary.get_failed_results()
    if failed_results:
        lines.append("## Failure Details\n")
        for result in failed_results:
            check_label = result.check_name or result.rule_name
            rule_type = result.rule_type or "unknown"
            failure_rate = (result.failed_rows / result.total_rows * 100) if result.total_rows > 0 else 0.0
            lines.append(f"### {check_label} · {rule_type} (`{result.column}`)")
            lines.append(f"- **Severity:** {result.severity}")
            lines.append(f"- **Rows failed:** {result.failed_rows:,} / {result.total_rows:,} ({failure_rate:.1f}%)")

            if result.failure_details and result.failure_details.sample_failures:
                details = result.failure_details
                samples = []
                for i in range(min(5, len(details.sample_failures))):
                    value = details.sample_values[i] if i < len(details.sample_values) else "N/A"
                    reason = details.sample_reasons[i] if i < len(details.sample_reasons) else ""
                    val_str = str(value).replace("|", "\\|")[:40]
                    reason_str = reason.replace("|", "\\|")[:60] if reason else ""
                    samples.append((details.sample_failures[i], val_str, reason_str))

                lines.append("\n**Sample failures:**\n")
                lines.append("| Row | Value | Reason |")
                lines.append("|-----|-------|--------|")
                for row_idx, val_str, reason_str in samples:
                    lines.append(f"| {row_idx} | {val_str} | {reason_str} |")
            lines.append("")

    # Execution errors
    error_results = summary.get_error_results()
    if error_results:
        lines.append("## Execution Errors\n")
        for result in error_results:
            check_label = result.check_name or result.rule_name
            rule_type = result.rule_type or ""
            lines.append(f"### {check_label} · {rule_type} (`{result.column}`)")
            lines.append(f"\n```\n{result.error}\n```\n")

    return "\n".join(lines)


@app.command()
def validate(
    data_source: str | None = typer.Argument(
        None,
        help="Data source: file path, connection string, or omit when using --source",
    ),
    config: str | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to validation config file (auto-discovered if not provided)",
    ),
    source: str | None = typer.Option(
        None,
        "--source",
        help="Named source from sources.yaml (uses source-based validation)",
    ),
    sources_file: str | None = typer.Option(
        None,
        "--sources-file",
        help="Path to sources YAML file (overrides config sources_file)",
    ),
    table: str | None = typer.Option(
        None,
        "--table",
        "-t",
        help="Database table name (for database sources)",
    ),
    where: str | None = typer.Option(
        None,
        "--where",
        "-w",
        help="WHERE clause for filtering (for database sources)",
    ),
    query: str | None = typer.Option(
        None,
        "--query",
        "-q",
        help="Custom SQL query (alternative to --table)",
    ),
    schema: str | None = typer.Option(
        None,
        "--schema",
        "-s",
        help="Schema/dataset name (for database/warehouse sources)",
    ),
    warehouse: str | None = typer.Option(
        None,
        "--warehouse",
        help="Snowflake warehouse name",
    ),
    credentials: str | None = typer.Option(
        None,
        "--credentials",
        help="Path to credentials file (e.g., BigQuery service account JSON)",
    ),
    region: str | None = typer.Option(
        None,
        "--region",
        help="Cloud region (for Redshift IAM auth)",
    ),
    cluster: str | None = typer.Option(
        None,
        "--cluster",
        help="Cluster identifier (for Redshift IAM auth)",
    ),
    iam_auth: bool = typer.Option(
        False,
        "--iam-auth",
        help="Use IAM authentication (for Redshift)",
    ),
    parallel: bool = typer.Option(
        False,
        "--parallel",
        help="Enable parallel execution for faster validation",
    ),
    workers: int | None = typer.Option(
        None,
        "--workers",
        help="Number of worker processes (default: CPU count)",
    ),
    chunk_size: int | None = typer.Option(
        None,
        "--chunk-size",
        help="Rows per chunk for parallel processing (default: 100000)",
    ),
    show_progress: bool = typer.Option(
        True,
        "--progress/--no-progress",
        help="Show progress indicators during validation (default: enabled)",
    ),
    slack_webhook: str | None = typer.Option(
        None,
        "--slack-webhook",
        help="Slack webhook URL for sending validation results notifications",
    ),
    output: str | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Save results to a file (terminal output is always shown). Format is controlled by --format.",
    ),
    output_format: str = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format when using --output: json (default), sarif, markdown, csv",
    ),
    csv_export: str | None = typer.Option(
        None,
        "--csv-export",
        help="Path to export failure details as CSV",
    ),
    suggestions: bool = typer.Option(
        True,
        "--suggestions/--no-suggestions",
        help="Show actionable suggestions for failures (default: enabled)",
    ),
    log_level: str = typer.Option(
        "WARNING",
        "--log-level",
        help="Log level: DEBUG, INFO, WARNING, ERROR, CRITICAL",
    ),
    log_format: str = typer.Option(
        "console",
        "--log-format",
        help="Log format: 'console' (human-readable) or 'json' (machine-parseable)",
    ),
    log_file: str | None = typer.Option(
        None,
        "--log-file",
        help="Path to log file (enables file logging with rotation)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable verbose logging (sets log level to DEBUG)",
    ),
) -> None:
    """Enforce validation rules against a configured data source.

    Supports both file-based and database sources.

    Exit codes:
      0 - All validation rules passed
      1 - Some validation rules failed
      2 - Configuration error
      3 - Data loading error
      4 - Unexpected error
    """
    # Configure logging
    effective_log_level = "DEBUG" if verbose else log_level
    configure_logging(
        level=effective_log_level,
        format_type=log_format,
        log_file=log_file,
        mask_sensitive=True,
    )

    # Generate trace ID for this validation run
    trace_id = generate_trace_id()
    set_trace_id(trace_id)

    logger = get_logger(__name__)
    logger.info(
        "validation_started",
        extra={
            "trace_id": trace_id,
            "data_source": data_source,
            "config": config,
        }
    )

    try:
        # Initialize validation engine first (to access config)
        try:
            if config:
                config_path = Path(config)
                engine = ValidationEngine(
                    config_path=config_path,
                    parallel=parallel,
                    workers=workers,
                    chunk_size=chunk_size,
                    show_progress=show_progress,
                    sources_file=sources_file,
                )
            else:
                engine = ValidationEngine(
                    parallel=parallel,
                    workers=workers,
                    chunk_size=chunk_size,
                    show_progress=show_progress,
                    sources_file=sources_file,
                )
        except ConfigurationError as e:
            console.print(f"[red]Configuration Error:[/red] {e}", style="red")
            raise typer.Exit(code=2) from e

        # Initialize Slack notifier: CLI flag overrides config
        notifier = None
        effective_webhook = slack_webhook
        mention_on_failure = False
        if not effective_webhook and engine.config.notifications:
            effective_webhook = engine.config.notifications.slack_webhook
            mention_on_failure = engine.config.notifications.mention_on_failure

        if effective_webhook:
            from datacheck.notifications import SlackNotifier
            try:
                notifier = SlackNotifier(effective_webhook, mention_on_failure=mention_on_failure)
            except Exception as e:
                console.print(f"[red]Slack Configuration Error:[/red] {e}", style="red")
                raise typer.Exit(code=2) from e

        # Attach notifier to engine
        engine.notifier = notifier

        # Progress spinner — gives user feedback during load + validation
        num_checks = len(engine.config.checks)
        _status = (
            console.status(
                f"[bold blue]Validating {num_checks} checks...",
                spinner="dots",
            )
            if show_progress
            else None
        )
        if _status:
            _status.start()

        # Load and validate data
        _start_time = time.monotonic()
        _source_info: str | None = None
        try:
            # Source-based validation mode
            if source or engine.sources:
                effective_source = source or engine.config.source or ""
                effective_table = table or engine.config.table
                _source_info = effective_source
                if effective_table:
                    _source_info += f" -> {effective_table}"
                elif query:
                    _source_info += " (custom query)"
                logger.debug(
                    "loading_from_source",
                    extra={"source": effective_source},
                )
                summary = engine.validate_sources(
                    source_name=source,
                    table=table,
                    where=where,
                    query=query,
                )
                logger.info(
                    "data_loaded",
                    extra={"source_type": "named_source", "source": source},
                )

            elif data_source is None and engine.config.data_source is not None:
                # Use inline data_source from config
                inline_source = engine.config.data_source
                # Resolve path relative to config file directory
                if config:
                    config_dir = Path(config).parent
                    source_path = config_dir / inline_source.path
                else:
                    source_path = Path(inline_source.path)

                _source_info = f"{source_path.name} ({inline_source.type})"
                logger.debug(
                    "loading_inline_data_source",
                    extra={"type": inline_source.type, "path": str(source_path)},
                )
                summary = engine.validate_file(str(source_path), **inline_source.options)
                logger.info(
                    "data_loaded",
                    extra={"source_type": "inline", "path": str(source_path)},
                )

            elif data_source is None:
                console.print(
                    "[red]Error:[/red] No data source specified. "
                    "Provide a file path/connection string as argument, "
                    "define 'data_source' in config, or use --source with --sources-file.",
                    style="red",
                )
                raise typer.Exit(code=2)

            # Warehouse connection string mode
            elif data_source.startswith(("snowflake://", "bigquery://", "redshift://")):
                _source_info = data_source.split("://")[0]
                if table:
                    _source_info += f" -> {table}"
                elif query:
                    _source_info += " (custom query)"
                logger.debug("loading_data", extra={"data_source": data_source})
                df = _load_from_warehouse(
                    data_source,
                    table=table,
                    query=query,
                    where=where,
                    schema=schema,
                    warehouse=warehouse,
                    credentials=credentials,
                    region=region,
                    cluster=cluster,
                    iam_auth=iam_auth,
                )
                logger.info("data_loaded", extra={"source_type": "warehouse", "row_count": len(df)})
                summary = engine.validate_dataframe(df)

            # File/connection string mode
            else:
                _source_info = Path(data_source).name if not data_source.startswith(("http://", "https://")) else data_source
                if table:
                    _source_info += f" -> {table}"
                logger.debug("loading_data", extra={"data_source": data_source})
                summary = engine.validate_file(
                    data_source,
                    table=table,
                    where=where,
                    query=query,
                )
                logger.info("data_loaded", extra={"source_type": "file", "data_source": data_source})
        except DataLoadError as e:
            logger.error("data_load_failed", extra={"error": str(e)})
            console.print(f"[red]Data Load Error:[/red] {e}", style="red")
            raise typer.Exit(code=3) from e
        finally:
            if _status:
                _status.stop()

        _elapsed = time.monotonic() - _start_time

        # Log validation results
        logger.info(
            "validation_completed",
            extra={
                "trace_id": trace_id,
                "total_rules": summary.total_rules,
                "passed_rules": summary.passed_rules,
                "failed_rules": summary.failed_rules,
                "all_passed": summary.all_passed,
                "has_errors": summary.has_errors,
            }
        )

        # Determine effective output file path from config if not specified via CLI
        effective_output = output
        if not output and engine.config.reporting and engine.config.reporting.output_path:
            effective_output = f"{engine.config.reporting.output_path}/results.json"

        # Terminal output — always shown
        from datacheck.reporting import TerminalReporter

        terminal_reporter = TerminalReporter(
            console=console,
            show_suggestions=suggestions,
        )
        terminal_reporter.report(summary, elapsed=_elapsed, source_info=_source_info)

        # File output — format controlled by --format flag
        if effective_output:
            from pathlib import Path as OutputPath
            OutputPath(effective_output).parent.mkdir(parents=True, exist_ok=True)

            fmt = output_format.lower().strip()
            if fmt == "sarif":
                from datacheck.reporting import SarifExporter
                SarifExporter.export(
                    summary,
                    output_path=effective_output,
                    elapsed=_elapsed,
                    source_info=_source_info,
                )
            elif fmt == "markdown":
                OutputPath(effective_output).write_text(
                    _generate_markdown_report(summary, source_info=_source_info, elapsed=_elapsed),
                    encoding="utf-8",
                )
            elif fmt == "csv":
                from datacheck.reporting import CsvExporter
                CsvExporter.export_failures(summary, output_path=effective_output)
            else:
                # Default: json — use JsonReporter for richer output
                from datacheck.reporting.json_reporter import JsonReporter
                JsonReporter().export(
                    summary,
                    output_path=effective_output,
                    source_info=_source_info,
                    elapsed=_elapsed,
                )

            console.print(f"[green]OK:[/green] Results saved to {effective_output} (format: {fmt})")

        # Export CSV if requested via CLI option
        if csv_export:
            from datacheck.reporting import CsvExporter

            CsvExporter.export_failures(
                summary,
                output_path=csv_export,
                include_suggestions=suggestions,
            )
            console.print(f"[green]OK:[/green] Failures exported to {csv_export}")

        # Export CSV if configured in config file (and not already exported via CLI)
        elif not csv_export and engine.config.reporting and engine.config.reporting.export_failures:
            from datacheck.reporting import CsvExporter
            from pathlib import Path as ExportPath

            # Determine export path
            reporting_config = engine.config.reporting
            if reporting_config.failures_file:
                export_path = reporting_config.failures_file
            elif reporting_config.output_path:
                # Use output_path as directory, create failures.csv inside
                export_dir = ExportPath(reporting_config.output_path)
                export_dir.mkdir(parents=True, exist_ok=True)
                export_path = str(export_dir / "failures.csv")
            else:
                export_path = "validation_failures.csv"

            # Only export if there are failures
            if not summary.all_passed:
                CsvExporter.export_failures(
                    summary,
                    output_path=export_path,
                    include_suggestions=suggestions,
                )
                console.print(f"[green]OK:[/green] Failures exported to {export_path}")

        # Determine exit code
        if summary.has_errors:
            # Validation errors occurred (configuration/execution issues)
            logger.warning("validation_finished_with_errors", extra={"exit_code": 4})
            raise typer.Exit(code=4)
        elif not summary.all_passed:
            # Validation rules failed
            logger.info("validation_finished_with_failures", extra={"exit_code": 1})
            raise typer.Exit(code=1)
        else:
            # All rules passed
            logger.info("validation_finished_success", extra={"exit_code": 0})
            raise typer.Exit(code=0)

    except typer.Exit:
        # Re-raise typer Exit exceptions (for proper exit codes)
        raise
    except (ConfigurationError, DataLoadError, ValidationError) as e:
        # These should have been handled above, but catch just in case
        logger.error("validation_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
    except DataCheckError as e:
        # Generic DataCheck error
        logger.error("datacheck_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]DataCheck Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
    except Exception as e:
        # Unexpected error
        logger.exception("unexpected_error", extra={"error_type": type(e).__name__, "error": str(e)})
        console.print(f"[red]Unexpected Error:[/red] {e}", style="red")
        raise typer.Exit(code=4) from e
