"""Compare schemas to detect changes."""

from difflib import SequenceMatcher

from datacheck.schema.models import (
    ChangeType,
    ColumnSchema,
    ColumnType,
    CompatibilityLevel,
    SchemaChange,
    SchemaComparison,
    TableSchema,
)


class SchemaComparator:
    """Compare two schemas and detect changes."""

    # Type change compatibility matrix
    # (old_type, new_type) -> CompatibilityLevel
    COMPATIBLE_TYPE_CHANGES = {
        (ColumnType.INTEGER, ColumnType.FLOAT),
        (ColumnType.INTEGER, ColumnType.STRING),
        (ColumnType.FLOAT, ColumnType.STRING),
        (ColumnType.BOOLEAN, ColumnType.STRING),
        (ColumnType.DATE, ColumnType.DATETIME),
        (ColumnType.DATE, ColumnType.STRING),
        (ColumnType.DATETIME, ColumnType.STRING),
    }

    BREAKING_TYPE_CHANGES = {
        (ColumnType.FLOAT, ColumnType.INTEGER),
        (ColumnType.STRING, ColumnType.INTEGER),
        (ColumnType.STRING, ColumnType.FLOAT),
        (ColumnType.STRING, ColumnType.BOOLEAN),
        (ColumnType.DATETIME, ColumnType.DATE),
        (ColumnType.STRING, ColumnType.DATETIME),
        (ColumnType.STRING, ColumnType.DATE),
    }

    def __init__(self, rename_threshold: float = 0.8):
        """
        Initialize comparator.

        Args:
            rename_threshold: Similarity threshold for rename detection (0.0-1.0)
        """
        self.rename_threshold = rename_threshold

    def compare(
        self,
        baseline: TableSchema,
        current: TableSchema,
    ) -> SchemaComparison:
        """
        Compare two schemas.

        Args:
            baseline: Baseline schema
            current: Current schema to compare

        Returns:
            SchemaComparison with detected changes
        """
        changes: list[SchemaChange] = []

        # Get column mappings
        baseline_cols = {col.name: col for col in baseline.columns}
        current_cols = {col.name: col for col in current.columns}

        baseline_names = set(baseline_cols.keys())
        current_names = set(current_cols.keys())

        # Find added and removed columns
        added = current_names - baseline_names
        removed = baseline_names - current_names

        # Detect renames first (this modifies added/removed sets)
        renames = self._detect_renames(removed, added, baseline_cols, current_cols)

        # Process detected renames
        renamed_old = set()
        renamed_new = set()
        for old_name, new_name in renames:
            change = SchemaChange(
                change_type=ChangeType.COLUMN_RENAMED,
                column_name=new_name,
                old_value=old_name,
                new_value=new_name,
                compatibility=CompatibilityLevel.WARNING,
                message=f"Column appears to be renamed from '{old_name}' to '{new_name}'",
            )
            changes.append(change)
            renamed_old.add(old_name)
            renamed_new.add(new_name)

        # Process remaining added columns (not renames)
        for col_name in added - renamed_new:
            col = current_cols[col_name]
            change = SchemaChange(
                change_type=ChangeType.COLUMN_ADDED,
                column_name=col_name,
                new_value=col.dtype.value,
                compatibility=CompatibilityLevel.COMPATIBLE,
                message=f"New column '{col_name}' added with type {col.dtype.value}",
            )
            changes.append(change)

        # Process remaining removed columns (not renames)
        for col_name in removed - renamed_old:
            col = baseline_cols[col_name]
            change = SchemaChange(
                change_type=ChangeType.COLUMN_REMOVED,
                column_name=col_name,
                old_value=col.dtype.value,
                compatibility=CompatibilityLevel.BREAKING,
                message=f"Column '{col_name}' removed - this is a BREAKING change",
            )
            changes.append(change)

        # Detect changes in existing columns (excluding renamed ones)
        common = (baseline_names & current_names) - renamed_old - renamed_new
        for col_name in common:
            baseline_col = baseline_cols[col_name]
            current_col = current_cols[col_name]

            # Check type change
            if baseline_col.dtype != current_col.dtype:
                compatibility = self._assess_type_change_compatibility(
                    baseline_col.dtype, current_col.dtype
                )

                change = SchemaChange(
                    change_type=ChangeType.TYPE_CHANGED,
                    column_name=col_name,
                    old_value=baseline_col.dtype.value,
                    new_value=current_col.dtype.value,
                    compatibility=compatibility,
                    message=f"Type changed from {baseline_col.dtype.value} to {current_col.dtype.value}",
                )
                changes.append(change)

            # Check nullable change
            if baseline_col.nullable != current_col.nullable:
                # Going from nullable to non-nullable is breaking
                compatibility = (
                    CompatibilityLevel.BREAKING
                    if baseline_col.nullable and not current_col.nullable
                    else CompatibilityLevel.COMPATIBLE
                )

                change = SchemaChange(
                    change_type=ChangeType.NULLABLE_CHANGED,
                    column_name=col_name,
                    old_value=baseline_col.nullable,
                    new_value=current_col.nullable,
                    compatibility=compatibility,
                    message=f"Nullable changed from {baseline_col.nullable} to {current_col.nullable}",
                )
                changes.append(change)

        # Determine overall compatibility
        has_breaking = any(c.compatibility == CompatibilityLevel.BREAKING for c in changes)
        has_warnings = any(c.compatibility == CompatibilityLevel.WARNING for c in changes)

        if has_breaking:
            overall_compatibility = CompatibilityLevel.BREAKING
            is_compatible = False
        elif has_warnings:
            overall_compatibility = CompatibilityLevel.WARNING
            is_compatible = True
        else:
            overall_compatibility = CompatibilityLevel.COMPATIBLE
            is_compatible = True

        return SchemaComparison(
            baseline_schema=baseline,
            current_schema=current,
            changes=changes,
            is_compatible=is_compatible,
            compatibility_level=overall_compatibility,
        )

    def _detect_renames(
        self,
        removed: set[str],
        added: set[str],
        baseline_cols: dict[str, ColumnSchema],
        current_cols: dict[str, ColumnSchema],
    ) -> list[tuple[str, str]]:
        """
        Detect potential column renames.

        Uses similarity comparison between removed and added columns.

        Args:
            removed: Set of removed column names
            added: Set of added column names
            baseline_cols: Baseline columns dict
            current_cols: Current columns dict

        Returns:
            List of (old_name, new_name) tuples
        """
        if not removed or not added:
            return []

        renames: list[tuple[str, str]] = []
        used_added: set[str] = set()

        for removed_name in removed:
            removed_col = baseline_cols[removed_name]
            best_match: str | None = None
            best_score = 0.0

            for added_name in added:
                if added_name in used_added:
                    continue

                added_col = current_cols[added_name]

                # Only consider if types match (or are compatible)
                if not self._types_compatible_for_rename(removed_col.dtype, added_col.dtype):
                    continue

                # Calculate similarity score
                score = self._calculate_similarity(removed_name, added_name)

                if score > best_score:
                    best_score = score
                    best_match = added_name

            # If similarity above threshold, consider it a rename
            if best_score >= self.rename_threshold and best_match:
                renames.append((removed_name, best_match))
                used_added.add(best_match)

        return renames

    def _types_compatible_for_rename(
        self, old_type: ColumnType, new_type: ColumnType
    ) -> bool:
        """
        Check if types are compatible for rename detection.

        Args:
            old_type: Old column type
            new_type: New column type

        Returns:
            True if types are compatible
        """
        # Exact match
        if old_type == new_type:
            return True

        # Allow some compatible type changes
        compatible_pairs = {
            (ColumnType.INTEGER, ColumnType.FLOAT),
            (ColumnType.FLOAT, ColumnType.INTEGER),
            (ColumnType.DATE, ColumnType.DATETIME),
            (ColumnType.DATETIME, ColumnType.DATE),
        }

        return (old_type, new_type) in compatible_pairs

    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """
        Calculate similarity between two strings.

        Uses multiple heuristics:
        1. Sequence matcher ratio
        2. Case-insensitive comparison
        3. Underscore/camelCase normalization

        Args:
            str1: First string
            str2: Second string

        Returns:
            Similarity score 0.0-1.0
        """
        # Direct match
        if str1 == str2:
            return 1.0

        # Case-insensitive match
        if str1.lower() == str2.lower():
            return 0.95

        # Normalize strings (convert camelCase to snake_case)
        norm1 = self._normalize_column_name(str1)
        norm2 = self._normalize_column_name(str2)

        if norm1 == norm2:
            return 0.9

        # Use sequence matcher on normalized names
        return SequenceMatcher(None, norm1, norm2).ratio()

    def _normalize_column_name(self, name: str) -> str:
        """
        Normalize column name for comparison.

        Converts camelCase to snake_case and lowercases.

        Args:
            name: Column name

        Returns:
            Normalized name
        """
        result = []
        for i, char in enumerate(name):
            if char.isupper() and i > 0:
                result.append("_")
            result.append(char.lower())

        return "".join(result).replace("-", "_").replace(" ", "_")

    def _assess_type_change_compatibility(
        self,
        old_type: ColumnType,
        new_type: ColumnType,
    ) -> CompatibilityLevel:
        """
        Assess compatibility of type change.

        Args:
            old_type: Previous data type
            new_type: New data type

        Returns:
            CompatibilityLevel
        """
        type_pair = (old_type, new_type)

        if type_pair in self.COMPATIBLE_TYPE_CHANGES:
            return CompatibilityLevel.COMPATIBLE
        elif type_pair in self.BREAKING_TYPE_CHANGES:
            return CompatibilityLevel.BREAKING
        else:
            return CompatibilityLevel.WARNING
