"""Data models for schema management."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class ColumnType(Enum):
    """Column data types."""

    INTEGER = "integer"
    FLOAT = "float"
    STRING = "string"
    BOOLEAN = "boolean"
    DATETIME = "datetime"
    DATE = "date"
    OBJECT = "object"
    UNKNOWN = "unknown"


class ChangeType(Enum):
    """Types of schema changes."""

    COLUMN_ADDED = "column_added"
    COLUMN_REMOVED = "column_removed"
    COLUMN_RENAMED = "column_renamed"
    TYPE_CHANGED = "type_changed"
    NULLABLE_CHANGED = "nullable_changed"
    ORDER_CHANGED = "order_changed"


class CompatibilityLevel(Enum):
    """Schema compatibility levels."""

    COMPATIBLE = "compatible"  # Backward compatible
    WARNING = "warning"  # Potentially breaking
    BREAKING = "breaking"  # Definitely breaking


@dataclass
class ColumnSchema:
    """Schema information for a single column."""

    name: str
    dtype: ColumnType
    nullable: bool = True
    position: int = 0
    unique_values: int | None = None
    null_percentage: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "dtype": self.dtype.value,
            "nullable": self.nullable,
            "position": self.position,
            "unique_values": self.unique_values,
            "null_percentage": self.null_percentage,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ColumnSchema":
        """Create from dictionary."""
        return cls(
            name=data["name"],
            dtype=ColumnType(data["dtype"]),
            nullable=data.get("nullable", True),
            position=data.get("position", 0),
            unique_values=data.get("unique_values"),
            null_percentage=data.get("null_percentage", 0.0),
        )


@dataclass
class TableSchema:
    """Schema information for entire table/dataset."""

    name: str
    columns: list[ColumnSchema]
    row_count: int = 0
    created_at: datetime = field(default_factory=datetime.now)
    source: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "name": self.name,
            "columns": [col.to_dict() for col in self.columns],
            "row_count": self.row_count,
            "created_at": self.created_at.isoformat(),
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "TableSchema":
        """Create from dictionary."""
        return cls(
            name=data["name"],
            columns=[ColumnSchema.from_dict(col) for col in data["columns"]],
            row_count=data.get("row_count", 0),
            created_at=datetime.fromisoformat(data["created_at"]),
            source=data.get("source"),
        )

    def get_column(self, name: str) -> ColumnSchema | None:
        """Get column by name."""
        for col in self.columns:
            if col.name == name:
                return col
        return None

    @property
    def column_names(self) -> list[str]:
        """Get list of column names."""
        return [col.name for col in self.columns]


@dataclass
class SchemaChange:
    """Represents a single schema change."""

    change_type: ChangeType
    column_name: str
    old_value: Any | None = None
    new_value: Any | None = None
    compatibility: CompatibilityLevel = CompatibilityLevel.COMPATIBLE
    message: str = ""

    def __str__(self) -> str:
        """Human-readable string representation."""
        if self.change_type == ChangeType.COLUMN_ADDED:
            return f"Added column '{self.column_name}' ({self.new_value})"
        elif self.change_type == ChangeType.COLUMN_REMOVED:
            return f"Removed column '{self.column_name}' ({self.old_value})"
        elif self.change_type == ChangeType.COLUMN_RENAMED:
            return f"Renamed column '{self.old_value}' -> '{self.new_value}'"
        elif self.change_type == ChangeType.TYPE_CHANGED:
            return f"Type changed for '{self.column_name}': {self.old_value} -> {self.new_value}"
        elif self.change_type == ChangeType.NULLABLE_CHANGED:
            return f"Nullable changed for '{self.column_name}': {self.old_value} -> {self.new_value}"
        else:
            return f"{self.change_type.value}: {self.column_name}"

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "change_type": self.change_type.value,
            "column_name": self.column_name,
            "old_value": self.old_value,
            "new_value": self.new_value,
            "compatibility": self.compatibility.value,
            "message": self.message,
        }


@dataclass
class SchemaComparison:
    """Result of comparing two schemas."""

    baseline_schema: TableSchema
    current_schema: TableSchema
    changes: list[SchemaChange] = field(default_factory=list)
    is_compatible: bool = True
    compatibility_level: CompatibilityLevel = CompatibilityLevel.COMPATIBLE

    @property
    def has_changes(self) -> bool:
        """Check if any changes detected."""
        return len(self.changes) > 0

    @property
    def breaking_changes(self) -> list[SchemaChange]:
        """Get list of breaking changes."""
        return [c for c in self.changes if c.compatibility == CompatibilityLevel.BREAKING]

    @property
    def warning_changes(self) -> list[SchemaChange]:
        """Get list of warning-level changes."""
        return [c for c in self.changes if c.compatibility == CompatibilityLevel.WARNING]

    @property
    def safe_changes(self) -> list[SchemaChange]:
        """Get list of safe changes."""
        return [c for c in self.changes if c.compatibility == CompatibilityLevel.COMPATIBLE]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary."""
        return {
            "baseline_schema": self.baseline_schema.to_dict(),
            "current_schema": self.current_schema.to_dict(),
            "changes": [c.to_dict() for c in self.changes],
            "is_compatible": self.is_compatible,
            "compatibility_level": self.compatibility_level.value,
            "summary": {
                "total_changes": len(self.changes),
                "breaking_changes": len(self.breaking_changes),
                "warning_changes": len(self.warning_changes),
                "safe_changes": len(self.safe_changes),
            },
        }
