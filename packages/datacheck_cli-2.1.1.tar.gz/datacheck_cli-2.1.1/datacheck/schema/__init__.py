"""Schema evolution detection for DataCheck.

This module provides tools for detecting and tracking schema changes
over time, helping data teams catch breaking changes before they
cause pipeline failures.

Example:
    >>> import pandas as pd
    >>> from datacheck.schema import SchemaDetector, SchemaComparator, BaselineManager
    >>>
    >>> # Detect schema from DataFrame
    >>> df = pd.DataFrame({"id": [1, 2], "name": ["Alice", "Bob"]})
    >>> detector = SchemaDetector()
    >>> schema = detector.detect(df, name="users")
    >>>
    >>> # Save as baseline
    >>> manager = BaselineManager()
    >>> manager.save_baseline(schema)
    >>>
    >>> # Later, compare new data against baseline
    >>> baseline = manager.load_baseline()
    >>> new_df = pd.DataFrame({"id": [1, 2], "email": ["a@test.com", "b@test.com"]})
    >>> new_schema = detector.detect(new_df, name="users")
    >>>
    >>> comparator = SchemaComparator()
    >>> comparison = comparator.compare(baseline, new_schema)
    >>> print(f"Has breaking changes: {not comparison.is_compatible}")
"""

from datacheck.schema.baseline import BaselineManager
from datacheck.schema.comparator import SchemaComparator
from datacheck.schema.detector import SchemaDetector
from datacheck.schema.models import (
    ChangeType,
    ColumnSchema,
    ColumnType,
    CompatibilityLevel,
    SchemaChange,
    SchemaComparison,
    TableSchema,
)

__all__ = [
    # Core classes
    "SchemaDetector",
    "SchemaComparator",
    "BaselineManager",
    # Models
    "TableSchema",
    "ColumnSchema",
    "SchemaChange",
    "SchemaComparison",
    # Enums
    "ColumnType",
    "ChangeType",
    "CompatibilityLevel",
]
