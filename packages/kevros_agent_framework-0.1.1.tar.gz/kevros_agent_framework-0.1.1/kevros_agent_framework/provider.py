"""
Governance provider protocol -- the interface between middleware and backend.

Two implementations:
  RemoteProvider  -- calls the gateway over HTTP (default)
  EmbeddedProvider -- calls GatewayServices locally (air-gapped/latency-critical)
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from .models import (
    AttestRequest, AttestResponse,
    BindIntentRequest, BindIntentResponse,
    VerifyRequest, VerifyResponse,
    VerifyOutcomeRequest, VerifyOutcomeResponse,
)


@runtime_checkable
class GovernanceProvider(Protocol):
    """Protocol that both remote and embedded providers implement."""

    async def verify(self, request: VerifyRequest) -> VerifyResponse: ...
    async def attest(self, request: AttestRequest) -> AttestResponse: ...
    async def bind_intent(self, request: BindIntentRequest) -> BindIntentResponse: ...
    async def verify_outcome(self, request: VerifyOutcomeRequest) -> VerifyOutcomeResponse: ...
    async def health(self) -> bool: ...
    async def close(self) -> None: ...
