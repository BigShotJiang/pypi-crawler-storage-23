"""
Pydantic models mirroring the Kevros A2A Governance Gateway schemas.

Source of truth: a2a_gateway/models.py and /openapi.json
DO NOT invent fields. If the gateway schema changes, update here to match.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional
from pydantic import BaseModel, Field


# --- Enums (mirroring gateway) ---

class Decision(str, Enum):
    ALLOW = "ALLOW"
    CLAMP = "CLAMP"
    DENY = "DENY"


class IntentType(str, Enum):
    NAVIGATION = "NAVIGATION"
    MANIPULATION = "MANIPULATION"
    SENSING = "SENSING"
    COMMUNICATION = "COMMUNICATION"
    MAINTENANCE = "MAINTENANCE"
    EMERGENCY = "EMERGENCY"
    OPERATOR_COMMAND = "OPERATOR_COMMAND"
    AI_GENERATED = "AI_GENERATED"
    AUTOMATED = "AUTOMATED"


class IntentSource(str, Enum):
    HUMAN_OPERATOR = "HUMAN_OPERATOR"
    AI_PLANNER = "AI_PLANNER"
    MISSION_SCRIPT = "MISSION_SCRIPT"
    REMOTE_API = "REMOTE_API"
    SENSOR_TRIGGER = "SENSOR_TRIGGER"
    INTERNAL = "INTERNAL"


class OutcomeStatus(str, Enum):
    ACHIEVED = "ACHIEVED"
    PARTIALLY_ACHIEVED = "PARTIALLY_ACHIEVED"
    FAILED = "FAILED"
    BLOCKED = "BLOCKED"
    TIMEOUT = "TIMEOUT"


# --- Verify (POST /governance/verify) ---

class VerifyRequest(BaseModel):
    """Mirrors a2a_gateway.models.VerifyRequest exactly."""
    action_type: str = Field(..., min_length=1, max_length=128)
    action_payload: Dict[str, Any]
    policy_context: Optional[Dict[str, Any]] = None
    agent_id: str
    idempotency_key: Optional[str] = None


class VerifyResponse(BaseModel):
    """Mirrors a2a_gateway.models.VerifyResponse exactly."""
    decision: Decision
    verification_id: str
    release_token: Optional[str] = None
    applied_action: Optional[Dict[str, Any]] = None
    policy_applied: Optional[Dict[str, Any]] = None
    reason: str = ""
    epoch: int
    provenance_hash: str
    hash_prev: Optional[str] = None
    timestamp_utc: str


# --- Attest (POST /governance/attest) ---

class AttestRequest(BaseModel):
    """Mirrors a2a_gateway.models.AttestRequest exactly."""
    agent_id: str
    action_description: str = Field(..., min_length=1, max_length=2048)
    action_payload: Dict[str, Any]
    context: Optional[Dict[str, Any]] = None
    prior_attestation_hash: Optional[str] = None


class AttestResponse(BaseModel):
    """Mirrors a2a_gateway.models.AttestResponse exactly."""
    attestation_id: str
    epoch: int
    hash_prev: str
    hash_curr: str
    pqc_block_ref: Optional[str] = None
    timestamp_utc: str
    chain_length: int


# --- Bind (POST /governance/bind) ---

class BindIntentRequest(BaseModel):
    """Mirrors a2a_gateway.models.BindIntentRequest exactly."""
    agent_id: str
    intent_type: IntentType
    intent_description: str = Field(..., min_length=1, max_length=2048)
    intent_source: IntentSource = IntentSource.AI_PLANNER
    goal_state: Optional[Dict[str, Any]] = None
    command_payload: Dict[str, Any]
    max_duration_ms: Optional[float] = None
    parent_intent_id: Optional[str] = None


class BindIntentResponse(BaseModel):
    """Mirrors a2a_gateway.models.BindIntentResponse exactly."""
    intent_id: str
    intent_hash: str
    binding_id: str
    binding_hmac: str
    command_hash: str
    epoch: int
    timestamp_utc: str


# --- Verify Outcome (POST /governance/verify-outcome) ---

class VerifyOutcomeRequest(BaseModel):
    """Mirrors a2a_gateway.models.VerifyOutcomeRequest exactly."""
    agent_id: str
    intent_id: str
    binding_id: str
    actual_state: Dict[str, Any]
    tolerance: float = 0.1


class VerifyOutcomeResponse(BaseModel):
    """Mirrors a2a_gateway.models.VerifyOutcomeResponse exactly."""
    verification_id: str
    intent_id: str
    status: OutcomeStatus
    achieved_percentage: float
    discrepancy: Optional[Dict[str, Any]] = None
    evidence_hash: str
    timestamp_utc: str


# --- Signup (POST /signup) ---

class SignupRequest(BaseModel):
    """Mirrors a2a_gateway.models.SignupRequest exactly."""
    agent_id: str = Field(..., min_length=1, max_length=256)
    operator_email: str = Field(default="", max_length=320)
    operator_name: str = Field(default="", max_length=256)
    referred_by: Optional[str] = None


class SignupResponse(BaseModel):
    """Mirrors a2a_gateway.models.SignupResponse exactly."""
    api_key: str
    tier: str = "free"
    monthly_limit: int = 100
    rate_limit_per_minute: int = 10
    upgrade_url: str = "/upgrade"
    usage: Dict[str, str] = Field(default_factory=dict)
