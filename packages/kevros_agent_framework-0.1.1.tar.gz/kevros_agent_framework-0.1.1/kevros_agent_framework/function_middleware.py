"""
KevrosFunctionMiddleware -- Function-level intent binding.

Intercepts tool/function calls to:
1. Bind intent before execution (pre-processing via /governance/bind)
2. Record outcome after execution (post-processing via /governance/verify-outcome)

Creates a cryptographic link between what the agent intended and what happened.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Awaitable, Callable
from typing import Any

from .config import KevrosConfig
from .models import (
    BindIntentRequest, IntentType, IntentSource,
    VerifyOutcomeRequest,
)

logger = logging.getLogger("kevros.middleware")

from agent_framework import FunctionMiddleware, FunctionInvocationContext


class KevrosFunctionMiddleware(FunctionMiddleware):
    """
    Kevros function middleware for Microsoft Agent Framework.

    Intercepts function/tool calls to bind intent before execution
    and verify outcomes after execution.
    """

    def __init__(self, config: KevrosConfig | None = None, client=None) -> None:
        self._config = config or KevrosConfig()
        # Import here to avoid circular -- provider is built by middleware.py helper
        from .middleware import _build_provider
        self._provider = _build_provider(self._config, client)

    async def process(
        self,
        context: FunctionInvocationContext,
        call_next: Callable[[], Awaitable[None]],
    ) -> None:
        agent_id = self._config.agent_id or "agent-framework-agent"
        function_name = _extract_function_name(context)
        parameters = _extract_function_parameters(context)

        # Pre-execution: bind intent
        intent_id = None
        binding_id = None
        if self._config.bind_intents:
            try:
                bind_req = BindIntentRequest(
                    agent_id=agent_id,
                    intent_type=IntentType.AI_GENERATED,
                    intent_description=f"Call {function_name}",
                    intent_source=IntentSource.AI_PLANNER,
                    command_payload=parameters,
                )
                bind_resp = await self._provider.bind_intent(bind_req)
                intent_id = bind_resp.intent_id
                binding_id = bind_resp.binding_id

                if self._config.log_decisions:
                    logger.info(
                        "Kevros intent bound: function=%s intent_id=%s",
                        function_name, intent_id,
                    )
            except Exception as exc:
                if self._config.fail_closed:
                    logger.error("Kevros intent binding failed (fail_closed=True): %s", exc)
                    raise
                else:
                    logger.warning("Kevros intent binding failed (fail_closed=False): %s", exc)

        # Execute the function
        start = time.monotonic()
        error_msg = None
        success = True
        try:
            await call_next()
        except Exception as exc:
            error_msg = str(exc)
            success = False
            raise
        finally:
            elapsed_ms = (time.monotonic() - start) * 1000

            # Post-execution: verify outcome
            if self._config.record_outcomes and intent_id and binding_id:
                try:
                    result_value = _extract_function_result(context)
                    outcome_req = VerifyOutcomeRequest(
                        agent_id=agent_id,
                        intent_id=intent_id,
                        binding_id=binding_id,
                        actual_state=result_value if isinstance(result_value, dict) else {"result": result_value, "success": success, "error": error_msg},
                    )
                    await self._provider.verify_outcome(outcome_req)

                    if self._config.log_decisions:
                        logger.info(
                            "Kevros outcome verified: function=%s intent_id=%s success=%s elapsed=%.1fms",
                            function_name, intent_id, success, elapsed_ms,
                        )
                except Exception as exc:
                    logger.warning("Kevros outcome verification failed: %s", exc)


# ---------------------------------------------------------------------------
# Context extraction -- adapted based on Step 0 discovery
# FunctionInvocationContext has: .function, .arguments, .metadata (dict), .result, .kwargs
# ---------------------------------------------------------------------------

def _extract_function_name(context) -> str:
    if hasattr(context, "function") and hasattr(context.function, "name"):
        return context.function.name
    return "unknown-function"


def _extract_function_parameters(context) -> dict[str, Any]:
    if hasattr(context, "arguments") and isinstance(context.arguments, dict):
        return _safe_serialize(context.arguments)
    return {}


def _extract_function_result(context) -> Any:
    if hasattr(context, "result"):
        return _safe_serialize_value(context.result)
    return None


def _safe_serialize(d: dict) -> dict:
    import json
    result = {}
    for k, v in d.items():
        result[k] = _safe_serialize_value(v)
    return result


def _safe_serialize_value(v: Any) -> Any:
    import json
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    try:
        json.dumps(v)
        return v
    except (TypeError, ValueError):
        return str(v)[:500]
