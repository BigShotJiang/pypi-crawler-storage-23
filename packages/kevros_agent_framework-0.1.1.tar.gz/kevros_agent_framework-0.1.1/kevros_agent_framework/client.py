"""
Remote governance provider -- HTTP client for the Kevros A2A Gateway.

Implements GovernanceProvider protocol. Handles auto-signup, retry,
and connection lifecycle. Safe to share across middleware instances.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Optional

import httpx

from .config import KevrosConfig
from .models import (
    AttestRequest, AttestResponse,
    BindIntentRequest, BindIntentResponse,
    SignupRequest, SignupResponse,
    VerifyRequest, VerifyResponse,
    VerifyOutcomeRequest, VerifyOutcomeResponse,
)

logger = logging.getLogger("kevros.middleware")


class KevrosGovernanceClient:
    """
    HTTP client for Kevros A2A Governance Gateway.

    Implements GovernanceProvider protocol.
    Use as async context manager for proper lifecycle:

        async with KevrosGovernanceClient(config) as client:
            result = await client.verify(req)
    """

    def __init__(self, config: KevrosConfig) -> None:
        self._config = config
        self._api_key: Optional[str] = config.api_key or os.environ.get("KEVROS_API_KEY")
        self._signup_lock = asyncio.Lock()
        self._http = httpx.AsyncClient(
            base_url=config.gateway_url,
            timeout=config.timeout_seconds,
            headers={"Content-Type": "application/json"},
        )

    async def __aenter__(self) -> KevrosGovernanceClient:
        return self

    async def __aexit__(self, *args) -> None:
        await self.close()

    async def _ensure_api_key(self) -> str:
        """Get or create API key via auto-signup. Thread-safe."""
        if self._api_key:
            return self._api_key

        async with self._signup_lock:
            # Double-check after acquiring lock
            if self._api_key:
                return self._api_key

            agent_id = self._config.agent_id or "agent-framework-agent"
            signup_req = SignupRequest(
                agent_id=agent_id,
                operator_email=self._config.operator_email or "",
                operator_name=self._config.operator_name or "",
            )
            resp = await self._http.post(
                "/signup",
                json=signup_req.model_dump(exclude_none=True),
            )
            resp.raise_for_status()
            signup_resp = SignupResponse.model_validate(resp.json())
            self._api_key = signup_resp.api_key
            logger.info(
                "Kevros auto-signup complete: agent_id=%s tier=%s limit=%d",
                agent_id, signup_resp.tier, signup_resp.monthly_limit,
            )
            return self._api_key

    async def _request_with_retry(
        self, method: str, path: str, json_body: dict
    ) -> httpx.Response:
        """Make an authenticated request with retry logic."""
        api_key = await self._ensure_api_key()
        headers = {"X-API-Key": api_key}

        last_exc: Optional[Exception] = None
        for attempt in range(1 + self._config.max_retries):
            try:
                resp = await self._http.request(
                    method, path, json=json_body, headers=headers,
                )
                resp.raise_for_status()
                return resp
            except (httpx.ConnectError, httpx.TimeoutException, httpx.HTTPStatusError) as exc:
                last_exc = exc
                # Don't retry on 4xx client errors (except 429)
                if isinstance(exc, httpx.HTTPStatusError) and 400 <= exc.response.status_code < 500 and exc.response.status_code != 429:
                    raise
                if attempt < self._config.max_retries:
                    await asyncio.sleep(self._config.retry_backoff_seconds * (attempt + 1))

        raise last_exc  # type: ignore[misc]

    async def verify(self, request: VerifyRequest) -> VerifyResponse:
        resp = await self._request_with_retry(
            "POST", "/governance/verify",
            request.model_dump(exclude_none=True),
        )
        return VerifyResponse.model_validate(resp.json())

    async def attest(self, request: AttestRequest) -> AttestResponse:
        resp = await self._request_with_retry(
            "POST", "/governance/attest",
            request.model_dump(exclude_none=True),
        )
        return AttestResponse.model_validate(resp.json())

    async def bind_intent(self, request: BindIntentRequest) -> BindIntentResponse:
        resp = await self._request_with_retry(
            "POST", "/governance/bind",
            request.model_dump(exclude_none=True),
        )
        return BindIntentResponse.model_validate(resp.json())

    async def verify_outcome(self, request: VerifyOutcomeRequest) -> VerifyOutcomeResponse:
        resp = await self._request_with_retry(
            "POST", "/governance/verify-outcome",
            request.model_dump(exclude_none=True),
        )
        return VerifyOutcomeResponse.model_validate(resp.json())

    async def health(self) -> bool:
        try:
            resp = await self._http.get("/governance/health")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    async def close(self) -> None:
        await self._http.aclose()
