"""Kevros middleware configuration."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class KevrosConfig:
    """Immutable configuration for Kevros governance middleware."""

    # Gateway connection
    gateway_url: str = "https://governance.taskhawktech.com"
    api_key: Optional[str] = None  # kvrs_... key. If None, auto-signup on first use.

    # Behavior
    fail_closed: bool = True       # Block agent on gateway errors
    log_decisions: bool = True     # Log governance decisions to stderr
    timeout_seconds: float = 5.0   # HTTP timeout per request
    max_retries: int = 1           # Retries before declaring gateway unreachable (0 = no retry)
    retry_backoff_seconds: float = 0.5  # Backoff between retries

    # Intent binding
    bind_intents: bool = True      # Enable function middleware intent binding
    record_outcomes: bool = True   # Record function results as outcomes

    # Agent identity
    agent_id: Optional[str] = None          # Override agent ID (defaults to agent name)
    agent_namespace: Optional[str] = None   # Organizational namespace
    operator_name: Optional[str] = None     # Legal entity name for signup
    operator_email: Optional[str] = None    # Contact email for signup

    # Mode
    embedded: bool = False         # If True, use local GatewayServices instead of HTTP
