"""Test fixtures for Kevros Agent Framework middleware tests."""

import os
import pytest
from kevros_agent_framework import KevrosConfig, KevrosGovernanceClient


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Prevent KEVROS_API_KEY env var from leaking into tests."""
    monkeypatch.delenv("KEVROS_API_KEY", raising=False)


@pytest.fixture
def config():
    return KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key="kvrs_test_key",
        fail_closed=True,
        timeout_seconds=5.0,
    )


@pytest.fixture
def shared_client(config):
    """Shared client for tests that need both middleware types."""
    return KevrosGovernanceClient(config)
