"""Tests for KevrosGovernanceClient -- real gateway schemas."""

import pytest
import respx
import httpx

from kevros_agent_framework import KevrosConfig, KevrosGovernanceClient
from kevros_agent_framework.models import VerifyRequest


@respx.mock
@pytest.mark.asyncio
async def test_auto_signup_with_real_schema():
    """Auto-signup uses actual SignupRequest/SignupResponse schemas."""
    config = KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key=None,
        agent_id="test-agent",
        operator_name="Test Corp",
        retry_backoff_seconds=0.01,
    )

    respx.post("https://test-gateway.example.com/signup").mock(
        return_value=httpx.Response(200, json={
            "api_key": "kvrs_auto_generated_key",
            "tier": "free",
            "monthly_limit": 100,
            "rate_limit_per_minute": 10,
            "upgrade_url": "/stripe/checkout",
            "usage": {"header": "X-API-Key", "example": "curl ..."},
        })
    )
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        return_value=httpx.Response(200, json={
            "decision": "ALLOW",
            "verification_id": "ver-001",
            "release_token": "token123",
            "reason": "OK",
            "epoch": 1,
            "provenance_hash": "abc",
            "timestamp_utc": "2026-02-24T12:00:00+00:00",
        })
    )

    async with KevrosGovernanceClient(config) as client:
        req = VerifyRequest(
            action_type="test",
            action_payload={"key": "value"},
            agent_id="test-agent",
        )
        result = await client.verify(req)
        assert result.decision.value == "ALLOW"

    # Verify signup was called with correct fields
    signup_call = respx.calls[0]
    body = signup_call.request.content
    import json
    signup_body = json.loads(body)
    assert signup_body["agent_id"] == "test-agent"
    assert signup_body["operator_name"] == "Test Corp"


@respx.mock
@pytest.mark.asyncio
async def test_concurrent_auto_signup_only_signs_up_once():
    """Two concurrent calls should only trigger one signup (lock test)."""
    import asyncio

    config = KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key=None,
        agent_id="race-test-agent",
        retry_backoff_seconds=0.01,
    )

    signup_count = 0
    def _signup_side_effect(request):
        nonlocal signup_count
        signup_count += 1
        return httpx.Response(200, json={
            "api_key": "kvrs_raced_key",
            "tier": "free",
            "monthly_limit": 100,
            "rate_limit_per_minute": 10,
            "upgrade_url": "/stripe/checkout",
            "usage": {},
        })

    respx.post("https://test-gateway.example.com/signup").mock(
        side_effect=_signup_side_effect
    )
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        return_value=httpx.Response(200, json={
            "decision": "ALLOW",
            "verification_id": "ver-001",
            "release_token": "token",
            "reason": "OK",
            "epoch": 1,
            "provenance_hash": "abc",
            "timestamp_utc": "2026-02-24T12:00:00+00:00",
        })
    )

    async with KevrosGovernanceClient(config) as client:
        req = VerifyRequest(action_type="test", action_payload={}, agent_id="test")
        await asyncio.gather(
            client.verify(req),
            client.verify(req),
        )

    assert signup_count == 1, f"Expected 1 signup call, got {signup_count}"


@respx.mock
@pytest.mark.asyncio
async def test_health_check():
    config = KevrosConfig(gateway_url="https://test-gateway.example.com", api_key="kvrs_test")
    respx.get("https://test-gateway.example.com/governance/health").mock(
        return_value=httpx.Response(200, json={"service": "kevros-governance-agent", "status": "ok"})
    )
    async with KevrosGovernanceClient(config) as client:
        assert await client.health() is True


@respx.mock
@pytest.mark.asyncio
async def test_health_check_failure():
    config = KevrosConfig(gateway_url="https://test-gateway.example.com", api_key="kvrs_test")
    respx.get("https://test-gateway.example.com/governance/health").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )
    async with KevrosGovernanceClient(config) as client:
        assert await client.health() is False
