"""Tests for EmbeddedGovernanceProvider using real GatewayServices."""

import pytest
from pathlib import Path

from kevros_agent_framework.models import (
    VerifyRequest, AttestRequest, BindIntentRequest,
    IntentType, IntentSource, VerifyOutcomeRequest, Decision,
)

# Skip all tests if gateway package not installed
pytest.importorskip("a2a_gateway")

from a2a_gateway.services import create_default_services
from kevros_agent_framework.embedded import EmbeddedGovernanceProvider


TEST_HMAC_KEY = "0" * 64  # 32-byte zero key for testing


@pytest.fixture
def provider(tmp_path):
    services = create_default_services(data_dir=tmp_path)
    return EmbeddedGovernanceProvider(services, hmac_key_hex=TEST_HMAC_KEY)


@pytest.mark.asyncio
async def test_verify_allow(provider):
    req = VerifyRequest(
        action_type="motor_command",
        action_payload={"speed": 50},
        agent_id="test-agent",
    )
    resp = await provider.verify(req)
    assert resp.decision == Decision.ALLOW
    assert resp.release_token is not None
    assert resp.epoch == 1


@pytest.mark.asyncio
async def test_verify_clamp(provider):
    req = VerifyRequest(
        action_type="motor_command",
        action_payload={"speed": 150},
        policy_context={"max_values": {"speed": 100}},
        agent_id="test-agent",
    )
    resp = await provider.verify(req)
    assert resp.decision == Decision.CLAMP
    assert resp.applied_action["speed"] == 100


@pytest.mark.asyncio
async def test_verify_deny(provider):
    req = VerifyRequest(
        action_type="dangerous_action",
        action_payload={"weapon": True},
        policy_context={"forbidden_keys": ["weapon"]},
        agent_id="test-agent",
    )
    resp = await provider.verify(req)
    assert resp.decision == Decision.DENY
    assert resp.release_token is None


@pytest.mark.asyncio
async def test_attest(provider):
    req = AttestRequest(
        agent_id="test-agent",
        action_description="Navigated to waypoint",
        action_payload={"lat": 38.0, "lon": -78.5},
    )
    resp = await provider.attest(req)
    assert resp.chain_length == 1
    assert resp.hash_prev is not None


@pytest.mark.asyncio
async def test_full_intent_lifecycle(provider):
    """bind_intent -> verify_outcome full cycle."""
    bind_req = BindIntentRequest(
        agent_id="test-agent",
        intent_type=IntentType.NAVIGATION,
        intent_description="Navigate to waypoint Alpha",
        command_payload={"target_lat": 38.0, "target_lon": -78.5},
        goal_state={"lat": 38.0, "lon": -78.5},
    )
    bind_resp = await provider.bind_intent(bind_req)
    assert bind_resp.intent_id
    assert bind_resp.binding_hmac

    outcome_req = VerifyOutcomeRequest(
        agent_id="test-agent",
        intent_id=bind_resp.intent_id,
        binding_id=bind_resp.binding_id,
        actual_state={"lat": 38.0, "lon": -78.5},
    )
    outcome_resp = await provider.verify_outcome(outcome_req)
    assert outcome_resp.status.value == "ACHIEVED"
    assert outcome_resp.achieved_percentage == 100.0
