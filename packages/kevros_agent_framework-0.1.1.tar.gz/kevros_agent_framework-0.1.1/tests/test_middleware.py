"""
Tests for KevrosGovernanceMiddleware.

Uses respx to mock HTTP calls to the gateway.
Tests use REAL gateway response schemas (VerifyResponse fields).

Adapted from Step 0: AgentContext (not AgentRunContext), call_next() takes no args.
"""

import pytest
import respx
import httpx
from unittest.mock import AsyncMock, MagicMock

from kevros_agent_framework import KevrosConfig, KevrosGovernanceClient
from kevros_agent_framework.middleware import KevrosGovernanceMiddleware, GovernanceDeniedException


@pytest.fixture
def config():
    return KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key="kvrs_test_key",
        fail_closed=True,
    )


@pytest.fixture
def client(config):
    return KevrosGovernanceClient(config)


@pytest.fixture
def middleware(config, client):
    return KevrosGovernanceMiddleware(config=config, client=client)


def _mock_context():
    """Create a mock AgentContext with attributes matching Step 0 discovery."""
    ctx = MagicMock()
    ctx.agent = MagicMock()
    ctx.agent.name = "test-agent"
    ctx.agent.instructions = "You are a test assistant."
    msg = MagicMock()
    msg.text = "What is the weather?"
    ctx.messages = [msg]
    ctx.metadata = {}
    return ctx


def _verify_response_json(decision="ALLOW", **overrides):
    """Build a valid VerifyResponse JSON matching the REAL gateway schema."""
    base = {
        "decision": decision,
        "verification_id": "ver-test-001",
        "release_token": "abc123def456" if decision != "DENY" else None,
        "applied_action": {"speed": 50} if decision != "DENY" else None,
        "policy_applied": {},
        "reason": "Test reason",
        "epoch": 42,
        "provenance_hash": "deadbeef01234567",
        "hash_prev": "cafebabe",
        "timestamp_utc": "2026-02-24T12:00:00+00:00",
    }
    base.update(overrides)
    return base


@respx.mock
@pytest.mark.asyncio
async def test_allow_decision_proceeds(middleware):
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        return_value=httpx.Response(200, json=_verify_response_json("ALLOW"))
    )
    ctx = _mock_context()
    next_called = False
    async def mock_next():
        nonlocal next_called
        next_called = True
    await middleware.process(ctx, mock_next)
    assert next_called


@respx.mock
@pytest.mark.asyncio
async def test_deny_decision_blocks(middleware):
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        return_value=httpx.Response(200, json=_verify_response_json("DENY", reason="Forbidden key detected"))
    )
    ctx = _mock_context()
    with pytest.raises(GovernanceDeniedException) as exc_info:
        await middleware.process(ctx, AsyncMock())
    assert "Forbidden key detected" in str(exc_info.value)


@respx.mock
@pytest.mark.asyncio
async def test_clamp_decision_proceeds_with_metadata(middleware):
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        return_value=httpx.Response(200, json=_verify_response_json(
            "CLAMP",
            reason="Clamped speed from 100 to 50",
            applied_action={"speed": 50},
        ))
    )
    ctx = _mock_context()
    next_called = False
    async def mock_next():
        nonlocal next_called
        next_called = True
    await middleware.process(ctx, mock_next)
    assert next_called
    assert ctx.metadata.get("kevros_decision") == "CLAMP"
    assert ctx.metadata.get("kevros_applied_action") == {"speed": 50}


@respx.mock
@pytest.mark.asyncio
async def test_gateway_unreachable_fail_closed_with_retry(middleware):
    """Unreachable gateway with fail_closed=True should retry then raise."""
    route = respx.post("https://test-gateway.example.com/governance/verify").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )
    ctx = _mock_context()
    with pytest.raises(GovernanceDeniedException):
        await middleware.process(ctx, AsyncMock())
    # Should have retried (1 original + 1 retry = 2 calls)
    assert route.call_count == 2


@respx.mock
@pytest.mark.asyncio
async def test_gateway_unreachable_fail_open():
    config = KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key="kvrs_test_key",
        fail_closed=False,
    )
    client = KevrosGovernanceClient(config)
    mw = KevrosGovernanceMiddleware(config=config, client=client)
    respx.post("https://test-gateway.example.com/governance/verify").mock(
        side_effect=httpx.ConnectError("Connection refused")
    )
    ctx = _mock_context()
    next_called = False
    async def mock_next():
        nonlocal next_called
        next_called = True
    await mw.process(ctx, mock_next)
    assert next_called


@respx.mock
@pytest.mark.asyncio
async def test_transient_503_retries_then_succeeds():
    """A 503 on first try should retry and succeed."""
    config = KevrosConfig(
        gateway_url="https://test-gateway.example.com",
        api_key="kvrs_test_key",
        retry_backoff_seconds=0.01,
    )
    client = KevrosGovernanceClient(config)
    mw = KevrosGovernanceMiddleware(config=config, client=client)

    call_count = 0
    def _side_effect(request):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return httpx.Response(503)
        return httpx.Response(200, json=_verify_response_json("ALLOW"))

    respx.post("https://test-gateway.example.com/governance/verify").mock(
        side_effect=_side_effect
    )
    ctx = _mock_context()
    next_called = False
    async def mock_next():
        nonlocal next_called
        next_called = True
    await mw.process(ctx, mock_next)
    assert next_called
    assert call_count == 2
