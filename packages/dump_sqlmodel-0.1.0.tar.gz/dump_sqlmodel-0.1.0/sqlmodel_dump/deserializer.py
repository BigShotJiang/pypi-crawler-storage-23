from asyncio import AbstractEventLoop, run, run_coroutine_threadsafe
from datetime import datetime
from enum import Enum
from inspect import isawaitable
from typing import Any, Callable
from warnings import warn

from pydantic import BaseModel
from sqlalchemy import inspect
from sqlalchemy.orm import Mapper
from sqlmodel import SQLModel

from sqlmodel_dump.error import (
    DeserializerMissing,
    DeserializerObjMissing,
    Invalid,
    InvalidOption,
    LostRef,
    WhereIsMyRef,
)


class Deserializer:
    _max_depth: int
    _get_class: Callable[[str], type[Any] | None]
    _get_ref: Callable[[str], Any | None]
    _self_ref: bool
    _ref: dict[str, Any] = {}
    _key_factory: Callable[[Any], str]
    _ref_alternative: Callable[[str], Any] | None
    _running_loop: AbstractEventLoop | None

    def __init__(
        self,
        get_class: Callable[[str], type[Any] | None],
        get_ref: Callable[[str], Any] | None = None,
        self_ref: bool = False,
        max_depth: int = 3,
        ref_alternative: Callable[[str], Any] | None = None,
        running_loop: AbstractEventLoop | None = None,
    ) -> None:
        """
        Create a Deserializer

        :param Callable get_class: The function to get the reference class.
        :param Callable | None get_ref: The function to get the reference.
        :param bool self_ref: Use self_ref mode. Will return a `self_ref` object.
        :param int max_depth: Controll how deep the deserializer will dig into the object.
        :param Callable | None ref_alternative: The function to call when the ref is missing. Could be a function to call to the DB. Should return the obj, not a dict, for example, a SQLModel object.
        :param AbstractEventLoop | None running_loop: The current running event loop. Will be used to call the `async_deserialize` method.
        """
        self._max_depth = max_depth
        self._get_class = get_class
        self._self_ref = self_ref
        if self_ref:
            self._get_ref = self._ref.get
        elif get_ref is None:
            raise InvalidOption("get_ref must be provided or self_ref must be true")
        else:
            self._get_ref = get_ref
        self._ref_alternative = ref_alternative
        self._running_loop = running_loop

    def deserialize(self, obj: Any, current_depth: int = 1) -> Any:
        """
        Deserialize json object into a object.

        :param Any obj: Object to deserialize
        :param int current_depth: To control the object depth

        :return Any: The loaded object 

        **Note:** This is the sync wrapper for `async_deserialize` method
        """
        if self._running_loop:
            fut = run_coroutine_threadsafe(
                self.async_deserialize(obj, current_depth), self._running_loop
            )
            return fut.result()
        else:
            return run(self.async_deserialize(obj, current_depth))

    async def async_deserialize(self, obj: Any, current_depth: int = 1) -> Any:
        """
        Deserialize json object into a object but with async :D.

        :param Any obj: Object to deserialize
        :param int current_depth: To control the object depth

        :return Any: The loaded object 
        """
        if isinstance(obj, dict):
            return await self._ds_dict(obj, current_depth)
        elif isinstance(obj, list):
            return [await self.async_deserialize(item, current_depth) for item in obj]
        else:
            return obj

    async def _ds_dict(self, obj: dict, current_depth: int) -> Any:
        if "__type" not in obj:
            return obj

        match obj["__type"]:
            case "model":
                return await self._ds_model(obj, current_depth)

            case "datetime":
                if "__val" not in obj:
                    raise DeserializerObjMissing("datetime", "__val")
                if not isinstance(obj["__val"], float):
                    raise Invalid("obj __val", "float", obj["__val"].__class__.__name__)
                return datetime.fromtimestamp(obj["__val"])

            case "enum":
                if "__class" not in obj:
                    raise DeserializerObjMissing("enum", "__class")
                if "__val" not in obj:
                    raise DeserializerObjMissing("enum", "__val")
                class_ = self._get_class(obj["__class"])
                if class_ is None:
                    raise DeserializerMissing("class", obj["__class"])
                if not issubclass(class_, Enum):
                    raise Invalid("obj class", "python Enum", class_.__name__)
                return class_(obj["__val"])

    async def _ds_model(self, obj: dict, current_depth: int) -> BaseModel:
        if "__class" not in obj:
            raise DeserializerObjMissing("model", "__class")
        class_ = self._get_class(obj["__class"])
        if class_ is None:
            raise DeserializerMissing("class", obj["__class"])
        if not issubclass(class_, BaseModel):
            raise Invalid("obj class", "pydantic BaseModel", class_.__name__)

        data = {}
        for key in class_.model_fields:
            data[key] = await self.async_deserialize(obj[key], current_depth + 1)

        if issubclass(class_, SQLModel):
            data |= await self._handle_sqlmodel(class_, obj, current_depth)

        return class_(**data)

    async def _handle_sqlmodel(
        self, class_: type[SQLModel], obj: Any, current_depth: int
    ) -> dict[str, Any]:
        insp: Mapper | None = inspect(class_, raiseerr=False)
        if insp is None:
            raise ValueError(
                "obj class is sqlmodel but can't inspect"
            )  # should not happend

        data = {}
        for key in insp.relationships.keys():
            value = obj[key]
            if value is None:
                raise Invalid(
                    f"key {key}",
                    "relationship obj",
                    value.__class__.__name__,
                )
            if "__class" not in value:
                raise DeserializerObjMissing("relationship", "__class")
            if "__ref" not in value:
                raise DeserializerObjMissing("relationship", "__ref")

            if self._self_ref is True:
                data[key] = await self._handle_self_ref(value, current_depth)
            else:
                data[key] = await self._hanle_obj_ref(value, current_depth + 1)

        return data

    async def _handle_self_ref(self, value: Any, current_depth: int) -> BaseModel:
        if "__use_ref" in value and value["__use_ref"] is True:
            ref = self._get_ref(value["__ref"])
            if ref is None:
                raise WhereIsMyRef(value["__ref"])
            return ref
        else:
            if "__val" not in value:
                raise DeserializerObjMissing("self ref relationship", "__value")
            ref = await self._ds_model(value["__val"], current_depth)
            self._ref[value["__ref"]] = ref
            return ref

    async def _hanle_obj_ref(self, value: Any, current_depth: int) -> BaseModel:
        if "__use_ref" in value or "__val" in value:
            warn(
                "found '__use_ref' or '__val' in relationship model, do you forget to set 'self_ref' to true?"
            )
        ref_key = value["__ref"]
        ref = self._get_ref(ref_key)
        if ref is None:
            if self._ref_alternative:
                ref_obj = self._ref_alternative(ref_key)
                if isawaitable(ref_obj):
                    return await ref_obj
                else:
                    return ref_obj

            else:
                raise LostRef(ref_key)

        else:
            return await self._ds_model(ref, current_depth)
