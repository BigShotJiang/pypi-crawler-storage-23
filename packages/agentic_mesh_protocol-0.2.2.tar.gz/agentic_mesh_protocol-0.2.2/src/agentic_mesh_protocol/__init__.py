"""Agentic Mesh Protocol - Python gRPC interfaces."""

from agentic_mesh_protocol.__version__ import __version__

__all__ = ["__version__"]
