#!/usr/bin/env bash

cd bingocpp
./build.sh
cd ../..
