import customtkinter as ctk

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.geometry("200x200")
        
        # Testing auto hide scrollbar approach
        self.sf = ctk.CTkScrollableFrame(self)
        self.sf.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Add a few items fast
        for i in range(15):
             ctk.CTkLabel(self.sf, text=f"Label {i}").pack()
             
        # Add dynamic hide
        self.sf._parent_canvas.bind("<Configure>", self.check_scroll)
        self.sf.bind("<Configure>", self.check_scroll)

    def check_scroll(self, event=None):
        canvas = self.sf._parent_canvas
        if canvas.bbox("all"):
            _, _, _, canvas_items_h = canvas.bbox("all")
            canvas_h = canvas.winfo_height()
            
            # if content taller than canvas, show scrollbar
            if canvas_items_h > canvas_h:
                 self.sf._scrollbar.grid(row=0, column=1, sticky="ns")
            else:
                 self.sf._scrollbar.grid_forget()

app = App()
app.after(500, app.check_scroll)
app.mainloop()
