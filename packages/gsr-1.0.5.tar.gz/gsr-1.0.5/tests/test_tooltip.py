import customtkinter as ctk

app = ctk.CTk()
app.geometry("300x200")

wrapper = ctk.CTkFrame(app)
wrapper.pack(pady=50)

seg = ctk.CTkSegmentedButton(wrapper, values=["A", "B", "C"])
seg.pack()

tooltip = None

def show_cursor_tooltip(event):
    global tooltip
    if tooltip:
        return
    x = wrapper.winfo_rootx()
    y = wrapper.winfo_rooty() + wrapper.winfo_height() + 4
    tooltip = ctk.CTkToplevel()
    tooltip.wm_overrideredirect(True)
    tooltip.wm_geometry(f"+{x}+{y}")
    label = ctk.CTkLabel(tooltip, text="Tooltip!")
    label.pack()

def hide_cursor_tooltip(event):
    global tooltip
    x, y = wrapper.winfo_pointerxy()
    x1 = wrapper.winfo_rootx()
    y1 = wrapper.winfo_rooty()
    x2 = x1 + wrapper.winfo_width()
    y2 = y1 + wrapper.winfo_height()
    # Add a 1px tolerance just in case
    if not (x1-1 <= x <= x2+1 and y1-1 <= y <= y2+1):
        if tooltip:
            tooltip.destroy()
            tooltip = None

def bind_recursive(widget):
    widget.bind("<Enter>", show_cursor_tooltip, add="+")
    widget.bind("<Leave>", hide_cursor_tooltip, add="+")
    for child in widget.winfo_children():
        bind_recursive(child)

bind_recursive(wrapper)

app.after(5000, app.destroy)
app.mainloop()
