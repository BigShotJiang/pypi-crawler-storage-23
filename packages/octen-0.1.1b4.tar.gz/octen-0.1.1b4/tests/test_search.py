"""测试 Search API"""

import pytest
from pydantic import ValidationError
from octen.models.search import (
    SearchRequest,
    SearchResponse,
    HighlightOptions,
    FullContentOptions,
)


def test_search_request_basic():
    """测试基础搜索请求"""
    request = SearchRequest(query="test query")
    assert request.query == "test query"
    assert request.count == 5  # 默认值
    assert request.search_type == "auto"  # 默认值


def test_search_request_full():
    """测试完整搜索请求"""
    request = SearchRequest(
        query="Python",
        count=10,
        search_type="semantic",
        include_domains=["github.com"],
        exclude_domains=["pinterest.com"],
        highlight=HighlightOptions(enable=True, max_tokens=300),
        full_content=FullContentOptions(enable=True, max_tokens=1000),
    )
    assert request.query == "Python"
    assert request.count == 10
    assert request.search_type == "semantic"
    assert request.include_domains == ["github.com"]


def test_search_request_validation():
    """测试请求验证"""
    # 查询字符串过长
    with pytest.raises(ValidationError):
        SearchRequest(query="x" * 501)

    # 结果数量超出范围
    with pytest.raises(ValidationError):
        SearchRequest(query="test", count=0)

    with pytest.raises(ValidationError):
        SearchRequest(query="test", count=101)

    # 无效的搜索类型
    with pytest.raises(ValidationError):
        SearchRequest(query="test", search_type="invalid")


def test_highlight_options():
    """测试高亮选项"""
    options = HighlightOptions(enable=True, max_tokens=500)
    assert options.enable is True
    assert options.max_tokens == 500

    # 测试默认值
    options_default = HighlightOptions()
    assert options_default.enable is True
    assert options_default.max_tokens == 300


def test_full_content_options():
    """测试完整内容选项"""
    options = FullContentOptions(enable=True, max_tokens=2000)
    assert options.enable is True
    assert options.max_tokens == 2000

    # 测试默认值
    options_default = FullContentOptions()
    assert options_default.enable is False
    assert options_default.max_tokens == 1000


def test_search_response():
    """测试搜索响应"""
    response_data = {
        "code": 0,
        "msg": "success",
        "data": {
            "query": "test",
            "search_type": "auto",
            "results": [
                {
                    "title": "Test Result",
                    "url": "https://example.com",
                    "highlight": "Test highlight",
                }
            ],
        },
        "meta": {
            "usage": {"total_tokens": 100},
            "latency": {"total": 500},
        },
    }

    response = SearchResponse(**response_data)
    assert response.code == 0
    assert response.msg == "success"
    assert len(response.results) == 1
    assert response.results[0]["title"] == "Test Result"
    assert response.query == "test"
    assert response.search_type == "auto"
    assert response.usage["total_tokens"] == 100
    assert response.latency["total"] == 500
