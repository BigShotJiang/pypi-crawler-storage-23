"""测试 Octen 客户端"""

import pytest
from octen import Octen
from octen.core.exceptions import OctenValidationError


def test_client_initialization():
    """测试客户端初始化"""
    client = Octen(api_key="test-key")
    assert client is not None
    assert client.search is not None
    assert client.embedding is not None
    client.close()


def test_client_context_manager():
    """测试上下文管理器"""
    with Octen(api_key="test-key") as client:
        assert client is not None


def test_client_no_api_key():
    """测试缺少 API key 时抛出异常"""
    with pytest.raises(ValueError, match="api_key 不能为空"):
        Octen(api_key="")


def test_client_custom_config():
    """测试自定义配置"""
    client = Octen(
        api_key="test-key",
        base_url="https://custom.api.com",
        timeout=60.0,
        max_retries=5,
        http2=False,
    )
    assert client._http_client.base_url == "https://custom.api.com"
    assert client._http_client.timeout == 60.0
    assert client._http_client.max_retries == 5
    client.close()


def test_client_repr():
    """测试字符串表示"""
    client = Octen(api_key="test-key", base_url="https://api.octen.ai")
    repr_str = repr(client)
    assert "Octen" in repr_str
    assert "https://api.octen.ai" in repr_str
    client.close()
