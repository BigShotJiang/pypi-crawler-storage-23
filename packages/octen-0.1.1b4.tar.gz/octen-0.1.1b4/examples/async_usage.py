"""异步用法示例

演示 Octen SDK 的异步功能（需要安装 octen[async]）
"""

import asyncio
from octen import AsyncOcten


async def main():
    """异步示例主函数"""
    async with AsyncOcten(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK 异步用法示例")
        print("=" * 80)

        # 示例 1: 异步搜索
        print("\n1. 异步搜索")
        print("-" * 80)
        response = await client.search.search("Python async", count=5)

        print(f"找到 {len(response.results)} 个结果")
        for result in response.results[:3]:
            print(f"  - {result['title']}")

        # 示例 2: 异步嵌入
        print("\n2. 异步嵌入")
        print("-" * 80)
        embedding = await client.embedding.create("async programming")
        vector = embedding.get_first_embedding()

        if vector:
            print(f"向量维度: {len(vector)}")

        # 示例 3: 并发执行多个请求
        print("\n3. 并发执行")
        print("-" * 80)

        # 同时执行搜索和嵌入
        search_task = client.search.search("AI", count=5)
        embedding_task = client.embedding.create("Hello")

        search_result, embedding_result = await asyncio.gather(
            search_task,
            embedding_task
        )

        print(f"搜索结果: {len(search_result.results)} 条")
        print(f"嵌入维度: {len(embedding_result.get_first_embedding())}")

        # 示例 4: 批量并发搜索
        print("\n4. 批量并发搜索")
        print("-" * 80)

        queries = ["Python", "JavaScript", "Go", "Rust"]
        tasks = [client.search.search(q, count=3) for q in queries]
        results = await asyncio.gather(*tasks)

        for query, result in zip(queries, results):
            print(f"  {query}: {len(result.results)} 个结果")

        # 示例 5: 批量并发嵌入
        print("\n5. 批量并发嵌入")
        print("-" * 80)

        texts = [f"Document {i}" for i in range(10)]
        tasks = [client.embedding.create(text) for text in texts]
        embeddings = await asyncio.gather(*tasks)

        print(f"生成了 {len(embeddings)} 个嵌入向量")


if __name__ == "__main__":
    # 运行异步主函数
    asyncio.run(main())
