"""基础用法示例

演示 Octen SDK 的基本功能
"""

from octen import Octen


def main():
    # 创建客户端（使用上下文管理器）
    with Octen(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK 基础用法示例")
        print("=" * 80)

        # 示例 1: 简单搜索
        print("\n1. 简单搜索")
        print("-" * 80)
        response = client.search.search("Python programming", count=5)

        print(f"查询: {response.query}")
        print(f"搜索类型: {response.search_type}")
        print(f"结果数量: {len(response.results)}\n")

        for i, result in enumerate(response.results, 1):
            print(f"结果 {i}:")
            print(f"  标题: {result['title']}")
            print(f"  URL: {result['url']}")
            if result.get('highlight'):
                print(f"  摘要: {result['highlight'][:100]}...")
            print()

        # 示例 2: 创建文本嵌入
        print("\n2. 创建文本嵌入")
        print("-" * 80)
        embedding_response = client.embedding.create(
            input="Hello, world!",
            model="octen-embedding-4b"
        )

        vector = embedding_response.get_first_embedding()
        if vector:
            print(f"输入文本: Hello, world!")
            print(f"向量维度: {len(vector)}")
            print(f"向量前 5 个值: {vector[:5]}")
            print(f"使用的模型: {embedding_response.model}")

        # 示例 3: 批量嵌入
        print("\n3. 批量文本嵌入")
        print("-" * 80)
        texts = [
            "Python is a programming language",
            "JavaScript is used for web development",
            "Machine learning is a subset of AI"
        ]

        batch_response = client.embedding.create(input=texts)
        vectors = batch_response.get_embeddings()

        print(f"输入文本数量: {len(texts)}")
        print(f"生成向量数量: {len(vectors)}")
        for i, text in enumerate(texts):
            print(f"  {i + 1}. {text} -> 向量维度 {len(vectors[i])}")

        # 示例 4: 使用便捷方法
        print("\n4. 使用便捷方法")
        print("-" * 80)

        # 简单搜索
        simple_response = client.search.simple_search("AI", count=3)
        print(f"简单搜索结果: {len(simple_response.results)} 条")

        # 查询嵌入
        query_vector = client.embedding.embed_query("search query")
        print(f"查询向量维度: {len(query_vector)}")

        # 文档嵌入
        doc_vectors = client.embedding.embed_documents(["doc 1", "doc 2"])
        print(f"文档向量数量: {len(doc_vectors)}")


if __name__ == "__main__":
    main()
