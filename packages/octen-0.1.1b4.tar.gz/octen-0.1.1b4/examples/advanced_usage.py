"""高级用法示例

演示 Octen SDK 的高级功能，包括过滤、高亮、完整内容等
"""

from octen import Octen, HighlightOptions, FullContentOptions


def main():
    with Octen(api_key="your-api-key") as client:
        print("=" * 80)
        print("Octen SDK 高级用法示例")
        print("=" * 80)

        # 示例 1: 高级搜索 - 域名过滤
        print("\n1. 域名过滤搜索")
        print("-" * 80)
        response = client.search.search(
            query="machine learning tutorials",
            count=10,
            include_domains=["github.com", "arxiv.org", "medium.com"],
            exclude_domains=["pinterest.com"]
        )

        print(f"找到 {len(response.results)} 个结果")
        for result in response.results[:3]:
            print(f"  - {result['title']}")
            print(f"    {result['url']}")

        # 示例 2: 时间范围搜索
        print("\n2. 时间范围搜索")
        print("-" * 80)
        response = client.search.search(
            query="Python 3.12 新特性",
            count=5,
            time_basis="published",
            start_time="2024-01-01T00:00:00Z",
            end_time="2024-12-31T23:59:59Z"
        )

        print(f"找到 {len(response.results)} 个结果")
        for result in response.results:
            pub_time = result.get('time_published', 'Unknown')
            print(f"  - {result['title']}")
            print(f"    发布时间: {pub_time}")

        # 示例 3: 自定义高亮
        print("\n3. 自定义高亮选项")
        print("-" * 80)
        response = client.search.search(
            query="deep learning",
            count=3,
            highlight=HighlightOptions(
                enable=True,
                max_tokens=500  # 更长的摘要
            )
        )

        for i, result in enumerate(response.results, 1):
            print(f"\n结果 {i}:")
            print(f"标题: {result['title']}")
            if result.get('highlight'):
                print(f"摘要 ({len(result['highlight'])} 字符):")
                print(f"{result['highlight'][:200]}...")

        # 示例 4: 获取完整内容
        print("\n4. 获取完整内容")
        print("-" * 80)
        response = client.search.search(
            query="API design best practices",
            count=2,
            full_content=FullContentOptions(
                enable=True,
                max_tokens=2000
            )
        )

        for i, result in enumerate(response.results, 1):
            print(f"\n结果 {i}: {result['title']}")
            if result.get('full_content'):
                content_length = len(result['full_content'])
                print(f"完整内容长度: {content_length} 字符")
                print(f"内容预览: {result['full_content'][:150]}...")

        # 示例 5: 语义搜索
        print("\n5. 语义搜索")
        print("-" * 80)
        response = client.search.search(
            query="如何提高代码质量",
            count=5,
            search_type="semantic",  # 使用语义搜索
            format="markdown"  # 返回 Markdown 格式
        )

        print(f"搜索类型: {response.search_type}")
        print(f"结果数量: {len(response.results)}")
        for result in response.results[:3]:
            print(f"  - {result['title']}")

        # 示例 6: 文本过滤
        print("\n6. 文本内容过滤")
        print("-" * 80)
        response = client.search.search(
            query="Python web framework",
            count=5,
            include_text=["Django", "Flask"],  # 必须包含这些词
            exclude_text=["deprecated", "outdated"]  # 排除这些词
        )

        print(f"找到 {len(response.results)} 个结果")
        for result in response.results:
            print(f"  - {result['title']}")

        # 示例 7: 自定义超时
        print("\n7. 自定义超时设置")
        print("-" * 80)
        try:
            # 这个请求使用 120 秒超时
            response = client.search.search(
                query="complex query",
                count=20,
                timeout=120.0
            )
            print(f"请求成功，找到 {len(response.results)} 个结果")
        except Exception as e:
            print(f"请求失败: {e}")

        # 示例 8: 查看使用量信息
        print("\n8. 查看使用量信息")
        print("-" * 80)
        response = client.search.search("test query", count=3)

        if response.usage:
            print(f"Token 使用量:")
            for key, value in response.usage.items():
                print(f"  {key}: {value}")

        if response.latency:
            print(f"\n延迟信息:")
            for key, value in response.latency.items():
                print(f"  {key}: {value}ms")


if __name__ == "__main__":
    main()
