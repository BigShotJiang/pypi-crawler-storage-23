"""Octen API 同步客户端"""

from typing import Optional
from .core.http_client import HTTPClient
from .resources.search import SearchResource
from .resources.embedding import EmbeddingResource
from .utils.constants import DEFAULT_BASE_URL, DEFAULT_TIMEOUT, DEFAULT_MAX_RETRIES


class Octen:
    """Octen API 同步客户端

    提供对 Octen API 的便捷访问，支持搜索和嵌入功能。

    Attributes:
        search: Search API 资源
        embedding: Embedding API 资源

    Example:
        基础用法::

            from octen import Octen

            # 使用上下文管理器（推荐）
            with Octen(api_key="your-api-key") as client:
                # 搜索
                response = client.search.search("Python programming", count=5)
                for result in response.results:
                    print(result['title'])

                # 创建嵌入
                embedding = client.embedding.create("Hello, world!")
                vector = embedding.get_first_embedding()

        自定义配置::

            with Octen(
                api_key="your-api-key",
                base_url="https://api.octen.ai",
                timeout=60.0,
                max_retries=5
            ) as client:
                # 使用自定义超时
                response = client.search.search(
                    "complex query",
                    timeout=120.0
                )

        不使用上下文管理器::

            client = Octen(api_key="your-api-key")
            try:
                response = client.search.search("query")
            finally:
                client.close()  # 确保关闭连接
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http2: bool = True,
    ):
        """初始化 Octen 客户端

        Args:
            api_key: Octen API 密钥（必填）
            base_url: API 基础 URL（默认: https://api.octen.ai）
            timeout: 默认请求超时时间，单位秒（默认: 30.0）
            max_retries: 最大重试次数（默认: 3）
            http2: 是否启用 HTTP/2（默认: True）

        Raises:
            ValueError: 如果 api_key 为空
        """
        if not api_key:
            raise ValueError("api_key 不能为空")

        # 创建 HTTP 客户端（核心请求层）
        self._http_client = HTTPClient(
            base_url=base_url,
            api_key=api_key,
            timeout=timeout,
            max_retries=max_retries,
            http2=http2,
        )

        # 初始化资源（业务层）
        self.search = SearchResource(self._http_client)
        self.embedding = EmbeddingResource(self._http_client)

    def close(self):
        """关闭客户端，释放连接池资源

        在不使用上下文管理器时，应该手动调用此方法。
        """
        self._http_client.close()

    def __enter__(self):
        """支持上下文管理器协议"""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """退出上下文管理器时自动关闭客户端"""
        self.close()
        return False

    def __repr__(self) -> str:
        """返回客户端的字符串表示"""
        return f"Octen(base_url={self._http_client.base_url!r})"
