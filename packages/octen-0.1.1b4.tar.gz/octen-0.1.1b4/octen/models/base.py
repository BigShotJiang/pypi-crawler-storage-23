"""Pydantic 基础模型"""

from typing import Any, Dict
from pydantic import BaseModel, ConfigDict


class OctenBaseModel(BaseModel):
    """所有 Octen 数据模型的基类

    配置:
        - 允许额外字段（API 可能返回未知字段）
        - 使用别名生成器支持驼峰命名
        - 冻结模型以确保不可变性
    """

    model_config = ConfigDict(
        extra="allow",  # 允许额外字段
        populate_by_name=True,  # 支持字段别名
        validate_assignment=True,  # 赋值时验证
    )

    def to_dict(self, exclude_none: bool = True) -> Dict[str, Any]:
        """转换为字典

        Args:
            exclude_none: 是否排除 None 值

        Returns:
            字典表示
        """
        return self.model_dump(exclude_none=exclude_none, by_alias=True)
