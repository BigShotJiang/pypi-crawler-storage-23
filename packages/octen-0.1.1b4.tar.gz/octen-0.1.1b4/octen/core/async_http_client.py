"""异步 HTTP 客户端实现"""

import httpx
from typing import Optional, Dict, Any
from .retry import AsyncRetryHandler
from .exceptions import (
    OctenAPIError,
    OctenTimeoutError,
    OctenConnectionError,
    OctenRateLimitError,
    OctenAuthenticationError,
)
from ..utils.constants import (
    DEFAULT_TIMEOUT,
    DEFAULT_MAX_RETRIES,
    DEFAULT_MAX_CONNECTIONS,
    DEFAULT_MAX_KEEPALIVE_CONNECTIONS,
    DEFAULT_KEEPALIVE_EXPIRY,
    HEADER_API_KEY,
    HEADER_CONTENT_TYPE,
    HEADER_USER_AGENT,
    USER_AGENT_TEMPLATE,
)


class AsyncHTTPClient:
    """异步 HTTP 客户端

    支持连接池、长连接、HTTP/2 和自动重试

    Attributes:
        base_url: API 基础 URL
        api_key: API 密钥
        timeout: 默认超时时间（秒）
        max_retries: 最大重试次数
        http2: 是否启用 HTTP/2
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        http2: bool = True,
        max_connections: int = DEFAULT_MAX_CONNECTIONS,
        max_keepalive_connections: int = DEFAULT_MAX_KEEPALIVE_CONNECTIONS,
        keepalive_expiry: float = DEFAULT_KEEPALIVE_EXPIRY,
    ):
        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout
        self.max_retries = max_retries

        # 配置连接池
        limits = httpx.Limits(
            max_connections=max_connections,
            max_keepalive_connections=max_keepalive_connections,
            keepalive_expiry=keepalive_expiry,
        )

        # 获取版本号
        try:
            from ..version import __version__
        except ImportError:
            __version__ = "unknown"

        # 构建请求头
        headers = {
            HEADER_API_KEY: api_key,
            HEADER_CONTENT_TYPE: "application/json",
            HEADER_USER_AGENT: USER_AGENT_TEMPLATE.format(version=__version__),
        }

        # 创建 httpx 异步客户端
        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=httpx.Timeout(timeout),
            http2=http2,
            limits=limits,
            headers=headers,
            follow_redirects=True,
        )

        # 初始化异步重试处理器
        self._retry_handler = AsyncRetryHandler(max_retries=max_retries)

    async def request(
        self,
        method: str,
        endpoint: str,
        timeout: Optional[float] = None,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """发送异步 HTTP 请求

        Args:
            method: HTTP 方法（GET, POST 等）
            endpoint: API 端点路径
            timeout: 请求超时时间（秒），覆盖默认值
            json: JSON 请求体
            params: URL 查询参数
            **kwargs: 其他传递给 httpx 的参数

        Returns:
            响应的 JSON 数据

        Raises:
            OctenAPIError: API 返回错误
            OctenTimeoutError: 请求超时
            OctenConnectionError: 连接错误
        """

        async def _make_request() -> Dict[str, Any]:
            try:
                # 使用自定义超时或默认超时
                request_timeout = timeout if timeout is not None else self.timeout

                response = await self._client.request(
                    method=method,
                    url=endpoint,
                    json=json,
                    params=params,
                    timeout=request_timeout,
                    **kwargs,
                )

                # 处理响应
                return self._handle_response(response)

            except httpx.TimeoutException as e:
                raise OctenTimeoutError(
                    message=f"Request timed out: {str(e)}",
                    timeout=timeout or self.timeout,
                )
            except httpx.ConnectError as e:
                raise OctenConnectionError(
                    message=f"Connection failed: {str(e)}",
                )
            except httpx.HTTPError as e:
                raise OctenConnectionError(
                    message=f"HTTP error occurred: {str(e)}",
                )

        # 使用异步重试处理器执行请求
        return await self._retry_handler.execute_async(_make_request)

    def _handle_response(self, response: httpx.Response) -> Dict[str, Any]:
        """处理 HTTP 响应

        Args:
            response: httpx 响应对象

        Returns:
            响应的 JSON 数据

        Raises:
            OctenAPIError: API 返回错误
            OctenRateLimitError: 速率限制错误
            OctenAuthenticationError: 认证错误
        """
        # 提取请求 ID（如果存在）
        request_id = response.headers.get("x-request-id")

        # 尝试解析 JSON 一次（性能优化）
        response_data = self._safe_json(response)

        # 处理成功响应（2xx）
        if response.is_success:
            if response_data is not None:
                return response_data
            else:
                raise OctenAPIError(
                    message="Failed to parse response JSON",
                    status_code=response.status_code,
                    request_id=request_id,
                )

        # 处理错误响应 - 从已解析的 JSON 中提取错误消息
        error_message = self._extract_error_message_from_data(response_data, response)

        # 认证错误（401）
        if response.status_code == 401:
            raise OctenAuthenticationError(
                message=error_message,
                response_data=response_data,
                request_id=request_id,
            )

        # 速率限制错误（429）
        if response.status_code == 429:
            retry_after = response.headers.get("retry-after")
            retry_after_seconds = int(retry_after) if retry_after else None
            raise OctenRateLimitError(
                message=error_message,
                retry_after=retry_after_seconds,
                response_data=response_data,
                request_id=request_id,
            )

        # 其他 API 错误
        raise OctenAPIError(
            message=error_message,
            status_code=response.status_code,
            response_data=response_data,
            request_id=request_id,
        )

    def _extract_error_message_from_data(
        self, data: Optional[Dict[str, Any]], response: httpx.Response
    ) -> str:
        """从已解析的 JSON 数据中提取错误消息

        Args:
            data: 已解析的 JSON 数据
            response: httpx 响应对象

        Returns:
            错误消息字符串
        """
        # 尝试从响应中提取错误消息
        if isinstance(data, dict):
            if "msg" in data:
                return data["msg"]
            if "message" in data:
                return data["message"]
            if "error" in data:
                return str(data["error"])

        # 使用默认错误消息
        return f"HTTP {response.status_code}: {response.reason_phrase}"

    def _safe_json(self, response: httpx.Response) -> Optional[Dict[str, Any]]:
        """安全地解析 JSON 响应

        Args:
            response: httpx 响应对象

        Returns:
            JSON 数据或 None
        """
        try:
            return response.json()
        except Exception:
            return None

    async def close(self):
        """关闭 HTTP 客户端，释放连接池资源"""
        await self._client.aclose()

    async def __aenter__(self):
        """支持异步上下文管理器"""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """退出异步上下文管理器时自动关闭"""
        await self.close()
