"""SDK 常量定义"""

# 默认配置
DEFAULT_BASE_URL = "https://api.octen.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3

# 连接池配置
DEFAULT_MAX_CONNECTIONS = 100
DEFAULT_MAX_KEEPALIVE_CONNECTIONS = 20
DEFAULT_KEEPALIVE_EXPIRY = 30.0

# 重试配置
RETRY_BASE_DELAY = 1.0
RETRY_MAX_DELAY = 60.0

# API 端点
ENDPOINT_SEARCH = "/search"
ENDPOINT_EMBEDDING = "/embedding"

# 请求头
HEADER_API_KEY = "x-api-key"
HEADER_CONTENT_TYPE = "Content-Type"
HEADER_USER_AGENT = "User-Agent"

# User-Agent
USER_AGENT_TEMPLATE = "octen-python-sdk/{version}"

# 嵌入模型
EMBEDDING_MODELS = {
    "0.6b": "octen-embedding-0.6b",
    "4b": "octen-embedding-4b",
    "8b": "octen-embedding-8b",
}

# 搜索类型
SEARCH_TYPES = {"auto", "keyword", "semantic"}

# 时间基准
TIME_BASIS_OPTIONS = {"auto", "published", "crawled"}

# 格式选项
FORMAT_OPTIONS = {"text", "markdown"}

# 安全搜索
SAFESEARCH_OPTIONS = {"off", "strict"}

# 输入类型
INPUT_TYPES = {"query", "document"}
