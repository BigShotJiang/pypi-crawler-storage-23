"""Embedding API 资源封装"""

from typing import Union, List, Optional
from .base import Resource
from ..models.embedding import EmbeddingRequest, EmbeddingResponse
from ..utils.constants import ENDPOINT_EMBEDDING


class EmbeddingResource(Resource):
    """Embedding API 资源

    提供文本嵌入功能
    """

    def create(
        self,
        input: Union[str, List[str]],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        input_type: Optional[str] = None,
        truncation: Optional[bool] = None,
        timeout: Optional[float] = None,
    ) -> EmbeddingResponse:
        """创建文本嵌入向量

        Args:
            input: 输入文本（字符串或字符串列表）
            model: 模型名称（octen-embedding-0.6b/4b/8b）
            dimension: 向量维度
            input_type: 输入类型（query/document）
            truncation: 是否截断超长输入（默认 True）
            timeout: 请求超时时间（秒），覆盖默认值

        Returns:
            EmbeddingResponse: 嵌入响应对象

        Raises:
            OctenValidationError: 参数验证失败
            OctenAPIError: API 请求失败
            OctenTimeoutError: 请求超时

        Example:
            >>> from octen import Octen
            >>> client = Octen(api_key="your-api-key")
            >>>
            >>> # 单个文本
            >>> response = client.embedding.create(
            ...     input="Hello, world!",
            ...     model="octen-embedding-4b"
            ... )
            >>> vector = response.get_first_embedding()
            >>> print(f"维度: {len(vector)}")
            >>>
            >>> # 批量文本
            >>> response = client.embedding.create(
            ...     input=["text 1", "text 2", "text 3"],
            ...     model="octen-embedding-8b"
            ... )
            >>> vectors = response.get_embeddings()
            >>> print(f"生成了 {len(vectors)} 个向量")
        """
        # 创建并验证请求模型
        request = EmbeddingRequest(
            input=input,
            model=model,
            dimension=dimension,
            input_type=input_type,
            truncation=truncation,
        )

        # 调用 HTTP 客户端
        response_data = self._client.request(
            method="POST",
            endpoint=ENDPOINT_EMBEDDING,
            json=request.model_dump(exclude_none=True),
            timeout=timeout,
        )

        # 解析并返回响应
        return EmbeddingResponse(**response_data)

    def embed_query(
        self,
        text: str,
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> List[float]:
        """嵌入查询文本（便捷方法）

        Args:
            text: 查询文本
            model: 模型名称
            dimension: 向量维度
            timeout: 请求超时时间（秒）

        Returns:
            向量列表

        Example:
            >>> vector = client.embedding.embed_query("search query")
        """
        response = self.create(
            input=[text],  # 修正：包装为列表
            model=model,
            dimension=dimension,
            input_type="query",
            timeout=timeout,
        )
        return response.get_first_embedding() or []

    def embed_documents(
        self,
        texts: List[str],
        model: Optional[str] = None,
        dimension: Optional[int] = None,
        timeout: Optional[float] = None,
    ) -> List[List[float]]:
        """嵌入文档文本列表（便捷方法）

        Args:
            texts: 文档文本列表
            model: 模型名称
            dimension: 向量维度
            timeout: 请求超时时间（秒）

        Returns:
            向量列表的列表

        Example:
            >>> vectors = client.embedding.embed_documents(
            ...     ["doc 1", "doc 2", "doc 3"]
            ... )
        """
        response = self.create(
            input=texts,
            model=model,
            dimension=dimension,
            input_type="document",
            timeout=timeout,
        )
        return response.get_embeddings()
