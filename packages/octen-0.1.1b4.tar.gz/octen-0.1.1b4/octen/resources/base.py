"""资源基类"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..core.http_client import HTTPClient


class Resource:
    """所有资源类的基类

    负责封装 API 端点，提供业务逻辑层接口

    Attributes:
        _client: HTTP 客户端实例
    """

    def __init__(self, client: "HTTPClient"):
        """初始化资源

        Args:
            client: HTTP 客户端实例
        """
        self._client = client
