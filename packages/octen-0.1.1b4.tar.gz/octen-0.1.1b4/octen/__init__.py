"""Octen Python SDK

一个用于访问 Octen API 的 Python SDK，提供搜索和嵌入功能。

基础用法::

    from octen import Octen

    with Octen(api_key="your-api-key") as client:
        # 搜索
        response = client.search.search("Python", count=5)
        for result in response.results:
            print(result['title'])

        # 嵌入
        embedding = client.embedding.create("Hello")
        vector = embedding.get_first_embedding()
"""

from .version import __version__, __author__, __license__
from .client import Octen

# 核心异常
from .core.exceptions import (
    OctenError,
    OctenAPIError,
    OctenTimeoutError,
    OctenConnectionError,
    OctenValidationError,
    OctenRateLimitError,
    OctenAuthenticationError,
)

# 数据模型
from .models.search import (
    HighlightOptions,
    FullContentOptions,
    SearchRequest,
    SearchResponse,
)
from .models.embedding import (
    EmbeddingRequest,
    EmbeddingResponse,
)

# 尝试导入异步客户端（如果已实现）
try:
    from .async_client import AsyncOcten

    __all__ = [
        # 版本信息
        "__version__",
        "__author__",
        "__license__",
        # 客户端
        "Octen",
        "AsyncOcten",
        # 异常
        "OctenError",
        "OctenAPIError",
        "OctenTimeoutError",
        "OctenConnectionError",
        "OctenValidationError",
        "OctenRateLimitError",
        "OctenAuthenticationError",
        # 数据模型
        "HighlightOptions",
        "FullContentOptions",
        "SearchRequest",
        "SearchResponse",
        "EmbeddingRequest",
        "EmbeddingResponse",
    ]
except ImportError:
    __all__ = [
        # 版本信息
        "__version__",
        "__author__",
        "__license__",
        # 客户端
        "Octen",
        # 异常
        "OctenError",
        "OctenAPIError",
        "OctenTimeoutError",
        "OctenConnectionError",
        "OctenValidationError",
        "OctenRateLimitError",
        "OctenAuthenticationError",
        # 数据模型
        "HighlightOptions",
        "FullContentOptions",
        "SearchRequest",
        "SearchResponse",
        "EmbeddingRequest",
        "EmbeddingResponse",
    ]
