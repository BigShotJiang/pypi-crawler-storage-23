"""Eval framework for testing agent roles against prompt suites."""
