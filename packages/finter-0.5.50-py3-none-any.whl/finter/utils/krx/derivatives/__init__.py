"""
KRX Derivatives Utilities.

ISIN generation, expiry date calculation, and related utilities
for KRX (Korea Exchange) derivative products.

Example:
    >>> from finter.utils.krx.derivatives import future_near, expire_date
    >>> # Get near-month KOSPI200 futures ISIN
    >>> isin = future_near("01", 20250120)
    >>> print(isin)  # KR4101W30003
    >>> # Get expiry date from ISIN
    >>> expiry = expire_date(isin)
    >>> print(expiry)  # 20250313
"""

from finter.utils.krx.derivatives.constants import (
    AssetType,
    FUTURES,
    SPREADS,
    INDEX_FUTURES,
    EQUITIES,
    get_asset_type,
    get_future_asset_type,
    is_future,
    is_derivative,
)
from finter.utils.krx.derivatives.expiry import (
    # Expiry calculation by product type
    stock_future_expiry,
    index_future_expiry,
    currency_future_expiry,
    interest_rate_future_expiry,
    gold_future_expiry,
    lean_hog_future_expiry,
    # Near/Next expiry
    near_expiry,
    next_expiry,
    # ISIN-based expiry
    expire_date,
    expire_ym,
    is_expired,
    expire_week,
    expire_week_by_code,
)
from finter.utils.krx.derivatives.isin import (
    parity_code,
    year_code,
    month_code,
    expire_code,
    future_near,
    future_next,
    future_spread,
)
from finter.utils.krx.derivatives.tr_codes import (
    get_tr_codes,
    get_multiplier,
)

__all__ = [
    # Constants
    "AssetType",
    "FUTURES",
    "SPREADS",
    "INDEX_FUTURES",
    "EQUITIES",
    "get_asset_type",
    "get_future_asset_type",
    "is_future",
    "is_derivative",
    # Expiry
    "stock_future_expiry",
    "index_future_expiry",
    "currency_future_expiry",
    "interest_rate_future_expiry",
    "gold_future_expiry",
    "lean_hog_future_expiry",
    "near_expiry",
    "next_expiry",
    "expire_date",
    "expire_ym",
    "is_expired",
    "expire_week",
    "expire_week_by_code",
    # ISIN
    "parity_code",
    "year_code",
    "month_code",
    "expire_code",
    "future_near",
    "future_next",
    "future_spread",
    # TR codes
    "get_tr_codes",
    "get_multiplier",
]
