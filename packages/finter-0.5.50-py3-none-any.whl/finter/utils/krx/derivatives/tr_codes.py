"""
KRX TR Codes and Multipliers.

Provides mapping for:
- TR codes: KRX data feed message types (trade, quote, etc.)
- Multipliers: Contract size multipliers for each product

TR Code Structure:
    A3xxx - Trade (체결)
    B6xxx - Quote/Orderbook (호가)
    G7xxx - Trade + Quote combined
    A0xxx - Batch (일괄)
"""

from typing import TypedDict

from finter.utils.krx.derivatives.constants import (
    AssetType,
    get_asset_type,
    get_future_asset_type,
)


class TRCodes(TypedDict, total=False):
    """TR code dictionary for a product type."""
    trade: str        # 체결 데이터
    quote: str        # 호가 데이터
    quote_lp: str     # LP 제외 호가 (주식 전용)
    trade_quote: str | None  # 체결+호가 결합
    batch: str        # 일괄 데이터


# TR codes by asset type
_TR_CODE_MAP: dict[AssetType, TRCodes] = {
    # Stock futures
    AssetType.STOCK_FUTURE: {
        "trade": "A3015",
        "quote": "B6015",
        "trade_quote": "G7015",
        "batch": "A0015",
    },
    AssetType.STOCK_FUTURE_SPREAD: {
        "trade": "A3015",
        "quote": "B6015",
        "trade_quote": "G7015",
        "batch": "A0015",
    },

    # Mini KOSPI200
    AssetType.MINI_KOSPI200_FUTURE: {
        "trade": "A3124",
        "quote": "B6124",
        "trade_quote": "G7124",
        "batch": "A0124",
    },
    AssetType.MINI_KOSPI200_FUTURE_SPREAD: {
        "trade": "A3124",
        "quote": "B6124",
        "trade_quote": "G7124",
        "batch": "A0124",
    },

    # KOSDAQ150
    AssetType.KOSDAQ150_FUTURE: {
        "trade": "A3024",
        "quote": "B6024",
        "trade_quote": "G7024",
        "batch": "A0024",
    },
    AssetType.KOSDAQ150_FUTURE_SPREAD: {
        "trade": "A3024",
        "quote": "B6024",
        "trade_quote": "G7024",
        "batch": "A0024",
    },

    # KOSPI200
    AssetType.KOSPI200_FUTURE: {
        "trade": "A3014",
        "quote": "B6014",
        "trade_quote": "G7014",
        "batch": "A0014",
    },
    AssetType.KOSPI200_FUTURE_SPREAD: {
        "trade": "A3014",
        "quote": "B6014",
        "trade_quote": "G7014",
        "batch": "A0014",
    },

    # Currency futures (USD, EUR, JPY)
    AssetType.CURRENCY_FUTURE: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.CURRENCY_FUTURE_SPREAD: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },

    # CNH (Yuan) futures
    AssetType.CURRENCY_CNH_FUTURE: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.CURRENCY_CNH_FUTURE_SPREAD: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },

    # Interest rate futures (KTB)
    AssetType.INTEREST_RATE_FUTURE: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.INTEREST_RATE_FUTURE_SPREAD: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },

    # Commodity futures
    AssetType.LEAN_HOG_FUTURE: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.LEAN_HOG_FUTURE_SPREAD: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.GOLD_FUTURE: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },
    AssetType.GOLD_FUTURE_SPREAD: {
        "trade": "A3016",
        "quote": "B6016",
        "trade_quote": "G7016",
        "batch": "A0016",
    },

    # Equities
    AssetType.COMMON_STOCK: {
        "trade": "A3011",
        "quote": "B7011",
        "quote_lp": "B6011",  # LP excluded
        "trade_quote": None,
        "batch": "A0011",
    },
    AssetType.TYPE_STOCK: {
        "trade": "A3011",
        "quote": "B7011",
        "quote_lp": "B6011",
        "trade_quote": None,
        "batch": "A0011",
    },
    AssetType.ETF: {
        "trade": "A3011",
        "quote": "B7011",
        "quote_lp": "B6011",
        "trade_quote": None,
        "batch": "A0011",
    },
    AssetType.ETN: {
        "trade": "A3011",
        "quote": "B7011",
        "quote_lp": "B6011",
        "trade_quote": None,
        "batch": "A0011",
    },
}


def get_tr_codes(isin_or_code: str) -> TRCodes:
    """
    Get TR codes for a product.

    Args:
        isin_or_code: Either 12-character ISIN or 2-digit product code

    Returns:
        Dictionary with TR codes for trade, quote, trade_quote, batch

    Raises:
        ValueError: If asset type is not supported

    Example:
        >>> get_tr_codes("KR4A01W20005")  # KOSPI200 future
        {'trade': 'A3014', 'quote': 'B6014', 'trade_quote': 'G7014', 'batch': 'A0014'}
        >>> get_tr_codes("01")  # KOSPI200 code
        {'trade': 'A3014', 'quote': 'B6014', 'trade_quote': 'G7014', 'batch': 'A0014'}
    """
    if len(isin_or_code) == 12:
        asset_type = get_asset_type(isin_or_code)
    else:
        asset_type = get_future_asset_type(isin_or_code)

    if asset_type not in _TR_CODE_MAP:
        raise ValueError(f"Unsupported asset type: {asset_type}")

    return _TR_CODE_MAP[asset_type]


# Multipliers by product code
# Contract size = price * multiplier
_MULTIPLIER_MAP: dict[str, int] = {
    "01": 250_000,   # KOSPI200 (250,000 KRW per point)
    "05": 50_000,    # Mini KOSPI200 (50,000 KRW per point)
    "06": 10_000,    # KOSDAQ150 (10,000 KRW per point)
    "65": 1_000_000, # KTB 3-year (1M KRW)
    "66": 1_000_000, # KTB 5-year (1M KRW)
    "67": 1_000_000, # KTB 10-year (1M KRW)
    "68": 1_000_000, # KTB 3-10 spread (1M KRW)
    "75": 10_000,    # USD/KRW (10,000 USD)
    "76": 10_000,    # EUR/KRW (10,000 EUR)
    "77": 10_000,    # JPY/KRW (10,000 x 100 JPY)
    "78": 100_000,   # CNH/KRW (100,000 CNH)
    "86": 1_000,     # Lean Hog (1,000 kg)
    "88": 100,       # Gold (100g)
}

# Default multiplier for stock futures
_DEFAULT_MULTIPLIER = 10


def get_multiplier(isin_or_code: str) -> int:
    """
    Get contract multiplier for a product.

    The multiplier is used to calculate notional value:
    Notional Value = Price * Multiplier

    Args:
        isin_or_code: Either 12-character ISIN or 2-digit product code

    Returns:
        Integer multiplier

    Example:
        >>> get_multiplier("01")  # KOSPI200
        250000
        >>> get_multiplier("KR4A01W20005")
        250000
        >>> get_multiplier("11")  # Stock future (e.g., Samsung)
        10
    """
    code = isin_or_code
    if len(isin_or_code) == 12:
        code = isin_or_code[4:6]

    return _MULTIPLIER_MAP.get(code, _DEFAULT_MULTIPLIER)
