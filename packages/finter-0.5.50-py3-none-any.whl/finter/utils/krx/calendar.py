"""
KRX Calendar Utilities.

Handles KRX (Korea Exchange) trading calendar including holidays,
business day calculations, and nth weekday computations.

Data is loaded from S3 with package fallback.
"""

from datetime import datetime, time, timedelta
from typing import List, Tuple, Union

from finter.utils.krx.data.loader import (
    get_holidays_set,
    get_holidays_yyyymmdd_set,
    get_market_times,
)


def datetime_to_yyyymmdd(dt: datetime) -> int:
    """Convert datetime to YYYYMMDD integer format."""
    return dt.year * 10000 + dt.month * 100 + dt.day


def yyyymmdd_to_datetime(date: int) -> datetime:
    """
    Convert YYYYMMDD integer to datetime.

    Args:
        date: Date in YYYYMMDD format (e.g., 20250120)

    Returns:
        datetime object
    """
    year = date // 10000
    month = (date % 10000) // 100
    day = date % 100
    return datetime(year, month, day)


def yyyymmdd_to_ymd(date: int) -> Tuple[int, int, int]:
    """
    Split YYYYMMDD integer into year, month, day components.

    Args:
        date: Date in YYYYMMDD format

    Returns:
        Tuple of (year, month, day)
    """
    year = date // 10000
    month = (date % 10000) // 100
    day = date % 100
    return year, month, day


def is_holiday(date: Union[int, datetime]) -> bool:
    """
    Check if a date is a KRX holiday.

    Args:
        date: Date as YYYYMMDD integer or datetime object

    Returns:
        True if the date is a KRX holiday
    """
    if isinstance(date, datetime):
        return date in get_holidays_set()
    return date in get_holidays_yyyymmdd_set()


def is_business_day(date: Union[int, datetime]) -> bool:
    """
    Check if a date is a KRX business day.

    A business day is a weekday (Mon-Fri) that is not a KRX holiday.

    Args:
        date: Date as YYYYMMDD integer or datetime object

    Returns:
        True if the date is a trading day
    """
    if isinstance(date, int):
        date = yyyymmdd_to_datetime(date)

    # Weekend check (Saturday=5, Sunday=6)
    if date.weekday() >= 5:
        return False

    return date not in get_holidays_set()


def nth_weekday(year: int, month: int, nth_week: int, weekday: int) -> datetime:
    """
    Find the nth occurrence of a weekday in a given month.

    Args:
        year: Year (e.g., 2025)
        month: Month (1-12)
        nth_week: Which occurrence (1 = first, 2 = second, etc.)
        weekday: Day of week (0 = Monday, 1 = Tuesday, ..., 6 = Sunday)

    Returns:
        datetime of the nth weekday
    """
    first_day = datetime(year, month, 1)
    days_until = (weekday - first_day.weekday()) % 7
    first_occurrence = first_day + timedelta(days=days_until)
    return first_occurrence + timedelta(weeks=nth_week - 1)


def workdays_before(date: int, n: int) -> List[int]:
    """
    Get n business days up to and including the given date.

    Args:
        date: End date in YYYYMMDD format
        n: Number of business days to retrieve

    Returns:
        List of business days in YYYYMMDD format, sorted ascending
    """
    dt = yyyymmdd_to_datetime(date)
    result: List[int] = []

    while len(result) < n:
        if is_business_day(dt):
            result.insert(0, datetime_to_yyyymmdd(dt))
        dt -= timedelta(days=1)

    return result


def next_month(yyyymm: int) -> int:
    """
    Get the next month in YYYYMM format.

    Args:
        yyyymm: Month in YYYYMM format (e.g., 202501)

    Returns:
        Next month in YYYYMM format
    """
    year = yyyymm // 100
    month = yyyymm % 100

    if month == 12:
        return (year + 1) * 100 + 1
    return yyyymm + 1


def this_quarter(yyyymm: int) -> int:
    """
    Get the end month of the current quarter in YYYYMM format.

    Quarter end months: 3, 6, 9, 12

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Quarter end month (YYYYMM)
    """
    year = yyyymm // 100
    month = yyyymm % 100
    quarter_end = ((month - 1) // 3 + 1) * 3
    return year * 100 + quarter_end


def next_quarter(yyyymm: int) -> int:
    """
    Get the end month of the next quarter in YYYYMM format.

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Next quarter end month (YYYYMM)
    """
    current = this_quarter(yyyymm)
    month = current % 100

    if month == 12:
        year = current // 100
        return (year + 1) * 100 + 3
    return current + 3


# Market time functions
def get_market_open_time(date: Union[int, datetime]) -> time:
    """
    Get market open time for a specific date.

    Normal: 09:00:00
    Special days (수능, 개장일): varies

    Args:
        date: Date as YYYYMMDD integer or datetime object

    Returns:
        Market open time
    """
    if isinstance(date, int):
        date = yyyymmdd_to_datetime(date)

    for mt in get_market_times():
        if mt.date.date() == date.date():
            return mt.start_time

    return time(9, 0, 0)


def get_market_close_time(date: Union[int, datetime]) -> time:
    """
    Get market close time for a specific date.

    Normal: 15:30:00
    Special days: varies (e.g., 수능일 16:20)

    Args:
        date: Date as YYYYMMDD integer or datetime object

    Returns:
        Market close time
    """
    if isinstance(date, int):
        date = yyyymmdd_to_datetime(date)

    for mt in get_market_times():
        if mt.date.date() == date.date():
            return mt.end_time

    return time(15, 30, 0)
