"""
KRX (Korea Exchange) Utilities.

Provides utilities for working with KRX market data:
- calendar: Trading calendar, holidays, business day utilities
- derivatives: ISIN generation, expiry calculation for futures/options
- data: Holiday and market time data loading from S3 with package fallback
"""

from finter.utils.krx.calendar import (
    datetime_to_yyyymmdd,
    yyyymmdd_to_datetime,
    yyyymmdd_to_ymd,
    is_holiday,
    is_business_day,
    nth_weekday,
    workdays_before,
    next_month,
    next_quarter,
    this_quarter,
    get_market_open_time,
    get_market_close_time,
)

from finter.utils.krx.data.loader import (
    get_holidays,
    get_holidays_set,
    get_holidays_yyyymmdd_set,
    get_market_times,
    Holiday,
    MarketTime,
)

__all__ = [
    # Calendar utilities
    "datetime_to_yyyymmdd",
    "yyyymmdd_to_datetime",
    "yyyymmdd_to_ymd",
    "is_holiday",
    "is_business_day",
    "nth_weekday",
    "workdays_before",
    "next_month",
    "next_quarter",
    "this_quarter",
    "get_market_open_time",
    "get_market_close_time",
    # Data access
    "get_holidays",
    "get_holidays_set",
    "get_holidays_yyyymmdd_set",
    "get_market_times",
    "Holiday",
    "MarketTime",
]
