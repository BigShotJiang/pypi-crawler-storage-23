"""
finter.lookthrough - ETF Position Look-Through Analysis

This module provides functions to analyze portfolio positions by decomposing
ETF holdings into their underlying assets, giving a true view of actual exposures.

Quick usage:
    from finter.lookthrough import get_model_lookthrough
    result = get_model_lookthrough('alpha.krx.krx.stock.user.model')

For batch operations:
    from finter.lookthrough import get_model_lookthrough_batch
    results = get_model_lookthrough_batch(['model1', 'model2'])

Dependencies:
    - finter.data (ModelData, Symbol)
    - pandas
    - redis (optional, for caching)
    - boto3 (for S3 ETF holdings data)
"""

from finter.lookthrough.api import (
    get_model_lookthrough,
    get_model_lookthrough_batch,
    LookthroughApi,
)

__all__ = [
    'get_model_lookthrough',
    'get_model_lookthrough_batch',
    'LookthroughApi',
]
