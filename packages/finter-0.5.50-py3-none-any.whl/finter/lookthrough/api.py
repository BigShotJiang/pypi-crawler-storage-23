"""
High-level API for ETF look-through analysis.

This module provides easy-to-use functions for analyzing model positions
by decomposing ETF holdings into underlying assets.

Usage:
    from finter.lookthrough import get_model_lookthrough

    # Single model
    result = get_model_lookthrough('alpha.krx.krx.stock.user.model')

    # Batch
    results = get_model_lookthrough_batch(['model1', 'model2'])
"""

import os
import json
import threading
from typing import Dict, List, Optional

from finter.lookthrough.calculator import LookthroughCalculator


# Singleton calculator instance
_calculator_instance: Optional[LookthroughCalculator] = None
_calculator_lock = threading.Lock()


def _get_calculator() -> LookthroughCalculator:
    """Get or create singleton calculator instance."""
    global _calculator_instance
    with _calculator_lock:
        if _calculator_instance is None:
            _calculator_instance = LookthroughCalculator()
    return _calculator_instance


def get_model_lookthrough(
    model_id: str,
    top_n: int = 5,
    force_refresh: bool = False,
) -> Dict:
    """
    Get ETF look-through analysis for a model.

    This function loads the model's positions, identifies ETF holdings,
    and decomposes them into their underlying assets using Morningstar data.

    Args:
        model_id: Full model ID (e.g., 'alpha.krx.krx.stock.user.model')
        top_n: Number of top holdings to include in summary (default: 5)
        force_refresh: If True, bypass cache and recalculate (default: False)

    Returns:
        Dict containing:
            - top_holdings: List of dicts with {ticker, name, weight, source_etfs}
            - total_positions: Total number of unique positions after decomposition
            - concentration_top5: Weight concentration in top 5 holdings (0-1)
            - _from_cache: Whether result was from cache
            - _calculated_at: Timestamp if freshly calculated
            - _error: Error message if calculation failed

    Example:
        >>> result = get_model_lookthrough('alpha.krx.krx.stock.smpark.momentum_v1')
        >>> print(result['top_holdings'][0])
        {'ticker': '005930', 'name': 'Samsung Electronics', 'weight': 24.5, 'source_etfs': 'KODEX 200'}
        >>> print(f"Concentration: {result['concentration_top5']:.1%}")
        Concentration: 42.3%
    """
    calculator = _get_calculator()
    return calculator.calculate_for_model(model_id, top_n, force_refresh)


def get_model_lookthrough_batch(
    model_ids: List[str],
    top_n: int = 5,
    force_refresh: bool = False,
) -> Dict[str, Dict]:
    """
    Get look-through analysis for multiple models at once.

    This is more efficient than calling get_model_lookthrough repeatedly
    as it shares the ETF data loading across all models.

    Args:
        model_ids: List of model IDs to analyze
        top_n: Number of top holdings per model (default: 5)
        force_refresh: If True, bypass cache for all models (default: False)

    Returns:
        Dict mapping model_id to look-through result dict.
        Models that fail to calculate will have _error in their result.

    Example:
        >>> results = get_model_lookthrough_batch([
        ...     'alpha.krx.krx.stock.smpark.model1',
        ...     'portfolio.krx.krx.stock.smpark.model2',
        ... ])
        >>> for model_id, data in results.items():
        ...     print(f"{model_id}: {data['total_positions']} positions")
    """
    calculator = _get_calculator()
    results = {}

    for model_id in model_ids:
        try:
            results[model_id] = calculator.calculate_for_model(
                model_id, top_n, force_refresh
            )
        except Exception as e:
            results[model_id] = {
                "top_holdings": [],
                "total_positions": 0,
                "concentration_top5": 0.0,
                "_from_cache": False,
                "_error": str(e)
            }

    return results


class LookthroughApi:
    """
    Object-oriented API for look-through analysis.

    This class provides more control over the calculation process,
    including custom Redis configuration and direct access to
    intermediate results.

    Example:
        >>> api = LookthroughApi(redis_host='localhost', redis_port=6379)
        >>> result = api.get_model_lookthrough('alpha.krx.krx.stock.user.model')
        >>> api.invalidate_cache('alpha.krx.krx.stock.user.model')
    """

    def __init__(
        self,
        redis_host: str = None,
        redis_port: int = None,
    ):
        """
        Initialize API with optional custom Redis configuration.

        Args:
            redis_host: Redis host (default: REDIS_HOST env var or localhost)
            redis_port: Redis port (default: REDIS_PORT env var or 6379)
        """
        self._calculator = LookthroughCalculator(redis_host, redis_port)

    def get_model_lookthrough(
        self,
        model_id: str,
        top_n: int = 5,
        force_refresh: bool = False,
    ) -> Dict:
        """
        Get look-through analysis for a model.

        See module-level get_model_lookthrough() for full documentation.
        """
        return self._calculator.calculate_for_model(model_id, top_n, force_refresh)

    def get_model_lookthrough_batch(
        self,
        model_ids: List[str],
        top_n: int = 5,
        force_refresh: bool = False,
    ) -> Dict[str, Dict]:
        """
        Get look-through for multiple models.

        See module-level get_model_lookthrough_batch() for full documentation.
        """
        results = {}
        for model_id in model_ids:
            try:
                results[model_id] = self._calculator.calculate_for_model(
                    model_id, top_n, force_refresh
                )
            except Exception as e:
                results[model_id] = {
                    "top_holdings": [],
                    "total_positions": 0,
                    "concentration_top5": 0.0,
                    "_from_cache": False,
                    "_error": str(e)
                }
        return results

    def calculate_positions_lookthrough(
        self,
        positions_df,
        universe: str = 'kr_stock',
        top_n: int = 5,
    ) -> Dict:
        """
        Calculate look-through for a positions DataFrame directly.

        This method allows you to calculate look-through without going
        through ModelData, useful for custom position data.

        Args:
            positions_df: DataFrame with columns [ticker, weight]
            universe: Universe type ('kr_stock' supported)
            top_n: Number of top holdings in summary

        Returns:
            Dict with look-through summary

        Example:
            >>> import pandas as pd
            >>> positions = pd.DataFrame([
            ...     {'ticker': '7754', 'weight': 50.0},   # KODEX 200
            ...     {'ticker': '5930', 'weight': 30.0},  # Samsung
            ... ])
            >>> api = LookthroughApi()
            >>> result = api.calculate_positions_lookthrough(positions, 'kr_stock')
        """
        lookthrough_df = self._calculator.calculate_lookthrough(positions_df, universe)
        summary = self._calculator.get_lookthrough_summary(lookthrough_df, top_n)
        summary['_from_cache'] = False
        return summary

    def invalidate_cache(self, model_id: str) -> bool:
        """
        Invalidate cached look-through for a model.

        Args:
            model_id: Model ID to invalidate

        Returns:
            True if cache was invalidated, False otherwise
        """
        try:
            r = self._calculator._get_redis()
            if r:
                cache_key = f"lookthrough:model:{model_id}"
                return r.delete(cache_key) > 0
        except Exception:
            pass
        return False

    def get_cache_stats(self) -> Dict:
        """
        Get cache statistics.

        Returns:
            Dict with cache stats (count, memory, etc.)
        """
        try:
            r = self._calculator._get_redis()
            if r is None:
                return {'status': 'unavailable'}

            # Count lookthrough keys
            count = 0
            for _ in r.scan_iter('lookthrough:model:*', count=1000):
                count += 1

            return {
                'status': 'connected',
                'lookthrough_keys': count,
            }
        except Exception as e:
            return {'status': 'error', 'error': str(e)}

    def preload_etf_data(self) -> Dict:
        """
        Preload ETF data into memory.

        Call this once before batch processing to avoid repeated S3 loads.

        Returns:
            Dict with loading stats
        """
        holdings_df, ticker_map = self._calculator._load_etf_holdings()
        etf_set = self._calculator._load_etf_set()

        return {
            'holdings_count': len(holdings_df),
            'ticker_mappings': len(ticker_map),
            'etf_ccids': len(etf_set),
        }
