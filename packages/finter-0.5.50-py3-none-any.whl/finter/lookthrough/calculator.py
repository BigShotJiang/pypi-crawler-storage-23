"""
Core look-through calculation logic.

This module contains the LookthroughCalculator class which handles:
1. Loading model positions via ModelData
2. Detecting ETF holdings
3. Decomposing ETFs into underlying assets
4. Caching results
"""

import os
import hashlib
from collections import defaultdict
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import pandas as pd

# Finter imports
try:
    from finter.data import Symbol, ModelData
    HAS_FINTER = True
except ImportError:
    HAS_FINTER = False

# S3 for Morningstar data
try:
    import boto3
    from botocore.config import Config as BotoConfig
    HAS_BOTO3 = True
except ImportError:
    HAS_BOTO3 = False

# Redis for caching
try:
    import redis
    HAS_REDIS = True
except ImportError:
    HAS_REDIS = False


class LookthroughCalculator:
    """
    Calculator for ETF look-through analysis.

    This class handles the decomposition of ETF positions into their
    underlying holdings using Morningstar data.
    """

    # S3 bucket and paths for Morningstar data
    S3_BUCKET = 'quanda-sm-test'
    S3_HOLDINGS_KEY = 'morningstar/api_inventory/df_fullholdings.csv'
    S3_OPP_KEY = 'morningstar/api_inventory/df_opp.csv'

    # S3 client config with timeouts to prevent hanging
    S3_CONFIG = BotoConfig(
        connect_timeout=5,
        read_timeout=30,
        retries={'max_attempts': 3, 'mode': 'standard'}
    ) if HAS_BOTO3 else None

    # CSV fallback path
    ETF_UNIVERSE_CSV = Path.home() / 'data' / 'kr_etf_universe_all.csv'

    # Cache TTL (24 hours)
    CACHE_TTL = 86400

    def __init__(self, redis_host: str = None, redis_port: int = None):
        """
        Initialize calculator.

        Args:
            redis_host: Redis host (default: REDIS_HOST env var or localhost)
            redis_port: Redis port (default: REDIS_PORT env var or 6379)
        """
        self._redis_host = redis_host or os.environ.get('REDIS_HOST', 'localhost')
        self._redis_port = redis_port or int(os.environ.get('REDIS_PORT', 6379))

        # Cache for ETF data (loaded once per instance)
        self._etf_holdings_df: Optional[pd.DataFrame] = None
        self._ticker_to_mstarid: Optional[Dict[str, str]] = None
        self._etf_set: Optional[Set[int]] = None

        # Redis client (lazy init)
        self._redis_client = None

    def _get_redis(self):
        """Get Redis client (lazy initialization)."""
        if not HAS_REDIS:
            return None

        if self._redis_client is None:
            try:
                self._redis_client = redis.Redis(
                    host=self._redis_host,
                    port=self._redis_port,
                    decode_responses=False,
                    socket_connect_timeout=5,
                    socket_timeout=10,
                )
                self._redis_client.ping()
            except Exception:
                self._redis_client = None

        return self._redis_client

    def _load_etf_holdings(self) -> Tuple[pd.DataFrame, Dict[str, str]]:
        """
        Load ETF holdings from Morningstar S3 data.

        Returns:
            Tuple of (holdings_df, ticker_to_mstarid)
        """
        if self._etf_holdings_df is not None:
            return self._etf_holdings_df, self._ticker_to_mstarid

        if not HAS_BOTO3:
            return pd.DataFrame(), {}

        try:
            s3 = boto3.client('s3', config=self.S3_CONFIG)

            # Load holdings
            obj = s3.get_object(Bucket=self.S3_BUCKET, Key=self.S3_HOLDINGS_KEY)
            self._etf_holdings_df = pd.read_csv(BytesIO(obj['Body'].read()))

            # Load opportunity data for ticker to MStarID mapping
            obj = s3.get_object(Bucket=self.S3_BUCKET, Key=self.S3_OPP_KEY)
            df_opp = pd.read_csv(BytesIO(obj['Body'].read()))

            # Build ticker to mstarid mapping
            self._ticker_to_mstarid = {}
            if 'Ticker' in df_opp.columns and 'MStarID' in df_opp.columns:
                for _, row in df_opp[df_opp['Ticker'].notna()].drop_duplicates(subset=['Ticker']).iterrows():
                    try:
                        ticker_val = row['Ticker']
                        if isinstance(ticker_val, (int, float)):
                            short_code = str(int(ticker_val))
                        else:
                            short_code = str(ticker_val).strip()
                            if short_code.isdigit():
                                short_code = str(int(short_code))

                        if not short_code:
                            continue

                        mstar_id = str(row['MStarID'])
                        self._ticker_to_mstarid[short_code] = mstar_id
                        self._ticker_to_mstarid[f"A{short_code}"] = mstar_id
                        if short_code.isdigit() and len(short_code) < 6:
                            self._ticker_to_mstarid[short_code.zfill(6)] = mstar_id
                    except (ValueError, TypeError):
                        continue

            return self._etf_holdings_df, self._ticker_to_mstarid

        except Exception as e:
            print(f"[lookthrough] Failed to load Morningstar data: {e}")
            return pd.DataFrame(), {}

    def _load_etf_set(self) -> Set[int]:
        """
        Load set of ETF ccids.

        Returns:
            Set of ETF ccids
        """
        if self._etf_set is not None:
            return self._etf_set

        # Try to get from cache first
        r = self._get_redis()
        if r:
            try:
                data = r.smembers('etf_set:kr_stock')
                if data:
                    self._etf_set = {int(x.decode('utf-8') if isinstance(x, bytes) else x) for x in data}
                    return self._etf_set
            except Exception:
                pass

        # Fallback: load from CSV
        if self.ETF_UNIVERSE_CSV.exists():
            try:
                df = pd.read_csv(self.ETF_UNIVERSE_CSV)
                if 'ccid' in df.columns:
                    self._etf_set = set(df['ccid'].dropna().astype(int).unique())

                    # Cache to Redis
                    if r and self._etf_set:
                        try:
                            key = 'etf_set:kr_stock'
                            r.delete(key)
                            r.sadd(key, *[str(x) for x in self._etf_set])
                            r.expire(key, self.CACHE_TTL)
                        except Exception:
                            pass

                    return self._etf_set
            except Exception:
                pass

        self._etf_set = set()
        return self._etf_set

    def _ccid_to_short_code(self, ccid: int) -> Optional[str]:
        """Convert ccid to short_code."""
        if not HAS_FINTER:
            return None

        try:
            result = Symbol.convert("id", "short_code", [ccid])
            return result.get(ccid)
        except Exception:
            return None

    def _get_etf_holdings(self, etf_code: str) -> pd.DataFrame:
        """Get holdings for a specific ETF."""
        holdings_df, ticker_to_mstarid = self._load_etf_holdings()
        if holdings_df.empty:
            return pd.DataFrame()

        # Try different code formats
        codes_to_try = [etf_code, f"A{etf_code}", etf_code.lstrip("A")]
        if etf_code.isdigit():
            codes_to_try.append(etf_code.zfill(6))

        mstarid = None
        for code in codes_to_try:
            if code in ticker_to_mstarid:
                mstarid = ticker_to_mstarid[code]
                break

        if not mstarid:
            return pd.DataFrame()

        # Filter holdings for this ETF
        if 'MStarID' in holdings_df.columns:
            etf_holdings = holdings_df[holdings_df['MStarID'] == mstarid].copy()
        elif 'FundMStarID' in holdings_df.columns:
            etf_holdings = holdings_df[holdings_df['FundMStarID'] == mstarid].copy()
        else:
            return pd.DataFrame()

        if etf_holdings.empty:
            return pd.DataFrame()

        # Get latest date
        if 'PortfolioDate' in etf_holdings.columns:
            latest_date = etf_holdings['PortfolioDate'].max()
            etf_holdings = etf_holdings[etf_holdings['PortfolioDate'] == latest_date]

        # Standardize column names
        result = pd.DataFrame()
        result['holding_ticker'] = etf_holdings.get('Ticker', etf_holdings.get('ticker', ''))
        result['holding_name'] = etf_holdings.get('Name', etf_holdings.get('name', ''))
        result['weight'] = etf_holdings.get('Weighting', etf_holdings.get('weight', 0))

        return result

    def _load_positions(self, model_id: str) -> pd.DataFrame:
        """
        Load model positions via ModelData.

        Args:
            model_id: Full model ID (e.g., 'alpha.krx.krx.stock.user.model')

        Returns:
            DataFrame with columns [ticker, weight] where ticker is ccid
        """
        if not HAS_FINTER:
            raise ImportError("finter package not available")

        try:
            # Use ModelData to get latest positions (no date args needed)
            data = ModelData.load(model_id)

            if data is None or data.empty:
                return pd.DataFrame(columns=['ticker', 'weight'])

            # Get latest row (columns are ccids, values are weights)
            latest_data = data.iloc[-1]

            # Convert to ticker/weight format
            # Filter non-zero positions and normalize weights to percentages
            positions = []
            total_weight = latest_data[latest_data != 0].abs().sum()

            if total_weight == 0:
                return pd.DataFrame(columns=['ticker', 'weight'])

            for ticker, weight in latest_data.items():
                if pd.notna(weight) and weight != 0:
                    # Normalize to percentage (0-100)
                    norm_weight = float(weight) / total_weight * 100.0
                    positions.append({'ticker': str(ticker), 'weight': norm_weight})

            return pd.DataFrame(positions)

        except Exception as e:
            print(f"[lookthrough] Failed to load positions for {model_id}: {e}")
            return pd.DataFrame(columns=['ticker', 'weight'])

    def calculate_lookthrough(
        self,
        positions: pd.DataFrame,
        universe: str = 'kr_stock',
        max_depth: int = 3
    ) -> pd.DataFrame:
        """
        Calculate look-through positions by recursively decomposing ETFs.

        ETFs that hold other ETFs (e.g. leveraged ETFs holding the base ETF)
        are decomposed recursively up to max_depth levels. Any remaining ETFs
        after decomposition are filtered out of the final result.

        Args:
            positions: DataFrame with columns [ticker, weight]
            universe: Universe type (currently only 'kr_stock' supported)
            max_depth: Maximum decomposition depth (default 3)

        Returns:
            DataFrame with columns [ticker, name, weight, source_etfs]
            containing only non-ETF underlying stocks.
        """
        if positions is None or positions.empty:
            return pd.DataFrame(columns=['ticker', 'name', 'weight', 'source_etfs'])

        if universe != 'kr_stock':
            print(f"[lookthrough] Only kr_stock supported, got {universe}")
            return pd.DataFrame(columns=['ticker', 'name', 'weight', 'source_etfs'])

        # Load ETF data
        etf_set = self._load_etf_set()
        holdings_df, ticker_to_mstarid = self._load_etf_holdings()

        if holdings_df.empty:
            return pd.DataFrame(columns=['ticker', 'name', 'weight', 'source_etfs'])

        # Build short_code ETF set for fast membership check on holdings
        etf_short_codes = set(ticker_to_mstarid.keys())

        # Result accumulator - use normalized ticker as key
        result = defaultdict(lambda: {"weight": 0.0, "source_etfs": set(), "name": ""})

        def normalize_ticker(t: str) -> str:
            """Normalize ticker to 6-digit short_code format for KR stocks."""
            t = str(t).strip().lstrip('A')
            if not t or t.lower() == 'nan':
                return ''
            if t.isdigit():
                return t.zfill(6)
            return t

        def _resolve_etf_short_code(ticker: str) -> Optional[str]:
            """Resolve ticker to ETF short_code if it's an ETF, else None."""
            for code in [ticker, f"A{ticker}", ticker.lstrip("A"), ticker.zfill(6)]:
                if code in ticker_to_mstarid:
                    return code
            if ticker.isdigit():
                try:
                    ccid = int(ticker)
                    if ccid in etf_set:
                        return self._ccid_to_short_code(ccid)
                except (ValueError, TypeError):
                    pass
            return None

        def _is_holding_etf(h_ticker: str) -> bool:
            """Check if a holding ticker (from Morningstar) is also an ETF."""
            for code in [h_ticker, h_ticker.lstrip("A"), h_ticker.zfill(6)]:
                if code in etf_short_codes:
                    return True
            return False

        def _decompose(ticker: str, weight: float, source_etf_label: str, depth: int):
            """Recursively decompose ETF holdings."""
            if weight <= 0:
                return

            short_code = _resolve_etf_short_code(ticker)

            if short_code is None:
                # Not an ETF — it's a stock, add to result
                norm = normalize_ticker(ticker)
                if norm:
                    result[norm]["weight"] += weight
                    if source_etf_label:
                        result[norm]["source_etfs"].add(source_etf_label)
                return

            # It's an ETF
            if depth >= max_depth:
                # Max depth reached — skip this ETF (don't add to results)
                return

            etf_holdings = self._get_etf_holdings(short_code)
            if etf_holdings.empty:
                # No Morningstar data for this ETF — skip
                return

            etf_label = source_etf_label or normalize_ticker(short_code)
            for _, h in etf_holdings.iterrows():
                h_ticker = str(h["holding_ticker"]).strip()
                h_weight = weight * float(h["weight"]) / 100.0
                h_name = str(h.get("holding_name", "")) if h.get("holding_name") else ""

                if not h_ticker or h_ticker.lower() == 'nan' or h_weight <= 0:
                    continue

                if _is_holding_etf(h_ticker):
                    # This holding is also an ETF — recurse
                    _decompose(h_ticker, h_weight, etf_label, depth + 1)
                else:
                    # Stock — add directly
                    norm_h = normalize_ticker(h_ticker)
                    if norm_h:
                        result[norm_h]["weight"] += h_weight
                        result[norm_h]["source_etfs"].add(etf_label)
                        if not result[norm_h]["name"] and h_name and h_name.lower() != 'nan':
                            result[norm_h]["name"] = h_name

        # Process each position
        for _, row in positions.iterrows():
            ticker = str(row.get("ticker", "")).strip()
            weight = float(row.get("weight", 0))
            if weight <= 0 or not ticker:
                continue
            _decompose(ticker, weight, "", 0)

        # Convert to DataFrame
        rows = []
        for ticker, data in result.items():
            if not ticker or ticker == 'nan':
                continue
            rows.append({
                "ticker": ticker,
                "name": data["name"] or ticker,
                "weight": round(data["weight"], 2),
                "source_etfs": ", ".join(sorted(data["source_etfs"])) if data["source_etfs"] else ""
            })

        df = pd.DataFrame(rows)
        if not df.empty:
            # Normalize weights to sum to 100% (leveraged ETFs may exceed 100%)
            total = df["weight"].sum()
            if total > 0 and abs(total - 100.0) > 1.0:
                df["weight"] = (df["weight"] / total * 100).round(2)
            df = df.sort_values("weight", ascending=False).reset_index(drop=True)

        return df

    def get_lookthrough_summary(self, df: pd.DataFrame, top_n: int = 5) -> dict:
        """
        Get summary of look-through positions.

        Args:
            df: DataFrame from calculate_lookthrough()
            top_n: Number of top holdings to include

        Returns:
            Dict with keys: top_holdings, total_positions, concentration
        """
        if df is None or df.empty:
            return {
                "top_holdings": [],
                "total_positions": 0,
                "concentration_top5": 0.0,
            }

        total_weight = df["weight"].sum()
        top_df = df.head(top_n)

        top_holdings = []
        for _, row in top_df.iterrows():
            top_holdings.append({
                "ticker": row["ticker"],
                "name": row["name"],
                "weight": round(row["weight"], 2),
                "source_etfs": row.get("source_etfs", "")
            })

        concentration = top_df["weight"].sum() / total_weight if total_weight > 0 else 0.0

        return {
            "top_holdings": top_holdings,
            "total_positions": len(df),
            "concentration_top5": round(concentration, 4),
        }

    def calculate_for_model(
        self,
        model_id: str,
        top_n: int = 5,
        force_refresh: bool = False
    ) -> dict:
        """
        Calculate look-through for a model, with caching.

        Args:
            model_id: Full model ID
            top_n: Number of top holdings to include
            force_refresh: If True, bypass cache

        Returns:
            Dict with look-through summary and cache metadata
        """
        cache_key = f"lookthrough:model:{model_id}"

        # Check cache first
        r = self._get_redis()
        if r and not force_refresh:
            try:
                import json
                data = r.get(cache_key)
                if data:
                    result = json.loads(data.decode('utf-8'))
                    result['_from_cache'] = True
                    return result
            except Exception:
                pass

        # Calculate fresh
        try:
            # Detect universe from model_id
            parts = model_id.split('.')
            if len(parts) >= 4:
                exchange = parts[1]
                universe_map = {
                    'krx': 'kr_stock',
                    'us': 'us_stock',
                    'vnm': 'vn_stock',
                    'id': 'id_stock',
                }
                universe = universe_map.get(exchange, 'kr_stock')
            else:
                universe = 'kr_stock'

            # Load positions
            positions = self._load_positions(model_id)

            if positions.empty:
                return {
                    "top_holdings": [],
                    "total_positions": 0,
                    "concentration_top5": 0.0,
                    "_from_cache": False,
                    "_error": "No positions found"
                }

            # Calculate look-through
            lookthrough_df = self.calculate_lookthrough(positions, universe)
            summary = self.get_lookthrough_summary(lookthrough_df, top_n)
            summary['_from_cache'] = False
            summary['_calculated_at'] = datetime.now().isoformat()

            # Store in cache
            if r:
                try:
                    import json
                    r.setex(cache_key, self.CACHE_TTL, json.dumps(summary).encode('utf-8'))
                except Exception:
                    pass

            return summary

        except Exception as e:
            return {
                "top_holdings": [],
                "total_positions": 0,
                "concentration_top5": 0.0,
                "_from_cache": False,
                "_error": str(e)
            }
