"""OOS (Out-of-Sample) analyzer for Finter backtest framework.

Provides IS/OOS split analysis, walk-forward validation, and rolling Sharpe
decay curves using PortfolioAnalyzer.nav2stats() for metric computation.
"""

from __future__ import annotations

from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from finter.performance.oos_types import (
    OOSReport,
    WalkForwardFold,
    WalkForwardReport,
)
from finter.performance.stats import PortfolioAnalyzer


class OOSAnalyzer:
    """Out-of-Sample performance analyzer.

    Splits NAV series into In-Sample (IS) and Out-of-Sample (OOS) periods
    around a submit date, computing performance degradation metrics.
    """

    # Default OOS window sizes in trading days
    DEFAULT_OOS_WINDOWS = {"3M": 63, "6M": 126, "1Y": 252}

    @staticmethod
    def _compute_metrics(nav_slice: pd.Series) -> Dict[str, float]:
        """Compute standard performance metrics from a NAV slice.

        Args:
            nav_slice: pd.Series with DatetimeIndex representing daily NAV.

        Returns:
            Dict with keys: sharpe, cagr, mdd, volatility.
        """
        if nav_slice is None or len(nav_slice) < 2:
            return {
                "sharpe": np.nan,
                "cagr": np.nan,
                "mdd": np.nan,
                "volatility": np.nan,
            }

        stats = PortfolioAnalyzer.nav2stats(nav_slice)

        return {
            "sharpe": float(stats.get("Sharpe Ratio", np.nan) or np.nan),
            "cagr": float(stats.get("CAGR (%)", np.nan) or np.nan),
            "mdd": float(stats.get("Max Drawdown (%)", np.nan) or np.nan),
            "volatility": float(stats.get("Volatility (%)", np.nan) or np.nan),
        }

    @classmethod
    def analyze(
        cls,
        nav: pd.Series,
        submit_date: int,
        is_window: Optional[int] = None,
        oos_windows: Optional[Dict[str, int]] = None,
    ) -> OOSReport:
        """Analyze IS vs OOS performance around a submit date.

        Args:
            nav: pd.Series with DatetimeIndex, daily NAV values.
            submit_date: Integer in YYYYMMDD format (e.g. 20250615).
            is_window: Optional number of trading days for IS window.
                       If None, uses all data before submit_date.
            oos_windows: Dict mapping label to trading days for OOS windows.
                         Default: {'3M': 63, '6M': 126, '1Y': 252}.

        Returns:
            OOSReport with IS/OOS comparison metrics.
        """
        if oos_windows is None:
            oos_windows = cls.DEFAULT_OOS_WINDOWS

        # Convert submit_date to pd.Timestamp
        submit_ts = pd.Timestamp(str(submit_date))

        # Split into IS and OOS
        is_nav = nav[nav.index < submit_ts]
        oos_nav = nav[nav.index >= submit_ts]

        # Apply IS window if specified
        if is_window is not None and len(is_nav) > is_window:
            is_nav = is_nav.iloc[-is_window:]

        # Compute IS metrics
        is_stats = cls._compute_metrics(is_nav)

        # Compute OOS metrics for each window
        oos_stats: Dict[str, Dict[str, float]] = {}
        largest_window_label = None
        largest_window_size = 0

        for label, days in sorted(oos_windows.items(), key=lambda x: x[1]):
            oos_slice = oos_nav.iloc[:days] if len(oos_nav) > days else oos_nav
            if len(oos_slice) >= 2:
                oos_stats[label] = cls._compute_metrics(oos_slice)
            else:
                oos_stats[label] = {
                    "sharpe": np.nan,
                    "cagr": np.nan,
                    "mdd": np.nan,
                    "volatility": np.nan,
                }
            if days > largest_window_size:
                largest_window_size = days
                largest_window_label = label

        # Compute decay ratio using largest OOS window
        is_sharpe = is_stats["sharpe"]
        if largest_window_label and not np.isnan(is_sharpe) and is_sharpe > 0:
            oos_sharpe = oos_stats[largest_window_label]["sharpe"]
            decay_ratio = oos_sharpe / is_sharpe if not np.isnan(oos_sharpe) else 0.0
        else:
            decay_ratio = 0.0

        # Performance drift (CAGR difference)
        is_cagr = is_stats["cagr"]
        if largest_window_label:
            oos_cagr = oos_stats[largest_window_label]["cagr"]
            performance_drift = (
                oos_cagr - is_cagr
                if not np.isnan(oos_cagr) and not np.isnan(is_cagr)
                else 0.0
            )
        else:
            performance_drift = 0.0

        degradation = 1 - decay_ratio
        is_robust = degradation < 0.3

        # Compute rolling Sharpe over the full NAV
        rolling_sharpe = cls.decay_curve(nav, submit_date)

        return OOSReport(
            submit_date=str(submit_date),
            is_stats=is_stats,
            oos_stats=oos_stats,
            decay_ratio=decay_ratio,
            performance_drift=performance_drift,
            degradation=degradation,
            is_robust=is_robust,
            rolling_sharpe=rolling_sharpe,
        )

    @classmethod
    def walk_forward(
        cls,
        nav: pd.Series,
        train_period: int = 504,
        test_period: int = 126,
        step_size: int = 63,
        expanding: bool = True,
    ) -> WalkForwardReport:
        """Walk-forward validation over a NAV series.

        Args:
            nav: pd.Series with DatetimeIndex, daily NAV values.
            train_period: Number of trading days for training window.
            test_period: Number of trading days for test window.
            step_size: Number of trading days to step forward between folds.
            expanding: If True, training window expands from start.
                       If False, training window is fixed size (rolling).

        Returns:
            WalkForwardReport with fold-level and aggregate metrics.
        """
        n = len(nav)
        folds: List[WalkForwardFold] = []
        fold_number = 0

        # Starting index for the first test period
        start_idx = train_period

        while start_idx + test_period <= n:
            # Define train and test slices
            if expanding:
                train_nav = nav.iloc[:start_idx]
            else:
                train_nav = nav.iloc[start_idx - train_period : start_idx]

            test_nav = nav.iloc[start_idx : start_idx + test_period]

            if len(train_nav) < 2 or len(test_nav) < 2:
                start_idx += step_size
                continue

            # Compute metrics
            train_metrics = cls._compute_metrics(train_nav)
            test_metrics = cls._compute_metrics(test_nav)

            train_sharpe = train_metrics["sharpe"]
            test_sharpe = test_metrics["sharpe"]

            # Compute degradation
            if not np.isnan(train_sharpe) and train_sharpe > 0:
                degradation = 1 - (test_sharpe / train_sharpe) if not np.isnan(test_sharpe) else 1.0
            else:
                degradation = np.nan

            fold_number += 1
            folds.append(
                WalkForwardFold(
                    fold_number=fold_number,
                    train_start=str(train_nav.index[0].date()),
                    train_end=str(train_nav.index[-1].date()),
                    test_start=str(test_nav.index[0].date()),
                    test_end=str(test_nav.index[-1].date()),
                    train_sharpe=train_sharpe if not np.isnan(train_sharpe) else 0.0,
                    test_sharpe=test_sharpe if not np.isnan(test_sharpe) else 0.0,
                    train_cagr=train_metrics["cagr"] if not np.isnan(train_metrics["cagr"]) else 0.0,
                    test_cagr=test_metrics["cagr"] if not np.isnan(test_metrics["cagr"]) else 0.0,
                    degradation=degradation if not np.isnan(degradation) else 0.0,
                )
            )

            start_idx += step_size

        # Aggregate metrics
        if folds:
            avg_train_sharpe = np.mean([f.train_sharpe for f in folds])
            avg_test_sharpe = np.mean([f.test_sharpe for f in folds])
            avg_degradation = np.mean([f.degradation for f in folds])
            consistency_score = sum(1 for f in folds if f.test_sharpe > 0) / len(folds)
        else:
            avg_train_sharpe = 0.0
            avg_test_sharpe = 0.0
            avg_degradation = 0.0
            consistency_score = 0.0

        is_stable = avg_degradation < 0.3

        return WalkForwardReport(
            folds=folds,
            avg_train_sharpe=avg_train_sharpe,
            avg_test_sharpe=avg_test_sharpe,
            avg_degradation=avg_degradation,
            consistency_score=consistency_score,
            is_stable=is_stable,
        )

    @staticmethod
    def decay_curve(
        nav: pd.Series,
        submit_date: int,
        rolling_window: int = 126,
    ) -> pd.Series:
        """Compute rolling Sharpe ratio curve over the NAV series.

        Args:
            nav: pd.Series with DatetimeIndex, daily NAV values.
            submit_date: Integer in YYYYMMDD format (for reference, not used in calc).
            rolling_window: Number of trading days for rolling window (default 126 = ~6M).

        Returns:
            pd.Series with DatetimeIndex, rolling annualized Sharpe ratio values.
        """
        daily_returns = nav.pct_change().dropna()

        if len(daily_returns) < rolling_window:
            return pd.Series(dtype=float)

        def _annualized_sharpe(x: pd.Series) -> float:
            std = x.std()
            if std > 0:
                return x.mean() / std * np.sqrt(252)
            return 0.0

        rolling_sharpe = daily_returns.rolling(rolling_window).apply(
            _annualized_sharpe, raw=False
        )

        return rolling_sharpe.dropna()

    @classmethod
    def analyze_from_nav(
        cls,
        nav: pd.Series,
        submit_date: int,
        is_window: Optional[int] = None,
        oos_windows: Optional[Dict[str, int]] = None,
        rolling_window: int = 126,
    ) -> OOSReport:
        """Convenience method: analyze IS/OOS from a NAV series.

        Same as analyze() but allows overriding rolling_window for the decay curve.

        Args:
            nav: pd.Series with DatetimeIndex, daily NAV values.
            submit_date: Integer in YYYYMMDD format.
            is_window: Optional IS window in trading days.
            oos_windows: Dict mapping label to trading days for OOS windows.
            rolling_window: Rolling window for Sharpe decay curve.

        Returns:
            OOSReport with IS/OOS comparison metrics.
        """
        report = cls.analyze(
            nav=nav,
            submit_date=submit_date,
            is_window=is_window,
            oos_windows=oos_windows,
        )

        # Re-compute rolling sharpe with custom window if different from default
        if rolling_window != 126:
            report.rolling_sharpe = cls.decay_curve(nav, submit_date, rolling_window)

        return report
