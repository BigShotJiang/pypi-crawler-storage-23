"""OOS (Out-of-Sample) analysis data types for Finter backtest framework."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import pandas as pd


@dataclass
class OOSReport:
    """Report containing IS (In-Sample) vs OOS (Out-of-Sample) performance comparison."""

    submit_date: str  # YYYYMMDD format
    is_stats: Dict[str, float]  # Sharpe, CAGR, MDD, Volatility for IS window
    oos_stats: Dict[
        str, Dict[str, float]
    ]  # Same metrics for each OOS window (keyed by window size)
    decay_ratio: float  # primary oos_sharpe / is_sharpe (using largest OOS window)
    performance_drift: float  # oos_cagr - is_cagr
    degradation: float  # 1 - decay_ratio
    is_robust: bool  # degradation < 0.3
    rolling_sharpe: Optional[pd.DataFrame] = None  # date -> sharpe time series

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        result = {
            "submit_date": self.submit_date,
            "is_stats": self.is_stats,
            "oos_stats": self.oos_stats,
            "decay_ratio": round(self.decay_ratio, 4),
            "performance_drift": round(self.performance_drift, 4),
            "degradation": round(self.degradation, 4),
            "is_robust": self.is_robust,
        }
        if self.rolling_sharpe is not None:
            result["rolling_sharpe"] = [
                {"date": str(idx)[:10], "sharpe": round(float(val), 4)}
                for idx, val in self.rolling_sharpe.items()
                if pd.notna(val)
            ]
        return result


@dataclass
class WalkForwardFold:
    """Single fold in walk-forward validation."""

    fold_number: int
    train_start: str
    train_end: str
    test_start: str
    test_end: str
    train_sharpe: float
    test_sharpe: float
    train_cagr: float
    test_cagr: float
    degradation: float  # 1 - (test_sharpe / train_sharpe) if train_sharpe > 0


@dataclass
class WalkForwardReport:
    """Walk-forward validation report with multiple folds."""

    folds: List[WalkForwardFold]
    avg_train_sharpe: float
    avg_test_sharpe: float
    avg_degradation: float
    consistency_score: float  # % of folds where test Sharpe > 0
    is_stable: bool  # avg_degradation < 0.3

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "folds": [
                {
                    "fold": f.fold_number,
                    "train_period": f"{f.train_start}-{f.train_end}",
                    "test_period": f"{f.test_start}-{f.test_end}",
                    "train_sharpe": round(f.train_sharpe, 4),
                    "test_sharpe": round(f.test_sharpe, 4),
                    "degradation": round(f.degradation, 4),
                }
                for f in self.folds
            ],
            "avg_train_sharpe": round(self.avg_train_sharpe, 4),
            "avg_test_sharpe": round(self.avg_test_sharpe, 4),
            "avg_degradation": round(self.avg_degradation, 4),
            "consistency_score": round(self.consistency_score, 4),
            "is_stable": self.is_stable,
        }
