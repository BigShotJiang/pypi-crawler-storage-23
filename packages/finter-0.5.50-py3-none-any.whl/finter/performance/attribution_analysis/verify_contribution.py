"""
Verification script: compare total return from AttributionAnalyzer vs ContributionAnalyzer.

The portfolio total return must be exactly the same regardless of which analyzer is used,
since the portfolio side of the computation is identical — only the benchmark differs.
"""

from finter.performance.attribution_analysis import (
    AttributionConfig,
    AttributionAnalyzer,
    ContributionAnalyzer,
)


def verify_total_return(
    portfolio_id: str,
    benchmark_id: str,
    universe: str = "us_stock",
    start: str = "20240101",
    end: str = "20241231",
):
    """Run both analyzers and compare port_return."""
    factory = (
        AttributionConfig.us_stock if universe == "us_stock"
        else AttributionConfig.kr_stock
    )

    # --- Attribution Analyzer (normal) ---
    config_attr = factory(
        benchmark_id=benchmark_id,
        portfolio_id=portfolio_id,
        start=start,
        end=end,
        model="carino",
        freq="Q",
    )
    attr_analyzer = AttributionAnalyzer(config_attr, verbose=True)
    attr_analyzer.load_data(use_parallel=False)
    attr_result = attr_analyzer.run()

    # --- Contribution Analyzer (cash benchmark) ---
    config_contrib = factory(
        benchmark_id=benchmark_id,  # ignored by ContributionAnalyzer
        portfolio_id=portfolio_id,
        start=start,
        end=end,
        model="carino",
        freq="Q",
    )
    contrib_analyzer = ContributionAnalyzer(config_contrib, verbose=True)
    contrib_analyzer.load_data(use_parallel=False)
    contrib_result = contrib_analyzer.run()

    # --- Compare ---
    print("\n" + "=" * 60)
    print("VERIFICATION: AttributionAnalyzer vs ContributionAnalyzer")
    print("=" * 60)
    print(f"Attribution  port_return: {attr_result.port_return:.10f}")
    print(f"Contribution port_return: {contrib_result.port_return:.10f}")
    print(f"Difference:               {abs(attr_result.port_return - contrib_result.port_return):.2e}")
    print()
    print(f"Attribution  bm_return:   {attr_result.bm_return:.10f}")
    print(f"Contribution bm_return:   {contrib_result.bm_return:.10f} (should be ~0.0)")
    print()
    print(f"Contribution excess_return = port_return? "
          f"{abs(contrib_result.relative_return - contrib_result.port_return) < 1e-10}")
    print("=" * 60)

    assert abs(attr_result.port_return - contrib_result.port_return) < 1e-8, \
        f"Port return mismatch! attr={attr_result.port_return}, contrib={contrib_result.port_return}"

    print("PASSED: port_return matches between both analyzers.")
    return attr_result, contrib_result


if __name__ == "__main__":
    verify_total_return(
        portfolio_id="meta_fund.us.compustat.stock.US_EQUITY",
        benchmark_id="content.quantit.compustat_cm.universe.proxy_spx_mktcap.1d",
        universe="us_stock",
        start="20240101",
        end="20241231",
    )
