import pandas as pd
import time
from typing import Optional

from .attribution_analyzer import AttributionAnalyzer, AttributionResult
from .config import AttributionConfig
from .data_loader import DataLoader


class ContributionAnalyzer(AttributionAnalyzer):
    """
    Contribution analysis engine derived from AttributionAnalyzer.

    Sets the benchmark to a 100% cash portfolio, so the attribution
    decomposition shows how each sector/stock contributed to the total
    portfolio return rather than comparing against a market benchmark.

    Skips loading actual benchmark holdings in load_data(), saving time.
    The benchmark_id in config is ignored.
    """

    def __init__(self, config: AttributionConfig, data_loader: Optional[DataLoader] = None, verbose: bool = False):
        # Force drop_cash=False: can't drop cash from an all-cash benchmark
        config.drop_cash = False
        super().__init__(config, data_loader=data_loader, verbose=verbose)

    def load_data(
        self,
        use_parallel: bool = False,
        convert_etf: bool = False,
    ) -> 'ContributionAnalyzer':
        """
        Load portfolio data and construct an all-cash benchmark.

        Skips loading actual benchmark holdings — instead creates a synthetic
        100% cash benchmark using the portfolio's date structure. This saves
        the time that would be spent loading benchmark data.
        """
        cfg = self.config
        ucfg = cfg.universe
        dcfg = cfg.dates
        t_total = time.time()

        # Load portfolio holdings only (skip benchmark)
        t0 = time.time()
        self._port_holdings = self.loader.load_holdings(
            cfg.portfolio_id, max_weight=cfg.max_weight,
            convert_etf=convert_etf,
        )
        if self.verbose:
            print(f"[Port] load_holdings: {time.time() - t0:.2f}s")
            print(f"[Step 1] Portfolio holdings loaded: {time.time() - t0:.2f}s")

        # Add next date
        self._port_holdings = self.loader.add_next_date(self._port_holdings)

        # Trim to date range
        start_dt = pd.to_datetime(dcfg.start, format='%Y%m%d')
        end_dt = pd.to_datetime(dcfg.end, format='%Y%m%d')

        self._port_holdings = self._port_holdings[
            (self._port_holdings[ucfg.date_col] >= start_dt) &
            (self._port_holdings[ucfg.date_col] <= end_dt)
        ]
        self._port_holdings = self._port_holdings[
            self._port_holdings[ucfg.next_date_col] <= end_dt
        ]

        # Create all-cash benchmark from portfolio date structure
        self._bm_holdings = self._make_cash_benchmark()

        # Collect security IDs from portfolio only (excluding cash)
        total_sec_ids = list(
            set(self._port_holdings[ucfg.id_col].unique()) - {ucfg.cash_id}
        )
        total_entity_ids = list(
            set(self._port_holdings[ucfg.entity_col].unique()) - {ucfg.cash_id}
        )

        # Load TRI and sector data
        t0 = time.time()
        if use_parallel:
            self._df_tri, self._df_sector = self.loader.load_data_parallel(
                total_sec_ids, total_entity_ids
            )
        else:
            self._df_tri = self.loader.load_tri_data(total_sec_ids)
            self._df_sector = self.loader.load_sector_data(total_entity_ids)
        if self.verbose:
            print(f"[Step 2] TRI & Sector loaded: {time.time() - t0:.2f}s")
            print(f"[Total] load_data: {time.time() - t_total:.2f}s")

        return self

    def _make_cash_benchmark(self) -> pd.DataFrame:
        """Construct a 100% cash benchmark from portfolio date structure."""
        ucfg = self.config.universe
        port = self._port_holdings
        dates_df = port[[ucfg.date_col, ucfg.next_date_col]].drop_duplicates()
        cash_bm = dates_df.copy()
        cash_bm[ucfg.id_col] = ucfg.cash_id
        cash_bm[ucfg.weight_col] = 1.0
        cash_bm['cum_' + ucfg.weight_col] = 1.0
        cash_bm['num_holdings'] = 1
        if ucfg.entity_col != ucfg.id_col:
            cash_bm[ucfg.entity_col] = ucfg.cash_id
        return cash_bm.reset_index(drop=True)
