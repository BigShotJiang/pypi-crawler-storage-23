"""
KR EMP (ETF Model Portfolio) to Equity Portfolio Converter

This module provides a class to convert Korean ETF-based portfolios into their
underlying equity positions using ETF PDF (Portfolio Disclosure File) data
from FnGuide.
"""

import pandas as pd
import numpy as np
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass
from tqdm import tqdm
from datetime import timedelta

from finter.modeling import DateConverter
from finter.data import IdTable, QuandaIceberg, ContentFactory

@dataclass
class EMPConversionResult:
    """Result of EMP to Equity conversion"""
    equity_position: pd.DataFrame  # Converted equity position (date x ccid)
    missing_etfs: List[int]  # ETF ccids with no PDF data
    coverage_stats: Dict  # Statistics about conversion coverage


class KR_EMP_2_Equity:
    """
    Converts Korean EMP (ETF Model Portfolio) positions to underlying equity positions.

    This class takes Korean ETF-level portfolio positions and decomposes them into
    their constituent equity holdings using FnGuide ETF PDF (Portfolio Disclosure File) data.
    Only applicable to kr_stock universe.

    Example:
        >>> converter = KR_EMP_2_Equity()
        >>> result = converter.convert(etf_position_df)
        >>> equity_portfolio = result.equity_position
    """

    def __init__(
        self,
        id_table_vendor: str = 'quantit',
        scale: float = 1e8,
        verbose: bool = True
    ):
        """
        Initialize the converter.

        Args:
            id_table_vendor: Vendor name for IdTable lookup (default: 'quantit')
            scale: Position scale factor (default: 1e8 for finter standard)
            verbose: Whether to print progress messages
        """
        self.etf_table_vendor = id_table_vendor
        self.scale = scale
        self.verbose = verbose

        self._etf_table: Optional[pd.DataFrame] = None
        self._db_engine = None
        self._valid_etf: Optional[pd.DataFrame] = None
        self._kospi200_constituents: Optional[pd.DataFrame] = None
        self._kospi200_cache_key: Optional[Tuple[int, int]] = None

        self.df_fnguide = IdTable('fnguide').get_stock()
        self.df_stock = IdTable(id_table_vendor).get_stock()
        self.df_stock = self.df_stock.dropna(subset=['short_code', 'ccid'])
        self.df_stock = self.df_stock[self.df_stock['instrument_id'].isin([1,2])]
        self.df_stock['stk_cd'] = self.df_stock['short_code'].str.replace('A','')

        # In-memory cache for PDF data: {ccid: DataFrame}
        self.pdf_cache: Dict[int, Optional[pd.DataFrame]] = {}


    @property
    def etf_table(self) -> pd.DataFrame:
        """Lazy load and cache ETF table (instrument_id == 3)"""
        if self._etf_table is None:
            df_id = IdTable(self.etf_table_vendor).get_stock()
            df_etf = df_id[df_id['instrument_id'] == 3].copy()
            df_etf = df_etf.dropna(subset=['short_code'])
            df_etf['etf_cd'] = df_etf['short_code'].str.replace('A', '', regex=False)
            df_etf = df_etf.rename(columns={'ccid': 'etf_ccid'})
            self._etf_table = df_etf
        return self._etf_table

    @property
    def db_engine(self):
        """Lazy load database engine"""
        if self._db_engine is None:
            self._db_engine = QuandaIceberg()
        return self._db_engine

    @property
    def valid_etf(self) -> pd.DataFrame:
        """Lazy load valid ETF info (Korean equity ETFs excluding US/Europe markets)"""
        if self._valid_etf is None:
            query = """
            SELECT * FROM fnguide.TS_ETF_INFO
            WHERE idx_comm_id_l = '주식'
            AND idx_comm_id_m != '시장대표'
            AND idx_mkt_id_m NOT IN ('북미', '유럽')
            """
            self._valid_etf = ((self.db_engine.query(query))
                               .merge(self.etf_table[['etf_cd','etf_ccid']], how='inner', on=['etf_cd']))
        return self._valid_etf

    def get_kospi200_constituents(self, start: int = 20050101, end: int = 20251231, shift: int = 1) -> pd.DataFrame:
        """
        Get KODEX 200 (KOSPI 200) constituents in wide format.

        Args:
            start: Start date (YYYYMMDD)
            end: End date (YYYYMMDD)

        Returns:
            DataFrame with index=date, columns=ccid, values=weight
        """
        cache_key = (start, end)
        if self._kospi200_constituents is None or self._kospi200_cache_key != cache_key:
            cf_kr = ContentFactory("kr_stock", start, end)
            cf_raw = ContentFactory("raw", cf_kr.start, cf_kr.end)

            df = cf_raw.get_df("content.quantit.fnguide_cm.universe.kodex200.1d")
            df = df.ffill(limit=3).shift(shift).reindex(cf_kr.trading_days)

            # Remove columns where max value is 0 or NaN
            valid_cols = df.max() > 0
            df = df.loc[:, valid_cols]

            self._kospi200_constituents = df
            self._kospi200_cache_key = cache_key
        return self._kospi200_constituents

    def get_etf_code(self, ccid: int) -> Optional[str]:
        """Get ETF code from ccid"""
        matched = self.etf_table[self.etf_table['etf_ccid'] == ccid]
        if len(matched) == 0:
            return None
        return matched['etf_cd'].values[0]

    def get_ccid_from_stk_cd(self, stk_cd: str) -> Optional[int]:
        """Get ccid from stock code"""
        from finter.data import IdTable
        df_stock = IdTable(self.etf_table_vendor).get_stock()

        # Clean stk_cd (remove leading zeros for matching)
        stk_cd_clean = str(stk_cd).lstrip('0')

        # Try different matching strategies
        for code_col in ['short_code', 'ticker']:
            if code_col in df_stock.columns:
                matched = df_stock[
                    df_stock[code_col].astype(str).str.replace('A', '', regex=False) == stk_cd_clean
                ]
                if len(matched) > 0:
                    return matched['ccid'].values[0]

        return None

    def clear_cache(self):
        """Clear all cached PDF data"""
        self.pdf_cache.clear()
        if self.verbose:
            print("Cleared in-memory PDF cache")

    def fetch_etf_pdf(
        self,
        etf_ccids: List[int],
        start_date: str,
        end_date: str,
        shift_pdf: int=2
    ) -> Tuple[pd.DataFrame, List[int]]:
        """
        Fetch ETF PDF data for given ETFs.
        Uses in-memory cache (self.pdf_cache) to avoid redundant queries.

        Args:
            etf_ccids: List of ETF ccids
            start_date: Start date in YYYYMMDD format
            end_date: End date in YYYYMMDD format

        Returns:
            Tuple of (pdf_dataframe, list_of_missing_ccids)
        """
        pdf_chunks = []
        missing_ccids = []

        # Separate cached vs uncached ccids
        cached_ccids = [c for c in etf_ccids if c in self.pdf_cache]
        uncached_ccids = [c for c in etf_ccids if c not in self.pdf_cache]

        # Use cached data
        for ccid in cached_ccids:
            cached_df = self.pdf_cache[ccid]
            if cached_df is not None and not cached_df.empty:
                # Filter by date range
                mask = (cached_df['trd_dt'] >= start_date) & (cached_df['trd_dt'] <= end_date)
                filtered = cached_df[mask].copy()
                if not filtered.empty:
                    pdf_chunks.append(filtered)
            else:
                missing_ccids.append(ccid)

        if self.verbose and cached_ccids:
            print(f"Using cached PDF data for {len(cached_ccids)} ETFs")

        # Fetch uncached data
        if uncached_ccids:
            iterator = tqdm(uncached_ccids, desc="Fetching ETF PDF") if self.verbose else uncached_ccids

            for ccid in iterator:
                etf_cd = self.get_etf_code(ccid)

                if etf_cd is None:
                    if self.verbose:
                        print(f"\nETF_CD not found for CCID {ccid}")
                    self.pdf_cache[ccid] = None  # Cache as missing
                    missing_ccids.append(ccid)
                    continue

                query = f"""
                    SELECT * FROM fnguide.ts_etf_pdf
                    WHERE etf_cd='{etf_cd}'
                    AND trd_dt >= '{start_date}'
                    AND trd_dt <= '{end_date}'
                """

                pdf = self.db_engine.query(query)

                if pdf.empty:
                    if self.verbose:
                        etf_info = self.etf_table[self.etf_table['etf_ccid'] == ccid]
                        if len(etf_info) > 0:
                            print(f"\nNo PDF data for: {etf_info[['etf_ccid', 'entity_name']].values[0]}")
                    self.pdf_cache[ccid] = None  # Cache as missing
                    missing_ccids.append(ccid)
                    continue

                pdf['etf_weight'] = pdf['etf_weight'].astype(float)
                pdf = pdf[pdf['etf_weight']>0.0] # remove unnecessary rows
                pdf['etf_ccid'] = ccid

                # Store in cache
                self.pdf_cache[ccid] = pdf.copy()
                pdf_chunks.append(pdf)

        if not pdf_chunks:
            df_pdf = pd.DataFrame()
        else:
            df_pdf = pd.concat(pdf_chunks, axis=0)
            # Filter to date range
            df_pdf = df_pdf[(df_pdf['trd_dt'] >= start_date) & (df_pdf['trd_dt'] <= end_date)]
            df_pdf['date'] = pd.to_datetime(df_pdf['trd_dt'], format='%Y%m%d')

            # add next trd_dt
            cf_kr = ContentFactory('kr_stock', start_date, end_date)
            trading_days = cf_kr.trading_days
            df_days = pd.DataFrame({
                'date': trading_days[:-shift_pdf],
                'next_date': trading_days[shift_pdf:]
            })
            df_days = df_days.dropna()
            df_days['date'] = pd.to_datetime(df_days['date'])
            df_days['next_date'] = pd.to_datetime(df_days['next_date'])
            len_pdf = len(df_pdf)
            df_pdf = df_pdf.merge(df_days, on='date', how='left')
            assert len_pdf == len(df_pdf), f"Something went wrong on merging next date! {len_pdf}, {len(df_pdf)}"

        return df_pdf, missing_ccids

    def convert(
        self,
        emp_position: pd.DataFrame,
        normalize: bool = True,
        map_to_ccid: bool = True,
        kospi200_only: bool = False,
    ) -> EMPConversionResult:
        """
        Convert EMP position to equity position.

        Args:
            emp_position: DataFrame with datetime index and ETF ccid columns,
                         values are position weights (scaled by self.scale)
            normalize: Whether to normalize final weights to sum to scale
            map_to_ccid: Whether to map stock codes to ccids (slower but gives ccid columns)
            kospi200_only: Whether to filter equity positions to only KOSPI 200 constituents

        Returns:
            EMPConversionResult containing:
                - equity_position: DataFrame with equity positions
                - missing_etfs: List of ETF ccids with no PDF data
                - coverage_stats: Dictionary with conversion statistics
        """
        if self.verbose:
            print("[1/5] Preparing input data...")

        # Ensure datetime index
        if not isinstance(emp_position.index, pd.DatetimeIndex):
            emp_position.index = pd.to_datetime(emp_position.index)

        # Get date range
        start_date = emp_position.index[0].strftime("%Y%m%d")
        end_date = emp_position.index[-1].strftime("%Y%m%d")
        lookback_days = 21
        lookforward_days = 21
        data_start = DateConverter.get_pre_start(start_date, lookback_days)
        data_end = DateConverter.get_pre_start(end_date, -lookforward_days)
        data_start = str(data_start)
        data_end = str(data_end)

        # Get unique ETF ccids
        etf_ccids = [int(c) for c in emp_position.columns]

        if self.verbose:
            print(f"      - Date range: {start_date} ~ {end_date}")
            print(f"      - Data Date range: {data_start} ~ {data_end}")
            print(f"      - ETF count: {len(etf_ccids)}")
            print(f"      - Position shape: {emp_position.shape}")
            print(f"[2/5] Fetching ETF PDF data...")

        # Fetch PDF data
        df_pdf, missing_ccids = self.fetch_etf_pdf(etf_ccids, data_start, data_end)

        if df_pdf.empty:
            if self.verbose:
                print("[!] No PDF data found. Returning empty result.")
            return EMPConversionResult(
                equity_position=pd.DataFrame(),
                missing_etfs=missing_ccids,
                coverage_stats={'coverage_ratio': 0.0}
            )

        if self.verbose:
            print(f"      - PDF records: {len(df_pdf):,}")
            print(f"      - Missing ETFs: {len(missing_ccids)}")
            print("[3/5] Merging EMP positions with ETF holdings...")

        # Melt EMP position to long format
        df_pos = emp_position.copy()
        df_pos.index.name = 'date'
        df_pos = df_pos / self.scale  # Normalize to weights
        df_pos = df_pos.reset_index().melt(
            id_vars=['date'],
            var_name='ccid',
            value_name='weight_lev0'
        )
        df_pos['ccid'] = df_pos['ccid'].astype(int)
        df_pos = df_pos[df_pos['weight_lev0'] > 0.0]

        if self.verbose:
            print(f"      - EMP records (non-zero): {len(df_pos):,}")

        # Merge with PDF data
        df_merged = df_pos.merge(
            df_pdf[['stk_cd', 'etf_ccid', 'stk_nm_kor', 'etf_weight', 'next_date']],
            how='inner',
            left_on=['date', 'ccid'],
            right_on=['next_date', 'etf_ccid']
        )
        df_merged = df_merged.drop(columns=['ccid'])

        # Calculate effective weight (EMP weight * ETF constituent weight)
        df_merged['effective_weight'] = df_merged['weight_lev0'] * df_merged['etf_weight']

        if self.verbose:
            print(f"      - Merged records: {len(df_merged):,}")
            print(f"      - Unique stocks: {df_merged['stk_cd'].nunique():,}")
            print("[4/5] Aggregating equity positions...")

        self.df_merged = df_merged

        # Aggregate by date and stock code
        if map_to_ccid:
            # Map stock codes to ccids
            df_merged = df_merged.merge(self.df_stock[['ccid', 'stk_cd']], how='inner', on=['stk_cd'])
            df_merged = df_merged.rename(columns={'ccid':'equity_ccid'})
            group_col = 'equity_ccid'
        else:
            group_col = 'stk_cd'

        pos_agg = df_merged.groupby(['date', group_col], as_index=False)['effective_weight'].sum()

        # Pivot to wide format
        equity_position = pos_agg.pivot(
            index='date',
            columns=group_col,
            values='effective_weight'
        ).fillna(0.0)

        # Filter to KOSPI 200 constituents if requested
        if kospi200_only and map_to_ccid:
            kospi200_df = self.get_kospi200_constituents(start=int(start_date), end=int(end_date), shift=2)
            kospi200_ccids = kospi200_df.columns.tolist()
            valid_cols = equity_position.columns.intersection(kospi200_ccids)
            equity_position = equity_position[valid_cols]
            if self.verbose:
                print(f"      - Filtered to KOSPI 200: {len(valid_cols)} stocks")

        # Normalize if requested
        if normalize:
            row_sums = equity_position.sum(axis=1)
            equity_position = equity_position.divide(row_sums, axis=0) * self.scale
        else:
            equity_position = equity_position * self.scale

        if self.verbose:
            print(f"      - Output shape: {equity_position.shape}")
            print("[5/5] Calculating coverage statistics...")

        # Calculate coverage statistics
        total_etf_weight = df_pos.groupby('date')['weight_lev0'].sum()
        covered_etf_weight = df_pos[~df_pos['ccid'].isin(missing_ccids)].groupby('date')['weight_lev0'].sum()
        avg_coverage = (covered_etf_weight / total_etf_weight).mean() if len(total_etf_weight) > 0 else 0

        coverage_stats = {
            'total_etfs': len(etf_ccids),
            'missing_etfs': len(missing_ccids),
            'covered_etfs': len(etf_ccids) - len(missing_ccids),
            'avg_coverage_ratio': float(avg_coverage),
            'num_equities': len(equity_position.columns),
            'date_range': (start_date, end_date)
        }

        if self.verbose:
            print(f"\n=== Conversion Summary ===")
            print(f"Total ETFs: {coverage_stats['total_etfs']}")
            print(f"Covered ETFs: {coverage_stats['covered_etfs']}")
            print(f"Missing ETFs: {coverage_stats['missing_etfs']}")
            print(f"Average Coverage: {coverage_stats['avg_coverage_ratio']:.1%}")
            print(f"Resulting Equities: {coverage_stats['num_equities']}")

        return EMPConversionResult(
            equity_position=equity_position,
            missing_etfs=missing_ccids,
            coverage_stats=coverage_stats
        )

    def validate_conversion(
        self,
        emp_position: pd.DataFrame,
        equity_position: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Validate that converted equity position weights sum correctly.

        Args:
            emp_position: Original EMP position
            equity_position: Converted equity position

        Returns:
            DataFrame with validation statistics per date
        """
        emp_sum = emp_position.sum(axis=1)
        equity_sum = equity_position.sum(axis=1)

        validation = pd.DataFrame({
            'emp_sum': emp_sum,
            'equity_sum': equity_sum,
            'diff': emp_sum - equity_sum,
            'diff_pct': (emp_sum - equity_sum) / emp_sum * 100
        })

        return validation

    def get_kodex200_constituents(
        self,
        start: int = 20050101,
        end: int = 20251231,
        format: str = 'long',
        ffill: int = 3
    ) -> pd.DataFrame:
        """
        Load KODEX 200 (KOSPI 200) constituent stocks using ContentFactory.

        Args:
            start: Start date in YYYYMMDD format (int)
            end: End date in YYYYMMDD format (int)
            format: Output format - 'long' or 'wide'
                - 'long': DataFrame with columns [trading_day, ccid, weight]
                - 'wide': DataFrame with index=date, columns=ccid, values=weight

        Returns:
            DataFrame with KODEX 200 constituent weights
        """
        cf_kr = ContentFactory("kr_stock", start, end)
        cf_raw = ContentFactory("raw", cf_kr.start, cf_kr.end)

        # Load KODEX 200 constituents
        df_kospi200 = cf_raw.get_df("content.quantit.fnguide_cm.universe.kodex200.1d")
        df_kospi200 = df_kospi200.ffill(limit=ffill).reindex(cf_kr.trading_days)

        # Remove columns where max value is 0 or NaN
        valid_cols = df_kospi200.max() > 0
        df_kospi200 = df_kospi200.loc[:, valid_cols]

        if format == 'wide':
            return df_kospi200

        # Convert to long format
        df_kospi200 = (
            df_kospi200
            .reset_index()
            .melt(id_vars='index', var_name='ccid', value_name='weight')
            .rename(columns={'index': 'trading_day'})
            .dropna(subset=['weight'])
        )
        df_kospi200['ccid'] = df_kospi200['ccid'].astype(int)

        return df_kospi200
