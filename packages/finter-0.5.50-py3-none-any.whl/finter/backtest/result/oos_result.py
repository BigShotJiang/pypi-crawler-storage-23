"""OOS Backtest Result — wraps IS and OOS BacktestResult objects."""

from __future__ import annotations

from typing import Dict

import pandas as pd

from finter.backtest.result.main import BacktestResult


class OOSBacktestResult:
    """Extended backtest result with IS/OOS split analysis.

    Wraps two BacktestResult objects (IS and OOS) along with decay metrics
    computed from the split, providing combined views for comparison.
    """

    def __init__(
        self,
        is_result: BacktestResult,
        oos_result: BacktestResult,
        submit_date: int,
        decay_metrics: Dict[str, float],
    ):
        self.is_result = is_result
        self.oos_result = oos_result
        self.submit_date = submit_date
        self.decay_metrics = decay_metrics

    @property
    def combined_summary(self) -> pd.DataFrame:
        """Full NAV series with IS/OOS labels."""
        is_summary = self.is_result.summary.copy()
        is_summary["period"] = "IS"
        oos_summary = self.oos_result.summary.copy()
        oos_summary["period"] = "OOS"
        return pd.concat([is_summary, oos_summary])

    @property
    def combined_statistics(self) -> pd.DataFrame:
        """Side-by-side IS vs OOS statistics."""
        is_stats = self.is_result.statistics.rename("IS")
        oos_stats = self.oos_result.statistics.rename("OOS")
        combined = pd.concat([is_stats, oos_stats], axis=1)
        combined["Drift"] = combined["OOS"] - combined["IS"]
        return combined
