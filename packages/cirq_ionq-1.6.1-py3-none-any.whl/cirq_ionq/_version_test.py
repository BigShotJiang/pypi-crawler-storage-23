# pylint: disable=wrong-or-nonexistent-copyright-notice
import cirq_ionq


def test_version():
    assert cirq_ionq.__version__ == "1.6.1"
