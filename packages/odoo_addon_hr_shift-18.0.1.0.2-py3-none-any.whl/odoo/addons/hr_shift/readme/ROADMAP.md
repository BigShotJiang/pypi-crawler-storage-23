- We can use the *Reviewed* field for more purposes, like setting the planning state
  when all the shifts are reviewed.
- Support working pauses.
