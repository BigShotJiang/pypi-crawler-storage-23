"""OpenAI automation module for Codex GitHub Mentions processing."""

__all__ = ["codex_github_mentions"]
