"""CLI tool for querying SolarWinds Observability logs."""

__version__ = "2.0.0"
