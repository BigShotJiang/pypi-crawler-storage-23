"""Core logic for Gremlin."""
