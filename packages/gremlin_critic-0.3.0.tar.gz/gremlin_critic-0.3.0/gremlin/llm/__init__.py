"""LLM integration for Gremlin."""
