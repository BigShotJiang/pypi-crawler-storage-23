import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Rectangle
from .utils import validate_dataframe
from .indicators import moving_average, rsi


def plot_chart(
    df,
    ma_windows=(20, 50),
    show_rsi=True,
    dark=False,
    save_path=None
):

    df = validate_dataframe(df)
    dates = np.arange(len(df))

    if dark:
        plt.style.use("dark_background")

    fig = plt.figure(figsize=(14, 10))

    if show_rsi:
        gs = fig.add_gridspec(3, 1, height_ratios=[3, 1, 1])
        ax_price = fig.add_subplot(gs[0])
        ax_volume = fig.add_subplot(gs[1], sharex=ax_price)
        ax_rsi = fig.add_subplot(gs[2], sharex=ax_price)
    else:
        gs = fig.add_gridspec(2, 1, height_ratios=[3, 1])
        ax_price = fig.add_subplot(gs[0])
        ax_volume = fig.add_subplot(gs[1], sharex=ax_price)
        ax_rsi = None

    # Candlesticks
    for i in range(len(df)):
        open_ = df["Open"].iloc[i]
        close = df["Close"].iloc[i]
        high = df["High"].iloc[i]
        low = df["Low"].iloc[i]

        color = "green" if close >= open_ else "red"

        ax_price.plot([dates[i], dates[i]], [low, high])

        rect = Rectangle(
            (dates[i] - 0.3, min(open_, close)),
            0.6,
            abs(close - open_),
            facecolor=color
        )

        ax_price.add_patch(rect)

    # Moving Averages
    for window in ma_windows:
        ma = moving_average(df["Close"], window)
        ax_price.plot(dates, ma, label=f"MA{window}")

    ax_price.legend()
    ax_price.set_title("stmrtpy Stock Chart")

    # Volume
    ax_volume.bar(dates, df["Volume"])

    # RSI
    if show_rsi:
        rsi_values = rsi(df["Close"])
        ax_rsi.plot(dates, rsi_values)
        ax_rsi.axhline(70)
        ax_rsi.axhline(30)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path)

    plt.show()