import os

from dotenv import load_dotenv

from artificer import AgentDispatcher
from planka_backend import PlankaBackend

load_dotenv()


dispatcher = AgentDispatcher(
    command="claude",
    poll_interval=30,
    agent_timeout=1800,
    max_concurrent_agents=1,
    max_retries=3,
    api_host="0.0.0.0",
    api_port=8000,
    queue_backend=PlankaBackend(
        url="http://localhost:3000",
        username=os.getenv("PLANKA_USER"),
        password=os.getenv("PLANKA_PASSWORD"),
    )
)


@dispatcher.route(
    args=["--agent", "prompt-engineer", "-p"],
    queue_name="Artificer Dispatcher.Prompt.Todo",
    in_progress_queue="Artificer Dispatcher.Prompt.In Progress",
    priority=4,
)
def prompt_engineer_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


@dispatcher.route(
    args=["--agent", "product-manager", "-p"],
    queue_name="Artificer Dispatcher.Product.Todo",
    in_progress_queue="Artificer Dispatcher.Product.In Progress",
    priority=3,
)
def product_manager_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


@dispatcher.route(
    args=["--agent", "architect", "-p"],
    queue_name="Artificer Dispatcher.Architecture.Todo",
    in_progress_queue="Artificer Dispatcher.Architecture.In Progress",
    priority=2,
)
def architect_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


@dispatcher.route(
    args=["--agent", "software-engineer", "-p"],
    queue_name="Artificer Dispatcher.Engineering.Todo",
    in_progress_queue="Artificer Dispatcher.Engineering.In Progress",
    priority=1,
)
def software_engineer_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


@dispatcher.route(
    args=["--agent", "qa-engineer", "-p"],
    queue_name="Artificer Dispatcher.QA.Todo",
    in_progress_queue="Artificer Dispatcher.QA.In Progress",
    priority=0,
)
def qa_engineer_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


@dispatcher.route(
    args=["--agent", "research", "-p"],
    queue_name="Artificer Dispatcher.Research.Todo",
    in_progress_queue="Artificer Dispatcher.Research In Progress",
    priority=5,
)
def research_agent(task_id: str, task_name: str) -> str:
    return f"Work on task {task_id}: {task_name}."


if __name__ == "__main__":
    dispatcher.run(debug=True)
