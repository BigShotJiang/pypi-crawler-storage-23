from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from artificer.adapters.base import TaskAdapter
    from artificer.agents.base import AgentAdapter

log = logging.getLogger(__name__)


class AgentDispatcher:
    """Library entry point that wires config, adapter, router, and HTTP server.

    Use this class to configure and run the dispatcher programmatically
    with a Flask-style ``@route()`` decorator API.

    Args:
        command: The base command to run for all routes (e.g. ``"claude"``).
        poll_interval: Seconds between polls (default: 30).
        agent_timeout: Default timeout in seconds for all agents (default: no timeout).
        max_concurrent_agents: Maximum concurrent agent processes (default: 3).
        max_retries: Default max retry attempts for failed/timed-out agents (default: 0).
        dead_letter_queue: Default queue for tasks that exhaust all retries.
        api_host: HTTP API bind address (default: ``"127.0.0.1"``).
        api_port: HTTP API port (default: 8000).
        queue_backend: A ``TaskAdapter`` instance (or any object with a
                       ``create_adapter()`` method). If ``None``, must be
                       set before calling ``run()``.
        agent_adapters: Optional mapping of command name → ``AgentAdapter``.
        enable_queue_management: Whether to enable queue CRUD HTTP endpoints.
    """

    def __init__(
        self,
        command: str,
        *,
        poll_interval: int = 30,
        agent_timeout: int | None = None,
        max_concurrent_agents: int = 3,
        max_retries: int = 0,
        dead_letter_queue: str | None = None,
        api_host: str = "127.0.0.1",
        api_port: int = 8000,
        queue_backend: TaskAdapter | None = None,
        agent_adapters: dict[str, AgentAdapter] | None = None,
        enable_queue_management: bool = False,
    ) -> None:
        self._command = command
        self._poll_interval = poll_interval
        self._agent_timeout = agent_timeout
        self._max_concurrent_agents = max_concurrent_agents
        self._max_retries = max_retries
        self._dead_letter_queue = dead_letter_queue
        self._api_host = api_host
        self._api_port = api_port
        self._queue_backend = queue_backend
        self._agent_adapters = agent_adapters
        self._enable_queue_management = enable_queue_management
        self._routes: list = []

    def route(
        self,
        *,
        queue_name: str,
        in_progress_queue: str = "In Progress",
        args: list[str] | None = None,
        timeout: int | None = None,
        poll_interval: int | None = None,
        priority: int | None = None,
        max_retries: int | None = None,
        dead_letter_queue: str | None = None,
    ) -> Callable:
        """Register a route via a decorator.

        The decorated function receives ``(task_id, task_name)`` and returns
        a prompt string that is appended to the command arguments.
        """
        from artificer.config import RouteConfig

        def decorator(fn: Callable[[str, str], str]) -> Callable[[str, str], str]:
            route_config = RouteConfig(
                queue_name=queue_name,
                command=self._command,
                args=args or [],
                in_progress_queue=in_progress_queue,
                timeout=timeout,
                poll_interval=poll_interval,
                priority=priority,
                max_retries=max_retries,
                dead_letter_queue=dead_letter_queue,
                prompt_fn=fn,
            )
            self._routes.append(route_config)
            return fn

        return decorator

    def _resolve_adapter(self) -> TaskAdapter:
        """Resolve queue_backend into a TaskAdapter."""
        from artificer.adapters.base import TaskAdapter as TaskAdapterProtocol

        backend = self._queue_backend
        if backend is None:
            raise ValueError(
                "No queue_backend configured. Pass a TaskAdapter (or an object "
                "with a create_adapter() method) to the AgentDispatcher constructor."
            )

        # Check if it has a create_adapter method (e.g. PlankaBackend)
        if hasattr(backend, "create_adapter"):
            return backend.create_adapter()

        # Otherwise assume it's already a TaskAdapter
        return backend

    def run(self, *, debug: bool = False) -> None:
        """Start the dispatcher (blocking).

        Runs the polling loop and HTTP API. Calls ``asyncio.run()``
        internally and handles ``KeyboardInterrupt`` gracefully.

        Use :meth:`run_async` if you already have a running event loop.

        Args:
            debug: If ``True``, configure root logging to ``DEBUG`` level
                   before starting. Defaults to ``False`` (``INFO`` level).
        """
        import logging as _logging

        _logging.basicConfig(
            level=_logging.DEBUG if debug else _logging.INFO,
            format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        )
        try:
            asyncio.run(self.run_async())
        except KeyboardInterrupt:
            log.info("Interrupted, exiting")

    async def run_async(self) -> None:
        """Start the dispatcher within an existing event loop.

        Same as :meth:`run` but does not call ``asyncio.run()``. Use this
        when integrating the dispatcher into an existing async application.
        """
        import uvicorn

        from artificer.http_api import create_app as create_rest_app
        from artificer.router import Router

        adapter = self._resolve_adapter()

        router = Router(
            adapter,
            routes=list(self._routes),
            poll_interval=self._poll_interval,
            max_concurrent_agents=self._max_concurrent_agents,
            default_agent_timeout=self._agent_timeout,
            default_max_retries=self._max_retries,
            default_dead_letter_queue=self._dead_letter_queue,
            agent_adapters=self._agent_adapters,
        )
        rest_app = create_rest_app(
            adapter,
            router,
            enable_queue_management=self._enable_queue_management,
        )

        uvicorn_config = uvicorn.Config(
            rest_app,
            host=self._api_host,
            port=self._api_port,
            log_level="info",
        )
        server = uvicorn.Server(uvicorn_config)

        loop = asyncio.get_running_loop()
        server_future = loop.run_in_executor(None, server.run)

        router_task = asyncio.create_task(router.run())

        log.info(
            "Started: HTTP API on %s:%d, polling every %ds",
            self._api_host,
            self._api_port,
            self._poll_interval,
        )

        done, pending = await asyncio.wait(
            [server_future, router_task],
            return_when=asyncio.FIRST_COMPLETED,
        )

        for task in pending:
            task.cancel()
        for task in done:
            if task.exception():
                log.error("Task failed: %s", task.exception())
