from __future__ import annotations

import json
from collections.abc import Sequence
from datetime import datetime, timezone
from pathlib import Path

from artificer.adapters.base import Queue, Task, TaskComment


class JsonFileAdapter:
    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)

    def _read(self) -> dict:
        return json.loads(self._path.read_text())

    def _write(self, data: dict) -> None:
        self._path.write_text(json.dumps(data, indent=2))

    def _find_task_data(self, data: dict, task_id: str) -> tuple[str, int, dict]:
        for queue_name, tasks in data["queues"].items():
            for i, task in enumerate(tasks):
                if task["id"] == task_id:
                    return queue_name, i, task
        raise KeyError(f"Task not found: {task_id}")

    def get_ready_tasks(self, queue_names: Sequence[str]) -> list[Task]:
        data = self._read()
        tasks = []
        for name in queue_names:
            for task_data in data["queues"].get(name, []):
                tasks.append(self._to_task(task_data, source_queue=name))
        return tasks

    def get_task(self, task_id: str) -> Task:
        data = self._read()
        queue_name, _, task_data = self._find_task_data(data, task_id)
        return self._to_task(task_data, source_queue=queue_name)

    def move_task(self, task_id: str, target_queue: str) -> None:
        data = self._read()
        if target_queue not in data["queues"]:
            raise KeyError(f"Target queue not found: {target_queue!r}")
        queue_name, idx, task_data = self._find_task_data(data, task_id)
        data["queues"][queue_name].pop(idx)
        data["queues"][target_queue].append(task_data)
        self._write(data)

    def add_comment(self, task_id: str, text: str) -> None:
        data = self._read()
        _, _, task_data = self._find_task_data(data, task_id)
        if "comments" not in task_data:
            task_data["comments"] = []
        task_data["comments"].append(
            {
                "author": "system",
                "text": text,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
        )
        self._write(data)

    def create_task(self, queue_name: str, name: str, description: str = "") -> Task:
        data = self._read()
        if queue_name not in data["queues"]:
            raise KeyError(f"Target queue not found: {queue_name!r}")
        all_ids = [
            int(t["id"])
            for tasks in data["queues"].values()
            for t in tasks
            if t["id"].isdigit()
        ]
        new_id = str(max(all_ids, default=0) + 1)
        task_data = {
            "id": new_id,
            "name": name,
            "description": description,
            "labels": [],
            "assignees": [],
            "comments": [],
            "tasks": [],
        }
        data["queues"][queue_name].append(task_data)
        self._write(data)
        return self._to_task(task_data, source_queue=queue_name)

    def update_task(
        self,
        task_id: str,
        *,
        assignees: list[str] | None = None,
        name: str | None = None,
        description: str | None = None,
        labels: list[str] | None = None,
        retry_count: int | None = None,
    ) -> None:
        data = self._read()
        _, _, task_data = self._find_task_data(data, task_id)

        if name is not None:
            task_data["name"] = name

        if description is not None:
            task_data["description"] = description

        if assignees is not None:
            task_data["assignees"] = [
                "system" if a == "me" else a for a in assignees
            ]

        if labels is not None:
            task_data["labels"] = labels

        if retry_count is not None:
            task_data["retry_count"] = retry_count

        self._write(data)

    def list_queues(self) -> list[Queue]:
        data = self._read()
        return [
            Queue(name=name, task_count=len(tasks))
            for name, tasks in data["queues"].items()
        ]

    def get_queue(self, queue_name: str) -> Queue:
        data = self._read()
        if queue_name not in data["queues"]:
            raise KeyError(f"Queue not found: {queue_name!r}")
        return Queue(name=queue_name, task_count=len(data["queues"][queue_name]))

    def create_queue(self, queue_name: str) -> Queue:
        data = self._read()
        if queue_name in data["queues"]:
            raise ValueError(f"Queue already exists: {queue_name!r}")
        data["queues"][queue_name] = []
        self._write(data)
        return Queue(name=queue_name, task_count=0)

    def update_queue(self, queue_name: str, *, new_name: str | None = None) -> Queue:
        data = self._read()
        if queue_name not in data["queues"]:
            raise KeyError(f"Queue not found: {queue_name!r}")
        if new_name is not None:
            if new_name in data["queues"]:
                raise ValueError(f"Queue already exists: {new_name!r}")
            data["queues"][new_name] = data["queues"].pop(queue_name)
            self._write(data)
            return Queue(name=new_name, task_count=len(data["queues"][new_name]))
        return Queue(name=queue_name, task_count=len(data["queues"][queue_name]))

    def delete_queue(self, queue_name: str) -> None:
        data = self._read()
        if queue_name not in data["queues"]:
            raise KeyError(f"Queue not found: {queue_name!r}")
        if data["queues"][queue_name]:
            raise ValueError(f"Queue is not empty: {queue_name!r}")
        del data["queues"][queue_name]
        self._write(data)

    def _to_task(self, data: dict, source_queue: str = "") -> Task:
        description = data.get("description", "")
        checklist_lines = []
        for t in data.get("tasks", []):
            mark = "x" if t.get("is_completed", False) else " "
            checklist_lines.append(f"- [{mark}] {t['name']}")
        if checklist_lines:
            suffix = "\n\n## Checklist\n" + "\n".join(checklist_lines)
            description = (description + suffix) if description else suffix.lstrip("\n")
        comments = [
            TaskComment(
                author=c.get("author", "unknown"),
                text=c["text"],
                created_at=c.get("created_at", ""),
            )
            for c in data.get("comments", [])
        ]
        return Task(
            id=data["id"],
            name=data["name"],
            description=description,
            url=data.get("url", ""),
            source_queue=source_queue,
            labels=data.get("labels", []),
            assignees=data.get("assignees", []),
            comments=comments,
            retry_count=data.get("retry_count", 0),
        )
