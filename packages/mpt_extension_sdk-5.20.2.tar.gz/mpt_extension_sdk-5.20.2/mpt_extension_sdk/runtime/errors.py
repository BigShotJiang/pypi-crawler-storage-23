# Custom exception for variable format errors


class VariableNotWellFormedError(Exception):
    """Raised when a variable is not well-formed."""
