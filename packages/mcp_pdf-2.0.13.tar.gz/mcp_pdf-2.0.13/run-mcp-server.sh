#!/bin/bash
# MCP PDF Tools Server Launcher
# This script provides an easy way to run the MCP server

cd "$(dirname "$0")"
exec uv run mcp-pdf-tools