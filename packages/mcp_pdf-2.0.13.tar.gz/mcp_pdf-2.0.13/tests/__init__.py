"""Tests package for MCP PDF Tools"""
