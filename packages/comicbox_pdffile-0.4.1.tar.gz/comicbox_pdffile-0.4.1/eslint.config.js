import baseConfig from "./cfg/eslint.config.js";

export default [...baseConfig];
