from __future__ import annotations

from exstruct.mcp.patch import internal as _internal

PatchOpError = _internal.PatchOpError

__all__ = ["PatchOpError"]
