"""Shared test fixtures for oakscriptpy tests."""

import pytest
from oakscriptpy._types import Bar


@pytest.fixture
def sample_bars() -> list[Bar]:
    """20 bars of sample OHLCV data."""
    return [
        Bar(time=1, open=10.0, high=12.0, low=9.0, close=11.0, volume=100.0),
        Bar(time=2, open=11.0, high=13.0, low=10.0, close=12.0, volume=110.0),
        Bar(time=3, open=12.0, high=14.0, low=11.0, close=13.0, volume=120.0),
        Bar(time=4, open=13.0, high=15.0, low=12.0, close=14.0, volume=130.0),
        Bar(time=5, open=14.0, high=16.0, low=13.0, close=15.0, volume=140.0),
        Bar(time=6, open=15.0, high=17.0, low=14.0, close=14.5, volume=150.0),
        Bar(time=7, open=14.5, high=16.0, low=13.5, close=14.0, volume=160.0),
        Bar(time=8, open=14.0, high=15.5, low=13.0, close=13.5, volume=170.0),
        Bar(time=9, open=13.5, high=15.0, low=12.5, close=13.0, volume=180.0),
        Bar(time=10, open=13.0, high=14.5, low=12.0, close=12.5, volume=190.0),
        Bar(time=11, open=12.5, high=14.0, low=11.5, close=13.0, volume=200.0),
        Bar(time=12, open=13.0, high=14.5, low=12.0, close=14.0, volume=210.0),
        Bar(time=13, open=14.0, high=15.5, low=13.0, close=15.0, volume=220.0),
        Bar(time=14, open=15.0, high=16.5, low=14.0, close=16.0, volume=230.0),
        Bar(time=15, open=16.0, high=17.5, low=15.0, close=17.0, volume=240.0),
        Bar(time=16, open=17.0, high=18.5, low=16.0, close=18.0, volume=250.0),
        Bar(time=17, open=18.0, high=19.5, low=17.0, close=19.0, volume=260.0),
        Bar(time=18, open=19.0, high=20.0, low=18.0, close=19.5, volume=270.0),
        Bar(time=19, open=19.5, high=20.5, low=18.5, close=20.0, volume=280.0),
        Bar(time=20, open=20.0, high=21.0, low=19.0, close=20.5, volume=290.0),
    ]
