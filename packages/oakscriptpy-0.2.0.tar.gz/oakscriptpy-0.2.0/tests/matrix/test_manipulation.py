"""Tests for matrix manipulation functions — ported from manipulation.test.ts."""

import math

import pytest

from oakscriptpy import matrix


# ==========================================
# Row/Column Operations
# ==========================================


class TestAddRow:
    def test_should_add_row_at_end_by_default(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.add_row(m)

        assert matrix.rows(m) == 3
        assert matrix.columns(m) == 3
        assert matrix.row(m, 2) == [None, None, None]

    def test_should_add_row_at_specified_index(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 0, 2)

        matrix.add_row(m, 1)

        assert matrix.rows(m) == 3
        assert matrix.row(m, 0) == [1, 0, 0]
        assert matrix.row(m, 1) == [None, None, None]
        assert matrix.row(m, 2) == [2, 0, 0]

    def test_should_add_array_as_row(self):
        m = matrix.new_matrix(2, 3, 0)
        arr = [1, 2, 3]

        matrix.add_row(m, 0, arr)

        assert matrix.rows(m) == 3
        assert matrix.row(m, 0) == [1, 2, 3]

    def test_should_add_array_to_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        arr = [1, 2]

        matrix.add_row(m, 0, arr)

        assert matrix.rows(m) == 1
        assert matrix.columns(m) == 2
        assert matrix.row(m, 0) == [1, 2]

    def test_should_raise_error_for_mismatched_array_size(self):
        m = matrix.new_matrix(2, 3, 0)
        arr = [1, 2]  # Wrong size

        with pytest.raises(ValueError, match="does not match"):
            matrix.add_row(m, 0, arr)

    def test_should_raise_error_for_out_of_bounds_index(self):
        m = matrix.new_matrix(2, 3, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.add_row(m, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.add_row(m, -1)


class TestAddCol:
    def test_should_add_column_at_end_by_default(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.add_col(m)

        assert matrix.rows(m) == 2
        assert matrix.columns(m) == 4
        assert matrix.col(m, 3) == [None, None]

    def test_should_add_column_at_specified_index(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)

        matrix.add_col(m, 1)

        assert matrix.columns(m) == 4
        assert matrix.row(m, 0) == [1, None, 2, 0]

    def test_should_add_array_as_column(self):
        m = matrix.new_matrix(2, 3, 0)
        arr = [1, 2]

        matrix.add_col(m, 0, arr)

        assert matrix.columns(m) == 4
        assert matrix.col(m, 0) == [1, 2]

    def test_should_add_array_to_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)
        arr = [1, 3]

        matrix.add_col(m, 0, arr)

        assert matrix.rows(m) == 2
        assert matrix.columns(m) == 1
        assert matrix.col(m, 0) == [1, 3]

    def test_should_raise_error_for_mismatched_array_size(self):
        m = matrix.new_matrix(2, 3, 0)
        arr = [1, 2, 3]  # Wrong size

        with pytest.raises(ValueError, match="does not match"):
            matrix.add_col(m, 0, arr)


class TestRemoveRow:
    def test_should_remove_last_row_by_default(self):
        m = matrix.new_matrix(2, 2, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        removed = matrix.remove_row(m)

        assert matrix.rows(m) == 1
        assert removed == [3, 4]

    def test_should_remove_row_at_specified_index(self):
        m = matrix.new_matrix(2, 2, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        removed = matrix.remove_row(m, 0)

        assert matrix.rows(m) == 1
        assert removed == [1, 2]
        assert matrix.row(m, 0) == [3, 4]

    def test_should_raise_error_for_out_of_bounds_index(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.remove_row(m, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.remove_row(m, -1)


class TestRemoveCol:
    def test_should_remove_last_column_by_default(self):
        m = matrix.new_matrix(2, 2, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        removed = matrix.remove_col(m)

        assert matrix.columns(m) == 1
        assert removed == [2, 4]

    def test_should_remove_column_at_specified_index(self):
        m = matrix.new_matrix(2, 2, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        removed = matrix.remove_col(m, 0)

        assert matrix.columns(m) == 1
        assert removed == [1, 3]
        assert matrix.col(m, 0) == [2, 4]

    def test_should_raise_error_for_out_of_bounds_index(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.remove_col(m, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.remove_col(m, -1)


class TestSwapRows:
    def test_should_swap_two_rows(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)
        matrix.set(m, 2, 0, 5)
        matrix.set(m, 2, 1, 6)

        matrix.swap_rows(m, 0, 1)

        assert matrix.row(m, 0) == [3, 4]
        assert matrix.row(m, 1) == [1, 2]
        assert matrix.row(m, 2) == [5, 6]

    def test_should_handle_swapping_same_row(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)

        matrix.swap_rows(m, 0, 0)

        assert matrix.row(m, 0) == [1, 2]

    def test_should_raise_error_for_out_of_bounds_indices(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.swap_rows(m, 0, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.swap_rows(m, -1, 0)


class TestSwapColumns:
    def test_should_swap_two_columns(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)

        matrix.swap_columns(m, 0, 2)

        assert matrix.col(m, 0) == [3, 6]
        assert matrix.col(m, 1) == [2, 5]
        assert matrix.col(m, 2) == [1, 4]

    def test_should_raise_error_for_out_of_bounds_indices(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.swap_columns(m, 0, 5)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.swap_columns(m, -1, 0)


# ==========================================
# Matrix Transformations
# ==========================================


class TestTranspose:
    def test_should_transpose_a_matrix(self):
        m1 = matrix.new_matrix(2, 3, 0)
        matrix.set(m1, 0, 0, 1)
        matrix.set(m1, 0, 1, 2)
        matrix.set(m1, 0, 2, 3)
        matrix.set(m1, 1, 0, 4)
        matrix.set(m1, 1, 1, 5)
        matrix.set(m1, 1, 2, 6)

        m2 = matrix.transpose(m1)

        assert matrix.rows(m2) == 3
        assert matrix.columns(m2) == 2
        assert matrix.row(m2, 0) == [1, 4]
        assert matrix.row(m2, 1) == [2, 5]
        assert matrix.row(m2, 2) == [3, 6]

    def test_should_transpose_a_square_matrix(self):
        m1 = matrix.new_matrix(2, 2, 0)
        matrix.set(m1, 0, 0, 1)
        matrix.set(m1, 0, 1, 2)
        matrix.set(m1, 1, 0, 3)
        matrix.set(m1, 1, 1, 4)

        m2 = matrix.transpose(m1)

        assert matrix.get(m2, 0, 1) == 3
        assert matrix.get(m2, 1, 0) == 2

    def test_should_handle_empty_matrix(self):
        m1 = matrix.new_matrix(0, 0, 0)
        m2 = matrix.transpose(m1)

        assert matrix.rows(m2) == 0
        assert matrix.columns(m2) == 0

    def test_should_not_modify_original_matrix(self):
        m1 = matrix.new_matrix(2, 3, 1)
        m2 = matrix.transpose(m1)

        matrix.set(m2, 0, 0, 99)

        assert matrix.get(m1, 0, 0) == 1


class TestConcat:
    def test_should_concatenate_two_matrices_vertically(self):
        m1 = matrix.new_matrix(2, 4, 0)
        m2 = matrix.new_matrix(2, 4, 1)

        matrix.concat(m1, m2)

        assert matrix.rows(m1) == 4
        assert matrix.columns(m1) == 4
        assert matrix.row(m1, 0) == [0, 0, 0, 0]
        assert matrix.row(m1, 2) == [1, 1, 1, 1]

    def test_should_raise_error_for_column_mismatch(self):
        m1 = matrix.new_matrix(2, 3, 0)
        m2 = matrix.new_matrix(2, 4, 1)

        with pytest.raises(ValueError, match="Column count mismatch"):
            matrix.concat(m1, m2)

    def test_should_return_the_modified_first_matrix(self):
        m1 = matrix.new_matrix(1, 2, 0)
        m2 = matrix.new_matrix(1, 2, 1)

        result = matrix.concat(m1, m2)

        assert result is m1


class TestSubmatrix:
    def test_should_extract_a_submatrix(self):
        m1 = matrix.new_matrix(2, 3, 0)
        matrix.set(m1, 0, 0, 1)
        matrix.set(m1, 0, 1, 2)
        matrix.set(m1, 0, 2, 3)
        matrix.set(m1, 1, 0, 4)
        matrix.set(m1, 1, 1, 5)
        matrix.set(m1, 1, 2, 6)

        m2 = matrix.submatrix(m1, 0, 2, 1, 3)

        assert matrix.rows(m2) == 2
        assert matrix.columns(m2) == 2
        assert matrix.row(m2, 0) == [2, 3]
        assert matrix.row(m2, 1) == [5, 6]

    def test_should_use_defaults_for_full_matrix(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.submatrix(m1)

        assert matrix.rows(m2) == 2
        assert matrix.columns(m2) == 2

    def test_should_return_independent_copy(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.submatrix(m1)

        matrix.set(m2, 0, 0, 99)

        assert matrix.get(m1, 0, 0) == 1

    def test_should_raise_error_for_invalid_indices(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.submatrix(m, -1)
        with pytest.raises(ValueError, match="out of bounds"):
            matrix.submatrix(m, 0, 5)


class TestReshape:
    def test_should_reshape_a_matrix(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)

        matrix.reshape(m, 3, 2)

        assert matrix.rows(m) == 3
        assert matrix.columns(m) == 2
        assert matrix.row(m, 0) == [1, 2]
        assert matrix.row(m, 1) == [3, 4]
        assert matrix.row(m, 2) == [5, 6]

    def test_should_reshape_to_single_row(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        matrix.reshape(m, 1, 4)

        assert matrix.row(m, 0) == [1, 2, 3, 4]

    def test_should_raise_error_for_element_count_mismatch(self):
        m = matrix.new_matrix(2, 3, 0)

        with pytest.raises(ValueError, match="Cannot reshape"):
            matrix.reshape(m, 2, 2)


class TestReverse:
    def test_should_reverse_rows_and_columns(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        matrix.reverse(m)

        assert matrix.row(m, 0) == [4, 3]
        assert matrix.row(m, 1) == [2, 1]

    def test_should_reverse_a_3x2_matrix(self):
        m = matrix.new_matrix(3, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)
        matrix.set(m, 2, 0, 5)
        matrix.set(m, 2, 1, 6)

        matrix.reverse(m)

        assert matrix.row(m, 0) == [6, 5]
        assert matrix.row(m, 1) == [4, 3]
        assert matrix.row(m, 2) == [2, 1]


class TestSort:
    def test_should_sort_by_first_column_ascending_by_default(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 3)
        matrix.set(m, 0, 1, 4)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, 2)

        matrix.sort(m)

        assert matrix.row(m, 0) == [1, 2]
        assert matrix.row(m, 1) == [3, 4]

    def test_should_sort_by_specified_column(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 3)
        matrix.set(m, 0, 1, 1)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, 4)

        matrix.sort(m, 1)

        assert matrix.row(m, 0) == [3, 1]
        assert matrix.row(m, 1) == [1, 4]

    def test_should_sort_descending(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        matrix.sort(m, 0, "descending")

        assert matrix.row(m, 0) == [3, 4]
        assert matrix.row(m, 1) == [1, 2]

    def test_should_raise_error_for_invalid_column(self):
        m = matrix.new_matrix(2, 2, 0)

        with pytest.raises(ValueError, match="out of bounds"):
            matrix.sort(m, 5)


# ==========================================
# Element-wise Arithmetic
# ==========================================


class TestSum:
    def test_should_add_two_matrices_element_wise(self):
        m1 = matrix.new_matrix(2, 3, 5)
        m2 = matrix.new_matrix(2, 3, 4)

        m3 = matrix.sum(m1, m2)

        assert matrix.get(m3, 0, 0) == 9
        assert matrix.get(m3, 1, 2) == 9

    def test_should_add_scalar_to_matrix(self):
        m1 = matrix.new_matrix(2, 3, 4)

        m2 = matrix.sum(m1, 1)

        assert matrix.get(m2, 0, 0) == 5
        assert matrix.get(m2, 1, 2) == 5

    def test_should_raise_error_for_dimension_mismatch(self):
        m1 = matrix.new_matrix(2, 3, 0)
        m2 = matrix.new_matrix(3, 2, 0)

        with pytest.raises(ValueError, match="dimensions must match"):
            matrix.sum(m1, m2)

    def test_should_not_modify_original_matrices(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.new_matrix(2, 2, 2)

        m3 = matrix.sum(m1, m2)
        matrix.set(m3, 0, 0, 99)

        assert matrix.get(m1, 0, 0) == 1
        assert matrix.get(m2, 0, 0) == 2


class TestDiff:
    def test_should_subtract_two_matrices_element_wise(self):
        m1 = matrix.new_matrix(2, 3, 5)
        m2 = matrix.new_matrix(2, 3, 4)

        m3 = matrix.diff(m1, m2)

        assert matrix.get(m3, 0, 0) == 1
        assert matrix.get(m3, 1, 2) == 1

    def test_should_subtract_scalar_from_matrix(self):
        m1 = matrix.new_matrix(2, 3, 4)

        m2 = matrix.diff(m1, 1)

        assert matrix.get(m2, 0, 0) == 3
        assert matrix.get(m2, 1, 2) == 3

    def test_should_raise_error_for_dimension_mismatch(self):
        m1 = matrix.new_matrix(2, 3, 0)
        m2 = matrix.new_matrix(3, 2, 0)

        with pytest.raises(ValueError, match="dimensions must match"):
            matrix.diff(m1, m2)


# ==========================================
# Statistical Functions
# ==========================================


class TestAvg:
    def test_should_calculate_average_of_all_elements(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.avg(m) == 2.5

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert math.isnan(matrix.avg(m))

    def test_should_ignore_nan_values(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, float("nan"))
        matrix.set(m, 1, 1, 3)

        assert matrix.avg(m) == 2  # (1+2+3) / 3


class TestMin:
    def test_should_return_minimum_element(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.min(m) == 1

    def test_should_handle_negative_numbers(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, -5)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.min(m) == -5

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert math.isnan(matrix.min(m))


class TestMax:
    def test_should_return_maximum_element(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.max(m) == 4

    def test_should_handle_negative_numbers(self):
        m = matrix.new_matrix(2, 2, -5)
        matrix.set(m, 1, 1, -1)

        assert matrix.max(m) == -1

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert math.isnan(matrix.max(m))


class TestMedian:
    def test_should_return_median_for_odd_count(self):
        m = matrix.new_matrix(1, 5, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 0, 3, 4)
        matrix.set(m, 0, 4, 5)

        assert matrix.median(m) == 3

    def test_should_return_median_for_even_count(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.median(m) == 2.5

    def test_should_handle_unsorted_values(self):
        m = matrix.new_matrix(1, 3, 0)
        matrix.set(m, 0, 0, 5)
        matrix.set(m, 0, 1, 1)
        matrix.set(m, 0, 2, 9)

        assert matrix.median(m) == 5

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert math.isnan(matrix.median(m))


class TestMode:
    def test_should_return_most_frequent_value(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 1, 2, 1)

        assert matrix.mode(m) == 2

    def test_should_return_smallest_value_on_tie(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 0)
        matrix.set(m, 0, 1, 0)
        matrix.set(m, 1, 0, 1)
        matrix.set(m, 1, 1, 1)

        assert matrix.mode(m) == 0

    def test_should_handle_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert math.isnan(matrix.mode(m))


class TestTrace:
    def test_should_return_sum_of_diagonal_elements(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.trace(m) == 5  # 1 + 4

    def test_should_work_for_3x3_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 2, 3)

        assert matrix.trace(m) == 6

    def test_should_raise_error_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        with pytest.raises(ValueError, match="must be square"):
            matrix.trace(m)

    def test_should_return_0_for_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert matrix.trace(m) == 0


# ==========================================
# Boolean Checks
# ==========================================


class TestIsDiagonal:
    def test_should_return_true_for_diagonal_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 2, 3)

        assert matrix.is_diagonal(m) is True

    def test_should_return_true_for_zero_matrix(self):
        m = matrix.new_matrix(3, 3, 0)

        assert matrix.is_diagonal(m) is True

    def test_should_return_false_for_non_diagonal(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)  # Off-diagonal element

        assert matrix.is_diagonal(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_diagonal(m) is False


class TestIsIdentity:
    def test_should_return_true_for_identity_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 1)
        matrix.set(m, 2, 2, 1)

        assert matrix.is_identity(m) is True

    def test_should_return_false_for_diagonal_matrix_with_non_1_values(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 2)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 2, 2)

        assert matrix.is_identity(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_identity(m) is False


class TestIsSymmetric:
    def test_should_return_true_for_symmetric_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 1, 1, 4)
        matrix.set(m, 1, 2, 5)
        matrix.set(m, 2, 0, 3)
        matrix.set(m, 2, 1, 5)
        matrix.set(m, 2, 2, 6)

        assert matrix.is_symmetric(m) is True

    def test_should_return_true_for_diagonal_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 2, 3)

        assert matrix.is_symmetric(m) is True

    def test_should_return_false_for_non_symmetric_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 1, 0, 3)
        matrix.set(m, 1, 1, 4)

        assert matrix.is_symmetric(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_symmetric(m) is False


class TestIsAntisymmetric:
    def test_should_return_true_for_antisymmetric_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, -1)
        matrix.set(m, 1, 0, -2)
        matrix.set(m, 1, 2, 3)
        matrix.set(m, 2, 0, 1)
        matrix.set(m, 2, 1, -3)

        assert matrix.is_antisymmetric(m) is True

    def test_should_return_true_for_zero_matrix(self):
        m = matrix.new_matrix(3, 3, 0)

        assert matrix.is_antisymmetric(m) is True

    def test_should_return_false_when_diagonal_is_not_zero(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 1)

        assert matrix.is_antisymmetric(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_antisymmetric(m) is False


class TestIsTriangular:
    def test_should_return_true_for_upper_triangular_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 1, 4)
        matrix.set(m, 1, 2, 5)
        matrix.set(m, 2, 2, 6)

        assert matrix.is_triangular(m) is True

    def test_should_return_true_for_lower_triangular_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 0, 2)
        matrix.set(m, 1, 1, 3)
        matrix.set(m, 2, 0, 4)
        matrix.set(m, 2, 1, 5)
        matrix.set(m, 2, 2, 6)

        assert matrix.is_triangular(m) is True

    def test_should_return_true_for_diagonal_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 2, 3)

        assert matrix.is_triangular(m) is True

    def test_should_return_false_for_non_triangular_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 2, 2)
        matrix.set(m, 2, 0, 3)
        matrix.set(m, 2, 2, 4)

        assert matrix.is_triangular(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_triangular(m) is False


class TestIsAntidiagonal:
    def test_should_return_true_for_antidiagonal_matrix(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 2, 1)
        matrix.set(m, 1, 1, 2)
        matrix.set(m, 2, 0, 3)

        assert matrix.is_antidiagonal(m) is True

    def test_should_return_true_for_zero_matrix(self):
        m = matrix.new_matrix(3, 3, 0)

        assert matrix.is_antidiagonal(m) is True

    def test_should_return_false_when_non_antidiagonal_element_is_non_zero(self):
        m = matrix.new_matrix(3, 3, 0)
        matrix.set(m, 0, 0, 1)  # Main diagonal, not antidiagonal

        assert matrix.is_antidiagonal(m) is False

    def test_should_return_false_for_non_square_matrix(self):
        m = matrix.new_matrix(2, 3, 0)

        assert matrix.is_antidiagonal(m) is False


class TestIsStochastic:
    def test_should_return_true_for_stochastic_matrix(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 0.5)
        matrix.set(m, 0, 1, 0.5)
        matrix.set(m, 1, 0, 0.3)
        matrix.set(m, 1, 1, 0.7)

        assert matrix.is_stochastic(m) is True

    def test_should_return_false_for_negative_elements(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, -0.5)
        matrix.set(m, 0, 1, 1.5)
        matrix.set(m, 1, 0, 0.3)
        matrix.set(m, 1, 1, 0.7)

        assert matrix.is_stochastic(m) is False

    def test_should_return_false_when_row_sum_is_not_1(self):
        m = matrix.new_matrix(2, 2, 0)
        matrix.set(m, 0, 0, 0.5)
        matrix.set(m, 0, 1, 0.6)  # Sum = 1.1
        matrix.set(m, 1, 0, 0.3)
        matrix.set(m, 1, 1, 0.7)

        assert matrix.is_stochastic(m) is False

    def test_should_return_false_for_empty_matrix(self):
        m = matrix.new_matrix(0, 0, 0)

        assert matrix.is_stochastic(m) is False

    def test_should_handle_floating_point_precision(self):
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 0.1)
        matrix.set(m, 0, 1, 0.2)
        matrix.set(m, 0, 2, 0.7)
        matrix.set(m, 1, 0, 0.3)
        matrix.set(m, 1, 1, 0.3)
        matrix.set(m, 1, 2, 0.4)

        assert matrix.is_stochastic(m) is True


# ==========================================
# Integration Tests
# ==========================================


class TestManipulationIntegration:
    def test_should_handle_complete_manipulation_workflow(self):
        # Create a 2x3 matrix
        m = matrix.new_matrix(2, 3, 0)
        matrix.set(m, 0, 0, 1)
        matrix.set(m, 0, 1, 2)
        matrix.set(m, 0, 2, 3)
        matrix.set(m, 1, 0, 4)
        matrix.set(m, 1, 1, 5)
        matrix.set(m, 1, 2, 6)

        # Transpose it
        transposed = matrix.transpose(m)
        assert matrix.rows(transposed) == 3
        assert matrix.columns(transposed) == 2

        # Extract a submatrix
        sub = matrix.submatrix(m, 0, 2, 1, 3)
        assert matrix.rows(sub) == 2
        assert matrix.columns(sub) == 2
        assert matrix.row(sub, 0) == [2, 3]

        # Statistics
        assert matrix.avg(m) == 3.5
        assert matrix.min(m) == 1
        assert matrix.max(m) == 6

    def test_should_handle_matrix_arithmetic_workflow(self):
        m1 = matrix.new_matrix(2, 2, 1)
        m2 = matrix.new_matrix(2, 2, 2)

        sum_matrix = matrix.sum(m1, m2)
        assert matrix.get(sum_matrix, 0, 0) == 3

        diff_matrix = matrix.diff(sum_matrix, 1)
        assert matrix.get(diff_matrix, 0, 0) == 2

    def test_should_handle_boolean_checks_workflow(self):
        # Create identity matrix
        identity = matrix.new_matrix(3, 3, 0)
        matrix.set(identity, 0, 0, 1)
        matrix.set(identity, 1, 1, 1)
        matrix.set(identity, 2, 2, 1)

        assert matrix.is_square(identity) is True
        assert matrix.is_diagonal(identity) is True
        assert matrix.is_identity(identity) is True
        assert matrix.is_symmetric(identity) is True
        assert matrix.is_triangular(identity) is True
        assert matrix.trace(identity) == 3
