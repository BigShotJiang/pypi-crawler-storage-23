"""Tests for color manipulation functions: new_color."""

import pytest

from oakscriptpy import color


class TestNewColor:
    def test_set_transparency_on_rgb(self):
        red = color.rgb(255, 0, 0)
        assert color.new_color(red, 50) == "rgba(255, 0, 0, 0.5)"
        assert color.new_color(red, 25) == "rgba(255, 0, 0, 0.75)"
        assert color.new_color(red, 75) == "rgba(255, 0, 0, 0.25)"

    def test_set_transparency_on_rgba(self):
        semi_red = color.rgb(255, 0, 0, 30)
        assert color.new_color(semi_red, 50) == "rgba(255, 0, 0, 0.5)"
        assert color.new_color(semi_red, 0) == "rgb(255, 0, 0)"
        assert color.new_color(semi_red, 100) == "rgba(255, 0, 0, 0.0)"

    def test_0_percent_fully_opaque(self):
        blue = color.rgb(0, 0, 255)
        assert color.new_color(blue, 0) == "rgb(0, 0, 255)"

    def test_100_percent_fully_transparent(self):
        green = color.rgb(0, 255, 0)
        assert color.new_color(green, 100) == "rgba(0, 255, 0, 0.0)"

    def test_preserves_rgb_while_changing_transparency(self):
        purple = color.rgb(128, 0, 128)
        result = color.new_color(purple, 40)
        assert result == "rgba(128, 0, 128, 0.6)"

        # Verify RGB values preserved
        assert color.r(result) == 128
        assert color.g(result) == 0
        assert color.b(result) == 128

    def test_works_with_hex_colors(self):
        orange = color.from_hex("#FFA500")
        assert color.new_color(orange, 50) == "rgba(255, 165, 0, 0.5)"

    def test_various_transparency_values(self):
        white = color.rgb(255, 255, 255)
        assert color.new_color(white, 10) == "rgba(255, 255, 255, 0.9)"

        result_33 = color.new_color(white, 33.33)
        assert "rgba(255, 255, 255," in result_33

        result_67 = color.new_color(white, 66.67)
        assert "rgba(255, 255, 255," in result_67

        # 90% transparency
        result_90 = color.new_color(white, 90)
        assert "rgba(255, 255, 255, 0." in result_90
        assert color.t(result_90) == pytest.approx(90, abs=1)

    def test_black_and_white(self):
        black = color.rgb(0, 0, 0)
        white = color.rgb(255, 255, 255)

        assert color.new_color(black, 50) == "rgba(0, 0, 0, 0.5)"
        assert color.new_color(white, 50) == "rgba(255, 255, 255, 0.5)"

    def test_override_existing_transparency(self):
        semi_transparent = color.rgb(255, 0, 0, 30)  # 30% transparent
        new_transparent = color.new_color(semi_transparent, 70)  # change to 70%

        assert "rgba(255, 0, 0, 0.3" in new_transparent
        assert color.t(new_transparent) == pytest.approx(70, abs=1)

    def test_grayscale_colors(self):
        gray = color.rgb(128, 128, 128)
        assert color.new_color(gray, 25) == "rgba(128, 128, 128, 0.75)"
        assert color.new_color(gray, 75) == "rgba(128, 128, 128, 0.25)"
