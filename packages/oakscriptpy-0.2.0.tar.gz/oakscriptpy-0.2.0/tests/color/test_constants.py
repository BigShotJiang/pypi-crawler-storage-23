"""Tests for color constants."""

from oakscriptpy import color


class TestColorConstants:
    def test_aqua(self):
        assert color.aqua == "#00FFFF"
        assert color.from_hex(color.aqua) == "rgb(0, 255, 255)"

    def test_black(self):
        assert color.black == "#000000"
        assert color.from_hex(color.black) == "rgb(0, 0, 0)"

    def test_blue(self):
        assert color.blue == "#0000FF"
        assert color.from_hex(color.blue) == "rgb(0, 0, 255)"

    def test_fuchsia(self):
        assert color.fuchsia == "#FF00FF"
        assert color.from_hex(color.fuchsia) == "rgb(255, 0, 255)"

    def test_gray(self):
        assert color.gray == "#808080"
        assert color.from_hex(color.gray) == "rgb(128, 128, 128)"

    def test_green(self):
        assert color.green == "#00FF00"
        assert color.from_hex(color.green) == "rgb(0, 255, 0)"

    def test_lime(self):
        assert color.lime == "#00FF00"
        assert color.from_hex(color.lime) == "rgb(0, 255, 0)"

    def test_maroon(self):
        assert color.maroon == "#800000"
        assert color.from_hex(color.maroon) == "rgb(128, 0, 0)"

    def test_navy(self):
        assert color.navy == "#000080"
        assert color.from_hex(color.navy) == "rgb(0, 0, 128)"

    def test_olive(self):
        assert color.olive == "#808000"
        assert color.from_hex(color.olive) == "rgb(128, 128, 0)"

    def test_orange(self):
        assert color.orange == "#FFA500"
        assert color.from_hex(color.orange) == "rgb(255, 165, 0)"

    def test_purple(self):
        assert color.purple == "#800080"
        assert color.from_hex(color.purple) == "rgb(128, 0, 128)"

    def test_red(self):
        assert color.red == "#FF0000"
        assert color.from_hex(color.red) == "rgb(255, 0, 0)"

    def test_silver(self):
        assert color.silver == "#C0C0C0"
        assert color.from_hex(color.silver) == "rgb(192, 192, 192)"

    def test_teal(self):
        assert color.teal == "#008080"
        assert color.from_hex(color.teal) == "rgb(0, 128, 128)"

    def test_white(self):
        assert color.white == "#FFFFFF"
        assert color.from_hex(color.white) == "rgb(255, 255, 255)"

    def test_yellow(self):
        assert color.yellow == "#FFFF00"
        assert color.from_hex(color.yellow) == "rgb(255, 255, 0)"

    def test_lime_and_green_same(self):
        assert color.lime == color.green

    def test_add_transparency_to_constants(self):
        assert color.from_hex(color.red, 50) == "rgba(255, 0, 0, 0.5)"
        assert color.from_hex(color.blue, 25) == "rgba(0, 0, 255, 0.75)"
        assert color.from_hex(color.green, 75) == "rgba(0, 255, 0, 0.25)"

    def test_constants_with_new_color(self):
        red_color = color.from_hex(color.red)
        assert color.new_color(red_color, 40) == "rgba(255, 0, 0, 0.6)"

        blue_color = color.from_hex(color.blue)
        assert color.new_color(blue_color, 60) == "rgba(0, 0, 255, 0.4)"

    def test_extract_components_from_constants(self):
        # Red
        red_color = color.from_hex(color.red)
        assert color.r(red_color) == 255
        assert color.g(red_color) == 0
        assert color.b(red_color) == 0

        # Green
        green_color = color.from_hex(color.green)
        assert color.r(green_color) == 0
        assert color.g(green_color) == 255
        assert color.b(green_color) == 0

        # Blue
        blue_color = color.from_hex(color.blue)
        assert color.r(blue_color) == 0
        assert color.g(blue_color) == 0
        assert color.b(blue_color) == 255

        # Orange
        orange_color = color.from_hex(color.orange)
        assert color.r(orange_color) == 255
        assert color.g(orange_color) == 165
        assert color.b(orange_color) == 0

        # Purple
        purple_color = color.from_hex(color.purple)
        assert color.r(purple_color) == 128
        assert color.g(purple_color) == 0
        assert color.b(purple_color) == 128

        # Gray
        gray_color = color.from_hex(color.gray)
        assert color.r(gray_color) == 128
        assert color.g(gray_color) == 128
        assert color.b(gray_color) == 128
