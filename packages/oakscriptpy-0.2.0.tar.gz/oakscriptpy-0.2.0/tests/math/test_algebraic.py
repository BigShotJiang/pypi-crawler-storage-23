"""Tests for algebraic math functions: sqrt, pow, exp, log, log10."""

import math as pymath

import pytest

from oakscriptpy import math_ as math


# --- math.sqrt ---

class TestSqrt:
    def test_perfect_squares(self):
        assert math.sqrt(4) == 2
        assert math.sqrt(9) == 3
        assert math.sqrt(16) == 4
        assert math.sqrt(25) == 5

    def test_non_perfect_squares(self):
        assert math.sqrt(2) == pytest.approx(1.414213, abs=1e-5)
        assert math.sqrt(3) == pytest.approx(1.732050, abs=1e-5)
        assert math.sqrt(5) == pytest.approx(2.236067, abs=1e-5)

    def test_zero_and_one(self):
        assert math.sqrt(0) == 0
        assert math.sqrt(1) == 1

    def test_decimal_numbers(self):
        assert math.sqrt(0.25) == 0.5
        assert math.sqrt(0.01) == pytest.approx(0.1)

    def test_negative_numbers_raise(self):
        # Python math.sqrt raises ValueError for negative input
        with pytest.raises(ValueError):
            math.sqrt(-1)
        with pytest.raises(ValueError):
            math.sqrt(-4)

    def test_sqrt_x_times_sqrt_x_equals_x(self):
        x = 7
        assert math.sqrt(x) * math.sqrt(x) == pytest.approx(x)


# --- math.pow ---

class TestPow:
    def test_integer_powers(self):
        assert math.pow(2, 3) == 8
        assert math.pow(3, 2) == 9
        assert math.pow(10, 2) == 100
        assert math.pow(5, 3) == 125

    def test_power_of_0(self):
        assert math.pow(5, 0) == 1
        assert math.pow(100, 0) == 1
        assert math.pow(-5, 0) == 1

    def test_power_of_1(self):
        assert math.pow(5, 1) == 5
        assert math.pow(100, 1) == 100

    def test_negative_exponents(self):
        assert math.pow(2, -1) == 0.5
        assert math.pow(10, -2) == 0.01
        assert math.pow(5, -1) == 0.2

    def test_fractional_exponents(self):
        assert math.pow(4, 0.5) == 2  # Square root
        assert math.pow(8, 1 / 3) == pytest.approx(2)  # Cube root
        assert math.pow(27, 1 / 3) == pytest.approx(3)

    def test_base_of_0(self):
        assert math.pow(0, 1) == 0
        assert math.pow(0, 5) == 0

    def test_base_of_1(self):
        assert math.pow(1, 100) == 1
        assert math.pow(1, -100) == 1


# --- math.exp ---

class TestExp:
    def test_small_integers(self):
        assert math.exp(0) == 1
        assert math.exp(1) == pytest.approx(pymath.e)
        assert math.exp(2) == pytest.approx(7.389056, abs=1e-5)

    def test_negative_exponents(self):
        assert math.exp(-1) == pytest.approx(0.367879, abs=1e-5)
        assert math.exp(-2) == pytest.approx(0.135335, abs=1e-5)

    def test_exp_and_log_are_inverses(self):
        x = 5
        assert math.exp(math.log(x)) == pytest.approx(x)

    def test_decimal_exponents(self):
        assert math.exp(0.5) == pytest.approx(1.648721, abs=1e-5)
        assert math.exp(1.5) == pytest.approx(4.481689, abs=1e-5)


# --- math.log ---

class TestLog:
    def test_natural_logarithm(self):
        assert math.log(1) == 0
        assert math.log(pymath.e) == pytest.approx(1)
        assert math.log(10) == pytest.approx(2.302585, abs=1e-5)

    def test_common_values(self):
        assert math.log(2) == pytest.approx(0.693147, abs=1e-5)
        assert math.log(100) == pytest.approx(4.605170, abs=1e-5)

    def test_log_and_exp_are_inverses(self):
        x = 10
        assert math.log(math.exp(x)) == pytest.approx(x)

    def test_negative_numbers_return_nan(self):
        # Python math.log raises ValueError for negative, but the JS test expects NaN.
        # The Python implementation wraps stdlib, so we test that it raises.
        with pytest.raises(ValueError):
            math.log(-1)
        with pytest.raises(ValueError):
            math.log(-10)

    def test_zero_raises(self):
        # Python math.log(0) raises ValueError
        with pytest.raises(ValueError):
            math.log(0)

    def test_decimal_inputs(self):
        assert math.log(0.5) == pytest.approx(-0.693147, abs=1e-5)
        assert math.log(0.1) == pytest.approx(-2.302585, abs=1e-5)


# --- math.log10 ---

class TestLog10:
    def test_base10_logarithm(self):
        assert math.log10(1) == 0
        assert math.log10(10) == 1
        assert math.log10(100) == 2
        assert math.log10(1000) == 3

    def test_non_powers_of_10(self):
        assert math.log10(2) == pytest.approx(0.301029, abs=1e-5)
        assert math.log10(5) == pytest.approx(0.698970, abs=1e-5)

    def test_decimal_inputs(self):
        assert math.log10(0.1) == pytest.approx(-1)
        assert math.log10(0.01) == pytest.approx(-2)

    def test_negative_numbers_raise(self):
        with pytest.raises(ValueError):
            math.log10(-1)
        with pytest.raises(ValueError):
            math.log10(-10)

    def test_zero_raises(self):
        # Python math.log10(0) raises ValueError
        with pytest.raises(ValueError):
            math.log10(0)

    def test_relationship_with_natural_log(self):
        x = 50
        assert math.log10(x) == pytest.approx(math.log(x) / math.log(10))
