"""Tests for math functions with Series support.

All tests in this file are skipped because the Python math_.py module
is currently scalar-only (no Series support yet).
"""

import pytest

pytestmark = pytest.mark.skip(reason="math_.py is scalar-only; Series support not yet implemented")


class TestPowSeries:
    def test_series_base_scalar_exponent(self):
        pass

    def test_scalar_base_series_exponent(self):
        pass

    def test_both_series(self):
        pass

    def test_both_scalars(self):
        pass


class TestSqrtSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass

    def test_nan_values_in_series(self):
        pass


class TestAbsSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestCeilSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestFloorSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestRoundSeries:
    def test_series_input_without_precision(self):
        pass

    def test_series_input_with_precision(self):
        pass

    def test_scalar_input(self):
        pass


class TestMaxSeries:
    def test_series_arguments(self):
        pass

    def test_mix_of_series_and_scalars(self):
        pass

    def test_all_scalars(self):
        pass


class TestMinSeries:
    def test_series_arguments(self):
        pass

    def test_mix_of_series_and_scalars(self):
        pass

    def test_all_scalars(self):
        pass


class TestAvgSeries:
    def test_series_arguments(self):
        pass

    def test_mix_of_series_and_scalars(self):
        pass

    def test_all_scalars(self):
        pass


class TestExpSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestLogSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestLog10Series:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestTrigSeries:
    def test_sin_series(self):
        pass

    def test_sin_scalar(self):
        pass

    def test_cos_series(self):
        pass

    def test_cos_scalar(self):
        pass

    def test_tan_series(self):
        pass

    def test_tan_scalar(self):
        pass

    def test_asin_series(self):
        pass

    def test_asin_scalar(self):
        pass

    def test_acos_series(self):
        pass

    def test_acos_scalar(self):
        pass

    def test_atan_series(self):
        pass

    def test_atan_scalar(self):
        pass


class TestAngleConversionSeries:
    def test_toradians_series(self):
        pass

    def test_toradians_scalar(self):
        pass

    def test_todegrees_series(self):
        pass

    def test_todegrees_scalar(self):
        pass


class TestSignSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass


class TestRoundToMintickSeries:
    def test_series_input(self):
        pass

    def test_scalar_input(self):
        pass

    def test_nan_values_in_series(self):
        pass

    def test_throws_without_mintick(self):
        pass
