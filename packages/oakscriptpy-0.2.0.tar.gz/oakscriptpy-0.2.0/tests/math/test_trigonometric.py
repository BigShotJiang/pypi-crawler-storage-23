"""Tests for trigonometric math functions: sin, cos, tan, asin, acos, atan."""

import math as pymath

import pytest

from oakscriptpy import math_ as math


# --- math.sin ---

class TestSin:
    def test_common_angles(self):
        assert math.sin(0) == 0
        assert math.sin(pymath.pi / 2) == pytest.approx(1)
        assert math.sin(pymath.pi) == pytest.approx(0)
        assert math.sin(3 * pymath.pi / 2) == pytest.approx(-1)

    def test_special_angles(self):
        assert math.sin(pymath.pi / 6) == pytest.approx(0.5)       # 30 degrees
        assert math.sin(pymath.pi / 4) == pytest.approx(pymath.sqrt(2) / 2)  # 45 degrees
        assert math.sin(pymath.pi / 3) == pytest.approx(pymath.sqrt(3) / 2)  # 60 degrees

    def test_negative_angles(self):
        assert math.sin(-pymath.pi / 2) == pytest.approx(-1)
        assert math.sin(-pymath.pi / 6) == pytest.approx(-0.5)

    def test_periodic_with_period_2pi(self):
        angle = pymath.pi / 4
        assert math.sin(angle) == pytest.approx(math.sin(angle + 2 * pymath.pi))
        assert math.sin(angle) == pytest.approx(math.sin(angle + 4 * pymath.pi))

    def test_pythagorean_identity(self):
        x = 0.7
        sin_x = math.sin(x)
        cos_x = math.cos(x)
        assert sin_x * sin_x + cos_x * cos_x == pytest.approx(1)


# --- math.cos ---

class TestCos:
    def test_common_angles(self):
        assert math.cos(0) == 1
        assert math.cos(pymath.pi / 2) == pytest.approx(0)
        assert math.cos(pymath.pi) == pytest.approx(-1)
        assert math.cos(2 * pymath.pi) == pytest.approx(1)

    def test_special_angles(self):
        assert math.cos(pymath.pi / 3) == pytest.approx(0.5)       # 60 degrees
        assert math.cos(pymath.pi / 4) == pytest.approx(pymath.sqrt(2) / 2)  # 45 degrees
        assert math.cos(pymath.pi / 6) == pytest.approx(pymath.sqrt(3) / 2)  # 30 degrees

    def test_negative_angles(self):
        assert math.cos(-pymath.pi) == pytest.approx(-1)
        assert math.cos(-pymath.pi / 3) == pytest.approx(0.5)

    def test_periodic_with_period_2pi(self):
        angle = pymath.pi / 3
        assert math.cos(angle) == pytest.approx(math.cos(angle + 2 * pymath.pi))
        assert math.cos(angle) == pytest.approx(math.cos(angle + 4 * pymath.pi))

    def test_even_function(self):
        x = 1.5
        assert math.cos(x) == pytest.approx(math.cos(-x))


# --- math.tan ---

class TestTan:
    def test_common_angles(self):
        assert math.tan(0) == pytest.approx(0)
        assert math.tan(pymath.pi / 4) == pytest.approx(1)
        assert math.tan(pymath.pi) == pytest.approx(0)

    def test_special_angles(self):
        assert math.tan(pymath.pi / 6) == pytest.approx(1 / pymath.sqrt(3))  # 30 degrees
        assert math.tan(pymath.pi / 3) == pytest.approx(pymath.sqrt(3))      # 60 degrees

    def test_tan_equals_sin_over_cos(self):
        x = 0.8
        assert math.tan(x) == pytest.approx(math.sin(x) / math.cos(x))

    def test_negative_angles(self):
        assert math.tan(-pymath.pi / 4) == pytest.approx(-1)

    def test_periodic_with_period_pi(self):
        angle = pymath.pi / 6
        assert math.tan(angle) == pytest.approx(math.tan(angle + pymath.pi))


# --- math.asin ---

class TestAsin:
    def test_common_values(self):
        assert math.asin(0) == 0
        assert math.asin(1) == pytest.approx(pymath.pi / 2)
        assert math.asin(-1) == pytest.approx(-pymath.pi / 2)

    def test_special_values(self):
        assert math.asin(0.5) == pytest.approx(pymath.pi / 6)                 # 30 degrees
        assert math.asin(pymath.sqrt(2) / 2) == pytest.approx(pymath.pi / 4)  # 45 degrees
        assert math.asin(pymath.sqrt(3) / 2) == pytest.approx(pymath.pi / 3)  # 60 degrees

    def test_inverse_of_sin(self):
        x = 0.7
        assert math.asin(math.sin(x)) == pytest.approx(x)

    def test_out_of_range_raises(self):
        with pytest.raises(ValueError):
            math.asin(1.5)
        with pytest.raises(ValueError):
            math.asin(-1.5)
        with pytest.raises(ValueError):
            math.asin(2)

    def test_values_in_valid_range(self):
        test_values = [0, 0.5, -0.5, 1, -1]
        for val in test_values:
            result = math.asin(val)
            assert result >= -pymath.pi / 2
            assert result <= pymath.pi / 2


# --- math.acos ---

class TestAcos:
    def test_common_values(self):
        assert math.acos(1) == 0
        assert math.acos(0) == pytest.approx(pymath.pi / 2)
        assert math.acos(-1) == pytest.approx(pymath.pi)

    def test_special_values(self):
        assert math.acos(0.5) == pytest.approx(pymath.pi / 3)                 # 60 degrees
        assert math.acos(pymath.sqrt(2) / 2) == pytest.approx(pymath.pi / 4)  # 45 degrees
        assert math.acos(pymath.sqrt(3) / 2) == pytest.approx(pymath.pi / 6)  # 30 degrees

    def test_inverse_of_cos(self):
        x = 2.5
        assert math.acos(math.cos(x)) == pytest.approx(x)

    def test_out_of_range_raises(self):
        with pytest.raises(ValueError):
            math.acos(1.5)
        with pytest.raises(ValueError):
            math.acos(-1.5)
        with pytest.raises(ValueError):
            math.acos(2)

    def test_values_in_valid_range(self):
        test_values = [0, 0.5, -0.5, 1, -1]
        for val in test_values:
            result = math.acos(val)
            assert result >= 0
            assert result <= pymath.pi


# --- math.atan ---

class TestAtan:
    def test_common_values(self):
        assert math.atan(0) == 0
        assert math.atan(1) == pytest.approx(pymath.pi / 4)
        assert math.atan(-1) == pytest.approx(-pymath.pi / 4)

    def test_special_values(self):
        assert math.atan(pymath.sqrt(3)) == pytest.approx(pymath.pi / 3)
        assert math.atan(1 / pymath.sqrt(3)) == pytest.approx(pymath.pi / 6)

    def test_inverse_of_tan(self):
        x = 0.5
        assert math.atan(math.tan(x)) == pytest.approx(x)

    def test_infinity(self):
        assert math.atan(float("inf")) == pytest.approx(pymath.pi / 2)
        assert math.atan(float("-inf")) == pytest.approx(-pymath.pi / 2)

    def test_values_in_valid_range(self):
        test_values = [0, 1, -1, 10, -10, 100]
        for val in test_values:
            result = math.atan(val)
            assert result >= -pymath.pi / 2
            assert result <= pymath.pi / 2

    def test_very_large_and_small_values(self):
        assert math.atan(1e10) == pytest.approx(pymath.pi / 2, abs=1e-5)
        assert math.atan(-1e10) == pytest.approx(-pymath.pi / 2, abs=1e-5)
        assert math.atan(1e-10) == pytest.approx(0, abs=1e-5)
