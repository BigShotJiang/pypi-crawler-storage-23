"""Tests for runtime context management and plot functions.

Ported from: D:/WebstormProjects/oakscriptJS/tests/runtime/runtime.test.ts
"""

import math

import pytest

from oakscriptpy.runtime import (
    set_context,
    clear_context,
    get_context,
    plot,
    hline,
    clear_plots,
    get_active_plots,
    register_calculate,
    recalculate,
)
from oakscriptpy.runtime_types import OakScriptContext, OhlcvData
from oakscriptpy.adapters.simple_input import SimpleInputAdapter


# ---------------------------------------------------------------------------
# Mock chart adapter
# ---------------------------------------------------------------------------

class MockSeriesHandle:
    def __init__(self, record: dict):
        self._record = record

    def set_data(self, data):
        self._record["data"] = data


class MockChartAdapter:
    def __init__(self):
        self.added_series: list[dict] = []
        self.removed_series: list[MockSeriesHandle] = []

    def add_series(self, type_: str, options=None):
        record = {"type": type_, "options": options or {}, "data": []}
        self.added_series.append(record)
        return MockSeriesHandle(record)

    def remove_series(self, series):
        self.removed_series.append(series)


def create_mock_context():
    mock_chart = MockChartAdapter()
    ctx = OakScriptContext(
        chart=mock_chart,
        inputs=SimpleInputAdapter(),
        ohlcv=OhlcvData(
            time=[1000, 2000, 3000, 4000, 5000],
            open=[100, 101, 102, 103, 104],
            high=[105, 106, 107, 108, 109],
            low=[95, 96, 97, 98, 99],
            close=[102, 103, 104, 105, 106],
            volume=[1000, 1100, 1200, 1300, 1400],
        ),
        bar_index=4,
    )
    return ctx, mock_chart


# ---------------------------------------------------------------------------
# Fixture: automatically clear context after each test
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _cleanup():
    yield
    clear_context()


# ===========================================================================
# Runtime Context Management
# ===========================================================================

class TestSetContext:
    def test_should_set_the_global_context(self):
        ctx, _ = create_mock_context()
        set_context(ctx)
        assert get_context() is ctx

    def test_should_clear_previous_plots_when_context_is_set(self):
        ctx1, _ = create_mock_context()
        set_context(ctx1)
        plot([1, 2, 3, 4, 5], "Test")

        ctx2, _ = create_mock_context()
        set_context(ctx2)

        assert len(get_active_plots()) == 0


class TestClearContext:
    def test_should_clear_the_global_context(self):
        ctx, _ = create_mock_context()
        set_context(ctx)
        clear_context()
        assert get_context() is None

    def test_should_clear_active_plots(self):
        ctx, _ = create_mock_context()
        set_context(ctx)
        plot([1, 2, 3, 4, 5], "Test")

        clear_context()
        assert len(get_active_plots()) == 0


class TestGetContext:
    def test_should_return_none_when_no_context_is_set(self):
        assert get_context() is None

    def test_should_return_the_current_context(self):
        ctx, _ = create_mock_context()
        set_context(ctx)
        assert get_context() is ctx


# ===========================================================================
# Calculate Registration and Recalculation
# ===========================================================================

class TestRegisterCalculate:
    def test_should_register_a_calculate_function(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        call_count = 0

        def calculate_fn():
            nonlocal call_count
            call_count += 1

        register_calculate(calculate_fn)
        recalculate()
        assert call_count == 1


class TestRecalculate:
    def test_should_clear_plots_before_recalculating(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "Test")
        assert len(get_active_plots()) == 1

        register_calculate(lambda: None)
        recalculate()

        # Plots should have been cleared before calling calculateFn.
        # The mock function doesn't add new plots, so count should be 0.
        assert len(get_active_plots()) == 0

    def test_should_do_nothing_if_no_calculate_function_is_registered(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        # Should not raise
        recalculate()


# ===========================================================================
# Plot Functions
# ===========================================================================

class TestPlot:
    def test_should_raise_if_no_context_is_set(self):
        with pytest.raises(RuntimeError, match="OakScript context not set"):
            plot([1, 2, 3], "Test")

    def test_should_add_a_line_series_to_the_chart(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "SMA")

        assert len(mock_chart.added_series) == 1
        assert mock_chart.added_series[0]["type"] == "line"

    def test_should_return_a_unique_plot_id(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        id1 = plot([1, 2, 3, 4, 5], "SMA")
        id2 = plot([2, 3, 4, 5, 6], "EMA")

        assert id1 != id2
        assert "SMA" in id1
        assert "EMA" in id2

    def test_should_track_active_plots(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "SMA")
        plot([2, 3, 4, 5, 6], "EMA")

        assert len(get_active_plots()) == 2

    def test_should_pass_color_and_linewidth_options(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "Test", color="#FF0000", linewidth=2)

        assert mock_chart.added_series[0]["options"]["color"] == "#FF0000"
        assert mock_chart.added_series[0]["options"]["lineWidth"] == 2

    def test_should_map_histogram_style_correctly(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "Volume", style="histogram")

        assert mock_chart.added_series[0]["type"] == "histogram"

    def test_should_set_time_value_data_on_the_series(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([10, 20, 30, 40, 50], "Test")

        series_data = mock_chart.added_series[0]["data"]
        assert len(series_data) == 5
        assert series_data[0] == {"time": 1000, "value": 10}
        assert series_data[4] == {"time": 5000, "value": 50}

    def test_should_filter_out_nan_values(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([10, float("nan"), 30, float("nan"), 50], "Test")

        series_data = mock_chart.added_series[0]["data"]
        assert len(series_data) == 3
        assert [d["value"] for d in series_data] == [10, 30, 50]


class TestHline:
    def test_should_raise_if_no_context_is_set(self):
        with pytest.raises(RuntimeError, match="OakScript context not set"):
            hline(50, "Test")

    def test_should_add_a_horizontal_line_series(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        hline(50, "Support")

        assert len(mock_chart.added_series) == 1
        assert mock_chart.added_series[0]["type"] == "line"

    def test_should_create_constant_value_data_across_all_time_points(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        hline(50, "Support")

        series_data = mock_chart.added_series[0]["data"]
        assert len(series_data) == 5
        for point in series_data:
            assert point["value"] == 50

    def test_should_return_a_unique_hline_id(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        id1 = hline(50, "Support")
        id2 = hline(70, "Resistance")

        assert id1 != id2
        assert "hline" in id1
        assert "hline" in id2

    def test_should_track_active_hlines(self):
        ctx, _ = create_mock_context()
        set_context(ctx)

        hline(50, "Support")
        hline(70, "Resistance")

        assert len(get_active_plots()) == 2


class TestClearPlots:
    def test_should_remove_all_active_plots_from_chart(self):
        ctx, mock_chart = create_mock_context()
        set_context(ctx)

        plot([1, 2, 3, 4, 5], "SMA")
        plot([2, 3, 4, 5, 6], "EMA")
        hline(50, "Support")

        assert len(get_active_plots()) == 3

        clear_plots()

        assert len(get_active_plots()) == 0
        assert len(mock_chart.removed_series) == 3

    def test_should_handle_clearing_when_no_context_is_set(self):
        # No context, no error
        clear_plots()
