"""Tests for SimpleInputAdapter.

Ported from: D:/WebstormProjects/oakscriptJS/tests/runtime/adapters.test.ts
(Only the SimpleInputAdapter portion; LightweightChartsAdapter does not exist in Python.)
"""

import pytest

from oakscriptpy.adapters.simple_input import SimpleInputAdapter
from oakscriptpy.runtime_types import InputConfig


# ===========================================================================
# SimpleInputAdapter
# ===========================================================================

class TestRegisterInput:
    def test_should_register_a_new_input_and_return_default_value(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14, title="Length")

        value = adapter.register_input(config)
        assert value == 14

    def test_should_return_existing_value_if_input_already_registered(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14, title="Length")

        adapter.register_input(config)
        adapter.set_value("length", 20)

        # Register again - should return current value, not defval
        value = adapter.register_input(config)
        assert value == 20

    def test_should_handle_float_inputs(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="factor", type="float", defval=2.5, title="Factor")

        value = adapter.register_input(config)
        assert value == 2.5

    def test_should_handle_bool_inputs(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="showLabels", type="bool", defval=True, title="Show Labels")

        value = adapter.register_input(config)
        assert value is True

    def test_should_handle_string_inputs(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(
            id="maType", type="string", defval="SMA",
            title="MA Type", options=["SMA", "EMA", "WMA"],
        )

        value = adapter.register_input(config)
        assert value == "SMA"


class TestGetValue:
    def test_should_return_current_value_for_registered_input(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14)

        adapter.register_input(config)
        assert adapter.get_value("length") == 14

    def test_should_return_none_for_unregistered_input(self):
        adapter = SimpleInputAdapter()
        assert adapter.get_value("nonexistent") is None


class TestSetValue:
    def test_should_update_value_of_registered_input(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14)

        adapter.register_input(config)
        adapter.set_value("length", 20)
        assert adapter.get_value("length") == 20

    def test_should_ignore_set_value_for_unregistered_input(self):
        adapter = SimpleInputAdapter()
        adapter.set_value("nonexistent", 100)
        assert adapter.get_value("nonexistent") is None

    def test_should_enforce_min_constraint(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14, min=1, max=100)

        adapter.register_input(config)
        adapter.set_value("length", -5)
        assert adapter.get_value("length") == 1

    def test_should_enforce_max_constraint(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14, min=1, max=100)

        adapter.register_input(config)
        adapter.set_value("length", 500)
        assert adapter.get_value("length") == 100

    def test_should_floor_int_values(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14)

        adapter.register_input(config)
        adapter.set_value("length", 15.7)
        assert adapter.get_value("length") == 15

    def test_should_validate_string_options(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(
            id="maType", type="string", defval="SMA",
            options=["SMA", "EMA", "WMA"],
        )

        adapter.register_input(config)

        # Valid option
        adapter.set_value("maType", "EMA")
        assert adapter.get_value("maType") == "EMA"

        # Invalid option - should keep current value
        adapter.set_value("maType", "INVALID")
        assert adapter.get_value("maType") == "EMA"


class TestOnInputChange:
    def test_should_call_registered_callback_when_value_changes(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14)
        callback_calls = []

        adapter.register_input(config)
        adapter.on_input_change(lambda id_, val: callback_calls.append((id_, val)))
        adapter.set_value("length", 20)

        assert len(callback_calls) == 1
        assert callback_calls[0] == ("length", 20)

    def test_should_call_multiple_callbacks(self):
        adapter = SimpleInputAdapter()
        config = InputConfig(id="length", type="int", defval=14)
        calls1 = []
        calls2 = []

        adapter.register_input(config)
        adapter.on_input_change(lambda id_, val: calls1.append((id_, val)))
        adapter.on_input_change(lambda id_, val: calls2.append((id_, val)))
        adapter.set_value("length", 20)

        assert len(calls1) == 1
        assert calls1[0] == ("length", 20)
        assert len(calls2) == 1
        assert calls2[0] == ("length", 20)


class TestGetAllInputs:
    def test_should_return_all_registered_inputs(self):
        adapter = SimpleInputAdapter()
        adapter.register_input(InputConfig(id="a", type="int", defval=1))
        adapter.register_input(InputConfig(id="b", type="float", defval=2.5))

        inputs = adapter.get_all_inputs()
        assert len(inputs) == 2
        assert inputs["a"]["value"] == 1
        assert inputs["b"]["value"] == 2.5


class TestClear:
    def test_should_remove_all_inputs_and_callbacks(self):
        adapter = SimpleInputAdapter()
        callback_calls = []
        adapter.register_input(InputConfig(id="a", type="int", defval=1))
        adapter.on_input_change(lambda id_, val: callback_calls.append((id_, val)))

        adapter.clear()

        assert adapter.get_value("a") is None
        assert len(adapter.get_all_inputs()) == 0
