"""Tests for array binary search and statistical (covariance) functions.

Ported from oakscriptJS/tests/array/search_and_stats.test.ts
"""

import math

import pytest

from oakscriptpy import array


# ---------------------------------------------------------------------------
# array.binary_search
# ---------------------------------------------------------------------------

class TestBinarySearch:
    def test_find_value_in_sorted_array(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search(arr, 5) == 3
        assert array.binary_search(arr, -2) == 0
        assert array.binary_search(arr, 9) == 4

    def test_return_neg1_when_value_not_found(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search(arr, 3) == -1
        assert array.binary_search(arr, 10) == -1
        assert array.binary_search(arr, -10) == -1

    def test_work_with_single_element(self):
        arr = [5]
        assert array.binary_search(arr, 5) == 0
        assert array.binary_search(arr, 3) == -1

    def test_work_with_two_elements(self):
        arr = [1, 5]
        assert array.binary_search(arr, 1) == 0
        assert array.binary_search(arr, 5) == 1
        assert array.binary_search(arr, 3) == -1

    def test_handle_duplicate_values(self):
        arr = [1, 2, 2, 2, 5]
        index = array.binary_search(arr, 2)
        # Should return one of the indices where 2 exists (1, 2, or 3)
        assert index in [1, 2, 3]
        assert arr[index] == 2

    def test_work_with_large_arrays(self):
        arr = list(range(1000))
        assert array.binary_search(arr, 500) == 500
        assert array.binary_search(arr, 0) == 0
        assert array.binary_search(arr, 999) == 999

    def test_work_with_negative_numbers(self):
        arr = [-10, -5, -1, 0, 5, 10]
        assert array.binary_search(arr, -5) == 1
        assert array.binary_search(arr, 0) == 3

    def test_handle_empty_array(self):
        arr: list[float] = []
        assert array.binary_search(arr, 5) == -1

    def test_work_with_decimal_values(self):
        arr = [1.1, 2.2, 3.3, 4.4, 5.5]
        assert array.binary_search(arr, 3.3) == 2


# ---------------------------------------------------------------------------
# array.binary_search_leftmost
# ---------------------------------------------------------------------------

class TestBinarySearchLeftmost:
    def test_return_index_of_leftmost_occurrence_for_duplicates(self):
        arr = [4, 5, 5, 5]
        assert array.binary_search_leftmost(arr, 5) == 1

    def test_return_position_left_of_where_value_would_be(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search_leftmost(arr, 3) == 2  # 1 is at index 2

    def test_find_exact_matches(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search_leftmost(arr, 5) == 3
        assert array.binary_search_leftmost(arr, 0) == 1

    def test_handle_value_smaller_than_all_elements(self):
        arr = [5, 10, 15, 20]
        assert array.binary_search_leftmost(arr, 3) == -1

    def test_handle_value_larger_than_all_elements(self):
        arr = [5, 10, 15, 20]
        assert array.binary_search_leftmost(arr, 25) == 3  # Index of 20

    def test_return_leftmost_for_multiple_duplicates_at_start(self):
        arr = [1, 1, 1, 2, 3]
        assert array.binary_search_leftmost(arr, 1) == 0

    def test_return_leftmost_for_multiple_duplicates_in_middle(self):
        arr = [1, 3, 3, 3, 5]
        assert array.binary_search_leftmost(arr, 3) == 1

    def test_return_leftmost_for_multiple_duplicates_at_end(self):
        arr = [1, 2, 5, 5, 5]
        assert array.binary_search_leftmost(arr, 5) == 2

    def test_work_with_single_element_found(self):
        arr = [5]
        assert array.binary_search_leftmost(arr, 5) == 0

    def test_work_with_single_element_not_found(self):
        arr = [5]
        assert array.binary_search_leftmost(arr, 10) == 0
        assert array.binary_search_leftmost(arr, 3) == -1

    def test_handle_empty_array(self):
        arr: list[float] = []
        assert array.binary_search_leftmost(arr, 5) == -1


# ---------------------------------------------------------------------------
# array.binary_search_rightmost
# ---------------------------------------------------------------------------

class TestBinarySearchRightmost:
    def test_return_index_of_rightmost_occurrence_for_duplicates(self):
        arr = [4, 5, 5, 5]
        assert array.binary_search_rightmost(arr, 5) == 3

    def test_return_position_right_of_where_value_would_be(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search_rightmost(arr, 3) == 3  # 5 is at index 3

    def test_find_exact_matches(self):
        arr = [-2, 0, 1, 5, 9]
        assert array.binary_search_rightmost(arr, 5) == 3
        assert array.binary_search_rightmost(arr, 0) == 1

    def test_handle_value_smaller_than_all_elements(self):
        arr = [5, 10, 15, 20]
        assert array.binary_search_rightmost(arr, 3) == 0  # Index of 5

    def test_handle_value_larger_than_all_elements(self):
        arr = [5, 10, 15, 20]
        assert array.binary_search_rightmost(arr, 25) == -1

    def test_return_rightmost_for_multiple_duplicates_at_start(self):
        arr = [1, 1, 1, 2, 3]
        assert array.binary_search_rightmost(arr, 1) == 2

    def test_return_rightmost_for_multiple_duplicates_in_middle(self):
        arr = [1, 3, 3, 3, 5]
        assert array.binary_search_rightmost(arr, 3) == 3

    def test_return_rightmost_for_multiple_duplicates_at_end(self):
        arr = [1, 2, 5, 5, 5]
        assert array.binary_search_rightmost(arr, 5) == 4

    def test_work_with_single_element_found(self):
        arr = [5]
        assert array.binary_search_rightmost(arr, 5) == 0

    def test_work_with_single_element_not_found(self):
        arr = [5]
        assert array.binary_search_rightmost(arr, 10) == -1
        assert array.binary_search_rightmost(arr, 3) == 0

    def test_handle_empty_array(self):
        arr: list[float] = []
        assert array.binary_search_rightmost(arr, 5) == -1


# ---------------------------------------------------------------------------
# binary_search comparison
# ---------------------------------------------------------------------------

class TestBinarySearchComparison:
    def test_demonstrate_difference_between_leftmost_and_rightmost(self):
        arr = [1, 5, 5, 5, 10]

        leftmost = array.binary_search_leftmost(arr, 5)
        rightmost = array.binary_search_rightmost(arr, 5)

        assert leftmost == 1   # First 5
        assert rightmost == 3  # Last 5

        # Regular binary search returns any occurrence
        regular = array.binary_search(arr, 5)
        assert regular >= leftmost
        assert regular <= rightmost

    def test_demonstrate_insertion_points_when_not_found(self):
        arr = [1, 3, 5, 7, 9]

        # Looking for 4 (between 3 and 5)
        leftmost = array.binary_search_leftmost(arr, 4)
        rightmost = array.binary_search_rightmost(arr, 4)
        regular = array.binary_search(arr, 4)

        assert leftmost == 1   # Index of 3 (left of where 4 would be)
        assert rightmost == 2  # Index of 5 (right of where 4 would be)
        assert regular == -1   # Not found


# ---------------------------------------------------------------------------
# array.covariance
# ---------------------------------------------------------------------------

class TestCovariance:
    def test_calculate_biased_covariance_by_default(self):
        arr1 = [1, 2, 3, 4, 5]
        arr2 = [2, 4, 6, 8, 10]

        cov = array.covariance(arr1, arr2)
        assert cov > 0
        assert cov == pytest.approx(4, abs=1e-5)

    def test_calculate_unbiased_covariance_when_specified(self):
        arr1 = [1, 2, 3, 4, 5]
        arr2 = [2, 4, 6, 8, 10]

        cov = array.covariance(arr1, arr2, False)
        assert cov > 0
        assert cov == pytest.approx(5, abs=1e-5)

    def test_calculate_negative_covariance_for_inverse_relationship(self):
        arr1 = [1, 2, 3, 4, 5]
        arr2 = [10, 8, 6, 4, 2]

        cov = array.covariance(arr1, arr2)
        assert cov < 0

    def test_calculate_zero_covariance_for_no_relationship(self):
        arr1 = [1, 2, 3, 4, 5]
        arr2 = [3, 3, 3, 3, 3]  # Constant

        cov = array.covariance(arr1, arr2)
        assert cov == pytest.approx(0)

    def test_return_nan_for_empty_arrays(self):
        arr1: list[float] = []
        arr2: list[float] = []

        cov = array.covariance(arr1, arr2)
        assert math.isnan(cov)

    def test_return_nan_for_arrays_of_different_lengths(self):
        arr1 = [1, 2, 3]
        arr2 = [1, 2, 3, 4, 5]

        cov = array.covariance(arr1, arr2)
        assert math.isnan(cov)

    def test_work_with_two_elements(self):
        arr1 = [1, 2]
        arr2 = [3, 4]

        cov_biased = array.covariance(arr1, arr2, True)
        cov_unbiased = array.covariance(arr1, arr2, False)

        assert cov_biased == pytest.approx(0.25)
        assert cov_unbiased == pytest.approx(0.5)

    def test_handle_negative_numbers(self):
        arr1 = [-5, -3, -1, 1, 3, 5]
        arr2 = [-10, -6, -2, 2, 6, 10]

        cov = array.covariance(arr1, arr2)
        assert cov > 0

    def test_work_with_real_world_price_volume_data(self):
        prices = [100, 102, 98, 105, 103]
        volumes = [1000, 1200, 950, 1300, 1100]

        cov = array.covariance(prices, volumes)
        assert cov > 0

    def test_match_variance_when_arrays_are_identical(self):
        arr = [1, 2, 3, 4, 5]

        cov = array.covariance(arr, arr, True)
        var = array.variance(arr)

        assert cov == pytest.approx(var)

    def test_handle_decimal_values(self):
        arr1 = [1.5, 2.3, 3.7, 4.1]
        arr2 = [2.1, 3.5, 5.2, 6.0]

        cov = array.covariance(arr1, arr2)
        assert cov > 0

    def test_demonstrate_difference_between_biased_and_unbiased(self):
        arr1 = [1, 2, 3, 4, 5]
        arr2 = [5, 4, 3, 2, 1]

        biased = array.covariance(arr1, arr2, True)
        unbiased = array.covariance(arr1, arr2, False)

        # Unbiased should have larger absolute value
        assert abs(unbiased) > abs(biased)

        # They should have same sign
        assert (biased > 0) == (unbiased > 0) or (biased < 0) == (unbiased < 0)
