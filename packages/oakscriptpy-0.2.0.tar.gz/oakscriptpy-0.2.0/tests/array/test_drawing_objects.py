"""Tests for array functions with drawing object types.

Tests array.new_line, array.new_box, array.new_label, array.new_linefill.

Ported from oakscriptJS/tests/array/drawing_objects.test.ts
"""

from oakscriptpy import array, line, box, label, linefill


# ---------------------------------------------------------------------------
# array.new_line
# ---------------------------------------------------------------------------

class TestNewLine:
    def test_create_empty_line_array_by_default(self):
        arr = array.new_line()
        assert array.size(arr) == 0

    def test_create_line_array_with_specified_size(self):
        arr = array.new_line(5)
        assert array.size(arr) == 5

    def test_create_line_array_with_initial_value(self):
        initial_line = line.new(0, 100, 50, 150)
        arr = array.new_line(3, initial_line)

        assert array.size(arr) == 3
        assert array.get(arr, 0) is initial_line
        assert array.get(arr, 1) is initial_line
        assert array.get(arr, 2) is initial_line

    def test_work_with_push_and_shift(self):
        lines = array.new_line()

        line1 = line.new(0, 100, 10, 110)
        line2 = line.new(10, 110, 20, 120)
        array.push(lines, line1)
        array.push(lines, line2)

        assert array.size(lines) == 2

        removed = array.shift(lines)
        assert removed is line1
        assert array.size(lines) == 1

    def test_manage_last_n_lines_pattern_from_docs(self):
        lines = array.new_line()
        max_lines = 15

        for i in range(20):
            new_line = line.new(i, 100 + i, i + 1, 101 + i)
            array.push(lines, new_line)

            if array.size(lines) > max_lines:
                array.shift(lines)

        assert array.size(lines) == max_lines

    def test_work_with_get_for_line_calculations(self):
        lines = array.new_line()

        array.push(lines, line.new(0, 100, 50, 150))
        array.push(lines, line.new(0, 90, 50, 140))

        line1 = array.get(lines, 0)
        line2 = array.get(lines, 1)

        price1 = line.get_price(line1, 25)
        price2 = line.get_price(line2, 25)

        assert price1 == 125  # 100 + (150-100)*(25-0)/(50-0)
        assert price2 == 115  # 90 + (140-90)*(25-0)/(50-0)


# ---------------------------------------------------------------------------
# array.new_box
# ---------------------------------------------------------------------------

class TestNewBox:
    def test_create_empty_box_array_by_default(self):
        arr = array.new_box()
        assert array.size(arr) == 0

    def test_create_box_array_with_specified_size(self):
        arr = array.new_box(5)
        assert array.size(arr) == 5

    def test_create_box_array_with_initial_value(self):
        initial_box = box.new(0, 120, 10, 100)
        arr = array.new_box(3, initial_box)

        assert array.size(arr) == 3
        assert array.get(arr, 0) is initial_box
        assert array.get(arr, 1) is initial_box
        assert array.get(arr, 2) is initial_box

    def test_track_multiple_gaps_pattern(self):
        gaps = array.new_box()

        gap1 = box.new(10, 120, 15, 110)
        gap2 = box.new(25, 135, 30, 125)
        gap3 = box.new(40, 140, 45, 130)

        array.push(gaps, gap1)
        array.push(gaps, gap2)
        array.push(gaps, gap3)

        assert array.size(gaps) == 3

        for i in range(array.size(gaps)):
            gap = array.get(gaps, i)
            gap_top = box.get_top(gap)
            gap_bottom = box.get_bottom(gap)
            gap_height = gap_top - gap_bottom

            assert gap_height == 10  # All gaps are 10 points high

    def test_detect_filled_gaps_from_array(self):
        gaps = array.new_box()

        array.push(gaps, box.new(10, 120, 15, 110))
        array.push(gaps, box.new(25, 135, 30, 125))

        current_high = 128
        current_low = 122

        filled_gaps = []
        for i in range(array.size(gaps)):
            gap = array.get(gaps, i)
            gap_top = box.get_top(gap)
            gap_bottom = box.get_bottom(gap)

            if current_low <= gap_top and current_high >= gap_bottom:
                filled_gaps.append(i)

        assert filled_gaps == [1]  # Second gap (125-135) is filled by price 122-128

    def test_remove_filled_gaps_from_array(self):
        gaps = array.new_box()

        array.push(gaps, box.new(10, 120, 15, 110))  # Won't be filled
        array.push(gaps, box.new(25, 135, 30, 125))  # Will be filled

        current_high = 130
        current_low = 127

        # Remove filled gaps (iterate backwards to avoid index issues)
        for i in range(array.size(gaps) - 1, -1, -1):
            gap = array.get(gaps, i)
            gap_top = box.get_top(gap)
            gap_bottom = box.get_bottom(gap)

            if current_low <= gap_top and current_high >= gap_bottom:
                array.remove(gaps, i)

        assert array.size(gaps) == 1  # Only unfilled gap remains
        remaining = array.get(gaps, 0)
        assert box.get_top(remaining) == 120


# ---------------------------------------------------------------------------
# array.new_label
# ---------------------------------------------------------------------------

class TestNewLabel:
    def test_create_empty_label_array_by_default(self):
        arr = array.new_label()
        assert array.size(arr) == 0

    def test_create_label_array_with_specified_size(self):
        arr = array.new_label(5)
        assert array.size(arr) == 5

    def test_create_label_array_with_initial_value(self):
        initial_label = label.new(50, 155.5, "Test")
        arr = array.new_label(3, initial_label)

        assert array.size(arr) == 3
        assert array.get(arr, 0) is initial_label
        assert array.get(arr, 1) is initial_label
        assert array.get(arr, 2) is initial_label

    def test_limit_label_count_pattern_from_docs(self):
        label_array = array.new_label()
        max_labels = 50

        for i in range(100):
            text = "Rising" if i % 2 == 0 else "Falling"
            lbl = label.new(i, 100 + i * 0.5, text)
            array.push(label_array, lbl)

            if array.size(label_array) > max_labels:
                array.shift(label_array)

        assert array.size(label_array) == max_labels

        # Verify labels are the most recent ones
        first_label = array.get(label_array, 0)
        assert label.get_x(first_label) == 50  # Bar 50 (100 - 50 = 50)

    def test_mark_pivot_points_with_labels(self):
        pivot_labels = array.new_label()

        array.push(pivot_labels, label.new(10, 155, "PH", "bar_index", "abovebar"))
        array.push(pivot_labels, label.new(25, 160, "PH", "bar_index", "abovebar"))
        array.push(pivot_labels, label.new(40, 158, "PH", "bar_index", "abovebar"))

        assert array.size(pivot_labels) == 3

        # Find highest pivot
        highest_pivot = array.get(pivot_labels, 0)
        highest_price = label.get_y(highest_pivot)

        for i in range(1, array.size(pivot_labels)):
            pivot = array.get(pivot_labels, i)
            price = label.get_y(pivot)
            if price > highest_price:
                highest_price = price
                highest_pivot = pivot

        assert label.get_x(highest_pivot) == 25
        assert highest_price == 160

    def test_update_label_properties_in_array(self):
        labels = array.new_label()

        array.push(labels, label.new(10, 100, "Signal 1"))
        array.push(labels, label.new(20, 110, "Signal 2"))

        # Update all labels to green
        for i in range(array.size(labels)):
            lbl = array.get(labels, i)
            label.set_color(lbl, "#00FF00")

        # Verify updates
        assert array.get(labels, 0).color == "#00FF00"
        assert array.get(labels, 1).color == "#00FF00"


# ---------------------------------------------------------------------------
# array.new_linefill
# ---------------------------------------------------------------------------

class TestNewLinefill:
    def test_create_empty_linefill_array_by_default(self):
        arr = array.new_linefill()
        assert array.size(arr) == 0

    def test_create_linefill_array_with_specified_size(self):
        arr = array.new_linefill(5)
        assert array.size(arr) == 5

    def test_create_linefill_array_with_initial_value(self):
        line1 = line.new(0, 120, 50, 130)
        line2 = line.new(0, 100, 50, 110)
        initial_fill = linefill.new(line1, line2, "#0000FF15")
        arr = array.new_linefill(3, initial_fill)

        assert array.size(arr) == 3
        assert array.get(arr, 0) is initial_fill
        assert array.get(arr, 1) is initial_fill
        assert array.get(arr, 2) is initial_fill

    def test_manage_multiple_channel_fills(self):
        channels = array.new_linefill()

        st_upper = line.new(0, 120, 50, 130)
        st_lower = line.new(0, 100, 50, 110)
        st_channel = linefill.new(st_upper, st_lower, "#0000FF15")

        lt_upper = line.new(0, 125, 100, 140)
        lt_lower = line.new(0, 95, 100, 105)
        lt_channel = linefill.new(lt_upper, lt_lower, "#FF000015")

        array.push(channels, st_channel)
        array.push(channels, lt_channel)

        assert array.size(channels) == 2

        assert array.get(channels, 0).color == "#0000FF15"
        assert array.get(channels, 1).color == "#FF000015"

    def test_change_colors_of_all_channels_based_on_condition(self):
        channels = array.new_linefill()

        for i in range(3):
            upper = line.new(i * 20, 120 + i * 10, (i + 1) * 20, 130 + i * 10)
            lower = line.new(i * 20, 100 + i * 10, (i + 1) * 20, 110 + i * 10)
            fill = linefill.new(upper, lower, "#0000FF15")
            array.push(channels, fill)

        is_bullish = False
        new_color = "#00FF0020" if is_bullish else "#FF000020"

        for i in range(array.size(channels)):
            channel = array.get(channels, i)
            linefill.set_color(channel, new_color)

        for i in range(array.size(channels)):
            assert array.get(channels, i).color == "#FF000020"

    def test_retrieve_lines_from_linefills_in_array(self):
        channels = array.new_linefill()

        upper = line.new(0, 120, 50, 130)
        lower = line.new(0, 100, 50, 110)
        channel = linefill.new(upper, lower, "#0000FF15")

        array.push(channels, channel)

        retrieved = array.get(channels, 0)
        line1 = linefill.get_line1(retrieved)
        line2 = linefill.get_line2(retrieved)

        assert line1 is upper
        assert line2 is lower


# ---------------------------------------------------------------------------
# Real-world integration patterns
# ---------------------------------------------------------------------------

class TestRealWorldIntegrationPatterns:
    def test_manage_trend_lines_with_breakout_detection(self):
        trend_lines = array.new_line()

        support = line.new(0, 95, 50, 105, "bar_index", "right")
        resistance = line.new(0, 115, 50, 125, "bar_index", "right")

        array.push(trend_lines, support)
        array.push(trend_lines, resistance)

        current_bar = 60
        current_price = 120

        above_support = False
        above_resistance = False

        for i in range(array.size(trend_lines)):
            trend_line = array.get(trend_lines, i)
            line_price = line.get_price(trend_line, current_bar)

            if i == 0 and current_price > line_price:
                above_support = True
            elif i == 1 and current_price > line_price:
                above_resistance = False  # 120 is below resistance at ~127

        assert above_support is True
        assert above_resistance is False

    def test_track_gaps_and_remove_when_filled(self):
        gaps = array.new_box()

        array.push(gaps, box.new(10, 120, 15, 110))
        array.push(gaps, box.new(25, 135, 30, 125))
        array.push(gaps, box.new(40, 145, 45, 140))

        high = 130
        low = 122

        for i in range(array.size(gaps) - 1, -1, -1):
            gap = array.get(gaps, i)
            if low <= box.get_top(gap) and high >= box.get_bottom(gap):
                array.remove(gaps, i)

        assert array.size(gaps) == 2  # Two gaps remain

    def test_combine_lines_boxes_and_labels(self):
        lines = array.new_line()
        boxes = array.new_box()
        labels = array.new_label()

        support = line.new(0, 100, 50, 110)
        array.push(lines, support)

        consolidation = box.new(20, 115, 30, 105)
        array.push(boxes, consolidation)

        breakout_label = label.new(35, 118, "BO")
        array.push(labels, breakout_label)

        assert array.size(lines) == 1
        assert array.size(boxes) == 1
        assert array.size(labels) == 1

    def test_manage_channel_fills_with_dynamic_updates(self):
        channels = array.new_linefill()
        lines = array.new_line()

        for i in range(5):
            upper = line.new(i * 10, 120, (i + 1) * 10, 125)
            lower = line.new(i * 10, 100, (i + 1) * 10, 105)

            array.push(lines, upper)
            array.push(lines, lower)

            fill = linefill.new(upper, lower, "#0000FF10")
            array.push(channels, fill)

        assert array.size(channels) == 5
        assert array.size(lines) == 10  # 2 lines per channel

        array.shift(channels)
        assert array.size(channels) == 4


# ---------------------------------------------------------------------------
# Edge cases and error handling
# ---------------------------------------------------------------------------

class TestEdgeCasesAndErrorHandling:
    def test_handle_none_initial_values(self):
        lines = array.new_line(3)
        assert array.size(lines) == 3
        assert array.get(lines, 0) is None

    def test_work_with_size_0(self):
        arr = array.new_line(0)
        assert array.size(arr) == 0

    def test_work_with_concat(self):
        arr1 = array.new_line()
        arr2 = array.new_line()

        array.push(arr1, line.new(0, 100, 10, 110))
        array.push(arr2, line.new(10, 110, 20, 120))

        combined = array.concat(arr1, arr2)
        assert array.size(combined) == 2

    def test_work_with_slice(self):
        lines = array.new_line()

        for i in range(10):
            array.push(lines, line.new(i, 100 + i, i + 1, 101 + i))

        last5 = array.slice(lines, 5, 10)
        assert array.size(last5) == 5

    def test_work_with_reverse(self):
        labels = array.new_label()

        array.push(labels, label.new(0, 100, "A"))
        array.push(labels, label.new(10, 110, "B"))
        array.push(labels, label.new(20, 120, "C"))

        array.reverse(labels)

        assert label.get_text(array.get(labels, 0)) == "C"
        assert label.get_text(array.get(labels, 1)) == "B"
        assert label.get_text(array.get(labels, 2)) == "A"
