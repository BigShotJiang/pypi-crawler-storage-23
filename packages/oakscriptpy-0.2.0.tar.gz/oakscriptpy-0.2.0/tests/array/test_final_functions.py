"""Tests for array.sort_indices, array.standardize, array.new_array (newtype equiv).

Ported from oakscriptJS/tests/array/final_functions.test.ts
"""

import math

import pytest

from oakscriptpy import array


# ---------------------------------------------------------------------------
# array.sort_indices
# ---------------------------------------------------------------------------

class TestSortIndices:
    def test_return_indices_that_would_sort_array_in_ascending_order(self):
        arr = [5, -2, 0, 9, 1]
        indices = array.sort_indices(arr)
        assert indices == [1, 2, 4, 0, 3]

    def test_return_indices_for_descending_order(self):
        arr = [5, -2, 0, 9, 1]
        indices = array.sort_indices(arr, "desc")
        assert indices == [3, 0, 4, 2, 1]

    def test_not_modify_original_array(self):
        arr = [5, -2, 0, 9, 1]
        original = arr[:]
        array.sort_indices(arr)
        assert arr == original

    def test_work_with_already_sorted_array(self):
        arr = [1, 2, 3, 4, 5]
        indices = array.sort_indices(arr)
        assert indices == [0, 1, 2, 3, 4]

    def test_work_with_reverse_sorted_array(self):
        arr = [5, 4, 3, 2, 1]
        indices = array.sort_indices(arr)
        assert indices == [4, 3, 2, 1, 0]

    def test_handle_duplicate_values(self):
        arr = [3, 1, 2, 1, 3]
        indices = array.sort_indices(arr)

        # Should maintain stable sort for duplicates
        assert arr[indices[0]] == 1
        assert arr[indices[1]] == 1
        assert arr[indices[2]] == 2
        assert arr[indices[3]] == 3
        assert arr[indices[4]] == 3

    def test_handle_single_element(self):
        arr = [42]
        indices = array.sort_indices(arr)
        assert indices == [0]

    def test_handle_empty_array(self):
        arr: list[float] = []
        indices = array.sort_indices(arr)
        assert indices == []

    def test_handle_negative_numbers(self):
        arr = [-5, -1, -3, -2, -4]
        indices = array.sort_indices(arr)
        assert indices == [0, 4, 2, 3, 1]
        # -5, -4, -3, -2, -1

    def test_handle_decimal_values(self):
        arr = [1.5, 1.1, 1.9, 1.3]
        indices = array.sort_indices(arr)
        assert indices == [1, 3, 0, 2]
        # 1.1, 1.3, 1.5, 1.9

    def test_allow_accessing_array_in_sorted_order(self):
        arr = [5, -2, 0, 9, 1]
        indices = array.sort_indices(arr)

        sorted_arr = [arr[i] for i in indices]
        assert sorted_arr == [-2, 0, 1, 5, 9]

    def test_maintain_correspondence_with_parallel_arrays(self):
        values = [5, -2, 0, 9, 1]
        names = ["E", "B", "C", "A", "D"]
        indices = array.sort_indices(values)

        sorted_names = [names[i] for i in indices]
        assert sorted_names == ["B", "C", "D", "E", "A"]
        # Corresponds to values: -2, 0, 1, 5, 9


# ---------------------------------------------------------------------------
# array.standardize
# ---------------------------------------------------------------------------

class TestStandardize:
    def test_standardize_array_to_mean_0_and_stddev_1(self):
        arr = [1, 2, 3, 4, 5]
        standardized = array.standardize(arr)

        mean = array.avg(standardized)
        assert mean == pytest.approx(0, abs=1e-10)

        stddev = array.stdev(standardized)
        assert stddev == pytest.approx(1, abs=1e-10)

    def test_calculate_correct_z_scores(self):
        arr = [1, 2, 3, 4, 5]
        standardized = array.standardize(arr)

        # Mean = 3, StdDev = sqrt(2) ~ 1.414
        assert standardized[0] == pytest.approx(-1.414, abs=0.01)
        assert standardized[1] == pytest.approx(-0.707, abs=0.01)
        assert standardized[2] == pytest.approx(0, abs=1e-10)
        assert standardized[3] == pytest.approx(0.707, abs=0.01)
        assert standardized[4] == pytest.approx(1.414, abs=0.01)

    def test_handle_all_identical_values(self):
        arr = [5, 5, 5, 5, 5]
        standardized = array.standardize(arr)

        # StdDev is 0, should return NaN
        assert all(math.isnan(x) for x in standardized)

    def test_handle_negative_numbers(self):
        arr = [-5, -3, -1, 1, 3, 5]
        standardized = array.standardize(arr)

        mean = array.avg(standardized)
        assert mean == pytest.approx(0, abs=1e-10)

        stddev = array.stdev(standardized)
        assert stddev == pytest.approx(1, abs=1e-10)

    def test_handle_decimal_values(self):
        arr = [1.1, 2.2, 3.3, 4.4, 5.5]
        standardized = array.standardize(arr)

        mean = array.avg(standardized)
        assert mean == pytest.approx(0, abs=1e-10)

        stddev = array.stdev(standardized)
        assert stddev == pytest.approx(1, abs=1e-10)

    def test_handle_single_element(self):
        arr = [42]
        standardized = array.standardize(arr)

        # StdDev is 0 for single element
        assert math.isnan(standardized[0])

    def test_handle_empty_array(self):
        arr: list[float] = []
        standardized = array.standardize(arr)
        assert standardized == []

    def test_handle_two_elements(self):
        arr = [1, 5]
        standardized = array.standardize(arr)

        # Mean = 3, StdDev = 2
        assert standardized[0] == pytest.approx(-1, abs=1e-10)
        assert standardized[1] == pytest.approx(1, abs=1e-10)

    def test_not_modify_original_array(self):
        arr = [1, 2, 3, 4, 5]
        original = arr[:]
        array.standardize(arr)
        assert arr == original

    def test_preserve_relative_ordering(self):
        arr = [10, 20, 30]
        standardized = array.standardize(arr)

        assert standardized[0] < standardized[1]
        assert standardized[1] < standardized[2]

    def test_work_with_large_range_of_values(self):
        arr = [0, 100, 1000, 10000]
        standardized = array.standardize(arr)

        mean = array.avg(standardized)
        assert mean == pytest.approx(0, abs=1e-5)

        stddev = array.stdev(standardized)
        assert stddev == pytest.approx(1, abs=1e-5)

    def test_demonstrate_use_case_for_comparing_different_scales(self):
        # Temperature in Celsius vs Height in cm
        temps = [10, 15, 20, 25, 30]
        heights = [150, 160, 170, 180, 190]

        temp_z = array.standardize(temps)
        height_z = array.standardize(heights)

        # Now both are on same scale (z-scores)
        # Middle values should be close to 0
        assert temp_z[2] == pytest.approx(0, abs=1e-10)
        assert height_z[2] == pytest.approx(0, abs=1e-10)

        # Both should have same stddev of 1
        assert array.stdev(temp_z) == pytest.approx(1, abs=1e-10)
        assert array.stdev(height_z) == pytest.approx(1, abs=1e-10)


# ---------------------------------------------------------------------------
# array.new_array (equivalent of JS array.newtype)
# ---------------------------------------------------------------------------

class TestNewArray:
    def test_create_empty_array_by_default(self):
        arr = array.new_array()
        assert arr == []
        assert len(arr) == 0

    def test_create_array_with_specified_size(self):
        arr = array.new_array(5)
        assert len(arr) == 5

    def test_create_array_with_initial_value(self):
        arr = array.new_array(3, 42)
        assert arr == [42, 42, 42]

    def test_work_with_string_type(self):
        arr = array.new_array(3, "test")
        assert arr == ["test", "test", "test"]

    def test_work_with_boolean_type(self):
        arr = array.new_array(2, True)
        assert arr == [True, True]

    def test_work_with_object_type(self):
        point = {"x": 1, "y": 2}
        arr = array.new_array(2, point)

        assert len(arr) == 2
        assert arr[0] is point
        assert arr[1] is point

    def test_work_as_generic_type_parameter(self):
        arr_num = array.new_array(3, 0)
        arr_str = array.new_array(3, "")

        assert arr_num == [0, 0, 0]
        assert arr_str == ["", "", ""]

    def test_note_limited_udt_support(self):
        arr = array.new_array(3)
        assert len(arr) == 3


# ---------------------------------------------------------------------------
# Drawing object array functions (existence checks)
# ---------------------------------------------------------------------------

class TestDrawingObjectArrayFunctions:
    def test_include_drawing_object_type_constructors(self):
        assert callable(array.new_line)
        assert callable(array.new_box)
        assert callable(array.new_label)
        assert callable(array.new_linefill)

        # new_table() remains excluded (no computational value)
        assert not hasattr(array, "new_table")

    def test_confirm_all_calculation_functions_remain_available(self):
        assert callable(array.avg)
        assert callable(array.stdev)
        assert callable(array.standardize)
        assert callable(array.covariance)
        assert callable(array.percentile_linear_interpolation)

        # Drawing object arrays are now available too
        assert callable(array.new_line)
        assert callable(array.new_box)
