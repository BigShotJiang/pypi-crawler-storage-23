"""Tests for array type constructors and simple math functions (abs, range).

Ported from oakscriptJS/tests/array/new_functions.test.ts
"""

import math

import pytest

from oakscriptpy import array


# ---------------------------------------------------------------------------
# array.new_bool
# ---------------------------------------------------------------------------

class TestNewBool:
    def test_create_empty_boolean_array_by_default(self):
        arr = array.new_bool()
        assert arr == []
        assert len(arr) == 0

    def test_create_boolean_array_with_specified_size(self):
        arr = array.new_bool(5)
        assert len(arr) == 5
        assert arr == [False, False, False, False, False]

    def test_create_boolean_array_with_initial_value(self):
        arr = array.new_bool(3, True)
        assert arr == [True, True, True]

    def test_handle_size_0_explicitly(self):
        arr = array.new_bool(0, True)
        assert arr == []


# ---------------------------------------------------------------------------
# array.new_float
# ---------------------------------------------------------------------------

class TestNewFloat:
    def test_create_empty_float_array_by_default(self):
        arr = array.new_float()
        assert arr == []
        assert len(arr) == 0

    def test_create_float_array_with_nan_by_default(self):
        arr = array.new_float(3)
        assert len(arr) == 3
        assert all(math.isnan(x) for x in arr)

    def test_create_float_array_with_initial_value(self):
        arr = array.new_float(4, 3.14)
        assert arr == [3.14, 3.14, 3.14, 3.14]

    def test_handle_decimal_values(self):
        arr = array.new_float(2, 0.5)
        assert arr == [0.5, 0.5]


# ---------------------------------------------------------------------------
# array.new_int
# ---------------------------------------------------------------------------

class TestNewInt:
    def test_create_empty_int_array_by_default(self):
        arr = array.new_int()
        assert arr == []
        assert len(arr) == 0

    def test_create_int_array_with_nan_by_default(self):
        arr = array.new_int(3)
        assert len(arr) == 3
        assert all(math.isnan(x) for x in arr)

    def test_create_int_array_with_initial_value(self):
        arr = array.new_int(5, 42)
        assert arr == [42, 42, 42, 42, 42]

    def test_handle_negative_values(self):
        arr = array.new_int(3, -10)
        assert arr == [-10, -10, -10]

    def test_handle_zero(self):
        arr = array.new_int(2, 0)
        assert arr == [0, 0]


# ---------------------------------------------------------------------------
# array.new_string
# ---------------------------------------------------------------------------

class TestNewString:
    def test_create_empty_string_array_by_default(self):
        arr = array.new_string()
        assert arr == []
        assert len(arr) == 0

    def test_create_string_array_with_none_by_default(self):
        arr = array.new_string(3)
        assert len(arr) == 3
        assert arr == [None, None, None]

    def test_create_string_array_with_initial_value(self):
        arr = array.new_string(4, "hello")
        assert arr == ["hello", "hello", "hello", "hello"]

    def test_handle_empty_string(self):
        arr = array.new_string(2, "")
        assert arr == ["", ""]

    def test_handle_special_characters(self):
        arr = array.new_string(2, "Hello \u4e16\u754c! \U0001f389")
        assert arr == ["Hello \u4e16\u754c! \U0001f389", "Hello \u4e16\u754c! \U0001f389"]


# ---------------------------------------------------------------------------
# array.new_color
# ---------------------------------------------------------------------------

class TestNewColor:
    def test_create_empty_color_array_by_default(self):
        arr = array.new_color()
        assert arr == []
        assert len(arr) == 0

    def test_create_color_array_with_none_by_default(self):
        arr = array.new_color(3)
        assert len(arr) == 3
        assert arr == [None, None, None]

    def test_create_color_array_with_hex_color(self):
        arr = array.new_color(3, "#FF0000")
        assert arr == ["#FF0000", "#FF0000", "#FF0000"]

    def test_create_color_array_with_numeric_color(self):
        arr = array.new_color(2, 0xFF0000)
        assert arr == [0xFF0000, 0xFF0000]

    def test_handle_rgb_strings(self):
        arr = array.new_color(2, "rgb(255, 0, 0)")
        assert arr == ["rgb(255, 0, 0)", "rgb(255, 0, 0)"]


# ---------------------------------------------------------------------------
# array.abs
# ---------------------------------------------------------------------------

class TestAbs:
    def test_return_absolute_values_of_all_elements(self):
        arr = [-1, -2, 3, -4, 5]
        result = array.abs(arr)
        assert result == [1, 2, 3, 4, 5]

    def test_handle_all_negative_values(self):
        arr = [-10, -20, -30]
        result = array.abs(arr)
        assert result == [10, 20, 30]

    def test_handle_all_positive_values(self):
        arr = [10, 20, 30]
        result = array.abs(arr)
        assert result == [10, 20, 30]

    def test_handle_mixed_positive_and_negative(self):
        arr = [5, -3, 0, -7, 2]
        result = array.abs(arr)
        assert result == [5, 3, 0, 7, 2]

    def test_handle_zero(self):
        arr = [0, -0]
        result = array.abs(arr)
        assert result == [0, 0]

    def test_handle_decimal_values(self):
        arr = [-1.5, 2.5, -3.7]
        result = array.abs(arr)
        assert result == [1.5, 2.5, 3.7]

    def test_handle_empty_array(self):
        arr: list[float] = []
        result = array.abs(arr)
        assert result == []

    def test_handle_nan_values(self):
        arr = [1, float("nan"), -3]
        result = array.abs(arr)
        assert result[0] == 1
        assert math.isnan(result[1])
        assert result[2] == 3

    def test_not_modify_original_array(self):
        arr = [-1, -2, -3]
        result = array.abs(arr)
        assert arr == [-1, -2, -3]
        assert result == [1, 2, 3]


# ---------------------------------------------------------------------------
# array.range
# ---------------------------------------------------------------------------

class TestRange:
    def test_return_difference_between_max_and_min(self):
        arr = [1, 5, 3, 9, 2]
        result = array.range(arr)
        assert result == 8  # 9 - 1

    def test_handle_all_positive_values(self):
        arr = [10, 20, 15, 25, 12]
        result = array.range(arr)
        assert result == 15  # 25 - 10

    def test_handle_all_negative_values(self):
        arr = [-10, -20, -5, -15]
        result = array.range(arr)
        assert result == 15  # -5 - (-20)

    def test_handle_mixed_positive_and_negative(self):
        arr = [-5, 10, -3, 8]
        result = array.range(arr)
        assert result == 15  # 10 - (-5)

    def test_return_0_for_identical_values(self):
        arr = [5, 5, 5, 5]
        result = array.range(arr)
        assert result == 0

    def test_handle_single_element(self):
        arr = [42]
        result = array.range(arr)
        assert result == 0

    def test_handle_two_elements(self):
        arr = [3, 7]
        result = array.range(arr)
        assert result == 4

    def test_return_nan_for_empty_array(self):
        arr: list[float] = []
        result = array.range(arr)
        assert math.isnan(result)

    def test_handle_decimal_values(self):
        arr = [1.5, 2.3, 0.8, 3.1]
        result = array.range(arr)
        assert result == pytest.approx(2.3)  # 3.1 - 0.8

    def test_handle_large_numbers(self):
        arr = [1000000, 5000000, 2000000]
        result = array.range(arr)
        assert result == 4000000  # 5000000 - 1000000

    def test_handle_very_small_differences(self):
        arr = [1.0001, 1.0002, 1.0003]
        result = array.range(arr)
        assert result == pytest.approx(0.0002)
