"""Tests for the linefill namespace — ported from linefill.test.ts."""

import pytest

from oakscriptpy import line, linefill


# --- linefill.new ---

class TestLinefillNew:
    def test_create_linefill_with_two_lines(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)

        fill = linefill.new(line1, line2)

        assert fill.line1 is line1
        assert fill.line2 is line2
        assert fill.color is None

    def test_create_linefill_with_color(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)

        fill = linefill.new(line1, line2, "#0000FF20")

        assert fill.color == "#0000FF20"

    def test_work_with_different_line_configurations(self):
        # Uptrending channel
        upper_up = line.new(0, 160, 50, 180, "bar_index", "right")
        lower_up = line.new(0, 140, 50, 160, "bar_index", "right")
        up_channel = linefill.new(upper_up, lower_up, "#00FF0020")

        assert up_channel.line1 is upper_up
        assert up_channel.line2 is lower_up

        # Downtrending channel
        upper_down = line.new(0, 160, 50, 150, "bar_index", "right")
        lower_down = line.new(0, 140, 50, 130, "bar_index", "right")
        down_channel = linefill.new(upper_down, lower_down, "#FF000020")

        assert down_channel.line1 is upper_down
        assert down_channel.line2 is lower_down


# --- linefill.get_line1 ---

class TestLinefillGetLine1:
    def test_return_first_line_reference(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        retrieved = linefill.get_line1(fill)

        assert retrieved is line1
        assert retrieved.x1 == 0
        assert retrieved.y1 == 160

    def test_allow_manipulating_retrieved_line(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        retrieved = linefill.get_line1(fill)
        line.set_y2(retrieved, 175)

        assert line1.y2 == 175
        assert fill.line1.y2 == 175


# --- linefill.get_line2 ---

class TestLinefillGetLine2:
    def test_return_second_line_reference(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        retrieved = linefill.get_line2(fill)

        assert retrieved is line2
        assert retrieved.x1 == 0
        assert retrieved.y1 == 140

    def test_allow_manipulating_retrieved_line(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        retrieved = linefill.get_line2(fill)
        line.set_y2(retrieved, 145)

        assert line2.y2 == 145
        assert fill.line2.y2 == 145


# --- linefill.set_color ---

class TestLinefillSetColor:
    def test_set_fill_color(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        linefill.set_color(fill, "#FF000030")

        assert fill.color == "#FF000030"

    def test_update_color_dynamically(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2, "#0000FF20")

        linefill.set_color(fill, "#00FF0020")
        assert fill.color == "#00FF0020"

        linefill.set_color(fill, "#FF000020")
        assert fill.color == "#FF000020"


# --- Real-world use cases ---

class TestLinefillRealWorld:
    def test_create_regression_channel_fill(self):
        upper = line.new(0, 165, 100, 175, "bar_index", "both")
        base = line.new(0, 155, 100, 165, "bar_index", "both")
        lower = line.new(0, 145, 100, 155, "bar_index", "both")

        upper_fill = linefill.new(upper, base, "#0000FF15")
        lower_fill = linefill.new(base, lower, "#0000FF15")

        assert upper_fill.line1 is upper
        assert upper_fill.line2 is base
        assert lower_fill.line1 is base
        assert lower_fill.line2 is lower

    def test_create_dynamic_channel_with_color_changes(self):
        upper_line = line.new(0, 160, 50, 170, "bar_index", "right")
        lower_line = line.new(0, 140, 50, 150, "bar_index", "right")
        channel = linefill.new(upper_line, lower_line, "#00FF0020")

        is_bullish = False
        if not is_bullish:
            linefill.set_color(channel, "#FF000020")

        assert channel.color == "#FF000020"

    def test_create_bollinger_bands_fill(self):
        upper_band = line.new(0, 160, 100, 165, "bar_index", "right")
        middle_band = line.new(0, 150, 100, 155, "bar_index", "right")
        lower_band = line.new(0, 140, 100, 145, "bar_index", "right")

        upper_fill = linefill.new(upper_band, middle_band, "#8080FF20")
        lower_fill = linefill.new(middle_band, lower_band, "#8080FF20")

        assert upper_fill.line1 is upper_band
        assert lower_fill.line2 is lower_band

    def test_update_channel_dynamically_by_manipulating_lines(self):
        upper_line = line.new(0, 160, 50, 170)
        lower_line = line.new(0, 140, 50, 150)
        channel = linefill.new(upper_line, lower_line, "#0000FF20")

        line.set_x2(upper_line, 75)
        line.set_y2(upper_line, 177.5)
        line.set_x2(lower_line, 75)
        line.set_y2(lower_line, 157.5)

        assert linefill.get_line1(channel).x2 == 75
        assert linefill.get_line2(channel).x2 == 75

    def test_create_fibonacci_extension_fills(self):
        fib618 = line.new(0, 162, 100, 162, "bar_index", "both")
        fib786 = line.new(0, 165, 100, 165, "bar_index", "both")
        fib1000 = line.new(0, 170, 100, 170, "bar_index", "both")

        fill618_786 = linefill.new(fib618, fib786, "#FFD70030")
        fill786_1000 = linefill.new(fib786, fib1000, "#FFD70030")

        assert fill618_786.line1 is fib618
        assert fill786_1000.line2 is fib1000

    def test_manage_multiple_channel_fills(self):
        st_upper = line.new(0, 160, 50, 170)
        st_lower = line.new(0, 140, 50, 150)
        short_term_channel = linefill.new(st_upper, st_lower, "#0000FF15")

        lt_upper = line.new(0, 165, 100, 180)
        lt_lower = line.new(0, 135, 100, 145)
        long_term_channel = linefill.new(lt_upper, lt_lower, "#FF000015")

        assert short_term_channel.line1 is st_upper
        assert long_term_channel.line1 is lt_upper
        assert short_term_channel.color != long_term_channel.color


# --- linefill.delete ---

class TestLinefillDelete:
    def test_exists_for_api_compatibility(self):
        line1 = line.new(0, 160, 50, 170)
        line2 = line.new(0, 140, 50, 150)
        fill = linefill.new(line1, line2)

        # Should not raise
        linefill.delete(fill)


# --- Edge cases ---

class TestLinefillEdgeCases:
    def test_handle_crossing_lines(self):
        ascending = line.new(0, 140, 50, 160)
        descending = line.new(0, 160, 50, 140)

        fill = linefill.new(ascending, descending)

        assert fill.line1 is ascending
        assert fill.line2 is descending

    def test_handle_parallel_horizontal_lines(self):
        upper = line.new(0, 160, 100, 160)
        lower = line.new(0, 140, 100, 140)

        fill = linefill.new(upper, lower, "#00FF0020")

        assert line.get_y1(fill.line1) == 160
        assert line.get_y1(fill.line2) == 140

    def test_handle_identical_lines(self):
        line1 = line.new(0, 150, 100, 160)
        line2 = line.new(0, 150, 100, 160)

        fill = linefill.new(line1, line2)

        assert fill.line1 is line1
        assert fill.line2 is line2

    def test_handle_lines_with_different_extends(self):
        extended_both = line.new(0, 160, 50, 170, "bar_index", "both")
        extended_right = line.new(0, 140, 50, 150, "bar_index", "right")

        fill = linefill.new(extended_both, extended_right)

        assert fill.line1.extend == "both"
        assert fill.line2.extend == "right"

    def test_handle_very_narrow_channels(self):
        upper = line.new(0, 150.1, 100, 160.1)
        lower = line.new(0, 150.0, 100, 160.0)

        fill = linefill.new(upper, lower, "#0000FF40")

        width = line.get_y1(fill.line1) - line.get_y1(fill.line2)
        assert width == pytest.approx(0.1)
