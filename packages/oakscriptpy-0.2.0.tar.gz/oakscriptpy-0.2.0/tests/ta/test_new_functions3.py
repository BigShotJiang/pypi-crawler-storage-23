"""Tests for ta.swma, ta.vwma, ta.linreg, ta.correlation, ta.percentrank
— ported from new_functions3.test.ts."""

import math

import pytest

from oakscriptpy import ta_core


class TestSwma:
    def test_should_calculate_symmetrically_weighted_moving_average_with_fixed_length_4(self):
        source = [1, 2, 3, 4, 5, 6, 7, 8]
        swma4 = ta_core.swma(source)

        # First 3 values should be NaN (need 4 bars)
        assert math.isnan(swma4[0])
        assert math.isnan(swma4[1])
        assert math.isnan(swma4[2])

        # Index 3: (1*1/6 + 2*2/6 + 3*2/6 + 4*1/6) = (1 + 4 + 6 + 4)/6 = 15/6 = 2.5
        assert swma4[3] == pytest.approx(2.5, abs=0.01)

        # Index 4: (2*1/6 + 3*2/6 + 4*2/6 + 5*1/6) = (2 + 6 + 8 + 5)/6 = 21/6 = 3.5
        assert swma4[4] == pytest.approx(3.5, abs=0.01)

    def test_should_handle_nan_values_correctly(self):
        source = [1, 2, float('nan'), 4, 5]
        result = ta_core.swma(source)

        # Index 3 should be NaN because it includes NaN value
        assert math.isnan(result[3])

    def test_should_work_with_symmetric_weights(self):
        source = [10, 20, 30, 40]
        result = ta_core.swma(source)

        # (10*1/6 + 20*2/6 + 30*2/6 + 40*1/6) = (10 + 40 + 60 + 40)/6 = 150/6 = 25
        assert result[3] == pytest.approx(25, abs=0.01)

    def test_should_handle_small_arrays(self):
        source = [1, 2]
        result = ta_core.swma(source)

        assert len(result) == 2
        assert all(math.isnan(v) for v in result)


class TestVwma:
    def test_should_calculate_volume_weighted_moving_average_correctly(self):
        price = [10, 20, 30, 40, 50]
        volume = [100, 200, 300, 400, 500]
        vwma3 = ta_core.vwma(price, 3, volume)

        assert math.isnan(vwma3[0])
        assert math.isnan(vwma3[1])

        # Index 2: sma([10*100, 20*200, 30*300], 3) / sma([100, 200, 300], 3)
        # = 14000/3 / 600/3 = 4666.67 / 200 = 23.33
        assert vwma3[2] == pytest.approx(23.33, abs=0.01)

    def test_should_give_higher_weight_to_high_volume_bars(self):
        price = [10, 10, 10]
        volume_equal = [100, 100, 100]
        volume_heavy = [100, 100, 1000]

        vwma_equal = ta_core.vwma(price, 3, volume_equal)
        vwma_heavy = ta_core.vwma(price, 3, volume_heavy)

        assert vwma_equal[2] == pytest.approx(10, abs=0.01)
        assert vwma_heavy[2] == pytest.approx(10, abs=0.01)

    def test_should_handle_varying_price_with_volume_weighting(self):
        price = [10, 20, 30]
        low_volume = [1000, 100, 100]
        result = ta_core.vwma(price, 3, low_volume)

        # sma([10000, 2000, 3000]) / sma([1000, 100, 100]) = 5000 / 400 = 12.5
        assert result[2] == pytest.approx(12.5, abs=0.01)

    def test_should_throw_error_when_volume_is_not_provided(self):
        price = [10, 20, 30]
        with pytest.raises(ValueError, match='requires volume series'):
            ta_core.vwma(price, 3)

    def test_should_handle_zero_volume_correctly(self):
        price = [10, 20, 30]
        volume = [0, 0, 0]
        result = ta_core.vwma(price, 3, volume)

        assert math.isnan(result[2])


class TestLinreg:
    def test_should_calculate_linear_regression_correctly(self):
        source = [1, 2, 3, 4, 5, 6, 7, 8]
        linreg5 = ta_core.linreg(source, 5, 0)

        assert math.isnan(linreg5[0])
        assert math.isnan(linreg5[3])

        # For perfectly linear data, linreg should match the actual value
        assert linreg5[4] == pytest.approx(5, abs=0.1)
        assert linreg5[7] == pytest.approx(8, abs=0.1)

    def test_should_project_forward_with_positive_offset(self):
        source = [1, 2, 3, 4, 5]
        linreg5_offset1 = ta_core.linreg(source, 5, 1)
        linreg5_offset0 = ta_core.linreg(source, 5, 0)

        # With offset=1, should project one bar back (lower value for uptrend)
        assert linreg5_offset1[4] < linreg5_offset0[4]

    def test_should_handle_non_linear_data(self):
        source = [10, 12, 11, 13, 14, 12, 15, 16]
        linreg5 = ta_core.linreg(source, 5, 0)

        assert len(linreg5) == len(source)
        assert not math.isnan(linreg5[4])

    def test_should_work_with_default_offset_of_0(self):
        source = [1, 2, 3, 4, 5]
        linreg_default = ta_core.linreg(source, 5)
        linreg_zero = ta_core.linreg(source, 5, 0)

        assert linreg_default[4] == linreg_zero[4]

    def test_should_calculate_slope_correctly_for_uptrend(self):
        uptrend = [10, 11, 12, 13, 14]
        result = ta_core.linreg(uptrend, 5, 0)

        assert result[4] == pytest.approx(14, abs=0.1)


class TestCorrelation:
    def test_should_return_1_for_perfectly_correlated_series(self):
        source1 = [1, 2, 3, 4, 5]
        source2 = [2, 4, 6, 8, 10]
        corr = ta_core.correlation(source1, source2, 5)

        assert corr[4] == pytest.approx(1.0, abs=0.01)

    def test_should_return_minus_1_for_perfectly_negatively_correlated_series(self):
        source1 = [1, 2, 3, 4, 5]
        source2 = [10, 9, 8, 7, 6]
        corr = ta_core.correlation(source1, source2, 5)

        assert corr[4] == pytest.approx(-1.0, abs=0.01)

    def test_should_return_nan_for_uncorrelated_constant_series(self):
        source1 = [5, 5, 5, 5, 5]  # Constant
        source2 = [1, 2, 3, 4, 5]
        corr = ta_core.correlation(source1, source2, 5)

        assert math.isnan(corr[4])

    def test_should_handle_varying_correlation_over_time(self):
        source1 = [1, 2, 3, 4, 5, 6, 7, 8]
        source2 = [1, 2, 3, 4, 5, 5, 4, 3]  # Correlated then diverges
        corr = ta_core.correlation(source1, source2, 4)

        # Early correlation should be high
        assert corr[3] == pytest.approx(1.0, abs=0.1)

        # Later correlation should be lower as they diverge
        assert abs(corr[7]) < 1.0

    def test_should_return_nan_for_insufficient_data(self):
        source1 = [1, 2, 3]
        source2 = [4, 5, 6]
        corr = ta_core.correlation(source1, source2, 5)

        assert all(math.isnan(v) for v in corr)

    def test_should_handle_partial_correlation(self):
        source1 = [1, 3, 2, 4, 3, 5]
        source2 = [2, 4, 3, 5, 4, 6]
        corr = ta_core.correlation(source1, source2, 4)

        assert corr[5] > 0
        assert corr[5] <= 1


class TestPercentrank:
    def test_should_return_100_when_current_is_higher_than_all_previous(self):
        source = [1, 2, 3, 4, 5, 6]
        prank = ta_core.percentrank(source, 5)

        # i=5, previous 5 = [1,2,3,4,5], current=6. All 5 <= 6. 5/5*100 = 100
        assert prank[5] == 100

    def test_should_return_0_when_current_is_lower_than_all_previous(self):
        source = [6, 5, 4, 3, 2, 1]
        prank = ta_core.percentrank(source, 5)

        # i=5, previous 5 = [6,5,4,3,2], current=1. 0 <= 1. 0/5*100 = 0
        assert prank[5] == 0

    def test_should_calculate_partial_percentrank_correctly(self):
        source = [1, 2, 3, 4, 5, 3]
        prank = ta_core.percentrank(source, 5)

        # i=5, previous 5 = [1,2,3,4,5], current=3. {1,2,3} <= 3 = 3. 3/5*100 = 60
        assert prank[5] == 60

    def test_should_handle_duplicate_values(self):
        source = [1, 2, 2, 2, 3, 2]
        prank = ta_core.percentrank(source, 5)

        # i=5, previous 5 = [1,2,2,2,3], current=2. {1,2,2,2} <= 2 = 4. 4/5*100 = 80
        assert prank[5] == 80

    def test_should_return_nan_for_insufficient_data(self):
        source = [1, 2, 3, 4, 5]
        prank = ta_core.percentrank(source, 5)

        for i in range(5):
            assert math.isnan(prank[i])

    def test_should_calculate_correctly_in_a_rolling_window(self):
        source = [10, 20, 30, 40, 50, 60, 70, 80]
        prank = ta_core.percentrank(source, 5)

        assert prank[5] == 100
        assert prank[6] == 100
        assert prank[7] == 100
