"""Integration tests for ta_series with Series — ported from ta-series-integration.test.ts."""

import math

from oakscriptpy._types import Bar
from oakscriptpy.series import Series
from oakscriptpy import ta_series as ta


class TestTaSeriesIntegration:
    def test_should_return_correct_length_array_with_data(self):
        bars = [
            Bar(
                time=1609459200 + i * 86400,
                open=100 + i * 0.1,
                high=110 + i * 0.1,
                low=90 + i * 0.1,
                close=100 + i * 0.1,
                volume=1000000,
            )
            for i in range(100)
        ]

        close = Series(bars, lambda bar, _i, _d: bar.close)
        sma_series = ta.sma(close, 9)
        sma_values = sma_series.to_array()

        # Should return array with same length as input
        assert len(sma_values) == len(bars)

        # Should contain actual data (not all NaN)
        non_nan_count = sum(1 for v in sma_values if not math.isnan(v))
        assert non_nan_count > 0

        # First 8 values should be NaN (period - 1)
        for i in range(8):
            assert math.isnan(sma_values[i])

        # 9th value and onwards should have data
        assert not math.isnan(sma_values[8])
        assert sma_values[8] == _approx(100.4, abs=0.1)

    def test_should_work_with_multiple_ta_functions(self):
        bars = [
            Bar(
                time=1609459200 + i * 86400,
                open=100 + i * 0.5,
                high=110 + i * 0.5,
                low=90 + i * 0.5,
                close=100 + i * 0.5,
                volume=1000000,
            )
            for i in range(50)
        ]

        close = Series(bars, lambda bar, _i, _d: bar.close)

        sma_series = ta.sma(close, 5)
        ema_series = ta.ema(close, 5)
        wma_series = ta.wma(close, 5)
        rma_series = ta.rma(close, 5)

        # All should return correct length
        assert len(sma_series.to_array()) == len(bars)
        assert len(ema_series.to_array()) == len(bars)
        assert len(wma_series.to_array()) == len(bars)
        assert len(rma_series.to_array()) == len(bars)

        # All should have non-NaN values
        assert sum(1 for v in sma_series.to_array() if not math.isnan(v)) > 0
        assert sum(1 for v in ema_series.to_array() if not math.isnan(v)) > 0
        assert sum(1 for v in wma_series.to_array() if not math.isnan(v)) > 0
        assert sum(1 for v in rma_series.to_array() if not math.isnan(v)) > 0


def _approx(expected, abs=1e-6):
    """Helper that returns a pytest.approx-compatible value for use in assert ==."""
    import pytest
    return pytest.approx(expected, abs=abs)
