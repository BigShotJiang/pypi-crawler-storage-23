"""Tests for ta.supertrend — ported from supertrend.test.ts."""

import math

from oakscriptpy import ta_core


class TestSupertrend:
    def test_should_calculate_supertrend_correctly_with_basic_data(self):
        high = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
        low = [9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
        close = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

        supertrend, direction = ta_core.supertrend(3, 3, high, low, close, False)

        assert len(supertrend) == 10
        assert len(direction) == 10

        # All direction values should be 1 or -1
        for d in direction:
            assert d in [1, -1]

        # SuperTrend values should be numbers
        for st in supertrend:
            assert isinstance(st, (int, float))

    def test_should_detect_uptrend_correctly(self):
        high = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        low = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        close = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

        supertrend, direction = ta_core.supertrend(3, 3, high, low, close, False)

        up_count = sum(1 for d in direction[5:] if d == 1)
        assert up_count > 0

    def test_should_detect_downtrend_correctly(self):
        high = [21, 20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10]
        low = [19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9, 8]
        close = [20, 19, 18, 17, 16, 15, 14, 13, 12, 11, 10, 9]

        supertrend, direction = ta_core.supertrend(1.5, 3, high, low, close, False)

        unique_directions = set(d for d in direction if not math.isnan(d))
        assert len(unique_directions) > 0

    def test_should_handle_trend_reversal(self):
        high = [12, 13, 14, 15, 17, 19, 18, 16, 14, 12, 10, 8]
        low = [10, 11, 12, 13, 15, 17, 16, 14, 12, 10, 8, 6]
        close = [11, 12, 13, 14, 16, 18, 17, 15, 13, 11, 9, 7]

        supertrend, direction = ta_core.supertrend(2, 3, high, low, close, False)

        assert len(supertrend) == 12
        assert len(direction) == 12

        valid_directions = [d for d in direction if not math.isnan(d)]
        for d in valid_directions:
            assert d in [1, -1]

    def test_should_work_with_different_factor_values(self):
        high = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        low = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        close = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

        st1, dir1 = ta_core.supertrend(1, 3, high, low, close)
        st2, dir2 = ta_core.supertrend(5, 3, high, low, close)

        assert len(st1) == 10
        assert len(st2) == 10
        assert len(dir1) == 10
        assert len(dir2) == 10

        for st in st1:
            assert isinstance(st, (int, float))
        for st in st2:
            assert isinstance(st, (int, float))

    def test_should_work_with_different_atr_lengths(self):
        high = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        low = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        close = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

        st1, dir1 = ta_core.supertrend(3, 3, high, low, close)
        st2, dir2 = ta_core.supertrend(3, 10, high, low, close)

        assert len(st1) == 10
        assert len(st2) == 10
        assert len(dir1) == 10
        assert len(dir2) == 10

    def test_should_handle_wicks_parameter_correctly(self):
        high = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21]
        low = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
        close = [11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

        st_no_wicks, dir_no_wicks = ta_core.supertrend(3, 3, high, low, close, False)
        st_wicks, dir_wicks = ta_core.supertrend(3, 3, high, low, close, True)

        assert len(st_no_wicks) == 10
        assert len(st_wicks) == 10

        for st in st_no_wicks:
            assert isinstance(st, (int, float))
        for st in st_wicks:
            assert isinstance(st, (int, float))

    def test_should_handle_minimum_data_correctly(self):
        high = [11, 12, 13]
        low = [9, 10, 11]
        close = [10, 11, 12]

        supertrend, direction = ta_core.supertrend(3, 2, high, low, close)

        assert len(supertrend) == 3
        assert len(direction) == 3

        # Initial direction should be 1 (uptrend)
        assert direction[0] == 1

    def test_should_maintain_trend_in_stable_upward_movement(self):
        high = [11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39]
        low = [9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37]
        close = [10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38]

        supertrend, direction = ta_core.supertrend(1, 3, high, low, close)

        valid_count = sum(1 for st in supertrend if not math.isnan(st))
        assert valid_count > 0

        # Check that when direction = -1 (uptrend in supertrend convention), supertrend is below close
        for i in range(5, len(supertrend)):
            if not math.isnan(supertrend[i]) and direction[i] == -1:
                assert supertrend[i] < close[i]

    def test_should_handle_sideways_market(self):
        high = [12, 13, 12, 13, 12, 13, 12, 13, 12, 13]
        low = [10, 11, 10, 11, 10, 11, 10, 11, 10, 11]
        close = [11, 12, 11, 12, 11, 12, 11, 12, 11, 12]

        supertrend, direction = ta_core.supertrend(3, 3, high, low, close)

        assert len(supertrend) == 10
        assert len(direction) == 10

        unique_directions = set(direction)
        assert len(unique_directions) >= 1
