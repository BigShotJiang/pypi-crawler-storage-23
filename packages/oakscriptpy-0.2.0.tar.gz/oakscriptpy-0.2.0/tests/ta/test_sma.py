"""Tests for ta.sma — ported from sma.test.ts."""

import math

from oakscriptpy import ta_core


class TestSma:
    def test_should_calculate_simple_moving_average_correctly(self):
        source = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        result = ta_core.sma(source, 3)

        assert math.isnan(result[0])
        assert math.isnan(result[1])
        assert result[2] == 2  # (1+2+3)/3 = 2
        assert result[3] == 3  # (2+3+4)/3 = 3
        assert result[4] == 4  # (3+4+5)/3 = 4
        assert result[9] == 9  # (8+9+10)/3 = 9

    def test_should_handle_length_of_1(self):
        source = [1, 2, 3, 4, 5]
        result = ta_core.sma(source, 1)

        assert result == source

    def test_should_handle_empty_array(self):
        source = []
        result = ta_core.sma(source, 3)

        assert result == []

    def test_should_match_pinescript_behavior_for_period_5(self):
        source = [10, 12, 11, 13, 15, 14, 16, 18, 17, 19]
        result = ta_core.sma(source, 5)

        assert result[4] == (10 + 12 + 11 + 13 + 15) / 5
        assert result[9] == (14 + 16 + 18 + 17 + 19) / 5
