"""Tests for string search functions: contains, pos, replace."""

from oakscriptpy import str_ as str_mod


# --- str.contains ---

class TestContains:
    def test_contains_substring(self):
        assert str_mod.contains("hello world", "hello") is True
        assert str_mod.contains("hello world", "world") is True
        assert str_mod.contains("hello world", "lo wo") is True
        assert str_mod.contains("test", "test") is True

    def test_does_not_contain(self):
        assert str_mod.contains("hello world", "goodbye") is False
        assert str_mod.contains("hello world", "xyz") is False
        assert str_mod.contains("test", "testing") is False

    def test_case_sensitive(self):
        assert str_mod.contains("hello world", "Hello") is False
        assert str_mod.contains("hello world", "WORLD") is False
        assert str_mod.contains("hello world", "hello") is True

    def test_empty_substring(self):
        assert str_mod.contains("hello", "") is True
        assert str_mod.contains("", "") is True

    def test_empty_source(self):
        assert str_mod.contains("", "hello") is False

    def test_special_characters(self):
        assert str_mod.contains("hello@world.com", "@") is True
        assert str_mod.contains("price: $100", "$100") is True
        assert str_mod.contains("a-b-c", "-") is True


# --- str.pos ---

class TestPos:
    def test_index_of_first_occurrence(self):
        assert str_mod.pos("hello world", "hello") == 0
        assert str_mod.pos("hello world", "world") == 6
        assert str_mod.pos("hello world", "o") == 4

    def test_not_found_returns_minus_1(self):
        assert str_mod.pos("hello world", "goodbye") == -1
        assert str_mod.pos("hello world", "xyz") == -1
        assert str_mod.pos("test", "testing") == -1

    def test_case_sensitive(self):
        assert str_mod.pos("hello world", "Hello") == -1
        assert str_mod.pos("hello world", "WORLD") == -1
        assert str_mod.pos("hello world", "hello") == 0

    def test_empty_substring(self):
        assert str_mod.pos("hello", "") == 0
        assert str_mod.pos("", "") == 0

    def test_empty_source(self):
        assert str_mod.pos("", "hello") == -1

    def test_first_occurrence_when_multiple(self):
        assert str_mod.pos("hello hello", "hello") == 0
        assert str_mod.pos("test test test", "test") == 0
        assert str_mod.pos("abcabc", "abc") == 0

    def test_special_characters(self):
        assert str_mod.pos("hello@world.com", "@") == 5
        assert str_mod.pos("price: $100", "$") == 7
        assert str_mod.pos("a-b-c", "-") == 1


# --- str.replace ---

class TestReplace:
    def test_replace_first_occurrence_when_0(self):
        assert str_mod.replace("hello world hello", "hello", "goodbye", 0) == "goodbye world hello"
        assert str_mod.replace("test test test", "test", "exam", 0) == "exam test test"

    def test_replace_all_when_not_0(self):
        assert str_mod.replace("hello world hello", "hello", "goodbye", 1) == "goodbye world goodbye"
        assert str_mod.replace("test test test", "test", "exam", 1) == "exam exam exam"
        assert str_mod.replace("hello world hello", "hello", "goodbye") == "goodbye world goodbye"

    def test_no_matches(self):
        assert str_mod.replace("hello world", "goodbye", "hello", 0) == "hello world"
        assert str_mod.replace("hello world", "xyz", "abc", 1) == "hello world"

    def test_case_sensitive(self):
        assert str_mod.replace("hello world", "Hello", "goodbye", 0) == "hello world"
        assert str_mod.replace("hello world", "WORLD", "earth", 1) == "hello world"

    def test_empty_strings(self):
        assert str_mod.replace("", "hello", "goodbye", 0) == ""
        assert str_mod.replace("hello", "", "x", 0) == "xhello"

    def test_special_characters(self):
        assert str_mod.replace("hello@world.com", "@", " at ", 0) == "hello at world.com"
        assert str_mod.replace("$100 + $200", "$", "USD", 1) == "USD100 + USD200"

    def test_replacement_with_empty(self):
        assert str_mod.replace("hello world", "hello ", "", 0) == "world"
        assert str_mod.replace("a-b-c", "-", "", 1) == "abc"

    def test_same_source_and_target(self):
        assert str_mod.replace("hello", "hello", "hello", 0) == "hello"
        assert str_mod.replace("test", "test", "test", 1) == "test"
