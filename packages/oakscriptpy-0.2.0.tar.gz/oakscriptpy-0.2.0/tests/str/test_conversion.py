"""Tests for string conversion functions: length, tostring, tonumber."""

import math

import pytest

from oakscriptpy import str_ as str_mod


# --- str.length ---

class TestLength:
    def test_string_length(self):
        assert str_mod.length("hello") == 5
        assert str_mod.length("world") == 5
        assert str_mod.length("test") == 4

    def test_empty_string(self):
        assert str_mod.length("") == 0

    def test_special_characters(self):
        assert str_mod.length("hello!") == 6
        assert str_mod.length("test@123") == 8
        assert str_mod.length("a b c") == 5

    def test_unicode_characters(self):
        # Python len counts Unicode code points, not UTF-16 units like JS
        # 'hello 👋' is 7 in Python (emoji is 1 code point), 8 in JS (surrogate pair)
        assert str_mod.length("hello \U0001f44b") == 7
        assert str_mod.length("cafe\u0301") == 5  # 'cafe' + combining accent


# --- str.tostring ---

class TestTostring:
    def test_numbers_to_strings(self):
        assert str_mod.tostring(123) == "123"
        assert str_mod.tostring(45.67) == "45.67"
        assert str_mod.tostring(-89) == "-89"
        assert str_mod.tostring(0) == "0"

    def test_boolean_to_strings(self):
        assert str_mod.tostring(True) == "True"
        assert str_mod.tostring(False) == "False"

    def test_none(self):
        assert str_mod.tostring(None) == "None"

    def test_format_numbers_with_format_string(self):
        assert str_mod.tostring(123.456, "#.##") == "123.46"
        assert str_mod.tostring(123.456, "#.#") == "123.5"
        assert str_mod.tostring(123.456, "#") == "123"
        assert str_mod.tostring(123, "#.##") == "123.00"

    def test_already_string_values(self):
        assert str_mod.tostring("hello") == "hello"
        assert str_mod.tostring("") == ""

    def test_special_numeric_values(self):
        assert str_mod.tostring(float("nan")) == "nan"
        assert str_mod.tostring(float("inf")) == "inf"
        assert str_mod.tostring(float("-inf")) == "-inf"


# --- str.tonumber ---

class TestTonumber:
    def test_valid_number_strings(self):
        assert str_mod.tonumber("123") == 123
        assert str_mod.tonumber("45.67") == 45.67
        assert str_mod.tonumber("-89") == -89
        assert str_mod.tonumber("0") == 0

    def test_strings_with_whitespace(self):
        assert str_mod.tonumber("  123  ") == 123
        assert str_mod.tonumber("45.67\n") == 45.67

    def test_invalid_strings_return_none(self):
        assert str_mod.tonumber("abc") is None
        assert str_mod.tonumber("hello") is None
        # Python float() rejects '12abc', unlike JS parseFloat
        assert str_mod.tonumber("12abc") is None
        assert str_mod.tonumber("abc123") is None

    def test_empty_string(self):
        assert str_mod.tonumber("") is None

    def test_special_numeric_strings(self):
        # Python float('NaN') returns nan, not None
        result = str_mod.tonumber("NaN")
        assert result is not None and math.isnan(result)
        assert str_mod.tonumber("Infinity") == float("inf")
        assert str_mod.tonumber("-Infinity") == float("-inf")

    def test_scientific_notation(self):
        assert str_mod.tonumber("1e3") == 1000
        assert str_mod.tonumber("1.5e2") == 150
        assert str_mod.tonumber("1e-3") == 0.001

    def test_decimal_numbers(self):
        assert str_mod.tonumber("0.5") == 0.5
        assert str_mod.tonumber(".5") == 0.5
        assert str_mod.tonumber("-.5") == -0.5
