"""Tests for string predicate functions: startswith, endswith, charAt."""

from oakscriptpy import str_ as str_mod


# --- str.startswith ---

class TestStartswith:
    def test_starts_with_prefix(self):
        assert str_mod.startswith("hello world", "hello") is True
        assert str_mod.startswith("test", "test") is True
        assert str_mod.startswith("testing", "test") is True
        assert str_mod.startswith("abc123", "abc") is True

    def test_does_not_start_with_prefix(self):
        assert str_mod.startswith("hello world", "world") is False
        assert str_mod.startswith("test", "testing") is False
        assert str_mod.startswith("hello", "goodbye") is False

    def test_case_sensitive(self):
        assert str_mod.startswith("hello world", "Hello") is False
        assert str_mod.startswith("Test", "test") is False
        assert str_mod.startswith("hello world", "hello") is True

    def test_empty_prefix(self):
        assert str_mod.startswith("hello", "") is True
        assert str_mod.startswith("test", "") is True
        assert str_mod.startswith("", "") is True

    def test_empty_source_string(self):
        assert str_mod.startswith("", "hello") is False
        assert str_mod.startswith("", "test") is False

    def test_prefix_longer_than_source(self):
        assert str_mod.startswith("hi", "hello") is False
        assert str_mod.startswith("test", "testing") is False

    def test_special_characters(self):
        assert str_mod.startswith("$100", "$") is True
        assert str_mod.startswith("@user", "@") is True
        assert str_mod.startswith("hello@world", "hello") is True


# --- str.endswith ---

class TestEndswith:
    def test_ends_with_suffix(self):
        assert str_mod.endswith("hello world", "world") is True
        assert str_mod.endswith("test", "test") is True
        assert str_mod.endswith("testing", "ing") is True
        assert str_mod.endswith("abc123", "123") is True

    def test_does_not_end_with_suffix(self):
        assert str_mod.endswith("hello world", "hello") is False
        assert str_mod.endswith("testing", "test") is False
        assert str_mod.endswith("hello", "goodbye") is False

    def test_case_sensitive(self):
        assert str_mod.endswith("hello world", "World") is False
        assert str_mod.endswith("Test", "TEST") is False
        assert str_mod.endswith("hello world", "world") is True

    def test_empty_suffix(self):
        assert str_mod.endswith("hello", "") is True
        assert str_mod.endswith("test", "") is True
        assert str_mod.endswith("", "") is True

    def test_empty_source_string(self):
        assert str_mod.endswith("", "hello") is False
        assert str_mod.endswith("", "test") is False

    def test_suffix_longer_than_source(self):
        assert str_mod.endswith("hi", "hello") is False
        assert str_mod.endswith("ing", "testing") is False

    def test_special_characters(self):
        assert str_mod.endswith("price$", "$") is True
        assert str_mod.endswith("user@", "@") is True
        assert str_mod.endswith("hello@world.com", ".com") is True


# --- str.char_at (JS: str.charAt) ---

class TestCharAt:
    def test_character_at_position(self):
        assert str_mod.char_at("hello", 0) == "h"
        assert str_mod.char_at("hello", 1) == "e"
        assert str_mod.char_at("hello", 4) == "o"
        assert str_mod.char_at("world", 2) == "r"

    def test_out_of_bounds_returns_empty(self):
        assert str_mod.char_at("hello", 5) == ""
        assert str_mod.char_at("hello", 10) == ""
        assert str_mod.char_at("test", -1) == ""

    def test_empty_string(self):
        assert str_mod.char_at("", 0) == ""
        assert str_mod.char_at("", 5) == ""

    def test_special_characters(self):
        assert str_mod.char_at("hello@world", 5) == "@"
        assert str_mod.char_at("$100", 0) == "$"
        assert str_mod.char_at("a-b-c", 1) == "-"

    def test_whitespace(self):
        assert str_mod.char_at("hello world", 5) == " "
        assert str_mod.char_at("a b c", 1) == " "

    def test_unicode_characters(self):
        # In Python, "cafe\u0301" is c(0), a(1), f(2), e(3), \u0301(4)
        # Position 3 is 'e', position 4 is the combining accent
        assert str_mod.char_at("cafe\u0301", 3) == "e"
        assert str_mod.char_at("cafe\u0301", 4) == "\u0301"
        # In Python, emoji is a single code point
        result = str_mod.char_at("hello \U0001f44b", 6)
        assert result == "\U0001f44b"

    def test_first_and_last_positions(self):
        text = "testing"
        assert str_mod.char_at(text, 0) == "t"
        assert str_mod.char_at(text, len(text) - 1) == "g"
