"""Linefill namespace — mirrors PineScript linefill.* functions."""

from __future__ import annotations

from ._types import Linefill, Line


def new(line1: Line, line2: Line, color: str | int | None = None) -> Linefill:
    return Linefill(line1=line1, line2=line2, color=color)


def get_line1(id: Linefill) -> Line:
    return id.line1


def get_line2(id: Linefill) -> Line:
    return id.line2


def set_color(id: Linefill, color: str | int) -> Linefill:
    id.color = color
    return id


def delete(id: Linefill) -> None:
    pass
