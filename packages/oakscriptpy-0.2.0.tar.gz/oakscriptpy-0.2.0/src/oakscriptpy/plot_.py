"""Plot helper — prepares data for charting."""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


@dataclass
class TimeValuePair:
    time: int | str
    value: float


@dataclass
class PlotResult:
    id: str
    data: list[TimeValuePair]
    options: dict[str, Any]


def plot(
    values: list[float | None],
    times: list[int | str],
    color: str | None = None,
    title: str | None = None,
    line_width: int | None = None,
    line_style: str | None = None,
    offset: int = 0,
) -> list[TimeValuePair]:
    result: list[TimeValuePair] = []
    for i, v in enumerate(values):
        if v is None or (isinstance(v, float) and math.isnan(v)):
            continue
        time_index = i + offset
        if time_index < 0 or time_index >= len(times):
            continue
        result.append(TimeValuePair(time=times[time_index], value=v))
    return result


def create_plot(
    id: str,
    values: list[float | None],
    times: list[int | str],
    **options: Any,
) -> PlotResult:
    return PlotResult(id=id, data=plot(values, times, **options), options=options)
