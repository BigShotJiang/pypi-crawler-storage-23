"""Series-based TA wrappers — accepts/returns Series objects."""

from __future__ import annotations

from . import ta as ta_core
from ._types import Bar
from .series import Series


def _bars_from(s: Series) -> list[Bar]:
    return s.bars


def _wrap(bars: list[Bar] | Series, values: list[float]) -> Series:
    return Series.from_array(bars if isinstance(bars, list) else bars.bar_data, values)


# --- Moving Averages ---

def sma(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.sma(source.to_array(), length))


def ema(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.ema(source.to_array(), length))


def wma(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.wma(source.to_array(), length))


def rma(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.rma(source.to_array(), length))


def vwma(source: Series, length: int, volume: Series) -> Series:
    return _wrap(source, ta_core.vwma(source.to_array(), length, volume.to_array()))


def hma(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.hma(source.to_array(), length))


def alma(source: Series, length: int = 9, offset: float = 0.85, sigma: float = 6, floor: bool = False) -> Series:
    return _wrap(source, ta_core.alma(source.to_array(), length, offset, sigma, floor))


def swma(source: Series) -> Series:
    return _wrap(source, ta_core.swma(source.to_array()))


def linreg(source: Series, length: int, offset: int = 0) -> Series:
    return _wrap(source, ta_core.linreg(source.to_array(), length, offset))


# --- Oscillators ---

def rsi(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.rsi(source.to_array(), length))


def stoch(source: Series, high: Series, low: Series, length: int) -> Series:
    return _wrap(source, ta_core.stoch(source.to_array(), high.to_array(), low.to_array(), length))


def cci(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.cci(source.to_array(), length))


def cmo(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.cmo(source.to_array(), length))


def tsi(source: Series, short_length: int, long_length: int) -> Series:
    return _wrap(source, ta_core.tsi(source.to_array(), short_length, long_length))


def mfi(source: Series, length: int, volume: Series) -> Series:
    return _wrap(source, ta_core.mfi(source.to_array(), length, volume.to_array()))


def cog(source: Series, length: int = 10) -> Series:
    return _wrap(source, ta_core.cog(source.to_array(), length))


def rci(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.rci(source.to_array(), length))


def percentrank(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.percentrank(source.to_array(), length))


# --- Bands & Channels ---

def macd(source: Series, fast_length: int, slow_length: int, signal_length: int) -> tuple[Series, Series, Series]:
    vals = ta_core.macd(source.to_array(), fast_length, slow_length, signal_length)
    return _wrap(source, vals[0]), _wrap(source, vals[1]), _wrap(source, vals[2])


def bb(source: Series, length: int, mult: float) -> tuple[Series, Series, Series]:
    upper, basis, lower = ta_core.bb(source.to_array(), length, mult)
    return _wrap(source, upper), _wrap(source, basis), _wrap(source, lower)


def bbw(source: Series, length: int, mult: float) -> Series:
    return _wrap(source, ta_core.bbw(source.to_array(), length, mult))


def kc(bars: list[Bar], source: Series, length: int, mult: float, use_true_range: bool = True) -> tuple[Series, Series, Series]:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    middle, upper, lower = ta_core.kc(source.to_array(), length, mult, use_true_range, high, low, close)
    return _wrap(bars, middle), _wrap(bars, upper), _wrap(bars, lower)


def kcw(bars: list[Bar], source: Series, length: int = 20, mult: float = 2, use_true_range: bool = True) -> Series:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    return _wrap(bars, ta_core.kcw(source.to_array(), length, mult, use_true_range, high, low, close))


# --- Volatility ---

def stdev(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.stdev(source.to_array(), length))


def variance(source: Series, length: int, biased: bool = True) -> Series:
    return _wrap(source, ta_core.variance(source.to_array(), length, biased))


def dev(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.dev(source.to_array(), length))


def atr(bars: list[Bar], length: int) -> Series:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    return _wrap(bars, ta_core.atr(length, high, low, close))


def tr(bars: list[Bar], handle_na: bool = False) -> Series:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    return _wrap(bars, ta_core.tr(handle_na, high, low, close))


# --- Trend ---

def supertrend(bars: list[Bar], factor: float, atr_length: int) -> tuple[Series, Series]:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    trend_vals, dir_vals = ta_core.supertrend(factor, atr_length, high, low, close)
    return _wrap(bars, trend_vals), _wrap(bars, dir_vals)


def vwap(source: Series, volume: Series) -> Series:
    return _wrap(source, ta_core.vwap(source.to_array(), volume.to_array()))


def sar(bars: list[Bar], start: float = 0.02, inc: float = 0.02, max_val: float = 0.2) -> Series:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    return _wrap(bars, ta_core.sar(start, inc, max_val, high, low, close))


def ichimoku(
    bars: list[Bar], conversion_periods: int, base_periods: int,
    lagging_span2_periods: int, displacement: int,
) -> tuple[Series, Series, Series, Series, Series]:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    tenkan, kijun, senkou_a, senkou_b, chikou = ta_core.ichimoku(
        conversion_periods, base_periods, lagging_span2_periods, displacement, high, low, close,
    )
    return (
        _wrap(bars, tenkan), _wrap(bars, kijun),
        _wrap(bars, senkou_a), _wrap(bars, senkou_b), _wrap(bars, chikou),
    )


def dmi(bars: list[Bar], di_length: int, adx_smoothing: int) -> tuple[Series, Series, Series]:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    plus_di, minus_di, adx = ta_core.dmi(di_length, adx_smoothing, high, low, close)
    return _wrap(bars, plus_di), _wrap(bars, minus_di), _wrap(bars, adx)


# --- Cross Detection ---

def crossover(source1: Series, source2: Series | float | int) -> Series:
    vals1 = source1.to_array()
    if isinstance(source2, Series):
        vals2 = source2.to_array()
    else:
        vals2 = [float(source2)] * len(vals1)
    result = ta_core.crossover(vals1, vals2)
    return _wrap(source1, [1.0 if b else 0.0 for b in result])


def crossunder(source1: Series, source2: Series | float | int) -> Series:
    vals1 = source1.to_array()
    if isinstance(source2, Series):
        vals2 = source2.to_array()
    else:
        vals2 = [float(source2)] * len(vals1)
    result = ta_core.crossunder(vals1, vals2)
    return _wrap(source1, [1.0 if b else 0.0 for b in result])


def cross(source1: Series, source2: Series | float | int) -> Series:
    vals1 = source1.to_array()
    if isinstance(source2, Series):
        vals2 = source2.to_array()
    else:
        vals2 = [float(source2)] * len(vals1)
    result = ta_core.cross(vals1, vals2)
    return _wrap(source1, [1.0 if b else 0.0 for b in result])


# --- Momentum ---

def change(source: Series, length: int = 1) -> Series:
    return _wrap(source, ta_core.change(source.to_array(), length))


def mom(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.mom(source.to_array(), length))


def roc(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.roc(source.to_array(), length))


# --- Extremes ---

def highest(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.highest(source.to_array(), length))


def lowest(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.lowest(source.to_array(), length))


def highestbars(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.highestbars(source.to_array(), length))


def lowestbars(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.lowestbars(source.to_array(), length))


# --- Detection ---

def rising(source: Series, length: int) -> Series:
    result = ta_core.rising(source.to_array(), length)
    return _wrap(source, [1.0 if b else 0.0 for b in result])


def falling(source: Series, length: int) -> Series:
    result = ta_core.falling(source.to_array(), length)
    return _wrap(source, [1.0 if b else 0.0 for b in result])


def pivothigh(source: Series, leftbars: int, rightbars: int) -> Series:
    return _wrap(source, ta_core.pivothigh(source.to_array(), leftbars, rightbars))


def pivotlow(source: Series, leftbars: int, rightbars: int) -> Series:
    return _wrap(source, ta_core.pivotlow(source.to_array(), leftbars, rightbars))


# --- Cumulative & Stats ---

def cum(source: Series) -> Series:
    return _wrap(source, ta_core.cum(source.to_array()))


def correlation(source1: Series, source2: Series, length: int) -> Series:
    return _wrap(source1, ta_core.correlation(source1.to_array(), source2.to_array(), length))


def median(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.median(source.to_array(), length))


def mode(source: Series, length: int) -> Series:
    return _wrap(source, ta_core.mode(source.to_array(), length))


def percentile_linear_interpolation(source: Series, length: int, percentage: float) -> Series:
    return _wrap(source, ta_core.percentile_linear_interpolation(source.to_array(), length, percentage))


def percentile_nearest_rank(source: Series, length: int, percentage: float) -> Series:
    return _wrap(source, ta_core.percentile_nearest_rank(source.to_array(), length, percentage))


# --- Bar-based ---

def barssince(condition: Series) -> Series:
    bool_values = [v == 1 for v in condition.to_array()]
    return _wrap(condition, ta_core.barssince(bool_values))


def valuewhen(condition: Series, source: Series, occurrence: int) -> Series:
    bool_values = [v == 1 for v in condition.to_array()]
    return _wrap(condition, ta_core.valuewhen(bool_values, source.to_array(), occurrence))


# --- Element-wise ---

def max(source1: Series, source2: Series) -> Series:
    return _wrap(source1, ta_core.max_(source1.to_array(), source2.to_array()))


def min(source1: Series, source2: Series) -> Series:
    return _wrap(source1, ta_core.min_(source1.to_array(), source2.to_array()))


def range(high: Series, low: Series) -> Series:
    return _wrap(high, ta_core.range_(high.to_array(), low.to_array()))


# --- Complex indicators ---

def zigzag(
    bars: list[Bar], deviation: float = 5, depth: int = 10, backstep: int = 3,
) -> tuple[Series, Series, Series]:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    zigzag_vals, dir_vals, pivot_vals = ta_core.zigzag(deviation, depth, backstep, None, high, low)
    return (
        _wrap(bars, zigzag_vals),
        _wrap(bars, dir_vals),
        _wrap(bars, [1.0 if b else 0.0 for b in pivot_vals]),
    )


def wpr(bars: list[Bar], length: int = 14) -> Series:
    high = [b.high for b in bars]
    low = [b.low for b in bars]
    close = [b.close for b in bars]
    return _wrap(bars, ta_core.wpr(high, low, close, length))
