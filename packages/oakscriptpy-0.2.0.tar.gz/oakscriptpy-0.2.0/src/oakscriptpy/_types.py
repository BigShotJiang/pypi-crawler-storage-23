"""Core types for oakscriptPy — mirrors PineScript type system."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

# Basic type aliases
series_float = list[float]
series_int = list[int]
series_bool = list[bool]
series_string = list[str]
series_color = list[str | int]
Source = list[float]
color = str | int

# Constants
import math as _math


class _Na:
    """PineScript-compatible NA: falsy constant, callable checker, numeric NaN.

    Usage::

        na          # falsy sentinel, acts as float('nan') in arithmetic
        na(value)   # True if value is None or NaN
        na + 1      # nan (propagates like NaN)
    """

    def __call__(self, value: object) -> bool:
        if value is None:
            return True
        if isinstance(value, float) and _math.isnan(value):
            return True
        return False

    def __bool__(self) -> bool:
        return False

    def __float__(self) -> float:
        return float("nan")

    def __repr__(self) -> str:
        return "na"

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _Na):
            return True
        if isinstance(other, float) and _math.isnan(other):
            return True
        return NotImplemented

    def __hash__(self) -> int:
        return hash(float("nan"))


na = _Na()


class _Xloc:
    bar_index: str = "bar_index"
    bar_time: str = "bar_time"


xloc = _Xloc()


# Drawing objects

@dataclass
class Line:
    x1: float
    y1: float
    x2: float
    y2: float
    xloc: str = "bar_index"
    extend: str = "none"
    color: str | int | None = None
    style: str | None = None
    width: int | None = None


@dataclass
class Box:
    left: float
    top: float
    right: float
    bottom: float
    xloc: str = "bar_index"
    extend: str = "none"
    border_color: str | int | None = None
    border_width: int | None = None
    border_style: str | None = None
    bgcolor: str | int | None = None
    text: str | None = None
    text_size: str | int | None = None
    text_color: str | int | None = None
    text_halign: str | None = None
    text_valign: str | None = None
    text_wrap: str | None = None
    text_font_family: str | None = None


@dataclass
class Label:
    x: float
    y: float
    xloc: str = "bar_index"
    yloc: str = "price"
    text: str | None = None
    tooltip: str | None = None
    color: str | int | None = None
    style: str | None = None
    textcolor: str | int | None = None
    size: str | int | None = None
    textalign: str | None = None
    text_font_family: str | None = None


@dataclass
class Linefill:
    line1: Line
    line2: Line
    color: str | int | None = None


@dataclass
class Table:
    position: str
    columns: int
    rows: int
    frame_color: str | int | None = None
    frame_width: int | None = None
    border_color: str | int | None = None
    border_width: int | None = None
    bgcolor: str | int | None = None
    cells: dict[str, TableCell] | None = None


@dataclass
class TableCell:
    text: str | None = None
    width: float | None = None
    height: float | None = None
    text_color: str | int | None = None
    text_halign: str | None = None
    text_valign: str | None = None
    text_size: str | int | None = None
    bgcolor: str | int | None = None
    tooltip: str | None = None
    text_font_family: str | None = None


@dataclass
class Plot:
    id: str
    series: Any = None
    title: str | None = None
    color: Any = None
    linewidth: int | None = None
    style: str | None = None
    trackprice: bool | None = None
    histbase: float | None = None
    offset: int | None = None
    join: bool | None = None
    editable: bool | None = None
    display: str | None = None


@dataclass
class HLine:
    id: str
    price: float
    title: str | None = None
    color: Any = None
    linestyle: str | None = None
    linewidth: int | None = None
    editable: bool | None = None


@dataclass
class Bar:
    time: int
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class OHLC:
    open: list[float]
    high: list[float]
    low: list[float]
    close: list[float]


@dataclass
class ChartPoint:
    time: float | None
    index: int | None
    price: float


@dataclass
class Polyline:
    id: str
    points: list[ChartPoint]
    curved: bool = False
    closed: bool = False
    xloc: str = "bar_index"
    line_color: str | int = "#2962FF"
    fill_color: str | int | None = None
    line_style: str = "solid"
    line_width: int = 1
    force_overlay: bool = False


@dataclass
class PineMatrix:
    rows: int
    columns: int
    data: list[list[Any]] = field(default_factory=list)
