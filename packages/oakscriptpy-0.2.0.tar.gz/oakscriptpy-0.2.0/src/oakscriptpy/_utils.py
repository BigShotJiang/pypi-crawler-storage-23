"""Internal utility functions for oakscriptPy."""

from __future__ import annotations

import math
import warnings
from typing import TYPE_CHECKING

from ._types import Bar, OHLC, series_float

if TYPE_CHECKING:
    from .series import Series


def validate_series_length(source: list[float], length: int, function_name: str) -> None:
    if len(source) < length:
        warnings.warn(
            f"{function_name}: Source length ({len(source)}) is less than required length ({length})"
        )


def create_nan_series(length: int) -> series_float:
    return [float("nan")] * length


def is_na(value: object) -> bool:
    if value is None:
        return True
    if isinstance(value, float) and math.isnan(value):
        return True
    return False


def nz(value: object, default: object = 0) -> object:
    """Replace na with default. Works on scalars and Series.

    Scalar: nz(float('nan')) -> 0, nz(float('nan'), -1) -> -1
    Series: nz(series) -> new Series with na values replaced by default
    """
    from .series import Series

    if isinstance(value, Series):
        replacement = float(default)
        ext = value._extractor

        def _nz(b: Bar, i: int, d: list[Bar]) -> float:
            v = ext(b, i, d)
            return replacement if (v is None or (isinstance(v, float) and math.isnan(v))) else v

        return Series(value._data_source, _nz)
    return default if is_na(value) else value


def fixnan(value: object) -> object:
    """Replace na with last non-na value (forward fill). Works on scalars and Series.

    Scalar: fixnan(float('nan')) -> float('nan') (no history to fill from)
    Series: fixnan(series) -> new Series with na forward-filled
    """
    from .series import Series

    if isinstance(value, Series):
        ext = value._extractor

        def _fixnan(_b: Bar, i: int, d: list[Bar]) -> float:
            v = ext(d[i], i, d)
            if not math.isnan(v):
                return v
            # Walk backwards to find last non-na value
            for j in range(i - 1, -1, -1):
                prev = ext(d[j], j, d)
                if not math.isnan(prev):
                    return prev
            return float("nan")

        return Series(value._data_source, _fixnan)
    return value


def clamp(value: float, min_val: float, max_val: float) -> float:
    return max(min_val, min(max_val, value))


def lerp(start: float, end: float, t: float) -> float:
    return start + (end - start) * t


def normalize(
    value: float, min_val: float, max_val: float, new_min: float = 0.0, new_max: float = 1.0
) -> float:
    return new_min + ((value - min_val) * (new_max - new_min)) / (max_val - min_val)


# Chart data utilities

def ohlc_from_bars(bars: list[Bar]) -> OHLC:
    return OHLC(
        open=[b.open for b in bars],
        high=[b.high for b in bars],
        low=[b.low for b in bars],
        close=[b.close for b in bars],
    )


def get_close(ohlc: OHLC) -> series_float:
    return ohlc.close


def get_high(ohlc: OHLC) -> series_float:
    return ohlc.high


def get_low(ohlc: OHLC) -> series_float:
    return ohlc.low


def get_open(ohlc: OHLC) -> series_float:
    return ohlc.open


def get_source(
    data: list[Bar] | OHLC,
    source: str = "close",
) -> series_float:
    if isinstance(data, OHLC):
        ohlc = data
        if source == "close":
            return ohlc.close
        if source == "open":
            return ohlc.open
        if source == "high":
            return ohlc.high
        if source == "low":
            return ohlc.low
        if source == "hl2":
            return [(h + l) / 2 for h, l in zip(ohlc.high, ohlc.low)]
        if source == "hlc3":
            return [(h + l + c) / 3 for h, l, c in zip(ohlc.high, ohlc.low, ohlc.close)]
        if source == "ohlc4":
            return [
                (o + h + l + c) / 4
                for o, h, l, c in zip(ohlc.open, ohlc.high, ohlc.low, ohlc.close)
            ]
        if source == "hlcc4":
            return [
                (h + l + c + c) / 4 for h, l, c in zip(ohlc.high, ohlc.low, ohlc.close)
            ]
    else:
        bars = data
        if source == "close":
            return [b.close for b in bars]
        if source == "open":
            return [b.open for b in bars]
        if source == "high":
            return [b.high for b in bars]
        if source == "low":
            return [b.low for b in bars]
        if source == "hl2":
            return [(b.high + b.low) / 2 for b in bars]
        if source == "hlc3":
            return [(b.high + b.low + b.close) / 3 for b in bars]
        if source == "ohlc4":
            return [(b.open + b.high + b.low + b.close) / 4 for b in bars]
        if source == "hlcc4":
            return [(b.high + b.low + b.close + b.close) / 4 for b in bars]
    return []


def shift(series: series_float, offset: int) -> series_float:
    if offset == 0:
        return series
    if offset > 0:
        return [float("nan")] * offset + series[: -offset]
    else:
        return series[-offset:] + [float("nan")] * (-offset)


def format_output(
    values: series_float, timestamps: list[float] | None = None
) -> list[dict]:
    result = []
    for i, value in enumerate(values):
        result.append({
            "time": timestamps[i] if timestamps else i,
            "value": None if math.isnan(value) else value,
        })
    return result
