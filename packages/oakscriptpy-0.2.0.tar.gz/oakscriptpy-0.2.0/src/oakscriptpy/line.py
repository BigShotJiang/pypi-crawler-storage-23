"""Line namespace — mirrors PineScript line.* functions."""

from __future__ import annotations

import copy as _copy

from ._types import Line


def new(
    x1: float, y1: float, x2: float, y2: float,
    xloc: str = "bar_index", extend: str = "none",
    color: str | int | None = None, style: str | None = None, width: int | None = None,
) -> Line:
    return Line(x1=x1, y1=y1, x2=x2, y2=y2, xloc=xloc, extend=extend,
                color=color, style=style or "solid", width=width or 1)


def get_price(id: Line, x: float) -> float:
    if id.xloc == "bar_time":
        raise ValueError("line.get_price() only works with xloc.bar_index lines")
    if id.x2 == id.x1:
        return float("nan")
    slope = (id.y2 - id.y1) / (id.x2 - id.x1)
    price = id.y1 + slope * (x - id.x1)
    lo = min(id.x1, id.x2)
    hi = max(id.x1, id.x2)
    if id.extend == "none":
        if x < lo or x > hi:
            return float("nan")
    elif id.extend == "left":
        if x > hi:
            return float("nan")
    elif id.extend == "right":
        if x < lo:
            return float("nan")
    return price


def get_x1(id: Line) -> float:
    return id.x1


def get_x2(id: Line) -> float:
    return id.x2


def get_y1(id: Line) -> float:
    return id.y1


def get_y2(id: Line) -> float:
    return id.y2


def copy(id: Line) -> Line:
    return _copy.copy(id)


def set_x1(id: Line, x: float) -> Line:
    id.x1 = x
    return id


def set_x2(id: Line, x: float) -> Line:
    id.x2 = x
    return id


def set_y1(id: Line, y: float) -> Line:
    id.y1 = y
    return id


def set_y2(id: Line, y: float) -> Line:
    id.y2 = y
    return id


def set_xy1(id: Line, x: float, y: float) -> Line:
    id.x1 = x
    id.y1 = y
    return id


def set_xy2(id: Line, x: float, y: float) -> Line:
    id.x2 = x
    id.y2 = y
    return id


def set_xloc(id: Line, x1: float, x2: float, xloc: str) -> Line:
    id.x1 = x1
    id.x2 = x2
    id.xloc = xloc
    return id


def set_extend(id: Line, extend: str) -> Line:
    id.extend = extend
    return id


def set_color(id: Line, color: str | int) -> Line:
    id.color = color
    return id


def set_style(id: Line, style: str) -> Line:
    id.style = style
    return id


def set_width(id: Line, width: int) -> Line:
    id.width = width
    return id


def delete(id: Line) -> None:
    pass
