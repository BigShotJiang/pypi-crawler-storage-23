"""Box namespace — mirrors PineScript box.* functions."""

from __future__ import annotations

import copy as _copy

from ._types import Box


def new(
    left: float, top: float, right: float, bottom: float,
    xloc: str = "bar_index", extend: str = "none",
    border_color: str | int | None = None, border_width: int | None = None,
    border_style: str | None = None, bgcolor: str | int | None = None,
    text: str | None = None, text_size: str | int | None = None,
    text_color: str | int | None = None, text_halign: str | None = None,
    text_valign: str | None = None, text_wrap: str | None = None,
    text_font_family: str | None = None,
) -> Box:
    return Box(
        left=left, top=top, right=right, bottom=bottom,
        xloc=xloc, extend=extend,
        border_color=border_color, border_width=border_width or 1,
        border_style=border_style or "solid", bgcolor=bgcolor,
        text=text, text_size=text_size, text_color=text_color,
        text_halign=text_halign, text_valign=text_valign,
        text_wrap=text_wrap, text_font_family=text_font_family,
    )


def get_left(id: Box) -> float:
    return id.left


def get_right(id: Box) -> float:
    return id.right


def get_top(id: Box) -> float:
    return id.top


def get_bottom(id: Box) -> float:
    return id.bottom


def copy(id: Box) -> Box:
    return _copy.copy(id)


def set_left(id: Box, left: float) -> Box:
    id.left = left
    return id


def set_right(id: Box, right: float) -> Box:
    id.right = right
    return id


def set_top(id: Box, top: float) -> Box:
    id.top = top
    return id


def set_bottom(id: Box, bottom: float) -> Box:
    id.bottom = bottom
    return id


def set_lefttop(id: Box, left: float, top: float) -> Box:
    id.left = left
    id.top = top
    return id


def set_rightbottom(id: Box, right: float, bottom: float) -> Box:
    id.right = right
    id.bottom = bottom
    return id


def set_xloc(id: Box, left: float, right: float, xloc: str) -> Box:
    id.left = left
    id.right = right
    id.xloc = xloc
    return id


def set_extend(id: Box, extend: str) -> Box:
    id.extend = extend
    return id


def set_border_color(id: Box, color: str | int) -> Box:
    id.border_color = color
    return id


def set_border_width(id: Box, width: int) -> Box:
    id.border_width = width
    return id


def set_border_style(id: Box, style: str) -> Box:
    id.border_style = style
    return id


def set_bgcolor(id: Box, color: str | int) -> Box:
    id.bgcolor = color
    return id


def set_text(id: Box, text: str) -> Box:
    id.text = text
    return id


def set_text_color(id: Box, color: str | int) -> Box:
    id.text_color = color
    return id


def set_text_size(id: Box, size: str | int) -> Box:
    id.text_size = size
    return id


def set_text_halign(id: Box, align: str) -> Box:
    id.text_halign = align
    return id


def set_text_valign(id: Box, align: str) -> Box:
    id.text_valign = align
    return id


def set_text_wrap(id: Box, wrap: str) -> Box:
    id.text_wrap = wrap
    return id


def set_text_font_family(id: Box, font: str) -> Box:
    id.text_font_family = font
    return id


def delete(id: Box) -> None:
    pass
