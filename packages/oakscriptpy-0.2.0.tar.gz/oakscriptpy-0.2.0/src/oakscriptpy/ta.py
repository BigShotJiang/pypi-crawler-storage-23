"""Technical Analysis (ta) namespace — mirrors PineScript ta.* functions."""

from __future__ import annotations

import math

from ._types import series_float, series_bool, series_int, Source
from ._utils import is_na, nz, create_nan_series, validate_series_length


def sma(source: Source, length: int) -> series_float:
    result: series_float = []
    length = int(length)

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            s = 0.0
            for j in range(length):
                s += source[i - j]
            result.append(s / length)

    return result


def ema(source: Source, length: int) -> series_float:
    result: series_float = []
    length = int(length)
    multiplier = 2 / (length + 1)

    first_valid_index = -1
    valid_count = 0
    init_sum = 0.0

    for i in range(len(source)):
        val = source[i]
        if val is not None and not math.isnan(val):
            init_sum += val
            valid_count += 1
            if valid_count == length:
                first_valid_index = i
                break

    ema_value = init_sum / valid_count if valid_count > 0 else float('nan')
    ema_initialized = first_valid_index >= 0

    for i in range(len(source)):
        if not ema_initialized or i < first_valid_index:
            result.append(float('nan'))
        elif i == first_valid_index:
            result.append(ema_value)
        else:
            val = source[i]
            if val is not None and not math.isnan(val):
                ema_value = (val - ema_value) * multiplier + ema_value
            result.append(ema_value)

    return result


def rsi(source: Source, length: int) -> series_float:
    result: series_float = []

    changes = []
    for i in range(1, len(source)):
        changes.append(source[i] - source[i - 1])

    gains = [c if c > 0 else 0.0 for c in changes]
    losses = [-c if c < 0 else 0.0 for c in changes]

    avg_gains = rma(gains, length)
    avg_losses = rma(losses, length)

    result.append(float('nan'))

    for i in range(len(avg_gains)):
        if avg_losses[i] == 0:
            result.append(100.0)
        else:
            rs = avg_gains[i] / avg_losses[i]
            result.append(100.0 - (100.0 / (1.0 + rs)))

    return result


def macd(source: Source, fast_length: int, slow_length: int, signal_length: int):
    fast_ema = ema(source, fast_length)
    slow_ema = ema(source, slow_length)

    macd_line: series_float = []
    for i in range(len(source)):
        macd_line.append(fast_ema[i] - slow_ema[i])

    signal_line = ema(macd_line, signal_length)

    histogram: series_float = []
    for i in range(len(source)):
        histogram.append(macd_line[i] - signal_line[i])

    return [macd_line, signal_line, histogram]


def bb(series: Source, length: int, mult: float):
    basis = sma(series, length)
    dev_values = stdev(series, length)

    upper: series_float = []
    lower: series_float = []

    for i in range(len(series)):
        upper.append(basis[i] + mult * dev_values[i])
        lower.append(basis[i] - mult * dev_values[i])

    return [basis, upper, lower]


def stdev(source: Source, length: int) -> series_float:
    result: series_float = []
    length = int(length)
    avg = sma(source, length)

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            sum_squares = 0.0
            for j in range(length):
                diff = source[i - j] - avg[i]
                sum_squares += diff * diff
            result.append(math.sqrt(sum_squares / length))

    return result


def crossover(series1: Source, series2: Source | float | int) -> series_bool:
    if isinstance(series2, (int, float)):
        series2 = [float(series2)] * len(series1)
    result: series_bool = []

    for i in range(len(series1)):
        if i == 0:
            result.append(False)
        else:
            result.append(series1[i] > series2[i] and series1[i - 1] <= series2[i - 1])

    return result


def crossunder(series1: Source, series2: Source | float | int) -> series_bool:
    if isinstance(series2, (int, float)):
        series2 = [float(series2)] * len(series1)
    result: series_bool = []

    for i in range(len(series1)):
        if i == 0:
            result.append(False)
        else:
            result.append(series1[i] < series2[i] and series1[i - 1] >= series2[i - 1])

    return result


def change(source: Source, length: int = 1) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
        else:
            result.append(source[i] - source[i - length])

    return result


def tr(handle_na: bool = False, high: Source = None, low: Source = None, close: Source = None) -> series_float:
    if high is None or low is None or close is None:
        raise ValueError(
            'ta.tr() requires high, low, and close series. '
            'Pass them explicitly.'
        )

    result: series_float = []

    for i in range(len(high)):
        if i == 0:
            result.append(high[i] - low[i])
        else:
            prev_close = close[i - 1]

            if math.isnan(prev_close):
                if handle_na:
                    result.append(high[i] - low[i])
                else:
                    result.append(float('nan'))
            else:
                tr_val = max(
                    high[i] - low[i],
                    abs(high[i] - prev_close),
                    abs(low[i] - prev_close)
                )
                result.append(tr_val)

    return result


def atr(length: int, high: Source = None, low: Source = None, close: Source = None) -> series_float:
    if high is None or low is None or close is None:
        raise ValueError(
            'ta.atr() requires high, low, and close series. '
            'Pass them explicitly.'
        )

    true_range = tr(False, high, low, close)
    return rma(true_range, length)


def supertrend(factor: float, atr_period: int, high: Source = None, low: Source = None, close: Source = None, wicks: bool = False):
    if high is None or low is None or close is None:
        raise ValueError(
            'ta.supertrend() requires high, low, and close series. '
            'Pass them explicitly.'
        )

    supertrend_values: series_float = []
    directions: series_int = []

    source: series_float = []
    for i in range(len(high)):
        source.append((high[i] + low[i]) / 2)

    atr_values = atr(atr_period, high, low, close)

    prev_lower_band = float('nan')
    prev_upper_band = float('nan')
    prev_super_trend = float('nan')

    for i in range(len(source)):
        atr_value = atr_values[i] * factor

        if math.isnan(atr_value):
            supertrend_values.append(float('nan'))
            directions.append(1)
            continue

        upper_band = source[i] + atr_value
        lower_band = source[i] - atr_value

        high_price = high[i] if wicks else close[i]
        low_price = low[i] if wicks else close[i]
        prev_low_price = (low[i - 1] if wicks else close[i - 1]) if i > 0 else 0.0
        prev_high_price = (high[i - 1] if wicks else close[i - 1]) if i > 0 else 0.0

        if i > 0 and not math.isnan(prev_lower_band) and not math.isnan(prev_upper_band):
            lower_band = lower_band if (lower_band > prev_lower_band or prev_low_price < prev_lower_band) else prev_lower_band
            upper_band = upper_band if (upper_band < prev_upper_band or prev_high_price > prev_upper_band) else prev_upper_band

        if math.isnan(prev_super_trend):
            current_direction = 1
        elif prev_super_trend == prev_upper_band:
            current_direction = -1 if high_price > upper_band else 1
        else:
            current_direction = 1 if low_price < lower_band else -1

        super_trend_value = lower_band if current_direction == -1 else upper_band

        supertrend_values.append(super_trend_value)
        directions.append(current_direction)

        prev_lower_band = lower_band
        prev_upper_band = upper_band
        prev_super_trend = super_trend_value

    return [supertrend_values, directions]


def rma(source: Source, length: int) -> series_float:
    result: series_float = []
    length = int(length)
    alpha = 1.0 / length

    first_valid_index = -1
    valid_count = 0
    init_sum = 0.0

    for i in range(len(source)):
        val = source[i]
        if val is not None and not math.isnan(val):
            init_sum += val
            valid_count += 1
            if valid_count == length:
                first_valid_index = i
                break

    rma_value = init_sum / valid_count if valid_count > 0 else float('nan')
    rma_initialized = first_valid_index >= 0

    for i in range(len(source)):
        if not rma_initialized or i < first_valid_index:
            result.append(float('nan'))
        elif i == first_valid_index:
            result.append(rma_value)
        else:
            val = source[i]
            if val is not None and not math.isnan(val):
                rma_value = alpha * val + (1 - alpha) * rma_value
            result.append(rma_value)

    return result


def wma(source: Source, length: int) -> series_float:
    result: series_float = []
    length = int(length)

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            s = 0.0
            weight_sum = 0

            for j in range(length):
                weight = length - j
                s += source[i - j] * weight
                weight_sum += weight

            result.append(s / weight_sum)

    return result


def highest(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        window_start = max(0, i - length + 1)
        max_val = -math.inf
        for j in range(window_start, i + 1):
            if not math.isnan(source[j]):
                max_val = max(max_val, source[j])
        result.append(float('nan') if max_val == -math.inf else max_val)

    return result


def lowest(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        window_start = max(0, i - length + 1)
        min_val = math.inf
        for j in range(window_start, i + 1):
            if not math.isnan(source[j]):
                min_val = min(min_val, source[j])
        result.append(float('nan') if min_val == math.inf else min_val)

    return result


def cum(source: Source) -> series_float:
    result: series_float = []
    s = 0.0

    for i in range(len(source)):
        s += source[i]
        result.append(s)

    return result


def cross(source1: Source, source2: Source | float | int) -> series_bool:
    if isinstance(source2, (int, float)):
        source2 = [float(source2)] * len(source1)
    result: series_bool = []

    for i in range(len(source1)):
        if i == 0:
            result.append(False)
        else:
            crossed_up = source1[i] > source2[i] and source1[i - 1] <= source2[i - 1]
            crossed_down = source1[i] < source2[i] and source1[i - 1] >= source2[i - 1]
            result.append(crossed_up or crossed_down)

    return result


def rising(source: Source, length: int) -> series_bool:
    result: series_bool = []

    for i in range(len(source)):
        if i < length:
            result.append(False)
        else:
            is_rising = True
            for j in range(1, length + 1):
                if source[i - j + 1] <= source[i - j]:
                    is_rising = False
                    break
            result.append(is_rising)

    return result


def falling(source: Source, length: int) -> series_bool:
    result: series_bool = []

    for i in range(len(source)):
        if i < length:
            result.append(False)
        else:
            is_falling = True
            for j in range(1, length + 1):
                if source[i - j + 1] >= source[i - j]:
                    is_falling = False
                    break
            result.append(is_falling)

    return result


def roc(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
        else:
            old_value = source[i - length]
            if old_value == 0 or math.isnan(old_value) or math.isnan(source[i]):
                result.append(float('nan'))
            else:
                change_value = source[i] - old_value
                result.append((100 * change_value) / old_value)

    return result


def mom(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
        else:
            if math.isnan(source[i]) or math.isnan(source[i - length]):
                result.append(float('nan'))
            else:
                result.append(source[i] - source[i - length])

    return result


def dev(source: Source, length: int) -> series_float:
    result: series_float = []
    mean_values = sma(source, length)

    for i in range(len(source)):
        if i < length - 1 or math.isnan(mean_values[i]):
            result.append(float('nan'))
        else:
            s = 0.0
            for j in range(length):
                if not math.isnan(source[i - j]):
                    s += abs(source[i - j] - mean_values[i])
            result.append(s / length)

    return result


def variance(source: Source, length: int, biased: bool = True) -> series_float:
    result: series_float = []
    mean_values = sma(source, length)

    for i in range(len(source)):
        if i < length - 1 or math.isnan(mean_values[i]):
            result.append(float('nan'))
        else:
            sum_squares = 0.0
            count = 0
            for j in range(length):
                if not math.isnan(source[i - j]):
                    diff = source[i - j] - mean_values[i]
                    sum_squares += diff * diff
                    count += 1
            divisor = count if biased else count - 1
            result.append(sum_squares / divisor if divisor > 0 else float('nan'))

    return result


def median(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            values = []
            for j in range(length):
                if not math.isnan(source[i - j]):
                    values.append(source[i - j])

            if len(values) == 0:
                result.append(float('nan'))
            else:
                values.sort()
                mid = len(values) // 2
                if len(values) % 2 == 0:
                    result.append((values[mid - 1] + values[mid]) / 2)
                else:
                    result.append(values[mid])

    return result


def swma(source: Source) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < 3:
            result.append(float('nan'))
        else:
            if math.isnan(source[i]) or math.isnan(source[i - 1]) or math.isnan(source[i - 2]) or math.isnan(source[i - 3]):
                result.append(float('nan'))
            else:
                value = (
                    source[i - 3] * (1 / 6) +
                    source[i - 2] * (2 / 6) +
                    source[i - 1] * (2 / 6) +
                    source[i] * (1 / 6)
                )
                result.append(value)

    return result


def vwma(source: Source, length: int, volume: Source = None) -> series_float:
    if volume is None:
        raise ValueError(
            'ta.vwma() requires volume series. '
            'Pass it explicitly.'
        )

    source_times_volume: series_float = []
    for i in range(len(source)):
        source_times_volume.append(source[i] * volume[i])

    numerator = sma(source_times_volume, length)
    denominator = sma(volume, length)

    result: series_float = []
    for i in range(len(source)):
        if denominator[i] == 0 or math.isnan(denominator[i]):
            result.append(float('nan'))
        else:
            result.append(numerator[i] / denominator[i])

    return result


def linreg(source: Source, length: int, offset: int = 0) -> series_float:
    result: series_float = []
    length = int(length)

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            has_nan = False
            for j in range(length):
                if math.isnan(source[i - j]):
                    has_nan = True
                    break

            if has_nan:
                result.append(float('nan'))
            else:
                sum_x = 0.0
                sum_y = 0.0
                sum_xy = 0.0
                sum_x2 = 0.0

                for j in range(length):
                    x = j
                    y = source[i - (length - 1 - j)]
                    sum_x += x
                    sum_y += y
                    sum_xy += x * y
                    sum_x2 += x * x

                slope = (length * sum_xy - sum_x * sum_y) / (length * sum_x2 - sum_x * sum_x)
                intercept = (sum_y - slope * sum_x) / length

                x_val = length - 1 - offset
                result.append(intercept + slope * x_val)

    return result


def correlation(source1: Source, source2: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source1)):
        if i < length - 1:
            result.append(float('nan'))
        else:
            pairs = []
            for j in range(length):
                if not math.isnan(source1[i - j]) and not math.isnan(source2[i - j]):
                    pairs.append((source1[i - j], source2[i - j]))

            if len(pairs) == 0:
                result.append(float('nan'))
            else:
                sum1 = 0.0
                sum2 = 0.0
                for v1, v2 in pairs:
                    sum1 += v1
                    sum2 += v2
                mean1 = sum1 / len(pairs)
                mean2 = sum2 / len(pairs)

                numerator = 0.0
                sum1_sq = 0.0
                sum2_sq = 0.0

                for v1, v2 in pairs:
                    dev1 = v1 - mean1
                    dev2 = v2 - mean2
                    numerator += dev1 * dev2
                    sum1_sq += dev1 * dev1
                    sum2_sq += dev2 * dev2

                denominator = math.sqrt(sum1_sq * sum2_sq)
                if denominator == 0:
                    result.append(float('nan'))
                else:
                    result.append(numerator / denominator)

    return result


def percentrank(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
        else:
            if math.isnan(source[i]):
                result.append(float('nan'))
                continue

            has_nan = False
            for j in range(1, length + 1):
                if math.isnan(source[i - j]):
                    has_nan = True
                    break

            if has_nan:
                result.append(float('nan'))
            else:
                current_value = source[i]
                count_less_or_equal = 0

                for j in range(1, length + 1):
                    if source[i - j] <= current_value:
                        count_less_or_equal += 1

                result.append((count_less_or_equal / length) * 100)

    return result


def cci(source: Source, length: int) -> series_float:
    result: series_float = []
    sma_values = sma(source, length)
    dev_values = dev(source, length)

    for i in range(len(source)):
        if math.isnan(sma_values[i]) or math.isnan(dev_values[i]) or dev_values[i] == 0:
            result.append(float('nan'))
        else:
            cci_val = (source[i] - sma_values[i]) / (0.015 * dev_values[i])
            result.append(cci_val)

    return result


def stoch(source: Source, high: Source, low: Source, length: int) -> series_float:
    result: series_float = []
    lowest_values = lowest(low, length)
    highest_values = highest(high, length)

    for i in range(len(source)):
        if i < length - 1 or math.isnan(lowest_values[i]) or math.isnan(highest_values[i]):
            result.append(float('nan'))
        else:
            range_val = highest_values[i] - lowest_values[i]
            if range_val == 0:
                result.append(float('nan'))
            else:
                stoch_value = 100 * (source[i] - lowest_values[i]) / range_val
                result.append(stoch_value)

    return result


def mfi(source: Source, length: int, volume: Source = None) -> series_float:
    if volume is None:
        raise ValueError(
            'ta.mfi() requires volume series. '
            'Pass it explicitly.'
        )

    result: series_float = []

    changes = [float('nan')]
    for i in range(1, len(source)):
        changes.append(source[i] - source[i - 1])

    positive_flow = []
    negative_flow = []

    for i in range(len(source)):
        if i == 0 or math.isnan(changes[i]):
            positive_flow.append(0.0)
            negative_flow.append(0.0)
        elif changes[i] > 0:
            positive_flow.append(volume[i] * source[i])
            negative_flow.append(0.0)
        elif changes[i] < 0:
            positive_flow.append(0.0)
            negative_flow.append(volume[i] * source[i])
        else:
            positive_flow.append(0.0)
            negative_flow.append(0.0)

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
        else:
            pos_sum = 0.0
            neg_sum = 0.0

            for j in range(length):
                pos_sum += positive_flow[i - j]
                neg_sum += negative_flow[i - j]

            if neg_sum == 0:
                result.append(100.0)
            else:
                money_ratio = pos_sum / neg_sum
                mfi_value = 100.0 - (100.0 / (1.0 + money_ratio))
                result.append(mfi_value)

    return result


def hma(source: Source, length: int) -> series_float:
    half_length = int(length / 2)
    sqrt_length = int(math.sqrt(length))

    wma_half = wma(source, half_length)
    wma_full = wma(source, length)

    diff: series_float = []
    for i in range(len(source)):
        diff.append(2 * wma_half[i] - wma_full[i])

    return wma(diff, sqrt_length)


def sar(start: float, inc: float, max_val: float, high: Source = None, low: Source = None, close: Source = None) -> series_float:
    if high is None or low is None or close is None:
        raise ValueError(
            'ta.sar() requires high, low, and close series. '
            'Pass them explicitly.'
        )

    result: series_float = []
    sar_value = float('nan')
    extreme_point = float('nan')
    acceleration = start
    is_up_trend = False
    is_first_trend_bar = False

    for i in range(len(close)):
        if i == 0:
            result.append(float('nan'))
            continue

        if i == 1:
            if close[i] > close[i - 1]:
                is_up_trend = True
                extreme_point = high[i]
                sar_value = low[i - 1]
            else:
                is_up_trend = False
                extreme_point = low[i]
                sar_value = high[i - 1]
            is_first_trend_bar = True
            acceleration = start

        sar_value = sar_value + acceleration * (extreme_point - sar_value)

        if is_up_trend:
            if sar_value > low[i]:
                is_first_trend_bar = True
                is_up_trend = False
                sar_value = max(high[i], extreme_point)
                extreme_point = low[i]
                acceleration = start
        else:
            if sar_value < high[i]:
                is_first_trend_bar = True
                is_up_trend = True
                sar_value = min(low[i], extreme_point)
                extreme_point = high[i]
                acceleration = start

        if not is_first_trend_bar:
            if is_up_trend:
                if high[i] > extreme_point:
                    extreme_point = high[i]
                    acceleration = min(acceleration + inc, max_val)
            else:
                if low[i] < extreme_point:
                    extreme_point = low[i]
                    acceleration = min(acceleration + inc, max_val)

        if is_up_trend:
            sar_value = min(sar_value, low[i - 1])
            if i > 1:
                sar_value = min(sar_value, low[i - 2])
        else:
            sar_value = max(sar_value, high[i - 1])
            if i > 1:
                sar_value = max(sar_value, high[i - 2])

        result.append(sar_value)
        is_first_trend_bar = False

    return result


def pivothigh(source_or_leftbars, leftbars_or_rightbars, rightbars=None, high=None):
    if rightbars is None:
        if high is None:
            raise ValueError('ta.pivothigh() requires high series when using two-parameter version.')
        source = high
        leftbars = source_or_leftbars
        right = leftbars_or_rightbars
    else:
        source = source_or_leftbars
        leftbars = leftbars_or_rightbars
        right = rightbars

    result: series_float = []

    for i in range(len(source)):
        if i < leftbars or i + right >= len(source):
            result.append(float('nan'))
            continue

        center_value = source[i]
        is_pivot = True

        for j in range(1, leftbars + 1):
            if source[i - j] > center_value:
                is_pivot = False
                break

        if is_pivot:
            for j in range(1, right + 1):
                if source[i + j] >= center_value:
                    is_pivot = False
                    break

        result.append(center_value if is_pivot else float('nan'))

    return result


def pivotlow(source_or_leftbars, leftbars_or_rightbars, rightbars=None, low=None):
    if rightbars is None:
        if low is None:
            raise ValueError('ta.pivotlow() requires low series when using two-parameter version.')
        source = low
        leftbars = source_or_leftbars
        right = leftbars_or_rightbars
    else:
        source = source_or_leftbars
        leftbars = leftbars_or_rightbars
        right = rightbars

    result: series_float = []

    for i in range(len(source)):
        if i < leftbars or i + right >= len(source):
            result.append(float('nan'))
            continue

        center_value = source[i]
        is_pivot = True

        for j in range(1, leftbars + 1):
            if source[i - j] < center_value:
                is_pivot = False
                break

        if is_pivot:
            for j in range(1, right + 1):
                if source[i + j] <= center_value:
                    is_pivot = False
                    break

        result.append(center_value if is_pivot else float('nan'))

    return result


def barssince(condition: series_bool) -> series_float:
    result: series_float = []
    bars_since_true = float('nan')

    for i in range(len(condition)):
        if condition[i]:
            bars_since_true = 0
        elif not math.isnan(bars_since_true):
            bars_since_true += 1
        result.append(bars_since_true)

    return result


def valuewhen(condition: series_bool, source: Source, occurrence: int) -> series_float:
    result: series_float = []

    for i in range(len(condition)):
        occurrence_count = 0
        found_value = float('nan')

        for j in range(i, -1, -1):
            if condition[j]:
                if occurrence_count == occurrence:
                    found_value = source[j]
                    break
                occurrence_count += 1

        result.append(found_value)

    return result


def dmi(di_length: int, adx_smoothing: int, high: Source, low: Source, close: Source):
    length = max(len(high), len(low), len(close))
    plus_dm: series_float = []
    minus_dm: series_float = []
    true_range_values = tr(False, high, low, close)

    for i in range(length):
        if i == 0:
            plus_dm.append(0.0)
            minus_dm.append(0.0)
        else:
            up_move = high[i] - high[i - 1]
            down_move = low[i - 1] - low[i]

            plus_dm_val = 0.0
            minus_dm_val = 0.0

            if up_move > down_move and up_move > 0:
                plus_dm_val = up_move
            if down_move > up_move and down_move > 0:
                minus_dm_val = down_move

            plus_dm.append(plus_dm_val)
            minus_dm.append(minus_dm_val)

    smoothed_plus_dm = rma(plus_dm, di_length)
    smoothed_minus_dm = rma(minus_dm, di_length)
    smoothed_tr = rma(true_range_values, di_length)

    plus_di: series_float = []
    minus_di: series_float = []

    for i in range(length):
        if smoothed_tr[i] == 0:
            plus_di.append(0.0)
            minus_di.append(0.0)
        else:
            plus_di.append((smoothed_plus_dm[i] / smoothed_tr[i]) * 100)
            minus_di.append((smoothed_minus_dm[i] / smoothed_tr[i]) * 100)

    dx: series_float = []
    for i in range(length):
        total = plus_di[i] + minus_di[i]
        if total == 0:
            dx.append(0.0)
        else:
            dx.append((abs(plus_di[i] - minus_di[i]) / total) * 100)

    adx_values = rma(dx, adx_smoothing)

    return [plus_di, minus_di, adx_values]


def tsi(source: Source, short_length: int, long_length: int) -> series_float:
    momentum: series_float = []

    for i in range(len(source)):
        if i == 0:
            momentum.append(float('nan'))
        else:
            momentum.append(source[i] - source[i - 1])

    smoothed_momentum = ema(ema(momentum, long_length), short_length)

    abs_momentum = [abs(v) for v in momentum]
    smoothed_abs_momentum = ema(ema(abs_momentum, long_length), short_length)

    result: series_float = []
    for i in range(len(source)):
        if smoothed_abs_momentum[i] == 0:
            result.append(0.0)
        else:
            result.append((smoothed_momentum[i] / smoothed_abs_momentum[i]) * 100)

    return result


def cmo(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length:
            result.append(float('nan'))
            continue

        sum_gains = 0.0
        sum_losses = 0.0

        for j in range(length):
            change_val = source[i - j] - source[i - j - 1]
            if change_val > 0:
                sum_gains += change_val
            else:
                sum_losses += abs(change_val)

        total_movement = sum_gains + sum_losses
        if total_movement == 0:
            result.append(0.0)
        else:
            cmo_value = ((sum_gains - sum_losses) / total_movement) * 100
            result.append(cmo_value)

    return result


def kc(source: Source, length: int, mult: float, use_true_range: bool = True, high: Source = None, low: Source = None, close: Source = None):
    middle = ema(source, length)

    if use_true_range:
        if high is None or low is None or close is None:
            raise ValueError('ta.kc() with use_true_range=True requires high, low, and close data')
        range_values = tr(False, high, low, close)
    else:
        if high is None or low is None:
            raise ValueError('ta.kc() requires high and low data')
        range_values = []
        for i in range(len(high)):
            range_values.append(high[i] - low[i])

    range_ema = ema(range_values, length)

    upper: series_float = []
    lower: series_float = []

    for i in range(len(middle)):
        upper.append(middle[i] + range_ema[i] * mult)
        lower.append(middle[i] - range_ema[i] * mult)

    return [middle, upper, lower]


def bbw(source: Source, length: int, mult: float) -> series_float:
    basis, upper, lower = bb(source, length, mult)
    result: series_float = []

    for i in range(len(source)):
        if basis[i] == 0:
            result.append(float('nan'))
        else:
            width = ((upper[i] - lower[i]) / basis[i]) * 100
            result.append(width)

    return result


def wpr(high: Source, low: Source, close: Source, length: int = 14) -> series_float:
    result: series_float = []

    for i in range(len(close)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        highest_high = high[i - length + 1]
        lowest_low = low[i - length + 1]

        for j in range(i - length + 2, i + 1):
            if high[j] > highest_high:
                highest_high = high[j]
            if low[j] < lowest_low:
                lowest_low = low[j]

        range_val = highest_high - lowest_low
        if range_val == 0:
            result.append(float('nan'))
        else:
            wpr_value = ((highest_high - close[i]) / range_val) * -100
            result.append(wpr_value)

    return result


def vwap(source: Source, volume: Source) -> series_float:
    if len(source) != len(volume):
        raise ValueError('ta.vwap: source and volume must have the same length')

    result: series_float = []
    cumulative_pv = 0.0
    cumulative_volume = 0.0

    for i in range(len(source)):
        if math.isnan(source[i]) or math.isnan(volume[i]):
            result.append(float('nan'))
            continue

        cumulative_pv += source[i] * volume[i]
        cumulative_volume += volume[i]

        if cumulative_volume == 0:
            result.append(float('nan'))
        else:
            result.append(cumulative_pv / cumulative_volume)

    return result


def alma(source: Source, length: int = 9, offset: float = 0.85, sigma: float = 6, floor: bool = False) -> series_float:
    result: series_float = []
    m = int(offset * (length - 1)) if floor else offset * (length - 1)
    s = length / sigma

    weights = []
    weight_sum = 0.0

    for i in range(length):
        weight = math.exp(-1 * (i - m) ** 2 / (2 * s ** 2))
        weights.append(weight)
        weight_sum += weight

    for i in range(length):
        weights[i] /= weight_sum

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        alma_value = 0.0
        for j in range(length):
            alma_value += source[i - length + 1 + j] * weights[j]

        result.append(alma_value)

    return result


def kcw(source: Source, length: int = 20, mult: float = 2, use_true_range: bool = True, high: Source = None, low: Source = None, close: Source = None) -> series_float:
    basis, upper, lower = kc(source, length, mult, use_true_range, high, low, close)
    result: series_float = []

    for i in range(len(source)):
        if math.isnan(basis[i]) or basis[i] == 0:
            result.append(float('nan'))
        else:
            width = ((upper[i] - lower[i]) / basis[i]) * 100
            result.append(width)

    return result


def range_(high: Source, low: Source) -> series_float:
    if len(high) != len(low):
        raise ValueError('ta.range: high and low must have the same length')

    result: series_float = []

    for i in range(len(high)):
        if math.isnan(high[i]) or math.isnan(low[i]):
            result.append(float('nan'))
        else:
            result.append(high[i] - low[i])

    return result


def highestbars(source: Source, length: int) -> series_int:
    result: series_int = []

    for i in range(len(source)):
        window_start = max(0, i - length + 1)
        highest_value = source[window_start]
        highest_offset = i - window_start

        for j in range(window_start + 1, i + 1):
            if source[j] > highest_value:
                highest_value = source[j]
                highest_offset = i - j

        result.append(highest_offset)

    return result


def lowestbars(source: Source, length: int) -> series_int:
    result: series_int = []

    for i in range(len(source)):
        window_start = max(0, i - length + 1)
        lowest_value = source[window_start]
        lowest_offset = i - window_start

        for j in range(window_start + 1, i + 1):
            if source[j] < lowest_value:
                lowest_value = source[j]
                lowest_offset = i - j

        result.append(lowest_offset)

    return result


def max_(source1: Source, source2: Source) -> series_float:
    if len(source1) != len(source2):
        raise ValueError('ta.max: source1 and source2 must have the same length')

    result: series_float = []

    for i in range(len(source1)):
        if math.isnan(source1[i]) or math.isnan(source2[i]):
            result.append(float('nan'))
        else:
            result.append(max(source1[i], source2[i]))

    return result


def min_(source1: Source, source2: Source) -> series_float:
    if len(source1) != len(source2):
        raise ValueError('ta.min: source1 and source2 must have the same length')

    result: series_float = []

    for i in range(len(source1)):
        if math.isnan(source1[i]) or math.isnan(source2[i]):
            result.append(float('nan'))
        else:
            result.append(min(source1[i], source2[i]))

    return result


def cog(source: Source, length: int = 10) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        numerator = 0.0
        denominator = 0.0

        for j in range(length):
            weight = j + 1
            price = source[i - length + 1 + j]
            numerator += weight * price
            denominator += price

        if denominator == 0:
            result.append(float('nan'))
        else:
            cog_val = -1 * (numerator / denominator) + (length + 1) / 2
            result.append(cog_val)

    return result


def mode(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        values = []
        for j in range(length):
            value = source[i - j]
            if not math.isnan(value):
                values.append(value)

        if len(values) == 0:
            result.append(float('nan'))
            continue

        frequency_map = {}
        for value in values:
            frequency_map[value] = frequency_map.get(value, 0) + 1

        max_frequency = max(frequency_map.values())

        modes_with_max_freq = [v for v, freq in frequency_map.items() if freq == max_frequency]

        result.append(min(modes_with_max_freq))

    return result


def percentile_linear_interpolation(source: Source, length: int, percentage: float) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        values = []
        for j in range(length):
            values.append(source[i - j])

        if any(math.isnan(v) for v in values):
            result.append(float('nan'))
            continue

        sorted_vals = sorted(values)

        position = (percentage / 100) * (len(sorted_vals) - 1)
        lower_index = int(position)
        upper_index = math.ceil(position)

        if lower_index == upper_index:
            result.append(sorted_vals[lower_index])
        else:
            fraction = position - lower_index
            interpolated = sorted_vals[lower_index] + fraction * (sorted_vals[upper_index] - sorted_vals[lower_index])
            result.append(interpolated)

    return result


def percentile_nearest_rank(source: Source, length: int, percentage: float) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        values = []
        for j in range(length):
            value = source[i - j]
            if not math.isnan(value):
                values.append(value)

        if len(values) == 0:
            result.append(float('nan'))
            continue

        sorted_vals = sorted(values)

        if percentage >= 100:
            result.append(sorted_vals[-1])
            continue

        rank = math.ceil((percentage / 100) * len(sorted_vals))

        index = max(0, rank - 1)

        result.append(sorted_vals[index])

    return result


def rci(source: Source, length: int) -> series_float:
    result: series_float = []

    for i in range(len(source)):
        if i < length - 1:
            result.append(float('nan'))
            continue

        values = []
        for j in range(length):
            values.append(source[i - length + 1 + j])

        if any(math.isnan(v) for v in values):
            result.append(float('nan'))
            continue

        indexed = [(value, idx) for idx, value in enumerate(values)]

        sorted_indexed = sorted(indexed, key=lambda x: x[0])

        ranks = [0.0] * length
        j = 0
        while j < len(sorted_indexed):
            tie_count = 1
            while j + tie_count < len(sorted_indexed) and sorted_indexed[j][0] == sorted_indexed[j + tie_count][0]:
                tie_count += 1

            current_rank = j + 1
            avg_rank = (current_rank + (current_rank + tie_count - 1)) / 2

            for k in range(tie_count):
                ranks[sorted_indexed[j + k][1]] = avg_rank

            j += tie_count

        sum_squared_diff = 0.0
        for j in range(length):
            time_rank = j + 1
            diff = ranks[j] - time_rank
            sum_squared_diff += diff * diff

        n = length
        base = (n * n * n - n) / 12

        tie_correction = 0.0
        j = 0
        while j < len(sorted_indexed):
            tie_count = 1
            while j + tie_count < len(sorted_indexed) and sorted_indexed[j][0] == sorted_indexed[j + tie_count][0]:
                tie_count += 1
            if tie_count > 1:
                tie_correction += (tie_count * tie_count * tie_count - tie_count) / 12
            j += tie_count

        a = base - tie_correction
        b = base

        if a == 0 or b == 0:
            rho = 0.0
        else:
            rho = (a + b - sum_squared_diff) / (2 * math.sqrt(a * b))

        result.append(rho * 100)

    return result


def _calculate_pivot_levels(type_str, h, l, c, o):
    if math.isnan(h) or math.isnan(l) or math.isnan(c):
        return [float('nan')] * 11

    levels = [float('nan')] * 11

    if type_str in ('Traditional', 'Fibonacci', 'Classic'):
        p = (h + l + c) / 3
    elif type_str == 'Woodie':
        p = (h + l + 2 * c) / 4
    elif type_str == 'DM':
        p = (h + l + c) / 3
    elif type_str == 'Camarilla':
        p = (h + l + c) / 3
    else:
        p = (h + l + c) / 3

    levels[0] = p

    if type_str in ('Traditional', 'Classic'):
        levels[1] = 2 * p - l
        levels[2] = 2 * p - h
        levels[3] = p + (h - l)
        levels[4] = p - (h - l)
        levels[5] = h + 2 * (p - l)
        levels[6] = l - 2 * (h - p)
        levels[7] = levels[5] + (h - l)
        levels[8] = levels[6] - (h - l)
        levels[9] = levels[7] + (h - l)
        levels[10] = levels[8] - (h - l)

    elif type_str == 'Fibonacci':
        levels[1] = p + 0.382 * (h - l)
        levels[2] = p - 0.382 * (h - l)
        levels[3] = p + 0.618 * (h - l)
        levels[4] = p - 0.618 * (h - l)
        levels[5] = p + (h - l)
        levels[6] = p - (h - l)
        levels[7] = levels[5] + 0.618 * (h - l)
        levels[8] = levels[6] - 0.618 * (h - l)
        levels[9] = levels[7] + 0.382 * (h - l)
        levels[10] = levels[8] - 0.382 * (h - l)

    elif type_str == 'Woodie':
        levels[1] = 2 * p - l
        levels[2] = 2 * p - h
        levels[3] = p + (h - l)
        levels[4] = p - (h - l)
        levels[5] = h + 2 * (p - l)
        levels[6] = l - 2 * (h - p)
        levels[7] = levels[5] + (h - l)
        levels[8] = levels[6] - (h - l)
        levels[9] = levels[7] + (h - l)
        levels[10] = levels[8] - (h - l)

    elif type_str == 'DM':
        x = h + l + (c * 2) + (c if math.isnan(o) else o)
        new_p = x / (4 if math.isnan(o) else 5)
        levels[0] = new_p
        levels[1] = x / 2 - l
        levels[2] = x / 2 - h

    elif type_str == 'Camarilla':
        range_val = h - l
        levels[1] = c + range_val * 1.1 / 12
        levels[2] = c - range_val * 1.1 / 12
        levels[3] = c + range_val * 1.1 / 6
        levels[4] = c - range_val * 1.1 / 6
        levels[5] = c + range_val * 1.1 / 4
        levels[6] = c - range_val * 1.1 / 4
        levels[7] = c + range_val * 1.1 / 2
        levels[8] = c - range_val * 1.1 / 2
        levels[9] = h
        levels[10] = l

    return levels


def pivot_point_levels(type_val, anchor, developing=False, high=None, low=None, close=None, open_=None):
    type_str = type_val if isinstance(type_val, str) else str(type_val[0])
    is_developing = developing if isinstance(developing, bool) else developing[0]

    if type_str == 'Woodie' and is_developing:
        raise ValueError('ta.pivot_point_levels: Woodie type cannot use developing=True')

    length = len(anchor)
    if high is not None and len(high) != length:
        raise ValueError('High series length mismatch')
    if low is not None and len(low) != length:
        raise ValueError('Low series length mismatch')
    if close is not None and len(close) != length:
        raise ValueError('Close series length mismatch')
    if open_ is not None and len(open_) != length:
        raise ValueError('Open series length mismatch')

    results = [[] for _ in range(11)]

    last_h = float('nan')
    last_l = float('nan')
    last_c = float('nan')
    last_o = float('nan')
    last_anchor_index = -1

    for i in range(length):
        if anchor[i]:
            last_anchor_index = i
            last_h = high[i] if high else float('nan')
            last_l = low[i] if low else float('nan')
            last_c = close[i] if close else float('nan')
            last_o = open_[i] if open_ else float('nan')

        if is_developing and last_anchor_index >= 0:
            h = max(v for v in high[last_anchor_index:i + 1] if not math.isnan(v)) if high else float('nan')
            l = min(v for v in low[last_anchor_index:i + 1] if not math.isnan(v)) if low else float('nan')
            c = close[i] if close else float('nan')
            o = open_[last_anchor_index] if open_ and last_anchor_index >= 0 else float('nan')
        else:
            h = last_h
            l = last_l
            c = last_c
            o = last_o

        levels = _calculate_pivot_levels(type_str, h, l, c, o)

        for j in range(11):
            results[j].append(levels[j])

    return results


def ichimoku(conversion_periods: int, base_periods: int, lagging_span2_periods: int, displacement: int, high: Source, low: Source, close: Source):
    length = len(high)

    highest_conversion = highest(high, conversion_periods)
    lowest_conversion = lowest(low, conversion_periods)
    tenkan_sen: series_float = []
    for i in range(length):
        if math.isnan(highest_conversion[i]) or math.isnan(lowest_conversion[i]):
            tenkan_sen.append(float('nan'))
        else:
            tenkan_sen.append((highest_conversion[i] + lowest_conversion[i]) / 2)

    highest_base = highest(high, base_periods)
    lowest_base = lowest(low, base_periods)
    kijun_sen: series_float = []
    for i in range(length):
        if math.isnan(highest_base[i]) or math.isnan(lowest_base[i]):
            kijun_sen.append(float('nan'))
        else:
            kijun_sen.append((highest_base[i] + lowest_base[i]) / 2)

    senkou_span_a: series_float = []
    for i in range(length):
        source_index = i - displacement
        if source_index < 0 or math.isnan(tenkan_sen[source_index]) or math.isnan(kijun_sen[source_index]):
            senkou_span_a.append(float('nan'))
        else:
            senkou_span_a.append((tenkan_sen[source_index] + kijun_sen[source_index]) / 2)

    highest_lagging = highest(high, lagging_span2_periods)
    lowest_lagging = lowest(low, lagging_span2_periods)
    senkou_span_b: series_float = []
    for i in range(length):
        source_index = i - displacement
        if source_index < 0 or math.isnan(highest_lagging[source_index]) or math.isnan(lowest_lagging[source_index]):
            senkou_span_b.append(float('nan'))
        else:
            senkou_span_b.append((highest_lagging[source_index] + lowest_lagging[source_index]) / 2)

    chikou_span: series_float = []
    for i in range(length):
        source_index = i + displacement
        if source_index >= length or math.isnan(close[source_index]):
            chikou_span.append(float('nan'))
        else:
            chikou_span.append(close[source_index])

    return [tenkan_sen, kijun_sen, senkou_span_a, senkou_span_b, chikou_span]


def zigzag(deviation: float = 5.0, depth: int = 10, backstep: int = 3, source: Source = None, high: Source = None, low: Source = None):
    if high is not None and low is not None:
        high_source = high
        low_source = low
    elif source is not None:
        high_source = source
        low_source = source
    else:
        raise ValueError(
            'ta.zigzag() requires either source series or high/low series. '
            'Pass them explicitly.'
        )

    length = len(high_source)
    if len(low_source) != length:
        raise ValueError('ta.zigzag: high and low must have the same length')

    zigzag_values: series_float = [float('nan')] * length
    directions: series_int = [0] * length
    is_pivot: series_bool = [False] * length

    def get_deviation(price1, price2):
        if abs(price1) < 1e-10 or math.isnan(price1) or math.isnan(price2):
            return 0.0
        return abs((price2 - price1) / price1) * 100

    last_confirmed_pivot = None
    potential_pivot = None
    current_direction = 0

    confirmed_pivots = []

    start_index = -1
    initial_highest = -math.inf
    initial_lowest = math.inf
    initial_high_index = -1
    initial_low_index = -1

    for i in range(min(depth, length)):
        if not math.isnan(high_source[i]) and high_source[i] > initial_highest:
            initial_highest = high_source[i]
            initial_high_index = i
        if not math.isnan(low_source[i]) and low_source[i] < initial_lowest:
            initial_lowest = low_source[i]
            initial_low_index = i

    if initial_high_index >= 0 and initial_low_index >= 0:
        if initial_low_index <= initial_high_index:
            last_confirmed_pivot = {'index': initial_low_index, 'price': initial_lowest, 'type': 'low'}
            current_direction = 1
        else:
            last_confirmed_pivot = {'index': initial_high_index, 'price': initial_highest, 'type': 'high'}
            current_direction = -1
        confirmed_pivots.append(last_confirmed_pivot)
        start_index = last_confirmed_pivot['index'] + 1
    else:
        start_index = depth

    for i in range(max(start_index, depth), length):
        current_high = high_source[i]
        current_low = low_source[i]

        if math.isnan(current_high) or math.isnan(current_low):
            directions[i] = current_direction
            continue

        is_potential_high = True
        for j in range(1, backstep + 1):
            if i - j < 0:
                break
            if not math.isnan(high_source[i - j]) and high_source[i - j] >= current_high:
                is_potential_high = False
                break

        is_potential_low = True
        for j in range(1, backstep + 1):
            if i - j < 0:
                break
            if not math.isnan(low_source[i - j]) and low_source[i - j] <= current_low:
                is_potential_low = False
                break

        if current_direction == 1:
            if is_potential_high:
                if potential_pivot is None or potential_pivot['type'] != 'high':
                    if last_confirmed_pivot and get_deviation(last_confirmed_pivot['price'], current_high) >= deviation:
                        potential_pivot = {'index': i, 'price': current_high, 'type': 'high'}
                else:
                    if current_high > potential_pivot['price']:
                        potential_pivot = {'index': i, 'price': current_high, 'type': 'high'}

            if potential_pivot and potential_pivot['type'] == 'high':
                deviation_from_potential = get_deviation(potential_pivot['price'], current_low)
                if deviation_from_potential >= deviation and i - potential_pivot['index'] >= backstep:
                    confirmed_pivots.append(potential_pivot)
                    last_confirmed_pivot = potential_pivot
                    current_direction = -1
                    potential_pivot = None

        elif current_direction == -1:
            if is_potential_low:
                if potential_pivot is None or potential_pivot['type'] != 'low':
                    if last_confirmed_pivot and get_deviation(last_confirmed_pivot['price'], current_low) >= deviation:
                        potential_pivot = {'index': i, 'price': current_low, 'type': 'low'}
                else:
                    if current_low < potential_pivot['price']:
                        potential_pivot = {'index': i, 'price': current_low, 'type': 'low'}

            if potential_pivot and potential_pivot['type'] == 'low':
                deviation_from_potential = get_deviation(potential_pivot['price'], current_high)
                if deviation_from_potential >= deviation and i - potential_pivot['index'] >= backstep:
                    confirmed_pivots.append(potential_pivot)
                    last_confirmed_pivot = potential_pivot
                    current_direction = 1
                    potential_pivot = None

        else:
            if last_confirmed_pivot:
                if last_confirmed_pivot['type'] == 'low' and get_deviation(last_confirmed_pivot['price'], current_high) >= deviation:
                    current_direction = 1
                elif last_confirmed_pivot['type'] == 'high' and get_deviation(last_confirmed_pivot['price'], current_low) >= deviation:
                    current_direction = -1

        directions[i] = current_direction

    last_potential_was_added = potential_pivot is not None
    if potential_pivot:
        confirmed_pivots.append(potential_pivot)

    for pivot in confirmed_pivots:
        zigzag_values[pivot['index']] = pivot['price']
        is_pivot[pivot['index']] = True

    current_dir = 0
    pivot_idx = 0
    num_confirmed = len(confirmed_pivots) - 1 if last_potential_was_added else len(confirmed_pivots)

    for i in range(length):
        while pivot_idx < num_confirmed and confirmed_pivots[pivot_idx]['index'] <= i:
            pivot = confirmed_pivots[pivot_idx]
            current_dir = 1 if pivot['type'] == 'low' else -1
            pivot_idx += 1
        directions[i] = current_dir

    return [zigzag_values, directions, is_pivot]
