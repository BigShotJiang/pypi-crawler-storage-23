"""ZigZag library — identifies trend reversals via pivot highs and lows."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .._types import Bar


@dataclass
class ZigZagSettings:
    dev_threshold: float = 5.0
    depth: int = 10
    line_color: str = "#2962FF"
    extend_last: bool = True
    display_reversal_price: bool = True
    display_cumulative_volume: bool = True
    display_reversal_price_change: bool = True
    difference_price_mode: str = "Absolute"
    allow_zigzag_on_one_bar: bool = True


@dataclass
class ZigZagPoint:
    time: int
    bar_index: int
    price: float


@dataclass
class ZigZagPivot:
    is_high: bool
    volume: float
    start: ZigZagPoint
    end: ZigZagPoint


@dataclass
class ZigZagResult:
    pivots: list[ZigZagPivot]
    extension: ZigZagPivot | None


class ZigZag:
    def __init__(self, settings: ZigZagSettings | None = None) -> None:
        self.settings = settings or ZigZagSettings()
        self.pivots: list[ZigZagPivot] = []
        self.sum_vol: float = 0.0
        self._high_buffer: list[float] = []
        self._low_buffer: list[float] = []
        self._time_buffer: list[int] = []
        self._bar_count: int = 0

    def update(self, bar: Bar, bar_index: int) -> bool:
        self._high_buffer.append(bar.high)
        self._low_buffer.append(bar.low)
        self._time_buffer.append(bar.time)
        self._bar_count += 1

        depth = max(2, self.settings.depth // 2)
        self.sum_vol += bar.volume

        if self._bar_count < depth * 2 + 1:
            return False

        changed = self._try_find_pivot(True, depth, bar_index)
        changed = self._try_find_pivot(
            False, depth, bar_index,
            self.settings.allow_zigzag_on_one_bar or not changed,
        ) or changed
        return changed

    def last_pivot(self) -> ZigZagPivot | None:
        return self.pivots[-1] if self.pivots else None

    def get_extension(self, current_bar: Bar, bar_index: int) -> ZigZagPivot | None:
        if not self.settings.extend_last:
            return None
        last = self.last_pivot()
        if last is None:
            return None
        is_high = not last.is_high
        price = current_bar.high if is_high else current_bar.low
        return ZigZagPivot(
            is_high=is_high, volume=self.sum_vol,
            start=last.end, end=ZigZagPoint(time=current_bar.time, bar_index=bar_index, price=price),
        )

    def _try_find_pivot(self, is_high: bool, depth: int, current_bar_index: int, register: bool = True) -> bool:
        point = self._find_pivot_point(is_high, depth, current_bar_index)
        if point is None or not register:
            return False
        return self._new_pivot_found(is_high, point)

    def _find_pivot_point(self, is_high: bool, depth: int, current_bar_index: int) -> ZigZagPoint | None:
        buffer = self._high_buffer if is_high else self._low_buffer
        pivot_idx = len(buffer) - 1 - depth
        if pivot_idx < depth:
            return None
        pivot_price = buffer[pivot_idx]

        for i in range(pivot_idx + 1, len(buffer)):
            p = buffer[i]
            if is_high and p > pivot_price:
                return None
            if not is_high and p < pivot_price:
                return None

        for i in range(pivot_idx - depth, pivot_idx):
            p = buffer[i]
            if is_high and p >= pivot_price:
                return None
            if not is_high and p <= pivot_price:
                return None

        return ZigZagPoint(
            time=self._time_buffer[pivot_idx],
            bar_index=current_bar_index - depth,
            price=pivot_price,
        )

    def _calc_dev(self, base_price: float, price: float) -> float:
        return 100 * (price - base_price) / abs(base_price) if base_price != 0 else 0.0

    def _new_pivot_found(self, is_high: bool, point: ZigZagPoint) -> bool:
        last = self.last_pivot()
        if last is None:
            self.pivots.append(ZigZagPivot(is_high=is_high, volume=self.sum_vol, start=point, end=point))
            self.sum_vol = 0.0
            return True

        if last.is_high == is_high:
            more_extreme = (point.price > last.end.price) if is_high else (point.price < last.end.price)
            if more_extreme:
                last.end = point
                last.volume += self.sum_vol
                self.sum_vol = 0.0
                return True
        else:
            dev = self._calc_dev(last.end.price, point.price)
            threshold = self.settings.dev_threshold
            meets = (dev <= -threshold) if last.is_high else (dev >= threshold)
            if meets:
                self.pivots.append(ZigZagPivot(is_high=is_high, volume=self.sum_vol, start=last.end, end=point))
                self.sum_vol = 0.0
                return True
        return False


def calculate_zigzag(bars: list[Bar], settings: ZigZagSettings | None = None) -> ZigZagResult:
    if not bars:
        return ZigZagResult(pivots=[], extension=None)
    zz = ZigZag(settings)
    for i, bar in enumerate(bars):
        zz.update(bar, i)
    extension = zz.get_extension(bars[-1], len(bars) - 1)
    return ZigZagResult(pivots=zz.pivots, extension=extension)
