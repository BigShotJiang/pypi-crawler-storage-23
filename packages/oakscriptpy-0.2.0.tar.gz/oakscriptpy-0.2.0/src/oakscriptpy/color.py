"""Color namespace — mirrors PineScript color.* functions."""

from __future__ import annotations

import re

# Named color constants
aqua = "#00FFFF"
black = "#000000"
blue = "#0000FF"
fuchsia = "#FF00FF"
gray = "#808080"
green = "#00FF00"
lime = "#00FF00"
maroon = "#800000"
navy = "#000080"
olive = "#808000"
orange = "#FFA500"
purple = "#800080"
red = "#FF0000"
silver = "#C0C0C0"
teal = "#008080"
white = "#FFFFFF"
yellow = "#FFFF00"


def rgb(red: int, green: int, blue: int, transp: float | None = None) -> str:
    r = max(0, min(255, red))
    g = max(0, min(255, green))
    b = max(0, min(255, blue))
    a = 1 - (transp / 100) if transp is not None else 1.0
    if a == 1:
        return f"rgb({r}, {g}, {b})"
    return f"rgba({r}, {g}, {b}, {a})"


def from_hex(hex_str: str, transp: float | None = None) -> str:
    hex_str = hex_str.lstrip("#")
    r = int(hex_str[0:2], 16)
    g = int(hex_str[2:4], 16)
    b = int(hex_str[4:6], 16)
    return rgb(r, g, b, transp)


def new_color(base_color: str, transp: float) -> str:
    rgba = _parse_color(base_color)
    return rgb(rgba["r"], rgba["g"], rgba["b"], transp)


# Alias for PineScript color.new()
new = new_color


def r(clr: str) -> int:
    return _parse_color(clr)["r"]


def g(clr: str) -> int:
    return _parse_color(clr)["g"]


def b(clr: str) -> int:
    return _parse_color(clr)["b"]


def t(clr: str) -> float:
    return _parse_color(clr)["t"]


def from_gradient(
    value: float,
    bottom_value: float,
    top_value: float,
    bottom_color: str,
    top_color: str,
) -> str:
    c1 = _parse_color_rgba(bottom_color)
    c2 = _parse_color_rgba(top_color)

    if value <= bottom_value:
        f = 0.0
    elif value >= top_value:
        f = 1.0
    else:
        f = (value - bottom_value) / (top_value - bottom_value)

    r = builtins_round(c1[0] + (c2[0] - c1[0]) * f)
    g = builtins_round(c1[1] + (c2[1] - c1[1]) * f)
    b = builtins_round(c1[2] + (c2[2] - c1[2]) * f)
    a = c1[3] + (c2[3] - c1[3]) * f

    if a == 1:
        return f"rgb({r}, {g}, {b})"
    return f"rgba({r}, {g}, {b}, {a})"


builtins_round = __builtins__["round"] if isinstance(__builtins__, dict) else getattr(__builtins__, "round")


def _parse_color(clr: str) -> dict:
    if isinstance(clr, str):
        m = re.match(r"rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)", clr)
        if m:
            return {
                "r": int(m.group(1)),
                "g": int(m.group(2)),
                "b": int(m.group(3)),
                "t": (1 - float(m.group(4))) * 100 if m.group(4) else 0.0,
            }
        if clr.startswith("#"):
            h = clr.lstrip("#")
            return {
                "r": int(h[0:2], 16),
                "g": int(h[2:4], 16),
                "b": int(h[4:6], 16),
                "t": 0.0,
            }
    return {"r": 0, "g": 0, "b": 0, "t": 0.0}


def _parse_color_rgba(clr: str) -> tuple[int, int, int, float]:
    if isinstance(clr, str):
        if clr.startswith("#"):
            h = clr.lstrip("#")
            return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 1.0)
        m = re.match(r"rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)", clr)
        if m:
            return (
                int(m.group(1)),
                int(m.group(2)),
                int(m.group(3)),
                float(m.group(4)) if m.group(4) else 1.0,
            )
    return (0, 0, 0, 1.0)
