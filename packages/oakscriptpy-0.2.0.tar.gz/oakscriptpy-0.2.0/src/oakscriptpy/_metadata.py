"""Indicator metadata types for oakscriptPy."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


PlotStyle = str  # 'line' | 'stepline' | 'histogram' | 'area' | 'circles' | 'columns' | 'cross' | 'areabr' | 'steplinebr' | 'linebr'
LineStyle = str  # 'solid' | 'dashed' | 'dotted'
PlotDisplay = str  # 'all' | 'none' | 'data_window' | 'status_line' | 'pane'
InputType = str  # 'int' | 'float' | 'bool' | 'string' | 'source' | 'color' | 'timeframe' | 'session'


@dataclass
class PlotOptions:
    title: str | None = None
    color: str | None = None
    linewidth: int | None = None
    style: str | None = None
    trackprice: bool | None = None
    histbase: float | None = None
    offset: int | None = None
    join: bool | None = None
    editable: bool | None = None
    display: str | None = None
    transp: int | None = None


@dataclass
class HLineOptions:
    title: str | None = None
    color: str | None = None
    linestyle: str | None = None
    linewidth: int | None = None
    editable: bool | None = None


@dataclass
class FillOptions:
    color: str | None = None
    transp: int | None = None
    title: str | None = None
    editable: bool | None = None
    fillgaps: bool | None = None


@dataclass
class InputMetadata:
    type: str
    name: str
    title: str
    defval: Any
    minval: float | None = None
    maxval: float | None = None
    step: float | None = None
    tooltip: str | None = None
    inline: str | None = None
    group: str | None = None
    options: list[Any] | None = None
    confirm: bool | None = None


@dataclass
class PlotMetadata:
    var_name: str
    title: str
    color: str
    linewidth: int
    style: str


@dataclass
class IndicatorMetadata:
    title: str
    shorttitle: str | None = None
    overlay: bool = False
    precision: int | None = None
    format: str | None = None
    timeframe: str | None = None
    timeframe_gaps: bool | None = None
    inputs: list[InputMetadata] | None = None
    plots: list[PlotMetadata] | None = None


@dataclass
class TimeValue:
    time: Any
    value: float
    color: str | None = None


@dataclass
class PlotData:
    data: list[TimeValue]
    options: PlotOptions | None = None


@dataclass
class HLineData:
    value: float
    options: HLineOptions | None = None


@dataclass
class FillData:
    plot1: int | str
    plot2: int | str
    options: FillOptions | None = None
    colors: list[str] | None = None


@dataclass
class IndicatorResult:
    metadata: IndicatorMetadata
    plots: dict[str, list[TimeValue]]
    hlines: list[HLineData] | None = None
    fills: list[FillData] | None = None
