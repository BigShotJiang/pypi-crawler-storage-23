"""Runtime type definitions — Protocol classes for adapters."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Protocol


class SeriesHandle(Protocol):
    def set_data(self, data: list[dict[str, Any]]) -> None: ...


class ChartAdapter(Protocol):
    def add_series(self, type: str, options: dict[str, Any] | None = None) -> SeriesHandle: ...
    def remove_series(self, series: SeriesHandle) -> None: ...


@dataclass
class InputConfig:
    id: str
    type: str  # 'int' | 'float' | 'bool' | 'string' | 'source' | 'color'
    defval: Any
    title: str | None = None
    min: float | None = None
    max: float | None = None
    step: float | None = None
    options: list[str] | None = None


class InputAdapter(Protocol):
    def register_input(self, config: InputConfig) -> Any: ...
    def get_value(self, id: str) -> Any: ...
    def set_value(self, id: str, value: Any) -> None: ...
    def on_input_change(self, callback: Callable[[str, Any], None]) -> None: ...


@dataclass
class OhlcvData:
    time: list[int]
    open: list[float]
    high: list[float]
    low: list[float]
    close: list[float]
    volume: list[float]


@dataclass
class OakScriptContext:
    chart: Any  # ChartAdapter
    inputs: Any  # InputAdapter
    ohlcv: OhlcvData
    bar_index: int = 0
