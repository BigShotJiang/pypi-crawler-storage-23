"""String namespace — mirrors PineScript str.* functions."""

from __future__ import annotations

import re as _re
from datetime import datetime, timezone


def length(s: str) -> int:
    return len(s)


def tostring(value: object, fmt: str | None = None) -> str:
    if isinstance(value, (int, float)) and fmt:
        decimals = len(fmt.split(".")[1]) if "." in fmt else 0
        return f"{value:.{decimals}f}"
    return str(value)


def tonumber(s: str) -> float | None:
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def substring(s: str, begin: int, end: int | None = None) -> str:
    if end is None:
        return s[begin:]
    return s[begin:end]


def upper(s: str) -> str:
    return s.upper()


def lower(s: str) -> str:
    return s.lower()


def contains(source: str, sub: str) -> bool:
    return sub in source


def pos(source: str, sub: str) -> int:
    return source.find(sub)


def replace(source: str, target: str, replacement: str, occurrence: int | None = None) -> str:
    if occurrence == 0:
        return source.replace(target, replacement, 1)
    return source.replace(target, replacement)


def replace_all(source: str, target: str, replacement: str) -> str:
    return source.replace(target, replacement)


def split(s: str, separator: str) -> list[str]:
    return s.split(separator)


def concat(*strings: str) -> str:
    return "".join(strings)


def format(format_str: str, *args: object) -> str:
    result = format_str
    for i, arg in enumerate(args):
        result = result.replace(f"{{{i}}}", str(arg))
    return result


def startswith(source: str, prefix: str) -> bool:
    return source.startswith(prefix)


def endswith(source: str, suffix: str) -> bool:
    return source.endswith(suffix)


def char_at(s: str, position: int) -> str:
    if 0 <= position < len(s):
        return s[position]
    return ""


def trim(s: str) -> str:
    return s.strip()


def trim_left(s: str) -> str:
    return s.lstrip()


def trim_right(s: str) -> str:
    return s.rstrip()


def match(source: str, regex: str) -> bool:
    return bool(_re.search(regex, source))


def repeat(source: str, count: int, separator: str = "") -> str | None:
    if source is None:
        return None
    if count <= 0:
        return ""
    return separator.join([source] * count)


def format_time(time_ms: int, fmt: str) -> str:
    dt = datetime.fromtimestamp(time_ms / 1000, tz=timezone.utc)

    month_names = [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December",
    ]
    month_names_short = [
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
    ]

    year = dt.year
    month = dt.month - 1
    day = dt.day
    hours = dt.hour
    minutes = dt.minute
    seconds = dt.second

    hours12 = hours % 12 or 12
    ampm = "AM" if hours < 12 else "PM"

    replacements = [
        ("yyyy", str(year)),
        ("yy", str(year)[-2:]),
        ("MMMM", month_names[month]),
        ("MMM", month_names_short[month]),
        ("MM", f"{month + 1:02d}"),
        ("M", str(month + 1)),
        ("dd", f"{day:02d}"),
        ("d", str(day)),
        ("HH", f"{hours:02d}"),
        ("H", str(hours)),
        ("hh", f"{hours12:02d}"),
        ("h", str(hours12)),
        ("mm", f"{minutes:02d}"),
        ("m", str(minutes)),
        ("ss", f"{seconds:02d}"),
        ("s", str(seconds)),
        ("a", ampm),
    ]

    # Two-pass replacement using unique tokens
    tokens: list[str] = []
    result = fmt
    for i, (pattern, value) in enumerate(replacements):
        token = f"\ufff0{i}\ufff1"
        result = result.replace(pattern, token)
        tokens.append(value)

    for i, value in enumerate(tokens):
        token = f"\ufff0{i}\ufff1"
        result = result.replace(token, value)

    return result
