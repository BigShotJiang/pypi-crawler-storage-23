"""Indicator factory — creates reusable indicator instances."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

from ._types import Bar
from .series import BuiltIns


@dataclass
class IndicatorMetadataConfig:
    title: str
    short_title: str | None = None
    overlay: bool = False
    format: str = "price"
    precision: int = 2


@dataclass
class IndicatorContext:
    data: list[Bar]
    open: list[float]
    high: list[float]
    low: list[float]
    close: list[float]
    volume: list[float]
    time: list[int]
    pane_index: int = 0


class IndicatorInstance:
    def __init__(self, metadata: IndicatorMetadataConfig, setup: Callable[[IndicatorContext], None]) -> None:
        self.metadata = metadata
        self._setup = setup
        self._pane_index = 0 if metadata.overlay else 1
        self._input_values: dict[str, Any] = {}

    @property
    def pane_index(self) -> int:
        return self._pane_index

    def is_overlay(self) -> bool:
        return self.metadata.overlay

    def update_inputs(self, inputs: dict[str, Any]) -> None:
        self._input_values.update(inputs)

    def get_input_values(self) -> dict[str, Any]:
        return dict(self._input_values)

    def calculate(self, data: list[Bar]) -> None:
        ctx = IndicatorContext(
            data=data,
            open=[b.open for b in data],
            high=[b.high for b in data],
            low=[b.low for b in data],
            close=[b.close for b in data],
            volume=[b.volume for b in data],
            time=[b.time for b in data],
            pane_index=self._pane_index,
        )
        self._setup(ctx)


class Script:
    """Decorator-style indicator: receives BuiltIns, returns computed results.

    Usage::

        @indicator("My SMA", overlay=True)
        def my_sma(b):
            return ta.sma(b.close, 14)

        result = my_sma.calculate(bars)
    """

    def __init__(self, metadata: IndicatorMetadataConfig, fn: Callable[[BuiltIns], Any]) -> None:
        self.metadata = metadata
        self._fn = fn

    def calculate(self, data: list[Bar]) -> Any:
        b = BuiltIns(data)
        return self._fn(b)


def indicator(
    title_or_metadata: str | IndicatorMetadataConfig,
    setup: Callable[[IndicatorContext], None] | None = None,
    /,
    *,
    overlay: bool = False,
    short_title: str | None = None,
    format: str = "price",
    precision: int = 2,
) -> Callable[[], IndicatorInstance] | Callable[..., Script]:
    """Create an indicator — as a factory (legacy) or as a decorator (new).

    Legacy API::

        factory = indicator(IndicatorMetadataConfig(...), setup_fn)
        instance = factory()
        instance.calculate(bars)

    Decorator API::

        @indicator("My Script", overlay=True)
        def my_script(b):
            return ta.sma(b.close, 14)

        result = my_script.calculate(bars)
    """
    if isinstance(title_or_metadata, str):
        metadata = IndicatorMetadataConfig(
            title=title_or_metadata,
            short_title=short_title or title_or_metadata,
            overlay=overlay,
            format=format,
            precision=precision,
        )

        def decorator(fn: Callable[[BuiltIns], Any]) -> Script:
            return Script(metadata, fn)

        return decorator

    # Legacy path: indicator(IndicatorMetadataConfig, setup_fn)
    metadata = title_or_metadata
    assert setup is not None, "setup function required for legacy indicator() API"
    normalized = IndicatorMetadataConfig(
        title=metadata.title,
        short_title=metadata.short_title or metadata.title,
        overlay=metadata.overlay,
        format=metadata.format,
        precision=metadata.precision,
    )

    def factory() -> IndicatorInstance:
        return IndicatorInstance(normalized, setup)

    return factory
