<p align="center">
  <img src="./logo.png" width="150" />
</p>

<h1 align="center">OakScriptPy</h1>

<p align="center">
  PineScript-like API for technical analysis in Python. Pure Python, zero dependencies.
</p>

---

## Install

```bash
pip install oakscriptpy
```

## Quick Start

```python
from oakscriptpy import indicator, ta, nz

@indicator("My SMA", overlay=True)
def my_sma(b):
    sma14 = ta.sma(b.close, 14)
    return nz(sma14)

# Run on bar data
from oakscriptpy._types import Bar
bars = [Bar(time=1, open=10, high=12, low=9, close=11, volume=100), ...]
result = my_sma.calculate(bars)
```

The `@indicator` decorator provides a `BuiltIns` object with pre-built Series for all standard fields:

| Variable | Description |
|----------|-------------|
| `b.open`, `b.high`, `b.low`, `b.close`, `b.volume` | OHLCV price data |
| `b.hl2`, `b.hlc3`, `b.ohlc4` | Derived composites |
| `b.bar_index`, `b.time` | Bar identity |

## PineScript-like Syntax

```python
from oakscriptpy import BuiltIns, ta, nz, fixnan, na

b = BuiltIns(bars)

# History access: close[1] instead of close.offset(1)
change = b.close - b.close[1]

# TA functions
sma = ta.sma(b.close, 14)
rsi = ta.rsi(b.close, 14)
macd_line, signal, hist = ta.macd(b.close, 12, 26, 9)

# na handling
safe = nz(sma)            # replace NaN with 0
filled = fixnan(sma)      # forward-fill NaN values
if na(sma.last()):
    pass

# Comparisons and logic
bullish = b.close > b.open
above_sma = b.close > sma
signal = bullish.and_(above_sma)
result = signal.iff(1, -1)
```

## Array-based API

For direct computation without Series overhead:

```python
from oakscriptpy import ta as ta_core

closes = [b.close for b in bars]
sma_values = ta_core.sma(closes, 3)      # list[float]
ema_values = ta_core.ema(closes, 3)
rsi_values = ta_core.rsi(closes, 14)
```

## Namespaces

| Namespace | Functions | Description |
|-----------|-----------|-------------|
| `ta` | 64 | Technical analysis (SMA, EMA, RSI, MACD, Bollinger Bands, Ichimoku, SuperTrend, ZigZag, etc.) |
| `math` | 26 | Mathematical functions (abs, ceil, floor, sqrt, pow, trig, etc.) |
| `array` | 42+ | Array manipulation (push, pop, sort, slice, binary_search, percentile, etc.) |
| `color` | 14 + 17 constants | Color creation and manipulation (rgb, from_hex, new_color, named constants) |
| `str` | 20+ | String functions (split, replace, substring, contains, match, etc.) |
| `time` | 2 | Time utilities (format_time) |
| `matrix` | 43 | Matrix operations (add, mult, det, inv, eigenvalues, eigenvectors, etc.) |
| `line` | 10 | Line drawing objects |
| `box` | 12 | Box drawing objects |
| `label` | 10 | Label drawing objects |
| `linefill` | 4 | Linefill functions |
| `chart_point` | 3 | Chart point functions |
| `polyline` | 5 | Polyline functions |

## Series

The `Series` class provides lazy evaluation with Python operator overloading:

```python
b = BuiltIns(bars)

# Arithmetic: +, -, *, /, %
spread = b.close - b.open

# Comparison: >, >=, <, <=, eq(), neq()
bullish = b.close > b.open

# Logical: and_(), or_(), not_()
signal = bullish.and_(b.close > sma)

# History access
prev_close = b.close[1]

# Conditional (ternary)
result = bullish.iff(1, -1)
```

## Tests

```bash
uv run pytest
# 1,224 passed, 56 skipped
```

## License

MIT
