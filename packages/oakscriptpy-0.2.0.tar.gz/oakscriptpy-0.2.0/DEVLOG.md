# DEVLOG

## 2026-02-26 - Port oakscriptJS to oakscriptPy

### Goal
Port the complete oakscriptJS TypeScript library (PineScript-like API) to Python, covering all 217+ functions across 13 namespaces.

### Approach Taken
7-phase implementation following dependency order:
1. Foundation types & utils
2. Core computation (ta, math, array, color, str, time, matrix)
3. Drawing objects (line, box, label, linefill, chartpoint, polyline)
4. Series + TA-Series (lazy evaluation, operator overloading)
5. Runtime system (context, plot, hline, inputs, adapters)
6. Infrastructure (indicator factory, input helpers, plot helpers, zigzag library)
7. Package integration (__init__.py, re-exports, verification)

### What Worked
- Parallel background agents for ta.py (1795 lines) and matrix.py (1136 lines) while writing smaller modules directly
- Python operator overloading for Series (`__add__`, `__radd__`, `__gt__`, etc.) maps naturally to the JS `.add()`, `.sub()`, `.gt()` methods
- `typing.Protocol` for adapter interfaces mirrors TS interfaces cleanly
- Trailing underscore naming (`math_.py`, `str_.py`, `time_.py`) avoids stdlib clashes, re-exported as `math`, `str`, `time` in `__init__.py`
- `range_`, `max_`, `min_` in ta.py avoid Python builtin clashes

### Current State
- **Done**: All 7 phases complete, 6224 lines across 28 Python files
- **Verified**: Package imports, SMA/EMA calculations, Series operators, matrix operations, line interpolation, string functions, chart points, time functions, is_na/nz
- **Not yet done**: Series dual-mode support in math_.py (scalar functions work, Series support deferred)

### Key Decisions
- `PineArray` = plain `list[T]` (no wrapper class)
- `PineMatrix` = `@dataclass` with `rows`, `columns`, `data: list[list[Any]]`
- NaN = `float('nan')`, NA = `None`, `is_na()` checks both
- Series logical ops as methods (`and_()`, `or_()`, `not_()`) since Python reserves keywords
- No external dependencies (pure Python)
- Python 3.11+ required (union type syntax)

## 2026-02-26 - Port Jest tests to pytest (math, color, str, new_functions)

### Goal
Port all Jest test files from oakscriptJS to Python pytest equivalents for math, color, str namespaces and new_functions.

### Approach Taken
1-to-1 file mapping from JS test files to Python test files. Adapted for Python-specific behavior differences (ValueError vs NaN for math domain errors, float formatting, Python slicing semantics, Unicode code points vs UTF-16 surrogate pairs).

### What Worked
- Direct porting of all scalar math, trig, utility, color, and string tests
- Series-based math tests marked with `pytest.mark.skip` (56 tests)
- Adapted JS-specific edge cases to Python equivalents (e.g., `math.sqrt(-1)` raises ValueError in Python vs returning NaN in JS)

### Files Created
- `tests/math/test_basic.py` (abs, ceil, floor, round, max, min, avg, sum)
- `tests/math/test_algebraic.py` (sqrt, pow, exp, log, log10)
- `tests/math/test_trigonometric.py` (sin, cos, tan, asin, acos, atan)
- `tests/math/test_utility.py` (toradians, todegrees, random, sign)
- `tests/math/test_series_support.py` (skipped - Series not implemented)
- `tests/math/test_sum_series.py` (skipped - Series not implemented)
- `tests/color/test_creation.py` (rgb, from_hex)
- `tests/color/test_components.py` (r, g, b, t)
- `tests/color/test_constants.py` (all named color constants)
- `tests/color/test_manipulation.py` (new_color)
- `tests/str/test_conversion.py` (length, tostring, tonumber)
- `tests/str/test_formatting.py` (split, concat, format)
- `tests/str/test_manipulation.py` (substring, upper, lower)
- `tests/str/test_predicates.py` (startswith, endswith, char_at)
- `tests/str/test_search.py` (contains, pos, replace)
- `tests/str/test_whitespace.py` (trim, trim_left, trim_right, match)
- `tests/test_new_functions.py` (color.new alias, replace_all, format_time)
- `__init__.py` in tests/, tests/math/, tests/color/, tests/str/

### Current State
- **339 passed, 56 skipped** (all skipped are Series-based math tests)
- No failures

### Key Decisions
- Python `math.sqrt(-1)` / `math.log(0)` raise ValueError (tests use `pytest.raises`), unlike JS which returns NaN/-Infinity
- Python `round(0.005, 2)` = 0.0 due to IEEE 754 float representation (adapted test expectation)
- Python `color.rgb(r,g,b,100)` produces `"rgba(..., 0.0)"` not `"rgba(..., 0)"` (float formatting)
- Python `str.split('', '')` raises ValueError (tested as such instead of returning `[]`)
- Python `substring` uses direct slicing (negative indices and begin>end behave differently from JS)
- Python counts Unicode code points, not UTF-16 units (emoji = 1 char, not 2)

## 2026-02-28 - PineScript DSL ergonomics (#10, #11, #12, #16)

### Goal
Make the Python API feel closer to PineScript's DSL by reducing boilerplate and adding familiar patterns.

### Approach Taken
Reviewed PineScript v5/v6 DSL characteristics against the current API. Identified achievable ergonomic wins vs inherent Python limitations. Implemented four features:

1. `Series.__getitem__` — `close[1]` instead of `close.offset(1)`
2. `BuiltIns` class — pre-built OHLCV Series from bar data
3. `na` first-class concept — enhanced `na` constant, Series-aware `nz()` and `fixnan()`
4. Decorator-style `@indicator()` — minimal working program pattern

### What Worked
- `__getitem__` was trivial (delegates to `offset()`, returns self for `[0]`)
- `BuiltIns` as a simple class with pre-built Series avoids proxy/magic complexity
- `na.__float__()` lets it participate in arithmetic as NaN
- `indicator()` overload detects `str` vs `IndicatorMetadataConfig` for backward-compatible dual API

### What Failed
- Cannot override `and`/`or`/`not` or `==`/`!=` on Series — Python language limitation. Documented as known gaps (#13, #14)

### Current State
- **Done**: All 4 features shipped, 1224 tests passing
- **Remaining open issues**: #13 (logical operators, wontfix), #14 (equality operators, wontfix), #15 (missing namespaces, future)

### Key Decisions
- `BuiltIns` is an explicit object (not module-level proxies) — no thread-local state, no import magic
- `close[n]` only accepts non-negative integers, raises `ValueError` otherwise
- `@indicator("title")` returns `Script` with `.calculate(bars)`, legacy API unchanged
- `nz()`/`fixnan()` on Series create new lazy Series (no eager computation)
