from .fakeinternet import FakeInternetTestCase
from .fakeinternetcontents import *
from .fakeresponse import TestResponseObject, FakeInternetData, FlaskRequest
from .mocks import *
