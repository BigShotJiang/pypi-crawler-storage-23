# Dependency Confusion Protection
This package is registered by a security researcher to prevent malicious hijacking of an internal dependency name.