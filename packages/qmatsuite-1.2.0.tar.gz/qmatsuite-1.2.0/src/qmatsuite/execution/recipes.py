"""
Engine Recipes: Materialization strategies for different engine types.

This module implements the three recipe patterns:
1. QE-Recipe: Directory-state, one job per step
2. ORCA-Recipe: QC strong-chain, one job per subchain
3. PySCF-Recipe: QC weak-chain/session, one job per subchain

Per engine_recipes_jobgraph_plan.md (Constitution):
- Recipes materialize JobGraphs from calculation steps
- JobGraph is runtime-only (NOT persisted)
- Working directories and scratch dirs follow engine filesystem contracts
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import TYPE_CHECKING, Dict, List, Optional, Protocol, runtime_checkable

from qmatsuite.execution.job_graph import Job, JobGraph, compute_job_fingerprint
from qmatsuite.workflow.public import get_registry, generate_subchain_basename, get_chain_namespace_folder
from qmatsuite.engine.public import SCF_ROOT_TYPES, RELAX_STEP_TYPES
from qmatsuite.core.public import DriverRegistry

if TYPE_CHECKING:
    from qmatsuite.calculation.public import Step


class TopologyError(Exception):
    """Raised when step topology violates QC chain rules."""
    pass


def verify_qc_topology(steps: List["Step"], registry) -> None:
    """
    Verify QC topology before execution.
    
    Rules:
    - Relax steps are standalone (length=1 chains)
    - Non-relax, non-SCF steps must trace to SCF root without crossing relax
    
    Args:
        steps: List of Step objects to verify
        registry: StepTypeRegistry instance
        
    Raises:
        TopologyError: If topology is invalid
    """
    for i, step in enumerate(steps):
        # Get step type - prefer step_type_gen, fallback to step_type_spec
        step_type_gen = getattr(step, 'step_type_gen', None)
        if not step_type_gen:
            # If no step_type_gen, try to extract from step_type_spec
            step_type_spec = getattr(step, 'step_type_spec', None)
            if step_type_spec:
                # Convert SPEC to GEN for registry lookup
                from qmatsuite.workflow.public import gen_from
                step_type_gen = gen_from(step_type_spec)
            else:
                continue  # No step type info, skip

        # Look up in registry using GEN type (registry.get() expects GEN)
        spec = registry.get(step_type_gen)
        if spec:
            # Use registry's step_type_gen (canonical)
            step_gen_type = spec.step_type_gen
        else:
            # Fallback: use extracted gen type
            step_gen_type = step_type_gen

        if step_gen_type in RELAX_STEP_TYPES:
            continue  # Relax is standalone, always valid

        if step_gen_type in SCF_ROOT_TYPES:
            continue  # SCF root starts new chain, always valid

        # Non-relax, non-SCF: must find SCF ancestor without intervening relax
        found_scf = False
        for j in range(i - 1, -1, -1):
            ancestor_step = steps[j]
            # Get ancestor GEN type
            ancestor_gen = getattr(ancestor_step, 'step_type_gen', None)
            if not ancestor_gen:
                ancestor_spec = getattr(ancestor_step, 'step_type_spec', None)
                if ancestor_spec:
                    from qmatsuite.workflow.public import gen_from
                    ancestor_gen = gen_from(ancestor_spec)
                else:
                    continue

            ancestor_spec_obj = registry.get(ancestor_gen)
            if ancestor_spec_obj:
                ancestor_gen_type = ancestor_spec_obj.step_type_gen
            else:
                ancestor_gen_type = ancestor_gen

            if ancestor_gen_type in RELAX_STEP_TYPES:
                step_name = getattr(step, 'name', f'step_{i}') or f'step_{i}'
                raise TopologyError(
                    f"TOPOLOGY_ERROR: Step '{step_name}' (index {i}) cannot trace to SCF root. "
                    f"A relax step at index {j} blocks the dependency chain. "
                    "Relax steps are not electronic state providers; they must be in standalone chains."
                )
            if ancestor_gen_type in SCF_ROOT_TYPES:
                found_scf = True
                break
        
        if not found_scf:
            step_name = getattr(step, 'name', f'step_{i}') or f'step_{i}'
            raise TopologyError(
                f"TOPOLOGY_ERROR: Step '{step_name}' (index {i}) requires SCF root but none found. "
                "Add an SCF step before this step."
            )


@runtime_checkable
class Recipe(Protocol):
    """
    Protocol for engine recipes.

    A recipe knows how to materialize a JobGraph from calculation steps.
    """

    def materialize(
        self,
        steps: List["Step"],
        calc_raw_dir: Path,
        step_shas: Optional[Dict[str, str]] = None,
    ) -> JobGraph:
        """
        Materialize a JobGraph from calculation steps.

        Args:
            steps: List of Step objects to materialize
            calc_raw_dir: Path to calculation raw directory (calc/raw/)
            step_shas: Optional dict of step_ulid -> SHA256 for fingerprinting

        Returns:
            JobGraph with jobs ready for execution
        """
        ...


class BaseRecipe(ABC):
    """Base class for recipe implementations."""

    @abstractmethod
    def materialize(
        self,
        steps: List["Step"],
        calc_raw_dir: Path,
        step_shas: Optional[Dict[str, str]] = None,
    ) -> JobGraph:
        """Materialize a JobGraph from calculation steps."""
        pass

    def _get_step_sha(
        self, step: "Step", step_shas: Optional[Dict[str, str]]
    ) -> Optional[str]:
        """Get SHA for a step from the provided map."""
        if step_shas is None:
            return None
        return step_shas.get(step.meta.ulid)


def get_recipe_for_engine(engine_family: str) -> BaseRecipe:
    """
    Get the appropriate recipe for an engine family via registry.

    Args:
        engine_family: Engine family name ("qe", "orca", "pyscf")

    Returns:
        Recipe instance for the engine family

    Raises:
        UnknownEngineError: If engine family is unknown
    """
    # Ensure drivers are loaded
    import qmatsuite.drivers

    recipe_class = DriverRegistry.get_recipe_class(engine_family)
    return recipe_class()


# Backward-compatibility re-exports for migrated recipe classes
# These recipes were moved to driver bundles but are re-exported here
# to maintain compatibility with existing test code and handlers.
# The DriverRegistry is the primary mechanism; these are compat shims.
# Import at module level to ensure isinstance() checks work correctly
_RECIPE_EXPORTS = {
    "QERecipe": "qmatsuite.drivers.qe.recipe",
    "ORCARecipe": "qmatsuite.drivers.orca.recipe",
    "VASPRecipe": "qmatsuite.drivers.vasp.recipe",
    "PySCFRecipe": "qmatsuite.drivers.pyscf.recipe",
    "CP2KRecipe": "qmatsuite.drivers.cp2k.recipe",
    "LAMMPSRecipe": "qmatsuite.drivers.lammps.recipe",
    "W90Recipe": "qmatsuite.drivers.w90.recipe",
}


def __getattr__(name: str):
    """Lazy-load recipe re-exports to avoid import cycles."""
    if name in _RECIPE_EXPORTS:
        import importlib

        module = importlib.import_module(_RECIPE_EXPORTS[name])
        value = getattr(module, name)
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "BaseRecipe",
    "get_recipe_for_engine",
    "QERecipe",
    "ORCARecipe",
    "VASPRecipe",
    "PySCFRecipe",
    "CP2KRecipe",
    "LAMMPSRecipe",
    "W90Recipe",
]
