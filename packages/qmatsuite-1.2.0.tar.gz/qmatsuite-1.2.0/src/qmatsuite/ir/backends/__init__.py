"""
IR backend adapters.

Each engine has its own adapter that converts IR parameters ↔ engine-specific parameters.
"""

