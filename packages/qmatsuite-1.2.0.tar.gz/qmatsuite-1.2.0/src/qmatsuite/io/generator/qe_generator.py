"""Backward-compatibility re-export for QE generator (moved to drivers/qe/io/)."""

from qmatsuite.drivers.qe.io.generator import QEInputGenerator

__all__ = ["QEInputGenerator"]

