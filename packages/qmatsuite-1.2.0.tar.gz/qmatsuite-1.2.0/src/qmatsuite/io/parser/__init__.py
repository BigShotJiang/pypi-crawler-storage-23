"""Backward-compatibility re-export for QE parser (moved to drivers/qe/io/)."""

# Empty __init__.py - qe_parser.py is re-exported below
