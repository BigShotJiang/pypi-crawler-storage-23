"""Backward-compatibility re-export for QE parser (moved to drivers/qe/io/)."""

from qmatsuite.drivers.qe.io.parser import QEInputParser

__all__ = ["QEInputParser"]

