"""
Re-export the new PseudoManager implementation.
"""

from qmatsuite.core.engines.qe_pseudopotentials import PseudoManager

__all__ = ["PseudoManager"]

