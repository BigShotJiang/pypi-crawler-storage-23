"""Gaussian engine metadata and data files."""
