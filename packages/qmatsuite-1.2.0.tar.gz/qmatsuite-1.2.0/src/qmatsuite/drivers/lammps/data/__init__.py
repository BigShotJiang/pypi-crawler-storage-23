"""LAMMPS parameter metadata catalog."""
