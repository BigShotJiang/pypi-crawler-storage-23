"""LAMMPS engine utilities: resource staging and optional dev-only runner."""
