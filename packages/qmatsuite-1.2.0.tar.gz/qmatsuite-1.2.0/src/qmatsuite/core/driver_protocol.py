"""Engine driver protocol and base class.

This module defines the interface that all engine drivers must implement,
plus a base class providing sensible defaults for optional methods.
"""

from abc import abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Protocol, runtime_checkable

if TYPE_CHECKING:
    from qmatsuite.execution.job_graph import Job
    from qmatsuite.execution.executor import JobResult
    from qmatsuite.inputformat.core import EngineInputSpec


class WorkdirPolicy(Enum):
    """Workdir management policy for engine handlers."""

    ISOLATED = "isolated"   # Per-step workdir, no cleanup (default)
    CLEANUP = "cleanup"     # rm -rf before each step (VASP)
    SHARED = "shared"       # Shared outdir with prefixes (QE)


class ErrorClass(Enum):
    """Classification of execution errors for reporting."""

    UNKNOWN = "unknown"
    CONVERGENCE = "convergence"
    MEMORY = "memory"
    TIMEOUT = "timeout"
    INPUT_ERROR = "input_error"
    MISSING_FILE = "missing_file"
    LICENSE = "license"
    EXECUTABLE_NOT_FOUND = "executable_not_found"


@dataclass(frozen=True)
class StepTypeSpec:
    """Specification for a step type.

    This dataclass defines all properties of a step type that the kernel
    needs to know for routing and execution.
    """

    step_type_spec: str              # Unique step type identifier (e.g., "vasp_scf")
    engine: str                      # Engine family (e.g., "vasp")
    executable: str                  # Default executable name (e.g., "vasp_std")
    description: str = ""            # Human-readable description
    category: str = "calculation"    # Category: calculation, postprocess, utility
    supports_restart: bool = True    # Whether step supports restart from checkpoint
    mpi_aware: bool = True           # Whether step can use MPI

    def __post_init__(self):
        if not self.step_type_spec:
            raise ValueError("StepTypeSpec.step_type_spec cannot be empty")
        if not self.engine:
            raise ValueError("StepTypeSpec.engine cannot be empty")
        if not self.step_type_spec.startswith(f"{self.engine}_") and self.step_type_spec not in self._allowed_special_ids():
            raise ValueError(
                f"StepTypeSpec.step_type_spec '{self.step_type_spec}' must start with engine prefix '{self.engine}_'"
            )

    def _allowed_special_ids(self) -> set[str]:
        """Step type specs that don't follow the prefix convention."""
        return {"w90_wannierprep", "w90_wannier"}  # Wannier90 legacy names


@dataclass
class PreflightRequirement:
    """A requirement that must be satisfied before step execution."""

    artifact_type: str              # e.g., "CHGCAR", "WAVECAR"
    source_step: str | None = None  # Step that produces it (None = auto-resolve)
    required: bool = True           # False = optional optimization
    description: str = ""           # Human-readable description


@dataclass(frozen=True)
class PreflightIssue:
    """A validation issue found during preflight parameter checking.

    Immutable value object returned by engine-specific preflight checkers.
    """

    code: str               # Machine-readable code, e.g. "MISSING_ECUTWFC"
    severity: str            # "blocking" | "warning" | "advisory"
    message: str             # Human-readable explanation
    step: int | None = None  # Step index where the issue was found
    parameter: str | None = None   # Parameter name that triggered the issue
    suggestion: str | None = None  # Suggested fix
    knowledge_ref: str | None = None  # Reference to docs/knowledge base


# StepContext is a placeholder type - actual implementation may vary
# For now, we use a dict[str, Any] to match existing handler signatures
StepContext = dict[str, Any]


@runtime_checkable
class EngineDriver(Protocol):
    """Protocol defining the required interface for engine drivers.

    All engine drivers MUST implement these methods/properties.
    This is a Protocol, so drivers don't need to inherit from it,
    but they must structurally conform to this interface.
    """

    # ─────────────────────────────────────────────────────────────────────
    # MUST: Properties (3 required)
    # ─────────────────────────────────────────────────────────────────────

    @property
    def engine_family(self) -> str:
        """Unique engine identifier (e.g., 'vasp', 'orca').

        This is the canonical name used throughout the system.
        Must be lowercase, alphanumeric with underscores only.
        """
        ...

    @property
    def display_name(self) -> str:
        """Human-readable name for UI/logs (e.g., 'VASP', 'ORCA')."""
        ...

    @property
    def driver_api_version(self) -> str:
        """Semver string (e.g., '1.0.0').

        Kernel validates major version compatibility at registration.
        Current kernel requires major version 1.
        """
        ...

    # ─────────────────────────────────────────────────────────────────────
    # MUST: Methods (4 required)
    # ─────────────────────────────────────────────────────────────────────

    def get_step_type_specs(self) -> list[StepTypeSpec]:
        """Return all step types this driver handles.

        Each StepTypeSpec must have engine matching self.engine_family.
        """
        ...

    def get_handler(self) -> Callable[["Job", StepContext], "JobResult"]:
        """Return the step handler function.

        The handler is called for each step execution.
        Note: Actual handler signatures may vary; this is the protocol contract.
        """
        ...

    def get_recipe_class(self) -> type:
        """Return the recipe class for input staging.

        Recipe class must inherit from BaseRecipe.
        """
        ...

    def get_materialization_map(self) -> dict[str, str]:
        """Return gen→spec mapping for generalized steps.

        Keys are gen step names (e.g., 'scf').
        Values are engine-specific types (e.g., 'vasp_scf').
        Return empty dict if engine doesn't support generalized steps.
        
        Note: This method MUST return purely derived mappings:
        {gen: f"{PREFIX}_{gen}"} for gen in SUPPORTED_GEN_STEPS.
        """
        ...


class BaseEngineDriver:
    """Base class providing sensible defaults for optional driver methods.

    Drivers can inherit from this class to get default implementations
    of SHOULD and PLUGIN methods. Only MUST methods need to be overridden.

    This is an optional convenience - drivers can implement EngineDriver
    protocol directly without inheriting from this class.
    """

    # ─────────────────────────────────────────────────────────────────────
    # Engine classification (per GUI_ENGINE_FAMILY_DEMO_SPEC.md v1.1)
    # ─────────────────────────────────────────────────────────────────────

    ENGINE_ROLE: str = "base"
    COMPANION_ENGINES: frozenset = frozenset()
    ANALYSIS_CAPABILITIES: list = []  # Override in engine drivers

    # ─────────────────────────────────────────────────────────────────────
    # SHOULD: Methods with sensible defaults
    # ─────────────────────────────────────────────────────────────────────

    def get_workdir_policy(self) -> WorkdirPolicy:
        """Default: isolated per-step workdir, no cleanup."""
        return WorkdirPolicy.ISOLATED

    def get_capabilities(self) -> set[str]:
        """Default: no capabilities declared.

        Override to declare engine capabilities like:
        - Calculation types: 'scf', 'relax', 'md', 'bands', 'dos'
        - Structure types: 'periodic', 'molecular', 'surface'
        - Parallelism: 'mpi', 'openmp', 'gpu'
        """
        return set()

    def supports_incremental_skip(self, step_type_spec: str) -> bool:
        """Default: all steps can be skipped if already done.

        Override to return False for steps that should always run
        (e.g., MD steps where continuation matters).
        """
        return True

    def get_preflight_requirements(self, step: Any) -> list[PreflightRequirement]:
        """Default: no preflight checks.

        Override to declare requirements like CHGCAR/WAVECAR for VASP.
        """
        return []

    def get_materialization_map(self) -> dict[str, str]:
        """Default: Build materialization map from PREFIX + SUPPORTED_GEN_STEPS.
        
        Delegates to DriverRegistry which builds the map from driver attributes.
        This method is kept for backward compatibility with code that calls it directly.
        Drivers should not override this - use PREFIX + SUPPORTED_GEN_STEPS instead.
        """
        from qmatsuite.core.driver_registry import DriverRegistry
        registry = DriverRegistry.get_instance()
        # Get from registry's stored map (built during registration)
        family = self.engine_family
        return registry._materialization_maps.get(family, {})

    def classify_error(self, stderr: str, exit_code: int) -> ErrorClass:
        """Default: unknown error class.

        Override to parse stderr and classify errors for better reporting.
        """
        return ErrorClass.UNKNOWN

    # ─────────────────────────────────────────────────────────────────────
    # PLUGIN: Optional extension points
    # ─────────────────────────────────────────────────────────────────────

    def get_input_spec(self, **context: Any) -> "EngineInputSpec | None":
        """Return input format specification for this engine.

        Override to declare the engine's input files, resource refs, and
        SSOT mapping.  Returns None if not yet implemented (Phase A default).

        Args:
            **context: Engine-specific context for resolving dynamic
                filenames (e.g., gen_type for QE, system_label for Siesta).

        Returns:
            EngineInputSpec or None.
        """
        return None

    def get_preflight_checker(self) -> Any:
        """Return a preflight parameter checker for this engine.

        Override to provide engine-specific parameter validation.
        The returned checker must implement a ``check()`` method:

            checker.check(step_params, structure_info, workflow_context)
              -> list[PreflightIssue]

        Returns None if the engine has no preflight checker.
        """
        return None

    def get_artifact_patterns(self) -> dict[str, str]:
        """Default: no artifact patterns.

        Override to declare output artifact patterns like:
        {'CHGCAR': 'CHGCAR*', 'WAVECAR': 'WAVECAR'}
        """
        return {}

    def find_latest_artifact(self, workdir: Path, artifact_type: str) -> Path | None:
        """Default: no artifact discovery.

        Override to implement artifact resolution logic.
        """
        return None

    def resolve_executable(self, step_type_spec: str) -> Path | None:
        """Default: use PATH lookup.

        Override to implement custom executable resolution.
        """
        return None
