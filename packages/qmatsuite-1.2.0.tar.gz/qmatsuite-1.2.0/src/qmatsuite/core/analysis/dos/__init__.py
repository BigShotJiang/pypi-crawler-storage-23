"""DOS analysis model."""
from qmatsuite.core.analysis.dos.model import DOS

__all__ = ["DOS"]

