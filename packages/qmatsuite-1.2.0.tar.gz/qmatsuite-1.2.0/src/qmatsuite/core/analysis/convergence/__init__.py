"""Convergence analysis model."""
from qmatsuite.core.analysis.convergence.model import Convergence

__all__ = ["Convergence"]
