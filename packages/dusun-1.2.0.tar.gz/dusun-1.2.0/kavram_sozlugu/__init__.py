"""
kavram_sozlugu — Ontology Lens (Lens #1 of 7).

Concept ontology / Name mapping instrument for the multi-lens
analytical apparatus defined in AGENTS.md §4.1.

  Lens: Ontoloji | Faculty: Akil | Domain: Concept ontology / Name mapping

Public API:
  Types:      Sifat, Isim, Tecelli, Kavram
  Registry:   KavramSozlugu
  Functions:  tecelli_degree, istinad, delalet, mana_harfi, mana_ismi
  Data:       SIFAT_SEBA, ESMA_UL_HUSNA
  Constraints: kv1_classified, kv8_grounded, name_density,
               valid_tecelli_degrees, convergence_bound,
               names_in_registry, valid_ontology_entry
"""

from kavram_sozlugu.types import Sifat, Isim, Tecelli, Kavram
from kavram_sozlugu.registry import (
    KavramSozlugu,
    tecelli_degree,
    istinad,
    delalet,
    mana_harfi,
    mana_ismi,
)
from kavram_sozlugu.data import SIFAT_SEBA, ESMA_UL_HUSNA, VALID_SIFAT_NAMES
from kavram_sozlugu.constraints import (
    kv1_classified,
    kv8_grounded,
    name_density,
    valid_tecelli_degrees,
    convergence_bound,
    names_in_registry,
    valid_ontology_entry,
)

__all__ = [
    # Types
    "Sifat", "Isim", "Tecelli", "Kavram",
    # Registry
    "KavramSozlugu",
    # Predicate functions
    "tecelli_degree", "istinad", "delalet", "mana_harfi", "mana_ismi",
    # Data
    "SIFAT_SEBA", "ESMA_UL_HUSNA", "VALID_SIFAT_NAMES",
    # Constraints
    "kv1_classified", "kv8_grounded", "name_density",
    "valid_tecelli_degrees", "convergence_bound",
    "names_in_registry", "valid_ontology_entry",
]
