# Bundled framework files for `fw-engine --init` deployment.
# These files are copied to the user's workspace to enable /fw slash commands
# and the full AGENTS.md reasoning pipeline.
