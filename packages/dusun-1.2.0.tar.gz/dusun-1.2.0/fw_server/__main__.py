"""Allow running with: python -m fw_server"""
from fw_server.server import main

main()
