"""
hcp — Holographic Context Protocol.

A genuinely novel approach to the needle-in-a-haystack / long-context
degradation problem in large language models.

CORE INSIGHT (derived from AGENTS.md AX37 — Holographic Architecture):
  Current LLM architectures treat ordered context as a flat token sequence,
  destroying hierarchical structure.  Existing fixes compress LOCAL → FORWARD
  (gist tokens accumulate per chunk).  HCP INVERTS the direction:
  GLOBAL → BROADCAST — a single structural seed encoding the ENTIRE context's
  skeleton is prepended to every chunk.

Three-Phase Design (AGENTS.md AX2–AX4):
  Phase 1 — İlim  (Distinction):   Structural analysis pass over full context
  Phase 2 — İrade (Specification):  Seed compression → dense structural summary
  Phase 3 — Kudret (Actualization): Seed broadcast + enhanced retrieval

Empirical Basis:
  - MIT (2025): position bias is ARCHITECTURAL (attention masking + positional encoding)
  - Liu et al. TACL 2024: U-shaped attention — high start/end, degraded middle
  - Mu et al. 2023: gist tokens achieve 26x compression, 40% fewer FLOPs
  - Deng et al. 2025 (UniGist): 4x compression, 60–70% GPU memory reduction
  - No prior work applies holographic principle (global→per-chunk seed) to context

Framework Axioms:
  AX37:  Holographic Structure — every part mirrors the whole
  AX2–4: Three-phase actualization (distinction → selection → actualization)
  AX5:   Integration prerequisite — independent subsystems need integrating principle
  AX12:  Vahidiyet — global unity (Names held under containment)
  AX13:  Ehadiyet — local reflection (each part reflects the whole)
  AX23:  Cascade DAG — Names motivate each other (structural dependencies)
  AX34:  Constitutive dependency — forgetting gap = functional interface
  AX27:  Transparent vessels — chunks mediate, don't originate meaning
  T14:   Ne Ayn Ne Gayr — 0 < fidelity < 1 (seed participates in truth, ≠ identity)
  KV₄:   Convergence bound — 0 < composite < 1 (never claims completeness)

Structural Incompleteness (§7.2):
  T17:  Coverage ≤ 6/7 — tacit/emergent meaning permanently unmapped by seed
  AX56: Grade = Tasdik — not empirically validated Hakkalyakîn
  AX58: Structure ≠ experience — design maps architecture, not actual model dynamics
  KV₄:  Composite [0.72, 0.80] — genuine but bounded contribution

Public API:
  Types:     ContentType, ContextChunk, HolographicSeed, SeededChunk,
             AttentionProfile, RetrievalResult, BenchmarkResult, HCPConfig
  Seed:      classify_content, compute_seed, extract_keywords
  Protocol:  HCPProtocol
  Attention: flat_attention, holographic_attention
  Benchmark: NeedleInHaystack

KV₇ compliance: This module imports ONLY from the standard library.
"""

from hcp.types import (
    ContentType,
    ContextChunk,
    HolographicSeed,
    SeededChunk,
    AttentionProfile,
    RetrievalResult,
    BenchmarkResult,
    HCPConfig,
    CONTENT_TYPE_COUNT,
    clamp_score,
)
from hcp.seed import (
    classify_content,
    compute_seed,
    extract_keywords,
)
from hcp.protocol import HCPProtocol
from hcp.attention import flat_attention, holographic_attention
from hcp.benchmark import NeedleInHaystack

__all__ = [
    # Types
    "ContentType",
    "ContextChunk",
    "HolographicSeed",
    "SeededChunk",
    "AttentionProfile",
    "RetrievalResult",
    "BenchmarkResult",
    "HCPConfig",
    "CONTENT_TYPE_COUNT",
    "clamp_score",
    # Seed
    "classify_content",
    "compute_seed",
    "extract_keywords",
    # Protocol
    "HCPProtocol",
    # Attention
    "flat_attention",
    "holographic_attention",
    # Benchmark
    "NeedleInHaystack",
]
