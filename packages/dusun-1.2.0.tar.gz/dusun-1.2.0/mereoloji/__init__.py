"""
mereoloji — Mereology Lens (Lens #2 of 7).

Part-whole and teleological structure instrument for the multi-lens
analytical apparatus defined in AGENTS.md §4.1.

  Lens: Mereoloji | Faculty: — | Domain: Part-whole // teleological structure

Public API:
  Types:       Telos, Part, Whole, PartOfEdge
  Structure:   MereologicalStructure
  Functions:   is_proper_part, telos_hierarchy
  Axioms:      check_m1..m5, check_t1..t5, check_all_cem, check_all_teleological
  Constraints: cem_valid, holographic_omnipresence, telos_complete,
               integration_present, dual_order, convergence_bound,
               valid_mereological_entry
"""

from mereoloji.types import Telos, Part, Whole, PartOfEdge
from mereoloji.relations import (
    MereologicalStructure,
    is_proper_part,
    telos_hierarchy,
)
from mereoloji.axioms import (
    check_m1_irreflexivity,
    check_m2_asymmetry,
    check_m3_transitivity,
    check_m4_supplementation,
    check_m5_fusion,
    check_t1_telos_present,
    check_t2_telos_propagation,
    check_t3_telos_ordering,
    check_t4_no_purposeless,
    check_t5_irreducible_telos,
    check_all_cem,
    check_all_teleological,
)
from mereoloji.constraints import (
    cem_valid,
    holographic_omnipresence,
    telos_complete,
    integration_present,
    dual_order,
    convergence_bound,
    valid_mereological_entry,
)

__all__ = [
    # Types
    "Telos", "Part", "Whole", "PartOfEdge",
    # Structure
    "MereologicalStructure",
    # Functions
    "is_proper_part", "telos_hierarchy",
    # Axiom checks
    "check_m1_irreflexivity", "check_m2_asymmetry",
    "check_m3_transitivity", "check_m4_supplementation",
    "check_m5_fusion",
    "check_t1_telos_present", "check_t2_telos_propagation",
    "check_t3_telos_ordering", "check_t4_no_purposeless",
    "check_t5_irreducible_telos",
    "check_all_cem", "check_all_teleological",
    # Constraints
    "cem_valid", "holographic_omnipresence", "telos_complete",
    "integration_present", "dual_order", "convergence_bound",
    "valid_mereological_entry",
]
