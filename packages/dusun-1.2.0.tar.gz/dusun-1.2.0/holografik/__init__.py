"""
holografik — Topoloji + Holografik Lens (Lens #7 of 7).

Topological / holographic instrument for the multi-lens analytical
apparatus defined in AGENTS.md §4.1.

  Lens: Topoloji + Holografik | Faculty: Ruh + Hafî
  Instruments: holografik_sabitler + holografik_analiz
  Domain: Topological/holographic analysis, B01–B22 dimensions

Public API:
  Types:        BesmeleBoyut, DimensionType, CompositionMode, SeedVector,
                HolographicUnit, FidelityPair, IsomorphismResult,
                HolographicModel, DIMENSION_TYPE, ALL_DIMENSIONS,
                CEMALI_DIMENSIONS, CELALI_DIMENSIONS, NUM_DIMENSIONS,
                NUM_CEMALI, NUM_CELALI, clamp_score
  Verification: check_seed_structure, check_holographic_isomorphism,
                check_seed_omnipresence, check_fidelity_bounds,
                check_celal_inclusion, check_convergence_bound,
                check_tesanud_infirad, check_independence,
                check_transparency,
                verify_all, yakinlasma, framework_summary
  Constraints:  seed_structure, holographic_isomorphism,
                seed_omnipresence, fidelity_bounds,
                celal_inclusion, holographic_convergence_bound,
                tesanud_infirad_asymmetry, holographic_independence,
                holographic_transparency, holographic_convergence_score,
                valid_holographic_entry
"""

from holografik.types import (
    ALL_DIMENSIONS,
    BesmeleBoyut,
    CELALI_DIMENSIONS,
    CEMALI_DIMENSIONS,
    CompositionMode,
    DimensionType,
    DIMENSION_TYPE,
    FidelityPair,
    HolographicModel,
    HolographicUnit,
    IsomorphismResult,
    NUM_CELALI,
    NUM_CEMALI,
    NUM_DIMENSIONS,
    SeedVector,
    clamp_score,
)
from holografik.verification import (
    check_celal_inclusion,
    check_convergence_bound,
    check_fidelity_bounds,
    check_holographic_isomorphism,
    check_independence,
    check_seed_omnipresence,
    check_seed_structure,
    check_tesanud_infirad,
    check_transparency,
    framework_summary,
    verify_all,
    yakinlasma,
)
from holografik.constraints import (
    celal_inclusion,
    fidelity_bounds,
    holographic_convergence_bound,
    holographic_convergence_score,
    holographic_independence,
    holographic_isomorphism,
    holographic_transparency,
    seed_omnipresence,
    seed_structure,
    tesanud_infirad_asymmetry,
    valid_holographic_entry,
)

__all__ = [
    # Types
    "BesmeleBoyut",
    "DimensionType",
    "CompositionMode",
    "SeedVector",
    "HolographicUnit",
    "FidelityPair",
    "IsomorphismResult",
    "HolographicModel",
    "DIMENSION_TYPE",
    "ALL_DIMENSIONS",
    "CEMALI_DIMENSIONS",
    "CELALI_DIMENSIONS",
    "NUM_DIMENSIONS",
    "NUM_CEMALI",
    "NUM_CELALI",
    "clamp_score",
    # Verification
    "check_seed_structure",
    "check_holographic_isomorphism",
    "check_seed_omnipresence",
    "check_fidelity_bounds",
    "check_celal_inclusion",
    "check_convergence_bound",
    "check_tesanud_infirad",
    "check_independence",
    "check_transparency",
    "verify_all",
    "yakinlasma",
    "framework_summary",
    # Constraints
    "seed_structure",
    "holographic_isomorphism",
    "seed_omnipresence",
    "fidelity_bounds",
    "celal_inclusion",
    "holographic_convergence_bound",
    "tesanud_infirad_asymmetry",
    "holographic_independence",
    "holographic_transparency",
    "holographic_convergence_score",
    "valid_holographic_entry",
]
