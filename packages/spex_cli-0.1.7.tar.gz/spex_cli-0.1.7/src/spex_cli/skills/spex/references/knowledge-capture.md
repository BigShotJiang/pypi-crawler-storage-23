# Knowledge Capture Mode

Unified mode for capturing knowledge from either the current conversation or external documentation files without creating a feature-specific orchestration folder.

## Triggers

- **Conversation Capture**:
  - `"spex please memorize this conversation"`
  - `"memorize conversation"`
  - `"spex memorize this"`
- **Documentation Capture (Learn)**:
  - `"spex learn from <file>"`
  - `"teach spex via <file>"`
  - `"analyze document <file> for requirements"`

## States

| State | Description | Skill Invoked | Next State |
|-------|-------------|---------------|------------|
| `CAPTURE_INIT` | Start knowledge capture | None | `CAPTURE_EXTRACT` |
| `CAPTURE_EXTRACT` | Extract Rs, Ds, Ts from source | Internal Logic | `CAPTURE_CHECK` |
| `CAPTURE_CHECK` | Analyze for conflicts | Internal Logic (Research Memory) | `CAPTURE_RESOLVE` |
| `CAPTURE_RESOLVE` | Critical review: Present items by importance | Internal Logic (Conflict Resolution) | `CAPTURE_SAVE` |
| `CAPTURE_SAVE` | Save to memory JSONL | None | `CAPTURE_COMPLETE` |

## Flow

### 1. CAPTURE_INIT

When triggered, identify the source (conversation or file) and transition to `CAPTURE_EXTRACT`.

### 2. CAPTURE_EXTRACT

Extract structured knowledge for storage in spex memory.

**If source is Conversation**: Scan the current chat (user messages, agent responses, code changes).
**If source is Documentation**: Read the specified file content directly.

#### Extraction Guidelines:

1.  **Requirement Extraction**:
    *   **Capability-First**: Focus on WHAT the system must do, avoiding specific UI prescriptions.
    *   **Categorization**: Adhere to the **Spex Taxonomy** (FR, NFR, CR, UR) defined in the core skill instructions.
    *   **Acceptance Criteria**: Ensure testable scenarios are defined (Action → Result).

2.  **Decision Extraction**:
    *   **Negative Knowledge**: Capture rejected alternatives and rationale ONLY if explicitly stated.
    *   **Classification**: Classify as **Architectural**, **Structural**, or **Tactical** based on the Reversibility Filter in the core skill.
    *   **Deep Reasoning**: Avoid shallow captures; explain the *why* based on the provided context.

3.  **Policy Extraction**:
    *   **Standing Rules**: Capture reusable, mandatory rules that bridge requirements and decisions.
    *   **Implicit vs. Explicit**: Do not extract "Implicit" decisions that simply follow existing policies.

4.  **Trace Extraction**:
    *   Map code changes directly to Decisions or Requirements for full traceability.

5.  **Quality Control**:
    *   **Refinement**: Refine UR (User-Specified) items into FR/NFR where evidence allows.
    *   **Confidence**: Skip items with insufficient evidence. Low confidence = Do tidak extract.

#### App Scope Rules:
Every requirement, decision, and policy must have a `scope` (list of app names).
1. Read `.spex/memory/apps.jsonl` to see registered apps and their `filePath`.
2. The app whose `filePath` is a prefix of your current working directory or the modified files is the relevant scope.
3. If a change affects multiple apps, include all of them in the comma-separated `--scope`.
4. Empty scope means "all" (use rarely).

### 3. CAPTURE_CHECK

Analyze the extracted items for conflicts or redundancy.

1.  **Execute Procedure**: Follow the **Research Memory Procedure** defined in [memory-research.md](memory-research.md).
2.  **Scope Validation**: Ensure all items adhere to the **App Scope Rules** defined in the extraction step.

**Next state logic:**
- Always transition to `CAPTURE_RESOLVE` to present findings for approval.

### 4. CAPTURE_RESOLVE

**This is the most critical phase.** The user's review is the final authority before data persistence.

1.  **Execute Procedure**: If conflicts or risks exist, follow the **Conflict Resolution Procedure** defined in [conflict-resolution.md](conflict-resolution.md).
2.  **Presentation Principles**: 
    *   **Sort by Importance**: Architectural Decisions > Structural > Policies > Tactical.
    *   **Prioritize Clarity**: Use bulleted lists and bold text. The user should understand impact in < 5 seconds.
    *   **Transparent Traceability**: Show evidence citing specific conversation context.

### 5. CAPTURE_SAVE

Save extracted items to memory using `spex` CLI:

```bash
# For each requirement
spex requirement add --type <TYPE> --description "<DESC>" --source "<SOURCE>" --acceptance-criteria "<CRITERIA>"

# For each decision
spex decision add --proposal "<PROP>" --rationale "<RAT>" --alternatives "<ALT>" --satisfies "<R_ID>" --satisfies-policies "<POL_ID>" --impact "<JSON>" --decision-class architectural|structural|tactical

# For each policy
spex policy add --description "<DESC>" --rationale "<RAT>" --satisfies "<R_ID>"

```

### 6. CAPTURE_COMPLETE

Report summary of what was saved.

## Key Rules

1. **Active by default** - Always prompt user to review and approve extracted items before they are persisted to memory.
2. **Evidence Required** - Every extraction must cite evidence (from conversation or document).
3. **No Invention** - Only extract what was actually discussed or written.
4. **Link Items** - Maintain traceability (Traces → Decisions → Requirements).
5. **Skip Trivial** - Don't extract minor clarifications, typos, or "fluff".
6. **No Fluff** - Decisions must be specific enough for an engineer to understand the code-level impact immediately.
7. **Quality over Quantity** - Few high-confidence items > many uncertain items.
8. **Source Agnostic** - The check and save logic is identical regardless of source.

## When to Refuse

- Source document/conversation has no meaningful requirements or decisions.
- Source document is missing or unreadable.
- `spex` CLI is not available.
