# Conflict Resolution Procedure

This procedure is used to handle contradictions, redundancies, or risks identified during memory research or auditing.

## Goal
Ensure the Spex memory remains a "Single Source of Truth" without stale, conflicting, or redundant entries.

## Resolution Strategies

When a conflict is detected, present it to the human with the following options:

1.  **Override**: The new direction is correct. Deprecate the existing memory item and persist the new one.
2.  **Merge**: The existing item and new item are both partially correct. Combine them into a new version, deprecate the old one, and persist the merged result.
3.  **Cancel**: The existing memory item is correct. Reject the new proposal and maintain the current state.
4.  **Refine**: The new proposal can be adjusted to avoid the conflict while still satisfying the goal.

## Detailed Procedure

### 1. Present Options
For each blocking conflict, show:
*   **The Discrepancy**: "Goal says X, but existing Decision [D-XXX] says Y."
*   **The Impact**: What happens to downstream requirements or traces if [D-XXX] is changed.
*   **Rationale for Conflict**: Why the friction exists (e.g., "Historical performance target [NFR-001] is incompatible with this new search logic").
*   **Concrete Resolution Options**: Present 2-3 specific options (e.g., "Option A: Merged Requirement draft", "Option B: Specific Deprecation plan") so the user can choose or iterate on a concrete proposal.

### 2. Execute Resolution
Once the user selects a strategy, use the `spex` CLI to update memory:
*   **Deprecate**: `spex decision deprecate --id <ID>`
*   **Update**: `spex requirement update --id <ID> ...`
*   **Add**: Use the standard `add` commands for the new or merged items.

### 3. Verify Side Effects
*   Check if the resolution broke any "Satisfies" links.
*   Warn the user if a resolved conflict leaves orphaned items (e.g., a Decision pointing to a now-deprecated Requirement).
