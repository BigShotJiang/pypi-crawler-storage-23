# Security

If you discover a security issue, please report it privately to `oss@sentient.ai`.

Do not open a public issue for vulnerabilities.

