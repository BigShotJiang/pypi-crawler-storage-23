"""icd10-am: Lightweight query interface for the ICD-10 code hierarchy."""

from ._core import (
    ICD10,
    normalize_code,
    ICD10Error,
    CodeNotFoundError,
    NoParentError,
    NotAChapterError,
    MapNotFoundError,
)

__all__ = [
    "ICD10",
    "normalize_code",
    "ICD10Error",
    "CodeNotFoundError",
    "NoParentError",
    "NotAChapterError",
    "MapNotFoundError",
]

__version__ = "0.1.0"