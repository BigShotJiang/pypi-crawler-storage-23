"""
Core sub-package for autoguess solver backends and utilities.
"""
