from __future__ import annotations
from aiel_sdk.errors import RuntimeDependencyError

try:
    from langsmith import Client  # type: ignore
except Exception as e:  # pragma: no cover
    raise RuntimeDependencyError("langsmith", "pip install 'aiel-sdk[langsmith]'") from e

__all__ = ["Client"]
