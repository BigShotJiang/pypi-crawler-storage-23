# aiel_sdk/models/integrations.py
from __future__ import annotations

from typing import Any, Dict, List, Optional
from pydantic import BaseModel, ConfigDict, Field


class IntegrationConnector(BaseModel):
    model_config = ConfigDict(extra="allow")
    id: str
    version: str


class IntegrationAuth(BaseModel):
    model_config = ConfigDict(extra="allow")
    method: str
    resource_credential_id: Optional[str] = None
    oauth_client_profile_id: Optional[str] = None


class IntegrationConnection(BaseModel):
    model_config = ConfigDict(extra="allow")

    connection_id: str
    workspace_id: str
    project_id: str
    provider: str
    connector: IntegrationConnector
    resource_type: str
    display_name: str
    status: str
    status_reason: Optional[str] = None
    capabilities: List[str] = Field(default_factory=list)
    allowed_actions: List[str] = Field(default_factory=list)
    granted_actions: List[str] = Field(default_factory=list)
    auth: IntegrationAuth
    metadata: Dict[str, Any] = Field(default_factory=dict)