from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Tuple

@dataclass(frozen=True)
class ToolExport:
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool

@dataclass(frozen=True)
class AgentExport:
    name: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool

@dataclass(frozen=True)
class FlowExport:
    name: str
    fn: Callable[..., Any] | None
    graph_builder: Callable[..., Any] | None
    module: str
    qualname: str

@dataclass(frozen=True)
class HttpHandlerExport:
    method: str
    path: str
    fn: Callable[..., Any]
    module: str
    qualname: str
    is_async: bool

@dataclass
class McpServerExport:
    name: str
    tools: List[str]

McpToolMap = Dict[Tuple[str, str], Callable[..., Any]]