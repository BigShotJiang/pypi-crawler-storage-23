from __future__ import annotations
import inspect
from typing import Any, Callable
from .errors import ContractViolation
from .registry import get_registry

def validate_contracts() -> None:
    reg = get_registry()
    for name, exp in reg.tools.items():
        _min_arity(f"tool:{name}", exp.fn, 2)
    for name, exp in reg.agents.items():
        _min_arity(f"agent:{name}", exp.fn, 2)
    for name, exp in reg.flows.items():
        if exp.fn is not None:
            _min_arity(f"flow:{name}", exp.fn, 2)

def _min_arity(label: str, fn: Callable[..., Any], n: int) -> None:
    sig = inspect.signature(fn)
    if len(sig.parameters) < n:
        raise ContractViolation(f"{label} must accept at least {n} args (ctx, payload/state). Got: {sig}")
