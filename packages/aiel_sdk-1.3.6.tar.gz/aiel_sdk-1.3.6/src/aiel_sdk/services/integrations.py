from __future__ import annotations

from typing import Any, Dict, List, Optional
from typing import TYPE_CHECKING

from pydantic import BaseModel

from ..models.integrations import IntegrationConnection
if TYPE_CHECKING:
    from ..client import AielClient


class IntegrationsService:
    def __init__(self, client: AielClient) -> None:
        self._c = client

    def list(self, workspace_id: str, project_id: str) -> List[IntegrationConnection]:
        path = f"/v1/workspaces/{workspace_id}/projects/{project_id}/integrations"
        data = self._c._request("integrations", "GET", path)
        return [IntegrationConnection.model_validate(x) for x in (data or [])]

    def get(self, workspace_id: str, project_id: str, connection_id: str) -> IntegrationConnection:
        path = f"/v1/workspaces/{workspace_id}/projects/{project_id}/integrations/{connection_id}"
        data = self._c._request("integrations", "GET", path)
        return IntegrationConnection.model_validate(data)

    def invoke_action(
        self,
        workspace_id: str,
        project_id: str,
        connection_id: str,
        action: str,
        payload: Optional[Dict[str, Any]] = None,
        *,
        request_id: str | None = None,
    ) -> Dict[str, Any]:
        path = (
            f"/v1/workspaces/{workspace_id}/projects/{project_id}"
            f"/integrations/{connection_id}/action/{action}:invoke"
        )
        return self._c._request(
            "integrations",
            "POST",
            path,
            json_body=payload or {},
            request_id=request_id,
        ) or {}
