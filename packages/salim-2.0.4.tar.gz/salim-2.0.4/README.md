# 🤖 Salim v12 — Your AI-Powered Laptop Assistant on Telegram

Control your entire laptop, run autonomous tasks, and automate your digital life — all through Telegram.  
**No cloud. No subscriptions. 100% yours.**

---

## ✨ What Salim Can Do

| Category | Capability |
|---|---|
| 🖥️ System | Screenshots, process control, power (shutdown/sleep/lock), disk info |
| 🐚 Shell | Run any terminal command, live output streaming |
| 📁 Files | Browse, upload, download, search, watch for changes |
| 🧠 AI | Natural language understanding, chat memory, vision (describe images) |
| 📄 Documents | Create DOCX, XLSX, PDF, PPTX, CSV — receive real files in Telegram |
| 📧 Email | Send, read, reply, search via SMTP/IMAP — no third-party app |
| 🤖 Agent | Autonomous multi-step task execution — "create an invoice and email it" |
| 🌍 Weather | Real-time forecasts, 7-day outlook (Open-Meteo, free, no API key) |
| 📅 Calendar | Google Calendar + local calendar, add/view/search events |
| 🌐 Web | Fetch pages, DuckDuckGo search, news, YouTube summaries |
| 🔀 Git | Full git control — status, commit, push, pull, clone, branch |
| 🌅 Digest | Morning briefing: weather + calendar + email + news + system health |
| 🌐 Translate | 30+ languages via LibreTranslate (free, open-source) |
| 🔌 Network | Port scanner, network devices, ping, DNS, traceroute, WHOIS |
| ⏰ Reminders | Natural language: "remind me to call John in 2 hours" |
| 💰 Finance | Stocks, crypto, forex in real-time (Yahoo Finance + CoinGecko, free) |
| 💾 Backup | rsync/tar encrypted file backups, scheduled recurring |
| 📋 Transcript | JSONL session logs, searchable audit trail, token usage stats |
| 🔔 Alerts | CPU/RAM/disk/temp thresholds with call/video Telegram buttons |
| 🎙️ Voice | Send a voice message → Salim transcribes and executes |
| 📷 Camera | Webcam snapshots, motion detection alerts |
| 🖥️ Stream | Live screen stream to Telegram |
| 🔐 SSH | Remote control other machines from the same bot |
| 🌐 Browser | Playwright browser automation, screenshots, form filling |
| 🗂️ Notes | Quick note-taking, searchable |
| ⏱️ Scheduler | Cron-style task scheduler |
| 💾 Memory | Persistent user memory across sessions |
| 🔌 Skills | Dynamic plugin system — install community skills |

---

## 🚀 Quick Start

```bash
pip install salim
salim setup    # enter bot token + allowed user ID
salim          # start the bot
```

**All dependencies install automatically.** You'll be running in under 2 minutes.

---

## 📦 Installation & Auto-Install

Salim installs all required libraries automatically on first run:

```bash
pip install salim          # installs everything
salim setup                # one-time config wizard
salim                      # start

# Force reinstall all deps
python -m salim._post_install --force

# Install with optional extras
pip install salim[gcal]    # Google Calendar OAuth
pip install salim[youtube] # YouTube video summarizer (yt-dlp)
pip install salim[all]     # everything
```

If any optional library fails to install (e.g., PyAudio on certain systems), Salim logs a warning and continues — no crash. Every feature degrades gracefully.

**System tools** (detected and hinted, not silently broken):
- `ffmpeg` — for audio conversion  
- `nmap` — for full network scanning  
- `rsync` — for file backups (falls back to tar)  
- `git` — for git commands  

---

## 🌍 Weather

Real-time weather powered by [Open-Meteo](https://open-meteo.com/) — **completely free, no API key**.

```
/weather                    — weather at your saved location
/weather London             — weather for any city
/weather London 5           — 5-day forecast
/weather set Dubai          — save your default city
```

Shows: condition, temperature, feels-like, humidity, wind speed, precipitation, sunrise/sunset.

---

## 📅 Calendar

Works with **Google Calendar** (optional OAuth) or a built-in **local calendar** with no setup.

```
/cal                        — today's events
/cal tomorrow               — tomorrow's events
/cal week                   — this week's events
/cal add Meeting with Alex tomorrow 3pm
/cal add Dentist April 15 10am 1h
/cal search project
/cal delete <id>
/cal setup                  — Google Calendar OAuth guide
```

No Google account needed — local calendar works out of the box.

---

## 🌐 Web Search & Fetch

DuckDuckGo search, webpage reader, news aggregator, YouTube summarizer — **no API keys**.

```
/websearch latest AI news
/webnews Bitcoin
/web https://example.com          — fetch + extract content
/web summary https://example.com  — AI-powered page summary
/webread https://example.com      — full readable text as file
/yt https://youtube.com/watch?v=  — video info + AI summary
```

---

## 🔀 Git Control

Full git operations from your phone.

```
/git                       — status of current repo
/git log 20                — last 20 commits
/git diff                  — uncommitted changes
/git pull                  — pull from remote
/git push                  — push to remote
/git commit Fixed bug in auth module
/git checkout feature/new-ui
/git clone https://github.com/user/repo
/git branch                — list all branches
/git repos                 — find git repos on this machine
/git cd ~/Projects/myapp   — set working repository
```

---

## 🌅 Daily Digest

One command gives you everything you need to start the day.

```
/digest                    — full morning briefing now
/digest schedule 7:30      — auto-send every morning at 7:30am
/digest stop               — cancel scheduled digest
```

The digest includes:
- 🌍 Weather at your location
- 📅 Calendar events for today
- 📧 Unread email count + important senders
- 📰 Top news headlines
- 💻 System health (CPU, RAM, disk, battery)
- 👋 Greeting based on time of day

---

## 🌐 Translation

Translate between 30+ languages using [LibreTranslate](https://libretranslate.com/) — **free, open-source, self-hostable**.

```
/translate Hello world to Arabic
/translate Bonjour monde           — auto-detect → English
/tl ar How are you?                — shorthand: /tl <lang> <text>
/tl zh Good morning everyone
/translate sethost http://localhost:5000   — use your own instance
```

Supported: English, Arabic, French, German, Spanish, Italian, Portuguese, Russian, Chinese, Japanese, Korean, Hindi, Urdu, Turkish, Persian, Hebrew, and 20+ more.

Falls back to AI translation if no LibreTranslate instance is reachable.

---

## 🔌 Network & SysMon

```
/ports                     — open ports on this machine
/portscan 192.168.1.1      — scan ports on any host
/netdevices                — find all devices on local network (nmap/ARP)
/myip                      — local IP + public IP
/ping google.com
/dns openai.com
/traceroute 8.8.8.8
/whois github.com
```

Requires `nmap` for full network scan (`sudo apt install nmap` or `brew install nmap`). Falls back to ARP table without it.

---

## ⏰ Reminders

Natural language reminder system — no date format to learn.

```
/remind me to call John in 2 hours
/remind take medicine every day at 8am
/remind standup meeting tomorrow at 9am
/remind backup server every week
/remind gym in 30 minutes

/reminders                 — list all reminders
/remdel <id>               — delete a reminder
/remclear                  — clear all reminders
```

Recurring reminders survive restarts. All reminders fire even when you're away from keyboard.

---

## 💰 Stocks, Crypto & Forex

Real-time prices from **Yahoo Finance** and **CoinGecko** — both free, no API key.

```
/price AAPL                — Apple stock price
/price BTC ETH SOL         — multiple crypto prices
/price AAPL MSFT GOOGL     — multiple stocks

/market                    — S&P 500, Dow, NASDAQ, FTSE, Nikkei, Gold, Oil

/fx USD to AED             — exchange rate
/fx 1000 SAR to USD        — currency conversion
/fx 500 EUR to GBP
```

Shows: price, 24h change %, market cap (crypto), exchange.

---

## 💾 Backup

File backups using `rsync` (incremental, fast) with `tar.gz` fallback.

```
/backup now ~/Documents
/backup now ~/Projects to /Volumes/ExternalDrive
/backup schedule ~/Documents daily 2am
/backup schedule ~/Projects weekly
/backup list               — scheduled backups
/backup status             — last backup results
/backup cancel <id>        — cancel a schedule
```

---

## 📋 Session Transcript

Every AI conversation is automatically saved as replayable JSONL, inspired by OpenClaw's architecture.

```
/transcript                — today's turns
/transcript stats          — 30-day token usage + cost estimate
/transcript search meeting — search past conversations
/transcript export         — download full JSONL log
/transcript clear          — wipe today's log
```

---

## 🤖 Autonomous Agent

The most powerful feature. Give Salim a complex task and it figures out all the steps.

```
/agent create a professional invoice for ABC Corp 5000 USD and email it to billing@abc.com
/agent summarize all PDFs in my Downloads folder and create an Excel report
/agent fetch the homepage of anthropic.com and write a one-page summary as a Word doc
/agent check my email, find anything from my boss, and draft a reply

/agentstop                 — stop running agent
/agentstatus               — check if agent is running
/agentlog                  — see last agent run steps
/agenthelp                 — full guide
```

---

## 📄 Document Creation

All documents are real files — no placeholders, no mocks.

```
/agent create a resignation letter for [company]
/agent make an Excel salary sheet for 10 employees
/agent create a PowerPoint pitch deck with 5 slides about AI trends
/agent convert report.docx to PDF
```

Files are automatically sent to your Telegram chat.

---

## 📧 Email

Full SMTP/IMAP email integration. Works with Gmail, Outlook, Yahoo, or any email provider.

```
# Setup (one time)
/agent email setup

# Send email
/agent email send to boss@company.com subject Monthly Report body Done. attach report.xlsx

# Read inbox
/agent email read 10
/agent email search invoice

# Reply
/agent email reply to ID123 body Thanks, will review by Friday.
```

---

## 🔔 Alert System

Automatic monitoring with escalating notifications.

```
/alert cpu 80              — alert when CPU > 80%
/alert ram 90              — alert when RAM > 90%
/alert disk 95             — alert when disk > 95%
/alert temp 75             — alert when CPU temp > 75°C
/alert process chrome      — alert if process stops

/alerts                    — list active alerts
/alertstop <id>            — stop an alert
```

Alert messages include inline buttons:
- 📞 **Call Now** — opens a Telegram voice call
- 📹 **Video Call Now** — opens a Telegram video call  
- ✅ **Acknowledge** — marks alert as seen

Use `--call` or `--video` flags: `/alert cpu 90 --call`

---

## 🖥️ System Control

```
/screenshot                — take screenshot
/screen                    — start live screen stream
/screenstream stop

/ps                        — running processes
/kill <pid>                — kill a process
/top                       — CPU/RAM usage

/shutdown                  — shutdown PC
/restart                   — restart PC
/sleep                     — sleep mode
/lock                      — lock screen
```

---

## 🐚 Shell

```
/shell ls -la ~/Desktop
/shell git log --oneline -20
/shell df -h
/shell python3 script.py
/run python3 script.py      — alias
```

---

## 📁 Files

```
/ls                        — list current directory
/cd ~/Desktop              — change directory
/find *.pdf                — find files by pattern
/upload                    — send a file to your PC
/download ~/file.pdf       — download a file from your PC
/watch ~/Downloads         — watch a folder for changes
```

---

## 🔐 SSH

```
/ssh_add myserver          — register a remote host
/ssh myserver ls -la       — run command on remote
/ssh_upload myserver local.txt /remote/path/
/ssh_download myserver /remote/file.txt
```

---

## 🎙️ Voice Messages

Send a voice message → Salim transcribes it (Whisper, offline) → executes the command.

---

## 📷 Camera

```
/camera                    — take webcam snapshot
/camera 5                  — take 5 photos
/motion                    — start motion detection alerts
/motionstop                — stop motion detection
```

---

## 🌐 Browser Automation

```
/browse https://example.com         — open page, take screenshot
/browse click "Sign In"
/browse type username admin
/browse screenshot
/browse pdf                          — save page as PDF
```

---

## 🔐 Intrusion Detection

```
/guard on                  — enable intrusion detection
/guard off                 — disable
/guard status              — current status
```

Triggers when unauthorized users message the bot.

---

## 📝 Notes

```
/note Buy groceries
/note Meeting notes: discussed Q4 targets
/notes                     — list all notes
/notedel 3                 — delete note #3
```

---

## ⏱️ Scheduler

```
/at 2pm /screenshot        — run command at specific time
/every 30m /ps             — run every 30 minutes
/jobs                      — list scheduled jobs
/jobcancel <id>            — cancel a job
```

---

## 🔌 Skills (Plugins)

```
/skills                    — list installed skills
/skilladd https://...      — install community skill
```

Skills are Python files you drop in `~/.salim/skills/`. Each skill adds new `/commands`.

---

## ⚙️ Configuration

Stored in `~/.salim/config.enc` (encrypted).

```bash
salim setup                # full wizard
salim config show          # view current settings
salim config set key value # update a value
```

Key settings:
- `bot_token` — your Telegram bot token (from @BotFather)
- `allowed_users` — comma-separated Telegram user IDs
- `ai_api_key` — NVIDIA NIM / OpenAI compatible key for AI features
- `ai_model` — model to use (default: meta/llama-3.1-70b-instruct)

---

## 🔧 Advanced

**Run as a background service:**
```bash
# systemd (Linux)
salim install-service
systemctl --user start salim

# launchd (macOS)
salim install-service
launchctl start salim
```

**Update:**
```bash
pip install --upgrade salim
# All new deps install automatically on next start
```

**Logs:**
```bash
salim --verbose            # verbose mode
~/.salim/logs/             # log files
/transcript stats          # AI usage stats from inside Telegram
```

---

## 📋 All Commands

| Command | Description |
|---|---|
| `/start` | Welcome message |
| `/help` | Full command list |
| **System** | |
| `/screenshot` | Take a screenshot |
| `/screen` | Live screen stream |
| `/ps` | Running processes |
| `/kill <pid>` | Kill a process |
| `/top` | CPU/RAM monitor |
| `/sysinfo` | System information |
| **Shell** | |
| `/shell <cmd>` | Run terminal command |
| `/run <cmd>` | Alias for shell |
| **Files** | |
| `/ls` | List directory |
| `/cd <path>` | Change directory |
| `/find <pattern>` | Find files |
| `/watch <path>` | Watch for changes |
| **Power** | |
| `/shutdown` | Shutdown PC |
| `/restart` | Restart PC |
| `/sleep` | Sleep mode |
| `/lock` | Lock screen |
| **AI & Agent** | |
| `/agent <task>` | Autonomous task |
| `/agentstop` | Stop agent |
| `/agentlog` | Last agent log |
| `/agenthelp` | Agent guide |
| **Weather** | |
| `/weather [city] [days]` | Weather forecast |
| **Calendar** | |
| `/cal [today/week/add]` | Calendar |
| **Web** | |
| `/websearch <query>` | Web search |
| `/webnews <topic>` | News on topic |
| `/web <url>` | Fetch webpage |
| `/yt <url>` | YouTube summary |
| **Git** | |
| `/git <subcommand>` | Git control |
| **Digest** | |
| `/digest` | Morning briefing |
| **Translation** | |
| `/translate <text> to <lang>` | Translate |
| `/tl <lang> <text>` | Quick translate |
| **Network** | |
| `/ports` | Open ports |
| `/netdevices` | LAN devices |
| `/myip` | Local + public IP |
| `/ping <host>` | Ping |
| `/dns <domain>` | DNS lookup |
| `/traceroute <host>` | Traceroute |
| `/whois <domain>` | WHOIS |
| **Reminders** | |
| `/remind <text>` | Set reminder |
| `/reminders` | List reminders |
| `/remdel <id>` | Delete reminder |
| **Finance** | |
| `/price <symbol>` | Stock/crypto price |
| `/market` | Market overview |
| `/fx <from> to <to>` | Currency rate |
| **Backup** | |
| `/backup now <path>` | Backup now |
| `/backup schedule` | Schedule backup |
| **Transcript** | |
| `/transcript` | View session log |
| `/transcript stats` | Token usage |
| `/transcript export` | Download JSONL |
| **Alerts** | |
| `/alert <type> <threshold>` | Set alert |
| `/alerts` | List alerts |
| **Notes** | |
| `/note <text>` | Add note |
| `/notes` | List notes |
| **Scheduler** | |
| `/at <time> <cmd>` | Run at time |
| `/every <interval> <cmd>` | Recurring |
| `/jobs` | Scheduled jobs |
| **SSH** | |
| `/ssh_add <host>` | Register host |
| `/ssh <host> <cmd>` | Run remote cmd |
| **Browser** | |
| `/browse <url>` | Browser control |
| **Voice/Camera** | |
| `/camera` | Webcam snapshot |
| `/tts <text>` | Text-to-speech |
| **QR** | |
| `/qr <text>` | Generate QR code |
| **Skills** | |
| `/skills` | List plugins |
| `/skilladd <url>` | Install plugin |

---

## 🆕 What's New in v12

**11 new capability modules, all real implementations:**

- **🌍 Weather** — Open-Meteo (free, no key), real forecasts, 7-day outlook, saves default city
- **📅 Calendar** — Google Calendar OAuth + local calendar fallback, natural language date parsing
- **🌐 Web** — DuckDuckGo HTML search (no API key), full page reader, AI summaries, YouTube info
- **🔀 Git** — Full git control, auto-finds repos, clone to Desktop, branch/commit/push/pull
- **🌅 Daily Digest** — Automated morning briefing combining 5 data sources
- **🌐 Translation** — LibreTranslate (self-hostable), 30+ languages, AI fallback
- **🔌 Network/SysMon** — Port scanner, LAN device discovery (nmap/ARP), DNS, ping, traceroute, WHOIS
- **⏰ Reminders** — Natural language parsing, recurring reminders, survive restarts
- **💰 Finance** — Yahoo Finance + CoinGecko (both free), stocks/crypto/forex, market overview
- **💾 Backup** — rsync incremental backups with tar.gz fallback, scheduled recurring
- **📋 Transcripts** — JSONL session audit log (OpenClaw-inspired), searchable, token stats

**Auto-install**: all new dependencies install automatically on `pip install --upgrade salim`.

---

## 🏗️ Architecture

```
~/.salim/
├── config.enc           # encrypted config
├── memory.json          # persistent user memory
├── alerts.json          # active alert monitors
├── reminders.json       # pending reminders
├── transcripts/         # JSONL session logs (per user per day)
│   └── session_<uid>_<date>.jsonl
├── backups/             # local file backups
├── calendar/            # calendar data + Google OAuth token
├── skills/              # installed skill plugins
├── logs/                # application logs
└── agent/               # agent run logs
```

Every component stores its state in `~/.salim/`. Nothing goes to the cloud without your explicit configuration.

---

## 🔒 Security

- All config stored **encrypted** on disk (Fernet symmetric encryption)
- **Allowlist only** — only your Telegram user IDs can control the bot
- Intrusion detection — unauthorized attempts trigger instant alerts
- SSH keys stored encrypted, never plaintext
- Email credentials stored with `chmod 600` (owner-read-only)

---

## 📄 License

MIT — free to use, modify, and distribute.

---

*Built with ❤️ using Python, python-telegram-bot, and 100% free/open-source tools.*
