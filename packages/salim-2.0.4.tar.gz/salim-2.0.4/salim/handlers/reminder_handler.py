"""
Salim Reminder Handler — Natural language reminders with snooze, recurring support.

Commands:
  /remind me to call John in 2 hours
  /remind me to take medicine every day at 8am
  /remind meeting with team tomorrow at 3pm
  /reminders                      — list all upcoming reminders
  /remdel <id>                    — delete a reminder
  /remclear                       — clear all reminders
"""
from __future__ import annotations
import asyncio
import json
import logging
import re
from datetime import datetime, timedelta
from pathlib import Path

from telegram import Update, Bot
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.reminders")
REMINDERS_FILE = Path.home() / ".salim" / "reminders.json"
_reminder_tasks: dict[str, asyncio.Task] = {}


def _load() -> list[dict]:
    if REMINDERS_FILE.exists():
        try:
            return json.loads(REMINDERS_FILE.read_text())
        except Exception:
            pass
    return []


def _save(reminders: list[dict]):
    REMINDERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    REMINDERS_FILE.write_text(json.dumps(reminders, indent=2, default=str))


def _parse_reminder_time(text: str) -> tuple[datetime | None, bool, str]:
    """
    Parse natural language time from reminder text.
    Returns (when, is_recurring, cleaned_text).
    """
    now = datetime.now()
    text_lower = text.lower()
    is_recurring = False
    when = None

    # Recurring: every day/week/hour/X minutes
    recurring_match = re.search(
        r"every\s+(?:(\d+)\s+)?(day|hour|minute|week|month)s?(?:\s+at\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm)?))?",
        text_lower
    )
    if recurring_match:
        is_recurring = True
        amount = int(recurring_match.group(1) or 1)
        unit   = recurring_match.group(2)
        time_str = recurring_match.group(3)
        unit_map = {"minute": amount, "hour": amount * 60, "day": amount * 1440,
                    "week": amount * 10080, "month": amount * 43200}
        interval_mins = unit_map.get(unit, 1440)

        if time_str:
            # Parse specific time for daily recurring
            m = re.match(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", time_str.strip(), re.I)
            if m:
                h = int(m.group(1)); mn = int(m.group(2) or 0)
                ap = (m.group(3) or "").lower()
                if ap == "pm" and h < 12: h += 12
                elif ap == "am" and h == 12: h = 0
                when = now.replace(hour=h, minute=mn, second=0, microsecond=0)
                if when <= now:
                    when += timedelta(days=1)
        else:
            when = now + timedelta(minutes=interval_mins)

        text = re.sub(recurring_match.re, "", text).strip()
        text = re.sub(r"^(me to|to)\s+", "", text, flags=re.I).strip()
        return when, is_recurring, text

    # In X minutes/hours/days
    m = re.search(r"in\s+(\d+)\s+(minute|hour|day|week)s?", text_lower)
    if m:
        amount = int(m.group(1)); unit = m.group(2)
        delta_map = {"minute": timedelta(minutes=amount), "hour": timedelta(hours=amount),
                     "day": timedelta(days=amount), "week": timedelta(weeks=amount)}
        when = now + delta_map[unit]
        text = re.sub(m.re, "", text).strip()

    # At specific time today/tomorrow
    elif re.search(r"\bat\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?", text_lower):
        t_match = re.search(r"at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text_lower, re.I)
        if t_match:
            h = int(t_match.group(1)); mn = int(t_match.group(2) or 0)
            ap = (t_match.group(3) or "").lower()
            if ap == "pm" and h < 12: h += 12
            elif ap == "am" and h == 12: h = 0
            when = now.replace(hour=h, minute=mn, second=0, microsecond=0)
            if "tomorrow" in text_lower:
                when += timedelta(days=1)
            elif when <= now:
                when += timedelta(days=1)
            text = re.sub(r"\bat\s+\d{1,2}(?::\d{2})?\s*(?:am|pm)?", "", text, flags=re.I).strip()

    # Tomorrow at X
    elif "tomorrow" in text_lower:
        when = (now + timedelta(days=1)).replace(hour=9, minute=0, second=0, microsecond=0)

    # Clean up prefix words
    text = re.sub(r"^(remind\s+)?(me\s+to|to)\s+", "", text, flags=re.I).strip()
    text = re.sub(r"\btomorrow\b", "", text, flags=re.I).strip()
    return when, is_recurring, text


class ReminderHandlers:

    @require_auth
    async def cmd_remind(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /remind me to call John in 2 hours
        /remind take medicine every day at 8am
        /remind meeting tomorrow at 3pm
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        text    = " ".join(ctx.args) if ctx.args else ""

        if not text:
            await msg.reply_text(
                "⏰ <b>Reminder Examples:</b>\n\n"
                "<code>/remind me to call John in 2 hours</code>\n"
                "<code>/remind take medicine every day at 8am</code>\n"
                "<code>/remind meeting tomorrow at 3pm</code>\n"
                "<code>/remind standup in 30 minutes</code>\n"
                "<code>/remind backup every week</code>\n\n"
                "📋 List: <code>/reminders</code>",
                parse_mode="HTML"
            )
            return

        when, is_recurring, label = _parse_reminder_time(text)

        if not when:
            await msg.reply_text(
                "❌ Could not parse time.\n\n"
                "Try: <code>/remind call John in 2 hours</code> or "
                "<code>/remind standup tomorrow at 9am</code>",
                parse_mode="HTML"
            )
            return

        reminder = {
            "id":         f"rem_{int(when.timestamp())}_{hash(label) % 10000:04d}",
            "label":      label,
            "when":       when.isoformat(),
            "user_id":    user_id,
            "recurring":  is_recurring,
            "original":   text,
            "created":    datetime.now().isoformat(),
        }
        reminders = _load()
        reminders.append(reminder)
        _save(reminders)

        time_str = when.strftime("%a %b %d at %I:%M %p")
        recur_str = " (recurring)" if is_recurring else ""
        await msg.reply_text(
            f"✅ <b>Reminder set{recur_str}</b>\n\n"
            f"📝 {label}\n"
            f"⏰ {time_str}\n\n"
            f"ID: <code>{reminder['id']}</code>  ·  /reminders to view all",
            parse_mode="HTML"
        )

        # Schedule the reminder fire
        await self._schedule_reminder(reminder, update.get_bot())

    async def _schedule_reminder(self, reminder: dict, bot: Bot):
        """Schedule a reminder to fire at the right time."""
        rid = reminder["id"]
        when = datetime.fromisoformat(reminder["when"])
        delay = max(0.0, (when - datetime.now()).total_seconds())

        async def _fire():
            await asyncio.sleep(delay)
            try:
                await bot.send_message(
                    chat_id=reminder["user_id"],
                    text=f"⏰ <b>Reminder!</b>\n\n📝 {reminder['label']}",
                    parse_mode="HTML"
                )
                # If recurring, reschedule
                if reminder.get("recurring"):
                    _, _, _ = _parse_reminder_time(reminder["original"])
                    new_when = when + timedelta(days=1)  # daily default
                    new_rem = {**reminder, "when": new_when.isoformat()}
                    reminders = _load()
                    reminders = [r for r in reminders if r["id"] != rid]
                    reminders.append(new_rem)
                    _save(reminders)
                    await self._schedule_reminder(new_rem, bot)
                else:
                    reminders = _load()
                    _save([r for r in reminders if r["id"] != rid])
            except Exception as e:
                logger.error(f"Reminder fire error: {e}")

        task = asyncio.create_task(_fire())
        _reminder_tasks[rid] = task

    async def restore_reminders(self, bot: Bot):
        """Called at startup to restore pending reminders."""
        reminders = _load()
        now = datetime.now()
        active = []
        for r in reminders:
            try:
                when = datetime.fromisoformat(r["when"])
                if when > now:
                    active.append(r)
                    await self._schedule_reminder(r, bot)
                elif r.get("recurring"):
                    # Reschedule missed recurring reminders for next occurrence
                    new_when = now.replace(
                        hour=when.hour, minute=when.minute, second=0, microsecond=0
                    )
                    if new_when <= now:
                        new_when += timedelta(days=1)
                    new_rem = {**r, "when": new_when.isoformat()}
                    active.append(new_rem)
                    await self._schedule_reminder(new_rem, bot)
            except Exception:
                pass
        _save(active)

    @require_auth
    async def cmd_reminders(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/reminders — list all upcoming reminders."""
        msg = update.effective_message
        reminders = [r for r in _load() if str(r.get("user_id")) == str(update.effective_user.id)]
        reminders.sort(key=lambda r: r.get("when", ""))

        if not reminders:
            await msg.reply_text(
                "📋 No reminders set.\n\n"
                "Add one: <code>/remind call John in 2 hours</code>",
                parse_mode="HTML"
            )
            return

        lines = [f"📋 <b>Your Reminders ({len(reminders)})</b>\n"]
        for r in reminders:
            try:
                when = datetime.fromisoformat(r["when"])
                time_str = when.strftime("%a %b %d at %I:%M %p")
            except Exception:
                time_str = r.get("when", "?")
            recur = " 🔁" if r.get("recurring") else ""
            lines.append(
                f"⏰ <b>{r['label']}</b>{recur}\n"
                f"   {time_str}  ·  ID: <code>{r['id'][-8:]}</code>"
            )
        lines.append("\n<i>Delete: /remdel &lt;id&gt;</i>")
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_remdel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/remdel <id> — delete a reminder."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/remdel &lt;id&gt;</code>  (get IDs from /reminders)", parse_mode="HTML")
            return
        rid = args[0]
        reminders = _load()
        # Match full or partial ID
        before = len(reminders)
        reminders = [r for r in reminders if rid not in r.get("id", "")]
        if len(reminders) < before:
            _save(reminders)
            if rid in _reminder_tasks:
                _reminder_tasks[rid].cancel()
            await msg.reply_text("🗑️ Reminder deleted.")
        else:
            await msg.reply_text(f"❌ No reminder found with ID: <code>{rid}</code>", parse_mode="HTML")

    @require_auth
    async def cmd_remclear(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/remclear — delete all your reminders."""
        uid = str(update.effective_user.id)
        reminders = [r for r in _load() if str(r.get("user_id")) != uid]
        _save(reminders)
        for tid, task in list(_reminder_tasks.items()):
            task.cancel()
        _reminder_tasks.clear()
        await update.effective_message.reply_text("🗑️ All reminders cleared.")
