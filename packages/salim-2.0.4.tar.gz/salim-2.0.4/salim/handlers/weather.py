"""
Salim Weather Handler — Real-time weather using Open-Meteo (100% free, no API key needed).

Commands:
  /weather                    — weather at your saved location
  /weather London             — weather in any city
  /weather London 5           — 5-day forecast
  /weather set London         — save your default location
"""
from __future__ import annotations
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.weather")
WEATHER_CFG = Path.home() / ".salim" / "weather_config.json"

WMO_CODES = {
    0:"☀️ Clear sky", 1:"🌤 Mainly clear", 2:"⛅ Partly cloudy", 3:"☁️ Overcast",
    45:"🌫 Foggy", 48:"🌫 Icy fog", 51:"🌦 Light drizzle", 53:"🌦 Drizzle",
    55:"🌧 Heavy drizzle", 61:"🌧 Light rain", 63:"🌧 Rain", 65:"🌧 Heavy rain",
    71:"❄️ Light snow", 73:"❄️ Snow", 75:"❄️ Heavy snow", 77:"🌨 Snow grains",
    80:"🌦 Light showers", 81:"🌧 Showers", 82:"⛈ Heavy showers",
    85:"🌨 Snow showers", 86:"❄️ Heavy snow showers",
    95:"⛈ Thunderstorm", 96:"⛈ Thunderstorm + hail", 99:"⛈ Heavy thunderstorm + hail",
}

async def _geocode(city: str) -> tuple[float, float, str] | None:
    """Return (lat, lon, display_name) for a city name."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(
                "https://geocoding-api.open-meteo.com/v1/search",
                params={"name": city, "count": 1, "language": "en", "format": "json"}
            )
            data = r.json()
            results = data.get("results", [])
            if not results:
                return None
            res = results[0]
            name = f"{res.get('name','')}, {res.get('country','')}"
            return res["latitude"], res["longitude"], name
    except Exception as e:
        logger.error(f"Geocode error: {e}")
        return None


async def _fetch_weather(lat: float, lon: float, days: int = 1) -> dict | None:
    """Fetch weather from Open-Meteo (free, no API key)."""
    try:
        params = {
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weathercode,apparent_temperature,precipitation",
            "daily": "weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,wind_speed_10m_max,sunrise,sunset",
            "timezone": "auto",
            "forecast_days": min(days, 7),
        }
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
            return r.json()
    except Exception as e:
        logger.error(f"Weather fetch error: {e}")
        return None


def _load_location() -> dict:
    if WEATHER_CFG.exists():
        try:
            return json.loads(WEATHER_CFG.read_text())
        except Exception:
            pass
    return {}


def _save_location(city: str, lat: float, lon: float, name: str):
    WEATHER_CFG.parent.mkdir(parents=True, exist_ok=True)
    WEATHER_CFG.write_text(json.dumps({"city": city, "lat": lat, "lon": lon, "name": name}, indent=2))


class WeatherHandlers:

    @require_auth
    async def cmd_weather(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /weather                — current weather at saved location
        /weather London         — weather in London
        /weather London 5       — 5-day forecast
        /weather set London     — save default location
        """
        msg  = update.effective_message
        args = ctx.args or []

        # Save location
        if args and args[0].lower() == "set":
            city = " ".join(args[1:])
            if not city:
                await msg.reply_text("Usage: <code>/weather set London</code>", parse_mode="HTML")
                return
            await msg.reply_text(f"🔍 Looking up <b>{city}</b>…", parse_mode="HTML")
            geo = await _geocode(city)
            if not geo:
                await msg.reply_text(f"❌ City not found: <b>{city}</b>", parse_mode="HTML")
                return
            lat, lon, name = geo
            _save_location(city, lat, lon, name)
            await msg.reply_text(
                f"✅ Default location set to <b>{name}</b>\n"
                f"Now use <code>/weather</code> anytime for quick weather.",
                parse_mode="HTML"
            )
            return

        # Parse city and days
        days = 1
        city_parts = []
        for a in args:
            if a.isdigit():
                days = min(int(a), 7)
            else:
                city_parts.append(a)
        city = " ".join(city_parts)

        # Resolve location
        if city:
            geo = await _geocode(city)
            if not geo:
                await msg.reply_text(f"❌ City not found: <b>{city}</b>", parse_mode="HTML")
                return
            lat, lon, display_name = geo
        else:
            saved = _load_location()
            if not saved:
                await msg.reply_text(
                    "📍 No default location set.\n\n"
                    "Set one: <code>/weather set YourCity</code>\n"
                    "Or get weather directly: <code>/weather London</code>",
                    parse_mode="HTML"
                )
                return
            lat, lon, display_name = saved["lat"], saved["lon"], saved["name"]

        await msg.reply_text("🌍 Fetching weather…")
        data = await _fetch_weather(lat, lon, days)
        if not data or "current" not in data:
            await msg.reply_text("❌ Could not fetch weather data. Try again shortly.")
            return

        cur = data["current"]
        code = cur.get("weathercode", 0)
        condition = WMO_CODES.get(code, "Unknown")
        temp   = cur.get("temperature_2m", "?")
        feels  = cur.get("apparent_temperature", "?")
        humid  = cur.get("relative_humidity_2m", "?")
        wind   = cur.get("wind_speed_10m", "?")
        precip = cur.get("precipitation", 0)

        lines = [
            f"🌍 <b>{display_name}</b>",
            f"🕐 {datetime.now().strftime('%a %b %d, %H:%M')}",
            "",
            f"{condition}",
            f"🌡️ <b>{temp}°C</b>  (feels like {feels}°C)",
            f"💧 Humidity: {humid}%",
            f"💨 Wind: {wind} km/h",
        ]
        if precip:
            lines.append(f"🌧 Precipitation: {precip} mm")

        # Multi-day forecast
        if days > 1 and "daily" in data:
            daily = data["daily"]
            lines += ["", f"<b>📅 {days}-Day Forecast</b>"]
            dates = daily.get("time", [])
            for i in range(min(days, len(dates))):
                try:
                    d = datetime.strptime(dates[i], "%Y-%m-%d")
                    day_name = d.strftime("%a %d")
                    d_code = daily["weathercode"][i]
                    d_cond = WMO_CODES.get(d_code, "—")
                    hi  = daily["temperature_2m_max"][i]
                    lo  = daily["temperature_2m_min"][i]
                    rain = daily["precipitation_sum"][i]
                    lines.append(
                        f"  <b>{day_name}</b>  {d_cond}  {hi}°↑ {lo}°↓"
                        + (f"  🌧{rain}mm" if rain else "")
                    )
                except Exception:
                    pass

        lines.append(f"\n<i>Data: Open-Meteo (open-source, no API key)</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
