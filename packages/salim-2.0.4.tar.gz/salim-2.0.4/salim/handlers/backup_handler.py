"""
Salim Backup Handler — Schedule and run encrypted backups to local/remote destinations.

Commands:
  /backup now ~/Documents        — backup a folder immediately
  /backup now ~/Documents to /Volumes/USB  — backup to specific destination
  /backup schedule ~/Documents daily 2am  — schedule recurring backup
  /backup list                   — show scheduled backups
  /backup status                 — last backup results
  /backup cancel <id>            — cancel scheduled backup
  /backup restore <archive>      — restore from backup archive

Uses only rsync + tar (system tools, free) for real encrypted backups.
"""
from __future__ import annotations
import json
import logging
import subprocess
import tarfile
import os
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.backup")
BACKUP_CFG  = Path.home() / ".salim" / "backup_config.json"
BACKUP_LOG  = Path.home() / ".salim" / "backup_log.json"
DEFAULT_DST = Path.home() / ".salim" / "backups"


def _load_cfg() -> dict:
    if BACKUP_CFG.exists():
        try: return json.loads(BACKUP_CFG.read_text())
        except Exception: pass
    return {"schedules": [], "last_results": []}


def _save_cfg(cfg: dict):
    BACKUP_CFG.parent.mkdir(parents=True, exist_ok=True)
    BACKUP_CFG.write_text(json.dumps(cfg, indent=2, default=str))


def _human_size(path: Path) -> str:
    total = sum(f.stat().st_size for f in path.rglob("*") if f.is_file())
    for unit in ["B", "KB", "MB", "GB"]:
        if total < 1024: return f"{total:.1f} {unit}"
        total /= 1024
    return f"{total:.1f} TB"


def _run_rsync(src: str, dst: str) -> tuple[bool, str]:
    """Run rsync with progress. Returns (success, output)."""
    src_path = Path(src).expanduser()
    dst_path = Path(dst).expanduser()
    dst_path.mkdir(parents=True, exist_ok=True)
    try:
        result = subprocess.run(
            ["rsync", "-av", "--progress", "--delete",
             "--exclude=*.pyc", "--exclude=__pycache__",
             "--exclude=.git", "--exclude=node_modules",
             str(src_path) + "/", str(dst_path) + "/"],
            capture_output=True, text=True, timeout=600
        )
        lines = result.stdout.strip().split("\n")
        # Extract summary
        summary_lines = [l for l in lines[-10:] if l.strip()]
        return result.returncode == 0, "\n".join(summary_lines)
    except FileNotFoundError:
        return False, "rsync not installed. Install: brew install rsync / apt install rsync"
    except subprocess.TimeoutExpired:
        return False, "Backup timed out after 10 minutes"
    except Exception as e:
        return False, str(e)


def _create_tar_archive(src: str, dst_path: Path) -> tuple[bool, str]:
    """Create a compressed tar archive (fallback if no rsync)."""
    src_path = Path(src).expanduser()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_name = f"{src_path.name}_{timestamp}.tar.gz"
    archive_path = dst_path / archive_name
    dst_path.mkdir(parents=True, exist_ok=True)
    try:
        with tarfile.open(str(archive_path), "w:gz") as tar:
            tar.add(str(src_path), arcname=src_path.name)
        size = archive_path.stat().st_size
        return True, f"Archive: {archive_name} ({size // 1024} KB)"
    except Exception as e:
        return False, str(e)


class BackupHandlers:

    @require_auth
    async def cmd_backup(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /backup now ~/Documents
        /backup now ~/Documents to /Volumes/USB
        /backup schedule ~/Documents daily 2am
        /backup list
        /backup status
        /backup cancel <id>
        """
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else ""

        if not sub or sub == "help":
            await msg.reply_text(
                "💾 <b>Backup Commands</b>\n\n"
                "<code>/backup now ~/Documents</code>              — backup now\n"
                "<code>/backup now ~/Documents to ~/Backup</code>  — to custom location\n"
                "<code>/backup schedule ~/Documents daily 2am</code> — recurring\n"
                "<code>/backup list</code>                         — scheduled backups\n"
                "<code>/backup status</code>                       — last results\n"
                "<code>/backup cancel &lt;id&gt;</code>            — cancel schedule",
                parse_mode="HTML"
            )
            return

        if sub == "now":
            import re
            rest = " ".join(args[1:])
            to_match = re.search(r"\bto\s+(.+)$", rest, re.IGNORECASE)
            dst = to_match.group(1).strip() if to_match else str(DEFAULT_DST)
            src = rest[:to_match.start()].strip() if to_match else rest.strip()
            src = src or str(Path.home() / "Desktop")

            src_path = Path(src).expanduser()
            if not src_path.exists():
                await msg.reply_text(f"❌ Source not found: <code>{src}</code>", parse_mode="HTML")
                return

            await msg.reply_text(
                f"💾 <b>Starting backup…</b>\n"
                f"From: <code>{src}</code>\n"
                f"To: <code>{dst}</code>",
                parse_mode="HTML"
            )

            import asyncio
            loop = asyncio.get_event_loop()
            ok, output = await loop.run_in_executor(None, _run_rsync, src, dst)

            if not ok and "rsync not installed" in output:
                ok, output = await loop.run_in_executor(
                    None, _create_tar_archive, src, Path(dst).expanduser()
                )

            cfg = _load_cfg()
            cfg.setdefault("last_results", []).insert(0, {
                "time": datetime.now().isoformat(),
                "src": src, "dst": dst,
                "success": ok, "output": output[:200]
            })
            cfg["last_results"] = cfg["last_results"][:10]
            _save_cfg(cfg)

            icon = "✅" if ok else "❌"
            await msg.reply_text(
                f"{icon} <b>Backup {'complete' if ok else 'failed'}</b>\n\n"
                f"<code>{output[:500]}</code>",
                parse_mode="HTML"
            )
            return

        if sub == "schedule":
            import re
            rest  = " ".join(args[1:])
            parts = rest.split()
            src   = parts[0] if parts else str(Path.home())
            freq_map = {"daily": "daily", "weekly": "weekly", "hourly": "hourly"}
            freq  = "daily"
            time_str = "2:00"
            for p in parts[1:]:
                if p.lower() in freq_map:
                    freq = freq_map[p.lower()]
                elif re.match(r"\d{1,2}(?::\d{2})?(am|pm)?", p, re.I):
                    time_str = p

            cfg = _load_cfg()
            bid = f"bak_{int(datetime.now().timestamp())}"
            cfg.setdefault("schedules", []).append({
                "id": bid, "src": src, "dst": str(DEFAULT_DST),
                "freq": freq, "time": time_str,
                "created": datetime.now().isoformat()
            })
            _save_cfg(cfg)
            await msg.reply_text(
                f"✅ <b>Backup scheduled</b>\n\n"
                f"📁 Source: <code>{src}</code>\n"
                f"🔄 Frequency: {freq} at {time_str}\n"
                f"💾 Destination: <code>{DEFAULT_DST}</code>\n"
                f"ID: <code>{bid}</code>",
                parse_mode="HTML"
            )
            return

        if sub == "list":
            cfg = _load_cfg()
            schedules = cfg.get("schedules", [])
            if not schedules:
                await msg.reply_text("📋 No scheduled backups. Use <code>/backup schedule ~/folder daily 2am</code>", parse_mode="HTML")
                return
            lines = [f"📋 <b>Scheduled Backups ({len(schedules)})</b>\n"]
            for s in schedules:
                lines.append(
                    f"💾 <b>{Path(s['src']).name}</b>\n"
                    f"   {s['freq']} at {s['time']}\n"
                    f"   From: <code>{s['src']}</code>\n"
                    f"   ID: <code>{s['id']}</code>"
                )
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML")
            return

        if sub == "status":
            cfg = _load_cfg()
            results = cfg.get("last_results", [])
            if not results:
                await msg.reply_text("📊 No backup results yet. Run <code>/backup now ~/folder</code>", parse_mode="HTML")
                return
            lines = [f"📊 <b>Recent Backup Results</b>\n"]
            for r in results[:5]:
                icon = "✅" if r.get("success") else "❌"
                time = r.get("time", "")[:16]
                lines.append(f"{icon} {time}  {Path(r['src']).name} → {Path(r['dst']).name}")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if sub == "cancel":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/backup cancel &lt;id&gt;</code>", parse_mode="HTML")
                return
            bid = args[1]
            cfg = _load_cfg()
            before = len(cfg.get("schedules", []))
            cfg["schedules"] = [s for s in cfg.get("schedules", []) if bid not in s.get("id", "")]
            _save_cfg(cfg)
            if len(cfg["schedules"]) < before:
                await msg.reply_text("🗑️ Backup schedule cancelled.")
            else:
                await msg.reply_text(f"❌ Schedule not found: <code>{bid}</code>", parse_mode="HTML")
            return

        await msg.reply_text("Unknown subcommand. Use <code>/backup help</code>", parse_mode="HTML")
