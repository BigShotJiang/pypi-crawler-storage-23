"""
Salim Translate Handler — Real translation using LibreTranslate (free, open source).
Falls back to DeepL free API or AI translation if LibreTranslate unavailable.

Commands:
  /translate Hello world to Arabic      — translate text
  /translate Hello world                — auto-detect + translate to English
  /tl en Hello world                    — shorthand (tl <target_lang> <text>)
  /tl ar How are you                    — translate to Arabic
  /translate setup                      — configure LibreTranslate instance
"""
from __future__ import annotations
import json
import logging
from pathlib import Path

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.translate")

TRANS_CFG = Path.home() / ".salim" / "translate_config.json"

# Free public LibreTranslate instances (community-maintained)
PUBLIC_INSTANCES = [
    "https://libretranslate.de",
    "https://translate.terraprint.co",
    "https://lt.vern.cc",
]

LANG_NAMES = {
    "en":"English","ar":"Arabic","fr":"French","de":"German","es":"Spanish",
    "it":"Italian","pt":"Portuguese","ru":"Russian","zh":"Chinese","ja":"Japanese",
    "ko":"Korean","hi":"Hindi","ur":"Urdu","tr":"Turkish","nl":"Dutch",
    "pl":"Polish","sv":"Swedish","da":"Danish","fi":"Finnish","no":"Norwegian",
    "fa":"Persian","he":"Hebrew","th":"Thai","vi":"Vietnamese","id":"Indonesian",
    "ms":"Malay","bn":"Bengali","ta":"Tamil","te":"Telugu","mr":"Marathi",
    "gu":"Gujarati","kn":"Kannada","ml":"Malayalam","si":"Sinhala",
}

LANG_CODE_MAP = {v.lower(): k for k, v in LANG_NAMES.items()}
LANG_CODE_MAP.update({k: k for k in LANG_NAMES})  # identity


def _lang_code(name: str) -> str:
    """Convert language name to ISO code."""
    n = name.lower().strip()
    return LANG_CODE_MAP.get(n, n[:2].lower())


def _load_cfg() -> dict:
    if TRANS_CFG.exists():
        try:
            return json.loads(TRANS_CFG.read_text())
        except Exception:
            pass
    return {}


def _save_cfg(cfg: dict):
    TRANS_CFG.parent.mkdir(parents=True, exist_ok=True)
    TRANS_CFG.write_text(json.dumps(cfg, indent=2))


async def _libretranslate(text: str, target: str, source: str = "auto") -> str | None:
    """Try translation via LibreTranslate public instances."""
    cfg      = _load_cfg()
    instances = [cfg.get("instance")] + PUBLIC_INSTANCES if cfg.get("instance") else PUBLIC_INSTANCES

    for instance in instances:
        if not instance:
            continue
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.post(
                    f"{instance}/translate",
                    json={"q": text, "source": source, "target": target, "format": "text"},
                    headers={"Content-Type": "application/json"},
                )
                if r.status_code == 200:
                    data = r.json()
                    return data.get("translatedText")
        except Exception as e:
            logger.debug(f"LibreTranslate {instance}: {e}")
    return None


async def _ai_translate(text: str, target_lang: str, ai_instance) -> str | None:
    """Fallback: use configured AI for translation."""
    if not ai_instance or not ai_instance.is_configured():
        return None
    try:
        target_name = LANG_NAMES.get(target_lang, target_lang)
        result, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": f"Translate the following text to {target_name}. Reply with ONLY the translation, nothing else:\n\n{text}"}],
            system="You are a professional translator. Translate accurately and naturally.",
            max_tokens=1000, temperature=0.1,
        )
        return result.strip()
    except Exception:
        return None


class TranslateHandlers:

    @require_auth
    async def cmd_translate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /translate Hello world to Arabic
        /translate Hello world              — auto to English
        /tl ar Hello world                  — shorthand
        """
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "🌐 <b>Translate</b>\n\n"
                "<code>/translate Hello world to Arabic</code>\n"
                "<code>/translate Bonjour</code>  (auto-detect → English)\n"
                "<code>/tl ar Hello world</code>  (shorthand)\n\n"
                "<b>Languages:</b> English, Arabic, French, German, Spanish, Italian, "
                "Portuguese, Russian, Chinese, Japanese, Korean, Hindi, Urdu, Turkish, and 30+ more.",
                parse_mode="HTML"
            )
            return

        if args[0].lower() == "setup":
            await msg.reply_text(
                "⚙️ <b>Translation Setup</b>\n\n"
                "Salim uses LibreTranslate (open-source, free).\n\n"
                "<b>Self-host (optional, better reliability):</b>\n"
                "<code>pip install libretranslate\nlibretranslate --host 0.0.0.0 --port 5000</code>\n\n"
                "Then save your instance:\n"
                "<code>/translate sethost http://localhost:5000</code>\n\n"
                "<i>Without setup, public instances are used automatically.</i>",
                parse_mode="HTML"
            )
            return

        if args[0].lower() == "sethost":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/translate sethost http://localhost:5000</code>", parse_mode="HTML")
                return
            cfg = _load_cfg()
            cfg["instance"] = args[1]
            _save_cfg(cfg)
            await msg.reply_text(f"✅ LibreTranslate instance saved: <code>{args[1]}</code>", parse_mode="HTML")
            return

        # Parse: /translate <text> to <lang>
        full_text = " ".join(args)
        target = "en"
        source = "auto"

        import re
        to_match = re.search(r"\bto\s+(\w+)\s*$", full_text, re.IGNORECASE)
        if to_match:
            target    = _lang_code(to_match.group(1))
            full_text = full_text[:to_match.start()].strip()
        elif args[0].lower() in LANG_CODE_MAP:
            target    = _lang_code(args[0])
            full_text = " ".join(args[1:])

        if not full_text.strip():
            await msg.reply_text("❌ No text to translate.", parse_mode="HTML")
            return

        target_name = LANG_NAMES.get(target, target.upper())
        await msg.reply_text(f"🌐 Translating to <b>{target_name}</b>…", parse_mode="HTML")

        # Try LibreTranslate first
        result = await _libretranslate(full_text, target, source)

        # Fallback to AI
        if not result:
            result = await _ai_translate(full_text, target, self._ai)

        if result:
            await msg.reply_text(
                f"🌐 <b>Translation → {target_name}</b>\n\n"
                f"<b>Original:</b> {full_text[:300]}\n\n"
                f"<b>Translated:</b> {result[:1000]}",
                parse_mode="HTML"
            )
        else:
            await msg.reply_text(
                "❌ Translation failed. No LibreTranslate instance available and no AI configured.\n\n"
                "• Self-host: <code>pip install libretranslate && libretranslate</code>\n"
                "• Or configure AI via <code>salim setup</code>",
                parse_mode="HTML"
            )

    @require_auth
    async def cmd_tl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/tl <lang_code> <text> — quick translate shorthand."""
        ctx.args = ctx.args or []
        await self.cmd_translate(update, ctx)
