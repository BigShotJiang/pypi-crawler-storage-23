# gravi-model-client

Python client for Gravitate's demand and supply optimization models.

## Installation

```bash
pip install gravi-model-client
```

## Usage

```python
from gravi_model_client import GraviModelClient, ModelRunRequest, OptimizationInput

async with GraviModelClient(api_key="your-api-key", base_url="https://...") as client:
    # Health check
    await client.health_check()

    # Run demand model
    result = await client.run_demand_model(request)

    # Run TSD (supply) model
    result = await client.run_tsd_model(optimization)
```

## Models

This package is the single source of truth for all pydantic models used by both
the client and the server. Import models directly:

```python
from gravi_model_client.demand import ModelRunRequest, StoreRequest, TankRequest, VolumeRange
from gravi_model_client.tsd import OptimizationInput, Directive, Site, Tank
```
