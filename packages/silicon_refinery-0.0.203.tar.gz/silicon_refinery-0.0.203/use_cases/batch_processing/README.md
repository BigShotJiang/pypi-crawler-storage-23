# Batch Processing

For testing batch processing pipelines (e.g., bulk summarization, data enrichment, generating embeddings/text for large datasets) using the SDK.
