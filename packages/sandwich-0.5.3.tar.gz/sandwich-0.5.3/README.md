[![pipeline status](https://gitlab.com/22kittens/sandwich/badges/main/pipeline.svg?job=pages&key_text=pages)](https://gitlab.com/22kittens/sandwich/-/commits/main)
[![PyPI - Version](https://img.shields.io/pypi/v/sandwich)](https://pypi.org/project/sandwich)
[![Documentation](https://img.shields.io/badge/ref-Documentation-blue)](https://22kittens.gitlab.io/sandwich/)
[![coverage](https://gitlab.com/22kittens/sandwich/badges/main/coverage.svg?job=coverage)](https://gitlab.com/22kittens/sandwich/-/commits/main)


Data Vault 2.0 scaffolding tool

> :warning: **Pre-alpha version disclaimer** Please note that this package is in a **pre-alpha** version which means it is used internally in a small circle of users and backwards-incompatible changes might be introduced in future releases.

This tool is designed to streamline the process of creating Data Vault 2.0 entities, such as `hubs`, `links`, and `satellites`. 
As well as building information layer objects such as `dim` and `fact` tables from a multidimensional paradigm.

## How it works

User: provides a staging view `stg.[entity_name]` (or a table if the staging layer persisted)
with all requirements for the `[entity_name]` defined in the schema (how to define see below).  
Tool:
1. Validates metadata of the provided staging view or table.  
2. Generates the necessary DDL statements to create the Data Vault 2.0 entities.
3. Generates ELT procedures to load data to the generated entities.
4. Generates support procedures such as `meta.Drop_all_related_to_[entity_name]` and `elt.Run_all_related_to_[entity_name]`


## Installation

You can install `sandwich` via pip:

```bash
pip install sandwich
```

## Usage example

```python

```

For more examples and detailed usage, please refer to the [documentation](https://22kittens.gitlab.io/sandwich).

## Contributing

Contributions are welcome! If you have suggestions, feature requests, or find any bugs, please open an issue or submit a pull request. Make sure to follow the [contribution guidelines](https://22kittens.gitlab.io/sandwich/CONTRIBUTING).

## Acknowledgments

This project is inspired by the beauty of the Data Vault 2.0 [methodology](https://www.scalefree.com/consulting/data-vault-2-0).

## License

This project is licensed under the [MIT License](https://22kittens.gitlab.io/sandwich/LICENSE).
