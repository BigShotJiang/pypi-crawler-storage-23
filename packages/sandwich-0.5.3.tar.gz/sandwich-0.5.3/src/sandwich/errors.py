from typing import Any

class _Dv2TemplatedError(Exception):
    """Override `_template` with a string using `{value}` placeholder and optionally `{field}` placeholder.
    Example: `_template = "User with {field}={value} not found"`
    """

    _template: str

    def __init__(self, value: Any, field: str | None = None):
        profile = getattr(self, "_template", None)
        if not profile:
            raise NotImplementedError("_template is not implemented")

        if field:
            message = profile.format(field=field, value=value)
        else:
            message = profile.format(value=value)

        super().__init__(message)

class Dv2NotYetImplementedForDialectError(_Dv2TemplatedError):
    _template = "Not yet implemented for '{value}' dialect"
    def __init__(self, value: Any):
        super().__init__(value)
