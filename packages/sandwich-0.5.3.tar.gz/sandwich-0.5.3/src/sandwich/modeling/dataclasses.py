from dataclasses import dataclass
from datetime import datetime
from typing import Any, Tuple

from sqlalchemy import Table

@dataclass(frozen=True)
class Dv2Entity:
    entity_name: str
    profile: str
    created_on: datetime
    version: str

@dataclass(frozen=True)
class StgInfo:
    stg_name: str
    stg_schema: str
    hk_keys: dict[str, Any]
    bk_keys: dict[str, Any]
    sys_columns: dict[str, Any]
    bus_columns: dict[str, Any]
    degenerate_field: dict[str, Any]

@dataclass(frozen=True)
class Dv2SystemInfo:
    entities_list: list[Dv2Entity]
    sys_entities: Table

@dataclass(frozen=True)
class ValidationResult:
    stg_schema: str
    entity_name: str
    bk_keys: list[Tuple[str, Any]]
    hk_keys: list[Tuple[str, Any]]
    business_column_types: dict[str, Any]
    system_column_types: dict[str, Any]
    profile: str
    degenerate_field: dict[str, Any]