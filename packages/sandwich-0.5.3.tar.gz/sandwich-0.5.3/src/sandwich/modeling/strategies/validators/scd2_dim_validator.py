from sandwich.modeling.dataclasses import StgInfo, Dv2SystemInfo
from sandwich.modeling.metadata import modeling_metadata

from .hub_based_validator import HubBasedValidator


class Scd2DimValidator(HubBasedValidator):
    def __init__(self, profile: str):
        super().__init__(profile)
        self._on_validate_staging.append(self._validate_staging)

    @staticmethod
    def _validate_staging(stg_info: StgInfo, _: Dv2SystemInfo) -> None:
        system_column_names = stg_info.sys_columns.keys()
        if modeling_metadata.hashdiff not in system_column_names:
            raise Exception(f"{modeling_metadata.hashdiff} column is required for scd2dim validation")
        if modeling_metadata.is_available not in system_column_names:
            raise Exception(f"{modeling_metadata.is_available} column is required for scd2dim validation")
