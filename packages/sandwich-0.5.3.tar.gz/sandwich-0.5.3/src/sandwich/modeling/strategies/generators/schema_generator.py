from abc import ABC, abstractmethod
from typing import Tuple

from sqlalchemy import Table


class SchemaGenerator(ABC):
    @abstractmethod
    def make_tables(self) -> dict[str, Table]:
        pass

    @abstractmethod
    def make_procedures(self, tables: dict[str, Table]) -> dict[str, Tuple[str, str, str]]:
        pass
