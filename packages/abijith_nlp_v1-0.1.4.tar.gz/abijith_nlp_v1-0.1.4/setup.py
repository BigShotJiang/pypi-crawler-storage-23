from setuptools import setup, find_packages

setup(
    name="abijith_nlp_v1",       # MUST BE UNIQUE on PyPI
    version="0.1.4",
    packages=find_packages(),
    install_requires=[
       "textblob",           
        "spacy",              
        "nltk",              
        "scikit-learn",       
        "gensim",             
        "pandas",             
        "numpy",
    ],
    author="G Abijith",
    description="A simple NLP library for sentiment and entity analysis",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
)