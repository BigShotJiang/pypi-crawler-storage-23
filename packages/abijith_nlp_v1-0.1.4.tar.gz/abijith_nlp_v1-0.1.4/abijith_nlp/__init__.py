from textblob import TextBlob
import spacy

# Load the model carefully
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("Warning: Model not found. Run: python -m spacy download en_core_web_sm")

def analyze_sentiment(text):
    """Returns the polarity score and sentiment label."""
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    
    if polarity > 0:
        sentiment = "Positive"
    elif polarity < 0:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"
        
    return {"polarity": polarity, "sentiment": sentiment}

def extract_entities(text):
    """Returns a dictionary of entity counts."""
    doc = nlp(text)
    entity_count = {}
    
    for ent in doc.ents:
        current_count = entity_count.get(ent.label_, 0)
        entity_count[ent.label_] = current_count + 1
        
    return entity_count

# ... keep your existing imports and functions above ...

def show_example_code():
    """Prints the source code for a sentiment analysis demo."""
    code_to_print = """
!pip install textblob nltk spacy
!python -m spacy download en_core_web_sm

from textblob import TextBlob

sentences = [
    "The movie was fantastic",
    "The plot was boring", 
    "The music was average",
    "I would not recommend this film",
    "The acting was excellent"]

polarities = []

for sentence in sentences:
    blob = TextBlob(sentence)
    polarity = blob.sentiment.polarity
    polarities.append(polarity)

    if polarity > 0:
        sentiment = "Positive"
    elif polarity < 0:
        sentiment = "Negative"
    else:
        sentiment = "Neutral"

    print(sentence)
    print("Polarity: ", polarity)
    print("Sentiment: ", sentiment)

    Labsheet 1
    import nltk
nltk.download('punkt')#punkt is used for tokenization
nltk.download('punkt_tab')#punkt_tab is used for tab tokenization
from nltk.tokenize import word_tokenize, sent_tokenize#tokenization is the process of breaking down text into smaller units like words or sentences
text = "Hello there! How are you doing today? Let's tokenize this text."#sample text for tokenization

print("Word Tokenization:", word_tokenize(text))#word_tokenize function breaks the text into individual words
print("Sentence Tokenization:", sent_tokenize(text))#sent_tokenize function breaks the text into sentences

nltk.download('stopwords')#stopwords are common words that are usually filtered out in text processing
from nltk.corpus import stopwords#importing stopwords from nltk corpus
stop_words = set(stopwords.words('english'))#defining a set of English stopwords
filtered_words = [word for word in word_tokenize(text) if word.lower() not in stop_words]#filtering out stopwords from the tokenized words
print("Filtered Words:", filtered_words)#printing the filtered words

#wordnet download: wordnet is a lexical database whihc is used to find the base word form
nltk.download('wordnet')#downloading wordnet
from nltk.stem import WordNetLemmatizer#importing WordNetLemmatizer for lemmatization
lemmatizer = WordNetLemmatizer() #creating an instance of WordNetLemmatizer
#lemmatization is the process of reducing words to their base or root form   
lemmatized_words = [lemmatizer.lemmatize(word) for word in filtered_words]#lemmatizing the filtered words
print("Lemmatized Words:", lemmatized_words)#printing the lemmatized words

#POS tagging
nltk.download('averaged_perceptron_tagger_eng')#downloading POS tagger
from nltk import pos_tag #part of speech tagging
tokens = word_tokenize("Ronaldo is the Greatest Of all time")#tokenizing a sample sentence
print(pos_tag(tokens))#printing the POS tags for the tokens

'''import nltk
nltk.download('tagsets_json')
nltk.help.upenn_tagset()'''

#NLP pipeline in spacy
import spacy#importing spacy library
nlp = spacy.load("en_core_web_sm")#loading the small English model in spacy
doc = nlp("Apple is looking at buying U.K. startup for $1 billion")#processing a sample text through the NLP pipeline
for token in doc:#iterating through the tokens in the processed document
    print(token.text,  token.pos_)#printing the token text and its part of speech

#NER in spacy
for ent in doc.ents:#iterating through the named entities in the processed document
    print(ent.text,"->", ent.label_)#printing the entity text and its label

    

Labsheet2:
import nltk
from nltk.corpus import wordnet as wn
from gensim.models import Word2Vec
sentences = [["cat", "say", "meow"], ["dog", "say", "woof"], ["natural," "language", "processing"]]
model = Word2Vec(sentences, vector_size=100, window=5, min_count=1, workers=4)
vector = model.wv['cat']
print(vector)

similarity = model.wv.similarity('cat', 'dog')
print(f"Similarity between 'cat' and 'dog': {similarity}")

import gensim.downloader as api
word_vectors = api.load("glove-wiki-gigaword-50")
print(word_vectors['computer'])
print(word_vectors.similarity('computer', 'laptop'))


import gensim.downloader as api
word_vectors = api.load("glove-wiki-gigaword-50")
print(word_vectors['computer'])
print(word_vectors.similarity('computer', 'laptop'))

from transformers import BertTokenizer, BertModel
import torch
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')

sentence = "The Bank is near the river."
inputs = tokenizer(sentence, return_tensors='pt')
outputs = model(**inputs)
embeddings = outputs.last_hidden_state
print(embeddings)

from transformers import RobertaTokenizer, RobertaModel

tokenizer = RobertaTokenizer.from_pretrained("roberta-base")
model = RobertaModel.from_pretrained("roberta-base")
inputs = tokenizer("Word representations are powerful", return_tensors = "pt")

outputs = model(**inputs)

print(outputs.last_hidden_state.shape)


Labsheet 3;
import nltk
from nltk.corpus import brown
from collections import Counter as counter
nltk.download('brown')
words = brown.words()
freq_dist = counter(word.lower() for word in words)

def is_complex(word, threshold=50):
    return freq_dist[word.lower()] < threshold

sentence = "The quick brown fox jumps over the lazy dog"
for word in sentence.split():
    if is_complex(word):
        print(f"Complex word found: {word}")
    else:
        print(f"Simple word: {word}")
        


import pandas as pd
from sklearn.tree import DecisionTreeClassifier

def extract_features(word):
    return {
        "length": len(word),
        "frequency": freq_dist.get(word.lower(), 0)
    }


data = [
    ("dog", 0), 
    ("cat", 0), 
    ("gay", 1),
    ("photosynthesis", 1),
    ("think", 0),
    ("bitch", 1)
]

df = pd.DataFrame(data, columns=["word", "label"])

features = df["word"].apply(extract_features)
X = pd.DataFrame(features.tolist())
y = df["label"]

model = DecisionTreeClassifier()
model.fit(X,y)

test_words = ["flow", "stitch"]

test_features = pd.DataFrame([extract_features(w) for w in test_words])
predictions = model.predict(test_features)

for word, label in zip(test_words, predictions):
    print(word, "->", "Complex" if label == 1 else "Simple")
    """
    print(code_to_print)