# Abijith NLP Library

This is a custom library for performing:
1. Sentiment Analysis
2. Named Entity Recognition (NER)

## Installation
```bash
pip install abijith_nlp_v1