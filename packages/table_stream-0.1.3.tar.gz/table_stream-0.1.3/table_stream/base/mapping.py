
from __future__ import annotations
from abc import abstractmethod, ABC, ABCMeta
from collections.abc import Iterator
from typing import Any, Callable, TypeVar, Generic, Union, Literal
#import pandas as pd
#from pandas import Series


T = TypeVar('T')
K = TypeVar('K')
hashMapName = Literal['DATAFRAME', 'DICT']


class ArrayList[T](list):
    
    def __init__(self, items: list[T] | None = None):
        if items is None:
            items = list()
        super().__init__(items)
        
    def set_items(self, items: list[T]):
        self.clear()
        super().__init__(items)
        
    def for_each(self, func: Callable[[T], Any | None]) -> None:
        for x in self: func(x)
    
    def apply_command(self, func: Callable[[T], Any]) -> ArrayList[Any]:
        return ArrayList([func(x) for x in self])
    
    def size(self) -> int:
        return len(self)
        
    def empty(self) -> bool:
        return self.size() == 0
        
    def get_first(self) -> T:
        return self[0]

    def get_last(self) -> T:
        return self[-1]
    
    def hash(self) -> int:
        return hash(tuple(self))
    
    def contains(self, _o: T) -> bool:
        for i in self:
            if i == _o:
                return True
        return False
    

class HashMap[K, T](metaclass=ABCMeta):
    
    def __repr__(self) -> str:
        return f"<HashMap()> {self.header()}"
    
    @abstractmethod
    def size_values(self) -> int:
        pass
    
    @abstractmethod
    def size_header(self) -> int:
        pass
    
    @abstractmethod
    def __getitem__(self, key: K) -> T:
        pass
    
    @abstractmethod
    def __setitem__(self, key: K, value: T) -> None:
        pass
    
    @abstractmethod
    def get_hash_map_name(self) -> hashMapName:
        pass
    
    @abstractmethod
    def get_real_hash_map(self) -> Union[dict[K, T], pd.DataFrame]:
        pass
    
    @abstractmethod
    def set_real_hash_map(self, hash_map: dict[K, T] | pd.DataFrame) -> None:
        pass

    @abstractmethod
    def clear(self) -> None:
        pass

    @abstractmethod
    def get_first(self) -> T:
        pass

    @abstractmethod
    def set_first(self, value: T) -> None:
        pass

    @abstractmethod
    def get_last(self) -> T:
        pass

    @abstractmethod
    def set_last(self, value: T) -> None:
        pass

    @abstractmethod
    def set_value(self, key: K, value: T) -> None:
        pass

    @abstractmethod
    def get_value(self, key: K) -> T:
        pass

    @abstractmethod
    def header(self) -> ArrayList[K]:
        """
            Retornar as chaves de um dicionário ou columns de um DataFrame()
        """
        pass

    @abstractmethod
    def values(self) -> ArrayList[T]:
        pass

    @abstractmethod
    def delete_items(self, keys: list[K]) -> None:
        """
            Apaga chaves e valores, semelhante ao método pop().
        """
        pass

    @abstractmethod
    def to_json(self) -> str:
        """
            Converte o HashMap() para uma representação no formato json.
        """
        pass

    @abstractmethod
    def to_map_str(self) -> dict[str, Any]:
        """
            Converte o HashMap() para uma representação no formato dict() python.
        """
        pass

    @classmethod
    def from_json(cls, data: str) -> HashMap:
        pass

    @classmethod
    def from_map(cls, data: Any) -> HashMap:
        pass
