from typing import Any, Literal
from pandas.core.api import DataFrame
from table_stream.base.mapping import ArrayList, HashMap, T
import json


class HashMapDict[K, T](HashMap):
    
    def __init__(self, _mapping: dict[K, T] | None = None) -> None:
        super().__init__()
        if _mapping is None:
            _mapping = dict()
        self._mapping: dict[K, T] = _mapping
    
    def size_values(self) -> int:
        return len(self._mapping.values())

    def size_header(self) -> int:
        return self.header().size()

    def __getitem__(self, key: K) -> T:
        return self._mapping[key]

    def __setitem__(self, key: K, value: T) -> None:
        self._mapping[key] = value

    def get_hash_map_name(self) -> Literal['DICT']:
        return "DICT"

    def get_real_hash_map(self) -> dict[K, T]:
        return self._mapping

    def set_real_hash_map(self, hash_map: dict[K, T]) -> None:
        self._mapping = hash_map

    def clear(self) -> None:
        self._mapping.clear()

    def get_first(self) -> T:
        return self._mapping[self.header().get_first()]

    def set_first(self, value: T) -> None:
        self._mapping[self.header().get_first()] = value

    def get_last(self) -> T:
        return self._mapping[self.header().get_last()]

    def set_last(self, value: T) -> None:
        self._mapping[self.header().get_last()] = value

    def set_value(self, key: K, value: T) -> None:
        self._mapping[key] = value

    def get_value(self, key: K) -> T:
        return self._mapping[key]

    def header(self) -> ArrayList[K]:
        return ArrayList(list(self._mapping.keys()))

    def values(self) -> ArrayList[T]:
        return ArrayList(list(self._mapping.values()))

    def delete_items(self, keys: list[K]) -> None:
        for k in keys:
            self._mapping.pop(k)

    def to_json(self) -> str:
        """
        Converte o mapa real para uma string JSON.
        Nota: As chaves e valores devem ser serializáveis pelo módulo json.
        """
        return json.dumps(self.to_map_str(), ensure_ascii=False, indent=4)

    def to_map_str(self) -> dict[str, Any]:
        final = dict()
        for i in self.header():
            final[str(i)] = str(self.get_value(i))
        return final

    
class HashMapDataFrame[K, Series](HashMap):
    
    def __init__(self, data: DataFrame | None) -> None:
        super().__init__()
        if data is None:
            data = DataFrame()
        self._data: DataFrame = data
    
    def size_values(self) -> int:
        return len(self.values())

    def size_header(self) -> int:
        return len(self.header())

    def __getitem__(self, key: K) -> Series:
        return self._data[key]

    def __setitem__(self, key: K, value: Series) -> None:
        self._data[key] = value

    def get_hash_map_name(self) -> Literal['DATAFRAME']:
        return "DATAFRAME"

    def get_real_hash_map(self) -> DataFrame:
        return self._data

    def set_real_hash_map(self, hash_map: DataFrame) -> None:
        self._data = hash_map

    def clear(self) -> None:
        self._data = DataFrame()

    def get_first(self) -> Series:
        return self._data[self.header().get_first()]

    def set_first(self, value: Series) -> None:
        self._data[self.header().get_first()] = value

    def get_last(self) -> Series:
        return self._data[self.header().get_last()]

    def set_last(self, value: T) -> None:
        raise NotImplementedError

    def set_value(self, key: K, value: Series) -> None:
        self._data[key] = value

    def get_value(self, key: K) -> Series:
        return self._data[key]

    def header(self) -> ArrayList[K]:
        return ArrayList(self._data.columns.tolist())

    def values(self) -> ArrayList[Any]:
        return ArrayList(self._data.values.tolist())

    def delete_items(self, keys: list[K]) -> None:
        """
        Remove as colunas informadas.
        """
        # axis=1 indica que queremos remover colunas (as chaves do seu mapa)
        # errors='ignore' evita que o código quebre caso uma chave não exista
        #self._data.drop(columns=keys, axis=1, inplace=True, errors='ignore'
        self._data.drop(columns=keys, inplace=True, errors="ignore",)

    def to_json(self) -> str:
        """
        Serializa o DataFrame para JSON.
        Mantém estrutura por colunas.
        """
        return self._data.astype(str).to_json(orient="columns", force_ascii=False, indent=4)

    def to_map_str(self) -> dict[str, Any]:
        return self._data.astype('str').to_dict()

    
     
   

    