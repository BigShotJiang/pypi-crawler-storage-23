from __future__ import annotations
from abc import ABCMeta, abstractmethod
from typing import Callable, Iterable, Mapping, Any, Optional, Literal, Union, TypeVar
from table_stream.base.hash_map import ArrayList
from table_stream.types.pattner.observer import EventListener, EventProvider, VALUE
import threading
from time import sleep

statusThread = Literal["not_started", "running", "finished"]
exceptionValue = Union[Exception, None]



class StateValue(object):

    def __init__(self) -> None:
        self._running: bool = False
        self._status: statusThread = "not_started"
        self._return_bool: bool = False
        self._exception: exceptionValue = None
        
    def __repr__(self) -> str:
        return f"<{__class__.__name__}()> status: {self._status}, return_bool: {self._return_bool}"

    def get_exception(self) -> exceptionValue:
        return self._exception

    def set_exception(self, exception: exceptionValue) -> None:
        self._exception = exception

    def success(self) -> bool:
        return self._return_bool and self._status == 'finished'

    def operation_erro(self) -> bool:
        if self._status != "finished":
            return False
        if not self._return_bool:
            return True
        return False

    def set_return_bool(self, value: bool) -> None:
        self._return_bool = value

    def get_return_bool(self) -> bool:
        return self._return_bool

    def set_status(self, status: statusThread) -> None:
        self._status = status

    def get_status(self) -> statusThread:
        return self._status

    def is_running(self) -> bool:
        return self._running

    def set_running(self, running: bool) -> None:
        self._running = running


class ThreadConsumer[VALUE](metaclass=ABCMeta):
    """
        Este objeto de ser adicionado ao ControlledThread() para consumir dados e
    status da Thread(), ao iniciar e ao finalizar a Thread() este objeto será notificado

    """

    def __init__(self) -> None:
        self._state: StateValue = StateValue()
        self._name = None
        self._listener = EventListener[ControlledThread[VALUE]]()

    def __repr__(self):
        if self._name is None:
            return f'<{__class__.__name__}()>'
        return f'<{__class__.__name__}() {self._name}>'
    
    def get_listener(self) -> EventListener[ControlledThread[VALUE]]:
        return self._listener
    
    def set_listener(self, listener: EventListener[ControlledThread[VALUE]]):
        self._listener = listener
    
    def get_name(self) -> str | None:
        return self._name
    
    def set_name(self, name: str):
        self._name = name

    @abstractmethod
    def event_init_thread(self) -> None:
        """Recebe uma notificação quando a Thread é iniciada"""
        pass

    @abstractmethod
    def event_finish_thread(self, t: ControlledThread[VALUE]):
        """Recebe uma notificação quando a Thread é finalizada."""
        pass

    def set_consumer_thread(self, func: Callable[[ControlledThread[VALUE]], Any | None]) -> None:
        """
        Repassa a notificação de Thread finalizada para uma função, func deve receber
        uma ControllerThread()
        """
        self.get_listener().set_consumer_command(func)

    def get_consumer_thread(self) -> Callable[[ControlledThread[VALUE]], Any | None] | None:
        return self.get_listener().get_consumer_command()

    def get_state(self) -> StateValue:
        return self._state

    def set_state(self, state: StateValue) -> None:
        self._state = state



class ThreadApplyEvent[VALUE](ThreadConsumer):

    def __init__(self) -> None:
        super().__init__()

    def event_init_thread(self) -> None:
        pass

    def event_finish_thread(self, t: ControlledThread):
        self.get_listener().receiver_notify(t)


class ControlledThread[VALUE](threading.Thread):

    def __init__(
            self, *,
            group=None,
            target: Callable,
            name=None,
            args: Iterable[Any] = None,
            kwargs: Mapping[str, Any] | None = None,
            daemon: bool | None = None,
    ):
        if args is None:
            args = ()
        super().__init__(group, target, name, args, kwargs, daemon=daemon)
        self._target: Callable[[Optional[Any]], Any] = target
        self._args: tuple[Any, ...] = tuple(args)
        self._kwargs: dict[str, Any] = dict(kwargs or {})

        self.__state: StateValue = StateValue()
        self._pause_event: threading.Event = threading.Event()
        self._stop_event: threading.Event = threading.Event()
        # Começa rodando
        self._pause_event.set()

        self._result: VALUE = None
        self._consumer: ThreadApplyEvent = None
        self._provider: EventProvider[ControlledThread] = EventProvider()
        self._provider.set_value(self)
        
    def get_provider(self) -> EventProvider[ControlledThread]:
        return self._provider

    def set_provider(self, p: EventProvider[ControlledThread]) -> None:
        self._provider = p
        self._provider.set_value(self)

    def add_listener(self, listener: EventListener[ControlledThread]) -> None:
        self._provider.add_listener(listener)

    def clear_listeners(self) -> None:
        self._provider.clear_listeners()

    def remove_listener(self, listener: EventListener[ControlledThread]) -> None:
        self._provider.remove_listener(listener)

    def notify_listeners(self):
        self._provider.notify_listeners()

    def set_consumer(self, consumer: ThreadApplyEvent[VALUE]) -> None:
        self._consumer = consumer

    def get_consumer(self) -> ThreadApplyEvent[VALUE] | None:
        return self._consumer

    def get_state(self) -> StateValue:
        return self.__state

    def remove_consumer(self) -> None:
        self._consumer = None

    def on_finish_thread(self) -> None:
        """
            Notificar o CONSUMER e os OBSERVADORES sobre a conclusão da Thread().
        """
        self.__state.set_status("finished")
        self.__state.set_running(False)

        if self.get_consumer() is not None:
            # Informar o consumer sobre a finalização da thread.
            self.get_consumer().set_state(self.get_state())
            self.get_consumer().event_finish_thread(self)
        self.notify_listeners()

    def on_init_thread(self) -> None:
        """
            Notificar o CONSUMER sobre o inicio da Thread().
        """
        self.__state.set_status("running")
        self.__state.set_running(True)
        if self.get_consumer() is not None:
            self.get_consumer().set_state(self.get_state())
            self.get_consumer().event_init_thread()
        self.notify_listeners()

    def get_result(self) -> VALUE:
        return self._result

    def run(self) -> None:
        """
        Executa o callable alvo respeitando pause / stop.
        O callable pode checar should_stop() se quiser encerrar limpo.
        """
        self._pause_event.wait()
        self.on_init_thread()

        # Executa o target
        try:
            if self._target is not None:
                self._result = self._target(*self._args, **self._kwargs)
        except Exception as e:
            self.__state.set_exception(e)
            self.__state.set_return_bool(False)
            self._result = None
        else:
            self.__state.set_return_bool(True)
        finally:
            del self._target, self._args, self._kwargs
            self.on_finish_thread()

    def pause(self) -> None:
        print(f'{__class__.__name__} Thread pausada [{self.name}]')
        self._pause_event.clear()

    def resume(self) -> None:
        self._pause_event.set()

    def stop(self) -> None:
        print(f'{__class__.__name__} Thread cancelada [{self.name}]')
        self._stop_event.set()
        self._pause_event.set()
        self.__state.set_return_bool(False)
        self.on_finish_thread()

    def wait_thread(self, timeout: Optional[float] = None) -> None:
        self.join(timeout)

    def should_stop(self) -> bool:
        """
        Pode ser chamado de dentro do target para parada cooperativa.
        """
        return self._stop_event.is_set()


class ProviderMultiThread(EventProvider[ControlledThread[VALUE]]):

    def __init__(self, name: str = None, show_output: bool = False) -> None:
        super().__init__()
        self._name = name
        self._show_output: bool = show_output
        self.max_threads: int = 2
        self._count_threads: int = 0
        self._started: int = 0
        self._finished: int = 0
        
        self._threads_list = ArrayList[ControlledThread[VALUE]]()
        self._current: ControlledThread = None
        
        self.__erros: int = 0
        self.__success: int = 0
        self.__operations_exceptions: dict[str, Exception] = dict()
        
    def log_operation(self) -> dict[str, int]:
        return {"erros": self.__erros, "succes": self.__success}
    
    def exceptions(self) -> dict[str, Exception]:
        return self.__operations_exceptions
    
    def clear(self):
        self._threads_list.clear()
        self.__erros = 0
        self.__success = 0
        self.__operations_exceptions = dict()
        self._started: int = 0
        self._finished: int = 0
        self._count_threads: int = 0

    def __repr__(self):
        if self._name is not None:
            return f"<{__class__.__name__}() {self._name}>"
        return f"<{__class__.__name__}()>"
    
    def current_thread(self) -> ControlledThread | None:
        return self._current

    def increment_started(self):
        self._count_threads += 1
        self._started += 1

    def increment_finished(self):
        self._finished += 1
        self._count_threads -= 1

    def get_consumer(self) -> ThreadApplyEvent:
        c = ThreadApplyEvent()
        c.set_consumer_thread(self.on_finish_thread)
        return c

    def add_thread(self, t: ControlledThread[VALUE]) -> None:
        t.set_consumer(self.get_consumer())

        if self._count_threads < self.max_threads:
            t.start()
            self.increment_started()
        else:
            self._threads_list.append(t)
            self.run_worker()

    def run_worker(self):
        while self._count_threads >= self.max_threads:
            sleep(0.05)
            continue
        if self._threads_list.size() == 0:
            return

        current: ControlledThread = self._threads_list[0]
        del self._threads_list[0]
        current.start()
        self._current = current
        self.increment_started()

    def on_finish_thread(self, value: ControlledThread[VALUE] = None) -> None:
        self.increment_finished()
        if value is None:
            print(f'{self} Thread nula!!!')
            return None
        if not value.get_state().success():
            print(f'{self} Falha {value.name} ... {value.get_state().get_exception()}')
            
        if value.get_state().get_return_bool():
            self.__success += 1
        else:
            self.__erros += 1
            self.__operations_exceptions[value.name: value.get_state().get_exception()]
            
        self.info()
        self.set_value(value)
        self.notify_listeners()
        self.run_worker()
        
    def get_info(self) -> str:
        return f'{self} Ativas {self._count_threads} [Finalizadas {self._finished}]'

    def info(self):
        if self._show_output:
            print(self.get_info())

    def flush(self):
        while self._finished != self._started:
            sleep(1)
            self.info()
            self.run_worker()
