from table_stream.base.hash_map import HashMapDict, ArrayList
from pandas import DataFrame


class WorkbookData(HashMapDict[str, DataFrame]):
    
    def __init__(self, _mapping: dict[str, DataFrame] | None = None) -> None:
        super().__init__(_mapping)
        
    @property
    def sheet_names(self) -> ArrayList[str]:
        return self.header()
        
    def get_sheet_from_name(self, name: str) -> DataFrame:
        return self.get_value(name)
    
    def get_sheet_at(self, idx: int) -> DataFrame:
        key: str = self.header()[idx]
        return self.get_value(key)
        