from abc import abstractmethod, ABCMeta
from table_stream.types.pattner.observer import Provider, MessageNotification


#=================================================================#
# Base para o padrão de projeto Mediator
#=================================================================#
class Mediator[T](metaclass=ABCMeta):

    def __init__(self, name: str, *, group:str = None, provider: Provider = None):
        self._name = name
        self._group = group
        self._provider: Provider = provider
        
    def get_provider(self) -> Provider | None:
        return self._provider
    
    def set_provider(self, p: Provider):
        self._provider = p

    def get_name(self) -> str:
        return self._name

    def set_name(self, name: str):
        self._name = name

    def get_group(self) -> str | None:
        return self._group

    def set_group(self, group: str):
        self._group = group

    @abstractmethod
    def notify(self, message: MessageNotification) -> None:
        """
            Executa uma ação após receber uma notificação.
        """
        pass

    @abstractmethod
    def clear(self) -> None:
        """
            Limpar observadores
        """
        pass


class ComponentMediator[T]:

    def __init__(self, name: str, *, mediator: Mediator = None, group: str = None):
        self._mediator: Mediator = mediator
        self._name: str = name
        self._group: str = group

    def get_group(self) -> str | None:
        return self._group

    def set_group(self, g: str):
        self._group = g

    def get_name(self) -> str | None:
        return self._name

    def set_name(self, name: str):
        self._name = name

    def get_mediator(self) -> Mediator:
        return self._mediator

    def set_mediator(self, mediator: Mediator) -> None:
        self._mediator = mediator

    def contains_mediator(self) -> bool:
        return self._mediator is not None
