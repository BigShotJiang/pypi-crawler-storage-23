from __future__ import annotations
from abc import ABC, abstractmethod, ABCMeta
from typing import Any, TypeVar
from table_stream.base.hash_map import ArrayList


ADAPTATIVE = TypeVar('ADAPTATIVE')
IMPLEMENTATION = TypeVar('IMPLEMENTATION')


class ObjectAdapter[IMPLEMENTATION](metaclass=ABCMeta):

    def __init__(self, implementation: IMPLEMENTATION):
        super().__init__()
        self._implementation: IMPLEMENTATION = implementation

    @abstractmethod
    def get_adaptative(self) -> ADAPTATIVE:
        pass

    def get_implementation(self) -> IMPLEMENTATION:
        return self._implementation

    def iqual(self, other: ObjectAdapter) -> bool:
        return self.__eq__(other)

    def __eq__(self, other: ObjectAdapter) -> bool:
        return self.hash() == other.hash()

    def hash(self) -> int:
        return self.__hash__()

    def __hash__(self) -> int:
        return self.get_implementation().hash()

    @classmethod
    def build_interface(cls) -> BuilderInterface:
        pass


class BuilderInterface(ABC):

    @abstractmethod
    def create(self) -> Any:
        pass


class ObjectCommand[T](ABC):

    @abstractmethod
    def value(self) -> T:
        pass

    @abstractmethod
    def execute(self) -> None:
        pass


class ObjectRunCommands(object):

    def __init__(self, **kwargs):
        self._commands: ArrayList[ObjectCommand] = ArrayList()

    def clear(self):
        self._commands.clear()

    def contains_command(self, command: ObjectCommand) -> bool:
        return self._commands.contains(command)

    def add_command(self, cmd: ObjectCommand) -> None:
        pass

    def run_commands(self) -> None:
        for cmd in self._commands:
            cmd.execute()


__all__ = [
    'ObjectAdapter', 'ObjectCommand', 'ObjectRunCommands', 'BuilderInterface',
    'ADAPTATIVE', 'IMPLEMENTATION',
]

