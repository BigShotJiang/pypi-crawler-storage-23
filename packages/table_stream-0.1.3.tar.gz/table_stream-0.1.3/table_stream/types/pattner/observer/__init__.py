from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Any, TypeVar, Callable
from table_stream.base import ArrayList


VALUE = TypeVar('VALUE')  
SENDER = TypeVar('SENDER')
ELEMENT = TypeVar('ELEMENT') 
EVENT_TYPE = TypeVar('EVENT_TYPE')  # Evento, geralmente str/Enum



class MessageNotification[EVENT_TYPE, VALUE]:
    
    def __init__(self, event_type: EVENT_TYPE, provider: Any = None) -> None:
        self._value: VALUE = None
        self._provider: Any = provider
        self._event_type: EVENT_TYPE = event_type
    
    def empty(self) -> bool:
        return self._value is None
        
    def get_event_type(self) -> EVENT_TYPE:
        return self._event_type
    
    def set_event_type(self, event_type: EVENT_TYPE):
        self._event_type = event_type
        
    def get_value_notify(self) -> VALUE:
        return self._value
    
    def set_value_notify(self, value: VALUE):
        self._value = value
        
    def get_provider(self) -> Any:
        return self._provider
    
    def set_provider(self, provider: Any):
        self._provider = provider


class AbstractListener[VALUE](ABC):
    
    def __init__(self) -> None:
        pass

    @abstractmethod
    def receiver_notify(self, message: MessageNotification[EVENT_TYPE, VALUE]) -> Any | None:
        pass


class AbstractProvider[VALUE](ABC):
    
    def __init__(self) -> None:
        super().__init__()
        self._listeners: ArrayList[AbstractListener] = ArrayList()

    def __repr__(self):
        return f"<{__class__.__name__}"
    
    def clear(self):
        self._listeners.clear()

    def get_listeners(self) -> ArrayList[AbstractListener]:
        return self._listeners
    
    def set_listeners(self, listeners: ArrayList[AbstractListener]):
        self._listeners = listeners
    
    def add_listener(self, listener: AbstractListener):
        self._listeners.append(listener)

    @abstractmethod
    def get_message(self) -> MessageNotification:
        pass

    @abstractmethod
    def set_message(self, message: MessageNotification, notify: bool = False):
        pass

    @abstractmethod
    def set_message_event(self, event: EVENT_TYPE):
        pass

    @abstractmethod
    def notify_listeners(self):
        pass


class Listener[VALUE](AbstractListener):
    
    def __init__(
                self, name: str, *, group: str = None,
                apply_action: Callable[[VALUE], Any | None] | None = None
            ) -> None:
        super().__init__()
        self._name = name
        self._group = group
        self._apply_act: Callable[[VALUE], Any | None] | None = apply_action

    def get_name(self) -> str | None:
        return self._name

    def set_name(self, name: str):
        self._name = name

    def get_group(self) -> str | None:
        return self._group

    def set_group(self, group: str):
        self._group = group

    def set_apply_action(self, apply_act: Callable[[VALUE], Any | None]):
        self._apply_act = apply_act

    def get_apply_action(self) -> Callable[[VALUE], Any | None] | None:
        return self._apply_act

    def receiver_notify(self, message: MessageNotification[EVENT_TYPE, VALUE]) -> Any | None:
        if self.get_apply_action() is None:
            return None
        return self.get_apply_action()(message.get_value_notify())

    
class Provider[VALUE](AbstractProvider):
    
    def __init__(self, name: str, *, group: str = None) -> None:
        super().__init__()
        self._name = name
        self._group = group
        self._message: MessageNotification = MessageNotification(self._name, provider=self)

    def get_message(self) -> MessageNotification:
        return self._message

    def set_message(self, message: MessageNotification, notify: bool = False):
        self._message = message
        if notify:
            self.notify_listeners()

    def set_message_event(self, event: EVENT_TYPE):
        self._message.set_event_type(event)

    def get_name(self) -> str | None:
        return self._name

    def set_name(self, name: str):
        self._name = name

    def get_group(self) -> str | None:
        return self._group

    def set_group(self, group: str):
        self._group = group

    def notify_listeners(self):
        if self.get_message().empty():
            print(f'[Erro] {self} - Mensagem vazia!')
            return
        
        o: AbstractListener
        for o in self._listeners:
            o.receiver_notify(self.get_message())


class EventListener[VALUE]:

    def __init__(self) -> None:
        self._consumer_cmd: Callable[[VALUE], Any | None] = None
        self._action_on_init: Callable[[EventListener], Any | None] = None
        self._action_on_finish: Callable[[EventListener], Any | None] = None
        self._name = None
        
    def __repr__(self) -> str:
        if self.get_name() is None:
            return f"<EventListener()>"
        return f"<EventListener()> {self.get_name()}"
    
    def set_action_on_init(self, action: Callable[[EventListener], Any | None]):
        self._action_on_init = action
    
    def set_action_on_finish(self, action: Callable[[EventListener], Any | None]):
        self._action_on_finish = action
        
    def get_name(self) -> str | None:
        return self._name
    
    def set_name(self, name: str):
        self._name = name

    def get_consumer_command(self) -> Callable[[VALUE], Any | None] | None:
        return self._consumer_cmd

    def set_consumer_command(self, consumer: Callable[[VALUE], Any | None]) -> None:
        self._consumer_cmd = consumer
        
    def on_init_event(self) -> Any | None:
        if self._action_on_init is None:
            return None
        return self._action_on_init(self)
    
    def on_finish_event(self) -> Any | None:
        if self._action_on_finish is None:
            return None
        return self._action_on_finish(self)

    def receiver_notify(self, event: VALUE) -> None:
        if self.get_consumer_command() is not None:
            self.get_consumer_command()(event) # type: ignore


class EventProvider[VALUE]:

    def __init__(self) -> None:
        self._listeners: ArrayList[EventListener] = ArrayList()
        self.action_other_event: Callable[[Any], Any | None] = None
        self._value: VALUE = None
        self._name: str | None = None
        
    def get_name(self) -> str | None:
        return self._name
    
    def set_name(self, name):
        self._name = name

    def get_value(self) -> VALUE | None:
        return self._value

    def set_value(self, value: VALUE) -> None:
        self._value = value

    def add_listener(self, listener: EventListener[VALUE]) -> None:
        self._listeners.append(listener)

    def clear_listeners(self) -> None:
        self._listeners.clear()

    def remove_listener(self, listener: EventListener[VALUE]) -> None:
        self._listeners.remove(listener)
        
    def notify_init_event(self) -> None:
        listener: EventListener[VALUE]
        for listener in self._listeners:
            listener.on_init_event()
    
    def notify_finish_event(self) -> None:
        listener: EventListener[VALUE]
        for listener in self._listeners:
            listener.on_finish_event()
            
    def other_event(self, **kwargs):
        if self.action_other_event is not None:
            self.action_other_event(kwargs)

    def notify_listeners(self) -> None:
        listener: EventListener[VALUE]
        for listener in self._listeners:
            listener.receiver_notify(self.get_value())
            
             
       

