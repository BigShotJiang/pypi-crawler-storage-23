class CoreException(Exception):

    def __init__(self, message: str = f'Erro') -> None:
        super().__init__(message)
        self._message = message

    def get_message(self) -> str:
        return self._message

    def set_message(self, message: str) -> None:
        self._message = message
        super().__init__(f"{__class__.__name__}: {message}")

    def launch_exception_handler(self) -> None:
        raise self


#============================================================#
# Erros relacionados a HashMap
#============================================================#
class InvalidHashMapTableError(CoreException):

    def __init__(self, message: str = 'HashMap inválido') -> None:
        super().__init__(message)


class InvalidBodyTableError(InvalidHashMapTableError):

    def __init__(self, message: str = 'Erro corpo de tabela inválido') -> None:
        super().__init__(message)


class SizeTableError(InvalidHashMapTableError):

    def __init__(self, message: str = 'Tamanho de tabela inválido') -> None:
        super().__init__(message)


#============================================================#
# Erros relacionados a planilhas
#============================================================#
class UndefinedSheetIndex(CoreException):

    def __init__(self, message: str = 'SheetIndexNames não foi definido') -> None:
        super().__init__(message)


class LoadWorkbookError(CoreException):

    def __init__(self, message: str = 'Erro ao tentar ler Workbook') -> None:
        super().__init__(message)

#============================================================#
# Erros relacionados a arquivos/bytes de imagem (.png, .jpg, ...)
#============================================================#
class InvalidSourceImageError(CoreException):

    def __init__(self, message: str = 'Erro, use bytes de imagem') -> None:
        super().__init__(message)


#============================================================#
# Erros relacionados a módulos
#============================================================#
class NotImplementedModuleError(CoreException):

    def __init__(self, message: str = 'Erro, módulo não implementado') -> None:
        super().__init__(message)


class NotImplementedModuleImageError(NotImplementedModuleError):

    def __init__(self, message: str = 'Erro, módulo IMAGEM não implementado') -> None:
        super().__init__(message)


class NotImplementedModulePdfError(NotImplementedModuleError):

    def __init__(self, message: str = 'Erro, módulo PDF não implementado') -> None:
        super().__init__(message)


class NotImplementedInvertColor(NotImplementedError):

    def __init__(self, message: str = 'Adaptador InvertColor não implementado...') -> None:
        super().__init__(message)




