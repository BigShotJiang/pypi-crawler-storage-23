from __future__ import annotations
import os
from abc import ABCMeta, abstractmethod
from typing import Literal
from io import BytesIO
from table_stream.types.workbook import  WorkbookData
from table_stream.base.hash_map import ArrayList
from pandas import DataFrame


sheetExtension = Literal['.csv', '.xlsx', '.ods']


class InterfaceSheetLoad(metaclass=ABCMeta):

    def check_file(self):
        if self.get_file_sheet() is None:
            raise FileNotFoundError()
        if isinstance(self.get_file_sheet(), str):
            if not os.path.exists(self.get_file_sheet()):
                raise FileNotFoundError()

    @abstractmethod
    def get_type_load(self) -> sheetExtension:
        pass

    @abstractmethod
    def set_file_sheet(self, f: str | BytesIO) -> None:
        pass

    @abstractmethod
    def get_file_sheet(self) -> str | BytesIO:
        pass

    @abstractmethod
    def hash(self) -> int:
        pass

    @abstractmethod
    def get_workbook_data(self, sheet_name: str = None) -> WorkbookData:
        """
            Retorna um conjunto de chave:valor com os nomes de cada ABA da planilha
        apontando para o DataFrame() correspondente.
        """
        pass

    @abstractmethod
    def get_sheet_names(self) -> ArrayList[str]:
        pass

    def get_sheet_at(self, idx: int) -> DataFrame:
        sheet_name = self.get_sheet_names()[idx]
        return self.get_sheet(sheet_name)

    def get_sheet(self, sheet_name: str) -> DataFrame:
        return self.get_workbook_data(sheet_name).get_first()


__all__ = ['InterfaceSheetLoad', 'sheetExtension']




