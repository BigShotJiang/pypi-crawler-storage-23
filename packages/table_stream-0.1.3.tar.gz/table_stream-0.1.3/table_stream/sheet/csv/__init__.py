from __future__ import annotations
from io import BytesIO
import pandas as pd
from typing import Literal, Union, TypedDict

from table_stream import ArrayList
from table_stream.erros import LoadWorkbookError
from table_stream.types.workbook import WorkbookData
from table_stream.sheet.interface import InterfaceSheetLoad

csvEncoding = Literal['utf-8', 'iso-8859-1', 'latin1', 'cp1252']
CsvEncodingList: list[str] = ['utf-8', 'iso-8859-1', 'latin1',  'cp1252']  # ["utf-8", "latin1", "cp1252"]
csvSeparator = Literal[',', ';', '|', '\t', '_', ' ']
CsvSeparatorList: list[str] = [';', ',', '|', '\t', '_', ' ']  # [";", ",", "\\t", "|", "-"]


class CsvMapping(TypedDict, total=True):

    encoding: csvEncoding
    separator: csvSeparator
    virgula: csvSeparator
    ponto_virgula: csvSeparator
    pipe: csvSeparator
    tab: csvSeparator
    esp: csvSeparator
    under: csvSeparator


def create_csv_mapping() -> CsvMapping:

    return {
        'encoding': 'utf-8',
        'separator': ';',
        'virgula': ',',
        'ponto_virgula': ';',
        'pipe': '|',
        'tab': '\t',
        'esp': ' ',
        'under': '_',
    }


class CsvLoadPandasInterface(InterfaceSheetLoad):
    """Leitura de CSV usando a biblioteca Pandas."""

    def __init__(
                self,
                file_csv: Union[str, BytesIO] | None,
                delimiter: csvSeparator = "\t",
                encoding: csvEncoding = 'utf-8'
            ):
        super().__init__()
        self._file_csv: Union[str, BytesIO] | None = file_csv
        self.delimiter: csvSeparator = delimiter
        self.encoding: csvEncoding = encoding

    def get_sheet_names(self) -> ArrayList[str]:
        return ArrayList(["Sheet1"])

    def _check_file_csv(self):
        self.check_file()

    def set_file_sheet(self, f: str | BytesIO) -> None:
        self._file_csv = f

    def get_file_sheet(self) -> str | BytesIO:
        return self._file_csv

    def hash(self) -> int:
        self._check_file_csv()
        return hash(self._file_csv)

    def get_workbook_data(self, sheet_name: str = None) -> WorkbookData:
        self._check_file_csv()
        df: pd.DataFrame
        workbook_data = WorkbookData()
        try:
            # Forçar a leitura como str.
            workbook_data.set_value(
                "Sheet1",
                pd.read_csv(self._file_csv, sep=self.delimiter, encoding=self.encoding, dtype=str).fillna('')
            )
        except Exception as e:
            raise LoadWorkbookError(f"{__class__.__name__} Error: {e}")
        else:
            return workbook_data

    def get_type_load(self) -> Literal[".csv"]:
        return ".csv"


__all__ = [
    'csvEncoding', 'CsvMapping', 'csvSeparator', 'CsvLoadPandasInterface',
    'create_csv_mapping', 'CsvEncodingList', 'CsvSeparatorList',
]


