from __future__ import annotations
import pandas as pd
from pandas import DataFrame
from soup_files import Directory
from table_stream.types.pattner import AbstractProvider, EVENT_TYPE, MessageNotification, AbstractListener
from table_stream.base.hash_map import ArrayList


class FilterData(object):

    def __init__(self, col_find: str, value_find: str, *, return_cols: list[str] = None):
        self.__col_find = col_find
        self.__value_find = value_find
        if return_cols is None:
            self.__return_cols = []
        else:
            self.__return_cols = return_cols

    def get_col_find(self) -> str:
        return self.__col_find

    def get_value_find(self) -> str:
        return self.__value_find

    def get_return_cols(self) -> list[str]:
        return self.__return_cols

    def set_return_cols(self, return_cols: list[str]):
        self.__return_cols = return_cols


class SearchInData(object):

    def __init__(self, filter_data: FilterData):
        self.__filter_data: FilterData = filter_data

    def get_filter_data(self) -> FilterData:
        return self.__filter_data

    def filter_items(self, data: pd.DataFrame) -> pd.DataFrame[str]:
        _col_find = self.get_filter_data().get_col_find()
        _value_find = self.get_filter_data().get_value_find()
        final = data[data[_col_find] == _value_find].astype('str')

        if len(self.get_filter_data().get_return_cols()) > 0:
            _select = self.get_filter_data().get_return_cols()
            idx: int = final.columns.tolist().index(_col_find)
            _select.insert(idx, _col_find)
            final = final[_select]
        return final.astype('str')


class ParserData(AbstractProvider[DataFrame]):

    def __init__(self, data: pd.DataFrame):
        super().__init__()
        self.__data: pd.DataFrame = data.astype(str)
        self._msg = MessageNotification[str, DataFrame]('dataframe', provider=self)

    def __repr__(self):
        return f"<{__class__.__name__}()>"

    def get_message(self) -> MessageNotification:
        return self._msg

    def set_message(self, message: MessageNotification, notify: bool = False):
        self._msg = message
        if notify:
            self.notify_listeners()

    def set_message_event(self, event: EVENT_TYPE):
        self._msg.set_event_type(event)

    def notify_listeners(self):
        o: AbstractListener
        for o in self.get_listeners():
            o.receiver_notify(self.get_message())

    def get_data(self) -> pd.DataFrame:
        return self.__data

    def remove_na(self, col: str) -> None:
        """
            Remover valores nan de uma coluna.
        :param col: coluna do DataFrame()
        :return: None
        """
        self.__data = self.__data.dropna(subset=[col]).astype('str')
        self._msg.set_value_notify(self.__data)
        self.notify_listeners()

    def remove_null(self, col: str) -> None:
        """
            Remove valores nan e em seguida limpa valores vazios da coluna.
        :param col: Coluna do DataFrame()
        :return: None
        """
        self.remove_na(col)
        self.__data = self.__data[self.__data[col] != ""].astype('str')
        self._msg.set_value_notify(self.__data)
        self.notify_listeners()

    def delete_columns(self, columns: list[str]) -> None:
        if self.get_data().empty:
            raise Exception(f"{self} No data available")

        # valida se todas as colunas existem
        missing: list[str] = [col for col in columns if col not in self.__data.columns]
        if missing:
            raise KeyError(
                f"{__class__.__name__} Columns not found: {missing}"
            )
        # remove as colunas
        self.__data = self.__data.drop(columns=columns).astype("str")
        # atualiza mensagem e notifica
        self._msg.set_value_notify(self.__data)
        self.notify_listeners()

    def get_columns(self) -> ArrayList[str]:
        if self.get_data().empty:
            raise Exception(f"{self} No data available")
        return ArrayList(self.__data.astype('str').columns.tolist())

    def select_columns(self, columns: list[str]) -> ParserData:
        if self.get_data().empty:
            raise Exception(f"{__class__.__name__} No data available")
        return ParserData(self.__data[columns])

    def concat_columns(
                self,
                columns: list[str], *,
                conc_name: str = 'concatenar',
                sep: str = '_'
            ):
        if self.get_data().empty:
            raise Exception(f"{__class__.__name__} No data available")
        self.__data[conc_name] = self.__data[columns].agg(sep.join, axis=1)
        self._msg.set_value_notify(self.__data)
        self.notify_listeners()

    def _get_uniq_values_column(self, col_split) -> list[str]:
        return self.__data[col_split].drop_duplicates().astype('str').values.tolist()

    def split_to_disk(
                self,
                output_path: str | Directory, *,
                col_split: str,
                extension: str = "xlsx",
                prefix: str = None
            ) -> None:
        if isinstance(output_path, str):
            output_path: Directory = Directory(output_path)

        list_items: list[str] = self._get_uniq_values_column(col_split)
        list_items.sort()
        element: str
        current: pd.DataFrame
        for num, element in enumerate(list_items):
            current = self.__data[self.__data[col_split] == element]
            filename = f"{element}.{extension}"
            if prefix is not None:
                filename = f'{prefix}-{filename}'
            file_path = output_path.join_file(filename)
            try:
                print(f'Exportando: {file_path.basename()}')
                if extension == 'xlsx':
                    current.to_excel(file_path.absolute(), index=False)
                elif extension == 'csv':
                    current.to_csv(file_path.absolute(), index=False, sep='\t', encoding='utf-8')
            except Exception as e:
                print(f'{self} {e}')

    def split_to_tuple(self, col_split) -> list[pd.DataFrame]:
        set_items: list[str] = self._get_uniq_values_column(col_split)
        values: list[pd.DataFrame] = list()
        for element in set_items:
            current = self.__data[self.__data[col_split] == element]
            values.append(current)
        return values


__all__ = ['ParserData', 'FilterData']

