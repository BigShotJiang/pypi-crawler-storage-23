from __future__ import annotations
from typing import Union
from io import BytesIO
from pandas import DataFrame
from table_stream.types.workbook import WorkbookData
from table_stream.base.hash_map import ArrayList
from table_stream.types.pattner import ObjectAdapter, ADAPTATIVE
from table_stream.sheet.interface import InterfaceSheetLoad, sheetExtension
from table_stream.sheet.csv import CsvLoadPandasInterface, csvSeparator, csvEncoding
from table_stream.sheet.excel import ExcelLoadPandasInterface
from table_stream.sheet.ods import ODSLoadPandasInterface


class SheetLoader[IMPLEMENTATION](ObjectAdapter):

    def __init__(self, implementation: IMPLEMENTATION):
        super().__init__(implementation)

    def get_type_load(self) -> sheetExtension:
        return self.get_implementation().get_type_load()

    def get_adaptative(self) -> ADAPTATIVE:
        raise NotImplementedError()

    def get_implementation(self) -> InterfaceSheetLoad:
        return self._implementation

    def set_file_sheet(self, f: Union[str | BytesIO]) -> None:
        self._implementation.set_file_sheet(f)

    def get_file_sheet(self) -> Union[str | BytesIO] | None:
        return self._implementation.get_file_sheet()

    def hash(self) -> int:
        return self._implementation.hash()

    def get_workbook_data(self, sheet_name: str = None) -> WorkbookData:
        return self._implementation.get_workbook_data(sheet_name)

    def get_sheet_names(self) -> ArrayList[str]:
        return self._implementation.get_sheet_names()

    def get_sheet_at(self, idx: int) -> DataFrame:
        return self._implementation.get_sheet_at(idx)

    def get_sheet(self, sheet_name: str) -> DataFrame:
        return self._implementation.get_sheet(sheet_name)

    @classmethod
    def create_load_csv(
            cls, file_csv: Union[str | BytesIO] | None, *,
            delimiter: csvSeparator = '\t',
            encoding: csvEncoding = 'utf-8'
    ) -> SheetLoader:
        return cls(CsvLoadPandasInterface(file_csv, delimiter, encoding))

    @classmethod
    def create_load_excel(cls, file_excel: Union[str, BytesIO] | None) -> SheetLoader:
        return cls(ExcelLoadPandasInterface(file_excel))

    @classmethod
    def create_load_ods(cls, ods_file: Union[str, BytesIO] | None) -> SheetLoader:
        return cls(ODSLoadPandasInterface(ods_file))

