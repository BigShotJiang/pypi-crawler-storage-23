from __future__ import annotations
from io import BytesIO
import pandas as pd
from typing import Union, Literal
from table_stream import ArrayList
from table_stream.types import WorkbookData
from table_stream.sheet.interface import InterfaceSheetLoad


# ------------------------------------------------------#
# IMPLEMENTAÇÃO COM PANDAS
# ------------------------------------------------------#
class ODSLoadPandasInterface(InterfaceSheetLoad):
    """Carregador ODS utilizando a biblioteca Pandas."""

    def __init__(self, ods_file: Union[str, BytesIO] | None):
        self._ods_file: Union[str, BytesIO] | None = ods_file

    def get_type_load(self) -> Literal[".ods"]:
        return ".ods"

    def get_sheet_names(self) -> ArrayList[str]:
        self._check_file()
        rd: pd.ExcelFile = pd.ExcelFile(self.get_file_sheet())
        return ArrayList([str(x) for x in rd.sheet_names])

    def _check_file(self) -> None:
        self.check_file()

    def set_file_sheet(self, f: Union[str, BytesIO]) -> None:
        self._ods_file = f

    def get_file_sheet(self) -> Union[str, BytesIO] | None:
        return self._ods_file

    def hash(self) -> int:
        self._check_file()
        return hash(self._ods_file)

    def get_workbook_data(self, sheet_name: str = None) -> WorkbookData:
        if sheet_name is None:
            return WorkbookData(pd.read_excel(self.get_file_sheet(), sheet_name=None, engine='odf'))
        return WorkbookData({
            sheet_name: pd.read_excel(self.get_file_sheet(), sheet_name=sheet_name, engine='odf'),
        })


__all__ = ['ODSLoadPandasInterface']
