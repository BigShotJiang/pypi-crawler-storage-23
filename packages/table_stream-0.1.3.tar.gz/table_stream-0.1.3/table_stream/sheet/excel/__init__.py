from __future__ import annotations
from io import BytesIO
from typing import Union, Literal
import pandas as pd
from table_stream.base.hash_map import ArrayList
from table_stream.types.workbook import WorkbookData
from table_stream.sheet.interface import InterfaceSheetLoad


class ExcelLoadPandasInterface(InterfaceSheetLoad):

    def __init__(self, xlsx_file: Union[str, BytesIO] | None):
        self._xlsx_file: Union[str, BytesIO] | None = xlsx_file

    def get_sheet_names(self) -> ArrayList[str]:
        self._check_file()
        rd: pd.ExcelFile = pd.ExcelFile(self._xlsx_file)
        return ArrayList([str(x) for x in rd.sheet_names])

    def _check_file(self) -> None:
        self.check_file()

    def set_file_sheet(self, f: str | BytesIO) -> None:
        self._xlsx_file = f

    def get_file_sheet(self) -> str | BytesIO:
        return self._xlsx_file

    def hash(self) -> int:
        self.check_file()
        return hash(self.get_file_sheet())

    def get_workbook_data(self, sheet_name: str = None) -> WorkbookData:
        if sheet_name is None:
            return WorkbookData(pd.read_excel(self.get_file_sheet(), sheet_name=None))
        return WorkbookData({
            sheet_name: pd.read_excel(self.get_file_sheet(), sheet_name=sheet_name),
        })

    def get_type_load(self) -> Literal[".xlsx"]:
        return ".xlsx"


__all__ = ['ExcelLoadPandasInterface']

