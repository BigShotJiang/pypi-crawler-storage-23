# License

This project is licensed under the MIT License.

See the full text in the repository root `LICENSE` file.
