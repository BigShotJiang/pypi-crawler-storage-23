# Audit Completeness — Actual Results

> **Warning:** Real data is included from `_generated/audit/`, not stored in the repo.

## Summary Statistics

```{include} ../_generated/audit/summary_stats.md
```

## Missing File Analysis

```{include} ../_generated/audit/missing_file_analysis.md
```
