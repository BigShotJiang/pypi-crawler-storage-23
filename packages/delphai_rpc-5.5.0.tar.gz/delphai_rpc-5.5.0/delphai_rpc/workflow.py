import asyncio
import functools
import inspect
import logging
import time
from collections.abc import Callable, Iterable, Mapping, Sequence
from typing import Any

import pydantic

from . import errors, metrics, utils
from .models import BaseModel, Request, Response, Result, RpcCall
from .queue_client import QueueClient

logger = logging.getLogger(__name__)


RPC_CALL_MAX_DEPTH = 2

RpcCallNested = (
    RpcCall | tuple[RpcCall | Any, ...] | list[RpcCall | Any] | dict[Any, RpcCall | Any]
)

RpcCallPath = tuple[Any, ...]


class Context(BaseModel):
    handler_name: str
    rpc_call_path: RpcCallPath
    args: tuple[RpcCallNested | Any, ...]
    kwargs: dict[str, RpcCallNested | Any]


class RpcWorkflow:
    def __init__(self, queue_client: QueueClient) -> None:
        self._queue_client = queue_client
        self._queue_name = f"workflow.{self._queue_client.service_name}"

        self._prefetch_count = 1
        self._started = False

        self._handlers: dict[str, tuple[inspect.Signature, Callable]] = {}

    def set_prefetch_count(self, prefetch_count: int) -> None:
        if self._started:
            raise RuntimeError(
                "Prefetch count must be configured before workflow start"
            )

        self._prefetch_count = prefetch_count

    async def start(self) -> None:
        if not self._handlers:
            return

        if self._started:
            raise RuntimeError("Workflow has been already started")

        await self._queue_client.declare_consume_named_queue(
            queue_name=self._queue_name,
            handler=self._on_message,
            prefetch_count=self._prefetch_count,
        )

        logger.info("RPC workflow is consuming messages from `%s`", self._queue_name)
        self._started = True

    def step(
        self,
        handler: Callable | None = None,
        *,
        name: str | None = None,
    ) -> Callable:
        def decorator(handler: Callable) -> Callable:
            handler_name = self._register_handler(handler=handler, name=name)

            @functools.wraps(handler)
            async def wrapper(*args: Any, **kwargs: Any) -> Any:
                return await self._resolve_or_call(handler_name, args, kwargs)

            return wrapper

        if handler:
            return decorator(handler)

        return decorator

    def _register_handler(self, *, handler: Callable, name: str | None = None) -> str:
        handler_name = name or f"{handler.__module__}.{handler.__qualname__}"
        if handler_name in self._handlers:
            raise ValueError(f"Handler {handler_name} is already defined")

        utils.assert_handler_is_coroutine(handler)

        signature = inspect.signature(handler)

        handler = pydantic.validate_call(
            validate_return=True,
            config=pydantic.ConfigDict(arbitrary_types_allowed=True),
        )(handler)

        self._handlers[handler_name] = signature, handler

        return handler_name

    async def _resolve_or_call(
        self,
        handler_name: str,
        args: tuple[RpcCallNested | Any, ...],
        kwargs: dict[str, RpcCallNested | Any],
        timings: list[tuple[str, float]] | None = None,
    ) -> Any:
        if handler_name not in self._handlers:
            raise errors.UnknownMethodError(handler_name)

        signature, handler = self._handlers[handler_name]
        signature.bind(*args, **kwargs)

        found_unresolved_rpc_call = self._find_unresolved_rpc_call(args, ("args",))
        if not found_unresolved_rpc_call:
            found_unresolved_rpc_call = self._find_unresolved_rpc_call(
                kwargs, ("kwargs",)
            )

        if not found_unresolved_rpc_call:
            with metrics.workflow_handler_calls_in_progress.labels(
                handler=handler_name,
            ).track_inprogress():
                elapsed = -time.perf_counter()
                error: Exception | None = None

                try:
                    result = await handler(*args, **kwargs)
                except Exception:
                    logger.exception("Error in step `%s`", handler_name)

                    # We don't explicitly propagate a pure Exception,
                    # since it would be treated as unexpected behavior above.
                    # Also, to decrease metrics cardinality.
                    error = errors.ExecutionError()
                    raise error
                finally:
                    elapsed += time.perf_counter()
                    metrics.workflow_handler_call_processed(
                        handler=handler_name,
                        elapsed=elapsed,
                        error=error,
                    )

            return result

        next_unresolved_rpc_call, next_unresolved_rpc_call_path = (
            found_unresolved_rpc_call
        )

        next_unresolved_rpc_call_arguments = next_unresolved_rpc_call.arguments
        next_unresolved_rpc_call.arguments = {}

        context_bytes = await asyncio.to_thread(
            Context(
                rpc_call_path=next_unresolved_rpc_call_path,
                handler_name=handler_name,
                args=args,
                kwargs=kwargs,
            ).model_dump_msgpack
        )
        if len(context_bytes) > utils.COMPRESS_MIN_SIZE:
            context_bytes, _ = await asyncio.to_thread(
                utils.compress,
                context_bytes,
                encoding="zstd",
            )

        request = Request(
            method_name=next_unresolved_rpc_call.method_name,
            arguments=next_unresolved_rpc_call_arguments,
            context=context_bytes,
            timings=timings or [],
        )
        del context_bytes

        await self._queue_client.send(
            **(await asyncio.to_thread(request.model_dump_message)),
            exchange_name=f"service.{next_unresolved_rpc_call.service_name}",
            routing_key=f"method.{next_unresolved_rpc_call.method_name}",
            reply_to=self._queue_name,
            priority=next_unresolved_rpc_call.options.priority,
            timeout=None,
        )

        metrics.workflow_rpc_calls_sent_count.labels(
            service=next_unresolved_rpc_call.service_name,
            method=next_unresolved_rpc_call.method_name,
            handler=handler_name,
            priority=next_unresolved_rpc_call.options.priority,
        ).inc()

        return ...

    async def _on_message(
        self,
        body: bytes,
        content_type: str,
        message_type: str,
        message_id: str,
        priority: int,
        published_timestamp: float | None = None,
        **_: Any,
    ) -> Any:
        consumed_timestamp = time.time()

        response = await asyncio.to_thread(
            Response.model_validate_message,
            body=body,
            content_type=content_type,
            message_type=message_type,
        )
        if not response.context:
            logger.warning("[MID:%s] Message has empty context", message_id)
            return None

        encoding = utils.get_encoding(response.context)
        if encoding:
            try:
                context_bytes = await asyncio.to_thread(
                    utils.decompress,
                    response.context,
                    encoding=encoding,
                )
            except Exception as error:
                raise errors.BadMessageError(f"Decompression failed: `{error!r}`")
        else:
            context_bytes = response.context

        context = await asyncio.to_thread(
            Context.model_validate_msgpack,
            context_bytes,
        )
        del context_bytes

        rpc_call = self._get_rpc_call_by_path(
            path=context.rpc_call_path,
            args=context.args,
            kwargs=context.kwargs,
        )

        rpc_call.result = Result(
            result=response.result,
            error=response.error,
        )

        timings = response.timings
        queued_for = None
        if published_timestamp is not None:
            queued_for = consumed_timestamp - published_timestamp

        timings.append(
            (
                f"queue.consumed.workflow by {self._queue_client.app_id}",
                consumed_timestamp,
            ),
        )

        logger.info(
            "[MID:%s] Resolved %r %s for %s. In queue: %ims, success: %s%s",
            message_id,
            context.rpc_call_path,
            rpc_call,
            context.handler_name,
            (None if queued_for is None else max(queued_for * 1000, 0)),
            response.error is None,
            f", error: {response.error.message}" if response.error else "",
        )

        metrics.workflow_rpc_call_resolved(
            service=rpc_call.service_name,
            method=rpc_call.method_name,
            handler=context.handler_name,
            priority=priority,
            queued_for=queued_for or 0,
            error=response.error,
        )

        return await self._resolve_or_call(
            context.handler_name,
            context.args,
            context.kwargs,
            timings=timings,
        )

    @staticmethod
    def _find_unresolved_rpc_call(
        value: Any,
        path: RpcCallPath,
        depth: int = 0,
    ) -> tuple[RpcCall, RpcCallPath] | None:
        if depth > RPC_CALL_MAX_DEPTH:
            return None

        if isinstance(value, RpcCall) and not value.is_done:
            return value, path

        items: Iterable
        if isinstance(value, Mapping):
            items = value.items()
        elif isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
            items = enumerate(value)
        else:
            return None

        for key, item in items:
            result = RpcWorkflow._find_unresolved_rpc_call(
                item, (*path, key), depth + 1
            )
            if result:
                return result

        return None

    @staticmethod
    def _get_rpc_call_by_path(
        path: RpcCallPath,
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> RpcCall:
        arg_type, *arg_path = path

        current_object: Any = args if arg_type == "args" else kwargs
        for key in arg_path:
            current_object = current_object[key]

        if not isinstance(current_object, RpcCall):
            raise TypeError(
                "Cannot find `RpcCall`, "
                f"path `{path}`, args `{args}`, kwargs `{kwargs}`"
            )

        return current_object
