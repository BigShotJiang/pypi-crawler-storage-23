# mini_siem/__init__.py
__version__ = "1.0.0"
__author__  = "Jyoti Kuaner"