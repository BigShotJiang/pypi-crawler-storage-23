r'''
# dynamodb-zero-etl-s3tables

[![npm version](https://badge.fury.io/js/dynamodb-zero-etl-s3tables.svg)](https://www.npmjs.com/package/dynamodb-zero-etl-s3tables)
[![PyPI version](https://badge.fury.io/py/dynamodb-zero-etl-s3tables.svg)](https://pypi.org/project/dynamodb-zero-etl-s3tables/)
[![NuGet version](https://img.shields.io/nuget/v/LeeroyHannigan.CDK.DynamoDbZeroEtlS3Tables.svg)](https://www.nuget.org/packages/LeeroyHannigan.CDK.DynamoDbZeroEtlS3Tables/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![jsii](https://img.shields.io/badge/jsii-compatible-brightgreen.svg)](https://github.com/aws/jsii)
[![stability: experimental](https://img.shields.io/badge/stability-experimental-orange.svg)](https://www.npmjs.com/package/dynamodb-zero-etl-s3tables)

An AWS CDK L3 construct that wires up a complete **zero-ETL integration** from **Amazon DynamoDB** to **Amazon S3 Tables** (Apache Iceberg) — in a single line of code.

> **Zero-ETL** eliminates the need to build and maintain ETL pipelines. Data flows automatically from your DynamoDB table into Iceberg tables on S3, ready for analytics with Athena, Redshift, EMR, and more.

## Why this construct?

Setting up DynamoDB zero-ETL to S3 Tables manually requires **7+ resources** across DynamoDB, S3 Tables, IAM, Glue, and custom resources — each with specific permissions, dependencies, and ordering constraints. One misconfigured policy and the integration silently fails.

This construct handles all of that for you:

```
┌──────────────┐         ┌──────────────────┐         ┌─────────────────┐
│              │         │                  │         │                 │
│   DynamoDB   │────────▶│  AWS Glue        │────────▶│  S3 Tables      │
│   Table      │  zero   │  Integration     │  write  │  (Iceberg)      │
│              │  ETL    │                  │         │                 │
└──────────────┘         └──────────────────┘         └─────────────────┘
       │                        │                            │
       ▼                        ▼                            ▼
  Resource Policy          Catalog Policy              Table Bucket
  (Glue export)            (Custom Resource)           IAM Target Role
```

**What gets created:**

| Resource | Purpose |
|----------|---------|
| `AWS::S3Tables::TableBucket` | Iceberg-native storage for your analytics data |
| `AWS::IAM::Role` | Least-privilege role for Glue to write to S3 Tables and catalog |
| `AWS::Glue::Integration` | The zero-ETL integration connecting source to target |
| `AWS::Glue::IntegrationResourceProperty` | Wires the target IAM role to the integration |
| `Custom::AWS` (AwsCustomResource) | Sets the Glue Data Catalog resource policy (no CloudFormation support) |
| DynamoDB Resource Policy | Allows Glue to export and describe the source table |

## Installation

**TypeScript/JavaScript:**

```bash
npm install dynamodb-zero-etl-s3tables
```

**Python:**

```bash
pip install dynamodb-zero-etl-s3tables
```

**Java (Maven):**

```xml
<dependency>
    <groupId>io.github.leeroyhannigan</groupId>
    <artifactId>dynamodb-zero-etl-s3tables</artifactId>
</dependency>
```

**.NET:**

```bash
dotnet add package LeeroyHannigan.CDK.DynamoDbZeroEtlS3Tables
```

## Quick Start

```python
import { DynamoDbZeroEtlToS3Tables } from 'dynamodb-zero-etl-s3tables';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';

const table = new dynamodb.Table(this, 'Table', {
  tableName: 'Orders',
  partitionKey: { name: 'PK', type: dynamodb.AttributeType.STRING },
  sortKey: { name: 'SK', type: dynamodb.AttributeType.STRING },
  billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
  pointInTimeRecovery: true,
});

new DynamoDbZeroEtlToS3Tables(this, 'ZeroEtl', {
  table,
  tableBucketName: 'orders-iceberg-bucket',
});
```

That's it. Your DynamoDB data will automatically replicate to Iceberg tables on S3.

## Props

| Property | Type | Required | Default | Description |
|----------|------|----------|---------|-------------|
| `table` | `dynamodb.Table` | Yes | — | DynamoDB table with an explicit `tableName` and PITR enabled |
| `tableBucketName` | `string` | Yes | — | Name for the S3 Table Bucket |
| `integrationName` | `string` | No | `'ddb-to-s3tables'` | Name for the Glue zero-ETL integration |

## Exposed Properties

All key resources are exposed as public properties for extension:

| Property | Type | Description |
|----------|------|-------------|
| `tableBucket` | `s3tables.CfnTableBucket` | The S3 Table Bucket for Iceberg storage |
| `targetRole` | `iam.Role` | The IAM role Glue uses to write to the target |
| `integration` | `glue.CfnIntegration` | The Glue zero-ETL integration |

## Customization Examples

### Add custom permissions to the target role

```python
const zeroEtl = new DynamoDbZeroEtlToS3Tables(this, 'ZeroEtl', {
  table,
  tableBucketName: 'my-bucket',
});

zeroEtl.targetRole.addToPolicy(new iam.PolicyStatement({
  actions: ['s3:GetObject'],
  resources: ['arn:aws:s3:::my-other-bucket/*'],
}));
```

### Configure Iceberg file maintenance

```python
zeroEtl.tableBucket.unreferencedFileRemoval = {
  status: 'Enabled',
  unreferencedDays: 10,
  noncurrentDays: 30,
};
```

### Tag the integration

```python
zeroEtl.integration.tags = [
  { key: 'Environment', value: 'production' },
  { key: 'Team', value: 'analytics' },
];
```

## Prerequisites

Your DynamoDB table **must** have:

1. **An explicit `tableName`** — auto-generated names (CloudFormation tokens) are not supported. The construct validates this at synth time.
2. **Point-in-time recovery (PITR) enabled** — required by the zero-ETL integration for data export. The construct validates this at synth time.

If either requirement is not met, the construct throws a descriptive error during synthesis.

## How It Works

1. **S3 Table Bucket** is created as the Iceberg-native target for your data
2. **IAM Role** is created with least-privilege permissions for S3 Tables, Glue Catalog, CloudWatch, and Logs
3. **DynamoDB Resource Policy** is set on your table, allowing the Glue service to export data
4. **Glue Catalog Resource Policy** is applied via a custom resource (CloudFormation doesn't support this natively)
5. **Integration Resource Property** wires the IAM role to the target catalog
6. **Glue Integration** is created, connecting your DynamoDB table to the S3 Tables catalog

All resources are created with correct dependency ordering to ensure a successful single-deploy experience.

## Querying Your Data

Once the integration is active, your DynamoDB data is available as Iceberg tables. Query with Amazon Athena:

```sql
SELECT * FROM "s3tablescatalog/my-bucket"."namespace"."table_name" LIMIT 10;
```

## Security

* All IAM permissions follow **least-privilege** principles
* S3 Tables permissions are scoped to the specific bucket and sub-resources
* Glue catalog permissions are scoped to the account's catalog and databases
* DynamoDB resource policy uses `aws:SourceAccount` and `aws:SourceArn` conditions
* CloudWatch metrics are conditioned on the `AWS/Glue/ZeroETL` namespace

## Contributing

Contributions, issues, and feature requests are welcome!

* [GitHub Repository](https://github.com/LeeroyHannigan/dynamodb-zero-etl-s3tables)
* [Issue Tracker](https://github.com/LeeroyHannigan/dynamodb-zero-etl-s3tables/issues)

## License

This project is licensed under the [MIT License](https://opensource.org/licenses/MIT).

## Author

**Lee Hannigan** — [GitHub](https://github.com/LeeroyHannigan)
'''
from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ._jsii import *

import aws_cdk.aws_dynamodb as _aws_cdk_aws_dynamodb_ceddda9d
import aws_cdk.aws_glue as _aws_cdk_aws_glue_ceddda9d
import aws_cdk.aws_iam as _aws_cdk_aws_iam_ceddda9d
import aws_cdk.aws_s3tables as _aws_cdk_aws_s3tables_ceddda9d
import constructs as _constructs_77d1e7e8


class DynamoDbZeroEtlToS3Tables(
    _constructs_77d1e7e8.Construct,
    metaclass=jsii.JSIIMeta,
    jsii_type="dynamodb-zero-etl-s3tables.DynamoDbZeroEtlToS3Tables",
):
    '''(experimental) An L3 construct that creates a complete zero-ETL integration from Amazon DynamoDB to Amazon S3 Tables (Apache Iceberg).

    This construct provisions:

    - An S3 Table Bucket for Iceberg storage
    - An IAM role with least-privilege permissions for Glue
    - A DynamoDB resource policy allowing Glue to export data
    - A Glue Data Catalog resource policy (via custom resource)
    - A Glue IntegrationResourceProperty wiring the target role
    - A Glue CfnIntegration connecting source to target

    :stability: experimental
    '''

    def __init__(
        self,
        scope: "_constructs_77d1e7e8.Construct",
        id: builtins.str,
        *,
        table: "_aws_cdk_aws_dynamodb_ceddda9d.Table",
        table_bucket_name: builtins.str,
        integration_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''
        :param scope: -
        :param id: -
        :param table: (experimental) The DynamoDB table to use as the source. Must have an explicit tableName set and PITR enabled.
        :param table_bucket_name: (experimental) Name for the S3 Table Bucket (Iceberg-native).
        :param integration_name: (experimental) Optional name for the Glue zero-ETL integration. Default: 'ddb-to-s3tables'

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ff53c13976873faad60e29987f9063b94336200db2d6a73704bc2ac15ee76327)
            check_type(argname="argument scope", value=scope, expected_type=type_hints["scope"])
            check_type(argname="argument id", value=id, expected_type=type_hints["id"])
        props = DynamoDbZeroEtlToS3TablesProps(
            table=table,
            table_bucket_name=table_bucket_name,
            integration_name=integration_name,
        )

        jsii.create(self.__class__, self, [scope, id, props])

    @builtins.property
    @jsii.member(jsii_name="integration")
    def integration(self) -> "_aws_cdk_aws_glue_ceddda9d.CfnIntegration":
        '''(experimental) The Glue zero-ETL integration.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_glue_ceddda9d.CfnIntegration", jsii.get(self, "integration"))

    @builtins.property
    @jsii.member(jsii_name="tableBucket")
    def table_bucket(self) -> "_aws_cdk_aws_s3tables_ceddda9d.CfnTableBucket":
        '''(experimental) The S3 Table Bucket created for Iceberg storage.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_s3tables_ceddda9d.CfnTableBucket", jsii.get(self, "tableBucket"))

    @builtins.property
    @jsii.member(jsii_name="targetRole")
    def target_role(self) -> "_aws_cdk_aws_iam_ceddda9d.Role":
        '''(experimental) The IAM role used by Glue to write to the target.

        :stability: experimental
        '''
        return typing.cast("_aws_cdk_aws_iam_ceddda9d.Role", jsii.get(self, "targetRole"))


@jsii.data_type(
    jsii_type="dynamodb-zero-etl-s3tables.DynamoDbZeroEtlToS3TablesProps",
    jsii_struct_bases=[],
    name_mapping={
        "table": "table",
        "table_bucket_name": "tableBucketName",
        "integration_name": "integrationName",
    },
)
class DynamoDbZeroEtlToS3TablesProps:
    def __init__(
        self,
        *,
        table: "_aws_cdk_aws_dynamodb_ceddda9d.Table",
        table_bucket_name: builtins.str,
        integration_name: typing.Optional[builtins.str] = None,
    ) -> None:
        '''(experimental) Properties for DynamoDbZeroEtlToS3Tables.

        :param table: (experimental) The DynamoDB table to use as the source. Must have an explicit tableName set and PITR enabled.
        :param table_bucket_name: (experimental) Name for the S3 Table Bucket (Iceberg-native).
        :param integration_name: (experimental) Optional name for the Glue zero-ETL integration. Default: 'ddb-to-s3tables'

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__de9c8f294792a3de027f16d2e2d174c7fbb3fde5533d2b6670788b841e4b510d)
            check_type(argname="argument table", value=table, expected_type=type_hints["table"])
            check_type(argname="argument table_bucket_name", value=table_bucket_name, expected_type=type_hints["table_bucket_name"])
            check_type(argname="argument integration_name", value=integration_name, expected_type=type_hints["integration_name"])
        self._values: typing.Dict[builtins.str, typing.Any] = {
            "table": table,
            "table_bucket_name": table_bucket_name,
        }
        if integration_name is not None:
            self._values["integration_name"] = integration_name

    @builtins.property
    def table(self) -> "_aws_cdk_aws_dynamodb_ceddda9d.Table":
        '''(experimental) The DynamoDB table to use as the source.

        Must have an explicit tableName set and PITR enabled.

        :stability: experimental
        '''
        result = self._values.get("table")
        assert result is not None, "Required property 'table' is missing"
        return typing.cast("_aws_cdk_aws_dynamodb_ceddda9d.Table", result)

    @builtins.property
    def table_bucket_name(self) -> builtins.str:
        '''(experimental) Name for the S3 Table Bucket (Iceberg-native).

        :stability: experimental
        '''
        result = self._values.get("table_bucket_name")
        assert result is not None, "Required property 'table_bucket_name' is missing"
        return typing.cast(builtins.str, result)

    @builtins.property
    def integration_name(self) -> typing.Optional[builtins.str]:
        '''(experimental) Optional name for the Glue zero-ETL integration.

        :default: 'ddb-to-s3tables'

        :stability: experimental
        '''
        result = self._values.get("integration_name")
        return typing.cast(typing.Optional[builtins.str], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "DynamoDbZeroEtlToS3TablesProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "DynamoDbZeroEtlToS3Tables",
    "DynamoDbZeroEtlToS3TablesProps",
]

publication.publish()

def _typecheckingstub__ff53c13976873faad60e29987f9063b94336200db2d6a73704bc2ac15ee76327(
    scope: _constructs_77d1e7e8.Construct,
    id: builtins.str,
    *,
    table: _aws_cdk_aws_dynamodb_ceddda9d.Table,
    table_bucket_name: builtins.str,
    integration_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de9c8f294792a3de027f16d2e2d174c7fbb3fde5533d2b6670788b841e4b510d(
    *,
    table: _aws_cdk_aws_dynamodb_ceddda9d.Table,
    table_bucket_name: builtins.str,
    integration_name: typing.Optional[builtins.str] = None,
) -> None:
    """Type checking stubs"""
    pass
