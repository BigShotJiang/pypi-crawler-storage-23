#Project Setup Guide
This guide explains how to setup the project.You will need python 3.13 or later.
##Prerequisites

- python>=3.13
-  git
-   docker (optional)
- git
- docker (optional)

Make sure you have `uv` installed. You can install it with:
Make sure you have  `uv` installed.  You can install it with:

```
curl -LsSf https://astral.sh/uv/install.sh|sh
```

