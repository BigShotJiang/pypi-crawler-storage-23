# Changelog

## 0.0.1-alpha.0

This is the first alpha release of pydantic-explain. See the documentation for more information.

### Contributors

- [@MatthewMckee4](https://github.com/MatthewMckee4)
