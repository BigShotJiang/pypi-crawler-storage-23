"""SynAuth MCP Server — Biometric approval for AI agent actions."""

__version__ = "0.1.3"
