# 2.0

- Removed `.unit` attribute of `Quantity` objects
- Renamed `ton` to `tonne`
