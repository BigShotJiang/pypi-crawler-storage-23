from trello_mcp.server import main

main()
