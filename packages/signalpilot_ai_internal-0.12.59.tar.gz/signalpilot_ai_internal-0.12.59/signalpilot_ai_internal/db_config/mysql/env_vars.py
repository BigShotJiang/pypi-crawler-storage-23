"""MySQL environment variable builder."""

from signalpilot_ai_internal.db_config.base.env_vars import BaseEnvVarBuilder
from signalpilot_ai_internal.db_config.mysql.url_builder import MySQLURLBuilder


class MySQLEnvVarBuilder(BaseEnvVarBuilder):
    """Builds environment variables for MySQL."""

    URL_BUILDER_CLASS = MySQLURLBuilder
