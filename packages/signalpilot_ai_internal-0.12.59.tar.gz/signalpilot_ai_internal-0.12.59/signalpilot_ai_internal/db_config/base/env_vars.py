"""Base class for environment variable builders."""

import json
import re
from abc import ABC
from typing import Any, ClassVar, Dict, List, Tuple, Type

from signalpilot_ai_internal.db_config.base.url_builder import BaseURLBuilder


class BaseEnvVarBuilder(ABC):
    """Abstract base class for building database environment variables.

    Subclasses define:
        URL_BUILDER_CLASS: The URL builder class for this database type
        EXTRA_FIELDS: List of (config_key, env_suffix) tuples for db-specific fields
    """

    URL_BUILDER_CLASS: ClassVar[Type[BaseURLBuilder]]
    EXTRA_FIELDS: ClassVar[List[Tuple[str, str]]] = []

    def build_kernel_env(self, config: Dict[str, Any], prefix: str) -> Dict[str, str]:
        """Build environment variables for kernel injection."""
        env_vars = self._build_common_env(config, prefix)
        self._add_extra_fields(config, prefix, env_vars)
        self._add_connection_url(config, prefix, env_vars)
        return env_vars

    def _build_common_env(self, config: Dict[str, Any], prefix: str) -> Dict[str, str]:
        """Build common env vars shared by all database types."""
        env_vars = {}

        if config.get("host"):
            env_vars[f"{prefix}_HOST"] = str(config["host"])
        if config.get("port"):
            env_vars[f"{prefix}_PORT"] = str(config["port"])
        if config.get("database"):
            env_vars[f"{prefix}_DATABASE"] = str(config["database"])
        if config.get("username"):
            env_vars[f"{prefix}_USERNAME"] = str(config["username"])
        if config.get("password"):
            env_vars[f"{prefix}_PASSWORD"] = str(config["password"])

        env_vars[f"{prefix}_TYPE"] = config.get("type", "")
        env_vars[f"{prefix}_CONNECTION_JSON"] = json.dumps(config)

        return env_vars

    def _add_extra_fields(
        self, config: Dict[str, Any], prefix: str, env_vars: Dict[str, str]
    ) -> None:
        """Add database-specific fields from EXTRA_FIELDS."""
        for config_key, env_suffix in self.EXTRA_FIELDS:
            value = config.get(config_key)
            if value:
                env_vars[f"{prefix}_{env_suffix}"] = str(value)

    def _add_connection_url(
        self, config: Dict[str, Any], prefix: str, env_vars: Dict[str, str]
    ) -> None:
        """Add CONNECTION_URL using the URL builder."""
        try:
            url_builder = self.URL_BUILDER_CLASS()
            env_vars[f"{prefix}_CONNECTION_URL"] = url_builder.build(config)
        except ValueError:
            pass

    @staticmethod
    def normalize_name(name: str) -> str:
        """Normalize database name to env var prefix."""
        return re.sub(r"[^A-Z0-9]", "_", name.upper())
