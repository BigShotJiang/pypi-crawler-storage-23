"""Databricks URL builder."""

from typing import Any, Dict
from urllib.parse import quote

from signalpilot_ai_internal.db_config.base.url_builder import BaseURLBuilder
from signalpilot_ai_internal.db_config.databricks.auth import DatabricksTokenProvider


class DatabricksURLBuilder(BaseURLBuilder):
    """Builds Databricks SQLAlchemy connection URLs."""

    def build(self, config: Dict[str, Any]) -> str:
        """Build Databricks connection URL.

        Format: databricks://token:{token}@{host}?http_path={http_path}&catalog={catalog}
        """
        host = self._get_host(config)
        token = DatabricksTokenProvider.get_token(config)
        encoded_token = quote(token, safe="")

        query_parts = self._build_query_parts(config)
        url = f"databricks://token:{encoded_token}@{host}"

        if query_parts:
            url += f"?{'&'.join(query_parts)}"

        return url

    def _get_host(self, config: Dict[str, Any]) -> str:
        """Extract and normalize host from config."""
        host = config.get("host") or config.get("connectionUrl", "")
        if not host:
            raise ValueError("host or connectionUrl is required for Databricks")

        host = host.replace("https://", "").replace("http://", "")
        return host.rstrip("/")

    def _build_query_parts(self, config: Dict[str, Any]) -> list:
        """Build URL query parameters."""
        query_parts = []

        http_path = config.get("httpPath") or config.get("warehouseHttpPath")
        if http_path:
            query_parts.append(f"http_path={quote(http_path, safe='')}")

        catalog = config.get("catalog")
        if catalog:
            query_parts.append(f"catalog={quote(catalog, safe='')}")

        schema = config.get("schema")
        if schema:
            query_parts.append(f"schema={quote(schema, safe='')}")

        return query_parts
