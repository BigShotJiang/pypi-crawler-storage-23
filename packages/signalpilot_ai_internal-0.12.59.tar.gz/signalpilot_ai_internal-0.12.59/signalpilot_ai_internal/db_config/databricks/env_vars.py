"""Databricks environment variable builder."""

from typing import Any, Dict

from signalpilot_ai_internal.db_config.base.env_vars import BaseEnvVarBuilder
from signalpilot_ai_internal.db_config.databricks.url_builder import DatabricksURLBuilder


class DatabricksEnvVarBuilder(BaseEnvVarBuilder):
    """Builds environment variables for Databricks."""

    URL_BUILDER_CLASS = DatabricksURLBuilder
    EXTRA_FIELDS = [
        ("httpPath", "HTTP_PATH"),
        ("catalog", "CATALOG"),
        ("schema", "SCHEMA"),
        ("authType", "AUTH_TYPE"),
    ]

    def _build_common_env(self, config: Dict[str, Any], prefix: str) -> Dict[str, str]:
        """Override to use Databricks host field instead of standard host."""
        env_vars = super()._build_common_env(config, prefix)

        host = config.get("host") or config.get("connectionUrl", "")
        if host:
            host = host.replace("https://", "").replace("http://", "").rstrip("/")
            env_vars[f"{prefix}_HOST"] = host

        return env_vars
