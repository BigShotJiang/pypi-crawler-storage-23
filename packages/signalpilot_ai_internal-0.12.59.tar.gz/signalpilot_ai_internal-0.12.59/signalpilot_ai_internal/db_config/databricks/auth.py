"""Databricks authentication providers."""

import json
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Dict

from signalpilot_ai_internal.db_config.constants import (
    AUTH_TYPE_PAT,
    AUTH_TYPE_SERVICE_PRINCIPAL,
    DEFAULT_DATABRICKS_SCOPES,
    TOKEN_REFRESH_BUFFER_SECONDS,
)

_token_cache: Dict[str, Dict[str, Any]] = {}


class DatabricksTokenProvider:
    """Provides access tokens for Databricks authentication."""

    @staticmethod
    def get_token(config: Dict) -> str:
        """Get access token based on auth type."""
        auth_type = config.get("authType", AUTH_TYPE_PAT)

        if auth_type == AUTH_TYPE_PAT:
            return DatabricksTokenProvider._get_pat_token(config)
        if auth_type == AUTH_TYPE_SERVICE_PRINCIPAL:
            return DatabricksTokenProvider._get_oauth_token(config)
        raise ValueError(f"Unknown authentication type: {auth_type}")

    @staticmethod
    def _get_pat_token(config: Dict) -> str:
        """Return PAT directly."""
        token = config.get("accessToken")
        if not token:
            raise ValueError("Personal Access Token is required for PAT authentication")
        return token

    @staticmethod
    def _get_oauth_token(config: Dict) -> str:
        """Get OAuth token via client credentials flow with caching."""
        client_id = config.get("clientId")
        client_secret = config.get("clientSecret")

        if not client_id or not client_secret:
            raise ValueError(
                "Client ID and Client Secret are required for Service Principal authentication"
            )

        cache_key = f"{client_id}:{hash(client_secret)}"

        cached = _token_cache.get(cache_key)
        if cached and cached.get("expires_at", 0) > time.time() + TOKEN_REFRESH_BUFFER_SECONDS:
            return cached["access_token"]

        token_url = DatabricksTokenProvider._derive_token_url(config)

        scopes = config.get("scopes", DEFAULT_DATABRICKS_SCOPES)
        if isinstance(scopes, str):
            scopes = [scopes]

        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": " ".join(scopes),
        }

        encoded_data = urllib.parse.urlencode(data).encode("utf-8")

        req = urllib.request.Request(
            token_url,
            data=encoded_data,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
        )

        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                result = json.loads(response.read().decode("utf-8"))

                access_token = result.get("access_token")
                expires_in = result.get("expires_in", 3600)

                if not access_token:
                    raise ValueError("No access_token in OAuth response")

                _token_cache[cache_key] = {
                    "access_token": access_token,
                    "expires_at": time.time() + expires_in,
                }

                return access_token

        except urllib.error.HTTPError as e:
            error_body = e.read().decode("utf-8") if e.fp else str(e)
            raise ValueError(f"OAuth token request failed: {e.code} - {error_body}")
        except Exception as e:
            raise ValueError(f"Failed to obtain OAuth token: {str(e)}")

    @staticmethod
    def _derive_token_url(config: Dict) -> str:
        """Derive OAuth token URL from config or workspace hostname."""
        token_url = config.get("oauthTokenUrl")
        if token_url:
            return token_url

        host = config.get("host") or config.get("connectionUrl", "")
        if not host:
            raise ValueError(
                "Cannot determine OAuth token URL. Please provide oauthTokenUrl or connectionUrl."
            )

        if "azuredatabricks.net" in host:
            tenant_id = config.get("tenantId", "common")
            return f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
        return f"https://{host}/oidc/v1/token"
