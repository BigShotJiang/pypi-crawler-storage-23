"""
MCP Connections - Base and implementation classes for MCP server connections.

Supports command-based (stdio) and HTTP connection types.
"""
import asyncio
import json
import logging
import os
import platform
import subprocess
from typing import Dict, List, Optional, Any, IO

import aiohttp

from .constants import MCP_PROTOCOL_VERSION, MCP_CLIENT_INFO
from .errors import MCPConnectionError, MCPProtocolError

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)


class MCPConnection:
    """Base class for MCP connections."""

    def __init__(self, server_id: str, config: Dict[str, Any]):
        """Initialize connection."""
        self.server_id = server_id
        self.config = config
        self.connected = False

    async def connect(self):
        """Connect to the MCP server."""
        raise NotImplementedError

    async def disconnect(self):
        """Disconnect from the MCP server."""
        raise NotImplementedError

    async def list_tools(self) -> List[Dict[str, Any]]:
        """List available tools."""
        raise NotImplementedError

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a tool."""
        raise NotImplementedError

    def is_connected(self) -> bool:
        """Check if connected."""
        return self.connected

    def _convert_tool_schema(self, tool: Dict[str, Any]) -> Dict[str, Any]:
        """Convert MCP tool schema to standard format."""
        return {
            'name': tool.get('name'),
            'description': tool.get('description', ''),
            'inputSchema': tool.get('inputSchema', {'type': 'object', 'properties': {}})
        }


class MCPCommandConnection(MCPConnection):
    """Command-based MCP connection using stdio."""

    def __init__(self, server_id: str, config: Dict[str, Any]):
        """Initialize command connection."""
        super().__init__(server_id, config)
        self._process: Optional[subprocess.Popen] = None
        self._stdin: Optional[IO[bytes]] = None
        self._stdout: Optional[IO[bytes]] = None
        self._stderr: Optional[IO[bytes]] = None
        self._request_id = 0
        self._stdout_queue: asyncio.Queue[bytes] = asyncio.Queue()
        self._stderr_queue: asyncio.Queue[bytes] = asyncio.Queue()
        self._reader_tasks: List[asyncio.Task] = []

    async def connect(self):
        """Start subprocess and establish stdio connection."""
        command = self.config.get('command')
        if not command:
            raise MCPConnectionError(
                f"'command' is required for server '{self.server_id}'. "
                f"Config has keys: {list(self.config.keys())}"
            )
        args = self.config.get('args', [])
        env = self._prepare_environment(self.config.get('env', {}))

        logger.info(f"[MCP] Connecting: server_id={self.server_id}, command={command}")

        await self._start_process(command, args, env)
        await self._initialize_protocol()

    def _prepare_environment(self, env: Dict[str, str]) -> Dict[str, str]:
        """Prepare environment variables including OAuth tokens."""
        from ..oauth_token_store import get_oauth_token_store

        token_store = get_oauth_token_store()
        is_oauth = self.config.get('isOAuthIntegration') or token_store.is_oauth_server(self.server_id)

        if is_oauth:
            oauth_env = token_store.get_tokens(self.server_id)
            if oauth_env:
                env = {**env, **oauth_env}

        full_env = os.environ.copy()
        full_env.update(env)
        return full_env

    async def _start_process(self, command: str, args: List[str], env: Dict[str, str]):
        """Start the subprocess and store stream references."""
        is_windows = platform.system() == 'Windows'
        creationflags = subprocess.CREATE_NO_WINDOW if is_windows else 0

        process = self._try_spawn_process(command, args, env, creationflags, is_windows)

        self._process = process
        self._stdin = process.stdin
        self._stdout = process.stdout
        self._stderr = process.stderr

        logger.debug(f"[MCP] Process started with PID: {process.pid}")
        self._start_reader_tasks()

        await asyncio.sleep(0.5)

        if process.poll() is not None:
            stderr_text = await self._read_all_stderr()
            raise MCPConnectionError(f"Server exited with code {process.returncode}. Error: {stderr_text}")

        self.connected = True

    def _try_spawn_process(
        self, command: str, args: List[str], env: Dict[str, str], creationflags: int, is_windows: bool
    ) -> subprocess.Popen:
        """Try to spawn process, with Windows extension fallback."""
        try:
            return subprocess.Popen(
                [command] + args,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                env=env,
                creationflags=creationflags
            )
        except FileNotFoundError:
            if is_windows and not any(command.endswith(ext) for ext in ['.exe', '.cmd', '.bat']):
                for ext in ['.exe', '.cmd', '.bat']:
                    try:
                        return subprocess.Popen(
                            [command + ext] + args,
                            stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            env=env,
                            creationflags=creationflags
                        )
                    except FileNotFoundError:
                        continue
            raise MCPConnectionError(f"Command not found: {command}")

    async def _read_all_stderr(self) -> str:
        """Read all stderr synchronously."""
        if not self._stderr:
            return "No error output"
        loop = asyncio.get_event_loop()
        data = await loop.run_in_executor(None, self._stderr.read)
        return data.decode('utf-8', errors='replace') if data else "No error output"

    async def _initialize_protocol(self):
        """Send MCP initialization request."""
        await self._send_request('initialize', {
            'protocolVersion': MCP_PROTOCOL_VERSION,
            'capabilities': {},
            'clientInfo': MCP_CLIENT_INFO
        })
        logger.debug(f"[MCP] Initialization successful")

    def _start_reader_tasks(self):
        """Start background tasks to read from stdout/stderr."""
        if not self._stdout or not self._stderr:
            raise MCPConnectionError("Process streams not available")

        loop = asyncio.get_event_loop()
        self._reader_tasks = [
            loop.create_task(self._read_stream(self._stdout, self._stdout_queue, 'stdout')),
            loop.create_task(self._read_stream(self._stderr, self._stderr_queue, 'stderr'))
        ]

    async def _read_stream(self, stream: IO[bytes], queue: asyncio.Queue[bytes], name: str):
        """Read from a stream in background and put lines into queue."""
        loop = asyncio.get_event_loop()
        try:
            while True:
                line = await loop.run_in_executor(None, stream.readline)
                if not line:
                    break
                await queue.put(line)
        except Exception as e:
            logger.error(f"[MCP] Error reading {name}: {e}")

    async def disconnect(self):
        """Terminate subprocess."""
        if not self._process:
            return

        for task in self._reader_tasks:
            task.cancel()

        self._process.terminate()

        loop = asyncio.get_event_loop()
        try:
            await asyncio.wait_for(loop.run_in_executor(None, self._process.wait), timeout=5.0)
        except asyncio.TimeoutError:
            self._process.kill()
            await loop.run_in_executor(None, self._process.wait)

        self.connected = False

    def is_connected(self) -> bool:
        """Check if connected and process is still alive."""
        if not self.connected or not self._process:
            return False

        if self._process.poll() is not None:
            self.connected = False
            return False
        return True

    async def list_tools(self) -> List[Dict[str, Any]]:
        """List tools via JSON-RPC."""
        response = await self._send_request('tools/list', {})
        tools = response.get('result', {}).get('tools', [])
        return [self._convert_tool_schema(tool) for tool in tools]

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a tool via JSON-RPC."""
        response = await self._send_request('tools/call', {'name': tool_name, 'arguments': arguments})
        return response.get('result', {})

    async def _send_request(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Send JSON-RPC request and get response."""
        if not self._process or not self._stdin:
            raise MCPProtocolError("Not connected to MCP server")

        if self._process.poll() is not None:
            raise MCPProtocolError(f"Server exited with code {self._process.returncode}")

        self._request_id += 1
        request = {'jsonrpc': '2.0', 'id': self._request_id, 'method': method, 'params': params}
        request_data = json.dumps(request) + '\n'

        loop = asyncio.get_event_loop()
        await loop.run_in_executor(None, self._stdin.write, request_data.encode())
        await loop.run_in_executor(None, self._stdin.flush)

        try:
            response_line = await asyncio.wait_for(self._stdout_queue.get(), timeout=30.0)
        except asyncio.TimeoutError:
            raise MCPProtocolError(f"Response timeout for method '{method}'")

        response = json.loads(response_line.decode('utf-8', errors='replace'))

        if 'error' in response:
            raise MCPProtocolError(f"Server error: {response['error']}")

        return response


class MCPHTTPConnection(MCPConnection):
    """HTTP-based MCP connection using Streamable HTTP Transport."""

    def __init__(self, server_id: str, config: Dict[str, Any]):
        """Initialize HTTP connection."""
        super().__init__(server_id, config)
        self._session: Optional[aiohttp.ClientSession] = None
        self._base_url = config['url'].rstrip('/')
        self._request_id = 0
        self._session_id: Optional[str] = None

    async def connect(self):
        """Establish HTTP connection."""
        self._session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30))

        try:
            response = await self._jsonrpc_request('initialize', {
                'protocolVersion': MCP_PROTOCOL_VERSION,
                'capabilities': {},
                'clientInfo': MCP_CLIENT_INFO
            })
            logger.info(f"[MCP] Initialized: {response.get('serverInfo', response)}")

            await self._jsonrpc_notify('notifications/initialized', {})
            self.connected = True
            logger.info(f"[MCP] Connected to HTTP server: {self._base_url}")
        except Exception:
            if self._session:
                await self._session.close()
                self._session = None
            raise

    async def disconnect(self):
        """Close HTTP session."""
        if self._session:
            await self._session.close()
            self._session = None
        self._session_id = None
        self.connected = False

    async def list_tools(self) -> List[Dict[str, Any]]:
        """List tools via JSON-RPC."""
        response = await self._jsonrpc_request('tools/list', {})
        tools = response.get('tools', [])
        return [self._convert_tool_schema(tool) for tool in tools]

    async def call_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Any:
        """Call a tool via JSON-RPC."""
        return await self._jsonrpc_request('tools/call', {'name': tool_name, 'arguments': arguments})

    def _build_headers(self) -> Dict[str, str]:
        """Build HTTP headers for request."""
        headers = {'Content-Type': 'application/json', 'Accept': 'application/json, text/event-stream'}
        if token := self.config.get('token'):
            headers['Authorization'] = f'Bearer {token}'
        if self._session_id:
            headers['Mcp-Session-Id'] = self._session_id
        return headers

    async def _jsonrpc_request(self, method: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Send JSON-RPC request to MCP server."""
        if not self._session:
            raise MCPProtocolError("Not connected to MCP server")

        self._request_id += 1
        payload = {'jsonrpc': '2.0', 'id': self._request_id, 'method': method, 'params': params}

        async with self._session.post(self._base_url, json=payload, headers=self._build_headers()) as response:
            response.raise_for_status()
            if 'mcp-session-id' in response.headers:
                self._session_id = response.headers['mcp-session-id']
            result = await response.json()
            if 'error' in result:
                raise MCPProtocolError(f"JSON-RPC error: {result['error']}")
            return result.get('result', {})

    async def _jsonrpc_notify(self, method: str, params: Dict[str, Any]):
        """Send JSON-RPC notification (no response expected)."""
        if not self._session:
            raise MCPProtocolError("Not connected to MCP server")

        payload = {'jsonrpc': '2.0', 'method': method, 'params': params}
        async with self._session.post(self._base_url, json=payload, headers=self._build_headers()) as response:
            response.raise_for_status()
