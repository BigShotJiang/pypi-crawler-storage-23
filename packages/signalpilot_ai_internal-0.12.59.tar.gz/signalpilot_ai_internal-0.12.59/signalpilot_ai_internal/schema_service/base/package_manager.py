"""Runtime package installation manager."""

import subprocess
import sys
from typing import List


class PackageManager:
    """Manages runtime package installation for database drivers."""

    PACKAGES = {
        "postgresql": ["psycopg2-binary"],
        "mysql": ["pymysql"],
        "snowflake": ["snowflake-connector-python"],
        "databricks": ["databricks-sql-connector"],
    }

    @classmethod
    def ensure_installed(cls, db_type: str) -> None:
        """Ensure required packages are installed for database type.

        Raises:
            ImportError: If packages cannot be installed.
        """
        packages = cls.PACKAGES.get(db_type, [])
        missing = []

        for package in packages:
            if not cls._is_installed(package):
                if not cls._install_package(package):
                    missing.append(package)

        if missing:
            raise ImportError(
                f"Required packages could not be installed: {', '.join(missing)}"
            )

    @staticmethod
    def _is_installed(package: str) -> bool:
        """Check if a package is installed."""
        # Map package names to import names
        import_map = {
            "psycopg2-binary": "psycopg2",
            "pymysql": "pymysql",
            "snowflake-connector-python": "snowflake.connector",
            "databricks-sql-connector": "databricks.sql",
        }
        import_name = import_map.get(package, package.replace("-", "_"))

        try:
            __import__(import_name)
            return True
        except ImportError:
            return False

    @staticmethod
    def _install_package(package: str) -> bool:
        """Install a package using pip."""
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", package],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            return True
        except subprocess.CalledProcessError:
            return False
