---
title: Project Memory
description: "Manage persistent project memory in SIGNALPILOT.md - read at session start, write when user says 'remember this'."
when_to_apply: Auto
alwaysApply: false
applyIntelligently: true
updated_at: "2026-02-23T00:00:00Z"
default: true
category: core
version: "1.2.0"
active: true
---

# Project Memory

SignalPilot maintains persistent memory for each project in `SIGNALPILOT.md`. This file is automatically loaded into your context at the start of each session.

## How It Works

1. **Reading**: The file content appears in your system prompt as `=== PROJECT MEMORY ===` section
2. **Writing**: Use the `memory-update` tool when user says "remember this"

## When to Save Memories

Save to project memory when the user:
- Says "remember this", "save this", "don't forget"
- Explicitly asks you to remember something for future sessions

## How to Write Memories

Use the `memory-update` MCP tool:

### Append new content
```json
{
  "action": "append",
  "content": "\n\n## Topic\n\n- Memory item here\n"
}
```

### Replace entire file (for consolidation)
```json
{
  "action": "replace",
  "content": "# Project Memory\n\n## Section\n\n- Item 1\n- Item 2\n"
}
```

### Read current content
```json
{
  "action": "read"
}
```

## Example

User says: "Remember that I prefer pandas over polars for this project"

```json
{
  "action": "append",
  "content": "\n\n## User Preferences\n\n- Prefers pandas over polars for dataframe operations\n"
}
```

## Memory File Format

Use markdown with clear sections:

```markdown
# Project Memory

## User Preferences
- Prefers pandas over polars
- Likes concise code comments

## Project Context
- Main data source: PostgreSQL database "analytics"

## Important Decisions
- 2024-02-23: Decided to use scikit-learn for ML models
```

## File Size Management

**CRITICAL: Keep the file under 1000 characters.** This file is loaded into every request.

### Before Adding New Memory

1. Check if `=== PROJECT MEMORY ===` section exists in your context
2. Check for duplicates - Don't add if similar memory exists
3. Check for contradictions - If new memory contradicts old, use "replace" action
4. If file is large, consolidate with "replace" action

### When to Use Replace vs Append

| Situation | Action |
|-----------|--------|
| New topic | `append` |
| Updated preference | `replace` entire file with updated content |
| File too large | `replace` with consolidated content |

## Best Practices

1. **Be concise** - One line per memory when possible
2. **Use sections** - Group related memories under headers
3. **Confirm to user** - Tell the user what you saved/updated
4. **Consolidate** - Use replace action to merge related entries when needed
