"""Shared base utilities for MCP tools."""
