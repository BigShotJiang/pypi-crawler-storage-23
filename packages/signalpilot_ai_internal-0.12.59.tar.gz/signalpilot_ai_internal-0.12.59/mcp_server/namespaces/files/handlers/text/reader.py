"""Plain text file reader with line-based pagination."""

from pathlib import Path

CHUNK_SIZE = 65536


class TextReader:
    """Reads text files with line-based start/end pagination."""

    def __init__(self, max_lines: int):
        self.max_lines = max_lines

    def read(self, path: Path, start: int, end: int) -> tuple[str, int, bool]:
        """Read lines [start, end) from a text file.

        Counts total lines via raw byte reads, then streams only the
        requested slice so large files don't load fully into memory.

        Returns:
            Tuple of (content, total_lines, truncated).
        """
        total_lines = self._count_lines(path)
        limit = min(end, total_lines)
        selected = self._read_slice(path, start, limit)

        truncated = len(selected) > self.max_lines
        if truncated:
            truncation_msg = f"... [Truncated: showing {self.max_lines} of {len(selected)} lines]"
            selected = selected[: self.max_lines] + [truncation_msg]

        content = "\n".join(selected)
        return content, total_lines, truncated

    @staticmethod
    def _count_lines(path: Path) -> int:
        """Count newlines in a file using buffered binary reads."""
        count = 0
        with path.open("rb") as f:
            while chunk := f.read(CHUNK_SIZE):
                count += chunk.count(b"\n")
        return count

    @staticmethod
    def _read_slice(path: Path, start: int, end: int) -> list[str]:
        """Read only lines [start, end) from a file."""
        lines: list[str] = []
        with path.open(errors="replace") as f:
            for i, line in enumerate(f):
                if i >= end:
                    break
                if i >= start:
                    lines.append(line.rstrip("\n"))
        return lines
