"""Memory service for project memory and chat history operations."""

from __future__ import annotations

import json
import os
import platform
import re
from pathlib import Path
from typing import Optional

from namespaces.base.config import get_root_dir
from namespaces.memory.models import (
    ChatSearchMatch,
    ChatSearchRequest,
    ChatSearchResponse,
    MemoryUpdateRequest,
    MemoryUpdateResponse,
)


MAX_MEMORY_SIZE = 1000  # Max recommended chars for memory file


class MemoryService:
    """Service for managing project memory and chat history."""

    def _get_chat_history_dir(self) -> Path:
        """Get platform-specific chat history directory."""
        system = platform.system()
        if system == "Darwin":
            return Path.home() / "Library/Caches/SignalPilotAI/chat-histories"
        elif system == "Linux":
            return Path.home() / ".cache/signalpilot-ai-internal/chat-histories"
        elif system == "Windows":
            local_app_data = os.environ.get("LOCALAPPDATA", "")
            return Path(local_app_data) / "SignalPilotAI/Cache/chat-histories"
        return Path.home() / ".cache/signalpilot-ai-internal/chat-histories"

    async def update(self, request: MemoryUpdateRequest) -> MemoryUpdateResponse:
        """Update the project memory file (SIGNALPILOT.md)."""
        memory_file = get_root_dir() / "SIGNALPILOT.md"

        if request.action == "read":
            if not memory_file.exists():
                return MemoryUpdateResponse(
                    success=True,
                    content=None,
                    message="No project memory file exists yet.",
                )
            content = memory_file.read_text()
            return MemoryUpdateResponse(
                success=True,
                content=content,
                message="Read project memory successfully.",
            )

        if request.action == "append":
            if not request.content:
                return MemoryUpdateResponse(
                    success=False,
                    content=None,
                    message="No content provided.",
                    error="Content is required for append action.",
                )
            existing = memory_file.read_text() if memory_file.exists() else ""
            new_content = existing + request.content
            memory_file.write_text(new_content)
            msg = "Appended to project memory."
            if len(new_content) > MAX_MEMORY_SIZE:
                msg += f" Warning: file is {len(new_content)} chars (recommended max: {MAX_MEMORY_SIZE}). Consider consolidating."
            return MemoryUpdateResponse(
                success=True,
                content=new_content,
                message=msg,
            )

        if request.action == "replace":
            if not request.content:
                return MemoryUpdateResponse(
                    success=False,
                    content=None,
                    message="No content provided.",
                    error="Content is required for replace action.",
                )
            memory_file.write_text(request.content)
            msg = "Replaced project memory."
            if len(request.content) > MAX_MEMORY_SIZE:
                msg += f" Warning: file is {len(request.content)} chars (recommended max: {MAX_MEMORY_SIZE}). Consider consolidating."
            return MemoryUpdateResponse(
                success=True,
                content=request.content,
                message=msg,
            )

        return MemoryUpdateResponse(
            success=False,
            content=None,
            message=f"Unknown action: {request.action}",
            error="Action must be 'read', 'append', or 'replace'.",
        )

    async def chat_search(self, request: ChatSearchRequest) -> ChatSearchResponse:
        """Search through chat history files."""
        chat_dir = self._get_chat_history_dir()

        if not chat_dir.exists():
            return ChatSearchResponse(
                matches=[],
                count=0,
                truncated=False,
                message="No chat history directory found.",
            )

        try:
            flags = re.IGNORECASE if request.case_insensitive else 0
            regex = re.compile(request.query, flags)
        except re.error as e:
            return ChatSearchResponse(
                matches=[],
                count=0,
                truncated=False,
                message="Invalid search pattern.",
                error=f"Invalid regex: {e}",
            )

        matches: list[ChatSearchMatch] = []
        truncated = False

        json_files = sorted(chat_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)

        for file_path in json_files:
            if len(matches) >= request.max_results:
                truncated = True
                break

            match = self._search_chat_file(file_path, regex)
            if match:
                matches.append(match)

        return ChatSearchResponse(
            matches=matches,
            count=len(matches),
            truncated=truncated,
            message=f"Found {len(matches)} match{'es' if len(matches) != 1 else ''} in chat history.",
        )

    def _search_chat_file(
        self,
        file_path: Path,
        regex: re.Pattern,
    ) -> ChatSearchMatch | None:
        """Search a single chat history file as raw text."""
        try:
            content = file_path.read_text(errors="ignore")
        except OSError:
            return None

        match = regex.search(content)
        if not match:
            return None

        # Extract snippet around match
        start = max(0, match.start() - 200)
        end = min(len(content), match.end() + 200)
        snippet = content[start:end]
        if start > 0:
            snippet = "..." + snippet
        if end < len(content):
            snippet = snippet + "..."

        # Extract thread name from JSON content, fallback to filename
        thread_name = self._extract_thread_name(content, file_path.stem)

        return ChatSearchMatch(
            file=str(file_path),
            thread_name=thread_name,
            thread_id=file_path.stem,
            snippet=snippet,
            timestamp=int(file_path.stat().st_mtime * 1000),
        )

    def _extract_thread_name(self, content: str, fallback: str) -> str:
        """Extract thread name from JSON content."""
        try:
            data = json.loads(content)
            if isinstance(data, list) and data:
                name = data[0].get("name")
                if name and name != "New Chat":
                    return name
        except (json.JSONDecodeError, KeyError, IndexError):
            pass
        return fallback.replace("notebook_chat_", "")


_memory_service: Optional[MemoryService] = None


def get_memory_service() -> MemoryService:
    """Get or create the singleton service instance."""
    global _memory_service
    if _memory_service is None:
        _memory_service = MemoryService()
    return _memory_service
