import React from 'react';
import { ReactWidget } from '@jupyterlab/apputils';
import { JupyterFrontEnd } from '@jupyterlab/application';
import { NotebookPanel, INotebookModel } from '@jupyterlab/notebook';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { IDisposable } from '@lumino/disposable';
import { MessageLoop } from '@lumino/messaging';
import { Widget } from '@lumino/widgets';
import { SPToolbar } from './SPToolbar';

/**
 * ReactWidget wrapper for the SPToolbar component.
 * One instance per notebook panel.
 */
class SPToolbarWidget extends ReactWidget {
  private _panel: NotebookPanel;
  private _app: JupyterFrontEnd;

  constructor(panel: NotebookPanel, app: JupyterFrontEnd) {
    super();
    this._panel = panel;
    this._app = app;
    this.addClass('sp-toolbar-widget');
  }

  protected render(): React.ReactElement {
    return <SPToolbar panel={this._panel} app={this._app} />;
  }
}

/**
 * WidgetExtension that injects SPToolbar into each notebook panel.
 * Registered via app.docRegistry.addWidgetExtension('Notebook', ...).
 */
export class SPToolbarExtension
  implements
    DocumentRegistry.IWidgetExtension<NotebookPanel, INotebookModel>
{
  private _app: JupyterFrontEnd;

  constructor(app: JupyterFrontEnd) {
    this._app = app;
  }

  createNew(
    panel: NotebookPanel,
    _context: DocumentRegistry.IContext<INotebookModel>
  ): IDisposable {
    const toolbar = new SPToolbarWidget(panel, this._app);

    // Insert the toolbar node before the notebook content area
    panel.node.insertBefore(toolbar.node, panel.content.node);

    // Send lumino lifecycle messages so ReactWidget renders
    MessageLoop.sendMessage(toolbar, Widget.Msg.BeforeAttach);
    MessageLoop.sendMessage(toolbar, Widget.Msg.AfterAttach);

    return toolbar;
  }
}
