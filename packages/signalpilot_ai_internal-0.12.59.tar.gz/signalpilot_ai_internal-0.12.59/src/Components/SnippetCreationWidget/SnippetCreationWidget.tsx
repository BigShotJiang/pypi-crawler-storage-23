import * as React from 'react';
import { ReactWidget } from '@jupyterlab/ui-components';
import { ISignal, Signal } from '@lumino/signaling';
import { useSnippetStore, ISnippet } from '../../stores/snippetStore';
import { SNIPPETS_ICON } from '@/ChatBox/Context/icons';
import { ISnippetCreationState } from './types';
import { SnippetCreationContent } from './SnippetCreationContent';

/**
 * Component for displaying content on the left side panel
 */
export class SnippetCreationWidget extends ReactWidget {
  private _state: ISnippetCreationState;
  private _stateChanged = new Signal<this, ISnippetCreationState>(this);

  constructor() {
    super();
    this._state = {
      isVisible: true,
      snippets: [],
      isCreating: false,
      editingSnippet: null,
      viewingSnippet: null, // Keep for compatibility but not used
      title: '',
      description: '',
      content: '',
      mode: 'manual'
    };
    this.addClass('sage-ai-snippet-creation-widget');
    this.id = 'sage-ai-snippet-creation';
    this.title.icon = SNIPPETS_ICON;
    this.title.closable = true;

    // Set the panel title to 'Rules'
    // this.title.label = 'Rules';

    // Set initial visibility state
    if (!this._state.isVisible) {
      this.addClass('hidden');
    }

    // Load snippets from cache
    void this.loadSnippets();
  }

  /**
   * Get the signal that fires when state changes
   */
  public get stateChanged(): ISignal<this, ISnippetCreationState> {
    return this._stateChanged;
  }

  /**
   * Render the React component
   */
  render(): JSX.Element {
    return (
      <SnippetCreationContent
        state={this._state}
        onCreateNew={this.handleCreateNew.bind(this)}
        onSave={this.handleSave.bind(this)}
        onEdit={this.handleEdit.bind(this)}
        onView={this.handleView.bind(this)}
        onDelete={this.handleDelete.bind(this)}
        onDuplicate={this.handleDuplicate.bind(this)}
        onClose={this.handleClose.bind(this)}
        onEnable={this.handleEnable.bind(this)}
        onTitleChange={this.handleTitleChange.bind(this)}
        onDescriptionChange={this.handleDescriptionChange.bind(this)}
        onContentChange={this.handleContentChange.bind(this)}
        onModeChange={this.handleModeChange.bind(this)}
        onToggleActive={this.handleToggleActive.bind(this)}
      />
    );
  }

  /**
   * Load snippets from snippet store
   */
  private async loadSnippets(): Promise<void> {
    try {
      // Load snippets from StateDB through snippet store
      await useSnippetStore.getState().loadFromStateDB();
      const snippets = useSnippetStore.getState().snippets;
      this._state = {
        ...this._state,
        snippets
      };
      this._stateChanged.emit(this._state);
      this.update();
    } catch (error) {
      console.error('[SnippetCreationWidget] Failed to load snippets:', error);
    }
  }

  /**
   * Handle create new snippet
   */
  private handleCreateNew(): void {
    this._state = {
      ...this._state,
      isCreating: true,
      editingSnippet: null,
      viewingSnippet: null,
      title: '',
      description: '',
      content: '',
      mode: 'manual'
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle save snippet
   */
  private async handleSave(): Promise<void> {
    if (!this._state.title.trim() || !this._state.content.trim()) {
      return;
    }

    const now = new Date().toISOString();

    if (this._state.editingSnippet) {
      // Update existing snippet
      console.log(
        '[SnippetCreationWidget] Updating snippet:',
        this._state.editingSnippet.filename
      );
      console.log('[SnippetCreationWidget] New content:', {
        title: this._state.title.trim(),
        description: this._state.description.trim(),
        content: this._state.content.trim(),
        mode: this._state.mode
      });

      await useSnippetStore
        .getState()
        .updateSnippet(this._state.editingSnippet.filename, {
          title: this._state.title.trim(),
          description: this._state.description.trim(),
          content: this._state.content.trim(),
          mode: this._state.mode,
          updatedAt: now
        });

      console.log('[SnippetCreationWidget] Snippet updated successfully');

      this._state = {
        ...this._state,
        snippets: useSnippetStore.getState().snippets,
        isCreating: false,
        editingSnippet: null,
        title: '',
        description: '',
        content: '',
        mode: 'manual'
      };
    } else {
      // Create new snippet (filename is derived from title by the backend)
      console.log('[SnippetCreationWidget] Creating new snippet');
      const newSnippet = {
        title: this._state.title.trim(),
        description: this._state.description.trim(),
        content: this._state.content.trim(),
        mode: this._state.mode,
        source: 'user' as const,
        filePath: '',
        createdAt: now,
        updatedAt: now,
        // New fields for default rules system
        isDefault: false,
        category: 'user' as const,
        deactivated: false,
        active: true
      };

      await useSnippetStore.getState().addSnippet(newSnippet);

      this._state = {
        ...this._state,
        snippets: useSnippetStore.getState().snippets,
        isCreating: false,
        title: '',
        description: '',
        content: '',
        mode: 'manual'
      };
    }

    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle edit snippet
   */
  private handleEdit(snippet: ISnippet): void {
    console.log('[SnippetCreationWidget] Editing snippet:', snippet);
    this._state = {
      ...this._state,
      isCreating: false,
      editingSnippet: snippet,
      title: snippet.title,
      description: snippet.description,
      content: snippet.content,
      mode: snippet.mode || 'manual'
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle view snippet (now same as edit for compatibility)
   */
  private handleView(snippet: ISnippet): void {
    this.handleEdit(snippet);
  }

  /**
   * Handle delete snippet
   */
  private async handleDelete(snippetFilename: string): Promise<void> {
    if (!confirm('Are you sure you want to delete this snippet?')) {
      return;
    }

    await useSnippetStore.getState().removeSnippet(snippetFilename);

    this._state = {
      ...this._state,
      snippets: useSnippetStore.getState().snippets,
      editingSnippet: null
    };

    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle duplicate snippet - creates a copy with (N) appended to title
   */
  private async handleDuplicate(snippet: ISnippet): Promise<void> {
    // Find a unique title by appending (N)
    const existingTitles = this._state.snippets.map(s => s.title);
    let newTitle = snippet.title;
    let counter = 1;

    // Check if the title already ends with (N) pattern
    const match = newTitle.match(/^(.+?)\s*\((\d+)\)$/);
    if (match) {
      newTitle = match[1];
      counter = parseInt(match[2], 10) + 1;
    }

    // Find a unique title
    let candidateTitle = `${newTitle} (${counter})`;
    while (existingTitles.includes(candidateTitle)) {
      counter++;
      candidateTitle = `${newTitle} (${counter})`;
    }

    // Create the duplicated snippet directly
    const now = new Date().toISOString();
    const duplicatedSnippet = {
      title: candidateTitle,
      description: snippet.description,
      content: snippet.content,
      mode: snippet.mode || 'manual',
      source: 'user' as const,
      filePath: '',
      createdAt: now,
      updatedAt: now,
      isDefault: false,
      category: 'user' as const,
      deactivated: false,
      active: true
    };

    await useSnippetStore.getState().addSnippet(duplicatedSnippet);

    this._state = {
      ...this._state,
      snippets: useSnippetStore.getState().snippets
    };

    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle close form/viewer
   */
  private handleClose(): void {
    this._state = {
      ...this._state,
      isCreating: false,
      editingSnippet: null,
      title: '',
      description: '',
      content: '',
      mode: 'manual'
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle mode change
   */
  private handleModeChange(mode: 'always' | 'intelligent' | 'manual'): void {
    this._state = {
      ...this._state,
      mode
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle enable snippet (placeholder for future implementation)
   */
  private handleEnable(snippet: ISnippet): void {
    console.log('[SnippetCreationWidget] Enable snippet:', snippet.title);
    // TODO: Implement enable functionality
    // This would integrate with the chat context system
  }

  /**
   * Handle toggle active state of a rule
   */
  private async handleToggleActive(
    snippetFilename: string,
    active: boolean
  ): Promise<void> {
    console.log(
      '[SnippetCreationWidget] Toggle active:',
      snippetFilename,
      active
    );

    await useSnippetStore.getState().updateSnippet(snippetFilename, {
      active
    });

    this._state = {
      ...this._state,
      snippets: useSnippetStore.getState().snippets
    };

    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle title change
   */
  private handleTitleChange(value: string): void {
    this._state = {
      ...this._state,
      title: value
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle description change
   */
  private handleDescriptionChange(value: string): void {
    this._state = {
      ...this._state,
      description: value
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Handle content change
   */
  private handleContentChange(value: string): void {
    this._state = {
      ...this._state,
      content: value
    };
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Show the panel
   */
  public show(): void {
    this._state = {
      ...this._state,
      isVisible: true
    };
    this.removeClass('hidden');
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Hide the panel
   */
  public hide(): void {
    this._state = {
      ...this._state,
      isVisible: false
    };
    this.addClass('hidden');
    this._stateChanged.emit(this._state);
    this.update();
  }

  /**
   * Check if the panel is currently visible
   */
  public getIsVisible(): boolean {
    return this._state.isVisible;
  }

  /**
   * Get the current state
   */
  public getState(): ISnippetCreationState {
    return { ...this._state };
  }

  /**
   * Get all snippets
   */
  public getSnippets(): ISnippet[] {
    return [...this._state.snippets];
  }

  /**
   * Handle close request when the widget is closed
   */
  protected onCloseRequest(): void {
    this.dispose();
  }

  /**
   * Dispose of the widget and clean up resources
   */
  dispose(): void {
    if (this.isDisposed) {
      return;
    }

    // Clear any state
    this._state = {
      isVisible: false,
      snippets: [],
      isCreating: false,
      editingSnippet: null,
      viewingSnippet: null,
      title: '',
      description: '',
      content: '',
      mode: 'manual'
    };

    // Apply hidden class since isVisible is false
    this.addClass('hidden');

    // Emit final state change
    this._stateChanged.emit(this._state);

    // Call parent dispose
    super.dispose();
  }
}
