import argparse
from .api import start_server

def main():
    parser = argparse.ArgumentParser(description="xorfice: Elite Multimodal Inference Server")
    parser.add_argument("--host", type=str, default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8000, help="Port to bind to")
    parser.add_argument("--weights", type=str, default="./weights", help="Path to local model weights")
    parser.add_argument("--hf", type=str, default=None, help="Hugging Face Model Repo ID (overrides --weights)")
    
    args = parser.parse_args()
    
    import os
    os.environ["XORON_MODEL_PATH"] = args.hf if args.hf else args.weights
    
    print(f"📡 Starting xorfice server on {args.host}:{args.port}...")
    start_server(host=args.host, port=args.port)

if __name__ == "__main__":
    main()
