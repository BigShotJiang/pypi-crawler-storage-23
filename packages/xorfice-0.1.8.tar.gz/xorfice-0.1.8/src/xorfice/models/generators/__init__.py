"""Generator modules for Xoron-Dev."""

from xorfice.models.generators.image import MobileDiffusionGenerator
from xorfice.models.generators.video import MobileVideoDiffusion

__all__ = ['MobileDiffusionGenerator', 'MobileVideoDiffusion']
