docker compose stop ${CONTAINER}
docker compose rm -f ${CONTAINER}
