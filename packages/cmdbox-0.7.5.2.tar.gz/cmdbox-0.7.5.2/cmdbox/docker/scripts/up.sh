docker compose up -d ${CONTAINER}
