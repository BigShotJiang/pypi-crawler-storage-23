"""MMLU dataset source wrapper."""

from .dataloader import MMLUDataLoader

__all__ = ["MMLUDataLoader"]
