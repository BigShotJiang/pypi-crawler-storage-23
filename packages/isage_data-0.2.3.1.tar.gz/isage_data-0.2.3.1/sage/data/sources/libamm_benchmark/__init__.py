"""LibAMM benchmark dataset source.

This provides access to the LibAMM benchmark datasets located in the
libamm-benchmark directory.
"""

# Note: The actual data is in ../libamm-benchmark/
# This wrapper provides a consistent interface through the sources layer

__all__ = []
