from glm_mcp.server import mcp


def main() -> None:
    mcp.run()
