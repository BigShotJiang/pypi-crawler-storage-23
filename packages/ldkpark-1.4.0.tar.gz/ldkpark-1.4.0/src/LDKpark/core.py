def add(a,b):
    return a+b

def minus(a,b):
    return a-b