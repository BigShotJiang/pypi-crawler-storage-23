"""SDK helper CLI scripts."""

