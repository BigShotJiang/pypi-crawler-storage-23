"""Generated CRM code namespace.

v0.1.1 includes codegen scaffolding and fixtures; generated runtime modules will
expand as coverage increases.
"""
