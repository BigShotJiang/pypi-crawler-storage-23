"""Generated Creator code namespace (expands in later releases)."""
