from mcp_yolo.server import main

if __name__ == "__main__":
    main()
