#!/usr/bin/env python
# -*- coding: utf-8 -*-
from ._version import __version__
from .AutoCython import compile


def main():
    compile()