import os
import sys
import locale
import argparse

from ._version import __version__

def get_system_language():
    """
    获取系统语言，兼容 Python 3.11+

    :return: 'zh' 或 'en'
    """
    try:
        # Python 3.11+ 推荐方式
        lang = locale.getlocale()[0]
        if lang is None:
            # 回退到环境变量
            lang = os.environ.get('LANG', os.environ.get('LANGUAGE', ''))
        return 'zh' if lang and lang.startswith('zh') else 'en'
    except Exception:
        return 'en'

def find_python_files(path):
    """
    查找指定路径下的所有子孙py文件，不包括 __init__.py, 排除头两行包含"# AutoCython No Compile"的文件

    :param path: 要搜索的根目录路径
    :return: 符合条件的py文件路径列表
    """
    # 排除标记（兼容旧版本拼写错误）
    exclude_markers = ["# AutoCython No Compile", "# AucoCython No Compile"]

    def has_exclude_marker(line):
        return any(marker in line for marker in exclude_markers)

    valid_py_files = []
    skip_dirs = {
        "__pycache__", "venv", ".venv", "build", "dist",
        "node_modules", ".git", ".eggs",
    }

    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in skip_dirs and not d.endswith(".egg-info")]
        for file in files:
            if file == "__init__.py":
                continue
            if file.endswith('.py'):
                filepath = os.path.join(root, file)

                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        # 读取头两行
                        line1 = f.readline()
                        line2 = f.readline()

                        # 检查是否包含排除标记
                        if not has_exclude_marker(line1) and not has_exclude_marker(line2):
                            valid_py_files.append(filepath)
                except UnicodeDecodeError:
                    # 如果utf-8解码失败，尝试其他编码
                    try:
                        with open(filepath, 'r', encoding='latin-1') as f:
                            line1 = f.readline()
                            line2 = f.readline()

                            if not has_exclude_marker(line1) and not has_exclude_marker(line2):
                                valid_py_files.append(filepath)
                    except Exception as e:
                        print(f"无法读取文件 {filepath}: {e}")
                except Exception as e:
                    print(f"处理文件 {filepath} 时出错: {e}")

    return valid_py_files

def parse_arguments():
    # 获取系统语言
    lang = get_system_language()

    # 中英文帮助信息配置
    help_messages = {
        'en': {
            'description': 'AutoCython',
            'file_help': 'Compile File Path',
            'path_help': 'Compile directory path',
            'conc_help': 'Compile concurrency count (default: 2)',
            'del_help': 'Remove source code after compilation (default: False)',
            'seed_help': 'Set obfuscation random seed for reproducible output',
            'help_help': 'Show help message',
            'version_help': 'Show program version',
            'version_text': f'v{__version__}',
            'required_error': 'The following arguments are required: {}',
            'epilog': 'Example:\n   AutoCython -f demo.py\n   AutoCython -p path'
        },
        'zh': {
            'description': 'AutoCython',
            'file_help': '编译文件路径',
            'path_help': '编译目录路径',
            'conc_help': '编译并发数（默认：2）',
            'del_help': '编译后删除源代码（默认：False）',
            'seed_help': '设置混淆随机种子（用于可复现构建）',
            'help_help': '显示帮助信息',
            'version_help': '显示程序版本',
            'version_text': f'v{__version__}',
            'required_error': '缺少必要参数: {}',
            'epilog': '示例:\n   AutoCython -f demo.py\n   AutoCython -p path'
        }
    }
    msg = help_messages[lang]

    # 创建带自定义错误处理的解析器
    class CustomParser(argparse.ArgumentParser):
        def error(self, message):
            self.print_usage(sys.stderr)
            sys.stderr.write(f'error: {message}\n')
            sys.exit(2)

    # 配置参数解析器
    parser = CustomParser(
        description=msg['description'],
        epilog=msg['epilog'],
        add_help=False,
        formatter_class=argparse.RawTextHelpFormatter
    )

    # 添加参数定义（文件与目录互斥）
    input_group = parser.add_mutually_exclusive_group(required=False)
    input_group.add_argument('-f', '--file', type=str, help=msg['file_help'])
    input_group.add_argument('-p', '--path', type=str, help=msg['path_help'])

    optional_group = parser.add_argument_group('optional arguments')
    optional_group.add_argument('-c', '--conc', type=int, default=2, help=msg['conc_help'])
    optional_group.add_argument('-d', '--del', dest='del_source', action='store_true', help=msg['del_help'])
    optional_group.add_argument('--seed', type=int, default=None, help=msg['seed_help'])
    optional_group.add_argument('-h', '--help', action='store_true', help=msg['help_help'])
    optional_group.add_argument('-v', '--version', action='store_true', help=msg['version_help'])

    # 解析参数
    args = parser.parse_args()

    # 处理帮助和版本请求
    if args.help:
        parser.print_help()
        sys.exit(0)

    if args.version:
        print(msg['version_text'])
        sys.exit(0)

    if not args.file and not args.path:
        parser.print_help()
        print(f"\nerror: {msg['required_error'].format('-f/--file, -p/--path')}", file=sys.stderr)
        sys.exit(2)

    return args

def show_no_compilable_files(path):
    lang = get_system_language()

    if lang == 'zh':
        print(f"{path} 目录下没有任何需要编译的文件!")
    else:
        print(f"The {path} directory does not contain any files that need to be compiled!")

def show_file_not_found(file):
    lang = get_system_language()

    if lang == 'zh':
        print(f"文件 {file} 不存在!")
    else:
        print(f"File {file} does not exist!")

def show_path_not_found(path):
    lang = get_system_language()

    if lang == 'zh':
        print(f"路径 {path} 不存在!")
    else:
        print(f"Path {path} does not exist!")

if __name__ == "__main__":  # pragma: no cover
    args = parse_arguments()
    print(f"文件: {args.file}")
    print(f"路径: {args.path}")
    print(f"并发数: {args.conc}")
