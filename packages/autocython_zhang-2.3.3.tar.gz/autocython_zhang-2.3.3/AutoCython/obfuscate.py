"""AST 混淆模块：去 docstring、去 annotation、局部变量重命名、字符串加密、常量折叠、控制流平坦化、虚假分支"""
import ast
import copy
import hashlib
import random

_UNSAFE_CALLS = frozenset({'globals', 'locals', 'eval', 'exec', 'vars'})
_PATTERN_SKIP_ATTR = '_autocython_skip_literal_obf'


def _has_unsafe_call(node):
    """检查函数体是否包含 globals()/locals()/eval()/exec()/vars() 调用"""
    if hasattr(node, 'body') and isinstance(node.body, list):
        nodes = _walk_no_nested_scope(node.body)
    else:
        nodes = ast.walk(node)
    for child in nodes:
        if isinstance(child, ast.Call) and isinstance(child.func, ast.Name) and child.func.id in _UNSAFE_CALLS:
            return True
    return False


def _walk_no_nested_scope(body):
    """遍历 body 中的节点，不穿透嵌套函数/类定义"""
    for node in body:
        yield node
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue
        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                continue
            yield from _walk_no_nested_scope([child])


def _is_docstring_stmt(stmt):
    """判断语句是否为合法 docstring（仅字符串字面量）"""
    if not isinstance(stmt, ast.Expr):
        return False
    value = stmt.value
    if isinstance(value, ast.Constant):
        return isinstance(value.value, str)
    return isinstance(value, ast.Str)


def _mark_pattern_constants(pattern):
    """标记 match/case pattern 内常量，避免被替换为表达式导致语法失效"""
    for child in ast.walk(pattern):
        if isinstance(child, ast.Constant):
            setattr(child, _PATTERN_SKIP_ATTR, True)


class _DocstringRemover(ast.NodeTransformer):
    """移除 module/class/function 首部的 docstring"""

    def _strip_docstring(self, node):
        if node.body and _is_docstring_stmt(node.body[0]):
            node.body.pop(0)
            if not node.body:
                node.body.append(ast.Pass())
        return node

    def visit_Module(self, node):
        self.generic_visit(node)
        return self._strip_docstring(node)

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        return self._strip_docstring(node)

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self.generic_visit(node)
        return self._strip_docstring(node)


class _AnnotationRemover(ast.NodeTransformer):
    """清除非类体内的变量注解。
    保留函数参数/返回值注解和类体内注解赋值，
    因为 FastAPI/Pydantic/dataclass/attrs 等框架在运行时依赖 __annotations__。"""

    def __init__(self):
        self._scope_stack = ['module']

    def visit_FunctionDef(self, node):
        self._scope_stack.append('function')
        self.generic_visit(node)
        self._scope_stack.pop()
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        self._scope_stack.append('class')
        self.generic_visit(node)
        self._scope_stack.pop()
        if not node.body:
            node.body.append(ast.Pass())
        return node

    def visit_AnnAssign(self, node):
        self.generic_visit(node)
        # 类体内的注解赋值必须保留（Pydantic/dataclass 等框架依赖 __annotations__）
        if self._scope_stack[-1] == 'class':
            return node
        if node.value is not None:
            return ast.Assign(targets=[node.target], value=node.value,
                              lineno=node.lineno, col_offset=node.col_offset)
        return None  # 纯注解无赋值，直接删除


def _collect_nested_free_refs(body, local_names):
    """收集嵌套函数/类中引用的外层变量名（闭包变量）"""
    free = set()
    for node in body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # 嵌套函数自己的局部名
            nested_locals = set()
            # nonlocal/global 声明的变量不是局部变量
            nonlocal_names = set()
            for child in _walk_no_nested_scope(node.body):
                if isinstance(child, (ast.Nonlocal, ast.Global)):
                    nonlocal_names.update(child.names)
            for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
                nested_locals.add(arg.arg)
            if node.args.vararg:
                nested_locals.add(node.args.vararg.arg)
            if node.args.kwarg:
                nested_locals.add(node.args.kwarg.arg)
            for child in _walk_no_nested_scope(node.body):
                if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                    if child.id not in nonlocal_names:
                        nested_locals.add(child.id)
            # 嵌套函数中读取的、属于外层 local_names 且不被自身遮蔽的名字
            for child in ast.walk(node):
                if isinstance(child, ast.Name) and child.id in local_names and child.id not in nested_locals:
                    free.add(child.id)
        elif isinstance(node, ast.ClassDef):
            # 类体中直接引用的外层变量
            for child in _walk_no_nested_scope(node.body):
                if isinstance(child, ast.Name) and child.id in local_names and isinstance(child.ctx, ast.Load):
                    free.add(child.id)
            free |= _collect_nested_free_refs(node.body, local_names)
        else:
            # 递归搜索所有子节点中的嵌套函数/类（穿透 Try/With/For/If 等）
            for child in ast.walk(node):
                if child is node:
                    continue
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    free |= _collect_nested_free_refs([child], local_names)
    return free


def _hash_name(name, salt):
    """基于原名+salt生成短 hash 标识符，避免明显的序号模式"""
    h = hashlib.md5(f'{salt}:{name}'.encode()).hexdigest()[:8]
    return f'_{h}'


class _LocalVarRenamer(ast.NodeTransformer):
    """函数作用域内的局部变量重命名为 hash-based 短标识符"""

    def _rename_function(self, node):
        if _has_unsafe_call(node):
            self.generic_visit(node)
            return node

        # 收集参数名（不重命名）
        param_names = set()
        for arg in node.args.args + node.args.posonlyargs + node.args.kwonlyargs:
            param_names.add(arg.arg)
        if node.args.vararg:
            param_names.add(node.args.vararg.arg)
        if node.args.kwarg:
            param_names.add(node.args.kwarg.arg)

        # 收集局部赋值目标（不穿透嵌套作用域）
        local_names = set()
        # 排除 nonlocal/global 声明的变量
        nonlocal_names = set()
        for child in _walk_no_nested_scope(node.body):
            if isinstance(child, (ast.Nonlocal, ast.Global)):
                nonlocal_names.update(child.names)
            if isinstance(child, ast.Name) and isinstance(child.ctx, ast.Store):
                name = child.id
                if (name not in param_names and name != 'self' and name != 'cls'
                        and not name.startswith('__')):
                    local_names.add(name)
        local_names -= nonlocal_names

        if not local_names:
            self.generic_visit(node)
            return node

        # 排除被嵌套函数引用的闭包变量（重命名会破坏语义）
        closure_refs = _collect_nested_free_refs(node.body, local_names)
        local_names -= closure_refs

        if not local_names:
            self.generic_visit(node)
            return node

        # 构建重命名映射（hash-based，用函数名做 salt 防跨函数碰撞）
        salt = getattr(node, 'name', '')
        rename_map = {name: _hash_name(name, salt) for name in sorted(local_names)}
        # 碰撞检测：若有重复值，回退加序号
        seen = {}
        for name in sorted(local_names):
            h = rename_map[name]
            if h in seen:
                rename_map[name] = f'{h}{len(seen)}'
            seen[h] = name

        # 应用重命名（不穿透嵌套作用域）
        for child in _walk_no_nested_scope(node.body):
            if isinstance(child, ast.Name) and child.id in rename_map:
                child.id = rename_map[child.id]

        # 递归处理嵌套函数/类（它们有自己的作用域）
        self.generic_visit(node)
        return node

    def visit_FunctionDef(self, node):
        return self._rename_function(node)

    visit_AsyncFunctionDef = visit_FunctionDef


class _StringEncryptor(ast.NodeTransformer):
    """将字符串常量替换为 XOR 解密表达式"""

    def __init__(self, rng=None):
        self._rng = rng or random
        self._key = self._rng.randint(1, 255)

    def visit_JoinedStr(self, node):
        return node  # 不处理 f-string

    def visit_match_case(self, node):
        _mark_pattern_constants(node.pattern)
        return self.generic_visit(node)

    def visit_Constant(self, node):
        v = node.value
        if getattr(node, _PATTERN_SKIP_ATTR, False):
            return node
        if not isinstance(v, str) or len(v) <= 1:
            return node
        key = self._key
        enc = bytes(b ^ key for b in v.encode('utf-8'))
        # bytes(enc_literal).translate(bytes.maketrans(range(256), bytes(b^KEY for b in range(256)))).decode()
        # 简化为：直接存加密后的 bytes 常量，用 translate 解密
        # 构建 XOR 转换表作为常量
        table_bytes = bytes(b ^ key for b in range(256))
        return ast.Call(
            func=ast.Attribute(
                value=ast.Call(
                    func=ast.Attribute(
                        value=ast.Constant(value=enc),
                        attr='translate',
                        ctx=ast.Load(),
                    ),
                    args=[ast.Call(
                        func=ast.Attribute(
                            value=ast.Name(id='bytes', ctx=ast.Load()),
                            attr='maketrans',
                            ctx=ast.Load(),
                        ),
                        args=[
                            ast.Constant(value=bytes(range(256))),
                            ast.Constant(value=table_bytes),
                        ],
                        keywords=[],
                    )],
                    keywords=[],
                ),
                attr='decode',
                ctx=ast.Load(),
            ),
            args=[],
            keywords=[],
        )


class _ConstantFoldingObfuscator(ast.NodeTransformer):
    """将整数常量拆分为算术表达式"""

    def __init__(self, rng=None):
        self._rng = rng or random

    def visit_match_case(self, node):
        _mark_pattern_constants(node.pattern)
        return self.generic_visit(node)

    def visit_Constant(self, node):
        v = node.value
        if getattr(node, _PATTERN_SKIP_ATTR, False):
            return node
        if isinstance(v, bool) or not isinstance(v, int):
            return node
        if v in (0, 1) or v < 0 or v > 10000:
            return node
        return self._decompose_2layer(v)

    def _decompose_1layer(self, n):
        if n <= 1:
            return ast.Constant(value=n)
        # 尝试找因子
        for d in range(2, min(int(n**0.5) + 1, 100)):
            if n % d == 0:
                return ast.BinOp(
                    left=ast.Constant(value=d),
                    op=ast.Mult(),
                    right=ast.Constant(value=n // d),
                )
        # 加法拆分
        a = self._rng.randint(1, n - 1)
        return ast.BinOp(
            left=ast.Constant(value=a),
            op=ast.Add(),
            right=ast.Constant(value=n - a),
        )

    def _decompose_2layer(self, n):
        a = self._rng.randint(1, n - 1)
        b = n - a
        return ast.BinOp(
            left=self._decompose_1layer(a),
            op=ast.Add(),
            right=self._decompose_1layer(b),
        )


class _ControlFlowFlattener(ast.NodeTransformer):
    """将函数体转换为 while True + 状态机调度"""

    def __init__(self, rng=None):
        self._rng = rng or random

    def visit_FunctionDef(self, node):
        self.generic_visit(node)  # 先递归处理嵌套
        if self._should_skip(node):
            return node
        node.body = self._flatten_body(node.body)
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def _should_skip(self, node):
        if isinstance(node, ast.AsyncFunctionDef):
            return True
        if _has_unsafe_call(node):
            return True
        if len(node.body) < 3:
            return True
        for child in _walk_no_nested_scope(node.body):
            if isinstance(child, (ast.Yield, ast.YieldFrom)):
                return True
            # nonlocal/global 变量在状态机分支中会被 Cython 误判为未赋值
            if isinstance(child, (ast.Nonlocal, ast.Global)):
                return True
        # comprehension 在 while True 状态机内会触发 Cython ControlFlowAnalysis crash
        for child in _walk_no_nested_scope(node.body):
            if isinstance(child, (ast.ListComp, ast.SetComp, ast.DictComp, ast.GeneratorExp)):
                return True
        return False

    def _flatten_body(self, stmts):
        states = self._rng.sample(range(100, 999), len(stmts) + 1)
        # states[0] = 初始, states[1..n] = 各语句, states[-1] = 终止(break)
        state_var = '_s'
        cases = []
        for i, stmt in enumerate(stmts):
            test = ast.Compare(
                left=ast.Name(id=state_var, ctx=ast.Load()),
                ops=[ast.Eq()],
                comparators=[ast.Constant(value=states[i])],
            )
            body = [stmt]
            # return 语句不追加状态转移
            if not isinstance(stmt, ast.Return):
                if i < len(stmts) - 1:
                    body.append(ast.Assign(
                        targets=[ast.Name(id=state_var, ctx=ast.Store())],
                        value=ast.Constant(value=states[i + 1]),
                    ))
                else:
                    body.append(ast.Break())
            cases.append((test, body))

        # 构建 if/elif 链
        if_node = None
        for test, body in reversed(cases):
            if if_node is None:
                if_node = ast.If(test=test, body=body, orelse=[])
            else:
                if_node = ast.If(test=test, body=body, orelse=[if_node])

        return [
            ast.Assign(
                targets=[ast.Name(id=state_var, ctx=ast.Store())],
                value=ast.Constant(value=states[0]),
            ),
            ast.While(
                test=ast.Constant(value=True),
                body=[if_node],
                orelse=[],
            ),
        ]


class _OpaquePredicateInserter(ast.NodeTransformer):
    """在函数体中插入永真/永假虚假分支"""

    _PREDICATES_TRUE = [
        # n * n >= 0
        lambda: ast.Compare(
            left=ast.BinOp(
                left=ast.Constant(value=7),
                op=ast.Mult(),
                right=ast.Constant(value=7),
            ),
            ops=[ast.GtE()],
            comparators=[ast.Constant(value=0)],
        ),
        # isinstance(1, int)
        lambda: ast.Call(
            func=ast.Name(id='isinstance', ctx=ast.Load()),
            args=[ast.Constant(value=1), ast.Name(id='int', ctx=ast.Load())],
            keywords=[],
        ),
        # len([0]) > 0
        lambda: ast.Compare(
            left=ast.Call(
                func=ast.Name(id='len', ctx=ast.Load()),
                args=[ast.List(elts=[ast.Constant(value=0)], ctx=ast.Load())],
                keywords=[],
            ),
            ops=[ast.Gt()],
            comparators=[ast.Constant(value=0)],
        ),
    ]

    _DEAD_CODE = [
        lambda: ast.Assign(
            targets=[ast.Name(id='_', ctx=ast.Store())],
            value=ast.Constant(value=0),
        ),
        lambda: ast.Pass(),
    ]

    def __init__(self, rng=None):
        self._rng = rng or random

    def visit_FunctionDef(self, node):
        self.generic_visit(node)
        if _has_unsafe_call(node):
            return node
        node.body = self._insert_predicates(node.body)
        return node

    visit_AsyncFunctionDef = visit_FunctionDef

    def _insert_predicates(self, stmts):
        result = []
        for stmt in stmts:
            result.append(stmt)
            if self._rng.random() < 0.3:
                pred = self._rng.choice(self._PREDICATES_TRUE)()
                dead = self._rng.choice(self._DEAD_CODE)()
                if self._rng.random() < 0.5:
                    # 永真分支：真分支有原始无害代码，假分支有死代码
                    result.append(ast.If(test=pred, body=[ast.Pass()], orelse=[dead]))
                else:
                    # 永假分支（取反）
                    result.append(ast.If(
                        test=ast.UnaryOp(op=ast.Not(), operand=pred),
                        body=[dead],
                        orelse=[],
                    ))
        return result


def obfuscate_source(source_code: str, seed=None) -> str:
    """对源码执行七重 AST 变换：去 docstring、去 annotation、局部变量重命名、
    字符串加密、常量折叠、控制流平坦化、虚假分支。
    ast.unparse() 天然丢弃所有注释。

    :param seed: 随机种子；传入后可复现混淆结果
    """
    if not source_code.strip():
        return source_code
    rng = random.Random(seed) if seed is not None else random
    tree = ast.parse(source_code)
    tree = _DocstringRemover().visit(tree)
    tree = _AnnotationRemover().visit(tree)
    tree = _LocalVarRenamer().visit(tree)
    tree = _ControlFlowFlattener(rng=rng).visit(tree)
    tree = _OpaquePredicateInserter(rng=rng).visit(tree)
    tree = _StringEncryptor(rng=rng).visit(tree)
    tree = _ConstantFoldingObfuscator(rng=rng).visit(tree)
    ast.fix_missing_locations(tree)
    return ast.unparse(tree)
