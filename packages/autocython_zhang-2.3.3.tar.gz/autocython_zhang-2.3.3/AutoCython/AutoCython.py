import os
import sys
from .run_tasks import run_tasks
from .compile import compile_to_binary
from .tools import parse_arguments, find_python_files
from .tools import show_no_compilable_files, show_file_not_found, show_path_not_found

def compile():
    try:
        args = parse_arguments()
        obfuscate_seed = args.seed

        if args.file:
            if os.path.isfile(args.file):
                compile_file = args.file
                del_source = args.del_source
                tasks = [
                    # 函数, 位置参数, 关键字参数
                    (compile_to_binary, compile_file, (compile_file, del_source, True, obfuscate_seed), {}),
                ]
                run_tasks(tasks, max_workers=1, raise_on_failure=True) # 执行编译
            else:
                show_file_not_found(args.file)
        elif args.path:
            if os.path.exists(args.path) and not os.path.isfile(args.path):
                compile_file_list = find_python_files(args.path)
                if compile_file_list:
                    del_source = args.del_source
                    tasks = []
                    for compile_file in compile_file_list:
                        tasks.append(
                            # 函数, 位置参数, 关键字参数
                            (compile_to_binary, compile_file, (compile_file, del_source, True, obfuscate_seed), {}),
                        )
                    run_tasks(tasks, max_workers=args.conc, raise_on_failure=True) # 执行编译
                else:
                    show_no_compilable_files(args.path)
            else:
                show_path_not_found(args.path)
    except KeyboardInterrupt:
        sys.exit(130)
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
