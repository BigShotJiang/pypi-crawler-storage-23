#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""版本号模块 - 单一版本号来源"""

__version__ = "2.3.3"
