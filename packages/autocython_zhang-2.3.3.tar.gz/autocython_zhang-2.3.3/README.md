# AutoCython

> 自动将 Python 源码编译为 Cython 二进制扩展（`.so`/`.pyd`），支持七重 AST 混淆、并发编译、跨平台运行。

[![PyPI](https://img.shields.io/pypi/v/AutoCython-zhang)](https://pypi.org/project/AutoCython-zhang/)
[![Python](https://img.shields.io/pypi/pyversions/AutoCython-zhang)](https://pypi.org/project/AutoCython-zhang/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

## 概述

AutoCython 是一个 Python 源码保护工具，通过 Cython 编译 + AST 混淆双重手段，将 `.py` 文件转换为不可逆的二进制扩展模块。适用于商业项目源码保护、SDK 分发、知识产权保护等场景。

## 特性

- **一键编译** — 单文件 (`-f`) 或整目录 (`-p`) 批量编译为 `.so`/`.pyd`
- **七重 AST 混淆** — docstring 移除、注解清除、局部变量重命名、字符串 XOR 加密、常量折叠、控制流平坦化、虚假分支注入
- **并发编译** — 基于 `ThreadPoolExecutor` 的多线程并行编译，可配置并发数
- **实时进度面板** — 基于 Rich 的实时任务状态表格、进度条、耗时统计
- **跨平台** — 支持 Linux、macOS、Windows，自动适配 `.so`/`.pyd` 扩展名
- **可复现构建** — 通过 `--seed` 参数固定混淆随机种子
- **智能排除** — 自动跳过 `__init__.py`、虚拟环境、构建目录；支持 `# AutoCython No Compile` 标记豁免
- **中英双语** — CLI 帮助信息和进度面板自动适配系统语言

## 安装

```bash
pip install AutoCython-zhang
```

### 依赖

| 包 | 用途 |
|---|------|
| `cython` | Python → C 编译核心 |
| `setuptools` | 构建扩展模块 |
| `rich` | 终端实时进度面板 |

## 使用方法

### 编译单文件

```bash
AutoCython -f demo.py
```

### 编译整个目录

```bash
AutoCython -p ./my_project
```

### 常用选项

```bash
AutoCython -p ./src -c 4          # 4 线程并发编译
AutoCython -f main.py -d          # 编译后删除源文件
AutoCython -p ./src --seed 42     # 固定混淆种子（可复现）
AutoCython -v                     # 查看版本
AutoCython -h                     # 查看帮助
```

### 排除文件

在文件头两行内添加注释即可跳过编译：

```python
# AutoCython No Compile
```

### 作为库调用

```python
from AutoCython.compile import compile_to_binary

# 编译单文件
output = compile_to_binary("demo.py", del_source=False, obfuscate=True, obfuscate_seed=42)
print(f"生成: {output}")
```

## API 概览

### 核心函数

| 函数 | 模块 | 描述 |
|------|------|------|
| `compile()` | `AutoCython.AutoCython` | 主入口：解析参数并调度编译任务 |
| `compile_to_binary()` | `AutoCython.compile` | 将单个 `.py` 文件编译为二进制扩展 |
| `obfuscate_source()` | `AutoCython.obfuscate` | 对源码执行七重 AST 混淆变换 |
| `run_tasks()` | `AutoCython.run_tasks` | 并发任务执行引擎（含实时进度面板） |
| `find_python_files()` | `AutoCython.tools` | 递归扫描目录下的可编译 `.py` 文件 |
| `parse_arguments()` | `AutoCython.tools` | CLI 参数解析（中英双语） |
| `get_platform_extension()` | `AutoCython.compile` | 返回当前平台的二进制扩展名 |
| `get_system_language()` | `AutoCython.tools` | 检测系统语言（`zh`/`en`） |

## 目录结构

```
AutoCython/
├── AutoCython/
│   ├── __init__.py          # 包入口，导出 compile() 和 main()
│   ├── _version.py          # 单一版本号来源
│   ├── AutoCython.py        # 主编译调度逻辑
│   ├── compile.py           # Cython 编译核心（临时目录隔离）
│   ├── obfuscate.py         # 七重 AST 混淆引擎
│   ├── run_tasks.py         # 并发任务执行 + Rich 实时面板
│   └── tools.py             # CLI 参数解析、文件扫描、国际化
├── tests/
│   ├── test_autocython.py   # 主入口集成测试
│   ├── test_compile.py      # 编译功能单元测试
│   ├── test_obfuscate.py    # 混淆引擎单元测试
│   ├── test_obfuscate_advanced.py  # 混淆高级场景测试
│   ├── test_obfuscate_anti.py      # 混淆反模式/边界测试
│   ├── test_compile_anti.py        # 编译反模式测试
│   ├── test_run_tasks.py    # 任务执行器测试
│   ├── test_tools.py        # 工具函数测试
│   └── kd_dist/             # 知识蒸馏测试集（编译矩阵 + 行为等价）
├── pyproject.toml           # 项目配置与构建定义
├── requirements.txt         # 依赖清单
├── LICENSE                  # MIT 许可证
└── DESIGN.md                # 设计文档
```

## 相关文档

- [设计文档](DESIGN.md)
- [PyPI 主页](https://pypi.org/project/AutoCython-zhang/)
- [GitHub 仓库](https://github.com/zhang0281/AutoCython)
