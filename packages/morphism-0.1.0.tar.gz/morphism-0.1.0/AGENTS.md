# AGENTS — Morphism Systems Governance

This monorepo is governed by the **Morphism Categorical Governance Framework**.

<!-- SSOT:governance-authority:begin -->## Governance Source

| Authority | Location |
|-----------|----------|
| Root governance | [AGENTS.md](AGENTS.md) (this file) |
| SSOT | [SSOT.md](SSOT.md) |
| Guidelines | [GUIDELINES.md](GUIDELINES.md) |
| Consumer config | [.morphism/](.morphism/) |

## Scope

This file governs the morphism-systems monorepo. All directories, packages, and scripts listed below fall under this governance framework.

## Monorepo Scope

| Directory | Governance Level | Notes |
|-----------|-----------------|-------|
| `apps/morphism/` | **Monorepo app** | Next.js app — follow TS conventions |
| `packages/shared/` | **Shared package** | `@morphism-systems/shared` — shared TS utilities |
| `packages/agentic-math/` | **npm package** | `@morphism-systems/agentic-math` — MCP math server |
| `packages/mcp-server/` | **npm package** | `@morphism-systems/mcp-server` — governance MCP server |
| `packages/cli/` | **npm package** | `@morphism-systems/cli` — governance CLI |
| `packages/plugin-bundle/` | **npm package** | `@morphism-systems/plugin-bundle` — one-command installer |
| `src/morphism/` | **Python core** | Category theory engine + CLI |
| `docs/`, `scripts/` | **Governance** | Documentation and automation |
| `archive/` | **Read-only** | Historical artifacts |

## Protocol

1. Read governance docs before structural changes
2. State the one thing
3. Verify the path
4. Execute incrementally
5. Refuse scope creep

Full agent protocol, refusal/trace templates, and checklists: [docs/governance/agent-kernel-prompt.md](docs/governance/agent-kernel-prompt.md).

Deferred work: track in [docs/TODO.md](docs/TODO.md) (date \| priority \| area \| owner \| task \| next-step).

## Commands

```bash
# Validate TypeScript
npx turbo typecheck && npx turbo lint && npx turbo test

# Validate Python
ruff check src/ tests/ && mypy src/ && pytest tests/
```

Full testing commands: [docs/TEST_COMMANDS.md](docs/TEST_COMMANDS.md).

On Windows, Turbo requires the `turbo-windows-64` optional dependency for local builds.

<!-- SSOT:governance-authority:end -->
