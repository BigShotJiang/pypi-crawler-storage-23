import * as Sentry from '@sentry/nextjs'

// Only initialize when a DSN is provided; keeps local/dev clean
if (process.env.NEXT_PUBLIC_SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
    environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
    // APM + RUM defaults — tune in Sentry if needed
    tracesSampleRate: 0.2,
    profilesSampleRate: 0.2,
    replaysOnErrorSampleRate: 1.0,
    replaysSessionSampleRate: 0.1,
  })
}
