import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@morphism-systems/shared/supabase/server'
import { z } from 'zod'
import { createHash } from 'crypto'
import * as Sentry from '@sentry/nextjs'

const driftReportSchema = z.object({
  agent_name: z.string().min(1),
  session_id: z.string().optional(),
  drift_score: z.number().min(0).max(100),
  contradictions: z.array(z.object({
    rule: z.string(),
    expected: z.string(),
    actual: z.string(),
    severity: z.enum(['low', 'medium', 'high', 'critical']).default('medium'),
  })).optional().default([]),
  metadata: z.record(z.unknown()).optional().default({}),
})

// Authenticate via API key (Bearer token)
async function authenticateApiKey(req: NextRequest) {
  const authHeader = req.headers.get('authorization')
  if (!authHeader?.startsWith('Bearer mk_live_')) {
    return null
  }

  const rawKey = authHeader.slice(7) // Remove "Bearer "
  const keyHash = createHash('sha256').update(rawKey).digest('hex')

  const admin = createAdminClient()
  const { data: apiKey } = await admin
    .from('api_keys')
    .select('id, org_id')
    .eq('key_hash', keyHash)
    .single()

  if (!apiKey) return null

  // Update last used
  await admin
    .from('api_keys')
    .update({ last_used_at: new Date().toISOString() })
    .eq('id', apiKey.id)

  return apiKey
}

export async function POST(req: NextRequest) {
  try {
    const apiKey = await authenticateApiKey(req)
    if (!apiKey) {
      return NextResponse.json(
        { error: 'Invalid or missing API key. Use: Authorization: Bearer mk_live_...' },
        { status: 401 }
      )
    }

    const body = await req.json()
    const parsed = driftReportSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const admin = createAdminClient()

    // Find the agent by name within this org
    const { data: agent } = await admin
      .from('agents')
      .select('id, drift_score, sessions_count')
      .eq('org_id', apiKey.org_id)
      .eq('name', parsed.data.agent_name)
      .single()

    if (!agent) {
      return NextResponse.json(
        { error: `Agent "${parsed.data.agent_name}" not found in this organization` },
        { status: 404 }
      )
    }

    // Update agent drift score (exponential moving average)
    const alpha = 0.3 // Smoothing factor
    const newDrift = alpha * parsed.data.drift_score + (1 - alpha) * agent.drift_score

    await admin
      .from('agents')
      .update({
        drift_score: Math.round(newDrift * 10) / 10,
        sessions_count: agent.sessions_count + 1,
        last_active: new Date().toISOString(),
      })
      .eq('id', agent.id)

    // Create assessment if drift is significant
    if (parsed.data.drift_score > 25) {
      await admin
        .from('assessments')
        .insert({
          org_id: apiKey.org_id,
          agent_id: agent.id,
          title: `Drift Alert: ${parsed.data.agent_name} (score: ${parsed.data.drift_score})`,
          type: 'drift',
          status: 'completed',
          risk_score: parsed.data.drift_score,
          findings: parsed.data.contradictions.map((c, i) => ({
            id: `D${i + 1}`,
            severity: c.severity,
            title: `Rule violation: ${c.rule}`,
            description: `Expected: "${c.expected}" — Got: "${c.actual}"`,
          })),
          recommendations: [
            'Review agent system prompt for consistency',
            'Check if governance rules have been updated recently',
            parsed.data.drift_score > 50
              ? 'CRITICAL: Consider pausing this agent until drift is resolved'
              : 'Monitor over next 5 sessions',
          ],
          completed_at: new Date().toISOString(),
        })
    }

    // Audit log
    await admin.from('audit_log').insert({
      org_id: apiKey.org_id,
      action: 'drift.reported',
      actor: 'api_key',
      resource_type: 'agent',
      resource_id: agent.id,
      metadata: {
        drift_score: parsed.data.drift_score,
        new_ema: newDrift,
        contradictions_count: parsed.data.contradictions.length,
        session_id: parsed.data.session_id,
      },
    })

    return NextResponse.json({
      received: true,
      agent_id: agent.id,
      updated_drift_score: Math.round(newDrift * 10) / 10,
      alert_created: parsed.data.drift_score > 25,
    })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/drift-report] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
