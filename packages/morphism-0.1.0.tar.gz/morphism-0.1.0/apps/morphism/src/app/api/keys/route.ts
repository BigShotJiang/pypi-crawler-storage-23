import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createSupabaseClient, createAdminClient } from '@morphism-systems/shared/supabase/server'
import { z } from 'zod'
import { randomBytes } from 'crypto'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

// ── GET: List API keys ──────────────────────────────────────────────────────

export async function GET() {
  try {
    const supabase = await createSupabaseClient()
    const { data, error } = await supabase
      .from('api_keys')
      .select('id, name, prefix, last_used_at, created_at')
      .order('created_at', { ascending: false })

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ keys: data })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/keys] GET error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// ── POST: Create API key ────────────────────────────────────────────────────

const createKeySchema = z.object({
  name: z.string().min(1).max(100),
})

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = createKeySchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = await createSupabaseClient()
    const { data: org } = await supabase.from('organizations').select('id').single()
    if (!org) return NextResponse.json({ error: 'Organization not found' }, { status: 404 })

    // Generate API key: mk_live_<32 random hex chars>
    const rawKey = `mk_live_${randomBytes(32).toString('hex')}`
    const prefix = rawKey.slice(0, 12) + '...'

    // Hash the key for storage (sha256)
    const { createHash } = await import('crypto')
    const keyHash = createHash('sha256').update(rawKey).digest('hex')

    const admin = createAdminClient()
    const { data, error } = await admin
      .from('api_keys')
      .insert({
        org_id: org.id,
        name: parsed.data.name,
        key_hash: keyHash,
        prefix,
      })
      .select('id, name, prefix, created_at')
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    // Audit log
    await admin.from('audit_log').insert({
      org_id: org.id,
      action: 'api_key.created',
      actor: orgId,
      resource_type: 'api_key',
      resource_id: data.id,
      metadata: { name: parsed.data.name },
    })

    // Return raw key ONCE — never stored in plain text
    return NextResponse.json({ key: rawKey, ...data }, { status: 201 })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/keys] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

// ── DELETE: Revoke API key ──────────────────────────────────────────────────

export async function DELETE(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { searchParams } = new URL(req.url)
    const keyId = searchParams.get('id')
    if (!keyId) return NextResponse.json({ error: 'Missing key id' }, { status: 400 })

    const supabase = await createSupabaseClient()
    const { error } = await supabase
      .from('api_keys')
      .delete()
      .eq('id', keyId)

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    // Audit log
    const { data: org } = await supabase.from('organizations').select('id').single()
    if (org) {
      const admin = createAdminClient()
      await admin.from('audit_log').insert({
        org_id: org.id,
        action: 'api_key.revoked',
        actor: orgId,
        resource_type: 'api_key',
        resource_id: keyId,
      })
    }

    return NextResponse.json({ deleted: true })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/keys] DELETE error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
