import { NextRequest, NextResponse } from 'next/server'
import { Webhook } from 'svix'
import { createAdminClient } from '@morphism-systems/shared/supabase/server'
import * as Sentry from '@sentry/nextjs'

interface WebhookEvent {
  type: string
  data: Record<string, unknown>
}

export async function POST(req: NextRequest) {
  const WEBHOOK_SECRET = process.env.CLERK_WEBHOOK_SECRET
  if (!WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Webhook secret not configured' }, { status: 500 })
  }

  // Verify signature
  const svix_id = req.headers.get('svix-id')
  const svix_timestamp = req.headers.get('svix-timestamp')
  const svix_signature = req.headers.get('svix-signature')

  if (!svix_id || !svix_timestamp || !svix_signature) {
    return NextResponse.json({ error: 'Missing svix headers' }, { status: 400 })
  }

  const body = await req.text()

  let event: WebhookEvent
  try {
    const wh = new Webhook(WEBHOOK_SECRET)
    event = wh.verify(body, {
      'svix-id': svix_id,
      'svix-timestamp': svix_timestamp,
      'svix-signature': svix_signature,
    }) as WebhookEvent
  } catch {
    return NextResponse.json({ error: 'Invalid signature' }, { status: 401 })
  }

  const admin = createAdminClient()

  try {
    switch (event.type) {
      case 'organization.created': {
        const { id, name, slug } = event.data as { id: string; name: string; slug: string }
        const { error } = await admin.from('organizations').insert({
          clerk_org_id: id,
          name,
          slug: slug || id,
          plan: 'free',
          agent_limit: 5,
        })
        if (error) console.error('Failed to create org:', error)
        break
      }

      case 'organization.updated': {
        const { id, name, slug } = event.data as { id: string; name: string; slug: string }
        const { error } = await admin
          .from('organizations')
          .update({ name, slug: slug || id })
          .eq('clerk_org_id', id)
        if (error) console.error('Failed to update org:', error)
        break
      }

      case 'organization.deleted': {
        const { id } = event.data as { id: string }
        const { error } = await admin
          .from('organizations')
          .delete()
          .eq('clerk_org_id', id)
        if (error) console.error('Failed to delete org:', error)
        break
      }

      default:
        console.log(`Unhandled webhook event: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[clerk webhook] Processing error:', e)
    return NextResponse.json({ error: 'Webhook processing error' }, { status: 500 })
  }
}
