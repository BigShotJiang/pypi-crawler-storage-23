import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { validateGovernance } from '@morphism-systems/shared/ai'
import { createSupabaseClient, createAdminClient } from '@morphism-systems/shared/supabase/server'
import { validateSchema } from '@morphism-systems/shared/schemas'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = validateSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = await createSupabaseClient()

    // Load org policies if requested
    let policies: Array<{ name: string; rules: string[] }> | undefined
    if (parsed.data.include_policies) {
      const { data: policyData } = await supabase
        .from('governance_policies')
        .select('name, rules')
        .eq('is_active', true)
      policies = policyData ?? undefined
    }

    // Run validation
    const result = await validateGovernance({
      text: parsed.data.text,
      framework: parsed.data.framework,
      policies,
    })

    // Audit log
    const { data: org } = await supabase.from('organizations').select('id').single()
    if (org) {
      const admin = createAdminClient()
      await admin.from('audit_log').insert({
        org_id: org.id,
        action: 'validation.run',
        actor: orgId,
        resource_type: 'validation',
        metadata: {
          score: result.score,
          violations_count: result.violations.length,
          framework: parsed.data.framework,
          policies_checked: result.policies_checked,
        },
      })
    }

    return NextResponse.json(result)
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/validate] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
