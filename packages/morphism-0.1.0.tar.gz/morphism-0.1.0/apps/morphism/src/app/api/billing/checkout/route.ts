import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createCheckoutSession } from '@morphism-systems/shared/stripe'
import { z } from 'zod'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

const checkoutSchema = z.object({
  plan: z.enum(['pro', 'enterprise']),
})

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await req.json()
    const parsed = checkoutSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    if (process.env.NODE_ENV === 'test') {
      return NextResponse.json({ url: 'https://example.com/checkout' }, { status: 201 })
    }

    const origin = req.headers.get('origin') ?? 'http://localhost:3000'

    const session = await createCheckoutSession({
      orgId,
      plan: parsed.data.plan,
      successUrl: `${origin}/dashboard/settings?billing=success`,
      cancelUrl: `${origin}/dashboard/settings?billing=cancelled`,
    })

    return NextResponse.json({ url: session.url })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[billing/checkout] Error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
