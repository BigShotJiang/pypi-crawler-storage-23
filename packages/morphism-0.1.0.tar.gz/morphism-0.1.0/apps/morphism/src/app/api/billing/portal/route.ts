import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createBillingPortalSession } from '@morphism-systems/shared/stripe'
import { createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const supabase = await createSupabaseClient()
    const { data: org } = await supabase
      .from('organizations')
      .select('stripe_customer_id')
      .single()

    if (!org?.stripe_customer_id) {
      return NextResponse.json(
        { error: 'No billing account found. Subscribe to a plan first.' },
        { status: 400 }
      )
    }

    const origin = req.headers.get('origin') ?? 'http://localhost:3000'

    const session = await createBillingPortalSession({
      customerId: org.stripe_customer_id,
      returnUrl: `${origin}/dashboard/settings`,
    })

    return NextResponse.json({ url: session.url })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[billing/portal] Error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
