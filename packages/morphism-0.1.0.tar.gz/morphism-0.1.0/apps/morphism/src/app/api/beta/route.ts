import { NextRequest, NextResponse } from 'next/server'
import { createAdminClient } from '@morphism-systems/shared/supabase/server'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'
import { z } from 'zod'
import * as Sentry from '@sentry/nextjs'

const betaSchema = z.object({
  firstName: z.string().min(1).max(100),
  lastName: z.string().max(100).default(''),
  email: z.string().email().max(320),
  company: z.string().max(200).default(''),
  teamSize: z.string().max(50).default(''),
  agentCount: z.string().max(50).default(''),
  painPoint: z.string().max(2000).default(''),
})

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData()
    const csrfToken = form.get('csrfToken')
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
      bodyToken: typeof csrfToken === 'string' ? csrfToken : null,
    })
    if (!csrfValid) {
      return NextResponse.redirect(new URL('/beta?error=csrf', req.url))
    }

    const parsed = betaSchema.safeParse({
      firstName: form.get('firstName'),
      lastName: form.get('lastName'),
      email: form.get('email'),
      company: form.get('company'),
      teamSize: form.get('teamSize'),
      agentCount: form.get('agentCount'),
      painPoint: form.get('painPoint'),
    })

    if (!parsed.success) {
      return NextResponse.redirect(new URL('/beta?error=missing-fields', req.url))
    }

    const entry = {
      ...parsed.data,
      timestamp: new Date().toISOString(),
    }

    // Store in audit log (no org yet — they'll create one on signup)
    try {
      const admin = createAdminClient()
      await admin.from('audit_log').insert({
        org_id: '00000000-0000-0000-0000-000000000000', // placeholder
        action: 'beta.signup',
        actor: entry.email,
        resource_type: 'beta_application',
        metadata: entry,
      })
    } catch {
      // DB may not be provisioned yet — log to console
      console.log('[beta-signup]', JSON.stringify(entry))
    }

    // Redirect to a thank you state (use query param)
    return NextResponse.redirect(new URL('/beta/thank-you', req.url))
  } catch (error) {
    Sentry.captureException(error)
    return NextResponse.redirect(new URL('/beta?error=internal', req.url))
  }
}
