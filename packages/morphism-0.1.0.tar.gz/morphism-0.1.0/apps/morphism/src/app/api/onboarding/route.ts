import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createAdminClient } from '@morphism-systems/shared/supabase/server'
import { z } from 'zod'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

const onboardingSchema = z.object({
  team_size: z.string(),
  llm_providers: z.array(z.string()),
  pain_point: z.string(),
})

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId, userId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = onboardingSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const admin = createAdminClient()

    // Store onboarding data in audit log for now (lightweight)
    const { data: org } = await admin
      .from('organizations')
      .select('id')
      .eq('clerk_org_id', orgId)
      .single()

    if (org) {
      await admin.from('audit_log').insert({
        org_id: org.id,
        action: 'onboarding.completed',
        actor: userId ?? orgId,
        resource_type: 'organization',
        resource_id: org.id,
        metadata: parsed.data,
      })
    }

    return NextResponse.json({ success: true })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/onboarding] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
