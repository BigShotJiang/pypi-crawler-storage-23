import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createAdminClient, createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import { z } from 'zod'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

const feedbackSchema = z.object({
  type: z.enum(['bug', 'feature', 'general']),
  message: z.string().min(1).max(5000),
})

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId, userId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = feedbackSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = await createSupabaseClient()
    const { data: org } = await supabase.from('organizations').select('id').single()

    if (org) {
      const admin = createAdminClient()
      await admin.from('audit_log').insert({
        org_id: org.id,
        action: 'feedback.submitted',
        actor: userId ?? orgId,
        resource_type: 'feedback',
        metadata: {
          type: parsed.data.type,
          message: parsed.data.message,
        },
      })
    }

    // In production, also send to Slack/Discord/email
    console.log(`[feedback] ${parsed.data.type}: ${parsed.data.message.slice(0, 100)}`)

    return NextResponse.json({ received: true })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/feedback] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
