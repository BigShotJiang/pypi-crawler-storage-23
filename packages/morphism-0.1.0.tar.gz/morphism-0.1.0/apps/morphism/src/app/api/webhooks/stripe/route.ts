import { NextRequest, NextResponse } from 'next/server'
import { stripe, PLANS, type PlanKey } from '@morphism-systems/shared/stripe'
import { createAdminClient } from '@morphism-systems/shared/supabase/server'
import Stripe from 'stripe'
import * as Sentry from '@sentry/nextjs'

export async function POST(req: NextRequest) {
  const body = await req.text()
  const signature = req.headers.get('stripe-signature')

  if (!signature || !process.env.STRIPE_WEBHOOK_SECRET) {
    return NextResponse.json({ error: 'Missing signature or webhook secret' }, { status: 400 })
  }

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(body, signature, process.env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    Sentry.captureException(err)
    console.error('[stripe webhook] Signature verification failed:', err)
    return NextResponse.json({ error: 'Invalid signature' }, { status: 400 })
  }

  const admin = createAdminClient()

  try {
    switch (event.type) {
      // ── Checkout completed → activate subscription ──────────────────────
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        const clerkOrgId = session.metadata?.clerk_org_id
        const plan = (session.metadata?.plan ?? 'pro') as PlanKey

        if (!clerkOrgId) {
          console.error('[stripe webhook] Missing clerk_org_id in session metadata')
          break
        }

        const planConfig = PLANS[plan] ?? PLANS.pro

        await admin
          .from('organizations')
          .update({
            plan,
            agent_limit: planConfig.agentLimit,
            stripe_customer_id: session.customer as string,
            stripe_subscription_id: session.subscription as string,
          })
          .eq('clerk_org_id', clerkOrgId)

        await admin.from('audit_log').insert({
          org_id: (
            await admin
              .from('organizations')
              .select('id')
              .eq('clerk_org_id', clerkOrgId)
              .single()
          ).data?.id,
          action: 'billing.subscribed',
          actor: 'stripe',
          resource_type: 'subscription',
          resource_id: session.subscription as string,
          metadata: { plan, customer_id: session.customer },
        })

        console.log(`[stripe webhook] Org ${clerkOrgId} upgraded to ${plan}`)
        break
      }

      // ── Subscription updated (plan change, renewal) ─────────────────────
      case 'customer.subscription.updated': {
        const subscription = event.data.object as Stripe.Subscription
        const clerkOrgId = subscription.metadata?.clerk_org_id
        const plan = (subscription.metadata?.plan ?? 'pro') as PlanKey

        if (!clerkOrgId) break

        const planConfig = PLANS[plan] ?? PLANS.pro

        if (subscription.status === 'active') {
          await admin
            .from('organizations')
            .update({ plan, agent_limit: planConfig.agentLimit })
            .eq('clerk_org_id', clerkOrgId)
        }
        break
      }

      // ── Subscription cancelled or expired ───────────────────────────────
      case 'customer.subscription.deleted': {
        const subscription = event.data.object as Stripe.Subscription
        const clerkOrgId = subscription.metadata?.clerk_org_id

        if (!clerkOrgId) break

        // Downgrade to free
        await admin
          .from('organizations')
          .update({
            plan: 'free',
            agent_limit: PLANS.free.agentLimit,
            stripe_subscription_id: null,
          })
          .eq('clerk_org_id', clerkOrgId)

        const { data: org } = await admin
          .from('organizations')
          .select('id')
          .eq('clerk_org_id', clerkOrgId)
          .single()

        if (org) {
          await admin.from('audit_log').insert({
            org_id: org.id,
            action: 'billing.cancelled',
            actor: 'stripe',
            resource_type: 'subscription',
            resource_id: subscription.id,
            metadata: { previous_plan: subscription.metadata?.plan },
          })
        }

        console.log(`[stripe webhook] Org ${clerkOrgId} downgraded to free`)
        break
      }

      // ── Payment failed ──────────────────────────────────────────────────
      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice
        const customerId = invoice.customer as string

        const { data: org } = await admin
          .from('organizations')
          .select('id, clerk_org_id')
          .eq('stripe_customer_id', customerId)
          .single()

        if (org) {
          await admin.from('audit_log').insert({
            org_id: org.id,
            action: 'billing.payment_failed',
            actor: 'stripe',
            resource_type: 'invoice',
            resource_id: invoice.id,
            metadata: { amount_due: invoice.amount_due, attempt_count: invoice.attempt_count },
          })
        }

        console.log(`[stripe webhook] Payment failed for customer ${customerId}`)
        break
      }

      default:
        console.log(`[stripe webhook] Unhandled event: ${event.type}`)
    }

    return NextResponse.json({ received: true })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[stripe webhook] Processing error:', e)
    return NextResponse.json({ error: 'Webhook processing error' }, { status: 500 })
  }
}
