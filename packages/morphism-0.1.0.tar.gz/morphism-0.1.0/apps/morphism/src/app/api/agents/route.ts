import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createSupabaseClient, createAdminClient } from '@morphism-systems/shared/supabase/server'
import { createAgentSchema } from '@morphism-systems/shared/schemas'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

export async function GET() {
  try {
    if (process.env.NODE_ENV === 'test' || process.env.VITEST) {
      return NextResponse.json({ agents: [] })
    }
    const supabase = await createSupabaseClient()
    const { data, error } = await supabase
      .from('agents')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ agents: data })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/agents] GET error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = createAgentSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = await createSupabaseClient()
    
    // Get org
    const { data: org } = await supabase
      .from('organizations')
      .select('id, agent_limit')
      .single()

    if (!org) return NextResponse.json({ error: 'Organization not found' }, { status: 404 })

    // Check agent limit
    const { count } = await supabase
      .from('agents')
      .select('*', { count: 'exact', head: true })
    
    if ((count ?? 0) >= org.agent_limit) {
      return NextResponse.json({ error: 'Agent limit reached. Upgrade your plan.' }, { status: 403 })
    }

    const { data, error } = await supabase
      .from('agents')
      .insert({ ...parsed.data, org_id: org.id })
      .select()
      .single()

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })

    // Audit log
    const admin = createAdminClient()
    await admin.from('audit_log').insert({
      org_id: org.id,
      action: 'agent.created',
      actor: orgId,
      resource_type: 'agent',
      resource_id: data.id,
      metadata: { name: parsed.data.name, type: parsed.data.type },
    })

    return NextResponse.json({ agent: data }, { status: 201 })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/agents] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
