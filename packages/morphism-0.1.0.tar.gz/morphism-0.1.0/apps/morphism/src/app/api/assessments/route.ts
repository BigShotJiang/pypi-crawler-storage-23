import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs/server'
import { createSupabaseClient, createAdminClient } from '@morphism-systems/shared/supabase/server'
import { assessRisk } from '@morphism-systems/shared/ai'
import { createAssessmentSchema } from '@morphism-systems/shared/schemas'
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

export async function GET() {
  try {
    const supabase = await createSupabaseClient()
    const { data, error } = await supabase
      .from('assessments')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) return NextResponse.json({ error: error.message }, { status: 500 })
    return NextResponse.json({ assessments: data })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/assessments] GET error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(req.headers),
      headerToken: getCsrfHeader(req.headers),
    })
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 })
    }

    const { orgId } = await auth()
    if (!orgId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const parsed = createAssessmentSchema.safeParse(body)
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 })
    }

    const supabase = await createSupabaseClient()
    const { data: org } = await supabase.from('organizations').select('id').single()
    if (!org) return NextResponse.json({ error: 'Organization not found' }, { status: 404 })

    // Create assessment in pending state
    const { data: assessment, error: insertErr } = await supabase
      .from('assessments')
      .insert({
        ...parsed.data,
        org_id: org.id,
        status: 'in_progress',
      })
      .select()
      .single()

    if (insertErr) return NextResponse.json({ error: insertErr.message }, { status: 500 })

    // If risk assessment with agent_id, run AI analysis
    if (parsed.data.type === 'risk' && parsed.data.agent_id) {
      const { data: agent } = await supabase
        .from('agents')
        .select('name, type, model, description')
        .eq('id', parsed.data.agent_id)
        .single()

      if (agent) {
        try {
          const result = await assessRisk(agent)
          await supabase
            .from('assessments')
            .update({
              status: 'completed',
              risk_score: result.risk_score,
              findings: result.findings,
              recommendations: result.recommendations,
              completed_at: new Date().toISOString(),
            })
            .eq('id', assessment.id)
        } catch (e) {
            Sentry.captureException(e)
    console.error('[api/assessments] Risk assessment failed:', e)
          await supabase
            .from('assessments')
            .update({ status: 'failed' })
            .eq('id', assessment.id)
        }
      }
    }

    // Audit log
    const admin = createAdminClient()
    await admin.from('audit_log').insert({
      org_id: org.id,
      action: 'assessment.created',
      actor: orgId,
      resource_type: 'assessment',
      resource_id: assessment.id,
      metadata: { title: parsed.data.title, type: parsed.data.type },
    })

    // Re-fetch to get updated status
    const { data: updated } = await supabase
      .from('assessments')
      .select('*')
      .eq('id', assessment.id)
      .single()

    return NextResponse.json({ assessment: updated ?? assessment }, { status: 201 })
  } catch (e) {
    Sentry.captureException(e)
    console.error('[api/assessments] POST error:', e)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
