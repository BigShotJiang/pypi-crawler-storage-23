/**
 * Credentials API Route
 *
 * Handles CRUD operations for credentials with:
 * - GitHub username extraction from Clerk
 * - RLS context injection for Supabase
 * - Encryption/decryption of values
 * - Access control validation
 * - Audit logging
 */

import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs/server';
import { createClient } from '@morphism-systems/shared/supabase/server';
import { encrypt, decrypt, maskCredential, hash } from '@morphism-systems/shared/encryption';
import { z } from 'zod';
import * as Sentry from '@sentry/nextjs'
import { getCsrfCookie, getCsrfHeader, validateCsrfToken } from '@morphism-systems/shared/csrf'

// Validation schemas
const uuidSchema = z.string().uuid('Invalid credential ID format');

const getQuerySchema = z.object({
  id: z.string().uuid().nullish(),
  key_name: z.string().min(1).max(255).nullish(),
  service: z.string().min(1).max(255).nullish(),
  unmask: z.enum(['true', 'false']).nullish(),
});

const createBodySchema = z.object({
  key_name: z.string().min(1).max(255),
  service: z.string().min(1).max(255),
  value: z.string().min(1),
  metadata: z.object({
    expires_at: z.string().optional(),
    created_by: z.string().optional(),
    purpose: z.string().optional(),
    tags: z.array(z.string()).optional(),
  }).optional(),
});

const updateBodySchema = z.object({
  value: z.string().min(1).optional(),
  metadata: z.object({
    expires_at: z.string().optional(),
    created_by: z.string().optional(),
    purpose: z.string().optional(),
    tags: z.array(z.string()).optional(),
  }).optional(),
  change_reason: z.string().max(500).optional(),
});

// Types
interface Credential {
  id: string;
  org_id: string;
  key_name: string;
  service: string;
  encrypted_value: string;
  encryption_key_id: string;
  metadata: {
    expires_at?: string;
    created_by?: string;
    purpose?: string;
    tags?: string[];
  };
  created_at: string;
  updated_at: string;
}

interface CredentialCreateRequest {
  key_name: string;
  service: string;
  value: string;
  metadata?: Credential['metadata'];
}

interface CredentialUpdateRequest {
  value?: string;
  metadata?: Credential['metadata'];
  change_reason?: string;
}

/**
 * GET /api/credentials
 * List all credentials (values masked) or get a specific credential
 */
export async function GET(request: NextRequest) {
  try {
    const { userId, orgId } = await auth();
    if (!userId || !orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = await createClient();

    // Get GitHub username from Clerk user metadata
    // TODO: This requires Clerk to store GitHub username during OAuth
    // For now, we'll use Clerk user ID as fallback
    const githubUsername = userId; // Replace with actual GitHub username extraction

    // Set RLS context
    await supabase.rpc('set_clerk_org_id', { org_id: orgId });

    // Validate and extract query params
    const { searchParams } = new URL(request.url);
    const queryResult = getQuerySchema.safeParse({
      id: searchParams.get('id'),
      key_name: searchParams.get('key_name'),
      service: searchParams.get('service'),
      unmask: searchParams.get('unmask'),
    });

    if (!queryResult.success) {
      return NextResponse.json({ error: queryResult.error.flatten() }, { status: 400 });
    }

    const { id: credentialId, key_name: keyName, service, unmask: unmaskParam } = queryResult.data;
    const unmask = unmaskParam === 'true';

    if (credentialId) {
      // Get specific credential
      const { data: credential, error } = await supabase
        .from('credentials')
        .select('*')
        .eq('id', credentialId)
        .single();

      if (error) {
        return NextResponse.json({ error: error.message }, { status: 400 });
      }

      if (!credential) {
        return NextResponse.json({ error: 'Credential not found' }, { status: 404 });
      }

      // Check access
      const { data: hasAccess } = await supabase.rpc('has_credential_access', {
        p_github_username: githubUsername,
        p_key_name: credential.key_name,
        p_org_id: credential.org_id,
      });

      if (!hasAccess) {
        return NextResponse.json({ error: 'Access denied' }, { status: 403 });
      }

      // Log access
      await supabase.rpc('log_credential_access', {
        p_org_id: credential.org_id,
        p_key_name: credential.key_name,
        p_accessed_by: githubUsername,
      });

      // Decrypt if unmask requested
      let value = maskCredential(credential.encrypted_value);
      if (unmask) {
        try {
          value = await decrypt(credential.encrypted_value, credential.encryption_key_id);
        } catch (error) {
            Sentry.captureException(error)
    console.error('Decryption error:', error);
          return NextResponse.json({ error: 'Failed to decrypt credential' }, { status: 500 });
        }
      }

      return NextResponse.json({
        ...credential,
        encrypted_value: value,
      });
    }

    // List all credentials
    let query = supabase.from('credentials').select('*');

    if (keyName) {
      query = query.eq('key_name', keyName);
    }

    if (service) {
      query = query.eq('service', service);
    }

    const { data: credentials, error } = await query;

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    // Mask all values
    const maskedCredentials = credentials?.map((cred: Credential) => ({
      ...cred,
      encrypted_value: maskCredential(cred.encrypted_value),
    }));

    return NextResponse.json(maskedCredentials);
  } catch (error) {
    Sentry.captureException(error)
    console.error('GET /api/credentials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/credentials
 * Create a new credential
 */
export async function POST(request: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(request.headers),
      headerToken: getCsrfHeader(request.headers),
    });
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 });
    }

    const { userId, orgId } = await auth();
    if (!userId || !orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = await createClient();
    const githubUsername = userId;

    // Set RLS context
    await supabase.rpc('set_clerk_org_id', { org_id: orgId });

    // Parse and validate request body
    const bodyResult = createBodySchema.safeParse(await request.json());
    if (!bodyResult.success) {
      return NextResponse.json({ error: bodyResult.error.flatten() }, { status: 400 });
    }
    const { key_name, service, value, metadata } = bodyResult.data;

    // Get organization ID
    const { data: org } = await supabase
      .from('organizations')
      .select('id')
      .eq('clerk_org_id', orgId)
      .single();

    if (!org) {
      return NextResponse.json({ error: 'Organization not found' }, { status: 404 });
    }

    // Check access (need admin or owner role)
    const { data: role } = await supabase.rpc('get_user_credential_role', {
      p_github_username: githubUsername,
      p_org_id: org.id,
    });

    if (role !== 'owner' && role !== 'admin') {
      return NextResponse.json(
        { error: 'Insufficient permissions (requires admin or owner role)' },
        { status: 403 }
      );
    }

    // Encrypt the value
    const encryptedValue = await encrypt(value);

    // Insert credential
    const { data: credential, error } = await supabase
      .from('credentials')
      .insert({
        org_id: org.id,
        key_name,
        service,
        encrypted_value: encryptedValue,
        encryption_key_id: 'v1',
        metadata: {
          ...metadata,
          created_by: githubUsername,
        },
      })
      .select()
      .single();

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    // Log the creation
    await supabase.rpc('log_credential_change', {
      p_org_id: org.id,
      p_action: 'credential.create',
      p_key_name: key_name,
      p_changed_by: githubUsername,
      p_reason: 'Created via API',
    });

    return NextResponse.json(
      {
        ...credential,
        encrypted_value: maskCredential(credential.encrypted_value),
      },
      { status: 201 }
    );
  } catch (error) {
    Sentry.captureException(error)
    console.error('POST /api/credentials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/credentials/:id
 * Update a credential (rotates value, creates new version)
 */
export async function PUT(request: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(request.headers),
      headerToken: getCsrfHeader(request.headers),
    });
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 });
    }

    const { userId, orgId } = await auth();
    if (!userId || !orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = await createClient();
    const githubUsername = userId;

    // Set RLS context
    await supabase.rpc('set_clerk_org_id', { org_id: orgId });

    // Validate credential ID from query params
    const { searchParams } = new URL(request.url);
    const rawId = searchParams.get('id');
    const idResult = uuidSchema.safeParse(rawId);

    if (!rawId || !idResult.success) {
      return NextResponse.json({ error: 'Missing or invalid credential ID' }, { status: 400 });
    }
    const credentialId = idResult.data;

    // Parse and validate request body
    const bodyResult = updateBodySchema.safeParse(await request.json());
    if (!bodyResult.success) {
      return NextResponse.json({ error: bodyResult.error.flatten() }, { status: 400 });
    }
    const { value, metadata, change_reason } = bodyResult.data;

    // Get existing credential
    const { data: credential, error: fetchError } = await supabase
      .from('credentials')
      .select('*')
      .eq('id', credentialId)
      .single();

    if (fetchError || !credential) {
      return NextResponse.json({ error: 'Credential not found' }, { status: 404 });
    }

    // Check access
    const { data: hasAccess } = await supabase.rpc('has_credential_access', {
      p_github_username: githubUsername,
      p_key_name: credential.key_name,
      p_org_id: credential.org_id,
    });

    if (!hasAccess) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    // Prepare update object
    const updates: Record<string, unknown> = {
      updated_at: new Date().toISOString(),
    };

    // Encrypt new value if provided
    if (value) {
      updates.encrypted_value = await encrypt(value);
    }

    // Update metadata if provided
    if (metadata) {
      updates.metadata = {
        ...credential.metadata,
        ...metadata,
        updated_by: githubUsername,
      };
    }

    // Set GitHub username for version tracking
    await supabase.rpc('set_github_username', { username: githubUsername });

    // Update credential (trigger will create version)
    const { data: updated, error: updateError } = await supabase
      .from('credentials')
      .update(updates)
      .eq('id', credentialId)
      .select()
      .single();

    if (updateError) {
      return NextResponse.json({ error: updateError.message }, { status: 400 });
    }

    // Log the change
    await supabase.rpc('log_credential_change', {
      p_org_id: credential.org_id,
      p_action: 'credential.update',
      p_key_name: credential.key_name,
      p_changed_by: githubUsername,
      p_reason: change_reason || 'Updated via API',
    });

    return NextResponse.json({
      ...updated,
      encrypted_value: maskCredential(updated.encrypted_value),
    });
  } catch (error) {
    Sentry.captureException(error)
    console.error('PUT /api/credentials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/credentials/:id
 * Delete a credential (soft delete by marking as inactive)
 */
export async function DELETE(request: NextRequest) {
  try {
    const csrfValid = validateCsrfToken({
      cookieToken: getCsrfCookie(request.headers),
      headerToken: getCsrfHeader(request.headers),
    });
    if (!csrfValid) {
      return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 });
    }

    const { userId, orgId } = await auth();
    if (!userId || !orgId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const supabase = await createClient();
    const githubUsername = userId;

    // Set RLS context
    await supabase.rpc('set_clerk_org_id', { org_id: orgId });

    // Validate credential ID from query params
    const { searchParams } = new URL(request.url);
    const rawId = searchParams.get('id');
    const idResult = uuidSchema.safeParse(rawId);

    if (!rawId || !idResult.success) {
      return NextResponse.json({ error: 'Missing or invalid credential ID' }, { status: 400 });
    }
    const credentialId = idResult.data;

    // Get existing credential
    const { data: credential, error: fetchError } = await supabase
      .from('credentials')
      .select('*')
      .eq('id', credentialId)
      .single();

    if (fetchError || !credential) {
      return NextResponse.json({ error: 'Credential not found' }, { status: 404 });
    }

    // Check access (need admin or owner role)
    const { data: role } = await supabase.rpc('get_user_credential_role', {
      p_github_username: githubUsername,
      p_org_id: credential.org_id,
    });

    if (role !== 'owner' && role !== 'admin') {
      return NextResponse.json(
        { error: 'Insufficient permissions (requires admin or owner role)' },
        { status: 403 }
      );
    }

    // Delete credential (hard delete for now, can make soft delete later)
    const { error: deleteError } = await supabase
      .from('credentials')
      .delete()
      .eq('id', credentialId);

    if (deleteError) {
      return NextResponse.json({ error: deleteError.message }, { status: 400 });
    }

    // Log the deletion
    await supabase.rpc('log_credential_change', {
      p_org_id: credential.org_id,
      p_action: 'credential.delete',
      p_key_name: credential.key_name,
      p_changed_by: githubUsername,
      p_reason: 'Deleted via API',
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    Sentry.captureException(error)
    console.error('DELETE /api/credentials error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
