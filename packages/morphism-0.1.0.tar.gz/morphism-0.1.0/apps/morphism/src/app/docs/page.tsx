import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'API Documentation | Morphism',
  description: 'Reference documentation for the Morphism AI Governance API.',
  alternates: {
    canonical: 'https://morphism.systems/docs',
  },
}

function Endpoint({ method, path, desc, auth, body, response }: {
  method: string
  path: string
  desc: string
  auth: string
  body?: string
  response: string
}) {
  const methodColors: Record<string, string> = {
    GET: 'bg-green-100 text-green-700',
    POST: 'bg-blue-100 text-blue-700',
    DELETE: 'bg-red-100 text-red-700',
  }
  return (
    <div className="border rounded-xl overflow-hidden">
      <div className="flex items-center gap-3 px-6 py-4 bg-gray-50 border-b">
        <span className={`px-2 py-1 rounded text-xs font-bold ${methodColors[method] ?? 'bg-gray-100'}`}>
          {method}
        </span>
        <code className="text-sm font-mono">{path}</code>
      </div>
      <div className="px-6 py-4 space-y-4 text-sm">
        <p className="text-gray-600">{desc}</p>
        <div>
          <span className="text-xs font-medium text-gray-400 uppercase">Auth</span>
          <p className="mt-1 font-mono text-xs text-gray-700">{auth}</p>
        </div>
        {body && (
          <div>
            <span className="text-xs font-medium text-gray-400 uppercase">Request Body</span>
            <pre className="mt-1 bg-gray-900 text-gray-100 text-xs p-4 rounded-lg overflow-x-auto">{body}</pre>
          </div>
        )}
        <div>
          <span className="text-xs font-medium text-gray-400 uppercase">Response</span>
          <pre className="mt-1 bg-gray-900 text-gray-100 text-xs p-4 rounded-lg overflow-x-auto">{response}</pre>
        </div>
      </div>
    </div>
  )
}

export default function DocsPage() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="max-w-4xl mx-auto px-6 py-6 flex justify-between items-center border-b">
        <Link href="/" className="text-xl font-bold tracking-tight">◇ morphism</Link>
        <div className="flex gap-4 text-sm">
          <Link href="/beta" className="text-gray-500 hover:text-gray-900">Beta</Link>
          <Link href="/sign-in" className="text-gray-500 hover:text-gray-900">Dashboard</Link>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16 space-y-12">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">API Reference</h1>
          <p className="text-gray-500 mt-2">
            Base URL: <code className="bg-gray-100 px-2 py-0.5 rounded text-sm">https://hub.morphism.systems/api</code>
          </p>
        </div>

        {/* Auth */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Authentication</h2>
          <div className="bg-gray-50 rounded-xl p-6 text-sm space-y-3">
            <p>All API endpoints accept one of two auth methods:</p>
            <ul className="list-disc pl-5 space-y-1 text-gray-600">
              <li><strong>Session cookie</strong> — automatic via the dashboard (Clerk)</li>
              <li><strong>API key</strong> — for CI/CD and external integrations. Create keys in Settings → API Keys.</li>
            </ul>
            <pre className="bg-gray-900 text-gray-100 p-3 rounded-lg text-xs mt-2">
{`curl -X POST https://hub.morphism.systems/api/drift-report \\
  -H "Authorization: Bearer mk_live_abc123..." \\
  -H "Content-Type: application/json" \\
  -d '{"agent_name": "my-agent", "drift_score": 18.5}'`}
            </pre>
          </div>
        </section>

        {/* Endpoints */}
        <section className="space-y-6">
          <h2 className="text-xl font-semibold">Endpoints</h2>

          <Endpoint
            method="POST"
            path="/api/validate"
            desc="Validate an AI agent configuration against Morphism governance axioms using Claude AI."
            auth="Session cookie (Clerk)"
            body={`{
  "config": {
    "name": "support-bot",
    "model": "gpt-4",
    "temperature": 0.7,
    "max_tokens": 4096,
    "system_prompt": "You are a helpful assistant..."
  }
}`}
            response={`{
  "valid": true,
  "violations": [],
  "risk_score": 15,
  "recommendations": ["Add output filtering for PII"]
}`}
          />

          <Endpoint
            method="POST"
            path="/api/drift-report"
            desc="Report a drift score for an agent. Scores are smoothed with exponential moving average (α=0.3). Automatically creates an assessment if drift > 25."
            auth="Bearer API key"
            body={`{
  "agent_name": "support-bot",
  "drift_score": 28.5,
  "metadata": {
    "provider": "openai",
    "region": "us-east-1"
  }
}`}
            response={`{
  "agent_id": "uuid",
  "new_drift_score": 21.3,
  "assessment_created": true,
  "assessment_id": "uuid"
}`}
          />

          <Endpoint
            method="GET"
            path="/api/keys"
            desc="List all API keys for the current organization. Returns prefixes only — full keys are never stored."
            auth="Session cookie (Clerk)"
            response={`{
  "keys": [
    {
      "id": "uuid",
      "name": "CI Pipeline",
      "prefix": "mk_live_a1b2c3d4...",
      "last_used_at": "2026-02-08T...",
      "created_at": "2026-02-07T..."
    }
  ]
}`}
          />

          <Endpoint
            method="POST"
            path="/api/keys"
            desc="Create a new API key. The raw key is returned ONCE and never stored."
            auth="Session cookie (Clerk)"
            body={`{ "name": "CI Pipeline" }`}
            response={`{
  "key": "mk_live_a1b2c3d4e5f6..."
}`}
          />

          <Endpoint
            method="DELETE"
            path="/api/keys?id=uuid"
            desc="Revoke an API key permanently."
            auth="Session cookie (Clerk)"
            response={`{ "deleted": true }`}
          />

          <Endpoint
            method="POST"
            path="/api/assessments"
            desc="Create a new governance assessment with AI-powered risk analysis."
            auth="Session cookie (Clerk)"
            body={`{
  "agent_id": "uuid",
  "assessment_type": "drift",
  "config": { ... }
}`}
            response={`{
  "id": "uuid",
  "risk_score": 42,
  "findings": [
    {
      "severity": "high",
      "category": "drift",
      "description": "Agent output divergence exceeds threshold",
      "recommendation": "Retrain with updated governance constraints"
    }
  ]
}`}
          />

          <Endpoint
            method="GET"
            path="/api/health"
            desc="Health check endpoint."
            auth="None"
            response={`{
  "status": "ok",
  "timestamp": "2026-02-08T..."
}`}
          />
        </section>

        {/* Rate Limits */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">Rate Limits</h2>
          <div className="bg-gray-50 rounded-xl p-6 text-sm text-gray-600">
            <table className="w-full">
              <thead>
                <tr className="text-left text-xs uppercase text-gray-400">
                  <th className="pb-2">Plan</th>
                  <th className="pb-2">Requests / minute</th>
                  <th className="pb-2">Agents</th>
                  <th className="pb-2">Assessments / month</th>
                </tr>
              </thead>
              <tbody className="space-y-2">
                <tr className="border-t"><td className="py-2">Free</td><td>30</td><td>3</td><td>50</td></tr>
                <tr className="border-t"><td className="py-2">Pro</td><td>300</td><td>25</td><td>Unlimited</td></tr>
                <tr className="border-t"><td className="py-2">Enterprise</td><td>Custom</td><td>Unlimited</td><td>Unlimited</td></tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* SDKs */}
        <section className="space-y-4">
          <h2 className="text-xl font-semibold">SDKs &amp; CLI</h2>
          <div className="bg-gray-50 rounded-xl p-6 text-sm text-gray-600">
            <p>Coming soon:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li><code className="bg-gray-200 px-1 rounded">@morphism-systems/sdk</code> — TypeScript/Node.js SDK</li>
              <li><code className="bg-gray-200 px-1 rounded">morphism-py</code> — Python SDK</li>
              <li><code className="bg-gray-200 px-1 rounded">morphism</code> — CLI (Homebrew/npm)</li>
            </ul>
          </div>
        </section>
      </main>

      <footer className="max-w-4xl mx-auto px-6 py-8 border-t text-center text-xs text-gray-400">
        © 2026 Morphism. All rights reserved.
      </footer>
    </div>
  )
}
