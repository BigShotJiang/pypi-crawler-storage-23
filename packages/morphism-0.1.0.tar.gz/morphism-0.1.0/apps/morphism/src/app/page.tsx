'use client'

import {
  Nav,
  Hero,
  Problem,
  HowItWorks,
  CtaBanner,
  Footer,
} from '@/components/landing'

export default function LandingPage() {
  return (
    <div className="landing">
      <Nav />
      <Hero />
      <Problem />
      <HowItWorks />
      <CtaBanner />
      <Footer />
    </div>
  )
}
