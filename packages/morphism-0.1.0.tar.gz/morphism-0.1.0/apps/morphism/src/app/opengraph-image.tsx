import { ImageResponse } from 'next/og'

export const runtime = 'edge'
export const alt = 'Morphism — Structure-Preserving Transformations'
export const size = { width: 1200, height: 630 }
export const contentType = 'image/png'

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          background: '#0a0a0f',
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          fontFamily: 'system-ui, sans-serif',
        }}
      >
        {/* Gradient accent */}
        <div
          style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            height: '4px',
            background: 'linear-gradient(to right, #3b82f6, #06b6d4)',
          }}
        />

        {/* Logo mark */}
        <svg
          width="64"
          height="64"
          viewBox="0 0 40 40"
          fill="none"
          style={{ marginBottom: '24px' }}
        >
          <circle cx="20" cy="20" r="18" stroke="#3b82f6" strokeWidth="1.5" opacity="0.3" />
          <path d="M20 6L34 20L20 34L6 20Z" stroke="#3b82f6" strokeWidth="1.5" opacity="0.6" />
          <path d="M12 20H28M24 16L28 20L24 24" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="20" cy="20" r="2.5" fill="white" opacity="0.8" />
        </svg>

        <div style={{ fontSize: 72, fontWeight: 700, color: 'white', letterSpacing: '-0.02em' }}>
          morphism
        </div>

        <div
          style={{
            fontSize: 28,
            color: '#9ca3af',
            marginTop: '12px',
            letterSpacing: '0.05em',
          }}
        >
          Structure-Preserving Transformations
        </div>

        <div
          style={{
            display: 'flex',
            gap: '32px',
            marginTop: '40px',
            fontSize: 16,
            color: '#6b7280',
          }}
        >
          <span>7 Invariants</span>
          <span>·</span>
          <span>10 Tenets</span>
          <span>·</span>
          <span>κ &lt; 1 Design Target</span>
        </div>

        {/* Bottom bar */}
        <div
          style={{
            position: 'absolute',
            bottom: '32px',
            fontSize: 14,
            color: '#374151',
          }}
        >
          morphism.systems
        </div>
      </div>
    ),
    { ...size }
  )
}
