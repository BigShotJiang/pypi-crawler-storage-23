import { createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import { ScrollText, Plus, Check, X } from 'lucide-react'
import type { GovernancePolicy } from '@morphism-systems/shared/types'

export const dynamic = 'force-dynamic'

async function getPolicies(): Promise<GovernancePolicy[]> {
  const supabase = await createSupabaseClient()
  const { data, error } = await supabase
    .from('governance_policies')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw error
  return (data ?? []) as GovernancePolicy[]
}

export default async function PoliciesPage() {
  let policies: GovernancePolicy[] = []
  let error: string | null = null

  try {
    policies = await getPolicies()
  } catch {
    error = 'Could not load policies. Is Supabase configured?'
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Governance Policies</h1>
        <button className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">
          <Plus className="h-4 w-4" /> Add Policy
        </button>
      </div>

      {error && (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-6 text-sm">
          {error}
        </div>
      )}

      {policies.length === 0 && !error && (
        <div className="border rounded-xl p-12 text-center text-gray-500">
          <ScrollText className="h-8 w-8 mx-auto mb-2 text-gray-300" />
          No governance policies defined yet. Create your first policy.
        </div>
      )}

      <div className="grid gap-4">
        {policies.map((policy) => (
          <div key={policy.id} className="border rounded-xl p-6">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="text-lg font-semibold flex items-center gap-2">
                  {policy.name}
                  {policy.is_active ? (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-green-100 text-green-700">
                      <Check className="h-3 w-3" /> Active
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs bg-gray-100 text-gray-500">
                      <X className="h-3 w-3" /> Inactive
                    </span>
                  )}
                </h3>
                {policy.description && <p className="text-sm text-gray-500 mt-1">{policy.description}</p>}
              </div>
            </div>
            <div className="space-y-1.5">
              {policy.rules.map((rule, i) => (
                <div key={i} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-blue-500 mt-0.5">•</span>
                  {rule}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
