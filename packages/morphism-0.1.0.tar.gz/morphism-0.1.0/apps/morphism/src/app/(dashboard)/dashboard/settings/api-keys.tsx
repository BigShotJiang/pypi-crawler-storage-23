'use client'

import { useState, useEffect } from 'react'
import { Key, Copy, Trash2, Plus, Eye, EyeOff } from 'lucide-react'
import { withCsrfHeaders } from '@morphism-systems/shared/csrf'

interface ApiKey {
  id: string
  name: string
  prefix: string
  last_used_at: string | null
  created_at: string
}

export function ApiKeyManager() {
  const [keys, setKeys] = useState<ApiKey[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [newKeyName, setNewKeyName] = useState('')
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newKey, setNewKey] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    fetchKeys()
  }, [])

  async function fetchKeys() {
    try {
      const res = await fetch('/api/keys')
      if (res.ok) {
        const data = await res.json()
        setKeys(data.keys ?? [])
      }
    } catch {
      // Silently fail — keys may not be available without Supabase
    } finally {
      setLoading(false)
    }
  }

  async function createKey() {
    if (!newKeyName.trim()) return
    setCreating(true)
    try {
      const res = await fetch('/api/keys', {
        method: 'POST',
        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ name: newKeyName }),
      })
      if (res.ok) {
        const data = await res.json()
        setNewKey(data.key)
        setNewKeyName('')
        setShowCreateForm(false)
        fetchKeys()
      }
    } catch {
      // Handle error
    } finally {
      setCreating(false)
    }
  }

  async function deleteKey(id: string) {
    if (!confirm('Revoke this API key? This cannot be undone.')) return
    await fetch(`/api/keys?id=${id}`, {
      method: 'DELETE',
      headers: withCsrfHeaders(),
    })
    fetchKeys()
  }

  function copyKey() {
    if (newKey) {
      navigator.clipboard.writeText(newKey)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
  }

  return (
    <div className="border rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold">API Keys</h2>
        <button
          onClick={() => setShowCreateForm(true)}
          className="inline-flex items-center gap-1.5 text-sm text-blue-600 hover:text-blue-700"
        >
          <Plus className="h-4 w-4" /> Create Key
        </button>
      </div>

      {/* New key display (shown once after creation) */}
      {newKey && (
        <div className="mb-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-sm font-medium text-green-800 mb-2">
            ✓ API key created! Copy it now — you won&apos;t see it again.
          </p>
          <div className="flex items-center gap-2">
            <code className="flex-1 text-xs bg-white px-3 py-2 rounded border font-mono break-all">
              {newKey}
            </code>
            <button
              onClick={copyKey}
              className="px-3 py-2 bg-green-600 text-white rounded text-xs hover:bg-green-700"
            >
              {copied ? '✓ Copied' : 'Copy'}
            </button>
          </div>
          <button
            onClick={() => setNewKey(null)}
            className="mt-2 text-xs text-green-600 hover:underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Create form */}
      {showCreateForm && (
        <div className="mb-4 p-4 border rounded-lg bg-gray-50">
          <label className="block text-sm font-medium mb-1">Key Name</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              placeholder="e.g., CI/CD Pipeline"
              className="flex-1 px-3 py-2 border rounded-lg text-sm"
              onKeyDown={(e) => e.key === 'Enter' && createKey()}
            />
            <button
              onClick={createKey}
              disabled={creating || !newKeyName.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm hover:bg-blue-700 disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create'}
            </button>
            <button
              onClick={() => { setShowCreateForm(false); setNewKeyName('') }}
              className="px-3 py-2 border rounded-lg text-sm hover:bg-gray-100"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Key list */}
      {loading ? (
        <p className="text-sm text-gray-400">Loading keys...</p>
      ) : keys.length === 0 ? (
        <div className="text-center py-6 text-sm text-gray-400">
          <Key className="h-8 w-8 mx-auto mb-2 opacity-30" />
          <p>No API keys yet. Create one to use the drift-report API.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {keys.map((key) => (
            <div key={key.id} className="flex items-center justify-between py-2 px-3 rounded-lg border text-sm">
              <div>
                <span className="font-medium">{key.name}</span>
                <span className="ml-2 text-gray-400 font-mono text-xs">{key.prefix}</span>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-gray-400">
                  {key.last_used_at
                    ? `Used ${new Date(key.last_used_at).toLocaleDateString()}`
                    : 'Never used'}
                </span>
                <button
                  onClick={() => deleteKey(key.id)}
                  className="text-gray-400 hover:text-red-600"
                  title="Revoke key"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <p className="mt-4 text-xs text-gray-400">
        Use API keys with: <code className="bg-gray-100 px-1 rounded">Authorization: Bearer mk_live_...</code>
      </p>
    </div>
  )
}
