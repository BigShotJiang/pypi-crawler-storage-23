// Plan configuration shared between client and server
// This is a client-safe module (no Stripe secret key)

export const PLANS = {
  free: {
    name: 'Free',
    agentLimit: 5,
    features: [
      'Up to 5 agents',
      'Basic risk assessments',
      'Community support',
      'Dashboard access',
    ],
  },
  pro: {
    name: 'Pro',
    agentLimit: 50,
    features: [
      'Up to 50 agents',
      'Advanced AI assessments',
      'Priority support',
      'Custom governance policies',
      'Drift monitoring',
      'Audit log export',
    ],
  },
  enterprise: {
    name: 'Enterprise',
    agentLimit: 1000,
    features: [
      'Unlimited agents',
      'Dedicated account manager',
      'SLA guarantee',
      'Custom integrations',
      'On-premise option',
      'SOC 2 compliance report',
    ],
  },
} as const

export type PlanKey = keyof typeof PLANS
