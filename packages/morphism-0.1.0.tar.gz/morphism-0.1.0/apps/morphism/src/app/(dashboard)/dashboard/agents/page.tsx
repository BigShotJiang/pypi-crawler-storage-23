import Link from 'next/link'
import { createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import { Bot, Plus } from 'lucide-react'
import type { Agent } from '@morphism-systems/shared/types'

export const dynamic = 'force-dynamic'

async function getAgents(): Promise<Agent[]> {
  const supabase = await createSupabaseClient()
  const { data, error } = await supabase
    .from('agents')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw error
  return (data ?? []) as Agent[]
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    active: 'bg-green-100 text-green-700',
    inactive: 'bg-gray-100 text-gray-700',
    error: 'bg-red-100 text-red-700',
  }
  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] ?? colors.inactive}`}>
      {status}
    </span>
  )
}

function DriftBadge({ score }: { score: number }) {
  const color = score > 30 ? 'text-red-600' : score > 15 ? 'text-yellow-600' : 'text-green-600'
  return <span className={`font-medium ${color}`}>{score.toFixed(1)}%</span>
}

export default async function AgentsPage() {
  let agents: Agent[] = []
  let error: string | null = null

  try {
    agents = await getAgents()
  } catch (e) {
    error = 'Could not load agents. Is Supabase configured?'
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Agents</h1>
        <Link
          href="/dashboard/agents/new"
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700"
        >
          <Plus className="h-4 w-4" /> Add Agent
        </Link>
      </div>

      {error && (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-6 text-sm">
          {error}
        </div>
      )}

      <div className="border rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Agent</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Drift</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Sessions</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Model</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {agents.length === 0 && !error && (
              <tr>
                <td colSpan={6} className="px-6 py-12 text-center text-gray-500">
                  <Bot className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                  No agents registered yet. Add your first agent to get started.
                </td>
              </tr>
            )}
            {agents.map((agent) => (
              <tr key={agent.id} className="hover:bg-gray-50">
                <td className="px-6 py-4">
                  <div>
                    <p className="font-medium text-gray-900">{agent.name}</p>
                    {agent.description && <p className="text-sm text-gray-500 mt-0.5">{agent.description}</p>}
                  </div>
                </td>
                <td className="px-6 py-4 text-sm text-gray-600">{agent.type}</td>
                <td className="px-6 py-4"><StatusBadge status={agent.status} /></td>
                <td className="px-6 py-4 text-sm"><DriftBadge score={agent.drift_score} /></td>
                <td className="px-6 py-4 text-sm text-gray-600">{agent.sessions_count}</td>
                <td className="px-6 py-4 text-sm text-gray-500 font-mono">{agent.model}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
