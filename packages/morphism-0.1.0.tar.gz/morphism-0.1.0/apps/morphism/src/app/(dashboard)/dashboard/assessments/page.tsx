import Link from 'next/link'
import { createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import { ClipboardCheck, Plus } from 'lucide-react'
import type { Assessment } from '@morphism-systems/shared/types'

export const dynamic = 'force-dynamic'

async function getAssessments(): Promise<Assessment[]> {
  const supabase = await createSupabaseClient()
  const { data, error } = await supabase
    .from('assessments')
    .select('*')
    .order('created_at', { ascending: false })

  if (error) throw error
  return (data ?? []) as Assessment[]
}

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    pending: 'bg-gray-100 text-gray-700',
    in_progress: 'bg-yellow-100 text-yellow-700',
    completed: 'bg-green-100 text-green-700',
    failed: 'bg-red-100 text-red-700',
  }
  return (
    <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors[status] ?? colors.pending}`}>
      {status.replace('_', ' ')}
    </span>
  )
}

function RiskScore({ score }: { score: number | null }) {
  if (score === null) return <span className="text-gray-400">—</span>
  const color = score >= 60 ? 'text-red-600' : score >= 30 ? 'text-yellow-600' : 'text-green-600'
  return <span className={`font-semibold ${color}`}>{score}</span>
}

export default async function AssessmentsPage() {
  let assessments: Assessment[] = []
  let error: string | null = null

  try {
    assessments = await getAssessments()
  } catch {
    error = 'Could not load assessments. Is Supabase configured?'
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Assessments</h1>
        <Link
          href="/dashboard/assessments/new"
          className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700"
        >
          <Plus className="h-4 w-4" /> New Assessment
        </Link>
      </div>

      {error && (
        <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg mb-6 text-sm">
          {error}
        </div>
      )}

      <div className="border rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="bg-gray-50 border-b">
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Assessment</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Type</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Status</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Risk Score</th>
              <th className="text-left px-6 py-3 text-xs font-medium text-gray-500 uppercase">Findings</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            {assessments.length === 0 && !error && (
              <tr>
                <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                  <ClipboardCheck className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                  No assessments yet. Run your first governance assessment.
                </td>
              </tr>
            )}
            {assessments.map((a) => (
              <tr key={a.id} className="hover:bg-gray-50">
                <td className="px-6 py-4 font-medium text-gray-900">{a.title}</td>
                <td className="px-6 py-4 text-sm text-gray-600 capitalize">{a.type}</td>
                <td className="px-6 py-4"><StatusBadge status={a.status} /></td>
                <td className="px-6 py-4"><RiskScore score={a.risk_score} /></td>
                <td className="px-6 py-4 text-sm text-gray-600">{a.findings?.length ?? 0}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
