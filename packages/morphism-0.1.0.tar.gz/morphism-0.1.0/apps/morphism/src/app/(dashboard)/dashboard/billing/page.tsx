'use client'

import { useState } from 'react'
import { PLANS, type PlanKey } from './plans'
import { withCsrfHeaders } from '@morphism-systems/shared/csrf'

function PricingCard({
  plan,
  planKey,
  currentPlan,
  onUpgrade,
  loading,
}: {
  plan: (typeof PLANS)[PlanKey]
  planKey: PlanKey
  currentPlan: string
  onUpgrade: (plan: 'pro' | 'enterprise') => void
  loading: boolean
}) {
  const isCurrent = currentPlan === planKey
  const isDowngrade = currentPlan === 'enterprise' && planKey === 'pro'
  const isFree = planKey === 'free'

  return (
    <div
      className={`rounded-xl border p-6 ${
        isCurrent
          ? 'border-blue-500 bg-blue-50 dark:bg-blue-950/20'
          : 'border-gray-200 dark:border-gray-800'
      }`}
    >
      <h3 className="text-lg font-semibold">{plan.name}</h3>
      <p className="mt-1 text-sm text-gray-500">
        Up to {plan.agentLimit === 1000 ? 'unlimited' : plan.agentLimit} agents
      </p>

      <ul className="mt-4 space-y-2">
        {plan.features.map((feature) => (
          <li key={feature} className="flex items-start gap-2 text-sm">
            <span className="mt-0.5 text-green-500">✓</span>
            <span>{feature}</span>
          </li>
        ))}
      </ul>

      <div className="mt-6">
        {isCurrent ? (
          <button
            disabled
            className="w-full rounded-lg bg-blue-100 px-4 py-2 text-sm font-medium text-blue-700 dark:bg-blue-900/40 dark:text-blue-300"
          >
            Current Plan
          </button>
        ) : isFree || isDowngrade ? (
          <button
            disabled
            className="w-full rounded-lg bg-gray-100 px-4 py-2 text-sm font-medium text-gray-500 dark:bg-gray-800"
          >
            {isFree ? 'Included' : 'Contact support to downgrade'}
          </button>
        ) : (
          <button
            onClick={() => onUpgrade(planKey as 'pro' | 'enterprise')}
            disabled={loading}
            className="w-full rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
          >
            {loading ? 'Redirecting...' : `Upgrade to ${plan.name}`}
          </button>
        )}
      </div>
    </div>
  )
}

export default function BillingPage() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // In a real app, currentPlan comes from the server/org data
  const currentPlan = 'free'

  async function handleUpgrade(plan: 'pro' | 'enterprise') {
    setLoading(true)
    setError(null)

    try {
      const res = await fetch('/api/billing/checkout', {
        method: 'POST',
        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ plan }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Failed to create checkout session')
        return
      }

      if (data.url) {
        window.location.href = data.url
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  async function handleManageBilling() {
    setLoading(true)
    setError(null)

    try {
      const res = await fetch('/api/billing/portal', {
        method: 'POST',
        headers: withCsrfHeaders(),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Failed to open billing portal')
        return
      }

      if (data.url) {
        window.location.href = data.url
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Billing & Plans</h1>
          <p className="mt-1 text-gray-500">
            Manage your subscription and billing details.
          </p>
        </div>
        {currentPlan !== 'free' && (
          <button
            onClick={handleManageBilling}
            disabled={loading}
            className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800"
          >
            Manage Billing
          </button>
        )}
      </div>

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/20 dark:text-red-400">
          {error}
        </div>
      )}

      <div className="grid gap-6 md:grid-cols-3">
        {(Object.entries(PLANS) as [PlanKey, (typeof PLANS)[PlanKey]][]).map(
          ([key, plan]) => (
            <PricingCard
              key={key}
              planKey={key}
              plan={plan}
              currentPlan={currentPlan}
              onUpgrade={handleUpgrade}
              loading={loading}
            />
          )
        )}
      </div>
    </div>
  )
}
