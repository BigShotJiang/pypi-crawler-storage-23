import { currentUser } from '@clerk/nextjs/server'
import { ApiKeyManager } from './api-keys'
import { FeedbackWidget } from './feedback'

export const dynamic = 'force-dynamic'

export default async function SettingsPage() {
  const user = await currentUser()

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Settings</h1>

      <div className="max-w-2xl space-y-6">
        {/* Profile */}
        <div className="border rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4">Profile</h2>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between py-2 border-b">
              <span className="text-gray-500">Name</span>
              <span className="font-medium">{user?.fullName ?? '—'}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-gray-500">Email</span>
              <span className="font-medium">{user?.primaryEmailAddress?.emailAddress ?? '—'}</span>
            </div>
          </div>
        </div>

        {/* API Keys */}
        <ApiKeyManager />

        {/* API Configuration Status */}
        <div className="border rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4">Service Status</h2>
          <div className="space-y-4 text-sm">
            <div>
              <label className="block text-gray-500 mb-1">Supabase</label>
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                process.env.NEXT_PUBLIC_SUPABASE_URL ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {process.env.NEXT_PUBLIC_SUPABASE_URL ? 'Connected' : 'Not configured'}
              </span>
            </div>
            <div>
              <label className="block text-gray-500 mb-1">Anthropic (Claude)</label>
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                process.env.ANTHROPIC_API_KEY ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {process.env.ANTHROPIC_API_KEY ? 'Connected' : 'Not configured'}
              </span>
            </div>
            <div>
              <label className="block text-gray-500 mb-1">Stripe</label>
              <span className={`px-2 py-1 rounded text-xs font-medium ${
                process.env.STRIPE_SECRET_KEY ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
              }`}>
                {process.env.STRIPE_SECRET_KEY ? 'Connected' : 'Not configured'}
              </span>
            </div>
          </div>
        </div>

        {/* Feedback */}
        <FeedbackWidget />

        {/* Danger Zone */}
        <div className="border border-red-200 rounded-xl p-6">
          <h2 className="text-lg font-semibold text-red-600 mb-4">Danger Zone</h2>
          <p className="text-sm text-gray-500 mb-4">Delete your organization and all associated data. This action cannot be undone.</p>
          <button className="px-4 py-2 border border-red-300 text-red-600 rounded-lg text-sm hover:bg-red-50">
            Delete Organization
          </button>
        </div>
      </div>
    </div>
  )
}
