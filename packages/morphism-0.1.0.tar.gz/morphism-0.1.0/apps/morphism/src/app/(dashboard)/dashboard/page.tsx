import { createSupabaseClient } from '@morphism-systems/shared/supabase/server'
import { Shield, Bot, ClipboardCheck, AlertTriangle } from 'lucide-react'

export const dynamic = 'force-dynamic'

async function getStats() {
  const supabase = await createSupabaseClient()

  const [
    { count: agentCount },
    { count: assessmentCount },
    { count: policyCount },
    { data: agents },
  ] = await Promise.all([
    supabase.from('agents').select('*', { count: 'exact', head: true }),
    supabase.from('assessments').select('*', { count: 'exact', head: true }),
    supabase.from('governance_policies').select('*', { count: 'exact', head: true }),
    supabase.from('agents').select('drift_score').eq('status', 'active'),
  ])

  const avgDrift = agents?.length
    ? agents.reduce((sum: number, a: { drift_score: number }) => sum + a.drift_score, 0) / agents.length
    : 0

  return {
    agents: agentCount ?? 0,
    assessments: assessmentCount ?? 0,
    policies: policyCount ?? 0,
    avgDrift: Math.round(avgDrift * 10) / 10,
  }
}

export default async function DashboardPage() {
  let stats = { agents: 0, assessments: 0, policies: 0, avgDrift: 0 }

  try {
    stats = await getStats()
  } catch {
    // Supabase not configured yet — show zeroes
  }

  const cards = [
    { label: 'Active Agents', value: stats.agents, icon: Bot, color: 'text-blue-600 bg-blue-50' },
    { label: 'Assessments', value: stats.assessments, icon: ClipboardCheck, color: 'text-green-600 bg-green-50' },
    { label: 'Policies', value: stats.policies, icon: Shield, color: 'text-purple-600 bg-purple-50' },
    { label: 'Avg Drift Score', value: `${stats.avgDrift}%`, icon: AlertTriangle, color: stats.avgDrift > 30 ? 'text-red-600 bg-red-50' : 'text-green-600 bg-green-50' },
  ]

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Dashboard</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {cards.map((card) => (
          <div key={card.label} className="border rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500">{card.label}</span>
              <div className={`p-2 rounded-lg ${card.color}`}>
                <card.icon className="h-4 w-4" />
              </div>
            </div>
            <p className="text-3xl font-bold">{card.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="border rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4">Recent Activity</h2>
          <p className="text-sm text-gray-500">Connect Supabase to see audit log entries.</p>
        </div>
        <div className="border rounded-xl p-6">
          <h2 className="text-lg font-semibold mb-4">Governance Score</h2>
          <div className="flex items-center gap-4">
            <div className="text-4xl font-bold text-green-600">85%</div>
            <p className="text-sm text-gray-500">Based on active policies and agent compliance.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
