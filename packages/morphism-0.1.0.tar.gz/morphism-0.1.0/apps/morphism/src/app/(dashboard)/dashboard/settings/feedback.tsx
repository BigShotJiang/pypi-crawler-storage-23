'use client'

import { useState } from 'react'
import { MessageSquare, Send } from 'lucide-react'
import { withCsrfHeaders } from '@morphism-systems/shared/csrf'

export function FeedbackWidget() {
  const [open, setOpen] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [type, setType] = useState<'bug' | 'feature' | 'general'>('general')
  const [submitted, setSubmitted] = useState(false)
  const [sending, setSending] = useState(false)

  async function handleSubmit() {
    if (!feedback.trim()) return
    setSending(true)

    try {
      await fetch('/api/feedback', {
        method: 'POST',
        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({ type, message: feedback }),
      })
      setSubmitted(true)
      setFeedback('')
      setTimeout(() => {
        setSubmitted(false)
        setOpen(false)
      }, 2000)
    } catch {
      // Non-blocking
    } finally {
      setSending(false)
    }
  }

  if (!open) {
    return (
      <div className="border rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">Feedback</h2>
            <p className="text-sm text-gray-500 mt-1">Help us make Morphism better.</p>
          </div>
          <button
            onClick={() => setOpen(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100"
          >
            <MessageSquare className="h-4 w-4" />
            Send Feedback
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="border rounded-xl p-6 border-blue-200 bg-blue-50/30">
      <h2 className="text-lg font-semibold mb-4">Send Feedback</h2>

      {submitted ? (
        <div className="text-center py-4">
          <p className="text-green-600 font-medium">✓ Thank you for your feedback!</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex gap-2">
            {(['bug', 'feature', 'general'] as const).map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize ${
                  type === t
                    ? 'bg-blue-600 text-white'
                    : 'bg-white border text-gray-600 hover:border-gray-300'
                }`}
              >
                {t === 'bug' ? '🐛 Bug' : t === 'feature' ? '✨ Feature' : '💬 General'}
              </button>
            ))}
          </div>
          <textarea
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
            placeholder="Tell us what's on your mind..."
            rows={4}
            className="w-full px-3 py-2 border rounded-lg text-sm resize-none"
          />
          <div className="flex justify-end gap-2">
            <button
              onClick={() => { setOpen(false); setFeedback('') }}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900"
            >
              Cancel
            </button>
            <button
              onClick={handleSubmit}
              disabled={!feedback.trim() || sending}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              {sending ? 'Sending...' : 'Send'}
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
