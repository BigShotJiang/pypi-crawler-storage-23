import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Changelog | Morphism',
  description: 'Version history and release notes for Morphism.',
  alternates: {
    canonical: 'https://morphism.systems/changelog',
  },
}

interface Release {
  version: string
  date: string
  changes: string[]
}

const releases: Release[] = [
  {
    version: '0.1.0',
    date: '2026-02-19',
    changes: [
      'Initial public release',
      'Category theory engine: morphisms, functors, natural transformations',
      'Convergence (kappa) and drift (delta) metrics',
      'MCP server: @morphism-systems/agentic-math with 9 tools',
      'Governance MCP server: @morphism-systems/mcp-server',
      'CLI: @morphism-systems/cli with init, validate, score, doctor commands',
      'Plugin bundle: one-command installer for MCP + config + hooks',
      'Governance framework: 7 invariants, 10 tenets, 12 CI scripts',
      'Maturity score: 98/105',
      'SEO: sitemap, robots.txt, JSON-LD structured data, PWA manifest',
      'Documentation: style guide, docs index, quality reporting',
    ],
  },
]

export default function ChangelogPage() {
  return (
    <div className="min-h-screen bg-white">
      <nav className="max-w-4xl mx-auto px-6 py-6 flex justify-between items-center border-b">
        <Link href="/" className="text-xl font-bold tracking-tight">&#x25C7; morphism</Link>
        <div className="flex gap-4 text-sm">
          <Link href="/docs" className="text-gray-500 hover:text-gray-900">Docs</Link>
          <Link href="/beta" className="text-gray-500 hover:text-gray-900">Beta</Link>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16 space-y-12">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Changelog</h1>
          <p className="text-gray-500 mt-2">Version history and release notes.</p>
        </div>

        {releases.map((release) => (
          <section key={release.version} className="space-y-3">
            <div className="flex items-baseline gap-3">
              <h2 className="text-xl font-semibold">v{release.version}</h2>
              <span className="text-sm text-gray-400">{release.date}</span>
            </div>
            <ul className="list-disc pl-5 space-y-1 text-sm text-gray-600">
              {release.changes.map((change, i) => (
                <li key={i}>{change}</li>
              ))}
            </ul>
          </section>
        ))}
      </main>

      <footer className="max-w-4xl mx-auto px-6 py-8 border-t text-center text-xs text-gray-400">
        &copy; 2026 Morphism. All rights reserved.
      </footer>
    </div>
  )
}
