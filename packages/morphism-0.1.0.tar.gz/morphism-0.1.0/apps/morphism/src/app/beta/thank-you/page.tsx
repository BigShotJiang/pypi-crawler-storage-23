import { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Thank You | Morphism Beta',
}

export default function ThankYouPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900 text-white flex items-center justify-center">
      <div className="max-w-md mx-auto px-6 text-center">
        <div className="text-5xl mb-6">&loz;</div>
        <h1 className="text-3xl font-bold mb-4">You&apos;re on the list!</h1>
        <p className="text-gray-400 mb-8">
          We&apos;ll review your application and activate your beta access within 72 hours.
          Check your email for a confirmation.
        </p>
        <div className="space-y-3">
          <Link
            href="/"
            className="block py-3 px-6 bg-blue-600 hover:bg-blue-500 rounded-lg font-medium text-sm transition-colors"
          >
            Back to Home
          </Link>
          <a
            href="https://github.com/alawein/morphism"
            target="_blank"
            className="block py-3 px-6 border border-white/10 hover:border-white/20 rounded-lg text-sm text-gray-300 transition-colors"
          >
            Star us on GitHub ★
          </a>
        </div>
      </div>
    </div>
  )
}
