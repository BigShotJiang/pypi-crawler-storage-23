import { Metadata } from 'next'
import { cookies } from 'next/headers'
import Link from 'next/link'
import { MorphismWordmark } from '@/components/logo'
import { CSRF_COOKIE_NAME } from '@morphism-systems/shared/csrf'

export const metadata: Metadata = {
  title: 'Join the Beta',
  description: 'Get early access to the first mathematically-proven AI governance platform.',
}

export default async function BetaPage() {
  const cookieStore = await cookies()
  const csrfToken = cookieStore.get(CSRF_COOKIE_NAME)?.value ?? ''

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-blue-900 text-white">
      {/* Nav */}
      <nav className="max-w-5xl mx-auto px-6 py-6 flex justify-between items-center">
        <Link href="/">
          <MorphismWordmark />
        </Link>
        <Link href="/sign-in" className="text-sm text-gray-400 hover:text-white">Sign In &rarr;</Link>
      </nav>

      <main className="max-w-2xl mx-auto px-6 py-20">
        <div className="text-center mb-12">
          <span className="inline-block px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-xs font-medium mb-6">
            Limited Beta
          </span>
          <h1 className="text-4xl font-bold tracking-tight mb-4">
            Get Early Access
          </h1>
          <p className="text-lg text-gray-400">
            Join the first wave of teams using mathematically-proven AI governance.
            Beta includes <span className="text-white font-medium">Pro features free for 90 days</span>.
          </p>
        </div>

        <form
          action="/api/beta"
          method="POST"
          className="space-y-6 bg-white/5 border border-white/10 rounded-2xl p-8"
        >
          <input type="hidden" name="csrfToken" value={csrfToken} />
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">First Name</label>
              <input
                type="text"
                name="firstName"
                required
                className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Jane"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-1">Last Name</label>
              <input
                type="text"
                name="lastName"
                required
                className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Doe"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Work Email</label>
            <input
              type="email"
              name="email"
              required
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="jane@acme.com"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Company</label>
            <input
              type="text"
              name="company"
              required
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm placeholder-gray-500 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Acme AI Labs"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Team Size</label>
            <select
              name="teamSize"
              required
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-gray-300"
            >
              <option value="">Select...</option>
              <option value="1-5">1-5 engineers</option>
              <option value="6-20">6-20 engineers</option>
              <option value="21-50">21-50 engineers</option>
              <option value="51-200">51-200 engineers</option>
              <option value="200+">200+ engineers</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">How many AI agents do you run?</label>
            <select
              name="agentCount"
              required
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm text-gray-300"
            >
              <option value="">Select...</option>
              <option value="1-5">1-5 agents</option>
              <option value="6-25">6-25 agents</option>
              <option value="26-100">26-100 agents</option>
              <option value="100+">100+ agents</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">Biggest AI governance pain point</label>
            <textarea
              name="painPoint"
              rows={3}
              className="w-full px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg text-sm placeholder-gray-500 resize-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., We have no way to detect when our agents start hallucinating in production..."
            />
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-blue-600 hover:bg-blue-500 rounded-lg font-semibold text-sm transition-colors"
          >
            Request Beta Access &rarr;
          </button>

          <p className="text-xs text-gray-500 text-center">
            No credit card required. Pro features included free for 90 days.
          </p>
        </form>

        <div className="mt-16 grid sm:grid-cols-3 gap-6 text-center">
          <div>
            <div className="text-2xl font-bold text-blue-400">≤ 72h</div>
            <p className="text-sm text-gray-400 mt-1">Activation time</p>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-400">90 days</div>
            <p className="text-sm text-gray-400 mt-1">Free Pro access</p>
          </div>
          <div>
            <div className="text-2xl font-bold text-blue-400">&kappa; &lt; 1</div>
            <p className="text-sm text-gray-400 mt-1">Convergence (design target)</p>
          </div>
        </div>
      </main>

      <footer className="text-center py-8 text-xs text-gray-500">
        &copy; 2026 Morphism. All rights reserved.
      </footer>
    </div>
  )
}
