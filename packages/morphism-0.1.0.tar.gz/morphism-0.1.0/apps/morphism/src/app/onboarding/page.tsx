'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Shield, Users, Bot, ArrowRight, Check } from 'lucide-react'
import { withCsrfHeaders } from '@morphism-systems/shared/csrf'

const TEAM_SIZES = ['Just me', '2–5', '6–20', '21–100', '100+'] as const
const LLM_PROVIDERS = [
  { id: 'openai', name: 'OpenAI (GPT-4, o1)' },
  { id: 'anthropic', name: 'Anthropic (Claude)' },
  { id: 'google', name: 'Google (Gemini)' },
  { id: 'meta', name: 'Meta (Llama)' },
  { id: 'mistral', name: 'Mistral' },
  { id: 'other', name: 'Other / Custom' },
] as const

const PAIN_POINTS = [
  'Agents contradict each other across sessions',
  'No visibility into what agents actually do',
  'Hard to enforce company policies on AI outputs',
  'Agents drift from architectural decisions',
  'Compliance/regulatory concerns with AI usage',
  'Just exploring — no specific pain yet',
] as const

type Step = 1 | 2 | 3

export default function OnboardingPage() {
  const router = useRouter()
  const [step, setStep] = useState<Step>(1)
  const [teamSize, setTeamSize] = useState('')
  const [selectedLLMs, setSelectedLLMs] = useState<string[]>([])
  const [painPoint, setPainPoint] = useState('')
  const [saving, setSaving] = useState(false)

  function toggleLLM(id: string) {
    setSelectedLLMs((prev) =>
      prev.includes(id) ? prev.filter((l) => l !== id) : [...prev, id]
    )
  }

  async function handleComplete() {
    setSaving(true)
    try {
      await fetch('/api/onboarding', {
        method: 'POST',
        headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
        body: JSON.stringify({
          team_size: teamSize,
          llm_providers: selectedLLMs,
          pain_point: painPoint,
        }),
      })
    } catch {
      // Non-blocking — onboarding data is nice-to-have
    }
    router.push('/dashboard')
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 px-4">
      <div className="w-full max-w-lg">
        {/* Progress */}
        <div className="flex items-center justify-center gap-2 mb-8">
          {[1, 2, 3].map((s) => (
            <div
              key={s}
              className={`h-2 w-16 rounded-full transition-colors ${
                s <= step ? 'bg-blue-600' : 'bg-gray-200'
              }`}
            />
          ))}
        </div>

        <div className="bg-white rounded-2xl border shadow-sm p-8">
          {/* Step 1: Team Size */}
          {step === 1 && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-50 mb-4">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold">Welcome to Morphism</h2>
                <p className="text-gray-500 mt-2">How large is your team?</p>
              </div>
              <div className="space-y-2">
                {TEAM_SIZES.map((size) => (
                  <button
                    key={size}
                    onClick={() => setTeamSize(size)}
                    className={`w-full text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                      teamSize === size
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {teamSize === size && <Check className="inline h-4 w-4 mr-2" />}
                    {size}
                  </button>
                ))}
              </div>
              <button
                onClick={() => setStep(2)}
                disabled={!teamSize}
                className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Continue <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Step 2: LLM Providers */}
          {step === 2 && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-50 mb-4">
                  <Bot className="h-6 w-6 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold">Your AI Stack</h2>
                <p className="text-gray-500 mt-2">Which LLMs does your team use? (Select all)</p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {LLM_PROVIDERS.map((llm) => (
                  <button
                    key={llm.id}
                    onClick={() => toggleLLM(llm.id)}
                    className={`text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                      selectedLLMs.includes(llm.id)
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {selectedLLMs.includes(llm.id) && <Check className="inline h-4 w-4 mr-1" />}
                    {llm.name}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-3 rounded-lg border text-sm font-medium hover:bg-gray-50"
                >
                  Back
                </button>
                <button
                  onClick={() => setStep(3)}
                  disabled={selectedLLMs.length === 0}
                  className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Continue <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Pain Point */}
          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-blue-50 mb-4">
                  <Shield className="h-6 w-6 text-blue-600" />
                </div>
                <h2 className="text-2xl font-bold">Your Biggest Challenge</h2>
                <p className="text-gray-500 mt-2">What&apos;s your top AI governance pain point?</p>
              </div>
              <div className="space-y-2">
                {PAIN_POINTS.map((point) => (
                  <button
                    key={point}
                    onClick={() => setPainPoint(point)}
                    className={`w-full text-left px-4 py-3 rounded-lg border text-sm transition-colors ${
                      painPoint === point
                        ? 'border-blue-500 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                    }`}
                  >
                    {painPoint === point && <Check className="inline h-4 w-4 mr-2" />}
                    {point}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-3 rounded-lg border text-sm font-medium hover:bg-gray-50"
                >
                  Back
                </button>
                <button
                  onClick={handleComplete}
                  disabled={!painPoint || saving}
                  className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {saving ? 'Setting up...' : 'Go to Dashboard'}
                  {!saving && <ArrowRight className="h-4 w-4" />}
                </button>
              </div>
            </div>
          )}
        </div>

        <p className="text-center text-xs text-gray-400 mt-6">
          This helps us customize your experience. You can skip anytime.
        </p>
      </div>
    </div>
  )
}
