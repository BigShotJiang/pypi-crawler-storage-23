import { ImageResponse } from 'next/og'

export const runtime = 'edge'
export const size = { width: 32, height: 32 }
export const contentType = 'image/png'

export default function Icon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '32',
          height: '32',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#0a0a0f',
          borderRadius: '6px',
        }}
      >
        <svg
          width="24"
          height="24"
          viewBox="0 0 40 40"
          fill="none"
        >
          <path d="M20 6L34 20L20 34L6 20Z" stroke="#3b82f6" strokeWidth="2" opacity="0.6" />
          <path d="M12 20H28M24 16L28 20L24 24" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <circle cx="20" cy="20" r="2.5" fill="#3b82f6" />
        </svg>
      </div>
    ),
    { ...size }
  )
}
