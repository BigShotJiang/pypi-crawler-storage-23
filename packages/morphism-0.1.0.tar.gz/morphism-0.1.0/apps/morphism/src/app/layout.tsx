import type { Metadata } from 'next'
import { ClerkProvider } from '@clerk/nextjs'
import { Inter, IBM_Plex_Mono } from 'next/font/google'
import { OrganizationJsonLd, SoftwareApplicationJsonLd } from '@/components/json-ld'
import './globals.css'

const inter = Inter({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  variable: '--font-sans',
})

const plexMono = IBM_Plex_Mono({
  subsets: ['latin'],
  weight: ['300', '400', '600', '700'],
  variable: '--font-mono',
})

const hasClerkKeys =
  !!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY && !!process.env.CLERK_SECRET_KEY

export const dynamic = 'force-dynamic'

export const metadata: Metadata = {
  title: {
    default: 'Morphism — Governance Layer for AI Agent Fleets',
    template: '%s | Morphism',
  },
  description: 'Governance layer for AI agent fleets. Mathematical foundations for compliance, drift detection, and self-healing. Source-available core.',
  metadataBase: new URL('https://morphism.systems'),
  openGraph: {
    title: 'Morphism — Governance Layer for AI Agent Fleets',
    description: 'Governance layer for AI agent fleets. Mathematical foundations for compliance, drift detection, and self-healing. Source-available core.',
    url: 'https://morphism.systems',
    siteName: 'Morphism',
    locale: 'en_US',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Morphism — Governance Layer for AI Agent Fleets',
    description: 'Governance layer for AI agent fleets. Mathematical foundations for compliance, drift detection, and self-healing.',
  },
  keywords: [
    'AI governance', 'LLM governance', 'agent governance',
    'drift detection', 'convergence', 'governance framework', 'AI agent monitoring',
    'governance as code', 'MCP server', 'model context protocol', 'self-healing AI',
    'AI fleet management', 'AI safety tools', 'category theory software',
    'AI compliance', 'agent fleet management', 'AI governance platform', 'enterprise AI',
  ],
  alternates: {
    canonical: 'https://morphism.systems',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const shell = (
    <html lang="en" className={`${inter.variable} ${plexMono.variable}`}>
      <head>
        <OrganizationJsonLd />
        <SoftwareApplicationJsonLd />
      </head>
      <body>
        {children}
      </body>
    </html>
  )

  if (hasClerkKeys) {
    return <ClerkProvider>{shell}</ClerkProvider>
  }

  return shell
}
