import { clerkMiddleware, createRouteMatcher } from '@clerk/nextjs/server'
import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'
import { checkRateLimit, rateLimitKey } from '@morphism-systems/shared/rate-limit'
import { CSRF_COOKIE_NAME, getCookieValue } from '@morphism-systems/shared/csrf'

const isProtectedRoute = createRouteMatcher(['/dashboard(.*)'])
const isWebhookRoute = createRouteMatcher(['/api/webhooks(.*)'])
const isApiRoute = createRouteMatcher(['/api(.*)'])

const hasClerkKeys =
  !!process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY && !!process.env.CLERK_SECRET_KEY

function applySharedMiddleware(req: NextRequest): NextResponse | undefined {
  // Skip webhooks entirely (they have their own signature verification).
  if (isWebhookRoute(req)) return undefined

  // Rate-limit API routes before any further processing.
  if (isApiRoute(req)) {
    const ip = req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? null
    const key = rateLimitKey(req, ip)
    const url = new URL(req.url)
    const result = checkRateLimit(key, url.pathname)

    if (!result.allowed) {
      return new NextResponse(
        JSON.stringify({
          error: 'Too many requests',
          retryAfter: result.retryAfterSeconds,
        }),
        {
          status: 429,
          headers: {
            'Content-Type': 'application/json',
            'Retry-After': String(result.retryAfterSeconds),
            'X-RateLimit-Limit': String(result.limit),
            'X-RateLimit-Remaining': '0',
          },
        },
      )
    }
  }

  return undefined
}

function applyCsrf(req: NextRequest, response: NextResponse): NextResponse {
  const csrfCookie = getCookieValue(req.headers.get('cookie'), CSRF_COOKIE_NAME)
  if (!csrfCookie) {
    response.cookies.set(CSRF_COOKIE_NAME, crypto.randomUUID(), {
      httpOnly: false,
      sameSite: 'lax',
      secure: process.env.NODE_ENV === 'production',
      path: '/',
    })
  }
  return response
}

// When Clerk keys are present, use clerkMiddleware for auth.
// When missing, serve public routes without auth so the site stays up.
const handler = hasClerkKeys
  ? clerkMiddleware(async (auth: any, req: NextRequest) => {
      const earlyResponse = applySharedMiddleware(req)
      if (earlyResponse) return earlyResponse

      if (isProtectedRoute(req)) {
        await auth.protect()
      }

      return applyCsrf(req, NextResponse.next())
    })
  : (req: NextRequest) => {
      const earlyResponse = applySharedMiddleware(req)
      if (earlyResponse) return earlyResponse

      return applyCsrf(req, NextResponse.next())
    }

export default handler

export const config = {
  matcher: [
    '/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)',
    '/(api|trpc)(.*)',
  ],
}
