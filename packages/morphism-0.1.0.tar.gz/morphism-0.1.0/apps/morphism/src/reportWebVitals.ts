import type { NextWebVitalsMetric } from 'next/app'
import * as Sentry from '@sentry/nextjs'

const thresholds: Partial<Record<NextWebVitalsMetric['name'], number>> = {
  FCP: 1800,
  LCP: 2500,
  TTFB: 600,
  FID: 100,
  CLS: 0.1,
  INP: 200,
}

export function reportWebVitals(metric: NextWebVitalsMetric) {
  // Only send poor experiences to avoid noise
  const threshold = thresholds[metric.name as keyof typeof thresholds]
  const isBad = threshold !== undefined && metric.value > threshold

  if (isBad && process.env.NEXT_PUBLIC_SENTRY_DSN) {
    const rating = (metric as any).rating
    const delta = (metric as any).delta
    Sentry.captureMessage('[web-vital]', {
      level: 'info',
      tags: { name: metric.name },
      extra: {
        id: metric.id,
        value: metric.value,
        rating,
        delta,
      },
    })
  }
}
