export const openApiSpec = {
  openapi: '3.0.3',
  info: {
    title: 'Morphism API',
    version: '0.1.0',
    description: 'Public API surface for Morphism core endpoints.',
  },
  servers: [{ url: '/' }],
  components: {
    securitySchemes: {
      csrfToken: {
        type: 'apiKey',
        in: 'header',
        name: 'x-csrf-token',
      },
    },
    schemas: {
      ErrorResponse: {
        type: 'object',
        properties: {
          error: { type: 'string' },
        },
      },
      Agent: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          name: { type: 'string' },
          type: { type: 'string' },
          model: { type: 'string' },
          description: { type: 'string', nullable: true },
          config: { type: 'object', additionalProperties: true },
        },
      },
      Assessment: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          title: { type: 'string' },
          type: { type: 'string' },
          status: { type: 'string' },
          risk_score: { type: 'number', nullable: true },
        },
      },
      ApiKey: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          name: { type: 'string' },
          prefix: { type: 'string' },
          created_at: { type: 'string', format: 'date-time' },
          last_used_at: { type: 'string', format: 'date-time', nullable: true },
        },
      },
      Credential: {
        type: 'object',
        properties: {
          id: { type: 'string', format: 'uuid' },
          key_name: { type: 'string' },
          service: { type: 'string' },
          value: { type: 'string' },
          masked_value: { type: 'string' },
          metadata: { type: 'object', additionalProperties: true },
        },
      },
    },
  },
  paths: {
    '/api/agents': {
      get: {
        summary: 'List agents',
        responses: {
          '200': {
            description: 'Agent list',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    agents: { type: 'array', items: { $ref: '#/components/schemas/Agent' } },
                  },
                },
              },
            },
          },
        },
      },
      post: {
        summary: 'Create agent',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  type: { type: 'string' },
                  model: { type: 'string' },
                  description: { type: 'string', nullable: true },
                  config: { type: 'object', additionalProperties: true },
                },
                required: ['name', 'type'],
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'Agent created',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    agent: { $ref: '#/components/schemas/Agent' },
                  },
                },
              },
            },
          },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
    '/api/assessments': {
      get: {
        summary: 'List assessments',
        responses: {
          '200': {
            description: 'Assessment list',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    assessments: { type: 'array', items: { $ref: '#/components/schemas/Assessment' } },
                  },
                },
              },
            },
          },
        },
      },
      post: {
        summary: 'Create assessment',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  title: { type: 'string' },
                  type: { type: 'string', enum: ['risk', 'compliance', 'drift', 'governance'] },
                  agent_id: { type: 'string', format: 'uuid', nullable: true },
                },
                required: ['title', 'type'],
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'Assessment created',
            content: { 'application/json': { schema: { type: 'object', properties: { assessment: { $ref: '#/components/schemas/Assessment' } } } } },
          },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
    '/api/keys': {
      get: {
        summary: 'List API keys',
        responses: {
          '200': {
            description: 'API keys',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    keys: { type: 'array', items: { $ref: '#/components/schemas/ApiKey' } },
                  },
                },
              },
            },
          },
        },
      },
      post: {
        summary: 'Create API key',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: { name: { type: 'string' } },
                required: ['name'],
              },
            },
          },
        },
        responses: {
          '201': {
            description: 'API key created',
            content: {
              'application/json': {
                schema: {
                  type: 'object',
                  properties: {
                    key: { type: 'string' },
                    id: { type: 'string', format: 'uuid' },
                    name: { type: 'string' },
                    prefix: { type: 'string' },
                    created_at: { type: 'string', format: 'date-time' },
                  },
                },
              },
            },
          },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
      delete: {
        summary: 'Revoke API key',
        security: [{ csrfToken: [] }],
        parameters: [
          { name: 'id', in: 'query', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          '200': {
            description: 'API key revoked',
            content: { 'application/json': { schema: { type: 'object', properties: { deleted: { type: 'boolean' } } } } },
          },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
    '/api/credentials': {
      get: {
        summary: 'List or fetch credentials',
        parameters: [
          { name: 'id', in: 'query', required: false, schema: { type: 'string', format: 'uuid' } },
          { name: 'key_name', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'service', in: 'query', required: false, schema: { type: 'string' } },
          { name: 'unmask', in: 'query', required: false, schema: { type: 'string', enum: ['true', 'false'] } },
        ],
        responses: {
          '200': {
            description: 'Credentials',
            content: {
              'application/json': {
                schema: {
                  oneOf: [
                    { $ref: '#/components/schemas/Credential' },
                    { type: 'array', items: { $ref: '#/components/schemas/Credential' } },
                  ],
                },
              },
            },
          },
        },
      },
      post: {
        summary: 'Create credential',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  key_name: { type: 'string' },
                  service: { type: 'string' },
                  value: { type: 'string' },
                  metadata: { type: 'object', additionalProperties: true },
                },
                required: ['key_name', 'service', 'value'],
              },
            },
          },
        },
        responses: {
          '201': { description: 'Credential created' },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
      put: {
        summary: 'Update credential',
        security: [{ csrfToken: [] }],
        parameters: [
          { name: 'id', in: 'query', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  value: { type: 'string' },
                  metadata: { type: 'object', additionalProperties: true },
                  change_reason: { type: 'string' },
                },
              },
            },
          },
        },
        responses: {
          '200': { description: 'Credential updated' },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
      delete: {
        summary: 'Delete credential',
        security: [{ csrfToken: [] }],
        parameters: [
          { name: 'id', in: 'query', required: true, schema: { type: 'string', format: 'uuid' } },
        ],
        responses: {
          '200': { description: 'Credential deleted' },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
    '/api/feedback': {
      post: {
        summary: 'Submit feedback',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  type: { type: 'string', enum: ['bug', 'feature', 'general'] },
                  message: { type: 'string' },
                },
                required: ['type', 'message'],
              },
            },
          },
        },
        responses: {
          '200': { description: 'Feedback received' },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
    '/api/validate': {
      post: {
        summary: 'Validate governance',
        security: [{ csrfToken: [] }],
        requestBody: {
          required: true,
          content: {
            'application/json': {
              schema: {
                type: 'object',
                properties: {
                  text: { type: 'string' },
                  framework: { type: 'string' },
                  include_policies: { type: 'boolean' },
                },
                required: ['text'],
              },
            },
          },
        },
        responses: {
          '200': { description: 'Validation result' },
          '403': { description: 'CSRF validation failed', content: { 'application/json': { schema: { $ref: '#/components/schemas/ErrorResponse' } } } },
        },
      },
    },
  },
} as const
