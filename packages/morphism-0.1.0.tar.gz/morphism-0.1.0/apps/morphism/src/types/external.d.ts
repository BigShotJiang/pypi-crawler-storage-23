declare module '@google/generative-ai' {
  export class GoogleGenerativeAI {
    constructor(apiKey: string)
    getGenerativeModel(options: { model: string }): {
      generateContent(prompt: string): Promise<{ response: { text(): string } }>
    }
  }
}

declare module '@supabase/ssr' {
  export type CookieOptions = Record<string, unknown>
  export function createServerClient(url: string, key: string, options: any): any
}

declare module '@supabase/supabase-js' {
  export function createClient(url: string, key: string, options?: any): any
}

declare module '@clerk/nextjs/server' {
  export const auth: () => Promise<any>
  export const currentUser: () => Promise<any>
  export const clerkClient: () => Promise<any>
  export const clerkMiddleware: (handler: any) => any
  export const createRouteMatcher: (patterns: string[]) => (req: any) => boolean
}

declare module 'next/headers' {
  export const cookies: () => Promise<any>
}

declare module 'clsx' {
  export type ClassValue = any
  export function clsx(...inputs: ClassValue[]): string
}

declare module 'tailwind-merge' {
  export function twMerge(...classLists: Array<string | null | undefined | false>): string
}
