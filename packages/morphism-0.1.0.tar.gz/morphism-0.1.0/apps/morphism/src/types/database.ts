export interface Organization {
  id: string
  clerk_org_id: string
  name: string
  slug: string
  plan: 'free' | 'pro' | 'enterprise'
  agent_limit: number
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  created_at: string
  updated_at: string
}

export interface Agent {
  id: string
  org_id: string
  name: string
  type: string
  status: 'active' | 'inactive' | 'error'
  model: string
  description: string | null
  config: Record<string, unknown>
  last_active: string | null
  drift_score: number
  sessions_count: number
  created_at: string
  updated_at: string
}

export interface Assessment {
  id: string
  org_id: string
  agent_id: string | null
  title: string
  type: 'risk' | 'compliance' | 'drift' | 'governance'
  status: 'pending' | 'in_progress' | 'completed' | 'failed'
  risk_score: number | null
  findings: Finding[] | null
  recommendations: string[] | null
  created_at: string
  completed_at: string | null
  updated_at: string
}

export interface Finding {
  id: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  title: string
  description: string
  tenet_id?: string
}

export interface GovernancePolicy {
  id: string
  org_id: string
  name: string
  description: string | null
  rules: string[]
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface AuditLogEntry {
  id: string
  org_id: string
  action: string
  actor: string
  resource_type: string
  resource_id: string | null
  metadata: Record<string, unknown> | null
  created_at: string
}

export interface ValidationResult {
  score: number
  violations: Violation[]
  suggestions: string[]
  framework: string
  policies_checked: number
}

export interface Violation {
  rule: string
  severity: 'critical' | 'high' | 'medium' | 'low'
  message: string
  suggestion: string
}
