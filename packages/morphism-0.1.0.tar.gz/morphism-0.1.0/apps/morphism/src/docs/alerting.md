# Alerting and Incident Response

## Sentry CLI (setup and automation)
- Install: `npm i -g @sentry/cli` (or `brew install sentry-cli` on macOS).
- Auth: set `SENTRY_AUTH_TOKEN` (token with project:admin from Sentry → Settings → Auth Tokens) and `SENTRY_ORG=alawein-team`. Never commit the token.

## Live Signals (chosen provider: Sentry)
- **Sentry**: Errors, traces, profiles, and web vitals (active when `NEXT_PUBLIC_SENTRY_DSN` is set).
  - Sampling defaults: `tracesSampleRate=0.2`, `profilesSampleRate=0.2`, `replaysSessionSampleRate=0.1`, `replaysOnErrorSampleRate=1.0`.
- **Rate limits**: `/src/lib/rate-limit.ts` — emits 429 responses; monitor via API logs.

## Minimum Alert Rules (create in Sentry)
1. **Error Spike**: error rate > 5/min for 5 minutes → page on-call.
2. **Frontend Degradation**: LCP > 2.5s or CLS > 0.1 for 5% of sessions → warn + ticket.
3. **API Latency**: p95 > 1500ms on any API route → warn.
4. **Rate-Limit Abuse**: >100 429s in 5 minutes from same IP → warn.

## Runbook (quick)
1. Acknowledge in Sentry and link incident to ticket.
2. Identify recent deploy (Vercel) and roll back if necessary.
3. Check Supabase status and Clerk/Stripe webhooks.
4. If credentials involved, rotate keys (.env.local + Vercel env).
5. Add regression test and close incident with postmortem note.

## Dashboard Starters
- Sentry: Error rate, transaction duration, LCP/CLS/INP distributions; add Apdex by route.
- Supabase: Postgres health, RLS latency.

## Staging Smoke (manual checklist)
Base URL: https://morphism.systems
1) Rate limit: send 31 requests to any `/api/*` route within a minute; expect a 429 with `Retry-After` header.
2) Security headers: `curl -I https://morphism.systems/` — verify Strict-Transport-Security, etc.
3) CSRF/auth: `curl -i -X POST https://morphism.systems/api/agents -H "Content-Type: application/json" -d "{}"` — expect 401/403 without session.

## Ownership
- Primary: Morphism Eng.
- Escalation: Security for credential or auth incidents.
