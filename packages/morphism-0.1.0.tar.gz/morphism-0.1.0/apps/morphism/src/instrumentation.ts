import * as Sentry from '@sentry/nextjs'

export async function register() {
  if (process.env.NEXT_RUNTIME === 'nodejs') {
    if (process.env.NEXT_PUBLIC_SENTRY_DSN) {
      Sentry.init({
        dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
        environment: process.env.VERCEL_ENV ?? process.env.NODE_ENV,
        tracesSampleRate: 0.2,
        profilesSampleRate: 0.2,
      })
    }
  }
}

export async function onRequestError(
  error: Error & { digest?: string },
  request: { path: string; method: string },
  _context?: { routePath: string; routeType: string }
) {
  Sentry.captureException(error, {
    extra: { path: request.path, method: request.method, digest: error.digest },
  })
}
