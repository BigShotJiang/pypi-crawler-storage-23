export function OrganizationJsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Morphism',
    url: 'https://morphism.systems',
    logo: 'https://morphism.systems/favicon.ico',
    description: 'AI governance with mathematical foundations. Self-healing intelligence layer for AI agent fleets.',
    sameAs: [
      'https://github.com/morphism-systems',
    ],
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}

export function SoftwareApplicationJsonLd() {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name: 'Morphism',
    applicationCategory: 'DeveloperApplication',
    operatingSystem: 'Any',
    description: 'Category-theoretic governance framework for AI agent fleets. Mathematical foundations for drift detection, convergence, and self-healing.',
    url: 'https://morphism.systems',
    license: 'https://spdx.org/licenses/BSL-1.1.html',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
      description: 'Open-core — BSL 1.1',
    },
  }

  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  )
}

