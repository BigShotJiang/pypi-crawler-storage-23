export function MorphismLogo({ className = 'h-8 w-8' }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Outer ring — governance boundary */}
      <circle cx="20" cy="20" r="18" stroke="currentColor" strokeWidth="1.5" opacity="0.3" />
      {/* Inner converging diamond — the fixed point */}
      <path
        d="M20 6L34 20L20 34L6 20Z"
        stroke="currentColor"
        strokeWidth="1.5"
        fill="none"
        opacity="0.6"
      />
      {/* Core morphism arrow — structure-preserving transformation */}
      <path
        d="M12 20H28M24 16L28 20L24 24"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Fixed point dot */}
      <circle cx="20" cy="20" r="2.5" fill="currentColor" opacity="0.8" />
    </svg>
  )
}

export function MorphismWordmark({ className = '' }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <MorphismLogo className="h-7 w-7" />
      <span className="text-lg font-bold tracking-tight">morphism</span>
    </div>
  )
}
