import Link from 'next/link'

export function Footer() {
  return (
    <footer className="site-footer">
      <div>
        <div className="footer-logo">MORPHISM</div>
        <div className="footer-tagline">Governance Layer for AI Agent Fleets &middot; &copy; 2026</div>
      </div>
      <ul className="footer-links">
        <li><a href="https://github.com/morphism-systems/morphism" target="_blank" rel="noopener noreferrer">GitHub</a></li>
        <li><Link href="/docs">Docs</Link></li>
        <li><a href="https://github.com/morphism-systems/morphism/blob/main/LICENSE" target="_blank" rel="noopener noreferrer">BSL 1.1</a></li>
        <li><a href="mailto:hello@morphism.systems">Contact</a></li>
      </ul>
    </footer>
  )
}
