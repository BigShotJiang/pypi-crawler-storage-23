'use client'

import { AnimatedSection } from './animated-section'

export function Problem() {
  return (
    <section id="problem" className="site-section">
      <div className="section-inner">
        <AnimatedSection>
          <div className="section-tag">The Problem</div>
        </AnimatedSection>
        <AnimatedSection delay={0.1}>
          <h2>
            Ungoverned AI agents are a<br />
            <span style={{ color: 'var(--red)' }}>liability</span>, not an asset.
          </h2>
        </AnimatedSection>
        <AnimatedSection delay={0.2}>
          <p className="section-sub">
            Every autonomous AI agent is a compliance surface. Without governance,
            you get drift, violations, and broken trust.
          </p>
        </AnimatedSection>
        <AnimatedSection delay={0.3}>
          <div className="problem-grid">
            <div className="problem-col bad-col">
              <div className="problem-label bad">Without Governance</div>
              <ul className="problem-list">
                <li>Agents drift from policies silently</li>
                <li>Compliance violations discovered in audits</li>
                <li>Manual review of agent behavior doesn&apos;t scale</li>
                <li>No audit trail for agent decisions</li>
              </ul>
            </div>
            <div className="problem-col good-col">
              <div className="problem-label good">With Morphism</div>
              <ul className="problem-list good">
                <li>Continuous drift detection across 5 drift types</li>
                <li>Policy enforcement runs on every commit</li>
                <li>Self-healing engine auto-corrects violations</li>
                <li>Full governance log with maturity scoring</li>
              </ul>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
