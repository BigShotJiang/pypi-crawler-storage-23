'use client'

import Link from 'next/link'
import { useEffect, useRef } from 'react'

export function Nav() {
  const navRef = useRef<HTMLElement>(null)

  useEffect(() => {
    const handleScroll = () => {
      navRef.current?.classList.toggle('scrolled', window.scrollY > 40)
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <nav ref={navRef} className="site-nav">
      <Link href="/" className="nav-logo">MORPHISM</Link>
      <ul className="nav-links">
        <li><a href="#problem">Problem</a></li>
        <li><a href="#how">How it works</a></li>
        <li><Link href="/docs">Docs</Link></li>
      </ul>
      <div className="nav-actions">
        <a href="mailto:hello@morphism.systems" className="btn-primary-sm">Book a Demo &rarr;</a>
      </div>
    </nav>
  )
}
