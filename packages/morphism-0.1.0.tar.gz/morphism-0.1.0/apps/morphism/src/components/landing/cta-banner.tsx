'use client'

import { AnimatedSection } from './animated-section'

export function CtaBanner() {
  return (
    <section className="site-section" style={{ borderBottom: 'none' }}>
      <div className="section-inner">
        <AnimatedSection>
          <div className="cta-banner">
            <h2>Ready to govern<br />your AI fleet?</h2>
            <p className="cta-sub">
              Open-core. Self-healing. Built on mathematical foundations.
            </p>
            <div className="cta-actions">
              <a href="mailto:hello@morphism.systems" className="btn-lg">Book a Demo &rarr;</a>
              <a
                href="https://github.com/morphism-systems/morphism"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-lg-ghost"
              >
                View on GitHub
              </a>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
