'use client'

import { AnimatedSection } from './animated-section'

export function HowItWorks() {
  return (
    <section id="how" className="site-section">
      <div className="section-inner">
        <AnimatedSection>
          <div className="section-tag">How It Works</div>
        </AnimatedSection>
        <AnimatedSection delay={0.1}>
          <h2>
            Three steps to<br />governed AI agents.
          </h2>
        </AnimatedSection>
        <AnimatedSection delay={0.2}>
          <p className="section-sub">Deploy in minutes. Governance runs continuously.</p>
        </AnimatedSection>
        <AnimatedSection delay={0.3}>
          <div className="steps-grid steps-3">
            <div className="step-card">
              <div className="step-num">01</div>
              <div className="step-icon">&#x25A0;</div>
              <div className="step-title">Install</div>
              <p className="step-body">
                One command. Works with any LLM provider.
              </p>
              <div className="step-code">
                <code>npx @morphism-systems/plugin-bundle install</code>
              </div>
            </div>
            <div className="step-card">
              <div className="step-num">02</div>
              <div className="step-icon">&#x25C6;</div>
              <div className="step-title">Define</div>
              <p className="step-body">
                Governance as code. Your rules, your invariants.
              </p>
              <div className="step-code">
                <code>morphism init --tenets 10</code>
              </div>
            </div>
            <div className="step-card">
              <div className="step-num">03</div>
              <div className="step-icon">&infin;</div>
              <div className="step-title">Heal</div>
              <p className="step-body">
                Drift detected and auto-corrected. No human intervention required.
              </p>
              <div className="step-code">
                <code>morphism heal --apply</code>
              </div>
            </div>
          </div>
        </AnimatedSection>
      </div>
    </section>
  )
}
