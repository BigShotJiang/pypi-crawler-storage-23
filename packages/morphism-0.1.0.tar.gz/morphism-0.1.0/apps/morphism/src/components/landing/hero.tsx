'use client'

import Link from 'next/link'
import { useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  radius: number
}

export function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const mouseRef = useRef({ x: -1000, y: -1000 })
  const particlesRef = useRef<Particle[]>([])
  const animFrameRef = useRef<number>(0)
  const heroGridRef = useRef<HTMLDivElement>(null)

  const initParticles = useCallback((width: number, height: number) => {
    const count = Math.floor((width * height) / 12000)
    particlesRef.current = Array.from({ length: Math.min(count, 120) }, () => ({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      radius: Math.random() * 1.5 + 0.5,
    }))
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      if (heroGridRef.current) {
        heroGridRef.current.style.transform = `translateY(${window.scrollY * 0.15}px)`
      }
    }
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const resize = () => {
      const parent = canvas.parentElement
      if (!parent) return
      canvas.width = parent.clientWidth
      canvas.height = parent.clientHeight
      initParticles(canvas.width, canvas.height)
    }

    resize()
    window.addEventListener('resize', resize)

    const handleMouse = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect()
      mouseRef.current = { x: e.clientX - rect.left, y: e.clientY - rect.top }
    }
    canvas.addEventListener('mousemove', handleMouse)

    function draw() {
      if (!ctx || !canvas) return
      ctx.clearRect(0, 0, canvas.width, canvas.height)
      const particles = particlesRef.current
      const mouse = mouseRef.current
      const connectDist = 120

      for (const p of particles) {
        p.x += p.vx
        p.y += p.vy

        if (p.x < 0 || p.x > canvas.width) p.vx *= -1
        if (p.y < 0 || p.y > canvas.height) p.vy *= -1

        const dx = mouse.x - p.x
        const dy = mouse.y - p.y
        const dist = Math.sqrt(dx * dx + dy * dy)
        if (dist < 200 && dist > 0) {
          p.vx += (dx / dist) * 0.02
          p.vy += (dy / dist) * 0.02
        }

        p.vx *= 0.99
        p.vy *= 0.99

        ctx.beginPath()
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2)
        ctx.fillStyle = 'rgba(181, 123, 255, 0.6)'
        ctx.fill()
      }

      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x
          const dy = particles[i].y - particles[j].y
          const dist = Math.sqrt(dx * dx + dy * dy)
          if (dist < connectDist) {
            const alpha = (1 - dist / connectDist) * 0.15
            ctx.beginPath()
            ctx.moveTo(particles[i].x, particles[i].y)
            ctx.lineTo(particles[j].x, particles[j].y)
            ctx.strokeStyle = `rgba(181, 123, 255, ${alpha})`
            ctx.lineWidth = 0.5
            ctx.stroke()
          }
        }
      }

      animFrameRef.current = requestAnimationFrame(draw)
    }

    animFrameRef.current = requestAnimationFrame(draw)

    return () => {
      window.removeEventListener('resize', resize)
      canvas.removeEventListener('mousemove', handleMouse)
      cancelAnimationFrame(animFrameRef.current)
    }
  }, [initParticles])

  return (
    <section className="hero">
      <div ref={heroGridRef} className="hero-grid" />
      <div className="hero-mesh-bg" />
      <canvas ref={canvasRef} className="hero-canvas" />
      <div className="hero-inner">
        <motion.div
          className="hero-label"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          MORPHISM
        </motion.div>
        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4 }}
        >
          Governance layer for<br />
          <span className="highlight">AI agent fleets.</span>
        </motion.h1>
        <motion.p
          className="hero-sub"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.6 }}
        >
          Drift detection, policy enforcement, and self-healing &mdash;
          powered by category theory.
        </motion.p>
        <motion.div
          className="hero-cta"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.8 }}
        >
          <Link href="https://github.com/morphism-systems/morphism" className="btn-lg">
            Get Started &rarr;
          </Link>
          <a href="mailto:hello@morphism.systems" className="btn-lg-ghost">Book a Demo</a>
        </motion.div>
        <StatsBar />
      </div>
    </section>
  )
}

function StatsBar() {
  const statsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function animateCount(el: Element) {
      const htmlEl = el as HTMLElement
      const target = parseFloat(htmlEl.dataset.count || '0')
      const suffix = htmlEl.dataset.suffix || ''
      const duration = 1200
      const start = performance.now()

      function update(now: number) {
        const elapsed = now - start
        const progress = Math.min(elapsed / duration, 1)
        const eased = 1 - Math.pow(1 - progress, 3)
        const current = target * eased
        htmlEl.textContent = Math.floor(current) + suffix
        if (progress < 1) requestAnimationFrame(update)
      }
      requestAnimationFrame(update)
    }

    const statsBar = statsRef.current
    if (!statsBar) return

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          statsBar.querySelectorAll('[data-count]').forEach(animateCount)
          observer.unobserve(statsBar)
        }
      },
      { threshold: 0.5 }
    )
    observer.observe(statsBar)
    return () => observer.disconnect()
  }, [])

  return (
    <motion.div
      ref={statsRef}
      className="stats-bar"
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, delay: 1.0 }}
    >
      <div className="stat">
        <div className="stat-val" data-count="160" data-suffix="">160</div>
        <div className="stat-label">Tests Passing</div>
      </div>
      <div className="stat">
        <div className="stat-val">125/125</div>
        <div className="stat-label">Governance Maturity</div>
      </div>
      <div className="stat">
        <div className="stat-val" data-count="5" data-suffix="">5</div>
        <div className="stat-label">Drift Types</div>
      </div>
      <div className="stat">
        <div className="stat-val">BSL 1.1</div>
        <div className="stat-label">Source Available</div>
      </div>
    </motion.div>
  )
}
