-- Morphism Hub — Seed Data (Demo)
-- Creates a demo organization with sample agents, policies, and assessments

-- Demo organization
INSERT INTO organizations (id, clerk_org_id, name, slug, plan, agent_limit)
VALUES (
  '00000000-0000-0000-0000-000000000001',
  'org_demo_morphism',
  'Morphism Demo',
  'morphism-demo',
  'pro',
  25
) ON CONFLICT (clerk_org_id) DO NOTHING;

-- Set context for RLS
SELECT set_clerk_org_id('org_demo_morphism');

-- Demo agents
INSERT INTO agents (org_id, name, type, status, model, description, drift_score, sessions_count) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Code Review Agent', 'code-review', 'active', 'claude-sonnet-4-5-20250929', 'Automated code review with governance checks', 12.5, 142),
  ('00000000-0000-0000-0000-000000000001', 'Architecture Validator', 'architecture', 'active', 'claude-sonnet-4-5-20250929', 'Validates architecture decisions against SSOT', 5.2, 89),
  ('00000000-0000-0000-0000-000000000001', 'Compliance Monitor', 'compliance', 'active', 'claude-sonnet-4-5-20250929', 'Monitors compliance with governance policies', 8.1, 234),
  ('00000000-0000-0000-0000-000000000001', 'Drift Detector', 'drift', 'inactive', 'claude-sonnet-4-5-20250929', 'Detects policy drift across sessions', 45.3, 67)
ON CONFLICT DO NOTHING;

-- Demo governance policies
INSERT INTO governance_policies (org_id, name, description, rules, is_active) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Authentication Standard', 'OAuth 2.0 with PKCE for all auth flows', ARRAY['Use OAuth 2.0 with PKCE', 'No session-based auth', 'JWT for API tokens only', 'Refresh tokens must expire in 24h'], true),
  ('00000000-0000-0000-0000-000000000001', 'API Design', 'RESTful API standards', ARRAY['Use REST with JSON:API spec', 'Version all APIs (v1/v2)', 'Rate limit all endpoints', 'Document with OpenAPI 3.1'], true),
  ('00000000-0000-0000-0000-000000000001', 'Data Governance', 'Data handling and privacy', ARRAY['PII must be encrypted at rest', 'No PII in logs', 'Data retention max 90 days', 'GDPR delete within 72h'], true)
ON CONFLICT DO NOTHING;

-- Demo assessments
INSERT INTO assessments (org_id, title, type, status, risk_score, findings, recommendations) VALUES
  ('00000000-0000-0000-0000-000000000001', 'Q1 2026 Governance Audit', 'governance', 'completed', 28,
   '[{"id":"F1","severity":"medium","title":"Drift in auth recommendations","description":"3 sessions recommended different auth approaches"}]'::jsonb,
   '["Enforce SSOT auth policy in all agent contexts","Add pre-prompt governance injection"]'::jsonb),
  ('00000000-0000-0000-0000-000000000001', 'Agent Risk Assessment', 'risk', 'completed', 42,
   '[{"id":"F1","severity":"high","title":"Unbounded agent scope","description":"Code review agent has access to production configs"}]'::jsonb,
   '["Restrict agent scope to source code only","Add file-path allowlists"]'::jsonb),
  ('00000000-0000-0000-0000-000000000001', 'Compliance Check', 'compliance', 'in_progress', null, '[]'::jsonb, '[]'::jsonb)
ON CONFLICT DO NOTHING;

-- Demo audit log
INSERT INTO audit_log (org_id, action, actor, resource_type, resource_id, metadata) VALUES
  ('00000000-0000-0000-0000-000000000001', 'agent.created', 'user_demo', 'agent', null, '{"name":"Code Review Agent"}'::jsonb),
  ('00000000-0000-0000-0000-000000000001', 'policy.created', 'user_demo', 'policy', null, '{"name":"Authentication Standard"}'::jsonb),
  ('00000000-0000-0000-0000-000000000001', 'assessment.completed', 'system', 'assessment', null, '{"title":"Q1 2026 Governance Audit","risk_score":28}'::jsonb),
  ('00000000-0000-0000-0000-000000000001', 'validation.run', 'user_demo', 'validation', null, '{"score":0.85,"violations_count":2}'::jsonb)
ON CONFLICT DO NOTHING;
