-- Morphism Hub — Initial Schema
-- Tables: organizations, agents, assessments, governance_policies, audit_log, api_keys
-- All tables use RLS with Clerk org_id scoping
-- SSOT: morphism-hub/supabase/schema.sql

-- ============================================================================
-- RLS helper: lets the app set Clerk org context per-request
-- ============================================================================

create or replace function public.set_clerk_org_id(org_id text)
returns void
language plpgsql
security definer
as $$
begin
  perform set_config('app.clerk_org_id', org_id, true);  -- true = local (transaction-scoped)
end;
$$;

-- Helper to read it back inside RLS policies
create or replace function public.current_clerk_org_id()
returns text
language sql
stable
as $$
  select coalesce(current_setting('app.clerk_org_id', true), '');
$$;

-- ============================================================================
-- Organizations
-- ============================================================================

create table if not exists public.organizations (
  id                      uuid primary key default gen_random_uuid(),
  clerk_org_id            text unique not null,
  name                    text not null,
  slug                    text not null,
  plan                    text not null default 'free' check (plan in ('free', 'pro', 'enterprise')),
  agent_limit             int  not null default 5,
  stripe_customer_id      text unique,
  stripe_subscription_id  text unique,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now()
);

alter table public.organizations enable row level security;

create policy "org_select" on public.organizations
  for select using (clerk_org_id = current_clerk_org_id());

create policy "org_update" on public.organizations
  for update using (clerk_org_id = current_clerk_org_id());

-- ============================================================================
-- Agents
-- ============================================================================

create table if not exists public.agents (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references public.organizations(id) on delete cascade,
  name            text not null,
  type            text not null,
  model           text not null default 'claude-sonnet-4-5-20250929',
  description     text,
  status          text not null default 'active' check (status in ('active', 'inactive', 'error')),
  drift_score     real not null default 0,
  sessions_count  int  not null default 0,
  config          jsonb not null default '{}',
  last_active     timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.agents enable row level security;

create policy "agents_select" on public.agents
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "agents_insert" on public.agents
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "agents_update" on public.agents
  for update using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "agents_delete" on public.agents
  for delete using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Assessments
-- ============================================================================

create table if not exists public.assessments (
  id              uuid primary key default gen_random_uuid(),
  org_id          uuid not null references public.organizations(id) on delete cascade,
  agent_id        uuid references public.agents(id) on delete set null,
  title           text not null,
  type            text not null check (type in ('risk', 'compliance', 'drift', 'governance')),
  status          text not null default 'pending' check (status in ('pending', 'in_progress', 'completed', 'failed')),
  risk_score      real,
  findings        jsonb,
  recommendations jsonb,
  completed_at    timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

alter table public.assessments enable row level security;

create policy "assessments_select" on public.assessments
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "assessments_insert" on public.assessments
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "assessments_update" on public.assessments
  for update using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Governance Policies
-- ============================================================================

create table if not exists public.governance_policies (
  id          uuid primary key default gen_random_uuid(),
  org_id      uuid not null references public.organizations(id) on delete cascade,
  name        text not null,
  description text,
  rules       jsonb not null default '[]',
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

alter table public.governance_policies enable row level security;

create policy "policies_select" on public.governance_policies
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "policies_insert" on public.governance_policies
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "policies_update" on public.governance_policies
  for update using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Audit Log (no RLS — written via service role only)
-- ============================================================================

create table if not exists public.audit_log (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references public.organizations(id) on delete cascade,
  action        text not null,
  actor         text not null,
  resource_type text not null,
  resource_id   text,
  metadata      jsonb,
  created_at    timestamptz not null default now()
);

-- Audit log uses service role key, no RLS needed
-- But we still enable it and add a broad policy for reads
alter table public.audit_log enable row level security;

create policy "audit_log_select" on public.audit_log
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- API Keys
-- ============================================================================

create table if not exists public.api_keys (
  id            uuid primary key default gen_random_uuid(),
  org_id        uuid not null references public.organizations(id) on delete cascade,
  name          text not null,
  key_hash      text not null unique,
  prefix        text not null,
  last_used_at  timestamptz,
  created_at    timestamptz not null default now()
);

alter table public.api_keys enable row level security;

create policy "api_keys_select" on public.api_keys
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "api_keys_delete" on public.api_keys
  for delete using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Indexes
-- ============================================================================

create index if not exists idx_agents_org on public.agents(org_id);
create index if not exists idx_assessments_org on public.assessments(org_id);
create index if not exists idx_assessments_agent on public.assessments(agent_id);
create index if not exists idx_policies_org on public.governance_policies(org_id);
create index if not exists idx_audit_log_org on public.audit_log(org_id);
create index if not exists idx_audit_log_action on public.audit_log(action);
create index if not exists idx_organizations_clerk on public.organizations(clerk_org_id);
create index if not exists idx_api_keys_org on public.api_keys(org_id);
create index if not exists idx_api_keys_hash on public.api_keys(key_hash);

-- ============================================================================
-- Updated-at triggers
-- ============================================================================

create or replace function public.update_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger trg_organizations_updated_at
  before update on public.organizations
  for each row execute function public.update_updated_at();

create trigger trg_agents_updated_at
  before update on public.agents
  for each row execute function public.update_updated_at();

create trigger trg_assessments_updated_at
  before update on public.assessments
  for each row execute function public.update_updated_at();

create trigger trg_policies_updated_at
  before update on public.governance_policies
  for each row execute function public.update_updated_at();
