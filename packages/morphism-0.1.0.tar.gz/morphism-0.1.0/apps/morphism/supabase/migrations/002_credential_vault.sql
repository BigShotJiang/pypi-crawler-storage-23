-- Morphism Credential Vault Migration
-- Adds secure credential storage with version control, access control, and audit trail

-- ============================================================================
-- Helper Functions for RLS Context Management
-- ============================================================================

-- Helper to set GitHub username context (for credential access control)
create or replace function public.set_github_username(username text)
returns void
language plpgsql
security definer
as $$
begin
  perform set_config('app.github_username', username, true);  -- true = local (transaction-scoped)
end;
$$;

-- Helper to read current GitHub username from context
create or replace function public.current_github_username()
returns text
language sql
stable
as $$
  select coalesce(current_setting('app.github_username', true), '');
$$;

-- ============================================================================
-- Helper Functions for Encryption Key Management
-- ============================================================================

-- Store and retrieve encryption key version (for key rotation support)
create or replace function public.get_encryption_key_version()
returns text
language sql
stable
as $$
  select coalesce(current_setting('app.encryption_key_version', true), 'v1');
$$;

-- ============================================================================
-- Credentials Table (Primary Storage)
-- ============================================================================

create table if not exists public.credentials (
  id                 uuid primary key default gen_random_uuid(),
  org_id             uuid not null references public.organizations(id) on delete cascade,
  key_name           text not null,
  service            text not null,  -- 'github', 'supabase', 'stripe', etc.
  encrypted_value    text not null,  -- AES-256-GCM encrypted
  encryption_key_id  text not null default 'v1',
  metadata           jsonb default '{}',  -- { expires_at, created_by, purpose, tags }
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),

  -- Unique constraint: one key per service per org
  unique(org_id, service, key_name)
);

-- Indexes for fast lookups
create index if not exists idx_credentials_org on public.credentials(org_id);
create index if not exists idx_credentials_service on public.credentials(service);
create index if not exists idx_credentials_key_name on public.credentials(key_name);

-- RLS policies
alter table public.credentials enable row level security;

create policy "credentials_select" on public.credentials
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "credentials_insert" on public.credentials
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "credentials_update" on public.credentials
  for update using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "credentials_delete" on public.credentials
  for delete using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- Updated-at trigger
create trigger trg_credentials_updated_at
  before update on public.credentials
  for each row execute function public.update_updated_at();

-- ============================================================================
-- Credential Versions Table (Immutable History)
-- ============================================================================

create table if not exists public.credential_versions (
  id                uuid primary key default gen_random_uuid(),
  credential_id     uuid not null references public.credentials(id) on delete cascade,
  org_id            uuid not null references public.organizations(id) on delete cascade,
  version_number    int not null,
  encrypted_value   text not null,
  changed_by        text not null,  -- GitHub username from Clerk
  change_reason     text,
  created_at        timestamptz not null default now(),

  unique(credential_id, version_number)
);

-- Indexes
create index if not exists idx_credential_versions_cred on public.credential_versions(credential_id);
create index if not exists idx_credential_versions_org on public.credential_versions(org_id);
create index if not exists idx_credential_versions_created on public.credential_versions(created_at desc);

-- RLS policies
alter table public.credential_versions enable row level security;

create policy "credential_versions_select" on public.credential_versions
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- Versions are append-only - no update/delete policies needed

-- ============================================================================
-- Access Grants Table (GitHub-Based Permissions)
-- ============================================================================

create table if not exists public.access_grants (
  id                   uuid primary key default gen_random_uuid(),
  org_id               uuid not null references public.organizations(id) on delete cascade,
  github_username      text not null,
  role                 text not null check (role in ('owner', 'admin', 'developer', 'readonly')),
  credential_pattern   text not null,  -- SQL LIKE pattern: 'GITHUB_%', 'SUPABASE_%', '%'
  granted_by           text not null,  -- GitHub username who granted access
  granted_at           timestamptz not null default now(),
  expires_at           timestamptz,
  is_active            boolean not null default true
);

-- Indexes
create index if not exists idx_access_grants_org on public.access_grants(org_id);
create index if not exists idx_access_grants_username on public.access_grants(github_username);
create index if not exists idx_access_grants_pattern on public.access_grants(credential_pattern);

-- RLS policies
alter table public.access_grants enable row level security;

create policy "access_grants_select" on public.access_grants
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "access_grants_insert" on public.access_grants
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "access_grants_update" on public.access_grants
  for update using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "access_grants_delete" on public.access_grants
  for delete using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Verification Scans Table (Audit Trail for Automated Checks)
-- ============================================================================

create table if not exists public.verification_scans (
  id                   uuid primary key default gen_random_uuid(),
  org_id               uuid not null references public.organizations(id) on delete cascade,
  scan_type            text not null,  -- 'integrity', 'expiration', 'swap_detection', 'full'
  credentials_checked  int not null default 0,
  issues_found         int not null default 0,
  findings             jsonb default '[]',  -- [ { key_name, issue_type, severity, details } ]
  initiated_by         text not null,  -- 'cron', 'manual', 'github_username'
  created_at           timestamptz not null default now()
);

-- Indexes
create index if not exists idx_verification_scans_org on public.verification_scans(org_id);
create index if not exists idx_verification_scans_type on public.verification_scans(scan_type);
create index if not exists idx_verification_scans_created on public.verification_scans(created_at desc);

-- RLS policies
alter table public.verification_scans enable row level security;

create policy "verification_scans_select" on public.verification_scans
  for select using (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

create policy "verification_scans_insert" on public.verification_scans
  for insert with check (
    org_id in (select id from public.organizations where clerk_org_id = current_clerk_org_id())
  );

-- ============================================================================
-- Helper Functions for Access Control
-- ============================================================================

-- Check if a user has access to a specific credential
create or replace function public.has_credential_access(
  p_github_username text,
  p_key_name text,
  p_org_id uuid
)
returns boolean
language plpgsql
stable
as $$
declare
  v_has_access boolean;
begin
  select exists(
    select 1
    from public.access_grants
    where org_id = p_org_id
      and github_username = p_github_username
      and p_key_name like credential_pattern
      and is_active = true
      and (expires_at is null or expires_at > now())
  ) into v_has_access;

  return v_has_access;
end;
$$;

-- Get effective role for a user (highest privilege level)
create or replace function public.get_user_credential_role(
  p_github_username text,
  p_org_id uuid
)
returns text
language plpgsql
stable
as $$
declare
  v_role text;
begin
  select role into v_role
  from public.access_grants
  where org_id = p_org_id
    and github_username = p_github_username
    and is_active = true
    and (expires_at is null or expires_at > now())
  order by
    case role
      when 'owner' then 1
      when 'admin' then 2
      when 'developer' then 3
      when 'readonly' then 4
    end
  limit 1;

  return coalesce(v_role, 'none');
end;
$$;

-- ============================================================================
-- Audit Logging for Credential Operations
-- ============================================================================

-- Log credential access (read)
create or replace function public.log_credential_access(
  p_org_id uuid,
  p_key_name text,
  p_accessed_by text
)
returns void
language plpgsql
security definer
as $$
begin
  insert into public.audit_log (org_id, action, actor, resource_type, resource_id, metadata)
  values (
    p_org_id,
    'credential.read',
    p_accessed_by,
    'credential',
    p_key_name,
    jsonb_build_object('timestamp', now())
  );
end;
$$;

-- Log credential modification (create/update/delete)
create or replace function public.log_credential_change(
  p_org_id uuid,
  p_action text,
  p_key_name text,
  p_changed_by text,
  p_reason text default null
)
returns void
language plpgsql
security definer
as $$
begin
  insert into public.audit_log (org_id, action, actor, resource_type, resource_id, metadata)
  values (
    p_org_id,
    p_action,
    p_changed_by,
    'credential',
    p_key_name,
    jsonb_build_object(
      'timestamp', now(),
      'reason', p_reason
    )
  );
end;
$$;

-- Trigger to automatically create version on credential update
create or replace function public.create_credential_version()
returns trigger
language plpgsql
as $$
declare
  v_max_version int;
begin
  -- Get current max version for this credential
  select coalesce(max(version_number), 0) into v_max_version
  from public.credential_versions
  where credential_id = NEW.id;

  -- Insert new version
  insert into public.credential_versions (
    credential_id,
    org_id,
    version_number,
    encrypted_value,
    changed_by,
    change_reason
  ) values (
    NEW.id,
    NEW.org_id,
    v_max_version + 1,
    NEW.encrypted_value,
    coalesce(current_setting('app.github_username', true), 'system'),
    'Auto-versioned on update'
  );

  return NEW;
end;
$$;

-- Attach trigger to credentials table
create trigger trg_credential_version
  after update of encrypted_value on public.credentials
  for each row execute function public.create_credential_version();

-- ============================================================================
-- Views for Convenient Access
-- ============================================================================

-- View: Latest credential versions with metadata
create or replace view public.credentials_with_latest_version as
select
  c.id,
  c.org_id,
  c.key_name,
  c.service,
  c.encrypted_value,
  c.encryption_key_id,
  c.metadata,
  c.created_at,
  c.updated_at,
  cv.version_number as current_version,
  cv.changed_by as last_changed_by,
  cv.created_at as last_changed_at
from public.credentials c
left join lateral (
  select version_number, changed_by, created_at
  from public.credential_versions
  where credential_id = c.id
  order by version_number desc
  limit 1
) cv on true;

-- View: Access grants with user info
create or replace view public.active_access_grants as
select
  ag.id,
  ag.org_id,
  ag.github_username,
  ag.role,
  ag.credential_pattern,
  ag.granted_by,
  ag.granted_at,
  ag.expires_at,
  case
    when ag.expires_at is null then 'permanent'
    when ag.expires_at > now() then 'active'
    else 'expired'
  end as status
from public.access_grants ag
where ag.is_active = true;

-- ============================================================================
-- Sample Data (for testing only - remove in production)
-- ============================================================================

-- Note: This section should be removed before deploying to production
-- It's included here for development/testing purposes only

-- Example: Create access grant for the workspace owner
-- insert into public.access_grants (org_id, github_username, role, credential_pattern, granted_by)
-- select
--   o.id,
--   'alawein',
--   'owner',
--   '%',
--   'system'
-- from public.organizations o
-- where o.clerk_org_id = 'your_clerk_org_id'
-- on conflict do nothing;
