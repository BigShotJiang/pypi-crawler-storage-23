# Morphism Hub

> The first AI governance **ecosystem** with mathematical convergence guarantees.
> 7 Kernel invariants and 10 operational tenets. κ < 1 design target; formal verification on roadmap.

[![CI](https://github.com/morphism-systems/morphism-systems/actions/workflows/ci.yml/badge.svg)](https://github.com/morphism-systems/morphism-systems/actions)

## Why Morphism?

Your AI agents drift 40% of the time. Monday's helpful assistant becomes Wednesday's hallucinating liability. Morphism detects drift in real time, validates configs against formal governance axioms, and mathematically guarantees convergence.

## Stack

| Layer | Tech |
|-------|------|
| Framework | Next.js 15.2 (App Router, React 19) |
| Auth | Clerk (org multi-tenancy) |
| Database | Supabase (PostgreSQL + Row-Level Security) |
| AI Engine | Google Gemini 2.0 Flash (risk analysis + validation) |
| Payments | Stripe (checkout, portal, webhooks) |
| Styling | Tailwind CSS 3.4 |
| Validation | Zod |
| Testing | Vitest |
| CI/CD | GitHub Actions → Vercel |

## Quick Start

```bash
# 1. Install
npm install

# 2. Configure environment
cp .env.local.example .env.local
# Fill in: CLERK_*, SUPABASE_*, GEMINI_API_KEY, STRIPE_*

# 3. Provision database
npx supabase db push    # applies supabase/schema.sql

# 4. Run
npm run dev             # http://localhost:3000
```

## Project Structure

```
src/
├── app/
│   ├── page.tsx                    # Marketing landing page
│   ├── beta/                       # Beta signup flow
│   │   ├── page.tsx                # Application form
│   │   └── thank-you/page.tsx      # Confirmation
│   ├── docs/page.tsx               # API documentation
│   ├── onboarding/page.tsx         # 3-step onboarding wizard
│   ├── sign-in/                    # Clerk auth
│   ├── sign-up/                    # Clerk auth
│   ├── (dashboard)/                # Authenticated area
│   │   └── dashboard/
│   │       ├── page.tsx            # Overview with stats
│   │       ├── agents/             # Agent management
│   │       ├── assessments/        # AI risk assessments
│   │       ├── billing/            # Stripe billing + plans
│   │       ├── policies/           # Governance policies
│   │       └── settings/           # Settings, API keys, feedback
│   │           ├── page.tsx
│   │           ├── api-keys.tsx    # API key manager component
│   │           └── feedback.tsx    # Feedback widget component
│   └── api/
│       ├── agents/                 # CRUD agents (Zod validated)
│       ├── assessments/            # CRUD + AI risk analysis
│       ├── beta/                   # Beta signup handler
│       ├── billing/
│       │   ├── checkout/           # Stripe checkout session
│       │   └── portal/            # Stripe customer portal
│       ├── drift-report/           # External drift reporting (API key auth)
│       ├── feedback/               # User feedback collection
│       ├── health/                 # Health check
│       ├── keys/                   # API key management (create/list/revoke)
│       ├── onboarding/             # Onboarding data storage
│       ├── validate/               # Governance validation via Gemini
│       └── webhooks/
│           ├── clerk/              # Org sync events
│           └── stripe/             # Payment events
├── lib/
│   ├── ai.ts                       # assessRisk() + validateGovernance()
│   ├── stripe.ts                   # Stripe SDK wrapper + plans
│   └── supabase/server.ts         # SSR client + admin client + RLS
├── middleware.ts                   # Route protection
└── types/database.ts               # Full TypeScript types

supabase/
├── schema.sql                      # Tables, RLS, indexes, functions
└── seed.sql                        # Demo data

.github/workflows/ci.yml           # Type check → Build → Deploy
```

## API Endpoints

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `POST` | `/api/validate` | Session | Validate agent config against governance axioms |
| `POST` | `/api/drift-report` | API Key | Report drift score (EMA smoothing, auto-assessment) |
| `GET` | `/api/keys` | Session | List API keys (prefix only) |
| `POST` | `/api/keys` | Session | Create API key (SHA-256 hashed, raw shown once) |
| `DELETE` | `/api/keys?id=` | Session | Revoke API key |
| `GET/POST` | `/api/agents` | Session | CRUD agents |
| `GET/POST` | `/api/assessments` | Session | CRUD assessments with AI risk analysis |
| `POST` | `/api/billing/checkout` | Session | Create Stripe checkout |
| `POST` | `/api/billing/portal` | Session | Open Stripe portal |
| `GET` | `/api/health` | None | Health check |

Full API documentation at `/docs`.

## Architecture

```
                    ┌─────────────┐
                    │  Landing    │ ← /
                    │  Beta       │ ← /beta
                    │  Docs       │ ← /docs
                    └──────┬──────┘
                           │ Clerk Auth
                    ┌──────▼──────┐
                    │  Dashboard  │ ← /dashboard/*
                    │  Onboarding │ ← /onboarding
                    └──────┬──────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
        ┌─────▼─────┐ ┌───▼───┐ ┌─────▼─────┐
        │  Supabase  │ │Gemini │ │  Stripe   │
        │  (RLS)     │ │  AI   │ │  Billing  │
        └───────────┘ └───────┘ └───────────┘

    External CI/CD ──→ POST /api/drift-report (API Key)
```

## Security

- **Row-Level Security**: Every query scoped to `clerk_org_id` via Supabase RLS
- **API Keys**: SHA-256 hashed, prefix-only display, raw key shown once
- **Webhook verification**: Svix (Clerk) + Stripe signature validation
- **Middleware**: All `/dashboard` routes require authentication

## Pricing

| Plan | Price | Agents | Assessments |
|------|-------|--------|-------------|
| Free | $0/mo | 3 | 50/month |
| Pro | $99/mo | 25 | Unlimited |
| Enterprise | Custom | Unlimited | Unlimited + SOC 2 |

## Mathematical Foundation

Morphism is built on the Morphism Framework — a category-theoretic governance system with 7 Kernel invariants and 10 operational tenets (see [docs/governance/INVENTORY.md](../../docs/governance/INVENTORY.md)). Convergence (κ &lt; 1) is a design target; formal verification is on the roadmap (see [docs/governance/RECONCILIATION_REPORT.md](../../docs/governance/RECONCILIATION_REPORT.md)).

## License

MIT — © 2026 Morphism Systems. See [LICENSE](LICENSE).
