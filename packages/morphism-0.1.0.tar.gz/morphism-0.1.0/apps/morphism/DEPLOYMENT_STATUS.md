# Morphism — Deployment Status

**Status:** ✅ **Deployed to Production**
**Last Updated:** 2026-02-17
**Live URL:** https://morphism-systems.vercel.app (canonical); legacy https://morphism-hub.vercel.app

**Vercel env vars:** Add all variables from [.env.local.example](.env.local.example) in Vercel → Project → Settings → Environment Variables so sign-in, API, and billing work in production.

---

## Services

| Service | Status | Details |
|---------|--------|---------|
| **Vercel** | ✅ Live | Project `morphism-hub`, alias `morphism-hub.vercel.app` |
| **Supabase** | ✅ Live | Project `<REDACTED>` (us-east-2), 10 tables |
| **Clerk** | ✅ Live | Org multi-tenancy, webhook active |
| **Stripe** | ✅ Live | Pro $29/mo + Enterprise $99/mo, webhook active |
| **Gemini** | ✅ Live | `gemini-2.0-flash` for risk assessment |
| **Credential Vault** | ✅ Live | AES-256-GCM encryption, key rotation support |

## Environment Variables (All Set)

All 13 env vars configured on Vercel production:

- `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY`, `CLERK_WEBHOOK_SECRET`
- `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`
- `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`, `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`
- `STRIPE_PRO_PRICE_ID`, `STRIPE_ENTERPRISE_PRICE_ID`
- `GEMINI_API_KEY`
- `MORPHISM_ENCRYPTION_KEY_V1`

## Database (10 Tables)

| Table | Migration | Purpose |
|-------|-----------|---------|
| `organizations` | 001 | Orgs + Stripe billing |
| `agents` | 001 | AI agents + drift tracking |
| `assessments` | 001 | Risk/compliance assessments |
| `governance_policies` | 001 | Custom governance rules |
| `audit_log` | 001 | Immutable action log |
| `api_keys` | 001 | External API key management |
| `credentials` | 002 | Encrypted credential storage |
| `credential_versions` | 002 | Immutable version history |
| `access_grants` | 002 | GitHub-based RBAC |
| `verification_scans` | 002 | Automated scan audit trail |

## API Routes (11)

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/agents` | GET/POST | List/create agents |
| `/api/assessments` | GET/POST | List/create assessments + AI analysis |
| `/api/validate` | POST | Governance validation via Gemini |
| `/api/keys` | GET/POST/DELETE | API key management |
| `/api/credentials` | GET/POST/PUT/DELETE | Credential vault CRUD |
| `/api/drift-report` | POST | External drift reporting (API key auth) |
| `/api/billing/checkout` | POST | Stripe checkout session |
| `/api/billing/portal` | POST | Stripe billing portal |
| `/api/webhooks/clerk` | POST | Org lifecycle events |
| `/api/webhooks/stripe` | POST | Billing events |
| `/api/onboarding` | POST | Onboarding data capture |
| `/api/health` | GET | Health check |

## Dashboards

| Service | URL |
|---------|-----|
| Vercel | https://vercel.com/<REDACTED>/morphism-hub |
| Supabase | https://supabase.com/dashboard/project/<REDACTED> |
| Clerk | https://dashboard.clerk.com |
| Stripe | https://dashboard.stripe.com/test |
| Gemini | https://aistudio.google.com |
