# Morphism Systems — Claude Code Configuration

**Canonical Governance:** [AGENTS.md](AGENTS.md)

## Project Context

This is the **morphism-systems** monorepo — the single canonical home for the Morphism
Categorical Governance Framework. It contains:

- **TypeScript app** (`apps/morphism/`) — Next.js 15 with Turborepo
- **npm packages** (`packages/shared/`, `packages/agentic-math/`, `packages/mcp-server/`, `packages/cli/`, `packages/plugin-bundle/`)
- **Python core** (`src/morphism/`) — category theory engine and CLI
- **Governance docs and scripts** (`docs/`, `scripts/`) — SSOT atoms, validation, maturity scoring
- **Consumer config** (`.morphism/`) — cross-IDE configs, hooks, schemas, workflows

Runs on **Windows 11 native** (Python via `python`, not `python3`). Core trinity: `AGENTS.md` → `SSOT.md` → `GUIDELINES.md`.
Normative kernel (7 invariants I-1..I-7): `docs/governance/morphism-kernel.md`.

Do not assume the existence of other repos or structures unless you verify with `ls` first.

## Quick Links

- Governance: [AGENTS.md](AGENTS.md)
- MORPHISM Framework: [docs/governance/MORPHISM.md](docs/governance/MORPHISM.md)
- SSOT: [SSOT.md](SSOT.md)
- Guidelines: [GUIDELINES.md](GUIDELINES.md)
- Handoff & integration: [docs/HANDOFF.md](docs/HANDOFF.md)
- Deferred work: [docs/TODO.md](docs/TODO.md)
- Governance roadmap: [docs/governance/roadmap.md](docs/governance/roadmap.md)
- Worked example: [docs/governance/worked-example.md](docs/governance/worked-example.md)
- Agent kernel prompt (full protocol, templates, checklists): [docs/governance/agent-kernel-prompt.md](docs/governance/agent-kernel-prompt.md)

## Context for handoff / multi-tool use

When starting work or switching from another agent (e.g. Cursor), read: AGENTS.md, SSOT.md, GUIDELINES.md, docs/HANDOFF.md, docs/TODO.md. That gives governance, current state, integration checklist, and deferred work.

## Session Bootstrap

At the start of every session, before taking any action:

1. Run `git log --oneline -15` to understand recent work.
2. Run `git status` to see current branch and uncommitted changes.
3. Read `docs/HANDOFF_STATE.md` (if it exists) for prior session context.
4. Read `docs/TODO.md` for current deferred work.
5. Only then respond to the user's request.

Use `/bootstrap` to run this automatically.

## Work Style

- **Execute, do not plan.** When asked to do something, do it. Do not produce a plan, outline, or proposal unless the user explicitly asks for one. If you catch yourself writing "here is my plan" or "I will," stop and execute instead.
- **One change at a time.** Make the smallest complete change, verify it works, then move to the next. Do not batch speculative changes.
- **If stuck for more than 2 tool calls, stop and ask.** Do not spiral into exploratory loops. State what you tried, what failed, and ask the user for direction.

## Output Scope

- **Proportional response.** Match output complexity to request complexity. A question about a list gets a list, not a refactored module. A one-file fix touches one file.
- **File count heuristic.** If your change touches more than 3 files for a task the user described in one sentence, stop and confirm scope with the user before proceeding.
- **No speculative refactoring.** Do not "improve" code adjacent to your change unless explicitly asked. Scope creep violates I-4 (Scope Binding).

## Test Gates

- **Verify after every change.** After modifying any code file, run the relevant test/lint command before proceeding to the next change:
  - Python files: `ruff check <file> && mypy <file>`
  - TypeScript files: `npx turbo typecheck && npx turbo lint`
  - Governance scripts: `python scripts/verify_pipeline.py`
  - Documentation: `python scripts/docs_graph.py --check`
- **Do not stack unverified changes.** If a test fails, fix it before making additional changes. Never say "I will fix this later."
- **Report test results.** After running tests, state the result (pass/fail with error summary) in your response. Do not silently skip failed tests.

## Session Management

- **Mandatory handoff.** Before ending any session, write a handoff note to `docs/HANDOFF_STATE.md` with: (1) what was done, (2) what remains, (3) current branch and uncommitted changes, (4) blockers. Use `/handoff` to generate this automatically.
- **Rate-limit awareness.** If you notice responses are being truncated or you are approaching a long session (>30 tool calls), prioritize: (1) complete the current atomic change, (2) run verification, (3) commit, (4) write handoff. Do not start new work when approaching limits.
- **Commit incrementally.** Do not accumulate a large uncommitted changeset. Commit after each logical unit of work with a conventional commit message.
- **No AI attribution.** Do not add Co-Authored-By, "Generated with", or "prepared by" credits in commits or documentation. The author writes commit messages.

## Environment

This repo runs on **Windows 11 native** (not WSL). Key constraints:

- **Python:** Use `python` (not `python3`). Windows native Python installs as `python`.
- **Line endings:** Git is configured for LF. Do not introduce CRLF. If a file shows as fully modified in `git diff`, check `git config core.autocrlf`.
- **Tool availability:** `jq` may not be installed. Use `python -c "import json, sys; ..."` as a fallback for JSON processing. Check tool availability with `which <tool>` before assuming it exists.
- **Shell:** bash (Git Bash). Scripts use `#!/usr/bin/env bash`.

## Baseline

- Read governance docs before structural changes.
- Run scoped validation before PR submission.
- Keep governance docs aligned to canonical sources.

## Monorepo Layout

| Context | Rules |
|---------|-------|
| Working in `apps/morphism/` | Next.js app — TypeScript, Vitest |
| Working in `packages/shared/` | Shared TS utilities — `@morphism-systems/shared` |
| Working in `packages/agentic-math/` | MCP math server — `@morphism-systems/agentic-math` |
| Working in `packages/mcp-server/` | Governance MCP server — `@morphism-systems/mcp-server` |
| Working in `packages/cli/` | Governance CLI — `@morphism-systems/cli` |
| Working in `packages/plugin-bundle/` | Installer bundle — `@morphism-systems/plugin-bundle` |
| Working in `src/morphism/` | Python core — ruff, mypy, pytest |
| Working in `docs/` | Documentation — Markdown |
| Working in `scripts/` | Governance scripts |

## Commands

```bash
# TypeScript
npm install && npx turbo build
npx turbo typecheck && npx turbo lint && npx turbo test

# Python
pip install -e ".[dev]"
ruff check src/ tests/ && mypy src/ && pytest tests/

# Governance and policy
bash scripts/install-hooks.sh
python scripts/policy_check.py --mode ci --explain
python scripts/ssot_extract.py && python scripts/ssot_verify.py
python scripts/docs_sync.py --check
python scripts/docs_graph.py --check
python scripts/maturity_score.py --ci --threshold 60
python scripts/verify_pipeline.py

# Batch audit (multi-repo)
bash scripts/batch-audit.sh

# Validate changes locally (before commit)
echo "feat(scope): subject" | python scripts/validate_commit.py /dev/stdin
python scripts/validate_branch.py
```

## Custom Skills

Claude Code custom skills are in `.claude/commands/`. Use them as slash commands:

| Skill | Command | Purpose |
|-------|---------|---------|
| Bootstrap | `/bootstrap` | Load session context before working |
| Handoff | `/handoff` | Write session handoff before ending |
| Audit | `/audit` | Full governance validation pipeline (7 checks) |
| Governance check | `/governance-check` | Quick pre-commit governance check (3 checks) |
| Parallel audit | `/parallel-audit` | Multi-repo governance audit |
| Scope | `/scope` | Bind task scope before executing |
| Context switch | `/context-switch` | Switch in from Cursor or another agent |
| Governance baseline | `/governance-baseline` | Pre-structural-change governance prep |

## Hooks

Claude Code hooks in `.claude/settings.json` auto-validate files after write:
- Python (`.py`): runs `ruff check` on the file
- TypeScript (`.ts`, `.tsx`): runs `tsc --noEmit`
- Other files: logs the write

These hooks catch errors immediately rather than at commit time.
