# Cursor rules and skills — Morphism workflow map

**Purpose:** Map morphism-systems workflows to Cursor rule/skill names and built-ins. Use this to choose which rule or skill to invoke for the current task.

**Governance:** Agents must still follow root [AGENTS.md](../../../AGENTS.md) and read SSOT, [GUIDELINES.md](../../../GUIDELINES.md), [docs/HANDOFF.md](../../../docs/HANDOFF.md), and [docs/TODO.md](../../../docs/TODO.md) before structural changes. After file changes, run the relevant verify commands from AGENTS.md (e.g. `npx turbo typecheck && npx turbo lint && npx turbo test` for TS; `ruff check src/ tests/ && mypy src/ && pytest tests/` for Python).

---

## Workflow → rules/skills

| Morphism workflow | Cursor rules/skills to use |
|-------------------|----------------------------|
| Onboard / understand repo | analysis-codebase-discovery, analysis-goals-and-next, analysis-next-steps-plan |
| Audit or assess codebase | analysis-audit-codebase |
| Debug failure / error | debug-error-triage, debug-logging-trace, debug-stacktrace-and-fix |
| Run and verify changes | execution-run-and-verify |
| Commit changes | commit-message-conventional (must match [GUIDELINES.md](../../../GUIDELINES.md): Conventional Commits, branch pattern, MOR- refs when applicable) |
| Prepare or review PR | code-review-pr-summary, review-pr-checklist, review-quality-security |
| Docs: API / runbook | docs-api-and-runbook, documentation-runbook |
| Docs: README / quickstart | docs-readme-update, documentation-readme-quickstart |
| Refactor (structure) | refactor-clean-arch, refactor-extract-and-simplify, refactor-patterns |
| Security checks | security-deps-and-secrets, security-scan-basics, security-secrets-and-input |
| Tests: Python | test-generation-pytest, testing-coverage-check, testing-tdd-workflow, testing-unit-and-edge |
| Tests: TypeScript | test-generation-vitest, testing-coverage-check, testing-tdd-workflow, testing-unit-and-edge |
| Add new rule/skill/convention | create-rule, create-skill; migrate-to-skills if consolidating |
| Cursor/IDE config | update-cursor-settings |
| Multi-agent or delegated tasks | create-subagent |

---

## Built-ins (when to use)

- **create-rule** — Adding or changing project conventions, file-specific patterns, or RULE.md.
- **create-skill** — Adding a new Cursor skill (e.g. morphism-specific workflow).
- **create-subagent** — Decomposing work for another agent.
- **migrate-to-skills** — Moving existing guidance into the skills format.
- **update-cursor-settings** — Changing Cursor/editor settings (e.g. settings.json).

---

## Governance alignment

- **Commit/branch:** Use `commit-message-conventional`; output must match GUIDELINES (Conventional Commits, branch pattern `(feat|fix|chore|ci|docs|refactor|test|perf|hotfix)/<description>`, MOR- in footer when applicable). Validation: `scripts/validate_commit.py`, `scripts/validate_branch.py`, CI.
- **Testing:** Python → pytest (80%+ coverage); TypeScript → vitest. See [HANDOFF.md](../../../docs/HANDOFF.md) for test commands and CI.
- **Review:** Before merging to main, use code-review-pr-summary, review-pr-checklist, and review-quality-security; consistent with HANDOFF and branch protection.
