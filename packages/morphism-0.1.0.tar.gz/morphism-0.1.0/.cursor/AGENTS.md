# Cursor Agent Notes

Cursor reads root `.cursorrules` for workspace guidance. When working in this repo, use the rule/skill set listed in **RULES_AND_SKILLS.md** (this directory) for the current task.

## Rules and skills

- **Workflow map:** [RULES_AND_SKILLS.md](RULES_AND_SKILLS.md) — maps morphism workflows (onboard, debug, commit, PR review, docs, refactor, security, tests) to Cursor rule/skill names and built-ins.
- **Project rules:** `rules/*.mdc` (if present) — morphism-specific alwaysApply or file-scoped rules.
- **Project skills:** `skills/*/SKILL.md` (if present) — morphism-specific skills (e.g. PR review).

## Reviewers

Reviewer specs are centralized under the morphism config:

- **Registry:** [.morphism/reviewers/REGISTRY.md](../../reviewers/REGISTRY.md)
- **Reviewer specs:** [.morphism/reviewers/](../../reviewers/) — one directory per reviewer (e.g. `architecture-boundary/REVIEWER.md`, `entropy-guard/REVIEWER.md`).
- **Claude reviewer agents:** [.morphism/ide-configs/claude/agents/](../claude/agents/) — same reviewers, Claude-oriented prompts.

Open the reviewer spec and follow the 5-phase review process when running a review.
