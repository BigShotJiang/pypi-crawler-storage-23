---
name: morphism-pr-review
description: Runs PR review checklist and quality/security review for morphism-systems; use when preparing or reviewing a pull request before merge to main.
---

# Morphism PR review

Use when preparing or reviewing a pull request in morphism-systems, before merging to main.

## Instructions

1. **Apply Cursor rules/skills:**
   - **review-pr-checklist** — run the PR checklist (code quality, standards, completeness).
   - **review-quality-security** — run quality and security review (security implications, performance, maintainability).

2. **Optionally run code-review-pr-summary** for a concise PR summary.

3. **Verify CI and governance:**
   - Ensure changes align with root AGENTS.md, GUIDELINES.md, and docs/HANDOFF.md.
   - Remind that CI must pass (TS: typecheck, lint, test, build; Python: ruff, mypy, pytest) and that branch protection applies to main.

4. **Reviewers:** For deeper governance checks, use the reviewer system: see .morphism/reviewers/REGISTRY.md (e.g. architecture-boundary, entropy-guard, ship-readiness, truth-documentation as needed).

## When to use

- User asks to review a PR or prepare for merge.
- User asks for a pre-merge checklist or quality/security pass.
- Before creating or updating a PR targeting main.
