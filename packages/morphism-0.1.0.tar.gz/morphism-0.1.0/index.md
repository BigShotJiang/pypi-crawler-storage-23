---
title: Morphism Systems
---

# Morphism Systems

**Categorical Governance Framework for AI-assisted software development.**

Morphism Systems applies category theory to governance — morphisms, functors, and natural transformations become the language for policy enforcement, drift detection, and convergence metrics.

## Quick Start

### Install the CLI

```bash
npm install -g @morphism-systems/cli
morphism init        # Create .morphism/ config
morphism doctor      # Verify setup
morphism validate    # Run governance pipeline
morphism score       # Compute maturity score
```

### Install the MCP Servers

```bash
npx @morphism-systems/plugin-bundle install
```

This adds two MCP servers to your Claude Code config:

- **morphism-math** — Category theory computations (morphisms, functors, natural transformations, convergence)
- **morphism-governance** — Governance validation, maturity scoring, SSOT verification

### Python Core

```bash
pip install morphism
morphism --help
```

## Packages

| Package | Description |
|---------|-------------|
| [@morphism-systems/agentic-math](https://www.npmjs.com/package/@morphism-systems/agentic-math) | Category theory MCP server |
| [@morphism-systems/mcp-server](https://www.npmjs.com/package/@morphism-systems/mcp-server) | Governance MCP server |
| [@morphism-systems/cli](https://www.npmjs.com/package/@morphism-systems/cli) | Governance CLI |
| [@morphism-systems/plugin-bundle](https://www.npmjs.com/package/@morphism-systems/plugin-bundle) | One-command installer |
| [morphism (PyPI)](https://pypi.org/project/morphism/) | Python governance engine |

## Key Concepts

- **7 Invariants** (I-1 through I-7) — the normative kernel that cannot be violated
- **10 Tenets** — operational implementation of the invariants
- **Convergence (kappa)** — measures whether governance is converging or diverging over time
- **Drift (delta)** — quantifies deviation between baseline and current state
- **SSOT atoms** — content-addressed governance facts with SHA-256 integrity

## Documentation

- [MORPHISM Framework](docs/governance/MORPHISM.md) — full governance reference
- [Normative Kernel](docs/governance/morphism-kernel.md) — the 7 invariants
- [Getting Started](docs/onboarding.md) — onboarding guide
- [Architecture Decisions](docs/adr/001-canonical-repos-consolidation.md) — ADR index
