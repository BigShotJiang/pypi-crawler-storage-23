# SSOT — Morphism Systems Authority

This monorepo is the single source of truth for the **Morphism Categorical Governance Framework**.

<!-- SSOT:monorepo-scope:begin -->

## Canonical

This monorepo is the canonical source for all Morphism governance artifacts. No external fork, mirror, or copy is authoritative.

## Governance Documents

| Document | Purpose |
|----------|---------|
| [AGENTS.md](AGENTS.md) | Root governance rules |
| [SSOT.md](SSOT.md) | This file — scope and authority |
| [GUIDELINES.md](GUIDELINES.md) | Naming, git, code style conventions |
| [CLAUDE.md](CLAUDE.md) | Claude Code configuration |
| [docs/governance/MORPHISM.md](docs/governance/MORPHISM.md) | Consolidated framework reference (7 invariants, 10 tenets) |
| [docs/governance/MORPHISM_FORMAL.md](docs/governance/MORPHISM_FORMAL.md) | Formal definitions and theorem statements (source for formalization) |
| [docs/TODO.md](docs/TODO.md) | Deferred work backlog (date \| priority \| area \| owner \| task \| next-step) |

## Configuration

| Config | Purpose |
|--------|---------|
| [.morphism/config.json](.morphism/config.json) | Consumer configuration (discovery, validation) |
| [.morphism/ide-configs/cursor/RULES_AND_SKILLS.md](.morphism/ide-configs/cursor/RULES_AND_SKILLS.md) | Cursor workflow map (which rule/skill per morphism task) |
| [docs/ssot/registry.json](docs/ssot/registry.json) | SSOT atom registry (id, file, sha256, consumers) |
| [package.json](package.json) | npm workspaces root |
| [turbo.json](turbo.json) | Turborepo task orchestration |
| [pyproject.toml](pyproject.toml) | Python core configuration |

Governance scripts: `scripts/ssot_extract.py`, `scripts/ssot_verify.py`, `scripts/docs_sync.py`, `scripts/docs_graph.py`, `scripts/maturity_score.py`, `scripts/policy_check.py`, `scripts/verify_pipeline.py`, `scripts/docs_quality_report.py`.

## Scope Boundaries

| Directory | Scope |
|-----------|-------|
| `apps/morphism/` | **Monorepo app** — Next.js, governed by Turborepo |
| `packages/shared/` | **Shared package** — `@morphism-systems/shared` TS utilities |
| `packages/agentic-math/` | **npm package** — `@morphism-systems/agentic-math` MCP math server |
| `packages/mcp-server/` | **npm package** — `@morphism-systems/mcp-server` governance MCP server |
| `packages/cli/` | **npm package** — `@morphism-systems/cli` governance CLI |
| `packages/plugin-bundle/` | **npm package** — `@morphism-systems/plugin-bundle` one-command installer |
| `src/morphism/` | **Python core** — category theory engine + CLI |
| `docs/`, `scripts/` | **Governance** — documentation and automation |
| `archive/` | **Read-only** — historical artifacts |
<!-- SSOT:monorepo-scope:end -->
