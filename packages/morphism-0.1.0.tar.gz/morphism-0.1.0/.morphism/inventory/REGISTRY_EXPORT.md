# Component Registry

**Total Components:** 8

| Name | Type | Version | Status | Maturity |
|------|------|---------|--------|----------|
| Morphism Plugin | plugin | 1.1.0 | active | beta |
| Repo Superpowers Plugin | plugin | 1.0.0 | active | beta |
| DOCX Skill | skill | 1.0.0 | active | polished |
| Code Reviewer Agent | agent | 1.0.0 | active | polished |
| Documentation Writer Agent | agent | 1.0.0 | active | beta |
| Context Optimizer Agent | agent | 1.0.0 | active | alpha |
| Orchestrator Agent | agent | 1.0.0 | active | experimental |
| Morphism Validation MCP Server | mcp-server | 1.0.0 | active | beta |
