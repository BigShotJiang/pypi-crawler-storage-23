#!/usr/bin/env bash
#
# Morphism Component Registry Manager
# Cross-platform tool for managing component inventory
#
# Usage:
#   ./manage-registry.sh list [type]           - List components (optionally by type)
#   ./manage-registry.sh add <component.json>  - Add component from JSON file
#   ./manage-registry.sh update <id>           - Update component by ID
#   ./manage-registry.sh remove <id>           - Remove component by ID
#   ./manage-registry.sh sync                  - Sync with installed_plugins.json
#   ./manage-registry.sh validate              - Validate registry against schema
#   ./manage-registry.sh export <format>       - Export (json|csv|md|html)
#   ./manage-registry.sh search <query>        - Search components
#   ./manage-registry.sh stats                 - Show statistics

set -euo pipefail

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REGISTRY_FILE="${SCRIPT_DIR}/COMPONENT_REGISTRY.json"
SCHEMA_FILE="${SCRIPT_DIR}/../schemas/component-registry.schema.json"
AUDIT_FILE="${SCRIPT_DIR}/COMPONENT_AUDIT_2026-02-11.md"

# Detect platform
if [[ -f "/proc/version" ]] && grep -qi microsoft /proc/version; then
    PLATFORM="wsl"
    CLAUDE_HOME="/home/$(whoami)/.claude"
    WINDOWS_CONFIGS="/mnt/c/Users/$(powershell.exe -Command "Write-Host -NoNewline \$env:USERNAME" 2>/dev/null | tr -d '\r')/Configs"
elif [[ "$OSTYPE" == "msys" ]] || [[ "$OSTYPE" == "win32" ]]; then
    PLATFORM="windows"
    CLAUDE_HOME="$HOME/.claude"
    WINDOWS_CONFIGS="$(cygpath -u "C:/Users/$USERNAME/Configs")"
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    PLATFORM="linux"
    CLAUDE_HOME="$HOME/.claude"
elif [[ "$OSTYPE" == "darwin"* ]]; then
    PLATFORM="macos"
    CLAUDE_HOME="$HOME/.claude"
else
    PLATFORM="unknown"
    CLAUDE_HOME="$HOME/.claude"
fi

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
MAGENTA='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m' # No Color

# ─────────────────────────────────────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────────────────────────────────────

log_info() {
    echo -e "${BLUE}ℹ${NC} $*"
}

log_success() {
    echo -e "${GREEN}✓${NC} $*"
}

log_warning() {
    echo -e "${YELLOW}⚠${NC} $*"
}

log_error() {
    echo -e "${RED}✗${NC} $*" >&2
}

log_section() {
    echo -e "\n${WHITE}═══${NC} ${CYAN}$*${NC} ${WHITE}═══${NC}"
}

# Check if jq is available (optional but recommended)
HAS_JQ=false
if command -v jq &> /dev/null; then
    HAS_JQ=true
fi

# Parse JSON without jq (basic fallback)
json_get() {
    local file=$1
    local path=$2
    if $HAS_JQ; then
        jq -r "$path" "$file" 2>/dev/null || echo ""
    else
        # Basic grep-based extraction (limited)
        grep -Po "\"${path##*.}\"\\s*:\\s*\"\\K[^\"]*" "$file" 2>/dev/null | head -1 || echo ""
    fi
}

# Normalize path for current platform
normalize_path() {
    local path=$1
    case $PLATFORM in
        wsl)
            # Convert Windows paths to WSL
            if [[ $path =~ ^[A-Z]: ]]; then
                path=$(echo "$path" | sed 's|^C:|/mnt/c|' | sed 's|\\|/|g')
            fi
            ;;
        windows)
            # Convert WSL paths to Windows
            if [[ $path =~ ^/mnt/([a-z]) ]]; then
                drive=$(echo "${BASH_REMATCH[1]}" | tr '[:lower:]' '[:upper:]')
                path=$(echo "$path" | sed "s|^/mnt/[a-z]|${drive}:|" | sed 's|/|\\|g')
            fi
            ;;
    esac
    echo "$path"
}

# ─────────────────────────────────────────────────────────────────────────────
# Core Functions
# ─────────────────────────────────────────────────────────────────────────────

list_components() {
    local filter_type="${1:-}"

    log_section "Component Registry"
    log_info "Platform: $PLATFORM | Registry: $REGISTRY_FILE"
    echo

    if [[ ! -f "$REGISTRY_FILE" ]]; then
        log_error "Registry file not found: $REGISTRY_FILE"
        return 1
    fi

    if ! $HAS_JQ; then
        log_warning "jq not found. Install jq for better JSON processing."
        log_info "Showing basic listing..."
        cat "$REGISTRY_FILE"
        return 0
    fi

    # Get total count
    local total=$(jq '.statistics.totalComponents' "$REGISTRY_FILE")
    log_info "Total Components: ${WHITE}$total${NC}\n"

    # Filter by type if specified
    local jq_filter='.components[]'
    if [[ -n "$filter_type" ]]; then
        jq_filter=".components[] | select(.type == \"$filter_type\")"
        log_info "Filtering by type: ${WHITE}$filter_type${NC}\n"
    fi

    # Print table header
    printf "${WHITE}%-30s %-15s %-10s %-12s %-10s${NC}\n" \
        "NAME" "TYPE" "VERSION" "STATUS" "MATURITY"
    printf "${WHITE}%-30s %-15s %-10s %-12s %-10s${NC}\n" \
        "$(printf '─%.0s' {1..30})" \
        "$(printf '─%.0s' {1..15})" \
        "$(printf '─%.0s' {1..10})" \
        "$(printf '─%.0s' {1..12})" \
        "$(printf '─%.0s' {1..10})"

    # List components
    jq -r "$jq_filter | [.name, .type, .version, .status, .maturity] | @tsv" "$REGISTRY_FILE" | \
    while IFS=$'\t' read -r name type version status maturity; do
        # Truncate long names
        if [[ ${#name} -gt 28 ]]; then
            name="${name:0:25}..."
        fi

        # Color code status
        case $status in
            active) status_color=$GREEN ;;
            inactive) status_color=$YELLOW ;;
            failed) status_color=$RED ;;
            *) status_color=$NC ;;
        esac

        # Color code maturity
        case $maturity in
            polished) maturity_icon="✨" ;;
            beta) maturity_icon="🚀" ;;
            alpha) maturity_icon="🔨" ;;
            experimental) maturity_icon="🧪" ;;
            deprecated) maturity_icon="❌" ;;
            archived) maturity_icon="🗄️" ;;
            *) maturity_icon="" ;;
        esac

        printf "%-30s %-15s %-10s ${status_color}%-12s${NC} %-10s\n" \
            "$name" "$type" "$version" "$status" "$maturity_icon $maturity"
    done
}

sync_plugins() {
    log_section "Syncing Plugins from installed_plugins.json"

    local installed_plugins_file
    if [[ $PLATFORM == "wsl" ]] && [[ -n "${WINDOWS_CONFIGS:-}" ]]; then
        installed_plugins_file="${WINDOWS_CONFIGS}/plugins/installed_plugins.json"
    else
        installed_plugins_file="${CLAUDE_HOME}/plugins/installed_plugins.json"
    fi

    if [[ ! -f "$installed_plugins_file" ]]; then
        log_error "installed_plugins.json not found at: $installed_plugins_file"
        return 1
    fi

    log_info "Reading from: $installed_plugins_file"

    if ! $HAS_JQ; then
        log_error "jq is required for sync operation"
        return 1
    fi

    # Extract plugin list
    local plugin_count=$(jq '.plugins | length' "$installed_plugins_file")
    log_info "Found $plugin_count plugins to sync"

    # TODO: Implement sync logic
    # - Read each plugin from installed_plugins.json
    # - Check if exists in registry
    # - Add/update as needed

    log_warning "Sync implementation in progress..."
}

show_stats() {
    log_section "Component Statistics"

    if [[ ! -f "$REGISTRY_FILE" ]]; then
        log_error "Registry file not found: $REGISTRY_FILE"
        return 1
    fi

    if ! $HAS_JQ; then
        log_error "jq is required for stats"
        return 1
    fi

    # Total
    local total=$(jq '.statistics.totalComponents' "$REGISTRY_FILE")
    echo -e "${WHITE}Total Components:${NC} $total\n"

    # By Type
    echo -e "${CYAN}By Type:${NC}"
    jq -r '.statistics.byType | to_entries[] | "  \(.key): \(.value)"' "$REGISTRY_FILE"
    echo

    # By Status
    echo -e "${CYAN}By Status:${NC}"
    jq -r '.statistics.byStatus | to_entries[] | "  \(.key): \(.value)"' "$REGISTRY_FILE"
    echo

    # By Maturity
    echo -e "${CYAN}By Maturity:${NC}"
    jq -r '.statistics.byMaturity | to_entries[] | "  \(.key): \(.value)"' "$REGISTRY_FILE"
    echo

    # Platform info
    echo -e "${CYAN}Platform:${NC}"
    jq -r '.platform | "  OS: \(.os)\n  Architecture: \(.architecture)\n  Environment: \(.environment)"' "$REGISTRY_FILE"
}

search_components() {
    local query="${1:-}"

    if [[ -z "$query" ]]; then
        log_error "Search query required"
        return 1
    fi

    log_section "Search Results: '$query'"

    if ! $HAS_JQ; then
        log_error "jq is required for search"
        return 1
    fi

    # Search in name, description, tags
    jq -r --arg q "$query" '.components[] |
        select(
            (.name | ascii_downcase | contains($q | ascii_downcase)) or
            (.description | ascii_downcase | contains($q | ascii_downcase)) or
            (.tags[]? | ascii_downcase | contains($q | ascii_downcase))
        ) |
        "\(.name) (\(.type)) - \(.description)"' "$REGISTRY_FILE" | \
    while read -r line; do
        echo -e "  ${GREEN}•${NC} $line"
    done
}

validate_registry() {
    log_section "Validating Registry"

    if [[ ! -f "$REGISTRY_FILE" ]]; then
        log_error "Registry file not found: $REGISTRY_FILE"
        return 1
    fi

    if [[ ! -f "$SCHEMA_FILE" ]]; then
        log_warning "Schema file not found: $SCHEMA_FILE"
        log_info "Skipping schema validation"
    fi

    # Basic JSON validation
    if $HAS_JQ; then
        if jq empty "$REGISTRY_FILE" 2>/dev/null; then
            log_success "Registry JSON is valid"
        else
            log_error "Registry JSON is invalid"
            return 1
        fi
    else
        log_warning "jq not available, skipping validation"
    fi

    # TODO: Add schema validation if ajv is available
}

show_help() {
    cat << EOF
${WHITE}Morphism Component Registry Manager${NC}

${CYAN}Usage:${NC}
  $(basename "$0") <command> [options]

${CYAN}Commands:${NC}
  ${WHITE}list${NC} [type]              List all components (optionally filter by type)
  ${WHITE}add${NC} <file.json>          Add component from JSON file
  ${WHITE}update${NC} <id>              Update component by ID
  ${WHITE}remove${NC} <id>              Remove component by ID
  ${WHITE}sync${NC}                     Sync with installed_plugins.json
  ${WHITE}validate${NC}                 Validate registry against schema
  ${WHITE}search${NC} <query>           Search components by name/description/tags
  ${WHITE}stats${NC}                    Show component statistics
  ${WHITE}help${NC}                     Show this help message

${CYAN}Component Types:${NC}
  plugin, skill, agent, mcp-server, workflow, orchestration, hook, extension

${CYAN}Examples:${NC}
  $(basename "$0") list                    # List all components
  $(basename "$0") list plugin             # List only plugins
  $(basename "$0") search morphism         # Search for 'morphism'
  $(basename "$0") sync                    # Sync plugins from Claude
  $(basename "$0") stats                   # Show statistics

${CYAN}Platform:${NC} $PLATFORM
${CYAN}Registry:${NC} $REGISTRY_FILE
EOF
}

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

main() {
    local command="${1:-help}"
    shift || true

    case $command in
        list)
            list_components "$@"
            ;;
        add)
            log_error "Add command not yet implemented"
            return 1
            ;;
        update)
            log_error "Update command not yet implemented"
            return 1
            ;;
        remove)
            log_error "Remove command not yet implemented"
            return 1
            ;;
        sync)
            sync_plugins "$@"
            ;;
        validate)
            validate_registry "$@"
            ;;
        search)
            search_components "$@"
            ;;
        stats)
            show_stats "$@"
            ;;
        help|--help|-h)
            show_help
            ;;
        *)
            log_error "Unknown command: $command"
            echo
            show_help
            return 1
            ;;
    esac
}

main "$@"
