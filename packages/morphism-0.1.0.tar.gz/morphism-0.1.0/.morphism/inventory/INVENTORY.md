# Kiro Workspace Inventory

**Purpose:** Canonical catalog of all reusable components across the workspace.

**Last Updated:** 2026-02-07

**See also:** `.kiro/MATURITY.md` for ownership and publishability tracking.

---

## Taxonomy

### 1. Prompts (Agent Personalities)
**Location:** `~/.kiro/steering/*.md` (global) or `.kiro/steering/*.md` (workspace)
**Purpose:** Specialized agent behaviors and domain expertise
**Format:** Markdown with frontmatter (name, description, triggers, license)

### 2. Skills (Procedural Knowledge)
**Location:** `~/.kiro/steering/*.md` (global) or `.kiro/steering/*.md` (workspace)
**Purpose:** Step-by-step workflows for specific tasks (e.g., docx manipulation)
**Format:** Markdown with Quick Reference tables, examples, critical rules

### 3. Workflows (Multi-Step Processes)
**Location:** `.kiro/workflows/*.md` or `docs/workspace/WORKFLOWS.md`
**Purpose:** Orchestrated sequences across multiple tools/skills
**Format:** Markdown with numbered steps, decision trees

### 4. Agents/Schemas (Structured Configs)
**Location:** `.kiro/agents/*.json` or `.kiro/schemas/*.json`
**Purpose:** Formal agent definitions, validation schemas
**Format:** JSON/YAML with strict schema

### 5. Orchestrations (Multi-Agent Coordination)
**Location:** `.kiro/orchestrations/*.md` or `.kiro/orchestrations/*.json`
**Purpose:** Parallel/sequential agent coordination patterns
**Format:** Markdown or JSON with dependency graphs

### 6. Layouts/Templates (Boilerplates)
**Location:** `.kiro/templates/` or `templates/`
**Purpose:** Project scaffolds, file templates, directory structures
**Format:** Directory trees with placeholder files

### 7. MCPs (Model Context Protocols)
**Location:** `.kiro/settings/mcp.json`
**Purpose:** External tool integrations (servers, APIs)
**Format:** JSON configuration

### 8. CLIs (Command-Line Tools)
**Location:** `scripts/` or `bin/`
**Purpose:** Executable automation scripts
**Format:** Shell, Python, Node.js with shebang

### 9. Specs (Requirements & Design)
**Location:** `.kiro/specs/`
**Purpose:** Detailed specifications for features/systems
**Format:** Markdown with requirements, design, tasks

### 10. Plans (Strategic Roadmaps)
**Location:** `docs/plans/`
**Purpose:** Multi-phase implementation strategies
**Format:** Markdown with phases, priorities, timelines

---

## Current Inventory

### Prompts (Agent Personalities)
| Name | Location | Triggers | Status |
|------|----------|----------|--------|
| agentic-math | `~/.kiro/steering/agentic-math-prompt.md` | formal verification, Lean 4, convergence | ✅ Active |
| global-standards | `~/.kiro/steering/global-standards.md` | (always included) | ✅ Active |

### Skills (Procedural Knowledge)
| Name | Location | Triggers | Status |
|------|----------|----------|--------|
| docx | `~/.kiro/steering/docx.md` | Word doc, .docx, document creation | ✅ Active |

### Workflows (Multi-Step Processes)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| daily-operations | `.kiro/workflows/daily-operations.md` | Daily workspace tasks | ✅ Active |
| multi-agent-worktrees | `.kiro/workflows/multi-agent-worktrees.md` | Parallel git lanes | ✅ Active |
| documentation-validation | `.kiro/workflows/documentation-validation.md` | Doc validation | ✅ Active |
| project-creation | `.kiro/workflows/project-creation.md` | Create new projects | ✅ Active |

### Agents (Autonomous Definitions)
| Name | Location | Purpose | Axioms | κ | Status |
|------|----------|---------|--------|---|--------|
| code-reviewer | `.morphism/agents/code-reviewer.json` | Code quality review | A0,A7,A8 | 0.15 | ✅ Active |
| doc-writer | `.morphism/agents/doc-writer.json` | Documentation generation | A0,A5,A7 | 0.30 | ✅ Active |
| context-optimizer | `.morphism/agents/context-optimizer.json` | Context management | A1,A7,A8 | 0.25 | ✅ Active |
| orchestrator | `.morphism/agents/orchestrator.json` | Multi-agent coordination | A0,A3,A8,A9 | 0.01125 | 🧪 Experimental |

### Schemas (Validation Definitions)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| agent.schema.json | `.kiro/schemas/agent.schema.json` | Agent definition validation | ✅ Active |
| workflow.schema.json | `.kiro/schemas/workflow.schema.json` | Workflow definition validation | ✅ Active |
| skill.schema.json | `.kiro/schemas/skill.schema.json` | Skill definition validation | ✅ Active |
| orchestration.schema.json | `.kiro/schemas/orchestration.schema.json` | Orchestration pattern validation | ✅ Active |

### Orchestrations (Multi-Agent Coordination)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| worktree-parallel | `.kiro/orchestrations/worktree-parallel.md` | Parallel git worktree lanes | ✅ Active |
| sequential-validation | `.kiro/orchestrations/sequential-validation.md` | Chained validation pipeline | ✅ Active |
| parallel-skills | `.kiro/orchestrations/parallel-skills.md` | Parallel skill execution | ✅ Active |

### Hooks (Git/Event Triggers)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| pre-commit-validation | `.kiro/hooks/pre-commit-validation.sh` | Pre-commit quality checks | ✅ Active |
| post-merge-sync | `.kiro/hooks/post-merge-sync.sh` | Post-merge synchronization | ✅ Active |
| workflow-trigger | `.kiro/hooks/workflow-trigger.sh` | Auto-trigger workflows on events | ✅ Active |
| pr-validation | `.kiro/hooks/pr-validation.sh` | PR quality validation | ✅ Active |

### Powers (Platform Capabilities)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| context-management | `.kiro/powers/context-management.md` | Token/context optimization | ✅ Active |
| parallel-execution | `.kiro/powers/parallel-execution.md` | Parallel agent coordination | ✅ Active |

### Layouts/Templates (Boilerplates)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| (none yet) | `.kiro/templates/` | TBD | 📋 Planned |

### MCPs (Model Context Protocols)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| mcp-minimal | `.kiro/settings/mcp-minimal.json` | Minimal MCP config | ✅ Active |
| mcp | `.kiro/settings/mcp.json` | Full MCP config | ✅ Active |

### CLIs (Command-Line Tools)
| Name | Location | Purpose | Status |
|------|----------|---------|--------|
| workspace | `workspace` | Workspace management | ✅ Active |
| workspace-health | `scripts/workspace-health.sh` | Health checks | ✅ Active |
| pull-all | `scripts/pull-all.sh` | Bulk git pull | ✅ Active |
| worktree-agents | `scripts/worktree-agents.sh` | Multi-agent lanes | ✅ Active |
| validate-inventory | `scripts/validate-inventory.sh` | Inventory validation | ✅ Active |
| check-agents-pointers | `scripts/check-agents-pointers.sh` | AGENTS.md pointer validation | ✅ Active |
| status-all | `scripts/status-all.sh` | Repo status | ✅ Active |
| validate-all-projects | `scripts/validate-all-projects.sh` | Project validation | ✅ Active |
| workspace-api | `scripts/workspace-api.sh` | API interface | 🧪 Experimental |
| workspace-analytics | `scripts/workspace-analytics.sh` | Analytics | 🧪 Experimental |
| workspace-dashboard | `scripts/workspace-dashboard.sh` | Dashboard | ✅ Active |
| workspace-metrics | `scripts/workspace-metrics.sh` | Metrics | 🧪 Experimental |
| workspace-monitor | `scripts/workspace-monitor.sh` | Monitoring | 🧪 Experimental |
| workspace-portfolio | `scripts/workspace-portfolio.sh` | Portfolio view | 🧪 Experimental |
| workspace-collab | `scripts/workspace-collab.sh` | Collaboration | 🧪 Experimental |
| workspace-migrate | `scripts/workspace-migrate.sh` | Migration | 🧪 Experimental |
| health-check | `scripts/health-check.sh` | Health check | ✅ Active |
| security-preflight | `scripts/security-preflight.sh` | Security checks | ✅ Active |
| validate-prompt-compliance | `scripts/validate-prompt-compliance.sh` | Prompt validation | ✅ Active |
| template-manager | `scripts/template-manager.sh` | Template management | 🧪 Experimental |
| generate-template | `scripts/generate-template.sh` | Template generation | 🧪 Experimental |
| setup-from-template | `scripts/setup-from-template.sh` | Template setup | 🧪 Experimental |
| setup-new-project | `scripts/setup-new-project.sh` | Project setup | 🧪 Experimental |
| project | `scripts/project.sh` | Project management | 🧪 Experimental |
| project-status | `scripts/project-status.sh` | Project status | 🧪 Experimental |
| init-workspace | `scripts/init-workspace.sh` | Workspace init | ✅ Active |
| update-workspace | `scripts/update-workspace.sh` | Workspace update | ✅ Active |
| backup-restore | `scripts/backup-restore.sh` | Backup/restore | 🧪 Experimental |
| track-transformation | `scripts/track-transformation.sh` | Track changes | 🧪 Experimental |
| scheduler | `scripts/scheduler.sh` | Task scheduling | 🧪 Experimental |
| api | `scripts/api.sh` | API | 🧪 Experimental |
| validate | `scripts/validate.sh` | Generic validation | ✅ Active |
| architecture-redesign-audit | `scripts/architecture-redesign-audit.sh` | Architecture audit | 🗄️ Archived |

### Specs (Requirements & Design)
| Name | Location | Status |
|------|----------|--------|
| agent-context-optimizer | `.kiro/specs/agent-context-optimizer/` | 🚧 In Progress |

### Plans (Strategic Roadmaps)
| Name | Location | Status |
|------|----------|--------|
| phase1-verification-first | `docs/plans/2025-02-05-phase1-verification-first.md` | ✅ Complete |
| phase2-domain-knowledge-skills | `docs/plans/2025-02-05-phase2-domain-knowledge-skills.md` | 🚧 In Progress |
| phase3-custom-subagents | `docs/plans/2025-02-05-phase3-custom-subagents.md` | 📋 Planned |
| enterprise-skills-development | `docs/plans/2026-02-06-enterprise-skills-development.md` | 📋 Planned |
| skill-creation-plan | `.kiro/steering/SKILL_CREATION_PLAN.md` | 🚧 In Progress |

---

## Decision Criteria: Mathematical Principle Selection

### Why Category Theory (A0, A3)
**Chosen:** Composition is the fundamental operation of multi-agent systems. `composition_associative` in CategoryTheory.lean proves pipeline ordering doesn't affect correctness.
**Rejected:** Graph-theoretic coordination (connectivity without composition semantics).

### Why Banach Fixed-Point Theorem (A8)
**Chosen:** Constructive convergence with explicit rate: d(Γⁿ(s₀), s*) ≤ κⁿ/(1-κ)·d(Γ(s₀), s₀). Gives concrete iteration counts.
**Rejected:** Brouwer Fixed-Point Theorem (existence without constructiveness or rate).

### Why Shannon Entropy (A1)
**Chosen:** Computable, measurable. `meetsOptimizationTarget` gives concrete 40%/80% guarantee.
**Rejected:** Kolmogorov complexity (uncomputable — violates A7: Decidability).

### Why Sheaf Theory (A4, A5)
**Chosen:** Precise formulation of "local consistency → global consistency." H¹ = 0 is obstruction-free.
**Status:** Definitions formalized, proofs incomplete (sorry). ~15% proof gap. Acceptable as supporting result.

---

## Traceability Matrix: Agent Capabilities → Mathematical Foundations

| Agent Capability | Axiom | Lean Theorem | Proof Status |
|-----------------|-------|--------------|--------------
| Code review convergence | A8 | `governance_converges` | ✅ proven |
| Review perturbation recovery | A8 | `perturbation_recovery` | ✅ proven |
| Multi-agent composition | A3 | `composition_associative` | ✅ proven |
| Composed κ improvement | A3,A8 | `composition_improves_contraction` | ✅ proven |
| Agent coordination safety | A3 | `coordinated_composition_safe` | ✅ proven |
| Context entropy reduction | A1 | `governance_reduces_entropy` | ✅ proven (coherence ≤ 10/13) |
| Compression target (40%/80%) | A1 | `composed_compression_target` | ✅ proven |
| Iterated compression bound | A1 | `iterated_compression_bound` | ✅ proven |
| Iterated governance improvement | A3,A8 | `iterated_governance_improves` | ✅ proven |
| Documentation coherence | A5 | `coherence_iff_vanishing_cohomology` | ⚠️ sorry (Sheaf API) |
| Governance Bell inequality | A0 | `structure_relative_bound` | ✅ proven |
| Invariant preservation | A0 | `mantra` | ✅ proven |
| DAG acyclicity | A6 | `acyclicity` | ✅ proven |
| Decidable invariants | A7 | `decidability` | ✅ proven |

**Coverage:** 14 capabilities → 13 proven (92.9%), 1 sorry (7.1%) — blocked on Mathlib Sheaf API

---

## Negative Results & Boundary Conditions

### Documented Failures
1. **Entropy reduction has boundary.** `governance_reduces_entropy` now proven with hypothesis `coherence ≤ 10/13`. The theorem is FALSE when coherence > 10/13 ≈ 0.769 — this is a genuine mathematical boundary, not a proof gap.
2. **LLM stochasticity unformalizable.** κ values assume deterministic operators. Real LLM variance increases effective κ.
3. **Sheaf proofs require Mathlib API.** Čech cohomology H¹ = 0 requires Mathlib Sheaf API still under development. Only remaining sorry.
4. ~~**Fixed-point final assembly.**~~ RESOLVED: `exists_unique_fixed_point` fully proven (existence via continuity + tendsto_nhds_unique, uniqueness via contraction contradiction).
5. ~~**Network convergence induction.**~~ RESOLVED: `network_converges_faster` proven via `foldl_compose_kappa` helper + `list_prod_le_elem`.
6. **Learning convergence requires rate hypothesis.** `learning_converges_to_optimal` now proven with explicit learning rate `r > 0` such that `κ_{n+1} ≤ (1-r) · κ_n`. Without this, the theorem is false (a decreasing sequence need not converge to 0).
7. **Robustness requires preservation hypothesis.** `governance_increases_robustness` now proven with hypothesis that governance preserves invariants. Without this, invariants at the original state don't transfer to the governed state.

### Boundary Conditions
| Condition | Affected Guarantee | Severity |
|-----------|-------------------|----------|
| coherence > 0.556, token reduction < 20% | Entropy reduction | Documented boundary |
| Files > 500KB | Code review convergence rate | Constraint |
| > 3 iterated compressions | Coherence below 0.512× | Diminishing returns |
| Concurrent code changes during doc gen | Doc-writer convergence | Resets iteration |
| > 5 agents in pipeline | Floating-point κ precision | Engineering limit |
| LLM stochasticity | All κ values | Acknowledged |

---

## Governance Documents (Not Inventory)

These are **canonical references**, not reusable components:

- `morphism/MORPHISM.md` - 10 axioms → 42 tenets
- `morphism/AGENTS.md` - Agent conventions
- `morphism/SSOT.md` - Single source of truth
- `docs/workspace/LANDING.md` - Workspace overview
- `.morphism/metrics/metrics.json` - Quantified proof & convergence metrics

---

## Maintenance Rules

1. **Add entries immediately** when creating new components
2. **Update status** as work progresses (📋 Planned → 🚧 In Progress → ✅ Active → 🗄️ Archived)
3. **Link to source** - always include file path
4. **Document triggers** - how does Kiro know to use this?
5. **Review quarterly** - archive unused, consolidate duplicates

---

## Status Legend

- ✅ **Active** - In use, maintained
- 🚧 **In Progress** - Under development
- 📋 **Planned** - Roadmap item
- 🗄️ **Archived** - Deprecated, read-only
- 🧪 **Experimental** - Prototype, not production-ready
- ❌ **Deprecated** - Do not use

---

## Adding New Items

### Prompts/Skills
```bash
# Create in global steering (all workspaces)
vim ~/.kiro/steering/my-skill.md

# Or workspace-specific
vim .kiro/steering/my-skill.md

# Update this inventory
vim .kiro/INVENTORY.md
```

### Workflows
```bash
mkdir -p .kiro/workflows
vim .kiro/workflows/my-workflow.md
```

### Templates
```bash
mkdir -p .kiro/templates/my-template
# Add files...
```

### MCPs
```bash
# Edit existing config
vim .kiro/settings/mcp.json
```

### CLIs
```bash
# Add to scripts/
vim scripts/my-tool.sh
chmod +x scripts/my-tool.sh
```

---

## Search Commands

```bash
# Find all prompts/skills
find ~/.kiro/steering .kiro/steering -name "*.md" 2>/dev/null

# Find all workflows
find .kiro/workflows docs/workspace -name "*WORKFLOW*.md" 2>/dev/null

# Find all templates
find .kiro/templates templates -type d -maxdepth 1 2>/dev/null

# Find all MCPs
find .kiro/settings -name "mcp*.json" 2>/dev/null

# Find all CLIs
find scripts bin -type f -executable 2>/dev/null
```

---

## Next Steps

1. ✅ Create this inventory (DONE)
2. 📋 Create `.kiro/workflows/` directory
3. 📋 Create `.kiro/templates/` directory
4. 📋 Migrate SKILL_CREATION_PLAN items to proper skills
5. 📋 Document existing workflows from `docs/workspace/WORKFLOWS.md`
6. 📋 Create skill template for consistent formatting
