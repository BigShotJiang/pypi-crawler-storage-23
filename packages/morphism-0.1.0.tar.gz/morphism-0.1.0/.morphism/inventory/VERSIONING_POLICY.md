# Versioning Policy

**Version:** 1.0.0
**Last Updated:** 2026-02-11

---

## Overview

All Morphism components use **semantic versioning** (MAJOR.MINOR.PATCH) with versions assigned based on maturity level.

## Version by Maturity

| Maturity Level | Version Range | Description | Examples |
|----------------|---------------|-------------|----------|
| **✨ Polished** | v1.x.x | Production-ready, well-documented, stable API | code-reviewer, daily-operations |
| **🚀 Beta** | v0.9.x | Ready for external use, API mostly stable | doc-writer, orchestrator |
| **🔨 Alpha** | v0.5.x | Working but needs refinement, API may change | context-optimizer |
| **🌱 Prototype/Experimental** | v0.1.x | Early stage, API unstable | New experimental features |

## Versioning Rules

### MAJOR version (x.0.0)
Increment when:
- Making incompatible API changes
- Breaking backward compatibility
- Major architectural changes

### MINOR version (0.x.0)
Increment when:
- Adding functionality in a backward-compatible manner
- Deprecating functionality
- Introducing substantial new features
- Promoting from Beta to Polished

### PATCH version (0.0.x)
Increment when:
- Making backward-compatible bug fixes
- Documentation updates
- Performance improvements
- Minor tweaks

## Promotion Paths

### Alpha → Beta (v0.5.x → v0.9.0)
Requirements:
- Feature complete
- Basic documentation
- Internal testing passed
- API stabilizing

### Beta → Polished (v0.9.x → v1.0.0)
Requirements:
- Production usage demonstrated
- Complete documentation
- Examples and tutorials
- Comprehensive testing
- Stable API
- Changelog complete

### Polished → Stable (v1.x.x → v2.0.0+)
Requirements:
- Mature, widely adopted
- Minimal breaking changes expected
- Long-term support commitment

## Examples

### Component: code-reviewer
- **Maturity:** Polished
- **Current Version:** v1.2.0
- **Rationale:** Production-ready, supports 9 languages, well-documented

### Component: orchestrator
- **Maturity:** Beta (recently promoted from Experimental)
- **Current Version:** v0.9.0 (was v1.1.0, adjusted to match maturity)
- **Rationale:** Strong foundation, needs production usage data

### Component: context-optimizer
- **Maturity:** Alpha
- **Current Version:** v0.5.0
- **Rationale:** Working but spec in progress, API evolving

## Version Consistency

All component versions must align with their maturity level:
- Changelogs must reflect the component's current version
- dependencies.json must reference correct versions
- Component metadata must be consistent

## Changelog Requirements

Each component must have a changelog following [Keep a Changelog](https://keepachangelog.com/):
- [Unreleased] section for upcoming changes
- Released versions with dates
- Categorized changes (Added, Changed, Deprecated, Removed, Fixed, Security)
- Version numbers match semantic versioning

---

**Policy Approved:** 2026-02-11
**Next Review:** 2026-05-11
