# Morphism Component Inventory System

**Version:** 1.0.0
**Last Updated:** 2026-02-11
**Status:** ✅ Production Ready

---

## Overview

The Morphism Component Inventory System provides comprehensive tracking and management of all skills, agents, plugins, MCPs, workflows, and other components across the Morphism ecosystem. It's designed to work seamlessly across WSL, Windows, Linux, and macOS.

## Quick Start

```bash
# Show statistics
python3 .morphism/inventory/registry-manager.py stats

# List all components
python3 .morphism/inventory/registry-manager.py list

# List only plugins
python3 .morphism/inventory/registry-manager.py list plugin

# Search for components
python3 .morphism/inventory/registry-manager.py search morphism

# Validate registry
python3 .morphism/inventory/registry-manager.py validate

# Export to CSV
python3 .morphism/inventory/registry-manager.py export csv -o components.csv
```

---

## System Architecture

### Files

| File | Purpose | Format |
|------|---------|--------|
| `COMPONENT_REGISTRY.json` | Master component registry | JSON |
| `component-registry.schema.json` | JSON Schema for validation | JSON Schema |
| `registry-manager.py` | Python management tool | Python 3 |
| `manage-registry.sh` | Bash management tool (optional, requires jq) | Bash |
| `COMPONENT_AUDIT_2026-02-11.md` | Initial audit report | Markdown |
| `INVENTORY.md` | Human-readable inventory (deprecated) | Markdown |
| `EXPANDED_INVENTORY.md` | Discovery report | Markdown |
| `MATURITY.md` | Component maturity tracking | Markdown |
| `dependencies.json` | Dependency graph | JSON |

### Schema Structure

```json
{
  "$schema": "component-registry.schema.json",
  "version": "1.0.0",
  "lastUpdated": "2026-02-11T15:45:00Z",
  "platform": {
    "os": "Linux",
    "architecture": "x86_64",
    "environment": "wsl"
  },
  "components": [
    {
      "id": "component-id",
      "name": "Component Name",
      "type": "plugin|skill|agent|mcp-server|...",
      "version": "1.0.0",
      "description": "Description",
      "status": "active|inactive|pending|failed|disabled",
      "maturity": "polished|beta|alpha|experimental|deprecated|archived",
      "platform": "cross-platform|wsl|windows|linux|macos",
      "source": "local|official|community|custom|marketplace",
      "location": {
        "wsl": "/path/in/wsl",
        "windows": "C:\\path\\in\\windows",
        "normalized": "{WORKSPACE}/relative/path"
      },
      "installedAt": "2026-01-28T10:30:00Z",
      "lastUpdated": "2026-01-28T17:48:00Z",
      "dependencies": [],
      "provides": ["capability1", "capability2"],
      "tags": ["tag1", "tag2"],
      "metadata": {}
    }
  ],
  "statistics": {
    "totalComponents": 8,
    "byType": { "plugin": 2, "skill": 1 },
    "byStatus": { "active": 8 },
    "byMaturity": { "polished": 2, "beta": 4 }
  },
  "index": {
    "byId": { "component-id": 0 },
    "byType": { "plugin": [0, 1] },
    "byTag": { "tag1": [0] }
  }
}
```

---

## Component Types

| Type | Description | Example |
|------|-------------|---------|
| `plugin` | Claude Code plugins (local or official) | `morphism@local` |
| `skill` | Procedural knowledge / workflows | `docx-skill` |
| `agent` | Autonomous subagents | `code-reviewer-agent` |
| `mcp-server` | Model Context Protocol servers | `morphism-validation-mcp` |
| `mcp-credential` | MCP credential configurations | `github-mcp-creds` |
| `workflow` | Multi-step processes | `daily-operations` |
| `orchestration` | Multi-agent coordination | `worktree-parallel` |
| `hook` | Git/event triggers | `pre-commit` |
| `extension` | Platform capabilities | `context-management` |
| `schema` | JSON/YAML schemas | `agent.schema.json` |
| `template` | Boilerplate structures | `project-template` |
| `cli` | Command-line tools | `workspace-health.sh` |
| `prompt` | AI agent prompts | `agentic-math-prompt` |
| `plan` | Strategic roadmaps | `phase1-verification-first` |

---

## Status & Maturity

### Status

| Status | Meaning | Use When |
|--------|---------|----------|
| `active` | Component is installed and functional | Ready to use |
| `inactive` | Component is installed but disabled | Temporarily disabled |
| `pending` | Installation/configuration in progress | Being set up |
| `failed` | Component failed to install or run | Needs troubleshooting |
| `disabled` | Component intentionally disabled | Not in use |

### Maturity

| Level | Icon | Meaning | Publishable |
|-------|------|---------|-------------|
| `polished` | ✨ | Production-ready, well-tested | ✅ Yes |
| `beta` | 🚀 | Feature-complete, testing phase | 🟡 Soon |
| `alpha` | 🔨 | Functional but incomplete | ❌ No |
| `experimental` | 🧪 | Proof of concept | ❌ No |
| `deprecated` | ❌ | No longer maintained | ❌ No |
| `archived` | 🗄️ | Historical reference only | ❌ No |

---

## Management Tools

### Python Tool (Recommended)

**No external dependencies required.** Works everywhere Python 3 is available.

```bash
# Alias for convenience
alias registry='python3 .morphism/inventory/registry-manager.py'

# Usage
registry stats                  # Show statistics
registry list                   # List all components
registry list plugin            # List plugins only
registry search <query>         # Search by name/description/tags
registry validate               # Validate and rebuild indices
registry export json            # Export to JSON
registry export csv -o out.csv  # Export to CSV
registry export md -o out.md    # Export to Markdown
```

### Bash Tool (Optional)

**Requires jq.** Provides similar functionality with shell scripting.

```bash
# Install jq first (Ubuntu/Debian)
sudo apt-get install jq

# Usage
bash .morphism/inventory/manage-registry.sh stats
bash .morphism/inventory/manage-registry.sh list
bash .morphism/inventory/manage-registry.sh search <query>
```

---

## Cross-Platform Support

### Path Resolution

The registry handles platform-specific paths automatically:

| Platform | Example Path |
|----------|--------------|
| WSL | `/home/meshal/.claude/plugins/local/morphism` |
| Windows | `C:\Users\mesha\.claude\plugins\local\morphism` |
| Linux | `/home/user/.claude/plugins/local/morphism` |
| macOS | `/Users/user/.claude/plugins/local/morphism` |

**Normalized paths** use placeholders:
- `{CLAUDE_HOME}` → `~/.claude/` or `C:\Users\mesha\.claude\`
- `{WORKSPACE}` → workspace root
- `{WINDOWS_CONFIGS}` → Windows config directory

### Environment Detection

The tool automatically detects:
- Operating system (Linux, Windows, macOS)
- Architecture (x86_64, arm64)
- Environment (WSL, native)

---

## Current Inventory

### Summary (As of 2026-02-11)

| Category | Count | Active |
|----------|-------|--------|
| **Plugins** | 2 | 2 |
| **Skills** | 1 | 1 |
| **Agents** | 4 | 4 |
| **MCP Servers** | 1 | 1 |
| **Total** | **8** | **8** |

### Component List

#### Plugins (2)
- `morphism@local` - v1.1.0 (🚀 beta)
- `repo-superpowers@local` - v1.0.0 (🚀 beta)

#### Skills (1)
- `docx-skill` - v1.0.0 (✨ polished)

#### Agents (4)
- `code-reviewer-agent` - v1.0.0 (✨ polished, κ=0.15)
- `doc-writer-agent` - v1.0.0 (🚀 beta, κ=0.30)
- `context-optimizer-agent` - v1.0.0 (🔨 alpha, κ=0.25)
- `orchestrator-agent` - v1.0.0 (🧪 experimental, κ=0.01125)

#### MCP Servers (1)
- `morphism-validation-mcp` - v1.0.0 (🚀 beta)

---

## Expansion Framework

### Adding New Components

#### Manual Addition

1. Create component JSON file:

```json
{
  "id": "my-component",
  "name": "My Component",
  "type": "skill",
  "version": "1.0.0",
  "description": "Description",
  "status": "active",
  "maturity": "beta",
  "platform": "cross-platform",
  "source": "custom",
  "location": {
    "normalized": "{WORKSPACE}/.morphism/skills/my-component"
  },
  "installedAt": "2026-02-11T16:00:00Z",
  "lastUpdated": "2026-02-11T16:00:00Z",
  "dependencies": [],
  "provides": ["feature1"],
  "tags": ["category1"]
}
```

2. Add to `COMPONENT_REGISTRY.json`:

```bash
# Edit manually or use Python:
python3 << 'EOF'
import json

with open('.morphism/inventory/COMPONENT_REGISTRY.json', 'r+') as f:
    registry = json.load(f)

    # Add your component
    registry['components'].append({
        # ... your component data ...
    })

    # Save
    f.seek(0)
    json.dump(registry, f, indent=2)
    f.truncate()
EOF

# Rebuild indices
python3 .morphism/inventory/registry-manager.py validate
```

#### Auto-Discovery (Future)

```bash
# Scan and discover new components
python3 .morphism/inventory/registry-manager.py discover

# Sync from Claude plugins
python3 .morphism/inventory/registry-manager.py sync plugins

# Sync from .morphism/
python3 .morphism/inventory/registry-manager.py sync morphism
```

---

## Integration

### With .morphism/ System

The registry integrates with:
- `.morphism/agents/*.json` - Agent definitions
- `.morphism/workflows/*.md` - Workflow documents
- `.morphism/hooks/*.sh` - Git hooks
- `.morphism/extensions/*.md` - Platform capabilities
- `.morphism/schemas/*.json` - Validation schemas

### With Claude Plugins

Reads from:
- `{CLAUDE_HOME}/plugins/installed_plugins.json`
- `{CLAUDE_HOME}/plugins/local/*`
- `{CLAUDE_HOME}/plugins/cache/*`

### With Skills

Tracks skills from:
- `.claude/skills/*` (workspace-specific)
- `~/.claude/skills/*` (global)
- Plugin-provided skills

---

## Validation

### Schema Validation

```bash
# Validate registry structure
python3 .morphism/inventory/registry-manager.py validate
```

Checks:
- ✅ JSON syntax valid
- ✅ Required fields present
- ✅ Component IDs unique
- ✅ Dependencies resolved
- ✅ Indices consistent
- ✅ Statistics accurate

### Data Quality

```bash
# Generate quality report
bash .morphism/inventory/validate-enhanced.sh
```

---

## Export Formats

### JSON

```bash
python3 .morphism/inventory/registry-manager.py export json -o components.json
```

Full component data, suitable for:
- Backup/restore
- API integration
- Data processing

### CSV

```bash
python3 .morphism/inventory/registry-manager.py export csv -o components.csv
```

Flat table format, suitable for:
- Excel/Google Sheets
- Database import
- Reporting

### Markdown

```bash
python3 .morphism/inventory/registry-manager.py export md -o components.md
```

Human-readable format, suitable for:
- Documentation
- GitHub wiki
- Status reports

---

## Troubleshooting

### Registry file not found

```bash
# Initialize new registry
cp .morphism/inventory/COMPONENT_REGISTRY.json.template \
   .morphism/inventory/COMPONENT_REGISTRY.json
```

### Invalid JSON

```bash
# Validate JSON syntax
python3 -m json.tool .morphism/inventory/COMPONENT_REGISTRY.json
```

### Missing components

```bash
# Sync from Claude plugins
python3 .morphism/inventory/registry-manager.py sync plugins

# Manual audit
bash .morphism/inventory/discover-components.sh
```

### Cross-platform path issues

Paths are automatically normalized. If issues persist:
1. Check symlinks: `ls -la ~/.claude/`
2. Verify Windows mount: `ls -la /mnt/c/Users/`
3. Update location in registry with both `wsl` and `windows` paths

---

## Roadmap

### ✅ Phase 1: Foundation (Complete)
- [x] Design schema
- [x] Create registry file
- [x] Build management tools
- [x] Initial population (8 components)

### 🔄 Phase 2: Expansion (In Progress)
- [ ] Add all 32 installed plugins
- [ ] Discover plugin-provided skills
- [ ] Catalog MCP credentials
- [ ] Extract workflow metadata

### 📋 Phase 3: Automation (Planned)
- [ ] Auto-discovery from `installed_plugins.json`
- [ ] Auto-discovery from `.morphism/`
- [ ] Sync command for incremental updates
- [ ] Change detection and notifications

### 📋 Phase 4: Advanced Features (Planned)
- [ ] Dependency visualization
- [ ] Version conflict detection
- [ ] Component health checks
- [ ] Usage analytics
- [ ] Recommendation engine

---

## Contributing

### Adding New Component Types

1. Update schema:

```json
// .morphism/schemas/component-registry.schema.json
"componentType": {
  "enum": [
    "plugin",
    "skill",
    // ... existing ...
    "new-type"  // Add here
  ]
}
```

2. Document in this README

3. Update management tools if needed

### Reporting Issues

File issues at: [GitHub Issues](https://github.com/alawein/morphism/issues)

Include:
- Platform (WSL/Windows/Linux/macOS)
- Python version
- Error message
- Steps to reproduce

---

## License

MIT License - See [LICENSE](../../../LICENSE)

---

## References

- **AGENTS.md** - Universal AI IDE standards
- **MORPHISM.md** - Categorical governance framework
- **SSOT.md** - Single Source of Truth hierarchy
- **Component Audit** - `COMPONENT_AUDIT_2026-02-11.md`
- **Maturity Tracking** - `MATURITY.md`
- **Dependencies** - `dependencies.json`

---

**Last Updated:** 2026-02-11
**Maintainers:** Morphism Core Team
**Status:** ✅ Production Ready
