#!/usr/bin/env python3
"""
Morphism Component Registry Manager
Cross-platform Python tool for managing component inventory
"""

import json
import sys
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import argparse

# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

SCRIPT_DIR = Path(__file__).parent
REGISTRY_FILE = SCRIPT_DIR / "COMPONENT_REGISTRY.json"
SCHEMA_FILE = SCRIPT_DIR.parent / "schemas" / "component-registry.schema.json"

# Colors (ANSI escape codes)
class Colors:
    RED = '\033[0;31m'
    GREEN = '\033[0;32m'
    YELLOW = '\033[1;33m'
    BLUE = '\033[0;34m'
    MAGENTA = '\033[0;35m'
    CYAN = '\033[0;36m'
    WHITE = '\033[1;37m'
    NC = '\033[0m'  # No Color

# ─────────────────────────────────────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────────────────────────────────────

def log_info(message: str):
    print(f"{Colors.BLUE}ℹ{Colors.NC} {message}")

def log_success(message: str):
    print(f"{Colors.GREEN}✓{Colors.NC} {message}")

def log_warning(message: str):
    print(f"{Colors.YELLOW}⚠{Colors.NC} {message}")

def log_error(message: str):
    print(f"{Colors.RED}✗{Colors.NC} {message}", file=sys.stderr)

def log_section(message: str):
    print(f"\n{Colors.WHITE}═══{Colors.NC} {Colors.CYAN}{message}{Colors.NC} {Colors.WHITE}═══{Colors.NC}")

def detect_platform() -> str:
    """Detect current platform"""
    if sys.platform == "win32":
        return "windows"
    elif sys.platform == "darwin":
        return "macos"
    elif sys.platform.startswith("linux"):
        # Check if running in WSL
        try:
            with open("/proc/version", "r") as f:
                if "microsoft" in f.read().lower():
                    return "wsl"
        except:
            pass
        return "linux"
    return "unknown"

# ─────────────────────────────────────────────────────────────────────────────
# Registry Operations
# ─────────────────────────────────────────────────────────────────────────────

def load_registry() -> Dict[str, Any]:
    """Load registry from file"""
    if not REGISTRY_FILE.exists():
        log_error(f"Registry file not found: {REGISTRY_FILE}")
        sys.exit(1)

    try:
        with open(REGISTRY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        log_error(f"Invalid JSON in registry: {e}")
        sys.exit(1)
    except Exception as e:
        log_error(f"Failed to load registry: {e}")
        sys.exit(1)

def save_registry(registry: Dict[str, Any]):
    """Save registry to file"""
    try:
        with open(REGISTRY_FILE, 'w', encoding='utf-8') as f:
            json.dump(registry, f, indent=2, ensure_ascii=False)
        log_success(f"Registry saved: {REGISTRY_FILE}")
    except Exception as e:
        log_error(f"Failed to save registry: {e}")
        sys.exit(1)

def rebuild_indices(registry: Dict[str, Any]):
    """Rebuild index structures"""
    components = registry.get('components', [])

    # Build indices
    by_id = {}
    by_type = {}
    by_tag = {}

    for idx, component in enumerate(components):
        comp_id = component.get('id')
        comp_type = component.get('type')
        comp_tags = component.get('tags', [])

        if comp_id:
            by_id[comp_id] = idx

        if comp_type:
            if comp_type not in by_type:
                by_type[comp_type] = []
            by_type[comp_type].append(idx)

        for tag in comp_tags:
            if tag not in by_tag:
                by_tag[tag] = []
            by_tag[tag].append(idx)

    registry['index'] = {
        'byId': by_id,
        'byType': by_type,
        'byTag': by_tag
    }

def rebuild_statistics(registry: Dict[str, Any]):
    """Rebuild statistics"""
    components = registry.get('components', [])

    by_type = {}
    by_status = {}
    by_maturity = {}

    for component in components:
        comp_type = component.get('type')
        comp_status = component.get('status')
        comp_maturity = component.get('maturity')

        if comp_type:
            by_type[comp_type] = by_type.get(comp_type, 0) + 1

        if comp_status:
            by_status[comp_status] = by_status.get(comp_status, 0) + 1

        if comp_maturity:
            by_maturity[comp_maturity] = by_maturity.get(comp_maturity, 0) + 1

    registry['statistics'] = {
        'totalComponents': len(components),
        'byType': by_type,
        'byStatus': by_status,
        'byMaturity': by_maturity
    }

# ─────────────────────────────────────────────────────────────────────────────
# Commands
# ─────────────────────────────────────────────────────────────────────────────

def cmd_list(args):
    """List components"""
    log_section("Component Registry")
    platform = detect_platform()
    log_info(f"Platform: {platform} | Registry: {REGISTRY_FILE}")
    print()

    registry = load_registry()
    components = registry.get('components', [])
    total = len(components)

    log_info(f"Total Components: {Colors.WHITE}{total}{Colors.NC}\n")

    # Filter by type if specified
    if args.type:
        components = [c for c in components if c.get('type') == args.type]
        log_info(f"Filtering by type: {Colors.WHITE}{args.type}{Colors.NC}\n")

    if not components:
        log_warning("No components found")
        return

    # Print table header
    print(f"{Colors.WHITE}{'NAME':<30} {'TYPE':<15} {'VERSION':<10} {'STATUS':<12} {'MATURITY':<10}{Colors.NC}")
    print(f"{Colors.WHITE}{'-'*30} {'-'*15} {'-'*10} {'-'*12} {'-'*10}{Colors.NC}")

    # Maturity icons
    maturity_icons = {
        'polished': '✨',
        'beta': '🚀',
        'alpha': '🔨',
        'experimental': '🧪',
        'deprecated': '❌',
        'archived': '🗄️'
    }

    # Status colors
    status_colors = {
        'active': Colors.GREEN,
        'inactive': Colors.YELLOW,
        'failed': Colors.RED
    }

    # Print components
    for component in components:
        name = component.get('name', 'Unknown')[:28]
        comp_type = component.get('type', 'unknown')
        version = component.get('version', '?')[:10]
        status = component.get('status', 'unknown')
        maturity = component.get('maturity', '')

        status_color = status_colors.get(status, Colors.NC)
        maturity_icon = maturity_icons.get(maturity, '')

        print(f"{name:<30} {comp_type:<15} {version:<10} {status_color}{status:<12}{Colors.NC} {maturity_icon} {maturity}")

def cmd_stats(args):
    """Show statistics"""
    log_section("Component Statistics")

    registry = load_registry()
    stats = registry.get('statistics', {})
    platform_info = registry.get('platform', {})

    # Total
    total = stats.get('totalComponents', 0)
    print(f"{Colors.WHITE}Total Components:{Colors.NC} {total}\n")

    # By Type
    print(f"{Colors.CYAN}By Type:{Colors.NC}")
    for comp_type, count in stats.get('byType', {}).items():
        print(f"  {comp_type}: {count}")
    print()

    # By Status
    print(f"{Colors.CYAN}By Status:{Colors.NC}")
    for status, count in stats.get('byStatus', {}).items():
        print(f"  {status}: {count}")
    print()

    # By Maturity
    print(f"{Colors.CYAN}By Maturity:{Colors.NC}")
    for maturity, count in stats.get('byMaturity', {}).items():
        print(f"  {maturity}: {count}")
    print()

    # Platform
    print(f"{Colors.CYAN}Platform:{Colors.NC}")
    print(f"  OS: {platform_info.get('os', 'Unknown')}")
    print(f"  Architecture: {platform_info.get('architecture', 'Unknown')}")
    print(f"  Environment: {platform_info.get('environment', 'Unknown')}")

def cmd_search(args):
    """Search components"""
    query = args.query.lower()
    log_section(f"Search Results: '{query}'")

    registry = load_registry()
    components = registry.get('components', [])

    results = []
    for component in components:
        name = component.get('name', '').lower()
        description = component.get('description', '').lower()
        tags = [t.lower() for t in component.get('tags', [])]

        if query in name or query in description or any(query in tag for tag in tags):
            results.append(component)

    if not results:
        log_warning(f"No results found for '{query}'")
        return

    log_info(f"Found {len(results)} result(s)\n")

    for component in results:
        name = component.get('name', 'Unknown')
        comp_type = component.get('type', 'unknown')
        description = component.get('description', '')
        print(f"  {Colors.GREEN}•{Colors.NC} {name} ({comp_type}) - {description}")

def cmd_validate(args):
    """Validate registry"""
    log_section("Validating Registry")

    try:
        registry = load_registry()
        log_success("Registry JSON is valid")

        # Basic structure validation
        required_fields = ['version', 'components']
        for field in required_fields:
            if field not in registry:
                log_error(f"Missing required field: {field}")
                sys.exit(1)

        # Validate components
        components = registry.get('components', [])
        log_info(f"Validating {len(components)} components...")

        for idx, component in enumerate(components):
            comp_required = ['id', 'name', 'type', 'version', 'status', 'location']
            for field in comp_required:
                if field not in component:
                    log_error(f"Component {idx}: missing required field '{field}'")

        log_success("All components validated")

        # Rebuild indices and statistics
        rebuild_indices(registry)
        rebuild_statistics(registry)
        registry['lastUpdated'] = datetime.utcnow().isoformat() + 'Z'

        save_registry(registry)

    except Exception as e:
        log_error(f"Validation failed: {e}")
        sys.exit(1)

def cmd_export(args):
    """Export registry"""
    registry = load_registry()
    components = registry.get('components', [])

    format = args.format.lower()
    output_file = args.output or f"component-registry.{format}"

    if format == 'json':
        with open(output_file, 'w') as f:
            json.dump(components, f, indent=2)
        log_success(f"Exported to {output_file}")

    elif format == 'csv':
        import csv
        with open(output_file, 'w', newline='') as f:
            if not components:
                log_warning("No components to export")
                return

            writer = csv.DictWriter(f, fieldnames=components[0].keys())
            writer.writeheader()
            writer.writerows(components)
        log_success(f"Exported to {output_file}")

    elif format == 'md':
        with open(output_file, 'w') as f:
            f.write("# Component Registry\n\n")
            f.write(f"**Total Components:** {len(components)}\n\n")
            f.write("| Name | Type | Version | Status | Maturity |\n")
            f.write("|------|------|---------|--------|----------|\n")
            for c in components:
                f.write(f"| {c.get('name', '?')} | {c.get('type', '?')} | {c.get('version', '?')} | {c.get('status', '?')} | {c.get('maturity', '?')} |\n")
        log_success(f"Exported to {output_file}")

    else:
        log_error(f"Unsupported format: {format}")
        sys.exit(1)

# ─────────────────────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Morphism Component Registry Manager",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    subparsers = parser.add_subparsers(dest='command', help='Command to execute')

    # List command
    list_parser = subparsers.add_parser('list', help='List components')
    list_parser.add_argument('type', nargs='?', help='Filter by component type')

    # Stats command
    subparsers.add_parser('stats', help='Show statistics')

    # Search command
    search_parser = subparsers.add_parser('search', help='Search components')
    search_parser.add_argument('query', help='Search query')

    # Validate command
    subparsers.add_parser('validate', help='Validate registry')

    # Export command
    export_parser = subparsers.add_parser('export', help='Export registry')
    export_parser.add_argument('format', choices=['json', 'csv', 'md'], help='Export format')
    export_parser.add_argument('-o', '--output', help='Output file')

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    # Execute command
    commands = {
        'list': cmd_list,
        'stats': cmd_stats,
        'search': cmd_search,
        'validate': cmd_validate,
        'export': cmd_export
    }

    cmd_func = commands.get(args.command)
    if cmd_func:
        cmd_func(args)
    else:
        log_error(f"Unknown command: {args.command}")
        parser.print_help()
        sys.exit(1)

if __name__ == '__main__':
    main()
