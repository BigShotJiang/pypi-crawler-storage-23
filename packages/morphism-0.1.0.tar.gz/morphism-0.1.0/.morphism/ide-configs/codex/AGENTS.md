# Codex CLI Agent Settings

This workspace uses a centralized reviewer registry and tool-agnostic agent specs.

- Registry: `../REVIEWER_REGISTRY.yml`
- Reviewer specs: `../.claude/agents/`
- Runner guide: `../REVIEWER_RUNNERS.md`
- Codex config: `./config.toml`
- Codex rules: `./rules/default.rules`
- Codex skills: `./skills/`

Use the reviewer spec Markdown files as the source of truth for any review task.
