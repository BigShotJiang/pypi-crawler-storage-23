---
name: "truth-documentation-reviewer"
description: "Run the Truth Documentation Reviewer 5-phase process by loading the local spec from .claude/agents/truth-documentation-reviewer.md."
---

# Truth Documentation Reviewer

## Instructions

1. Read `.claude/agents/truth-documentation-reviewer.md` completely.
2. Follow its 5-phase review process focusing on evidence, SSOT, and doc↔code sync.
3. Validate examples when the spec requires it; report exactly what you ran and what failed/passed.
4. Output exactly in the spec’s report format and approval gate.

