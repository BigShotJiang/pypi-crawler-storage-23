---
name: "ship-readiness-reviewer"
description: "Run the Ship Readiness Reviewer 5-phase process by loading the local spec from .claude/agents/ship-readiness-reviewer.md."
---

# Ship Readiness Reviewer

## Instructions

1. Read `.claude/agents/ship-readiness-reviewer.md` completely.
2. Follow its 5-phase review process focusing on pre-deploy gates (tests, CI health, release readiness).
3. Ground findings in evidence (paths + line numbers), and run the verification commands the spec requires when feasible.
4. Output exactly in the spec’s report format and approval gate.

