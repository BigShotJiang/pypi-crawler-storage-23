---
name: "mcp-integration-reviewer"
description: "Run the MCP Integration Reviewer 5-phase process by loading the local spec from .claude/agents/mcp-integration-reviewer.md."
---

# MCP Integration Reviewer

## Instructions

1. Read `.claude/agents/mcp-integration-reviewer.md` completely.
2. Follow its 5-phase review process focusing on MCP server configuration, tool composition, and graceful degradation.
3. Ground findings in evidence (paths + line numbers). When an MCP server/config is referenced, locate the actual config file(s) in-repo.
4. Output exactly in the spec’s report format and approval gate.

