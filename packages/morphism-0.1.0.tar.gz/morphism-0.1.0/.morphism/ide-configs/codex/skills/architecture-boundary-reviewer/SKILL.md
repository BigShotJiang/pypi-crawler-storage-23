---
name: "architecture-boundary-reviewer"
description: "Run the Architecture Boundary Reviewer 5-phase process by loading the local spec from .claude/agents/architecture-boundary-reviewer.md."
---

# Architecture Boundary Reviewer

## Instructions

1. Read `.claude/agents/architecture-boundary-reviewer.md` completely.
2. Follow its 5-phase review process on the user’s requested scope (uncommitted changes, base branch, specific commit, or paths).
3. Ground findings in evidence: concrete file paths + line numbers.
4. If the spec references architecture docs/paths that don’t exist in the current repo, call that out explicitly and continue with best-available evidence.
5. Output exactly in the spec’s report format and approval gate.

