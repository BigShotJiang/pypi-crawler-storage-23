---
name: "reviewer-runner"
description: "Use when you want to run one of the centralized reviewer subagents from REVIEWER_REGISTRY.yml / .claude/agents (5-phase review process)."
---

# Reviewer Runner

## Goal

Run a structured review using a reviewer spec in `.claude/agents/*.md`, chosen via `REVIEWER_REGISTRY.yml`.

## Workflow

1. **Discover available reviewers**
   - Prefer `REVIEWER_REGISTRY.yml` if present.
   - Otherwise, list `.claude/agents/*.md`.

2. **Select the reviewer**
   - If the user already named a reviewer id, use it.
   - Otherwise, ask the user which reviewer id to run.

3. **Load the reviewer spec**
   - Read `.claude/agents/<reviewer-id>.md` in full before starting.

4. **Execute the 5-phase process**
   - Follow the spec phases/checklists exactly.
   - Use repository docs/code as evidence (file paths + line numbers).
   - If the spec references paths that don't exist in this repo, note that explicitly and continue with best-available evidence.

5. **Report in the spec’s format**
   - Use the spec’s output template and approval gate (APPROVED / CONDITIONAL / BLOCKED).

## Failure modes

- If `.claude/agents` or the spec file is missing, state which paths you tried and ask where the reviewer specs live in this repo.

