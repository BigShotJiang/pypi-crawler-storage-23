---
name: "entropy-guard-reviewer"
description: "Run the Entropy Guard Reviewer 5-phase process by loading the local spec from .claude/agents/entropy-guard-reviewer.md."
---

# Entropy Guard Reviewer

## Instructions

1. Read `.claude/agents/entropy-guard-reviewer.md` completely.
2. Follow its 5-phase process, prioritizing session health, context limits, and hallucination prevention.
3. Use evidence for claims (paths + line numbers); avoid unsupported assertions.
4. Output exactly in the spec’s report format and approval gate.

