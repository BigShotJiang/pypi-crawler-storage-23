#!/bin/bash
echo "Test script"
