# Claude Code Project Configuration

**Verification-First Philosophy**: Give Claude Code a way to verify everything works before proceeding.

---

## Quick Reference

| Category | Project | Verify Command | What It Checks |
|----------|---------|-----------------|-----------------|
| **Products** | morphism | `make verify-all` | All systems operational |
| | morphism | `pnpm mcp:validate` | MCP server connections |
| | morphism | `pnpm test` | Unit test suite |
| | the-circus | `pytest tests/` | Agent orchestration |
| | aiclarity | `npm run verify` | AI clarity validation |
| **Research** | qaplibria | `pytest` | Quantum library tests |
| | helios | `python -m pytest` | Hypothesis system |
| | tal-ai | `pytest tests/` | Lab analysis modules |
| | llmworks | `python -m pytest` | LLM experiments |
| **Tools** | codemap | `python -m codemap --help` | CLI operational |
| | brand-kit | `brand-kit --help` | Print branding functional |
| | workspace-cli | `./workspace.bat` | Workspace launcher |

---

## Products Category

### morphism (Main Framework)

**Structure Verification**
```bash
cd Products/morphism
make verify-structure
# ✓ Confirms: MCP servers (57), Workflows (26), Docs present
```

**Tenets Verification** (Category theory & physics alignment)
```bash
cd Products/morphism
make verify-tenets
# ✓ Confirms: Functorial design, Yoneda embedding, Morphism laws
# → See: docs/category_theory.md
```

**Drift Detection** (From upstream commitments)
```bash
cd Products/morphism
make verify-drift
# ✓ Confirms: No breaking changes to API contracts
# ✓ Confirms: Type signatures stable
# ✓ Confirms: Performance within bounds
```

**MCP Server Validation**
```bash
cd Products/morphism
pnpm mcp:validate
# ✓ Confirms: All 57 MCP servers respond
# ✓ Confirms: Tool schemas correct
# ✓ Confirms: Resource trees accessible
```

**Workflow Integrity**
```bash
cd Products/morphism
pnpm workflow:validate
# ✓ Confirms: All 26 GitHub Actions workflows parse
# ✓ Confirms: Secrets configured
# ✓ Confirms: Triggers defined
```

**Unit Tests**
```bash
cd Products/morphism
pnpm test
# ✓ Confirms: Core logic correct
# ✓ Confirms: No regressions
```

**End-to-End Tests**
```bash
cd Products/morphism
pnpm test:e2e
# ✓ Confirms: Full pipeline works
# ✓ Confirms: Integration points solid
```

### the-circus (Agent Orchestration)

```bash
cd Products/the-circus
pytest tests/
# ✓ Confirms: Agent spawning works
# ✓ Confirms: Message routing correct
# ✓ Confirms: State management stable
```

### aiclarity (AI Clarity Platform)

```bash
cd Products/aiclarity
npm run verify
# ✓ Confirms: Dashboard responsive
# ✓ Confirms: API endpoints active
# ✓ Confirms: Data pipelines flowing
```

---

## Research Category

### qaplibria (Quantum/Physics Library)

```bash
cd Research/qaplibria
pytest
# ✓ Confirms: Quantum gates correct
# ✓ Confirms: Material properties accurate
# ✓ Confirms: DFT calculations valid
```

### helios (Hypothesis Generation System)

```bash
cd Research/helios
python -m pytest
# ✓ Confirms: Hypothesis generation working
# ✓ Confirms: Experimental design valid
# ✓ Confirms: Results reproducible
```

### tal-ai (Lab Analysis AI Modules)

```bash
cd Research/tal-ai
pytest tests/
# ✓ Confirms: ML models loaded
# ✓ Confirms: Lab data parsing correct
# ✓ Confirms: Analysis pipelines functional
```

### llmworks (LLM Experimentation)

```bash
cd Research/llmworks
python -m pytest
# ✓ Confirms: Model loading works
# ✓ Confirms: Prompt templates valid
# ✓ Confirms: Output parsing correct
```

---

## Tools Category

### codemap (Code Documentation CLI)

```bash
cd Tools/codemap
python -m codemap --help
# ✓ Confirms: CLI available
# ✓ Confirms: All commands listed

# Generate documentation
python -m codemap Products/morphism
# ✓ Confirms: Maps generated
# ✓ Confirms: Symbol tracking works
```

### brand-kit (Print Branding CLI)

```bash
cd Tools/brand-kit
brand-kit --help
# ✓ Confirms: CLI available
# ✓ Confirms: All export formats listed

# Test branding generation
brand-kit --template logo --output test.pdf
# ✓ Confirms: PDF generation works
```

### workspace-cli (Workspace Launcher)

```bash
cd Tools/workspace-cli
./workspace.bat              # Windows
./workspace.sh               # Linux/Mac
# ✓ Confirms: All repos cloned
# ✓ Confirms: Dependencies installed
# ✓ Confirms: Environment configured
```

---

## Workspace-Level Verification

```bash
# Root level verification
make verify-workspace
# ✓ Confirms: Directory structure valid
# ✓ Confirms: All symlinks correct
# ✓ Confirms: .claude/ config present
# ✓ Confirms: .github/ workflows valid
# ✓ Confirms: AGENTS.md accessible in each category

# Check git status across all repos
git status --porcelain
# ✓ Confirms: No uncommitted changes
# ✓ Confirms: No untracked dangerous files
```

---

## Screenshot Verification

When documenting features or bugs:

```bash
# For Products (use morphism dashboard)
cd Products/morphism/.api/public
# Open dashboard and screenshot the feature
# Save to: docs/screenshots/[FEATURE]-[DATE].png

# For Research (use helios UI if available)
cd Research/helios
# Screenshot experiment interface
# Save to: docs/screenshots/[EXPERIMENT]-[DATE].png

# For Tools (use CLI with --help screenshots)
cd Tools/codemap
python -m codemap --help > docs/screenshots/codemap-help-[DATE].txt
```

---

## Git Workflow Integration

Before committing:

```bash
# 1. Verify the specific category
cd Products/morphism  # or Research/*, Tools/*
make verify-all       # Run category-specific tests
git status            # Check what's staged

# 2. Create meaningful commit
git add <files>
git commit -m "feat: add feature X to morphism

- Detail 1: explain what changed
- Detail 2: why it changed
- Verification: make verify-all ✓"

# 3. Verify entire workspace after commit
cd /path/to/workspace
make verify-workspace
```

---

## Permission Allowlists

**Claude Code is allowed to:**
- ✅ Read all AGENTS.md files (governance reference)
- ✅ Run verification commands (make verify-*)
- ✅ Create .claude/ config files
- ✅ Modify non-core files (docs, examples, tests)
- ✅ Suggest changes to Products/morphism MCP configs

**Claude Code is NOT allowed to:**
- ❌ Modify Products/morphism/core without category AGENTS.md review
- ❌ Add new MCP servers without Meshal approval
- ❌ Modify .github/workflows/* without testing locally first
- ❌ Commit changes with AI attribution ("Claude wrote this")
- ❌ Push directly to main/master branches

**Before committing anything:**
- Check: `cat Products/AGENTS.md` (if modifying Products)
- Check: `cat Research/AGENTS.md` (if modifying Research)
- Check: `cat Tools/AGENTS.md` (if modifying Tools)

---

## Session Hygiene

**Start of session:**
```bash
cd /path/to/workspace
git status              # Confirm no uncommitted changes
make verify-workspace   # Quick health check
cat AGENTS.md          # Refresh on governance rules
```

**During session:**
```bash
# Before switching projects
git status             # Any uncommitted work?
# If yes: git stash or commit before moving

# When making changes
make verify-<category> # Verify after modifications
git diff              # Review what you changed
```

**End of session:**
```bash
# Before closing
git status                 # Any uncommitted changes?
make verify-workspace      # Final workspace check
git log --oneline -5       # Review commits made this session
```

---

## Troubleshooting

**"make verify-all fails"**
1. Run: `make clean` (clean build artifacts)
2. Run: `pnpm install` or `pip install -r requirements.txt`
3. Check: `cat AGENTS.md` for category-specific requirements
4. Run: `make verify-all` again

**"MCP server connection fails"**
1. Check: `pnpm mcp:validate` output
2. Verify: All .env variables present
3. Verify: Firewall allows local connections
4. Restart: `pnpm dev` or equivalent

**"Git workflow breaks"**
1. Check: `git status --porcelain` for untracked files
2. Check: `.gitignore` doesn't ignore needed files
3. Check: No accidental edits to core files
4. Use: `git stash` to save work, then investigate

**"Tests fail unexpectedly"**
1. Run: `make clean && make verify-all`
2. Check: Recent commits haven't broken dependencies
3. Check: Required services running (DB, Redis, etc.)
4. Review: Category-specific AGENTS.md for test requirements

---

## See Also

- **Root governance:** `../AGENTS.md`
- **Products rules:** `../Products/AGENTS.md`
- **Research rules:** `../Research/AGENTS.md`
- **Tools rules:** `../Tools/AGENTS.md`
- **Commands index:** `../COMMANDS-REFERENCE.md`
- **Quick cheatsheet:** `../COMMANDS-CHEATSHEET.md`
- **Workflow guide:** `../WORKFLOW-GUIDE.md`
- **Category theory ref:** `../Products/morphism/docs/category_theory.md`

---

**Last Updated:** 2026-02-05 | Dario's Principle #1: "Give Claude a way to verify everything."
