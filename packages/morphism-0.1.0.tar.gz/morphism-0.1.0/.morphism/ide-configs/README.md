# AI IDE Configurations

**Version:** 1.0.0
**Purpose:** Unified AI IDE configurations for consistent governance across development tools

---

## 📋 Overview

This directory contains configurations for multiple AI IDEs, all following the same governance principles and reviewer system.

### Supported IDEs

- **Claude Code** - Anthropic's official CLI
- **Codex** - AI coding assistant
- **Cursor** - AI-first code editor
- **AmazonQ** - AWS AI assistant
- **Windsurf** - (Reserved for future)

---

## 🏗️ Structure

```
.morphism/ide-configs/
├── claude/              # Claude Code configuration
│   ├── CLAUDE.md        # Main config
│   ├── REVIEWERS.md     # Reviewer registry
│   └── agents/          # Reviewer agents
├── codex/               # Codex configuration
├── cursor/              # Cursor configuration
│   ├── AGENTS.md        # Cursor-specific config
│   ├── RULES_AND_SKILLS.md   # Workflow map (which rule/skill per task)
│   ├── rules/           # Optional .mdc project rules
│   └── skills/          # Optional project skills (e.g. morphism-pr-review)
├── amazonq/             # AmazonQ configuration
└── windsurf/            # Windsurf (future)
```

---

## 🎯 Design Principles

### 1. Consistency
- Same governance rules across all IDEs
- Shared reviewer system
- Unified validation approach

### 2. Tool-Agnostic Specs
- Reviewer agents are IDE-independent
- Core governance in MORPHISM.md
- IDE-specific adapters

### 3. Verification-First
- All IDEs follow verification-first philosophy
- Common validation commands
- Shared drift detection

---

## 🚀 Usage

### Activating for Claude Code

Claude Code automatically uses `.claude/` in the root. We use a symlink:

```bash
# Symlink (already done during setup)
ln -s .morphism/ide-configs/claude .claude
```

### Activating for Codex

```bash
# Codex looks for .codex/ config
ln -s .morphism/ide-configs/codex .codex
```

### Activating for Cursor

```bash
# Cursor uses .cursor/ or .cursorrules
ln -s .morphism/ide-configs/cursor .cursor
```

### Activating for AmazonQ

```bash
# AmazonQ looks for .amazonq/
ln -s .morphism/ide-configs/amazonq .amazonq
```

---

## 🔧 Configuration Files

### Claude Code (.morphism/ide-configs/claude/)

**CLAUDE.md** - Main configuration
- Project overview
- Core commands
- Architecture boundaries
- Verification commands

**REVIEWERS.md** - Reviewer registry
- List of all reviewers
- When to use each reviewer
- Review triggers

**agents/** - Reviewer agents
- architecture-boundary-reviewer.md
- entropy-guard-reviewer.md
- mcp-integration-reviewer.md
- ship-readiness-reviewer.md
- truth-documentation-reviewer.md

### Codex (.morphism/ide-configs/codex/)

**AGENTS.md** - Codex-specific config
**skills/** - Codex skills

### Cursor (.morphism/ide-configs/cursor/)

**AGENTS.md** - Cursor-specific config; points to workflow map and reviewer paths.

**RULES_AND_SKILLS.md** - Workflow map: which Cursor rule/skill to use for each morphism workflow (onboard, debug, commit, PR review, docs, refactor, security, tests). Single source for "when to use which rule/skill" in this repo.

**rules/** - Optional project rules (`.mdc`): morphism-governance (alwaysApply), morphism-commits (conventional commits per GUIDELINES).

**skills/** - Optional project skills: e.g. morphism-pr-review (run review-pr-checklist and review-quality-security before merge).

### AmazonQ (.morphism/ide-configs/amazonq/)

**config.json** - AmazonQ configuration
**prompts/** - Prompt library
**rules/** - Rule definitions

---

## 📚 Reviewer System

### Available Reviewers

1. **Architecture Boundary Reviewer**
   - Purpose: Enforce layer boundaries (Kernel/Hub/Lab)
   - When: Before structural changes
   - Tool: All IDEs

2. **Entropy Guard Reviewer**
   - Purpose: Prevent complexity growth
   - When: During refactoring
   - Tool: All IDEs

3. **MCP Integration Reviewer**
   - Purpose: Validate MCP server configurations
   - When: Before MCP changes
   - Tool: All IDEs

4. **Ship Readiness Reviewer**
   - Purpose: Production readiness checks
   - When: Before deployment
   - Tool: All IDEs

5. **Truth Documentation Reviewer**
   - Purpose: Ensure docs match implementation
   - When: After significant changes
   - Tool: All IDEs

---

## 🔄 Customization

### Adding IDE-Specific Config

1. Create directory in `.morphism/ide-configs/{ide-name}/`
2. Add IDE-specific configuration files
3. Create symlink in root: `ln -s .morphism/ide-configs/{ide-name} .{ide-name}`
4. Document in this README

### Adding New Reviewer

1. Create reviewer spec in `.morphism/reviewers/{reviewer-name}/`
2. Add to each IDE's configuration
3. Update REVIEWERS.md registry
4. Document usage patterns

---

## 📊 Configuration Status

| IDE | Status | Config Files | Reviewers | Symlink |
|-----|--------|--------------|-----------|---------|
| Claude | ✅ Active | 3 files | 5 agents | ✅ |
| Codex | ✅ Active | 2 files | 5 skills | ⏳ |
| Cursor | ✅ Active | 1 file | Shared | ⏳ |
| AmazonQ | ✅ Active | 3 dirs | Shared | ⏳ |
| Windsurf | 📋 Planned | - | - | - |

---

## 🎯 Next Steps

1. ✅ Copy configs from FILES directory (DONE)
2. ⏳ Create symlinks for all IDEs
3. ⏳ Adapt paths for workspace structure
4. ⏳ Test each IDE configuration
5. ⏳ Document IDE-specific features

---

**See also:** [docs/LLM_INTERACTION_STANDARDS.md](../../docs/LLM_INTERACTION_STANDARDS.md) — how we standardize Claude/LLM use (prompts, tool use, doc references).

**Maintained by:** Morphism Team
**Last Updated:** 2026-02-11
