# 50 Workspace Analysis Prompts

## Architecture & Design (1-10)

### 1. System Architecture Audit
Analyze the complete architecture across FILES to read and GitHub workspaces. Map all projects, their dependencies, and integration points. Identify architectural patterns, anti-patterns, and opportunities for consolidation.

### 2. MORPHISM Framework Deep Dive
Review MORPHISM_COMPLETE.md and all related docs. Explain the mathematical foundations (Banach Fixed-Point, Sheaf Cohomology), practical applications, and how it differs from existing agent governance solutions.

### 3. CCIS Integration Analysis
Evaluate the newly built CCIS system. How does it integrate with existing credential management, MCP servers, and the broader MORPHISM ecosystem? Identify gaps and enhancement opportunities.

### 4. Multi-Project Dependency Graph
Create a comprehensive dependency graph showing relationships between: Aegis, Catalyst, Nexus, Sentinel, CCIS, career_automation, and summaries. Identify circular dependencies and optimization opportunities.

### 5. Configuration Consolidation Strategy
Analyze all config files across both workspaces. Propose a unified configuration strategy that leverages CCIS while maintaining backward compatibility.

### 6. Secret Management Unification
Review credential systems in both workspaces. Design a unified secret management strategy using the existing AES-256-GCM vault with CCIS integration.

### 7. MCP Server Ecosystem Mapping
Document all MCP servers across both workspaces. Analyze their purposes, credentials, and usage patterns. Propose optimization and consolidation strategies.

### 8. Prompt System Scalability
Evaluate the 65-prompt system. Analyze usage patterns, identify redundancies, and propose a categorization system for scaling to 200+ prompts.

### 9. API Gateway Architecture
Design a unified API gateway that consolidates CCIS API, credential API, and any other APIs across both workspaces. Include authentication, rate limiting, and monitoring.

### 10. Database Strategy Review
Analyze database configurations across projects. Propose a unified database strategy (Postgres, Redis, MongoDB) with proper connection pooling and failover.

## Code Quality & Optimization (11-20)

### 11. Code Duplication Analysis
Scan both workspaces for duplicate code patterns. Identify opportunities for shared libraries, utilities, and common modules.

### 12. Performance Bottleneck Identification
Analyze all JavaScript/Python code for performance issues. Focus on: file I/O, API calls, database queries, and synchronous operations.

### 13. Security Vulnerability Scan
Comprehensive security audit of both workspaces. Check for: exposed secrets, insecure dependencies, SQL injection risks, XSS vulnerabilities, and improper authentication.

### 14. Test Coverage Analysis
Evaluate test coverage across all projects. Identify critical paths without tests and generate test strategies for each project.

### 15. Error Handling Audit
Review error handling patterns across both workspaces. Identify missing try-catch blocks, unhandled promises, and inconsistent error reporting.

### 16. Logging Strategy Unification
Analyze logging implementations. Propose a unified logging strategy with proper levels (debug, info, warn, error), structured logging, and centralized log aggregation.

### 17. Code Style Consistency
Review code style across projects. Identify inconsistencies and propose unified ESLint/Prettier/Black configurations for JavaScript and Python.

### 18. Dependency Audit
Analyze all package.json and requirements.txt files. Identify: outdated dependencies, security vulnerabilities, unused packages, and version conflicts.

### 19. Documentation Coverage
Evaluate documentation across both workspaces. Identify undocumented APIs, missing README files, and outdated documentation.

### 20. Refactoring Opportunities
Identify code that needs refactoring. Focus on: long functions, deep nesting, god objects, and violation of SOLID principles.

## Integration & Automation (21-30)

### 21. CI/CD Pipeline Design
Design comprehensive CI/CD pipelines for all projects. Include: testing, linting, security scanning, deployment, and rollback strategies.

### 22. GitHub Actions Workflow Optimization
Review existing GitHub Actions workflows. Optimize for speed, cost, and reliability. Add missing workflows for automated testing and deployment.

### 23. Kiro CLI Enhancement Strategy
Analyze current Kiro integration. Propose enhancements: new shortcuts, automation scripts, and integration with CCIS.

### 24. Amazon Q Prompt Orchestration
Design an orchestration system for the 65 prompts. Include: prompt chaining, context management, and result aggregation.

### 25. MCP Server Auto-Discovery
Design a system to auto-discover and register MCP servers. Include health checks, credential validation, and automatic failover.

### 26. Cross-Workspace Sync Automation
Design automation for syncing configs, prompts, and secrets between FILES to read and GitHub workspaces.

### 27. Deployment Automation Strategy
Create deployment automation for all projects. Include: environment promotion (dev to staging to prod), rollback procedures, and health checks.

### 28. Monitoring & Alerting System
Design comprehensive monitoring for all services. Include: uptime monitoring, performance metrics, error tracking, and alerting rules.

### 29. Backup & Recovery Strategy
Design backup strategies for: databases, credential vaults, configurations, and code repositories. Include recovery procedures and testing.

### 30. Development Environment Setup
Create automated setup scripts for new developers. Include: dependency installation, configuration, database setup, and verification.

## Business & Product (31-40)

### 31. MORPHISM Go-to-Market Strategy
Analyze competitive landscape and design GTM strategy. Include: target customers, pricing model, marketing channels, and sales approach.

### 32. Product Roadmap Prioritization
Review PRODUCT_ROADMAP.md and prioritize features. Use: customer impact, technical complexity, and business value as criteria.

### 33. Design Partner Engagement Plan
Create strategy for engaging design partners. Include: outreach templates, demo scripts, feedback collection, and iteration process.

### 34. YC Application Optimization
Review YC-related docs and optimize application materials. Focus on: problem statement, solution uniqueness, traction metrics, and team story.

### 35. Competitive Analysis Deep Dive
Analyze competitors in agent governance space. Compare: features, pricing, technology, market positioning, and differentiation opportunities.

### 36. Customer Discovery Framework
Design customer discovery process. Include: interview scripts, survey templates, data analysis methods, and insight synthesis.

### 37. Pricing Strategy Analysis
Analyze potential pricing models: freemium, usage-based, enterprise, and hybrid. Recommend optimal strategy with justification.

### 38. Partnership Opportunity Mapping
Identify potential partners: cloud providers, AI platforms, enterprise software vendors. Design partnership proposals and value propositions.

### 39. Content Marketing Strategy
Design content strategy for MORPHISM. Include: blog topics, technical papers, case studies, tutorials, and distribution channels.

### 40. Community Building Plan
Design strategy for building developer community. Include: Discord/Slack setup, documentation, tutorials, and engagement tactics.

## Research & Innovation (41-50)

### 41. Mathematical Foundation Validation
Review mathematical foundations (Banach Fixed-Point, Sheaf Cohomology). Validate correctness, identify edge cases, and propose enhancements.

### 42. Agent Convergence Algorithm Optimization
Analyze convergence algorithms. Propose optimizations for: faster convergence, lower computational cost, and better stability guarantees.

### 43. Event Discovery Research Integration
Review event-discovery project. Analyze integration opportunities with MORPHISM for agent behavior analysis and anomaly detection.

### 44. Video Functor Application Exploration
Analyze video-functor project. Explore applications in: agent visualization, behavior analysis, and debugging tools.

### 45. Energy Sheaf Framework Analysis
Review energy-sheaf research. Identify applications in: agent energy optimization, resource allocation, and cost minimization.

### 46. Quantum Computing Integration
Explore quantum computing applications for MORPHISM. Focus on: optimization problems, cryptography, and simulation acceleration.

### 47. GPU Optimization Opportunities
Identify GPU acceleration opportunities across projects. Focus on: matrix operations, parallel processing, and ML inference.

### 48. Distributed System Design
Design distributed architecture for MORPHISM. Include: consensus algorithms, fault tolerance, and horizontal scaling strategies.

### 49. Real-time Monitoring Dashboard
Design real-time dashboard for agent swarms. Include: convergence metrics, cost tracking, performance visualization, and alerting.

### 50. Future Research Directions
Identify promising research directions. Focus on: novel mathematical frameworks, emerging AI paradigms, and unsolved problems in agent governance.
