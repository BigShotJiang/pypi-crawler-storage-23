# Core Context Rules (Auto-Loaded)

## Project Identity
- **Framework**: MORPHISM - Compositional governed transformations
- **Mission**: Build production-ready AI orchestration platform
- **Status**: Pre-seed, design partner phase

## Key References
- Main docs: `MORPHISM_COMPLETE.md`, `README.md`
- Architecture: `docs/technical/ARCHITECTURE.md`
- Roadmap: `docs/plans/PRODUCT_ROADMAP.md`

## Governance Rules
1. Read `AGENTS.md` before modifications
2. No secrets in commits
3. Validate before destructive ops
4. Ask before MCP/GitHub Actions changes

## Code Standards
- Minimal, production-ready code only
- No verbose implementations
- Security-first approach
- Test coverage required
