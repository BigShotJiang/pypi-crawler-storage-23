# Changelog - GitHub PR Validation Hook

All notable changes to the GitHub PR Validation hook will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Integration with GitHub branch protection rules
- Automated code owner notification
- Review distribution across team members
- Commit message validation (conventional commits)
- Automated dependency upgrade PRs

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial GitHub PR validation hook
- Four automatic validation checks for pull requests:
  1. **PR Description** - Validates presence and completeness of PR description
  2. **Labels** - Ensures appropriate labels are applied
  3. **Merge Conflicts** - Detects and reports merge conflicts
  4. **CI Status** - Checks that all CI checks are passing
- Enforcing comments on PR with validation results
- Pull request blocking on validation failures
- Integration with GitHub API for status updates

### Validation Checks
- **PR Description** - Requires non-empty description with minimum 20 characters
  - Checks for: problem statement, solution description, testing notes
  - Suggests template if missing
  - Blocks merge if empty (bypassed with approval)

- **Labels** - Requires at least one label from predefined categories:
  - Type: bug, feature, enhancement, documentation, refactor
  - Priority: critical, high, medium, low
  - Area: kernel, hub, lab, docs, tests

- **Merge Conflicts** - Detects merge conflicts in PR
  - Blocks merge if conflicts present
  - Provides conflict resolution suggestions
  - Updates automatically when conflicts resolved

- **CI Status** - Ensures all required checks pass
  - Checks: lint, test, build, type-check (language-dependent)
  - Blocks merge if any check fails
  - Updates status on re-run

### GitHub Integration
- Posts validation results as PR comments
- Updates PR status checks
- Adds/removes blocking labels automatically
- Integrates with branch protection rules
- Supports GitHub Actions workflows

### Features
- Automatic comment posting with validation results
- Detailed error messages with remediation steps
- Non-intrusive for passing PRs
- Supports multiple commit updates (re-validation on push)
- Customizable validation rules per repo

### Performance
- Validation check: 5-15 seconds per PR
- GitHub API calls: 3-5 requests
- Status update: <2 seconds
- Non-blocking on PR creation

### Configuration
- Rules defined in `.github/pr-validation.yml`
- Customizable per repository
- Template suggestions configurable
- Label requirements definable

### Documentation
- Hook installation: `.morphism/hooks/pr-validation.sh`
- GitHub Actions workflow: `.github/workflows/pr-validation.yml`
- Configuration guide in `.morphism/hooks/README.md`
- PR template: `.github/pull_request_template.md`
- Example passing/failing PRs

## [0.9.0] - 2026-01-30

### Added
- Hook design and specification
- Initial validation rules
- GitHub Actions workflow framework
