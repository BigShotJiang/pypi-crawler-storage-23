# Changelog - Orchestration JSON Schema

All notable changes to the Orchestration JSON Schema will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Nested orchestration support (orchestrations calling orchestrations)
- Dynamic agent/skill assignment based on input
- Orchestration templates for common patterns
- Performance optimization directives
- Cost estimation and tracking

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial JSON Schema for orchestration pattern definitions
- Orchestration type validation (sequential, parallel, hybrid, streaming, hierarchical)
- Agent role definition and validation (leader, worker, reviewer, coordinator, executor, validator)
- Coordination protocol specification
- Failure handling and recovery strategies
- Communication patterns between agents
- Resource allocation specification
- Monitoring and observability requirements

### Orchestration Types
- **Sequential** - Agents execute one after another with output passing
- **Parallel** - Agents execute simultaneously with aggregation
- **Hybrid** - Mix of sequential and parallel execution
- **Streaming** - Continuous data flow between agents
- **Hierarchical** - Master-worker pattern with supervision

### Agent Roles
- **Leader** - Orchestrates execution and makes decisions
- **Worker** - Executes assigned tasks
- **Reviewer** - Validates outputs from workers
- **Coordinator** - Manages communication between agents
- **Executor** - Performs actual work tasks
- **Validator** - Ensures quality and constraints

### Schema Sections
- **Metadata** - name, version, description, type, owner
- **Agents** - Array of agent definitions with roles
- **Coordination** - Communication protocol, message format
- **Failure Strategy** - Error handling (fail-fast, continue-on-error, retry)
- **Monitoring** - Observability requirements (metrics, logs, alerts)
- **Resources** - CPU, memory, timeout requirements
- **Communication** - Message queue, protocol (HTTP, gRPC, message bus)
- **Execution Plan** - Order and dependencies of agent execution

### Validation Rules
- Orchestration name: alphanumeric + hyphens, 3-50 characters
- Version: semantic versioning (X.Y.Z)
- Type: one of [sequential, parallel, hybrid, streaming, hierarchical]
- Agents: minimum 2 required
- Roles: at least one leader or coordinator required
- Timeout: 60-36000 seconds (1 min - 10 hours)
- Failure strategy: one of [fail-fast, continue-on-error, retry]
- Max retries: 1-10 attempts

### Properties
- Mandatory: name, version, type, agents, coordination, failure_strategy
- Optional: description, owner, monitoring, resources, communication_protocol, examples, documentation_url

## [0.9.0] - 2026-01-30

### Added
- Initial schema design
- Orchestration type enumeration
- Agent role definitions
