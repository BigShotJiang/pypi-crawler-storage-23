# Component Changelogs

**Purpose:** Track version history and breaking changes for all components.

## Format

Follows [Keep a Changelog](https://keepachangelog.com/) standard:

```markdown
# Changelog

All notable changes to this component will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Added
- New features

### Changed
- Changes to existing functionality

### Deprecated
- Soon-to-be removed features

### Removed
- Removed features

### Fixed
- Bug fixes

### Security
- Security fixes

## [1.0.0] - 2026-02-07

### Added
- Initial release
```

## Files

One file per component:
- `workflows/daily-operations.md` → `workflows-daily-operations.md`
- `agents/code-reviewer.md` → `agents-code-reviewer.md`
- etc.

## Version Numbering

**MAJOR.MINOR.PATCH**

- **MAJOR**: Breaking changes
- **MINOR**: New features, backward compatible
- **PATCH**: Bug fixes, backward compatible

## Updating Changelogs

When making changes:

1. Add entry under [Unreleased]
2. Bump version in component frontmatter
3. Move [Unreleased] to [X.Y.Z] with date
4. Keep old versions for reference

## Validation

Automated checks ensure:
- Each component has a changelog
- Versions are semantic (X.Y.Z format)
- No version skips (1.0.0 → 1.1.0 ✅, 1.0.0 → 2.0.0 ✅, 1.0.0 → 1.0.3 ❌ if 1.0.1/1.0.2 exist)
- [Unreleased] section always present
- Dates in YYYY-MM-DD format
