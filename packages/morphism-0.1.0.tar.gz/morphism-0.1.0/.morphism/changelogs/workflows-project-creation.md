# Changelog - Project Creation Workflow

All notable changes to the Project Creation workflow will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Interactive template selector with preview
- Custom template creation and sharing
- Project creation from GitHub templates
- Automated dependency installation verification
- Post-creation setup checklist validation

## [0.9.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial release with template-based project scaffolding capability
- Support for multiple project types: monorepo, web-app, library, documentation, research
- Template customization during creation (project name, description, author)
- Automatic .claude, .morphism, and .validation directory initialization
- Generated CLAUDE.md, AGENTS.md, and MEMORY.md files for new projects
- Project structure validation post-creation
- Integration with workspace management tools
- Decision trees for selecting appropriate templates

### Features
- Create projects from predefined templates
- 5 template types: monorepo, web-app, library, documentation, research
- Customizable frontmatter in generated files
- Automatic git initialization (optional)
- Directory structure templates with placeholders
- Generated CLI entrypoints and validation scripts
- Pre-populated documentation templates

### Documentation
- Complete workflow guide in `.morphism/workflows/project-creation.md`
- Template structure documentation
- Customization examples for each template type
- Post-creation checklist and verification steps
- Integration with workspace CLI

### Constraints
- Max 50 characters for project name
- Directories must not already exist at creation path
- Timeout: 3 minutes per project creation
- Template size: max 10MB
- Max 100 files per template

### Performance
- Average creation time: 5-10 seconds
- Template loading: <1 second
- Directory structure validation: <2 seconds
