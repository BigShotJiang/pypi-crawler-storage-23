# Changelog - Post-Merge Sync Hook

All notable changes to the Post-Merge Sync hook will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Automatic dependency version resolution
- Notification integration (Slack, GitHub status)
- Parallel follow-up task execution
- Custom merge event handlers
- Merge conflict analytics and reporting

## [1.0.0] - 2026-02-07

### Added
- Initial post-merge synchronization hook
- Four automatic checks after merges:
  1. Inventory changes detection
  2. Dependency updates verification
  3. Documentation changes notification
  4. Follow-up action suggestions
- Helpful prompts for common post-merge tasks
- Non-blocking execution (doesn't prevent merges)
- Integration with workspace utilities

### Checks Implemented
- **Inventory Changes** - Detects modified `.morphism/INVENTORY.md`, suggests update review
- **Dependencies** - Identifies `.morphism/dependencies.json` changes, recommends re-validation
- **Documentation** - Reports modified docs, suggests regeneration if needed
- **Changelog** - Detects changelog updates, suggests version validation

### Follow-Up Suggestions
- "Run ./scripts/validate-inventory.sh to check consistency"
- "Run ./scripts/validate-dependencies.sh to verify dependencies"
- "Consider regenerating documentation with doc-writer agent"
- "Update MEMORY.md if component structure changed"
- "Bump version numbers in changelogs if significant changes"

### Features
- Automatic detection of changed files post-merge
- Pattern matching for component changes
- Contextual suggestions based on what changed
- Summary of changes in readable format
- Non-intrusive warnings (doesn't block workflow)

### Performance
- Hook execution: <1 second
- File change detection: <500ms
- Suggestion generation: <500ms
- No performance impact on merge operations

### Configuration
- Automatically runs after successful merges
- Can be skipped with `git merge --no-verify` (discouraged)
- Configuration in `.morphism/hooks/.post-merge-config`
- Customizable suggestion messages

### Documentation
- Hook installation: `.morphism/hooks/post-merge-sync.sh`
- Configuration guide in `.morphism/hooks/README.md`
- Integration with daily operations workflow
- Examples of common post-merge scenarios

## [0.9.0] - 2026-01-30

### Added
- Hook design and specification
- Initial detection patterns
- Bash implementation framework
