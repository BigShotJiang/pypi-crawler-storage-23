# Changelog - Skill JSON Schema

All notable changes to the Skill JSON Schema will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Skill composition and combining capabilities
- Dynamic capability loading
- Plugin ecosystem for skill extensions
- Skill marketplace metadata
- Performance profiling schema

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial JSON Schema for skill frontmatter validation
- Metadata validation (name, version, description, triggers)
- Category validation against predefined list
- Status tracking (stable, beta, experimental, archived)
- Execution environment constraints
- Input/output parameter validation
- Dependency and prerequisite tracking
- Usage examples schema

### Schema Sections
- **Metadata** - name, version, description, author, created, updated
- **Category** - Skills organized into 12+ categories
- **Triggers** - How/when skills are invoked (command, file-pattern, schedule, webhook, manual)
- **Execution** - Environment requirements (shell, Node.js version, Python version, etc.)
- **Parameters** - Input parameters with types, defaults, validation rules
- **Output** - Output specification and format
- **Dependencies** - Required tools/components
- **Status** - One of [stable, beta, experimental, archived]
- **Examples** - Usage examples and output samples

### Skill Categories
- document-manipulation, code-generation, analysis, automation, validation
- documentation, testing, debugging, performance, security, deployment, custom

### Validation Rules
- Skill name: alphanumeric + hyphens, 3-50 characters
- Version: semantic versioning (X.Y.Z)
- Category: must match predefined list
- Status: one of [stable, beta, experimental, archived]
- Triggers: at least one required
- Parameters: optional, array of parameter objects
- Parameters have: name (string), type (string/number/boolean/array/object), required (boolean), default (optional)

### Properties
- Mandatory: name, version, description, category, triggers, status
- Optional: author, created, updated, dependencies, parameters, output, examples, documentation_url, timeout

## [0.9.0] - 2026-01-30

### Added
- Initial schema design
- Category enumeration
- Basic trigger patterns
