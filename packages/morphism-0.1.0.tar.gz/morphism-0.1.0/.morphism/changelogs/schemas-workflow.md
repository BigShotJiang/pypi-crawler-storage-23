# Changelog - Workflow JSON Schema

All notable changes to the Workflow JSON Schema will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Conditional workflow steps
- Loop and iteration support
- Dynamic step ordering based on input
- Workflow templates and variable substitution
- Visual workflow editor schema

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial JSON Schema for workflow definitions
- Workflow metadata validation (name, version, description, owner)
- Trigger definition validation (events that start workflows)
- Step structure validation (sequential execution order)
- Decision point validation (conditional branches)
- Duration and timeout constraints
- Owner and maintenance information
- Status tracking (active, deprecated, experimental)

### Schema Sections
- **Metadata** - name, version, description, owner, status (active/deprecated/experimental)
- **Triggers** - Events that initiate workflow (manual, file-change, schedule, webhook)
- **Duration** - Expected runtime, timeout, SLA definitions
- **Steps** - Sequential workflow steps with action, condition, on_error handlers
- **Decision Points** - Conditional logic with multiple branches
- **Prerequisites** - Tools/components required before execution
- **Examples** - Sample workflow execution scenarios
- **Owner Info** - Contact, documentation link, maintenance schedule

### Validation Rules
- Workflow name: alphanumeric + hyphens, 3-50 characters
- Version: semantic versioning (X.Y.Z)
- Status: one of [active, deprecated, experimental]
- Triggers: at least one required
- Steps: at least one required
- Duration: HH:MM:SS format
- Timeout: must be >= estimated duration
- Owner: email format or team identifier

### Properties
- Mandatory: name, version, triggers, steps, duration, owner
- Optional: description, decision_points, prerequisites, examples, tags, documentation_url
- Step properties: action (string), condition (optional), on_error (optional), timeout (optional)

## [0.9.0] - 2026-01-30

### Added
- Initial schema design
- Basic workflow structure
- Step validation framework
