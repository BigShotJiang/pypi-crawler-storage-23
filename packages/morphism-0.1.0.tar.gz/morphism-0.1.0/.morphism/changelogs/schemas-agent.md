# Changelog - Agent JSON Schema

All notable changes to the Agent JSON Schema will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Support for conditional capabilities
- Custom capability parameter schemas
- Agent grouping and categorization
- Performance benchmark schema extension
- Integration metrics tracking

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial JSON Schema for agent definitions
- Validation of agent metadata (name, version, description, type)
- Capability structure validation
- Constraint validation (tokens, timeout, file limits, size limits)
- Interface specification validation (inputs, outputs, errors)
- Dependencies tracking schema
- Configuration options validation
- Performance metrics schema

### Schema Sections
- **Metadata** - name, version, description, author, type (autonomous/reactive/coordinator)
- **Capabilities** - Array of capability objects with name, description, inputs, outputs
- **Constraints** - Token limit, timeout, file count limit, file size limit, max agents
- **Interface** - Input schema, output schema, error types
- **Dependencies** - Array of component dependencies
- **Configuration** - Configurable options with types and defaults
- **Performance** - Benchmarks, accuracy metrics, false positive rates

### Validation Rules
- Agent name: alphanumeric + hyphens, 3-50 characters
- Version: semantic versioning (X.Y.Z)
- Capabilities: min 1, max 20 per agent
- Constraints: all positive integers
- Timeout: 60-3600 seconds (1 min - 1 hour)
- Token limits: 10,000 - 300,000 tokens
- File limits: 1-100 files
- Size limits: 100KB - 100MB

### Properties
- Mandatory: name, version, type, capabilities, constraints, interface
- Optional: author, description, configuration, performance, dependencies, tags, examples

## [0.9.0] - 2026-01-30

### Added
- Initial schema design
- Core capability structure
- Basic constraint validation
