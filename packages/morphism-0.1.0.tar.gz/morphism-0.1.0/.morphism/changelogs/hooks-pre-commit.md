# Changelog - Pre-Commit Validation Hook

All notable changes to the Pre-Commit Validation hook will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Integration with pre-commit framework (yaml configuration)
- Customizable validation rule sets
- Performance optimization with parallel checking
- Integration with secret scanning services (GitHub, GitLab)
- Automatic fixing of common issues (formatter integration)

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial pre-commit validation hook implementation
- Five automatic checks before commits:
  1. File size validation (max 10MB per file)
  2. Debug statement detection (console.log, print, debugger)
  3. Secrets scanning (API keys, credentials, private tokens)
  4. Inventory consistency verification
  5. Documentation completeness checks
- Detailed error messages with remediation steps
- Hard blocks on validation failures (commits are prevented)
- Warning messages for non-critical issues

### Checks Implemented
- **File Size** - Blocks files > 10MB, warns on > 5MB
- **Debug Statements** - Detects and reports console.log, print(), debugger; statements
- **Secrets** - Scans for common credential patterns (API_KEY, password=, token:)
- **Inventory** - Verifies .morphism/INVENTORY.md references actual files
- **Documentation** - Checks for required README files in modified directories

### Validation Rules
- Blocks commits if:
  - Any file > 10MB detected
  - Active debug statements found
  - Potential secrets detected
  - Broken inventory references found
- Warns but allows commit if:
  - File > 5MB (recommend splitting)
  - Missing optional documentation
  - Inventory inconsistencies (non-critical)

### Performance
- Validation time: 2-5 seconds for typical commits
- Scales linearly with file count
- Parallel checking for file validation
- Early exit if critical issues found

### Configuration
- Checks applied to all commits by default
- Can be overridden with `git commit --no-verify` (discouraged)
- Ignore patterns definable in `.git-hooks-ignore`

### Documentation
- Hook installation: `.morphism/hooks/pre-commit-validation.sh`
- Configuration guide in `.morphism/hooks/README.md`
- Troubleshooting common validation failures
- Integration with CI/CD pipelines

## [0.9.0] - 2026-01-30

### Added
- Hook design and specification
- Initial validation rules
- Bash implementation framework
