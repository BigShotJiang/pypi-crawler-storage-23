# Changelog: proofs/InformationTheory

All notable changes to InformationTheory will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

### Planned
- Future enhancements and improvements

---

## [0.9.0] - 2026-02-11

### Changed
- Version updated to reflect maturity level
- Component status: active

### Added
- Initial implementation of InformationTheory
- Core functionality complete
- Documentation created

---

**Component Type:** proofs
**Status:** active
**Critical:** False
