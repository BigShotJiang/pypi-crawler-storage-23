# Changelog - Workflow Trigger Hook

All notable changes to the Workflow Trigger hook will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Conditional workflow execution based on change content
- Parallel workflow launching
- Workflow completion notifications
- Custom trigger rules and patterns
- Workflow result aggregation and reporting

## [1.0.0] - 2026-02-07

### Added
- Initial workflow auto-triggering hook
- Three automatic workflow triggers based on file patterns:
  1. **Documentation Validation** - Triggers on `docs/` or `*.md` changes
  2. **Proof Building** - Triggers on `lab/proofs/` changes
  3. **Kiro Validation** - Triggers on `.morphism/` changes
- Pattern matching for file change detection
- Asynchronous workflow execution (non-blocking)
- Workflow status logging and reporting

### Automatic Triggers
- **Documentation Changes** - Modified files matching `docs/**`, `*.md`
  - Runs: documentation-validation workflow
  - Checks: file syntax, link validity, structure completeness
  - Report: generated as `.morphism/logs/doc-validation-{timestamp}.log`

- **Proof Changes** - Modified files matching `lab/proofs/**`, `Morphism.lean`
  - Runs: proof-build workflow
  - Checks: Lean syntax, Lake build success, import validity
  - Report: generated as `.morphism/logs/proof-build-{timestamp}.log`

- **Inventory Changes** - Modified files matching `.morphism/**`
  - Runs: inventory-validation workflow
  - Checks: INVENTORY.md consistency, schema validity, dependency integrity
  - Report: generated as `.morphism/logs/inventory-validation-{timestamp}.log`

### Features
- Automatic file pattern detection
- Non-blocking asynchronous execution
- Parallel workflow launching
- Detailed execution logging
- Workflow result notifications
- Error reporting with remediation suggestions

### Configuration
- Pattern definitions in `.morphism/hooks/.workflow-triggers.json`
- Per-pattern timeout and retry limits
- Customizable notification thresholds
- Enable/disable per workflow

### Performance
- Hook execution: <100ms
- Trigger detection: <50ms
- Background workflow execution: 2-10 minutes (depends on workflow)
- No blocking on commit/push operations

### Logging
- All triggered workflows logged to `.morphism/logs/`
- Log format: timestamp | workflow_name | status | duration | summary
- Log retention: 30 days (configurable)
- Accessible via `./scripts/view-workflow-logs.sh`

### Documentation
- Hook installation: `.morphism/hooks/workflow-trigger.sh`
- Configuration guide in `.morphism/hooks/README.md`
- Trigger pattern reference
- Troubleshooting false triggers

## [0.9.0] - 2026-01-30

### Added
- Hook design and specification
- Initial trigger patterns
- Bash implementation framework
