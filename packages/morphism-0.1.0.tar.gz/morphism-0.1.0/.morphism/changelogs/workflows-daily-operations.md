# Changelog - Daily Operations Workflow

All notable changes to the Daily Operations workflow will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Planned
- Dashboard refresh rate optimization
- Slack integration for status alerts
- Multi-workspace support

## [1.2.0] - 2026-02-11

### Changed
- Version updated based on maturity level
- Reflects current component status

---

## [1.0.0] - 2026-02-07

### Added
- Initial release with three core commands:
  - `./workspace status` - Quick repository health check
  - `./workspace status --full` - Comprehensive scan with git details
  - `./scripts/pull-all.sh` - Bulk git pull across all projects
- Dashboard view for visual status overview
- Daily operations documentation with decision trees
- Integration with workspace CLI
- Support for custom project limits and filtering

### Features
- Fast status checks (<1 second for default)
- Full scans available (2-3 seconds)
- Color-coded status indicators
- Stale branch detection
- Merge conflict identification
- Pull progress reporting

### Documentation
- Complete workflow guide in `.morphism/workflows/daily-operations.md`
- Usage examples and decision points
- Integration with morning standups
- Best practices for team alignment
