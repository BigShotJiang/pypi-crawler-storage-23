# Extensions

**Purpose:** Platform-level capabilities that agents and workflows can request and use.

**Format:** Markdown with clear capability definition, API surface, constraints.

## Extensions

- `context-management.md` - Token/context optimization and multi-turn management
- `parallel-execution.md` - Parallel agent/skill execution with coordination

## What is an Extension?

An "extension" is a system-level capability that:
- Provides an API agents can call
- Manages shared resources (tokens, processes, state)
- Enforces constraints and governance
- Enables advanced patterns (handoffs, parallel execution)

**Example:**
```bash
# Agent calls context management power
context-extension token-budget --format=json
# Returns: {used: 45000, max: 100000, remaining: 55000}
```

## Creating New Extensions

1. Create markdown file: `my-extension.md`
2. Define capability overview
3. Document APIs
4. List constraints
5. Provide use cases
6. Update this README

Template:
```markdown
---
name: My Power Name
description: Brief description
type: platform-capability
status: ✅ Active
version: 1.0.0
---

# My Power Name

## Overview

What this power does...

## Capabilities Granted

### 1. Capability Name
Details...

**API:**
\`\`\`bash
my-extension action --flag=value
\`\`\`

## Configuration

...

## Constraints

...

## Use Cases

...

## Integration Points

...
```

## Extension Lifecycle

1. **Proposed:** New extension identified as needed
2. **Designed:** Capability and API defined
3. **Implemented:** Backend implementation (may be stub)
4. **Documented:** This README updated, constraints clear
5. **Released:** Available to agents/workflows
6. **Monitored:** Track usage, performance
7. **Evolved:** Add capabilities as needed
8. **Deprecated:** Phase out if superseded

## API Conventions

All extensions should follow:

```bash
# Pattern: extension-name action [options]
context-extension token-budget --format=json
parallel-extension launch --agents=a,b,c --timeout=300

# Return JSON with status, data, errors
{
  "status": "success|error",
  "data": {...},
  "error": null,
  "elapsed_ms": 125
}
```

## Constraints Documentation

Every extension must document:
- Max resource usage (tokens, memory, time)
- Concurrent operation limits
- Input/output size limits
- Timeout policies
- Error recovery options

Example:
```yaml
constraints:
  max_tokens: 100000
  max_concurrent_jobs: 5
  timeout_seconds: 600
  max_output_mb: 100
```

## Governance

Each extension should define:
- **Owner:** Team responsible
- **Approval required:** For what operations?
- **Audit trail:** What's logged?
- **Data retention:** How long kept?

## Monitoring Extensions

```bash
# Check extension status
my-extension health-check

# Get extension metrics
my-extension metrics --time-range=24h

# List active extension usages
my-extension list-active
```

## Related Concepts

- **Orchestrations** (`.morphism/orchestrations/`) - Patterns for using extensions
- **Agents** (`.morphism/agents/`) - Define what calls extensions
- **Workflows** (`.morphism/workflows/`) - Trigger extension usage
- **Hooks** (`.morphism/hooks/`) - Automate extension calls

## Roadmap

Potential future extensions:
- **State Management** - Persistent state across conversations
- **Error Recovery** - Automatic failure detection and recovery
- **Rate Limiting** - Fair access to shared resources
- **Caching** - Results reuse and optimization
- **Audit & Compliance** - Governance and compliance tracking

## See Also

- `AGENTS.md` - Agent governance
- `ORCHESTRATIONS/` - Coordination patterns
- `WORKFLOWS/` - Multi-step processes
