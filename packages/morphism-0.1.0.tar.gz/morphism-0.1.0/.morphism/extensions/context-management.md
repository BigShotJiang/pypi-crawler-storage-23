---
name: Context Management Power
description: Capability to manage conversation context, token budgets, and multi-turn state
type: platform-capability
status: ✅ Active
version: 1.0.0
---

# Context Management Power

System-level capability for managing conversation context, optimizing token usage, and handling multi-turn agent interactions.

## Overview

Allows agents and workflows to:
- Track and optimize token consumption
- Manage conversation memory and history
- Compress context when approaching limits
- Perform handoffs between agents with full context
- Detect and prevent context thrashing

## Capabilities Granted

### 1. Token Budget Management
- Read current token usage
- Check remaining budget
- Get alerts at 75%/90% threshold
- Request context compression

**API:**
```bash
context-power token-budget --format=json
# Returns: {used: 45000, max: 100000, remaining: 55000, percent_used: 45}
```

### 2. Context Compression
- Automatic summarization of long conversations
- Intelligent pruning of redundant messages
- Preserve critical decision points and requirements
- Generate handoff summaries for context transfer

**API:**
```bash
context-power compress --strategy=balanced --target-tokens=50000
# Returns: {original: 85000, compressed: 50000, saved: 35000, quality_impact: "minimal"}
```

### 3. Conversation State Tracking
- Maintain full conversation history
- Index by topic/decision/requirement
- Quick retrieval of specific context
- Detect conversation drift

**API:**
```bash
context-power track --action=index-decision --key="authentication-method" --value="oauth2"
context-power track --action=retrieve --key="authentication-method"
```

### 4. Multi-Agent Handoff
- Create handoff summaries with condensed context
- Tag critical information for next agent
- Preserve decision history and requirements
- Ensure continuity across agent transitions

**API:**
```bash
context-power handoff \
  --from-agent="code-reviewer" \
  --to-agent="doc-writer" \
  --preserve-keys="requirements,decisions,code-samples"
# Returns: {handoff_summary: "...", context_size: 8000, critical_items: [...]}
```

### 5. Memory Optimization
- Identify redundant context
- Suggest pruning candidates
- Optimize for relevance
- Detect unnecessary duplication

**API:**
```bash
context-power analyze --action=find-redundancy
# Returns: {redundancy_percent: 15, candidates: [...], savings_potential: 12000}
```

## Use Cases

### Case 1: Long Running Conversation

```
Initial context: 2000 tokens
Growth per turn: 500 tokens
Target: 100 turns

Alert at 80% (80000 tokens after 60 turns)
  ↓
Automatic compression: 80000 → 40000 tokens (50% saved)
  ↓
Continue with 40000 + remaining budget
```

### Case 2: Multi-Agent Workflow

```
Agent 1 (code-reviewer): Completes analysis
  ↓ Request handoff
context-power handoff --from="code-reviewer" --to="doc-writer"
  ↓ Returns condensed context (8000 tokens)
Agent 2 (doc-writer): Starts with context summary
  ↓ Has all critical decisions, preserves continuity
```

### Case 3: Context Drift Prevention

```
Conversation started: "Implement authentication"
After 50 turns: Discussing UI colors

Detection: Topic drift detected
Action: Alert user, suggest refocus or context reset
```

## Configuration

### Token Limits

```yaml
# .claude/context-management.yaml
max_tokens: 100000
warning_threshold: 75000   # 75%
critical_threshold: 90000  # 90%
compression_trigger: 85000  # 85%

compression:
  strategy: "balanced"
  preserve_minimum_tokens: 20000
  target_ratio: 0.5  # Compress to 50%
```

### Preservation Policies

```yaml
always_preserve:
  - user_requirements
  - critical_decisions
  - security_constraints
  - architecture_decisions
  - error_messages

can_prune:
  - verbose_explanations
  - intermediate_steps
  - redundant_confirmations
  - outdated_context
```

## Constraints

- **Minimum preserve:** 20,000 tokens (critical context)
- **Compression ratio:** Cannot exceed 50% reduction without quality loss
- **History depth:** Last 100 turns always available
- **Handoff size:** Max 10,000 tokens per handoff summary

## Integration Points

### Pre-commit Hook

```bash
# Check context health before major operations
context-power check-health --fail-if-over-budget
```

### Workflow Trigger

```bash
# Auto-compress when budget low
if context-power token-budget --percent | grep -q "85"; then
    context-power compress --strategy=aggressive
fi
```

### Agent Handoff

```bash
# Automatic on agent transition
context-power handoff \
    --from="$CURRENT_AGENT" \
    --to="$NEXT_AGENT" \
    --auto-summary
```

## Monitoring

### Health Check

```bash
context-power health-report
# Output:
# ✅ Token budget: 45% used (45000/100000)
# ✅ History indexed: 50 turns
# ✅ No redundancy detected
# ⚠️  Compression recommended at 75% (in 3 turns)
```

### Metrics

```bash
context-power metrics
# Output:
# - Total compressions: 3
# - Avg compression ratio: 0.52
# - Quality preservation: 98%
# - Handoffs performed: 2
# - Avg handoff time: 2.3 seconds
```

## Governance

**Owner:** Platform
**Approval required:** For disabling compression
**Audit trail:** All compressions logged
**Data retention:** 7 days

## Related Powers

- [State Management](./state-management.md)
- [Error Recovery](./error-recovery.md)
