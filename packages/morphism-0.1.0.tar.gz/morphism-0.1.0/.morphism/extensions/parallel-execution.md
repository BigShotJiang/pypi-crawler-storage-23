---
name: Parallel Execution Power
description: Capability to execute multiple agents/skills in parallel with coordination
type: platform-capability
status: ✅ Active
version: 1.0.0
---

# Parallel Execution Power

System-level capability for safely executing multiple independent agents or skills in parallel with coordination, synchronization, and result aggregation.

## Overview

Allows agents and workflows to:
- Launch multiple parallel operations
- Coordinate between independent processes
- Aggregate results from parallel execution
- Handle partial failures gracefully
- Monitor parallel progress

## Capabilities Granted

### 1. Parallel Launch

Start multiple agents/skills simultaneously:

```bash
parallel-power launch \
  --agents="code-reviewer,doc-writer,security-scanner" \
  --input="src/" \
  --timeout=300
# Returns: {job_id: "par-2026-02-07-001", agents: 3, status: "running"}
```

### 2. Execution Coordination

Manage dependencies and ordering:

```bash
parallel-power coordinate \
  --job-id="par-2026-02-07-001" \
  --strategy="independent"  # or "dependent", "staged"
# Independent: All start together
# Dependent: B waits for A's output
# Staged: Groups execute in phases
```

### 3. Progress Monitoring

Real-time progress tracking:

```bash
parallel-power monitor --job-id="par-2026-02-07-001"
# Returns:
# agent-1: 45% complete (elapsed: 120s)
# agent-2: 85% complete (elapsed: 120s)
# agent-3: 10% complete (elapsed: 120s)
# Overall: 47% complete
```

### 4. Result Aggregation

Combine results from parallel execution:

```bash
parallel-power aggregate \
  --job-id="par-2026-02-07-001" \
  --mode="merge"  # or "concat", "nest", "custom"
# Returns: {merged results from all agents}
```

### 5. Failure Handling

Handle failures in parallel operations:

```bash
parallel-power handle-failure \
  --job-id="par-2026-02-07-001" \
  --agent="code-reviewer" \
  --strategy="continue"  # or "retry", "rollback"
# Decide what to do with failed agent
```

## Use Cases

### Case 1: Independent Parallel Skills

```
Document Processing:
  ├─ Extract text (2 min)
  ├─ Extract metadata (1 min)
  ├─ Extract images (3 min)
  └─ Analyze structure (2 min)

Timeline: 3 min total (vs 8 min sequential)

parallel-power launch --agents="text,meta,images,structure" --input="doc.docx"
```

### Case 2: Dependent Parallel Agents

```
Code Review Pipeline:
  ├─ Syntax check (2 min)
  ├─┴─ Logic check [depends on syntax] (3 min)
  ├─┴─ Security scan [depends on syntax] (4 min)
  └─┴─ Generate report [depends on all] (1 min)

Timeline: 10 min (structured dependencies)

parallel-power launch --agents="..." --strategy="dependent"
```

### Case 3: Multi-Team Parallel Effort

```
Workspace Modernization:
  Team A: CLI hardening (3 days)
  Team B: Documentation cleanup (3 days)
  Team C: Performance optimization (3 days)
  Team D: Security sweep (3 days)

Timeline: 3 days total (vs 12 days sequential)
Coordination: Merge in risk order after all complete
```

## Configuration

### Parallelization Rules

```yaml
# .claude/parallel-execution.yaml
max_parallel_agents: 10
max_parallel_processes: 4  # Limited by CPU cores
default_timeout_seconds: 600
timeout_strategy: "fail-fast"  # or "extend", "graceful"

failure_handling:
  default_mode: "continue"  # or "fail-fast", "retry"
  max_retries: 2
  backoff_multiplier: 1.5

result_aggregation:
  default_mode: "merge"  # or "concat", "nest"
  remove_duplicates: true
  sort_results: false
```

### Resource Limits

```yaml
per_agent:
  max_memory_mb: 1024
  max_cpu_percent: 50
  max_disk_usage_mb: 500

cluster:
  max_concurrent_jobs: 5
  max_agents_per_job: 10
  queue_timeout_seconds: 3600
```

## Constraints

- **Max agents:** 10 per job (avoid overload)
- **Memory per agent:** 1GB (configurable)
- **Timeout:** 10 minutes default (configurable)
- **Result size:** 100MB max per agent output

## Advanced Features

### Custom Aggregation

```bash
parallel-power aggregate \
  --job-id="par-2026-02-07-001" \
  --mode="custom" \
  --script="./aggregate-results.sh"
# Custom script handles aggregation logic
```

### Load Balancing

```bash
parallel-power launch \
  --agents="..." \
  --load-balance="adaptive"
# Distributes work based on agent capacity
# Slower agents get smaller workloads
```

### Fault Tolerance

```bash
parallel-power launch \
  --agents="..." \
  --fault-tolerance="high"
  # High: Continue if 1 agent fails
  # Medium: Retry once then continue
  # Low: Fail if any agent fails
```

## Integration Points

### Workflow Orchestration

```bash
# In workflow definition
agents:
  - code-reviewer
  - doc-writer
  - security-scanner
coordination: parallel
timeout: 600
failure_mode: continue
```

### Skill Parallel Execution

```bash
# In skill definition
skills:
  - extract-skill
  - transform-skill
  - validate-skill
execution: parallel
aggregation: merge
```

## Monitoring

### Job Status

```bash
parallel-power status --job-id="par-2026-02-07-001"
# Output:
# Job: par-2026-02-07-001
# Status: RUNNING
# Progress: 3/4 complete (75%)
# Elapsed: 285 seconds
# Estimated completion: 45 seconds
```

### Performance Metrics

```bash
parallel-power metrics --job-id="par-2026-02-07-001"
# Output:
# - Total time: 330 seconds
# - Sequential equivalent: 480 seconds
# - Speedup: 1.45x
# - Efficiency: 36% (4 agents / 4 CPU cores)
# - Memory used: 2.3GB / 4GB
```

### Failure Report

```bash
parallel-power report --job-id="par-2026-02-07-001"
# Output:
# - Agent code-reviewer: FAILED (timeout after 600s)
# - Agent doc-writer: SUCCESS (180s)
# - Agent security-scanner: SUCCESS (240s)
# - Aggregate status: PARTIAL (2/3 succeeded)
```

## Governance

**Owner:** Platform
**Approval required:** For custom aggregation scripts
**Audit trail:** All parallel jobs logged
**Data retention:** 14 days

## Best Practices

1. **Balance loads:** Keep agent runtimes similar
2. **Minimize shared state:** Reduces coordination overhead
3. **Timeout generously:** Account for system load
4. **Plan aggregation:** Know how to combine results
5. **Test independently:** Each agent should work solo

## Related Powers

- [Context Management](./context-management.md)
- [Orchestration Patterns](./../orchestrations/)

## Examples

### Data Processing Pipeline

```bash
parallel-power launch \
  --agents="extract,transform,validate,report" \
  --input="large-dataset.csv" \
  --timeout=900 \
  --failure-mode="continue"
```

### Multi-Agent Code Review

```bash
parallel-power launch \
  --agents="code-reviewer,security-scanner,performance-analyzer" \
  --input="src/" \
  --aggregation="merge" \
  --timeout=600
```

### Team Parallel Development

```bash
# In workflow YAML
teams:
  - name: "cli-team"
    agent: "code-reviewer"
    branch: "feat/cli-hardening"
  - name: "docs-team"
    agent: "doc-writer"
    branch: "docs/cleanup"

parallel-power launch --agents="code-reviewer,doc-writer" --mode="worktree-parallel"
```
