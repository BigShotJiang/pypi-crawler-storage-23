# Hooks

**Purpose:** Automated triggers that run on git events and custom triggers.

**Format:** Bash shell scripts with shebang (`#!/bin/bash`).

## Hooks

- `pre-commit-validation.sh` - Validates code quality before commit
- `pre-push-validation.sh` - Enforces branch/scope/gate policy before push
- `post-merge-sync.sh` - Synchronizes workspace after merge/pull
- `workflow-trigger.sh` - Automatically triggers workflows on events
- `pr-validation.sh` - Validates PRs meet quality standards

## Installation

### Git Pre-Commit Hook

```bash
# Install workspace-managed hook wrapper
./scripts/install-hooks.sh
```

Test:
```bash
# This will trigger the hook
git commit -m "test"
```

What this enforces:
- Branch naming policy (`feature/*`, `fix/*`, `docs/*`, `chore/*`, `codex/*`, etc.)
- Scoped change hygiene (blocks broad, mixed commits by default)
- Required quality gate selection (`fast` for docs-only, `strict` otherwise)

Rare overrides:
- `ALLOW_MAIN_BRANCH=1` (allow direct commit on `main`/`master`)
- `ALLOW_BROAD_SCOPE=1` (allow intentionally broad commit scope)

### GitHub Actions Hooks

PR validation runs automatically via GitHub Actions:
- Triggered on every PR
- Validates description, labels, conflicts, CI status
- Comments results to PR

## Creating New Hooks

1. Create script in this directory: `my-hook.sh`
2. Add shebang: `#!/bin/bash`
3. Implement validation/action logic
4. Make executable: `chmod +x my-hook.sh`
5. Link from `.git/hooks/` if git hook
6. Update this README

Example:
```bash
#!/bin/bash
# Post-merge hook example

set -e
echo "🔄 Running post-merge sync..."

# Your validation/sync logic here

echo "✅ Post-merge sync complete"
exit 0
```

## Hook Guidelines

- **Exit 0:** Success (allow action)
- **Exit 1:** Failure (block action for pre-commit hooks)
- **Use color:** Green for success, red for errors, yellow for warnings
- **Be fast:** Hooks run synchronously, minimize latency
- **Be safe:** No destructive operations
- **Document:** Add comments explaining purpose

## Integration with Workflows

Hooks can trigger workflows:

```bash
# Trigger workflow on event
if [[ condition ]]; then
    ./run-sequential-validation.sh ...
fi
```

## See Also

- `.morphism/orchestrations/` - Coordination patterns
- `.morphism/extensions/` - Platform capabilities
- `.morphism/workflows/` - Multi-step processes
