#!/bin/bash
# Pre-commit validation hook
# Runs on: git commit
# Purpose: Validate code quality before commit

set -e

echo "🔍 Running pre-commit validation..."

# Use python3 or python (Windows compatibility)
# On Windows, python3 may be a broken Store alias — check python first
if python --version >/dev/null 2>&1; then
    PYTHON=python
elif python3 --version >/dev/null 2>&1; then
    PYTHON=python3
else
    echo "No Python interpreter found, skipping Python checks"
    PYTHON=""
fi

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Get staged files
STAGED_FILES=$(git diff --cached --name-only --diff-filter=ACM)

if [ -z "$STAGED_FILES" ]; then
    echo "✅ No files to validate"
    exit 0
fi

# Professional standards policy (branch naming, scoped changes, gate selection)
if [ -f "./scripts/enforce-professional-standards.sh" ]; then
    echo "🧭 Enforcing professional standards..."
    if ! bash ./scripts/enforce-professional-standards.sh --source staged --run-gate; then
        echo -e "${RED}❌ Professional standards check failed${NC}"
        exit 1
    fi
fi

# Validation results
ERRORS=0
WARNINGS=0

# 1. Check for large files
echo "📊 Checking file sizes..."
for file in $STAGED_FILES; do
    size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null || echo 0)
    if [ $size -gt 50000000 ]; then
        echo -e "${RED}❌ File too large: $file ($((size/1024/1024))MB)${NC}"
        ERRORS=$((ERRORS + 1))
    fi
done

# 2. Check for debug code (console.log, debugger, etc.)
echo "🐛 Checking for debug statements..."
if git diff --cached | grep -E "(console\.log|debugger|pdb\.set_trace|print\()" > /dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  Debug statements found${NC}"
    WARNINGS=$((WARNINGS + 1))
fi

# 3. Check for secrets/credentials
echo "🔐 Checking for secrets..."
if git diff --cached | grep -E "(AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36}|-----BEGIN (RSA|OPENSSH|EC|DSA) PRIVATE KEY-----|(?i)(password|secret|token|api[_-]?key)[[:space:]]*[:=][[:space:]]*['\"][^'\"]{8,})" > /dev/null 2>&1; then
    echo -e "${YELLOW}⚠️  Potential secret-like content found (manual review recommended)${NC}"
    WARNINGS=$((WARNINGS + 1))
fi

# 4. Check Kiro inventory consistency
echo "📋 Checking Kiro inventory..."
if [ -f ".morphism/inventory/INVENTORY.md" ]; then
    # Verify referenced files exist
    if grep -o '`\.morphism/[^`]*`' .morphism/inventory/INVENTORY.md | sed 's/[`]//g' | while read -r path; do
        if [[ "$path" == *"*"* ]]; then
            continue
        fi
        if [ ! -f "$path" ] && [ ! -d "$path" ]; then
            echo -e "${YELLOW}⚠️  Referenced path not found: $path${NC}"
            WARNINGS=$((WARNINGS + 1))
        fi
    done; then
        :
    fi
fi

# 5. Validate agent JSON against schema
echo "🤖 Validating agent definitions..."
AGENT_DIR=".morphism/agents"
AGENT_SCHEMA=".morphism/schemas/agent.schema.json"
if [ -d "$AGENT_DIR" ] && [ -f "$AGENT_SCHEMA" ]; then
    for agent_file in "$AGENT_DIR"/*.json; do
        if [ -f "$agent_file" ]; then
            agent_name=$(basename "$agent_file")
            # Check valid JSON
            if ! $PYTHON -c "import json; json.load(open('$agent_file'))" 2>/dev/null; then
                echo -e "${RED}❌ Invalid JSON: $agent_name${NC}"
                ERRORS=$((ERRORS + 1))
            else
                # Verify required fields exist
                for field in name version description type status capabilities constraints interface; do
                    if ! $PYTHON -c "import json; d=json.load(open('$agent_file')); assert '$field' in d" 2>/dev/null; then
                        echo -e "${RED}❌ Missing required field '$field' in $agent_name${NC}"
                        ERRORS=$((ERRORS + 1))
                    fi
                done
                # Verify mathematicalFoundation has axioms if present
                if $PYTHON -c "import json; d=json.load(open('$agent_file')); assert 'mathematicalFoundation' in d" 2>/dev/null; then
                    if ! $PYTHON -c "import json; d=json.load(open('$agent_file')); assert 'axioms' in d['mathematicalFoundation'] and len(d['mathematicalFoundation']['axioms']) > 0" 2>/dev/null; then
                        echo -e "${YELLOW}⚠️  mathematicalFoundation in $agent_name missing axiom references${NC}"
                        WARNINGS=$((WARNINGS + 1))
                    fi
                fi
                echo -e "${GREEN}  ✅ $agent_name valid${NC}"
            fi
        fi
    done
fi

# 6. Check Lean proof status (non-blocking)
echo "📐 Checking Lean proof status..."
PROOF_DIR="morphism/lab/proofs"
if [ -d "$PROOF_DIR" ]; then
    SORRY_COUNT=$(grep -r "sorry" "$PROOF_DIR"/ --include="*.lean" 2>/dev/null | grep -v "STATUS:" | grep -v "^--" | wc -l || echo 0)
    SORRY_COUNT=$(echo "$SORRY_COUNT" | tr -d ' ')
    if [ "$SORRY_COUNT" -gt 0 ]; then
        echo -e "${YELLOW}⚠️  $SORRY_COUNT sorry placeholders found in Lean proofs (non-blocking)${NC}"
        WARNINGS=$((WARNINGS + 1))
    else
        echo -e "${GREEN}✅ All Lean proofs complete (no sorry)${NC}"
    fi
fi

# Report
echo ""
if [ $ERRORS -eq 0 ] && [ $WARNINGS -eq 0 ]; then
    echo -e "${GREEN}✅ All validations passed${NC}"
    exit 0
elif [ $ERRORS -eq 0 ]; then
    echo -e "${YELLOW}⚠️  $WARNINGS warnings (non-blocking)${NC}"
    exit 0
else
    echo -e "${RED}❌ $ERRORS errors found${NC}"
    echo "Fix errors before committing."
    exit 1
fi
