#!/bin/bash
# PR validation hook
# Runs on: GitHub PR events (via Actions)
# Purpose: Validate PR meets quality standards

set -e

echo "✅ PR validation hook"

PR_NUMBER="${1:-}"
if [ -z "$PR_NUMBER" ]; then
    echo "Usage: $0 <pr_number>"
    exit 1
fi

echo "🔍 Validating PR #$PR_NUMBER..."

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ERRORS=0
WARNINGS=0

# 1. Check if description present
if ! gh pr view "$PR_NUMBER" --json body -q '.body' | grep -q .; then
    echo -e "${YELLOW}⚠️  PR missing description${NC}"
    ((WARNINGS++))
fi

# 2. Check if labels present
labels=$(gh pr view "$PR_NUMBER" --json labels -q '.labels[].name' | wc -l)
if [ "$labels" -eq 0 ]; then
    echo -e "${YELLOW}⚠️  PR missing labels${NC}"
    ((WARNINGS++))
fi

# 3. Check for draft status
draft=$(gh pr view "$PR_NUMBER" --json isDraft -q '.isDraft')
if [ "$draft" = "true" ]; then
    echo -e "${YELLOW}📝 PR is in draft state${NC}"
    ((WARNINGS++))
fi

# 4. Check for merge conflicts
conflicts=$(gh pr view "$PR_NUMBER" --json mergeable -q '.mergeable')
if [ "$conflicts" = "CONFLICTING" ]; then
    echo -e "${RED}❌ PR has merge conflicts${NC}"
    ((ERRORS++))
fi

# 5. Check CI status
status=$(gh pr view "$PR_NUMBER" --json statusCheckRollup -q '.statusCheckRollup[0].state' 2>/dev/null || echo "UNKNOWN")
if [ "$status" = "FAILURE" ]; then
    echo -e "${RED}❌ CI checks failed${NC}"
    ((ERRORS++))
elif [ "$status" = "PENDING" ]; then
    echo -e "${YELLOW}⏳ CI checks still running${NC}"
fi

# Summary
echo ""
if [ $ERRORS -eq 0 ]; then
    echo -e "${GREEN}✅ PR validation passed${NC}"
    exit 0
else
    echo -e "${RED}❌ PR validation failed ($ERRORS errors)${NC}"
    exit 1
fi
