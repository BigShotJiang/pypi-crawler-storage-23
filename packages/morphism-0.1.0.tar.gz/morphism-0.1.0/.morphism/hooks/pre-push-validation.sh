#!/usr/bin/env bash
# Pre-push standards validation hook
# Runs on: git push
# Purpose: Block pushes that violate branch/scope/gate policy.

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

echo "🚦 Running pre-push standards validation..."

if [ ! -f "./scripts/enforce-professional-standards.sh" ]; then
  echo "⚠️  Skipping: standards validator not found (scripts/enforce-professional-standards.sh)"
  exit 0
fi

bash ./scripts/enforce-professional-standards.sh --source ci --base-ref origin/main --run-gate

echo "✅ Pre-push standards validation passed"
