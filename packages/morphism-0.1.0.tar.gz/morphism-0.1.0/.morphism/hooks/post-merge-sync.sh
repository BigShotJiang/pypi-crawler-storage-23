#!/bin/bash
# Post-merge synchronization hook
# Runs on: git merge, git pull
# Purpose: Keep workspace in sync after merges

set -e

echo "🔄 Running post-merge synchronization..."

# Color codes
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# 1. Update Kiro inventory if changed
if git diff-tree --no-commit-id --name-only -r HEAD | grep -q "\.morphism/inventory/INVENTORY\.md"; then
    echo "${YELLOW}📋 Kiro inventory changed, validating...${NC}"
    if [ -f ".morphism/inventory/INVENTORY.md" ]; then
        ./scripts/validate-inventory.sh --quiet || true
    fi
fi

# 2. Update dependencies if changed
if git diff-tree --no-commit-id --name-only -r HEAD | grep -qE "(package\.json|pnpm-lock\.yaml|Gemfile|poetry\.lock)"; then
    echo "${YELLOW}📦 Dependencies changed, consider updating...${NC}"
    echo "Run: pnpm install (or npm install / bundle install)"
fi

# 3. Check for documentation changes
if git diff-tree --no-commit-id --name-only -r HEAD | grep -qE "\.md$|docs/"; then
    echo "${YELLOW}📖 Documentation changed${NC}"
    if [ -f "scripts/morphism-docs.mjs" ]; then
        echo "Run: node scripts/morphism-docs.mjs validate"
    fi
fi

# 4. Verify no stale worktrees
if [ -d ".worktrees" ]; then
    stale_count=$(find .worktrees -maxdepth 1 -type d -mtime +7 2>/dev/null | wc -l)
    if [ $stale_count -gt 0 ]; then
        echo "${YELLOW}⚠️  Found $stale_count stale worktrees (>7 days old)${NC}"
        echo "Run: ./scripts/worktree-agents.sh prune"
    fi
fi

echo "${GREEN}✅ Post-merge sync complete${NC}"
exit 0
