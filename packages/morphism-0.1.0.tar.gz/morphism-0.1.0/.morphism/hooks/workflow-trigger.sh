#!/bin/bash
# Workflow trigger hook
# Runs on: Custom events
# Purpose: Automatically trigger workflows based on events

set -e

echo "⚙️  Workflow trigger system initializing..."

# Color codes
BLUE='\033[0;34m'
GREEN='\033[0;32m'
NC='\033[0m'

# Trigger registry
declare -A TRIGGERS

# 1. Documentation validation trigger
TRIGGERS["doc-commit"]="
if git diff-tree --no-commit-id --name-only -r HEAD | grep -qE '\.md$|MORPHISM\.md|SSOT\.md'; then
    echo '${BLUE}📖 Documentation changed, running validation workflow...${NC}'
    node scripts/morphism-docs.mjs validate || true
fi
"

# 2. Proof validation trigger
TRIGGERS["proof-commit"]="
if git diff-tree --no-commit-id --name-only -r HEAD | grep -qE 'lab/proofs.*\.lean'; then
    echo '${BLUE}📚 Proofs changed, building...${NC}'
    cd lab && lake build || true
fi
"

# 3. Kiro inventory trigger
TRIGGERS["kiro-commit"]="
if git diff-tree --no-commit-id --name-only -r HEAD | grep -qE '\.morphism/'; then
    echo '${BLUE}📋 Kiro inventory changed, validating...${NC}'
    ./scripts/validate-inventory.sh --quiet || true
fi
"

# Execute triggered workflows
echo "${GREEN}Checking for triggered workflows...${NC}"

# Check each trigger
for trigger_name in "${!TRIGGERS[@]}"; do
    eval "${TRIGGERS[$trigger_name]}"
done

echo "${GREEN}✅ Workflow trigger check complete${NC}"
exit 0
