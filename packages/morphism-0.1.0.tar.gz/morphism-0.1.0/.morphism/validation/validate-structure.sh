#!/bin/bash
# Structure Validation Script
# Validates workspace directory structure

set -e

echo "🔍 Validating Workspace Structure..."
echo ""

ERRORS=0
WARNINGS=0

# Check required top-level directories
echo "Checking top-level directories..."
REQUIRED_DIRS=("morphism" "Products" "Research" "Tools" ".morphism" "docs" "scripts")

for dir in "${REQUIRED_DIRS[@]}"; do
  if [ -d "$dir" ]; then
    echo "  ✓ $dir/ exists"
  else
    echo "  ✗ $dir/ missing"
    ((ERRORS++))
  fi
done

# Check .morphism structure
echo ""
echo "Checking .morphism/ structure..."
MORPHISM_DIRS=("templates" "ide-configs" "reviewers" "validation" "inventory" "schemas" "docs")

for dir in "${MORPHISM_DIRS[@]}"; do
  if [ -d ".morphism/$dir" ]; then
    echo "  ✓ .morphism/$dir/ exists"
  else
    echo "  ✗ .morphism/$dir/ missing"
    ((ERRORS++))
  fi
done

# Check category READMEs
echo ""
echo "Checking category documentation..."
CATEGORY_READMES=("Products/README.md" "Research/README.md" "Tools/README.md")

for readme in "${CATEGORY_READMES[@]}"; do
  if [ -f "$readme" ]; then
    echo "  ✓ $readme exists"
  else
    echo "  ⚠ $readme missing"
    ((WARNINGS++))
  fi
done

# Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Structure Validation Complete"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Errors:   $ERRORS"
echo "Warnings: $WARNINGS"
echo ""

if [ $ERRORS -gt 0 ]; then
  echo "❌ Structure validation FAILED"
  exit 1
elif [ $WARNINGS -gt 0 ]; then
  echo "⚠️  Structure validation PASSED with warnings"
  exit 0
else
  echo "✅ Structure validation PASSED"
  exit 0
fi
