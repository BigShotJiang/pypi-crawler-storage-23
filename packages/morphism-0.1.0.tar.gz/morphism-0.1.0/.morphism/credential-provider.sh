#!/usr/bin/env bash
# =============================================================================
# Morphism Credential Provider
# =============================================================================
# Sources credentials from the vault into the current shell session.
# Designed for IDE tasks, terminal sessions, and local development.
#
# Usage:
#   source .morphism/credential-provider.sh              # Load all
#   source .morphism/credential-provider.sh hub          # Load project-specific
#   source .morphism/credential-provider.sh github       # Load service-specific
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
VAULT_DIR="$ROOT_DIR/.secrets"

if [ ! -d "$VAULT_DIR" ]; then
    echo "Error: Vault not found at $VAULT_DIR" >&2
    return 1 2>/dev/null || exit 1
fi

load_env_file() {
    local file="$1"
    if [ -f "$file" ]; then
        local count=0
        while IFS='=' read -r key value; do
            if [ -n "$key" ] && [ -n "$value" ]; then
                export "$key=$value"
                count=$((count + 1))
            fi
        done < <(grep -v '^\s*#' "$file" | grep -v '^\s*$' | grep '=')
        echo "  Loaded $count keys from $(basename "$file")"
    fi
}

TARGET="${1:-all}"

echo "Loading credentials from vault..."

case "$TARGET" in
    all)
        for f in "$VAULT_DIR"/*.env; do
            if [ -f "$f" ] && [ "$(basename "$f")" != "master.env" ]; then
                load_env_file "$f"
            fi
        done
        ;;
    hub|morphism-hub)
        load_env_file "$VAULT_DIR/morphism-hub-supabase.env"
        load_env_file "$VAULT_DIR/clerk.env"
        load_env_file "$VAULT_DIR/stripe.env"
        load_env_file "$VAULT_DIR/gemini.env"
        ;;
    github)
        load_env_file "$VAULT_DIR/github.env"
        ;;
    supabase)
        load_env_file "$VAULT_DIR/supabase.env"
        load_env_file "$VAULT_DIR/morphism-hub-supabase.env"
        ;;
    clerk)
        load_env_file "$VAULT_DIR/clerk.env"
        ;;
    stripe)
        load_env_file "$VAULT_DIR/stripe.env"
        ;;
    vercel)
        load_env_file "$VAULT_DIR/vercel.env"
        ;;
    *)
        local file="$VAULT_DIR/${TARGET}.env"
        if [ -f "$file" ]; then
            load_env_file "$file"
        else
            echo "Unknown target: $TARGET" >&2
            echo "Available: all, hub, github, supabase, clerk, stripe, vercel" >&2
            return 1 2>/dev/null || exit 1
        fi
        ;;
esac

echo "Done."
