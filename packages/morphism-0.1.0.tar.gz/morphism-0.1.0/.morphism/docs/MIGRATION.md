# Migration Guide: .kiro/ → .morphism/

**Migration Date:** 2026-02-08
**Version:** 1.0.0
**Status:** Complete

## Overview

This document describes the migration from `.kiro/` (Claude Code-specific) to `.morphism/` (universal LLM governance standard).

## Why Migrate?

**Problem:** `.kiro/` branding implied Claude Code exclusivity, limiting adoption.

**Solution:** `.morphism/` provides a universal standard that works across all LLM IDEs:
- Claude Code (Kiro)
- Cursor (Agent mode)
- GitHub Copilot (Workspace)
- Windsurf (Cascade)
- Devin
- Any future LLM IDE

## What Changed

### Directory Rename

```
.kiro/ → .morphism/
```

### Structure Mapping

| Old (.kiro/) | New (.morphism/) | Change Type |
|--------------|------------------|-------------|
| `agents/` | `agents/` | No change |
| `hooks/` | `hooks/` | No change |
| `orchestrations/` | `workflows/orchestrations/` | Nested |
| `powers/` | `extensions/` | ✅ **Renamed** |
| `schemas/` | `schemas/` | No change |
| `workflows/` | `workflows/` | No change |
| `changelogs/` | `changelogs/` | No change |
| `INVENTORY.md` | `inventory/INVENTORY.md` | Moved |
| `MATURITY.md` | `inventory/MATURITY.md` | Moved |
| `dependencies.json` | `inventory/dependencies.json` | Moved |

### Key Renames

1. **powers/ → extensions/** - Clarifies that these are MCP servers/plugins (standard concept), not proprietary "powers"
2. **Inventory files grouped** - `INVENTORY.md`, `MATURITY.md`, `dependencies.json` now in `inventory/` subdirectory
3. **Orchestrations nested** - Now under `workflows/orchestrations/` for logical grouping

## Migration Steps

### Automated Migration

```bash
# 1. Create new structure
mkdir -p .morphism/{agents,workflows/orchestrations,hooks,extensions,schemas,inventory,changelogs,docs}

# 2. Migrate files
cp -r .kiro/agents/*.json .morphism/agents/
cp -r .kiro/hooks/*.sh .morphism/hooks/
cp -r .kiro/hooks/README.md .morphism/hooks/
cp -r .kiro/orchestrations/*.md .morphism/workflows/orchestrations/
cp -r .kiro/powers/*.md .morphism/extensions/  # powers → extensions
cp -r .kiro/schemas/*.json .morphism/schemas/
cp -r .kiro/workflows/*.md .morphism/workflows/
cp -r .kiro/changelogs/*.md .morphism/changelogs/
cp .kiro/INVENTORY.md .morphism/inventory/
cp .kiro/MATURITY.md .morphism/inventory/
cp .kiro/dependencies.json .morphism/inventory/

# 3. Update script paths
find scripts/ -name "*.sh" -exec sed -i 's/\.kiro\//\.morphism\//g' {} \;

# 4. Rename tools
mv scripts/kiro-dashboard.sh scripts/morphism-dashboard.sh

# 5. Update documentation
sed -i 's/\.kiro\//\.morphism\//g' CLAUDE.md
sed -i 's/\.kiro\//\.morphism\//g' AGENTS.md
sed -i 's/\.kiro\//\.morphism\//g' morphism/AGENTS.md

# 6. Validate
./scripts/validate-enhanced.sh
./scripts/validate-versions.sh
./scripts/validate-dependencies.sh

# 7. Remove old directory
rm -rf .kiro/
git rm -r .kiro/
git add .morphism/
git commit -m "refactor: Migrate .kiro → .morphism (universal governance standard)"
```

### Manual Steps Required

1. **Update memory:** Edit `/home/meshal/.claude/projects/-mnt-c-Users-mesha-Desktop-GitHub/memory/MEMORY.md`
   - Replace all `.kiro/` references with `.morphism/`
   - Update "powers" terminology to "extensions"

2. **Update .gitignore:**
   ```
   # Morphism local overrides
   .morphism/settings.local.json
   .morphism/.cache/
   .morphism/logs/
   ```

3. **Update CI/CD:**
   - `.github/workflows/*.yml` - Update paths if they reference `.kiro/`

## Verification Checklist

### File Migration

- [ ] 3 agents migrated (`.morphism/agents/*.json`)
- [ ] 5 hooks migrated (`.morphism/hooks/*.sh`)
- [ ] 3 orchestrations migrated (`.morphism/workflows/orchestrations/*.md`)
- [ ] 2 extensions migrated (`.morphism/extensions/*.md`)
- [ ] 4 schemas migrated (`.morphism/schemas/*.json`)
- [ ] 4 workflows migrated (`.morphism/workflows/*.md`)
- [ ] 21 changelogs migrated (`.morphism/changelogs/*.md`)
- [ ] 3 inventory files migrated (`.morphism/inventory/`)

### Script Updates

- [ ] All scripts updated with `.morphism/` paths
- [ ] `kiro-dashboard.sh` renamed to `morphism-dashboard.sh`
- [ ] No remaining `.kiro/` references in `scripts/`

### Validation

- [ ] `validate-enhanced.sh` passes (0 errors)
- [ ] `validate-versions.sh` passes (0 errors)
- [ ] `validate-dependencies.sh` passes (0 errors)
- [ ] Dashboard launches (`./scripts/morphism-dashboard.sh`)
- [ ] Export works (`./scripts/export-inventory.sh -f json`)
- [ ] Search works (`./scripts/search-components.sh "agent"`)

### Documentation

- [ ] CLAUDE.md updated
- [ ] AGENTS.md updated
- [ ] morphism/AGENTS.md updated
- [ ] MEMORY.md updated
- [ ] .gitignore updated

### Git

- [ ] `.kiro/` directory removed
- [ ] `.morphism/` committed
- [ ] Migration commit pushed

## Rollback Procedure

If issues arise during migration:

```bash
# Restore from backup
rm -rf .morphism
mv .kiro.backup .kiro

# Revert script changes
git checkout -- scripts/

# Revert documentation
git checkout -- CLAUDE.md AGENTS.md morphism/AGENTS.md
```

**Note:** Keep `.kiro.backup/` until migration is verified stable.

## Post-Migration

### Updated Commands

Old:
```bash
./scripts/kiro-dashboard.sh
grep -r "\.kiro" scripts/
```

New:
```bash
./scripts/morphism-dashboard.sh
grep -r "\.morphism" scripts/
```

### Configuration

New configuration file: `.morphism/config.json`

See [README.md](../README.md) for configuration options and discovery algorithm.

## Compatibility

### Cross-IDE Support

The `.morphism/` standard is designed to work across all LLM IDEs:

- **Claude Code:** Auto-discovers via upward search
- **Cursor:** Read via `.cursor/` or manual integration
- **Copilot:** VSCode extension support
- **Windsurf/Devin:** Manual integration via config

See [COMPATIBILITY.md](COMPATIBILITY.md) for IDE-specific integration guides.

## Timeline

**Week 1: Migration (2026-02-03 to 2026-02-07)**
- Day 1-2: Create structure, migrate files
- Day 3-4: Update script paths
- Day 5: Validation and testing

**Week 2: Validation (2026-02-08)**
- Day 1: Final validation passes
- Day 2: Documentation updates
- Day 3: Commit and push

**Status:** ✅ Complete (2026-02-08)

## Support

**Questions?** See:
- [README.md](../README.md) - Quick reference
- [COMPATIBILITY.md](COMPATIBILITY.md) - Cross-IDE guide
- [AGENTS.md](../../AGENTS.md) - Governance rules

**Issues?** Check:
```bash
# Run diagnostics
./scripts/validate-enhanced.sh
./scripts/generate-validation-report.sh

# View component status
./scripts/morphism-dashboard.sh
```
