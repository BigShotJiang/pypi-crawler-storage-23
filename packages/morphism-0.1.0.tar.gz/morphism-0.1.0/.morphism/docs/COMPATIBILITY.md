# Cross-IDE Compatibility Guide

**Version:** 1.0.0
**Last Updated:** 2026-02-08

## Overview

The `.morphism/` standard is designed to work across all LLM IDEs and AI coding assistants. This guide explains how to integrate Morphism governance with different tools.

## Universal Components

These work everywhere without modification:

✅ **Markdown Documentation** - AGENTS.md, README.md, workflow docs
✅ **Shell Scripts** - Validation scripts, hooks (`.sh`)
✅ **JSON Configuration** - config.json, dependencies.json
✅ **JSON Schema** - Validation definitions
✅ **Directory Structure** - `.morphism/` pattern

## IDE-Specific Integration

### Claude Code

**Native Support:** ✅ Full

**Discovery:**
- Recursive upward search from CWD to root
- Checks for `.morphism/` in each parent directory
- Falls back to `~/.config/morphism/` (XDG) or `~/.morphism/` (legacy)

**Configuration:**
```json
// .morphism/config.json
{
  "discovery": {
    "agents": ".morphism/agents/*.json",
    "skills": ".morphism/skills/*/SKILL.md",
    "workflows": ".morphism/workflows/*.md"
  }
}
```

**Usage:**
```bash
# Auto-discovered when running from project root
claude-code

# Or specify explicitly
MORPHISM_CONFIG_DIR=.morphism claude-code
```

**Skills Format:**
- YAML frontmatter + Markdown content
- Auto-loaded from `.morphism/skills/*/SKILL.md`

---

### Cursor

**Native Support:** ⚠️ Partial (requires adapter)

**Discovery:**
- Looks for `.cursor/` in project root
- No upward directory search
- Can read `.cursorrules` (legacy)

**Integration Strategy:**

**Option 1: Symlink (Recommended)**
```bash
ln -s .morphism .cursor
```

**Option 2: Cursor Rules File**
```bash
# .cursorrules
# Include Morphism governance
@include .morphism/inventory/INVENTORY.md
@include AGENTS.md

# Auto-load workflows
@directory .morphism/workflows/
```

**Option 3: Manual Context**
- Add `.morphism/inventory/INVENTORY.md` to Cursor's context
- Reference workflows in chat: "Follow `.morphism/workflows/daily-operations.md`"

**Agent Format:**
- Cursor uses custom agent syntax
- Translate `.morphism/agents/*.json` to Cursor format:

```typescript
// Cursor agent config
{
  "name": "code-reviewer",
  "description": "Reviews code for quality",
  "trigger": "on:commit",
  "actions": ["lint", "test", "review"]
}
```

---

### GitHub Copilot

**Native Support:** ⚠️ Limited

**Discovery:**
- Looks for `.github/copilot.yaml` in project root
- No upward search
- No auto-discovery of custom directories

**Integration Strategy:**

**Option 1: Copilot Configuration**
```yaml
# .github/copilot.yaml
context:
  - .morphism/inventory/INVENTORY.md
  - AGENTS.md
  - MORPHISM.md

workflows:
  - .morphism/workflows/*.md

validation:
  pre-commit:
    - ./scripts/validate-enhanced.sh
```

**Option 2: VSCode Extension**
- Create VSCode extension to read `.morphism/`
- Inject context into Copilot requests
- Trigger workflows via commands

**Option 3: GitHub Actions**
```yaml
# .github/workflows/morphism-validation.yml
name: Morphism Governance
on: [push, pull_request]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Run Morphism validation
        run: ./scripts/validate-enhanced.sh
```

---

### Windsurf (Cascade)

**Native Support:** 🔄 Unknown (new tool)

**Assumed Discovery:**
- Similar to Cursor (project root only)
- May support custom config paths

**Integration Strategy:**

**Option 1: Configuration File**
```json
// .windsurf/config.json
{
  "governance": ".morphism/",
  "workflows": ".morphism/workflows/",
  "validation": "./scripts/validate-enhanced.sh"
}
```

**Option 2: Symlink**
```bash
ln -s .morphism .windsurf
```

**Option 3: Environment Variable**
```bash
export WINDSURF_CONFIG_DIR=.morphism
windsurf
```

---

### Devin

**Native Support:** 🔄 Unknown (new tool)

**Assumed Discovery:**
- Likely project root only
- May support environment variables

**Integration Strategy:**

**Option 1: Explicit Context**
```bash
devin --context .morphism/inventory/INVENTORY.md \
      --governance AGENTS.md \
      --validation ./scripts/validate-enhanced.sh
```

**Option 2: Configuration File**
```json
// .devin/config.json
{
  "morphism": {
    "enabled": true,
    "configPath": ".morphism/config.json",
    "autoValidate": true
  }
}
```

---

## Discovery Algorithm Comparison

| IDE | Upward Search | XDG Support | Env Var | Config File |
|-----|---------------|-------------|---------|-------------|
| **Claude Code** | ✅ Yes | ✅ Yes | ✅ Yes | ✅ Yes |
| **Cursor** | ❌ No | ❌ No | ⚠️ Unknown | ✅ Yes |
| **Copilot** | ❌ No | ❌ No | ❌ No | ✅ Yes |
| **Windsurf** | 🔄 Unknown | 🔄 Unknown | 🔄 Unknown | 🔄 Unknown |
| **Devin** | 🔄 Unknown | 🔄 Unknown | 🔄 Unknown | 🔄 Unknown |

**Legend:**
- ✅ Supported
- ❌ Not supported
- ⚠️ Partial support
- 🔄 Unknown (tool-specific research needed)

---

## Configuration Hierarchy

All tools should respect this priority order:

1. **Environment Variables** - `MORPHISM_CONFIG_DIR`
2. **Local Config** - `.morphism/settings.local.json` (gitignored)
3. **Project Config** - `.morphism/config.json` (committed)
4. **Global Config** - `~/.config/morphism/` (XDG) or `~/.morphism/` (legacy)
5. **Built-in Defaults** - Hardcoded fallbacks

---

## File Format Standards

### Universal Formats (Work Everywhere)

| Format | Use Case | Tools |
|--------|----------|-------|
| **Markdown (.md)** | Documentation, workflows | All |
| **JSON (.json)** | Configuration, schemas | All |
| **YAML (.yaml)** | Workflows, orchestrations | Most |
| **Shell (.sh)** | Validation, hooks | Unix-based |

### Tool-Specific Formats

| Tool | Agent Format | Skill Format | Workflow Format |
|------|--------------|--------------|-----------------|
| **Claude Code** | JSON | YAML+MD | Markdown |
| **Cursor** | TypeScript | Markdown | Custom |
| **Copilot** | YAML | N/A | GitHub Actions |
| **Windsurf** | Unknown | Unknown | Unknown |
| **Devin** | Unknown | Unknown | Unknown |

---

## Adapter Patterns

### JSON to YAML Converter

For tools that prefer YAML:

```bash
# Convert agent JSON to YAML
cat .morphism/agents/code-reviewer.json | yq -P > .cursor/agents/code-reviewer.yaml
```

### Workflow Translator

For tools with custom workflow syntax:

```python
# translate-workflow.py
import json
import yaml

def morphism_to_cursor(morphism_workflow):
    """Convert Morphism workflow to Cursor format"""
    return {
        "name": morphism_workflow["name"],
        "steps": morphism_workflow["steps"],
        "trigger": morphism_workflow.get("trigger", "manual")
    }

# Usage
with open(".morphism/workflows/daily-operations.md") as f:
    workflow = parse_morphism_workflow(f.read())
    cursor_workflow = morphism_to_cursor(workflow)

with open(".cursor/workflows/daily-operations.yaml", "w") as f:
    yaml.dump(cursor_workflow, f)
```

---

## Environment Variable Support

All tools should support these environment variables:

```bash
# Primary config directory
export MORPHISM_CONFIG_DIR=.morphism

# Global config (XDG-compliant)
export XDG_CONFIG_HOME=~/.config

# Tool-specific overrides
export CLAUDE_MORPHISM_CONFIG=.morphism/config.json
export CURSOR_MORPHISM_CONFIG=.morphism/config.json
export COPILOT_MORPHISM_CONFIG=.morphism/config.json
```

---

## Testing Compatibility

### Verification Script

```bash
#!/bin/bash
# test-ide-compatibility.sh

echo "Testing Morphism compatibility..."

# Check directory exists
if [ ! -d ".morphism" ]; then
  echo "❌ .morphism/ directory not found"
  exit 1
fi

# Check config
if [ ! -f ".morphism/config.json" ]; then
  echo "❌ config.json not found"
  exit 1
fi

# Check components
for dir in agents workflows hooks extensions schemas inventory; do
  if [ ! -d ".morphism/$dir" ]; then
    echo "❌ Missing directory: $dir"
    exit 1
  fi
done

# Validate JSON
jq empty .morphism/config.json 2>/dev/null
if [ $? -ne 0 ]; then
  echo "❌ Invalid JSON in config.json"
  exit 1
fi

echo "✅ Morphism structure valid"

# Test each IDE
for ide in claude cursor copilot windsurf devin; do
  echo -n "Testing $ide... "
  if command -v $ide &> /dev/null; then
    echo "✅ Installed"
  else
    echo "⚠️ Not installed"
  fi
done
```

---

## Certification

### Morphism v1.0 Compliant

Tools can be certified as "Morphism v1.0 Compliant" if they:

1. ✅ Discover `.morphism/` directory (upward search or env var)
2. ✅ Parse `.morphism/config.json`
3. ✅ Load components from standard locations
4. ✅ Respect configuration hierarchy
5. ✅ Support validation scripts
6. ✅ Provide adapter for tool-specific formats

**Badge:**
```markdown
![Morphism v1.0 Compliant](https://img.shields.io/badge/Morphism-v1.0-blue)
```

---

## Future Enhancements

### Planned Improvements

1. **Universal Adapter Layer** - Automatic format translation
2. **MCP Server** - Morphism as Model Context Protocol server
3. **CLI Tool** - `morphism init`, `morphism validate`, `morphism export`
4. **IDE Extensions** - Native plugins for each IDE
5. **Registry** - Central registry of Morphism-compliant tools

---

## Support Matrix

| Feature | Claude | Cursor | Copilot | Windsurf | Devin |
|---------|--------|--------|---------|----------|-------|
| Auto-discovery | ✅ | ❌ | ❌ | 🔄 | 🔄 |
| Agent loading | ✅ | ⚠️ | ❌ | 🔄 | 🔄 |
| Workflow execution | ✅ | ⚠️ | ⚠️ | 🔄 | 🔄 |
| Hook triggering | ✅ | ❌ | ⚠️ | 🔄 | 🔄 |
| Validation | ✅ | ✅ | ✅ | 🔄 | 🔄 |
| Documentation | ✅ | ✅ | ✅ | ✅ | ✅ |

**Legend:**
- ✅ Full support
- ⚠️ Partial support (requires adapter)
- ❌ No support
- 🔄 Unknown (needs testing)

---

## Contributing

Help improve cross-IDE compatibility:

1. Test `.morphism/` with your IDE
2. Report findings in `COMPATIBILITY.md`
3. Create adapters for unsupported IDEs
4. Submit integration guides

**Resources:**
- [Morphism Standard Spec](https://github.com/morphism-labs/standard)
- [Adapter Examples](https://github.com/morphism-labs/adapters)
- [Integration Tests](https://github.com/morphism-labs/integration-tests)
