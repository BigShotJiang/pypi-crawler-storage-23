# Morphism Template Inventory

**Version:** 1.0.0
**Last Updated:** 2026-02-11

---

## 📋 Overview

This directory contains comprehensive templates for creating new projects, documentation, configurations, and workflows following Morphism principles and best practices.

**Philosophy:** Every project should look like its stack/category, with consistent structure, documentation, and tooling.

---

## 🏗️ Directory Structure

```
.morphism/templates/
├── projects/          # Project templates by type
│   ├── product-web/           # Web application product
│   ├── product-cli/           # CLI application product
│   ├── research-math/         # Mathematical research
│   ├── research-experimental/ # Experimental research
│   ├── tool-cli/              # CLI utility tool
│   └── tool-library/          # Library/package tool
│
├── docs/              # Documentation templates
│   ├── ARCHITECTURE.template.md
│   ├── API.template.md
│   ├── DEPLOYMENT.template.md
│   ├── DEVELOPMENT.template.md
│   └── SECURITY.template.md
│
├── configs/           # Configuration templates
│   ├── typescript/    # TypeScript configs
│   ├── python/        # Python configs
│   ├── lean/          # Lean 4 configs
│   └── common/        # Common configs
│
└── workflows/         # GitHub Actions workflows
    ├── ci.template.yml
    ├── deploy.template.yml
    └── test.template.yml
```

---

## 🎯 Template Categories

### 1. Project Templates

#### Product Templates
- **product-web** - Web applications (Next.js, React, Vue, etc.)
- **product-cli** - CLI applications with user interfaces

**Use When:** Building production-ready software for end users

#### Research Templates
- **research-math** - Mathematical/theoretical research with proofs
- **research-experimental** - Experimental/exploratory research

**Use When:** Conducting research, formalization, or experimentation

#### Tool Templates
- **tool-cli** - Command-line utilities
- **tool-library** - Libraries and packages

**Use When:** Creating developer tooling or reusable components

---

### 2. Documentation Templates

| Template | Purpose | Use For |
|----------|---------|---------|
| **ARCHITECTURE.md** | System architecture | All projects |
| **API.md** | API reference | APIs, libraries |
| **DEPLOYMENT.md** | Deployment guide | Products, services |
| **DEVELOPMENT.md** | Development setup | All projects |
| **SECURITY.md** | Security policy | All projects |

---

### 3. Configuration Templates

| Language | Includes |
|----------|----------|
| **TypeScript** | tsconfig.json, eslint, prettier |
| **Python** | pyproject.toml, ruff, mypy |
| **Lean** | lakefile.lean, toolchain |
| **Common** | .gitignore, .editorconfig, etc. |

---

### 4. Workflow Templates

| Template | Purpose |
|----------|---------|
| **ci.yml** | Continuous integration |
| **deploy.yml** | Deployment automation |
| **test.yml** | Test automation |

---

## 🚀 Using Templates

### Method 1: Manual Application

1. **Choose Template:**
   ```bash
   cd .morphism/templates/projects/
   ls  # Browse available templates
   ```

2. **Copy Structure:**
   ```bash
   # Example: Create new web product
   cp -r product-web/ ../../../_projects/Products/my-new-app/
   cd ../../../_projects/Products/my-new-app/
   ```

3. **Replace Variables:**

   Find and replace all `{{VARIABLE}}` placeholders:

   ```bash
   # Manual replacement
   # Replace {{PROJECT_NAME}} with actual project name
   # Replace {{DESCRIPTION}} with project description
   # etc.
   ```

4. **Customize:**
   - Remove sections you don't need
   - Add project-specific content
   - Adjust structure as needed

### Method 2: Using Template Tool (TODO)

```bash
# Future: Automated template application
morphism template apply product-web \
  --name my-app \
  --stack nextjs \
  --output _projects/Products/
```

---

## 📐 Template Variable Reference

### Common Variables

All templates support these variables:

| Variable | Description | Example |
|----------|-------------|---------|
| `{{PROJECT_NAME}}` | Project name | `morphism-web` |
| `{{DESCRIPTION}}` | Short description | `Web dashboard for...` |
| `{{STATUS}}` | Project status | `Development`, `Production` |
| `{{LICENSE}}` | License type | `MIT`, `Apache-2.0` |
| `{{MAINTAINER}}` | Maintainer name/team | `Morphism Team` |
| `{{LAST_UPDATED}}` | Last update date | `2026-02-11` |

### Stack-Specific Variables

#### Web Projects
| Variable | Description | Example |
|----------|-------------|---------|
| `{{FRONTEND_FRAMEWORK}}` | Frontend framework | `Next.js 14`, `React 18` |
| `{{STYLING_SOLUTION}}` | CSS solution | `Tailwind CSS`, `CSS Modules` |
| `{{STATE_MANAGEMENT}}` | State library | `Zustand`, `Redux` |
| `{{BACKEND_SOLUTION}}` | Backend type | `Supabase`, `API Routes` |
| `{{DATABASE}}` | Database | `PostgreSQL`, `MongoDB` |
| `{{AUTH_SOLUTION}}` | Auth provider | `Clerk`, `Auth.js` |

#### CLI Projects
| Variable | Description | Example |
|----------|-------------|---------|
| `{{LANGUAGE}}` | Programming language | `TypeScript`, `Python` |
| `{{CLI_COMMAND}}` | Command name | `morphism`, `my-tool` |
| `{{CONFIG_PATH}}` | Config file location | `~/.myapp/config.json` |

#### Research Projects
| Variable | Description | Example |
|----------|-------------|---------|
| `{{DOMAIN}}` | Research domain | `Category Theory`, `Topology` |
| `{{PROOF_ASSISTANT}}` | Proof assistant | `Lean 4`, `Coq` |
| `{{MATHLIB}}` | Math library | `Mathlib4`, `stdmath` |

---

## 🎨 Customization Guidelines

### When to Modify Templates

✅ **DO modify:**
- Project-specific sections
- Variable values
- Optional sections

❌ **DON'T modify:**
- Core structure (without good reason)
- Required sections (Architecture, Security, etc.)
- Morphism governance references

### Adding Custom Sections

Place custom sections at the end, before the footer:

```markdown
---

## 🔧 Custom Section

Your custom content here...

---

**Maintained by:** {{MAINTAINER}}
```

---

## 🔄 Template Maintenance

### Versioning

Templates follow semantic versioning:
- **Major (x.0.0):** Breaking structure changes
- **Minor (1.x.0):** New templates or sections
- **Patch (1.0.x):** Fixes and improvements

### Updating Projects

When templates are updated:

1. Check [CHANGELOG.md](./CHANGELOG.md)
2. Review changes
3. Selectively apply updates to existing projects
4. Don't blindly overwrite - merge carefully

---

## 📊 Template Catalog

### Available Templates

| Type | Category | Stack | Status |
|------|----------|-------|--------|
| Project | Product | Web | ✅ Ready |
| Project | Product | CLI | 🚧 In Progress |
| Project | Research | Math | ✅ Ready |
| Project | Research | Experimental | 🚧 In Progress |
| Project | Tool | CLI | ✅ Ready |
| Project | Tool | Library | 🚧 In Progress |
| Docs | All | Architecture | ✅ Ready |
| Docs | All | API | 🚧 In Progress |
| Docs | All | Deployment | 🚧 In Progress |
| Docs | All | Development | 🚧 In Progress |
| Docs | All | Security | 🚧 In Progress |

**Legend:**
- ✅ Ready - Complete and tested
- 🚧 In Progress - Under development
- 📋 Planned - On roadmap

---

## 🤝 Contributing

### Adding New Templates

1. Create template directory
2. Add all necessary files
3. Use `{{VARIABLE}}` syntax for placeholders
4. Document all variables
5. Add to catalog above
6. Submit PR

### Improving Existing Templates

1. Identify improvement
2. Test changes
3. Update documentation
4. Update version number
5. Add to CHANGELOG
6. Submit PR

---

## 📚 References

### Internal
- [Morphism Framework](../../../morphism/MORPHISM.md)
- [Governance](../../../morphism/AGENTS.md)
- [SSOT](../../../morphism/SSOT.md)

### External
- [Morphism Website](https://morphism.systems)
- [Documentation](https://docs.morphism.systems)

---

## 🎯 Next Steps

1. ✅ Create core project templates (DONE)
2. 🚧 Create documentation templates (IN PROGRESS)
3. 📋 Create configuration templates
4. 📋 Create workflow templates
5. 📋 Build template application tool
6. 📋 Write comprehensive usage guide

---

**Template System Version:** 1.0.0
**Maintained by:** Morphism Team
**Last Updated:** 2026-02-11
