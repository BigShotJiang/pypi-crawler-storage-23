# {{PROJECT_NAME}}

**Category:** Product (Web Application)
**Stack:** {{STACK}} (e.g., Next.js, React + Vite, etc.)
**Status:** {{STATUS}} (e.g., Development, Production, Archived)

---

## 📋 Overview

{{DESCRIPTION}}

---

## 🚀 Quick Start

### Prerequisites

```bash
# Required
node >= {{NODE_VERSION}}
{{PACKAGE_MANAGER}} >= {{PACKAGE_MANAGER_VERSION}}

# Optional
{{OPTIONAL_DEPENDENCIES}}
```

### Installation

```bash
# Clone and install
git clone {{REPO_URL}}
cd {{PROJECT_NAME}}
{{PACKAGE_MANAGER}} install

# Environment setup
cp .env.example .env.local
# Edit .env.local with your values
```

### Development

```bash
{{PACKAGE_MANAGER}} dev
```

Open [http://localhost:{{PORT}}](http://localhost:{{PORT}})

### Build

```bash
{{PACKAGE_MANAGER}} build
{{PACKAGE_MANAGER}} start  # Preview production build
```

---

## 🏗️ Architecture

### Stack

| Layer | Technology |
|-------|-----------|
| **Frontend** | {{FRONTEND_FRAMEWORK}} |
| **Styling** | {{STYLING_SOLUTION}} |
| **State** | {{STATE_MANAGEMENT}} |
| **Backend** | {{BACKEND_SOLUTION}} |
| **Database** | {{DATABASE}} |
| **Auth** | {{AUTH_SOLUTION}} |
| **Deployment** | {{DEPLOYMENT_PLATFORM}} |

### Project Structure

```
{{PROJECT_NAME}}/
├── src/
│   ├── components/     # React components
│   ├── pages/          # Page components
│   ├── lib/            # Utilities and helpers
│   ├── hooks/          # Custom React hooks
│   ├── styles/         # Global styles
│   └── types/          # TypeScript types
├── public/             # Static assets
├── tests/              # Test suites
├── docs/               # Documentation
└── config/             # Configuration files
```

---

## 🧪 Testing

```bash
# Unit tests
{{PACKAGE_MANAGER}} test

# E2E tests
{{PACKAGE_MANAGER}} test:e2e

# Coverage
{{PACKAGE_MANAGER}} test:coverage
```

---

## 🚢 Deployment

### Vercel (Recommended)

```bash
vercel --prod
```

### Manual

```bash
{{PACKAGE_MANAGER}} build
# Deploy dist/ directory to your hosting
```

### Environment Variables

Required variables (see `.env.example`):

```env
{{REQUIRED_ENV_VARS}}
```

---

## 📚 Documentation

- [Architecture](./docs/ARCHITECTURE.md)
- [API Reference](./docs/API.md)
- [Deployment Guide](./docs/DEPLOYMENT.md)
- [Development Guide](./docs/DEVELOPMENT.md)

---

## 🔒 Security

- All secrets in `.env` (never commit!)
- API keys managed via environment variables
- See [Security Policy](./SECURITY.md)

---

## 📄 License

{{LICENSE}}

---

## 🤝 Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md)

---

**Maintained by:** {{MAINTAINER}}
**Last Updated:** {{LAST_UPDATED}}
