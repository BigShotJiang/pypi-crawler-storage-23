# {{PROJECT_NAME}}

**Category:** Tool (CLI)
**Language:** {{LANGUAGE}} (e.g., TypeScript, Python, Rust)
**Status:** {{STATUS}}

---

## 📋 Overview

{{DESCRIPTION}}

### Features

- {{FEATURE_1}}
- {{FEATURE_2}}
- {{FEATURE_3}}

---

## 🚀 Installation

### Via Package Manager

```bash
# npm
npm install -g {{PACKAGE_NAME}}

# yarn
yarn global add {{PACKAGE_NAME}}

# pnpm
pnpm add -g {{PACKAGE_NAME}}
```

### From Source

```bash
git clone {{REPO_URL}}
cd {{PROJECT_NAME}}
{{PACKAGE_MANAGER}} install
{{PACKAGE_MANAGER}} build
{{PACKAGE_MANAGER}} link  # or npm link
```

---

## 💻 Usage

### Basic Usage

```bash
{{CLI_COMMAND}} [options] [arguments]
```

### Common Commands

```bash
# Example command 1
{{CLI_COMMAND}} {{COMMAND_1}} {{ARGS_1}}

# Example command 2
{{CLI_COMMAND}} {{COMMAND_2}} {{ARGS_2}}

# Help
{{CLI_COMMAND}} --help
```

### Examples

```bash
# Example 1: {{EXAMPLE_1_DESCRIPTION}}
{{EXAMPLE_1_COMMAND}}

# Example 2: {{EXAMPLE_2_DESCRIPTION}}
{{EXAMPLE_2_COMMAND}}

# Example 3: {{EXAMPLE_3_DESCRIPTION}}
{{EXAMPLE_3_COMMAND}}
```

---

## ⚙️ Configuration

### Config File

Location: `{{CONFIG_PATH}}`

```{{CONFIG_FORMAT}}
{{CONFIG_EXAMPLE}}
```

### Environment Variables

```bash
{{ENV_VAR_1}}={{ENV_VAR_1_DEFAULT}}  # {{ENV_VAR_1_DESCRIPTION}}
{{ENV_VAR_2}}={{ENV_VAR_2_DEFAULT}}  # {{ENV_VAR_2_DESCRIPTION}}
```

---

## 🏗️ Project Structure

```
{{PROJECT_NAME}}/
├── src/
│   ├── commands/       # CLI commands
│   ├── lib/            # Core logic
│   ├── utils/          # Utilities
│   └── types/          # TypeScript types
├── tests/              # Test suites
├── bin/                # CLI entry point
├── docs/               # Documentation
└── examples/           # Usage examples
```

---

## 🧪 Development

### Setup

```bash
{{PACKAGE_MANAGER}} install
{{PACKAGE_MANAGER}} build
```

### Testing

```bash
# Run tests
{{PACKAGE_MANAGER}} test

# Watch mode
{{PACKAGE_MANAGER}} test:watch

# Coverage
{{PACKAGE_MANAGER}} test:coverage
```

### Development Mode

```bash
# Build and watch
{{PACKAGE_MANAGER}} dev

# Test CLI locally
{{PACKAGE_MANAGER}} start {{ARGS}}
# or
node dist/index.js {{ARGS}}
```

---

## 📚 Documentation

- [API Reference](./docs/API.md)
- [Commands](./docs/COMMANDS.md)
- [Configuration](./docs/CONFIGURATION.md)
- [Development](./docs/DEVELOPMENT.md)

---

## 🔧 Troubleshooting

### Common Issues

**Issue 1:** {{ISSUE_1_DESCRIPTION}}
```bash
# Solution
{{ISSUE_1_SOLUTION}}
```

**Issue 2:** {{ISSUE_2_DESCRIPTION}}
```bash
# Solution
{{ISSUE_2_SOLUTION}}
```

---

## 📄 License

{{LICENSE}}

---

## 🤝 Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md)

---

**Maintained by:** {{MAINTAINER}}
**Version:** {{VERSION}}
**Last Updated:** {{LAST_UPDATED}}
