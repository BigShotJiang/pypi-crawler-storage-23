# {{PROJECT_NAME}}

**Category:** Research (Mathematical/Theoretical)
**Language:** {{LANGUAGE}} (e.g., Lean 4, Python + SymPy, Coq)
**Domain:** {{DOMAIN}} (e.g., Category Theory, Topology, Algebra)
**Status:** {{STATUS}}

---

## 📋 Overview

{{DESCRIPTION}}

### Research Questions

1. {{RESEARCH_QUESTION_1}}
2. {{RESEARCH_QUESTION_2}}
3. {{RESEARCH_QUESTION_3}}

### Contributions

- {{CONTRIBUTION_1}}
- {{CONTRIBUTION_2}}
- {{CONTRIBUTION_3}}

---

## 📐 Mathematical Background

### Prerequisites

Required mathematical background:

- {{PREREQ_1}}
- {{PREREQ_2}}
- {{PREREQ_3}}

### Key Concepts

**{{CONCEPT_1}}**
{{CONCEPT_1_DESCRIPTION}}

**{{CONCEPT_2}}**
{{CONCEPT_2_DESCRIPTION}}

**{{CONCEPT_3}}**
{{CONCEPT_3_DESCRIPTION}}

---

## 🔬 Formalization

### Proof Assistant

**{{PROOF_ASSISTANT}}** version {{VERSION}}

### Core Definitions

```{{LANGUAGE}}
{{CORE_DEFINITIONS}}
```

### Main Theorems

#### Theorem 1: {{THEOREM_1_NAME}}

**Statement:**
```{{LANGUAGE}}
{{THEOREM_1_STATEMENT}}
```

**Status:** {{THEOREM_1_STATUS}} (e.g., Proved, Sorry'd, In Progress)

**Proof Strategy:**
{{THEOREM_1_STRATEGY}}

#### Theorem 2: {{THEOREM_2_NAME}}

**Statement:**
```{{LANGUAGE}}
{{THEOREM_2_STATEMENT}}
```

**Status:** {{THEOREM_2_STATUS}}

---

## 🏗️ Project Structure

```
{{PROJECT_NAME}}/
├── src/                        # Core formalization
│   ├── Definitions.{{EXT}}     # Type definitions
│   ├── Theorems.{{EXT}}        # Main theorems
│   ├── Proofs.{{EXT}}          # Proof implementations
│   └── Examples.{{EXT}}        # Usage examples
├── theory/                     # Theoretical documentation
│   ├── background.md           # Mathematical background
│   ├── proofs.md               # Proof sketches
│   └── references.md           # Citations
├── examples/                   # Computational examples
├── tests/                      # Property tests
└── docs/                       # Documentation
```

---

## 🚀 Setup

### Prerequisites

```bash
{{PROOF_ASSISTANT}} --version  # Should be >= {{VERSION}}
```

### Installation

```bash
# Clone
git clone {{REPO_URL}}
cd {{PROJECT_NAME}}

# Build
{{BUILD_COMMAND}}
```

---

## 🧪 Verification

### Check All Proofs

```bash
{{VERIFY_COMMAND}}
```

### Interactive Development

```bash
{{INTERACTIVE_COMMAND}}
```

### Build Documentation

```bash
{{DOC_COMMAND}}
```

---

## 📊 Progress

### Proof Status

| Theorem | Statement | Proof | Tests |
|---------|-----------|-------|-------|
| {{THEOREM_1_NAME}} | ✅ | {{THEOREM_1_PROOF_STATUS}} | {{THEOREM_1_TEST_STATUS}} |
| {{THEOREM_2_NAME}} | ✅ | {{THEOREM_2_PROOF_STATUS}} | {{THEOREM_2_TEST_STATUS}} |
| {{THEOREM_3_NAME}} | ✅ | {{THEOREM_3_PROOF_STATUS}} | {{THEOREM_3_TEST_STATUS}} |

**Legend:**
- ✅ Complete
- 🚧 In Progress
- ❌ Not Started
- ⚠️ Sorry'd (needs proof)

---

## 📚 References

### Papers

1. {{PAPER_1}}
2. {{PAPER_2}}
3. {{PAPER_3}}

### Books

1. {{BOOK_1}}
2. {{BOOK_2}}

### Related Work

1. {{RELATED_WORK_1}}
2. {{RELATED_WORK_2}}

---

## 🔗 Dependencies

### Mathematical Libraries

- {{MATHLIB_1}} - {{MATHLIB_1_PURPOSE}}
- {{MATHLIB_2}} - {{MATHLIB_2_PURPOSE}}

### Toolchain

```
{{TOOLCHAIN_INFO}}
```

---

## 🤝 Contributing

### Adding Proofs

1. Add theorem statement to `src/Theorems.{{EXT}}`
2. Implement proof in `src/Proofs.{{EXT}}`
3. Add tests in `tests/`
4. Update progress table
5. Submit PR

See [CONTRIBUTING.md](./CONTRIBUTING.md) for details.

---

## 📄 License

{{LICENSE}}

---

**Authors:** {{AUTHORS}}
**Institution:** {{INSTITUTION}}
**Last Updated:** {{LAST_UPDATED}}
