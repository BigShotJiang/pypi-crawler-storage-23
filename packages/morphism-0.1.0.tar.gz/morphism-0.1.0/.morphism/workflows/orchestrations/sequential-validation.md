---
name: Sequential Validation Orchestration
description: Chain validators in sequence where each validates output of previous agent
type: sequential
version: 1.0.0
status: ✅ Active
owner: Quality Assurance
---

# Sequential Validation Orchestration Pattern

Chain multiple validation agents in sequence where each agent validates the output of the previous one, providing layered quality assurance.

## Pattern Overview

```
Input
  ↓
┌─────────────────────┐
│ Validator 1: Syntax │ (Fast - basic structure)
│ (1-2 min)          │
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│ Validator 2: Logic  │ (Medium - business rules)
│ (2-5 min)          │
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│ Validator 3: Style  │ (Fast - standards)
│ (1-3 min)          │
└──────────┬──────────┘
           ↓
┌─────────────────────┐
│ Validator 4: Security│ (Slow - deep analysis)
│ (5-10 min)         │
└──────────┬──────────┘
           ↓
Report (Pass/Fail)
```

## Coordination Rules

### 1. Sequential Execution

**Requirement:** No validator starts until previous completes.

```bash
# Timeline
00:00 - Validator 1 starts (syntax check)
00:02 - Validator 1 done, Validator 2 starts (logic check)
00:07 - Validator 2 done, Validator 3 starts (style check)
00:10 - Validator 3 done, Validator 4 starts (security check)
00:20 - All validation complete
```

### 2. Fail-Fast Option

**Requirement:** Stop on first failure (optional).

```bash
# With fail-fast (recommended):
Syntax fails → Stop, report error
→ Don't run logic/style/security checks (waste of resources)

# Without fail-fast:
Syntax fails → Continue anyway
→ Run all validators, report all issues at once
```

### 3. Output Forwarding

**Requirement:** Each validator consumes output of previous.

```bash
Validator 1 output: {status: "pass", artifact: "code.ast"}
  ↓ Pass to Validator 2
Validator 2 input: {artifact: "code.ast"}
Validator 2 output: {status: "pass", issues: [...]}
  ↓ Pass to Validator 3
Validator 3 input: {issues: [...]}
  ↓ Continue...
```

## Execution Workflow

### Setup Phase

```bash
# Define validation pipeline
validators=(
  "syntax-validator"
  "logic-validator"
  "style-validator"
  "security-validator"
)

# Target artifact
artifact="./src/app.ts"

# Start validation
./run-sequential-validation.sh "${validators[@]}" "$artifact"
```

### Syntax Validation (1-2 minutes)

```bash
# Run: syntax-validator
# Input: code file
# Checks:
#   - Valid syntax for language
#   - No parse errors
#   - Valid file structure
#   - Required imports/declarations

# Output
{
  "status": "pass",
  "time_ms": 1200,
  "artifact": {
    "type": "ast",
    "location": "/tmp/ast.json"
  }
}
```

**Fail scenarios:**
- Syntax error (missing bracket, invalid import, etc.)
- File not found
- Unsupported file type

**Pass → Continue to logic validation**
**Fail → Stop (or continue based on fail-fast setting)**

### Logic Validation (2-5 minutes)

```bash
# Run: logic-validator
# Input: artifact from syntax validator
# Checks:
#   - Business logic correctness
#   - Proper control flow
#   - Valid state transitions
#   - API contract compliance
#   - Data type correctness

# Output
{
  "status": "pass",
  "time_ms": 3500,
  "issues": [],
  "artifact": {
    "type": "issues_list",
    "location": "/tmp/issues.json"
  }
}
```

**Fail scenarios:**
- Logic error (invalid control flow)
- Data type mismatch
- Contract violation
- State machine error

### Style Validation (1-3 minutes)

```bash
# Run: style-validator
# Input: code file + previous issues
# Checks:
#   - Code style compliance
#   - Naming conventions
#   - Documentation completeness
#   - Formatting standards
#   - Comment clarity

# Output
{
  "status": "pass",
  "time_ms": 2100,
  "warnings": [],
  "artifact": {
    "type": "report",
    "location": "/tmp/style_report.md"
  }
}
```

**Fail scenarios:**
- Style violations (severity-dependent)
- Missing documentation
- Naming convention breach
- Poor formatting

### Security Validation (5-10 minutes)

```bash
# Run: security-validator
# Input: code file + previous issues
# Checks:
#   - OWASP vulnerabilities
#   - Input validation
#   - Data exposure risks
#   - Authentication/authorization
#   - Cryptography misuse
#   - Dependency vulnerabilities

# Output
{
  "status": "pass",
  "time_ms": 8000,
  "vulnerabilities": [],
  "artifact": {
    "type": "security_report",
    "location": "/tmp/security_report.md"
  }
}
```

**Fail scenarios:**
- Critical vulnerability found
- SQL injection risk
- XSS vulnerability
- Missing authentication
- Weak cryptography

## Decision Points

### After Syntax Validation

```
Syntax Valid?
├─ YES → Proceed to Logic
└─ NO → Stop (unless continue-on-error)
```

### After Logic Validation

```
Logic Valid?
├─ YES → Proceed to Style
├─ WARNINGS → Proceed (fix later)
└─ ERRORS → Stop (or continue)
```

### After Style Validation

```
Style Compliant?
├─ YES → Proceed to Security
├─ WARNINGS → Proceed (non-blocking)
└─ ERRORS → Stop (or continue)
```

### After Security Validation

```
Security Valid?
├─ CRITICAL FOUND → FAIL (block merge)
├─ HIGH FOUND → Review required
├─ MEDIUM FOUND → Log for improvement
└─ NONE FOUND → PASS (allow merge)
```

## Configuration

### Fail-Fast Mode

```bash
# Stop on first error
./run-sequential-validation.sh --fail-fast "${validators[@]}" "$artifact"
# Faster feedback, saves resources

# Continue on errors
./run-sequential-validation.sh --no-fail-fast "${validators[@]}" "$artifact"
# Complete report, slower
```

### Severity Thresholds

```bash
# Fail if any error found
--min-severity=error

# Warn on warnings and above
--min-severity=warning

# Info level (report everything)
--min-severity=info
```

### Timeout per Validator

```bash
# Syntax: 5 seconds
# Logic: 30 seconds
# Style: 15 seconds
# Security: 60 seconds (can be slow)
```

## Monitoring & Reporting

### Real-time Progress

```bash
$ ./run-sequential-validation.sh "${validators[@]}" src/app.ts

[00:00] Starting validation of src/app.ts
[00:01] ✅ Syntax validation: PASSED (1 sec)
[00:05] ✅ Logic validation: PASSED (4 sec)
[00:07] ✅ Style validation: PASSED (2 sec)
[00:20] ⚠️  Security validation: FOUND 1 MEDIUM issue (13 sec)

Final Report:
✅ Overall: PASSED (with warnings)
📊 Syntax: PASS
📊 Logic: PASS
📊 Style: PASS
⚠️  Security: 1 MEDIUM (CWE-89: Possible SQL injection)

Recommendations:
- Parameterize database queries
- Use ORM instead of raw SQL
```

### Output Files

```
validation-report-2026-02-07T14:35:42Z/
├── summary.json           # High-level results
├── syntax-report.json     # Detailed syntax results
├── logic-report.json      # Logic validation details
├── style-report.md        # Style violations
├── security-report.md     # Security findings
└── recommendations.md     # Action items
```

## Integration with CI/CD

### GitHub Actions Example

```yaml
name: Validation Pipeline

on: pull_request

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Sequential Validation
        run: |
          ./run-sequential-validation.sh \
            --fail-fast \
            --min-severity=error \
            syntax-validator \
            logic-validator \
            style-validator \
            security-validator \
            src/**/*.ts
      - name: Comment Results
        if: always()
        uses: actions/github-script@v6
        with:
          script: |
            const report = require('./validation-report.json');
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Validation Results\n${JSON.stringify(report)}`
            });
```

### Pre-commit Hook

```bash
#!/bin/bash
# .git/hooks/pre-commit

VALIDATORS=(
  "syntax-validator"
  "style-validator"
  "logic-validator"
)

if ! ./run-sequential-validation.sh \
    --fail-fast \
    --min-severity=error \
    "${VALIDATORS[@]}" \
    ./src; then
  echo "❌ Validation failed. Commit blocked."
  exit 1
fi

echo "✅ All validations passed."
exit 0
```

## Performance Optimization

### Parallelization (If Applicable)

Some validators can run in parallel if independent:

```
├─ Syntax (1) ──┬─ Logic (2)
                ├─ Style (1)
                └─ Security (8)
```

However, most validation chains benefit from sequential execution to:
- Avoid running expensive checks on invalid input
- Provide early failure feedback
- Reuse previous results

### Caching

```bash
# Cache syntax parse results
validator cache set syntax src/app.ts ast.json

# Reuse if file unchanged
validator cache get syntax src/app.ts
# Returns cached ast.json (instant)
```

## Use Cases

### Pre-commit Validation

```
Developer commits
  ↓
Syntax check (instant feedback)
  ↓
Logic check (catches business logic errors)
  ↓
Style check (enforces standards)
  ↓
Commit allowed or blocked
```

### Pre-merge Validation

```
PR created
  ↓
All validators run sequentially
  ↓
Security validator (thorough scan)
  ↓
Report to reviewers
  ↓
Review + merge decision
```

### Release Validation

```
Release candidate
  ↓
All validators with high severity
  ↓
Final security audit
  ↓
Release approval
```

## Limitations

- **Serial execution:** Not faster than running all in parallel
- **Dependencies:** Useful only if later validators depend on earlier results
- **Timeout risk:** If any validator hangs, pipeline stalls
- **Resource overhead:** Multiple analysis passes

Use parallel orchestration if validators are independent!
