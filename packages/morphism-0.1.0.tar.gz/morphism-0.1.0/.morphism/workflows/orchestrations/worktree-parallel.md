---
name: Worktree Parallel Orchestration
description: Run multiple agents in parallel on isolated git worktrees with independent branches
type: parallel
version: 1.0.0
status: ✅ Active
owner: Platform
---

# Worktree Parallel Orchestration Pattern

Execute multiple agents on isolated git worktrees, each with their own branch and filesystem copy.

## Pattern Overview

```
┌─────────────────────────────────────────────────────────────────┐
│ Main Repository (Shared)                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  .worktrees/                                                    │
│  ├── agent-cli        (branch: feat/cli-hardening)             │
│  ├── agent-docs       (branch: docs/cleanup)                   │
│  ├── agent-perf       (branch: perf/optimization)              │
│  └── agent-security   (branch: chore/security-sweep)           │
│                                                                 │
│  Each worktree is an isolated environment                      │
│  - Independent git history                                     │
│  - Separate filesystem state                                   │
│  - No cross-contamination                                      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Coordination Rules

### 1. Agent Isolation

**Requirement:** No agent works across multiple worktrees.

```bash
# ✅ CORRECT: One agent per lane
agent-cli works in .worktrees/agent-cli
agent-docs works in .worktrees/agent-docs

# ❌ WRONG: One agent in multiple lanes
agent-cli works in .worktrees/agent-cli AND .worktrees/agent-docs
```

### 2. Branch Independence

**Requirement:** Each lane has unique branch name.

```bash
# Setup
./scripts/worktree-agents.sh create agent-cli feat/cli-hardening main
./scripts/worktree-agents.sh create agent-docs docs/cleanup main
# ✅ Different branches: feat/cli-hardening vs docs/cleanup
```

### 3. Merge Order

**Requirement:** Merge in risk order (lowest to highest impact).

```
1. ✅ CLI reliability (low user impact)
   ├── branch: feat/cli-hardening
   ├── impact: Internal tooling
   └── risk: Low (developers only)

2. 📋 Documentation (moderate impact)
   ├── branch: docs/cleanup
   ├── impact: User-facing docs
   └── risk: Moderate (visibility)

3. ⚡ Performance (medium impact)
   ├── branch: perf/optimization
   ├── impact: Runtime behavior
   └── risk: Medium (testing required)

4. 🔒 Security (highest impact)
   ├── branch: chore/security-sweep
   ├── impact: Security posture
   └── risk: High (thorough review required)
```

## Execution Workflow

### Phase 1: Setup (5 minutes)

```bash
# Create all worktrees
./scripts/worktree-agents.sh spawn
# or
./scripts/worktree-agents.sh create agent-cli feat/cli-hardening main
./scripts/worktree-agents.sh create agent-docs docs/cleanup main
./scripts/worktree-agents.sh create agent-perf perf/optimization main
./scripts/worktree-agents.sh create agent-security chore/security-sweep main

# Verify all created
./scripts/worktree-agents.sh list
```

### Phase 2: Parallel Execution (1-7 days)

Each agent works independently in their lane:

```bash
# Agent 1: CLI hardening
cd .worktrees/agent-cli
git checkout feat/cli-hardening
# Make changes, commit, work locally

# Agent 2: Documentation (same time, different lane)
cd .worktrees/agent-docs
git checkout docs/cleanup
# Make changes, commit, work locally

# No conflicts, no cross-contamination
```

### Phase 3: Push & Review (varies)

Each branch pushed independently:

```bash
# Agent 1 pushes when ready
cd .worktrees/agent-cli
git push origin feat/cli-hardening
# Creates/updates PR

# Agent 2 pushes when ready (independent)
cd .worktrees/agent-docs
git push origin docs/cleanup
# Creates/updates PR
```

### Phase 4: Sequential Merge (depends on review)

Merge in risk order:

```bash
# 1. Merge CLI hardening (low risk)
git checkout main
git merge feat/cli-hardening
git push

# 2. Merge documentation (moderate risk)
git checkout main
git pull
git merge docs/cleanup
git push

# Continue in order...
```

### Phase 5: Cleanup (1 minute)

```bash
# Remove merged worktrees
./scripts/worktree-agents.sh remove agent-cli
./scripts/worktree-agents.sh remove agent-docs
./scripts/worktree-agents.sh remove agent-perf
./scripts/worktree-agents.sh remove agent-security

# Verify cleanup
./scripts/worktree-agents.sh list  # Should be empty
```

## Coordination Between Agents

### Case 1: No Direct Collaboration

Most common - agents work independently:

```bash
# Timeline
Day 1-2: agent-cli works independently
Day 1-2: agent-docs works independently
Day 1-2: agent-perf works independently
→ All merge without interaction
```

### Case 2: Sequential Dependency

Agent B waits for Agent A to merge:

```bash
# Timeline
Day 1-3: agent-cli makes changes and merges
Day 3-5: agent-docs uses CLI changes, works independently
Day 5-6: agent-perf uses both, works independently

# Implement:
cd .worktrees/agent-docs
git pull origin main  # Get agent-cli's merged changes
# Continue working...
```

### Case 3: Shared State (Avoid!)

❌ **DO NOT:** Share state between worktrees

```bash
# ❌ WRONG: One agent modifies another's branch
cd .worktrees/agent-cli
git checkout docs/cleanup  # Don't do this!

# ✅ CORRECT: Each agent stays in its lane
cd .worktrees/agent-cli
git checkout feat/cli-hardening  # Stay in own branch
```

## State Management

### Isolation Guarantee

Each worktree is fully isolated:

```
.worktrees/agent-cli/
├── .git/              # Independent git history
├── src/               # Independent files
├── node_modules/      # Separate copies
└── .env               # Independent config

.worktrees/agent-docs/
├── .git/              # Independent git history
├── src/               # Independent files
├── node_modules/      # Separate copies
└── .env               # Independent config
```

### Sync When Needed

If Agent B needs changes from Agent A:

```bash
# Before Agent A merges:
cd .worktrees/agent-docs
git fetch origin
git rebase origin/feat/cli-hardening  # Get A's changes
# Continue working...

# Or wait for A to merge:
cd .worktrees/agent-docs
git pull origin main  # Get merged changes
# Continue working...
```

## Failure Handling

### If Agent Fails

```bash
# Option 1: Reset and retry
cd .worktrees/agent-cli
git reset --hard HEAD~3
# Fix issues, retry

# Option 2: Abandon and cleanup
./scripts/worktree-agents.sh remove agent-cli
# Start fresh if needed
```

### If Merge Conflict

```bash
# Resolve in the branch before pushing to main
cd .worktrees/agent-cli
git merge origin/main  # Get latest main
# Resolve conflicts
git add . && git commit -m "Merge main, resolve conflicts"
git push origin feat/cli-hardening
# PR now shows resolved conflicts
```

### If Main Progresses

```bash
# Agent can sync with main anytime
cd .worktrees/agent-docs
git pull origin main  # Get latest
# Continue working...
```

## Monitoring & Observability

### Check Worktree Status

```bash
./scripts/worktree-agents.sh list
# Shows:
# - agent-cli: 5 commits ahead of main
# - agent-docs: 2 commits ahead of main
# - agent-perf: 8 commits ahead of main
```

### Monitor Branch Progress

```bash
cd .worktrees/agent-cli
git log --oneline --graph origin/main..HEAD
# Shows commits specific to this branch
```

### Track Merge Status

```bash
gh pr list  # Show all open PRs
# Can see which branches are review-ready
```

## Performance Characteristics

| Aspect | Value | Notes |
|--------|-------|-------|
| Setup time | 1-2 min | Create all worktrees |
| Parallel execution | 1-7 days | Fully independent |
| Merge time | 5-30 min per branch | Sequential |
| Cleanup | 1 min | Remove all worktrees |
| Total duration | 1-10 days | Setup + work + merge + cleanup |
| Filesystem overhead | ~500 MB × agents | Each worktree ~500MB |

## Use Cases

### Multi-Team Project

```
Team 1 (CLI) → agent-cli (feat/cli-hardening)
Team 2 (Docs) → agent-docs (docs/cleanup)
Team 3 (Perf) → agent-perf (perf/optimization)
Team 4 (Sec) → agent-security (chore/security-sweep)

All work in parallel, merge in risk order
```

### Isolated Experiments

```
Main branch: stable code
agent-exp1: Try approach A
agent-exp2: Try approach B
agent-exp3: Try approach C

Compare, pick winner, cleanup others
```

### Bug Fix & Feature Parallel

```
agent-cli: Fix critical CLI bug
agent-docs: Document new feature
agent-perf: Optimize bottleneck

All independent, stagger merges
```

## Guardrails

- ✅ One agent per worktree
- ✅ Unique branch names
- ✅ Pull before significant commits (sync with main)
- ✅ Resolve conflicts before pushing
- ✅ Merge in risk order
- ✅ Cleanup after merge

## Integration

### Pre-merge Checks

```bash
# Validate branch before merge
git merge --no-commit --no-ff feat/cli-hardening
# Runs tests, linters, etc.
# If passes: git commit
# If fails: git merge --abort
```

### CI/CD per Branch

Each branch has independent CI/CD:

```yaml
# .github/workflows/pr-validation.yml
on: pull_request
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - run: npm test
      - run: npm run lint
```

## Limitations

- Disk space: Each worktree uses ~500MB
- Number of agents: Practical limit ~5-10 (more = complexity)
- Merge conflicts: Must resolve before main merge
- Long-running branches: Risk of growing conflicts
