# Orchestrations

**Purpose:** Multi-agent coordination patterns for parallel or sequential execution.

**Format:** Markdown or JSON with dependency graphs and agent assignments.

## Structure

```markdown
# Orchestration Name

**Purpose:** What this coordinates
**Agents:** List of agents involved
**Execution:** Parallel | Sequential | Hybrid
**Duration:** Estimated time

## Dependency Graph

```mermaid
graph TD
  A[Agent 1] --> C[Agent 3]
  B[Agent 2] --> C
  C --> D[Agent 4]
```

## Agent Assignments

- **Agent 1:** Task description
- **Agent 2:** Task description
- **Agent 3:** Task description (waits for 1 & 2)
- **Agent 4:** Task description (waits for 3)

## Execution

[How to run this orchestration]
```

## Examples

- `parallel-skill-creation.md` - Create 4 skills simultaneously
- `sequential-deployment.md` - Build → Test → Deploy pipeline
- `hybrid-research.md` - Parallel research + sequential synthesis

## See Also

- `.morphism/workflows/` - Single-agent processes
- `scripts/worktree-agents.sh` - Git worktree orchestration
