---
name: Parallel Skills Orchestration
description: Execute multiple independent skills in parallel for faster task completion
type: parallel
version: 1.0.0
status: ✅ Active
owner: Platform
---

# Parallel Skills Orchestration Pattern

Execute multiple independent skills in parallel to complete complex tasks faster while managing dependencies and state.

## Pattern Overview

```
Input Task
  ├─→ Skill A (Extract data)      [↓ 2 min]
  ├─→ Skill B (Transform)         [↓ 3 min]
  ├─→ Skill C (Validate)          [↓ 1 min]
  └─→ Skill D (Package)           [↓ 1 min]
             ↓
        All complete
             ↓
        Join results
             ↓
        Final output
```

## Coordination Rules

### 1. Independent Execution

**Requirement:** Skills must be independent (no blocking dependencies).

```bash
# ✅ CORRECT: All independent
skill-a processes: data.json
skill-b processes: data.json
skill-c processes: data.json
→ All run in parallel

# ❌ WRONG: B depends on A
skill-a generates: artifact.json
skill-b needs: artifact.json
→ Must run sequentially (or use sequential pattern)
```

### 2. Shared Input

**Requirement:** Multiple skills operate on same input.

```bash
Input: raw-data.csv
  ├── Skill 1: Extract columns A, B, C
  ├── Skill 2: Extract columns D, E, F
  ├── Skill 3: Statistical analysis
  └── Skill 4: Data quality check

All start with same input, can overlap
```

### 3. Result Aggregation

**Requirement:** Join results into final output.

```bash
Skill A output: {extracted: [...]}
Skill B output: {transformed: [...]}
Skill C output: {validated: true}
Skill D output: {formatted: "..."}
  ↓
Aggregator: Combine into unified output
  ↓
Final: {extracted, transformed, validated, formatted}
```

## Execution Workflow

### Phase 1: Setup (1-2 minutes)

```bash
# Define parallel skills
skills=(
  "extract-skill"
  "transform-skill"
  "validate-skill"
  "package-skill"
)

# Input
input_data="data.json"

# Start parallel execution
./run-parallel-skills.sh "${skills[@]}" "$input_data"
```

### Phase 2: Parallel Execution (Longest single skill)

All skills start simultaneously:

```
Time   Skill A          Skill B          Skill C        Skill D
────────────────────────────────────────────────────────────────
00:00  [============]   [===============] [==]           [==]
00:01  [============]   [===============] [==]           [==]
00:02  [============]   [===============] [==]           [==]
00:03             ✓     [===============] [==]           [==]
00:04                            ✓       [==]           [==]
00:05                                       ✓            [==]
00:06                                                      ✓
```

**Total time:** 6 minutes (not 2+3+1+1 = 7 minutes)

### Phase 3: Result Collection (1-2 minutes)

Wait for all skills to complete:

```bash
# Timeout: 60 seconds per skill
skill-a: ✅ complete (180s)
skill-b: ✅ complete (150s)
skill-c: ✅ complete (45s)
skill-d: ✅ complete (60s)

All done, proceed to aggregation
```

### Phase 4: Result Aggregation (1-2 minutes)

Combine results into unified output:

```json
{
  "extracted": {...},
  "transformed": {...},
  "validated": true,
  "formatted": "...",
  "metadata": {
    "execution_time_seconds": 360,
    "skills_completed": 4,
    "aggregation_time_ms": 125
  }
}
```

## Configuration

### Skill Definition

```json
{
  "name": "extract-skill",
  "input": "data.json",
  "timeout_seconds": 180,
  "parallelizable": true,
  "output_format": "json",
  "retry_on_failure": 1
}
```

### Execution Modes

#### All-or-Nothing

```bash
# If any skill fails, whole operation fails
--mode=all-or-nothing
→ All skills must pass

# All timeout at same time
--timeout=60
```

#### Partial Success

```bash
# If some skills fail, continue with others
--mode=partial-success
→ Skill A fails, B/C/D continue
→ Final output includes: "failed_skills: [a]"
```

#### Timeout Strategy

```bash
# Wait for all (or timeout)
--timeout-strategy=wait-all
→ Wait max 180 seconds

# Fail immediately on first timeout
--timeout-strategy=fail-fast
→ If skill doesn't complete in time, fail all
```

## Dependency Management

### Independent Skills (No Dependencies)

```bash
Skills: A, B, C, D
Dependencies: None

# All start at 00:00
./run-parallel-skills.sh \
  --parallelizable=true \
  skill-a skill-b skill-c skill-d \
  input.json
```

### Linear Dependencies

If A must complete before B:

```bash
Skills: A → B → C (cannot parallelize)

# Use sequential pattern instead
./run-sequential-skills.sh \
  skill-a skill-b skill-c \
  input.json
```

### Partial Dependencies

If A/B independent, C depends on both:

```bash
     A ──┐
         → C
     B ──┘

# Run A+B in parallel, then C
./run-parallel-then-sequential.sh \
  --parallel="skill-a,skill-b" \
  --then="skill-c" \
  input.json
```

## State Management

### Shared State (If Needed)

```bash
# All skills can read shared state
shared_state={
  "user_id": 123,
  "api_key": "...",
  "config": {...}
}

# Each skill reads from shared_state
skill-a reads: shared_state.api_key
skill-b reads: shared_state.config
skill-c reads: shared_state.user_id
```

### Isolated State

```bash
# Each skill has isolated state (recommended)
skill-a: state = {temp_a: ...}
skill-b: state = {temp_b: ...}
skill-c: state = {temp_c: ...}

# No cross-contamination
# Join results at end
```

## Error Handling

### Strategy 1: Fail-Fast

```bash
Skill A fails at 00:30
  ↓
All other skills (B/C/D) stop immediately
  ↓
Report failure, return partial results

# Useful for: Critical checks, quality gates
```

### Strategy 2: Continue on Error

```bash
Skill A fails at 00:30
  ↓
Skill B/C/D continue executing
  ↓
All skills complete
  ↓
Report: 1 failed, 3 passed

# Useful for: Comprehensive validation, best-effort processing
```

### Strategy 3: Retry Failed

```bash
Skill A fails at 00:30
  ↓
Retry skill-a (if retries remaining)
  ↓
All complete or max retries exceeded
  ↓
Report final status

# Useful for: Transient failures, network timeouts
```

## Monitoring & Observability

### Real-time Progress

```bash
$ ./run-parallel-skills.sh skill-a skill-b skill-c input.json

[00:00] Starting parallel execution (3 skills)
[00:01] skill-a: Running (50% complete)
[00:01] skill-b: Running (10% complete)
[00:01] skill-c: Waiting to start...
[00:02] skill-a: ✅ DONE (90s)
[00:03] skill-b: Running (80% complete)
[00:04] skill-c: ✅ DONE (45s)
[00:05] skill-b: ✅ DONE (150s)

Final Report:
✅ All skills completed
⏱️  Total time: 150 seconds (vs 285 if sequential)
📊 Speedup: 1.9x faster than sequential

Results aggregated to: output.json
```

### Detailed Metrics

```json
{
  "execution": {
    "start_time": "2026-02-07T14:00:00Z",
    "end_time": "2026-02-07T14:02:30Z",
    "total_seconds": 150,
    "sequential_equivalent_seconds": 285,
    "speedup_ratio": 1.9
  },
  "skills": {
    "skill-a": {
      "status": "success",
      "start": 0,
      "end": 90,
      "duration_seconds": 90
    },
    "skill-b": {
      "status": "success",
      "start": 0,
      "end": 150,
      "duration_seconds": 150
    },
    "skill-c": {
      "status": "success",
      "start": 0,
      "end": 45,
      "duration_seconds": 45
    }
  }
}
```

## Integration Examples

### Document Processing Pipeline

```bash
# Process document in parallel
Input: document.docx

Skills:
├─ Extract text skill (2 min)
├─ Extract metadata skill (1 min)
├─ Extract images skill (3 min)
└─ Analyze structure skill (2 min)

Timeline: 3 min total (vs 8 min sequential)

Output: {text, metadata, images, structure}
```

### Data Analysis Pipeline

```bash
# Analyze dataset in parallel
Input: large-dataset.csv

Skills:
├─ Statistical analysis (2 min)
├─ Anomaly detection (3 min)
├─ Visualization generation (1 min)
└─ Data quality report (2 min)

Timeline: 3 min total (vs 8 min sequential)

Output: {stats, anomalies, visualizations, quality_report}
```

### Code Review Pipeline

```bash
# Review code in parallel
Input: src/**/*.ts

Skills:
├─ Syntax checker (1 min)
├─ Style validator (1 min)
├─ Security scanner (4 min)
└─ Test coverage analyzer (2 min)

Timeline: 4 min total (vs 8 min sequential)

Output: {syntax, style, security, coverage}
```

## Performance Characteristics

| Metric | Value | Notes |
|--------|-------|-------|
| Parallelization overhead | 1-2 sec | Process spawn, IPC |
| Result aggregation | <1 sec | Combining outputs |
| Total time | max(skill_times) + overhead | Limited by slowest skill |
| Memory overhead | skill_count × memory_per | Each skill in separate process |
| CPU usage | Linear with skill count | Until CPU saturation |

## Best Practices

### 1. Balance Skill Load

```bash
# ✅ GOOD: Similar execution times
skill-a: 2 min
skill-b: 2 min
skill-c: 2.5 min
→ No bottleneck, efficient

# ❌ BAD: Imbalanced
skill-a: 0.5 min
skill-b: 10 min
skill-c: 0.5 min
→ Waiting for B (throughput limited)
```

### 2. Minimize Shared State

```bash
# ✅ GOOD: Each skill independent
skill-a reads: input_data, writes: output_a
skill-b reads: input_data, writes: output_b
→ No coordination overhead

# ❌ BAD: Heavy shared state
skill-a reads/writes: shared_state
skill-b reads/writes: shared_state
skill-c reads: shared_state
→ Synchronization overhead, potential race conditions
```

### 3. Timeout Conservatively

```bash
# ✅ GOOD: Reasonable timeout
skill-a: max 180 seconds
skill-b: max 300 seconds
→ Allows slow operations

# ❌ BAD: Too tight
skill-a: max 10 seconds
→ Fails on normal completion
```

### 4. Handle Partial Failures Gracefully

```bash
# ✅ GOOD: Define behavior
--mode=partial-success
→ Some fail, others complete, report both

# ❌ BAD: All-or-nothing for best-effort
--mode=all-or-nothing
→ One slow skill blocks all
```

## Limitations

- **Not good for sequential workflows** - Use sequential pattern if B depends on A's output
- **Resource overhead** - Multiple processes consume memory
- **CPU saturation** - Can't parallelize beyond available CPU cores
- **Synchronization complexity** - Managing shared state is hard
