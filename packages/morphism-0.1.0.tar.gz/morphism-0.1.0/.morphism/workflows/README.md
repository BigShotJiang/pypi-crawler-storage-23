# Workflows

**Purpose:** Multi-step processes that orchestrate multiple tools/skills.

**Format:** Markdown with numbered steps, decision trees, and clear entry/exit conditions.

## Structure

```markdown
# Workflow Name

**Triggers:** When to use this workflow
**Prerequisites:** Required tools, skills, or setup
**Duration:** Estimated time
**Outputs:** What this produces

## Steps

1. Step one
2. Step two
3. Step three

## Decision Points

- If X, then Y
- If A, then B

## Examples

[Concrete examples]
```

## Examples

- `dependency-upgrade.md` - Upgrade all dependencies safely
- `new-feature.md` - Add feature from spec to deployment
- `incident-response.md` - Handle production issues

## See Also

- `.morphism/steering/` - Skills (procedural knowledge)
- `.morphism/orchestrations/` - Multi-agent coordination
