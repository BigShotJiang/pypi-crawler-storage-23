---
name: Project Creation
description: Create new workspace projects from templates with proper structure
triggers:
  - New project needed
  - Initialization from template
  - Workspace expansion
duration: 5-10 minutes
owner: Team
version: 1.0.0
status: ✅ Active
---

# Project Creation Workflow

Scaffold new workspace projects using standardized templates to ensure consistency and completeness.

## Quick Reference

| Task | Command | Time | Purpose |
|------|---------|------|---------|
| Create default project | `./workspace new <project-name>` | 1m | Create with default template |
| Create with template | `./workspace new <project-name> <template>` | 2m | Use specific template |
| List templates | `./workspace templates list` | <1m | See available scaffolds |
| Validate template | `./workspace templates validate <template>` | <1m | Check template integrity |

## Available Templates

| Template | Location | Description | Structure |
|----------|----------|-------------|-----------|
| `default` | `.morphism/templates/default/` | Standard workspace project | kernel/hub/lab structure |
| `lean-proof` | `.morphism/templates/lean-proof/` | Lean 4 proof project | Lake build, Mathlib4 integration |
| `documentation` | `.morphism/templates/documentation/` | Doc-heavy project | Markdown, diagrams, assets |
| `cli-tool` | `.morphism/templates/cli-tool/` | Command-line tool | Scripts, tests, docs |
| `library` | `.morphism/templates/library/` | Library/SDK project | Source, tests, exports |

## Workflow Steps

### Step 1: Choose Template

**Decision:** What type of project are you creating?

```
┌─ Lean proof?         → Use: lean-proof
├─ Command-line tool?  → Use: cli-tool
├─ Library/SDK?        → Use: library
├─ Documentation heavy?→ Use: documentation
└─ Standard project?   → Use: default
```

### Step 2: Create Project

```bash
# Example: Create CLI tool named "workspace-audit"
./workspace new workspace-audit cli-tool
```

Output:
```
✅ Creating project: workspace-audit
📁 Template: cli-tool
📂 Structure:
   workspace-audit/
   ├── README.md
   ├── package.json
   ├── src/
   │   └── index.ts
   ├── tests/
   │   └── index.test.ts
   ├── scripts/
   │   ├── build.sh
   │   ├── test.sh
   │   └── lint.sh
   └── docs/
       └── USAGE.md

🎯 Next steps:
   1. cd workspace-audit
   2. npm install
   3. npm run test
   4. npm run build
```

### Step 3: Initialize Git (if needed)

```bash
cd workspace-audit
git add .
git commit -m "init: create workspace-audit from cli-tool template"
```

### Step 4: Customize Project

Edit template-generated files:

```bash
# Update README with project description
vim README.md

# Update package.json with metadata
vim package.json

# Add initial implementation
vim src/index.ts

# Run tests
npm test
```

### Step 5: Integrate with Workspace

```bash
# For new top-level project
git subtree add --prefix=workspace-audit <remote-url> main

# Or for nested project (if adding to kernel/hub/lab)
cd kernel
git subtree add --prefix=workspace-audit <remote-url> main
```

### Decision Points

#### Is this a new standalone project?
- **Yes** → Create in workspace root, add to pnpm workspace
- **No** → Create nested in kernel/, hub/, or lab/

#### Does the template meet your needs?
- **Yes** → Proceed with customization
- **No** → Start with closest template, modify structure

#### Are dependencies required?
- **Yes** → `npm install` after creation
- **No** → Structure is ready, customize content

## Examples

### Create Lean proof project

```bash
./workspace new morphism-ext lean-proof
cd morphism-ext

# Structure created:
# ├── lakefile.lean       # Lake build configuration
# ├── lean.toml           # Lean version config
# ├── Morphism.lean       # Main module
# └── tests/              # Test proofs

# Build and test
lake build
lake test
```

### Create CLI tool from template

```bash
./workspace new data-exporter cli-tool
cd data-exporter

# Generated files:
# ├── src/cli.sh          # CLI entry point
# ├── src/commands/       # Individual commands
# ├── src/lib/            # Shared utilities
# ├── tests/              # Bash test suite
# └── docs/COMMANDS.md    # CLI reference

# Test the CLI
./src/cli.sh --help
./src/cli.sh export --format=json
```

### Create documentation project

```bash
./workspace new workspace-guide documentation
cd workspace-guide

# Structure created:
# ├── docs/               # All markdown files
# ├── assets/             # Images, diagrams
# ├── scripts/            # Build/deploy scripts
# ├── package.json        # Build tools (if needed)
# └── .github/workflows/  # Auto-publish on push

# Build documentation site
npm run build:docs
npm run serve
```

## Template Structure Reference

### Default Template
```
project/
├── README.md                    # Project overview
├── GETTING_STARTED.md           # Quick start guide
├── package.json                 # Dependencies (if Node.js)
├── src/                         # Source code
│   ├── index.ts                 # Main entry
│   └── utils/                   # Utilities
├── tests/                       # Test suite
│   └── index.test.ts
├── docs/                        # Documentation
│   ├── API.md
│   └── CONTRIBUTING.md
└── scripts/                     # Automation
    ├── build.sh
    ├── test.sh
    └── lint.sh
```

### Lean Proof Template
```
project/
├── lakefile.lean                # Lake build config
├── lean.toml                    # Lean version
├── Project.lean                 # Module structure
├── Proofs/                      # Proof files
│   ├── Core.lean
│   └── Extensions.lean
├── tests/                       # Verification
│   └── ProofTests.lean
└── README.md                    # Theorem catalog
```

## Validation Checklist

After creation, verify:

- [ ] All template files present
- [ ] Directory structure matches template
- [ ] README.md explains project purpose
- [ ] Dependencies (if any) are listed
- [ ] First build/test succeeds
- [ ] Git initialized and first commit clean

## Integration with Kiro Inventory

After creating a project:

1. Update `.morphism/inventory/INVENTORY.md` with new project
2. Add to appropriate category (e.g., "CLIs", "Libs", "Proofs")
3. Set initial maturity status (e.g., "🚧 In Progress")

Example INVENTORY.md entry:
```markdown
| workspace-audit | scripts/workspace-audit.sh | Monitor workspace | 🚧 In Progress |
```

## Dependencies

- **Requires:** `./workspace` CLI, templates in `.morphism/templates/`
- **Requires:** Git, Node.js (for JS projects), Lean (for proofs)
- **Related:** `daily-operations` workflow (verify new project status)

## Notes

- Templates are version-controlled in `.morphism/templates/`
- Each template has `template.yaml` with metadata
- Customize templates for team standards
- Document template-specific setup steps
- Archive deprecated templates (don't delete)
