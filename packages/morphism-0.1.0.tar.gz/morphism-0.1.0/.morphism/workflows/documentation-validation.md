---
name: Documentation Validation
description: Audit, validate, and maintain documentation consistency
triggers:
  - Documentation changes committed
  - Weekly quality audit
  - Before release
  - AGENTS.md drift detected
duration: 5-15 minutes
owner: Documentation Team
version: 1.1.0
status: ✅ Active
---

# Documentation Validation Workflow

Ensure documentation completeness, consistency, and adherence to organizational standards. **In this repo** we use Python scripts only; the full testing and doc-revision sequence (including link check, frontmatter, tests, MkDocs) is in [docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md](../../docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md).

## Why This Workflow

- ✅ Catch missing or broken references early
- ✅ Maintain docs alignment with codebase
- ✅ Ensure AGENTS.md governance is properly reflected
- ✅ Prevent documentation debt accumulation
- ✅ Validate pointer consistency across workspace

## Quick Reference

| Task | Command | Time | Purpose |
|------|---------|------|---------|
| Audit / map docs (graph + report) | `python scripts/docs_graph.py --report` | 1m | JSON report: nodes, edges, broken_refs, archived_broken_refs, cycles |
| Check links (CI gate) | `python scripts/docs_graph.py --check` | 1m | Exit 1 on non-archived broken refs; warnings for archived dirs |
| Frontmatter check | `python scripts/docs_frontmatter.py --check` | 1-2m | Validate YAML frontmatter in docs |
| Check AGENTS pointers (optional) | `./scripts/check-agents-pointers.sh` | 1m | For repos with `morphism/AGENTS.md`; this repo has root AGENTS.md so script skips (see below) |
| Full validation | See [playbook](../../docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md) | 5-10m | Link check + frontmatter + pytest + MkDocs build |

**Note:** `scripts/morphism-docs.mjs` is not present in this repo. Documentation validation uses [scripts/docs_graph.py](../../scripts/docs_graph.py) and [scripts/docs_frontmatter.py](../../scripts/docs_frontmatter.py) as the canonical tools.

## Workflow Steps

### Phase 1: Link check (audit / map)

```bash
python scripts/docs_graph.py --report
```

Inspect the JSON for `broken_refs`, `archived_broken_refs`, and `cycles`. For CI and pass/fail:

```bash
python scripts/docs_graph.py --check
```

- **Exit 0:** No broken refs in non-archived docs (or only warnings in archived dirs).
- **Exit 1:** At least one broken ref in a non-archived doc; fix before merge.

**What it checks:**
- All `[text](path)` links in `docs/` and root `.md` resolve (file-relative or root-relative).
- Orphans and cycles are reported in `--report`. Broken refs in `docs/governance/audits`, `docs/governance/history`, `docs/implementation/workspace`, `docs/implementation/reports`, `docs/plans` are warnings only (non-blocking).

### Phase 2: Frontmatter and optional graph frontmatter

```bash
python scripts/docs_frontmatter.py --check
```

Optionally combine with docs_graph frontmatter checks:

```bash
python scripts/docs_graph.py --check --frontmatter
```

**What it checks:**
- YAML frontmatter in docs; normative placement; SSOT atom registry alignment (see script help).

### Phase 3: AGENTS pointers (optional, repo-specific)

```bash
./scripts/check-agents-pointers.sh
```

**In this repo:** The script expects `morphism/AGENTS.md` as the canonical file. This repo has **root** [AGENTS.md](../../AGENTS.md), so the script exits 0 with "Warning: canonical file not found" and does not validate pointers. Use this step only in repos that have a `morphism/` subdirectory with its own AGENTS.md. For morphism-systems, governance pointers are validated by reading AGENTS.md, SSOT.md, and GUIDELINES.md directly.

### Decision Points

#### After link check:

- **Exit 1 (broken refs)?** → Fix links in non-archived docs; re-run `--check`.
- **Only archived warnings?** → Non-blocking; see playbook "Known link warnings." Optional P3: fix in [docs/TODO.md](../../docs/TODO.md).

#### After frontmatter:

- **Errors?** → Fix frontmatter or add stubs per script guidance.
- **Warnings?** → Schedule in backlog if needed.

#### Full sequence:

- Run the full sequence from [docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md](../../docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md) (link check → frontmatter → pytest → MkDocs build) for a complete pass.

## Examples

### Pre-commit documentation validation

```bash
python scripts/docs_graph.py --check && python scripts/docs_frontmatter.py --check
```

### Full testing and doc-revision pass

See [docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md](../../docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md) for the ordered steps (link check, frontmatter, Python tests, MkDocs build, optional Turbo, optional Truth Documentation Review).

## Output Files

- **docs_graph.py --report:** JSON to stdout (nodes, edges, broken_refs, archived_broken_refs, cycles).
- **docs_frontmatter.py:** See script `--report` / `--add-stub` for outputs.

## Guardrails

- **Never** commit documentation that fails `docs_graph.py --check` (non-archived broken refs).
- **Never** create orphaned files without adding to nav or marking in INVENTORY/docs.
- **Always** run the playbook (or at least link check + MkDocs build) before release.

## Integration Points

- **CI:** [.github/workflows/docs.yml](../../.github/workflows/docs.yml) runs `python scripts/docs_graph.py --check` and `mkdocs build --strict` on `docs/**` and `mkdocs.yml` changes.
- **Full playbook:** [docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md](../../docs/TESTING_AND_DOC_REVISION_PLAYBOOK.md).

## Dependencies

- **Requires:** Python 3.11+ (stdlib only for docs_graph.py); see docs_frontmatter.py for its deps.
- **Scripts:** [scripts/docs_graph.py](../../scripts/docs_graph.py), [scripts/docs_frontmatter.py](../../scripts/docs_frontmatter.py); optional [scripts/check-agents-pointers.sh](../../scripts/check-agents-pointers.sh) for repos with morphism/AGENTS.md.

## Notes

- Run before every commit to catch link issues early.
- Run the full playbook before releases.
- Archived-dir broken refs (62 as of last run) are documented in the playbook and do not block CI.
