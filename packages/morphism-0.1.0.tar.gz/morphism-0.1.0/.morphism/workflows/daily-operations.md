---
name: Daily Operations
description: Essential daily tasks for workspace health and visibility
triggers:
  - Morning standup
  - Project status check
  - Repository health monitoring
duration: 5-10 minutes
owner: Team
version: 1.0.0
status: ✅ Active
---

# Daily Operations Workflow

Regular tasks for maintaining workspace health and keeping the team aligned on status.

## Quick Reference

| Task | Command | Time | Purpose |
|------|---------|------|---------|
| Status check (default) | `./workspace status` | <1m | Fast repo scan |
| Status check (detailed) | `./workspace status --full` | 2-3m | Comprehensive health check |
| Status check (custom) | `./scripts/status-all.sh --full --limit 30` | <2m | Specific project focus |
| Pull latest | `./scripts/pull-all.sh` | 1-2m | Sync all branches |
| Dashboard | `./workspace dashboard` | <1m | Visual overview |

## Workflow Steps

### Morning Health Check (Daily at start of work)

1. **Get repository status**
   ```bash
   ./workspace status
   ```
   Expected output: All green indicators, no stale branches

2. **Review dashboard**
   ```bash
   ./workspace dashboard
   ```
   Expected output: Visual status of all projects, recent commits

3. **Pull latest changes**
   ```bash
   ./scripts/pull-all.sh
   ```
   Expected output: All projects updated to latest main

### Decision Points

- **Are there merge conflicts?**
  - Yes → Resolve in individual project directories
  - No → Continue to next task

- **Are any projects in ⚠️ Warning state?**
  - Yes → Run `./workspace status --full` for details
  - No → Proceed with normal work

- **Are there stale branches (>30 days)?**
  - Yes → Review with team, consider cleanup
  - No → Continue to next task

## Examples

### Check workspace health quickly
```bash
./workspace status
# Output:
# ✅ kernel/ - main: clean
# ✅ hub/ - main: clean
# ✅ lab/ - main: clean
# ✅ docs/ - main: clean
```

### Get full details on one project
```bash
cd kernel && git status --short
git log --oneline -5
```

### Sync everything to latest
```bash
./scripts/pull-all.sh
# Output:
# Pulling kernel/...
# Pulling hub/...
# Pulling lab/...
# ✅ All projects synchronized
```

## Dependencies

- **Requires:** `./workspace` CLI, `./scripts/status-all.sh`, `./scripts/pull-all.sh`
- **Related:** `documentation-validation` workflow for doc checks

## Notes

- Morning check takes <5 minutes and is critical for team alignment
- Run `--full` flag on Mondays for comprehensive weekly review
- If health check fails, escalate to workspace administrator
