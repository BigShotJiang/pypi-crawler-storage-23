---
name: Multi-Agent Worktrees
description: Execute parallel agent lanes using git worktree isolation
triggers:
  - Multi-agent collaboration required
  - Parallel development streams
  - Isolated sandbox needed per agent
duration: 10-30 minutes (setup), 1-7 days (execution)
owner: Team
version: 1.0.0
status: ✅ Active
---

# Multi-Agent Worktrees Workflow

Run parallel agent lanes safely using `git worktree` so each agent has an isolated branch and filesystem.

## Why This Pattern

- ✅ Avoid branch collisions and accidental cross-task edits
- ✅ Keep each agent focused on one lane of work
- ✅ Merge lane branches independently after validation
- ✅ Sandbox filesystem per agent (no shared state pollution)
- ✅ Easy rollback: just remove the worktree

## Quick Reference

| Task | Command | Time | Purpose |
|------|---------|------|---------|
| Spawn default lanes | `./scripts/worktree-agents.sh spawn` | 1m | Create 4 standard agents |
| List active lanes | `./scripts/worktree-agents.sh list` | <1m | See all worktrees |
| Create custom lane | `./scripts/worktree-agents.sh create <name> <branch> [base]` | <1m | Add one agent |
| Remove lane | `./scripts/worktree-agents.sh remove <name>` | <1m | Cleanup after merge |
| Prune stale lanes | `./scripts/worktree-agents.sh prune` | <1m | Remove unused worktrees |

## Workflow Steps

### 1. Setup Parallel Lanes (Day 1 start)

```bash
./scripts/worktree-agents.sh spawn
```

Creates:
- `.worktrees/agent-cli` → branch `feat/workspace-cli-hardening`
- `.worktrees/agent-governance` → branch `docs/agents-pointer-standardization`
- `.worktrees/agent-performance` → branch `perf/workspace-status-fast`
- `.worktrees/agent-security` → branch `chore/security-governance-sweep`

### 2. Run Agent in Isolated Lane

Each agent works independently:

```bash
cd .worktrees/agent-cli
# Make changes locally - no impact on main worktree or other lanes
git add .
git commit -m "feat: CLI hardening - input validation"
```

### 3. Review Lane Progress

```bash
./scripts/worktree-agents.sh list
```

Output shows:
- Path to each agent's worktree
- Branch name
- Detached HEAD status
- Commit count ahead of main

### 4. Push Branch for Review

```bash
cd .worktrees/agent-governance
git push origin docs/agents-pointer-standardization
# Open PR from this branch
```

### 5. Merge in Risk Order

Once PR is approved:

1. **CLI reliability** (lowest risk user impact)
   - Merge `feat/workspace-cli-hardening`

2. **Governance/documentation** (moderate impact)
   - Merge `docs/agents-pointer-standardization`

3. **Performance** (medium impact)
   - Merge `perf/workspace-status-fast`

4. **Security hardening** (potential impact)
   - Merge `chore/security-governance-sweep`

### 6. Cleanup Merged Lanes

```bash
./scripts/worktree-agents.sh remove agent-cli
./scripts/worktree-agents.sh remove agent-governance
./scripts/worktree-agents.sh remove agent-performance
./scripts/worktree-agents.sh remove agent-security
```

## Decision Points

### Is a lane no longer needed?
- **Yes** → `./scripts/worktree-agents.sh remove <name>`
- **No** → Continue working or switch focus

### Did agent commit conflicting changes?
- **Yes** → Resolve in the worktree before push
- **No** → Proceed to push/PR

### Are multiple agents on same branch?
- **Yes** → STOP! Create separate branches for each agent
- **No** → Continue (guardrail maintained)

## Examples

### Standard workflow for one agent

```bash
# Day 1: Setup
./scripts/worktree-agents.sh spawn

# Agent works in isolated lane for 3 days
cd .worktrees/agent-cli
git log --oneline -10  # See their commits
git status            # Check uncommitted work

# Day 4: Ready for merge
git push origin feat/workspace-cli-hardening
# GitHub: Open PR, get review, merge

# Cleanup
./scripts/worktree-agents.sh remove agent-cli
```

### Create custom agent lane

```bash
./scripts/worktree-agents.sh create agent-docs docs/workspace-cleanup main
# Agent starts on new branch from main
cd .worktrees/agent-docs
# ... do work ...
git push origin docs/workspace-cleanup
```

### Monitor multiple agents

```bash
./scripts/worktree-agents.sh list
# Output:
# agent-cli    (.worktrees/agent-cli)    [feat/workspace-cli-hardening]
# agent-governance (.worktrees/agent-governance) [docs/agents-pointer-standardization]
# agent-performance (.worktrees/agent-performance) [perf/workspace-status-fast]
```

## Guardrails ⚠️

- **Never** run one agent across multiple worktree lanes
- **Never** share code between lanes until approved merge
- **Never** push to same branch from multiple lanes
- **Keep** each lane narrow and scoped to one concern
- **Remove** lanes after merging to avoid stale worktrees

## Dependencies

- **Requires:** `git worktree`, `./scripts/worktree-agents.sh`, Git 2.7+
- **Recommends:** `gh` CLI for PR management
- **Related workflows:** `daily-operations` (status check), `project-creation` (templates)

## Notes

- Worktrees are full filesystem copies (~500MB each)
- Best for 2-5 parallel agents (more = complexity risk)
- CI/CD validates each branch independently before merge
- Merge conflict resolution happens per-branch before main merge
