# Changelog

All notable changes to the Morphism Universal Governance Standard will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-02-08

### Added

**Core Infrastructure:**
- Created `.morphism/` directory structure (universal LLM governance standard)
- Added `config.json` with discovery rules and configuration hierarchy
- Added `README.md` with quick reference and component overview
- Added `CHANGELOG.md` following Keep a Changelog standard
- Created `docs/` subdirectory for migration and compatibility guides

**Documentation:**
- Added `docs/MIGRATION.md` - Complete migration guide from `.kiro/`
- Added `docs/COMPATIBILITY.md` - Cross-IDE integration guide for 5+ LLM tools

**Component Migration:**
- Migrated 3 agents from `.kiro/agents/` → `.morphism/agents/`
- Migrated 5 hooks from `.kiro/hooks/` → `.morphism/hooks/`
- Migrated 3 orchestrations from `.kiro/orchestrations/` → `.morphism/workflows/orchestrations/`
- Migrated 4 workflows from `.kiro/workflows/` → `.morphism/workflows/`
- Migrated 4 schemas from `.kiro/schemas/` → `.morphism/schemas/`
- Migrated 21 changelogs from `.kiro/changelogs/` → `.morphism/changelogs/`

**Inventory System:**
- Created `inventory/` subdirectory for component registry
- Moved `INVENTORY.md` → `.morphism/inventory/INVENTORY.md`
- Moved `MATURITY.md` → `.morphism/inventory/MATURITY.md`
- Moved `dependencies.json` → `.morphism/inventory/dependencies.json`

**Discovery System:**
- Implemented upward directory search algorithm
- Added environment variable support (`MORPHISM_CONFIG_DIR`)
- Added XDG Base Directory specification support (`~/.config/morphism/`)
- Added configuration hierarchy (Env > Local > Project > Global > Defaults)

**Compatibility:**
- Defined cross-IDE compatibility matrix (Claude, Cursor, Copilot, Windsurf, Devin)
- Added adapter patterns for tool-specific formats
- Documented discovery algorithm differences across IDEs

### Changed

- **Renamed:** `.kiro/powers/` → `.morphism/extensions/` (clarifies MCP server/plugin role)
- **Reorganized:** Inventory files now grouped in `inventory/` subdirectory
- **Nested:** Orchestrations now under `workflows/orchestrations/` for logical grouping
- **Updated:** All script paths from `.kiro/` → `.morphism/` (86 references)
- **Renamed:** Tool prefix from `kiro-*` → `morphism-*` in script names

### Removed

- Removed `.kiro/` directory (migrated to `.morphism/`)
- Removed platform-specific branding (Claude Code → Universal)
- Removed "powers" terminology (replaced with standard "extensions")

### Migration Notes

**Breaking Changes:**
- All `.kiro/` paths now use `.morphism/`
- Tool name changed: `kiro-dashboard.sh` → `morphism-dashboard.sh`
- Powers directory renamed to extensions

**Compatibility:**
- No backward compatibility layer (clean break)
- All validation tools updated to use `.morphism/`
- Documentation updated (CLAUDE.md, AGENTS.md, MEMORY.md)

**Timeline:**
- Migration completed in 2 weeks (2026-01-26 to 2026-02-08)
- All 12 tools operational with new paths
- 0 validation errors after migration

### Component Inventory

**Agents (3):**
- code-reviewer.json
- doc-writer.json
- context-optimizer.json

**Workflows (4):**
- daily-operations.md
- multi-agent-worktrees.md
- documentation-validation.md
- project-creation.md

**Orchestrations (3):**
- worktree-parallel.md
- sequential-validation.md
- parallel-skills.md

**Hooks (5):**
- pre-commit-validation.sh
- pre-push-validation.sh
- post-merge-sync.sh
- pr-validation.sh
- workflow-trigger.sh

**Extensions (2):**
- context-management.md
- parallel-execution.md

**Schemas (4):**
- agent.schema.json
- workflow.schema.json
- skill.schema.json
- orchestration.schema.json

**Total Components:** 39 (29 publishable)

### Validation Status

✅ **Schema Validation:** 100% compliant (0 errors)
✅ **Version Checks:** All v1.0.0, consistent
✅ **Dependency Health:** 0 circular references, 8 critical components
✅ **Quality Analysis:** 90/100 average score
✅ **Cross-References:** 0 broken links

### Tools Available

**Validation (5):**
- validate-enhanced.sh
- validate-versions.sh
- validate-dependencies.sh
- analyze-component-quality.sh
- generate-validation-report.sh

**Version Management (2):**
- version-check.sh
- visualize-dependencies.sh

**Usage Tracking (2):**
- log-usage.sh
- usage-analytics.sh

**User Interfaces (3):**
- morphism-dashboard.sh (renamed from kiro-dashboard.sh)
- export-inventory.sh
- search-components.sh

### Governance

**Canonical Documents:**
- AGENTS.md - Universal LLM governance standards
- MORPHISM.md - Framework axioms (v4.0: 10 axioms → 42 tenets)
- SSOT.md - 4-layer truth hierarchy
- .morphism/inventory/INVENTORY.md - Component registry

**Standards:**
- JSON Schema validation for all configs
- Semantic versioning (SemVer 2.0.0)
- Keep a Changelog format
- XDG Base Directory specification

### Future Enhancements

**Planned for v1.1.0:**
- Universal adapter layer for format translation
- MCP server implementation
- CLI tool (`morphism init`, `morphism validate`)
- Native IDE extensions

**Planned for v2.0.0:**
- Central registry of Morphism-compliant tools
- Certification program for IDEs
- Auto-discovery protocol standardization

---

## Version History

| Version | Date | Status | Notes |
|---------|------|--------|-------|
| 1.0.0 | 2026-02-08 | ✅ Released | Initial release, migrated from .kiro/ |

---

**See Also:**
- [README.md](README.md) - Quick reference
- [docs/MIGRATION.md](docs/MIGRATION.md) - Migration guide
- [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md) - Cross-IDE guide
- [inventory/INVENTORY.md](inventory/INVENTORY.md) - Component registry
