# .morphism/ — Consumer Configuration

**Version:** 1.1.0
**Status:** Active
**Updated:** 2026-02-08

## What is .morphism/?

This directory is the **consumer-side configuration** for the Morphism Categorical
Governance Framework. It is what any workspace creates when it adopts Morphism governance.

**This is NOT the framework source.** The framework itself lives in [`morphism/`](../morphism/). In this repository, root [AGENTS.md](../AGENTS.md), [SSOT.md](../SSOT.md), and [GUIDELINES.md](../GUIDELINES.md) are the governance authority; there is no separate morphism/ directory.

### Framework vs Consumer

| | Framework Source | Consumer Config |
|---|---|---|
| **Location** | `morphism/` | `.morphism/` |
| **Contains** | SSOT, axioms, tenets, kernel, tools | Agent configs, hooks, schemas, workflows |
| **Who creates it** | Framework developers | Any workspace adopting Morphism |
| **Equivalent for external users** | `npm install morphism-tools` | `npx morphism init` |

### Cross-Platform Support

Works across all LLM IDEs:
- ✅ Claude Code (Kiro)
- ✅ Cursor (Agent mode)
- ✅ GitHub Copilot (Workspace)
- ✅ Windsurf (Cascade)
- ✅ Devin
- ✅ Any future LLM IDE

## Quick Start

```bash
# View configuration
cat .morphism/config.json

# Browse components
./scripts/morphism-dashboard.sh

# Run validation
./scripts/validate-enhanced.sh

# Search components
./scripts/search-components.sh "agent"

# Export inventory
./scripts/export-inventory.sh -f json
```

## Directory Structure

```
.morphism/
├── config.json              # Main configuration
├── agents/                  # Agent definitions (3)
├── workflows/               # Orchestration patterns (4)
│   └── orchestrations/      # Multi-agent coordination (3)
├── hooks/                   # Lifecycle hooks (5)
├── extensions/              # MCP servers, plugins (2)
├── schemas/                 # JSON Schema validation (4)
├── inventory/               # Component registry
│   ├── INVENTORY.md         # Canonical catalog
│   ├── MATURITY.md          # Ownership tracking
│   └── dependencies.json    # Dependency graph
├── changelogs/              # Version history (21)
└── docs/                    # Documentation
```

## Component Categories

| Category | Count | Description |
|----------|-------|-------------|
| **Agents** | 3 | Autonomous AI workers (code-reviewer, doc-writer, context-optimizer) |
| **Workflows** | 4 | Multi-step orchestration patterns |
| **Orchestrations** | 3 | Multi-agent coordination strategies |
| **Hooks** | 5 | Lifecycle event automation |
| **Extensions** | 2 | Platform capabilities (MCP servers, plugins) |
| **Schemas** | 4 | JSON Schema validation definitions |

## Key Files

- **config.json** - Main configuration with discovery rules
- **inventory/INVENTORY.md** - Canonical component registry (39 components)
- **inventory/MATURITY.md** - Ownership and maturity tracking (29 publishable)
- **inventory/dependencies.json** - Component dependency graph
- **changelogs/** - Version history (all v1.0.0)

## Discovery Algorithm

The `.morphism/` directory is discovered using this search order:

1. `$MORPHISM_CONFIG_DIR` environment variable
2. `.morphism/` in current working directory
3. Walk up directory tree to root looking for `.morphism/`
4. `$XDG_CONFIG_HOME/morphism/` or `~/.config/morphism/`
5. `~/.morphism/` (legacy)
6. Built-in defaults

## Configuration Hierarchy

Priority from high to low:

1. Environment variables (`MORPHISM_CONFIG_DIR`)
2. Local config (`.morphism/settings.local.json`) - gitignored
3. Project config (`.morphism/config.json`) - committed
4. Global config (`~/.config/morphism/`) - user-level
5. Built-in defaults - hardcoded

## Migration Notes

**Migrated from:** `.kiro/` (2026-02-08)

**Key Changes:**
- `.kiro/powers/` → `.morphism/extensions/` (clarifies MCP server/plugin role)
- All paths updated: `.kiro/` → `.morphism/`
- Scripts renamed: `kiro-*` → `morphism-*`
- Universal governance: Platform-agnostic design

**See:** `.morphism/docs/MIGRATION.md` for complete migration guide

## Validation

Run comprehensive validation:

```bash
# Schema validation
./scripts/validate-enhanced.sh

# Version checks
./scripts/validate-versions.sh

# Dependency health
./scripts/validate-dependencies.sh

# Quality analysis
./scripts/analyze-component-quality.sh

# Full report
./scripts/generate-validation-report.sh
```

## Tools Available

**Validation (5):**
- validate-enhanced.sh, validate-versions.sh, validate-dependencies.sh
- analyze-component-quality.sh, generate-validation-report.sh

**Version Management (2):**
- version-check.sh, visualize-dependencies.sh

**Usage Tracking (2):**
- log-usage.sh, usage-analytics.sh

**User Interfaces (3):**
- morphism-dashboard.sh, export-inventory.sh, search-components.sh

## Learn More

- **Workspace governance:** [AGENTS.md](../AGENTS.md) (workspace-level, consumer)
- **Framework SSOT:** [morphism/MORPHISM.md](../morphism/MORPHISM.md) (canonical source)
- **Framework rules:** [morphism/AGENTS.md](../morphism/AGENTS.md) (for framework development)
- **Migration:** [.morphism/docs/MIGRATION.md](docs/MIGRATION.md)
- **Compatibility:** [.morphism/docs/COMPATIBILITY.md](docs/COMPATIBILITY.md)

## Status

✅ **Phase 1:** Component Population (2026-02-07)
✅ **Phase 2:** Enhanced Features (2026-02-08)
✅ **Phase 3:** Advanced Capabilities (2026-02-08)
✅ **Migration:** .kiro → .morphism (2026-02-08)

**Current State:**
- 39 components tracked
- 29 publishable (Stable/Mature)
- 0 validation errors
- 12 operational tools
