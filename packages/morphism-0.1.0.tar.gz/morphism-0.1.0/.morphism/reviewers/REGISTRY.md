# Reviewer Registry

**Version:** 1.0.0
**Purpose:** Central registry of all code reviewers and their usage patterns

---

## 📋 Overview

The Morphism Reviewer System provides specialized AI agents that enforce governance rules, architectural boundaries, and quality standards across the workspace.

### Philosophy

- **Proactive Review**: Catch issues before they become problems
- **Automated Governance**: Enforce rules consistently
- **Category-Theoretic**: Preserve morphism properties
- **Multi-IDE**: Works across all AI development tools

---

## 🔍 Available Reviewers

### 1. Architecture Boundary Reviewer

**Location:** `./architecture-boundary/REVIEWER.md`

**Purpose:** Enforce Morphism's 3-layer architecture (Kernel/Hub/Lab)

**When to Use:**
- Before adding dependencies
- Before structural changes
- During refactoring
- Before cross-layer imports

**Checks:**
- Dependency direction (Lab → Hub → Kernel only)
- No kernel code in hub/lab
- No personal code in shipped code
- Layer boundary violations

**Invocation:**
```bash
# Claude Code
/review architecture-boundary

# Manual
Read .morphism/reviewers/architecture-boundary/REVIEWER.md
```

---

### 2. Entropy Guard Reviewer

**Location:** `./entropy-guard/REVIEWER.md`

**Purpose:** Prevent complexity growth and code entropy

**When to Use:**
- During refactoring
- Before adding abstractions
- When complexity feels high
- Before committing large changes

**Checks:**
- Cyclomatic complexity
- Abstraction levels
- DRY violations
- Over-engineering
- Premature optimization

**Invocation:**
```bash
# Claude Code
/review entropy-guard

# Manual
Read .morphism/reviewers/entropy-guard/REVIEWER.md
```

---

### 3. MCP Integration Reviewer

**Location:** `./mcp-integration/REVIEWER.md`

**Purpose:** Validate MCP server configurations and integrations

**When to Use:**
- Before adding MCP servers
- Before modifying MCP configs
- When MCP connections fail
- During MCP troubleshooting

**Checks:**
- MCP server connections
- Tool schema validity
- Resource accessibility
- Configuration correctness
- Security (no secrets in config)

**Invocation:**
```bash
# Claude Code
/review mcp-integration

# Manual
Read .morphism/reviewers/mcp-integration/REVIEWER.md
```

---

### 4. Ship Readiness Reviewer

**Location:** `./ship-readiness/REVIEWER.md`

**Purpose:** Ensure production readiness before deployment

**When to Use:**
- Before creating releases
- Before deployment
- Before tagging versions
- During pre-launch checklist

**Checks:**
- Test coverage
- Documentation completeness
- Security review
- Performance benchmarks
- Error handling
- Deployment configuration

**Invocation:**
```bash
# Claude Code
/review ship-readiness

# Manual
Read .morphism/reviewers/ship-readiness/REVIEWER.md
```

---

### 5. Truth Documentation Reviewer

**Location:** `./truth-documentation/REVIEWER.md`

**Purpose:** Ensure documentation matches implementation

**When to Use:**
- After significant changes
- Before updating docs
- During API changes
- Before releases

**Checks:**
- Code-doc alignment
- Example accuracy
- API documentation
- Architecture diagrams
- README correctness

**Invocation:**
```bash
# Claude Code
/review truth-documentation

# Manual
Read .morphism/reviewers/truth-documentation/REVIEWER.md
```

---

## 🔄 Review Workflow

### Standard Review Process

1. **Trigger**: Significant change completed
2. **Select**: Choose appropriate reviewer(s)
3. **Run**: Invoke reviewer via AI IDE
4. **Address**: Fix identified issues
5. **Verify**: Re-run reviewer
6. **Commit**: Proceed when passing

### Multi-Reviewer Flow

For major changes, use multiple reviewers:

```bash
# Example: Pre-deployment review
1. /review architecture-boundary  # Check structure
2. /review entropy-guard          # Check complexity
3. /review ship-readiness         # Check production readiness
4. /review truth-documentation    # Check docs
```

---

## 🎯 When to Use Each Reviewer

| Scenario | Reviewers |
|----------|-----------|
| **Adding Feature** | Architecture Boundary → Entropy Guard → Truth Documentation |
| **Refactoring** | Architecture Boundary → Entropy Guard |
| **Adding MCP Server** | MCP Integration → Architecture Boundary |
| **Pre-Deployment** | Ship Readiness → Truth Documentation |
| **API Changes** | Truth Documentation → Ship Readiness |
| **Large PR** | All Reviewers |

---

## 🔧 Configuration

### IDE Integration

Each reviewer is accessible through:

**Claude Code:**
```bash
/review {reviewer-name}
```

**Codex:**
```bash
codex review {reviewer-name}
```

**Cursor:**
Via context menu or command palette

**AmazonQ:**
Via Q+ review commands

### Custom Triggers

Reviewers can be triggered by:
- Manual invocation
- Git hooks (pre-commit, pre-push)
- CI/CD pipelines
- IDE shortcuts

---

## 📊 Reviewer Statistics

| Reviewer | Checks | Avg Runtime | Pass Rate |
|----------|--------|-------------|-----------|
| Architecture Boundary | 12 | ~5s | TBD |
| Entropy Guard | 8 | ~10s | TBD |
| MCP Integration | 15 | ~8s | TBD |
| Ship Readiness | 20+ | ~15s | TBD |
| Truth Documentation | 10 | ~12s | TBD |

*Statistics will be populated as reviewers are used*

---

## 🤝 Contributing

### Adding New Reviewer

1. Create directory: `.morphism/reviewers/{name}/`
2. Write spec: `REVIEWER.md`
3. Add to this registry
4. Integrate with IDE configs
5. Test thoroughly
6. Submit PR

### Improving Existing Reviewer

1. Update `REVIEWER.md`
2. Test changes
3. Update registry if needed
4. Submit PR

---

## 📚 References

### Internal
- [Morphism Framework](../../morphism/MORPHISM.md)
- [SSOT](../../morphism/SSOT.md)
- [AGENTS.md](../../morphism/AGENTS.md)

### IDE Configs
- [Claude Config](../.morphism/ide-configs/claude/REVIEWERS.md)
- [Codex Config](../.morphism/ide-configs/codex/AGENTS.md)
- [Cursor Config](../.morphism/ide-configs/cursor/AGENTS.md)

---

**Reviewer System Version:** 1.0.0
**Maintained by:** Morphism Governance Team
**Last Updated:** 2026-02-11
