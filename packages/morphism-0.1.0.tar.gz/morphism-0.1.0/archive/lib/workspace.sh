#!/usr/bin/env bash

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

VERSION="2.0.0"

if [ -z "${WORKSPACE_ROOT:-}" ]; then
  LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  WORKSPACE_ROOT="$(cd "$LIB_DIR/.." && pwd)"
fi

DOCS_DIR="$WORKSPACE_ROOT/docs/workspace"
SCRIPTS_DIR="$WORKSPACE_ROOT/scripts"
PROJECTS_DIR="$WORKSPACE_ROOT/cloud/deployment/lab"
TEMPLATES_DIR="$WORKSPACE_ROOT/templates"
API_PORT="3000"
API_HOST="localhost"
MONITOR_PID_FILE="$WORKSPACE_ROOT/.monitor/monitor.pid"
API_PID_FILE="$WORKSPACE_ROOT/.api/api.pid"

print_header() {
  echo -e "${BLUE}Morphism Workspace CLI v$VERSION${NC}"
}

print_success() { echo -e "${GREEN}OK${NC} $1"; }
print_error() { echo -e "${RED}Error:${NC} $1"; }
print_warning() { echo -e "${YELLOW}Warning:${NC} $1"; }
print_info() { echo -e "${CYAN}Info:${NC} $1"; }

check_script() {
  local script_path="$1"
  if [ ! -f "$script_path" ]; then
    print_error "Script not found: $script_path"
    return 1
  fi
  if [ ! -x "$script_path" ]; then
    chmod +x "$script_path"
  fi
  return 0
}

run_script() {
  local script_path="$1"
  shift || true
  if check_script "$script_path"; then
    bash "$script_path" "$@"
    return $?
  fi
  return 1
}
