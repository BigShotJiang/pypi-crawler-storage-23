$tokenFile = "$env:USERPROFILE\.local\share\com.vercel.cli\auth.json"
$altPath = "$env:APPDATA\com.vercel.cli\auth.json"
$token = $null
if (Test-Path $tokenFile) { $tokenData = Get-Content $tokenFile -Raw | ConvertFrom-Json; $token = $tokenData.token; Write-Host "Token from local share" }
elseif (Test-Path $altPath) { $tokenData = Get-Content $altPath -Raw | ConvertFrom-Json; $token = $tokenData.token; Write-Host "Token from appdata" }
else { Get-ChildItem -Path $env:USERPROFILE -Recurse -Filter "auth.json" -ErrorAction SilentlyContinue | Where-Object { $_.FullName -like "*vercel*" } | ForEach-Object { Write-Host "Found: $($_.FullName)" }; exit 1 }
$h = @{ Authorization = "Bearer $token"; "Content-Type" = "application/json" }
$tid = "team_cGFXe2xrRySciNomITsbHNPE"
$ps = (Invoke-RestMethod -Uri "https://api.vercel.com/v9/projects?teamId=$tid" -Headers $h).projects
foreach ($p in $ps) { Write-Host "$($p.name) $($p.id)" }
foreach ($pn in @("morphism-web","morphism")) { $x=$ps|Where-Object{$_.name -eq $pn}; if($x){ foreach($d in @("morphism.systems","www.morphism.systems")){ try{ Invoke-RestMethod -Method DELETE -Uri "https://api.vercel.com/v9/projects/$($x.id)/domains/${d}?teamId=$tid" -Headers $h|Out-Null; Write-Host "DEL $d from $pn" }catch{ Write-Host "SKIP $d from $pn" } } } }
$hub=$ps|Where-Object{$_.name -eq "morphism-hub"}
if($hub){ foreach($d in @("morphism.systems","www.morphism.systems")){ try{ Invoke-RestMethod -Method POST -Uri "https://api.vercel.com/v10/projects/$($hub.id)/domains?teamId=$tid" -Headers $h -Body "{`"name`":`"$d`"}" -ContentType "application/json"|Out-Null; Write-Host "ADD $d to morphism-hub" }catch{ Write-Host "ERR $d : $($_.Exception.Message)" } } }
Write-Host "DONE"
