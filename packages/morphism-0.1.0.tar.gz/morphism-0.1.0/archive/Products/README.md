# Products

**Category:** Production Software
**Purpose:** Production-ready applications and services for end users

---

## 📋 Overview

This directory contains production software projects following best practices for deployment, monitoring, and user experience.

### Characteristics

- Production-ready code
- Full test coverage
- CI/CD pipelines
- Monitoring and observability
- User documentation
- Production deployment

---

## 🏗️ Projects

### hub/
**Status:** ✅ Active - Production
**Type:** Web Application
**Stack:** Next.js + Supabase + Tailwind CSS
**Deployment:** Vercel
**URL:** https://hub.morphism.systems (production)

Morphism Hub - central platform for the morphism ecosystem. Provides user dashboard, project management, and integration with morphism tools.

**Key Features:**
- User authentication and profiles
- Project management dashboard
- Real-time collaboration
- Integration with morphism framework

**Quick Start:**
```bash
cd Products/hub
pnpm install
cp .env.local.example .env.local
# Edit .env.local with your credentials
pnpm dev
```

**Documentation:**
- [Architecture](./hub/docs/ARCHITECTURE.md)
- [Deployment](./hub/DEPLOYMENT_STATUS.md)
- [Development](./hub/README.md)

---

## 📐 Structure Standards

All product projects follow the `product-web` or `product-cli` template:

```
Products/{project}/
├── README.md              # Project overview
├── src/                   # Source code
├── tests/                 # Test suites
├── docs/                  # Documentation
│   ├── ARCHITECTURE.md
│   ├── API.md
│   ├── DEPLOYMENT.md
│   └── DEVELOPMENT.md
├── config/                # Configuration
└── public/                # Static assets (web)
```

---

## 🚀 Getting Started

See individual project READMEs for setup instructions.

### Common Prerequisites

- Node.js 18+
- pnpm 9+
- Git

### Development Workflow

1. Clone repository
2. Install dependencies: `pnpm install`
3. Set up environment: Copy `.env.example` to `.env.local`
4. Start dev server: `pnpm dev`
5. Run tests: `pnpm test`
6. Build: `pnpm build`

---

## 📚 Documentation

- [Template Guide](../.morphism/templates/README.md)
- [Workspace Guide](../docs/WORKSPACE_GUIDE.md)
- [Morphism Framework](../morphism/MORPHISM.md)

---

**Maintained by:** Morphism Team
