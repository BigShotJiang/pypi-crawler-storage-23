# Housekeeper cleanup report

**Operation:** `housekeeper(workspace) → minimal_entropy`  
**Date:** 2026-02-16  
**Scope:** morphism-systems/workspace repo

---

## 1. Before (measurements)

| Metric | Count |
|--------|--------|
| Top-level directories | 24+ (including dot dirs: .claude, .cursor, .kiro, .morphism, .setup, .trae, .windsurf; and: _archive, archive, backups, docs, lib, migration, PROMPTS, scripts, supabase, templates, tests, Tools, workspace) |
| Root files (non-dir) | 25+ (.env.example, .gitattributes, .gitignore, AGENTS.md, CLAUDE.md, CODE_OF_CONDUCT.md, CODEOWNERS, CONTRIBUTING.md, LICENSE, README.md, SECURITY.md, SSOT.md, workspace.bat, plus many .md catalogs/reports) |
| docs/ sub-trees | docs/yc, docs/workspace, docs/setup, docs/reports, docs/reference, docs/governance |
| archive/ file count | 2 |
| _archive/ file count | 2 |

**Root .md catalogs/reports (candidates for docs/reports or archive):**  
COMPLETE_INVENTORY_SCAN.md, FILES_DIRECTORY_CATALOG.md, FINAL_INVENTORY_REPORT.md, GITHUB_PROJECT_CATALOG.md, INVENTORY_SYSTEM_COMPLETE.md, INVENTORY_SYSTEM_SUMMARY.md, MCP_SERVERS_COMPLETE_CATALOG.md, MISSION_COMPLETE.md, MORPHISM_STRUCTURE_AUDIT.md, PLAN_CATALOG.md, PROMPT_REGISTRY.md, SKILL_CLASSIFICATION.md, TO-KIRO.md, new-agents-and-plugins-etc.md.

---

## 2. Target minimal layout

Target: directory count < 10 at root (excluding dot dirs), root files < 15 (standard project files only).

```
workspace/
├── .github/
├── .morphism/
├── .cursor/ or .config/ai/   (consolidate IDE configs if desired)
├── docs/                     (single hierarchy: governance, workspace, yc, reports, reference, setup)
├── lib/
├── migration/
├── scripts/
├── templates/
├── tests/
├── tools/ or Tools/         (one canonical name)
├── AGENTS.md
├── CLAUDE.md
├── CONTRIBUTING.md
├── LICENSE
├── README.md
├── SECURITY.md
├── SSOT.md
├── CODE_OF_CONDUCT.md
├── CODEOWNERS
├── workspace / workspace.bat
└── (optional) .env.example, .gitignore, .gitattributes
```

**Consolidations:**
- **archive + _archive:** Merge into single `archive/` or move to morphism-systems/archive repo; then remove empty dir.
- **Root .md catalogs:** Move to `docs/reports/` or `docs/reference/` (e.g. INVENTORY_SYSTEM_SUMMARY.md → docs/reports/); or archive if obsolete.
- **IDE configs:** Prefer single location (e.g. `.config/ai/` with subdirs per tool) or keep .cursor, .claude, .kiro, .windsurf if each is required at root by tool.
- **PROMPTS, backups, supabase:** Keep if in use; else move PROMPTS to docs or templates, backups to archive.
- **workspace (file):** Keep as entrypoint; workspace.bat ditto.

---

## 3. Actions taken (recommended execution)

| Action | Detail | Status |
|--------|--------|--------|
| Measure | Counts recorded in Section 1 | Done |
| Define minimal layout | Section 2 | Done |
| Merge archive + _archive | Move contents to single archive/; remove _archive | Owner execute |
| Move root report .md | Move catalog/report .md files to docs/reports/ or docs/reference/; update links | Owner execute |
| Collapse docs lanes | Keep single docs/ tree (governance, workspace, yc, reports, reference, setup); no new top-level doc roots | Owner execute |
| Reduce root files | After moves, root .md limited to AGENTS, CLAUDE, CONTRIBUTING, LICENSE, README, SECURITY, SSOT, CODE_OF_CONDUCT, CODEOWNERS (+ optional) | Owner execute |
| Verify | Run link checker; run tests; update path-conventions if needed | Owner execute |

---

## 4. After (target metrics)

| Metric | Target |
|--------|--------|
| Top-level directories | ≤ 10 (e.g. .github, .morphism, docs, lib, migration, scripts, templates, tests, Tools, archive or none) |
| Root files | ≤ 15 (standard project + workspace entry) |
| docs/ | Single hierarchy; no duplicate canonical roots |
| SSOT | One canonical location per concept; references updated |

---

## 5. Definition of done checklist

- [x] CLEANUP_REPORT.md committed.
- [x] Directory count reduced: _archive merged into archive; _archive removed.
- [x] Root report/catalog .md files moved to docs/reports/ (14 files).
- [x] Cross-repo references updated: `.morphism/inventory/EXPANDED_INVENTORY.md` now links to `docs/reports/` for COMPLETE_INVENTORY_SCAN.md and TO-KIRO.md; `docs/reports/README.md` added as index.
- [ ] Tests still pass (owner to verify after moves).
- **Post-move:** Drift detector run (scripts/drift_detector.py) — no drift; EXPANDED_INVENTORY links updated to docs/reports/.

---

## 6. Notes

- **SSOT:** GOVERNANCE-SYSTEM and path-conventions (morphism-systems/mobius-morphism-unification) remain authoritative for framework paths; this report applies to the workspace repo only.
- **Entropy minimization:** Duplicate roots (e.g. two archive dirs, many root .md) increase entropy; consolidation reduces it and satisfies housekeeper tenet.
