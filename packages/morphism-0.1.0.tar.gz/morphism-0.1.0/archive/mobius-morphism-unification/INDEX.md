# Index: How to work in this repo

**Open this repository as your workspace** (not the parent folder). All paths below are relative to the repo root.

---

## Start here

| Role | Start here |
|------|------------|
| **Human (first time)** | [README.md](README.md) → then [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md) (the company's police and housekeeper). |
| **AI / agent** | [morphism/AGENTS.md](morphism/AGENTS.md) and [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md). |
| **Claude / Cursor** | [CLAUDE.md](CLAUDE.md) (concise instructions for this repo). |

---

## Layout

This repo is the **morphism-systems** organization canonical unification repo. One repo, one workspace.

- **morphism/** — Standalone Morphism framework (theory, tenets, governance, scripts). Single governance entry: [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md).
- **integration/mobius/** — Möbius (company) integration: docs site, onboarding, roadmap, planning. Use this to teach and deploy Morphism with your team.

**Repo and org:** [morphism/docs/guides/repo-and-org.md](morphism/docs/guides/repo-and-org.md).

---

## Rules and execution

- **Task Plan:** [TASK-PLAN.md](TASK-PLAN.md) — prioritized todos and checklists; review before starting new work, update when goals change or when asked.
- **Rules:** [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md) links to AGENTS.md, standards, enforcement, housekeeping.
- **Context and IDE:** [morphism/docs/guides/context-optimization.md](morphism/docs/guides/context-optimization.md) (AI context, @-mentions), [morphism/docs/guides/ide-and-coding-tips.md](morphism/docs/guides/ide-and-coding-tips.md) (Cursor, coding conventions).
- **Cursor:** `.cursor/rules/morphism-governance.mdc` applies governance and agent rules in chat.
- **Before commit:** Run `scripts/governance-check.ps1` or `scripts/governance-check.sh` from repo root.
- **Execution checklist:** [integration/mobius/docs/docs/roadmap/execution-checklist.md](integration/mobius/docs/docs/roadmap/execution-checklist.md).

---

## Why open the repo as workspace?

Opening the **repo root** (this folder) as your workspace keeps paths consistent: `morphism/`, `integration/mobius/`, `scripts/` all resolve correctly. Opening a parent folder (e.g. Desktop or GitHub) can mix other directories and break relative links. Set things up for success: **File → Open Folder → select this repo.**

## Projects and Misc (outside this repo)

To treat **Projects** as its own workspace and move unrelated items out of the way: see [templates/MISC-AND-PROJECTS-SETUP.md](templates/MISC-AND-PROJECTS-SETUP.md). Copy [templates/workspace-projects/](templates/workspace-projects/) into your Projects folder, then use **Desktop/Misc** (or similar) for anything unrelated. **What to do with files already in Projects** (before opening this repo as workspace): [integration/mobius/planning/PROJECTS-CLEANUP-AND-NEXT-STEPS.md](integration/mobius/planning/PROJECTS-CLEANUP-AND-NEXT-STEPS.md).
