# Instructions for Claude / Cursor (this repo)

- **Repo:** Morphism framework + Möbius (company) integration. morphism-systems org; this repo = canonical unification (morphism/ + integration/mobius/). Open **this repo root** as the workspace.
- **Governance:** Single entry is [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md). It ties together rules, theory, enforcement, secrets, agents, schemas, and housekeeping.
- **Agent rules:** [morphism/AGENTS.md](morphism/AGENTS.md). Follow theory ([morphism/docs/theory/](morphism/docs/theory/)), tenets ([morphism/docs/vision/tenets.md](morphism/docs/vision/tenets.md)), and [morphism/docs/guides/enforcement.md](morphism/docs/guides/enforcement.md).
- **Paths:** In-repo use `morphism/`, `integration/mobius/`, `scripts/`. Workspace-only (not in repo): `.morphism/`, `.kiro/`, `Tools/` — document as "workspace:" and do not assume they exist in this clone.
- **Validation:** Before commit, run `scripts/governance-check.ps1` or `scripts/governance-check.sh`. Proof backlog: `morphism/scripts/validate_proof_backlog.py`.
- **Index:** [INDEX.md](INDEX.md) has the full entry-point table for humans and agents.
- **Task Plan:** [TASK-PLAN.md](TASK-PLAN.md) — single unified plan; review before starting new work, update when goals change or when asked.
- **Context:** Use [morphism/docs/guides/context-optimization.md](morphism/docs/guides/context-optimization.md) for @-mentions and keeping context clear. **IDE and coding:** [morphism/docs/guides/ide-and-coding-tips.md](morphism/docs/guides/ide-and-coding-tips.md).
- **Cursor rules:** `.cursor/rules/morphism-governance.mdc` applies in Cursor and points to GOVERNANCE-SYSTEM and AGENTS.
