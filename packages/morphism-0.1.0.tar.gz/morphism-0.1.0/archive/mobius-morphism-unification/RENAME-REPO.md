# Rename this repo to `morphism`

To make "morphism under GitHub" the repo name in the morphism-systems org:

**On GitHub (web):**
1. Open the repo on GitHub.
2. Settings → General → Repository name.
3. Change `mobius-morphism-unification` to `morphism` and save.

**With GitHub CLI (if installed):**
```bash
gh repo rename morphism --repo morphism-systems/mobius-morphism-unification
```

**After renaming:** Update your local remote if you use a full URL:
```bash
git remote set-url origin https://github.com/morphism-systems/morphism.git
# or
git remote set-url origin git@github.com:morphism-systems/morphism.git
```

The layout (morphism/ + integration/mobius/) does not depend on the repo name.
