# Build the Möbius–Morphism docs site

From this directory (`integration/mobius/docs/`):

```bash
# Install MkDocs and Material theme if needed
pip install mkdocs mkdocs-material

# Build static site
mkdocs build

# Output: integration/mobius/docs/site/
```

**If `mkdocs` is not in PATH:** use Python module form from repo root, or run from this directory:
```bash
# Option A: from repo root (or use scripts/build-docs.ps1 or build-docs.sh)
python -m mkdocs build -f integration/mobius/docs/mkdocs.yml

# Option B: from this directory (integration/mobius/docs/) — avoids Python path issues
cd integration/mobius/docs
mkdocs build
# Site written to integration/mobius/docs/site/
```
If Python fails from repo root (e.g. "No module named 'encodings'"), use Option B or a dedicated venv.

**From repo root (script):**
```powershell
# Windows
.\scripts\build-docs.ps1
```
```bash
# WSL / Linux / macOS
./scripts/build-docs.sh
```

**Serve locally:**
```bash
mkdocs serve
# Open http://127.0.0.1:8000
```
