# Integrating Morphism with Möbius

**How to use the Morphism framework within the Möbius platform**

---

## Overview

Morphism is the mathematical foundation that powers Möbius's AI governance. This guide explains how to integrate Morphism's convergence guarantees into Möbius agents and services.

---

## Architecture

```
Möbius Platform
├── Agents (your AI agents)
├── Morphism Layer (governance + monitoring)
│   ├── Governance Operators (κ < 1)
│   ├── Drift Detection
│   └── Self-Healing
└── Infrastructure (APIs, databases, etc.)
```

**Morphism sits between your agents and infrastructure**, ensuring all agents have convergence guarantees.

---

## Integration Patterns

### Pattern 1: Wrap Existing Agents

**Before (no guarantees):**
```typescript
class CustomerSupportAgent {
  async respond(query: string): Promise<string> {
    // Agent logic
    return response;
  }
}
```

**After (with Morphism):**
```typescript
import { GovernanceOperator } from '@morphism-systems/core';
import { DriftDetector } from '@morphism-systems/monitoring';

class CustomerSupportAgent {
  private operator: GovernanceOperator;
  private detector: DriftDetector;

  constructor() {
    this.operator = new GovernanceOperator({ kappa: 0.80 });
    this.detector = new DriftDetector({ threshold: 0.15 });
  }

  async respond(query: string, policy: SupportPolicy): Promise<Response> {
    // 1. Check drift
    const drift = await this.detector.check('customer-support');
    if (drift > 0.15) {
      await this.operator.resetToFixedPoint();
    }

    // 2. Apply governance
    const governedPolicy = await this.operator.apply(policy);

    // 3. Generate response with governed policy
    const response = await this.generateResponse(query, governedPolicy);

    // 4. Return with guarantees
    return {
      response,
      metadata: {
        convergenceGuarantee: this.operator.getConvergenceProperties(),
        driftScore: drift,
      },
    };
  }

  private async generateResponse(query: string, policy: SupportPolicy): Promise<string> {
    // Your existing agent logic
    return "Response";
  }
}
```

---

### Pattern 2: Möbius Agent Base Class

Create a base class for all Möbius agents:

```typescript
// mobius/base-agent.ts
import { GovernanceOperator } from '@morphism-systems/core';
import { DriftDetector } from '@morphism-systems/monitoring';

export abstract class MobiusAgent<TInput, TOutput, TPolicy> {
  protected operator: GovernanceOperator;
  protected detector: DriftDetector;
  protected agentId: string;
  protected kappa: number;

  constructor(agentId: string, kappa: number = 0.85) {
    if (kappa >= 1) {
      throw new Error('κ must be < 1 for convergence guarantee');
    }
    
    this.agentId = agentId;
    this.kappa = kappa;
    this.operator = new GovernanceOperator({ kappa });
    this.detector = new DriftDetector({ threshold: 0.15 });
  }

  async execute(input: TInput, policy: TPolicy): Promise<MobiusResponse<TOutput>> {
    // 1. Pre-execution: Check drift
    const drift = await this.detector.check(this.agentId);
    if (drift > 0.15) {
      console.warn(`[${this.agentId}] Drift detected: ${drift.toFixed(4)}`);
      await this.operator.resetToFixedPoint();
    }

    // 2. Apply governance
    const governedPolicy = await this.operator.apply(policy);

    // 3. Execute agent logic (implemented by subclass)
    const output = await this.process(input, governedPolicy);

    // 4. Post-execution: Return with guarantees
    return {
      output,
      metadata: {
        agentId: this.agentId,
        convergenceGuarantee: this.operator.getConvergenceProperties(),
        driftScore: drift,
        timestamp: new Date().toISOString(),
      },
    };
  }

  // Subclasses implement this
  protected abstract process(input: TInput, policy: TPolicy): Promise<TOutput>;
}

export interface MobiusResponse<T> {
  output: T;
  metadata: {
    agentId: string;
    convergenceGuarantee: {
      kappa: number;
      convergenceRate: string;
      robustness: number;
      convergenceSpeed: string;
    };
    driftScore: number;
    timestamp: string;
  };
}
```

**Usage:**
```typescript
class CodeReviewAgent extends MobiusAgent<Code, Review, ReviewPolicy> {
  constructor() {
    super('code-reviewer', 0.85);
  }

  protected async process(code: Code, policy: ReviewPolicy): Promise<Review> {
    // Your code review logic
    return {
      passed: true,
      violations: [],
      suggestions: [],
    };
  }
}

// Use it
const agent = new CodeReviewAgent();
const result = await agent.execute(code, policy);
// result.metadata.convergenceGuarantee.kappa === 0.85
// result.metadata.driftScore < 0.15 (guaranteed)
```

---

### Pattern 3: Möbius Service Integration

Integrate at the service level:

```typescript
// mobius/services/agent-service.ts
import { MobiusAgent } from '../base-agent';

export class AgentService {
  private agents: Map<string, MobiusAgent<any, any, any>> = new Map();

  registerAgent(agent: MobiusAgent<any, any, any>) {
    this.agents.set(agent.agentId, agent);
  }

  async executeAgent<TInput, TOutput>(
    agentId: string,
    input: TInput,
    policy: any
  ): Promise<MobiusResponse<TOutput>> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error(`Agent ${agentId} not found`);
    }

    return await agent.execute(input, policy);
  }

  async checkAllAgentsDrift(): Promise<DriftReport[]> {
    const reports: DriftReport[] = [];
    
    for (const [agentId, agent] of this.agents) {
      const drift = await agent.detector.check(agentId);
      reports.push({
        agentId,
        driftScore: drift,
        alert: drift > 0.15,
        timestamp: new Date().toISOString(),
      });
    }

    return reports;
  }
}

interface DriftReport {
  agentId: string;
  driftScore: number;
  alert: boolean;
  timestamp: string;
}
```

---

## Möbius Dashboard Integration

### Real-time Monitoring

```typescript
// mobius/dashboard/monitoring.ts
import { AgentService } from '../services/agent-service';

export class MobiusDashboard {
  constructor(private agentService: AgentService) {}

  async getDashboardData(): Promise<DashboardData> {
    const driftReports = await this.agentService.checkAllAgentsDrift();
    
    return {
      agents: driftReports.map(r => ({
        id: r.agentId,
        status: r.alert ? 'DRIFT_DETECTED' : 'NORMAL',
        driftScore: r.driftScore,
        lastChecked: r.timestamp,
      })),
      summary: {
        total: driftReports.length,
        healthy: driftReports.filter(r => !r.alert).length,
        drifting: driftReports.filter(r => r.alert).length,
      },
    };
  }
}

interface DashboardData {
  agents: Array<{
    id: string;
    status: 'NORMAL' | 'DRIFT_DETECTED';
    driftScore: number;
    lastChecked: string;
  }>;
  summary: {
    total: number;
    healthy: number;
    drifting: number;
  };
}
```

---

## Configuration

### Möbius Config File

```typescript
// mobius.config.ts
export const mobiusConfig = {
  morphism: {
    // Default κ for all agents
    defaultKappa: 0.85,
    
    // Drift detection threshold
    driftThreshold: 0.15,
    
    // Agent-specific overrides
    agents: {
      'code-reviewer': { kappa: 0.85 },
      'content-moderator': { kappa: 0.75 },
      'customer-support': { kappa: 0.80 },
    },
  },
  
  monitoring: {
    // Check drift every 5 minutes
    checkInterval: 300000,
    
    // Alert channels
    alerts: {
      email: 'alerts@mobius.com',
      slack: '#agent-monitoring',
    },
  },
};
```

---

## Testing

### Unit Tests

```typescript
import { describe, it, expect } from 'vitest';
import { CodeReviewAgent } from './code-review-agent';

describe('CodeReviewAgent', () => {
  it('should have convergence guarantee', async () => {
    const agent = new CodeReviewAgent();
    const result = await agent.execute(code, policy);
    
    expect(result.metadata.convergenceGuarantee.kappa).toBeLessThan(1);
    expect(result.metadata.convergenceGuarantee.kappa).toBeGreaterThanOrEqual(0);
  });

  it('should detect drift', async () => {
    const agent = new CodeReviewAgent();
    const result = await agent.execute(code, policy);
    
    expect(result.metadata.driftScore).toBeDefined();
    expect(result.metadata.driftScore).toBeGreaterThanOrEqual(0);
  });

  it('should self-heal when drift detected', async () => {
    const agent = new CodeReviewAgent();
    
    // Simulate drift
    agent.detector.history.set('code-reviewer', [0.25]); // Above threshold
    
    const result = await agent.execute(code, policy);
    
    // Should have reset to fixed point
    expect(result.metadata.driftScore).toBeLessThan(0.15);
  });
});
```

---

## Deployment

### 1. Install Morphism Packages

```bash
npm install @morphism-systems/core @morphism-systems/monitoring @morphism-systems/governance
```

### 2. Create Base Agent Class

Copy `mobius/base-agent.ts` to your project.

### 3. Migrate Existing Agents

```typescript
// Before
class MyAgent {
  async execute(input: any): Promise<any> {
    return result;
  }
}

// After
class MyAgent extends MobiusAgent<Input, Output, Policy> {
  constructor() {
    super('my-agent', 0.85);
  }

  protected async process(input: Input, policy: Policy): Promise<Output> {
    return result;
  }
}
```

### 4. Set Up Monitoring

```typescript
import { AgentService } from './services/agent-service';
import { MobiusDashboard } from './dashboard/monitoring';

const service = new AgentService();
const dashboard = new MobiusDashboard(service);

// Register agents
service.registerAgent(new CodeReviewAgent());
service.registerAgent(new ContentModeratorAgent());

// Start monitoring
setInterval(async () => {
  const data = await dashboard.getDashboardData();
  console.log('Dashboard:', data);
}, 300000); // Every 5 minutes
```

---

## Best Practices

### 1. Choose κ Appropriately

- **Critical agents** (security, compliance): κ = 0.70-0.80 (fast convergence)
- **Standard agents** (code review, support): κ = 0.80-0.85 (balanced)
- **Experimental agents** (research, testing): κ = 0.85-0.95 (slow but flexible)

### 2. Monitor Drift Regularly

```typescript
// Check drift every 5 minutes
setInterval(async () => {
  const reports = await service.checkAllAgentsDrift();
  const alerts = reports.filter(r => r.alert);
  
  if (alerts.length > 0) {
    console.warn('Drift alerts:', alerts);
    // Send notifications
  }
}, 300000);
```

### 3. Log Convergence Properties

```typescript
const result = await agent.execute(input, policy);
console.log('Convergence:', result.metadata.convergenceGuarantee);
// {
//   kappa: 0.85,
//   convergenceRate: 'O(0.85^n)',
//   robustness: 0.075,
//   convergenceSpeed: 'moderate'
// }
```

### 4. Test Convergence

```typescript
it('should converge to fixed point', async () => {
  const agent = new MyAgent();
  const operator = agent.operator;
  
  const result = await operator.findFixedPoint(initialPolicy);
  
  expect(result.converged).toBe(true);
  expect(result.iterations).toBeLessThan(100);
});
```

---

## Troubleshooting

### "κ must be < 1"
- Check your agent's κ value
- Ensure it's between 0 and 1 (exclusive of 1)

### "Drift score always high"
- Check if agent logic is deterministic
- Verify policy is stable
- Consider lowering κ for faster convergence

### "Slow convergence"
- Lower κ (e.g., 0.85 → 0.75)
- Check if fixed point exists
- Verify governance operator is correct

---

## Summary

**Integrating Morphism with Möbius:**

1. **Install packages:** `@morphism-systems/core`, `@morphism-systems/monitoring`
2. **Create base class:** `MobiusAgent<TInput, TOutput, TPolicy>`
3. **Extend for each agent:** Implement `process()` method
4. **Set up monitoring:** `AgentService` + `MobiusDashboard`
5. **Configure:** Set κ values and drift thresholds
6. **Test:** Verify convergence guarantees
7. **Deploy:** Monitor drift, self-heal automatically

**Result:** All Möbius agents have mathematical convergence guarantees (κ < 1).
