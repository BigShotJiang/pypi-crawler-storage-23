# Möbius integration of Morphism

This directory contains the **Möbius** (company) integration of the Morphism framework: how Morphism is embedded in the Möbius platform, plus docs, roadmap, and onboarding.

## Contents

- **[MOBIUS-MORPHISM-UNIFICATION.md](MOBIUS-MORPHISM-UNIFICATION.md)** — Integration guide (patterns, base agent, architecture)
- **docs/** — MkDocs site: vision, team, theory, integration, roadmap, standards, patents, papers, about
- **onboarding/** — Teaching materials, morphism-onboarding, competitive intel, run sheets
- **integration/** — Implementation patterns (e.g. base-agent.md)

## Morphism framework

The standalone Morphism framework (theory, tenets, quick start) lives at:

- **[../../morphism/](../../morphism/)** — Product overview, WHAT-IS-MORPHISM, theory, philosophy, tenets, getting-started

Use the framework docs for the math and guarantees; use this directory for Möbius-specific unification, team API, and execution roadmap.

## Execution checklist

**Use the CTO/CSO readiness plan as the master execution checklist:** [planning/CTO-READINESS-PLAN.md](planning/CTO-READINESS-PLAN.md). It covers repo consolidation, teaching materials, mkdocs deploy, dashboards, and next actions.

**For extremely detailed, agent/skill-level execution:** [planning/DETAILED-EXECUTION-PLAN.md](planning/DETAILED-EXECUTION-PLAN.md) — defines agents (Planner, Executor, Inventory Steward, Doc Publisher, Validator, Onboarding Guide), skills (e.g. register-component, build-deploy-mkdocs, reconcile-inventory-repo), and phased tasks with inventory baseline. Do not edit the plan file during execution; use a separate execution log.

**In-repo component inventory:** [planning/COMPONENT-INVENTORY.md](planning/COMPONENT-INVENTORY.md) — plans, integration patterns, onboarding, MkDocs docs, morphism/ framework, and orchestration/workflow entries. Execution progress: [planning/EXECUTION-LOG-2026-02-15.md](planning/EXECUTION-LOG-2026-02-15.md). **Parallel orchestration run:** [planning/ORCHESTRATION-RUN-2026-02-15.md](planning/ORCHESTRATION-RUN-2026-02-15.md).

## Quick links

- [Unification overview](docs/docs/vision/unification-overview.md)
- [Team API](docs/docs/team/team-api.md)
- [Base agent pattern](integration/base-agent.md)
- [Start here (onboarding)](onboarding/00-start-here.md)
- [Build docs site](docs/BUILD.md) — `mkdocs build` from `docs/`
