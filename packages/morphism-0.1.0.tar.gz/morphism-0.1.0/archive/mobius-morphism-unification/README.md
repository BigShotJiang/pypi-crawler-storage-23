# Morphism (repo)

**Start here:** [INDEX.md](INDEX.md) — how to work in this repo (open this repo as your workspace). For governance and rules: [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md).

This repository contains:

1. **[morphism/](morphism/)** — **Morphism** as a complete standalone project: AI governance with mathematical convergence guarantees. Framework-only docs (theory, philosophy, tenets, getting-started). No company-specific content.

2. **[integration/mobius/](integration/mobius/)** — **Möbius** (company) integration of Morphism: unification guide, MkDocs site, onboarding, roadmap, and implementation patterns for embedding Morphism in the Möbius platform.

## Entry points

| If you want to… | Start here |
|-----------------|------------|
| **Governance, rules, police & housekeeper** | [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md) |
| **Agent / AI instructions** | [morphism/AGENTS.md](morphism/AGENTS.md) · [CLAUDE.md](CLAUDE.md) |
| **Use or understand Morphism (framework only)** | [morphism/README.md](morphism/README.md) · [What is Morphism?](morphism/WHAT-IS-MORPHISM.md) |
| **Integrate Morphism with Möbius** | [integration/mobius/README.md](integration/mobius/README.md) · [MOBIUS-MORPHISM-UNIFICATION.md](integration/mobius/MOBIUS-MORPHISM-UNIFICATION.md) |
| **Onboard (Möbius team)** | [integration/mobius/onboarding/00-start-here.md](integration/mobius/onboarding/00-start-here.md) |
| **Run the execution checklist** | [integration/mobius/docs/docs/roadmap/execution-checklist.md](integration/mobius/docs/docs/roadmap/execution-checklist.md) |
| **Build or deploy the docs site** | [integration/mobius/docs/BUILD.md](integration/mobius/docs/BUILD.md) — build from repo root: `python -m mkdocs build -f integration/mobius/docs/mkdocs.yml` |

## Docs site

- **Build:** From repo root run `python -m mkdocs build -f integration/mobius/docs/mkdocs.yml` (requires `pip install mkdocs mkdocs-material`). Output: `integration/mobius/docs/site/`.
- **Scripts:** Or use `.\scripts\build-docs.ps1` (Windows) or `./scripts/build-docs.sh` (WSL/Linux/macOS) from repo root.
- **Deploy:** After build, use `mkdocs gh-deploy` from `integration/mobius/docs/` for GitHub Pages, or deploy `site/` to Vercel/Netlify. Docs URL: *(set after first deploy)*.

## Set up for success

- **Open this repo as your workspace** (File → Open Folder → this repo). Do not open the parent folder; paths and links assume repo root.
- **Clear instructions:** [INDEX.md](INDEX.md) (entry points), [CLAUDE.md](CLAUDE.md) (for AI), [morphism/AGENTS.md](morphism/AGENTS.md) (agent rules). Everything in GitHub so you can share and teach via integration/mobius with your team.

## Quick links

- **Governance:** [morphism/GOVERNANCE-SYSTEM.md](morphism/GOVERNANCE-SYSTEM.md)
- **Framework:** [morphism/README.md](morphism/README.md) · [What is Morphism?](morphism/WHAT-IS-MORPHISM.md)
- **Möbius integration:** [integration/mobius/README.md](integration/mobius/README.md) · [MOBIUS-MORPHISM-UNIFICATION.md](integration/mobius/MOBIUS-MORPHISM-UNIFICATION.md)
- **Planning / historical:** [integration/mobius/planning/](integration/mobius/planning/) (CTO-READINESS-PLAN, PHASE-*, conversation export)
