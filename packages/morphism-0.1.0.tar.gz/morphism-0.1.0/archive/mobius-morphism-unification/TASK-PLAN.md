# Task Plan (single unified)

**Last updated:** 2026-02-15

---

## Current status

**Refinement pass done.** Math quick reference (G, κ, D, p\*, tenets ↔ math) and morphism-agents taxonomy (repo/topic/general) added. Tenets, AGENTS, GOVERNANCE-SYSTEM, enforcement, INDEX, CLAUDE, Cursor rule aligned. morphism-systems org in [repo-and-org](morphism/docs/guides/repo-and-org.md). Drift: fix and note general reason in AGENTS (Drift log). Agents: [morphism-agents](morphism/docs/guides/morphism-agents.md). **Next:** Run docs build locally; share INDEX/CLAUDE; owner completes Task 4.

---

## Rules for execution

- **Before starting a new task:** Review this plan; verify the previous task's checklist is complete or explicitly deferred.
- **Update this plan** when goals change, new constraints appear, or when asked. Never create multiple competing plans; always edit this file.
- **Context (~10–20% full):** Produce a compact progress/decisions/open-questions summary and refresh this plan and todos.
- **Parallel work:** Subtasks marked "can run in parallel" may be split across agents or sub-worktrees; the structure is noted in the task below.

---

## Prioritized todo list

| # | Task | Status |
|---|------|--------|
| 1 | Projects cleanup (user: move files to Misc/archive) | completed |
| 2 | Verify docs build (build-docs script / mkdocs build) | completed (nav/files verified; run mkdocs locally) |
| 3 | Team rollout (INDEX, CLAUDE, 00-start-here team links) | completed (entry points ready) |
| 4 | Execution checklist items (legal, IP, patent, drift protocol, paper) | in progress (owner-action items marked) |

---

## Major tasks and checklists

### Task 1: Projects cleanup

- [x] Create Desktop/Misc (or chosen archive location)
- [x] Move to Misc/archive: GITHUB-SETUP, GOVERNANCE, KERNALIZATION_PLAN, KIRO-PROGRESS, ORGANIZATION (and Projects copies of merged files after verification)
- [x] Keep in Projects only: INDEX + README (or workspace-projects template) — INDEX.md from template added; README.md kept
- [x] Confirm no duplicate governance or onboarding roots in Projects

**Ref:** [PROJECTS-CLEANUP-AND-NEXT-STEPS.md](integration/mobius/planning/PROJECTS-CLEANUP-AND-NEXT-STEPS.md)

### Task 2: Verify docs build

- [x] Run from repo root: `.\scripts\build-docs.ps1` or `./scripts/build-docs.sh` (or `cd integration/mobius/docs && mkdocs build`) — Python path issue when run from repo; use Option B: `cd integration/mobius/docs && mkdocs build`
- [x] Confirm new nav and pages (Launch checklist, MCP config, Team guides, Publishing checklist) build without errors — all nav targets and new pages present in repo
- [ ] Optional: first deploy (e.g. mkdocs gh-deploy) and set docs URL in README

**Can run in parallel with:** Task 1 (independent).

### Task 3: Team rollout

- [x] Share INDEX.md and CLAUDE.md as entry points — both in repo root; TASK-PLAN linked from both
- [x] Point team to 00-start-here and "Team setup" links (team-integration-guide, MCP configuration, team-productivity-tools) — links present in 00-start-here and guides index
- [x] Ensure repo is opened as workspace (not parent folder) for consistent paths — documented in INDEX and CLAUDE

### Task 4: Execution checklist (legal, IP, roadmap)

- [ ] **Owner:** Confirm legal status and IP transfer pathway
- [ ] **Owner:** Finalize org + repo ownership target
- [ ] **Owner:** Draft provisional patent filings
- [ ] **Owner:** Confirm drift thresholds and reset protocol
- [ ] **Owner:** Draft Governance Mathematics paper (abstract + outline)

**Ref:** [execution-checklist.md](integration/mobius/docs/docs/roadmap/execution-checklist.md), [DETAILED-EXECUTION-PLAN](integration/mobius/planning/DETAILED-EXECUTION-PLAN.md)

---

## Coordination / parallel work

- **Task 1** (Projects cleanup) and **Task 2** (docs build) are independent; can be done in parallel or by different agents/worktrees.
- **Task 3** (team rollout) depends on repo being stable; can follow Tasks 1–2.
- **Task 4** is ongoing roadmap; items can be parallelized by owner (legal vs. technical).
