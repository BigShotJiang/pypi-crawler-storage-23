# Research

**Category:** Research Projects
**Purpose:** Mathematical formalization, theoretical work, and experimental research

---

## 📋 Overview

This directory contains research projects including mathematical formalizations in Lean 4, experimental algorithms, and theoretical explorations.

### Characteristics

- Proof-driven development
- Mathematical rigor
- Experimental implementations
- Research documentation
- Theory papers and proofs

---

## 🏗️ Projects

### llmworks/
**Status:** 🚧 Active - Experimental
**Type:** LLM Research & Experimentation
**Stack:** Python
**Purpose:** Large Language Model research, experimentation, and tooling

Experimental playground for LLM research including prompt engineering, model evaluation, and experimental architectures.

**Quick Start:**
```bash
cd Research/llmworks
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

---

### bolts/
**Status:** 🚧 Active - Experimental
**Type:** Experimental Project
**Stack:** To be determined
**Purpose:** Experimental features and prototypes

Early-stage experimental work and prototypes. Structure and purpose may evolve.

**Quick Start:**
```bash
cd Research/bolts
# Setup instructions to be added
```

---

## 📐 Structure Standards

Research projects follow the `research-math` or `research-experimental` template:

```
Research/{project}/
├── README.md              # Project overview
├── src/                   # Formalization/implementation
├── theory/                # Theoretical documentation
│   ├── background.md
│   ├── proofs.md
│   └── references.md
├── examples/              # Examples and tests
├── tests/                 # Property tests
└── docs/                  # Research documentation
```

---

## 🚀 Getting Started

### Prerequisites

For Lean 4 projects:
- Lean 4 toolchain
- Lake build system
- VS Code with Lean extension

For Python projects:
- Python 3.11+
- Poetry or pip
- Jupyter (optional)

### Creating New Research Project

```bash
# Use appropriate template
cp -r ../.morphism/templates/projects/research-math ./my-research
cd my-research
# Edit README.md and fill in template variables
```

---

## 📚 Documentation

- [Research Templates](../.morphism/templates/projects/)
- [Lean 4 Guide](../morphism/lab/proofs/README.md)
- [Morphism Framework](../morphism/MORPHISM.md)

---

**Maintained by:** Morphism Research Team
