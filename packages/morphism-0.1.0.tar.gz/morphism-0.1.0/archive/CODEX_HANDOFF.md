# Codex Implementation Handoff
**Date:** 2026-02-16
**Status:** Tier 1-2 Complete, Tier 3-4 Pending
**Next Agent:** Codex

---

## 🎯 Current Status

### ✅ Completed (Tier 1: Emergency & Tier 2: Foundation)

#### Tier 1 - Critical Security Fixes
- **SQL Injection:** Eliminated template literal interpolation in credentials API
- **Credential Exposure:** Removed 25+ hardcoded API keys from git history
- **Input Validation:** Added Zod schemas to all API endpoints
- **Git History:** Force-scrubbed all credential files from all commits

#### Tier 2 - Foundation Security/Quality
- **Rate Limiting:** Implemented sliding window (30 req/min, in-memory)
- **Security Headers:** Added 7 headers + CSP to all responses
- **Test Infrastructure:** Integrated vitest into CI pipeline
- **Error Handling:** Added error boundary component + API logging

### ⏳ Pending (Tier 3: Code Quality & Tier 4: Scalability)

#### Tier 3 (Code Quality - High Priority)
- [ ] CSRF Protection on POST/PUT/DELETE endpoints
- [ ] Sentry integration for production error tracking
- [ ] OpenAPI/Swagger documentation for 12 API endpoints
- [ ] Consolidate morphism/hub code duplication

#### Tier 4 (Scalability - Medium Priority)
- [ ] Production APM setup (distributed tracing)
- [ ] Real User Monitoring (Core Web Vitals)
- [ ] Automated dependency management
- [ ] Alert rules and incident response procedures

---

## 📂 Critical Files Modified

### Both morphism and hub repos (identical changes):

**Security Fixes:**
- `src/app/api/credentials/route.ts`
  - Line 333-335: Changed `exec_sql` RPC to `set_github_username`
  - Added Zod validation schemas (uuidSchema, getQuerySchema, createBodySchema, updateBodySchema)
  - Type-safe updates: `const updates: Record<string, unknown>`

- `.gitignore`
  - Added credential file patterns to prevent re-commitment

**New Rate Limiting:**
- `src/lib/rate-limit.ts` (new file)
  - Sliding window algorithm with in-memory Map
  - Function: `checkRateLimit(key, pathname)`
  - Default: 30 req/min, configurable per-route

- `src/middleware.ts` (modified)
  - Rate limit check after webhook bypass
  - Returns 429 with retry-after header

**Security Headers:**
- `next.config.ts` (modified)
  - Added async `headers()` function with 7 security headers
  - CSP with unsafe-inline (required for Next.js hydration)
  - Changed `eslint.ignoreDuringBuilds` to false

**Error Handling:**
- `src/components/error-boundary.tsx` (new file)
  - React class component with getDerivedStateFromError
  - Logs to console with structured prefix

- `src/app/(dashboard)/layout.tsx` (modified)
  - Wrapped {children} with ErrorBoundary component

- 7 API routes with error logging:
  - agents, assessments, keys, feedback, onboarding, drift-report, validate

**Testing:**
- `package.json` (modified)
  - Added `"test": "vitest run"` to scripts

- `.github/workflows/ci.yml` (modified)
  - Added `test` job running in parallel with build
  - Runs after lint-and-typecheck

### Deleted Files:
- All credential documentation removed from git history via git-filter-repo

---

## 🔧 Implementation Details for Tier 3

### 1. CSRF Protection (Estimated: 2-3 hours)

**Approach:** Double-submit cookie pattern
- Generate random CSRF token in server middleware
- Require token in X-CSRF-Token header for POST/PUT/DELETE
- Validate token matches cookie value

**Files to modify:**
- `src/middleware.ts` - Generate and set CSRF cookie
- `src/app/api/*/route.ts` (POST/PUT/DELETE handlers) - Validate token
- Client-side form helper - Read cookie and add to headers

**Example validation:**
```typescript
const token = request.headers.get('x-csrf-token');
const cookie = parseCookie(request.headers.get('cookie'), 'csrf-token');
if (token !== cookie) return NextResponse.json({ error: 'CSRF validation failed' }, { status: 403 });
```

### 2. Sentry Integration (Estimated: 1-2 hours)

**Setup steps:**
1. Create Sentry account and project
2. Install @sentry/nextjs: `npm install @sentry/nextjs`
3. Create `sentry.client.config.js` and `sentry.server.config.js`
4. Update `next.config.ts` to wrap with withSentryConfig
5. Update `error-boundary.tsx` to call Sentry.captureException
6. Add Sentry initialization to all 7 API routes

**Example:**
```typescript
import * as Sentry from '@sentry/nextjs';

export async function POST(req: NextRequest) {
  try {
    // ... existing code
  } catch (error) {
    Sentry.captureException(error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
```

**Key config:**
- Set tracesSampleRate to 0.1 (10% of transactions)
- Environment detection from VERCEL_ENV
- Attach Clerk user context for issue tracking

### 3. OpenAPI/Swagger Documentation (Estimated: 3-4 hours)

**Endpoints to document (12 total):**
1. POST /api/agents - Create agent
2. GET /api/agents/:id - Get agent
3. POST /api/assessments - Create assessment
4. GET /api/assessments/:id - Get assessment
5. POST /api/keys - Create encryption key
6. GET /api/keys - List keys
7. POST /api/credentials - Create credential
8. GET /api/credentials - List/get credential
9. PUT /api/credentials/:id - Update credential
10. DELETE /api/credentials/:id - Delete credential
11. POST /api/feedback - Submit feedback
12. POST /api/validate - Validate governance

**Tools:** Consider swagger-ui or OpenAPI generator
- Install: `npm install swagger-ui-react swagger-jsdoc`
- Create `lib/swagger.ts` with endpoint definitions
- Mount UI at `/api/docs`

### 4. Code Consolidation (Estimated: 4-6 hours)

**Current state:** morphism and hub are identical twins

**Options:**
- **Option A:** Create shared npm package (`@morphism-systems/sdk`)
  - Extract common utilities, types, database functions
  - Both repos depend on @morphism-systems/sdk
  - Reduces duplication, enables versioning

- **Option B:** Monorepo reorganization
  - Move to single repo with `apps/morphism` and `apps/hub`
  - Shared `packages/sdk` for common code
  - Single CI/CD pipeline

- **Recommendation:** Option A (shared npm package) - less disruptive

**First step:** Identify shared code patterns
- Encryption/decryption functions
- Supabase client initialization
- Zod validation schemas
- Error handling patterns

---

## 📋 Implementation Checklist for Codex

### Pre-Implementation
- [ ] Review this document completely
- [ ] Verify Tier 1-2 implementations in both repos
- [ ] Test rate limiting: send 31+ requests to /api/*, verify 429
- [ ] Verify security headers: `curl -i https://morphism.dev`
- [ ] Check CI pipeline runs tests successfully

### Tier 3 Implementation
- [ ] CSRF protection: implement in middleware + 5 POST/PUT/DELETE routes
- [ ] Sentry setup: account creation → integration in error-boundary + 7 API routes
- [ ] OpenAPI docs: create swagger definitions + mount UI
- [ ] Code consolidation: extract shared package (Option A recommended)

### Pre-Deployment Verification
- [ ] All tests pass: `npm test`
- [ ] No ESLint errors: `npm run lint`
- [ ] No TypeScript errors: `npm run type-check`
- [ ] CSRF token flow works end-to-end
- [ ] Sentry captures errors in staging
- [ ] OpenAPI docs render at /api/docs
- [ ] Rate limiting still works with new changes

### Deployment
- [ ] Merge Tier 3 changes to main
- [ ] Deploy to staging first, test 24 hours
- [ ] Rotate credentials in all service dashboards (see below)
- [ ] Update .env.local with new credentials
- [ ] Update Vercel environment variables
- [ ] Deploy to production
- [ ] Monitor error logs and Sentry dashboard

---

## ⚠️ Critical Manual Actions Still Required

### Credential Rotation (User Action)
**Why:** Credential files were exposed in git history

**Services needing credential rotation:**
1. Supabase - Rotate API keys
2. Clerk - Regenerate secret key
3. Stripe - Create new API keys
4. Gemini - Create new API key
5. GitHub PATs - Create new tokens
6. Vercel - Create new access tokens
7. Claude API - Create new API key
8. Groq - Create new API key
9. DeepSeek - Create new API key
10. OpenRouter - Create new API key

**Steps for each service:**
1. Log into service dashboard
2. Generate new credential
3. Update .env.local in your local machine
4. Update Vercel environment variables
5. Verify app works with new credentials
6. Delete old credentials from service dashboard

---

## 🏗️ Architecture Decisions & Rationale

### Rate Limiting: In-Memory vs Redis
**Current:** In-memory Map (Tier 2)
**Why:**
- Zero external dependencies
- Suitable for serverless (Vercel Edge Runtime compatible)
- Fast startup, no cold start penalty

**Limitation:** Single instance only
**Scaling path:** Move to Redis/Upstash when:
- Multi-region deployments planned
- Traffic exceeds single Vercel instance capacity
- Need persistence across deploys

### Security Headers: CSP with 'unsafe-inline'
**Current:** Allows 'unsafe-inline' for scripts
**Why:** Next.js requires it for hydration during server rendering
**Limitation:** Reduces XSS protection slightly
**Future improvement:** Nonce-based CSP when Next.js app refactored to use external script loading

### Error Handling: Boundary + API Logging
**Current:** React error boundary for rendering errors, console.error in API routes
**Why:**
- Boundary prevents white screen of death
- Logging helps debug production issues
- Structured format `[api/route]` enables log aggregation

**Future:** Sentry integration (Tier 3) will capture both rendering and API errors in one place

---

## 🧪 Testing Verification Steps

After each Tier 3 implementation, test:

### CSRF Protection
```bash
# Should fail without token
curl -X POST https://morphism.dev/api/credentials -d '{}' -H "Content-Type: application/json"
# Returns: 403 CSRF validation failed

# Should succeed with token
TOKEN=$(curl -s https://morphism.dev | grep csrf | ...)
curl -X POST https://morphism.dev/api/credentials \
  -H "X-CSRF-Token: $TOKEN" \
  -d '{}' \
  -H "Content-Type: application/json"
```

### Sentry Integration
```javascript
// In error-boundary.tsx after capturing exception
Sentry.captureException(error);
// Should appear in Sentry dashboard within 5 seconds
```

### OpenAPI Docs
```bash
curl https://morphism.dev/api/docs
# Should return HTML with interactive Swagger UI
```

### Rate Limiting (already tested in Tier 2)
```bash
for i in {1..31}; do curl https://morphism.dev/api/agents; done
# Request 31 should return 429 Too Many Requests
```

---

## 📊 Tier 3-4 Execution Recommendation

### Sequential Approach (Lower Risk)
1. **CSRF Protection** (2-3 hours)
   - Lowest risk, most critical security feature
   - Can test independently

2. **Sentry Integration** (1-2 hours)
   - High value for monitoring
   - Non-blocking if fails

3. **OpenAPI Documentation** (3-4 hours)
   - Nice-to-have, lower risk
   - Can generate automatically from code

4. **Code Consolidation** (4-6 hours)
   - Largest refactor, most disruptive
   - Consider for future sprint

### Parallel Approach (Higher Velocity)
- CSRF + Sentry in parallel (independent implementations)
- Then OpenAPI docs (can reference fixed API signatures)
- Code consolidation last (requires stable APIs)

**Recommendation:** Sequential for Tier 3 (stability), save Tier 4 for next iteration

---

## 📞 Questions for Codex

As you implement Tier 3, consider:

1. **CSRF Token Generation:** Use crypto.randomBytes or external JWT service?
2. **Sentry Sample Rate:** 10% of transactions or higher in staging?
3. **OpenAPI Format:** Swagger 3.0 or 3.1? Include authentication examples?
4. **Consolidation:** Which shared code first - encryption or database client?

---

## 📌 Key Takeaways for Codex

✅ **What's done:** All critical security vulnerabilities fixed, foundation improvements in place
⏳ **What's next:** CSRF protection, error tracking, API documentation, code consolidation
🎯 **Priority:** CSRF first (security), Sentry next (observability), docs third (developer experience)
⚠️ **Important:** Credentials still need manual rotation in service dashboards
🚀 **Ready to deploy:** After Tier 3 + credential rotation, Tier 1-2 can go to production

---

Generated: 2026-02-16
