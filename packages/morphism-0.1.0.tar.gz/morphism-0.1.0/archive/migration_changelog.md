# Migration Changelog

## 2026-02-08

- Applied governance policy update for development gates:
  - local default: `quality:check:fast`
  - CI authority: `quality:check:strict` + `optimize:master:ci`
- Updated tenet documentation and operational runbook to codify commit hygiene:
  - one concern per commit
  - explicit staging paths
  - avoid broad staging in mixed workspaces
- Added missing workspace navigation docs:
  - `docs/workspace/LANDING.md`
  - `docs/workspace/INDEX.md`
  - `docs/workspace/GETTING_STARTED.md`
- Added missing README files across docs lanes:
  - `docs/history/README.md`
  - `docs/plans/README.md`
  - `docs/reference/README.md`
  - `docs/setup/README.md`
  - `docs/workspace/README.md`
  - `morphism/docs/workspace/README.md`
- Updated stale audit guidance in `docs/audits/README.md` to point to current strict Morphism checks.
- Executed fallback manual doc audit because `ops/scripts consolidation_toolbox.py` is not present in this workspace.
- Finished doc lane consolidation and navigation cleanup:
  - Added/updated docs lane READMEs (`docs/plans/README.md`, `docs/reference/README.md`, `docs/workspace/README.md`)
  - Linked architecture + canonical structure in `docs/workspace/INDEX.md`
  - Fixed moved-doc references in `docs/history/PHASE-2-COMPLETION.md` and workspace completion reports
- Standardized secrets documentation to use `.secrets/` as the local vault:
  - Updated `docs/reference/TOKEN_LOCATIONS.md`
- Reduced workspace git noise by ignoring local checkouts and local agent/editor state:
  - Updated `.gitignore` to ignore `_projects/`, `archive/`, `morphism-*` checkouts, `.kiro/`, `.kiro.backup/`, `.claude/system-prompts/`, and coverage outputs
- Added ecosystem audit tooling and stored audit artifacts under `docs/audits/ecosystem/`:
  - `scripts/ecosystem_audit.py`
  - `scripts/consolidation_toolbox.py` (legacy wrapper)
  - `docs/audits/ecosystem/inventory_20260208_041409.json`
- Moved migration test script into `scripts/migration/` and updated secrets path to `.secrets/github.env`
- Normalized workspace root to match `CANONICAL_STRUCTURE.md`:
  - Moved time-bound reports into `docs/history/` (migration/, verification/, governance/, proposals/, cleanup/, projects/)
  - Moved migration/governance tooling into `scripts/migration/` and `scripts/governance/`
  - Moved runtime artifacts into `archive/runtime/workspace-migration_2026-02-08/`
  - Regenerated ecosystem audit artifacts after moves (`bash scripts/ecosystem-audit.sh all`)

## 2026-02-09

- Ran ecosystem audit tooling and regenerated artifacts after ownership attribution fix:
  - `py -3 scripts/ecosystem_audit.py all`
  - Updated inventory + coverage under `docs/audits/ecosystem/`
- Fixed governance documentation link issue detected by `doc-auditor`:
  - `docs/README.md` now links to `docs/CONTRIBUTING.md`
- Corrected ownership attribution in ecosystem inventory generation:
  - `scripts/ecosystem_audit.py` now applies CODEOWNERS rules to per-path inventory entries
- Added workspace project assessment report:
  - `docs/audits/ecosystem/PROJECT_ASSESSMENT_2026-02-09.md`
