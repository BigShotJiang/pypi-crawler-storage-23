# Contributing

## Baseline

- Keep changes scoped and branch-specific.
- Run relevant validation before opening a PR.
- Keep governance pointers (`AGENTS.md`, `SSOT.md`, `CLAUDE.md`) aligned with canonical sources.

## Minimum Checks

- `./workspace status`
- `./workspace audit ecosystem --profile active --format all`
- `cd morphism && pnpm run quality:check:strict` for governance-impacting changes
