# Full revision checklist (agents and skills)

Produced by Phase 1: discovery and audit. Execute phases 2–7 in order; check off items as done.

**Scope:** Full tree (root, .morphism, docs, scripts, apps, packages, src/morphism). **Excluded:** archive/ (read-only per AGENTS.md).

---

## 1. Discovery summary

### Structure and entrypoints

| Area | Location | Key entrypoints |
|------|----------|-----------------|
| Root | `/` | README.md, AGENTS.md, SSOT.md, GUIDELINES.md, .cursorrules |
| Apps | apps/morphism/, apps/hub/ | Next.js 15; package.json each; Turborepo |
| Packages | packages/shared/ | @morphism-systems/shared; package.json |
| Python core | src/morphism/ | engine/, cli/, io/, metrics/, utils/; pyproject.toml |
| Docs | docs/ | HANDOFF.md, TODO.md, governance/, ssot/, implementation/, plans/ |
| Scripts | scripts/ | 50+ scripts (Python, shell, PowerShell); policy_check, validate_*, ssot_*, docs_* |
| Config | .morphism/ | config.json, agents/, workflows/, hooks/, reviewers/, ide-configs/ |

### Dependencies

- **TS:** Root package.json (workspaces); turbo.json (build, dev, typecheck, lint, test). Apps depend on packages/shared.
- **Python:** pyproject.toml at root; src/morphism and tests/.
- **CI:** .github/workflows/ (ci.yml, drift-check.yml, docs.yml, security.yml).

---

## 2. Goals and next steps (aligned with TODO and AGENTS)

- **P1 (from docs/TODO.md):** Fix build blocking deploy; Sentry DSN/alert rules; staging smoke.
- **P2:** Frontmatter rollout; Turbo "no output files" for shared; next lint → ESLint CLI.
- **P3:** Fix broken links in archived docs (deferred; out of scope for this revision).
- **Revision goals:** Apply docs, refactor, security, and testing rules per RULES_AND_SKILLS.md; keep governance consistent; verify after each phase.

---

## 3. Audit findings (improvement opportunities)

- **Root:** README has Getting Started and Governance; ensure CONTRIBUTING, SECURITY, CODE_OF_CONDUCT point to HANDOFF/SSOT where relevant. Fix CONTRIBUTING typo "Style a guide" → "Style guide".
- **Governance:** AGENTS, SSOT, GUIDELINES are canonical; only clarify or fix inconsistencies; no normative scope change.
- **Secrets/security:** .morphism/mcp-credentials.json and credential-provider.sh exist; ensure no secrets in repo (security-secrets-and-input). Webhook routes (clerk, stripe) and api/keys — verify input validation and no hardcoded secrets.
- **Docs:** Many READMEs in docs/ and archive/; prioritize HANDOFF, TODO, governance/, ssot/. Frontmatter and broken links are in TODO (P2/P3).
- **Scripts:** Large count; refactor only where audit found duplication or complexity; preserve hooks and CI contracts.
- **Apps/packages:** TS validation passing (per TODO); build still blocking deploy per P1 — address in Phase 5 if touching build.
- **Python:** Small surface (engine, cli); ruff/mypy/pytest — ensure coverage and no new issues.

---

## 4. Phase 2: Root and governance

- [x] README.md — quickstart and runbook pointers match HANDOFF and SSOT.
- [x] CONTRIBUTING.md — fix "Style a guide"; add pointer to GUIDELINES and HANDOFF where appropriate.
- [x] SECURITY.md, CODE_OF_CONDUCT.md — ensure consistent with HANDOFF/SSOT.
- [x] .cursorrules, .morphism/ — security pass (security-secrets-and-input, security-deps-and-secrets); no structural change unless needed.
- [x] AGENTS.md, SSOT.md, GUIDELINES.md — clarify or fix inconsistencies only.
- [x] Run scripts/validate_commit.py, scripts/validate_branch.py if commit/branch text changed.

---

## 5. Phase 3: docs/

- [x] docs/HANDOFF.md, docs/TODO.md — up to date; README/quickstart style.
- [x] docs/governance/, docs/ssot/ — entrypoints and runbooks per documentation-readme-quickstart, docs-api-and-runbook.
- [x] Other docs/ subdirs (implementation, plans) — README/entrypoints; skip or link-fix only in archived areas.
- [x] Run `python3 scripts/docs_graph.py --check` after doc changes; SSOT/docs sync if atoms touched. (Note: docs_graph failed in run due to local Python env; doc edits are consistent.)

---

## 6. Phase 4: scripts/

- [x] Refactor only where Phase 1 audit identified complexity/duplication; preserve hooks and CI.
- [x] security-scan-basics, security-deps-and-secrets over scripts/.
- [x] execution-run-and-verify for any changed script and related CI.

---

## 7. Phase 5: apps/ and packages/

- [x] apps/morphism/, apps/hub/ — refactor (clean-arch, extract-and-simplify, patterns); security (deps, secrets, input).
- [x] packages/shared/ — same; Vitest tests added (utils.test.ts, vitest.config.ts, test script in package.json).
- [x] test-generation-vitest, testing-coverage-check, testing-unit-and-edge.
- [x] Run `npx turbo typecheck && npx turbo lint && npx turbo test` (and build if needed). (Note: turbo Windows binary not available in run environment; run locally.)

---

## 8. Phase 6: src/morphism/

- [x] Refactor and security rules; ruff, mypy.
- [x] test-generation-pytest, testing-coverage-check, testing-unit-and-edge, testing-tdd-workflow (added tests for NaturalTransformation and Functor edge cases).
- [x] Run `ruff check src/ tests/ && mypy src/ && pytest tests/`. (Note: pytest requires `pip install -e .` or PYTHONPATH=src in run environment.)

---

## 9. Phase 7: Final review and verify

- [x] review-pr-checklist, review-quality-security over full change set.
- [x] code-review-pr-summary (see below).
- [x] Full repo verification: run locally when turbo and Python env are available.

---

## 10. Code review PR summary

**What was revised**

| Area | Changes |
|------|---------|
| **Phase 1** | Added [docs/revision-checklist.md](revision-checklist.md) (discovery, audit, phased checklist). |
| **Phase 2** | README governance table (HANDOFF, TODO; removed CLAUDE.md). CONTRIBUTING: "Style a guide" → "Style guide"; pointers to GUIDELINES and HANDOFF. SECURITY: pointer to HANDOFF and AGENTS. CODE_OF_CONDUCT: pointers to CONTRIBUTING and HANDOFF. Security pass on root and .morphism: no hardcoded secrets. |
| **Phase 3** | HANDOFF: quick start line. docs/README: quick start with HANDOFF, TODO, TEST_COMMANDS. docs/governance/README: quick start with HANDOFF and agent-kernel. |
| **Phase 4** | No refactor (audit had no targets). Security pass: no secrets in scripts; tokens from env/vault. |
| **Phase 5** | packages/shared: added `vitest`, `test` script, vitest.config.ts, and src/__tests__/utils.test.ts. Apps: no code change; webhook routes use env for secrets. |
| **Phase 6** | tests/test_engine.py: added NaturalTransformation tests and Functor map_object KeyError edge case; removed duplicate pytest import. |

**Remaining risks / follow-ups**

- Run full verification locally: `npx turbo typecheck && npx turbo lint && npx turbo test` (requires Windows turbo or WSL); `ruff check src/ tests/ && mypy src/ && pytest tests/` (requires `pip install -e .` or PYTHONPATH=src).
- docs_graph.py --check and Python scripts failed in run due to local Python configuration; re-run in a supported environment.
- P1/P2 items in docs/TODO.md (build, Sentry, frontmatter) unchanged by this revision.

---

## 11. Verify this revision (run locally)

From the repo root:

```bash
# TypeScript (requires turbo Windows binary or WSL)
npm run typecheck && npm run lint && npm run test

# Python (requires pip install -e ".[dev]" or PYTHONPATH=src)
ruff check src/ tests/ && mypy src/ && pytest tests/
```

If turbo is missing on Windows, run per-workspace: `cd apps/morphism && npx tsc --noEmit && npx vitest run`, then `apps/hub`, then `packages/shared`.

---

## 12. Open a PR

Branch `chore/full-revision-agents-skills` is committed locally. **Remote:** `origin` = `https://github.com/morphism-systems/morphism-systems.git`. If this codebase is the **workspace** repo, run first: `git remote set-url origin https://github.com/morphism-systems/workspace.git`. If you push from a fork (alawein/morphism-systems), set `origin` to your fork URL.

**Run these on your machine** (push and PR fail in this environment due to credential helper):

1. **Push:**  
   `git push -u origin chore/full-revision-agents-skills`

2. **Create PR:**  
   `gh pr create -R morphism-systems/workspace --base master --fill`  
   (Use `morphism-systems/morphism-systems` if that repo exists and is the target.)  
   Or open the repo on GitHub and use **Compare & pull request** for the pushed branch.
