# LLM interaction standards

How we standardize use of Claude and other LLMs in this repo. **Authority:** [AGENTS.md](../AGENTS.md), [SSOT.md](../SSOT.md), [GUIDELINES.md](../GUIDELINES.md). This doc does not override them.

---

## In-repo authority

- **Before structural or governance changes:** Read [AGENTS.md](../AGENTS.md), [SSOT.md](../SSOT.md), [GUIDELINES.md](../GUIDELINES.md) and [docs/HANDOFF.md](HANDOFF.md).
- **IDE and prompts:** Use [.morphism/ide-configs/](../.morphism/ide-configs/) — Claude Code, Cursor, Codex, AmazonQ — for shared reviewers, rules, and prompts. Symlink as described in that README (e.g. `.claude` → `.morphism/ide-configs/claude`).
- **Protocol:** Read first, state one thing, verify path, execute incrementally, refuse scope creep. Full agent protocol: [docs/governance/agent-kernel-prompt.md](governance/agent-kernel-prompt.md).

---

## Prompt and tool-use design

- For **prompt structure, tool use, and best practices** we use Anthropic’s prompt engineering guide as a reference (we do not use API docs as our coding standard):
  - [Prompt engineering overview](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/overview) — primary reference for how we design prompts and tool-use patterns.
- **Official docs we use:** [docs.anthropic.com](https://docs.anthropic.com/) (API reference, model specs, SDKs), [docs.claude.com](https://docs.claude.com/) (Claude guides, integrations). Do not reference or depend on `code.claude.com/docs` (invalid/404).
- **SDKs and examples:** [anthropic-sdk-python](https://github.com/anthropics/anthropic-sdk-python), [anthropic-sdk-typescript](https://github.com/anthropics/anthropic-sdk-typescript).

---

## Summary

| Goal | Where |
|------|--------|
| Governance and scope | AGENTS.md, SSOT.md, GUIDELINES.md |
| Prompts and reviewers | .morphism/ide-configs/ |
| Prompt-engineering reference | docs.anthropic.com (prompt engineering overview) |
| API / SDK reference | docs.anthropic.com, official GitHub SDK repos |
