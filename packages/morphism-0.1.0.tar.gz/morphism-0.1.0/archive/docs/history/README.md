---
type: historical
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# History Docs

> **NON-NORMATIVE.**

This folder contains time-bound reports, completion notes, and proposals that should not live at the workspace root.

## Structure

- `cleanup/` - Workspace cleanup reports and notes
- `governance/` - Governance rollout plans, guides, and completion packages
- `migration/` - Migration summaries, execution notes, and post-mortems
- `projects/` - Project completion reports
- `proposals/` - Workspace/repo proposals and position docs
- `verification/` - Verification reports and validation summaries
- `PHASE-2-COMPLETION.md` - Phase completion report
