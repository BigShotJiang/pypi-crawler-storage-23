---
type: reference
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# Archive repos — morphism-systems org

> **NON-NORMATIVE.**

**Purpose:** Archive legacy org repos so the single active repo is **morphism-systems/morphism** (this monorepo).

## Repos to archive (GitHub UI)

In [morphism-systems](https://github.com/orgs/morphism-systems/repositories), archive **hub** and **workspace** so they become read-only:

| Repo | Action |
|------|--------|
| **hub** | Settings → Danger Zone → Archive this repository |
| **workspace** | Settings → Danger Zone → Archive this repository |

Keep **morphism** active — it now holds this monorepo (apps/morphism, apps/hub, packages/shared, etc.). The **archive** repo in the org can hold snapshots or legacy copies if needed.

## Active codebase and deploy

- **Canonical repo:** [morphism-systems/morphism](https://github.com/morphism-systems/morphism)
- **Deploy:** Vercel → import this repo, root = repo root, build = `npx turbo run build --filter=morphism-app`, output = `apps/morphism/.next`
