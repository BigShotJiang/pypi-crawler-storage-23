---
type: reference
authority: derived
audience: [contributors, leadership]
last-verified: 2026-02-17
scope: governance
---

# Proof roadmap — formal verification

> **NON-NORMATIVE.** This document tracks the path to formal verification of governance invariants and theory. Until proof artifacts are published, website and docs use "design target" / "framework" wording; see [RECONCILIATION_REPORT.md](RECONCILIATION_REPORT.md).

---

## 1. Current status

- **Proof artifacts in repo:** None. No committed Lean 4 (or other) proof files in the live morphism-systems repo.
- **Claims:** "98.1% formally verified in Lean 4" and similar are **retracted** until proof artifacts are published. κ &lt; 1 and Agentic Uncertainty are **design target** / **concept**; formalization deferred to roadmap.
- **Validation:** [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md) and [VALIDATION.md](../VALIDATION.md) document executable and rationale soundness; formal soundness is aspirational.

---

## 2. Candidate targets for formalization

Formal statements for these targets are in [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md); proof strategies and tactics in [PROOF_STRATEGIES.md](PROOF_STRATEGIES.md). Order and priority to be set by owners. Suggested ordering (invariants and theory statements that have clear predicates):

| Priority | Target | Description | Artifact location (when added) |
|----------|--------|-------------|--------------------------------|
| 1 | I-5 Entropy Monotonicity | $E(s') \leq E(s) + \epsilon$ for admissible transitions | e.g. `proofs/` or `archive/`; TBD |
| 2 | I-6 Refusal as Structure | $\mathcal{R}(s,f)$ total; Refuse has O(1) cost and structured output | TBD |
| 3 | Convergence (κ &lt; 1) | Governance operator as contraction; unique fixed point | Referenced on website; no proof in repo yet |
| 4 | I-1, I-2 (One Truth, Drift) | Uniqueness of canonical source; drift blocks merge | TBD |
| 5 | Agentic Uncertainty | Cert_p × Cert_r ≥ ℏ_agent (concept); formalization TBD | Deferred |

---

## 3. Tooling and process

- **Proof assistant:** Lean 4 + Mathlib4 (referenced on website and in RECONCILIATION_REPORT).
- **Review:** When a proof is added, it must pass [proof-review-workflow.md](../proof-review-workflow.md) and reference the invariant or theorem it proves. See [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md).
- **Placement:** Proofs may live under `proofs/`, `docs/governance/proofs/`, or `archive/` per repo layout decision. Update this roadmap when a location is chosen.

---

## 4. Timeline (operational)

- **Q2 2026 (target):** Formal verification work (e.g. first Lean 4 proof for an invariant or entropy inequality) tracked here; no commitment until artifacts exist.
- **Reconciliation:** When proof artifacts are merged, update [RECONCILIATION_REPORT.md](RECONCILIATION_REPORT.md) and evidence ledger; then website copy may be updated to link to proofs.

---

## 5. Future work (optional)

- **Reduced axiom set (Phase 2 option B):** Introduce 3–5 minimal mathematical axioms and derive the 7 Kernel invariants as theorems for a cleaner "foundation → implementation" story. Document in [morphism-theory.md](../architecture/morphism-theory.md) or a dedicated axioms doc.
- **Intellectual resources:** When adding proofs or refining axioms, use [REFERENCES.md](REFERENCES.md) to record specific texts (category theory, logic, entropy, proof assistants) from your collection.

---

## 6. Related documents

| Document | Role |
|----------|------|
| [morphism-kernel.md](morphism-kernel.md) | Normative invariants (formalization targets). |
| [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) | Formal definitions and theorem statements (source for formalization). |
| [PROOF_STRATEGIES.md](PROOF_STRATEGIES.md) | Tactics and strategies per roadmap target; Lean 4/Mathlib4. |
| [morphism-theory.md](../architecture/morphism-theory.md) | Semi-formal axioms and theory (exposition). |
| [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md) | Soundness criteria; formal soundness = roadmap. |
| [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md) | How scripts implement maturity, drift, refusal, trace. |
| [RECONCILIATION_REPORT.md](RECONCILIATION_REPORT.md) | Website vs repo claims; retracted until proofs exist. |
| [proof-review-workflow.md](../proof-review-workflow.md) | Review process for new proofs. |
| [roadmap.md](roadmap.md) | Phased governance rollout (operational). |
| [REFERENCES.md](REFERENCES.md) | Intellectual resources and foundational texts for revision. |

---

*Normative: [morphism-kernel.md](morphism-kernel.md) · Roadmap maintained for revision.*

<!-- Governance invariant references: I-3, I-4, I-7 -->
