---
type: reference
authority: non-normative
audience: [contributors, public]
last-verified: 2026-02-17
scope: governance
---

# Enhanced Prompt Request — Reference (Sections 1–4)

> **NON-NORMATIVE.** This document is a revised, repo-aligned version of the "Enhanced Prompt Request" text for use when providing context to external assistants or services. Normative governance: [morphism-kernel.md](morphism-kernel.md).

### How to run / use this

When an external assistant says it has no prior documents and asks you to resubmit or clarify (the "Enhanced Prompt Request"):

1. **Paste** — Copy sections 1–4 below (from "## 1. Documents to work from" through "## 4. What we want from you") and paste them into that conversation. That gives the assistant the document list, objectives, formalism, and deliverables in one block.
2. **Attach (if supported)** — If the tool allows file upload, attach key docs from the table (e.g. `morphism-kernel.md`, `morphism-theory.md`, `MORPHISM_FORMAL.md`, `PROOF_ROADMAP.md`) so the assistant can read the actual text.
3. **One-liner** — If you need a minimal prompt, send: "Work from the Morphism Categorical Governance Framework. Normative: 7 invariants in morphism-kernel.md. Theory: morphism-theory.md (category of context, entropy functor, governance monad, refusal functor). Formalization source: MORPHISM_FORMAL.md. I want rigorous definitions/theorems, Lean 4 proof strategies, algorithmic validation approaches, cross-disciplinary mapping, and concrete examples aligned with the 7 invariants."

---

## 1. Documents to work from

**Project:** Morphism Categorical Governance Framework — a monorepo that governs itself via category-theoretic and algebra-style structure.

**Key documents (titles, locations, roles):**

| Document | Location (in repo) | Role |
|----------|--------------------|------|
| MORPHISM Governance Kernel | `docs/governance/morphism-kernel.md` | Normative: 7 invariants (I-1–I-7), Read–Verify–Execute protocol, enforcement pointers. |
| MORPHISM (framework) | `docs/governance/MORPHISM.md` | Reference: kernel summary, tenets, repo scope, protocol in practice. |
| Mathematical exposition | `docs/architecture/morphism-theory.md` | Non-normative: category of context, entropy functor, governance monad, refusal functor, ideation algebra; semi-formal axioms for each invariant. |
| Validation criteria | `docs/governance/VALIDATION_CRITERIA.md` | Defines formal / executable / rationale soundness per invariant; formal verification on roadmap. |
| Proof roadmap | `docs/governance/PROOF_ROADMAP.md` | Formal verification plan: candidate targets (e.g. I-5, I-6, convergence κ&lt;1), Lean 4 + Mathlib4, review workflow. |
| Root governance | `AGENTS.md`, `SSOT.md` | Authority and scope of the monorepo and governance. SSOT.md also references MORPHISM.md and MORPHISM_FORMAL.md in its Governance Documents table. |
| MORPHISM_FORMAL | `docs/governance/MORPHISM_FORMAL.md` | Formal definitions and theorem statements; intended source for PROOF_ROADMAP formalization targets; notation, State, Admissible transition, Trace, E, G, R, theorems (e.g. entropy monotonicity, refusal structure, convergence κ&lt;1). |
| ALGORITHMIC_VALIDATION | `docs/governance/ALGORITHMIC_VALIDATION.md` | How scripts/CI implement maturity (I-5), drift (I-1/I-2), refusal and observability (I-6, I-3); links to maturity_score.py, ssot_verify.py, policy_check.py, convergence.py; proof-search/verification methodology. |
| PROOF_STRATEGIES | `docs/governance/PROOF_STRATEGIES.md` | Proof tactics and verification methodologies per roadmap target (I-5, I-6, convergence); Lean 4 + Mathlib4; strategy and tactics per invariant. |
| EXAMPLES | `docs/governance/EXAMPLES.md` | Concrete examples for category of context, entropy functor E, refusal functor R, governance monad G, ideation algebra in context of the 7 invariants. |
| INVENTORY | `docs/governance/INVENTORY.md` | Canonical list of 7 invariants and 10 tenets; derivation graph (tenet → invariant); consistency matrix (theory ↔ Kernel ↔ tenets). |
| MORPHISM §4 | `docs/governance/MORPHISM.md` | Tenet definitions, enforcement points, failure modes, audit procedure, break-glass; operational implementation of the Kernel. |
| TENET_DERIVATION | `docs/governance/TENET_DERIVATION.md` | Derivation traces tenet ↔ invariant; contradiction check. |
| proof-review-workflow | `docs/proof-review-workflow.md` | Review process for new proofs (e.g. Lean); required before merging proof artifacts. |
| VALIDATION | `docs/VALIDATION.md` | Empirical validation and methodology; referenced by VALIDATION_CRITERIA and governance README. |
| REFERENCES | `docs/governance/REFERENCES.md` | Intellectual resources and foundational texts for formalization (PROOF_ROADMAP). |

**Structure:**

- **Normative:** [morphism-kernel.md](morphism-kernel.md) (7 invariants, Read–Verify–Execute protocol).
- **Derived framework:** [MORPHISM.md](MORPHISM.md) (kernel summary, tenets, repo scope, protocol in practice).
- **Theory (non-normative):** [morphism-theory.md](../architecture/morphism-theory.md) (category of context, entropy functor, governance monad, refusal functor, ideation algebra; semi-formal axioms in §0).
- **Formalization source:** [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) (definitions and theorem statements for proof roadmap).
- **Supporting reference:** [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md), [PROOF_STRATEGIES.md](PROOF_STRATEGIES.md), [EXAMPLES.md](EXAMPLES.md).
- **Rationale and inventory:** Tenets derived from invariants ([TENET_DERIVATION.md](TENET_DERIVATION.md)); [INVENTORY.md](INVENTORY.md) and [MORPHISM.md §4](MORPHISM.md) complete the operational layer. [proof-review-workflow.md](../proof-review-workflow.md) applies when adding governance proofs.

---

## 2. Clarify objectives

- **Primary:** A governance framework for a software monorepo (single source of truth, drift, observability, scope, entropy, refusal, minimal authority), with category-theoretic and algebraic foundations used to justify and explain the design.
- **Formal verification:** Desired but not yet present. We want formal verification methods and proof strategies for the mathematical system (invariants and theory); roadmap in PROOF_ROADMAP.md; no proof artifacts in repo yet. We have formal definitions and theorem statements in MORPHISM_FORMAL.md and proof strategies in PROOF_STRATEGIES.md; we want verification methods and tactics that build on these.
- **Benchmarking/validation:** We already have executable soundness (scripts/CI per invariant) and rationale soundness (written derivations). Algorithmic approaches are documented in ALGORITHMIC_VALIDATION.md (maturity, drift, refusal, trace); we are interested in refinement and extension, and in methodological approaches that support formal proof efforts.
- **Category-theoretic foundations:** We are developing (and documenting) these foundations specifically for governance: states as objects, admissible transitions as morphisms, entropy functor, governance monad, refusal functor, ideation algebra — all in service of the 7 kernel invariants.

---

## 3. Formalism framework

- **Category theory:** Categories of context (states, morphisms as valid transitions, composition via Read–Verify–Execute); functors (entropy E, refusal R); governance monad G with unit and bind; coherence and monad laws.
- **Semi-formal / predicate form:** Each invariant is stated in semi-formal form (e.g. ∀ governance assertion a: ∃! canonical source c) in morphism-theory.md §0. Formal definitions and theorem statements are collected in MORPHISM_FORMAL.md.
- **Algebraic:** Ideation algebra (in the same theory doc) for composition of "ideation" operations.
- **Not in scope (for this project):** Physics-inspired Lagrangians/Hamiltonians or field theories; we are not asking for those unless they can be clearly tied to our category/algebra setup. **Computational complexity:** Refusal is required to be O(1); we are interested in complexity considerations only as they relate to the governance model (e.g. refusal cost, verification cost).

---

## 4. What we want from you

Once you have the above (and, if possible, the referenced docs):

1. **Rigorous mathematical documentation** — Refine or extend the formal definitions and theorem statements in MORPHISM_FORMAL.md so they align with morphism-theory.md and the kernel and feed the proof roadmap; or provide additional formal/semi-formal definitions and theorems that integrate with these.
2. **Proof strategies and verification methodologies** — Extend or deepen PROOF_STRATEGIES.md; provide approaches and tactics for proving the invariants and key theory statements (entropy monotonicity, refusal structure, convergence κ&lt;1), ideally compatible with Lean 4 / Mathlib4.
3. **Algorithmic approaches** — Align with or extend ALGORITHMIC_VALIDATION.md: benchmarking and validation of governance (maturity, entropy, drift) and, where applicable, proof-search or verification tooling methodology.
4. **Cross-disciplinary formalism** — Strengthen or clarify links between the category-theoretic/algebraic layer and the executable enforcement (scripts, CI) and rationale (tenet derivations in TENET_DERIVATION and executive-overview).
5. **Concrete examples** — Extend EXAMPLES.md or add new examples that illustrate each main concept (category, functors, monad, refusal, ideation algebra) in the context of the 7 invariants.

---

### Reference links (key docs to attach or cite)

- [morphism-kernel.md](morphism-kernel.md) — normative invariants and protocol
- [morphism-theory.md](../architecture/morphism-theory.md) — mathematical exposition
- [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) — formal definitions and theorem statements
- [PROOF_ROADMAP.md](PROOF_ROADMAP.md) — formal verification plan
- [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md) — scripts/CI and benchmarking
- [EXAMPLES.md](EXAMPLES.md) — concrete examples for category, E, R, G, ideation algebra

### One-liner (copy-paste)

Work from the Morphism Categorical Governance Framework. Normative: 7 invariants in morphism-kernel.md. Theory: morphism-theory.md (category of context, entropy functor, governance monad, refusal functor). Formalization source: MORPHISM_FORMAL.md. I want rigorous definitions/theorems, Lean 4 proof strategies, algorithmic validation approaches, cross-disciplinary mapping, and concrete examples aligned with the 7 invariants.

<!-- Governance invariant references: I-4 -->
