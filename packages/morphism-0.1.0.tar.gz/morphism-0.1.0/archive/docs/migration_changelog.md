# Migration Changelog

## 2026-02-18

- Initialized `docs/migration_changelog.md` (missing but referenced in `docs/README.md`).
- Alignment planner: `scripts/consolidation_toolbox.py` does not support `alignment-planner` (unsupported legacy command).
- Manual fallback: searched `docs/` for alignment plan sections; none found.
- Archive manager: ran `py -3 scripts/consolidation_toolbox.py archive-manager` after `python ops/consolidation_toolbox.py` failed; inventory generated.
- Duplicate filename scan between `docs/` and `archive/` returned no matches.
- Audits collector: `python ops/consolidation_toolbox.py audits-collector` failed (Python runtime encodings); `py -3 scripts/consolidation_toolbox.py audits-collector` unsupported legacy command.
- Manual audit report list under `docs/audits/`: `docs/audits/ecosystem/INVENTORY_FULL.md`, `docs/audits/ecosystem/SCHEMA.md`, `docs/audits/ecosystem/SCOPE_POLICY.md` (data files: `inventory-full.json`, `inventory.csv`).
- Added `docs/audits/README.md` to index audit reports and data files.
- Extended `scripts/consolidation_toolbox.py` with `audits-collector` output (JSON list of audit reports and data).
- Ran `py -3 scripts/consolidation_toolbox.py audits-collector`; reports: `docs/audits/ecosystem/INVENTORY_FULL.md`, `docs/audits/ecosystem/SCHEMA.md`, `docs/audits/ecosystem/SCOPE_POLICY.md`, `docs/audits/README.md`.
- Added `ops/consolidation_toolbox.py` wrapper so skill commands can call `python ops/consolidation_toolbox.py ...`.
- Linked `audits/README.md` from `docs/README.md`.
- `python ops/consolidation_toolbox.py audits-collector` still fails on this host (Python encodings error); use `py -3` as a workaround.
- Added `py -3` fallback in `ops/consolidation_toolbox.py` when the primary interpreter run fails.
