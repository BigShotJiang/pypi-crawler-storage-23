---
type: reference
authority: non-normative
audience: [contributors]
last-verified: 2026-02-17
scope: governance
---

# Proof strategies and verification methodologies

> **NON-NORMATIVE.** This document describes tactics and proof strategies for formalizing the governance invariants and key theory statements. It is aligned with [PROOF_ROADMAP.md](PROOF_ROADMAP.md) and [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) (Definitions 2.1-2.13, Theorems 1-9). Normative requirements: [morphism-kernel.md](morphism-kernel.md).

---

## 1. Tooling and process

- **Proof assistant:** Lean 4 with Mathlib4. All formalization targets are intended to be expressed in Lean 4 and to use Mathlib4 where applicable.
- **Artifact location:** When proofs are added, they may live under `proofs/`, `docs/governance/proofs/`, or `archive/` per repo decision. Update [PROOF_ROADMAP.md](PROOF_ROADMAP.md) when a location is chosen.
- **Review:** Every new proof must satisfy [proof-review-workflow.md](../proof-review-workflow.md) and must reference the invariant or theorem it proves (e.g. in a comment or README). See [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md).

---

## 2. Mathlib4 dependencies (likely)

When formalizing, the following namespaces or modules are likely to be useful:

- **Order and reals:** `Mathlib.Data.Real.Basic`, `Mathlib.Order.Basic` — for $E(s') \leq E(s) + \epsilon$ (Thm 5), thresholds.
- **Metric spaces and contraction:** `Mathlib.Analysis.NormedSpace.Contraction`, `Mathlib.Topology.MetricSpace.Basic` — for convergence (Thm 8, κ < 1) and Banach fixed-point.
- **Structures and types:** Sum types (Admit | Refuse), existential uniqueness (ExistsUnique), predicates over states, transitions, drift, scope, permissions.
- **Category theory (optional):** If formalizing the category of context (Def 2.7) or the monad (Def 2.9, Thm 9), `Mathlib.CategoryTheory` — categories, functors, monads. May be deferred; invariants can be formalized first without full category theory.

---

## 3. Strategy per roadmap target

Targets and theorem numbers follow [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) Section 3 (Theorems 1-9) and Section 4 (Invariant index).

### 3.1 I-1 Canonical source uniqueness (Thm 1)

**Formal statement (MORPHISM_FORMAL Thm 1):** For every assertion $a \in A$, there exists a unique $c \in \mathrm{Src}$ with $a \in \mathrm{Content}(c)$; $\mathrm{src}(a)$ is well-defined. If $a$ appears in any derived artifact $d$, then $d$ is derived from $\mathrm{src}(a)$.

**Definitions:** MORPHISM_FORMAL Def 2.1 (domain, assertion), Def 2.2 (canonical source).

**Strategy:**
1. Represent assertions and sources as types; define `Content : Source -> Set Assertion` and `src : Assertion -> Source` (or equivalent).
2. Prove existence: for all `a`, `a \in Content (src a)`.
3. Prove uniqueness: if `a \in Content c1` and `a \in Content c2` then `c1 = c2`. Use `ExistsUnique`; split into existence and uniqueness goals if needed.
4. Optional: prove that any derived artifact containing `a` is derived from `src a`.

**Tactics:** `intro`, `use` / `exists`, `unique` or two goals; `rfl` for definitional equalities.

---

### 3.2 I-2 Drift blocks admissible merge (Thm 2)

**Formal statement (MORPHISM_FORMAL Thm 2):** For a merge transition $f : s \to s'$, if $\mathrm{drift}(s')$ is non-empty or any assertion is stale, then $\mathcal{R}(s, f) = \mathrm{Refuse}$. Equivalently, admissible merge implies $\mathrm{drift}(s') = \emptyset$ and no stale assertions.

**Definitions:** MORPHISM_FORMAL Def 2.3 (drift, staleness), Def 2.5 (admissible, merge gating), Def 2.10 (R).

**Strategy:**
1. Define `drift (s : State) : Set Assertion`, `stale (a, s)`, and merge transitions (subset of admissible targeting protected branches).
2. State: if `f` is merge and (drift s' non-empty or exists stale) then `R s f = Refuse`. Or contrapositive: if `R s f = Admit` and `f` is merge then drift empty and no stale.
3. Proof: by Def 2.5 (Verify requires drift empty and no stale for merge); link R to Admit iff Verify passes.

**Tactics:** `by_cases`, `intro`, `apply`; pattern match on `R s f`.

---

### 3.3 I-3 Observability (Thm 3) and monad laws (Thm 9)

**Formal statement (Thm 3):** For any admissible $f : s_1 \to s_2$, there exists $\tau \in G(s_2)$ whose final step is $f$. No governance-changing transition is admissible without such a trace.

**Formal statement (Thm 9):** $\mathcal{G} = (G, \eta, \mu)$ satisfies left identity, right identity, and associativity.

**Definitions:** MORPHISM_FORMAL Def 2.6 (trace), Def 2.9 (governance monad G).

**Strategy (Thm 3):** Define Trace, G, admissible; for each admissible f construct a trace ending in f. Prove no admissible transition without a trace in G (by definition of admissible).

**Strategy (Thm 9):** Define eta, bind; state and prove the three monad laws (left/right identity, associativity). Use `rfl` or induction on trace structure.

**Tactics:** `use`, `constructor`, `rfl`, `simp`; for Thm 9 possibly `induction` on traces.

---

### 3.4 I-4 Scope binding (Thm 4)

**Formal statement (MORPHISM_FORMAL Thm 4):** For protocol $P$ and admissible $f$ under $P$, all modified/introduced assertions satisfy $\mathrm{dom}(a) \in \mathrm{scope}_{\mathrm{in}}(P)$. If $\mathrm{dom}(a) \in \mathrm{scope}_{\mathrm{out}}(P)$ then $\mathcal{R}(s, f) = \mathrm{Refuse}$. Any transition that changes $\mathrm{scope}_{\mathrm{in}}$ without explicit declaration is refused.

**Definitions:** MORPHISM_FORMAL Def 2.11 (scope declaration, binding, scope drift).

**Strategy:** Define scope_in, scope_out with disjointness; transition-under-protocol; prove admissible f under P implies dom a in scope_in P for modified/introduced a; prove scope_out implies Refuse; prove scope change without declaration implies Refuse.

**Tactics:** `intro`, `by_contra`, `apply`; use definition of admissible and R.

---

### 3.5 I-5 Entropy monotonicity (Thm 5)

**Formal statement (MORPHISM_FORMAL Thm 5):** For every admissible transition $f : s \to s'$, $E(s') \leq E(s) + \epsilon$.

**Definitions:** MORPHISM_FORMAL Def 2.4 (state), Def 2.5 (admissible), Def 2.8 (entropy E, monotonicity condition).

**Strategy:**
1. Define types: State, predicate Admissible (encoding Read-Verify-Execute), E : State -> RR (or NNReal).
2. State the theorem: Admissible f -> f.source = s -> f.target = s' -> E s' <= E s + epsilon.
3. Proof: by Def 2.8 (monotonicity axiom for admissible f), or induction on trace length, or preorder on states; use le_add_of_nonneg_right, linarith/nlinarith.
4. Link to implementation: maturity_score.py approximates E; formal E is an abstraction the script underapproximates.

**Tactics (Lean 4):** `intro`, `unfold Admissible`, `apply le_trans`, `linarith`/`nlinarith`, `omega`.

---

### 3.6 I-6 Refusal totality and structure (Thm 6)

**Formal statement (MORPHISM_FORMAL Thm 6):** (1) $\mathcal{R}(s, f)$ is total. (2) If Refuse, then non-empty structured output. (3) O(1) cost bound.

**Definitions:** MORPHISM_FORMAL Def 2.10 (refusal decision R, requirements).

**Strategy:**
1. Define `inductive Decision | Admit | Refuse (payload : StructuredOutput)` with StructuredOutput non-empty.
2. Define R by cases on Read/Verify/Execute; prove totality.
3. For Refuse p, prove payload non-empty by definition of StructuredOutput.
4. Cost: state O(1) in comment or complexity spec unless formalizing cost.

**Tactics:** Pattern matching; `rfl`; `simp` for simplifying R.

---

### 3.7 I-7 Minimal authority (Thm 7)

**Formal statement (MORPHISM_FORMAL Thm 7):** For any assignment assign(u, p) with u not repo owner, p is minimal among permissions authorizing required actions. For each critical path cp, there exists owner o and permission p with ctx(p) covering cp.

**Definitions:** MORPHISM_FORMAL Def 2.12 (permission, minimal authority).

**Strategy:** Define permission with cap, ctx and partial order; assign; prove minimality for non-owner and coverage for critical paths (CODEOWNERS). Tactics: intro, by_contra, obtain; order lemmas.

---

### 3.8 Convergence (Thm 8) - design target

**Formal statement (MORPHISM_FORMAL Thm 8):** If $\Gamma$ is a contraction with constant $\kappa < 1$, then $\Gamma$ has a unique fixed point.

**Strategy:** Use Mathlib contraction/Banach fixed-point. Define metric on state space, self-map Gamma, hypothesis Contraction Gamma k with k < 1. Apply library theorem; prove Gamma satisfies contraction condition. Interpretation: governance operator is Gamma; formalization makes design target precise.

**Tactics:** `apply` library lemma; `exact` for contraction hypothesis; `simp`/`unfold` to show Gamma is contraction.

---

### 3.9 Agentic Uncertainty (deferred)

**Status:** Concept (Cert_p x Cert_r >= h_agent); formalization TBD. When addressed, define types for prompt/response certainty and state the inequality as axiom or derived bound.

---

### (Legacy) I-1 and I-2 - see 3.1 and 3.2

See 3.1 and 3.2 above.

---

## 4. Proof file layout (suggested)

When adding proof artifacts, a minimal layout could be:

```
proofs/
  Morphism/
    State.lean       -- State, Transition, Admissible
    Entropy.lean      -- E, Thm 5 (entropy monotonicity)
    Refusal.lean      -- R, Thm 6 (refusal totality and structure)
    Convergence.lean  -- Gamma, kappa, Thm 8 (Banach)
    Monad.lean        -- G, eta, mu, Thm 9 (monad laws)
    OneTruth.lean     -- Thm 1 (canonical source), Thm 2 (drift blocks merge)
    Scope.lean        -- Thm 4 (scope binding)
    Authority.lean    -- Thm 7 (minimal authority)
```

Each file should begin with a comment referencing the Kernel invariant(s) and the theorem in [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md).

---

## 5. Related documents

| Document | Role |
|----------|------|
| [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) | Formal definitions and theorem statements (source for formalization). |
| [PROOF_ROADMAP.md](PROOF_ROADMAP.md) | Targets, timeline, artifact location. |
| [proof-review-workflow.md](../proof-review-workflow.md) | Review checklist for new proofs. |
| [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md) | Formal soundness criteria. |
| [morphism-kernel.md](morphism-kernel.md) | Normative invariants. |
| [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md) | How scripts implement E, R, drift, trace (benchmarking). |

---

*Normative: [morphism-kernel.md](morphism-kernel.md)*
