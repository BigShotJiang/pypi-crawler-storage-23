# Morphism CLI — Script inventory and command map

**Purpose:** Map scripts in `scripts/` to CLI commands; inventory inputs/outputs; P0/P1/P2 priorities. See [CLI_SCOPE.md](CLI_SCOPE.md) for scope and decisions.

---

## 1. Script inventory

| Script | Purpose | Inputs | Outputs | Exit | Domain |
|--------|---------|--------|---------|------|--------|
| ssot_extract.py | Extract SSOT atoms from governance docs; update registry | ROOT, SOURCES (files) | docs/ssot/atoms/*.md, docs/ssot/registry.json | 0 ok, 1 fail | ssot |
| ssot_verify.py | Verify SSOT registry: file existence and SHA-256 match | ROOT, docs/ssot/registry.json | stdout/stderr | 0 ok, 1 drift | ssot |
| validate-registry.py | Unified registry validation (duplicates, refs, metadata, versions, deps, orphans, security) | .morphism/inventory/UNIFIED_REGISTRY.json, dependencies.json | stdout (errors/warnings) | 0 ok, non-zero fail | validation |
| policy_check.py | Orchestrate checks: pre-commit / pre-push / ci (validate_commit, validate_branch, ssot_verify, secret scan) | --mode, --explain, --dry-run; ROOT | stdout | 0 ok, non-zero fail | validation |
| docs_frontmatter.py | Validate YAML frontmatter in docs/**/*.md | --check / --report / --add-stub; docs/ | stdout or JSON report | 1 on violations (--check) | docs |
| docs_sync.py | Inject SSOT atom content into consumer docs; --check for CI | --check optional; ROOT, docs/ssot/atoms | consumer files updated or check | 1 if drift (--check) | docs |
| docs_graph.py | Build graph of .md files; orphans, broken refs, cycles | --check / --report / --viz; docs/ | stdout, JSON, or DOT | 1 on broken refs (--check) | docs |
| maturity_score.py | Compute governance maturity (0–105); --ci exits 1 if below threshold | --ci, --threshold; ROOT | stdout score | 1 if below threshold (--ci) | inventory |
| drift_detector.py | CI drift: claim–evidence, docs–registry, SSOT, ARTIFACT_REGISTRY | REPO_ROOT, .morphism/, docs/ | stdout [DRIFT] OK/WARN/ERROR | 0 ok, 1 fail | drift |
| validate_commit.py | Validate commit message grammar (conventional commits) | commit message file or stdin | stdout | 0 ok, non-zero fail | validation |
| validate_branch.py | Validate branch name (type/description) | --branch optional; git HEAD | stdout | 0 ok, non-zero fail | validation |
| ecosystem_audit.py | Ecosystem inventory and governance verification | ROOT, env ECOSYSTEM_*; various args | csv, json, stdout | 0 ok, non-zero fail | audit |
| build-unified-registry.py | Build UNIFIED_REGISTRY from inventory sources | .morphism/inventory sources | UNIFIED_REGISTRY.json | 0 ok | inventory |
| assign-independent-versions.py | Assign versions to components | registry / config | stdout/files | 0 ok | release |
| generate_dashboard.py | Generate dashboard assets | config / data | dashboard output | 0 ok | inventory |
| generate_todo_list.py | Generate TODO list from sources | config | todo output | 0 ok | docs |
| sync-changelogs.py | Sync changelog files | changelog paths | updated changelogs | 0 ok | release |
| triage_issues.py | Triage issues (e.g. GitHub) | config / API | stdout | 0 ok | audit |
| verify_pipeline.py | Verify pipeline/CI | pipeline config | stdout | 0 ok | validation |
| consolidation_toolbox.py | Consolidation utilities | args | stdout/files | 0 ok | audit |

---

## 2. Command map (script → CLI command)

| CLI command | Script(s) | Notes |
|-------------|-----------|-------|
| morphism init | (none; CLI writes config) | Writes .morphism/config.json from defaults/templates |
| morphism validate | validate-registry.py, policy_check.py, ssot_verify.py | Run in sequence; aggregate exit codes |
| morphism ssot extract | ssot_extract.py | Pass-through args |
| morphism ssot verify | ssot_verify.py | Pass-through args |
| morphism docs frontmatter | docs_frontmatter.py | --check / --report / --add-stub |
| morphism docs sync | docs_sync.py | --check for CI |
| morphism docs graph | docs_graph.py | --check / --report / --viz |
| morphism doctor | (CLI-native) | Python version, paths, env vars |
| morphism inventory (v2) | build-unified-registry.py, maturity_score.py | P1 |
| morphism audit (v2) | ecosystem_audit.py, triage_issues.py | P1 |
| morphism drift (v2) | drift_detector.py | P1; name distinct from morphism analyze (metrics) |
| morphism release (v2) | assign-independent-versions.py, sync-changelogs.py | P2 |
| morphism generate (v2) | (CLI + templates) | P2 |
| morphism watch (v2) | drift_detector.py + inventory (loop) | P2 |

---

## 3. Gap analysis and priorities

**Current state:** [src/morphism/cli/main.py](../../src/morphism/cli/main.py) implements the full v1 set: `init`, `validate`, `ssot` (extract/verify), `docs` (frontmatter/sync/graph), `doctor`, and `analyze` (convergence metrics). Scripts are wired via [morphism.tooling](../../src/morphism/tooling/). [ARCHITECTURE.md](workspace/ARCHITECTURE.md) and [PROJECT_CATALOG.md](workspace/PROJECT_CATALOG.md) describe v1 and the external "14+ binaries" target for @morphism-systems/tools (v2/ecosystem).

**Priority list:**

| Priority | Scope | Commands / work |
|----------|--------|------------------|
| **P0 (done)** | v1 | init, validate (3 scripts), ssot extract/verify, docs frontmatter/sync/graph, doctor, analyze. |
| **P1 (automation)** | v2 | inventory, audit, drift — wire scripts above; drift command for drift_detector.py (distinct from morphism analyze). |
| **P2 (nice-to-have)** | v2 | release, generate, watch. Full 14-command suite when all groups implemented. |

---

## 4. Convergence/drift semantics (Phase 5)

Morphism-native metrics to support (no external project names):

- **Convergence constant (κ):** Contraction-style bound (κ < 1) for governance iteration; see [morphism-theory.md](../../docs/architecture/morphism-theory.md).
- **Robustness delta (δ):** Drift/state difference from a baseline or between traces.

Document in internal provenance note only; formulas and types in `src/morphism/convergence.py` with docstrings and optional link to theory doc.

---

*Governance: [AGENTS.md](../../AGENTS.md), [CLI_SCOPE.md](CLI_SCOPE.md).*
