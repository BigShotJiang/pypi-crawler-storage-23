# WORKFLOWS

_Common tasks and the one command that runs them._

## Workspace CLI

The workspace ships a unified CLI:

- Help: `./workspace --help`
- Status: `./workspace status`
- Dashboard: `./workspace dashboard`
- Ecosystem audit: `./workspace audit ecosystem --profile active --format all`

## Daily operations

- Repo status (fast default): `./workspace status`
- Repo status (full scan): `./workspace status --full`
- Repo status (custom): `./scripts/status-all.sh --full --limit 30`
- Pull (all): `./scripts/pull-all.sh`

## Professional flow (required)

1. Branch from `main` with one clear scope.
2. Make scoped changes and stage by path (no broad staging).
3. Run local fast checks for iteration.
4. Run strict gate before PR or merge.
5. Rebase on `main`, open PR, and squash merge.
6. Delete lane branch after merge and sync local `main`.

Enforcement command:

- `bash ./scripts/enforce-professional-standards.sh --source staged --run-gate`
- One-time setup: `./scripts/install-hooks.sh`

Conflict resolution policy:

- Keep target branch behavior by default when conflicts are ambiguous.
- Prefer incoming changes only when they are newer and validated.
- Record non-trivial conflict decisions in the PR description.

## Creating a project

- Create from template: `./workspace new <project-name> [template]`

See: [GETTING_STARTED.md](./GETTING_STARTED.md)

## Documentation validation

- Audit + map: `node scripts/morphism-docs.mjs audit`
- Validate: `node scripts/morphism-docs.mjs validate`
- AGENTS pointer policy: `./scripts/check-agents-pointers.sh`
- Ecosystem inventory + atlas: `./workspace audit ecosystem --profile active --format all`

## Quality gates

- Fast local loop: `cd morphism && pnpm run quality:check:fast`
- Strict pre-merge gate: `cd morphism && pnpm run quality:check:strict`
- Deterministic CI profile: `cd morphism && pnpm run optimize:master:ci`
- Workspace standards gate: `./workspace validate standards`

## Multi-agent parallel lanes (git worktree)

- Spawn default parallel worktrees: `./scripts/worktree-agents.sh spawn`
- Create one lane: `./scripts/worktree-agents.sh create <agent-name> <branch> [base-ref]`
- List lanes: `./scripts/worktree-agents.sh list`
- Remove lane: `./scripts/worktree-agents.sh remove <agent-name>`

See: [MULTI_AGENT_WORKTREES.md](./MULTI_AGENT_WORKTREES.md)
