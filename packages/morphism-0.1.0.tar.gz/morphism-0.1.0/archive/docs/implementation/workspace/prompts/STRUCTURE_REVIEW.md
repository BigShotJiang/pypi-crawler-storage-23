# Prompt: Review and Validate Canonical Structure

Use this prompt with Claude, Codex, or any LLM to review and validate the workspace structure.

---

## Prompt

```
You are a workspace architect reviewing the Morphism workspace structure.

## Current State

The workspace has `CANONICAL_STRUCTURE.md` that defines:

### Root Directories
- `morphism/` - Governance and Core Framework (MORPHISM.md, AGENTS.md, SSOT.md required)
- `morphism-ship/` - Governed Extensions (follows morphism governance)
- `morphism-bible/` - Documentation and Specifications
- `morphism-references/` - Reference/Research knowledge base (non-SSOT)
- `morphism-profile/` - Personal/Internal (never ships)
- `_projects/` - Active product projects (apps/libs)
- `docs/` - Workspace Documentation (setup/, reference/, plans/, history/, audits/)
- `scripts/` - Workspace Scripts
- `lib/` - Workspace CLI support library (shared helpers for `./workspace`)
- `templates/` - Shared templates
- `PROMPTS/` - Human-run prompts (structure review, audits, migrations)
- `_archive/` - Curated archived projects/plans (read-only)
- `archive/` - Tool-generated snapshots/runtime artifacts (read-only)
- Active tooling projects may also live at root (e.g., agent-context-optimizer/, monorepo-health-analyzer/)

### Root Files Allowed
Root is intentionally small. Root-level Markdown is limited to workspace entrypoints (README,
CONTRIBUTING, canonical structure, architecture, catalogs, etc.). All other Markdown should live in
`docs/` or inside the owning project directory.

## Your Task

Analyze this structure and answer:

1. **Logical Coherence**: Does the separation of concerns make sense? Are there conflicts?

2. **Completeness**: Is anything missing? Should there be additional directories?

3. **Workflow Validation**: Does this structure support:
   - Clear governance
   - Independent project shipping
   - Documentation discoverability
   - Script automation
   - Historical preservation

4. **Naming**: Are directory names clear and consistent?

5. **Recommendations**: What changes would you suggest?

6. **Edge Cases**: What situations might this structure not handle well?

## Output Format

Respond with:
- Analysis of each directory's purpose and interactions
- Specific recommendations with reasoning
- Any potential issues you've identified
- Suggested improvements
```

---

## What to Expect

The AI should analyze:

- Whether `morphism/` as governance makes sense
- If `morphism-bible/` vs `docs/` separation is clear
- If `_archive/` vs `archive/` is properly scoped
- Whether root-level tooling projects conflict with the structure
- If ownership model is reasonable

---

## Example Output (what you should get)

```markdown
## Analysis

### 1. Logical Coherence

The structure follows clear separation of concerns:

- Governance lives in `morphism/`
- Shipped products live in `morphism-ship/`
- Personal work lives in `morphism-profile/`

**Potential Issue**: `docs/` vs `morphism-bible/` overlap. Both contain documentation.

### 2. Recommendations

- Clarify what goes in `docs/` vs `morphism-bible/`
- Consider moving `docs/workspace/` to `morphism-bible/guides/`
- Or define `docs/` as workspace-specific and `morphism-bible/` as general docs

### 3. Edge Cases

- What if a project spans multiple categories?
- What about cross-cutting concerns like scripts that touch multiple projects?
```

---

## Usage

1. Copy the prompt above
2. Give it to Claude, Codex, or any LLM
3. Review the analysis
4. Update CANONICAL_STRUCTURE.md based on recommendations
   - Canonical structure: `CANONICAL_STRUCTURE.md`
   - Ecosystem overview: `ARCHITECTURE.md`
