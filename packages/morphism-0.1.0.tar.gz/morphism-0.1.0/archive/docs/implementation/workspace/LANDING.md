# Workspace Landing

This workspace **adopts** the Morphism Categorical Governance Framework and hosts related project families.

## Start Here

1. Read [INDEX.md](./INDEX.md) for navigation.
2. Read [GETTING_STARTED.md](./GETTING_STARTED.md) for setup and daily flow.
3. Use [WORKFLOWS.md](./WORKFLOWS.md) for command-level operations.

## Governance

- Workspace governance: [AGENTS.md](../../AGENTS.md)
- Workspace SSOT: [SSOT.md](../../SSOT.md)
- Framework SSOT: [morphism/MORPHISM.md](../../morphism/MORPHISM.md)
- Consumer config: [.morphism/](../../.morphism/README.md)

## Operating Policy

- Run fast local checks before each commit.
- Run strict checks and optimization profile before merge.
- Keep commits scoped and reviewable.
