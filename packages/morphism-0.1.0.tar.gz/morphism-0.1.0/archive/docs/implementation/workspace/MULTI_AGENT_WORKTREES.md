# MULTI_AGENT_WORKTREES

Run parallel agent lanes safely using `git worktree` so each agent has an isolated branch and filesystem.

## Why this pattern

- Avoid branch collisions and accidental cross-task edits.
- Keep each agent focused on one lane of work.
- Merge lane branches independently after validation.

## Quick start

From workspace root:

```bash
./scripts/worktree-agents.sh spawn
```

This creates:

- `.worktrees/agent-cli` on `feat/workspace-cli-hardening`
- `.worktrees/agent-governance` on `docs/agents-pointer-standardization`
- `.worktrees/agent-performance` on `perf/workspace-status-fast`
- `.worktrees/agent-security` on `chore/security-governance-sweep`

## Common commands

```bash
./scripts/worktree-agents.sh list
./scripts/worktree-agents.sh create agent-docs docs/workspace-cleanup main
./scripts/worktree-agents.sh remove agent-docs
./scripts/worktree-agents.sh prune
```

## Suggested workflow

1. Spawn lanes.
2. Run one agent per lane.
3. Commit and push from each lane branch.
4. Open PRs per lane.
5. Merge in risk order:
   1. CLI reliability
   2. Governance/documentation
   3. Performance
   4. Security hardening

## Guardrails

- Never run one agent across multiple worktree lanes.
- Keep each lane narrow and scoped to one concern.
- Rebase lane branches onto `main` before opening PR.
