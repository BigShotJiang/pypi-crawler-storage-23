# Workspace Docs

This folder is the operational documentation lane for workspace-level usage.

Primary docs:

- `LANDING.md`
- `INDEX.md`
- `ARCHITECTURE.md`
- `CANONICAL_STRUCTURE.md`
- `GETTING_STARTED.md`
- `WORKFLOWS.md`
- `MULTI_AGENT_WORKTREES.md`
