# Morphism Workspace Architecture

**Overview of the Morphism ecosystem and how projects relate to each other**

## Table of Contents

- [Core Framework](#core-framework)
- [Agent Systems](#agent-systems)
- [CLI Tools](#cli-tools)
- [Web Platforms](#web-platforms)
- [Python Libraries](#python-libraries)
- [Data Flow](#data-flow)
- [Technology Stack](#technology-stack)

---

## Core Framework

### Morphism (`morphism/`)

The central framework that provides governance, agent rules, and SSOT (Single Source of Truth)
principles.

**Key Components:**

- `morphism/AGENTS.md` - Agent behavior rules
- `morphism/SSOT.md` - Single source of truth definitions
- `morphism/MORPHISM.md` - Core framework documentation

**Packages:**

- `@morphism-systems/core` - Core utilities and types
- `@morphism-systems/mcp` - Model Context Protocol integration
- `@morphism-systems/tools` - CLI tool suite (v2 target: 14+ commands)

**Morphism governance CLI (this repo):** Python package `morphism` provides the `morphism` binary. v1 commands: init, validate, ssot (extract/verify), docs (frontmatter/sync/graph), doctor, analyze. Install: `pip install morphism`. See [CLI_SCOPE.md](../../CLI_SCOPE.md) and [CLI_SCRIPT_MAP.md](../../CLI_SCRIPT_MAP.md).

---

## Agent Systems

### THE CIRCUS (`_archive/the-circus/`)

Validated agent orchestration with built-in hallucination prevention.

- **Type:** Agent System
- **Status:** Archived snapshot (read-only)
- **Tools:** 31+ tools
- **Features:** Hallucination prevention, validation

### Morphism Lab Agents (`morphism/lab/agents/`)

Research and specialized AI agents.

| Agent                 | Purpose                  |
| --------------------- | ------------------------ |
| category-theory-agent | Category theory research |
| logic-agent           | Logic and reasoning      |
| paper-research-agent  | Academic paper research  |
| proof-verifier-agent  | Proof verification       |
| topology-agent        | Topological analysis     |

---

## CLI Tools

### Morphism governance CLI (`morphism` binary)

| Command | Purpose |
|---------|---------|
| `morphism init` | Initialize .morphism/config.json |
| `morphism validate` | Run registry, policy, SSOT checks |
| `morphism ssot extract` / `morphism ssot verify` | SSOT registry extract and verify |
| `morphism docs frontmatter` / `sync` / `graph` | Docs frontmatter, sync, link graph |
| `morphism doctor` | Environment and path checks |
| `morphism analyze` | Convergence (κ) and robustness (δ) from score sequence |

Package: `morphism` (pip). Location: `src/morphism/cli/`, `src/morphism/tooling/`.

### Primary CLI Tools (ecosystem)

| Tool                         | Package                              | Purpose                      | Location                              |
| ---------------------------- | ------------------------------------ | ---------------------------- | ------------------------------------- |
| **KiloCode Hub CLI**         | `@kilocode/hub-cli`                  | Context hub management       | — (not in this checkout)              |
| **Agent Context Optimizer**  | `@morphism-systems/agent-context-optimizer`  | SSOT architecture generation | `_projects/agent-context-optimizer/`  |
| **Monorepo Health Analyzer** | `@morphism-systems/monorepo-health-analyzer` | Codebase analysis            | `_projects/monorepo-health-analyzer/` |

### Utility Tools

| Tool      | Language | Purpose                | Location              |
| --------- | -------- | ---------------------- | --------------------- |
| Codemap   | Python   | Code documentation     | `_projects/codemap/`  |
| Brand Kit | Python   | Brand asset generation | `_projects/brand-kit/` |
| QAPlibria | Python   | QAP optimization       | `_archive/qaplibria/` |

---

## Web Platforms

### Production Ready

| Platform      | Stack                     | Purpose                 | Location              |
| ------------- | ------------------------- | ----------------------- | --------------------- |
| **BOLTS.FIT** | Next.js, Supabase, Stripe | Fitness transformation  | `_projects/bolts/`    |
| **LLMWorks**  | Vite, React, Supabase     | LLM evaluation platform | `_projects/llmworks/` |

### In Development

| Platform           | Purpose                      | Location                 | Status             |
| ------------------ | ---------------------------- | ------------------------ | ------------------ |
| **Morphism Hub**   | Hub platform for ecosystem   | `hub/`                 | Development        |
| **Morphism Site**  | Marketing and documentation  | — (not in this checkout) | External/missing   |
| **HELIOS**         | Research discovery           | `_archive/helios/`       | Archived (snapshot) |
| **TalAI**          | Testing & laboratory AI      | `_archive/tal-ai/`       | Archived (snapshot) |

---

## Python Libraries

| Library       | Purpose                                   | Status             | Location               |
| ------------- | ----------------------------------------- | ------------------ | ---------------------- |
| **QAPlibria** | Quadratic Assignment Problem optimization | Archived (snapshot) | `_archive/qaplibria/`  |
| **Codemap**   | Code documentation generation             | Production         | `_projects/codemap/`   |
| **Brand Kit** | Brand asset automation                    | Production         | `_projects/brand-kit/` |

---

## Data Flow

```
┌─────────────────────────────────────────────────────────┐
│                    User / Developer                      │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                    CLI Tools                             │
│  ┌─────────────────┐  ┌─────────────────────────────┐  │
│  │ Hub CLI         │  │ Agent Context Optimizer     │  │
│  └─────────────────┘  └─────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────┐
│                 Core Framework                           │
│  ┌─────────────┐  ┌─────────────┐  ┌───────────────┐  │
│  │ @morphism-systems/  │  │ @morphism-systems/  │  │ @morphism-systems/    │  │
│  │ core        │  │ mcp         │  │ tools         │  │
│  └─────────────┘  └─────────────┘  └───────────────┘  │
└─────────────────────────────────────────────────────────┘
                           │
              ┌────────────┼────────────┐
              ▼            ▼            ▼
     ┌──────────────┐ ┌──────────────┐ ┌──────────────┐
     │ Web Platforms│ │ Agent Systems │ │ Python Libs  │
     └──────────────┘ └──────────────┘ └──────────────┘
```

---

## Technology Stack

### Languages

| Language                  | Usage                    | Percentage |
| ------------------------- | ------------------------ | ---------- |
| **TypeScript/JavaScript** | Frontend, CLI, Framework | 46%        |
| **Python**                | AI/ML, Research, CLI     | 26%        |
| **HTML/Static**           | Documentation, Landing   | 6%         |
| **Other**                 | Various                  | 22%        |

### Key Technologies

| Category       | Technologies                                   |
| -------------- | ---------------------------------------------- |
| **Frontend**   | React, Next.js 14, Vite, Radix UI, TailwindCSS |
| **Backend**    | Supabase, FastAPI, Node.js                     |
| **Testing**    | Jest, Vitest, Playwright, pytest               |
| **AI/ML**      | PyTorch, LLM Integration, AsyncIO              |
| **Monitoring** | Winston, prom-client                           |

---

## Project Relationships

### Hierarchy

```
Morphism Framework (Core)
    │
    ├── @morphism-systems/core (Foundation)
    │   └── @morphism-systems/mcp (MCP Integration)
    │   └── @morphism-systems/tools (CLI Tools)
    │       ├── Hub CLI (external)
    │       ├── Context Optimizer
    │       └── Health Analyzer
    │
    └── Web Platforms
        ├── Morphism Hub
        ├── Morphism Site (external)
        ├── BOLTS.FIT
        └── LLMWorks
```

### Dependencies

- **Hub CLI** (external) → Uses `@morphism-systems/core`
- **Agent Context Optimizer** → Uses `@morphism-systems/core`
- **Monorepo Health Analyzer** → Independent
- **Web Platforms** → May use any CLI tool

---

## Development Workflow

### Standard Flow

1. **Create** → New project in `_projects/` or `morphism/hub/packages/`
2. **Develop** → Follow workspace conventions
3. **Test** → Add tests (Vitest, Jest, or pytest)
4. **Document** → Add README.md and documentation
5. **Publish** → Release to npm or PyPI
6. **Audit** → Run Monorepo Health Analyzer

### Quality Gates

- [ ] Tests pass
- [ ] Linting passes
- [ ] Type checking passes
- [ ] Documentation complete
- [ ] Health score acceptable

---

## Getting Started

### New to the Workspace?

1. Read [README.md](README.md) for overview
2. Review [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines
3. Check [PROJECT_CATALOG.md](PROJECT_CATALOG.md) for project list
4. Explore [docs/](docs/) for detailed documentation

### Adding a New Project

1. Create project directory
2. Add `package.json` or `pyproject.toml`
3. Add `README.md` with setup instructions
4. Add tests directory
5. Update `PROJECT_CATALOG.md`

---

## Related Documentation

- [CONTRIBUTING.md](CONTRIBUTING.md) - Contribution guidelines
- [DOCUMENTATION-STYLE-GUIDE.md](DOCUMENTATION-STYLE-GUIDE.md) - Documentation standards
- [PROJECT_CATALOG.md](PROJECT_CATALOG.md) - Complete project list
- [docs/README.md](docs/README.md) - Documentation index

---

_Last Updated: 2026-02-08_
