# Morphism Workspace Guide

**Version:** 2.0.0
**Last Updated:** 2026-02-11
**Status:** ✅ Complete

---

## 🎯 Welcome

Welcome to the Morphism workspace! This guide will help you navigate the newly organized structure and understand where everything lives.

---

## 📐 Workspace Structure

```
Morphism Workspace/
│
├── 🏢 FRAMEWORK CORE
│   └── morphism/              # Morphism framework (kernel/hub/lab/profile)
│
├── 📦 PROJECT CATEGORIES
│   ├── Products/              # Production software
│   ├── Research/              # Research & experiments
│   └── Tools/                 # Utilities & dev tools
│
├── ⚙️ GOVERNANCE
│   └── .morphism/             # Templates, configs, reviewers, validation
│
├── 📚 DOCUMENTATION
│   ├── docs/                  # Workspace documentation
│   ├── WORKSPACE_GUIDE.md     # This file
│   ├── FINAL_MORPHISM_LAYOUT.md
│   └── [various guides]
│
├── 🔧 AUTOMATION
│   └── scripts/               # Automation scripts
│
└── 🗄️ ARCHIVES
    └── _archive/              # Archived projects
```

---

## 🗂️ Where Things Are

### Finding Projects

**"I want to work on the production platform"**
→ `Products/hub/`

**"I want to use a developer tool"**
→ `Tools/{tool-name}/`
- brand-kit - Branding toolkit
- codemap - Codebase visualization
- agent-context-optimizer - Context optimization
- monorepo-health-analyzer - Monorepo analysis
- skills-agents-inventory - Skills catalog

**"I want to see research/experimental work"**
→ `Research/{project-name}/`
- llmworks - LLM experimentation
- bolts - Experimental prototypes

**"I want to access the morphism framework"**
→ `morphism/` (kernel/hub/lab structure)

### Finding Templates

**"I want to create a new project"**
→ `.morphism/templates/projects/`
- product-web - Web applications
- product-cli - CLI applications
- tool-cli - CLI utilities
- tool-library - Libraries
- research-math - Mathematical research
- research-experimental - Experimental research

**"I need documentation templates"**
→ `.morphism/templates/docs/`
- ARCHITECTURE.template.md
- API.template.md
- DEPLOYMENT.template.md
- DEVELOPMENT.template.md

### Finding AI IDE Configurations

**"I want to configure my AI IDE"**
→ `.morphism/ide-configs/{ide-name}/`
- claude/ - Claude Code
- codex/ - Codex CLI
- cursor/ - Cursor IDE
- amazonq/ - Amazon Q
- windsurf/ - Windsurf (reserved)

**"I want to see the reviewer system"**
→ `.morphism/reviewers/`
- REGISTRY.md - Reviewer catalog
- architecture-boundary/
- entropy-guard/
- mcp-integration/
- ship-readiness/
- truth-documentation/

### Finding Documentation

**"I want to understand the workspace structure"**
→ This file (WORKSPACE_GUIDE.md)

**"I want to see the final layout plan"**
→ FINAL_MORPHISM_LAYOUT.md

**"I want to understand morphism principles"**
→ morphism/MORPHISM.md (in live repo: 7 invariants → 10 tenets; see [docs/governance/INVENTORY.md](../../governance/INVENTORY.md))

**"I want to see governance rules"**
→ morphism/AGENTS.md

**"I want to see the SSOT hierarchy"**
→ morphism/SSOT.md

---

## 🚀 Common Tasks

### Starting a New Project

**1. Choose Template:**
```bash
cd .morphism/templates/projects/
ls  # Browse available templates
```

**2. Copy Template:**
```bash
# Example: New web product
cp -r .morphism/templates/projects/product-web/ Products/my-new-app/
cd Products/my-new-app/
```

**3. Fill Variables:**
Replace all `{{VARIABLE}}` placeholders in README and configs

**4. Initialize:**
```bash
git init
pnpm install  # or appropriate package manager
```

**5. Update Category README:**
Add your project to the category README (Products/README.md, etc.)

---

### Using the Reviewer System

**1. Invoke Reviewer:**
```bash
# Via Claude Code
/review architecture-boundary

# Via manual read
cat .morphism/reviewers/architecture-boundary/REVIEWER.md
```

**2. Address Issues:**
Fix any issues identified by the reviewer

**3. Re-run:**
Verify fixes by running reviewer again

---

### Running Validation

**Full Validation:**
```bash
.morphism/validation/validate-all.sh
```

**Structure Only:**
```bash
.morphism/validation/validate-structure.sh
```

**From Any Directory:**
```bash
cd /path/to/workspace
.morphism/validation/validate-all.sh
```

---

### Working with Multiple AI IDEs

**Setup:**
```bash
# Symlinks already created during Phase 1
ls -la .claude .codex .cursor .amazonq
# All point to .morphism/ide-configs/{ide}/
```

**Configuration:**
Each IDE reads from its config directory automatically

**Consistency:**
All IDEs share:
- Same governance rules
- Same reviewer system
- Same validation framework

---

## 📚 Category Guide

### Products/ (Production Software)

**Purpose:** Production-ready applications for end users

**Standards:**
- Full test coverage
- CI/CD pipelines
- Production deployment
- Comprehensive documentation

**Template:** product-web or product-cli

**Current Projects:**
- hub/ - Morphism Hub platform

---

### Research/ (Research & Experiments)

**Purpose:** Mathematical formalization, experimental work

**Standards:**
- Proof-driven (for math)
- Experimental freedom
- Research documentation
- Theory papers

**Template:** research-math or research-experimental

**Current Projects:**
- llmworks/ - LLM experimentation
- bolts/ - Experimental prototypes

---

### Tools/ (Utilities)

**Purpose:** Developer tools, CLI utilities, libraries

**Standards:**
- Well-documented APIs
- Comprehensive examples
- Clear usage instructions
- Developer-focused

**Template:** tool-cli or tool-library

**Current Projects:**
- brand-kit/ - Branding toolkit
- codemap/ - Codebase cartography
- agent-context-optimizer/ - Context optimization
- monorepo-health-analyzer/ - Monorepo analysis
- skills-agents-inventory/ - Skills catalog

---

### _personal/ (Personal - Gitignored)

**Purpose:** Personal files, profiles, notes

**Standards:**
- Never committed to git
- Never shipped
- Personal use only

**Template:** None

**Current:**
- profile/ - Personal profiles

---

## 🎯 Decision Trees

### "Where should my new project go?"

```
Is it production software for users?
├─ YES → Products/
└─ NO
    └─ Is it research or experimental?
        ├─ YES → Research/
        └─ NO
            └─ Is it a developer tool/utility?
                ├─ YES → Tools/
                └─ NO → Ask in workspace discussion
```

### "Which template should I use?"

```
What type of project?
├─ Web application → product-web
├─ CLI application (product) → product-cli
├─ Mathematical research → research-math
├─ Experimental research → research-experimental
├─ CLI utility → tool-cli
└─ Library/package → tool-library
```

### "Which reviewer should I use?"

```
What are you doing?
├─ Changing structure/dependencies → architecture-boundary
├─ Refactoring code → entropy-guard
├─ Adding MCP server → mcp-integration
├─ Preparing for deployment → ship-readiness
├─ Updating documentation → truth-documentation
└─ Major PR → All reviewers
```

---

## ⚠️ Important Rules

### Git Rules

1. **Never commit:**
   - _personal/ directory
   - .env files
   - Secrets or API keys
   - Large binaries

2. **Always verify:**
   - .gitignore is correct
   - No secrets in commits
   - Tests pass before push

### Morphism Rules

1. **Always:**
   - Read MORPHISM.md before governance reasoning
   - Run validation before pushing
   - Use appropriate templates

2. **Ask first:**
   - Before adding MCP connections
   - Before structural changes
   - Before modifying workflows

3. **Never:**
   - Mix personal and shared code
   - Bypass validation
   - Modify core framework without review

---

## 🔧 Troubleshooting

### "I can't find a project"

1. Check category (Products/Research/Tools)
2. Search in _archive/ if very old
3. Check if it's in _projects/ (pre-migration)

### "Template variables aren't replaced"

1. Manually find and replace {{VARIABLE}}
2. Check .morphism/templates/README.md for variable list
3. Use search & replace in your editor

### "Validation fails"

1. Read error messages carefully
2. Fix identified issues
3. Re-run validation
4. Ask for help if stuck

### "Reviewer gives unclear feedback"

1. Re-read the reviewer spec
2. Check examples in REVIEWER.md
3. Ask in workspace discussion

---

## 📖 Key Documents

| Document | Purpose |
|----------|---------|
| **WORKSPACE_GUIDE.md** | This file - navigation guide |
| **FINAL_MORPHISM_LAYOUT.md** | Complete structure spec |
| **MORPHISM_STRUCTURE_AUDIT.md** | Structure analysis |
| **PROJECT_CATEGORIZATION.md** | Project categorization plan |
| **PHASE_1_COMPLETE.md** | Phase 1 implementation |
| **PHASE_2_COMPLETE.md** | Phase 2 implementation |
| **morphism/MORPHISM.md** | Framework axioms & tenets |
| **morphism/AGENTS.md** | Governance rules |
| **morphism/SSOT.md** | Truth hierarchy |

---

## 🎉 Quick Wins

### Start Developing Immediately

```bash
# Pick a project
cd Products/hub  # or Tools/brand-kit, etc.

# Install dependencies
pnpm install

# Start development
pnpm dev
```

### Create a New Tool

```bash
# Copy template
cp -r .morphism/templates/projects/tool-cli Tools/my-new-tool

# Customize
cd Tools/my-new-tool
# Edit README.md, package.json, etc.

# Initialize
pnpm install
pnpm build
```

### Run Quality Checks

```bash
# Full validation
.morphism/validation/validate-all.sh

# Structure check
.morphism/validation/validate-structure.sh

# Reviewer (via Claude Code)
/review architecture-boundary
```

---

## 🤝 Getting Help

### Resources

1. **This Guide** - General navigation
2. **Template READMEs** - Project-specific help
3. **Reviewer Specs** - Quality guidance
4. **Morphism Docs** - Framework principles

### Support Channels

- GitHub Issues (for bugs)
- Workspace Discussions (for questions)
- Code Reviews (for feedback)

---

## 🎯 Next Steps

1. **Explore** - Browse the new structure
2. **Experiment** - Try creating a project with templates
3. **Validate** - Run validation scripts
4. **Review** - Try the reviewer system
5. **Build** - Start developing!

---

**Welcome to the organized Morphism workspace!** 🎉

**Version 2.0.0** • Refactored February 2026
