# Getting Started

## Prerequisites

- Git installed
- Node.js and pnpm installed (for `morphism/`)
- Bash available for workspace scripts

## First-Time Setup

1. Review [LANDING.md](./LANDING.md).
2. Review top-level [README.md](../../README.md).
3. Enter `morphism/` and install dependencies:

```bash
cd morphism
pnpm install
```

## Daily Development Flow

1. Create a branch for one concern.
2. Make scoped changes.
3. Run fast local checks:

```bash
cd morphism
pnpm run quality:check:fast
```

4. Commit with explicit file paths (`git add <paths>`).
5. Before merge, run strict checks:

```bash
cd morphism
pnpm run quality:check:strict
pnpm run optimize:master:ci
```
