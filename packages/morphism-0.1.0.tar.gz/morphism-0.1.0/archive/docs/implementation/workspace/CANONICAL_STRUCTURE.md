# CANONICAL_STRUCTURE (pointer)

**Canonical:** [../../CANONICAL_STRUCTURE.md](../../CANONICAL_STRUCTURE.md)

This file is a pointer for workspace-docs navigation. The authoritative canonical structure lives
at the workspace root in `CANONICAL_STRUCTURE.md`.

