# Project Categorization Plan

**Date:** 2026-02-11
**Purpose:** Categorize all projects in `_projects/` for migration to Products/Research/Tools

---

## 📋 Projects to Categorize

### From _projects/

1. agent-context-optimizer
2. aiclairty
3. bolts
4. brand-kit
5. codemap
6. llmworks
7. monorepo-health-analyzer
8. profile
9. skills-agents-inventory

### From Root

10. hub/

---

## 🎯 Categorization

### Products/ (Production Software)

#### hub/
**Type:** Web Application
**Stack:** Next.js + Supabase
**Template:** product-web
**Action:** Move from root → Products/hub/
**Reason:** Main production platform, deployed to production, full web app

#### aiclairty/
**Type:** Web Application
**Stack:** React/TypeScript
**Template:** product-web
**Action:** Move from _projects/ → Products/aiclairty/
**Reason:** AI clarity platform product (if production-ready)
**Note:** Check deployment status first

---

### Research/ (Exploratory/Experimental)

#### llmworks/
**Type:** Experimental Research
**Stack:** Python
**Template:** research-experimental
**Action:** Move from _projects/ → Research/llmworks/
**Reason:** LLM experimentation and research

#### bolts/
**Type:** Experimental Project
**Stack:** Unknown (check)
**Template:** research-experimental
**Action:** Move from _projects/ → Research/bolts/
**Reason:** Exploratory/experimental work

---

### Tools/ (Utilities & Developer Tools)

#### brand-kit/
**Type:** CLI Tool
**Stack:** TypeScript
**Template:** tool-cli
**Action:** Move from _projects/ → Tools/brand-kit/
**Reason:** Branding toolkit utility

#### codemap/
**Type:** CLI Tool
**Stack:** TypeScript
**Template:** tool-cli
**Action:** Move from _projects/ → Tools/codemap/
**Reason:** Codebase cartographer tool

#### agent-context-optimizer/
**Type:** CLI/Library Tool
**Stack:** TypeScript (likely)
**Template:** tool-cli or tool-library
**Action:** Move from _projects/ → Tools/agent-context-optimizer/
**Reason:** Context optimization utility

#### monorepo-health-analyzer/
**Type:** CLI Tool
**Stack:** TypeScript (likely)
**Template:** tool-cli
**Action:** Move from _projects/ → Tools/monorepo-health-analyzer/
**Reason:** Monorepo analysis tool

#### skills-agents-inventory/
**Type:** CLI/Library Tool
**Stack:** Unknown (check)
**Template:** tool-cli or tool-library
**Action:** Move from _projects/ → Tools/skills-agents-inventory/
**Reason:** Skills/agents cataloging tool

---

### _personal/ (Personal - Gitignored)

#### profile/
**Type:** Personal Data
**Stack:** N/A
**Template:** None (gitignored)
**Action:** Move from _projects/ → _personal/profile/
**Reason:** Personal profiles, never shipped

---

## 📊 Summary

| Category | Projects | Templates Needed |
|----------|----------|------------------|
| **Products** | 2 | product-web (2x) |
| **Research** | 2 | research-experimental (2x) |
| **Tools** | 5 | tool-cli (5x) |
| **_personal** | 1 | None (gitignored) |
| **Total** | 10 | 9 templates |

---

## 🚀 Migration Order

### Phase 1: High Priority (Production)
1. ✅ hub/ → Products/hub/
   - Production platform
   - Already deployed
   - Apply product-web template

### Phase 2: Tools (Development Infrastructure)
2. ✅ brand-kit/ → Tools/brand-kit/
3. ✅ codemap/ → Tools/codemap/
4. ✅ agent-context-optimizer/ → Tools/agent-context-optimizer/
5. ✅ monorepo-health-analyzer/ → Tools/monorepo-health-analyzer/
6. ✅ skills-agents-inventory/ → Tools/skills-agents-inventory/

### Phase 3: Research (Experimental)
7. ✅ llmworks/ → Research/llmworks/
8. ✅ bolts/ → Research/bolts/

### Phase 4: Products (Conditional)
9. ⏸️ aiclairty/ → Products/aiclairty/ (check status first)

### Phase 5: Personal
10. ✅ profile/ → _personal/profile/

---

## 🔄 Migration Process

For each project:

1. **Verify Current State**
   - Check if project is in use
   - Verify dependencies
   - Note any special configurations

2. **Move to Category**
   ```bash
   mv _projects/{project} {Category}/{project}
   ```

3. **Apply Template**
   - Copy appropriate README.template.md
   - Fill in variables
   - Merge with existing README if present

4. **Update Documentation**
   - Add to category README
   - Update cross-references
   - Document any special notes

5. **Verify**
   - Check build still works
   - Update any hardcoded paths
   - Run validation

---

## ⚠️ Special Considerations

### hub/
- Already has comprehensive documentation
- Merge template carefully, don't overwrite
- Preserve all existing config
- Update paths in workflows

### aiclairty/
- Check deployment status before categorizing
- May be archived or incomplete
- Verify if it should be in Products or Research

### profile/
- Must be gitignored completely
- No templates needed
- Document that it's personal only

---

## ✅ Success Criteria

- [ ] All 10 projects categorized
- [ ] 9 templates applied
- [ ] All READMEs updated
- [ ] Cross-references updated
- [ ] Validation passing
- [ ] No broken dependencies

---

**Next:** Execute migration starting with hub/
