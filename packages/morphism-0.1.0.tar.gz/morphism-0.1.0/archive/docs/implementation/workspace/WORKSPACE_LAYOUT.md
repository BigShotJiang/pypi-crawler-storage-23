# Workspace Layout

This document is a map of the workspace root and where things live.

**Canonical directory policy:** See [AGENTS.md](../../AGENTS.md) for workspace scope.

## Quick Links

- Workspace overview: `README.md`
- Workspace governance: `AGENTS.md`
- Ecosystem overview: `docs/workspace/ARCHITECTURE.md`
- Workspace docs index: `docs/README.md`
- Framework authority: `morphism/MORPHISM.md`, `morphism/AGENTS.md`, `morphism/SSOT.md`

## Root Map (High Level)

```text
GitHub/
├── morphism/              # Framework source (self-governed, independent)
├── .morphism/             # Consumer config (workspace-level Morphism settings)
├── bible/                 # Ecosystem docs (includes references/)
├── hub/                   # Ecosystem SaaS platform
├── cloud/                 # Ecosystem cloud infra (includes deployment/)
├── _projects/             # Independent projects (governance opt-in)
│   ├── profile/           # Personal portfolio (out of scope)
│   ├── agent-context-optimizer/
│   └── monorepo-health-analyzer/
├── docs/                  # Workspace documentation
├── scripts/               # Workspace automation
├── lib/                   # Workspace CLI support (used by ./workspace)
├── templates/             # Shared templates
├── PROMPTS/               # Human-run LLM prompts
├── _archive/              # Curated archives (read-only)
└── archive/               # Tool-generated snapshots (read-only)
```

## Documentation Policy

- Root-level Markdown is limited to workspace governance entrypoints (`AGENTS.md`,
  `SSOT.md`, `CLAUDE.md`, `README.md`).
- Workspace operating docs live in `docs/`.
- Project-specific docs live with the project (or link into `docs/` only when truly
  workspace-wide).

## Deployment (High Level)

Deployment is owned by the project that ships. Look for project-local deployment docs (for example,
`DEPLOYMENT*.md`, `README.md`, or `docs/` inside the project).

For Morphism core governance and release workflows, start in `morphism/` (for example,
`morphism/RELEASE-CHECKLIST.md`).

## Recovery / Remediation (High Level)

- Pointer integrity: `bash ./scripts/check-agents-pointers.sh`
- Structure drift (Morphism core): `cd morphism && pnpm run validate:structure`
- Security preflight before pushing: `bash ./scripts/security-preflight.sh`
