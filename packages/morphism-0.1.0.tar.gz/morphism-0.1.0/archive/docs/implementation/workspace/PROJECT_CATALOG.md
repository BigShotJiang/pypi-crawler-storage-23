# Project Catalog

**Generated:** 2026-02-08  
**Last Updated:** 2026-02-08  
**Total Projects:** 52+  
**Production Ready:** 10

## Quick Links

- [Production Ready](#-production-ready)
- [Ready for Publication](#-ready-for-publication)
- [Active Development](#-active-development)
- [Morphism Hub Packages](#-morphism-hub-packages)
- [Morphism Lab Agents](#-morphism-lab-agents)
- [Desktop Projects](#-desktop-projects)
- [Recommendations](#-recommendations)

---

## 🚀 PRODUCTION READY

### Web Platforms

| #   | Project       | Package                              | Version | Tech Stack                                                       | Location              |
| --- | ------------- | ------------------------------------ | ------- | ---------------------------------------------------------------- | --------------------- |
| 1   | **BOLTS.FIT** | @boltsfit/web → @alawein/boltsfit    | 1.0.0   | Next.js 14, React, TypeScript, Supabase, Stripe, Playwright      | `_projects/bolts/`    |
| 2   | **LLMWorks**  | @meshal/llmworks → @alawein/llmworks | 1.0.0   | Vite, React, Radix UI, TailwindCSS, Supabase, Playwright, Vitest | `_projects/llmworks/` |

### Python Libraries

| #   | Project       | Package   | Version | Tech Stack                                     | Location               |
| --- | ------------- | --------- | ------- | ---------------------------------------------- | ---------------------- |
| 3   | **QAPlibria** | qaplibria | 0.1.0   | Python 3.10+, NumPy, SciPy, Matplotlib, pytest | `_archive/qaplibria/` (archived snapshot) |

### CLI Tools

| #   | Project              | Package                                       | Version | Tech Stack                                              | Location                                |
| --- | -------------------- | --------------------------------------------- | ------- | ------------------------------------------------------- | --------------------------------------- |
| 3a  | **Morphism governance CLI** | morphism (pip) | 0.1.0 | Python, Click; init/validate/ssot/docs/doctor/analyze | src/morphism/cli/ |
| 4   | **KiloCode Hub CLI** | @kilocode/hub-cli → @morphism-systems/hub-cli | 1.0.0   | Node.js, ES Modules, Commander.js                       | — (not in this checkout)                |
| 5   | **Brand Kit**        | brand-kit → @alawein/brand-kit                | -       | Python                                                  | `_projects/brand-kit/`                  |
| 6   | **Codemap**          | codemap → @alawein/codemap                    | -       | Python                                                  | `_projects/codemap/`                    |
| 7   | **@morphism-systems/tools**  | @morphism-systems/tools → @morphism-systems/tools     | 2.0.0   | Node.js, TypeScript, Winston, prom-client, 14+ binaries | `morphism/hub/packages/morphism-tools/` |

### Agent Systems

| #   | Project          | Package                                             | Version | Tech Stack        | Location                |
| --- | ---------------- | --------------------------------------------------- | ------- | ----------------- | ----------------------- |
| 8   | **THE CIRCUS**   | @circus/validated-8-agent-orchestration → @alawein/circus-agent | -       | Node.js, 31 tools | `_archive/the-circus/` (archived snapshot) |

### Libraries/Frameworks

| #   | Project            | Package                                 | Version | Tech Stack          | Location                               |
| --- | ------------------ | --------------------------------------- | ------- | ------------------- | -------------------------------------- |
| 9   | **@morphism-systems/core** | @morphism-systems/core → @morphism-systems/core | 1.0.0   | TypeScript, Vitest  | `morphism/hub/packages/morphism-core/` |
| 10  | **@morphism-systems/mcp**  | @morphism-systems/mcp → @morphism-systems/mcp   | 2.0.0   | TypeScript, MCP SDK | `morphism/hub/packages/morphism-mcp/`  |

---

## 📦 READY FOR PUBLICATION

| #   | Project                      | Package                                                                         | Version | Tech Stack                               | Location                    |
| --- | ---------------------------- | ------------------------------------------------------------------------------- | ------- | ---------------------------------------- | --------------------------- |
| 11  | **Agent Context Optimizer**  | @morphism-systems/agent-context-optimizer → @morphism-systems/agent-context-optimizer   | 0.1.0   | TypeScript, Commander.js, Mustache, Jest | `_projects/agent-context-optimizer/`  |
| 12  | **Monorepo Health Analyzer** | @morphism-systems/monorepo-health-analyzer → @morphism-systems/monorepo-health-analyzer | 0.1.0   | TypeScript, Commander.js, Vitest, tsup   | `_projects/monorepo-health-analyzer/` |

---

## 📄 TEMPLATES

| #   | Template              | Version | Tech Stack                                    | Location                   |
| --- | --------------------- | ------- | --------------------------------------------- | -------------------------- |
| 13  | **REST API Template** | 1.0.0   | Express, TypeScript, Jest, Supertest          | — (not in this checkout)   |
| 14  | **SaaS Template**     | 0.1.0   | Next.js 14, React, TailwindCSS, Zustand, Jest | — (not in this checkout)   |

---

## 🚧 ACTIVE DEVELOPMENT

### Local Project Checkouts

| #   | Project   | Type              | Status              | Tech Stack               | Location                 |
| --- | --------- | ----------------- | ------------------- | ------------------------ | ------------------------ |
| 15  | AIClairty | Web Platform      | Assessment Needed   | HTML-based               | `_projects/aiclairty/`   |
| 16  | HELIOS    | Research Platform | Archived (snapshot) | Python, FastAPI, PyTorch | `_archive/helios/`       |
| 17  | TalAI     | AI Platform       | Archived (snapshot) | Python, AsyncIO, LLM     | `_archive/tal-ai/`       |

### Morphism Framework

| #   | Project             | Package                                  | Version | Type                  | Location               |
| --- | ------------------- | ---------------------------------------- | ------- | --------------------- | ---------------------- |
| 18  | Morphism Framework  | morphism → @morphism-systems/framework   | 0.1.0   | Framework/Monorepo    | `morphism/`            |
| 19  | Morphism Hub        | morphism-hub → @morphism-systems/hub     | 0.1.0   | Web Platform          | `hub/`                   |
| 20  | Morphism Site       | morphism-site → @morphism-systems/site   | 0.1.0   | Marketing Site        | — (not in this checkout) |
| 21  | Morphism Cloud      | morphism-cloud                           | -       | Cloud Infra + Deploy  | `cloud/`                 |
| 22  | Morphism Bible      | -                                        | -       | Documentation         | `bible/`                 |
| 23  | Morphism Profile    | -                                        | -       | Portfolio System      | `_projects/profile/`     |

---

## 🔬 MORPHISM HUB PACKAGES

### Core Hub (`morphism/hub/packages/`)

| #   | Package               | Version | Type          | Status      |
| --- | --------------------- | ------- | ------------- | ----------- |
| 25  | morphism-agentic-math | -       | Library       | Development |
| 26  | morphism-audit        | -       | Tool          | Development |
| 27  | morphism-plugin       | -       | Plugin System | Development |

### Cloud Deployment Hub (`cloud/deployment/hub/packages/`)

| #   | Package                      | Type            | Description                             | Status      |
| --- | ---------------------------- | --------------- | --------------------------------------- | ----------- |
| 28  | atelier-rounaq               | Creative Studio | Creative design workspace               | Development |
| 29  | branding-automation-platform | Platform        | Automated branding workflows            | Development |
| 30  | brandos                      | OS              | Brand operating system                  | Development |
| 31  | brandy                       | Tool            | GitHub Spark template (private, v0.0.0) | Development |
| 32  | bwiz                         | Tool            | Business intelligence tool              | Development |
| 33  | meshy-tools                  | Tools           | Mesh processing tools                   | Development |
| 34  | pixelsmith                   | Design Tool     | Pixel manipulation                      | Development |
| 35  | promolabs                    | Platform        | Promotion and marketing lab             | Development |
| 36  | @4ship/ui                    | 0.1.0           | UI Library                              | Development |

---

## 🧪 MORPHISM LAB AGENTS

| #   | Agent                 | Type           | Location               |
| --- | --------------------- | -------------- | ---------------------- |
| 37  | category-theory-agent | Research Agent | `morphism/lab/agents/` |
| 38  | logic-agent           | Research Agent | `morphism/lab/agents/` |
| 39  | paper-research-agent  | Research Agent | `morphism/lab/agents/` |
| 40  | proof-verifier-agent  | Research Agent | `morphism/lab/agents/` |
| 41  | topology-agent        | Research Agent | `morphism/lab/agents/` |

---

## 🖥️ DESKTOP PROJECTS

### Fitness (`C:/Users/mesha/Desktop/---DESKTOP---/Fitness/`)

| #   | Project           | Type              | Status | Notes                      |
| --- | ----------------- | ----------------- | ------ | -------------------------- |
| 42  | **REPZ**          | Fitness Platform  | Active | Comprehensive JSON schemas |
| 43  | COACHES           | Coaching Platform | Active | -                          |
| 44  | PEDs              | Platform          | Active | -                          |
| 45  | PEDs-Monetization | Platform          | Active | -                          |

### Business (`C:/Users/mesha/Desktop/---DESKTOP---/Business/`)

| #   | Project      | Type              | Status | Notes                      |
| --- | ------------ | ----------------- | ------ | -------------------------- |
| 46  | **SparkFit** | Web Platform      | Active | **Duplicate of BOLTS.FIT** |
| 47  | Repz         | Platform          | Active | -                          |
| 48  | LiveItIconic | Platform          | Active | -                          |
| 49  | Coaching     | Coaching Platform | Active | -                          |

---

## 📊 SUMMARY STATISTICS

| Metric                    | Count  |
| ------------------------- | ------ |
| **Production Ready**      | 10     |
| **Ready for Publication** | 2      |
| **Templates**             | 2      |
| **Active Development**    | 12     |
| **Hub Packages**          | 15     |
| **Lab Agents**            | 5      |
| **Desktop Projects**      | 8      |
| **TOTAL**                 | **54** |

---

## 🏷️ LANGUAGE DISTRIBUTION

| Language              | Projects | Percentage |
| --------------------- | -------- | ---------- |
| TypeScript/JavaScript | 25+      | 46%        |
| Python                | 14+      | 26%        |
| HTML/Static           | 3        | 6%         |
| Mixed/Other           | 12+      | 22%        |

---

## 🎯 RECOMMENDATIONS

### Immediate Actions (This Week)

1. ✅ Publish **QAPlibria** to PyPI
2. ✅ Deploy **BOLTS.FIT** to production
3. ✅ Deploy **LLMWorks** to production
4. ✅ Publish **3 Morphism Hub packages** (@morphism-systems/tools, @morphism-systems/mcp, @morphism-systems/core)
5. ✅ Publish **3 standalone CLI tools**

### Short-Term Actions (Next 2 Weeks)

6. Assess **REPZ** and **SparkFit** Desktop projects
7. Complete **Morphism Hub** MVP (v1.0.0)
8. Package remaining **Morphism Hub** tools

### Name Changes Required

| Old Name                           | New Name                                   | Reason                |
| ---------------------------------- | ------------------------------------------ | --------------------- |
| @meshal/llmworks                   | @alawein/llmworks                          | Namespace consistency |
| @boltsfit/web                      | @alawein/boltsfit                          | Namespace consistency |
| @morphism-systems/core                     | @morphism-systems/core                     | Company namespace     |
| @morphism-systems/mcp                      | @morphism-systems/mcp                      | Company namespace     |
| @morphism-systems/tools                    | @morphism-systems/tools                    | Company namespace     |
| @kilocode/hub-cli                  | @morphism-systems/hub-cli                  | Company namespace     |
| @morphism-systems/agent-context-optimizer  | @morphism-systems/agent-context-optimizer  | Company namespace     |
| @morphism-systems/monorepo-health-analyzer | @morphism-systems/monorepo-health-analyzer | Company namespace     |

---

## 📝 NOTES

- **SparkFit** (Desktop) is a duplicate of **BOLTS.FIT** with extensive content/documentation
- **REPZ** has comprehensive JSON schemas (plan, client-profile, lab-result, pharmacology)
- **brandy** is a private GitHub Spark template (not shippable)
- **@4ship/ui** is in early development (v0.1.0)

---

## CLI Commands in @morphism-systems/tools

1. `morphism` - Main CLI
2. `morphism-init` - Initialize project
3. `morphism-apply` - Apply template
4. `morphism-validate` - Validate template
5. `morphism-diff` - Diff template
6. `morphism-coverage` - Coverage report
7. `morphism-analyze` - Session analyzer
8. `morphism-sanitize` - Sanitize secrets
9. `morphism-setup` - Setup (bash)
10. `morphism-setup-windows` - Setup (PowerShell)
11. `morphism-drift` - Drift detection
12. `morphism-orchestrate` - Orchestration

---

_Last Updated: 2026-02-08_  
_Discovery Status: Complete_
