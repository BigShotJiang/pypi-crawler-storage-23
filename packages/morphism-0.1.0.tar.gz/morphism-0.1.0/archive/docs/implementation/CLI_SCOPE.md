# Morphism CLI — Scope and guardrails

**Purpose:** Lock distribution, naming, v1/v2 scope, and Definition of Done for the Morphism CLI and tooling build. No references to external source projects in repo code or public docs; provenance is captured in a private/internal note only.

---

## Decisions (Phase 0)

| Decision | Choice | Rationale |
|----------|--------|------------|
| **Primary distribution** | Python-only | Single `morphism` entrypoint via `pip install morphism` and `python -m morphism`. No npm package in v1. |
| **v1 scope** | Minimal core | Commands: init, validate, ssot (extract/verify), docs (frontmatter/sync/graph), doctor. Full suite (inventory, audit, security, drift, release, generate, watch) deferred to v2. |
| **Convergence-metrics depth** | Metrics only | One module (`convergence.py`) with convergence constant (κ) and robustness delta (δ); one CLI command (`morphism analyze` or `morphism drift`). No deeper agent/network APIs in v1. |

---

## Naming

- **Binary:** `morphism`. Subcommands as groups (e.g. `morphism ssot extract`, `morphism docs sync`).
- **Package:** Python package name `morphism`; entry point `morphism = morphism.cli.main:cli` (see [pyproject.toml](../../pyproject.toml)).
- **No external references:** No external project names in code, docstrings, or user-facing documentation. Pattern provenance (CLI layout, scaffolding, config validation, drift scoring, metrics formulas) is recorded in a single private/internal note (e.g. `.morphism/internal/PROVENANCE.md`), gitignored or access-controlled.

---

## Scope

### v1 (minimal core)

- `morphism init` — Initialize `.morphism/config.json` from defaults/templates.
- `morphism validate` — Run validate-registry, policy_check, ssot_verify; aggregate pass/fail.
- `morphism ssot extract` — Wrap ssot_extract.py.
- `morphism ssot verify` — Wrap ssot_verify.py.
- `morphism docs` — Subcommands/flags for frontmatter, sync, graph (wrap docs_frontmatter, docs_sync, docs_graph).
- `morphism doctor` — Environment checks (Python version, key paths, env vars).

### v2 (full suite)

- inventory, audit, security, drift, release, generate, watch (and any remaining commands from the 14-command target in PROJECT_CATALOG).

---

## Definition of Done

- All v1 commands run locally and produce **deterministic exit codes**: 0 = success, 1 = validation/execution failure, 2 = usage error.
- Help text and README match actual commands and behavior.
- [ARCHITECTURE.md](workspace/ARCHITECTURE.md) and [PROJECT_CATALOG.md](workspace/PROJECT_CATALOG.md) updated so "CLI" and "14+ binaries" claims match reality (or are explicitly scoped to "v1: N commands" / "v2: full suite").

---

## No external references rule

Code, docstrings, and user-facing docs in this repo **must not** name or link to external source projects. Provenance of patterns (e.g. CLI scaffolding, config validation, drift scoring, convergence metrics) is maintained only in a private/internal note, not in the public tree.

---

*Governance: [AGENTS.md](../../AGENTS.md), [GUIDELINES.md](../../GUIDELINES.md), [docs/HANDOFF.md](../../docs/HANDOFF.md).*
