# Credential Management System

**Version:** 1.0.0 | **Owner:** @alawein | **Updated:** 2026-02-09

## Overview

The Morphism Credential Management System provides centralized, version-controlled
storage for all secrets (API keys, tokens, database passwords) across the ecosystem.

**Architecture:**

```
.secrets/                          ← Encrypted vault (gitignored)
├── github.env                     ← GitHub tokens
├── morphism-hub-supabase.env      ← Morphism Hub Supabase keys
├── supabase.env                   ← meshal-website Supabase keys
├── clerk.env                      ← Clerk auth keys
├── stripe.env                     ← Stripe billing keys
├── gemini.env                     ← Google Gemini AI key
├── vercel.env                     ← Vercel tokens
├── master.env                     ← Combined (auto-generated)
├── _history/                      ← Timestamped backups
└── _checksums.sha256              ← Integrity checksums

scripts/manage-secrets.sh          ← CLI for vault operations
scripts/scan-credentials.sh        ← Automated scanner
.morphism/credential-provider.sh   ← IDE/shell credential injection
.morphism/access-control.yml       ← Role-based access definitions
.morphism/mcp-credentials.json     ← MCP credential references (env var refs only)
CODEOWNERS                         ← GitHub review requirements
```

---

## Quick Start

### View all credentials (masked)
```bash
./scripts/manage-secrets.sh list
```

### Get a specific credential
```bash
./scripts/manage-secrets.sh get STRIPE_SECRET_KEY
```

### Update a credential (creates automatic backup)
```bash
./scripts/manage-secrets.sh set GEMINI_API_KEY "AIzaSy..."
```

### Load all credentials into your terminal session
```bash
source .morphism/credential-provider.sh
# Or load project-specific:
source .morphism/credential-provider.sh morphism-hub
```

### Inject vault into morphism-hub/.env.local
```bash
./scripts/manage-secrets.sh inject morphism-hub
```

### Run integrity scan
```bash
./scripts/manage-secrets.sh scan
# Or the standalone scanner with JSON output:
./scripts/scan-credentials.sh --json
```

---

## Credential Files

### Service Files

| File | Purpose | Keys |
|------|---------|------|
| `github.env` | GitHub PATs, deploy keys | `GITHUB_TOKEN`, `GITHUB_PAT` |
| `morphism-hub-supabase.env` | Morphism Hub database | `NEXT_PUBLIC_SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, DB password |
| `supabase.env` | meshal-website database | `SUPABASE_URL`, `SUPABASE_ANON_KEY` |
| `clerk.env` | Authentication (Clerk) | `CLERK_PUBLISHABLE_KEY`, `CLERK_SECRET_KEY` |
| `stripe.env` | Billing (Stripe) | `STRIPE_SECRET_KEY`, price IDs |
| `gemini.env` | AI (Google Gemini) | `GEMINI_API_KEY` |
| `vercel.env` | Deployment (Vercel) | OIDC tokens, project IDs |
| `master.env` | Combined export | Auto-generated from all above |

### Adding a New Service

1. Create `.secrets/newservice.env` with credentials
2. Add the filename to the `SERVICE_FILES` array in `scripts/manage-secrets.sh`
3. Run `./scripts/manage-secrets.sh rebuild` to update master.env
4. Run `./scripts/manage-secrets.sh scan` to verify

---

## Overwrite Protection

Every modification via `manage-secrets.sh set` automatically:

1. **Creates a timestamped backup** in `.secrets/_history/`
2. **Logs the change** (old prefix → new prefix)
3. **Updates checksums** for integrity verification

To manually backup the entire vault:
```bash
./scripts/manage-secrets.sh backup
```

Previous versions are stored as:
```
.secrets/_history/stripe.env.2026-02-09T14-30-00
.secrets/_history/full-backup-2026-02-09T14-30-00/
```

---

## Access Control

Defined in `.morphism/access-control.yml`.

### Roles

| Role | Permissions | Who |
|------|------------|-----|
| **Owner** | Read, write, rotate, delete, grant/revoke access | @alawein |
| **Consumer** | Read-only (for CI/IDE credential injection) | GitHub Actions runners |
| **Auditor** | Scan results only, no raw values | — |

### GitHub Integration

- **CODEOWNERS**: All credential paths require @alawein review
- **Authentication**: GitHub account identity
- **CI/CD**: GitHub Actions secrets (never stored in repo)

---

## IDE Integration

### VS Code Task

The workspace includes a "Load Secrets" task. Run it via:
- `Ctrl+Shift+P` → "Tasks: Run Task" → "Load Secrets"

### Terminal Integration

```bash
# Load all credentials
source .morphism/credential-provider.sh

# Load only Morphism Hub credentials
source .morphism/credential-provider.sh morphism-hub

# Load only GitHub credentials
source .morphism/credential-provider.sh github
```

### MCP Server Integration

MCP servers should reference credentials via environment variables, not raw values.
See `.morphism/mcp-credentials.json` for the reference template.

**Startup pattern:**
```bash
# 1. Load credentials into env
source .morphism/credential-provider.sh
# 2. Start MCP server (reads from env)
node my-mcp-server.js
```

---

## CI/CD Integration

### GitHub Actions

Credentials for CI are stored as **GitHub Actions Secrets** (separate from the vault).
The vault is the source of truth; GitHub Secrets are copies.

Required GitHub Secrets:
- `VERCEL_TOKEN` — Vercel deployment
- `VERCEL_ORG_ID` — Vercel org
- `VERCEL_PROJECT_ID` — Vercel project

### Vercel Environment Variables

Set via `vercel env add`:
```bash
# These are already set on Vercel for morphism-hub
vercel env ls
```

Sync vault → Vercel:
```bash
# Manual process (Vercel CLI doesn't support bulk import)
./scripts/manage-secrets.sh get STRIPE_SECRET_KEY | vercel env add STRIPE_SECRET_KEY production --force
```

---

## Automated Scanning

### Pre-commit Hook

`scripts/security-preflight.sh` runs on every commit and checks for:
- Tracked `.env` / `.db` / `.sqlite` files
- Secret patterns (`ghp_*`, `sk-*`, `AKIA*`, private keys)

### Credential Scanner

`scripts/scan-credentials.sh` performs comprehensive checks:

1. **Vault structure** — All expected files exist
2. **Tracked file scan** — No secrets leaked into git
3. **Placeholder detection** — Find unfilled credentials
4. **Format validation** — Key prefixes match expected patterns
5. **Cross-reference** — Vault matches project `.env.local` files
6. **`.gitignore` coverage** — All credential patterns excluded
7. **CODEOWNERS** — Credential paths have assigned owners

Run with JSON output for CI:
```bash
./scripts/scan-credentials.sh --json --ci
```

---

## Recovery Procedures

### Vault Deleted

1. Check `_history/` for recent backups
2. Retrieve from Vercel: `vercel env ls` (shows names, pull values)
3. Log into each service dashboard (Clerk, Stripe, Supabase)
4. Rebuild credential files manually
5. Run `./scripts/manage-secrets.sh rebuild`

### Key Compromised

1. Revoke the key immediately in the service dashboard
2. Generate a new key
3. Update vault: `./scripts/manage-secrets.sh set KEY_NAME "new_value"`
4. Update Vercel: `echo "new_value" | vercel env add KEY_NAME production --force`
5. Redeploy: `vercel --prod`
6. Run scan: `./scripts/manage-secrets.sh scan`

### Accidental Git Commit of Secrets

1. **Do NOT push** — if you haven't pushed yet, amend the commit
2. If already pushed:
   - Revoke ALL exposed credentials immediately
   - Use `git filter-repo` to remove from history
   - Force push
   - Generate new credentials for all exposed keys
   - Update vault and Vercel

---

## Security Rules

1. **Never commit** `.env` files — `.gitignore` enforces this
2. **Never paste** credential values into chat, LLM context, or prompts
3. **Always use** `manage-secrets.sh` for modifications — it creates backups
4. **Run scans** before every deployment
5. **CODEOWNERS** ensures @alawein reviews all credential-adjacent changes
6. **Principle of least privilege** — use anon keys on client, service role on server only
7. **No hardcoded keys** — always reference environment variables in code
