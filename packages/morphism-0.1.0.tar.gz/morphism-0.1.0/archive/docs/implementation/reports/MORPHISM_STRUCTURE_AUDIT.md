# Morphism Structure Audit & Refactoring Plan

**Generated:** 2026-02-11
**Purpose:** Comprehensive audit of current morphism workspace structure and identification of refactoring needs

---

## 📊 Executive Summary

| Aspect | Current State | Target State | Priority |
|--------|---------------|--------------|----------|
| **Structure** | Mixed patterns | Unified 3-layer hierarchy | ★★★★★ |
| **AI IDE Configs** | Partial (Claude, Cursor) | Complete multi-IDE | ★★★★★ |
| **Verification** | Basic validation | Comprehensive framework | ★★★★ |
| **Templates** | Ad-hoc | Centralized inventory | ★★★★★ |
| **Governance** | Strong (AGENTS.md) | Enhanced with reviewers | ★★★★ |
| **Documentation** | Good foundation | Stack-specific docs | ★★★ |

---

## 🏗️ Current Structure Analysis

### Root Level Directories

```
Current Workspace/
├── morphism/              # Main morphism framework (git submodule?)
├── hub/                   # Hub project (separate git repo)
├── bible/                 # Empty directory
├── cloud/                 # Empty directory
├── _projects/             # Independent projects
│   ├── agent-context-optimizer/
│   ├── aiclairty/
│   ├── bolts/
│   ├── brand-kit/
│   ├── codemap/
│   ├── llmworks/
│   ├── monorepo-health-analyzer/
│   ├── profile/           # Personal (never ships)
│   └── skills-agents-inventory/
├── _archive/              # Archived projects
├── .morphism/             # Workspace-level morphism config
├── .claude/               # Claude Code config (workspace-level)
├── .cursor/               # Cursor config
├── .kiro/                 # Legacy Kiro config
├── .trae/                 # Trae config
├── .windsurf/             # Windsurf config
├── .secrets/              # Secrets management
├── docs/                  # Workspace documentation
├── scripts/               # Workspace scripts
├── PROMPTS/               # Prompt collection
├── archive/               # Another archive?
├── backups/               # Backups
└── migration/             # Migration files
```

### Morphism Internal Structure

```
morphism/ (Git submodule)
├── kernel/                # Governance (no code, slow changes)
├── hub/                   # Ships to npm (apps, packages)
├── lab/                   # Experiments (may break)
├── profile/               # Personal (never ships)
├── .validation/           # Validation scripts
├── .morphism/             # Internal morphism config
├── .claude/               # Claude config
├── .codex/                # Codex config
├── .github/               # GitHub Actions
├── .scripts/              # Internal scripts
└── docs/                  # Morphism documentation
```

---

## 🔍 Issues Identified

### 1. Structural Confusion (Priority: ★★★★★)

**Issue:** Mixed organizational patterns
- Workspace has both `morphism/` (submodule) and separate `hub/`, `bible/`, `cloud/`
- Unclear relationship between workspace-level and morphism-internal structures
- Empty directories (`bible/`, `cloud/`) suggest incomplete migration

**Impact:**
- Confusion about where new projects belong
- Duplicate configuration files
- Unclear governance boundaries

**Resolution Needed:**
- Clarify workspace vs. framework relationship
- Complete or remove incomplete directory structure
- Define clear project placement rules

### 2. Multiple Archives (Priority: ★★★)

**Issue:** Multiple archive locations
- `_archive/` (main)
- `archive/` (duplicate?)
- `_archive/_trash/`
- Various dated consolidation archives

**Impact:**
- Difficult to find archived projects
- Storage waste
- Confusion about what's archived vs. deleted

**Resolution Needed:**
- Consolidate to single `_archive/` structure
- Create archive index
- Remove duplicate archive directories

### 3. AI IDE Configuration Fragmentation (Priority: ★★★★★)

**Issue:** Inconsistent AI IDE support
- Claude: Partial config (workspace + morphism)
- Cursor: Present but minimal
- Kiro: Legacy, incomplete
- Missing: Codex, AmazonQ, Trae, Windsurf

**Files Directory Has:**
- Complete configs for Claude, Codex, Cursor, Kiro, AmazonQ
- Reviewer system (5 agents)
- Verification framework

**Current Workspace Has:**
- `.claude/` - Basic config
- `.cursor/` - Minimal
- `.kiro/` - Legacy
- `.trae/`, `.windsurf/` - Unknown state

**Impact:**
- Inconsistent experience across AI IDEs
- Missing reviewer system
- No verification-first philosophy

**Resolution Needed:**
- Extract and adapt FILES directory configs
- Implement reviewer system
- Standardize across all IDEs
- Add missing IDE configs

### 4. Template Inventory Missing (Priority: ★★★★★)

**Issue:** No centralized template system
- No project templates
- No documentation templates
- No configuration templates
- Ad-hoc structure for new projects

**FILES Directory Has:**
- Products/ template pattern
- Research/ template pattern
- Tools/ template pattern
- Complete documentation templates

**Impact:**
- Inconsistent project structure
- Repeated setup work
- Missing best practices

**Resolution Needed:**
- Create `.morphism/templates/` structure
- Port templates from FILES directory
- Create template application system
- Document template usage

### 5. Verification Infrastructure Incomplete (Priority: ★★★★)

**Issue:** Basic validation only
- `.validation/validate-all.sh` exists
- Limited scope validation
- No drift detection
- No architecture boundary checking

**FILES Directory Has:**
- Comprehensive verification commands
- Drift detection
- Structure validation
- Tenet validation
- MCP validation

**Impact:**
- Undetected issues
- Manual verification
- Inconsistent quality

**Resolution Needed:**
- Enhanced validation scripts
- Drift detection implementation
- Architecture boundary enforcement
- Integration with CI/CD

### 6. Project Categorization Unclear (Priority: ★★★★)

**Issue:** `_projects/` is a catch-all
- No clear categorization
- Mix of types (tools, research, products)
- No stack-specific structure

**FILES Directory Pattern:**
- Products/ (production software)
- Research/ (exploratory work)
- Tools/ (utilities)

**Current `_projects/`:**
- agent-context-optimizer → Tools?
- aiclairty → Products?
- bolts → Research?
- brand-kit → Tools
- codemap → Tools
- llmworks → Research?
- monorepo-health-analyzer → Tools
- skills-agents-inventory → Tools?

**Impact:**
- Difficult to find projects
- No stack-specific conventions
- Unclear maturity/purpose

**Resolution Needed:**
- Categorize projects (Products/Research/Tools)
- Apply stack-specific layouts
- Create category-specific READMEs

### 7. Documentation Organization (Priority: ★★★)

**Issue:** Documentation scattered
- Workspace-level `docs/`
- Morphism-internal `docs/`
- Project-specific docs
- No clear hierarchy

**FILES Directory Pattern:**
- docs/technical/
- docs/market/
- docs/planning/
- docs/strategy/
- docs/reference/

**Impact:**
- Hard to find docs
- Duplicate information
- No doc templates

**Resolution Needed:**
- Organize docs by type
- Create doc templates
- Clear doc hierarchy
- Cross-reference system

### 8. Scripts & Automation (Priority: ★★★)

**Issue:** Scripts scattered across locations
- Workspace `scripts/`
- Morphism `.scripts/`
- Project-specific scripts
- No inventory or documentation

**Impact:**
- Script duplication
- Unknown capabilities
- Hard to discover tools

**Resolution Needed:**
- Centralize scripts
- Create script inventory
- Document script usage
- Categorize by purpose

---

## 🎯 Strengths to Preserve

### ✅ Strong Governance Foundation
- Excellent AGENTS.md
- MORPHISM.md (in live repo: 7 invariants → 10 tenets; see [INVENTORY.md](../../governance/INVENTORY.md))
- SSOT.md hierarchy
- Clear category-theoretic foundation

### ✅ Validation Infrastructure
- `.validation/validate-all.sh` framework
- Type checking (pnpm validate)
- Tenet tracking system

### ✅ Secrets Management
- `.secrets/` structure
- Credential management system
- Environment management policies

### ✅ Git Structure
- Clean git history
- Proper gitignore
- Branch management

### ✅ Morphism Internal Structure
- Clear kernel/hub/lab/profile separation
- Good documentation in morphism/
- Strong category theory foundation

---

## 📋 Refactoring Priorities

### Phase 1: Foundation (Immediate - Week 1)

1. **Clarify Workspace Structure** ★★★★★
   - Define workspace vs. morphism relationship
   - Complete or remove bible/, cloud/
   - Document structure in README

2. **AI IDE Configuration** ★★★★★
   - Port FILES directory configs
   - Implement reviewer system
   - Standardize across IDEs

3. **Template Inventory** ★★★★★
   - Create `.morphism/templates/`
   - Port project templates
   - Port doc templates
   - Create usage guide

### Phase 2: Organization (Week 2)

4. **Project Categorization** ★★★★
   - Categorize _projects/ contents
   - Apply stack-specific layouts
   - Create category READMEs

5. **Archive Consolidation** ★★★
   - Merge archive directories
   - Create archive index
   - Document archive policy

6. **Documentation Organization** ★★★
   - Organize by type
   - Create doc templates
   - Build cross-reference system

### Phase 3: Enhancement (Week 3)

7. **Verification Enhancement** ★★★★
   - Enhanced validation scripts
   - Drift detection
   - Architecture boundaries
   - CI/CD integration

8. **Script Organization** ★★★
   - Centralize scripts
   - Create inventory
   - Document usage

---

## 🔧 Specific Refactoring Tasks

### Task 1: Workspace Structure Clarification

**Goal:** Clear, unambiguous structure

**Actions:**
1. Document workspace vs. morphism boundary
2. Decide on bible/, cloud/ fate
3. Create WORKSPACE_STRUCTURE.md
4. Update README with navigation

**Deliverable:** Clear structure diagram + documentation

### Task 2: AI IDE Configuration Deployment

**Goal:** Complete multi-IDE support with reviewers

**Actions:**
1. Create `.morphism/ide-configs/` directory
2. Port .claude/ from FILES (enhanced)
3. Port .codex/ from FILES
4. Port .cursor/ from FILES (enhanced)
5. Port .amazonq/ from FILES
6. Create reviewer registry
7. Deploy 5 reviewer agents
8. Test each IDE config

**Deliverable:** Complete, tested IDE configs

### Task 3: Template Inventory Creation

**Goal:** Centralized, reusable templates

**Structure:**
```
.morphism/templates/
├── projects/
│   ├── product/           # Production software template
│   ├── research/          # Research project template
│   └── tool/              # Utility tool template
├── docs/
│   ├── architecture.md
│   ├── api.md
│   ├── deployment.md
│   └── development.md
├── configs/
│   ├── typescript/
│   ├── python/
│   └── lean/
└── workflows/
    ├── ci.yml
    ├── deploy.yml
    └── test.yml
```

**Actions:**
1. Create directory structure
2. Port templates from FILES
3. Adapt to morphism patterns
4. Create template application tool
5. Document template usage

**Deliverable:** Complete template inventory + tooling

### Task 4: Project Categorization & Layout

**Goal:** Clear categories with stack-specific layouts

**New Structure:**
```
_projects/
├── Products/              # Production software
│   ├── aiclairty/        # → Web app layout
│   └── ...
├── Research/              # Exploratory work
│   ├── llmworks/         # → Research layout
│   └── ...
├── Tools/                 # Utilities
│   ├── brand-kit/        # → CLI tool layout
│   ├── codemap/          # → CLI tool layout
│   ├── agent-context-optimizer/
│   ├── monorepo-health-analyzer/
│   └── skills-agents-inventory/
└── profile/              # Personal (unchanged)
```

**Actions:**
1. Categorize each project
2. Apply appropriate layout template
3. Add stack-specific tooling
4. Create category READMEs
5. Update workspace README

**Deliverable:** Organized, categorized projects with consistent layouts

---

## 📐 Target Architecture

### Unified Workspace Structure

```
Workspace Root/
├── morphism/                   # Morphism framework (kernel+hub+lab)
│   ├── kernel/                 # Pure governance
│   ├── hub/                    # Shipped packages
│   ├── lab/                    # Experiments
│   └── profile/                # Personal
│
├── _projects/                  # Workspace projects
│   ├── Products/              # Production software
│   ├── Research/              # Exploratory work
│   ├── Tools/                 # Utilities
│   └── profile/               # Personal workspace
│
├── .morphism/                  # Workspace governance
│   ├── templates/             # Project+doc+config templates
│   ├── ide-configs/           # Multi-IDE configurations
│   ├── reviewers/             # Reviewer agents
│   ├── validation/            # Validation tools
│   ├── inventory/             # Component inventory
│   └── schemas/               # Validation schemas
│
├── docs/                       # Workspace documentation
│   ├── technical/
│   ├── reference/
│   ├── guides/
│   └── architecture/
│
├── scripts/                    # Workspace automation
│   ├── validation/
│   ├── templates/
│   └── utilities/
│
├── _archive/                   # Archived projects
└── .secrets/                   # Secrets (unchanged)
```

---

## ✅ Success Criteria

### Phase 1 Complete When:
- [ ] Clear workspace structure documented
- [ ] Multi-IDE configs deployed and tested
- [ ] Template inventory created and documented
- [ ] At least 3 projects using templates

### Phase 2 Complete When:
- [ ] All projects categorized correctly
- [ ] Stack-specific layouts applied
- [ ] Archives consolidated
- [ ] Documentation organized

### Phase 3 Complete When:
- [ ] Enhanced validation running
- [ ] Drift detection operational
- [ ] Scripts inventoried and documented
- [ ] CI/CD integrated

---

## 🚀 Next Steps

1. ✅ Complete audit (DONE)
2. ⏭️ Design template inventory system (Task #3)
3. ⏭️ Design final morphism layout (Task #4)
4. ⏭️ Implement Phase 1 refactorings
5. ⏭️ Validate against morphism principles
6. ⏭️ Deploy and test

---

**Audit Complete** • Ready for template design phase
