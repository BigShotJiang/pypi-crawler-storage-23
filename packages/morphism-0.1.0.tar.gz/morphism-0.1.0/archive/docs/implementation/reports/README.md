# Reports and catalogs

Root-level report and catalog documents were moved here as part of the housekeeper cleanup (see [CLEANUP_REPORT.md](../CLEANUP_REPORT.md)).

| Document | Description |
|----------|-------------|
| COMPLETE_INVENTORY_SCAN.md | Comprehensive inventory scan |
| FILES_DIRECTORY_CATALOG.md | File and directory catalog |
| FINAL_INVENTORY_REPORT.md | Final inventory report |
| GITHUB_PROJECT_CATALOG.md | GitHub project catalog |
| INVENTORY_SYSTEM_COMPLETE.md | Inventory system completion |
| INVENTORY_SYSTEM_SUMMARY.md | Inventory system summary |
| MCP_SERVERS_COMPLETE_CATALOG.md | MCP servers catalog |
| MISSION_COMPLETE.md | Mission completion report |
| MORPHISM_STRUCTURE_AUDIT.md | Morphism structure audit |
| PLAN_CATALOG.md | Plan catalog |
| PROMPT_REGISTRY.md | Prompt registry |
| SKILL_CLASSIFICATION.md | Skill classification |
| TO-KIRO.md | Consolidated context (TO-KIRO) |
| new-agents-and-plugins-etc.md | New agents and plugins |

Additional reports (migration, architecture, component snapshots) are also in this directory.
