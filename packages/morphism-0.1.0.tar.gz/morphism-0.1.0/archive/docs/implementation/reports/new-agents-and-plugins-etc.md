# Agent & rPlugin Ecosystem Reference

Consolidated patterns, configurations, and references for AI agent systems, prompt engineering, and plugin architectures.

---

## AI Agent Prompt Systems

### Core Agent Categories

| Category | Purpose | Example Agents |
|----------|---------|----------------|
| Methods & Algorithms | Code analysis, optimization | Algorithm Extractor, Optimization Cataloger |
| Notation & Symbols | Mathematical notation parsing | Symbol Dictionary, Matrix Notation Specialist |
| References & Citations | Literature management | Citation Extractor, Paper Inventory |
| Theoretical Foundations | Proof analysis | Theorem Extractor, Convergence Analyzer |
| Taxonomy & Classification | Method categorization | Method Taxonomy Builder, Complexity Classifier |
| Intellectual Property | Patent tracking | Patent Disclosure Extractor, Novelty Tracker |
| Research Planning | Proposal development | Research Proposal Finder, Roadmap Builder |
| Tools & Infrastructure | Development tooling | Software Tool Inventory, CI/CD Cataloger |
| Benchmarks & Evaluation | Performance testing | Benchmark Instance Cataloger, Metric Tracker |
| Documentation | Content management | Documentation Structure Analyzer, Glossary Builder |
| Attribution & Credits | Contribution tracking | Contributor Tracker, License Inventory |
| Infrastructure Patterns | System architecture | Autonomous Agents Discovery, Guardrails Inventory |

### Prompt Engineering Patterns

**Effective Prompt Structure:**
1. Role definition and context
2. Task specification with constraints
3. Output format requirements
4. Edge case handling
5. Verification criteria

**Anti-Patterns to Avoid:**
- Vague terms: "might," "could," "possibly," "potentially"
- Filler phrases: "it's worth noting," "in some cases"
- Unmeasurable claims: "robust" or "scalable" without specifics

**Replacements:**
| Instead of | Use |
|------------|-----|
| "robust" | "handles [specific edge cases]" |
| "scalable" | "tested to [N] units with [performance]" |
| "AI-powered" | "uses [specific algorithm]" |

---

## Platform Configurations

### REPZ Platform

| Layer | Technology |
|-------|------------|
| Frontend | React 18, TypeScript, Vite, Tailwind CSS |
| Backend | Supabase (PostgreSQL + Edge Functions) |
| Auth | Supabase Auth with PKCE flow |
| Payments | Stripe |
| Testing | Vitest, Playwright |

**Patterns:** Multi-tenant RLS, real-time subscriptions, tier subscriptions, edge functions.

### Supabase

- **Database:** PostgreSQL with auto-generated types
- **Security:** Row Level Security for tenant isolation
- **Real-time:** Live subscriptions
- **Compute:** Edge Functions (serverless)
- **Storage:** File uploads

```bash
supabase gen types typescript --project-id YOUR_PROJECT_ID > src/integrations/supabase/types.ts
```

---

## Development Standards

### Naming Conventions

| Language | Functions/Variables | Classes | Constants |
|----------|---------------------|---------|-----------|
| Python | `snake_case` | `PascalCase` | `UPPER_SNAKE_CASE` |
| TypeScript | `camelCase` | `PascalCase` | `UPPER_SNAKE_CASE` |
| SQL | `snake_case` (plural tables) | — | `UPPER_SNAKE_CASE` |

### Test Coverage

| Type | Requirements |
|------|-------------|
| Happy path | 3+ input/output cases |
| Edge cases | Empty, None, boundary values |
| Error cases | Invalid inputs → exceptions |
| Property tests | Invariants that must hold |
| Target | ≥80% overall coverage |

### Code Review Checklist

- Logic errors and edge cases
- Security: injection, XSS, secrets in code
- Performance: O(?) issues, unnecessary loops
- Style: PEP 8, naming, comments
- Documentation: docstrings, type hints
- Testability: missing test cases

---

## MEZAN Framework

**Meta-Equilibrium Zero-regret Assignment Network**

- Algorithm Selection Theory
- Tournament-based Meta-learning
- Multi-agent orchestration
- GPU acceleration support

**Status:** Score 7.0/10 — 60 TODOs in QAPFlow, 61 bare `except:` clauses, type safety concerns.

---

## Legal Case Management

| Case | Type | Strength | Priority |
|------|------|----------|----------|
| Airbnb | Consumer/Housing Fraud | ⭐⭐⭐⭐⭐ | Concurrent |
| Turing | Employment/Wage Theft | ⭐⭐⭐⭐ | This week (OPT clock active) |
| Heirich | Federal Criminal | ⭐⭐⭐⭐⭐ | Immediate (immigration protection) |

---

## Infrastructure Patterns

### Quality Gates

- Pre-commit hooks (linting/formatting)
- CI/CD merge approval
- Production deployment gates
- Quality thresholds with bypass procedures

### Reproducibility

- Seed management for deterministic execution
- Environment lock files
- Version pinning
- Docker isolation

### Workflow Orchestration

- Task dependency graphs
- Execution engines: Dagster, GitHub Actions
- Error handling: retries/timeouts
- Conditional logic and state passing

---

## Quick Reference

### Supabase
```bash
supabase start           # Local instance
supabase functions deploy
supabase db push
```

### Development
```bash
npm run typegen   # Generate types
npm run test      # Test suite
npm run build     # Production build
```

### Key Integrations

| Integration | Purpose | Use Case |
|-------------|---------|----------|
| Supabase | Database, Auth, Real-time | Data persistence, user management |
| Stripe | Payments | Subscriptions, one-time charges |
| Resend | Email | Transactional emails |
| OpenAI | AI Features | Embeddings, analysis |

---

## Document Organization

### Structure
```
docs/
├── governance/     # Rules, compliance, onboarding
├── prompts/        # Standardized AI prompts
├── compliance/     # Validation scripts and reports
└── turing-system/  # Architecture and execution
```

### SSOT Principles
1. Single source of truth for all configuration
2. Modular structure by purpose
3. Index file for navigation
4. Semantic versioning

---

*Updated: 2026-02-11*
