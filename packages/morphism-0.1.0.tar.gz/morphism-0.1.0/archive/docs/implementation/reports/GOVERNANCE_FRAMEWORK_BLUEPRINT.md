# Building Morphism: A Production Governance Framework for Monorepos

**Date:** 2026-02-18
**Status:** Draft (non-normative)
**Scope:** CLI architecture, benchmarking methodology, invariant testing

**Notes:**
- External statistics and citations in this blueprint are placeholders until independently validated.
- This document is architectural guidance; normative requirements remain in `docs/governance/morphism-kernel.md`.

Morphism's three core components - a CLI, a benchmarking suite, and a testing infrastructure - can be built to production quality by combining patterns from Checkov's self-registering check architecture, Hypothesis's stateful property testing, and contraction-mapping convergence estimation. The most critical architectural decision is adopting Click with a runner-registry pattern for the CLI, ASV with custom `track_*` methods for non-timing governance metrics, and `RuleBasedStateMachine` for invariant verification. What follows is a concrete blueprint aligned with the Kernel invariants and existing CLI architecture.

---

## Part 1: The governance CLI

### Checkov's runner-registry pattern is the gold standard

The most proven architecture for governance CLIs comes from Checkov (Prisma Cloud), which uses a self-registration pattern where each check registers itself into a singleton registry on import. This eliminates manual wiring and scales to large numbers of checks. Checkov uses `configargparse` (not Click), but the pattern maps cleanly onto Click groups. OPA uses Go's Cobra with discrete subcommands; that maps directly to Click groups as well.

**Recommended stack:** Click (not Typer) with `click-plugins` for extensibility. Click's mature `@click.group()` decorator directly supports a `morphism check / entropy / drift / validate` structure, and `click-plugins` integrates with `entry_points` for third-party extensions.

```python
# src/morphism/cli/main.py - CLI entry point
from importlib.metadata import entry_points
import click
import sys
from click_plugins import with_plugins
from morphism.checks.registry import CheckRegistry
from morphism.output.formatters import format_results
from morphism.scoring.maturity import GovernanceScore


class ExitCode:
    SUCCESS = 0           # All checks passed
    VIOLATIONS_FOUND = 1  # Governance violations detected
    ERROR = 2             # Usage or internal error


@with_plugins(entry_points(group="morphism.plugins"))
@click.group()
@click.version_option(version="0.1.0")
@click.option("--format", "-f", "output_format",
              type=click.Choice(["text", "json", "sarif", "junit"]), default="text")
@click.option("--config", "-c", type=click.Path(), default=".morphism/config.json")
@click.option("--soft-fail", is_flag=True, help="Always exit 0")
@click.pass_context
def cli(ctx, output_format, config, soft_fail):
    """Morphism: Governance enforcement for your monorepo."""
    ctx.ensure_object(dict)
    ctx.obj.update(output_format=output_format, config=config, soft_fail=soft_fail)


@cli.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--check", multiple=True, help="Run only these checks (e.g., MORPH_OWN_001)")
@click.option("--severity", type=click.Choice(["LOW", "MEDIUM", "HIGH", "CRITICAL"]))
@click.pass_context
def check(ctx, path, check, severity):
    """Run all governance checks against the monorepo."""
    registry = CheckRegistry()
    registry.load_checks()
    results = []
    for gov_check in registry.get_checks(include=check or None, min_severity=severity):
        results.extend(gov_check.run(path))

    score = GovernanceScore.calculate(results)
    click.echo(format_results(results, score, ctx.obj["output_format"]))
    sys.exit(ExitCode.SUCCESS if ctx.obj["soft_fail"] or score.failed == 0
             else ExitCode.VIOLATIONS_FOUND)
```

The self-registering check pattern makes adding new checks trivial - create a class, and it appears in the CLI automatically:

```python
# src/morphism/checks/base_check.py
from abc import ABC, abstractmethod
from morphism.checks.registry import CheckRegistry


class BaseCheck(ABC):
    def __init__(self):
        CheckRegistry.register(self)  # Self-registration on import

    @property
    @abstractmethod
    def id(self) -> str:  # e.g., "MORPH_OWN_001"
        raise NotImplementedError

    @property
    @abstractmethod
    def severity(self) -> str:  # LOW | MEDIUM | HIGH | CRITICAL
        raise NotImplementedError

    @abstractmethod
    def scan(self, path: str) -> list[dict]:
        raise NotImplementedError

    def run(self, path: str) -> list[dict]:
        try:
            return self.scan(path)
        except Exception as exc:
            return [{
                "check_id": self.id,
                "result": "ERROR",
                "message": str(exc),
            }]
```

```python
# src/morphism/checks/ownership/codeowners.py
from pathlib import Path
from morphism.checks.base_check import BaseCheck


class CodeownersCheck(BaseCheck):
    id = "MORPH_OWN_001"
    name = "Service has CODEOWNERS entry"
    severity = "HIGH"

    def scan(self, path):
        exists = (Path(path) / ".github" / "CODEOWNERS").exists()
        return [{
            "check_id": self.id,
            "result": "PASSED" if exists else "FAILED",
            "severity": self.severity,
            "resource": path,
        }]


_check = CodeownersCheck()  # Self-register on import
```

### Wrapping existing scripts requires a subprocess bridge

Morphism's existing scripts (`ssot_verify.py`, `maturity_score.py`, `policy_check.py`, `docs_sync.py`, `verify_pipeline.py`) can be integrated through a uniform subprocess wrapper that expects JSON stdout or falls back to exit-code-based pass/fail:

```python
import json
import subprocess
import sys
from pathlib import Path


def run_external_script(script_path: str, target: str) -> list[dict]:
    """Bridge existing governance scripts into Morphism's result format."""
    proc = subprocess.run(
        [sys.executable, script_path, target],
        capture_output=True,
        text=True,
        timeout=300,
    )
    try:
        return json.loads(proc.stdout)
    except json.JSONDecodeError:
        return [{
            "check_id": f"EXT_{Path(script_path).stem.upper()}",
            "result": "PASSED" if proc.returncode == 0 else "FAILED",
            "severity": "MEDIUM",
            "message": proc.stdout.strip() or proc.stderr.strip(),
        }]
```

The migration path is clear: start by wrapping scripts as external checks, then incrementally rewrite each as a native `BaseCheck` subclass. Prefer direct imports for Python when refactoring (per `docs/implementation/CLI_ARCHITECTURE.md`), and use subprocess only for legacy or non-Python tools.

### Output formats and exit codes for CI integration

- **SARIF v2.1.0** is the industry standard for static analysis results and integrates with GitHub Code Scanning. Each governance finding maps to a SARIF `result` with `ruleId`, `level` (error/warning/note), and `physicalLocation`.
- **Three-state exit codes** align with repo conventions: 0 success, 1 violations found, 2 usage or internal error. Include `--soft-fail` and severity-based exit options for CI flexibility.

### Recommended project layout

```
src/morphism/
  cli/
    main.py                 # Click root + command groups
  checks/
    registry.py             # CheckRegistry singleton
    base_check.py           # Abstract BaseCheck
    ownership/              # MORPH_OWN_* checks
    drift/                  # MORPH_DFT_* checks
    structure/              # MORPH_STR_* checks
  output/
    formatters.py           # Text, JSON, SARIF, JUnit formatters
    sarif.py                # SARIF v2.1.0 schema
  scoring/
    maturity.py             # Governance score calculation
    entropy.py              # Entropy metric computation
  plugins/
    loader.py               # entry_points plugin discovery
```

Plugin developers register via `pyproject.toml`:

```toml
[project.entry-points."morphism.plugins"]
my_custom_check = "my_package.cli:custom_check_command"
```

---

## Part 2: The benchmarking suite

### Measuring entropy requires concrete metrics

Software entropy decomposes into measurable quantities:

- Ambiguity score: `(undocumented_exceptions + unclear_ownership_files) / total_entities`
- Staleness index: `files_not_modified_in_N_months / total_files` and `doc_age - code_age` delta
- Dead code ratio: unreachable paths / total paths (use `vulture` for Python)
- Configuration drift score: `drifted_attributes / total_managed_attributes`
- Documentation freshness: `1 - (avg_doc_age_days / max_acceptable_age)`

Shannon entropy can quantify the distribution of code across risk categories:

```
H = -sum((F_k / N) * log2(F_k / N))
```

### ASV is the right choice for tracking metrics across commits

ASV (Airspeed Velocity) supports `track_*` methods that store arbitrary values (not just timing) across git history, with an interactive web frontend for visualization.

```python
# benchmarks/benchmarks_governance.py
import random


class GovernanceEntropy:
    timeout = 120

    def setup(self):
        self.files = [{
            "has_docstring": random.random() > 0.3,
            "has_owner": random.random() > 0.2,
            "days_since_modified": random.randint(0, 365),
        } for _ in range(1000)]

    def track_entropy_score(self):
        """Custom tracked metric: composite governance entropy."""
        total = len(self.files)
        undoc = sum(1 for f in self.files if not f["has_docstring"])
        unown = sum(1 for f in self.files if not f["has_owner"])
        stale = sum(1 for f in self.files if f["days_since_modified"] > 180)
        return (undoc + unown + stale) / (3 * total)
    track_entropy_score.unit = "entropy"

    def track_drift_count(self):
        return sum(
            1 for f in self.files
            if f["days_since_modified"] > 90 and not f["has_owner"]
        )
    track_drift_count.unit = "drifted_files"


class ConvergenceBenchmark:
    params = [1, 5, 10, 20, 50]
    param_names = ["iterations"]

    def track_residual_entropy(self, iterations):
        """Track how fast governance application reduces entropy."""
        state = {"entropy": 0.8, "violations": 100, "coverage": 0.3}
        for _ in range(iterations):
            state["violations"] = int(state["violations"] * 0.7)
            state["coverage"] = min(1.0, state["coverage"] + 0.05)
            state["entropy"] = state["violations"] / 100 * (1 - state["coverage"])
        return state["entropy"]
    track_residual_entropy.unit = "entropy"
```

Run `asv run ALL` to benchmark across commits, `asv publish` to generate HTML, and `asv preview` to view the dashboard.

### Convergence rate estimation validates the category-theoretic foundation

Empirically estimate the contraction constant `kappa`:

```
kappa_n = |x_{n+1} - x_n| / |x_n - x_{n-1}|
```

Use the median of the tail for stability and compute confidence intervals.

```python
import numpy as np
from scipy import stats


def estimate_convergence_rate(governance_func, initial_state, max_iter=100, tol=1e-10):
    states = [initial_state]
    residuals = []
    kappas = []
    for _ in range(max_iter):
        new = governance_func(states[-1])
        states.append(new)
        residual = abs(new - states[-2])
        residuals.append(residual)
        if len(residuals) >= 2 and residuals[-2] > tol:
            kappas.append(residuals[-1] / residuals[-2])
        if residual < tol:
            break

    tail = kappas[len(kappas) // 2:]
    kappa_est = float(np.median(tail)) if tail else float("nan")
    ci = (
        tuple(np.percentile(tail, [2.5, 97.5]).tolist())
        if len(tail) >= 3 else (kappa_est, kappa_est)
    )

    if len(residuals) >= 4:
        errors = np.array(residuals)
        slope = stats.linregress(
            np.log(errors[:-1] + 1e-300),
            np.log(errors[1:] + 1e-300),
        ).slope
    else:
        slope = 1.0

    return {
        "kappa": kappa_est,
        "kappa_ci": ci,
        "order": slope,
        "iterations": len(residuals),
        "converged": residuals[-1] < tol,
    }
```

### Drift detection accuracy needs ground-truth benchmarking

Synthetic ground truth datasets plus precision/recall/F1 (and MCC for imbalance) provide measurable drift detector quality.

```python
import numpy as np


def benchmark_drift_detector(detector_fn, n_trials=10, n_items=1000, drift_rate=0.1):
    """Aggregate precision/recall/F1 across trials with synthetic ground truth."""
    results = []
    for seed in range(n_trials):
        items, actual_drifted = create_ground_truth(n_items, drift_rate, seed)
        detected = detector_fn(items)
        tp = len(detected & actual_drifted)
        fp = len(detected - actual_drifted)
        fn = len(actual_drifted - detected)
        precision = tp / (tp + fp) if (tp + fp) else 0
        recall = tp / (tp + fn) if (tp + fn) else 0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0
        results.append({"precision": precision, "recall": recall, "f1": f1})
    return {
        key: {
            "mean": float(np.mean([row[key] for row in results])),
            "std": float(np.std([row[key] for row in results])),
        }
        for key in results[0]
    }
```

### ROI measurement uses the Cost of Quality framework

Use the PAF model (prevention, appraisal, internal failure, external failure) to track governance ROI. Translate time saved and incident reduction into cost estimates and track deltas across releases.

---

## Part 3: The testing infrastructure

### Hypothesis property tests encode each invariant directly

Property-based testing with Hypothesis maps each invariant to a property.

```python
from hypothesis import given, settings
from hypothesis import strategies as st


@given(
    state=governance_state,
    transition=st.sampled_from(["consolidate", "remove_dead", "merge_domains"]),
)
@settings(max_examples=500)
def test_entropy_never_increases_on_valid_transition(state, transition):
    """Invariant: Entropy Monotonicity."""
    before = compute_entropy(state)
    new_state = apply_valid_transition(state, transition)
    after = compute_entropy(new_state)
    assert after <= before, (
        f"Entropy increased {before} -> {after} on '{transition}': "
        f"violates Entropy Monotonicity"
    )
```

Refusal-as-structure can be tested with time bounds:

```python
@given(
    small_req=st.builds(Request, payload=st.dictionaries(st.text(), st.text(), max_size=1)),
    large_req=st.builds(Request, payload=st.dictionaries(st.text(), st.text(), min_size=50, max_size=100)),
)
def test_refusal_time_independent_of_input_size(small_req, large_req):
    """Refusal time must not scale with input size."""
    t1 = measure_refusal_time(small_req)
    t2 = measure_refusal_time(large_req)
    assert t2 < t1 * 3 + 100_000, "Refusal time scales with input - not O(1)"
```

One-truth-per-domain becomes a uniqueness property:

```python
@given(assertions=st.lists(governance_assertion, min_size=2, max_size=30))
def test_one_truth_per_domain(assertions):
    """Every governance assertion has exactly one canonical source per domain."""
    registry = GovernanceRegistry()
    for assertion in assertions:
        registry.register(assertion)
    for domain in Domain:
        claims = registry.get_claims(domain)
        assert len([c.claim for c in claims]) == len(set(c.claim for c in claims))
```

### Stateful testing catches invariant violations across operation sequences

```python
from hypothesis.stateful import RuleBasedStateMachine, Bundle, rule, invariant, initialize
from hypothesis import strategies as st


class GovernanceStateMachine(RuleBasedStateMachine):
    registered_assertions = Bundle("registered_assertions")

    @initialize()
    def init(self):
        self.registry = GovernanceRegistry()
        self.current_entropy = 0.0

    @rule(
        target=registered_assertions,
        domain=st.sampled_from(list(Domain)),
        claim=st.text(min_size=1, max_size=50),
        source=st.from_regex(r"src/[a-z]+/[a-z_]+\.py", fullmatch=True),
    )
    def register_assertion(self, domain, claim, source):
        assertion = GovernanceAssertion(domain=domain, claim=claim, source_file=source)
        self.registry.register(assertion)
        self.current_entropy = self.registry.compute_entropy()
        return assertion

    @rule(assertion=registered_assertions)
    def consolidate(self, assertion):
        """Consolidate duplicates - must not increase entropy."""
        old = self.current_entropy
        self.registry.consolidate(assertion.domain)
        self.current_entropy = self.registry.compute_entropy()
        assert self.current_entropy <= old  # Entropy Monotonicity

    @invariant()
    def one_truth_per_domain(self):
        for domain in self.registry.active_domains:
            claims = self.registry.get_claims(domain)
            assert len(claims) == len(set(c.claim for c in claims))

    @invariant()
    def entropy_bounded(self):
        assert self.current_entropy >= 0


TestGovernance = GovernanceStateMachine.TestCase
TestGovernance.settings = settings(max_examples=100, stateful_step_count=30)
```

### CI gates use a single aggregator job as required status check

```yaml
name: Governance Gates
on:
  pull_request:
    branches: [main]
  push:
    branches: [main]

jobs:
  governance-lint:
    name: "Quick Lint"
    runs-on: ubuntu-latest
    timeout-minutes: 5
    steps:
      - uses: actions/checkout@v4
        with: { fetch-depth: 0 }
      - uses: actions/setup-python@v5
        with: { python-version: "3.12", cache: "pip" }
      - run: pip install -e ".[governance]"
      - run: morphism check --format sarif --output governance.sarif
      - uses: github/codeql-action/upload-sarif@v3
        with: { sarif_file: governance.sarif }

  governance-invariants:
    name: "Property Tests"
    runs-on: ubuntu-latest
    timeout-minutes: 10
    needs: governance-lint
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12", cache: "pip" }
      - run: pip install -e ".[test,governance]"
      - run: pytest tests/governance/ -m invariant --hypothesis-seed=0 -x

  governance-meta:
    name: "Meta-Tests"
    runs-on: ubuntu-latest
    timeout-minutes: 10
    needs: governance-lint
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12", cache: "pip" }
      - run: pip install -e ".[test,governance]"
      - run: pytest tests/meta/ -x

  governance-gate:
    name: "Governance Gate"
    runs-on: ubuntu-latest
    needs: [governance-lint, governance-invariants, governance-meta]
    if: always()
    steps:
      - run: |
          if [[ "${{ needs.governance-lint.result }}" != "success" ]] ||
             [[ "${{ needs.governance-invariants.result }}" != "success" ]] ||
             [[ "${{ needs.governance-meta.result }}" != "success" ]]; then
            echo "Governance gate FAILED"
            exit 1
          fi
          echo "All governance gates passed"
```

### Meta-testing follows OPA and Semgrep patterns

Golden-file tests, self-consistency checks, and false positive/negative fixtures ensure the checkers themselves are correct.

```python
class TestGovernanceCheckerItself:
    def test_detects_known_violation(self):
        result = check_one_truth(root="tests/fixtures/duplicate_domain/")
        assert not result.passed

    def test_no_false_positive_on_clean_repo(self):
        result = check_one_truth(root="tests/fixtures/clean_codebase/")
        assert result.passed

    def test_governance_code_passes_own_checks(self):
        """Self-consistency: Morphism's source code obeys its own rules."""
        result = run_all_checks(root="src/morphism/")
        assert result.passed, f"Governance code violates own rules: {result.violations}"
```

### Mutation testing with mutmut validates test suite quality

```toml
[tool.mutmut]
paths_to_mutate = ["src/morphism/checks/", "src/morphism/invariants/", "src/morphism/engine/"]
do_not_mutate = ["src/morphism/__init__.py", "src/morphism/cli.py"]
mutate_only_covered_lines = true
```

Set a mutation score threshold (e.g., 80 percent) for governance modules and run weekly in CI due to cost.

### Formal verification bridge connects Hypothesis to Lean 4

Structure property tests to mirror Lean theorems, so the test suite becomes a living specification.

```python
# tests/bridge/test_entropy_matches_lean.py
"""Properties that mirror Lean 4 proofs in lean/Morphism/Invariants/."""

@given(
    state=governance_state,
    transition=st.sampled_from(["consolidate", "remove_dead", "merge_domains"]),
)
@settings(max_examples=500)
def test_entropy_monotone_mirrors_lean_proof(state, transition):
    """Mirrors: theorem entropy_monotone (lean/Morphism/Invariants/EntropyMonotonicity.lean)"""
    before = compute_entropy(state)
    after = compute_entropy(apply_valid_transition(state, transition))
    assert after <= before
```

Recommended structure:

```
src/morphism/          # Python implementation
tests/
  governance/          # Property-based invariant tests
  meta/                # Meta-tests (test the checkers)
  bridge/              # PBT <-> Lean correspondence tests
lean/
  Morphism/Invariants/EntropyMonotonicity.lean
  Morphism/Model/GovernanceState.lean
  lakefile.lean
benchmarks/            # ASV + pytest-benchmark suites
```

---

## Conclusion: where the architecture decisions compound

Three architectural choices create the most leverage for Morphism. First, Checkov's self-registering check pattern makes governance extensible without wiring. Second, ASV's `track_*` methods solve the unique problem of tracking non-timing governance metrics (entropy, drift count, kappa convergence rate) across commit history with automatic visualization. Third, Hypothesis `RuleBasedStateMachine` with `@invariant()` decorators provides the strongest possible testing for the Kernel invariants by generating randomized operation sequences and checking every invariant after every step.

The less obvious but equally critical decisions: use SARIF output from day one (feeds GitHub Code Scanning), adopt the three-state exit code convention (0/1/2) with `--soft-fail` granularity, and structure Hypothesis properties to mirror Lean 4 proof statements so the PBT suite serves as both a test suite and a living specification that can be incrementally formalized. The convergence rate estimator - computing `kappa` from the tail of `|x_{n+1} - x_n| / |x_n - x_{n-1}|` - provides empirical evidence that the category-theoretic foundation can be validated in practice.
