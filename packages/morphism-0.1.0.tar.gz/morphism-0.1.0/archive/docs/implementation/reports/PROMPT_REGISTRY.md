# Prompt Registry

**Generated:** 2026-02-11T23:29:35Z
**Source:** `/mnt/c/Users/mesha/.aws/amazonq/prompts`
**Total Prompts:** 149

---

## Category Summary

| Category | Count | Percentage |
|----------|-------|------------|
| **Orchestrators** | 1 | 0.7% |
| **Development** | 0 | 0.0% |
| **Architecture** | 0 | 0.0% |
| **Quality** | 140 | 94.0% |
| **Documentation** | 1 | 0.7% |
| **Specialized** | 7 | 4.7% |

---

## Orchestrators (1 prompts)

### 🤖 QMAT-Sim - Master Superprompt & AI Orchestration

**File:** `quantum-materials-simulation.md`
**Description:** **Project:** QMAT-Sim (Quantum Material Simulation)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,✅ Your Priorities,
**Size:** 199 words

---

## Development (0 prompts)

*No prompts in this category*

---

## Architecture (0 prompts)

*No prompts in this category*

---

## Quality (140 prompts)

### Technology Stack Validator

**File:** `validation.md`
**Description:** You are a technology stack consistency expert that validates and optimizes framework and library usage across projects. Focus on:
**Sections:** Stack Analysis Dimensions,Validation Framework,Technology Stack Assessment,Optimization Strategies,Compliance Monitoring,Integration Points,
**Size:** 247 words

### Crew Manager System Prompt

**File:** `multi-agent-coordination.md`
**Description:** You are a Crew Manager responsible for coordinating multi-agent teams to accomplish complex tasks.
**Sections:** Core Responsibilities,Available Crews,Delegation Protocol,Coordination Patterns,Communication Guidelines,Output Format,Crew Status Report,Quality Standards,
**Size:** 440 words

### Context Bridge

**File:** `context-bridge.md`
**Description:** You are a context preservation specialist that maintains state and knowledge across sequential prompt executions. Focus on:
**Sections:** Context Preservation,State Management,Handoff Protocol,Previous Context Summary,Chaining Recommendation,Integration Patterns,
**Size:** 179 words

### 🎯 Universal Prompt Optimizer

**File:** `prompt-engineering-optimizer.md`
**Description:** **Transform any prompt from mediocre to exceptional in 2 minutes.**
**Sections:** 🚀 Quick Start (30 seconds),📊 The 8-Dimension Scoring Framework,🎯 Analysis Template,📝 Optimization Checklist,🔥 Before/After Examples,🧠 Advanced Techniques,📏 Prompt Scoring Guide,🎯 Quick Optimization Formula,🔬 Self-Optimization Exercise,🚀 Pro Tips,📊 Real-World Prompt Analysis,💡 Common Mistakes & Fixes,🎓 Graduation Test,📚 Additional Resources,🏁 Summary,🎯 Your Next Action,
**Size:** 4057 words

### 🤖 TalAI - Master Superprompt & AI Orchestration

**File:** `ai-research-platform.md`
**Description:** **Project:** TalAI (AI Talent Acquisition)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,📋 When You Analyze TalAI,🎓 Key Commands for Claude Code,💡 MCP Servers Available,🚀 Cost Optimization,✅ Your Priorities for TalAI,📞 Quick Reference,
**Size:** 565 words

### Amazon Q Orchestration Deployment

**File:** `deployment-status.md`
**Description:** - **8 Amazon Q Orchestrators** - Master, Workflow, Multi-Agent, Context, Quality, Task Router, Enterprise, Configuration
**Sections:** ✅ System Status: READY FOR PRODUCTION,
**Size:** 252 words

### Data Engineering Pipeline Framework

**File:** `data-pipeline-engineering.md`
**Description:** Design and implement scalable, reliable data processing systems.
**Sections:** Purpose,1. INGESTION LAYER,2. TRANSFORMATION LAYER,3. STORAGE LAYER,4. ORCHESTRATION,Pipeline Template,Checklist,
**Size:** 844 words

### Notebook Polish

**File:** `notebook-polish.md`
**Description:** Transform Jupyter notebooks into production-ready, polished documents:
**Sections:** Code Quality Enhancement,Documentation & Narrative,Visualization Improvement,Reproducibility & Maintenance,Production Readiness,
**Size:** 166 words

### 🤖 SimCore - Master Superprompt & AI Orchestration

**File:** `SIMCORE_SUPERPROMPT.md`
**Description:** **Project:** SimCore (Simulation Engine)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,📋 When You Analyze SimCore,🎓 Key Commands for Claude Code,✅ Your Priorities,
**Size:** 327 words

### Master AI Development Orchestrator

**File:** `master-ai-development-orchestrator.md`
**Description:** Comprehensive AI-powered development environment with intelligent multi-agent coordination.
**Sections:** System Architecture,Intelligent Coordination,Enterprise Workflow Templates,Advanced Features,Configuration Schema,Implementation Roadmap,
**Size:** 914 words

### Mathematical Research Acceleration

**File:** `mathematical-research.md`
**Description:** You are an expert in using quantum computing to accelerate mathematical research within Morphism Projects. Focus on:
**Sections:** Research Domains,Quantum Advantage Areas,Implementation Strategy,Research Integration,Innovation Focus,
**Size:** 186 words

### Compositional Workflow Orchestrator

**File:** `workflow-orchestrator.md`
**Description:** You are a workflow orchestration expert that chains multiple development tasks together. Focus on:
**Sections:** Core Capabilities,Workflow Patterns,Context Management,Integration Points,Expected Outputs,
**Size:** 202 words

### Amazon Q Workflow Validation

**File:** `workflow-validation.md`
**Description:** Test and validate Amazon Q's orchestration system with real-world scenarios.
**Sections:** Test Scenarios,Validation Framework,
**Size:** 331 words

### API Development & Integration Standards

**File:** `api-design-development.md`
**Description:** RESTful/GraphQL API design and implementation with enterprise-grade quality.
**Sections:** Purpose,Design Principles,Authentication & Authorization,Implementation Standards,Testing Requirements,Documentation Requirements,
**Size:** 620 words

### Test Coverage Analysis Engine

**File:** `test-coverage-analysis.md`
**Description:** You are a test coverage specialist that analyzes and optimizes test coverage for maximum quality assurance. Focus on:
**Sections:** Coverage Metrics Analysis,Coverage Quality Assessment,Coverage Analysis Report,Improvement Recommendations,Coverage Automation,Integration Points,
**Size:** 242 words

### TypeScript Automation CLI - Implementation Status

**File:** `typescript-automation.md`
**Description:** Successfully completed comprehensive TypeScript automation CLI implementation with full functionality validation.
**Sections:** Overview,Build & Installation,Core Functionality,Technical Achievements,Production Readiness,Integration Capabilities,Summary,
**Size:** 528 words

### Testing & Quality Assurance Superprompt

**File:** `testing-qa-strategy.md`
**Description:** Comprehensive testing and quality assurance framework for ensuring code reliability, maintainability, and production readiness across all project types.
**Sections:** Purpose,System Prompt,Testing Pyramid Strategy,Test Implementation Templates,Test Configuration,Quality Metrics & Gates,CI/CD Integration,Execution Phases,
**Size:** 1308 words

### Social Media Platform Development - Complete Phased Approach

**File:** `social-media-development-phases.md`
**Description:** 1. "Create a modern social media platform with [Next.js/React/Vue], real-time capabilities, and scalable architecture"
**Sections:** Phase 1: Foundation & Authentication (Prompts 1-10),Phase 2: Content Creation & Sharing (Prompts 11-20),Phase 3: Social Interactions (Prompts 21-30),Phase 4: Messaging & Communication (Prompts 31-40),Phase 5: Discovery & Exploration (Prompts 41-50),Phase 6: Groups & Communities (Prompts 51-60),Phase 7: Monetization & Creator Tools (Prompts 61-70),Phase 8: Privacy & Safety (Prompts 71-80),Phase 9: Analytics & Insights (Prompts 81-90),Phase 10: Mobile & Cross-Platform (Prompts 91-95),Phase 11: Advanced Features (Prompts 96-100),
**Size:** 1367 words

### Amazon Q Enterprise Workflows

**File:** `amazonq-enterprise-workflows.md`
**Description:** You are Amazon Q's enterprise workflow engine. Execute complex development workflows with approval gates and quality controls.
**Sections:** Enterprise Workflow Templates,Approval Gates,Execution Rules,
**Size:** 235 words

### 🤖 Mag-Logic - Master Superprompt & AI Orchestration

**File:** `magnetic-simulation-system.md`
**Description:** **Project:** Mag-Logic (Magnetic Logic Systems)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,✅ Your Priorities,
**Size:** 196 words

### System Architecture & Integration

**File:** `system-architecture.md`
**Description:** You are a system architect for the Morphism Projects ecosystem. Focus on:
**Sections:** Architecture Principles,Integration Patterns,Performance & Scalability,DevOps & Deployment,Security & Reliability,Documentation Standards,
**Size:** 192 words

### Librex.QAP Implementation Superprompt

**File:** `quadratic-assignment-problem.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Testing Protocol,6. Benchmark Setup,7. Publication Strategy,8. Code Repository Structure,9. Success Criteria,10. Next Actions,
**Size:** 3248 words

### Router System Prompt

**File:** `request-routing.md`
**Description:** You are a Task Router responsible for classifying incoming requests and directing them to the appropriate handler.
**Sections:** Classification Categories,Routing Algorithm,Confidence Thresholds,Output Format,Special Cases,
**Size:** 433 words

### Phase 1: Infrastructure Consolidation

**File:** `infrastructure-setup-phase.md`
**Description:** Merge scattered infrastructure folders (deploy/, templates/) into .metaHub/ for unified DevOps management.
**Sections:** Objective,Pre-Flight Checks,Execution Steps,Path Updates Required,Validation Tests,Rollback Procedure,Success Criteria,Commit Message,
**Size:** 465 words

### 🎯 Universal Prompt Optimizer

**File:** `prompt-refinement.md`
**Description:** **Transform any prompt from mediocre to exceptional in 2 minutes.**
**Sections:** 🚀 Quick Start (30 seconds),📊 The 8-Dimension Scoring Framework,🎯 Analysis Template,📝 Optimization Checklist,🔥 Before/After Examples,🧠 Advanced Techniques,📏 Prompt Scoring Guide,🎯 Quick Optimization Formula,🔬 Self-Optimization Exercise,🚀 Pro Tips,📊 Real-World Prompt Analysis,💡 Common Mistakes & Fixes,🎓 Graduation Test,📚 Additional Resources,🏁 Summary,🎯 Your Next Action,
**Size:** 4057 words

### Amazon Q Multi-Agent Coordinator

**File:** `amazonq-multi-agent-coordinator.md`
**Description:** You are Amazon Q's internal multi-agent coordinator. Simulate specialized development roles within Q's unified interface.
**Sections:** Agent Personas,Coordination Protocol,
**Size:** 215 words

### Amazon Q Internal System Configuration

**File:** `amazonq-system-configuration.md`
**Description:** Configuration guide for Amazon Q's internal orchestration and workflow systems.
**Sections:** System Architecture,Internal Prompt System,Tool Integration Matrix,Workflow Templates for Q,Implementation Guidelines,
**Size:** 445 words

### Librex.Evo Implementation Superprompt

**File:** `evolutionary-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Success Criteria,
**Size:** 1858 words

### Testing Strategy Architect

**File:** `testing-strategy.md`
**Description:** You are a testing strategy expert that designs comprehensive testing approaches for software projects. Focus on:
**Sections:** Testing Pyramid Design,Strategy Framework,Testing Strategy Matrix,Quality Gates,Test Environment Strategy,Integration Points,
**Size:** 247 words

### Enterprise Agentic AI Architecture Superprompt

**File:** `enterprise-ai-agents.md`
**Description:** Comprehensive framework for building state-of-the-art enterprise agentic AI systems with advanced caching, intelligent orchestration, and production-grade reliability patterns.
**Sections:** Purpose,System Prompt,Multi-Layer Caching Architecture,Continuous Intelligence Monitoring,Policy-Driven Validation (A2K Bridge Pattern),Resource-Aware Agent Scheduling,KILO Consolidation Methodology,Execution Phases,Integration with Existing Systems,
**Size:** 3002 words

### Frontend Optimizer

**File:** `frontend-optimizer.md`
**Description:** Optimize frontend applications for performance and user experience:
**Sections:** Performance Optimization,User Experience,Code Quality,Build & Deployment,Framework Optimization,
**Size:** 175 words

### Task Decomposition Engine

**File:** `task-decomposition.md`
**Description:** You are a task decomposition specialist that breaks complex requirements into manageable, sequential steps. Focus on:
**Sections:** Decomposition Strategy,Task Categorization,Output Format,Integration Points,
**Size:** 192 words

### 50 Workspace Analysis Prompts

**File:** `workspace-analysis-50.md`
**Description:** Analyze the complete architecture across FILES to read and GitHub workspaces. Map all projects, their dependencies, and integration points. Identify architectural patterns, anti-patterns, and opportunities for consolidation.
**Sections:** Architecture & Design (1-10),Code Quality & Optimization (11-20),Integration & Automation (21-30),Business & Product (31-40),Research & Innovation (41-50),
**Size:** 1152 words

### Catalyst Multi-Agent Orchestration

**File:** `catalyst-orchestration.md`
**Description:** You are an expert in the Catalyst orchestration framework for Morphism Projects. Focus on:
**Sections:** Core Capabilities,Architecture Principles,Implementation Standards,Integration Patterns,Key Focus Areas,
**Size:** 179 words

### Test Generator

**File:** `test-generator.md`
**Description:** Generate comprehensive test suites and testing strategies:
**Sections:** Unit Testing,Integration Testing,End-to-End Testing,Test Infrastructure,Quality Assurance,
**Size:** 169 words

### 🤖 MEZAN - Master Superprompt & AI Orchestration

**File:** `optimization-framework.md`
**Description:** **Project:** MEZAN (Quantum Machine Learning)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,📋 When You Analyze MEZAN,🎓 Key Commands for Claude Code,💡 MCP Servers Available,🚀 Cost Optimization,✅ Your Priorities for MEZAN,📞 Quick Reference,
**Size:** 550 words

### Dependency Security Audit

**File:** `dependency-security-audit.md`
**Description:** Conduct comprehensive security audit of project dependencies:
**Sections:** Vulnerability Assessment,Dependency Analysis,Security Hardening,Compliance & Governance,
**Size:** 137 words

### Project Setup Orchestrator

**File:** `project-setup.md`
**Description:** You are a project setup specialist that creates optimal development environments and project structures. Focus on:
**Sections:** Setup Phases,Technology Detection,Setup Templates,Project Type: [Detected/Specified],Validation Checklist,Integration Points,
**Size:** 213 words

### Librex.Flow Implementation Superprompt

**File:** `flow-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Testing Protocol,6. Publication Strategy,7. Success Criteria,8. Next Actions,
**Size:** 2501 words

### Repository Organization & Cleanup Master Prompt

**File:** `codebase-cleanup.md`
**Description:** A comprehensive, adaptable prompt for organizing and professionalizing any repository.
**Sections:** Overview,Master Prompt Template,Current Situation,Goals,Scope of Work,Project Type Specifics,Expandability Requirements,Deliverables,Timeline & Commits,Quick Reference: Customization Sections,Standard Directory Structures by Type,Documentation Checklist,Common Issues & Solutions,Implementation Steps,Git Workflow Template,Verification Checklist,Result: Professional Project Characteristics,Customization Examples,Current Situation,Specific Goals,Type: PYTHON,Current Situation,Specific Goals,Type: MONOREPO + NODE.JS,Current Situation,Specific Goals,Type: PYTHON (Data Science),Resources & Templates,Quick Facts,Getting Started,Documentation,Contributing,Overview,Directories,How to Navigate,Adding New [Features/Modules],Getting Started,Development Workflow,Submitting Changes,Code Standards,Questions?,Final Notes,
**Size:** 2459 words

### Governance & Compliance Superprompt

**File:** `governance-compliance.md`
**Description:** Comprehensive framework for enforcing governance standards, compliance requirements, ethical AI practices, and access controls across all projects and repositories.
**Sections:** Purpose,System Prompt,Governance Framework,Overview,Compliance Requirements,Access Control,Code Review Requirements,Ethical AI Guidelines,Audit Requirements,Incident Response,Review Schedule,Policy-as-Code Implementation,Access Control Implementation,Ethical AI Framework,Model Details,Intended Use,Training Data,Evaluation Data,Metrics,Fairness Analysis,Ethical Considerations,Limitations,Recommendations,Compliance Automation,Audit Trail Implementation,Execution Phases,
**Size:** 1870 words

### Platform & Deployment Superprompt

**File:** `platform-deployment.md`
**Description:** Comprehensive framework for web platform deployment, cloud infrastructure, responsive design implementation, SEO optimization, and performance engineering.
**Sections:** Purpose,System Prompt,Cloud Infrastructure,Deployment Strategies,SEO Optimization,Performance Optimization,Kubernetes Deployment,Execution Phases,
**Size:** 1695 words

### API Design Optimizer

**File:** `api-design-optimizer.md`
**Description:** Design and optimize RESTful and GraphQL APIs:
**Sections:** API Architecture,Performance & Scalability,Security Implementation,Documentation & Testing,Monitoring & Analytics,
**Size:** 179 words

### Repository Health Assessment

**File:** `repo-health-assessment.md`
**Description:** You are a repository health specialist that evaluates GitHub repositories for code quality, maintainability, and best practices. Focus on:
**Sections:** Health Metrics Analysis,Assessment Areas,Output Format,Repository Health Score: X/100,Integration Points,
**Size:** 192 words

### API Documentation Generator

**File:** `api-documentation.md`
**Description:** You are an API documentation specialist that creates comprehensive, accurate, and user-friendly API documentation. Focus on:
**Sections:** Documentation Standards,Content Structure,API Documentation Outline,Quality Assurance,Automation Integration,Integration Points,
**Size:** 213 words

### Data Pipeline Architect

**File:** `data-pipeline-architect.md`
**Description:** Design and optimize data processing pipelines:
**Sections:** Pipeline Architecture,Data Quality & Governance,Performance & Scalability,Storage & Processing,Monitoring & Reliability,
**Size:** 178 words

### SimCore Claude Code Superprompt

**File:** `physics-simulation-engine.md`
**Description:** _Ultimate implementation guide for the SimCore Interactive Scientific Computing Laboratory_
**Sections:** 🚀 Master Superprompt,🎯 Focused Implementation Prompts,🛠️ Technical Implementation Guide,✅ Success Validation Checklist,🚀 Deployment Commands,📋 Quick Reference,🎯 Implementation Priority,
**Size:** 1335 words

### Technical Debt Reduction Specialist

**File:** `technical-debt-reduction.md`
**Description:** You are a technical debt specialist that identifies, prioritizes, and systematically reduces technical debt. Focus on:
**Sections:** Debt Classification,Debt Quantification,Technical Debt Assessment,Reduction Strategy,Prevention Measures,Integration Points,
**Size:** 253 words

### 🎯 LOCAL AI/ML/LLM ORCHESTRATION SUPERPROMPT

**File:** `local-ai-orchestration.md`
**Description:** **For**: Claude Instance 3 (Local Development Environment Setup)
**Sections:** MISSION BRIEF,CURRENT STATE ANALYSIS,DELIVERABLES EXPECTED,SPECIFIC INSTRUCTIONS,REFERENCE SPECIFICATIONS,INTEGRATION WITH ORCHEX/LIBRIA,DELIVERABLE CHECKLIST,SUCCESS CRITERIA,BONUS FEATURES (If Time Allows),REFERENCES,SUCCESS HANDOFF,
**Size:** 1604 words

### Amazon Q Quality Orchestrator

**File:** `amazonq-quality-orchestrator.md`
**Description:** You are Amazon Q's quality orchestration system. Coordinate quality assurance across all Q operations and workflows.
**Sections:** Quality Coordination,Quality Orchestration Patterns,Implementation Framework,
**Size:** 360 words

### E-Commerce Platform Development - Complete Phased Approach

**File:** `ecommerce-development-phases.md`
**Description:** 1. "Create a modern [Next.js 14/React/Vue] project with TypeScript, [Tailwind/styled-components], and [App Router/routing solution] for an e-commerce platform"
**Sections:** Phase 1: Foundation & Setup (Prompts 1-5),Phase 2: Core E-Commerce Features (Prompts 6-15),Phase 3: Enhanced Shopping Experience (Prompts 16-25),Phase 4: Admin & Management (Prompts 26-35),Phase 5: Advanced Features (Prompts 36-45),Phase 6: Mobile & PWA (Prompts 46-50),Phase 7: Marketing & Growth (Prompts 51-60),Phase 8: Technical Excellence (Prompts 61-70),Phase 9: Analytics & Optimization (Prompts 71-80),Phase 10: Internationalization & Scale (Prompts 81-90),Phase 11: Advanced Integrations (Prompts 91-100),
**Size:** 1591 words

### Naming Standards Architect

**File:** `standards-architect.md`
**Description:** You are a naming standards expert that establishes and documents comprehensive naming conventions for projects. Focus on:
**Sections:** Standards Framework,Convention Categories,Naming Standards Specification,Documentation Generation,Validation Tools,Integration Points,
**Size:** 254 words

### Pull Request Analysis

**File:** `pr-analysis.md`
**Description:** You are a pull request analysis expert that provides comprehensive code review and impact assessment. Focus on:
**Sections:** Analysis Dimensions,Review Categories,Output Format,PR Analysis Summary,Integration Points,
**Size:** 205 words

### Repository Consolidation Master Prompt

**File:** `repository-consolidation-master.md`
**Description:** Transform the GitHub workspace from 47 root folders into a streamlined 10-folder architecture while preserving all functionality, improving governance, and maintaining zero data loss.
**Sections:** Mission,Current State Analysis,Target Architecture,Consolidation Strategy,Critical Safeguards,File Path Updates Required,Success Metrics,Rollback Plan,Execution Order,Notes,
**Size:** 878 words

### AI Development Environment Integration Optimizer

**File:** `ai-development-integration-optimizer.md`
**Description:** Optimize and integrate all AI development components into a cohesive, high-performance system.
**Sections:** Integration Analysis,Unified Configuration System,Workflow Integration Patterns,Advanced Integration Features,Implementation Strategy,
**Size:** 792 words

### Instructions for Claude Opus: Repository Consolidation

**File:** `claude-opus-configuration.md`
**Description:** Execute a comprehensive repository consolidation to transform 47 root folders into 10 streamlined directories while maintaining zero data loss and full functionality.
**Sections:** Your Mission,Available Prompts,Execution Protocol,Summary,Changes Made,Validation Results,Breaking Changes,Migration Guide,Critical Rules,Error Handling,Communication Protocol,Success Criteria Checklist,Final Command,Notes,
**Size:** 879 words

### Prompt Optimization Superprompt

**File:** `prompt-optimization.md`
**Description:** Comprehensive framework for optimizing prompts for length, formatting, code generation quality, and IDE-specific features including Blackbox AI, Cursor, and other AI coding assistants.
**Sections:** Purpose,System Prompt,Prompt Optimization Principles,IDE-Specific Optimization,Code Generation Quality,Prompt Testing Framework,Optimization Checklist,Execution Phases,
**Size:** 1733 words

### Constitutional Self-Alignment Prompt

**File:** `constitutional-ai-alignment.md`
**Description:** Enable AI to critique and revise its own outputs based on constitutional principles.
**Sections:** Purpose,Source,System Prompt,Constitutional Principles,Two-Phase Implementation,Benefits,
**Size:** 288 words

### State-of-the-Art AI & Architecture Practices

**File:** `ai-best-practices.md`
**Description:** Comprehensive evaluation of enterprise-grade agentic AI platform practices, caching strategies, and organizational architecture patterns.
**Sections:** Overview,Prompt Caching,Advanced Caching Architectures,Enterprise-Grade Optimization Techniques,Advanced Agentic AI Patterns,Scalability & Performance Practices,Enterprise Reliability Patterns,State-of-the-Art Implementation Checklist,Governance Framework,Optimal Architecture Structure,Assessment Scores,Key Differentiators,
**Size:** 1081 words

### Refactoring Orchestrator

**File:** `refactoring-orchestrator.md`
**Description:** You are a refactoring specialist that systematically improves code quality while preserving functionality. Focus on:
**Sections:** Refactoring Categories,Refactoring Strategy,Refactoring Plan,Risk Management,Integration Points,
**Size:** 233 words

### AI/ML Integration Superprompt

**File:** `ai-ml-integration.md`
**Description:** Comprehensive framework for integrating AI/ML capabilities into applications, including LLM integration, model deployment, MLOps practices, and responsible AI implementation.
**Sections:** Purpose,System Prompt,LLM Integration Patterns,Prompt Engineering,Model Serving,MLOps Pipeline,Execution Phases,
**Size:** 2274 words

### Enterprise Repository Audit

**File:** `enterprise-repo-audit.md`
**Description:** Comprehensive enterprise repository assessment:
**Sections:** Repository Health,Security Posture,Development Workflow,Governance & Compliance,Performance Metrics,
**Size:** 169 words

### Write Comprehensive Tests For Rest

**File:** `test-api-testing.md`
**Description:** > **Comprehensive testing strategy**
**Sections:** Purpose,When to Use,Prompt,Examples,Success Criteria,Related Prompts,
**Size:** 199 words

### Design System Superprompts Collection

**File:** `DESIGN_SYSTEM_PROMPTS.md`
**Description:** 1. [Anti-Generic Design Principles](#anti-generic-design-principles)
**Sections:** Table of Contents,Anti-Generic Design Principles,Authentic Content & Copy,Sophisticated Visual Design,Elegant Animation Patterns,Component Design Excellence,Professional Polish Details,Modern Layout Techniques,Color & Theme Sophistication,Typography Excellence,Anti-Patterns to Avoid,Implementation Standards,Comprehensive Audit Protocol,Platform Rebranding Framework,Additional Sophistication Patterns,Testing & Quality Assurance,
**Size:** 2366 words

### Amazon Q Workflow Orchestrator

**File:** `amazonq-workflow-orchestrator.md`
**Description:** You are Amazon Q's internal workflow orchestrator. Coordinate multi-step development tasks across Amazon Q's capabilities.
**Sections:** Core Functions,Workflow Patterns,Implementation,
**Size:** 189 words

### Quantum Algorithm Development

**File:** `quantum-algorithm-dev.md`
**Description:** You are an expert quantum computing developer working on the Morphism Projects quantum mathematics engine. Focus on:
**Sections:** Core Responsibilities,Code Standards,Architecture Patterns,Key Considerations,
**Size:** 158 words

### Security Audit Comprehensive

**File:** `security-audit-comprehensive.md`
**Description:** Comprehensive security assessment and hardening:
**Sections:** Application Security,Infrastructure Security,Data Security,Code Security,Incident Response,
**Size:** 176 words

### Amazon Q Intelligent Task Router

**File:** `amazonq-intelligent-task-router.md`
**Description:** You are Amazon Q's intelligent task routing system. Analyze requests and route to optimal Q capabilities and workflows.
**Sections:** Routing Intelligence,Smart Routing Rules,Implementation,
**Size:** 276 words

### Amazon Q Architecture Review

**File:** `architecture-review.md`
**Description:** You are Amazon Q's internal architecture reviewer. Analyze codebase architecture using Q's tools and provide comprehensive recommendations for:
**Sections:** Core Analysis,Technical Debt Assessment,Recommendations,
**Size:** 131 words

### Gating & Approval Workflows Superprompt

**File:** `approval-gating-system.md`
**Description:** Comprehensive framework for implementing quality gates, approval workflows, and security checkpoints to ensure code quality, compliance, and controlled releases.
**Sections:** Purpose,System Prompt,Gating Framework,Code Review Process,Description,Type of Change,Related Issues,Testing,Security Checklist,Documentation,Deployment Notes,Screenshots,Security Gates,Approval Workflows,Compliance Gates,Quality Gate Configuration,Execution Phases,
**Size:** 1504 words

### Monorepo & Architecture Superprompt

**File:** `monorepo-architecture.md`
**Description:** Comprehensive framework for organizing, structuring, and managing monorepo architectures with modular design, dependency handling, and scalable project organization.
**Sections:** Purpose,System Prompt,Monorepo Structure,Nx Configuration,Turborepo Configuration,Package Boundaries,Workspace Configuration,CI/CD for Monorepos,Code Generation,Execution Phases,
**Size:** 1453 words

### GPU Optimization Superprompt

**File:** `gpu-optimization.md`
**Description:** > **Optimize Python code for GPU acceleration with JAX/CUDA**
**Sections:** Metadata,Purpose,Prompt,Context,Code to Optimize,Requirements,Workflow,Example,Success Criteria,Usage,Related Resources,
**Size:** 365 words

### Consistency Enforcement Engine

**File:** `consistency-enforcement.md`
**Description:** You are a naming consistency specialist that enforces and maintains consistent naming conventions across codebases. Focus on:
**Sections:** Naming Convention Analysis,Consistency Audit,Naming Consistency Report,Enforcement Automation,Refactoring Coordination,Integration Points,
**Size:** 247 words

### Test Generation and Coverage Analysis

**File:** `automated-test-generation.md`
**Description:** Automated test creation with coverage goals and quality standards.
**Sections:** Purpose,Test Generation Framework,Test Generation Prompt,Coverage Analysis Report,Coverage Report,Integration Commands,
**Size:** 758 words

### Refactor Modernize

**File:** `refactor-modernize.md`
**Description:** Modernize legacy codebases with systematic refactoring:
**Sections:** Legacy Code Assessment,Modernization Strategy,Refactoring Techniques,Testing & Validation,Migration Planning,
**Size:** 160 words

### Security & Cybersecurity Superprompt

**File:** `security-implementation.md`
**Description:** Comprehensive framework for application security, infrastructure security, DevSecOps practices, and cybersecurity implementation across all projects.
**Sections:** Purpose,System Prompt,Security Architecture,OWASP Top 10 Mitigations,Security Scanning Pipeline,Threat Modeling,Security Monitoring,Incident Response,Execution Phases,
**Size:** 1963 words

### Framework Optimization Engine

**File:** `framework-optimization.md`
**Description:** You are a framework optimization specialist that maximizes the effectiveness and performance of technology frameworks. Focus on:
**Sections:** Optimization Areas,Framework Analysis,Framework Optimization Report,Best Practice Implementation,Performance Monitoring,Integration Points,
**Size:** 254 words

### ML Model Optimizer

**File:** `ml-model-optimizer.md`
**Description:** Optimize machine learning models and deployment:
**Sections:** Model Performance,Training Optimization,Model Deployment,Data Management,MLOps Integration,
**Size:** 169 words

### Phase 3: AI System Integration

**File:** `ai-integration-phase.md`
**Description:** Merge ai-tools/ into .ai/tools/ for unified AI orchestration management.
**Sections:** Objective,Pre-Flight Checks,Execution Steps,Path Updates Required,Validation Tests,Rollback Procedure,Success Criteria,Commit Message,
**Size:** 341 words

### Session Summary: AI Automation Enhancement (Nov 30, 2024)

**File:** `session-summary-template.md`
**Description:** This session focused on enhancing the `automation/` system with state-of-the-art AI practices based on comprehensive research of CrewAI, AutoGen, LangGraph, MetaGPT, and Anthropic's prompt engineering best practices.
**Sections:** Overview,Session Timeline,Issue: automation-ts Deletion,Final Asset Counts,Key Research Findings Implemented,Investigation Findings,Next Steps,
**Size:** 921 words

### 🚀 CRAZY IDEAS MASTER PROMPT - Ready-to-Deploy Project Repository Generator

**File:** `creative-ideation.md`
**Description:** **Purpose**: Transform brainstorming ideas into production-ready project repositories with golden template governance.
**Sections:** 📚 TABLE OF CONTENTS,🎯 OVERVIEW & PHILOSOPHY,🏗️ GOLDEN TEMPLATE STRUCTURE,🎨 20 CRAZY IDEAS,🚀 DEPLOYMENT INSTRUCTIONS,📊 GOVERNANCE & STANDARDS,🎯 PROJECT PRIORITIZATION MATRIX,🎬 EXAMPLE: DEPLOYING PROJECT #1 (HYPOTHESIS DATING),📝 SSOT PROMPT TEMPLATES,🚀 QUICK REFERENCE COMMANDS,📚 ADDITIONAL RESOURCES,🎉 FINAL NOTES,
**Size:** 8216 words

### Cloud Architecture Optimizer

**File:** `cloud-architecture-optimizer.md`
**Description:** Optimize cloud infrastructure and architecture:
**Sections:** Infrastructure Design,Cost Optimization,Performance & Reliability,Security & Compliance,DevOps Integration,
**Size:** 175 words

### SaaS Platform Development - Complete Phased Approach

**File:** `saas-development-phases.md`
**Description:** 1. "Create a modern [Next.js/React/Vue] SaaS application with TypeScript, authentication framework, and database setup"
**Sections:** Phase 1: Foundation & Authentication (Prompts 1-10),Phase 2: Core SaaS Features (Prompts 11-20),Phase 3: Subscription & Monetization (Prompts 21-30),Phase 4: Team Collaboration (Prompts 31-40),Phase 5: Admin & Management (Prompts 41-50),Phase 6: Integrations & API (Prompts 51-60),Phase 7: Mobile & Cross-Platform (Prompts 61-65),Phase 8: Security & Compliance (Prompts 66-75),Phase 9: Performance & Scale (Prompts 76-85),Phase 10: Analytics & Insights (Prompts 86-95),Phase 11: Advanced Features (Prompts 96-100),
**Size:** 1435 words

### Modernization Engine

**File:** `modernization-engine.md`
**Description:** You are a code modernization expert that upgrades legacy code to current standards and best practices. Focus on:
**Sections:** Modernization Targets,Migration Strategy,Modernization Roadmap,Compatibility Management,Validation Framework,Integration Points,
**Size:** 232 words

### Architecture Validation Engine

**File:** `architecture-validation.md`
**Description:** You are an architecture validation specialist that ensures project structure aligns with architectural principles and best practices. Focus on:
**Sections:** Validation Dimensions,Architectural Rules,Architecture Validation Rules,Violation Detection,Improvement Recommendations,Architecture Improvement Plan,Integration Points,
**Size:** 305 words

### Documentation Maintenance Orchestrator

**File:** `maintenance-orchestrator.md`
**Description:** You are a documentation maintenance specialist that keeps technical documentation accurate, current, and useful. Focus on:
**Sections:** Maintenance Activities,Automated Checks,Documentation Health Metrics,Update Workflows,Quality Assurance,Integration Points,
**Size:** 207 words

### Test Generation Engine

**File:** `test-generation.md`
**Description:** You are a test generation specialist that creates comprehensive, maintainable test suites. Focus on:
**Sections:** Test Generation Strategies,Test Categories,Generated Test Suite Structure,Code Analysis Integration,Test Maintenance,Integration Points,
**Size:** 254 words

### Project Organization Architect

**File:** `project-organization.md`
**Description:** You are a project organization expert that designs optimal folder structures and architectural layouts. Focus on:
**Sections:** Organization Principles,Structure Patterns,Recommended Project Structure,Migration Strategy,Validation Framework,Integration Points,
**Size:** 257 words

### KILO Consolidation Methodology Superprompt

**File:** `repository-consolidation.md`
**Description:** Comprehensive framework for radical codebase simplification following the KILO (Keep It Lean, Optimize) methodology - achieving 80%+ reduction in complexity while maintaining full functionality.
**Sections:** Purpose,System Prompt,KILO Principles,Consolidation Analysis Framework,Unified CLI Architecture,Shared Library Extraction,Automated Enforcement,Migration Guide Template,Overview,Command Mapping,Breaking Changes,Deprecation Timeline,Getting Help,Consolidation Metrics Dashboard,Execution Phases,
**Size:** 2217 words

### Amazon Q Prompts - Quick Reference

**File:** `quick-reference.md`
**Description:** ```bash
**Sections:** 🎯 MOST USED (Top 10),📁 DIRECTORY STRUCTURE,🔍 FIND THE RIGHT PROMPT,⚡ COMMON WORKFLOWS,🎨 ORCHESTRATOR DECISION TREE,📊 TIER SYSTEM,🚀 GETTING STARTED,📚 DOCUMENTATION,🔄 BACKUP & RESTORE,
**Size:** 440 words

### Amazon Q Enterprise Code Review

**File:** `code-review-enterprise.md`
**Description:** You are Amazon Q's internal enterprise code reviewer. Perform enterprise-grade code review using Q's codeReview tool and focusing on:
**Sections:** Code Quality Standards,Security Assessment,Performance & Scalability,Maintainability,
**Size:** 160 words

### Optimize Memory Usage In Python Application

**File:** `test-memory-optimization.md`
**Description:** > **Optimize for performance and efficiency**
**Sections:** Purpose,When to Use,Prompt,Examples,Success Criteria,Related Prompts,
**Size:** 187 words

### Intelligent Agent Registry

**File:** `intelligent-agent-registry.md`
**Description:** Dynamic agent management system with capability-based routing and orchestration.
**Sections:** Agent Management,Orchestration Intelligence,Agent Specifications,Implementation Framework,
**Size:** 455 words

### Healthcare Platform Development - Complete Phased Approach

**File:** `healthcare-development-phases.md`
**Description:** 1. "Create a HIPAA-compliant healthcare platform with [Next.js/React], secure architecture, and encrypted database"
**Sections:** Phase 1: Foundation & Compliance (Prompts 1-10),Phase 2: Appointment Management (Prompts 11-20),Phase 3: Telemedicine & Virtual Care (Prompts 21-30),Phase 4: Electronic Health Records (EHR) (Prompts 31-40),Phase 5: Billing & Insurance (Prompts 41-50),Phase 6: Clinical Decision Support (Prompts 51-60),Phase 7: Patient Engagement (Prompts 61-70),Phase 8: Provider Tools (Prompts 71-80),Phase 9: Analytics & Reporting (Prompts 81-90),Phase 10: Integrations (Prompts 91-95),Phase 11: Advanced Features (Prompts 96-100),
**Size:** 1398 words

### Amazon Q Context Orchestrator

**File:** `amazonq-context-orchestrator.md`
**Description:** You are Amazon Q's context orchestration system. Manage context flow and state across complex multi-step operations.
**Sections:** Context Management,Orchestration Patterns,Implementation Rules,
**Size:** 329 words

### Enterprise Workflow Automation

**File:** `enterprise-workflow-automation.md`
**Description:** Comprehensive enterprise-grade workflow automation with intelligent orchestration.
**Sections:** Workflow Architecture,Enterprise Features,Implementation Specifications,
**Size:** 392 words

### 🤖 QUBE-ML - Master Superprompt & AI Orchestration

**File:** `quantum-ml-framework.md`
**Description:** **Project:** QUBE-ML (Quantum Machine Learning)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,✅ Your Priorities,
**Size:** 203 words

### Lovable Fullstack Template System

**File:** `LOVABLE_FULLSTACK_TEMPLATE_SYSTEM.md`
**Description:** ---
**Sections:** Complete Documentation & Unification Strategy,1.1 Purpose,1.2 Key Deliverables,1.3 Credit Allocation Summary,2.1 Background,2.2 Goals,2.3 Target Use Cases,3.1 Alawein Design System - Color Tokens,3.2 Typography System,3.3 Animation System,3.4 Effects System,4.1 Engine Overview,4.2 Glassmorphism Engine,4.3 Neumorphism Engine,4.4 Brutalist Engine,4.5 Cyberpunk Engine,4.6 Soft Pastel Engine,5.1 Complete Template List (43+ Templates),6.1 Master Template Gallery Prompt,Project Overview,Technical Stack,Layout Structure,Animations (Framer Motion),Color Palette,Typography,Responsive Breakpoints,Accessibility Requirements,DO NOT INCLUDE,6.2 Glassmorphism Templates,Visual Design,Layout Structure,Animations,Special Effects,Technical Requirements,DO NOT INCLUDE,Visual Design,Layout Structure,Animations,Technical Requirements,6.3 Neumorphism Templates,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,6.4 Brutalist Templates,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Typography,Animations,Technical Requirements,6.5 Cyberpunk Templates,Visual Design,Layout Structure,Special Effects,Animations,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,6.6 Soft Pastel Templates,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,1. PROJECT OVERVIEW,2. FRONTEND ANALYSIS,3. BACKEND ANALYSIS (if applicable),4. FILE STRUCTURE,5. DEPENDENCIES,6. QUALITY METRICS,7. RECOMMENDATIONS,8. INTEGRATION READINESS,9. COMPLETE CODE INVENTORY,10. VISUAL DOCUMENTATION,8.1 Unification Architecture,8.2 Backend Integration Patterns,8.3 Shared Type Definitions,8.4 Fullstack Template Prompt,Overview,Technical Stack,Database Schema,Features to Implement,UI Components (Glassmorphism Style),File Structure,Environment Variables,Styling Requirements,DO NOT INCLUDE,Deliverables,8.5 Unification Folder Structure,9.1 Phase 1: Foundation (Week 1),9.2 Phase 2: Engine Templates (Week 2),9.3 Phase 3: Additional Templates (Week 3),9.4 Phase 4: Fullstack Integration (Week 4),9.5 Credit Summary,10.1 Core Dependencies,10.2 Tailwind Configuration,10.3 Vite Configuration,11.1 Immediate Post-Download Tasks,After Downloading Each Template,11.2 Deployment Checklist,Deployment Preparation,Appendix A: CSS Design Tokens File,Appendix B: Quick Reference Card,Lovable Prompt Best Practices,Credit Optimization Tips,Appendix C: Emergency Prompt Template,Colors,Typography,Layout,Features,Tech Stack,DO NOT INCLUDE,
**Size:** 10848 words

### Debugger System Prompt

**File:** `debugger.md`
**Description:** You are a Debugging Specialist responsible for systematically identifying and resolving software issues.
**Sections:** Core Methodology,Debugging Process,Bug Report Analysis,Reproduction Steps,Minimal Reproduction,Hypothesis Testing,Root Cause,Fix Strategy,Implementation,Debugging Techniques,Common Bug Patterns,Output Format,Summary,Investigation,Fix,Best Practices,
**Size:** 587 words

### 🤖 SCI-COMP - Master Superprompt & AI Orchestration

**File:** `scientific-computing-library.md`
**Description:** **Project:** SCI-COMP (Scientific Computing)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,✅ Your Priorities,
**Size:** 193 words

### ML/AI Pipeline Development Framework

**File:** `ml-pipeline-design.md`
**Description:** End-to-end machine learning project execution with production-ready standards.
**Sections:** Purpose,1. DATA ENGINEERING,2. MODEL DEVELOPMENT,3. DEPLOYMENT,4. DOCUMENTATION,Model Details,Intended Use,Training Data,Evaluation,Ethical Considerations,Limitations,Checklist,
**Size:** 555 words

### Dependency Management Optimizer

**File:** `dependency-management.md`
**Description:** You are a dependency management expert that optimizes package dependencies for security, performance, and maintainability. Focus on:
**Sections:** Dependency Analysis,Optimization Strategies,Output Format,Dependency Audit Results,Automation Setup,Integration Points,
**Size:** 220 words

### Orchestrator System Prompt

**File:** `workflow-orchestration.md`
**Description:** You are an AI Orchestrator responsible for coordinating multi-agent workflows and routing tasks to appropriate specialists.
**Sections:** Core Responsibilities,Available Agents,Workflow Patterns,Decision Framework,Handoff Protocol,Error Handling,Output Format,Task Analysis,Selected Pattern,Execution Plan,Success Criteria,
**Size:** 479 words

### Code Review Orchestrator

**File:** `code-review-orchestrator.md`
**Description:** You are a code review orchestration expert that coordinates comprehensive multi-dimensional code reviews. Focus on:
**Sections:** Review Orchestration,Review Dimensions,Reviewer Assignment,Review Assignment Matrix,Quality Gates,Integration Points,
**Size:** 187 words

### Multi-Agent Development Coordinator

**File:** `multi-agent-development-coordinator.md`
**Description:** Coordinate specialized development agents for complex software engineering tasks.
**Sections:** Agent Ecosystem,Workflow Templates,Implementation Requirements,
**Size:** 372 words

### Librex.Meta Implementation Superprompt

**File:** `meta-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Testing Protocol,6. Benchmark Setup,7. Publication Strategy,8. Code Repository Structure,9. Risk Mitigation,10. Success Criteria,11. Next Actions,12. Contact and Coordination,Appendix: Key References,
**Size:** 3979 words

### Environment Configuration Manager

**File:** `environment-config.md`
**Description:** You are an environment configuration specialist that manages development, staging, and production environments. Focus on:
**Sections:** Configuration Management,Environment Parity,Security Considerations,Security Checklist,Configuration Templates,Environment: [Development/Staging/Production],Integration Points,
**Size:** 208 words

### 🤖 Repz - Master Superprompt & AI Orchestration

**File:** `fitness-platform-development.md`
**Description:** **Project:** Repz (Resume Management & Automation)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,📋 When You Analyze Repz,🎓 Key Commands for Claude Code,💡 MCP Servers Available,🚀 Cost Optimization,✅ Your Priorities for Repz,📞 Quick Reference,
**Size:** 554 words

### QAP Optimization Specialist

**File:** `qap-optimization.md`
**Description:** You are an expert in Quadratic Assignment Problem (QAP) optimization within the QAPlibria framework. Focus on:
**Sections:** Core Expertise,Algorithm Implementation,Performance Standards,Research Integration,Code Quality,
**Size:** 183 words

### Brainstorming prompt for automation

**File:** `brainstorming-facilitation.md`
**Description:** **User:** Anonymous (meshal.ow@live.com)  
**Sections:** Prompt:,Response:,Prompt:,**1. "SCIENTIFIC TINDER" - Hypothesis Dating App**,Response:,Prompt:,System Overview,Response Format (Required for ALL answers),Question Clusters (by Priority),Key Constraints,Deliverable,Key Improvements,Response:,Prompt:,Response:,Prompt:,Response:,1\. Optimized Claude Prompt,Role & Context,Response Contract (for EVERY question cluster),Question Clusters (by Priority),Key Constraints,Deliverable,2\. Content-Level Review & How to Use This Prompt,Prompt:,Response:,1\. What is this system, actually?,2\. Multi-step, self-refuting master prompt,GLOBAL ANSWER CONTRACT (for all phases),PHASE 1 – System Identity & Problem Definition,PHASE 2 – Foundations: SSOT, Data, and Ontology,PHASE 3 – Agent Architecture, Meta-Learning, and Self-Learning,PHASE 4 – Safety, Governance, and MLOps,PHASE 5 – Roadmap and Minimal Viable System,FINAL OUTPUT EXPECTATION,3\. What base assets do we need to assume?,
**Size:** 12702 words

### Evaluator System Prompt

**File:** `code-evaluation.md`
**Description:** You are a Quality Evaluator responsible for assessing AI-generated outputs against defined criteria.
**Sections:** Evaluation Dimensions,Scoring Rubric,Evaluation Process,Output Format,Iteration Protocol,Quality Gates,
**Size:** 477 words

### Mobile App Optimizer

**File:** `mobile-app-optimizer.md`
**Description:** Optimize mobile applications for performance and user experience:
**Sections:** Performance Optimization,User Interface,Platform Integration,Data Management,Testing & Quality,
**Size:** 175 words

### Librex.Dual Implementation Superprompt

**File:** `dual-problem-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Success Criteria,
**Size:** 2098 words

### DevOps Pipeline Optimizer

**File:** `devops-pipeline-optimizer.md`
**Description:** Optimize CI/CD pipelines and DevOps practices:
**Sections:** Pipeline Architecture,Testing Integration,Deployment Strategies,Monitoring & Observability,Infrastructure Management,
**Size:** 172 words

### Prompt Index

**File:** `prompt-index.md`
**Description:** Comprehensive catalog and management of AI prompts:
**Sections:** Prompt Organization,Quality Assessment,Prompt Engineering,Usage Analytics,Maintenance & Governance,
**Size:** 166 words

### Librex.Alloc Implementation Superprompt

**File:** `resource-allocation-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Success Criteria,
**Size:** 1966 words

### Multi-Hop RAG Query Processing

**File:** `multi-hop-rag.md`
**Description:** Complex retrieval with reasoning chains for questions requiring multiple evidence pieces.
**Sections:** Purpose,Source,Multi-Hop Retrieval Process,Self-RAG (Adaptive Retrieval),Agentic RAG Pipeline,Output Format,Answer,Evidence Chain,Sources,Confidence Assessment,Integration,
**Size:** 779 words

### Database Optimizer

**File:** `database-optimizer.md`
**Description:** Optimize database performance and design:
**Sections:** Schema Design,Query Optimization,Performance Monitoring,Data Management,Security & Compliance,
**Size:** 163 words

### UI/UX Design Superprompt

**File:** `ui-ux-design.md`
**Description:** Comprehensive framework for user interface design, user experience optimization, accessibility standards, and design system implementation.
**Sections:** Purpose,System Prompt,Design System Architecture,Component Implementation,Accessibility Standards,Responsive Design,User Feedback Loops,Execution Phases,
**Size:** 1869 words

### Git Workflow Optimizer

**File:** `git-workflow-optimizer.md`
**Description:** Optimize Git workflows and repository management:
**Sections:** Branching Strategy,Commit Management,Collaboration Workflow,Repository Optimization,Automation & Integration,
**Size:** 163 words

### 🤖 SPIN-CIRC - Master Superprompt & AI Orchestration

**File:** `quantum-circuit-simulator.md`
**Description:** **Project:** SPIN-CIRC (Spin Circuits)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,✅ Your Priorities,
**Size:** 195 words

### IDE Integration Framework

**File:** `ide-integration-framework.md`
**Description:** Seamless integration of AI workflow orchestration into development environments.
**Sections:** Integration Architecture,Development Workflow Integration,Configuration Management,API Integration,Implementation Guidelines,
**Size:** 652 words

### Educational Platform (LMS) Development - Complete Phased Approach

**File:** `lms-development-phases.md`
**Description:** 1. "Create a modern LMS platform with [Next.js/React/Vue], TypeScript, authentication, and database architecture"
**Sections:** Phase 1: Foundation & User Management (Prompts 1-10),Phase 2: Course Creation & Management (Prompts 11-20),Phase 3: Learning Experience (Prompts 21-30),Phase 4: Assessment & Grading (Prompts 31-40),Phase 5: Communication & Collaboration (Prompts 41-50),Phase 6: Content Library & Resources (Prompts 51-60),Phase 7: Analytics & Reporting (Prompts 61-70),Phase 8: Monetization & Commerce (Prompts 71-80),Phase 9: Mobile & Accessibility (Prompts 81-85),Phase 10: Integrations & Extensions (Prompts 86-95),Phase 11: Advanced Features (Prompts 96-100),
**Size:** 1423 words

### 🤖 Librex - Master Superprompt & AI Orchestration

**File:** `optimization-algorithms-library.md`
**Description:** **Project:** Librex (Control Hub & Workflow Engine)
**Sections:** 🎯 Project Context,⚡ Execution Framework,🔧 Configuration,📋 When You Analyze Librex,🎓 Key Commands for Claude Code,💡 MCP Servers Available,🚀 Cost Optimization,✅ Your Priorities for Librex,📞 Quick Reference,
**Size:** 546 words

### Chain-of-Thought Meta-Prompt

**File:** `chain-of-thought-reasoning.md`
**Description:** Enable structured reasoning for complex problems through visible thought processes.
**Sections:** Purpose,Source,System Prompt,When to Use,Reasoning Patterns,Scratchpad Technique,Benefits,
**Size:** 297 words

### CI/CD Pipeline Superprompt

**File:** `cicd-pipeline-setup.md`
**Description:** Comprehensive CI/CD pipeline design and implementation framework for automated building, testing, and deployment across multiple environments.
**Sections:** Purpose,System Prompt,Pipeline Architecture,GitHub Actions Workflows,Deployment Strategies,Environment Configuration,Execution Phases,
**Size:** 1331 words

### Performance Optimizer

**File:** `performance-optimizer.md`
**Description:** Comprehensive performance analysis and optimization:
**Sections:** Performance Profiling,Algorithm Optimization,System-Level Optimization,Language-Specific Optimization,Monitoring & Measurement,
**Size:** 162 words

### Physics Code Review Prompt

**File:** `physics-code-review.md`
**Description:** > **Review code with physics correctness as priority**
**Sections:** Metadata,Prompt,Code,Review Checklist,Output Format,Usage,
**Size:** 201 words

### Agentic Code Review

**File:** `agentic-code-review.md`
**Description:** AI-powered pull request reviews with comprehensive context analysis.
**Sections:** Purpose,Source,Code Review Checklist,Review Output Format,Code Review Summary,Review Workflow,Severity Levels,Integration Commands,
**Size:** 643 words

### Amazon Q Auto-Discovery & Learning System

**File:** `auto-discovery-system.md`
**Description:** ```json
**Sections:** How IDEs/LLMs Learn to Use the Orchestration System,
**Size:** 203 words

### Lovable Template Generation Strategy

**File:** `fullstack-saas-template.md`
**Description:** This document provides a comprehensive strategy for maximizing 200 Lovable credits to generate a library of deployment-ready UI/UX templates. All templates are designed to align with the Alawein Design System - a sophisticated, physics-inspired aesthetic featuring quantum visualizations, GPU-accelerated animations, and scientific elegance.
**Sections:** Executive Summary,Part 1: Master Design Token Reference,Part 2: Template Folder Structure,Part 3: Category-Specific Lovable Prompts,Visual Design,Layout Structure,Animations,Technical Requirements,DO NOT INCLUDE,Visual Design,Layout Structure,Interactive Elements,Code Display,Animations,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Data Visualization,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Real-Time Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Animations,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,DO NOT INCLUDE,Technical Requirements,Visual Design,Layout Structure,Technical Requirements,Visual Design,Layout Structure,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Placeholder Elements,Technical Requirements,Visual Design,Layout Structure,Technical Requirements,Visual Design,Layout Structure,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Visual Design,Layout Structure,Features,Technical Requirements,Part 4: Post-Processing Checklist,After Downloading Each Template,Design System Integration Steps,Alawein Signature Enhancements,Deployment Checklist,Part 5: Quick Reference Card,DO ✅,DON'T ❌,Maximize Your 200 Credits,Colors,Typography,Layout,Features,Tech Stack,DO NOT INCLUDE,Appendix: Design Token CSS File,
**Size:** 7206 words

### Amazon Q Usage Automation

**File:** `usage-automation.md`
**Description:** ```bash
**Sections:** How to Use the Orchestration System,
**Size:** 234 words

### Phase 2: Tooling Consolidation

**File:** `tooling-setup-phase.md`
**Description:** Merge tools/ and scripts/ into .metaHub/tools/ for unified CLI and automation management.
**Sections:** Objective,Pre-Flight Checks,Execution Steps,Path Updates Required,Validation Tests,Rollback Procedure,Success Criteria,Commit Message,
**Size:** 406 words

### Code Documentation Generator

**File:** `code-documentation.md`
**Description:** You are a code documentation expert that creates clear, maintainable inline and architectural documentation. Focus on:
**Sections:** Documentation Types,Documentation Standards,Code Documentation Template,Quality Metrics,Automation Features,Integration Points,
**Size:** 197 words

### Optilibria Optimization Framework Prompt

**File:** `optilibria-optimization.md`
**Description:** Specialized prompt for optimizing algorithms in the Optilibria library using JAX and CUDA acceleration.
**Sections:** Purpose,Context,Prompt,Usage Example,Success Criteria,Related Prompts,
**Size:** 300 words

### Amazon Q Orchestration - Next Phase

**File:** `next-phase-roadmap.md`
**Description:** - **Prompt Registry**: Dynamic discovery of available orchestrators
**Sections:** Phase 2: Intelligence & Automation,Implementation Priority,Success Metrics,
**Size:** 258 words

### Amazon Q Integration Examples

**File:** `integration-examples.md`
**Description:** Real-world examples of using Amazon Q's orchestration system for development tasks.
**Sections:** Example 1: Full-Stack Feature Development,Example 2: Code Quality Pipeline,Example 3: Database Optimization,Example 4: Security Audit,Example 5: Performance Optimization,Integration Best Practices,
**Size:** 533 words

### Amazon Q Master Orchestrator

**File:** `amazonq-master-orchestrator.md`
**Description:** You are Amazon Q's master orchestration system. Coordinate all Q capabilities, workflows, and internal systems for optimal user experience.
**Sections:** Master Coordination,Master Workflow Templates,Optimization Engine,Implementation Rules,
**Size:** 454 words

### AI Development System Implementation Guide

**File:** `ai-development-system-implementation-guide.md`
**Description:** Complete implementation roadmap for enterprise-grade AI-powered development environment.
**Sections:** System Overview,Implementation Roadmap,Technical Implementation,Configuration Templates,Success Metrics,Deployment Strategy,
**Size:** 1149 words

---

## Documentation (1 prompts)

### Context Engineering Prompt

**File:** `context-engineering.md`
**Description:** Manage limited attention budget effectively for optimal AI performance.
**Sections:** Purpose,Source,System Prompt,Context Budget Tracking,Structured Context Format,Context Optimization Strategies,Memory Management Patterns,Benefits,
**Size:** 317 words

---

## Specialized (7 prompts)

### Librex.Graph Implementation Superprompt

**File:** `graph-optimization.md`
**Description:** **Version**: 1.0
**Sections:** Executive Summary,1. Technical Specification,2. Research Validation,3. Implementation Roadmap,4. Integration with Libria Suite,5. Success Criteria,
**Size:** 1816 words

### Quantum Backend Integration Expert

**File:** `quantum-backend-integration.md`
**Description:** You are a specialist in quantum backend integration and hardware abstraction for Morphism Projects. Focus on:
**Sections:** Backend Support,Hardware Abstraction,Performance Optimization,Reliability Engineering,Integration Standards,
**Size:** 191 words

### AI Workflow Orchestrator

**File:** `ai-workflow-orchestrator.md`
**Description:** Multi-agent workflow coordination and intelligent task routing system.
**Sections:** Core Orchestration,Enterprise Features,Implementation Directives,
**Size:** 290 words

### Quantum Proof Verification Expert

**File:** `quantum-proof-verification.md`
**Description:** You are a specialist in quantum-enhanced mathematical proof verification for the Morphism Projects ecosystem. Focus on:
**Sections:** Core Mission,Technical Approach,Implementation Standards,Research Integration,
**Size:** 154 words

### Microservices Architect

**File:** `microservices-architect.md`
**Description:** Design and optimize microservices architecture:
**Sections:** Service Design,Architecture Patterns,Scalability & Performance,Data Management,Operational Excellence,
**Size:** 171 words

### Documentation Generator

**File:** `documentation-generator.md`
**Description:** Generate comprehensive project documentation:
**Sections:** API Documentation,Code Documentation,Architecture Documentation,User Documentation,
**Size:** 138 words

---

## Alphabetical Index

- **Design System Superprompts Collection** (`DESIGN_SYSTEM_PROMPTS.md`) — Quality — 2366 words
- **Lovable Fullstack Template System** (`LOVABLE_FULLSTACK_TEMPLATE_SYSTEM.md`) — Quality — 10848 words
- **🤖 SimCore - Master Superprompt & AI Orchestration** (`SIMCORE_SUPERPROMPT.md`) — Quality — 327 words
- **Agentic Code Review** (`agentic-code-review.md`) — Quality — 643 words
- **State-of-the-Art AI & Architecture Practices** (`ai-best-practices.md`) — Quality — 1081 words
- **AI Development Environment Integration Optimizer** (`ai-development-integration-optimizer.md`) — Quality — 792 words
- **AI Development System Implementation Guide** (`ai-development-system-implementation-guide.md`) — Quality — 1149 words
- **Phase 3: AI System Integration** (`ai-integration-phase.md`) — Quality — 341 words
- **AI/ML Integration Superprompt** (`ai-ml-integration.md`) — Quality — 2274 words
- **🤖 TalAI - Master Superprompt & AI Orchestration** (`ai-research-platform.md`) — Quality — 565 words
- **AI Workflow Orchestrator** (`ai-workflow-orchestrator.md`) — Specialized — 290 words
- **Amazon Q Context Orchestrator** (`amazonq-context-orchestrator.md`) — Quality — 329 words
- **Amazon Q Enterprise Workflows** (`amazonq-enterprise-workflows.md`) — Quality — 235 words
- **Amazon Q Intelligent Task Router** (`amazonq-intelligent-task-router.md`) — Quality — 276 words
- **Amazon Q Master Orchestrator** (`amazonq-master-orchestrator.md`) — Quality — 454 words
- **Amazon Q Multi-Agent Coordinator** (`amazonq-multi-agent-coordinator.md`) — Quality — 215 words
- **Amazon Q Quality Orchestrator** (`amazonq-quality-orchestrator.md`) — Quality — 360 words
- **Amazon Q Internal System Configuration** (`amazonq-system-configuration.md`) — Quality — 445 words
- **Amazon Q Workflow Orchestrator** (`amazonq-workflow-orchestrator.md`) — Quality — 189 words
- **API Development & Integration Standards** (`api-design-development.md`) — Quality — 620 words
- **API Design Optimizer** (`api-design-optimizer.md`) — Quality — 179 words
- **API Documentation Generator** (`api-documentation.md`) — Quality — 213 words
- **Gating & Approval Workflows Superprompt** (`approval-gating-system.md`) — Quality — 1504 words
- **Amazon Q Architecture Review** (`architecture-review.md`) — Quality — 131 words
- **Architecture Validation Engine** (`architecture-validation.md`) — Quality — 305 words
- **Amazon Q Auto-Discovery & Learning System** (`auto-discovery-system.md`) — Quality — 203 words
- **Test Generation and Coverage Analysis** (`automated-test-generation.md`) — Quality — 758 words
- **Brainstorming prompt for automation** (`brainstorming-facilitation.md`) — Quality — 12702 words
- **Catalyst Multi-Agent Orchestration** (`catalyst-orchestration.md`) — Quality — 179 words
- **Chain-of-Thought Meta-Prompt** (`chain-of-thought-reasoning.md`) — Quality — 297 words
- **CI/CD Pipeline Superprompt** (`cicd-pipeline-setup.md`) — Quality — 1331 words
- **Instructions for Claude Opus: Repository Consolidation** (`claude-opus-configuration.md`) — Quality — 879 words
- **Cloud Architecture Optimizer** (`cloud-architecture-optimizer.md`) — Quality — 175 words
- **Code Documentation Generator** (`code-documentation.md`) — Quality — 197 words
- **Evaluator System Prompt** (`code-evaluation.md`) — Quality — 477 words
- **Amazon Q Enterprise Code Review** (`code-review-enterprise.md`) — Quality — 160 words
- **Code Review Orchestrator** (`code-review-orchestrator.md`) — Quality — 187 words
- **Repository Organization & Cleanup Master Prompt** (`codebase-cleanup.md`) — Quality — 2459 words
- **Consistency Enforcement Engine** (`consistency-enforcement.md`) — Quality — 247 words
- **Constitutional Self-Alignment Prompt** (`constitutional-ai-alignment.md`) — Quality — 288 words
- **Context Bridge** (`context-bridge.md`) — Quality — 179 words
- **Context Engineering Prompt** (`context-engineering.md`) — Documentation — 317 words
- **🚀 CRAZY IDEAS MASTER PROMPT - Ready-to-Deploy Project Repository Generator** (`creative-ideation.md`) — Quality — 8216 words
- **Data Pipeline Architect** (`data-pipeline-architect.md`) — Quality — 178 words
- **Data Engineering Pipeline Framework** (`data-pipeline-engineering.md`) — Quality — 844 words
- **Database Optimizer** (`database-optimizer.md`) — Quality — 163 words
- **Debugger System Prompt** (`debugger.md`) — Quality — 587 words
- **Dependency Management Optimizer** (`dependency-management.md`) — Quality — 220 words
- **Dependency Security Audit** (`dependency-security-audit.md`) — Quality — 137 words
- **Amazon Q Orchestration Deployment** (`deployment-status.md`) — Quality — 252 words
- **DevOps Pipeline Optimizer** (`devops-pipeline-optimizer.md`) — Quality — 172 words
- **Documentation Generator** (`documentation-generator.md`) — Specialized — 138 words
- **Librex.Dual Implementation Superprompt** (`dual-problem-optimization.md`) — Quality — 2098 words
- **E-Commerce Platform Development - Complete Phased Approach** (`ecommerce-development-phases.md`) — Quality — 1591 words
- **Enterprise Agentic AI Architecture Superprompt** (`enterprise-ai-agents.md`) — Quality — 3002 words
- **Enterprise Repository Audit** (`enterprise-repo-audit.md`) — Quality — 169 words
- **Enterprise Workflow Automation** (`enterprise-workflow-automation.md`) — Quality — 392 words
- **Environment Configuration Manager** (`environment-config.md`) — Quality — 208 words
- **Librex.Evo Implementation Superprompt** (`evolutionary-optimization.md`) — Quality — 1858 words
- **🤖 Repz - Master Superprompt & AI Orchestration** (`fitness-platform-development.md`) — Quality — 554 words
- **Librex.Flow Implementation Superprompt** (`flow-optimization.md`) — Quality — 2501 words
- **Framework Optimization Engine** (`framework-optimization.md`) — Quality — 254 words
- **Frontend Optimizer** (`frontend-optimizer.md`) — Quality — 175 words
- **Lovable Template Generation Strategy** (`fullstack-saas-template.md`) — Quality — 7206 words
- **Git Workflow Optimizer** (`git-workflow-optimizer.md`) — Quality — 163 words
- **Governance & Compliance Superprompt** (`governance-compliance.md`) — Quality — 1870 words
- **GPU Optimization Superprompt** (`gpu-optimization.md`) — Quality — 365 words
- **Librex.Graph Implementation Superprompt** (`graph-optimization.md`) — Specialized — 1816 words
- **Healthcare Platform Development - Complete Phased Approach** (`healthcare-development-phases.md`) — Quality — 1398 words
- **IDE Integration Framework** (`ide-integration-framework.md`) — Quality — 652 words
- **Phase 1: Infrastructure Consolidation** (`infrastructure-setup-phase.md`) — Quality — 465 words
- **Amazon Q Integration Examples** (`integration-examples.md`) — Quality — 533 words
- **Intelligent Agent Registry** (`intelligent-agent-registry.md`) — Quality — 455 words
- **Educational Platform (LMS) Development - Complete Phased Approach** (`lms-development-phases.md`) — Quality — 1423 words
- **🎯 LOCAL AI/ML/LLM ORCHESTRATION SUPERPROMPT** (`local-ai-orchestration.md`) — Quality — 1604 words
- **🤖 Mag-Logic - Master Superprompt & AI Orchestration** (`magnetic-simulation-system.md`) — Quality — 196 words
- **Documentation Maintenance Orchestrator** (`maintenance-orchestrator.md`) — Quality — 207 words
- **Master AI Development Orchestrator** (`master-ai-development-orchestrator.md`) — Quality — 914 words
- **Mathematical Research Acceleration** (`mathematical-research.md`) — Quality — 186 words
- **Librex.Meta Implementation Superprompt** (`meta-optimization.md`) — Quality — 3979 words
- **Microservices Architect** (`microservices-architect.md`) — Specialized — 171 words
- **ML Model Optimizer** (`ml-model-optimizer.md`) — Quality — 169 words
- **ML/AI Pipeline Development Framework** (`ml-pipeline-design.md`) — Quality — 555 words
- **Mobile App Optimizer** (`mobile-app-optimizer.md`) — Quality — 175 words
- **Modernization Engine** (`modernization-engine.md`) — Quality — 232 words
- **Monorepo & Architecture Superprompt** (`monorepo-architecture.md`) — Quality — 1453 words
- **Crew Manager System Prompt** (`multi-agent-coordination.md`) — Quality — 440 words
- **Multi-Agent Development Coordinator** (`multi-agent-development-coordinator.md`) — Quality — 372 words
- **Multi-Hop RAG Query Processing** (`multi-hop-rag.md`) — Quality — 779 words
- **Amazon Q Orchestration - Next Phase** (`next-phase-roadmap.md`) — Quality — 258 words
- **Notebook Polish** (`notebook-polish.md`) — Quality — 166 words
- **Optilibria Optimization Framework Prompt** (`optilibria-optimization.md`) — Quality — 300 words
- **🤖 Librex - Master Superprompt & AI Orchestration** (`optimization-algorithms-library.md`) — Quality — 546 words
- **🤖 MEZAN - Master Superprompt & AI Orchestration** (`optimization-framework.md`) — Quality — 550 words
- **Performance Optimizer** (`performance-optimizer.md`) — Quality — 162 words
- **Physics Code Review Prompt** (`physics-code-review.md`) — Quality — 201 words
- **SimCore Claude Code Superprompt** (`physics-simulation-engine.md`) — Quality — 1335 words
- **Platform & Deployment Superprompt** (`platform-deployment.md`) — Quality — 1695 words
- **Pull Request Analysis** (`pr-analysis.md`) — Quality — 205 words
- **Project Organization Architect** (`project-organization.md`) — Quality — 257 words
- **Project Setup Orchestrator** (`project-setup.md`) — Quality — 213 words
- **🎯 Universal Prompt Optimizer** (`prompt-engineering-optimizer.md`) — Quality — 4057 words
- **Prompt Index** (`prompt-index.md`) — Quality — 166 words
- **Prompt Optimization Superprompt** (`prompt-optimization.md`) — Quality — 1733 words
- **🎯 Universal Prompt Optimizer** (`prompt-refinement.md`) — Quality — 4057 words
- **QAP Optimization Specialist** (`qap-optimization.md`) — Quality — 183 words
- **Librex.QAP Implementation Superprompt** (`quadratic-assignment-problem.md`) — Quality — 3248 words
- **Quantum Algorithm Development** (`quantum-algorithm-dev.md`) — Quality — 158 words
- **Quantum Backend Integration Expert** (`quantum-backend-integration.md`) — Specialized — 191 words
- **🤖 SPIN-CIRC - Master Superprompt & AI Orchestration** (`quantum-circuit-simulator.md`) — Quality — 195 words
- **🤖 QMAT-Sim - Master Superprompt & AI Orchestration** (`quantum-materials-simulation.md`) — Orchestrators — 199 words
- **🤖 QUBE-ML - Master Superprompt & AI Orchestration** (`quantum-ml-framework.md`) — Quality — 203 words
- **Quantum Proof Verification Expert** (`quantum-proof-verification.md`) — Specialized — 154 words
- **Amazon Q Prompts - Quick Reference** (`quick-reference.md`) — Quality — 440 words
- **Refactor Modernize** (`refactor-modernize.md`) — Quality — 160 words
- **Refactoring Orchestrator** (`refactoring-orchestrator.md`) — Quality — 233 words
- **Repository Health Assessment** (`repo-health-assessment.md`) — Quality — 192 words
- **Repository Consolidation Master Prompt** (`repository-consolidation-master.md`) — Quality — 878 words
- **KILO Consolidation Methodology Superprompt** (`repository-consolidation.md`) — Quality — 2217 words
- **Router System Prompt** (`request-routing.md`) — Quality — 433 words
- **Librex.Alloc Implementation Superprompt** (`resource-allocation-optimization.md`) — Quality — 1966 words
- **SaaS Platform Development - Complete Phased Approach** (`saas-development-phases.md`) — Quality — 1435 words
- **🤖 SCI-COMP - Master Superprompt & AI Orchestration** (`scientific-computing-library.md`) — Quality — 193 words
- **Security Audit Comprehensive** (`security-audit-comprehensive.md`) — Quality — 176 words
- **Security & Cybersecurity Superprompt** (`security-implementation.md`) — Quality — 1963 words
- **Session Summary: AI Automation Enhancement (Nov 30, 2024)** (`session-summary-template.md`) — Quality — 921 words
- **Social Media Platform Development - Complete Phased Approach** (`social-media-development-phases.md`) — Quality — 1367 words
- **Naming Standards Architect** (`standards-architect.md`) — Quality — 254 words
- **System Architecture & Integration** (`system-architecture.md`) — Quality — 192 words
- **Task Decomposition Engine** (`task-decomposition.md`) — Quality — 192 words
- **Technical Debt Reduction Specialist** (`technical-debt-reduction.md`) — Quality — 253 words
- **Write Comprehensive Tests For Rest** (`test-api-testing.md`) — Quality — 199 words
- **Test Coverage Analysis Engine** (`test-coverage-analysis.md`) — Quality — 242 words
- **Test Generation Engine** (`test-generation.md`) — Quality — 254 words
- **Test Generator** (`test-generator.md`) — Quality — 169 words
- **Optimize Memory Usage In Python Application** (`test-memory-optimization.md`) — Quality — 187 words
- **Testing & Quality Assurance Superprompt** (`testing-qa-strategy.md`) — Quality — 1308 words
- **Testing Strategy Architect** (`testing-strategy.md`) — Quality — 247 words
- **Phase 2: Tooling Consolidation** (`tooling-setup-phase.md`) — Quality — 406 words
- **TypeScript Automation CLI - Implementation Status** (`typescript-automation.md`) — Quality — 528 words
- **UI/UX Design Superprompt** (`ui-ux-design.md`) — Quality — 1869 words
- **Amazon Q Usage Automation** (`usage-automation.md`) — Quality — 234 words
- **Technology Stack Validator** (`validation.md`) — Quality — 247 words
- **Orchestrator System Prompt** (`workflow-orchestration.md`) — Quality — 479 words
- **Compositional Workflow Orchestrator** (`workflow-orchestrator.md`) — Quality — 202 words
- **Amazon Q Workflow Validation** (`workflow-validation.md`) — Quality — 331 words
- **50 Workspace Analysis Prompts** (`workspace-analysis-50.md`) — Quality — 1152 words

---

## IDE Sync Status

**Amazon Q Prompts:** 149
**Sync Status:**
- ✅ Amazon Q (Cursor/VSCode/Kiro): 149 prompts
- ⚠️ Claude Code: Not synced (different prompt system)

**Sync Method:** Prompts are stored in `~/.aws/amazonq/prompts/` and automatically available across Amazon Q-enabled IDEs (Cursor, VSCode with Q extension, Kiro).

---

## Recommendations

### Integration with Unified Registry

1. Add 149 prompts to UNIFIED_REGISTRY.json as type: 'prompt'
2. Include metadata: category, word_count, sections
3. Track sync status across IDEs

### Quality Improvements

- Standardize prompt format (title, description, sections)
- Add usage examples to each prompt
- Create prompt templates for common patterns
- Document trigger keywords for IDE integration

### Consolidation

- Review prompts in same category for duplication
- Merge similar prompts with overlapping functionality
- Archive unused or outdated prompts

---

**Registry Complete**
**Output:** `PROMPT_REGISTRY.md`
**Next Step:** Integrate with unified component registry
