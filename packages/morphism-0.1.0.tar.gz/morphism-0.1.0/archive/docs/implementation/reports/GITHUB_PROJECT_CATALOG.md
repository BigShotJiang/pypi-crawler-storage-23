# Complete GitHub Project Catalog

**Comprehensive, Consolidated Repository Catalog**

**Generated:** 2026-02-11 15:38:07 UTC

**Priority Order:** alaweimm90-* repositories (archive, business, science, testing, tools) → alawein-* repositories (personal, test) → AlaweinOS → MeatheadPhysicist → meshal-alawein → morphism-systems

**Note:** Earlier versions from alaweimm90-* organizations represent the original conceptual framework and are prioritized as more conceptually complete than later versions.

---

## 📊 Executive Summary

| Metric | Count |
|--------|-------|
| **Total Repositories** | **176** |
| **Organizations** | **11** |
| **Public Repos** | 10 |
| **Private Repos** | 166 |
| **Archived** | 58 |
| **Forks** | 0 |
| **Original Projects** | 176 |
| **Duplicates Consolidated** | 13 |

---

## 🏢 Organizations Overview

| Organization | Repositories | Public | Private | Archived |
|--------------|--------------|--------|---------|----------|
| **alaweimm90-archieve** | 56 | 6 | 50 | 27 |
| **alaweimm90-business** | 3 | 0 | 3 | 0 |
| **alaweimm90-science** | 1 | 0 | 1 | 0 |
| **alaweimm90-testing** | 10 | 0 | 10 | 0 |
| **alaweimm90-tools** | 1 | 0 | 1 | 0 |
| **alawein-personal** | 15 | 0 | 15 | 0 |
| **alawein-test** | 20 | 1 | 19 | 0 |
| **AlaweinOS** | 4 | 1 | 3 | 0 |
| **MeatheadPhysicist** | 0 | 0 | 0 | 0 |
| **meshal-alawein** | 64 | 1 | 63 | 31 |
| **morphism-systems** | 2 | 1 | 1 | 0 |

---

## 🔄 Consolidated Projects

**13 project(s)** had multiple versions across organizations. The version from the earliest priority organization is kept as primary.

- **alaweimm90-archieve/repz--** ← consolidated from: alaweimm90-archieve/REPZ-, alaweimm90-archieve/REPZ, alawein-personal/repz
- **alaweimm90-archieve/Attributa** ← consolidated from: alawein-test/attributa
- **alaweimm90-archieve/HELIOS** ← consolidated from: alawein-test/helios
- **alaweimm90-archieve/LLMWorks** ← consolidated from: alawein-test/llmworks
- **alaweimm90-archieve/Optilibria-** ← consolidated from: alaweimm90-archieve/optilibria, AlaweinOS/Optilibria
- **alaweimm90-archieve/LiveItIconic-** ← consolidated from: alaweimm90-archieve/live-it-iconic, alaweimm90-archieve/LiveItIconic, alawein-test/liveiticonic
- **alaweimm90-archieve/SimCore** ← consolidated from: alawein-test/simcore
- **alaweimm90-archieve/Portfolio** ← consolidated from: alawein-test/portfolio
- **alaweimm90-archieve/QMLab** ← consolidated from: alawein-test/qmlab
- **alaweimm90-testing/TalAI** ← consolidated from: alawein-test/tal-ai, AlaweinOS/Talai
- **alawein-test/morphism-web** ← consolidated from: alawein-test/morphism-web-
- **alawein-test/meathead-physicist** ← consolidated from: MeatheadPhysicist/MeatheadPhysicist
- **alawein-test/legal-cases** ← consolidated from: alawein-test/legalcases

---

## 📚 Complete Repository Catalog

### alaweimm90-archieve

**Total: 56 repositories**

#### benchbarrier

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/benchbarrier` |
| **URL** | https://github.com/alaweimm90-archieve/benchbarrier |
| **Visibility** | PUBLIC |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-13 |
| **Last Push** | 2026-02-09 |
| **Homepage** | https://benchbarrier.vercel.app |
| **License** | None |

#### evidentia

**Description:** Automate legal evidence submission to government agencies and courts

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/evidentia` |
| **URL** | https://github.com/alaweimm90-archieve/evidentia |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-13 |
| **Last Push** | 2026-01-31 |
| **License** | None |

#### ai-development-platf

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/ai-development-platf` |
| **URL** | https://github.com/alaweimm90-archieve/ai-development-platf |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |

#### tidal-fresh-beachy-c

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/tidal-fresh-beachy-c` |
| **URL** | https://github.com/alaweimm90-archieve/tidal-fresh-beachy-c |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-08 |
| **License** | MIT License |

#### organizations

**Description:** Consolidated organizational repositories

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/organizations` |
| **URL** | https://github.com/alaweimm90-archieve/organizations |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-20 |
| **Last Push** | 2025-12-19 |
| **License** | Other |

#### repz--

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/repz--` |
| **URL** | https://github.com/alaweimm90-archieve/repz-- |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-12-09 |
| **Last Push** | 2025-12-19 |
| **Homepage** | https://repz-app-alawein-team.vercel.app |
| **License** | None |
| **Duplicates** | `alaweimm90-archieve/REPZ-`, `alaweimm90-archieve/REPZ`, `alawein-personal/repz` |

#### meshal-website

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/meshal-website` |
| **URL** | https://github.com/alaweimm90-archieve/meshal-website |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-13 |
| **Last Push** | 2025-12-19 |
| **License** | None |

#### rounaq

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/rounaq` |
| **URL** | https://github.com/alaweimm90-archieve/rounaq |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-13 |
| **Last Push** | 2025-12-19 |
| **License** | None |

#### peptides-platform

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/peptides-platform` |
| **URL** | https://github.com/alaweimm90-archieve/peptides-platform |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-17 |
| **Last Push** | 2025-12-18 |
| **License** | MIT License |

#### repzapp

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/repzapp` |
| **URL** | https://github.com/alaweimm90-archieve/repzapp |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-16 |
| **Last Push** | 2025-12-18 |
| **License** | None |

#### .archive

**Description:** Archived historical projects

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/.archive` |
| **URL** | https://github.com/alaweimm90-archieve/.archive |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-20 |
| **Last Push** | 2025-12-16 |
| **License** | None |

#### Attributa

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/Attributa` |
| **URL** | https://github.com/alaweimm90-archieve/Attributa |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-12-15 |
| **License** | MIT License |
| **Duplicates** | `alawein-test/attributa` |

#### backups

**Description:** Centralized backup repository for all projects and releases

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/backups` |
| **URL** | https://github.com/alaweimm90-archieve/backups |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-12 |
| **Last Push** | 2025-12-12 |
| **License** | None |

#### demo-repository

**Description:** A code repository designed to show the best GitHub has to offer.

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/demo-repository` |
| **URL** | https://github.com/alaweimm90-archieve/demo-repository |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-19 |
| **Last Push** | 2025-11-20 |
| **License** | None |

#### 1-BACKUP-NO-TOUCH

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/1-BACKUP-NO-TOUCH` |
| **URL** | https://github.com/alaweimm90-archieve/1-BACKUP-NO-TOUCH |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-06 |
| **Last Push** | 2025-11-20 |
| **License** | None |

#### 2-CLAUDE-CODE

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/2-CLAUDE-CODE` |
| **URL** | https://github.com/alaweimm90-archieve/2-CLAUDE-CODE |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-06 |
| **Last Push** | 2025-11-19 |
| **License** | None |

#### HELIOS

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/HELIOS` |
| **URL** | https://github.com/alaweimm90-archieve/HELIOS |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-05 |
| **Last Push** | 2025-11-19 |
| **License** | MIT License |
| **Duplicates** | `alawein-test/helios` |

#### LLMWorks

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/LLMWorks` |
| **URL** | https://github.com/alaweimm90-archieve/LLMWorks |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-11 |
| **Last Push** | 2025-11-19 |
| **License** | None |
| **Duplicates** | `alawein-test/llmworks` |

#### CrazyIdeas

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/CrazyIdeas` |
| **URL** | https://github.com/alaweimm90-archieve/CrazyIdeas |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-09 |
| **Last Push** | 2025-11-19 |
| **License** | None |

#### alaweimm90-archieve

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/alaweimm90-archieve` |
| **URL** | https://github.com/alaweimm90-archieve/alaweimm90-archieve |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-18 |
| **Last Push** | 2025-11-18 |
| **License** | MIT License |

#### SciComp-edu

**Description:** Scientific computing educational tools

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/SciComp-edu` |
| **URL** | https://github.com/alaweimm90-archieve/SciComp-edu |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-14 |
| **Last Push** | 2025-11-14 |
| **License** | MIT License |

#### SpinCirc-science

**Description:** Spin circuit simulation library

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/SpinCirc-science` |
| **URL** | https://github.com/alaweimm90-archieve/SpinCirc-science |
| **Visibility** | PRIVATE |
| **Language** | MATLAB |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-14 |
| **Last Push** | 2025-11-14 |
| **License** | MIT License |

#### QubeML-science

**Description:** Quantum machine learning toolkit

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QubeML-science` |
| **URL** | https://github.com/alaweimm90-archieve/QubeML-science |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-14 |
| **Last Push** | 2025-11-14 |
| **License** | MIT License |

#### QMatSim-science

**Description:** Quantum materials simulation framework

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QMatSim-science` |
| **URL** | https://github.com/alaweimm90-archieve/QMatSim-science |
| **Visibility** | PRIVATE |
| **Language** | Shell |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-14 |
| **Last Push** | 2025-11-14 |
| **License** | Other |

#### MagLogic-science

**Description:** Magnetic logic simulation research library

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/MagLogic-science` |
| **URL** | https://github.com/alaweimm90-archieve/MagLogic-science |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-14 |
| **Last Push** | 2025-11-14 |
| **License** | Other |

#### Optilibria-

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/Optilibria-` |
| **URL** | https://github.com/alaweimm90-archieve/Optilibria- |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-09 |
| **Last Push** | 2025-11-13 |
| **License** | Other |
| **Duplicates** | `alaweimm90-archieve/optilibria`, `AlaweinOS/Optilibria` |

#### LiveItIconic-

**Description:** LiveItIconic organization repository

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/LiveItIconic-` |
| **URL** | https://github.com/alaweimm90-archieve/LiveItIconic- |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-08 |
| **Last Push** | 2025-11-13 |
| **License** | MIT License |
| **Duplicates** | `alaweimm90-archieve/live-it-iconic`, `alaweimm90-archieve/LiveItIconic`, `alawein-test/liveiticonic` |

#### Prompty

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/Prompty` |
| **URL** | https://github.com/alaweimm90-archieve/Prompty |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-11 |
| **Last Push** | 2025-11-11 |
| **License** | None |

#### alaweimm90

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/alaweimm90` |
| **URL** | https://github.com/alaweimm90-archieve/alaweimm90 |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-05 |
| **Last Push** | 2025-11-07 |
| **License** | None |

#### QAP-CLAUDE-CODE 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-CLAUDE-CODE` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-CLAUDE-CODE |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-06 |
| **Last Push** | 2025-11-06 |
| **License** | MIT License |

#### live-it-iconic-e3e1196b 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/live-it-iconic-e3e1196b` |
| **URL** | https://github.com/alaweimm90-archieve/live-it-iconic-e3e1196b |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-06 |
| **Last Push** | 2025-11-06 |
| **License** | MIT License |

#### GitHub 🗄️ **ARCHIVED**

**Description:** Multi-project infrastructure and governance system

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/GitHub` |
| **URL** | https://github.com/alaweimm90-archieve/GitHub |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-05 |
| **Last Push** | 2025-11-06 |
| **License** | MIT License |

#### dev-infrastructure 🗄️ **ARCHIVED**

**Description:** Shared development infrastructure: CLI tools, git hooks, templates, and configurations for all projects

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/dev-infrastructure` |
| **URL** | https://github.com/alaweimm90-archieve/dev-infrastructure |
| **Visibility** | PRIVATE |
| **Language** | Shell |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-05 |
| **Last Push** | 2025-11-05 |
| **License** | MIT License |

#### SimCore 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/SimCore` |
| **URL** | https://github.com/alaweimm90-archieve/SimCore |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-07-22 |
| **Last Push** | 2025-10-31 |
| **License** | None |
| **Duplicates** | `alawein-test/simcore` |

#### Portfolio 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/Portfolio` |
| **URL** | https://github.com/alaweimm90-archieve/Portfolio |
| **Visibility** | PRIVATE |
| **Language** | JavaScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-07-25 |
| **Last Push** | 2025-10-31 |
| **License** | Other |
| **Duplicates** | `alawein-test/portfolio` |

#### QMLab 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QMLab` |
| **URL** | https://github.com/alaweimm90-archieve/QMLab |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-11 |
| **Last Push** | 2025-10-31 |
| **License** | MIT License |
| **Duplicates** | `alawein-test/qmlab` |

#### .meta 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/.meta` |
| **URL** | https://github.com/alaweimm90-archieve/.meta |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-29 |
| **Last Push** | 2025-10-29 |
| **License** | None |

#### QAPlibria 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAPlibria` |
| **URL** | https://github.com/alaweimm90-archieve/QAPlibria |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-05 |
| **Last Push** | 2025-10-29 |
| **License** | MIT License |

#### QAP-UNIFIED 🗄️ **ARCHIVED**

**Description:** Quantum Assignment Problem Solver with 24/7 Autonomous Multi-Agent System

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-UNIFIED` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-UNIFIED |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-24 |
| **Last Push** | 2025-10-25 |
| **License** | None |

#### QAP-QUICK-Deploy 🗄️ **ARCHIVED**

**Description:** 24/7 Autonomous QAP Discovery System

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-QUICK-Deploy` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-QUICK-Deploy |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-23 |
| **Last Push** | 2025-10-25 |
| **License** | None |

#### QAP_modular_repo 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP_modular_repo` |
| **URL** | https://github.com/alaweimm90-archieve/QAP_modular_repo |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-21 |
| **Last Push** | 2025-10-21 |
| **License** | None |

#### QAP-1 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-1` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-1 |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-15 |
| **Last Push** | 2025-10-16 |
| **License** | MIT License |

#### QAP-2 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-2` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-2 |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-15 |
| **Last Push** | 2025-10-16 |
| **License** | MIT License |

#### QAP-3 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP-3` |
| **URL** | https://github.com/alaweimm90-archieve/QAP-3 |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-15 |
| **Last Push** | 2025-10-16 |
| **License** | None |

#### 14-Attractor-Programming 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/14-Attractor-Programming` |
| **URL** | https://github.com/alaweimm90-archieve/14-Attractor-Programming |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-02 |
| **Last Push** | 2025-10-15 |
| **License** | MIT License |

#### QAP 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QAP` |
| **URL** | https://github.com/alaweimm90-archieve/QAP |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-10-15 |
| **Last Push** | 2025-10-15 |
| **License** | None |

#### SpinCirc 🗄️ **ARCHIVED**

**Description:** MATLAB/Cadence-based scalable stochastic simulator for modeling multistate spin-based logic and device architectures with SPICE-compatible integration

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/SpinCirc` |
| **URL** | https://github.com/alaweimm90-archieve/SpinCirc |
| **Visibility** | PUBLIC |
| **Language** | MATLAB |
| **Stars** | 2 |
| **Forks** | 1 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-08-12 |
| **License** | MIT License |

#### SciComp 🗄️ **ARCHIVED**

**Description:** Cross-platform scientific computing framework for quantum physics, materials science, physics-informed ML, and more...

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/SciComp` |
| **URL** | https://github.com/alaweimm90-archieve/SciComp |
| **Visibility** | PUBLIC |
| **Language** | Python |
| **Stars** | 2 |
| **Forks** | 0 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-08-12 |
| **License** | MIT License |

#### MagLogic 🗄️ **ARCHIVED**

**Description:** OOMMF/MuMax3-based scalable micromagnetic simulation suite for reconfigurable spintronic logic and multistate device analysis

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/MagLogic` |
| **URL** | https://github.com/alaweimm90-archieve/MagLogic |
| **Visibility** | PUBLIC |
| **Language** | Python |
| **Stars** | 2 |
| **Forks** | 0 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-08-12 |
| **License** | Other |

#### QMatSim 🗄️ **ARCHIVED**

**Description:** Modular Multiscale Framework for DFT and MD Integration with SIESTA + LAMMPS

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QMatSim` |
| **URL** | https://github.com/alaweimm90-archieve/QMatSim |
| **Visibility** | PUBLIC |
| **Language** | Shell |
| **Stars** | 2 |
| **Forks** | 1 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-08-12 |
| **License** | Other |

#### QubeML 🗄️ **ARCHIVED**

**Description:** Educational framework for quantum computing and materials informatics using Python, Jupyter, and Colab.

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/QubeML` |
| **URL** | https://github.com/alaweimm90-archieve/QubeML |
| **Visibility** | PUBLIC |
| **Language** | Jupyter Notebook |
| **Stars** | 2 |
| **Forks** | 0 |
| **Created** | 2025-08-08 |
| **Last Push** | 2025-08-12 |
| **License** | MIT License |

#### Zotero-Sage 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/Zotero-Sage` |
| **URL** | https://github.com/alaweimm90-archieve/Zotero-Sage |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-12 |
| **Last Push** | 2025-08-12 |
| **License** | None |

#### CiteGuard 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/CiteGuard` |
| **URL** | https://github.com/alaweimm90-archieve/CiteGuard |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-11 |
| **Last Push** | 2025-08-12 |
| **License** | None |

#### PromptForge 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/PromptForge` |
| **URL** | https://github.com/alaweimm90-archieve/PromptForge |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-12 |
| **Last Push** | 2025-08-12 |
| **License** | None |

#### CodebaseCartographer 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/CodebaseCartographer` |
| **URL** | https://github.com/alaweimm90-archieve/CodebaseCartographer |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-08-12 |
| **Last Push** | 2025-08-12 |
| **License** | None |

#### sample-codes 🗄️ **ARCHIVED**

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-archieve/sample-codes` |
| **URL** | https://github.com/alaweimm90-archieve/sample-codes |
| **Visibility** | PRIVATE |
| **Language** | Jupyter Notebook |
| **Stars** | 1 |
| **Forks** | 0 |
| **Created** | 2025-05-02 |
| **Last Push** | 2025-05-28 |
| **License** | None |

---

### alaweimm90-business

**Total: 3 repositories**

#### monorepo

**Description:** Business and enterprise projects - Consolidated monorepo

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-business/monorepo` |
| **URL** | https://github.com/alaweimm90-business/monorepo |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-27 |
| **Last Push** | 2025-11-27 |
| **License** | MIT License |

#### alaweimm90-business

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-business/alaweimm90-business` |
| **URL** | https://github.com/alaweimm90-business/alaweimm90-business |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-09 |
| **Last Push** | 2025-11-20 |
| **License** | MIT License |

#### .github

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-business/.github` |
| **URL** | https://github.com/alaweimm90-business/.github |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-13 |
| **Last Push** | 2025-11-17 |
| **License** | None |

---

### alaweimm90-science

**Total: 1 repositories**

#### alaweimm90-science

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-science/alaweimm90-science` |
| **URL** | https://github.com/alaweimm90-science/alaweimm90-science |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-09 |
| **Last Push** | 2025-11-18 |
| **License** | MIT License |

---

### alaweimm90-testing

**Total: 10 repositories**

#### coaching-app-2

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/coaching-app-2` |
| **URL** | https://github.com/alaweimm90-testing/coaching-app-2 |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-09 |
| **Last Push** | 2026-02-02 |
| **License** | None |

#### spark-projects

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/spark-projects` |
| **URL** | https://github.com/alaweimm90-testing/spark-projects |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-19 |
| **Last Push** | 2025-12-20 |
| **License** | None |

#### spark-projects-quantum

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/spark-projects-quantum` |
| **URL** | https://github.com/alaweimm90-testing/spark-projects-quantum |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2025-12-18 |
| **License** | None |

#### backup-coaching-app-1

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/backup-coaching-app-1` |
| **URL** | https://github.com/alaweimm90-testing/backup-coaching-app-1 |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-13 |
| **Last Push** | 2025-12-16 |
| **License** | None |

#### central-knowledge

**Description:** Knowledge Management System for Nexus Framework

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/central-knowledge` |
| **URL** | https://github.com/alaweimm90-testing/central-knowledge |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-14 |
| **Last Push** | 2025-12-14 |
| **License** | None |

#### lovable-template-guide

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/lovable-template-guide` |
| **URL** | https://github.com/alaweimm90-testing/lovable-template-guide |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-09 |
| **Last Push** | 2025-12-09 |
| **License** | None |

#### coaching

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/coaching` |
| **URL** | https://github.com/alaweimm90-testing/coaching |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-09 |
| **Last Push** | 2025-12-09 |
| **License** | None |

#### TalAI

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/TalAI` |
| **URL** | https://github.com/alaweimm90-testing/TalAI |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-06 |
| **Last Push** | 2025-12-06 |
| **License** | None |
| **Duplicates** | `alawein-test/tal-ai`, `AlaweinOS/Talai` |

#### QAP-Hub

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/QAP-Hub` |
| **URL** | https://github.com/alaweimm90-testing/QAP-Hub |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-06 |
| **Last Push** | 2025-12-06 |
| **License** | None |

#### alaweimm90-testing

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-testing/alaweimm90-testing` |
| **URL** | https://github.com/alaweimm90-testing/alaweimm90-testing |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-18 |
| **Last Push** | 2025-11-18 |
| **License** | MIT License |

---

### alaweimm90-tools

**Total: 1 repositories**

#### alaweimm90-tools

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alaweimm90-tools/alaweimm90-tools` |
| **URL** | https://github.com/alaweimm90-tools/alaweimm90-tools |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-09 |
| **Last Push** | 2025-11-19 |
| **License** | MIT License |

---

### alawein-personal

**Total: 15 repositories**

#### legal-cases-automation

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/legal-cases-automation` |
| **URL** | https://github.com/alawein-personal/legal-cases-automation |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-29 |
| **Last Push** | 2026-02-09 |
| **License** | None |

#### legal-unified

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/legal-unified` |
| **URL** | https://github.com/alawein-personal/legal-unified |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-11 |
| **Last Push** | 2026-02-09 |
| **License** | None |

#### botocre

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/botocre` |
| **URL** | https://github.com/alawein-personal/botocre |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-03 |
| **Last Push** | 2026-01-25 |
| **Homepage** | https://benchbarrier.vercel.app |
| **License** | None |

#### gainboy

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/gainboy` |
| **URL** | https://github.com/alawein-personal/gainboy |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-13 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### riom

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/riom` |
| **URL** | https://github.com/alawein-personal/riom |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-13 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### scribd-fit

**Description:** Scribd Fit - Fitness Equipment E-commerce Platform

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/scribd-fit` |
| **URL** | https://github.com/alawein-personal/scribd-fit |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-09 |
| **Last Push** | 2026-01-13 |
| **License** | None |

#### tensorai

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/tensorai` |
| **URL** | https://github.com/alawein-personal/tensorai |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-13 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### pixelsmith

**Description:** Pixel-art-arcade branch of pixelsmith

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/pixelsmith` |
| **URL** | https://github.com/alawein-personal/pixelsmith |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-09 |
| **Last Push** | 2026-01-13 |
| **License** | None |

#### sehat

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/sehat` |
| **URL** | https://github.com/alawein-personal/sehat |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-23 |
| **Last Push** | 2026-01-13 |
| **Homepage** | https://sandbox-eight-lilac.vercel.app |
| **License** | MIT License |

#### glint-app

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/glint-app` |
| **URL** | https://github.com/alawein-personal/glint-app |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-23 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### promolabs

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/promolabs` |
| **URL** | https://github.com/alawein-personal/promolabs |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### brandy

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/brandy` |
| **URL** | https://github.com/alawein-personal/brandy |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### bwiz

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/bwiz` |
| **URL** | https://github.com/alawein-personal/bwiz |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### brandos

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/brandos` |
| **URL** | https://github.com/alawein-personal/brandos |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

#### atelier-rounaq

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-personal/atelier-rounaq` |
| **URL** | https://github.com/alawein-personal/atelier-rounaq |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-18 |
| **Last Push** | 2026-01-13 |
| **License** | MIT License |

---

### alawein-test

**Total: 20 repositories**

#### the-circus

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/the-circus` |
| **URL** | https://github.com/alawein-test/the-circus |
| **Visibility** | PRIVATE |
| **Language** | JavaScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-16 |
| **Last Push** | 2026-02-02 |
| **License** | MIT License |

#### agentic-formal

**Description:** Agentic formal verification and reasoning system

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/agentic-formal` |
| **URL** | https://github.com/alawein-test/agentic-formal |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-31 |
| **Last Push** | 2026-01-31 |
| **License** | None |

#### morphism-web

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/morphism-web` |
| **URL** | https://github.com/alawein-test/morphism-web |
| **Visibility** | PUBLIC |
| **Language** | JavaScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-17 |
| **Last Push** | 2026-01-25 |
| **Homepage** | https://morphism-web-dun.vercel.app |
| **License** | None |
| **Duplicates** | `alawein-test/morphism-web-` |

#### universal-intelligence-platform

**Description:** Universal Intelligence Platform - Multi-modal AI orchestration

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/universal-intelligence-platform` |
| **URL** | https://github.com/alawein-test/universal-intelligence-platform |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-24 |
| **Last Push** | 2026-01-24 |
| **License** | None |

#### meshy-tools

**Description:** Meshy Tools - Mesh network utilities and helpers

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/meshy-tools` |
| **URL** | https://github.com/alawein-test/meshy-tools |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-24 |
| **Last Push** | 2026-01-24 |
| **License** | MIT License |

#### ingesta

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/ingesta` |
| **URL** | https://github.com/alawein-test/ingesta |
| **Visibility** | PRIVATE |
| **Language** | PowerShell |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-17 |
| **Last Push** | 2026-01-17 |
| **License** | None |

#### branding-automation-platform

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/branding-automation-platform` |
| **URL** | https://github.com/alawein-test/branding-automation-platform |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-15 |
| **License** | Other |

#### repo-standardization-tool

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/repo-standardization-tool` |
| **URL** | https://github.com/alawein-test/repo-standardization-tool |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-15 |
| **License** | Other |

#### microtask-automation-assistant

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/microtask-automation-assistant` |
| **URL** | https://github.com/alawein-test/microtask-automation-assistant |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-15 |
| **License** | MIT License |

#### quasar

**Description:** Quasar - Quantum Algorithms for Scientific and Academic Research

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/quasar` |
| **URL** | https://github.com/alawein-test/quasar |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-09 |
| **Last Push** | 2026-01-15 |
| **License** | MIT License |

#### meathead-physicist

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/meathead-physicist` |
| **URL** | https://github.com/alawein-test/meathead-physicist |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-12 |
| **License** | MIT License |
| **Duplicates** | `MeatheadPhysicist/MeatheadPhysicist` |

#### doccon

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/doccon` |
| **URL** | https://github.com/alawein-test/doccon |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |

#### bolts

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/bolts` |
| **URL** | https://github.com/alawein-test/bolts |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-03 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |

#### brainiac

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/brainiac` |
| **URL** | https://github.com/alawein-test/brainiac |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |

#### legal-cases

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/legal-cases` |
| **URL** | https://github.com/alawein-test/legal-cases |
| **Visibility** | PRIVATE |
| **Language** | CSS |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |
| **Duplicates** | `alawein-test/legalcases` |

#### eureka

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/eureka` |
| **URL** | https://github.com/alawein-test/eureka |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-09 |
| **License** | MIT License |

#### aiclairty

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/aiclairty` |
| **URL** | https://github.com/alawein-test/aiclairty |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-03 |
| **Last Push** | 2026-01-09 |
| **License** | None |

#### turing-lawcase

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/turing-lawcase` |
| **URL** | https://github.com/alawein-test/turing-lawcase |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-05 |
| **License** | MIT License |

#### ideas

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/ideas` |
| **URL** | https://github.com/alawein-test/ideas |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-05 |
| **Last Push** | 2026-01-05 |
| **License** | MIT License |

#### rounaq-atelier

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `alawein-test/rounaq-atelier` |
| **URL** | https://github.com/alawein-test/rounaq-atelier |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-01-03 |
| **Last Push** | 2026-01-03 |
| **License** | None |

---

### AlaweinOS

**Total: 4 repositories**

#### MEZAN

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `AlaweinOS/MEZAN` |
| **URL** | https://github.com/AlaweinOS/MEZAN |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-25 |
| **Last Push** | 2025-12-25 |
| **License** | None |

#### CORE

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `AlaweinOS/CORE` |
| **URL** | https://github.com/AlaweinOS/CORE |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-25 |
| **Last Push** | 2025-12-25 |
| **License** | None |

#### WizSci

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `AlaweinOS/WizSci` |
| **URL** | https://github.com/AlaweinOS/WizSci |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-12-25 |
| **Last Push** | 2025-12-25 |
| **License** | None |

#### AlaweinOS

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `AlaweinOS/AlaweinOS` |
| **URL** | https://github.com/AlaweinOS/AlaweinOS |
| **Visibility** | PUBLIC |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2025-11-17 |
| **Last Push** | 2025-11-24 |
| **License** | MIT License |

---

### meshal-alawein

**Total: 64 repositories**

#### agentic-formal-verification

**Description:** Agentic formal verification and reasoning system

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/agentic-formal-verification` |
| **URL** | https://github.com/meshal-alawein/agentic-formal-verification |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### helios-astronomy

**Description:** Helios - Solar system visualization and astronomy tools

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/helios-astronomy` |
| **URL** | https://github.com/meshal-alawein/helios-astronomy |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### event-discovery-framework

**Description:** Event discovery and analysis framework

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/event-discovery-framework` |
| **URL** | https://github.com/meshal-alawein/event-discovery-framework |
| **Visibility** | PUBLIC |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-02 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### liveiticonic-platform

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/liveiticonic-platform` |
| **URL** | https://github.com/meshal-alawein/liveiticonic-platform |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### circus-app

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/circus-app` |
| **URL** | https://github.com/meshal-alawein/circus-app |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### benchmark-barrier

**Description:** Benchmark barrier implementation for runtime monitoring

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/benchmark-barrier` |
| **URL** | https://github.com/meshal-alawein/benchmark-barrier |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-pixelsmith

**Description:** Migrated from alawein-personal/pixelsmith

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-pixelsmith` |
| **URL** | https://github.com/meshal-alawein/personal-pixelsmith |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-legal-unified

**Description:** Migrated from alawein-personal/legal-unified

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-legal-unified` |
| **URL** | https://github.com/meshal-alawein/personal-legal-unified |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### quasar-quantum

**Description:** Quasar - Quantum Algorithms for Scientific and Academic Research

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/quasar-quantum` |
| **URL** | https://github.com/meshal-alawein/quasar-quantum |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### microtask-assistant

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/microtask-assistant` |
| **URL** | https://github.com/meshal-alawein/microtask-assistant |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### ingesta-tool

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/ingesta-tool` |
| **URL** | https://github.com/meshal-alawein/ingesta-tool |
| **Visibility** | PRIVATE |
| **Language** | PowerShell |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### mesh-utilities

**Description:** Meshy Tools - Mesh network utilities and helpers

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/mesh-utilities` |
| **URL** | https://github.com/meshal-alawein/mesh-utilities |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### portfolio-site

**Description:** Portfolio - Personal portfolio and project showcase

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/portfolio-site` |
| **URL** | https://github.com/meshal-alawein/portfolio-site |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### universal-intelligence

**Description:** Universal Intelligence Platform - Multi-modal AI orchestration

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/universal-intelligence` |
| **URL** | https://github.com/meshal-alawein/universal-intelligence |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-atelier-rounaq

**Description:** Migrated from alawein-personal/atelier-rounaq

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-atelier-rounaq` |
| **URL** | https://github.com/meshal-alawein/personal-atelier-rounaq |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-brandos

**Description:** Migrated from alawein-personal/brandos

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-brandos` |
| **URL** | https://github.com/meshal-alawein/personal-brandos |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-bwiz

**Description:** Migrated from alawein-personal/bwiz

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-bwiz` |
| **URL** | https://github.com/meshal-alawein/personal-bwiz |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-brandy

**Description:** Migrated from alawein-personal/brandy

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-brandy` |
| **URL** | https://github.com/meshal-alawein/personal-brandy |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-gainboy

**Description:** Migrated from alawein-personal/gainboy

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-gainboy` |
| **URL** | https://github.com/meshal-alawein/personal-gainboy |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-glint-app

**Description:** Migrated from alawein-personal/glint-app

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-glint-app` |
| **URL** | https://github.com/meshal-alawein/personal-glint-app |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-repz

**Description:** Migrated from alawein-personal/repz

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-repz` |
| **URL** | https://github.com/meshal-alawein/personal-repz |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-riom

**Description:** Migrated from alawein-personal/riom

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-riom` |
| **URL** | https://github.com/meshal-alawein/personal-riom |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-sehat

**Description:** Migrated from alawein-personal/sehat

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-sehat` |
| **URL** | https://github.com/meshal-alawein/personal-sehat |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### branding-automation

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/branding-automation` |
| **URL** | https://github.com/meshal-alawein/branding-automation |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### personal-tensorai

**Description:** Migrated from alawein-personal/tensorai

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-tensorai` |
| **URL** | https://github.com/meshal-alawein/personal-tensorai |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-promolabs

**Description:** Migrated from alawein-personal/promolabs

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-promolabs` |
| **URL** | https://github.com/meshal-alawein/personal-promolabs |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### tal-ai-framework

**Description:** TAL-AI - Temporal Abstraction Learning with AI

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/tal-ai-framework` |
| **URL** | https://github.com/meshal-alawein/tal-ai-framework |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### legacy-llmworks 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/llmworks

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-llmworks` |
| **URL** | https://github.com/meshal-alawein/legacy-llmworks |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-meathead-physicist 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/meathead-physicist

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-meathead-physicist` |
| **URL** | https://github.com/meshal-alawein/legacy-meathead-physicist |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-repz 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/repz

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-repz` |
| **URL** | https://github.com/meshal-alawein/legacy-repz |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-simcore 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/simcore

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-simcore` |
| **URL** | https://github.com/meshal-alawein/legacy-simcore |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-qmlab 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/qmlab

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-qmlab` |
| **URL** | https://github.com/meshal-alawein/legacy-qmlab |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-tal-ai 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/tal-ai

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-tal-ai` |
| **URL** | https://github.com/meshal-alawein/legacy-tal-ai |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### legacy-repo-standardization-tool 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/repo-standardization-tool

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-repo-standardization-tool` |
| **URL** | https://github.com/meshal-alawein/legacy-repo-standardization-tool |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### legacy-morphism-web 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/morphism-web

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-morphism-web` |
| **URL** | https://github.com/meshal-alawein/legacy-morphism-web |
| **Visibility** | PRIVATE |
| **Language** | JavaScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### repo-standardizer

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/repo-standardizer` |
| **URL** | https://github.com/meshal-alawein/repo-standardizer |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### legacy-agentic-formal 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/agentic-formal

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-agentic-formal` |
| **URL** | https://github.com/meshal-alawein/legacy-agentic-formal |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-branding-automation-platform 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/branding-automation-platform

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-branding-automation-platform` |
| **URL** | https://github.com/meshal-alawein/legacy-branding-automation-platform |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | Other |

#### legacy-benchbarrier 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/benchbarrier

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-benchbarrier` |
| **URL** | https://github.com/meshal-alawein/legacy-benchbarrier |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-the-circus 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/the-circus

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-the-circus` |
| **URL** | https://github.com/meshal-alawein/legacy-the-circus |
| **Visibility** | PRIVATE |
| **Language** | JavaScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-rounaq-atelier 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/rounaq-atelier

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-rounaq-atelier` |
| **URL** | https://github.com/meshal-alawein/legacy-rounaq-atelier |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legal-tech-platform

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legal-tech-platform` |
| **URL** | https://github.com/meshal-alawein/legal-tech-platform |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-legal-cases 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/legal-cases

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-legal-cases` |
| **URL** | https://github.com/meshal-alawein/legacy-legal-cases |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-bolts 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/bolts

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-bolts` |
| **URL** | https://github.com/meshal-alawein/legacy-bolts |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-portfolio 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/portfolio

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-portfolio` |
| **URL** | https://github.com/meshal-alawein/legacy-portfolio |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-ingesta 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/ingesta

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-ingesta` |
| **URL** | https://github.com/meshal-alawein/legacy-ingesta |
| **Visibility** | PRIVATE |
| **Language** | PowerShell |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-meshal-website 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/meshal-website

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-meshal-website` |
| **URL** | https://github.com/meshal-alawein/legacy-meshal-website |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-quasar 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/quasar

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-quasar` |
| **URL** | https://github.com/meshal-alawein/legacy-quasar |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-doccon 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/doccon

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-doccon` |
| **URL** | https://github.com/meshal-alawein/legacy-doccon |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-microtask-automation-assistant 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/microtask-automation-assistant

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-microtask-automation-assistant` |
| **URL** | https://github.com/meshal-alawein/legacy-microtask-automation-assistant |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-aiclairty 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/aiclairty

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-aiclairty` |
| **URL** | https://github.com/meshal-alawein/legacy-aiclairty |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-eureka 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/eureka

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-eureka` |
| **URL** | https://github.com/meshal-alawein/legacy-eureka |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-turing-lawcase 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/turing-lawcase

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-turing-lawcase` |
| **URL** | https://github.com/meshal-alawein/legacy-turing-lawcase |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### web-platform

**Description:** Migrated from source organizations

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/web-platform` |
| **URL** | https://github.com/meshal-alawein/web-platform |
| **Visibility** | PRIVATE |
| **Language** | JavaScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-ideas 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/ideas

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-ideas` |
| **URL** | https://github.com/meshal-alawein/legacy-ideas |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-attributa 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/attributa

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-attributa` |
| **URL** | https://github.com/meshal-alawein/legacy-attributa |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-brainiac 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/brainiac

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-brainiac` |
| **URL** | https://github.com/meshal-alawein/legacy-brainiac |
| **Visibility** | PRIVATE |
| **Language** | None |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-meshy-tools 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/meshy-tools

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-meshy-tools` |
| **URL** | https://github.com/meshal-alawein/legacy-meshy-tools |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-liveiticonic 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/liveiticonic

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-liveiticonic` |
| **URL** | https://github.com/meshal-alawein/legacy-liveiticonic |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-universal-intelligence-platform 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/universal-intelligence-platform

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-universal-intelligence-platform` |
| **URL** | https://github.com/meshal-alawein/legacy-universal-intelligence-platform |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-botocre

**Description:** Migrated from alawein-personal/botocre

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-botocre` |
| **URL** | https://github.com/meshal-alawein/personal-botocre |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-legal-cases-automation

**Description:** Migrated from alawein-personal/legal-cases-automation

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-legal-cases-automation` |
| **URL** | https://github.com/meshal-alawein/personal-legal-cases-automation |
| **Visibility** | PRIVATE |
| **Language** | HTML |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### personal-scribd-fit

**Description:** Migrated from alawein-personal/scribd-fit

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/personal-scribd-fit` |
| **URL** | https://github.com/meshal-alawein/personal-scribd-fit |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### legacy-helios 🗄️ **ARCHIVED**

**Description:** Migrated from alawein-test/helios

| Property | Value |
|----------|-------|
| **Full Name** | `meshal-alawein/legacy-helios` |
| **URL** | https://github.com/meshal-alawein/legacy-helios |
| **Visibility** | PRIVATE |
| **Language** | Python |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-08 |
| **License** | MIT License |

---

### morphism-systems

**Total: 2 repositories**

#### morphism

**Description:** *No description*

| Property | Value |
|----------|-------|
| **Full Name** | `morphism-systems/morphism` |
| **URL** | https://github.com/morphism-systems/morphism |
| **Visibility** | PUBLIC |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-08 |
| **Last Push** | 2026-02-11 |
| **License** | MIT License |

#### hub

**Description:** Morphism Hub — SaaS platform

| Property | Value |
|----------|-------|
| **Full Name** | `morphism-systems/hub` |
| **URL** | https://github.com/morphism-systems/hub |
| **Visibility** | PRIVATE |
| **Language** | TypeScript |
| **Stars** | 0 |
| **Forks** | 0 |
| **Created** | 2026-02-10 |
| **Last Push** | 2026-02-10 |
| **License** | MIT License |

---

## 📝 Notes

### Priority Rationale

Repositories from **alaweimm90-*** organizations are prioritized because they represent the original conceptual framework and are generally more conceptually complete than later versions that may have been altered by LLMs or other automated tools without explicit consent.

### Consolidation Strategy

1. **Duplicate Detection:** Repositories with similar names across organizations are identified
2. **Priority Preservation:** The version from the earliest organization (highest priority) is kept as primary
3. **Reference Tracking:** Alternative versions are noted under 'Duplicates' field
4. **Original Integrity:** All original project information is preserved

---

**Catalog Complete** • 176 repositories • 11 organizations • Generated 2026-02-11
