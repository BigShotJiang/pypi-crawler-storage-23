# Morphism CLI — Architecture

**Purpose:** Command taxonomy, conventions, config schema, execution model, and plugin design. See [CLI_SCOPE.md](CLI_SCOPE.md) and [CLI_SCRIPT_MAP.md](CLI_SCRIPT_MAP.md).

---

## 1. Command taxonomy and conventions

### Top-level groups

- `morphism init` — Initialize project (write .morphism/config.json).
- `morphism validate` — Run validation suite (registry, policy, SSOT).
- `morphism ssot` — SSOT extract / verify.
- `morphism docs` — Docs frontmatter / sync / graph.
- `morphism doctor` — Environment and path checks.
- (v2) `morphism inventory`, `morphism audit`, `morphism security`, `morphism drift`, `morphism release`, `morphism generate`, `morphism watch`.

### Help and output

- One-line description per command; `--help` consistent via Click.
- Exit codes: **0** = success; **1** = validation/execution failure; **2** = usage error.
- Logging: DEBUG/INFO/WARNING/ERROR; optional `--verbose` / `--quiet` where applicable.
- Optional `--json` for machine-readable output on commands that report results (validate, doctor, analyze).

### Cross-platform

- Use `pathlib` throughout; no hardcoded path separators.
- No bash-only assumptions; document PowerShell equivalents in HANDOFF or CLI README for any script-like usage.

---

## 2. Config schema and loader

### Source of truth

- Config file: `.morphism/config.json` (relative to repo root).
- Schema: Pydantic models in `src/morphism/config.py`; optional JSON schema export for `.morphism/schemas/config.schema.json` (can be generated from Pydantic).

### Loader behavior

- **Discovery:** From cwd, walk upward until `.morphism/config.json` is found; else optional default or fail with clear error.
- **Validation:** Load JSON, validate with Pydantic; reject unsupported `version` with clear error (supported: e.g. 1.0.0, 1.1.0).
- **Defaults:** Optional fields have defaults in the model; required: version, name, frameworkSource (or minimal set).

### Versioning

- Config has a `version` field (semver). CLI supports a defined range; unsupported versions produce exit 2 and a message to upgrade or migrate.

---

## 3. Execution model

- **Preferred:** Direct Python imports. Scripts are refactored into callable modules under `src/morphism/tooling/`; CLI imports and calls them (no subprocess for Python).
- **Fallback:** Shell or subprocess only for legacy or non-Python tools; document which commands use which.
- **Benefits:** Single process, testable, no path/shell quirks on Windows.

---

## 4. Plugin registry (v1 minimal)

- **v1:** Simple manifest (e.g. `.morphism/cli-plugins.json` or a list in config) mapping command name → module path or entry point. CLI discovers and registers these at startup so new tools can add commands without editing `main.py`.
- **v2:** Full plugin discovery (entry points, scan directories, etc.).

---

## 5. File layout (reference)

```
src/morphism/
  __init__.py
  config.py          # Pydantic models + load_config()
  cli/
    main.py           # Click root + command groups
  tooling/            # Callable modules (Phase 4)
    ssot.py
    docs.py
    validate.py
    ...
  convergence.py      # Phase 5 (metrics)
```

---

*Governance: [AGENTS.md](../../AGENTS.md), [CLI_SCOPE.md](CLI_SCOPE.md).*
