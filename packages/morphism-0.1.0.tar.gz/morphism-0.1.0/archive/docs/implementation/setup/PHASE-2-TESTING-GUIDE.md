# Phase 2: Testing & Verification Guide

**Status**: Step-by-step testing procedures
**Date**: 2026-02-06
**Purpose**: Verify all Phase 2 configurations work correctly

---

## Quick Test (5 minutes)

Run this to quickly verify your setup is working:

### WSL Quick Test

```bash
# 1. Source the environment
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# 2. Verify environment
show-context
# Expected: Running Context = WSL

# 3. Navigate and verify
workspace && verify-paths
# Expected: All 4 paths exist ✓

# 4. Check Git
check-git-config
# Expected: core.autocrlf = input

# 5. Test agent access
ls $KIRO_AGENTS | head
# Expected: List of agent JSON files
```

### Windows Quick Test

```powershell
# 1. Run environment script
. "C:\Users\mesha\Desktop\GitHub\.setup\windows-environment.ps1"

# 2. Verify environment
Show-Context
# Expected: Running Context = Windows

# 3. Navigate and verify
workspace; Verify-Paths
# Expected: All 4 paths exist ✓

# 4. Check Git
Check-GitConfig
# Expected: core.autocrlf = input

# 5. Test agent access
dir $env:KIRO_AGENTS | Select -First 5
# Expected: List of agent JSON files
```

---

## Comprehensive Testing (30 minutes)

### Test 1: Environment Variables (5 min)

#### WSL

```bash
# Check all key variables are set
echo "WORKSPACE_ROOT: $WORKSPACE_ROOT"
echo "KIRO_CONFIG_HOME: $KIRO_CONFIG_HOME"
echo "IS_WSL: $IS_WSL"
echo "RUNNING_CONTEXT: $RUNNING_CONTEXT"

# Expected output:
# WORKSPACE_ROOT: /mnt/c/Users/mesha/Desktop/GitHub
# KIRO_CONFIG_HOME: /mnt/c/Users/mesha/.kiro
# IS_WSL: true
# RUNNING_CONTEXT: WSL
```

#### Windows

```powershell
# Check all key variables are set
Write-Host "WORKSPACE_ROOT: $env:WORKSPACE_ROOT"
Write-Host "KIRO_CONFIG_HOME: $env:KIRO_CONFIG_HOME"
Write-Host "IS_WINDOWS: $env:IS_WINDOWS"
Write-Host "RUNNING_CONTEXT: $env:RUNNING_CONTEXT"

# Expected output:
# WORKSPACE_ROOT: C:\Users\mesha\Desktop\GitHub
# KIRO_CONFIG_HOME: C:\Users\mesha\.kiro
# IS_WINDOWS: True
# RUNNING_CONTEXT: Windows
```

---

### Test 2: Path Accessibility (5 min)

#### WSL

```bash
# Test each path
echo "Testing workspace..."
test -d "$WORKSPACE_ROOT" && echo "  ✓ Workspace exists" || echo "  ✗ Workspace missing"

echo "Testing Kiro config..."
test -d "$KIRO_CONFIG_HOME" && echo "  ✓ Config exists" || echo "  ✗ Config missing"

echo "Testing agents..."
test -d "$KIRO_AGENTS" && echo "  ✓ Agents exist" || echo "  ✗ Agents missing"

echo "Testing steering..."
test -d "$KIRO_STEERING" && echo "  ✓ Steering exists" || echo "  ✗ Steering missing"

# Count agent files
echo ""
echo "Agent files:"
ls "$KIRO_AGENTS"/*.json 2>/dev/null | wc -l | xargs echo "  Found:"
```

#### Windows

```powershell
# Test each path
"Testing workspace..." | Write-Host
if (Test-Path "$env:WORKSPACE_ROOT") { "  ✓ Workspace exists" } else { "  ✗ Workspace missing" }

"Testing Kiro config..." | Write-Host
if (Test-Path "$env:KIRO_CONFIG_HOME") { "  ✓ Config exists" } else { "  ✗ Config missing" }

"Testing agents..." | Write-Host
if (Test-Path "$env:KIRO_AGENTS") { "  ✓ Agents exist" } else { "  ✗ Agents missing" }

"Testing steering..." | Write-Host
if (Test-Path "$env:KIRO_STEERING") { "  ✓ Steering exists" } else { "  ✗ Steering missing" }

# Count agent files
"`nAgent files:" | Write-Host
(Get-ChildItem "$env:KIRO_AGENTS\*.json" -ErrorAction SilentlyContinue).Count | Write-Host "  Found:"
```

---

### Test 3: JSON Configuration Validity (5 min)

#### Verify math-agent.json (Fixed in Phase 1)

```bash
# WSL
python3 -m json.tool "$KIRO_AGENTS/math-agent.json" > /dev/null && \
  echo "✓ math-agent.json is valid JSON" || \
  echo "✗ math-agent.json has syntax errors"

# Check for hardcoded paths
grep -i "/home/meshal\|C:\\\\Users" "$KIRO_AGENTS/math-agent.json" && \
  echo "⚠️  Found absolute paths in math-agent.json" || \
  echo "✓ No absolute paths found"

# Check resource paths
grep -A 3 '"resources"' "$KIRO_AGENTS/math-agent.json"
# Expected: Should reference morphism/AGENTS.md and morphism/MORPHISM.md
```

#### Check All Agent Files

```bash
# WSL
for file in "$KIRO_AGENTS"/*.json; do
  python3 -m json.tool "$file" > /dev/null 2>&1
  if [ $? -eq 0 ]; then
    echo "  ✓ $(basename "$file")"
  else
    echo "  ✗ $(basename "$file") - INVALID JSON"
  fi
done
```

---

### Test 4: Git Configuration (5 min)

#### Verify CRLF Setting

```bash
# WSL or Windows
git config --show-origin core.autocrlf
# Expected: file:~/.gitconfig (or /root/.gitconfig)    input
#           OR file:C:\Users\mesha\.gitconfig  input

# If not set to "input", set it:
git config --global core.autocrlf input
git config --show-origin core.autocrlf
```

#### Verify Credential Helper

```bash
# WSL
git config --show-origin credential.helper
# Expected: file:~/.gitconfig    cache

# Windows
git config --show-origin credential.helper
# Expected: file:C:\Users\mesha\.gitconfig  manager-core
```

#### Test Git Functionality

```bash
# Navigate to workspace
cd /mnt/c/Users/mesha/Desktop/GitHub  # WSL
# OR
cd C:\Users\mesha\Desktop\GitHub      # Windows

# Check status
git status
# Expected: Shows clean working tree, no "every file modified"
```

---

### Test 5: IDE Integration (10 min)

#### Test VS Code from WSL

```bash
cd /mnt/c/Users/mesha/Desktop/GitHub
code .
```

**Expected behavior**:
1. VS Code opens
2. Look at bottom-left corner
3. Should show: `><WSL: Ubuntu-24.04` (green indicator)
4. Terminal in VS Code should be bash
5. You can run: `lake build`, `pnpm install`, etc.

**If Remote-WSL doesn't activate**:
```bash
# Close VS Code
# Install Remote-WSL extension
code --install-extension ms-vscode-remote.remote-wsl

# Try again
code .
```

---

#### Test VS Code from Windows

```powershell
cd C:\Users\mesha\Desktop\GitHub
code .
```

**Expected behavior**:
1. VS Code opens
2. Bottom-left should NOT show WSL indicator
3. Terminal should be PowerShell
4. You can run: `npm test`, `pnpm build`, etc.

---

#### Test Cursor (Windows Only)

```powershell
cd C:\Users\mesha\Desktop\GitHub
cursor-workspace
# OR
cursor .
```

**Expected behavior**:
1. Cursor opens
2. Workspace is loaded
3. Terminal is PowerShell
4. Can navigate, edit files, run npm commands

---

#### Test Agent Loading

**From VS Code**:
```bash
# In VS Code terminal (from WSL)
cd /mnt/c/Users/mesha/Desktop/GitHub

# Check math-agent can be loaded
cat ~/.kiro/agents/math-agent.json | jq '.prompt'
# Expected: "file://.kiro/steering/agentic-math-prompt.md"

# Verify prompt file exists
cat ~/.kiro/steering/agentic-math-prompt.md
# Expected: Markdown content
```

---

### Test 6: Tool Availability (5 min)

#### Check Tools in Windows

```powershell
"Checking tool availability..."

@("node", "npm", "pnpm", "git", "code", "lean") | ForEach-Object {
  if (Get-Command $_ -ErrorAction SilentlyContinue) {
    Write-Host "  ✓ $_"
  } else {
    Write-Host "  ✗ $_ (not found)"
  }
}
```

#### Check Tools in WSL

```bash
echo "Checking tool availability..."

for tool in node npm pnpm git code lean lake; do
  if command -v $tool &> /dev/null; then
    echo "  ✓ $tool"
  else
    echo "  ✗ $tool (not found)"
  fi
done
```

---

### Test 7: Cross-Context File Access (5 min)

#### Read Same File from Both Contexts

**From Windows**:
```powershell
# Get first 5 lines of math-agent.json
Get-Content "C:\Users\mesha\.kiro\agents\math-agent.json" -Head 5
```

**From WSL**:
```bash
# Get first 5 lines of same file
head -5 /mnt/c/Users/mesha/.kiro/agents/math-agent.json
```

**Expected**:
- Both should show identical content
- Both should be valid JSON
- No encoding/charset issues

---

## Detailed Test Results Template

Create a file `PHASE-2-TEST-RESULTS.md` and fill it in as you test:

```markdown
# Phase 2: Test Results

Date: [today's date]
Tester: [your name]

## Quick Tests

### WSL Quick Test
- [ ] Source environment script: YES / NO / ERROR
- [ ] show-context works: YES / NO / ERROR
- [ ] show-context output correct: YES / NO / ERROR
- [ ] verify-paths works: YES / NO / ERROR
- [ ] All paths exist: YES / NO / PARTIAL

### Windows Quick Test
- [ ] Load environment script: YES / NO / ERROR
- [ ] Show-Context works: YES / NO / ERROR
- [ ] Show-Context output correct: YES / NO / ERROR
- [ ] Verify-Paths works: YES / NO / ERROR
- [ ] All paths exist: YES / NO / PARTIAL

## Comprehensive Tests

### Test 1: Environment Variables
- [ ] WSL variables set correctly
- [ ] Windows variables set correctly
- [ ] Context detection works

### Test 2: Path Accessibility
- [ ] WSL: All paths accessible
- [ ] Windows: All paths accessible
- [ ] Agent files found

### Test 3: JSON Validity
- [ ] math-agent.json is valid
- [ ] All agent files are valid
- [ ] No absolute paths found

### Test 4: Git Configuration
- [ ] core.autocrlf set to input
- [ ] Credential helper configured
- [ ] Git status shows clean repo

### Test 5: IDE Integration
- [ ] VS Code from WSL: WORKS / ISSUE
- [ ] VS Code from Windows: WORKS / ISSUE
- [ ] Cursor from Windows: WORKS / ISSUE
- [ ] Remote-WSL extension active: YES / NO

### Test 6: Tool Availability
- [ ] Node.js available
- [ ] npm available
- [ ] pnpm available
- [ ] Git available
- [ ] Lean available: YES / NO / N/A

### Test 7: Cross-Context Access
- [ ] File readable from Windows
- [ ] File readable from WSL
- [ ] Content identical
- [ ] No encoding issues

## Issues Found

[List any issues and their solutions]

## Summary

Overall Status: PASS / PASS WITH ISSUES / FAIL

Ready for Phase 3: YES / NO

Notes:
[Any additional notes]
```

---

## Troubleshooting During Testing

### Issue: "Environment script not found"

```bash
# Verify file exists
ls -la /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# If not found, Phase 2 files weren't created properly
# Check PHASE-2-SETUP-GUIDE.md for creation instructions
```

---

### Issue: "show-context command not found"

**Cause**: Environment script not sourced

**Fix**:
```bash
# Source it manually
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# Try again
show-context

# To make permanent, add to ~/.bashrc or ~/.zshrc:
echo "source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh" >> ~/.bashrc
```

---

### Issue: "Paths don't exist"

**WSL**:
```bash
# Check if mount is working
ls /mnt/c/Users/mesha
# If no output: WSL mount issue

# Check WSL configuration
wsl -l -v
# Should show Ubuntu-24.04 with version 2
```

**Windows**:
```powershell
# Check if folders exist
Test-Path "C:\Users\mesha\Desktop\GitHub"
Test-Path "C:\Users\mesha\.kiro"

# If false: Check folder structure
Get-ChildItem "C:\Users\mesha\Desktop" | Select Name
```

---

### Issue: "VS Code Remote-WSL not working"

**Check if extension is installed**:
```bash
# From VS Code terminal
code --list-extensions | grep remote-wsl
# Expected: ms-vscode-remote.remote-wsl

# If not found, install it:
code --install-extension ms-vscode-remote.remote-wsl
```

---

### Issue: "Git shows every file as modified"

**Verify CRLF setting**:
```bash
git config --global core.autocrlf
# Should show: input

# If not:
git config --global core.autocrlf input

# Refresh Git index:
git add --renormalize -A
git commit -m "fix: normalize line endings"
```

---

## Success Criteria Checklist

Mark these as you complete testing:

```
Phase 2 Success Criteria:

Environment Variables:
  [ ] WSL variables set and accessible
  [ ] Windows variables set and accessible
  [ ] Context detection working
  [ ] show-context / Show-Context functions work

Paths & Files:
  [ ] All workspace paths accessible from WSL
  [ ] All workspace paths accessible from Windows
  [ ] Agent files present and readable
  [ ] Config files are valid JSON
  [ ] No hardcoded absolute paths in configs

Git Configuration:
  [ ] core.autocrlf set globally to input
  [ ] Credential helper configured for context
  [ ] Git status shows clean repo
  [ ] No spurious file modifications

IDE Integration:
  [ ] VS Code opens from WSL (with Remote-WSL)
  [ ] VS Code opens from Windows
  [ ] Cursor opens from Windows
  [ ] Agent files accessible from IDE
  [ ] Terminals in IDEs work correctly

Tool Access:
  [ ] Node.js available in context
  [ ] npm/pnpm available in context
  [ ] Git available in context
  [ ] Lean available in WSL
  [ ] Docker available in WSL

Cross-Context:
  [ ] Same files readable from both contexts
  [ ] No encoding/charset issues
  [ ] Git diff shows no modifications
  [ ] Workflow transitions smoothly

Overall:
  [ ] All tests pass
  [ ] No critical issues
  [ ] Ready for Phase 3
```

---

## Test Execution Timeline

**Estimated time per phase**:
- Quick test: 5 minutes
- Each comprehensive test: 3-5 minutes
- Total comprehensive: 30-40 minutes
- Troubleshooting: 5-10 minutes

**Recommended approach**:
1. Run quick test first (validate basic setup)
2. If quick test passes, run comprehensive tests
3. Document any issues found
4. Use troubleshooting section for fixes
5. Re-test fixed items

---

## Next Steps After Testing

**If all tests pass**:
- Create `PHASE-2-TEST-RESULTS.md` with results
- Proceed to Phase 3 (optional dual-config setup)
- Establish development workflow

**If some tests fail**:
- Note specific issues in test results
- Use troubleshooting section
- Re-test after fixes
- Document solutions for future reference

**If critical tests fail**:
- Check Phase 1 audit (verify fixes are still in place)
- Review setup guide steps
- May need to re-run Phase 1 fixes

---

**Generated**: 2026-02-06
**Phase**: 2 of 3
**Status**: Testing procedures ready
