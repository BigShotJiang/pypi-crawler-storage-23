# Phase 2: Environment-Aware Configuration & Tool Setup Guide

**Status**: Ready for implementation
**Date**: 2026-02-06
**Focus**: Cross-environment tool compatibility and workflow optimization

---

## Table of Contents

1. [Quick Start](#quick-start)
2. [Environment Variables](#environment-variables)
3. [WSL Setup](#wsl-setup)
4. [Windows Setup](#windows-setup)
5. [Tool-Specific Workflows](#tool-specific-workflows)
6. [Git Configuration](#git-configuration)
7. [Troubleshooting](#troubleshooting)
8. [Testing Checklist](#testing-checklist)

---

## Quick Start

### For WSL Users

```bash
# 1. Add to your ~/.bashrc or ~/.zshrc
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# 2. Verify setup
show-context
verify-paths

# 3. Navigate to workspace
workspace
```

### For Windows Users (PowerShell)

```powershell
# 1. Find your PowerShell profile location
$PROFILE

# 2. Add to your profile
. "C:\Users\mesha\Desktop\GitHub\.setup\windows-environment.ps1"

# 3. Verify setup
Show-Context
Verify-Paths
```

---

## Environment Variables

### Key Variables (Both Platforms)

| Variable | WSL | Windows | Purpose |
|----------|-----|---------|---------|
| `WORKSPACE_ROOT` | `/mnt/c/Users/mesha/Desktop/GitHub` | `C:\Users\mesha\Desktop\GitHub` | Primary workspace |
| `KIRO_CONFIG_HOME` | `/mnt/c/Users/mesha/.kiro` | `C:\Users\mesha\.kiro` | Agent config location |
| `RUNNING_CONTEXT` | `WSL` | `Windows` | Detect current environment |
| `IS_WSL` | `true` | `false` | Boolean flag |
| `IS_WINDOWS` | `false` | `true` | Boolean flag |

### How They Work

The setup scripts **automatically set these variables based on your environment**. You don't need to do anything special — just source the script and they're available.

```bash
# Example: Using in a script
if [ "$IS_WSL" = true ]; then
  echo "Running in WSL context"
  # Use WSL-specific tools
else
  echo "Running in Windows context"
  # Use Windows-specific tools
fi
```

---

## WSL Setup

### Step 1: Add Environment Script to Shell Profile

**For Bash** (`~/.bashrc`):
```bash
# Add this line to the end of ~/.bashrc
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh
```

**For Zsh** (`~/.zshrc`):
```bash
# Add this line to the end of ~/.zshrc
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh
```

### Step 2: Reload Shell Configuration

```bash
# For Bash
source ~/.bashrc

# For Zsh
source ~/.zshrc

# Verify it worked
show-context
```

### Step 3: Verify Paths

```bash
verify-paths
```

Expected output:
```
Verifying path accessibility...
  ✓ /mnt/c/Users/mesha/Desktop/GitHub
  ✓ /mnt/c/Users/mesha/.kiro
  ✓ /mnt/c/Users/mesha/.kiro/agents
  ✓ /mnt/c/Users/mesha/.kiro/steering
All paths verified ✓
```

### Step 4: Test Git Configuration

```bash
check-git-config
```

Expected output should show:
```
Git Configuration:
  core.autocrlf:      input
  credential.helper:  cache
```

If not set correctly, run:
```bash
git config --global core.autocrlf input
git config --global credential.helper cache
```

---

## Windows Setup

### Step 1: Find Your PowerShell Profile

```powershell
# This will print the path to your profile
$PROFILE

# Example output:
# C:\Users\mesha\Documents\PowerShell\profile.ps1
```

### Step 2: Create/Edit PowerShell Profile

```powershell
# Create the profile if it doesn't exist
if (!(Test-Path -Path $PROFILE)) {
    New-Item -ItemType File -Path $PROFILE -Force
}

# Open in your editor
code $PROFILE
# or
notepad $PROFILE
```

### Step 3: Add the Setup Script

Add this line to your PowerShell profile:

```powershell
# Load Morphism environment configuration
. "C:\Users\mesha\Desktop\GitHub\.setup\windows-environment.ps1"
```

### Step 4: Reload PowerShell

```powershell
# Close and reopen PowerShell, OR reload the profile:
& $PROFILE
```

### Step 5: Verify Setup

```powershell
Show-Context
Verify-Paths
```

---

## Tool-Specific Workflows

### VS Code (Works from Both Contexts)

**From Windows**:
```powershell
cd C:\Users\mesha\Desktop\GitHub
code .
```

**From WSL**:
```bash
cd /mnt/c/Users/mesha/Desktop/GitHub
code .
```

**Via Remote-WSL** (recommended for WSL work):
```bash
# From WSL terminal
code .
# This automatically opens VS Code with Remote-WSL extension
```

**Benefit**: VS Code detects WSL and provides integrated terminal with WSL bash.

---

### Cursor (Windows Only)

**Launch Method 1: From PowerShell**:
```powershell
workspace  # Navigate to workspace
cursor-workspace
```

**Launch Method 2: From Windows Explorer**:
1. Right-click folder → "Open with Cursor"

**Key Behavior**:
- Cursor runs in Windows context only
- All paths must be Windows paths: `C:\Users\...`
- Terminal in Cursor will be PowerShell

**When to Use**:
- Writing TypeScript/JavaScript (Node.js tools)
- Working with npm packages
- IDE features are best in Windows context

---

### Windsurf (Windows Only)

**Launch Method 1: From PowerShell**:
```powershell
workspace
open-workspace windsurf
```

**Launch Method 2: Command line**:
```powershell
windsurf C:\Users\mesha\Desktop\GitHub
```

**Key Behavior**:
- Same as Cursor (Windows context)
- All paths must be Windows paths

**When to Use**:
- Similar to Cursor
- Personal preference between Cursor/Windsurf

---

### Lean/Proofs (WSL Recommended)

**Why WSL for Lean?**
- Lake build system works better in Linux
- Docker/container support
- Consistent with CI/CD pipeline

**Workflow**:
```bash
# From WSL
workspace
cd lab/proofs

# Build proofs
lake build

# Run specific proof
lean Morphism.lean
```

**From Windows** (if needed):
```powershell
# Not recommended - use WSL instead
# But if necessary:
cd C:\Users\mesha\Desktop\GitHub\lab\proofs
lean Morphism.lean
```

---

### pnpm/Node (Works from Both)

**From Windows PowerShell**:
```powershell
workspace
pnpm install
pnpm run build
```

**From WSL Bash**:
```bash
workspace
pnpm install
pnpm run build
```

**Key Point**: Use native tools from each context
- Windows: Use Windows pnpm/node
- WSL: Use WSL pnpm/node
- (They're installed separately in each environment)

---

### Git (Works from Both, with Care)

**Line Endings** (critical):
```bash
# Set once, works everywhere
git config --global core.autocrlf input
```

This ensures:
- Repository stores LF (Linux standard)
- Windows checkout converts to CRLF
- WSL checkout keeps LF
- No spurious "file changed" messages

**Credentials** (context-dependent):

**Windows**:
```powershell
git config --global credential.helper manager-core
```

**WSL**:
```bash
git config --global credential.helper cache
```

Both approaches work — they just use different credential stores.

---

## Git Configuration

### Critical: CRLF Handling

```bash
# Set this once (globally)
git config --global core.autocrlf input

# Verify
git config --show-origin core.autocrlf
# Should output: file:/home/meshal/.gitconfig    input
```

**Why `input`?**
- Keeps repository clean (all LF)
- Converts to CRLF on Windows checkout
- Converts to LF on WSL checkout
- Prevents "every file modified" messages

### Credential Management

**Option 1: Windows Credential Manager (Windows)**
```powershell
git config --global credential.helper manager-core
```

**Option 2: Git Credential Cache (WSL)**
```bash
git config --global credential.helper cache
git config --global credential.cache --timeout=3600
```

**Option 3: SSH Keys (Recommended)**
```bash
# Generate SSH key
ssh-keygen -t ed25519 -C "your@email.com"

# Add to GitHub:
# Settings → SSH and GPG keys → New SSH key
# Paste contents of ~/.ssh/id_ed25519.pub

# Test connection
ssh -T git@github.com
# Should output: Hi username! You've successfully authenticated...
```

---

## Troubleshooting

### Issue: "WORKSPACE_ROOT not found"

**Cause**: Environment script not sourced

**Fix**:
```bash
# Verify the script exists
ls /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# Source it manually
source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

# Verify
echo $WORKSPACE_ROOT
# Should print: /mnt/c/Users/mesha/Desktop/GitHub
```

---

### Issue: "Git command not found" in one context

**Cause**: Git not installed in that context

**Fix (Windows)**:
```powershell
# Check if Git is installed
git --version

# If not: Install from https://git-scm.com/download/win
# Choose "Use Git from Windows Command Prompt"
```

**Fix (WSL)**:
```bash
# Check if Git is installed
git --version

# If not:
sudo apt update
sudo apt install git
```

---

### Issue: "Perm denied" when accessing Windows config from WSL

**Cause**: Permission differences between Windows and WSL

**Fix**:
```bash
# Check permissions
ls -la /mnt/c/Users/mesha/.kiro

# If needed, adjust permissions (WSL side)
chmod 755 /mnt/c/Users/mesha/.kiro
chmod 755 /mnt/c/Users/mesha/.kiro/agents
```

---

### Issue: IDE can't find agent configuration

**Cause**: Path resolution mismatch

**Check**:
```bash
# From WSL
ls $KIRO_CONFIG_HOME/agents
# Should show all agent JSON files

# From Windows
dir C:\Users\mesha\.kiro\agents
# Should show all agent JSON files
```

**Fix**: Ensure paths in agent JSON use relative format:
```bash
# Should be:
"file://.kiro/steering/agentic-math-prompt.md"

# NOT:
"file:///home/meshal/.kiro/steering/agentic-math-prompt.md"
"file:///C:/Users/mesha/.kiro/steering/agentic-math-prompt.md"
```

---

### Issue: "Can't open code from PowerShell"

**Cause**: VS Code not in PATH

**Fix**:
```powershell
# Check if code command works
code --version

# If not, add VS Code to PATH:
# 1. Install VS Code (if not already)
# 2. During installation, check "Add to PATH"
# 3. Restart PowerShell
```

---

## Testing Checklist

### Phase 2 Verification (Do This)

#### ✓ WSL Context Testing

```bash
# 1. Navigate to workspace
workspace
# Expected: You're in /mnt/c/Users/mesha/Desktop/GitHub

# 2. Check environment
show-context
# Expected: RUNNING_CONTEXT = WSL, IS_WSL = true

# 3. Verify paths
verify-paths
# Expected: All 4 paths exist ✓

# 4. Check Git config
check-git-config
# Expected: core.autocrlf = input, credential.helper = cache

# 5. Test Kiro access
ls $KIRO_AGENTS
# Expected: List of agent JSON files

# 6. Open in VS Code
code .
# Expected: VS Code opens with Remote-WSL
```

#### ✓ Windows Context Testing

```powershell
# 1. Navigate to workspace
workspace
# Expected: You're in C:\Users\mesha\Desktop\GitHub

# 2. Check environment
Show-Context
# Expected: RUNNING_CONTEXT = Windows, IS_WINDOWS = true

# 3. Verify paths
Verify-Paths
# Expected: All 4 paths exist ✓

# 4. Check Git config
Check-GitConfig
# Expected: core.autocrlf = input, credential.helper = manager-core

# 5. Test Kiro access
dir $env:KIRO_AGENTS
# Expected: List of agent JSON files

# 6. Open in VS Code
code-workspace
# Expected: VS Code opens in Windows context
```

#### ✓ Cross-Context Testing

```bash
# From WSL: Check if you can access agent files
cat /mnt/c/Users/mesha/.kiro/agents/math-agent.json | head -5
# Expected: Valid JSON output

# From Windows: Check if you can access the same files
type C:\Users\mesha\.kiro\agents\math-agent.json | head -5
# Expected: Same valid JSON output
```

#### ✓ IDE Testing

**VS Code from WSL**:
```bash
code .
# Expected: Opens VS Code with Remote-WSL indicator
# Check bottom-left corner shows "WSL: Ubuntu-24.04"
```

**Cursor from Windows**:
```powershell
cursor-workspace
# Expected: Cursor opens with Windows context
# Terminal in Cursor shows PowerShell
```

#### ✓ Git Testing

```bash
# From WSL
git status
# Expected: Shows repo status, no "every file changed" message

# From Windows
git status
# Expected: Same result, no CRLF conversion issues
```

---

## Summary of Configuration

### What You Now Have

1. **WSL Environment Script** (`.setup/wsl-environment.sh`)
   - Sets environment variables
   - Provides helper functions
   - Works with bash and zsh

2. **Windows Environment Script** (`.setup/windows-environment.ps1`)
   - Sets environment variables
   - Provides navigation shortcuts
   - Works in PowerShell

3. **Git Configuration**
   - CRLF handling (input mode)
   - Credential management
   - Cross-environment compatibility

4. **Tool Workflows**
   - VS Code: Works from both contexts
   - Cursor/Windsurf: Windows-only (recommended)
   - Lean: WSL-recommended
   - Node/pnpm: Works from both

### Next Actions

1. **Implement Environment Scripts**
   ```bash
   # WSL
   source /mnt/c/Users/mesha/Desktop/GitHub/.setup/wsl-environment.sh

   # Windows
   . "C:\Users\mesha\Desktop\GitHub\.setup\windows-environment.ps1"
   ```

2. **Run Verification**
   - WSL: `show-context && verify-paths`
   - Windows: `Show-Context && Verify-Paths`

3. **Test Each Tool**
   - Launch each IDE from your preferred context
   - Verify agent loading works
   - Check terminal integration

4. **Document Issues**
   - Note any issues encountered
   - Use troubleshooting section above
   - Report anything not covered

---

## Reference: File Structure

```
.setup/
├── wsl-environment.sh         ← Source this in ~/.bashrc/zshrc
├── windows-environment.ps1    ← Source this in PowerShell profile
└── phase-2-setup-guide.md     ← This file

.kiro/
├── agents/                    ← Accessible from both contexts
├── steering/                  ← Accessible from both contexts
└── extensions/                ← Accessible from both contexts

PHASE-1-AUDIT-COMPLETE.md     ← Results from Phase 1
PHASE-1-COMPLETION-SUMMARY.md ← Detailed Phase 1 summary
PHASE-2-SETUP-GUIDE.md        ← This file
```

---

## Success Criteria

✅ WSL context: `show-context` works and shows WSL
✅ Windows context: `Show-Context` works and shows Windows
✅ Both contexts: Can navigate to workspace
✅ Both contexts: Agent files accessible
✅ Both contexts: Git works with consistent line endings
✅ Each IDE: Opens and loads agents correctly
✅ Cross-context: Git status shows no spurious changes

---

**Next Phase**: Phase 3 (Optional)
- Implement dual-config strategy if issues persist
- Create config sync script
- Document advanced workflows

**Questions?** See troubleshooting section above.

---

**Generated**: 2026-02-06
**Phase**: 2 of 3
**Status**: Ready for implementation
