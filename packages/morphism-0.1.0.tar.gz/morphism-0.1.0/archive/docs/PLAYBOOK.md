---
type: operational
authority: derived
audience: [contributors]
last-verified: 2026-02-20
---

# Morphism workspace playbook

> **NON-NORMATIVE.**

One flow when you're overwhelmed or need a clean pre-PR state.

---

## When overwhelmed (do this)

1. Run **morphism-steward** with goal: "pre-PR check + fix what's safe."
2. If any **Needs human decision** items exist: pick one, decide, then re-run steward.
3. If you moved files or changed commands: run **morphism-docs** with what changed.
4. Run **morphism-steward** one last time for a clean Status Summary.

---

## When changing claims or evidence

1. Update the evidence (e.g. new validation, new artifact).
2. Update ledger/registry as needed (evidence_ledger.json, ARTIFACT_REGISTRY.json).
3. Run **morphism-steward** (fix drift if reported).
4. Ensure RECONCILIATION_REPORT is updated if public claims changed.
5. Re-run validations (drift + registry + e2e per `docs/TEST_COMMANDS.md`).

---

## When preparing a release

Follow `docs/governance/RELEASE_CHECKLIST_V1.md`:

- Apply RECONCILIATION_REPORT to website (if not already).
- Verify ARTIFACT_REGISTRY and evidence_ledger are complete.
- Run steward for clean Status Summary; then tag and deploy per checklist.

No dedicated release agent yet; use the checklist and steward for verification.
