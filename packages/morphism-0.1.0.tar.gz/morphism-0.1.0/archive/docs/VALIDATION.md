---
type: operational
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# Validation: empirical evidence and methodology

> **NON-NORMATIVE.**

**Purpose:** Document empirical validation of Morphism governance (AGENTS.md + SSOT pattern, tooling, and Hub). Formal verification (e.g. Lean 4) is on the roadmap; this document covers what is evidenced today.

---

## 1. Scope

- **Governance pattern:** AGENTS.md + SSOT.md + .morphism config; enforcement via scripts and CI.
- **Hub (SaaS):** Next.js app with auth, credential vault, governance checks; tests (Vitest), CI, deployment (Vercel).
- **Workspace:** Scripts (validate-registry, status, pull-all), ARTIFACT_REGISTRY, governance docs.

---

## 2. Methodology

| Area | How we validate |
|------|------------------|
| **Code quality** | Lint, typecheck, unit/integration tests; CI (GitHub Actions) runs on push/PR. |
| **Governance checks** | governance-check scripts (κ config, no secrets in code); validate-registry.py for registry/inventory. |
| **Deployment** | Build passes; deploy to Vercel (Hub); smoke/health checks where configured. |
| **Agent-eval / before-after** | When available: Vercel or internal agent-eval data comparing AGENTS.md vs no-governance; link or summarize here. |

---

## 3. Evidence (current)

| Artifact | Evidence |
|----------|----------|
| **Hub** | CI (GitHub Actions), Vitest tests, Vercel deployment. See ARTIFACT_REGISTRY.json → hub.evidence. |
| **Workspace** | validate-registry.py, e2e-inventory-system.sh, scripts; docs and templates. |
| **Tenets / κ < 1** | Documented in morphism/docs/vision/tenets.md and theory docs; enforced by governance-check (config validation). No published formal proof yet. |
| **7 invariants → 10 tenets** | Current framework: [governance/INVENTORY.md](governance/INVENTORY.md). MORPHISM.md defines the tenets; “proven” reframed as “framework” until formal proofs published (see RECONCILIATION_REPORT.md). |

---

## 4. Formal verification (roadmap)

- **Status:** Not yet evidenced in repos (no committed Lean proof artifacts).
- **Roadmap:** Formal verification (Lean 4, proof backlog) targeted Q2 2026. See [execution-checklist](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/integration/mobius/docs/docs/roadmap/execution-checklist.md) and [04_mathematical_proofs/README](https://github.com/morphism-systems/mobius-morphism-unification/tree/main/integration/mobius/onboarding/morphism-onboarding/04_mathematical_proofs).
- **Placeholder for proof artifacts:** When published, link Lean 4 proof repo or path here (e.g. morphism-systems/proofs or morphism/lab/proofs).
- **Until then:** Claims on website and docs use “empirically validated” or “design target” / “framework” wording; no “formally verified” without proof link.

---

## 5. Links

- [RECONCILIATION_REPORT.md](governance/RECONCILIATION_REPORT.md) — Claim–Evidence reconciliation and website copy.
- [ARTIFACT_REGISTRY](../../.morphism/ARTIFACT_REGISTRY.json) — Canonical artifacts and evidence pointers.
- [Tenets](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/morphism/docs/vision/tenets.md) — Governance non-negotiables.
- [Execution checklist](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/integration/mobius/docs/docs/roadmap/execution-checklist.md) — Launch and formal-verification roadmap.
