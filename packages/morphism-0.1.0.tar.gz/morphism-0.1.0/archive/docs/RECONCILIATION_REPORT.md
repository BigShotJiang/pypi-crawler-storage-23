---
type: reference
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# Reconciliation Report: Claims vs Evidence

> **NON-NORMATIVE.**

**Operation:** `reconcile(Claims, Evidence)`  
**Date:** 2026-02-16  
**Status:** Complete  
**Invariant:** ∀ claim ∈ website : ∃ evidence ∈ ledger ∨ claim.status = retracted/deferred

---

## 1. Claim inventory (from morphism.systems / public narrative)

Claims that have appeared on the morphism.systems website or in public narrative (from audit):

| Claim ID | Claim text | Source |
|----------|------------|--------|
| C1 | "98.1% formally verified in Lean 4" | Website / marketing |
| C2 | "42 proven tenets" | Website (10 axioms → 42 tenets) |
| C3 | "κ < 1 convergence guarantee" | Website / technical claims |
| C4 | "Agentic Uncertainty Principle" (formalized) | Website / concept |
| C5 | Performance / improvement metrics (e.g. agent eval) | Website / case study |

---

## 2. Evidence query results

| Claim ID | Evidence location | Verification status |
|----------|-------------------|---------------------|
| C1 | No `.lean` proof artifacts in repos; [04_mathematical_proofs/README](https://github.com/morphism-systems/mobius-morphism-unification/tree/main/integration/mobius/onboarding/morphism-onboarding/04_mathematical_proofs) references backlog and "when populated" paths only | **None** |
| C2 | [tenets.md](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/morphism/docs/vision/tenets.md) lists 7 tenets; MORPHISM.md references "10 axioms → 42 tenets" as SSOT; no enumerated 42 with proofs | **Incomplete** (tenets exist as policy; "proven" unsupported) |
| C3 | [math-quick-reference.md](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/morphism/docs/theory/math-quick-reference.md), [GOVERNANCE-SYSTEM.md](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/morphism/GOVERNANCE-SYSTEM.md) define κ < 1; no published proof artifact | **Incomplete** (theory documented; formal proof not published) |
| C4 | Concept exists in docs; no formalization artifact (e.g. Lean) in repo | **Incomplete** |
| C5 | Vercel agent-eval / AGENTS.md study referenced in critique; no public validation report in repo yet | **Empirical possible** (methodology + VALIDATION.md to be added) |

---

## 3. Reconciliation decisions (ledger)

| Claim ID | Action | Evidence ID (if any) | Notes |
|----------|--------|----------------------|-------|
| C1 | **RETRACT** | — | Remove from website until proof artifacts published. Move to /research or roadmap. |
| C2 | **REFRAME_AS_EMPIRICAL** | E2 | Use "42 tenets (framework)" or "governance tenets"; drop "proven" unless proofs linked. Link to [tenets.md](https://github.com/morphism-systems/mobius-morphism-unification/blob/main/morphism/docs/vision/tenets.md) and MORPHISM.md. |
| C3 | **REFRAME_AS_EMPIRICAL** | E3 | Use "κ < 1 (design target)" or "convergence under governance"; link to theory docs. Add roadmap: "Formal verification Q2 2026". |
| C4 | **DEFER_TO_ROADMAP** | — | Keep as concept; do not claim formalization until artifact exists. |
| C5 | **KEEP_WITH_LINK** | E5 (after VALIDATION.md) | After Phase 4: link to VALIDATION.md and agent-eval methodology. |

---

## 4. Evidence ledger entries (to register)

| Evidence ID | Description | Location |
|-------------|-------------|----------|
| E2 | Governance tenets (7 listed; framework 10 axioms → 42 tenets doc) | morphism/docs/vision/tenets.md, MORPHISM.md |
| E3 | κ < 1 theory and governance-check (config validation) | morphism/docs/theory/math-quick-reference.md, scripts/governance-check |
| E5 | Empirical validation (after Phase 4) | docs/VALIDATION.md, CI/test reports |

---

## 5. Proposed website copy changes

**Hero / above fold (replace formal verification claim):**
- **Before:** "98.1% formally verified in Lean 4" (or similar).
- **After:** "Governance layer for AI coding agents" or "AGENTS.md + SSOT enforcement for AI teams." Optionally: "Empirically validated governance pattern."

**Tenets / framework:**
- **Before:** "42 proven tenets."
- **After:** "Governance framework with 10 axioms and 42 tenets" (link to MORPHISM.md or GitHub). Or: "7 core tenets + extended framework" (link to tenets.md).

**Guarantees:**
- **Before:** "κ < 1 convergence guarantee."
- **After:** "κ < 1 design target — convergence under governance" with link to [theory docs](https://github.com/morphism-systems/mobius-morphism-unification/tree/main/morphism/docs/theory). Add: "Formal verification on roadmap (Q2 2026)."

**Research / long-term:**
- Move retracted formal claims to a `/research` or "Roadmap" section: "Formal verification (Lean 4) and Agentic Uncertainty formalization in progress."

---

## 6. Definition of done checklist

- [x] Every claim on website has ledger entry (Claim ID, Evidence ID or status).
- [x] Retracted claims removed or relocated (applied to hub + morphism app `page.tsx` and `opengraph-image.tsx`).
- [x] Kept/reframed claims link to evidence (copy uses "framework", "design target", "roadmap Q2 2026"; evidence in VALIDATION.md and tenets/theory docs).
- [x] Invariant: ∀ claim ∈ website : ∃ evidence ∈ ledger ∨ claim.status = retracted/deferred (satisfied by this report).

---

## 7. Approval

- **Report committed:** workspace repo, `docs/governance/RECONCILIATION_REPORT.md`.
- **Owner action:** Update morphism.systems website source with Section 5 copy; add evidence links; move retracted claims to /research or roadmap.

---

## 8. Framework revision (mathematically-sound revision)

**Evidence IDs for in-repo framework rigor (2026-02-17):**

| Evidence ID | Description | Location |
|-------------|-------------|----------|
| E-REV-1 | Governance inventory (7 invariants, 10 tenets, derivation graph, consistency matrix) | [INVENTORY.md](INVENTORY.md) |
| E-REV-2 | Tenet derivation traces (tenet ↔ invariant + reasoning; contradiction check) | [TENET_DERIVATION.md](TENET_DERIVATION.md) |
| E-REV-3 | Validation criteria and soundness (formal / executable / rationale per invariant) | [VALIDATION_CRITERIA.md](VALIDATION_CRITERIA.md) |
| E-REV-4 | Proof roadmap (formal verification targets, timeline, process) | [PROOF_ROADMAP.md](PROOF_ROADMAP.md) |
| E-REV-5 | Semi-formal axioms and consistency note | [morphism-theory.md](../architecture/morphism-theory.md) §0, §IX |

These support "7 invariants → 10 tenets" as the current framework and provide a defensible, traceable basis for reframed website claims.
