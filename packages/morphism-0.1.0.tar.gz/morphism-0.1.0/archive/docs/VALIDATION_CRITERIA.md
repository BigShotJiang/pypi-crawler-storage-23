---
type: reference
authority: derived
audience: [agents, contributors]
last-verified: 2026-02-17
scope: governance
---

# Validation criteria and soundness

> **NON-NORMATIVE.** This document defines what "sound" means for each invariant and how to validate it. Normative requirements: [morphism-kernel.md](morphism-kernel.md).

---

## 1. Soundness criteria (per principle)

- **Formal soundness (aspirational):** The principle is stated in a formal language and has a machine-checked proof (e.g. Lean 4). Status: none yet; track in [PROOF_ROADMAP.md](PROOF_ROADMAP.md) (or roadmap section).
- **Executable soundness:** The principle is enforced by a script or CI job. Status: documented per invariant in the Kernel and [MORPHISM.md §4](MORPHISM.md).
- **Rationale soundness:** The principle has a clear, written rationale that links to the axiom set and does not appeal to undefined terms. Status: [MORPHISM.md §4](MORPHISM.md) and [TENET_DERIVATION.md](TENET_DERIVATION.md).

---

## 2. Invariant soundness table

| Invariant | Formal | Executable | Rationale |
|-----------|--------|------------|-----------|
| I-1 One Truth Per Domain | Roadmap | `ssot_verify.py`, `docs_sync.py`, drift-check | executive-overview T1, T7; TENET_DERIVATION |
| I-2 Drift Is Debt | Roadmap | drift-check workflow, `ssot_extract.py` | executive-overview T1, T7; TENET_DERIVATION |
| I-3 Observability | Roadmap | commit-msg hook, `validate_commit.py`, CODEOWNERS | executive-overview T2, T3, T5, T9; TENET_DERIVATION |
| I-4 Scope Binding | Roadmap | PR review, executive-overview matrix | executive-overview T3, T6, T9; TENET_DERIVATION |
| I-5 Entropy Monotonicity | Roadmap | `maturity_score.py --ci --threshold 60` | executive-overview T4, T8, T10; morphism-theory §II |
| I-6 Refusal as Structure | Roadmap | `policy_check.py --mode ci --explain` | executive-overview T4; morphism-theory §IV |
| I-7 Minimal Authority | Roadmap | `verify_pipeline.py` (CODEOWNERS) | executive-overview T5; morphism-theory §VII |

**Checklist per invariant:** (1) Semi-formal statement exists (morphism-theory §0); formal statements in [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md). (2) At least one enforcement script. (3) Rationale in executive-overview and derivation in TENET_DERIVATION. (4) Formal proof: yes / no / roadmap.

**Checklist per tenet:** (1) Derivation from invariants in TENET_DERIVATION. (2) Enforcement points in executive-overview. (3) No contradiction with invariants (TENET_DERIVATION §2).

---

## 3. Framework soundness level

**Current:** Executable + rationale soundness for all 7 invariants and 10 tenets. Formal verification (e.g. Lean 4) is on the roadmap; no machine-checked proof artifacts in repo yet. See [RECONCILIATION_REPORT.md](RECONCILIATION_REPORT.md) and [VALIDATION.md](../VALIDATION.md).

---

## 4. Related documents

| Document | Role |
|----------|------|
| [morphism-kernel.md](morphism-kernel.md) | Normative invariants and enforcement pointers. |
| [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) | Formal definitions and theorem statements (source for formalization). |
| [PROOF_STRATEGIES.md](PROOF_STRATEGIES.md) | Proof tactics and strategies per roadmap target. |
| [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md) | How scripts implement maturity, drift, refusal, trace (benchmarking/validation). |
| [EXAMPLES.md](EXAMPLES.md) | Concrete examples for category, E, R, G, ideation algebra. |
| [MORPHISM.md §4](MORPHISM.md) | Tenet rationale and enforcement. |
| [TENET_DERIVATION.md](TENET_DERIVATION.md) | Derivation traces and contradiction check. |
| [proof-review-workflow.md](../proof-review-workflow.md) | When adding governance proofs (Lean etc.), use that workflow and reference the invariant. |
| [PROOF_ROADMAP.md](PROOF_ROADMAP.md) | Formal verification roadmap (Phase 6). |

---

*Normative: [morphism-kernel.md](morphism-kernel.md)*
