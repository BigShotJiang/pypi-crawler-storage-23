# Scope Policy

## Classes

- `active`: Current product/governance surfaces.
  - `morphism`, `morphism-ship`, `morphism-bible`, `morphism-profile`, `morphism-references`, `docs`, `scripts`, `templates`, workspace root, active config folders.
- `archive`: Historical material.
  - `_archive`, `archive`.
- `vendor`: Third-party/generated/cache surfaces.
  - `node_modules`, `.git`, `.lake/packages`, `dist`, `build`, `coverage`, `.next`, cache folders.
- `worktree`: Parallel local work lanes.
  - `.worktrees`.

## Inclusion Profiles

- `active`: Includes only `active` scope paths.
- `full`: Includes all scope classes.

## Deterministic Runtime Defaults

- `ECOSYSTEM_MAX_DEPTH=3`
- `ECOSYSTEM_MAX_PATHS=50000`

