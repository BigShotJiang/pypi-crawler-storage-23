# Full Ecosystem Inventory

Generated: 2026-02-18T18:32:17Z
Profile: `full`

## Totals

- Paths: 973
- Files: 646
- Directories: 327

## Scope Counts

- `active`: 965
- `archive`: 2
- `vendor`: 4
- `worktree`: 2

## Top Roots

| Root | Paths |
|---|---:|
| `site` | 260 |
| `docs` | 197 |
| `.morphism` | 134 |
| `apps` | 83 |
| `.turbo` | 66 |
| `scripts` | 65 |
| `src` | 34 |
| `root` | 24 |
| `packages` | 20 |
| `.playwright-mcp` | 15 |
| `tests` | 14 |
| `.github` | 12 |
| `.claude` | 11 |
| `.ruff_cache` | 11 |
| `.pytest_cache` | 8 |
| `.githooks` | 5 |
| `.vercel` | 3 |
| `notebooks` | 2 |
| `.git` | 2 |
| `.worktrees` | 2 |

## Top Languages

| Language | Files |
|---|---:|
| `markdown` | 241 |
| `unknown` | 198 |
| `json` | 77 |
| `python` | 42 |
| `bash` | 41 |
| `typescript` | 26 |
| `yaml` | 13 |
| `powershell` | 3 |
| `javascript` | 1 |

## Notes

- Entries include path-level classification and ownership attribution.
- Priority uses scope + security risk to assign P0..P3.
- Full profile includes detailed active paths plus summarized non-active lanes for deterministic runtime.
