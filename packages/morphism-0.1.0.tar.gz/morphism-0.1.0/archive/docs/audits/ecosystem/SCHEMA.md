# Ecosystem Inventory Schema

## Fields

- `path`: Workspace-relative path.
- `kind`: `file` or `dir`.
- `scope`: `active`, `archive`, `vendor`, `worktree`.
- `status`: Scope-derived lifecycle status.
- `purpose`: Inferred role of component.
- `owner`: CODEOWNERS match, remote org fallback, or `UNOWNED`.
- `repo_remote`: Origin remote for nearest git repository.
- `governance_level`: `canonical`, `pointer-or-policy`, `standard`.
- `language`: Inferred source language.
- `build_system`: Inferred build/runtime system for nearest repo.
- `entrypoints`: Marker for operational entrypoints.
- `depends_on`: Reserved for dependency enrichment.
- `depended_by`: Reserved for reverse dependency enrichment.
- `security_risk`: `low`, `medium`, `high` heuristic.
- `priority`: `P0..P3`, derived from risk and scope.

## Runtime Guardrails

- Active inventory traversal is bounded for deterministic runtime:
  - `ECOSYSTEM_MAX_DEPTH` (default: 3)
  - `ECOSYSTEM_MAX_PATHS` (default: 50000)
- Full profile includes active-path detail plus summarized non-active lane metadata.

