# Audits

This lane stores machine-generated audit outputs and reports. Do not edit generated files by hand. If you regenerate outputs, log the change in `docs/migration_changelog.md`.

## Ecosystem audit

Reports:
- `docs/audits/ecosystem/INVENTORY_FULL.md` - full inventory summary
- `docs/audits/ecosystem/SCHEMA.md` - inventory schema and field notes
- `docs/audits/ecosystem/SCOPE_POLICY.md` - scope and inclusion policy

Data files:
- `docs/audits/ecosystem/inventory-full.json`
- `docs/audits/ecosystem/inventory.csv`

## Generate

```bash
python scripts/ecosystem_audit.py inventory --profile full
python scripts/ecosystem_audit.py all
python scripts/consolidation_toolbox.py audits-collector
```
