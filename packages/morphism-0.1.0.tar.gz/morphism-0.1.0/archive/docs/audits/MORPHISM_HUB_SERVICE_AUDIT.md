---
type: reference
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# Morphism Cloud — Service Configuration Audit

> **NON-NORMATIVE.**

**Document Version:** 1.0  
**Last Updated:** 2026-02-09  
**Project Path:** [`morphism-hub/`](../morphism-hub/)  
**Status:** Pre-Launch Configuration

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Service Architecture Overview](#service-architecture-overview)
3. [Environment Variables Status](#environment-variables-status)
4. [Service Deep Dives](#service-deep-dives)
   - [Supabase Database](#supabase-database)
   - [Clerk Authentication](#clerk-authentication)
   - [Stripe Billing](#stripe-billing)
   - [Google Gemini AI](#google-gemini-ai)
5. [Code Architecture Analysis](#code-architecture-analysis)
6. [Webhook Configurations](#webhook-configurations)
7. [Database Schema Reference](#database-schema-reference)
8. [Action Items Matrix](#action-items-matrix)
9. [Launch Readiness Score](#launch-readiness-score)

---

## Executive Summary

This document consolidates the complete service configuration state for **Morphism Hub**, a Next.js application that provides AI agent governance and compliance management. The application integrates four primary external services:

| Service | Purpose | Current Status | Blocker Level |
|---------|---------|---------------|---------------|
| **Supabase** | Database, Auth, Row Level Security | ⚠️ Needs keys + schema run | 🔴 Critical |
| **Clerk** | User/Organization Authentication | ✅ Keys configured | 🟡 Minor |
| **Stripe** | Subscription Billing | ⚠️ Partial setup | 🟠 Secondary |
| **Gemini AI** | Risk Assessment & Governance Validation | ❌ No API key | 🟠 Secondary |

### Current Readiness: 40%

**Primary Blocker:** Supabase credentials not extracted and schema not applied  
**Secondary Blockers:** Clerk webhook not configured, Gemini API key not obtained  
**Tertiary Blockers:** Stripe products and webhook not configured

---

## Service Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     Morphism Hub Application                     │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │   Clerk     │  │  Supabase   │  │   Stripe    │              │
│  │  Auth +     │  │  Database   │  │   Billing   │              │
│  │  Orgs       │  │  (PostgreSQL│  │             │              │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘              │
│         │                │                 │                     │
│         │    ┌───────────┼─────────────────┤                     │
│         │    │           │                 │                     │
│         ▼    ▼           ▼                 ▼                     │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              Next.js API Routes                          │   │
│  │  ┌──────────────┐ ┌──────────────┐ ┌─────────────────┐    │   │
│  │  │ /api/webhooks│ │ /api/billing│ │ /api/agents     │    │   │
│  │  │ (Clerk,Stripe)│ │            │ │ /api/assessment │    │   │
│  │  └──────────────┘ └──────────────┘ └─────────────────┘    │   │
│  └─────────────────────────────────────────────────────────┘   │
│                              │                                   │
│                              ▼                                   │
│                    ┌─────────────────┐                           │
│                    │   Gemini AI     │                           │
│                    │  (Risk Analysis │                           │
│                    │   & Governance) │                           │
│                    └─────────────────┘                           │
└─────────────────────────────────────────────────────────────────┘
```

---

## Environment Variables Status

### Configuration Files Analyzed

| File | Purpose | Placeholder Values |
|------|---------|-------------------|
| [`.env.local`](../morphism-hub/.env.local) | Local development secrets | Supabase, Stripe, Gemini placeholders |
| [`.env.local.example`](../morphism-hub/.env.local.example) | Template for env vars | All patterns documented |

### Complete Variable Matrix

| Variable | Required For | Current State | Source | Priority |
|----------|-------------|--------------|--------|----------|
| `NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY` | Client-side auth | ✅ Configured | Clerk Dashboard | — |
| `CLERK_SECRET_KEY` | Server-side auth | ✅ Configured | Clerk Dashboard | — |
| `CLERK_WEBHOOK_SECRET` | Org sync webhook | ❌ Missing | Clerk → Webhooks | 🔴 P0 |
| `NEXT_PUBLIC_SUPABASE_URL` | Database connection | ❌ Placeholder | Supabase → Settings → API | 🔴 P0 |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Client database | ❌ Placeholder | Supabase → Settings → API | 🔴 P0 |
| `SUPABASE_SERVICE_ROLE_KEY` | Admin operations | ❌ Placeholder | Supabase → Settings → API | 🔴 P0 |
| `GEMINI_API_KEY` | AI risk analysis | ❌ Missing | aistudio.google.com/apikey | 🟠 P2 |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Checkout UI | ❌ Placeholder | Stripe → API Keys | 🟠 P3 |
| `STRIPE_SECRET_KEY` | Billing operations | ❌ Placeholder | Stripe → API Keys | 🟠 P3 |
| `STRIPE_WEBHOOK_SECRET` | Subscription sync | ❌ Missing | Stripe → Webhooks | 🟠 P3 |
| `STRIPE_PRO_PRICE_ID` | Pro plan subscription | ❌ Missing | Stripe → Products | 🟠 P3 |
| `STRIPE_ENTERPRISE_PRICE_ID` | Enterprise plan | ❌ Missing | Stripe → Products | 🟠 P3 |

### Optional Variables (Not Critical)

| Variable | Default Behavior | Purpose |
|----------|-----------------|---------|
| `NEXT_PUBLIC_CLERK_SIGN_IN_URL` | `/sign-in` | Custom sign-in path |
| `NEXT_PUBLIC_CLERK_SIGN_UP_URL` | `/sign-up` | Custom sign-up path |
| `NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL` | `/dashboard` | Post-login redirect |
| `NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL` | `/dashboard` | Post-signup redirect |

---

## Service Deep Dives

### Supabase Database

#### Project Details

| Attribute | Value |
|----------|-------|
| **Project Name** | morphism-hub |
| **Project ID** | szvnlnmxlnhszbptvmut |
| **Organization** | morphism-systems |
| **Org ID** | yhosepgpkvpxwbqeothq |
| **Region** | AWS us-east-2 (Ohio) |
| **Plan** | Nano (FREE) |
| **Status** | Active, Healthy |
| **Dashboard** | https://supabase.com/dashboard/project/szvnlnmxlnhszbptvmut |

#### Required Credentials

```bash
# Project URL (already extracted)
NEXT_PUBLIC_SUPABASE_URL=https://szvnlnmxlnhszbptvmut.supabase.co

# Anon public key (need to copy from dashboard)
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_JTHlpSXrZfzanRJ9Yqw8cQ_xVTRz...

# Service role secret (copied to clipboard)
SUPABASE_SERVICE_ROLE_KEY=<from-clipboard>
```

#### Schema Status

- **File:** [`supabase/schema.sql`](../../morphism-hub/supabase/schema.sql)
- **Lines:** 254
- **Tables:** 6 (organizations, agents, assessments, governance_policies, audit_log, api_keys)
- **RLS Policies:** Enabled on all tables
- **Functions:** 3 (set_clerk_org_id, current_clerk_org_id, update_updated_at)
- **Indexes:** 8 optimized indexes
- **Triggers:** 4 updated_at triggers

**⚠️ Action Required:** Schema must be run in Supabase SQL Editor

---

### Clerk Authentication

#### Application Details

| Attribute | Value |
|----------|-------|
| **App Name** | Morphism Hub |
| **App ID** | app_39PIwZhOHijz67ZhyOBoOCtULcp |
| **Instance ID** | ins_39PIwVf3z1CeMtfevEfWtl89bUT |
| **Plan** | Hobby (Personal workspace) |
| **Status** | Active, No users yet |
| **Dashboard** | https://dashboard.clerk.com/apps/app_39PIwZhOHijz67ZhyOBoOCtULcp/instances/ins_39PIwVf3z1CeMtfevEfWtl89bUT |

#### Configured Credentials

```bash
# Already in .env.local ✅
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_d2FudGVkLWdsb3d3b3JtLTU1LmNsZXJrLmFjY291bnRzLmRldiQ
CLERK_SECRET_KEY=sk_test_6j6bz8yVH0zt82UGqFJKmemHC9WHMvEM3bl55JZ3JZ
```

#### Webhook Configuration Required

| Setting | Value |
|---------|-------|
| **Endpoint URL** | `https://morphism-hub.vercel.app/api/webhooks/clerk` |
| **Events Required** | `organization.created`, `organization.updated`, `organization.deleted` |
| **Signing Secret** | `whsec_...` (copy after creation) |
| **Dashboard** | https://dashboard.clerk.com/apps/app_39PIwZhOHijz67ZhyOBoOCtULcp/instances/ins_39PIwVf3z1CeMtfevEfWtl89bUT/webhooks |

**⚠️ Impact:** Without webhook, creating organizations in Clerk won't create matching rows in Supabase

---

### Stripe Billing

#### Account Details

| Attribute | Value |
|----------|-------|
| **Account Name** | Benchbarrier |
| **Account ID** | acct_1SliTfDJGc3SYHjN |
| **Mode** | Test Mode 🧪 |
| **Dashboard** | https://dashboard.stripe.com/acct_1SliTfDJGc3SYHjN/test/dashboard |
| **Status** | Needs business verification |

#### Available Keys

```bash
# Visible in dashboard (need to copy)
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_51SliTfDJGc3SYHjNRlsUMZwsxOTxORAG9uoY8wLyZxtr0yatL4eiXDykfbGqi6sfEVKJZubBQTnaJCKE170sM1o400M...
STRIPE_SECRET_KEY=sk_test_51SliTfDJGc3SYHjNWoJnNTFL1tKqP6ECnaR0qfzndNLYzdwC8wvOk8s1wZYinm9Nh9SbJuyT5CkQ1to4Eg8TS4q0000...
```

#### Plan Configuration

| Plan | Price | Monthly Cost | Price ID | Status |
|------|-------|--------------|----------|--------|
| **Free** | N/A | $0 | `null` | ✅ Built-in |
| **Pro** | $99/month | $99 | `price_...` | ❌ Not created |
| **Enterprise** | $499/month | $499 | `price_...` | ❌ Not created |

#### Webhook Configuration Required

| Setting | Value |
|---------|-------|
| **Endpoint URL** | `https://morphism-hub.vercel.app/api/webhooks/stripe` |
| **Events Required** | `checkout.session.completed`, `customer.subscription.created`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed` |
| **Signing Secret** | `whsec_...` (copy after creation) |

---

### Google Gemini AI

#### Configuration Status

| Attribute | Value |
|----------|-------|
| **Purpose** | Risk assessments, Governance validation |
| **Model Used** | `gemini-2.0-flash` |
| **Free Tier** | 15 RPM, 1M tokens/day |
| **Status** | ❌ No API key configured |

#### Required Credential

```bash
# Get from: https://aistudio.google.com/apikey
GEMINI_API_KEY=AIzaSy...
```

#### Functions Implemented

| Function | Purpose | File |
|----------|---------|------|
| [`assessRisk()`](../../morphism-hub/src/lib/ai.ts:13) | AI agent risk analysis | `src/lib/ai.ts` |
| [`validateGovernance()`](../../morphism-hub/src/lib/ai.ts:54) | Policy compliance validation | `src/lib/ai.ts` |

**⚠️ Impact:** AI features disabled without key (non-blocking for MVP)

---

## Code Architecture Analysis

### Supabase Integration Layer

#### Files Involved

| File | Purpose | Status |
|------|---------|--------|
| [`src/lib/supabase/server.ts`](../../morphism-hub/src/lib/supabase/server.ts) | Client creation, Admin client | ✅ Complete |
| Database types | TypeScript interfaces | ✅ Synced with schema |

#### Client Implementation

```typescript
// SSR Client with Clerk org context (lines 6-33)
export async function createSupabaseClient() {
  const cookieStore = await cookies()
  const { orgId } = await auth()

  const client = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    { /* cookies config */ }
  )

  // Set org context for RLS
  if (orgId) {
    await client.rpc('set_clerk_org_id', { org_id: orgId })
  }

  return client
}

// Admin client for webhooks (lines 35-41)
export function createAdminClient() {
  return createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  )
}
```

---

### Stripe Integration Layer

#### Files Involved

| File | Purpose | Status |
|------|---------|--------|
| [`src/lib/stripe.ts`](../../morphism-hub/src/lib/stripe.ts) | Client, Plans, Helpers | ✅ Complete |
| [`src/app/api/webhooks/stripe/route.ts`](../../morphism-hub/src/app/api/webhooks/stripe/route.ts) | Webhook handler | ✅ Complete |

#### Plan Definitions

```typescript
export const PLANS = {
  free: {
    name: 'Free',
    agentLimit: 5,
    priceId: null,
  },
  pro: {
    name: 'Pro',
    agentLimit: 50,
    priceId: process.env.STRIPE_PRO_PRICE_ID ?? null,
  },
  enterprise: {
    name: 'Enterprise',
    agentLimit: 1000,
    priceId: process.env.STRIPE_ENTERPRISE_PRICE_ID ?? null,
  },
} as const
```

#### Webhook Events Handled

| Event | Action | Lines |
|-------|--------|-------|
| `checkout.session.completed` | Activate subscription | 28-67 |
| `customer.subscription.updated` | Update plan limits | 70-86 |
| `customer.subscription.deleted` | Downgrade to free | 89-124 |
| `invoice.payment_failed` | Log failure | 127-150 |

---

### Authentication Middleware

#### File: [`src/middleware.ts`](../../morphism-hub/src/middleware.ts:1)

```typescript
export default clerkMiddleware(async (auth, req) => {
  // Allow webhook routes (no auth required)
  if (isWebhookRoute(req)) return
  
  // Protect dashboard routes
  if (isProtectedRoute(req)) {
    await auth.protect()
  }
})
```

#### Route Patterns

| Pattern | Protection |
|---------|------------|
| `/dashboard(.*)` | Authenticated users only |
| `/api/webhooks(.*)` | Webhook signatures only |
| `/api/(?!webhooks)(.*)` | Authenticated users |

---

## Webhook Configurations

### Clerk Webhook Handler

**File:** [`src/app/api/webhooks/clerk/route.ts`](../../morphism-hub/src/app/api/webhooks/clerk/route.ts)

#### Signature Verification

```typescript
const svix_id = req.headers.get('svix-id')
const svix_timestamp = req.headers.get('svix-timestamp')
const svix_signature = req.headers.get('svix-signature')

const wh = new Webhook(WEBHOOK_SECRET)
event = wh.verify(body, { 'svix-id': svix_id, ... }) as WebhookEvent
```

#### Events Handled

| Event | Database Action | Lines |
|-------|----------------|-------|
| `organization.created` | Insert new org | 42-53 |
| `organization.updated` | Update org name/slug | 55-63 |
| `organization.deleted` | Delete org | 65-73 |

---

### Stripe Webhook Handler

**File:** [`src/app/api/webhooks/stripe/route.ts`](../../morphism-hub/src/app/api/webhooks/stripe/route.ts)

#### Signature Verification

```typescript
const signature = req.headers.get('stripe-signature')
event = stripe.webhooks.constructEvent(
  body, 
  signature, 
  process.env.STRIPE_WEBHOOK_SECRET
)
```

#### Events Handled

| Event | Action |
|-------|--------|
| `checkout.session.completed` | Activate subscription, log audit |
| `customer.subscription.updated` | Update plan limits |
| `customer.subscription.deleted` | Downgrade to free |
| `invoice.payment_failed` | Log payment failure |

---

## Database Schema Reference

### Table: `organizations`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK, default: gen_random_uuid() | Primary key |
| `clerk_org_id` | text | UNIQUE, NOT NULL | Clerk org reference |
| `name` | text | NOT NULL | Display name |
| `slug` | text | NOT NULL | URL-friendly identifier |
| `plan` | text | NOT NULL, CHECK: free/pro/enterprise | Subscription tier |
| `agent_limit` | int | NOT NULL, default: 5 | Max agents allowed |
| `stripe_customer_id` | text | UNIQUE | Stripe customer reference |
| `stripe_subscription_id` | text | UNIQUE | Stripe subscription |
| `created_at` | timestamptz | NOT NULL, default: now() | Creation timestamp |
| `updated_at` | timestamptz | NOT NULL, default: now() | Modification timestamp |

### Table: `agents`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK | Agent identifier |
| `org_id` | uuid | FK → organizations(id), CASCADE delete | Organization ownership |
| `name` | text | NOT NULL | Agent name |
| `type` | text | NOT NULL | Agent classification |
| `model` | text | NOT NULL | AI model used |
| `description` | text | NULL | Optional description |
| `status` | text | NOT NULL, CHECK: active/inactive/error | Current state |
| `drift_score` | real | NOT NULL, default: 0 | Entropy measurement |
| `sessions_count` | int | NOT NULL, default: 0 | Usage tracking |
| `config` | jsonb | NOT NULL, default: '{}' | Configuration blob |
| `last_active` | timestamptz | NULL | Last activity time |

### Table: `assessments`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK | Assessment identifier |
| `org_id` | uuid | FK → organizations(id), CASCADE delete | Organization |
| `agent_id` | uuid | FK → agents(id), SET NULL on delete | Target agent |
| `title` | text | NOT NULL | Assessment name |
| `type` | text | NOT NULL, CHECK: risk/compliance/drift/governance | Assessment type |
| `status` | text | NOT NULL | Current state |
| `risk_score` | real | NULL | Calculated risk (0-100) |
| `findings` | jsonb | NULL | Risk findings array |
| `recommendations` | jsonb | NULL | Improvement suggestions |
| `completed_at` | timestamptz | NULL | Completion timestamp |

### Table: `governance_policies`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK | Policy identifier |
| `org_id` | uuid | FK → organizations(id), CASCADE delete | Organization |
| `name` | text | NOT NULL | Policy name |
| `description` | text | NULL | Optional description |
| `rules` | jsonb | NOT NULL, default: '[]' | Policy rules array |
| `is_active` | boolean | NOT NULL, default: true | Active status |
| `created_at` | timestamptz | NOT NULL | Creation timestamp |
| `updated_at` | timestamptz | NOT NULL | Modification timestamp |

### Table: `audit_log`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK | Log entry identifier |
| `org_id` | uuid | FK → organizations(id), CASCADE delete | Organization |
| `action` | text | NOT NULL | Action performed |
| `actor` | text | NOT NULL | Who performed it |
| `resource_type` | text | NOT NULL | Type of resource |
| `resource_id` | text | NULL | Resource identifier |
| `metadata` | jsonb | NULL | Additional context |
| `created_at` | timestamptz | NOT NULL | Timestamp |

### Table: `api_keys`

| Column | Type | Constraints | Purpose |
|--------|------|-------------|---------|
| `id` | uuid | PK | Key identifier |
| `org_id` | uuid | FK → organizations(id), CASCADE delete | Organization |
| `name` | text | NOT NULL | Key name/label |
| `key_hash` | text | NOT NULL, UNIQUE | Hashed key value |
| `prefix` | text | NOT NULL | Key prefix (for display) |
| `last_used_at` | timestamptz | NULL | Last usage timestamp |
| `created_at` | timestamptz | NOT NULL | Creation timestamp |

### Helper Functions

| Function | Returns | Purpose |
|----------|---------|---------|
| `set_clerk_org_id(org_id text)` | void | Sets Clerk org context for request |
| `current_clerk_org_id()` | text | Reads current org context for RLS |
| `update_updated_at()` | trigger | Auto-updates updated_at columns |

---

## Action Items Matrix

### Priority: Critical (Do First)

| # | Action | Service | Time | Owner | Status |
|---|--------|---------|------|-------|--------|
| 1 | Extract Supabase URL + Anon Key | Supabase | 2 min | User | ⏳ Waiting |
| 2 | Run schema.sql in Supabase SQL Editor | Supabase | 1 min | User | ⏳ Waiting |
| 3 | Configure Clerk webhook endpoint | Clerk | 3 min | User | ⏳ Waiting |
| 4 | Add CLERK_WEBHOOK_SECRET to env | Both | 1 min | AI | ⏳ Waiting |

### Priority: High (Before Testing)

| # | Action | Service | Time | Owner | Status |
|---|--------|---------|------|-------|--------|
| 5 | Get Gemini API key | Gemini | 2 min | User | ⏳ Waiting |
| 6 | Add GEMINI_API_KEY to env | Both | 1 min | AI | ⏳ Waiting |

### Priority: Medium (Before Production)

| # | Action | Service | Time | Owner | Status |
|---|--------|---------|------|-------|--------|
| 7 | Copy Stripe publishable key | Stripe | 1 min | User | ⏳ Waiting |
| 8 | Copy Stripe secret key | Stripe | 1 min | User | ⏳ Waiting |
| 9 | Create Pro product ($99/mo) | Stripe | 3 min | User | ⏳ Waiting |
| 10 | Create Enterprise product ($499/mo) | Stripe | 3 min | User | ⏳ Waiting |
| 11 | Configure Stripe webhook | Stripe | 3 min | User | ⏳ Waiting |
| 12 | Add all Stripe vars to env | Both | 2 min | AI | ⏳ Waiting |

### Total Estimated Time: ~20 minutes

---

## Launch Readiness Score

### Scoring Criteria

| Category | Weight | Score (0-100) |
|----------|--------|---------------|
| Database (Supabase) | 30% | 0 (blocked) |
| Authentication (Clerk) | 25% | 80 (missing webhook) |
| Billing (Stripe) | 25% | 30 (partial) |
| AI Features (Gemini) | 10% | 0 (no key) |
| Code Quality | 10% | 100 (complete) |

### Weighted Score: 40%

### Status Levels

| Score | Status | Description |
|-------|--------|-------------|
| 0-24% | 🔴 Critical | Major blockers exist |
| 25-49% | 🔴 High | Significant work remaining |
| 50-74% | 🟠 Medium | Most functionality works |
| 75-89% | 🟢 Near | Minor polish needed |
| 90-100% | ✅ Ready | Production ready |

### Current Status: 🔴 High Priority

---

## Quick Reference Links

### Service Dashboards

| Service | URL |
|---------|-----|
| Supabase | https://supabase.com/dashboard/project/szvnlnmxlnhszbptvmut |
| Clerk | https://dashboard.clerk.com/apps/app_39PIwZhOHijz67ZhyOBoOCtULcp |
| Stripe (Test) | https://dashboard.stripe.com/acct_1SliTfDJGc3SYHjN/test/dashboard |
| Google AI Studio | https://aistudio.google.com/apikey |
| Vercel | https://vercel.com/alawein-team/morphism-hub |

### Local Project Files

| File | Path |
|------|------|
| Environment Config | [`morphism-hub/.env.local`](../morphism-hub/.env.local) |
| Environment Template | [`morphism-hub/.env.local.example`](../morphism-hub/.env.local.example) |
| Database Schema | [`morphism-hub/supabase/schema.sql`](../morphism-hub/supabase/schema.sql) |
| Supabase Client | [`morphism-hub/src/lib/supabase/server.ts`](../../morphism-hub/src/lib/supabase/server.ts) |
| Stripe Library | [`morphism-hub/src/lib/stripe.ts`](../../morphism-hub/src/lib/stripe.ts) |
| AI Library | [`morphism-hub/src/lib/ai.ts`](../../morphism-hub/src/lib/ai.ts) |
| Clerk Webhook | [`morphism-hub/src/app/api/webhooks/clerk/route.ts`](../../morphism-hub/src/app/api/webhooks/clerk/route.ts) |
| Stripe Webhook | [`morphism-hub/src/app/api/webhooks/stripe/route.ts`](../../morphism-hub/src/app/api/webhooks/stripe/route.ts) |
| Middleware | [`morphism-hub/src/middleware.ts`](../../morphism-hub/src/middleware.ts) |

---

## Document Metadata

| Attribute | Value |
|-----------|-------|
| **Version** | 1.0 |
| **Created** | 2026-02-09 |
| **Author** | AI Assistant |
| **Mode** | Documentation Specialist |
| **Related Documents** | [Project Catalog](../../workspace/PROJECT_CATALOG.md), [Ecosystem Atlas](ECOSYSTEM_ATLAS.md) |
| **Next Review** | After all critical actions completed |

---

*This document is part of the Morphism ecosystem governance documentation. For questions or updates, refer to the [Contributing Guide](../../CONTRIBUTING.md).*

|
