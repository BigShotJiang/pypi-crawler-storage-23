# Testing and doc revision playbook

Single canonical sequence for running a full testing and documentation-revision pass. Use this when validating that tests pass, docs build, and links are consistent. Humans or AI agents can follow these steps in order.

**Authority:** [AGENTS.md](../AGENTS.md), [SSOT.md](../SSOT.md), [GUIDELINES.md](GUIDELINES.md). This playbook is non-normative operational guidance.

---

## Roles (agentic team)

| Role | Responsibility | Tool / artifact |
|------|----------------|-----------------|
| **Link checker** | Detect broken refs, orphans, cycles in `docs/` and root `.md`. | `python scripts/docs_graph.py --check` (optionally `--frontmatter`) |
| **Frontmatter validator** | Validate YAML frontmatter in docs. | `python scripts/docs_frontmatter.py --check` |
| **Test runner** | Python and (where available) TypeScript tests. | `pytest tests/` (pythonpath=src), `npx turbo typecheck lint test` (WSL/CI on Windows) |
| **Build validator** | Ensure MkDocs builds. | `mkdocs build --strict` |
| **Truth/doc reviewer** | Evidence-based claims, doc–code sync, SSOT. | Human or AI following the Truth Documentation Reviewer 5-phase process; see step 6 and [.morphism/ide-configs/claude/agents/truth-documentation-reviewer.md](../.morphism/ide-configs/claude/agents/truth-documentation-reviewer.md). |

---

## Ordered steps

Run from repo root. Exit 0 = success; non-zero = fix before merge (or document as known, e.g. archived link warnings).

### Step 1: Link check

**Agent:** Link checker (script).

```bash
python scripts/docs_graph.py --check
```

- **Expected:** Exit 0 if no broken refs in **non-archived** docs. Exit 1 if any broken ref in docs outside `docs/governance/audits`, `docs/governance/history`, `docs/implementation/workspace`, `docs/implementation/reports`, `docs/plans`.
- **Optional:** `python scripts/docs_graph.py --check --frontmatter` to also check frontmatter quality (warnings/errors to stderr).
- **Report (for inspection):** `python scripts/docs_graph.py --report` outputs JSON with `broken_refs`, `archived_broken_refs`, `cycles`.

### Step 2: Frontmatter check

**Agent:** Frontmatter validator (script).

```bash
python scripts/docs_frontmatter.py --check
```

- **Expected:** Exit 0 when frontmatter is valid; non-zero when required frontmatter is missing or invalid. See script help for `--add-stub` or `--report`.

### Step 3: Python tests

**Agent:** Test runner (pytest).

```bash
ruff check src/ tests/ && mypy src/ && pytest tests/
```

- **Expected:** Exit 0 when lint and tests pass. Use `PYTHONPATH=src` or `pip install -e .` if running from repo root so that `morphism` is importable.
- **Note:** CI runs this; see [.github/workflows/ci.yml](../.github/workflows/ci.yml).

### Step 4: MkDocs build

**Agent:** Build validator (mkdocs).

```bash
pip install mkdocs-material pymdown-extensions
mkdocs build --strict
```

- **Expected:** Exit 0 when the docs site builds. With `--strict`, MkDocs treats warnings as errors; you may see many (e.g. pages not in nav, broken links in archived/ssot docs). If the build aborts, run `mkdocs build` without `--strict` to confirm the site builds; fix nav or links to clear strict mode. CI (docs.yml) runs `mkdocs build --strict`.

### Step 5: TypeScript / Turbo (optional)

**Agent:** Test runner (turbo).

```bash
npx turbo typecheck lint test
```

- **Expected:** Exit 0 on Linux/CI. On Windows, Turbo may be unavailable (use WSL or rely on CI). See [AGENTS.md](../AGENTS.md) Commands.

### Step 6: Truth Documentation Review (optional)

**Agent:** Truth/doc reviewer (human or AI).

- **Spec:** [.morphism/ide-configs/claude/agents/truth-documentation-reviewer.md](../.morphism/ide-configs/claude/agents/truth-documentation-reviewer.md). Use the **"In morphism-systems repo"** block in that spec for paths and commands.
- **Morphism-specific commands:**
  - Canonical governance: [AGENTS.md](../AGENTS.md), [SSOT.md](../SSOT.md), [GUIDELINES.md](GUIDELINES.md).
  - Doc graph: `python scripts/docs_graph.py --check`.
  - Frontmatter: `python scripts/docs_frontmatter.py --check`.
  - Tenet/invariant context: [docs/governance/INVENTORY.md](governance/INVENTORY.md), [docs/governance/MORPHISM.md](governance/MORPHISM.md).
- **Purpose:** Evidence-based claims, doc–code sync, SSOT compliance. Run when doing a deep doc revision or before release.

---

## Known link warnings (archived docs)

Broken refs **inside** these directories are reported as warnings only and do not cause `docs_graph.py --check` to exit 1:

- `docs/governance/audits`
- `docs/governance/history`
- `docs/implementation/workspace`
- `docs/implementation/reports`
- `docs/plans`

To list them: `python scripts/docs_graph.py --report` and inspect `archived_broken_refs`. Fixing them is tracked in [docs/TODO.md](TODO.md) (P3). See [scripts/docs_graph.py](../scripts/docs_graph.py) for `ARCHIVE_DIRS`.

---

## Quick reference (one-liner sequence)

```bash
python scripts/docs_graph.py --check && \
python scripts/docs_frontmatter.py --check && \
ruff check src/ tests/ && mypy src/ && pytest tests/ && \
mkdocs build --strict
```

Add `npx turbo typecheck lint test` when Turbo is available (e.g. Linux/CI).

---

## Related

- **Workflow (high-level):** [.morphism/workflows/documentation-validation.md](../.morphism/workflows/documentation-validation.md).
- **CI:** [.github/workflows/docs.yml](../.github/workflows/docs.yml) runs link check and MkDocs build on `docs/**` changes.
- **Audit:** [docs/governance/audits/TEST_AND_CLAIMS_AUDIT.md](governance/audits/TEST_AND_CLAIMS_AUDIT.md) records tool and claims verification status.
