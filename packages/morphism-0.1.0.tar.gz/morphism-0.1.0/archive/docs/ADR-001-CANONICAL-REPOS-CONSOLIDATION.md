---
type: historical
authority: non-normative
audience: [contributors]
last-verified: 2026-02-20
---

# ADR-001: Canonical repos and artifact registry consolidation

> **NON-NORMATIVE.**

**Status:** Accepted  
**Date:** 2026-02-16  
**Operation:** Phase 2 `consolidate(repos) → canonical_registry`

---

## Context

Multiple repos and references exist under morphism-systems and related orgs. To satisfy GK invariants (SSOT, evidence per artifact, no orphaned artifacts), we need a single canonical list of production artifacts and clear consolidation rules.

## Decision

1. **Canonical product surfaces:** Three named surfaces — **hub**, **workspace**, **cli**.
   - **Hub:** Morphism SaaS application (Next.js) and @morphism-systems/sheaf; single repo `morphism-systems/hub` (or morphism if hub is alias). If both morphism and hub exist as separate clones of the same codebase, one is canonical and the other is archived or redirected.
   - **Workspace:** Governance repo `morphism-systems/workspace` — AGENTS.md, SSOT.md, .morphism config, scripts, docs. Single source for workspace layout and validation.
   - **CLI:** Enforcement CLI (init, validate, sync). May live inside workspace or as `morphism-systems/cli`; decision recorded in registry and implemented when package strategy is fixed.

2. **Unification repo:** `morphism-systems/mobius-morphism-unification` remains the framework source (morphism/ + integration/mobius/). Workspace and other consumers reference it via AGENTS.md/SSOT pointers; it is not the same artifact as “hub” (hub is the product app).

3. **Artifact registry:** Single machine-readable registry at `workspace/.morphism/ARTIFACT_REGISTRY.json` with fields: id, name, type, path, owner, evidence (ci, tests, deployment), status, default_branch. All canonical artifacts registered; deprecated/duplicate entries listed in `deprecated_or_archived`.

4. **Validation:** Existing `validate-registry.py` continues to validate UNIFIED_REGISTRY.json (component inventory) where present. ARTIFACT_REGISTRY.json is the GK canonical artifact list; scripts may be extended to validate registry ↔ repo list consistency (Phase 6 drift detector).

## Consequences

- READMEs and docs should link to canonical paths (e.g. github.com/morphism-systems/hub, github.com/morphism-systems/workspace).
- Duplicate repos (morphism vs hub if same code) are resolved by owner: archive one and point links to the other.
- New artifacts must be added to ARTIFACT_REGISTRY with evidence before being treated as canonical.
