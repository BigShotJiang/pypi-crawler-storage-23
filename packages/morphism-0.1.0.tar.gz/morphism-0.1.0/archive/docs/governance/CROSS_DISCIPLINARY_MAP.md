---
type: reference
authority: non-normative
audience: [agents, contributors]
last-verified: 2026-02-17
scope: governance
---

# Cross-disciplinary map: theory <-> Kernel <-> executable <-> rationale

> **NON-NORMATIVE.** This document makes explicit the links between the category-theoretic layer, the normative Kernel, the scripts/CI that enforce it, and the tenet derivations. Formal definitions and theorem statements: [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md). Normative requirements: [morphism-kernel.md](morphism-kernel.md).

---

## 1. Theory - Kernel - Executable - Rationale

Each row links a theory construct to the Kernel invariant(s), the scripts/CI that enforce it, the tenet rationale, and the formal Def/Theorem in [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md).

| Theory construct | Kernel | Executable (script / CI) | Rationale (tenet / derivation) | Formal (MORPHISM_FORMAL) |
|------------------|--------|---------------------------|---------------------------------|--------------------------|
| Category of context $\mathcal{C}$ (states, admissible morphisms) | I-1, I-3 | ssot_verify, validate_commit, drift-check | T1, T2, T3, T7; [TENET_DERIVATION.md](TENET_DERIVATION.md) | Def 2.4, 2.5, 2.7; Thm 1, 3 |
| Canonical source $\mathrm{src}(a)$; drift $\mathrm{drift}(s)$, staleness | I-1, I-2 | ssot_verify.py, ssot_extract.py, drift-check workflow | T1, T7; TENET_DERIVATION | Def 2.2, 2.3; Thm 1, 2 |
| Entropy functor $E$; $E(s') \leq E(s) + \epsilon$ | I-5 | maturity_score.py --ci --threshold 60 | T4, T8, T10; executive-overview; morphism-theory Section II | Def 2.8; Thm 5 |
| Governance monad $G$ (traces, unit, bind) | I-3 | commit-msg hook, validate_commit, CODEOWNERS, registry updates | T2, T3, T5, T9; morphism-theory Section III | Def 2.6, 2.9; Thm 3, 9 |
| Refusal $\mathcal{R}(s,f)$; Admit/Refuse; O(1); structured output | I-6 | policy_check.py --mode ci --explain | T4; executive-overview; morphism-theory Section IV | Def 2.10; Thm 6 |
| Scope declaration $\mathrm{scope}_{\mathrm{in}/\mathrm{out}}(P)$; scope binding | I-4 | PR review, executive-overview matrix | T3, T6, T9; morphism-theory Section V | Def 2.11; Thm 4 |
| Permission lattice; minimal authority | I-7 | verify_pipeline.py (CODEOWNERS) | T5; morphism-theory Section VII | Def 2.12; Thm 7 |
| Ideation algebra (sequential, product, limit, coproduct, policy) | I-4, I-7 | PR review, verify_pipeline.py | T3, T5, T6, T9; morphism-theory Section V, Section VII | Def 2.13 |

---

## 2. Read-Verify-Execute mapping

The protocol is defined in [morphism-kernel.md](morphism-kernel.md) and [MORPHISM.md](MORPHISM.md) Section 3. Formal admissibility conditions: [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) Def 2.5 (Read, Verify, Execute; drift empty, no stale, scope respected, minimal authority).

| Phase | Meaning | Scripts / artifacts |
|-------|---------|----------------------|
| **READ** | Establish current state, entropy bounds, scope constraints | Load AGENTS.md, SSOT.md, GUIDELINES.md, HANDOFF.md, TODO.md; read SSOT registry and config |
| **VERIFY** | Check: valid state output? entropy preserved ($E(s') \leq E(s) + \epsilon$)? scope respected? $\mathrm{drift}(s') = \emptyset$? no stale assertions? minimal authority? | ssot_verify.py (registry vs content); policy_check.py (branch, commit, secrets, SSOT); maturity_score.py --ci (threshold); PR review and executive-overview matrix |
| **EXECUTE** | Apply change; record input state, rule applied, output state, evidence | Commit (with message validated by validate_commit); SSOT registry update (ssot_extract.py); ADR entry when amending governance |

Executing without completing Verify is undefined behavior; violations discovered mid-Execute must produce rollback, not silent partial commit.

---

## 3. One paragraph per invariant

Each invariant is linked to its formal definitions and theorem in [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) (Def / Thm), executable enforcement (scripts/CI), and rationale (tenets and [TENET_DERIVATION.md](TENET_DERIVATION.md)).

- **I-1 One Truth Per Domain:** **Formal:** Def 2.2 (canonical source), Thm 1 (uniqueness). Enforced by `ssot_verify.py`, `docs_sync.py --check`, and drift-check CI; justified by T1, T6, T7 and TENET_DERIVATION.
- **I-2 Drift Is Debt:** **Formal:** Def 2.3 (derived artifacts, drift, staleness), Def 2.5 (admissible merge gating), Thm 2 (drift blocks admissible merge). Enforced by drift-check workflow and `ssot_extract.py`; justified by T1, T7.
- **I-3 Observability:** **Formal:** Def 2.6 (trace), Def 2.9 (governance monad G), Thm 3 (every admissible transition has a trace), Thm 9 (monad laws). Enforced by commit-msg hook, `validate_commit.py`, CODEOWNERS; justified by T2, T3, T5, T9.
- **I-4 Scope Binding:** **Formal:** Def 2.11 (scope declaration, binding, scope drift), Thm 4 (scope binding and refusal for out-of-scope). Enforced by PR review and executive-overview matrix; justified by T3, T6, T9.
- **I-5 Entropy Monotonicity:** **Formal:** Def 2.8 (entropy functor E, monotonicity condition), Thm 5 ($E(s') \leq E(s) + \epsilon$). Enforced by `maturity_score.py --ci --threshold 60`; justified by T4, T8, T10 and morphism-theory Section II.
- **I-6 Refusal as Structure:** **Formal:** Def 2.10 (refusal decision $\mathcal{R}$, totality, structured output, O(1)), Thm 6 (totality, structure, cost). Enforced by `policy_check.py --mode ci --explain`; justified by T4.
- **I-7 Minimal Authority:** **Formal:** Def 2.12 (permission lattice, minimal authority), Thm 7 (minimal assignment, critical-path coverage). Enforced by `verify_pipeline.py` (CODEOWNERS); justified by T5 and morphism-theory Section VII.

---

## 4. Invariant -> formal reference (quick lookup)

| Invariant | MORPHISM_FORMAL definitions | MORPHISM_FORMAL theorem |
|-----------|-----------------------------|-------------------------|
| I-1 One Truth Per Domain | 2.2 (canonical source) | Thm 1 |
| I-2 Drift Is Debt | 2.3 (drift, staleness), 2.5 (merge gating) | Thm 2 |
| I-3 Observability | 2.6 (trace), 2.9 (monad G) | Thm 3, 9 |
| I-4 Scope Binding | 2.11 (scope declaration, binding) | Thm 4 |
| I-5 Entropy Monotonicity | 2.8 (entropy E) | Thm 5 |
| I-6 Refusal as Structure | 2.10 (refusal R) | Thm 6 |
| I-7 Minimal Authority | 2.12 (permission, minimal authority) | Thm 7 |

Design target (convergence): MORPHISM_FORMAL Thm 8.

---

## 5. Related documents

| Document | Role |
|----------|------|
| [morphism-kernel.md](morphism-kernel.md) | Normative invariants and protocol. |
| [MORPHISM_FORMAL.md](MORPHISM_FORMAL.md) | Formal definitions and theorem statements; source for Def/Thm references above. |
| [MORPHISM.md](MORPHISM.md) | Framework reference; protocol in practice. |
| [INVENTORY.md](INVENTORY.md) | Consistency matrix (theory <-> Kernel <-> tenets). |
| [TENET_DERIVATION.md](TENET_DERIVATION.md) | Derivation traces tenet <-> invariant. |
| [ALGORITHMIC_VALIDATION.md](ALGORITHMIC_VALIDATION.md) | How scripts implement E, R, drift, trace. |
| [PROOF_STRATEGIES.md](PROOF_STRATEGIES.md) | Tactics and strategies per Def/Thm (Lean 4 + Mathlib4). |
| [EXAMPLES.md](EXAMPLES.md) | Concrete examples for category, E, R, G, ideation algebra. |

---

*Normative: [morphism-kernel.md](morphism-kernel.md)*
