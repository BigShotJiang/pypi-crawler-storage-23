# Morphism Website Redesign — Design Brief

**Scope:** Morphism product site ([apps/morphism](../../apps/morphism)), live at https://morphism.systems.  
**Purpose:** Single source for a full redesign; hand off to developer or AI to build from scratch.

### Gap priority (for builders)

Fill in this order so the builder can make consistent decisions:

1. **Fill first** (affects every design decision):  
   `visual.colorPreferences` · `visual.darkLightMode` · `visual.density` · `brand.targetAudience`
2. **Fill second** (affects layout and structure):  
   `currentSite.conversionGoals` · `currentSite.likes` · `currentSite.dislikes` · `visual.aestheticReferences` (3–5 URLs)
3. **Can defer:**  
   Mission/value proposition (copy only), competitors, testimonials/images/video.

### Design direction decision

Two aesthetic references exist: **(A) Current live “Violet Theorem”** — glassmorphism, purple gradient mesh, low-density (see [DESIGN_REDESIGN_SUMMARY.md](../../apps/morphism/DESIGN_REDESIGN_SUMMARY.md)). **(B) Terminal aesthetic** — high-density, terminal/code-first feel (if built as a separate artifact, point the builder at it).

**If the terminal redesign is the new direction:** Treat it as the source of truth for color, dark/light, and density; the builder can close `visual.colorPreferences`, `visual.darkLightMode`, and `visual.density` by following that artifact.  
**If Violet Theorem remains the direction:** Keep those gaps and fill them explicitly (e.g. “keep purple”, “dark only”, “low-density”).

### Fill-first intake (four answers = brief unblocked)

Answer these four; the builder can then proceed.

| # | Question | Answer |
|---|----------|--------|
| 1 | **Color:** Keep Violet Theorem (purple/glassmorphism) or shift to the terminal aesthetic (dark, lime/monospace, high-density)? | **Terminal** — dark, lime/monospace, high-density. |
| 2 | **Dark/light mode:** Dark only, or both? | **Dark only.** |
| 3 | **Density:** Atmospheric and spacious (current) or information-dense (terminal)? | **Information-dense (terminal).** |
| 4 | **Target audience:** Who is actually buying this — eng leads, CTOs, compliance teams? Startups or enterprise? | **Eng leads and CTOs** (primary); compliance teams (secondary). **Startups to mid-market** first; enterprise for compliance and scale. |

### Fill-second intake (four answers = layout & hero locked)

| # | Question | Answer |
|---|----------|--------|
| 1 | **Conversion goals:** What should visitors do? (e.g. sign up, request beta, contact sales — pick primary) | *[ANSWER]* |
| 2 | **Likes:** What do you want to preserve from the current design? | *[ANSWER]* |
| 3 | **Dislikes:** What should the builder scrap or avoid? | *[ANSWER]* |
| 4 | **Aesthetic references:** 3–5 URLs of sites you like (communicates faster than words) | *[ANSWER]* |

---

## 1. Brand & Identity

| Field | Value |
|-------|--------|
| **Company name** | Morphism |
| **Tagline** | Structure-Preserving Transformations |
| **One-line description** | AI governance with mathematical guarantees. 7 Kernel invariants and 10 operational tenets; κ < 1 design target; formal verification on roadmap. Monitor, validate, and enforce governance policies across your AI agents. |
| **Mission statement** | *[GAP: Provide mission statement]* |
| **Core value proposition** | *[GAP: Beyond one-line above]* |
| **Target audience** | Eng leads and CTOs (primary); compliance secondary. Startups to mid-market first; enterprise for compliance and scale. |
| **Brand personality** | *[GAP: 3–5 adjectives]* |
| **Fonts** | Terminal: Mono primary (JetBrains Mono or Fira Code); DM Sans for small UI labels only. |
| **Brand guidelines / logo / palette** | *[GAP: Any beyond repo]* |

**Logo:** Current SVG in `src/components/logo.tsx` (MorphismLogo + MorphismWordmark). Favicon: `public/favicon.svg` (blue theme). *[GAP: Keep or provide new SVG]*

---

## 2. Current Site Audit

| Field | Value |
|-------|--------|
| **URL** | https://morphism.systems |
| **Live fetch** | Timed out; audit based on repo and DESIGN_REDESIGN_SUMMARY. |
| **Summary** | Landing: violet/purple glassmorphism, hero with gradient text, stats bar (7 invariants, 10 tenets, κ < 1 design target, H(Γ(s)) ≤ H(s)), capabilities, how-it-works, flywheel, features, math section, pricing, CTA, footer. Beta page uses gray/blue (inconsistent with landing). See [RECONCILIATION_REPORT](../governance/RECONCILIATION_REPORT.md) for claim wording. |

**Pages (from repo):**

| Path | Purpose |
|------|---------|
| `/` | Landing / marketing homepage |
| `/docs` | API reference documentation |
| `/beta` | Beta signup form |
| `/beta/thank-you` | Beta confirmation |
| `/sign-in` | Clerk sign-in |
| `/sign-up` | Clerk sign-up |
| `/onboarding` | Post-signup onboarding (team size, LLM providers, pain point) |
| `/dashboard` | Dashboard overview |
| `/dashboard/agents` | Agent management |
| `/dashboard/assessments` | Assessments |
| `/dashboard/policies` | Policies |
| `/dashboard/billing` | Billing / plans |
| `/dashboard/settings` | Settings (API keys, feedback) |

- **Conversion goals:** *[GAP: What should visitors do?]*  
- **Likes:** *[GAP]*  
- **Dislikes:** *[GAP]*  
- **Pages to add / remove / restructure:** *[GAP]*

---

## 3. Content

### Headlines (from landing)

- Hero: **The Self-Healing Intelligence Layer** for AI Agent Fleets  
- Sub: Mathematically-proven governance. Autonomous correction. Compound learning.  
- Mono: Not heuristics. Theorems with proofs.  
- Capabilities: The Self-Healing Stack  
- How it works: LLM Entropy & Deterministic Degradation  
- Flywheel: Gets Better With Every Interaction  
- Features: Production-Ready from Day One  
- Math: Not heuristics. Theorems with proofs.  
- Pricing: Simple, transparent pricing  
- CTA: Deploy Your Self-Healing Fleet  

### Stats (aligned with [RECONCILIATION_REPORT](../governance/RECONCILIATION_REPORT.md))

- 7 — Kernel Invariants  
- 10 — Operational Tenets  
- κ < 1 — Convergence (design target)  
- H(Γ(s)) ≤ H(s) — Entropy Reduction  

### CTAs

- Primary: Start Free / Start Free Trial / Get Started  
- Secondary: View Demo → / Request Beta Access →  
- Nav: Get Started  
- Pricing: Start Free, Start Free Trial, Contact Sales  

### Code / formulas (to render)

- Entropy: `S(session) = -k Σ pᵢ ln(pᵢ)`; comment: With Morphism: H(Γ(s)) ≤ H(s) → convergence  
- Agentic Uncertainty: Cert_p × Cert_r ≥ ℏ_agent  
- Lean 4: `theorem iterate_converges_to_fixed_point (Γ : GovernanceOperator) (κ : Γ.contraction_constant < 1) : ∃! x, Γ x = x ∧ ∀ x₀, Γ^n x₀ → x`  

### Pricing tiers (full feature lists)

- **Starter** — $499/mo: Up to 10 developers, Core tenet enforcement, Basic entropy monitoring, Dashboard access, Community support, Self-healing capabilities. CTA: Start Free.  
- **Professional** — $2,999/mo (highlighted): Up to 50 developers, Full self-healing suite, Advanced analytics & ROI, Custom tenet integration, Proof state library, API + CLI, Priority support. CTA: Start Free Trial.  
- **Enterprise** — Custom: Unlimited developers, On-premise, Dedicated success manager, Custom proof development, SLA 99.9%, SSO/SAML, SOC 2. CTA: Contact Sales.  

*[GAP: Confirm or revise pricing and features.]*

### Navigation

- Landing: Capabilities, How it works, Mathematics, Pricing, Docs, Sign in, Get Started  
- Footer: GitHub, API Docs, Beta, Contact  
- Dashboard: Overview, Agents, Assessments, Policies, Billing, Settings  

### Forms

- **Beta form:** firstName, lastName, email, company, teamSize (1–5 … 200+), agentCount (1–5 … 100+), painPoint (textarea). Submit: Request Beta Access →  
- **Onboarding:** team_size, llm_providers (multi), pain_point (from PAIN_POINTS). 3 steps.  

### Testimonials / social proof

*[GAP: None in repo; add if desired.]*

---

## 4. Visual Direction

**Current (from repo):** Violet Theorem — purple/violet/magenta, glassmorphism, grain, Playfair Display + DM Sans + JetBrains Mono, dark gradient mesh, gradient text, scroll/hover animations.

- **Aesthetic references:** *[GAP: Sites you like, URLs or screenshots]*  
- **Color preferences:** Terminal — dark, lime/monospace, high-density.  
- **Dark/light mode:** Dark only.  
- **Typography:** *[GAP: Serif/sans/mono, personality]*  
- **Density:** Information-dense (terminal).  
- **Motifs (terminal direction):** Math (formulas, Lean), code blocks, terminal/CLI UI. Drop glassmorphism and grain for the redesign.

### Terminal design tokens (use for redesign)

Builder-ready tokens from the chosen direction (dark, lime, monospace, information-dense):

| Token | Value | Use |
|-------|--------|-----|
| **Background** | `#0d1117` (GitHub dark) or `#0a0e14` | Page/surface |
| **Surface** | `#161b22` | Cards, panels |
| **Border** | `#30363d` | Dividers, inputs |
| **Text primary** | `#e6edf3` | Headings, body |
| **Text muted** | `#8b949e` | Captions, labels |
| **Accent (lime)** | `#84cc16` (Tailwind lime-500) or `#a3e635` (lime-400) | CTAs, links, highlights |
| **Accent dim** | `#65a30d` | Hover, secondary accent |
| **Mono font** | JetBrains Mono or Fira Code | Body + code (terminal feel) |
| **Sans (optional)** | DM Sans or system UI | Small labels only |
| **Spacing** | Tighter than current; e.g. section `py-12` not `py-32`, card `p-6` not `p-10` | Information-dense |

**Reference (legacy Violet Theorem):** Violet 50–950, mesh #0a0118→#2d1b4e, gradient text purple→magenta. See tailwind.config / globals.css if reverting.

### Typography (terminal direction)

- **Primary:** Monospace (JetBrains Mono or Fira Code) for headings and body — terminal feel.  
- **Secondary:** Sans (DM Sans or system) for nav labels, buttons, small UI only.  
- **Code:** Same mono; syntax highlighting with lime accent.

### Spacing / components (terminal direction)

- **Density:** Reduced vertical rhythm; compact sections and cards.  
- **Cards/panels:** Flat or subtle border (`border border-[#30363d]`), no glass blur.  
- **Buttons:** Solid lime accent or outline; no gradient.  
- **Code blocks:** Dark surface, lime/green accents for keywords, white/gray for text.  

---

## 5. Technical Constraints

| Field | Value |
|-------|--------|
| **Framework** | Next.js 15 (React 19) |
| **Hosting** | *[GAP: Current or target]* |
| **Component libraries** | lucide-react. *[GAP: Design system]* |
| **Responsive** | *[GAP: Mobile-first or desktop-first]* |
| **Performance** | *[GAP]* |
| **Accessibility** | *[GAP]* |

**Existing stack:** Tailwind CSS, Clerk, Supabase, Stripe, Sentry, @morphism-systems/shared. Components: logo, scroll-animation, error-boundary.

---

## 6. Assets

| Asset | Status |
|-------|--------|
| **Logo** | Existing: `src/components/logo.tsx`. *[GAP: Keep or new SVG]* |
| **Icons** | lucide-react. *[GAP: Custom icons/illustrations]* |
| **Images** | None on landing. *[GAP]* |
| **Video** | None. *[GAP]* |
| **Favicon** | `public/favicon.svg` (blue). *[GAP: Align or replace]* |

---

## 7. Competitive Context

- **Competitor URLs:** *[GAP: 3–5]*  
- **Differentiation:** *[GAP: How to differentiate visually]*  
- **Conventions:** *[GAP: Follow or break]*  

---

## 8. Deliverables (pages & sections)

| Page | Layout | Key content | Primary action | Interactives | Forms |
|------|--------|-------------|----------------|--------------|--------|
| Landing | Single-page, anchored sections | Hero, stats, capabilities, how-it-works, flywheel, features, math, pricing, CTA | Sign up / Get Started | Scroll animations, hover, anchor links | — |
| Docs | Doc layout | API reference | Use API | — | — |
| Beta | Centered form | Headline, form, stats (≤72h, 90 days, κ<1) | Submit beta request | — | Beta form (see §3) |
| Beta thank-you | Centered message | Confirmation, Back to Home, GitHub | Back to Home | — | — |
| Dashboard | Sidebar + main | Overview, agents, assessments, policies, billing, settings | Use product | Nav, UserButton | Onboarding (first time) |

*[GAP: Per-page layout preference, key content, primary action; modals, tabs, accordions, animations; any other forms.]*

---

## 9. Gaps (missing information)

Fill these to complete the brief for a builder. **Order matters:** see [Gap priority](#gap-priority-for-builders) above.

| Priority | Section | Field | Note |
|----------|---------|--------|------|
| ~~Fill first~~ ✓ | visual | colorPreferences | **Closed:** Terminal — dark, lime, monospace |
| ~~Fill first~~ ✓ | visual | darkLightMode | **Closed:** Dark only |
| ~~Fill first~~ ✓ | visual | density | **Closed:** Information-dense (terminal) |
| ~~Fill first~~ ✓ | brand | targetAudience | **Closed:** Eng leads/CTOs; compliance secondary; startups→enterprise |
| **Fill second** | currentSite | conversionGoals | Primary CTA drives hero design |
| **Fill second** | currentSite | likes | What to preserve |
| **Fill second** | currentSite | dislikes | What to scrap |
| **Fill second** | visual | aestheticReferences | 3–5 URLs — communicates faster than words |
| — | brand | mission | Provide mission statement (copy; can defer) |
| — | brand | valueProposition | Core value proposition (copy; can defer) |
| — | brand | personality | 3–5 adjectives |
| — | brand | fonts | Confirm Playfair/DM Sans/JetBrains or change |
| — | brand | logoNotes | Keep current logo or provide new SVG |
| — | currentSite | pagesToAddRemoveRestructure | Pages to add, remove, or restructure |
| — | content | testimonials | Add testimonials, logos, social proof (can defer) |
| — | content | pricing | Confirm or revise pricing tiers and features |
| — | visual | typography | Serif/sans/mono, personality |
| — | technical | hosting | Deployment target |
| — | technical | componentLibraries | Design system to use |
| — | technical | responsive | Mobile-first or desktop-first |
| — | technical | performance | Performance constraints |
| — | technical | accessibility | Accessibility requirements |
| — | assets | icons | Custom icons or illustrations |
| — | assets | images | Images to include (can defer) |
| — | assets | video | Video or animation assets (can defer) |
| — | assets | favicon | Align favicon with palette or replace |
| — | competitive | competitorUrls | 3–5 competitor URLs (can defer) |
| — | competitive | differentiation | How to differentiate visually (can defer) |
| — | competitive | conventions | Industry conventions to follow or break (can defer) |
| — | deliverables | gapsPerPage | Per-page layout, interactives, forms if different |

---

### What we need from you next

To lock layout and hero design, answer the **fill-second intake** (table above):

1. **Conversion goals** — What should visitors do? (e.g. “Sign up” vs “Request beta” as primary CTA.)  
2. **Likes** — What to preserve from the current design.  
3. **Dislikes** — What to scrap or avoid.  
4. **Aesthetic references** — 3–5 URLs of sites you like.

Reply with those four and we’ll close the fill-second gaps and the brief is ready for build.

---

**Machine-readable brief:** [design-brief.json](design-brief.json)
