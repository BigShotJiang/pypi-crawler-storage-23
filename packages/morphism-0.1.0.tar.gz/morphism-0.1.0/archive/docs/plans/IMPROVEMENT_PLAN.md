# 🚀 Dario Amodei Best Practices Implementation Plan

## Current Assessment

### ✅ Already Strong
- **Governance**: Excellent AGENTS.md structure with category theory framework
- **Organization**: Clear directory hierarchy (Products/, Research/, Tools/, Personal/)
- **Validation**: Comprehensive `.validation/` scripts exist
- **Documentation**: MORPHISM.md, docs/ directory with detailed refs

### ❌ Gaps from Dario's Principles
1. **No `.claude/skills/` directory** - Missing reusable workflows
2. **No `.claude/agents/` directory** - Missing custom subagents
3. **CLAUDE.md lacks verification examples** - Not following "give Claude a way to verify"
4. **No explicit hooks configuration** - Missing deterministic validations
5. **No plugin infrastructure** - If developing Claude Code plugins
6. **MCP servers undocumented** - 57 servers exist, but no central reference for Claude Code

---

## Implementation Roadmap

### 🔴 Phase 1: Verification-First Philosophy (Highest Impact)
**Goal**: Implement Principle #1 - "Give Claude a Way to Verify Its Work"

**Files to Create/Modify**:
1. **`.claude/CLAUDE.md`** (NEW)
   - Project-level overrides for Claude Code
   - Explicitly document verification commands
   - Include examples of test runs, screenshots, output validation

2. **Enhance `/GitHub/CLAUDE.md`**
   - Add section: "How to Verify Your Work"
   - Link verification commands per project
   - Include permission allowlists

**Example Content**:
```markdown
## Verification Commands

### For morphism/
- Tests: `cd Products/morphism && pnpm validate`
- Structure: `pnpm validate:structure`
- Take screenshot of Morphism dashboard after changes

### For Research projects/
- Physics: `cd Research/qaplibria && pytest tests/`
- Screenshots: Visualizations must load without errors
```

**Deliverable**: CLAUDE.md that makes verification first-class requirement

---

### 🟡 Phase 2: Create Domain Knowledge Skills (High Impact)
**Goal**: Implement Principle #10 - "Create Skills for Domain Knowledge"

**Skills to Create** (`.claude/skills/`):

#### 1. **category-theory-conventions/SKILL.md**
```markdown
---
name: category-theory-conventions
description: Category theory conventions and verification for morphism framework
---
When working with categorical concepts:
1. Reference MORPHISM.md for definitions (don't trust training data)
2. Verify composition laws: F∘G must compose correctly
3. Check functor laws: preserve structure, identity, composition
4. Use MCP morphism-validator server
5. Link tenet references (kernel/docs/TENETS_OVERVIEW.md)
```

#### 2. **physics-conventions/SKILL.md**
```markdown
---
name: physics-conventions
description: Physics, materials science, quantum computing conventions
---
When working with physics-adjacent code:
1. Check unit consistency (eV, meV, eV/Å, etc.)
2. Verify DFT assumptions (pseudopotential, exchange-correlation)
3. Validate quantum gate operations
4. Link to Research/*/docs/ for domain-specific guidance
```

#### 3. **morphism-validation-protocol/SKILL.md**
```markdown
---
name: morphism-validation-protocol
description: Complete workflow for validating morphism changes
---
Before pushing changes:
1. Run `.validation/validate-all.sh`
2. Check tenet drift: `pnpm morphism:validate`
3. Verify MCP server configs (no secrets exposed)
4. Type-check: `pnpm validate`
5. Test each category: Products/, Research/, Tools/
```

**Location**: Create `.claude/skills/` directory with subdirectories for each skill

**Deliverable**: Reusable skills that Claude Code can invoke with `/skill-name`

---

### 🟡 Phase 3: Custom Subagents (Medium Impact)
**Goal**: Implement Principle #11 - "Create Custom Subagents"

**Agents to Create** (`.claude/agents/`):

#### 1. **tenet-reviewer.md**
```markdown
---
name: tenet-reviewer
description: Reviews code changes against 42 morphism tenets
tools: Read, Grep, Glob
model: opus
---
You are a morphism framework architect. Review code changes:
1. Load kernel/docs/TENETS_OVERVIEW.md
2. Check which tenets apply to changes
3. Verify no tenets are violated
4. Suggest improvements aligned with framework
5. Link to MORPHISM.md if tenets are unclear
```

#### 2. **documentation-auditor.md**
```markdown
---
name: documentation-auditor
description: Audits documentation completeness and accuracy
tools: Read, Grep, Glob
---
Audit documentation:
1. Check doc exists for major components
2. Verify examples run without error
3. Check for outdated references
4. Ensure doc matches code reality
5. Flag missing edge case documentation
```

#### 3. **physics-reviewer.md**
```markdown
---
name: physics-reviewer
description: Reviews physics/materials science code for correctness
tools: Read, Grep, Glob
model: opus
---
Review physics code:
1. Check unit consistency throughout
2. Verify physical laws are respected
3. Validate DFT/quantum conventions
4. Reference Research/*/docs/ for standards
```

**Location**: Create `.claude/agents/` directory

**Deliverable**: Invoke with subagent tool for specialized reviews

---

### 🟢 Phase 4: Hooks & Automation (Optional but Valuable)
**Goal**: Implement Principle #9 - "Set Up Hooks"

**Hooks to Configure** (`.claude/hooks.json` or interactive setup):

```json
{
  "PreToolUse": [
    {
      "condition": "tool_name == 'Bash' && args.command.includes('git push')",
      "action": "require_git_status_clean",
      "message": "Check git status first to avoid accidents"
    },
    {
      "condition": "tool_name == 'Bash' && args.command.includes('rm -rf')",
      "action": "block",
      "message": "Destructive operations blocked—use /clear instead"
    }
  ]
}
```

**Deliverable**: Interactive hook configuration via `/hooks` command

---

### 🔵 Phase 5: Plugin Infrastructure (If Developing Plugins)
**Goal**: Support creation of Claude Code plugins

**Files to Create**:

1. **`.claude/plugin-templates/`** directory with:
   - Skill template
   - Agent template
   - Hook template
   - MCP integration template

2. **`PLUGIN_DEVELOPMENT_GUIDE.md`**
   - How to create a plugin
   - Testing plugins locally
   - Publishing to Claude Code plugin marketplace

**Deliverable**: Plugin development template + guide

---

## Implementation Steps

### Week 1: Phase 1 (Verification-First)
```bash
# Create .claude directory structure
mkdir -p /GitHub/.claude/{skills,agents,hooks,templates}

# Create CLAUDE.md with verification commands
# Reference: Ubuntu-24.04.txt Principle #5 & #1
```

### Week 2-3: Phase 2-3 (Skills & Agents)
```bash
# Create skills directory
touch .claude/skills/category-theory-conventions/SKILL.md
touch .claude/skills/physics-conventions/SKILL.md
touch .claude/skills/morphism-validation-protocol/SKILL.md

# Create agents directory
touch .claude/agents/tenet-reviewer.md
touch .claude/agents/documentation-auditor.md
touch .claude/agents/physics-reviewer.md
```

### Week 4: Phase 4-5 (Optional)
- Configure hooks via `/hooks`
- Create plugin templates
- Write plugin development guide

---

## Quick Wins (Can Do Today)

1. **Create `.claude/CLAUDE.md`** (5 min)
   ```markdown
   # Morphism Workspace - Claude Code Config

   See root [AGENTS.md](../../AGENTS.md) for governance.

   ## Verification Commands
   - `make verify-all` (all projects)
   - `pnpm validate` (type + lint + test)
   - `pnpm morphism:validate` (tenet checking)
   ```

2. **Create `.claude/VERIFICATION.md`** (10 min)
   - Document all test commands per project
   - Add screenshot examples for UI changes
   - Include expected outputs

3. **Update root CLAUDE.md** (5 min)
   - Add permissions section
   - Link to `.claude/` subdirectory

4. **Update `/GitHub/AGENTS.md`** (5 min)
   - Add references to skills, agents when created
   - Add MCP server inventory link

---

## Expected Outcomes

### After Phase 1
- Claude Code users get clear verification path
- Fewer iterations needed to get correct changes
- Tests/validation are first-class requirements

### After Phase 2-3
- Reusable workflows reduce repetition
- Custom agents handle specialized reviews
- Better code quality through tenet checking

### After Phase 4-5
- Automated validations via hooks
- Plugin development is self-serve
- Cleaner commit history (fewer fix-commit cycles)

---

## Key References from Dario's Guide

| Principle | Implementation |
|-----------|-----------------|
| #1: Give Claude a way to verify | CLAUDE.md + verification commands |
| #5: Write effective CLAUDE.md | `.claude/CLAUDE.md` + project overrides |
| #10: Create Skills | `.claude/skills/` with 3+ domain skills |
| #11: Create Subagents | `.claude/agents/` with specialized reviewers |
| #9: Set Up Hooks | Interactive hook configuration |

---

## Files to Edit/Create Summary

```
/GitHub/
├── .claude/ (CREATE if missing)
│   ├── CLAUDE.md (NEW) - verification-first philosophy
│   ├── VERIFICATION.md (NEW) - all test commands
│   ├── skills/
│   │   ├── category-theory-conventions/SKILL.md (NEW)
│   │   ├── physics-conventions/SKILL.md (NEW)
│   │   └── morphism-validation-protocol/SKILL.md (NEW)
│   └── agents/
│       ├── tenet-reviewer.md (NEW)
│       ├── documentation-auditor.md (NEW)
│       └── physics-reviewer.md (NEW)
├── AGENTS.md (ENHANCE) - add skill/agent references
├── CLAUDE.md (ENHANCE) - add .claude/ reference
└── IMPROVEMENT_PLAN.md (THIS FILE)
```

---

**Created**: 2025-02-05
**Source**: Dario Amodei's Best Practices (Ubuntu-24.04.txt)
**Next Step**: Start with Phase 1 (CLAUDE.md + verification examples)
