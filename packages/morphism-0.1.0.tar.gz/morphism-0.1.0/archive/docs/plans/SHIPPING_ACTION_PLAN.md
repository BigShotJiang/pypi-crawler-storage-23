# Shipping Action Plan

**Generated:** 2026-02-08  
**Priority:** Immediate to Long-term  

---

## 🚀 PHASE 1: IMMEDIATE (This Week)

### Priority 1A: Deploy Web Platforms (Days 1-2)

| # | Project | Action | Estimated Time | Blockers |
|---|---------|--------|----------------|----------|
| 1 | **BOLTS.FIT** | Deploy to Vercel production | 2 hours | Environment variables |
| 2 | **LLMWorks** | Deploy to Vercel production | 2 hours | Domain configuration |

**Pre-deployment Checklist:**
- [ ] Verify environment variables
- [ ] Run final tests
- [ ] Check Stripe webhooks
- [ ] Verify Supabase connections
- [ ] Enable Vercel analytics

---

### Priority 1B: Publish Python Library (Day 3)

| # | Project | Action | Estimated Time | Blockers |
|---|---------|--------|----------------|----------|
| 3 | **QAPlibria** | Publish to PyPI | 1 hour | PyPI credentials |

**Steps:**
1. Build package: `python -m build`
2. Upload to TestPyPI: `twine upload --repository testpypi dist/*`
3. Verify installation from TestPyPI
4. Upload to PyPI: `twine upload dist/*`
5. Verify: `pip install qaplibria`

---

### Priority 1C: Publish CLI Tools (Days 4-5)

| # | Project | Action | Estimated Time | Blockers |
|---|---------|--------|----------------|----------|
| 4 | **@morphism-systems/tools** | Publish to npm | 30 min | npm credentials |
| 5 | **@morphism-systems/mcp** | Publish to npm | 30 min | npm credentials |
| 6 | **@morphism-systems/core** | Publish to npm | 30 min | npm credentials |
| 7 | **KiloCode Hub CLI** | Verify npm publish | 30 min | Already v1.0.0 |

**npm Publishing Steps:**
```bash
cd <package-directory>
npm version patch  # if needed
npm run build      # if build script exists
npm publish --access public
```

---

## 📦 PHASE 2: SHORT-TERM (Next 2 Weeks)

### Priority 2A: Ready for Publication

| # | Project | Action | Estimated Time |
|---|---------|--------|----------------|
| 8 | **Agent Context Optimizer** | Final testing + npm publish | 4 hours |
| 9 | **Monorepo Health Analyzer** | Final testing + npm publish | 4 hours |

**Tasks:**
- [ ] Run full test suites
- [ ] Update README with examples
- [ ] Add CHANGELOG.md
- [ ] Verify CLI commands work
- [ ] Publish to npm

---

### Priority 2B: Template Publication

| # | Template | Action | Estimated Time |
|---|----------|--------|----------------|
| 10 | **REST API Template** | Document + publish | 2 hours |
| 11 | **SaaS Template** | Document + publish | 2 hours |

**Publication Options:**
- GitHub Template Repository
- npm init template
- Vercel template marketplace

---

## 🔍 PHASE 3: ASSESSMENT (Week 3-4)

### Priority 3: Desktop Projects

| # | Project | Action | Purpose |
|---|---------|--------|---------|
| 12 | **REPZ** | Deep technical audit | Determine shippable status |
| 13 | **SparkFit** | Verify duplicate status | Merge with BOLTS.FIT or differentiate |

**REPZ Assessment Checklist:**
- [ ] Review all JSON schemas
- [ ] Check frontend completeness
- [ ] Verify Supabase setup
- [ ] Test PDF generation
- [ ] Assess deployment readiness

---

## 🛠️ PHASE 4: DEVELOPMENT (Month 2)

### Priority 4A: Morphism Framework

| # | Project | Target Version | Key Milestones |
|---|---------|----------------|----------------|
| 14 | **Morphism Hub** | v1.0.0 | Complete auth, dashboard, billing |
| 15 | **Morphism Site** | v1.0.0 | Marketing pages, docs, blog |
| 16 | **Morphism Framework** | v1.0.0 | Stable API, full test coverage |

### Priority 4B: Remaining Hub Packages

| # | Package | Status | Action |
|---|---------|--------|--------|
| 17 | morphism-agentic-math | Development | Complete core algorithms |
| 18 | morphism-audit | Development | Add audit rules |
| 19 | morphism-plugin | Development | Finalize plugin API |

---

## 📊 SHIPPING METRICS

### Week 1 Goals
- [ ] 2 Web platforms deployed
- [ ] 1 Python library on PyPI
- [ ] 3 npm packages published

### Month 1 Goals
- [ ] 10 production projects shipped
- [ ] 2 additional CLI tools published
- [ ] 2 templates published
- [ ] Desktop projects assessed

### Quarter 1 Goals
- [ ] Morphism Framework v1.0.0
- [ ] Morphism Hub live
- [ ] 15+ total projects shipped

---

## 🎯 PRIORITY MATRIX

```
                    HIGH IMPACT
                         │
    BOLTS.FIT           │    QAPlibria
    LLMWorks            │    @morphism-systems/tools
    ────────────────────┼────────────────────
    @morphism-systems/mcp      │    Brand Kit
    @morphism-systems/core     │    Codemap
                         │
                    LOW IMPACT
           LOW EFFORT  │  HIGH EFFORT
```

**Ship First:** Top-right quadrant (High Impact, Low Effort)

---

## 📋 DAILY SHIPPING CHECKLIST

```markdown
## Today I'm Shipping: [PROJECT NAME]

### Morning (9 AM)
- [ ] Review code one final time
- [ ] Run all tests
- [ ] Check for sensitive data

### Mid-day (12 PM)
- [ ] Build/package project
- [ ] Write release notes
- [ ] Update version number

### Afternoon (3 PM)
- [ ] Deploy/Publish
- [ ] Verify it works
- [ ] Announce in #shipped channel

### Evening (5 PM)
- [ ] Monitor metrics
- [ ] Respond to issues
- [ ] Document learnings
```

---

## 🚨 BLOCKERS & DEPENDENCIES

### Current Blockers
| Blocker | Affects | Resolution |
|---------|---------|------------|
| Environment variables | BOLTS.FIT, LLMWorks | Document in .env.example |
| npm credentials | 6 packages | Verify npm login |
| PyPI credentials | QAPlibria | Generate API token |

### Dependencies
```
@morphism-systems/mcp depends on @morphism-systems/core
Morphism Hub depends on @morphism-systems/tools
Templates depend on stable framework
```

---

## 📈 SUCCESS METRICS

| Metric | Target | Current | Status |
|--------|--------|---------|--------|
| Production Projects | 10 | 0 | 🟡 In Progress |
| npm Packages | 8 | 3 | 🟡 In Progress |
| PyPI Packages | 1 | 0 | 🟡 In Progress |
| Deployed Web Apps | 2 | 0 | 🟡 In Progress |

---

*Plan Created: 2026-02-08*  
*Review Weekly*
