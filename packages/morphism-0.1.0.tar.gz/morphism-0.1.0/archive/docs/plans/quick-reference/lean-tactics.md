# Lean 4 Tactics Cheat Sheet

## Core Tactics for Proof Engineering

### Elementary Tactics
```lean
intro          -- Introduce hypothesis
apply          -- Apply theorem to goal
exact          -- Give exact term
refine         -- Partial term with holes
simp           -- Simplify using lemmas
rw [h]         -- Rewrite with hypothesis
```

### Category Theory Tactics
```lean
ext            -- Extensionality (for natural transformations)
dsimp          -- Simplify definitions
unfold         -- Unfold definition
change         -- Change goal to equivalent form
```

### Existence & Uniqueness
```lean
use x          -- Provide witness for existence
existsi x      -- Introduce existence witness
cases h with   -- Destruct existence proof
```

### Equality Tactics
```lean
rfl            -- Reflexivity
congr          -- Congruence
apply_fun f    -- Apply function to both sides
```

## Common Patterns

### 1. Proving Natural Transformation Equality
```lean
ext x
simp [naturality]
```

### 2. Working with Functors
```lean
dsimp [F.map]
rw [comp_h]
```

### 3. Universal Properties
```lean
apply IsLimit.isLimit
intro m
use <morphism>
```

## Sheaf Theory Specific

### Gluing Proofs
```lean
-- Construct glued section
use <glued_section>
intro i
-- Show restriction property
simp [restriction_map, hcompatible]
```

### Compatibility Conditions
```lean
intro i j
simp [F.map, inclusion]
rw [hcompat]
```

## Debugging Commands

```lean
#check theorem_name    -- Check type
#print definition      -- Print definition
#eval term            -- Evaluate term
set_option pp.all true -- Show full details
```

## Proof State Navigation

```lean
{ n }                 -- Go to nth goal
-                     -- Focus on current goal
done                  -- Check if all goals solved
```

## Common Lemmas

```lean
functor.map_id        -- Identity law
functor.map_comp      -- Composition law
NatTrans.ext          -- Extensionality
```

## Tips for Productivity

1. Use `simp?` to find simplification lemmas
2. Use `exact?` to suggest exact terms
3. Use `apply?` for applicable theorems
4. Break complex proofs into `have` lemmas
5. Use `by` tactics for structured proofs

## Resources

- [Lean 4 Documentation](https://lean-lang.org/)
- [Mathlib Documentation](https://leanprover-community.github.io/mathlib_docs/)
- [Category Theory in Lean](https://github.com/leanprover-community/mathlib/blob/master/Mathlib/CategoryTheory)
