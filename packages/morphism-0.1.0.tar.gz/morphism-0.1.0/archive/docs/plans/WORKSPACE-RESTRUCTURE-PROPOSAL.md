# Workspace Restructure Proposal — Morphism Framework Isolation

**Date:** February 8, 2026
**Status:** 📋 Proposal — Awaiting Review
**Objective:** Separate Morphism framework source from workspace consumption

---

## Problem Statement

The workspace currently treats itself AS the Morphism framework:
- Root `AGENTS.md` is a pointer to `morphism/AGENTS.md` (workspace = framework)
- Root `SSOT.md` is a pointer to `morphism/SSOT.md`
- Root `README.md` says "governance has one home: morphism/"
- `.morphism/` config references `MORPHISM.md` as if it's a local file

This creates three problems:
1. **No independent development** — Non-Morphism projects (bolts, llmworks, etc.) inherit framework governance they don't need
2. **No dogfooding** — We can't demonstrate the customer experience of adopting Morphism externally
3. **No clear boundary** — Framework source code, consumer config, and unrelated projects are mixed at root level

---

## Current State Classification

### Layer 1: Morphism Framework Source (what we ship)
```
morphism/                    ← Self-contained framework repo
├── MORPHISM.md              ← The SSOT (in live repo: 7 invariants → 10 tenets)
├── AGENTS.md                ← Framework development governance
├── CLAUDE.md                ← Framework Claude config
├── SSOT.md                  ← Authority declarations
├── kernel/                  ← Governance core (policies, contracts, templates)
├── hub/                     ← Publishable packages + apps
│   ├── packages/            ← morphism-tools, morphism-core, morphism-mcp, etc.
│   └── apps/                ← meshal-web, morphism-web
├── lab/                     ← Experiments (agents, proofs, research)
├── profile/                 ← Personal contributor profile
├── package.json             ← pnpm workspace root
└── pnpm-workspace.yaml      ← hub/packages/*, hub/apps/*, lab/*
```
Already has its own repo URL: `https://github.com/alawein/morphism.git`

### Layer 2: Workspace Consumer Config (how this workspace uses Morphism)
```
.morphism/                   ← Consumer-side governance config
├── config.json              ← Discovery rules, validation settings
├── agents/                  ← Workspace-specific agent definitions
├── hooks/                   ← Workspace-specific git hooks
├── schemas/                 ← Validation schemas
├── workflows/               ← Orchestration patterns
├── extensions/              ← MCP servers, plugins
└── inventory/               ← Component registry
```

### Layer 3: Morphism Ecosystem Projects (consume Morphism governance)
```
morphism-bible/              ← Canon docs, packages (morphism-framework, morphism-integrations)
morphism-hub/              ← Next.js SaaS app (Supabase)
morphism-ship/               ← Governed extension lane (hub/lab/profile)
```

### Layer 4: Personal / Non-Morphism
```
morphism-profile/            ← Job applications, resume, personal data
morphism-references/         ← Reference materials (agentic-formal)
_projects/                   ← Non-Morphism projects:
  ├── aiclairty/             ← Web app
  ├── bolts/                 ← Next.js platform
  ├── brand-kit/             ← Python package
  ├── codemap/               ← Python package
  └── llmworks/              ← Full-stack app
agent-context-optimizer/     ← Standalone tool
monorepo-health-analyzer/    ← Standalone tool
```

### Layer 5: Workspace Infrastructure
```
docs/                        ← Workspace docs (audits, history, plans, setup)
scripts/                     ← Workspace scripts (governance, migration, health)
templates/                   ← GitHub governance templates
lib/                         ← Workspace CLI support
archive/                     ← Runtime artifacts, trash
_archive/                    ← Archived projects
```

---

## Proposed Changes

### Semantic Shift (The Core Change)

**Before:** Workspace IS the Morphism framework
**After:** Workspace USES the Morphism framework

This requires changes to 4 root files and 1 config file. No file moves required for Phase 1.

---

### Phase 1: Decouple Root Governance (Low Risk)

**Goal:** Root files declare the workspace as a Morphism CONSUMER, not the framework itself.

#### 1.1 Rewrite `AGENTS.md` (root)

**Before:** Pointer to `morphism/AGENTS.md`
**After:** Workspace governance doc that references Morphism as an adopted standard

```markdown
# AGENTS — Workspace Governance

This workspace adopts the **Morphism Categorical Governance Framework**.

## Governance Source
- Framework SSOT: `morphism/MORPHISM.md`
- Framework rules: `morphism/AGENTS.md`
- Consumer config: `.morphism/`

## Workspace Scope
- **Framework development:** `morphism/` follows its own AGENTS.md
- **Morphism ecosystem:** `morphism-bible/`, `morphism-hub/`, `morphism-ship/` follow Morphism governance
- **Other projects:** `_projects/*` are independent — Morphism governance is optional
- **Personal:** `morphism-profile/`, `morphism-references/` are out of governance scope

## Consumer Protocol (Tenets 54-58)
1. Read MORPHISM.md before governance reasoning
2. State the one thing
3. Verify the path
4. Execute incrementally
5. Refuse scope creep
```

#### 1.2 Rewrite `SSOT.md` (root)

**Before:** Pointer to `morphism/SSOT.md`
**After:** Workspace SSOT that declares Morphism as the governance standard

```markdown
# SSOT — Workspace Authority

## Governance Framework
This workspace adopts Morphism governance. The canonical framework is at:
- Framework definitions: `morphism/MORPHISM.md`
- Framework scope: `morphism/SSOT.md`

## Workspace Configuration
- Consumer config: `.morphism/config.json`
- Workspace layout: `docs/workspace/WORKSPACE_LAYOUT.md`

## Scope Boundaries
- Framework source: `morphism/` (independent, self-governed)
- Governed projects: `morphism-bible/`, `morphism-hub/`, `morphism-ship/`
- Independent projects: `_projects/*`
- Out of scope: `morphism-profile/`, `morphism-references/`, `archive/`, `_archive/`
```

#### 1.3 Update `CLAUDE.md` (root)

**Before:** References `morphism/AGENTS.md` as the canonical source
**After:** References workspace governance with Morphism as an adopted framework

#### 1.4 Update `.morphism/config.json`

Add a `frameworkSource` field to explicitly declare where Morphism is:

```json
{
  "frameworkSource": {
    "type": "local",
    "path": "./morphism",
    "note": "Local development mode. For production: type=npm, package=morphism-tools"
  }
}
```

#### 1.5 Update `.morphism/README.md`

Clarify that `.morphism/` is the **consumer configuration directory** — what any
workspace creates when it adopts Morphism governance. This is NOT the framework source.

---

### Phase 2: Clean Root Clutter (Medium Risk)

**Goal:** Move workspace-level docs out of root into proper locations.

| File | Action | Destination |
|------|--------|-------------|
| `ARCHITECTURE.md` | Move | `docs/workspace/ARCHITECTURE.md` |
| `CANONICAL_STRUCTURE.md` | Archive | `_archive/CANONICAL_STRUCTURE.md` (superseded by this proposal) |
| `CONTRIBUTING.md` | Move | `docs/CONTRIBUTING.md` (already exists there) — delete root copy |
| `DOCUMENTATION-CONSOLIDATION-COMPLETE.md` | Archive | `_archive/` |
| `DOCUMENTATION-STYLE-GUIDE.md` | Move | `docs/reference/DOCUMENTATION-STYLE-GUIDE.md` |
| `PROJECT_CATALOG.md` | Move | `docs/workspace/PROJECT_CATALOG.md` |
| `PROMPTS/` | Keep | Stays at root (used actively) |
| `commands.sh` | Move | `scripts/commands.sh` |
| `workspace.bat` | Move | `scripts/workspace.bat` |
| `lib/` | Keep | Stays at root (used by `./workspace` CLI) |
| `package.json` (root) | Keep | Stays (workspace-level dependency: docx) |
| `package-lock.json` (root) | Keep | Stays |

**Resulting root after Phase 2:**
```
GitHub/
├── .morphism/               ← Consumer governance config
├── morphism/                ← Framework source (independent)
├── morphism-bible/          ← Morphism ecosystem project
├── morphism-hub/          ← Morphism ecosystem project
├── morphism-ship/           ← Morphism ecosystem project
├── morphism-profile/        ← Personal (out of scope)
├── morphism-references/     ← Personal (out of scope)
├── _projects/               ← Non-Morphism projects
├── _archive/                ← Archived projects
├── archive/                 ← Runtime artifacts
├── docs/                    ← Workspace documentation
├── scripts/                 ← Workspace automation
├── templates/               ← Shared templates
├── lib/                     ← Workspace CLI support
├── PROMPTS/                 ← LLM prompts
├── AGENTS.md                ← Workspace governance (consumer)
├── CLAUDE.md                ← Claude config (consumer)
├── SSOT.md                  ← Workspace SSOT (consumer)
├── README.md                ← Workspace overview
├── package.json             ← Workspace dependencies
└── package-lock.json
```

---

### Phase 3: Consumer Experience Pattern (Low Risk)

**Goal:** Demonstrate how an external user would adopt Morphism.

#### How External Users Would Adopt Morphism

```bash
# 1. Install the framework CLI
npm install -D morphism-tools

# 2. Initialize consumer config
npx morphism init
# Creates .morphism/ with:
#   config.json, agents/, hooks/, schemas/, workflows/

# 3. Configure governance level
npx morphism config --level standard
# Options: minimal | standard | strict

# 4. Validate against Morphism tenets
npx morphism validate
npx morphism drift check
```

#### How THIS Workspace Does It (Dogfooding)

Since `morphism/` is co-located for development, we use pnpm workspace linking:

```json
// Root package.json addition:
{
  "devDependencies": {
    "morphism-tools": "workspace:morphism/hub/packages/morphism-tools"
  }
}
```

Or in `.morphism/config.json`:
```json
{
  "frameworkSource": {
    "type": "local",
    "path": "./morphism"
  }
}
```

This means:
- During **development**, the workspace uses the local `morphism/` directory
- During **CI/production**, it would use the published npm package
- The **experience is identical** — `.morphism/` config is the same either way

---

## Migration Plan

### Execution Order

| Step | Phase | Risk | Description | Reversible? |
|------|-------|------|-------------|-------------|
| 1 | 1.1 | Low | Rewrite root `AGENTS.md` | Yes (git revert) |
| 2 | 1.2 | Low | Rewrite root `SSOT.md` | Yes |
| 3 | 1.3 | Low | Update root `CLAUDE.md` | Yes |
| 4 | 1.4 | Low | Update `.morphism/config.json` | Yes |
| 5 | 1.5 | Low | Update `.morphism/README.md` | Yes |
| 6 | 2 | Med | Move root docs to proper locations | Yes (git revert) |
| 7 | 3 | Low | Document consumer pattern | Yes |

### What Does NOT Move

- `morphism/` — stays exactly where it is (it's already self-contained)
- `.morphism/` — stays (this IS the consumer config)
- `morphism-bible/`, `morphism-hub/`, `morphism-ship/` — stay at root (they're independent repos)
- `morphism-profile/`, `morphism-references/` — stay at root (independent repos)
- `_projects/` — stays
- `docs/`, `scripts/`, `templates/` — stay

### What Changes

1. **Root `AGENTS.md`** — From pointer to consumer governance doc
2. **Root `SSOT.md`** — From pointer to consumer SSOT
3. **Root `CLAUDE.md`** — From framework config to consumer config
4. **`.morphism/config.json`** — Add `frameworkSource` field
5. **`.morphism/README.md`** — Clarify consumer role
6. **Root `README.md`** — Update to reflect consumer pattern
7. **6 root files** — Move to proper locations (Phase 2)

---

## Success Criteria

- [ ] Root `AGENTS.md` describes workspace governance (not a pointer)
- [ ] Root `SSOT.md` declares Morphism as adopted framework (not a pointer)
- [ ] `.morphism/config.json` explicitly declares framework source location
- [ ] `morphism/` remains completely self-contained and unchanged
- [ ] Non-Morphism projects in `_projects/` are clearly outside governance scope
- [ ] A developer reading root files understands: "this workspace USES Morphism"
- [ ] Root directory has ≤15 entries (down from current ~25+)

---

## What This Enables

1. **Independent Development:** `_projects/bolts/` can be developed without knowing Morphism exists
2. **Dogfooding:** `.morphism/` demonstrates exactly what external users would set up
3. **Framework Publishing:** `morphism/` can be published independently — nothing outside it needs to change
4. **Clear Onboarding:** New developers see "this workspace uses Morphism governance" not "this IS Morphism"
5. **Scope Control:** AI agents see workspace-level rules, not framework development rules

