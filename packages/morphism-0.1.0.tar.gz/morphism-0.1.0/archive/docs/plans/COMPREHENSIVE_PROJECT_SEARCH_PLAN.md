# Comprehensive Project Search Plan

**Generated:** 2026-02-08  
**Purpose:** Find ALL projects, MVPs, platforms, tools across all locations

---

## 🎯 SEARCH SCOPE

### Primary Locations (Must Search)

| Location | Type | Priority | Search Command |
|----------|------|----------|----------------|
| `c:/Users/mesha/Desktop/GitHub/` | GitHub Workspace | 🔴 Critical | Recursive |
| `C:/Users/mesha/Desktop/` | Desktop Root | 🔴 Critical | Recursive |
| `C:/home/meshal/` | WSL Home | 🔴 Critical | Recursive |
| `C:/Users/mesha/` | User Profile | 🟡 Important | Recursive |
| `D:/` (if exists) | Additional Drive | 🟡 Important | Check exists |

### Secondary Locations (If Exist)

| Location | Type | Priority | Search Command |
|----------|------|----------|----------------|
| `C:/Users/mesha/OneDrive/` | OneDrive | 🟢 Medium | Check exists |
| `C:/Users/mesha/Dropbox/` | Dropbox | 🟢 Medium | Check exists |
| `C:/Users/mesha/Google Drive/` | Google Drive | 🟢 Medium | Check exists |
| `~/.ssh/` or `C:/Users/mesha/.ssh/` | SSH Keys | 🟢 Medium | Check config |

---

## 📋 SEARCH EXECUTION PLAN

### Phase 1: File-Based Discovery

#### 1.1 Package.json Search (Node.js Projects)
```bash
# Find ALL package.json files
find /mnt/c/Users/mesha -name "package.json" -type f 2>/dev/null

# Specifically in GitHub workspace
find /mnt/c/Users/mesha/Desktop/GitHub -name "package.json" -type f

# In Desktop
find /mnt/c/Users/mesha/Desktop -name "package.json" -type f

# In WSL
find /home/meshal -name "package.json" -type f
```

#### 1.2 pyproject.toml Search (Python Projects)
```bash
# Find ALL pyproject.toml files
find /mnt/c/Users/mesha -name "pyproject.toml" -type f 2>/dev/null

# Find setup.py files (legacy Python packages)
find /mnt/c/Users/mesha -name "setup.py" -type f 2>/dev/null

# Find requirements.txt (look for -r flags or base deps)
find /mnt/c/Users/mesha -name "requirements*.txt" -type f 2>/dev/null
```

#### 1.3 Cargo.toml Search (Rust Projects)
```bash
# Find ALL Cargo.toml files
find /mnt/c/Users/mesha -name "Cargo.toml" -type f 2>/dev/null
```

#### 1.4 go.mod Search (Go Projects)
```bash
# Find ALL go.mod files
find /mnt/c/Users/mesha -name "go.mod" -type f 2>/dev/null
```

---

### Phase 2: Directory Pattern Search

#### 2.1 Common Project Patterns
```bash
# Look for project indicators
find /mnt/c/Users/mesha -type d -name "*project*" 2>/dev/null
find /mnt/c/Users/mesha -type d -name "*app*" 2>/dev/null
find /mnt/c/Users/mesha -type d -name "*platform*" 2>/dev/null
find /mnt/c/Users/mesha -type d -name "*tool*" 2>/dev/null

# Look for version control (git repositories)
find /mnt/c/Users/mesha -name ".git" -type d 2>/dev/null

# Look for build artifacts
find /mnt/c/Users/mesha -name "dist" -type d 2>/dev/null
find /mnt/c/Users/mesha -name "build" -type d 2>/dev/null
find /mnt/c/Users/mesha -name "out" -type d 2>/dev/null
```

#### 2.2 Hidden Directories (Important for configurations)
```bash
# Look for hidden project directories
find /mnt/c/Users/mesha -maxdepth 4 -type d -name ".*" 2>/dev/null

# Check .config directories
find /mnt/c/Users/mesha -name ".config" -type d 2>/dev/null
```

---

### Phase 3: GitHub & Cloud Repository Search

#### 3.1 GitHub Organizations
```bash
# Check GitHub CLI for all accessible repos
gh repo list --limit 1000

# Check for specific organizations
gh org list

# Search for user repos
gh api user/repos -q '.[].full_name'
```

#### 3.2 GitLab Repositories
```bash
# Check for GitLab CLI
glab repo list --all 2>/dev/null || echo "GLab not installed"

# Search for .gitlab-ci.yml files
find /mnt/c/Users/mesha -name ".gitlab-ci.yml" -type f 2>/dev/null
```

#### 3.3 Bitbucket Repositories
```bash
# Check for BB CLI
bb repo list 2>/dev/null || echo "BB CLI not installed"
```

---

### Phase 4: IDE & Editor Project Search

#### 4.1 VSCode Workspaces
```bash
# Find VSCode workspace files
find /mnt/c/Users/mesha -name "*.code-workspace" -type f 2>/dev/null

# Find VSCode settings
find /mnt/c/Users/mesha/.vscode -name "settings.json" 2>/dev/null

# Find recent projects
cat /mnt/c/Users/mesha/AppData/Roaming/Code/User/workspaceStorage/*/settings.json 2>/dev/null
```

#### 4.2 Cursor IDE Projects
```bash
# Find Cursor workspace storage
find /mnt/c/Users/mesha/AppData/Roaming/Cursor -name "*.code-workspace" 2>/dev/null

# Find Cursor recent projects
cat /mnt/c/Users/mesha/AppData/Roaming/Cursor/User/workspaceStorage/*/settings.json 2>/dev/null
```

#### 4.3 JetBrains IDEs
```bash
# Find JetBrains project files
find /mnt/c/Users/mesha -name "*.iml" -type f 2>/dev/null

# Find JetBrains recent projects
cat /mnt/c/Users/mesha/.local/share/JetBrains/*/options/recentProjects.xml 2>/dev/null
```

---

### Phase 5: Archive & Backup Search

#### 5.1 Archive Directories
```bash
# Check for archive directories
find /mnt/c/Users/mesha/Desktop/GitHub/archive -type f -name "*.zip" 2>/dev/null
find /mnt/c/Users/mesha/Desktop/GitHub/backups -type f 2>/dev/null

# Check for tar.gz files (backups)
find /mnt/c/Users/mesha/Desktop/GitHub/backups -name "*.tar.gz" 2>/dev/null
```

#### 5.2 Trash/Recycle Search
```bash
# Check for deleted projects (Windows Recycle Bin)
# Located at: C:/$Recycle.Bin/

# Check for local trash
find /mnt/c/Users/mesha -name "*trash*" -type d 2>/dev/null
find /mnt/c/Users/mesha -name "*deleted*" -type d 2>/dev/null
```

---

## 🔍 SPECIFIC SEARCH COMMANDS

### Quick Discovery Commands (Run First)
```bash
# One-liner to find all package.json files
find /mnt/c/Users/mesha -name "package.json" -type f 2>/dev/null

# One-liner to find all pyproject.toml files
find /mnt/c/Users/mesha -name "pyproject.toml" -type f 2>/dev/null

# Find all git repositories
find /mnt/c/Users/mesha -name ".git" -type d 2>/dev/null

# Find all .gitignore files (indicates project root)
find /mnt/c/Users/mesha -name ".gitignore" -type f 2>/dev/null
```

### Deep Discovery Commands (Run After Quick)
```bash
# Find all README files (indicates project)
find /mnt/c/Users/mesha -name "README.md" -type f 2>/dev/null

# Find all index.html files (web projects)
find /mnt/c/Users/mesha -name "index.html" -type f 2>/dev/null

# Find all __init__.py files (Python packages)
find /mnt/c/Users/mesha -name "__init__.py" -type f 2>/dev/null

# Find all tsconfig.json files (TypeScript projects)
find /mnt/c/Users/mesha -name "tsconfig.json" -type f 2>/dev/null
```

---

## 📊 OUTPUT & CATEGORIZATION

### Required Output Format
```markdown
## Project: [PROJECT_NAME]

| Field | Value |
|-------|-------|
| Full Path | /absolute/path/to/project |
| Type | Web/CLI/Library/Agent/Platform |
| Language | Python/TypeScript/JavaScript/Rust/Go |
| Package.json | Yes/No |
| pyproject.toml | Yes/No |
| Version | From package.json/pyproject.toml |
| Dependencies | Count |
| Last Modified | Date |
| Git Repository | Yes/No |
| Shippable | Yes/No/Partial |
| Notes | Any relevant notes |
```

### Categorization Criteria

#### Shippable = Yes
- Has package.json with version OR pyproject.toml with version
- Builds successfully
- Has tests or examples
- Documentation present

#### Shippable = Partial
- Has package.json OR pyproject.toml
- Builds with issues OR missing tests
- Partial documentation

#### Shippable = No
- No package manifest
- Missing critical components
- Incomplete project

---

## 🚀 AUTOMATED SCRIPT

### Create and Run Discovery Script
```bash
#!/bin/bash
# Project Discovery Script
# Run this to find ALL projects

echo "=== PROJECT DISCOVERY REPORT ===" > project_discovery_report.md
echo "Generated: $(date)" >> project_discovery_report.md
echo "" >> project_discovery_report.md

# Package.json files
echo "## Node.js Projects (package.json)" >> project_discovery_report.md
find /mnt/c/Users/mesha -name "package.json" -type f 2>/dev/null >> project_discovery_report.md
echo "" >> project_discovery_report.md

# pyproject.toml files
echo "## Python Projects (pyproject.toml)" >> project_discovery_report.md
find /mnt/c/Users/mesha -name "pyproject.toml" -type f 2>/dev/null >> project_discovery_report.md
echo "" >> project_discovery_report.md

# Git repositories
echo "## Git Repositories (.git)" >> project_discovery_report.md
find /mnt/c/Users/mesha -name ".git" -type d 2>/dev/null >> project_discovery_report.md
echo "" >> project_discovery_report.md

# README files
echo "## Projects (README.md)" >> project_discovery_report.md
find /mnt/c/Users/mesha -name "README.md" -type f 2>/dev/null >> project_discovery_report.md

echo "Report saved to: project_discovery_report.md"
```

---

## 📋 VERIFICATION CHECKLIST

Before declaring "all projects found", verify:

- [ ] All package.json files discovered
- [ ] All pyproject.toml files discovered
- [ ] All git repositories identified
- [ ] All Desktop projects catalogued
- [ ] All WSL projects catalogued
- [ ] All cloud repositories synced
- [ ] All archive/backups checked
- [ ] All IDE workspaces identified
- [ ] All hidden/project directories discovered

---

## 🎯 SUCCESS CRITERIA

**Complete Discovery =**
- Zero missing package.json files
- Zero missing pyproject.toml files
- All projects categorized (Shippable/Partial/Incomplete)
- All projects have version numbers
- All projects have locations documented

---

*Plan Created: 2026-02-08*  
*Execute immediately for complete inventory*