# Workspace Cleanup Plan

**Date:** 2026-02-05  
**Derives from:** [morphism/MORPHISM.md](morphism/MORPHISM.md), [morphism/SSOT.md](morphism/SSOT.md)

## Current Issues

### Root-Level Clutter
1. **Loose files at root:**
   - `.aider.chat.history.md` - AI tool history
   - `firebase-debug.log` - Debug log
   - `sqlite_mcp_server.db` - Empty database file
   - `package-lock.json` - Minimal/empty package lock
   - `Untitled-3.md` - Temporary file
   - `workspace`, `workspace-minimal`, `workspace-simplified` - Script variants
   - `workspace.bat` - Windows batch script
   - `MORPHISM_MASTER_AUDIT_2025.md` - Audit document
   - `IMPROVEMENT_PLAN.md` - Planning document
   - `TODO.md` - Task list
   - `CLAUDE.md` - AI instructions (should be in .claude/)

2. **Redundant configuration folders:**
   - `.api/` - API public folder (minimal content)
   - `.benchmarks/` - Empty folder
   - `.claude/` - Claude AI configuration (good location)
   - `.codex/` - Codex configuration
   - `.collab/` - Empty collaboration folders
   - `.kilocode/` - Kilocode configuration
   - `.monitor/` - Single health report
   - `.morphism/` - Morphism logs
   - `.mypy_cache/` - Python type checking cache (should be gitignored)
   - `.pytest_cache/` - Python test cache (should be gitignored)

3. **Duplicate/scattered documentation:**
   - Root `AGENTS.md`, `SSOT.md`, `CLAUDE.md` are pointers (good)
   - `MORPHISM_MASTER_AUDIT_2025.md` should be in docs/audits/
   - `IMPROVEMENT_PLAN.md` should be in docs/plans/
   - `TODO.md` should be in docs/ or morphism/

### Folder Organization Issues

1. **Archive folder:**
   - Contains deprecated-runtime, generated, runtime, _trash
   - Should follow ARCHIVE_POLICY.md

2. **Backups folder:**
   - Single backup file
   - Should have clear retention policy

3. **Commands folder:**
   - Contains api.sh, project.sh, validate.sh
   - Should be consolidated with scripts/

4. **Exports folder:**
   - Contains portfolio exports
   - Should be in morphism-profile/

5. **Ops folder:**
   - Single Python script
   - Should be in scripts/ or morphism/kernel/

6. **Templates folder:**
   - Contains rest-api and saas-template
   - Good location, but should be documented

## Cleanup Actions

### Phase 1: Remove Clutter (Immediate)

1. **Delete temporary/cache files:**
   ```bash
   rm .aider.chat.history.md
   rm firebase-debug.log
   rm sqlite_mcp_server.db
   rm Untitled-3.md
   rm package-lock.json
   ```

2. **Add to .gitignore:**
   ```
   .mypy_cache/
   .pytest_cache/
   *.db
   firebase-debug.log
   Untitled-*.md
   ```

3. **Move documentation to proper locations:**
   ```bash
   mv MORPHISM_MASTER_AUDIT_2025.md docs/audits/
   mv IMPROVEMENT_PLAN.md docs/plans/
   mv TODO.md docs/workspace/
   ```

4. **Consolidate workspace scripts:**
   ```bash
   # Keep workspace.bat for Windows users
   # Move workspace variants to scripts/
   mv workspace scripts/workspace-main
   mv workspace-minimal scripts/workspace-minimal
   mv workspace-simplified scripts/workspace-simplified
   ```

### Phase 2: Folder Consolidation

1. **Clean up empty/minimal folders:**
   ```bash
   # Remove if truly empty
   rmdir .benchmarks
   rmdir .collab/knowledge .collab/reviews .collab/tasks
   
   # Move .api/ content if needed, or remove
   # Move .monitor/ to docs/audits/ or morphism/
   ```

2. **Consolidate commands:**
   ```bash
   # Move commands/ scripts to scripts/
   mv commands/api.sh scripts/
   mv commands/project.sh scripts/
   mv commands/validate.sh scripts/
   rmdir commands
   
   # Update commands.sh to reference new locations
   ```

3. **Move ops to proper location:**
   ```bash
   mv ops/consolidation_toolbox.py scripts/
   rmdir ops
   ```

4. **Move exports to morphism-profile:**
   ```bash
   mv exports/portfolio morphism-profile/exports/
   rmdir exports
   ```

### Phase 3: Archive Cleanup

1. **Review archive/ contents:**
   - Apply ARCHIVE_POLICY.md
   - Date all snapshots clearly
   - Remove _trash if no longer needed
   - Document what's archived and why

2. **Backup consolidation:**
   - Define retention policy
   - Move to archive/ if appropriate
   - Document backup strategy

### Phase 4: Configuration Cleanup

1. **Review .claude/ structure:**
   - Move root CLAUDE.md content into .claude/ if needed
   - Ensure agents, skills, settings are organized

2. **Review .kiro/ structure:**
   - Ensure specs are organized
   - Clean up any temporary files

3. **Document configuration folders:**
   - Create docs/workspace/CONFIGURATION.md
   - Explain purpose of each dot-folder

### Phase 5: Verification

1. **Run validation:**
   ```bash
   cd morphism
   ./.validation/validate-all.sh
   ```

2. **Check git status:**
   ```bash
   ./scripts/status-all.sh
   ```

3. **Verify structure:**
   - All governance docs in morphism/
   - All workspace docs in docs/workspace/
   - All scripts in scripts/
   - Root is minimal and clean

## Expected Final Root Structure

```
GitHub/
├── .claude/              # Claude AI configuration
├── .codex/               # Codex configuration
├── .git/                 # Git repository
├── .github/              # GitHub workflows
├── .kilocode/            # Kilocode configuration
├── .kiro/                # Kiro IDE configuration
├── .morphism/            # Morphism logs
├── .vscode/              # VS Code settings
├── archive/              # Dated snapshots (per ARCHIVE_POLICY.md)
├── backups/              # Workspace backups (with retention policy)
├── docs/                 # Workspace documentation
│   ├── audits/           # Audit reports
│   ├── plans/            # Planning documents
│   └── workspace/        # Workspace layout, policies
├── lib/                  # Shared shell libraries
├── monorepo-health-analyzer/  # Standalone tool
├── morphism/             # Canonical governance tree
├── morphism-bible/       # Docs, specs, prompts
├── morphism-profile/     # Personal (never ships)
├── morphism-references/  # Reference materials
├── morphism-ship/        # Governed extension
├── morphism.worktrees/   # Git worktrees
├── scripts/              # All workspace scripts
├── templates/            # Project templates
├── _projects/            # Out-of-scope projects
├── AGENTS.md             # Pointer to morphism/AGENTS.md
├── CLAUDE.md             # Pointer to .claude/CLAUDE.md
├── commands.sh           # Main command dispatcher
├── README.md             # Workspace entry point
├── SSOT.md               # Pointer to morphism/SSOT.md
└── workspace.bat         # Windows workspace launcher
```

## Success Criteria

- [ ] No temporary files at root
- [ ] No cache directories in git
- [ ] All documentation in proper locations
- [ ] All scripts consolidated in scripts/
- [ ] Root has < 15 files
- [ ] All folders have clear purpose
- [ ] Validation passes
- [ ] Git status is clean
- [ ] Documentation updated

## Notes

- Follow MORPHISM.md tenets throughout
- Maintain single source of truth (T4)
- Preserve governance structure (T31)
- Document all changes
- Test after each phase
