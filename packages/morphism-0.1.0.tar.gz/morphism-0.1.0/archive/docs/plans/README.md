# Plans Docs

This folder contains planning documents for workspace improvements and execution tracks.

Current files:

- `COMPREHENSIVE_PROJECT_SEARCH_PLAN.md`
- `IMPROVEMENT_PLAN.md`
- `SHIPPING_ACTION_PLAN.md`
- `WORKSPACE_CLEANUP_PLAN.md`
