# Documentation Style Guide

This guide establishes consistent standards for all documentation in the Morphism workspace.

## Table of Contents

- [General Principles](#general-principles)
- [File Naming](#file-naming)
- [Markdown Standards](#markdown-standards)
- [Structure](#structure)
- [Language and Tone](#language-and-tone)
- [Code Examples](#code-examples)
- [Linking](#linking)
- [Special Elements](#special-elements)

## General Principles

### Clarity Over Cleverness

Write documentation that is clear and easy to understand. Avoid jargon when simpler words will do.
If technical terms are necessary, define them on first use.

### Single Source of Truth

Each topic should have one canonical location. Avoid duplicating information across multiple
documents. Cross-reference instead of duplicating.

### Keep It Current

Documentation should reflect the current state of the project. Outdated documentation is worse than
no documentation. Update or archive documents when processes change.

### Write for Your Reader

Consider who will read the documentation and what they need to achieve. Provide appropriate context
and background information.

## File Naming

### Conventions

- Use kebab-case: `my-document.md` (not `MyDocument.md` or `my_document.md`)
- Use descriptive names: `setup-guide.md` (not `sg.md` or `setup.md`)
- Include version or date only when necessary: `roadmap-2024.md`

### Avoid

- Spaces in filenames
- Special characters (except hyphens and underscores)
- Overly long filenames
- Abbreviations that aren't widely understood

### Examples

| Good                 | Bad                         |
| -------------------- | --------------------------- |
| `setup-guide.md`     | `GettingStartedFinal_v2.md` |
| `api-reference.md`   | `API.md`                    |
| `troubleshooting.md` | `help.md`                   |

## Markdown Standards

### Headings

- Use `#` for document title (one per document)
- Use `##` for major sections
- Use `###` for subsections
- Use `####` sparingly (indicates need for refactoring)
- Capitalize headings like sentences: "Setup and Configuration" not "Setup And Configuration"

```markdown
# Document Title

## Major Section

### Subsection

#### Rarely used
```

### Line Length

- Wrap lines at 100 characters for readability
- Use a newline at the end of every file
- Use blank lines between headings and paragraphs

### Lists

- Use bullet points for unordered lists
- Use numbered lists for sequences
- Keep list items parallel (same grammatical structure)
- Limit lists to 7 items; use subsections if more are needed

```markdown
- First item
- Second item
- Third item

1. First step
2. Second step
3. Third step
```

### Emphasis

- Use **bold** for important terms and UI elements
- Use _italics_ for emphasis on specific words
- Use `code` for file paths, commands, and code elements
- Use > for blockquotes and notes

## Structure

### Required Elements

1. **Title** - Clear, descriptive document title
2. **Introduction** - Brief overview of document purpose
3. **Table of Contents** - For documents longer than 2 screens
4. **Body** - Organized content with clear sections
5. **Examples** - Practical applications when relevant
6. **Related Resources** - Links to related documentation

### Document Template

````markdown
# Document Title

Brief description of what this document covers.

## Table of Contents

- [Section 1](#section-1)
- [Section 2](#section-2)
- [Section 3](#section-3)

## Section 1

Content for section 1.

### Subsection

More detailed content.

## Section 2

Content for section 2.

## Section 3

Content for section 3.

## Examples

### Example 1

```language
code example here
```
````

## Related Resources

- [Related Document 1](path/to/doc.md)
- [Related Document 2](path/to/doc.md)

````

## Language and Tone

### Voice

- Use active voice ("Run the command" not "The command should be run")
- Use present tense ("The system validates" not "The system will validate")
- Use second person ("You can" not "The user can")
- Use imperative mood for instructions ("Run this command")

### Tone

- Professional but accessible
- Concise but complete
- Direct and action-oriented
- Avoid overly casual language in formal documentation

### Common Mistakes

| Incorrect | Correct |
|-----------|---------|
| "Make sure to..." | "Ensure..." |
| "In order to" | "To" |
| "At this point in time" | "Now" |
| "Please note that" | "Note:" |
| "If you don't" | "Unless you" |

## Code Examples

### When to Include

- Every procedural step
- Every configuration option
- Every API endpoint
- Common use cases

### Best Practices

1. **Use language-specific code blocks**

```markdown
```bash
npm install
````

````

2. **Label non-obvious code blocks**

```markdown
```typescript
// TypeScript example
const result = processData(input);
````

````

3. **Explain what the code does**

```markdown
Install dependencies:

```bash
npm install
````

This command downloads all packages listed in `package.json`.

````

4. **Show expected output when helpful**

```bash
$ npm install
added 142 packages in 3s
````

### Command-Line Examples

- Use `$` prefix for commands that require user input
- Use `#` prefix for commands that require root/admin
- Show the command and its output separately

```bash
$ npm test

> my-project@1.0.0 test
> jest

 PASS  src/index.test.ts
 ✓ all tests passed
```

## Linking

### Internal Links

Use relative paths for links within the repository:

```markdown
- [Setup Guide](docs/setup/setup-guide.md)
- [API Reference](docs/reference/api.md)
```

### Anchor Links

Use auto-generated anchors from headings:

```markdown
- [Installation](#installation)
- [Configuration](#configuration)
```

### External Links

- Use HTTPS when available
- Add title attribute for accessibility (optional but recommended)
- Consider adding `(opens in new tab)` for external links

```markdown
- [Node.js Documentation](https://nodejs.org 'Node.js Official Documentation')
```

### Link Text

- Use descriptive link text, not "click here"
- Keep links as short as possible
- Avoid redundant words

| Good                          | Bad                              |
| ----------------------------- | -------------------------------- |
| "Read the [setup guide](...)" | "Read [this](...) guide"         |
| "[API documentation](...)"    | "[Click here](...) for API docs" |

## Special Elements

### Notes and Warnings

Use blockquotes for important notes and warnings:

```markdown
> **Note:** This feature is experimental.

> **Warning:** This action cannot be undone.
```

### Tables

Use tables for structured data:

| Column 1 | Column 2 | Column 3 |
| -------- | -------- | -------- |
| Value 1  | Value 2  | Value 3  |
| Value 4  | Value 5  | Value 6  |

### Diagrams

Use Mermaid.js for flowcharts and diagrams when appropriate:

````markdown
```mermaid
graph TD
    A[Start] --> B{Decision}
    B -->|Yes| C[Action 1]
    B -->|No| D[Action 2]
```
````

```

## Project-Specific Guidelines

### README.md Files

Every project should have a README.md with:

1. Project name and one-line description
2. Quick start (3-5 steps)
3. Key features
4. Requirements
5. Installation
6. Usage examples
7. Links to full documentation

### API Documentation

Use JSDoc comments in code and generate API docs. Include:

- Function/class purpose
- Parameters with types
- Return values
- Examples
- Known limitations

### Changelog

Use the CHANGELOG-TEMPLATE.md from templates/ directory.

## Checklist for New Documents

- [ ] Follows file naming conventions
- [ ] Has clear title
- [ ] Has introduction
- [ ] Uses proper heading hierarchy
- [ ] Includes code examples where appropriate
- [ ] Has internal links to related documents
- [ ] Has been proofread
- [ ] Follows this style guide

## References

- [Markdown Guide](https://www.markdownguide.org)
- [Google Developer Documentation Style Guide](https://developers.google.com/style)
- [Microsoft Writing Style Guide](https://docs.microsoft.com/en-us/style-guide/welcome/)
```
