# Package Naming Convention

## Your Two Namespaces

| Namespace | Owner | Purpose | Use For |
|-----------|-------|---------|---------|
| **@alawein** | Meshal Alawein (personal) | Personal projects | Apps, platforms, experiments |
| **@morphism-systems** | Morphism Systems (company) | Company products | MCP servers, CLIs, tools |

---

## Why This Split Makes Sense

### @alawein (Personal)
- **Owner:** Meshal Alawein
- **Philosophy:** Personal brand, family name (alawein - unique, reserved)
- **Purpose:** Your apps, platforms, experiments
- **Examples:**
  - @alawein/llmworks — Your LLM evaluation platform
  - @alawein/boltsfit — Your fitness platform

### @morphism-systems (Company)
- **Owner:** Morphism Systems LLC
- **Philosophy:** Company governance, tenets, rules
- **Purpose:** Commercial products, MCP servers, CLI tools
- **Examples:**
  - @morphism-systems/core — Framework core
  - @morphism-systems/mcp — MCP integration
  - @morphism-systems/cli — Command-line tools

---

## Naming Decision Tree

```
Is this project a commercial tool/product?
│
├─ YES → Use @morphism-systems
│   │
│   ├─ MCP server? → @morphism-systems/mcp-[name]
│   ├─ CLI tool? → @morphism-systems/cli-[name]
│   └─ Library? → @morphism-systems/[name]
│
└─ NO → Use @alawein
    │
    ├─ Web app? → @alawein/[app-name]
    ├─ Platform? → @alawein/[platform-name]
    └─ Experiment? → @alawein/[experiment-name]
```

---

## Consolidated Package List

### Personal (@alawein)

| Project | Package Name | Type | Status |
|---------|-------------|------|--------|
| LLMWorks | @alawein/llmworks | Web Platform | Ready (was @meshal/llmworks) |
| BOLTS.FIT | @alawein/boltsfit | Web Platform | Ready (was @boltsfit/web) |
| REPZ | @alawein/repz | Platform | Assessment needed |
| Event Discovery | @alawein/event-discovery | Research | Assessment needed |
| Brand Kit | @alawein/brand-kit | CLI | Ready |
| Codemap | @alawein/codemap | CLI | Ready |

### Company (@morphism-systems)

| Project | Package Name | Type | Status |
|---------|-------------|------|--------|
| Core Framework | @morphism-systems/core | Library | Ready (was @morphism-systems/core) |
| MCP Integration | @morphism-systems/mcp | MCP | Ready (was @morphism-systems/mcp) |
| Tools | @morphism-systems/tools | CLI | Ready (was @morphism-systems/tools) |
| Agent Context Optimizer | @morphism-systems/agent-context-optimizer | CLI | Ready |
| Monorepo Health Analyzer | @morphism-systems/monorepo-health-analyzer | CLI | Ready |
| KiloCode Hub CLI | @morphism-systems/hub-cli | CLI | Ready (was @kilocode/hub-cli) |

---

## Migration Plan

### Step 1: Create npm Accounts

1. **@alawein** on npmjs.com
   - Personal account
   - Link to your email

2. **@morphism-systems** on npmjs.com
   - Organization account
   - Invite @alawein as owner

### Step 2: Update package.json Files

```json
// Before (@meshal/llmworks)
{
  "name": "@meshal/llmworks",
  "version": "1.0.0"
}

// After (@alawein/llmworks)
{
  "name": "@alawein/llmworks",
  "version": "1.0.0"
}
```

```json
// Before (@morphism-systems/core)
{
  "name": "@morphism-systems/core",
  "version": "1.0.0"
}

// After (@morphism-systems/core)
{
  "name": "@morphism-systems/core",
  "version": "1.0.0"
}
```

### Step 3: Republish Packages

```bash
# Update version (major for namespace change)
npm version major

# Publish with access
npm publish --access public
```

---

## Installation Examples

```bash
# Personal packages
npm install @alawein/llmworks
npm install @alawein/boltsfit

# Company packages
npm install @morphism-systems/core
npm install @morphism-systems/mcp
npm install @morphism-systems/hub-cli
```

---

## Import Examples

```typescript
// Personal package
import { something } from '@alawein/llmworks'

// Company package
import { something } from '@morphism-systems/core'
```

---

## GitHub Repository Names

| Current | New |
|---------|-----|
| meshal/llmworks | alawein/llmworks |
| boltsfit/web | alawein/boltsfit |
| morphism/core | morphism-systems/core |
| morphism/mcp | morphism-systems/mcp |
| morphism/tools | morphism-systems/tools |
| kilocode/hub-cli | morphism-systems/hub-cli |

---

## Summary

| Namespace | Owner | When to Use |
|-----------|-------|-------------|
| @alawein | Personal | Your apps, platforms, experiments |
| @morphism-systems | Company | MCP servers, CLI tools, commercial products |

**Clean. Simple. Scalable.**

---

*Document Created: 2026-02-08*  
*Version: 1.0.0*