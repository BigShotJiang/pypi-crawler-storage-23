# Reference Docs

This folder contains technical references and compatibility documentation.

Current files:

- `PACKAGE_NAMING_CONVENTION.md`
- `PHASE-2-TOOL-COMPATIBILITY.md`
- `SECURITY_AUDIT.md`
- `TOKEN_LOCATIONS.md`
