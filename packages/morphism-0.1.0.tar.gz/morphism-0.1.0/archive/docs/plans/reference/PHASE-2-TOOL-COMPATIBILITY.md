# Phase 2: Tool Compatibility Matrix & Workflow Guide

**Status**: Reference document for Phase 2
**Date**: 2026-02-06
**Purpose**: Clear guidance on which tools to use from which context

---

## Executive Summary

| Tool | Windows | WSL | Recommendation | Notes |
|------|---------|-----|-----------------|-------|
| **VS Code** | ✓ Native | ✓ Remote | Either | Remote-WSL is excellent |
| **Cursor** | ✓ Native | ✗ N/A | Windows | No WSL support |
| **Windsurf** | ✓ Native | ✗ N/A | Windows | No WSL support |
| **pnpm/npm** | ✓ Windows | ✓ WSL | Either | Use native to context |
| **Git** | ✓ Works | ✓ Works | Either | Configure CRLF globally |
| **Lean** | ⚠️ Possible | ✓ Recommended | WSL | Better build system |
| **Node.js** | ✓ Windows | ✓ WSL | Either | Keep separate installs |
| **Docker** | ✓ Desktop | ✓ Native | WSL | Faster in WSL |
| **Bash/Shell** | ✗ Limited | ✓ Native | WSL | Use WSL for scripting |

---

## Detailed Tool Workflows

### 1. VS Code (✓ Both Contexts Recommended)

#### From Windows

```powershell
cd C:\Users\mesha\Desktop\GitHub
code .
```

**What happens**:
- VS Code opens in Windows context
- Terminal defaults to PowerShell
- Git uses Windows Git installation
- Node uses Windows Node installation
- All paths are Windows format

**Best for**:
- Writing TypeScript/JavaScript
- Quick edits with npm/pnpm
- When you're already in Windows

---

#### From WSL (Recommended for Lean/Proofs)

```bash
cd /mnt/c/Users/mesha/Desktop/GitHub
code .
```

**What happens**:
- VS Code opens in Windows (executable is Windows binary)
- Detects WSL environment
- Activates Remote-WSL extension automatically
- Terminal runs WSL bash
- Git uses WSL Git installation
- Can run Lake build, Docker, etc.

**Best for**:
- Lean proofs (uses Lake build system)
- Docker development
- Linux-native tools
- Full WSL capabilities

**Key feature**: VS Code Remote-WSL gives you the best of both worlds
- Windows IDE performance
- WSL development environment
- Integrated WSL terminal

---

### 2. Cursor (✓ Windows Only)

```powershell
# Option 1: From PowerShell
cd C:\Users\mesha\Desktop\GitHub
cursor-workspace

# Option 2: Via Windows Explorer
# Right-click folder → Open with Cursor

# Option 3: Command line
cursor C:\Users\mesha\Desktop\GitHub
```

**Context**:
- Always runs in Windows context
- Terminal is PowerShell
- Paths are Windows format

**Best for**:
- Pure Windows development
- When you specifically want Cursor's features
- TypeScript/JavaScript with npm/pnpm

**Not ideal for**:
- Lean proofs (no Lake integration)
- Docker work
- Linux-specific tooling

---

### 3. Windsurf (✓ Windows Only)

```powershell
# Option 1: From PowerShell
cd C:\Users\mesha\Desktop\GitHub
windsurf .

# Option 2: Via Start menu
# Search "Windsurf" and open

# Option 3: Command line
windsurf C:\Users\mesha\Desktop\GitHub
```

**Context**: Same as Cursor
- Windows context only
- PowerShell terminal
- Windows paths

**Best for**: Similar to Cursor

**Note**: Windsurf is newer — choose based on preference

---

### 4. Terminal/Shell (Choose Based on Task)

#### For Node/pnpm Work (Either)

**From Windows PowerShell**:
```powershell
workspace          # Navigate to workspace
pnpm install       # Install dependencies
pnpm run build     # Build project
```

**From WSL Bash**:
```bash
workspace          # Navigate to workspace
pnpm install       # Install dependencies
pnpm run build     # Build project
```

**Both work equally well** — use whichever you prefer.

---

#### For Lean/Proofs (WSL Recommended)

**From WSL Bash** ✓ **Recommended**:
```bash
workspace
cd lab/proofs
lake build          # Build with Lake
lean Morphism.lean  # Run specific proof
```

**From Windows PowerShell** ⚠️ **Possible but not ideal**:
```powershell
workspace
cd lab\proofs
lean Morphism.lean
# Lake build may have issues on Windows
```

**Why WSL is better for Lean**:
- Lake is Linux-native
- Docker integration works seamlessly
- Consistent with CI/CD pipeline
- Better performance

---

#### For Scripting/Bash Work (WSL Only)

```bash
# From WSL
workspace

# Run bash scripts
bash .setup/verify-all.sh

# System administration
sudo systemctl status docker
```

**Not available in Windows** (without extra setup)

---

### 5. Git (Works from Both with Caveats)

#### From Windows

```powershell
workspace
git status      # Check status
git add .       # Stage files
git commit -m "message"  # Commit
git push        # Push to remote
```

**Configuration**:
```powershell
# Already set by environment script
git config core.autocrlf input
git config credential.helper manager-core
```

---

#### From WSL

```bash
workspace
git status      # Check status
git add .       # Stage files
git commit -m "message"  # Commit
git push        # Push to remote
```

**Configuration**:
```bash
# Already set by environment script
git config core.autocrlf input
git config credential.helper cache
```

---

#### Critical: CRLF Configuration

**Must be set globally** (done in Phase 2 setup scripts):

```bash
# Set once
git config --global core.autocrlf input

# Verify it's set
git config --show-origin core.autocrlf
```

**Without this**:
- Windows Git converts LF → CRLF
- WSL Git keeps LF
- Every file appears "modified" → Git commit shows all files changed
- Very frustrating!

**With `input` mode**:
- Repo stores LF (standard)
- Windows checkout: LF → CRLF automatically
- WSL checkout: Keeps LF
- No spurious modifications

---

### 6. Docker (WSL Recommended)

#### From WSL (✓ Recommended)

```bash
# Docker runs natively in WSL2
docker ps                    # List containers
docker build -t myapp .      # Build image
docker compose up            # Start services
```

**Performance**: Excellent (native Docker in Linux kernel)

---

#### From Windows (⚠️ Via Docker Desktop)

```powershell
# Docker Desktop creates WSL2 backend
docker ps
docker build -t myapp .
docker compose up
```

**Performance**: Good but goes through Windows → WSL translation layer

**Recommendation**: Use `docker` command from WSL terminal for best performance

---

### 7. Node.js & pnpm (Choose Context Based on Task)

#### For TypeScript/JavaScript Development

Both work equally well:

**Windows**:
```powershell
workspace
npm test
pnpm run build
```

**WSL**:
```bash
workspace
npm test
pnpm run build
```

#### For Native Modules

If your project uses native modules (C++/Rust bindings):

**Use Windows for Windows-native modules**:
```powershell
npm install  # Builds for Windows
```

**Use WSL for Linux-native modules**:
```bash
npm install  # Builds for Linux
```

**Note**: Keep `node_modules` separate between Windows and WSL
- Add to `.gitignore`
- Don't share between contexts

---

## Decision Tree: Which Tool to Use?

```
Start with task type:

┌─ TypeScript/JavaScript (Web)
│  ├─ Quick edit? → Use Cursor or VS Code (Windows)
│  ├─ Full dev? → Use VS Code (either), launch from preference
│  └─ Need Node features? → Windows or WSL (both work)

├─ Lean/Formal Proofs
│  ├─ Editing? → VS Code from WSL (opens Remote-WSL)
│  ├─ Building? → WSL terminal with Lake
│  └─ Avoid Cursor/Windsurf for this task

├─ System/Linux work
│  ├─ Scripting? → WSL terminal only
│  ├─ Docker? → WSL terminal (Docker Desktop okay too)
│  └─ SSH/remote? → WSL terminal

├─ Git operations
│  ├─ Simple commit? → Use either (both configured)
│  ├─ Complex merge? → Use either (both configured)
│  └─ Credential issues? → Check Git config (see troubleshooting)

└─ General development
   ├─ Mixed tasks? → VS Code (Remote-WSL for flexibility)
   ├─ Windows-only? → Cursor or Windsurf
   └─ Unix-heavy? → WSL terminal + VS Code Remote
```

---

## Workflow Recommendations

### Recommended Daily Workflow

**Morning Setup**:
```powershell
# Windows PowerShell
workspace                    # Navigate to workspace
Show-Context                 # Verify you're in Windows context
Verify-Paths                 # Ensure config is accessible
```

**For TypeScript/JavaScript Work**:
```powershell
# From Windows PowerShell
workspace
code .                       # Open in VS Code
# In VS Code terminal: Already PowerShell, ready to use
```

**For Lean/Proof Work**:
```bash
# From WSL bash
workspace
code .                       # Opens VS Code with Remote-WSL
# In VS Code terminal: Now bash, ready for Lake
lake build
```

**Git Operations**:
```bash
# Can do from either, but example from WSL:
workspace
git status
git add .
git commit -m "feature: ..."
git push
```

---

### Example Workflow: Adding a Feature

**Step 1: Feature planning (VS Code)**
```powershell
workspace
code .
# Edit spec document, plan architecture
# Use Cursor/Windsurf if you prefer, or VS Code from Windows
```

**Step 2: Implementation (match task type)**

*If implementing TypeScript*:
```powershell
# Can use Windows or WSL
workspace
code .
# Write code, run `npm test` in terminal
```

*If implementing Lean proofs*:
```bash
workspace
code .
# Opens VS Code with Remote-WSL
# Use VS Code terminal or external WSL terminal
lake build  # Build proofs
```

**Step 3: Testing**
```bash
# Test from appropriate context
workspace
npm test      # TypeScript
lake test     # Lean
```

**Step 4: Commit**
```bash
# Either context works
git status
git add .
git commit -m "feature: description"
git push
```

---

## Environment-Specific Quick Reference

### Use Windows PowerShell For:
- ✓ Launching Cursor/Windsurf
- ✓ npm/pnpm work (Node.js)
- ✓ Quick edits in VS Code
- ✓ Windows-native tools
- ✗ Lean proofs
- ✗ Docker work
- ✗ Bash scripting

### Use WSL Bash/Zsh For:
- ✓ Lean proofs
- ✓ Docker work
- ✓ Bash scripting
- ✓ VS Code with Remote-WSL
- ✓ System administration
- ✓ Linux-native tools
- ✗ Cursor/Windsurf (they're Windows-only)

### Use VS Code From Either:
- ✓ From Windows: Opens in Windows context
- ✓ From WSL: Opens in Windows, detects WSL, enables Remote
- ✓ Remote-WSL is excellent for WSL work
- ✓ Best tool for cross-context work

---

## Common Scenarios

### Scenario 1: I want to edit TypeScript and run tests

**Option A (Windows)**:
```powershell
workspace
code .
# In VS Code terminal: already PowerShell
npm test
```

**Option B (WSL)**:
```bash
workspace
code .  # Opens with Remote-WSL
# In VS Code terminal: already bash
npm test
```

**Recommendation**: Either works, choose based on preference. Windows is slightly faster (no Remote overhead).

---

### Scenario 2: I need to write Lean proofs

**Option A (WSL) ✓ Recommended**:
```bash
workspace
code .  # Opens with Remote-WSL
# In VS Code terminal: bash
lake build
```

**Option B (Windows) ⚠️ Possible but harder**:
```powershell
workspace
cursor .  # Opens in Windows context
# Terminal is PowerShell, Lean tools may not work well
```

**Recommendation**: Use WSL. Lake build system works best there.

---

### Scenario 3: I need to use Docker

**Option A (WSL) ✓ Recommended**:
```bash
workspace
docker compose up
```

**Option B (Windows via Docker Desktop)**:
```powershell
workspace
docker compose up
```

**Recommendation**: WSL is faster (native Docker kernel).

---

### Scenario 4: I'm pair programming with someone on a different OS

**You're on Windows, They're on Linux**:
- Use WSL to match their environment
- `code .` from WSL gives you their experience
- Troubleshooting is easier when contexts match

**You're on WSL, They're on macOS**:
- Similar idea: WSL bash is closer to macOS zsh than Windows PowerShell

---

## Troubleshooting: Wrong Tool in Wrong Context

### Problem: "Lean build fails from Windows"

**Cause**: Lake expects Linux environment

**Solution**:
```bash
# Use WSL instead
workspace
code .  # Opens with Remote-WSL
lake build
```

---

### Problem: "Cursor can't find Node.js"

**Cause**: Cursor is Windows-only; Node might be in WSL

**Solution**:
```powershell
# Install Node.js in Windows
# https://nodejs.org/

# OR use VS Code from WSL and get WSL's Node
workspace
code .  # Remote-WSL mode
npm test
```

---

### Problem: "Git shows every file as modified"

**Cause**: CRLF not configured correctly

**Solution**:
```bash
# Verify configuration
git config --global core.autocrlf
# Should show: input

# If not set:
git config --global core.autocrlf input
```

---

## Summary

| What | Which Context? | Which Tool? | Why |
|------|---|---|---|
| **Web development** | Windows or WSL | VS Code | Works everywhere |
| **Lean proofs** | WSL | VS Code Remote | Lake needs Linux |
| **Docker** | WSL | Terminal | Native Docker |
| **Bash scripting** | WSL | Terminal | Bash is Linux |
| **Quick edits** | Windows | Cursor/Windsurf | No Remote overhead |
| **Full development** | WSL + Remote | VS Code | Best flexibility |

---

**Generated**: 2026-02-06
**Phase**: 2 of 3
**Status**: Reference guide for Phase 2
