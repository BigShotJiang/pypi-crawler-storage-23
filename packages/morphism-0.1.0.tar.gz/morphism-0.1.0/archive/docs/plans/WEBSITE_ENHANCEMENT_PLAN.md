# Website Enhancement Plan
**Morphism.systems Design Integration**

**Date:** 2026-02-09
**Phase:** 7 (Post-Migration Enhancement)
**Status:** Planning

---

## Table of Contents

1. [Executive Summary](#executive-summary)
2. [Design System Analysis](#design-system-analysis)
3. [Reusable Components](#reusable-components)
4. [Integration Strategy](#integration-strategy)
5. [Implementation Phases](#implementation-phases)
6. [User Decision Points](#user-decision-points)

---

## Executive Summary

### Objectives

Apply Morphism Hub's production-ready design system to other Morphism ecosystem projects, ensuring visual consistency and professional presentation across:
- Marketing/landing pages
- Documentation sites
- Developer portals
- Component showcases

### Key Findings

Morphism Hub (morphism.systems) implements a sophisticated SaaS design:
- **Tech Stack:** Next.js 15.2 + React 19 + Tailwind CSS 3.4
- **Visual Language:** Dark, mathematical, geometric
- **Design Philosophy:** Glassmorphism + modern SaaS patterns
- **Color Psychology:** Premium/technical aesthetic

### Deliverables

1. **Component Library** - Extracted reusable components
2. **Design Tokens** - Tailwind configuration with brand colors
3. **Page Templates** - Landing, docs, dashboard layouts
4. **Integration Guide** - Step-by-step implementation

---

## Design System Analysis

### 1. Color Palette

```css
/* Base Colors */
--bg-primary: #0a0a0f;          /* Almost black background */
--text-primary: rgb(243 244 246); /* Gray-100 - light text */
--text-secondary: rgb(156 163 175); /* Gray-400 - muted */

/* Borders & Overlays */
--border-subtle: rgba(255, 255, 255, 0.05);  /* white/5 */
--bg-glass: rgba(10, 10, 15, 0.8);           /* Semi-transparent */

/* Accents */
--accent-blue: rgb(59 130 246);   /* Blue-500 */
--accent-hover: white;            /* Hover state */

/* Selection */
--selection-bg: rgba(59, 130, 246, 0.3);  /* Blue-500/30 */
```

### 2. Typography Scale

```typescript
// Tailwind Classes
{
  wordmark: 'text-lg font-bold tracking-tight',
  heading-xl: 'text-5xl md:text-6xl font-bold',
  heading-lg: 'text-4xl font-bold',
  heading-md: 'text-2xl font-semibold',
  body: 'text-base',
  caption: 'text-sm text-gray-400',
}
```

### 3. Layout System

**Container:**
```tsx
<div className="max-w-6xl mx-auto px-6">
  {/* Content */}
</div>
```

**Responsive Padding:**
- Mobile: `px-6 py-4`
- Desktop: `px-8 py-6`

**Spacing:**
- Section gaps: `py-16 md:py-24`
- Element gaps: `gap-8`, `gap-12`, `gap-16`

### 4. Component Patterns

**Glassmorphism Card:**
```tsx
<div className="border border-white/5 bg-[#0a0a0f]/80 backdrop-blur-xl rounded-xl p-6">
  {/* Content */}
</div>
```

**CTA Button:**
```tsx
<button className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg transition-colors">
  Get Started
</button>
```

**Navigation:**
```tsx
<nav className="fixed top-0 w-full z-50 border-b border-white/5 bg-[#0a0a0f]/80 backdrop-blur-xl">
  {/* Nav content */}
</nav>
```

### 5. Visual Elements

**Geometric Icons:**
- ◇ (diamond) - Drift detection
- △ (triangle) - AI assessment
- □ (square) - Policy enforcement
- ⬡ (hexagon) - CLI integration
- ○ (circle) - Audit trail
- ∞ (infinity) - Convergence

**Morphism Logo:**
- Outer ring: Governance boundary (opacity: 0.3)
- Inner diamond: Fixed point (opacity: 0.6)
- Core arrow: Structure-preserving transformation
- Center dot: Fixed point (opacity: 0.8)

### 6. Animation & Transitions

```css
/* Hover States */
.hover\\:text-white { transition: color 0.2s; }
.hover\\:bg-blue-600 { transition: background-color 0.2s; }

/* Transitions */
transition-colors
transition-opacity
transition-transform
```

---

## Reusable Components

### Extracted Component Library

#### 1. Logo Components

**MorphismLogo** (`components/logo.tsx`)
- SVG icon with mathematical symbolism
- Configurable size via className
- Current color inheritance

**MorphismWordmark** (`components/wordmark.tsx`)
- Logo + "morphism" text
- Flex layout with gap-2.5
- Consistent branding

#### 2. Navigation

**GlassNav** (`components/glass-nav.tsx`)
- Fixed top navigation
- Backdrop blur effect
- Border-bottom styling
- Responsive menu (desktop/mobile)

```tsx
<GlassNav>
  <Logo />
  <NavLinks>
    <NavLink href="#features">Features</NavLink>
    <NavLink href="#pricing">Pricing</NavLink>
  </NavLinks>
  <CTAButtons>
    <Button variant="ghost">Sign In</Button>
    <Button variant="primary">Get Started</Button>
  </CTAButtons>
</GlassNav>
```

#### 3. Hero Section

**HeroWithProof** (`components/hero-with-proof.tsx`)
- Large heading with gradient
- Subheading with emphasis
- CTA buttons (primary + secondary)
- Mathematical proof badge

```tsx
<HeroWithProof
  title="Your agents converge — provably"
  subtitle="The first AI governance ecosystem with mathematical convergence guarantees"
  ctaPrimary={{ text: "Start Free Trial", href: "/sign-up" }}
  ctaSecondary={{ text: "View Docs", href: "/docs" }}
  proofBadge="κ < 1 convergence"
/>
```

#### 4. Feature Grid

**FeatureGrid** (`components/feature-grid.tsx`)
- 3-column responsive grid
- Icon + title + description
- Glassmorphism cards
- Hover effects

```tsx
<FeatureGrid features={[
  { icon: '◇', title: 'Drift Detection', desc: '...' },
  { icon: '△', title: 'AI Risk', desc: '...' },
  // ...
]} />
```

#### 5. Pricing Tiers

**PricingCards** (`components/pricing-cards.tsx`)
- 3-tier layout (Free, Pro, Enterprise)
- Highlighted tier (Pro)
- Feature checkmarks
- CTA buttons

```tsx
<PricingCards tiers={PRICING_DATA} />
```

#### 6. UI Primitives

**Button** (`components/ui/button.tsx`)
- Variants: primary, secondary, ghost, outline
- Sizes: sm, md, lg
- States: default, hover, disabled

**Card** (`components/ui/card.tsx`)
- Glassmorphism styling
- Border + backdrop blur
- Configurable padding

---

## Integration Strategy

### Phase 1: Design Token Migration

**1.1 Tailwind Configuration**

Create `tailwind.morphism.config.ts`:

```typescript
import type { Config } from 'tailwindcss'

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        morphism: {
          bg: {
            primary: '#0a0a0f',
            glass: 'rgba(10, 10, 15, 0.8)',
          },
          border: {
            subtle: 'rgba(255, 255, 255, 0.05)',
          },
          text: {
            primary: 'rgb(243 244 246)',
            secondary: 'rgb(156 163 175)',
          },
        },
      },
      backdropBlur: {
        'xl': '24px',
      },
    },
  },
  plugins: [],
}

export default config
```

**1.2 CSS Variables**

Create `styles/morphism-tokens.css`:

```css
:root {
  /* Colors */
  --morphism-bg-primary: #0a0a0f;
  --morphism-text-primary: rgb(243 244 246);
  --morphism-text-secondary: rgb(156 163 175);
  --morphism-border-subtle: rgba(255, 255, 255, 0.05);

  /* Typography */
  --morphism-font-wordmark: 'Inter', sans-serif;
  --morphism-tracking-tight: -0.02em;

  /* Spacing */
  --morphism-container-max: 72rem; /* 1152px */
  --morphism-section-py: 4rem;
}

@media (min-width: 768px) {
  :root {
    --morphism-section-py: 6rem;
  }
}
```

### Phase 2: Component Library Setup

**2.1 Directory Structure**

```
src/
├── components/
│   ├── morphism/
│   │   ├── logo.tsx
│   │   ├── wordmark.tsx
│   │   ├── glass-nav.tsx
│   │   ├── hero-with-proof.tsx
│   │   ├── feature-grid.tsx
│   │   ├── pricing-cards.tsx
│   │   └── index.ts  # Barrel export
│   └── ui/
│       ├── button.tsx
│       ├── card.tsx
│       └── index.ts
└── styles/
    ├── globals.css
    └── morphism-tokens.css
```

**2.2 Component Extraction**

Copy components from `morphism-hub/src/components/` to library:

```bash
# Extract logo
cp morphism-hub/src/components/logo.tsx src/components/morphism/

# Extract and adapt page sections
# (Requires manual extraction from page.tsx)
```

### Phase 3: Page Template Creation

**3.1 Landing Page Template**

```tsx
// templates/landing-morphism.tsx
import {
  GlassNav,
  HeroWithProof,
  FeatureGrid,
  PricingCards,
  Footer,
} from '@/components/morphism'

export default function MorphismLanding() {
  return (
    <div className="min-h-screen bg-morphism-bg-primary text-morphism-text-primary">
      <GlassNav />

      <main>
        <HeroWithProof {...heroProps} />
        <FeatureGrid features={FEATURES} />
        <PricingCards tiers={PRICING} />
      </main>

      <Footer />
    </div>
  )
}
```

**3.2 Documentation Template**

```tsx
// templates/docs-morphism.tsx
import { DocsNav, DocsSidebar, DocsContent } from '@/components/morphism/docs'

export default function MorphismDocs({ children }) {
  return (
    <div className="min-h-screen bg-morphism-bg-primary">
      <DocsNav />
      <div className="max-w-7xl mx-auto px-6 py-8 grid grid-cols-[240px_1fr] gap-12">
        <DocsSidebar />
        <DocsContent>{children}</DocsContent>
      </div>
    </div>
  )
}
```

### Phase 4: Integration Testing

**4.1 Visual Regression**

```bash
# Install testing tools
npm install --save-dev @storybook/react chromatic

# Create Storybook stories
src/components/morphism/__stories__/
├── logo.stories.tsx
├── glass-nav.stories.tsx
└── feature-grid.stories.tsx
```

**4.2 Accessibility Audit**

```bash
# Install axe-core
npm install --save-dev @axe-core/react

# Run accessibility tests
npm run test:a11y
```

---

## Implementation Phases

### Phase 1: Foundation (Week 1)

**Tasks:**
1. ✅ Analyze Morphism Hub design system
2. ✅ Document color palette & typography
3. ✅ Extract component patterns
4. ✅ Create design token configuration

**Deliverables:**
- `tailwind.morphism.config.ts`
- `styles/morphism-tokens.css`
- `docs/plans/WEBSITE_ENHANCEMENT_PLAN.md` (this document)

### Phase 2: Component Library (Week 2)

**Tasks:**
1. Extract logo components
2. Build UI primitives (Button, Card)
3. Create navigation components
4. Develop feature grid & pricing cards

**Deliverables:**
- `src/components/morphism/` directory
- Component documentation (JSDoc)
- Storybook stories

### Phase 3: Page Templates (Week 3)

**Tasks:**
1. Create landing page template
2. Build documentation template
3. Develop dashboard layout
4. Design component showcase

**Deliverables:**
- `templates/landing-morphism.tsx`
- `templates/docs-morphism.tsx`
- `templates/dashboard-morphism.tsx`

### Phase 4: Integration & Testing (Week 4)

**Tasks:**
1. Integrate templates into target sites
2. Visual regression testing
3. Accessibility audit
4. Performance optimization

**Deliverables:**
- Integrated websites
- Test reports
- Performance metrics

---

## User Decision Points

### 🎨 Design Decisions (Your Input Needed)

The following decisions require your domain knowledge and preferences:

#### 1. Color Customization

**Question:** Should we maintain the exact Morphism Hub color scheme, or create variants for different contexts?

**Context:**
- Morphism Hub uses very dark bg (`#0a0a0f`)
- Great for SaaS product, but documentation might benefit from lighter variant
- Consider: dark mode toggle vs. fixed dark

**Options:**
A. **Exact Match** - Use `#0a0a0f` everywhere (consistent branding)
B. **Context-Aware** - Dark for marketing, lighter for docs (`#1a1a1f`)
C. **Theme Toggle** - User-selectable light/dark mode

**Trade-offs:**
- A: Maximum consistency, but docs might feel heavy
- B: Better readability, but less brand consistency
- C: Best UX, but more complexity to maintain

**Your Decision:**
```typescript
// TODO: Choose color strategy
// File: src/components/morphism/theme-config.ts
export const MORPHISM_THEME = {
  strategy: 'exact-match' | 'context-aware' | 'theme-toggle',
  colors: {
    // Your customizations here
  }
}
```

#### 2. Typography Hierarchy

**Question:** Should we extend the typography scale for documentation-heavy content?

**Context:**
- Morphism Hub has 3 heading levels (XL, LG, MD)
- Documentation often needs 5-6 levels (h1-h6)
- Code blocks need monospace styling

**Your Decision:**
```css
/* TODO: Define extended typography scale */
/* File: styles/morphism-typography.css */

.morphism-h1 { /* Your choice */ }
.morphism-h2 { /* Your choice */ }
.morphism-h3 { /* Your choice */ }
.morphism-h4 { /* Needed? */ }
.morphism-h5 { /* Needed? */ }
.morphism-h6 { /* Needed? */ }
```

#### 3. Navigation Structure

**Question:** What navigation pattern works best for different site types?

**Context:**
- Marketing: Fixed top nav (current Morphism Hub pattern)
- Docs: Left sidebar + top nav
- Dashboard: Top nav + left sidebar
- Component showcase: Top nav only

**Your Preferences:**
- Which sites need search?
- Should nav be collapsible on mobile?
- Sticky positioning for docs sidebar?

**Implementation Location:**
```tsx
// File: src/components/morphism/navigation/
// TODO: Implement your chosen patterns
```

#### 4. Demo Section Content

**Question:** What should be showcased in the demo sections?

**Context from your request:**
> "with the final additions and thoughts and vision and content to show/not show, demo, etc."

**Options to Consider:**
A. **Interactive Component Playground**
   - Live code editor
   - Component previews
   - Props documentation

B. **Mathematical Proofs Showcase**
   - Visual proof diagrams
   - κ < 1 convergence demonstration
   - Interactive fixed-point finder

C. **Agent Governance Demo**
   - Sample agent configurations
   - Drift detection simulation
   - Policy validation examples

D. **All of the Above** (Comprehensive showcase)

**Your Vision:**
```markdown
<!-- TODO: Define demo content strategy -->
<!-- File: docs/plans/DEMO_CONTENT_STRATEGY.md -->

# Demo Sections to Include

1. [ ] Component playground (Y/N)
2. [ ] Mathematical proofs (Y/N)
3. [ ] Agent governance (Y/N)
4. [ ] Other: __________________

Priority order: 1. _____ 2. _____ 3. _____
```

#### 5. Animation & Interactions

**Question:** How much interactivity should be added?

**Context:**
- Current Morphism Hub: Minimal animations (transitions only)
- Could add: Scroll reveals, parallax, hover effects, micro-interactions

**Options:**
A. **Minimal** - Keep current transition-only approach
B. **Moderate** - Add scroll reveals + enhanced hovers
C. **Rich** - Full animation suite with parallax

**Trade-offs:**
- Minimal: Fast, accessible, but less engaging
- Moderate: Good balance
- Rich: Most engaging, but performance concerns

**Your Preference:**
```typescript
// File: src/components/morphism/animations.ts
// TODO: Set animation philosophy
export const ANIMATION_LEVEL = 'minimal' | 'moderate' | 'rich'
```

---

## Next Steps

### Immediate Actions

1. **Review this plan** - Confirm direction and scope
2. **Make design decisions** - Answer the 5 decision points above
3. **Set up repository** - Create `morphism-design-system` package
4. **Extract components** - Begin Phase 2 implementation

### Questions for User

Before proceeding with implementation, please provide input on:

1. **Color Strategy** - Which option (A/B/C) for color scheme?
2. **Typography** - Do you need h4/h5/h6 levels?
3. **Navigation** - Specific requirements for each site type?
4. **Demo Content** - What should be showcased?
5. **Animation Level** - Minimal, moderate, or rich?
6. **Timeline** - Should we accelerate any phases?
7. **Target Sites** - Which sites should be updated first?

---

## Appendices

### A. Morphism Hub Tech Stack

```json
{
  "framework": "Next.js 15.2 (App Router)",
  "react": "19.0.0",
  "styling": "Tailwind CSS 3.4",
  "auth": "Clerk (org multi-tenancy)",
  "database": "Supabase (PostgreSQL + RLS)",
  "ai": "Google Gemini 2.0 Flash",
  "payments": "Stripe",
  "validation": "Zod",
  "testing": "Vitest",
  "deployment": "Vercel"
}
```

### B. Component Inventory

**From Morphism Hub:**
- `logo.tsx` (MorphismLogo, MorphismWordmark)
- `page.tsx` sections (Hero, Features, Pricing)
- `layout.tsx` (Nav, Footer structure)

**To Create:**
- `glass-nav.tsx`
- `hero-with-proof.tsx`
- `feature-grid.tsx`
- `pricing-cards.tsx`
- `button.tsx`
- `card.tsx`

### C. Design Token Reference

```typescript
// Complete token specification
export const MORPHISM_DESIGN_TOKENS = {
  colors: {
    bg: {
      primary: '#0a0a0f',
      glass: 'rgba(10, 10, 15, 0.8)',
      card: '#141419',
    },
    border: {
      subtle: 'rgba(255, 255, 255, 0.05)',
      default: 'rgba(255, 255, 255, 0.1)',
    },
    text: {
      primary: 'rgb(243 244 246)',    // gray-100
      secondary: 'rgb(156 163 175)',  // gray-400
      muted: 'rgb(107 114 128)',      // gray-500
    },
    accent: {
      blue: 'rgb(59 130 246)',        // blue-500
      blueHover: 'rgb(37 99 235)',    // blue-600
    },
  },
  typography: {
    fontFamily: {
      sans: ['Inter', 'system-ui', 'sans-serif'],
      mono: ['JetBrains Mono', 'monospace'],
    },
    fontSize: {
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '4xl': '2.25rem',
      '5xl': '3rem',
      '6xl': '3.75rem',
    },
    fontWeight: {
      normal: '400',
      medium: '500',
      semibold: '600',
      bold: '700',
    },
    letterSpacing: {
      tight: '-0.02em',
      normal: '0',
      wide: '0.02em',
    },
  },
  spacing: {
    containerMax: '72rem',      // 1152px
    sectionPy: {
      mobile: '4rem',
      desktop: '6rem',
    },
  },
  effects: {
    backdropBlur: {
      xl: '24px',
    },
    transition: {
      colors: '200ms',
      opacity: '200ms',
      transform: '200ms',
    },
  },
}
```

---

*Plan created by: Claude Sonnet 4.5*
*Date: 2026-02-09*
*Status: Awaiting user decisions on 5 key design points*
