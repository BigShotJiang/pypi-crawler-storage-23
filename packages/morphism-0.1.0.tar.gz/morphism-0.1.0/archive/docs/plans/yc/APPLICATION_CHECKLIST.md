# YC S26 Application Checklist

**Deadline:** Check https://www.ycombinator.com/apply for S26 deadline
**Note:** YC accepts late applications — better late than never

---

## Before Submitting

### Application Form
- [ ] Review and finalize answers in [YC_APPLICATION_ANSWERS.md](application/YC_APPLICATION_ANSWERS.md)
- [ ] Choose Draft A or Draft B for each answer (or combine)
- [ ] Fill in ALL [FOUNDER: ...] placeholders with real data
- [ ] Keep answers concise — YC reviewers read thousands
- [ ] Proofread for typos

### 1-Minute Video
- [ ] Practice the script from [YC_FOUNDER_ANSWERS.md](application/YC_FOUNDER_ANSWERS.md)
- [ ] Record in one take, looking at camera
- [ ] Show terminal with `morphism validate` at the 30-second mark
- [ ] Keep under 60 seconds
- [ ] Upload to YouTube (unlisted) or host on personal site
- [ ] Test the link works

### Profile & Links
- [ ] GitHub profile link (github.com/alawein)
- [ ] LinkedIn profile link
- [ ] Product URL (morphism.systems — if live)
- [ ] npm package links (if published)
- [ ] Any relevant blog posts or content

### Traction Evidence
- [ ] Run the [TRACTION_SPRINT.md](traction/TRACTION_SPRINT.md) before or during application
- [ ] Update application with real numbers
- [ ] Include design partner count (even if 0 — be honest)
- [ ] Include discovery call count
- [ ] Include npm download count (if published)

---

## After Submitting

### If Invited to Interview
- [ ] Review [INTERVIEW_PREP.md](interview/INTERVIEW_PREP.md) — practice all 30 questions
- [ ] Print [INTERVIEW_CHEAT_SHEET.md](interview/INTERVIEW_CHEAT_SHEET.md)
- [ ] Review [OBJECTION_HANDLING.md](interview/OBJECTION_HANDLING.md)
- [ ] Prepare terminal with Morphism commands ready to demo
- [ ] Test screen sharing if video interview
- [ ] Practice 15-second answers (time yourself)

### If Not Invited
- [ ] Continue the traction sprint
- [ ] Apply again next batch with updated numbers
- [ ] Many funded YC companies applied 2+ times — no penalty

---

## Quick Reference

| What | Where |
|------|-------|
| All draft answers | [application/YC_APPLICATION_ANSWERS.md](application/YC_APPLICATION_ANSWERS.md) |
| Video script | [application/YC_FOUNDER_ANSWERS.md](application/YC_FOUNDER_ANSWERS.md) |
| Interview prep | [interview/INTERVIEW_PREP.md](interview/INTERVIEW_PREP.md) |
| Cheat sheet | [interview/INTERVIEW_CHEAT_SHEET.md](interview/INTERVIEW_CHEAT_SHEET.md) |
| Traction plan | [traction/TRACTION_SPRINT.md](traction/TRACTION_SPRINT.md) |
| Business model | [business/BUSINESS_MODEL.md](business/BUSINESS_MODEL.md) |
| Full package | [YC_PACKAGE_README.md](YC_PACKAGE_README.md) |
