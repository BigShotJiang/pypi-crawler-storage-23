# Morphism — Technical One-Pager

---

## What It Is

A universal governance framework for AI coding agents. One configuration governs Claude Code, Cursor, GitHub Copilot, Windsurf, and any MCP-compatible tool.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    GOVERNANCE MODEL                          │
│  MORPHISM.md: 10 Axioms -> 42 Tenets (Category Theory)     │
│  AGENTS.md: Agent-readable governance rules                  │
│  .morphism/config.json: Consumer configuration               │
└──────────────┬──────────────────────────────────────────────┘
               │
               v
┌─────────────────────────────────────────────────────────────┐
│                    ENFORCEMENT LAYER                          │
│  @morphism-systems/tools: 14 CLI commands                            │
│  validate | drift    | sanitize | orchestrate                │
│  init     | baseline | coverage | review                     │
│  apply    | check    | analyze  | setup                      │
│  diff     | report   | scope    | promote                    │
└──────────────┬──────────────────────────────────────────────┘
               │
               v
┌─────────────────────────────────────────────────────────────┐
│                    INTEGRATION LAYER                          │
│  @morphism-systems/mcp: Model Context Protocol server (v2.0)        │
│  @morphism-systems/core: Types, utilities, governance primitives     │
│                                                              │
│  Targets: Claude Code | Cursor | Copilot | Windsurf | Any   │
└──────────────┬──────────────────────────────────────────────┘
               │
               v
┌─────────────────────────────────────────────────────────────┐
│                    PLATFORM (In Development)                  │
│  Morphism Hub: Next.js 15 + Supabase + Stripe + Clerk       │
│  Cloud validation, analytics dashboard, team management      │
└─────────────────────────────────────────────────────────────┘
```

---

## How the Governance Model Works

**Category Theory Foundations:**
- **Axioms** (10): Abstract structural principles derived from category theory (composition, identity, functoriality, etc.)
- **Tenets** (42): Operational rules derived from axioms. Each tenet maps to a specific enforcement mechanism.
- **Validation**: CLI tools check tenet compliance. Violations are reported with specific tenet IDs.

**Example flow:**
```
Axiom: "Composition Preservation"
  -> Tenet: "Every module must have a single entry point"
  -> Tenet: "Cross-module dependencies must be explicit"
  -> Validation: morphism validate checks entry points and dependency declarations
  -> Drift: morphism drift check detects new implicit dependencies
```

---

## What Makes It Hard to Replicate

1. **Formal model**: Categorical governance isn't arbitrary rules — it's derived from mathematical foundations. Competitors need equivalent formalism.
2. **Cross-tool portability**: Integrating with MCP, AGENTS.md, .cursorrules requires ongoing work as each tool evolves.
3. **Ecosystem tooling**: 14 CLI commands, ecosystem auditing, drift detection, secret scanning — months of compounding engineering.
4. **Network effects**: Once teams standardize on Morphism, switching costs are high.

---

## Performance

| Operation | Time | Scale |
|-----------|------|-------|
| morphism validate | < 5s | Full project validation |
| morphism drift check | < 3s | Baseline comparison |
| Ecosystem audit | < 30s | 1,976 files, 547 directories |
| Secret scan | < 10s | All tracked content |
| Quality gates (fast) | < 15s | Lint + type-check + test |

---

## Integration Surface

| AI Tool | Integration Method | Status |
|---------|-------------------|--------|
| Claude Code | AGENTS.md + .claude/ + MCP | Full |
| Cursor | .cursorrules generation | Designed |
| GitHub Copilot | MCP server | Designed |
| Windsurf | MCP server | Designed |
| CI/CD (GitHub Actions) | CLI commands in workflow | Shipped |
| Custom tools | @morphism-systems/core + @morphism-systems/mcp | Available |

---

## Security Model

- **Secrets**: Never committed. .secrets/ gitignored. security-preflight.sh scans tracked content.
- **Validation**: Schema-based. All configs validated against .morphism/schemas/.
- **Permissions**: CODEOWNERS-based ownership attribution.
- **Audit trail**: Ecosystem audit generates reproducible artifacts.
- **Compliance-ready**: Audit artifacts suitable for SOC2/GDPR evidence.

---

## Stack

| Layer | Technology |
|-------|-----------|
| Language | TypeScript (framework), Python (tooling), Bash (automation) |
| Runtime | Node.js >= 18, pnpm 8.x |
| Build | Turbo 2.8, tsup, esbuild |
| Testing | Vitest, Jest, Playwright |
| Platform | Next.js 15, React 19, Supabase, Stripe, Clerk |
| Protocol | Model Context Protocol (MCP) |
| CI | GitHub Actions |
