# YC Interview Cheat Sheet — Print This

**One-line answers. Keep next to camera.**

---

| Question | Answer |
|----------|--------|
| What do you do? | Governance layer for AI coding agents. One config, every tool. |
| Why is this a company? | No vendor will govern competitors. Cross-tool layer must be independent. |
| Who's your competitor? | Doing nothing. No one governs AI agents across tools today. |
| How do you make money? | Open-core SaaS. Free CLI, $20/dev Teams, $40/dev Enterprise. |
| How big is the market? | $3.6B TAM. 15M devs using AI tools x $20/month. |
| Why now? | AI coding tools just hit critical mass. Governance is at zero. |
| Do you have users? | [INSERT REAL NUMBER] design partners. [X] npm downloads. |
| Revenue? | Pre-revenue. Product built. Distribution activating now. |
| Why you? | Built entire framework solo. 14 CLI commands. Category theory background. |
| Solo founder risk? | v1 shipped solo. Now hiring. Need GTM cofounder. |
| What kills you? | Vendors add basic governance before we're the standard. |
| What do you need from YC? | Enterprise network + Demo Day + cofounder matching. |
| Path to $1M ARR? | Month 15. 75 companies, 43 seats avg, $30/seat. |
| Biggest risk? | Category creation — convincing teams they need governance. |
| Show me the product? | [Run: morphism validate, morphism drift check] |

---

**Remember:**
- < 15 seconds per answer
- Be honest about 0 users
- Show the terminal if asked for demo
- Don't explain category theory unless asked
