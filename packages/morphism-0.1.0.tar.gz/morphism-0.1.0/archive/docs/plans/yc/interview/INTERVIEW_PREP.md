# YC Interview Prep — 30 Questions with Crisp Answers

**Generated:** 2026-02-09
**Format:** YC interviews are 10 minutes. Answers must be < 15 seconds each.

---

## Product Questions

### 1. What do you do?
"We're the governance layer for AI coding agents. One config enforces rules across Claude, Cursor, Copilot — with validation, drift detection, and audit trails."

### 2. Can you show me?
"Yes. [Open terminal] `morphism validate` — checks governance compliance. `morphism drift check` — catches when agents deviate. 14 commands total, all working."

### 3. Why is this a company and not a feature?
"No single AI vendor will build governance for their competitors. Anthropic won't govern Cursor. GitHub won't govern Claude. The cross-tool layer must be independent."

### 4. What does your product actually do technically?
"Define governance rules in a `.morphism/` config. Our CLI validates compliance across your codebase. Our MCP server integrates with any AI tool. Our drift engine catches deviations over time."

### 5. What's the hardest technical problem you've solved?
"Making governance portable across fundamentally different AI tools. Each tool has its own format — AGENTS.md, .cursorrules, MCP. We abstract over all of them from a single formal model."

---

## Market Questions

### 6. How big is this market?
"Every developer using AI coding tools needs governance. That's ~15M developers in 2026. At $20-40/dev/month, the TAM is $3.6B."

### 7. Who's your competitor?
"Today, the main competitor is 'doing nothing.' Most teams have zero AI agent governance. The closest alternatives are writing separate AGENTS.md files per tool — manual, un-validated, tool-specific."

### 8. Why won't [Anthropic/GitHub/Cursor] just build this?
"Each vendor will build governance for THEIR tool. None will build for competitors. The cross-tool governance layer is structurally independent — like how Terraform works across AWS, GCP, and Azure."

### 9. Is this really a problem people have?
"Yes. Enterprises want to roll out AI coding tools but compliance teams block it because there's no governance. We're solving the blocker. [Add real quotes from design partner calls if available]."

### 10. Why now?
"AI coding tool adoption just crossed the tipping point. Claude Code, Cursor, Copilot are all maturing simultaneously. Multi-tool usage creates governance fragmentation. The problem didn't exist 18 months ago."

---

## Business Questions

### 11. How do you make money?
"Open-core SaaS. Free CLI drives adoption. Teams pay $20/dev/month for cloud dashboard, drift history, and alerts. Enterprise pays $40/dev/month for SSO, compliance reporting, and custom policies."

### 12. What do you charge?
"$20/dev/month for teams, $40/dev/month for enterprise. Comparable to Snyk and Semgrep."

### 13. How do you get customers?
"Product-led growth. Developer discovers free CLI on npm → uses it → shares with team → team wants dashboard → pays for Teams tier. Plus direct outreach to platform engineering teams."

### 14. What's your revenue?
"$0 today. We've been building the technical foundation. We're now pivoting to distribution — npm publication, landing page, and design partner outreach are happening this month."

### 15. What are your unit economics?
"~90% gross margin (SaaS). Blended CAC ~$32/seat via PLG. LTV ~$831/seat (33-month lifetime). LTV/CAC is 26x."

---

## Traction Questions

### 16. Do you have users?
"[Be honest] We have [X] design partners and [Y] npm downloads as of today. [OR] No external users yet — we just published. Our first design partners are onboarding now."

### 17. Do you have revenue?
"No. We're pre-revenue. The product is built — now we're activating distribution."

### 18. What traction do you have?
"[Use real numbers] X design partners, Y discovery calls, Z npm downloads. [OR] We shipped v1 with 14 CLI commands, MCP integration, and drift detection. External traction starts this month."

### 19. How will you get your first 10 customers?
"Publish npm packages → HN launch → direct outreach to 50 platform engineering teams → 20 discovery calls → 5 design partners → 3 convert to paid."

### 20. When will you get to $1M ARR?
"Month 15 in our base case. 75 companies, average 43 seats, at $30/seat blended."

---

## Team Questions

### 21. Why you? What's your unfair advantage?
"I built the entire framework solo — 14 CLI commands, MCP integration, formal governance model, validation pipeline. I ship fast. And my category theory background enabled the formal model that no one else has."

### 22. You're a solo founder — can you scale this?
"Building the technical foundation required solo focus. Now that v1 is shipped, I'm hiring. Priority: developer advocate + engineer. YC's network accelerates this."

### 23. What's your background?
"[FOUNDER: Berkeley education, prior experience, relevant technical depth]"

### 24. Have you worked on this full-time?
"[FOUNDER: Be honest — yes/no, since when]"

### 25. Are you looking for a cofounder?
"Yes — someone with developer tools GTM experience. I have the technical side. I need a partner for distribution and enterprise sales."

---

## Risk Questions

### 26. What kills your company?
"AI tool vendors adding 'good enough' native governance before we establish the standard. We mitigate by being cross-tool — the one thing no vendor will build for competitors."

### 27. What if AI coding tools are just a fad?
"They're not. GitHub reports 50%+ of new code is AI-assisted. The trend is accelerating, not slowing. The question is whether governance becomes standardized — not whether AI coding persists."

### 28. What's the hardest thing about this business?
"Category creation. We need to convince teams they have a governance problem before we can sell the solution. That's why our free CLI is critical — let them experience the value, then monetize."

### 29. What if nobody pays for this?
"Developer tool governance is a proven category. Companies pay $25-50/dev/month for Snyk, Semgrep, SonarQube. AI agent governance is the next layer. The spend is there."

### 30. What do you need from YC?
"Distribution. The product is built. I need YC's enterprise network for design partners, Demo Day for visibility, and the YC brand to close enterprise deals. Plus a cofounder match."

---

## Meta-Tips for the Interview

1. **Be concise.** Every answer under 15 seconds. They'll ask follow-ups if they want more.
2. **Be honest about weaknesses.** "0 users" is fine. "0 users with a plan to get 10" is better.
3. **Show the product.** If they ask "can you show me?" — be ready to run `morphism validate` live.
4. **Don't over-explain the formal model.** They care about the product, not category theory.
5. **Energy matters.** Be excited but not manic. Confident but not arrogant.
6. **Know your numbers.** TAM, pricing, unit economics, timeline to $1M ARR.
7. **Have a clear ask.** "We need YC for [specific thing]" is better than "we need funding."
