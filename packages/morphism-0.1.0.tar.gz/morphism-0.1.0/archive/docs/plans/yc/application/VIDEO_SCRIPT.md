# 1-Minute Video Script for YC

**Duration:** 60 seconds
**Format:** Talking head + screen recording
**Goal:** Show problem, solution, traction

---

## Script

### Opening (0-10 seconds)

**[On camera, confident]**

> "Hi, I'm [Your name]. I'm building Morphism—the first AI governance framework with mathematical convergence guarantees."

---

### Problem (10-25 seconds)

**[Screen: Agent without Morphism failing]**

> "AI agents are powerful, but they can diverge. Watch this agent reveal its system prompt when given adversarial input."

**[Show terminal: adversarial input → system prompt leaked]**

> "No validation. No safety net. This is how most agents work today."

---

### Solution (25-45 seconds)

**[Screen: Agent with Morphism blocking attack]**

> "Morphism changes that. Every agent gets a contraction constant—kappa—proven to be less than 1 in Lean 4."

**[Show terminal: adversarial input → blocked by governance]**

> "The agent detected the attack and refused to process it. Convergence maintained."

**[Show Lean 4 proof snippet]**

> "This isn't just monitoring—it's mathematical proof that your agents will never diverge."

---

### Traction (45-55 seconds)

**[On camera]**

> "We've already deployed this in production. Two apps, zero governance violations in six months."

**[Screen: morphism.systems]**

> "We're targeting enterprise AI teams. If you're deploying agents at scale, we'd love to work with you."

---

### Call to Action (55-60 seconds)

**[On camera, direct]**

> "Apply to work with us at morphism.systems. Let's make AI safe."

**[End screen: morphism.systems + GitHub link]**

---

## Production Notes

### Equipment
- **Camera:** Webcam or phone (1080p minimum)
- **Mic:** Lapel mic or USB mic (clear audio critical)
- **Lighting:** Natural light or ring light (face well-lit)
- **Background:** Clean, minimal (bookshelf or plain wall)

### Screen Recording
- **Tool:** QuickTime (Mac) or OBS (Windows/Linux)
- **Resolution:** 1920x1080
- **Font size:** Large (18pt+ for terminal)
- **Speed:** Slow down terminal commands (readable)

### Editing
- **Tool:** iMovie, Final Cut, or DaVinci Resolve
- **Transitions:** Quick cuts (no fades)
- **Music:** None (voice only, clear)
- **Captions:** Add subtitles (accessibility + silent viewing)

### Delivery
- **Format:** MP4 (H.264)
- **Resolution:** 1920x1080
- **Framerate:** 30fps
- **File size:** <50MB (YC upload limit)

---

## Rehearsal Checklist

- [ ] Practice script 5x (memorize, don't read)
- [ ] Time yourself (stay under 60 seconds)
- [ ] Test screen recording (readable, smooth)
- [ ] Check audio (no background noise)
- [ ] Review lighting (face visible, no shadows)
- [ ] Test upload (file size, format)

---

## Alternative: Asciinema Version

If you prefer terminal-only (no talking head):

**0-10s:** Title card: "Morphism: Mathematical Governance for Safe AI"
**10-30s:** Demo without Morphism (agent fails)
**30-50s:** Demo with Morphism (agent blocks attack)
**50-60s:** End card: "morphism.systems | Apply to work with us"

**Pros:** Easier to record, no camera needed
**Cons:** Less personal, harder to convey passion

---

## Key Messages

1. **Problem is real:** Agents can diverge (show it)
2. **Solution is unique:** Mathematical proofs (show Lean 4)
3. **Traction is real:** Production deployments (state it)
4. **Call to action:** Apply to work with us (clear)

---

## What NOT to Do

❌ Don't go over 60 seconds (YC will cut you off)
❌ Don't use jargon without explanation (assume non-technical)
❌ Don't show slides (boring, use live demo)
❌ Don't apologize or hedge ("we think", "maybe")
❌ Don't forget call to action (tell them what to do)

---

## Recording Day Checklist

**Before:**
- [ ] Charge devices (camera, mic)
- [ ] Test equipment (audio, video)
- [ ] Prepare demo (terminal ready)
- [ ] Clear background (clean space)
- [ ] Dress professionally (solid colors, no patterns)

**During:**
- [ ] Record 3-5 takes (pick best)
- [ ] Check audio after each take
- [ ] Review footage (lighting, framing)
- [ ] Record B-roll (screen recordings)

**After:**
- [ ] Edit video (cuts, captions)
- [ ] Export (MP4, <50MB)
- [ ] Upload to YouTube (unlisted)
- [ ] Test playback (all devices)
- [ ] Submit to YC

---

_This video is your first impression. Make it count._
