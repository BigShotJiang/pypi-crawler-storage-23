# YC S26 — Founder Answers & Video Script

**Generated:** 2026-02-09
**Status:** DRAFT — Requires personalization

---

## Tell us about yourselves

**Draft A:**
[FOUNDER: Fill in with real bio]
- Name: Meshal Alawein
- Education: [Berkeley — specify degree, year]
- Background: [Prior work experience, relevant domain expertise]
- Built: 10+ production projects including 2 deployed web platforms (BOLTS.FIT, LLMWorks), a QAP optimization library, an agent orchestration system (31 tools), and the complete Morphism governance framework
- Technical depth: Category theory foundations, TypeScript/Python, full-stack web, AI tooling

**Draft B:**
I'm Meshal Alawein, [Berkeley background]. I've built [X] production projects across fitness platforms, LLM evaluation tools, and AI agent systems. I built Morphism because I was the power user — working across 4 AI coding tools daily, I experienced governance fragmentation firsthand. My category theory background enabled the formal model that makes Morphism more than just another config file. I ship fast: the current system has 14 CLI commands, MCP integration, drift detection, and a complete validation pipeline — all built solo.

---

## 1-Minute Video Script

**IMPORTANT:** This is the most important part of the YC application. Record this in one take, looking at the camera, from your desk. No slides, no editing needed.

### Script (60 seconds)

```
[0-10s] HOOK
"Hi, I'm Meshal. I'm building Morphism — the governance layer for AI coding agents.

[10-25s] PROBLEM
Here's the problem: developers now use Claude, Cursor, and Copilot — often all three
on the same project. But each tool has its own rules format. AGENTS.md works for Claude.
.cursorrules works for Cursor. And there's no validation that any agent actually follows
the rules. For enterprises, this is a blocker — compliance teams won't approve AI tools
they can't govern.

[25-40s] SOLUTION + DEMO MOMENT
Morphism solves this. One config file governs all your AI tools.
[Show terminal] I run 'morphism validate' — it checks every governance rule across
the entire project. I run 'morphism drift check' — it catches when agents deviate
from the baseline. One source of truth, every tool, validated and audited.

[40-50s] WHY NOW
AI coding adoption is exploding, but governance is stuck at zero. Every enterprise
adopting these tools will need this layer. We're building the Terraform for AI
agent behavior.

[50-60s] ASK
We're applying to YC S26 to get our first 10 enterprise design partners and
establish Morphism as the standard for AI agent governance. Thank you."
```

### Video Tips
- Record at your desk with your code editor visible behind you
- Look directly at the camera
- Speak conversationally, not scripted
- One take is fine — YC doesn't care about production quality
- If you can show a real `morphism validate` command running, do it at the 30s mark
- Keep it under 60 seconds

---

## How did you meet your cofounders? / Solo founder narrative

**Solo Founder Framing:**

**Draft A:**
I'm a solo founder. I chose to build alone because Morphism's technical foundation (category theory + governance model + cross-tool integration) requires deep, focused work that's hard to divide early. The risk is execution breadth — I need help with enterprise sales and developer marketing. My plan: use YC to find a technical cofounder or first engineering hire, and leverage the YC network for enterprise introductions.

**Draft B:**
Solo founder by choice during the technical foundation phase. Building a formal governance model requires deep, uninterrupted work. Now that v1 is shipped, the hiring priority is clear: (1) a developer advocate to drive OSS adoption, (2) an enterprise sales lead for design partners. I'm looking for a cofounder with GTM experience in developer tools. YC's network is the fastest path to finding that person.

---

## What convinced you to work on this?

**Draft A:**
I was building across Claude Code and Cursor on the same project and realized my AGENTS.md rules didn't apply in Cursor. My .cursorrules didn't apply in Claude. And when I added Copilot, there was nothing at all. I searched for a cross-tool governance solution and found nothing. Every team adopting multiple AI tools will hit this exact problem. The category is being defined right now, and I want to define it.

**Draft B:**
Three things: (1) Personal pain — working across 4 AI tools with zero governance, (2) Timing — agentic coding just crossed the adoption tipping point, but governance is at zero, (3) Insight — no single AI vendor will build governance for competitors' tools. The cross-tool governance layer must be independent. That's Morphism.

---

## How will you get your first 10 customers?

**Draft A:**
1. Publish @morphism-systems/* packages on npm (free, discoverable)
2. Write the definitive guide on "AI Agent Governance" (category-defining content)
3. Post on Hacker News — this is a topic developers care about now
4. Direct outreach to 50 platform engineering teams at companies publicly adopting AI tools
5. Offer free onboarding for first 10 design partners
6. Leverage YC network for enterprise introductions

**Draft B:**
Week 1: Publish npm packages + landing page.
Week 2: HN post + direct outreach to 50 target companies.
Week 3: 20 discovery calls → 5 design partners.
Week 4: Design partners using Morphism → feedback → iterate.
By Demo Day: 10 design partners, 3 converting to paid.

---

## Where do you want to be in 1 year? 5 years?

**1 year:**
- 50+ companies using Morphism
- $500K ARR from enterprise governance dashboard
- npm packages with 10K+ weekly downloads
- "AI agent governance" established as a recognized category
- Team of 5 (eng + GTM)

**5 years:**
- Standard governance layer for AI coding tools (like ESLint is for JS)
- Integrated into CI/CD pipelines at 5,000+ companies
- $50M+ ARR
- Expanded beyond coding agents to AI agent governance broadly (support agents, data agents, etc.)

---

## Why should YC fund you specifically?

**Draft A:**
Three reasons: (1) I've already built the technical foundation — 14 CLI commands, MCP integration, formal governance model, and validation pipeline, all solo. This demonstrates execution speed. (2) The timing is perfect — AI agent governance is needed now, and no one else is building the cross-tool layer. (3) I need YC's network to convert this technical foundation into enterprise traction. The product exists; I need distribution.

**Draft B:**
I ship. Solo founder, built: formal governance model, 14-command CLI, MCP integration, drift detection, validation pipeline, ecosystem audit tooling, and a web dashboard — all in [X months]. What I need from YC isn't help building — it's help distributing. YC's enterprise network + demo day + credibility signal turns this from "impressive solo project" into "the standard for AI agent governance."
