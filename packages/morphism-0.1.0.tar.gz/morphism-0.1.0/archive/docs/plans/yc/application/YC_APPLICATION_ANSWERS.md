# YC S26 Application — Draft Answers

**Generated:** 2026-02-09
**Status:** DRAFT — Requires founder review and personalization
**Format:** Two versions per answer (A = conservative, B = strongest framing)

---

## Company Name
**Morphism**

---

## One-line description (max 60 chars)

**Draft A:** Governance layer for AI coding agents
**Draft B:** One config to govern all your AI coding tools

---

## What does your company do?

**Draft A:**
Morphism provides a universal governance framework for AI coding agents. Teams define rules once in a `.morphism/` config, and those rules are enforced across Claude Code, Cursor, GitHub Copilot, and any MCP-compatible tool. We provide validation, drift detection, and audit trails so enterprises can adopt AI coding tools without losing control.

**Draft B:**
Morphism is the governance layer for AI coding agents. One config file governs all your AI tools — Claude, Cursor, Copilot. We validate compliance, detect drift, and provide audit trails. Think of us as Terraform for AI agent behavior: define once, enforce everywhere.

---

## Why did you pick this idea? What domain expertise do you have?

**Draft A:**
I've been building with AI coding tools since early 2025 and experienced the governance gap firsthand. When working across Claude Code and Cursor on the same project, rules were inconsistent — AGENTS.md worked for Claude but Cursor had its own format. I realized every team adopting multiple AI tools would hit this problem. I built Morphism because I needed it, then realized every enterprise would need it too.

[FOUNDER: Add your specific background — Berkeley education, prior work, technical depth]

**Draft B:**
I built Morphism because I was the user. Working across 4 AI coding tools simultaneously, I watched governance fragment — different rules per tool, no validation, no audit trail. The problem is structural: AI tools are multiplying but governance is tool-specific. I have [X years] building developer tools and a category theory background that enabled the formal governance model. I've shipped 10+ production projects including this framework's 14-command CLI.

---

## What's new about what you're making? What substitutes exist?

**Draft A:**
Today, AI agent governance is fragmented. AGENTS.md works only with Claude. .cursorrules works only with Cursor. There's no cross-tool standard and no way to validate compliance. Morphism creates a single governance configuration that works across all AI coding tools, with automated validation, drift detection, and audit trails. The closest substitutes are writing separate instruction files per tool (manual, un-validated) or not governing AI agents at all (risky).

**Draft B:**
Nobody governs AI coding agents today. The substitutes are: (1) AGENTS.md — Claude-only, no validation, (2) .cursorrules — Cursor-only, static text, (3) nothing — most teams. Morphism is the first cross-tool governance layer with formal foundations, automated enforcement, and drift detection. We're building the Terraform for AI agent behavior — the infrastructure layer that enterprises will require before rolling out AI coding tools at scale.

---

## Who are your users? How do you know they need this?

**Draft A:**
Our target users are platform engineering and DevOps teams at companies with 50+ developers adopting AI coding tools. We know they need this because: (1) AI tool adoption is accelerating but enterprise compliance teams are blocking rollout due to lack of governance, (2) every developer using multiple AI tools experiences rule fragmentation, and (3) security incidents from ungoverned AI agents are beginning to surface.

[FOUNDER: Add any real conversations, pain statements, or signal from potential users]

**Draft B:**
Platform engineers and security teams at companies adopting AI coding tools. The signal is clear: enterprises want to use Claude/Cursor/Copilot but compliance teams block rollout because there's no governance. We're solving the blocker. Every company with a SOC2 audit and AI coding tools will need this.

[FOUNDER: Replace with real evidence — # conversations, specific quotes, named companies willing to pilot]

---

## What is your revenue model? How much could you charge?

**Draft A:**
Open-core SaaS. Free CLI tools for individual developers. Paid cloud dashboard for teams ($15-25/dev/month) with validation, drift detection, and audit trails. Enterprise tier ($30-50/dev/month) with SSO, compliance reporting, and custom policy engines. Comparable to Snyk ($15-50/dev/month) and Semgrep ($40/dev/month for Teams).

**Draft B:**
Per-seat SaaS. Free OSS framework drives adoption. Teams tier: $20/dev/month (cloud validation, drift detection, audit dashboard). Enterprise tier: $40/dev/month (SSO, compliance reporting, custom policies). Comp set: Snyk ($8.5B valuation, similar per-seat model), Semgrep (Series C, $40/dev/month). AI governance is a new budget line — we define the pricing.

---

## How far along are you?

**Draft A:**
We've built the complete framework: formal governance model (10 axioms → 42 tenets), 14-command CLI, MCP integration, drift detection engine, validation pipeline, and ecosystem audit tooling. We have a web dashboard (Morphism Hub) in development using Next.js 15 + Supabase + Stripe. We have 0 external users and $0 revenue. All work to date is solo founder.

**Draft B:**
v1 shipped. 14-command CLI, MCP integration for AI tool interop, drift detection, automated validation, and formal governance model. Web dashboard in development. 0 external users — we've been heads-down building the technical foundation. Now pivoting to distribution: npm publication, landing page, and design partner outreach in the next 4 weeks.

---

## How long have the founders been working on this? Full-time?

[FOUNDER: Fill in accurately]
- Started: [month/year]
- Full-time: [yes/no — since when]
- Prior iteration: Previously called "Kiro" — migrated to Morphism in Feb 2026

---

## How do you acquire users/customers?

**Draft A:**
Three channels: (1) Open-source CLI tools on npm — developers discover and adopt the free tools, (2) Content marketing — publish articles and guides on AI agent governance (new category, high SEO opportunity), (3) Direct outreach to platform engineering teams at companies adopting AI coding tools.

**Draft B:**
Open-source led. Publish @morphism-systems/* packages on npm. Developers adopt free CLI → teams upgrade for cloud features. Content marketing on AI governance (category-defining content). Direct outreach to platform engineering teams at 50 target companies. Goal: 5 design partners in 4 weeks, 10 by Demo Day.

---

## What's the biggest risk?

**Draft A:**
That AI tool vendors (Anthropic, Cursor, GitHub) build native governance features that are "good enough" for most teams, commoditizing the cross-tool layer. We mitigate this by: (1) being cross-tool — no single vendor will build for competitors, (2) moving fast to establish the standard, and (3) going deeper than basic features (formal model, drift detection, compliance reporting).

**Draft B:**
Platform risk — AI tool vendors adding basic governance. Mitigation: no single vendor will govern competitors' tools. Anthropic won't build Cursor governance. GitHub won't build Claude governance. The cross-tool layer is a natural independent product. We need to be the standard before "good enough" native features arrive (~12-18 months).

---

## Who writes code? Was any AI-generated?

**Draft A:**
Solo founder writes all code. AI coding tools (Claude Code, Cursor) are used extensively for development — approximately 40-60% of code is AI-assisted. All code is reviewed, validated, and tested by the founder. This is relevant: we're building governance for AI coding tools, and we use them daily. We experience the problem firsthand.

**Draft B:**
Solo founder, heavily AI-assisted (Claude Code + Cursor). ~50% of code is AI-generated with human review. We're building governance for AI coding — we eat our own dog food daily. Every governance gap we find in our own workflow becomes a product feature.

---

## IMPORTANT: What This Draft Needs

Before submitting, the founder MUST:

1. **Add real numbers** — Replace all [FOUNDER: ...] placeholders with actual data
2. **Add traction evidence** — Even if 0 users, add: # customer conversations, # people on waitlist, # design partner commitments
3. **Record the 1-minute video** — See YC_FOUNDER_ANSWERS.md for script
4. **Verify the deadline** — Check https://www.ycombinator.com/apply for S26 deadline
5. **Be honest** — YC values clarity over spin. "0 users, strong technical foundation, starting outreach now" is better than vague claims
6. **Keep answers short** — YC reviewers read thousands of applications. Brevity wins.
