# Morphism Demo Script — 2 Minutes

**Purpose:** Show Morphism working in a real project
**Audience:** YC partners, potential design partners, investors
**Prerequisite:** Morphism framework installed locally

---

## Setup (Before Recording)

```bash
# Ensure you're in the workspace root
cd c:\Users\mesha\Desktop\GitHub

# Have the terminal visible with dark theme, large font
# Pre-run all commands once to verify output
```

---

## Script

### [0:00-0:15] Hook — The Problem

**Say:** "Every team using AI coding tools has a governance problem. AGENTS.md works for Claude. .cursorrules works for Cursor. Copilot has nothing. And none of them validate that rules are actually followed."

**Show:** Quick flash of an AGENTS.md file, a .cursorrules file, and an empty Copilot config.

---

### [0:15-0:40] Demo — The Solution

**Say:** "Morphism fixes this with one governance configuration that works across all tools."

**Run these commands live:**

```bash
# 1. Show the governance config
cat .morphism/config.json
```

**Say:** "One config file. It points to the governance model, defines validation rules, and declares compatibility with Claude, Cursor, Copilot, and Windsurf."

```bash
# 2. Show the formal governance model (briefly)
head -30 morphism/MORPHISM.md
```

**Say:** "The governance model is based on 10 axioms that derive 42 operational tenets. It's mathematically grounded — not arbitrary rules."

---

### [0:40-1:10] Demo — Validation and Drift

```bash
# 3. Run validation
cd morphism
pnpm run morphism:validate
```

**Say:** "One command validates governance compliance across the entire project. It checks structure, naming, documentation standards, and policy enforcement."

```bash
# 4. Run drift detection
pnpm run drift:check
```

**Say:** "Drift detection catches when your codebase deviates from the governance baseline over time. This is critical for enterprises — you need to know when AI agents go off-track."

---

### [1:10-1:30] Demo — CLI Power

```bash
# 5. Show the full CLI
pnpm run morphism:help
```

**Say:** "14 commands: validate, drift, init, apply, coverage, analyze, sanitize, orchestrate, review, and more. This isn't a prototype — it's a complete governance toolkit."

```bash
# 6. Show ecosystem audit
cd ..
py -3 scripts/ecosystem_audit.py all
```

**Say:** "The ecosystem audit scans your entire workspace — multiple repos, thousands of files — and generates compliance artifacts. Ownership coverage, security posture, governance status."

---

### [1:30-1:50] The Cross-Tool Story

**Say:** "Here's the key insight: this governance layer is tool-agnostic."

**Show:** `.morphism/config.json` — point to the compatibility section:
```json
"compatibility": {
  "morphism": "1.0.0",
  "claude": "1.x",
  "cursor": "0.x",
  "copilot": "0.x",
  "windsurf": "0.x"
}
```

**Say:** "One config. Every AI tool. Validated, versioned, enforced. No other product does this."

---

### [1:50-2:00] Close

**Say:** "Morphism is the governance layer for AI coding agents. We're looking for design partners — enterprise teams adopting AI tools that need governance before rollout. If that's you, let's talk."

---

## Backup Commands (if something fails)

```bash
# Show quality gates
cd morphism && pnpm run quality:check:fast

# Show secret scanning
bash scripts/security-preflight.sh

# Show workspace status
bash ./workspace status --fast

# Show component inventory
cat .morphism/inventory/INVENTORY.md | head -50
```

---

## Recording Tips

1. **Use a dark terminal theme** — looks more professional on video
2. **Increase font size** — viewers need to read terminal output
3. **Pre-run commands once** — so you know what output to expect
4. **Don't explain every line** — keep moving, show velocity
5. **If a command fails** — acknowledge it briefly and move on
6. **Total time:** 2 minutes max. Cut if over.

---

## What This Demo Proves

- The product exists and runs (not a mockup)
- The CLI is real (14+ commands)
- Validation and drift detection work
- The cross-tool story is concrete (config shows it)
- Ecosystem-scale tooling is operational
- Solo founder shipped all of this
