# Unit Economics — Morphism

**Generated:** 2026-02-09

---

## Per-Seat Economics

### Teams Tier ($20/dev/month)

| Metric | Value | Notes |
|--------|-------|-------|
| Revenue/seat/month | $20 | |
| Revenue/seat/year | $240 | |
| COGS/seat/month | ~$2 | Cloud infra (Supabase, Vercel) |
| Gross margin | ~90% | SaaS standard |
| Gross profit/seat/year | $216 | |

### Enterprise Tier ($40/dev/month)

| Metric | Value | Notes |
|--------|-------|-------|
| Revenue/seat/month | $40 | |
| Revenue/seat/year | $480 | |
| COGS/seat/month | ~$4 | Cloud infra + support cost |
| Gross margin | ~90% | |
| Gross profit/seat/year | $432 | |

---

## Customer Acquisition Cost (CAC)

### Developer-Led (Product-Led Growth)
| Channel | Cost | Conversion Rate | CAC/Company |
|---------|------|-----------------|-------------|
| npm + content marketing | ~$0 (time) | 2% of active users | ~$200 |
| Hacker News / community | ~$0 (time) | 1% of readers | ~$100 |
| GitHub stars → trial | ~$0 (time) | 5% of stars | ~$150 |

### Direct Sales (Enterprise)
| Channel | Cost | Conversion Rate | CAC/Company |
|---------|------|-----------------|-------------|
| Direct outreach | $500/qualified lead | 10% close rate | ~$5,000 |
| YC network intros | $0 | 20% close rate | ~$500 |
| Conference/event | $2,000/event | 5% close rate | ~$3,000 |

### Blended CAC (Year 1)
- **PLG channel:** $150/company (60% of customers)
- **Direct sales:** $3,000/company (40% of customers)
- **Blended CAC:** ~$1,290/company
- **Blended CAC/seat:** ~$32 (assuming avg 40 seats/company)

---

## Lifetime Value (LTV)

| Assumption | Value |
|-----------|-------|
| Average revenue/seat/month | $28 (blended Teams + Enterprise) |
| Average seats/company | 40 |
| Monthly churn | 3% (conservative for new product) |
| Average lifetime | 33 months (1/0.03) |
| Gross margin | 90% |

**LTV per seat:** $28 x 33 x 0.90 = **$831**
**LTV per company:** $831 x 40 = **$33,240**

---

## LTV/CAC Ratio

| Metric | Value | Target |
|--------|-------|--------|
| LTV/seat | $831 | |
| CAC/seat | $32 | |
| **LTV/CAC** | **26x** | > 3x |
| LTV/company | $33,240 | |
| CAC/company | $1,290 | |
| **LTV/CAC (company)** | **25.8x** | > 3x |

These ratios are very strong because:
1. Near-zero COGS (SaaS)
2. Product-led growth keeps CAC low
3. Seat expansion within companies drives NDR > 100%

---

## Path to $1M ARR

| Milestone | Companies | Avg Seats | Total Seats | Avg Revenue/Seat | MRR | ARR |
|-----------|-----------|-----------|-------------|-------------------|-----|-----|
| Month 3 | 5 | 20 | 100 | $20 | $2K | $24K |
| Month 6 | 15 | 30 | 450 | $24 | $10.8K | $130K |
| Month 9 | 30 | 35 | 1,050 | $28 | $29.4K | $353K |
| Month 12 | 50 | 40 | 2,000 | $30 | $60K | $720K |
| Month 15 | 75 | 45 | 3,375 | $32 | $108K | **$1.3M** |

**Key assumptions:**
- Seat expansion within companies (land and expand)
- Enterprise mix increases over time (higher ARPU)
- Churn decreases as product matures
- YC Demo Day drives initial pipeline

---

## Sensitivity Analysis

| Variable | Bear | Base | Bull |
|----------|------|------|------|
| Companies at Month 12 | 20 | 50 | 100 |
| Avg seats/company | 25 | 40 | 60 |
| Blended price/seat | $18 | $28 | $35 |
| **ARR at Month 12** | **$108K** | **$672K** | **$2.5M** |

**Break-even point:** ~$30K MRR covers a 3-person team (founder + 2 hires). Achievable by Month 6-9 in base case.

---

## Key Risks to Unit Economics

1. **High churn early** — New category, unclear buyer commitment. Mitigate: free tier reduces risk, design partner program builds commitment.
2. **Long enterprise sales cycles** — 3-6 months for enterprise. Mitigate: PLG drives Teams tier faster.
3. **Price pressure** — If AI vendors add basic governance. Mitigate: go deeper (compliance, audit, cross-tool) than basic features.
4. **Seat contraction** — Companies reduce AI tool adoption. Mitigate: unlikely given industry trends.
