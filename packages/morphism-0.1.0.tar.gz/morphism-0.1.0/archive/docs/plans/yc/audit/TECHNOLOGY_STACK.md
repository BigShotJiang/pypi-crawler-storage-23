# Technology Stack — Complete Technical Inventory

**Generated:** 2026-02-09
**Workspace:** Morphism Ecosystem

---

## Language Distribution

| Language | Files | Percentage | Primary Use |
|----------|-------|------------|-------------|
| Markdown | 739 | 52% | Documentation, governance definitions |
| Bash/Shell | 141 | 10% | Automation, validation, CI scripts |
| JSON | 114 | 8% | Configuration, schemas, package manifests |
| Python | 55 | 4% | Audit tooling, ML/research, CLI tools |
| YAML | 36 | 3% | CI/CD, configuration |
| TypeScript | 36 | 3% | Core packages, CLI tools, web apps |
| JavaScript | 24 | 2% | Web apps, utilities |
| PowerShell | 20 | 1% | Windows automation |
| Other | 258 | 18% | Various (images, data, etc.) |

---

## Core Framework Stack

### Morphism Framework (`morphism/`)

| Layer | Technology | Version |
|-------|-----------|---------|
| Runtime | Node.js | >= 18 |
| Package Manager | pnpm | 8.15.0 |
| Language | TypeScript | 5.7+ |
| Build | Turbo (monorepo) | 2.8.1 |
| Bundler | tsup / esbuild | Latest |
| Testing | Vitest, Jest | Latest |
| Linting | ESLint 9 + typescript-eslint | 9.x |
| Formatting | Prettier | 3.7.4 |
| Git Hooks | Husky + lint-staged | 9.x / 15.x |
| CI/CD | GitHub Actions | Custom workflows |

### @morphism-systems/core
- TypeScript, Vitest
- Core types, utilities, governance primitives

### @morphism-systems/mcp
- TypeScript, MCP SDK (@modelcontextprotocol/sdk >= 1.26.0)
- Model Context Protocol integration

### @morphism-systems/tools (14+ CLIs)
- Node.js, TypeScript, Commander.js
- Winston (logging), prom-client (metrics)
- Drift detection, validation, orchestration

---

## Web Platform Stack

### Morphism Hub (`morphism-hub/`)

| Layer | Technology | Version |
|-------|-----------|---------|
| Framework | Next.js | 15.2.3 |
| UI | React | 19.0.0 |
| Auth | Clerk | 6.12.0 |
| Database | Supabase | 2.49.1 |
| Payments | Stripe | 17.5.0 |
| AI | Google Generative AI | 0.24.0 |
| Styling | TailwindCSS | 3.4.17 |
| UI Primitives | Lucide React, CVA, clsx | Latest |
| Validation | Zod | 3.24.1 |
| Webhooks | Svix | 1.42.0 |
| Testing | Vitest | 3.2.1 |

### BOLTS.FIT (`_projects/bolts/`)
- Next.js 14, React, TypeScript
- Supabase, Stripe
- Playwright (E2E testing)

### LLMWorks (`_projects/llmworks/`)
- Vite, React, Radix UI
- TailwindCSS, Supabase
- Playwright, Vitest

---

## CLI Tools Stack

### Agent Context Optimizer
- TypeScript, Commander.js, Mustache (templating)
- Jest (testing)

### Monorepo Health Analyzer
- TypeScript, Commander.js
- Vitest, tsup (bundling)

---

## Python Stack

| Tool | Dependencies |
|------|-------------|
| Ecosystem Audit | Python 3.11+, standard library |
| QAPlibria | NumPy, SciPy, Matplotlib, pytest |
| HELIOS | FastAPI, PyTorch |
| TalAI | AsyncIO, LLM integration |
| Codemap | Python standard library |
| Brand Kit | Python standard library |

---

## Infrastructure & DevOps

| Category | Technology |
|----------|-----------|
| Version Control | Git, GitHub |
| CI/CD | GitHub Actions (`ubuntu-latest`) |
| Database | Supabase (PostgreSQL) |
| Auth | Clerk (Morphism Hub), Supabase Auth (other apps) |
| Payments | Stripe |
| Hosting | Vercel (target for Next.js apps) |
| Secrets | `.secrets/` (local, gitignored), env vars |
| Security | `security-preflight.sh` (tracked-content scan) |

---

## Governance & Validation Toolchain

| Tool | Type | Purpose |
|------|------|---------|
| quality-check-fast.sh | Bash | Quick quality gates |
| quality-check-strict.sh | Bash | Strict quality gates |
| enforce-professional-standards.sh | Bash | CI standards enforcement |
| check-secrets.sh | Bash | Secret leak prevention |
| check-naming.sh | Bash | Naming convention enforcement |
| validate-enhanced.sh | Bash | Schema validation |
| validate-versions.sh | Bash | Version consistency |
| validate-dependencies.sh | Bash | Dependency health |

---

## Cross-Tool Compatibility Matrix

| AI Tool | Support Level |
|---------|--------------|
| Claude Code | Full (AGENTS.md, .claude/) |
| Cursor | Designed (.cursorrules) |
| GitHub Copilot | Designed |
| Windsurf | Designed |
| Custom MCP servers | Full (@morphism-systems/mcp) |

---

## Key Architectural Decisions

1. **Monorepo with pnpm workspaces** — single repo for framework packages
2. **TypeScript-first** — all new code in TypeScript with strict mode
3. **Governance-as-code** — rules defined in Markdown, enforced by tooling
4. **MCP integration** — Model Context Protocol for AI tool interop
5. **Platform-agnostic** — works across Claude, Cursor, Copilot, Windsurf
6. **Validation pipeline** — automated quality gates in CI and pre-commit
