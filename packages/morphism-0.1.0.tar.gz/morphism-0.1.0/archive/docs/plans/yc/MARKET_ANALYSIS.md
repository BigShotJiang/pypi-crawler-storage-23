# Market Analysis — Morphism

**Generated:** 2026-02-09
**Purpose:** YC S26 Application Support

---

## 1. Core Problem

**AI coding agents have no governance layer.**

Teams using AI coding tools (Claude Code, Cursor, GitHub Copilot, Windsurf) face a growing problem: these agents write code fast, but there's no way to enforce consistent rules, safety policies, or compliance requirements across them.

Today's workarounds:
- **AGENTS.md** — Claude-only, no enforcement, no validation, no versioning
- **.cursorrules** — Cursor-only, static text, no cross-tool portability
- **Internal wikis/docs** — Humans read them, AI agents don't
- **Nothing** — Most teams have zero governance for their AI coding tools

As AI agents write more code (estimates suggest 30-50% of new code in 2026), ungoverned AI becomes an enterprise blocker.

**The problem in one sentence:** There's no Terraform for AI agent behavior.

---

## 2. Target Market & User Personas

### Primary: Platform Engineering Teams (Enterprise)
- **Who:** Platform engineers at companies with 50-500+ developers
- **Pain:** Need to ensure AI coding tools comply with internal standards, security policies, and compliance requirements
- **Current spend:** Already paying $15-50/dev/month for tools like Snyk, Semgrep, SonarQube
- **Buying trigger:** First incident where an AI agent introduces a security vulnerability or compliance violation

### Secondary: DevOps/Security Teams
- **Who:** Security-conscious engineering leaders
- **Pain:** Can't audit what AI agents are doing across the org
- **Current workaround:** Blocking AI tools entirely (losing productivity)

### Tertiary: AI-First Startups
- **Who:** Small teams building with AI coding tools from day one
- **Pain:** Want structure without bureaucracy
- **Current workaround:** Informal conventions, tribal knowledge

### User Personas

| Persona | Role | Pain Point | Willingness to Pay |
|---------|------|-----------|-------------------|
| **Sarah** | VP Engineering, 200-person startup | "Our devs use 3 different AI tools. I have no idea what rules they follow." | $20-40/dev/month |
| **Marcus** | Platform Engineer, Fortune 500 | "Compliance team is blocking AI tool rollout because we can't enforce policies." | $30-50/dev/month |
| **Priya** | CTO, 15-person startup | "We love AI tools but our codebase is getting inconsistent." | $10-15/dev/month |

---

## 3. Competitive Landscape

### Direct Competitors: None (Category Creation)

No product today provides cross-tool AI agent governance. This is a category-creation opportunity.

### Adjacent/Partial Competitors

| Company | What They Do | Gap Morphism Fills |
|---------|-------------|-------------------|
| **Snyk** ($8.5B valuation) | Code security scanning | Scans code output, doesn't govern agent behavior |
| **Semgrep** (Series C) | Static analysis rules | Pattern matching on code, not agent governance |
| **SonarQube** (Established) | Code quality gates | Post-hoc analysis, not real-time governance |
| **GitHub** (AGENTS.md support) | Basic agent instructions | Single-tool, no validation, no enforcement |
| **Cursor** (.cursorrules) | Cursor-specific rules | Single-tool, static text only |
| **Anthropic** (CLAUDE.md) | Claude-specific context | Single-tool, no cross-tool story |

### Key Insight
These tools operate on **code output** (scan after writing). Morphism operates on **agent behavior** (govern before/during writing). This is an orthogonal layer — complementary, not competitive.

---

## 4. Unique Value Proposition

**Morphism is the governance layer for AI coding agents.**

One config. Every AI tool. Validated, versioned, enforced.

### Value Chain

```
Without Morphism:
  Dev uses Claude → writes code → maybe follows rules → maybe not
  Dev uses Cursor → writes code → different rules → inconsistency
  Security team → finds out too late → blocks AI tools → productivity loss

With Morphism:
  Team defines governance → .morphism/config.json
  Dev uses Claude → Morphism enforces rules → validated code
  Dev uses Cursor → same rules enforced → consistency
  Security team → sees audit trail → approves AI tools → productivity gain
```

### Why Morphism, Not DIY?

| DIY Approach | Morphism Approach |
|-------------|------------------|
| Write AGENTS.md manually per tool | One .morphism/ config for all tools |
| No validation that rules are followed | `morphism validate` — automated compliance |
| No drift detection over time | `morphism drift` — continuous monitoring |
| No audit trail | Ecosystem audit generates artifacts |
| Breaks when you add a new AI tool | MCP integration — works with any MCP tool |

---

## 5. Market Size Estimation

### TAM (Total Addressable Market)
- **Global developers using AI coding tools:** ~15M by end of 2026
- **Average governance tool spend:** $20/dev/month
- **TAM:** $3.6B/year

### SAM (Serviceable Addressable Market)
- **Enterprise developers with compliance requirements:** ~3M
- **Average spend:** $30/dev/month
- **SAM:** $1.1B/year

### SOM (Serviceable Obtainable Market — 3-year target)
- **Target:** 10,000 developers at 200 companies
- **Average spend:** $25/dev/month
- **SOM:** $3M ARR (Year 3)

### Market Growth Drivers
1. AI coding tool adoption growing 3-5x annually
2. Enterprise compliance requirements increasing (SOC2, GDPR, HIPAA)
3. Multi-tool fragmentation accelerating (Claude + Cursor + Copilot in same org)
4. First major incidents from ungoverned AI agents will create urgency

---

## 6. Why Now

### Timing Signals

1. **Agentic coding explosion (2025-2026)**
   - Claude Code, Cursor, Copilot Workspace, Windsurf all launched/expanded
   - Developers rapidly adopting multiple tools simultaneously

2. **Enterprise AI governance gap**
   - Companies want to use AI tools but compliance teams are blocking rollout
   - No existing solution addresses AI agent governance specifically

3. **Model Context Protocol (MCP) standardization**
   - Anthropic's MCP creates a universal integration surface
   - Morphism's MCP integration makes it pluggable into any MCP-compatible tool

4. **AGENTS.md becoming a de facto standard**
   - Claude Code popularized the concept of agent instruction files
   - But AGENTS.md is Claude-only and un-validated — Morphism generalizes it

5. **Regulatory pressure building**
   - EU AI Act, SEC guidance on AI-generated code
   - Companies need auditable governance before regulators require it

### Window of Opportunity
- The governance category is being defined RIGHT NOW
- First mover with a cross-tool solution can set the standard
- In 12-18 months, AI tool vendors will build basic governance features
- Morphism needs to be the established standard before that happens
