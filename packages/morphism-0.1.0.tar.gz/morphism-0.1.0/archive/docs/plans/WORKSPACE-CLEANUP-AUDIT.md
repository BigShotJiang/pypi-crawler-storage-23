# Workspace Cleanup & Naming Convention Audit

**Date:** 2026-02-09
**Status:** Proposal — awaiting approval before execution
**Principle:** Only `morphism/` should carry the "morphism" name. Everything else is a consumer.

---

## 1. Naming Convention — `morphism-*` Directories

### Current State

| Directory | Purpose | Separate Git Repo? | Rename? |
|-----------|---------|-------------------|---------|
| `morphism/` | Framework source (SSOT, axioms, tenets, kernel, tools) | Yes | **No** — this IS the framework |
| `morphism-hub/` | SaaS product — "Morphism Hub" platform (Next.js) | Yes | **No** — product brand name |
| `morphism-ship/` | Extension lane — ships apps/packages under governance | Yes | **Yes** → `ship/` |
| `morphism-bible/` | Specs, workflows, prompts companion | Yes | **Yes** → `bible/` |
| `morphism-profile/` | Personal portfolio (resumes, job apps, interview prep) | Yes | **Yes** → `profile/` |
| `morphism-references/` | Academic/formal research materials | Yes | **Yes** → `references/` |

### Rationale

**Keep `morphism-hub/`:** This is the commercial product named "Morphism Hub." The directory
name matches the GitHub repo name. Renaming would break
the brand identity. It's analogous to `stripe/` (framework) vs `stripe-dashboard/` (product).

**Rename the other four:** These directories are NOT Morphism products — they're workspace
utilities that happen to be related to the Morphism ecosystem. The `morphism-` prefix creates
a false impression that they're part of the framework. Shorter names are clearer:

- `ship/` — what ships (governed extensions)
- `bible/` — the reference bible (specs, prompts)
- `profile/` — personal data (has zero Morphism content)
- `references/` — research materials

### Impact

Each is a separate git repo. Local rename does NOT affect the remote repo name.
All workspace docs referencing these directories must be updated.

---

## 2. Root Directory Cleanup

### Files to KEEP (per user spec + operational need)

| File | Reason |
|------|--------|
| `README.md` | Workspace entry point |
| `AGENTS.md` | Workspace governance |
| `SSOT.md` | Workspace authority |
| `CLAUDE.md` | Claude Code config |
| `commands.sh` | Workspace CLI commands |
| `.gitignore` | Git exclusion rules |
| `.gitattributes` | Git attributes |
| `workspace` | Workspace CLI (bash, referenced in README) |
| `workspace.bat` | Windows wrapper for workspace CLI |
| `.env.example` | Environment template for onboarding |

### Files to REMOVE

| File | Size | Reason | Action |
|------|------|--------|--------|
| `package.json` | 54 B | Only dependency: `docx ^9.5.1`. No scripts. Orphaned. | Delete |
| `package-lock.json` | 8 KB | Lock file for above. | Delete |

### Git Tracking Cleanup (6 stale entries)

These files were moved/deleted in Phase 2 but are still tracked in git:

| File | Current Location | Action |
|------|-----------------|--------|
| `ARCHITECTURE.md` | `docs/workspace/ARCHITECTURE.md` | `git rm ARCHITECTURE.md` |
| `CANONICAL_STRUCTURE.md` | `_archive/CANONICAL_STRUCTURE.md` | `git rm CANONICAL_STRUCTURE.md` |
| `CONTRIBUTING.md` | `docs/CONTRIBUTING.md` (kept copy) | `git rm CONTRIBUTING.md` |
| `DOCUMENTATION-CONSOLIDATION-COMPLETE.md` | `_archive/` | `git rm` |
| `DOCUMENTATION-STYLE-GUIDE.md` | `docs/reference/` | `git rm` |
| `PROJECT_CATALOG.md` | `docs/workspace/` | `git rm` |

---

## 3. Hidden Directory Cleanup

| Directory | Files | Size | Action | Reason |
|-----------|-------|------|--------|--------|
| `.api/` | 0 | 0 B | **Remove** | Empty directory |
| `.kiro/` | 4 | 10 KB | **Remove** | Legacy — migrated to `.morphism/` |
| `.kiro.backup/` | 58 | 231 KB | **Remove** | Backup of legacy `.kiro/` |
| `.mypy_cache/` | 171 | 8.5 MB | Leave | Auto-generated, gitignored |
| `.worktrees/` | 155 | 934 KB | Leave | Git worktree state, gitignored |
| `.secrets/` | 33 | 8.3 MB | Leave | Sensitive data, gitignored |
| `.setup/` | 2 | 22 KB | Leave | Setup scripts |
| `.vscode/` | 1 | 0.5 KB | Leave | Editor settings |
| `.github/` | 1 | 0.8 KB | Leave | GitHub config |
| `.claude/` | 11 | 101 KB | Leave | Claude Code config |
| `.morphism/` | — | 256 KB | Leave | Consumer config (active) |

---

## 4. Stale Documentation Cleanup

| File | Issue | Action |
|------|-------|--------|
| `docs/SSOT.md` | Old 6-line pointer. Root `SSOT.md` is now a full doc. | Delete |
| `docs/workspace/CANONICAL_STRUCTURE.md` | Pointer to root file that no longer exists | Delete |
| `_archive/README.md` line 56 | References `../PROJECT_CATALOG.md` (moved) | Fix path |
| `scripts/__pycache__/` | Python cache committed to repo | Add to `.gitignore`, `git rm -r` |

---

## 5. Stray Projects at Root

| Directory | Contents | Action |
|-----------|----------|--------|
| `agent-context-optimizer/` | README + test files (14 KB) | Move to `_projects/agent-context-optimizer/` |
| `monorepo-health-analyzer/` | Placeholder README only (329 B) | Move to `_projects/monorepo-health-analyzer/` |

---

## 6. Archive Consolidation

**Current state:** Two archive directories with different roles.

| Directory | Role | Contents |
|-----------|------|----------|
| `_archive/` | Curated archives (has README + policy) | 8 project snapshots, 2 docs, legacy-plans |
| `archive/` | Tool-generated snapshots | `_trash/`, `runtime/` |

**Proposal:** Keep both — they serve different purposes. But:
- `archive/_trash/` → Review contents, delete if truly trash
- Update `_archive/README.md` to fix broken `PROJECT_CATALOG.md` reference

---

## 7. Scripts Cleanup

| Item | Action |
|------|--------|
| `scripts/__pycache__/` | `git rm -r`, add to `.gitignore` |
| `scripts/package.json` + `scripts/package-lock.json` | Audit — are these used? |

---



## 8. `.gitignore` Updates

Add these patterns to prevent future clutter:

```
# Python cache (workspace-level)
scripts/__pycache__/

# Legacy config directories
.kiro/
.kiro.backup/
```

---

## 9. Execution Plan

### Step 1: Git cleanup (safe, reversible)
```bash
git rm ARCHITECTURE.md CANONICAL_STRUCTURE.md CONTRIBUTING.md
git rm DOCUMENTATION-CONSOLIDATION-COMPLETE.md DOCUMENTATION-STYLE-GUIDE.md PROJECT_CATALOG.md
git rm -r scripts/__pycache__/
```

### Step 2: Delete clutter
```bash
rm package.json package-lock.json
rm -rf .api/ .kiro/ .kiro.backup/
rm docs/SSOT.md docs/workspace/CANONICAL_STRUCTURE.md
```

### Step 3: Move stray projects
```bash
mv agent-context-optimizer/ _projects/agent-context-optimizer/
mv monorepo-health-analyzer/ _projects/monorepo-health-analyzer/
```

### Step 4: Rename directories
```bash
mv morphism-ship/ ship/
mv morphism-bible/ bible/
mv morphism-profile/ profile/
mv morphism-references/ references/
```

### Step 5: Update all references (~15+ files)

### Step 6: Update `.gitignore` with new directory names

### Step 7: Commit all changes

---

## 10. Summary

| Category | Items | Risk |
|----------|-------|------|
| Directory renames | 4 (`ship/`, `bible/`, `profile/`, `references/`) | Medium |
| Root file deletions | 2 (`package.json`, `package-lock.json`) | Low |
| Hidden dir removals | 3 (`.api/`, `.kiro/`, `.kiro.backup/`) | Low |
| Stale doc deletions | 2 (`docs/SSOT.md`, `docs/workspace/CANONICAL_STRUCTURE.md`) | Low |
| Stray project moves | 2 (to `_projects/`) | Low |
| Git tracking fixes | 6 stale entries + `__pycache__/` | Low |
| Reference updates | ~15+ files | Medium |

**Total:** ~30 operations. All reversible via `git revert`.

---

## Decision Required

1. **Rename all 4 directories?** (`morphism-ship/` → `ship/`, etc.)
2. **Keep `morphism-hub/`** as-is? (product brand name)
3. **Delete root `package.json`?** (only has `docx` dependency — is this used?)
4. **Proceed with all other cleanup items?**
