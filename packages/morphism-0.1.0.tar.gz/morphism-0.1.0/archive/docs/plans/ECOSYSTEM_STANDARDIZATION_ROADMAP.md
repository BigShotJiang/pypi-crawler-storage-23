# Ecosystem Standardization Roadmap

## P0 (Blocking Integrity/Security)

1. Keep governance links green in active surfaces.
2. Eliminate unowned P0/P1 assets.
3. Keep strict quality checks required in CI.

## P1 (Governance + CI Determinism)

1. Normalize runtime versions for strict workflows.
2. Enforce artifactized optimization runs in CI.
3. Keep ownership map current with CODEOWNERS coverage.

## P2 (Developer Ergonomics)

1. Align workspace command docs with actual entrypoints.
2. Keep fast local checks lightweight and strict checks scoped.

## P3 (Archive Hygiene)

1. Reduce scan noise from archive/vendor in operational dashboards.
2. Keep archival normalization out of active governance loops.
