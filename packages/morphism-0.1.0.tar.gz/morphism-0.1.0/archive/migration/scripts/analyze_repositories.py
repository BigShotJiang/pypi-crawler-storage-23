#!/usr/bin/env python3
"""
Repository Analysis Script for Phase 2: Cataloging and Classification
Analyzes all discovered repositories and creates comprehensive inventory
"""

import json
import subprocess
import sys
from datetime import datetime
from collections import defaultdict

def load_repository_data():
    """Load repository data from JSON files"""
    try:
        with open('alawein-test-repos.json', 'r') as f:
            test_repos = json.load(f)
        with open('alawein-personal-repos.json', 'r') as f:
            personal_repos = json.load(f)
        with open('meshal-alawein-repos.json', 'r') as f:
            target_repos = json.load(f)

        return test_repos, personal_repos, target_repos
    except Exception as e:
        print(f"Error loading repository data: {e}")
        sys.exit(1)

def analyze_conflicts(source_repos, target_repos):
    """Identify naming conflicts between source and target repositories"""
    conflicts = []
    target_names = {repo['name'].lower() for repo in target_repos}

    for repo in source_repos:
        repo_name = repo['name'].lower()
        if repo_name in target_names:
            conflicts.append({
                'source_name': repo['name'],
                'source_org': 'alawein-test' if 'alawein-test' in repo.get('url', '') else 'alawein-personal',
                'conflict_type': 'exact_match',
                'recommendation': 'Rename with prefix or skip if duplicate'
            })

        # Check for similar names (morphism- prefix variations)
        if repo_name.startswith('morphism-'):
            base_name = repo_name.replace('morphism-', '')
            if base_name in target_names or f'morphism-{base_name}' in target_names:
                conflicts.append({
                    'source_name': repo['name'],
                    'source_org': 'alawein-test' if 'alawein-test' in repo.get('url', '') else 'alawein-personal',
                    'conflict_type': 'morphism_prefix_variation',
                    'recommendation': 'Review for duplicate functionality'
                })

    return conflicts

def classify_by_language(repos):
    """Classify repositories by primary programming language"""
    language_stats = defaultdict(list)

    for repo in repos:
        lang = repo.get('primaryLanguage', {})
        if lang:
            lang_name = lang.get('name', 'Unknown')
        else:
            lang_name = 'Unknown'

        language_stats[lang_name].append(repo['name'])

    return dict(language_stats)

def classify_by_activity(repos):
    """Classify repositories by activity status"""
    from datetime import datetime, timedelta

    now = datetime.now()
    active = []
    stale = []
    archived = []

    for repo in repos:
        if repo.get('isArchived', False):
            archived.append(repo['name'])
            continue

        updated_str = repo.get('updatedAt', '')
        if updated_str:
            try:
                updated = datetime.fromisoformat(updated_str.replace('Z', '+00:00'))
                days_since_update = (now - updated.replace(tzinfo=None)).days

                if days_since_update <= 30:
                    active.append((repo['name'], days_since_update))
                else:
                    stale.append((repo['name'], days_since_update))
            except:
                stale.append((repo['name'], 'unknown'))

    return {
        'active': sorted(active, key=lambda x: x[1]),
        'stale': sorted(stale, key=lambda x: x[1] if isinstance(x[1], int) else 999),
        'archived': archived
    }

def infer_application_type(repo):
    """Infer application type from repository name and description"""
    name = repo['name'].lower()
    desc = (repo.get('description') or '').lower()

    # Patterns for classification
    if any(x in name for x in ['api', 'service', 'backend']):
        return 'microservice'
    elif any(x in name for x in ['lib', 'library', 'util', 'helper']):
        return 'library'
    elif any(x in name for x in ['cli', 'tool', 'script']):
        return 'tool'
    elif any(x in name for x in ['doc', 'guide', 'wiki']):
        return 'documentation'
    elif any(x in name for x in ['infra', 'terraform', 'ansible', 'k8s', 'kubernetes']):
        return 'infrastructure'
    elif any(x in name for x in ['config', 'settings']):
        return 'configuration'
    elif any(x in name for x in ['web', 'site', 'app', 'ui', 'frontend']):
        return 'web_application'
    elif any(x in name for x in ['test', 'benchmark']):
        return 'testing'
    else:
        return 'other'

def generate_catalog(test_repos, personal_repos, target_repos):
    """Generate comprehensive repository catalog"""

    all_source_repos = test_repos + personal_repos

    print("=" * 80)
    print("PHASE 2: REPOSITORY CATALOGING AND CLASSIFICATION")
    print("=" * 80)
    print()

    # Basic Statistics
    print("📊 REPOSITORY STATISTICS")
    print("-" * 80)
    print(f"Source Repositories (alawein-test): {len(test_repos)}")
    print(f"Source Repositories (alawein-personal): {len(personal_repos)}")
    print(f"Total Source Repositories: {len(all_source_repos)}")
    print(f"Target Organization Repositories: {len(target_repos)}")
    print()

    # Language Classification
    print("💻 LANGUAGE DISTRIBUTION")
    print("-" * 80)
    lang_stats = classify_by_language(all_source_repos)
    for lang, repos in sorted(lang_stats.items(), key=lambda x: len(x[1]), reverse=True):
        print(f"{lang:20s}: {len(repos):3d} repositories")
    print()

    # Activity Classification
    print("📈 ACTIVITY STATUS")
    print("-" * 80)
    activity = classify_by_activity(all_source_repos)
    print(f"Active (updated within 30 days): {len(activity['active'])}")
    print(f"Stale (not updated recently): {len(activity['stale'])}")
    print(f"Archived: {len(activity['archived'])}")
    print()

    if activity['active']:
        print("Most Recently Active:")
        for name, days in activity['active'][:5]:
            print(f"  • {name} (updated {days} days ago)")
        print()

    # Application Type Classification
    print("🏗️  APPLICATION TYPE CLASSIFICATION")
    print("-" * 80)
    type_stats = defaultdict(list)
    for repo in all_source_repos:
        app_type = infer_application_type(repo)
        type_stats[app_type].append(repo['name'])

    for app_type, repos in sorted(type_stats.items(), key=lambda x: len(x[1]), reverse=True):
        print(f"{app_type.replace('_', ' ').title():20s}: {len(repos):3d} repositories")
    print()

    # Conflict Analysis
    print("⚠️  NAMING CONFLICT ANALYSIS")
    print("-" * 80)
    conflicts = analyze_conflicts(all_source_repos, target_repos)

    if conflicts:
        print(f"Found {len(conflicts)} potential conflicts:")
        for conflict in conflicts[:10]:
            print(f"  • {conflict['source_name']} ({conflict['conflict_type']})")
            print(f"    → {conflict['recommendation']}")
        if len(conflicts) > 10:
            print(f"  ... and {len(conflicts) - 10} more conflicts")
    else:
        print("✅ No naming conflicts detected")
    print()

    # Visibility Analysis
    print("🔒 VISIBILITY DISTRIBUTION")
    print("-" * 80)
    visibility_stats = defaultdict(int)
    for repo in all_source_repos:
        visibility = repo.get('visibility', 'UNKNOWN')
        visibility_stats[visibility] += 1

    for visibility, count in visibility_stats.items():
        print(f"{visibility:10s}: {count:3d} repositories")
    print()

    # Generate detailed catalog data
    catalog_data = {
        'generated_at': datetime.now().isoformat(),
        'summary': {
            'total_source_repos': len(all_source_repos),
            'alawein_test_repos': len(test_repos),
            'alawein_personal_repos': len(personal_repos),
            'target_org_repos': len(target_repos),
            'conflicts_detected': len(conflicts)
        },
        'language_distribution': {k: len(v) for k, v in lang_stats.items()},
        'activity_status': {
            'active': len(activity['active']),
            'stale': len(activity['stale']),
            'archived': len(activity['archived'])
        },
        'application_types': {k: len(v) for k, v in type_stats.items()},
        'conflicts': conflicts,
        'repositories': []
    }

    # Detailed repository information
    for repo in all_source_repos:
        source_org = 'alawein-test' if repo in test_repos else 'alawein-personal'

        primary_lang = repo.get('primaryLanguage')
        if primary_lang and isinstance(primary_lang, dict):
            lang_name = primary_lang.get('name', 'Unknown')
        else:
            lang_name = 'Unknown'

        catalog_data['repositories'].append({
            'name': repo['name'],
            'source_organization': source_org,
            'description': repo.get('description', ''),
            'primary_language': lang_name,
            'visibility': repo.get('visibility', 'UNKNOWN'),
            'is_archived': repo.get('isArchived', False),
            'last_updated': repo.get('updatedAt', ''),
            'url': repo.get('url', ''),
            'application_type': infer_application_type(repo),
            'migration_status': 'pending',
            'conflicts': [c for c in conflicts if c['source_name'] == repo['name']]
        })

    # Save catalog to file
    with open('migration/reports/repository_catalog.json', 'w') as f:
        json.dump(catalog_data, f, indent=2)

    print("=" * 80)
    print("✅ Catalog generated successfully")
    print(f"📄 Detailed catalog saved to: migration/reports/repository_catalog.json")
    print("=" * 80)

    return catalog_data

def main():
    """Main execution function"""
    print("Loading repository data...")
    test_repos, personal_repos, target_repos = load_repository_data()

    print("Analyzing repositories...")
    catalog = generate_catalog(test_repos, personal_repos, target_repos)

    print()
    print("Phase 2 analysis complete!")
    print("Next steps:")
    print("  1. Review the generated catalog")
    print("  2. Address identified conflicts")
    print("  3. Proceed to Phase 3: Morphism Framework Governance")

if __name__ == '__main__':
    main()
