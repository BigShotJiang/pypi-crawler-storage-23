/**
 * CodebaseAnalyzer - Analyzes repository structure
 */
import * as fs from "fs";
import * as path from "path";
import { AnalysisResult, LanguageInfo, FrameworkInfo, ServiceInfo, APIInfo, DatabaseInfo } from "../types";

export class CodebaseAnalyzer {
  async analyze(repoPath: string): Promise<AnalysisResult> {
    const absolutePath = path.resolve(repoPath);
    
    if (!fs.existsSync(absolutePath)) {
      throw new Error(`Repository path does not exist: ${absolutePath}`);
    }

    const languages = await this.detectLanguages(absolutePath);
    const frameworks = await this.detectFrameworks(absolutePath);
    const services = this.detectServices(absolutePath);
    const apis = this.detectAPIs(absolutePath);
    const databases = this.detectDatabases(absolutePath);
    const architecturePatterns = this.detectArchitecturePatterns(absolutePath);
    const repositoryType = this.detectRepositoryType(absolutePath);

    return {
      repositoryType,
      languages,
      frameworks,
      services,
      apis,
      databases,
      architecturePatterns,
    };
  }

  private async detectLanguages(repoPath: string): Promise<LanguageInfo[]> {
    const languages: LanguageInfo[] = [];
    const extToLang: Record<string, string> = {
      ".ts": "TypeScript",
      ".js": "JavaScript",
      ".py": "Python",
      ".go": "Go",
      ".java": "Java",
      ".rs": "Rust",
      ".rb": "Ruby",
    };

    const fileCount: Record<string, number> = {};
    this.scanFiles(repoPath, (file) => {
      const ext = path.extname(file);
      const lang = extToLang[ext];
      if (lang) {
        fileCount[lang] = (fileCount[lang] || 0) + 1;
      }
    });

    Object.entries(fileCount).forEach(([name, count]) => {
      languages.push({ name, fileCount: count });
    });

    return languages.sort((a, b) => b.fileCount - a.fileCount);
  }

  private async detectFrameworks(repoPath: string): Promise<FrameworkInfo[]> {
    const frameworks: FrameworkInfo[] = [];
    const pkgPath = path.join(repoPath, "package.json");
    
    if (fs.existsSync(pkgPath)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
        const deps = { ...pkg.dependencies, ...pkg.devDependencies };
        
        const frameworkMap: Record<string, { name: string; category: FrameworkInfo["category"] }> = {
          "jest": { name: "jest", category: "testing" },
          "vitest": { name: "vitest", category: "testing" },
          "typescript": { name: "typescript", category: "build" },
          "webpack": { name: "webpack", category: "build" },
          "vite": { name: "vite", category: "build" },
          "express": { name: "express", category: "runtime" },
          "fastify": { name: "fastify", category: "runtime" },
          "react": { name: "react", category: "framework" },
          "vue": { name: "vue", category: "framework" },
        };

        Object.entries(deps).forEach(([dep, version]) => {
          const mapping = frameworkMap[dep];
          if (mapping) {
            frameworks.push({
              name: mapping.name,
              version: version as string,
              category: mapping.category,
            });
          }
        });
      } catch {
        // Ignore parse errors
      }
    }

    return frameworks;
  }

  private detectServices(repoPath: string): ServiceInfo[] {
    const services: ServiceInfo[] = [];
    
    // Check for common service patterns
    const pkgPath = path.join(repoPath, "package.json");
    if (fs.existsSync(pkgPath)) {
      try {
        const pkg = JSON.parse(fs.readFileSync(pkgPath, "utf-8"));
        if (pkg.scripts) {
          if (pkg.scripts.start?.includes("react-scripts")) {
            services.push({ name: "create-react-app", type: "http" });
          }
          if (pkg.scripts.dev?.includes("next")) {
            services.push({ name: "nextjs", type: "http", endpoints: ["/"] });
          }
        }
      } catch {
        // Ignore
      }
    }

    return services;
  }

  private detectAPIs(repoPath: string): APIInfo[] {
    const apis: APIInfo[] = [];
    const apiPatterns = ["openapi.yaml", "openapi.yml", "openapi.json", "swagger.json"];
    
    for (const pattern of apiPatterns) {
      const apiPath = path.join(repoPath, pattern);
      if (fs.existsSync(apiPath)) {
        apis.push({
          name: "openapi",
          format: "openapi",
          specPath: pattern,
        });
        break;
      }
    }

    return apis;
  }

  private detectDatabases(repoPath: string): DatabaseInfo[] {
    const databases: DatabaseInfo[] = [];
    const dbPatterns = [
      { name: "schema.sql", type: "sql" as const },
      { name: "schema.prisma", type: "sql" as const },
      { name: "models.py", type: "sql" as const },
    ];

    for (const pattern of dbPatterns) {
      const dbPath = path.join(repoPath, pattern.name);
      if (fs.existsSync(dbPath)) {
        databases.push({
          name: pattern.name.replace(".sql", "").replace(".prisma", "").replace("models", "main"),
          type: pattern.type,
          schemaPath: pattern.name,
        });
      }
    }

    return databases;
  }

  private detectArchitecturePatterns(repoPath: string): string[] {
    const patterns: string[] = [];
    
    // Check for common architecture indicators
    const dirs = fs.readdirSync(repoPath);
    if (dirs.includes("src") && dirs.includes("tests")) {
      patterns.push("standard-layout");
    }
    if (dirs.some(d => d.startsWith("packages") || d.startsWith("apps"))) {
      patterns.push("monorepo");
    }
    if (dirs.includes("api") && dirs.includes("client")) {
      patterns.push("client-server");
    }
    if (dirs.includes("services") || dirs.includes("gateways")) {
      patterns.push("microservices");
    }

    return patterns;
  }

  private detectRepositoryType(repoPath: string): "single" | "monorepo" | "polyrepo" {
    const dirs = fs.readdirSync(repoPath);
    
    if (dirs.includes("pnpm-workspace.yaml") || dirs.includes("lerna.json") || 
        dirs.includes("turbo.json") || dirs.some(d => d.startsWith("packages"))) {
      return "monorepo";
    }

    return "single";
  }

  private scanFiles(dir: string, callback: (file: string) => void): void {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        if (!entry.name.startsWith(".") && entry.name !== "node_modules") {
          this.scanFiles(fullPath, callback);
        }
      } else if (entry.isFile()) {
        callback(fullPath);
      }
    }
  }
}
