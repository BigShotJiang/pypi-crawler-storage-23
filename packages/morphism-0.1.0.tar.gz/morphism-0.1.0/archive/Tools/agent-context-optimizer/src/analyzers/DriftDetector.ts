/**
 * DriftDetector - Detects drift between context files and actual repository state
 */
import * as fs from "fs";
import * as path from "path";
import { DriftReport, DriftedFile } from "../types";

export class DriftDetector {
  async detectDrift(repoPath: string): Promise<DriftReport> {
    const absolutePath = path.resolve(repoPath);
    const contextDir = path.join(absolutePath, ".kiro");

    if (!fs.existsSync(contextDir)) {
      return {
        hasDrift: true,
        severity: "warning",
        driftedFiles: [],
        suggestions: ["No .kiro directory found. Run 'generate' to create context files."],
      };
    }

    const driftedFiles: DriftedFile[] = [];
    
    // Check for missing context files
    const expectedFiles = ["AGENTS.md", "SSOT-core.md", "SSOT-system.md"];
    for (const file of expectedFiles) {
      const filePath = path.join(contextDir, file);
      if (!fs.existsSync(filePath)) {
        driftedFiles.push({
          path: filePath,
          sections: [],
          reason: `Context file missing: ${file}`,
        });
      }
    }

    // Check for architecture drift
    const coreFile = path.join(contextDir, "SSOT-core.md");
    if (fs.existsSync(coreFile)) {
      const { CodebaseAnalyzer } = await import("./CodebaseAnalyzer");
      const analyzer = new CodebaseAnalyzer();
      const currentAnalysis = await analyzer.analyze(absolutePath);

      // Simple pattern-based drift detection
      const content = fs.readFileSync(coreFile, "utf-8");
      
      if (currentAnalysis.architecturePatterns.length > 0) {
        const patternsDetected = currentAnalysis.architecturePatterns.join(", ");
        if (!content.includes(patternsDetected)) {
          driftedFiles.push({
            path: coreFile,
            sections: ["Architecture Patterns"],
            reason: "Architecture patterns have changed",
          });
        }
      }
    }

    // Determine severity
    const severity = driftedFiles.length > 0 
      ? (driftedFiles.some(f => f.reason.includes("missing")) ? "critical" : "warning")
      : "none";

    return {
      hasDrift: driftedFiles.length > 0,
      severity,
      driftedFiles,
      suggestions: driftedFiles.map(f => `Regenerate ${path.basename(f.path)}`),
    };
  }
}
