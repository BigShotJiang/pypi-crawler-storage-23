#!/usr/bin/env node
/**
 * Agent Context Optimizer - CLI Entry Point
 */
import { CLI } from "./cli/CLI";
import { CommandRouter } from "./cli/CommandRouter";
import { AnalyzeCommand } from "./cli/commands/AnalyzeCommand";
import { GenerateCommand } from "./cli/commands/GenerateCommand";
import { SyncCommand } from "./cli/commands/SyncCommand";
import { CheckCommand } from "./cli/commands/CheckCommand";
import { EvalCommand } from "./cli/commands/EvalCommand";

// Set up command router
const router = new CommandRouter();
router.register("analyze", new AnalyzeCommand());
router.register("generate", new GenerateCommand());
router.register("sync", new SyncCommand());
router.register("check", new CheckCommand());
router.register("eval", new EvalCommand());

// Create CLI and run with command line arguments
const cli = new CLI(router);
cli.run(process.argv.slice(2)).catch((error) => {
  console.error(`Error: ${error.message}`);
  process.exit(1);
});
