/**
 * MetadataSynchronizer - Syncs metadata with context files
 */
import * as fs from "fs";
import * as path from "path";

export class MetadataSynchronizer {
  async sync(repoPath: string, systemFile: string): Promise<void> {
    const absolutePath = path.resolve(repoPath);
    const absoluteSystemFile = path.resolve(systemFile);

    console.log(`Syncing metadata at: ${absolutePath}`);
    console.log(`Target file: ${absoluteSystemFile}`);

    if (!fs.existsSync(absoluteSystemFile)) {
      console.log("System file not found. Run 'generate' first.");
      return;
    }

    // Read the current system file
    const content = fs.readFileSync(absoluteSystemFile, "utf-8");
    
    // Update the timestamp
    const updatedContent = content.replace(
      /## Metadata[\s\S]*?Generated:.*$/m,
      `## Metadata

- **Generated**: ${new Date().toISOString()}
- **Generator**: Agent Context Optimizer`
    );

    // Write back
    fs.writeFileSync(absoluteSystemFile, updatedContent, "utf-8");
    console.log("Metadata synchronized successfully.");
  }
}
