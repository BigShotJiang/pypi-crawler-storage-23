/**
 * ConfigLoader - Loads configuration from files
 */
import * as fs from "fs";
import * as path from "path";
import { Config } from "../types";

export class ConfigLoader {
  load(configPath: string): Config {
    const absolutePath = path.resolve(configPath);
    
    if (!fs.existsSync(absolutePath)) {
      throw new Error(`Config file not found: ${absolutePath}`);
    }

    try {
      const content = fs.readFileSync(absolutePath, "utf-8");
      const config = JSON.parse(content);
      return this.validateConfig(config);
    } catch (error) {
      throw new Error(`Failed to load config: ${error}`);
    }
  }

  private validateConfig(config: Record<string, unknown>): Config {
    return {
      contextDir: typeof config.contextDir === "string" ? config.contextDir : undefined,
      includePatterns: Array.isArray(config.includePatterns) ? config.includePatterns : undefined,
      excludePatterns: Array.isArray(config.excludePatterns) ? config.excludePatterns : undefined,
      verbose: typeof config.verbose === "boolean" ? config.verbose : undefined,
      output: typeof config.output === "string" ? config.output : undefined,
      format: this.parseFormat(config.format),
    };
  }

  private parseFormat(format: unknown): Config["format"] {
    if (format === "json" || format === "markdown" || format === "text") {
      return format;
    }
    return undefined;
  }
}
