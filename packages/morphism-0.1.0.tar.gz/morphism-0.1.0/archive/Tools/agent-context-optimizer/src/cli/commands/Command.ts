/**
 * Base Command interface for all CLI commands
 */
import { CommandOptions } from "../../types";

export interface Command {
  execute(options: CommandOptions): Promise<void>;
}
