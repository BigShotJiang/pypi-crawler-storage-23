/**
 * GenerateCommand - Generates context files from repository analysis
 */
import { Command } from "./Command";
import { CommandOptions } from "../../types";
import * as fs from "fs";
import * as path from "path";

export class GenerateCommand implements Command {
  async execute(options: CommandOptions): Promise<void> {
    const { path: repoPath, dryRun = false, config } = options;
    console.log(`Generating context files for: ${repoPath}`);

    // Load config if provided
    let contextDir = ".kiro";
    if (config) {
      const { ConfigLoader } = await import("../../config/ConfigLoader");
      const loader = new ConfigLoader();
      const cfg = loader.load(config);
      contextDir = cfg.contextDir || contextDir;
    }

    const absolutePath = path.resolve(repoPath);
    const contextPath = path.join(absolutePath, contextDir);

    if (!fs.existsSync(contextPath)) {
      if (!dryRun) {
        fs.mkdirSync(contextPath, { recursive: true });
      }
    }

    // Import dependencies
    const { CodebaseAnalyzer } = await import("../../analyzers/CodebaseAnalyzer");
    const { ContextGenerator } = await import("../../generators/ContextGenerator");

    const analyzer = new CodebaseAnalyzer();
    const analysis = await analyzer.analyze(absolutePath);
    const generator = new ContextGenerator();

    // Generate AGENTS.md
    const agentsContent = generator.generateAgentsMd(analysis);
    this.writeFile(path.join(contextPath, "AGENTS.md"), agentsContent, dryRun);

    // Generate SSOT-core.md
    const coreContent = generator.generateSSOTCore(analysis);
    this.writeFile(path.join(contextPath, "SSOT-core.md"), coreContent, dryRun);

    // Generate SSOT-system.md
    const systemContent = generator.generateSSOTSystem(analysis);
    this.writeFile(path.join(contextPath, "SSOT-system.md"), systemContent, dryRun);

    console.log(dryRun 
      ? "Dry run complete - no files written"
      : `Context files generated in: ${contextPath}`
    );
  }

  private writeFile(filePath: string, content: string, dryRun: boolean): void {
    if (dryRun) {
      console.log(`[DRY-RUN] Would write: ${filePath}`);
    } else {
      fs.writeFileSync(filePath, content, "utf-8");
      console.log(`Written: ${filePath}`);
    }
  }
}
