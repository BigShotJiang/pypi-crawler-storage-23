/**
 * EvalCommand - Evaluates context strategies for agent tasks
 */
import { Command } from "./Command";
import { CommandOptions, EvaluationTask } from "../../types";
import * as fs from "fs";
import * as path from "path";

export class EvalCommand implements Command {
  async execute(options: CommandOptions): Promise<void> {
    const { path: repoPath, tasks: tasksPath } = options;

    if (!tasksPath) {
      console.error("Error: --tasks flag is required");
      process.exit(1);
    }

    const absoluteTasksPath = fs.existsSync(tasksPath) 
      ? tasksPath 
      : fs.existsSync(path.resolve(repoPath, tasksPath))
        ? path.resolve(repoPath, tasksPath)
        : null;

    if (!absoluteTasksPath || !fs.existsSync(absoluteTasksPath)) {
      console.error(`Error: Tasks file not found: ${tasksPath}`);
      process.exit(1);
    }

    console.log(`Evaluating tasks from: ${absoluteTasksPath}`);

    try {
      const tasksContent = fs.readFileSync(absoluteTasksPath, "utf-8");
      const tasks: EvaluationTask[] = JSON.parse(tasksContent);

      const { EvaluationHarness } = await import("../../evaluation/EvaluationHarness");
      const harness = new EvaluationHarness();
      const report = await harness.evaluate(tasks);

      console.log("\n=== Evaluation Report ===\n");
      console.log("Always-On Strategy:");
      console.log(`  - Token Usage: ${report.alwaysOn.tokenUsage}`);
      console.log(`  - Task Completion: ${(report.alwaysOn.taskCompletionRate * 100).toFixed(1)}%`);
      console.log(`  - Tool Accuracy: ${(report.alwaysOn.toolInvocationAccuracy * 100).toFixed(1)}%`);
      console.log(`  - Avg Response Time: ${report.alwaysOn.averageResponseTime}ms`);

      console.log("\nRetrieval Strategy:");
      console.log(`  - Token Usage: ${report.retrieval.tokenUsage}`);
      console.log(`  - Task Completion: ${(report.retrieval.taskCompletionRate * 100).toFixed(1)}%`);
      console.log(`  - Tool Accuracy: ${(report.retrieval.toolInvocationAccuracy * 100).toFixed(1)}%`);
      console.log(`  - Avg Response Time: ${report.retrieval.averageResponseTime}ms`);

      console.log("\nRecommendations:");
      for (const rec of report.recommendations) {
        console.log(`  - ${rec.contextFile} (${rec.priority}): ${rec.condition}`);
      }

      // Exit with failure if recommendations indicate issues
      process.exit(1);
    } catch (error) {
      console.error(`Error evaluating tasks: ${error}`);
      process.exit(1);
    }
  }
}
