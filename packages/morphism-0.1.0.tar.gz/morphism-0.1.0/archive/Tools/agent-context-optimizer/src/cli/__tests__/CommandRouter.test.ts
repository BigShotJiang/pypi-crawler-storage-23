import { CommandRouter } from "../CommandRouter";
import { Command } from "../commands/Command";

describe("CommandRouter", () => {
  it("routes to a registered command", async () => {
    const router = new CommandRouter();
    const execute = jest.fn().mockResolvedValue(undefined);
    const command: Command = { execute };

    router.register("analyze", command);
    await router.route("analyze", { path: "." });

    expect(execute).toHaveBeenCalledWith({ path: "." });
  });

  it("throws for unknown commands", async () => {
    const router = new CommandRouter();

    await expect(router.route("missing", {})).rejects.toThrow("Unknown command: missing");
  });
});

