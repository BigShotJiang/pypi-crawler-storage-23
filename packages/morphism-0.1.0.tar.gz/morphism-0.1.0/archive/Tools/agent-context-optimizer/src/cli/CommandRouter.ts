/**
 * CommandRouter - Routes commands to their handlers
 */
import { Command } from "./commands/Command";
import { CommandOptions } from "../types";

export class CommandRouter {
  private commands: Map<string, Command> = new Map();

  register(name: string, command: Command): void {
    this.commands.set(name, command);
  }

  async route(commandName: string, options: CommandOptions): Promise<void> {
    const command = this.commands.get(commandName);
    if (!command) {
      throw new Error(`Unknown command: ${commandName}`);
    }
    await command.execute(options);
  }
}
