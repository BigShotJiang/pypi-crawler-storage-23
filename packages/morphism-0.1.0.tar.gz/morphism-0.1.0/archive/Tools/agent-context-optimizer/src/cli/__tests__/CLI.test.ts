import { CLI } from "../CLI";
import { CommandRouter } from "../CommandRouter";

describe("CLI", () => {
  it("routes analyze command", async () => {
    const router = { route: jest.fn().mockResolvedValue(undefined) } as unknown as CommandRouter;
    const cli = new CLI(router);

    await cli.run(["analyze", "repo-path"]);

    expect((router.route as jest.Mock).mock.calls[0][0]).toBe("analyze");
    expect((router.route as jest.Mock).mock.calls[0][1].path).toBe("repo-path");
  });

  it("routes generate command with flags", async () => {
    const router = { route: jest.fn().mockResolvedValue(undefined) } as unknown as CommandRouter;
    const cli = new CLI(router);

    await cli.run(["generate", ".", "--dry-run", "--config", "cfg.yml"]);

    expect((router.route as jest.Mock).mock.calls[0][0]).toBe("generate");
    expect((router.route as jest.Mock).mock.calls[0][1]).toEqual(
      expect.objectContaining({ path: ".", dryRun: true, config: "cfg.yml" })
    );
  });

  it("routes sync/check/eval commands", async () => {
    const router = { route: jest.fn().mockResolvedValue(undefined) } as unknown as CommandRouter;
    const cli = new CLI(router);

    await cli.run(["sync", "."]);
    await cli.run(["check", ".", "--fail-on-drift"]);
    await cli.run(["eval", ".", "--tasks", "tasks.json"]);

    expect((router.route as jest.Mock).mock.calls[0][0]).toBe("sync");
    expect((router.route as jest.Mock).mock.calls[1][0]).toBe("check");
    expect((router.route as jest.Mock).mock.calls[1][1].failOnDrift).toBe(true);
    expect((router.route as jest.Mock).mock.calls[2][0]).toBe("eval");
    expect((router.route as jest.Mock).mock.calls[2][1].tasks).toBe("tasks.json");
  });
});

