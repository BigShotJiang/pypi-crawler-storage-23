/**
 * AnalyzeCommand - Analyzes repository structure and outputs context information
 */
import { Command } from "./Command";
import { CommandOptions, AnalysisResult } from "../../types";

export class AnalyzeCommand implements Command {
  async execute(options: CommandOptions): Promise<void> {
    const { path } = options;
    console.log(`Analyzing repository at: ${path}`);
    
    // Import dynamically to avoid circular dependencies
    const { CodebaseAnalyzer } = await import("../../analyzers/CodebaseAnalyzer");
    const analyzer = new CodebaseAnalyzer();
    const analysis = await analyzer.analyze(path);
    
    this.printAnalysis(analysis, options.format);
  }

  private printAnalysis(analysis: AnalysisResult, format?: string): void {
    if (format === "json") {
      console.log(JSON.stringify(analysis, null, 2));
      return;
    }

    console.log(`\n=== Repository Analysis ===\n`);
    console.log(`Repository Type: ${analysis.repositoryType}`);
    console.log(`\nLanguages:`);
    analysis.languages.forEach((lang) => {
      console.log(`  - ${lang.name} (${lang.fileCount} files${lang.primaryVersion ? `, v${lang.primaryVersion}` : ""})`);
    });
    console.log(`\nFrameworks:`);
    analysis.frameworks.forEach((fw) => {
      console.log(`  - ${fw.name}@${fw.version} (${fw.category})`);
    });
    console.log(`\nServices:`);
    analysis.services.forEach((svc) => {
      console.log(`  - ${svc.name} (${svc.type})${svc.endpoints ? `, endpoints: ${svc.endpoints.join(", ")}` : ""}`);
    });
    console.log(`\nAPIs:`);
    analysis.apis.forEach((api) => {
      console.log(`  - ${api.name} (${api.format}): ${api.specPath}`);
    });
    console.log(`\nDatabases:`);
    analysis.databases.forEach((db) => {
      console.log(`  - ${db.name} (${db.type})${db.schemaPath ? `: ${db.schemaPath}` : ""}`);
    });
    console.log(`\nArchitecture Patterns: ${analysis.architecturePatterns.join(", ")}`);
  }
}
