/**
 * SyncCommand - Synchronizes metadata with context files
 */
import { Command } from "./Command";
import { CommandOptions } from "../../types";
import * as path from "path";

export class SyncCommand implements Command {
  async execute(options: CommandOptions): Promise<void> {
    const { path: repoPath } = options;
    console.log(`Syncing metadata at: ${repoPath}`);

    const { MetadataSynchronizer } = await import("../../extractors/MetadataSynchronizer");
    const synchronizer = new MetadataSynchronizer();

    const systemFile = path.join(repoPath, ".kiro", "SSOT-system.md");
    await synchronizer.sync(repoPath, systemFile);
  }
}
