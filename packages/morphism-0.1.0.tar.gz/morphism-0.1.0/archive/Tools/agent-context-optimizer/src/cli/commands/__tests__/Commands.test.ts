import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { AnalyzeCommand } from "../AnalyzeCommand";
import { GenerateCommand } from "../GenerateCommand";
import { SyncCommand } from "../SyncCommand";
import { CheckCommand } from "../CheckCommand";
import { EvalCommand } from "../EvalCommand";
import { CodebaseAnalyzer } from "../../../analyzers/CodebaseAnalyzer";
import { MetadataSynchronizer } from "../../../extractors/MetadataSynchronizer";
import { DriftDetector } from "../../../analyzers/DriftDetector";
import { EvaluationHarness } from "../../../evaluation/EvaluationHarness";
import { ConfigLoader } from "../../../config/ConfigLoader";
import { ContextGenerator } from "../../../generators/ContextGenerator";
import { AnalysisResult, DriftReport, EvaluationTask } from "../../../types";

const sampleAnalysis: AnalysisResult = {
  repositoryType: "single",
  languages: [{ name: "TypeScript", fileCount: 10, primaryVersion: "5.0.0" }],
  frameworks: [{ name: "jest", version: "^29.0.0", category: "testing" }],
  services: [{ name: "api", type: "http", endpoints: ["/health"] }],
  apis: [{ name: "openapi", format: "openapi", specPath: "openapi.yaml" }],
  databases: [{ name: "main", type: "sql", schemaPath: "schema.sql" }],
  architecturePatterns: ["layered"],
};

describe("CLI Commands", () => {
  let logSpy: jest.SpyInstance;
  let errSpy: jest.SpyInstance;

  beforeEach(() => {
    jest.restoreAllMocks();
    logSpy = jest.spyOn(console, "log").mockImplementation(() => undefined);
    errSpy = jest.spyOn(console, "error").mockImplementation(() => undefined);
  });

  afterEach(() => {
    logSpy.mockRestore();
    errSpy.mockRestore();
  });

  it("AnalyzeCommand prints analysis output", async () => {
    jest.spyOn(CodebaseAnalyzer.prototype, "analyze").mockResolvedValue(sampleAnalysis);
    const cmd = new AnalyzeCommand();

    await cmd.execute({ path: "/repo" });

    expect(CodebaseAnalyzer.prototype.analyze).toHaveBeenCalledWith("/repo");
    expect(logSpy).toHaveBeenCalledWith("Analyzing repository at: /repo");
    expect(logSpy).toHaveBeenCalledWith(expect.stringContaining("Repository Type: single"));
  });

  it("GenerateCommand supports dry-run and write mode", async () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "aco-generate-"));
    jest.spyOn(ConfigLoader.prototype, "load").mockReturnValue({});
    jest.spyOn(CodebaseAnalyzer.prototype, "analyze").mockResolvedValue(sampleAnalysis);
    jest.spyOn(ContextGenerator.prototype, "generateAgentsMd").mockReturnValue("# AGENTS");
    jest.spyOn(ContextGenerator.prototype, "generateSSOTCore").mockReturnValue("# SSOT Core");
    jest.spyOn(ContextGenerator.prototype, "generateSSOTSystem").mockReturnValue("# SSOT System");

    const cmd = new GenerateCommand();
    await cmd.execute({ path: tmpDir, dryRun: true });
    expect(fs.existsSync(path.join(tmpDir, ".kiro", "AGENTS.md"))).toBe(false);

    await cmd.execute({ path: tmpDir, dryRun: false });
    expect(fs.readFileSync(path.join(tmpDir, ".kiro", "AGENTS.md"), "utf-8")).toContain("# AGENTS");
    expect(fs.readFileSync(path.join(tmpDir, ".kiro", "SSOT-core.md"), "utf-8")).toContain("# SSOT Core");
    expect(fs.readFileSync(path.join(tmpDir, ".kiro", "SSOT-system.md"), "utf-8")).toContain("# SSOT System");
  });

  it("SyncCommand runs metadata synchronizer", async () => {
    const syncSpy = jest.spyOn(MetadataSynchronizer.prototype, "sync").mockResolvedValue(undefined);
    const cmd = new SyncCommand();

    await cmd.execute({ path: "/repo" });

    expect(syncSpy).toHaveBeenCalledWith("/repo", path.join("/repo", ".kiro", "SSOT-system.md"));
  });

  it("CheckCommand logs no drift and drift paths; exits when configured", async () => {
    const noDrift: DriftReport = {
      hasDrift: false,
      severity: "none",
      driftedFiles: [],
      suggestions: [],
    };
    const yesDrift: DriftReport = {
      hasDrift: true,
      severity: "critical",
      driftedFiles: [{ path: "/repo/.kiro/SSOT-core.md", sections: ["Architecture"], reason: "Pattern changed" }],
      suggestions: ["Regenerate SSOT-core.md"],
    };

    const detectSpy = jest.spyOn(DriftDetector.prototype, "detectDrift");
    detectSpy.mockResolvedValueOnce(noDrift);
    detectSpy.mockResolvedValueOnce(yesDrift);

    const exitSpy = jest
      .spyOn(process, "exit")
      .mockImplementation((() => {
        throw new Error("exit");
      }) as never);

    const cmd = new CheckCommand();
    await cmd.execute({ path: "/repo", failOnDrift: false });
    expect(logSpy).toHaveBeenCalledWith(expect.stringContaining("No drift detected"));

    await expect(cmd.execute({ path: "/repo", failOnDrift: true })).rejects.toThrow("exit");
    expect(exitSpy).toHaveBeenCalledWith(1);
  });

  it("EvalCommand handles missing and present tasks file", async () => {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "aco-eval-"));
    const tasksPath = path.join(tmpDir, "tasks.json");
    const tasks: EvaluationTask[] = [
      { id: "t1", description: "Task", expectedOutcome: "Done", contextStrategy: "always-on" },
    ];

    const report = {
      alwaysOn: { strategy: "always-on" as const, tokenUsage: 100, taskCompletionRate: 1, toolInvocationAccuracy: 1, averageResponseTime: 10 },
      retrieval: { strategy: "retrieval" as const, tokenUsage: 80, taskCompletionRate: 0.9, toolInvocationAccuracy: 0.95, averageResponseTime: 12 },
      recommendations: [{ contextFile: "context/api.md", condition: "api", priority: "retrieval" as const }],
    };

    const evaluateSpy = jest.spyOn(EvaluationHarness.prototype, "evaluate").mockResolvedValue(report);
    const exitSpy = jest
      .spyOn(process, "exit")
      .mockImplementation((() => {
        throw new Error("exit");
      }) as never);

    const cmd = new EvalCommand();
    await expect(cmd.execute({ path: tmpDir, tasks: path.join(tmpDir, "missing.json") })).rejects.toThrow("exit");

    fs.writeFileSync(tasksPath, JSON.stringify(tasks, null, 2));
    await cmd.execute({ path: tmpDir, tasks: tasksPath });
    expect(evaluateSpy).toHaveBeenCalledWith(tasks);
    expect(exitSpy).toHaveBeenCalledWith(1);
  });
});

