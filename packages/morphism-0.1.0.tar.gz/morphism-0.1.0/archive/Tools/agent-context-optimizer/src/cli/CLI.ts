/**
 * CLI - Main entry point for command execution
 */
import { CommandRouter } from "./CommandRouter";
import { CommandOptions } from "../types";

export class CLI {
  private router: CommandRouter;

  constructor(router: CommandRouter) {
    this.router = router;
  }

  async run(args: string[]): Promise<void> {
    if (args.length === 0) {
      this.printHelp();
      return;
    }

    const commandName = args[0];
    const options = this.parseOptions(args.slice(1));

    await this.router.route(commandName, options);
  }

  private parseOptions(args: string[]): CommandOptions {
    const options: CommandOptions = {
      path: ".",
    };

    for (let i = 0; i < args.length; i++) {
      const arg = args[i];
      const next = args[i + 1];

      switch (arg) {
        case "--path":
        case "-p":
          if (next) {
            options.path = next;
            i++;
          }
          break;
        case "--dry-run":
        case "-d":
          options.dryRun = true;
          break;
        case "--config":
        case "-c":
          if (next) {
            options.config = next;
            i++;
          }
          break;
        case "--fail-on-drift":
        case "-f":
          options.failOnDrift = true;
          break;
        case "--tasks":
        case "-t":
          if (next) {
            options.tasks = next;
            i++;
          }
          break;
        case "--verbose":
        case "-v":
          options.verbose = true;
          break;
        case "--output":
        case "-o":
          if (next) {
            options.output = next;
            i++;
          }
          break;
        case "--format":
        case "-F":
          if (next && ["json", "markdown", "text"].includes(next)) {
            options.format = next as "json" | "markdown" | "text";
            i++;
          }
          break;
        case "--help":
        case "-h":
          this.printHelp();
          process.exit(0);
          break;
      }
    }

    return options;
  }

  private printHelp(): void {
    console.log(`
Agent Context Optimizer

Usage: aco <command> [options]

Commands:
  analyze    Analyze repository and output context information
  generate   Generate context files from repository analysis
  sync       Synchronize metadata with context files
  check      Check for drift between context and repository
  eval       Evaluate context strategies for agent tasks

Options:
  --path, -p      Repository path (default: .)
  --dry-run, -d   Show what would be done without making changes
  --config, -c    Path to configuration file
  --fail-on-drift, -f  Exit with error code if drift is detected
  --tasks, -t     Path to tasks file for evaluation
  --verbose, -v   Enable verbose output
  --output, -o   Output file path
  --format, -F    Output format (json, markdown, text)
  --help, -h      Show this help message

Examples:
  aco analyze .
  aco generate . --dry-run
  aco check . --fail-on-drift
  aco eval . --tasks tasks.json
`);
  }
}
