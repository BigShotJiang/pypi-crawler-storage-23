/**
 * CheckCommand - Checks for drift between context files and repository state
 */
import { Command } from "./Command";
import { CommandOptions } from "../../types";

export class CheckCommand implements Command {
  async execute(options: CommandOptions): Promise<void> {
    const { path: repoPath, failOnDrift = false } = options;
    console.log(`Checking for drift at: ${repoPath}`);

    const { DriftDetector } = await import("../../analyzers/DriftDetector");
    const detector = new DriftDetector();
    const report = await detector.detectDrift(repoPath);

    if (report.hasDrift) {
      console.log("\n⚠️  Drift detected!\n");
      console.log(`Severity: ${report.severity}`);
      console.log("\nDrifted files:");
      for (const file of report.driftedFiles) {
        console.log(`  - ${file.path}`);
        console.log(`    Reason: ${file.reason}`);
        if (file.sections.length > 0) {
          console.log(`    Sections: ${file.sections.join(", ")}`);
        }
      }
      console.log("\nSuggestions:");
      for (const suggestion of report.suggestions) {
        console.log(`  - ${suggestion}`);
      }

      if (failOnDrift) {
        process.exit(1);
      }
    } else {
      console.log("✅ No drift detected. Context files are up to date.");
    }
  }
}
