# Tools

**Category:** Utility Tools
**Purpose:** CLI tools, libraries, and utilities for developers

---

## 📋 Overview

This directory contains developer tools including CLI utilities, libraries, and automation scripts.

### Characteristics

- Developer-focused
- Command-line interfaces
- Reusable libraries
- Well-documented APIs
- Comprehensive examples

---

## 🏗️ Projects

### brand-kit/
**Status:** ✅ Active
**Type:** CLI Tool
**Stack:** TypeScript
**Purpose:** Branding toolkit and asset management

CLI tool for managing brand assets, generating branded materials, and ensuring brand consistency across projects.

**Quick Start:**
```bash
cd Tools/brand-kit
pnpm install
pnpm build
pnpm link
brand-kit --help
```

---

### codemap/
**Status:** ✅ Active
**Type:** CLI Tool
**Stack:** TypeScript
**Purpose:** Codebase cartography and visualization

Maps and visualizes codebase structure, dependencies, and relationships. Useful for understanding large codebases.

**Quick Start:**
```bash
cd Tools/codemap
pnpm install
pnpm build
codemap analyze /path/to/codebase
```

---

### agent-context-optimizer/
**Status:** ✅ Active
**Type:** CLI/Library Tool
**Stack:** TypeScript
**Purpose:** AI agent context optimization

Optimizes context provided to AI agents by analyzing code structure, selecting relevant files, and managing token budgets.

**Quick Start:**
```bash
cd Tools/agent-context-optimizer
pnpm install
pnpm build
```

---

### monorepo-health-analyzer/
**Status:** ✅ Active
**Type:** CLI Tool
**Stack:** TypeScript
**Purpose:** Monorepo health monitoring and analysis

Analyzes monorepo health, identifies issues, suggests improvements, and tracks metrics over time.

**Quick Start:**
```bash
cd Tools/monorepo-health-analyzer
pnpm install
pnpm build
pnpm start
```

---

### skills-agents-inventory/
**Status:** ✅ Active
**Type:** CLI/Library Tool
**Stack:** TypeScript
**Purpose:** Skills and agents cataloging

Catalogs and manages skills and agents across the workspace. Provides inventory, search, and documentation generation.

**Quick Start:**
```bash
cd Tools/skills-agents-inventory
pnpm install
pnpm build
```

---

## 📐 Structure Standards

Tool projects follow the `tool-cli` or `tool-library` template:

```
Tools/{project}/
├── README.md              # Project overview
├── src/                   # Source code
│   ├── commands/          # CLI commands (for CLI tools)
│   ├── lib/               # Core logic
│   └── utils/             # Utilities
├── bin/                   # CLI entry point (for CLI tools)
├── tests/                 # Test suites
├── examples/              # Usage examples
└── docs/                  # Documentation
    ├── API.md
    ├── COMMANDS.md
    └── DEVELOPMENT.md
```

---

## 🚀 Getting Started

### Prerequisites

For TypeScript tools:
- Node.js 18+
- pnpm 9+

For Python tools:
- Python 3.11+
- pip or poetry

### Creating New Tool

```bash
# Use appropriate template
cp -r ../.morphism/templates/projects/tool-cli ./my-tool
cd my-tool
# Edit README.md and fill in template variables
```

---

## 💻 Common Patterns

### CLI Tool Structure

```typescript
// src/index.ts
#!/usr/bin/env node
import { Command } from 'commander';

const program = new Command();

program
  .name('my-tool')
  .description('Tool description')
  .version('1.0.0');

program
  .command('action')
  .description('Action description')
  .action(() => {
    // Implementation
  });

program.parse();
```

### Library Structure

```typescript
// src/index.ts
export { MyClass } from './lib/MyClass';
export { myFunction } from './lib/functions';
export type { MyType } from './types';
```

---

## 📚 Documentation

- [Tool Templates](../.morphism/templates/projects/)
- [CLI Development Guide](../docs/guides/cli-development.md)
- [Library Development Guide](../docs/guides/library-development.md)

---

**Maintained by:** Morphism Tools Team
