// Quick manual test of PathResolver functionality
const { PathResolver } = require('./dist/core/PathResolver');

console.log('Testing PathResolver...\n');

// Test 1: Format detection
console.log('1. Format Detection:');
console.log('  Windows path:', PathResolver.detectFormat('C:\\Users\\mesha'));
console.log('  Linux path:', PathResolver.detectFormat('/home/meshal'));
console.log('  WSL path:', PathResolver.detectFormat('/mnt/c/Users/mesha'));

// Test 2: Normalization
console.log('\n2. Normalization:');
console.log('  C:\\Users\\mesha ->', PathResolver.normalize('C:\\Users\\mesha'));
console.log('  /home/meshal ->', PathResolver.normalize('/home/meshal'));
console.log('  /mnt/c/Users ->', PathResolver.normalize('/mnt/c/Users'));

// Test 3: Idempotence
console.log('\n3. Idempotence:');
const path1 = 'C:\\Users\\mesha';
const norm1 = PathResolver.normalize(path1);
const norm2 = PathResolver.normalize(norm1);
console.log('  First normalize:', norm1);
console.log('  Second normalize:', norm2);
console.log('  Idempotent:', norm1 === norm2);

// Test 4: Round-trip
console.log('\n4. Round-trip (Windows <-> WSL):');
const winPath = 'C:\\Users\\mesha\\Desktop';
const wslPath = PathResolver.toWSL(winPath);
const backToWin = PathResolver.toWindows(wslPath);
console.log('  Original Windows:', winPath);
console.log('  To WSL:', wslPath);
console.log('  Back to Windows:', backToWin);
console.log('  Semantic match:', backToWin === 'C:\\Users\\mesha\\Desktop');

console.log('\n✓ Manual tests complete');
