// REST API service
// TODO: Uncomment when InventoryService is implemented
// export * from './InventoryService';
