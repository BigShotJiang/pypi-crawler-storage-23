// CLI integration
// TODO: Uncomment when InventoryCLI is implemented
// export * from './InventoryCLI';
