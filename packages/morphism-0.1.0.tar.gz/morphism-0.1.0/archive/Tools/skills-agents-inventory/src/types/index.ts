// Type definitions and interfaces

export type ComponentType = 'skill' | 'agent' | 'cli';

export interface ComponentMetadata {
  name: string;
  version?: string;
  description?: string;
  summary?: string;
  language?: string;
  capabilities?: string[];
  commands?: CommandInfo[];
  dependencies?: Record<string, string>;
  customFields?: Record<string, any>;
}

export interface CommandInfo {
  name: string;
  description: string;
  arguments?: ArgumentInfo[];
}

export interface ArgumentInfo {
  name: string;
  description: string;
  required: boolean;
  type?: string;
}

export interface Component {
  id: string;
  type: ComponentType;
  name: string;
  path: string;
  relativePath: string;
  metadata: ComponentMetadata;
  discoveredAt: Date;
  lastModified: Date;
  isActive: boolean;
}

export interface ScanOptions {
  maxDepth: number;
  followSymlinks: boolean;
  excludePatterns: string[];
  includePatterns: string[];
}

export interface QueryCriteria {
  name?: string;
  type?: ComponentType[];
  language?: string;
  keywords?: string[];
  fuzzyMatch?: boolean;
  limit?: number;
  offset?: number;
}

export interface SearchOptions {
  type?: ComponentType[];
  language?: string;
  fuzzyMatch?: boolean;
  limit?: number;
}

export interface ListOptions {
  type?: ComponentType[];
  language?: string;
  limit?: number;
  offset?: number;
}

export interface InventoryConfig {
  workspace: {
    root: string;
    excludePatterns: string[];
    includePatterns: string[];
  };
  discovery: {
    maxDepth: number;
    followSymlinks: boolean;
    autoRefreshInterval?: number;
  };
  service: {
    port: number;
    host: string;
    enableCORS: boolean;
    authToken?: string;
  };
  database: {
    path: string;
  };
  cache: {
    enabled: boolean;
    ttl: number;
  };
}

// API Response Types
export interface SearchResponse {
  results: ComponentSearchResult[];
  total: number;
  page: number;
  limit: number;
}

export interface ComponentSearchResult extends Component {
  score?: number;
}

export interface ErrorResponse {
  error: {
    code: string;
    message: string;
    details?: any;
    suggestions?: string[];
  };
}

export interface HealthCheckResponse {
  status: 'healthy' | 'unhealthy';
  timestamp: string;
  version?: string;
}

export interface RefreshResponse {
  success: boolean;
  componentsAdded: number;
  componentsUpdated: number;
  componentsRemoved: number;
  duration: number;
}
