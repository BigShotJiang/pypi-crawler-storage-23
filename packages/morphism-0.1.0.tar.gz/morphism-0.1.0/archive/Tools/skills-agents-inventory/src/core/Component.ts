import { Component as IComponent, ComponentType, ComponentMetadata } from '../types';
import { createHash } from 'crypto';
import { basename, dirname } from 'path';

/**
 * Component class representing a skill, agent, or CLI tool in the inventory.
 * Provides factory methods for creating components from different sources.
 */
export class Component implements IComponent {
  constructor(
    public id: string,
    public type: ComponentType,
    public name: string,
    public path: string,
    public relativePath: string,
    public metadata: ComponentMetadata,
    public discoveredAt: Date,
    public lastModified: Date,
    public isActive: boolean = true
  ) {}

  /**
   * Create a Component from a package.json file.
   * @param path Absolute path to the package.json file
   * @param content Parsed package.json content
   * @param relativePath Relative path from workspace root
   * @param lastModified Last modified timestamp of the package.json file
   * @returns Component instance
   */
  static fromPackageJson(
    path: string,
    content: any,
    relativePath: string,
    lastModified: Date
  ): Component {
    const componentPath = dirname(path);
    const componentRelativePath = dirname(relativePath);
    
    // Determine component type based on package.json content
    const type = Component.inferTypeFromPackageJson(content);
    
    // Extract metadata
    const metadata: ComponentMetadata = {
      name: content.name || basename(componentPath),
      version: content.version,
      description: content.description,
      language: Component.inferLanguage(content),
      dependencies: content.dependencies,
      customFields: {
        devDependencies: content.devDependencies,
        scripts: content.scripts,
        keywords: content.keywords,
        author: content.author,
        license: content.license,
      },
    };

    // Extract CLI commands if this is a CLI tool
    if (type === 'cli' && content.bin) {
      metadata.commands = Component.extractCommandsFromBin(content.bin);
    }

    // Generate unique ID based on path
    const id = Component.generateId(componentPath);

    return new Component(
      id,
      type,
      metadata.name,
      componentPath,
      componentRelativePath,
      metadata,
      new Date(),
      lastModified,
      true
    );
  }

  /**
   * Create a Component from an agent configuration file.
   * @param path Absolute path to the agent config file
   * @param content Parsed agent config content
   * @param relativePath Relative path from workspace root
   * @param lastModified Last modified timestamp of the config file
   * @returns Component instance
   */
  static fromAgentConfig(
    path: string,
    content: any,
    relativePath: string,
    lastModified: Date
  ): Component {
    const componentPath = dirname(path);
    const componentRelativePath = dirname(relativePath);
    
    // Extract metadata from agent config
    const metadata: ComponentMetadata = {
      name: content.name || basename(componentPath),
      version: content.version,
      description: content.description,
      capabilities: content.capabilities || [],
      customFields: {
        interfaces: content.interfaces,
        config: content.config,
        dependencies: content.dependencies,
      },
    };

    // Generate unique ID based on path
    const id = Component.generateId(componentPath);

    return new Component(
      id,
      'agent',
      metadata.name,
      componentPath,
      componentRelativePath,
      metadata,
      new Date(),
      lastModified,
      true
    );
  }

  /**
   * Serialize the component to a JSON-compatible object.
   * @returns Plain object representation
   */
  toJSON(): object {
    return {
      id: this.id,
      type: this.type,
      name: this.name,
      path: this.path,
      relativePath: this.relativePath,
      metadata: this.metadata,
      discoveredAt: this.discoveredAt.toISOString(),
      lastModified: this.lastModified.toISOString(),
      isActive: this.isActive,
    };
  }

  /**
   * Generate a unique ID for a component based on its path.
   * Uses SHA-256 hash of the path to ensure consistency.
   * @param path Component path
   * @returns Unique ID string
   */
  private static generateId(path: string): string {
    const hash = createHash('sha256').update(path).digest('hex');
    return hash.substring(0, 16);
  }

  /**
   * Infer component type from package.json content.
   * @param content Parsed package.json
   * @returns Component type
   */
  private static inferTypeFromPackageJson(content: any): ComponentType {
    // Check if it has bin entries (CLI tool)
    if (content.bin) {
      return 'cli';
    }

    // Check keywords for agent indicators
    const keywords = content.keywords || [];
    if (keywords.some((k: string) => k.toLowerCase().includes('agent'))) {
      return 'agent';
    }

    // Check name for agent indicators
    if (content.name && content.name.toLowerCase().includes('agent')) {
      return 'agent';
    }

    // Default to skill
    return 'skill';
  }

  /**
   * Infer primary programming language from package.json.
   * @param content Parsed package.json
   * @returns Language identifier
   */
  private static inferLanguage(content: any): string {
    // Check for TypeScript
    if (
      content.devDependencies?.typescript ||
      content.dependencies?.typescript
    ) {
      return 'typescript';
    }

    // Default to JavaScript for npm packages
    return 'javascript';
  }

  /**
   * Extract command information from package.json bin field.
   * @param bin Bin field from package.json
   * @returns Array of command info
   */
  private static extractCommandsFromBin(bin: any): any[] {
    if (typeof bin === 'string') {
      // Single command with package name
      return [{ name: 'default', description: '' }];
    }

    if (typeof bin === 'object') {
      // Multiple commands
      return Object.keys(bin).map((name) => ({
        name,
        description: '',
      }));
    }

    return [];
  }
}
