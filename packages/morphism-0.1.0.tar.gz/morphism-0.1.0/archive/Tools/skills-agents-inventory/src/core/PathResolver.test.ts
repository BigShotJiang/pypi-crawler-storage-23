import { PathResolver, PathFormat } from './PathResolver';

describe('PathResolver', () => {
  describe('detectFormat', () => {
    it('should detect Windows paths', () => {
      expect(PathResolver.detectFormat('C:\\Users\\mesha')).toBe('windows');
      expect(PathResolver.detectFormat('D:\\Projects\\test')).toBe('windows');
      expect(PathResolver.detectFormat('c:/Users/mesha')).toBe('windows');
      expect(PathResolver.detectFormat('Z:\\data')).toBe('windows');
    });

    it('should detect Linux paths', () => {
      expect(PathResolver.detectFormat('/home/meshal')).toBe('linux');
      expect(PathResolver.detectFormat('/usr/local/bin')).toBe('linux');
      expect(PathResolver.detectFormat('/var/log')).toBe('linux');
      expect(PathResolver.detectFormat('/')).toBe('linux');
    });

    it('should detect WSL paths', () => {
      expect(PathResolver.detectFormat('/mnt/c/Users/mesha')).toBe('wsl');
      expect(PathResolver.detectFormat('/mnt/d/Projects')).toBe('wsl');
      expect(PathResolver.detectFormat('/mnt/z/data')).toBe('wsl');
    });

    it('should return unknown for invalid paths', () => {
      expect(PathResolver.detectFormat('')).toBe('unknown');
      expect(PathResolver.detectFormat('   ')).toBe('unknown');
      expect(PathResolver.detectFormat('relative/path')).toBe('unknown');
      expect(PathResolver.detectFormat('./relative')).toBe('unknown');
    });
  });

  describe('isWindows', () => {
    it('should return true for Windows paths', () => {
      expect(PathResolver.isWindows('C:\\Users\\mesha')).toBe(true);
      expect(PathResolver.isWindows('D:/Projects')).toBe(true);
    });

    it('should return false for non-Windows paths', () => {
      expect(PathResolver.isWindows('/home/meshal')).toBe(false);
      expect(PathResolver.isWindows('/mnt/c/Users')).toBe(false);
    });
  });

  describe('isLinux', () => {
    it('should return true for Linux paths', () => {
      expect(PathResolver.isLinux('/home/meshal')).toBe(true);
      expect(PathResolver.isLinux('/usr/local')).toBe(true);
    });

    it('should return false for non-Linux paths', () => {
      expect(PathResolver.isLinux('C:\\Users')).toBe(false);
      expect(PathResolver.isLinux('/mnt/c/Users')).toBe(false);
    });
  });

  describe('isWSL', () => {
    it('should return true for WSL paths', () => {
      expect(PathResolver.isWSL('/mnt/c/Users/mesha')).toBe(true);
      expect(PathResolver.isWSL('/mnt/d/Projects')).toBe(true);
    });

    it('should return false for non-WSL paths', () => {
      expect(PathResolver.isWSL('C:\\Users')).toBe(false);
      expect(PathResolver.isWSL('/home/meshal')).toBe(false);
    });
  });

  describe('normalize', () => {
    it('should normalize Windows paths to WSL format', () => {
      expect(PathResolver.normalize('C:\\Users\\mesha')).toBe('/mnt/c/Users/mesha');
      expect(PathResolver.normalize('D:\\Projects\\test')).toBe('/mnt/d/Projects/test');
      expect(PathResolver.normalize('c:/Users/mesha')).toBe('/mnt/c/Users/mesha');
    });

    it('should normalize WSL paths', () => {
      expect(PathResolver.normalize('/mnt/c/Users/mesha')).toBe('/mnt/c/Users/mesha');
      expect(PathResolver.normalize('/mnt/d/Projects/')).toBe('/mnt/d/Projects');
    });

    it('should normalize Linux paths', () => {
      expect(PathResolver.normalize('/home/meshal')).toBe('/home/meshal');
      expect(PathResolver.normalize('/usr/local/bin/')).toBe('/usr/local/bin');
    });

    it('should convert backslashes to forward slashes', () => {
      expect(PathResolver.normalize('/mnt/c\\Users\\mesha')).toBe('/mnt/c/Users/mesha');
    });

    it('should collapse multiple consecutive slashes', () => {
      expect(PathResolver.normalize('/home//meshal///projects')).toBe('/home/meshal/projects');
      expect(PathResolver.normalize('/mnt/c///Users')).toBe('/mnt/c/Users');
    });

    it('should remove trailing slashes except for root', () => {
      expect(PathResolver.normalize('/home/meshal/')).toBe('/home/meshal');
      expect(PathResolver.normalize('/mnt/c/Users/')).toBe('/mnt/c/Users');
      expect(PathResolver.normalize('/')).toBe('/');
    });

    it('should handle empty and whitespace paths', () => {
      expect(PathResolver.normalize('')).toBe('');
      expect(PathResolver.normalize('   ')).toBe('');
    });

    it('should be idempotent', () => {
      const paths = [
        'C:\\Users\\mesha',
        '/home/meshal',
        '/mnt/c/Users/mesha',
        'D:/Projects/test'
      ];

      paths.forEach(path => {
        const normalized = PathResolver.normalize(path);
        const doubleNormalized = PathResolver.normalize(normalized);
        expect(normalized).toBe(doubleNormalized);
      });
    });
  });

  describe('toWindows', () => {
    it('should convert WSL paths to Windows format', () => {
      expect(PathResolver.toWindows('/mnt/c/Users/mesha')).toBe('C:\\Users\\mesha');
      expect(PathResolver.toWindows('/mnt/d/Projects/test')).toBe('D:\\Projects\\test');
    });

    it('should convert Windows paths to Windows format', () => {
      expect(PathResolver.toWindows('C:\\Users\\mesha')).toBe('C:\\Users\\mesha');
      expect(PathResolver.toWindows('c:/Users/mesha')).toBe('C:\\Users\\mesha');
    });

    it('should return Linux paths as-is (cannot convert)', () => {
      expect(PathResolver.toWindows('/home/meshal')).toBe('/home/meshal');
      expect(PathResolver.toWindows('/usr/local')).toBe('/usr/local');
    });

    it('should handle empty paths', () => {
      expect(PathResolver.toWindows('')).toBe('');
    });
  });

  describe('toLinux', () => {
    it('should keep Linux paths as-is', () => {
      expect(PathResolver.toLinux('/home/meshal')).toBe('/home/meshal');
      expect(PathResolver.toLinux('/usr/local/bin')).toBe('/usr/local/bin');
    });

    it('should normalize WSL paths to Linux-style', () => {
      expect(PathResolver.toLinux('/mnt/c/Users/mesha')).toBe('/mnt/c/Users/mesha');
    });

    it('should convert Windows paths to normalized format', () => {
      expect(PathResolver.toLinux('C:\\Users\\mesha')).toBe('/mnt/c/Users/mesha');
    });

    it('should handle empty paths', () => {
      expect(PathResolver.toLinux('')).toBe('');
    });
  });

  describe('toWSL', () => {
    it('should keep WSL paths as-is', () => {
      expect(PathResolver.toWSL('/mnt/c/Users/mesha')).toBe('/mnt/c/Users/mesha');
      expect(PathResolver.toWSL('/mnt/d/Projects')).toBe('/mnt/d/Projects');
    });

    it('should convert Windows paths to WSL format', () => {
      expect(PathResolver.toWSL('C:\\Users\\mesha')).toBe('/mnt/c/Users/mesha');
      expect(PathResolver.toWSL('D:/Projects/test')).toBe('/mnt/d/Projects/test');
    });

    it('should return Linux paths as-is (cannot convert)', () => {
      expect(PathResolver.toWSL('/home/meshal')).toBe('/home/meshal');
    });

    it('should handle empty paths', () => {
      expect(PathResolver.toWSL('')).toBe('');
    });
  });

  describe('edge cases', () => {
    it('should handle paths with spaces', () => {
      expect(PathResolver.normalize('C:\\Users\\John Doe\\Documents')).toBe('/mnt/c/Users/John Doe/Documents');
      expect(PathResolver.toWindows('/mnt/c/Users/John Doe')).toBe('C:\\Users\\John Doe');
    });

    it('should handle paths with special characters', () => {
      expect(PathResolver.normalize('C:\\Users\\mesha\\Projects (2024)')).toBe('/mnt/c/Users/mesha/Projects (2024)');
    });

    it('should handle mixed slashes in Windows paths', () => {
      expect(PathResolver.normalize('C:\\Users/mesha\\Documents')).toBe('/mnt/c/Users/mesha/Documents');
    });

    it('should handle case sensitivity in drive letters', () => {
      expect(PathResolver.normalize('c:\\Users')).toBe('/mnt/c/Users');
      expect(PathResolver.normalize('C:\\Users')).toBe('/mnt/c/Users');
      expect(PathResolver.toWindows('/mnt/c/Users')).toBe('C:\\Users');
    });
  });

  describe('round-trip conversions', () => {
    it('should maintain semantic meaning for Windows <-> WSL', () => {
      const windowsPath = 'C:\\Users\\mesha\\Desktop\\GitHub';
      const wslPath = PathResolver.toWSL(windowsPath);
      const backToWindows = PathResolver.toWindows(wslPath);
      
      expect(wslPath).toBe('/mnt/c/Users/mesha/Desktop/GitHub');
      expect(backToWindows).toBe('C:\\Users\\mesha\\Desktop\\GitHub');
    });

    it('should maintain semantic meaning for WSL <-> Windows', () => {
      const wslPath = '/mnt/d/Projects/test';
      const windowsPath = PathResolver.toWindows(wslPath);
      const backToWSL = PathResolver.toWSL(windowsPath);
      
      expect(windowsPath).toBe('D:\\Projects\\test');
      expect(backToWSL).toBe('/mnt/d/Projects/test');
    });
  });
});
