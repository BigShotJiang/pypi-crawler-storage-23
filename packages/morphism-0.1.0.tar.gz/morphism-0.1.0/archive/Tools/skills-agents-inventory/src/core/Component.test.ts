import { Component } from './Component';
import { ComponentType } from '../types';

describe('Component', () => {
  describe('constructor', () => {
    it('should create a component with all properties', () => {
      const now = new Date();
      const component = new Component(
        'test-id',
        'skill',
        'Test Component',
        '/path/to/component',
        'relative/path',
        { name: 'Test Component' },
        now,
        now,
        true
      );

      expect(component.id).toBe('test-id');
      expect(component.type).toBe('skill');
      expect(component.name).toBe('Test Component');
      expect(component.path).toBe('/path/to/component');
      expect(component.relativePath).toBe('relative/path');
      expect(component.metadata.name).toBe('Test Component');
      expect(component.discoveredAt).toBe(now);
      expect(component.lastModified).toBe(now);
      expect(component.isActive).toBe(true);
    });

    it('should default isActive to true when not provided', () => {
      const now = new Date();
      const component = new Component(
        'test-id',
        'skill',
        'Test Component',
        '/path/to/component',
        'relative/path',
        { name: 'Test Component' },
        now,
        now
      );

      expect(component.isActive).toBe(true);
    });
  });

  describe('fromPackageJson', () => {
    it('should create a skill component from basic package.json', () => {
      const packageJson = {
        name: 'my-skill',
        version: '1.0.0',
        description: 'A test skill',
      };

      const lastModified = new Date('2024-01-01');
      const component = Component.fromPackageJson(
        '/workspace/my-skill/package.json',
        packageJson,
        'my-skill/package.json',
        lastModified
      );

      expect(component.type).toBe('skill');
      expect(component.name).toBe('my-skill');
      expect(component.path).toBe('/workspace/my-skill');
      expect(component.relativePath).toBe('my-skill');
      expect(component.metadata.name).toBe('my-skill');
      expect(component.metadata.version).toBe('1.0.0');
      expect(component.metadata.description).toBe('A test skill');
      expect(component.metadata.language).toBe('javascript');
      expect(component.lastModified).toBe(lastModified);
      expect(component.isActive).toBe(true);
    });

    it('should create a CLI component when bin field is present', () => {
      const packageJson = {
        name: 'my-cli',
        version: '1.0.0',
        bin: {
          'my-command': './bin/cli.js',
        },
      };

      const component = Component.fromPackageJson(
        '/workspace/my-cli/package.json',
        packageJson,
        'my-cli/package.json',
        new Date()
      );

      expect(component.type).toBe('cli');
      expect(component.metadata.commands).toEqual([
        { name: 'my-command', description: '' },
      ]);
    });

    it('should handle single bin string', () => {
      const packageJson = {
        name: 'my-cli',
        version: '1.0.0',
        bin: './bin/cli.js',
      };

      const component = Component.fromPackageJson(
        '/workspace/my-cli/package.json',
        packageJson,
        'my-cli/package.json',
        new Date()
      );

      expect(component.type).toBe('cli');
      expect(component.metadata.commands).toEqual([
        { name: 'default', description: '' },
      ]);
    });

    it('should create an agent component when keywords include "agent"', () => {
      const packageJson = {
        name: 'my-agent',
        version: '1.0.0',
        keywords: ['ai', 'agent', 'automation'],
      };

      const component = Component.fromPackageJson(
        '/workspace/my-agent/package.json',
        packageJson,
        'my-agent/package.json',
        new Date()
      );

      expect(component.type).toBe('agent');
    });

    it('should create an agent component when name includes "agent"', () => {
      const packageJson = {
        name: 'my-agent-tool',
        version: '1.0.0',
      };

      const component = Component.fromPackageJson(
        '/workspace/my-agent-tool/package.json',
        packageJson,
        'my-agent-tool/package.json',
        new Date()
      );

      expect(component.type).toBe('agent');
    });

    it('should detect TypeScript language', () => {
      const packageJson = {
        name: 'my-skill',
        version: '1.0.0',
        devDependencies: {
          typescript: '^5.0.0',
        },
      };

      const component = Component.fromPackageJson(
        '/workspace/my-skill/package.json',
        packageJson,
        'my-skill/package.json',
        new Date()
      );

      expect(component.metadata.language).toBe('typescript');
    });

    it('should include dependencies in metadata', () => {
      const packageJson = {
        name: 'my-skill',
        version: '1.0.0',
        dependencies: {
          express: '^4.18.0',
          lodash: '^4.17.21',
        },
      };

      const component = Component.fromPackageJson(
        '/workspace/my-skill/package.json',
        packageJson,
        'my-skill/package.json',
        new Date()
      );

      expect(component.metadata.dependencies).toEqual({
        express: '^4.18.0',
        lodash: '^4.17.21',
      });
    });

    it('should include custom fields in metadata', () => {
      const packageJson = {
        name: 'my-skill',
        version: '1.0.0',
        scripts: {
          test: 'jest',
          build: 'tsc',
        },
        keywords: ['test', 'skill'],
        author: 'John Doe',
        license: 'MIT',
        devDependencies: {
          jest: '^29.0.0',
        },
      };

      const component = Component.fromPackageJson(
        '/workspace/my-skill/package.json',
        packageJson,
        'my-skill/package.json',
        new Date()
      );

      expect(component.metadata.customFields).toEqual({
        devDependencies: { jest: '^29.0.0' },
        scripts: { test: 'jest', build: 'tsc' },
        keywords: ['test', 'skill'],
        author: 'John Doe',
        license: 'MIT',
      });
    });

    it('should use directory name when package name is missing', () => {
      const packageJson = {
        version: '1.0.0',
      };

      const component = Component.fromPackageJson(
        '/workspace/unnamed-skill/package.json',
        packageJson,
        'unnamed-skill/package.json',
        new Date()
      );

      expect(component.metadata.name).toBe('unnamed-skill');
    });

    it('should generate consistent IDs for the same path', () => {
      const packageJson = { name: 'test', version: '1.0.0' };

      const component1 = Component.fromPackageJson(
        '/workspace/test/package.json',
        packageJson,
        'test/package.json',
        new Date()
      );

      const component2 = Component.fromPackageJson(
        '/workspace/test/package.json',
        packageJson,
        'test/package.json',
        new Date()
      );

      expect(component1.id).toBe(component2.id);
    });

    it('should generate different IDs for different paths', () => {
      const packageJson = { name: 'test', version: '1.0.0' };

      const component1 = Component.fromPackageJson(
        '/workspace/test1/package.json',
        packageJson,
        'test1/package.json',
        new Date()
      );

      const component2 = Component.fromPackageJson(
        '/workspace/test2/package.json',
        packageJson,
        'test2/package.json',
        new Date()
      );

      expect(component1.id).not.toBe(component2.id);
    });
  });

  describe('fromAgentConfig', () => {
    it('should create an agent component from config', () => {
      const agentConfig = {
        name: 'my-agent',
        version: '1.0.0',
        description: 'A test agent',
        capabilities: ['chat', 'search'],
      };

      const lastModified = new Date('2024-01-01');
      const component = Component.fromAgentConfig(
        '/workspace/my-agent/agent.json',
        agentConfig,
        'my-agent/agent.json',
        lastModified
      );

      expect(component.type).toBe('agent');
      expect(component.name).toBe('my-agent');
      expect(component.path).toBe('/workspace/my-agent');
      expect(component.relativePath).toBe('my-agent');
      expect(component.metadata.name).toBe('my-agent');
      expect(component.metadata.version).toBe('1.0.0');
      expect(component.metadata.description).toBe('A test agent');
      expect(component.metadata.capabilities).toEqual(['chat', 'search']);
      expect(component.lastModified).toBe(lastModified);
      expect(component.isActive).toBe(true);
    });

    it('should handle agent config with interfaces and dependencies', () => {
      const agentConfig = {
        name: 'my-agent',
        version: '1.0.0',
        interfaces: ['http', 'websocket'],
        config: {
          port: 3000,
          host: 'localhost',
        },
        dependencies: {
          'other-agent': '^1.0.0',
        },
      };

      const component = Component.fromAgentConfig(
        '/workspace/my-agent/agent.json',
        agentConfig,
        'my-agent/agent.json',
        new Date()
      );

      expect(component.metadata.customFields).toEqual({
        interfaces: ['http', 'websocket'],
        config: { port: 3000, host: 'localhost' },
        dependencies: { 'other-agent': '^1.0.0' },
      });
    });

    it('should use directory name when agent name is missing', () => {
      const agentConfig = {
        version: '1.0.0',
      };

      const component = Component.fromAgentConfig(
        '/workspace/unnamed-agent/agent.json',
        agentConfig,
        'unnamed-agent/agent.json',
        new Date()
      );

      expect(component.metadata.name).toBe('unnamed-agent');
    });

    it('should default capabilities to empty array when missing', () => {
      const agentConfig = {
        name: 'my-agent',
        version: '1.0.0',
      };

      const component = Component.fromAgentConfig(
        '/workspace/my-agent/agent.json',
        agentConfig,
        'my-agent/agent.json',
        new Date()
      );

      expect(component.metadata.capabilities).toEqual([]);
    });
  });

  describe('toJSON', () => {
    it('should serialize component to JSON-compatible object', () => {
      const discoveredAt = new Date('2024-01-01T10:00:00Z');
      const lastModified = new Date('2024-01-01T09:00:00Z');

      const component = new Component(
        'test-id',
        'skill',
        'Test Component',
        '/path/to/component',
        'relative/path',
        {
          name: 'Test Component',
          version: '1.0.0',
          description: 'A test component',
        },
        discoveredAt,
        lastModified,
        true
      );

      const json = component.toJSON();

      expect(json).toEqual({
        id: 'test-id',
        type: 'skill',
        name: 'Test Component',
        path: '/path/to/component',
        relativePath: 'relative/path',
        metadata: {
          name: 'Test Component',
          version: '1.0.0',
          description: 'A test component',
        },
        discoveredAt: '2024-01-01T10:00:00.000Z',
        lastModified: '2024-01-01T09:00:00.000Z',
        isActive: true,
      });
    });

    it('should handle inactive components', () => {
      const component = new Component(
        'test-id',
        'skill',
        'Test Component',
        '/path/to/component',
        'relative/path',
        { name: 'Test Component' },
        new Date(),
        new Date(),
        false
      );

      const json = component.toJSON();

      expect(json).toHaveProperty('isActive', false);
    });

    it('should serialize complex metadata', () => {
      const component = new Component(
        'test-id',
        'cli',
        'Test CLI',
        '/path/to/cli',
        'relative/path',
        {
          name: 'Test CLI',
          version: '2.0.0',
          description: 'A test CLI tool',
          language: 'typescript',
          commands: [
            { name: 'cmd1', description: 'Command 1' },
            { name: 'cmd2', description: 'Command 2' },
          ],
          dependencies: {
            commander: '^10.0.0',
          },
          customFields: {
            author: 'Jane Doe',
            license: 'Apache-2.0',
          },
        },
        new Date(),
        new Date(),
        true
      );

      const json = component.toJSON();

      expect(json).toHaveProperty('metadata.commands');
      expect(json).toHaveProperty('metadata.dependencies');
      expect(json).toHaveProperty('metadata.customFields');
    });
  });

  describe('type inference', () => {
    it('should prioritize CLI type when bin field exists', () => {
      const packageJson = {
        name: 'agent-cli',
        keywords: ['agent'],
        bin: './cli.js',
      };

      const component = Component.fromPackageJson(
        '/workspace/agent-cli/package.json',
        packageJson,
        'agent-cli/package.json',
        new Date()
      );

      expect(component.type).toBe('cli');
    });

    it('should detect agent from keywords case-insensitively', () => {
      const packageJson = {
        name: 'my-tool',
        keywords: ['AI', 'AGENT', 'automation'],
      };

      const component = Component.fromPackageJson(
        '/workspace/my-tool/package.json',
        packageJson,
        'my-tool/package.json',
        new Date()
      );

      expect(component.type).toBe('agent');
    });

    it('should detect agent from name case-insensitively', () => {
      const packageJson = {
        name: 'MY-AGENT-TOOL',
      };

      const component = Component.fromPackageJson(
        '/workspace/MY-AGENT-TOOL/package.json',
        packageJson,
        'MY-AGENT-TOOL/package.json',
        new Date()
      );

      expect(component.type).toBe('agent');
    });
  });

  describe('ID generation', () => {
    it('should generate 16-character hex IDs', () => {
      const packageJson = { name: 'test', version: '1.0.0' };

      const component = Component.fromPackageJson(
        '/workspace/test/package.json',
        packageJson,
        'test/package.json',
        new Date()
      );

      expect(component.id).toMatch(/^[0-9a-f]{16}$/);
    });

    it('should generate stable IDs across multiple calls', () => {
      const packageJson = { name: 'test', version: '1.0.0' };
      const ids = new Set();

      for (let i = 0; i < 10; i++) {
        const component = Component.fromPackageJson(
          '/workspace/test/package.json',
          packageJson,
          'test/package.json',
          new Date()
        );
        ids.add(component.id);
      }

      expect(ids.size).toBe(1);
    });
  });
});
