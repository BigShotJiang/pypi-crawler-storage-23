/**
 * Config - Configuration management for the inventory system
 * 
 * Provides default configuration with workspace root detection
 * and utilities for working with inventory configuration.
 */

import * as os from 'os';
import * as path from 'path';
import * as fs from 'fs';
import { InventoryConfig } from '../types';
import { PathResolver } from './PathResolver';

/**
 * Detect the workspace root directory
 * 
 * Detection strategy:
 * 1. Check INVENTORY_WORKSPACE_ROOT environment variable
 * 2. Use default workspace location based on platform
 * 3. Normalize to canonical format using PathResolver
 */
export function detectWorkspaceRoot(): string {
  // Check environment variable first
  if (process.env.INVENTORY_WORKSPACE_ROOT) {
    return PathResolver.normalize(process.env.INVENTORY_WORKSPACE_ROOT);
  }

  // Default workspace location
  const platform = os.platform();
  const homeDir = os.homedir();

  let workspaceRoot: string;

  if (platform === 'win32') {
    // Windows: C:\Users\mesha\Desktop\GitHub
    workspaceRoot = path.join(homeDir, 'Desktop', 'GitHub');
  } else if (platform === 'linux') {
    // Check if running in WSL
    const isWSL = process.env.WSL_DISTRO_NAME !== undefined || 
                  process.env.WSLENV !== undefined;
    
    if (isWSL) {
      // WSL: /mnt/c/Users/mesha/Desktop/GitHub
      workspaceRoot = '/mnt/c/Users/mesha/Desktop/GitHub';
    } else {
      // Native Linux: ~/GitHub
      workspaceRoot = path.join(homeDir, 'GitHub');
    }
  } else {
    // macOS or other: ~/GitHub
    workspaceRoot = path.join(homeDir, 'GitHub');
  }

  return PathResolver.normalize(workspaceRoot);
}

/**
 * Get the default inventory configuration
 * 
 * This configuration works for standard workspace layouts and can be
 * overridden via environment variables or config files.
 */
export function getDefaultConfig(): InventoryConfig {
  const workspaceRoot = detectWorkspaceRoot();

  return {
    workspace: {
      root: workspaceRoot,
      excludePatterns: [
        'node_modules',
        '.git',
        'dist',
        'build',
        'coverage',
        '.next',
        '.nuxt',
        'out',
        'target',
        'bin',
        'obj',
        '.cache',
        'tmp',
        'temp'
      ],
      includePatterns: ['**']
    },
    discovery: {
      maxDepth: 10,
      followSymlinks: true,
      autoRefreshInterval: undefined // Disabled by default
    },
    service: {
      port: 3000,
      host: 'localhost',
      enableCORS: true,
      authToken: undefined // No authentication by default
    },
    database: {
      path: '.inventory/inventory.db'
    },
    cache: {
      enabled: true,
      ttl: 300 // 5 minutes in seconds
    }
  };
}

/**
 * Create a deep copy of a configuration object
 */
export function cloneConfig(config: InventoryConfig): InventoryConfig {
  return {
    workspace: {
      root: config.workspace.root,
      excludePatterns: [...config.workspace.excludePatterns],
      includePatterns: [...config.workspace.includePatterns]
    },
    discovery: {
      maxDepth: config.discovery.maxDepth,
      followSymlinks: config.discovery.followSymlinks,
      autoRefreshInterval: config.discovery.autoRefreshInterval
    },
    service: {
      port: config.service.port,
      host: config.service.host,
      enableCORS: config.service.enableCORS,
      authToken: config.service.authToken
    },
    database: {
      path: config.database.path
    },
    cache: {
      enabled: config.cache.enabled,
      ttl: config.cache.ttl
    }
  };
}

/**
 * Configuration validation error
 */
export class ConfigValidationError extends Error {
  constructor(
    message: string,
    public readonly field: string,
    public readonly value: any
  ) {
    super(message);
    this.name = 'ConfigValidationError';
  }
}

/**
 * Load configuration from a JSON file
 * 
 * @param filePath - Path to the configuration file
 * @returns Partial configuration object or null if file doesn't exist
 * @throws ConfigValidationError if file exists but is invalid JSON
 */
export function loadConfigFile(filePath: string): Partial<InventoryConfig> | null {
  // Check if file exists
  if (!fs.existsSync(filePath)) {
    return null;
  }

  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    throw new ConfigValidationError(
      `Failed to parse configuration file: ${error instanceof Error ? error.message : String(error)}`,
      'configFile',
      filePath
    );
  }
}

/**
 * Load configuration from environment variables
 * 
 * Environment variable mapping:
 * - INVENTORY_WORKSPACE_ROOT -> workspace.root
 * - INVENTORY_WORKSPACE_EXCLUDE -> workspace.excludePatterns (comma-separated)
 * - INVENTORY_WORKSPACE_INCLUDE -> workspace.includePatterns (comma-separated)
 * - INVENTORY_MAX_DEPTH -> discovery.maxDepth
 * - INVENTORY_FOLLOW_SYMLINKS -> discovery.followSymlinks
 * - INVENTORY_AUTO_REFRESH -> discovery.autoRefreshInterval
 * - INVENTORY_SERVICE_PORT -> service.port
 * - INVENTORY_SERVICE_HOST -> service.host
 * - INVENTORY_SERVICE_CORS -> service.enableCORS
 * - INVENTORY_AUTH_TOKEN -> service.authToken
 * - INVENTORY_DB_PATH -> database.path
 * - INVENTORY_CACHE_ENABLED -> cache.enabled
 * - INVENTORY_CACHE_TTL -> cache.ttl
 */
export function loadConfigFromEnv(): Partial<InventoryConfig> {
  const config: Partial<InventoryConfig> = {};

  // Workspace configuration
  if (process.env.INVENTORY_WORKSPACE_ROOT) {
    if (!config.workspace) config.workspace = {} as any;
    config.workspace!.root = PathResolver.normalize(process.env.INVENTORY_WORKSPACE_ROOT);
  }

  if (process.env.INVENTORY_WORKSPACE_EXCLUDE) {
    if (!config.workspace) config.workspace = {} as any;
    config.workspace!.excludePatterns = process.env.INVENTORY_WORKSPACE_EXCLUDE
      .split(',')
      .map(p => p.trim())
      .filter(p => p.length > 0);
  }

  if (process.env.INVENTORY_WORKSPACE_INCLUDE) {
    if (!config.workspace) config.workspace = {} as any;
    config.workspace!.includePatterns = process.env.INVENTORY_WORKSPACE_INCLUDE
      .split(',')
      .map(p => p.trim())
      .filter(p => p.length > 0);
  }

  // Discovery configuration
  if (process.env.INVENTORY_MAX_DEPTH) {
    if (!config.discovery) config.discovery = {} as any;
    const maxDepth = parseInt(process.env.INVENTORY_MAX_DEPTH, 10);
    if (isNaN(maxDepth)) {
      throw new ConfigValidationError(
        'INVENTORY_MAX_DEPTH must be a valid integer',
        'discovery.maxDepth',
        process.env.INVENTORY_MAX_DEPTH
      );
    }
    config.discovery!.maxDepth = maxDepth;
  }

  if (process.env.INVENTORY_FOLLOW_SYMLINKS) {
    if (!config.discovery) config.discovery = {} as any;
    const value = process.env.INVENTORY_FOLLOW_SYMLINKS.toLowerCase();
    if (value !== 'true' && value !== 'false') {
      throw new ConfigValidationError(
        'INVENTORY_FOLLOW_SYMLINKS must be "true" or "false"',
        'discovery.followSymlinks',
        process.env.INVENTORY_FOLLOW_SYMLINKS
      );
    }
    config.discovery!.followSymlinks = value === 'true';
  }

  if (process.env.INVENTORY_AUTO_REFRESH) {
    if (!config.discovery) config.discovery = {} as any;
    const autoRefresh = parseInt(process.env.INVENTORY_AUTO_REFRESH, 10);
    if (isNaN(autoRefresh)) {
      throw new ConfigValidationError(
        'INVENTORY_AUTO_REFRESH must be a valid integer',
        'discovery.autoRefreshInterval',
        process.env.INVENTORY_AUTO_REFRESH
      );
    }
    config.discovery!.autoRefreshInterval = autoRefresh;
  }

  // Service configuration
  if (process.env.INVENTORY_SERVICE_PORT) {
    if (!config.service) config.service = {} as any;
    const port = parseInt(process.env.INVENTORY_SERVICE_PORT, 10);
    if (isNaN(port) || port < 1 || port > 65535) {
      throw new ConfigValidationError(
        'INVENTORY_SERVICE_PORT must be a valid port number (1-65535)',
        'service.port',
        process.env.INVENTORY_SERVICE_PORT
      );
    }
    config.service!.port = port;
  }

  if (process.env.INVENTORY_SERVICE_HOST) {
    if (!config.service) config.service = {} as any;
    config.service!.host = process.env.INVENTORY_SERVICE_HOST;
  }

  if (process.env.INVENTORY_SERVICE_CORS) {
    if (!config.service) config.service = {} as any;
    const value = process.env.INVENTORY_SERVICE_CORS.toLowerCase();
    if (value !== 'true' && value !== 'false') {
      throw new ConfigValidationError(
        'INVENTORY_SERVICE_CORS must be "true" or "false"',
        'service.enableCORS',
        process.env.INVENTORY_SERVICE_CORS
      );
    }
    config.service!.enableCORS = value === 'true';
  }

  if (process.env.INVENTORY_AUTH_TOKEN) {
    if (!config.service) config.service = {} as any;
    config.service!.authToken = process.env.INVENTORY_AUTH_TOKEN;
  }

  // Database configuration
  if (process.env.INVENTORY_DB_PATH) {
    if (!config.database) config.database = {} as any;
    config.database!.path = process.env.INVENTORY_DB_PATH;
  }

  // Cache configuration
  if (process.env.INVENTORY_CACHE_ENABLED) {
    if (!config.cache) config.cache = {} as any;
    const value = process.env.INVENTORY_CACHE_ENABLED.toLowerCase();
    if (value !== 'true' && value !== 'false') {
      throw new ConfigValidationError(
        'INVENTORY_CACHE_ENABLED must be "true" or "false"',
        'cache.enabled',
        process.env.INVENTORY_CACHE_ENABLED
      );
    }
    config.cache!.enabled = value === 'true';
  }

  if (process.env.INVENTORY_CACHE_TTL) {
    if (!config.cache) config.cache = {} as any;
    const ttl = parseInt(process.env.INVENTORY_CACHE_TTL, 10);
    if (isNaN(ttl) || ttl < 0) {
      throw new ConfigValidationError(
        'INVENTORY_CACHE_TTL must be a non-negative integer',
        'cache.ttl',
        process.env.INVENTORY_CACHE_TTL
      );
    }
    config.cache!.ttl = ttl;
  }

  return config;
}

/**
 * Deep merge two partial configurations
 * 
 * @param base - Base configuration
 * @param override - Configuration to merge on top
 * @returns Merged configuration
 */
function mergeConfigs(
  base: Partial<InventoryConfig>,
  override: Partial<InventoryConfig>
): Partial<InventoryConfig> {
  const result: Partial<InventoryConfig> = { ...base };

  if (override.workspace) {
    result.workspace = {
      ...(base.workspace || {} as any),
      ...override.workspace
    };
  }

  if (override.discovery) {
    result.discovery = {
      ...(base.discovery || {} as any),
      ...override.discovery
    };
  }

  if (override.service) {
    result.service = {
      ...(base.service || {} as any),
      ...override.service
    };
  }

  if (override.database) {
    result.database = {
      ...(base.database || {} as any),
      ...override.database
    };
  }

  if (override.cache) {
    result.cache = {
      ...(base.cache || {} as any),
      ...override.cache
    };
  }

  return result;
}

/**
 * Validate a complete configuration object
 * 
 * @param config - Configuration to validate
 * @throws ConfigValidationError if validation fails
 */
export function validateConfig(config: InventoryConfig): void {
  // Validate workspace.root
  if (!config.workspace.root || typeof config.workspace.root !== 'string') {
    throw new ConfigValidationError(
      'workspace.root is required and must be a string',
      'workspace.root',
      config.workspace.root
    );
  }

  if (config.workspace.root.trim().length === 0) {
    throw new ConfigValidationError(
      'workspace.root cannot be empty',
      'workspace.root',
      config.workspace.root
    );
  }

  // Validate workspace.excludePatterns
  if (!Array.isArray(config.workspace.excludePatterns)) {
    throw new ConfigValidationError(
      'workspace.excludePatterns must be an array',
      'workspace.excludePatterns',
      config.workspace.excludePatterns
    );
  }

  // Validate workspace.includePatterns
  if (!Array.isArray(config.workspace.includePatterns)) {
    throw new ConfigValidationError(
      'workspace.includePatterns must be an array',
      'workspace.includePatterns',
      config.workspace.includePatterns
    );
  }

  if (config.workspace.includePatterns.length === 0) {
    throw new ConfigValidationError(
      'workspace.includePatterns must contain at least one pattern',
      'workspace.includePatterns',
      config.workspace.includePatterns
    );
  }

  // Validate discovery.maxDepth
  if (typeof config.discovery.maxDepth !== 'number' || !Number.isInteger(config.discovery.maxDepth)) {
    throw new ConfigValidationError(
      'discovery.maxDepth must be an integer',
      'discovery.maxDepth',
      config.discovery.maxDepth
    );
  }

  if (config.discovery.maxDepth < 1) {
    throw new ConfigValidationError(
      'discovery.maxDepth must be at least 1',
      'discovery.maxDepth',
      config.discovery.maxDepth
    );
  }

  // Validate discovery.followSymlinks
  if (typeof config.discovery.followSymlinks !== 'boolean') {
    throw new ConfigValidationError(
      'discovery.followSymlinks must be a boolean',
      'discovery.followSymlinks',
      config.discovery.followSymlinks
    );
  }

  // Validate discovery.autoRefreshInterval (optional)
  if (config.discovery.autoRefreshInterval !== undefined) {
    if (typeof config.discovery.autoRefreshInterval !== 'number' || 
        !Number.isInteger(config.discovery.autoRefreshInterval)) {
      throw new ConfigValidationError(
        'discovery.autoRefreshInterval must be an integer',
        'discovery.autoRefreshInterval',
        config.discovery.autoRefreshInterval
      );
    }

    if (config.discovery.autoRefreshInterval < 0) {
      throw new ConfigValidationError(
        'discovery.autoRefreshInterval must be non-negative',
        'discovery.autoRefreshInterval',
        config.discovery.autoRefreshInterval
      );
    }
  }

  // Validate service.port
  if (typeof config.service.port !== 'number' || !Number.isInteger(config.service.port)) {
    throw new ConfigValidationError(
      'service.port must be an integer',
      'service.port',
      config.service.port
    );
  }

  if (config.service.port < 1 || config.service.port > 65535) {
    throw new ConfigValidationError(
      'service.port must be between 1 and 65535',
      'service.port',
      config.service.port
    );
  }

  // Validate service.host
  if (!config.service.host || typeof config.service.host !== 'string') {
    throw new ConfigValidationError(
      'service.host is required and must be a string',
      'service.host',
      config.service.host
    );
  }

  // Validate service.enableCORS
  if (typeof config.service.enableCORS !== 'boolean') {
    throw new ConfigValidationError(
      'service.enableCORS must be a boolean',
      'service.enableCORS',
      config.service.enableCORS
    );
  }

  // Validate service.authToken (optional)
  if (config.service.authToken !== undefined && typeof config.service.authToken !== 'string') {
    throw new ConfigValidationError(
      'service.authToken must be a string',
      'service.authToken',
      config.service.authToken
    );
  }

  // Validate database.path
  if (!config.database.path || typeof config.database.path !== 'string') {
    throw new ConfigValidationError(
      'database.path is required and must be a string',
      'database.path',
      config.database.path
    );
  }

  if (config.database.path.trim().length === 0) {
    throw new ConfigValidationError(
      'database.path cannot be empty',
      'database.path',
      config.database.path
    );
  }

  // Validate cache.enabled
  if (typeof config.cache.enabled !== 'boolean') {
    throw new ConfigValidationError(
      'cache.enabled must be a boolean',
      'cache.enabled',
      config.cache.enabled
    );
  }

  // Validate cache.ttl
  if (typeof config.cache.ttl !== 'number' || !Number.isInteger(config.cache.ttl)) {
    throw new ConfigValidationError(
      'cache.ttl must be an integer',
      'cache.ttl',
      config.cache.ttl
    );
  }

  if (config.cache.ttl < 0) {
    throw new ConfigValidationError(
      'cache.ttl must be non-negative',
      'cache.ttl',
      config.cache.ttl
    );
  }
}

/**
 * Load and merge configuration from all sources
 * 
 * Configuration precedence (highest to lowest):
 * 1. Environment variables
 * 2. Configuration file
 * 3. Default configuration
 * 
 * @param configFilePath - Optional path to configuration file (defaults to .inventory.config.json in workspace root)
 * @returns Complete, validated configuration
 * @throws ConfigValidationError if configuration is invalid
 */
export function loadConfig(configFilePath?: string): InventoryConfig {
  // Start with defaults
  const defaults = getDefaultConfig();

  // Determine config file path
  const configFile = configFilePath || 
    path.join(defaults.workspace.root, '.inventory.config.json');

  // Load from file (if exists)
  const fileConfig = loadConfigFile(configFile);

  // Load from environment
  const envConfig = loadConfigFromEnv();

  // Merge configurations: defaults < file < env
  let merged = defaults as Partial<InventoryConfig>;
  
  if (fileConfig) {
    merged = mergeConfigs(merged, fileConfig);
  }
  
  merged = mergeConfigs(merged, envConfig);

  // Cast to full config (we know it's complete because we started with defaults)
  const finalConfig = merged as InventoryConfig;

  // Validate the final configuration
  validateConfig(finalConfig);

  return finalConfig;
}
