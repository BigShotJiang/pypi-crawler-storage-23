/**
 * Tests for Config module
 */

import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import { 
  detectWorkspaceRoot, 
  getDefaultConfig, 
  cloneConfig,
  loadConfigFile,
  loadConfigFromEnv,
  loadConfig,
  validateConfig,
  ConfigValidationError
} from './Config';
import { InventoryConfig } from '../types';

describe('Config', () => {
  describe('detectWorkspaceRoot', () => {
    const originalEnv = process.env.INVENTORY_WORKSPACE_ROOT;

    afterEach(() => {
      // Restore original environment
      if (originalEnv !== undefined) {
        process.env.INVENTORY_WORKSPACE_ROOT = originalEnv;
      } else {
        delete process.env.INVENTORY_WORKSPACE_ROOT;
      }
    });

    it('should use environment variable when set', () => {
      process.env.INVENTORY_WORKSPACE_ROOT = '/custom/workspace';
      const root = detectWorkspaceRoot();
      expect(root).toBe('/custom/workspace');
    });

    it('should normalize environment variable path', () => {
      process.env.INVENTORY_WORKSPACE_ROOT = 'C:\\Users\\test\\workspace';
      const root = detectWorkspaceRoot();
      expect(root).toBe('/mnt/c/Users/test/workspace');
    });

    it('should detect workspace root when no environment variable', () => {
      delete process.env.INVENTORY_WORKSPACE_ROOT;
      const root = detectWorkspaceRoot();
      
      // Should return a valid path (exact path depends on platform)
      expect(root).toBeTruthy();
      expect(typeof root).toBe('string');
      expect(root.length).toBeGreaterThan(0);
    });

    it('should return normalized path', () => {
      delete process.env.INVENTORY_WORKSPACE_ROOT;
      const root = detectWorkspaceRoot();
      
      // Should not have trailing slash (except root)
      if (root.length > 1) {
        expect(root.endsWith('/')).toBe(false);
      }
      
      // Should use forward slashes
      expect(root.includes('\\')).toBe(false);
    });
  });

  describe('getDefaultConfig', () => {
    it('should return a valid configuration object', () => {
      const config = getDefaultConfig();
      
      expect(config).toBeDefined();
      expect(config.workspace).toBeDefined();
      expect(config.discovery).toBeDefined();
      expect(config.service).toBeDefined();
      expect(config.database).toBeDefined();
      expect(config.cache).toBeDefined();
    });

    it('should have workspace root set', () => {
      const config = getDefaultConfig();
      
      expect(config.workspace.root).toBeTruthy();
      expect(typeof config.workspace.root).toBe('string');
      expect(config.workspace.root.length).toBeGreaterThan(0);
    });

    it('should have sensible default exclude patterns', () => {
      const config = getDefaultConfig();
      
      expect(config.workspace.excludePatterns).toContain('node_modules');
      expect(config.workspace.excludePatterns).toContain('.git');
      expect(config.workspace.excludePatterns).toContain('dist');
      expect(config.workspace.excludePatterns).toContain('build');
    });

    it('should have default include pattern', () => {
      const config = getDefaultConfig();
      
      expect(config.workspace.includePatterns).toContain('**');
    });

    it('should have discovery settings', () => {
      const config = getDefaultConfig();
      
      expect(config.discovery.maxDepth).toBe(10);
      expect(config.discovery.followSymlinks).toBe(true);
      expect(config.discovery.autoRefreshInterval).toBeUndefined();
    });

    it('should have service settings', () => {
      const config = getDefaultConfig();
      
      expect(config.service.port).toBe(3000);
      expect(config.service.host).toBe('localhost');
      expect(config.service.enableCORS).toBe(true);
      expect(config.service.authToken).toBeUndefined();
    });

    it('should have database settings', () => {
      const config = getDefaultConfig();
      
      expect(config.database.path).toBe('.inventory/inventory.db');
    });

    it('should have cache settings', () => {
      const config = getDefaultConfig();
      
      expect(config.cache.enabled).toBe(true);
      expect(config.cache.ttl).toBe(300);
    });
  });

  describe('cloneConfig', () => {
    it('should create a deep copy of config', () => {
      const original = getDefaultConfig();
      const cloned = cloneConfig(original);
      
      expect(cloned).toEqual(original);
      expect(cloned).not.toBe(original);
    });

    it('should not share array references', () => {
      const original = getDefaultConfig();
      const cloned = cloneConfig(original);
      
      // Modify cloned arrays
      cloned.workspace.excludePatterns.push('test');
      cloned.workspace.includePatterns.push('test');
      
      // Original should be unchanged
      expect(original.workspace.excludePatterns).not.toContain('test');
      expect(original.workspace.includePatterns).not.toContain('test');
    });

    it('should preserve all configuration values', () => {
      const custom: InventoryConfig = {
        workspace: {
          root: '/custom/root',
          excludePatterns: ['a', 'b'],
          includePatterns: ['c', 'd']
        },
        discovery: {
          maxDepth: 5,
          followSymlinks: false,
          autoRefreshInterval: 60
        },
        service: {
          port: 8080,
          host: '0.0.0.0',
          enableCORS: false,
          authToken: 'secret'
        },
        database: {
          path: '/custom/db.sqlite'
        },
        cache: {
          enabled: false,
          ttl: 600
        }
      };

      const cloned = cloneConfig(custom);
      
      expect(cloned).toEqual(custom);
      expect(cloned.workspace.root).toBe('/custom/root');
      expect(cloned.discovery.maxDepth).toBe(5);
      expect(cloned.discovery.followSymlinks).toBe(false);
      expect(cloned.discovery.autoRefreshInterval).toBe(60);
      expect(cloned.service.port).toBe(8080);
      expect(cloned.service.host).toBe('0.0.0.0');
      expect(cloned.service.enableCORS).toBe(false);
      expect(cloned.service.authToken).toBe('secret');
      expect(cloned.database.path).toBe('/custom/db.sqlite');
      expect(cloned.cache.enabled).toBe(false);
      expect(cloned.cache.ttl).toBe(600);
    });
  });

  describe('loadConfigFile', () => {
    let tempDir: string;

    beforeEach(() => {
      // Create a temporary directory for test files
      tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'config-test-'));
    });

    afterEach(() => {
      // Clean up temporary directory
      if (fs.existsSync(tempDir)) {
        fs.rmSync(tempDir, { recursive: true, force: true });
      }
    });

    it('should return null for non-existent file', () => {
      const result = loadConfigFile(path.join(tempDir, 'nonexistent.json'));
      expect(result).toBeNull();
    });

    it('should load valid JSON configuration', () => {
      const configPath = path.join(tempDir, 'config.json');
      const config = {
        workspace: {
          root: '/test/workspace'
        },
        service: {
          port: 8080
        }
      };

      fs.writeFileSync(configPath, JSON.stringify(config));
      const result = loadConfigFile(configPath);

      expect(result).toEqual(config);
    });

    it('should throw ConfigValidationError for invalid JSON', () => {
      const configPath = path.join(tempDir, 'invalid.json');
      fs.writeFileSync(configPath, '{ invalid json }');

      expect(() => loadConfigFile(configPath)).toThrow(ConfigValidationError);
    });

    it('should throw ConfigValidationError with descriptive message', () => {
      const configPath = path.join(tempDir, 'invalid.json');
      fs.writeFileSync(configPath, '{ invalid json }');

      try {
        loadConfigFile(configPath);
        fail('Should have thrown ConfigValidationError');
      } catch (error) {
        expect(error).toBeInstanceOf(ConfigValidationError);
        expect((error as ConfigValidationError).field).toBe('configFile');
        expect((error as ConfigValidationError).value).toBe(configPath);
        expect((error as ConfigValidationError).message).toContain('Failed to parse');
      }
    });
  });

  describe('loadConfigFromEnv', () => {
    const originalEnv = { ...process.env };

    beforeEach(() => {
      // Clear all inventory-related environment variables
      Object.keys(process.env).forEach(key => {
        if (key.startsWith('INVENTORY_')) {
          delete process.env[key];
        }
      });
    });

    afterEach(() => {
      // Restore original environment
      process.env = { ...originalEnv };
    });

    it('should return empty config when no env vars set', () => {
      const config = loadConfigFromEnv();
      expect(config).toEqual({});
    });

    it('should load workspace root from env', () => {
      process.env.INVENTORY_WORKSPACE_ROOT = '/test/workspace';
      const config = loadConfigFromEnv();
      
      expect(config.workspace?.root).toBe('/test/workspace');
    });

    it('should normalize workspace root path', () => {
      process.env.INVENTORY_WORKSPACE_ROOT = 'C:\\test\\workspace';
      const config = loadConfigFromEnv();
      
      expect(config.workspace?.root).toBe('/mnt/c/test/workspace');
    });

    it('should load exclude patterns from env', () => {
      process.env.INVENTORY_WORKSPACE_EXCLUDE = 'node_modules, .git, dist';
      const config = loadConfigFromEnv();
      
      expect(config.workspace?.excludePatterns).toEqual(['node_modules', '.git', 'dist']);
    });

    it('should load include patterns from env', () => {
      process.env.INVENTORY_WORKSPACE_INCLUDE = '**/*.ts, **/*.js';
      const config = loadConfigFromEnv();
      
      expect(config.workspace?.includePatterns).toEqual(['**/*.ts', '**/*.js']);
    });

    it('should load max depth from env', () => {
      process.env.INVENTORY_MAX_DEPTH = '5';
      const config = loadConfigFromEnv();
      
      expect(config.discovery?.maxDepth).toBe(5);
    });

    it('should throw error for invalid max depth', () => {
      process.env.INVENTORY_MAX_DEPTH = 'invalid';
      
      expect(() => loadConfigFromEnv()).toThrow(ConfigValidationError);
    });

    it('should load follow symlinks from env', () => {
      process.env.INVENTORY_FOLLOW_SYMLINKS = 'false';
      const config = loadConfigFromEnv();
      
      expect(config.discovery?.followSymlinks).toBe(false);
    });

    it('should throw error for invalid follow symlinks', () => {
      process.env.INVENTORY_FOLLOW_SYMLINKS = 'invalid';
      
      expect(() => loadConfigFromEnv()).toThrow(ConfigValidationError);
    });

    it('should load auto refresh interval from env', () => {
      process.env.INVENTORY_AUTO_REFRESH = '60';
      const config = loadConfigFromEnv();
      
      expect(config.discovery?.autoRefreshInterval).toBe(60);
    });

    it('should load service port from env', () => {
      process.env.INVENTORY_SERVICE_PORT = '8080';
      const config = loadConfigFromEnv();
      
      expect(config.service?.port).toBe(8080);
    });

    it('should throw error for invalid port', () => {
      process.env.INVENTORY_SERVICE_PORT = '99999';
      
      expect(() => loadConfigFromEnv()).toThrow(ConfigValidationError);
    });

    it('should load service host from env', () => {
      process.env.INVENTORY_SERVICE_HOST = '0.0.0.0';
      const config = loadConfigFromEnv();
      
      expect(config.service?.host).toBe('0.0.0.0');
    });

    it('should load CORS setting from env', () => {
      process.env.INVENTORY_SERVICE_CORS = 'false';
      const config = loadConfigFromEnv();
      
      expect(config.service?.enableCORS).toBe(false);
    });

    it('should load auth token from env', () => {
      process.env.INVENTORY_AUTH_TOKEN = 'secret-token';
      const config = loadConfigFromEnv();
      
      expect(config.service?.authToken).toBe('secret-token');
    });

    it('should load database path from env', () => {
      process.env.INVENTORY_DB_PATH = '/custom/db.sqlite';
      const config = loadConfigFromEnv();
      
      expect(config.database?.path).toBe('/custom/db.sqlite');
    });

    it('should load cache enabled from env', () => {
      process.env.INVENTORY_CACHE_ENABLED = 'false';
      const config = loadConfigFromEnv();
      
      expect(config.cache?.enabled).toBe(false);
    });

    it('should load cache TTL from env', () => {
      process.env.INVENTORY_CACHE_TTL = '600';
      const config = loadConfigFromEnv();
      
      expect(config.cache?.ttl).toBe(600);
    });

    it('should throw error for negative cache TTL', () => {
      process.env.INVENTORY_CACHE_TTL = '-1';
      
      expect(() => loadConfigFromEnv()).toThrow(ConfigValidationError);
    });
  });

  describe('validateConfig', () => {
    it('should validate a valid configuration', () => {
      const config = getDefaultConfig();
      expect(() => validateConfig(config)).not.toThrow();
    });

    it('should throw error for missing workspace root', () => {
      const config = getDefaultConfig();
      (config.workspace as any).root = '';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for non-array exclude patterns', () => {
      const config = getDefaultConfig();
      (config.workspace as any).excludePatterns = 'not-an-array';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for empty include patterns', () => {
      const config = getDefaultConfig();
      config.workspace.includePatterns = [];
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for invalid max depth', () => {
      const config = getDefaultConfig();
      (config.discovery as any).maxDepth = 0;
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for non-boolean follow symlinks', () => {
      const config = getDefaultConfig();
      (config.discovery as any).followSymlinks = 'true';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for negative auto refresh interval', () => {
      const config = getDefaultConfig();
      config.discovery.autoRefreshInterval = -1;
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for invalid port', () => {
      const config = getDefaultConfig();
      config.service.port = 99999;
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for missing host', () => {
      const config = getDefaultConfig();
      (config.service as any).host = '';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for non-boolean CORS', () => {
      const config = getDefaultConfig();
      (config.service as any).enableCORS = 'true';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for non-string auth token', () => {
      const config = getDefaultConfig();
      (config.service as any).authToken = 123;
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for empty database path', () => {
      const config = getDefaultConfig();
      config.database.path = '';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for non-boolean cache enabled', () => {
      const config = getDefaultConfig();
      (config.cache as any).enabled = 'true';
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });

    it('should throw error for negative cache TTL', () => {
      const config = getDefaultConfig();
      config.cache.ttl = -1;
      
      expect(() => validateConfig(config)).toThrow(ConfigValidationError);
    });
  });

  describe('loadConfig', () => {
    let tempDir: string;
    const originalEnv = { ...process.env };

    beforeEach(() => {
      // Create a temporary directory for test files
      tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'config-test-'));
      
      // Clear all inventory-related environment variables
      Object.keys(process.env).forEach(key => {
        if (key.startsWith('INVENTORY_')) {
          delete process.env[key];
        }
      });
    });

    afterEach(() => {
      // Clean up temporary directory
      if (fs.existsSync(tempDir)) {
        fs.rmSync(tempDir, { recursive: true, force: true });
      }
      
      // Restore original environment
      process.env = { ...originalEnv };
    });

    it('should load default config when no file or env vars', () => {
      const config = loadConfig(path.join(tempDir, 'nonexistent.json'));
      const defaults = getDefaultConfig();
      
      expect(config).toEqual(defaults);
    });

    it('should merge file config with defaults', () => {
      const configPath = path.join(tempDir, 'config.json');
      const fileConfig = {
        service: {
          port: 8080
        }
      };

      fs.writeFileSync(configPath, JSON.stringify(fileConfig));
      const config = loadConfig(configPath);

      expect(config.service.port).toBe(8080);
      expect(config.service.host).toBe('localhost'); // From defaults
    });

    it('should merge env config with file and defaults', () => {
      const configPath = path.join(tempDir, 'config.json');
      const fileConfig = {
        service: {
          port: 8080,
          host: 'file-host'
        }
      };

      fs.writeFileSync(configPath, JSON.stringify(fileConfig));
      process.env.INVENTORY_SERVICE_PORT = '9090';

      const config = loadConfig(configPath);

      expect(config.service.port).toBe(9090); // From env (highest priority)
      expect(config.service.host).toBe('file-host'); // From file
    });

    it('should validate merged configuration', () => {
      const configPath = path.join(tempDir, 'config.json');
      const fileConfig = {
        service: {
          port: 99999 // Invalid port
        }
      };

      fs.writeFileSync(configPath, JSON.stringify(fileConfig));

      expect(() => loadConfig(configPath)).toThrow(ConfigValidationError);
    });

    it('should handle partial file configuration', () => {
      const configPath = path.join(tempDir, 'config.json');
      const fileConfig = {
        workspace: {
          excludePatterns: ['custom-exclude']
        }
      };

      fs.writeFileSync(configPath, JSON.stringify(fileConfig));
      const config = loadConfig(configPath);

      expect(config.workspace.excludePatterns).toEqual(['custom-exclude']);
      expect(config.workspace.root).toBeTruthy(); // From defaults
      expect(config.workspace.includePatterns).toEqual(['**']); // From defaults
    });
  });
});
