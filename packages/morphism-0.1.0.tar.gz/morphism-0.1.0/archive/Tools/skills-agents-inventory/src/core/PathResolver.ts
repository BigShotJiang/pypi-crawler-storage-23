/**
 * PathResolver - Cross-platform path resolution for Windows, WSL, and Linux
 * 
 * Handles path normalization and conversion between different path formats:
 * - Windows: C:\Users\mesha\...
 * - Linux: /home/meshal/...
 * - WSL: /mnt/c/Users/mesha/...
 * 
 * Canonical format is Linux-style with forward slashes.
 */

export type PathFormat = 'windows' | 'linux' | 'wsl' | 'unknown';

export class PathResolver {
  // Pattern matching for path format detection
  private static readonly WINDOWS_PATTERN = /^[A-Za-z]:[\\\/]/;
  private static readonly LINUX_PATTERN = /^\/(?!mnt\/[a-z]\/)/;
  private static readonly WSL_PATTERN = /^\/mnt\/[a-z]\//;

  /**
   * Detect the format of a given path
   */
  static detectFormat(path: string): PathFormat {
    if (!path || path.trim() === '') {
      return 'unknown';
    }

    const normalized = path.trim();

    if (this.WSL_PATTERN.test(normalized)) {
      return 'wsl';
    }
    if (this.WINDOWS_PATTERN.test(normalized)) {
      return 'windows';
    }
    if (this.LINUX_PATTERN.test(normalized)) {
      return 'linux';
    }

    return 'unknown';
  }

  /**
   * Check if path is in Windows format
   */
  static isWindows(path: string): boolean {
    return this.detectFormat(path) === 'windows';
  }

  /**
   * Check if path is in Linux format
   */
  static isLinux(path: string): boolean {
    return this.detectFormat(path) === 'linux';
  }

  /**
   * Check if path is in WSL format
   */
  static isWSL(path: string): boolean {
    return this.detectFormat(path) === 'wsl';
  }

  /**
   * Normalize path to canonical format (Linux-style with forward slashes)
   * 
   * Normalization rules:
   * - Windows (C:\Users\...) -> /mnt/c/Users/...
   * - WSL (/mnt/c/Users/...) -> /mnt/c/Users/...
   * - Linux (/home/...) -> /home/...
   * - All backslashes converted to forward slashes
   * - Multiple consecutive slashes collapsed to single slash
   * - Trailing slashes removed (except for root)
   */
  static normalize(path: string): string {
    if (!path || path.trim() === '') {
      return '';
    }

    let normalized = path.trim();
    const format = this.detectFormat(normalized);

    // Convert Windows path to WSL format
    if (format === 'windows') {
      // Extract drive letter and path
      const match = normalized.match(/^([A-Za-z]):[\\\/](.*)$/);
      if (match) {
        const drive = match[1].toLowerCase();
        const pathPart = match[2];
        normalized = `/mnt/${drive}/${pathPart}`;
      }
    }

    // Convert all backslashes to forward slashes
    normalized = normalized.replace(/\\/g, '/');

    // Collapse multiple consecutive slashes
    normalized = normalized.replace(/\/+/g, '/');

    // Remove trailing slash (except for root)
    if (normalized.length > 1 && normalized.endsWith('/')) {
      normalized = normalized.slice(0, -1);
    }

    return normalized;
  }

  /**
   * Convert path to Windows format (C:\Users\...)
   */
  static toWindows(path: string): string {
    const normalized = this.normalize(path);
    
    if (!normalized) {
      return '';
    }

    // Check if it's a WSL path that can be converted
    const wslMatch = normalized.match(/^\/mnt\/([a-z])\/(.*)$/);
    if (wslMatch) {
      const drive = wslMatch[1].toUpperCase();
      const pathPart = wslMatch[2];
      return `${drive}:\\${pathPart.replace(/\//g, '\\')}`;
    }

    // If it's already a Linux path (not WSL), return as-is
    // (can't convert native Linux paths to Windows)
    return normalized;
  }

  /**
   * Convert path to Linux format (/home/...)
   * 
   * Note: This converts WSL paths to their Windows equivalent first,
   * then to Linux. Pure Linux paths are returned as-is.
   */
  static toLinux(path: string): string {
    const normalized = this.normalize(path);
    
    if (!normalized) {
      return '';
    }

    // WSL paths are already in Linux-style format
    // Pure Linux paths are already correct
    return normalized;
  }

  /**
   * Convert path to WSL format (/mnt/c/...)
   */
  static toWSL(path: string): string {
    const normalized = this.normalize(path);
    
    if (!normalized) {
      return '';
    }

    // If already in WSL format, return as-is
    if (this.WSL_PATTERN.test(normalized)) {
      return normalized;
    }

    // If it's a Windows path, normalize() already converted it to WSL
    const format = this.detectFormat(path);
    if (format === 'windows') {
      return normalized;
    }

    // Pure Linux paths can't be converted to WSL format
    return normalized;
  }
}
