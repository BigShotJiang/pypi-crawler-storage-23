import { ReadmeExtractor } from './ReadmeExtractor';
import { MetadataExtractionError } from './MetadataExtractor';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { mkdtemp, rm } from 'node:fs/promises';

describe('ReadmeExtractor', () => {
  let extractor: ReadmeExtractor;
  let tempDir: string;

  beforeEach(async () => {
    extractor = new ReadmeExtractor();
    tempDir = await mkdtemp(join(tmpdir(), 'readme-extractor-test-'));
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true, force: true });
  });

  describe('canExtract', () => {
    it('should accept README.md', () => {
      expect(extractor.canExtract('/path/to/README.md')).toBe(true);
    });

    it('should accept readme.md (lowercase)', () => {
      expect(extractor.canExtract('/path/to/readme.md')).toBe(true);
    });

    it('should accept README.markdown', () => {
      expect(extractor.canExtract('/path/to/README.markdown')).toBe(true);
    });

    it('should accept README.txt', () => {
      expect(extractor.canExtract('/path/to/README.txt')).toBe(true);
    });

    it('should accept README (no extension)', () => {
      expect(extractor.canExtract('/path/to/README')).toBe(true);
    });

    it('should reject non-README files', () => {
      expect(extractor.canExtract('/path/to/package.json')).toBe(false);
      expect(extractor.canExtract('/path/to/index.ts')).toBe(false);
      expect(extractor.canExtract('/path/to/CHANGELOG.md')).toBe(false);
    });
  });

  describe('extract', () => {
    it('should extract first paragraph from simple README', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# My Project

This is the first paragraph describing the project.

This is the second paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first paragraph describing the project.');
    });

    it('should skip headers and extract first paragraph', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Title

## Subtitle

### Another Header

This is the actual first paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the actual first paragraph.');
    });

    it('should skip badges and extract first paragraph', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

![Build Status](https://img.shields.io/badge/build-passing-green)
![Coverage](https://img.shields.io/badge/coverage-100%25-green)

This is the first real paragraph after badges.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first real paragraph after badges.');
    });

    it('should skip code blocks and extract first paragraph', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

\`\`\`bash
npm install
\`\`\`

This is the first paragraph after the code block.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first paragraph after the code block.');
    });

    it('should join multi-line paragraphs', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

This is a paragraph
that spans multiple
lines in the source.

Second paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is a paragraph that spans multiple lines in the source.');
    });

    it('should clean markdown formatting', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

This is **bold** and *italic* text with \`code\` and a [link](https://example.com).`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is bold and italic text with code and a link.');
    });

    it('should handle README with only headers', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Title

## Subtitle

### Another Header`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBeUndefined();
    });

    it('should handle empty README', async () => {
      const readmePath = join(tempDir, 'README.md');
      await fs.writeFile(readmePath, '', 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBeUndefined();
    });

    it('should handle README with only whitespace', async () => {
      const readmePath = join(tempDir, 'README.md');
      await fs.writeFile(readmePath, '\n\n\n   \n\n', 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBeUndefined();
    });

    it('should skip HTML comments', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

<!-- This is a comment -->

This is the first paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first paragraph.');
    });

    it('should skip horizontal rules', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

---

This is the first paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first paragraph.');
    });

    it('should handle complex markdown with multiple formatting', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Skills & Agents Inventory

![Build](https://img.shields.io/badge/build-passing-green)

The **Skills & Agents Inventory System** provides *automated discovery*, \`indexing\`, and [online deployment](https://example.com) of skills, agents, and CLI tools.

## Features

- Feature 1
- Feature 2`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe(
        'The Skills & Agents Inventory System provides automated discovery, indexing, and online deployment of skills, agents, and CLI tools.'
      );
    });

    it('should throw MetadataExtractionError for non-existent file', async () => {
      const readmePath = join(tempDir, 'nonexistent.md');

      await expect(extractor.extract(readmePath)).rejects.toThrow(MetadataExtractionError);
    });

    it('should handle README with metadata lines', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

Version: 1.0.0
Author: John Doe
License: MIT

This is the first real paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first real paragraph.');
    });

    it('should handle README with nested code blocks', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

\`\`\`typescript
function example() {
  console.log("test");
}
\`\`\`

\`\`\`bash
npm install
\`\`\`

This is the first paragraph after multiple code blocks.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is the first paragraph after multiple code blocks.');
    });

    it('should handle README with inline HTML', async () => {
      const readmePath = join(tempDir, 'README.md');
      const content = `# Project

This is a paragraph with <strong>HTML tags</strong> and <em>inline elements</em>.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is a paragraph with HTML tags and inline elements.');
    });

    it('should handle README.txt plain text files', async () => {
      const readmePath = join(tempDir, 'README.txt');
      const content = `My Project

This is a plain text README file.

Second paragraph.`;

      await fs.writeFile(readmePath, content, 'utf-8');

      const metadata = await extractor.extract(readmePath);

      expect(metadata.summary).toBe('This is a plain text README file.');
    });
  });
});
