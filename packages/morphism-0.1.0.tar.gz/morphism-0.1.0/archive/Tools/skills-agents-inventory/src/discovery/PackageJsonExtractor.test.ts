import { PackageJsonExtractor } from './PackageJsonExtractor';
import { MetadataExtractionError } from './MetadataExtractor';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { mkdtemp, rm } from 'node:fs/promises';

describe('PackageJsonExtractor', () => {
  let extractor: PackageJsonExtractor;
  let tempDir: string;

  beforeEach(async () => {
    extractor = new PackageJsonExtractor();
    tempDir = await mkdtemp(join(tmpdir(), 'package-json-test-'));
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true, force: true });
  });

  describe('canExtract', () => {
    it('should return true for package.json files', () => {
      expect(extractor.canExtract('/path/to/package.json')).toBe(true);
      expect(extractor.canExtract('/path/to/PACKAGE.JSON')).toBe(true);
      expect(extractor.canExtract('package.json')).toBe(true);
    });

    it('should return false for non-package.json files', () => {
      expect(extractor.canExtract('/path/to/other.json')).toBe(false);
      expect(extractor.canExtract('/path/to/package.txt')).toBe(false);
      expect(extractor.canExtract('/path/to/package-lock.json')).toBe(false);
    });
  });

  describe('extract', () => {
    it('should extract basic metadata from valid package.json', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        description: 'A test package',
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('test-package');
      expect(metadata.version).toBe('1.0.0');
      expect(metadata.description).toBe('A test package');
    });

    it('should extract dependencies from package.json', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        dependencies: {
          'express': '^4.18.0',
          'lodash': '^4.17.21',
        },
        devDependencies: {
          'jest': '^29.0.0',
          'typescript': '^5.0.0',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.dependencies).toEqual({
        'express': '^4.18.0',
        'lodash': '^4.17.21',
        'jest': '^29.0.0',
        'typescript': '^5.0.0',
      });
    });

    it('should detect TypeScript as language when typescript is a dependency', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        devDependencies: {
          'typescript': '^5.0.0',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('TypeScript');
    });

    it('should detect JavaScript (ESM) when type is module', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        type: 'module',
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('JavaScript (ESM)');
    });

    it('should default to JavaScript when no language indicators present', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('JavaScript');
    });

    it('should extract keywords as capabilities', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        keywords: ['testing', 'automation', 'cli'],
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.capabilities).toEqual(['testing', 'automation', 'cli']);
    });

    it('should filter out non-string keywords', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        keywords: ['valid', 123, null, 'another-valid', ''],
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.capabilities).toEqual(['valid', 'another-valid']);
    });

    it('should extract custom fields (author, license, repository, homepage)', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        author: 'John Doe',
        license: 'MIT',
        repository: 'https://github.com/user/repo',
        homepage: 'https://example.com',
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.author).toBe('John Doe');
      expect(metadata.customFields?.license).toBe('MIT');
      expect(metadata.customFields?.repository).toBe('https://github.com/user/repo');
      expect(metadata.customFields?.homepage).toBe('https://example.com');
    });

    it('should handle author as object', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        author: {
          name: 'John Doe',
          email: 'john@example.com',
          url: 'https://johndoe.com',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.author).toBe('John Doe');
    });

    it('should handle repository as object', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        repository: {
          type: 'git',
          url: 'https://github.com/user/repo.git',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.repository).toBe('https://github.com/user/repo.git');
    });

    it('should extract bin commands', async () => {
      const packageJson = {
        name: 'test-cli',
        version: '1.0.0',
        bin: {
          'test-cli': './bin/cli.js',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.bin).toEqual({
        'test-cli': './bin/cli.js',
      });
    });

    it('should extract scripts', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        scripts: {
          'test': 'jest',
          'build': 'tsc',
          'start': 'node dist/index.js',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.scripts).toEqual({
        'test': 'jest',
        'build': 'tsc',
        'start': 'node dist/index.js',
      });
    });

    it('should handle minimal package.json with only name', async () => {
      const packageJson = {
        name: 'minimal-package',
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('minimal-package');
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.language).toBe('JavaScript');
    });

    it('should handle empty package.json', async () => {
      const packageJson = {};

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBeUndefined();
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
    });

    it('should throw MetadataExtractionError for malformed JSON', async () => {
      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, '{ invalid json }');

      await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
      await expect(extractor.extract(filePath)).rejects.toThrow(/Invalid JSON/);
    });

    it('should throw MetadataExtractionError for non-existent file', async () => {
      const filePath = join(tempDir, 'non-existent-package.json');

      await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
    });

    it('should handle package.json with unexpected field types gracefully', async () => {
      const packageJson = {
        name: 123, // Should be string
        version: ['1.0.0'], // Should be string
        description: { text: 'description' }, // Should be string
        dependencies: 'not-an-object', // Should be object
        keywords: 'not-an-array', // Should be array
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      // Should handle gracefully with undefined values
      expect(metadata.name).toBeUndefined();
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.dependencies).toBeUndefined();
      expect(metadata.capabilities).toBeUndefined();
    });

    it('should handle package.json with null values', async () => {
      const packageJson = {
        name: 'test-package',
        version: null,
        description: null,
        dependencies: null,
        keywords: null,
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('test-package');
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.dependencies).toBeUndefined();
      expect(metadata.capabilities).toBeUndefined();
    });

    it('should prioritize TypeScript over ESM detection', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        type: 'module',
        devDependencies: {
          'typescript': '^5.0.0',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('TypeScript');
    });

    it('should detect TypeScript from @types/node dependency', async () => {
      const packageJson = {
        name: 'test-package',
        version: '1.0.0',
        devDependencies: {
          '@types/node': '^20.0.0',
        },
      };

      const filePath = join(tempDir, 'package.json');
      await fs.writeFile(filePath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('TypeScript');
    });
  });
});
