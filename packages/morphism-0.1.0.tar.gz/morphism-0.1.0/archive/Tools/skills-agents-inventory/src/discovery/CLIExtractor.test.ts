import { CLIExtractor } from './CLIExtractor';
import { MetadataExtractionError } from './MetadataExtractor';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { mkdtemp, rm, writeFile, chmod } from 'node:fs/promises';

describe('CLIExtractor', () => {
  let extractor: CLIExtractor;
  let tempDir: string;

  beforeEach(async () => {
    extractor = new CLIExtractor();
    // Create a temporary directory for test files
    tempDir = await mkdtemp(join(tmpdir(), 'cli-extractor-test-'));
  });

  afterEach(async () => {
    // Clean up temporary directory
    await rm(tempDir, { recursive: true, force: true });
  });

  describe('canExtract', () => {
    it('should return true for cli.json files', () => {
      expect(extractor.canExtract('/path/to/cli.json')).toBe(true);
      expect(extractor.canExtract('/path/to/CLI.json')).toBe(true);
    });

    it('should return true for package.json files', () => {
      expect(extractor.canExtract('/path/to/package.json')).toBe(true);
    });

    it('should return true for files in bin/ directories', () => {
      expect(extractor.canExtract('/path/to/bin/mycli.js')).toBe(true);
      expect(extractor.canExtract('/path/to/bin/tool.ts')).toBe(true);
      expect(extractor.canExtract('/path/to/bin/script.py')).toBe(true);
      expect(extractor.canExtract('/path/to/bin/run.sh')).toBe(true);
    });

    it('should return false for non-CLI files', () => {
      expect(extractor.canExtract('/path/to/README.md')).toBe(false);
      expect(extractor.canExtract('/path/to/src/index.ts')).toBe(false);
      expect(extractor.canExtract('/path/to/config.yaml')).toBe(false);
    });
  });

  describe('extract - cli.json', () => {
    it('should extract metadata from valid cli.json', async () => {
      const cliJsonPath = join(tempDir, 'cli.json');
      const cliConfig = {
        name: 'my-cli',
        version: '1.0.0',
        description: 'A sample CLI tool',
        language: 'TypeScript',
        entryPoint: './bin/cli.js',
        commands: [
          {
            name: 'start',
            description: 'Start the service',
            arguments: [
              {
                name: 'port',
                description: 'Port number',
                required: true,
                type: 'number',
              },
            ],
          },
          {
            name: 'stop',
            description: 'Stop the service',
          },
        ],
        usage: 'my-cli <command> [options]',
        examples: ['my-cli start --port 3000', 'my-cli stop'],
      };

      await writeFile(cliJsonPath, JSON.stringify(cliConfig, null, 2));

      const metadata = await extractor.extract(cliJsonPath);

      expect(metadata.name).toBe('my-cli');
      expect(metadata.version).toBe('1.0.0');
      expect(metadata.description).toBe('A sample CLI tool');
      expect(metadata.language).toBe('TypeScript');
      expect(metadata.commands).toHaveLength(2);
      expect(metadata.commands?.[0]).toEqual({
        name: 'start',
        description: 'Start the service',
        arguments: [
          {
            name: 'port',
            description: 'Port number',
            required: true,
            type: 'number',
          },
        ],
      });
      expect(metadata.commands?.[1]).toEqual({
        name: 'stop',
        description: 'Stop the service',
      });
      expect(metadata.capabilities).toEqual(['start', 'stop']);
      expect(metadata.customFields?.entryPoint).toBe('./bin/cli.js');
      expect(metadata.customFields?.usage).toBe('my-cli <command> [options]');
      expect(metadata.customFields?.examples).toEqual([
        'my-cli start --port 3000',
        'my-cli stop',
      ]);
    });

    it('should handle cli.json with minimal fields', async () => {
      const cliJsonPath = join(tempDir, 'cli.json');
      const cliConfig = {
        name: 'simple-cli',
      };

      await writeFile(cliJsonPath, JSON.stringify(cliConfig));

      const metadata = await extractor.extract(cliJsonPath);

      expect(metadata.name).toBe('simple-cli');
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.commands).toBeUndefined();
    });

    it('should handle malformed cli.json gracefully', async () => {
      const cliJsonPath = join(tempDir, 'cli.json');
      await writeFile(cliJsonPath, '{ invalid json }');

      await expect(extractor.extract(cliJsonPath)).rejects.toThrow(MetadataExtractionError);
    });

    it('should filter out invalid commands', async () => {
      const cliJsonPath = join(tempDir, 'cli.json');
      const cliConfig = {
        name: 'test-cli',
        commands: [
          { name: 'valid', description: 'Valid command' },
          { description: 'Missing name' }, // Invalid - no name
          'invalid-string', // Invalid - not an object
          { name: 'another-valid', description: 'Another valid command' },
        ],
      };

      await writeFile(cliJsonPath, JSON.stringify(cliConfig));

      const metadata = await extractor.extract(cliJsonPath);

      expect(metadata.commands).toHaveLength(2);
      expect(metadata.commands?.[0].name).toBe('valid');
      expect(metadata.commands?.[1].name).toBe('another-valid');
    });
  });

  describe('extract - package.json with bin', () => {
    it('should extract CLI metadata from package.json with single bin', async () => {
      const packageJsonPath = join(tempDir, 'package.json');
      const packageJson = {
        name: 'my-package',
        version: '2.0.0',
        description: 'A package with CLI',
        bin: './bin/cli.js',
      };

      await writeFile(packageJsonPath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(packageJsonPath);

      expect(metadata.name).toBe('my-package');
      expect(metadata.version).toBe('2.0.0');
      expect(metadata.description).toBe('A package with CLI');
      expect(metadata.language).toBe('JavaScript');
      expect(metadata.commands).toHaveLength(1);
      expect(metadata.commands?.[0].name).toBe('my-package');
      expect(metadata.capabilities).toEqual(['my-package']);
      expect(metadata.customFields?.bin).toBe('./bin/cli.js');
    });

    it('should extract CLI metadata from package.json with multiple bins', async () => {
      const packageJsonPath = join(tempDir, 'package.json');
      const packageJson = {
        name: 'multi-cli',
        version: '1.5.0',
        description: 'Multiple CLI commands',
        bin: {
          'cli-one': './bin/one.js',
          'cli-two': './bin/two.js',
          'cli-three': './bin/three.js',
        },
      };

      await writeFile(packageJsonPath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(packageJsonPath);

      expect(metadata.name).toBe('multi-cli');
      expect(metadata.commands).toHaveLength(3);
      expect(metadata.commands?.map(c => c.name)).toEqual(['cli-one', 'cli-two', 'cli-three']);
      expect(metadata.capabilities).toEqual(['cli-one', 'cli-two', 'cli-three']);
    });

    it('should return empty metadata for package.json without bin', async () => {
      const packageJsonPath = join(tempDir, 'package.json');
      const packageJson = {
        name: 'no-cli',
        version: '1.0.0',
        description: 'No CLI here',
      };

      await writeFile(packageJsonPath, JSON.stringify(packageJson));

      const metadata = await extractor.extract(packageJsonPath);

      expect(metadata).toEqual({});
    });
  });

  describe('extract - executable scripts', () => {
    it('should extract basic metadata from non-executable script', async () => {
      const scriptPath = join(tempDir, 'bin', 'script.js');
      await fs.mkdir(join(tempDir, 'bin'), { recursive: true });
      await writeFile(scriptPath, '#!/usr/bin/env node\nconsole.log("Hello");');

      const metadata = await extractor.extract(scriptPath);

      expect(metadata.name).toBe('script');
      expect(metadata.language).toBe('JavaScript');
    });

    it('should detect language from file extension', async () => {
      const testCases = [
        { file: 'script.js', language: 'JavaScript' },
        { file: 'script.ts', language: 'TypeScript' },
        { file: 'script.py', language: 'Python' },
        { file: 'script.sh', language: 'Shell' },
        { file: 'script.rb', language: 'Ruby' },
        { file: 'script.go', language: 'Go' },
        { file: 'script.rs', language: 'Rust' },
        { file: 'script.unknown', language: 'Unknown' },
      ];

      for (const { file, language } of testCases) {
        const scriptPath = join(tempDir, 'bin', file);
        await fs.mkdir(join(tempDir, 'bin'), { recursive: true });
        await writeFile(scriptPath, '#!/usr/bin/env node\n');

        const metadata = await extractor.extract(scriptPath);

        expect(metadata.language).toBe(language);
      }
    });

    // Note: Testing executable scripts with --help is platform-dependent and may not work in all environments
    // These tests are skipped by default but can be enabled for local testing
    it.skip('should parse help output from executable script', async () => {
      const scriptPath = join(tempDir, 'bin', 'mycli.sh');
      await fs.mkdir(join(tempDir, 'bin'), { recursive: true });
      
      const scriptContent = `#!/bin/bash
if [ "$1" = "--help" ]; then
  echo "My CLI Tool - A sample command-line tool"
  echo ""
  echo "Usage: mycli <command>"
  echo ""
  echo "Commands:"
  echo "  start    Start the service"
  echo "  stop     Stop the service"
  echo "  status   Check service status"
fi
`;
      
      await writeFile(scriptPath, scriptContent);
      await chmod(scriptPath, 0o755);

      const metadata = await extractor.extract(scriptPath);

      expect(metadata.name).toBe('mycli');
      expect(metadata.description).toContain('sample command-line tool');
      expect(metadata.commands).toBeDefined();
      expect(metadata.commands?.length).toBeGreaterThan(0);
    });
  });

  describe('parseHelpOutput', () => {
    it('should parse help output with description and commands', () => {
      const helpOutput = `
My CLI Tool - A powerful command-line interface

Usage: mycli <command> [options]

Commands:
  start      Start the application
  stop       Stop the application
  restart    Restart the application
  status     Check application status

Options:
  --help     Show help
  --version  Show version
`;

      // Access private method via type assertion for testing
      const result = (extractor as any).parseHelpOutput(helpOutput);

      expect(result.description).toContain('powerful command-line interface');
      expect(result.commands).toHaveLength(4);
      expect(result.commands[0]).toEqual({
        name: 'start',
        description: 'Start the application',
      });
      expect(result.commands[3]).toEqual({
        name: 'status',
        description: 'Check application status',
      });
    });

    it('should handle help output without commands section', () => {
      const helpOutput = `
Simple CLI Tool

Usage: simple-cli [options]

Options:
  --help     Show help
`;

      const result = (extractor as any).parseHelpOutput(helpOutput);

      expect(result.description).toContain('Simple CLI Tool');
      expect(result.commands).toBeUndefined();
    });

    it('should handle empty help output', () => {
      const helpOutput = '';

      const result = (extractor as any).parseHelpOutput(helpOutput);

      expect(result.description).toBeUndefined();
      expect(result.commands).toBeUndefined();
    });
  });

  describe('error handling', () => {
    it('should throw MetadataExtractionError for non-existent file', async () => {
      const nonExistentPath = join(tempDir, 'does-not-exist.json');

      await expect(extractor.extract(nonExistentPath)).rejects.toThrow(MetadataExtractionError);
    });

    it('should throw MetadataExtractionError with path information', async () => {
      const invalidPath = join(tempDir, 'cli.json');
      await writeFile(invalidPath, '{ invalid }');

      await expect(extractor.extract(invalidPath)).rejects.toThrow(MetadataExtractionError);
      
      try {
        await extractor.extract(invalidPath);
      } catch (error) {
        expect(error).toBeInstanceOf(MetadataExtractionError);
        expect((error as MetadataExtractionError).path).toBe(invalidPath);
        expect((error as MetadataExtractionError).message).toContain('cli.json');
      }
    });
  });
});
