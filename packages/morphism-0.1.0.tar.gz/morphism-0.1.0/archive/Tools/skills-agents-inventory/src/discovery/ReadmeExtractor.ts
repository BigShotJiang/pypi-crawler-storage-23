import { MetadataExtractor, MetadataExtractionError } from './MetadataExtractor';
import { ComponentMetadata } from '../types';
import { basename } from 'node:path';

/**
 * Extracts metadata from README.md files.
 * Extracts the first paragraph as a summary.
 */
export class ReadmeExtractor extends MetadataExtractor {
  protected readonly supportedExtensions = ['.md', '.markdown', '.txt'];

  /**
   * Check if the file is a README file.
   * @param path Absolute path to the file
   * @returns True if the file is a README file
   */
  canExtract(path: string): boolean {
    const filename = basename(path).toLowerCase();
    return filename.startsWith('readme');
  }

  /**
   * Extract metadata from README file.
   * @param path Absolute path to README file
   * @returns Partial ComponentMetadata with summary
   */
  protected async extractImpl(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      const content = await this.readTextFile(path);
      const summary = this.extractFirstParagraph(content);

      return {
        summary: summary || undefined,
      };
    } catch (error) {
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from README: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Extract the first paragraph from markdown content.
   * Skips headers, code blocks, and empty lines to find the first text paragraph.
   * @param content Markdown content
   * @returns First paragraph text or null if not found
   */
  private extractFirstParagraph(content: string): string | null {
    const lines = content.split('\n');
    let inCodeBlock = false;
    let paragraphLines: string[] = [];
    let foundParagraph = false;
    let lineIndex = 0;
    let skippedFirstLine = false;

    for (const line of lines) {
      const trimmed = line.trim();

      // Track code block state
      if (trimmed.startsWith('```')) {
        inCodeBlock = !inCodeBlock;
        lineIndex++;
        continue;
      }

      // Skip lines inside code blocks
      if (inCodeBlock) {
        lineIndex++;
        continue;
      }

      // Skip headers (lines starting with #)
      if (trimmed.startsWith('#')) {
        lineIndex++;
        continue;
      }

      // Skip horizontal rules
      if (/^[-*_]{3,}$/.test(trimmed)) {
        lineIndex++;
        continue;
      }

      // Empty line - if we've collected paragraph lines, we're done
      if (trimmed === '') {
        if (paragraphLines.length > 0) {
          foundParagraph = true;
          break;
        }
        lineIndex++;
        continue;
      }

      // Skip lines that look like metadata or badges
      if (this.isMetadataOrBadge(trimmed)) {
        lineIndex++;
        continue;
      }

      // Skip single-line header at the beginning of plain text files
      // (first non-empty line followed by an empty line)
      if (lineIndex === 0 && !skippedFirstLine && lines.length > lineIndex + 1) {
        const nextLine = lines[lineIndex + 1].trim();
        if (nextLine === '') {
          // This looks like a plain text header, skip it
          skippedFirstLine = true;
          lineIndex++;
          continue;
        }
      }

      // Collect paragraph lines
      paragraphLines.push(trimmed);
      lineIndex++;
    }

    if (paragraphLines.length === 0) {
      return null;
    }

    // Join lines and clean up markdown formatting
    let paragraph = paragraphLines.join(' ');
    paragraph = this.cleanMarkdown(paragraph);

    return paragraph.trim() || null;
  }

  /**
   * Check if a line is metadata or a badge.
   * @param line Trimmed line content
   * @returns True if the line is metadata or a badge
   */
  private isMetadataOrBadge(line: string): boolean {
    // Badge patterns (shields.io, etc.)
    if (line.includes('![') && line.includes('](')) {
      return true;
    }

    // HTML comments
    if (line.startsWith('<!--') || line.startsWith('-->')) {
      return true;
    }

    // Common metadata patterns
    if (line.match(/^(version|author|license|status):/i)) {
      return true;
    }

    return false;
  }

  /**
   * Clean markdown formatting from text.
   * Removes links, bold, italic, code, etc.
   * @param text Text with markdown formatting
   * @returns Plain text
   */
  private cleanMarkdown(text: string): string {
    let cleaned = text;

    // Remove inline code
    cleaned = cleaned.replace(/`([^`]+)`/g, '$1');

    // Remove links but keep text: [text](url) -> text
    cleaned = cleaned.replace(/\[([^\]]+)\]\([^)]+\)/g, '$1');

    // Remove bold/italic: **text** or *text* -> text
    cleaned = cleaned.replace(/\*\*([^*]+)\*\*/g, '$1');
    cleaned = cleaned.replace(/\*([^*]+)\*/g, '$1');
    cleaned = cleaned.replace(/__([^_]+)__/g, '$1');
    cleaned = cleaned.replace(/_([^_]+)_/g, '$1');

    // Remove HTML tags
    cleaned = cleaned.replace(/<[^>]+>/g, '');

    // Normalize whitespace
    cleaned = cleaned.replace(/\s+/g, ' ');

    return cleaned;
  }
}
