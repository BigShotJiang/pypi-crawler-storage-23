import { AgentConfigExtractor } from './AgentConfigExtractor';
import { MetadataExtractionError } from './MetadataExtractor';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { mkdtemp, rm } from 'node:fs/promises';

describe('AgentConfigExtractor', () => {
  let extractor: AgentConfigExtractor;
  let tempDir: string;

  beforeEach(async () => {
    extractor = new AgentConfigExtractor();
    tempDir = await mkdtemp(join(tmpdir(), 'agent-config-test-'));
  });

  afterEach(async () => {
    await rm(tempDir, { recursive: true, force: true });
  });

  describe('canExtract', () => {
    it('should return true for agent.json files', () => {
      expect(extractor.canExtract('/path/to/agent.json')).toBe(true);
      expect(extractor.canExtract('/path/to/AGENT.JSON')).toBe(true);
      expect(extractor.canExtract('agent.json')).toBe(true);
    });

    it('should return false for non-agent.json files', () => {
      expect(extractor.canExtract('/path/to/other.json')).toBe(false);
      expect(extractor.canExtract('/path/to/agent.txt')).toBe(false);
      expect(extractor.canExtract('/path/to/package.json')).toBe(false);
      expect(extractor.canExtract('/path/to/agent-config.json')).toBe(false);
    });
  });

  describe('extract', () => {
    it('should extract basic metadata from valid agent.json', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        description: 'A test agent for verification',
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('test-agent');
      expect(metadata.version).toBe('1.0.0');
      expect(metadata.description).toBe('A test agent for verification');
    });

    it('should extract skills as capabilities', async () => {
      const agentConfig = {
        name: 'proof-verifier-agent',
        version: '1.0.0',
        description: 'Converts informal proofs to Lean and verifies them',
        skills: [
          'lean-synthesis',
          'proof-sketch-to-formal',
          'counterexample-finder',
        ],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.capabilities).toEqual([
        'lean-synthesis',
        'proof-sketch-to-formal',
        'counterexample-finder',
      ]);
    });

    it('should filter out non-string skills', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        skills: ['valid-skill', 123, null, 'another-skill', ''],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.capabilities).toEqual(['valid-skill', 'another-skill']);
    });

    it('should extract MCP server configuration', async () => {
      const agentConfig = {
        name: 'topology-agent',
        version: '1.0.0',
        description: 'Specialized agent for sheaf theory',
        mcp_server: {
          command: 'node',
          args: ['server.js'],
          env: {
            AGENT_TYPE: 'topology',
          },
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.mcpServer).toEqual({
        command: 'node',
        args: ['server.js'],
        env: {
          AGENT_TYPE: 'topology',
        },
      });
    });

    it('should extract dependencies', async () => {
      const agentConfig = {
        name: 'category-theory-agent',
        version: '1.0.0',
        dependencies: {
          morphism: 'A0, A3, A9',
          lean4: '^4.0.0',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.dependencies).toEqual({
        morphism: 'A0, A3, A9',
        lean4: '^4.0.0',
      });
    });

    it('should detect JavaScript language from node command', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        mcp_server: {
          command: 'node',
          args: ['server.js'],
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('JavaScript');
    });

    it('should detect Python language from python command', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        mcp_server: {
          command: 'python',
          args: ['server.py'],
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('Python');
    });

    it('should detect Python language from python3 command', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        mcp_server: {
          command: 'python3',
          args: ['server.py'],
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('Python');
    });

    it('should detect TypeScript language from deno command', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        mcp_server: {
          command: 'deno',
          args: ['run', 'server.ts'],
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('TypeScript');
    });

    it('should detect Lean language from lean4 dependency', async () => {
      const agentConfig = {
        name: 'proof-verifier-agent',
        version: '1.0.0',
        dependencies: {
          lean4: '^4.0.0',
          mathlib4: 'latest',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('Lean');
    });

    it('should detect TypeScript from typescript dependency', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        dependencies: {
          typescript: '^5.0.0',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('TypeScript');
    });

    it('should use explicit language field when provided', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        language: 'Rust',
        mcp_server: {
          command: 'node',
          args: ['server.js'],
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('Rust');
    });

    it('should default to JavaScript when no language indicators present', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('JavaScript');
    });

    it('should extract interfaces', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        interfaces: ['http', 'websocket', 'grpc'],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.interfaces).toEqual(['http', 'websocket', 'grpc']);
    });

    it('should extract capabilities metadata', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        capabilities: {
          maxConcurrentTasks: 10,
          supportsStreaming: true,
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.capabilitiesMetadata).toEqual({
        maxConcurrentTasks: 10,
        supportsStreaming: true,
      });
    });

    it('should extract custom fields (author, license, repository, homepage)', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        author: 'Jane Doe',
        license: 'Apache-2.0',
        repository: 'https://github.com/user/agent',
        homepage: 'https://agent.example.com',
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.author).toBe('Jane Doe');
      expect(metadata.customFields?.license).toBe('Apache-2.0');
      expect(metadata.customFields?.repository).toBe('https://github.com/user/agent');
      expect(metadata.customFields?.homepage).toBe('https://agent.example.com');
    });

    it('should handle author as object', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        author: {
          name: 'Jane Doe',
          email: 'jane@example.com',
          url: 'https://janedoe.com',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.author).toBe('Jane Doe');
    });

    it('should handle repository as object', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        repository: {
          type: 'git',
          url: 'https://github.com/user/agent.git',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.repository).toBe('https://github.com/user/agent.git');
    });

    it('should extract tags', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        tags: ['ai', 'automation', 'verification'],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.tags).toEqual(['ai', 'automation', 'verification']);
    });

    it('should extract config schema', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        config_schema: {
          type: 'object',
          properties: {
            apiKey: { type: 'string' },
            timeout: { type: 'number' },
          },
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.configSchema).toEqual({
        type: 'object',
        properties: {
          apiKey: { type: 'string' },
          timeout: { type: 'number' },
        },
      });
    });

    it('should handle complete agent.json with all fields', async () => {
      const agentConfig = {
        name: 'proof-verifier-agent',
        version: '1.0.0',
        description: 'Converts informal proofs to Lean and verifies them',
        language: 'TypeScript',
        skills: [
          'lean-synthesis',
          'proof-sketch-to-formal',
          'counterexample-finder',
        ],
        interfaces: ['http', 'cli'],
        mcp_server: {
          command: 'node',
          args: ['server.js'],
          env: {
            AGENT_TYPE: 'proof_verifier',
          },
        },
        dependencies: {
          lean4: '^4.0.0',
          mathlib4: 'latest',
        },
        author: 'Research Team',
        license: 'MIT',
        repository: 'https://github.com/org/proof-verifier',
        homepage: 'https://proof-verifier.example.com',
        tags: ['formal-verification', 'lean', 'mathematics'],
        capabilities: {
          maxProofSize: 10000,
          supportsParallel: true,
        },
        config_schema: {
          type: 'object',
          properties: {
            leanPath: { type: 'string' },
          },
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('proof-verifier-agent');
      expect(metadata.version).toBe('1.0.0');
      expect(metadata.description).toBe('Converts informal proofs to Lean and verifies them');
      expect(metadata.language).toBe('TypeScript');
      expect(metadata.capabilities).toEqual([
        'lean-synthesis',
        'proof-sketch-to-formal',
        'counterexample-finder',
      ]);
      expect(metadata.dependencies).toEqual({
        lean4: '^4.0.0',
        mathlib4: 'latest',
      });
      expect(metadata.customFields?.mcpServer).toBeDefined();
      expect(metadata.customFields?.interfaces).toEqual(['http', 'cli']);
      expect(metadata.customFields?.author).toBe('Research Team');
      expect(metadata.customFields?.license).toBe('MIT');
      expect(metadata.customFields?.repository).toBe('https://github.com/org/proof-verifier');
      expect(metadata.customFields?.homepage).toBe('https://proof-verifier.example.com');
      expect(metadata.customFields?.tags).toEqual(['formal-verification', 'lean', 'mathematics']);
      expect(metadata.customFields?.capabilitiesMetadata).toBeDefined();
      expect(metadata.customFields?.configSchema).toBeDefined();
    });

    it('should handle minimal agent.json with only name', async () => {
      const agentConfig = {
        name: 'minimal-agent',
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('minimal-agent');
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.language).toBe('JavaScript');
    });

    it('should handle empty agent.json', async () => {
      const agentConfig = {};

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBeUndefined();
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.language).toBe('JavaScript');
    });

    it('should throw MetadataExtractionError for malformed JSON', async () => {
      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, '{ invalid json }');

      await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
      await expect(extractor.extract(filePath)).rejects.toThrow(/Invalid JSON/);
    });

    it('should throw MetadataExtractionError for non-existent file', async () => {
      const filePath = join(tempDir, 'non-existent-agent.json');

      await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
    });

    it('should handle agent.json with unexpected field types gracefully', async () => {
      const agentConfig = {
        name: 123, // Should be string
        version: ['1.0.0'], // Should be string
        description: { text: 'description' }, // Should be string
        skills: 'not-an-array', // Should be array
        dependencies: 'not-an-object', // Should be object
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      // Should handle gracefully with undefined values
      expect(metadata.name).toBeUndefined();
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.capabilities).toBeUndefined();
      expect(metadata.dependencies).toBeUndefined();
    });

    it('should handle agent.json with null values', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: null,
        description: null,
        skills: null,
        dependencies: null,
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.name).toBe('test-agent');
      expect(metadata.version).toBeUndefined();
      expect(metadata.description).toBeUndefined();
      expect(metadata.capabilities).toBeUndefined();
      expect(metadata.dependencies).toBeUndefined();
    });

    it('should filter out empty strings from skills', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        skills: ['skill1', '  ', 'skill2', '', 'skill3'],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.capabilities).toEqual(['skill1', 'skill2', 'skill3']);
    });

    it('should filter out empty strings from interfaces', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        interfaces: ['http', '  ', 'websocket', ''],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.interfaces).toEqual(['http', 'websocket']);
    });

    it('should filter out empty strings from tags', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        tags: ['tag1', '', 'tag2', '   '],
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.customFields?.tags).toEqual(['tag1', 'tag2']);
    });

    it('should prioritize explicit language over inferred language', async () => {
      const agentConfig = {
        name: 'test-agent',
        version: '1.0.0',
        language: 'Rust',
        mcp_server: {
          command: 'node',
          args: ['server.js'],
        },
        dependencies: {
          typescript: '^5.0.0',
          lean4: '^4.0.0',
        },
      };

      const filePath = join(tempDir, 'agent.json');
      await fs.writeFile(filePath, JSON.stringify(agentConfig));

      const metadata = await extractor.extract(filePath);

      expect(metadata.language).toBe('Rust');
    });
  });
});
