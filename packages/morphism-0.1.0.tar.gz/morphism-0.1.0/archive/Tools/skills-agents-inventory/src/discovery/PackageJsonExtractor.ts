import { MetadataExtractor, MetadataExtractionError } from './MetadataExtractor';
import { ComponentMetadata } from '../types';
import { basename, dirname } from 'node:path';

/**
 * Extracts metadata from package.json files.
 * Handles npm package metadata including name, version, description, and dependencies.
 */
export class PackageJsonExtractor extends MetadataExtractor {
  protected readonly supportedExtensions = ['.json'];

  /**
   * Check if the file is specifically a package.json file.
   * @param path Absolute path to the file
   * @returns True if the file is named package.json
   */
  canExtract(path: string): boolean {
    return basename(path).toLowerCase() === 'package.json';
  }

  /**
   * Extract metadata from package.json file.
   * @param path Absolute path to package.json
   * @returns Partial ComponentMetadata with package information
   */
  protected async extractImpl(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      const packageJson = await this.readJsonFile(path);
      
      // Extract basic metadata
      const metadata: Partial<ComponentMetadata> = {
        name: this.safeString(packageJson, 'name'),
        version: this.safeString(packageJson, 'version'),
        description: this.safeString(packageJson, 'description'),
      };

      // Extract dependencies (combine dependencies and devDependencies)
      const dependencies = this.safeObject(packageJson, 'dependencies');
      const devDependencies = this.safeObject(packageJson, 'devDependencies');
      
      if (dependencies || devDependencies) {
        metadata.dependencies = {
          ...(dependencies || {}),
          ...(devDependencies || {}),
        };
      }

      // Detect language from package.json indicators
      metadata.language = this.detectLanguage(packageJson);

      // Extract keywords as capabilities
      const keywords = this.safeArray(packageJson, 'keywords');
      if (keywords && keywords.length > 0) {
        metadata.capabilities = keywords
          .filter((k): k is string => typeof k === 'string')
          .map(k => k.trim())
          .filter(k => k.length > 0);
      }

      // Store additional fields that might be useful
      metadata.customFields = {};
      
      // Extract author information
      const author = packageJson.author;
      if (author) {
        metadata.customFields.author = typeof author === 'string' 
          ? author 
          : author.name || author.email || author.url;
      }

      // Extract license
      const license = this.safeString(packageJson, 'license');
      if (license) {
        metadata.customFields.license = license;
      }

      // Extract repository information
      const repository = packageJson.repository;
      if (repository) {
        metadata.customFields.repository = typeof repository === 'string'
          ? repository
          : repository.url || repository;
      }

      // Extract homepage
      const homepage = this.safeString(packageJson, 'homepage');
      if (homepage) {
        metadata.customFields.homepage = homepage;
      }

      // Extract bin commands if present (for CLI tools)
      const bin = packageJson.bin;
      if (bin) {
        metadata.customFields.bin = bin;
      }

      // Extract scripts
      const scripts = this.safeObject(packageJson, 'scripts');
      if (scripts) {
        metadata.customFields.scripts = scripts;
      }

      return metadata;
    } catch (error) {
      // If it's already a MetadataExtractionError, re-throw it
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      // Handle malformed JSON gracefully
      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from package.json: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Detect the primary programming language from package.json.
   * @param packageJson Parsed package.json content
   * @returns Detected language or undefined
   */
  private detectLanguage(packageJson: any): string | undefined {
    // Check for TypeScript indicators
    const dependencies = this.safeObject(packageJson, 'dependencies') || {};
    const devDependencies = this.safeObject(packageJson, 'devDependencies') || {};
    const allDeps = { ...dependencies, ...devDependencies };

    if (allDeps['typescript'] || allDeps['@types/node']) {
      return 'TypeScript';
    }

    // Check for type field
    const type = this.safeString(packageJson, 'type');
    if (type === 'module') {
      return 'JavaScript (ESM)';
    }

    // Default to JavaScript
    return 'JavaScript';
  }
}
