import { MetadataExtractor, MetadataExtractionError, IMetadataExtractor } from './MetadataExtractor';
import { ComponentMetadata } from '../types';
import { promises as fs } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

/**
 * Concrete implementation of MetadataExtractor for testing.
 */
class TestExtractor extends MetadataExtractor {
  protected readonly supportedExtensions = ['.test', '.txt'];
  
  // Expose protected methods for testing
  public testReadJsonFile(path: string) {
    return this.readJsonFile(path);
  }
  
  public testReadTextFile(path: string) {
    return this.readTextFile(path);
  }
  
  public testSafeString(obj: any, key: string) {
    return this.safeString(obj, key);
  }
  
  public testSafeArray(obj: any, key: string) {
    return this.safeArray(obj, key);
  }
  
  public testSafeObject(obj: any, key: string) {
    return this.safeObject(obj, key);
  }

  protected async extractImpl(path: string): Promise<Partial<ComponentMetadata>> {
    const content = await this.readTextFile(path);
    return {
      name: 'test-component',
      description: content,
    };
  }
}

describe('MetadataExtractor', () => {
  let extractor: TestExtractor;
  let tempDir: string;

  beforeEach(async () => {
    extractor = new TestExtractor();
    // Create a unique temp directory for each test
    tempDir = join(tmpdir(), `metadata-extractor-test-${Date.now()}`);
    await fs.mkdir(tempDir, { recursive: true });
  });

  afterEach(async () => {
    // Clean up temp directory
    try {
      await fs.rm(tempDir, { recursive: true, force: true });
    } catch (error) {
      // Ignore cleanup errors
    }
  });

  describe('canExtract', () => {
    it('should return true for supported extensions', () => {
      expect(extractor.canExtract('/path/to/file.test')).toBe(true);
      expect(extractor.canExtract('/path/to/file.txt')).toBe(true);
    });

    it('should return false for unsupported extensions', () => {
      expect(extractor.canExtract('/path/to/file.json')).toBe(false);
      expect(extractor.canExtract('/path/to/file.md')).toBe(false);
      expect(extractor.canExtract('/path/to/file')).toBe(false);
    });

    it('should be case-insensitive', () => {
      expect(extractor.canExtract('/path/to/file.TEST')).toBe(true);
      expect(extractor.canExtract('/path/to/file.TXT')).toBe(true);
    });
  });

  describe('extract', () => {
    it('should extract metadata from a valid file', async () => {
      const filePath = join(tempDir, 'test.txt');
      await fs.writeFile(filePath, 'Test content');

      const metadata = await extractor.extract(filePath);

      expect(metadata).toEqual({
        name: 'test-component',
        description: 'Test content',
      });
    });

    it('should throw MetadataExtractionError for non-existent file', async () => {
      const filePath = join(tempDir, 'nonexistent.txt');

      await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
      await expect(extractor.extract(filePath)).rejects.toThrow(/Failed to extract metadata/);
    });

    it('should throw MetadataExtractionError for unreadable file', async () => {
      const filePath = join(tempDir, 'unreadable.txt');
      await fs.writeFile(filePath, 'content');
      
      // Make file unreadable (Unix-like systems only)
      if (process.platform !== 'win32') {
        await fs.chmod(filePath, 0o000);

        await expect(extractor.extract(filePath)).rejects.toThrow(MetadataExtractionError);
        
        // Restore permissions for cleanup
        await fs.chmod(filePath, 0o644);
      }
    });

    it('should include path in error', async () => {
      const filePath = join(tempDir, 'nonexistent.txt');

      try {
        await extractor.extract(filePath);
        fail('Should have thrown an error');
      } catch (error) {
        expect(error).toBeInstanceOf(MetadataExtractionError);
        expect((error as MetadataExtractionError).path).toBe(filePath);
      }
    });
  });

  describe('readJsonFile', () => {
    it('should read and parse valid JSON', async () => {
      const filePath = join(tempDir, 'test.json');
      const data = { name: 'test', version: '1.0.0' };
      await fs.writeFile(filePath, JSON.stringify(data));

      const result = await extractor.testReadJsonFile(filePath);

      expect(result).toEqual(data);
    });

    it('should throw MetadataExtractionError for invalid JSON', async () => {
      const filePath = join(tempDir, 'invalid.json');
      await fs.writeFile(filePath, '{ invalid json }');

      await expect(extractor.testReadJsonFile(filePath)).rejects.toThrow(MetadataExtractionError);
      await expect(extractor.testReadJsonFile(filePath)).rejects.toThrow(/Invalid JSON/);
    });

    it('should throw MetadataExtractionError for non-existent file', async () => {
      const filePath = join(tempDir, 'nonexistent.json');

      await expect(extractor.testReadJsonFile(filePath)).rejects.toThrow();
    });
  });

  describe('readTextFile', () => {
    it('should read text file content', async () => {
      const filePath = join(tempDir, 'test.txt');
      const content = 'Hello, World!';
      await fs.writeFile(filePath, content);

      const result = await extractor.testReadTextFile(filePath);

      expect(result).toBe(content);
    });

    it('should handle UTF-8 encoding', async () => {
      const filePath = join(tempDir, 'utf8.txt');
      const content = 'Hello 世界 🌍';
      await fs.writeFile(filePath, content, 'utf-8');

      const result = await extractor.testReadTextFile(filePath);

      expect(result).toBe(content);
    });
  });

  describe('safeString', () => {
    it('should extract string values', () => {
      const obj = { name: 'test', version: '1.0.0' };
      
      expect(extractor.testSafeString(obj, 'name')).toBe('test');
      expect(extractor.testSafeString(obj, 'version')).toBe('1.0.0');
    });

    it('should return undefined for non-string values', () => {
      const obj = { number: 42, array: [1, 2, 3], object: { key: 'value' } };
      
      expect(extractor.testSafeString(obj, 'number')).toBeUndefined();
      expect(extractor.testSafeString(obj, 'array')).toBeUndefined();
      expect(extractor.testSafeString(obj, 'object')).toBeUndefined();
    });

    it('should return undefined for missing keys', () => {
      const obj = { name: 'test' };
      
      expect(extractor.testSafeString(obj, 'missing')).toBeUndefined();
    });

    it('should handle null and undefined objects', () => {
      expect(extractor.testSafeString(null, 'key')).toBeUndefined();
      expect(extractor.testSafeString(undefined, 'key')).toBeUndefined();
    });
  });

  describe('safeArray', () => {
    it('should extract array values', () => {
      const obj = { items: [1, 2, 3], tags: ['a', 'b'] };
      
      expect(extractor.testSafeArray(obj, 'items')).toEqual([1, 2, 3]);
      expect(extractor.testSafeArray(obj, 'tags')).toEqual(['a', 'b']);
    });

    it('should return undefined for non-array values', () => {
      const obj = { string: 'test', number: 42, object: { key: 'value' } };
      
      expect(extractor.testSafeArray(obj, 'string')).toBeUndefined();
      expect(extractor.testSafeArray(obj, 'number')).toBeUndefined();
      expect(extractor.testSafeArray(obj, 'object')).toBeUndefined();
    });

    it('should return undefined for missing keys', () => {
      const obj = { items: [1, 2, 3] };
      
      expect(extractor.testSafeArray(obj, 'missing')).toBeUndefined();
    });

    it('should handle empty arrays', () => {
      const obj = { empty: [] };
      
      expect(extractor.testSafeArray(obj, 'empty')).toEqual([]);
    });
  });

  describe('safeObject', () => {
    it('should extract object values', () => {
      const obj = { config: { key: 'value' }, metadata: { version: '1.0.0' } };
      
      expect(extractor.testSafeObject(obj, 'config')).toEqual({ key: 'value' });
      expect(extractor.testSafeObject(obj, 'metadata')).toEqual({ version: '1.0.0' });
    });

    it('should return undefined for non-object values', () => {
      const obj = { string: 'test', number: 42, array: [1, 2, 3] };
      
      expect(extractor.testSafeObject(obj, 'string')).toBeUndefined();
      expect(extractor.testSafeObject(obj, 'number')).toBeUndefined();
      expect(extractor.testSafeObject(obj, 'array')).toBeUndefined();
    });

    it('should return undefined for missing keys', () => {
      const obj = { config: { key: 'value' } };
      
      expect(extractor.testSafeObject(obj, 'missing')).toBeUndefined();
    });

    it('should handle empty objects', () => {
      const obj = { empty: {} };
      
      expect(extractor.testSafeObject(obj, 'empty')).toEqual({});
    });

    it('should handle null values', () => {
      const obj = { nullable: null };
      
      expect(extractor.testSafeObject(obj, 'nullable')).toBeUndefined();
    });
  });

  describe('MetadataExtractionError', () => {
    it('should create error with message and path', () => {
      const error = new MetadataExtractionError('Test error', '/path/to/file');
      
      expect(error.message).toBe('Test error');
      expect(error.path).toBe('/path/to/file');
      expect(error.name).toBe('MetadataExtractionError');
      expect(error.cause).toBeUndefined();
    });

    it('should create error with cause', () => {
      const cause = new Error('Original error');
      const error = new MetadataExtractionError('Test error', '/path/to/file', cause);
      
      expect(error.message).toBe('Test error');
      expect(error.path).toBe('/path/to/file');
      expect(error.cause).toBe(cause);
    });

    it('should be instanceof Error', () => {
      const error = new MetadataExtractionError('Test error', '/path/to/file');
      
      expect(error).toBeInstanceOf(Error);
      expect(error).toBeInstanceOf(MetadataExtractionError);
    });
  });
});
