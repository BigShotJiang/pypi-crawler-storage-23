import { MetadataExtractor, MetadataExtractionError } from './MetadataExtractor';
import { ComponentMetadata } from '../types';
import { basename } from 'node:path';

/**
 * Extracts metadata from agent configuration files (agent.json).
 * Handles agent-specific metadata including capabilities, interfaces, and MCP server configuration.
 */
export class AgentConfigExtractor extends MetadataExtractor {
  protected readonly supportedExtensions = ['.json'];

  /**
   * Check if the file is specifically an agent.json file.
   * @param path Absolute path to the file
   * @returns True if the file is named agent.json
   */
  canExtract(path: string): boolean {
    return basename(path).toLowerCase() === 'agent.json';
  }

  /**
   * Extract metadata from agent.json file.
   * @param path Absolute path to agent.json
   * @returns Partial ComponentMetadata with agent information
   */
  protected async extractImpl(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      const agentConfig = await this.readJsonFile(path);
      
      // Extract basic metadata
      const metadata: Partial<ComponentMetadata> = {
        name: this.safeString(agentConfig, 'name'),
        version: this.safeString(agentConfig, 'version'),
        description: this.safeString(agentConfig, 'description'),
      };

      // Extract skills as capabilities
      const skills = this.safeArray(agentConfig, 'skills');
      if (skills && skills.length > 0) {
        metadata.capabilities = skills
          .filter((s): s is string => typeof s === 'string')
          .map(s => s.trim())
          .filter(s => s.length > 0);
      }

      // Extract dependencies
      const dependencies = this.safeObject(agentConfig, 'dependencies');
      if (dependencies) {
        metadata.dependencies = dependencies;
      }

      // Detect language (agents are typically TypeScript/JavaScript)
      metadata.language = this.detectLanguage(agentConfig);

      // Store agent-specific fields in customFields
      metadata.customFields = {};

      // Extract MCP server configuration
      const mcpServer = this.safeObject(agentConfig, 'mcp_server');
      if (mcpServer) {
        metadata.customFields.mcpServer = {
          command: this.safeString(mcpServer, 'command'),
          args: this.safeArray(mcpServer, 'args'),
          env: this.safeObject(mcpServer, 'env'),
        };
      }

      // Extract interfaces if present
      const interfaces = this.safeArray(agentConfig, 'interfaces');
      if (interfaces && interfaces.length > 0) {
        metadata.customFields.interfaces = interfaces
          .filter((i): i is string => typeof i === 'string')
          .map(i => i.trim())
          .filter(i => i.length > 0);
      }

      // Extract capabilities metadata if present (different from skills)
      const capabilitiesMetadata = this.safeObject(agentConfig, 'capabilities');
      if (capabilitiesMetadata) {
        metadata.customFields.capabilitiesMetadata = capabilitiesMetadata;
      }

      // Extract author information
      const author = agentConfig.author;
      if (author) {
        metadata.customFields.author = typeof author === 'string' 
          ? author 
          : author.name || author.email || author.url;
      }

      // Extract license
      const license = this.safeString(agentConfig, 'license');
      if (license) {
        metadata.customFields.license = license;
      }

      // Extract repository information
      const repository = agentConfig.repository;
      if (repository) {
        metadata.customFields.repository = typeof repository === 'string'
          ? repository
          : repository.url || repository;
      }

      // Extract homepage
      const homepage = this.safeString(agentConfig, 'homepage');
      if (homepage) {
        metadata.customFields.homepage = homepage;
      }

      // Extract tags/keywords if present
      const tags = this.safeArray(agentConfig, 'tags');
      if (tags && tags.length > 0) {
        metadata.customFields.tags = tags
          .filter((t): t is string => typeof t === 'string')
          .map(t => t.trim())
          .filter(t => t.length > 0);
      }

      // Extract configuration schema if present
      const configSchema = this.safeObject(agentConfig, 'config_schema');
      if (configSchema) {
        metadata.customFields.configSchema = configSchema;
      }

      return metadata;
    } catch (error) {
      // If it's already a MetadataExtractionError, re-throw it
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      // Handle malformed JSON gracefully
      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from agent.json: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Detect the primary programming language from agent.json.
   * @param agentConfig Parsed agent.json content
   * @returns Detected language or undefined
   */
  private detectLanguage(agentConfig: any): string | undefined {
    // Check for language field
    const language = this.safeString(agentConfig, 'language');
    if (language) {
      return language;
    }

    // Check MCP server command to infer language
    const mcpServer = this.safeObject(agentConfig, 'mcp_server');
    if (mcpServer) {
      const command = this.safeString(mcpServer, 'command');
      if (command === 'node') {
        return 'JavaScript';
      } else if (command === 'python' || command === 'python3') {
        return 'Python';
      } else if (command === 'deno') {
        return 'TypeScript';
      }
    }

    // Check dependencies for language indicators
    const dependencies = this.safeObject(agentConfig, 'dependencies');
    if (dependencies) {
      if (dependencies['typescript'] || dependencies['@types/node']) {
        return 'TypeScript';
      }
      if (dependencies['lean4'] || dependencies['mathlib4']) {
        return 'Lean';
      }
    }

    // Default to JavaScript for agents
    return 'JavaScript';
  }
}
