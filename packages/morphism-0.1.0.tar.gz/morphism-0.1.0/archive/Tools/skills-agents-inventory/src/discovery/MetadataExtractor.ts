import { ComponentMetadata } from '../types';
import { promises as fs } from 'node:fs';
import { extname } from 'node:path';

/**
 * Error thrown when metadata extraction fails.
 */
export class MetadataExtractionError extends Error {
  constructor(
    message: string,
    public readonly path: string,
    public readonly cause?: Error
  ) {
    super(message);
    this.name = 'MetadataExtractionError';
    
    // Maintain proper stack trace for where our error was thrown (only available on V8)
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, MetadataExtractionError);
    }
  }
}

/**
 * Interface for metadata extractors.
 * Each extractor is responsible for extracting metadata from a specific file type.
 */
export interface IMetadataExtractor {
  /**
   * Determine if this extractor can handle the given file path.
   * @param path Absolute path to the file
   * @returns True if this extractor can extract metadata from the file
   */
  canExtract(path: string): boolean;

  /**
   * Extract metadata from the file at the given path.
   * @param path Absolute path to the file
   * @returns Promise resolving to ComponentMetadata
   * @throws MetadataExtractionError if extraction fails
   */
  extract(path: string): Promise<Partial<ComponentMetadata>>;
}

/**
 * Abstract base class for metadata extractors.
 * Provides common functionality and error handling.
 */
export abstract class MetadataExtractor implements IMetadataExtractor {
  /**
   * File extensions this extractor can handle.
   * Subclasses should override this.
   */
  protected abstract readonly supportedExtensions: string[];

  /**
   * Determine if this extractor can handle the given file path.
   * Default implementation checks file extension.
   * @param path Absolute path to the file
   * @returns True if this extractor can extract metadata from the file
   */
  canExtract(path: string): boolean {
    const ext = extname(path).toLowerCase();
    return this.supportedExtensions.includes(ext);
  }

  /**
   * Extract metadata from the file at the given path.
   * Implements error handling and delegates to extractImpl.
   * @param path Absolute path to the file
   * @returns Promise resolving to ComponentMetadata
   * @throws MetadataExtractionError if extraction fails
   */
  async extract(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      // Verify file exists and is readable
      await fs.access(path, fs.constants.R_OK);
      
      // Delegate to implementation
      return await this.extractImpl(path);
    } catch (error) {
      if (error instanceof MetadataExtractionError) {
        // Re-throw our custom errors
        throw error;
      }
      
      // Wrap other errors
      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from ${path}: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Implementation-specific extraction logic.
   * Subclasses must implement this method.
   * @param path Absolute path to the file
   * @returns Promise resolving to ComponentMetadata
   * @throws Error if extraction fails
   */
  protected abstract extractImpl(path: string): Promise<Partial<ComponentMetadata>>;

  /**
   * Read and parse a JSON file.
   * @param path Absolute path to the JSON file
   * @returns Parsed JSON content
   * @throws MetadataExtractionError if file cannot be read or parsed
   */
  protected async readJsonFile(path: string): Promise<any> {
    try {
      const content = await fs.readFile(path, 'utf-8');
      return JSON.parse(content);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new MetadataExtractionError(
          `Invalid JSON in ${path}: ${error.message}`,
          path,
          error
        );
      }
      throw error;
    }
  }

  /**
   * Read a text file.
   * @param path Absolute path to the file
   * @returns File content as string
   * @throws Error if file cannot be read
   */
  protected async readTextFile(path: string): Promise<string> {
    return await fs.readFile(path, 'utf-8');
  }

  /**
   * Safely extract a string value from an object.
   * @param obj Object to extract from
   * @param key Key to extract
   * @returns String value or undefined
   */
  protected safeString(obj: any, key: string): string | undefined {
    const value = obj?.[key];
    return typeof value === 'string' ? value : undefined;
  }

  /**
   * Safely extract an array value from an object.
   * @param obj Object to extract from
   * @param key Key to extract
   * @returns Array value or undefined
   */
  protected safeArray(obj: any, key: string): any[] | undefined {
    const value = obj?.[key];
    return Array.isArray(value) ? value : undefined;
  }

  /**
   * Safely extract an object value from an object.
   * @param obj Object to extract from
   * @param key Key to extract
   * @returns Object value or undefined
   */
  protected safeObject(obj: any, key: string): Record<string, any> | undefined {
    const value = obj?.[key];
    return value && typeof value === 'object' && !Array.isArray(value) ? value : undefined;
  }
}
