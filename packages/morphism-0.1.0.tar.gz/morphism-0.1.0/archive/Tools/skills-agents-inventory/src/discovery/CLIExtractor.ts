import { MetadataExtractor, MetadataExtractionError } from './MetadataExtractor';
import { ComponentMetadata, CommandInfo } from '../types';
import { basename, dirname, join } from 'node:path';
import { promises as fs } from 'node:fs';
import { exec } from 'node:child_process';
import { promisify } from 'node:util';

const execAsync = promisify(exec);

/**
 * Extracts metadata from CLI tools.
 * Handles CLI-specific metadata including available commands and their descriptions.
 * 
 * Supports multiple detection strategies:
 * 1. cli.json configuration files
 * 2. package.json with bin field
 * 3. Executable scripts with --help output parsing
 */
export class CLIExtractor extends MetadataExtractor {
  protected readonly supportedExtensions = ['.json', '.js', '.ts', '.sh', '.py'];

  /**
   * Check if the file is a CLI-related file.
   * @param path Absolute path to the file
   * @returns True if the file is a CLI configuration or executable
   */
  canExtract(path: string): boolean {
    const filename = basename(path).toLowerCase();
    
    // Check for cli.json configuration file
    if (filename === 'cli.json') {
      return true;
    }
    
    // Check for package.json with bin field (handled separately but can provide CLI info)
    if (filename === 'package.json') {
      return true;
    }
    
    // Check for executable scripts in bin/ directories
    if (dirname(path).endsWith('bin') && super.canExtract(path)) {
      return true;
    }
    
    return false;
  }

  /**
   * Extract metadata from CLI tool.
   * @param path Absolute path to CLI file
   * @returns Partial ComponentMetadata with CLI information
   */
  protected async extractImpl(path: string): Promise<Partial<ComponentMetadata>> {
    const filename = basename(path).toLowerCase();
    
    // Strategy 1: Extract from cli.json configuration file
    if (filename === 'cli.json') {
      return await this.extractFromCliJson(path);
    }
    
    // Strategy 2: Extract from package.json with bin field
    if (filename === 'package.json') {
      return await this.extractFromPackageJson(path);
    }
    
    // Strategy 3: Extract from executable script
    return await this.extractFromExecutable(path);
  }

  /**
   * Extract metadata from cli.json configuration file.
   * @param path Absolute path to cli.json
   * @returns Partial ComponentMetadata
   */
  private async extractFromCliJson(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      const cliConfig = await this.readJsonFile(path);
      
      const metadata: Partial<ComponentMetadata> = {
        name: this.safeString(cliConfig, 'name'),
        version: this.safeString(cliConfig, 'version'),
        description: this.safeString(cliConfig, 'description'),
      };

      // Extract commands
      const commands = this.safeArray(cliConfig, 'commands');
      if (commands && commands.length > 0) {
        metadata.commands = commands
          .filter((cmd): cmd is any => typeof cmd === 'object' && cmd !== null)
          .map(cmd => this.parseCommandInfo(cmd))
          .filter((cmd): cmd is CommandInfo => cmd !== null);
      }

      // Extract language
      metadata.language = this.safeString(cliConfig, 'language') || 'Unknown';

      // Extract capabilities from command names
      if (metadata.commands && metadata.commands.length > 0) {
        metadata.capabilities = metadata.commands.map(cmd => cmd.name);
      }

      // Store additional CLI-specific fields
      metadata.customFields = {};

      const entryPoint = this.safeString(cliConfig, 'entryPoint');
      if (entryPoint) {
        metadata.customFields.entryPoint = entryPoint;
      }

      const usage = this.safeString(cliConfig, 'usage');
      if (usage) {
        metadata.customFields.usage = usage;
      }

      const examples = this.safeArray(cliConfig, 'examples');
      if (examples) {
        metadata.customFields.examples = examples;
      }

      return metadata;
    } catch (error) {
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from cli.json: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Extract CLI metadata from package.json with bin field.
   * @param path Absolute path to package.json
   * @returns Partial ComponentMetadata
   */
  private async extractFromPackageJson(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      const packageJson = await this.readJsonFile(path);
      
      // Only process if bin field exists
      const bin = packageJson.bin;
      if (!bin) {
        return {};
      }

      const metadata: Partial<ComponentMetadata> = {
        name: this.safeString(packageJson, 'name'),
        version: this.safeString(packageJson, 'version'),
        description: this.safeString(packageJson, 'description'),
        language: 'JavaScript',
      };

      // Extract commands from bin field
      const commands: CommandInfo[] = [];
      
      if (typeof bin === 'string') {
        // Single command (command name is package name)
        const commandName = metadata.name || 'cli';
        commands.push({
          name: commandName,
          description: metadata.description || `${commandName} command`,
        });
      } else if (typeof bin === 'object' && bin !== null) {
        // Multiple commands
        for (const [commandName, scriptPath] of Object.entries(bin)) {
          commands.push({
            name: commandName,
            description: `${commandName} command`,
          });
        }
      }

      if (commands.length > 0) {
        metadata.commands = commands;
        metadata.capabilities = commands.map(cmd => cmd.name);
      }

      // Store bin information in customFields
      metadata.customFields = {
        bin,
      };

      return metadata;
    } catch (error) {
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract CLI metadata from package.json: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Extract metadata from executable script by parsing --help output.
   * @param path Absolute path to executable
   * @returns Partial ComponentMetadata
   */
  private async extractFromExecutable(path: string): Promise<Partial<ComponentMetadata>> {
    try {
      // Check if file is executable
      try {
        await fs.access(path, fs.constants.X_OK);
      } catch {
        // Not executable, return minimal metadata
        return {
          name: basename(path, this.getExtension(path)),
          language: this.detectLanguageFromExtension(path),
        };
      }

      const metadata: Partial<ComponentMetadata> = {
        name: basename(path, this.getExtension(path)),
        language: this.detectLanguageFromExtension(path),
      };

      // Try to execute with --help flag to extract commands and description
      try {
        const { stdout, stderr } = await execAsync(`"${path}" --help`, {
          timeout: 5000, // 5 second timeout
          maxBuffer: 1024 * 1024, // 1MB buffer
        });

        const helpOutput = stdout || stderr;
        
        // Parse help output for description and commands
        const parsed = this.parseHelpOutput(helpOutput);
        
        if (parsed.description) {
          metadata.description = parsed.description;
        }
        
        if (parsed.commands && parsed.commands.length > 0) {
          metadata.commands = parsed.commands;
          metadata.capabilities = parsed.commands.map(cmd => cmd.name);
        }

        metadata.customFields = {
          helpOutput: helpOutput.substring(0, 500), // Store first 500 chars
        };
      } catch (execError) {
        // Execution failed, but we still have basic metadata
        // This is not a fatal error
        metadata.customFields = {
          executableError: execError instanceof Error ? execError.message : String(execError),
        };
      }

      return metadata;
    } catch (error) {
      if (error instanceof MetadataExtractionError) {
        throw error;
      }

      const message = error instanceof Error ? error.message : String(error);
      throw new MetadataExtractionError(
        `Failed to extract metadata from executable: ${message}`,
        path,
        error instanceof Error ? error : undefined
      );
    }
  }

  /**
   * Parse command information from CLI config object.
   * @param cmd Command object from config
   * @returns CommandInfo or null if invalid
   */
  private parseCommandInfo(cmd: any): CommandInfo | null {
    const name = this.safeString(cmd, 'name');
    const description = this.safeString(cmd, 'description');
    
    if (!name) {
      return null;
    }

    const commandInfo: CommandInfo = {
      name,
      description: description || `${name} command`,
    };

    // Parse arguments if present
    const args = this.safeArray(cmd, 'arguments') || this.safeArray(cmd, 'args');
    if (args && args.length > 0) {
      commandInfo.arguments = args
        .filter((arg): arg is any => typeof arg === 'object' && arg !== null)
        .map(arg => ({
          name: this.safeString(arg, 'name') || '',
          description: this.safeString(arg, 'description') || '',
          required: Boolean(arg.required),
          type: this.safeString(arg, 'type'),
        }))
        .filter(arg => arg.name !== '');
    }

    return commandInfo;
  }

  /**
   * Parse --help output to extract description and commands.
   * @param helpOutput Help text output
   * @returns Parsed metadata
   */
  private parseHelpOutput(helpOutput: string): {
    description?: string;
    commands?: CommandInfo[];
  } {
    const lines = helpOutput.split('\n');
    
    let description: string | undefined;
    const commands: CommandInfo[] = [];

    // Try to extract description (usually first non-empty line or after "Description:")
    for (let i = 0; i < Math.min(lines.length, 10); i++) {
      const line = lines[i].trim();
      if (line && !line.startsWith('Usage:') && !line.startsWith('Options:') && !line.startsWith('Commands:')) {
        if (line.toLowerCase().startsWith('description:')) {
          description = line.substring('description:'.length).trim();
        } else if (!description && line.length > 10 && line.length < 200) {
          description = line;
        }
        if (description) break;
      }
    }

    // Try to extract commands (look for "Commands:" section)
    let inCommandsSection = false;
    for (const line of lines) {
      const trimmedLine = line.trim();
      
      if (trimmedLine.toLowerCase().startsWith('commands:')) {
        inCommandsSection = true;
        continue;
      }

      if (inCommandsSection) {
        // Stop if we hit another section
        if (trimmedLine.toLowerCase().startsWith('options:') || trimmedLine.toLowerCase().startsWith('flags:')) {
          break;
        }

        // Skip empty lines
        if (!trimmedLine) {
          continue;
        }

        // Parse command line (format: "  command-name    Description of command")
        // Match lines that start with whitespace followed by a command name
        const match = line.match(/^\s+([a-z0-9-_]+)\s+(.+)$/i);
        if (match) {
          commands.push({
            name: match[1],
            description: match[2].trim(),
          });
        }
      }
    }

    return { description, commands: commands.length > 0 ? commands : undefined };
  }

  /**
   * Get file extension including the dot.
   * @param path File path
   * @returns Extension with dot (e.g., ".js")
   */
  private getExtension(path: string): string {
    const match = path.match(/\.[^.]+$/);
    return match ? match[0] : '';
  }

  /**
   * Detect programming language from file extension.
   * @param path File path
   * @returns Detected language
   */
  private detectLanguageFromExtension(path: string): string {
    const ext = this.getExtension(path).toLowerCase();
    
    const languageMap: Record<string, string> = {
      '.js': 'JavaScript',
      '.ts': 'TypeScript',
      '.py': 'Python',
      '.sh': 'Shell',
      '.bash': 'Bash',
      '.rb': 'Ruby',
      '.go': 'Go',
      '.rs': 'Rust',
    };

    return languageMap[ext] || 'Unknown';
  }
}
