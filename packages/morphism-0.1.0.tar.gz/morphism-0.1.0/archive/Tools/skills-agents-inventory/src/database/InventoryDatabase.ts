import Database from 'better-sqlite3';
import { Component, QueryCriteria } from '../types';
import { Component as ComponentClass } from '../core/Component';

/**
 * InventoryDatabase manages persistence and querying of component inventory using SQLite.
 * Provides CRUD operations, full-text search, and efficient querying capabilities.
 */
export class InventoryDatabase {
  private db: Database.Database;

  constructor(dbPath: string) {
    this.db = new Database(dbPath);
    // Enable WAL mode for better concurrent access
    this.db.pragma('journal_mode = WAL');
  }

  /**
   * Initialize the database schema.
   * Creates tables, indexes, and FTS5 virtual table for full-text search.
   */
  async initialize(): Promise<void> {
    // Create components table
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS components (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        name TEXT NOT NULL,
        path TEXT NOT NULL,
        relative_path TEXT NOT NULL,
        metadata TEXT NOT NULL,
        discovered_at TEXT NOT NULL,
        last_modified TEXT NOT NULL,
        is_active INTEGER DEFAULT 1
      )
    `);

    // Create indexes for efficient querying
    this.db.exec(`
      CREATE INDEX IF NOT EXISTS idx_name ON components(name);
      CREATE INDEX IF NOT EXISTS idx_type ON components(type);
      CREATE INDEX IF NOT EXISTS idx_active ON components(is_active);
    `);

    // Create FTS5 virtual table for full-text search
    // This enables fast keyword and fuzzy searching across name and description
    this.db.exec(`
      CREATE VIRTUAL TABLE IF NOT EXISTS components_fts USING fts5(
        id UNINDEXED,
        name,
        description,
        content=''
      )
    `);

    // Create triggers to keep FTS table in sync with components table
    this.db.exec(`
      CREATE TRIGGER IF NOT EXISTS components_fts_insert AFTER INSERT ON components BEGIN
        INSERT INTO components_fts(id, name, description)
        VALUES (
          new.id,
          new.name,
          json_extract(new.metadata, '$.description')
        );
      END;
    `);

    this.db.exec(`
      CREATE TRIGGER IF NOT EXISTS components_fts_update AFTER UPDATE ON components BEGIN
        UPDATE components_fts
        SET name = new.name,
            description = json_extract(new.metadata, '$.description')
        WHERE id = new.id;
      END;
    `);

    this.db.exec(`
      CREATE TRIGGER IF NOT EXISTS components_fts_delete AFTER DELETE ON components BEGIN
        DELETE FROM components_fts WHERE id = old.id;
      END;
    `);
  }

  /**
   * Insert a new component into the database.
   * @param component Component to insert
   */
  async insert(component: Component): Promise<void> {
    const stmt = this.db.prepare(`
      INSERT INTO components (
        id, type, name, path, relative_path, metadata,
        discovered_at, last_modified, is_active
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      component.id,
      component.type,
      component.name,
      component.path,
      component.relativePath,
      JSON.stringify(component.metadata),
      component.discoveredAt.toISOString(),
      component.lastModified.toISOString(),
      component.isActive ? 1 : 0
    );
  }

  /**
   * Update an existing component in the database.
   * @param component Component to update
   */
  async update(component: Component): Promise<void> {
    const stmt = this.db.prepare(`
      UPDATE components
      SET type = ?,
          name = ?,
          path = ?,
          relative_path = ?,
          metadata = ?,
          discovered_at = ?,
          last_modified = ?,
          is_active = ?
      WHERE id = ?
    `);

    stmt.run(
      component.type,
      component.name,
      component.path,
      component.relativePath,
      JSON.stringify(component.metadata),
      component.discoveredAt.toISOString(),
      component.lastModified.toISOString(),
      component.isActive ? 1 : 0,
      component.id
    );
  }

  /**
   * Mark a component as inactive (soft delete).
   * Preserves historical data while indicating the component is no longer available.
   * @param componentId ID of the component to mark inactive
   */
  async markInactive(componentId: string): Promise<void> {
    const stmt = this.db.prepare(`
      UPDATE components
      SET is_active = 0
      WHERE id = ?
    `);

    stmt.run(componentId);
  }

  /**
   * Get a component by its ID.
   * @param id Component ID
   * @returns Component or null if not found
   */
  async getById(id: string): Promise<Component | null> {
    const stmt = this.db.prepare(`
      SELECT * FROM components WHERE id = ?
    `);

    const row = stmt.get(id) as any;
    return row ? this.rowToComponent(row) : null;
  }

  /**
   * Get all components from the database.
   * @returns Array of all components
   */
  async getAll(): Promise<Component[]> {
    const stmt = this.db.prepare(`
      SELECT * FROM components WHERE is_active = 1
      ORDER BY name
    `);

    const rows = stmt.all() as any[];
    return rows.map((row) => this.rowToComponent(row));
  }

  /**
   * Query components based on criteria.
   * Supports filtering by name, type, language, keywords, and fuzzy matching.
   * @param criteria Query criteria
   * @returns Array of matching components
   */
  async query(criteria: QueryCriteria): Promise<Component[]> {
    let query = 'SELECT * FROM components WHERE is_active = 1';
    const params: any[] = [];

    // Filter by type
    if (criteria.type && criteria.type.length > 0) {
      const placeholders = criteria.type.map(() => '?').join(',');
      query += ` AND type IN (${placeholders})`;
      params.push(...criteria.type);
    }

    // Filter by language
    if (criteria.language) {
      query += ` AND json_extract(metadata, '$.language') = ?`;
      params.push(criteria.language);
    }

    // Filter by name (exact or fuzzy)
    if (criteria.name && !criteria.fuzzyMatch) {
      query += ` AND name LIKE ?`;
      params.push(`%${criteria.name}%`);
    }

    // Use FTS5 for fuzzy matching with keywords or name
    if (criteria.fuzzyMatch && (criteria.keywords || criteria.name)) {
      const searchTerms = criteria.keywords || [criteria.name!];
      const ftsQuery = searchTerms.join(' OR ');
      
      query = `
        SELECT c.* FROM components c
        INNER JOIN components_fts fts ON c.id = fts.id
        WHERE c.is_active = 1 AND components_fts MATCH ?
      `;
      params.unshift(ftsQuery);
    }

    // Add ordering
    query += ' ORDER BY name';

    // Add pagination
    if (criteria.limit) {
      query += ' LIMIT ?';
      params.push(criteria.limit);
    }

    if (criteria.offset) {
      query += ' OFFSET ?';
      params.push(criteria.offset);
    }

    const stmt = this.db.prepare(query);
    const rows = stmt.all(...params) as any[];
    return rows.map((row) => this.rowToComponent(row));
  }

  /**
   * Close the database connection.
   */
  close(): void {
    this.db.close();
  }

  /**
   * Convert a database row to a Component object.
   * @param row Database row
   * @returns Component instance
   */
  private rowToComponent(row: any): Component {
    return {
      id: row.id,
      type: row.type,
      name: row.name,
      path: row.path,
      relativePath: row.relative_path,
      metadata: JSON.parse(row.metadata),
      discoveredAt: new Date(row.discovered_at),
      lastModified: new Date(row.last_modified),
      isActive: row.is_active === 1,
    };
  }
}
