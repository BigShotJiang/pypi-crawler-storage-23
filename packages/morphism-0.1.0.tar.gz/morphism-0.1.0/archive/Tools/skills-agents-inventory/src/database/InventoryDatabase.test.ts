import { InventoryDatabase } from './InventoryDatabase';
import { Component } from '../types';
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';

describe('InventoryDatabase', () => {
  let db: InventoryDatabase;
  let dbPath: string;

  beforeEach(async () => {
    // Create a temporary database file for testing
    const tmpDir = os.tmpdir();
    dbPath = path.join(tmpDir, `test-inventory-${Date.now()}.db`);
    db = new InventoryDatabase(dbPath);
    await db.initialize();
  });

  afterEach(() => {
    // Clean up
    db.close();
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    // Also clean up WAL files
    const walPath = `${dbPath}-wal`;
    const shmPath = `${dbPath}-shm`;
    if (fs.existsSync(walPath)) {
      fs.unlinkSync(walPath);
    }
    if (fs.existsSync(shmPath)) {
      fs.unlinkSync(shmPath);
    }
  });

  describe('initialize', () => {
    it('should create components table', async () => {
      // The table should be created during initialization
      // Try to insert a component to verify the table exists
      const component: Component = {
        id: 'test-id-1',
        type: 'skill',
        name: 'test-skill',
        path: '/test/path',
        relativePath: 'test/path',
        metadata: {
          name: 'test-skill',
          description: 'A test skill',
        },
        discoveredAt: new Date(),
        lastModified: new Date(),
        isActive: true,
      };

      await expect(db.insert(component)).resolves.not.toThrow();
    });

    it('should create indexes for name, type, and is_active', async () => {
      // Insert multiple components to test index usage
      const components: Component[] = [
        {
          id: 'test-id-1',
          type: 'skill',
          name: 'alpha-skill',
          path: '/test/alpha',
          relativePath: 'test/alpha',
          metadata: { name: 'alpha-skill' },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
        {
          id: 'test-id-2',
          type: 'agent',
          name: 'beta-agent',
          path: '/test/beta',
          relativePath: 'test/beta',
          metadata: { name: 'beta-agent' },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
        {
          id: 'test-id-3',
          type: 'cli',
          name: 'gamma-cli',
          path: '/test/gamma',
          relativePath: 'test/gamma',
          metadata: { name: 'gamma-cli' },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: false,
        },
      ];

      for (const component of components) {
        await db.insert(component);
      }

      // Query by type (should use idx_type)
      const agents = await db.query({ type: ['agent'] });
      expect(agents).toHaveLength(1);
      expect(agents[0].name).toBe('beta-agent');

      // Query by name (should use idx_name)
      const alphaResults = await db.query({ name: 'alpha' });
      expect(alphaResults).toHaveLength(1);
      expect(alphaResults[0].name).toBe('alpha-skill');

      // Get all active (should use idx_active)
      const allActive = await db.getAll();
      expect(allActive).toHaveLength(2);
    });

    it('should create FTS5 virtual table for full-text search', async () => {
      // Insert components with descriptions
      const components: Component[] = [
        {
          id: 'test-id-1',
          type: 'skill',
          name: 'authentication-skill',
          path: '/test/auth',
          relativePath: 'test/auth',
          metadata: {
            name: 'authentication-skill',
            description: 'Handles user authentication and authorization',
          },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
        {
          id: 'test-id-2',
          type: 'agent',
          name: 'database-agent',
          path: '/test/db',
          relativePath: 'test/db',
          metadata: {
            name: 'database-agent',
            description: 'Manages database connections and queries',
          },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
      ];

      for (const component of components) {
        await db.insert(component);
      }

      // Test fuzzy search using FTS5
      const authResults = await db.query({
        keywords: ['authentication'],
        fuzzyMatch: true,
      });
      expect(authResults.length).toBeGreaterThan(0);
      expect(authResults[0].name).toBe('authentication-skill');

      const dbResults = await db.query({
        keywords: ['database'],
        fuzzyMatch: true,
      });
      expect(dbResults.length).toBeGreaterThan(0);
      expect(dbResults[0].name).toBe('database-agent');
    });

    it('should handle multiple initializations without errors', async () => {
      // Initialize again - should not throw errors
      await expect(db.initialize()).resolves.not.toThrow();
      
      // Verify database still works
      const component: Component = {
        id: 'test-id-1',
        type: 'skill',
        name: 'test-skill',
        path: '/test/path',
        relativePath: 'test/path',
        metadata: { name: 'test-skill' },
        discoveredAt: new Date(),
        lastModified: new Date(),
        isActive: true,
      };

      await db.insert(component);
      const retrieved = await db.getById('test-id-1');
      expect(retrieved).not.toBeNull();
      expect(retrieved?.name).toBe('test-skill');
    });
  });

  describe('CRUD operations', () => {
    it('should insert and retrieve a component', async () => {
      const component: Component = {
        id: 'test-id-1',
        type: 'skill',
        name: 'test-skill',
        path: '/test/path',
        relativePath: 'test/path',
        metadata: {
          name: 'test-skill',
          description: 'A test skill',
          version: '1.0.0',
        },
        discoveredAt: new Date('2025-01-01T00:00:00Z'),
        lastModified: new Date('2025-01-01T00:00:00Z'),
        isActive: true,
      };

      await db.insert(component);
      const retrieved = await db.getById('test-id-1');

      expect(retrieved).not.toBeNull();
      expect(retrieved?.id).toBe(component.id);
      expect(retrieved?.type).toBe(component.type);
      expect(retrieved?.name).toBe(component.name);
      expect(retrieved?.metadata.description).toBe('A test skill');
    });

    it('should update an existing component', async () => {
      const component: Component = {
        id: 'test-id-1',
        type: 'skill',
        name: 'test-skill',
        path: '/test/path',
        relativePath: 'test/path',
        metadata: { name: 'test-skill', version: '1.0.0' },
        discoveredAt: new Date(),
        lastModified: new Date(),
        isActive: true,
      };

      await db.insert(component);

      // Update the component
      component.metadata.version = '2.0.0';
      component.metadata.description = 'Updated description';
      await db.update(component);

      const retrieved = await db.getById('test-id-1');
      expect(retrieved?.metadata.version).toBe('2.0.0');
      expect(retrieved?.metadata.description).toBe('Updated description');
    });

    it('should mark a component as inactive', async () => {
      const component: Component = {
        id: 'test-id-1',
        type: 'skill',
        name: 'test-skill',
        path: '/test/path',
        relativePath: 'test/path',
        metadata: { name: 'test-skill' },
        discoveredAt: new Date(),
        lastModified: new Date(),
        isActive: true,
      };

      await db.insert(component);
      await db.markInactive('test-id-1');

      const retrieved = await db.getById('test-id-1');
      expect(retrieved?.isActive).toBe(false);

      // Should not appear in getAll() results
      const allActive = await db.getAll();
      expect(allActive).toHaveLength(0);
    });
  });

  describe('query', () => {
    beforeEach(async () => {
      // Insert test data
      const components: Component[] = [
        {
          id: 'skill-1',
          type: 'skill',
          name: 'auth-skill',
          path: '/test/auth',
          relativePath: 'test/auth',
          metadata: {
            name: 'auth-skill',
            description: 'Authentication utilities',
            language: 'typescript',
          },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
        {
          id: 'agent-1',
          type: 'agent',
          name: 'db-agent',
          path: '/test/db',
          relativePath: 'test/db',
          metadata: {
            name: 'db-agent',
            description: 'Database management agent',
            language: 'typescript',
          },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
        {
          id: 'cli-1',
          type: 'cli',
          name: 'deploy-cli',
          path: '/test/deploy',
          relativePath: 'test/deploy',
          metadata: {
            name: 'deploy-cli',
            description: 'Deployment command-line tool',
            language: 'javascript',
          },
          discoveredAt: new Date(),
          lastModified: new Date(),
          isActive: true,
        },
      ];

      for (const component of components) {
        await db.insert(component);
      }
    });

    it('should filter by type', async () => {
      const skills = await db.query({ type: ['skill'] });
      expect(skills).toHaveLength(1);
      expect(skills[0].type).toBe('skill');

      const agentsAndClis = await db.query({ type: ['agent', 'cli'] });
      expect(agentsAndClis).toHaveLength(2);
    });

    it('should filter by language', async () => {
      const tsComponents = await db.query({ language: 'typescript' });
      expect(tsComponents).toHaveLength(2);

      const jsComponents = await db.query({ language: 'javascript' });
      expect(jsComponents).toHaveLength(1);
    });

    it('should filter by name', async () => {
      const authResults = await db.query({ name: 'auth' });
      expect(authResults).toHaveLength(1);
      expect(authResults[0].name).toBe('auth-skill');
    });

    it('should support pagination', async () => {
      const page1 = await db.query({ limit: 2, offset: 0 });
      expect(page1).toHaveLength(2);

      const page2 = await db.query({ limit: 2, offset: 2 });
      expect(page2).toHaveLength(1);
    });

    it('should support fuzzy matching with keywords', async () => {
      const results = await db.query({
        keywords: ['database'],
        fuzzyMatch: true,
      });
      expect(results.length).toBeGreaterThan(0);
      expect(results[0].name).toBe('db-agent');
    });
  });
});
