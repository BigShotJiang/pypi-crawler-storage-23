# Skills & Agents Inventory System

Automated discovery, indexing, and online deployment of skills, agents, and CLI tools developed across the GitHub workspace.

## Features

- **Automated Discovery**: Scans workspace to identify skills, agents, and CLI tools
- **Cross-Platform**: Works on Windows, WSL, and Linux with intelligent path resolution
- **Rich Metadata**: Extracts comprehensive information from package.json, README, and config files
- **REST API**: Query inventory through a high-performance Fastify-based service
- **CLI Integration**: Command-line tools for searching and managing the inventory
- **Efficient Storage**: SQLite database with full-text search capabilities

## Installation

```bash
npm install
npm run build
```

## Quick Start

### Start the Inventory Service

```bash
npm run start:server
```

### Use the CLI

```bash
# Search for components
npm run start:cli search authentication

# List all components
npm run start:cli list

# Show component details
npm run start:cli show <component-id>

# Refresh inventory
npm run start:cli refresh
```

## Development

```bash
# Build TypeScript
npm run build

# Watch mode
npm run dev

# Run tests
npm test

# Run tests in watch mode
npm test:watch

# Generate coverage report
npm test:coverage
```

## Configuration

Configuration can be provided via environment variables or a `.inventory.config.json` file in the workspace root.

See documentation for full configuration options.

## Project Structure

```
src/
├── core/         # Core utilities (path resolution, config)
├── types/        # TypeScript type definitions
├── discovery/    # Discovery engine and metadata extractors
├── database/     # SQLite database layer
├── api/          # REST API service
└── cli/          # CLI integration
```

## License

MIT
