# Complete Tooling Inventory — Your Workspace

**Generated:** 2026-02-09
**Purpose:** Complete inventory of all tools, scripts, and capabilities

---

## 1. Workspace Scripts (33 tools in `scripts/`)

### Multi-Repo Management
- `pull-all.sh` — Pull all repos in workspace
- `status-all.sh` — Status check across all repos
- `workspace-main` — Main workspace CLI
- `workspace-simplified` — Simplified workspace commands
- `workspace-minimal` — Minimal workspace interface
- `workspace-api.sh` — Workspace API interface

### Publishing & Distribution
- `publish-npm.sh` — Publish packages to npm

### Validation & Quality
- `validate-enhanced.sh` — Enhanced validation
- `validate-versions.sh` — Version consistency checks
- `validate-all-projects.sh` — Validate all projects
- `version-check.sh` — Version checking
- `analyze-component-quality.sh` — Component quality analysis
- `generate-validation-report.sh` — Generate validation reports
- `health-check.sh` — Workspace health check

### Security
- `security-preflight.sh` — Security scan before commits
- `manage-secrets.sh` — Secret management
- `scan-credentials.sh` — Credential scanning

### Ecosystem Management
- `ecosystem_audit.py` — Complete ecosystem audit (Python)
- `consolidation_toolbox.py` — Doc auditing (Python)
- `ecosystem-audit.sh` — Ecosystem audit wrapper

### Morphism-Specific
- `morphism-dashboard.sh` — Morphism dashboard
- `export-inventory.sh` — Export component inventory
- `search-components.sh` — Search components

### Governance
- `check-agents-pointers.sh` — Validate AGENTS.md pointers
- `enforce-professional-standards.sh` — Enforce standards
- `worktree-agents.sh` — Git worktree for agents

### Utilities
- `cleanup-workspace.sh` — Clean workspace
- `install-hooks.sh` — Install git hooks

---

## 2. Morphism Framework Tools (64 tools in `morphism/.validation/`)

### Quality Gates
- `quality-check-fast.sh` — Fast quality check
- `quality-check-strict.sh` — Strict quality check
- `run-optimization-plan.sh` — Run optimization plan (Bash)
- `run-optimization-plan.ps1` — Run optimization plan (PowerShell)

### Validation Suite
- `validate-all.sh` — Run all validations
- `check-structure.sh` — Structure validation
- `check-drift.sh` — Drift detection
- `validate-template.sh` — Template validation
- `validate-mode.sh` — Mode validation
- `validate-context.sh` — Context validation
- `validate-context.py` — Context validation (Python)

### Python Validators
- `validate_freshness.py` — Check doc freshness
- `validate_circular_refs.py` — Circular reference detection
- `validate_layer_consistency.py` — Layer consistency
- `validate_semver.py` — Semantic versioning validation
- `audit-dependencies.py` — Dependency auditing
- `check-doc-todos.py` — TODO tracking in docs
- `list-scoped-files.py` — List files in scope
- `scan-duplication-hotspots.py` — Find duplication
- `scan-error-handling.py` — Error handling analysis

### Security & Secrets
- `check-secrets.sh` — Secret scanning
- `check-duplicate-remotes.sh` — Duplicate remote detection

### Naming & Structure
- `check-naming.sh` — Naming convention enforcement
- `check-package-structure.sh` — Package structure validation
- `check-boundaries.sh` — Boundary enforcement

### Documentation
- `check-all-docs.sh` — All doc checks
- `check-docs-governance.sh` — Doc governance

### Profile/Personal Data Protection
- `check-profile-boundaries.sh` — Profile boundary enforcement
- `pre-commit-profile-check.sh` — Pre-commit profile check
- `sanitize-profile.sh` — Sanitize profile data

### LLM Governance (26 specialized checks)
- `check-llm-alignment.sh` — LLM alignment
- `check-llm-change-management.sh` — Change management
- `check-llm-cost-efficiency.sh` — Cost efficiency
- `check-llm-deployment.sh` — Deployment checks
- `check-llm-documentation.sh` — Documentation
- `check-llm-ethics.sh` — Ethics compliance
- `check-llm-evaluation.sh` — Evaluation standards
- `check-llm-explainability.sh` — Explainability
- `check-llm-feedback-loops.sh` — Feedback loops
- `check-llm-governance.sh` — Governance
- `check-llm-human-oversight.sh` — Human oversight
- `check-llm-incident-response.sh` — Incident response
- `check-llm-legal-review.sh` — Legal review
- `check-llm-monitoring.sh` — Monitoring
- `check-llm-observability.sh` — Observability
- `check-llm-output.sh` — Output validation
- `check-llm-regulatory-compliance.sh` — Regulatory compliance
- `check-llm-reproducibility.sh` — Reproducibility
- `check-llm-retirement.sh` — Model retirement
- `check-llm-risk-management.sh` — Risk management
- `check-llm-scalability.sh` — Scalability
- `check-llm-security.sh` — Security
- `check-llm-training-data-management.sh` — Training data
- `check-llm-versioning.sh` — Versioning

### Ship Checklist
- `check-ship-checklist.sh` — Pre-ship validation

---

## 3. Morphism CLI Commands (16 commands)

### Governance
- `morphism tenet` — View and manage tenets
- `morphism validate` — Run validation checks
- `morphism drift` — Check for governance drift
- `morphism baseline` — Manage governance baselines

### Development
- `morphism session` — Initialize and manage dev sessions
- `morphism scope` — Define and check scope boundaries
- `morphism promote` — Promote code through layers
- `morphism review` — Code review assistance

### Project
- `morphism init` — Initialize new project
- `morphism setup` — Run setup scripts
- `morphism status` — Show project status
- `morphism config` — Manage configuration

### Documentation
- `morphism docs` — View documentation
- `morphism guide` — Show guides and tutorials
- `morphism help` — Get help on commands
- `morphism test` — Run CLI tests

**Run from:** `cd morphism && pnpm run morphism:<command>`

---

## 4. .morphism/ Configuration System

### Structure
```
.morphism/
├── config.json              — Consumer configuration
├── README.md                — Configuration guide
├── CHANGELOG.md             — Change history
├── access-control.yml       — Access control rules
├── credential-provider.sh   — Credential management
├── mcp-credentials.json     — MCP credentials
├── agents/                  — Agent configurations
├── changelogs/              — Component changelogs
├── docs/                    — Configuration docs
├── extensions/              — MCP extensions
├── hooks/                   — Git hooks
├── inventory/               — Component registry (39 components)
├── metrics/                 — Usage metrics
├── schemas/                 — JSON schemas
├── secrets/                 — Secret storage (gitignored)
└── workflows/               — Workflow definitions
```

### Key Files
- **config.json** — Points to framework source, defines discovery paths
- **inventory/INVENTORY.md** — 39 tracked components
- **inventory/MATURITY.md** — Component maturity levels
- **inventory/dependencies.json** — Dependency graph

---

## 5. Kiro CLI Configuration (~/.kiro/)

### Steering Files (3)
- `agentic-math-prompt.md` — Agentic math specialist prompt
- `docx.md` — Word document creation/editing skill
- `global-standards.md` — Global development standards

### Skills
- Managed via `~/.kiro/skills/`
- Registry: `registry.json`
- Installed: `installed.json`

### Powers (MCP Servers)
- Managed via `~/.kiro/powers/`
- Registry: `registry.json`

### Settings
- `~/.kiro/settings/` — Kiro CLI settings

---

## 6. Quick Command Reference

### Run Ecosystem Audit
```bash
cd /mnt/c/Users/mesha/Desktop/GitHub
python3 scripts/ecosystem_audit.py all
```

### Run Morphism Validation
```bash
cd morphism
pnpm run morphism:validate
```

### Check Drift
```bash
cd morphism
pnpm run drift:check
```

### Run Quality Gates
```bash
cd morphism
pnpm run quality:check:fast    # Fast
pnpm run quality:check:strict  # Strict
```

### Security Scan
```bash
bash scripts/security-preflight.sh
```

### Workspace Status
```bash
bash scripts/status-all.sh
```

### Pull All Repos
```bash
bash scripts/pull-all.sh
```

### Publish to npm
```bash
bash scripts/publish-npm.sh
```

---

## 7. What Can Be Configured

### A. Add New Kiro Skills
Skills are markdown files that extend Kiro's capabilities.

**Location:** `~/.kiro/steering/`

**Example:** The `docx.md` skill teaches Kiro how to create Word documents.

**To add a new skill:** Create a markdown file in `~/.kiro/steering/` with:
```markdown
---
name: skill-name
description: "What this skill does"
---

# Skill instructions here
```

### B. Add MCP Servers
MCP servers extend Kiro with external tools.

**Location:** `~/.kiro/powers/`

**Registry:** `~/.kiro/powers/registry.json`

**To add:** Follow MCP server installation docs (varies per server)

### C. Configure Morphism Governance
**Location:** `.morphism/config.json`

**What you can configure:**
- Framework source (local vs npm)
- Discovery paths (agents, skills, workflows)
- Validation rules
- Compatibility targets

### D. Add Workspace Scripts
**Location:** `scripts/`

**Pattern:** Create executable bash/python scripts, make them executable:
```bash
chmod +x scripts/my-new-script.sh
```

---

## 8. Summary Stats

| Category | Count |
|----------|-------|
| Workspace scripts | 33 |
| Morphism validation tools | 64 |
| Morphism CLI commands | 16 |
| .morphism tracked components | 39 |
| Kiro steering files | 3 |
| Total automation tools | 155+ |

---

## Next Steps

1. **Explore a tool:** Pick any script and run it to see what it does
2. **Add a skill:** Create a new steering file in `~/.kiro/steering/`
3. **Configure Morphism:** Edit `.morphism/config.json` to customize governance
4. **Run validations:** Try `pnpm run morphism:validate` in the morphism directory

All tools are documented. Check README files in each directory for details.
