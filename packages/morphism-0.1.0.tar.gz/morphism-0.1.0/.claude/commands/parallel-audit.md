# Parallel Multi-repo Audit

Launch governance audits across multiple repos. Read-only — does not modify any repo.

## Steps

1. Ask the user for repo root paths, or auto-detect sibling directories of this repo that contain `AGENTS.md`:
   ```bash
   for dir in ../*/; do [ -f "$dir/AGENTS.md" ] && echo "$dir"; done
   ```

2. For each repo path, run (in parallel if using Claude Code Task agents):
   ```bash
   cd <REPO_PATH>
   echo "=== $(basename $(pwd)) ==="
   git rev-parse --abbrev-ref HEAD
   python3 scripts/ssot_verify.py 2>&1 || echo "SSOT verify: N/A"
   python3 scripts/policy_check.py --mode ci --explain 2>&1 || echo "Policy check: N/A"
   python3 scripts/verify_pipeline.py 2>&1 || echo "Pipeline verify: N/A"
   ```

3. Produce a consolidated report:

| Repo | Branch | SSOT | Policy | Pipeline | Notes |
|------|--------|------|--------|----------|-------|
| repo-a | main | PASS | PASS | PASS | clean |
| repo-b | feat/x | FAIL | PASS | PASS | drift in AGENTS.md |

4. For any failures, list the specific error and affected repo.

## Notes
- Do not modify any repo during an audit.
- If a repo lacks a script, mark that check as N/A.
