# Session Bootstrap

Establish current context before taking any action. Run these steps in order:

1. Run `git log --oneline -15` and summarize recent work.
2. Run `git status` and report current branch and any uncommitted changes.
3. Run `git diff --stat HEAD~5` to see recent change patterns.
4. Read `docs/HANDOFF_STATE.md` if it exists. Summarize what the last session left.
5. Read `docs/TODO.md` and list any P0 or P1 items.
6. Read `AGENTS.md` to refresh governance context.

Produce a brief status report:

---

## Session Bootstrap — [DATE]
- **Branch:** [BRANCH]
- **Last 3 commits:** [SUMMARIES]
- **Uncommitted changes:** [YES/NO]
- **Prior handoff:** [SUMMARY or "none found"]
- **Active P0/P1 items:** [COUNT and summaries]
- **Ready for:** [what the user likely needs based on context]

---

Do NOT take any other action until this bootstrap is complete.
