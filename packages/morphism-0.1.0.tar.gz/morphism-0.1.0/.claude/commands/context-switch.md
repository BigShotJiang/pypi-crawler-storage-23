# Context Switch

Load baseline after switching from Cursor or another agent. Run these steps in order:

1. Read governance docs: AGENTS.md, SSOT.md, GUIDELINES.md, docs/HANDOFF.md, docs/TODO.md.
2. Run `git status` — check for uncommitted work left by the previous agent.
3. Run `git log --oneline -10` — understand what was done recently.
4. Read `docs/HANDOFF_STATE.md` if it exists — pick up where the last session left off.
5. Run `git stash list` — check for stashed changes.
6. Run `git diff --stat` — see any pending modifications.

Produce a status report:

---

## Context Switch — [DATE]
- **Switching from:** [PREVIOUS AGENT]
- **Branch:** [BRANCH]
- **Last 3 commits:** [SUMMARIES]
- **Uncommitted changes:** [YES/NO — list files if yes]
- **Stashed changes:** [YES/NO]
- **Prior handoff:** [SUMMARY or "none found"]
- **Active P0/P1 items:** [COUNT and summaries]
- **Ready for:** [what the user likely needs based on context]

---

Use the same governance and work style: execute don't plan, one change at a time, verify after each change. Do NOT take any other action until this context switch is complete.
