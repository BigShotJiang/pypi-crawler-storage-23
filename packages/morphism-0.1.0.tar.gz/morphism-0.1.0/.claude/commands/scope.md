# Task Scope

Bind scope for a single task before executing. Run these steps in order:

1. Ask the user: "What is the one thing?" — get a single-sentence goal.
2. Ask the user: "What does done mean?" — get a testable condition.
3. List in-scope files/systems and explicitly state what is out of scope.
4. Identify the relevant test/lint command:
   - TypeScript: `npx turbo typecheck && npx turbo lint`
   - Python: `ruff check <file> && mypy <file>`
   - Governance/docs: `python3 scripts/verify_pipeline.py`
5. Execute the smallest complete change, run verification, then proceed to the next change.
6. If the change would touch more than 3 files, stop and confirm scope with the user before proceeding.

Produce a scope card:

---

## Scope — [GOAL]
- **One thing:** [SINGLE-SENTENCE GOAL]
- **Done means:** [TESTABLE CONDITION]
- **In scope:** [FILES/SYSTEMS]
- **Out of scope:** [EXPLICITLY EXCLUDED]
- **Verify with:** [TEST COMMAND]

---

Do not plan or batch changes. Execute one change at a time. If stuck after 2 attempts, stop and ask the user for direction.
