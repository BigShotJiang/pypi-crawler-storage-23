# Full Governance Audit

Run the complete governance validation pipeline and report results.

1. `python scripts/ssot_extract.py` — extract SSOT atoms
2. `python scripts/ssot_verify.py` — verify atom hashes
3. `python scripts/docs_sync.py --check` — check docs sync
4. `python scripts/docs_graph.py --check` — check doc graph (orphans, broken refs)
5. `python scripts/maturity_score.py --ci --threshold 60` — maturity score gate
6. `python scripts/policy_check.py --mode ci --explain` — policy compliance
7. `python scripts/verify_pipeline.py` — pipeline verification
8. `npx @morphism-systems/cli doctor` — CLI self-check (dog-food)

Produce a summary table:

| Check | Status | Notes |
|-------|--------|-------|
| SSOT extract | PASS/FAIL | ... |
| SSOT verify | PASS/FAIL | ... |
| Docs sync | PASS/FAIL | ... |
| Docs graph | PASS/FAIL | ... |
| Maturity score | PASS/FAIL (score: N/125) | ... |
| Policy check | PASS/FAIL | ... |
| Pipeline verify | PASS/FAIL | ... |
| CLI doctor | PASS/FAIL | ... |

If any check fails, list the specific error and suggest the fix.
