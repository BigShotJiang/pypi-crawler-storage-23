# Quick Governance Check

Run the minimum governance checks needed before a commit or PR.

1. `python scripts/ssot_verify.py` — verify SSOT atoms are current
2. `python scripts/policy_check.py --mode ci --explain` — policy compliance
3. `python scripts/verify_pipeline.py` — pipeline integrity

Report pass/fail for each. If all pass, say "Governance check passed — safe to commit."
If any fail, report the error and suggest a fix before proceeding.
