# Governance Baseline

Prepare for a structural or governance change. Run these steps before executing anything:

1. Read governance docs: AGENTS.md, SSOT.md, GUIDELINES.md.
2. Read docs/HANDOFF.md and docs/TODO.md for current state and deferred work.
3. State the one thing being changed and why.
4. List files and tools in scope. Explicitly state what is out of scope.
5. Run `python3 scripts/ssot_verify.py` — confirm SSOT atoms are current.
6. Run `python3 scripts/policy_check.py --mode ci --explain` — confirm policy compliance.

Produce a baseline card:

---

## Governance Baseline — [DATE]
- **Change:** [ONE-SENTENCE DESCRIPTION]
- **Rationale:** [WHY]
- **In scope:** [FILES/TOOLS]
- **Out of scope:** [EXPLICITLY EXCLUDED]
- **SSOT verify:** [PASS/FAIL]
- **Policy check:** [PASS/FAIL]
- **Cleared to proceed:** [YES/NO]

---

If either check fails, report the error and fix it before proceeding. Do not execute the structural change until this baseline passes. One change at a time; verify after each change. Refuse scope creep.
