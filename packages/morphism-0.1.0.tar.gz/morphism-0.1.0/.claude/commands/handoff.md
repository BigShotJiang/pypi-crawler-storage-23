# Session Handoff

Generate a session handoff document. Run these steps:

1. Run `git status` to capture current branch and uncommitted changes.
2. Run `git log --oneline -10` to capture recent commits.
3. Run `git diff --stat` to capture pending changes summary.
4. Write the following template to `docs/HANDOFF_STATE.md`, filling in values:

---

# Session Handoff — [DATE]

## What was done this session
- (summarize commits and changes made)

## What remains
- (list incomplete work items)

## Current state
- Branch: [BRANCH]
- Uncommitted changes: [YES/NO — list files if yes]
- Tests passing: [YES/NO]

## Blockers
- (any blockers encountered)

## Next steps
- (1-3 concrete next actions with file paths)

---

5. Stage and commit: `git add docs/HANDOFF_STATE.md && git commit -m "docs: session handoff state"`
