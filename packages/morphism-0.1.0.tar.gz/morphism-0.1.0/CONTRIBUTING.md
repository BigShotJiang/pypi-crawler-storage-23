# Contributing to Morphism

We welcome contributions! Here's how to get started.

## Development Setup

### Prerequisites

- Node.js 20+, npm 10+
- Python 3.11+
- Git

### Quick Start

```bash
# Clone and install
git clone https://github.com/morphism-systems/morphism.git
cd morphism
npm install

# Build and test
npx turbo build
npx turbo test

# Python setup
pip install -e ".[dev]"
pytest tests/
```

### Architecture Overview

```
morphism-systems/
├── apps/morphism/          # Next.js 15 SaaS app
├── packages/
│   ├── shared/             # @morphism-systems/shared — shared types & schemas
│   ├── agentic-math/       # @morphism-systems/agentic-math — MCP math server
│   ├── mcp-server/         # @morphism-systems/mcp-server — governance MCP server
│   ├── cli/                # @morphism-systems/cli — governance CLI
│   └── plugin-bundle/      # @morphism-systems/plugin-bundle — one-command installer
├── src/morphism/           # Python category theory engine
├── scripts/                # Governance validation scripts
└── docs/                   # Documentation
```

## How to Contribute

1. Fork the repository
2. Create a branch: `feat/my-feature` or `fix/my-bug` (see [GUIDELINES.md](GUIDELINES.md))
3. Make your changes and commit with conventional commits
4. Run tests: `npx turbo test && pytest tests/`
5. Push and create a pull request

## Good First Issues

Look for issues labeled `good first issue` on GitHub. Common entry points:

- **Documentation:** Improve READMEs, add examples, fix broken links
- **Tests:** Add test coverage for existing code
- **TypeScript:** Add Zod schemas or type improvements to packages
- **Python:** Add metrics or CLI commands

## Code Style

- **TypeScript:** ESLint + Prettier, enforced by `npx turbo lint`
- **Python:** Ruff + mypy, enforced by `ruff check src/ tests/ && mypy src/`
- **Commits:** Conventional commits (`feat:`, `fix:`, `docs:`, etc.)
- **Branches:** `feat/`, `fix/`, `docs/`, `chore/` prefixes

See [GUIDELINES.md](GUIDELINES.md) for full conventions.

## Governance

Changes to governance documents (AGENTS.md, SSOT.md, kernel) require review. Run `python3 scripts/verify_pipeline.py` before submitting PRs that touch governance.

## Drift Detection

CI runs a drift detector on every PR. If it fails, fix the reported issues before merging. Run locally:

```bash
python3 scripts/drift_detector.py
```

## Questions?

Open an issue on GitHub or reach out at hello@morphism.systems.
