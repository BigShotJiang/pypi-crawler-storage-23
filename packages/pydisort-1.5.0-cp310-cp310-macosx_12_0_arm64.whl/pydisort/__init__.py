import torch
from .pydisort import *

__version__ = "1.5.0"
