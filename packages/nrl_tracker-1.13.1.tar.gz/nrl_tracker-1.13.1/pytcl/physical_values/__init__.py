"""physical_values module."""

__all__ = []
