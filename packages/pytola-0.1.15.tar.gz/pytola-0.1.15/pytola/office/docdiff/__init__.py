"""Docdiff module."""
