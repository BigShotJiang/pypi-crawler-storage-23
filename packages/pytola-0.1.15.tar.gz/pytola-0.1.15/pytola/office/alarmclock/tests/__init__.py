"""Tests for alarmclock module."""
