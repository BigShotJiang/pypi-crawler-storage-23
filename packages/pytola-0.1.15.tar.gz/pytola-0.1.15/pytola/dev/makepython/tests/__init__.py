"""Tests for MakePython."""
