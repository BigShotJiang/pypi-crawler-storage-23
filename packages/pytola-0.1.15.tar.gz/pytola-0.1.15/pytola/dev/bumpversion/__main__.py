"""Entry point for running bumpversion as a module."""

from .cli import main

if __name__ == "__main__":
    main()
