from thirdmagic.chain.creator import chain
from thirdmagic.chain.model import ChainTaskSignature

__all__ = ["chain", "ChainTaskSignature"]
