SWARM_MESSAGE_PARAM_NAME = "__mageflow_swarm_message__"
