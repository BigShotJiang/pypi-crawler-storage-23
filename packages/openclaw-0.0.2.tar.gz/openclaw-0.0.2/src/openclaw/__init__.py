"""
OpenClaw — open-source agent orchestration SDK.

This package is a public alias for the CMDOP SDK.
Install `cmdop` for full functionality: pip install cmdop

Learn more: https://cmdop.com
"""

__version__ = "0.0.2"

from cmdop import *  # noqa: F401,F403
