import fnmatch
import os
import pathlib
import shutil
import sys
from collections.abc import Generator
from typing import Protocol

from iker.common.utils.strutils import is_empty

__all__ = [
    "make_path",
    "fn_suffix",
    "fn_suffixes",
    "fn_stem",
    "path_depth",
    "glob_match",
    "scan_files",
    "copy_files",
]


def make_path(
    path: str | os.PathLike[str] | None,
    *,
    expand: bool = False,
    normalize: bool = False,
    absolute: bool = False,
    resolve: bool = False,
    check_exists: bool = False,
    check_is_dir: bool = False,
    check_is_file: bool = False,
) -> pathlib.Path | None:
    """
    Creates a ``pathlib.Path`` object from the given path string or path-like object, applying the specified
    transformations and checks.

    :param path: The path string or path-like object to convert to a ``pathlib.Path`` object.
    :param expand: If ``True``, expands environment variables and user home directory in the path.
    :param normalize: If ``True``, normalizes the path by collapsing redundant separators and up-level references.
    :param absolute: If ``True``, converts the path to an absolute path.
    :param resolve: If ``True``, resolves symbolic links and returns the canonical path.
    :param check_exists: If ``True``, checks if the path exists and raises a ``FileNotFoundError`` if it does not.
    :param check_is_dir: If ``True``, checks if the path is a directory and raises a ``NotADirectoryError`` if it is not.
    :param check_is_file: If ``True``, checks if the path is a file and raises a ``FileNotFoundError`` if it is not.
    :return: A ``pathlib.Path`` object representing the given path after applying the specified transformations and
    checks, or ``None`` if the input path is ``None``.
    """
    if path is None:
        return None
    path = os.fspath(path)

    if expand:
        path = os.path.expandvars(path)
        path = os.path.expanduser(path)
    if normalize:
        path = os.path.normpath(path)
    if absolute:
        path = os.path.abspath(path)
    if resolve:
        path = os.path.realpath(path)

    path = pathlib.Path(path)

    if check_exists and not path.exists():
        raise FileNotFoundError(f"path does not exist '{path}'")
    if check_is_dir and not path.is_dir():
        raise NotADirectoryError(f"path is not a directory '{path}'")
    if check_is_file and not path.is_file():
        raise FileNotFoundError(f"path is not a file '{path}'")

    return path


def fn_suffix(filename: str | os.PathLike[str] | None) -> str | None:
    """
    Extracts the filename suffix from the given filename or path.

    :param filename: The specific filename or path.
    :return: The filename suffix, including the leading dot (e.g., ".txt" for "file.txt"),
    or ``None`` if the input filename is ``None``.
    """
    if (path := make_path(filename)) is not None:
        if sys.version_info < (3, 14):
            _, suffix_name = os.path.splitext(path.name)
            return suffix_name
        else:
            return path.suffix
    return None


def fn_suffixes(filename: str | os.PathLike[str] | None) -> list[str]:
    """
    Extracts all filename suffixes from the given filename or path.

    :param filename: The specific filename or path.
    :return: A list of filename suffixes, each including the leading dot (e.g., [".tar", ".gz"] for "archive.tar.gz").
    """
    if (path := make_path(filename)) is not None:
        if sys.version_info < (3, 14):
            results = []
            stem_name = path.name
            while True:
                stem_name, suffix_name = os.path.splitext(stem_name)
                if is_empty(suffix_name):
                    return list(reversed(results))
                results.append(suffix_name)
        else:
            return path.suffixes
    return []


def fn_stem(filename: str | os.PathLike[str] | None, minimal: bool = False) -> str | None:
    """
    Extracts the filename stem from the given filename or path.

    :param filename: The specific filename or path.
    :param minimal: If ``True``, extracts the minimal (shortest) stem, otherwise the default stem.
    :return: The filename stem.
    """
    if (path := make_path(filename)) is not None:
        if sys.version_info < (3, 14):
            if not minimal:
                stem_name, _ = os.path.splitext(path.name)
                return stem_name
            else:
                stem_name = path.name
                while True:
                    stem_name, suffix_name = os.path.splitext(stem_name)
                    if is_empty(suffix_name):
                        return stem_name
        else:
            if not minimal:
                return path.stem
            else:
                while True:
                    if is_empty(path.suffix):
                        return path.stem
                    path = path.with_suffix("")
    return None


def path_depth(root: str | os.PathLike[str], child: str | os.PathLike[str]) -> int:
    """
    Returns the relative path depth from the given ``child`` to the ``root``.

    :param root: The root path.
    :param child: The child path.
    :return: Relative depth, or -1 if ``child`` is not under ``root``.
    """
    root = make_path(root, expand=True, resolve=True)
    child = make_path(child, expand=True, resolve=True)
    if not child.is_relative_to(root):
        return -1
    return len(child.relative_to(root).parts)


def glob_match(
    names: list[str],
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
) -> list[str]:
    """
    Applies the given inclusive and exclusive glob patterns to the given ``names`` and returns the filtered result.

    :param names: Names to apply the glob patterns to.
    :param include_patterns: Inclusive glob patterns.
    :param exclude_patterns: Exclusive glob patterns.
    :return: Filtered names matching the patterns.
    """
    ret = set()
    for pat in (include_patterns or []):
        ret.update(fnmatch.filter(names, pat))
    if include_patterns is None or len(include_patterns) == 0:
        ret.update(names)
    for pat in (exclude_patterns or []):
        ret.difference_update(fnmatch.filter(names, pat))
    return list(ret)


class CopyFuncProtocol(Protocol):
    def __call__(self, src: str | os.PathLike[str], dst: str | os.PathLike[str], **kwargs) -> None: ...


def scan_files(
    path: str | os.PathLike[str],
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    depth: int = 0,
) -> Generator[pathlib.Path, None, None]:
    """
    Recursively scans the given ``path`` and returns a list of files whose names satisfy the given name patterns and the
    relative depth of their folders to the given root path is not greater than the specified ``depth`` value.

    :param path: The root path to scan.
    :param include_patterns: Inclusive glob patterns applied to the filenames.
    :param exclude_patterns: Exclusive glob patterns applied to the filenames.
    :param depth: Maximum depth of the subdirectories included in the scan.
    :return: A generator yielding the paths of the files matching the patterns.
    """
    path = make_path(path, expand=True)
    if path.exists() and not path.is_dir():
        if len(glob_match([path.name], include_patterns, exclude_patterns)) == 0:
            return
        yield path

    for parent, dirs, filenames in path.walk():
        if 0 < depth <= path_depth(path, parent):
            continue
        for filename in glob_match(filenames, include_patterns, exclude_patterns):
            yield parent / filename


def copy_files(
    src: str | os.PathLike[str],
    dst: str | os.PathLike[str],
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    depth: int = 0,
    follow_symlinks: bool = False,
    ignore_dangling_symlinks: bool = False,
    dirs_exist_ok: bool = False,
    copy_func: CopyFuncProtocol = shutil.copy2
):
    """
    Recursively copies the given source path to the destination path. Only copies the files whose names satisfy the
    given name patterns and the relative depth of their folders to the given source path is not greater than the
    specified ``depth`` value.

    :param src: The source path or file.
    :param dst: The destination path or file.
    :param include_patterns: Inclusive glob patterns applied to the filenames.
    :param exclude_patterns: Exclusive glob patterns applied to the filenames.
    :param depth: Maximum depth of the subdirectories included in the scan.
    :param follow_symlinks: If ``True``, create symbolic links for the symbolic links present in the source; otherwise,
    make a physical copy.
    :param ignore_dangling_symlinks: If ``True``, ignore errors if the file pointed by the symbolic link does not exist.
    :param dirs_exist_ok: If ``True``, ignore errors if the destination directory and subdirectories exist.
    :param copy_func: Copy function to use for copying files.
    """
    src = make_path(src, expand=True)
    dst = make_path(dst, expand=True)
    if not src.is_dir():
        if len(glob_match([src.name], include_patterns, exclude_patterns)) == 0:
            return
        if not dst.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
        copy_func(src, dst, follow_symlinks=follow_symlinks)
        return

    def ignore_func(parent: str | os.PathLike[str], names: list[str]) -> set[str]:
        parent = make_path(parent, expand=True)
        filenames = list(filter(lambda x: not (parent / x).is_dir(), names))
        ret = set(filenames)
        if 0 < depth <= path_depth(src, parent):
            return ret
        ret.difference_update(glob_match(filenames, include_patterns, exclude_patterns))
        return ret

    shutil.copytree(src,
                    dst,
                    symlinks=follow_symlinks,
                    ignore=ignore_func,
                    ignore_dangling_symlinks=ignore_dangling_symlinks,
                    dirs_exist_ok=dirs_exist_ok,
                    copy_function=copy_func)
