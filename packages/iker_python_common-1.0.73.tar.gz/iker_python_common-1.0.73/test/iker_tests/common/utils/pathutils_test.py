import os
import pathlib
import tempfile
import unittest

import ddt

from iker.common.utils.pathutils import copy_files, scan_files
from iker.common.utils.pathutils import fn_stem, fn_suffix, fn_suffixes
from iker.common.utils.pathutils import glob_match
from iker.common.utils.pathutils import make_path, path_depth
from testenv import resources_directory

work_dir = pathlib.Path.cwd
home_dir = pathlib.Path.home


@ddt.ddt
class PathUtilsTest(unittest.TestCase):
    data_fn_suffix = [
        (None, None),
        ("", ""),
        (".", ""),
        ("..", ""),
        ("...", ""),
        (".ignored", ""),
        (".ignored.", "."),
        (".git.ignored", ".ignored"),
        ("..git.ignored", ".ignored"),
        ("..git..ignored", ".ignored"),
        ("git.ignored", ".ignored"),
        ("git.scrappy.ignored", ".ignored"),
        ("~/git.scrappy.ignored", ".ignored"),
        ("./git.scrappy.ignored", ".ignored"),
        ("../git.scrappy.ignored", ".ignored"),
        ("/~/git.scrappy.ignored", ".ignored"),
        ("/./git.scrappy.ignored", ".ignored"),
        ("/../git.scrappy.ignored", ".ignored"),
        ("/foo/bar/git.scrappy.ignored", ".ignored"),
        ("/foo/bar/~/git.scrappy.ignored", ".ignored"),
        ("/foo/bar/./git.scrappy.ignored", ".ignored"),
        ("/foo/bar/../git.scrappy.ignored", ".ignored"),
        ("/foo/bar/git.scrappy.ignored..baz.", "."),
        ("http://domain/foo/bar/git.scrappy.ignored", ".ignored"),
        ("s3://bucket/foo/bar/git.scrappy.ignored", ".ignored"),
    ]

    @ddt.idata(data_fn_suffix)
    @ddt.unpack
    def test_fn_suffix(self, data, expect):
        self.assertEqual(expect, fn_suffix(data))

    data_fn_suffixes = [
        (None, []),
        ("", []),
        (".", []),
        ("..", []),
        ("...", []),
        (".ignored", []),
        (".ignored.", ["."]),
        (".git.ignored", [".ignored"]),
        ("..git.ignored", [".ignored"]),
        ("..git..ignored", [".", ".ignored"]),
        ("git.ignored", [".ignored"]),
        ("git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("~/git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("./git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("../git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/~/git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/./git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/../git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/foo/bar/git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/foo/bar/~/git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/foo/bar/./git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/foo/bar/../git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("/foo/bar/git.scrappy.ignored..baz.", [".scrappy", ".ignored", ".", ".baz", "."]),
        ("http://domain/foo/bar/git.scrappy.ignored", [".scrappy", ".ignored"]),
        ("s3://bucket/foo/bar/git.scrappy.ignored", [".scrappy", ".ignored"]),
    ]

    @ddt.idata(data_fn_suffixes)
    @ddt.unpack
    def test_fn_suffixes(self, data, expect):
        self.assertEqual(expect, fn_suffixes(data))

    data_fn_stem = [
        (None, None),
        ("", ""),
        (".", ""),
        ("..", ".."),
        ("...", "..."),
        (".ignored", ".ignored"),
        (".ignored.", ".ignored"),
        (".git.ignored", ".git"),
        ("..git.ignored", "..git"),
        ("..git..ignored", "..git."),
        ("git.ignored", "git"),
        ("git.scrappy.ignored", "git.scrappy"),
        ("~/git.scrappy.ignored", "git.scrappy"),
        ("./git.scrappy.ignored", "git.scrappy"),
        ("../git.scrappy.ignored", "git.scrappy"),
        ("/~/git.scrappy.ignored", "git.scrappy"),
        ("/./git.scrappy.ignored", "git.scrappy"),
        ("/../git.scrappy.ignored", "git.scrappy"),
        ("/foo/bar/git.scrappy.ignored", "git.scrappy"),
        ("/foo/bar/~/git.scrappy.ignored", "git.scrappy"),
        ("/foo/bar/./git.scrappy.ignored", "git.scrappy"),
        ("/foo/bar/../git.scrappy.ignored", "git.scrappy"),
        ("/foo/bar/git.scrappy.ignored..baz.", "git.scrappy.ignored..baz"),
        ("http://domain/foo/bar/git.scrappy.ignored", "git.scrappy"),
        ("s3://bucket/foo/bar/git.scrappy.ignored", "git.scrappy"),
    ]

    @ddt.idata(data_fn_stem)
    @ddt.unpack
    def test_fn_stem(self, data, expect):
        self.assertEqual(expect, fn_stem(data))

    data_fn_stem__minimal = [
        (None, None),
        ("", ""),
        (".", ""),
        ("..", ".."),
        ("...", "..."),
        (".ignored", ".ignored"),
        (".ignored.", ".ignored"),
        (".git.ignored", ".git"),
        ("..git.ignored", "..git"),
        ("..git..ignored", "..git"),
        ("git.ignored", "git"),
        ("git.scrappy.ignored", "git"),
        ("~/git.scrappy.ignored", "git"),
        ("./git.scrappy.ignored", "git"),
        ("../git.scrappy.ignored", "git"),
        ("/~/git.scrappy.ignored", "git"),
        ("/./git.scrappy.ignored", "git"),
        ("/../git.scrappy.ignored", "git"),
        ("/foo/bar/git.scrappy.ignored", "git"),
        ("/foo/bar/~/git.scrappy.ignored", "git"),
        ("/foo/bar/./git.scrappy.ignored", "git"),
        ("/foo/bar/../git.scrappy.ignored", "git"),
        ("/foo/bar/git.scrappy.ignored..baz.", "git"),
        ("http://domain/foo/bar/git.scrappy.ignored", "git"),
        ("s3://bucket/foo/bar/git.scrappy.ignored", "git"),
    ]

    @ddt.idata(data_fn_stem__minimal)
    @ddt.unpack
    def test_fn_stem__minimal(self, data, expect):
        self.assertEqual(expect, fn_stem(data, minimal=True))

    data_make_path = [
        (".", f"{work_dir()}"),
        ("./", f"{work_dir()}"),
        ("./foo", f"{work_dir()}/foo"),
        ("./foo.bar", f"{work_dir()}/foo.bar"),
        ("./foo/..", f"{work_dir()}"),
        ("./foo/../bar", f"{work_dir()}/bar"),
        ("./foo/../bar/..", f"{work_dir()}"),
        ("~", f"{home_dir()}"),
        ("~/", f"{home_dir()}"),
        ("~/foo", f"{home_dir()}/foo"),
        ("~/foo.bar", f"{home_dir()}/foo.bar"),
        ("~/foo/..", f"{home_dir()}"),
        ("~/foo/../bar", f"{home_dir()}/bar"),
        ("~/foo/../bar/..", f"{home_dir()}"),
        ("", f"{work_dir()}"),
        ("/", f"/"),
        ("/foo", f"/foo"),
        ("/foo.bar", f"/foo.bar"),
        ("/foo/..", f"/"),
        ("/foo/../bar", f"/bar"),
        ("/foo/../bar/..", f"/"),
        ("${DUMMY_ENV_PARAM}", f"{work_dir()}/dummy_parent"),
        ("${DUMMY_ENV_PARAM}/", f"{work_dir()}/dummy_parent"),
        ("${DUMMY_ENV_PARAM}/foo", f"{work_dir()}/dummy_parent/foo"),
        ("${DUMMY_ENV_PARAM}/foo.bar", f"{work_dir()}/dummy_parent/foo.bar"),
        ("${DUMMY_ENV_PARAM}/foo/..", f"{work_dir()}/dummy_parent"),
        ("${DUMMY_ENV_PARAM}/foo/../bar", f"{work_dir()}/dummy_parent/bar"),
        ("${DUMMY_ENV_PARAM}/foo/../bar/..", f"{work_dir()}/dummy_parent"),
        ("${LOST_ENV_PARAM}", f"{work_dir()}/${{LOST_ENV_PARAM}}"),
        ("${LOST_ENV_PARAM}/", f"{work_dir()}/${{LOST_ENV_PARAM}}"),
        ("${LOST_ENV_PARAM}/foo", f"{work_dir()}/${{LOST_ENV_PARAM}}/foo"),
        ("${LOST_ENV_PARAM}/foo.bar", f"{work_dir()}/${{LOST_ENV_PARAM}}/foo.bar"),
        ("${LOST_ENV_PARAM}/foo/..", f"{work_dir()}/${{LOST_ENV_PARAM}}"),
        ("${LOST_ENV_PARAM}/foo/../bar", f"{work_dir()}/${{LOST_ENV_PARAM}}/bar"),
        ("${LOST_ENV_PARAM}/foo/../bar/..", f"{work_dir()}/${{LOST_ENV_PARAM}}"),
        ("${EMPTY_ENV_PARAM}", f"{work_dir()}"),
        ("${EMPTY_ENV_PARAM}/", f"/"),
        ("${EMPTY_ENV_PARAM}/foo", f"/foo"),
        ("${EMPTY_ENV_PARAM}/foo.bar", f"/foo.bar"),
        ("${EMPTY_ENV_PARAM}/foo/..", f"/"),
        ("${EMPTY_ENV_PARAM}/foo/../bar", f"/bar"),
        ("${EMPTY_ENV_PARAM}/foo/../bar/..", f"/"),
    ]

    @ddt.idata(data_make_path)
    @ddt.unpack
    def test_make_path(self, data, expect):
        os.environ["DUMMY_ENV_PARAM"] = "dummy_parent"
        os.environ["EMPTY_ENV_PARAM"] = ""

        self.assertEqual(make_path(expect), make_path(expect, normalize=True))
        self.assertEqual(make_path(expect), make_path(data, expand=True, normalize=True, absolute=True, resolve=True))

        if not make_path(expect).exists():
            with self.assertRaises(FileNotFoundError):
                make_path(expect, check_exists=True)
            with self.assertRaises(NotADirectoryError):
                make_path(expect, check_is_dir=True)
            with self.assertRaises(FileNotFoundError):
                make_path(expect, check_is_file=True)

    data_path_depth = [
        (".", ".", 0),
        ("..", "..", 0),
        ("/..", "/", 0),
        ("/", "/..", 0),
        ("foo/..", "bar/..", 0),
        ("/foo/bar/../..", "/foo/../bar/..", 0),
        ("/foo/../bar/..", "/foo/bar/../..", 0),
        ("././././.", "", 0),
        ("", "././././.", 0),
        ("foo/bar/baz", "foo/bar/baz/", 0),
        ("foo/bar/baz/", "foo/bar/baz", 0),

        ("foo", "foo/bar", 1),
        ("foo", "foo/bar/baz", 2),
        ("foo", "foo/bar/../baz", 1),
        ("foo", "foo/bar/../baz/..", 0),
        ("/foo", "/foo/bar", 1),
        ("/foo", "/foo/bar/baz", 2),
        ("/foo", "/foo/bar/../baz", 1),
        ("/foo", "/foo/bar/../baz/..", 0),

        ("foo", "bar", -1),
        ("foo/bar", "foo/baz", -1),
    ]

    @ddt.idata(data_path_depth)
    @ddt.unpack
    def test_path_depth(self, root, child, expect):
        self.assertEqual(path_depth(root, child), expect)

    data_glob_match = [
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            ["*.foo", "*.bar"],
            ["*.foo.bar"],
            ["file.foo", "file.bar"],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            [],
            ["*.foo.bar"],
            ["file.foo", "file.bar", "file.baz", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            ["*.foo"],
            [],
            ["file.foo"],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            ["*.foo"],
            ["*.foo"],
            [],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            [],
            [],
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            [".foo"],
            [],
            [],
        ),
        (
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
            [],
            [".foo"],
            ["file.foo", "file.bar", "file.baz", "file.foo.bar", "file.foo.baz", "file.bar.baz", "file.foo.bar.baz"],
        ),
    ]

    @ddt.idata(data_glob_match)
    @ddt.unpack
    def test_glob_match(self, names, include_patterns, exclude_patterns, expect):
        self.assertSetEqual(
            set(map(lambda x: make_path(x, normalize=True), glob_match(names, include_patterns, exclude_patterns))),
            set(map(lambda x: make_path(x, normalize=True), expect)),
        )

    data_scan_files = [
        (
            "unittest/pathutils",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.bar.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/dir.foo.bar.baz/file.foo.bar.baz",
            ],
        ),
        (
            "unittest/pathutils/dir.foo",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.bar.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/dir.foo.bar.baz/file.foo.bar.baz",
            ],
        ),
        (
            "unittest/pathutils/dir.baz",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
            ],
        ),
        (
            "unittest/pathutils",
            ["*.foo", "*.bar"],
            ["*.foo.bar"],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
            ],
        ),
        (
            "unittest/pathutils",
            ["*.foo", "*.bar"],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
            ],
        ),
        (
            "unittest/pathutils",
            [],
            ["*.baz"],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
            ],
        ),
        (
            "unittest/pathutils",
            [],
            [],
            2,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            [],
            [],
            2,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            ["*.foo", "*.bar"],
            ["*.baz"],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            ["*.foo"],
            [],
            0,
            [],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            [],
            ["*.bar"],
            0,
            [],
        ),
    ]

    @ddt.idata(data_scan_files)
    @ddt.unpack
    def test_scan_files(self, path, include_patterns, exclude_patterns, depth, expect):
        self.assertSetEqual(
            set(map(lambda x: make_path(x, normalize=True), scan_files(resources_directory / path,
                                                                       include_patterns=include_patterns,
                                                                       exclude_patterns=exclude_patterns,
                                                                       depth=depth))),
            set(map(lambda x: make_path(x, normalize=True), map(lambda x: resources_directory / x, expect))),
        )

    data_copy_files = [
        (
            "unittest/pathutils",
            "unittest/pathutils",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.bar.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/dir.foo.bar.baz/file.foo.bar.baz",
            ],
        ),
        (
            "unittest/pathutils/dir.foo",
            "unittest/pathutils/dir.foo",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.bar.baz",
                "unittest/pathutils/dir.foo/dir.foo.bar/dir.foo.bar.baz/file.foo.bar.baz",
            ],
        ),
        (
            "unittest/pathutils/dir.baz",
            "unittest/pathutils/dir.baz",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
            ],
        ),
        (
            "unittest/pathutils",
            "unittest/pathutils",
            ["*.foo", "*.bar"],
            ["*.foo.bar"],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
            ],
        ),
        (
            "unittest/pathutils",
            "unittest/pathutils",
            ["*.foo", "*.bar"],
            [],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
            ],
        ),
        (
            "unittest/pathutils",
            "unittest/pathutils",
            [],
            ["*.baz"],
            0,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.foo",
                "unittest/pathutils/dir.foo/dir.foo.bar/file.foo.bar",
            ],
        ),
        (
            "unittest/pathutils",
            "unittest/pathutils",
            [],
            [],
            2,
            [
                "unittest/pathutils/dir.baz/file.foo.bar",
                "unittest/pathutils/dir.baz/file.foo.baz",
                "unittest/pathutils/dir.baz/file.bar.baz",
                "unittest/pathutils/dir.foo/file.bar",
                "unittest/pathutils/dir.foo/file.baz",
                "unittest/pathutils/dir.foo/file.foo",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            "unittest/pathutils/dir.foo/file.bar",
            [],
            [],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            "unittest/pathutils/dir.foo/file.bar",
            [],
            [],
            2,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            "unittest/pathutils/dir.foo/file.bar",
            ["*.foo", "*.bar"],
            ["*.baz"],
            0,
            [
                "unittest/pathutils/dir.foo/file.bar",
            ],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            "unittest/pathutils/dir.foo/file.bar",
            ["*.foo"],
            [],
            0,
            [],
        ),
        (
            "unittest/pathutils/dir.foo/file.bar",
            "unittest/pathutils/dir.foo/file.bar",
            [],
            ["*.bar"],
            0,
            [],
        ),
    ]

    @ddt.idata(data_copy_files)
    @ddt.unpack
    def test_copy_files(self, src, dst, include_patterns, exclude_patterns, depth, expect):
        with tempfile.TemporaryDirectory() as temp_directory:
            temp_directory = pathlib.Path(temp_directory)
            copy_files(resources_directory / src,
                       temp_directory / dst,
                       include_patterns=include_patterns,
                       exclude_patterns=exclude_patterns,
                       depth=depth)

            self.assertSetEqual(
                set(map(lambda x: make_path(x, normalize=True), scan_files(temp_directory / dst))),
                set(map(lambda x: make_path(x, normalize=True), map(lambda x: temp_directory / x, expect))),
            )
