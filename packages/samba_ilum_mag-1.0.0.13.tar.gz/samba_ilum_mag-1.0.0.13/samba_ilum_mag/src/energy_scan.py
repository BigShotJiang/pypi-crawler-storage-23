# SAMBA_ilum Copyright (C) 2025-2026
# GNU GPL-3.0 license


import os


try:
    path_dir, name_dir = os.path.split(os.getcwd())
except Exception as e:
    pass


#------------
converged = 0
#------------
try:
    with open('OUTCAR', 'r') as f:
        for line in f:
            if 'reached' in line:
                converged = 1
                break
except FileNotFoundError:
    pass
except Exception as e:
    pass


if (converged == 1):


   #===================================================
   # Obtaining information about magnetization ========
   #===================================================
   file_path = os.path.join('output', 'informacoes.txt')
   magnetic_mode = 0
   #----------------------------
   if os.path.isfile(file_path):
      if os.path.isfile('magmom.txt'):
         #----------------
         magnetic_mode = 1
         #--------------------------------------
         target_tags = [ "Mean Absolute Magmom",
                         "Total Net MAGMOM",
                         "Magnetic Order Parameter (R)",
                         "Magnetic Type Primary",
                         "Magnetic Phase Description" ]
         #---------------------------------------------
         magnetic_map = { "Non-magnetic (NM)": "1",
                          "quasi Non-magnetic (NM)": "-1",
                          "Ferromagnetic (FM)": "2",
                          "quasi Ferromagnetic (FM)": "-2",
                          "Antiferromagnetic (AFM)": "3",
                          "quasi Antiferromagnetic (AFM)": "-3",
                          "Ferrimagnetic/Complex": "4" }
         #--------------------------------------------------------
         magnetic_results = {tag: "--" for tag in target_tags}
         #----------------------------------------------------
         with open(file_path, 'r') as f:
              for line in f:
                  if ":" in line:
                     #-------------------------
                     parts = line.split(":", 1)
                     tag = parts[0].strip()
                     #---------------------
                     if tag in target_tags:
                        val_raw = parts[1].strip()
                        if tag == "Magnetic Order Parameter (R)":
                           try: magnetic_results[tag] = float(val_raw)
                           except ValueError: magnetic_results[tag] = -9999.999
                        else: magnetic_results[tag] = magnetic_map.get(val_raw, val_raw)
         #------------------------------------------------------------------
         mag_v1 = magnetic_results['Mean Absolute Magmom'].replace(" muB","")
         mag_v2 = magnetic_results['Total Net MAGMOM'].replace(" muB","")
         mag_v3 = magnetic_results['Magnetic Order Parameter (R)']
         mag_v4 = magnetic_results['Magnetic Type Primary']
         mag_v5 = magnetic_results['Magnetic Phase Description']


   try:
       with open('OSZICAR', 'r') as f:
            last_line = f.readlines()[-1].strip()
            energy_value = last_line.replace('=', ' ').split()[4]
       #--------------------------------------------------------
       with open('../energy_scan.txt', "a") as energy_file:
            if (magnetic_mode == 0): energy_file.write(f'{name_dir} {energy_value} \n')
            if (magnetic_mode == 1): energy_file.write(f'{name_dir} {energy_value} {mag_v1} {mag_v2} {mag_v3} {mag_v4} {mag_v5} \n')
            #-----------------------------------------------------------------------------------------------------------------------
            temp_name = name_dir.replace('_', ' ').split()
            #---------------------------------------------
            if len(temp_name) == 2:
               t_temp_name_original = temp_name.copy()
               #---------------------------------------------
               if temp_name[0] == '0.0': temp_name[0] = '1.0'
               if temp_name[1] == '0.0': temp_name[1] = '1.0'
               #---------------------------------------------
               if temp_name[0] == '1.0' or temp_name[1] == '1.0':
                  new_name_dir = f'{temp_name[0]}_{temp_name[1]}'
                  if (magnetic_mode == 0): energy_file.write(f'{new_name_dir} {energy_value} \n')
                  if (magnetic_mode == 1): energy_file.write(f'{new_name_dir} {energy_value} {mag_v1} {mag_v2} {mag_v3} {mag_v4} {mag_v5} \n')
               #------------------------------------------------------------------------------------------------------------------------------
               if t_temp_name_original[0] == '0.0' and t_temp_name_original[1] == '0.0':
                  if (magnetic_mode == 0):
                     energy_file.write(f'1.0_0.0 {energy_value} \n')
                     energy_file.write(f'0.0_1.0 {energy_value} \n')
                  if (magnetic_mode == 1):
                     energy_file.write(f'1.0_0.0 {energy_value} {mag_v1} {mag_v2} {mag_v3} {mag_v4} {mag_v5} \n')
                     energy_file.write(f'0.0_1.0 {energy_value} {mag_v1} {mag_v2} {mag_v3} {mag_v4} {mag_v5} \n')
   except FileNotFoundError:
       pass
   except IndexError:
       pass
   except Exception as e:
       pass
