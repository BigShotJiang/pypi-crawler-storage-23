import warnings

warnings.warn(
    "\n" + "=" * 70 + "\n"
    "DEPRECATION NOTICE: arcade_google is no longer maintained.\n"
    "\n"
    "This package has been deprecated. Please visit https://docs.arcade.dev\n"
    "for the latest documentation on integrating Arcade tools into your\n"
    "applications.\n"
    "\n",
    DeprecationWarning,
    stacklevel=2,
)

__all__: list[str] = []
