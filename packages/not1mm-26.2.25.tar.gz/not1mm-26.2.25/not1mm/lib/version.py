"""It's the version"""

__version__ = "26.2.25"
