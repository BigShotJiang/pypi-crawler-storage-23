from setuptools import setup


# See pyproject.toml for package metadata
setup()
