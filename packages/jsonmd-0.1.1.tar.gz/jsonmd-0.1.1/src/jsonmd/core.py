from __future__ import annotations

import json
import re
import warnings
from pathlib import Path
from typing import Any, TextIO

import json5

_MD_BLOCK_RE = re.compile(
    r"(?P<prefix>:\s*)<<<(?P<tag>[A-Z][A-Z0-9_-]*)[ \t]*\n"
    r"(?P<body>.*?)\n"
    r"(?P=tag)(?=\s*[,}\]])",
    re.S,
)
_ANGLE_BLOCK_RE = re.compile(
    r"(?P<prefix>:\s*)<(?P<tag>[a-z][a-z0-9_-]*)>"
    r"(?P<body>.*?)"
    r"</(?P=tag)>(?P<tail>.*?)(?=\s*[,}\]])",
    re.S,
)
_IDENT_RE = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")


def _rewrite_markdown_blocks(text: str) -> str:
    def repl_heredoc(match: re.Match[str]) -> str:
        body = match.group("body")
        return match.group("prefix") + json.dumps(body, ensure_ascii=False)

    def repl_angle(match: re.Match[str]) -> str:
        body = match.group("body")
        tail = match.group("tail")
        if tail.strip():
            tag = match.group("tag")
            warnings.warn(
                f"Potential early </{tag}> close detected; "
                "trailing content before separator was included as text.",
                stacklevel=2,
            )
            body += tail
        return match.group("prefix") + json.dumps(body, ensure_ascii=False)

    out = _ANGLE_BLOCK_RE.sub(repl_angle, text)
    out = _MD_BLOCK_RE.sub(repl_heredoc, out)
    return out


def loads(text: str) -> Any:
    rewritten = _rewrite_markdown_blocks(text)
    return json5.loads(rewritten)


def load(path: str | Path, encoding: str = "utf-8") -> Any:
    with open(path, "r", encoding=encoding) as f:
        return loads(f.read())


def _choose_md_tag(text: str, base_tag: str = "MD") -> str:
    lines = set(text.splitlines())
    if base_tag not in lines:
        return base_tag

    i = 2
    while True:
        candidate = f"{base_tag}{i}"
        if candidate not in lines:
            return candidate
        i += 1


def _choose_angle_tag(text: str, base_tag: str = "md") -> str:
    tag = base_tag
    i = 2
    while f"</{tag}>" in text:
        tag = f"{base_tag}{i}"
        i += 1
    return tag


def _dump_key(key: str) -> str:
    return key if _IDENT_RE.match(key) else json5.dumps(key)


def _dump_value(
    value: Any,
    indent: int,
    level: int,
    md_tag: str,
    block_style: str,
) -> str:
    if isinstance(value, dict):
        if not value:
            return "{}"
        pad = " " * (indent * level)
        child_pad = " " * (indent * (level + 1))
        items = []
        for k, v in value.items():
            items.append(
                f"{child_pad}{_dump_key(str(k))}: "
                f"{_dump_value(v, indent, level + 1, md_tag, block_style)}"
            )
        return "{\n" + ",\n".join(items) + f"\n{pad}}}"

    if isinstance(value, list):
        if not value:
            return "[]"
        pad = " " * (indent * level)
        child_pad = " " * (indent * (level + 1))
        items = [
            f"{child_pad}{_dump_value(v, indent, level + 1, md_tag, block_style)}"
            for v in value
        ]
        return "[\n" + ",\n".join(items) + f"\n{pad}]"

    if isinstance(value, str) and "\n" in value:
        if block_style == "angle":
            tag = _choose_angle_tag(value, md_tag)
            return f"<{tag}>{value}</{tag}>"
        tag = _choose_md_tag(value, md_tag.upper())
        return f"<<<{tag}\n{value}\n{tag}"

    return json5.dumps(value, ensure_ascii=False)


def dumps(
    value: Any,
    *,
    indent: int = 2,
    md_tag: str = "md",
    block_style: str = "angle",
) -> str:
    if block_style not in {"angle", "heredoc"}:
        raise ValueError("block_style must be 'angle' or 'heredoc'")
    return _dump_value(
        value, indent=indent, level=0, md_tag=md_tag, block_style=block_style
    )


def dump(
    value: Any,
    fp: TextIO,
    *,
    indent: int = 2,
    md_tag: str = "md",
    block_style: str = "angle",
) -> None:
    fp.write(dumps(value, indent=indent, md_tag=md_tag, block_style=block_style))
