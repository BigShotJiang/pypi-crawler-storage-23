from .core import dump, dumps, load, loads

__all__ = ["loads", "load", "dumps", "dump"]
