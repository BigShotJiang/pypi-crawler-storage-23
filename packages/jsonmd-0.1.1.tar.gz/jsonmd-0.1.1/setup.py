from setuptools import find_packages, setup


setup(
    name="jsonmd",
    version="0.1.1",
    description="JSON/JSON5 loader and dumper with raw multiline markdown block support",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    python_requires=">=3.9",
    package_dir={"": "src"},
    packages=find_packages("src"),
    install_requires=["json5>=0.12.0"],
)
