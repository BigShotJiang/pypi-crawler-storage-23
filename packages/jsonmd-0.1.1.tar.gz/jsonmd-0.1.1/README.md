# jsonmd

# 背景

在人机协作时代，提示词和结构化文本配置会被开发者与 AI 代理高频共同编辑。
可读性和低摩擦编辑能力会直接影响迭代速度与交付质量。

`jsonmd` 用来解决 JSON 不支持原生多行字符串的问题。

通过 `<md>...</md>` 语法标记，你可以在 JSON/JSON5 中嵌入原始多行文本块
（例如 Markdown），而不需要使用 `\n` 转义符。

这让在配置文件中存储富文本更直观、可读性更高。

示例：

```json5
{
  content: <md># Title
- item
</md>
}
```

而不是：

```json
{
  "content": "# Title\n- item"
}
```

# 使用

```python
from jsonmd import loads, dumps

text = """
{
  content: <md># Title
- item
</md>
}
"""
data = loads(text)

encoded = dumps({"content": "# Title\n- item"})
```

# Background

In the era of human-AI collaboration, prompts and structured text configs are
edited frequently by both developers and AI agents. Readability and low-friction
editing directly affect iteration speed and quality.

`jsonmd` solves the problem that JSON does not support native multiline strings.

With `<md>...</md>` block markers, you can embed raw multiline text
(for example Markdown) in JSON/JSON5 without `\n` escaping.

This makes rich text in config files easier to read and maintain.

Example:

```json5
{
  content: <md># Title
- item
</md>
}
```

instead of:

```json
{
  "content": "# Title\n- item"
}
```


# Usage

```python
from jsonmd import loads, dumps

text = """
{
  content: <md># Title
- item
</md>
}
"""
data = loads(text)

encoded = dumps({"content": "# Title\n- item"})
```
