"""Utilities module - Common utilities for elspais."""
