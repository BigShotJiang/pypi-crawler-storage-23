# Implements: REQ-p00080-A
"""PDF generation package for elspais.

Provides the MarkdownAssembler for building structured Markdown from the graph,
and Pandoc integration for PDF compilation.
"""
