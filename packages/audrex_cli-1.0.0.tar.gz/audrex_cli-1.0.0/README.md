# Audrex CLI

Connect your infrastructure to Audrex ComplianceOS for real-time compliance monitoring.

## Installation

```bash
pip install audrex-cli
```

Or install from source:

```bash
git clone https://github.com/melih-inweb/audrex.git
cd audrex-cli
pip install -e .
```

## Usage

1. **Generate a connection key** from your Audrex dashboard at https://www.audrex.ai/onboarding

2. **Connect your infrastructure:**

```bash
audrex connect ADRX-XXXX-XXXX-XXXX
```

3. **Monitor compliance** in real-time from your dashboard

## What Gets Connected?

When you run the connect command, Audrex CLI:
- Gathers basic server information (hostname, OS, architecture)
- Sends this information securely to the Audrex API
- Activates your connection for real-time monitoring
- Enables AI-powered compliance scanning and chaos engineering

## Security

- Connection keys are single-use and expire after activation
- All communication uses HTTPS/TLS encryption
- No sensitive data or credentials are collected
- You can revoke connections anytime from your dashboard

For security vulnerabilities, see [SECURITY.md](SECURITY.md) or contact security@audrex.ai.

## Requirements

- Python 3.8 or higher
- Active Audrex service subscription
- Network access to api.audrex.ai

## License

**Proprietary Software** - This CLI tool is proprietary software owned by Audrex Team.

By installing and using this software, you agree to the terms in the LICENSE file. Usage is restricted to:
- Active Audrex service subscribers only
- Connecting your infrastructure to Audrex ComplianceOS platform
- Personal or organizational use as per your service agreement

Unauthorized distribution, modification, or reverse engineering is strictly prohibited.

For licensing inquiries: legal@audrex.ai

## Support

For issues or questions:
- Email: support@audrex.ai
- Documentation: https://www.audrex.ai/docs
