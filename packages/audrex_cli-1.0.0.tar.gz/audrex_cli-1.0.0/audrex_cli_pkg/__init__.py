"""Audrex CLI Package - Connect your infrastructure to ComplianceOS"""

from .audrex_cli import main

__version__ = "1.0.0"
__all__ = ["main"]
