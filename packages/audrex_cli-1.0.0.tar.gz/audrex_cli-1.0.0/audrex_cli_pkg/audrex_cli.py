#!/usr/bin/env python3
"""
Audrex CLI - Infrastructure Connection Tool
Connects your infrastructure to Audrex ComplianceOS
"""

import socket
import platform
import httpx
import asyncio
import sys
import argparse
from typing import Optional


async def get_server_info() -> dict:
    """Gather server information."""
    return {
        'hostname': socket.gethostname(),
        'platform': platform.system(),
        'platform_release': platform.release(),
        'platform_version': platform.version(),
        'architecture': platform.machine(),
        'processor': platform.processor() or 'Unknown',
    }


async def activate_connection(connect_key: str, api_url: str = 'https://api.audrex.ai') -> bool:
    """Activate connection with backend."""
    try:
        server_info = await get_server_info()
        
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                f'{api_url}/api/v1/connect/activate',
                json={
                    'connect_key': connect_key,
                    'server_info': server_info,
                    'cli_version': '1.0.0'
                }
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"\n✅ Connection activated successfully!")
                print(f"   Connection ID: {data.get('id', 'N/A')}")
                print(f"   Status: {data.get('status', 'N/A')}")
                if data.get('name'):
                    print(f"   Name: {data.get('name')}")
                return True
            else:
                print(f"\n❌ Activation failed: {response.status_code}")
                try:
                    error_detail = response.json().get('detail', 'Unknown error')
                except:
                    error_detail = response.text or 'Unknown error'
                print(f"   Message: {error_detail}")
                return False
                
    except httpx.TimeoutException:
        print("\n❌ Connection timeout - check your network and API URL")
        return False
    except httpx.ConnectError as e:
        print(f"\n❌ Cannot reach API at {api_url}")
        print(f"   Error: {str(e)}")
        return False
    except Exception as e:
        print(f"\n❌ Connection failed: {str(e)}")
        return False


async def connect_command(connect_key: str, api_url: Optional[str] = None):
    """Handle the connect command."""
    if not api_url:
        api_url = 'https://api.audrex.ai'
    
    print("\n" + "="*60)
    print("  🛡️  Audrex CLI - Infrastructure Connection")
    print("="*60 + "\n")
    
    # Validate key format
    if not connect_key.startswith('ADRX-'):
        print("❌ Invalid connection key format. Keys should start with 'ADRX-'")
        sys.exit(1)
    
    print(f"🔗 Connecting with key: {connect_key}")
    print(f"🌐 API: {api_url}\n")
    
    server_info = await get_server_info()
    print("📊 Server Information:")
    print(f"   Hostname: {server_info['hostname']}")
    print(f"   Platform: {server_info['platform']} {server_info['platform_release']}")
    print(f"   Architecture: {server_info['architecture']}")
    print("\n⏳ Activating connection...")
    
    success = await activate_connection(connect_key, api_url)
    
    if success:
        print("\n✨ Your infrastructure is now connected to Audrex!")
        print("   You can now access your dashboard at: https://www.audrex.ai\n")
        sys.exit(0)
    else:
        print("\n⚠️  Connection failed. Please check:")
        print("   - Your connection key is valid and not expired")
        print("   - Your network can reach the API endpoint")
        print("   - The key hasn't been revoked")
        print("\n   Generate a new key at: https://www.audrex.ai/onboarding\n")
        sys.exit(1)


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Audrex CLI - Connect your infrastructure to ComplianceOS',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  audrex connect ADRX-XXXX-XXXX-XXXX
  audrex connect ADRX-XXXX-XXXX-XXXX --api https://api.audrex.ai
        """
    )
    
    parser.add_argument(
        'command',
        choices=['connect'],
        help='Command to execute'
    )
    
    parser.add_argument(
        'key',
        help='Connection key (ADRX-XXXX-XXXX-XXXX format)'
    )
    
    parser.add_argument(
        '--api',
        default='https://api.audrex.ai',
        help='API endpoint URL (default: https://api.audrex.ai)'
    )
    
    args = parser.parse_args()
    
    if args.command == 'connect':
        asyncio.run(connect_command(args.key, args.api))
    else:
        print(f"Unknown command: {args.command}")
        sys.exit(1)


if __name__ == '__main__':
    main()
