"""Riverse — River Algorithm memory consolidation for AI applications."""

from riverse.client import Riverse

__version__ = "0.1.0"
__all__ = ["Riverse"]
