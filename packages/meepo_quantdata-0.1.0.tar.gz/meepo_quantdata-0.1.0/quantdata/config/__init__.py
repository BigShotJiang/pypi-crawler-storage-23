"""
QuantData Config Module

配置管理模块
"""

from quantdata.config.settings import Config, config

__all__ = ["Config", "config"]
