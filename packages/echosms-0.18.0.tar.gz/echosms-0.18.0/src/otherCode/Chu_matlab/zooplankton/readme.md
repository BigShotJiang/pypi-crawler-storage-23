# Zooplankton scattering models

This directory contains a graphical Matlab program that will calculate the scatter from a variety of weak scatterers using a DWBA model.

Instructions on its' use are given in the `Program Description.pdf` file (the source document is also there - `Program Description.docx`).

