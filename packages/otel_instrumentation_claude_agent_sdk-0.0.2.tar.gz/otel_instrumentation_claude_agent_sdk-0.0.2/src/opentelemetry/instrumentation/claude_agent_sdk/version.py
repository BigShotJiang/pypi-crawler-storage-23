"""Version information for otel-instrumentation-claude-agent-sdk."""

from importlib.metadata import version

__version__: str = version("otel-instrumentation-claude-agent-sdk")
