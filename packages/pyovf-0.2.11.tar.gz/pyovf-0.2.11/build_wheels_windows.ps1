# Build wheels for Windows - all Python versions
# (c) 2026 Prof. Flavio ABREU ARAUJO
# Run this in PowerShell from the pyovf directory

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "PyOVF Windows Wheel Builder" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host ""

# Clean previous builds
Write-Host "Cleaning previous builds..." -ForegroundColor Yellow
Remove-Item -Path "dist\*" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "build" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "*.egg-info" -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path "dist" -Force | Out-Null

# Python versions to build for
$pythonVersions = @("3.9", "3.10", "3.11", "3.12", "3.13", "3.14")

Write-Host ""
Write-Host "=== Building Windows Wheels ===" -ForegroundColor Green
Write-Host ""

$successCount = 0
$failCount = 0
$skipCount = 0

foreach ($pyver in $pythonVersions) {
    Write-Host "Building for Python $pyver..." -ForegroundColor Cyan
    
    # Try to find Python using multiple methods
    $pyCmd = $null
    $pyVersion = $null
    
    # Method 1: Try py launcher
    try {
        $testVersion = & py -$pyver --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            $pyCmd = "py -$pyver"
            $pyVersion = $testVersion
            Write-Host "  → Found via py launcher: $pyVersion" -ForegroundColor Gray
        }
    } catch {}
    
    # Method 2: Try python3.X directly
    if (-not $pyCmd) {
        $pythonExe = "python$pyver"
        try {
            $testVersion = & $pythonExe --version 2>&1
            if ($LASTEXITCODE -eq 0 -and $testVersion -match $pyver) {
                $pyCmd = $pythonExe
                $pyVersion = $testVersion
                Write-Host "  → Found: $pythonExe ($pyVersion)" -ForegroundColor Gray
            }
        } catch {}
    }
    
    # Method 3: Check common installation paths
    if (-not $pyCmd) {
        $commonPaths = @(
            "C:\Python$($pyver.Replace('.',''))\python.exe",
            "C:\Program Files\Python$($pyver.Replace('.',''))\python.exe",
            "$env:LOCALAPPDATA\Programs\Python\Python$($pyver.Replace('.',''))\python.exe"
        )
        foreach ($path in $commonPaths) {
            if (Test-Path $path) {
                try {
                    $testVersion = & $path --version 2>&1
                    if ($LASTEXITCODE -eq 0 -and $testVersion -match $pyver) {
                        $pyCmd = "`"$path`""
                        $pyVersion = $testVersion
                        Write-Host "  → Found at: $path" -ForegroundColor Gray
                        break
                    }
                } catch {}
            }
        }
    }
    
    if (-not $pyCmd) {
        Write-Host "  ⚠ Python $pyver not found, skipping..." -ForegroundColor Yellow
        $skipCount++
        Write-Host ""
        continue
    }
    
    # Install build dependencies
    Write-Host "  → Installing build dependencies..." -ForegroundColor Gray
    try {
        Invoke-Expression "$pyCmd -m pip install --quiet --upgrade pip setuptools wheel build 2>&1" | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Failed to install dependencies"
        }
    } catch {
        Write-Host "  ✗ Failed to install dependencies for Python $pyver" -ForegroundColor Red
        $failCount++
        Write-Host ""
        continue
    }
    
    # Build wheel
    Write-Host "  → Building wheel..." -ForegroundColor Gray
    try {
        Invoke-Expression "$pyCmd -m build --wheel 2>&1" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  ✓ Wheel built successfully for Python $pyver" -ForegroundColor Green
            $successCount++
        } else {
            throw "Build failed"
        }
    } catch {
        Write-Host "  ✗ Failed to build wheel for Python $pyver" -ForegroundColor Red
        Write-Host "    Run with --verbose flag to debug: $pyCmd -m build --wheel --verbose" -ForegroundColor Yellow
        $failCount++
    }
    
    Write-Host ""
}

# Build source distribution (sdist) with latest Python
Write-Host "Building source distribution..." -ForegroundColor Cyan
$sdistCmd = $null

# Try multiple methods to find any Python
foreach ($pyver in @("3.14", "3.13", "3.12", "3.11", "3.10", "3.9")) {
    # Try py launcher
    try {
        & py -$pyver --version 2>&1 | Out-Null
        if ($LASTEXITCODE -eq 0) {
            $sdistCmd = "py -$pyver"
            break
        }
    } catch {}
    
    # Try direct python command
    if (-not $sdistCmd) {
        try {
            $pythonExe = "python$pyver"
            & $pythonExe --version 2>&1 | Out-Null
            if ($LASTEXITCODE -eq 0) {
                $sdistCmd = $pythonExe
                break
            }
        } catch {}
    }
}

# Fallback to current python (might be from venv, but that's okay for sdist)
if (-not $sdistCmd) {
    try {
        $pyVersion = & python --version 2>&1
        if ($LASTEXITCODE -eq 0) {
            $sdistCmd = "python"
            Write-Host "  → Using current Python: $pyVersion" -ForegroundColor Gray
        }
    } catch {}
}

if ($sdistCmd) {
    try {
        Invoke-Expression "$sdistCmd -m build --sdist 2>&1" | Out-Null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "  ✓ Source distribution built successfully" -ForegroundColor Green
        } else {
            throw "Build failed"
        }
    } catch {
        Write-Host "  ⚠ Failed to build source distribution" -ForegroundColor Yellow
    }
} else {
    Write-Host "  ⚠ No Python found for building source distribution" -ForegroundColor Yellow
}
Write-Host ""

# List built wheels
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "Built Artifacts" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host ""

$wheels = Get-ChildItem -Path "dist\*.whl" -ErrorAction SilentlyContinue
$tarballs = Get-ChildItem -Path "dist\*.tar.gz" -ErrorAction SilentlyContinue

if ($wheels) {
    Write-Host "Wheels:" -ForegroundColor Green
    foreach ($wheel in $wheels) {
        $size = "{0:N2}" -f ($wheel.Length / 1MB)
        Write-Host "  ✓ $($wheel.Name) ($size MB)" -ForegroundColor Green
    }
} else {
    Write-Host "No wheels built" -ForegroundColor Yellow
}

if ($tarballs) {
    Write-Host ""
    Write-Host "Source Distribution:" -ForegroundColor Green
    foreach ($tarball in $tarballs) {
        $size = "{0:N2}" -f ($tarball.Length / 1MB)
        Write-Host "  ✓ $($tarball.Name) ($size MB)" -ForegroundColor Green
    }
}

Write-Host ""
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "Summary" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "  Success: $successCount" -ForegroundColor Green
Write-Host "  Failed:  $failCount" -ForegroundColor $(if ($failCount -gt 0) { "Red" } else { "Gray" })
Write-Host "  Skipped: $skipCount" -ForegroundColor $(if ($skipCount -gt 0) { "Yellow" } else { "Gray" })
Write-Host ""

if ($successCount -gt 0) {
    Write-Host "✓ Build complete!" -ForegroundColor Green
    Write-Host "Wheels are in: $(Resolve-Path dist)" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Cyan
    Write-Host "  1. Test wheels:" -ForegroundColor Gray
    Write-Host "     py -3.13 -m venv test_venv" -ForegroundColor Gray
    Write-Host "     .\test_venv\Scripts\Activate.ps1" -ForegroundColor Gray
    Write-Host "     pip install dist\pyovf-*.whl" -ForegroundColor Gray
    Write-Host ""
    Write-Host "  2. Upload to PyPI:" -ForegroundColor Gray
    Write-Host "     twine upload dist/*" -ForegroundColor Gray
    Write-Host ""
} else {
    Write-Host "⚠ No wheels were built successfully" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Possible issues:" -ForegroundColor Yellow
    Write-Host "  - Install more Python versions: https://www.python.org/downloads/" -ForegroundColor Gray
    Write-Host "  - Ensure Visual Studio Build Tools are installed" -ForegroundColor Gray
    Write-Host "  - Run with verbose flag to see detailed errors" -ForegroundColor Gray
    exit 1
}
