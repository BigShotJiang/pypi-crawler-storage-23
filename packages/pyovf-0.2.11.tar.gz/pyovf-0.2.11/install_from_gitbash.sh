#!/bin/bash
# Helper script for installing pyovf from Git Bash
# This script handles the interactive prompt issue in Git Bash

echo "=========================================="
echo "pyovf Installation Helper for Git Bash"
echo "=========================================="
echo ""
echo "Git Bash doesn't support interactive prompts during pip builds."
echo "This script will set the required environment variable and proceed."
echo ""
echo "What would you like to do?"
echo "  1. Download and install C++ Build Tools (Recommended)"
echo "  2. Skip building from source (use pre-built wheels from PyPI)"
echo "  3. Cancel"
echo ""
read -p "Enter your choice (1-3): " choice

case $choice in
    1)
        echo ""
        echo "Setting PYOVF_AUTO_INSTALL_BUILDTOOLS=yes"
        export PYOVF_AUTO_INSTALL_BUILDTOOLS=yes
        echo "Starting pip install..."
        echo ""
        pip install -e .
        ;;
    2)
        echo ""
        echo "Installing from PyPI (pre-built wheels)..."
        echo ""
        pip install pyovf
        ;;
    3)
        echo ""
        echo "Installation cancelled."
        exit 0
        ;;
    *)
        echo ""
        echo "Invalid choice. Installation cancelled."
        exit 1
        ;;
esac

echo ""
echo "=========================================="
echo "Installation Complete"
echo "=========================================="
echo ""
echo "If C++ Build Tools were downloaded, you may need to:"
echo "  1. Complete the Visual Studio Build Tools installation"
echo "  2. Restart your terminal"
echo "  3. Run this script again or: pip install -e ."
echo ""
