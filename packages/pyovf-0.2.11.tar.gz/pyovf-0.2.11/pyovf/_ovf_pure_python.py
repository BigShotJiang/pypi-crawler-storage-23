# (c) 2021-2026 Prof. Flavio ABREU ARAUJO. All rights reserved.
#
# Pure Python fallback for OVF file I/O.
# Used automatically when the C++ extension (_ovf_core) cannot be loaded.
#
# Implements the same interface as the pybind11 _ovf_core.OVFFile binding,
# derived directly from the C++ OVF_File implementation in ovf-rw.
#
# Supported: OVF 2.0, Binary 4 (float32), rectangular mesh.
# Not supported: Binary 8 (float64), Text format.

import struct
import numpy as np

_MAGIC_BINARY4 = struct.pack('<f', 1234567.0)


class OVFFile:
    """
    Pure Python OVF file reader/writer.

    Mirrors the interface of _ovf_core.OVFFile (pybind11 binding) so that
    ovf_handler.py works identically whether the C++ extension is present or not.

    Data layout: float32 C-contiguous array with shape
        (znodes, ynodes, xnodes, valuedim)  for vector fields (valuedim > 1)
        (znodes, ynodes, xnodes)            for scalar fields (valuedim == 1)
    This matches the strides used by the pybind11 get_data_as_numpy() function.
    """

    def __init__(self):
        self.Title = ""
        self.meshtype = ""
        self.meshunit = ""
        self.xmin = 0.0
        self.ymin = 0.0
        self.zmin = 0.0
        self.xmax = 0.0
        self.ymax = 0.0
        self.zmax = 0.0
        self.valuedim = 0
        self.xbase = 0.0
        self.ybase = 0.0
        self.zbase = 0.0
        self.xnodes = 0
        self.ynodes = 0
        self.znodes = 0
        self.xstepsize = 0.0
        self.ystepsize = 0.0
        self.zstepsize = 0.0
        self.StageSimTime = 0.0
        self.StageSimTimeUnit = ""
        self.TotalSimTime = 0.0
        self.TotalSimTimeUnit = ""
        self.elementNum = 0
        self._data = None

    # ------------------------------------------------------------------
    # data property — keeps dimension fields in sync (same as C++ setter)
    # ------------------------------------------------------------------

    @property
    def data(self):
        return self._data

    @data.setter
    def data(self, value):
        arr = np.ascontiguousarray(value, dtype=np.float32)
        if arr.ndim == 3:
            self.znodes, self.ynodes, self.xnodes = arr.shape
            self.valuedim = 1
        elif arr.ndim == 4:
            self.znodes, self.ynodes, self.xnodes, self.valuedim = arr.shape
        else:
            raise ValueError(f"Data must be 3D or 4D, got {arr.ndim}D")
        self.elementNum = self.znodes * self.ynodes * self.xnodes * self.valuedim
        self._data = arr

    # ------------------------------------------------------------------
    # Read
    # ------------------------------------------------------------------

    def read(self, filename):
        """Read an OVF 2.0 Binary 4 file."""
        with open(filename, 'rb') as f:
            while True:
                raw_line = f.readline()
                if not raw_line:
                    break
                line = raw_line.decode('ascii', errors='replace').rstrip('\r\n')
                tokens = line.split()

                if not tokens or tokens[0] != '#' or len(tokens) < 2:
                    continue

                key = tokens[1]
                val = tokens[2] if len(tokens) > 2 else ""

                if key == 'Title:':
                    self.Title = val
                elif key == 'meshtype:':
                    self.meshtype = val
                elif key == 'meshunit:':
                    self.meshunit = val
                elif key == 'valuedim:':
                    self.valuedim = int(val) if val else 0
                elif key == 'xmin:':
                    self.xmin = float(val) if val else 0.0
                elif key == 'ymin:':
                    self.ymin = float(val) if val else 0.0
                elif key == 'zmin:':
                    self.zmin = float(val) if val else 0.0
                elif key == 'xmax:':
                    self.xmax = float(val) if val else 0.0
                elif key == 'ymax:':
                    self.ymax = float(val) if val else 0.0
                elif key == 'zmax:':
                    self.zmax = float(val) if val else 0.0
                elif key == 'xbase:':
                    self.xbase = float(val) if val else 0.0
                elif key == 'ybase:':
                    self.ybase = float(val) if val else 0.0
                elif key == 'zbase:':
                    self.zbase = float(val) if val else 0.0
                elif key == 'xnodes:':
                    self.xnodes = int(val) if val else 0
                elif key == 'ynodes:':
                    self.ynodes = int(val) if val else 0
                elif key == 'znodes:':
                    self.znodes = int(val) if val else 0
                elif key == 'xstepsize:':
                    self.xstepsize = float(val) if val else 0.0
                elif key == 'ystepsize:':
                    self.ystepsize = float(val) if val else 0.0
                elif key == 'zstepsize:':
                    self.zstepsize = float(val) if val else 0.0
                elif key == 'Desc:' and len(tokens) == 7:
                    # # Desc: Stage simulation time:  <val>  <unit>
                    # # Desc: Total simulation time:  <val>  <unit>
                    try:
                        if tokens[2] == 'Stage':
                            self.StageSimTime = float(tokens[5])
                            self.StageSimTimeUnit = tokens[6]
                        elif tokens[2] == 'Total':
                            self.TotalSimTime = float(tokens[5])
                            self.TotalSimTimeUnit = tokens[6]
                    except (ValueError, IndexError):
                        pass
                elif key == 'Begin:' and len(tokens) >= 3 and tokens[2] == 'Data':
                    if len(tokens) >= 5 and tokens[3] == 'Binary' and tokens[4] == '4':
                        self._read_binary4(f)
                    elif len(tokens) >= 4 and tokens[3] == 'Text':
                        raise ValueError(
                            "OVF Text format is not supported by the pure Python fallback. "
                            "Install build tools and reinstall pyovf for full format support."
                        )
                    elif len(tokens) >= 5 and tokens[3] == 'Binary' and tokens[4] == '8':
                        raise ValueError(
                            "OVF Binary 8 (float64) format is not supported by the pure Python "
                            "fallback. Install build tools and reinstall pyovf for full format support."
                        )
                    break  # data section handled; stop parsing

    def _read_binary4(self, f):
        """Read the Binary 4 data block from an already-opened file positioned
        immediately after the '# Begin: Data Binary 4\\n' line."""
        # Skip the 4-byte magic number (1234567.0 as float32).
        # The C++ reader does: myfile.seekg(sizeof(NumType), ios::cur)
        f.read(4)

        self.elementNum = self.valuedim * self.xnodes * self.ynodes * self.znodes
        raw = f.read(self.elementNum * 4)
        if len(raw) < self.elementNum * 4:
            raise ValueError(
                f"Truncated OVF file: expected {self.elementNum * 4} bytes, "
                f"got {len(raw)}"
            )
        arr = np.frombuffer(raw, dtype=np.float32).copy()

        if self.valuedim == 1:
            self._data = arr.reshape(self.znodes, self.ynodes, self.xnodes)
        else:
            self._data = arr.reshape(self.znodes, self.ynodes, self.xnodes, self.valuedim)

    # ------------------------------------------------------------------
    # Write
    # ------------------------------------------------------------------

    def write(self, filename):
        """Write an OVF 2.0 Binary 4 file."""
        if self._data is None:
            raise ValueError("No data to write")

        data = np.ascontiguousarray(self._data, dtype=np.float32)

        if data.ndim == 3:
            znodes, ynodes, xnodes = data.shape
            valuedim = 1
        elif data.ndim == 4:
            znodes, ynodes, xnodes, valuedim = data.shape
        else:
            raise ValueError(f"Data must be 3D or 4D, got {data.ndim}D")

        with open(filename, 'wb') as f:

            def w(s):
                f.write((s + '\n').encode('ascii'))

            w("# OOMMF OVF 2.0")
            w("# Segment count: 1")
            w("# Begin: Segment")
            w("# Begin: Header")
            w(f"# Title: {self.Title}")
            w(f"# meshtype: {self.meshtype}")
            w(f"# meshunit: {self.meshunit}")
            w(f"# xmin: {self.xmin:.15g}")
            w(f"# ymin: {self.ymin:.15g}")
            w(f"# zmin: {self.zmin:.15g}")
            w(f"# xmax: {self.xmax:.15g}")
            w(f"# ymax: {self.ymax:.15g}")
            w(f"# zmax: {self.zmax:.15g}")
            w(f"# valuedim: {valuedim}")

            # valuelabels / valueunits — mirrors C++ writeOVF() logic exactly
            if valuedim == 3:
                if self.Title == 'm':
                    w("# valuelabels: m_x m_y m_z")
                    w("# valueunits: 1 1 1")
                elif self.Title == 'B_ext':
                    w("# valuelabels: B_ext_x B_ext_y B_ext_z")
                    w("# valueunits: T T T")
                elif self.Title == 'J':
                    w("# valuelabels: J_x J_y J_z")
                    w("# valueunits: A/m^2 A/m^2 A/m^2")
                else:
                    w("# valuelabels: m_x m_y m_z")
                    w("# valueunits: 1 1 1")
            elif valuedim == 1:
                w(f"# valuelabels: {self.Title}")
                w("# valueunits: 1")
            else:
                w("# valuelabels: unknown")
                w("# valueunits: 1")

            # Note: the C++ writer uses "Total simulation time" for *both* Desc
            # lines (the Stage line label is a known quirk in writeOVF).
            # We replicate this exactly so files are byte-compatible.
            w(f"# Desc: Total simulation time:  {self.StageSimTime}  {self.StageSimTimeUnit}")
            w(f"# Desc: Total simulation time:  {self.TotalSimTime}  {self.TotalSimTimeUnit}")
            w(f"# xbase: {self.xbase:.15g}")
            w(f"# ybase: {self.ybase:.15g}")
            w(f"# zbase: {self.zbase:.15g}")
            w(f"# xnodes: {xnodes}")
            w(f"# ynodes: {ynodes}")
            w(f"# znodes: {znodes}")
            w(f"# xstepsize: {self.xstepsize:.15g}")
            w(f"# ystepsize: {self.ystepsize:.15g}")
            w(f"# zstepsize: {self.zstepsize:.15g}")
            w("# End: Header")
            w("# Begin: Data Binary 4")

            # Magic number (same constant as C++: 1234567.0f, little-endian)
            f.write(_MAGIC_BINARY4)

            # Raw float32 data — C-contiguous (z, y, x, dim) order
            f.write(data.tobytes())

            w("# End: Data Binary 4")
            w("# End: Segment")

    def __repr__(self):
        return (
            f"<OVFFile '{self.Title}' "
            f"{self.xnodes}x{self.ynodes}x{self.znodes}x{self.valuedim}>"
        )


def file_exists(filename):
    """Check if a file exists (mirrors the C++ utility exposed in _ovf_core)."""
    import os
    return os.path.isfile(filename)
