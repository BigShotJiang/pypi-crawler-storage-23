"""
Benchmark: C++ extension (_ovf_core) vs Pure Python (_ovf_pure_python)

Measures read and write throughput for several array sizes.
Run from the pyovf/ directory:

    python benchmarks/benchmark_backends.py

Optional flags:
    --reps N      repetitions per measurement (default: 10)
    --sizes small  only run the small/medium sizes (faster)
"""

import argparse
import struct
import sys
import tempfile
import time
from pathlib import Path

import numpy as np

# ---------------------------------------------------------------------------
# Ensure repo is importable without an install
# ---------------------------------------------------------------------------
_REPO = Path(__file__).resolve().parents[1]
if str(_REPO) not in sys.path:
    sys.path.insert(0, str(_REPO))

from pyovf._ovf_pure_python import OVFFile as PureOVFFile  # noqa: E402

# Try to load the C++ backend
try:
    from pyovf import _ovf_core as _cpp_mod
    CppOVFFile = _cpp_mod.OVFFile
    HAS_CPP = True
except ImportError:
    HAS_CPP = False
    CppOVFFile = None


# ---------------------------------------------------------------------------
# ANSI colour support
# ---------------------------------------------------------------------------

def _enable_ansi():
    """Enable ANSI virtual terminal processing on Windows; no-op elsewhere."""
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)  # STD_OUTPUT_HANDLE
        mode = ctypes.c_ulong()
        if kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return bool(kernel32.SetConsoleMode(handle, mode.value | 4))
    except Exception:
        pass
    return False


_USE_COLOR = _enable_ansi()


def _c(code):
    return code if _USE_COLOR else ""


RESET = _c("\033[0m")
BOLD  = _c("\033[1m")
DIM   = _c("\033[2m")
GREEN = _c("\033[32m")
RED   = _c("\033[31m")
CYAN  = _c("\033[36m")


# ---------------------------------------------------------------------------
# Test cases: (label, znodes, ynodes, xnodes, valuedim)
# ---------------------------------------------------------------------------
SIZES = [
    ("tiny    (  1 x  10 x  10 x 3)", 1,   10,  10,  3),
    ("small   (  1 x  50 x  50 x 3)", 1,   50,  50,  3),
    ("medium  (  1 x 100 x 100 x 3)", 1,  100, 100,  3),
    ("large   (  5 x 100 x 100 x 3)", 5,  100, 100,  3),
    ("xlarge  ( 10 x 100 x 100 x 3)", 10, 100, 100,  3),
    ("xxlarge ( 50 x 100 x 100 x 3)", 50, 100, 100,  3),
]

SIZES_FAST = SIZES[:3]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_data(z, y, x, d):
    return np.random.rand(z, y, x, d).astype(np.float32)


def _prep_ovf(OVFClass, data):
    """Create and populate an OVFFile-like object ready to write."""
    ovf = OVFClass()
    ovf.Title = "m"
    ovf.meshtype = "rectangular"
    ovf.meshunit = "m"
    ovf.xstepsize = 5e-9
    ovf.ystepsize = 5e-9
    ovf.zstepsize = 5e-9
    ovf.data = data
    return ovf


def _write_temp(OVFClass, data, path):
    ovf = _prep_ovf(OVFClass, data)
    ovf.write(path)


def _measure(fn, reps):
    """Run fn() reps times; return (mean_seconds, std_seconds)."""
    times = []
    for _ in range(reps):
        t0 = time.perf_counter()
        fn()
        times.append(time.perf_counter() - t0)
    mean = sum(times) / len(times)
    variance = sum((t - mean) ** 2 for t in times) / len(times)
    return mean, variance ** 0.5


def _throughput_mb(z, y, x, d, seconds):
    """MB/s for reading or writing z*y*x*d float32 values."""
    bytes_ = z * y * x * d * 4
    return (bytes_ / seconds) / (1024 ** 2)


# ---------------------------------------------------------------------------
# Benchmark runners
# ---------------------------------------------------------------------------

def bench_write(OVFClass, data, path, reps):
    def fn():
        ovf = _prep_ovf(OVFClass, data)
        ovf.write(path)
    return _measure(fn, reps)


def bench_read(OVFClass, path, reps):
    def fn():
        ovf = OVFClass()
        ovf.read(path)
    return _measure(fn, reps)


# ---------------------------------------------------------------------------
# Pretty-print table helpers
# ---------------------------------------------------------------------------

_C1, _C2, _C3, _C4 = 20, 28, 12, 13  # column content widths


def _tbl_sep(has_cpp=True):
    base = f"+{'-' * (_C1 + 2)}+{'-' * (_C2 + 2)}+{'-' * (_C3 + 2)}"
    return base + f"+{'-' * (_C4 + 2)}+" if has_cpp else base + "+"


def _tbl_hdr(has_cpp=True):
    base = f"| {'':^{_C1}} | {'mean +/- std':^{_C2}} | {'throughput':^{_C3}}"
    return base + f" | {'vs C++':^{_C4}} |" if has_cpp else base + " |"


def _tbl_row(name, t_str, mb_str, result=None, has_cpp=True):
    """result must be pre-padded to _C4 chars wide (may contain ANSI codes)."""
    base = f"| {name:<{_C1}} | {t_str:>{_C2}} | {mb_str:>{_C3}}"
    if not has_cpp:
        return base + " |"
    cell = result if result is not None else " " * _C4
    return base + f" | {cell} |"


def _fmt_t_pm(mean, std):
    """Format mean +/- std in consistent units."""
    if mean < 1e-3:
        return f"{mean * 1e6:.1f} +/- {std * 1e6:.1f} us"
    if mean < 1:
        return f"{mean * 1e3:.2f} +/- {std * 1e3:.2f} ms"
    return f"{mean:.3f} +/- {std:.3f} s"


def _fmt_mb(mb):
    return f"{mb:.1f} MB/s"


def _fmt_x(speedup):
    return f"{speedup:.2f}x"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

WIDTH = 78


def _verdict_cell(speedup, verdict):
    """Return a pre-padded, coloured speedup cell string (_C4 chars wide)."""
    color = GREEN if verdict == "faster" else RED
    return color + f"{_fmt_x(speedup)} {verdict}".rjust(_C4) + RESET


def run(reps, sizes):
    sep_line = BOLD + "=" * WIDTH + RESET
    print()
    print(sep_line)
    print(BOLD + "  pyOVF backend benchmark" + RESET)
    print(f"  Repetitions per measurement: {reps}  (mean +/- std shown)")
    if HAS_CPP:
        print(f"  C++ extension: {GREEN}available (OK){RESET}")
    else:
        print(f"  C++ extension: {RED}NOT available{RESET} -- only pure Python results shown")
    print(sep_line)

    for label, z, y, x, d in sizes:
        data = _make_data(z, y, x, d)
        size_mb = z * y * x * d * 4 / (1024 ** 2)
        cat = label.split()[0]

        print(f"\n  {CYAN}{BOLD}{cat}{RESET}  ({z} x {y} x {x} x {d})  --  {size_mb:.2f} MB of float32")

        with tempfile.NamedTemporaryFile(suffix=".ovf", delete=False) as tf:
            path = tf.name

        try:
            # ---- Measure writes ----
            py_w_mean, py_w_std = bench_write(PureOVFFile, data, path, reps)
            if HAS_CPP:
                cpp_w_mean, cpp_w_std = bench_write(CppOVFFile, data, path, reps)

            # Pre-write with pure Python so both backends read identical bytes
            _write_temp(PureOVFFile, data, path)

            # ---- Measure reads ----
            py_r_mean, py_r_std = bench_read(PureOVFFile, path, reps)
            if HAS_CPP:
                cpp_r_mean, cpp_r_std = bench_read(CppOVFFile, path, reps)

            # ---- Compute speedups ----
            if HAS_CPP:
                if py_w_mean >= cpp_w_mean:
                    w_speedup, w_label = py_w_mean / cpp_w_mean, "slower"
                else:
                    w_speedup, w_label = cpp_w_mean / py_w_mean, "faster"

                if py_r_mean >= cpp_r_mean:
                    r_speedup, r_label = py_r_mean / cpp_r_mean, "slower"
                else:
                    r_speedup, r_label = cpp_r_mean / py_r_mean, "faster"

            # ---- Print table ----
            sep = DIM + _tbl_sep(HAS_CPP) + RESET
            print(sep)
            print(_tbl_hdr(HAS_CPP))
            print(sep)

            if HAS_CPP:
                print(DIM + _tbl_row("C++ write",
                               _fmt_t_pm(cpp_w_mean, cpp_w_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, cpp_w_mean))) + RESET)
                print(_tbl_row("Pure Python write",
                               _fmt_t_pm(py_w_mean, py_w_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, py_w_mean)),
                               _verdict_cell(w_speedup, w_label)))
                print(sep)
                print(DIM + _tbl_row("C++ read",
                               _fmt_t_pm(cpp_r_mean, cpp_r_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, cpp_r_mean))) + RESET)
                print(_tbl_row("Pure Python read",
                               _fmt_t_pm(py_r_mean, py_r_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, py_r_mean)),
                               _verdict_cell(r_speedup, r_label)))
            else:
                print(_tbl_row("Pure Python write",
                               _fmt_t_pm(py_w_mean, py_w_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, py_w_mean)),
                               has_cpp=False))
                print(sep)
                print(_tbl_row("Pure Python read",
                               _fmt_t_pm(py_r_mean, py_r_std),
                               _fmt_mb(_throughput_mb(z, y, x, d, py_r_mean)),
                               has_cpp=False))

            print(sep)

        finally:
            Path(path).unlink(missing_ok=True)

    print()
    print(sep_line)
    if HAS_CPP:
        print("  Speedup = max(py, cpp) / min(py, cpp)  -- always >= 1x")
        print(f"  {GREEN}'faster'{RESET} = Pure Python wins  |  {RED}'slower'{RESET} = C++ wins")
    print(sep_line)
    print()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="pyOVF backend benchmark")
    parser.add_argument("--reps", type=int, default=10,
                        help="repetitions per measurement (default: 10)")
    parser.add_argument("--sizes", choices=["all", "fast"], default="all",
                        help="'fast' skips the two largest sizes (default: all)")
    args = parser.parse_args()

    chosen_sizes = SIZES_FAST if args.sizes == "fast" else SIZES
    run(reps=args.reps, sizes=chosen_sizes)
