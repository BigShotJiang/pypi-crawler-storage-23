# Complete Windows deployment workflow for PyPI
# (c) 2026 Prof. Flavio ABREU ARAUJO
# Run this in PowerShell from the pyovf directory

param(
    [string]$PyPIToken = $env:PYPI_TOKEN,
    [switch]$TestPyPI,
    [switch]$SkipTests
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "PyOVF Windows Deployment Workflow" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host ""

# ============================================================================
# Step 1: Validate production tag
# ============================================================================

Write-Host "Step 1: Validating production tag..." -ForegroundColor Green
Write-Host ""

try {
    $tag = git describe --tags --exact-match 2>$null
    if ($LASTEXITCODE -ne 0) {
        throw "No tag found"
    }
} catch {
    Write-Host "✗ Error: No git tag on current commit" -ForegroundColor Red
    Write-Host ""
    Write-Host "Production deployments require a git tag." -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Create a tag:" -ForegroundColor Cyan
    Write-Host "  git tag -a v0.2.11 -m 'Release v0.2.11'" -ForegroundColor Gray
    Write-Host "  git push origin v0.2.11" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

# Check for pre-release markers
if ($tag -match "\.dev\d+|a\d+|b\d+|rc\d+") {
    Write-Host "✗ Error: Pre-release tag detected: $tag" -ForegroundColor Red
    Write-Host ""
    Write-Host "Cannot deploy pre-release versions to production PyPI." -ForegroundColor Yellow
    Write-Host "Only stable versions are allowed (e.g., v0.2.11, v1.0.0)" -ForegroundColor Yellow
    Write-Host ""
    if ($TestPyPI) {
        Write-Host "Continuing with TestPyPI deployment..." -ForegroundColor Yellow
    } else {
        Write-Host "Use -TestPyPI flag to deploy development versions to TestPyPI." -ForegroundColor Cyan
        exit 1
    }
}

Write-Host "✓ Production tag validated: $tag" -ForegroundColor Green
Write-Host ""

# ============================================================================
# Step 2: Build wheels
# ============================================================================

Write-Host "Step 2: Building wheels..." -ForegroundColor Green
Write-Host ""

& .\build_wheels_windows.ps1

if ($LASTEXITCODE -ne 0) {
    Write-Host ""
    Write-Host "✗ Build failed" -ForegroundColor Red
    exit 1
}

# ============================================================================
# Step 3: Test wheels
# ============================================================================

if (-not $SkipTests) {
    Write-Host "Step 3: Testing wheels..." -ForegroundColor Green
    Write-Host ""

    # Find a wheel to test (prefer Python 3.13)
    $testWheel = Get-ChildItem dist\*cp313*.whl | Select-Object -First 1
    if (-not $testWheel) {
        # Fallback to any wheel
        $testWheel = Get-ChildItem dist\*.whl | Select-Object -First 1
    }

    if ($testWheel) {
        Write-Host "  → Testing: $($testWheel.Name)" -ForegroundColor Gray
        
        try {
            # Create test environment
            $testVenv = "test_venv_$(Get-Random)"
            py -3.13 -m venv $testVenv 2>&1 | Out-Null
            
            # Activate and test
            & ".\$testVenv\Scripts\Activate.ps1"
            pip install --quiet $testWheel.FullName
            $testResult = python -c "import pyovf; print('OK:', pyovf.__version__)" 2>&1
            deactivate
            
            # Cleanup
            Remove-Item $testVenv -Recurse -Force -ErrorAction SilentlyContinue
            
            if ($testResult -match "OK:") {
                Write-Host "  ✓ Import test successful: $testResult" -ForegroundColor Green
            } else {
                throw "Import test failed: $testResult"
            }
        } catch {
            Write-Host "  ✗ Wheel test failed: $_" -ForegroundColor Red
            Write-Host ""
            Write-Host "Fix the issue or use -SkipTests to skip testing" -ForegroundColor Yellow
            exit 1
        }
    } else {
        Write-Host "  ⚠ No wheels found to test" -ForegroundColor Yellow
    }
    Write-Host ""
} else {
    Write-Host "Step 3: Skipping tests (-SkipTests flag)" -ForegroundColor Yellow
    Write-Host ""
}

# ============================================================================
# Step 4: Upload to PyPI
# ============================================================================

Write-Host "Step 4: Uploading to " -NoNewline -ForegroundColor Green
if ($TestPyPI) {
    Write-Host "TestPyPI..." -ForegroundColor Yellow
} else {
    Write-Host "PyPI..." -ForegroundColor Green
}
Write-Host ""

# Check for PyPI token
if (-not $PyPIToken) {
    Write-Host "✗ Error: PYPI_TOKEN not set" -ForegroundColor Red
    Write-Host ""
    Write-Host "Set your PyPI API token:" -ForegroundColor Yellow
    Write-Host "  `$env:PYPI_TOKEN = 'pypi-AgEIcHlwaS5vcmc...'" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Or pass as parameter:" -ForegroundColor Yellow
    Write-Host "  .\deploy_windows.ps1 -PyPIToken 'pypi-AgEI...'" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Get your token at:" -ForegroundColor Cyan
    Write-Host "  https://pypi.org/manage/account/token/" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

# Check if twine is installed
try {
    twine --version 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "twine not found"
    }
} catch {
    Write-Host "✗ Error: twine not installed" -ForegroundColor Red
    Write-Host ""
    Write-Host "Install twine:" -ForegroundColor Yellow
    Write-Host "  pip install --upgrade twine" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

# Set environment variables for twine
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = $PyPIToken
$env:KEYRING_PROVIDER = "fail"  # Disable keyring to prevent interactive prompts

# Set repository URL
if ($TestPyPI) {
    $env:TWINE_REPOSITORY_URL = "https://test.pypi.org/legacy/"
    $repoUrl = "https://test.pypi.org/project/pyovf/"
} else {
    $env:TWINE_REPOSITORY_URL = "https://upload.pypi.org/legacy/"
    $repoUrl = "https://pypi.org/project/pyovf/"
}

# Count files to upload
$files = Get-ChildItem dist\* | Where-Object { $_.Extension -in ".whl", ".gz" }
Write-Host "  → Uploading $($files.Count) files..." -ForegroundColor Gray
foreach ($file in $files) {
    Write-Host "    - $($file.Name)" -ForegroundColor Gray
}
Write-Host ""

# Upload with twine
try {
    # Use --skip-existing to avoid errors if some files already exist
    twine upload --skip-existing --verbose dist/*
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host ""
        Write-Host "✓ Upload successful!" -ForegroundColor Green
    } else {
        throw "Upload failed with exit code $LASTEXITCODE"
    }
} catch {
    Write-Host ""
    Write-Host "✗ Upload failed: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Common issues:" -ForegroundColor Yellow
    Write-Host "  - Invalid PyPI token" -ForegroundColor Gray
    Write-Host "  - Version already exists on PyPI" -ForegroundColor Gray
    Write-Host "  - Network connection issues" -ForegroundColor Gray
    Write-Host ""
    exit 1
}

# ============================================================================
# Success
# ============================================================================

Write-Host ""
Write-Host "=========================================" -ForegroundColor Blue
Write-Host "Deployment Complete!" -ForegroundColor Blue
Write-Host "=========================================" -ForegroundColor Blue
Write-Host ""
Write-Host "✓ Tagged version: $tag" -ForegroundColor Green
Write-Host "✓ Wheels built: $($files.Count) files" -ForegroundColor Green
Write-Host "✓ Uploaded to: " -NoNewline -ForegroundColor Green
if ($TestPyPI) {
    Write-Host "TestPyPI" -ForegroundColor Yellow
} else {
    Write-Host "PyPI" -ForegroundColor Green
}
Write-Host ""
Write-Host "Check your release:" -ForegroundColor Cyan
Write-Host "  $repoUrl" -ForegroundColor Gray
Write-Host ""
Write-Host "Test installation:" -ForegroundColor Cyan
Write-Host "  pip install pyovf" -ForegroundColor Gray
Write-Host ""
