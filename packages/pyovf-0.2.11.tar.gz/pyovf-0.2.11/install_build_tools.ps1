# Install Microsoft C++ Build Tools for pyovf
# This script downloads and installs the required C++ compiler tools

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Microsoft C++ Build Tools Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "This script will download and install Microsoft C++ Build Tools"
Write-Host "which are required to build the pyovf package from source."
Write-Host ""

# Check if already installed
$vsWhere = "${env:ProgramFiles(x86)}\Microsoft Visual Studio\Installer\vswhere.exe"
if (Test-Path $vsWhere) {
    Write-Host "Checking for existing Visual Studio installations..." -ForegroundColor Yellow
    $installationPath = (& $vsWhere -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath | Out-String).Trim()
    if (-not [string]::IsNullOrWhiteSpace($installationPath)) {
        Write-Host "[OK] Visual C++ Build Tools are already installed!" -ForegroundColor Green
        Write-Host "Detected at: $installationPath" -ForegroundColor Green
        Write-Host ""
        Write-Host "You can now run: pip install -e ." -ForegroundColor Green
        exit 0
    }
}

Write-Host "Visual C++ Build Tools not found. Proceeding with installation..." -ForegroundColor Yellow
Write-Host ""

# Download URL
$url = "https://aka.ms/vs/17/release/vs_BuildTools.exe"
$installerPath = "$env:TEMP\vs_buildtools.exe"

Write-Host "Downloading installer..." -ForegroundColor Cyan
try {
    Invoke-WebRequest -Uri $url -OutFile $installerPath -UseBasicParsing
    Write-Host "[OK] Downloaded successfully" -ForegroundColor Green
} catch {
    Write-Host "[FAILED] Download failed: $_" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Starting Installation" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "The installer will now launch. Please:" -ForegroundColor Yellow
Write-Host "  1. Select 'Desktop development with C++' workload" -ForegroundColor Yellow
Write-Host "  2. Keep the default components selected" -ForegroundColor Yellow
Write-Host "  3. Click 'Install' and wait for completion" -ForegroundColor Yellow
Write-Host ""
Write-Host "Note: This will download approximately 1-2 GB of data" -ForegroundColor Yellow
Write-Host "      and may take 15-30 minutes depending on your connection." -ForegroundColor Yellow
Write-Host ""

# Run installer with required components
$arguments = @(
    "--quiet",
    "--wait",
    "--norestart",
    "--nocache",
    "--add", "Microsoft.VisualStudio.Workload.VCTools",
    "--add", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
    "--add", "Microsoft.VisualStudio.Component.Windows11SDK.22000",
    "--includeRecommended"
)

Write-Host "Launching installer with silent mode..." -ForegroundColor Cyan
Write-Host "Command: $installerPath $($arguments -join ' ')" -ForegroundColor Gray
Write-Host ""

try {
    # Check if running as administrator
    $isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    
    if (-not $isAdmin) {
        Write-Host "[WARNING] Administrator privileges required for installation" -ForegroundColor Yellow
        Write-Host "Attempting to elevate..." -ForegroundColor Yellow
        
        # Relaunch with admin rights
        $argumentsString = $arguments -join " "
        Start-Process -FilePath $installerPath -ArgumentList $argumentsString -Verb RunAs -Wait
    } else {
        Start-Process -FilePath $installerPath -ArgumentList $arguments -Wait
    }
    
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "Installation Complete!" -ForegroundColor Green
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "Next steps:" -ForegroundColor Green
    Write-Host "  1. Close and reopen your terminal/PowerShell window" -ForegroundColor Green
    Write-Host "  2. Navigate to the pyovf directory" -ForegroundColor Green
    Write-Host "  3. Run: pip install -e ." -ForegroundColor Green
    Write-Host ""
    
} catch {
    Write-Host ""
    Write-Host "[FAILED] Installation failed or was cancelled: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "Alternative: Manual Installation" -ForegroundColor Yellow
    Write-Host "  1. Run: $installerPath" -ForegroundColor Yellow
    Write-Host "  2. Select 'Desktop development with C++'" -ForegroundColor Yellow
    Write-Host "  3. Click Install" -ForegroundColor Yellow
    exit 1
}

# Cleanup
if (Test-Path $installerPath) {
    Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
}
