import os
import sys

# Change to a safe directory to avoid namespace package conflicts
# (the pyovf project directory can interfere with the installed package)
os.chdir(os.path.expanduser('~'))

import pyovf as OVF
import numpy as np

try:
    print(f"pyovf version: {OVF.__version__}")
except AttributeError:
    print("pyovf version: unknown")

print(f"pyovf location: {OVF.__file__}")
print(f"Available functions: {[attr for attr in dir(OVF) if not attr.startswith('_')]}")
print()

#* Create a (2, 2, 2, 3) ndarray representing a fictive vector field
data_in = np.array([[[[1.1, 1.2, 1.3],   # vector @ z-comp 0, y-comp 0, x-comp 0
                      [1.4, 1.5, 1.6]],  # vector @ z-comp 0, y-comp 0, x-comp 1
                     [[2.1, 2.2, 2.3],   # vector @ z-comp 0, y-comp 1, x-comp 0
                      [2.4, 2.5, 2.6]]], # vector @ z-comp 0, y-comp 1, x-comp 1
                    [[[3.1, 3.2, 3.3],   # vector @ z-comp 1, y-comp 0, x-comp 0
                      [3.4, 3.5, 3.6]],  # vector @ z-comp 1, y-comp 0, x-comp 1
                     [[4.1, 4.2, 4.3],   # vector @ z-comp 1, y-comp 1, x-comp 0
                      [4.4, 4.5, 4.6]]], # vector @ z-comp 1, y-comp 1, x-comp 1
                   ], dtype=np.float32)

#* Writes data_in into file
OVF.write('test.ovf', data_in, title="J", Xlim=[0,10e-9],
                Ylim=[0,10e-9], Zlim=[0,10e-9])

#* Reads data and meshgrid (X, Y) from file
# Note: Use return_mesh=True for backward compatibility with old API
X, Y, ovf = OVF.read('test.ovf', return_mesh=True)
data_out = ovf.data
#?INFO output format => data_out[z-comp, y-comp, x-comp, vect-comp]
#?INFO vect-comp = 0 for scalar field data (geam, etc.)
#?INFO vect-comp = {0, 1, 2} for vector field data (m, B_ext, etc.)
print(f"data_out shape: {data_out.shape}")

#? Checks if the data elements correspond
if (data_in == data_out.squeeze()).all():
    print('✓ Test passed (read with mesh)!')
else:
    print('✗ Test failed (read with mesh)')

#* Reads data (only) from file
data_out2 = OVF.read_data_only('test.ovf')
#?INFO read_data_only applies squeeze(), so z-comp may disappear
#?INFO if data is scalar field, the vect-comp also disappears
print(f"data_out2 shape: {data_out2.shape}")

#? Checks if the data elements correspond
if (data_in == data_out2).all():
    print('✓ Test passed (read_data_only)!')
else:
    print('✗ Test failed (read_data_only)')
