#!/bin/bash
# (c) 2026 Prof. Flavio ABREU ARAUJO
# PyOVF code verification script

set -e

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo "========================================="
echo "PyOVF Code Verification"
echo "========================================="
echo ""

# Check Python source files
echo -e "${YELLOW}Checking Python source files...${NC}"
py_ok=0
for file in pyovf/__init__.py pyovf/_version.py pyovf/helper_funcs.py pyovf/ovf_handler.py; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((py_ok++))
    else
        echo -e "${RED}✗${NC} $file (missing)"
    fi
done

# Check C++ binding files
echo ""
echo -e "${YELLOW}Checking C++ binding files...${NC}"
cpp_ok=0
for file in src/pyovf/bindings/ovf_bindings.cpp \
             src/pyovf/ovf-rw/src_c++/OVF_File.cpp \
             src/pyovf/ovf-rw/src_c++/OVF_File.h; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((cpp_ok++))
    else
        echo -e "${RED}✗${NC} $file (missing)"
    fi
done

# Check build system files
echo ""
echo -e "${YELLOW}Checking build system files...${NC}"
build_ok=0
for file in setup.py pyproject.toml CMakeLists.txt MANIFEST.in; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((build_ok++))
    else
        echo -e "${RED}✗${NC} $file (missing)"
    fi
done

# Check test files
echo ""
echo -e "${YELLOW}Checking test files...${NC}"
test_ok=0
for file in tests/test_pyovf.py tests/test_coverage_paths.py test.py; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((test_ok++))
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check documentation files
echo ""
echo -e "${YELLOW}Checking documentation files...${NC}"
docs_ok=0
for file in README.md BUILD_GUIDE.md DOCKER_WHEELS_GUIDE.md \
             WINDOWS_BUILD_SETUP.md CI_CD_QUICK_REFERENCE.md LICENSE; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((docs_ok++))
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check CI/CD files
echo ""
echo -e "${YELLOW}Checking CI/CD files...${NC}"
ci_ok=0
for file in .gitlab-ci.yml Dockerfile Dockerfile.manylinux; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((ci_ok++))
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check build scripts
echo ""
echo -e "${YELLOW}Checking build scripts...${NC}"
script_ok=0
for file in build.sh build_wheels.sh test.sh run_tests.sh \
             local_build_main.sh docker-build-wheels.sh \
             verify_architecture.sh setup_multiarch_env.sh; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((script_ok++))
        # Check if executable
        if [ ! -x "$file" ]; then
            echo -e "${YELLOW}  ⚠ Not executable (chmod +x $file)${NC}"
        fi
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check Windows-specific files
echo ""
echo -e "${YELLOW}Checking Windows-specific files...${NC}"
win_ok=0
for file in install_build_tools.ps1 install_from_gitbash.sh; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((win_ok++))
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check deployment scripts
echo ""
echo -e "${YELLOW}Checking deployment scripts...${NC}"
deploy_ok=0
for file in deploy_pypi.sh deploy_gitlab.sh release.sh delete_version_tag.sh; do
    if [ -f "$file" ]; then
        echo -e "${GREEN}✓${NC} $file"
        ((deploy_ok++))
    else
        echo -e "${YELLOW}⚠${NC} $file (missing)"
    fi
done

# Check code quality
echo ""
echo -e "${YELLOW}Checking code syntax...${NC}"
syntax_ok=0
if command -v python3 &> /dev/null; then
    for pyfile in pyovf/*.py; do
        if [ -f "$pyfile" ]; then
            if python3 -m py_compile "$pyfile" 2>/dev/null; then
                echo -e "${GREEN}✓${NC} $pyfile syntax OK"
                ((syntax_ok++))
            else
                echo -e "${RED}✗${NC} $pyfile syntax error"
            fi
        fi
    done
else
    echo -e "${YELLOW}⚠${NC} Python3 not found, skipping syntax check"
fi

echo ""
echo "========================================="
echo "Summary"
echo "========================================="
echo "Python source files: $py_ok/4"
echo "C++ binding files: $cpp_ok/3"
echo "Build system files: $build_ok/4"
echo "Test files: $test_ok/3"
echo "Documentation files: $docs_ok/6"
echo "CI/CD files: $ci_ok/3"
echo "Build scripts: $script_ok/8"
echo "Windows files: $win_ok/2"
echo "Deployment scripts: $deploy_ok/4"
if [ $syntax_ok -gt 0 ]; then
    echo "Python syntax checks: $syntax_ok passed"
fi
echo ""

# Final status
if [ $py_ok -eq 4 ] && [ $cpp_ok -eq 3 ] && [ $build_ok -ge 3 ]; then
    echo -e "${GREEN}✓ PyOVF code structure is complete!${NC}"
    echo ""
    echo "Next steps:"
    echo "  ${BLUE}Build & Test:${NC}"
    echo "    pip install -e ."
    echo "    python -m pytest tests/"
    echo ""
    echo "  ${BLUE}Build Wheels:${NC}"
    echo "    ./build_wheels.sh"
    echo "    ./docker-build-wheels.sh"
    echo ""
    echo "  ${BLUE}Deploy:${NC}"
    echo "    ./deploy_pypi.sh"
    echo "    git push --tags"
    echo ""
else
    echo -e "${YELLOW}⚠ Some critical files may be missing. Please check above.${NC}"
    echo ""
    if [ $py_ok -lt 4 ]; then
        echo -e "${RED}Critical:${NC} Missing Python source files"
    fi
    if [ $cpp_ok -lt 3 ]; then
        echo -e "${RED}Critical:${NC} Missing C++ binding files"
    fi
    if [ $build_ok -lt 3 ]; then
        echo -e "${RED}Critical:${NC} Missing build system files"
    fi
fi

echo ""
echo "========================================="
