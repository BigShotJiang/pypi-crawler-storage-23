# (c) 2020-2026 Prof. Flavio ABREU ARAUJO. All rights reserved.

"""
Setup script for pyovf - compiles C++ extension on-the-fly
Supports Python 3.8 - 3.14
"""

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from setuptools import Extension, setup # type: ignore
from setuptools.command.build_ext import build_ext # type: ignore

# ovf-rw repository URL
OVF_RW_REPO = "https://gitlab.flavio.be/flavio/ovf-rw.git"

# Microsoft Visual C++ Build Tools download URL
MSVC_BUILD_TOOLS_URL = "https://aka.ms/vs/17/release/vs_BuildTools.exe"


class CMakeExtension(Extension):
    """CMake extension for building C++ code"""
    
    def __init__(self, name: str, sourcedir: str = "") -> None:
        super().__init__(name, sources=[])
        self.sourcedir = os.fspath(Path(sourcedir).resolve())


class CMakeBuild(build_ext):
    """Custom build_ext command that runs CMake"""
    
    def _check_cpp_compiler(self) -> bool:
        """Check if a C++ compiler is available"""
        # Check for common C++ compilers
        compilers = ["cl", "g++", "clang++", "c++"]
        for compiler in compilers:
            if shutil.which(compiler):
                print(f"Found C++ compiler: {compiler}")
                return True

        # Check for Visual Studio VC toolchain component via vswhere
        vswhere = Path(os.environ.get("ProgramFiles(x86)", "")) / "Microsoft Visual Studio" / "Installer" / "vswhere.exe"
        if vswhere.exists():
            try:
                install_path = subprocess.check_output(
                    [
                        str(vswhere),
                        "-products", "*",
                        "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                        "-property", "installationPath",
                    ],
                    text=True,
                ).strip()
                if install_path:
                    print(f"Found Visual Studio C++ toolchain at: {install_path}")
                    return True
            except Exception:
                pass

        # Legacy fallback checks
        vs_paths = [
            "C:\\Program Files\\Microsoft Visual Studio\\2022\\",
            "C:\\Program Files (x86)\\Microsoft Visual Studio\\2022\\",
            "C:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\",
            "C:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\",
        ]
        for vs_path in vs_paths:
            if os.path.exists(vs_path):
                print(f"Found Visual Studio installation at: {vs_path}")
                return True
        
        return False
    
    def _download_build_tools_installer(self) -> Path:
        """Download Microsoft Visual C++ Build Tools installer"""
        try:
            import urllib.request
            import tempfile
            
            print("\nDownloading Microsoft Visual C++ Build Tools installer...")
            print(f"URL: {MSVC_BUILD_TOOLS_URL}")
            
            temp_dir = Path(tempfile.gettempdir())
            installer_path = temp_dir / "vs_buildtools.exe"
            
            # Download the installer
            urllib.request.urlretrieve(MSVC_BUILD_TOOLS_URL, installer_path)
            
            print(f"[OK] Downloaded installer to: {installer_path}")
            return installer_path
            
        except Exception as e:
            print(f"[FAILED] Failed to download installer: {e}")
            return None
    
    def _offer_build_tools_installation(self) -> bool:
        """Offer to download and install Microsoft C++ Build Tools"""
        print("\n" + "="*70)
        print("C++ COMPILER NOT FOUND")
        print("="*70)
        print("\nBuilding pyovf requires a C++ compiler.")
        print("\nOptions:")
        print("  1. Auto-download Microsoft C++ Build Tools installer (Recommended)")
        print("  2. Use pre-built wheel from PyPI (if available)")
        print("  3. Install manually and retry")
        print("  4. Abort installation")
        print("="*70)
        
        # Check environment variable for automation
        auto_install = os.environ.get("PYOVF_AUTO_INSTALL_BUILDTOOLS", "").lower()
        is_ci = any(
            os.environ.get(var, "").strip().lower() in {"1", "true", "yes"}
            for var in ("CI", "GITHUB_ACTIONS", "GITLAB_CI", "TF_BUILD")
        )
        
        if auto_install == "yes":
            choice = "1"
            print("Environment variable PYOVF_AUTO_INSTALL_BUILDTOOLS=yes detected")
            print("Automatically selecting option 1...\n")
        elif auto_install == "skip":
            choice = "2"
            print("Environment variable PYOVF_AUTO_INSTALL_BUILDTOOLS=skip detected")
            print("Automatically selecting option 2...\n")
        elif auto_install == "abort":
            choice = "4"
            print("Environment variable PYOVF_AUTO_INSTALL_BUILDTOOLS=abort detected")
            print("Automatically selecting option 4...\n")
        else:
            # Check if we're in an interactive terminal
            is_interactive = sys.stdin.isatty() if hasattr(sys.stdin, 'isatty') else False
            
            if not is_interactive:
                # Non-interactive environment (PEP 517 build subprocess, CI, etc.)
                print("\nNon-interactive build environment detected.")
                if is_ci:
                    choice = "2"
                    print("CI environment detected; automatically selecting option 2 (skip).")
                    print("Use pre-built wheels in CI: pip install pyovf")
                elif platform.system() == "Windows":
                    choice = "1"
                    print("Windows local environment detected; automatically selecting option 1.")
                    print("Tip: Set PYOVF_AUTO_INSTALL_BUILDTOOLS=skip to avoid installer download.")
                    print("Tip: Set PYOVF_AUTO_INSTALL_BUILDTOOLS=abort to fail immediately.")
                else:
                    choice = "3"
                    print("Non-Windows environment detected; automatically selecting option 3.")
                    print("Install a C++ compiler and re-run pip install -e .")
            
            if is_interactive:
                # Interactive mode
                try:
                    choice = input("\nEnter your choice (1-4): ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nAborted by user.")
                    return False
        
        if choice == "1":
            # Download and open installer
            installer_path = self._download_build_tools_installer()
            if installer_path and installer_path.exists():
                print("\n" + "-"*70)
                print("MANUAL INSTALLATION REQUIRED")
                print("-"*70)
                print("\nThe installer has been downloaded. To complete installation:")
                print(f"  1. Run: {installer_path}")
                print("  2. Select 'Desktop development with C++'")
                print("  3. Click Install and wait for completion")
                print("  4. Restart your terminal")
                print(f"  5. Run: pip install -e {Path(__file__).parent}")
                print("-"*70)
                
                # Try to open the installer
                if platform.system() == "Windows":
                    try:
                        os.startfile(installer_path)
                        print(f"\n[OK] Opened installer: {installer_path}")
                    except Exception as e:
                        print(f"\n[FAILED] Could not auto-open installer: {e}")
                        print(f"Please manually run: {installer_path}")
                
                print("\nInstallation will abort now. Please run pip install again after")
                print("installing the C++ Build Tools.")
                return False
        
        elif choice == "2":
            print("\nAttempting to use pre-built wheels from PyPI...")
            print("Please try: pip uninstall pyovf && pip install pyovf")
            return False
        
        elif choice == "3":
            print("\nPlease install one of the following:")
            print("  • Microsoft C++ Build Tools:")
            print("    https://visualstudio.microsoft.com/visual-cpp-build-tools/")
            print("  • MinGW-w64: https://www.mingw-w64.org/")
            print("  • LLVM/Clang: https://clang.llvm.org/")
            print("\nThen run: pip install -e . again")
            return False
        
        else:
            print("\nInstallation aborted.")
            return False
        
        return False
    
    def _get_cmake_generator(self) -> str:
        """Detect an appropriate CMake generator for Windows"""
        import shutil
        
        # Prefer Visual Studio generators on Windows when available.
        # This avoids requiring cl.exe to be preloaded in PATH (unlike Ninja toolchains).
        vswhere = Path(os.environ.get("ProgramFiles(x86)", "")) / "Microsoft Visual Studio" / "Installer" / "vswhere.exe"
        if vswhere.exists():
            try:
                version_out = subprocess.check_output(
                    [
                        str(vswhere),
                        "-products", "*",
                        "-requires", "Microsoft.VisualStudio.Component.VC.Tools.x86.x64",
                        "-property", "catalog_productLineVersion",
                    ],
                    text=True,
                ).strip()
                if version_out:
                    first_version = version_out.splitlines()[0].strip()
                    generator_map = {
                        "2022": "Visual Studio 17 2022",
                        "2019": "Visual Studio 16 2019",
                        "2017": "Visual Studio 15 2017",
                    }
                    if first_version in generator_map:
                        generator = generator_map[first_version]
                        print(f"Using CMake generator: {generator}")
                        return generator
            except Exception:
                pass

        # Fallback: directory existence checks
        vs_versions = [
            ("2022", "Visual Studio 17 2022", "C:\\Program Files\\Microsoft Visual Studio\\2022\\"),
            ("2019", "Visual Studio 16 2019", "C:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\"),
            ("2017", "Visual Studio 15 2017", "C:\\Program Files (x86)\\Microsoft Visual Studio\\2017\\"),
        ]

        for _, generator, vs_path in vs_versions:
            if os.path.exists(vs_path):
                print(f"Using CMake generator: {generator}")
                return generator

        # Next priority: Ninja (works well when a compiler toolchain is available)
        if shutil.which("ninja"):
            print("Using CMake generator: Ninja")
            return "Ninja"
        
        # Try Unix Makefiles if make is available
        if shutil.which("make"):
            print("Using CMake generator: Unix Makefiles")
            return "Unix Makefiles"
        
        # Try NMake if available
        if shutil.which("nmake"):
            print("Warning: Using NMake Makefiles. Consider installing Ninja for better compatibility.")
            return "NMake Makefiles"
        
        # If nothing else works, print a helpful error
        print("Warning: Could not detect a suitable CMake generator.")
        print("Available tools:")
        print(f"  - cmake: {shutil.which('cmake')}")
        print(f"  - ninja: {shutil.which('ninja')}")
        print(f"  - make: {shutil.which('make')}")
        print(f"  - nmake: {shutil.which('nmake')}")
        print("  - Visual Studio 2022: ", "NOT FOUND")
        print("  - Visual Studio 2019: ", "NOT FOUND")
        print("\nConsider installing: pip install cmake  (or build-tools)")
        return None
    
    def build_extension(self, ext: CMakeExtension) -> None:
        # Check for C++ compiler on Windows before attempting build
        if platform.system() == "Windows":
            if not self._check_cpp_compiler():
                print("\n" + "="*70)
                print("WARNING: No C++ compiler found -- skipping C++ extension build.")
                print("="*70)
                print("\npyovf will install with the pure Python fallback (_ovf_pure_python).")
                print("To enable the C++ backend, install a compiler and reinstall:")
                print("  https://visualstudio.microsoft.com/visual-cpp-build-tools/")
                print("  pip install pyovf --no-binary pyovf")
                print("="*70 + "\n")
                return
        
        try:
            # Ensure ovf-rw sources are available
            self._ensure_ovf_rw_sources()

            ext_fullpath = Path.cwd() / self.get_ext_fullpath(ext.name)
            extdir = ext_fullpath.parent.resolve()

            # CMake configuration
            debug = int(os.environ.get("DEBUG", 0)) if self.debug is None else self.debug
            cfg = "Debug" if debug else "Release"

            cmake_args = [
                f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY={extdir}{os.sep}",
                f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY_RELEASE={extdir}{os.sep}",
                f"-DCMAKE_LIBRARY_OUTPUT_DIRECTORY_DEBUG={extdir}{os.sep}",
                f"-DPYTHON_EXECUTABLE={sys.executable}",
                f"-DCMAKE_BUILD_TYPE={cfg}",
            ]

            build_args = []

            if platform.system() == "Windows":
                # Detect and set appropriate generator
                generator = self._get_cmake_generator()
                if generator:
                    cmake_args += ["-G", generator]

                # Only use -A flag with generators that support it (Visual Studio)
                if generator and "Visual Studio" in generator:
                    cmake_args += [
                        "-A", "x64" if sys.maxsize > 2**32 else "Win32",
                    ]

                build_args += ["--config", cfg]
            else:
                # Unix-like systems
                cmake_args += [f"-DCMAKE_BUILD_TYPE={cfg}"]

            # Parallel build
            if "CMAKE_BUILD_PARALLEL_LEVEL" not in os.environ:
                if hasattr(self, "parallel") and self.parallel:
                    build_args += [f"-j{self.parallel}"]
                else:
                    import multiprocessing
                    build_args += [f"-j{multiprocessing.cpu_count()}"]

            build_temp = Path(self.build_temp) / ext.name
            build_temp.mkdir(parents=True, exist_ok=True)

            subprocess.run(
                ["cmake", ext.sourcedir, *cmake_args],
                cwd=build_temp,
                check=True,
            )
            subprocess.run(
                ["cmake", "--build", ".", *build_args],
                cwd=build_temp,
                check=True,
            )
        except Exception as e:
            print("\n" + "="*70)
            print("WARNING: C++ extension (_ovf_core) could not be built.")
            print("="*70)
            print(f"\nReason: {e}")
            print("\npyovf will install successfully using the pure Python fallback")
            print("(_ovf_pure_python), which is fully functional.")
            print("\nTo enable the C++ extension, install a C++ compiler")
            print("and reinstall from source:  pip install pyovf --no-binary pyovf")
            print("="*70 + "\n")
    
    def _ensure_ovf_rw_sources(self) -> None:
        """Ensure ovf-rw sources are available for building"""
        this_dir = Path(__file__).parent.resolve()
        
        # Check multiple possible locations
        possible_locations = [
            this_dir.parent / "ovf-rw" / "src_c++",  # Sibling directory
            this_dir / "src" / "pyovf" / "ovf-rw" / "src_c++",  # Bundled
            this_dir / "ovf-rw" / "src_c++",  # Local clone
        ]
        
        for loc in possible_locations:
            if (loc / "OVF_File.cpp").exists() and (loc / "OVF_File.h").exists():
                print(f"Found ovf-rw sources at: {loc}")
                return
        
        # Sources not found, try to clone
        print("ovf-rw sources not found, attempting to clone...")
        target_dir = this_dir / "src" / "pyovf" / "ovf-rw"
        
        if self._clone_ovf_rw(target_dir):
            return
        
        raise RuntimeError(
            "Could not find or clone ovf-rw source directory.\n"
            "Please either:\n"
            "  1. Clone ovf-rw next to pyovf: git clone https://gitlab.flavio.be/flavio/ovf-rw.git\n"
            "  2. Or place OVF_File.cpp and OVF_File.h in src/pyovf/ovf-rw/src_c++/\n"
        )
    
    def _clone_ovf_rw(self, target_dir: Path) -> bool:
        """Clone ovf-rw repository and extract needed sources"""
        try:
            import tempfile
            
            with tempfile.TemporaryDirectory() as tmpdir:
                print(f"Cloning ovf-rw from {OVF_RW_REPO}...")
                result = subprocess.run(
                    ["git", "clone", "--depth", "1", OVF_RW_REPO, tmpdir],
                    capture_output=True,
                    text=True,
                )
                
                if result.returncode != 0:
                    print(f"Git clone failed: {result.stderr}")
                    return False
                
                # Copy needed sources
                src_dir = Path(tmpdir) / "src_c++"
                dest_dir = target_dir / "src_c++"
                dest_dir.mkdir(parents=True, exist_ok=True)
                
                for filename in ["OVF_File.cpp", "OVF_File.h"]:
                    src_file = src_dir / filename
                    dest_file = dest_dir / filename
                    if src_file.exists():
                        shutil.copy2(src_file, dest_file)
                        print(f"Copied {filename} to {dest_file}")
                    else:
                        print(f"Warning: {filename} not found in cloned repo")
                        return False
                
                print("Successfully fetched ovf-rw sources")
                return True
                
        except Exception as e:
            print(f"Failed to clone ovf-rw: {e}")
            return False


def get_ovf_rw_source_dir() -> str:
    """Get the path to ovf-rw source directory"""
    # Check relative to this file
    this_dir = Path(__file__).parent.resolve()
    
    # Check sibling directory first (development setup)
    ovf_rw_dir = this_dir.parent / "ovf-rw"
    if ovf_rw_dir.exists():
        return str(ovf_rw_dir)
    
    # Check if sources are bundled with the package
    bundled_dir = this_dir / "src" / "pyovf" / "ovf-rw"
    if bundled_dir.exists():
        return str(bundled_dir)
    
    # Check local clone
    local_dir = this_dir / "ovf-rw"
    if local_dir.exists():
        return str(local_dir)
    
    raise RuntimeError(
        "Could not find ovf-rw source directory. "
        "Please ensure the ovf-rw directory is present."
    )


setup(
    ext_modules=[CMakeExtension("pyovf._ovf_core", sourcedir=".")],
    cmdclass={"build_ext": CMakeBuild},
)
