# Building pyovf on Windows - C++ Compiler Setup

This guide explains how to set up the required C++ compiler for building pyovf from source on Windows.

## Important: Terminal Choice

**Git Bash / MINGW64 Users**: The interactive installer prompt doesn't work in Git Bash. Use one of these alternatives:
- Run `./install_from_gitbash.sh` (easiest)
- Set environment variable first (manual)
- Use PowerShell for interactive mode
- Use the standalone PowerShell script

## Quick Start

### Option 1: Git Bash Helper Script (Easiest)

```bash
# In Git Bash
cd pyovf
chmod +x install_from_gitbash.sh
./install_from_gitbash.sh
```

This interactive script handles the environment variables for you.

### Option 2: Git Bash with Environment Variable

```bash
# In Git Bash
export PYOVF_AUTO_INSTALL_BUILDTOOLS=yes
pip install -e .
```

The installer will download automatically and open for you to complete.

### Option 3: Automatic Installation (Recommended for PowerShell)

Run the provided PowerShell script:

```powershell
cd pyovf
.\install_build_tools.ps1
```

This will automatically download and install Microsoft Visual C++ Build Tools.

### Option 4: Environment Variable Control

**For PowerShell:**
```powershell
# Automatically download build tools installer
$env:PYOVF_AUTO_INSTALL_BUILDTOOLS = "yes"
pip install -e .

# Skip compiler build and suggest using pre-built wheels
$env:PYOVF_AUTO_INSTALL_BUILDTOOLS = "skip"
pip install -e .
```

**For Git Bash / CMD:**
```bash
# Git Bash
export PYOVF_AUTO_INSTALL_BUILDTOOLS=yes
pip install -e .

# CMD
set PYOVF_AUTO_INSTALL_BUILDTOOLS=yes
pip install -e .
```

### Option 5: Interactive Installation

Simply run:

```powershell
pip install -e .
```

If no C++ compiler is detected, you'll be presented with options:
1. Auto-download Microsoft C++ Build Tools installer
2. Use pre-built wheel from PyPI (if available)
3. Install manually and retry
4. Abort installation

### Option 6: Manual Installation

1. Download Microsoft C++ Build Tools from:
   https://visualstudio.microsoft.com/visual-cpp-build-tools/

2. Run the installer and select:
   - ✓ Desktop development with C++
   - ✓ Windows 11 SDK
   - ✓ CMake tools for Windows

3. After installation completes, close and reopen your terminal

4. Run: `pip install -e .`

## Alternative: Use Pre-built Wheels

If you don't need to modify the C++ code, you can install pre-built wheels from PyPI:

```powershell
pip install pyovf
```

This downloads pre-compiled binaries and doesn't require a C++ compiler.

## Requirements

Building from source requires:
- **C++ Compiler**: MSVC, MinGW-w64, or Clang
- **CMake**: Automatically installed via `pip` (included in `pyproject.toml`)
- **Ninja**: Automatically installed via `pip` (included in `pyproject.toml`)

The build system will automatically detect and use available tools.

## Troubleshooting

### MAX_PATH (260-character) Error — `MSB4018` / path too long

**Symptom**: Build fails with a CMake error referencing path length:

```
error MSB4018: System.InvalidOperationException: ... The fully qualified file name must be less than 260 characters.
```

**Cause**: Windows limits paths to 260 characters by default. The pip temporary build directory (`%TEMP%\pip-install-...\pyovf_...\build\temp.win-amd64-cpython-NNN\...`) is already long enough that nested CMake scratch paths exceed the limit.

**Fix 1 — Enable long paths system-wide (recommended, requires admin)**

Run PowerShell as Administrator:

```powershell
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" `
    -Name "LongPathsEnabled" -Value 1 -PropertyType DWORD -Force
```

Restart your terminal. `pip install pyovf` will then work normally.

**Fix 2 — Install from local source (no admin needed)**

Building from your local clone uses a much shorter path:

```bash
cd pyovf
pip install -e .
```

**Fix 3 — Use a shorter TEMP directory (no admin needed, per-session)**

```cmd
set TEMP=C:\T
set TMP=C:\T
mkdir C:\T 2>nul
pip install pyovf
```

---

### "Aborted by user" error in Git Bash

If you see "Aborted by user" when running `pip install -e .` in Git Bash:

**Solution**: Git Bash doesn't support interactive input during pip builds. Use environment variables:
```bash
export PYOVF_AUTO_INSTALL_BUILDTOOLS=yes
pip install -e .
```

Or switch to PowerShell for interactive mode:
```bash
powershell
cd pyovf
.\install_build_tools.ps1
```

### "C++ compiler not found" error

**Solution 1**: Run `.\install_build_tools.ps1` as administrator

**Solution 2**: Install Visual Studio Build Tools manually:
- Download from: https://visualstudio.microsoft.com/downloads/
- Select "Desktop development with C++" during installation

**Solution 3**: Use pre-built wheels: `pip install pyovf` (instead of `-e .`)

### Build fails with "CMake Error: CMAKE_CXX_COMPILER not set"

This means CMake can't find your C++ compiler. Solutions:
- Restart your terminal after installing Build Tools
- Add compiler to PATH
- Run from a "Developer Command Prompt for VS"

### "Permission denied" when downloading installer

Run PowerShell as Administrator:
```powershell
Start-Process powershell -Verb runAs
cd path\to\pyovf
.\install_build_tools.ps1
```

## Environment Variables

- `PYOVF_AUTO_INSTALL_BUILDTOOLS=yes`: Auto-download and launch installer
- `PYOVF_AUTO_INSTALL_BUILDTOOLS=skip`: Skip build, suggest pre-built wheels
- `DEBUG=1`: Build extension in debug mode with symbols

## For CI/CD Systems

In automated environments (like GitHub Actions, GitLab CI), set:

```yaml
env:
  PYOVF_AUTO_INSTALL_BUILDTOOLS: skip
```

Then either:
- Use pre-built wheels with `pip install pyovf`
- Pre-install build tools in your CI image
- Use manylinux Docker images for Linux builds

## More Information

- Main README: [../README.md](../README.md)
- Build Guide: [BUILD_GUIDE.md](BUILD_GUIDE.md)
- PyPI Package: https://pypi.org/project/pyovf/
