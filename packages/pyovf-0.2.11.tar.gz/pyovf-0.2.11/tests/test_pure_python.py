"""
Tests for the pure Python OVF fallback (pyovf._ovf_pure_python).

These tests import the fallback module directly and therefore run regardless
of whether the C++ extension (_ovf_core) is available or not.

Coverage targets:
  - OVFFile construction and data property
  - write() — header fields, magic number, binary layout
  - read()  — header parsing, Desc SimTime, data shape
  - Full roundtrip (vector, scalar, edge cases)
  - Binary format byte-level correctness
  - Unsupported format errors (Text, Binary 8), truncated file
  - file_exists() utility
  - Integration with ovf_handler when C++ extension is patched out
"""

import os
import struct
import sys
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pytest # type: ignore

# Make sure the repo root is importable even when running without an install
_REPO_ROOT = Path(__file__).resolve().parents[1]
if str(_REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(_REPO_ROOT))

from pyovf._ovf_pure_python import OVFFile, file_exists  # noqa: E402

_MAGIC_BYTES = struct.pack("<f", 1234567.0)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _vector_ovf(znodes=2, ynodes=10, xnodes=20, valuedim=3, title="m",
                xstep=5e-9, ystep=5e-9, zstep=10e-9):
    ovf = OVFFile()
    data = np.random.rand(znodes, ynodes, xnodes, valuedim).astype(np.float32)
    ovf.data = data
    ovf.Title = title
    ovf.meshtype = "rectangular"
    ovf.meshunit = "m"
    ovf.xstepsize = xstep
    ovf.ystepsize = ystep
    ovf.zstepsize = zstep
    return ovf, data


def _scalar_ovf(znodes=1, ynodes=30, xnodes=40, title="pressure",
                xstep=1e-9, ystep=1e-9, zstep=1e-9):
    ovf = OVFFile()
    data = np.random.rand(znodes, ynodes, xnodes).astype(np.float32)
    ovf.data = data
    ovf.Title = title
    ovf.meshtype = "rectangular"
    ovf.meshunit = "m"
    ovf.xstepsize = xstep
    ovf.ystepsize = ystep
    ovf.zstepsize = zstep
    return ovf, data


# ---------------------------------------------------------------------------
# Construction and data property
# ---------------------------------------------------------------------------

class TestConstruction:

    def test_default_attributes(self):
        ovf = OVFFile()
        assert ovf.Title == ""
        assert ovf.meshtype == ""
        assert ovf.meshunit == ""
        assert ovf.xnodes == 0
        assert ovf.ynodes == 0
        assert ovf.znodes == 0
        assert ovf.valuedim == 0
        assert ovf.elementNum == 0
        assert ovf.data is None
        assert ovf.xstepsize == 0.0
        assert ovf.ystepsize == 0.0
        assert ovf.zstepsize == 0.0
        assert ovf.xmin == ovf.ymin == ovf.zmin == 0.0
        assert ovf.xmax == ovf.ymax == ovf.zmax == 0.0
        assert ovf.xbase == ovf.ybase == ovf.zbase == 0.0
        assert ovf.TotalSimTime == 0.0
        assert ovf.TotalSimTimeUnit == ""
        assert ovf.StageSimTime == 0.0
        assert ovf.StageSimTimeUnit == ""

    def test_set_vector_data_updates_dims(self):
        ovf = OVFFile()
        data = np.ones((3, 10, 20, 3), dtype=np.float32)
        ovf.data = data
        assert ovf.znodes == 3
        assert ovf.ynodes == 10
        assert ovf.xnodes == 20
        assert ovf.valuedim == 3
        assert ovf.elementNum == 3 * 10 * 20 * 3

    def test_set_scalar_data_updates_dims(self):
        ovf = OVFFile()
        data = np.ones((1, 50, 50), dtype=np.float32)
        ovf.data = data
        assert ovf.znodes == 1
        assert ovf.ynodes == 50
        assert ovf.xnodes == 50
        assert ovf.valuedim == 1
        assert ovf.elementNum == 1 * 50 * 50

    def test_data_setter_converts_to_float32(self):
        ovf = OVFFile()
        ovf.data = np.ones((1, 5, 5, 3), dtype=np.float64)
        assert ovf.data.dtype == np.float32

    def test_data_setter_2d_raises(self):
        ovf = OVFFile()
        with pytest.raises(ValueError):
            ovf.data = np.ones((10, 10))

    def test_data_setter_5d_raises(self):
        ovf = OVFFile()
        with pytest.raises(ValueError):
            ovf.data = np.ones((1, 2, 3, 4, 5))

    def test_repr_contains_class_name_and_title(self):
        ovf, _ = _vector_ovf(title="mag")
        r = repr(ovf)
        assert "OVFFile" in r
        assert "mag" in r

    def test_repr_contains_dimensions(self):
        ovf, _ = _vector_ovf(znodes=2, ynodes=10, xnodes=20)
        r = repr(ovf)
        assert "20" in r
        assert "10" in r
        assert "2" in r


# ---------------------------------------------------------------------------
# Write — ASCII header structure
# ---------------------------------------------------------------------------

class TestWriteHeader:

    def _read_ascii(self, path):
        return Path(path).read_bytes().decode("ascii", errors="replace")

    def test_write_creates_file(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "out.ovf")
        ovf.write(path)
        assert os.path.exists(path)
        assert os.path.getsize(path) > 0

    def test_write_oommf_signature(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "sig.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "# OOMMF OVF 2.0" in text

    def test_write_segment_markers(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "seg.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "# Begin: Segment" in text
        assert "# End: Segment" in text
        assert "# Begin: Header" in text
        assert "# End: Header" in text

    def test_write_data_markers(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "data.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "# Begin: Data Binary 4" in text
        assert "# End: Data Binary 4" in text

    def test_write_title(self, tmp_path):
        ovf, _ = _vector_ovf(title="magnetization")
        path = str(tmp_path / "t.ovf")
        ovf.write(path)
        assert "# Title: magnetization" in self._read_ascii(path)

    def test_write_grid_dimensions(self, tmp_path):
        ovf, _ = _vector_ovf(znodes=2, ynodes=10, xnodes=20)
        path = str(tmp_path / "grid.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "# xnodes: 20" in text
        assert "# ynodes: 10" in text
        assert "# znodes: 2" in text
        assert "# valuedim: 3" in text

    def test_write_valuelabels_m(self, tmp_path):
        ovf, _ = _vector_ovf(title="m")
        path = str(tmp_path / "m.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "valuelabels: m_x m_y m_z" in text
        assert "valueunits: 1 1 1" in text

    def test_write_valuelabels_B_ext(self, tmp_path):
        ovf, _ = _vector_ovf(title="B_ext")
        path = str(tmp_path / "bext.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "valuelabels: B_ext_x B_ext_y B_ext_z" in text
        assert "valueunits: T T T" in text

    def test_write_valuelabels_J(self, tmp_path):
        ovf, _ = _vector_ovf(title="J")
        path = str(tmp_path / "j.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "valuelabels: J_x J_y J_z" in text
        assert "valueunits: A/m^2 A/m^2 A/m^2" in text

    def test_write_valuelabels_scalar(self, tmp_path):
        ovf, _ = _scalar_ovf(title="pressure")
        path = str(tmp_path / "sc.ovf")
        ovf.write(path)
        text = self._read_ascii(path)
        assert "valuelabels: pressure" in text
        assert "valueunits: 1" in text

    def test_write_no_data_raises(self):
        ovf = OVFFile()
        with pytest.raises(ValueError):
            ovf.write("/tmp/_pyovf_should_not_exist.ovf")


# ---------------------------------------------------------------------------
# Write — binary data layout
# ---------------------------------------------------------------------------

class TestWriteBinary:

    def _data_offset(self, content):
        """Return the byte offset right after the magic number."""
        marker = b"# Begin: Data Binary 4\n"
        idx = content.index(marker) + len(marker)
        return idx + 4  # skip 4-byte magic

    def test_magic_number_value(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "magic.ovf")
        ovf.write(path)
        content = Path(path).read_bytes()
        marker = b"# Begin: Data Binary 4\n"
        idx = content.index(marker) + len(marker)
        magic = struct.unpack("<f", content[idx: idx + 4])[0]
        assert magic == pytest.approx(1234567.0)

    def test_magic_bytes_present(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "magic2.ovf")
        ovf.write(path)
        assert _MAGIC_BYTES in Path(path).read_bytes()

    def test_data_bytes_correct(self, tmp_path):
        znodes, ynodes, xnodes, valuedim = 1, 2, 3, 3
        data = np.arange(
            znodes * ynodes * xnodes * valuedim, dtype=np.float32
        ).reshape(znodes, ynodes, xnodes, valuedim)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "bytes.ovf")
        ovf.write(path)

        content = Path(path).read_bytes()
        idx = self._data_offset(content)
        n = znodes * ynodes * xnodes * valuedim
        raw = np.frombuffer(content[idx: idx + n * 4], dtype=np.float32)
        np.testing.assert_array_equal(raw, data.ravel())

    def test_data_block_size(self, tmp_path):
        znodes, ynodes, xnodes, valuedim = 2, 5, 8, 3
        data = np.ones((znodes, ynodes, xnodes, valuedim), dtype=np.float32)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "size.ovf")
        ovf.write(path)

        content = Path(path).read_bytes()
        idx = self._data_offset(content)
        n = znodes * ynodes * xnodes * valuedim
        # Verify exactly n floats fit between magic and "# End:"
        end_marker = b"# End: Data Binary 4"
        end_idx = content.index(end_marker)
        # There may be a '\n' byte between data and end marker (OOMMF style)
        assert end_idx - idx in (n * 4, n * 4 + 1)

    def test_scalar_data_bytes_correct(self, tmp_path):
        data = np.arange(1 * 4 * 5, dtype=np.float32).reshape(1, 4, 5)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "scalar"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "sc.ovf")
        ovf.write(path)

        content = Path(path).read_bytes()
        idx = self._data_offset(content)
        n = 1 * 4 * 5
        raw = np.frombuffer(content[idx: idx + n * 4], dtype=np.float32)
        np.testing.assert_array_equal(raw, data.ravel())


# ---------------------------------------------------------------------------
# Read — header parsing
# ---------------------------------------------------------------------------

class TestReadHeader:

    def test_read_title(self, tmp_path):
        ovf, _ = _vector_ovf(title="myfield")
        path = str(tmp_path / "title.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.Title == "myfield"

    def test_read_meshtype_meshunit(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "mesh.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.meshtype == "rectangular"
        assert ovf2.meshunit == "m"

    def test_read_grid_nodes(self, tmp_path):
        ovf, _ = _vector_ovf(znodes=3, ynodes=7, xnodes=11)
        path = str(tmp_path / "nodes.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.znodes == 3
        assert ovf2.ynodes == 7
        assert ovf2.xnodes == 11

    def test_read_step_sizes(self, tmp_path):
        ovf, _ = _vector_ovf(xstep=3e-9, ystep=4e-9, zstep=8e-9)
        path = str(tmp_path / "steps.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.xstepsize == pytest.approx(3e-9)
        assert ovf2.ystepsize == pytest.approx(4e-9)
        assert ovf2.zstepsize == pytest.approx(8e-9)

    def test_read_valuedim(self, tmp_path):
        ovf, _ = _vector_ovf(valuedim=3)
        path = str(tmp_path / "vdim.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.valuedim == 3

    def test_read_desc_total_simtime(self, tmp_path):
        ovf, _ = _vector_ovf()
        ovf.TotalSimTime = 2e-9
        ovf.TotalSimTimeUnit = "s"
        path = str(tmp_path / "time.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.TotalSimTime == pytest.approx(2e-9)
        assert ovf2.TotalSimTimeUnit == "s"

    def test_read_elementNum(self, tmp_path):
        ovf, _ = _vector_ovf(znodes=2, ynodes=3, xnodes=4, valuedim=3)
        path = str(tmp_path / "enum.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.elementNum == 2 * 3 * 4 * 3

    def test_read_nonexistent_raises(self):
        ovf = OVFFile()
        with pytest.raises((FileNotFoundError, OSError)):
            ovf.read("/nonexistent/_pyovf_test_file_that_should_not_exist.ovf")


# ---------------------------------------------------------------------------
# Roundtrip — data integrity
# ---------------------------------------------------------------------------

class TestRoundtrip:

    def test_vector_field_data_exact(self, tmp_path):
        ovf, data = _vector_ovf(znodes=2, ynodes=10, xnodes=20)
        path = str(tmp_path / "vec.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.data.shape == data.shape
        np.testing.assert_array_equal(ovf2.data, data)

    def test_scalar_field_data_exact(self, tmp_path):
        ovf, data = _scalar_ovf(znodes=1, ynodes=30, xnodes=40)
        path = str(tmp_path / "scalar.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.data.shape == data.shape
        np.testing.assert_array_equal(ovf2.data, data)

    def test_metadata_preserved(self, tmp_path):
        ovf, _ = _vector_ovf(title="magnetization", xstep=7e-9, ystep=8e-9, zstep=12e-9)
        path = str(tmp_path / "meta.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.Title == "magnetization"
        assert ovf2.xstepsize == pytest.approx(7e-9)
        assert ovf2.ystepsize == pytest.approx(8e-9)
        assert ovf2.zstepsize == pytest.approx(12e-9)

    def test_single_cell_vector(self, tmp_path):
        data = np.array([[[[0.1, 0.2, 0.9]]]], dtype=np.float32)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "single.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        np.testing.assert_array_equal(ovf2.data, data)

    def test_single_cell_scalar(self, tmp_path):
        data = np.array([[[3.14]]], dtype=np.float32)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "scalar"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "pi.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        np.testing.assert_array_equal(ovf2.data, data)

    def test_large_field(self, tmp_path):
        data = np.random.rand(10, 100, 100, 3).astype(np.float32)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "large.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.data.shape == data.shape
        np.testing.assert_array_equal(ovf2.data, data)

    def test_float64_input_converted(self, tmp_path):
        data64 = np.random.rand(1, 5, 5, 3)  # float64
        ovf = OVFFile()
        ovf.data = data64
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "f64.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        np.testing.assert_array_almost_equal(
            ovf2.data, data64.astype(np.float32), decimal=5
        )

    def test_data_dtype_is_float32_after_read(self, tmp_path):
        ovf, _ = _vector_ovf()
        path = str(tmp_path / "dtype.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        assert ovf2.data.dtype == np.float32

    def test_vector3_known_values(self, tmp_path):
        data = np.array([[[[1.0, 0.0, 0.0],
                           [0.0, 1.0, 0.0]],
                          [[0.0, 0.0, 1.0],
                           [0.5, 0.5, 0.0]]]], dtype=np.float32)
        ovf = OVFFile()
        ovf.data = data
        ovf.Title = "m"
        ovf.meshtype = "rectangular"
        ovf.meshunit = "m"
        path = str(tmp_path / "known.ovf")
        ovf.write(path)
        ovf2 = OVFFile()
        ovf2.read(path)
        np.testing.assert_array_equal(ovf2.data, data)


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrors:

    def _write_header_only(self, path, data_format_line, nodes=(1, 1, 1), valuedim=3):
        """Write a minimal OVF file with a custom data section start line."""
        z, y, x = nodes
        with open(path, "wb") as f:
            for line in [
                "# OOMMF OVF 2.0",
                "# Segment count: 1",
                "# Begin: Segment",
                "# Begin: Header",
                "# Title: t",
                "# meshtype: rectangular",
                "# meshunit: m",
                "# xmin: 0", "# ymin: 0", "# zmin: 0",
                "# xmax: 1", "# ymax: 1", "# zmax: 1",
                f"# valuedim: {valuedim}",
                f"# xnodes: {x}",
                f"# ynodes: {y}",
                f"# znodes: {z}",
                "# xstepsize: 1e-9",
                "# ystepsize: 1e-9",
                "# zstepsize: 1e-9",
                "# End: Header",
                data_format_line,
            ]:
                f.write((line + "\n").encode("ascii"))

    def test_text_format_raises_valueerror(self, tmp_path):
        path = str(tmp_path / "text.ovf")
        self._write_header_only(path, "# Begin: Data Text")
        ovf = OVFFile()
        with pytest.raises(ValueError, match="Text format"):
            ovf.read(path)

    def test_binary8_format_raises_valueerror(self, tmp_path):
        path = str(tmp_path / "bin8.ovf")
        self._write_header_only(path, "# Begin: Data Binary 8")
        ovf = OVFFile()
        with pytest.raises(ValueError, match="Binary 8"):
            ovf.read(path)

    def test_truncated_file_raises(self, tmp_path):
        ovf, _ = _vector_ovf(znodes=1, ynodes=10, xnodes=10)
        path = str(tmp_path / "trunc.ovf")
        ovf.write(path)
        size = os.path.getsize(path)
        with open(path, "r+b") as f:
            f.truncate(size // 2)
        ovf2 = OVFFile()
        with pytest.raises((ValueError, Exception)):
            ovf2.read(path)

    def test_write_no_data_raises(self):
        ovf = OVFFile()
        with pytest.raises(ValueError):
            ovf.write("/tmp/_pyovf_no_data_should_not_exist.ovf")


# ---------------------------------------------------------------------------
# file_exists utility
# ---------------------------------------------------------------------------

class TestFileExists:

    def test_existing_file(self, tmp_path):
        p = tmp_path / "x.txt"
        p.write_text("ok")
        assert file_exists(str(p)) is True

    def test_missing_file(self, tmp_path):
        assert file_exists(str(tmp_path / "nope.txt")) is False

    def test_directory_not_a_file(self, tmp_path):
        assert file_exists(str(tmp_path)) is False


# ---------------------------------------------------------------------------
# Integration: ovf_handler using pure Python backend
# Patches OVF_File_py and _HAS_CPP so the handler runs the fallback path
# without requiring the C++ extension to be absent.
# ---------------------------------------------------------------------------

class TestHandlerWithPurePythonBackend:
    """
    Verify that pyovf.ovf_handler (the high-level API) works correctly when
    OVF_File_py is replaced with _ovf_pure_python at runtime.
    """

    @pytest.fixture(autouse=True)
    def _import_handler(self):
        import pyovf.ovf_handler as handler
        import pyovf._ovf_pure_python as pp
        self._handler = handler
        self._pp = pp

    def _patch(self):
        return (
            patch.object(self._handler, "OVF_File_py", self._pp),
            patch.object(self._handler, "_HAS_CPP", False),
        )

    def test_has_cpp_extension_returns_false(self):
        with patch.object(self._handler, "_HAS_CPP", False):
            assert self._handler.has_cpp_extension() is False

    def test_vector_roundtrip(self, tmp_path):
        data = np.random.rand(1, 8, 8, 3).astype(np.float32)
        p1, p2 = self._patch()
        with p1, p2:
            ovf = self._handler.create(data, title="m")
            path = str(tmp_path / "handler_vec.ovf")
            self._handler.write(path, ovf)
            ovf2 = self._handler.read(path)
        np.testing.assert_array_almost_equal(ovf2.data, data, decimal=5)
        assert ovf2.Title == "m"

    def test_scalar_roundtrip(self, tmp_path):
        data = np.random.rand(1, 12, 12).astype(np.float32)
        p1, p2 = self._patch()
        with p1, p2:
            ovf = self._handler.create(data, title="scalar")
            path = str(tmp_path / "handler_sc.ovf")
            self._handler.write(path, ovf)
            ovf2 = self._handler.read(path)
        assert ovf2.valuedim == 1
        np.testing.assert_array_almost_equal(ovf2.data, data, decimal=5)

    def test_read_data_only(self, tmp_path):
        data = np.random.rand(1, 5, 7, 3).astype(np.float32)
        p1, p2 = self._patch()
        with p1, p2:
            ovf = self._handler.create(data, title="m")
            path = str(tmp_path / "data_only.ovf")
            self._handler.write(path, ovf)
            arr = self._handler.read_data_only(path)
        np.testing.assert_array_almost_equal(arr, data.squeeze(), decimal=5)

    def test_step_sizes_preserved(self, tmp_path):
        data = np.random.rand(1, 6, 6, 3).astype(np.float32)
        p1, p2 = self._patch()
        with p1, p2:
            ovf = self._handler.create(
                data, xstepsize=3e-9, ystepsize=4e-9, zstepsize=5e-9
            )
            path = str(tmp_path / "steps.ovf")
            self._handler.write(path, ovf)
            ovf2 = self._handler.read(path)
        assert ovf2.xstepsize == pytest.approx(3e-9)
        assert ovf2.ystepsize == pytest.approx(4e-9)
        assert ovf2.zstepsize == pytest.approx(5e-9)

    def test_write_raw_array(self, tmp_path):
        """write() also accepts a raw numpy array (legacy path)."""
        data = np.random.rand(1, 5, 5, 3).astype(np.float32)
        p1, p2 = self._patch()
        with p1, p2:
            path = str(tmp_path / "raw.ovf")
            self._handler.write(
                path, data, Xlim=[0, 1e-7], Ylim=[0, 1e-7], Zlim=[0, 1e-8]
            )
            ovf2 = self._handler.read(path)
        np.testing.assert_array_almost_equal(ovf2.data, data, decimal=5)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
