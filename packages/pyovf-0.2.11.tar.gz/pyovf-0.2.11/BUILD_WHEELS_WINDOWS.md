# Building Windows Wheels for PyPI Deployment

This guide explains how to build Windows wheels for pyovf and deploy them to PyPI.

## Prerequisites

✅ **Already Installed:**
- Visual Studio Build Tools 2022 with C++ compiler
- Python 3.13 (you may need additional Python versions)
- Git
- Virtual environment support

## Step 1: Install Multiple Python Versions

For a complete PyPI release, you should build wheels for Python 3.9-3.13 (minimum).

### Download Python Versions

Download from https://www.python.org/downloads/windows/:
- Python 3.9.x (64-bit)
- Python 3.10.x (64-bit)
- Python 3.11.x (64-bit)
- Python 3.12.x (64-bit)
- Python 3.13.x (64-bit) ✓ Already installed

**Important:** During installation:
- ✓ Check "Add Python to PATH" (or note installation location)
- ✓ Check "Install for all users" (installs to `C:\Program Files\Python3X`)
- Or check "Customize installation" to specify location

### Verify Python Installations

```powershell
# Check installed Python versions
py -0  # Lists all Python versions

# Or check specific versions
py -3.9 --version
py -3.10 --version
py -3.11 --version
py -3.12 --version
py -3.13 --version
```

## Step 2: Create a Production Version Tag

Remove the `.dev` suffix to create a production version:

```bash
# Check current version
git describe --tags

# Create a production tag (example: v0.2.11)
git tag -a v0.2.11 -m "Release v0.2.11"

# Push the tag to GitLab
git push origin v0.2.11
```

**Version Format:**
- Production: `v0.2.11`, `v1.0.0`, `v2.1.3`
- Development: `v0.2.11.dev1`, `v0.3.0.dev5` (not for PyPI production)

## Step 3: Build Windows Wheels

### Option A: Build Script (Recommended)

Create `build_wheels_windows.ps1`:

```powershell
# Build wheels for Windows - all Python versions
# Run this in PowerShell from the pyovf directory

$ErrorActionPreference = "Stop"

# Clean previous builds
Write-Host "Cleaning previous builds..." -ForegroundColor Yellow
Remove-Item -Path "dist\*" -Force -ErrorAction SilentlyContinue
Remove-Item -Path "build" -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path "*.egg-info" -Recurse -Force -ErrorAction SilentlyContinue

# Python versions to build for
$pythonVersions = @("3.9", "3.10", "3.11", "3.12", "3.13")

Write-Host "`n=== Building Windows Wheels ===" -ForegroundColor Green
Write-Host ""

foreach ($pyver in $pythonVersions) {
    Write-Host "Building for Python $pyver..." -ForegroundColor Cyan
    
    # Try to find Python
    $pyexe = $null
    try {
        # Try py launcher first
        $pyexe = "py -$pyver"
        & py -$pyver --version 2>&1 | Out-Null
        if ($LASTEXITCODE -ne 0) { $pyexe = $null }
    } catch {
        $pyexe = $null
    }
    
    if (-not $pyexe) {
        Write-Host "  ⚠ Python $pyver not found, skipping..." -ForegroundColor Yellow
        continue
    }
    
    # Install build dependencies
    Write-Host "  → Installing build dependencies..."
    & py -$pyver -m pip install --quiet --upgrade pip setuptools wheel build
    
    # Build wheel
    Write-Host "  → Building wheel..."
    & py -$pyver -m build --wheel
    
    if ($LASTEXITCODE -eq 0) {
        Write-Host "  ✓ Wheel built successfully for Python $pyver" -ForegroundColor Green
    } else {
        Write-Host "  ✗ Failed to build wheel for Python $pyver" -ForegroundColor Red
    }
    
    Write-Host ""
}

# Build source distribution (sdist) with any Python
Write-Host "Building source distribution..." -ForegroundColor Cyan
& py -3.13 -m build --sdist
Write-Host ""

# List built wheels
Write-Host "=== Built Wheels ===" -ForegroundColor Green
Get-ChildItem dist\*.whl | ForEach-Object {
    Write-Host "  ✓ $($_.Name)" -ForegroundColor Green
}
Get-ChildItem dist\*.tar.gz | ForEach-Object {
    Write-Host "  ✓ $($_.Name) (source)" -ForegroundColor Green
}

Write-Host "`n✓ Build complete!" -ForegroundColor Green
Write-Host "Wheels are in: dist\" -ForegroundColor Cyan
```

Run the script:

```powershell
.\build_wheels_windows.ps1
```

### Option B: Manual Build (Each Version)

```powershell
# Clean previous builds
Remove-Item -Path dist, build, *.egg-info -Recurse -Force -ErrorAction SilentlyContinue

# Build for Python 3.9
py -3.9 -m pip install --upgrade pip setuptools wheel build
py -3.9 -m build --wheel

# Build for Python 3.10
py -3.10 -m pip install --upgrade pip setuptools wheel build
py -3.10 -m build --wheel

# Build for Python 3.11
py -3.11 -m pip install --upgrade pip setuptools wheel build
py -3.11 -m build --wheel

# Build for Python 3.12
py -3.12 -m pip install --upgrade pip setuptools wheel build
py -3.12 -m build --wheel

# Build for Python 3.13
py -3.13 -m pip install --upgrade pip setuptools wheel build
py -3.13 -m build --wheel

# Build source distribution
py -3.13 -m build --sdist
```

## Step 4: Verify Built Wheels

```powershell
# List all wheels
Get-ChildItem dist\*.whl

# Expected output:
# pyovf-0.2.11-cp39-cp39-win_amd64.whl
# pyovf-0.2.11-cp310-cp310-win_amd64.whl
# pyovf-0.2.11-cp311-cp311-win_amd64.whl
# pyovf-0.2.11-cp312-cp312-win_amd64.whl
# pyovf-0.2.11-cp313-cp313-win_amd64.whl
# pyovf-0.2.11.tar.gz

# Test installation
py -3.13 -m venv test_venv
.\test_venv\Scripts\Activate.ps1
pip install dist\pyovf-0.2.11-cp313-cp313-win_amd64.whl
python -c "import pyovf; print(pyovf.__version__)"
deactivate
Remove-Item test_venv -Recurse -Force
```

## Step 5: Upload to PyPI

### Install twine

```powershell
pip install --upgrade twine
```

### Set PyPI Token

**Option 1: Environment Variable**

```powershell
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = "pypi-AgEIcHlwaS5vcmc..."  # Your PyPI API token
```

**Option 2: Create ~/.pypirc**

Create `C:\Users\<YourUsername>\.pypirc`:

```ini
[distutils]
index-servers = pypi

[pypi]
username = __token__
password = pypi-AgEIcHlwaS5vcmc...
```

### Upload Wheels

```powershell
# Test upload to TestPyPI first (recommended)
twine upload --repository testpypi dist/*

# Production upload to PyPI
twine upload dist/*
```

### Upload Only New Files

```powershell
# Skip files that already exist on PyPI
twine upload --skip-existing dist/*
```

## Step 6: Verify PyPI Release

1. Check PyPI page: https://pypi.org/project/pyovf/
2. Test installation:

```powershell
# Create fresh virtual environment
py -3.13 -m venv test_pypi
.\test_pypi\Scripts\Activate.ps1

# Install from PyPI
pip install pyovf

# Test import
python -c "import pyovf; print(pyovf.__version__)"

deactivate
Remove-Item test_pypi -Recurse -Force
```

## Complete Workflow Script

Save as `deploy_windows.ps1`:

```powershell
# Complete Windows deployment workflow
param(
    [string]$PyPIToken = $env:PYPI_TOKEN
)

$ErrorActionPreference = "Stop"

Write-Host "`n=== PyOVF Windows Deployment Workflow ===" -ForegroundColor Blue

# Step 1: Validate production tag
Write-Host "`nStep 1: Validating production tag..." -ForegroundColor Green
$tag = git describe --tags --exact-match 2>$null
if (-not $tag) {
    Write-Host "Error: No git tag on current commit" -ForegroundColor Red
    Write-Host "Create a tag first: git tag v0.x.y && git push origin v0.x.y"
    exit 1
}
if ($tag -match "\.dev\d+") {
    Write-Host "Error: Development tag detected: $tag" -ForegroundColor Red
    Write-Host "Only production tags are allowed (e.g., v0.2.11)"
    exit 1
}
Write-Host "✓ Production tag validated: $tag" -ForegroundColor Green

# Step 2: Build wheels
Write-Host "`nStep 2: Building wheels..." -ForegroundColor Green
.\build_wheels_windows.ps1

# Step 3: Test wheels
Write-Host "`nStep 3: Testing wheels..." -ForegroundColor Green
py -3.13 -m venv test_venv
.\test_venv\Scripts\Activate.ps1
pip install --quiet dist\pyovf-*cp313*.whl
python -c "import pyovf; print('✓ Import successful:', pyovf.__version__)"
deactivate
Remove-Item test_venv -Recurse -Force

# Step 4: Upload to PyPI
Write-Host "`nStep 4: Uploading to PyPI..." -ForegroundColor Green
if (-not $PyPIToken) {
    Write-Host "Error: PYPI_TOKEN not set" -ForegroundColor Red
    Write-Host "Set token: `$env:PYPI_TOKEN = 'pypi-AgEI...'"
    exit 1
}
$env:TWINE_USERNAME = "__token__"
$env:TWINE_PASSWORD = $PyPIToken
$env:KEYRING_PROVIDER = "fail"
twine upload --skip-existing dist/*

Write-Host "`n✓ Deployment complete!" -ForegroundColor Green
Write-Host "Check: https://pypi.org/project/pyovf/" -ForegroundColor Cyan
```

Run:

```powershell
$env:PYPI_TOKEN = "pypi-AgEI..."
.\deploy_windows.ps1
```

## Troubleshooting

### Python Version Not Found

```powershell
# List installed Python versions
py -0

# Install missing versions from python.org
```

### Build Failures

```powershell
# Ensure Build Tools are installed
.\install_build_tools.ps1

# Check CMake is available
cmake --version

# Verbose build to see errors
py -3.13 -m build --wheel --verbose
```

### Upload Errors

```powershell
# Check PyPI token is valid
twine upload --verbose dist/*

# Test with TestPyPI first
twine upload --repository testpypi dist/*
```

## CI/CD Alternative

For automated builds, GitLab CI/CD will build Linux wheels. You only need Windows wheels if:
- Users specifically request Windows pre-built wheels
- You want to avoid users building from source on Windows

Linux users get manylinux wheels from GitLab CI.
Windows users can either:
- Use pre-built wheels (if you build them)
- Build from source (works with your automated Build Tools installer)
