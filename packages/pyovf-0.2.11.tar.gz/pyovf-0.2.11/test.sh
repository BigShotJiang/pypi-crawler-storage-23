#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PYTHON_BIN="python3.9"

# "${PYTHON_BIN}" -m pip list | grep pyovf

"${PYTHON_BIN}" -m pip install --upgrade --force-reinstall pyovf
# "${PYTHON_BIN}" -m pip install pyovf==0.2.8

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "${TMP_DIR}"' EXIT

cp "${SCRIPT_DIR}/test.py" "${TMP_DIR}/test.py"

(cd "${TMP_DIR}" && "${PYTHON_BIN}" test.py)

"${PYTHON_BIN}" -m pip uninstall -y pyovf
