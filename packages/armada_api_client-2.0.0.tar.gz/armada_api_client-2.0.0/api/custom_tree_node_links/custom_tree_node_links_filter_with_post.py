from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.custom_tree_node_link import CustomTreeNodeLink
from ...models.problem_details import ProblemDetails
from ...models.query_custom_tree_node_link import QueryCustomTreeNodeLink
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: QueryCustomTreeNodeLink | QueryCustomTreeNodeLink | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/CustomTreeNodeLinks/List",
    }

    if isinstance(body, QueryCustomTreeNodeLink):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, QueryCustomTreeNodeLink):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[CustomTreeNodeLink] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = CustomTreeNodeLink.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[CustomTreeNodeLink]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryCustomTreeNodeLink | QueryCustomTreeNodeLink | Unset = UNSET,
) -> Response[ProblemDetails | list[CustomTreeNodeLink]]:
    """Get list of custom tree node link matching filter (Auth policies: LocationRead)

     Get list of custom tree node link matching filter. Optionnal fields can be requested in the response
    by using fields query parameters

    Args:
        body (QueryCustomTreeNodeLink | Unset):
        body (QueryCustomTreeNodeLink | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[CustomTreeNodeLink]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QueryCustomTreeNodeLink | QueryCustomTreeNodeLink | Unset = UNSET,
) -> ProblemDetails | list[CustomTreeNodeLink] | None:
    """Get list of custom tree node link matching filter (Auth policies: LocationRead)

     Get list of custom tree node link matching filter. Optionnal fields can be requested in the response
    by using fields query parameters

    Args:
        body (QueryCustomTreeNodeLink | Unset):
        body (QueryCustomTreeNodeLink | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[CustomTreeNodeLink]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryCustomTreeNodeLink | QueryCustomTreeNodeLink | Unset = UNSET,
) -> Response[ProblemDetails | list[CustomTreeNodeLink]]:
    """Get list of custom tree node link matching filter (Auth policies: LocationRead)

     Get list of custom tree node link matching filter. Optionnal fields can be requested in the response
    by using fields query parameters

    Args:
        body (QueryCustomTreeNodeLink | Unset):
        body (QueryCustomTreeNodeLink | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[CustomTreeNodeLink]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QueryCustomTreeNodeLink | QueryCustomTreeNodeLink | Unset = UNSET,
) -> ProblemDetails | list[CustomTreeNodeLink] | None:
    """Get list of custom tree node link matching filter (Auth policies: LocationRead)

     Get list of custom tree node link matching filter. Optionnal fields can be requested in the response
    by using fields query parameters

    Args:
        body (QueryCustomTreeNodeLink | Unset):
        body (QueryCustomTreeNodeLink | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[CustomTreeNodeLink]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
