from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equ_type_group_sub_group_name import EquTypeGroupSubGroupName
from ...models.problem_details import ProblemDetails
from ...models.query_description_element import QueryDescriptionElement
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: QueryDescriptionElement | QueryDescriptionElement | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/DescriptionElements/DistinctEquTypeGroupSubGroupName",
    }

    if isinstance(body, QueryDescriptionElement):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, QueryDescriptionElement):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[EquTypeGroupSubGroupName] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = EquTypeGroupSubGroupName.from_dict(
                response_200_item_data
            )

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[EquTypeGroupSubGroupName]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryDescriptionElement | QueryDescriptionElement | Unset = UNSET,
) -> Response[ProblemDetails | list[EquTypeGroupSubGroupName]]:
    """Get distinct description types (Auth policies: ElementRead)

     Retrieves all distinct description types (equipment type, group, subgroup, name) using POST with
    query in body.

    Args:
        body (QueryDescriptionElement | Unset):
        body (QueryDescriptionElement | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[EquTypeGroupSubGroupName]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QueryDescriptionElement | QueryDescriptionElement | Unset = UNSET,
) -> ProblemDetails | list[EquTypeGroupSubGroupName] | None:
    """Get distinct description types (Auth policies: ElementRead)

     Retrieves all distinct description types (equipment type, group, subgroup, name) using POST with
    query in body.

    Args:
        body (QueryDescriptionElement | Unset):
        body (QueryDescriptionElement | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[EquTypeGroupSubGroupName]
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryDescriptionElement | QueryDescriptionElement | Unset = UNSET,
) -> Response[ProblemDetails | list[EquTypeGroupSubGroupName]]:
    """Get distinct description types (Auth policies: ElementRead)

     Retrieves all distinct description types (equipment type, group, subgroup, name) using POST with
    query in body.

    Args:
        body (QueryDescriptionElement | Unset):
        body (QueryDescriptionElement | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[EquTypeGroupSubGroupName]]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QueryDescriptionElement | QueryDescriptionElement | Unset = UNSET,
) -> ProblemDetails | list[EquTypeGroupSubGroupName] | None:
    """Get distinct description types (Auth policies: ElementRead)

     Retrieves all distinct description types (equipment type, group, subgroup, name) using POST with
    query in body.

    Args:
        body (QueryDescriptionElement | Unset):
        body (QueryDescriptionElement | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[EquTypeGroupSubGroupName]
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
