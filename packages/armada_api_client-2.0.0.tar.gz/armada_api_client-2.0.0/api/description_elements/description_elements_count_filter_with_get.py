import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.criteria_string import CriteriaString
from ...models.e_order import EOrder
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    value: str | Unset = UNSET,
    unit: str | Unset = UNSET,
    group: str | Unset = UNSET,
    sub_group: str | Unset = UNSET,
    name: str | Unset = UNSET,
    equ_id: list[int] | Unset = UNSET,
    equ_id_with_children: bool | Unset = UNSET,
    custom_tree_node_id: list[int] | Unset = UNSET,
    equ_type: str | Unset = UNSET,
    equ_status: str | Unset = UNSET,
    equ_path: str | Unset = UNSET,
    equ_path_rel: str | Unset = UNSET,
    equ_severity_type: str | Unset = UNSET,
    equ_severity_type_min: str | Unset = UNSET,
    equ_severity_level: int | Unset = UNSET,
    equ_refresh_date_time_gt: datetime.datetime | Unset = UNSET,
    equ_refresh_date_time_lt: datetime.datetime | Unset = UNSET,
    equ_has_schematic: bool | Unset = UNSET,
    equ_in_maintenance: bool | Unset = UNSET,
    equ_has_active_alarm_with_name: str | Unset = UNSET,
    equ_has_active_alarm_acknowledged: bool | Unset = UNSET,
    equ_loc_country: str | Unset = UNSET,
    equ_loc_region: str | Unset = UNSET,
    equ_loc_province: str | Unset = UNSET,
    equ_loc_city: str | Unset = UNSET,
    equ_loc_group_1: str | Unset = UNSET,
    equ_loc_group_2: str | Unset = UNSET,
    equ_loc_group_3: str | Unset = UNSET,
    equ_loc_group_4: str | Unset = UNSET,
    equ_loc_group_5: str | Unset = UNSET,
    equ_loc_name: str | Unset = UNSET,
    equ_loc_info: str | Unset = UNSET,
    equ_loc_type: int | Unset = UNSET,
    equ_criterias: list[CriteriaString] | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["value"] = value

    params["unit"] = unit

    params["group"] = group

    params["subGroup"] = sub_group

    params["name"] = name

    json_equ_id: list[int] | Unset = UNSET
    if not isinstance(equ_id, Unset):
        json_equ_id = equ_id

    params["equId"] = json_equ_id

    params["equIdWithChildren"] = equ_id_with_children

    json_custom_tree_node_id: list[int] | Unset = UNSET
    if not isinstance(custom_tree_node_id, Unset):
        json_custom_tree_node_id = custom_tree_node_id

    params["customTreeNodeId"] = json_custom_tree_node_id

    params["equType"] = equ_type

    params["equStatus"] = equ_status

    params["equPath"] = equ_path

    params["equPathRel"] = equ_path_rel

    params["equSeverityType"] = equ_severity_type

    params["equSeverityTypeMin"] = equ_severity_type_min

    params["equSeverityLevel"] = equ_severity_level

    json_equ_refresh_date_time_gt: str | Unset = UNSET
    if not isinstance(equ_refresh_date_time_gt, Unset):
        json_equ_refresh_date_time_gt = equ_refresh_date_time_gt.isoformat()
    params["equRefreshDateTimeGt"] = json_equ_refresh_date_time_gt

    json_equ_refresh_date_time_lt: str | Unset = UNSET
    if not isinstance(equ_refresh_date_time_lt, Unset):
        json_equ_refresh_date_time_lt = equ_refresh_date_time_lt.isoformat()
    params["equRefreshDateTimeLt"] = json_equ_refresh_date_time_lt

    params["equHasSchematic"] = equ_has_schematic

    params["equInMaintenance"] = equ_in_maintenance

    params["equHasActiveAlarmWithName"] = equ_has_active_alarm_with_name

    params["equHasActiveAlarmAcknowledged"] = equ_has_active_alarm_acknowledged

    params["equLocCountry"] = equ_loc_country

    params["equLocRegion"] = equ_loc_region

    params["equLocProvince"] = equ_loc_province

    params["equLocCity"] = equ_loc_city

    params["equLocGroup1"] = equ_loc_group_1

    params["equLocGroup2"] = equ_loc_group_2

    params["equLocGroup3"] = equ_loc_group_3

    params["equLocGroup4"] = equ_loc_group_4

    params["equLocGroup5"] = equ_loc_group_5

    params["equLocName"] = equ_loc_name

    params["equLocInfo"] = equ_loc_info

    params["equLocType"] = equ_loc_type

    json_equ_criterias: list[dict[str, Any]] | Unset = UNSET
    if not isinstance(equ_criterias, Unset):
        json_equ_criterias = []
        for equ_criterias_item_data in equ_criterias:
            equ_criterias_item = equ_criterias_item_data.to_dict()
            json_equ_criterias.append(equ_criterias_item)

    params["equCriterias"] = json_equ_criterias

    params["monConnectionStatus"] = mon_connection_status

    params["monType"] = mon_type

    params["monIpAddress"] = mon_ip_address

    json_monitoring_id: list[int] | Unset = UNSET
    if not isinstance(monitoring_id, Unset):
        json_monitoring_id = monitoring_id

    params["monitoringId"] = json_monitoring_id

    params["monStatus"] = mon_status

    params["locCountry"] = loc_country

    params["locRegion"] = loc_region

    params["locProvince"] = loc_province

    params["locCity"] = loc_city

    params["locGroup1"] = loc_group_1

    params["locGroup2"] = loc_group_2

    params["locGroup3"] = loc_group_3

    params["locGroup4"] = loc_group_4

    params["locGroup5"] = loc_group_5

    params["locName"] = loc_name

    params["locInfo"] = loc_info

    params["locType"] = loc_type

    params["qLoc"] = q_loc

    json_id: list[str] | Unset = UNSET
    if not isinstance(id, Unset):
        json_id = id

    params["id"] = json_id

    params["_start"] = field_start

    params["_end"] = field_end

    json_field_order: str | Unset = UNSET
    if not isinstance(field_order, Unset):
        json_field_order = field_order.value

    params["_order"] = json_field_order

    params["_sort"] = field_sort

    params["q"] = q

    json_gt_modified_date_time: str | Unset = UNSET
    if not isinstance(gt_modified_date_time, Unset):
        json_gt_modified_date_time = gt_modified_date_time.isoformat()
    params["gtModifiedDateTime"] = json_gt_modified_date_time

    json_lt_modified_date_time: str | Unset = UNSET
    if not isinstance(lt_modified_date_time, Unset):
        json_lt_modified_date_time = lt_modified_date_time.isoformat()
    params["ltModifiedDateTime"] = json_lt_modified_date_time

    json_gt_created_date_time: str | Unset = UNSET
    if not isinstance(gt_created_date_time, Unset):
        json_gt_created_date_time = gt_created_date_time.isoformat()
    params["gtCreatedDateTime"] = json_gt_created_date_time

    json_lt_created_date_time: str | Unset = UNSET
    if not isinstance(lt_created_date_time, Unset):
        json_lt_created_date_time = lt_created_date_time.isoformat()
    params["ltCreatedDateTime"] = json_lt_created_date_time

    json_fields: list[str] | Unset = UNSET
    if not isinstance(fields, Unset):
        json_fields = fields

    params["fields"] = json_fields

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/DescriptionElements/Count",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | int | None:
    if response.status_code == 200:
        response_200 = cast(int, response.json())
        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | int]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    value: str | Unset = UNSET,
    unit: str | Unset = UNSET,
    group: str | Unset = UNSET,
    sub_group: str | Unset = UNSET,
    name: str | Unset = UNSET,
    equ_id: list[int] | Unset = UNSET,
    equ_id_with_children: bool | Unset = UNSET,
    custom_tree_node_id: list[int] | Unset = UNSET,
    equ_type: str | Unset = UNSET,
    equ_status: str | Unset = UNSET,
    equ_path: str | Unset = UNSET,
    equ_path_rel: str | Unset = UNSET,
    equ_severity_type: str | Unset = UNSET,
    equ_severity_type_min: str | Unset = UNSET,
    equ_severity_level: int | Unset = UNSET,
    equ_refresh_date_time_gt: datetime.datetime | Unset = UNSET,
    equ_refresh_date_time_lt: datetime.datetime | Unset = UNSET,
    equ_has_schematic: bool | Unset = UNSET,
    equ_in_maintenance: bool | Unset = UNSET,
    equ_has_active_alarm_with_name: str | Unset = UNSET,
    equ_has_active_alarm_acknowledged: bool | Unset = UNSET,
    equ_loc_country: str | Unset = UNSET,
    equ_loc_region: str | Unset = UNSET,
    equ_loc_province: str | Unset = UNSET,
    equ_loc_city: str | Unset = UNSET,
    equ_loc_group_1: str | Unset = UNSET,
    equ_loc_group_2: str | Unset = UNSET,
    equ_loc_group_3: str | Unset = UNSET,
    equ_loc_group_4: str | Unset = UNSET,
    equ_loc_group_5: str | Unset = UNSET,
    equ_loc_name: str | Unset = UNSET,
    equ_loc_info: str | Unset = UNSET,
    equ_loc_type: int | Unset = UNSET,
    equ_criterias: list[CriteriaString] | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> Response[ProblemDetails | int]:
    """Get the count of description filtered by uri query (Auth policies: ElementRead)

    Args:
        value (str | Unset): Filter by description element value
        unit (str | Unset): Filter by description element unit
        group (str | Unset): Filter elements with that Group value
        sub_group (str | Unset): Filter elements with that SubGroup value
        name (str | Unset): Filter elements with that Name value
        equ_id (list[int] | Unset): Filter with a list of equipment ids (These Ids are
            autogenerated and visible in the frontend)
        equ_id_with_children (bool | Unset): If EquId filter is used, include the equipments that
            are sub-equipments (recursively)
        custom_tree_node_id (list[int] | Unset): Specific filter for the custom tree Armada
            Windows Client
        equ_type (str | Unset): Filter equipments of a certain type (site, energy_system,
            dc_system, inverter, rectifier, energy_meter, etc.)
        equ_status (str | Unset): Filter equipments with a certain status (alarms,absent,etc.)
        equ_path (str | Unset): Filter by exact equipment path inside of each site
        equ_path_rel (str | Unset): Filter by relative equipment path inside of each site
        equ_severity_type (str | Unset): Filter by exact equipment alarm type
            (none,warning,minor,major,critical)
        equ_severity_type_min (str | Unset): Filter by minimal equipment alarm type
            (warning,minor,major,critical)
        equ_severity_level (int | Unset): Filter by exact equipment alarm level
        equ_refresh_date_time_gt (datetime.datetime | Unset): Filter equipments refreshed after
            this datetime (ISO-8601 format)
        equ_refresh_date_time_lt (datetime.datetime | Unset): Filter equipments refreshed before
            this datetime (ISO-8601 format)
        equ_has_schematic (bool | Unset): Filter equipments that have a schematic diagram
        equ_in_maintenance (bool | Unset): Filter equipments that are declared in maintenance
        equ_has_active_alarm_with_name (str | Unset): Filter equipments that have an active alarm
            with this name
        equ_has_active_alarm_acknowledged (bool | Unset): Filter by active alarm acknowledgement
            status
        equ_loc_country (str | Unset): Filter equipments located in this country
        equ_loc_region (str | Unset): Filter equipments located in this region
        equ_loc_province (str | Unset): Filter equipments located in this province
        equ_loc_city (str | Unset): Filter equipments located in this city
        equ_loc_group_1 (str | Unset): Filter equipments that are part of this site Group 1
        equ_loc_group_2 (str | Unset): Filter equipments that are part of this site Group 2
        equ_loc_group_3 (str | Unset): Filter equipments that are part of this site Group 3
        equ_loc_group_4 (str | Unset): Filter equipments that are part of this site Group 4
        equ_loc_group_5 (str | Unset): Filter equipments that are part of this site Group 5
        equ_loc_name (str | Unset): Filter equipments that are part of this site Name
        equ_loc_info (str | Unset): Filter equipments that are part of this site Info
        equ_loc_type (int | Unset): Filter by location type, only relevant for remote power
            feeding
        equ_criterias (list[CriteriaString] | Unset): Legacy filter criteria's, used by Armada
            Windows Client
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        value=value,
        unit=unit,
        group=group,
        sub_group=sub_group,
        name=name,
        equ_id=equ_id,
        equ_id_with_children=equ_id_with_children,
        custom_tree_node_id=custom_tree_node_id,
        equ_type=equ_type,
        equ_status=equ_status,
        equ_path=equ_path,
        equ_path_rel=equ_path_rel,
        equ_severity_type=equ_severity_type,
        equ_severity_type_min=equ_severity_type_min,
        equ_severity_level=equ_severity_level,
        equ_refresh_date_time_gt=equ_refresh_date_time_gt,
        equ_refresh_date_time_lt=equ_refresh_date_time_lt,
        equ_has_schematic=equ_has_schematic,
        equ_in_maintenance=equ_in_maintenance,
        equ_has_active_alarm_with_name=equ_has_active_alarm_with_name,
        equ_has_active_alarm_acknowledged=equ_has_active_alarm_acknowledged,
        equ_loc_country=equ_loc_country,
        equ_loc_region=equ_loc_region,
        equ_loc_province=equ_loc_province,
        equ_loc_city=equ_loc_city,
        equ_loc_group_1=equ_loc_group_1,
        equ_loc_group_2=equ_loc_group_2,
        equ_loc_group_3=equ_loc_group_3,
        equ_loc_group_4=equ_loc_group_4,
        equ_loc_group_5=equ_loc_group_5,
        equ_loc_name=equ_loc_name,
        equ_loc_info=equ_loc_info,
        equ_loc_type=equ_loc_type,
        equ_criterias=equ_criterias,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    value: str | Unset = UNSET,
    unit: str | Unset = UNSET,
    group: str | Unset = UNSET,
    sub_group: str | Unset = UNSET,
    name: str | Unset = UNSET,
    equ_id: list[int] | Unset = UNSET,
    equ_id_with_children: bool | Unset = UNSET,
    custom_tree_node_id: list[int] | Unset = UNSET,
    equ_type: str | Unset = UNSET,
    equ_status: str | Unset = UNSET,
    equ_path: str | Unset = UNSET,
    equ_path_rel: str | Unset = UNSET,
    equ_severity_type: str | Unset = UNSET,
    equ_severity_type_min: str | Unset = UNSET,
    equ_severity_level: int | Unset = UNSET,
    equ_refresh_date_time_gt: datetime.datetime | Unset = UNSET,
    equ_refresh_date_time_lt: datetime.datetime | Unset = UNSET,
    equ_has_schematic: bool | Unset = UNSET,
    equ_in_maintenance: bool | Unset = UNSET,
    equ_has_active_alarm_with_name: str | Unset = UNSET,
    equ_has_active_alarm_acknowledged: bool | Unset = UNSET,
    equ_loc_country: str | Unset = UNSET,
    equ_loc_region: str | Unset = UNSET,
    equ_loc_province: str | Unset = UNSET,
    equ_loc_city: str | Unset = UNSET,
    equ_loc_group_1: str | Unset = UNSET,
    equ_loc_group_2: str | Unset = UNSET,
    equ_loc_group_3: str | Unset = UNSET,
    equ_loc_group_4: str | Unset = UNSET,
    equ_loc_group_5: str | Unset = UNSET,
    equ_loc_name: str | Unset = UNSET,
    equ_loc_info: str | Unset = UNSET,
    equ_loc_type: int | Unset = UNSET,
    equ_criterias: list[CriteriaString] | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> ProblemDetails | int | None:
    """Get the count of description filtered by uri query (Auth policies: ElementRead)

    Args:
        value (str | Unset): Filter by description element value
        unit (str | Unset): Filter by description element unit
        group (str | Unset): Filter elements with that Group value
        sub_group (str | Unset): Filter elements with that SubGroup value
        name (str | Unset): Filter elements with that Name value
        equ_id (list[int] | Unset): Filter with a list of equipment ids (These Ids are
            autogenerated and visible in the frontend)
        equ_id_with_children (bool | Unset): If EquId filter is used, include the equipments that
            are sub-equipments (recursively)
        custom_tree_node_id (list[int] | Unset): Specific filter for the custom tree Armada
            Windows Client
        equ_type (str | Unset): Filter equipments of a certain type (site, energy_system,
            dc_system, inverter, rectifier, energy_meter, etc.)
        equ_status (str | Unset): Filter equipments with a certain status (alarms,absent,etc.)
        equ_path (str | Unset): Filter by exact equipment path inside of each site
        equ_path_rel (str | Unset): Filter by relative equipment path inside of each site
        equ_severity_type (str | Unset): Filter by exact equipment alarm type
            (none,warning,minor,major,critical)
        equ_severity_type_min (str | Unset): Filter by minimal equipment alarm type
            (warning,minor,major,critical)
        equ_severity_level (int | Unset): Filter by exact equipment alarm level
        equ_refresh_date_time_gt (datetime.datetime | Unset): Filter equipments refreshed after
            this datetime (ISO-8601 format)
        equ_refresh_date_time_lt (datetime.datetime | Unset): Filter equipments refreshed before
            this datetime (ISO-8601 format)
        equ_has_schematic (bool | Unset): Filter equipments that have a schematic diagram
        equ_in_maintenance (bool | Unset): Filter equipments that are declared in maintenance
        equ_has_active_alarm_with_name (str | Unset): Filter equipments that have an active alarm
            with this name
        equ_has_active_alarm_acknowledged (bool | Unset): Filter by active alarm acknowledgement
            status
        equ_loc_country (str | Unset): Filter equipments located in this country
        equ_loc_region (str | Unset): Filter equipments located in this region
        equ_loc_province (str | Unset): Filter equipments located in this province
        equ_loc_city (str | Unset): Filter equipments located in this city
        equ_loc_group_1 (str | Unset): Filter equipments that are part of this site Group 1
        equ_loc_group_2 (str | Unset): Filter equipments that are part of this site Group 2
        equ_loc_group_3 (str | Unset): Filter equipments that are part of this site Group 3
        equ_loc_group_4 (str | Unset): Filter equipments that are part of this site Group 4
        equ_loc_group_5 (str | Unset): Filter equipments that are part of this site Group 5
        equ_loc_name (str | Unset): Filter equipments that are part of this site Name
        equ_loc_info (str | Unset): Filter equipments that are part of this site Info
        equ_loc_type (int | Unset): Filter by location type, only relevant for remote power
            feeding
        equ_criterias (list[CriteriaString] | Unset): Legacy filter criteria's, used by Armada
            Windows Client
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return sync_detailed(
        client=client,
        value=value,
        unit=unit,
        group=group,
        sub_group=sub_group,
        name=name,
        equ_id=equ_id,
        equ_id_with_children=equ_id_with_children,
        custom_tree_node_id=custom_tree_node_id,
        equ_type=equ_type,
        equ_status=equ_status,
        equ_path=equ_path,
        equ_path_rel=equ_path_rel,
        equ_severity_type=equ_severity_type,
        equ_severity_type_min=equ_severity_type_min,
        equ_severity_level=equ_severity_level,
        equ_refresh_date_time_gt=equ_refresh_date_time_gt,
        equ_refresh_date_time_lt=equ_refresh_date_time_lt,
        equ_has_schematic=equ_has_schematic,
        equ_in_maintenance=equ_in_maintenance,
        equ_has_active_alarm_with_name=equ_has_active_alarm_with_name,
        equ_has_active_alarm_acknowledged=equ_has_active_alarm_acknowledged,
        equ_loc_country=equ_loc_country,
        equ_loc_region=equ_loc_region,
        equ_loc_province=equ_loc_province,
        equ_loc_city=equ_loc_city,
        equ_loc_group_1=equ_loc_group_1,
        equ_loc_group_2=equ_loc_group_2,
        equ_loc_group_3=equ_loc_group_3,
        equ_loc_group_4=equ_loc_group_4,
        equ_loc_group_5=equ_loc_group_5,
        equ_loc_name=equ_loc_name,
        equ_loc_info=equ_loc_info,
        equ_loc_type=equ_loc_type,
        equ_criterias=equ_criterias,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    value: str | Unset = UNSET,
    unit: str | Unset = UNSET,
    group: str | Unset = UNSET,
    sub_group: str | Unset = UNSET,
    name: str | Unset = UNSET,
    equ_id: list[int] | Unset = UNSET,
    equ_id_with_children: bool | Unset = UNSET,
    custom_tree_node_id: list[int] | Unset = UNSET,
    equ_type: str | Unset = UNSET,
    equ_status: str | Unset = UNSET,
    equ_path: str | Unset = UNSET,
    equ_path_rel: str | Unset = UNSET,
    equ_severity_type: str | Unset = UNSET,
    equ_severity_type_min: str | Unset = UNSET,
    equ_severity_level: int | Unset = UNSET,
    equ_refresh_date_time_gt: datetime.datetime | Unset = UNSET,
    equ_refresh_date_time_lt: datetime.datetime | Unset = UNSET,
    equ_has_schematic: bool | Unset = UNSET,
    equ_in_maintenance: bool | Unset = UNSET,
    equ_has_active_alarm_with_name: str | Unset = UNSET,
    equ_has_active_alarm_acknowledged: bool | Unset = UNSET,
    equ_loc_country: str | Unset = UNSET,
    equ_loc_region: str | Unset = UNSET,
    equ_loc_province: str | Unset = UNSET,
    equ_loc_city: str | Unset = UNSET,
    equ_loc_group_1: str | Unset = UNSET,
    equ_loc_group_2: str | Unset = UNSET,
    equ_loc_group_3: str | Unset = UNSET,
    equ_loc_group_4: str | Unset = UNSET,
    equ_loc_group_5: str | Unset = UNSET,
    equ_loc_name: str | Unset = UNSET,
    equ_loc_info: str | Unset = UNSET,
    equ_loc_type: int | Unset = UNSET,
    equ_criterias: list[CriteriaString] | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> Response[ProblemDetails | int]:
    """Get the count of description filtered by uri query (Auth policies: ElementRead)

    Args:
        value (str | Unset): Filter by description element value
        unit (str | Unset): Filter by description element unit
        group (str | Unset): Filter elements with that Group value
        sub_group (str | Unset): Filter elements with that SubGroup value
        name (str | Unset): Filter elements with that Name value
        equ_id (list[int] | Unset): Filter with a list of equipment ids (These Ids are
            autogenerated and visible in the frontend)
        equ_id_with_children (bool | Unset): If EquId filter is used, include the equipments that
            are sub-equipments (recursively)
        custom_tree_node_id (list[int] | Unset): Specific filter for the custom tree Armada
            Windows Client
        equ_type (str | Unset): Filter equipments of a certain type (site, energy_system,
            dc_system, inverter, rectifier, energy_meter, etc.)
        equ_status (str | Unset): Filter equipments with a certain status (alarms,absent,etc.)
        equ_path (str | Unset): Filter by exact equipment path inside of each site
        equ_path_rel (str | Unset): Filter by relative equipment path inside of each site
        equ_severity_type (str | Unset): Filter by exact equipment alarm type
            (none,warning,minor,major,critical)
        equ_severity_type_min (str | Unset): Filter by minimal equipment alarm type
            (warning,minor,major,critical)
        equ_severity_level (int | Unset): Filter by exact equipment alarm level
        equ_refresh_date_time_gt (datetime.datetime | Unset): Filter equipments refreshed after
            this datetime (ISO-8601 format)
        equ_refresh_date_time_lt (datetime.datetime | Unset): Filter equipments refreshed before
            this datetime (ISO-8601 format)
        equ_has_schematic (bool | Unset): Filter equipments that have a schematic diagram
        equ_in_maintenance (bool | Unset): Filter equipments that are declared in maintenance
        equ_has_active_alarm_with_name (str | Unset): Filter equipments that have an active alarm
            with this name
        equ_has_active_alarm_acknowledged (bool | Unset): Filter by active alarm acknowledgement
            status
        equ_loc_country (str | Unset): Filter equipments located in this country
        equ_loc_region (str | Unset): Filter equipments located in this region
        equ_loc_province (str | Unset): Filter equipments located in this province
        equ_loc_city (str | Unset): Filter equipments located in this city
        equ_loc_group_1 (str | Unset): Filter equipments that are part of this site Group 1
        equ_loc_group_2 (str | Unset): Filter equipments that are part of this site Group 2
        equ_loc_group_3 (str | Unset): Filter equipments that are part of this site Group 3
        equ_loc_group_4 (str | Unset): Filter equipments that are part of this site Group 4
        equ_loc_group_5 (str | Unset): Filter equipments that are part of this site Group 5
        equ_loc_name (str | Unset): Filter equipments that are part of this site Name
        equ_loc_info (str | Unset): Filter equipments that are part of this site Info
        equ_loc_type (int | Unset): Filter by location type, only relevant for remote power
            feeding
        equ_criterias (list[CriteriaString] | Unset): Legacy filter criteria's, used by Armada
            Windows Client
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        value=value,
        unit=unit,
        group=group,
        sub_group=sub_group,
        name=name,
        equ_id=equ_id,
        equ_id_with_children=equ_id_with_children,
        custom_tree_node_id=custom_tree_node_id,
        equ_type=equ_type,
        equ_status=equ_status,
        equ_path=equ_path,
        equ_path_rel=equ_path_rel,
        equ_severity_type=equ_severity_type,
        equ_severity_type_min=equ_severity_type_min,
        equ_severity_level=equ_severity_level,
        equ_refresh_date_time_gt=equ_refresh_date_time_gt,
        equ_refresh_date_time_lt=equ_refresh_date_time_lt,
        equ_has_schematic=equ_has_schematic,
        equ_in_maintenance=equ_in_maintenance,
        equ_has_active_alarm_with_name=equ_has_active_alarm_with_name,
        equ_has_active_alarm_acknowledged=equ_has_active_alarm_acknowledged,
        equ_loc_country=equ_loc_country,
        equ_loc_region=equ_loc_region,
        equ_loc_province=equ_loc_province,
        equ_loc_city=equ_loc_city,
        equ_loc_group_1=equ_loc_group_1,
        equ_loc_group_2=equ_loc_group_2,
        equ_loc_group_3=equ_loc_group_3,
        equ_loc_group_4=equ_loc_group_4,
        equ_loc_group_5=equ_loc_group_5,
        equ_loc_name=equ_loc_name,
        equ_loc_info=equ_loc_info,
        equ_loc_type=equ_loc_type,
        equ_criterias=equ_criterias,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    value: str | Unset = UNSET,
    unit: str | Unset = UNSET,
    group: str | Unset = UNSET,
    sub_group: str | Unset = UNSET,
    name: str | Unset = UNSET,
    equ_id: list[int] | Unset = UNSET,
    equ_id_with_children: bool | Unset = UNSET,
    custom_tree_node_id: list[int] | Unset = UNSET,
    equ_type: str | Unset = UNSET,
    equ_status: str | Unset = UNSET,
    equ_path: str | Unset = UNSET,
    equ_path_rel: str | Unset = UNSET,
    equ_severity_type: str | Unset = UNSET,
    equ_severity_type_min: str | Unset = UNSET,
    equ_severity_level: int | Unset = UNSET,
    equ_refresh_date_time_gt: datetime.datetime | Unset = UNSET,
    equ_refresh_date_time_lt: datetime.datetime | Unset = UNSET,
    equ_has_schematic: bool | Unset = UNSET,
    equ_in_maintenance: bool | Unset = UNSET,
    equ_has_active_alarm_with_name: str | Unset = UNSET,
    equ_has_active_alarm_acknowledged: bool | Unset = UNSET,
    equ_loc_country: str | Unset = UNSET,
    equ_loc_region: str | Unset = UNSET,
    equ_loc_province: str | Unset = UNSET,
    equ_loc_city: str | Unset = UNSET,
    equ_loc_group_1: str | Unset = UNSET,
    equ_loc_group_2: str | Unset = UNSET,
    equ_loc_group_3: str | Unset = UNSET,
    equ_loc_group_4: str | Unset = UNSET,
    equ_loc_group_5: str | Unset = UNSET,
    equ_loc_name: str | Unset = UNSET,
    equ_loc_info: str | Unset = UNSET,
    equ_loc_type: int | Unset = UNSET,
    equ_criterias: list[CriteriaString] | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> ProblemDetails | int | None:
    """Get the count of description filtered by uri query (Auth policies: ElementRead)

    Args:
        value (str | Unset): Filter by description element value
        unit (str | Unset): Filter by description element unit
        group (str | Unset): Filter elements with that Group value
        sub_group (str | Unset): Filter elements with that SubGroup value
        name (str | Unset): Filter elements with that Name value
        equ_id (list[int] | Unset): Filter with a list of equipment ids (These Ids are
            autogenerated and visible in the frontend)
        equ_id_with_children (bool | Unset): If EquId filter is used, include the equipments that
            are sub-equipments (recursively)
        custom_tree_node_id (list[int] | Unset): Specific filter for the custom tree Armada
            Windows Client
        equ_type (str | Unset): Filter equipments of a certain type (site, energy_system,
            dc_system, inverter, rectifier, energy_meter, etc.)
        equ_status (str | Unset): Filter equipments with a certain status (alarms,absent,etc.)
        equ_path (str | Unset): Filter by exact equipment path inside of each site
        equ_path_rel (str | Unset): Filter by relative equipment path inside of each site
        equ_severity_type (str | Unset): Filter by exact equipment alarm type
            (none,warning,minor,major,critical)
        equ_severity_type_min (str | Unset): Filter by minimal equipment alarm type
            (warning,minor,major,critical)
        equ_severity_level (int | Unset): Filter by exact equipment alarm level
        equ_refresh_date_time_gt (datetime.datetime | Unset): Filter equipments refreshed after
            this datetime (ISO-8601 format)
        equ_refresh_date_time_lt (datetime.datetime | Unset): Filter equipments refreshed before
            this datetime (ISO-8601 format)
        equ_has_schematic (bool | Unset): Filter equipments that have a schematic diagram
        equ_in_maintenance (bool | Unset): Filter equipments that are declared in maintenance
        equ_has_active_alarm_with_name (str | Unset): Filter equipments that have an active alarm
            with this name
        equ_has_active_alarm_acknowledged (bool | Unset): Filter by active alarm acknowledgement
            status
        equ_loc_country (str | Unset): Filter equipments located in this country
        equ_loc_region (str | Unset): Filter equipments located in this region
        equ_loc_province (str | Unset): Filter equipments located in this province
        equ_loc_city (str | Unset): Filter equipments located in this city
        equ_loc_group_1 (str | Unset): Filter equipments that are part of this site Group 1
        equ_loc_group_2 (str | Unset): Filter equipments that are part of this site Group 2
        equ_loc_group_3 (str | Unset): Filter equipments that are part of this site Group 3
        equ_loc_group_4 (str | Unset): Filter equipments that are part of this site Group 4
        equ_loc_group_5 (str | Unset): Filter equipments that are part of this site Group 5
        equ_loc_name (str | Unset): Filter equipments that are part of this site Name
        equ_loc_info (str | Unset): Filter equipments that are part of this site Info
        equ_loc_type (int | Unset): Filter by location type, only relevant for remote power
            feeding
        equ_criterias (list[CriteriaString] | Unset): Legacy filter criteria's, used by Armada
            Windows Client
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return (
        await asyncio_detailed(
            client=client,
            value=value,
            unit=unit,
            group=group,
            sub_group=sub_group,
            name=name,
            equ_id=equ_id,
            equ_id_with_children=equ_id_with_children,
            custom_tree_node_id=custom_tree_node_id,
            equ_type=equ_type,
            equ_status=equ_status,
            equ_path=equ_path,
            equ_path_rel=equ_path_rel,
            equ_severity_type=equ_severity_type,
            equ_severity_type_min=equ_severity_type_min,
            equ_severity_level=equ_severity_level,
            equ_refresh_date_time_gt=equ_refresh_date_time_gt,
            equ_refresh_date_time_lt=equ_refresh_date_time_lt,
            equ_has_schematic=equ_has_schematic,
            equ_in_maintenance=equ_in_maintenance,
            equ_has_active_alarm_with_name=equ_has_active_alarm_with_name,
            equ_has_active_alarm_acknowledged=equ_has_active_alarm_acknowledged,
            equ_loc_country=equ_loc_country,
            equ_loc_region=equ_loc_region,
            equ_loc_province=equ_loc_province,
            equ_loc_city=equ_loc_city,
            equ_loc_group_1=equ_loc_group_1,
            equ_loc_group_2=equ_loc_group_2,
            equ_loc_group_3=equ_loc_group_3,
            equ_loc_group_4=equ_loc_group_4,
            equ_loc_group_5=equ_loc_group_5,
            equ_loc_name=equ_loc_name,
            equ_loc_info=equ_loc_info,
            equ_loc_type=equ_loc_type,
            equ_criterias=equ_criterias,
            mon_connection_status=mon_connection_status,
            mon_type=mon_type,
            mon_ip_address=mon_ip_address,
            monitoring_id=monitoring_id,
            mon_status=mon_status,
            loc_country=loc_country,
            loc_region=loc_region,
            loc_province=loc_province,
            loc_city=loc_city,
            loc_group_1=loc_group_1,
            loc_group_2=loc_group_2,
            loc_group_3=loc_group_3,
            loc_group_4=loc_group_4,
            loc_group_5=loc_group_5,
            loc_name=loc_name,
            loc_info=loc_info,
            loc_type=loc_type,
            q_loc=q_loc,
            id=id,
            field_start=field_start,
            field_end=field_end,
            field_order=field_order,
            field_sort=field_sort,
            q=q,
            gt_modified_date_time=gt_modified_date_time,
            lt_modified_date_time=lt_modified_date_time,
            gt_created_date_time=gt_created_date_time,
            lt_created_date_time=lt_created_date_time,
            fields=fields,
        )
    ).parsed
