import datetime
from http import HTTPStatus
from io import BytesIO
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.e_aggregate import EAggregate
from ...models.problem_details import ProblemDetails
from ...types import UNSET, File, Response, Unset


def _get_kwargs(
    *,
    from_date_time: datetime.datetime | Unset = UNSET,
    to_date_time: datetime.datetime | Unset = UNSET,
    key: list[str] | Unset = UNSET,
    interval: str | Unset = UNSET,
    aggregate: list[EAggregate] | Unset = UNSET,
    create_empty: bool | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_from_date_time: str | Unset = UNSET
    if not isinstance(from_date_time, Unset):
        json_from_date_time = from_date_time.isoformat()
    params["fromDateTime"] = json_from_date_time

    json_to_date_time: str | Unset = UNSET
    if not isinstance(to_date_time, Unset):
        json_to_date_time = to_date_time.isoformat()
    params["toDateTime"] = json_to_date_time

    json_key: list[str] | Unset = UNSET
    if not isinstance(key, Unset):
        json_key = key

    params["key"] = json_key

    params["interval"] = interval

    json_aggregate: list[str] | Unset = UNSET
    if not isinstance(aggregate, Unset):
        json_aggregate = []
        for aggregate_item_data in aggregate:
            aggregate_item = aggregate_item_data.value
            json_aggregate.append(aggregate_item)

    params["aggregate"] = json_aggregate

    params["createEmpty"] = create_empty

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/TimeSeries/queryMulti/xlsx",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> File | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = File(payload=BytesIO(response.json()))

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[File | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_date_time: datetime.datetime | Unset = UNSET,
    to_date_time: datetime.datetime | Unset = UNSET,
    key: list[str] | Unset = UNSET,
    interval: str | Unset = UNSET,
    aggregate: list[EAggregate] | Unset = UNSET,
    create_empty: bool | Unset = UNSET,
) -> Response[File | ProblemDetails]:
    """Export multiple time series to Excel (Auth policies: ElementRead)

     Exports time series data for multiple metrics to an Excel (.xlsx) file.

    Args:
        from_date_time (datetime.datetime | Unset):
        to_date_time (datetime.datetime | Unset):
        key (list[str] | Unset):
        interval (str | Unset):
        aggregate (list[EAggregate] | Unset):
        create_empty (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[File | ProblemDetails]
    """

    kwargs = _get_kwargs(
        from_date_time=from_date_time,
        to_date_time=to_date_time,
        key=key,
        interval=interval,
        aggregate=aggregate,
        create_empty=create_empty,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    from_date_time: datetime.datetime | Unset = UNSET,
    to_date_time: datetime.datetime | Unset = UNSET,
    key: list[str] | Unset = UNSET,
    interval: str | Unset = UNSET,
    aggregate: list[EAggregate] | Unset = UNSET,
    create_empty: bool | Unset = UNSET,
) -> File | ProblemDetails | None:
    """Export multiple time series to Excel (Auth policies: ElementRead)

     Exports time series data for multiple metrics to an Excel (.xlsx) file.

    Args:
        from_date_time (datetime.datetime | Unset):
        to_date_time (datetime.datetime | Unset):
        key (list[str] | Unset):
        interval (str | Unset):
        aggregate (list[EAggregate] | Unset):
        create_empty (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        File | ProblemDetails
    """

    return sync_detailed(
        client=client,
        from_date_time=from_date_time,
        to_date_time=to_date_time,
        key=key,
        interval=interval,
        aggregate=aggregate,
        create_empty=create_empty,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_date_time: datetime.datetime | Unset = UNSET,
    to_date_time: datetime.datetime | Unset = UNSET,
    key: list[str] | Unset = UNSET,
    interval: str | Unset = UNSET,
    aggregate: list[EAggregate] | Unset = UNSET,
    create_empty: bool | Unset = UNSET,
) -> Response[File | ProblemDetails]:
    """Export multiple time series to Excel (Auth policies: ElementRead)

     Exports time series data for multiple metrics to an Excel (.xlsx) file.

    Args:
        from_date_time (datetime.datetime | Unset):
        to_date_time (datetime.datetime | Unset):
        key (list[str] | Unset):
        interval (str | Unset):
        aggregate (list[EAggregate] | Unset):
        create_empty (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[File | ProblemDetails]
    """

    kwargs = _get_kwargs(
        from_date_time=from_date_time,
        to_date_time=to_date_time,
        key=key,
        interval=interval,
        aggregate=aggregate,
        create_empty=create_empty,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    from_date_time: datetime.datetime | Unset = UNSET,
    to_date_time: datetime.datetime | Unset = UNSET,
    key: list[str] | Unset = UNSET,
    interval: str | Unset = UNSET,
    aggregate: list[EAggregate] | Unset = UNSET,
    create_empty: bool | Unset = UNSET,
) -> File | ProblemDetails | None:
    """Export multiple time series to Excel (Auth policies: ElementRead)

     Exports time series data for multiple metrics to an Excel (.xlsx) file.

    Args:
        from_date_time (datetime.datetime | Unset):
        to_date_time (datetime.datetime | Unset):
        key (list[str] | Unset):
        interval (str | Unset):
        aggregate (list[EAggregate] | Unset):
        create_empty (bool | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        File | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            from_date_time=from_date_time,
            to_date_time=to_date_time,
            key=key,
            interval=interval,
            aggregate=aggregate,
            create_empty=create_empty,
        )
    ).parsed
