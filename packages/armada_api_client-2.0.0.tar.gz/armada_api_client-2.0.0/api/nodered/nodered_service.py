from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.e_control_service import EControlService
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    wanted_state: EControlService | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_wanted_state: str | Unset = UNSET
    if not isinstance(wanted_state, Unset):
        json_wanted_state = wanted_state.value

    params["wantedState"] = json_wanted_state

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Nodered/ServiceControl",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | bool | None:
    if response.status_code == 200:
        response_200 = cast(bool, response.json())
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | bool]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    wanted_state: EControlService | Unset = UNSET,
) -> Response[ProblemDetails | bool]:
    """Control Node-RED service (Auth policies: NoderedAdmin)

     Starts, stops, or restarts the Node-RED service for the current tenant.

    Args:
        wanted_state (EControlService | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | bool]
    """

    kwargs = _get_kwargs(
        wanted_state=wanted_state,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    wanted_state: EControlService | Unset = UNSET,
) -> ProblemDetails | bool | None:
    """Control Node-RED service (Auth policies: NoderedAdmin)

     Starts, stops, or restarts the Node-RED service for the current tenant.

    Args:
        wanted_state (EControlService | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | bool
    """

    return sync_detailed(
        client=client,
        wanted_state=wanted_state,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    wanted_state: EControlService | Unset = UNSET,
) -> Response[ProblemDetails | bool]:
    """Control Node-RED service (Auth policies: NoderedAdmin)

     Starts, stops, or restarts the Node-RED service for the current tenant.

    Args:
        wanted_state (EControlService | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | bool]
    """

    kwargs = _get_kwargs(
        wanted_state=wanted_state,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    wanted_state: EControlService | Unset = UNSET,
) -> ProblemDetails | bool | None:
    """Control Node-RED service (Auth policies: NoderedAdmin)

     Starts, stops, or restarts the Node-RED service for the current tenant.

    Args:
        wanted_state (EControlService | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | bool
    """

    return (
        await asyncio_detailed(
            client=client,
            wanted_state=wanted_state,
        )
    ).parsed
