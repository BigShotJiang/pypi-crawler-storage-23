from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.site_location import SiteLocation
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: str,
    *,
    body: SiteLocation | SiteLocation | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/SiteLocations/{id}".format(
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, SiteLocation):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, SiteLocation):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | SiteLocation | None:
    if response.status_code == 200:
        response_200 = SiteLocation.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | SiteLocation]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SiteLocation | SiteLocation | Unset = UNSET,
) -> Response[ProblemDetails | SiteLocation]:
    """Modify site location (Auth policies: ElementRead, ElementWrite)

     Updates an existing site location information including address, GPS coordinates, and grouping.

    Args:
        id (str):
        body (SiteLocation | Unset):
        body (SiteLocation | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | SiteLocation]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SiteLocation | SiteLocation | Unset = UNSET,
) -> ProblemDetails | SiteLocation | None:
    """Modify site location (Auth policies: ElementRead, ElementWrite)

     Updates an existing site location information including address, GPS coordinates, and grouping.

    Args:
        id (str):
        body (SiteLocation | Unset):
        body (SiteLocation | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | SiteLocation
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SiteLocation | SiteLocation | Unset = UNSET,
) -> Response[ProblemDetails | SiteLocation]:
    """Modify site location (Auth policies: ElementRead, ElementWrite)

     Updates an existing site location information including address, GPS coordinates, and grouping.

    Args:
        id (str):
        body (SiteLocation | Unset):
        body (SiteLocation | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | SiteLocation]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: SiteLocation | SiteLocation | Unset = UNSET,
) -> ProblemDetails | SiteLocation | None:
    """Modify site location (Auth policies: ElementRead, ElementWrite)

     Updates an existing site location information including address, GPS coordinates, and grouping.

    Args:
        id (str):
        body (SiteLocation | Unset):
        body (SiteLocation | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | SiteLocation
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
