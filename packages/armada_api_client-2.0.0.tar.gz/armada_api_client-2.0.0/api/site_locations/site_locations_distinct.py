from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.id_value import IdValue
from ...models.problem_details import ProblemDetails
from ...types import Response


def _get_kwargs(
    field: str,
) -> dict[str, Any]:
    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/SiteLocations/Distinct/{field}".format(
            field=quote(str(field), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[IdValue] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = IdValue.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[IdValue]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    field: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ProblemDetails | list[IdValue]]:
    """Get distinct site location field values (Auth policies: ElementRead)

     Retrieves all distinct values for a specified field across all site locations (e.g., cities,
    countries, regions).

    Args:
        field (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[IdValue]]
    """

    kwargs = _get_kwargs(
        field=field,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    field: str,
    *,
    client: AuthenticatedClient | Client,
) -> ProblemDetails | list[IdValue] | None:
    """Get distinct site location field values (Auth policies: ElementRead)

     Retrieves all distinct values for a specified field across all site locations (e.g., cities,
    countries, regions).

    Args:
        field (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[IdValue]
    """

    return sync_detailed(
        field=field,
        client=client,
    ).parsed


async def asyncio_detailed(
    field: str,
    *,
    client: AuthenticatedClient | Client,
) -> Response[ProblemDetails | list[IdValue]]:
    """Get distinct site location field values (Auth policies: ElementRead)

     Retrieves all distinct values for a specified field across all site locations (e.g., cities,
    countries, regions).

    Args:
        field (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[IdValue]]
    """

    kwargs = _get_kwargs(
        field=field,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    field: str,
    *,
    client: AuthenticatedClient | Client,
) -> ProblemDetails | list[IdValue] | None:
    """Get distinct site location field values (Auth policies: ElementRead)

     Retrieves all distinct values for a specified field across all site locations (e.g., cities,
    countries, regions).

    Args:
        field (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[IdValue]
    """

    return (
        await asyncio_detailed(
            field=field,
            client=client,
        )
    ).parsed
