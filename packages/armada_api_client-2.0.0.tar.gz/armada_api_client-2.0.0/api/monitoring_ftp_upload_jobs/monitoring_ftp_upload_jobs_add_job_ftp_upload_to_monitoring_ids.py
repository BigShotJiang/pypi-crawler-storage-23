from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.query_monitoring import QueryMonitoring
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: QueryMonitoring | QueryMonitoring | Unset = UNSET,
    file_info_id: int,
    remote_directory: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["fileInfoId"] = file_info_id

    params["remoteDirectory"] = remote_directory

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/MonitoringFtpUploadJobs/CreateJobs",
        "params": params,
    }

    if isinstance(body, QueryMonitoring):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, QueryMonitoring):
        _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | int | None:
    if response.status_code == 200:
        response_200 = cast(int, response.json())
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | int]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryMonitoring | QueryMonitoring | Unset = UNSET,
    file_info_id: int,
    remote_directory: str,
) -> Response[ProblemDetails | int]:
    """Create FTP upload jobs (Auth policies: AdminRead, AdminWrite)

     Creates FTP upload jobs for specified monitoring devices to upload firmware or files to a remote
    directory.

    Args:
        file_info_id (int):
        remote_directory (str):
        body (QueryMonitoring):
        body (QueryMonitoring):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        body=body,
        file_info_id=file_info_id,
        remote_directory=remote_directory,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QueryMonitoring | QueryMonitoring | Unset = UNSET,
    file_info_id: int,
    remote_directory: str,
) -> ProblemDetails | int | None:
    """Create FTP upload jobs (Auth policies: AdminRead, AdminWrite)

     Creates FTP upload jobs for specified monitoring devices to upload firmware or files to a remote
    directory.

    Args:
        file_info_id (int):
        remote_directory (str):
        body (QueryMonitoring):
        body (QueryMonitoring):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return sync_detailed(
        client=client,
        body=body,
        file_info_id=file_info_id,
        remote_directory=remote_directory,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryMonitoring | QueryMonitoring | Unset = UNSET,
    file_info_id: int,
    remote_directory: str,
) -> Response[ProblemDetails | int]:
    """Create FTP upload jobs (Auth policies: AdminRead, AdminWrite)

     Creates FTP upload jobs for specified monitoring devices to upload firmware or files to a remote
    directory.

    Args:
        file_info_id (int):
        remote_directory (str):
        body (QueryMonitoring):
        body (QueryMonitoring):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        body=body,
        file_info_id=file_info_id,
        remote_directory=remote_directory,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QueryMonitoring | QueryMonitoring | Unset = UNSET,
    file_info_id: int,
    remote_directory: str,
) -> ProblemDetails | int | None:
    """Create FTP upload jobs (Auth policies: AdminRead, AdminWrite)

     Creates FTP upload jobs for specified monitoring devices to upload firmware or files to a remote
    directory.

    Args:
        file_info_id (int):
        remote_directory (str):
        body (QueryMonitoring):
        body (QueryMonitoring):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            file_info_id=file_info_id,
            remote_directory=remote_directory,
        )
    ).parsed
