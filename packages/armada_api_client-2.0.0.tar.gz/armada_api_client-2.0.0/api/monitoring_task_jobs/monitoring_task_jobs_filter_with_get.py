import datetime
from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.e_order import EOrder
from ...models.job_task import JobTask
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    status: str | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["status"] = status

    params["monConnectionStatus"] = mon_connection_status

    params["monType"] = mon_type

    params["monIpAddress"] = mon_ip_address

    json_monitoring_id: list[int] | Unset = UNSET
    if not isinstance(monitoring_id, Unset):
        json_monitoring_id = monitoring_id

    params["monitoringId"] = json_monitoring_id

    params["monStatus"] = mon_status

    params["locCountry"] = loc_country

    params["locRegion"] = loc_region

    params["locProvince"] = loc_province

    params["locCity"] = loc_city

    params["locGroup1"] = loc_group_1

    params["locGroup2"] = loc_group_2

    params["locGroup3"] = loc_group_3

    params["locGroup4"] = loc_group_4

    params["locGroup5"] = loc_group_5

    params["locName"] = loc_name

    params["locInfo"] = loc_info

    params["locType"] = loc_type

    params["qLoc"] = q_loc

    json_id: list[str] | Unset = UNSET
    if not isinstance(id, Unset):
        json_id = id

    params["id"] = json_id

    params["_start"] = field_start

    params["_end"] = field_end

    json_field_order: str | Unset = UNSET
    if not isinstance(field_order, Unset):
        json_field_order = field_order.value

    params["_order"] = json_field_order

    params["_sort"] = field_sort

    params["q"] = q

    json_gt_modified_date_time: str | Unset = UNSET
    if not isinstance(gt_modified_date_time, Unset):
        json_gt_modified_date_time = gt_modified_date_time.isoformat()
    params["gtModifiedDateTime"] = json_gt_modified_date_time

    json_lt_modified_date_time: str | Unset = UNSET
    if not isinstance(lt_modified_date_time, Unset):
        json_lt_modified_date_time = lt_modified_date_time.isoformat()
    params["ltModifiedDateTime"] = json_lt_modified_date_time

    json_gt_created_date_time: str | Unset = UNSET
    if not isinstance(gt_created_date_time, Unset):
        json_gt_created_date_time = gt_created_date_time.isoformat()
    params["gtCreatedDateTime"] = json_gt_created_date_time

    json_lt_created_date_time: str | Unset = UNSET
    if not isinstance(lt_created_date_time, Unset):
        json_lt_created_date_time = lt_created_date_time.isoformat()
    params["ltCreatedDateTime"] = json_lt_created_date_time

    json_fields: list[str] | Unset = UNSET
    if not isinstance(fields, Unset):
        json_fields = fields

    params["fields"] = json_fields

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/MonitoringTaskJobs",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[JobTask] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = JobTask.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[JobTask]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    status: str | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> Response[ProblemDetails | list[JobTask]]:
    """Get list of job task matching filter (Auth policies: AdminRead)

     Get list of job task matching filter. Optionnal fields can be requested in the response by using
    fields query parameters

    Args:
        status (str | Unset):
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[JobTask]]
    """

    kwargs = _get_kwargs(
        status=status,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    status: str | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> ProblemDetails | list[JobTask] | None:
    """Get list of job task matching filter (Auth policies: AdminRead)

     Get list of job task matching filter. Optionnal fields can be requested in the response by using
    fields query parameters

    Args:
        status (str | Unset):
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[JobTask]
    """

    return sync_detailed(
        client=client,
        status=status,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    status: str | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> Response[ProblemDetails | list[JobTask]]:
    """Get list of job task matching filter (Auth policies: AdminRead)

     Get list of job task matching filter. Optionnal fields can be requested in the response by using
    fields query parameters

    Args:
        status (str | Unset):
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[JobTask]]
    """

    kwargs = _get_kwargs(
        status=status,
        mon_connection_status=mon_connection_status,
        mon_type=mon_type,
        mon_ip_address=mon_ip_address,
        monitoring_id=monitoring_id,
        mon_status=mon_status,
        loc_country=loc_country,
        loc_region=loc_region,
        loc_province=loc_province,
        loc_city=loc_city,
        loc_group_1=loc_group_1,
        loc_group_2=loc_group_2,
        loc_group_3=loc_group_3,
        loc_group_4=loc_group_4,
        loc_group_5=loc_group_5,
        loc_name=loc_name,
        loc_info=loc_info,
        loc_type=loc_type,
        q_loc=q_loc,
        id=id,
        field_start=field_start,
        field_end=field_end,
        field_order=field_order,
        field_sort=field_sort,
        q=q,
        gt_modified_date_time=gt_modified_date_time,
        lt_modified_date_time=lt_modified_date_time,
        gt_created_date_time=gt_created_date_time,
        lt_created_date_time=lt_created_date_time,
        fields=fields,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    status: str | Unset = UNSET,
    mon_connection_status: str | Unset = UNSET,
    mon_type: str | Unset = UNSET,
    mon_ip_address: str | Unset = UNSET,
    monitoring_id: list[int] | Unset = UNSET,
    mon_status: str | Unset = UNSET,
    loc_country: str | Unset = UNSET,
    loc_region: str | Unset = UNSET,
    loc_province: str | Unset = UNSET,
    loc_city: str | Unset = UNSET,
    loc_group_1: str | Unset = UNSET,
    loc_group_2: str | Unset = UNSET,
    loc_group_3: str | Unset = UNSET,
    loc_group_4: str | Unset = UNSET,
    loc_group_5: str | Unset = UNSET,
    loc_name: str | Unset = UNSET,
    loc_info: str | Unset = UNSET,
    loc_type: int | Unset = UNSET,
    q_loc: str | Unset = UNSET,
    id: list[str] | Unset = UNSET,
    field_start: int | Unset = UNSET,
    field_end: int | Unset = UNSET,
    field_order: EOrder | Unset = UNSET,
    field_sort: str | Unset = UNSET,
    q: str | Unset = UNSET,
    gt_modified_date_time: datetime.datetime | Unset = UNSET,
    lt_modified_date_time: datetime.datetime | Unset = UNSET,
    gt_created_date_time: datetime.datetime | Unset = UNSET,
    lt_created_date_time: datetime.datetime | Unset = UNSET,
    fields: list[str] | Unset = UNSET,
) -> ProblemDetails | list[JobTask] | None:
    """Get list of job task matching filter (Auth policies: AdminRead)

     Get list of job task matching filter. Optionnal fields can be requested in the response by using
    fields query parameters

    Args:
        status (str | Unset):
        mon_connection_status (str | Unset): Filter by monitoring connection status
        mon_type (str | Unset): Filter by monitoring type
        mon_ip_address (str | Unset): Filter by exact ip address, or MQTT(****) identifier. This
            allows to find Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | Unset): Filter with a list of exact Monitoring Id
        mon_status (str | Unset): Filter by monitoring site level status
        loc_country (str | Unset): Filter by site location country
        loc_region (str | Unset): Filter by site location region
        loc_province (str | Unset): Filter by site location province/state
        loc_city (str | Unset): Filter by site location city
        loc_group_1 (str | Unset): Filter by site location custom group 1
        loc_group_2 (str | Unset): Filter by site location custom group 2
        loc_group_3 (str | Unset): Filter by site location custom group 3
        loc_group_4 (str | Unset): Filter by site location custom group 4
        loc_group_5 (str | Unset): Filter by site location custom group 5
        loc_name (str | Unset): Filter by site location name
        loc_info (str | Unset): Filter by site location info/description
        loc_type (int | Unset): Filter by site location type
        q_loc (str | Unset): Text search across all location fields (name, country, city, etc.)
        id (list[str] | Unset): Filter by unique identifiers. Format depends on the object type
            (e.g., equipment: integer, element: 'equId_elemId')
        field_start (int | Unset): Pagination: starting index (0-based)
        field_end (int | Unset): Pagination: ending index (exclusive)
        field_order (EOrder | Unset):
        field_sort (str | Unset): Field name(s) to sort by. Can be comma-separated for multiple
            sort fields
        q (str | Unset): Text search query - searches across multiple fields depending on the
            object type
        gt_modified_date_time (datetime.datetime | Unset): Filter objects modified after this
            datetime (ISO-8601 format)
        lt_modified_date_time (datetime.datetime | Unset): Filter objects modified before this
            datetime (ISO-8601 format)
        gt_created_date_time (datetime.datetime | Unset): Filter objects created after this
            datetime (ISO-8601 format)
        lt_created_date_time (datetime.datetime | Unset): Filter objects created before this
            datetime (ISO-8601 format)
        fields (list[str] | Unset): Include optional objects in the response object (depends on
            the object). Examples for an element: 'Equipment' will include the related equipment
            object. Other useful examples: Equipment.Location, Equipment.MonitoringStatus, Audit. For
            monitoring level: Location, Equipments, Audit

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[JobTask]
    """

    return (
        await asyncio_detailed(
            client=client,
            status=status,
            mon_connection_status=mon_connection_status,
            mon_type=mon_type,
            mon_ip_address=mon_ip_address,
            monitoring_id=monitoring_id,
            mon_status=mon_status,
            loc_country=loc_country,
            loc_region=loc_region,
            loc_province=loc_province,
            loc_city=loc_city,
            loc_group_1=loc_group_1,
            loc_group_2=loc_group_2,
            loc_group_3=loc_group_3,
            loc_group_4=loc_group_4,
            loc_group_5=loc_group_5,
            loc_name=loc_name,
            loc_info=loc_info,
            loc_type=loc_type,
            q_loc=q_loc,
            id=id,
            field_start=field_start,
            field_end=field_end,
            field_order=field_order,
            field_sort=field_sort,
            q=q,
            gt_modified_date_time=gt_modified_date_time,
            lt_modified_date_time=lt_modified_date_time,
            gt_created_date_time=gt_created_date_time,
            lt_created_date_time=lt_created_date_time,
            fields=fields,
        )
    ).parsed
