from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response


def _get_kwargs(
    *,
    ip_range: str,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["ipRange"] = ip_range

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Monitorings/SearchMonitoringOnLocalNetwork",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    ip_range: str,
) -> Response[ProblemDetails | list[str]]:
    """(Auth policies: AdminWrite, ElementRead)

    Args:
        ip_range (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[str]]
    """

    kwargs = _get_kwargs(
        ip_range=ip_range,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    ip_range: str,
) -> ProblemDetails | list[str] | None:
    """(Auth policies: AdminWrite, ElementRead)

    Args:
        ip_range (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[str]
    """

    return sync_detailed(
        client=client,
        ip_range=ip_range,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    ip_range: str,
) -> Response[ProblemDetails | list[str]]:
    """(Auth policies: AdminWrite, ElementRead)

    Args:
        ip_range (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | list[str]]
    """

    kwargs = _get_kwargs(
        ip_range=ip_range,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    ip_range: str,
) -> ProblemDetails | list[str] | None:
    """(Auth policies: AdminWrite, ElementRead)

    Args:
        ip_range (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | list[str]
    """

    return (
        await asyncio_detailed(
            client=client,
            ip_range=ip_range,
        )
    ).parsed
