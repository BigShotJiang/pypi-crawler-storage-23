from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.report_auto_send import ReportAutoSend
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: str,
    *,
    body: ReportAutoSend | ReportAutoSend | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/api/ReportAutoSend/{id}".format(
            id=quote(str(id), safe=""),
        ),
    }

    if isinstance(body, ReportAutoSend):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, ReportAutoSend):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | ReportAutoSend | None:
    if response.status_code == 200:
        response_200 = ReportAutoSend.from_dict(response.json())

        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | ReportAutoSend]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ReportAutoSend | ReportAutoSend | Unset = UNSET,
) -> Response[ProblemDetails | ReportAutoSend]:
    """Modify report auto send (Auth policies: ReportRead, ReportWrite)

     Updates an existing report auto send with the provided data. The ID in the URL must match the report
    auto send's ID.

    Args:
        id (str):
        body (ReportAutoSend | Unset):
        body (ReportAutoSend | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ReportAutoSend]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ReportAutoSend | ReportAutoSend | Unset = UNSET,
) -> ProblemDetails | ReportAutoSend | None:
    """Modify report auto send (Auth policies: ReportRead, ReportWrite)

     Updates an existing report auto send with the provided data. The ID in the URL must match the report
    auto send's ID.

    Args:
        id (str):
        body (ReportAutoSend | Unset):
        body (ReportAutoSend | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ReportAutoSend
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ReportAutoSend | ReportAutoSend | Unset = UNSET,
) -> Response[ProblemDetails | ReportAutoSend]:
    """Modify report auto send (Auth policies: ReportRead, ReportWrite)

     Updates an existing report auto send with the provided data. The ID in the URL must match the report
    auto send's ID.

    Args:
        id (str):
        body (ReportAutoSend | Unset):
        body (ReportAutoSend | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | ReportAutoSend]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    body: ReportAutoSend | ReportAutoSend | Unset = UNSET,
) -> ProblemDetails | ReportAutoSend | None:
    """Modify report auto send (Auth policies: ReportRead, ReportWrite)

     Updates an existing report auto send with the provided data. The ID in the URL must match the report
    auto send's ID.

    Args:
        id (str):
        body (ReportAutoSend | Unset):
        body (ReportAutoSend | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | ReportAutoSend
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
        )
    ).parsed
