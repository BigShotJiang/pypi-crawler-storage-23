import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    resolution: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    json_from_: str | Unset = UNSET
    if not isinstance(from_, Unset):
        json_from_ = from_.isoformat()
    params["from"] = json_from_

    json_to: str | Unset = UNSET
    if not isinstance(to, Unset):
        json_to = to.isoformat()
    params["to"] = json_to

    params["resolution"] = resolution

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/Tools/CopySqlDataRecordsToInflux",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | str | None:
    if response.status_code == 200:
        response_200 = cast(str, response.json())
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    resolution: str | Unset = UNSET,
) -> Response[ProblemDetails | str]:
    """Copy SQL data records to InfluxDB (Auth policies: AdminWrite)

     Migrates time series data from SQL database to InfluxDB for specified date range and resolution
    (minute/hour/day).

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        resolution (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | str]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        resolution=resolution,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    resolution: str | Unset = UNSET,
) -> ProblemDetails | str | None:
    """Copy SQL data records to InfluxDB (Auth policies: AdminWrite)

     Migrates time series data from SQL database to InfluxDB for specified date range and resolution
    (minute/hour/day).

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        resolution (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | str
    """

    return sync_detailed(
        client=client,
        from_=from_,
        to=to,
        resolution=resolution,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    resolution: str | Unset = UNSET,
) -> Response[ProblemDetails | str]:
    """Copy SQL data records to InfluxDB (Auth policies: AdminWrite)

     Migrates time series data from SQL database to InfluxDB for specified date range and resolution
    (minute/hour/day).

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        resolution (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | str]
    """

    kwargs = _get_kwargs(
        from_=from_,
        to=to,
        resolution=resolution,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    from_: datetime.datetime | Unset = UNSET,
    to: datetime.datetime | Unset = UNSET,
    resolution: str | Unset = UNSET,
) -> ProblemDetails | str | None:
    """Copy SQL data records to InfluxDB (Auth policies: AdminWrite)

     Migrates time series data from SQL database to InfluxDB for specified date range and resolution
    (minute/hour/day).

    Args:
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        resolution (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | str
    """

    return (
        await asyncio_detailed(
            client=client,
            from_=from_,
            to=to,
            resolution=resolution,
        )
    ).parsed
