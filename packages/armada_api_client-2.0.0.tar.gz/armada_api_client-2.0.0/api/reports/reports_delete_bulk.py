from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.query_report import QueryReport
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: QueryReport | QueryReport | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Reports/DeleteWithFilter",
    }

    if isinstance(body, QueryReport):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, QueryReport):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ProblemDetails | int | None:
    if response.status_code == 200:
        response_200 = cast(int, response.json())
        return response_200

    if response.status_code == 400:
        response_400 = ProblemDetails.from_dict(response.json())

        return response_400

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ProblemDetails | int]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryReport | QueryReport | Unset = UNSET,
) -> Response[ProblemDetails | int]:
    """Delete multiple report infos by filter (Auth policies: ReportRead, ReportWrite)

     Deletes multiple report infos that match the provided query filter criteria.

    Args:
        body (QueryReport | Unset):
        body (QueryReport | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QueryReport | QueryReport | Unset = UNSET,
) -> ProblemDetails | int | None:
    """Delete multiple report infos by filter (Auth policies: ReportRead, ReportWrite)

     Deletes multiple report infos that match the provided query filter criteria.

    Args:
        body (QueryReport | Unset):
        body (QueryReport | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryReport | QueryReport | Unset = UNSET,
) -> Response[ProblemDetails | int]:
    """Delete multiple report infos by filter (Auth policies: ReportRead, ReportWrite)

     Deletes multiple report infos that match the provided query filter criteria.

    Args:
        body (QueryReport | Unset):
        body (QueryReport | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ProblemDetails | int]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QueryReport | QueryReport | Unset = UNSET,
) -> ProblemDetails | int | None:
    """Delete multiple report infos by filter (Auth policies: ReportRead, ReportWrite)

     Deletes multiple report infos that match the provided query filter criteria.

    Args:
        body (QueryReport | Unset):
        body (QueryReport | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ProblemDetails | int
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
