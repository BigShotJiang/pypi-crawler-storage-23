from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.counted_equipment_ordered_by import CountedEquipmentOrderedBy
from ...models.criteria_string import CriteriaString
from ...models.problem_details import ProblemDetails
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: list[CriteriaString] | list[CriteriaString] | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Equipments/CountTree",
    }

    if isinstance(body, list[CriteriaString]):
        _kwargs["json"] = []
        for body_item_data in body:
            body_item = body_item_data.to_dict()
            _kwargs["json"].append(body_item)

        headers["Content-Type"] = "application/json"
    if isinstance(body, list[CriteriaString]):
        _kwargs["json"] = []
        for body_item_data in body:
            body_item = body_item_data.to_dict()
            _kwargs["json"].append(body_item)

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> CountedEquipmentOrderedBy | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = CountedEquipmentOrderedBy.from_dict(response.json())

        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[CountedEquipmentOrderedBy | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: list[CriteriaString] | list[CriteriaString] | Unset = UNSET,
) -> Response[CountedEquipmentOrderedBy | ProblemDetails]:
    """Get ordered equipment list (Auth policies: ElementRead)

     Retrieves equipments grouped in a cluster with ordering and counting. Used for tree view display.

    Args:
        body (list[CriteriaString]):
        body (list[CriteriaString]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CountedEquipmentOrderedBy | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: list[CriteriaString] | list[CriteriaString] | Unset = UNSET,
) -> CountedEquipmentOrderedBy | ProblemDetails | None:
    """Get ordered equipment list (Auth policies: ElementRead)

     Retrieves equipments grouped in a cluster with ordering and counting. Used for tree view display.

    Args:
        body (list[CriteriaString]):
        body (list[CriteriaString]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CountedEquipmentOrderedBy | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: list[CriteriaString] | list[CriteriaString] | Unset = UNSET,
) -> Response[CountedEquipmentOrderedBy | ProblemDetails]:
    """Get ordered equipment list (Auth policies: ElementRead)

     Retrieves equipments grouped in a cluster with ordering and counting. Used for tree view display.

    Args:
        body (list[CriteriaString]):
        body (list[CriteriaString]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CountedEquipmentOrderedBy | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: list[CriteriaString] | list[CriteriaString] | Unset = UNSET,
) -> CountedEquipmentOrderedBy | ProblemDetails | None:
    """Get ordered equipment list (Auth policies: ElementRead)

     Retrieves equipments grouped in a cluster with ordering and counting. Used for tree view display.

    Args:
        body (list[CriteriaString]):
        body (list[CriteriaString]):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CountedEquipmentOrderedBy | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
