import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.problem_details import ProblemDetails
from ...models.query_equipment import QueryEquipment
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: QueryEquipment | QueryEquipment | Unset = UNSET,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_start_time = start_time.isoformat()
    params["startTime"] = json_start_time

    json_end_time = end_time.isoformat()
    params["endTime"] = json_end_time

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/Equipments/SetMaintenanceMode",
        "params": params,
    }

    if isinstance(body, QueryEquipment):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/json"
    if isinstance(body, QueryEquipment):
        if not isinstance(body, Unset):
            _kwargs["json"] = body.to_dict()

        headers["Content-Type"] = "application/*+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | ProblemDetails | None:
    if response.status_code == 200:
        response_200 = cast(Any, None)
        return response_200

    if response.status_code == 401:
        response_401 = ProblemDetails.from_dict(response.json())

        return response_401

    if response.status_code == 404:
        response_404 = ProblemDetails.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | ProblemDetails]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryEquipment | QueryEquipment | Unset = UNSET,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
) -> Response[Any | ProblemDetails]:
    """Set equipment maintenance mode (Auth policies: ElementRead, ElementWrite)

     Disables alarms on specified equipments by setting maintenance mode with start and end times.

    Args:
        start_time (datetime.datetime):
        end_time (datetime.datetime):
        body (QueryEquipment | Unset):
        body (QueryEquipment | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
        start_time=start_time,
        end_time=end_time,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: QueryEquipment | QueryEquipment | Unset = UNSET,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
) -> Any | ProblemDetails | None:
    """Set equipment maintenance mode (Auth policies: ElementRead, ElementWrite)

     Disables alarms on specified equipments by setting maintenance mode with start and end times.

    Args:
        start_time (datetime.datetime):
        end_time (datetime.datetime):
        body (QueryEquipment | Unset):
        body (QueryEquipment | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return sync_detailed(
        client=client,
        body=body,
        start_time=start_time,
        end_time=end_time,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: QueryEquipment | QueryEquipment | Unset = UNSET,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
) -> Response[Any | ProblemDetails]:
    """Set equipment maintenance mode (Auth policies: ElementRead, ElementWrite)

     Disables alarms on specified equipments by setting maintenance mode with start and end times.

    Args:
        start_time (datetime.datetime):
        end_time (datetime.datetime):
        body (QueryEquipment | Unset):
        body (QueryEquipment | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ProblemDetails]
    """

    kwargs = _get_kwargs(
        body=body,
        start_time=start_time,
        end_time=end_time,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: QueryEquipment | QueryEquipment | Unset = UNSET,
    start_time: datetime.datetime,
    end_time: datetime.datetime,
) -> Any | ProblemDetails | None:
    """Set equipment maintenance mode (Auth policies: ElementRead, ElementWrite)

     Disables alarms on specified equipments by setting maintenance mode with start and end times.

    Args:
        start_time (datetime.datetime):
        end_time (datetime.datetime):
        body (QueryEquipment | Unset):
        body (QueryEquipment | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ProblemDetails
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            start_time=start_time,
            end_time=end_time,
        )
    ).parsed
