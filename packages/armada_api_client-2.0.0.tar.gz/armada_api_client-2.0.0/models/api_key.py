from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_date_and_user import AuditDateAndUser


T = TypeVar("T", bound="ApiKey")


@_attrs_define
class ApiKey:
    """
    Attributes:
        id (str): Unique API key identifier (string representation of KeyId)
        key_id (int): API key identifier (auto-generated unique ID)
        description (str): Description of what this API key is used for
        group_id (int): User group ID that determines permissions for this API key
        audit (AuditDateAndUser | None | Unset): Audit information with creation/modification dates and users (included
            only when 'Audit' is specified in fields parameter)
        key (None | str | Unset): The actual API key string (only returned when creating a new key, null otherwise for
            security)
    """

    id: str
    key_id: int
    description: str
    group_id: int
    audit: AuditDateAndUser | None | Unset = UNSET
    key: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.audit_date_and_user import AuditDateAndUser

        id = self.id

        key_id = self.key_id

        description = self.description

        group_id = self.group_id

        audit: dict[str, Any] | None | Unset
        if isinstance(self.audit, Unset):
            audit = UNSET
        elif isinstance(self.audit, AuditDateAndUser):
            audit = self.audit.to_dict()
        else:
            audit = self.audit

        key: None | str | Unset
        if isinstance(self.key, Unset):
            key = UNSET
        else:
            key = self.key

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "keyId": key_id,
                "description": description,
                "groupId": group_id,
            }
        )
        if audit is not UNSET:
            field_dict["audit"] = audit
        if key is not UNSET:
            field_dict["key"] = key

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_date_and_user import AuditDateAndUser

        d = dict(src_dict)
        id = d.pop("id")

        key_id = d.pop("keyId")

        description = d.pop("description")

        group_id = d.pop("groupId")

        def _parse_audit(data: object) -> AuditDateAndUser | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                audit_type_1 = AuditDateAndUser.from_dict(data)

                return audit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuditDateAndUser | None | Unset, data)

        audit = _parse_audit(d.pop("audit", UNSET))

        def _parse_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        key = _parse_key(d.pop("key", UNSET))

        api_key = cls(
            id=id,
            key_id=key_id,
            description=description,
            group_id=group_id,
            audit=audit,
            key=key,
        )

        return api_key
