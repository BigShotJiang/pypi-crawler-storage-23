from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.date_values import DateValues
    from ..models.multi_time_series_headers_type_0_item import (
        MultiTimeSeriesHeadersType0Item,
    )


T = TypeVar("T", bound="MultiTimeSeries")


@_attrs_define
class MultiTimeSeries:
    """
    Attributes:
        headers (list[MultiTimeSeriesHeadersType0Item] | None | Unset): List of header objects describing each time
            series metric (keys, equipment info, etc.)
        values (list[DateValues] | None | Unset): List of timestamped value arrays containing data for all metrics
    """

    headers: list[MultiTimeSeriesHeadersType0Item] | None | Unset = UNSET
    values: list[DateValues] | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        headers: list[dict[str, Any]] | None | Unset
        if isinstance(self.headers, Unset):
            headers = UNSET
        elif isinstance(self.headers, list):
            headers = []
            for headers_type_0_item_data in self.headers:
                headers_type_0_item = headers_type_0_item_data.to_dict()
                headers.append(headers_type_0_item)

        else:
            headers = self.headers

        values: list[dict[str, Any]] | None | Unset
        if isinstance(self.values, Unset):
            values = UNSET
        elif isinstance(self.values, list):
            values = []
            for values_type_0_item_data in self.values:
                values_type_0_item = values_type_0_item_data.to_dict()
                values.append(values_type_0_item)

        else:
            values = self.values

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if headers is not UNSET:
            field_dict["headers"] = headers
        if values is not UNSET:
            field_dict["values"] = values

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.date_values import DateValues
        from ..models.multi_time_series_headers_type_0_item import (
            MultiTimeSeriesHeadersType0Item,
        )

        d = dict(src_dict)

        def _parse_headers(
            data: object,
        ) -> list[MultiTimeSeriesHeadersType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                headers_type_0 = []
                _headers_type_0 = data
                for headers_type_0_item_data in _headers_type_0:
                    headers_type_0_item = MultiTimeSeriesHeadersType0Item.from_dict(
                        headers_type_0_item_data
                    )

                    headers_type_0.append(headers_type_0_item)

                return headers_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[MultiTimeSeriesHeadersType0Item] | None | Unset, data)

        headers = _parse_headers(d.pop("headers", UNSET))

        def _parse_values(data: object) -> list[DateValues] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                values_type_0 = []
                _values_type_0 = data
                for values_type_0_item_data in _values_type_0:
                    values_type_0_item = DateValues.from_dict(values_type_0_item_data)

                    values_type_0.append(values_type_0_item)

                return values_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DateValues] | None | Unset, data)

        values = _parse_values(d.pop("values", UNSET))

        multi_time_series = cls(
            headers=headers,
            values=values,
        )

        return multi_time_series
