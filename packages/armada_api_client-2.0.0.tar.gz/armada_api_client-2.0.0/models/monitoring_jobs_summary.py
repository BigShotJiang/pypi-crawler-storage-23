from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="MonitoringJobsSummary")


@_attrs_define
class MonitoringJobsSummary:
    """
    Attributes:
        monitoring_id (int): Monitoring system identifier
        last_job (datetime.datetime | None): Datetime of the most recent job execution (ISO-8601 format)
        get_count (int): Total count of HTTP GET jobs executed
        get_start (datetime.datetime | None): Start datetime of current/last HTTP GET job (ISO-8601 format)
        get_state (None | str): Current state of HTTP GET job (e.g., 'Running', 'Completed', 'Failed')
        get_progress_info (None | str): Progress information for HTTP GET job
        post_count (int): Total count of HTTP POST jobs executed
        post_start (datetime.datetime | None): Start datetime of current/last HTTP POST job (ISO-8601 format)
        post_state (None | str): Current state of HTTP POST job (e.g., 'Running', 'Completed', 'Failed')
        post_progress_info (None | str): Progress information for HTTP POST job
        event_count (int): Total count of event processing jobs executed
        event_start (datetime.datetime | None): Start datetime of current/last event processing job (ISO-8601 format)
        event_state (None | str): Current state of event processing job
        event_progress_info (None | str): Progress information for event processing job
        task_count (int): Total count of monitoring tasks executed
        task_name (None | str): Name of current/last monitoring task
        task_start (datetime.datetime | None): Start datetime of current/last monitoring task (ISO-8601 format)
        task_state (None | str): Current state of monitoring task
        task_progress_info (None | str): Progress information for monitoring task
        id (None | str | Unset): Unique identifier (string representation of MonitoringId)
    """

    monitoring_id: int
    last_job: datetime.datetime | None
    get_count: int
    get_start: datetime.datetime | None
    get_state: None | str
    get_progress_info: None | str
    post_count: int
    post_start: datetime.datetime | None
    post_state: None | str
    post_progress_info: None | str
    event_count: int
    event_start: datetime.datetime | None
    event_state: None | str
    event_progress_info: None | str
    task_count: int
    task_name: None | str
    task_start: datetime.datetime | None
    task_state: None | str
    task_progress_info: None | str
    id: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        monitoring_id = self.monitoring_id

        last_job: None | str
        if isinstance(self.last_job, datetime.datetime):
            last_job = self.last_job.isoformat()
        else:
            last_job = self.last_job

        get_count = self.get_count

        get_start: None | str
        if isinstance(self.get_start, datetime.datetime):
            get_start = self.get_start.isoformat()
        else:
            get_start = self.get_start

        get_state: None | str
        get_state = self.get_state

        get_progress_info: None | str
        get_progress_info = self.get_progress_info

        post_count = self.post_count

        post_start: None | str
        if isinstance(self.post_start, datetime.datetime):
            post_start = self.post_start.isoformat()
        else:
            post_start = self.post_start

        post_state: None | str
        post_state = self.post_state

        post_progress_info: None | str
        post_progress_info = self.post_progress_info

        event_count = self.event_count

        event_start: None | str
        if isinstance(self.event_start, datetime.datetime):
            event_start = self.event_start.isoformat()
        else:
            event_start = self.event_start

        event_state: None | str
        event_state = self.event_state

        event_progress_info: None | str
        event_progress_info = self.event_progress_info

        task_count = self.task_count

        task_name: None | str
        task_name = self.task_name

        task_start: None | str
        if isinstance(self.task_start, datetime.datetime):
            task_start = self.task_start.isoformat()
        else:
            task_start = self.task_start

        task_state: None | str
        task_state = self.task_state

        task_progress_info: None | str
        task_progress_info = self.task_progress_info

        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "monitoringId": monitoring_id,
                "lastJob": last_job,
                "getCount": get_count,
                "getStart": get_start,
                "getState": get_state,
                "getProgressInfo": get_progress_info,
                "postCount": post_count,
                "postStart": post_start,
                "postState": post_state,
                "postProgressInfo": post_progress_info,
                "eventCount": event_count,
                "eventStart": event_start,
                "eventState": event_state,
                "eventProgressInfo": event_progress_info,
                "taskCount": task_count,
                "taskName": task_name,
                "taskStart": task_start,
                "taskState": task_state,
                "taskProgressInfo": task_progress_info,
            }
        )
        if id is not UNSET:
            field_dict["id"] = id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        monitoring_id = d.pop("monitoringId")

        def _parse_last_job(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_job_type_0 = isoparse(data)

                return last_job_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        last_job = _parse_last_job(d.pop("lastJob"))

        get_count = d.pop("getCount")

        def _parse_get_start(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                get_start_type_0 = isoparse(data)

                return get_start_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        get_start = _parse_get_start(d.pop("getStart"))

        def _parse_get_state(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        get_state = _parse_get_state(d.pop("getState"))

        def _parse_get_progress_info(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        get_progress_info = _parse_get_progress_info(d.pop("getProgressInfo"))

        post_count = d.pop("postCount")

        def _parse_post_start(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                post_start_type_0 = isoparse(data)

                return post_start_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        post_start = _parse_post_start(d.pop("postStart"))

        def _parse_post_state(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        post_state = _parse_post_state(d.pop("postState"))

        def _parse_post_progress_info(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        post_progress_info = _parse_post_progress_info(d.pop("postProgressInfo"))

        event_count = d.pop("eventCount")

        def _parse_event_start(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                event_start_type_0 = isoparse(data)

                return event_start_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        event_start = _parse_event_start(d.pop("eventStart"))

        def _parse_event_state(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        event_state = _parse_event_state(d.pop("eventState"))

        def _parse_event_progress_info(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        event_progress_info = _parse_event_progress_info(d.pop("eventProgressInfo"))

        task_count = d.pop("taskCount")

        def _parse_task_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        task_name = _parse_task_name(d.pop("taskName"))

        def _parse_task_start(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                task_start_type_0 = isoparse(data)

                return task_start_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        task_start = _parse_task_start(d.pop("taskStart"))

        def _parse_task_state(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        task_state = _parse_task_state(d.pop("taskState"))

        def _parse_task_progress_info(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        task_progress_info = _parse_task_progress_info(d.pop("taskProgressInfo"))

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        monitoring_jobs_summary = cls(
            monitoring_id=monitoring_id,
            last_job=last_job,
            get_count=get_count,
            get_start=get_start,
            get_state=get_state,
            get_progress_info=get_progress_info,
            post_count=post_count,
            post_start=post_start,
            post_state=post_state,
            post_progress_info=post_progress_info,
            event_count=event_count,
            event_start=event_start,
            event_state=event_state,
            event_progress_info=event_progress_info,
            task_count=task_count,
            task_name=task_name,
            task_start=task_start,
            task_state=task_state,
            task_progress_info=task_progress_info,
            id=id,
        )

        return monitoring_jobs_summary
