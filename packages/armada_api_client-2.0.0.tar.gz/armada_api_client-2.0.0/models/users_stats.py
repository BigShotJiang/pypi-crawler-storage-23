from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.user_stat import UserStat


T = TypeVar("T", bound="UsersStats")


@_attrs_define
class UsersStats:
    """
    Attributes:
        count (int):
        last_5_active (list[UserStat] | None):
    """

    count: int
    last_5_active: list[UserStat] | None

    def to_dict(self) -> dict[str, Any]:
        count = self.count

        last_5_active: list[dict[str, Any]] | None
        if isinstance(self.last_5_active, list):
            last_5_active = []
            for last_5_active_type_0_item_data in self.last_5_active:
                last_5_active_type_0_item = last_5_active_type_0_item_data.to_dict()
                last_5_active.append(last_5_active_type_0_item)

        else:
            last_5_active = self.last_5_active

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "count": count,
                "last5Active": last_5_active,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_stat import UserStat

        d = dict(src_dict)
        count = d.pop("count")

        def _parse_last_5_active(data: object) -> list[UserStat] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                last_5_active_type_0 = []
                _last_5_active_type_0 = data
                for last_5_active_type_0_item_data in _last_5_active_type_0:
                    last_5_active_type_0_item = UserStat.from_dict(
                        last_5_active_type_0_item_data
                    )

                    last_5_active_type_0.append(last_5_active_type_0_item)

                return last_5_active_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[UserStat] | None, data)

        last_5_active = _parse_last_5_active(d.pop("last5Active"))

        users_stats = cls(
            count=count,
            last_5_active=last_5_active,
        )

        return users_stats
