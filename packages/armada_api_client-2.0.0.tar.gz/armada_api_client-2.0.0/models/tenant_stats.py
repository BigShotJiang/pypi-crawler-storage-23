from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.monitorings_stats import MonitoringsStats
    from ..models.users_stats import UsersStats


T = TypeVar("T", bound="TenantStats")


@_attrs_define
class TenantStats:
    """
    Attributes:
        id (None | str):
        ready (bool):
        monitorings (MonitoringsStats | None):
        users (None | UsersStats):
    """

    id: None | str
    ready: bool
    monitorings: MonitoringsStats | None
    users: None | UsersStats

    def to_dict(self) -> dict[str, Any]:
        from ..models.monitorings_stats import MonitoringsStats
        from ..models.users_stats import UsersStats

        id: None | str
        id = self.id

        ready = self.ready

        monitorings: dict[str, Any] | None
        if isinstance(self.monitorings, MonitoringsStats):
            monitorings = self.monitorings.to_dict()
        else:
            monitorings = self.monitorings

        users: dict[str, Any] | None
        if isinstance(self.users, UsersStats):
            users = self.users.to_dict()
        else:
            users = self.users

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "ready": ready,
                "monitorings": monitorings,
                "users": users,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.monitorings_stats import MonitoringsStats
        from ..models.users_stats import UsersStats

        d = dict(src_dict)

        def _parse_id(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        id = _parse_id(d.pop("id"))

        ready = d.pop("ready")

        def _parse_monitorings(data: object) -> MonitoringsStats | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                monitorings_type_1 = MonitoringsStats.from_dict(data)

                return monitorings_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MonitoringsStats | None, data)

        monitorings = _parse_monitorings(d.pop("monitorings"))

        def _parse_users(data: object) -> None | UsersStats:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                users_type_1 = UsersStats.from_dict(data)

                return users_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UsersStats, data)

        users = _parse_users(d.pop("users"))

        tenant_stats = cls(
            id=id,
            ready=ready,
            monitorings=monitorings,
            users=users,
        )

        return tenant_stats
