from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.date_value import DateValue
    from ..models.single_time_series_header_type_0 import SingleTimeSeriesHeaderType0


T = TypeVar("T", bound="SingleTimeSeries")


@_attrs_define
class SingleTimeSeries:
    """
    Attributes:
        header (None | SingleTimeSeriesHeaderType0):
        values (list[DateValue] | None):
    """

    header: None | SingleTimeSeriesHeaderType0
    values: list[DateValue] | None

    def to_dict(self) -> dict[str, Any]:
        from ..models.single_time_series_header_type_0 import (
            SingleTimeSeriesHeaderType0,
        )

        header: dict[str, Any] | None
        if isinstance(self.header, SingleTimeSeriesHeaderType0):
            header = self.header.to_dict()
        else:
            header = self.header

        values: list[dict[str, Any]] | None
        if isinstance(self.values, list):
            values = []
            for values_type_0_item_data in self.values:
                values_type_0_item = values_type_0_item_data.to_dict()
                values.append(values_type_0_item)

        else:
            values = self.values

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "header": header,
                "values": values,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.date_value import DateValue
        from ..models.single_time_series_header_type_0 import (
            SingleTimeSeriesHeaderType0,
        )

        d = dict(src_dict)

        def _parse_header(data: object) -> None | SingleTimeSeriesHeaderType0:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                header_type_0 = SingleTimeSeriesHeaderType0.from_dict(data)

                return header_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | SingleTimeSeriesHeaderType0, data)

        header = _parse_header(d.pop("header"))

        def _parse_values(data: object) -> list[DateValue] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                values_type_0 = []
                _values_type_0 = data
                for values_type_0_item_data in _values_type_0:
                    values_type_0_item = DateValue.from_dict(values_type_0_item_data)

                    values_type_0.append(values_type_0_item)

                return values_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[DateValue] | None, data)

        values = _parse_values(d.pop("values"))

        single_time_series = cls(
            header=header,
            values=values,
        )

        return single_time_series
