from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.criteria_string import CriteriaString
    from ..models.table_info_selector import TableInfoSelector


T = TypeVar("T", bound="ReportParameters")


@_attrs_define
class ReportParameters:
    """
    Attributes:
        table_info_selectors (list[TableInfoSelector]): Table/data selectors defining which tables and columns to
            include
        type_ (str): Report type (e.g., 'Equipment', 'DataRecords', 'Alarms', 'CustomQuery')
        criterias (list[CriteriaString] | None | Unset): Criteria to filter which equipments are included in the report
        equ_ids (list[int] | None | Unset): List of specific equipment IDs to include in the report
        columns_to_remove (list[str] | None | Unset): List of column names to exclude from the report
        custom_query (None | str | Unset): Custom SQL query for custom report types
        culture_abbreviation (None | str | Unset): Culture abbreviation for localization (e.g., 'en-US', 'fr-FR')
    """

    table_info_selectors: list[TableInfoSelector]
    type_: str
    criterias: list[CriteriaString] | None | Unset = UNSET
    equ_ids: list[int] | None | Unset = UNSET
    columns_to_remove: list[str] | None | Unset = UNSET
    custom_query: None | str | Unset = UNSET
    culture_abbreviation: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        table_info_selectors = []
        for table_info_selectors_item_data in self.table_info_selectors:
            table_info_selectors_item = table_info_selectors_item_data.to_dict()
            table_info_selectors.append(table_info_selectors_item)

        type_ = self.type_

        criterias: list[dict[str, Any]] | None | Unset
        if isinstance(self.criterias, Unset):
            criterias = UNSET
        elif isinstance(self.criterias, list):
            criterias = []
            for criterias_type_0_item_data in self.criterias:
                criterias_type_0_item = criterias_type_0_item_data.to_dict()
                criterias.append(criterias_type_0_item)

        else:
            criterias = self.criterias

        equ_ids: list[int] | None | Unset
        if isinstance(self.equ_ids, Unset):
            equ_ids = UNSET
        elif isinstance(self.equ_ids, list):
            equ_ids = self.equ_ids

        else:
            equ_ids = self.equ_ids

        columns_to_remove: list[str] | None | Unset
        if isinstance(self.columns_to_remove, Unset):
            columns_to_remove = UNSET
        elif isinstance(self.columns_to_remove, list):
            columns_to_remove = self.columns_to_remove

        else:
            columns_to_remove = self.columns_to_remove

        custom_query: None | str | Unset
        if isinstance(self.custom_query, Unset):
            custom_query = UNSET
        else:
            custom_query = self.custom_query

        culture_abbreviation: None | str | Unset
        if isinstance(self.culture_abbreviation, Unset):
            culture_abbreviation = UNSET
        else:
            culture_abbreviation = self.culture_abbreviation

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tableInfoSelectors": table_info_selectors,
                "type": type_,
            }
        )
        if criterias is not UNSET:
            field_dict["criterias"] = criterias
        if equ_ids is not UNSET:
            field_dict["equIds"] = equ_ids
        if columns_to_remove is not UNSET:
            field_dict["columnsToRemove"] = columns_to_remove
        if custom_query is not UNSET:
            field_dict["customQuery"] = custom_query
        if culture_abbreviation is not UNSET:
            field_dict["cultureAbbreviation"] = culture_abbreviation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.criteria_string import CriteriaString
        from ..models.table_info_selector import TableInfoSelector

        d = dict(src_dict)
        table_info_selectors = []
        _table_info_selectors = d.pop("tableInfoSelectors")
        for table_info_selectors_item_data in _table_info_selectors:
            table_info_selectors_item = TableInfoSelector.from_dict(
                table_info_selectors_item_data
            )

            table_info_selectors.append(table_info_selectors_item)

        type_ = d.pop("type")

        def _parse_criterias(data: object) -> list[CriteriaString] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                criterias_type_0 = []
                _criterias_type_0 = data
                for criterias_type_0_item_data in _criterias_type_0:
                    criterias_type_0_item = CriteriaString.from_dict(
                        criterias_type_0_item_data
                    )

                    criterias_type_0.append(criterias_type_0_item)

                return criterias_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[CriteriaString] | None | Unset, data)

        criterias = _parse_criterias(d.pop("criterias", UNSET))

        def _parse_equ_ids(data: object) -> list[int] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                equ_ids_type_0 = cast(list[int], data)

                return equ_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[int] | None | Unset, data)

        equ_ids = _parse_equ_ids(d.pop("equIds", UNSET))

        def _parse_columns_to_remove(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                columns_to_remove_type_0 = cast(list[str], data)

                return columns_to_remove_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        columns_to_remove = _parse_columns_to_remove(d.pop("columnsToRemove", UNSET))

        def _parse_custom_query(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        custom_query = _parse_custom_query(d.pop("customQuery", UNSET))

        def _parse_culture_abbreviation(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        culture_abbreviation = _parse_culture_abbreviation(
            d.pop("cultureAbbreviation", UNSET)
        )

        report_parameters = cls(
            table_info_selectors=table_info_selectors,
            type_=type_,
            criterias=criterias,
            equ_ids=equ_ids,
            columns_to_remove=columns_to_remove,
            custom_query=custom_query,
            culture_abbreviation=culture_abbreviation,
        )

        return report_parameters
