from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_config import UserConfig


T = TypeVar("T", bound="User")


@_attrs_define
class User:
    """
    Attributes:
        id (str): Unique user identifier (string representation of UserId)
        user_id (int): User identifier (auto-generated unique ID)
        login (str): User login/username for authentication
        first_name (None | str): User's first name
        last_name (None | str): User's last name
        mail (None | str): User's email address
        phone (None | str): User's phone number
        language (None | str): User's preferred language code (e.g., 'en', 'fr', 'es')
        group_id (int): User group identifier determining permissions and roles
        auth_source (int): Authentication source identifier (0=local, 1=LDAP, etc.)
        password (None | str | Unset): User password (write-only, never returned in responses)
        last_connection (datetime.datetime | None | Unset): Last successful login datetime (ISO-8601 format)
        group_name (None | str | Unset): User group name (included only when 'GroupName' is specified in fields
            parameter)
        roles (list[str] | None | Unset): List of role names assigned to this user (included only when 'Roles' is
            specified in fields parameter)
        user_config (None | Unset | UserConfig): User configuration and preferences (included only when 'UserConfig' is
            specified in fields parameter)
        tenant (None | str | Unset): Tenant name this user belongs to
        tenant_actual (None | str | Unset): Actual tenant name if user is accessing from a delegated tenant
        tenants (list[str] | None | Unset): List of tenant names this user has access to (for partner/admin users)
    """

    id: str
    user_id: int
    login: str
    first_name: None | str
    last_name: None | str
    mail: None | str
    phone: None | str
    language: None | str
    group_id: int
    auth_source: int
    password: None | str | Unset = UNSET
    last_connection: datetime.datetime | None | Unset = UNSET
    group_name: None | str | Unset = UNSET
    roles: list[str] | None | Unset = UNSET
    user_config: None | Unset | UserConfig = UNSET
    tenant: None | str | Unset = UNSET
    tenant_actual: None | str | Unset = UNSET
    tenants: list[str] | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.user_config import UserConfig

        id = self.id

        user_id = self.user_id

        login = self.login

        first_name: None | str
        first_name = self.first_name

        last_name: None | str
        last_name = self.last_name

        mail: None | str
        mail = self.mail

        phone: None | str
        phone = self.phone

        language: None | str
        language = self.language

        group_id = self.group_id

        auth_source = self.auth_source

        password: None | str | Unset
        if isinstance(self.password, Unset):
            password = UNSET
        else:
            password = self.password

        last_connection: None | str | Unset
        if isinstance(self.last_connection, Unset):
            last_connection = UNSET
        elif isinstance(self.last_connection, datetime.datetime):
            last_connection = self.last_connection.isoformat()
        else:
            last_connection = self.last_connection

        group_name: None | str | Unset
        if isinstance(self.group_name, Unset):
            group_name = UNSET
        else:
            group_name = self.group_name

        roles: list[str] | None | Unset
        if isinstance(self.roles, Unset):
            roles = UNSET
        elif isinstance(self.roles, list):
            roles = self.roles

        else:
            roles = self.roles

        user_config: dict[str, Any] | None | Unset
        if isinstance(self.user_config, Unset):
            user_config = UNSET
        elif isinstance(self.user_config, UserConfig):
            user_config = self.user_config.to_dict()
        else:
            user_config = self.user_config

        tenant: None | str | Unset
        if isinstance(self.tenant, Unset):
            tenant = UNSET
        else:
            tenant = self.tenant

        tenant_actual: None | str | Unset
        if isinstance(self.tenant_actual, Unset):
            tenant_actual = UNSET
        else:
            tenant_actual = self.tenant_actual

        tenants: list[str] | None | Unset
        if isinstance(self.tenants, Unset):
            tenants = UNSET
        elif isinstance(self.tenants, list):
            tenants = self.tenants

        else:
            tenants = self.tenants

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "userId": user_id,
                "login": login,
                "firstName": first_name,
                "lastName": last_name,
                "mail": mail,
                "phone": phone,
                "language": language,
                "groupId": group_id,
                "authSource": auth_source,
            }
        )
        if password is not UNSET:
            field_dict["password"] = password
        if last_connection is not UNSET:
            field_dict["lastConnection"] = last_connection
        if group_name is not UNSET:
            field_dict["groupName"] = group_name
        if roles is not UNSET:
            field_dict["roles"] = roles
        if user_config is not UNSET:
            field_dict["userConfig"] = user_config
        if tenant is not UNSET:
            field_dict["tenant"] = tenant
        if tenant_actual is not UNSET:
            field_dict["tenantActual"] = tenant_actual
        if tenants is not UNSET:
            field_dict["tenants"] = tenants

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_config import UserConfig

        d = dict(src_dict)
        id = d.pop("id")

        user_id = d.pop("userId")

        login = d.pop("login")

        def _parse_first_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        first_name = _parse_first_name(d.pop("firstName"))

        def _parse_last_name(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        last_name = _parse_last_name(d.pop("lastName"))

        def _parse_mail(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        mail = _parse_mail(d.pop("mail"))

        def _parse_phone(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        phone = _parse_phone(d.pop("phone"))

        def _parse_language(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        language = _parse_language(d.pop("language"))

        group_id = d.pop("groupId")

        auth_source = d.pop("authSource")

        def _parse_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        password = _parse_password(d.pop("password", UNSET))

        def _parse_last_connection(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_connection_type_0 = isoparse(data)

                return last_connection_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_connection = _parse_last_connection(d.pop("lastConnection", UNSET))

        def _parse_group_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        group_name = _parse_group_name(d.pop("groupName", UNSET))

        def _parse_roles(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                roles_type_0 = cast(list[str], data)

                return roles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        roles = _parse_roles(d.pop("roles", UNSET))

        def _parse_user_config(data: object) -> None | Unset | UserConfig:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                user_config_type_1 = UserConfig.from_dict(data)

                return user_config_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UserConfig, data)

        user_config = _parse_user_config(d.pop("userConfig", UNSET))

        def _parse_tenant(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tenant = _parse_tenant(d.pop("tenant", UNSET))

        def _parse_tenant_actual(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tenant_actual = _parse_tenant_actual(d.pop("tenantActual", UNSET))

        def _parse_tenants(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tenants_type_0 = cast(list[str], data)

                return tenants_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tenants = _parse_tenants(d.pop("tenants", UNSET))

        user = cls(
            id=id,
            user_id=user_id,
            login=login,
            first_name=first_name,
            last_name=last_name,
            mail=mail,
            phone=phone,
            language=language,
            group_id=group_id,
            auth_source=auth_source,
            password=password,
            last_connection=last_connection,
            group_name=group_name,
            roles=roles,
            user_config=user_config,
            tenant=tenant,
            tenant_actual=tenant_actual,
            tenants=tenants,
        )

        return user
