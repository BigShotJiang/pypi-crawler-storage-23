from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ElementModificationPreview")


@_attrs_define
class ElementModificationPreview:
    """
    Attributes:
        new_value (str): New value to set for this element attribute
        equipment_path (str): Full hierarchical path of the equipment
        equ_id (int): Equipment identifier
        table_name (str): Table/element type name (e.g., 'Alarm', 'Data', 'Config', 'Control', 'Description')
        attribute_name (str): Attribute name to modify (e.g., 'Value', 'SeverityType', 'SeverityLevel', 'Name')
        element_id (int): Element identifier within the equipment
        old_value (str): Original value before the proposed modification
        valid (bool): Indicates if the modification is valid and can be applied
        element_group (None | str | Unset): Element group name (used to identify the element along with subgroup and
            name)
        element_subgroup (None | str | Unset): Element subgroup name (used to identify the element along with group and
            name)
        element_name (None | str | Unset): Element name (used to identify the element along with group and subgroup)
    """

    new_value: str
    equipment_path: str
    equ_id: int
    table_name: str
    attribute_name: str
    element_id: int
    old_value: str
    valid: bool
    element_group: None | str | Unset = UNSET
    element_subgroup: None | str | Unset = UNSET
    element_name: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        new_value = self.new_value

        equipment_path = self.equipment_path

        equ_id = self.equ_id

        table_name = self.table_name

        attribute_name = self.attribute_name

        element_id = self.element_id

        old_value = self.old_value

        valid = self.valid

        element_group: None | str | Unset
        if isinstance(self.element_group, Unset):
            element_group = UNSET
        else:
            element_group = self.element_group

        element_subgroup: None | str | Unset
        if isinstance(self.element_subgroup, Unset):
            element_subgroup = UNSET
        else:
            element_subgroup = self.element_subgroup

        element_name: None | str | Unset
        if isinstance(self.element_name, Unset):
            element_name = UNSET
        else:
            element_name = self.element_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "newValue": new_value,
                "equipmentPath": equipment_path,
                "equId": equ_id,
                "tableName": table_name,
                "attributeName": attribute_name,
                "elementId": element_id,
                "oldValue": old_value,
                "valid": valid,
            }
        )
        if element_group is not UNSET:
            field_dict["elementGroup"] = element_group
        if element_subgroup is not UNSET:
            field_dict["elementSubgroup"] = element_subgroup
        if element_name is not UNSET:
            field_dict["elementName"] = element_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        new_value = d.pop("newValue")

        equipment_path = d.pop("equipmentPath")

        equ_id = d.pop("equId")

        table_name = d.pop("tableName")

        attribute_name = d.pop("attributeName")

        element_id = d.pop("elementId")

        old_value = d.pop("oldValue")

        valid = d.pop("valid")

        def _parse_element_group(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        element_group = _parse_element_group(d.pop("elementGroup", UNSET))

        def _parse_element_subgroup(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        element_subgroup = _parse_element_subgroup(d.pop("elementSubgroup", UNSET))

        def _parse_element_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        element_name = _parse_element_name(d.pop("elementName", UNSET))

        element_modification_preview = cls(
            new_value=new_value,
            equipment_path=equipment_path,
            equ_id=equ_id,
            table_name=table_name,
            attribute_name=attribute_name,
            element_id=element_id,
            old_value=old_value,
            valid=valid,
            element_group=element_group,
            element_subgroup=element_subgroup,
            element_name=element_name,
        )

        return element_modification_preview
