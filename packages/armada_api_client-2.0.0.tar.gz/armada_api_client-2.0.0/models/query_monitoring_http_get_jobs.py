from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.e_order import EOrder
from ..types import UNSET, Unset

T = TypeVar("T", bound="QueryMonitoringHttpGetJobs")


@_attrs_define
class QueryMonitoringHttpGetJobs:
    """
    Attributes:
        id (list[str] | None | Unset): Filter by unique identifiers. Format depends on the object type (e.g., equipment:
            integer, element: 'equId_elemId')
        start (int | None | Unset): Pagination: starting index (0-based)
        end (int | None | Unset): Pagination: ending index (exclusive)
        order (EOrder | None | Unset): Sort order direction (ASC or DESC)
        sort (None | str | Unset): Field name(s) to sort by. Can be comma-separated for multiple sort fields
        q (None | str | Unset): Text search query - searches across multiple fields depending on the object type
        gt_modified_date_time (datetime.datetime | None | Unset): Filter objects modified after this datetime (ISO-8601
            format)
        lt_modified_date_time (datetime.datetime | None | Unset): Filter objects modified before this datetime (ISO-8601
            format)
        gt_created_date_time (datetime.datetime | None | Unset): Filter objects created after this datetime (ISO-8601
            format)
        lt_created_date_time (datetime.datetime | None | Unset): Filter objects created before this datetime (ISO-8601
            format)
        fields (list[str] | None | Unset): Include optional objects in the response object (depends on the object).
            Examples for an element: 'Equipment' will include the related equipment object. Other useful examples:
            Equipment.Location, Equipment.MonitoringStatus, Audit. For monitoring level: Location, Equipments, Audit
        loc_country (None | str | Unset): Filter by site location country
        loc_region (None | str | Unset): Filter by site location region
        loc_province (None | str | Unset): Filter by site location province/state
        loc_city (None | str | Unset): Filter by site location city
        loc_group_1 (None | str | Unset): Filter by site location custom group 1
        loc_group_2 (None | str | Unset): Filter by site location custom group 2
        loc_group_3 (None | str | Unset): Filter by site location custom group 3
        loc_group_4 (None | str | Unset): Filter by site location custom group 4
        loc_group_5 (None | str | Unset): Filter by site location custom group 5
        loc_name (None | str | Unset): Filter by site location name
        loc_info (None | str | Unset): Filter by site location info/description
        loc_type (int | None | Unset): Filter by site location type
        q_loc (None | str | Unset): Text search across all location fields (name, country, city, etc.)
        mon_connection_status (None | str | Unset): Filter by monitoring connection status
        mon_type (None | str | Unset): Filter by monitoring type
        mon_ip_address (None | str | Unset): Filter by exact ip address, or MQTT(****) identifier. This allows to find
            Armada generated Monitoring Id with a unique reference
        monitoring_id (list[int] | None | Unset): Filter with a list of exact Monitoring Id
        mon_status (None | str | Unset): Filter by monitoring site level status
        status (None | str | Unset):
    """

    id: list[str] | None | Unset = UNSET
    start: int | None | Unset = UNSET
    end: int | None | Unset = UNSET
    order: EOrder | None | Unset = UNSET
    sort: None | str | Unset = UNSET
    q: None | str | Unset = UNSET
    gt_modified_date_time: datetime.datetime | None | Unset = UNSET
    lt_modified_date_time: datetime.datetime | None | Unset = UNSET
    gt_created_date_time: datetime.datetime | None | Unset = UNSET
    lt_created_date_time: datetime.datetime | None | Unset = UNSET
    fields: list[str] | None | Unset = UNSET
    loc_country: None | str | Unset = UNSET
    loc_region: None | str | Unset = UNSET
    loc_province: None | str | Unset = UNSET
    loc_city: None | str | Unset = UNSET
    loc_group_1: None | str | Unset = UNSET
    loc_group_2: None | str | Unset = UNSET
    loc_group_3: None | str | Unset = UNSET
    loc_group_4: None | str | Unset = UNSET
    loc_group_5: None | str | Unset = UNSET
    loc_name: None | str | Unset = UNSET
    loc_info: None | str | Unset = UNSET
    loc_type: int | None | Unset = UNSET
    q_loc: None | str | Unset = UNSET
    mon_connection_status: None | str | Unset = UNSET
    mon_type: None | str | Unset = UNSET
    mon_ip_address: None | str | Unset = UNSET
    monitoring_id: list[int] | None | Unset = UNSET
    mon_status: None | str | Unset = UNSET
    status: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        id: list[str] | None | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        elif isinstance(self.id, list):
            id = self.id

        else:
            id = self.id

        start: int | None | Unset
        if isinstance(self.start, Unset):
            start = UNSET
        else:
            start = self.start

        end: int | None | Unset
        if isinstance(self.end, Unset):
            end = UNSET
        else:
            end = self.end

        order: None | str | Unset
        if isinstance(self.order, Unset):
            order = UNSET
        elif isinstance(self.order, EOrder):
            order = self.order.value
        else:
            order = self.order

        sort: None | str | Unset
        if isinstance(self.sort, Unset):
            sort = UNSET
        else:
            sort = self.sort

        q: None | str | Unset
        if isinstance(self.q, Unset):
            q = UNSET
        else:
            q = self.q

        gt_modified_date_time: None | str | Unset
        if isinstance(self.gt_modified_date_time, Unset):
            gt_modified_date_time = UNSET
        elif isinstance(self.gt_modified_date_time, datetime.datetime):
            gt_modified_date_time = self.gt_modified_date_time.isoformat()
        else:
            gt_modified_date_time = self.gt_modified_date_time

        lt_modified_date_time: None | str | Unset
        if isinstance(self.lt_modified_date_time, Unset):
            lt_modified_date_time = UNSET
        elif isinstance(self.lt_modified_date_time, datetime.datetime):
            lt_modified_date_time = self.lt_modified_date_time.isoformat()
        else:
            lt_modified_date_time = self.lt_modified_date_time

        gt_created_date_time: None | str | Unset
        if isinstance(self.gt_created_date_time, Unset):
            gt_created_date_time = UNSET
        elif isinstance(self.gt_created_date_time, datetime.datetime):
            gt_created_date_time = self.gt_created_date_time.isoformat()
        else:
            gt_created_date_time = self.gt_created_date_time

        lt_created_date_time: None | str | Unset
        if isinstance(self.lt_created_date_time, Unset):
            lt_created_date_time = UNSET
        elif isinstance(self.lt_created_date_time, datetime.datetime):
            lt_created_date_time = self.lt_created_date_time.isoformat()
        else:
            lt_created_date_time = self.lt_created_date_time

        fields: list[str] | None | Unset
        if isinstance(self.fields, Unset):
            fields = UNSET
        elif isinstance(self.fields, list):
            fields = self.fields

        else:
            fields = self.fields

        loc_country: None | str | Unset
        if isinstance(self.loc_country, Unset):
            loc_country = UNSET
        else:
            loc_country = self.loc_country

        loc_region: None | str | Unset
        if isinstance(self.loc_region, Unset):
            loc_region = UNSET
        else:
            loc_region = self.loc_region

        loc_province: None | str | Unset
        if isinstance(self.loc_province, Unset):
            loc_province = UNSET
        else:
            loc_province = self.loc_province

        loc_city: None | str | Unset
        if isinstance(self.loc_city, Unset):
            loc_city = UNSET
        else:
            loc_city = self.loc_city

        loc_group_1: None | str | Unset
        if isinstance(self.loc_group_1, Unset):
            loc_group_1 = UNSET
        else:
            loc_group_1 = self.loc_group_1

        loc_group_2: None | str | Unset
        if isinstance(self.loc_group_2, Unset):
            loc_group_2 = UNSET
        else:
            loc_group_2 = self.loc_group_2

        loc_group_3: None | str | Unset
        if isinstance(self.loc_group_3, Unset):
            loc_group_3 = UNSET
        else:
            loc_group_3 = self.loc_group_3

        loc_group_4: None | str | Unset
        if isinstance(self.loc_group_4, Unset):
            loc_group_4 = UNSET
        else:
            loc_group_4 = self.loc_group_4

        loc_group_5: None | str | Unset
        if isinstance(self.loc_group_5, Unset):
            loc_group_5 = UNSET
        else:
            loc_group_5 = self.loc_group_5

        loc_name: None | str | Unset
        if isinstance(self.loc_name, Unset):
            loc_name = UNSET
        else:
            loc_name = self.loc_name

        loc_info: None | str | Unset
        if isinstance(self.loc_info, Unset):
            loc_info = UNSET
        else:
            loc_info = self.loc_info

        loc_type: int | None | Unset
        if isinstance(self.loc_type, Unset):
            loc_type = UNSET
        else:
            loc_type = self.loc_type

        q_loc: None | str | Unset
        if isinstance(self.q_loc, Unset):
            q_loc = UNSET
        else:
            q_loc = self.q_loc

        mon_connection_status: None | str | Unset
        if isinstance(self.mon_connection_status, Unset):
            mon_connection_status = UNSET
        else:
            mon_connection_status = self.mon_connection_status

        mon_type: None | str | Unset
        if isinstance(self.mon_type, Unset):
            mon_type = UNSET
        else:
            mon_type = self.mon_type

        mon_ip_address: None | str | Unset
        if isinstance(self.mon_ip_address, Unset):
            mon_ip_address = UNSET
        else:
            mon_ip_address = self.mon_ip_address

        monitoring_id: list[int] | None | Unset
        if isinstance(self.monitoring_id, Unset):
            monitoring_id = UNSET
        elif isinstance(self.monitoring_id, list):
            monitoring_id = self.monitoring_id

        else:
            monitoring_id = self.monitoring_id

        mon_status: None | str | Unset
        if isinstance(self.mon_status, Unset):
            mon_status = UNSET
        else:
            mon_status = self.mon_status

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        else:
            status = self.status

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if start is not UNSET:
            field_dict["start"] = start
        if end is not UNSET:
            field_dict["end"] = end
        if order is not UNSET:
            field_dict["order"] = order
        if sort is not UNSET:
            field_dict["sort"] = sort
        if q is not UNSET:
            field_dict["q"] = q
        if gt_modified_date_time is not UNSET:
            field_dict["gtModifiedDateTime"] = gt_modified_date_time
        if lt_modified_date_time is not UNSET:
            field_dict["ltModifiedDateTime"] = lt_modified_date_time
        if gt_created_date_time is not UNSET:
            field_dict["gtCreatedDateTime"] = gt_created_date_time
        if lt_created_date_time is not UNSET:
            field_dict["ltCreatedDateTime"] = lt_created_date_time
        if fields is not UNSET:
            field_dict["fields"] = fields
        if loc_country is not UNSET:
            field_dict["locCountry"] = loc_country
        if loc_region is not UNSET:
            field_dict["locRegion"] = loc_region
        if loc_province is not UNSET:
            field_dict["locProvince"] = loc_province
        if loc_city is not UNSET:
            field_dict["locCity"] = loc_city
        if loc_group_1 is not UNSET:
            field_dict["locGroup1"] = loc_group_1
        if loc_group_2 is not UNSET:
            field_dict["locGroup2"] = loc_group_2
        if loc_group_3 is not UNSET:
            field_dict["locGroup3"] = loc_group_3
        if loc_group_4 is not UNSET:
            field_dict["locGroup4"] = loc_group_4
        if loc_group_5 is not UNSET:
            field_dict["locGroup5"] = loc_group_5
        if loc_name is not UNSET:
            field_dict["locName"] = loc_name
        if loc_info is not UNSET:
            field_dict["locInfo"] = loc_info
        if loc_type is not UNSET:
            field_dict["locType"] = loc_type
        if q_loc is not UNSET:
            field_dict["qLoc"] = q_loc
        if mon_connection_status is not UNSET:
            field_dict["monConnectionStatus"] = mon_connection_status
        if mon_type is not UNSET:
            field_dict["monType"] = mon_type
        if mon_ip_address is not UNSET:
            field_dict["monIpAddress"] = mon_ip_address
        if monitoring_id is not UNSET:
            field_dict["monitoringId"] = monitoring_id
        if mon_status is not UNSET:
            field_dict["monStatus"] = mon_status
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_id(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                id_type_0 = cast(list[str], data)

                return id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_start(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        start = _parse_start(d.pop("start", UNSET))

        def _parse_end(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        end = _parse_end(d.pop("end", UNSET))

        def _parse_order(data: object) -> EOrder | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                order_type_1 = EOrder(data)

                return order_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EOrder | None | Unset, data)

        order = _parse_order(d.pop("order", UNSET))

        def _parse_sort(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sort = _parse_sort(d.pop("sort", UNSET))

        def _parse_q(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        q = _parse_q(d.pop("q", UNSET))

        def _parse_gt_modified_date_time(
            data: object,
        ) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                gt_modified_date_time_type_0 = isoparse(data)

                return gt_modified_date_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        gt_modified_date_time = _parse_gt_modified_date_time(
            d.pop("gtModifiedDateTime", UNSET)
        )

        def _parse_lt_modified_date_time(
            data: object,
        ) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                lt_modified_date_time_type_0 = isoparse(data)

                return lt_modified_date_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        lt_modified_date_time = _parse_lt_modified_date_time(
            d.pop("ltModifiedDateTime", UNSET)
        )

        def _parse_gt_created_date_time(
            data: object,
        ) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                gt_created_date_time_type_0 = isoparse(data)

                return gt_created_date_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        gt_created_date_time = _parse_gt_created_date_time(
            d.pop("gtCreatedDateTime", UNSET)
        )

        def _parse_lt_created_date_time(
            data: object,
        ) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                lt_created_date_time_type_0 = isoparse(data)

                return lt_created_date_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        lt_created_date_time = _parse_lt_created_date_time(
            d.pop("ltCreatedDateTime", UNSET)
        )

        def _parse_fields(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                fields_type_0 = cast(list[str], data)

                return fields_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        fields = _parse_fields(d.pop("fields", UNSET))

        def _parse_loc_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_country = _parse_loc_country(d.pop("locCountry", UNSET))

        def _parse_loc_region(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_region = _parse_loc_region(d.pop("locRegion", UNSET))

        def _parse_loc_province(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_province = _parse_loc_province(d.pop("locProvince", UNSET))

        def _parse_loc_city(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_city = _parse_loc_city(d.pop("locCity", UNSET))

        def _parse_loc_group_1(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_group_1 = _parse_loc_group_1(d.pop("locGroup1", UNSET))

        def _parse_loc_group_2(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_group_2 = _parse_loc_group_2(d.pop("locGroup2", UNSET))

        def _parse_loc_group_3(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_group_3 = _parse_loc_group_3(d.pop("locGroup3", UNSET))

        def _parse_loc_group_4(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_group_4 = _parse_loc_group_4(d.pop("locGroup4", UNSET))

        def _parse_loc_group_5(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_group_5 = _parse_loc_group_5(d.pop("locGroup5", UNSET))

        def _parse_loc_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_name = _parse_loc_name(d.pop("locName", UNSET))

        def _parse_loc_info(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        loc_info = _parse_loc_info(d.pop("locInfo", UNSET))

        def _parse_loc_type(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        loc_type = _parse_loc_type(d.pop("locType", UNSET))

        def _parse_q_loc(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        q_loc = _parse_q_loc(d.pop("qLoc", UNSET))

        def _parse_mon_connection_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mon_connection_status = _parse_mon_connection_status(
            d.pop("monConnectionStatus", UNSET)
        )

        def _parse_mon_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mon_type = _parse_mon_type(d.pop("monType", UNSET))

        def _parse_mon_ip_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mon_ip_address = _parse_mon_ip_address(d.pop("monIpAddress", UNSET))

        def _parse_monitoring_id(data: object) -> list[int] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                monitoring_id_type_0 = cast(list[int], data)

                return monitoring_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[int] | None | Unset, data)

        monitoring_id = _parse_monitoring_id(d.pop("monitoringId", UNSET))

        def _parse_mon_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mon_status = _parse_mon_status(d.pop("monStatus", UNSET))

        def _parse_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        query_monitoring_http_get_jobs = cls(
            id=id,
            start=start,
            end=end,
            order=order,
            sort=sort,
            q=q,
            gt_modified_date_time=gt_modified_date_time,
            lt_modified_date_time=lt_modified_date_time,
            gt_created_date_time=gt_created_date_time,
            lt_created_date_time=lt_created_date_time,
            fields=fields,
            loc_country=loc_country,
            loc_region=loc_region,
            loc_province=loc_province,
            loc_city=loc_city,
            loc_group_1=loc_group_1,
            loc_group_2=loc_group_2,
            loc_group_3=loc_group_3,
            loc_group_4=loc_group_4,
            loc_group_5=loc_group_5,
            loc_name=loc_name,
            loc_info=loc_info,
            loc_type=loc_type,
            q_loc=q_loc,
            mon_connection_status=mon_connection_status,
            mon_type=mon_type,
            mon_ip_address=mon_ip_address,
            monitoring_id=monitoring_id,
            mon_status=mon_status,
            status=status,
        )

        return query_monitoring_http_get_jobs
