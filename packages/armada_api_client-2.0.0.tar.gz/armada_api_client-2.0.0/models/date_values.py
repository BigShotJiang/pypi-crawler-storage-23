from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="DateValues")


@_attrs_define
class DateValues:
    """
    Attributes:
        t (datetime.datetime): Timestamp for this data point (ISO-8601 format)
        v (list[float] | None): Array of values, one for each metric in the headers list
    """

    t: datetime.datetime
    v: list[float] | None

    def to_dict(self) -> dict[str, Any]:
        t = self.t.isoformat()

        v: list[float] | None
        if isinstance(self.v, list):
            v = self.v

        else:
            v = self.v

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "t": t,
                "v": v,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        t = isoparse(d.pop("t"))

        def _parse_v(data: object) -> list[float] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                v_type_0 = cast(list[float], data)

                return v_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[float] | None, data)

        v = _parse_v(d.pop("v"))

        date_values = cls(
            t=t,
            v=v,
        )

        return date_values
