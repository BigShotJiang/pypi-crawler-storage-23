from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="TenantRegistrationInfoDto")


@_attrs_define
class TenantRegistrationInfoDto:
    """
    Attributes:
        organization (None | str | Unset):
        admin_email (None | str | Unset):
        admin_password (None | str | Unset):
        admin_first_name (None | str | Unset):
        admin_last_name (None | str | Unset):
        frontend_theme (None | str | Unset):
        delegated_access_partner (None | str | Unset):
    """

    organization: None | str | Unset = UNSET
    admin_email: None | str | Unset = UNSET
    admin_password: None | str | Unset = UNSET
    admin_first_name: None | str | Unset = UNSET
    admin_last_name: None | str | Unset = UNSET
    frontend_theme: None | str | Unset = UNSET
    delegated_access_partner: None | str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        organization: None | str | Unset
        if isinstance(self.organization, Unset):
            organization = UNSET
        else:
            organization = self.organization

        admin_email: None | str | Unset
        if isinstance(self.admin_email, Unset):
            admin_email = UNSET
        else:
            admin_email = self.admin_email

        admin_password: None | str | Unset
        if isinstance(self.admin_password, Unset):
            admin_password = UNSET
        else:
            admin_password = self.admin_password

        admin_first_name: None | str | Unset
        if isinstance(self.admin_first_name, Unset):
            admin_first_name = UNSET
        else:
            admin_first_name = self.admin_first_name

        admin_last_name: None | str | Unset
        if isinstance(self.admin_last_name, Unset):
            admin_last_name = UNSET
        else:
            admin_last_name = self.admin_last_name

        frontend_theme: None | str | Unset
        if isinstance(self.frontend_theme, Unset):
            frontend_theme = UNSET
        else:
            frontend_theme = self.frontend_theme

        delegated_access_partner: None | str | Unset
        if isinstance(self.delegated_access_partner, Unset):
            delegated_access_partner = UNSET
        else:
            delegated_access_partner = self.delegated_access_partner

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if organization is not UNSET:
            field_dict["organization"] = organization
        if admin_email is not UNSET:
            field_dict["adminEmail"] = admin_email
        if admin_password is not UNSET:
            field_dict["adminPassword"] = admin_password
        if admin_first_name is not UNSET:
            field_dict["adminFirstName"] = admin_first_name
        if admin_last_name is not UNSET:
            field_dict["adminLastName"] = admin_last_name
        if frontend_theme is not UNSET:
            field_dict["frontendTheme"] = frontend_theme
        if delegated_access_partner is not UNSET:
            field_dict["delegatedAccessPartner"] = delegated_access_partner

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_organization(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        organization = _parse_organization(d.pop("organization", UNSET))

        def _parse_admin_email(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        admin_email = _parse_admin_email(d.pop("adminEmail", UNSET))

        def _parse_admin_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        admin_password = _parse_admin_password(d.pop("adminPassword", UNSET))

        def _parse_admin_first_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        admin_first_name = _parse_admin_first_name(d.pop("adminFirstName", UNSET))

        def _parse_admin_last_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        admin_last_name = _parse_admin_last_name(d.pop("adminLastName", UNSET))

        def _parse_frontend_theme(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        frontend_theme = _parse_frontend_theme(d.pop("frontendTheme", UNSET))

        def _parse_delegated_access_partner(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        delegated_access_partner = _parse_delegated_access_partner(
            d.pop("delegatedAccessPartner", UNSET)
        )

        tenant_registration_info_dto = cls(
            organization=organization,
            admin_email=admin_email,
            admin_password=admin_password,
            admin_first_name=admin_first_name,
            admin_last_name=admin_last_name,
            frontend_theme=frontend_theme,
            delegated_access_partner=delegated_access_partner,
        )

        return tenant_registration_info_dto
