from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_date import AuditDate
    from ..models.equipment import Equipment


T = TypeVar("T", bound="ControlElement")


@_attrs_define
class ControlElement:
    """
    Attributes:
        equ_id (int): Equipment identifier that this element belongs to
        name (str): Element name (e.g., 'Battery Voltage', 'Door Open')
        group (str): Element group for categorization (e.g., 'Battery', 'Environment', 'System')
        sub_group (str): Element subgroup for further categorization
        id (str): Unique identifier combining equipment ID and control ID (format: 'equId_controlId')
        control_id (int): Control identifier (unique within an equipment)
        value (str): Control setpoint value that can be written to the device
        unit (str): Unit of measurement for the control (e.g., 'V', 'A', '°C')
        audit (AuditDate | None | Unset): Audit information containing creation and modification dates (included only
            when 'Audit' is specified in the fields parameter)
        equipment (Equipment | None | Unset): Related equipment object (included only when 'Equipment' is specified in
            the fields parameter)
    """

    equ_id: int
    name: str
    group: str
    sub_group: str
    id: str
    control_id: int
    value: str
    unit: str
    audit: AuditDate | None | Unset = UNSET
    equipment: Equipment | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.audit_date import AuditDate
        from ..models.equipment import Equipment

        equ_id = self.equ_id

        name = self.name

        group = self.group

        sub_group = self.sub_group

        id = self.id

        control_id = self.control_id

        value = self.value

        unit = self.unit

        audit: dict[str, Any] | None | Unset
        if isinstance(self.audit, Unset):
            audit = UNSET
        elif isinstance(self.audit, AuditDate):
            audit = self.audit.to_dict()
        else:
            audit = self.audit

        equipment: dict[str, Any] | None | Unset
        if isinstance(self.equipment, Unset):
            equipment = UNSET
        elif isinstance(self.equipment, Equipment):
            equipment = self.equipment.to_dict()
        else:
            equipment = self.equipment

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "equId": equ_id,
                "name": name,
                "group": group,
                "subGroup": sub_group,
                "id": id,
                "controlId": control_id,
                "value": value,
                "unit": unit,
            }
        )
        if audit is not UNSET:
            field_dict["audit"] = audit
        if equipment is not UNSET:
            field_dict["equipment"] = equipment

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_date import AuditDate
        from ..models.equipment import Equipment

        d = dict(src_dict)
        equ_id = d.pop("equId")

        name = d.pop("name")

        group = d.pop("group")

        sub_group = d.pop("subGroup")

        id = d.pop("id")

        control_id = d.pop("controlId")

        value = d.pop("value")

        unit = d.pop("unit")

        def _parse_audit(data: object) -> AuditDate | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                audit_type_1 = AuditDate.from_dict(data)

                return audit_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AuditDate | None | Unset, data)

        audit = _parse_audit(d.pop("audit", UNSET))

        def _parse_equipment(data: object) -> Equipment | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                equipment_type_1 = Equipment.from_dict(data)

                return equipment_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(Equipment | None | Unset, data)

        equipment = _parse_equipment(d.pop("equipment", UNSET))

        control_element = cls(
            equ_id=equ_id,
            name=name,
            group=group,
            sub_group=sub_group,
            id=id,
            control_id=control_id,
            value=value,
            unit=unit,
            audit=audit,
            equipment=equipment,
        )

        return control_element
