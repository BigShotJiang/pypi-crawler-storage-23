from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.user_role import UserRole


T = TypeVar("T", bound="UserGroup")


@_attrs_define
class UserGroup:
    """
    Attributes:
        id (str): Unique user group identifier (string representation of GroupId)
        group_id (int): Group identifier (auto-generated unique ID)
        name (str): User group name (e.g., 'Administrators', 'Operators', 'Viewers')
        ldap_group (None | str | Unset): LDAP group name for external authentication integration (null if not using
            LDAP)
        user_roles (list[UserRole] | None | Unset): List of roles assigned to this group determining permissions
    """

    id: str
    group_id: int
    name: str
    ldap_group: None | str | Unset = UNSET
    user_roles: list[UserRole] | None | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        id = self.id

        group_id = self.group_id

        name = self.name

        ldap_group: None | str | Unset
        if isinstance(self.ldap_group, Unset):
            ldap_group = UNSET
        else:
            ldap_group = self.ldap_group

        user_roles: list[dict[str, Any]] | None | Unset
        if isinstance(self.user_roles, Unset):
            user_roles = UNSET
        elif isinstance(self.user_roles, list):
            user_roles = []
            for user_roles_type_0_item_data in self.user_roles:
                user_roles_type_0_item = user_roles_type_0_item_data.to_dict()
                user_roles.append(user_roles_type_0_item)

        else:
            user_roles = self.user_roles

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "id": id,
                "groupId": group_id,
                "name": name,
            }
        )
        if ldap_group is not UNSET:
            field_dict["ldapGroup"] = ldap_group
        if user_roles is not UNSET:
            field_dict["userRoles"] = user_roles

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.user_role import UserRole

        d = dict(src_dict)
        id = d.pop("id")

        group_id = d.pop("groupId")

        name = d.pop("name")

        def _parse_ldap_group(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ldap_group = _parse_ldap_group(d.pop("ldapGroup", UNSET))

        def _parse_user_roles(data: object) -> list[UserRole] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                user_roles_type_0 = []
                _user_roles_type_0 = data
                for user_roles_type_0_item_data in _user_roles_type_0:
                    user_roles_type_0_item = UserRole.from_dict(
                        user_roles_type_0_item_data
                    )

                    user_roles_type_0.append(user_roles_type_0_item)

                return user_roles_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[UserRole] | None | Unset, data)

        user_roles = _parse_user_roles(d.pop("userRoles", UNSET))

        user_group = cls(
            id=id,
            group_id=group_id,
            name=name,
            ldap_group=ldap_group,
            user_roles=user_roles,
        )

        return user_group
