from setuptools import setup, find_packages

setup(
    name="armada_api_client",
    version="2.0.0",
    packages=find_packages(),
    install_requires=[
        "httpx",
        "pydantic",
    ],
)