from fastapi_boot.tortoise_utils.decorator import (
    Select as Select,
    Update as Update,
    Insert as Insert,
    Delete as Delete,
    Sql as Sql,
)
