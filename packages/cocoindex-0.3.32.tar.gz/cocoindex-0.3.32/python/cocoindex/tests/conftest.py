import os

os.environ.setdefault("PYTHONASYNCIODEBUG", "1")
