# openapi-docs

Generate readable `DOCS.md` files from OpenAPI specs (JSON or YAML).

```bash
pip install openapi-docs
openapi-docs path/to/openapi.json -o DOCS.md
```
