#!/bin/bash
#sudo /usr/local/sbin/mount_share.sh $share_name $share_root
