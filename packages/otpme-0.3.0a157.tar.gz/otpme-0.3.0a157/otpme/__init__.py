# -*- coding: utf-8 -*-
# Copyright (C) 2014 the2nd <the2nd@otpme.org>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#import datetime
#now = datetime.datetime.now()

__project_name__ = "otpme"
#__project_url__ = "http://www.otpme.org"
#__copyright__ = "Copyright 2014-2024 the2nd <the2nd@otpme.org>"
#__project_description__ = "OTPme: A flexible One-Time-Password system."
#__author__ = "the2nd"
#__email__ = "the2nd@otpme.org"
#__credits__ = []
#__license__ = "GPLv3"
__version__ = "0.3.0a157"
#__status__ = "Development Status :: 3 - Alpha"
## In future versions :D
##__status__ = "Development Status :: 4 - Beta"
##__status__ = "Development Status :: 5 - Production/Stable"
#__pkg_name__ = __project_name__
#__maintainer__ = __author__
#__author_email__  = __email__
#__maintainer_email__  = __email__
#__release_date__ = f"{now.strftime('%d')}.{now.strftime('%m')}.{now.strftime('%y')}"
