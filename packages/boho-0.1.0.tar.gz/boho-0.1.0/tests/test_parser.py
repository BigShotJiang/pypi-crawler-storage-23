import pytest

from boho.parser import Parser
from boho.objects import Token, Tree


# ── Fixtures ──────────────────────────────────────────────


@pytest.fixture
def simple_instructions():
    """Grammar: statement -> "get" variable | "put" variable
                variable -> NAME"""
    return {
        '0': {'"get"': '1',
              '"put"': '2',
              'read': '3',
              'write': '3',
              'statement': '4'},
        '1': {'NAME': '5', 'variable': '6'},
        '2': {'NAME': '5', 'variable': '7'},
        '3': {'$': (1, 'statement')},
        '4': {'$': True},
        '5': {'$': (1, 'variable')},
        '6': {'$': (2, 'read')},
        '7': {'$': (2, 'write')}
    }


@pytest.fixture
def chain_instructions():
    """Grammar from examples/parser_example.py:
       start -> _statement
       _statement -> NAME "=" VALUE_
       VALUE_ -> NAME "=" VALUE_ | start"""
    return {
        '0': {
            'NAME': '1',
            '_statement': '2',
            'start': '3'
        },
        '1': {
            '"="': '4'
        },
        '2': {
            '$': (1, 'start')
        },
        '3': {
            '$': True
        },
        '4': {
            'NAME': '5',
            'VALUE_': '6',
            '_statement': '2',
            'start': '7'
        },
        '5': {
            '"="': '4',
            '$': (1, 'VALUE_')
        },
        '6': {
            '$': (3, '_statement')
        },
        '7': {
            '$': (1, 'VALUE_')
        }
    }


@pytest.fixture
def auxiliary_instructions():
    """Grammar with auxiliary nonterminal:
       list -> NAME _tail
       _tail -> "," NAME _tail | (epsilon)"""
    return {
        '0': {'NAME': '1', 'list': '5'},
        '1': {'","': '2', '$': (0, '_tail'), '_tail': '4'},
        '2': {'NAME': '3'},
        '3': {'","': '2', '$': (0, '_tail'), '_tail': '6'},
        '4': {'$': (2, 'list')},
        '5': {'$': True},
        '6': {'$': (3, '_tail')},
    }


# ── Basic parsing from examples/parser_example.py ─────────────────


class TestBasicParsing:

    def test_simple_parse(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [
            Token('"get"', 'get'),
            Token('NAME', 'x'),
        ]
        tree = parser(tokens)
        assert isinstance(tree, Tree)
        assert tree.name == 'statement'

    def test_simple_tree_structure(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [
            Token('"get"', 'get'),
            Token('NAME', 'x'),
        ]
        tree = parser(tokens)
        # statement -> read -> variable -> NAME
        assert tree.name == 'statement'
        assert len(tree) == 1
        read = tree[0]
        assert read.name == 'read'
        assert len(read) == 1
        var = read[0]
        assert var.name == 'variable'
        assert len(var) == 1
        assert var[0] == Token('NAME', 'x')

    def test_alternative_branch(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [
            Token('"put"', 'put'),
            Token('NAME', 'y'),
        ]
        tree = parser(tokens)
        assert tree.name == 'statement'
        write = tree[0]
        assert write.name == 'write'
        assert write[0].name == 'variable'

    def test_literal_terminals_removed(self, simple_instructions):
        """Terminals starting with " should be removed from tree."""
        parser = Parser(simple_instructions)
        tokens = [
            Token('"get"', 'get'),
            Token('NAME', 'x'),
        ]
        tree = parser(tokens)
        # "get" should not appear in the tree
        read = tree[0]
        # read has only variable, no literal terminal
        assert len(read) == 1
        assert read[0].name == 'variable'


# ── Chain example from examples/parser_example.py ──────────────────


class TestChainExample:

    def test_chain_parse(self, chain_instructions):
        parser = Parser(chain_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"="', '='),
            Token('NAME', 'b'),
            Token('"="', '='),
            Token('NAME', 'c'),
            Token('"="', '='),
            Token('NAME', 'd'),
        ]
        tree = parser(tokens)
        assert isinstance(tree, Tree)
        assert tree.name == 'start'

    def test_chain_single_assignment(self, chain_instructions):
        parser = Parser(chain_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"="', '='),
            Token('NAME', 'b'),
        ]
        tree = parser(tokens)
        assert tree.name == 'start'

    def test_chain_has_fake_terminal(self, chain_instructions):
        """VALUE_ is a fake terminal — it should become a Token."""
        parser = Parser(chain_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"="', '='),
            Token('NAME', 'b'),
        ]
        tree = parser(tokens)
        # start -> [NAME(a), VALUE_(b)]  (via flattened _statement)
        children = tree.children
        assert any(
            isinstance(c, Token) and c.name == 'VALUE_'
            for c in children
        )

    def test_chain_fake_terminal_value(self, chain_instructions):
        """The fake terminal VALUE_ should have concatenated value."""
        parser = Parser(chain_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"="', '='),
            Token('NAME', 'b'),
        ]
        tree = parser(tokens)
        value_token = [c for c in tree.children
                       if isinstance(c, Token) and c.name == 'VALUE_'][0]
        assert value_token.value == 'b'


# ── Auxiliary nonterminals (_lowercase) ────────────────────


class TestAuxiliaryNonterminals:

    def test_auxiliary_flattens_children(self, auxiliary_instructions):
        """Auxiliary nonterminals (starting with _lowercase) should
        have their children promoted into the parent node."""
        parser = Parser(auxiliary_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('","', ','),
            Token('NAME', 'b'),
            Token('","', ','),
            Token('NAME', 'c'),
        ]
        tree = parser(tokens)
        assert tree.name == 'list'
        # All NAMEs should be direct children of list (flattened)
        names = [c.value for c in tree.children if isinstance(c, Token)]
        assert names == ['a', 'b', 'c']

    def test_auxiliary_single_element(self, auxiliary_instructions):
        parser = Parser(auxiliary_instructions)
        tokens = [Token('NAME', 'only')]
        tree = parser(tokens)
        assert tree.name == 'list'
        assert len(tree) == 1
        assert tree[0] == Token('NAME', 'only')

    def test_auxiliary_two_elements(self, auxiliary_instructions):
        parser = Parser(auxiliary_instructions)
        tokens = [
            Token('NAME', 'x'),
            Token('","', ','),
            Token('NAME', 'y'),
        ]
        tree = parser(tokens)
        assert tree.name == 'list'
        assert len(tree) == 2
        assert tree[0].value == 'x'
        assert tree[1].value == 'y'


# ── Fake terminals (_Uppercase) ────────────────────────────


class TestFakeTerminals:

    def test_fake_terminal_merges_to_token(self):
        """Nonterminals starting with _Uppercase should become
        a single Token with concatenated values."""
        instructions = {
            '0': {'NAME': '1', 'PATH_': '2', 'result': '3'},
            '1': {'"."': '4'},
            '2': {'$': (1, 'result')},
            '3': {'$': True},
            '4': {'NAME': '5'},
            '5': {'$': (3, 'PATH_')},
        }
        parser = Parser(instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"."', '.'),
            Token('NAME', 'b'),
        ]
        tree = parser(tokens)
        assert tree.name == 'result'
        assert isinstance(tree[0], Token)
        assert tree[0].name == 'PATH_'
        # "." is literal (starts with ") so removed; children are NAME(a), NAME(b)
        assert tree[0].value == 'ab'

    def test_fake_terminal_single_child(self):
        """_Uppercase with single child still produces a token."""
        instructions = {
            '0': {'NUM': '1', 'NUM_': '2', 'result': '3'},
            '1': {'$': (1, 'NUM_')},
            '2': {'$': (1, 'result')},
            '3': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', '42')]
        tree = parser(tokens)
        assert tree.name == 'result'
        assert isinstance(tree[0], Token)
        assert tree[0].name == 'NUM_'
        assert tree[0].value == '42'

    def test_fake_terminal_from_chain(self, chain_instructions):
        """The chain example uses VALUE_ as a fake terminal."""
        parser = Parser(chain_instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('"="', '='),
            Token('NAME', 'b'),
            Token('"="', '='),
            Token('NAME', 'c'),
        ]
        tree = parser(tokens)
        # Find all VALUE_ tokens in the tree
        values = [c for c in tree.children
                  if isinstance(c, Token) and c.name == 'VALUE_']
        assert len(values) == 1


# ── Ignore terminals ──────────────────────────────────────


class TestIgnoreTerminals:

    def test_ignored_terminal_is_skipped(self):
        """Terminals listed under '' key should be silently skipped."""
        instructions = {
            '': ['SPACE'],
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [
            Token('SPACE', ' '),
            Token('NAME', 'x'),
            Token('SPACE', ' '),
        ]
        tree = parser(tokens)
        assert tree.name == 'result'
        assert tree[0] == Token('NAME', 'x')

    def test_ignored_between_valid_tokens(self):
        """Ignored terminals appearing between valid tokens."""
        instructions = {
            '': ['WS'],
            '0': {'NAME': '1', 'sum': '3'},
            '1': {'"+"': '2'},
            '2': {'NAME': '4'},
            '3': {'$': True},
            '4': {'$': (3, 'sum')},
        }
        parser = Parser(instructions)
        tokens = [
            Token('NAME', 'a'),
            Token('WS', ' '),  # Unexpected here but ignored
            Token('"+"', '+'),
            Token('NAME', 'b'),
        ]
        tree = parser(tokens)
        assert tree.name == 'sum'

    def test_non_ignored_unexpected_raises(self):
        """Unexpected terminals not in ignore list should raise."""
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [
            Token('SPACE', ' ', 0, 0),
            Token('NAME', 'x'),
        ]
        with pytest.raises(SyntaxError):
            parser(tokens)


# ── Default action (empty key in state) ───────────────────


class TestDefaultAction:

    def test_default_action_used_for_unknown_terminal(self):
        """Empty key '' in a state acts as fallback."""
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result'), '': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        # After NAME, the default '' action triggers reduce
        tokens = [Token('NAME', 'x')]
        tree = parser(tokens)
        assert tree.name == 'result'


# ── Start state ───────────────────────────────────────────


class TestStartState:

    def test_default_start_is_zero(self):
        """Parser should default to state '0'."""
        instructions = {
            '0': {'NUM': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        assert parser.start == '0'
        tokens = [Token('NUM', '5')]
        tree = parser(tokens)
        assert tree.name == 'result'

    def test_start_param_is_stored(self):
        """The start parameter is stored on the parser."""
        instructions = {
            '0': {'NUM': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions, start='custom')
        assert parser.start == 'custom'

    def test_custom_start_state(self):
        """Parser should begin in the specified start state."""
        instructions = {
            'begin': {'NUM': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions, start='begin')
        tokens = [Token('NUM', '42')]
        tree = parser(tokens)
        assert tree.name == 'result'
        assert tree[0] == Token('NUM', '42')


# ── Error handling ────────────────────────────────────────


class TestErrors:

    def test_unexpected_terminal_raises_syntax_error(self):
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', '5', 0, 0)]
        with pytest.raises(SyntaxError, match='Unexpected NUM'):
            parser(tokens)

    def test_error_shows_state(self):
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', '5', 0, 0)]
        with pytest.raises(SyntaxError, match='state 0'):
            parser(tokens)

    def test_error_shows_expected(self):
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', '5', 0, 0)]
        with pytest.raises(SyntaxError, match='Expected one of'):
            parser(tokens)

    def test_error_shows_line_number(self):
        """Error message shows line based on previously seen tokens."""
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'NAME': '3'},
            '2': {'$': True},
            '3': {'$': (2, 'result')},
        }
        parser = Parser(instructions)
        # First token is on line 0, second unexpected token on line 1
        tokens = [
            Token('NAME', 'ok', 0, 0),
            Token('NUM', 'bad', 1, 0),
        ]
        with pytest.raises(SyntaxError, match='line 1'):
            parser(tokens)

    def test_error_mid_parse(self, simple_instructions):
        """Error in the middle of parsing (after shifting)."""
        parser = Parser(simple_instructions)
        tokens = [
            Token('"get"', 'get'),
            Token('NUM', '5', 0, 4),
        ]
        with pytest.raises(SyntaxError, match='Unexpected NUM'):
            parser(tokens)

    def test_error_caret_position(self):
        """Error message should include caret pointing to error."""
        instructions = {
            '0': {'NAME': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', 'bad', 0, 0)]
        with pytest.raises(SyntaxError, match=r'\^'):
            parser(tokens)

    def test_error_excludes_empty_and_ignored_from_expected(self):
        """Expected list should not include '' key or ignored terminals."""
        instructions = {
            '': ['SPACE'],
            '0': {'NAME': '1', 'SPACE': '1', 'result': '2'},
            '1': {'$': (1, 'result')},
            '2': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NUM', 'x', 0, 0)]
        with pytest.raises(SyntaxError) as exc_info:
            parser(tokens)
        msg = str(exc_info.value)
        assert 'NAME' in msg
        # Ignored terminals should not appear in expected list
        assert 'SPACE' not in msg


# ── Reduce with zero length ──────────────────────────────


class TestZeroLengthReduce:

    def test_epsilon_reduce(self):
        """Reduce with length 0 creates an empty tree node."""
        instructions = {
            '0': {'NAME': '1', 'wrapper': '3'},
            '1': {'$': (0, 'empty'), 'empty': '2'},
            '2': {'$': (2, 'wrapper')},
            '3': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('NAME', 'x')]
        tree = parser(tokens)
        assert tree.name == 'wrapper'
        assert tree[0] == Token('NAME', 'x')
        # The empty nonterminal should have no children
        empty = tree[1]
        assert empty.name == 'empty'
        assert len(empty) == 0


# ── Tree iteration and indexing ──────────────────────────


class TestTreeAccess:

    def test_tree_iter(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens)
        children = list(tree)
        assert len(children) == 1

    def test_tree_getitem(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens)
        assert tree[0].name == 'read'

    def test_tree_len(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens)
        assert len(tree) == 1

    def test_tree_value(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'hello')]
        tree = parser(tokens)
        # tree.value concatenates all children values recursively
        assert 'hello' in tree.value

    def test_tree_pretty(self, simple_instructions):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens)
        pretty = tree.pretty()
        assert 'statement' in pretty
        assert 'read' in pretty
        assert 'NAME' in pretty


# ── Logging ──────────────────────────────────────────────


class TestLogging:

    def test_log_does_not_affect_result(self, simple_instructions, capsys):
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens, log=True)
        assert tree.name == 'statement'
        captured = capsys.readouterr()
        assert 'SYNTACTIC ANALYSIS' in captured.out
        assert 'SHIFT' in captured.out
        assert 'REDUCE' in captured.out


# ── Reusability ──────────────────────────────────────────


class TestReusability:

    def test_parser_can_be_called_multiple_times(self, simple_instructions):
        parser = Parser(simple_instructions)
        t1 = parser([Token('"get"', 'get'), Token('NAME', 'a')])
        t2 = parser([Token('"put"', 'put'), Token('NAME', 'b')])
        assert t1.name == 'statement'
        assert t2.name == 'statement'
        assert t1[0].name == 'read'
        assert t2[0].name == 'write'


# ── Literal terminals with different prefixes ─────────────


class TestLiteralPrefixes:

    def test_double_quote_literal_removed(self, simple_instructions):
        """Terminals starting with " are removed during reduce."""
        parser = Parser(simple_instructions)
        tokens = [Token('"get"', 'get'), Token('NAME', 'x')]
        tree = parser(tokens)
        read = tree[0]
        # "get" should be removed, only variable remains
        assert len(read) == 1
        assert read[0].name == 'variable'

    def test_single_quote_literal_removed(self):
        """Terminals starting with ' are also removed during reduce."""
        instructions = {
            '0': {"'kw'": '1', 'result': '2'},
            '1': {'NAME': '3', 'result': '4'},
            '2': {'$': True},
            '3': {'$': (1, 'result')},
            '4': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token("'kw'", 'kw'), Token('NAME', 'x')]
        tree = parser(tokens)
        # Outer result: reduce (1, 'result') at state 4 doesn't happen...
        # Let me trace: state 0, 'kw' -> '1'. state 1, NAME -> '3'.
        # state 3, $ -> (1, 'result') => Tree('result', [NAME(x)]).
        # goto states['1']['result'] = '4'. state 4, $ -> True.
        # return stack[1] = ?? No wait, stack is ['0', 'kw', '1', result_tree, '4']
        # True -> break, return stack[1] which is Token('kw').
        # That's wrong. Let me use a proper grammar.
        # Actually after reduce at state 3: stack = ['0', 'kw'_token, '1', Tree('result'), '4']
        # Then True -> return stack[1] = Token("'kw'", 'kw')
        # That's not what I want. Let me fix the grammar.
        assert True  # placeholder - tested properly below

    def test_single_quote_literal_removed_in_reduce(self):
        """Terminals starting with ' are filtered out during reduce."""
        instructions = {
            '0': {"'kw'": '1', 'result': '3'},
            '1': {'NAME': '2'},
            '2': {'$': (2, 'result')},
            '3': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token("'kw'", 'kw'), Token('NAME', 'x')]
        tree = parser(tokens)
        assert tree.name == 'result'
        # 'kw' literal should be filtered out
        assert len(tree) == 1
        assert tree[0] == Token('NAME', 'x')

    def test_slash_literal_removed_in_reduce(self):
        """Terminals starting with / are filtered out during reduce."""
        instructions = {
            '0': {'/re/': '1', 'result': '3'},
            '1': {'NAME': '2'},
            '2': {'$': (2, 'result')},
            '3': {'$': True},
        }
        parser = Parser(instructions)
        tokens = [Token('/re/', 're'), Token('NAME', 'x')]
        tree = parser(tokens)
        assert tree.name == 'result'
        # /re/ literal should be filtered out
        assert len(tree) == 1
        assert tree[0] == Token('NAME', 'x')
