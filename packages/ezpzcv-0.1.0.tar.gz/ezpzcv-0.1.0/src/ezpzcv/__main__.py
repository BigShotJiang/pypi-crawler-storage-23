"""Main entry point for the application."""

from .ezpzcv import cli_runner

if __name__ == "__main__":
    cli_runner()
