"""ezpzcv package initialization."""
