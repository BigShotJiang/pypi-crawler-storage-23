"""setup.py: Installation script."""
from setuptools import setup

setup()
