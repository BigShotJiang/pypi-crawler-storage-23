## [0.1.0] - 2026-03-03

### 🚀 Features

- Add initial pyproject, .python-version and lockfile
- *(aws_lighthouse)* Add CLI, auth, agent graph and infra tools
- *(agent)* Bypass approval for safe tools
- *(cli)* Add security findings table for public RDS instances
- *(inventory)* Add EC2, RDS, and S3 inventory tools
- Add security scan tool and integrate into CLI
- *(cli)* Add cost waste scanning and reporting
- Add memory checkpointer and thread config for persistent sessions
- *(cli)* Add rich UI components and default REPL loop
- *(lambda)* Add inventory tool and dashboard for Lambda functions
- *(cost-anomaly)* Add cost anomaly detection tool and CLI integration
- *(tagging)* Add tag compliance check tool and integrate into CLI
- *(iam)* Add over‑permissive IAM policy scanning tool
- *(cloudwatch)* Detect missing EC2 and RDS CloudWatch alarms
- *(remediation)* Add one‑click remediation UI and actions
- *(multi-region)* Add region-aware inventory tools and scanning
- *(ri_sp_coverage)* Add RI and Savings Plan coverage tool
- *(agent)* Add cost and security scan tools
- *(lambda)* Add alarm and tag compliance checks for Lambda
- *(security_scan)* Add IMDSv2 and EBS encryption checks
- *(cli)* Add --region option to scan a single AWS region
- *(security)* Add S3 default encryption check
- Add Lambda support to CloudWatch, tagging, and security scans
- *(agent)* Add OLLAMA_HOST env var to configure Ollama base URL
- *(docker)* Add Dockerfile, compose and .dockerignore
- *(remediation)* Add GuardDuty, CloudTrail, IMDSv2, S3 encryption
- *(tests)* Add remediation action tests and validation
- *(security)* Block sensitive file paths in read/write tools
- *(bash)* Add dangerous command detection and blocking
- *(auth)* Add adaptive retry config to boto3 clients
- *(docker)* Run container as non-root user
- *(ci)* Add dependency, container, and secret scanning
- *(agent)* Add user approval flag and conditional routing
- *(bash)* Add allowlist and shlex parsing for safer command execution
- *(cfn_deploy)* Add bucket hardening and switch to get_client
- *(tools)* Add blocked path validation to Terraform parsing
- *(auth)* Add client caching to reduce Boto3 client creation
- *(cloudwatch_scan)* Add paginator and alarm detection for EC2/RDS
- *(remediation)* Report per-volume deletion status
- *(security)* Block additional sensitive files and directories
- *(db)* Add audit_log table and record_audit_log method
- *(audit)* Log tool execution decisions in audit database
- *(db)* Implement audit log recording and add tests
- *(cli)* Add JSON output option and return section data
- *(types)* Add Severity literal and apply to finding typings

### 🐛 Bug Fixes

- *(cli)* Capture previous snapshot before saving
- *(db)* Tighten file permissions for database directory and file

### 💼 Other

- *(docker)* Pin images to digests for reproducible builds
- *(docker)* Copy README.md for hatchling wheel build

### 🚜 Refactor

- *(cfn_deploy)* Use authenticated session for AWS clients
- Improve formatting and readability across modules
- Add type hints and improve sorting in cost anomaly tool
- *(agent)* Reformat tool_execute_bash signature for readability
- *(tools)* Use paginators for AWS describe calls
- *(aws)* Handle specific botocore errors
- *(agent)* Defer Ollama init to runtime avoid import side-effects
- *(auth)* Add get_client and replace direct client calls
- *(types)* Add TypedDicts for findings and update return types
- *(cli)* Modularize analyze command, add region to findings
- *(mypy)* Remove ignore_errors override for cli module
- Modernize type hints and clean up imports across project
- *(tests)* Condense inline policy list literals
- *(auth)* Add thread‑safe double‑checked locking for session
- Rename get_aws_client to get_client across tools
- *(tests)* Replace get_aws_client with get_client in tests
- Add region param to AWS remediation funcs
- *(tools)* Narrow exception handling to specific errors
- *(db)* Add return type hints to DatabaseManager methods
- *(logger)* Add return type hints to logger methods

### 📚 Documentation

- Add project overview and usage guide in README
- *(readme)* Revamp README with detailed usage and install guide
- Update security checks and remediation actions in README
- *(tools)* Expand docstrings with detailed usage and region info
- Add comprehensive project metadata and stricter mypy settings
- *(readme)* Increase security checks to eleven and add considerations

### ⚡ Performance

- *(iam_scan)* Reduce IAM API calls by batching auth details
- *(cli)* Parallelize region scans to improve performance
- *(ri_sp_coverage)* Run CE calls in parallel to reduce latency
- *(security_scan)* Use credential report to reduce IAM API calls
- *(tagging)* Bulk-fetch Lambda tags to reduce API calls

### 🧪 Testing

- Add unit tests for cloudwatch, cost, and tagging tools
- *(lambda)* Add coverage for Lambda alarm gaps and tag compliance
- *(security_scan)* Add tests for IMDSv2 and EBS encryption checks
- *(security_scan)* Add comprehensive S3 encryption checks
- Add unit tests for cost, inventory and security scans
- *(agent)* Add comprehensive tests for approval gating and denial
- Refactor tests to use paginator helpers and add inventory tests
- *(bash)* Add comprehensive dangerous command detection tests
- Use ClientError for AWS API error mocks in scans
- *(agent)* Remove unnecessary sys.modules mock for langchain_ollama
- Replace get_aws_client with get_client in tests
- Adjust API error test to expect empty result
- Add comprehensive unit tests for auth, cli, and db
- *(auth)* Add tests for adaptive retry config forwarding
- Replace timezone.utc with datetime.UTC in test suite
- Add pytest-cov and pytest-timeout, configure coverage
- *(iam_scan)* Add extensive overpermissive IAM tests and mock helpers
- *(agent)* Add comprehensive approval routing tests
- *(bash)* Add comprehensive allowlist behavior tests
- Remove unused _ALLOWED_COMMANDS import
- *(cfn_deploy)* Add comprehensive unit tests for deploy_cur_template
- *(terraform)* Add comprehensive tests for parse_terraform_context
- *(auth)* Add concurrent session authentication test
- *(auth)* Add client caching tests and update get_client delegation
- Add paginator-based mocks and pagination regression tests
- *(ri_sp_coverage)* Add unit tests for fetchers and parallel execution
- *(security_scan)* Add credential report tests, refactor IAM checks
- *(tagging)* Use bulk tagging API for Lambda tags and pagination
- *(remediation)* Add unit tests for remediation functions
- *(remediation)* Verify region is passed to client calls
- Replace generic Exception with BotoCoreError in test suites
- *(cost)* Add comprehensive unit tests for monthly cost summary
- *(security)* Add unit tests for s3_block_public_access
- *(bash)* Add blocked path tests covering new patterns
- *(cli)* Add integration tests for JSON output

### ⚙️ Miscellaneous Tasks

- Add .gitignore
- Add GitHub Actions CI workflow
- *(mypy)* Add mypy config to ignore missing imports
- Reformat blocked path set and test assertions for readability
- *(mypy)* Suppress type errors for cli module
- *(lint)* Add ruff configuration to enforce lint rules
- *(dependabot)* Add weekly dependabot config for pip, docker, actions
- *(workflow)* Use pip-audit file export and upload Trivy SARIF results
- *(workflow)* Allow Trivy scan errors and guard SARIF upload
- Simplify Python dependency audit step
- Set Trivy action exit-code to 0 to avoid CI failure
- Add Trivy install step and use CLI for image scan
- Switch to Trivy GitHub Action for container scanning
- *(workflow)* Update Trivy action to v0.34.1
- Simplify CI pipeline and remove Docker build files
- *(workflows)* Add --no-hashes flag to uv export
- *(release)* Add GitHub Actions workflow for automated releases
- *(release)* Fix git-cliff version to v2.12.0 (v2.4.0 never existed)
- *(release)* Fix git-cliff download URL (v2.12.0, no v-prefix in filename)
