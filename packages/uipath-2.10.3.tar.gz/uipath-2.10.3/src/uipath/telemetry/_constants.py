_CONNECTION_STRING = "InstrumentationKey=962c4d0f-d70c-435f-9d9e-94f6837cbd42;IngestionEndpoint=https://northeurope-2.in.applicationinsights.azure.com/;LiveEndpoint=https://northeurope.livediagnostics.monitor.azure.com/;ApplicationId=9ed6a164-c041-461d-a0ff-c5652d2366a9"

_APP_INSIGHTS_EVENT_MARKER_ATTRIBUTE = "APPLICATION_INSIGHTS_EVENT_MARKER_ATTRIBUTE"
_OTEL_RESOURCE_ATTRIBUTES = "OTEL_RESOURCE_ATTRIBUTES"
_SDK_VERSION = "SdkVersion"
_PROJECT_KEY = "ProjectKey"

_TELEMETRY_CONFIG_FILE = ".telemetry.json"

_CODE_FILEPATH = "code.file.path"
_CODE_FUNCTION = "code.function.name"
_CODE_LINENO = "code.line.number"

_CLOUD_ORG_ID = "CloudOrganizationId"
_CLOUD_TENANT_ID = "CloudTenantId"
_CLOUD_URL = "CloudUrl"
_CLOUD_USER_ID = "CloudUserId"
_APP_NAME = "ApplicationName"

_UNKNOWN = ""
