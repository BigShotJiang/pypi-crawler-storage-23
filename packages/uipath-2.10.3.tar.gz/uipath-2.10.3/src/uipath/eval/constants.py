"""Constants used in the evaluation module."""

# Folder names
LEGACY_EVAL_FOLDER = "evals"
EVALS_FOLDER = "evaluations"

# Evaluators
CUSTOM_EVALUATOR_PREFIX = "file://"
