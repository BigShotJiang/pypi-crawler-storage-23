.. _tutorials:

=========
Tutorials
=========

Example calculations using ``radDefects`` will be provided in the future.

.. toctree::
    :maxdepth: 2

    GaN_radDefects_example
    GaN_cc_template