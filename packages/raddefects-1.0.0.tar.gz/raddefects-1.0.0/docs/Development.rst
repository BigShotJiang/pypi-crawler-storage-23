.. _development:

===================
Development (To-Do)
===================

--------------
radDefects WIP
--------------
* add verbose/debug option
* improve documentation

------
cli.py
------
* build out functionalities