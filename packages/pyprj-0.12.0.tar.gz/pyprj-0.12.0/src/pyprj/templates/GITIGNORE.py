GITIGNORE: str = """# Python-generated files
__pycache__/
*.py[oc]
build/
dist/
wheels/
*.egg-info

# Virtual environments
.venv

# Example folder in sphinx docs
doc/sphinx/source/notebooks/examples/
"""
