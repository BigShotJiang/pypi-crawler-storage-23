PYPRJ_JSON: str = """{
    "token": "",
    "published_versions": []
}"""
