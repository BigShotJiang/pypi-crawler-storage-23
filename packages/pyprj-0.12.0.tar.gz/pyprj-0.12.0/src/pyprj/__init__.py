from .ipython_magics import load_ipython_extension
