# Canvas MCP TODO

## High Priority

<!-- Add high priority items here -->

---

## Medium Priority

<!-- Add future items here -->

---

## Low Priority

<!-- Add future items here -->

---

## Completed

- **2026-01-25**: Added `update_assignment` tool - PUT /api/v1/courses/:course_id/assignments/:id
  - Parameters: course_identifier, assignment_id, name, description, submission_types, due_at, unlock_at, lock_at, points_possible, grading_type, published, assignment_group_id, peer_reviews, automatic_peer_reviews, allowed_extensions
