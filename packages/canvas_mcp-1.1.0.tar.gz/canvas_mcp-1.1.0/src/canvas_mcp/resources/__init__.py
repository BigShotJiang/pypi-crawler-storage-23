"""Resource modules for Canvas MCP server."""

from .resources import register_resources_and_prompts

__all__ = ['register_resources_and_prompts']
