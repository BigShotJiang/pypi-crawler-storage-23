# Changelog

All notable changes to `nimoh-be-django-base` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

_No unreleased changes._

---

## [0.2.2] — 2026-03-03

### Fixed

- **`requirements.txt.j2` missing `channels` extra** — when a project was generated with `use_channels=True`, the template emitted only a comment instead of `nimoh-be-django-base[channels]>=...`, causing `ModuleNotFoundError: No module named 'channels'` at Docker build time. The line now correctly renders the pip extra.

---

## [0.2.1] — 2026-02-22

### Fixed

- **`sessions.py` still imported `django_ratelimit`** — `list_sessions_view`, `terminate_session_view`, and `terminate_all_sessions_view` still used `@ratelimit` decorators after M6 was applied only to `password.py`. Replaced with `DeviceManagementRateThrottle` inline checks.

### Added

- **`docs/DEPLOYMENT.md`** — new guide covering nginx reverse-proxy config, `SECURE_PROXY_SSL_HEADER`, trusted proxy IP considerations, Let's Encrypt TLS cert setup, Gunicorn systemd unit, and a pre-launch checklist.
- **`_get_package_version()` fallback in `monitoring/views.py`** — `/api/v1/health/` now resolves the version via `importlib.metadata` when `APP_VERSION` is not set in Django settings, eliminating the `"unknown"` default.

### Changed

- **`register_view` / `login_view` docstrings merged** — each view had two separate docstrings (the second one after the throttle check was a dead string literal). Merged into a single canonical docstring; throttle imports moved to module level.
- **`CELERY_WORKER_PREFETCH_MULTIPLIER`** — added explanatory comment documenting why 1 is the safer default for variable-cost tasks.
- **`get_base_simple_jwt()` docstring** — documents when to switch to `RS256` with a ready-to-use override snippet.
- **`get_base_middleware()` comment** — clarifies why `SessionMiddleware` is retained even for JWT-only projects (`UserSession.session_key` tracking).
- **`PerformanceMonitoringMiddleware` health skip-list** — added `/api/v1/health/` alongside `/health/`, `/healthz/`, `/ready/` so the canonical endpoint is excluded from performance metrics.

### Removed / Fixed

- **`self.nonce_cache = {}`** removed from `SecurityHeadersMiddleware.__init__` — the dict was initialised but never written to (CSP nonces live on `request.csp_nonce` per-request).

---

## [0.2.0] — 2026-05-29

### Added

- **Auth view test suite** (`tests/test_auth_views.py`) — 11 integration tests covering register, login, token refresh, logout, and password reset endpoints using `pytest-django` and `APIClient`.
- **`ChangePasswordRateThrottle`** — new DRF throttle class in `core/throttling.py` with scope `change_password`, completing the unified throttle system for all auth endpoints.
- **`include_channels` / `include_otp` params on `get_base_apps()`** — callers can now exclude `channels` / `channels-redis` or `django_otp` / OTP plugins from `INSTALLED_APPS` by passing `include_channels=False` / `include_otp=False`.
- **Optional extras in `pyproject.toml`** — `[channels]`, `[sentry]`, `[monitoring]`, `[csp]`, `[cli]`, `[dev]`, `[all]` extras give consumers fine-grained control over installed dependencies.
- **Beta classifier** — `Development Status :: 4 - Beta`.

### Changed

- **`get_base_celery()` default `result_backend`** changed from `'django-db'` to `'redis://localhost:6379/2'`. Pass `result_backend='django-db'` explicitly to restore the old behaviour.
- **Password views** (`change_password_view`, `password_reset_request_view`, `PasswordResetConfirmView`) now use DRF throttle classes instead of `@ratelimit` decorators — eliminates the `django-ratelimit` dependency and provides a unified rate-limiting interface.
- **Response-level PII scrubbing disabled by default** — `SECURITY_SCRUB_PII` now defaults to `False`. The previous default of `True` caused `/api/v1/me/` to return `{"email": "[REDACTED]"}`. Log-level redaction via `SensitiveDataFilter` covers the primary threat model. Opt in with `SECURITY_SCRUB_PII=True`.

### Removed

- `django-csp`, `channels`, `channels-redis`, `sentry-sdk`, `structlog`, `psutil`, `django-ratelimit` removed from hard dependencies. Use the new optional extras where needed.

---

## [0.1.21] — 2026-02-22

### Added / Changed

- **Phase 2 — H1–H5 security hardening** — account lockout (`MAX_LOGIN_ATTEMPTS`, `ACCOUNT_LOCK_DURATION_MINUTES`), `PrivacyConsentRecord`, `PrivacySerializer`, `AuditLog` improvements, JWT `BLACKLIST_AFTER_ROTATION=True`, and `SensitiveDataFilter` integrated into `LOGGING`.

---

## [0.1.20] — 2026-02-22

### Fixed

- **Phase 1 — C1–C5 production-readiness fixes** — template bugs: corrected `get_base_apps()` channel/OTP app names, fixed scaffolded `CELERY_BROKER_URL` env var reference, fixed `CorsMiddleware` ordering, removed non-existent `nimoh_base.search` app reference, ensured `nimoh_base_urlpatterns()` is called in generated `urls.py`.

---

## [0.1.19] — 2026-02-21

### Fixed

- Added `HEALTH_CHECK_CELERY=false` to the `.env.example` template so new projects can immediately opt out of the Celery worker check during local development.

---

## [0.1.18] — 2026-02-21

### Fixed

- **Celery health check fast-fail** — `check_celery()` now returns `{"status": "degraded"}` (instead of raising an exception) when the broker is unreachable, preventing the health endpoint from returning `500`.
- **`HEALTH_CHECK_CELERY` opt-out flag** — set `NIMOH_BASE["HEALTH_CHECK_CELERY"] = False` to skip the Celery worker check in `/api/v1/health/`. Useful in environments where Celery is not deployed.

---

## [0.1.17] — 2026-02-20

### Style

- Formatted `conf/__init__.py` and `core/logging.py` with `ruff format` — no logic changes.

---

## [0.1.16] — 2026-02-20

### Fixed

- Resolved ruff lint errors in `core/logging.py`: `RUF002` (ambiguous unicode in docstring), `I001` (unsorted imports), `RUF100` (unused `# noqa`), `UP017` (`datetime.timezone.utc` → `datetime.UTC`).

---

## [0.1.15] — 2026-02-20

### Added

- **Structured logging** — three new log formatters in `core/logging.py`:
  - `DevConsoleFormatter` — coloured, human-readable output for local development.
  - `JsonFormatter` — structured JSON output for production log aggregators.
  - `SensitiveDataFilter` — `logging.Filter` that redacts email addresses, passwords, tokens, and credit card numbers from log records before they are emitted.
- `get_base_logging()` in `NimohBaseSettings` wires these formatters into the standard Django `LOGGING` dict.

---

## [0.1.14] — 2026-02-20

### Fixed

- Removed the `db` postgres service from the `docker-compose.yml` template — the database is expected to run on the host. Replaced all `db` hostname references in `DATABASE_URL` env vars with `host.docker.internal`.

---

## [0.1.13] — 2026-02-20

### Changed

- Version bump only.

---

## [0.1.12] — 2026-02-20

### Changed

- Version bump only.

---

## [0.1.11] — 2026-02-20

### Fixed

- **Docs URL alias renamed** — `api/v1/docs/` alias renamed to `api/v1/schema/docs/` for consistency with the `schema/` URL namespace.
- **COEP + font-src on docs pages** — resolved `Cross-Origin-Embedder-Policy` conflict with Swagger / ReDoc assets; added `https://fonts.googleapis.com` and `https://fonts.gstatic.com` to `font-src`.

---

## [0.1.10] — 2026-02-20

### Fixed

- Added `https://cdn.redoc.ly` to CSP `img-src` (ReDoc logo).
- Added `blob:` to `worker-src` for ReDoc's web worker.
- Added Google Fonts sources (`fonts.googleapis.com`, `fonts.gstatic.com`) to `font-src` for docs pages.

---

## [0.1.9] — 2026-02-20

### Fixed

- Removed dead `anonymize_recovery_data` field from `PrivacyProfileSerializer` (field had been removed from the model but the serializer still referenced it, causing a `FieldDoesNotExist` error on read).
- Fixed report-only CSP policy for API documentation pages.

---

## [0.1.8] — 2026-02-20

### Fixed

- **CSP `_is_api_documentation` versioned paths** — replaced hardcoded path list (`/api/docs`, `/api/schema`) with segment-based matching so `/api/v1/docs/`, `/api/v1/schema/swagger-ui/` etc. are correctly identified as documentation pages.
- Registered `csp-report` endpoint in `nimoh_base_urlpatterns()`.

---

## [0.1.7] — 2026-02-20

### Added

- **`api/v1/docs/` shortcut URL** — `nimoh_base_urlpatterns()` now registers a
  `api/v1/docs/` path (named `docs`) as a short, memorable alias for the
  Swagger UI. Previously the only way to reach the interactive API docs was
  via the verbose `api/v1/schema/swagger-ui/` URL.
- **Root `/` redirect in generated projects** — the scaffolded `config/urls.py`
  now includes a `DEBUG`-gated `RedirectView` that sends `GET /` →
  `/api/v1/docs/`, so opening the bare root URL in a browser during
  development lands directly on the API docs instead of a 404.

---

## [0.1.6] — 2026-02-20

### Fixed

- **`EnhancedUserAdmin` 500 error on `/admin/nimoh_auth/user/`** —
  `get_queryset()` called `.select_related("basic_profile")` but no such
  reverse relation exists on `User`. The only OneToOne relation is
  `privacy_profile` (from `PrivacyProfile`). Six more references to the
  non-existent `basic_profile` were scattered across `display_name_from_profile`,
  `profile_completion_status`, and `profile_info_summary` methods, all of which
  used it to access `display_name`, `bio`, and `timezone` fields that don't
  exist anywhere. Fixed by:
  - `get_queryset`: `select_related("basic_profile")` → `select_related("privacy_profile")`
  - `display_name_from_profile`: replaced with `obj.get_full_name() or obj.username`
  - `profile_completion_status`: now shows privacy consent percentages from `privacy_profile`
  - `profile_info_summary`: now shows consent + visibility info from `privacy_profile`
  - `search_fields`: replaced `basic_profile__display_name` / `basic_profile__bio` with
    `first_name` / `last_name` (fields that actually exist on `User`)
  - All broken `RelatedObjectDoesNotExist` exception handlers replaced with plain `AttributeError`

---

## [0.1.5] — 2026-02-20

### Fixed

- **CSRF 403 on every admin/form POST — two separate root causes:**
  1. `SecurityHeadersMiddleware._compile_pii_patterns()` contained a catch-all
     pattern (`[A-Za-z0-9]{20,}`) intended to redact session tokens from JSON
     API responses. Because `_scrub_response_pii()` also processed `text/html`
     responses, this pattern matched and replaced the 64-char CSRF token inside
     every rendered Django form with `[REDACTED]` (9 chars). Django's CSRF
     middleware then rejected the POST with *"CSRF token from POST has incorrect
     length"*. Fixed by:
     - Removing the over-broad long-alphanumeric and IP-address patterns from
       `_compile_pii_patterns()`.
     - Restricting `_scrub_response_pii()` to `application/json` and
       `application/xml` content types only (was also matching `text/*`).
  2. `set_response_cookies()` in `auth/utils/cookies.py` called
     `set_csrf_cookie()`, which unconditionally overwrote the `csrftoken`
     cookie with an empty string (`""`). This happened on every login response,
     clearing the valid token that `CsrfViewMiddleware` had just written.
     Fixed by removing the `set_csrf_cookie()` call — Django's middleware
     already manages that cookie correctly.

---

## [0.1.4] — 2026-02-20

### Fixed

- **`project_slug` empty in `--no-input` mode** — `load_config()` in `cli/config.py` now
  auto-derives `project_slug` from `project_name` when the field is absent or blank in the
  YAML config file. Previously, omitting `project_slug` from `init.yml` caused
  `INSTALLED_APPS` to contain an empty string (`''`), resulting in
  `ValueError: Empty module name` on `manage.py migrate`.
- **Celery Redis URL double path in `.env.example.j2`** — `CELERY_BROKER_URL` and
  `CELERY_RESULT_BACKEND` templates previously appended `/1` and `/2` directly to
  `{{ redis_url }}` (which already ends in a database index, e.g. `/0`), producing invalid
  URLs like `redis://localhost:6379/0/1`. Fixed to strip the trailing index before appending
  the correct one (e.g. `redis://localhost:6379/1`).

### Added

- **`docs/GETTING_STARTED.md`** — comprehensive step-by-step guide for creating a new
  project from scratch: prerequisites, install, scaffold, `.env` configuration, database
  setup, migrations, running the server, verifying endpoints, Celery setup, Docker Compose
  usage, and troubleshooting.

---

## [0.1.3] — 2026-02-20

### Fixed

- **`get_base_apps()`** — renamed kwargs `monitoring=` / `privacy=` / `channels=` to
  `include_monitoring=` / `include_privacy=` (dropped non-existent `channels=` parameter).
  Template `config/settings/base.py.j2` updated to match.
- **`get_base_spectacular_settings()`** — added `title`, `description`, and `version` parameters
  (template was already passing them; method now accepts and uses them).
- **`get_base_logging()`** — added `log_level` parameter; returned dict now includes a `loggers`
  section with `nimoh_base` and `django` sub-loggers (required by generated `development.py`).
- **`nimoh_base_urlpatterns()`** — renamed kwargs `monitoring=` / `privacy=` / `api_docs=` to
  `include_monitoring=` / `include_privacy=` / `include_schema=`.
  Template `config/urls.py.j2` updated to match.
- **`conf/urls.py`** — fixed import of health check view: was
  `from nimoh_base.core.health import health_check_view` (non-existent); corrected to
  `from nimoh_base.monitoring.views import health_check`.
- **Jinja2 boolean rendering** — replaced `{{ var | lower }}` (renders Python `True` as JSON
  `true`) with `{{ 'True' if var else 'False' }}` in `base.py.j2` and `urls.py.j2`.
- **`AUTH_USER_MODEL` in template** — was `'{{ project_slug }}.User'`; corrected to
  `'nimoh_auth.User'` (custom User model lives in the package, not the consumer project).
- **`read_env()` path** — template now resolves the project root via
  `pathlib.Path(__file__).resolve().parent.parent.parent` and passes it explicitly to
  `environ.Env.read_env()`. Fixes `django-environ ≥0.9` behaviour where `read_env()` without
  arguments looks in the caller's directory (`config/settings/`) instead of the project root.
- **Default `DATABASE_URL` in template** — replaced invalid `django.db.backends.postgresql://…`
  scheme with the correct `postgresql://…` scheme.
- **Celery broker / result-backend URLs** — template default was `env('REDIS_URL') + '/N'`,
  producing a double-path URL (`redis://localhost:6379/0/1`). Replaced with
  `_REDIS_BASE = env('REDIS_URL').rsplit('/', 1)[0]` to obtain the base URL, then appended `/1`
  and `/2` separately.
- **`SecurityHeadersMiddleware._apply_core_headers()`** — replaced `response.pop("Server", None)`
  (dict method, not available on `HttpResponse`) with a `del response["Server"]` guarded by
  `try / except KeyError`. Fixes `AttributeError: 'JsonResponse' object has no attribute 'pop'`
  on every request through the middleware.

---

## [0.1.2] — 2026-02-20

### Fixed

- **`auth.admin`** — replaced module-level `from apps.profiles.models import UserProfileBasic`
  and `from apps.profiles.admin import UserProfileBasicAdminForm` with a `_get_configured_profile_model()`
  helper using `NIMOH_BASE['PROFILE_MODEL']`. The `UserProfileBasicInline` is only registered if
  a profile model is configured; otherwise it is skipped gracefully.
- **`auth.admin.create_missing_profiles`** — replaced hardcoded `UserProfileBasic.objects` with
  the configured `ProfileModel` resolved at call time.
- **`privacy.utils.gdpr`** — removed module-level `from apps.profiles.models import UserProfileBasic`;
  both `except UserProfileBasic.DoesNotExist` clauses replaced with the portable
  `except ObjectDoesNotExist` from `django.core.exceptions`.

---

## [0.1.1] — 2026-02-20

### Fixed

- **`privacy.services`** — replaced hardcoded `from apps.profiles.models import UserProfileBasic`
  with a configurable lookup via `NIMOH_BASE['PROFILE_MODEL']` (e.g. `'profiles.UserProfileBasic'`).
  Raises `ImproperlyConfigured` with a clear message if the setting is absent.
- **`privacy.tasks`** — corrected indentation inside `try:` block that caused
  `IndentationError` at import time in the 0.1.0 sdist.
- **Missing base dependencies** — added `Pillow>=9.0` and `user-agents>=2.2` to the
  package's required dependencies (both were hard imports but omitted from `pyproject.toml`).

---

## [0.1.0] — 2025-02-19

Initial alpha release.  Extracted from the `tast-be-app` internal backend over
seven phases of debranding, decoupling, scaffolding, testing, and documentation.

### Added

#### Core (`nimoh_base.core`)
- `TimeStampedModel` and `SoftDeleteModel` abstract base models
- `SecurityHeadersMiddleware` — configurable `Server:` header, HSTS, frame-options
- `PerformanceMonitoringMiddleware` — per-request HTTP/DB metrics with optional DB persistence
- SQL injection guard middleware
- Custom DRF throttle classes (burst + sustained)
- Standardised DRF exception handler returning consistent JSON error envelopes
- `NimohBaseSettings` — composable helpers for `INSTALLED_APPS`, `MIDDLEWARE`,
  `REST_FRAMEWORK`, `SIMPLE_JWT`, `CACHES`, `LOGGING`
- `validate_nimoh_base_settings()` — asserts required `NIMOH_BASE` keys at startup
- `nimoh_setting(key, default=…)` — safe accessor for `NIMOH_BASE` values

#### Auth (`nimoh_base.auth`)
- `AbstractNimohUser` — email-primary swappable user model with fields:
  `email`, `username`, `email_verified`, `email_verified_at`,
  `failed_login_attempts`, `locked_until`
- Account-lock helpers: `lock_account()`, `unlock_account()`,
  `record_failed_login()`, `record_successful_login()`, `is_account_locked()`
- JWT authentication (access + rotating refresh) via `djangorestframework-simplejwt`
- Device-session tracking with `User-Agent` parsing and mobile-client detection
- MFA (TOTP) registration, verify, and disable endpoints
- Email verification flow (send, confirm, resend)
- Password-reset flow (request, confirm)
- HIBP Pwned Passwords validator on registration and password change
- Audit log for login/logout/password-change events
- Registration, login, refresh, logout, user-detail REST endpoints

#### Monitoring (`nimoh_base.monitoring`)
- HTTP performance metrics model and API endpoint
- DB query-count per-request tracking
- Liveness (`/health/`) and readiness (`/health/ready/`) health-check endpoints
- K8s / Docker-compatible JSON health responses

#### Privacy (`nimoh_base.privacy`)
- `PrivacyProfile` model (one-per-user) with consent and visibility fields
- Consent records and data-processing log endpoints
- GDPR data-export endpoint (async, emailed to user)
- Data-deletion confirmation flow

#### Config (`nimoh_base.conf`)
- `nimoh_base_urlpatterns(api_prefix, *, include_auth, include_monitoring,
  include_privacy, include_schema, include_health)` — one-call URL registration
- `make_celery(settings_module=None)` — Celery app factory
- `NIMOH_BASE_SCHEMA`, `NIMOH_BASE_DEFAULTS`, `NIMOH_BASE_REQUIRED_KEYS`

#### CLI (`nimoh_base.cli`) — requires `[cli]` extra
- `nimoh-base init` — interactive project scaffolding with Jinja2 templates
- `nimoh-base check` — pre-flight `NIMOH_BASE` validation
- `nimoh-base config-template` — prints a ready-to-edit `NIMOH_BASE` snippet

#### Testing utilities
- `pytest-django` integration; `conftest.py` with session-scoped DB fixtures
- `UserFactory` and `create_user_with_profile` helpers
- Full test suite: 119 tests across Python 3.12 + 3.13 / Django 5.1 matrix
- `tox.ini` + GitHub Actions CI workflow

#### Documentation
- Comprehensive `README.md` with Quick Start, CLI walkthrough, URL reference
- `docs/SETTINGS.md` — full `NIMOH_BASE` key reference
- `docs/EXTENDING.md` — user-model subclassing, template/view/middleware overrides
- `docs/MIGRATION_GUIDE.md` — step-by-step for new and existing projects

### App label changes (from internal tast-be-app)

| Old label | New label |
|-----------|-----------|
| `core` (`apps.core`) | `nimoh_core` |
| `authentication` (`apps.authentication`) | `nimoh_auth` |
| `monitoring` (`apps.monitoring`) | `nimoh_monitoring` |
| `privacy` (`apps.privacy`) | `nimoh_privacy` |

> See [docs/MIGRATION_GUIDE.md](docs/MIGRATION_GUIDE.md) for full migration instructions.

---

[Unreleased]: https://github.com/ThriledLokki983/nimoh-be-django-base/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ThriledLokki983/nimoh-be-django-base/releases/tag/v0.1.0
