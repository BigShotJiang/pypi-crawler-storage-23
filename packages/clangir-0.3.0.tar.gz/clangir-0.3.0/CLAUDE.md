Follow the instructions in @AGENTS.md
