from .installer import DepsInstaller

__all__ = ["DepsInstaller"]
