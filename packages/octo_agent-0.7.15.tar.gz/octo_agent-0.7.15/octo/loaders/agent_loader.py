"""Backward-compat shim — moved to octo.core.loaders.agent_loader."""
from octo.core.loaders.agent_loader import *  # noqa: F401,F403
from octo.core.loaders.agent_loader import AgentConfig, load_agents, load_octo_agents
