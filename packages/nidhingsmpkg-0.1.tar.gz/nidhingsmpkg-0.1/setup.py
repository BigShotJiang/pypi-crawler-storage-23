from setuptools import setup, find_packages

setup(
    name='nidhingsmpkg',                    # Your package name
    version='0.1',                        # Version number
    packages=find_packages(),             # Automatically find packages
    install_requires=[],                  # List dependencies if any
    author='Nidhin',                   # Your name
    author_email='nidhinpsath@gmail.com',# Your email
    description='A brief description of your package',
    url='https://github.com/nidhinpath/nidhingsmpkg', # Your project URL
)
