"""Micromegas CLI utilities."""
