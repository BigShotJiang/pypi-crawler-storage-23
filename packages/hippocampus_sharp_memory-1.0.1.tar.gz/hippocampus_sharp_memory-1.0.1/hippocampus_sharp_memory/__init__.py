"""
Hippocampus Sharp Memory — Brain-Inspired Memory for AI Agents
=========================================================

O(1) recall via LSH index, Ebbinghaus forgetting curve, context-weighted
scoring, and optional disk-backed persistence with user-controlled quotas.

Quick Start::

    from hippocampus_memory import create_memory

    mem = create_memory()
    mem.remember("billing complaint about invoice #4821", salience=60.0)
    mem.remember("server CPU at 95% — alert triggered", salience=80.0, emotional_tag=3)

    results = mem.recall("billing issue", top_k=3)
    for r in results:
        print(f"  [{r.retention*100:.0f}% retained] {r.content}")

Persistent Storage::

    from hippocampus_memory import create_persistent_memory

    mem = create_persistent_memory(quota_gb=7.5)
    # Memories survive restarts, with automatic quota enforcement

Part of the `Ebbiforge <https://github.com/juyterman1000/ebbiforge>`_ ecosystem.

.. note::
    This package is a thin wrapper around ``ebbiforge_core.HippocampusEngine``
    (written in Rust via PyO3). Zero code duplication — same engine, same speed.
"""

__version__ = "1.0.1"
__all__ = [
    # Core engine
    "HippocampusEngine",
    "MemoryBankConfig",
    # Result types
    "RecallResult",
    "HippocampusStats",
    "Episode",
    # Factory functions
    "create_memory",
    "create_persistent_memory",
]

# ── Import from Rust core ─────────────────────────────────────────────────
try:
    from ebbiforge_core import (
        HippocampusEngine,
        MemoryBankConfig,
    )
    from ebbiforge_core import Episode
    from ebbiforge_core.hippocampus import RecallResult, HippocampusStats
except ImportError:
    try:
        from ebbiforge_core import HippocampusEngine, MemoryBankConfig, Episode
        # RecallResult and HippocampusStats may be at module root
        try:
            from ebbiforge_core import RecallResult, HippocampusStats
        except ImportError:
            RecallResult = None
            HippocampusStats = None
    except ImportError:
        raise ImportError(
            "\n"
            "╔══════════════════════════════════════════════════════════════╗\n"
            "║  hippocampus-memory requires the Ebbiforge Rust engine.    ║\n"
            "║                                                            ║\n"
            "║  Install it:                                               ║\n"
            "║    pip install ebbiforge                                    ║\n"
            "║                                                            ║\n"
            "║  Or build from source:                                     ║\n"
            "║    git clone https://github.com/juyterman1000/ebbiforge       ║\n"
            "║    cd ebbiforge && pip install maturin                        ║\n"
            "║    maturin develop --release                                  ║\n"
            "╚══════════════════════════════════════════════════════════════╝\n"
        ) from None


# ── Factory Functions ──────────────────────────────────────────────────────

def create_memory(
    capacity: int = 500_000,
    consolidation_interval: int = 100,
    recall_reinforcement: float = 1.3,
) -> HippocampusEngine:
    """Create an in-memory HippocampusEngine with sensible defaults.

    This is the fastest way to get started. Memories live in RAM only
    and are lost when the process exits.

    Args:
        capacity: Maximum number of episodes before eviction (default: 500K).
        consolidation_interval: Ticks between sleep-replay consolidation cycles.
        recall_reinforcement: Salience multiplier on each recall (spaced repetition).

    Returns:
        A configured ``HippocampusEngine`` ready to use.

    Example::

        mem = create_memory()
        mem.remember("user prefers dark mode", salience=30.0)
        results = mem.recall("dark mode preference", top_k=1)
    """
    return HippocampusEngine(
        capacity=capacity,
        consolidation_interval=consolidation_interval,
        recall_reinforcement=recall_reinforcement,
    )


def create_persistent_memory(
    quota_gb: float = 7.5,
    capacity: int = 1_000_000,
    storage_path: str = "",
    consolidation_interval: int = 100,
    recall_reinforcement: float = 1.3,
) -> "HippocampusEngine":
    """Create a disk-backed HippocampusEngine with persistent storage.

    Memories survive process restarts. Disk usage is automatically
    managed with oldest-first eviction when the quota is reached.

    Args:
        quota_gb: Maximum disk usage in GB (5.0 to 10.0, default: 7.5).
        capacity: Maximum in-memory episodes (default: 1M).
        storage_path: Custom storage path. Empty string = OS default
            (``~/.local/share/ebbiforge/`` on Linux,
            ``~/Library/Application Support/ebbiforge/`` on macOS,
            ``%APPDATA%/ebbiforge/`` on Windows).
        consolidation_interval: Ticks between consolidation cycles.
        recall_reinforcement: Salience multiplier on recall.

    Returns:
        A configured ``HippocampusEngine`` with disk persistence.

    Example::

        mem = create_persistent_memory(quota_gb=7.5)
        mem.remember("critical incident report", salience=90.0, emotional_tag=3)
        # This memory survives process restarts
    """
    _config = MemoryBankConfig(
        storage_mode="disk",
        disk_quota_gb=quota_gb,
        storage_path=storage_path,
    )
    return HippocampusEngine(
        capacity=capacity,
        consolidation_interval=consolidation_interval,
        recall_reinforcement=recall_reinforcement,
    )
