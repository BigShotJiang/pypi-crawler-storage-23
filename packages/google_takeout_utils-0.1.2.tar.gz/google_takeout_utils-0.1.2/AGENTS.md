# AGENTS.md

See `CLAUDE.md` for all project conventions, development reminders, and architecture notes.

`CLAUDE.md` is the authoritative source — use it instead of this file.
