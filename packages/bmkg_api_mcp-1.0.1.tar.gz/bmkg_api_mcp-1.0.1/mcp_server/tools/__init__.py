"""MCP Tools for BMKG API."""

from mcp_server.tools.earthquake import *
from mcp_server.tools.weather import *
from mcp_server.tools.nowcast import *
from mcp_server.tools.region import *
