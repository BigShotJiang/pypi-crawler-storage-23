"""Exception classes for Obra."""

from collections.abc import Callable
from dataclasses import asdict, dataclass
from http import HTTPStatus
from typing import cast

# HTTP status code boundaries (RFC 9110)
HTTP_SERVER_ERROR_MAX = 600  # Upper bound of 5xx range (exclusive)


@dataclass
class ErrorContext:
    """Investigation context for debugging errors.

    Aggregates session, phase, and log information to help users
    understand what operation failed and how to investigate.

    Attributes:
        session_id: Active session ID (for recovery commands)
        project_id: Project ID if available
        request_id: Server request ID for correlation
        server_trace_id: Server Cloud Logging trace ID (CHORE-SERVER-ERROR-CONTEXT-001)
        phase: Current orchestration phase (derive, execute, refinement)
        action: Specific action that failed
        log_path: Path to local event log for investigation
        retry_count: Number of retries attempted
        recovery_suggestion: Server-computed recovery command
        error_classification: Server error category (auth, server, session, etc.)
        recent_activity: Recent server operations for debugging
    """

    session_id: str | None = None
    project_id: str | None = None
    request_id: str | None = None
    server_trace_id: str | None = None  # CHORE-SERVER-ERROR-CONTEXT-001
    phase: str | None = None
    action: str | None = None
    log_path: str | None = None
    retry_count: int | None = None
    recovery_suggestion: str | None = None  # CHORE-SERVER-ERROR-CONTEXT-001
    error_classification: str | None = None  # CHORE-SERVER-ERROR-CONTEXT-001
    recent_activity: list | None = None  # CHORE-SERVER-ERROR-CONTEXT-001

    def to_display_dict(self) -> dict[str, str | int | list]:
        """Return dict of non-None fields for display rendering."""
        return {k: v for k, v in asdict(self).items() if v is not None}


class ObraError(Exception):
    """Base exception for all Obra errors.

    All Obra exceptions include a `recovery` field with guidance on how to resolve
    the error. This helps both users and LLM agents understand the next steps.

    Attributes:
        recovery: Human-readable guidance on how to resolve this error
        error_context: Optional ErrorContext with investigation data
    """

    def __init__(
        self,
        message: str,
        recovery: str = "",
        error_context: ErrorContext | None = None,
    ) -> None:
        """Initialize ObraError.

        Args:
            message: Error message describing what went wrong
            recovery: Guidance on how to resolve the error
            error_context: Optional ErrorContext with investigation data
        """
        super().__init__(message)
        self.recovery = recovery or "Check the error message and try again."
        self.error_context = error_context


class APIError(ObraError):
    """Raised when Cloud Functions API call fails.

    Common causes:
    - Network connectivity issues
    - Invalid authentication token
    - Rate limit exceeded
    - Server-side errors

    Attributes:
        status_code: HTTP status code (0 if not applicable)
        response_body: Raw response body from server
        recovery: Guidance on how to resolve the error
        error_context: Optional ErrorContext with investigation data
    """

    def __init__(
        self,
        message: str,
        status_code: int = 0,
        response_body: str = "",
        recovery: str = "",
        error_context: ErrorContext | None = None,
    ) -> None:
        """Initialize APIError.

        Args:
            message: Error message
            status_code: HTTP status code (0 if not applicable)
            response_body: Raw response body from server
            recovery: Guidance on how to resolve the error
            error_context: Optional ErrorContext with investigation data
        """
        if not recovery:
            recovery = self._default_recovery(status_code)
        super().__init__(message, recovery, error_context=error_context)
        self.status_code = status_code
        self.response_body = response_body

    @staticmethod
    def _default_recovery(status_code: int | None) -> str:
        """Generate default recovery guidance based on HTTP status code."""
        from obra.messages.registry import get_message

        message_fn = cast(Callable[..., str], get_message)
        if status_code is None or status_code == 0:
            return "Check your network connection and try again."
        if status_code == HTTPStatus.UNAUTHORIZED.value:
            return message_fn("recovery.auth.login")
        if status_code == HTTPStatus.FORBIDDEN.value:
            return f"Access denied. {message_fn('recovery.auth.login')} or contact support."
        if status_code == HTTPStatus.NOT_FOUND.value:
            return "Resource not found. The session may have expired."
        if status_code == HTTPStatus.TOO_MANY_REQUESTS.value:
            return "Rate limit exceeded. Wait for reset or request a limit increase."
        if HTTPStatus.INTERNAL_SERVER_ERROR.value <= status_code < HTTP_SERVER_ERROR_MAX:
            return "Server error. Try again in a few minutes."
        return "Check the error details and try again."


class ConfigurationError(ObraError):
    """Raised when configuration is invalid or missing.

    Common causes:
    - Configuration file not found
    - Not authenticated (no Firebase auth token)
    - Missing required fields
    - Terms not accepted

    Attributes:
        recovery: Guidance on how to resolve the error
    """

    def __init__(self, message: str, recovery: str = "") -> None:
        """Initialize ConfigurationError.

        Args:
            message: Error message
            recovery: Guidance on how to resolve the error
        """
        if not recovery:
            from obra.messages.registry import get_message

            recovery = cast(Callable[..., str], get_message)("recovery.auth.login")
        super().__init__(message, recovery)


class ExecutionError(ObraError):
    """Raised when LLM execution fails.

    Common causes:
    - LLM CLI not found (claude, gemini, or codex)
    - Process timeout
    - JSON parsing errors
    - Permission issues

    Attributes:
        exit_code: Process exit code
        stderr: Standard error output from process
        recovery: Guidance on how to resolve the error
    """

    def __init__(
        self,
        message: str,
        exit_code: int = 0,
        stderr: str = "",
        recovery: str = "",
        error_context: ErrorContext | None = None,
    ) -> None:
        """Initialize ExecutionError.

        Args:
            message: Error message
            exit_code: Process exit code
            stderr: Standard error output from process
            recovery: Guidance on how to resolve the error
            error_context: Optional ErrorContext with investigation data
        """
        if not recovery:
            recovery = self._default_recovery(exit_code, message)
        super().__init__(message, recovery, error_context=error_context)
        self.exit_code = exit_code
        self.stderr = stderr

    @staticmethod
    def _default_recovery(exit_code: int, message: str) -> str:
        """Generate default recovery guidance based on error details."""
        msg_lower = message.lower()
        if "not found" in msg_lower or "no such file" in msg_lower:
            return (
                "Install an LLM CLI: claude, gemini, or codex. Run 'obra health-check' for details."
            )
        if "timeout" in msg_lower:
            return "The task may be too complex. Try breaking it into smaller steps."
        if "json" in msg_lower or "parse" in msg_lower:
            return "Output parsing failed. Run 'obra health-check' to verify installation."
        if exit_code == 1:
            return "Check the stderr output for details."
        if exit_code == 127:
            return "Command not found. Verify LLM CLI is installed and in PATH."
        return "Check 'obra health-check' for installation issues."


class AuthenticationError(ObraError):
    """Raised when authentication fails.

    Common causes:
    - User cancelled browser sign-in
    - Email not on beta allowlist
    - Invalid or expired token
    - Network error during auth

    Attributes:
        recovery: Guidance on how to resolve the error
    """

    def __init__(self, message: str, recovery: str = "") -> None:
        """Initialize AuthenticationError.

        Args:
            message: Error message
            recovery: Guidance on how to resolve the error
        """
        if not recovery:
            from obra.messages.registry import get_message

            recovery = cast(Callable[..., str], get_message)("recovery.auth.login")
        super().__init__(message, recovery)


class BrowserUnavailableError(AuthenticationError):
    """Raised when browser cannot be opened for OAuth flow.

    CLI should fall back to device code authentication.
    """

    def __init__(self, message: str = "Could not open browser.") -> None:
        """Initialize BrowserUnavailableError.

        Args:
            message: Error message
        """
        super().__init__(
            message,
            recovery="Use device code flow: obra login --device-code",
        )


class TermsNotAcceptedError(APIError):
    """Raised when server rejects request due to terms not accepted.

    This is a specific 403 error indicating the user must run
    'obra login' to accept the Beta Software Agreement.

    Attributes:
        required_version: The terms version that must be accepted
        terms_url: URL to view the terms
        action: Suggested action to resolve the issue
        recovery: Guidance on how to resolve the error
    """

    def __init__(
        self,
        message: str = "Terms not accepted",
        required_version: str = "",
        terms_url: str = "https://obra.dev/terms",
        action: str | None = None,
    ) -> None:
        """Initialize TermsNotAcceptedError.

        Args:
            message: Error message from server
            required_version: The terms version that must be accepted
            terms_url: URL to view the terms
            action: Suggested action to resolve the issue
        """
        if action is None:
            from obra.messages.registry import get_message

            action = cast(Callable[..., str], get_message)("recovery.auth.terms")
        recovery = f"{action} View terms at: {terms_url}"
        super().__init__(
            message=message,
            status_code=403,
            response_body="",
            recovery=recovery,
        )
        self.required_version = required_version
        self.terms_url = terms_url
        self.action = action


class ConnectionError(ObraError):
    """Raised when Obra cannot connect to the server.

    Obra requires an internet connection for the hybrid architecture.
    This error is raised when the server is unreachable.

    Attributes:
        recovery: Guidance on how to resolve the error
    """

    def __init__(self, message: str = "") -> None:
        """Initialize ConnectionError.

        Args:
            message: Error message
        """
        default_msg = (
            "Obra requires an internet connection. Please check your network and try again."
        )
        super().__init__(message or default_msg, recovery="Check your network connection.")


class OrchestratorError(ObraError):
    """Raised when orchestration fails.

    This error is raised when the orchestration loop encounters
    an unrecoverable error.

    Attributes:
        session_id: Session ID if available
        recovery: Guidance on how to resolve the error
        error_context: Optional ErrorContext with investigation data
    """

    def __init__(
        self,
        message: str,
        session_id: str = "",
        recovery: str = "",
        error_context: ErrorContext | None = None,
    ) -> None:
        """Initialize OrchestratorError.

        Args:
            message: Error message
        session_id: Session ID if available
        recovery: Recovery guidance
        error_context: Optional ErrorContext with investigation data
        """
        if session_id and not recovery:
            recovery = f"Try resuming with: obra run --resume {session_id}"
        super().__init__(message, recovery=recovery, error_context=error_context)
        self.session_id = session_id


class SessionCompletedInfo(OrchestratorError):
    """Informational notice when a session is already completed."""

    display_title = "Session Complete"
    display_style = "cyan"


class QualityGateError(ObraError):
    """Raised when UserPlan quality assessment fails to meet threshold.

    This error blocks derivation until the plan quality is improved.
    Provides actionable hints for improving the plan.

    Attributes:
        score: Quality score received (0.0-1.0)
        threshold: Minimum threshold required
        hints: List of improvement suggestions
        userplan_id: UserPlan ID that failed quality check
        recovery: Guidance on how to resolve the error
    """

    def __init__(
        self,
        message: str,
        score: float,
        threshold: float,
        hints: list[str] | None = None,
        userplan_id: str = "",
        recovery: str = "",
    ) -> None:
        """Initialize QualityGateError.

        Args:
            message: Error message
            score: Quality score received (0.0-1.0)
            threshold: Minimum threshold required
            hints: List of improvement suggestions
            userplan_id: UserPlan ID that failed quality check
            recovery: Recovery guidance
        """
        if not recovery:
            recovery = self._build_recovery(hints, userplan_id)
        super().__init__(message, recovery=recovery)
        self.score = score
        self.threshold = threshold
        self.hints = hints or []
        self.userplan_id = userplan_id

    @staticmethod
    def _build_recovery(hints: list[str] | None, userplan_id: str) -> str:
        """Build recovery guidance from hints."""
        parts = ["Fix the plan quality issues and try again."]
        if hints:
            parts.append("\nImprovement suggestions:")
            for hint in hints[:5]:  # Show top 5 hints
                parts.append(f"  - {hint}")
        if userplan_id:
            parts.append(f"\nUserPlan ID: {userplan_id}")
        parts.append("\nTo skip quality check: obra derive --skip-quality-check")
        return "\n".join(parts)


class ObjectiveTooVagueError(ObraError):
    """Raised when objective is too vague to proceed with enrichment.

    This error provides actionable guidance on what's missing from the objective.

    Attributes:
        objective: The original objective text
        word_count: Number of words in objective
        min_words: Minimum words required
        missing_elements: List of missing elements (e.g., deliverable, action)
        recovery: Guidance on how to improve the objective
    """

    def __init__(
        self,
        message: str,
        objective: str,
        word_count: int = 0,
        min_words: int = 3,
        missing_elements: list[str] | None = None,
        recovery: str = "",
    ) -> None:
        """Initialize ObjectiveTooVagueError.

        Args:
            message: Error message
            objective: The original objective text
            word_count: Number of words in objective
            min_words: Minimum words required
            missing_elements: List of missing elements
            recovery: Recovery guidance
        """
        if not recovery:
            recovery = self._build_recovery(objective, missing_elements)
        super().__init__(message, recovery=recovery)
        self.objective = objective
        self.word_count = word_count
        self.min_words = min_words
        self.missing_elements = missing_elements or []

    @staticmethod
    def _build_recovery(objective: str, missing_elements: list[str] | None) -> str:
        """Build recovery guidance for vague objective."""
        parts = ["Your objective needs more detail to proceed."]
        if missing_elements:
            parts.append("\nMissing elements:")
            for elem in missing_elements:
                parts.append(f"  - {elem}")
        parts.append("\nA good objective should include:")
        parts.append("  - What you want to build or change (deliverable)")
        parts.append("  - How you'll know it's done (success criteria)")
        parts.append("  - Any constraints or requirements")
        parts.append(
            f'\nYour objective: "{objective[:100]}..."'
            if len(objective) > 100
            else f'\nYour objective: "{objective}"'
        )
        return "\n".join(parts)


class IntentQualityError(ObraError):
    """Raised when enriched intent quality is below threshold.

    This error indicates that even after LLM enrichment, the intent
    is not sufficient to derive a quality plan.

    Attributes:
        intent_id: ID of the intent that failed quality check
        score: Quality score received (0.0-1.0)
        threshold: Minimum threshold required
        hints: List of improvement suggestions
        recovery: Guidance on how to improve the objective
    """

    def __init__(
        self,
        message: str,
        intent_id: str = "",
        score: float = 0.0,
        threshold: float = 0.6,
        hints: list[str] | None = None,
        recovery: str = "",
    ) -> None:
        """Initialize IntentQualityError.

        Args:
            message: Error message
            intent_id: ID of the intent that failed
            score: Quality score received (0.0-1.0)
            threshold: Minimum threshold required
            hints: List of improvement suggestions
            recovery: Recovery guidance
        """
        if not recovery:
            recovery = self._build_recovery(hints)
        super().__init__(message, recovery=recovery)
        self.intent_id = intent_id
        self.score = score
        self.threshold = threshold
        self.hints = hints or []

    @staticmethod
    def _build_recovery(hints: list[str] | None) -> str:
        """Build recovery guidance for intent quality failure."""
        parts = [
            "The enriched intent does not meet quality standards.",
            "Please provide a more detailed objective.",
        ]
        if hints:
            parts.append("\nTo improve, consider adding:")
            for hint in hints[:5]:
                parts.append(f"  - {hint}")
        parts.append("\nTry rephrasing your objective with:")
        parts.append("  - Specific deliverables (what files/features to create)")
        parts.append("  - Clear success criteria (how to verify it works)")
        parts.append("  - Technology preferences if any")
        return "\n".join(parts)


class SecurityError(ObraError):
    """Raised when a security violation is detected.

    This error indicates that an operation would violate security constraints,
    such as a path traversal attempt outside the working directory.

    Attributes:
        attempted_path: The path that was attempted
        allowed_root: The allowed root directory
        recovery: Guidance on how to resolve the error
    """

    def __init__(
        self,
        message: str,
        attempted_path: str = "",
        allowed_root: str = "",
        recovery: str = "",
    ) -> None:
        """Initialize SecurityError.

        Args:
            message: Error message
            attempted_path: The path that was attempted
            allowed_root: The allowed root directory
            recovery: Recovery guidance
        """
        if not recovery:
            recovery = self._build_recovery(attempted_path, allowed_root)
        super().__init__(message, recovery=recovery)
        self.attempted_path = attempted_path
        self.allowed_root = allowed_root

    @staticmethod
    def _build_recovery(attempted_path: str, allowed_root: str) -> str:
        """Build recovery guidance for security violation."""
        parts = ["Path traversal blocked for security."]
        if attempted_path:
            parts.append(f"Attempted path: {attempted_path}")
        if allowed_root:
            parts.append(f"Allowed root: {allowed_root}")
        parts.append("\nTo resolve:")
        parts.append("  - Ensure all file operations target the project working directory")
        parts.append("  - Check that paths do not contain '..' traversal sequences")
        parts.append(
            "  - If you need to access files outside working_dir, update the project config"
        )
        return "\n".join(parts)


class DerivationStallError(ObraError):
    """Raised when derivation stalls with no LLM output.

    This error indicates that the LLM has not produced output for an extended
    period during derivation, suggesting a hang, timeout, or other issue.

    Attributes:
        step: Derivation step number (1, 2, or 3)
        step_name: Name of the step (structure, tasks, serialize)
        elapsed_seconds: Time elapsed since step started (seconds)
        timeout_seconds: Configured timeout threshold (seconds)
        recovery: Guidance on how to resolve the error
    """

    def __init__(
        self,
        step: int,
        step_name: str,
        elapsed_seconds: float,
        timeout_seconds: float,
    ) -> None:
        """Initialize DerivationStallError.

        Args:
            step: Derivation step number (1, 2, or 3)
            step_name: Name of the step (structure, tasks, serialize)
            elapsed_seconds: Time elapsed since step started (seconds)
            timeout_seconds: Configured timeout threshold (seconds)
        """
        message = (
            f"Derivation stalled at step {step} ({step_name}): "
            f"no output for {elapsed_seconds:.0f}s (timeout: {timeout_seconds:.0f}s)"
        )
        recovery = "Try running with a simpler objective or check LLM provider status."
        super().__init__(message, recovery=recovery)
        self.step = step
        self.step_name = step_name
        self.elapsed_seconds = elapsed_seconds
        self.timeout_seconds = timeout_seconds


__all__ = [
    "APIError",
    "AuthenticationError",
    "BrowserUnavailableError",
    "ConfigurationError",
    "ConnectionError",
    "DerivationStallError",
    "ErrorContext",
    "ExecutionError",
    "IntentQualityError",
    "ObjectiveTooVagueError",
    "ObraError",
    "OrchestratorError",
    "QualityGateError",
    "SecurityError",
    "TermsNotAcceptedError",
]
