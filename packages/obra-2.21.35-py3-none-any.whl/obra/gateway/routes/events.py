"""Server-Sent Events (SSE) streaming endpoint for session progress."""

from __future__ import annotations

import json
from typing import AsyncIterator

from fastapi import APIRouter, HTTPException, Query, Request, status
from starlette.responses import StreamingResponse

from obra.gateway.session_manager import SessionNotFoundError

router = APIRouter(prefix="/v1/sessions", tags=["events"])


async def _event_generator(
    session_id: str, request: Request, filter_types: set[str] | None = None
) -> AsyncIterator[str]:
    """Async generator yielding SSE-formatted events from the session event bus."""
    sm = request.app.state.session_manager
    event_bus = sm.get_event_bus(session_id)

    async for event in event_bus.consume():
        if filter_types and event.get("event_type") not in filter_types:
            continue
        yield f"data: {json.dumps(event)}\n\n"

    yield "data: [DONE]\n\n"


@router.get("/{session_id}/events")
async def stream_events(
    session_id: str,
    request: Request,
    filter: str | None = Query(default=None, description="Comma-separated event types to include"),
) -> StreamingResponse:
    """Stream session events via Server-Sent Events."""
    sm = request.app.state.session_manager
    try:
        sm.get_session(session_id)
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    filter_types: set[str] | None = None
    if filter:
        filter_types = {t.strip() for t in filter.split(",")}

    return StreamingResponse(
        _event_generator(session_id, request, filter_types),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
        },
    )
