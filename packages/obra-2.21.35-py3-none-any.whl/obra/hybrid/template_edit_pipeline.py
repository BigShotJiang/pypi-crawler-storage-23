"""Template Edit Pipeline for LLM JSON Responses.

This module provides a unified pipeline for requesting structured JSON outputs
from LLMs using file editing instead of text response parsing. This approach
eliminates preamble/prose contamination issues where LLMs naturally add
explanatory text before JSON ("I need to carefully examine..."), causing
parse failures.

The Template Method pattern separates pipeline mechanics (retry, validation,
observability) from domain logic (schemas, validators, fallbacks).
"""

import json
import logging
import re
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any, ClassVar, Literal
from uuid import uuid4

from obra.config.llm import DEFAULT_REASONING_LEVEL
from obra.config.loaders import (
    get_llm_logging_preview_max_response_chars,
    get_template_edit_max_retries,
    get_template_retention_settings,
)
from obra.hybrid.json_utils import extract_json_payload

_CONTROL_CHAR_RE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _sanitize_control_chars(text: str) -> str:
    """Strip invalid JSON control characters, preserving \\n, \\r, \\t."""
    return _CONTROL_CHAR_RE.sub("", text)
from obra.llm.cli_runner import invoke_llm_via_cli
from obra.prompts.fragments.template_edit import (
    build_template_edit_prompt,
    build_template_edit_prompt_text,
)

logger = logging.getLogger(__name__)


class TemplateEditPipeline:
    """Pipeline for structured JSON responses via file editing.

    This class handles the mechanics of template-based JSON generation:
    - Creates template files with schema guidance
    - Invokes LLM with file editing instructions
    - Validates responses and retries on failure
    - Provides observability hooks for monitoring

    Handlers provide domain-specific components:
    - Template schema (initial JSON structure with _instructions)
    - Validator function (checks fields, types, constraints)
    - Fallback function (safe default on validation failure)

    Example:
        pipeline = TemplateEditPipeline(
            working_dir=Path('/project'),
            action_name='examine',
            max_retries=3
        )

        def validator(data: dict) -> tuple[bool, str | None]:
            if 'issues' not in data:
                return (False, 'Missing issues field')
            return (True, None)

        def fallback() -> list:
            return []

        result, metadata = pipeline.execute(
            base_prompt="Examine this code",
            template_content={'issues': [], '_instructions': '...'},
            validator=validator,
            fallback_fn=fallback,
            llm_config={'provider': 'claude'}
        )
    """

    def __init__(
        self,
        working_dir: Path,
        action_name: str,
        output_format: Literal["json", "text"] = "json",
        on_stream: Callable[[str], None] | None = None,
        log_event: Callable[..., None] | None = None,
        production_logger: Any | None = None,
        max_retries: int | None = None,
    ):
        """Initialize the template edit pipeline.

        Args:
            working_dir: Project working directory (base for relative paths)
            action_name: Action identifier (e.g., 'examine', 'derive')
            output_format: Output format ('json' for structured data, 'text' for prose)
            on_stream: Optional callback for streaming LLM output
            log_event: Optional callback for observability events
            max_retries: Maximum validation retry attempts (default from config: 3)
        """
        self._working_dir = working_dir
        self._action_name = action_name
        self._output_format = output_format
        self._on_stream = on_stream
        self._log_event = log_event
        self._production_logger = production_logger
        self._max_retries = (
            max_retries if max_retries is not None else get_template_edit_max_retries()
        )

    def _emit_log_event(self, event_type: str, **kwargs: Any) -> None:
        """Emit a log event using the configured callback.

        This wrapper normalizes the calling convention to use **kwargs,
        matching HybridOrchestrator._log_session_event signature.

        Args:
            event_type: Event type string (e.g., 'template_created')
            **kwargs: Event-specific data as keyword arguments
        """
        if self._log_event:
            try:
                self._log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log event '{event_type}': {e}")
        if self._production_logger:
            try:
                self._production_logger.log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log production event '{event_type}': {e}")

    def _create_template(self, template_content: dict[str, Any] | str) -> Path:
        """Create a template file with the given content.

        For JSON format: The template file is a JSON file containing the schema
        structure with an _instructions field providing guidance to the LLM.

        For text format: The template file is a markdown file containing prose
        content with <FILL:...> placeholders for the LLM to populate.

        Args:
            template_content: Dictionary with schema structure (JSON format) or
                string with prose template (text format)

        Returns:
            Path to the created template file

        Example (JSON):
            >>> template_path = pipeline._create_template({
            ...     'issues': [],
            ...     '_instructions': 'Add examination issues to the issues array'
            ... })
            >>> # Creates .obra/llm_output/examine_20260124_143022.json

        Example (text):
            >>> template_path = pipeline._create_template(
            ...     "E1.S1: <FILL: story title>\\n<FILL: description>"
            ... )
            >>> # Creates .obra/llm_output/derivation_20260124_143022.md
        """
        # Create output directory if it doesn't exist
        output_dir = self._working_dir / ".obra" / "llm_output"
        output_dir.mkdir(parents=True, exist_ok=True)

        # Generate unique filename with timestamp + UUID suffix to prevent
        # collisions when concurrent threads create templates in the same second
        # (e.g., parallel epic serialization via ThreadPoolExecutor)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_suffix = uuid4().hex[:8]

        # Choose file extension based on output format
        extension = ".md" if self._output_format == "text" else ".json"
        filename = f"{self._action_name}_{timestamp}_{unique_suffix}{extension}"
        template_path = output_dir / filename

        # Write content to template file
        if self._output_format == "text":
            # Text format: write string directly
            template_path.write_text(template_content)
        else:
            # JSON format: serialize dictionary
            template_path.write_text(json.dumps(template_content, indent=2))

        logger.debug(f"Created template file: {template_path}")
        return template_path

    # ISSUE-HYBRID-056: Patterns in server-generated prompts that contradict
    # template-edit mode.  The server may instruct "Do NOT create/modify files"
    # for text-mode JSON output, but template-edit requires file editing.
    _TEXT_MODE_PREAMBLE_PATTERNS: ClassVar[list[re.Pattern[str]]] = [
        re.compile(
            r"\*\*CRITICAL OUTPUT REQUIREMENT\*\*:.*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
        re.compile(
            r"Your ENTIRE response must be parseable by json\.loads\(\)\..*?(?=\n\n|\n#|\Z)",
            re.DOTALL,
        ),
    ]

    @staticmethod
    def _strip_text_mode_preamble(prompt: str) -> str:
        """Remove text-mode JSON output instructions that contradict file-edit mode.

        Server-generated prompts may contain directives like "Do NOT create files"
        intended for text-mode JSON responses.  These conflict with the template-edit
        suffix that instructs the LLM to edit a file, causing the model to either
        refuse or write JSON to stdout instead of editing the template
        (ISSUE-HYBRID-056).
        """
        cleaned = prompt
        for pattern in TemplateEditPipeline._TEXT_MODE_PREAMBLE_PATTERNS:
            cleaned = pattern.sub("", cleaned)
        # Collapse runs of 3+ blank lines left by removal
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned

    def _build_template_edit_prompt(self, base_prompt: str, template_path: Path) -> str:
        """Build augmented prompt with file editing instructions.

        Transforms a base prompt into a template edit prompt by adding
        instructions to edit the template file instead of responding with prose.
        This forces the LLM to use tool actions (structural) rather than text
        responses (prose), eliminating preamble contamination.

        Args:
            base_prompt: Original prompt describing the task
            template_path: Path to the template file to edit

        Returns:
            Augmented prompt with file editing instructions

        Example:
            >>> prompt = pipeline._build_template_edit_prompt(
            ...     "Examine this code for issues",
            ...     Path("/project/.obra/llm_output/examine_20260124_143022.json")
            ... )
            >>> # Returns: "Examine this code for issues\n\nIMPORTANT: Edit the file..."
        """
        # ISSUE-HYBRID-056: Strip text-mode JSON preamble that conflicts with
        # file-edit instructions (defense-in-depth; server-side fix is primary).
        cleaned_prompt = self._strip_text_mode_preamble(base_prompt)

        # Calculate relative path if possible, fallback to absolute
        try:
            relative_path = template_path.relative_to(self._working_dir)
        except ValueError:
            # Template path is not relative to working_dir, use absolute
            relative_path = template_path

        # Build augmented prompt with editing instructions (dispatch based on format)
        if self._output_format == "text":
            return build_template_edit_prompt_text(cleaned_prompt, relative_path)
        else:
            task_verb = "revisions" if self._action_name == "revise" else "findings"
            return build_template_edit_prompt(
                cleaned_prompt,
                relative_path,
                task_verb=task_verb,
            )

    def _recover_json_payload(self, content: str) -> tuple[dict[str, Any] | None, int | None]:
        payload = extract_json_payload(content)
        if not payload:
            return (None, None)
        payload = _sanitize_control_chars(payload)
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError as e:
            repaired = self._repair_missing_comma(payload, e)
            if repaired is None:
                return (None, None)
            return (repaired, len(payload))
        if not isinstance(parsed, dict):
            return (None, None)
        return (parsed, len(payload))

    def _repair_missing_comma(
        self,
        content: str,
        error: json.JSONDecodeError,
    ) -> dict[str, Any] | None:
        if error.msg != "Expecting ',' delimiter":
            return None
        insert_at = error.pos
        if insert_at <= 0 or insert_at > len(content):
            return None
        prev_index = insert_at - 1
        while prev_index >= 0 and content[prev_index].isspace():
            prev_index -= 1
        if prev_index < 0:
            return None
        if content[prev_index] in "{[,":
            return None
        repaired_text = f"{content[:insert_at]},{content[insert_at:]}"
        repaired_text = _sanitize_control_chars(repaired_text)
        try:
            repaired = json.loads(repaired_text)
        except json.JSONDecodeError:
            return None
        if not isinstance(repaired, dict):
            return None
        return repaired

    def _try_recover_from_stdout(
        self,
        stdout: str,
        template_content: dict[str, Any],
        validator: Callable[[dict[str, Any]], tuple[bool, str | None]],
    ) -> dict[str, Any] | None:
        """Attempt to recover valid structured output from LLM stdout.

        When the LLM writes revision/examination JSON to stdout instead of
        editing the template file, this method tries to extract and validate
        that output.  Uses the existing ``extract_json_payload`` utility which
        handles markdown code fences and bare JSON objects in mixed text.

        Returns validated data dict on success, ``None`` on failure.
        """
        if not stdout or not stdout.strip():
            return None

        # Try direct JSON parse first (fastest path)
        try:
            data = json.loads(stdout.strip())
            if isinstance(data, dict):
                data.pop("_instructions", None)
                is_valid, _ = validator(data)
                if is_valid:
                    return data
        except (json.JSONDecodeError, ValueError):
            pass

        # Try extraction from mixed content (code fences, preamble text)
        recovered_data, _ = self._recover_json_payload(stdout)
        if recovered_data is not None:
            recovered_data.pop("_instructions", None)
            is_valid, _ = validator(recovered_data)
            if is_valid:
                return recovered_data

        return None

    @staticmethod
    def _is_model_not_found_error(message: str) -> bool:
        """Return True when CLI/API reported unknown model."""
        text = message.lower()
        return (
            "model_not_found" in text
            or ("requested model" in text and "does not exist" in text)
            or "unknown model" in text
        )

    def _build_model_not_found_message(self, llm_config: dict[str, Any], detail: str) -> str:
        provider = str(llm_config.get("provider", "unknown"))
        model = str(llm_config.get("model", "unknown"))
        return (
            f"Configured model '{model}' is not available for provider '{provider}'. "
            "Failing fast to avoid repeated retries. "
            "Fix config (for example via 'obra config show llm' and set an available model), "
            f"then retry. Detail: {detail}"
        )

    def execute(
        self,
        base_prompt: str,
        template_content: dict[str, Any] | str,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        fallback_fn: Callable[[], Any],
        llm_config: dict[str, Any],
        timeout_s: int | None = None,
        max_retries: int | None = None,
        allow_unchanged: bool = True,
    ) -> tuple[Any, dict[str, Any]]:
        """Execute the template edit pipeline with retry loop.

        This is the main entry point for the pipeline. It orchestrates:
        1. Template creation
        2. LLM invocation with editing instructions
        3. Response validation with retry on failure
        4. Fallback on exhausted retries

        Args:
            base_prompt: The task description prompt
            template_content: Initial content - JSON dict with _instructions
                (JSON format) or prose string with <FILL:> placeholders (text format)
            validator: Function that validates parsed data (dict for JSON, str
                for text) and returns (is_valid, error_msg). Return (True, None)
                if valid.
            fallback_fn: Function that returns a safe default value if
                all retry attempts fail
            llm_config: LLM configuration dict with keys:
                - provider: str (e.g., 'anthropic', 'openai')
                - model: str (model identifier)
                - reasoning_level: str (reasoning level)
                - auth: str (auth method, default 'oauth')
                - allowed_tools: Optional list[str] tool allowlist
            timeout_s: Optional timeout override for the LLM call.
            max_retries: Optional retry override for this execution.
            allow_unchanged: When False, unchanged template files are treated
                as validation failures and retried/fallbacked instead of being
                accepted as "no changes required".

        Returns:
            Tuple of (result_data, metadata). Metadata includes:
            - status: 'template_success' (first attempt), 'template_retry_success' (retry succeeded), or 'template_fallback' (all retries failed)
            - attempts: number of attempts made

        Example:
            >>> def validator(data: dict) -> tuple[bool, str | None]:
            ...     if 'issues' not in data:
            ...         return (False, 'Missing issues field')
            ...     return (True, None)
            >>> def fallback() -> list:
            ...     return []
            >>> result, meta = pipeline.execute(
            ...     base_prompt="Examine this code",
            ...     template_content={'issues': [], '_instructions': '...'},
            ...     validator=validator,
            ...     fallback_fn=fallback,
            ...     llm_config={'provider': 'anthropic', 'model': 'claude-3-5-sonnet-20241022', 'thinking': 'off', 'auth': 'oauth'}
            ... )
        """
        # Create template file
        template_path = self._create_template(template_content)
        initial_content = template_path.read_text(encoding="utf-8")

        # Log template creation
        self._emit_log_event(
            "template_created",
            template_path=str(template_path),
            action=self._action_name,
        )

        # Build augmented prompt with editing instructions
        augmented_prompt = self._build_template_edit_prompt(base_prompt, template_path)

        max_attempts = self._max_retries if max_retries is None else max_retries

        # Retry loop
        for attempt in range(max_attempts):
            try:
                # Preserve OpenAI Codex safety defaults for template-edit calls.
                # Many callsites pass only provider/model/thinking/auth in llm_config.
                codex_config = llm_config.get("codex", {})
                if not isinstance(codex_config, dict):
                    codex_config = {}
                git_config = llm_config.get("git", {})
                if not isinstance(git_config, dict):
                    git_config = {}

                has_top_bypass = "bypass_sandbox" in llm_config
                has_codex_bypass = "bypass_sandbox" in codex_config
                has_top_skip = "skip_git_check" in llm_config
                has_git_skip = "skip_check" in git_config

                bypass_sandbox = bool(
                    llm_config.get(
                        "bypass_sandbox",
                        codex_config.get("bypass_sandbox", False),
                    )
                )
                approval_mode = llm_config.get("approval_mode", codex_config.get("approval_mode"))
                skip_git_check = bool(
                    llm_config.get(
                        "skip_git_check",
                        git_config.get("skip_check", True),
                    )
                )

                provider = str(llm_config.get("provider", ""))
                if provider == "openai":
                    if not has_top_bypass and not has_codex_bypass:
                        bypass_sandbox = True
                    if approval_mode is None:
                        approval_mode = "full-auto"
                    if not has_top_skip and not has_git_skip:
                        skip_git_check = True

                # Invoke LLM — capture stdout for recovery if template is
                # unchanged (ISSUE-HYBRID-056).
                llm_stdout = invoke_llm_via_cli(
                    prompt=augmented_prompt,
                    cwd=self._working_dir,
                    provider=llm_config["provider"],
                    model=llm_config["model"],
                    reasoning_level=llm_config.get("reasoning_level", DEFAULT_REASONING_LEVEL),
                    auth_method=llm_config.get("auth", "oauth"),
                    timeout_s=timeout_s,
                    on_stream=self._on_stream,
                    log_event=self._log_event,
                    call_site=f"template_edit:{self._action_name}",
                    skip_git_check=skip_git_check,
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                    mode="execute",
                    response_format="text",
                    allowed_tools=llm_config.get("allowed_tools"),
                )

                # Read template file
                content = template_path.read_text(encoding="utf-8")
                data: dict[str, Any] | str | None = None

                content_unchanged = content == initial_content

                if self._output_format == "text":
                    # Text format: content is the raw string
                    data = content
                else:
                    # JSON format: parse and validate JSON
                    if content_unchanged:
                        # LLM completed successfully but didn't edit the file.
                        # Accept only if the template defaults pass validation.
                        # ISSUE-HYBRID-056: Include model/tool compliance data.
                        self._emit_log_event(
                            "template_unchanged_detected",
                            attempt=attempt + 1,
                            template_path=str(template_path),
                            model=llm_config.get("model", "unknown"),
                            provider=llm_config.get("provider", "unknown"),
                            action=self._action_name,
                        )
                        data = {k: v for k, v in template_content.items() if k != "_instructions"}
                    else:
                        try:
                            data = json.loads(content)
                        except json.JSONDecodeError as e:
                            repaired_data = self._repair_missing_comma(content, e)
                            if repaired_data is not None:
                                data = repaired_data
                                self._emit_log_event(
                                    "parse_repaired",
                                    attempt=attempt + 1,
                                    error_msg=str(e),
                                    repair_type="missing_comma",
                                    source="content",
                                )
                            else:
                                recovered_data, extracted_length = self._recover_json_payload(content)
                                if recovered_data is None:
                                    raise
                                data = recovered_data
                                self._emit_log_event(
                                    "parse_recovered",
                                    attempt=attempt + 1,
                                    error_msg=str(e),
                                    extracted_length=extracted_length or 0,
                                )

                    if data is None:
                        raise ValueError("Template edit returned no data")

                    # Auto-wrap: if LLM returned a raw JSON array instead of the
                    # expected object, wrap it using the template's single data key.
                    # e.g. LLM wrote [{...}] instead of {"stories": [{...}]}
                    if isinstance(data, list):
                        data_keys = [k for k in template_content if k != "_instructions"]
                        if len(data_keys) == 1 and isinstance(template_content[data_keys[0]], list):
                            self._emit_log_event(
                                "array_auto_wrapped",
                                attempt=attempt + 1,
                                wrap_key=data_keys[0],
                                array_length=len(data),
                            )
                            data = {data_keys[0]: data}
                        else:
                            raise ValueError(
                                f"LLM returned a JSON array but template expects object "
                                f"with keys: {data_keys}"
                            )

                    if not content_unchanged:
                        for key, value in template_content.items():
                            if key == "_instructions":
                                continue
                            if key not in data:
                                data[key] = value

                        # Remove _instructions field (not part of result)
                        data.pop("_instructions", None)

                try:
                    # Log template read
                    self._emit_log_event("template_read", file_size=len(content), attempt=attempt + 1)
                except Exception:
                    self._emit_log_event("template_read", file_size=0, attempt=attempt + 1)

                # Log parse attempt
                self._emit_log_event("parse_attempt", attempt=attempt + 1, max_retries=max_attempts)

                # Validate result
                if content_unchanged and not allow_unchanged:
                    is_valid = False
                    error_msg = "Template file unchanged but edits are required"
                else:
                    is_valid, error_msg = validator(data)

                if is_valid:
                    # Success! Log with content preview for log viewer
                    max_preview = get_llm_logging_preview_max_response_chars()
                    if isinstance(data, dict):
                        preview_str = json.dumps(data, indent=2)[:max_preview]
                    else:
                        preview_str = str(data)[:max_preview]
                    self._emit_log_event(
                        "parse_success",
                        attempts=attempt + 1,
                        action=self._action_name,
                        content_preview=preview_str,
                    )

                    if content_unchanged:
                        self._emit_log_event(
                            "template_unchanged_accepted",
                            attempt=attempt + 1,
                            template_path=str(template_path),
                        )
                        logger.debug(
                            "Template unchanged after LLM call - accepting as 'no changes required'"
                        )
                        self._schedule_cleanup(template_path, on_error=False)
                        return (
                            data,
                            {"status": "no_changes_required", "attempts": attempt + 1},
                        )

                    # Schedule cleanup on success
                    self._schedule_cleanup(template_path, on_error=False)

                    # Use 3-tier status: template_success on first attempt, template_retry_success after retries
                    status = "template_success" if attempt == 0 else "template_retry_success"
                    return (data, {"status": status, "attempts": attempt + 1})

                # Validation failed
                self._emit_log_event("parse_error", error_msg=error_msg, attempt=attempt + 1)
                if content_unchanged:
                    self._emit_log_event(
                        "template_unchanged_rejected",
                        attempt=attempt + 1,
                        template_path=str(template_path),
                        error_msg=error_msg,
                    )

                # ISSUE-HYBRID-056: Short-circuit retries on deterministic
                # unchanged failure.  When the LLM returns valid output in
                # stdout but does not edit the template file, retrying with
                # the same prompt produces the same failure.  Before falling
                # back, attempt to recover valid structured output from stdout.
                if content_unchanged and not allow_unchanged:
                    # Try stdout recovery before giving up.
                    recovered = self._try_recover_from_stdout(
                        llm_stdout, template_content, validator
                    )
                    if recovered is not None:
                        logger.info(
                            "ISSUE-HYBRID-056: Recovered valid output from "
                            "stdout (template unchanged, stdout had parseable data)"
                        )
                        self._emit_log_event(
                            "template_unchanged_stdout_recovered",
                            attempt=attempt + 1,
                            recovered_keys=sorted(recovered.keys()),
                            model=llm_config.get("model", "unknown"),
                        )
                        self._schedule_cleanup(template_path, on_error=False)
                        return (
                            recovered,
                            {
                                "status": "stdout_recovery",
                                "attempts": attempt + 1,
                            },
                        )

                    # Stdout recovery failed — short-circuit remaining retries.
                    logger.warning(
                        "ISSUE-HYBRID-056: Deterministic unchanged failure "
                        "(valid_output_no_file_edit) — skipping %d remaining "
                        "retries and using fallback",
                        max(0, max_attempts - attempt - 1),
                    )
                    self._emit_log_event(
                        "template_unchanged_short_circuit",
                        attempt=attempt + 1,
                        max_retries=max_attempts,
                        skipped_retries=max(0, max_attempts - attempt - 1),
                        failure_class="valid_output_no_file_edit",
                        model=llm_config.get("model", "unknown"),
                    )
                    self._schedule_cleanup(template_path, on_error=True)
                    fallback_result = fallback_fn()
                    return (
                        fallback_result,
                        {
                            "status": "template_fallback",
                            "attempts": attempt + 1,
                            "failure_class": "valid_output_no_file_edit",
                        },
                    )

                if attempt + 1 < max_attempts:
                    # Build error fix prompt and retry, preserving original context
                    augmented_prompt = self._build_template_edit_prompt(base_prompt, template_path)
                    if self._output_format == "text":
                        augmented_prompt += (
                            f"\n\nNote: Previous attempt had validation error: {error_msg}. "
                            f"Fill remaining placeholders and fix this specific issue."
                        )
                    else:
                        augmented_prompt += (
                            f"\n\nNote: Previous attempt had validation error: {error_msg}. "
                            f"Please fix this specific issue."
                        )
                    logger.warning(
                        f"Validation failed (attempt {attempt + 1}/{max_attempts}): {error_msg}"
                    )

                    self._emit_log_event(
                        "retry_attempt",
                        reason="validation_error",
                        error_msg=error_msg,
                        new_prompt_preview=augmented_prompt[:100],
                    )
                else:
                    # All retries exhausted, use fallback
                    logger.error(
                        "Validation failed after %d attempts. Using fallback.",
                        max_attempts,
                    )

                    # Schedule cleanup on error
                    self._schedule_cleanup(template_path, on_error=True)

                    fallback_result = fallback_fn()
                    return (
                        fallback_result,
                        {"status": "template_fallback", "attempts": max_attempts},
                    )

                continue
            except json.JSONDecodeError as e:
                # JSON parsing error
                self._emit_log_event(
                    "parse_error",
                    error_msg=f"JSON parse error: {e!s}",
                    attempt=attempt + 1,
                )

                if attempt + 1 < max_attempts:
                    # Build JSON fix prompt and retry, preserving original context
                    augmented_prompt = self._build_template_edit_prompt(base_prompt, template_path)
                    augmented_prompt += (
                        f"\n\nNote: Previous attempt had JSON parse error: {e!s}. "
                        f"Fix the JSON syntax."
                    )
                    logger.warning(
                        f"JSON parse error (attempt {attempt + 1}/{max_attempts}): {e!s}"
                    )

                    self._emit_log_event(
                        "retry_attempt",
                        reason="json_parse_error",
                        error_msg=str(e),
                        new_prompt_preview=augmented_prompt[:100],
                    )
                else:
                    # All retries exhausted, use fallback
                    logger.exception(
                        "JSON parse error after %d attempts. Using fallback.",
                        max_attempts,
                    )

                    # Schedule cleanup on error
                    self._schedule_cleanup(template_path, on_error=True)

                    fallback_result = fallback_fn()
                    return (
                        fallback_result,
                        {"status": "template_fallback", "attempts": max_attempts},
                    )

            except Exception as e:
                if self._is_model_not_found_error(str(e)):
                    message = self._build_model_not_found_message(llm_config, str(e))
                    self._emit_log_event(
                        "template_error",
                        error_msg=message,
                        attempt=attempt + 1,
                    )
                    logger.error(message)
                    self._schedule_cleanup(template_path, on_error=True)
                    raise RuntimeError(message) from e

                self._emit_log_event("template_error", error_msg=str(e), attempt=attempt + 1)
                if attempt + 1 < max_attempts:
                    logger.warning(
                        "Template edit failed (attempt %d/%d): %s",
                        attempt + 1,
                        max_attempts,
                        e,
                    )
                    continue

                logger.exception(
                    "Template edit failed after %d attempts. Using fallback.",
                    max_attempts,
                )
                self._schedule_cleanup(template_path, on_error=True)
                fallback_result = fallback_fn()
                return (
                    fallback_result,
                    {"status": "template_error", "attempts": max_attempts},
                )

        # Should never reach here, but add fallback for safety
        self._schedule_cleanup(template_path, on_error=True)
        fallback_result = fallback_fn()
        return (
            fallback_result,
            {"status": "validation_failed", "attempts": max_attempts},
        )

    def _schedule_cleanup(self, template_path: Path, on_error: bool) -> None:
        """Clean up template file based on retention policy.

        Retention policy:
        - Success: Delete template unless retention configured
        - Error: Keep template unless retention disabled

        Args:
            template_path: Path to template file
            on_error: Whether the pipeline ended in error state
        """
        keep_on_success, keep_on_error = get_template_retention_settings()
        should_keep = keep_on_error if on_error else keep_on_success
        if should_keep:
            logger.debug(
                "Template kept (on_error=%s, keep_on_success=%s, keep_on_error=%s): %s",
                on_error,
                keep_on_success,
                keep_on_error,
                template_path,
            )
            return

        try:
            template_path.unlink()
            logger.debug("Template cleaned up: %s", template_path)
        except Exception as e:
            logger.warning("Failed to cleanup template %s: %s", template_path, e)
