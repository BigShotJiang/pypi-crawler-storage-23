"""Shared parallel execution module for Obra.

Provides a reusable ParallelExecutor with fan-out, stagger, per-item
timeout, error isolation, and deterministic result ordering.

First consumer: fix handler parallel batch dispatch (Story S1).
Future consumers: any workload requiring thread-pooled fan-out with
observability hooks (deployer, orchestrator examine/revise, etc.).

Work ID: REFACTOR-PARALLEL-MODULE-001
"""

from __future__ import annotations

import logging
import time
from concurrent.futures import Future, ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, Literal, TypeVar

logger = logging.getLogger(__name__)

T = TypeVar("T")


@dataclass
class WorkerResult(Generic[T]):
    """Result from a single parallel worker."""

    index: int
    item_key: str | None
    result: T | None
    error: Exception | None
    status: Literal["success", "error", "timeout"]
    elapsed_ms: float


@dataclass
class ParallelResult(Generic[T]):
    """Aggregate result from a parallel execution run."""

    results: list[WorkerResult[T]]
    wall_clock_ms: float
    worker_count: int
    items_total: int
    items_succeeded: int
    items_failed: int
    speedup_ratio: float
    straggler_ratio: float


@dataclass
class ParallelExecutor:
    """Thread-pool executor with fan-out, stagger, and error isolation.

    Provides deterministic result ordering, per-item timeout, and
    observability hooks for parallel workloads.

    Args:
        max_workers: Maximum concurrent threads (clamped to item count).
        worker_delay_s: Stagger delay between worker submissions to
            avoid provider rate-limit exhaustion.
        per_item_timeout_s: Timeout per individual work item. None = no
            per-item timeout (relies on overall_timeout_s only).
        label: Human-readable label for logging context.
        on_item_complete: Optional callback invoked after each item
            completes with the WorkerResult.
        on_execution_complete: Optional callback invoked after all items
            complete with the aggregate ParallelResult. Fires before
            execute() returns. Errors are isolated (logged, not raised).
    """

    max_workers: int = 4
    worker_delay_s: float = 1.0
    per_item_timeout_s: float | None = None
    label: str = "parallel"
    on_item_complete: Callable[[WorkerResult[Any]], None] | None = field(
        default=None, repr=False
    )
    on_execution_complete: Callable[[ParallelResult[Any]], None] | None = field(
        default=None, repr=False
    )

    def execute(
        self,
        items: list[tuple[str, Callable[[], T]]],
        overall_timeout_s: float | None = None,
    ) -> ParallelResult[T]:
        """Fan out work items to a thread pool and collect results.

        Args:
            items: List of (item_key, callable) pairs. Each callable
                takes no arguments and returns a result of type T.
            overall_timeout_s: Wall-clock timeout for the entire
                execution. None = no overall timeout.

        Returns:
            ParallelResult with deterministic ordering matching the
            input item order.
        """
        if not items:
            return ParallelResult(
                results=[],
                wall_clock_ms=0.0,
                worker_count=0,
                items_total=0,
                items_succeeded=0,
                items_failed=0,
                speedup_ratio=1.0,
                straggler_ratio=1.0,
            )

        effective_workers = min(max(self.max_workers, 1), len(items))
        total_start = time.monotonic()
        results_by_index: dict[int, WorkerResult[T]] = {}

        with ThreadPoolExecutor(max_workers=effective_workers) as executor:
            futures: dict[Future[T], int] = {}
            item_starts: dict[int, float] = {}
            # Record true completion timestamps via done callbacks
            # so elapsed_ms reflects actual task duration, not
            # iteration-order artifacts (ADR-072 timing semantics).
            completion_times: dict[int, float] = {}

            for idx, (item_key, fn) in enumerate(items):
                if idx > 0 and self.worker_delay_s > 0:
                    time.sleep(self.worker_delay_s)
                item_starts[idx] = time.monotonic()
                future = executor.submit(fn)
                future.add_done_callback(
                    lambda f, i=idx: completion_times.__setitem__(
                        i, time.monotonic()
                    )
                )
                futures[future] = idx

            # Collect completed futures with overall timeout
            remaining = self._remaining_timeout(
                total_start, overall_timeout_s
            )
            completed_futures: set[Future[T]] = set()
            try:
                for future in as_completed(futures, timeout=remaining):
                    completed_futures.add(future)
                    idx = futures[future]
                    item_key = items[idx][0]
                    elapsed_ms = (
                        completion_times.get(idx, time.monotonic())
                        - item_starts[idx]
                    ) * 1000

                    try:
                        result_val = future.result()
                        worker_result: WorkerResult[T] = WorkerResult(
                            index=idx,
                            item_key=item_key,
                            result=result_val,
                            error=None,
                            status="success",
                            elapsed_ms=round(elapsed_ms, 1),
                        )
                    except Exception as exc:
                        worker_result = WorkerResult(
                            index=idx,
                            item_key=item_key,
                            result=None,
                            error=exc,
                            status="error",
                            elapsed_ms=round(elapsed_ms, 1),
                        )

                    results_by_index[idx] = worker_result
                    self._notify_callback(worker_result)

            except TimeoutError:
                # Overall timeout expired; mark remaining as timed out
                pass

            # Mark any futures not yet collected as timed out
            for future, idx in futures.items():
                if future not in completed_futures:
                    item_key = items[idx][0]
                    elapsed_ms = (
                        completion_times.get(idx, time.monotonic())
                        - item_starts[idx]
                    ) * 1000
                    worker_result = WorkerResult(
                        index=idx,
                        item_key=item_key,
                        result=None,
                        error=TimeoutError(
                            f"{self.label} item {item_key!r} timed out"
                        ),
                        status="timeout",
                        elapsed_ms=round(elapsed_ms, 1),
                    )
                    results_by_index[idx] = worker_result
                    self._notify_callback(worker_result)
                    future.cancel()

        wall_clock_ms = (time.monotonic() - total_start) * 1000
        ordered_results = [results_by_index[i] for i in range(len(items))]

        # Compute metrics
        items_succeeded = sum(
            1 for r in ordered_results if r.status == "success"
        )
        items_failed = len(ordered_results) - items_succeeded

        per_item_ms = [r.elapsed_ms for r in ordered_results]
        sum_per_item = sum(per_item_ms) if per_item_ms else wall_clock_ms
        speedup_ratio = (
            round(sum_per_item / wall_clock_ms, 2)
            if wall_clock_ms > 0
            else 1.0
        )

        if len(per_item_ms) >= 2 and min(per_item_ms) > 0:
            straggler_ratio = round(max(per_item_ms) / min(per_item_ms), 2)
        else:
            straggler_ratio = 1.0

        parallel_result = ParallelResult(
            results=ordered_results,
            wall_clock_ms=round(wall_clock_ms, 1),
            worker_count=effective_workers,
            items_total=len(items),
            items_succeeded=items_succeeded,
            items_failed=items_failed,
            speedup_ratio=speedup_ratio,
            straggler_ratio=straggler_ratio,
        )

        self._notify_execution_complete(parallel_result)
        return parallel_result

    def _notify_callback(self, worker_result: WorkerResult[T]) -> None:
        """Invoke on_item_complete callback with error isolation."""
        if self.on_item_complete is None:
            return
        try:
            self.on_item_complete(worker_result)
        except Exception:
            logger.debug(
                "%s: on_item_complete callback failed for %s",
                self.label,
                worker_result.item_key,
                exc_info=True,
            )

    def _notify_execution_complete(
        self, parallel_result: ParallelResult[T]
    ) -> None:
        """Invoke on_execution_complete callback with error isolation."""
        if self.on_execution_complete is None:
            return
        try:
            self.on_execution_complete(parallel_result)
        except Exception:
            logger.debug(
                "%s: on_execution_complete callback failed",
                self.label,
                exc_info=True,
            )

    @staticmethod
    def _remaining_timeout(
        start: float,
        overall_timeout_s: float | None,
    ) -> float | None:
        """Compute remaining time budget from overall timeout."""
        if overall_timeout_s is None:
            return None
        elapsed = time.monotonic() - start
        remaining = overall_timeout_s - elapsed
        return max(remaining, 0)
