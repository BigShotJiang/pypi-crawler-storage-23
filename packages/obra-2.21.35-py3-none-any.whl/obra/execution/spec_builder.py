"""Orchestrator functions for the typed LLM pipeline.

This module provides three orchestrator functions that coordinate the
three-stage typed pipeline:

1. build_command_spec() - Stage 1: Extract high-level intent from config
2. build_provider_spec() - Stage 2: Dispatch to provider-specific builders
3. build_exec_spec() - Stage 3: Assemble subprocess.Popen-ready ExecSpec

These orchestrators are the entry points for the typed pipeline, replacing
the monolithic build_llm_args() function.

Related:
    - docs/design/briefs/ECL_PHASE2_TYPED_PIPELINE_BRIEF.md
    - obra/execution/pipeline_types.py (dataclass definitions)
    - obra/execution/provider_specs.py (provider-specific builders)
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import replace
from pathlib import Path

from obra.execution.os_compat import (
    EnvironmentProfile,
    build_popen_kwargs,
    build_subprocess_env,
)
from obra.execution.pipeline_types import CommandSpec, ExecSpec, ProviderSpec
from obra.execution.provider_specs import (
    build_anthropic_spec,
    build_default_spec,
    build_google_spec,
    build_ollama_spec,
    build_openai_spec,
)

logger = logging.getLogger(__name__)

# Shell command-line buffer limit for inline prompt delivery (protocol constant)
INLINE_PROMPT_MAX_CHARS = 4000


def _build_tool_restriction_prompt(allowed_tools: list[str]) -> str:
    tools = ", ".join(allowed_tools)
    return (
        f"CRITICAL: You MUST ONLY use these tools: {tools}. "
        "Do NOT use Write, Edit, or Bash under any circumstances."
    )


def _apply_tool_restrictions(
    cmd_spec: CommandSpec,
    provider_spec: ProviderSpec,
) -> ProviderSpec:
    """Apply tool restriction controls to a provider spec.

    Anthropic supports explicit `--allowedTools`. Other providers currently
    receive an explicit prompt-level restriction via provider metadata.
    """
    if cmd_spec.allowed_tools is None:
        return provider_spec

    allowed_tools = cmd_spec.allowed_tools
    provider = cmd_spec.provider.lower()

    if provider == "anthropic":
        return replace(
            provider_spec,
            argv=[*provider_spec.argv, "--allowedTools", ",".join(allowed_tools)],
        )

    restriction_prompt = _build_tool_restriction_prompt(allowed_tools)
    provider_meta = {
        **provider_spec.provider_meta,
        "tool_restriction_prompt": restriction_prompt,
    }
    return replace(provider_spec, provider_meta=provider_meta)


def build_command_spec(
    config: dict,
    mode: str,
    response_format: str,
    cwd: Path,
    streaming: bool,
    timeout_s: int,
    auth_method: str,
    allowed_tools: list[str] | None = None,
) -> CommandSpec:
    """Build CommandSpec from resolved LLM configuration.

    Extracts high-level intent (provider, model, thinking, mode, etc) from
    the config dict and produces a frozen CommandSpec. This is Stage 1 of
    the typed pipeline.

    Args:
        config: Resolved config dict with provider, model, reasoning_level, etc
        mode: Operation mode - "text" for derive/examine, "execute" for execute/fix
        response_format: Response format - "json" or "text"
        cwd: Working directory for LLM subprocess
        streaming: Whether to enable streaming output
        timeout_s: Timeout in seconds for LLM subprocess
        auth_method: Authentication method (e.g., "api_key")
        allowed_tools: Optional list of allowed tool names. None means no
            additional restriction.

    Returns:
        Frozen CommandSpec with spec_id assigned for correlation
    """
    # Extract fields from config
    provider = config.get("provider", "anthropic")
    model = config.get("model", "default")
    reasoning_level = config.get("reasoning_level", "off")
    provider_reasoning_level = config.get("provider_reasoning_level")

    # Extract Codex-specific config (if present)
    codex_config = config.get("codex")
    if isinstance(codex_config, dict):
        # Preserve codex config dict for OpenAI builder
        pass
    else:
        codex_config = None

    return CommandSpec(
        provider=provider,
        model=model,
        mode=mode,
        response_format=response_format,
        reasoning_level=reasoning_level,
        provider_reasoning_level=provider_reasoning_level,
        cwd=cwd,
        streaming=streaming,
        timeout_s=timeout_s,
        auth_method=auth_method,
        codex_config=codex_config,
        allowed_tools=allowed_tools,
        spec_id=str(uuid.uuid4()),  # Assign correlation ID
    )


def build_provider_spec(
    cmd_spec: CommandSpec,
    profile: EnvironmentProfile,
) -> ProviderSpec:
    """Build ProviderSpec by dispatching to provider-specific builder.

    This is Stage 2 of the typed pipeline. Dispatches to the appropriate
    provider-specific builder based on cmd_spec.provider.

    Args:
        cmd_spec: High-level command specification with user intent
        profile: Resolved OS environment profile for platform-specific decisions

    Returns:
        ProviderSpec with provider-specific argv, env, and execution config

    Dispatch map:
        - anthropic -> build_anthropic_spec()
        - openai -> build_openai_spec()
        - google -> build_google_spec()
        - ollama -> build_ollama_spec()
        - fallback (unknown) -> build_default_spec()
    """
    # Provider dispatch map
    provider_builders = {
        "anthropic": build_anthropic_spec,
        "openai": build_openai_spec,
        "google": build_google_spec,
        "ollama": build_ollama_spec,
    }

    # Get provider-specific builder or fall back to default
    builder = provider_builders.get(cmd_spec.provider, build_default_spec)

    provider_spec = builder(cmd_spec, profile)
    return _apply_tool_restrictions(cmd_spec, provider_spec)


def build_exec_spec(
    provider_spec: ProviderSpec,
    profile: EnvironmentProfile,
    cmd_spec: CommandSpec,
    prompt: str,
    *,
    prompt_manager: "PromptFileManager | None" = None,
) -> ExecSpec:
    """Build ExecSpec from ProviderSpec, assembling subprocess.Popen-ready args.

    This is Stage 3 of the typed pipeline. Combines provider-specific argv
    with platform-specific environment, preexec_fn, and prompt delivery to
    produce a frozen ExecSpec ready for subprocess.Popen.

    Args:
        provider_spec: Provider-specific command construction from Stage 2
        profile: Resolved OS environment profile for encoding and preexec_fn
        cmd_spec: Original CommandSpec for cwd, timeout_s, streaming, auth_method
        prompt: Prompt text content for delivery (file or inline)
        prompt_manager: Optional PromptFileManager for file-based prompt delivery.
            If None and prompt_delivery is 'file', a default manager is created.

    Returns:
        Frozen ExecSpec with all fields resolved for subprocess.Popen

    Raises:
        NotImplementedError: If prompt_delivery is 'stdin' (deferred to Phase 3)
    """
    # 1. Build base command: [cli_executable, *argv]
    base_cmd = [provider_spec.cli_executable, *provider_spec.argv]

    # 2. Build subprocess environment with auth-aware API key handling
    env = build_subprocess_env(
        cmd_spec.auth_method,
        extra_env=provider_spec.env_overrides,
    )

    # 3. Resolve preexec_fn from platform profile
    popen_kwargs = build_popen_kwargs()
    preexec_fn = popen_kwargs.get("preexec_fn")

    # Inject prompt-level tool restrictions for providers that don't expose a
    # CLI-level allowlist flag.
    effective_prompt = prompt
    restriction_prompt = provider_spec.provider_meta.get("tool_restriction_prompt")
    if (
        isinstance(restriction_prompt, str)
        and restriction_prompt.strip()
        and cmd_spec.provider.lower() != "anthropic"
    ):
        effective_prompt = f"{restriction_prompt}\n\n{prompt}"

    # 4. Handle prompt delivery
    temp_files: list[str] = []
    prompt_delivery = provider_spec.prompt_delivery

    if prompt_delivery == "stdin":
        raise NotImplementedError("stdin delivery deferred to Phase 3 (R10)")

    if prompt_delivery == "inline" and len(effective_prompt) > INLINE_PROMPT_MAX_CHARS:
        # Fall back to file delivery for prompts exceeding shell buffer limit
        logger.debug(
            "Inline prompt exceeds %d chars (%d), falling back to file delivery",
            INLINE_PROMPT_MAX_CHARS,
            len(effective_prompt),
        )
        prompt_delivery = "file"

    if prompt_delivery == "file":
        # Lazy import to avoid circular dependency
        from obra.hybrid.prompt_file import PromptFileManager as _PromptFileManager

        if prompt_manager is None:
            from obra.config.loaders import get_prompt_max_files, get_prompt_retention

            prompt_manager = _PromptFileManager(
                cmd_spec.cwd,
                retain=get_prompt_retention(),
                max_files=get_prompt_max_files(),
            )

        prompt_path, prompt_instruction = prompt_manager.write_prompt(
            effective_prompt,
            use_absolute=provider_spec.use_absolute_paths,
            path_format=profile.path_format,
        )
        temp_files.append(str(prompt_path))
        prompt_argument = prompt_instruction
    else:
        # Inline delivery: prompt text appended directly to command
        prompt_argument = effective_prompt

    # 5. Assemble full command with prompt argument
    cmd = [*base_cmd, prompt_argument]

    return ExecSpec(
        cmd=cmd,
        env=env,
        cwd=str(cmd_spec.cwd),
        encoding=profile.encoding,
        preexec_fn=preexec_fn,
        shell=False,
        timeout_s=cmd_spec.timeout_s,
        streaming=cmd_spec.streaming,
        temp_files=temp_files,
        spec_id=provider_spec.spec_id,
    )
