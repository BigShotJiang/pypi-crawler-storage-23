"""Extraction strategies"""
