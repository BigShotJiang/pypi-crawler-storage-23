# Ultrian

Ultrian is a high-level Python library for working with modern language models in a simple and efficient way.

It provides a clean and minimal interface for text generation, embeddings, and model interaction — allowing developers to focus on building products instead of managing model complexity.
also ultrian is a part of Thon AI project- thon-ai.kesug.com
---

## 🚀 Features

- Simple text generation
- Clean API
- Fast model initialization
- Lightweight abstraction
- Designed for production-ready workflows

---

## 📦 Installation

```bash
pip install ultrian