"""Infrastructure: Ollama client, run repository, tools, specialists."""
