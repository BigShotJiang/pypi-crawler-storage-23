from the_file_tool.convert_handler import handle_conversion

handle_conversion('/Users/xydra01/The_File_Tool/app/file_tool/test/Screenshot 2026-02-05 at 10.30.09 PM.png', '.jpeg', '/Users/xydra01/The_File_Tool/app/file_tool/src/output')