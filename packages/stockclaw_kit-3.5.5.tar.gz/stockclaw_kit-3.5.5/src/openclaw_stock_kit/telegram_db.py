#!/usr/bin/env python3
"""Telegram DB Module

SQLite 기반 텔레그램 메시지 저장/조회 모듈.
DB 파일 위치: {config_dir}/telegram.db
"""

import math
import sqlite3
from pathlib import Path


# ─── DDL ───────────────────────────────────────────────────────
_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS telegram_messages (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id    TEXT NOT NULL,
    channel_name  TEXT,
    message_id    INTEGER,
    content       TEXT,
    message_date  TEXT,
    views         INTEGER DEFAULT 0,
    is_ad         INTEGER DEFAULT 0,
    image_url     TEXT,
    urls          TEXT,
    grouped_id    TEXT,
    collected_at  TEXT DEFAULT (datetime('now', 'localtime'))
);
"""

_CREATE_IDX_CHANNEL_MSG_SQL = """
CREATE UNIQUE INDEX IF NOT EXISTS idx_channel_msg
    ON telegram_messages(channel_id, message_id);
"""

_CREATE_IDX_CHANNEL_SQL = """
CREATE INDEX IF NOT EXISTS idx_channel ON telegram_messages(channel_id);
"""

_CREATE_IDX_DATE_SQL = """
CREATE INDEX IF NOT EXISTS idx_date ON telegram_messages(message_date DESC);
"""

_CREATE_IDX_COLLECTED_SQL = """
CREATE INDEX IF NOT EXISTS idx_collected ON telegram_messages(collected_at DESC);
"""


class TelegramDB:
    """텔레그램 메시지 SQLite 저장소. 요청마다 커넥션을 열고 닫음."""

    def __init__(self, config_dir: str):
        db_dir = Path(config_dir)
        db_dir.mkdir(parents=True, exist_ok=True)
        self._db_path = str(db_dir / "telegram.db")
        # 초기화: 스키마 생성
        with self._connect() as conn:
            conn.execute(_CREATE_TABLE_SQL)
            conn.execute(_CREATE_IDX_CHANNEL_MSG_SQL)
            conn.execute(_CREATE_IDX_CHANNEL_SQL)
            conn.execute(_CREATE_IDX_DATE_SQL)
            conn.execute(_CREATE_IDX_COLLECTED_SQL)
            conn.commit()

    def _connect(self):
        """새 커넥션을 열고 WAL + busy_timeout 설정."""
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        return conn

    def save_messages(self, messages: list) -> dict:
        """메시지 배치 저장. INSERT OR REPLACE로 중복 시 업데이트.

        messages: [{"channel_id": str, "channel_name": str, "message_id": int,
                    "content": str, "message_date": str, "views": int,
                    "is_ad": bool/int, "image_url": str,
                    "urls": str(JSON), "grouped_id": str}]
        Returns: {"saved": int, "duplicates": int}
        """
        saved = 0
        duplicates = 0
        with self._connect() as conn:
            cur = conn.cursor()
            for msg in messages:
                channel_id = msg.get("channel_id", "")
                if not channel_id:
                    duplicates += 1
                    continue
                # bool → int 변환
                is_ad = msg.get("is_ad", 0)
                if isinstance(is_ad, bool):
                    is_ad = 1 if is_ad else 0
                else:
                    is_ad = int(is_ad) if is_ad else 0

                cur.execute(
                    """INSERT OR REPLACE INTO telegram_messages
                        (channel_id, channel_name, message_id, content,
                         message_date, views, is_ad, image_url, urls, grouped_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        channel_id,
                        msg.get("channel_name", ""),
                        msg.get("message_id"),
                        msg.get("content", ""),
                        msg.get("message_date", ""),
                        msg.get("views", 0),
                        is_ad,
                        msg.get("image_url", ""),
                        msg.get("urls", ""),
                        msg.get("grouped_id", ""),
                    ),
                )
                if cur.rowcount == 1:
                    saved += 1
                else:
                    duplicates += 1
            conn.commit()
        return {"saved": saved, "duplicates": duplicates}

    def get_messages(
        self,
        channel_id: str = "",
        keyword: str = "",
        start_date: str = "",
        end_date: str = "",
        is_ad: str = "",
        limit: int = 50,
        page: int = 1,
    ) -> dict:
        """메시지 조회 with 필터링 + 페이지네이션.

        Returns: {"messages": [...], "pagination": {"page": int, "totalPages": int, "total": int}}
        - channel_id 필터 (비어있으면 전체)
        - keyword: content LIKE %keyword%
        - start_date / end_date: message_date 범위
        - is_ad: "true"=광고만, "false"=광고제외, ""=전체
        - ORDER BY message_date DESC
        """
        conditions = []
        params = []

        if channel_id:
            conditions.append("channel_id = ?")
            params.append(channel_id)
        if keyword:
            conditions.append("content LIKE ?")
            params.append(f"%{keyword}%")
        if start_date:
            conditions.append("message_date >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("message_date <= ?")
            params.append(end_date)
        if is_ad == "true":
            conditions.append("is_ad = 1")
        elif is_ad == "false":
            conditions.append("is_ad = 0")

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""

        offset = (max(page, 1) - 1) * limit

        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                f"SELECT COUNT(*) FROM telegram_messages {where}",
                params,
            )
            total = cur.fetchone()[0]
            cur.execute(
                f"""SELECT id, channel_id, channel_name, message_id, content,
                           message_date, views, is_ad, image_url, urls,
                           grouped_id, collected_at
                    FROM telegram_messages {where}
                    ORDER BY message_date DESC
                    LIMIT ? OFFSET ?""",
                params + [limit, offset],
            )
            messages_data = [dict(row) for row in cur.fetchall()]

        total_pages = math.ceil(total / limit) if limit > 0 else 1
        return {
            "messages": messages_data,
            "pagination": {
                "page": page,
                "totalPages": total_pages,
                "total": total,
            },
        }

    def get_channels(self) -> list:
        """저장된 채널 목록 + 메시지 수.

        Returns: [{"channel_id": str, "channel_name": str, "message_count": int}]
        - GROUP BY channel_id
        - ORDER BY message_count DESC
        """
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """SELECT channel_id,
                          MAX(channel_name) AS channel_name,
                          COUNT(*) AS message_count
                   FROM telegram_messages
                   GROUP BY channel_id
                   ORDER BY message_count DESC"""
            )
            return [dict(row) for row in cur.fetchall()]

    def delete_messages(self, ids: list) -> int:
        """id 목록으로 삭제."""
        if not ids:
            return 0
        placeholders = ",".join("?" * len(ids))
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                f"DELETE FROM telegram_messages WHERE id IN ({placeholders})",
                ids,
            )
            conn.commit()
            return cur.rowcount

    def get_stats(self) -> dict:
        """통계: {"total_messages": int, "total_channels": int, "oldest": str, "newest": str}"""
        with self._connect() as conn:
            cur = conn.cursor()
            cur.execute(
                """SELECT
                       COUNT(*) AS total_messages,
                       COUNT(DISTINCT channel_id) AS total_channels,
                       MIN(message_date) AS oldest,
                       MAX(message_date) AS newest
                   FROM telegram_messages"""
            )
            row = cur.fetchone()
            if row:
                return {
                    "total_messages": row["total_messages"],
                    "total_channels": row["total_channels"],
                    "oldest": row["oldest"] or "",
                    "newest": row["newest"] or "",
                }
        return {
            "total_messages": 0,
            "total_channels": 0,
            "oldest": "",
            "newest": "",
        }

    def close(self) -> None:
        """호환성 유지 (이제 no-op)."""
        pass
