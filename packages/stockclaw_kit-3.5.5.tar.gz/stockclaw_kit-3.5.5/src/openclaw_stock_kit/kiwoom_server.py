#!/usr/bin/env python3
"""키움증권 범용 도구 서버 (로컬 — 사용자 컨테이너)

PDR v7 정의: 사용자별 API키로 키움 REST API 185개 전체 호출
포트: 8201
모의/실전: KIWOOM_ENV=mock → mockapi.kiwoom.com, KIWOOM_ENV=live → api.kiwoom.com

도구 11개:
  REST (4개):
  - kiwoom_call_api        : 185개 전체 REST API 범용 호출 + DB 자동저장
  - kiwoom_list_apis       : 사용 가능한 API 코드 카탈로그
  - kiwoom_get_env_info    : 현재 환경 정보 (env, base_url, 계좌번호)
  - kiwoom_api_spec        : API 스펙 조회 (파라미터/응답 구조 확인)

  WebSocket 조건검색 (4개, ka10171~10174):
  - kiwoom_condition_list  : 조건검색식 목록 조회 (ka10171/CNSRLST)
  - kiwoom_condition_search: 조건검색식 종목조회 (ka10172/CNSRREQ)
  - kiwoom_condition_realtime: 실시간 조건검색 등록 (ka10173/CNSRREQ search_type=1)
  - kiwoom_condition_stop  : 실시간 조건검색 해제 (ka10174/CNSRCLR)

  WebSocket 실시간 데이터 (3개, REG/REMOVE 패턴):
  - kiwoom_realtime_register: 실시간 데이터 등록 (0H, 0J, 00 등 19개 타입)
  - kiwoom_realtime_remove  : 실시간 데이터 해제
  - kiwoom_realtime_types   : 지원 실시간 타입 목록 조회

응답 표준 (STANDARD.md):
  성공: {"ok": true, "source": "kiwoom", "asof": "...", "data": {...}, "meta": {...}, "error": null}
  실패: {"ok": false, "source": "kiwoom", "asof": "...", "data": null, "meta": {...}, "error": {"code": "...", "message": "..."}}

DB 저장 흐름:
  1) hub_api_responses — 모든 API 응답 무조건 JSONB 저장
  2) 정규화 테이블 — api_code 라우팅 (7개 API → 5개 테이블)
     ka10001 → kiwoom_prices      (현재가)
     ka10079 → kiwoom_charts      (틱차트)
     ka10080 → kiwoom_charts      (분봉)
     ka10004 → kiwoom_orderbooks  (호가)
     kt00018 → kiwoom_balances    (잔고)
     kt10000 → kiwoom_orders      (매수)
     kt10001 → kiwoom_orders      (매도)

사용 예시:
    KIWOOM_ENV=mock python kiwoom_server.py
"""

import os
import sys
import json
import gzip
import base64
import hashlib
import re
from pathlib import Path
from typing import Any, Dict

# kiwoom_rest_client.py 임포트 (같은 디렉토리)
sys.path.insert(0, str(Path(__file__).parent))
import kiwoom_rest_client as krc
import kiwoom_ws_client as kwc
from response import ok_response, error_response, ErrorCode

import db_local  # 로컬 SQLite 모듈

# ─── api_code → 정규화 테이블 라우팅 ────────────────────────────
_NORMALIZED_ROUTES = {
    "ka10001": "prices",       # 현재가 → kiwoom_prices
    "ka10079": "charts",       # 틱차트 → kiwoom_charts
    "ka10080": "charts",       # 분봉 → kiwoom_charts
    "ka10004": "orderbooks",   # 호가 → kiwoom_orderbooks
    "kt00018": "balances",     # 잔고 → kiwoom_balances
    "kt10000": "orders",       # 매수주문 → kiwoom_orders
    "kt10001": "orders",       # 매도주문 → kiwoom_orders
}

def _db_save(api_code: str, params: dict, result: dict):
    """API 응답을 로컬 SQLite에 저장 (hub_api_responses + 정규화 테이블)"""
    try:
        db_local.save_hub(f"kiwoom:{api_code}", params, result)
        _db_save_normalized(api_code, params, result)
    except Exception as e:
        print(f"[DB] 저장 실패 (kiwoom:{api_code}): {e}")


def _db_save_normalized(api_code: str, params: dict, result: dict):
    """api_code 기반 정규화 테이블 라우팅 저장

    7개 api_code만 정규화 테이블에 추가 저장.
    나머지 178개 API는 hub_api_responses만으로 충분.
    실패 응답(ok=False)은 정규화하지 않음.
    """
    if not result.get("ok"):
        return

    route = _NORMALIZED_ROUTES.get(api_code)
    if not route:
        return  # 매핑 없는 API → hub_api_responses만 (이미 저장 완료)

    data = result.get("data", {})
    env = (result.get("meta") or {}).get("env", "mock")
    data_json = json.dumps(data, ensure_ascii=False, default=str)
    ticker = params.get("stk_cd", "")
    conn = db_local.get_conn()

    if route == "prices":
        conn.execute(
            "INSERT INTO kiwoom_prices (ticker, env, price_data) VALUES (?, ?, ?)",
            (ticker, env, data_json),
        )

    elif route == "charts":
        # ka10079: 틱차트, ka10080: 분봉
        if api_code == "ka10079":
            period = "tick"
        elif api_code == "ka10080":
            period = "minute"
        else:
            _period_map = {"1": "day", "2": "week", "3": "month"}
            period = _period_map.get(str(params.get("period_tp", "1")), "day")
        bar_count = int(params.get("req_cnt", 0))
        conn.execute(
            "INSERT INTO kiwoom_charts (ticker, period, bar_count, env, chart_data) VALUES (?, ?, ?, ?, ?)",
            (ticker, period, bar_count, env, data_json),
        )

    elif route == "orderbooks":
        conn.execute(
            "INSERT INTO kiwoom_orderbooks (ticker, env, orderbook) VALUES (?, ?, ?)",
            (ticker, env, data_json),
        )

    elif route == "balances":
        conn.execute(
            "INSERT INTO kiwoom_balances (env, balance_data) VALUES (?, ?)",
            (env, data_json),
        )

    elif route == "orders":
        conn.execute(
            "INSERT INTO kiwoom_orders (ticker, side, qty, price, env, order_data) VALUES (?, ?, ?, ?, ?, ?)",
            (
                ticker,
                "buy" if api_code == "kt10000" else "sell",
                int(params.get("ord_qty", 0)),
                int(params.get("ord_prc", 0)),
                env,
                data_json,
            ),
        )

    conn.commit()


# ─── API 스펙 데이터 (lazy 로딩 + 캐시) ─────────────────────
_DATA_DIR = Path(__file__).parent / "data"
_min_cache: dict | None = None
_lossless_raw: str | None = None


def _load_min() -> dict:
    """kiwoom_api_min.json 로드 (최초 1회, 이후 캐시)"""
    global _min_cache
    if _min_cache is not None:
        return _min_cache
    min_path = _DATA_DIR / "kiwoom_api_min.json"
    if not min_path.exists():
        return {}
    with open(min_path, "r", encoding="utf-8") as f:
        _min_cache = json.load(f)
    return _min_cache


def _load_lossless_raw() -> str:
    """kiwoom_api_lossless.json → gzip+base64 디코딩 → 마크다운 텍스트"""
    global _lossless_raw
    if _lossless_raw is not None:
        return _lossless_raw
    lossless_path = _DATA_DIR / "kiwoom_api_lossless.json"
    if not lossless_path.exists():
        return ""
    with open(lossless_path, "r", encoding="utf-8") as f:
        obj = json.load(f)
    _lossless_raw = gzip.decompress(base64.b64decode(obj["payload"])).decode("utf-8")
    return _lossless_raw


def _extract_full(api_code: str) -> str:
    """lossless 마크다운에서 특정 API 섹션만 추출"""
    raw = _load_lossless_raw()
    if not raw:
        return ""
    pattern = re.compile(
        r'^(## ' + re.escape(api_code) + r' .+?)(?=^## [a-z]|\Z)',
        re.MULTILINE | re.DOTALL,
    )
    m = pattern.search(raw)
    return m.group(1).strip() if m else ""


# ─── 도구 8개 ──────────────────────────────────────────

def register_tools(registry, get_pg=None):
    """ToolRegistry 인스턴스에 Kiwoom 도구 8개 등록

    get_pg: 하위 호환성을 위해 유지하되 내부에서 무시 (SQLite 사용)
    """

    @registry.tool()
    def kiwoom_call_api(api_code: str, payload_json: str = "{}") -> dict:
        """키움증권 실시간 시세 + 매매 — 185개 API (키움 계좌/인증 필요)

        USE THIS WHEN: 실시간 현재가, 호가, 체결, 순위, 주문 실행
        DO NOT USE: 과거 주가/차트 분석 → datakit_call (무료), 뉴스 → news_search_stock

        Args:
            api_code: 키움 API 코드 (예: "ka10001" 현재가, "ka10079" 일봉, "kt00018" 잔고)
            payload_json: JSON 문자열 파라미터 (예: '{"stk_cd":"005930"}')

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "asof": "2026-02-18T09:30:00+09:00",
                "data": { ... API 응답 ... },
                "meta": {"env": "mock", "api_code": "ka10001"},
                "error": null
            }

        DB 자동저장:
            - hub_api_responses: 모든 API 무조건 저장 (JSONB 통합 로그)
            - kiwoom_prices: ka10001 (현재가)
            - kiwoom_charts: ka10079/ka10080 (차트)
            - kiwoom_orderbooks: ka10004 (호가)
            - kiwoom_balances: kt00018 (잔고)
            - kiwoom_orders: kt10000/kt10001 (주문)

        Note:
            kiwoom_list_apis()로 사용 가능한 185개 API 코드 목록 확인 가능.
        """
        try:
            payload = json.loads(payload_json) if payload_json else {}
        except json.JSONDecodeError:
            return error_response(
                ErrorCode.INVALID_PARAMS, "payload_json 파싱 실패",
                source="kiwoom", meta={"api_code": api_code},
            )

        # issueToken 특별 처리
        if api_code == "issueToken":
            try:
                token_data = krc.fetch_token(force=True)
                return ok_response(
                    {"success": True, "token": token_data.get("token", ""),
                     "expires_at": token_data.get("expires_dt", ""),
                     "token_status": "valid", "env": token_data.get("env", "")},
                    source="kiwoom", meta={"api_code": "issueToken"}
                )
            except krc.KiwoomError as e:
                return error_response(
                    ErrorCode.API_ERROR, str(e),
                    source="kiwoom", meta={"api_code": "issueToken"}
                )

        try:
            data = krc.call_api(api_code, payload)
            result = ok_response(data, source="kiwoom", meta={"env": krc.pick_env(), "api_code": api_code})
        except krc.KiwoomError as e:
            result = error_response(
                ErrorCode.API_ERROR, str(e),
                source="kiwoom", meta={"api_code": api_code},
            )
        except Exception as e:
            result = error_response(
                ErrorCode.UNKNOWN, str(e),
                source="kiwoom", meta={"api_code": api_code},
            )

        try:
            _db_save(api_code, payload, result)
        except Exception as e:
            print(f"[Kiwoom DB] {api_code} 저장 실패: {e}")
        return result


    @registry.tool()
    def kiwoom_list_apis() -> dict:
        """키움증권 185개 전체 API 코드 카탈로그

        Returns:
            카테고리별 API 코드 목록 + 정규화 테이블 매핑 + 사용법 예시
        """
        categories = {}
        for tr_code, cat in krc._TR_CATEGORY.items():
            categories.setdefault(cat, []).append(tr_code)

        cat_names = {
            "stkinfo": "종목정보", "mrkcond": "시세/호가", "frgnistt": "외국인/기관",
            "sect": "업종", "rkinfo": "순위", "chart": "차트", "acnt": "계좌",
            "elw": "ELW", "etf": "ETF", "thme": "테마", "slb": "대차거래",
            "ordr": "주문", "crdordr": "신용주문",
        }

        result = []
        total = 0
        for cat, codes in sorted(categories.items()):
            codes_sorted = sorted(codes)
            total += len(codes_sorted)
            result.append({
                "category": cat,
                "name": cat_names.get(cat, cat),
                "count": len(codes_sorted),
                "api_codes": codes_sorted,
            })

        return ok_response(
            {
                "total_api_count": total,
                "categories": result,
                "normalized_tables": {
                    "ka10001": "kiwoom_prices (현재가)",
                    "ka10079": "kiwoom_charts (틱차트)",
                    "ka10080": "kiwoom_charts (분봉)",
                    "ka10004": "kiwoom_orderbooks (호가)",
                    "kt00018": "kiwoom_balances (잔고)",
                    "kt10000": "kiwoom_orders (매수)",
                    "kt10001": "kiwoom_orders (매도)",
                },
                "usage_examples": [
                    'kiwoom_call_api(api_code="ka10001", payload_json=\'{"stk_cd":"005930"}\')',
                    'kiwoom_call_api(api_code="ka10081", payload_json=\'{"stk_cd":"005930","base_dt":"20260224","adj_prc_tp":"1"}\')',
                    'kiwoom_call_api(api_code="ka10004", payload_json=\'{"stk_cd":"005930"}\')',
                ],
            },
            source="kiwoom",
        )


    @registry.tool()
    def kiwoom_get_env_info() -> dict:
        """현재 키움 도구 서버 환경 정보 조회

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "env": "mock" or "live",
                    "base_url": "...",
                    "account_no": "12345678" or null,
                    "total_api_count": 185,
                    "normalized_routes": 7
                }
            }
        """
        try:
            data = {
                "env": krc.pick_env(),
                "base_url": krc.get_base_url(),
                "creds_path": str(krc.creds_path()),
                "token_cache_path": str(krc.token_cache_path()),
                "account_no": os.environ.get("KIWOOM_ACCOUNT_NO"),
                "total_api_count": len(krc._TR_CATEGORY),
                "normalized_routes": len(_NORMALIZED_ROUTES),
            }
            return ok_response(data, source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


    @registry.tool()
    def kiwoom_api_spec(api_code: str = "", detail: str = "min") -> dict:
        """키움 REST API 스펙 조회. 파라미터/응답 구조 확인용.

        USE THIS FIRST: API 호출 전 파라미터 확인이 필요할 때
        THEN USE: kiwoom_call_api로 실제 호출

        Args:
            api_code: API 코드 (예: "ka10001"). 빈 값이면 전체 목록.
            detail: "min" = 파라미터명만 (기본), "full" = 원문 전체 스펙

        Returns:
            min: {name, cat, method, url, req{field: {type, required, desc, values?}}, res[]}
                 req의 각 필드에 type/required/desc가 포함되며,
                 values가 있으면 허용값 사전 (예: {"000": "전체", "001": "코스피"})
            full: 원문 마크다운 섹션 (Request/Response 필드 전체)

        Examples:
            kiwoom_api_spec("ka10001")          → 현재가 API 파라미터 확인
            kiwoom_api_spec("ka10001", "full")  → 현재가 API 전체 스펙
            kiwoom_api_spec("")                 → 188개 전체 목록 (카테고리별)
        """
        try:
            min_data = _load_min()
            if not min_data:
                return error_response(
                    ErrorCode.DATA_UNAVAILABLE, "API 스펙 데이터 없음 (kiwoom_api_min.json)",
                    source="kiwoom",
                )

            # 전체 목록 (api_code 비어있을 때)
            if not api_code:
                grouped = {}
                for code, info in sorted(min_data.items()):
                    cat = info.get("cat", "etc")
                    grouped.setdefault(cat, []).append({
                        "code": code,
                        "name": info["name"],
                        "method": info["method"],
                        "url": info["url"],
                    })
                return ok_response(
                    {"total": len(min_data), "categories": grouped},
                    source="kiwoom",
                )

            # 개별 API 조회
            if api_code not in min_data:
                return error_response(
                    ErrorCode.NOT_FOUND,
                    f"'{api_code}' 없음. kiwoom_api_spec('')으로 전체 목록 확인",
                    source="kiwoom",
                )

            if detail == "full":
                full_text = _extract_full(api_code)
                if not full_text:
                    return error_response(
                        ErrorCode.DATA_UNAVAILABLE,
                        f"'{api_code}' 원문 데이터 없음 (kiwoom_api_lossless.json)",
                        source="kiwoom",
                    )
                return ok_response(
                    {"api_code": api_code, "detail": "full", "spec": full_text},
                    source="kiwoom",
                )

            # min (기본)
            return ok_response(
                {"api_code": api_code, "detail": "min", "spec": min_data[api_code]},
                source="kiwoom",
            )

        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


    # ── WebSocket 조건검색 도구 4개 (ka10171~10174) ─────────────────

    @registry.tool()
    async def kiwoom_condition_list() -> dict:
        """키움 조건검색식 목록 조회 (ka10171/CNSRLST — WebSocket)

        USE THIS WHEN: HTS에 저장된 조건검색식 목록이 필요할 때.
        REQUIRES: 키움 HTS에서 조건검색식을 사전 등록해야 함.

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "conditions": [{"seq": "0", "name": "조건명"}, ...],
                    "count": N
                }
            }
        """
        try:
            data = await kwc.get_condition_list()
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @registry.tool()
    async def kiwoom_condition_search(
        seq: str,
        search_type: str = "0",
        stex_tp: str = "K",
    ) -> dict:
        """키움 조건검색식 종목조회 (ka10172/CNSRREQ — WebSocket)

        USE kiwoom_condition_list() FIRST to get available seq values.

        Args:
            seq: 조건검색식 순번 (kiwoom_condition_list로 조회)
            search_type: "0" = 일반조회(기본), "1" = 실시간등록(→ kiwoom_condition_realtime 권장)
            stex_tp: 거래소 구분. "K" = KRX (기본값, 현재 유일한 유효값)

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {
                    "seq": "1",
                    "stk_list": [
                        {"stk_cd": "A005930", "stk_nm": "삼성전자",
                         "price": "75000", "volume": "10386116", ...}
                    ],
                    "stk_cnt": 15
                }
            }
        """
        try:
            data = await kwc.search_condition(seq, search_type, stex_tp)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @registry.tool()
    async def kiwoom_condition_realtime(seq: str, stex_tp: str = "K") -> dict:
        """키움 실시간 조건검색 등록 (ka10173/CNSRREQ search_type=1 — WebSocket)

        USE THIS WHEN: 조건검색식 실시간 모니터링 등록이 필요할 때.
        NOTE: 요청-응답 특성상 실시간 스트림이 아닌 등록 응답(초기 종목코드 목록)만 반환.
              등록 해제는 kiwoom_condition_stop(seq) 사용.

        Args:
            seq: 조건검색식 순번 (kiwoom_condition_list로 조회)
            stex_tp: 거래소 구분. "K" = KRX (기본값, 현재 유일한 유효값)

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {"seq": "1", "stk_list": [{"stk_cd": "A005930"}, ...],
                         "stk_cnt": N, "registered": true}
            }
        """
        try:
            data = await kwc.search_condition(seq, search_type="1", stex_tp=stex_tp)
            data["registered"] = True
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @registry.tool()
    async def kiwoom_condition_stop(seq: str) -> dict:
        """키움 실시간 조건검색 해제 (ka10174/CNSRCLR — WebSocket)

        USE THIS WHEN: kiwoom_condition_realtime()으로 등록한 조건검색을 해제할 때.

        Args:
            seq: 해제할 조건검색식 순번

        Returns:
            {
                "ok": true,
                "source": "kiwoom",
                "data": {"seq": "1", "return_msg": "해제 완료"}
            }
        """
        try:
            data = await kwc.stop_condition(seq)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    # ── WebSocket 실시간 데이터 도구 3개 (REG/REMOVE 패턴) ─────────

    @registry.tool()
    async def kiwoom_realtime_register(
        items: str,
        types: str,
        grp_no: str = "1",
        refresh: str = "1",
    ) -> dict:
        """키움 실시간 데이터 등록 (REG — WebSocket)

        USE THIS WHEN: 특정 종목의 실시간 체결/호가/잔고 등 실시간 데이터 구독 등록.
        NOTE: 요청-응답 특성상 실시간 스트림이 아닌 등록 성공 응답만 반환.
              실시간 이벤트 수신은 watch engine에서 처리.

        지원 타입: 0H(주식체결), 0J(업종지수), 00(주문체결), 04(잔고),
        0A(주식기심), 0B(주식체결), 0C(주식우선호가), 0D(주식호가잔량),
        0E(주식시간외호가), 0F(주식단일거래량), 0G(ETF), 0I(주요환율/금시세),
        0U(프로그램), 0g(주식예상체결), 0m(ELW이론가), 0s(장운영시간),
        0u(ELW지표), 0w(장외프로그램매매), 1h(VI발동/해제)

        Args:
            items: 종목코드 (쉼표 구분) "005930,000660"
            types: 실시간 타입 (쉼표 구분) "0H,0J"
            grp_no: 그룹번호 (기본 "1")
            refresh: "0"=기존유지추가, "1"=기존삭제후추가(기본)

        Returns:
            {"ok": true, "data": {"registered": true, "items": [...], "types": [...]}}
        """
        try:
            item_list = [s.strip() for s in items.split(",") if s.strip()]
            type_list = [s.strip() for s in types.split(",") if s.strip()]
            if not item_list or not type_list:
                return error_response(
                    ErrorCode.INVALID_PARAM,
                    "items와 types는 필수 (쉼표 구분)",
                    source="kiwoom",
                )
            data = await kwc.register_realtime(item_list, type_list, grp_no, refresh)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @registry.tool()
    async def kiwoom_realtime_remove(
        items: str,
        types: str,
        grp_no: str = "1",
    ) -> dict:
        """키움 실시간 데이터 해제 (REMOVE — WebSocket)

        USE THIS WHEN: kiwoom_realtime_register()로 등록한 실시간 구독 해제.

        Args:
            items: 종목코드 (쉼표 구분) "005930,000660"
            types: 실시간 타입 (쉼표 구분) "0H,0J"
            grp_no: 그룹번호 (기본 "1")

        Returns:
            {"ok": true, "data": {"removed": true, "items": [...], "types": [...]}}
        """
        try:
            item_list = [s.strip() for s in items.split(",") if s.strip()]
            type_list = [s.strip() for s in types.split(",") if s.strip()]
            if not item_list or not type_list:
                return error_response(
                    ErrorCode.INVALID_PARAM,
                    "items와 types는 필수 (쉼표 구분)",
                    source="kiwoom",
                )
            data = await kwc.remove_realtime(item_list, type_list, grp_no)
            return ok_response(data, source="kiwoom", meta={"env": krc.pick_env()})
        except kwc.KiwoomWsError as e:
            return error_response(ErrorCode.API_ERROR, str(e), source="kiwoom")
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")

    @registry.tool()
    def kiwoom_realtime_types() -> dict:
        """키움 실시간 데이터 타입 목록 조회

        USE THIS WHEN: kiwoom_realtime_register()에 사용 가능한 타입 확인.

        Returns:
            {"ok": true, "data": {"types": {"0H": "주식체결(종합)", ...}, "count": 19}}
        """
        try:
            types = kwc.list_realtime_types()
            return ok_response(
                {"types": types, "count": len(types)},
                source="kiwoom",
                meta={"env": krc.pick_env()},
            )
        except Exception as e:
            return error_response(ErrorCode.UNKNOWN, str(e), source="kiwoom")


if __name__ == "__main__":
    from openclaw_stock_kit.tool_registry import ToolRegistry
    registry = ToolRegistry("Kiwoom Data")
    register_tools(registry)

    print(f"Kiwoom Data — standalone test")
    print(f"   Environment: {krc.pick_env()}")
    print(f"   API Count: {len(krc._TR_CATEGORY)}")
    print(f"   Tools: {[t['name'] for t in registry.list_tools()]}")
