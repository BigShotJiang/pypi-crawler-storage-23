// ==================== 종목 진단 카드 (Stock Diagnosis) ====================
// 체결강도, VI 위험도, 고가거리 등 종합 분석

// 글로벌 상태
let diagnosisCache = {};  // 종목별 진단 캐시
let viStocksCache = [];   // VI 발동 종목 캐시
let highNearCache = [];   // 고가근접 종목 캐시

// 종목 진단 모달 열기
async function openStockDiagnosis(stockCode, stockName) {
    const modal = document.getElementById('diagnosisModal');
    const overlay = document.getElementById('diagnosisOverlay');

    if (!modal || !overlay) {
        console.error('[진단] 모달 요소가 없습니다');
        return;
    }

    // 모달 표시
    overlay.classList.remove('hidden');
    modal.classList.remove('hidden');

    // 헤더 업데이트
    document.getElementById('diagnosisStockName').textContent = stockName || stockCode;
    document.getElementById('diagnosisStockCode').textContent = stockCode;

    // 로딩 상태
    setDiagnosisLoading(true);

    try {
        // 병렬로 데이터 조회
        const [strengthResult, viResult, highNearResult] = await Promise.all([
            fetchContractStrength(stockCode),
            fetchViStatus(stockCode),
            fetchHighNearStatus(stockCode)
        ]);

        // 결과 렌더링
        renderDiagnosis(stockCode, stockName, {
            strength: strengthResult,
            vi: viResult,
            highNear: highNearResult
        });

    } catch (e) {
        console.error('[진단] 오류:', e);
        showDiagnosisError(e.message);
    } finally {
        setDiagnosisLoading(false);
    }
}

// 진단 모달 닫기
function closeDiagnosis() {
    const modal = document.getElementById('diagnosisModal');
    const overlay = document.getElementById('diagnosisOverlay');
    if (modal) modal.classList.add('hidden');
    if (overlay) overlay.classList.add('hidden');
}

// 로딩 상태 설정
function setDiagnosisLoading(loading) {
    const content = document.getElementById('diagnosisContent');
    if (!content) return;

    if (loading) {
        content.innerHTML = `
            <div style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 24px; color: var(--accent);"></i>
                <p style="margin-top: 12px; color: var(--text-muted);">종목 분석 중...</p>
            </div>
        `;
    }
}

// 에러 표시
function showDiagnosisError(message) {
    const content = document.getElementById('diagnosisContent');
    if (!content) return;

    content.innerHTML = `
        <div style="text-align: center; padding: 40px;">
            <i class="fas fa-exclamation-circle" style="font-size: 24px; color: var(--danger);"></i>
            <p style="margin-top: 12px; color: var(--danger);">${message}</p>
        </div>
    `;
}

// ==================== API 호출 함수들 ====================

// 체결강도 조회
async function fetchContractStrength(stockCode) {
    const host = localStorage.getItem('kiwoom_host') || 'https://api.kiwoom.com';
    const token = localStorage.getItem('kiwoom_token');

    if (!token) {
        return { success: false, error: '토큰 없음' };
    }

    try {
        // IPC로 체결강도 조회
        const result = await window.electronAPI.kiwoom.contractStrength(stockCode);
        return result;
    } catch (e) {
        return { success: false, error: e.message };
    }
}

// VI 상태 조회 (전체 조회 후 캐시)
async function fetchViStatus(stockCode) {
    const host = localStorage.getItem('kiwoom_host') || 'https://api.kiwoom.com';
    const token = localStorage.getItem('kiwoom_token');

    if (!token) {
        return { success: false, error: '토큰 없음', isVi: false };
    }

    try {
        // IPC or REST API로 VI 발동 종목 조회
        let result;
        if (window.electronAPI?.kiwoom?.viStocks) {
            // Electron IPC
            result = await window.electronAPI.kiwoom.viStocks({
                mrkt_tp: '000',     // 전체
                bf_mkrt_tp: '0',    // 전체
                motn_tp: '0'        // 전체 (정적+동적)
            });
        } else if (typeof callKiwoom === 'function') {
            // 브라우저 REST API - ka10054
            result = await callKiwoom('ka10054', {
                mrkt_tp: '000',
                bf_mkrt_tp: '1',
                stk_cd: '',
                motn_tp: '0',
                skip_stk: '000000000',
                trde_qty_tp: '0',
                min_trde_qty: '0',
                max_trde_qty: '100000000',
                trde_prica_tp: '0',
                min_trde_prica: '0',
                max_trde_prica: '100000000',
                motn_drc: '0',
                stex_tp: '1'
            });
        } else {
            return { isVi: false, viData: null, allViStocks: [] };
        }

        const viStocksData = result.data?.vi_motn_stk || result.data?.motn_stk;
        if (result.success && viStocksData) {
            viStocksCache = viStocksData;
            // 해당 종목이 VI 목록에 있는지 확인
            const viStock = viStocksCache.find(v => v.stk_cd === stockCode);
            return {
                success: true,
                isVi: !!viStock,
                viData: viStock,
                allViStocks: viStocksCache
            };
        }

        return { success: true, isVi: false };
    } catch (e) {
        return { success: false, error: e.message, isVi: false };
    }
}

// 고가근접 상태 조회
async function fetchHighNearStatus(stockCode) {
    const host = localStorage.getItem('kiwoom_host') || 'https://api.kiwoom.com';
    const token = localStorage.getItem('kiwoom_token');

    if (!token) {
        return { success: false, error: '토큰 없음', isNear: false };
    }

    try {
        // IPC로 고저가근접 조회
        const result = await window.electronAPI.kiwoom.highLowNear({
            high_low_tp: '1',   // 고가
            alacc_rt: '30',     // 3% 이내
            mrkt_tp: '000'      // 전체
        });

        if (result.success && result.data?.high_low_alacc) {
            highNearCache = result.data.high_low_alacc;
            // 해당 종목이 고가근접 목록에 있는지 확인
            const nearStock = highNearCache.find(h => h.stk_cd === stockCode);
            return {
                success: true,
                isNear: !!nearStock,
                nearData: nearStock,
                distance: nearStock ? parseFloat(nearStock.high_gap_rt || 0) : null
            };
        }

        return { success: true, isNear: false };
    } catch (e) {
        return { success: false, error: e.message, isNear: false };
    }
}

// ==================== 렌더링 함수 ====================

function renderDiagnosis(stockCode, stockName, data) {
    const content = document.getElementById('diagnosisContent');
    if (!content) return;

    const { strength, vi, highNear } = data;

    // 체결강도 계산
    let strengthValue = 100;
    let strengthTrend = 'neutral';
    if (strength.success && strength.data?.cntr_str_time?.length > 0) {
        const latest = strength.data.cntr_str_time[0];
        strengthValue = parseFloat(latest.cntr_str) || 100;
        strengthTrend = strengthValue > 100 ? 'up' : strengthValue < 100 ? 'down' : 'neutral';
    }

    // VI 상태
    const isVi = vi.isVi || false;
    const viType = vi.viData?.motn_tp === '1' ? '정적VI' :
                   vi.viData?.motn_tp === '2' ? '동적VI' :
                   vi.viData?.motn_tp === '3' ? '정적+동적' : '';

    // 고가거리
    const isNearHigh = highNear.isNear || false;
    const highDistance = highNear.distance || null;

    // 종합 점수 계산 (100점 만점)
    let score = 50;  // 기본 점수

    // 체결강도 점수 (±20점)
    if (strengthValue > 120) score += 20;
    else if (strengthValue > 100) score += (strengthValue - 100) * 1;
    else if (strengthValue < 80) score -= 20;
    else if (strengthValue < 100) score -= (100 - strengthValue) * 1;

    // VI 위험도 (-30점)
    if (isVi) score -= 30;

    // 고가근접 (주의 필요, -10점)
    if (isNearHigh && highDistance !== null && highDistance < 1) {
        score -= 10;
    }

    score = Math.max(0, Math.min(100, Math.round(score)));

    // 판정
    let verdict = '';
    let verdictClass = '';
    if (score >= 70) {
        verdict = '매수 적합';
        verdictClass = 'success';
    } else if (score >= 50) {
        verdict = '중립 (관망)';
        verdictClass = 'warning';
    } else {
        verdict = '매수 주의';
        verdictClass = 'danger';
    }

    content.innerHTML = `
        <div class="diagnosis-grid">
            <!-- 체결강도 -->
            <div class="diagnosis-item">
                <div class="diagnosis-label">
                    <i class="fas fa-bolt"></i> 체결강도
                </div>
                <div class="diagnosis-value ${strengthTrend === 'up' ? 'text-success' : strengthTrend === 'down' ? 'text-danger' : ''}">
                    ${strengthValue.toFixed(1)}
                </div>
                <div class="diagnosis-bar">
                    <div class="diagnosis-bar-fill ${strengthTrend === 'up' ? 'bar-success' : strengthTrend === 'down' ? 'bar-danger' : 'bar-neutral'}"
                         style="width: ${Math.min(100, strengthValue)}%"></div>
                </div>
                <div class="diagnosis-desc">
                    ${strengthValue > 100 ? '매수세 우위' : strengthValue < 100 ? '매도세 우위' : '균형'}
                </div>
            </div>

            <!-- VI 상태 -->
            <div class="diagnosis-item">
                <div class="diagnosis-label">
                    <i class="fas fa-exclamation-triangle"></i> VI 상태
                </div>
                <div class="diagnosis-value ${isVi ? 'text-danger' : 'text-success'}">
                    ${isVi ? viType : '정상'}
                </div>
                <div class="diagnosis-bar">
                    <div class="diagnosis-bar-fill ${isVi ? 'bar-danger' : 'bar-success'}"
                         style="width: ${isVi ? '100' : '30'}%"></div>
                </div>
                <div class="diagnosis-desc">
                    ${isVi ? 'VI 발동 중 - 주의!' : 'VI 미발동'}
                </div>
            </div>

            <!-- 고가거리 -->
            <div class="diagnosis-item">
                <div class="diagnosis-label">
                    <i class="fas fa-arrow-up"></i> 고가 거리
                </div>
                <div class="diagnosis-value ${isNearHigh && highDistance < 1 ? 'text-warning' : ''}">
                    ${highDistance !== null ? highDistance.toFixed(2) + '%' : '-'}
                </div>
                <div class="diagnosis-bar">
                    <div class="diagnosis-bar-fill ${isNearHigh ? 'bar-warning' : 'bar-neutral'}"
                         style="width: ${highDistance !== null ? Math.max(10, 100 - highDistance * 20) : 30}%"></div>
                </div>
                <div class="diagnosis-desc">
                    ${isNearHigh && highDistance < 1 ? '고가 근접 - 추격 주의' :
                      highDistance !== null ? '고가 대비 ' + highDistance.toFixed(2) + '% 하락' : '데이터 없음'}
                </div>
            </div>
        </div>

        <!-- 종합 점수 -->
        <div class="diagnosis-score-section">
            <div class="score-circle score-${verdictClass}">
                <span class="score-value">${score}</span>
                <span class="score-label">점</span>
            </div>
            <div class="score-verdict verdict-${verdictClass}">
                ${verdict}
            </div>
            <div class="score-details">
                ${strengthValue > 100 ? '<span class="detail-good">체결강도 양호</span>' :
                  strengthValue < 100 ? '<span class="detail-bad">체결강도 약세</span>' : ''}
                ${isVi ? '<span class="detail-bad">VI 발동</span>' : ''}
                ${isNearHigh && highDistance < 1 ? '<span class="detail-warn">고가 근접</span>' : ''}
            </div>
        </div>

        <!-- 차트로 이동 버튼 -->
        <div class="diagnosis-actions">
            <button class="btn-diagnosis" onclick="openChartWithStock('${stockCode}', '${stockName}', 'daily'); closeDiagnosis();">
                <i class="fas fa-chart-line"></i> 차트 보기
            </button>
            <button class="btn-diagnosis secondary" onclick="closeDiagnosis();">
                닫기
            </button>
        </div>
    `;
}

// ==================== VI 모니터링 (실시간 알림용) ====================

let viMonitorInterval = null;
let viAlertHistory = [];  // 이미 알림한 종목

// VI 모니터링 시작
function startViMonitor() {
    if (viMonitorInterval) return;

    console.log('[VI Monitor] 모니터링 시작');
    fetchViStocksForAlert();

    // 30초마다 갱신
    viMonitorInterval = setInterval(fetchViStocksForAlert, 30000);
}

// VI 모니터링 중지
function stopViMonitor() {
    if (viMonitorInterval) {
        clearInterval(viMonitorInterval);
        viMonitorInterval = null;
        console.log('[VI Monitor] 모니터링 중지');
    }
}

// VI 종목 조회 및 알림
async function fetchViStocksForAlert() {
    const host = localStorage.getItem('kiwoom_host') || 'https://api.kiwoom.com';
    const token = localStorage.getItem('kiwoom_token');

    if (!token) return;

    try {
        // IPC or REST API로 VI 발동 종목 조회
        let result;
        if (window.electronAPI?.kiwoom?.viStocks) {
            // Electron IPC
            result = await window.electronAPI.kiwoom.viStocks({
                mrkt_tp: '000',
                bf_mkrt_tp: '1',    // 정규시장
                motn_tp: '0'
            });
        } else if (typeof callKiwoom === 'function') {
            // 브라우저 REST API - ka10054
            result = await callKiwoom('ka10054', {
                mrkt_tp: '000',
                bf_mkrt_tp: '1',
                stk_cd: '',
                motn_tp: '0',
                skip_stk: '000000000',
                trde_qty_tp: '0',
                min_trde_qty: '0',
                max_trde_qty: '100000000',
                trde_prica_tp: '0',
                min_trde_prica: '0',
                max_trde_prica: '100000000',
                motn_drc: '0',
                stex_tp: '1'
            });
        } else {
            return;
        }

        const viStocks = result.data?.vi_motn_stk || result.data?.motn_stk;
        if (result.success && viStocks) {

            // 새로 발동된 VI 종목 체크
            for (const stock of viStocks) {
                const key = stock.stk_cd + '_' + stock.motn_tm;
                if (!viAlertHistory.includes(key)) {
                    viAlertHistory.push(key);
                    addViAlert(stock);
                }
            }

            // 알림 히스토리 최대 100개 유지
            if (viAlertHistory.length > 100) {
                viAlertHistory = viAlertHistory.slice(-100);
            }

            // 사이드바 업데이트
            updateViSidebar(viStocks);
        }
    } catch (e) {
        console.error('[VI Monitor] 오류:', e);
    }
}

// VI 알림 추가
function addViAlert(stock) {
    const alertList = document.getElementById('alertList');
    if (!alertList) return;

    const now = new Date();
    const timeStr = now.getHours().toString().padStart(2, '0') + ':' +
                    now.getMinutes().toString().padStart(2, '0');

    const viType = stock.motn_tp === '1' ? '정적VI' :
                   stock.motn_tp === '2' ? '동적VI' : 'VI';

    const alertHtml = `
        <div class="alert-item alert-vi" onclick="openStockDiagnosis('${stock.stk_cd}', '${stock.stk_nm}')">
            <div class="alert-time">${timeStr}</div>
            <div class="alert-icon"><i class="fas fa-exclamation-triangle"></i></div>
            <div class="alert-content">
                <div class="alert-title">${viType} 발동</div>
                <div class="alert-stock">${stock.stk_nm} (${stock.stk_cd})</div>
                <div class="alert-detail">${stock.flu_rt || ''}%</div>
            </div>
        </div>
    `;

    alertList.insertAdjacentHTML('afterbegin', alertHtml);

    // 최대 50개 유지
    while (alertList.children.length > 50) {
        alertList.removeChild(alertList.lastChild);
    }

    addLog(`VI 발동: ${stock.stk_nm} (${viType})`, 'warning');
}

// VI 사이드바 업데이트
function updateViSidebar(viStocks) {
    const viCount = document.getElementById('viCount');
    if (viCount) {
        viCount.textContent = viStocks.length;
    }
}

// ==================== VI 모니터 패널 ====================

// VI 데이터 캐시 (조회 버튼 클릭 시 전체 데이터 저장)
let viDataCache = [];
let viPriceCache = {};  // 현재가 캐시

// 조회 버튼 클릭 시: API 호출 → 캐시 저장 → 필터 적용
async function fetchViMonitorData() {
    const viTableBody = document.getElementById('viTableBody');
    const refreshBtn = document.getElementById('viRefreshBtn');
    const lastUpdateEl = document.getElementById('viLastUpdate');

    if (!viTableBody) return;

    // 로딩 상태
    if (refreshBtn) {
        refreshBtn.disabled = true;
        refreshBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 조회 중...';
    }

    viTableBody.innerHTML = `
        <tr>
            <td colspan="6" style="text-align: center; padding: 40px;">
                <i class="fas fa-spinner fa-spin" style="font-size: 24px; color: var(--accent);"></i>
                <p style="margin-top: 12px; color: var(--text-muted);">VI 발동 종목 조회 중...</p>
            </td>
        </tr>
    `;

    const token = localStorage.getItem('kiwoom_token');

    if (!token) {
        viTableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: var(--danger);">
                    <i class="fas fa-exclamation-circle" style="font-size: 24px;"></i>
                    <p style="margin-top: 12px;">토큰이 없습니다. API 인증 탭에서 토큰을 발급하세요.</p>
                </td>
            </tr>
        `;
        if (refreshBtn) {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '<i class="fas fa-search"></i> 조회';
        }
        return;
    }

    try {
        // IPC or REST API로 VI 발동 종목 조회 (필터 없이 전체 조회)
        // skip_stk 9자리: 우선주,관리종목,투자경고/위험,투자주의,환기종목,단기과열종목,증거금100%,ETF,ETN
        // '000000011' = ETF/ETN 제외
        let result;
        if (window.electronAPI?.kiwoom?.viStocks) {
            // Electron IPC
            result = await window.electronAPI.kiwoom.viStocks({
                mrkt_tp: '000',       // 전체 시장
                bf_mkrt_tp: '1',      // 정규시장
                motn_tp: '0',         // 전체 (정적+동적)
                motn_drc: '0',        // 전체 (상승+하락)
                skip_stk: '000000011' // ETF/ETN 제외
            });
        } else if (typeof callKiwoom === 'function') {
            // 브라우저 REST API - ka10054
            result = await callKiwoom('ka10054', {
                mrkt_tp: '000',
                bf_mkrt_tp: '1',
                stk_cd: '',
                motn_tp: '0',
                skip_stk: '000000011',
                trde_qty_tp: '0',
                min_trde_qty: '0',
                max_trde_qty: '100000000',
                trde_prica_tp: '0',
                min_trde_prica: '0',
                max_trde_prica: '100000000',
                motn_drc: '0',
                stex_tp: '1'
            });
        } else {
            throw new Error('API 연결 없음');
        }

        const viData = result.data?.vi_motn_stk || result.data?.motn_stk;
        if (result.success && viData) {
            viDataCache = viData;

            // 디버그 로그
            if (viDataCache.length > 0) {
                console.log('[VI] 응답 필드:', Object.keys(viDataCache[0]));
                console.log('[VI] 첫 번째 항목:', JSON.stringify(viDataCache[0]));
                console.log('[VI] 전체 데이터 개수:', viDataCache.length);
            }

            // 종목코드에서 _AL, _NX 등 마켓 접미사 제거 함수
            const cleanCode = (code) => (code || '').replace(/_[A-Z]+$/, '').trim();

            // 현재가 조회 (전체 데이터에 대해)
            viPriceCache = {};
            const batchSize = 10;
            const codesToFetch = viDataCache.map(s => cleanCode(s.stk_cd)).filter(c => c.length === 6);
            for (let i = 0; i < codesToFetch.length; i += batchSize) {
                const batch = codesToFetch.slice(i, i + batchSize);
                await Promise.all(batch.map(async (code) => {
                    try {
                        let infoResult;
                        if (window.electronAPI?.kiwoom?.stockInfo) {
                            infoResult = await window.electronAPI.kiwoom.stockInfo(code);
                        } else if (typeof callKiwoom === 'function') {
                            infoResult = await callKiwoom('stockInfo', {stk_cd: code});
                        } else {
                            return;
                        }
                        const info = infoResult?.data || infoResult;
                        if (info?.cur_prc) {
                            viPriceCache[code] = {
                                price: parseInt((info.cur_prc || '0').replace(/[^0-9-]/g, '')) || 0,
                                changeRate: parseFloat((info.flu_rt || '0').replace(/[^0-9.-]/g, '')) || 0
                            };
                        }
                    } catch (e) {
                        console.warn('[VI] 현재가 조회 실패:', code, e.message);
                    }
                }));
            }

            // 마지막 업데이트 시간
            const now = new Date();
            const timeStr = now.getHours().toString().padStart(2, '0') + ':' +
                            now.getMinutes().toString().padStart(2, '0') + ':' +
                            now.getSeconds().toString().padStart(2, '0');
            if (lastUpdateEl) {
                lastUpdateEl.textContent = '마지막 조회: ' + timeStr;
            }

            addLog(`VI 발동 종목 ${viDataCache.length}개 조회 완료`, viDataCache.length > 0 ? 'warning' : 'success');

            // 필터 적용하여 렌더링
            applyViFilter();

        } else {
            throw new Error(result.error || '데이터 없음');
        }

    } catch (e) {
        viTableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 40px; color: var(--danger);">
                    <i class="fas fa-exclamation-circle" style="font-size: 24px;"></i>
                    <p style="margin-top: 12px;">${e.message}</p>
                </td>
            </tr>
        `;
        addLog('VI 조회 오류: ' + e.message, 'error');
    } finally {
        if (refreshBtn) {
            refreshBtn.disabled = false;
            refreshBtn.innerHTML = '<i class="fas fa-search"></i> 조회';
        }
    }
}

// 필터 변경 시: 캐시된 데이터에서 즉시 필터 적용 (API 호출 없음)
function applyViFilter() {
    const viTableBody = document.getElementById('viTableBody');
    if (!viTableBody) return;

    // 캐시가 비어있으면 안내 메시지
    if (!viDataCache || viDataCache.length === 0) {
        viTableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 60px; color: var(--text-muted);">
                    <i class="fas fa-info-circle" style="font-size: 32px;"></i>
                    <p style="margin-top: 12px;">'조회' 버튼을 클릭하여 VI 발동 종목을 조회하세요.</p>
                </td>
            </tr>
        `;
        return;
    }

    // 필터 값 가져오기 (semantic values: all, kospi, kosdaq, static, dynamic, up, down)
    const marketFilter = document.querySelector('input[name="viMarket"]:checked')?.value || 'all';
    const typeFilter = document.querySelector('input[name="viType"]:checked')?.value || 'all';
    const directionFilter = document.querySelector('input[name="viDirection"]:checked')?.value || 'all';

    console.log('[VI] 필터 적용:', { marketFilter, typeFilter, directionFilter });

    // 종목코드에서 _AL, _NX 등 마켓 접미사 제거 함수
    const cleanCode = (code) => (code || '').replace(/_[A-Z]+$/, '').trim();

    // 캐시된 데이터 필터링
    let filteredStocks = viDataCache.filter(stock => {
        const code = cleanCode(stock.stk_cd);
        const cached = viPriceCache[code] || {};
        const fluRt = cached.changeRate || parseFloat(stock.flu_rt) || 0;

        // 시장 필터 (mrkt_div: 1=코스피, 2=코스닥)
        if (marketFilter === 'kospi' && stock.mrkt_div !== '1') return false;
        if (marketFilter === 'kosdaq' && stock.mrkt_div !== '2') return false;

        // VI 유형 필터 (viaplc_tp 기준)
        const viType = stock.viaplc_tp || stock.motn_tp || '';
        if (typeFilter === 'static') {
            // 정적만: '정적' 포함하되 '동적' 미포함, 또는 코드 '1'
            const isStatic = (viType.includes('정적') && !viType.includes('동적')) || viType === '1';
            if (!isStatic) return false;
        }
        if (typeFilter === 'dynamic') {
            // 동적만: '동적' 포함하되 '정적' 미포함, 또는 코드 '2'
            const isDynamic = (viType.includes('동적') && !viType.includes('정적')) || viType === '2';
            if (!isDynamic) return false;
        }

        // 방향 필터 (VI 발동가 vs 기준가)
        const motnPrc = Math.abs(parseInt(stock.motn_pric)) || 0;
        const stdPrc = Math.abs(parseInt(stock.static_stdpc)) || 0;
        const isViUp = motnPrc > stdPrc;
        if (directionFilter === 'up' && !isViUp) return false;
        if (directionFilter === 'down' && isViUp) return false;

        return true;
    });

    // 시간순 정렬 (최신순 - 내림차순)
    filteredStocks.sort((a, b) => (b.trde_cntr_proc_time || '').localeCompare(a.trde_cntr_proc_time || ''));

    // 사이드바 업데이트
    updateViSidebar(filteredStocks);

    // 필터 결과가 없으면
    if (filteredStocks.length === 0) {
        viTableBody.innerHTML = `
            <tr>
                <td colspan="6" style="text-align: center; padding: 60px; color: var(--success);">
                    <i class="fas fa-check-circle" style="font-size: 32px;"></i>
                    <p style="margin-top: 12px;">해당 조건의 VI 발동 종목이 없습니다.</p>
                    <p style="margin-top: 4px; font-size: 12px; color: var(--text-muted);">전체 조회: ${viDataCache.length}개 / 필터 결과: 0개</p>
                </td>
            </tr>
        `;
        return;
    }

    // 테이블 행 렌더링
    viTableBody.innerHTML = filteredStocks.map(stock => {
        const code = cleanCode(stock.stk_cd);
        const cached = viPriceCache[code] || {};
        const curPrc = cached.price || Math.abs(parseInt(stock.motn_pric)) || 0;
        const fluRt = cached.changeRate || parseFloat(stock.flu_rt) || 0;
        const fluClass = fluRt > 0 ? 'price-up' : fluRt < 0 ? 'price-down' : '';

        // VI 구분 판단 (viaplc_tp 또는 motn_tp 사용)
        const viType = stock.viaplc_tp || stock.motn_tp || '';
        let viTypeText = 'VI';
        if (viType.includes('정적') && viType.includes('동적')) {
            viTypeText = '정적+동적';
        } else if (viType.includes('정적') || viType === '1') {
            viTypeText = '정적';
        } else if (viType.includes('동적') || viType === '2') {
            viTypeText = '동적';
        } else if (viType === '3') {
            viTypeText = '정적+동적';
        }

        // 방향 판단: VI 발동가 vs 기준가
        const motnPrc = Math.abs(parseInt(stock.motn_pric)) || 0;
        const stdPrc = Math.abs(parseInt(stock.static_stdpc)) || 0;
        const isUp = motnPrc > stdPrc;
        const directionIcon = isUp ? '▲' : '▼';
        const directionClass = isUp ? 'vi-direction-up' : 'vi-direction-down';

        // 발동시간 포맷 (trde_cntr_proc_time: HHMMSS → HH:MM:SS)
        const tm = stock.trde_cntr_proc_time || stock.motn_tm || '';
        const timeFormatted = tm.length >= 6
            ? `${tm.slice(0,2)}:${tm.slice(2,4)}:${tm.slice(4,6)}`
            : (tm || '-');

        return `
            <tr onclick="openStockDetailTab('${code}', '${stock.stk_nm}')">
                <td class="text-center" style="font-family: monospace;">${timeFormatted}</td>
                <td style="max-width: 140px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;"><strong>${stock.stk_nm || '-'}</strong></td>
                <td class="text-center" style="color: var(--text-muted);">${code}</td>
                <td class="text-center"><span class="${directionClass}">${directionIcon}</span> ${viTypeText}</td>
                <td class="text-right" style="font-weight: 600;">${curPrc.toLocaleString()}</td>
                <td class="text-right ${fluClass}">${fluRt > 0 ? '+' : ''}${fluRt.toFixed(2)}%</td>
            </tr>
        `;
    }).join('');

    console.log(`[VI] 필터 적용 완료: 전체 ${viDataCache.length}개 → 필터 결과 ${filteredStocks.length}개`);
}
