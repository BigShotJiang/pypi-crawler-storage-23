/**
 * settings-panel.js
 * API Keys 설정 패널 관리 모듈 (settings.html → stockclaw-kit-ui.html 통합용)
 *
 * - 진입점: initSettingsPanel()
 * - HTML 컨테이너: <div id="panel-credentials" class="content-panel">
 * - 전역 변수: API_BASE (부모 페이지에서 제공)
 */

(function () {
  'use strict';

  // ─── API Base ──────────────────────────────────────────────────────────────
  var API_BASE = window.API_BASE || '';

  // ─── Module definitions ────────────────────────────────────────────────────
  var SETTINGS_MODULES = [
    {
      id: 'free',
      name: '무료 데이터 (PyKRX)',
      icon: 'fas fa-database',
      badge: 'FREE',
      badgeStyle: 'background:#065f46;color:#6ee7b7',
      description: '키 없이 사용 가능 — 주가, 시총, 재무제표 등',
      expandable: false,
      keys: []
    },
    {
      id: 'news',
      name: '뉴스 검색 (Naver)',
      icon: 'fas fa-newspaper',
      badge: 'FREE',
      badgeStyle: 'background:#1e3a4a;color:#38bdf8',
      description: '네이버 뉴스 API',
      expandable: true,
      keys: [
        { id: 'NAVER_CLIENT_ID',     label: 'Client ID',     required: true,  placeholder: 'Client ID' },
        { id: 'NAVER_CLIENT_SECRET', label: 'Client Secret', required: true,  placeholder: 'Client Secret' }
      ],
      guide: '<b>발급 방법:</b><ol><li><a href="https://developers.naver.com/apps/" target="_blank">developers.naver.com/apps</a> 접속</li><li>애플리케이션 등록 → 검색 > 뉴스 선택</li><li>Client ID / Secret 복사</li></ol>'
    },
    {
      id: 'telegram',
      name: '텔레그램 뉴스',
      icon: 'fab fa-telegram',
      badge: 'FREE',
      badgeStyle: 'background:#1a2a3f;color:#38bdf8',
      description: '텔레그램 채널/그룹 수집',
      expandable: true,
      keys: [
        { id: 'TELEGRAM_API_ID',   label: 'API ID',   required: true,  placeholder: 'API ID' },
        { id: 'TELEGRAM_API_HASH', label: 'API Hash', required: true,  placeholder: 'API Hash' },
        { id: 'TELEGRAM_PHONE',    label: '전화번호', required: true,  placeholder: '+821012345678' }
      ],
      guide: '<b>발급 방법:</b><ol><li><a href="https://my.telegram.org/" target="_blank">my.telegram.org</a> 접속</li><li>API development tools 클릭</li><li>App 생성 → API ID, Hash 복사</li></ol>',
      hasAuth: true
    },
    {
      id: 'kiwoom',
      name: '키움증권 REST API',
      icon: 'fas fa-chart-line',
      badge: '185 APIs',
      badgeStyle: 'background:#3b2a1a;color:#fb923c',
      description: '실시간 시세, 주문, 잔고 조회',
      expandable: true,
      hasEnvToggle: true,
      envKey: 'kiwoom_env',
      envValues: { live: 'live', mock: 'mock' },
      liveColor: '#fb923c',
      mockColor: '#38bdf8',
      keys: [
        { id: 'KIWOOM_APP_KEY',          label: 'App Key',    required: true,  placeholder: 'App Key',    env: 'live' },
        { id: 'KIWOOM_APP_SECRET',       label: 'App Secret', required: true,  placeholder: 'App Secret', env: 'live' },
        { id: 'KIWOOM_ACCOUNT_NO',       label: '계좌번호',   required: false, placeholder: '계좌번호',   env: 'live' },
        { id: 'KIWOOM_PAPER_APP_KEY',    label: 'App Key',    required: true,  placeholder: 'App Key',    env: 'mock' },
        { id: 'KIWOOM_PAPER_APP_SECRET', label: 'App Secret', required: true,  placeholder: 'App Secret', env: 'mock' }
      ],
      guide: '<b>발급:</b> <a href="https://openapi.kiwoom.com/" target="_blank">openapi.kiwoom.com</a>'
    },
    {
      id: 'kis',
      name: '한국투자증권 KIS',
      icon: 'fas fa-university',
      badge: '166 APIs',
      badgeStyle: 'background:#1a2a1a;color:#4ade80',
      description: '국내외 주식, 채권, 선물옵션',
      expandable: true,
      hasEnvToggle: true,
      envKey: 'kis_env',
      envValues: { live: 'real', mock: 'demo' },
      liveColor: '#4ade80',
      mockColor: '#38bdf8',
      keys: [
        { id: 'KIS_APP_KEY',          label: 'App Key',    required: true,  placeholder: 'App Key',    env: 'live' },
        { id: 'KIS_APP_SECRET',       label: 'App Secret', required: true,  placeholder: 'App Secret', env: 'live' },
        { id: 'KIS_PAPER_APP_KEY',    label: 'App Key',    required: true,  placeholder: 'App Key',    env: 'mock' },
        { id: 'KIS_PAPER_APP_SECRET', label: 'App Secret', required: true,  placeholder: 'App Secret', env: 'mock' }
      ],
      guide: '<b>발급:</b> <a href="https://apiportal.koreainvestment.com/" target="_blank">한국투자증권 Open API</a>'
    },
    {
      id: 'datakit',
      name: '공시/경제지표',
      icon: 'fas fa-landmark',
      badge: 'FREE',
      badgeStyle: 'background:#1e2a3a;color:#60a5fa',
      description: 'DART 전자공시, ECOS 경제통계, 환율',
      expandable: true,
      keys: [
        { id: 'DART_API_KEY', label: 'DART API Key', required: false, placeholder: '선택' },
        { id: 'ECOS_API_KEY', label: 'ECOS API Key', required: false, placeholder: '선택' },
        { id: 'EXIM_API_KEY', label: 'EXIM API Key', required: false, placeholder: '선택' }
      ],
      guide: 'DART: <a href="https://opendart.fss.or.kr/" target="_blank">opendart.fss.or.kr</a> | ECOS: <a href="https://ecos.bok.or.kr/" target="_blank">ecos.bok.or.kr</a> | EXIM: <a href="https://www.koreaexim.go.kr/" target="_blank">koreaexim.go.kr</a>'
    },
    {
      id: 'themalab',
      name: '테마트래커 멤버십',
      icon: 'fas fa-crown',
      badge: 'API',
      badgeStyle: 'background:#2d1e4a;color:#a78bfa',
      description: '프리미엄 데이터 피드 + AI 브리핑',
      expandable: true,
      keys: [
        { id: 'THEMALAB_API_KEY', label: 'API Key', required: false, placeholder: 'tt_live_... (선택)' }
      ],
      guide: '<b>발급:</b> <a href="https://readinginvestor.com/my-page" target="_blank">readinginvestor.com</a> → 내정보 → API 키 탭'
    }
  ];

  // ─── State ─────────────────────────────────────────────────────────────────
  var _loadedKeys = {};
  var _tgState = 'unknown'; // unknown | disconnected | code_sent | connected
  var _currentTab = 'settings';

  // ─── CSS injected once ────────────────────────────────────────────────────
  var _cssInjected = false;

  function injectStyles() {
    if (_cssInjected) return;
    _cssInjected = true;

    var css = [
      /* ── Server status banner ── */
      '.sp-server-banner{display:flex;align-items:center;gap:10px;',
      'background:var(--bg-card,#1a1d27);border:1px solid var(--border,#2d3140);',
      'border-radius:10px;padding:12px 14px;margin-bottom:24px;',
      'font-size:13px;color:var(--text-muted,#8b8fa3);transition:border-color .3s,background .3s}',
      '.sp-server-banner.sp-ok{border-color:rgba(52,211,153,.3);background:rgba(6,95,70,.12);',
      'color:var(--green,#34d399)}',
      '.sp-server-banner.sp-error{border-color:rgba(248,113,113,.35);',
      'background:rgba(127,29,29,.18);color:var(--red,#f87171)}',
      '.sp-server-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0;',
      'background:var(--text-muted,#8b8fa3)}',
      '.sp-server-dot.sp-ok{background:var(--green,#34d399);',
      'box-shadow:0 0 6px rgba(52,211,153,.5)}',
      '.sp-server-dot.sp-error{background:var(--red,#f87171);',
      'box-shadow:0 0 6px rgba(248,113,113,.5)}',
      '.sp-server-dot.sp-loading{background:#fbbf24;animation:sp-dotPulse 1s infinite}',
      '@keyframes sp-dotPulse{0%,100%{opacity:1}50%{opacity:.3}}',

      /* ── Tab nav ── */
      '.sp-tab-nav{display:flex;gap:0;margin-bottom:24px;',
      'border-bottom:1px solid var(--border,#2d3140)}',
      '.sp-tab-btn{flex:1;padding:12px 0;background:none;border:none;',
      'border-bottom:2px solid transparent;',
      'color:var(--text-muted,#8b8fa3);font-size:15px;font-weight:600;',
      'cursor:pointer;transition:all .2s;font-family:inherit}',
      '.sp-tab-btn:hover{color:var(--text,#e4e6ed)}',
      '.sp-tab-btn.sp-active{color:var(--accent,#6c8cff);',
      'border-bottom-color:var(--accent,#6c8cff)}',

      /* ── Section label ── */
      '.sp-section-label{font-size:11px;font-weight:600;',
      'color:var(--text-muted,#8b8fa3);text-transform:uppercase;',
      'letter-spacing:.08em;margin-bottom:12px}',

      /* ── Module card ── */
      '.sp-mod-card{background:var(--bg-card,#1a1d27);',
      'border:1px solid var(--border,#2d3140);border-radius:14px;',
      'margin-bottom:10px;overflow:hidden;transition:border-color .2s}',
      '.sp-mod-card.sp-expanded{border-color:rgba(108,140,255,.4)}',

      '.sp-card-header{display:flex;align-items:center;gap:14px;',
      'padding:16px 18px;cursor:pointer;user-select:none;transition:background .15s}',
      '.sp-card-header:hover{background:rgba(255,255,255,.025)}',
      '.sp-card-header.sp-no-expand{cursor:default}',
      '.sp-card-header.sp-no-expand:hover{background:transparent}',

      '.sp-mod-icon{width:40px;height:40px;border-radius:10px;',
      'display:flex;align-items:center;justify-content:center;',
      'font-size:18px;flex-shrink:0}',
      '.sp-mod-meta{flex:1;min-width:0}',
      '.sp-mod-name-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}',
      '.sp-mod-name{font-size:15px;font-weight:600;color:var(--text,#e4e6ed)}',
      '.sp-mod-badge{font-size:11px;padding:2px 8px;border-radius:8px;font-weight:600;flex-shrink:0}',
      '.sp-mod-status-row{display:flex;align-items:center;gap:6px;margin-top:3px}',
      '.sp-status-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0}',
      '.sp-status-dot.sp-on,.sp-status-dot.sp-set{background:var(--green,#34d399);',
      'box-shadow:0 0 5px rgba(52,211,153,.5)}',
      '.sp-status-dot.sp-unset{background:var(--text-muted,#8b8fa3)}',
      '.sp-status-dot.sp-err{background:var(--red,#f87171)}',
      '.sp-status-label{font-size:12px;color:var(--text-muted,#8b8fa3)}',
      '.sp-status-label.sp-set{color:var(--green,#34d399)}',

      '.sp-expand-arrow{font-size:13px;color:var(--text-muted,#8b8fa3);flex-shrink:0;',
      'transition:transform .25s ease}',
      '.sp-expand-arrow.sp-open{transform:rotate(180deg)}',

      /* ── Card body ── */
      '.sp-card-body{display:none;padding:0 18px 18px;',
      'border-top:1px solid var(--border,#2d3140);',
      'animation:sp-slideDown .22s ease}',
      '.sp-card-body.sp-show{display:block}',
      '@keyframes sp-slideDown{from{opacity:0;transform:translateY(-6px)}to{opacity:1;transform:translateY(0)}}',
      '.sp-form-inner{padding-top:16px}',

      /* ── Always-on tag ── */
      '.sp-always-on-tag{display:inline-flex;align-items:center;gap:6px;',
      'background:rgba(52,211,153,.1);border:1px solid rgba(52,211,153,.3);',
      'border-radius:8px;padding:8px 14px;font-size:13px;',
      'color:var(--green,#34d399);font-weight:600;margin-top:12px}',

      /* ── Guide ── */
      '.sp-guide-btn{background:none;border:none;color:var(--accent,#6c8cff);',
      'font-size:12px;cursor:pointer;padding:0;font-family:inherit;',
      'margin-bottom:12px;display:inline-block}',
      '.sp-guide-btn:hover{text-decoration:underline}',
      '.sp-api-guide{font-size:12px;color:var(--text-muted,#8b8fa3);line-height:1.7;',
      'background:var(--bg-dark,#0f1117);border-radius:8px;padding:10px 12px;',
      'border-left:3px solid var(--accent,#6c8cff);margin-bottom:16px;display:none}',
      '.sp-api-guide.sp-show{display:block}',
      '.sp-api-guide a{color:var(--accent,#6c8cff);text-decoration:none}',
      '.sp-api-guide a:hover{text-decoration:underline}',
      '.sp-api-guide code{background:var(--bg-dark,#0f1117);',
      'border:1px solid var(--border,#2d3140);border-radius:4px;',
      'padding:1px 5px;font-family:"SF Mono","Cascadia Code",monospace;',
      'font-size:11px;color:var(--accent,#6c8cff)}',
      '.sp-api-guide ol{margin:6px 0 0 18px}',
      '.sp-api-guide li{margin-bottom:4px}',

      /* ── Fields ── */
      '.sp-field{margin-bottom:14px}',
      '.sp-field:last-child{margin-bottom:0}',
      '.sp-field label{display:flex;align-items:center;gap:8px;',
      'font-size:13px;font-weight:500;margin-bottom:6px;color:var(--text,#e4e6ed)}',
      '.sp-field label .sp-req{font-size:10px;color:#fbbf24;font-weight:600}',
      '.sp-field label .sp-opt{font-size:10px;color:var(--text-muted,#8b8fa3);font-weight:500}',
      '.sp-input-wrap{position:relative}',
      '.sp-input-wrap input{width:100%;padding:10px 38px 10px 12px;',
      'background:var(--bg-dark,#0f1117);border:1px solid var(--border,#2d3140);',
      'border-radius:8px;color:var(--text,#e4e6ed);font-size:14px;',
      'font-family:"SF Mono","Cascadia Code",monospace;outline:none;',
      'transition:border-color .2s}',
      '.sp-input-wrap input:focus{border-color:var(--accent,#6c8cff)}',
      '.sp-input-wrap input::placeholder{color:#4a4f63}',
      '.sp-toggle-vis{position:absolute;right:10px;top:50%;transform:translateY(-50%);',
      'background:none;border:none;color:var(--text-muted,#8b8fa3);cursor:pointer;',
      'font-size:15px;padding:4px;line-height:1}',
      '.sp-toggle-vis:hover{color:var(--text,#e4e6ed)}',

      '.sp-subsection-label{font-size:13px;font-weight:600;margin-bottom:10px;margin-top:4px}',
      '.sp-api-divider{border:none;border-top:1px solid var(--border,#2d3140);margin:14px 0}',

      /* ── Save / Clear row ── */
      '.sp-save-row{display:flex;gap:10px;margin-top:18px;align-items:center}',
      '.sp-btn-save{background:var(--accent,#6c8cff);color:#fff;padding:10px 24px;',
      'border:none;border-radius:8px;font-size:14px;font-weight:600;cursor:pointer;',
      'transition:all .2s;font-family:inherit;flex:1}',
      '.sp-btn-save:hover{background:var(--accent2,#4a6adf)}',
      '.sp-btn-save:disabled{opacity:.5;cursor:not-allowed}',
      '.sp-btn-clear{background:none;color:var(--text-muted,#8b8fa3);',
      'border:1px solid var(--border,#2d3140);border-radius:8px;',
      'padding:10px 16px;font-size:13px;cursor:pointer;font-family:inherit;transition:all .2s}',
      '.sp-btn-clear:hover{color:var(--red,#f87171);border-color:rgba(248,113,113,.4)}',

      /* ── Telegram auth ── */
      '.sp-tg-auth{margin-top:16px;padding:14px;',
      'background:var(--bg-dark,#0f1117);border:1px solid var(--border,#2d3140);',
      'border-radius:8px}',
      '.sp-tg-row{display:flex;align-items:center;gap:10px;font-size:13px}',
      '.sp-tg-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}',
      '.sp-tg-dot.sp-connected{background:var(--green,#34d399);',
      'box-shadow:0 0 5px rgba(52,211,153,.5)}',
      '.sp-tg-dot.sp-pending{background:#fbbf24;animation:sp-dotPulse 1s infinite}',
      '.sp-tg-dot.sp-error{background:var(--red,#f87171)}',
      '.sp-tg-dot.sp-disconnected{background:var(--text-muted,#8b8fa3)}',
      '.sp-tg-label{flex:1}',
      '.sp-tg-label.sp-ok{color:var(--green,#34d399);font-weight:600}',
      '.sp-btn-tg{padding:6px 14px;border:none;border-radius:6px;',
      'font-size:12px;font-weight:600;cursor:pointer;background:#229ED9;',
      'color:#fff;font-family:inherit}',
      '.sp-btn-tg:hover{background:#1A8BC7}',
      '.sp-btn-tg:disabled{opacity:.5;cursor:not-allowed}',
      '.sp-tg-code-row{display:flex;gap:8px;margin-top:10px;align-items:center}',
      '.sp-tg-code-row input{flex:1;padding:8px 10px;',
      'background:var(--bg-card,#1a1d27);border:1px solid var(--border,#2d3140);',
      'border-radius:6px;color:var(--text,#e4e6ed);font-size:14px;',
      'font-family:"SF Mono","Cascadia Code",monospace;letter-spacing:3px;',
      'text-align:center;outline:none}',
      '.sp-tg-code-row input:focus{border-color:var(--accent,#6c8cff)}',
      '.sp-tg-code-row input::placeholder{letter-spacing:0;font-size:12px}',

      /* ── Inline toast (fallback) ── */
      '.sp-toast{position:fixed;top:20px;right:20px;padding:12px 20px;',
      'border-radius:8px;font-size:14px;font-weight:500;',
      'transform:translateX(120%);transition:transform .3s ease;',
      'z-index:9999;max-width:320px;pointer-events:none}',
      '.sp-toast.sp-show{transform:translateX(0)}',
      '.sp-toast.sp-success{background:#065f46;color:#6ee7b7}',
      '.sp-toast.sp-error{background:#7f1d1d;color:#fca5a5}',
      '.sp-toast.sp-info{background:#1e3a5f;color:#93c5fd}',

      /* ── Env toggle ── */
      '.sp-env-toggle{display:flex;align-items:center;gap:10px;margin:0 0 16px;padding:10px 14px;background:var(--bg-dark,#0f1117);border-radius:8px;border:1px solid var(--border,#2d3140)}',
      '.sp-env-label{font-size:13px;font-weight:500;color:var(--text-muted,#8b8fa3);cursor:pointer;transition:all .2s;user-select:none}',
      '.sp-env-label.sp-active{font-weight:700}',
      '.sp-switch{position:relative;display:inline-block;width:44px;height:24px;flex-shrink:0}',
      '.sp-switch input{display:none}',
      '.sp-slider{position:absolute;inset:0;background:#4a4f63;border-radius:12px;cursor:pointer;transition:.3s}',
      '.sp-slider:before{content:"";position:absolute;width:18px;height:18px;left:3px;bottom:3px;background:#fff;border-radius:50%;transition:.3s}',
      '.sp-switch input:checked+.sp-slider{background:#38bdf8}',
      '.sp-switch input:checked+.sp-slider:before{transform:translateX(20px)}',
      '.sp-token-row{display:flex;align-items:center;gap:10px;margin-top:14px;padding-top:14px;border-top:1px solid var(--border,#2d3140)}',
      '.sp-btn-token{background:none;border:1px solid var(--accent,#6c8cff);color:var(--accent,#6c8cff);padding:8px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;font-family:inherit;transition:all .2s;display:flex;align-items:center;gap:6px}',
      '.sp-btn-token:hover{background:rgba(108,140,255,.1)}',
      '.sp-btn-token:disabled{opacity:.5;cursor:not-allowed}',
      '.sp-tok-status{font-size:12px;color:var(--text-muted,#8b8fa3)}',
      '.sp-tok-status.sp-ok{color:var(--green,#34d399)}',
      '.sp-tok-status.sp-err{color:var(--red,#f87171)}'
    ].join('');

    var el = document.createElement('style');
    el.id = 'settings-panel-css';
    el.textContent = css;
    document.head.appendChild(el);
  }

  // ─── Public entry point ────────────────────────────────────────────────────
  function initSettingsPanel() {
    injectStyles();
    var container = document.getElementById('panel-credentials');
    if (!container) {
      console.warn('[settings-panel] #panel-credentials not found');
      return;
    }

    container.innerHTML = buildPanelHTML();
    _bindTabButtons();
    loadAllKeys();
  }

  // ─── Build full panel HTML ─────────────────────────────────────────────────
  function buildPanelHTML() {
    var html = '';

    // Tab nav
    html += '<div class="sp-tab-nav">';
    html += '<button class="sp-tab-btn sp-active" id="sp-tabBtn-settings" onclick="spSwitchTab(\'settings\')">&#9881; 설정</button>';
    html += '</div>';

    // Settings tab content
    html += '<div id="sp-tab-settings">';
    html += buildSettingsTabHTML();
    html += '</div>';

    // Fallback toast (used when parent showToast is unavailable)
    if (!document.getElementById('sp-toast')) {
      html += '<div class="sp-toast" id="sp-toast"></div>';
    }

    return html;
  }

  function buildSettingsTabHTML() {
    var html = '';

    // Server status banner
    html += '<div class="sp-server-banner" id="sp-serverBanner">';
    html += '<div class="sp-server-dot sp-loading" id="sp-serverDot"></div>';
    html += '<span id="sp-serverMsg">서버 연결 확인 중...</span>';
    html += '</div>';

    // Module cards
    html += '<div class="sp-section-label">모듈별 API 키 설정</div>';
    html += '<div id="sp-moduleCards">';
    for (var i = 0; i < SETTINGS_MODULES.length; i++) {
      html += buildModuleCard(SETTINGS_MODULES[i]);
    }
    html += '</div>';

    return html;
  }

  // ─── Build one module card ─────────────────────────────────────────────────
  function buildModuleCard(mod) {
    var isExpandable = mod.expandable !== false;
    var headerCls = 'sp-card-header' + (isExpandable ? '' : ' sp-no-expand');
    var headerClick = isExpandable ? ' onclick="spToggleCard(\'' + mod.id + '\')"' : '';

    var s = '<div class="sp-mod-card" id="sp-card-' + mod.id + '">';

    // Header
    s += '<div class="' + headerCls + '"' + headerClick + '>';

    // Icon
    s += '<div class="sp-mod-icon">';
    s += '<i class="' + mod.icon + '"></i>';
    s += '</div>';

    // Meta
    s += '<div class="sp-mod-meta">';
    s += '<div class="sp-mod-name-row">';
    s += '<span class="sp-mod-name">' + mod.name + '</span>';
    s += '<span class="sp-mod-badge" style="' + mod.badgeStyle + '">' + mod.badge + '</span>';
    s += '</div>';
    s += '<div class="sp-mod-status-row">';
    if (!isExpandable) {
      s += '<div class="sp-status-dot sp-on"></div>';
      s += '<span class="sp-status-label sp-set">항상 활성화</span>';
    } else {
      s += '<div class="sp-status-dot sp-unset" id="sp-sdot-' + mod.id + '"></div>';
      s += '<span class="sp-status-label" id="sp-stxt-' + mod.id + '">키 미설정</span>';
    }
    s += '</div>';
    s += '</div>'; // /mod-meta

    if (isExpandable) {
      s += '<span class="sp-expand-arrow" id="sp-arrow-' + mod.id + '">&#9660;</span>';
    }
    s += '</div>'; // /header

    // Body
    if (isExpandable) {
      s += '<div class="sp-card-body" id="sp-body-' + mod.id + '">';
      s += '<div class="sp-form-inner">';

      // Guide toggle
      if (mod.guide) {
        s += '<button class="sp-guide-btn" id="sp-gtbtn-' + mod.id + '" onclick="spToggleGuide(\'' + mod.id + '\')">발급 안내 보기 &#9660;</button>';
        s += '<div class="sp-api-guide" id="sp-guide-' + mod.id + '">' + mod.guide + '</div>';
      }

      // Env toggle (실전/모의 전환)
      if (mod.hasEnvToggle) {
        s += '<div class="sp-env-toggle">';
        s += '<span class="sp-env-label sp-active" id="sp-envLive-' + mod.id + '" style="color:' + (mod.liveColor || '#fb923c') + ';font-weight:700" onclick="spSetEnv(\'' + mod.id + '\',\'live\')">실전투자</span>';
        s += '<label class="sp-switch">';
        s += '<input type="checkbox" id="sp-envChk-' + mod.id + '" onchange="spToggleEnv(\'' + mod.id + '\')">';
        s += '<span class="sp-slider"></span>';
        s += '</label>';
        s += '<span class="sp-env-label" id="sp-envMock-' + mod.id + '" onclick="spSetEnv(\'' + mod.id + '\',\'mock\')">모의투자</span>';
        s += '</div>';
      }

      // Key fields
      for (var i = 0; i < mod.keys.length; i++) {
        var k = mod.keys[i];
        if (k.divider) continue; // 토글이 대체하므로 divider 무시
        var envAttr = k.env ? ' data-env="' + k.env + '"' : '';
        var hideStyle = (mod.hasEnvToggle && k.env === 'mock') ? ' style="display:none"' : '';
        s += '<div class="sp-field"' + envAttr + hideStyle + '>';
        s += '<label>' + k.label;
        s += k.required
          ? ' <span class="sp-req">필수</span>'
          : ' <span class="sp-opt">선택</span>';
        s += '</label>';
        s += '<div class="sp-input-wrap">';
        s += '<input type="password" id="sp-inp-' + k.id + '" placeholder="' + k.placeholder + '" autocomplete="off">';
        s += '<button class="sp-toggle-vis" onclick="spToggleKeyVis(this)" title="보기/숨기기">&#128065;</button>';
        s += '</div>';
        s += '</div>';
      }

      // Telegram auth section
      if (mod.hasAuth) {
        s += '<div class="sp-tg-auth" id="sp-tgAuth-' + mod.id + '">';
        s += '<div class="sp-tg-row">';
        s += '<div class="sp-tg-dot sp-disconnected" id="sp-tgDot-' + mod.id + '"></div>';
        s += '<span class="sp-tg-label" id="sp-tgLabel-' + mod.id + '">인증 상태 확인 중...</span>';
        s += '<button class="sp-btn-tg" id="sp-tgBtn-' + mod.id + '" onclick="spTgAction(\'' + mod.id + '\')">인증</button>';
        s += '</div>';
        s += '<div id="sp-tgExtra-' + mod.id + '"></div>';
        s += '</div>';
      }

      // Token issue button (for env-toggle modules)
      if (mod.hasEnvToggle) {
        s += '<div class="sp-token-row">';
        s += '<button class="sp-btn-token" id="sp-tok-' + mod.id + '" onclick="spIssueToken(\'' + mod.id + '\')"><i class="fas fa-key"></i> 실전 토큰 발급</button>';
        s += '<span class="sp-tok-status" id="sp-tokstat-' + mod.id + '"></span>';
        s += '</div>';
      }

      // Action buttons
      s += '<div class="sp-save-row">';
      s += '<button class="sp-btn-save" id="sp-bsave-' + mod.id + '" onclick="spSaveModule(\'' + mod.id + '\')">저장</button>';
      s += '<button class="sp-btn-clear" onclick="spClearModule(\'' + mod.id + '\')">키 삭제</button>';
      s += '</div>';

      s += '</div>'; // /form-inner
      s += '</div>'; // /card-body
    }

    s += '</div>'; // /mod-card
    return s;
  }

  // ─── Tab switching ─────────────────────────────────────────────────────────
  function spSwitchTab(tab) {
    _currentTab = tab;
    var settingsEl = document.getElementById('sp-tab-settings');
    var btnSettings = document.getElementById('sp-tabBtn-settings');

    settingsEl.style.display = '';
    btnSettings.classList.add('sp-active');
  }

  function _bindTabButtons() {
    // tabs are bound via inline onclick; nothing extra needed here
  }

  // ─── Card toggle ───────────────────────────────────────────────────────────
  function spToggleCard(modId) {
    var card  = document.getElementById('sp-card-'  + modId);
    var body  = document.getElementById('sp-body-'  + modId);
    var arrow = document.getElementById('sp-arrow-' + modId);
    if (!card || !body || !arrow) return;

    var isOpen = body.classList.contains('sp-show');
    if (isOpen) {
      body.classList.remove('sp-show');
      arrow.classList.remove('sp-open');
      card.classList.remove('sp-expanded');
    } else {
      body.classList.add('sp-show');
      arrow.classList.add('sp-open');
      card.classList.add('sp-expanded');
      var firstInput = body.querySelector('input');
      if (firstInput) {
        setTimeout(function () { firstInput.focus(); }, 40);
      }
    }
  }

  // ─── Guide toggle ──────────────────────────────────────────────────────────
  function spToggleGuide(modId) {
    var guide = document.getElementById('sp-guide-'  + modId);
    var btn   = document.getElementById('sp-gtbtn-' + modId);
    if (!guide || !btn) return;

    if (guide.classList.contains('sp-show')) {
      guide.classList.remove('sp-show');
      btn.innerHTML = '발급 안내 보기 &#9660;';
    } else {
      guide.classList.add('sp-show');
      btn.innerHTML = '발급 안내 접기 &#9650;';
    }
  }

  // ─── Key visibility toggle ─────────────────────────────────────────────────
  function spToggleKeyVis(btn) {
    var inp = btn.parentElement.querySelector('input');
    if (!inp) return;
    if (inp.type === 'password') {
      inp.type = 'text';
      btn.innerHTML = '&#128274;'; // lock
    } else {
      inp.type = 'password';
      btn.innerHTML = '&#128065;'; // eye
    }
  }

  // ─── Load all keys from server ─────────────────────────────────────────────
  function loadAllKeys() {
    var dot    = document.getElementById('sp-serverDot');
    var msg    = document.getElementById('sp-serverMsg');
    var banner = document.getElementById('sp-serverBanner');

    var xhr = new XMLHttpRequest();
    xhr.open('GET', API_BASE + '/api/keys', true);
    xhr.timeout = 8000;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var d = JSON.parse(xhr.responseText);
          _loadedKeys = d.keys || {};
          _populateAllFields();
          refreshStatusDots();
          _loadEnvState();
          _fetchStatusCount(function (info) {
            if (dot) dot.className = 'sp-server-dot sp-ok';
            if (banner) banner.className = 'sp-server-banner sp-ok';
            if (msg) {
              if (info) {
                msg.textContent = '서버 연결됨 — ' + info.modules + '개 모듈, ' + info.tools + '개 도구';
              } else {
                msg.textContent = '서버 연결됨';
              }
            }
            tgCheckAuth();
          });
        } catch (e) {
          _setServerError('응답 파싱 오류');
        }
      } else {
        _setServerError('서버 오류 (HTTP ' + xhr.status + ')');
      }
    };

    xhr.onerror   = function () { _setServerError('서버 연결 안 됨 — 서버가 실행 중인지 확인하세요'); };
    xhr.ontimeout = function () { _setServerError('연결 시간 초과'); };
    xhr.send();
  }

  function _setServerError(errMsg) {
    var dot    = document.getElementById('sp-serverDot');
    var banner = document.getElementById('sp-serverBanner');
    var msg    = document.getElementById('sp-serverMsg');
    if (dot)    dot.className    = 'sp-server-dot sp-error';
    if (banner) banner.className = 'sp-server-banner sp-error';
    if (msg)    msg.textContent  = errMsg;
  }

  function _fetchStatusCount(callback) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', API_BASE + '/api/status', true);
    xhr.timeout = 5000;
    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var d = JSON.parse(xhr.responseText);
          // Accept either d.ok or d.success style responses
          var modules = d.connected_modules || d.modules || 0;
          var tools   = d.total_tools || d.tools || 0;
          callback(tools || modules ? { modules: modules, tools: tools } : null);
        } catch (e) { callback(null); }
      } else { callback(null); }
    };
    xhr.onerror   = function () { callback(null); };
    xhr.ontimeout = function () { callback(null); };
    xhr.send();
  }

  // ─── Populate input fields ─────────────────────────────────────────────────
  function _populateAllFields() {
    for (var i = 0; i < SETTINGS_MODULES.length; i++) {
      var mod = SETTINGS_MODULES[i];
      if (!mod.expandable) continue;
      for (var j = 0; j < mod.keys.length; j++) {
        var k = mod.keys[j];
        if (k.divider) continue;
        var el = document.getElementById('sp-inp-' + k.id);
        if (el && _loadedKeys[k.id]) {
          el.value = _loadedKeys[k.id];
        }
      }
    }
  }

  // ─── Status dots ───────────────────────────────────────────────────────────
  function refreshStatusDots() {
    for (var i = 0; i < SETTINGS_MODULES.length; i++) {
      var mod = SETTINGS_MODULES[i];
      if (!mod.expandable) continue;
      _refreshModuleDot(mod);
    }
  }

  function _refreshModuleDot(mod) {
    var dot = document.getElementById('sp-sdot-' + mod.id);
    var txt = document.getElementById('sp-stxt-' + mod.id);
    if (!dot || !txt) return;

    var configured = _checkConfigured(mod);
    if (configured) {
      dot.className = 'sp-status-dot sp-set';
      txt.className = 'sp-status-label sp-set';
      txt.textContent = '설정됨';
    } else {
      dot.className = 'sp-status-dot sp-unset';
      txt.className = 'sp-status-label';
      txt.textContent = '키 미설정';
    }
  }

  function _checkConfigured(mod) {
    // First pass: any required key present
    for (var i = 0; i < mod.keys.length; i++) {
      var k = mod.keys[i];
      if (k.divider) continue;
      if (k.required && _loadedKeys[k.id]) return true;
    }
    // Second pass: any key present at all
    for (var i = 0; i < mod.keys.length; i++) {
      var k = mod.keys[i];
      if (k.divider) continue;
      if (_loadedKeys[k.id]) return true;
    }
    return false;
  }

  // ─── Save module ───────────────────────────────────────────────────────────
  function spSaveModule(modId) {
    var mod = _findMod(modId);
    if (!mod) return;

    var btn = document.getElementById('sp-bsave-' + modId);
    if (btn) { btn.disabled = true; btn.textContent = '저장 중...'; }

    var keys   = {};
    var hasAny = false;
    for (var i = 0; i < mod.keys.length; i++) {
      var k = mod.keys[i];
      if (k.divider) continue;
      var el = document.getElementById('sp-inp-' + k.id);
      if (el && el.value.trim()) {
        keys[k.id] = el.value.trim();
        hasAny = true;
      }
    }

    if (!hasAny) {
      spShowToast('입력된 키가 없습니다.', 'info');
      if (btn) { btn.disabled = false; btn.textContent = '저장'; }
      return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/keys', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 8000;

    xhr.onload = function () {
      if (btn) { btn.disabled = false; btn.textContent = '저장'; }
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var d = JSON.parse(xhr.responseText);
          // Accept d.ok or d.success
          if (d.ok || d.success) {
            for (var key in keys) { _loadedKeys[key] = keys[key]; }
            _refreshModuleDot(mod);
            spShowToast(mod.name + ' 키가 저장되었습니다.', 'success');
          } else {
            spShowToast('저장 실패: ' + (d.error || '알 수 없는 오류'), 'error');
          }
        } catch (e) {
          spShowToast('응답 파싱 오류', 'error');
        }
      } else {
        spShowToast('서버 오류 (HTTP ' + xhr.status + ')', 'error');
      }
    };
    xhr.onerror   = function () {
      if (btn) { btn.disabled = false; btn.textContent = '저장'; }
      spShowToast('서버 연결 실패', 'error');
    };
    xhr.ontimeout = function () {
      if (btn) { btn.disabled = false; btn.textContent = '저장'; }
      spShowToast('연결 시간 초과', 'error');
    };
    xhr.send(JSON.stringify({ keys: keys }));
  }

  // ─── Clear module ──────────────────────────────────────────────────────────
  function spClearModule(modId) {
    var mod = _findMod(modId);
    if (!mod) return;

    var hasAny = false;
    var keysToDelete = {};
    for (var i = 0; i < mod.keys.length; i++) {
      var k = mod.keys[i];
      if (k.divider) continue;
      if (_loadedKeys[k.id]) {
        keysToDelete[k.id] = '';
        hasAny = true;
      }
    }

    if (!hasAny) {
      spShowToast('삭제할 키가 없습니다.', 'info');
      return;
    }

    // Clear inputs immediately (optimistic)
    for (var i = 0; i < mod.keys.length; i++) {
      var k = mod.keys[i];
      if (k.divider) continue;
      var el = document.getElementById('sp-inp-' + k.id);
      if (el) el.value = '';
      delete _loadedKeys[k.id];
    }
    _refreshModuleDot(mod);

    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/keys', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 8000;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        spShowToast(mod.name + ' 키가 삭제되었습니다.', 'success');
      } else {
        spShowToast('서버 오류 — 로컬 상태만 초기화됨', 'info');
      }
    };
    xhr.onerror   = function () { spShowToast('서버 연결 실패 — 로컬 상태만 초기화됨', 'info'); };
    xhr.ontimeout = function () { spShowToast('연결 시간 초과 — 로컬 상태만 초기화됨', 'info'); };
    xhr.send(JSON.stringify({ keys: keysToDelete }));
  }

  // ─── Telegram auth ─────────────────────────────────────────────────────────
  function tgCheckAuth() {
    var dot   = document.getElementById('sp-tgDot-telegram');
    var label = document.getElementById('sp-tgLabel-telegram');
    var btn   = document.getElementById('sp-tgBtn-telegram');
    if (!dot) return;

    var xhr = new XMLHttpRequest();
    xhr.open('GET', API_BASE + '/api/telegram', true);
    xhr.timeout = 5000;

    xhr.onload = function () {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          var d = JSON.parse(xhr.responseText);
          if ((d.ok || d.success) && d.status === 'connected') {
            _tgState = 'connected';
            dot.className   = 'sp-tg-dot sp-connected';
            label.className = 'sp-tg-label sp-ok';
            label.textContent = '연결됨' + (d.user ? ' (' + d.user + ')' : '');
            if (btn) btn.style.display = 'none';
          } else {
            _tgState = 'disconnected';
            dot.className   = 'sp-tg-dot sp-disconnected';
            label.className = 'sp-tg-label';
            label.textContent = '인증 필요';
            if (btn) { btn.textContent = '인증 코드 보내기'; btn.style.display = ''; }
          }
        } catch (e) { _setTgError('응답 파싱 오류'); }
      } else { _setTgError('서버 오류'); }
    };
    xhr.onerror   = function () { _setTgError('서버 연결 안 됨'); };
    xhr.ontimeout = function () { _setTgError('연결 시간 초과'); };
    xhr.send();
  }

  function _setTgError(msg) {
    var dot   = document.getElementById('sp-tgDot-telegram');
    var label = document.getElementById('sp-tgLabel-telegram');
    var btn   = document.getElementById('sp-tgBtn-telegram');
    _tgState = 'disconnected';
    if (dot)   dot.className   = 'sp-tg-dot sp-error';
    if (label) { label.className = 'sp-tg-label'; label.textContent = msg; }
    if (btn)   btn.style.display = 'none';
  }

  function spTgAction(modId) {
    if (_tgState === 'code_sent') return;

    var btn   = document.getElementById('sp-tgBtn-'   + modId);
    var label = document.getElementById('sp-tgLabel-' + modId);
    var dot   = document.getElementById('sp-tgDot-'   + modId);
    var extra = document.getElementById('sp-tgExtra-' + modId);

    if (btn)   { btn.disabled = true; btn.textContent = '전송 중...'; }
    if (label) label.textContent = '코드 전송 중...';
    if (dot)   dot.className = 'sp-tg-dot sp-pending';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/telegram', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 15000;

    xhr.onload = function () {
      if (btn) btn.disabled = false;
      try {
        var d = JSON.parse(xhr.responseText);
        if ((d.ok || d.success) && d.status === 'code_sent') {
          _tgState = 'code_sent';
          if (label) label.textContent = '코드 전송됨' + (d.phone ? ' (' + d.phone + ')' : '');
          if (btn)   btn.style.display = 'none';
          if (extra) {
            extra.innerHTML =
              '<div class="sp-tg-code-row">' +
              '<input type="text" id="sp-tgCodeInp-' + modId + '" placeholder="인증 코드" maxlength="10">' +
              '<button class="sp-btn-tg" onclick="spTgVerifyCode(\'' + modId + '\')">확인</button>' +
              '</div>';
            var inp = document.getElementById('sp-tgCodeInp-' + modId);
            if (inp) setTimeout(function () { inp.focus(); }, 50);
          }
        } else {
          if (dot)   dot.className = 'sp-tg-dot sp-error';
          if (label) label.textContent = (d.error || '전송 실패');
          if (btn)   { btn.textContent = '다시 시도'; btn.style.display = ''; }
        }
      } catch (e) {
        if (dot)   dot.className = 'sp-tg-dot sp-error';
        if (label) label.textContent = '응답 오류';
        if (btn)   { btn.textContent = '다시 시도'; btn.style.display = ''; }
      }
    };
    xhr.onerror = function () {
      if (btn)   { btn.disabled = false; btn.textContent = '다시 시도'; btn.style.display = ''; }
      if (dot)   dot.className = 'sp-tg-dot sp-error';
      if (label) label.textContent = '서버 연결 실패';
    };
    xhr.send(JSON.stringify({ action: 'send_code' }));
  }

  function spTgVerifyCode(modId) {
    var inp   = document.getElementById('sp-tgCodeInp-' + modId);
    var code  = inp ? inp.value.trim() : '';
    if (!code) { spShowToast('코드를 입력하세요', 'info'); return; }

    var label = document.getElementById('sp-tgLabel-' + modId);
    var dot   = document.getElementById('sp-tgDot-'   + modId);
    var extra = document.getElementById('sp-tgExtra-' + modId);
    if (label) label.textContent = '확인 중...';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/telegram', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 15000;

    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if ((d.ok || d.success) && d.status === 'connected') {
          _tgState = 'connected';
          if (dot)   dot.className   = 'sp-tg-dot sp-connected';
          if (label) { label.className = 'sp-tg-label sp-ok'; label.textContent = '연결됨'; }
          if (extra) extra.innerHTML = '';
          var btn = document.getElementById('sp-tgBtn-' + modId);
          if (btn) btn.style.display = 'none';
          spShowToast('텔레그램 인증 성공!', 'success');
        } else if ((d.ok || d.success) && d.status === 'need_2fa') {
          if (label) label.textContent = '2FA 비밀번호 필요';
          if (extra) {
            extra.innerHTML =
              '<div class="sp-tg-code-row">' +
              '<input type="password" id="sp-tg2faInp-' + modId + '" placeholder="2FA 비밀번호">' +
              '<button class="sp-btn-tg" onclick="spTgVerify2fa(\'' + modId + '\')">확인</button>' +
              '</div>';
            var inp2 = document.getElementById('sp-tg2faInp-' + modId);
            if (inp2) setTimeout(function () { inp2.focus(); }, 50);
          }
        } else {
          if (dot)   dot.className = 'sp-tg-dot sp-error';
          if (label) label.textContent = (d.error || '인증 실패');
          spShowToast('인증 실패: ' + (d.error || ''), 'error');
        }
      } catch (e) {
        if (dot)   dot.className = 'sp-tg-dot sp-error';
        if (label) label.textContent = '응답 오류';
      }
    };
    xhr.onerror = function () {
      if (dot)   dot.className = 'sp-tg-dot sp-error';
      if (label) label.textContent = '서버 연결 실패';
    };
    xhr.send(JSON.stringify({ action: 'verify', code: code }));
  }

  function spTgVerify2fa(modId) {
    var inp = document.getElementById('sp-tg2faInp-' + modId);
    var pw  = inp ? inp.value.trim() : '';
    if (!pw) { spShowToast('비밀번호를 입력하세요', 'info'); return; }

    var label = document.getElementById('sp-tgLabel-' + modId);
    var dot   = document.getElementById('sp-tgDot-'   + modId);
    var extra = document.getElementById('sp-tgExtra-' + modId);
    if (label) label.textContent = '확인 중...';

    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/telegram', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 15000;

    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if ((d.ok || d.success) && d.status === 'connected') {
          _tgState = 'connected';
          if (dot)   dot.className   = 'sp-tg-dot sp-connected';
          if (label) { label.className = 'sp-tg-label sp-ok'; label.textContent = '연결됨'; }
          if (extra) extra.innerHTML = '';
          var btn = document.getElementById('sp-tgBtn-' + modId);
          if (btn) btn.style.display = 'none';
          spShowToast('텔레그램 인증 성공!', 'success');
        } else {
          if (dot)   dot.className = 'sp-tg-dot sp-error';
          if (label) label.textContent = (d.error || '2FA 실패');
          spShowToast('2FA 인증 실패: ' + (d.error || ''), 'error');
        }
      } catch (e) {
        if (dot)   dot.className = 'sp-tg-dot sp-error';
        if (label) label.textContent = '응답 오류';
      }
    };
    xhr.onerror = function () {
      if (dot)   dot.className = 'sp-tg-dot sp-error';
      if (label) label.textContent = '서버 연결 실패';
    };
    xhr.send(JSON.stringify({ action: 'verify_2fa', password: pw }));
  }

  // ─── Env toggle (실전/모의 전환) ──────────────────────────────────────────
  var _envState = {}; // { kiwoom: 'live', kis: 'live' }

  function spToggleEnv(modId) {
    var chk = document.getElementById('sp-envChk-' + modId);
    if (!chk) return;
    spSetEnv(modId, chk.checked ? 'mock' : 'live');
  }

  function spSetEnv(modId, env) {
    var mod = _findMod(modId);
    if (!mod || !mod.hasEnvToggle) return;

    _envState[modId] = env;
    _refreshEnvUI(modId, env);

    // POST /api/env to persist
    var body = {};
    body[mod.envKey] = mod.envValues[env] || env;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', API_BASE + '/api/env', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 5000;
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok && d.token_invalidated) {
          var stat = document.getElementById('sp-tokstat-' + modId);
          if (stat) { stat.textContent = '모드 변경됨 — 토큰 재발급 필요'; stat.className = 'sp-tok-status sp-err'; }
        }
      } catch (e) {}
    };
    xhr.onerror = function () { spShowToast('서버 연결 실패', 'error'); };
    xhr.send(JSON.stringify(body));
  }

  function _refreshEnvUI(modId, env) {
    var mod = _findMod(modId);
    if (!mod) return;
    var isMock = (env === 'mock');

    // Toggle checkbox
    var chk = document.getElementById('sp-envChk-' + modId);
    if (chk) chk.checked = isMock;

    // Label active state
    var liveLabel = document.getElementById('sp-envLive-' + modId);
    var mockLabel = document.getElementById('sp-envMock-' + modId);
    if (liveLabel) {
      liveLabel.className = 'sp-env-label' + (isMock ? '' : ' sp-active');
      liveLabel.style.color = isMock ? 'var(--text-muted,#8b8fa3)' : (mod.liveColor || '#fb923c');
      liveLabel.style.fontWeight = isMock ? '500' : '700';
    }
    if (mockLabel) {
      mockLabel.className = 'sp-env-label' + (isMock ? ' sp-active' : '');
      mockLabel.style.color = isMock ? (mod.mockColor || '#38bdf8') : 'var(--text-muted,#8b8fa3)';
      mockLabel.style.fontWeight = isMock ? '700' : '500';
    }

    // Show/hide key fields
    var body = document.getElementById('sp-body-' + modId);
    if (body) {
      var fields = body.querySelectorAll('.sp-field[data-env]');
      for (var i = 0; i < fields.length; i++) {
        var fieldEnv = fields[i].getAttribute('data-env');
        fields[i].style.display = (fieldEnv === env) ? '' : 'none';
      }
    }

    // Token button label
    var tokBtn = document.getElementById('sp-tok-' + modId);
    if (tokBtn) {
      tokBtn.innerHTML = '<i class="fas fa-key"></i> ' + (isMock ? '모의' : '실전') + ' 토큰 발급';
    }
  }

  function spIssueToken(modId) {
    var mod = _findMod(modId);
    if (!mod || !mod.hasEnvToggle) return;

    var btn = document.getElementById('sp-tok-' + modId);
    var stat = document.getElementById('sp-tokstat-' + modId);
    if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> 발급 중...'; }
    if (stat) { stat.textContent = '토큰 발급 중...'; stat.className = 'sp-tok-status'; }

    var endpoint, body;
    if (modId === 'kiwoom') {
      endpoint = API_BASE + '/api/kiwoom/call';
      body = JSON.stringify({ api_code: 'issueToken', params: {} });
    } else if (modId === 'kis') {
      // KIS token — 한투는 별도 인증 API 사용
      endpoint = API_BASE + '/api/kis/auth';
      body = JSON.stringify({ action: 'token' });
    } else {
      return;
    }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', endpoint, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.timeout = 15000;

    var env = _envState[modId] || 'live';
    xhr.onload = function () {
      var envLabel = (env === 'mock') ? '모의' : '실전';
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-key"></i> ' + envLabel + ' 토큰 발급'; }
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok || d.success) {
          if (stat) { stat.textContent = envLabel + ' 토큰 발급 완료'; stat.className = 'sp-tok-status sp-ok'; }
          spShowToast(mod.name + ' ' + envLabel + ' 토큰 발급 성공', 'success');
        } else {
          if (stat) { stat.textContent = '실패: ' + (d.error || '알 수 없는 오류'); stat.className = 'sp-tok-status sp-err'; }
          spShowToast('토큰 발급 실패: ' + (d.error || ''), 'error');
        }
      } catch (e) {
        if (stat) { stat.textContent = '응답 오류'; stat.className = 'sp-tok-status sp-err'; }
      }
    };
    xhr.onerror = function () {
      var envLabel = (env === 'mock') ? '모의' : '실전';
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-key"></i> ' + envLabel + ' 토큰 발급'; }
      if (stat) { stat.textContent = '서버 연결 실패'; stat.className = 'sp-tok-status sp-err'; }
    };
    xhr.ontimeout = function () {
      var envLabel = (env === 'mock') ? '모의' : '실전';
      if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-key"></i> ' + envLabel + ' 토큰 발급'; }
      if (stat) { stat.textContent = '시간 초과'; stat.className = 'sp-tok-status sp-err'; }
    };
    xhr.send(body);
  }

  function _loadEnvState() {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', API_BASE + '/api/env', true);
    xhr.timeout = 5000;
    xhr.onload = function () {
      try {
        var d = JSON.parse(xhr.responseText);
        if (d.ok) {
          // kiwoom: live/mock
          var kwEnv = d.kiwoom_env === 'mock' ? 'mock' : 'live';
          _envState['kiwoom'] = kwEnv;
          _refreshEnvUI('kiwoom', kwEnv);
          // kis: real/demo → live/mock
          var kisEnv = d.kis_env === 'demo' ? 'mock' : 'live';
          _envState['kis'] = kisEnv;
          _refreshEnvUI('kis', kisEnv);
        }
      } catch (e) {}
    };
    xhr.send();
  }

  // ─── Toast ─────────────────────────────────────────────────────────────────
  function spShowToast(msg, type) {
    // Prefer parent page's showToast if available
    if (typeof window.showToast === 'function') {
      window.showToast(msg, type || 'success');
      return;
    }
    // Fallback: own toast element
    var el = document.getElementById('sp-toast');
    if (!el) {
      el = document.createElement('div');
      el.id = 'sp-toast';
      el.className = 'sp-toast';
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.className = 'sp-toast sp-' + (type || 'success') + ' sp-show';
    clearTimeout(el._tid);
    el._tid = setTimeout(function () { el.classList.remove('sp-show'); }, 3500);
  }

  // ─── Utils ─────────────────────────────────────────────────────────────────
  function _findMod(modId) {
    for (var i = 0; i < SETTINGS_MODULES.length; i++) {
      if (SETTINGS_MODULES[i].id === modId) return SETTINGS_MODULES[i];
    }
    return null;
  }

  function _esc(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ─── Expose globals (inline onclick handlers need these) ──────────────────
  window.initSettingsPanel  = initSettingsPanel;
  window.spSwitchTab        = spSwitchTab;
  window.spToggleCard       = spToggleCard;
  window.spToggleGuide      = spToggleGuide;
  window.spToggleKeyVis     = spToggleKeyVis;
  window.spSaveModule       = spSaveModule;
  window.spClearModule      = spClearModule;
  window.spTgAction         = spTgAction;
  window.spTgVerifyCode     = spTgVerifyCode;
  window.spTgVerify2fa      = spTgVerify2fa;

  // Also expose internal helpers for external callers if needed
  window.spRefreshStatusDots = refreshStatusDots;
  window.spLoadAllKeys       = loadAllKeys;
  window.spSetEnv            = spSetEnv;
  window.spToggleEnv         = spToggleEnv;
  window.spIssueToken        = spIssueToken;

})();
